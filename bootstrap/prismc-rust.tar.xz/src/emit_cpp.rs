//! The module `EmitCpp`, from `target/bootstrap/src/prismc/emit_cpp.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (docs/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;
#[allow(unused_imports)]
use crate::{program, ast, check_blocks, check_env, check_errors, check_expr, check_passes, check_types, cpp_prelude_template, cpp_templates, emit, fs, lexer, lower, parser, prelude_template, process, rust_templates, sexp, typed};

/// `Cp`:
///
/// ```prism
/// type Cp = record:
/// ```
#[derive(Clone)]
pub struct Cp {
    pub home: Text,
    pub mods: Array<Text>,
    pub types: Map<Text, TyInfo>,
    pub ctors: Map<Text, Text>,
    pub members: Map<Text, bool>,
    pub methods: Map<Text, bool>,
    pub field_names: Map<Text, bool>,
    pub fns: Map<Text, bool>,
    pub fields: Map<Text, lower::OutTy>,
    pub renames: Map<Text, Text>,
    pub pointers: Map<Text, bool>,
}

impl ToPod for Cp {
    fn to_pod(&self) -> Pod {
        Pod::record("Cp", vec![("home", self.home.to_pod()), ("mods", self.mods.to_pod()), ("types", self.types.to_pod()), ("ctors", self.ctors.to_pod()), ("members", self.members.to_pod()), ("methods", self.methods.to_pod()), ("field_names", self.field_names.to_pod()), ("fns", self.fns.to_pod()), ("fields", self.fields.to_pod()), ("renames", self.renames.to_pod()), ("pointers", self.pointers.to_pod())])
    }
}

impl FromPod for Cp {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Cp { home: FromPod::from_pod(field(p, "home")?)?, mods: FromPod::from_pod(field(p, "mods")?)?, types: FromPod::from_pod(field(p, "types")?)?, ctors: FromPod::from_pod(field(p, "ctors")?)?, members: FromPod::from_pod(field(p, "members")?)?, methods: FromPod::from_pod(field(p, "methods")?)?, field_names: FromPod::from_pod(field(p, "field_names")?)?, fns: FromPod::from_pod(field(p, "fns")?)?, fields: FromPod::from_pod(field(p, "fields")?)?, renames: FromPod::from_pod(field(p, "renames")?)?, pointers: FromPod::from_pod(field(p, "pointers")?)? })
    }
}

/// `Parts`:
///
/// ```prism
/// type Parts = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Parts {
    pub forward: Array<Text>,
    pub handles: Array<Text>,
    pub values: Array<ValueDecl>,
    pub cases: Array<Text>,
    pub protos: Array<Text>,
    pub classes: Array<Text>,
    pub generic: Array<Text>,
    pub defs: Array<Text>,
}

impl Show for Parts {
    fn show(&self, p: &mut Printer) {
        p.record("Parts", &[("forward", &self.forward), ("handles", &self.handles), ("values", &self.values), ("cases", &self.cases), ("protos", &self.protos), ("classes", &self.classes), ("generic", &self.generic), ("defs", &self.defs)]);
    }
}

impl ToPod for Parts {
    fn to_pod(&self) -> Pod {
        Pod::record("Parts", vec![("forward", self.forward.to_pod()), ("handles", self.handles.to_pod()), ("values", self.values.to_pod()), ("cases", self.cases.to_pod()), ("protos", self.protos.to_pod()), ("classes", self.classes.to_pod()), ("generic", self.generic.to_pod()), ("defs", self.defs.to_pod())])
    }
}

impl FromPod for Parts {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Parts { forward: FromPod::from_pod(field(p, "forward")?)?, handles: FromPod::from_pod(field(p, "handles")?)?, values: FromPod::from_pod(field(p, "values")?)?, cases: FromPod::from_pod(field(p, "cases")?)?, protos: FromPod::from_pod(field(p, "protos")?)?, classes: FromPod::from_pod(field(p, "classes")?)?, generic: FromPod::from_pod(field(p, "generic")?)?, defs: FromPod::from_pod(field(p, "defs")?)? })
    }
}

/// `TyInfo`:
///
/// ```prism
/// type TyInfo = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct TyInfo {
    pub kind: Text,
    pub fields: Array<Text>,
    pub params: Array<Text>,
}

impl Show for TyInfo {
    fn show(&self, p: &mut Printer) {
        p.record("TyInfo", &[("kind", &self.kind), ("fields", &self.fields), ("params", &self.params)]);
    }
}

impl ToPod for TyInfo {
    fn to_pod(&self) -> Pod {
        Pod::record("TyInfo", vec![("kind", self.kind.to_pod()), ("fields", self.fields.to_pod()), ("params", self.params.to_pod())])
    }
}

impl FromPod for TyInfo {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(TyInfo { kind: FromPod::from_pod(field(p, "kind")?)?, fields: FromPod::from_pod(field(p, "fields")?)?, params: FromPod::from_pod(field(p, "params")?)? })
    }
}

/// `ValueDecl`:
///
/// ```prism
/// type ValueDecl = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct ValueDecl {
    pub path_: Text,
    pub deps: Array<Text>,
    pub text: Text,
}

impl Show for ValueDecl {
    fn show(&self, p: &mut Printer) {
        p.record("ValueDecl", &[("path", &self.path_), ("deps", &self.deps), ("text", &self.text)]);
    }
}

impl ToPod for ValueDecl {
    fn to_pod(&self) -> Pod {
        Pod::record("ValueDecl", vec![("path", self.path_.to_pod()), ("deps", self.deps.to_pod()), ("text", self.text.to_pod())])
    }
}

impl FromPod for ValueDecl {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(ValueDecl { path_: FromPod::from_pod(field(p, "path")?)?, deps: FromPod::from_pod(field(p, "deps")?)?, text: FromPod::from_pod(field(p, "text")?)? })
    }
}

/// ```prism
/// CppId: fn Text -> Text
/// ```
pub fn cpp_id(n: &Text) -> Text {
    if in_list(&cpp_keywords(), n) { Text::from(format!("{}_", n)) } else { n.clone() }
}

/// ```prism
/// let cppKeywords
/// ```
pub fn cpp_keywords() -> Array<Text> {
    Array::from(vec![Text::from("explicit"), Text::from("and"), Text::from("and_eq"), Text::from("asm"), Text::from("auto"), Text::from("bitand"), Text::from("bitor"), Text::from("bool"), Text::from("case"), Text::from("catch"), Text::from("char"), Text::from("char8_t"), Text::from("char16_t"), Text::from("char32_t"), Text::from("class"), Text::from("compl"), Text::from("concept"), Text::from("const_cast"), Text::from("consteval"), Text::from("constexpr"), Text::from("constinit"), Text::from("co_await"), Text::from("co_return"), Text::from("co_yield"), Text::from("decltype"), Text::from("default"), Text::from("delete"), Text::from("double"), Text::from("dynamic_cast"), Text::from("explicit"), Text::from("export"), Text::from("extern"), Text::from("float"), Text::from("friend"), Text::from("goto"), Text::from("inline"), Text::from("int"), Text::from("long"), Text::from("mutable"), Text::from("namespace"), Text::from("new"), Text::from("noexcept"), Text::from("not"), Text::from("not_eq"), Text::from("nullptr"), Text::from("operator"), Text::from("or"), Text::from("or_eq"), Text::from("private"), Text::from("protected"), Text::from("public"), Text::from("register"), Text::from("reinterpret_cast"), Text::from("requires"), Text::from("short"), Text::from("signed"), Text::from("sizeof"), Text::from("static_assert"), Text::from("static_cast"), Text::from("switch"), Text::from("template"), Text::from("this"), Text::from("thread_local"), Text::from("throw"), Text::from("try"), Text::from("typedef"), Text::from("typeid"), Text::from("typename"), Text::from("union"), Text::from("unsigned"), Text::from("using"), Text::from("virtual"), Text::from("void"), Text::from("volatile"), Text::from("wchar_t"), Text::from("xor"), Text::from("xor_eq"), Text::from("errno"), Text::from("assert"), Text::from("NULL"), Text::from("EOF"), Text::from("stdin"), Text::from("stdout"), Text::from("stderr"), Text::from("major"), Text::from("minor")])
}

/// ```prism
/// FieldId: fn Text -> Text
/// ```
pub fn field_id(f: &Text) -> Text {
    if in_list(&Array::from(vec![Text::from("show"), Text::from("to_pod"), Text::from("from_pod"), Text::from("cases")]), f) {
        Text::from(format!("{}_", f))
    } else {
        cpp_id(f)
    }
}

/// ```prism
/// CppPathId: fn Text -> Text
/// ```
pub fn cpp_path_id(p_: &Text) -> Text {
    lexer::join(&each(&split(p_, &Text::from("::")), &(|s: &Text| cpp_id(s))), &Text::from("::"))
}

/// ```prism
/// InList: fn [Text], Text -> Bool
/// ```
pub fn in_list(xs: &Array<Text>, x: &Text) -> bool {
    fold(xs, &false, &(|seen: &bool, y: &Text| *seen || (y == x)))
}

/// ```prism
/// Absolute: fn Cp, Text -> Text
/// ```
pub fn absolute(cp: &Cp, p_: &Text) -> Text {
    let q = lexer::drop_prefix(p_, &Text::from("crate::"));
    let first_ = or(&index(&split(&q, &Text::from("::")), &Nat::from(0u32)), &Text::from(""));
    if in_list(&cp.mods, &first_) {
        q.clone()
    } else {
        Text::from(format!("{}::{}", &cp.home, &q))
    }
}

/// ```prism
/// ?TypeOf: fn Cp, Text -> ?TyInfo
/// ```
pub fn type_of(cp: &Cp, p_: &Text) -> Option<TyInfo> {
    let q = lexer::drop_prefix(p_, &Text::from("crate::"));
    match get(&cp.types, &absolute(cp, &q)) {
        Some(t) => Some(t.clone()),
        None => match get(&cp.types, &Text::from(format!("prelude::{}", &q))) {
            Some(t) => Some(t.clone()),
            None => get(&cp.types, &q),
        },
    }
}

/// ```prism
/// ?CaseOf: fn Cp, Text -> ?Text
/// ```
pub fn case_of(cp: &Cp, p_: &Text) -> Option<Text> {
    let q = lexer::drop_prefix(p_, &Text::from("crate::"));
    match get(&cp.ctors, &absolute(cp, &q)) {
        Some(_) => Some(parent_path(p_)),
        None => match get(&cp.ctors, &Text::from(format!("prelude::{}", &q))) {
            Some(_) => Some(parent_path(p_)),
            None => match get(&cp.ctors, &q) {
                Some(_) => Some(parent_path(p_)),
                None => None,
            },
        },
    }
}

/// ```prism
/// ParentPath: fn Text -> Text
/// ```
pub fn parent_path(p_: &Text) -> Text {
    let segs = split(p_, &Text::from("::"));
    lexer::join(&take(&segs, &lexer::dec(&len(&segs))), &Text::from("::"))
}

/// ```prism
/// LastSegment: fn Text -> Text
/// ```
pub fn last_segment(p_: &Text) -> Text {
    or(&lexer::last(&split(p_, &Text::from("::"))), p_)
}

/// ```prism
/// Context: fn Model -> Cp
/// ```
pub fn context(model: &lower::Model) -> Cp {
    let mods = push(&each(&model.mods, &(|m: &lower::ModDef| m.name.clone())), &Text::from("prelude"));
    let base = Cp { home: Text::from(""), mods: mods.clone(), types: prelude_types(), ctors: prelude_ctors(), members: node_base(), methods: Map::new(), field_names: Map::new(), fns: Map::new(), fields: Map::new(), renames: Map::new(), pointers: Map::new() };
    let with_elem = add_row(&add_answer(&base, &model.answer), &Text::from(""), &model.elem);
    fold(&model.mods, &with_elem, &(|cp: &Cp, m: &lower::ModDef| fold(&m.items, cp, &(|c: &Cp, it: &lower::Item| add_model_item(c, &m.name, it)))))
}

/// ```prism
/// let preludeTypes
/// ```
pub fn prelude_types() -> Map<Text, TyInfo> {
    map_of(vec![(Text::from("prelude::Ordering"), TyInfo { kind: Text::from("choice"), fields: Array::new(), params: Array::new() }), (Text::from("prelude::Span"), TyInfo { kind: Text::from("record"), fields: Array::from(vec![Text::from("file"), Text::from("line"), Text::from("column"), Text::from("binding")]), params: Array::new() }), (Text::from("prelude::Exception"), TyInfo { kind: Text::from("record"), fields: Array::from(vec![Text::from("kind"), Text::from("message"), Text::from("spans"), Text::from("path_")]), params: Array::new() }), (Text::from("prelude::Duration"), TyInfo { kind: Text::from("newtype"), fields: Array::new(), params: Array::new() }), (Text::from("prelude::PreludeUnwrap"), TyInfo { kind: Text::from("tag"), fields: Array::new(), params: Array::new() }), (Text::from("prelude::PreludeExceptions"), TyInfo { kind: Text::from("tag"), fields: Array::new(), params: Array::new() })])
}

/// ```prism
/// let preludeCtors
/// ```
pub fn prelude_ctors() -> Map<Text, Text> {
    map_of(vec![(Text::from("prelude::Ordering::Less"), Text::from("choice")), (Text::from("prelude::Ordering::Equal"), Text::from("choice")), (Text::from("prelude::Ordering::Greater"), Text::from("choice"))])
}

/// ```prism
/// let nodeBase
/// ```
pub fn node_base() -> Map<Text, bool> {
    map_of(vec![(Text::from("make"), true), (Text::from("push"), true), (Text::from("wake"), true), (Text::from("started"), true), (Text::from("deferred"), true), (Text::from("build"), true), (Text::from("swap"), true), (Text::from("leave"), true), (Text::from("patch"), true), (Text::from("edges"), true), (Text::from("release"), true), (Text::from("clean_up"), true), (Text::from("path"), true), (Text::from("leave_row"), true), (Text::from("answer"), true), (Text::from("document"), true), (Text::from("deliver"), true), (Text::from("document_moved"), true), (Text::from("me"), true), (Text::from("result_dynamic"), true)])
}

/// ```prism
/// AddModelItem: fn Cp, Text, Item -> Cp
/// ```
pub fn add_model_item(cp: &Cp, m: &Text, it: &lower::Item) -> Cp {
    match it {
        lower::Item::ItType(t) => add_type(cp, m, t),
        lower::Item::ItTag(t) => add_ty(cp, &Text::from(format!("{}::{}", m, &t.name)), &TyInfo { kind: Text::from("tag"), fields: each(&t.fields, &(|(_, f, _): &(Text, Text, lower::OutTy)| f.clone())), params: Array::new() }),
        lower::Item::ItRow(r) => add_row(cp, m, r),
        lower::Item::ItJob(j) => add_ty(cp, &Text::from(format!("{}::{}", m, &j.name)), &TyInfo { kind: Text::from("job"), fields: each(&j.fields, &(|(f, _): &(Text, lower::OutTy)| f.clone())), params: each(&j.generics, &(|(g, _): &(Text, Array<Text>)| g.clone())) }),
        lower::Item::ItNode(n) => add_node(cp, m, n),
        lower::Item::ItFn(f) => {
            let mut this: Cp = cp.clone();
            this.fns = insert(&this.fns, &Text::from(format!("{}::{}", m, &f.name)), &true);
            this
        },
        _ => cp.clone(),
    }
}

/// ```prism
/// AddTy: fn Cp, Text, TyInfo -> Cp
/// ```
pub fn add_ty(cp: &Cp, path_: &Text, info: &TyInfo) -> Cp {
    let mut this: Cp = cp.clone();
    this.types = insert(&this.types, path_, info);
    this
}

/// ```prism
/// AddCtor: fn Cp, Text, Text -> Cp
/// ```
pub fn add_ctor(cp: &Cp, path_: &Text, kind: &Text) -> Cp {
    let mut this: Cp = cp.clone();
    this.ctors = insert(&this.ctors, path_, kind);
    this
}

/// ```prism
/// AddMember: fn Cp, Text -> Cp
/// ```
pub fn add_member(cp: &Cp, name: &Text) -> Cp {
    let mut this: Cp = cp.clone();
    this.members = insert(&this.members, name, &true);
    this
}

/// ```prism
/// AddType: fn Cp, Text, TyDef -> Cp
/// ```
pub fn add_type(cp: &Cp, m: &Text, t: &lower::TyDef) -> Cp {
    let path_ = Text::from(format!("{}::{}", m, &t.name));
    let first_ = or(&index(&t.cases, &Nat::from(0u32)), &lower::CaseDef { name: Text::from(""), prism: Text::from(""), fields: Array::new() });
    match &t.shape {
        lower::TyShape::ShapeRecord => add_ty(cp, &path_, &TyInfo { kind: Text::from("record"), fields: each(&first_.fields, &(|(f, _): &(Text, lower::OutTy)| f.clone())), params: t.params.clone() }),
        lower::TyShape::ShapeNewtype => add_ty(cp, &path_, &TyInfo { kind: Text::from("newtype"), fields: Array::new(), params: t.params.clone() }),
        lower::TyShape::ShapeUnit => add_ty(cp, &path_, &TyInfo { kind: Text::from("unit"), fields: Array::new(), params: t.params.clone() }),
        lower::TyShape::ShapeChoice => fold(&t.cases, &add_ty(cp, &path_, &TyInfo { kind: Text::from("choice"), fields: Array::new(), params: t.params.clone() }), &(|c: &Cp, k: &lower::CaseDef| add_ctor(c, &Text::from(format!("{}::{}", &path_, &k.name)), &Text::from("choice")))),
    }
}

/// ```prism
/// AddRow: fn Cp, Text, RowDef -> Cp
/// ```
pub fn add_row(cp: &Cp, m: &Text, r: &lower::RowDef) -> Cp {
    let path_ = if m == &Text::from("") {
        r.name.clone()
    } else {
        Text::from(format!("{}::{}", m, &r.name))
    };
    fold(&r.cases, &add_ty(cp, &path_, &TyInfo { kind: Text::from("choice"), fields: Array::new(), params: Array::new() }), &(|c: &Cp, (v_, _): &(Text, Text)| add_ctor(c, &Text::from(format!("{}::{}", &path_, v_)), &Text::from("choice"))))
}

/// ```prism
/// AddAnswer: fn Cp, AnswerDef -> Cp
/// ```
pub fn add_answer(cp: &Cp, a: &lower::AnswerDef) -> Cp {
    fold(&a.cases, &add_ty(cp, &Text::from("Answer"), &TyInfo { kind: Text::from("choice"), fields: Array::new(), params: Array::new() }), &(|c: &Cp, k: &lower::AnswerCase| add_ctor(c, &Text::from(format!("Answer::{}", &k.variant)), &Text::from("choice"))))
}

/// ```prism
/// AddNode: fn Cp, Text, NodeDef -> Cp
/// ```
pub fn add_node(cp: &Cp, m: &Text, n: &lower::NodeDef) -> Cp {
    let with_fields_ = fold(&n.fields, cp, &(|c: &Cp, (f, _, _): &(Text, lower::OutTy, Text)| {
        let mut this: Cp = add_member(c, f);
        this.field_names = insert(&this.field_names, f, &true);
        this
    }));
    let with_methods = fold(&append(&n.methods, &n.hosted), &with_fields_, &(|c: &Cp, md: &lower::MethDef| {
        let mut this: Cp = add_member(c, &md.name);
        this.methods = insert(&this.methods, &md.name, &true);
        this
    }));
    let with_builders = fold(&n.builders, &with_methods, &(|c: &Cp, b: &lower::ForDef| add_member(c, &Text::from(format!("{}_build", &b.name)))));
    let with_gens = fold(&n.gens, &with_builders, &(|c: &Cp, g: &lower::GenDef| add_member(c, &Text::from(format!("{}_build", &g.name)))));
    add_ty(&with_gens, &Text::from(format!("{}::{}", m, &n.name)), &TyInfo { kind: Text::from("node"), fields: each(&n.fields, &(|(f, _, _): &(Text, lower::OutTy, Text)| f.clone())), params: Array::new() })
}

/// ```prism
/// InHome: fn Cp, Text -> Cp
/// ```
pub fn in_home(cp: &Cp, m: &Text) -> Cp {
    let mut this: Cp = cp.clone();
    this.home = m.clone();
    this
}

/// ```prism
/// WithFields: fn Cp, [((Text, OutTy))] -> Cp
/// ```
pub fn with_fields(cp: &Cp, fs: &Array<(Text, lower::OutTy)>) -> Cp {
    let mut this: Cp = cp.clone();
    this.fields = fold(fs, &Map::new(), &(|acc: &Map<Text, lower::OutTy>, (f, t): &(Text, lower::OutTy)| insert(acc, f, t)));
    this
}

/// ```prism
/// CppType: unbounded fn Cp, OutTy -> Text
/// ```
pub fn cpp_type(cp: &Cp, t: &lower::OutTy) -> Text {
    'm10328: {
        if let lower::OutTy::OutNat = t {
            break 'm10328 Text::from("Nat");
        }
        if let lower::OutTy::OutInt = t {
            break 'm10328 Text::from("Int");
        }
        if let lower::OutTy::OutU8 = t {
            break 'm10328 Text::from("std::uint8_t");
        }
        if let lower::OutTy::OutFloat = t {
            break 'm10328 Text::from("double");
        }
        if let lower::OutTy::OutBool = t {
            break 'm10328 Text::from("bool");
        }
        if let lower::OutTy::OutChar = t {
            break 'm10328 Text::from("char32_t");
        }
        if let lower::OutTy::OutText = t {
            break 'm10328 Text::from("Text");
        }
        if let lower::OutTy::OutCursor = t {
            break 'm10328 Text::from("Cursor");
        }
        if let lower::OutTy::OutUnit = t {
            break 'm10328 Text::from("Unit");
        }
        if let lower::OutTy::OutPath = t {
            break 'm10328 Text::from("Path");
        }
        if let lower::OutTy::OutDuration = t {
            break 'm10328 Text::from("Duration");
        }
        if let lower::OutTy::OutError = t {
            break 'm10328 Text::from("Error");
        }
        if let lower::OutTy::OutNamed(m10328_12_0, m10328_12_1) = t && (m10328_12_0 == &Text::from("Cell")) && (m10328_12_1.len() == 1) && let Some(i) = index(m10328_12_1, &Nat::from(0u32)) {
            break 'm10328 cpp_type(cp, &i);
        }
        if let lower::OutTy::OutNamed(m10328_13_0, m10328_13_1) = t && (m10328_13_0 == &Text::from("RefCell")) && (m10328_13_1.len() == 1) && let Some(i) = index(m10328_13_1, &Nat::from(0u32)) {
            break 'm10328 cpp_type(cp, &i);
        }
        if let lower::OutTy::OutNamed(m10328_14_0, m10328_14_1) = t && (m10328_14_0 == &Text::from("Vec")) && (m10328_14_1.len() == 1) && let Some(i) = index(m10328_14_1, &Nat::from(0u32)) {
            break 'm10328 Text::from(format!("std::vector<{}>", &cpp_type(cp, &i)));
        }
        if let lower::OutTy::OutNamed(m10328_15_0, m10328_15_1) = t && (m10328_15_0 == &Text::from("Result")) && (m10328_15_1.len() == 2) && let Some(a) = index(m10328_15_1, &Nat::from(0u32)) && let Some(b) = index(m10328_15_1, &Nat::from(1u32)) {
            break 'm10328 Text::from(format!("Expected<{}, {}>", &cpp_type(cp, &a), &cpp_type(cp, &b)));
        }
        if let lower::OutTy::OutNamed(n, m10328_16_1) = t && (m10328_16_1.len() == 0) {
            break 'm10328 own_type_path(cp, n);
        }
        if let lower::OutTy::OutNamed(n, args) = t {
            break 'm10328 Text::from(format!("{}<{}>", &own_type_path(cp, n), &cpp_types(cp, args)));
        }
        if let lower::OutTy::OutOpt(i) = t {
            break 'm10328 Text::from(format!("std::optional<{}>", &cpp_type(cp, &**i)));
        }
        if let lower::OutTy::OutRes(i) = t {
            break 'm10328 Text::from(format!("Fallible<{}>", &cpp_type(cp, &**i)));
        }
        if let lower::OutTy::OutTuple(ts) = t {
            break 'm10328 Text::from(format!("std::tuple<{}>", &cpp_types(cp, ts)));
        }
        if let lower::OutTy::OutArray(e) = t {
            break 'm10328 Text::from(format!("Array<{}>", &cpp_type(cp, &**e)));
        }
        if let lower::OutTy::OutMap(k, v_) = t {
            break 'm10328 Text::from(format!("Map<{}, {}>", &cpp_type(cp, &**k), &cpp_type(cp, &**v_)));
        }
        if let lower::OutTy::OutFn(ps, r) = t {
            break 'm10328 Text::from(format!("Fn<{}({})>", &cpp_type(cp, &**r), &param_types(cp, ps)));
        }
        if let lower::OutTy::OutRef(m10328_24_0) = t && let lower::OutTy::OutFn(ps, r) = &**m10328_24_0 {
            break 'm10328 Text::from(format!("const std::function<{}({})>&", &cpp_type(cp, &**r), &param_types(cp, ps)));
        }
        if let lower::OutTy::OutRef(m10328_25_0) = t && let lower::OutTy::OutSlice(i) = &**m10328_25_0 {
            break 'm10328 Text::from(format!("std::span<const {}>", &cpp_type(cp, &**i)));
        }
        if let lower::OutTy::OutRef(i) = t {
            break 'm10328 Text::from(format!("const {}&", &cpp_type(cp, &**i)));
        }
        if let lower::OutTy::OutJobFn(a, b) = t {
            break 'm10328 Text::from(format!("prism_rtl::Fn<prism_rtl::JobRef<{}>({})>", &cpp_type(cp, &**b), &cpp_type(cp, &**a)));
        }
        if let lower::OutTy::OutJob(b) = t {
            break 'm10328 Text::from(format!("prism_rtl::JobRef<{}>", &cpp_type(cp, &**b)));
        }
        if let lower::OutTy::OutEvent(i) = t {
            break 'm10328 Text::from(format!("Event<{}>", &cpp_type(cp, &**i)));
        }
        if let lower::OutTy::OutDyn(i) = t {
            break 'm10328 Text::from(format!("Dynamic<{}>", &cpp_type(cp, &**i)));
        }
        if let lower::OutTy::OutGen(n) = t {
            break 'm10328 n.clone();
        }
        if let lower::OutTy::OutRc(i) = t {
            break 'm10328 if is_value_ty(cp, &**i) {
                cpp_type(cp, &**i)
            } else {
                Text::from(format!("std::shared_ptr<{}>", &cpp_type(cp, &**i)))
            };
        }
        if let lower::OutTy::OutPod = t {
            break 'm10328 Text::from("Pod");
        }
        if let lower::OutTy::OutShowAny = t {
            break 'm10328 Text::from("std::shared_ptr<const DynShow>");
        }
        if let lower::OutTy::OutHold(i) = t {
            break 'm10328 Text::from(format!("Hold<{}>", &cpp_type(cp, &**i)));
        }
        if let lower::OutTy::OutStamped(i) = t {
            break 'm10328 Text::from(format!("Stamped<{}>", &cpp_type(cp, &**i)));
        }
        if let lower::OutTy::OutSnapshot(i) = t {
            break 'm10328 Text::from(format!("Snapshot<{}>", &cpp_type(cp, &**i)));
        }
        if let lower::OutTy::OutDefer(i) = t {
            break 'm10328 Text::from(format!("Defer<{}>", &cpp_type(cp, &**i)));
        }
        if let lower::OutTy::OutWeak(n) = t {
            break 'm10328 Text::from(format!("std::weak_ptr<{}>", &type_path(n)));
        }
        if let lower::OutTy::OutCell(i) = t {
            break 'm10328 cpp_type(cp, &**i);
        }
        if let lower::OutTy::OutWakes = t {
            break 'm10328 Text::from("Wakes");
        }
        if let lower::OutTy::OutCount = t {
            break 'm10328 Text::from("std::uint32_t");
        }
        if let lower::OutTy::OutObj(i) = t {
            break 'm10328 Text::from(format!("std::shared_ptr<{}>", &cpp_type(cp, &**i)));
        }
        if let lower::OutTy::OutSlice(i) = t {
            break 'm10328 Text::from(format!("std::span<const {}>", &cpp_type(cp, &**i)));
        }
        if let lower::OutTy::OutPort(i) = t {
            break 'm10328 Text::from(format!("Port<{}>", &cpp_type(cp, &**i)));
        }
        if let lower::OutTy::OutLive(i) = t {
            break 'm10328 Text::from(format!("Live<{}>", &cpp_type(cp, &**i)));
        }
        if let lower::OutTy::OutUnknown(m10328_47_0) = t && (m10328_47_0 == &Text::from("the job's turn")) {
            break 'm10328 Text::from("decltype(this->cycle())");
        }
        if let lower::OutTy::OutUnknown(what) = t {
            break 'm10328 Text::from(format!("Unit /* {} */", what));
        }
        if let lower::OutTy::OutQuantified(b) = t {
            break 'm10328 Text::from(format!("compile_error!(\"{}a quantified type variable of `{}`: no instantiation gives it a type\")", &lower::lowering_refusal(), b));
        }
        unreachable!("no clause matched")
    }
}

/// The step machine of `CppType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppType: unbounded fn Cp, OutTy -> Text
/// ```
pub struct CppType {
    pub cp: Cp,
    pub t: lower::OutTy,
}

impl prism_rtl::Job<Text> for CppType {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let t = &self.t;
        'm10328: {
            if let lower::OutTy::OutNat = t {
                break 'm10328 prism_rtl::Turn::Finished(Text::from("Nat"));
            }
            if let lower::OutTy::OutInt = t {
                break 'm10328 prism_rtl::Turn::Finished(Text::from("Int"));
            }
            if let lower::OutTy::OutU8 = t {
                break 'm10328 prism_rtl::Turn::Finished(Text::from("std::uint8_t"));
            }
            if let lower::OutTy::OutFloat = t {
                break 'm10328 prism_rtl::Turn::Finished(Text::from("double"));
            }
            if let lower::OutTy::OutBool = t {
                break 'm10328 prism_rtl::Turn::Finished(Text::from("bool"));
            }
            if let lower::OutTy::OutChar = t {
                break 'm10328 prism_rtl::Turn::Finished(Text::from("char32_t"));
            }
            if let lower::OutTy::OutText = t {
                break 'm10328 prism_rtl::Turn::Finished(Text::from("Text"));
            }
            if let lower::OutTy::OutCursor = t {
                break 'm10328 prism_rtl::Turn::Finished(Text::from("Cursor"));
            }
            if let lower::OutTy::OutUnit = t {
                break 'm10328 prism_rtl::Turn::Finished(Text::from("Unit"));
            }
            if let lower::OutTy::OutPath = t {
                break 'm10328 prism_rtl::Turn::Finished(Text::from("Path"));
            }
            if let lower::OutTy::OutDuration = t {
                break 'm10328 prism_rtl::Turn::Finished(Text::from("Duration"));
            }
            if let lower::OutTy::OutError = t {
                break 'm10328 prism_rtl::Turn::Finished(Text::from("Error"));
            }
            if let lower::OutTy::OutNamed(m10328_12_0, m10328_12_1) = t && (m10328_12_0 == &Text::from("Cell")) && (m10328_12_1.len() == 1) && let Some(i) = index(m10328_12_1, &Nat::from(0u32)) {
                break 'm10328 prism_rtl::Turn::More(Rc::new(CppType { cp: cp.clone(), t: i.clone() }));
            }
            if let lower::OutTy::OutNamed(m10328_13_0, m10328_13_1) = t && (m10328_13_0 == &Text::from("RefCell")) && (m10328_13_1.len() == 1) && let Some(i) = index(m10328_13_1, &Nat::from(0u32)) {
                break 'm10328 prism_rtl::Turn::More(Rc::new(CppType { cp: cp.clone(), t: i.clone() }));
            }
            if let lower::OutTy::OutNamed(m10328_14_0, m10328_14_1) = t && (m10328_14_0 == &Text::from("Vec")) && (m10328_14_1.len() == 1) && let Some(i) = index(m10328_14_1, &Nat::from(0u32)) {
                break 'm10328 {
                    let cp = cp.clone();
                    call_then(start_cpp_type(cp.clone(), i.clone()), move |cpp_type_10728: Text| prism_rtl::Turn::Finished(Text::from(format!("std::vector<{}>", &cpp_type_10728))))
                };
            }
            if let lower::OutTy::OutNamed(m10328_15_0, m10328_15_1) = t && (m10328_15_0 == &Text::from("Result")) && (m10328_15_1.len() == 2) && let Some(a) = index(m10328_15_1, &Nat::from(0u32)) && let Some(b) = index(m10328_15_1, &Nat::from(1u32)) {
                break 'm10328 {
                    let cp = cp.clone();
                    call_then(start_cpp_type(cp.clone(), a.clone()), move |cpp_type_10789: Text| call_then(start_cpp_type(cp.clone(), b.clone()), move |cpp_type_10806: Text| prism_rtl::Turn::Finished(Text::from(format!("Expected<{}, {}>", &cpp_type_10789, &cpp_type_10806)))))
                };
            }
            if let lower::OutTy::OutNamed(n, m10328_16_1) = t && (m10328_16_1.len() == 0) {
                break 'm10328 prism_rtl::Turn::Finished(own_type_path(cp, n));
            }
            if let lower::OutTy::OutNamed(n, args) = t {
                break 'm10328 {
                    let args = args.clone();
                    let cp = cp.clone();
                    let n = n.clone();
                    call_then(start_cpp_types(cp.clone(), args.clone()), move |cpp_types_10907: Text| prism_rtl::Turn::Finished(Text::from(format!("{}<{}>", &own_type_path(&cp, &n), &cpp_types_10907))))
                };
            }
            if let lower::OutTy::OutOpt(i) = t {
                break 'm10328 {
                    let cp = cp.clone();
                    let i = (**i).clone();
                    call_then(start_cpp_type(cp.clone(), i.clone()), move |cpp_type_10958: Text| prism_rtl::Turn::Finished(Text::from(format!("std::optional<{}>", &cpp_type_10958))))
                };
            }
            if let lower::OutTy::OutRes(i) = t {
                break 'm10328 {
                    let cp = cp.clone();
                    let i = (**i).clone();
                    call_then(start_cpp_type(cp.clone(), i.clone()), move |cpp_type_11000: Text| prism_rtl::Turn::Finished(Text::from(format!("Fallible<{}>", &cpp_type_11000))))
                };
            }
            if let lower::OutTy::OutTuple(ts) = t {
                break 'm10328 {
                    let cp = cp.clone();
                    let ts = ts.clone();
                    call_then(start_cpp_types(cp.clone(), ts.clone()), move |cpp_types_11047: Text| prism_rtl::Turn::Finished(Text::from(format!("std::tuple<{}>", &cpp_types_11047))))
                };
            }
            if let lower::OutTy::OutArray(e) = t {
                break 'm10328 {
                    let cp = cp.clone();
                    let e = (**e).clone();
                    call_then(start_cpp_type(cp.clone(), e.clone()), move |cpp_type_11090: Text| prism_rtl::Turn::Finished(Text::from(format!("Array<{}>", &cpp_type_11090))))
                };
            }
            if let lower::OutTy::OutMap(k, v_) = t {
                break 'm10328 {
                    let cp = cp.clone();
                    let k = (**k).clone();
                    let v_ = (**v_).clone();
                    call_then(start_cpp_type(cp.clone(), k.clone()), move |cpp_type_11130: Text| call_then(start_cpp_type(cp.clone(), v_.clone()), move |cpp_type_11147: Text| prism_rtl::Turn::Finished(Text::from(format!("Map<{}, {}>", &cpp_type_11130, &cpp_type_11147)))))
                };
            }
            if let lower::OutTy::OutFn(ps, r) = t {
                break 'm10328 {
                    let cp = cp.clone();
                    let ps = ps.clone();
                    let r = (**r).clone();
                    call_then(start_cpp_type(cp.clone(), r.clone()), move |cpp_type_11186: Text| call_then(start_param_types(cp.clone(), ps.clone()), move |param_types_11202: Text| prism_rtl::Turn::Finished(Text::from(format!("Fn<{}({})>", &cpp_type_11186, &param_types_11202)))))
                };
            }
            if let lower::OutTy::OutRef(m10328_24_0) = t && let lower::OutTy::OutFn(ps, r) = &**m10328_24_0 {
                break 'm10328 {
                    let cp = cp.clone();
                    let ps = ps.clone();
                    let r = (**r).clone();
                    call_then(start_cpp_type(cp.clone(), r.clone()), move |cpp_type_11272: Text| call_then(start_param_types(cp.clone(), ps.clone()), move |param_types_11288: Text| prism_rtl::Turn::Finished(Text::from(format!("const std::function<{}({})>&", &cpp_type_11272, &param_types_11288)))))
                };
            }
            if let lower::OutTy::OutRef(m10328_25_0) = t && let lower::OutTy::OutSlice(i) = &**m10328_25_0 {
                break 'm10328 {
                    let cp = cp.clone();
                    let i = (**i).clone();
                    call_then(start_cpp_type(cp.clone(), i.clone()), move |cpp_type_11354: Text| prism_rtl::Turn::Finished(Text::from(format!("std::span<const {}>", &cpp_type_11354))))
                };
            }
            if let lower::OutTy::OutRef(i) = t {
                break 'm10328 {
                    let cp = cp.clone();
                    let i = (**i).clone();
                    call_then(start_cpp_type(cp.clone(), i.clone()), move |cpp_type_11393: Text| prism_rtl::Turn::Finished(Text::from(format!("const {}&", &cpp_type_11393))))
                };
            }
            if let lower::OutTy::OutJobFn(a, b) = t {
                break 'm10328 {
                    let a = (**a).clone();
                    let b = (**b).clone();
                    let cp = cp.clone();
                    call_then(start_cpp_type(cp.clone(), b.clone()), move |cpp_type_11463: Text| call_then(start_cpp_type(cp.clone(), a.clone()), move |cpp_type_11480: Text| prism_rtl::Turn::Finished(Text::from(format!("prism_rtl::Fn<prism_rtl::JobRef<{}>({})>", &cpp_type_11463, &cpp_type_11480)))))
                };
            }
            if let lower::OutTy::OutJob(b) = t {
                break 'm10328 {
                    let b = (**b).clone();
                    let cp = cp.clone();
                    call_then(start_cpp_type(cp.clone(), b.clone()), move |cpp_type_11532: Text| prism_rtl::Turn::Finished(Text::from(format!("prism_rtl::JobRef<{}>", &cpp_type_11532))))
                };
            }
            if let lower::OutTy::OutEvent(i) = t {
                break 'm10328 {
                    let cp = cp.clone();
                    let i = (**i).clone();
                    call_then(start_cpp_type(cp.clone(), i.clone()), move |cpp_type_11573: Text| prism_rtl::Turn::Finished(Text::from(format!("Event<{}>", &cpp_type_11573))))
                };
            }
            if let lower::OutTy::OutDyn(i) = t {
                break 'm10328 {
                    let cp = cp.clone();
                    let i = (**i).clone();
                    call_then(start_cpp_type(cp.clone(), i.clone()), move |cpp_type_11614: Text| prism_rtl::Turn::Finished(Text::from(format!("Dynamic<{}>", &cpp_type_11614))))
                };
            }
            if let lower::OutTy::OutGen(n) = t {
                break 'm10328 prism_rtl::Turn::Finished(n.clone());
            }
            if let lower::OutTy::OutRc(i) = t {
                break 'm10328 if is_value_ty(cp, &**i) {
                    prism_rtl::Turn::More(Rc::new(CppType { cp: cp.clone(), t: (**i).clone() }))
                } else {
                    {
                        let cp = cp.clone();
                        let i = (**i).clone();
                        call_then(start_cpp_type(cp.clone(), i.clone()), move |cpp_type_11718: Text| prism_rtl::Turn::Finished(Text::from(format!("std::shared_ptr<{}>", &cpp_type_11718))))
                    }
                };
            }
            if let lower::OutTy::OutPod = t {
                break 'm10328 prism_rtl::Turn::Finished(Text::from("Pod"));
            }
            if let lower::OutTy::OutShowAny = t {
                break 'm10328 prism_rtl::Turn::Finished(Text::from("std::shared_ptr<const DynShow>"));
            }
            if let lower::OutTy::OutHold(i) = t {
                break 'm10328 {
                    let cp = cp.clone();
                    let i = (**i).clone();
                    call_then(start_cpp_type(cp.clone(), i.clone()), move |cpp_type_11824: Text| prism_rtl::Turn::Finished(Text::from(format!("Hold<{}>", &cpp_type_11824))))
                };
            }
            if let lower::OutTy::OutStamped(i) = t {
                break 'm10328 {
                    let cp = cp.clone();
                    let i = (**i).clone();
                    call_then(start_cpp_type(cp.clone(), i.clone()), move |cpp_type_11869: Text| prism_rtl::Turn::Finished(Text::from(format!("Stamped<{}>", &cpp_type_11869))))
                };
            }
            if let lower::OutTy::OutSnapshot(i) = t {
                break 'm10328 {
                    let cp = cp.clone();
                    let i = (**i).clone();
                    call_then(start_cpp_type(cp.clone(), i.clone()), move |cpp_type_11916: Text| prism_rtl::Turn::Finished(Text::from(format!("Snapshot<{}>", &cpp_type_11916))))
                };
            }
            if let lower::OutTy::OutDefer(i) = t {
                break 'm10328 {
                    let cp = cp.clone();
                    let i = (**i).clone();
                    call_then(start_cpp_type(cp.clone(), i.clone()), move |cpp_type_11957: Text| prism_rtl::Turn::Finished(Text::from(format!("Defer<{}>", &cpp_type_11957))))
                };
            }
            if let lower::OutTy::OutWeak(n) = t {
                break 'm10328 prism_rtl::Turn::Finished(Text::from(format!("std::weak_ptr<{}>", &type_path(n))));
            }
            if let lower::OutTy::OutCell(i) = t {
                break 'm10328 prism_rtl::Turn::More(Rc::new(CppType { cp: cp.clone(), t: (**i).clone() }));
            }
            if let lower::OutTy::OutWakes = t {
                break 'm10328 prism_rtl::Turn::Finished(Text::from("Wakes"));
            }
            if let lower::OutTy::OutCount = t {
                break 'm10328 prism_rtl::Turn::Finished(Text::from("std::uint32_t"));
            }
            if let lower::OutTy::OutObj(i) = t {
                break 'm10328 {
                    let cp = cp.clone();
                    let i = (**i).clone();
                    call_then(start_cpp_type(cp.clone(), i.clone()), move |cpp_type_12132: Text| prism_rtl::Turn::Finished(Text::from(format!("std::shared_ptr<{}>", &cpp_type_12132))))
                };
            }
            if let lower::OutTy::OutSlice(i) = t {
                break 'm10328 {
                    let cp = cp.clone();
                    let i = (**i).clone();
                    call_then(start_cpp_type(cp.clone(), i.clone()), move |cpp_type_12183: Text| prism_rtl::Turn::Finished(Text::from(format!("std::span<const {}>", &cpp_type_12183))))
                };
            }
            if let lower::OutTy::OutPort(i) = t {
                break 'm10328 {
                    let cp = cp.clone();
                    let i = (**i).clone();
                    call_then(start_cpp_type(cp.clone(), i.clone()), move |cpp_type_12222: Text| prism_rtl::Turn::Finished(Text::from(format!("Port<{}>", &cpp_type_12222))))
                };
            }
            if let lower::OutTy::OutLive(i) = t {
                break 'm10328 {
                    let cp = cp.clone();
                    let i = (**i).clone();
                    call_then(start_cpp_type(cp.clone(), i.clone()), move |cpp_type_12261: Text| prism_rtl::Turn::Finished(Text::from(format!("Live<{}>", &cpp_type_12261))))
                };
            }
            if let lower::OutTy::OutUnknown(m10328_47_0) = t && (m10328_47_0 == &Text::from("the job's turn")) {
                break 'm10328 prism_rtl::Turn::Finished(Text::from("decltype(this->cycle())"));
            }
            if let lower::OutTy::OutUnknown(what) = t {
                break 'm10328 prism_rtl::Turn::Finished(Text::from(format!("Unit /* {} */", what)));
            }
            if let lower::OutTy::OutQuantified(b) = t {
                break 'm10328 prism_rtl::Turn::Finished(Text::from(format!("compile_error!(\"{}a quantified type variable of `{}`: no instantiation gives it a type\")", &lower::lowering_refusal(), b)));
            }
            unreachable!("no clause matched")
        }
    }
}

/// `Start CppType, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_type(cp: Cp, t: lower::OutTy) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppType { cp, t })
}

/// ```prism
/// CppTypes: unbounded fn Cp, [OutTy] -> Text
/// ```
pub fn cpp_types(cp: &Cp, ts: &Array<lower::OutTy>) -> Text {
    lexer::join(&run_to_end(each_job(ts.clone(), {
        let cp = cp.clone();
        Rc::new(move |p0: lower::OutTy| {
            let cp = cp.clone();
            entered(once_job(move || {
                let t = p0;
                prism_rtl::Turn::More(Rc::new(CppType { cp: cp.clone(), t: t.clone() }))
            }))
        }) as Rc<dyn Fn(lower::OutTy) -> Rc<dyn prism_rtl::Job<Text>>>
    })), &Text::from(", "))
}

/// The step machine of `CppTypes`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppTypes: unbounded fn Cp, [OutTy] -> Text
/// ```
pub struct CppTypes {
    pub cp: Cp,
    pub ts: Array<lower::OutTy>,
}

impl prism_rtl::Job<Text> for CppTypes {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let ts = &self.ts;
        let cp = cp.clone();
        let ts = ts.clone();
        call_value(each_job(ts.clone(), {
            let cp = cp.clone();
            Rc::new(move |p0: lower::OutTy| {
                let cp = cp.clone();
                entered(once_job(move || {
                    let t = p0;
                    prism_rtl::Turn::More(Rc::new(CppType { cp: cp.clone(), t: t.clone() }))
                }))
            }) as Rc<dyn Fn(lower::OutTy) -> Rc<dyn prism_rtl::Job<Text>>>
        }), move |each_12579: Array<Text>| prism_rtl::Turn::Finished(lexer::join(&each_12579, &Text::from(", "))))
    }
}

/// `Start CppTypes, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_types(cp: Cp, ts: Array<lower::OutTy>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppTypes { cp, ts })
}

/// ```prism
/// ParamTypes: unbounded fn Cp, [OutTy] -> Text
/// ```
pub fn param_types(cp: &Cp, ts: &Array<lower::OutTy>) -> Text {
    lexer::join(&run_to_end(each_job(ts.clone(), {
        let cp = cp.clone();
        Rc::new(move |p0: lower::OutTy| {
            let cp = cp.clone();
            entered(once_job(move || {
                let t = p0;
                call_then(start_cpp_type(cp.clone(), t.clone()), move |cpp_type_12794: Text| prism_rtl::Turn::Finished(Text::from(format!("const {}&", &cpp_type_12794))))
            }))
        }) as Rc<dyn Fn(lower::OutTy) -> Rc<dyn prism_rtl::Job<Text>>>
    })), &Text::from(", "))
}

/// The step machine of `ParamTypes`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParamTypes: unbounded fn Cp, [OutTy] -> Text
/// ```
pub struct ParamTypes {
    pub cp: Cp,
    pub ts: Array<lower::OutTy>,
}

impl prism_rtl::Job<Text> for ParamTypes {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let ts = &self.ts;
        let cp = cp.clone();
        let ts = ts.clone();
        call_value(each_job(ts.clone(), {
            let cp = cp.clone();
            Rc::new(move |p0: lower::OutTy| {
                let cp = cp.clone();
                entered(once_job(move || {
                    let t = p0;
                    call_then(start_cpp_type(cp.clone(), t.clone()), move |cpp_type_12794: Text| prism_rtl::Turn::Finished(Text::from(format!("const {}&", &cpp_type_12794))))
                }))
            }) as Rc<dyn Fn(lower::OutTy) -> Rc<dyn prism_rtl::Job<Text>>>
        }), move |each_12772: Array<Text>| prism_rtl::Turn::Finished(lexer::join(&each_12772, &Text::from(", "))))
    }
}

/// `Start ParamTypes, x`: what the function value is when passed to `@Run`.
pub fn start_param_types(cp: Cp, ts: Array<lower::OutTy>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(ParamTypes { cp, ts })
}

/// ```prism
/// OwnTypePath: fn Cp, Text -> Text
/// ```
pub fn own_type_path(cp: &Cp, n: &Text) -> Text {
    let shadowed = !lexer::contains(n, &Text::from(":")) && in_list(&Array::from(vec![Text::from("Job"), Text::from("Node"), Text::from("Row"), Text::from("Turn"), Text::from("Program")]), n);
    match type_of(cp, n) {
        Some(_) => if shadowed { Text::from(format!("crate::{}::{}", &cp.home, n)) } else { type_path(n) },
        None => type_path(n),
    }
}

/// ```prism
/// TypePath: fn Text -> Text
/// ```
pub fn type_path(p_: &Text) -> Text {
    let no_fish = lexer::join(&split(p_, &Text::from("::<")), &Text::from("<"));
    let no_holes = lexer::join(&split(&no_fish, &Text::from(", _>")), &Text::from(">"));
    lexer::join(&split(&no_holes, &Text::from("<_>")), &Text::from(""))
}

/// ```prism
/// IsValueTy: fn Cp, OutTy -> Bool
/// ```
pub fn is_value_ty(cp: &Cp, t: &lower::OutTy) -> bool {
    match t {
        lower::OutTy::OutNamed(n, _) => match type_of(cp, n) {
            Some(info) => (&info.kind != &Text::from("node")) && (&info.kind != &Text::from("job")),
            None => false,
        },
        lower::OutTy::OutCell(_) => false,
        lower::OutTy::OutPort(_) => false,
        lower::OutTy::OutHold(_) => false,
        lower::OutTy::OutStamped(_) => false,
        lower::OutTy::OutSnapshot(_) => false,
        lower::OutTy::OutDefer(_) => false,
        lower::OutTy::OutObj(_) => false,
        lower::OutTy::OutWakes => false,
        _ => true,
    }
}

/// ```prism
/// CppLoose: fn Ex -> Bool
/// ```
pub fn cpp_loose(x: &lower::Ex) -> bool {
    match x {
        lower::Ex::XBlock(m14393_0_0, inner) if (m14393_0_0.len() == 0) => cpp_loose(&**inner),
        lower::Ex::XBin(_, _, _) => true,
        lower::Ex::XUnary(_, _) => true,
        lower::Ex::XIf(_, _, _) => true,
        lower::Ex::XRef(y) => cpp_loose(&**y),
        lower::Ex::XRefMut(y) => cpp_loose(&**y),
        lower::Ex::XDeref(y) => cpp_loose(&**y),
        lower::Ex::XClone(y) => cpp_loose(&**y),
        _ => false,
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// CppTight: unbounded fn Cp, Ex -> Text
/// ```
pub fn cpp_tight(cp: &Cp, x: &lower::Ex) -> Text {
    if cpp_loose(x) {
        Text::from(format!("({})", &cpp_expr(cp, x)))
    } else {
        cpp_expr(cp, x)
    }
}

/// The step machine of `CppTight`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppTight: unbounded fn Cp, Ex -> Text
/// ```
pub struct CppTight {
    pub cp: Cp,
    pub x: lower::Ex,
}

impl prism_rtl::Job<Text> for CppTight {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let x = &self.x;
        if cpp_loose(x) {
            {
                let cp = cp.clone();
                let x = x.clone();
                call_then(start_cpp_expr(cp.clone(), x.clone()), move |cpp_expr_14745: Text| prism_rtl::Turn::Finished(Text::from(format!("({})", &cpp_expr_14745))))
            }
        } else {
            prism_rtl::Turn::More(Rc::new(CppExpr { cp: cp.clone(), x: x.clone() }))
        }
    }
}

/// `Start CppTight, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_tight(cp: Cp, x: lower::Ex) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppTight { cp, x })
}

/// ```prism
/// CppArgs: unbounded fn Cp, [Ex] -> Text
/// ```
pub fn cpp_args(cp: &Cp, xs: &Array<lower::Ex>) -> Text {
    lexer::join(&run_to_end(each_job(xs.clone(), {
        let cp = cp.clone();
        Rc::new(move |p0: lower::Ex| {
            let cp = cp.clone();
            entered(once_job(move || {
                let x = p0;
                prism_rtl::Turn::More(Rc::new(CppExpr { cp: cp.clone(), x: x.clone() }))
            }))
        }) as Rc<dyn Fn(lower::Ex) -> Rc<dyn prism_rtl::Job<Text>>>
    })), &Text::from(", "))
}

/// The step machine of `CppArgs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppArgs: unbounded fn Cp, [Ex] -> Text
/// ```
pub struct CppArgs {
    pub cp: Cp,
    pub xs: Array<lower::Ex>,
}

impl prism_rtl::Job<Text> for CppArgs {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let xs = &self.xs;
        let cp = cp.clone();
        let xs = xs.clone();
        call_value(each_job(xs.clone(), {
            let cp = cp.clone();
            Rc::new(move |p0: lower::Ex| {
                let cp = cp.clone();
                entered(once_job(move || {
                    let x = p0;
                    prism_rtl::Turn::More(Rc::new(CppExpr { cp: cp.clone(), x: x.clone() }))
                }))
            }) as Rc<dyn Fn(lower::Ex) -> Rc<dyn prism_rtl::Job<Text>>>
        }), move |each_14848: Array<Text>| prism_rtl::Turn::Finished(lexer::join(&each_14848, &Text::from(", "))))
    }
}

/// `Start CppArgs, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_args(cp: Cp, xs: Array<lower::Ex>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppArgs { cp, xs })
}

/// ```prism
/// CppExpr: unbounded fn Cp, Ex -> Text
/// ```
pub fn cpp_expr(cp: &Cp, x: &lower::Ex) -> Text {
    match x {
        lower::Ex::XVar(n) => var_name(cp, n),
        lower::Ex::XPath(p_) => path_value(cp, p_),
        lower::Ex::XSelf => Text::from("prism_rtl::share(this)"),
        lower::Ex::XCx => Text::from("cx"),
        lower::Ex::XConst(n) => n.clone(),
        lower::Ex::XUnit => Text::from("Unit{}"),
        lower::Ex::XNone => Text::from("std::nullopt"),
        lower::Ex::XBool(b) => if *b { Text::from("true") } else { Text::from("false") },
        lower::Ex::XNat(d) => Text::from(format!("Nat({}u)", d)),
        lower::Ex::XInt(d) => if &len_text(&(if lexer::has_prefix(d, &Text::from("-")) { lexer::after_first(d) } else { d.clone() })) <= &Nat::from(18u32) {
            Text::from(format!("Int({}ll)", d))
        } else {
            Text::from(format!("*Int::parse(\"{}\")", d))
        },
        lower::Ex::XByte(d) => Text::from(format!("std::uint8_t({})", d)),
        lower::Ex::XFloat(d) => d.clone(),
        lower::Ex::XIndex(n) => Text::from(format!("{}u", n)),
        lower::Ex::XChar(c) => Text::from(format!("U'{}'", &cpp_char_escape(c))),
        lower::Ex::XStr(t) => cpp_string(t),
        lower::Ex::XRef(y) => cpp_expr(cp, &**y),
        lower::Ex::XRefMut(y) => cpp_expr(cp, &**y),
        lower::Ex::XDeref(y) => cpp_expr(cp, &**y),
        lower::Ex::XTarget(y) => cpp_expr(cp, &**y),
        lower::Ex::XClone(y) => cpp_expr(cp, &**y),
        lower::Ex::XWeak(y) => Text::from(format!("prism_rtl::weaken({})", &cpp_expr(cp, &**y))),
        lower::Ex::XUpgrade(y) => Text::from(format!("prism_rtl::upgrade({})", &cpp_expr(cp, &**y))),
        lower::Ex::XBreak(l, y) => Text::from(format!("({})", &cpp_break(cp, l, &**y))),
        lower::Ex::XBreakLoop => Text::from("({ break; })"),
        lower::Ex::XLater(y) => Text::from(format!("[=](Cx& cx) -> Done {{ {}; return {{}}; }}", &cpp_expr(cp, &**y))),
        lower::Ex::XFormatStr(parts) => cpp_format(cp, parts, &Text::from("prism_rtl::str")),
        lower::Ex::XIsCase(y, m14940_26_1) if (m14940_26_1.len() == 0) => Text::from("false"),
        lower::Ex::XIsCase(y, cs) => Text::from(format!("({})", &lexer::join(&run_to_end(each_job(cs.clone(), {
            let cp = cp.clone();
            let y = (**y).clone();
            Rc::new(move |p0: Text| {
                let cp = cp.clone();
                let y = y.clone();
                entered(once_job(move || {
                    let c = p0;
                    call_then(start_cpp_tight(cp.clone(), y.clone()), move |cpp_tight_15966: Text| prism_rtl::Turn::Finished(case_test(&cp, &c, &cpp_tight_15966)))
                }))
            }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<Text>>>
        })), &Text::from(" || ")))),
        lower::Ex::XRefusal(what) => Text::from(format!("compile_error!(\"{}{}\")", &lower::lowering_refusal(), &lower::escape(what))),
        lower::Ex::XUnreachable => Text::from("throw prism_rtl::Panic(\"entered unreachable code\")"),
        lower::Ex::XCall(f, args) => cpp_call(cp, f, args),
        lower::Ex::XApply(f, args) => Text::from(format!("{}({})", &cpp_tight(cp, &**f), &cpp_args(cp, args))),
        lower::Ex::XMethod(r, m, args) => cpp_method(cp, &**r, m, args),
        lower::Ex::XBin(op, l, r) => Text::from(format!("{} {} {}", &cpp_tight(cp, &**l), op, &cpp_tight(cp, &**r))),
        lower::Ex::XUnary(op, y) => Text::from(format!("{}{}", op, &cpp_tight(cp, &**y))),
        lower::Ex::XCtor(p_, args) => cpp_ctor(cp, p_, args),
        lower::Ex::XRecord(p_, fs) => cpp_record(cp, p_, fs),
        lower::Ex::XTuple(xs) => Text::from(format!("std::tuple{{{}}}", &cpp_args(cp, xs))),
        lower::Ex::XVec(m14940_38_0) if (m14940_38_0.len() == 0) => Text::from("{}"),
        lower::Ex::XVec(xs) => Text::from(format!("std::vector{{{}}}", &cpp_args(cp, xs))),
        lower::Ex::XText(t) => Text::from(format!("Text({})", &cpp_string(t))),
        lower::Ex::XFormat(parts) => if fold(parts, &true, &(|f: &bool, p_: &lower::Ex| *f && is_text_piece(p_))) {
            Text::from(format!("Text({})", &cpp_string(&concat(&each(parts, &(|p_: &lower::Ex| text_piece(p_)))))))
        } else {
            cpp_format(cp, parts, &Text::from("prism_rtl::cat"))
        },
        lower::Ex::XMatch(s, arms, fallback, t) => cpp_match(cp, &**s, arms, t),
        lower::Ex::XChain(label, s, arms, t) => cpp_match(cp, &**s, arms, t),
        lower::Ex::XIf(c, t, e) => cpp_if(cp, &**c, &**t, &**e),
        lower::Ex::XBlock(m14940_45_0, e) if (m14940_45_0.len() == 0) => cpp_expr(cp, &**e),
        lower::Ex::XBlock(dos, e) => {
            let (st, cp2) = cpp_statements_cp(cp, dos);
            cpp_templates::stmt_expr(&st, &unvexed(&cpp_expr(&cp2, &**e)))
        },
        lower::Ex::XLabeled(label, dos, e, t) => cpp_labeled(cp, label, dos, &**e, t),
        lower::Ex::XClosure(mv, ps, body) => cpp_closure(cp, mv, ps, &**body),
        lower::Ex::XTry(y) => Text::from(format!("TRY({})", &cpp_expr(cp, &**y))),
        lower::Ex::XField(r, f) => cpp_field(cp, &**r, f),
        lower::Ex::XPart(r, k) => Text::from(format!("std::get<{}>({})", k, &cpp_expr(cp, &**r))),
        lower::Ex::XDecode(t, y) => Text::from(format!("TRY(prism_rtl::from_pod<{}>({}))", &cpp_type(cp, t), &cpp_expr(cp, &**y))),
        lower::Ex::XCast(y, t) => Text::from(format!("static_cast<{}>({})", &cpp_type(cp, t), &cpp_expr(cp, &**y))),
        lower::Ex::XTyped(y, t) => {
            let e = cpp_expr(cp, &**y);
            if (&e == &Text::from("{}")) || (&e == &Text::from("std::nullopt")) {
                Text::from(format!("{}{{}}", &cpp_type(cp, t)))
            } else {
                if is_ctor(&**y, &Text::from("Ok")) || is_ctor(&**y, &Text::from("Err")) {
                    Text::from(format!("{}({})", &cpp_type(cp, t), &e))
                } else {
                    e.clone()
                }
            }
        },
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `CppExpr`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppExpr: unbounded fn Cp, Ex -> Text
/// ```
pub struct CppExpr {
    pub cp: Cp,
    pub x: lower::Ex,
}

impl prism_rtl::Job<Text> for CppExpr {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let x = &self.x;
        match x {
            lower::Ex::XVar(n) => prism_rtl::Turn::Finished(var_name(cp, n)),
            lower::Ex::XPath(p_) => prism_rtl::Turn::Finished(path_value(cp, p_)),
            lower::Ex::XSelf => prism_rtl::Turn::Finished(Text::from("prism_rtl::share(this)")),
            lower::Ex::XCx => prism_rtl::Turn::Finished(Text::from("cx")),
            lower::Ex::XConst(n) => prism_rtl::Turn::Finished(n.clone()),
            lower::Ex::XUnit => prism_rtl::Turn::Finished(Text::from("Unit{}")),
            lower::Ex::XNone => prism_rtl::Turn::Finished(Text::from("std::nullopt")),
            lower::Ex::XBool(b) => if *b {
                prism_rtl::Turn::Finished(Text::from("true"))
            } else {
                prism_rtl::Turn::Finished(Text::from("false"))
            },
            lower::Ex::XNat(d) => prism_rtl::Turn::Finished(Text::from(format!("Nat({}u)", d))),
            lower::Ex::XInt(d) => if &len_text(&(if lexer::has_prefix(d, &Text::from("-")) { lexer::after_first(d) } else { d.clone() })) <= &Nat::from(18u32) {
                prism_rtl::Turn::Finished(Text::from(format!("Int({}ll)", d)))
            } else {
                prism_rtl::Turn::Finished(Text::from(format!("*Int::parse(\"{}\")", d)))
            },
            lower::Ex::XByte(d) => prism_rtl::Turn::Finished(Text::from(format!("std::uint8_t({})", d))),
            lower::Ex::XFloat(d) => prism_rtl::Turn::Finished(d.clone()),
            lower::Ex::XIndex(n) => prism_rtl::Turn::Finished(Text::from(format!("{}u", n))),
            lower::Ex::XChar(c) => prism_rtl::Turn::Finished(Text::from(format!("U'{}'", &cpp_char_escape(c)))),
            lower::Ex::XStr(t) => prism_rtl::Turn::Finished(cpp_string(t)),
            lower::Ex::XRef(y) => prism_rtl::Turn::More(Rc::new(CppExpr { cp: cp.clone(), x: (**y).clone() })),
            lower::Ex::XRefMut(y) => prism_rtl::Turn::More(Rc::new(CppExpr { cp: cp.clone(), x: (**y).clone() })),
            lower::Ex::XDeref(y) => prism_rtl::Turn::More(Rc::new(CppExpr { cp: cp.clone(), x: (**y).clone() })),
            lower::Ex::XTarget(y) => prism_rtl::Turn::More(Rc::new(CppExpr { cp: cp.clone(), x: (**y).clone() })),
            lower::Ex::XClone(y) => prism_rtl::Turn::More(Rc::new(CppExpr { cp: cp.clone(), x: (**y).clone() })),
            lower::Ex::XWeak(y) => {
                let cp = cp.clone();
                let y = (**y).clone();
                call_then(start_cpp_expr(cp.clone(), y.clone()), move |cpp_expr_15601: Text| prism_rtl::Turn::Finished(Text::from(format!("prism_rtl::weaken({})", &cpp_expr_15601))))
            },
            lower::Ex::XUpgrade(y) => {
                let cp = cp.clone();
                let y = (**y).clone();
                call_then(start_cpp_expr(cp.clone(), y.clone()), move |cpp_expr_15655: Text| prism_rtl::Turn::Finished(Text::from(format!("prism_rtl::upgrade({})", &cpp_expr_15655))))
            },
            lower::Ex::XBreak(l, y) => {
                let cp = cp.clone();
                let l = l.clone();
                let y = (**y).clone();
                call_then(start_cpp_break(cp.clone(), l.clone(), y.clone()), move |cpp_break_15692: Text| prism_rtl::Turn::Finished(Text::from(format!("({})", &cpp_break_15692))))
            },
            lower::Ex::XBreakLoop => prism_rtl::Turn::Finished(Text::from("({ break; })")),
            lower::Ex::XLater(y) => {
                let cp = cp.clone();
                let y = (**y).clone();
                call_then(start_cpp_expr(cp.clone(), y.clone()), move |cpp_expr_15785: Text| prism_rtl::Turn::Finished(Text::from(format!("[=](Cx& cx) -> Done {{ {}; return {{}}; }}", &cpp_expr_15785))))
            },
            lower::Ex::XFormatStr(parts) => prism_rtl::Turn::More(Rc::new(CppFormat { cp: cp.clone(), parts: parts.clone(), how: Text::from("prism_rtl::str") })),
            lower::Ex::XIsCase(y, m14940_26_1) if (m14940_26_1.len() == 0) => prism_rtl::Turn::Finished(Text::from("false")),
            lower::Ex::XIsCase(y, cs) => {
                let cp = cp.clone();
                let cs = cs.clone();
                let y = (**y).clone();
                call_value(each_job(cs.clone(), {
                    let cp = cp.clone();
                    let y = y.clone();
                    Rc::new(move |p0: Text| {
                        let cp = cp.clone();
                        let y = y.clone();
                        entered(once_job(move || {
                            let c = p0;
                            call_then(start_cpp_tight(cp.clone(), y.clone()), move |cpp_tight_15966: Text| prism_rtl::Turn::Finished(case_test(&cp, &c, &cpp_tight_15966)))
                        }))
                    }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<Text>>>
                }), move |each_15935: Array<Text>| prism_rtl::Turn::Finished(Text::from(format!("({})", &lexer::join(&each_15935, &Text::from(" || "))))))
            },
            lower::Ex::XRefusal(what) => prism_rtl::Turn::Finished(Text::from(format!("compile_error!(\"{}{}\")", &lower::lowering_refusal(), &lower::escape(what)))),
            lower::Ex::XUnreachable => prism_rtl::Turn::Finished(Text::from("throw prism_rtl::Panic(\"entered unreachable code\")")),
            lower::Ex::XCall(f, args) => prism_rtl::Turn::More(Rc::new(CppCall { cp: cp.clone(), f: f.clone(), args: args.clone() })),
            lower::Ex::XApply(f, args) => {
                let args = args.clone();
                let cp = cp.clone();
                let f = (**f).clone();
                call_then(start_cpp_tight(cp.clone(), f.clone()), move |cpp_tight_16200: Text| call_then(start_cpp_args(cp.clone(), args.clone()), move |cpp_args_16217: Text| prism_rtl::Turn::Finished(Text::from(format!("{}({})", &cpp_tight_16200, &cpp_args_16217)))))
            },
            lower::Ex::XMethod(r, m, args) => prism_rtl::Turn::More(Rc::new(CppMethod { cp: cp.clone(), r: (**r).clone(), m: m.clone(), args: args.clone() })),
            lower::Ex::XBin(op, l, r) => {
                let cp = cp.clone();
                let l = (**l).clone();
                let op = op.clone();
                let r = (**r).clone();
                call_then(start_cpp_tight(cp.clone(), l.clone()), move |cpp_tight_16307: Text| call_then(start_cpp_tight(cp.clone(), r.clone()), move |cpp_tight_16329: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {} {}", &cpp_tight_16307, &op, &cpp_tight_16329)))))
            },
            lower::Ex::XUnary(op, y) => {
                let cp = cp.clone();
                let op = op.clone();
                let y = (**y).clone();
                call_then(start_cpp_tight(cp.clone(), y.clone()), move |cpp_tight_16370: Text| prism_rtl::Turn::Finished(Text::from(format!("{}{}", &op, &cpp_tight_16370))))
            },
            lower::Ex::XCtor(p_, args) => prism_rtl::Turn::More(Rc::new(CppCtor { cp: cp.clone(), p_: p_.clone(), args: args.clone() })),
            lower::Ex::XRecord(p_, fs) => prism_rtl::Turn::More(Rc::new(CppRecord { cp: cp.clone(), p_: p_.clone(), fs: fs.clone() })),
            lower::Ex::XTuple(xs) => {
                let cp = cp.clone();
                let xs = xs.clone();
                call_then(start_cpp_args(cp.clone(), xs.clone()), move |cpp_args_16494: Text| prism_rtl::Turn::Finished(Text::from(format!("std::tuple{{{}}}", &cpp_args_16494))))
            },
            lower::Ex::XVec(m14940_38_0) if (m14940_38_0.len() == 0) => prism_rtl::Turn::Finished(Text::from("{}")),
            lower::Ex::XVec(xs) => {
                let cp = cp.clone();
                let xs = xs.clone();
                call_then(start_cpp_args(cp.clone(), xs.clone()), move |cpp_args_16563: Text| prism_rtl::Turn::Finished(Text::from(format!("std::vector{{{}}}", &cpp_args_16563))))
            },
            lower::Ex::XText(t) => prism_rtl::Turn::Finished(Text::from(format!("Text({})", &cpp_string(t)))),
            lower::Ex::XFormat(parts) => if fold(parts, &true, &(|f: &bool, p_: &lower::Ex| *f && is_text_piece(p_))) {
                prism_rtl::Turn::Finished(Text::from(format!("Text({})", &cpp_string(&concat(&each(parts, &(|p_: &lower::Ex| text_piece(p_))))))))
            } else {
                prism_rtl::Turn::More(Rc::new(CppFormat { cp: cp.clone(), parts: parts.clone(), how: Text::from("prism_rtl::cat") }))
            },
            lower::Ex::XMatch(s, arms, fallback, t) => prism_rtl::Turn::More(Rc::new(CppMatch { cp: cp.clone(), s: (**s).clone(), arms: arms.clone(), out_ty3: t.clone() })),
            lower::Ex::XChain(label, s, arms, t) => prism_rtl::Turn::More(Rc::new(CppMatch { cp: cp.clone(), s: (**s).clone(), arms: arms.clone(), out_ty3: t.clone() })),
            lower::Ex::XIf(c, t, e) => prism_rtl::Turn::More(Rc::new(CppIf { cp: cp.clone(), c: (**c).clone(), t: (**t).clone(), e: (**e).clone() })),
            lower::Ex::XBlock(m14940_45_0, e) if (m14940_45_0.len() == 0) => prism_rtl::Turn::More(Rc::new(CppExpr { cp: cp.clone(), x: (**e).clone() })),
            lower::Ex::XBlock(dos, e) => {
                let cp = cp.clone();
                let dos = dos.clone();
                let e = (**e).clone();
                call_then(start_cpp_statements_cp(cp.clone(), dos.clone()), move |cpp_statements_cp_17015: (Text, Cp)| {
                    let (st, cp2) = cpp_statements_cp_17015;
                    call_then(start_cpp_expr(cp2.clone(), e.clone()), move |cpp_expr_17070: Text| prism_rtl::Turn::Finished(cpp_templates::stmt_expr(&st, &unvexed(&cpp_expr_17070))))
                })
            },
            lower::Ex::XLabeled(label, dos, e, t) => prism_rtl::Turn::More(Rc::new(CppLabeled { cp: cp.clone(), label: label.clone(), dos: dos.clone(), e: (**e).clone(), t: t.clone() })),
            lower::Ex::XClosure(mv, ps, body) => prism_rtl::Turn::More(Rc::new(CppClosure { cp0: cp.clone(), mv: *mv, ps: ps.clone(), body: (**body).clone() })),
            lower::Ex::XTry(y) => {
                let cp = cp.clone();
                let y = (**y).clone();
                call_then(start_cpp_expr(cp.clone(), y.clone()), move |cpp_expr_17223: Text| prism_rtl::Turn::Finished(Text::from(format!("TRY({})", &cpp_expr_17223))))
            },
            lower::Ex::XField(r, f) => prism_rtl::Turn::More(Rc::new(CppField { cp: cp.clone(), ex1: (**r).clone(), f: f.clone() })),
            lower::Ex::XPart(r, k) => {
                let cp = cp.clone();
                let k = k.clone();
                let r = (**r).clone();
                call_then(start_cpp_expr(cp.clone(), r.clone()), move |cpp_expr_17307: Text| prism_rtl::Turn::Finished(Text::from(format!("std::get<{}>({})", &k, &cpp_expr_17307))))
            },
            lower::Ex::XDecode(t, y) => {
                let cp = cp.clone();
                let t = t.clone();
                let y = (**y).clone();
                call_then(start_cpp_type(cp.clone(), t.clone()), move |cpp_type_17368: Text| call_then(start_cpp_expr(cp.clone(), y.clone()), move |cpp_expr_17385: Text| prism_rtl::Turn::Finished(Text::from(format!("TRY(prism_rtl::from_pod<{}>({}))", &cpp_type_17368, &cpp_expr_17385)))))
            },
            lower::Ex::XCast(y, t) => {
                let cp = cp.clone();
                let t = t.clone();
                let y = (**y).clone();
                call_then(start_cpp_type(cp.clone(), t.clone()), move |cpp_type_17433: Text| call_then(start_cpp_expr(cp.clone(), y.clone()), move |cpp_expr_17450: Text| prism_rtl::Turn::Finished(Text::from(format!("static_cast<{}>({})", &cpp_type_17433, &cpp_expr_17450)))))
            },
            lower::Ex::XTyped(y, t) => {
                let cp = cp.clone();
                let t = t.clone();
                let y = (**y).clone();
                call_then(start_cpp_expr(cp.clone(), y.clone()), move |cpp_expr_17500: Text| {
                    let e = cpp_expr_17500;
                    if (&e == &Text::from("{}")) || (&e == &Text::from("std::nullopt")) {
                        call_then(start_cpp_type(cp.clone(), t.clone()), move |cpp_type_17563: Text| prism_rtl::Turn::Finished(Text::from(format!("{}{{}}", &cpp_type_17563))))
                    } else {
                        if is_ctor(&y, &Text::from("Ok")) || is_ctor(&y, &Text::from("Err")) {
                            call_then(start_cpp_type(cp.clone(), t.clone()), move |cpp_type_17639: Text| prism_rtl::Turn::Finished(Text::from(format!("{}({})", &cpp_type_17639, &e))))
                        } else {
                            prism_rtl::Turn::Finished(e.clone())
                        }
                    }
                })
            },
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start CppExpr, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_expr(cp: Cp, x: lower::Ex) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppExpr { cp, x })
}

/// ```prism
/// CppString: fn Text -> Text
/// ```
pub fn cpp_string(t: &Text) -> Text {
    if lexer::contains(t, &Text::from("\0")) {
        Text::from(format!("\"{}\"sv", &cpp_escape(t)))
    } else {
        Text::from(format!("\"{}\"", &cpp_escape(t)))
    }
}

/// ```prism
/// CppEscape: fn Text -> Text
/// ```
pub fn cpp_escape(t: &Text) -> Text {
    lexer::map_chars(t, &(Rc::new(move |p0: Text| once_job(move || {
        let c = p0;
        if &c == &Text::from("\0") {
            prism_rtl::Turn::Finished(Text::from("\\000"))
        } else {
            prism_rtl::Turn::Finished(lower::char_escape(&c))
        }
    })) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<Text>>>))
}

/// ```prism
/// IsTextPiece: fn Ex -> Bool
/// ```
pub fn is_text_piece(ex0: &lower::Ex) -> bool {
    match ex0 {
        lower::Ex::XText(_) => true,
        other => false,
    }
}

/// ```prism
/// TextPiece: fn Ex -> Text
/// ```
pub fn text_piece(ex0: &lower::Ex) -> Text {
    match ex0 {
        lower::Ex::XText(t) => t.clone(),
        other => Text::from(""),
    }
}

/// ```prism
/// CppFormat: unbounded fn Cp, [Ex], Text -> Text
/// ```
pub fn cpp_format(cp: &Cp, parts: &Array<lower::Ex>, how: &Text) -> Text {
    Text::from(format!("{}({})", how, &lexer::join(&run_to_end(each_job(parts.clone(), {
        let cp = cp.clone();
        Rc::new(move |p0: lower::Ex| {
            let cp = cp.clone();
            entered(once_job(move || {
                let p_ = p0;
                prism_rtl::Turn::More(Rc::new(FormatArg { cp: cp.clone(), ex1: p_.clone() }))
            }))
        }) as Rc<dyn Fn(lower::Ex) -> Rc<dyn prism_rtl::Job<Text>>>
    })), &Text::from(", "))))
}

/// The step machine of `CppFormat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppFormat: unbounded fn Cp, [Ex], Text -> Text
/// ```
pub struct CppFormat {
    pub cp: Cp,
    pub parts: Array<lower::Ex>,
    pub how: Text,
}

impl prism_rtl::Job<Text> for CppFormat {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let parts = &self.parts;
        let how = &self.how;
        let cp = cp.clone();
        let how = how.clone();
        let parts = parts.clone();
        call_value(each_job(parts.clone(), {
            let cp = cp.clone();
            Rc::new(move |p0: lower::Ex| {
                let cp = cp.clone();
                entered(once_job(move || {
                    let p_ = p0;
                    prism_rtl::Turn::More(Rc::new(FormatArg { cp: cp.clone(), ex1: p_.clone() }))
                }))
            }) as Rc<dyn Fn(lower::Ex) -> Rc<dyn prism_rtl::Job<Text>>>
        }), move |each_18431: Array<Text>| prism_rtl::Turn::Finished(Text::from(format!("{}({})", &how, &lexer::join(&each_18431, &Text::from(", "))))))
    }
}

/// `Start CppFormat, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_format(cp: Cp, parts: Array<lower::Ex>, how: Text) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppFormat { cp, parts, how })
}

/// ```prism
/// FormatArg: unbounded fn Cp, Ex -> Text
/// ```
pub fn format_arg(cp: &Cp, ex1: &lower::Ex) -> Text {
    match ex1 {
        lower::Ex::XText(t) => cpp_string(t),
        x => cpp_expr(cp, x),
    }
}

/// The step machine of `FormatArg`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FormatArg: unbounded fn Cp, Ex -> Text
/// ```
pub struct FormatArg {
    pub cp: Cp,
    pub ex1: lower::Ex,
}

impl prism_rtl::Job<Text> for FormatArg {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let ex1 = &self.ex1;
        match ex1 {
            lower::Ex::XText(t) => prism_rtl::Turn::Finished(cpp_string(t)),
            x => prism_rtl::Turn::More(Rc::new(CppExpr { cp: cp.clone(), x: x.clone() })),
        }
    }
}

/// `Start FormatArg, x`: what the function value is when passed to `@Run`.
pub fn start_format_arg(cp: Cp, ex1: lower::Ex) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(FormatArg { cp, ex1 })
}

/// ```prism
/// CppCharEscape: fn Text -> Text
/// ```
pub fn cpp_char_escape(text0: &Text) -> Text {
    match text0 {
        c0_0 if (c0_0 == &Text::from("'")) => Text::from("\\'"),
        c => lower::char_escape(c),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// PathValue: fn Cp, Text -> Text
/// ```
pub fn path_value(cp: &Cp, p_: &Text) -> Text {
    if is_node_method(cp, p_) {
        Text::from(format!("&{}::{}", &type_path(&parent_path(p_)), &node_method_name(cp, &last_segment(p_))))
    } else {
        match case_of(cp, p_) {
            Some(ty) => Text::from(format!("{}({}{{}})", &type_path(&ty), &type_path(p_))),
            None => match type_of(cp, p_) {
                Some(info) => if &info.kind == &Text::from("unit") {
                    Text::from(format!("{}{{}}", &type_path(p_)))
                } else {
                    type_path(p_)
                },
                None => type_path(p_),
            },
        }
    }
}

/// ```prism
/// IsNodeMethod: fn Cp, Text -> Bool
/// ```
pub fn is_node_method(cp: &Cp, p_: &Text) -> bool {
    let named = match get(&cp.methods, &last_segment(p_)) {
        Some(_) => true,
        None => false,
    };
    named && is_node_type(cp, &parent_path(p_))
}

/// ```prism
/// IsNodeType: fn Cp, Text -> Bool
/// ```
pub fn is_node_type(cp: &Cp, p_: &Text) -> bool {
    match type_of(cp, p_) {
        Some(info) => &info.kind == &Text::from("node"),
        None => false,
    }
}

/// ```prism
/// CppField: unbounded fn Cp, Ex, Text -> Text
/// ```
pub fn cpp_field(cp: &Cp, ex1: &lower::Ex, f: &Text) -> Text {
    match ex1 {
        lower::Ex::XSelf => Text::from(format!("this->{}", &field_id(f))),
        r => {
            let name = if is_digits(f) { Text::from(format!("a{}", f)) } else { field_id(f) };
            let through = match pointer(cp, r) {
                Some(b) => if b { Text::from("->") } else { Text::from(".") },
                None => match get(&cp.members, f) {
                    Some(_) => Text::from("->"),
                    None => Text::from("."),
                },
            };
            Text::from(format!("{}{}{}", &cpp_tight(cp, r), &through, &name))
        },
    }
}

/// The step machine of `CppField`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppField: unbounded fn Cp, Ex, Text -> Text
/// ```
pub struct CppField {
    pub cp: Cp,
    pub ex1: lower::Ex,
    pub f: Text,
}

impl prism_rtl::Job<Text> for CppField {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let ex1 = &self.ex1;
        let f = &self.f;
        match ex1 {
            lower::Ex::XSelf => prism_rtl::Turn::Finished(Text::from(format!("this->{}", &field_id(f)))),
            r => {
                let name = if is_digits(f) { Text::from(format!("a{}", f)) } else { field_id(f) };
                let through = match pointer(cp, r) {
                    Some(b) => if b { Text::from("->") } else { Text::from(".") },
                    None => match get(&cp.members, f) {
                        Some(_) => Text::from("->"),
                        None => Text::from("."),
                    },
                };
                let cp = cp.clone();
                let r = r.clone();
                call_then(start_cpp_tight(cp.clone(), r.clone()), move |cpp_tight_20030: Text| prism_rtl::Turn::Finished(Text::from(format!("{}{}{}", &cpp_tight_20030, &through, &name))))
            },
        }
    }
}

/// `Start CppField, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_field(cp: Cp, ex1: lower::Ex, f: Text) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppField { cp, ex1, f })
}

/// ```prism
/// IsDigits: fn Text -> Bool
/// ```
pub fn is_digits(t: &Text) -> bool {
    (t != &Text::from("")) && lexer::fold_chars(t, &true, &(Rc::new(move |(p0, p1): (bool, Text)| once_job(move || {
        let ok = p0;
        let c = p1;
        prism_rtl::Turn::Finished(ok && lexer::contains(&Text::from("0123456789"), &c))
    })) as Rc<dyn Fn((bool, Text)) -> Rc<dyn prism_rtl::Job<bool>>>))
}

/// ```prism
/// CppCtor: unbounded fn Cp, Text, [Ex] -> Text
/// ```
pub fn cpp_ctor(cp: &Cp, p_: &Text, args: &Array<lower::Ex>) -> Text {
    match p_ {
        m20380_0 if (m20380_0 == &Text::from("Some")) => Text::from(format!("std::optional({})", &cpp_args(cp, args))),
        m20380_1 if (m20380_1 == &Text::from("Ok")) => if args == &Array::from(vec![lower::Ex::XUnit]) {
            Text::from("prism_rtl::ok()")
        } else {
            cpp_args(cp, args)
        },
        m20380_2 if (m20380_2 == &Text::from("Err")) => Text::from(format!("unexpected({})", &cpp_args(cp, args))),
        m20380_3 if (m20380_3 == &Text::from("prism_rtl::Turn::More")) => Text::from(format!("prism_rtl::more({})", &cpp_args(cp, args))),
        m20380_4 if (m20380_4 == &Text::from("prism_rtl::Turn::Finished")) => Text::from(format!("prism_rtl::finished({})", &cpp_args(cp, args))),
        m20380_5 if (m20380_5 == &Text::from("Outcome::Fired")) => Text::from(format!("Outcome::fired({})", &cpp_args(cp, args))),
        m20380_6 if (m20380_6 == &Text::from("Outcome::Value")) => Text::from(format!("Outcome::value({})", &cpp_args(cp, args))),
        m20380_7 if (m20380_7 == &Text::from("Segment::Pos")) => Text::from(format!("Segment::pos({})", &cpp_args(cp, args))),
        m20380_8 if (m20380_8 == &Text::from("Segment::Gen")) => Text::from(format!("Segment::gen({})", &cpp_args(cp, args))),
        m20380_9 if (m20380_9 == &Text::from("Segment::Key")) => Text::from(format!("Segment::key({})", &cpp_args(cp, args))),
        _ => match case_of(cp, p_) {
            Some(ty) => Text::from(format!("{}({}{{{}}})", &type_path(&ty), &type_path(p_), &cpp_args(cp, args))),
            None => Text::from(format!("{}{{{}}}", &type_path(p_), &cpp_args(cp, args))),
        },
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `CppCtor`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppCtor: unbounded fn Cp, Text, [Ex] -> Text
/// ```
pub struct CppCtor {
    pub cp: Cp,
    pub p_: Text,
    pub args: Array<lower::Ex>,
}

impl prism_rtl::Job<Text> for CppCtor {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let p_ = &self.p_;
        let args = &self.args;
        match p_ {
            m20380_0 if (m20380_0 == &Text::from("Some")) => {
                let args = args.clone();
                let cp = cp.clone();
                call_then(start_cpp_args(cp.clone(), args.clone()), move |cpp_args_20417: Text| prism_rtl::Turn::Finished(Text::from(format!("std::optional({})", &cpp_args_20417))))
            },
            m20380_1 if (m20380_1 == &Text::from("Ok")) => if args == &Array::from(vec![lower::Ex::XUnit]) {
                prism_rtl::Turn::Finished(Text::from("prism_rtl::ok()"))
            } else {
                prism_rtl::Turn::More(Rc::new(CppArgs { cp: cp.clone(), xs: args.clone() }))
            },
            m20380_2 if (m20380_2 == &Text::from("Err")) => {
                let args = args.clone();
                let cp = cp.clone();
                call_then(start_cpp_args(cp.clone(), args.clone()), move |cpp_args_20534: Text| prism_rtl::Turn::Finished(Text::from(format!("unexpected({})", &cpp_args_20534))))
            },
            m20380_3 if (m20380_3 == &Text::from("prism_rtl::Turn::More")) => {
                let args = args.clone();
                let cp = cp.clone();
                call_then(start_cpp_args(cp.clone(), args.clone()), move |cpp_args_20601: Text| prism_rtl::Turn::Finished(Text::from(format!("prism_rtl::more({})", &cpp_args_20601))))
            },
            m20380_4 if (m20380_4 == &Text::from("prism_rtl::Turn::Finished")) => {
                let args = args.clone();
                let cp = cp.clone();
                call_then(start_cpp_args(cp.clone(), args.clone()), move |cpp_args_20676: Text| prism_rtl::Turn::Finished(Text::from(format!("prism_rtl::finished({})", &cpp_args_20676))))
            },
            m20380_5 if (m20380_5 == &Text::from("Outcome::Fired")) => {
                let args = args.clone();
                let cp = cp.clone();
                call_then(start_cpp_args(cp.clone(), args.clone()), move |cpp_args_20735: Text| prism_rtl::Turn::Finished(Text::from(format!("Outcome::fired({})", &cpp_args_20735))))
            },
            m20380_6 if (m20380_6 == &Text::from("Outcome::Value")) => {
                let args = args.clone();
                let cp = cp.clone();
                call_then(start_cpp_args(cp.clone(), args.clone()), move |cpp_args_20794: Text| prism_rtl::Turn::Finished(Text::from(format!("Outcome::value({})", &cpp_args_20794))))
            },
            m20380_7 if (m20380_7 == &Text::from("Segment::Pos")) => {
                let args = args.clone();
                let cp = cp.clone();
                call_then(start_cpp_args(cp.clone(), args.clone()), move |cpp_args_20849: Text| prism_rtl::Turn::Finished(Text::from(format!("Segment::pos({})", &cpp_args_20849))))
            },
            m20380_8 if (m20380_8 == &Text::from("Segment::Gen")) => {
                let args = args.clone();
                let cp = cp.clone();
                call_then(start_cpp_args(cp.clone(), args.clone()), move |cpp_args_20904: Text| prism_rtl::Turn::Finished(Text::from(format!("Segment::gen({})", &cpp_args_20904))))
            },
            m20380_9 if (m20380_9 == &Text::from("Segment::Key")) => {
                let args = args.clone();
                let cp = cp.clone();
                call_then(start_cpp_args(cp.clone(), args.clone()), move |cpp_args_20959: Text| prism_rtl::Turn::Finished(Text::from(format!("Segment::key({})", &cpp_args_20959))))
            },
            _ => match case_of(cp, p_) {
                Some(ty) => {
                    let args = args.clone();
                    let cp = cp.clone();
                    let p_ = p_.clone();
                    call_then(start_cpp_args(cp.clone(), args.clone()), move |cpp_args_21059: Text| prism_rtl::Turn::Finished(Text::from(format!("{}({}{{{}}})", &type_path(&ty), &type_path(&p_), &cpp_args_21059))))
                },
                None => {
                    let args = args.clone();
                    let cp = cp.clone();
                    let p_ = p_.clone();
                    call_then(start_cpp_args(cp.clone(), args.clone()), move |cpp_args_21110: Text| prism_rtl::Turn::Finished(Text::from(format!("{}{{{}}}", &type_path(&p_), &cpp_args_21110))))
                },
            },
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start CppCtor, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_ctor(cp: Cp, p_: Text, args: Array<lower::Ex>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppCtor { cp, p_, args })
}

/// ```prism
/// CppRecord: unbounded fn Cp, Text, [((Text, Ex))] -> Text
/// ```
pub fn cpp_record(cp: &Cp, p_: &Text, fs: &Array<(Text, lower::Ex)>) -> Text {
    let ordered = match type_of(cp, p_) {
        Some(info) => each(&info.fields, &(|f: &Text| or(&fold(fs, &None, &(|found_opt: &Option<lower::Ex>, (g, v_): &(Text, lower::Ex)| if g == f { Some(v_.clone()) } else { found_opt.clone() })), &lower::Ex::XUnit))),
        None => each(fs, &(|(_, v_): &(Text, lower::Ex)| v_.clone())),
    };
    let names = match type_of(cp, p_) {
        Some(info) => info.fields.clone(),
        None => each(fs, &(|(g, _): &(Text, lower::Ex)| g.clone())),
    };
    let kind = match type_of(cp, p_) {
        Some(info) => info.kind.clone(),
        None => Text::from(""),
    };
    if &kind == &Text::from("job") {
        Text::from(format!("{}({})", &type_path(p_), &cpp_args(cp, &ordered)))
    } else {
        Text::from(format!("{}{{{}}}", &type_path(p_), &lexer::join(&run_to_end(each_job(check_errors::range0(&len(&names)), {
            let names = names.clone();
            let cp = cp.clone();
            let ordered = ordered.clone();
            Rc::new(move |p0: Nat| {
                let names = names.clone();
                let cp = cp.clone();
                let ordered = ordered.clone();
                entered(once_job(move || {
                    let i = p0;
                    call_then(start_cpp_expr(cp.clone(), or(&index(&ordered, &i), &lower::Ex::XUnit)), move |cpp_expr_21849: Text| prism_rtl::Turn::Finished(Text::from(format!(".{} = {}", &field_id(&or(&index(&names, &i), &Text::from(""))), &cpp_expr_21849))))
                }))
            }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Text>>>
        })), &Text::from(", "))))
    }
}

/// The step machine of `CppRecord`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppRecord: unbounded fn Cp, Text, [((Text, Ex))] -> Text
/// ```
pub struct CppRecord {
    pub cp: Cp,
    pub p_: Text,
    pub fs: Array<(Text, lower::Ex)>,
}

impl prism_rtl::Job<Text> for CppRecord {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let p_ = &self.p_;
        let fs = &self.fs;
        let ordered = match type_of(cp, p_) {
            Some(info) => each(&info.fields, &(|f: &Text| or(&fold(fs, &None, &(|found_opt: &Option<lower::Ex>, (g, v_): &(Text, lower::Ex)| if g == f { Some(v_.clone()) } else { found_opt.clone() })), &lower::Ex::XUnit))),
            None => each(fs, &(|(_, v_): &(Text, lower::Ex)| v_.clone())),
        };
        let names = match type_of(cp, p_) {
            Some(info) => info.fields.clone(),
            None => each(fs, &(|(g, _): &(Text, lower::Ex)| g.clone())),
        };
        let kind = match type_of(cp, p_) {
            Some(info) => info.kind.clone(),
            None => Text::from(""),
        };
        if &kind == &Text::from("job") {
            {
                let cp = cp.clone();
                let p_ = p_.clone();
                call_then(start_cpp_args(cp.clone(), ordered.clone()), move |cpp_args_21729: Text| prism_rtl::Turn::Finished(Text::from(format!("{}({})", &type_path(&p_), &cpp_args_21729))))
            }
        } else {
            {
                let cp = cp.clone();
                let p_ = p_.clone();
                call_value(each_job(check_errors::range0(&len(&names)), {
                    let names = names.clone();
                    let cp = cp.clone();
                    let ordered = ordered.clone();
                    Rc::new(move |p0: Nat| {
                        let names = names.clone();
                        let cp = cp.clone();
                        let ordered = ordered.clone();
                        entered(once_job(move || {
                            let i = p0;
                            call_then(start_cpp_expr(cp.clone(), or(&index(&ordered, &i), &lower::Ex::XUnit)), move |cpp_expr_21849: Text| prism_rtl::Turn::Finished(Text::from(format!(".{} = {}", &field_id(&or(&index(&names, &i), &Text::from(""))), &cpp_expr_21849))))
                        }))
                    }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Text>>>
                }), move |each_21784: Array<Text>| prism_rtl::Turn::Finished(Text::from(format!("{}{{{}}}", &type_path(&p_), &lexer::join(&each_21784, &Text::from(", "))))))
            }
        }
    }
}

/// `Start CppRecord, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_record(cp: Cp, p_: Text, fs: Array<(Text, lower::Ex)>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppRecord { cp, p_, fs })
}

/// ```prism
/// CppCall: unbounded fn Cp, Text, [Ex] -> Text
/// ```
pub fn cpp_call(cp: &Cp, f: &Text, args: &Array<lower::Ex>) -> Text {
    let a = cpp_args(cp, args);
    match f {
        m22134_0 if (m22134_0 == &Text::from("Rc::new")) => if &a == &Text::from("{}") {
            Text::from("prism_rtl::make_new()")
        } else {
            Text::from(format!("prism_rtl::rc({})", &a))
        },
        m22134_1 if (m22134_1 == &Text::from("is_some")) => Text::from(format!("prism_rtl::is_some({})", &a)),
        m22134_2 if (m22134_2 == &Text::from("is_none")) => Text::from(format!("prism_rtl::is_none({})", &a)),
        m22134_3 if (m22134_3 == &Text::from("RefCell::new")) => a.clone(),
        m22134_4 if (m22134_4 == &Text::from("Cell::new")) => a.clone(),
        m22134_5 if (m22134_5 == &Text::from("Hold::new")) => Text::from(format!("{{{}}}", &a)),
        m22134_6 if (m22134_6 == &Text::from("Snapshot::new")) => Text::from(format!("snapshot({})", &a)),
        m22134_7 if (m22134_7 == &Text::from("Path::root")) => Text::from("Path::root()"),
        m22134_8 if (m22134_8 == &Text::from("Fault::answer")) => Text::from(format!("Fault::answer({})", &a)),
        m22134_9 if (m22134_9 == &Text::from("Error::new")) => Text::from(format!("Error({})", &a)),
        m22134_10 if (m22134_10 == &Text::from("Text::from")) => Text::from(format!("Text({})", &a)),
        m22134_11 if (m22134_11 == &Text::from("String::new")) => Text::from("std::string()"),
        m22134_12 if (m22134_12 == &Text::from("Array::from")) => Text::from(format!("Array({})", &a)),
        m22134_13 if (m22134_13 == &Text::from("prism_rtl::Dynamic::of")) => Text::from(format!("dynamic_of({})", &a)),
        m22134_14 if (m22134_14 == &Text::from("Dynamic::of")) => Text::from(format!("dynamic_of({})", &a)),
        m22134_15 if (m22134_15 == &Text::from("prism_rtl::Event::of")) => Text::from(format!("event_of({})", &a)),
        m22134_16 if (m22134_16 == &Text::from("prism_rtl::Host::new")) => Text::from(format!("host_new({})", &a)),
        m22134_17 if (m22134_17 == &Text::from("prism_rtl::forward_on_none")) => Text::from(format!("prism_rtl::forward_on_none<crate::Elem, crate::Answer>({})", &a)),
        m22134_18 if (m22134_18 == &Text::from("Event::never")) => Text::from("never_event()"),
        _ => if is_fresh(f) {
            Text::from("{}")
        } else {
            Text::from(format!("{}({})", &free_call_path(cp, f), &a))
        },
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `CppCall`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppCall: unbounded fn Cp, Text, [Ex] -> Text
/// ```
pub struct CppCall {
    pub cp: Cp,
    pub f: Text,
    pub args: Array<lower::Ex>,
}

impl prism_rtl::Job<Text> for CppCall {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let f = &self.f;
        let args = &self.args;
        let args = args.clone();
        let cp = cp.clone();
        let f = f.clone();
        call_then(start_cpp_args(cp.clone(), args.clone()), move |cpp_args_22113: Text| {
            let a = cpp_args_22113;
            match &f {
                m22134_0 if (m22134_0 == &Text::from("Rc::new")) => if &a == &Text::from("{}") {
                    prism_rtl::Turn::Finished(Text::from("prism_rtl::make_new()"))
                } else {
                    prism_rtl::Turn::Finished(Text::from(format!("prism_rtl::rc({})", &a)))
                },
                m22134_1 if (m22134_1 == &Text::from("is_some")) => prism_rtl::Turn::Finished(Text::from(format!("prism_rtl::is_some({})", &a))),
                m22134_2 if (m22134_2 == &Text::from("is_none")) => prism_rtl::Turn::Finished(Text::from(format!("prism_rtl::is_none({})", &a))),
                m22134_3 if (m22134_3 == &Text::from("RefCell::new")) => prism_rtl::Turn::Finished(a.clone()),
                m22134_4 if (m22134_4 == &Text::from("Cell::new")) => prism_rtl::Turn::Finished(a.clone()),
                m22134_5 if (m22134_5 == &Text::from("Hold::new")) => prism_rtl::Turn::Finished(Text::from(format!("{{{}}}", &a))),
                m22134_6 if (m22134_6 == &Text::from("Snapshot::new")) => prism_rtl::Turn::Finished(Text::from(format!("snapshot({})", &a))),
                m22134_7 if (m22134_7 == &Text::from("Path::root")) => prism_rtl::Turn::Finished(Text::from("Path::root()")),
                m22134_8 if (m22134_8 == &Text::from("Fault::answer")) => prism_rtl::Turn::Finished(Text::from(format!("Fault::answer({})", &a))),
                m22134_9 if (m22134_9 == &Text::from("Error::new")) => prism_rtl::Turn::Finished(Text::from(format!("Error({})", &a))),
                m22134_10 if (m22134_10 == &Text::from("Text::from")) => prism_rtl::Turn::Finished(Text::from(format!("Text({})", &a))),
                m22134_11 if (m22134_11 == &Text::from("String::new")) => prism_rtl::Turn::Finished(Text::from("std::string()")),
                m22134_12 if (m22134_12 == &Text::from("Array::from")) => prism_rtl::Turn::Finished(Text::from(format!("Array({})", &a))),
                m22134_13 if (m22134_13 == &Text::from("prism_rtl::Dynamic::of")) => prism_rtl::Turn::Finished(Text::from(format!("dynamic_of({})", &a))),
                m22134_14 if (m22134_14 == &Text::from("Dynamic::of")) => prism_rtl::Turn::Finished(Text::from(format!("dynamic_of({})", &a))),
                m22134_15 if (m22134_15 == &Text::from("prism_rtl::Event::of")) => prism_rtl::Turn::Finished(Text::from(format!("event_of({})", &a))),
                m22134_16 if (m22134_16 == &Text::from("prism_rtl::Host::new")) => prism_rtl::Turn::Finished(Text::from(format!("host_new({})", &a))),
                m22134_17 if (m22134_17 == &Text::from("prism_rtl::forward_on_none")) => prism_rtl::Turn::Finished(Text::from(format!("prism_rtl::forward_on_none<crate::Elem, crate::Answer>({})", &a))),
                m22134_18 if (m22134_18 == &Text::from("Event::never")) => prism_rtl::Turn::Finished(Text::from("never_event()")),
                _ => if is_fresh(&f) {
                    prism_rtl::Turn::Finished(Text::from("{}"))
                } else {
                    prism_rtl::Turn::Finished(Text::from(format!("{}({})", &free_call_path(&cp, &f), &a)))
                },
                _ => unreachable!("no arm matched"),
            }
        })
    }
}

/// `Start CppCall, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_call(cp: Cp, f: Text, args: Array<lower::Ex>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppCall { cp, f, args })
}

/// ```prism
/// FreeCallPath: fn Cp, Text -> Text
/// ```
pub fn free_call_path(cp: &Cp, f: &Text) -> Text {
    let p_ = call_path(f);
    let hidden = match get(&cp.members, f) {
        Some(_) => true,
        None => in_list(&std_names(), &p_) || in_list(&cp.mods, &p_),
    };
    if lexer::contains(&p_, &Text::from(":")) {
        p_.clone()
    } else {
        if hidden { qualified_call(cp, f, &p_) } else { p_.clone() }
    }
}

/// ```prism
/// QualifiedCall: fn Cp, Text, Text -> Text
/// ```
pub fn qualified_call(cp: &Cp, f: &Text, p_: &Text) -> Text {
    match get(&cp.fns, &Text::from(format!("{}::{}", &cp.home, f))) {
        Some(_) => Text::from(format!("{}::{}", &cp.home, p_)),
        None => Text::from(format!("prelude::{}", p_)),
    }
}

/// ```prism
/// let stdNames
/// ```
pub fn std_names() -> Array<Text> {
    Array::from(vec![Text::from("apply"), Text::from("begin"), Text::from("end"), Text::from("size"), Text::from("empty"), Text::from("data"), Text::from("get"), Text::from("swap"), Text::from("move"), Text::from("forward"), Text::from("find"), Text::from("count"), Text::from("copy"), Text::from("fill"), Text::from("sort"), Text::from("min"), Text::from("max"), Text::from("visit"), Text::from("invoke"), Text::from("merge"), Text::from("remove"), Text::from("replace"), Text::from("reverse"), Text::from("unique"), Text::from("transform"), Text::from("accumulate"), Text::from("distance"), Text::from("next"), Text::from("prev"), Text::from("exchange"), Text::from("tie"), Text::from("to_string"), Text::from("clamp"), Text::from("partition"), Text::from("equal"), Text::from("mismatch"), Text::from("erase"), Text::from("search"), Text::from("rotate")])
}

/// ```prism
/// IsFresh: fn Text -> Bool
/// ```
pub fn is_fresh(f: &Text) -> bool {
    in_list(&Array::from(vec![Text::from("Stamped::new"), Text::from("Port::new"), Text::from("Map::new"), Text::from("Array::new"), Text::from("Vec::new"), Text::from("Default::default"), Text::from("Wakes::default"), Text::from("Defer::new")]), f)
}

/// ```prism
/// CallPath: fn Text -> Text
/// ```
pub fn call_path(f: &Text) -> Text {
    let last = last_segment(f);
    let owner = last_segment(&parent_path(f));
    let is_type = (&parent_path(f) != &Text::from("")) && lexer::contains(&Text::from("ABCDEFGHIJKLMNOPQRSTUVWXYZ"), &lexer::head(&owner));
    if (&last == &Text::from("build")) && is_type {
        Text::from(format!("{}::make", &type_path(&parent_path(f))))
    } else {
        if &last == &Text::from("new") {
            type_path(&parent_path(f))
        } else {
            cpp_path_id(&type_path(f))
        }
    }
}

/// ```prism
/// CppMethod: unbounded fn Cp, Ex, Text, [Ex] -> Text
/// ```
pub fn cpp_method(cp: &Cp, r: &lower::Ex, m: &Text, args: &Array<lower::Ex>) -> Text {
    let recv = if r == &lower::Ex::XSelf { Text::from("this") } else { cpp_tight(cp, r) };
    let a = cpp_args(cp, args);
    let n = len(args);
    let sep = if &n == &Nat::from(0u32) { Text::from("") } else { Text::from(", ") };
    match method_form(m, &n) {
        m25259_0 if (&m25259_0 == &Text::from("id")) => recv.clone(),
        m25259_1 if (&m25259_1 == &Text::from("deref")) => match pointer(cp, r) {
            Some(b) => if b { Text::from(format!("(*{})", &recv)) } else { recv.clone() },
            None => recv.clone(),
        },
        m25259_2 if (&m25259_2 == &Text::from("assign")) => Text::from(format!("{} = {}", &recv, &a)),
        m25259_3 if (&m25259_3 == &Text::from("take")) => Text::from(format!("std::exchange({}, {{}})", &recv)),
        m25259_4 if (&m25259_4 == &Text::from("free")) => Text::from(format!("{}({}{}{})", &free_name(m), &recv, &sep, &a)),
        m25259_5 if (&m25259_5 == &Text::from("arrow")) => {
            let through = match pointer(cp, r) {
                Some(b) => if b { Text::from("->") } else { Text::from(".") },
                None => Text::from("->"),
            };
            Text::from(format!("{}{}{}({})", &recv, &through, &member_name(m), &a))
        },
        m25259_6 if (&m25259_6 == &Text::from("exchange")) => Text::from(format!("std::exchange({}, {})", &recv, &a)),
        _ => {
            let through = match pointer(cp, r) {
                Some(b) => if b { Text::from("->") } else { Text::from(".") },
                None => match get(&cp.members, m) {
                    Some(_) => Text::from("->"),
                    None => Text::from("."),
                },
            };
            Text::from(format!("{}{}{}({})", &recv, &through, &node_method_name(cp, m), &a))
        },
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `CppMethod`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppMethod: unbounded fn Cp, Ex, Text, [Ex] -> Text
/// ```
pub struct CppMethod {
    pub cp: Cp,
    pub r: lower::Ex,
    pub m: Text,
    pub args: Array<lower::Ex>,
}

impl prism_rtl::Job<Text> for CppMethod {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let r = &self.r;
        let m = &self.m;
        let args = &self.args;
        let recv = if r == &lower::Ex::XSelf { Text::from("this") } else { cpp_tight(cp, r) };
        let args = args.clone();
        let cp = cp.clone();
        let m = m.clone();
        let r = r.clone();
        call_then(start_cpp_args(cp.clone(), args.clone()), move |cpp_args_25178: Text| {
            let a = cpp_args_25178;
            let n = len(&args);
            let sep = if &n == &Nat::from(0u32) { Text::from("") } else { Text::from(", ") };
            match method_form(&m, &n) {
                m25259_0 if (&m25259_0 == &Text::from("id")) => prism_rtl::Turn::Finished(recv.clone()),
                m25259_1 if (&m25259_1 == &Text::from("deref")) => match pointer(&cp, &r) {
                    Some(b) => if b {
                        prism_rtl::Turn::Finished(Text::from(format!("(*{})", &recv)))
                    } else {
                        prism_rtl::Turn::Finished(recv.clone())
                    },
                    None => prism_rtl::Turn::Finished(recv.clone()),
                },
                m25259_2 if (&m25259_2 == &Text::from("assign")) => prism_rtl::Turn::Finished(Text::from(format!("{} = {}", &recv, &a))),
                m25259_3 if (&m25259_3 == &Text::from("take")) => prism_rtl::Turn::Finished(Text::from(format!("std::exchange({}, {{}})", &recv))),
                m25259_4 if (&m25259_4 == &Text::from("free")) => prism_rtl::Turn::Finished(Text::from(format!("{}({}{}{})", &free_name(&m), &recv, &sep, &a))),
                m25259_5 if (&m25259_5 == &Text::from("arrow")) => {
                    let through = match pointer(&cp, &r) {
                        Some(b) => if b { Text::from("->") } else { Text::from(".") },
                        None => Text::from("->"),
                    };
                    prism_rtl::Turn::Finished(Text::from(format!("{}{}{}({})", &recv, &through, &member_name(&m), &a)))
                },
                m25259_6 if (&m25259_6 == &Text::from("exchange")) => prism_rtl::Turn::Finished(Text::from(format!("std::exchange({}, {})", &recv, &a))),
                _ => {
                    let through = match pointer(&cp, &r) {
                        Some(b) => if b { Text::from("->") } else { Text::from(".") },
                        None => match get(&cp.members, &m) {
                            Some(_) => Text::from("->"),
                            None => Text::from("."),
                        },
                    };
                    prism_rtl::Turn::Finished(Text::from(format!("{}{}{}({})", &recv, &through, &node_method_name(&cp, &m), &a)))
                },
                _ => unreachable!("no arm matched"),
            }
        })
    }
}

/// `Start CppMethod, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_method(cp: Cp, r: lower::Ex, m: Text, args: Array<lower::Ex>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppMethod { cp, r, m, args })
}

/// ```prism
/// NodeMethodName: fn Cp, Text -> Text
/// ```
pub fn node_method_name(cp: &Cp, m: &Text) -> Text {
    match (get(&cp.methods, m), get(&cp.field_names, m)) {
        (Some(_), Some(_)) => Text::from(format!("{}_", &cpp_id(m))),
        _ => member_name(m),
    }
}

/// ```prism
/// ?Pointer: fn Cp, Ex -> ?Bool
/// ```
pub fn pointer(cp: &Cp, r: &lower::Ex) -> Option<bool> {
    'm26539: {
        if let lower::Ex::XSelf = r {
            break 'm26539 Some(true);
        }
        if let lower::Ex::XCx = r {
            break 'm26539 Some(false);
        }
        if let lower::Ex::XVar(n) = r {
            break 'm26539 get(&cp.pointers, n);
        }
        if let lower::Ex::XClone(y) = r {
            break 'm26539 pointer(cp, &**y);
        }
        if let lower::Ex::XRef(y) = r {
            break 'm26539 pointer(cp, &**y);
        }
        if let lower::Ex::XField(m26539_5_0, f) = r && let lower::Ex::XSelf = &**m26539_5_0 {
            break 'm26539 match get(&cp.fields, f) {
                Some(t) => Some(is_pointer_ty(cp, &t)),
                None => None,
            };
        }
        if let lower::Ex::XField(m26539_6_0, f) = r && let lower::Ex::XVar(m26539_6_0_r_0) = &**m26539_6_0 && (m26539_6_0_r_0 == &Text::from("node")) {
            break 'm26539 match get(&cp.fields, f) {
                Some(t) => Some(is_pointer_ty(cp, &t)),
                None => None,
            };
        }
        None
    }
}

/// ```prism
/// IsPointerTy: fn Cp, OutTy -> Bool
/// ```
pub fn is_pointer_ty(cp: &Cp, t: &lower::OutTy) -> bool {
    match t {
        lower::OutTy::OutNamed(m26937_0_0, _) if (m26937_0_0 == &Text::from("prism_rtl::Rows")) => true,
        lower::OutTy::OutPort(_) => false,
        lower::OutTy::OutRc(i) => !is_value_ty(cp, &**i),
        lower::OutTy::OutObj(_) => true,
        lower::OutTy::OutJob(_) => true,
        lower::OutTy::OutShowAny => true,
        _ => false,
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// MethodForm: fn Text, Nat -> Text
/// ```
pub fn method_form(m: &Text, n: &Nat) -> Text {
    match (m.clone(), n.clone()) {
        (m27476_0_0, m27476_0_1) if (&m27476_0_0 == &Text::from("borrow")) && (&m27476_0_1 == &Nat::from(0u32)) => Text::from("deref"),
        (m27476_1_0, m27476_1_1) if (&m27476_1_0 == &Text::from("borrow_mut")) && (&m27476_1_1 == &Nat::from(0u32)) => Text::from("deref"),
        (m27476_2_0, m27476_2_1) if (&m27476_2_0 == &Text::from("clone")) && (&m27476_2_1 == &Nat::from(0u32)) => Text::from("id"),
        (m27476_3_0, m27476_3_1) if (&m27476_3_0 == &Text::from("iter")) && (&m27476_3_1 == &Nat::from(0u32)) => Text::from("id"),
        (m27476_4_0, m27476_4_1) if (&m27476_4_0 == &Text::from("collect")) && (&m27476_4_1 == &Nat::from(0u32)) => Text::from("id"),
        (m27476_5_0, m27476_5_1) if (&m27476_5_0 == &Text::from("unwrap_or_default")) && (&m27476_5_1 == &Nat::from(0u32)) => Text::from("free"),
        (m27476_6_0, m27476_6_1) if (&m27476_6_0 == &Text::from("for_each")) && (&m27476_6_1 == &Nat::from(1u32)) => Text::from("free"),
        (m27476_7_0, m27476_7_1) if (&m27476_7_0 == &Text::from("into_iter")) && (&m27476_7_1 == &Nat::from(0u32)) => Text::from("id"),
        (m27476_8_0, m27476_8_1) if (&m27476_8_0 == &Text::from("as_ref")) && (&m27476_8_1 == &Nat::from(0u32)) => Text::from("id"),
        (m27476_9_0, m27476_9_1) if (&m27476_9_0 == &Text::from("get")) && (&m27476_9_1 == &Nat::from(0u32)) => Text::from("id"),
        (m27476_10_0, m27476_10_1) if (&m27476_10_0 == &Text::from("set")) && (&m27476_10_1 == &Nat::from(1u32)) => Text::from("assign"),
        (m27476_11_0, m27476_11_1) if (&m27476_11_0 == &Text::from("take")) && (&m27476_11_1 == &Nat::from(0u32)) => Text::from("take"),
        (m27476_12_0, m27476_12_1) if (&m27476_12_0 == &Text::from("replace")) && (&m27476_12_1 == &Nat::from(1u32)) => Text::from("exchange"),
        (m27476_13_0, m27476_13_1) if (&m27476_13_0 == &Text::from("values")) && (&m27476_13_1 == &Nat::from(0u32)) => Text::from("free"),
        (m27476_14_0, m27476_14_1) if (&m27476_14_0 == &Text::from("keys")) && (&m27476_14_1 == &Nat::from(0u32)) => Text::from("free"),
        (m27476_15_0, m27476_15_1) if (&m27476_15_0 == &Text::from("enumerate")) && (&m27476_15_1 == &Nat::from(0u32)) => Text::from("free"),
        (m27476_16_0, m27476_16_1) if (&m27476_16_0 == &Text::from("fire")) && (&m27476_16_1 == &Nat::from(2u32)) => Text::from("arrow"),
        (m27476_17_0, m27476_17_1) if (&m27476_17_0 == &Text::from("subscribe")) && (&m27476_17_1 == &Nat::from(1u32)) => Text::from("arrow"),
        (m27476_18_0, m27476_18_1) if (&m27476_18_0 == &Text::from("unsubscribe")) && (&m27476_18_1 == &Nat::from(1u32)) => Text::from("arrow"),
        (m27476_19_0, m27476_19_1) if (&m27476_19_0 == &Text::from("cycle")) && (&m27476_19_1 == &Nat::from(0u32)) => Text::from("arrow"),
        (m27476_20_0, m27476_20_1) if (&m27476_20_0 == &Text::from("upgrade")) && (&m27476_20_1 == &Nat::from(0u32)) => Text::from("free"),
        (m27476_21_0, m27476_21_1) if (&m27476_21_0 == &Text::from("expect")) && (&m27476_21_1 == &Nat::from(1u32)) => Text::from("free"),
        (m27476_22_0, m27476_22_1) if (&m27476_22_0 == &Text::from("to_pod")) && (&m27476_22_1 == &Nat::from(0u32)) => Text::from("free"),
        (m27476_23_0, m27476_23_1) if (&m27476_23_0 == &Text::from("cloned")) && (&m27476_23_1 == &Nat::from(0u32)) => Text::from("free"),
        (m27476_24_0, m27476_24_1) if (&m27476_24_0 == &Text::from("ok")) && (&m27476_24_1 == &Nat::from(0u32)) => Text::from("free"),
        (m27476_25_0, m27476_25_1) if (&m27476_25_0 == &Text::from("ok_or")) && (&m27476_25_1 == &Nat::from(1u32)) => Text::from("free"),
        (m27476_26_0, m27476_26_1) if (&m27476_26_0 == &Text::from("map")) && (&m27476_26_1 == &Nat::from(1u32)) => Text::from("free"),
        (m27476_27_0, m27476_27_1) if (&m27476_27_0 == &Text::from("iter_mut")) && (&m27476_27_1 == &Nat::from(0u32)) => Text::from("free"),
        (m27476_28_0, m27476_28_1) if (&m27476_28_0 == &Text::from("to_vec")) && (&m27476_28_1 == &Nat::from(0u32)) => Text::from("free"),
        (m27476_29_0, m27476_29_1) if (&m27476_29_0 == &Text::from("filter_some")) && (&m27476_29_1 == &Nat::from(0u32)) => Text::from("free"),
        _ => Text::from("dot"),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// FreeName: fn Text -> Text
/// ```
pub fn free_name(m: &Text) -> Text {
    match m {
        m28413_0 if (m28413_0 == &Text::from("to_pod")) => Text::from("prism_rtl::to_pod"),
        m28413_1 if (m28413_1 == &Text::from("ok")) => Text::from("prism_rtl::ignore"),
        m28413_2 if (m28413_2 == &Text::from("map")) => Text::from("prism_rtl::fmap"),
        m28413_3 if (m28413_3 == &Text::from("to_vec")) => Text::from("path_of"),
        m28413_4 if (m28413_4 == &Text::from("values")) => Text::from("prelude::values"),
        m28413_5 if (m28413_5 == &Text::from("keys")) => Text::from("prelude::keys"),
        m28413_6 if (m28413_6 == &Text::from("enumerate")) => Text::from("prism_rtl::enumerate"),
        m28413_7 if (m28413_7 == &Text::from("unwrap_or_default")) => Text::from("prism_rtl::unwrap_or_default"),
        m28413_8 if (m28413_8 == &Text::from("for_each")) => Text::from("prism_rtl::for_each"),
        _ => m.clone(),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// MemberName: fn Text -> Text
/// ```
pub fn member_name(m: &Text) -> Text {
    match m {
        m28797_0 if (m28797_0 == &Text::from("push_str")) => Text::from("append"),
        m28797_1 if (m28797_1 == &Text::from("len")) => Text::from("size"),
        m28797_2 if (m28797_2 == &Text::from("is_empty")) => Text::from("empty"),
        m28797_3 if (m28797_3 == &Text::from("push")) => Text::from("push_back"),
        m28797_4 if (m28797_4 == &Text::from("contains_key")) => Text::from("contains"),
        m28797_5 if (m28797_5 == &Text::from("build")) => Text::from("make"),
        _ => cpp_id(m),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// CaseTest: fn Cp, Text, Text -> Text
/// ```
pub fn case_test(cp: &Cp, c: &Text, v_: &Text) -> Text {
    match c {
        m29096_0 if (m29096_0 == &Text::from("Some")) => Text::from(format!("prism_rtl::is_some({})", v_)),
        m29096_1 if (m29096_1 == &Text::from("None")) => Text::from(format!("prism_rtl::is_none({})", v_)),
        m29096_2 if (m29096_2 == &Text::from("Ok")) => Text::from(format!("prism_rtl::is_ok({})", v_)),
        m29096_3 if (m29096_3 == &Text::from("Err")) => Text::from(format!("prism_rtl::is_err({})", v_)),
        m29096_4 if (m29096_4 == &Text::from("prism_rtl::Turn::More")) => Text::from(format!("{}.if_more()", v_)),
        m29096_5 if (m29096_5 == &Text::from("prism_rtl::Turn::Finished")) => Text::from(format!("{}.if_finished()", v_)),
        _ => match case_of(cp, c) {
            Some(_) => Text::from(format!("prism_rtl::is<{}>({})", &case_type(c), v_)),
            None => if is_runtime_case(c) {
                Text::from(format!("prism_rtl::is<{}>({})", &case_type(c), v_))
            } else {
                Text::from("true")
            },
        },
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// CaseType: fn Text -> Text
/// ```
pub fn case_type(c: &Text) -> Text {
    match c {
        m29648_0 if (m29648_0 == &Text::from("Segment::Pos")) => Text::from("pat::Pos"),
        m29648_1 if (m29648_1 == &Text::from("Segment::Gen")) => Text::from("pat::Gen"),
        m29648_2 if (m29648_2 == &Text::from("Segment::Key")) => Text::from("pat::Key"),
        _ => type_path(c),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// Payload: fn Cp, Text, Text, Nat -> Text
/// ```
pub fn payload(cp: &Cp, c: &Text, v_: &Text, i: &Nat) -> Text {
    match c {
        m29897_0 if (m29897_0 == &Text::from("Some")) => Text::from(format!("prism_rtl::some_of({})", v_)),
        m29897_1 if (m29897_1 == &Text::from("Ok")) => Text::from(format!("*{}", v_)),
        m29897_2 if (m29897_2 == &Text::from("Err")) => Text::from(format!("{}.error()", v_)),
        m29897_3 if (m29897_3 == &Text::from("prism_rtl::Turn::More")) => Text::from(format!("{}.if_more()->next", v_)),
        m29897_4 if (m29897_4 == &Text::from("prism_rtl::Turn::Finished")) => Text::from(format!("{}.if_finished()->value", v_)),
        _ => match case_of(cp, c) {
            Some(_) => Text::from(format!("prism_rtl::as<{}>({}).a{}", &case_type(c), v_, i)),
            None => if is_runtime_case(c) {
                Text::from(format!("prism_rtl::as<{}>({}).a{}", &case_type(c), v_, i))
            } else {
                Text::from(format!("{}.a{}", v_, i))
            },
        },
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// IsRuntimeCase: fn Text -> Bool
/// ```
pub fn is_runtime_case(c: &Text) -> bool {
    lexer::has_prefix(c, &Text::from("Segment::"))
}

/// ```prism
/// CppIf: unbounded fn Cp, Ex, Ex, Ex -> Text
/// ```
pub fn cpp_if(cp: &Cp, c: &lower::Ex, t: &lower::Ex, e: &lower::Ex) -> Text {
    let ct = cpp_expr(cp, c);
    let err_opt = match (err_of(t), err_of(e)) {
        (Some(y), _) => Some(y.clone()),
        (None, Some(y)) => Some(y.clone()),
        _ => None,
    };
    let tt = match &err_opt {
        Some(y) => ok_branch(cp, t, y),
        None => cpp_expr(cp, t),
    };
    let et = match &err_opt {
        Some(y) => ok_branch(cp, e, y),
        None => cpp_expr(cp, e),
    };
    let short = !lexer::contains(&Text::from(format!("{}{}", &tt, &et)), &Text::from("\n")) && (&len_text(&Text::from(format!("{}{}{}", &ct, &tt, &et))) < &Nat::from(70u32));
    if short {
        Text::from(format!("{} ? {} : {}", &ct, &tt, &et))
    } else {
        cpp_templates::cond_expr(&ct, &tt, &et)
    }
}

/// The step machine of `CppIf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppIf: unbounded fn Cp, Ex, Ex, Ex -> Text
/// ```
pub struct CppIf {
    pub cp: Cp,
    pub c: lower::Ex,
    pub t: lower::Ex,
    pub e: lower::Ex,
}

impl prism_rtl::Job<Text> for CppIf {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let c = &self.c;
        let t = &self.t;
        let e = &self.e;
        let c = c.clone();
        let cp = cp.clone();
        let e = e.clone();
        let t = t.clone();
        call_then(start_cpp_expr(cp.clone(), c.clone()), move |cpp_expr_30474: Text| {
            let ct = cpp_expr_30474;
            let err_opt = match (err_of(&t), err_of(&e)) {
                (Some(y), _) => Some(y.clone()),
                (None, Some(y)) => Some(y.clone()),
                _ => None,
            };
            let tt = match &err_opt {
                Some(y) => ok_branch(&cp, &t, y),
                None => cpp_expr(&cp, &t),
            };
            let et = match &err_opt {
                Some(y) => ok_branch(&cp, &e, y),
                None => cpp_expr(&cp, &e),
            };
            let short = !lexer::contains(&Text::from(format!("{}{}", &tt, &et)), &Text::from("\n")) && (&len_text(&Text::from(format!("{}{}{}", &ct, &tt, &et))) < &Nat::from(70u32));
            if short {
                prism_rtl::Turn::Finished(Text::from(format!("{} ? {} : {}", &ct, &tt, &et)))
            } else {
                prism_rtl::Turn::Finished(cpp_templates::cond_expr(&ct, &tt, &et))
            }
        })
    }
}

/// `Start CppIf, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_if(cp: Cp, c: lower::Ex, t: lower::Ex, e: lower::Ex) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppIf { cp, c, t, e })
}

/// ```prism
/// IsCtor: fn Ex, Text -> Bool
/// ```
pub fn is_ctor(ex0: &lower::Ex, c: &Text) -> bool {
    match ex0 {
        lower::Ex::XCtor(p_, _) => p_ == c,
        x => false,
    }
}

/// ```prism
/// ?ErrOf: fn Ex -> ?Ex
/// ```
pub fn err_of(x: &lower::Ex) -> Option<lower::Ex> {
    'm31113: {
        if let lower::Ex::XCtor(m31113_0_0, m31113_0_1) = x && (m31113_0_0 == &Text::from("Err")) && (m31113_0_1.len() == 1) && let Some(y) = index(m31113_0_1, &Nat::from(0u32)) {
            break 'm31113 Some(y.clone());
        }
        if let lower::Ex::XBlock(_, tail) = x {
            break 'm31113 err_of(&**tail);
        }
        None
    }
}

/// ```prism
/// OkBranch: unbounded fn Cp, Ex, Ex -> Text
/// ```
pub fn ok_branch(cp: &Cp, x: &lower::Ex, y: &lower::Ex) -> Text {
    'm31416: {
        if let lower::Ex::XCtor(m31416_0_0, m31416_0_1) = x && (m31416_0_0 == &Text::from("Ok")) && (m31416_0_1.len() == 1) && let Some(v_) = index(m31416_0_1, &Nat::from(0u32)) {
            break 'm31416 Text::from(format!("Expected<std::decay_t<decltype({})>, std::decay_t<decltype({})>>({})", &cpp_expr(cp, &v_), &cpp_expr(cp, y), &cpp_expr(cp, &v_)));
        }
        if let lower::Ex::XBlock(dos, m31416_1_1) = x && let lower::Ex::XCtor(m31416_1_1_r_0, m31416_1_1_r_1) = &**m31416_1_1 && (m31416_1_1_r_0 == &Text::from("Ok")) && (m31416_1_1_r_1.len() == 1) && let Some(v_) = index(m31416_1_1_r_1, &Nat::from(0u32)) {
            break 'm31416 {
                let (st, cp2) = cpp_statements_cp(cp, dos);
                cpp_templates::stmt_expr(&st, &Text::from(format!("Expected<std::decay_t<decltype({})>, std::decay_t<decltype({})>>({})", &cpp_expr(&cp2, &v_), &cpp_expr(&cp2, y), &cpp_expr(&cp2, &v_))))
            };
        }
        cpp_expr(cp, x)
    }
}

/// The step machine of `OkBranch`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// OkBranch: unbounded fn Cp, Ex, Ex -> Text
/// ```
pub struct OkBranch {
    pub cp: Cp,
    pub x: lower::Ex,
    pub y: lower::Ex,
}

impl prism_rtl::Job<Text> for OkBranch {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let x = &self.x;
        let y = &self.y;
        'm31416: {
            if let lower::Ex::XCtor(m31416_0_0, m31416_0_1) = x && (m31416_0_0 == &Text::from("Ok")) && (m31416_0_1.len() == 1) && let Some(v_) = index(m31416_0_1, &Nat::from(0u32)) {
                break 'm31416 {
                    let cp = cp.clone();
                    let y = y.clone();
                    call_then(start_cpp_expr(cp.clone(), v_.clone()), move |cpp_expr_31481: Text| call_then(start_cpp_expr(cp.clone(), y.clone()), move |cpp_expr_31522: Text| call_then(start_cpp_expr(cp.clone(), v_.clone()), move |cpp_expr_31541: Text| prism_rtl::Turn::Finished(Text::from(format!("Expected<std::decay_t<decltype({})>, std::decay_t<decltype({})>>({})", &cpp_expr_31481, &cpp_expr_31522, &cpp_expr_31541))))))
                };
            }
            if let lower::Ex::XBlock(dos, m31416_1_1) = x && let lower::Ex::XCtor(m31416_1_1_r_0, m31416_1_1_r_1) = &**m31416_1_1 && (m31416_1_1_r_0 == &Text::from("Ok")) && (m31416_1_1_r_1.len() == 1) && let Some(v_) = index(m31416_1_1_r_1, &Nat::from(0u32)) {
                break 'm31416 {
                    let cp = cp.clone();
                    let dos = dos.clone();
                    let y = y.clone();
                    call_then(start_cpp_statements_cp(cp.clone(), dos.clone()), move |cpp_statements_cp_31621: (Text, Cp)| {
                        let (st, cp2) = cpp_statements_cp_31621;
                        call_then(start_cpp_expr(cp2.clone(), v_.clone()), move |cpp_expr_31699: Text| call_then(start_cpp_expr(cp2.clone(), y.clone()), move |cpp_expr_31741: Text| call_then(start_cpp_expr(cp2.clone(), v_.clone()), move |cpp_expr_31761: Text| prism_rtl::Turn::Finished(cpp_templates::stmt_expr(&st, &Text::from(format!("Expected<std::decay_t<decltype({})>, std::decay_t<decltype({})>>({})", &cpp_expr_31699, &cpp_expr_31741, &cpp_expr_31761)))))))
                    })
                };
            }
            prism_rtl::Turn::More(Rc::new(CppExpr { cp: cp.clone(), x: x.clone() }))
        }
    }
}

/// `Start OkBranch, x`: what the function value is when passed to `@Run`.
pub fn start_ok_branch(cp: Cp, x: lower::Ex, y: lower::Ex) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(OkBranch { cp, x, y })
}

/// ```prism
/// CppClosure: unbounded fn Cp, Bool, [Pa], Ex -> Text
/// ```
pub fn cpp_closure(cp0: &Cp, mv: &bool, ps: &Array<lower::Pa>, body: &lower::Ex) -> Text {
    let cp = unbind(cp0, &concat2(&run_to_end(each_job(ps.clone(), Rc::new(move |p0: lower::Pa| entered(once_job(move || {
        let p_ = p0;
        prism_rtl::Turn::More(Rc::new(PatNames { p_: p_.clone() }))
    }))) as Rc<dyn Fn(lower::Pa) -> Rc<dyn prism_rtl::Job<Array<Text>>>>))));
    let params = lexer::join(&run_to_end(each_job(check_errors::range0(&len(ps)), {
        let cp = cp.clone();
        let ps = ps.clone();
        Rc::new(move |p0: Nat| {
            let cp = cp.clone();
            let ps = ps.clone();
            entered(once_job(move || {
                let i = p0;
                prism_rtl::Turn::More(Rc::new(ClosureParam { cp: cp.clone(), pa1: or(&index(&ps, &i), &lower::Pa::PaWild), i: i.clone() }))
            }))
        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Text>>>
    })), &Text::from(", "));
    let binds = concat(&run_to_end(each_job(check_errors::range0(&len(ps)), {
        let cp = cp.clone();
        let ps = ps.clone();
        Rc::new(move |p0: Nat| {
            let cp = cp.clone();
            let ps = ps.clone();
            entered(once_job(move || {
                let i = p0;
                prism_rtl::Turn::More(Rc::new(ClosureBinds { cp: cp.clone(), pa1: or(&index(&ps, &i), &lower::Pa::PaWild), i: i.clone() }))
            }))
        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Text>>>
    })));
    let capture = if *mv { Text::from("=") } else { Text::from("&") };
    let b = cpp_expr(&cp, body);
    let (ret, value) = match body {
        lower::Ex::XRef(_) => (Text::from(" -> decltype(auto)"), Text::from(format!("({})", &b))),
        lower::Ex::XRefMut(_) => (Text::from(" -> decltype(auto)"), Text::from(format!("({})", &b))),
        _ => (Text::from(""), b.clone()),
    };
    if (&binds == &Text::from("")) && !lexer::contains(&b, &Text::from("\n")) {
        Text::from(format!("[{}]({}){} {{ return {}; }}", &capture, &params, &ret, &value))
    } else {
        cpp_templates::lambda(&capture, &Text::from(format!("{}){}", &params, &ret)), &Text::from(format!("{}return {};", &binds, &value)))
    }
}

/// The step machine of `CppClosure`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppClosure: unbounded fn Cp, Bool, [Pa], Ex -> Text
/// ```
pub struct CppClosure {
    pub cp0: Cp,
    pub mv: bool,
    pub ps: Array<lower::Pa>,
    pub body: lower::Ex,
}

impl prism_rtl::Job<Text> for CppClosure {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp0 = &self.cp0;
        let mv = &self.mv;
        let ps = &self.ps;
        let body = &self.body;
        let body = body.clone();
        let cp0 = cp0.clone();
        let mv = *mv;
        let ps = ps.clone();
        call_value(each_job(ps.clone(), Rc::new(move |p0: lower::Pa| entered(once_job(move || {
            let p_ = p0;
            prism_rtl::Turn::More(Rc::new(PatNames { p_: p_.clone() }))
        }))) as Rc<dyn Fn(lower::Pa) -> Rc<dyn prism_rtl::Job<Array<Text>>>>), move |each_31996: Array<Array<Text>>| {
            let cp = unbind(&cp0, &concat2(&each_31996));
            call_value(each_job(check_errors::range0(&len(&ps)), {
                let cp = cp.clone();
                let ps = ps.clone();
                Rc::new(move |p0: Nat| {
                    let cp = cp.clone();
                    let ps = ps.clone();
                    entered(once_job(move || {
                        let i = p0;
                        prism_rtl::Turn::More(Rc::new(ClosureParam { cp: cp.clone(), pa1: or(&index(&ps, &i), &lower::Pa::PaWild), i: i.clone() }))
                    }))
                }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Text>>>
            }), move |each_32046: Array<Text>| {
                let params = lexer::join(&each_32046, &Text::from(", "));
                call_value(each_job(check_errors::range0(&len(&ps)), {
                    let cp = cp.clone();
                    let ps = ps.clone();
                    Rc::new(move |p0: Nat| {
                        let cp = cp.clone();
                        let ps = ps.clone();
                        entered(once_job(move || {
                            let i = p0;
                            prism_rtl::Turn::More(Rc::new(ClosureBinds { cp: cp.clone(), pa1: or(&index(&ps, &i), &lower::Pa::PaWild), i: i.clone() }))
                        }))
                    }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Text>>>
                }), move |each_32145: Array<Text>| {
                    let binds = concat(&each_32145);
                    let capture = if mv { Text::from("=") } else { Text::from("&") };
                    call_then(start_cpp_expr(cp.clone(), body.clone()), move |cpp_expr_32265: Text| {
                        let b = cpp_expr_32265;
                        let (ret, value) = match &body {
                            lower::Ex::XRef(_) => (Text::from(" -> decltype(auto)"), Text::from(format!("({})", &b))),
                            lower::Ex::XRefMut(_) => (Text::from(" -> decltype(auto)"), Text::from(format!("({})", &b))),
                            _ => (Text::from(""), b.clone()),
                        };
                        if (&binds == &Text::from("")) && !lexer::contains(&b, &Text::from("\n")) {
                            prism_rtl::Turn::Finished(Text::from(format!("[{}]({}){} {{ return {}; }}", &capture, &params, &ret, &value)))
                        } else {
                            prism_rtl::Turn::Finished(cpp_templates::lambda(&capture, &Text::from(format!("{}){}", &params, &ret)), &Text::from(format!("{}return {};", &binds, &value))))
                        }
                    })
                })
            })
        })
    }
}

/// `Start CppClosure, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_closure(cp0: Cp, mv: bool, ps: Array<lower::Pa>, body: lower::Ex) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppClosure { cp0, mv, ps, body })
}

/// ```prism
/// ClosureParam: unbounded fn Cp, Pa, Nat -> Text
/// ```
pub fn closure_param(cp: &Cp, pa1: &lower::Pa, i: &Nat) -> Text {
    'c: {
        if let lower::Pa::PaTyped(c0_1_0, t) = pa1 && let lower::Pa::PaBind(n) = &**c0_1_0 {
            break 'c Text::from(format!("{} {}", &param_type(cp, t), &cpp_id(n)));
        }
        if let lower::Pa::PaTyped(c1_1_0, t) = pa1 && let lower::Pa::PaMut(n) = &**c1_1_0 {
            break 'c Text::from(format!("{} {}", &cpp_type(cp, &unref(t)), &cpp_id(n)));
        }
        if let lower::Pa::PaTyped(p_, t) = pa1 {
            break 'c Text::from(format!("{} _p{}", &param_type(cp, t), i));
        }
        if let lower::Pa::PaBind(n) = pa1 {
            break 'c Text::from(format!("auto&& {}", &cpp_id(n)));
        }
        if let lower::Pa::PaMut(n) = pa1 {
            break 'c Text::from(format!("auto {}", &cpp_id(n)));
        }
        if let lower::Pa::PaWild = pa1 {
            break 'c Text::from("const auto&");
        }
        if let p_ = pa1 {
            break 'c Text::from(format!("const auto& _p{}", i));
        }
        unreachable!("no clause matched")
    }
}

/// The step machine of `ClosureParam`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ClosureParam: unbounded fn Cp, Pa, Nat -> Text
/// ```
pub struct ClosureParam {
    pub cp: Cp,
    pub pa1: lower::Pa,
    pub i: Nat,
}

impl prism_rtl::Job<Text> for ClosureParam {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let pa1 = &self.pa1;
        let i = &self.i;
        'j: {
            if let lower::Pa::PaTyped(j0_1_0, t) = pa1 && let lower::Pa::PaBind(n) = &**j0_1_0 {
                break 'j {
                    let cp = cp.clone();
                    let n = n.clone();
                    let t = t.clone();
                    call_then(start_param_type(cp.clone(), t.clone()), move |param_type_32727: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {}", &param_type_32727, &cpp_id(&n)))))
                };
            }
            if let lower::Pa::PaTyped(j1_1_0, t) = pa1 && let lower::Pa::PaMut(n) = &**j1_1_0 {
                break 'j {
                    let cp = cp.clone();
                    let n = n.clone();
                    let t = t.clone();
                    call_then(start_cpp_type(cp.clone(), unref(&t)), move |cpp_type_32805: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {}", &cpp_type_32805, &cpp_id(&n)))))
                };
            }
            if let lower::Pa::PaTyped(p_, t) = pa1 {
                break 'j {
                    let cp = cp.clone();
                    let i = i.clone();
                    let t = t.clone();
                    call_then(start_param_type(cp.clone(), t.clone()), move |param_type_32881: Text| prism_rtl::Turn::Finished(Text::from(format!("{} _p{}", &param_type_32881, &i))))
                };
            }
            if let lower::Pa::PaBind(n) = pa1 {
                break 'j prism_rtl::Turn::Finished(Text::from(format!("auto&& {}", &cpp_id(n))));
            }
            if let lower::Pa::PaMut(n) = pa1 {
                break 'j prism_rtl::Turn::Finished(Text::from(format!("auto {}", &cpp_id(n))));
            }
            if let lower::Pa::PaWild = pa1 {
                break 'j prism_rtl::Turn::Finished(Text::from("const auto&"));
            }
            if let p_ = pa1 {
                break 'j prism_rtl::Turn::Finished(Text::from(format!("const auto& _p{}", i)));
            }
            unreachable!("no clause matched")
        }
    }
}

/// `Start ClosureParam, x`: what the function value is when passed to `@Run`.
pub fn start_closure_param(cp: Cp, pa1: lower::Pa, i: Nat) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(ClosureParam { cp, pa1, i })
}

/// ```prism
/// ClosureBinds: unbounded fn Cp, Pa, Nat -> Text
/// ```
pub fn closure_binds(cp: &Cp, pa1: &lower::Pa, i: &Nat) -> Text {
    'c: {
        if let lower::Pa::PaTyped(c0_1_0, t) = pa1 && let lower::Pa::PaBind(n) = &**c0_1_0 {
            break 'c Text::from("");
        }
        if let lower::Pa::PaTyped(c1_1_0, t) = pa1 && let lower::Pa::PaMut(n) = &**c1_1_0 {
            break 'c Text::from("");
        }
        if let lower::Pa::PaTyped(p_, t) = pa1 {
            break 'c closure_binds(cp, &**p_, i);
        }
        if let lower::Pa::PaBind(n) = pa1 {
            break 'c Text::from("");
        }
        if let lower::Pa::PaMut(n) = pa1 {
            break 'c Text::from("");
        }
        if let lower::Pa::PaWild = pa1 {
            break 'c Text::from("");
        }
        if let p_ = pa1 {
            break 'c concat(&each(&pat_binds(cp, p_, &Text::from(format!("_p{}", i))), &(|b: &Text| Text::from(format!("{}\n", b)))));
        }
        unreachable!("no clause matched")
    }
}

/// The step machine of `ClosureBinds`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ClosureBinds: unbounded fn Cp, Pa, Nat -> Text
/// ```
pub struct ClosureBinds {
    pub cp: Cp,
    pub pa1: lower::Pa,
    pub i: Nat,
}

impl prism_rtl::Job<Text> for ClosureBinds {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let pa1 = &self.pa1;
        let i = &self.i;
        'j: {
            if let lower::Pa::PaTyped(j0_1_0, t) = pa1 && let lower::Pa::PaBind(n) = &**j0_1_0 {
                break 'j prism_rtl::Turn::Finished(Text::from(""));
            }
            if let lower::Pa::PaTyped(j1_1_0, t) = pa1 && let lower::Pa::PaMut(n) = &**j1_1_0 {
                break 'j prism_rtl::Turn::Finished(Text::from(""));
            }
            if let lower::Pa::PaTyped(p_, t) = pa1 {
                break 'j prism_rtl::Turn::More(Rc::new(ClosureBinds { cp: cp.clone(), pa1: (**p_).clone(), i: i.clone() }));
            }
            if let lower::Pa::PaBind(n) = pa1 {
                break 'j prism_rtl::Turn::Finished(Text::from(""));
            }
            if let lower::Pa::PaMut(n) = pa1 {
                break 'j prism_rtl::Turn::Finished(Text::from(""));
            }
            if let lower::Pa::PaWild = pa1 {
                break 'j prism_rtl::Turn::Finished(Text::from(""));
            }
            if let p_ = pa1 {
                break 'j {
                    let cp = cp.clone();
                    let i = i.clone();
                    let p_ = p_.clone();
                    call_then(start_pat_binds(cp.clone(), p_.clone(), Text::from(format!("_p{}", &i))), move |pat_binds_33471: Array<Text>| prism_rtl::Turn::Finished(concat(&each(&pat_binds_33471, &(|b: &Text| Text::from(format!("{}\n", b)))))))
                };
            }
            unreachable!("no clause matched")
        }
    }
}

/// `Start ClosureBinds, x`: what the function value is when passed to `@Run`.
pub fn start_closure_binds(cp: Cp, pa1: lower::Pa, i: Nat) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(ClosureBinds { cp, pa1, i })
}

/// ```prism
/// Unref: fn OutTy -> OutTy
/// ```
pub fn unref(out_ty0: &lower::OutTy) -> lower::OutTy {
    match out_ty0 {
        lower::OutTy::OutRef(t) => (**t).clone(),
        t => t.clone(),
    }
}

/// ```prism
/// ParamType: unbounded fn Cp, OutTy -> Text
/// ```
pub fn param_type(cp: &Cp, t: &lower::OutTy) -> Text {
    match t {
        lower::OutTy::OutRef(_) => cpp_type(cp, t),
        lower::OutTy::OutSlice(_) => cpp_type(cp, t),
        lower::OutTy::OutUnit => Text::from("Unit"),
        _ => cpp_type(cp, t),
    }
}

/// The step machine of `ParamType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParamType: unbounded fn Cp, OutTy -> Text
/// ```
pub struct ParamType {
    pub cp: Cp,
    pub t: lower::OutTy,
}

impl prism_rtl::Job<Text> for ParamType {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let t = &self.t;
        match t {
            lower::OutTy::OutRef(_) => prism_rtl::Turn::More(Rc::new(CppType { cp: cp.clone(), t: t.clone() })),
            lower::OutTy::OutSlice(_) => prism_rtl::Turn::More(Rc::new(CppType { cp: cp.clone(), t: t.clone() })),
            lower::OutTy::OutUnit => prism_rtl::Turn::Finished(Text::from("Unit")),
            _ => prism_rtl::Turn::More(Rc::new(CppType { cp: cp.clone(), t: t.clone() })),
        }
    }
}

/// `Start ParamType, x`: what the function value is when passed to `@Run`.
pub fn start_param_type(cp: Cp, t: lower::OutTy) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(ParamType { cp, t })
}

/// ```prism
/// PatConds: unbounded fn Cp, Pa, Text -> [Text]
/// ```
pub fn pat_conds(cp: &Cp, p_: &lower::Pa, v_: &Text) -> Array<Text> {
    match p_ {
        lower::Pa::PaWild => Array::new(),
        lower::Pa::PaBind(_) => Array::new(),
        lower::Pa::PaMut(_) => Array::new(),
        lower::Pa::PaTyped(q, _) => pat_conds(cp, &**q, v_),
        lower::Pa::PaUnit(c) => Array::from(vec![case_test(cp, c, v_)]),
        lower::Pa::PaCtor(c, ps) => {
            let own = case_test(cp, c, v_);
            let inner = concat2(&run_to_end(each_job(check_errors::range0(&len(ps)), {
                let cp = cp.clone();
                let ps = ps.clone();
                let c = c.clone();
                let v_ = v_.clone();
                Rc::new(move |p0: Nat| {
                    let cp = cp.clone();
                    let ps = ps.clone();
                    let c = c.clone();
                    let v_ = v_.clone();
                    entered(once_job(move || {
                        let i = p0;
                        prism_rtl::Turn::More(Rc::new(PatConds { cp: cp.clone(), p_: or(&index(&ps, &i), &lower::Pa::PaWild), v_: payload(&cp, &c, &v_, &i) }))
                    }))
                }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
            })));
            filter(&append(&Array::from(vec![own.clone()]), &inner), &(|t: &Text| t != &Text::from("true")))
        },
        lower::Pa::PaRecord(c, fs, _) => concat2(&run_to_end(each_job(fs.clone(), {
            let cp = cp.clone();
            let v_ = v_.clone();
            Rc::new(move |p0: (Text, lower::Pa)| {
                let cp = cp.clone();
                let v_ = v_.clone();
                entered(once_job(move || {
                    let (f, q) = p0;
                    prism_rtl::Turn::More(Rc::new(PatConds { cp: cp.clone(), p_: q.clone(), v_: Text::from(format!("{}.{}", &v_, &field_id(&f))) }))
                }))
            }) as Rc<dyn Fn((Text, lower::Pa)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
        }))),
        lower::Pa::PaTuple(ps) => concat2(&run_to_end(each_job(check_errors::range0(&len(ps)), {
            let cp = cp.clone();
            let ps = ps.clone();
            let v_ = v_.clone();
            Rc::new(move |p0: Nat| {
                let cp = cp.clone();
                let ps = ps.clone();
                let v_ = v_.clone();
                entered(once_job(move || {
                    let i = p0;
                    prism_rtl::Turn::More(Rc::new(PatConds { cp: cp.clone(), p_: or(&index(&ps, &i), &lower::Pa::PaWild), v_: Text::from(format!("std::get<{}>({})", &i, &v_)) }))
                }))
            }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
        }))),
        lower::Pa::PaChar(c) => Array::from(vec![Text::from(format!("{} == U'{}'", v_, &cpp_char_escape(c)))]),
        lower::Pa::PaBool(b) => Array::from(vec![if *b { v_.clone() } else { Text::from(format!("!{}", v_)) }]),
        lower::Pa::PaIndex(n) => Array::from(vec![Text::from(format!("{} == {}u", v_, n))]),
        lower::Pa::PaConst(n) => Array::from(vec![Text::from(format!("{} == {}", v_, n))]),
        lower::Pa::PaSlice(ps) => {
            let rest = fold(ps, &false, &(|f: &bool, q: &lower::Pa| *f || is_rest(q)));
            let fixed = len(&filter(ps, &(|q: &lower::Pa| !is_rest(q))));
            let size_ = if rest {
                Text::from(format!("{}.size() >= {}", v_, &fixed))
            } else {
                Text::from(format!("{}.size() == {}", v_, &fixed))
            };
            append(&Array::from(vec![size_.clone()]), &concat2(&run_to_end(each_job(check_errors::range0(&len(ps)), {
                let cp = cp.clone();
                let ps = ps.clone();
                let v_ = v_.clone();
                Rc::new(move |p0: Nat| {
                    let cp = cp.clone();
                    let ps = ps.clone();
                    let v_ = v_.clone();
                    entered(once_job(move || {
                        let i = p0;
                        prism_rtl::Turn::More(Rc::new(PatConds { cp: cp.clone(), p_: or(&index(&ps, &i), &lower::Pa::PaWild), v_: Text::from(format!("{}[{}]", &v_, &i)) }))
                    }))
                }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
            }))))
        },
        lower::Pa::PaRest(_) => Array::new(),
    }
}

/// The step machine of `PatConds`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PatConds: unbounded fn Cp, Pa, Text -> [Text]
/// ```
pub struct PatConds {
    pub cp: Cp,
    pub p_: lower::Pa,
    pub v_: Text,
}

impl prism_rtl::Job<Array<Text>> for PatConds {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let cp = &self.cp;
        let p_ = &self.p_;
        let v_ = &self.v_;
        match p_ {
            lower::Pa::PaWild => prism_rtl::Turn::Finished(Array::new()),
            lower::Pa::PaBind(_) => prism_rtl::Turn::Finished(Array::new()),
            lower::Pa::PaMut(_) => prism_rtl::Turn::Finished(Array::new()),
            lower::Pa::PaTyped(q, _) => prism_rtl::Turn::More(Rc::new(PatConds { cp: cp.clone(), p_: (**q).clone(), v_: v_.clone() })),
            lower::Pa::PaUnit(c) => prism_rtl::Turn::Finished(Array::from(vec![case_test(cp, c, v_)])),
            lower::Pa::PaCtor(c, ps) => {
                let own = case_test(cp, c, v_);
                let c = c.clone();
                let cp = cp.clone();
                let ps = ps.clone();
                let v_ = v_.clone();
                call_value(each_job(check_errors::range0(&len(&ps)), {
                    let cp = cp.clone();
                    let ps = ps.clone();
                    let c = c.clone();
                    let v_ = v_.clone();
                    Rc::new(move |p0: Nat| {
                        let cp = cp.clone();
                        let ps = ps.clone();
                        let c = c.clone();
                        let v_ = v_.clone();
                        entered(once_job(move || {
                            let i = p0;
                            prism_rtl::Turn::More(Rc::new(PatConds { cp: cp.clone(), p_: or(&index(&ps, &i), &lower::Pa::PaWild), v_: payload(&cp, &c, &v_, &i) }))
                        }))
                    }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
                }), move |each_34466: Array<Array<Text>>| {
                    let inner = concat2(&each_34466);
                    prism_rtl::Turn::Finished(filter(&append(&Array::from(vec![own.clone()]), &inner), &(|t: &Text| t != &Text::from("true"))))
                })
            },
            lower::Pa::PaRecord(c, fs, _) => {
                let cp = cp.clone();
                let fs = fs.clone();
                let v_ = v_.clone();
                call_value(each_job(fs.clone(), {
                    let cp = cp.clone();
                    let v_ = v_.clone();
                    Rc::new(move |p0: (Text, lower::Pa)| {
                        let cp = cp.clone();
                        let v_ = v_.clone();
                        entered(once_job(move || {
                            let (f, q) = p0;
                            prism_rtl::Turn::More(Rc::new(PatConds { cp: cp.clone(), p_: q.clone(), v_: Text::from(format!("{}.{}", &v_, &field_id(&f))) }))
                        }))
                    }) as Rc<dyn Fn((Text, lower::Pa)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
                }), move |each_34645: Array<Array<Text>>| prism_rtl::Turn::Finished(concat2(&each_34645)))
            },
            lower::Pa::PaTuple(ps) => {
                let cp = cp.clone();
                let ps = ps.clone();
                let v_ = v_.clone();
                call_value(each_job(check_errors::range0(&len(&ps)), {
                    let cp = cp.clone();
                    let ps = ps.clone();
                    let v_ = v_.clone();
                    Rc::new(move |p0: Nat| {
                        let cp = cp.clone();
                        let ps = ps.clone();
                        let v_ = v_.clone();
                        entered(once_job(move || {
                            let i = p0;
                            prism_rtl::Turn::More(Rc::new(PatConds { cp: cp.clone(), p_: or(&index(&ps, &i), &lower::Pa::PaWild), v_: Text::from(format!("std::get<{}>({})", &i, &v_)) }))
                        }))
                    }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
                }), move |each_34726: Array<Array<Text>>| prism_rtl::Turn::Finished(concat2(&each_34726)))
            },
            lower::Pa::PaChar(c) => prism_rtl::Turn::Finished(Array::from(vec![Text::from(format!("{} == U'{}'", v_, &cpp_char_escape(c)))])),
            lower::Pa::PaBool(b) => prism_rtl::Turn::Finished(Array::from(vec![if *b { v_.clone() } else { Text::from(format!("!{}", v_)) }])),
            lower::Pa::PaIndex(n) => prism_rtl::Turn::Finished(Array::from(vec![Text::from(format!("{} == {}u", v_, n))])),
            lower::Pa::PaConst(n) => prism_rtl::Turn::Finished(Array::from(vec![Text::from(format!("{} == {}", v_, n))])),
            lower::Pa::PaSlice(ps) => {
                let rest = fold(ps, &false, &(|f: &bool, q: &lower::Pa| *f || is_rest(q)));
                let fixed = len(&filter(ps, &(|q: &lower::Pa| !is_rest(q))));
                let size_ = if rest {
                    Text::from(format!("{}.size() >= {}", v_, &fixed))
                } else {
                    Text::from(format!("{}.size() == {}", v_, &fixed))
                };
                let cp = cp.clone();
                let ps = ps.clone();
                let v_ = v_.clone();
                call_value(each_job(check_errors::range0(&len(&ps)), {
                    let cp = cp.clone();
                    let ps = ps.clone();
                    let v_ = v_.clone();
                    Rc::new(move |p0: Nat| {
                        let cp = cp.clone();
                        let ps = ps.clone();
                        let v_ = v_.clone();
                        entered(once_job(move || {
                            let i = p0;
                            prism_rtl::Turn::More(Rc::new(PatConds { cp: cp.clone(), p_: or(&index(&ps, &i), &lower::Pa::PaWild), v_: Text::from(format!("{}[{}]", &v_, &i)) }))
                        }))
                    }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
                }), move |each_35209: Array<Array<Text>>| prism_rtl::Turn::Finished(append(&Array::from(vec![size_.clone()]), &concat2(&each_35209))))
            },
            lower::Pa::PaRest(_) => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start PatConds, x`: what the function value is when passed to `@Run`.
pub fn start_pat_conds(cp: Cp, p_: lower::Pa, v_: Text) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(PatConds { cp, p_, v_ })
}

/// ```prism
/// PatBinds: unbounded fn Cp, Pa, Text -> [Text]
/// ```
pub fn pat_binds(cp: &Cp, p_: &lower::Pa, v_: &Text) -> Array<Text> {
    'm35378: {
        if let lower::Pa::PaWild = p_ {
            break 'm35378 Array::new();
        }
        if let lower::Pa::PaBind(n) = p_ {
            break 'm35378 Array::from(vec![Text::from(format!("auto&& {} = {};", &cpp_id(n), v_))]);
        }
        if let lower::Pa::PaMut(n) = p_ {
            break 'm35378 Array::from(vec![Text::from(format!("auto {} = {};", &cpp_id(n), v_))]);
        }
        if let lower::Pa::PaTyped(m35378_3_0, t) = p_ && let lower::Pa::PaBind(n) = &**m35378_3_0 {
            break 'm35378 Array::from(vec![Text::from(format!("{} {} = {};", &cpp_type(cp, &unref(t)), &cpp_id(n), v_))]);
        }
        if let lower::Pa::PaTyped(q, _) = p_ {
            break 'm35378 pat_binds(cp, &**q, v_);
        }
        if let lower::Pa::PaUnit(_) = p_ {
            break 'm35378 Array::new();
        }
        if let lower::Pa::PaCtor(c, ps) = p_ {
            break 'm35378 concat2(&run_to_end(each_job(check_errors::range0(&len(ps)), {
                let cp = cp.clone();
                let ps = ps.clone();
                let c = c.clone();
                let v_ = v_.clone();
                Rc::new(move |p0: Nat| {
                    let cp = cp.clone();
                    let ps = ps.clone();
                    let c = c.clone();
                    let v_ = v_.clone();
                    entered(once_job(move || {
                        let i = p0;
                        prism_rtl::Turn::More(Rc::new(PatBinds { cp: cp.clone(), p_: or(&index(&ps, &i), &lower::Pa::PaWild), v_: payload(&cp, &c, &v_, &i) }))
                    }))
                }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
            })));
        }
        if let lower::Pa::PaRecord(c, fs, _) = p_ {
            break 'm35378 concat2(&run_to_end(each_job(fs.clone(), {
                let cp = cp.clone();
                let v_ = v_.clone();
                Rc::new(move |p0: (Text, lower::Pa)| {
                    let cp = cp.clone();
                    let v_ = v_.clone();
                    entered(once_job(move || {
                        let (f, q) = p0;
                        prism_rtl::Turn::More(Rc::new(PatBinds { cp: cp.clone(), p_: q.clone(), v_: Text::from(format!("{}.{}", &v_, &field_id(&f))) }))
                    }))
                }) as Rc<dyn Fn((Text, lower::Pa)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
            })));
        }
        if let lower::Pa::PaTuple(ps) = p_ {
            break 'm35378 concat2(&run_to_end(each_job(check_errors::range0(&len(ps)), {
                let cp = cp.clone();
                let ps = ps.clone();
                let v_ = v_.clone();
                Rc::new(move |p0: Nat| {
                    let cp = cp.clone();
                    let ps = ps.clone();
                    let v_ = v_.clone();
                    entered(once_job(move || {
                        let i = p0;
                        prism_rtl::Turn::More(Rc::new(PatBinds { cp: cp.clone(), p_: or(&index(&ps, &i), &lower::Pa::PaWild), v_: Text::from(format!("std::get<{}>({})", &i, &v_)) }))
                    }))
                }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
            })));
        }
        if let lower::Pa::PaSlice(ps) = p_ {
            break 'm35378 concat2(&run_to_end(each_job(check_errors::range0(&len(ps)), {
                let cp = cp.clone();
                let ps = ps.clone();
                let v_ = v_.clone();
                Rc::new(move |p0: Nat| {
                    let cp = cp.clone();
                    let ps = ps.clone();
                    let v_ = v_.clone();
                    entered(once_job(move || {
                        let i = p0;
                        prism_rtl::Turn::More(Rc::new(SliceBinds { cp: cp.clone(), pa1: or(&index(&ps, &i), &lower::Pa::PaWild), v_: v_.clone(), i: i.clone() }))
                    }))
                }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
            })));
        }
        Array::new()
    }
}

/// The step machine of `PatBinds`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PatBinds: unbounded fn Cp, Pa, Text -> [Text]
/// ```
pub struct PatBinds {
    pub cp: Cp,
    pub p_: lower::Pa,
    pub v_: Text,
}

impl prism_rtl::Job<Array<Text>> for PatBinds {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let cp = &self.cp;
        let p_ = &self.p_;
        let v_ = &self.v_;
        'm35378: {
            if let lower::Pa::PaWild = p_ {
                break 'm35378 prism_rtl::Turn::Finished(Array::new());
            }
            if let lower::Pa::PaBind(n) = p_ {
                break 'm35378 prism_rtl::Turn::Finished(Array::from(vec![Text::from(format!("auto&& {} = {};", &cpp_id(n), v_))]));
            }
            if let lower::Pa::PaMut(n) = p_ {
                break 'm35378 prism_rtl::Turn::Finished(Array::from(vec![Text::from(format!("auto {} = {};", &cpp_id(n), v_))]));
            }
            if let lower::Pa::PaTyped(m35378_3_0, t) = p_ && let lower::Pa::PaBind(n) = &**m35378_3_0 {
                break 'm35378 {
                    let cp = cp.clone();
                    let n = n.clone();
                    let t = t.clone();
                    let v_ = v_.clone();
                    call_then(start_cpp_type(cp.clone(), unref(&t)), move |cpp_type_35520: Text| prism_rtl::Turn::Finished(Array::from(vec![Text::from(format!("{} {} = {};", &cpp_type_35520, &cpp_id(&n), &v_))])))
                };
            }
            if let lower::Pa::PaTyped(q, _) = p_ {
                break 'm35378 prism_rtl::Turn::More(Rc::new(PatBinds { cp: cp.clone(), p_: (**q).clone(), v_: v_.clone() }));
            }
            if let lower::Pa::PaUnit(_) = p_ {
                break 'm35378 prism_rtl::Turn::Finished(Array::new());
            }
            if let lower::Pa::PaCtor(c, ps) = p_ {
                break 'm35378 {
                    let c = c.clone();
                    let cp = cp.clone();
                    let ps = ps.clone();
                    let v_ = v_.clone();
                    call_value(each_job(check_errors::range0(&len(&ps)), {
                        let cp = cp.clone();
                        let ps = ps.clone();
                        let c = c.clone();
                        let v_ = v_.clone();
                        Rc::new(move |p0: Nat| {
                            let cp = cp.clone();
                            let ps = ps.clone();
                            let c = c.clone();
                            let v_ = v_.clone();
                            entered(once_job(move || {
                                let i = p0;
                                prism_rtl::Turn::More(Rc::new(PatBinds { cp: cp.clone(), p_: or(&index(&ps, &i), &lower::Pa::PaWild), v_: payload(&cp, &c, &v_, &i) }))
                            }))
                        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
                    }), move |each_35655: Array<Array<Text>>| prism_rtl::Turn::Finished(concat2(&each_35655)))
                };
            }
            if let lower::Pa::PaRecord(c, fs, _) = p_ {
                break 'm35378 {
                    let cp = cp.clone();
                    let fs = fs.clone();
                    let v_ = v_.clone();
                    call_value(each_job(fs.clone(), {
                        let cp = cp.clone();
                        let v_ = v_.clone();
                        Rc::new(move |p0: (Text, lower::Pa)| {
                            let cp = cp.clone();
                            let v_ = v_.clone();
                            entered(once_job(move || {
                                let (f, q) = p0;
                                prism_rtl::Turn::More(Rc::new(PatBinds { cp: cp.clone(), p_: q.clone(), v_: Text::from(format!("{}.{}", &v_, &field_id(&f))) }))
                            }))
                        }) as Rc<dyn Fn((Text, lower::Pa)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
                    }), move |each_35777: Array<Array<Text>>| prism_rtl::Turn::Finished(concat2(&each_35777)))
                };
            }
            if let lower::Pa::PaTuple(ps) = p_ {
                break 'm35378 {
                    let cp = cp.clone();
                    let ps = ps.clone();
                    let v_ = v_.clone();
                    call_value(each_job(check_errors::range0(&len(&ps)), {
                        let cp = cp.clone();
                        let ps = ps.clone();
                        let v_ = v_.clone();
                        Rc::new(move |p0: Nat| {
                            let cp = cp.clone();
                            let ps = ps.clone();
                            let v_ = v_.clone();
                            entered(once_job(move || {
                                let i = p0;
                                prism_rtl::Turn::More(Rc::new(PatBinds { cp: cp.clone(), p_: or(&index(&ps, &i), &lower::Pa::PaWild), v_: Text::from(format!("std::get<{}>({})", &i, &v_)) }))
                            }))
                        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
                    }), move |each_35858: Array<Array<Text>>| prism_rtl::Turn::Finished(concat2(&each_35858)))
                };
            }
            if let lower::Pa::PaSlice(ps) = p_ {
                break 'm35378 {
                    let cp = cp.clone();
                    let ps = ps.clone();
                    let v_ = v_.clone();
                    call_value(each_job(check_errors::range0(&len(&ps)), {
                        let cp = cp.clone();
                        let ps = ps.clone();
                        let v_ = v_.clone();
                        Rc::new(move |p0: Nat| {
                            let cp = cp.clone();
                            let ps = ps.clone();
                            let v_ = v_.clone();
                            entered(once_job(move || {
                                let i = p0;
                                prism_rtl::Turn::More(Rc::new(SliceBinds { cp: cp.clone(), pa1: or(&index(&ps, &i), &lower::Pa::PaWild), v_: v_.clone(), i: i.clone() }))
                            }))
                        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
                    }), move |each_35967: Array<Array<Text>>| prism_rtl::Turn::Finished(concat2(&each_35967)))
                };
            }
            prism_rtl::Turn::Finished(Array::new())
        }
    }
}

/// `Start PatBinds, x`: what the function value is when passed to `@Run`.
pub fn start_pat_binds(cp: Cp, p_: lower::Pa, v_: Text) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(PatBinds { cp, p_, v_ })
}

/// ```prism
/// SliceBinds: unbounded fn Cp, Pa, Text, Nat -> [Text]
/// ```
pub fn slice_binds(cp: &Cp, pa1: &lower::Pa, v_: &Text, i: &Nat) -> Array<Text> {
    match pa1 {
        lower::Pa::PaRest(c0_1_0) if (c0_1_0 == &Text::from("")) => Array::new(),
        lower::Pa::PaRest(n) => Array::from(vec![Text::from(format!("auto {} = {}.subspan({});", &cpp_id(n), v_, i))]),
        p_ => pat_binds(cp, p_, &Text::from(format!("{}[{}]", v_, i))),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `SliceBinds`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SliceBinds: unbounded fn Cp, Pa, Text, Nat -> [Text]
/// ```
pub struct SliceBinds {
    pub cp: Cp,
    pub pa1: lower::Pa,
    pub v_: Text,
    pub i: Nat,
}

impl prism_rtl::Job<Array<Text>> for SliceBinds {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let cp = &self.cp;
        let pa1 = &self.pa1;
        let v_ = &self.v_;
        let i = &self.i;
        match pa1 {
            lower::Pa::PaRest(j0_1_0) if (j0_1_0 == &Text::from("")) => prism_rtl::Turn::Finished(Array::new()),
            lower::Pa::PaRest(n) => prism_rtl::Turn::Finished(Array::from(vec![Text::from(format!("auto {} = {}.subspan({});", &cpp_id(n), v_, i))])),
            p_ => prism_rtl::Turn::More(Rc::new(PatBinds { cp: cp.clone(), p_: p_.clone(), v_: Text::from(format!("{}[{}]", v_, i)) })),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start SliceBinds, x`: what the function value is when passed to `@Run`.
pub fn start_slice_binds(cp: Cp, pa1: lower::Pa, v_: Text, i: Nat) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(SliceBinds { cp, pa1, v_, i })
}

/// ```prism
/// IsRest: fn Pa -> Bool
/// ```
pub fn is_rest(pa0: &lower::Pa) -> bool {
    match pa0 {
        lower::Pa::PaRest(_) => true,
        other => false,
    }
}

/// ```prism
/// Concat2: fn [ [Text] ] -> [Text]
/// ```
pub fn concat2(xss: &Array<Array<Text>>) -> Array<Text> {
    fold(xss, &Array::new(), &(|acc: &Array<Text>, xs: &Array<Text>| append(acc, xs)))
}

/// ```prism
/// Conds: fn [Text] -> Text
/// ```
pub fn conds(xs0: &Array<Text>) -> Text {
    match xs0 {
        c0_0 if (c0_0.len() == 0) => Text::from("true"),
        cs => lexer::join(cs, &Text::from(" && ")),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// IsCatchAll: fn Pa -> Bool
/// ```
pub fn is_catch_all(p_: &lower::Pa) -> bool {
    match p_ {
        lower::Pa::PaWild => true,
        lower::Pa::PaBind(_) => true,
        lower::Pa::PaMut(_) => true,
        lower::Pa::PaTyped(q, _) => is_catch_all(&**q),
        _ => false,
    }
}

/// ```prism
/// Leaves: fn Ex -> Bool
/// ```
pub fn leaves(x: &lower::Ex) -> bool {
    match x {
        lower::Ex::XBreak(_, _) => true,
        lower::Ex::XBreakLoop => true,
        lower::Ex::XUnreachable => true,
        _ => false,
    }
}

/// ```prism
/// CppMatch: unbounded fn Cp, Ex, [XArm], OutTy -> Text
/// ```
pub fn cpp_match(cp: &Cp, s: &lower::Ex, arms: &Array<lower::XArm>, out_ty3: &lower::OutTy) -> Text {
    match out_ty3 {
        lower::OutTy::OutUnknown(what) => ternary_match(cp, s, arms),
        t => {
            let bound_opt = 'm37465: {
                if let lower::Ex::XVar(n) = s {
                    break 'm37465 Some(cpp_id(n));
                }
                if let lower::Ex::XRef(m37465_1_0) = s && let lower::Ex::XVar(n) = &**m37465_1_0 {
                    break 'm37465 Some(cpp_id(n));
                }
                None
            };
            let subject = or(&bound_opt, &Text::from("_m"));
            let bind = match &bound_opt {
                Some(_) => Text::from(""),
                None => Text::from(format!("auto&& _m = {};\n", &cpp_expr(cp, s))),
            };
            let lines = run_to_end(each_job(arms.clone(), {
                let cp = cp.clone();
                let subject = subject.clone();
                Rc::new(move |p0: lower::XArm| {
                    let cp = cp.clone();
                    let subject = subject.clone();
                    entered(once_job(move || {
                        let a = p0;
                        prism_rtl::Turn::More(Rc::new(MatchArm { cp0: cp.clone(), subject: subject.clone(), a: a.clone() }))
                    }))
                }) as Rc<dyn Fn(lower::XArm) -> Rc<dyn prism_rtl::Job<Text>>>
            }));
            let ends = match lexer::last(arms) {
                Some(a) => is_catch_all(&a.pat) && (&len(&a.conds) == &Nat::from(0u32)),
                None => false,
            };
            let tail = if ends {
                Text::from("")
            } else {
                Text::from("prism_rtl::unreachable(\"no arm matched\");\n")
            };
            cpp_templates::match_expr(&cpp_type(cp, t), &Text::from(format!("{}{}\n{}", &bind, &lexer::join(&lines, &Text::from("\n")), &tail)))
        },
    }
}

/// The step machine of `CppMatch`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppMatch: unbounded fn Cp, Ex, [XArm], OutTy -> Text
/// ```
pub struct CppMatch {
    pub cp: Cp,
    pub s: lower::Ex,
    pub arms: Array<lower::XArm>,
    pub out_ty3: lower::OutTy,
}

impl prism_rtl::Job<Text> for CppMatch {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let s = &self.s;
        let arms = &self.arms;
        let out_ty3 = &self.out_ty3;
        match out_ty3 {
            lower::OutTy::OutUnknown(what) => prism_rtl::Turn::More(Rc::new(TernaryMatch { cp: cp.clone(), s: s.clone(), arms: arms.clone() })),
            t => {
                let bound_opt = 'm37465: {
                    if let lower::Ex::XVar(n) = s {
                        break 'm37465 Some(cpp_id(n));
                    }
                    if let lower::Ex::XRef(m37465_1_0) = s && let lower::Ex::XVar(n) = &**m37465_1_0 {
                        break 'm37465 Some(cpp_id(n));
                    }
                    None
                };
                let subject = or(&bound_opt, &Text::from("_m"));
                let bind = match &bound_opt {
                    Some(_) => Text::from(""),
                    None => Text::from(format!("auto&& _m = {};\n", &cpp_expr(cp, s))),
                };
                let arms = arms.clone();
                let cp = cp.clone();
                let s = s.clone();
                let t = t.clone();
                call_value(each_job(arms.clone(), {
                    let cp = cp.clone();
                    let subject = subject.clone();
                    Rc::new(move |p0: lower::XArm| {
                        let cp = cp.clone();
                        let subject = subject.clone();
                        entered(once_job(move || {
                            let a = p0;
                            prism_rtl::Turn::More(Rc::new(MatchArm { cp0: cp.clone(), subject: subject.clone(), a: a.clone() }))
                        }))
                    }) as Rc<dyn Fn(lower::XArm) -> Rc<dyn prism_rtl::Job<Text>>>
                }), move |each_37706: Array<Text>| {
                    let lines = each_37706;
                    let ends = match lexer::last(&arms) {
                        Some(a) => is_catch_all(&a.pat) && (&len(&a.conds) == &Nat::from(0u32)),
                        None => false,
                    };
                    let tail = if ends {
                        Text::from("")
                    } else {
                        Text::from("prism_rtl::unreachable(\"no arm matched\");\n")
                    };
                    call_then(start_cpp_type(cp.clone(), t.clone()), move |cpp_type_37949: Text| prism_rtl::Turn::Finished(cpp_templates::match_expr(&cpp_type_37949, &Text::from(format!("{}{}\n{}", &bind, &lexer::join(&lines, &Text::from("\n")), &tail)))))
                })
            },
        }
    }
}

/// `Start CppMatch, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_match(cp: Cp, s: lower::Ex, arms: Array<lower::XArm>, out_ty3: lower::OutTy) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppMatch { cp, s, arms, out_ty3 })
}

/// ```prism
/// TernaryMatch: unbounded fn Cp, Ex, [XArm] -> Text
/// ```
pub fn ternary_match(cp: &Cp, s: &lower::Ex, arms: &Array<lower::XArm>) -> Text {
    let bound_opt = 'm38331: {
        if let lower::Ex::XVar(n) = s {
            break 'm38331 Some(var_name(cp, n));
        }
        if let lower::Ex::XRef(m38331_1_0) = s && let lower::Ex::XVar(n) = &**m38331_1_0 {
            break 'm38331 Some(var_name(cp, n));
        }
        None
    };
    let subject = or(&bound_opt, &Text::from("_m"));
    let bind = match &bound_opt {
        Some(_) => Text::from(""),
        None => Text::from(format!("auto&& _m = {};\n", &cpp_expr(cp, s))),
    };
    let reached = run_to_end(fold_job(arms.clone(), (Array::new(), false), {
        let cp = cp.clone();
        let subject = subject.clone();
        Rc::new(move |(p0, p1): ((Array<lower::XArm>, bool), lower::XArm)| {
            let cp = cp.clone();
            let subject = subject.clone();
            entered(once_job(move || {
                let (acc, done) = p0;
                let a = p1;
                if done {
                    prism_rtl::Turn::Finished((acc.clone(), done))
                } else {
                    call_then(start_pat_conds(cp.clone(), a.pat.clone(), subject.clone()), move |pat_conds_38770: Array<Text>| prism_rtl::Turn::Finished((push(&acc, &a), (&len(&pat_conds_38770) == &Nat::from(0u32)) && (&len(&a.conds) == &Nat::from(0u32)))))
                }
            }))
        }) as Rc<dyn Fn(((Array<lower::XArm>, bool), lower::XArm)) -> Rc<dyn prism_rtl::Job<(Array<lower::XArm>, bool)>>>
    }));
    let (kept, ends) = reached.clone();
    let parts = run_to_end(each_job(kept.clone(), {
        let cp = cp.clone();
        let subject = subject.clone();
        Rc::new(move |p0: lower::XArm| {
            let cp = cp.clone();
            let subject = subject.clone();
            entered(once_job(move || {
                let a = p0;
                prism_rtl::Turn::More(Rc::new(TernaryArm { cp0: cp.clone(), subject: subject.clone(), a: a.clone() }))
            }))
        }) as Rc<dyn Fn(lower::XArm) -> Rc<dyn prism_rtl::Job<Text>>>
    }));
    let last_text = if ends {
        Text::from("")
    } else {
        Text::from("\n    : throw prism_rtl::Panic(\"no arm matched\")")
    };
    cpp_templates::stmt_expr(&Text::from(format!("{}", &bind)), &Text::from(format!("{}{}", &lexer::join(&parts, &Text::from("\n    : ")), &last_text)))
}

/// The step machine of `TernaryMatch`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TernaryMatch: unbounded fn Cp, Ex, [XArm] -> Text
/// ```
pub struct TernaryMatch {
    pub cp: Cp,
    pub s: lower::Ex,
    pub arms: Array<lower::XArm>,
}

impl prism_rtl::Job<Text> for TernaryMatch {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let s = &self.s;
        let arms = &self.arms;
        let bound_opt = 'm38331: {
            if let lower::Ex::XVar(n) = s {
                break 'm38331 Some(var_name(cp, n));
            }
            if let lower::Ex::XRef(m38331_1_0) = s && let lower::Ex::XVar(n) = &**m38331_1_0 {
                break 'm38331 Some(var_name(cp, n));
            }
            None
        };
        let subject = or(&bound_opt, &Text::from("_m"));
        let bind = match &bound_opt {
            Some(_) => Text::from(""),
            None => Text::from(format!("auto&& _m = {};\n", &cpp_expr(cp, s))),
        };
        let arms = arms.clone();
        let cp = cp.clone();
        call_value(fold_job(arms.clone(), (Array::new(), false), {
            let cp = cp.clone();
            let subject = subject.clone();
            Rc::new(move |(p0, p1): ((Array<lower::XArm>, bool), lower::XArm)| {
                let cp = cp.clone();
                let subject = subject.clone();
                entered(once_job(move || {
                    let (acc, done) = p0;
                    let a = p1;
                    if done {
                        prism_rtl::Turn::Finished((acc.clone(), done))
                    } else {
                        call_then(start_pat_conds(cp.clone(), a.pat.clone(), subject.clone()), move |pat_conds_38770: Array<Text>| prism_rtl::Turn::Finished((push(&acc, &a), (&len(&pat_conds_38770) == &Nat::from(0u32)) && (&len(&a.conds) == &Nat::from(0u32)))))
                    }
                }))
            }) as Rc<dyn Fn(((Array<lower::XArm>, bool), lower::XArm)) -> Rc<dyn prism_rtl::Job<(Array<lower::XArm>, bool)>>>
        }), move |fold_38670: (Array<lower::XArm>, bool)| {
            let reached = fold_38670;
            let (kept, ends) = reached.clone();
            call_value(each_job(kept.clone(), {
                let cp = cp.clone();
                let subject = subject.clone();
                Rc::new(move |p0: lower::XArm| {
                    let cp = cp.clone();
                    let subject = subject.clone();
                    entered(once_job(move || {
                        let a = p0;
                        prism_rtl::Turn::More(Rc::new(TernaryArm { cp0: cp.clone(), subject: subject.clone(), a: a.clone() }))
                    }))
                }) as Rc<dyn Fn(lower::XArm) -> Rc<dyn prism_rtl::Job<Text>>>
            }), move |each_38879: Array<Text>| {
                let parts = each_38879;
                let last_text = if ends {
                    Text::from("")
                } else {
                    Text::from("\n    : throw prism_rtl::Panic(\"no arm matched\")")
                };
                prism_rtl::Turn::Finished(cpp_templates::stmt_expr(&Text::from(format!("{}", &bind)), &Text::from(format!("{}{}", &lexer::join(&parts, &Text::from("\n    : ")), &last_text))))
            })
        })
    }
}

/// `Start TernaryMatch, x`: what the function value is when passed to `@Run`.
pub fn start_ternary_match(cp: Cp, s: lower::Ex, arms: Array<lower::XArm>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(TernaryMatch { cp, s, arms })
}

/// ```prism
/// TernaryArm: unbounded fn Cp, Text, XArm -> Text
/// ```
pub fn ternary_arm(cp0: &Cp, subject: &Text, a: &lower::XArm) -> Text {
    let cp = unbind(cp0, &arm_names(a));
    let tests = pat_conds(&cp, &a.pat, subject);
    let binds = pat_binds(&cp, &a.pat, subject);
    let n = len(&a.conds);
    let lets = concat2(&run_to_end(each_job(check_errors::range0(&n), {
        let cp = cp.clone();
        let a = a.clone();
        let n = n.clone();
        Rc::new(move |p0: Nat| {
            let cp = cp.clone();
            let a = a.clone();
            let n = n.clone();
            entered(once_job(move || {
                let i = p0;
                prism_rtl::Turn::More(Rc::new(CondBinds { cp: cp.clone(), cc1: or(&index(&a.conds, &i), &lower::Cc::CcIf(lower::Ex::XUnit)), k: or(&(&n).checked_sub(&i), &Nat::from(0u32)) }))
            }))
        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
    })));
    let value = if &(&len(&binds) + &len(&lets)) == &Nat::from(0u32) {
        cpp_expr(&cp, &a.body)
    } else {
        cpp_templates::stmt_expr(&lexer::join(&append(&binds, &lets), &Text::from("\n")), &cpp_expr(&cp, &a.body))
    };
    let guard = if &len(&a.conds) == &Nat::from(0u32) {
        Array::new()
    } else {
        Array::from(vec![cpp_templates::stmt_expr(&lexer::join(&binds, &Text::from("\n")), &guard_test(&cp, &a.conds))])
    };
    let all = append(&tests, &guard);
    if &len(&all) == &Nat::from(0u32) {
        value.clone()
    } else {
        Text::from(format!("{} ? {}", &conds(&all), &value))
    }
}

/// The step machine of `TernaryArm`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TernaryArm: unbounded fn Cp, Text, XArm -> Text
/// ```
pub struct TernaryArm {
    pub cp0: Cp,
    pub subject: Text,
    pub a: lower::XArm,
}

impl prism_rtl::Job<Text> for TernaryArm {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp0 = &self.cp0;
        let subject = &self.subject;
        let a = &self.a;
        let a = a.clone();
        let cp0 = cp0.clone();
        let subject = subject.clone();
        call_then(start_arm_names(a.clone()), move |arm_names_39177: Array<Text>| {
            let cp = unbind(&cp0, &arm_names_39177);
            call_then(start_pat_conds(cp.clone(), a.pat.clone(), subject.clone()), move |pat_conds_39205: Array<Text>| {
                let tests = pat_conds_39205;
                call_then(start_pat_binds(cp.clone(), a.pat.clone(), subject.clone()), move |pat_binds_39249: Array<Text>| {
                    let binds = pat_binds_39249;
                    let n = len(&a.conds);
                    call_value(each_job(check_errors::range0(&n), {
                        let cp = cp.clone();
                        let a = a.clone();
                        let n = n.clone();
                        Rc::new(move |p0: Nat| {
                            let cp = cp.clone();
                            let a = a.clone();
                            let n = n.clone();
                            entered(once_job(move || {
                                let i = p0;
                                prism_rtl::Turn::More(Rc::new(CondBinds { cp: cp.clone(), cc1: or(&index(&a.conds, &i), &lower::Cc::CcIf(lower::Ex::XUnit)), k: or(&(&n).checked_sub(&i), &Nat::from(0u32)) }))
                            }))
                        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
                    }), move |each_39325: Array<Array<Text>>| {
                        let lets = concat2(&each_39325);
                        let value = if &(&len(&binds) + &len(&lets)) == &Nat::from(0u32) {
                            cpp_expr(&cp, &a.body)
                        } else {
                            cpp_templates::stmt_expr(&lexer::join(&append(&binds, &lets), &Text::from("\n")), &cpp_expr(&cp, &a.body))
                        };
                        let guard = if &len(&a.conds) == &Nat::from(0u32) {
                            Array::new()
                        } else {
                            Array::from(vec![cpp_templates::stmt_expr(&lexer::join(&binds, &Text::from("\n")), &guard_test(&cp, &a.conds))])
                        };
                        let all = append(&tests, &guard);
                        if &len(&all) == &Nat::from(0u32) {
                            prism_rtl::Turn::Finished(value.clone())
                        } else {
                            prism_rtl::Turn::Finished(Text::from(format!("{} ? {}", &conds(&all), &value)))
                        }
                    })
                })
            })
        })
    }
}

/// `Start TernaryArm, x`: what the function value is when passed to `@Run`.
pub fn start_ternary_arm(cp0: Cp, subject: Text, a: lower::XArm) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(TernaryArm { cp0, subject, a })
}

/// ```prism
/// CondBinds: unbounded fn Cp, Cc, Nat -> [Text]
/// ```
pub fn cond_binds(cp: &Cp, cc1: &lower::Cc, k: &Nat) -> Array<Text> {
    match cc1 {
        lower::Cc::CcLet(p_, x) => {
            let (v_, pre) = cond_subject(cp, x, k);
            append(&pre, &pat_binds(cp, p_, &v_))
        },
        lower::Cc::CcIf(x) => Array::new(),
    }
}

/// The step machine of `CondBinds`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CondBinds: unbounded fn Cp, Cc, Nat -> [Text]
/// ```
pub struct CondBinds {
    pub cp: Cp,
    pub cc1: lower::Cc,
    pub k: Nat,
}

impl prism_rtl::Job<Array<Text>> for CondBinds {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let cp = &self.cp;
        let cc1 = &self.cc1;
        let k = &self.k;
        match cc1 {
            lower::Cc::CcLet(p_, x) => {
                let cp = cp.clone();
                let k = k.clone();
                let p_ = p_.clone();
                let x = x.clone();
                call_then(start_cond_subject(cp.clone(), x.clone(), k.clone()), move |cond_subject_39854: (Text, Array<Text>)| {
                    let (v_, pre) = cond_subject_39854;
                    call_then(start_pat_binds(cp.clone(), p_.clone(), v_.clone()), move |pat_binds_39892: Array<Text>| prism_rtl::Turn::Finished(append(&pre, &pat_binds_39892)))
                })
            },
            lower::Cc::CcIf(x) => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start CondBinds, x`: what the function value is when passed to `@Run`.
pub fn start_cond_binds(cp: Cp, cc1: lower::Cc, k: Nat) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(CondBinds { cp, cc1, k })
}

/// ```prism
/// CondSubject: unbounded fn Cp, Ex, Nat -> ((Text, [Text]))
/// ```
pub fn cond_subject(cp: &Cp, x: &lower::Ex, k: &Nat) -> (Text, Array<Text>) {
    if is_place_ex(x) {
        (cpp_tight(cp, x), Array::new())
    } else {
        (Text::from(format!("_c{}", k)), Array::from(vec![Text::from(format!("auto&& _c{} = {};", k, &cpp_expr(cp, x)))]))
    }
}

/// The step machine of `CondSubject`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CondSubject: unbounded fn Cp, Ex, Nat -> ((Text, [Text]))
/// ```
pub struct CondSubject {
    pub cp: Cp,
    pub x: lower::Ex,
    pub k: Nat,
}

impl prism_rtl::Job<(Text, Array<Text>)> for CondSubject {
    fn cycle(&self) -> prism_rtl::Turn<(Text, Array<Text>)> {
        let cp = &self.cp;
        let x = &self.x;
        let k = &self.k;
        if is_place_ex(x) {
            {
                let cp = cp.clone();
                let x = x.clone();
                call_then(start_cpp_tight(cp.clone(), x.clone()), move |cpp_tight_40309: Text| prism_rtl::Turn::Finished((cpp_tight_40309, Array::new())))
            }
        } else {
            {
                let cp = cp.clone();
                let k = k.clone();
                let x = x.clone();
                call_then(start_cpp_expr(cp.clone(), x.clone()), move |cpp_expr_40369: Text| prism_rtl::Turn::Finished((Text::from(format!("_c{}", &k)), Array::from(vec![Text::from(format!("auto&& _c{} = {};", &k, &cpp_expr_40369))]))))
            }
        }
    }
}

/// `Start CondSubject, x`: what the function value is when passed to `@Run`.
pub fn start_cond_subject(cp: Cp, x: lower::Ex, k: Nat) -> Rc<dyn prism_rtl::Job<(Text, Array<Text>)>> {
    Rc::new(CondSubject { cp, x, k })
}

/// ```prism
/// IsPlaceEx: fn Ex -> Bool
/// ```
pub fn is_place_ex(x: &lower::Ex) -> bool {
    match x {
        lower::Ex::XVar(_) => true,
        lower::Ex::XField(y, _) => is_place_ex(&**y),
        lower::Ex::XPart(y, _) => is_place_ex(&**y),
        lower::Ex::XTarget(_) => true,
        lower::Ex::XSelf => true,
        lower::Ex::XRef(y) => is_place_ex(&**y),
        lower::Ex::XDeref(y) => is_place_ex(&**y),
        _ => false,
    }
}

/// ```prism
/// GuardTest: unbounded fn Cp, [Cc] -> Text
/// ```
pub fn guard_test(cp: &Cp, xs1: &Array<lower::Cc>) -> Text {
    match xs1 {
        c0_1 if (c0_1.len() == 0) => Text::from("true"),
        cs => {
            let first_ = or(&index(cs, &Nat::from(0u32)), &lower::Cc::CcIf(lower::Ex::XUnit));
            let rest = guard_test(cp, &drop(cs, &Nat::from(1u32)));
            match &first_ {
                lower::Cc::CcIf(x) => if &len(cs) == &Nat::from(1u32) {
                    cpp_tight(cp, x)
                } else {
                    Text::from(format!("{} && {}", &cpp_tight(cp, x), &rest))
                },
                lower::Cc::CcLet(p_, x) => {
                    let (v_, pre) = cond_subject(cp, x, &len(cs));
                    let tests = conds(&pat_conds(cp, p_, &v_));
                    let whole = if &len(cs) == &Nat::from(1u32) {
                        tests.clone()
                    } else {
                        Text::from(format!("{} && {}", &tests, &cpp_templates::stmt_expr(&lexer::join(&pat_binds(cp, p_, &v_), &Text::from("\n")), &rest)))
                    };
                    if &len(&pre) == &Nat::from(0u32) {
                        whole.clone()
                    } else {
                        cpp_templates::stmt_expr(&lexer::join(&pre, &Text::from("\n")), &whole)
                    }
                },
            }
        },
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `GuardTest`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// GuardTest: unbounded fn Cp, [Cc] -> Text
/// ```
pub struct GuardTest {
    pub cp: Cp,
    pub xs1: Array<lower::Cc>,
}

impl prism_rtl::Job<Text> for GuardTest {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let xs1 = &self.xs1;
        match xs1 {
            j0_1 if (j0_1.len() == 0) => prism_rtl::Turn::Finished(Text::from("true")),
            cs => {
                let first_ = or(&index(cs, &Nat::from(0u32)), &lower::Cc::CcIf(lower::Ex::XUnit));
                let cp = cp.clone();
                let cs = cs.clone();
                call_then(start_guard_test(cp.clone(), drop(&cs, &Nat::from(1u32))), move |guard_test_40873: Text| {
                    let rest = guard_test_40873;
                    match &first_ {
                        lower::Cc::CcIf(x) => if &len(&cs) == &Nat::from(1u32) {
                            prism_rtl::Turn::More(Rc::new(CppTight { cp: cp.clone(), x: x.clone() }))
                        } else {
                            {
                                let x = x.clone();
                                call_then(start_cpp_tight(cp.clone(), x.clone()), move |cpp_tight_40974: Text| prism_rtl::Turn::Finished(Text::from(format!("{} && {}", &cpp_tight_40974, &rest))))
                            }
                        },
                        lower::Cc::CcLet(p_, x) => {
                            let p_ = p_.clone();
                            let x = x.clone();
                            call_then(start_cond_subject(cp.clone(), x.clone(), len(&cs)), move |cond_subject_41050: (Text, Array<Text>)| {
                                let (v_, pre) = cond_subject_41050;
                                call_then(start_pat_conds(cp.clone(), p_.clone(), v_.clone()), move |pat_conds_41109: Array<Text>| {
                                    let tests = conds(&pat_conds_41109);
                                    let whole = if &len(&cs) == &Nat::from(1u32) {
                                        tests.clone()
                                    } else {
                                        Text::from(format!("{} && {}", &tests, &cpp_templates::stmt_expr(&lexer::join(&pat_binds(&cp, &p_, &v_), &Text::from("\n")), &rest)))
                                    };
                                    if &len(&pre) == &Nat::from(0u32) {
                                        prism_rtl::Turn::Finished(whole.clone())
                                    } else {
                                        prism_rtl::Turn::Finished(cpp_templates::stmt_expr(&lexer::join(&pre, &Text::from("\n")), &whole))
                                    }
                                })
                            })
                        },
                    }
                })
            },
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start GuardTest, x`: what the function value is when passed to `@Run`.
pub fn start_guard_test(cp: Cp, xs1: Array<lower::Cc>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(GuardTest { cp, xs1 })
}

/// ```prism
/// MatchArm: unbounded fn Cp, Text, XArm -> Text
/// ```
pub fn match_arm(cp0: &Cp, subject: &Text, a: &lower::XArm) -> Text {
    let cp = unbind(cp0, &arm_names(a));
    let tests = pat_conds(&cp, &a.pat, subject);
    let binds = pat_binds(&cp, &a.pat, subject);
    let body = if leaves(&a.body) {
        Text::from(format!("{};", &cpp_expr(&cp, &a.body)))
    } else {
        Text::from(format!("_v.set({});\ngoto _done;", &cpp_expr(&cp, &a.body)))
    };
    let guarded = if &len(&a.conds) == &Nat::from(0u32) {
        body.clone()
    } else {
        guarded_arm(&cp, &a.conds, &body)
    };
    let inner = lexer::join(&append(&binds, &Array::from(vec![guarded.clone()])), &Text::from("\n"));
    if &len(&tests) == &Nat::from(0u32) {
        cpp_templates::braced(&inner)
    } else {
        cpp_templates::if_block(&conds(&tests), &inner)
    }
}

/// The step machine of `MatchArm`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// MatchArm: unbounded fn Cp, Text, XArm -> Text
/// ```
pub struct MatchArm {
    pub cp0: Cp,
    pub subject: Text,
    pub a: lower::XArm,
}

impl prism_rtl::Job<Text> for MatchArm {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp0 = &self.cp0;
        let subject = &self.subject;
        let a = &self.a;
        let a = a.clone();
        let cp0 = cp0.clone();
        let subject = subject.clone();
        call_then(start_arm_names(a.clone()), move |arm_names_41493: Array<Text>| {
            let cp = unbind(&cp0, &arm_names_41493);
            call_then(start_pat_conds(cp.clone(), a.pat.clone(), subject.clone()), move |pat_conds_41521: Array<Text>| {
                let tests = pat_conds_41521;
                call_then(start_pat_binds(cp.clone(), a.pat.clone(), subject.clone()), move |pat_binds_41565: Array<Text>| {
                    let binds = pat_binds_41565;
                    let body = if leaves(&a.body) {
                        Text::from(format!("{};", &cpp_expr(&cp, &a.body)))
                    } else {
                        Text::from(format!("_v.set({});\ngoto _done;", &cpp_expr(&cp, &a.body)))
                    };
                    let guarded = if &len(&a.conds) == &Nat::from(0u32) {
                        body.clone()
                    } else {
                        guarded_arm(&cp, &a.conds, &body)
                    };
                    let inner = lexer::join(&append(&binds, &Array::from(vec![guarded.clone()])), &Text::from("\n"));
                    if &len(&tests) == &Nat::from(0u32) {
                        prism_rtl::Turn::Finished(cpp_templates::braced(&inner))
                    } else {
                        prism_rtl::Turn::Finished(cpp_templates::if_block(&conds(&tests), &inner))
                    }
                })
            })
        })
    }
}

/// `Start MatchArm, x`: what the function value is when passed to `@Run`.
pub fn start_match_arm(cp0: Cp, subject: Text, a: lower::XArm) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(MatchArm { cp0, subject, a })
}

/// ```prism
/// GuardedArm: unbounded fn Cp, [Cc], Text -> Text
/// ```
pub fn guarded_arm(cp: &Cp, xs1: &Array<lower::Cc>, body: &Text) -> Text {
    match xs1 {
        c0_1 if (c0_1.len() == 0) => body.clone(),
        cs => {
            let first_ = or(&index(cs, &Nat::from(0u32)), &lower::Cc::CcIf(lower::Ex::XUnit));
            let rest = guarded_arm(cp, &drop(cs, &Nat::from(1u32)), body);
            match &first_ {
                lower::Cc::CcIf(x) => cpp_templates::if_block(&cpp_expr(cp, x), &rest),
                lower::Cc::CcLet(p_, x) => {
                    let (v_, pre) = cond_subject(cp, x, &len(cs));
                    let inner = cpp_templates::if_block(&conds(&pat_conds(cp, p_, &v_)), &lexer::join(&append(&pat_binds(cp, p_, &v_), &Array::from(vec![rest.clone()])), &Text::from("\n")));
                    if &len(&pre) == &Nat::from(0u32) {
                        inner.clone()
                    } else {
                        cpp_templates::braced(&lexer::join(&push(&pre, &inner), &Text::from("\n")))
                    }
                },
            }
        },
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `GuardedArm`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// GuardedArm: unbounded fn Cp, [Cc], Text -> Text
/// ```
pub struct GuardedArm {
    pub cp: Cp,
    pub xs1: Array<lower::Cc>,
    pub body: Text,
}

impl prism_rtl::Job<Text> for GuardedArm {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let xs1 = &self.xs1;
        let body = &self.body;
        match xs1 {
            j0_1 if (j0_1.len() == 0) => prism_rtl::Turn::Finished(body.clone()),
            cs => {
                let first_ = or(&index(cs, &Nat::from(0u32)), &lower::Cc::CcIf(lower::Ex::XUnit));
                let body = body.clone();
                let cp = cp.clone();
                let cs = cs.clone();
                call_then(start_guarded_arm(cp.clone(), drop(&cs, &Nat::from(1u32)), body.clone()), move |guarded_arm_42165: Text| {
                    let rest = guarded_arm_42165;
                    match &first_ {
                        lower::Cc::CcIf(x) => {
                            let x = x.clone();
                            call_then(start_cpp_expr(cp.clone(), x.clone()), move |cpp_expr_42241: Text| prism_rtl::Turn::Finished(cpp_templates::if_block(&cpp_expr_42241, &rest)))
                        },
                        lower::Cc::CcLet(p_, x) => {
                            let p_ = p_.clone();
                            let x = x.clone();
                            call_then(start_cond_subject(cp.clone(), x.clone(), len(&cs)), move |cond_subject_42311: (Text, Array<Text>)| {
                                let (v_, pre) = cond_subject_42311;
                                call_then(start_pat_conds(cp.clone(), p_.clone(), v_.clone()), move |pat_conds_42379: Array<Text>| call_then(start_pat_binds(cp.clone(), p_.clone(), v_.clone()), move |pat_binds_42415: Array<Text>| {
                                    let inner = cpp_templates::if_block(&conds(&pat_conds_42379), &lexer::join(&append(&pat_binds_42415, &Array::from(vec![rest.clone()])), &Text::from("\n")));
                                    if &len(&pre) == &Nat::from(0u32) {
                                        prism_rtl::Turn::Finished(inner.clone())
                                    } else {
                                        prism_rtl::Turn::Finished(cpp_templates::braced(&lexer::join(&push(&pre, &inner), &Text::from("\n"))))
                                    }
                                }))
                            })
                        },
                    }
                })
            },
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start GuardedArm, x`: what the function value is when passed to `@Run`.
pub fn start_guarded_arm(cp: Cp, xs1: Array<lower::Cc>, body: Text) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(GuardedArm { cp, xs1, body })
}

/// ```prism
/// CppLabeled: unbounded fn Cp, Text, [Do], Ex, OutTy -> Text
/// ```
pub fn cpp_labeled(cp: &Cp, label: &Text, dos: &Array<lower::Do>, e: &lower::Ex, t: &lower::OutTy) -> Text {
    let l = cpp_label(label);
    let last = if leaves(e) {
        Text::from(format!("{};", &cpp_expr(cp, e)))
    } else {
        Text::from(format!("{}_v.set({});", &l, &cpp_expr(cp, e)))
    };
    cpp_templates::labeled_expr(&l, &cpp_type(cp, t), &lexer::join(&push(&run_to_end(each_job(dos.clone(), {
        let cp = cp.clone();
        Rc::new(move |p0: lower::Do| {
            let cp = cp.clone();
            entered(once_job(move || {
                let d = p0;
                prism_rtl::Turn::More(Rc::new(CppStatement { cp: cp.clone(), d: d.clone() }))
            }))
        }) as Rc<dyn Fn(lower::Do) -> Rc<dyn prism_rtl::Job<Text>>>
    })), &last), &Text::from("\n")))
}

/// The step machine of `CppLabeled`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppLabeled: unbounded fn Cp, Text, [Do], Ex, OutTy -> Text
/// ```
pub struct CppLabeled {
    pub cp: Cp,
    pub label: Text,
    pub dos: Array<lower::Do>,
    pub e: lower::Ex,
    pub t: lower::OutTy,
}

impl prism_rtl::Job<Text> for CppLabeled {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let label = &self.label;
        let dos = &self.dos;
        let e = &self.e;
        let t = &self.t;
        let l = cpp_label(label);
        let last = if leaves(e) {
            Text::from(format!("{};", &cpp_expr(cp, e)))
        } else {
            Text::from(format!("{}_v.set({});", &l, &cpp_expr(cp, e)))
        };
        let cp = cp.clone();
        let dos = dos.clone();
        let t = t.clone();
        call_then(start_cpp_type(cp.clone(), t.clone()), move |cpp_type_42841: Text| call_value(each_job(dos.clone(), {
            let cp = cp.clone();
            Rc::new(move |p0: lower::Do| {
                let cp = cp.clone();
                entered(once_job(move || {
                    let d = p0;
                    prism_rtl::Turn::More(Rc::new(CppStatement { cp: cp.clone(), d: d.clone() }))
                }))
            }) as Rc<dyn Fn(lower::Do) -> Rc<dyn prism_rtl::Job<Text>>>
        }), move |each_42870: Array<Text>| prism_rtl::Turn::Finished(cpp_templates::labeled_expr(&l, &cpp_type_42841, &lexer::join(&push(&each_42870, &last), &Text::from("\n"))))))
    }
}

/// `Start CppLabeled, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_labeled(cp: Cp, label: Text, dos: Array<lower::Do>, e: lower::Ex, t: lower::OutTy) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppLabeled { cp, label, dos, e, t })
}

/// ```prism
/// CppLabel: fn Text -> Text
/// ```
pub fn cpp_label(l: &Text) -> Text {
    if lexer::has_prefix(l, &Text::from("'")) { lexer::after_first(l) } else { l.clone() }
}

/// ```prism
/// CppBreak: unbounded fn Cp, Text, Ex -> Text
/// ```
pub fn cpp_break(cp: &Cp, l: &Text, y: &lower::Ex) -> Text {
    let n = cpp_label(l);
    Text::from(format!("{{ {}_v.set({}); goto {}; }}", &n, &cpp_expr(cp, y), &n))
}

/// The step machine of `CppBreak`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppBreak: unbounded fn Cp, Text, Ex -> Text
/// ```
pub struct CppBreak {
    pub cp: Cp,
    pub l: Text,
    pub y: lower::Ex,
}

impl prism_rtl::Job<Text> for CppBreak {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let l = &self.l;
        let y = &self.y;
        let n = cpp_label(l);
        let cp = cp.clone();
        let y = y.clone();
        call_then(start_cpp_expr(cp.clone(), y.clone()), move |cpp_expr_43115: Text| prism_rtl::Turn::Finished(Text::from(format!("{{ {}_v.set({}); goto {}; }}", &n, &cpp_expr_43115, &n))))
    }
}

/// `Start CppBreak, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_break(cp: Cp, l: Text, y: lower::Ex) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppBreak { cp, l, y })
}

/// ```prism
/// CppStatements: unbounded fn Cp, [Do] -> Text
/// ```
pub fn cpp_statements(cp: &Cp, dos: &Array<lower::Do>) -> Text {
    let (st, _) = cpp_statements_cp(cp, dos);
    st.clone()
}

/// The step machine of `CppStatements`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppStatements: unbounded fn Cp, [Do] -> Text
/// ```
pub struct CppStatements {
    pub cp: Cp,
    pub dos: Array<lower::Do>,
}

impl prism_rtl::Job<Text> for CppStatements {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let dos = &self.dos;
        let cp = cp.clone();
        let dos = dos.clone();
        call_then(start_cpp_statements_cp(cp.clone(), dos.clone()), move |cpp_statements_cp_43437: (Text, Cp)| {
            let (st, _) = cpp_statements_cp_43437;
            prism_rtl::Turn::Finished(st.clone())
        })
    }
}

/// `Start CppStatements, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_statements(cp: Cp, dos: Array<lower::Do>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppStatements { cp, dos })
}

/// ```prism
/// CppStatementsCp: unbounded fn Cp, [Do] -> ((Text, Cp))
/// ```
pub fn cpp_statements_cp(cp: &Cp, dos: &Array<lower::Do>) -> (Text, Cp) {
    let (lines, last) = run_to_end(fold_job(dos.clone(), (Array::new(), cp.clone()), Rc::new(move |(p0, p1): ((Array<Text>, Cp), lower::Do)| entered(once_job(move || {
        let (acc, c) = p0;
        let d = p1;
        call_then(start_rebound(c.clone(), d.clone()), move |rebound_43864: Cp| {
            let c2 = rebound_43864;
            let line = match &d {
                lower::Do::DoLet(p_, x) => cpp_let(&c, &c2, p_, x),
                _ => cpp_statement(&c2, &d),
            };
            prism_rtl::Turn::Finished((push(&acc, &line), c2.clone()))
        })
    }))) as Rc<dyn Fn(((Array<Text>, Cp), lower::Do)) -> Rc<dyn prism_rtl::Job<(Array<Text>, Cp)>>>));
    (lexer::join(&lines, &Text::from("\n")), last.clone())
}

/// The step machine of `CppStatementsCp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppStatementsCp: unbounded fn Cp, [Do] -> ((Text, Cp))
/// ```
pub struct CppStatementsCp {
    pub cp: Cp,
    pub dos: Array<lower::Do>,
}

impl prism_rtl::Job<(Text, Cp)> for CppStatementsCp {
    fn cycle(&self) -> prism_rtl::Turn<(Text, Cp)> {
        let cp = &self.cp;
        let dos = &self.dos;
        let cp = cp.clone();
        let dos = dos.clone();
        call_value(fold_job(dos.clone(), (Array::new(), cp.clone()), Rc::new(move |(p0, p1): ((Array<Text>, Cp), lower::Do)| entered(once_job(move || {
            let (acc, c) = p0;
            let d = p1;
            call_then(start_rebound(c.clone(), d.clone()), move |rebound_43864: Cp| {
                let c2 = rebound_43864;
                let line = match &d {
                    lower::Do::DoLet(p_, x) => cpp_let(&c, &c2, p_, x),
                    _ => cpp_statement(&c2, &d),
                };
                prism_rtl::Turn::Finished((push(&acc, &line), c2.clone()))
            })
        }))) as Rc<dyn Fn(((Array<Text>, Cp), lower::Do)) -> Rc<dyn prism_rtl::Job<(Array<Text>, Cp)>>>), move |fold_43806: (Array<Text>, Cp)| {
            let (lines, last) = fold_43806;
            prism_rtl::Turn::Finished((lexer::join(&lines, &Text::from("\n")), last.clone()))
        })
    }
}

/// `Start CppStatementsCp, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_statements_cp(cp: Cp, dos: Array<lower::Do>) -> Rc<dyn prism_rtl::Job<(Text, Cp)>> {
    Rc::new(CppStatementsCp { cp, dos })
}

/// ```prism
/// Unvexed: fn Text -> Text
/// ```
pub fn unvexed(t: &Text) -> Text {
    let head = or(&index(&split(t, &Text::from("(")), &Nat::from(0u32)), &Text::from(""));
    let type_like = lexer::contains(&head, &Text::from(":")) || lexer::contains(&Text::from("ABCDEFGHIJKLMNOPQRSTUVWXYZ"), &lexer::head(&head));
    let vexing = (((&lexer::last_char(t) == &Text::from(")")) && !lexer::contains(&head, &Text::from(" "))) && (&head != &Text::from(""))) && type_like;
    if vexing { Text::from(format!("({})", t)) } else { t.clone() }
}

/// ```prism
/// Rebound: unbounded fn Cp, Do -> Cp
/// ```
pub fn rebound(cp: &Cp, d: &lower::Do) -> Cp {
    match d {
        lower::Do::DoLetElse(p_, _, _) => unbind(cp, &pat_names(p_)),
        lower::Do::DoLet(lower::Pa::PaTuple(ps), _) => unbind(cp, &pat_names(&lower::Pa::PaTuple(ps.clone()))),
        lower::Do::DoLet(lower::Pa::PaCtor(c, ps), _) => unbind(cp, &pat_names(&lower::Pa::PaCtor(c.clone(), ps.clone()))),
        lower::Do::DoLet(lower::Pa::PaRecord(c, fs, r), _) => unbind(cp, &pat_names(&lower::Pa::PaRecord(c.clone(), fs.clone(), *r))),
        lower::Do::DoLet(p_, x) => match let_name(p_) {
            Some(n) => {
                let pointing_ = if is_pointer_let(cp, p_, x) { pointing(cp, &n) } else { known_value(cp, p_, &n) };
                if cpp_mentions(&cpp_expr(cp, x), &var_name(cp, &n)) {
                    {
                        let fresh = Text::from(format!("{}_{}", &var_name(cp, &n), &inc(&len(&keys(&cp.renames)))));
                        {
                            let mut this: Cp = pointing_.clone();
                            this.renames = insert(&this.renames, &n, &fresh);
                            this
                        }
                    }
                } else {
                    pointing_.clone()
                }
            },
            None => cp.clone(),
        },
        _ => cp.clone(),
    }
}

/// The step machine of `Rebound`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Rebound: unbounded fn Cp, Do -> Cp
/// ```
pub struct Rebound {
    pub cp: Cp,
    pub d: lower::Do,
}

impl prism_rtl::Job<Cp> for Rebound {
    fn cycle(&self) -> prism_rtl::Turn<Cp> {
        let cp = &self.cp;
        let d = &self.d;
        match d {
            lower::Do::DoLetElse(p_, _, _) => {
                let cp = cp.clone();
                let p_ = p_.clone();
                call_then(start_pat_names(p_.clone()), move |pat_names_44658: Array<Text>| prism_rtl::Turn::Finished(unbind(&cp, &pat_names_44658)))
            },
            lower::Do::DoLet(lower::Pa::PaTuple(ps), _) => {
                let cp = cp.clone();
                let ps = ps.clone();
                call_then(start_pat_names(lower::Pa::PaTuple(ps.clone())), move |pat_names_44714: Array<Text>| prism_rtl::Turn::Finished(unbind(&cp, &pat_names_44714)))
            },
            lower::Do::DoLet(lower::Pa::PaCtor(c, ps), _) => {
                let c = c.clone();
                let cp = cp.clone();
                let ps = ps.clone();
                call_then(start_pat_names(lower::Pa::PaCtor(c.clone(), ps.clone())), move |pat_names_44783: Array<Text>| prism_rtl::Turn::Finished(unbind(&cp, &pat_names_44783)))
            },
            lower::Do::DoLet(lower::Pa::PaRecord(c, fs, r), _) => {
                let c = c.clone();
                let cp = cp.clone();
                let fs = fs.clone();
                let r = *r;
                call_then(start_pat_names(lower::Pa::PaRecord(c.clone(), fs.clone(), r)), move |pat_names_44859: Array<Text>| prism_rtl::Turn::Finished(unbind(&cp, &pat_names_44859)))
            },
            lower::Do::DoLet(p_, x) => match let_name(p_) {
                Some(n) => {
                    let pointing_ = if is_pointer_let(cp, p_, x) { pointing(cp, &n) } else { known_value(cp, p_, &n) };
                    let cp = cp.clone();
                    let x = x.clone();
                    call_then(start_cpp_expr(cp.clone(), x.clone()), move |cpp_expr_45058: Text| if cpp_mentions(&cpp_expr_45058, &var_name(&cp, &n)) {
                        {
                            let fresh = Text::from(format!("{}_{}", &var_name(&cp, &n), &inc(&len(&keys(&cp.renames)))));
                            prism_rtl::Turn::Finished({
                                let mut this: Cp = pointing_.clone();
                                this.renames = insert(&this.renames, &n, &fresh);
                                this
                            })
                        }
                    } else {
                        prism_rtl::Turn::Finished(pointing_.clone())
                    })
                },
                None => prism_rtl::Turn::Finished(cp.clone()),
            },
            _ => prism_rtl::Turn::Finished(cp.clone()),
        }
    }
}

/// `Start Rebound, x`: what the function value is when passed to `@Run`.
pub fn start_rebound(cp: Cp, d: lower::Do) -> Rc<dyn prism_rtl::Job<Cp>> {
    Rc::new(Rebound { cp, d })
}

/// ```prism
/// PatNames: unbounded fn Pa -> [Text]
/// ```
pub fn pat_names(p_: &lower::Pa) -> Array<Text> {
    match p_ {
        lower::Pa::PaBind(n) => Array::from(vec![n.clone()]),
        lower::Pa::PaMut(n) => Array::from(vec![n.clone()]),
        lower::Pa::PaTyped(q, _) => pat_names(&**q),
        lower::Pa::PaCtor(_, ps) => concat2(&run_to_end(each_job(ps.clone(), Rc::new(move |p0: lower::Pa| entered(once_job(move || {
            let q = p0;
            prism_rtl::Turn::More(Rc::new(PatNames { p_: q.clone() }))
        }))) as Rc<dyn Fn(lower::Pa) -> Rc<dyn prism_rtl::Job<Array<Text>>>>))),
        lower::Pa::PaRecord(_, fs, _) => concat2(&run_to_end(each_job(fs.clone(), Rc::new(move |p0: (Text, lower::Pa)| entered(once_job(move || {
            let (_, q) = p0;
            prism_rtl::Turn::More(Rc::new(PatNames { p_: q.clone() }))
        }))) as Rc<dyn Fn((Text, lower::Pa)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>))),
        lower::Pa::PaTuple(ps) => concat2(&run_to_end(each_job(ps.clone(), Rc::new(move |p0: lower::Pa| entered(once_job(move || {
            let q = p0;
            prism_rtl::Turn::More(Rc::new(PatNames { p_: q.clone() }))
        }))) as Rc<dyn Fn(lower::Pa) -> Rc<dyn prism_rtl::Job<Array<Text>>>>))),
        lower::Pa::PaSlice(ps) => concat2(&run_to_end(each_job(ps.clone(), Rc::new(move |p0: lower::Pa| entered(once_job(move || {
            let q = p0;
            prism_rtl::Turn::More(Rc::new(PatNames { p_: q.clone() }))
        }))) as Rc<dyn Fn(lower::Pa) -> Rc<dyn prism_rtl::Job<Array<Text>>>>))),
        lower::Pa::PaRest(n) => if n == &Text::from("") { Array::new() } else { Array::from(vec![n.clone()]) },
        _ => Array::new(),
    }
}

/// The step machine of `PatNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PatNames: unbounded fn Pa -> [Text]
/// ```
pub struct PatNames {
    pub p_: lower::Pa,
}

impl prism_rtl::Job<Array<Text>> for PatNames {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let p_ = &self.p_;
        match p_ {
            lower::Pa::PaBind(n) => prism_rtl::Turn::Finished(Array::from(vec![n.clone()])),
            lower::Pa::PaMut(n) => prism_rtl::Turn::Finished(Array::from(vec![n.clone()])),
            lower::Pa::PaTyped(q, _) => prism_rtl::Turn::More(Rc::new(PatNames { p_: (**q).clone() })),
            lower::Pa::PaCtor(_, ps) => {
                let ps = ps.clone();
                call_value(each_job(ps.clone(), Rc::new(move |p0: lower::Pa| entered(once_job(move || {
                    let q = p0;
                    prism_rtl::Turn::More(Rc::new(PatNames { p_: q.clone() }))
                }))) as Rc<dyn Fn(lower::Pa) -> Rc<dyn prism_rtl::Job<Array<Text>>>>), move |each_45519: Array<Array<Text>>| prism_rtl::Turn::Finished(concat2(&each_45519)))
            },
            lower::Pa::PaRecord(_, fs, _) => {
                let fs = fs.clone();
                call_value(each_job(fs.clone(), Rc::new(move |p0: (Text, lower::Pa)| entered(once_job(move || {
                    let (_, q) = p0;
                    prism_rtl::Turn::More(Rc::new(PatNames { p_: q.clone() }))
                }))) as Rc<dyn Fn((Text, lower::Pa)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>), move |each_45587: Array<Array<Text>>| prism_rtl::Turn::Finished(concat2(&each_45587)))
            },
            lower::Pa::PaTuple(ps) => {
                let ps = ps.clone();
                call_value(each_job(ps.clone(), Rc::new(move |p0: lower::Pa| entered(once_job(move || {
                    let q = p0;
                    prism_rtl::Turn::More(Rc::new(PatNames { p_: q.clone() }))
                }))) as Rc<dyn Fn(lower::Pa) -> Rc<dyn prism_rtl::Job<Array<Text>>>>), move |each_45650: Array<Array<Text>>| prism_rtl::Turn::Finished(concat2(&each_45650)))
            },
            lower::Pa::PaSlice(ps) => {
                let ps = ps.clone();
                call_value(each_job(ps.clone(), Rc::new(move |p0: lower::Pa| entered(once_job(move || {
                    let q = p0;
                    prism_rtl::Turn::More(Rc::new(PatNames { p_: q.clone() }))
                }))) as Rc<dyn Fn(lower::Pa) -> Rc<dyn prism_rtl::Job<Array<Text>>>>), move |each_45701: Array<Array<Text>>| prism_rtl::Turn::Finished(concat2(&each_45701)))
            },
            lower::Pa::PaRest(n) => if n == &Text::from("") {
                prism_rtl::Turn::Finished(Array::new())
            } else {
                prism_rtl::Turn::Finished(Array::from(vec![n.clone()]))
            },
            _ => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start PatNames, x`: what the function value is when passed to `@Run`.
pub fn start_pat_names(p_: lower::Pa) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(PatNames { p_ })
}

/// ```prism
/// ArmNames: unbounded fn XArm -> [Text]
/// ```
pub fn arm_names(a: &lower::XArm) -> Array<Text> {
    append(&pat_names(&a.pat), &concat2(&run_to_end(each_job(a.conds.clone(), Rc::new(move |p0: lower::Cc| entered(once_job(move || {
        let c = p0;
        prism_rtl::Turn::More(Rc::new(CondNames { cc0: c.clone() }))
    }))) as Rc<dyn Fn(lower::Cc) -> Rc<dyn prism_rtl::Job<Array<Text>>>>))))
}

/// The step machine of `ArmNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ArmNames: unbounded fn XArm -> [Text]
/// ```
pub struct ArmNames {
    pub a: lower::XArm,
}

impl prism_rtl::Job<Array<Text>> for ArmNames {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let a = &self.a;
        let a = a.clone();
        call_then(start_pat_names(a.pat.clone()), move |pat_names_45853: Array<Text>| call_value(each_job(a.conds.clone(), Rc::new(move |p0: lower::Cc| entered(once_job(move || {
            let c = p0;
            prism_rtl::Turn::More(Rc::new(CondNames { cc0: c.clone() }))
        }))) as Rc<dyn Fn(lower::Cc) -> Rc<dyn prism_rtl::Job<Array<Text>>>>), move |each_45880: Array<Array<Text>>| prism_rtl::Turn::Finished(append(&pat_names_45853, &concat2(&each_45880)))))
    }
}

/// `Start ArmNames, x`: what the function value is when passed to `@Run`.
pub fn start_arm_names(a: lower::XArm) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(ArmNames { a })
}

/// ```prism
/// CondNames: unbounded fn Cc -> [Text]
/// ```
pub fn cond_names(cc0: &lower::Cc) -> Array<Text> {
    match cc0 {
        lower::Cc::CcLet(q, _) => pat_names(q),
        lower::Cc::CcIf(_) => Array::new(),
    }
}

/// The step machine of `CondNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CondNames: unbounded fn Cc -> [Text]
/// ```
pub struct CondNames {
    pub cc0: lower::Cc,
}

impl prism_rtl::Job<Array<Text>> for CondNames {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let cc0 = &self.cc0;
        match cc0 {
            lower::Cc::CcLet(q, _) => prism_rtl::Turn::More(Rc::new(PatNames { p_: q.clone() })),
            lower::Cc::CcIf(_) => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start CondNames, x`: what the function value is when passed to `@Run`.
pub fn start_cond_names(cc0: lower::Cc) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(CondNames { cc0 })
}

/// ```prism
/// Unbind: fn Cp, [Text] -> Cp
/// ```
pub fn unbind(cp: &Cp, names: &Array<Text>) -> Cp {
    let mut this: Cp = cp.clone();
    this.renames = fold(names, &this.renames, &(|m: &Map<Text, Text>, n: &Text| remove(m, n)));
    this.pointers = fold(names, &this.pointers, &(|m: &Map<Text, bool>, n: &Text| remove(m, n)));
    this
}

/// ```prism
/// Pointing: fn Cp, Text -> Cp
/// ```
pub fn pointing(cp: &Cp, n: &Text) -> Cp {
    let mut this: Cp = cp.clone();
    this.pointers = insert(&this.pointers, n, &true);
    this
}

/// ```prism
/// KnownValue: fn Cp, Pa, Text -> Cp
/// ```
pub fn known_value(cp: &Cp, p_: &lower::Pa, n: &Text) -> Cp {
    match p_ {
        lower::Pa::PaTyped(_, _) => {
            let mut this: Cp = cp.clone();
            this.pointers = insert(&this.pointers, n, &false);
            this
        },
        _ => cp.clone(),
    }
}

/// ```prism
/// IsPointerLet: fn Cp, Pa, Ex -> Bool
/// ```
pub fn is_pointer_let(cp: &Cp, p_: &lower::Pa, x: &lower::Ex) -> bool {
    match p_ {
        lower::Pa::PaTyped(_, t) => is_pointer_ty(cp, t),
        _ => 'm46998: {
            if let lower::Ex::XCall(m46998_0_0, _) = x && (m46998_0_0 == &Text::from("prism_rtl::Host::new")) {
                break 'm46998 true;
            }
            if let lower::Ex::XCall(m46998_1_0, m46998_1_1) = x && (m46998_1_0 == &Text::from("Rc::new")) && (m46998_1_1.len() == 1) && let Some(lower::Ex::XCall(m46998_1_1_0_0, _)) = index(m46998_1_1, &Nat::from(0u32)) && (&m46998_1_1_0_0 == &Text::from("Port::new")) {
                break 'm46998 true;
            }
            match pointer(cp, x) {
                Some(b) => b,
                None => false,
            }
        },
    }
}

/// ```prism
/// Inc: fn Nat -> Nat
/// ```
pub fn inc(n: &Nat) -> Nat {
    n + &Nat::from(1u32)
}

/// ```prism
/// ?LetName: fn Pa -> ?Text
/// ```
pub fn let_name(p_: &lower::Pa) -> Option<Text> {
    match p_ {
        lower::Pa::PaBind(n) => Some(n.clone()),
        lower::Pa::PaMut(n) => Some(n.clone()),
        lower::Pa::PaTyped(q, _) => let_name(&**q),
        _ => None,
    }
}

/// ```prism
/// VarName: fn Cp, Text -> Text
/// ```
pub fn var_name(cp: &Cp, n: &Text) -> Text {
    or(&get(&cp.renames, n), &cpp_id(n))
}

/// ```prism
/// CppMentions: fn Text, Text -> Bool
/// ```
pub fn cpp_mentions(t: &Text, n: &Text) -> bool {
    let parts = split(t, n);
    let k = len(&parts);
    fold(&check_errors::range0(&lexer::dec(&k)), &false, &(|f: &bool, i: &Nat| *f || (!cpp_ends_ident(&or(&index(&parts, i), &Text::from(""))) && !cpp_starts_ident(&or(&index(&parts, &(i + &Nat::from(1u32))), &Text::from(""))))))
}

/// ```prism
/// CppEndsIdent: fn Text -> Bool
/// ```
pub fn cpp_ends_ident(t: &Text) -> bool {
    let c = lexer::last_char(t);
    (cpp_ident_char(&c) || (&c == &Text::from("."))) || (&c == &Text::from(">"))
}

/// ```prism
/// CppStartsIdent: fn Text -> Bool
/// ```
pub fn cpp_starts_ident(t: &Text) -> bool {
    cpp_ident_char(&lexer::head(t))
}

/// ```prism
/// CppIdentChar: fn Text -> Bool
/// ```
pub fn cpp_ident_char(c: &Text) -> bool {
    (c != &Text::from("")) && lexer::contains(&Text::from("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_"), c)
}

/// ```prism
/// CppStatement: unbounded fn Cp, Do -> Text
/// ```
pub fn cpp_statement(cp: &Cp, d: &lower::Do) -> Text {
    match d {
        lower::Do::DoLet(p_, x) => cpp_let(cp, cp, p_, x),
        lower::Do::DoLetElse(p_, x, e) => {
            let v_ = Text::from(format!("_{}", &or(&first_binder(p_), &Text::from("m"))));
            Text::from(format!("auto&& {} = {};\nif (!({})) {{ {}; }}\n{}", &v_, &cpp_expr(cp, x), &conds(&pat_conds(cp, p_, &v_)), &cpp_expr(cp, e), &lexer::join(&pat_binds(cp, p_, &v_), &Text::from("\n"))))
        },
        lower::Do::DoAssign(p_, x) => Text::from(format!("{} = {};", &cpp_expr(cp, p_), &cpp_expr(cp, x))),
        lower::Do::DoWhile(c, body) => cpp_templates::block(&Text::from(format!("while ({})", &cpp_expr(cp, c))), &cpp_statements(cp, body)),
        lower::Do::DoWhileLet(p_, x, body) => {
            let v_ = Text::from("_m");
            let head = Text::from(format!("auto&& _m = {};\nif (!({})) break;", &cpp_expr(cp, x), &conds(&pat_conds(cp, p_, &v_))));
            cpp_templates::block(&Text::from("while (true)"), &lexer::join(&append(&append(&Array::from(vec![head.clone()]), &pat_binds(cp, p_, &v_)), &Array::from(vec![cpp_statements(cp, body)])), &Text::from("\n")))
        },
        lower::Do::DoFor(p_, x, body) => cpp_for(cp, p_, x, body),
        lower::Do::DoExpr(lower::Ex::XBreak(l, y)) => cpp_break(cp, l, &**y),
        lower::Do::DoExpr(lower::Ex::XBreakLoop) => Text::from("break;"),
        lower::Do::DoExpr(x) => Text::from(format!("{};", &cpp_expr(cp, x))),
        lower::Do::DoIf(c, t, e) => Text::from(format!("{}{}", &cpp_templates::block(&Text::from(format!("if ({})", &cpp_expr(cp, c))), &cpp_statements(cp, t)), &cpp_else(cp, e))),
        lower::Do::DoIfLet(p_, x, t, e) => cpp_if_let(cp, p_, x, t, e),
        lower::Do::DoMatch(x, cases) => cpp_do_match(cp, x, cases),
        lower::Do::DoReturn(x) => Text::from(format!("return {};", &cpp_expr(cp, x))),
        lower::Do::DoScope(body) => Text::from(format!("{{ {} }}", &cpp_inline(cp, body))),
        lower::Do::DoLine(body) => cpp_inline(cp, body),
        lower::Do::DoNote(t) => Text::from(format!("// {}", t)),
    }
}

/// The step machine of `CppStatement`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppStatement: unbounded fn Cp, Do -> Text
/// ```
pub struct CppStatement {
    pub cp: Cp,
    pub d: lower::Do,
}

impl prism_rtl::Job<Text> for CppStatement {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let d = &self.d;
        match d {
            lower::Do::DoLet(p_, x) => prism_rtl::Turn::More(Rc::new(CppLet { cp: cp.clone(), named: cp.clone(), p_: p_.clone(), x: x.clone() })),
            lower::Do::DoLetElse(p_, x, e) => {
                let cp = cp.clone();
                let e = e.clone();
                let p_ = p_.clone();
                let x = x.clone();
                call_then(start_first_binder(p_.clone()), move |first_binder_48290: Option<Text>| {
                    let v_ = Text::from(format!("_{}", &or(&first_binder_48290, &Text::from("m"))));
                    call_then(start_cpp_expr(cp.clone(), x.clone()), move |cpp_expr_48336: Text| call_then(start_pat_conds(cp.clone(), p_.clone(), v_.clone()), move |pat_conds_48367: Array<Text>| call_then(start_cpp_expr(cp.clone(), e.clone()), move |cpp_expr_48393: Text| call_then(start_pat_binds(cp.clone(), p_.clone(), v_.clone()), move |pat_binds_48420: Array<Text>| prism_rtl::Turn::Finished(Text::from(format!("auto&& {} = {};\nif (!({})) {{ {}; }}\n{}", &v_, &cpp_expr_48336, &conds(&pat_conds_48367), &cpp_expr_48393, &lexer::join(&pat_binds_48420, &Text::from("\n")))))))))
                })
            },
            lower::Do::DoAssign(p_, x) => {
                let cp = cp.clone();
                let p_ = p_.clone();
                let x = x.clone();
                call_then(start_cpp_expr(cp.clone(), p_.clone()), move |cpp_expr_48468: Text| call_then(start_cpp_expr(cp.clone(), x.clone()), move |cpp_expr_48486: Text| prism_rtl::Turn::Finished(Text::from(format!("{} = {};", &cpp_expr_48468, &cpp_expr_48486)))))
            },
            lower::Do::DoWhile(c, body) => {
                let body = body.clone();
                let c = c.clone();
                let cp = cp.clone();
                call_then(start_cpp_expr(cp.clone(), c.clone()), move |cpp_expr_48539: Text| call_then(start_cpp_statements(cp.clone(), body.clone()), move |cpp_statements_48558: Text| prism_rtl::Turn::Finished(cpp_templates::block(&Text::from(format!("while ({})", &cpp_expr_48539)), &cpp_statements_48558))))
            },
            lower::Do::DoWhileLet(p_, x, body) => {
                let v_ = Text::from("_m");
                let body = body.clone();
                let cp = cp.clone();
                let p_ = p_.clone();
                let x = x.clone();
                call_then(start_cpp_expr(cp.clone(), x.clone()), move |cpp_expr_48663: Text| call_then(start_pat_conds(cp.clone(), p_.clone(), v_.clone()), move |pat_conds_48694: Array<Text>| {
                    let head = Text::from(format!("auto&& _m = {};\nif (!({})) break;", &cpp_expr_48663, &conds(&pat_conds_48694)));
                    call_then(start_pat_binds(cp.clone(), p_.clone(), v_.clone()), move |pat_binds_48787: Array<Text>| call_then(start_cpp_statements(cp.clone(), body.clone()), move |cpp_statements_48811: Text| prism_rtl::Turn::Finished(cpp_templates::block(&Text::from("while (true)"), &lexer::join(&append(&append(&Array::from(vec![head.clone()]), &pat_binds_48787), &Array::from(vec![cpp_statements_48811])), &Text::from("\n"))))))
                }))
            },
            lower::Do::DoFor(p_, x, body) => prism_rtl::Turn::More(Rc::new(CppFor { cp0: cp.clone(), p_: p_.clone(), x: x.clone(), body: body.clone() })),
            lower::Do::DoExpr(lower::Ex::XBreak(l, y)) => prism_rtl::Turn::More(Rc::new(CppBreak { cp: cp.clone(), l: l.clone(), y: (**y).clone() })),
            lower::Do::DoExpr(lower::Ex::XBreakLoop) => prism_rtl::Turn::Finished(Text::from("break;")),
            lower::Do::DoExpr(x) => {
                let cp = cp.clone();
                let x = x.clone();
                call_then(start_cpp_expr(cp.clone(), x.clone()), move |cpp_expr_48981: Text| prism_rtl::Turn::Finished(Text::from(format!("{};", &cpp_expr_48981))))
            },
            lower::Do::DoIf(c, t, e) => {
                let c = c.clone();
                let cp = cp.clone();
                let e = e.clone();
                let t = t.clone();
                call_then(start_cpp_expr(cp.clone(), c.clone()), move |cpp_expr_49030: Text| call_then(start_cpp_statements(cp.clone(), t.clone()), move |cpp_statements_49049: Text| call_then(start_cpp_else(cp.clone(), e.clone()), move |cpp_else_49071: Text| prism_rtl::Turn::Finished(Text::from(format!("{}{}", &cpp_templates::block(&Text::from(format!("if ({})", &cpp_expr_49030)), &cpp_statements_49049), &cpp_else_49071))))))
            },
            lower::Do::DoIfLet(p_, x, t, e) => prism_rtl::Turn::More(Rc::new(CppIfLet { cp0: cp.clone(), p_: p_.clone(), x: x.clone(), t: t.clone(), e: e.clone() })),
            lower::Do::DoMatch(x, cases) => prism_rtl::Turn::More(Rc::new(CppDoMatch { cp: cp.clone(), x: x.clone(), cases: cases.clone() })),
            lower::Do::DoReturn(x) => {
                let cp = cp.clone();
                let x = x.clone();
                call_then(start_cpp_expr(cp.clone(), x.clone()), move |cpp_expr_49206: Text| prism_rtl::Turn::Finished(Text::from(format!("return {};", &cpp_expr_49206))))
            },
            lower::Do::DoScope(body) => {
                let body = body.clone();
                let cp = cp.clone();
                call_then(start_cpp_inline(cp.clone(), body.clone()), move |cpp_inline_49246: Text| prism_rtl::Turn::Finished(Text::from(format!("{{ {} }}", &cpp_inline_49246))))
            },
            lower::Do::DoLine(body) => prism_rtl::Turn::More(Rc::new(CppInline { cp: cp.clone(), dos: body.clone() })),
            lower::Do::DoNote(t) => prism_rtl::Turn::Finished(Text::from(format!("// {}", t))),
        }
    }
}

/// `Start CppStatement, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_statement(cp: Cp, d: lower::Do) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppStatement { cp, d })
}

/// ```prism
/// CppInline: unbounded fn Cp, [Do] -> Text
/// ```
pub fn cpp_inline(cp: &Cp, dos: &Array<lower::Do>) -> Text {
    lexer::join(&run_to_end(each_job(dos.clone(), {
        let cp = cp.clone();
        Rc::new(move |p0: lower::Do| {
            let cp = cp.clone();
            entered(once_job(move || {
                let d = p0;
                prism_rtl::Turn::More(Rc::new(CppStatement { cp: cp.clone(), d: d.clone() }))
            }))
        }) as Rc<dyn Fn(lower::Do) -> Rc<dyn prism_rtl::Job<Text>>>
    })), &Text::from(" "))
}

/// The step machine of `CppInline`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppInline: unbounded fn Cp, [Do] -> Text
/// ```
pub struct CppInline {
    pub cp: Cp,
    pub dos: Array<lower::Do>,
}

impl prism_rtl::Job<Text> for CppInline {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let dos = &self.dos;
        let cp = cp.clone();
        let dos = dos.clone();
        call_value(each_job(dos.clone(), {
            let cp = cp.clone();
            Rc::new(move |p0: lower::Do| {
                let cp = cp.clone();
                entered(once_job(move || {
                    let d = p0;
                    prism_rtl::Turn::More(Rc::new(CppStatement { cp: cp.clone(), d: d.clone() }))
                }))
            }) as Rc<dyn Fn(lower::Do) -> Rc<dyn prism_rtl::Job<Text>>>
        }), move |each_49400: Array<Text>| prism_rtl::Turn::Finished(lexer::join(&each_49400, &Text::from(" "))))
    }
}

/// `Start CppInline, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_inline(cp: Cp, dos: Array<lower::Do>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppInline { cp, dos })
}

/// ```prism
/// CppElse: unbounded fn Cp, [Do] -> Text
/// ```
pub fn cpp_else(cp: &Cp, xs1: &Array<lower::Do>) -> Text {
    'c: {
        if let c0_1 = xs1 && (c0_1.len() == 0) {
            break 'c Text::from("");
        }
        if let c1_1 = xs1 && (c1_1.len() == 1) && let Some(lower::Do::DoIf(c, t, e)) = index(c1_1, &Nat::from(0u32)) {
            break 'c Text::from(format!(" else {}", &cpp_statement(cp, &lower::Do::DoIf(c.clone(), t.clone(), e.clone()))));
        }
        if let c2_1 = xs1 && (c2_1.len() == 1) && let Some(lower::Do::DoIfLet(p_, x, t, e)) = index(c2_1, &Nat::from(0u32)) {
            break 'c Text::from(format!(" else {}", &cpp_statement(cp, &lower::Do::DoIfLet(p_.clone(), x.clone(), t.clone(), e.clone()))));
        }
        if let body = xs1 {
            break 'c Text::from(format!(" else {}", &cpp_templates::block(&Text::from(""), &cpp_statements(cp, body))));
        }
        unreachable!("no clause matched")
    }
}

/// The step machine of `CppElse`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppElse: unbounded fn Cp, [Do] -> Text
/// ```
pub struct CppElse {
    pub cp: Cp,
    pub xs1: Array<lower::Do>,
}

impl prism_rtl::Job<Text> for CppElse {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let xs1 = &self.xs1;
        'j: {
            if let j0_1 = xs1 && (j0_1.len() == 0) {
                break 'j prism_rtl::Turn::Finished(Text::from(""));
            }
            if let j1_1 = xs1 && (j1_1.len() == 1) && let Some(lower::Do::DoIf(c, t, e)) = index(j1_1, &Nat::from(0u32)) {
                break 'j {
                    let cp = cp.clone();
                    call_then(start_cpp_statement(cp.clone(), lower::Do::DoIf(c.clone(), t.clone(), e.clone())), move |cpp_statement_49549: Text| prism_rtl::Turn::Finished(Text::from(format!(" else {}", &cpp_statement_49549))))
                };
            }
            if let j2_1 = xs1 && (j2_1.len() == 1) && let Some(lower::Do::DoIfLet(p_, x, t, e)) = index(j2_1, &Nat::from(0u32)) {
                break 'j {
                    let cp = cp.clone();
                    call_then(start_cpp_statement(cp.clone(), lower::Do::DoIfLet(p_.clone(), x.clone(), t.clone(), e.clone())), move |cpp_statement_49633: Text| prism_rtl::Turn::Finished(Text::from(format!(" else {}", &cpp_statement_49633))))
                };
            }
            if let body = xs1 {
                break 'j {
                    let body = body.clone();
                    let cp = cp.clone();
                    call_then(start_cpp_statements(cp.clone(), body.clone()), move |cpp_statements_49714: Text| prism_rtl::Turn::Finished(Text::from(format!(" else {}", &cpp_templates::block(&Text::from(""), &cpp_statements_49714)))))
                };
            }
            unreachable!("no clause matched")
        }
    }
}

/// `Start CppElse, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_else(cp: Cp, xs1: Array<lower::Do>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppElse { cp, xs1 })
}

/// ```prism
/// CppLet: unbounded fn Cp, Cp, Pa, Ex -> Text
/// ```
pub fn cpp_let(cp: &Cp, named: &Cp, p_: &lower::Pa, x: &lower::Ex) -> Text {
    'm49930: {
        if let lower::Pa::PaWild = p_ {
            break 'm49930 Text::from(format!("static_cast<void>({});", &cpp_expr(cp, x)));
        }
        if let lower::Pa::PaBind(n) = p_ {
            break 'm49930 match x {
                lower::Ex::XRef(_) => Text::from(format!("const auto& {} = {};", &var_name(named, n), &cpp_expr(cp, x))),
                _ => Text::from(format!("auto {} = {};", &var_name(named, n), &cpp_expr(cp, x))),
            };
        }
        if let lower::Pa::PaMut(n) = p_ {
            break 'm49930 Text::from(format!("auto {} = {};", &var_name(named, n), &cpp_expr(cp, x)));
        }
        if let lower::Pa::PaTyped(m49930_3_0, t) = p_ && let lower::Pa::PaBind(n) = &**m49930_3_0 {
            break 'm49930 Text::from(format!("{} {} = {};", &cpp_type(cp, t), &var_name(named, n), &cpp_expr(cp, x)));
        }
        if let lower::Pa::PaTyped(m49930_4_0, t) = p_ && let lower::Pa::PaMut(n) = &**m49930_4_0 {
            break 'm49930 Text::from(format!("{} {} = {};", &cpp_type(cp, t), &var_name(named, n), &cpp_expr(cp, x)));
        }
        if let lower::Pa::PaTuple(ps) = p_ {
            break 'm49930 if fold(ps, &true, &(|f: &bool, q: &lower::Pa| *f && is_name(q))) {
                Text::from(format!("auto [{}] = {};", &lexer::join(&each(ps, &(|q: &lower::Pa| pat_name(q))), &Text::from(", ")), &cpp_expr(cp, x)))
            } else {
                let_through(cp, p_, x)
            };
        }
        let_through(cp, p_, x)
    }
}

/// The step machine of `CppLet`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppLet: unbounded fn Cp, Cp, Pa, Ex -> Text
/// ```
pub struct CppLet {
    pub cp: Cp,
    pub named: Cp,
    pub p_: lower::Pa,
    pub x: lower::Ex,
}

impl prism_rtl::Job<Text> for CppLet {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let named = &self.named;
        let p_ = &self.p_;
        let x = &self.x;
        'm49930: {
            if let lower::Pa::PaWild = p_ {
                break 'm49930 {
                    let cp = cp.clone();
                    let x = x.clone();
                    call_then(start_cpp_expr(cp.clone(), x.clone()), move |cpp_expr_49971: Text| prism_rtl::Turn::Finished(Text::from(format!("static_cast<void>({});", &cpp_expr_49971))))
                };
            }
            if let lower::Pa::PaBind(n) = p_ {
                break 'm49930 match x {
                    lower::Ex::XRef(_) => {
                        let cp = cp.clone();
                        let n = n.clone();
                        let named = named.clone();
                        let x = x.clone();
                        call_then(start_cpp_expr(cp.clone(), x.clone()), move |cpp_expr_50068: Text| prism_rtl::Turn::Finished(Text::from(format!("const auto& {} = {};", &var_name(&named, &n), &cpp_expr_50068))))
                    },
                    _ => {
                        let cp = cp.clone();
                        let n = n.clone();
                        let named = named.clone();
                        let x = x.clone();
                        call_then(start_cpp_expr(cp.clone(), x.clone()), move |cpp_expr_50132: Text| prism_rtl::Turn::Finished(Text::from(format!("auto {} = {};", &var_name(&named, &n), &cpp_expr_50132))))
                    },
                };
            }
            if let lower::Pa::PaMut(n) = p_ {
                break 'm49930 {
                    let cp = cp.clone();
                    let n = n.clone();
                    let named = named.clone();
                    let x = x.clone();
                    call_then(start_cpp_expr(cp.clone(), x.clone()), move |cpp_expr_50190: Text| prism_rtl::Turn::Finished(Text::from(format!("auto {} = {};", &var_name(&named, &n), &cpp_expr_50190))))
                };
            }
            if let lower::Pa::PaTyped(m49930_3_0, t) = p_ && let lower::Pa::PaBind(n) = &**m49930_3_0 {
                break 'm49930 {
                    let cp = cp.clone();
                    let n = n.clone();
                    let named = named.clone();
                    let t = t.clone();
                    let x = x.clone();
                    call_then(start_cpp_type(cp.clone(), t.clone()), move |cpp_type_50236: Text| call_then(start_cpp_expr(cp.clone(), x.clone()), move |cpp_expr_50273: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {} = {};", &cpp_type_50236, &var_name(&named, &n), &cpp_expr_50273)))))
                };
            }
            if let lower::Pa::PaTyped(m49930_4_0, t) = p_ && let lower::Pa::PaMut(n) = &**m49930_4_0 {
                break 'm49930 {
                    let cp = cp.clone();
                    let n = n.clone();
                    let named = named.clone();
                    let t = t.clone();
                    let x = x.clone();
                    call_then(start_cpp_type(cp.clone(), t.clone()), move |cpp_type_50318: Text| call_then(start_cpp_expr(cp.clone(), x.clone()), move |cpp_expr_50355: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {} = {};", &cpp_type_50318, &var_name(&named, &n), &cpp_expr_50355)))))
                };
            }
            if let lower::Pa::PaTuple(ps) = p_ {
                break 'm49930 if fold(ps, &true, &(|f: &bool, q: &lower::Pa| *f && is_name(q))) {
                    {
                        let cp = cp.clone();
                        let ps = ps.clone();
                        let x = x.clone();
                        call_then(start_cpp_expr(cp.clone(), x.clone()), move |cpp_expr_50488: Text| prism_rtl::Turn::Finished(Text::from(format!("auto [{}] = {};", &lexer::join(&each(&ps, &(|q: &lower::Pa| pat_name(q))), &Text::from(", ")), &cpp_expr_50488))))
                    }
                } else {
                    prism_rtl::Turn::More(Rc::new(LetThrough { cp: cp.clone(), p_: p_.clone(), x: x.clone() }))
                };
            }
            prism_rtl::Turn::More(Rc::new(LetThrough { cp: cp.clone(), p_: p_.clone(), x: x.clone() }))
        }
    }
}

/// `Start CppLet, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_let(cp: Cp, named: Cp, p_: lower::Pa, x: lower::Ex) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppLet { cp, named, p_, x })
}

/// ```prism
/// LetThrough: unbounded fn Cp, Pa, Ex -> Text
/// ```
pub fn let_through(cp: &Cp, p_: &lower::Pa, x: &lower::Ex) -> Text {
    let t = Text::from(format!("_{}", &or(&first_binder(p_), &Text::from("t"))));
    Text::from(format!("auto&& {} = {};\n{}", &t, &cpp_expr(cp, x), &lexer::join(&pat_binds(cp, p_, &t), &Text::from("\n"))))
}

/// The step machine of `LetThrough`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LetThrough: unbounded fn Cp, Pa, Ex -> Text
/// ```
pub struct LetThrough {
    pub cp: Cp,
    pub p_: lower::Pa,
    pub x: lower::Ex,
}

impl prism_rtl::Job<Text> for LetThrough {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let p_ = &self.p_;
        let x = &self.x;
        let cp = cp.clone();
        let p_ = p_.clone();
        let x = x.clone();
        call_then(start_first_binder(p_.clone()), move |first_binder_50747: Option<Text>| {
            let t = Text::from(format!("_{}", &or(&first_binder_50747, &Text::from("t"))));
            call_then(start_cpp_expr(cp.clone(), x.clone()), move |cpp_expr_50789: Text| call_then(start_pat_binds(cp.clone(), p_.clone(), t.clone()), move |pat_binds_50813: Array<Text>| prism_rtl::Turn::Finished(Text::from(format!("auto&& {} = {};\n{}", &t, &cpp_expr_50789, &lexer::join(&pat_binds_50813, &Text::from("\n")))))))
        })
    }
}

/// `Start LetThrough, x`: what the function value is when passed to `@Run`.
pub fn start_let_through(cp: Cp, p_: lower::Pa, x: lower::Ex) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(LetThrough { cp, p_, x })
}

/// ```prism
/// ?FirstBinder: unbounded fn Pa -> ?Text
/// ```
pub fn first_binder(p_: &lower::Pa) -> Option<Text> {
    match p_ {
        lower::Pa::PaBind(n) => Some(n.clone()),
        lower::Pa::PaMut(n) => Some(n.clone()),
        lower::Pa::PaTyped(q, _) => first_binder(&**q),
        lower::Pa::PaCtor(_, ps) => run_to_end(fold_job(ps.clone(), None, Rc::new(move |(p0, p1): (Option<Text>, lower::Pa)| entered(once_job(move || {
            let f_opt = p0;
            let q = p1;
            match &f_opt {
                Some(b) => prism_rtl::Turn::Finished(Some(b.clone())),
                None => prism_rtl::Turn::More(Rc::new(FirstBinder { p_: q.clone() })),
            }
        }))) as Rc<dyn Fn((Option<Text>, lower::Pa)) -> Rc<dyn prism_rtl::Job<Option<Text>>>>)),
        lower::Pa::PaTuple(ps) => run_to_end(fold_job(ps.clone(), None, Rc::new(move |(p0, p1): (Option<Text>, lower::Pa)| entered(once_job(move || {
            let f_opt = p0;
            let q = p1;
            match &f_opt {
                Some(b) => prism_rtl::Turn::Finished(Some(b.clone())),
                None => prism_rtl::Turn::More(Rc::new(FirstBinder { p_: q.clone() })),
            }
        }))) as Rc<dyn Fn((Option<Text>, lower::Pa)) -> Rc<dyn prism_rtl::Job<Option<Text>>>>)),
        _ => None,
    }
}

/// The step machine of `FirstBinder`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?FirstBinder: unbounded fn Pa -> ?Text
/// ```
pub struct FirstBinder {
    pub p_: lower::Pa,
}

impl prism_rtl::Job<Option<Text>> for FirstBinder {
    fn cycle(&self) -> prism_rtl::Turn<Option<Text>> {
        let p_ = &self.p_;
        match p_ {
            lower::Pa::PaBind(n) => prism_rtl::Turn::Finished(Some(n.clone())),
            lower::Pa::PaMut(n) => prism_rtl::Turn::Finished(Some(n.clone())),
            lower::Pa::PaTyped(q, _) => prism_rtl::Turn::More(Rc::new(FirstBinder { p_: (**q).clone() })),
            lower::Pa::PaCtor(_, ps) => fold_job(ps.clone(), None, Rc::new(move |(p0, p1): (Option<Text>, lower::Pa)| entered(once_job(move || {
                let f_opt = p0;
                let q = p1;
                match &f_opt {
                    Some(b) => prism_rtl::Turn::Finished(Some(b.clone())),
                    None => prism_rtl::Turn::More(Rc::new(FirstBinder { p_: q.clone() })),
                }
            }))) as Rc<dyn Fn((Option<Text>, lower::Pa)) -> Rc<dyn prism_rtl::Job<Option<Text>>>>).cycle(),
            lower::Pa::PaTuple(ps) => fold_job(ps.clone(), None, Rc::new(move |(p0, p1): (Option<Text>, lower::Pa)| entered(once_job(move || {
                let f_opt = p0;
                let q = p1;
                match &f_opt {
                    Some(b) => prism_rtl::Turn::Finished(Some(b.clone())),
                    None => prism_rtl::Turn::More(Rc::new(FirstBinder { p_: q.clone() })),
                }
            }))) as Rc<dyn Fn((Option<Text>, lower::Pa)) -> Rc<dyn prism_rtl::Job<Option<Text>>>>).cycle(),
            _ => prism_rtl::Turn::Finished(None),
        }
    }
}

/// `Start FirstBinder, x`: what the function value is when passed to `@Run`.
pub fn start_first_binder(p_: lower::Pa) -> Rc<dyn prism_rtl::Job<Option<Text>>> {
    Rc::new(FirstBinder { p_ })
}

/// ```prism
/// IsName: fn Pa -> Bool
/// ```
pub fn is_name(pa0: &lower::Pa) -> bool {
    match pa0 {
        lower::Pa::PaBind(_) => true,
        lower::Pa::PaMut(_) => true,
        other => false,
    }
}

/// ```prism
/// PatName: fn Pa -> Text
/// ```
pub fn pat_name(pa0: &lower::Pa) -> Text {
    match pa0 {
        lower::Pa::PaBind(n) => cpp_id(n),
        lower::Pa::PaMut(n) => cpp_id(n),
        other => Text::from("_"),
    }
}

/// ```prism
/// CppIfLet: unbounded fn Cp, Pa, Ex, [Do], [Do] -> Text
/// ```
pub fn cpp_if_let(cp0: &Cp, p_: &lower::Pa, x: &lower::Ex, t: &Array<lower::Do>, e: &Array<lower::Do>) -> Text {
    let cp = unbind(cp0, &pat_names(p_));
    let v_ = Text::from("_m");
    let head = Text::from(format!("if (auto&& _m = {}; {})", &cpp_expr(&cp, x), &conds(&pat_conds(&cp, p_, &v_))));
    let body = lexer::join(&append(&pat_binds(&cp, p_, &v_), &Array::from(vec![cpp_statements(&cp, t)])), &Text::from("\n"));
    Text::from(format!("{}{}", &cpp_templates::block(&head, &body), &cpp_else(&cp, e)))
}

/// The step machine of `CppIfLet`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppIfLet: unbounded fn Cp, Pa, Ex, [Do], [Do] -> Text
/// ```
pub struct CppIfLet {
    pub cp0: Cp,
    pub p_: lower::Pa,
    pub x: lower::Ex,
    pub t: Array<lower::Do>,
    pub e: Array<lower::Do>,
}

impl prism_rtl::Job<Text> for CppIfLet {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp0 = &self.cp0;
        let p_ = &self.p_;
        let x = &self.x;
        let t = &self.t;
        let e = &self.e;
        let cp0 = cp0.clone();
        let e = e.clone();
        let p_ = p_.clone();
        let t = t.clone();
        let x = x.clone();
        call_then(start_pat_names(p_.clone()), move |pat_names_51600: Array<Text>| {
            let cp = unbind(&cp0, &pat_names_51600);
            let v_ = Text::from("_m");
            call_then(start_cpp_expr(cp.clone(), x.clone()), move |cpp_expr_51662: Text| call_then(start_pat_conds(cp.clone(), p_.clone(), v_.clone()), move |pat_conds_51686: Array<Text>| {
                let head = Text::from(format!("if (auto&& _m = {}; {})", &cpp_expr_51662, &conds(&pat_conds_51686)));
                call_then(start_pat_binds(cp.clone(), p_.clone(), v_.clone()), move |pat_binds_51737: Array<Text>| call_then(start_cpp_statements(cp.clone(), t.clone()), move |cpp_statements_51760: Text| {
                    let body = lexer::join(&append(&pat_binds_51737, &Array::from(vec![cpp_statements_51760])), &Text::from("\n"));
                    call_then(start_cpp_else(cp.clone(), e.clone()), move |cpp_else_51814: Text| prism_rtl::Turn::Finished(Text::from(format!("{}{}", &cpp_templates::block(&head, &body), &cpp_else_51814))))
                }))
            }))
        })
    }
}

/// `Start CppIfLet, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_if_let(cp0: Cp, p_: lower::Pa, x: lower::Ex, t: Array<lower::Do>, e: Array<lower::Do>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppIfLet { cp0, p_, x, t, e })
}

/// ```prism
/// CppDoMatch: unbounded fn Cp, Ex, [((Pa, [Do]))] -> Text
/// ```
pub fn cpp_do_match(cp: &Cp, x: &lower::Ex, cases: &Array<(lower::Pa, Array<lower::Do>)>) -> Text {
    let v_ = Text::from("_m");
    let arms = run_to_end(each_job(cases.clone(), {
        let cp = cp.clone();
        let v_ = v_.clone();
        Rc::new(move |p0: (lower::Pa, Array<lower::Do>)| {
            let cp = cp.clone();
            let v_ = v_.clone();
            entered(once_job(move || {
                let (p_, body) = p0;
                call_then(start_pat_conds(cp.clone(), p_.clone(), v_.clone()), move |pat_conds_51994: Array<Text>| {
                    let tests = pat_conds_51994;
                    call_then(start_pat_binds(cp.clone(), p_.clone(), v_.clone()), move |pat_binds_52046: Array<Text>| call_then(start_cpp_statements(cp.clone(), body.clone()), move |cpp_statements_52069: Text| {
                        let inner = lexer::join(&append(&pat_binds_52046, &Array::from(vec![cpp_statements_52069])), &Text::from("\n"));
                        prism_rtl::Turn::Finished((tests.clone(), inner.clone()))
                    }))
                })
            }))
        }) as Rc<dyn Fn((lower::Pa, Array<lower::Do>)) -> Rc<dyn prism_rtl::Job<(Array<Text>, Text)>>>
    }));
    let blocks = each(&check_errors::range0(&len(&arms)), &(|i: &Nat| {
        let (tests, inner) = or(&index(&arms, i), &(Array::new(), Text::from("")));
        let head = if i == &Nat::from(0u32) {
            Text::from(format!("if ({})", &conds(&tests)))
        } else {
            if &len(&tests) == &Nat::from(0u32) {
                Text::from("else")
            } else {
                Text::from(format!("else if ({})", &conds(&tests)))
            }
        };
        cpp_templates::block(&head, &inner)
    }));
    cpp_templates::braced(&Text::from(format!("auto&& _m = {};\n{}", &cpp_expr(cp, x), &lexer::join(&blocks, &Text::from(" ")))))
}

/// The step machine of `CppDoMatch`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppDoMatch: unbounded fn Cp, Ex, [((Pa, [Do]))] -> Text
/// ```
pub struct CppDoMatch {
    pub cp: Cp,
    pub x: lower::Ex,
    pub cases: Array<(lower::Pa, Array<lower::Do>)>,
}

impl prism_rtl::Job<Text> for CppDoMatch {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let x = &self.x;
        let cases = &self.cases;
        let v_ = Text::from("_m");
        let cases = cases.clone();
        let cp = cp.clone();
        let x = x.clone();
        call_value(each_job(cases.clone(), {
            let cp = cp.clone();
            let v_ = v_.clone();
            Rc::new(move |p0: (lower::Pa, Array<lower::Do>)| {
                let cp = cp.clone();
                let v_ = v_.clone();
                entered(once_job(move || {
                    let (p_, body) = p0;
                    call_then(start_pat_conds(cp.clone(), p_.clone(), v_.clone()), move |pat_conds_51994: Array<Text>| {
                        let tests = pat_conds_51994;
                        call_then(start_pat_binds(cp.clone(), p_.clone(), v_.clone()), move |pat_binds_52046: Array<Text>| call_then(start_cpp_statements(cp.clone(), body.clone()), move |cpp_statements_52069: Text| {
                            let inner = lexer::join(&append(&pat_binds_52046, &Array::from(vec![cpp_statements_52069])), &Text::from("\n"));
                            prism_rtl::Turn::Finished((tests.clone(), inner.clone()))
                        }))
                    })
                }))
            }) as Rc<dyn Fn((lower::Pa, Array<lower::Do>)) -> Rc<dyn prism_rtl::Job<(Array<Text>, Text)>>>
        }), move |each_51947: Array<(Array<Text>, Text)>| {
            let arms = each_51947;
            let blocks = each(&check_errors::range0(&len(&arms)), &(|i: &Nat| {
                let (tests, inner) = or(&index(&arms, i), &(Array::new(), Text::from("")));
                let head = if i == &Nat::from(0u32) {
                    Text::from(format!("if ({})", &conds(&tests)))
                } else {
                    if &len(&tests) == &Nat::from(0u32) {
                        Text::from("else")
                    } else {
                        Text::from(format!("else if ({})", &conds(&tests)))
                    }
                };
                cpp_templates::block(&head, &inner)
            }));
            call_then(start_cpp_expr(cp.clone(), x.clone()), move |cpp_expr_52399: Text| prism_rtl::Turn::Finished(cpp_templates::braced(&Text::from(format!("auto&& _m = {};\n{}", &cpp_expr_52399, &lexer::join(&blocks, &Text::from(" ")))))))
        })
    }
}

/// `Start CppDoMatch, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_do_match(cp: Cp, x: lower::Ex, cases: Array<(lower::Pa, Array<lower::Do>)>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppDoMatch { cp, x, cases })
}

/// ```prism
/// CppFor: unbounded fn Cp, Pa, Ex, [Do] -> Text
/// ```
pub fn cpp_for(cp0: &Cp, p_: &lower::Pa, x: &lower::Ex, body: &Array<lower::Do>) -> Text {
    cpp_for_in(&unbind(cp0, &pat_names(p_)), p_, &cpp_expr(cp0, x), body)
}

/// The step machine of `CppFor`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppFor: unbounded fn Cp, Pa, Ex, [Do] -> Text
/// ```
pub struct CppFor {
    pub cp0: Cp,
    pub p_: lower::Pa,
    pub x: lower::Ex,
    pub body: Array<lower::Do>,
}

impl prism_rtl::Job<Text> for CppFor {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp0 = &self.cp0;
        let p_ = &self.p_;
        let x = &self.x;
        let body = &self.body;
        let body = body.clone();
        let cp0 = cp0.clone();
        let p_ = p_.clone();
        let x = x.clone();
        call_then(start_pat_names(p_.clone()), move |pat_names_52613: Array<Text>| call_then(start_cpp_expr(cp0.clone(), x.clone()), move |cpp_expr_52631: Text| prism_rtl::Turn::More(Rc::new(CppForIn { cp: unbind(&cp0, &pat_names_52613), p_: p_.clone(), xs: cpp_expr_52631, body: body.clone() }))))
    }
}

/// `Start CppFor, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_for(cp0: Cp, p_: lower::Pa, x: lower::Ex, body: Array<lower::Do>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppFor { cp0, p_, x, body })
}

/// ```prism
/// CppForIn: unbounded fn Cp, Pa, Text, [Do] -> Text
/// ```
pub fn cpp_for_in(cp: &Cp, p_: &lower::Pa, xs: &Text, body: &Array<lower::Do>) -> Text {
    match p_ {
        lower::Pa::PaBind(n) => cpp_templates::block(&Text::from(format!("for (auto&& {} : {})", &cpp_id(n), xs)), &cpp_statements(cp, body)),
        lower::Pa::PaMut(n) => cpp_templates::block(&Text::from(format!("for (auto {} : {})", &cpp_id(n), xs)), &cpp_statements(cp, body)),
        lower::Pa::PaTuple(ps) => if fold(ps, &true, &(|f: &bool, q: &lower::Pa| *f && is_name(q))) {
            cpp_templates::block(&Text::from(format!("for (auto&& [{}] : {})", &lexer::join(&each(ps, &(|q: &lower::Pa| pat_name(q))), &Text::from(", ")), xs)), &cpp_statements(cp, body))
        } else {
            cpp_templates::block(&Text::from(format!("for (auto&& _e : {})", xs)), &lexer::join(&append(&pat_binds(cp, p_, &Text::from("_e")), &Array::from(vec![cpp_statements(cp, body)])), &Text::from("\n")))
        },
        _ => cpp_templates::block(&Text::from(format!("for (auto&& _e : {})", xs)), &lexer::join(&append(&pat_binds(cp, p_, &Text::from("_e")), &Array::from(vec![cpp_statements(cp, body)])), &Text::from("\n"))),
    }
}

/// The step machine of `CppForIn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppForIn: unbounded fn Cp, Pa, Text, [Do] -> Text
/// ```
pub struct CppForIn {
    pub cp: Cp,
    pub p_: lower::Pa,
    pub xs: Text,
    pub body: Array<lower::Do>,
}

impl prism_rtl::Job<Text> for CppForIn {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let p_ = &self.p_;
        let xs = &self.xs;
        let body = &self.body;
        match p_ {
            lower::Pa::PaBind(n) => {
                let body = body.clone();
                let cp = cp.clone();
                let n = n.clone();
                let xs = xs.clone();
                call_then(start_cpp_statements(cp.clone(), body.clone()), move |cpp_statements_52797: Text| prism_rtl::Turn::Finished(cpp_templates::block(&Text::from(format!("for (auto&& {} : {})", &cpp_id(&n), &xs)), &cpp_statements_52797)))
            },
            lower::Pa::PaMut(n) => {
                let body = body.clone();
                let cp = cp.clone();
                let n = n.clone();
                let xs = xs.clone();
                call_then(start_cpp_statements(cp.clone(), body.clone()), move |cpp_statements_52872: Text| prism_rtl::Turn::Finished(cpp_templates::block(&Text::from(format!("for (auto {} : {})", &cpp_id(&n), &xs)), &cpp_statements_52872)))
            },
            lower::Pa::PaTuple(ps) => if fold(ps, &true, &(|f: &bool, q: &lower::Pa| *f && is_name(q))) {
                {
                    let body = body.clone();
                    let cp = cp.clone();
                    let ps = ps.clone();
                    let xs = xs.clone();
                    call_then(start_cpp_statements(cp.clone(), body.clone()), move |cpp_statements_53033: Text| prism_rtl::Turn::Finished(cpp_templates::block(&Text::from(format!("for (auto&& [{}] : {})", &lexer::join(&each(&ps, &(|q: &lower::Pa| pat_name(q))), &Text::from(", ")), &xs)), &cpp_statements_53033)))
                }
            } else {
                {
                    let body = body.clone();
                    let cp = cp.clone();
                    let p_ = p_.clone();
                    let xs = xs.clone();
                    call_then(start_pat_binds(cp.clone(), p_.clone(), Text::from("_e")), move |pat_binds_53118: Array<Text>| call_then(start_cpp_statements(cp.clone(), body.clone()), move |cpp_statements_53144: Text| prism_rtl::Turn::Finished(cpp_templates::block(&Text::from(format!("for (auto&& _e : {})", &xs)), &lexer::join(&append(&pat_binds_53118, &Array::from(vec![cpp_statements_53144])), &Text::from("\n"))))))
                }
            },
            _ => {
                let body = body.clone();
                let cp = cp.clone();
                let p_ = p_.clone();
                let xs = xs.clone();
                call_then(start_pat_binds(cp.clone(), p_.clone(), Text::from("_e")), move |pat_binds_53240: Array<Text>| call_then(start_cpp_statements(cp.clone(), body.clone()), move |cpp_statements_53266: Text| prism_rtl::Turn::Finished(cpp_templates::block(&Text::from(format!("for (auto&& _e : {})", &xs)), &lexer::join(&append(&pat_binds_53240, &Array::from(vec![cpp_statements_53266])), &Text::from("\n"))))))
            },
        }
    }
}

/// `Start CppForIn, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_for_in(cp: Cp, p_: lower::Pa, xs: Text, body: Array<lower::Do>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppForIn { cp, p_, xs, body })
}

/// ```prism
/// CppBody: unbounded fn Cp, Ex -> Text
/// ```
pub fn cpp_body(cp: &Cp, ex1: &lower::Ex) -> Text {
    match ex1 {
        lower::Ex::XBlock(dos, e) => {
            let (st, cp2) = cpp_statements_cp(cp, dos);
            if &len(dos) == &Nat::from(0u32) {
                cpp_body(cp, &**e)
            } else {
                Text::from(format!("{}\n{}", &st, &cpp_body(&cp2, &**e)))
            }
        },
        x => if leaves(x) {
            Text::from(format!("{};", &cpp_expr(cp, x)))
        } else {
            Text::from(format!("return {};", &cpp_expr(cp, x)))
        },
    }
}

/// The step machine of `CppBody`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppBody: unbounded fn Cp, Ex -> Text
/// ```
pub struct CppBody {
    pub cp: Cp,
    pub ex1: lower::Ex,
}

impl prism_rtl::Job<Text> for CppBody {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let ex1 = &self.ex1;
        match ex1 {
            lower::Ex::XBlock(dos, e) => {
                let cp = cp.clone();
                let dos = dos.clone();
                let e = (**e).clone();
                call_then(start_cpp_statements_cp(cp.clone(), dos.clone()), move |cpp_statements_cp_53454: (Text, Cp)| {
                    let (st, cp2) = cpp_statements_cp_53454;
                    if &len(&dos) == &Nat::from(0u32) {
                        prism_rtl::Turn::More(Rc::new(CppBody { cp: cp.clone(), ex1: e.clone() }))
                    } else {
                        call_then(start_cpp_body(cp2.clone(), e.clone()), move |cpp_body_53529: Text| prism_rtl::Turn::Finished(Text::from(format!("{}\n{}", &st, &cpp_body_53529))))
                    }
                })
            },
            x => if leaves(x) {
                {
                    let cp = cp.clone();
                    let x = x.clone();
                    call_then(start_cpp_expr(cp.clone(), x.clone()), move |cpp_expr_53580: Text| prism_rtl::Turn::Finished(Text::from(format!("{};", &cpp_expr_53580))))
                }
            } else {
                {
                    let cp = cp.clone();
                    let x = x.clone();
                    call_then(start_cpp_expr(cp.clone(), x.clone()), move |cpp_expr_53612: Text| prism_rtl::Turn::Finished(Text::from(format!("return {};", &cpp_expr_53612))))
                }
            },
        }
    }
}

/// `Start CppBody, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_body(cp: Cp, ex1: lower::Ex) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppBody { cp, ex1 })
}

/// ```prism
/// CppTemplateHead: fn [Text] -> Text
/// ```
pub fn cpp_template_head(xs0: &Array<Text>) -> Text {
    match xs0 {
        c0_0 if (c0_0.len() == 0) => Text::from(""),
        ps => Text::from(format!("template <{}>\n", &lexer::join(&each(ps, &(|p_: &Text| Text::from(format!("class {}", p_)))), &Text::from(", ")))),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// GenericNamesOf: fn [((Text, [Text]))] -> [Text]
/// ```
pub fn generic_names_of(gs: &Array<(Text, Array<Text>)>) -> Array<Text> {
    each(gs, &(|(g, _): &(Text, Array<Text>)| g.clone()))
}

/// ```prism
/// HeadOf: fn Text, [Text] -> Text
/// ```
pub fn head_of(name: &Text, xs1: &Array<Text>) -> Text {
    match xs1 {
        c0_1 if (c0_1.len() == 0) => name.clone(),
        ps => Text::from(format!("{}<{}>", name, &lexer::join(ps, &Text::from(", ")))),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// CppParams: unbounded fn Cp, [((Text, OutTy))] -> Text
/// ```
pub fn cpp_params(cp: &Cp, ps: &Array<(Text, lower::OutTy)>) -> Text {
    lexer::join(&run_to_end(each_job(ps.clone(), {
        let cp = cp.clone();
        Rc::new(move |p0: (Text, lower::OutTy)| {
            let cp = cp.clone();
            entered(once_job(move || {
                let (n, t) = p0;
                call_then(start_param_type(cp.clone(), t.clone()), move |param_type_54277: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {}", &param_type_54277, &cpp_id(&n)))))
            }))
        }) as Rc<dyn Fn((Text, lower::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>
    })), &Text::from(", "))
}

/// The step machine of `CppParams`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppParams: unbounded fn Cp, [((Text, OutTy))] -> Text
/// ```
pub struct CppParams {
    pub cp: Cp,
    pub ps: Array<(Text, lower::OutTy)>,
}

impl prism_rtl::Job<Text> for CppParams {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let ps = &self.ps;
        let cp = cp.clone();
        let ps = ps.clone();
        call_value(each_job(ps.clone(), {
            let cp = cp.clone();
            Rc::new(move |p0: (Text, lower::OutTy)| {
                let cp = cp.clone();
                entered(once_job(move || {
                    let (n, t) = p0;
                    call_then(start_param_type(cp.clone(), t.clone()), move |param_type_54277: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {}", &param_type_54277, &cpp_id(&n)))))
                }))
            }) as Rc<dyn Fn((Text, lower::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>
        }), move |each_54254: Array<Text>| prism_rtl::Turn::Finished(lexer::join(&each_54254, &Text::from(", "))))
    }
}

/// `Start CppParams, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_params(cp: Cp, ps: Array<(Text, lower::OutTy)>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppParams { cp, ps })
}

/// ```prism
/// FnSignature: unbounded fn Cp, FnDef -> Text
/// ```
pub fn fn_signature(cp: &Cp, f: &lower::FnDef) -> Text {
    Text::from(format!("{}{} {}({})", &cpp_template_head(&generic_names_of(&f.generics)), &cpp_type(cp, &f.ret), &cpp_id(&f.name), &cpp_params(cp, &f.params)))
}

/// The step machine of `FnSignature`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FnSignature: unbounded fn Cp, FnDef -> Text
/// ```
pub struct FnSignature {
    pub cp: Cp,
    pub f: lower::FnDef,
}

impl prism_rtl::Job<Text> for FnSignature {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let f = &self.f;
        let cp = cp.clone();
        let f = f.clone();
        call_then(start_cpp_type(cp.clone(), f.ret.clone()), move |cpp_type_54508: Text| call_then(start_cpp_params(cp.clone(), f.params.clone()), move |cpp_params_54543: Text| prism_rtl::Turn::Finished(Text::from(format!("{}{} {}({})", &cpp_template_head(&generic_names_of(&f.generics)), &cpp_type_54508, &cpp_id(&f.name), &cpp_params_54543)))))
    }
}

/// `Start FnSignature, x`: what the function value is when passed to `@Run`.
pub fn start_fn_signature(cp: Cp, f: lower::FnDef) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(FnSignature { cp, f })
}

/// ```prism
/// FnDefinition: unbounded fn Cp, FnDef -> Text
/// ```
pub fn fn_definition(cp: &Cp, f: &lower::FnDef) -> Text {
    cpp_templates::cpp_function(&cpp_doc(&f.doc), &fn_signature(cp, f), &cpp_body(cp, &f.body))
}

/// The step machine of `FnDefinition`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FnDefinition: unbounded fn Cp, FnDef -> Text
/// ```
pub struct FnDefinition {
    pub cp: Cp,
    pub f: lower::FnDef,
}

impl prism_rtl::Job<Text> for FnDefinition {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let f = &self.f;
        let cp = cp.clone();
        let f = f.clone();
        call_then(start_fn_signature(cp.clone(), f.clone()), move |fn_signature_54668: Text| call_then(start_cpp_body(cp.clone(), f.body.clone()), move |cpp_body_54689: Text| prism_rtl::Turn::Finished(cpp_templates::cpp_function(&cpp_doc(&f.doc), &fn_signature_54668, &cpp_body_54689))))
    }
}

/// `Start FnDefinition, x`: what the function value is when passed to `@Run`.
pub fn start_fn_definition(cp: Cp, f: lower::FnDef) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(FnDefinition { cp, f })
}

/// ```prism
/// ValueDeps: unbounded fn Cp, OutTy -> [Text]
/// ```
pub fn value_deps(cp: &Cp, t: &lower::OutTy) -> Array<Text> {
    match t {
        lower::OutTy::OutNamed(n, args) => {
            let own = match type_of(cp, n) {
                Some(info) => if (((&info.kind == &Text::from("record")) || (&info.kind == &Text::from("newtype"))) || (&info.kind == &Text::from("unit"))) || (&info.kind == &Text::from("tag")) {
                    Array::from(vec![absolute(cp, n)])
                } else {
                    Array::new()
                },
                None => Array::new(),
            };
            append(&own, &concat2(&run_to_end(each_job(args.clone(), {
                let cp = cp.clone();
                Rc::new(move |p0: lower::OutTy| {
                    let cp = cp.clone();
                    entered(once_job(move || {
                        let a = p0;
                        prism_rtl::Turn::More(Rc::new(ValueDeps { cp: cp.clone(), t: a.clone() }))
                    }))
                }) as Rc<dyn Fn(lower::OutTy) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
            }))))
        },
        lower::OutTy::OutOpt(i) => value_deps(cp, &**i),
        lower::OutTy::OutRes(i) => value_deps(cp, &**i),
        lower::OutTy::OutRc(i) => value_deps(cp, &**i),
        lower::OutTy::OutCell(i) => value_deps(cp, &**i),
        lower::OutTy::OutTuple(ts) => concat2(&run_to_end(each_job(ts.clone(), {
            let cp = cp.clone();
            Rc::new(move |p0: lower::OutTy| {
                let cp = cp.clone();
                entered(once_job(move || {
                    let a = p0;
                    prism_rtl::Turn::More(Rc::new(ValueDeps { cp: cp.clone(), t: a.clone() }))
                }))
            }) as Rc<dyn Fn(lower::OutTy) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
        }))),
        _ => Array::new(),
    }
}

/// The step machine of `ValueDeps`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ValueDeps: unbounded fn Cp, OutTy -> [Text]
/// ```
pub struct ValueDeps {
    pub cp: Cp,
    pub t: lower::OutTy,
}

impl prism_rtl::Job<Array<Text>> for ValueDeps {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let cp = &self.cp;
        let t = &self.t;
        match t {
            lower::OutTy::OutNamed(n, args) => {
                let own = match type_of(cp, n) {
                    Some(info) => if (((&info.kind == &Text::from("record")) || (&info.kind == &Text::from("newtype"))) || (&info.kind == &Text::from("unit"))) || (&info.kind == &Text::from("tag")) {
                        Array::from(vec![absolute(cp, n)])
                    } else {
                        Array::new()
                    },
                    None => Array::new(),
                };
                let args = args.clone();
                let cp = cp.clone();
                call_value(each_job(args.clone(), {
                    let cp = cp.clone();
                    Rc::new(move |p0: lower::OutTy| {
                        let cp = cp.clone();
                        entered(once_job(move || {
                            let a = p0;
                            prism_rtl::Turn::More(Rc::new(ValueDeps { cp: cp.clone(), t: a.clone() }))
                        }))
                    }) as Rc<dyn Fn(lower::OutTy) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
                }), move |each_55652: Array<Array<Text>>| prism_rtl::Turn::Finished(append(&own, &concat2(&each_55652))))
            },
            lower::OutTy::OutOpt(i) => prism_rtl::Turn::More(Rc::new(ValueDeps { cp: cp.clone(), t: (**i).clone() })),
            lower::OutTy::OutRes(i) => prism_rtl::Turn::More(Rc::new(ValueDeps { cp: cp.clone(), t: (**i).clone() })),
            lower::OutTy::OutRc(i) => prism_rtl::Turn::More(Rc::new(ValueDeps { cp: cp.clone(), t: (**i).clone() })),
            lower::OutTy::OutCell(i) => prism_rtl::Turn::More(Rc::new(ValueDeps { cp: cp.clone(), t: (**i).clone() })),
            lower::OutTy::OutTuple(ts) => {
                let cp = cp.clone();
                let ts = ts.clone();
                call_value(each_job(ts.clone(), {
                    let cp = cp.clone();
                    Rc::new(move |p0: lower::OutTy| {
                        let cp = cp.clone();
                        entered(once_job(move || {
                            let a = p0;
                            prism_rtl::Turn::More(Rc::new(ValueDeps { cp: cp.clone(), t: a.clone() }))
                        }))
                    }) as Rc<dyn Fn(lower::OutTy) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
                }), move |each_55832: Array<Array<Text>>| prism_rtl::Turn::Finished(concat2(&each_55832)))
            },
            _ => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start ValueDeps, x`: what the function value is when passed to `@Run`.
pub fn start_value_deps(cp: Cp, t: lower::OutTy) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(ValueDeps { cp, t })
}

/// ```prism
/// let noParts
/// ```
pub fn no_parts() -> Parts {
    Parts { forward: Array::new(), handles: Array::new(), values: Array::new(), cases: Array::new(), protos: Array::new(), classes: Array::new(), generic: Array::new(), defs: Array::new() }
}

/// ```prism
/// JoinParts: fn Parts, Parts -> Parts
/// ```
pub fn join_parts(a: &Parts, b: &Parts) -> Parts {
    Parts { forward: append(&a.forward, &b.forward), handles: append(&a.handles, &b.handles), values: append(&a.values, &b.values), cases: append(&a.cases, &b.cases), protos: append(&a.protos, &b.protos), classes: append(&a.classes, &b.classes), generic: append(&a.generic, &b.generic), defs: append(&a.defs, &b.defs) }
}

/// ```prism
/// ItemParts: unbounded fn Cp, Item -> Parts
/// ```
pub fn item_parts(cp: &Cp, it: &lower::Item) -> Parts {
    match it {
        lower::Item::ItType(t) => type_parts(cp, t),
        lower::Item::ItTag(t) => tag_parts(cp, t),
        lower::Item::ItRow(r) => row_parts(cp, &cp.home, r),
        lower::Item::ItFn(f) => fn_parts(cp, f),
        lower::Item::ItJob(j) => job_parts(cp, j),
        lower::Item::ItNode(n) => node_parts(cp, n),
        lower::Item::ItTrait(t) => trait_parts(cp, t),
        lower::Item::ItImpl(i) => impl_parts(cp, i),
        lower::Item::ItNote(t) => protos_defs(&Array::new(), &Array::from(vec![Text::from(format!("// {}", t))])),
        lower::Item::ItRefused(t) => protos_defs(&Array::new(), &Array::from(vec![Text::from(format!("compile_error!(\"{}{}\");", &lower::lowering_refusal(), &lower::escape(t)))])),
    }
}

/// The step machine of `ItemParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ItemParts: unbounded fn Cp, Item -> Parts
/// ```
pub struct ItemParts {
    pub cp: Cp,
    pub it: lower::Item,
}

impl prism_rtl::Job<Parts> for ItemParts {
    fn cycle(&self) -> prism_rtl::Turn<Parts> {
        let cp = &self.cp;
        let it = &self.it;
        match it {
            lower::Item::ItType(t) => prism_rtl::Turn::More(Rc::new(TypeParts { cp: cp.clone(), t: t.clone() })),
            lower::Item::ItTag(t) => prism_rtl::Turn::More(Rc::new(TagParts { cp: cp.clone(), t: t.clone() })),
            lower::Item::ItRow(r) => prism_rtl::Turn::More(Rc::new(RowParts { cp: cp.clone(), m: cp.home.clone(), r: r.clone() })),
            lower::Item::ItFn(f) => prism_rtl::Turn::More(Rc::new(FnParts { cp: cp.clone(), f: f.clone() })),
            lower::Item::ItJob(j) => prism_rtl::Turn::More(Rc::new(JobParts { cp: cp.clone(), j: j.clone() })),
            lower::Item::ItNode(n) => prism_rtl::Turn::More(Rc::new(NodeParts { cp: cp.clone(), n: n.clone() })),
            lower::Item::ItTrait(t) => prism_rtl::Turn::More(Rc::new(TraitParts { cp: cp.clone(), t: t.clone() })),
            lower::Item::ItImpl(i) => prism_rtl::Turn::More(Rc::new(ImplParts { cp: cp.clone(), i: i.clone() })),
            lower::Item::ItNote(t) => prism_rtl::Turn::Finished(protos_defs(&Array::new(), &Array::from(vec![Text::from(format!("// {}", t))]))),
            lower::Item::ItRefused(t) => prism_rtl::Turn::Finished(protos_defs(&Array::new(), &Array::from(vec![Text::from(format!("compile_error!(\"{}{}\");", &lower::lowering_refusal(), &lower::escape(t)))]))),
        }
    }
}

/// `Start ItemParts, x`: what the function value is when passed to `@Run`.
pub fn start_item_parts(cp: Cp, it: lower::Item) -> Rc<dyn prism_rtl::Job<Parts>> {
    Rc::new(ItemParts { cp, it })
}

/// ```prism
/// FnParts: unbounded fn Cp, FnDef -> Parts
/// ```
pub fn fn_parts(cp: &Cp, f: &lower::FnDef) -> Parts {
    if &len(&f.generics) > &Nat::from(0u32) {
        generic_only(&Array::from(vec![fn_definition(cp, f)]))
    } else {
        protos_defs(&Array::from(vec![Text::from(format!("{};", &fn_signature(cp, f)))]), &Array::from(vec![fn_definition(cp, f)]))
    }
}

/// The step machine of `FnParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FnParts: unbounded fn Cp, FnDef -> Parts
/// ```
pub struct FnParts {
    pub cp: Cp,
    pub f: lower::FnDef,
}

impl prism_rtl::Job<Parts> for FnParts {
    fn cycle(&self) -> prism_rtl::Turn<Parts> {
        let cp = &self.cp;
        let f = &self.f;
        if &len(&f.generics) > &Nat::from(0u32) {
            {
                let cp = cp.clone();
                let f = f.clone();
                call_then(start_fn_definition(cp.clone(), f.clone()), move |fn_definition_56916: Text| prism_rtl::Turn::Finished(generic_only(&Array::from(vec![fn_definition_56916]))))
            }
        } else {
            {
                let cp = cp.clone();
                let f = f.clone();
                call_then(start_fn_signature(cp.clone(), f.clone()), move |fn_signature_56963: Text| call_then(start_fn_definition(cp.clone(), f.clone()), move |fn_definition_56990: Text| prism_rtl::Turn::Finished(protos_defs(&Array::from(vec![Text::from(format!("{};", &fn_signature_56963))]), &Array::from(vec![fn_definition_56990])))))
            }
        }
    }
}

/// `Start FnParts, x`: what the function value is when passed to `@Run`.
pub fn start_fn_parts(cp: Cp, f: lower::FnDef) -> Rc<dyn prism_rtl::Job<Parts>> {
    Rc::new(FnParts { cp, f })
}

/// ```prism
/// CppDoc: fn Text -> Text
/// ```
pub fn cpp_doc(text: &Text) -> Text {
    if text == &Text::from("") {
        Text::from("")
    } else {
        concat(&each(&split(text, &Text::from("\n")), &(|l: &Text| if l == &Text::from("") {
            Text::from("///\n")
        } else {
            Text::from(format!("/// {}\n", l))
        })))
    }
}

/// ```prism
/// CppSourceDoc: fn Text, Text -> Text
/// ```
pub fn cpp_source_doc(lead: &Text, source: &Text) -> Text {
    let quoted = concat(&each(&split(source, &Text::from("\n")), &(|l: &Text| if l == &Text::from("") {
        Text::from("///\n")
    } else {
        Text::from(format!("/// {}\n", l))
    })));
    if source == &Text::from("") {
        cpp_doc(lead)
    } else {
        if lead == &Text::from("") {
            Text::from(format!("/// ```prism\n{}/// ```\n", &quoted))
        } else {
            Text::from(format!("/// {}\n///\n/// ```prism\n{}/// ```\n", lead, &quoted))
        }
    }
}

/// ```prism
/// TypeParts: unbounded fn Cp, TyDef -> Parts
/// ```
pub fn type_parts(cp: &Cp, t: &lower::TyDef) -> Parts {
    let eq = t.eq;
    let ord = t.ord && !t.floaty;
    let gens = cpp_template_head(&t.params);
    let head = head_of(&t.name, &t.params);
    let doc = cpp_source_doc(&Text::from(format!("`{}`:", &t.prism)), &t.doc);
    let members_ = members(&(&t.show != &lower::Shown::NotShown), &t.pod, &head);
    let generic = &len(&t.params) > &Nat::from(0u32);
    let fwd = Text::from(format!("{}{} {};", &gens, &(if &t.shape == &lower::TyShape::ShapeChoice {
        Text::from("class")
    } else {
        Text::from("struct")
    }), &t.name));
    match &t.shape {
        lower::TyShape::ShapeChoice => {
            let names = each(&t.cases, &(|c: &lower::CaseDef| c.name.clone()));
            let friend_eq = if eq && !generic {
                Text::from(format!("\nfriend inline bool operator==(const {}& a, const {}& b);", &head, &head))
            } else {
                Text::from("")
            };
            let handle = cpp_templates::choice_handle(&doc, &gens, &t.name, &lexer::join(&each(&names, &(|n: &Text| Text::from(format!("struct {};", n)))), &Text::from("\n")), &lexer::join(&names, &Text::from(", ")), &Text::from(format!("{}{}", &members_, &friend_eq)));
            let cases = run_to_end(each_job(t.cases.clone(), {
                let cp = cp.clone();
                let gens = gens.clone();
                let head = head.clone();
                let eq = eq;
                let ord = ord;
                Rc::new(move |p0: lower::CaseDef| {
                    let cp = cp.clone();
                    let gens = gens.clone();
                    let head = head.clone();
                    let eq = eq;
                    let ord = ord;
                    entered(once_job(move || {
                        let c = p0;
                        prism_rtl::Turn::More(Rc::new(CaseStruct { cp: cp.clone(), gens: gens.clone(), head: head.clone(), c: c.clone(), eq, ord }))
                    }))
                }) as Rc<dyn Fn(lower::CaseDef) -> Rc<dyn prism_rtl::Job<Text>>>
            }));
            let cmp = lexer::join(&filter(&Array::from(vec![if eq {
                Text::from(format!("{}inline bool operator==(const {}& a, const {}& b) {{ return a.cases() == b.cases(); }}", &gens, &head, &head))
            } else {
                Text::from("")
            }, if ord {
                Text::from(format!("{}inline auto operator<=>(const {}& a, const {}& b) {{ return a.cases() <=> b.cases(); }}", &gens, &head, &head))
            } else {
                Text::from("")
            }]), &(|s: &Text| s != &Text::from(""))), &Text::from("\n"));
            let defs = type_defs(cp, t, &head);
            Parts { forward: Array::from(vec![fwd.clone()]), handles: Array::from(vec![handle.clone()]), values: Array::new(), cases: append(&cases, &Array::from(vec![cases_accessor(&gens, &head), cmp.clone()])), protos: Array::new(), classes: Array::new(), generic: if generic { Array::from(vec![defs.clone()]) } else { Array::new() }, defs: if generic { Array::new() } else { Array::from(vec![defs.clone()]) } }
        },
        _ => {
            let first_ = or(&index(&t.cases, &Nat::from(0u32)), &lower::CaseDef { name: Text::from(""), prism: Text::from(""), fields: Array::new() });
            let fields = match &t.shape {
                lower::TyShape::ShapeRecord => lexer::join(&run_to_end(each_job(first_.fields.clone(), {
                    let cp = cp.clone();
                    Rc::new(move |p0: (Text, lower::OutTy)| {
                        let cp = cp.clone();
                        entered(once_job(move || {
                            let (f, ft) = p0;
                            call_then(start_cpp_type(cp.clone(), ft.clone()), move |cpp_type_59590: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {};", &cpp_type_59590, &field_id(&f)))))
                        }))
                    }) as Rc<dyn Fn((Text, lower::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>
                })), &Text::from("\n")),
                lower::TyShape::ShapeNewtype => positional_fields(cp, &first_.fields),
                _ => Text::from(""),
            };
            let cmps = lexer::join(&filter(&Array::from(vec![if eq {
                Text::from(format!("bool operator==(const {}&) const = default;", &t.name))
            } else {
                Text::from("")
            }, if ord {
                Text::from(format!("auto operator<=>(const {}&) const = default;", &t.name))
            } else {
                Text::from("")
            }]), &(|s: &Text| s != &Text::from(""))), &Text::from("\n"));
            let decl = cpp_templates::value_struct(&doc, &gens, &t.name, &fields, &lexer::join(&filter(&Array::from(vec![cmps.clone(), members_.clone()]), &(|s: &Text| s != &Text::from(""))), &Text::from("\n")));
            let defs = type_defs(cp, t, &head);
            let deps = concat2(&run_to_end(each_job(first_.fields.clone(), {
                let cp = cp.clone();
                Rc::new(move |p0: (Text, lower::OutTy)| {
                    let cp = cp.clone();
                    entered(once_job(move || {
                        let (_, ft) = p0;
                        prism_rtl::Turn::More(Rc::new(ValueDeps { cp: cp.clone(), t: ft.clone() }))
                    }))
                }) as Rc<dyn Fn((Text, lower::OutTy)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
            })));
            Parts { forward: Array::from(vec![fwd.clone()]), handles: Array::new(), values: Array::from(vec![ValueDecl { path_: Text::from(format!("{}::{}", &cp.home, &t.name)), deps: deps.clone(), text: decl.clone() }]), cases: Array::new(), protos: Array::new(), classes: Array::new(), generic: if generic { Array::from(vec![defs.clone()]) } else { Array::new() }, defs: if generic { Array::new() } else { Array::from(vec![defs.clone()]) } }
        },
    }
}

/// The step machine of `TypeParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TypeParts: unbounded fn Cp, TyDef -> Parts
/// ```
pub struct TypeParts {
    pub cp: Cp,
    pub t: lower::TyDef,
}

impl prism_rtl::Job<Parts> for TypeParts {
    fn cycle(&self) -> prism_rtl::Turn<Parts> {
        let cp = &self.cp;
        let t = &self.t;
        let eq = t.eq;
        let ord = t.ord && !t.floaty;
        let gens = cpp_template_head(&t.params);
        let head = head_of(&t.name, &t.params);
        let doc = cpp_source_doc(&Text::from(format!("`{}`:", &t.prism)), &t.doc);
        let members_ = members(&(&t.show != &lower::Shown::NotShown), &t.pod, &head);
        let generic = &len(&t.params) > &Nat::from(0u32);
        let fwd = Text::from(format!("{}{} {};", &gens, &(if &t.shape == &lower::TyShape::ShapeChoice {
            Text::from("class")
        } else {
            Text::from("struct")
        }), &t.name));
        match &t.shape {
            lower::TyShape::ShapeChoice => {
                let names = each(&t.cases, &(|c: &lower::CaseDef| c.name.clone()));
                let friend_eq = if eq && !generic {
                    Text::from(format!("\nfriend inline bool operator==(const {}& a, const {}& b);", &head, &head))
                } else {
                    Text::from("")
                };
                let handle = cpp_templates::choice_handle(&doc, &gens, &t.name, &lexer::join(&each(&names, &(|n: &Text| Text::from(format!("struct {};", n)))), &Text::from("\n")), &lexer::join(&names, &Text::from(", ")), &Text::from(format!("{}{}", &members_, &friend_eq)));
                let cp = cp.clone();
                let t = t.clone();
                call_value(each_job(t.cases.clone(), {
                    let cp = cp.clone();
                    let gens = gens.clone();
                    let head = head.clone();
                    let eq = eq;
                    let ord = ord;
                    Rc::new(move |p0: lower::CaseDef| {
                        let cp = cp.clone();
                        let gens = gens.clone();
                        let head = head.clone();
                        let eq = eq;
                        let ord = ord;
                        entered(once_job(move || {
                            let c = p0;
                            prism_rtl::Turn::More(Rc::new(CaseStruct { cp: cp.clone(), gens: gens.clone(), head: head.clone(), c: c.clone(), eq, ord }))
                        }))
                    }) as Rc<dyn Fn(lower::CaseDef) -> Rc<dyn prism_rtl::Job<Text>>>
                }), move |each_58739: Array<Text>| {
                    let cases = each_58739;
                    let cmp = lexer::join(&filter(&Array::from(vec![if eq {
                        Text::from(format!("{}inline bool operator==(const {}& a, const {}& b) {{ return a.cases() == b.cases(); }}", &gens, &head, &head))
                    } else {
                        Text::from("")
                    }, if ord {
                        Text::from(format!("{}inline auto operator<=>(const {}& a, const {}& b) {{ return a.cases() <=> b.cases(); }}", &gens, &head, &head))
                    } else {
                        Text::from("")
                    }]), &(|s: &Text| s != &Text::from(""))), &Text::from("\n"));
                    call_then(start_type_defs(cp.clone(), t.clone(), head.clone()), move |type_defs_59123: Text| {
                        let defs = type_defs_59123;
                        prism_rtl::Turn::Finished(Parts { forward: Array::from(vec![fwd.clone()]), handles: Array::from(vec![handle.clone()]), values: Array::new(), cases: append(&cases, &Array::from(vec![cases_accessor(&gens, &head), cmp.clone()])), protos: Array::new(), classes: Array::new(), generic: if generic { Array::from(vec![defs.clone()]) } else { Array::new() }, defs: if generic { Array::new() } else { Array::from(vec![defs.clone()]) } })
                    })
                })
            },
            _ => {
                let first_ = or(&index(&t.cases, &Nat::from(0u32)), &lower::CaseDef { name: Text::from(""), prism: Text::from(""), fields: Array::new() });
                let fields = match &t.shape {
                    lower::TyShape::ShapeRecord => lexer::join(&run_to_end(each_job(first_.fields.clone(), {
                        let cp = cp.clone();
                        Rc::new(move |p0: (Text, lower::OutTy)| {
                            let cp = cp.clone();
                            entered(once_job(move || {
                                let (f, ft) = p0;
                                call_then(start_cpp_type(cp.clone(), ft.clone()), move |cpp_type_59590: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {};", &cpp_type_59590, &field_id(&f)))))
                            }))
                        }) as Rc<dyn Fn((Text, lower::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>
                    })), &Text::from("\n")),
                    lower::TyShape::ShapeNewtype => positional_fields(cp, &first_.fields),
                    _ => Text::from(""),
                };
                let cmps = lexer::join(&filter(&Array::from(vec![if eq {
                    Text::from(format!("bool operator==(const {}&) const = default;", &t.name))
                } else {
                    Text::from("")
                }, if ord {
                    Text::from(format!("auto operator<=>(const {}&) const = default;", &t.name))
                } else {
                    Text::from("")
                }]), &(|s: &Text| s != &Text::from(""))), &Text::from("\n"));
                let decl = cpp_templates::value_struct(&doc, &gens, &t.name, &fields, &lexer::join(&filter(&Array::from(vec![cmps.clone(), members_.clone()]), &(|s: &Text| s != &Text::from(""))), &Text::from("\n")));
                let cp = cp.clone();
                let t = t.clone();
                call_then(start_type_defs(cp.clone(), t.clone(), head.clone()), move |type_defs_60064: Text| {
                    let defs = type_defs_60064;
                    call_value(each_job(first_.fields.clone(), {
                        let cp = cp.clone();
                        Rc::new(move |p0: (Text, lower::OutTy)| {
                            let cp = cp.clone();
                            entered(once_job(move || {
                                let (_, ft) = p0;
                                prism_rtl::Turn::More(Rc::new(ValueDeps { cp: cp.clone(), t: ft.clone() }))
                            }))
                        }) as Rc<dyn Fn((Text, lower::OutTy)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
                    }), move |each_60117: Array<Array<Text>>| {
                        let deps = concat2(&each_60117);
                        prism_rtl::Turn::Finished(Parts { forward: Array::from(vec![fwd.clone()]), handles: Array::new(), values: Array::from(vec![ValueDecl { path_: Text::from(format!("{}::{}", &cp.home, &t.name)), deps: deps.clone(), text: decl.clone() }]), cases: Array::new(), protos: Array::new(), classes: Array::new(), generic: if generic { Array::from(vec![defs.clone()]) } else { Array::new() }, defs: if generic { Array::new() } else { Array::from(vec![defs.clone()]) } })
                    })
                })
            },
        }
    }
}

/// `Start TypeParts, x`: what the function value is when passed to `@Run`.
pub fn start_type_parts(cp: Cp, t: lower::TyDef) -> Rc<dyn prism_rtl::Job<Parts>> {
    Rc::new(TypeParts { cp, t })
}

/// ```prism
/// CasesAccessor: fn Text, Text -> Text
/// ```
pub fn cases_accessor(gens: &Text, head: &Text) -> Text {
    Text::from(format!("{}inline const {}{}::Cases& {}::cases() const {{ return *cases_; }}", gens, &(if gens == &Text::from("") { Text::from("") } else { Text::from("typename ") }), head, head))
}

/// ```prism
/// Members: fn Bool, Bool, Text -> Text
/// ```
pub fn members(shown: &bool, pod: &bool, head: &Text) -> Text {
    let s = if *shown {
        Array::from(vec![Text::from("void show(Printer& p) const;")])
    } else {
        Array::new()
    };
    let d = if *pod {
        Array::from(vec![Text::from("Pod to_pod() const;"), Text::from(format!("static Result<{}> from_pod(const Pod& whole);", head))])
    } else {
        Array::new()
    };
    lexer::join(&append(&s, &d), &Text::from("\n"))
}

/// ```prism
/// CaseStruct: unbounded fn Cp, Text, Text, CaseDef, Bool, Bool -> Text
/// ```
pub fn case_struct(cp: &Cp, gens: &Text, head: &Text, c: &lower::CaseDef, eq: &bool, ord: &bool) -> Text {
    let fields = positional_fields(cp, &c.fields);
    let cmps = lexer::join(&filter(&Array::from(vec![if *eq {
        Text::from(format!("bool operator==(const {}&) const = default;", &c.name))
    } else {
        Text::from("")
    }, if *ord {
        Text::from(format!("auto operator<=>(const {}&) const = default;", &c.name))
    } else {
        Text::from("")
    }]), &(|s: &Text| s != &Text::from(""))), &Text::from("\n"));
    cpp_templates::case_decl(gens, &Text::from(format!("{}::{}", head, &c.name)), &lexer::join(&filter(&Array::from(vec![fields.clone(), cmps.clone()]), &(|s: &Text| s != &Text::from(""))), &Text::from("\n")))
}

/// The step machine of `CaseStruct`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CaseStruct: unbounded fn Cp, Text, Text, CaseDef, Bool, Bool -> Text
/// ```
pub struct CaseStruct {
    pub cp: Cp,
    pub gens: Text,
    pub head: Text,
    pub c: lower::CaseDef,
    pub eq: bool,
    pub ord: bool,
}

impl prism_rtl::Job<Text> for CaseStruct {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let gens = &self.gens;
        let head = &self.head;
        let c = &self.c;
        let eq = &self.eq;
        let ord = &self.ord;
        let c = c.clone();
        let cp = cp.clone();
        let eq = *eq;
        let gens = gens.clone();
        let head = head.clone();
        let ord = *ord;
        call_then(start_positional_fields(cp.clone(), c.fields.clone()), move |positional_fields_61132: Text| {
            let fields = positional_fields_61132;
            let cmps = lexer::join(&filter(&Array::from(vec![if eq {
                Text::from(format!("bool operator==(const {}&) const = default;", &c.name))
            } else {
                Text::from("")
            }, if ord {
                Text::from(format!("auto operator<=>(const {}&) const = default;", &c.name))
            } else {
                Text::from("")
            }]), &(|s: &Text| s != &Text::from(""))), &Text::from("\n"));
            prism_rtl::Turn::Finished(cpp_templates::case_decl(&gens, &Text::from(format!("{}::{}", &head, &c.name)), &lexer::join(&filter(&Array::from(vec![fields.clone(), cmps.clone()]), &(|s: &Text| s != &Text::from(""))), &Text::from("\n"))))
        })
    }
}

/// `Start CaseStruct, x`: what the function value is when passed to `@Run`.
pub fn start_case_struct(cp: Cp, gens: Text, head: Text, c: lower::CaseDef, eq: bool, ord: bool) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CaseStruct { cp, gens, head, c, eq, ord })
}

/// ```prism
/// TypeDefs: unbounded fn Cp, TyDef, Text -> Text
/// ```
pub fn type_defs(cp: &Cp, t: &lower::TyDef, head: &Text) -> Text {
    let gens = cpp_template_head(&t.params);
    let show_ = if &t.show == &lower::Shown::ShownDerived {
        Array::from(vec![show_def(cp, t, head, &gens)])
    } else {
        Array::new()
    };
    let pod = if t.pod {
        Array::from(vec![to_pod_def(cp, t, head, &gens), from_pod_def(cp, t, head, &gens)])
    } else {
        Array::new()
    };
    lexer::join(&append(&show_, &pod), &Text::from("\n"))
}

/// The step machine of `TypeDefs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TypeDefs: unbounded fn Cp, TyDef, Text -> Text
/// ```
pub struct TypeDefs {
    pub cp: Cp,
    pub t: lower::TyDef,
    pub head: Text,
}

impl prism_rtl::Job<Text> for TypeDefs {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let t = &self.t;
        let head = &self.head;
        let gens = cpp_template_head(&t.params);
        let show_ = if &t.show == &lower::Shown::ShownDerived {
            Array::from(vec![show_def(cp, t, head, &gens)])
        } else {
            Array::new()
        };
        let pod = if t.pod {
            Array::from(vec![to_pod_def(cp, t, head, &gens), from_pod_def(cp, t, head, &gens)])
        } else {
            Array::new()
        };
        prism_rtl::Turn::Finished(lexer::join(&append(&show_, &pod), &Text::from("\n")))
    }
}

/// `Start TypeDefs, x`: what the function value is when passed to `@Run`.
pub fn start_type_defs(cp: Cp, t: lower::TyDef, head: Text) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(TypeDefs { cp, t, head })
}

/// ```prism
/// ShowDef: unbounded fn Cp, TyDef, Text, Text -> Text
/// ```
pub fn show_def(cp: &Cp, t: &lower::TyDef, head: &Text, gens: &Text) -> Text {
    let body = match &t.shape {
        lower::TyShape::ShapeRecord => {
            let c = or(&index(&t.cases, &Nat::from(0u32)), &lower::CaseDef { name: Text::from(""), prism: Text::from(""), fields: Array::new() });
            Text::from(format!("p.record(\"{}\", {{{}}});", &t.prism, &lexer::join(&each(&c.fields, &(|(f, _): &(Text, lower::OutTy)| Text::from(format!("{{\"{}\", {}}}", &prism_field(f), &field_id(f))))), &Text::from(", "))))
        },
        lower::TyShape::ShapeChoice => lexer::join(&each(&check_errors::range0(&len(&t.cases)), &(|i: &Nat| show_case(t, i))), &Text::from("\n")),
        lower::TyShape::ShapeNewtype => Text::from(format!("p.choice(\"{}\", {{{}}});", &first_case(t), &lexer::join(&each(&check_errors::range0(&first_arity(t)), &(|k: &Nat| Text::from(format!("a{}", k)))), &Text::from(", ")))),
        lower::TyShape::ShapeUnit => Text::from(format!("p.choice(\"{}\", {{}});", &first_case(t))),
    };
    cpp_templates::cpp_function(&Text::from(""), &Text::from(format!("{}void {}::show(Printer& p) const", gens, head)), &body)
}

/// The step machine of `ShowDef`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ShowDef: unbounded fn Cp, TyDef, Text, Text -> Text
/// ```
pub struct ShowDef {
    pub cp: Cp,
    pub t: lower::TyDef,
    pub head: Text,
    pub gens: Text,
}

impl prism_rtl::Job<Text> for ShowDef {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let t = &self.t;
        let head = &self.head;
        let gens = &self.gens;
        let body = match &t.shape {
            lower::TyShape::ShapeRecord => {
                let c = or(&index(&t.cases, &Nat::from(0u32)), &lower::CaseDef { name: Text::from(""), prism: Text::from(""), fields: Array::new() });
                Text::from(format!("p.record(\"{}\", {{{}}});", &t.prism, &lexer::join(&each(&c.fields, &(|(f, _): &(Text, lower::OutTy)| Text::from(format!("{{\"{}\", {}}}", &prism_field(f), &field_id(f))))), &Text::from(", "))))
            },
            lower::TyShape::ShapeChoice => lexer::join(&each(&check_errors::range0(&len(&t.cases)), &(|i: &Nat| show_case(t, i))), &Text::from("\n")),
            lower::TyShape::ShapeNewtype => Text::from(format!("p.choice(\"{}\", {{{}}});", &first_case(t), &lexer::join(&each(&check_errors::range0(&first_arity(t)), &(|k: &Nat| Text::from(format!("a{}", k)))), &Text::from(", ")))),
            lower::TyShape::ShapeUnit => Text::from(format!("p.choice(\"{}\", {{}});", &first_case(t))),
        };
        prism_rtl::Turn::Finished(cpp_templates::cpp_function(&Text::from(""), &Text::from(format!("{}void {}::show(Printer& p) const", gens, head)), &body))
    }
}

/// `Start ShowDef, x`: what the function value is when passed to `@Run`.
pub fn start_show_def(cp: Cp, t: lower::TyDef, head: Text, gens: Text) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(ShowDef { cp, t, head, gens })
}

/// ```prism
/// ShowCase: fn TyDef, Nat -> Text
/// ```
pub fn show_case(t: &lower::TyDef, i: &Nat) -> Text {
    let c = or(&index(&t.cases, i), &lower::CaseDef { name: Text::from(""), prism: Text::from(""), fields: Array::new() });
    let head = Text::from(format!("{} (auto c = std::get_if<{}>(&cases()))", &(if i == &Nat::from(0u32) { Text::from("if") } else { Text::from("else if") }), &c.name));
    Text::from(format!("{} p.choice(\"{}\", {{{}}});", &head, &c.prism, &lexer::join(&each(&check_errors::range0(&len(&c.fields)), &(|k: &Nat| Text::from(format!("c->a{}", k)))), &Text::from(", "))))
}

/// ```prism
/// FirstCase: fn TyDef -> Text
/// ```
pub fn first_case(t: &lower::TyDef) -> Text {
    or(&index(&t.cases, &Nat::from(0u32)), &lower::CaseDef { name: Text::from(""), prism: t.prism.clone(), fields: Array::new() }).prism.clone()
}

/// ```prism
/// FirstArity: fn TyDef -> Nat
/// ```
pub fn first_arity(t: &lower::TyDef) -> Nat {
    len(&or(&index(&t.cases, &Nat::from(0u32)), &lower::CaseDef { name: Text::from(""), prism: Text::from(""), fields: Array::new() }).fields)
}

/// ```prism
/// FieldTypes: fn [((Text, OutTy))] -> [OutTy]
/// ```
pub fn field_types(fs: &Array<(Text, lower::OutTy)>) -> Array<lower::OutTy> {
    each(fs, &(|(_, t): &(Text, lower::OutTy)| t.clone()))
}

/// ```prism
/// PositionalFields: unbounded fn Cp, [((Text, OutTy))] -> Text
/// ```
pub fn positional_fields(cp: &Cp, fs: &Array<(Text, lower::OutTy)>) -> Text {
    let tys = field_types(fs);
    lexer::join(&run_to_end(each_job(check_errors::range0(&len(&tys)), {
        let cp = cp.clone();
        let tys = tys.clone();
        Rc::new(move |p0: Nat| {
            let cp = cp.clone();
            let tys = tys.clone();
            entered(once_job(move || {
                let i = p0;
                call_then(start_cpp_type(cp.clone(), or(&index(&tys, &i), &lower::OutTy::OutUnit)), move |cpp_type_63390: Text| prism_rtl::Turn::Finished(Text::from(format!("{} a{};", &cpp_type_63390, &i))))
            }))
        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Text>>>
    })), &Text::from("\n"))
}

/// The step machine of `PositionalFields`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PositionalFields: unbounded fn Cp, [((Text, OutTy))] -> Text
/// ```
pub struct PositionalFields {
    pub cp: Cp,
    pub fs: Array<(Text, lower::OutTy)>,
}

impl prism_rtl::Job<Text> for PositionalFields {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let fs = &self.fs;
        let tys = field_types(fs);
        let cp = cp.clone();
        call_value(each_job(check_errors::range0(&len(&tys)), {
            let cp = cp.clone();
            let tys = tys.clone();
            Rc::new(move |p0: Nat| {
                let cp = cp.clone();
                let tys = tys.clone();
                entered(once_job(move || {
                    let i = p0;
                    call_then(start_cpp_type(cp.clone(), or(&index(&tys, &i), &lower::OutTy::OutUnit)), move |cpp_type_63390: Text| prism_rtl::Turn::Finished(Text::from(format!("{} a{};", &cpp_type_63390, &i))))
                }))
            }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Text>>>
        }), move |each_63358: Array<Text>| prism_rtl::Turn::Finished(lexer::join(&each_63358, &Text::from("\n"))))
    }
}

/// `Start PositionalFields, x`: what the function value is when passed to `@Run`.
pub fn start_positional_fields(cp: Cp, fs: Array<(Text, lower::OutTy)>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(PositionalFields { cp, fs })
}

/// ```prism
/// ToPodDef: unbounded fn Cp, TyDef, Text, Text -> Text
/// ```
pub fn to_pod_def(cp: &Cp, t: &lower::TyDef, head: &Text, gens: &Text) -> Text {
    let structure = match &t.shape {
        lower::TyShape::ShapeRecord => {
            let c = or(&index(&t.cases, &Nat::from(0u32)), &lower::CaseDef { name: Text::from(""), prism: Text::from(""), fields: Array::new() });
            Text::from(format!("Pod::record(\"{}\", {{{}}})", &t.prism, &lexer::join(&each(&c.fields, &(|(f, _): &(Text, lower::OutTy)| Text::from(format!("{{\"{}\", prism_rtl::to_pod({})}}", &prism_field(f), &field_id(f))))), &Text::from(", "))))
        },
        lower::TyShape::ShapeChoice => choice_pod(t),
        lower::TyShape::ShapeNewtype => Text::from(format!("Pod::choice(\"{}\", {{{}}})", &first_case(t), &lexer::join(&each(&check_errors::range0(&first_arity(t)), &(|k: &Nat| Text::from(format!("prism_rtl::to_pod(a{})", k)))), &Text::from(", ")))),
        lower::TyShape::ShapeUnit => Text::from(format!("Pod::choice(\"{}\", {{}})", &first_case(t))),
    };
    let body = if &t.show == &lower::Shown::ShownOwn {
        Text::from(format!("Pod structure = {};\nreturn Pod::shown(prism_rtl::show(*this), structure);", &structure))
    } else {
        Text::from(format!("return {};", &structure))
    };
    cpp_templates::cpp_function(&Text::from(""), &Text::from(format!("{}Pod {}::to_pod() const", gens, head)), &body)
}

/// The step machine of `ToPodDef`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ToPodDef: unbounded fn Cp, TyDef, Text, Text -> Text
/// ```
pub struct ToPodDef {
    pub cp: Cp,
    pub t: lower::TyDef,
    pub head: Text,
    pub gens: Text,
}

impl prism_rtl::Job<Text> for ToPodDef {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let t = &self.t;
        let head = &self.head;
        let gens = &self.gens;
        let structure = match &t.shape {
            lower::TyShape::ShapeRecord => {
                let c = or(&index(&t.cases, &Nat::from(0u32)), &lower::CaseDef { name: Text::from(""), prism: Text::from(""), fields: Array::new() });
                Text::from(format!("Pod::record(\"{}\", {{{}}})", &t.prism, &lexer::join(&each(&c.fields, &(|(f, _): &(Text, lower::OutTy)| Text::from(format!("{{\"{}\", prism_rtl::to_pod({})}}", &prism_field(f), &field_id(f))))), &Text::from(", "))))
            },
            lower::TyShape::ShapeChoice => choice_pod(t),
            lower::TyShape::ShapeNewtype => Text::from(format!("Pod::choice(\"{}\", {{{}}})", &first_case(t), &lexer::join(&each(&check_errors::range0(&first_arity(t)), &(|k: &Nat| Text::from(format!("prism_rtl::to_pod(a{})", k)))), &Text::from(", ")))),
            lower::TyShape::ShapeUnit => Text::from(format!("Pod::choice(\"{}\", {{}})", &first_case(t))),
        };
        let body = if &t.show == &lower::Shown::ShownOwn {
            Text::from(format!("Pod structure = {};\nreturn Pod::shown(prism_rtl::show(*this), structure);", &structure))
        } else {
            Text::from(format!("return {};", &structure))
        };
        prism_rtl::Turn::Finished(cpp_templates::cpp_function(&Text::from(""), &Text::from(format!("{}Pod {}::to_pod() const", gens, head)), &body))
    }
}

/// `Start ToPodDef, x`: what the function value is when passed to `@Run`.
pub fn start_to_pod_def(cp: Cp, t: lower::TyDef, head: Text, gens: Text) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(ToPodDef { cp, t, head, gens })
}

/// ```prism
/// ChoicePod: fn TyDef -> Text
/// ```
pub fn choice_pod(t: &lower::TyDef) -> Text {
    let arms = each(&check_errors::range0(&len(&t.cases)), &(|i: &Nat| {
        let c = or(&index(&t.cases, i), &lower::CaseDef { name: Text::from(""), prism: Text::from(""), fields: Array::new() });
        Text::from(format!("std::holds_alternative<{}>(cases()) ? Pod::choice(\"{}\", {{{}}})", &c.name, &c.prism, &lexer::join(&each(&check_errors::range0(&len(&c.fields)), &(|k: &Nat| Text::from(format!("prism_rtl::to_pod(std::get<{}>(cases()).a{})", &c.name, k)))), &Text::from(", "))))
    }));
    Text::from(format!("{}\n    : Pod()", &lexer::join(&arms, &Text::from("\n    : "))))
}

/// ```prism
/// FromPodDef: unbounded fn Cp, TyDef, Text, Text -> Text
/// ```
pub fn from_pod_def(cp: &Cp, t: &lower::TyDef, head: &Text, gens: &Text) -> Text {
    let body = match &t.shape {
        lower::TyShape::ShapeRecord => {
            let c = or(&index(&t.cases, &Nat::from(0u32)), &lower::CaseDef { name: Text::from(""), prism: Text::from(""), fields: Array::new() });
            let reads = lexer::join(&run_to_end(each_job(c.fields.clone(), {
                let cp = cp.clone();
                Rc::new(move |p0: (Text, lower::OutTy)| {
                    let cp = cp.clone();
                    entered(once_job(move || {
                        let (f, ft) = p0;
                        call_then(start_cpp_type(cp.clone(), ft.clone()), move |cpp_type_64962: Text| prism_rtl::Turn::Finished(Text::from(format!(".{} = TRY(prism_rtl::from_pod<{}>(TRY(prelude::field(whole, \"{}\"))))", &field_id(&f), &cpp_type_64962, &prism_field(&f)))))
                    }))
                }) as Rc<dyn Fn((Text, lower::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>
            })), &Text::from(", "));
            Text::from(format!("return {}{{{}}};", head, &reads))
        },
        _ => {
            let arms = run_to_end(each_job(t.cases.clone(), {
                let cp = cp.clone();
                let t = t.clone();
                let head = head.clone();
                Rc::new(move |p0: lower::CaseDef| {
                    let cp = cp.clone();
                    let t = t.clone();
                    let head = head.clone();
                    entered(once_job(move || {
                        let c = p0;
                        {
                            let n = len(&c.fields);
                            let tys = field_types(&c.fields);
                            call_value(each_job(check_errors::range0(&n), {
                                let cp = cp.clone();
                                let tys = tys.clone();
                                Rc::new(move |p0: Nat| {
                                    let cp = cp.clone();
                                    let tys = tys.clone();
                                    entered(once_job(move || {
                                        let i = p0;
                                        call_then(start_cpp_type(cp.clone(), or(&index(&tys, &i), &lower::OutTy::OutUnit)), move |cpp_type_65301: Text| prism_rtl::Turn::Finished(Text::from(format!("TRY(prism_rtl::from_pod<{}>(c->args[{}]))", &cpp_type_65301, &i))))
                                    }))
                                }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Text>>>
                            }), move |each_65253: Array<Text>| {
                                let args = lexer::join(&each_65253, &Text::from(", "));
                                let made = match &t.shape {
                                    lower::TyShape::ShapeChoice => Text::from(format!("{}({}{{{}}})", &head, &c.name, &args)),
                                    _ => Text::from(format!("{}{{{}}}", &head, &args)),
                                };
                                prism_rtl::Turn::Finished(Text::from(format!("if (c->ctor == \"{}\" && c->args.size() == {}) return {};", &c.prism, &n, &made)))
                            })
                        }
                    }))
                }) as Rc<dyn Fn(lower::CaseDef) -> Rc<dyn prism_rtl::Job<Text>>>
            }));
            Text::from(format!("const Pod& p = whole.structure();\nif (auto c = p.if_choice()) {{\n{}\n}}\nreturn mismatch<{}>(\"a {}\", p);", &indent_cpp(&lexer::join(&arms, &Text::from("\n"))), head, &t.prism))
        },
    };
    cpp_templates::cpp_function(&Text::from(""), &Text::from(format!("{}Result<{}> {}::from_pod(const Pod& whole)", gens, head, head)), &body)
}

/// The step machine of `FromPodDef`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FromPodDef: unbounded fn Cp, TyDef, Text, Text -> Text
/// ```
pub struct FromPodDef {
    pub cp: Cp,
    pub t: lower::TyDef,
    pub head: Text,
    pub gens: Text,
}

impl prism_rtl::Job<Text> for FromPodDef {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let t = &self.t;
        let head = &self.head;
        let gens = &self.gens;
        let body = match &t.shape {
            lower::TyShape::ShapeRecord => {
                let c = or(&index(&t.cases, &Nat::from(0u32)), &lower::CaseDef { name: Text::from(""), prism: Text::from(""), fields: Array::new() });
                let reads = lexer::join(&run_to_end(each_job(c.fields.clone(), {
                    let cp = cp.clone();
                    Rc::new(move |p0: (Text, lower::OutTy)| {
                        let cp = cp.clone();
                        entered(once_job(move || {
                            let (f, ft) = p0;
                            call_then(start_cpp_type(cp.clone(), ft.clone()), move |cpp_type_64962: Text| prism_rtl::Turn::Finished(Text::from(format!(".{} = TRY(prism_rtl::from_pod<{}>(TRY(prelude::field(whole, \"{}\"))))", &field_id(&f), &cpp_type_64962, &prism_field(&f)))))
                        }))
                    }) as Rc<dyn Fn((Text, lower::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>
                })), &Text::from(", "));
                Text::from(format!("return {}{{{}}};", head, &reads))
            },
            _ => {
                let arms = run_to_end(each_job(t.cases.clone(), {
                    let cp = cp.clone();
                    let t = t.clone();
                    let head = head.clone();
                    Rc::new(move |p0: lower::CaseDef| {
                        let cp = cp.clone();
                        let t = t.clone();
                        let head = head.clone();
                        entered(once_job(move || {
                            let c = p0;
                            {
                                let n = len(&c.fields);
                                let tys = field_types(&c.fields);
                                call_value(each_job(check_errors::range0(&n), {
                                    let cp = cp.clone();
                                    let tys = tys.clone();
                                    Rc::new(move |p0: Nat| {
                                        let cp = cp.clone();
                                        let tys = tys.clone();
                                        entered(once_job(move || {
                                            let i = p0;
                                            call_then(start_cpp_type(cp.clone(), or(&index(&tys, &i), &lower::OutTy::OutUnit)), move |cpp_type_65301: Text| prism_rtl::Turn::Finished(Text::from(format!("TRY(prism_rtl::from_pod<{}>(c->args[{}]))", &cpp_type_65301, &i))))
                                        }))
                                    }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Text>>>
                                }), move |each_65253: Array<Text>| {
                                    let args = lexer::join(&each_65253, &Text::from(", "));
                                    let made = match &t.shape {
                                        lower::TyShape::ShapeChoice => Text::from(format!("{}({}{{{}}})", &head, &c.name, &args)),
                                        _ => Text::from(format!("{}{{{}}}", &head, &args)),
                                    };
                                    prism_rtl::Turn::Finished(Text::from(format!("if (c->ctor == \"{}\" && c->args.size() == {}) return {};", &c.prism, &n, &made)))
                                })
                            }
                        }))
                    }) as Rc<dyn Fn(lower::CaseDef) -> Rc<dyn prism_rtl::Job<Text>>>
                }));
                Text::from(format!("const Pod& p = whole.structure();\nif (auto c = p.if_choice()) {{\n{}\n}}\nreturn mismatch<{}>(\"a {}\", p);", &indent_cpp(&lexer::join(&arms, &Text::from("\n"))), head, &t.prism))
            },
        };
        prism_rtl::Turn::Finished(cpp_templates::cpp_function(&Text::from(""), &Text::from(format!("{}Result<{}> {}::from_pod(const Pod& whole)", gens, head, head)), &body))
    }
}

/// `Start FromPodDef, x`: what the function value is when passed to `@Run`.
pub fn start_from_pod_def(cp: Cp, t: lower::TyDef, head: Text, gens: Text) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(FromPodDef { cp, t, head, gens })
}

/// ```prism
/// PrismField: fn Text -> Text
/// ```
pub fn prism_field(f: &Text) -> Text {
    if &lexer::last_char(f) == &Text::from("_") {
        lexer::before_last(f)
    } else {
        f.clone()
    }
}

/// ```prism
/// IndentCpp: fn Text -> Text
/// ```
pub fn indent_cpp(t: &Text) -> Text {
    lexer::join(&each(&split(t, &Text::from("\n")), &(|l: &Text| if l == &Text::from("") { Text::from("") } else { Text::from(format!("    {}", l)) })), &Text::from("\n"))
}

/// ```prism
/// TagParts: unbounded fn Cp, TagDef -> Parts
/// ```
pub fn tag_parts(cp: &Cp, t: &lower::TagDef) -> Parts {
    let fields = lexer::join(&run_to_end(each_job(t.fields.clone(), {
        let cp = cp.clone();
        Rc::new(move |p0: (Text, Text, lower::OutTy)| {
            let cp = cp.clone();
            entered(once_job(move || {
                let (_, f, ft) = p0;
                call_then(start_cpp_type(cp.clone(), ft.clone()), move |cpp_type_66327: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {};", &cpp_type_66327, &field_id(&f)))))
            }))
        }) as Rc<dyn Fn((Text, Text, lower::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>
    })), &Text::from("\n"));
    let pods = lexer::join(&each(&t.fields, &(|(p_, f, _): &(Text, Text, lower::OutTy)| Text::from(format!("{{\"{}\", prism_rtl::to_pod({})}}", p_, &field_id(f))))), &Text::from(", "));
    let reads = lexer::join(&run_to_end(each_job(t.fields.clone(), {
        let cp = cp.clone();
        Rc::new(move |p0: (Text, Text, lower::OutTy)| {
            let cp = cp.clone();
            entered(once_job(move || {
                let (p_, f, ft) = p0;
                call_then(start_cpp_type(cp.clone(), ft.clone()), move |cpp_type_66567: Text| prism_rtl::Turn::Finished(Text::from(format!(".{} = TRY(prism_rtl::from_pod<{}>(TRY(prelude::field(p, \"{}\"))))", &field_id(&f), &cpp_type_66567, &p_))))
            }))
        }) as Rc<dyn Fn((Text, Text, lower::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>
    })), &Text::from(", "));
    let eq = if t.pod {
        Text::from(format!("bool operator==(const {}&) const = default;", &t.name))
    } else {
        Text::from("")
    };
    let back_ = if t.pod {
        Text::from(format!("static Result<{}> from_pod(const Pod& p);", &t.name))
    } else {
        Text::from("")
    };
    let decl = cpp_templates::cpp_tag_struct(&cpp_source_doc(&Text::from(format!("The `Level` of `{}`:", &t.tag_name)), &t.doc), &t.name, &fields, &t.tag_name, &lexer::join(&filter(&Array::from(vec![eq.clone(), back_.clone()]), &(|s: &Text| s != &Text::from(""))), &Text::from("\n")));
    let to_pod = cpp_templates::cpp_function(&Text::from(""), &Text::from(format!("Pod {}::to_pod() const", &t.name)), &Text::from(format!("return Pod::element(TAG, {{{}}});", &pods)));
    let show_ = cpp_templates::cpp_function(&Text::from(""), &Text::from(format!("void {}::show(Printer& p) const", &t.name)), &Text::from("prism_rtl::to_pod(*this).structure();\nShow<Pod>::show(prism_rtl::to_pod(*this), p);"));
    let from_pod = if t.pod {
        Array::from(vec![cpp_templates::cpp_function(&Text::from(""), &Text::from(format!("Result<{}> {}::from_pod(const Pod& p)", &t.name, &t.name)), &Text::from(format!("if (auto t = p.tag(); t && *t == TAG) return {}{{{}}};\nreturn mismatch<{}>(\"a {}\", p);", &t.name, &reads, &t.name, &t.tag_name)))])
    } else {
        Array::new()
    };
    let deps = concat2(&run_to_end(each_job(t.fields.clone(), {
        let cp = cp.clone();
        Rc::new(move |p0: (Text, Text, lower::OutTy)| {
            let cp = cp.clone();
            entered(once_job(move || {
                let (_, _, ft) = p0;
                prism_rtl::Turn::More(Rc::new(ValueDeps { cp: cp.clone(), t: ft.clone() }))
            }))
        }) as Rc<dyn Fn((Text, Text, lower::OutTy)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
    })));
    Parts { forward: Array::from(vec![Text::from(format!("struct {};", &t.name))]), handles: Array::new(), values: Array::from(vec![ValueDecl { path_: Text::from(format!("{}::{}", &cp.home, &t.name)), deps: deps.clone(), text: decl.clone() }]), cases: Array::new(), protos: Array::new(), classes: Array::new(), generic: Array::new(), defs: append(&Array::from(vec![to_pod.clone(), show_.clone()]), &from_pod) }
}

/// The step machine of `TagParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TagParts: unbounded fn Cp, TagDef -> Parts
/// ```
pub struct TagParts {
    pub cp: Cp,
    pub t: lower::TagDef,
}

impl prism_rtl::Job<Parts> for TagParts {
    fn cycle(&self) -> prism_rtl::Turn<Parts> {
        let cp = &self.cp;
        let t = &self.t;
        let cp = cp.clone();
        let t = t.clone();
        call_value(each_job(t.fields.clone(), {
            let cp = cp.clone();
            Rc::new(move |p0: (Text, Text, lower::OutTy)| {
                let cp = cp.clone();
                entered(once_job(move || {
                    let (_, f, ft) = p0;
                    call_then(start_cpp_type(cp.clone(), ft.clone()), move |cpp_type_66327: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {};", &cpp_type_66327, &field_id(&f)))))
                }))
            }) as Rc<dyn Fn((Text, Text, lower::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>
        }), move |each_66289: Array<Text>| {
            let fields = lexer::join(&each_66289, &Text::from("\n"));
            let pods = lexer::join(&each(&t.fields, &(|(p_, f, _): &(Text, Text, lower::OutTy)| Text::from(format!("{{\"{}\", prism_rtl::to_pod({})}}", p_, &field_id(f))))), &Text::from(", "));
            call_value(each_job(t.fields.clone(), {
                let cp = cp.clone();
                Rc::new(move |p0: (Text, Text, lower::OutTy)| {
                    let cp = cp.clone();
                    entered(once_job(move || {
                        let (p_, f, ft) = p0;
                        call_then(start_cpp_type(cp.clone(), ft.clone()), move |cpp_type_66567: Text| prism_rtl::Turn::Finished(Text::from(format!(".{} = TRY(prism_rtl::from_pod<{}>(TRY(prelude::field(p, \"{}\"))))", &field_id(&f), &cpp_type_66567, &p_))))
                    }))
                }) as Rc<dyn Fn((Text, Text, lower::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>
            }), move |each_66495: Array<Text>| {
                let reads = lexer::join(&each_66495, &Text::from(", "));
                let eq = if t.pod {
                    Text::from(format!("bool operator==(const {}&) const = default;", &t.name))
                } else {
                    Text::from("")
                };
                let back_ = if t.pod {
                    Text::from(format!("static Result<{}> from_pod(const Pod& p);", &t.name))
                } else {
                    Text::from("")
                };
                let decl = cpp_templates::cpp_tag_struct(&cpp_source_doc(&Text::from(format!("The `Level` of `{}`:", &t.tag_name)), &t.doc), &t.name, &fields, &t.tag_name, &lexer::join(&filter(&Array::from(vec![eq.clone(), back_.clone()]), &(|s: &Text| s != &Text::from(""))), &Text::from("\n")));
                let to_pod = cpp_templates::cpp_function(&Text::from(""), &Text::from(format!("Pod {}::to_pod() const", &t.name)), &Text::from(format!("return Pod::element(TAG, {{{}}});", &pods)));
                let show_ = cpp_templates::cpp_function(&Text::from(""), &Text::from(format!("void {}::show(Printer& p) const", &t.name)), &Text::from("prism_rtl::to_pod(*this).structure();\nShow<Pod>::show(prism_rtl::to_pod(*this), p);"));
                let from_pod = if t.pod {
                    Array::from(vec![cpp_templates::cpp_function(&Text::from(""), &Text::from(format!("Result<{}> {}::from_pod(const Pod& p)", &t.name, &t.name)), &Text::from(format!("if (auto t = p.tag(); t && *t == TAG) return {}{{{}}};\nreturn mismatch<{}>(\"a {}\", p);", &t.name, &reads, &t.name, &t.tag_name)))])
                } else {
                    Array::new()
                };
                call_value(each_job(t.fields.clone(), {
                    let cp = cp.clone();
                    Rc::new(move |p0: (Text, Text, lower::OutTy)| {
                        let cp = cp.clone();
                        entered(once_job(move || {
                            let (_, _, ft) = p0;
                            prism_rtl::Turn::More(Rc::new(ValueDeps { cp: cp.clone(), t: ft.clone() }))
                        }))
                    }) as Rc<dyn Fn((Text, Text, lower::OutTy)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
                }), move |each_67472: Array<Array<Text>>| {
                    let deps = concat2(&each_67472);
                    prism_rtl::Turn::Finished(Parts { forward: Array::from(vec![Text::from(format!("struct {};", &t.name))]), handles: Array::new(), values: Array::from(vec![ValueDecl { path_: Text::from(format!("{}::{}", &cp.home, &t.name)), deps: deps.clone(), text: decl.clone() }]), cases: Array::new(), protos: Array::new(), classes: Array::new(), generic: Array::new(), defs: append(&Array::from(vec![to_pod.clone(), show_.clone()]), &from_pod) })
                })
            })
        })
    }
}

/// `Start TagParts, x`: what the function value is when passed to `@Run`.
pub fn start_tag_parts(cp: Cp, t: lower::TagDef) -> Rc<dyn prism_rtl::Job<Parts>> {
    Rc::new(TagParts { cp, t })
}

/// ```prism
/// RowParts: unbounded fn Cp, Text, RowDef -> Parts
/// ```
pub fn row_parts(cp: &Cp, m: &Text, r: &lower::RowDef) -> Parts {
    let names = each(&r.cases, &(|(v_, _): &(Text, Text)| v_.clone()));
    let pod = Text::from(format!("Pod to_pod() const;\nvoid show(Printer& p) const;{}", &(if r.pod {
        Text::from(format!("\nstatic Result<{}> from_pod(const Pod& p);", &r.name))
    } else {
        Text::from("")
    })));
    let handle = cpp_templates::choice_handle(&cpp_source_doc(&Text::from(format!("`{}`, a row kind's values:", &r.prism)), &r.doc), &Text::from(""), &r.name, &lexer::join(&each(&names, &(|n: &Text| Text::from(format!("struct {};", n)))), &Text::from("\n")), &lexer::join(&names, &Text::from(", ")), &pod);
    let cases = each(&r.cases, &(|(v_, st): &(Text, Text)| cpp_templates::case_decl(&Text::from(""), &Text::from(format!("{}::{}", &r.name, v_)), &Text::from(format!("{} a0;{}", &row_struct(m, st), &(if r.pod {
        Text::from(format!("\nbool operator==(const {}&) const = default;", v_))
    } else {
        Text::from("")
    }))))));
    let eq = if r.pod {
        Array::from(vec![Text::from(format!("inline bool operator==(const {}& a, const {}& b) {{ return a.cases() == b.cases(); }}", &r.name, &r.name))])
    } else {
        Array::new()
    };
    let to_pod = cpp_templates::cpp_function(&Text::from(""), &Text::from(format!("Pod {}::to_pod() const", &r.name)), &Text::from("return std::visit([](const auto& c) { return prism_rtl::to_pod(c.a0); }, cases());"));
    let show_ = cpp_templates::cpp_function(&Text::from(""), &Text::from(format!("void {}::show(Printer& p) const", &r.name)), &Text::from("Show<Pod>::show(to_pod(), p);"));
    let reads = lexer::join(&each(&r.cases, &(|(v_, st): &(Text, Text)| Text::from(format!("if (*t == {}::TAG) return {}({}{{TRY(prism_rtl::from_pod<{}>(p))}});", &row_struct(m, st), &r.name, v_, &row_struct(m, st))))), &Text::from("\n"));
    let from_pod = if r.pod {
        Array::from(vec![cpp_templates::cpp_function(&Text::from(""), &Text::from(format!("Result<{}> {}::from_pod(const Pod& p)", &r.name, &r.name)), &Text::from(format!("if (auto t = p.tag()) {{\n{}\n}}\nreturn mismatch<{}>(\"a {}\", p);", &indent_cpp(&reads), &r.name, &r.name)))])
    } else {
        Array::new()
    };
    Parts { forward: Array::from(vec![Text::from(format!("class {};", &r.name))]), handles: Array::from(vec![handle.clone()]), values: Array::new(), cases: append(&push(&cases, &cases_accessor(&Text::from(""), &r.name)), &eq), protos: Array::new(), classes: Array::new(), generic: Array::new(), defs: append(&Array::from(vec![to_pod.clone(), show_.clone()]), &from_pod) }
}

/// The step machine of `RowParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RowParts: unbounded fn Cp, Text, RowDef -> Parts
/// ```
pub struct RowParts {
    pub cp: Cp,
    pub m: Text,
    pub r: lower::RowDef,
}

impl prism_rtl::Job<Parts> for RowParts {
    fn cycle(&self) -> prism_rtl::Turn<Parts> {
        let cp = &self.cp;
        let m = &self.m;
        let r = &self.r;
        let names = each(&r.cases, &(|(v_, _): &(Text, Text)| v_.clone()));
        let pod = Text::from(format!("Pod to_pod() const;\nvoid show(Printer& p) const;{}", &(if r.pod {
            Text::from(format!("\nstatic Result<{}> from_pod(const Pod& p);", &r.name))
        } else {
            Text::from("")
        })));
        let handle = cpp_templates::choice_handle(&cpp_source_doc(&Text::from(format!("`{}`, a row kind's values:", &r.prism)), &r.doc), &Text::from(""), &r.name, &lexer::join(&each(&names, &(|n: &Text| Text::from(format!("struct {};", n)))), &Text::from("\n")), &lexer::join(&names, &Text::from(", ")), &pod);
        let cases = each(&r.cases, &(|(v_, st): &(Text, Text)| cpp_templates::case_decl(&Text::from(""), &Text::from(format!("{}::{}", &r.name, v_)), &Text::from(format!("{} a0;{}", &row_struct(m, st), &(if r.pod {
            Text::from(format!("\nbool operator==(const {}&) const = default;", v_))
        } else {
            Text::from("")
        }))))));
        let eq = if r.pod {
            Array::from(vec![Text::from(format!("inline bool operator==(const {}& a, const {}& b) {{ return a.cases() == b.cases(); }}", &r.name, &r.name))])
        } else {
            Array::new()
        };
        let to_pod = cpp_templates::cpp_function(&Text::from(""), &Text::from(format!("Pod {}::to_pod() const", &r.name)), &Text::from("return std::visit([](const auto& c) { return prism_rtl::to_pod(c.a0); }, cases());"));
        let show_ = cpp_templates::cpp_function(&Text::from(""), &Text::from(format!("void {}::show(Printer& p) const", &r.name)), &Text::from("Show<Pod>::show(to_pod(), p);"));
        let reads = lexer::join(&each(&r.cases, &(|(v_, st): &(Text, Text)| Text::from(format!("if (*t == {}::TAG) return {}({}{{TRY(prism_rtl::from_pod<{}>(p))}});", &row_struct(m, st), &r.name, v_, &row_struct(m, st))))), &Text::from("\n"));
        let from_pod = if r.pod {
            Array::from(vec![cpp_templates::cpp_function(&Text::from(""), &Text::from(format!("Result<{}> {}::from_pod(const Pod& p)", &r.name, &r.name)), &Text::from(format!("if (auto t = p.tag()) {{\n{}\n}}\nreturn mismatch<{}>(\"a {}\", p);", &indent_cpp(&reads), &r.name, &r.name)))])
        } else {
            Array::new()
        };
        prism_rtl::Turn::Finished(Parts { forward: Array::from(vec![Text::from(format!("class {};", &r.name))]), handles: Array::from(vec![handle.clone()]), values: Array::new(), cases: append(&push(&cases, &cases_accessor(&Text::from(""), &r.name)), &eq), protos: Array::new(), classes: Array::new(), generic: Array::new(), defs: append(&Array::from(vec![to_pod.clone(), show_.clone()]), &from_pod) })
    }
}

/// `Start RowParts, x`: what the function value is when passed to `@Run`.
pub fn start_row_parts(cp: Cp, m: Text, r: lower::RowDef) -> Rc<dyn prism_rtl::Job<Parts>> {
    Rc::new(RowParts { cp, m, r })
}

/// ```prism
/// RowStruct: fn Text, Text -> Text
/// ```
pub fn row_struct(m: &Text, st: &Text) -> Text {
    if lexer::contains(st, &Text::from(":")) || (m == &Text::from("")) {
        type_path(st)
    } else {
        Text::from(format!("crate::{}::{}", m, st))
    }
}

/// ```prism
/// AnswerParts: unbounded fn Cp, AnswerDef -> Parts
/// ```
pub fn answer_parts(cp: &Cp, a: &lower::AnswerDef) -> Parts {
    let names = each(&a.cases, &(|c: &lower::AnswerCase| c.variant.clone()));
    let accessors = lexer::join(&run_to_end(each_job(a.cases.clone(), {
        let cp = cp.clone();
        Rc::new(move |p0: lower::AnswerCase| {
            let cp = cp.clone();
            entered(once_job(move || {
                let c = p0;
                call_then(start_cpp_type(cp.clone(), c.ty.clone()), move |cpp_type_69985: Text| prism_rtl::Turn::Finished(Text::from(format!("Result<{}> {}() const;", &cpp_type_69985, &c.accessor))))
            }))
        }) as Rc<dyn Fn(lower::AnswerCase) -> Rc<dyn prism_rtl::Job<Text>>>
    })), &Text::from("\n"));
    let members_ = Text::from(format!("const char* tag() const;\n{}\nstatic Result<Answer> decode(const Elem& e, const Pod& v);", &accessors));
    let handle = cpp_templates::choice_handle(&cpp_doc(&Text::from("`Answer c`: an answer to an element, typed by its tag (Semantics ch. 9): what a host's\nsupplier answers a child place with, and what a World's answer to a forwarded element\ndecodes to, carrying the tag's output.")), &Text::from(""), &Text::from("Answer"), &lexer::join(&each(&names, &(|n: &Text| Text::from(format!("struct {};", n)))), &Text::from("\n")), &lexer::join(&names, &Text::from(", ")), &members_);
    let cases = run_to_end(each_job(a.cases.clone(), {
        let cp = cp.clone();
        Rc::new(move |p0: lower::AnswerCase| {
            let cp = cp.clone();
            entered(once_job(move || {
                let c = p0;
                call_then(start_cpp_type(cp.clone(), c.ty.clone()), move |cpp_type_70570: Text| prism_rtl::Turn::Finished(cpp_templates::case_decl(&Text::from(""), &Text::from(format!("Answer::{}", &c.variant)), &Text::from(format!("{} a0;", &cpp_type_70570)))))
            }))
        }) as Rc<dyn Fn(lower::AnswerCase) -> Rc<dyn prism_rtl::Job<Text>>>
    }));
    let tags = lexer::join(&each(&a.cases, &(|c: &lower::AnswerCase| Text::from(format!("if (std::holds_alternative<{}>(cases())) return {}::TAG;", &c.variant, &type_path(&c.struct_path))))), &Text::from("\n"));
    let tag_fn = cpp_templates::cpp_function(&Text::from(""), &Text::from("const char* Answer::tag() const"), &Text::from(format!("{}\nprism_rtl::unreachable();", &tags)));
    let getters = run_to_end(each_job(a.cases.clone(), {
        let cp = cp.clone();
        Rc::new(move |p0: lower::AnswerCase| {
            let cp = cp.clone();
            entered(once_job(move || {
                let c = p0;
                call_then(start_cpp_type(cp.clone(), c.ty.clone()), move |cpp_type_70928: Text| prism_rtl::Turn::Finished(cpp_templates::cpp_function(&cpp_doc(&Text::from(format!("A `{}`'s answer.", &c.tag_name))), &Text::from(format!("Result<{}> Answer::{}() const", &cpp_type_70928, &c.accessor)), &Text::from(format!("if (auto c = std::get_if<{}>(&cases())) return c->a0;\nreturn unexpected(Fault::answer(str(\"an answer for \", tag(), \", where {}'s was expected\")));", &c.variant, &c.tag_name)))))
            }))
        }) as Rc<dyn Fn(lower::AnswerCase) -> Rc<dyn prism_rtl::Job<Text>>>
    }));
    let decodes = lexer::join(&run_to_end(each_job(a.cases.clone(), {
        let cp = cp.clone();
        Rc::new(move |p0: lower::AnswerCase| {
            let cp = cp.clone();
            entered(once_job(move || {
                let c = p0;
                call_then(start_cpp_type(cp.clone(), c.ty.clone()), move |cpp_type_71276: Text| prism_rtl::Turn::Finished(Text::from(format!("if (is<Elem::{}>(e)) return Answer({}{{TRY(prism_rtl::from_pod<{}>(v))}});", &c.variant, &c.variant, &cpp_type_71276))))
            }))
        }) as Rc<dyn Fn(lower::AnswerCase) -> Rc<dyn prism_rtl::Job<Text>>>
    })), &Text::from("\n"));
    let decode = cpp_templates::cpp_function(&cpp_doc(&Text::from("A World's answer to the element `e`, decoded by its tag.")), &Text::from("Result<Answer> Answer::decode(const Elem& e, const Pod& v)"), &Text::from(format!("{}\nprism_rtl::unreachable();", &decodes)));
    Parts { forward: Array::from(vec![Text::from("class Answer;")]), handles: Array::from(vec![handle.clone()]), values: Array::new(), cases: push(&cases, &cases_accessor(&Text::from(""), &Text::from("Answer"))), protos: Array::new(), classes: Array::new(), generic: Array::new(), defs: append(&Array::from(vec![tag_fn.clone()]), &push(&getters, &decode)) }
}

/// The step machine of `AnswerParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// AnswerParts: unbounded fn Cp, AnswerDef -> Parts
/// ```
pub struct AnswerParts {
    pub cp: Cp,
    pub a: lower::AnswerDef,
}

impl prism_rtl::Job<Parts> for AnswerParts {
    fn cycle(&self) -> prism_rtl::Turn<Parts> {
        let cp = &self.cp;
        let a = &self.a;
        let names = each(&a.cases, &(|c: &lower::AnswerCase| c.variant.clone()));
        let a = a.clone();
        let cp = cp.clone();
        call_value(each_job(a.cases.clone(), {
            let cp = cp.clone();
            Rc::new(move |p0: lower::AnswerCase| {
                let cp = cp.clone();
                entered(once_job(move || {
                    let c = p0;
                    call_then(start_cpp_type(cp.clone(), c.ty.clone()), move |cpp_type_69985: Text| prism_rtl::Turn::Finished(Text::from(format!("Result<{}> {}() const;", &cpp_type_69985, &c.accessor))))
                }))
            }) as Rc<dyn Fn(lower::AnswerCase) -> Rc<dyn prism_rtl::Job<Text>>>
        }), move |each_69957: Array<Text>| {
            let accessors = lexer::join(&each_69957, &Text::from("\n"));
            let members_ = Text::from(format!("const char* tag() const;\n{}\nstatic Result<Answer> decode(const Elem& e, const Pod& v);", &accessors));
            let handle = cpp_templates::choice_handle(&cpp_doc(&Text::from("`Answer c`: an answer to an element, typed by its tag (Semantics ch. 9): what a host's\nsupplier answers a child place with, and what a World's answer to a forwarded element\ndecodes to, carrying the tag's output.")), &Text::from(""), &Text::from("Answer"), &lexer::join(&each(&names, &(|n: &Text| Text::from(format!("struct {};", n)))), &Text::from("\n")), &lexer::join(&names, &Text::from(", ")), &members_);
            call_value(each_job(a.cases.clone(), {
                let cp = cp.clone();
                Rc::new(move |p0: lower::AnswerCase| {
                    let cp = cp.clone();
                    entered(once_job(move || {
                        let c = p0;
                        call_then(start_cpp_type(cp.clone(), c.ty.clone()), move |cpp_type_70570: Text| prism_rtl::Turn::Finished(cpp_templates::case_decl(&Text::from(""), &Text::from(format!("Answer::{}", &c.variant)), &Text::from(format!("{} a0;", &cpp_type_70570)))))
                    }))
                }) as Rc<dyn Fn(lower::AnswerCase) -> Rc<dyn prism_rtl::Job<Text>>>
            }), move |each_70513: Array<Text>| {
                let cases = each_70513;
                let tags = lexer::join(&each(&a.cases, &(|c: &lower::AnswerCase| Text::from(format!("if (std::holds_alternative<{}>(cases())) return {}::TAG;", &c.variant, &type_path(&c.struct_path))))), &Text::from("\n"));
                let tag_fn = cpp_templates::cpp_function(&Text::from(""), &Text::from("const char* Answer::tag() const"), &Text::from(format!("{}\nprism_rtl::unreachable();", &tags)));
                call_value(each_job(a.cases.clone(), {
                    let cp = cp.clone();
                    Rc::new(move |p0: lower::AnswerCase| {
                        let cp = cp.clone();
                        entered(once_job(move || {
                            let c = p0;
                            call_then(start_cpp_type(cp.clone(), c.ty.clone()), move |cpp_type_70928: Text| prism_rtl::Turn::Finished(cpp_templates::cpp_function(&cpp_doc(&Text::from(format!("A `{}`'s answer.", &c.tag_name))), &Text::from(format!("Result<{}> Answer::{}() const", &cpp_type_70928, &c.accessor)), &Text::from(format!("if (auto c = std::get_if<{}>(&cases())) return c->a0;\nreturn unexpected(Fault::answer(str(\"an answer for \", tag(), \", where {}'s was expected\")));", &c.variant, &c.tag_name)))))
                        }))
                    }) as Rc<dyn Fn(lower::AnswerCase) -> Rc<dyn prism_rtl::Job<Text>>>
                }), move |each_70850: Array<Text>| {
                    let getters = each_70850;
                    call_value(each_job(a.cases.clone(), {
                        let cp = cp.clone();
                        Rc::new(move |p0: lower::AnswerCase| {
                            let cp = cp.clone();
                            entered(once_job(move || {
                                let c = p0;
                                call_then(start_cpp_type(cp.clone(), c.ty.clone()), move |cpp_type_71276: Text| prism_rtl::Turn::Finished(Text::from(format!("if (is<Elem::{}>(e)) return Answer({}{{TRY(prism_rtl::from_pod<{}>(v))}});", &c.variant, &c.variant, &cpp_type_71276))))
                            }))
                        }) as Rc<dyn Fn(lower::AnswerCase) -> Rc<dyn prism_rtl::Job<Text>>>
                    }), move |each_71174: Array<Text>| {
                        let decodes = lexer::join(&each_71174, &Text::from("\n"));
                        let decode = cpp_templates::cpp_function(&cpp_doc(&Text::from("A World's answer to the element `e`, decoded by its tag.")), &Text::from("Result<Answer> Answer::decode(const Elem& e, const Pod& v)"), &Text::from(format!("{}\nprism_rtl::unreachable();", &decodes)));
                        prism_rtl::Turn::Finished(Parts { forward: Array::from(vec![Text::from("class Answer;")]), handles: Array::from(vec![handle.clone()]), values: Array::new(), cases: push(&cases, &cases_accessor(&Text::from(""), &Text::from("Answer"))), protos: Array::new(), classes: Array::new(), generic: Array::new(), defs: append(&Array::from(vec![tag_fn.clone()]), &push(&getters, &decode)) })
                    })
                })
            })
        })
    }
}

/// `Start AnswerParts, x`: what the function value is when passed to `@Run`.
pub fn start_answer_parts(cp: Cp, a: lower::AnswerDef) -> Rc<dyn prism_rtl::Job<Parts>> {
    Rc::new(AnswerParts { cp, a })
}

/// ```prism
/// JobParts: unbounded fn Cp, JobDef -> Parts
/// ```
pub fn job_parts(cp: &Cp, j: &lower::JobDef) -> Parts {
    let gens = cpp_template_head(&generic_names_of(&j.generics));
    let head = head_of(&j.name, &generic_names_of(&j.generics));
    let jcp = with_fields(cp, &j.fields);
    let fields = lexer::join(&run_to_end(each_job(j.fields.clone(), {
        let cp = cp.clone();
        Rc::new(move |p0: (Text, lower::OutTy)| {
            let cp = cp.clone();
            entered(once_job(move || {
                let (n, t) = p0;
                call_then(start_cpp_type(cp.clone(), t.clone()), move |cpp_type_72055: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {};", &cpp_type_72055, &field_id(&n)))))
            }))
        }) as Rc<dyn Fn((Text, lower::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>
    })), &Text::from("\n"));
    let params = lexer::join(&run_to_end(each_job(j.fields.clone(), {
        let cp = cp.clone();
        Rc::new(move |p0: (Text, lower::OutTy)| {
            let cp = cp.clone();
            entered(once_job(move || {
                let (n, t) = p0;
                call_then(start_cpp_type(cp.clone(), t.clone()), move |cpp_type_72143: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {}", &cpp_type_72143, &field_id(&n)))))
            }))
        }) as Rc<dyn Fn((Text, lower::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>
    })), &Text::from(", "));
    let inits = lexer::join(&each(&j.fields, &(|(n, _): &(Text, lower::OutTy)| Text::from(format!("{}(std::move({}))", &field_id(n), &field_id(n))))), &Text::from(", "));
    let ctor = if &len(&j.fields) == &Nat::from(0u32) {
        Text::from("")
    } else {
        Text::from(format!("{}({}) : {} {{}}", &j.name, &params, &inits))
    };
    let ret = cpp_type(cp, &j.ret);
    let decl = cpp_templates::job_struct(&cpp_doc(&j.doc), &gens, &j.name, &ret, &fields, &ctor);
    let cycle = cpp_templates::cpp_function(&Text::from(""), &Text::from(format!("{}prism_rtl::Turn<{}> {}::cycle() const", &gens, &ret, &head)), &cpp_body(&jcp, &j.body));
    let start = cpp_templates::cpp_function(&cpp_doc(&Text::from(format!("`Start {}, x`: what the function value is when passed to `@Run`.", &j.name))), &Text::from(format!("{}prism_rtl::JobRef<{}> {}({})", &gens, &ret, &j.start, &params)), &Text::from(format!("return std::make_shared<{}>({});", &head, &lexer::join(&each(&j.fields, &(|(n, _): &(Text, lower::OutTy)| field_id(n))), &Text::from(", ")))));
    let generic = &len(&j.generics) > &Nat::from(0u32);
    Parts { forward: Array::from(vec![Text::from(format!("{}struct {};", &gens, &j.name))]), handles: Array::new(), values: Array::new(), cases: Array::new(), protos: if generic {
        Array::new()
    } else {
        Array::from(vec![Text::from(format!("prism_rtl::JobRef<{}> {}({});", &ret, &j.start, &params))])
    }, classes: Array::from(vec![decl.clone()]), generic: if generic { Array::from(vec![cycle.clone(), start.clone()]) } else { Array::new() }, defs: if generic { Array::new() } else { Array::from(vec![cycle.clone(), start.clone()]) } }
}

/// The step machine of `JobParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// JobParts: unbounded fn Cp, JobDef -> Parts
/// ```
pub struct JobParts {
    pub cp: Cp,
    pub j: lower::JobDef,
}

impl prism_rtl::Job<Parts> for JobParts {
    fn cycle(&self) -> prism_rtl::Turn<Parts> {
        let cp = &self.cp;
        let j = &self.j;
        let gens = cpp_template_head(&generic_names_of(&j.generics));
        let head = head_of(&j.name, &generic_names_of(&j.generics));
        let jcp = with_fields(cp, &j.fields);
        let cp = cp.clone();
        let j = j.clone();
        call_value(each_job(j.fields.clone(), {
            let cp = cp.clone();
            Rc::new(move |p0: (Text, lower::OutTy)| {
                let cp = cp.clone();
                entered(once_job(move || {
                    let (n, t) = p0;
                    call_then(start_cpp_type(cp.clone(), t.clone()), move |cpp_type_72055: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {};", &cpp_type_72055, &field_id(&n)))))
                }))
            }) as Rc<dyn Fn((Text, lower::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>
        }), move |each_72026: Array<Text>| {
            let fields = lexer::join(&each_72026, &Text::from("\n"));
            call_value(each_job(j.fields.clone(), {
                let cp = cp.clone();
                Rc::new(move |p0: (Text, lower::OutTy)| {
                    let cp = cp.clone();
                    entered(once_job(move || {
                        let (n, t) = p0;
                        call_then(start_cpp_type(cp.clone(), t.clone()), move |cpp_type_72143: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {}", &cpp_type_72143, &field_id(&n)))))
                    }))
                }) as Rc<dyn Fn((Text, lower::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>
            }), move |each_72114: Array<Text>| {
                let params = lexer::join(&each_72114, &Text::from(", "));
                let inits = lexer::join(&each(&j.fields, &(|(n, _): &(Text, lower::OutTy)| Text::from(format!("{}(std::move({}))", &field_id(n), &field_id(n))))), &Text::from(", "));
                let ctor = if &len(&j.fields) == &Nat::from(0u32) {
                    Text::from("")
                } else {
                    Text::from(format!("{}({}) : {} {{}}", &j.name, &params, &inits))
                };
                call_then(start_cpp_type(cp.clone(), j.ret.clone()), move |cpp_type_72375: Text| {
                    let ret = cpp_type_72375;
                    let decl = cpp_templates::job_struct(&cpp_doc(&j.doc), &gens, &j.name, &ret, &fields, &ctor);
                    call_then(start_cpp_body(jcp.clone(), j.body.clone()), move |cpp_body_72553: Text| {
                        let cycle = cpp_templates::cpp_function(&Text::from(""), &Text::from(format!("{}prism_rtl::Turn<{}> {}::cycle() const", &gens, &ret, &head)), &cpp_body_72553);
                        let start = cpp_templates::cpp_function(&cpp_doc(&Text::from(format!("`Start {}, x`: what the function value is when passed to `@Run`.", &j.name))), &Text::from(format!("{}prism_rtl::JobRef<{}> {}({})", &gens, &ret, &j.start, &params)), &Text::from(format!("return std::make_shared<{}>({});", &head, &lexer::join(&each(&j.fields, &(|(n, _): &(Text, lower::OutTy)| field_id(n))), &Text::from(", ")))));
                        let generic = &len(&j.generics) > &Nat::from(0u32);
                        prism_rtl::Turn::Finished(Parts { forward: Array::from(vec![Text::from(format!("{}struct {};", &gens, &j.name))]), handles: Array::new(), values: Array::new(), cases: Array::new(), protos: if generic {
                            Array::new()
                        } else {
                            Array::from(vec![Text::from(format!("prism_rtl::JobRef<{}> {}({});", &ret, &j.start, &params))])
                        }, classes: Array::from(vec![decl.clone()]), generic: if generic { Array::from(vec![cycle.clone(), start.clone()]) } else { Array::new() }, defs: if generic { Array::new() } else { Array::from(vec![cycle.clone(), start.clone()]) } })
                    })
                })
            })
        })
    }
}

/// `Start JobParts, x`: what the function value is when passed to `@Run`.
pub fn start_job_parts(cp: Cp, j: lower::JobDef) -> Rc<dyn prism_rtl::Job<Parts>> {
    Rc::new(JobParts { cp, j })
}

/// ```prism
/// TraitParts: unbounded fn Cp, TraitDef -> Parts
/// ```
pub fn trait_parts(cp: &Cp, t: &lower::TraitDef) -> Parts {
    let defaults = filter(&t.methods, &(|f: &lower::FnDef| f.public));
    let defs = run_to_end(each_job(defaults.clone(), {
        let cp = cp.clone();
        Rc::new(move |p0: lower::FnDef| {
            let cp = cp.clone();
            entered(once_job(move || {
                let f = p0;
                prism_rtl::Turn::More(Rc::new(FnDefinition { cp: cp.clone(), f: with_generics(&f, &Array::from(vec![(Text::from("Self"), Array::new())])) }))
            }))
        }) as Rc<dyn Fn(lower::FnDef) -> Rc<dyn prism_rtl::Job<Text>>>
    }));
    generic_only(&Array::from(vec![cpp_templates::trait_namespace(&t.name, &lexer::join(&defs, &Text::from("\n")))]))
}

/// The step machine of `TraitParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TraitParts: unbounded fn Cp, TraitDef -> Parts
/// ```
pub struct TraitParts {
    pub cp: Cp,
    pub t: lower::TraitDef,
}

impl prism_rtl::Job<Parts> for TraitParts {
    fn cycle(&self) -> prism_rtl::Turn<Parts> {
        let cp = &self.cp;
        let t = &self.t;
        let defaults = filter(&t.methods, &(|f: &lower::FnDef| f.public));
        let cp = cp.clone();
        let t = t.clone();
        call_value(each_job(defaults.clone(), {
            let cp = cp.clone();
            Rc::new(move |p0: lower::FnDef| {
                let cp = cp.clone();
                entered(once_job(move || {
                    let f = p0;
                    prism_rtl::Turn::More(Rc::new(FnDefinition { cp: cp.clone(), f: with_generics(&f, &Array::from(vec![(Text::from("Self"), Array::new())])) }))
                }))
            }) as Rc<dyn Fn(lower::FnDef) -> Rc<dyn prism_rtl::Job<Text>>>
        }), move |each_73444: Array<Text>| {
            let defs = each_73444;
            prism_rtl::Turn::Finished(generic_only(&Array::from(vec![cpp_templates::trait_namespace(&t.name, &lexer::join(&defs, &Text::from("\n")))])))
        })
    }
}

/// `Start TraitParts, x`: what the function value is when passed to `@Run`.
pub fn start_trait_parts(cp: Cp, t: lower::TraitDef) -> Rc<dyn prism_rtl::Job<Parts>> {
    Rc::new(TraitParts { cp, t })
}

/// ```prism
/// ImplParts: unbounded fn Cp, ImplDef -> Parts
/// ```
pub fn impl_parts(cp: &Cp, i: &lower::ImplDef) -> Parts {
    let head = cpp_type(cp, &i.head);
    let gens = cpp_template_head(&generic_names_of(&i.generics));
    let fns = run_to_end(each_job(i.methods.clone(), {
        let cp = cp.clone();
        let i = i.clone();
        Rc::new(move |p0: lower::FnDef| {
            let cp = cp.clone();
            let i = i.clone();
            entered(once_job(move || {
                let f = p0;
                prism_rtl::Turn::More(Rc::new(FnParts { cp: cp.clone(), f: with_generics(&f, &i.generics) }))
            }))
        }) as Rc<dyn Fn(lower::FnDef) -> Rc<dyn prism_rtl::Job<Parts>>>
    }));
    let own = fold(&fns, &no_parts(), &(|acc: &Parts, p_: &Parts| join_parts(acc, p_)));
    match &i.cls {
        m74028_0 if (m74028_0 == &Text::from("Prelude.Show")) => {
            let shown = or(&index(&each(&i.methods, &(|f: &lower::FnDef| f.name.clone())), &Nat::from(0u32)), &Text::from("show"));
            join_parts(&own, &protos_defs(&Array::new(), &Array::from(vec![cpp_templates::cpp_function(&Text::from(""), &Text::from(format!("{}void {}::show(Printer& p) const", &gens, &head)), &Text::from(format!("p.raw({}(*this).to_string());", &shown)))])))
        },
        m74028_1 if (m74028_1 == &Text::from("Prelude.Eq")) => {
            let eq = fold(&i.methods, &Text::from(""), &(|acc: &Text, f: &lower::FnDef| if !lexer::has_prefix(&f.name, &Text::from("ne")) && (acc == &Text::from("")) {
                f.name.clone()
            } else {
                acc.clone()
            }));
            join_parts(&own, &protos_defs(&Array::from(vec![Text::from(format!("{}bool operator==(const {}& a, const {}& b);", &gens, &head, &head))]), &Array::from(vec![cpp_templates::cpp_function(&Text::from(""), &Text::from(format!("{}bool operator==(const {}& a, const {}& b)", &gens, &head, &head)), &Text::from(format!("return {}(a, b);", &eq)))])))
        },
        _ => {
            let tr = type_path(&i.tr);
            let in_trait = run_to_end(each_job(i.methods.clone(), {
                let tr = tr.clone();
                let cp = cp.clone();
                let i = i.clone();
                Rc::new(move |p0: lower::FnDef| {
                    let tr = tr.clone();
                    let cp = cp.clone();
                    let i = i.clone();
                    entered(once_job(move || {
                        let f = p0;
                        call_then(start_fn_definition(cp.clone(), with_generics(&f, &i.generics)), move |fn_definition_74749: Text| prism_rtl::Turn::Finished(cpp_templates::trait_namespace(&tr, &fn_definition_74749)))
                    }))
                }) as Rc<dyn Fn(lower::FnDef) -> Rc<dyn prism_rtl::Job<Text>>>
            }));
            let protos = run_to_end(each_job(i.methods.clone(), {
                let tr = tr.clone();
                let cp = cp.clone();
                let i = i.clone();
                Rc::new(move |p0: lower::FnDef| {
                    let tr = tr.clone();
                    let cp = cp.clone();
                    let i = i.clone();
                    entered(once_job(move || {
                        let f = p0;
                        call_then(start_fn_signature(cp.clone(), with_generics(&f, &i.generics)), move |fn_signature_74863: Text| prism_rtl::Turn::Finished(cpp_templates::trait_namespace(&tr, &Text::from(format!("{};", &fn_signature_74863)))))
                    }))
                }) as Rc<dyn Fn(lower::FnDef) -> Rc<dyn prism_rtl::Job<Text>>>
            }));
            protos_defs(&protos, &in_trait)
        },
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `ImplParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ImplParts: unbounded fn Cp, ImplDef -> Parts
/// ```
pub struct ImplParts {
    pub cp: Cp,
    pub i: lower::ImplDef,
}

impl prism_rtl::Job<Parts> for ImplParts {
    fn cycle(&self) -> prism_rtl::Turn<Parts> {
        let cp = &self.cp;
        let i = &self.i;
        let cp = cp.clone();
        let i = i.clone();
        call_then(start_cpp_type(cp.clone(), i.head.clone()), move |cpp_type_73810: Text| {
            let head = cpp_type_73810;
            let gens = cpp_template_head(&generic_names_of(&i.generics));
            call_value(each_job(i.methods.clone(), {
                let cp = cp.clone();
                let i = i.clone();
                Rc::new(move |p0: lower::FnDef| {
                    let cp = cp.clone();
                    let i = i.clone();
                    entered(once_job(move || {
                        let f = p0;
                        prism_rtl::Turn::More(Rc::new(FnParts { cp: cp.clone(), f: with_generics(&f, &i.generics) }))
                    }))
                }) as Rc<dyn Fn(lower::FnDef) -> Rc<dyn prism_rtl::Job<Parts>>>
            }), move |each_73902: Array<Parts>| {
                let fns = each_73902;
                let own = fold(&fns, &no_parts(), &(|acc: &Parts, p_: &Parts| join_parts(acc, p_)));
                match &i.cls {
                    m74028_0 if (m74028_0 == &Text::from("Prelude.Show")) => {
                        let shown = or(&index(&each(&i.methods, &(|f: &lower::FnDef| f.name.clone())), &Nat::from(0u32)), &Text::from("show"));
                        prism_rtl::Turn::Finished(join_parts(&own, &protos_defs(&Array::new(), &Array::from(vec![cpp_templates::cpp_function(&Text::from(""), &Text::from(format!("{}void {}::show(Printer& p) const", &gens, &head)), &Text::from(format!("p.raw({}(*this).to_string());", &shown)))]))))
                    },
                    m74028_1 if (m74028_1 == &Text::from("Prelude.Eq")) => {
                        let eq = fold(&i.methods, &Text::from(""), &(|acc: &Text, f: &lower::FnDef| if !lexer::has_prefix(&f.name, &Text::from("ne")) && (acc == &Text::from("")) {
                            f.name.clone()
                        } else {
                            acc.clone()
                        }));
                        prism_rtl::Turn::Finished(join_parts(&own, &protos_defs(&Array::from(vec![Text::from(format!("{}bool operator==(const {}& a, const {}& b);", &gens, &head, &head))]), &Array::from(vec![cpp_templates::cpp_function(&Text::from(""), &Text::from(format!("{}bool operator==(const {}& a, const {}& b)", &gens, &head, &head)), &Text::from(format!("return {}(a, b);", &eq)))]))))
                    },
                    _ => {
                        let tr = type_path(&i.tr);
                        call_value(each_job(i.methods.clone(), {
                            let tr = tr.clone();
                            let cp = cp.clone();
                            let i = i.clone();
                            Rc::new(move |p0: lower::FnDef| {
                                let tr = tr.clone();
                                let cp = cp.clone();
                                let i = i.clone();
                                entered(once_job(move || {
                                    let f = p0;
                                    call_then(start_fn_definition(cp.clone(), with_generics(&f, &i.generics)), move |fn_definition_74749: Text| prism_rtl::Turn::Finished(cpp_templates::trait_namespace(&tr, &fn_definition_74749)))
                                }))
                            }) as Rc<dyn Fn(lower::FnDef) -> Rc<dyn prism_rtl::Job<Text>>>
                        }), move |each_74708: Array<Text>| {
                            let in_trait = each_74708;
                            call_value(each_job(i.methods.clone(), {
                                let tr = tr.clone();
                                let cp = cp.clone();
                                let i = i.clone();
                                Rc::new(move |p0: lower::FnDef| {
                                    let tr = tr.clone();
                                    let cp = cp.clone();
                                    let i = i.clone();
                                    entered(once_job(move || {
                                        let f = p0;
                                        call_then(start_fn_signature(cp.clone(), with_generics(&f, &i.generics)), move |fn_signature_74863: Text| prism_rtl::Turn::Finished(cpp_templates::trait_namespace(&tr, &Text::from(format!("{};", &fn_signature_74863)))))
                                    }))
                                }) as Rc<dyn Fn(lower::FnDef) -> Rc<dyn prism_rtl::Job<Text>>>
                            }), move |each_74821: Array<Text>| {
                                let protos = each_74821;
                                prism_rtl::Turn::Finished(protos_defs(&protos, &in_trait))
                            })
                        })
                    },
                    _ => unreachable!("no arm matched"),
                }
            })
        })
    }
}

/// `Start ImplParts, x`: what the function value is when passed to `@Run`.
pub fn start_impl_parts(cp: Cp, i: lower::ImplDef) -> Rc<dyn prism_rtl::Job<Parts>> {
    Rc::new(ImplParts { cp, i })
}

/// ```prism
/// WithGenerics: fn FnDef, [((Text, [Text]))] -> FnDef
/// ```
pub fn with_generics(f: &lower::FnDef, gs: &Array<(Text, Array<Text>)>) -> lower::FnDef {
    let mut this: lower::FnDef = f.clone();
    this.generics = append(gs, &this.generics);
    this
}

/// ```prism
/// GenericOnly: fn [Text] -> Parts
/// ```
pub fn generic_only(xs: &Array<Text>) -> Parts {
    let mut this: Parts = no_parts();
    this.generic = xs.clone();
    this
}

/// ```prism
/// ProtosDefs: fn [Text], [Text] -> Parts
/// ```
pub fn protos_defs(ps: &Array<Text>, ds: &Array<Text>) -> Parts {
    let mut this: Parts = no_parts();
    this.protos = ps.clone();
    this.defs = ds.clone();
    this
}

/// ```prism
/// NodeParts: unbounded fn Cp, NodeDef -> Parts
/// ```
pub fn node_parts(cp: &Cp, n: &lower::NodeDef) -> Parts {
    let ncp = with_fields(cp, &each(&n.fields, &(|(f, t, _): &(Text, lower::OutTy, Text)| (f.clone(), t.clone()))));
    let base = if (&n.row_kind == &lower::RowKind::NotARow) && (&len(&n.hosted) == &Nat::from(0u32)) {
        Text::from("Node")
    } else {
        Text::from("Row")
    };
    let fields = lexer::join(&run_to_end(each_job(n.fields.clone(), {
        let cp = cp.clone();
        Rc::new(move |p0: (Text, lower::OutTy, Text)| {
            let cp = cp.clone();
            entered(once_job(move || {
                let (f, t, doc) = p0;
                call_then(start_cpp_type(cp.clone(), t.clone()), move |cpp_type_75839: Text| prism_rtl::Turn::Finished(Text::from(format!("{}mutable {} {};", &cpp_doc(&doc), &cpp_type_75839, &field_id(&f)))))
            }))
        }) as Rc<dyn Fn((Text, lower::OutTy, Text)) -> Rc<dyn prism_rtl::Job<Text>>>
    })), &Text::from("\n"));
    let consts = lexer::join(&each(&n.consts, &(|(c, h, doc): &(Text, Nat, Text)| Text::from(format!("{}static constexpr std::uint32_t {} = {};", &cpp_doc(&Text::from(format!("The {}.", doc))), c, h)))), &Text::from("\n"));
    let ctor_params = lexer::join(&append(&Array::from(vec![Text::from("Path path")]), &run_to_end(each_job(n.fields.clone(), {
        let cp = cp.clone();
        Rc::new(move |p0: (Text, lower::OutTy, Text)| {
            let cp = cp.clone();
            entered(once_job(move || {
                let (f, t, _) = p0;
                call_then(start_cpp_type(cp.clone(), t.clone()), move |cpp_type_76091: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {}", &cpp_type_76091, &field_id(&f)))))
            }))
        }) as Rc<dyn Fn((Text, lower::OutTy, Text)) -> Rc<dyn prism_rtl::Job<Text>>>
    }))), &Text::from(", "));
    let ctor_inits = lexer::join(&append(&Array::from(vec![Text::from("path(std::move(path))")]), &each(&n.fields, &(|(f, _, _): &(Text, lower::OutTy, Text)| Text::from(format!("{}(std::move({}))", &field_id(f), &field_id(f)))))), &Text::from(", "));
    let params = concat(&run_to_end(each_job(n.params.clone(), {
        let cp = cp.clone();
        Rc::new(move |p0: (Text, lower::OutTy)| {
            let cp = cp.clone();
            entered(once_job(move || {
                let (p_, t) = p0;
                call_then(start_param_type(cp.clone(), t.clone()), move |param_type_76330: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {}, ", &param_type_76330, &p_))))
            }))
        }) as Rc<dyn Fn((Text, lower::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>
    })));
    let ret = if n.fallible {
        Text::from(format!("Result<std::shared_ptr<{}>>", &n.name))
    } else {
        Text::from(format!("std::shared_ptr<{}>", &n.name))
    };
    let make_decl = Text::from(format!("static {} make(Path path, {}Cx& cx);", &ret, &params));
    let method_decls = run_to_end(each_job(append(&n.methods, &n.hosted), {
        let ncp = ncp.clone();
        Rc::new(move |p0: lower::MethDef| {
            let ncp = ncp.clone();
            entered(once_job(move || {
                let m = p0;
                call_then(start_method_sig(ncp.clone(), m.clone(), Text::from("")), move |method_sig_76585: Text| prism_rtl::Turn::Finished(Text::from(format!("{};", &method_sig_76585))))
            }))
        }) as Rc<dyn Fn(lower::MethDef) -> Rc<dyn prism_rtl::Job<Text>>>
    }));
    let builder_decls = append(&each(&n.builders, &(|b: &lower::ForDef| Text::from(format!("Done {}_build(Cx& cx);", &b.name)))), &each(&n.gens, &(|g: &lower::GenDef| Text::from(format!("Done {}_build(Cx& cx);", &g.name)))));
    let hook_decls = each(&n.hooks, &(|(h, _): &(Text, Array<lower::Do>)| Text::from(format!("{} override;", &hook_sig(h, &Text::from(""))))));
    let answer_decl = if &len(&n.answers) == &Nat::from(0u32) {
        Array::new()
    } else {
        Array::from(vec![Text::from("Done answer(std::span<const Segment> at, const Pod& v, Cx& cx) override;")])
    };
    let row_decl = if &n.row_kind == &lower::RowKind::NotARow {
        Array::new()
    } else {
        Array::from(vec![Text::from("void leave_row(Cx& cx) override;")])
    };
    let decls = lexer::join(&append(&append(&append(&append(&append(&Array::from(vec![make_decl.clone()]), &method_decls), &builder_decls), &hook_decls), &answer_decl), &row_decl), &Text::from("\n"));
    let doc = cpp_source_doc(&Text::from(format!("`{}`: a node of its own (docs/backend.md, \"A widget block\").", &n.prism)), &n.doc);
    let decl = cpp_templates::node_class(&doc, &n.name, &base, &fields, &consts, &Text::from(format!("{}({}) : {} {{}}", &n.name, &ctor_params, &ctor_inits)), &decls);
    let by_field = each(&n.fields, &(|(f, _, _): &(Text, lower::OutTy, Text)| or(&fold(&n.inits, &None, &(|found_opt: &Option<lower::Ex>, (g, v_): &(Text, lower::Ex)| if g == f { Some(v_.clone()) } else { found_opt.clone() })), &lower::Ex::XVar(f.clone()))));
    let (lets_text, lcp) = cpp_statements_cp(&ncp, &n.lets);
    let args = lexer::join(&append(&Array::from(vec![Text::from("path")]), &run_to_end(each_job(by_field.clone(), {
        let lcp = lcp.clone();
        Rc::new(move |p0: lower::Ex| {
            let lcp = lcp.clone();
            entered(once_job(move || {
                let v_ = p0;
                prism_rtl::Turn::More(Rc::new(CppExpr { cp: lcp.clone(), x: v_.clone() }))
            }))
        }) as Rc<dyn Fn(lower::Ex) -> Rc<dyn prism_rtl::Job<Text>>>
    }))), &Text::from(", "));
    let tail = if n.fallible { Text::from("return node;") } else { Text::from("return node;") };
    let make = cpp_templates::node_make(&n.name, &Text::from(format!("{} {}::make(Path path, {}Cx& cx)", &ret, &n.name, &params)), &lets_text, &args, &lexer::join(&filter(&Array::from(vec![cpp_statements(&pointing(&lcp, &Text::from("node")), &n.build), tail.clone()]), &(|s: &Text| s != &Text::from(""))), &Text::from("\n")));
    let methods = run_to_end(each_job(append(&n.methods, &n.hosted), {
        let ncp = ncp.clone();
        let n = n.clone();
        Rc::new(move |p0: lower::MethDef| {
            let ncp = ncp.clone();
            let n = n.clone();
            entered(once_job(move || {
                let m = p0;
                prism_rtl::Turn::More(Rc::new(MethodDef { cp: ncp.clone(), owner: n.name.clone(), m: m.clone() }))
            }))
        }) as Rc<dyn Fn(lower::MethDef) -> Rc<dyn prism_rtl::Job<Text>>>
    }));
    let builders = append(&run_to_end(each_job(n.builders.clone(), {
        let ncp = ncp.clone();
        let n = n.clone();
        Rc::new(move |p0: lower::ForDef| {
            let ncp = ncp.clone();
            let n = n.clone();
            entered(once_job(move || {
                let b = p0;
                prism_rtl::Turn::More(Rc::new(ForBuildCpp { cp: ncp.clone(), owner: n.name.clone(), b: b.clone() }))
            }))
        }) as Rc<dyn Fn(lower::ForDef) -> Rc<dyn prism_rtl::Job<Text>>>
    })), &run_to_end(each_job(n.gens.clone(), {
        let ncp = ncp.clone();
        let n = n.clone();
        Rc::new(move |p0: lower::GenDef| {
            let ncp = ncp.clone();
            let n = n.clone();
            entered(once_job(move || {
                let g = p0;
                prism_rtl::Turn::More(Rc::new(GenBuildCpp { cp: ncp.clone(), owner: n.name.clone(), gd: g.clone() }))
            }))
        }) as Rc<dyn Fn(lower::GenDef) -> Rc<dyn prism_rtl::Job<Text>>>
    })));
    let hooks = run_to_end(each_job(n.hooks.clone(), {
        let n = n.clone();
        let ncp = ncp.clone();
        Rc::new(move |p0: (Text, Array<lower::Do>)| {
            let n = n.clone();
            let ncp = ncp.clone();
            entered(once_job(move || {
                let (h, body) = p0;
                call_then(start_cpp_statements(ncp.clone(), body.clone()), move |cpp_statements_78322: Text| prism_rtl::Turn::Finished(cpp_templates::cpp_function(&Text::from(""), &hook_sig(&h, &Text::from(format!("{}::", &n.name))), &Text::from(format!("{}\nreturn {{}};", &cpp_statements_78322)))))
            }))
        }) as Rc<dyn Fn((Text, Array<lower::Do>)) -> Rc<dyn prism_rtl::Job<Text>>>
    }));
    let answer = if &len(&n.answers) == &Nat::from(0u32) {
        Array::new()
    } else {
        Array::from(vec![answer_def_cpp(&ncp, n)])
    };
    let leaving = if &n.row_kind == &lower::RowKind::NotARow {
        Array::new()
    } else {
        Array::from(vec![row_leaving(&ncp, n)])
    };
    let defs = append(&append(&append(&append(&append(&Array::from(vec![make.clone()]), &methods), &builders), &hooks), &answer), &leaving);
    let own = Parts { forward: Array::from(vec![Text::from(format!("class {};", &n.name))]), handles: Array::new(), values: Array::new(), cases: Array::new(), protos: Array::new(), classes: Array::from(vec![decl.clone()]), generic: Array::new(), defs: defs.clone() };
    own.clone()
}

/// The step machine of `NodeParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// NodeParts: unbounded fn Cp, NodeDef -> Parts
/// ```
pub struct NodeParts {
    pub cp: Cp,
    pub n: lower::NodeDef,
}

impl prism_rtl::Job<Parts> for NodeParts {
    fn cycle(&self) -> prism_rtl::Turn<Parts> {
        let cp = &self.cp;
        let n = &self.n;
        let ncp = with_fields(cp, &each(&n.fields, &(|(f, t, _): &(Text, lower::OutTy, Text)| (f.clone(), t.clone()))));
        let base = if (&n.row_kind == &lower::RowKind::NotARow) && (&len(&n.hosted) == &Nat::from(0u32)) {
            Text::from("Node")
        } else {
            Text::from("Row")
        };
        let cp = cp.clone();
        let n = n.clone();
        call_value(each_job(n.fields.clone(), {
            let cp = cp.clone();
            Rc::new(move |p0: (Text, lower::OutTy, Text)| {
                let cp = cp.clone();
                entered(once_job(move || {
                    let (f, t, doc) = p0;
                    call_then(start_cpp_type(cp.clone(), t.clone()), move |cpp_type_75839: Text| prism_rtl::Turn::Finished(Text::from(format!("{}mutable {} {};", &cpp_doc(&doc), &cpp_type_75839, &field_id(&f)))))
                }))
            }) as Rc<dyn Fn((Text, lower::OutTy, Text)) -> Rc<dyn prism_rtl::Job<Text>>>
        }), move |each_75785: Array<Text>| {
            let fields = lexer::join(&each_75785, &Text::from("\n"));
            let consts = lexer::join(&each(&n.consts, &(|(c, h, doc): &(Text, Nat, Text)| Text::from(format!("{}static constexpr std::uint32_t {} = {};", &cpp_doc(&Text::from(format!("The {}.", doc))), c, h)))), &Text::from("\n"));
            call_value(each_job(n.fields.clone(), {
                let cp = cp.clone();
                Rc::new(move |p0: (Text, lower::OutTy, Text)| {
                    let cp = cp.clone();
                    entered(once_job(move || {
                        let (f, t, _) = p0;
                        call_then(start_cpp_type(cp.clone(), t.clone()), move |cpp_type_76091: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {}", &cpp_type_76091, &field_id(&f)))))
                    }))
                }) as Rc<dyn Fn((Text, lower::OutTy, Text)) -> Rc<dyn prism_rtl::Job<Text>>>
            }), move |each_76054: Array<Text>| {
                let ctor_params = lexer::join(&append(&Array::from(vec![Text::from("Path path")]), &each_76054), &Text::from(", "));
                let ctor_inits = lexer::join(&append(&Array::from(vec![Text::from("path(std::move(path))")]), &each(&n.fields, &(|(f, _, _): &(Text, lower::OutTy, Text)| Text::from(format!("{}(std::move({}))", &field_id(f), &field_id(f)))))), &Text::from(", "));
                call_value(each_job(n.params.clone(), {
                    let cp = cp.clone();
                    Rc::new(move |p0: (Text, lower::OutTy)| {
                        let cp = cp.clone();
                        entered(once_job(move || {
                            let (p_, t) = p0;
                            call_then(start_param_type(cp.clone(), t.clone()), move |param_type_76330: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {}, ", &param_type_76330, &p_))))
                        }))
                    }) as Rc<dyn Fn((Text, lower::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>
                }), move |each_76301: Array<Text>| {
                    let params = concat(&each_76301);
                    let ret = if n.fallible {
                        Text::from(format!("Result<std::shared_ptr<{}>>", &n.name))
                    } else {
                        Text::from(format!("std::shared_ptr<{}>", &n.name))
                    };
                    let make_decl = Text::from(format!("static {} make(Path path, {}Cx& cx);", &ret, &params));
                    call_value(each_job(append(&n.methods, &n.hosted), {
                        let ncp = ncp.clone();
                        Rc::new(move |p0: lower::MethDef| {
                            let ncp = ncp.clone();
                            entered(once_job(move || {
                                let m = p0;
                                call_then(start_method_sig(ncp.clone(), m.clone(), Text::from("")), move |method_sig_76585: Text| prism_rtl::Turn::Finished(Text::from(format!("{};", &method_sig_76585))))
                            }))
                        }) as Rc<dyn Fn(lower::MethDef) -> Rc<dyn prism_rtl::Job<Text>>>
                    }), move |each_76543: Array<Text>| {
                        let method_decls = each_76543;
                        let builder_decls = append(&each(&n.builders, &(|b: &lower::ForDef| Text::from(format!("Done {}_build(Cx& cx);", &b.name)))), &each(&n.gens, &(|g: &lower::GenDef| Text::from(format!("Done {}_build(Cx& cx);", &g.name)))));
                        let hook_decls = each(&n.hooks, &(|(h, _): &(Text, Array<lower::Do>)| Text::from(format!("{} override;", &hook_sig(h, &Text::from(""))))));
                        let answer_decl = if &len(&n.answers) == &Nat::from(0u32) {
                            Array::new()
                        } else {
                            Array::from(vec![Text::from("Done answer(std::span<const Segment> at, const Pod& v, Cx& cx) override;")])
                        };
                        let row_decl = if &n.row_kind == &lower::RowKind::NotARow {
                            Array::new()
                        } else {
                            Array::from(vec![Text::from("void leave_row(Cx& cx) override;")])
                        };
                        let decls = lexer::join(&append(&append(&append(&append(&append(&Array::from(vec![make_decl.clone()]), &method_decls), &builder_decls), &hook_decls), &answer_decl), &row_decl), &Text::from("\n"));
                        let doc = cpp_source_doc(&Text::from(format!("`{}`: a node of its own (docs/backend.md, \"A widget block\").", &n.prism)), &n.doc);
                        let decl = cpp_templates::node_class(&doc, &n.name, &base, &fields, &consts, &Text::from(format!("{}({}) : {} {{}}", &n.name, &ctor_params, &ctor_inits)), &decls);
                        let by_field = each(&n.fields, &(|(f, _, _): &(Text, lower::OutTy, Text)| or(&fold(&n.inits, &None, &(|found_opt: &Option<lower::Ex>, (g, v_): &(Text, lower::Ex)| if g == f { Some(v_.clone()) } else { found_opt.clone() })), &lower::Ex::XVar(f.clone()))));
                        call_then(start_cpp_statements_cp(ncp.clone(), n.lets.clone()), move |cpp_statements_cp_77654: (Text, Cp)| {
                            let (lets_text, lcp) = cpp_statements_cp_77654;
                            call_value(each_job(by_field.clone(), {
                                let lcp = lcp.clone();
                                Rc::new(move |p0: lower::Ex| {
                                    let lcp = lcp.clone();
                                    entered(once_job(move || {
                                        let v_ = p0;
                                        prism_rtl::Turn::More(Rc::new(CppExpr { cp: lcp.clone(), x: v_.clone() }))
                                    }))
                                }) as Rc<dyn Fn(lower::Ex) -> Rc<dyn prism_rtl::Job<Text>>>
                            }), move |each_77723: Array<Text>| {
                                let args = lexer::join(&append(&Array::from(vec![Text::from("path")]), &each_77723), &Text::from(", "));
                                let tail = if n.fallible { Text::from("return node;") } else { Text::from("return node;") };
                                call_then(start_cpp_statements(pointing(&lcp, &Text::from("node")), n.build.clone()), move |cpp_statements_77947: Text| {
                                    let make = cpp_templates::node_make(&n.name, &Text::from(format!("{} {}::make(Path path, {}Cx& cx)", &ret, &n.name, &params)), &lets_text, &args, &lexer::join(&filter(&Array::from(vec![cpp_statements_77947, tail.clone()]), &(|s: &Text| s != &Text::from(""))), &Text::from("\n")));
                                    call_value(each_job(append(&n.methods, &n.hosted), {
                                        let ncp = ncp.clone();
                                        let n = n.clone();
                                        Rc::new(move |p0: lower::MethDef| {
                                            let ncp = ncp.clone();
                                            let n = n.clone();
                                            entered(once_job(move || {
                                                let m = p0;
                                                prism_rtl::Turn::More(Rc::new(MethodDef { cp: ncp.clone(), owner: n.name.clone(), m: m.clone() }))
                                            }))
                                        }) as Rc<dyn Fn(lower::MethDef) -> Rc<dyn prism_rtl::Job<Text>>>
                                    }), move |each_78042: Array<Text>| {
                                        let methods = each_78042;
                                        call_value(each_job(n.builders.clone(), {
                                            let ncp = ncp.clone();
                                            let n = n.clone();
                                            Rc::new(move |p0: lower::ForDef| {
                                                let ncp = ncp.clone();
                                                let n = n.clone();
                                                entered(once_job(move || {
                                                    let b = p0;
                                                    prism_rtl::Turn::More(Rc::new(ForBuildCpp { cp: ncp.clone(), owner: n.name.clone(), b: b.clone() }))
                                                }))
                                            }) as Rc<dyn Fn(lower::ForDef) -> Rc<dyn prism_rtl::Job<Text>>>
                                        }), move |each_78134: Array<Text>| call_value(each_job(n.gens.clone(), {
                                            let ncp = ncp.clone();
                                            let n = n.clone();
                                            Rc::new(move |p0: lower::GenDef| {
                                                let ncp = ncp.clone();
                                                let n = n.clone();
                                                entered(once_job(move || {
                                                    let g = p0;
                                                    prism_rtl::Turn::More(Rc::new(GenBuildCpp { cp: ncp.clone(), owner: n.name.clone(), gd: g.clone() }))
                                                }))
                                            }) as Rc<dyn Fn(lower::GenDef) -> Rc<dyn prism_rtl::Job<Text>>>
                                        }), move |each_78186: Array<Text>| {
                                            let builders = append(&each_78134, &each_78186);
                                            call_value(each_job(n.hooks.clone(), {
                                                let n = n.clone();
                                                let ncp = ncp.clone();
                                                Rc::new(move |p0: (Text, Array<lower::Do>)| {
                                                    let n = n.clone();
                                                    let ncp = ncp.clone();
                                                    entered(once_job(move || {
                                                        let (h, body) = p0;
                                                        call_then(start_cpp_statements(ncp.clone(), body.clone()), move |cpp_statements_78322: Text| prism_rtl::Turn::Finished(cpp_templates::cpp_function(&Text::from(""), &hook_sig(&h, &Text::from(format!("{}::", &n.name))), &Text::from(format!("{}\nreturn {{}};", &cpp_statements_78322)))))
                                                    }))
                                                }) as Rc<dyn Fn((Text, Array<lower::Do>)) -> Rc<dyn prism_rtl::Job<Text>>>
                                            }), move |each_78248: Array<Text>| {
                                                let hooks = each_78248;
                                                let answer = if &len(&n.answers) == &Nat::from(0u32) {
                                                    Array::new()
                                                } else {
                                                    Array::from(vec![answer_def_cpp(&ncp, &n)])
                                                };
                                                let leaving = if &n.row_kind == &lower::RowKind::NotARow {
                                                    Array::new()
                                                } else {
                                                    Array::from(vec![row_leaving(&ncp, &n)])
                                                };
                                                let defs = append(&append(&append(&append(&append(&Array::from(vec![make.clone()]), &methods), &builders), &hooks), &answer), &leaving);
                                                let own = Parts { forward: Array::from(vec![Text::from(format!("class {};", &n.name))]), handles: Array::new(), values: Array::new(), cases: Array::new(), protos: Array::new(), classes: Array::from(vec![decl.clone()]), generic: Array::new(), defs: defs.clone() };
                                                prism_rtl::Turn::Finished(own.clone())
                                            })
                                        }))
                                    })
                                })
                            })
                        })
                    })
                })
            })
        })
    }
}

/// `Start NodeParts, x`: what the function value is when passed to `@Run`.
pub fn start_node_parts(cp: Cp, n: lower::NodeDef) -> Rc<dyn prism_rtl::Job<Parts>> {
    Rc::new(NodeParts { cp, n })
}

/// ```prism
/// MethodSig: unbounded fn Cp, MethDef, Text -> Text
/// ```
pub fn method_sig(cp: &Cp, m: &lower::MethDef, owner: &Text) -> Text {
    let cx_ = match &m.cx_ {
        lower::CxArg::CxMut => Array::from(vec![Text::from("Cx& cx")]),
        lower::CxArg::CxRef => Array::from(vec![Text::from("const Cx& cx")]),
        lower::CxArg::CxNone => Array::new(),
    };
    let params = lexer::join(&append(&run_to_end(each_job(m.params.clone(), {
        let cp = cp.clone();
        Rc::new(move |p0: (Text, lower::OutTy)| {
            let cp = cp.clone();
            entered(once_job(move || {
                let (p_, t) = p0;
                call_then(start_param_type(cp.clone(), t.clone()), move |param_type_79029: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {}", &param_type_79029, &p_))))
            }))
        }) as Rc<dyn Fn((Text, lower::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>
    })), &cx_), &Text::from(", "));
    let constness = if &m.recv == &lower::Recv::RecvRef { Text::from(" const") } else { Text::from("") };
    Text::from(format!("{} {}{}({}){}", &cpp_type(cp, &m.ret), owner, &node_method_name(cp, &m.name), &params, &constness))
}

/// The step machine of `MethodSig`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// MethodSig: unbounded fn Cp, MethDef, Text -> Text
/// ```
pub struct MethodSig {
    pub cp: Cp,
    pub m: lower::MethDef,
    pub owner: Text,
}

impl prism_rtl::Job<Text> for MethodSig {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let m = &self.m;
        let owner = &self.owner;
        let cx_ = match &m.cx_ {
            lower::CxArg::CxMut => Array::from(vec![Text::from("Cx& cx")]),
            lower::CxArg::CxRef => Array::from(vec![Text::from("const Cx& cx")]),
            lower::CxArg::CxNone => Array::new(),
        };
        let cp = cp.clone();
        let m = m.clone();
        let owner = owner.clone();
        call_value(each_job(m.params.clone(), {
            let cp = cp.clone();
            Rc::new(move |p0: (Text, lower::OutTy)| {
                let cp = cp.clone();
                entered(once_job(move || {
                    let (p_, t) = p0;
                    call_then(start_param_type(cp.clone(), t.clone()), move |param_type_79029: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {}", &param_type_79029, &p_))))
                }))
            }) as Rc<dyn Fn((Text, lower::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>
        }), move |each_79000: Array<Text>| {
            let params = lexer::join(&append(&each_79000, &cx_), &Text::from(", "));
            let constness = if &m.recv == &lower::Recv::RecvRef { Text::from(" const") } else { Text::from("") };
            call_then(start_cpp_type(cp.clone(), m.ret.clone()), move |cpp_type_79129: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {}{}({}){}", &cpp_type_79129, &owner, &node_method_name(&cp, &m.name), &params, &constness))))
        })
    }
}

/// `Start MethodSig, x`: what the function value is when passed to `@Run`.
pub fn start_method_sig(cp: Cp, m: lower::MethDef, owner: Text) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(MethodSig { cp, m, owner })
}

/// ```prism
/// MethodDef: unbounded fn Cp, Text, MethDef -> Text
/// ```
pub fn method_def(cp: &Cp, owner: &Text, m: &lower::MethDef) -> Text {
    let (st, cp2) = cpp_statements_cp(cp, &m.body);
    let body = if &m.ret == &lower::OutTy::OutUnit {
        Text::from(format!("{}\nreturn Unit{{}};", &st))
    } else {
        if &len(&m.body) == &Nat::from(0u32) {
            cpp_body(cp, &m.tail)
        } else {
            Text::from(format!("{}\n{}", &st, &cpp_body(&cp2, &m.tail)))
        }
    };
    cpp_templates::cpp_function(&cpp_doc(&m.doc), &method_sig(cp, m, &Text::from(format!("{}::", owner))), &body)
}

/// The step machine of `MethodDef`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// MethodDef: unbounded fn Cp, Text, MethDef -> Text
/// ```
pub struct MethodDef {
    pub cp: Cp,
    pub owner: Text,
    pub m: lower::MethDef,
}

impl prism_rtl::Job<Text> for MethodDef {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let owner = &self.owner;
        let m = &self.m;
        let cp = cp.clone();
        let m = m.clone();
        let owner = owner.clone();
        call_then(start_cpp_statements_cp(cp.clone(), m.body.clone()), move |cpp_statements_cp_79305: (Text, Cp)| {
            let (st, cp2) = cpp_statements_cp_79305;
            let body = if &m.ret == &lower::OutTy::OutUnit {
                Text::from(format!("{}\nreturn Unit{{}};", &st))
            } else {
                if &len(&m.body) == &Nat::from(0u32) {
                    cpp_body(&cp, &m.tail)
                } else {
                    Text::from(format!("{}\n{}", &st, &cpp_body(&cp2, &m.tail)))
                }
            };
            call_then(start_method_sig(cp.clone(), m.clone(), Text::from(format!("{}::", &owner))), move |method_sig_79509: Text| prism_rtl::Turn::Finished(cpp_templates::cpp_function(&cpp_doc(&m.doc), &method_sig_79509, &body)))
        })
    }
}

/// `Start MethodDef, x`: what the function value is when passed to `@Run`.
pub fn start_method_def(cp: Cp, owner: Text, m: lower::MethDef) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(MethodDef { cp, owner, m })
}

/// ```prism
/// HookSig: fn Text, Text -> Text
/// ```
pub fn hook_sig(text0: &Text, owner: &Text) -> Text {
    match text0 {
        c0_0 if (c0_0 == &Text::from("push")) => Text::from(format!("Done {}push(const Pod& element, const Pod& v, Cx& cx)", owner)),
        h => Text::from(format!("Done {}{}(Cx& cx)", owner, h)),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// AnswerDefCpp: unbounded fn Cp, NodeDef -> Text
/// ```
pub fn answer_def_cpp(cp: &Cp, n: &lower::NodeDef) -> Text {
    let arms = run_to_end(each_job(n.answers.clone(), {
        let cp = cp.clone();
        Rc::new(move |p0: (lower::Pa, lower::Ex)| {
            let cp = cp.clone();
            entered(once_job(move || {
                let (pat, call) = p0;
                call_then(start_pat_conds(cp.clone(), pat.clone(), Text::from("at")), move |pat_conds_79852: Array<Text>| {
                    let tests = pat_conds_79852;
                    call_then(start_pat_binds(cp.clone(), pat.clone(), Text::from("at")), move |pat_binds_79895: Array<Text>| {
                        let binds = pat_binds_79895;
                        call_then(start_cpp_expr(cp.clone(), call.clone()), move |cpp_expr_79956: Text| prism_rtl::Turn::Finished((tests.clone(), lexer::join(&push(&binds, &Text::from(format!("{};", &cpp_expr_79956))), &Text::from("\n")))))
                    })
                })
            }))
        }) as Rc<dyn Fn((lower::Pa, lower::Ex)) -> Rc<dyn prism_rtl::Job<(Array<Text>, Text)>>>
    }));
    let blocks = each(&check_errors::range0(&len(&arms)), &(|i: &Nat| {
        let (tests, inner) = or(&index(&arms, i), &(Array::new(), Text::from("")));
        cpp_templates::block(&Text::from(format!("{} ({})", &(if i == &Nat::from(0u32) { Text::from("if") } else { Text::from("else if") }), &conds(&tests))), &inner)
    }));
    cpp_templates::cpp_function(&Text::from(""), &Text::from(format!("Done {}::answer(std::span<const Segment> at, const Pod& v, Cx& cx)", &n.name)), &Text::from(format!("{} else {{\n    return unexpected(Fault::answer(str(\"no answering place at \", path_of(at))));\n}}\nreturn {{}};", &lexer::join(&blocks, &Text::from(" ")))))
}

/// The step machine of `AnswerDefCpp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// AnswerDefCpp: unbounded fn Cp, NodeDef -> Text
/// ```
pub struct AnswerDefCpp {
    pub cp: Cp,
    pub n: lower::NodeDef,
}

impl prism_rtl::Job<Text> for AnswerDefCpp {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let n = &self.n;
        let cp = cp.clone();
        let n = n.clone();
        call_value(each_job(n.answers.clone(), {
            let cp = cp.clone();
            Rc::new(move |p0: (lower::Pa, lower::Ex)| {
                let cp = cp.clone();
                entered(once_job(move || {
                    let (pat, call) = p0;
                    call_then(start_pat_conds(cp.clone(), pat.clone(), Text::from("at")), move |pat_conds_79852: Array<Text>| {
                        let tests = pat_conds_79852;
                        call_then(start_pat_binds(cp.clone(), pat.clone(), Text::from("at")), move |pat_binds_79895: Array<Text>| {
                            let binds = pat_binds_79895;
                            call_then(start_cpp_expr(cp.clone(), call.clone()), move |cpp_expr_79956: Text| prism_rtl::Turn::Finished((tests.clone(), lexer::join(&push(&binds, &Text::from(format!("{};", &cpp_expr_79956))), &Text::from("\n")))))
                        })
                    })
                }))
            }) as Rc<dyn Fn((lower::Pa, lower::Ex)) -> Rc<dyn prism_rtl::Job<(Array<Text>, Text)>>>
        }), move |each_79799: Array<(Array<Text>, Text)>| {
            let arms = each_79799;
            let blocks = each(&check_errors::range0(&len(&arms)), &(|i: &Nat| {
                let (tests, inner) = or(&index(&arms, i), &(Array::new(), Text::from("")));
                cpp_templates::block(&Text::from(format!("{} ({})", &(if i == &Nat::from(0u32) { Text::from("if") } else { Text::from("else if") }), &conds(&tests))), &inner)
            }));
            prism_rtl::Turn::Finished(cpp_templates::cpp_function(&Text::from(""), &Text::from(format!("Done {}::answer(std::span<const Segment> at, const Pod& v, Cx& cx)", &n.name)), &Text::from(format!("{} else {{\n    return unexpected(Fault::answer(str(\"no answering place at \", path_of(at))));\n}}\nreturn {{}};", &lexer::join(&blocks, &Text::from(" "))))))
        })
    }
}

/// `Start AnswerDefCpp, x`: what the function value is when passed to `@Run`.
pub fn start_answer_def_cpp(cp: Cp, n: lower::NodeDef) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(AnswerDefCpp { cp, n })
}

/// ```prism
/// RowLeaving: unbounded fn Cp, NodeDef -> Text
/// ```
pub fn row_leaving(cp: &Cp, n: &lower::NodeDef) -> Text {
    let kept = if &n.row_kind == &lower::RowKind::ForRow {
        Array::from(vec![Text::from("this->left_entry = entry(cx);")])
    } else {
        Array::new()
    };
    let unsubscribe = each(&n.subs, &(|(ev, m, _): &(Text, Text, lower::OutTy)| Text::from(format!("if (auto p = parent.lock(); p && {}_sub) deref(p->{}_port).unsubscribe(*std::exchange({}_sub, std::nullopt));", m, ev, m))));
    cpp_templates::cpp_function(&Text::from(""), &Text::from(format!("void {}::leave_row(Cx& cx)", &n.name)), &lexer::join(&append(&push(&kept, &Text::from("remove_places(cx);")), &unsubscribe), &Text::from("\n")))
}

/// The step machine of `RowLeaving`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RowLeaving: unbounded fn Cp, NodeDef -> Text
/// ```
pub struct RowLeaving {
    pub cp: Cp,
    pub n: lower::NodeDef,
}

impl prism_rtl::Job<Text> for RowLeaving {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let n = &self.n;
        let kept = if &n.row_kind == &lower::RowKind::ForRow {
            Array::from(vec![Text::from("this->left_entry = entry(cx);")])
        } else {
            Array::new()
        };
        let unsubscribe = each(&n.subs, &(|(ev, m, _): &(Text, Text, lower::OutTy)| Text::from(format!("if (auto p = parent.lock(); p && {}_sub) deref(p->{}_port).unsubscribe(*std::exchange({}_sub, std::nullopt));", m, ev, m))));
        prism_rtl::Turn::Finished(cpp_templates::cpp_function(&Text::from(""), &Text::from(format!("void {}::leave_row(Cx& cx)", &n.name)), &lexer::join(&append(&push(&kept, &Text::from("remove_places(cx);")), &unsubscribe), &Text::from("\n"))))
    }
}

/// `Start RowLeaving, x`: what the function value is when passed to `@Run`.
pub fn start_row_leaving(cp: Cp, n: lower::NodeDef) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(RowLeaving { cp, n })
}

/// ```prism
/// ForBuildCpp: unbounded fn Cp, Text, ForDef -> Text
/// ```
pub fn for_build_cpp(cp: &Cp, owner: &Text, b: &lower::ForDef) -> Text {
    cpp_templates::for_build_template(owner, &b.name, &cpp_expr(cp, &b.at), &cpp_type(cp, &b.key_ty), &cpp_type(cp, &b.value_ty), &call_path(&Text::from(format!("{}::build", &b.row_node))), &b.source, &cpp_expr(cp, &b.parent), &concat(&run_to_end(each_job(b.passed.clone(), {
        let cp = cp.clone();
        Rc::new(move |p0: lower::Ex| {
            let cp = cp.clone();
            entered(once_job(move || {
                let x = p0;
                call_then(start_cpp_expr(cp.clone(), x.clone()), move |cpp_expr_81260: Text| prism_rtl::Turn::Finished(Text::from(format!(", {}", &cpp_expr_81260))))
            }))
        }) as Rc<dyn Fn(lower::Ex) -> Rc<dyn prism_rtl::Job<Text>>>
    }))))
}

/// The step machine of `ForBuildCpp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ForBuildCpp: unbounded fn Cp, Text, ForDef -> Text
/// ```
pub struct ForBuildCpp {
    pub cp: Cp,
    pub owner: Text,
    pub b: lower::ForDef,
}

impl prism_rtl::Job<Text> for ForBuildCpp {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let owner = &self.owner;
        let b = &self.b;
        let b = b.clone();
        let cp = cp.clone();
        let owner = owner.clone();
        call_then(start_cpp_expr(cp.clone(), b.at.clone()), move |cpp_expr_81093: Text| call_then(start_cpp_type(cp.clone(), b.key_ty.clone()), move |cpp_type_81113: Text| call_then(start_cpp_type(cp.clone(), b.value_ty.clone()), move |cpp_type_81136: Text| call_then(start_cpp_expr(cp.clone(), b.parent.clone()), move |cpp_expr_81204: Text| call_value(each_job(b.passed.clone(), {
            let cp = cp.clone();
            Rc::new(move |p0: lower::Ex| {
                let cp = cp.clone();
                entered(once_job(move || {
                    let x = p0;
                    call_then(start_cpp_expr(cp.clone(), x.clone()), move |cpp_expr_81260: Text| prism_rtl::Turn::Finished(Text::from(format!(", {}", &cpp_expr_81260))))
                }))
            }) as Rc<dyn Fn(lower::Ex) -> Rc<dyn prism_rtl::Job<Text>>>
        }), move |each_81236: Array<Text>| prism_rtl::Turn::Finished(cpp_templates::for_build_template(&owner, &b.name, &cpp_expr_81093, &cpp_type_81113, &cpp_type_81136, &call_path(&Text::from(format!("{}::build", &b.row_node))), &b.source, &cpp_expr_81204, &concat(&each_81236))))))))
    }
}

/// `Start ForBuildCpp, x`: what the function value is when passed to `@Run`.
pub fn start_for_build_cpp(cp: Cp, owner: Text, b: lower::ForDef) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(ForBuildCpp { cp, owner, b })
}

/// ```prism
/// GenBuildCpp: unbounded fn Cp, Text, GenDef -> Text
/// ```
pub fn gen_build_cpp(cp: &Cp, owner: &Text, gd: &lower::GenDef) -> Text {
    let path_ = if gd.transparent {
        Text::from("this->path")
    } else {
        Text::from(format!("{}.child(Segment::gen(g))", &cpp_expr(cp, &gd.at)))
    };
    cpp_templates::gen_build_template(owner, &gd.name, &cpp_expr(cp, &gd.at), &path_, &cpp_expr(cp, &gd.source), &cpp_type(cp, &gd.value_ty), &cpp_expr(cp, &gd.select))
}

/// The step machine of `GenBuildCpp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// GenBuildCpp: unbounded fn Cp, Text, GenDef -> Text
/// ```
pub struct GenBuildCpp {
    pub cp: Cp,
    pub owner: Text,
    pub gd: lower::GenDef,
}

impl prism_rtl::Job<Text> for GenBuildCpp {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let owner = &self.owner;
        let gd = &self.gd;
        let path_ = if gd.transparent {
            Text::from("this->path")
        } else {
            Text::from(format!("{}.child(Segment::gen(g))", &cpp_expr(cp, &gd.at)))
        };
        let cp = cp.clone();
        let gd = gd.clone();
        let owner = owner.clone();
        call_then(start_cpp_expr(cp.clone(), gd.at.clone()), move |cpp_expr_81496: Text| call_then(start_cpp_expr(cp.clone(), gd.source.clone()), move |cpp_expr_81523: Text| call_then(start_cpp_type(cp.clone(), gd.value_ty.clone()), move |cpp_type_81548: Text| call_then(start_cpp_expr(cp.clone(), gd.select.clone()), move |cpp_expr_81574: Text| prism_rtl::Turn::Finished(cpp_templates::gen_build_template(&owner, &gd.name, &cpp_expr_81496, &path_, &cpp_expr_81523, &cpp_type_81548, &cpp_expr_81574))))))
    }
}

/// `Start GenBuildCpp, x`: what the function value is when passed to `@Run`.
pub fn start_gen_build_cpp(cp: Cp, owner: Text, gd: lower::GenDef) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(GenBuildCpp { cp, owner, gd })
}

/// ```prism
/// ProgramCpp: unbounded fn Cp, ProgDef, Bool -> Text
/// ```
pub fn program_cpp(cp: &Cp, p_: &lower::ProgDef, fallible: &bool) -> Text {
    let n = len(&p_.params);
    let names = each(&p_.params, &(|(a, _): &(Text, lower::OutTy)| a.clone()));
    let plural = if &n == &Nat::from(1u32) { Text::from("") } else { Text::from("s") };
    let decode = if &n == &Nat::from(0u32) {
        Text::from("static_cast<void>(args);")
    } else {
        lexer::join(&append(&Array::from(vec![Text::from(format!("if (args.size() != {}) return unexpected(Fault::answer(\"@{} takes {} argument{}\"));", &n, &p_.prism, &n, &plural))]), &run_to_end(each_job(check_errors::range0(&n), {
            let cp = cp.clone();
            let p_ = p_.clone();
            Rc::new(move |p0: Nat| {
                let cp = cp.clone();
                let p_ = p_.clone();
                entered(once_job(move || {
                    let i = p0;
                    prism_rtl::Turn::More(Rc::new(DecodeArg { cp: cp.clone(), ps: p_.params.clone(), i: i.clone() }))
                }))
            }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Text>>>
        }))), &Text::from("\n"))
    };
    let call = Text::from(format!("{}(Path::root(), {}cx)", &call_path(&Text::from(format!("{}::build", &p_.node_))), &concat(&each(&names, &(|a: &Text| Text::from(format!("{}, ", a)))))));
    let root = if *fallible { Text::from(format!("TRY({})", &call)) } else { call.clone() };
    cpp_templates::program_class(&p_.name, &p_.prism, &type_path(&p_.node_), &decode, &root)
}

/// The step machine of `ProgramCpp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ProgramCpp: unbounded fn Cp, ProgDef, Bool -> Text
/// ```
pub struct ProgramCpp {
    pub cp: Cp,
    pub p_: lower::ProgDef,
    pub fallible: bool,
}

impl prism_rtl::Job<Text> for ProgramCpp {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let p_ = &self.p_;
        let fallible = &self.fallible;
        let n = len(&p_.params);
        let names = each(&p_.params, &(|(a, _): &(Text, lower::OutTy)| a.clone()));
        let plural = if &n == &Nat::from(1u32) { Text::from("") } else { Text::from("s") };
        let decode = if &n == &Nat::from(0u32) {
            Text::from("static_cast<void>(args);")
        } else {
            lexer::join(&append(&Array::from(vec![Text::from(format!("if (args.size() != {}) return unexpected(Fault::answer(\"@{} takes {} argument{}\"));", &n, &p_.prism, &n, &plural))]), &run_to_end(each_job(check_errors::range0(&n), {
                let cp = cp.clone();
                let p_ = p_.clone();
                Rc::new(move |p0: Nat| {
                    let cp = cp.clone();
                    let p_ = p_.clone();
                    entered(once_job(move || {
                        let i = p0;
                        prism_rtl::Turn::More(Rc::new(DecodeArg { cp: cp.clone(), ps: p_.params.clone(), i: i.clone() }))
                    }))
                }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Text>>>
            }))), &Text::from("\n"))
        };
        let call = Text::from(format!("{}(Path::root(), {}cx)", &call_path(&Text::from(format!("{}::build", &p_.node_))), &concat(&each(&names, &(|a: &Text| Text::from(format!("{}, ", a)))))));
        let root = if *fallible { Text::from(format!("TRY({})", &call)) } else { call.clone() };
        prism_rtl::Turn::Finished(cpp_templates::program_class(&p_.name, &p_.prism, &type_path(&p_.node_), &decode, &root))
    }
}

/// `Start ProgramCpp, x`: what the function value is when passed to `@Run`.
pub fn start_program_cpp(cp: Cp, p_: lower::ProgDef, fallible: bool) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(ProgramCpp { cp, p_, fallible })
}

/// ```prism
/// DecodeArg: unbounded fn Cp, [((Text, OutTy))], Nat -> Text
/// ```
pub fn decode_arg(cp: &Cp, ps: &Array<(Text, lower::OutTy)>, i: &Nat) -> Text {
    match index(ps, i) {
        Some((a, t)) => Text::from(format!("auto {} = TRY(prism_rtl::from_pod<{}>(args[{}]));", &a, &cpp_type(cp, &t), i)),
        None => Text::from(""),
    }
}

/// The step machine of `DecodeArg`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// DecodeArg: unbounded fn Cp, [((Text, OutTy))], Nat -> Text
/// ```
pub struct DecodeArg {
    pub cp: Cp,
    pub ps: Array<(Text, lower::OutTy)>,
    pub i: Nat,
}

impl prism_rtl::Job<Text> for DecodeArg {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let ps = &self.ps;
        let i = &self.i;
        match index(ps, i) {
            Some((a, t)) => {
                let cp = cp.clone();
                let i = i.clone();
                call_then(start_cpp_type(cp.clone(), t.clone()), move |cpp_type_82404: Text| prism_rtl::Turn::Finished(Text::from(format!("auto {} = TRY(prism_rtl::from_pod<{}>(args[{}]));", &a, &cpp_type_82404, &i))))
            },
            None => prism_rtl::Turn::Finished(Text::from("")),
        }
    }
}

/// `Start DecodeArg, x`: what the function value is when passed to `@Run`.
pub fn start_decode_arg(cp: Cp, ps: Array<(Text, lower::OutTy)>, i: Nat) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(DecodeArg { cp, ps, i })
}

/// ```prism
/// ModuleParts: unbounded fn Cp, ModDef -> Parts
/// ```
pub fn module_parts(cp: &Cp, m: &lower::ModDef) -> Parts {
    let mcp = in_home(cp, &m.name);
    let all = run_to_end(fold_job(m.items.clone(), no_parts(), {
        let mcp = mcp.clone();
        Rc::new(move |(p0, p1): (Parts, lower::Item)| {
            let mcp = mcp.clone();
            entered(once_job(move || {
                let acc = p0;
                let it = p1;
                call_then(start_item_parts(mcp.clone(), it.clone()), move |item_parts_82853: Parts| prism_rtl::Turn::Finished(join_parts(&acc, &item_parts_82853)))
            }))
        }) as Rc<dyn Fn((Parts, lower::Item)) -> Rc<dyn prism_rtl::Job<Parts>>>
    }));
    Parts { forward: in_ns(&m.name, &all.forward), handles: in_ns(&m.name, &all.handles), values: each(&all.values, &(|v_: &ValueDecl| in_ns_value(&m.name, v_))), cases: in_ns(&m.name, &all.cases), protos: in_ns(&m.name, &all.protos), classes: in_ns(&m.name, &all.classes), generic: in_ns(&m.name, &all.generic), defs: all.defs.clone() }
}

/// The step machine of `ModuleParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ModuleParts: unbounded fn Cp, ModDef -> Parts
/// ```
pub struct ModuleParts {
    pub cp: Cp,
    pub m: lower::ModDef,
}

impl prism_rtl::Job<Parts> for ModuleParts {
    fn cycle(&self) -> prism_rtl::Turn<Parts> {
        let cp = &self.cp;
        let m = &self.m;
        let mcp = in_home(cp, &m.name);
        let m = m.clone();
        call_value(fold_job(m.items.clone(), no_parts(), {
            let mcp = mcp.clone();
            Rc::new(move |(p0, p1): (Parts, lower::Item)| {
                let mcp = mcp.clone();
                entered(once_job(move || {
                    let acc = p0;
                    let it = p1;
                    call_then(start_item_parts(mcp.clone(), it.clone()), move |item_parts_82853: Parts| prism_rtl::Turn::Finished(join_parts(&acc, &item_parts_82853)))
                }))
            }) as Rc<dyn Fn((Parts, lower::Item)) -> Rc<dyn prism_rtl::Job<Parts>>>
        }), move |fold_82803: Parts| {
            let all = fold_82803;
            prism_rtl::Turn::Finished(Parts { forward: in_ns(&m.name, &all.forward), handles: in_ns(&m.name, &all.handles), values: each(&all.values, &(|v_: &ValueDecl| in_ns_value(&m.name, v_))), cases: in_ns(&m.name, &all.cases), protos: in_ns(&m.name, &all.protos), classes: in_ns(&m.name, &all.classes), generic: in_ns(&m.name, &all.generic), defs: all.defs.clone() })
        })
    }
}

/// `Start ModuleParts, x`: what the function value is when passed to `@Run`.
pub fn start_module_parts(cp: Cp, m: lower::ModDef) -> Rc<dyn prism_rtl::Job<Parts>> {
    Rc::new(ModuleParts { cp, m })
}

/// ```prism
/// InNsValue: fn Text, ValueDecl -> ValueDecl
/// ```
pub fn in_ns_value(ns: &Text, v_: &ValueDecl) -> ValueDecl {
    let mut this: ValueDecl = v_.clone();
    this.text = Text::from(format!("namespace {} {{\n\n{}\n\n}}  // namespace {}", ns, &this.text, ns));
    this
}

/// ```prism
/// InNs: fn Text, [Text] -> [Text]
/// ```
pub fn in_ns(ns: &Text, xs1: &Array<Text>) -> Array<Text> {
    match xs1 {
        c0_1 if (c0_1.len() == 0) => Array::new(),
        xs => Array::from(vec![Text::from(format!("namespace {} {{\n\n{}\n\n}}  // namespace {}", ns, &lexer::join(xs, &Text::from("\n\n")), ns))]),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// NodeFallibleCpp: fn Model, Text -> Bool
/// ```
pub fn node_fallible_cpp(model: &lower::Model, path_: &Text) -> bool {
    fold(&model.mods, &false, &(|f: &bool, m: &lower::ModDef| fold(&m.items, f, &(|f2: &bool, it: &lower::Item| match it {
        lower::Item::ItNode(n) => *f2 || ((&Text::from(format!("{}::{}", &m.name, &n.name)) == path_) && n.fallible),
        _ => *f2,
    }))))
}

/// ```prism
/// EmitCpp: unbounded fn Model, Text, [Text] -> [((Text, Text))]
/// ```
pub fn emit_cpp(model: &lower::Model, runtime: &Text, scripts: &Array<Text>) -> Array<(Text, Text)> {
    let cp = context(model);
    let crate_ = in_home(&cp, &Text::from(""));
    let elem = row_parts(&crate_, &Text::from(""), &model.elem);
    let answer = answer_parts(&crate_, &model.answer);
    let mods = run_to_end(each_job(model.mods.clone(), {
        let cp = cp.clone();
        Rc::new(move |p0: lower::ModDef| {
            let cp = cp.clone();
            entered(once_job(move || {
                let m = p0;
                prism_rtl::Turn::More(Rc::new(ModuleParts { cp: cp.clone(), m: m.clone() }))
            }))
        }) as Rc<dyn Fn(lower::ModDef) -> Rc<dyn prism_rtl::Job<Parts>>>
    }));
    let all = fold(&mods, &join_parts(&elem, &answer), &(|acc: &Parts, p_: &Parts| join_parts(acc, p_)));
    let programs = lexer::join(&run_to_end(each_job(all_programs_cpp(model), {
        let crate_ = crate_.clone();
        let model = model.clone();
        Rc::new(move |p0: lower::ProgDef| {
            let crate_ = crate_.clone();
            let model = model.clone();
            entered(once_job(move || {
                let p_ = p0;
                prism_rtl::Turn::More(Rc::new(ProgramCpp { cp: crate_.clone(), p_: p_.clone(), fallible: node_fallible_cpp(&model, &p_.node_) }))
            }))
        }) as Rc<dyn Fn(lower::ProgDef) -> Rc<dyn prism_rtl::Job<Text>>>
    })), &Text::from("\n\n"));
    let header_ = header(&model.name, &all, &programs);
    let regs = concat(&each(&model.programs, &(|p_: &lower::ProgDef| Text::from(format!("\n.program<{}>(\"{}\")", &p_.name, &p_.prism)))));
    let checks = concat(&run_to_end(each_job(model.checks.clone(), {
        let crate_ = crate_.clone();
        Rc::new(move |p0: lower::CheckDef| {
            let crate_ = crate_.clone();
            entered(once_job(move || {
                let c = p0;
                call_value(each_job(c.lines.clone(), {
                    let crate_ = crate_.clone();
                    Rc::new(move |p0: lower::Ex| {
                        let crate_ = crate_.clone();
                        entered(once_job(move || {
                            let l = p0;
                            prism_rtl::Turn::More(Rc::new(CppExpr { cp: crate_.clone(), x: l.clone() }))
                        }))
                    }) as Rc<dyn Fn(lower::Ex) -> Rc<dyn prism_rtl::Job<Text>>>
                }), move |each_84535: Array<Text>| prism_rtl::Turn::Finished(Text::from(format!("\n.check(\"{}\", [] {{ return std::vector<Result<Pod>>{{{}}}; }})", &c.name, &lexer::join(&each_84535, &Text::from(", "))))))
            }))
        }) as Rc<dyn Fn(lower::CheckDef) -> Rc<dyn prism_rtl::Job<Text>>>
    })));
    let script_list = lexer::join(&each(scripts, &(|s: &Text| Text::from(format!("\"{}\",", &lower::escape(s))))), &Text::from("\n"));
    let world = match &model.root {
        Some(r) => r.world.clone(),
        None => Text::from("test"),
    };
    let canvas = &world == &Text::from("canvas");
    let run_root = match &model.root {
        Some(r) => cpp_templates::cpp_run_root(&r.name, &(if canvas {
            cpp_templates::cpp_canvas_run(&r.name)
        } else {
            cpp_templates::cpp_no_canvas(&r.name)
        })),
        None => cpp_templates::cpp_no_root(&model.name),
    };
    let includes = if canvas {
        cpp_templates::cpp_canvas_include(&Text::from(""))
    } else {
        Text::from("")
    };
    let main = cpp_templates::cpp_main(&model.name, &includes, &regs, &checks, &script_list, &world, &run_root, &lexer::join(&concat2(&each(&Array::from(vec![elem.clone(), answer.clone()]), &(|p_: &Parts| p_.defs.clone()))), &Text::from("\n\n")));
    let per_module = each(&check_errors::range0(&len(&model.mods)), &(|i: &Nat| {
        let m = or(&index(&model.mods, i), &lower::ModDef { name: Text::from(""), prism: Text::from(""), path_: Text::from(""), uses: Array::new(), items: Array::new() });
        let p_ = or(&index(&mods, i), &no_parts());
        module_files(&m, &chunks(&p_.defs))
    }));
    let files = fold(&per_module, &Array::new(), &(|acc: &Array<(Text, Text)>, fs: &Array<(Text, Text)>| append(acc, fs)));
    let sources = lexer::join(&each(&files, &(|(f, _): &(Text, Text)| f.clone())), &Text::from(" "));
    append(&Array::from(vec![(Text::from("Makefile"), cpp_templates::cpp_makefile(&model.name, runtime, &sources, &(if canvas { cpp_templates::cpp_makefile_canvas(runtime) } else { Text::from("") }))), (Text::from("src/crate.hpp"), header_.clone()), (Text::from("src/main.cpp"), main.clone()), (Text::from("src/prelude.hpp"), cpp_prelude_template::cpp_prelude_source(&Text::from("")))]), &files)
}

/// The step machine of `EmitCpp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// EmitCpp: unbounded fn Model, Text, [Text] -> [((Text, Text))]
/// ```
pub struct EmitCpp {
    pub model: lower::Model,
    pub runtime: Text,
    pub scripts: Array<Text>,
}

impl prism_rtl::Job<Array<(Text, Text)>> for EmitCpp {
    fn cycle(&self) -> prism_rtl::Turn<Array<(Text, Text)>> {
        let model = &self.model;
        let runtime = &self.runtime;
        let scripts = &self.scripts;
        let cp = context(model);
        let crate_ = in_home(&cp, &Text::from(""));
        let model = model.clone();
        let runtime = runtime.clone();
        let scripts = scripts.clone();
        call_then(start_row_parts(crate_.clone(), Text::from(""), model.elem.clone()), move |row_parts_83944: Parts| {
            let elem = row_parts_83944;
            call_then(start_answer_parts(crate_.clone(), model.answer.clone()), move |answer_parts_83992: Parts| {
                let answer = answer_parts_83992;
                call_value(each_job(model.mods.clone(), {
                    let cp = cp.clone();
                    Rc::new(move |p0: lower::ModDef| {
                        let cp = cp.clone();
                        entered(once_job(move || {
                            let m = p0;
                            prism_rtl::Turn::More(Rc::new(ModuleParts { cp: cp.clone(), m: m.clone() }))
                        }))
                    }) as Rc<dyn Fn(lower::ModDef) -> Rc<dyn prism_rtl::Job<Parts>>>
                }), move |each_84039: Array<Parts>| {
                    let mods = each_84039;
                    let all = fold(&mods, &join_parts(&elem, &answer), &(|acc: &Parts, p_: &Parts| join_parts(acc, p_)));
                    call_value(each_job(all_programs_cpp(&model), {
                        let crate_ = crate_.clone();
                        let model = model.clone();
                        Rc::new(move |p0: lower::ProgDef| {
                            let crate_ = crate_.clone();
                            let model = model.clone();
                            entered(once_job(move || {
                                let p_ = p0;
                                prism_rtl::Turn::More(Rc::new(ProgramCpp { cp: crate_.clone(), p_: p_.clone(), fallible: node_fallible_cpp(&model, &p_.node_) }))
                            }))
                        }) as Rc<dyn Fn(lower::ProgDef) -> Rc<dyn prism_rtl::Job<Text>>>
                    }), move |each_84182: Array<Text>| {
                        let programs = lexer::join(&each_84182, &Text::from("\n\n"));
                        call_then(start_header(model.name.clone(), all.clone(), programs.clone()), move |header_84295: Text| {
                            let header_ = header_84295;
                            let regs = concat(&each(&model.programs, &(|p_: &lower::ProgDef| Text::from(format!("\n.program<{}>(\"{}\")", &p_.name, &p_.prism)))));
                            call_value(each_job(model.checks.clone(), {
                                let crate_ = crate_.clone();
                                Rc::new(move |p0: lower::CheckDef| {
                                    let crate_ = crate_.clone();
                                    entered(once_job(move || {
                                        let c = p0;
                                        call_value(each_job(c.lines.clone(), {
                                            let crate_ = crate_.clone();
                                            Rc::new(move |p0: lower::Ex| {
                                                let crate_ = crate_.clone();
                                                entered(once_job(move || {
                                                    let l = p0;
                                                    prism_rtl::Turn::More(Rc::new(CppExpr { cp: crate_.clone(), x: l.clone() }))
                                                }))
                                            }) as Rc<dyn Fn(lower::Ex) -> Rc<dyn prism_rtl::Job<Text>>>
                                        }), move |each_84535: Array<Text>| prism_rtl::Turn::Finished(Text::from(format!("\n.check(\"{}\", [] {{ return std::vector<Result<Pod>>{{{}}}; }})", &c.name, &lexer::join(&each_84535, &Text::from(", "))))))
                                    }))
                                }) as Rc<dyn Fn(lower::CheckDef) -> Rc<dyn prism_rtl::Job<Text>>>
                            }), move |each_84441: Array<Text>| {
                                let checks = concat(&each_84441);
                                let script_list = lexer::join(&each(&scripts, &(|s: &Text| Text::from(format!("\"{}\",", &lower::escape(s))))), &Text::from("\n"));
                                let world = match &model.root {
                                    Some(r) => r.world.clone(),
                                    None => Text::from("test"),
                                };
                                let canvas = &world == &Text::from("canvas");
                                let run_root = match &model.root {
                                    Some(r) => cpp_templates::cpp_run_root(&r.name, &(if canvas {
                                        cpp_templates::cpp_canvas_run(&r.name)
                                    } else {
                                        cpp_templates::cpp_no_canvas(&r.name)
                                    })),
                                    None => cpp_templates::cpp_no_root(&model.name),
                                };
                                let includes = if canvas {
                                    cpp_templates::cpp_canvas_include(&Text::from(""))
                                } else {
                                    Text::from("")
                                };
                                let main = cpp_templates::cpp_main(&model.name, &includes, &regs, &checks, &script_list, &world, &run_root, &lexer::join(&concat2(&each(&Array::from(vec![elem.clone(), answer.clone()]), &(|p_: &Parts| p_.defs.clone()))), &Text::from("\n\n")));
                                let per_module = each(&check_errors::range0(&len(&model.mods)), &(|i: &Nat| {
                                    let m = or(&index(&model.mods, i), &lower::ModDef { name: Text::from(""), prism: Text::from(""), path_: Text::from(""), uses: Array::new(), items: Array::new() });
                                    let p_ = or(&index(&mods, i), &no_parts());
                                    module_files(&m, &chunks(&p_.defs))
                                }));
                                let files = fold(&per_module, &Array::new(), &(|acc: &Array<(Text, Text)>, fs: &Array<(Text, Text)>| append(acc, fs)));
                                let sources = lexer::join(&each(&files, &(|(f, _): &(Text, Text)| f.clone())), &Text::from(" "));
                                prism_rtl::Turn::Finished(append(&Array::from(vec![(Text::from("Makefile"), cpp_templates::cpp_makefile(&model.name, &runtime, &sources, &(if canvas { cpp_templates::cpp_makefile_canvas(&runtime) } else { Text::from("") }))), (Text::from("src/crate.hpp"), header_.clone()), (Text::from("src/main.cpp"), main.clone()), (Text::from("src/prelude.hpp"), cpp_prelude_template::cpp_prelude_source(&Text::from("")))]), &files))
                            })
                        })
                    })
                })
            })
        })
    }
}

/// `Start EmitCpp, x`: what the function value is when passed to `@Run`.
pub fn start_emit_cpp(model: lower::Model, runtime: Text, scripts: Array<Text>) -> Rc<dyn prism_rtl::Job<Array<(Text, Text)>>> {
    Rc::new(EmitCpp { model, runtime, scripts })
}

/// ```prism
/// Chunks: fn [Text] -> [ [Text] ]
/// ```
pub fn chunks(defs: &Array<Text>) -> Array<Array<Text>> {
    let (done, current, size_) = fold(defs, &(Array::new(), Array::new(), Nat::from(0u32)), &(|(acc, cur, n): &(Array<Array<Text>>, Array<Text>, Nat), d: &Text| if (n > &chunk_size()) && (&len(cur) > &Nat::from(0u32)) {
        (push(acc, cur), Array::from(vec![d.clone()]), len_text(d))
    } else {
        (acc.clone(), push(cur, d), n + &len_text(d))
    }));
    if (&len(&current) == &Nat::from(0u32)) && (&len(&done) > &Nat::from(0u32)) {
        done.clone()
    } else {
        push(&done, &current)
    }
}

/// ```prism
/// let chunkSize
/// ```
pub fn chunk_size() -> Nat {
    Nat::from(250000u32)
}

/// ```prism
/// ModuleFiles: fn ModDef, [ [Text] ] -> [((Text, Text))]
/// ```
pub fn module_files(m: &lower::ModDef, chunks_: &Array<Array<Text>>) -> Array<(Text, Text)> {
    let title = if &m.prism == &Text::from("") {
        Text::from("The root module")
    } else {
        Text::from(format!("The module `{}`", &m.prism))
    };
    each(&check_errors::range0(&len(chunks_)), &(|k: &Nat| (chunk_file(&m.name, k), cpp_templates::cpp_module(&title, &m.path_, &m.name, &lexer::join(&or(&index(chunks_, k), &Array::new()), &Text::from("\n\n"))))))
}

/// ```prism
/// ChunkFile: fn Text, Nat -> Text
/// ```
pub fn chunk_file(m: &Text, k: &Nat) -> Text {
    if k == &Nat::from(0u32) {
        Text::from(format!("src/{}.cpp", m))
    } else {
        Text::from(format!("src/{}_{}.cpp", m, &(k + &Nat::from(1u32))))
    }
}

/// ```prism
/// AllProgramsCpp: fn Model -> [ProgDef]
/// ```
pub fn all_programs_cpp(model: &lower::Model) -> Array<lower::ProgDef> {
    match &model.root {
        Some(r) => if fold(&model.programs, &false, &(|f: &bool, p_: &lower::ProgDef| *f || (&p_.name == &r.name))) {
            model.programs.clone()
        } else {
            push(&model.programs, r)
        },
        None => model.programs.clone(),
    }
}

/// ```prism
/// Header: unbounded fn Text, Parts, Text -> Text
/// ```
pub fn header(name: &Text, all: &Parts, programs: &Text) -> Text {
    cpp_templates::cpp_header(name, &lexer::join(&all.forward, &Text::from("\n\n")), &lexer::join(&all.handles, &Text::from("\n\n")), &lexer::join(&order_values(&all.values, &fold(&all.values, &Map::new(), &(|m: &Map<Text, bool>, v_: &ValueDecl| insert(m, &v_.path_, &false))), &Array::new()), &Text::from("\n\n")), &lexer::join(&all.cases, &Text::from("\n\n")), &cpp_prelude_template::cpp_prelude_rows(&Text::from("")), &lexer::join(&all.protos, &Text::from("\n")), &lexer::join(&all.classes, &Text::from("\n\n")), programs, &lexer::join(&all.generic, &Text::from("\n\n")))
}

/// The step machine of `Header`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Header: unbounded fn Text, Parts, Text -> Text
/// ```
pub struct Header {
    pub name: Text,
    pub all: Parts,
    pub programs: Text,
}

impl prism_rtl::Job<Text> for Header {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let name = &self.name;
        let all = &self.all;
        let programs = &self.programs;
        let all = all.clone();
        let name = name.clone();
        let programs = programs.clone();
        call_then(start_order_values(all.values.clone(), fold(&all.values, &Map::new(), &(|m: &Map<Text, bool>, v_: &ValueDecl| insert(m, &v_.path_, &false))), Array::new()), move |order_values_87480: Array<Text>| prism_rtl::Turn::Finished(cpp_templates::cpp_header(&name, &lexer::join(&all.forward, &Text::from("\n\n")), &lexer::join(&all.handles, &Text::from("\n\n")), &lexer::join(&order_values_87480, &Text::from("\n\n")), &lexer::join(&all.cases, &Text::from("\n\n")), &cpp_prelude_template::cpp_prelude_rows(&Text::from("")), &lexer::join(&all.protos, &Text::from("\n")), &lexer::join(&all.classes, &Text::from("\n\n")), &programs, &lexer::join(&all.generic, &Text::from("\n\n")))))
    }
}

/// `Start Header, x`: what the function value is when passed to `@Run`.
pub fn start_header(name: Text, all: Parts, programs: Text) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(Header { name, all, programs })
}

/// ```prism
/// OrderValues: unbounded fn [ValueDecl], (Text ==> Bool), [Text] -> [Text]
/// ```
pub fn order_values(left: &Array<ValueDecl>, done: &Map<Text, bool>, acc: &Array<Text>) -> Array<Text> {
    let ready = filter(left, &(|v_: &ValueDecl| fold(&v_.deps, &true, &(|ok: &bool, d: &Text| *ok && ((d == &v_.path_) || declared(done, d))))));
    if &len(left) == &Nat::from(0u32) {
        acc.clone()
    } else {
        if &len(&ready) == &Nat::from(0u32) {
            append(acc, &each(left, &(|v_: &ValueDecl| v_.text.clone())))
        } else {
            {
                let later_ = filter(left, &(|v_: &ValueDecl| !fold(&v_.deps, &true, &(|ok: &bool, d: &Text| *ok && ((d == &v_.path_) || declared(done, d))))));
                let done2 = fold(&ready, done, &(|m: &Map<Text, bool>, v_: &ValueDecl| insert(m, &v_.path_, &true)));
                order_values(&later_, &done2, &append(acc, &each(&ready, &(|v_: &ValueDecl| v_.text.clone()))))
            }
        }
    }
}

/// The step machine of `OrderValues`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// OrderValues: unbounded fn [ValueDecl], (Text ==> Bool), [Text] -> [Text]
/// ```
pub struct OrderValues {
    pub left: Array<ValueDecl>,
    pub done: Map<Text, bool>,
    pub acc: Array<Text>,
}

impl prism_rtl::Job<Array<Text>> for OrderValues {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let left = &self.left;
        let done = &self.done;
        let acc = &self.acc;
        let ready = filter(left, &(|v_: &ValueDecl| fold(&v_.deps, &true, &(|ok: &bool, d: &Text| *ok && ((d == &v_.path_) || declared(done, d))))));
        if &len(left) == &Nat::from(0u32) {
            prism_rtl::Turn::Finished(acc.clone())
        } else {
            if &len(&ready) == &Nat::from(0u32) {
                prism_rtl::Turn::Finished(append(acc, &each(left, &(|v_: &ValueDecl| v_.text.clone()))))
            } else {
                {
                    let later_ = filter(left, &(|v_: &ValueDecl| !fold(&v_.deps, &true, &(|ok: &bool, d: &Text| *ok && ((d == &v_.path_) || declared(done, d))))));
                    let done2 = fold(&ready, done, &(|m: &Map<Text, bool>, v_: &ValueDecl| insert(m, &v_.path_, &true)));
                    prism_rtl::Turn::More(Rc::new(OrderValues { left: later_.clone(), done: done2.clone(), acc: append(acc, &each(&ready, &(|v_: &ValueDecl| v_.text.clone()))) }))
                }
            }
        }
    }
}

/// `Start OrderValues, x`: what the function value is when passed to `@Run`.
pub fn start_order_values(left: Array<ValueDecl>, done: Map<Text, bool>, acc: Array<Text>) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(OrderValues { left, done, acc })
}

/// ```prism
/// Declared: fn (Text ==> Bool), Text -> Bool
/// ```
pub fn declared(done: &Map<Text, bool>, d: &Text) -> bool {
    match get(done, d) {
        Some(b) => b,
        None => true,
    }
}
