//! The module `Lower.Functions`, from `target/bootstrap/src/prismc/lower/functions.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// ```prism
/// BoundOf: fn Lx, Text -> [Text]
/// ```
pub fn bound_of_f(lx_p0: &crate::lower::Lx, text1: &Text) -> Array<Text> {
    match text1 {
        c0_1 if (c0_1 == &Text::lit("Prelude.Eq")) => Array::from(vec![Text::lit("Eq")]),
        c1_1 if (c1_1 == &Text::lit("Prelude.Ord")) => Array::from(vec![Text::lit("Ord")]),
        c2_1 if (c2_1 == &Text::lit("Prelude.Show")) => Array::from(vec![Text::lit("Show")]),
        c3_1 if (c3_1 == &Text::lit("Prelude.Num")) => Array::from(vec![Text::lit("Num")]),
        c4_1 if (c4_1 == &Text::lit("Prelude.Pod")) => Array::from(vec![Text::lit("ToPod"), Text::lit("FromPod")]),
        cls_p6 => match crate::prelude::get(&lx_p0.g_p.traits_p, cls_p6) {
            Some(tr_p7) => Array::from(vec![crate::lower::path_in_f(lx_p0, &tr_p7.home_p, &crate::lower::camel_f(&crate::check::types::bare_name_f(cls_p6)))]),
            None => Array::new(),
        },
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// SchemeGenerics: fn Lx, Scheme -> [((Text, [Text]))]
/// ```
pub fn scheme_generics_f(lx_p0: &crate::lower::Lx, sc_p1: &crate::check::types::Scheme) -> Array<(Text, Array<Text>)> {
    crate::prelude::each(&sc_p1.qs_p, &(|q_p2: &Text| {
        let bs_p3 = crate::prelude::fold(&sc_p1.bounds_p, &Array::from(vec![Text::lit("Clone")]), &(|acc_p5: &Array<Text>, (v_p6, cls_p7): &(Text, Text)| if v_p6 == q_p2 {
            crate::check::types::union_texts_f(acc_p5, &bound_of_f(lx_p0, cls_p7))
        } else {
            acc_p5.clone()
        }));
        let keyed_p4 = if keys_by_f(&sc_p1.ty_p, q_p2) {
            crate::check::types::union_texts_f(&bs_p3, &Array::from(vec![Text::lit("Ord")]))
        } else {
            bs_p3.clone()
        };
        (crate::lower::camel_f(q_p2), keyed_p4.clone())
    }))
}

/// ```prism
/// KeysBy: fn Ty, Text -> Bool
/// ```
pub fn keys_by_f(t_p0: &crate::check::types::Ty, q_p1: &Text) -> bool {
    match t_p0 {
        crate::check::types::Ty::TyMap(k_p2, v_p3) => ((&**k_p2 == &crate::check::types::Ty::TyQ(q_p1.clone())) || keys_by_f(&**k_p2, q_p1)) || keys_by_f(&**v_p3, q_p1),
        crate::check::types::Ty::TyCon(_, ts_p4) => crate::prelude::fold(ts_p4, &false, &(|found_p5: &bool, x_p6: &crate::check::types::Ty| *found_p5 || keys_by_f(x_p6, q_p1))),
        crate::check::types::Ty::TyFn(_, ps_p7, r_p8) => crate::prelude::fold(ps_p7, &false, &(|found_p9: &bool, x_pa: &crate::check::types::Ty| *found_p9 || keys_by_f(x_pa, q_p1))) || keys_by_f(&**r_p8, q_p1),
        crate::check::types::Ty::TyTuple(ts_pb) => crate::prelude::fold(ts_pb, &false, &(|found_pc: &bool, x_pd: &crate::check::types::Ty| *found_pc || keys_by_f(x_pd, q_p1))),
        crate::check::types::Ty::TyArray(x_pe) => keys_by_f(&**x_pe, q_p1),
        crate::check::types::Ty::TySig(_, x_pf) => keys_by_f(&**x_pf, q_p1),
        crate::check::types::Ty::TyAt(x_pg, _) => keys_by_f(&**x_pg, q_p1),
        _ => false,
    }
}

/// ```prism
/// ParamNames: unbounded fn Lx, [FnClause], [OutTy] -> [((Text, Bool))]
/// ```
pub fn param_names_f(lx_p0: &crate::lower::Lx, clauses_p1: &Array<crate::syntax::decls::FnClause>, pts_p2: &Array<crate::lower::model::OutTy>) -> Array<(Text, bool)> {
    crate::prelude::run_to_end(crate::prelude::each_job(crate::check::errors::range0_f(&crate::prelude::len(pts_p2)), {
        let clauses_p1x = clauses_p1.clone();
        let lx_p0x = lx_p0.clone();
        let pts_p2x = pts_p2.clone();
        Rc::new(move |p0: Nat| {
            let clauses_p1xy = clauses_p1x.clone();
            let lx_p0xy = lx_p0x.clone();
            let pts_p2xy = pts_p2x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let i_p3 = p0;
                {
                    let names_p4 = crate::prelude::each(&clauses_p1xy, &(|c_p8: &crate::syntax::decls::FnClause| plain_binder_f(&lx_p0xy, &crate::prelude::or(&crate::prelude::index(&c_p8.params_p, &i_p3), &crate::lower::patterns::dummy_pat_p()))));
                    let first_p5 = crate::prelude::or(&crate::prelude::index(&names_p4, &Nat::from(0u32)), &Text::lit(""));
                    let same_p6 = (&first_p5 != &Text::lit("")) && crate::prelude::fold(&names_p4, &true, &(|ok_p9: &bool, n_pa: &Text| *ok_p9 && (n_pa == &first_p5)));
                    let span_p7 = match &*crate::prelude::or(&crate::prelude::index(&crate::prelude::or(&crate::prelude::index(&clauses_p1xy, &Nat::from(0u32)), &dummy_clause_p()).params_p, &i_p3), &crate::lower::patterns::dummy_pat_p()).kind_p {
                        crate::syntax::PatternKind::PName(n_pb) => n_pb.span_p.clone(),
                        _ => crate::syntax::Range { start_p: Nat::from(0u32), end_p: Nat::from(0u32) },
                    };
                    if same_p6 {
                        crate::prelude::call_then(crate::lower::start_local_name_at_f(lx_p0xy.clone(), first_p5.clone(), span_p7.clone()), move |local_name_at_f_3553: Text| prism_rtl::Turn::Finished((local_name_at_f_3553, false)))
                    } else {
                        prism_rtl::Turn::Finished((param_word_f(&crate::prelude::or(&crate::prelude::index(&pts_p2xy, &i_p3), &crate::lower::model::OutTy::OutUnit), &i_p3), true))
                    }
                }
            }))
        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<(Text, bool)>>>
    }))
}

/// The step machine of `ParamNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParamNames: unbounded fn Lx, [FnClause], [OutTy] -> [((Text, Bool))]
/// ```
pub struct ParamNames {
    pub lx_p0: crate::lower::Lx,
    pub clauses_p1: Array<crate::syntax::decls::FnClause>,
    pub pts_p2: Array<crate::lower::model::OutTy>,
}

impl prism_rtl::Job<Array<(Text, bool)>> for ParamNames {
    fn cycle(&self) -> prism_rtl::Turn<Array<(Text, bool)>> {
        let lx_p0 = &self.lx_p0;
        let clauses_p1 = &self.clauses_p1;
        let pts_p2 = &self.pts_p2;
        crate::prelude::each_job(crate::check::errors::range0_f(&crate::prelude::len(pts_p2)), {
            let clauses_p1x = clauses_p1.clone();
            let lx_p0x = lx_p0.clone();
            let pts_p2x = pts_p2.clone();
            Rc::new(move |p0: Nat| {
                let clauses_p1xy = clauses_p1x.clone();
                let lx_p0xy = lx_p0x.clone();
                let pts_p2xy = pts_p2x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let i_p3 = p0;
                    {
                        let names_p4 = crate::prelude::each(&clauses_p1xy, &(|c_p8: &crate::syntax::decls::FnClause| plain_binder_f(&lx_p0xy, &crate::prelude::or(&crate::prelude::index(&c_p8.params_p, &i_p3), &crate::lower::patterns::dummy_pat_p()))));
                        let first_p5 = crate::prelude::or(&crate::prelude::index(&names_p4, &Nat::from(0u32)), &Text::lit(""));
                        let same_p6 = (&first_p5 != &Text::lit("")) && crate::prelude::fold(&names_p4, &true, &(|ok_p9: &bool, n_pa: &Text| *ok_p9 && (n_pa == &first_p5)));
                        let span_p7 = match &*crate::prelude::or(&crate::prelude::index(&crate::prelude::or(&crate::prelude::index(&clauses_p1xy, &Nat::from(0u32)), &dummy_clause_p()).params_p, &i_p3), &crate::lower::patterns::dummy_pat_p()).kind_p {
                            crate::syntax::PatternKind::PName(n_pb) => n_pb.span_p.clone(),
                            _ => crate::syntax::Range { start_p: Nat::from(0u32), end_p: Nat::from(0u32) },
                        };
                        if same_p6 {
                            crate::prelude::call_then(crate::lower::start_local_name_at_f(lx_p0xy.clone(), first_p5.clone(), span_p7.clone()), move |local_name_at_f_3553: Text| prism_rtl::Turn::Finished((local_name_at_f_3553, false)))
                        } else {
                            prism_rtl::Turn::Finished((param_word_f(&crate::prelude::or(&crate::prelude::index(&pts_p2xy, &i_p3), &crate::lower::model::OutTy::OutUnit), &i_p3), true))
                        }
                    }
                }))
            }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<(Text, bool)>>>
        }).cycle()
    }
}

/// `Start ParamNames, x`: what the function value is when passed to `@Run`.
pub fn start_param_names_f(lx_p0: crate::lower::Lx, clauses_p1: Array<crate::syntax::decls::FnClause>, pts_p2: Array<crate::lower::model::OutTy>) -> Rc<dyn prism_rtl::Job<Array<(Text, bool)>>> {
    Rc::new(ParamNames { lx_p0, clauses_p1, pts_p2 })
}

/// ```prism
/// PlainBinder: fn Lx, Pattern -> Text
/// ```
pub fn plain_binder_f(lx_p0: &crate::lower::Lx, p_p1: &crate::syntax::Pattern_) -> Text {
    match &*p_p1.kind_p {
        crate::syntax::PatternKind::PName(n_p2) => {
            let (qk_o4, why_p5) = crate::check::env::names::resolve_value_f(&lx_p0.g_p, &lx_p0.home_p, n_p2);
            let is_ctor_p3 = match &qk_o4 {
                Some(qk_p6) => crate::check::env::has_key_f(&lx_p0.g_p.ctors_p, qk_p6) && (crate::check::env::is_upper_text_f(&crate::lower::base_f(&crate::check::env::sname_key_f(n_p2))) || crate::lower::patterns::is_unit_ctor_f(lx_p0, qk_p6)),
                None => false,
            };
            if is_ctor_p3 { Text::lit("") } else { crate::check::env::sname_key_f(n_p2) }
        },
        crate::syntax::PatternKind::PGroup(q_p7) => plain_binder_f(lx_p0, &**q_p7),
        _ => Text::lit(""),
    }
}

/// ```prism
/// ParamWord: fn OutTy, Nat -> Text
/// ```
pub fn param_word_f(t_p0: &crate::lower::model::OutTy, i_p1: &Nat) -> Text {
    let base_p2 = match t_p0 {
        crate::lower::model::OutTy::OutNamed(n_p3, _) => crate::lower::snake_f(&crate::prelude::or(&crate::syntax::lexer::chars::last_o(&crate::prelude::split_on(n_p3, &Text::lit("::"))), &Text::lit("arg"))),
        crate::lower::model::OutTy::OutText => Text::lit("text"),
        crate::lower::model::OutTy::OutNat => Text::lit("n"),
        crate::lower::model::OutTy::OutInt => Text::lit("i"),
        crate::lower::model::OutTy::OutArray(_) => Text::lit("xs"),
        crate::lower::model::OutTy::OutMap(_, _) => Text::lit("map"),
        crate::lower::model::OutTy::OutOpt(_) => Text::lit("opt"),
        _ => Text::lit("arg"),
    };
    Text::from(format!("{}{}", &base_p2, i_p1))
}

/// ```prism
/// ClausesBody: unbounded fn Lx, Env, [FnClause], [((Text, Bool))], [Ty], (fn Lx, Env, FnBody -> Ex), Text, OutTy -> Ex
/// ```
pub fn clauses_body_f(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, clauses_p2: &Array<crate::syntax::decls::FnClause>, names_p3: &Array<(Text, bool)>, ptys_p4: &Array<crate::check::types::Ty>, body_f5: &Rc<dyn Fn((crate::lower::Lx, crate::lower::types::Env, crate::syntax::decls::FnBody)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>, label_p6: &Text, t_p7: &crate::lower::model::OutTy) -> crate::lower::model::Ex {
    let env1_p8 = crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(names_p3)), env_p1.clone(), {
        let names_p3x = names_p3.clone();
        let lx_p0x = lx_p0.clone();
        let clauses_p2x = clauses_p2.clone();
        let ptys_p4x = ptys_p4.clone();
        Rc::new(move |(p0, p1): (crate::lower::types::Env, Nat)| {
            let names_p3xy = names_p3x.clone();
            let lx_p0xy = lx_p0x.clone();
            let clauses_p2xy = clauses_p2x.clone();
            let ptys_p4xy = ptys_p4x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let en_pa = p0;
                let i_pb = p1;
                {
                    let (rs_pc, matched_pd) = crate::prelude::or(&crate::prelude::index(&names_p3xy, &i_pb), &(Text::lit(""), true));
                    if matched_pd {
                        prism_rtl::Turn::Finished(en_pa.clone())
                    } else {
                        crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0xy.clone(), crate::lower::types::peel_f(&crate::prelude::or(&crate::prelude::index(&ptys_p4xy, &i_pb), &crate::check::types::Ty::TyErr))), move |out_ty_of_f_5056: crate::lower::model::OutTy| prism_rtl::Turn::Finished(crate::lower::types::bind_f(&en_pa, &plain_binder_f(&lx_p0xy, &crate::prelude::or(&crate::prelude::index(&crate::prelude::or(&crate::prelude::index(&clauses_p2xy, &Nat::from(0u32)), &dummy_clause_p()).params_p, &i_pb), &crate::lower::patterns::dummy_pat_p())), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(rs_pc.clone()), crate::lower::types::Holding::ByRef, out_ty_of_f_5056))))
                    }
                }
            }))
        }) as Rc<dyn Fn((crate::lower::types::Env, Nat)) -> Rc<dyn prism_rtl::Job<crate::lower::types::Env>>>
    }));
    let scrut_ix_p9 = crate::prelude::filter(&crate::check::errors::range0_f(&crate::prelude::len(names_p3)), &(|i_pe: &Nat| match crate::prelude::index(names_p3, i_pe) {
        Some((_, true)) => true,
        _ => false,
    }));
    if &crate::prelude::len(&scrut_ix_p9) == &Nat::from(0u32) {
        {
            let c_pf = crate::prelude::or(&crate::prelude::index(clauses_p2, &Nat::from(0u32)), &dummy_clause_p());
            crate::prelude::run_to_end(body_f5((lx_p0.clone(), env1_p8.clone(), c_pf.body_p.clone())))
        }
    } else {
        {
            let scrut_pg = 'm5353: {
                if let m5353_0 = &scrut_ix_p9 && (m5353_0.len() == 1) && let Some(i_pi) = crate::prelude::index(m5353_0, &Nat::from(0u32)) {
                    break 'm5353 crate::lower::model::Ex::XVar(crate::prelude::or(&crate::prelude::index(&crate::prelude::each(names_p3, &(|(n_pj, _): &(Text, bool)| n_pj.clone())), &i_pi), &Text::lit("arg")));
                }
                crate::lower::model::Ex::XTuple(crate::prelude::each(&scrut_ix_p9, &(|i_pk: &Nat| crate::lower::model::Ex::XVar(crate::prelude::or(&crate::prelude::index(&crate::prelude::each(names_p3, &(|(n_pl, _): &(Text, bool)| n_pl.clone())), i_pk), &Text::lit("arg"))))))
            };
            let arms_ph = crate::prelude::run_to_end(crate::prelude::each_job(crate::check::errors::range0_f(&crate::prelude::len(clauses_p2)), {
                let clauses_p2x = clauses_p2.clone();
                let scrut_ix_p9x = scrut_ix_p9.clone();
                let lx_p0x = lx_p0.clone();
                let ptys_p4x = ptys_p4.clone();
                let label_p6x = label_p6.clone();
                let body_f5x = body_f5.clone();
                let env1_p8x = env1_p8.clone();
                Rc::new(move |p0: Nat| {
                    let clauses_p2xy = clauses_p2x.clone();
                    let scrut_ix_p9xy = scrut_ix_p9x.clone();
                    let lx_p0xy = lx_p0x.clone();
                    let ptys_p4xy = ptys_p4x.clone();
                    let label_p6xy = label_p6x.clone();
                    let body_f5xy = body_f5x.clone();
                    let env1_p8xy = env1_p8x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let ci_pm = p0;
                        {
                            let c_pn = crate::prelude::or(&crate::prelude::index(&clauses_p2xy, &ci_pm), &dummy_clause_p());
                            crate::prelude::call_value(crate::prelude::each_job(scrut_ix_p9xy.clone(), {
                                let lx_p0xyx = lx_p0xy.clone();
                                let c_pnx = c_pn.clone();
                                let ptys_p4xyx = ptys_p4xy.clone();
                                let label_p6xyx = label_p6xy.clone();
                                let ci_pmx = ci_pm.clone();
                                Rc::new(move |p0: Nat| {
                                    let lx_p0xyxy = lx_p0xyx.clone();
                                    let c_pnxy = c_pnx.clone();
                                    let ptys_p4xyxy = ptys_p4xyx.clone();
                                    let label_p6xyxy = label_p6xyx.clone();
                                    let ci_pmxy = ci_pmx.clone();
                                    crate::prelude::entered(crate::prelude::once_job(move || {
                                        let i_ps = p0;
                                        prism_rtl::Turn::More(Rc::new(crate::lower::patterns::RustPat { lx_p0: lx_p0xyxy.clone(), p_p1: crate::prelude::or(&crate::prelude::index(&c_pnxy.params_p, &i_ps), &crate::lower::patterns::dummy_pat_p()), ty_p2: crate::prelude::or(&crate::prelude::index(&ptys_p4xyxy, &i_ps), &crate::check::types::Ty::TyErr), mode_p3: crate::lower::types::Holding::ByRef, fresh_p4: Text::from(format!("{}{}_{}", &label_p6xyxy, &ci_pmxy, &i_ps)) }))
                                    }))
                                }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<crate::lower::patterns::PatOut>>>
                            }), move |each_5668: Array<crate::lower::patterns::PatOut>| {
                                let pos_po = each_5668;
                                let pa_pp = 'm5794: {
                                    if let m5794_0 = &pos_po && (m5794_0.len() == 1) && let Some(o_pt) = crate::prelude::index(m5794_0, &Nat::from(0u32)) {
                                        break 'm5794 o_pt.pa_p.clone();
                                    }
                                    crate::lower::model::Pa::PaTuple(crate::prelude::each(&pos_po, &(|o_pu: &crate::lower::patterns::PatOut| o_pu.pa_p.clone())))
                                };
                                let conds_pq = crate::prelude::fold(&pos_po, &Array::new(), &(|acc_pv: &Array<crate::lower::model::Cc>, o_p10: &crate::lower::patterns::PatOut| crate::prelude::append(acc_pv, &o_p10.conds_p)));
                                let binds_pr = crate::prelude::fold(&pos_po, &Array::new(), &(|acc_p11: &Array<(Text, crate::lower::types::Bn)>, o_p12: &crate::lower::patterns::PatOut| crate::prelude::append(acc_p11, &o_p12.binds_p)));
                                crate::prelude::call_value((&body_f5xy)((lx_p0xy.clone(), crate::lower::expr::bind_all_f(&env1_p8xy, &binds_pr), c_pn.body_p.clone())), move |body_6074: crate::lower::model::Ex| prism_rtl::Turn::Finished(crate::lower::model::XArm { pat_p: pa_pp.clone(), conds_p: conds_pq.clone(), body_p: body_6074 }))
                            })
                        }
                    }))
                }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<crate::lower::model::XArm>>>
            }));
            crate::lower::types::own_f(&crate::lower::expr::arms_value_f(&scrut_pg, &arms_ph, &Text::from(format!("\'{}", label_p6)), t_p7))
        }
    }
}

/// The step machine of `ClausesBody`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ClausesBody: unbounded fn Lx, Env, [FnClause], [((Text, Bool))], [Ty], (fn Lx, Env, FnBody -> Ex), Text, OutTy -> Ex
/// ```
pub struct ClausesBody {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub clauses_p2: Array<crate::syntax::decls::FnClause>,
    pub names_p3: Array<(Text, bool)>,
    pub ptys_p4: Array<crate::check::types::Ty>,
    pub body_f5: Rc<dyn Fn((crate::lower::Lx, crate::lower::types::Env, crate::syntax::decls::FnBody)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>,
    pub label_p6: Text,
    pub t_p7: crate::lower::model::OutTy,
}

impl prism_rtl::Job<crate::lower::model::Ex> for ClausesBody {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::Ex> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let clauses_p2 = &self.clauses_p2;
        let names_p3 = &self.names_p3;
        let ptys_p4 = &self.ptys_p4;
        let body_f5 = &self.body_f5;
        let label_p6 = &self.label_p6;
        let t_p7 = &self.t_p7;
        let body_f5x = body_f5.clone();
        let clauses_p2x = clauses_p2.clone();
        let env_p1x = env_p1.clone();
        let label_p6x = label_p6.clone();
        let lx_p0x = lx_p0.clone();
        let names_p3x = names_p3.clone();
        let ptys_p4x = ptys_p4.clone();
        let t_p7x = t_p7.clone();
        crate::prelude::call_value(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(&names_p3x)), env_p1x.clone(), {
            let names_p3xx = names_p3x.clone();
            let lx_p0xx = lx_p0x.clone();
            let clauses_p2xx = clauses_p2x.clone();
            let ptys_p4xx = ptys_p4x.clone();
            Rc::new(move |(p0, p1): (crate::lower::types::Env, Nat)| {
                let names_p3xxy = names_p3xx.clone();
                let lx_p0xxy = lx_p0xx.clone();
                let clauses_p2xxy = clauses_p2xx.clone();
                let ptys_p4xxy = ptys_p4xx.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let en_pa = p0;
                    let i_pb = p1;
                    {
                        let (rs_pc, matched_pd) = crate::prelude::or(&crate::prelude::index(&names_p3xxy, &i_pb), &(Text::lit(""), true));
                        if matched_pd {
                            prism_rtl::Turn::Finished(en_pa.clone())
                        } else {
                            crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0xxy.clone(), crate::lower::types::peel_f(&crate::prelude::or(&crate::prelude::index(&ptys_p4xxy, &i_pb), &crate::check::types::Ty::TyErr))), move |out_ty_of_f_5056: crate::lower::model::OutTy| prism_rtl::Turn::Finished(crate::lower::types::bind_f(&en_pa, &plain_binder_f(&lx_p0xxy, &crate::prelude::or(&crate::prelude::index(&crate::prelude::or(&crate::prelude::index(&clauses_p2xxy, &Nat::from(0u32)), &dummy_clause_p()).params_p, &i_pb), &crate::lower::patterns::dummy_pat_p())), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(rs_pc.clone()), crate::lower::types::Holding::ByRef, out_ty_of_f_5056))))
                        }
                    }
                }))
            }) as Rc<dyn Fn((crate::lower::types::Env, Nat)) -> Rc<dyn prism_rtl::Job<crate::lower::types::Env>>>
        }), move |fold_4812: crate::lower::types::Env| {
            let env1_p8 = fold_4812;
            let scrut_ix_p9 = crate::prelude::filter(&crate::check::errors::range0_f(&crate::prelude::len(&names_p3x)), &(|i_pe: &Nat| match crate::prelude::index(&names_p3x, i_pe) {
                Some((_, true)) => true,
                _ => false,
            }));
            if &crate::prelude::len(&scrut_ix_p9) == &Nat::from(0u32) {
                {
                    let c_pf = crate::prelude::or(&crate::prelude::index(&clauses_p2x, &Nat::from(0u32)), &dummy_clause_p());
                    (&body_f5x)((lx_p0x.clone(), env1_p8.clone(), c_pf.body_p.clone())).cycle()
                }
            } else {
                {
                    let scrut_pg = 'm5353: {
                        if let m5353_0 = &scrut_ix_p9 && (m5353_0.len() == 1) && let Some(i_pi) = crate::prelude::index(m5353_0, &Nat::from(0u32)) {
                            break 'm5353 crate::lower::model::Ex::XVar(crate::prelude::or(&crate::prelude::index(&crate::prelude::each(&names_p3x, &(|(n_pj, _): &(Text, bool)| n_pj.clone())), &i_pi), &Text::lit("arg")));
                        }
                        crate::lower::model::Ex::XTuple(crate::prelude::each(&scrut_ix_p9, &(|i_pk: &Nat| crate::lower::model::Ex::XVar(crate::prelude::or(&crate::prelude::index(&crate::prelude::each(&names_p3x, &(|(n_pl, _): &(Text, bool)| n_pl.clone())), i_pk), &Text::lit("arg"))))))
                    };
                    crate::prelude::call_value(crate::prelude::each_job(crate::check::errors::range0_f(&crate::prelude::len(&clauses_p2x)), {
                        let clauses_p2xx = clauses_p2x.clone();
                        let scrut_ix_p9x = scrut_ix_p9.clone();
                        let lx_p0xx = lx_p0x.clone();
                        let ptys_p4xx = ptys_p4x.clone();
                        let label_p6xx = label_p6x.clone();
                        let body_f5xx = body_f5x.clone();
                        let env1_p8x = env1_p8.clone();
                        Rc::new(move |p0: Nat| {
                            let clauses_p2xxy = clauses_p2xx.clone();
                            let scrut_ix_p9xy = scrut_ix_p9x.clone();
                            let lx_p0xxy = lx_p0xx.clone();
                            let ptys_p4xxy = ptys_p4xx.clone();
                            let label_p6xxy = label_p6xx.clone();
                            let body_f5xxy = body_f5xx.clone();
                            let env1_p8xy = env1_p8x.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let ci_pm = p0;
                                {
                                    let c_pn = crate::prelude::or(&crate::prelude::index(&clauses_p2xxy, &ci_pm), &dummy_clause_p());
                                    crate::prelude::call_value(crate::prelude::each_job(scrut_ix_p9xy.clone(), {
                                        let lx_p0xxyx = lx_p0xxy.clone();
                                        let c_pnx = c_pn.clone();
                                        let ptys_p4xxyx = ptys_p4xxy.clone();
                                        let label_p6xxyx = label_p6xxy.clone();
                                        let ci_pmx = ci_pm.clone();
                                        Rc::new(move |p0: Nat| {
                                            let lx_p0xxyxy = lx_p0xxyx.clone();
                                            let c_pnxy = c_pnx.clone();
                                            let ptys_p4xxyxy = ptys_p4xxyx.clone();
                                            let label_p6xxyxy = label_p6xxyx.clone();
                                            let ci_pmxy = ci_pmx.clone();
                                            crate::prelude::entered(crate::prelude::once_job(move || {
                                                let i_ps = p0;
                                                prism_rtl::Turn::More(Rc::new(crate::lower::patterns::RustPat { lx_p0: lx_p0xxyxy.clone(), p_p1: crate::prelude::or(&crate::prelude::index(&c_pnxy.params_p, &i_ps), &crate::lower::patterns::dummy_pat_p()), ty_p2: crate::prelude::or(&crate::prelude::index(&ptys_p4xxyxy, &i_ps), &crate::check::types::Ty::TyErr), mode_p3: crate::lower::types::Holding::ByRef, fresh_p4: Text::from(format!("{}{}_{}", &label_p6xxyxy, &ci_pmxy, &i_ps)) }))
                                            }))
                                        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<crate::lower::patterns::PatOut>>>
                                    }), move |each_5668: Array<crate::lower::patterns::PatOut>| {
                                        let pos_po = each_5668;
                                        let pa_pp = 'm5794: {
                                            if let m5794_0 = &pos_po && (m5794_0.len() == 1) && let Some(o_pt) = crate::prelude::index(m5794_0, &Nat::from(0u32)) {
                                                break 'm5794 o_pt.pa_p.clone();
                                            }
                                            crate::lower::model::Pa::PaTuple(crate::prelude::each(&pos_po, &(|o_pu: &crate::lower::patterns::PatOut| o_pu.pa_p.clone())))
                                        };
                                        let conds_pq = crate::prelude::fold(&pos_po, &Array::new(), &(|acc_pv: &Array<crate::lower::model::Cc>, o_p10: &crate::lower::patterns::PatOut| crate::prelude::append(acc_pv, &o_p10.conds_p)));
                                        let binds_pr = crate::prelude::fold(&pos_po, &Array::new(), &(|acc_p11: &Array<(Text, crate::lower::types::Bn)>, o_p12: &crate::lower::patterns::PatOut| crate::prelude::append(acc_p11, &o_p12.binds_p)));
                                        crate::prelude::call_value((&body_f5xxy)((lx_p0xxy.clone(), crate::lower::expr::bind_all_f(&env1_p8xy, &binds_pr), c_pn.body_p.clone())), move |body_6074: crate::lower::model::Ex| prism_rtl::Turn::Finished(crate::lower::model::XArm { pat_p: pa_pp.clone(), conds_p: conds_pq.clone(), body_p: body_6074 }))
                                    })
                                }
                            }))
                        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<crate::lower::model::XArm>>>
                    }), move |each_5563: Array<crate::lower::model::XArm>| {
                        let arms_ph = each_5563;
                        prism_rtl::Turn::Finished(crate::lower::types::own_f(&crate::lower::expr::arms_value_f(&scrut_pg, &arms_ph, &Text::from(format!("\'{}", &label_p6x)), &t_p7x)))
                    })
                }
            }
        })
    }
}

/// `Start ClausesBody, x`: what the function value is when passed to `@Run`.
pub fn start_clauses_body_f(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, clauses_p2: Array<crate::syntax::decls::FnClause>, names_p3: Array<(Text, bool)>, ptys_p4: Array<crate::check::types::Ty>, body_f5: Rc<dyn Fn((crate::lower::Lx, crate::lower::types::Env, crate::syntax::decls::FnBody)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>, label_p6: Text, t_p7: crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>> {
    Rc::new(ClausesBody { lx_p0, env_p1, clauses_p2, names_p3, ptys_p4, body_f5, label_p6, t_p7 })
}

/// ```prism
/// let dummyClause
/// ```
pub fn dummy_clause_p() -> crate::syntax::decls::FnClause {
    crate::syntax::decls::FnClause { name_p: crate::syntax::decls::DefName::DefOp(Text::lit(""), crate::syntax::Range { start_p: Nat::from(0u32), end_p: Nat::from(0u32) }), params_p: Array::new(), body_p: crate::syntax::decls::FnBody::BodyExpr(crate::syntax::Expr { kind_p: Rc::new(crate::syntax::ExprKind::EError), span_p: crate::syntax::Range { start_p: Nat::from(0u32), end_p: Nat::from(0u32) } }), span_p: crate::syntax::Range { start_p: Nat::from(0u32), end_p: Nat::from(0u32) } }
}

/// ```prism
/// FnBodyValue: unbounded fn Lx, Env, FnBody -> Ex
/// ```
pub fn fn_body_value_f(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, fn_body2: &crate::syntax::decls::FnBody) -> crate::lower::model::Ex {
    match fn_body2 {
        crate::syntax::decls::FnBody::BodyExpr(x_p2) => crate::lower::types::own_f(&crate::lower::expr::value_of_f(lx_p0, env_p1, x_p2)),
        crate::syntax::decls::FnBody::BodyBlock(b_p5) => crate::lower::types::own_f(&crate::lower::expr::block_value_f(lx_p0, env_p1, b_p5)),
    }
}

/// The step machine of `FnBodyValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FnBodyValue: unbounded fn Lx, Env, FnBody -> Ex
/// ```
pub struct FnBodyValue {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub fn_body2: crate::syntax::decls::FnBody,
}

impl prism_rtl::Job<crate::lower::model::Ex> for FnBodyValue {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::Ex> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let fn_body2 = &self.fn_body2;
        match fn_body2 {
            crate::syntax::decls::FnBody::BodyExpr(x_p2) => {
                let env_p1x = env_p1.clone();
                let lx_p0x = lx_p0.clone();
                let x_p2x = x_p2.clone();
                crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p0x.clone(), env_p1x.clone(), x_p2x.clone()), move |value_of_f_6433: crate::lower::types::Vl| prism_rtl::Turn::Finished(crate::lower::types::own_f(&value_of_f_6433)))
            },
            crate::syntax::decls::FnBody::BodyBlock(b_p5) => {
                let b_p5x = b_p5.clone();
                let env_p1x = env_p1.clone();
                let lx_p0x = lx_p0.clone();
                crate::prelude::call_then(crate::lower::expr::start_block_value_f(lx_p0x.clone(), env_p1x.clone(), b_p5x.clone()), move |block_value_f_6498: crate::lower::types::Vl| prism_rtl::Turn::Finished(crate::lower::types::own_f(&block_value_f_6498)))
            },
        }
    }
}

/// `Start FnBodyValue, x`: what the function value is when passed to `@Run`.
pub fn start_fn_body_value_f(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, fn_body2: crate::syntax::decls::FnBody) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>> {
    Rc::new(FnBodyValue { lx_p0, env_p1, fn_body2 })
}

/// ```prism
/// FnDefOf: unbounded fn Lx, Text, [FnClause], Scheme -> FnDef
/// ```
pub fn fn_def_of_f(lx_p0: &crate::lower::Lx, qk_p1: &Text, clauses_p2: &Array<crate::syntax::decls::FnClause>, sc_p3: &crate::check::types::Scheme) -> crate::lower::model::FnDef {
    let (ptys0_pf, res_pg) = match &sc_p3.ty_p {
        crate::check::types::Ty::TyFn(_, ps_pc, r_pd) => (ps_pc.clone(), (**r_pd).clone()),
        other_pe => (Array::new(), other_pe.clone()),
    };
    let ptys_p4 = if crate::lower::types::has_blueprint_f(&res_pg) {
        crate::prelude::each(&ptys0_pf, &(|p_ph: &crate::check::types::Ty| crate::lower::types::event_param_f(p_ph)))
    } else {
        ptys0_pf.clone()
    };
    let pts_p5 = crate::prelude::run_to_end(crate::prelude::each_job(ptys_p4.clone(), {
        let lx_p0x = lx_p0.clone();
        Rc::new(move |p0: crate::check::types::Ty| {
            let lx_p0xy = lx_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let p_pi = p0;
                prism_rtl::Turn::More(Rc::new(crate::lower::types::OutTyOf { lx_p0: lx_p0xy.clone(), t_p1: crate::lower::types::peel_f(&p_pi) }))
            }))
        }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::lower::model::OutTy>>>
    }));
    let names_p6 = param_names_f(lx_p0, clauses_p2, &pts_p5);
    let body_p7 = clauses_body_f(lx_p0, &crate::lower::types::empty_env_p(), clauses_p2, &names_p6, &ptys_p4, &(Rc::new(|(a0, a1, a2): (crate::lower::Lx, crate::lower::types::Env, crate::syntax::decls::FnBody)| crate::prelude::entered(start_fn_body_value_f(a0, a1, a2))) as Rc<dyn Fn((crate::lower::Lx, crate::lower::types::Env, crate::syntax::decls::FnBody)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>), &Text::lit("c"), &crate::lower::types::out_ty_of_f(lx_p0, &crate::lower::types::peel_f(&res_pg)));
    let params_p8 = crate::prelude::each(&crate::check::errors::range0_f(&crate::prelude::len(&pts_p5)), &(|i_pj: &Nat| (crate::prelude::or(&crate::prelude::index(&crate::prelude::each(&names_p6, &(|(n_pk, _): &(Text, bool)| n_pk.clone())), i_pj), &Text::lit("arg")), crate::lower::model::OutTy::OutRef(Rc::new(crate::prelude::or(&crate::prelude::index(&pts_p5, i_pj), &crate::lower::model::OutTy::OutUnit))))));
    let ret_p9 = crate::lower::types::out_ty_of_f(lx_p0, &crate::lower::types::peel_f(&res_pg));
    let used_pa = crate::prelude::fold(&crate::prelude::push(&pts_p5, &ret_p9), &Array::new(), &(|acc_pl: &Array<Text>, t_pm: &crate::lower::model::OutTy| crate::check::types::union_texts_f(acc_pl, &ty_params_in_f(t_pm))));
    let generics_pb = crate::prelude::filter(&scheme_generics_f(lx_p0, sc_p3), &(|(g_pn, _): &(Text, Array<Text>)| crate::check::types::has_text_f(&used_pa, g_pn)));
    crate::lower::model::FnDef { name_p: crate::prelude::or(&crate::prelude::get(&lx_p0.rs_names_p, qk_p1), &crate::lower::snake_f(&crate::check::types::bare_name_f(qk_p1))), generics_p: generics_pb.clone(), params_p: params_p8.clone(), ret_p: ret_p9.clone(), body_p: body_p7.clone(), doc_p: signature_text_f(lx_p0, qk_p1), public_p: true }
}

/// The step machine of `FnDefOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FnDefOf: unbounded fn Lx, Text, [FnClause], Scheme -> FnDef
/// ```
pub struct FnDefOf {
    pub lx_p0: crate::lower::Lx,
    pub qk_p1: Text,
    pub clauses_p2: Array<crate::syntax::decls::FnClause>,
    pub sc_p3: crate::check::types::Scheme,
}

impl prism_rtl::Job<crate::lower::model::FnDef> for FnDefOf {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::FnDef> {
        let lx_p0 = &self.lx_p0;
        let qk_p1 = &self.qk_p1;
        let clauses_p2 = &self.clauses_p2;
        let sc_p3 = &self.sc_p3;
        let (ptys0_pf, res_pg) = match &sc_p3.ty_p {
            crate::check::types::Ty::TyFn(_, ps_pc, r_pd) => (ps_pc.clone(), (**r_pd).clone()),
            other_pe => (Array::new(), other_pe.clone()),
        };
        let ptys_p4 = if crate::lower::types::has_blueprint_f(&res_pg) {
            crate::prelude::each(&ptys0_pf, &(|p_ph: &crate::check::types::Ty| crate::lower::types::event_param_f(p_ph)))
        } else {
            ptys0_pf.clone()
        };
        let clauses_p2x = clauses_p2.clone();
        let lx_p0x = lx_p0.clone();
        let qk_p1x = qk_p1.clone();
        let sc_p3x = sc_p3.clone();
        crate::prelude::call_value(crate::prelude::each_job(ptys_p4.clone(), {
            let lx_p0xx = lx_p0x.clone();
            Rc::new(move |p0: crate::check::types::Ty| {
                let lx_p0xxy = lx_p0xx.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let p_pi = p0;
                    prism_rtl::Turn::More(Rc::new(crate::lower::types::OutTyOf { lx_p0: lx_p0xxy.clone(), t_p1: crate::lower::types::peel_f(&p_pi) }))
                }))
            }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::lower::model::OutTy>>>
        }), move |each_7055: Array<crate::lower::model::OutTy>| {
            let pts_p5 = each_7055;
            crate::prelude::call_then(start_param_names_f(lx_p0x.clone(), clauses_p2x.clone(), pts_p5.clone()), move |param_names_f_7108: Array<(Text, bool)>| {
                let names_p6 = param_names_f_7108;
                crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0x.clone(), crate::lower::types::peel_f(&res_pg)), move |out_ty_of_f_7218: crate::lower::model::OutTy| crate::prelude::call_then(start_clauses_body_f(lx_p0x.clone(), crate::lower::types::empty_env_p(), clauses_p2x.clone(), names_p6.clone(), ptys_p4.clone(), Rc::new(|(a0, a1, a2): (crate::lower::Lx, crate::lower::types::Env, crate::syntax::decls::FnBody)| crate::prelude::entered(start_fn_body_value_f(a0, a1, a2))) as Rc<dyn Fn((crate::lower::Lx, crate::lower::types::Env, crate::syntax::decls::FnBody)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>, Text::lit("c"), out_ty_of_f_7218), move |clauses_body_f_7151: crate::lower::model::Ex| {
                    let body_p7 = clauses_body_f_7151;
                    let params_p8 = crate::prelude::each(&crate::check::errors::range0_f(&crate::prelude::len(&pts_p5)), &(|i_pj: &Nat| (crate::prelude::or(&crate::prelude::index(&crate::prelude::each(&names_p6, &(|(n_pk, _): &(Text, bool)| n_pk.clone())), i_pj), &Text::lit("arg")), crate::lower::model::OutTy::OutRef(Rc::new(crate::prelude::or(&crate::prelude::index(&pts_p5, i_pj), &crate::lower::model::OutTy::OutUnit))))));
                    crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0x.clone(), crate::lower::types::peel_f(&res_pg)), move |out_ty_of_f_7386: crate::lower::model::OutTy| {
                        let ret_p9 = out_ty_of_f_7386;
                        let used_pa = crate::prelude::fold(&crate::prelude::push(&pts_p5, &ret_p9), &Array::new(), &(|acc_pl: &Array<Text>, t_pm: &crate::lower::model::OutTy| crate::check::types::union_texts_f(acc_pl, &ty_params_in_f(t_pm))));
                        let generics_pb = crate::prelude::filter(&scheme_generics_f(&lx_p0x, &sc_p3x), &(|(g_pn, _): &(Text, Array<Text>)| crate::check::types::has_text_f(&used_pa, g_pn)));
                        prism_rtl::Turn::Finished(crate::lower::model::FnDef { name_p: crate::prelude::or(&crate::prelude::get(&lx_p0x.rs_names_p, &qk_p1x), &crate::lower::snake_f(&crate::check::types::bare_name_f(&qk_p1x))), generics_p: generics_pb.clone(), params_p: params_p8.clone(), ret_p: ret_p9.clone(), body_p: body_p7.clone(), doc_p: signature_text_f(&lx_p0x, &qk_p1x), public_p: true })
                    })
                }))
            })
        })
    }
}

/// `Start FnDefOf, x`: what the function value is when passed to `@Run`.
pub fn start_fn_def_of_f(lx_p0: crate::lower::Lx, qk_p1: Text, clauses_p2: Array<crate::syntax::decls::FnClause>, sc_p3: crate::check::types::Scheme) -> Rc<dyn prism_rtl::Job<crate::lower::model::FnDef>> {
    Rc::new(FnDefOf { lx_p0, qk_p1, clauses_p2, sc_p3 })
}

/// ```prism
/// TyParamsIn: fn OutTy -> [Text]
/// ```
pub fn ty_params_in_f(t_p0: &crate::lower::model::OutTy) -> Array<Text> {
    match t_p0 {
        crate::lower::model::OutTy::OutGen(n_p1) => Array::from(vec![n_p1.clone()]),
        crate::lower::model::OutTy::OutNamed(_, ts_p2) => crate::prelude::fold(ts_p2, &Array::new(), &(|acc_p3: &Array<Text>, x_p4: &crate::lower::model::OutTy| crate::check::types::union_texts_f(acc_p3, &ty_params_in_f(x_p4)))),
        crate::lower::model::OutTy::OutTuple(ts_p5) => crate::prelude::fold(ts_p5, &Array::new(), &(|acc_p6: &Array<Text>, x_p7: &crate::lower::model::OutTy| crate::check::types::union_texts_f(acc_p6, &ty_params_in_f(x_p7)))),
        crate::lower::model::OutTy::OutFn(ts_p8, r_p9) => crate::prelude::fold(ts_p8, &ty_params_in_f(&**r_p9), &(|acc_pa: &Array<Text>, x_pb: &crate::lower::model::OutTy| crate::check::types::union_texts_f(acc_pa, &ty_params_in_f(x_pb)))),
        crate::lower::model::OutTy::OutJobFn(a_pc, r_pd) => crate::check::types::union_texts_f(&ty_params_in_f(&**a_pc), &ty_params_in_f(&**r_pd)),
        crate::lower::model::OutTy::OutMap(k_pe, v_pf) => crate::check::types::union_texts_f(&ty_params_in_f(&**k_pe), &ty_params_in_f(&**v_pf)),
        crate::lower::model::OutTy::OutOpt(x_pg) => ty_params_in_f(&**x_pg),
        crate::lower::model::OutTy::OutRes(x_ph) => ty_params_in_f(&**x_ph),
        crate::lower::model::OutTy::OutArray(x_pi) => ty_params_in_f(&**x_pi),
        crate::lower::model::OutTy::OutJob(x_pj) => ty_params_in_f(&**x_pj),
        crate::lower::model::OutTy::OutEvent(x_pk) => ty_params_in_f(&**x_pk),
        crate::lower::model::OutTy::OutDyn(x_pl) => ty_params_in_f(&**x_pl),
        crate::lower::model::OutTy::OutRc(x_pm) => ty_params_in_f(&**x_pm),
        crate::lower::model::OutTy::OutRef(x_pn) => ty_params_in_f(&**x_pn),
        crate::lower::model::OutTy::OutHold(x_po) => ty_params_in_f(&**x_po),
        crate::lower::model::OutTy::OutCell(x_pp) => ty_params_in_f(&**x_pp),
        crate::lower::model::OutTy::OutLive(x_pq) => ty_params_in_f(&**x_pq),
        _ => Array::new(),
    }
}

/// ```prism
/// SignatureText: fn Lx, Text -> Text
/// ```
pub fn signature_text_f(lx_p0: &crate::lower::Lx, qk_p1: &Text) -> Text {
    match crate::prelude::get(&lx_p0.g_p.vals_p, qk_p1) {
        Some(v_p2) => match crate::prelude::index(&lx_p0.g_p.srcs_p, &v_p2.file_p) {
            Some(src_p3) => crate::syntax::lexer::chars::trim_f(&crate::check::errors::span_text_f(&src_p3, &v_p2.span_p)),
            None => crate::check::types::bare_name_f(qk_p1),
        },
        None => crate::check::types::bare_name_f(qk_p1),
    }
}

/// ```prism
/// DefinitionText: fn Lx, Text -> Text
/// ```
pub fn definition_text_f(lx_p0: &crate::lower::Lx, qk_p1: &Text) -> Text {
    let spans_p2 = crate::prelude::fold(&lx_p0.g_p.defs_p, &Array::new(), &(|acc_p4: &Array<(Nat, crate::syntax::Range)>, d_p5: &crate::check::env::Def| if &d_p5.qk_p == qk_p1 {
        crate::prelude::push(acc_p4, &(d_p5.file_p.clone(), d_p5.span_p.clone()))
    } else {
        acc_p4.clone()
    }));
    let sig_p3 = match crate::prelude::get(&lx_p0.g_p.vals_p, qk_p1) {
        Some(v_p6) => if &v_p6.span_p.start_p < &crate::prelude::or(&crate::prelude::index(&crate::prelude::each(&spans_p2, &(|(_, r_p7): &(Nat, crate::syntax::Range)| r_p7.start_p.clone())), &Nat::from(0u32)), &Nat::from(0u32)) {
            Array::from(vec![(v_p6.file_p.clone(), v_p6.span_p.clone())])
        } else {
            Array::new()
        },
        None => Array::new(),
    };
    crate::syntax::lexer::chars::join_f(&crate::prelude::each(&crate::prelude::append(&sig_p3, &spans_p2), &(|(f_p8, r_p9): &(Nat, crate::syntax::Range)| src_text_f(lx_p0, f_p8, r_p9))), &Text::lit("\n"))
}

/// ```prism
/// SrcText: fn Lx, Nat, Range -> Text
/// ```
pub fn src_text_f(lx_p0: &crate::lower::Lx, f_p1: &Nat, r_p2: &crate::syntax::Range) -> Text {
    match crate::prelude::index(&lx_p0.g_p.srcs_p, f_p1) {
        Some(src_p3) => drop_trailing_comments_f(&crate::check::errors::span_text_f(&src_p3, r_p2)),
        None => Text::lit(""),
    }
}

/// ```prism
/// DropTrailingComments: fn Text -> Text
/// ```
pub fn drop_trailing_comments_f(t_p0: &Text) -> Text {
    let lines_p1 = crate::prelude::split_on(t_p0, &Text::lit("\n"));
    let keep_p2 = crate::prelude::fold(&crate::check::errors::range0_f(&crate::prelude::len(&lines_p1)), &Nat::from(0u32), &(|k_p3: &Nat, i_p4: &Nat| if is_code_line_f(&crate::prelude::or(&crate::prelude::index(&lines_p1, i_p4), &Text::lit(""))) {
        i_p4 + &Nat::from(1u32)
    } else {
        k_p3.clone()
    }));
    crate::syntax::lexer::chars::trim_end_f(&crate::syntax::lexer::chars::join_f(&crate::prelude::take(&lines_p1, &keep_p2), &Text::lit("\n")))
}

/// ```prism
/// IsCodeLine: fn Text -> Bool
/// ```
pub fn is_code_line_f(l_p0: &Text) -> bool {
    let s_p1 = crate::syntax::lexer::chars::trim_f(l_p0);
    (&s_p1 != &Text::lit("")) && !crate::syntax::lexer::chars::has_prefix_f(&s_p1, &Text::lit("#"))
}

/// ```prism
/// LetGetter: unbounded fn Lx, Text, LetDecl -> FnDef
/// ```
pub fn let_getter_f(lx_p0: &crate::lower::Lx, qk_p1: &Text, l_p2: &crate::syntax::decls::LetDecl) -> crate::lower::model::FnDef {
    let t_p3 = crate::lower::types::out_ty_of_f(lx_p0, &crate::lower::types::peel_f(&crate::lower::type_at_f(lx_p0, &l_p2.value_p.span_p)));
    let v_p4 = crate::lower::expr::value_of_f(lx_p0, &crate::lower::types::empty_env_p(), &l_p2.value_p);
    crate::lower::model::FnDef { name_p: crate::prelude::or(&crate::prelude::get(&lx_p0.rs_names_p, qk_p1), &crate::lower::snake_f(&crate::check::types::bare_name_f(qk_p1))), generics_p: Array::new(), params_p: Array::new(), ret_p: t_p3.clone(), body_p: crate::lower::types::own_f(&v_p4), doc_p: Text::from(format!("let {}", &crate::check::types::bare_name_f(qk_p1))), public_p: true }
}

/// The step machine of `LetGetter`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LetGetter: unbounded fn Lx, Text, LetDecl -> FnDef
/// ```
pub struct LetGetter {
    pub lx_p0: crate::lower::Lx,
    pub qk_p1: Text,
    pub l_p2: crate::syntax::decls::LetDecl,
}

impl prism_rtl::Job<crate::lower::model::FnDef> for LetGetter {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::FnDef> {
        let lx_p0 = &self.lx_p0;
        let qk_p1 = &self.qk_p1;
        let l_p2 = &self.l_p2;
        let l_p2x = l_p2.clone();
        let lx_p0x = lx_p0.clone();
        let qk_p1x = qk_p1.clone();
        crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0x.clone(), crate::lower::types::peel_f(&crate::lower::type_at_f(&lx_p0x, &l_p2x.value_p.span_p))), move |out_ty_of_f_10237: crate::lower::model::OutTy| {
            let t_p3 = out_ty_of_f_10237;
            crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p0x.clone(), crate::lower::types::empty_env_p(), l_p2x.value_p.clone()), move |value_of_f_10294: crate::lower::types::Vl| {
                let v_p4 = value_of_f_10294;
                prism_rtl::Turn::Finished(crate::lower::model::FnDef { name_p: crate::prelude::or(&crate::prelude::get(&lx_p0x.rs_names_p, &qk_p1x), &crate::lower::snake_f(&crate::check::types::bare_name_f(&qk_p1x))), generics_p: Array::new(), params_p: Array::new(), ret_p: t_p3.clone(), body_p: crate::lower::types::own_f(&v_p4), doc_p: Text::from(format!("let {}", &crate::check::types::bare_name_f(&qk_p1x))), public_p: true })
            })
        })
    }
}

/// `Start LetGetter, x`: what the function value is when passed to `@Run`.
pub fn start_let_getter_f(lx_p0: crate::lower::Lx, qk_p1: Text, l_p2: crate::syntax::decls::LetDecl) -> Rc<dyn prism_rtl::Job<crate::lower::model::FnDef>> {
    Rc::new(LetGetter { lx_p0, qk_p1, l_p2 })
}

/// ```prism
/// HasOwnShow: fn Lx, Text -> Bool
/// ```
pub fn has_own_show_f(lx_p0: &crate::lower::Lx, tn_p1: &Text) -> bool {
    crate::prelude::fold(&crate::prelude::or(&crate::prelude::get(&lx_p0.g_p.impls_p, &Text::lit("Prelude.Show")), &Array::new()), &false, &(|f_p2: &bool, im_p3: &crate::check::env::ImplInfo| *f_p2 || (!im_p3.derived_p && (&head_name_f(&im_p3.head_p) == tn_p1))))
}

/// ```prism
/// HeadName: fn Ty -> Text
/// ```
pub fn head_name_f(ty0: &crate::check::types::Ty) -> Text {
    match ty0 {
        crate::check::types::Ty::TyCon(n_p0, _) => n_p0.clone(),
        other_p1 => Text::lit(""),
    }
}

/// ```prism
/// SelfIn: unbounded fn Ty, Text -> Ty
/// ```
pub fn self_in_f(t_p0: &crate::check::types::Ty, param_p1: &Text) -> crate::check::types::Ty {
    crate::lower::expr::instantiated_f(t_p0, &Array::from(vec![param_p1.clone()]), &Array::from(vec![crate::check::types::Ty::TyCon(Text::lit("\0Self"), Array::new())]))
}

/// The step machine of `SelfIn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SelfIn: unbounded fn Ty, Text -> Ty
/// ```
pub struct SelfIn {
    pub t_p0: crate::check::types::Ty,
    pub param_p1: Text,
}

impl prism_rtl::Job<crate::check::types::Ty> for SelfIn {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::Ty> {
        let t_p0 = &self.t_p0;
        let param_p1 = &self.param_p1;
        prism_rtl::Turn::More(Rc::new(crate::lower::expr::Instantiated { t_p0: t_p0.clone(), params_p1: Array::from(vec![param_p1.clone()]), args_p2: Array::from(vec![crate::check::types::Ty::TyCon(Text::lit("\0Self"), Array::new())]) }))
    }
}

/// `Start SelfIn, x`: what the function value is when passed to `@Run`.
pub fn start_self_in_f(t_p0: crate::check::types::Ty, param_p1: Text) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>> {
    Rc::new(SelfIn { t_p0, param_p1 })
}

/// ```prism
/// TraitDefOf: unbounded fn Lx, TraitInfo -> TraitDef
/// ```
pub fn trait_def_of_f(lx0_p0: &crate::lower::Lx, tr_p1: &crate::check::env::TraitInfo) -> crate::lower::model::TraitDef {
    let lx_p2 = crate::lower::program::in_module_f(lx0_p0, &tr_p1.file_p, &tr_p1.home_p);
    let methods_p3 = crate::prelude::run_to_end(crate::prelude::each_job(tr_p1.methods_p.clone(), {
        let lx_p2x = lx_p2.clone();
        let tr_p1x = tr_p1.clone();
        Rc::new(move |p0: Text| {
            let lx_p2xy = lx_p2x.clone();
            let tr_p1xy = tr_p1x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let mq_p4 = p0;
                {
                    let v_p5 = crate::prelude::or(&crate::prelude::get(&lx_p2xy.g_p.vals_p, &mq_p4), &crate::check::env::builtin_f(&mq_p4, &crate::check::types::schemes::mono_f(&crate::check::types::Ty::TyErr)));
                    let sc_p6 = {
                        let mut this: crate::check::types::Scheme = v_p5.scheme_p.clone();
                        this.ty_p = self_in_f(&this.ty_p, &tr_p1xy.param_p);
                        this.qs_p = crate::prelude::filter(&this.qs_p, &(|q_pa: &Text| q_pa != &tr_p1xy.param_p));
                        this.bounds_p = crate::prelude::filter(&this.bounds_p, &(|(q_pb, _): &(Text, Text)| q_pb != &tr_p1xy.param_p));
                        this
                    };
                    let default_qk_p7 = crate::prelude::fold(&tr_p1xy.defaults_p, &Text::lit(""), &(|f_pc: &Text, dq_pd: &Text| if &crate::check::types::bare_name_f(dq_pd) == &crate::check::types::bare_name_f(&mq_p4) {
                        dq_pd.clone()
                    } else {
                        f_pc.clone()
                    }));
                    let clauses_p8 = if &default_qk_p7 == &Text::lit("") {
                        Array::new()
                    } else {
                        default_clauses_f(&lx_p2xy.g_p, &default_qk_p7)
                    };
                    crate::prelude::call_then(start_fn_def_of_f(lx_p2xy.clone(), mq_p4.clone(), if &crate::prelude::len(&clauses_p8) == &Nat::from(0u32) {
                        Array::from(vec![dummy_clause_p()])
                    } else {
                        clauses_p8.clone()
                    }, sc_p6.clone()), move |fn_def_of_f_11831: crate::lower::model::FnDef| {
                        let fd_p9 = fn_def_of_f_11831;
                        prism_rtl::Turn::Finished({
                            let mut this: crate::lower::model::FnDef = fd_p9.clone();
                            this.public_p = &crate::prelude::len(&clauses_p8) > &Nat::from(0u32);
                            this
                        })
                    })
                }
            }))
        }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<crate::lower::model::FnDef>>>
    }));
    crate::lower::model::TraitDef { name_p: crate::lower::camel_f(&crate::check::types::bare_name_f(&tr_p1.name_p)), methods_p: methods_p3.clone(), defaults_p: tr_p1.defaults_p.clone(), doc_p: crate::lower::program::type_doc_f(&lx_p2, &crate::check::env::TyInfo { name_p: tr_p1.name_p.clone(), home_p: tr_p1.home_p.clone(), params_p: Array::new(), body_p: crate::check::env::TyBody::BOpaque, derives_p: Array::new(), file_p: tr_p1.file_p.clone(), span_p: tr_p1.span_p.clone() }) }
}

/// The step machine of `TraitDefOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TraitDefOf: unbounded fn Lx, TraitInfo -> TraitDef
/// ```
pub struct TraitDefOf {
    pub lx0_p0: crate::lower::Lx,
    pub tr_p1: crate::check::env::TraitInfo,
}

impl prism_rtl::Job<crate::lower::model::TraitDef> for TraitDefOf {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::TraitDef> {
        let lx0_p0 = &self.lx0_p0;
        let tr_p1 = &self.tr_p1;
        let lx_p2 = crate::lower::program::in_module_f(lx0_p0, &tr_p1.file_p, &tr_p1.home_p);
        let tr_p1x = tr_p1.clone();
        crate::prelude::call_value(crate::prelude::each_job(tr_p1x.methods_p.clone(), {
            let lx_p2x = lx_p2.clone();
            let tr_p1xx = tr_p1x.clone();
            Rc::new(move |p0: Text| {
                let lx_p2xy = lx_p2x.clone();
                let tr_p1xxy = tr_p1xx.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let mq_p4 = p0;
                    {
                        let v_p5 = crate::prelude::or(&crate::prelude::get(&lx_p2xy.g_p.vals_p, &mq_p4), &crate::check::env::builtin_f(&mq_p4, &crate::check::types::schemes::mono_f(&crate::check::types::Ty::TyErr)));
                        let sc_p6 = {
                            let mut this: crate::check::types::Scheme = v_p5.scheme_p.clone();
                            this.ty_p = self_in_f(&this.ty_p, &tr_p1xxy.param_p);
                            this.qs_p = crate::prelude::filter(&this.qs_p, &(|q_pa: &Text| q_pa != &tr_p1xxy.param_p));
                            this.bounds_p = crate::prelude::filter(&this.bounds_p, &(|(q_pb, _): &(Text, Text)| q_pb != &tr_p1xxy.param_p));
                            this
                        };
                        let default_qk_p7 = crate::prelude::fold(&tr_p1xxy.defaults_p, &Text::lit(""), &(|f_pc: &Text, dq_pd: &Text| if &crate::check::types::bare_name_f(dq_pd) == &crate::check::types::bare_name_f(&mq_p4) {
                            dq_pd.clone()
                        } else {
                            f_pc.clone()
                        }));
                        let clauses_p8 = if &default_qk_p7 == &Text::lit("") {
                            Array::new()
                        } else {
                            default_clauses_f(&lx_p2xy.g_p, &default_qk_p7)
                        };
                        crate::prelude::call_then(start_fn_def_of_f(lx_p2xy.clone(), mq_p4.clone(), if &crate::prelude::len(&clauses_p8) == &Nat::from(0u32) {
                            Array::from(vec![dummy_clause_p()])
                        } else {
                            clauses_p8.clone()
                        }, sc_p6.clone()), move |fn_def_of_f_11831: crate::lower::model::FnDef| {
                            let fd_p9 = fn_def_of_f_11831;
                            prism_rtl::Turn::Finished({
                                let mut this: crate::lower::model::FnDef = fd_p9.clone();
                                this.public_p = &crate::prelude::len(&clauses_p8) > &Nat::from(0u32);
                                this
                            })
                        })
                    }
                }))
            }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<crate::lower::model::FnDef>>>
        }), move |each_11339: Array<crate::lower::model::FnDef>| {
            let methods_p3 = each_11339;
            prism_rtl::Turn::Finished(crate::lower::model::TraitDef { name_p: crate::lower::camel_f(&crate::check::types::bare_name_f(&tr_p1x.name_p)), methods_p: methods_p3.clone(), defaults_p: tr_p1x.defaults_p.clone(), doc_p: crate::lower::program::type_doc_f(&lx_p2, &crate::check::env::TyInfo { name_p: tr_p1x.name_p.clone(), home_p: tr_p1x.home_p.clone(), params_p: Array::new(), body_p: crate::check::env::TyBody::BOpaque, derives_p: Array::new(), file_p: tr_p1x.file_p.clone(), span_p: tr_p1x.span_p.clone() }) })
        })
    }
}

/// `Start TraitDefOf, x`: what the function value is when passed to `@Run`.
pub fn start_trait_def_of_f(lx0_p0: crate::lower::Lx, tr_p1: crate::check::env::TraitInfo) -> Rc<dyn prism_rtl::Job<crate::lower::model::TraitDef>> {
    Rc::new(TraitDefOf { lx0_p0, tr_p1 })
}

/// ```prism
/// DefaultClauses: fn G, Text -> [FnClause]
/// ```
pub fn default_clauses_f(g_p0: &crate::check::env::G, qk_p1: &Text) -> Array<crate::syntax::decls::FnClause> {
    crate::prelude::fold(&g_p0.defs_p, &Array::new(), &(|acc_p2: &Array<crate::syntax::decls::FnClause>, d_p3: &crate::check::env::Def| if &d_p3.qk_p == qk_p1 { default_of_f(d_p3, acc_p2) } else { acc_p2.clone() }))
}

/// ```prism
/// DefaultOf: fn Def, [FnClause] -> [FnClause]
/// ```
pub fn default_of_f(d_p0: &crate::check::env::Def, other_p1: &Array<crate::syntax::decls::FnClause>) -> Array<crate::syntax::decls::FnClause> {
    match &d_p0.body_p {
        crate::check::env::DefBody::DbDefault(cs_p2, _) => cs_p2.clone(),
        _ => other_p1.clone(),
    }
}

/// ```prism
/// ImplDefOf: unbounded fn Lx, ImplInfo -> ImplDef
/// ```
pub fn impl_def_of_f(lx_p0: &crate::lower::Lx, im_p1: &crate::check::env::ImplInfo) -> crate::lower::model::ImplDef {
    let tr_p2 = crate::prelude::or(&crate::prelude::get(&lx_p0.g_p.traits_p, &im_p1.cls_p), &crate::lower::expr::dummy_trait_info_p());
    let head_p3 = crate::lower::types::out_ty_of_f(lx_p0, &im_p1.head_p);
    let defs_p4 = crate::prelude::filter(&lx_p0.g_p.defs_p, &(|d_p7: &crate::check::env::Def| is_method_of_f(d_p7, im_p1)));
    let methods_p5 = crate::prelude::run_to_end(crate::prelude::each_job(defs_p4.clone(), {
        let tr_p2x = tr_p2.clone();
        let lx_p0x = lx_p0.clone();
        let im_p1x = im_p1.clone();
        Rc::new(move |p0: crate::check::env::Def| {
            let tr_p2xy = tr_p2x.clone();
            let lx_p0xy = lx_p0x.clone();
            let im_p1xy = im_p1x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let d_p8 = p0;
                {
                    let mq_p9 = crate::prelude::fold(&tr_p2xy.methods_p, &Text::lit(""), &(|found_pd: &Text, q_pe: &Text| if &crate::check::types::bare_name_f(q_pe) == &d_p8.name_p {
                        q_pe.clone()
                    } else {
                        found_pd.clone()
                    }));
                    let v_pa = crate::prelude::or(&crate::prelude::get(&lx_p0xy.g_p.vals_p, &mq_p9), &crate::check::env::builtin_f(&mq_p9, &crate::check::types::schemes::mono_f(&crate::check::types::Ty::TyErr)));
                    let sc_pb = {
                        let mut this: crate::check::types::Scheme = v_pa.scheme_p.clone();
                        this.ty_p = crate::lower::expr::instantiated_f(&this.ty_p, &Array::from(vec![tr_p2xy.param_p.clone()]), &Array::from(vec![im_p1xy.head_p.clone()]));
                        this.qs_p = crate::prelude::filter(&this.qs_p, &(|q_pf: &Text| q_pf != &tr_p2xy.param_p));
                        this.bounds_p = crate::prelude::filter(&this.bounds_p, &(|(q_pg, _): &(Text, Text)| q_pg != &tr_p2xy.param_p));
                        this
                    };
                    crate::prelude::call_then(start_fn_def_of_f(lx_p0xy.clone(), mq_p9.clone(), method_clauses_f(&d_p8), sc_pb.clone()), move |fn_def_of_f_13164: crate::lower::model::FnDef| {
                        let fd_pc = fn_def_of_f_13164;
                        if crate::syntax::lexer::chars::has_prefix_f(&im_p1xy.cls_p, &Text::lit("Prelude.")) {
                            prism_rtl::Turn::Finished(renamed_f(&fd_pc, &Text::from(format!("{}_{}", &crate::lower::snake_f(&d_p8.name_p), &crate::lower::snake_f(&crate::check::types::bare_name_f(&head_name_f(&im_p1xy.head_p)))))))
                        } else {
                            prism_rtl::Turn::Finished(fd_pc.clone())
                        }
                    })
                }
            }))
        }) as Rc<dyn Fn(crate::check::env::Def) -> Rc<dyn prism_rtl::Job<crate::lower::model::FnDef>>>
    }));
    let generics_p6 = crate::prelude::run_to_end(crate::prelude::each_job(im_p1.qs_p.clone(), {
        let lx_p0x = lx_p0.clone();
        let im_p1x = im_p1.clone();
        Rc::new(move |p0: Text| {
            let lx_p0xy = lx_p0x.clone();
            let im_p1xy = im_p1x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let q_ph = p0;
                crate::prelude::call_then(start_impl_bounds_f(lx_p0xy.clone(), im_p1xy.clone(), q_ph.clone()), move |impl_bounds_f_13447: Array<Text>| prism_rtl::Turn::Finished((crate::lower::camel_f(&q_ph), impl_bounds_f_13447)))
            }))
        }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<(Text, Array<Text>)>>>
    }));
    crate::lower::model::ImplDef { cls_p: im_p1.cls_p.clone(), tr_p: crate::lower::path_in_f(lx_p0, &tr_p2.home_p, &crate::lower::camel_f(&crate::check::types::bare_name_f(&im_p1.cls_p))), head_p: head_p3.clone(), generics_p: generics_p6.clone(), methods_p: methods_p5.clone(), doc_p: Text::lit("") }
}

/// The step machine of `ImplDefOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ImplDefOf: unbounded fn Lx, ImplInfo -> ImplDef
/// ```
pub struct ImplDefOf {
    pub lx_p0: crate::lower::Lx,
    pub im_p1: crate::check::env::ImplInfo,
}

impl prism_rtl::Job<crate::lower::model::ImplDef> for ImplDefOf {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::ImplDef> {
        let lx_p0 = &self.lx_p0;
        let im_p1 = &self.im_p1;
        let tr_p2 = crate::prelude::or(&crate::prelude::get(&lx_p0.g_p.traits_p, &im_p1.cls_p), &crate::lower::expr::dummy_trait_info_p());
        let im_p1x = im_p1.clone();
        let lx_p0x = lx_p0.clone();
        crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0x.clone(), im_p1x.head_p.clone()), move |out_ty_of_f_12657: crate::lower::model::OutTy| {
            let head_p3 = out_ty_of_f_12657;
            let defs_p4 = crate::prelude::filter(&lx_p0x.g_p.defs_p, &(|d_p7: &crate::check::env::Def| is_method_of_f(d_p7, &im_p1x)));
            crate::prelude::call_value(crate::prelude::each_job(defs_p4.clone(), {
                let tr_p2x = tr_p2.clone();
                let lx_p0xx = lx_p0x.clone();
                let im_p1xx = im_p1x.clone();
                Rc::new(move |p0: crate::check::env::Def| {
                    let tr_p2xy = tr_p2x.clone();
                    let lx_p0xxy = lx_p0xx.clone();
                    let im_p1xxy = im_p1xx.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let d_p8 = p0;
                        {
                            let mq_p9 = crate::prelude::fold(&tr_p2xy.methods_p, &Text::lit(""), &(|found_pd: &Text, q_pe: &Text| if &crate::check::types::bare_name_f(q_pe) == &d_p8.name_p {
                                q_pe.clone()
                            } else {
                                found_pd.clone()
                            }));
                            let v_pa = crate::prelude::or(&crate::prelude::get(&lx_p0xxy.g_p.vals_p, &mq_p9), &crate::check::env::builtin_f(&mq_p9, &crate::check::types::schemes::mono_f(&crate::check::types::Ty::TyErr)));
                            let sc_pb = {
                                let mut this: crate::check::types::Scheme = v_pa.scheme_p.clone();
                                this.ty_p = crate::lower::expr::instantiated_f(&this.ty_p, &Array::from(vec![tr_p2xy.param_p.clone()]), &Array::from(vec![im_p1xxy.head_p.clone()]));
                                this.qs_p = crate::prelude::filter(&this.qs_p, &(|q_pf: &Text| q_pf != &tr_p2xy.param_p));
                                this.bounds_p = crate::prelude::filter(&this.bounds_p, &(|(q_pg, _): &(Text, Text)| q_pg != &tr_p2xy.param_p));
                                this
                            };
                            crate::prelude::call_then(start_fn_def_of_f(lx_p0xxy.clone(), mq_p9.clone(), method_clauses_f(&d_p8), sc_pb.clone()), move |fn_def_of_f_13164: crate::lower::model::FnDef| {
                                let fd_pc = fn_def_of_f_13164;
                                if crate::syntax::lexer::chars::has_prefix_f(&im_p1xxy.cls_p, &Text::lit("Prelude.")) {
                                    prism_rtl::Turn::Finished(renamed_f(&fd_pc, &Text::from(format!("{}_{}", &crate::lower::snake_f(&d_p8.name_p), &crate::lower::snake_f(&crate::check::types::bare_name_f(&head_name_f(&im_p1xxy.head_p)))))))
                                } else {
                                    prism_rtl::Turn::Finished(fd_pc.clone())
                                }
                            })
                        }
                    }))
                }) as Rc<dyn Fn(crate::check::env::Def) -> Rc<dyn prism_rtl::Job<crate::lower::model::FnDef>>>
            }), move |each_12750: Array<crate::lower::model::FnDef>| {
                let methods_p5 = each_12750;
                crate::prelude::call_value(crate::prelude::each_job(im_p1x.qs_p.clone(), {
                    let lx_p0xx = lx_p0x.clone();
                    let im_p1xx = im_p1x.clone();
                    Rc::new(move |p0: Text| {
                        let lx_p0xxy = lx_p0xx.clone();
                        let im_p1xxy = im_p1xx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let q_ph = p0;
                            crate::prelude::call_then(start_impl_bounds_f(lx_p0xxy.clone(), im_p1xxy.clone(), q_ph.clone()), move |impl_bounds_f_13447: Array<Text>| prism_rtl::Turn::Finished((crate::lower::camel_f(&q_ph), impl_bounds_f_13447)))
                        }))
                    }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<(Text, Array<Text>)>>>
                }), move |each_13418: Array<(Text, Array<Text>)>| {
                    let generics_p6 = each_13418;
                    prism_rtl::Turn::Finished(crate::lower::model::ImplDef { cls_p: im_p1x.cls_p.clone(), tr_p: crate::lower::path_in_f(&lx_p0x, &tr_p2.home_p, &crate::lower::camel_f(&crate::check::types::bare_name_f(&im_p1x.cls_p))), head_p: head_p3.clone(), generics_p: generics_p6.clone(), methods_p: methods_p5.clone(), doc_p: Text::lit("") })
                })
            })
        })
    }
}

/// `Start ImplDefOf, x`: what the function value is when passed to `@Run`.
pub fn start_impl_def_of_f(lx_p0: crate::lower::Lx, im_p1: crate::check::env::ImplInfo) -> Rc<dyn prism_rtl::Job<crate::lower::model::ImplDef>> {
    Rc::new(ImplDefOf { lx_p0, im_p1 })
}

/// ```prism
/// ImplBounds: unbounded fn Lx, ImplInfo, Text -> [Text]
/// ```
pub fn impl_bounds_f(lx_p0: &crate::lower::Lx, im_p1: &crate::check::env::ImplInfo, q_p2: &Text) -> Array<Text> {
    crate::prelude::fold(&im_p1.bounds_p, &Array::from(vec![Text::lit("Clone")]), &(|acc_p3: &Array<Text>, (v_p4, cls_p5): &(Text, Text)| if v_p4 == q_p2 {
        crate::check::types::union_texts_f(acc_p3, &bound_of_f(lx_p0, cls_p5))
    } else {
        acc_p3.clone()
    }))
}

/// The step machine of `ImplBounds`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ImplBounds: unbounded fn Lx, ImplInfo, Text -> [Text]
/// ```
pub struct ImplBounds {
    pub lx_p0: crate::lower::Lx,
    pub im_p1: crate::check::env::ImplInfo,
    pub q_p2: Text,
}

impl prism_rtl::Job<Array<Text>> for ImplBounds {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let lx_p0 = &self.lx_p0;
        let im_p1 = &self.im_p1;
        let q_p2 = &self.q_p2;
        prism_rtl::Turn::Finished(crate::prelude::fold(&im_p1.bounds_p, &Array::from(vec![Text::lit("Clone")]), &(|acc_p3: &Array<Text>, (v_p4, cls_p5): &(Text, Text)| if v_p4 == q_p2 {
            crate::check::types::union_texts_f(acc_p3, &bound_of_f(lx_p0, cls_p5))
        } else {
            acc_p3.clone()
        })))
    }
}

/// `Start ImplBounds, x`: what the function value is when passed to `@Run`.
pub fn start_impl_bounds_f(lx_p0: crate::lower::Lx, im_p1: crate::check::env::ImplInfo, q_p2: Text) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(ImplBounds { lx_p0, im_p1, q_p2 })
}

/// ```prism
/// Renamed: fn FnDef, Text -> FnDef
/// ```
pub fn renamed_f(fd_p0: &crate::lower::model::FnDef, n_p1: &Text) -> crate::lower::model::FnDef {
    let mut this: crate::lower::model::FnDef = fd_p0.clone();
    this.name_p = n_p1.clone();
    this
}

/// ```prism
/// IsMethodOf: fn Def, ImplInfo -> Bool
/// ```
pub fn is_method_of_f(d_p0: &crate::check::env::Def, im_p1: &crate::check::env::ImplInfo) -> bool {
    match &d_p0.body_p {
        crate::check::env::DefBody::DbMethod(_, cls_p2, other_p3) => ((cls_p2 == &im_p1.cls_p) && (&other_p3.span_p == &im_p1.span_p)) && (&other_p3.file_p == &im_p1.file_p),
        _ => false,
    }
}

/// ```prism
/// MethodClauses: fn Def -> [FnClause]
/// ```
pub fn method_clauses_f(d_p0: &crate::check::env::Def) -> Array<crate::syntax::decls::FnClause> {
    match &d_p0.body_p {
        crate::check::env::DefBody::DbMethod(cs_p1, _, _) => cs_p1.clone(),
        _ => Array::new(),
    }
}

/// ```prism
/// IfGenLine: unbounded fn Wx, Env, Expr, Block, Block, Expr -> ((Wx, Wres))
/// ```
pub fn if_gen_line_f(wx_p0: &crate::lower::node_::Wx, menv_p1: &crate::lower::types::Env, c_p2: &crate::syntax::Expr, then_b_p3: &crate::syntax::Block, else_b_p4: &crate::syntax::Block, e_p5: &crate::syntax::Expr) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    let lx_p6 = wx_p0.lx_p.clone();
    let pos_p7 = wx_p0.pos_p.clone();
    let wx1_p8 = {
        let mut this: crate::lower::node_::Wx = wx_p0.clone();
        this.pos_p = crate::lower::model::next_pos_f(&this.pos_p);
        this
    };
    let (name_ph, wx2_pi) = crate::lower::node_::fresh_name_f(&wx1_p8, &Text::lit("arm"));
    let base_p9 = Text::from(format!("{}{}{}", &wx_p0.node_p, &crate::lower::camel_f(&name_ph), &crate::lower::node_::keyed::row_suffix_f(wx_p0)));
    let yes_pa = crate::lower::node_::switch_::gen_row_of_f(&wx2_pi, menv_p1, then_b_p3, &crate::lower::model::OutTy::OutUnit, &Text::from(format!("{}Then", &base_p9)), &name_ph);
    let no_pb = crate::lower::node_::switch_::gen_row_of_f(&yes_pa.parent_p, menv_p1, else_b_p4, &crate::lower::model::OutTy::OutUnit, &Text::from(format!("{}Else", &base_p9)), &name_ph);
    let cond_pc = crate::lower::types::as_bool_f(&crate::lower::expr::value_of_f(&lx_p6, menv_p1, c_p2));
    let tail_pd = crate::prelude::append(&crate::prelude::append(&Array::from(vec![crate::lower::model::Ex::XWeak(Rc::new(crate::lower::model::Ex::XSelf))]), &crate::lower::node_::keyed::hosted_passed_f(wx_p0)), &Array::from(vec![crate::lower::model::Ex::XCx]));
    let mk_fe = {
        let tail_pdx = tail_pd.clone();
        Rc::new(move |n_pj: &crate::lower::model::NodeDef| crate::lower::model::Ex::XCast(Rc::new(crate::lower::expr::try_of_f(&crate::lower::model::Ex::XCall(Text::from(format!("{}::build", &n_pj.name_p)), crate::prelude::append(&Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("path")), crate::lower::model::Ex::XVar(Text::lit("value"))]), &tail_pdx)))), crate::lower::model::OutTy::OutObj(Rc::new(crate::lower::model::OutTy::OutNamed(Text::lit("Row"), Array::new()))))) as Rc<dyn Fn(&crate::lower::model::NodeDef) -> crate::lower::model::Ex>
    };
    let select_pf = crate::lower::model::Ex::XIf(Rc::new(cond_pc.clone()), Rc::new((&mk_fe)(&yes_pa.node_p)), Rc::new((&mk_fe)(&no_pb.node_p)));
    let wx3_pg = {
        let mut this: crate::lower::node_::Wx = no_pb.parent_p.clone();
        this.gens_p = crate::prelude::push(&this.gens_p, &crate::lower::model::GenDef { name_p: name_ph.clone(), pos_p: pos_p7.clone(), at_p: crate::lower::node_::finish::place_at_f(wx_p0, &Text::lit("self"), &pos_p7), source_p: crate::lower::model::Ex::XUnit, value_ty_p: crate::lower::model::OutTy::OutUnit, select_p: select_pf.clone(), transparent_p: false, width_p: Nat::from(0u32), moved_p: crate::prelude::or(&crate::lower::node_::finish::hosted_rows_o(wx_p0), &Text::lit("")) });
        this.gen_holds_p = crate::prelude::push(&this.gen_holds_p, &(name_ph.clone(), Array::new()));
        this.rows_p = crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&crate::prelude::push(&this.rows_p, &yes_pa.node_p), &yes_pa.node_p.children_p), &Array::from(vec![no_pb.node_p.clone()])), &no_pb.node_p.children_p);
        this.getters_p = crate::prelude::push(&this.getters_p, &crate::lower::model::MethDef { name_p: Text::from(format!("{}_up", &name_ph)), recv_p: crate::lower::model::Recv::RecvRc, params_p: Array::from(vec![(Text::lit("v"), crate::lower::model::OutTy::OutUnit)]), cx_p: crate::lower::model::CxArg::CxMut, ret_p: crate::lower::model::OutTy::OutUnit, body_p: Array::new(), tail_p: crate::lower::model::Ex::XUnit, doc_p: Text::lit("An arm\'s result, which a building `if` of widgets drops.") });
        this
    };
    (wx3_pg.clone(), crate::lower::node_::Wres::WrUnit)
}

/// The step machine of `IfGenLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// IfGenLine: unbounded fn Wx, Env, Expr, Block, Block, Expr -> ((Wx, Wres))
/// ```
pub struct IfGenLine {
    pub wx_p0: crate::lower::node_::Wx,
    pub menv_p1: crate::lower::types::Env,
    pub c_p2: crate::syntax::Expr,
    pub then_b_p3: crate::syntax::Block,
    pub else_b_p4: crate::syntax::Block,
    pub e_p5: crate::syntax::Expr,
}

impl prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::node_::Wres)> for IfGenLine {
    fn cycle(&self) -> prism_rtl::Turn<(crate::lower::node_::Wx, crate::lower::node_::Wres)> {
        let wx_p0 = &self.wx_p0;
        let menv_p1 = &self.menv_p1;
        let c_p2 = &self.c_p2;
        let then_b_p3 = &self.then_b_p3;
        let else_b_p4 = &self.else_b_p4;
        let e_p5 = &self.e_p5;
        let lx_p6 = wx_p0.lx_p.clone();
        let pos_p7 = wx_p0.pos_p.clone();
        let wx1_p8 = {
            let mut this: crate::lower::node_::Wx = wx_p0.clone();
            this.pos_p = crate::lower::model::next_pos_f(&this.pos_p);
            this
        };
        let (name_ph, wx2_pi) = crate::lower::node_::fresh_name_f(&wx1_p8, &Text::lit("arm"));
        let base_p9 = Text::from(format!("{}{}{}", &wx_p0.node_p, &crate::lower::camel_f(&name_ph), &crate::lower::node_::keyed::row_suffix_f(wx_p0)));
        let yes_pa = crate::lower::node_::switch_::gen_row_of_f(&wx2_pi, menv_p1, then_b_p3, &crate::lower::model::OutTy::OutUnit, &Text::from(format!("{}Then", &base_p9)), &name_ph);
        let no_pb = crate::lower::node_::switch_::gen_row_of_f(&yes_pa.parent_p, menv_p1, else_b_p4, &crate::lower::model::OutTy::OutUnit, &Text::from(format!("{}Else", &base_p9)), &name_ph);
        let c_p2x = c_p2.clone();
        let menv_p1x = menv_p1.clone();
        let wx_p0x = wx_p0.clone();
        crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p6.clone(), menv_p1x.clone(), c_p2x.clone()), move |value_of_f_14903: crate::lower::types::Vl| {
            let cond_pc = crate::lower::types::as_bool_f(&value_of_f_14903);
            let tail_pd = crate::prelude::append(&crate::prelude::append(&Array::from(vec![crate::lower::model::Ex::XWeak(Rc::new(crate::lower::model::Ex::XSelf))]), &crate::lower::node_::keyed::hosted_passed_f(&wx_p0x)), &Array::from(vec![crate::lower::model::Ex::XCx]));
            let mk_fe = {
                let tail_pdx = tail_pd.clone();
                Rc::new(move |n_pj: &crate::lower::model::NodeDef| crate::lower::model::Ex::XCast(Rc::new(crate::lower::expr::try_of_f(&crate::lower::model::Ex::XCall(Text::from(format!("{}::build", &n_pj.name_p)), crate::prelude::append(&Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("path")), crate::lower::model::Ex::XVar(Text::lit("value"))]), &tail_pdx)))), crate::lower::model::OutTy::OutObj(Rc::new(crate::lower::model::OutTy::OutNamed(Text::lit("Row"), Array::new()))))) as Rc<dyn Fn(&crate::lower::model::NodeDef) -> crate::lower::model::Ex>
            };
            let select_pf = crate::lower::model::Ex::XIf(Rc::new(cond_pc.clone()), Rc::new((&mk_fe)(&yes_pa.node_p)), Rc::new((&mk_fe)(&no_pb.node_p)));
            let wx3_pg = {
                let mut this: crate::lower::node_::Wx = no_pb.parent_p.clone();
                this.gens_p = crate::prelude::push(&this.gens_p, &crate::lower::model::GenDef { name_p: name_ph.clone(), pos_p: pos_p7.clone(), at_p: crate::lower::node_::finish::place_at_f(&wx_p0x, &Text::lit("self"), &pos_p7), source_p: crate::lower::model::Ex::XUnit, value_ty_p: crate::lower::model::OutTy::OutUnit, select_p: select_pf.clone(), transparent_p: false, width_p: Nat::from(0u32), moved_p: crate::prelude::or(&crate::lower::node_::finish::hosted_rows_o(&wx_p0x), &Text::lit("")) });
                this.gen_holds_p = crate::prelude::push(&this.gen_holds_p, &(name_ph.clone(), Array::new()));
                this.rows_p = crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&crate::prelude::push(&this.rows_p, &yes_pa.node_p), &yes_pa.node_p.children_p), &Array::from(vec![no_pb.node_p.clone()])), &no_pb.node_p.children_p);
                this.getters_p = crate::prelude::push(&this.getters_p, &crate::lower::model::MethDef { name_p: Text::from(format!("{}_up", &name_ph)), recv_p: crate::lower::model::Recv::RecvRc, params_p: Array::from(vec![(Text::lit("v"), crate::lower::model::OutTy::OutUnit)]), cx_p: crate::lower::model::CxArg::CxMut, ret_p: crate::lower::model::OutTy::OutUnit, body_p: Array::new(), tail_p: crate::lower::model::Ex::XUnit, doc_p: Text::lit("An arm\'s result, which a building `if` of widgets drops.") });
                this
            };
            prism_rtl::Turn::Finished((wx3_pg.clone(), crate::lower::node_::Wres::WrUnit))
        })
    }
}

/// `Start IfGenLine, x`: what the function value is when passed to `@Run`.
pub fn start_if_gen_line_f(wx_p0: crate::lower::node_::Wx, menv_p1: crate::lower::types::Env, c_p2: crate::syntax::Expr, then_b_p3: crate::syntax::Block, else_b_p4: crate::syntax::Block, e_p5: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::node_::Wres)>> {
    Rc::new(IfGenLine { wx_p0, menv_p1, c_p2, then_b_p3, else_b_p4, e_p5 })
}
