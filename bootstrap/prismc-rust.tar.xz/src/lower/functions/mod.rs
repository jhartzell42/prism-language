//! The module `Lower.Functions`, from `target/bootstrap/src/prismc/lower/functions.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file. The runtime
//! side is reached from the crate, `crate::prelude` (and through it `::prism_rtl`), the
//! standard library from `::std`, and nothing is imported by name: a program's own type
//! (`Row`, `Option`) hides none of theirs. The traits are in scope unnamed, for their methods.

use crate::prelude::traits::*;

/// ```prism
/// BoundOf: fn Lx, Text -> [Text]
/// ```
pub fn bound_of_f(lx_p0: &crate::lower::Lx, text1: &crate::prelude::Text) -> crate::prelude::Array<crate::prelude::Text> {
    match text1 {
        c0_1 if (c0_1 == &crate::prelude::Text::lit("Prelude.Eq")) => crate::prelude::Array::from(vec![crate::prelude::Text::lit("std::Eq")]),
        c1_1 if (c1_1 == &crate::prelude::Text::lit("Prelude.Ord")) => crate::prelude::Array::from(vec![crate::prelude::Text::lit("std::Ord")]),
        c2_1 if (c2_1 == &crate::prelude::Text::lit("Prelude.Show")) => crate::prelude::Array::from(vec![crate::prelude::Text::lit("rt::Show")]),
        c3_1 if (c3_1 == &crate::prelude::Text::lit("Prelude.Num")) => crate::prelude::Array::from(vec![crate::prelude::Text::lit("rt::Num")]),
        c4_1 if (c4_1 == &crate::prelude::Text::lit("Prelude.Pod")) => crate::prelude::Array::from(vec![crate::prelude::Text::lit("rt::ToPod"), crate::prelude::Text::lit("rt::FromPod")]),
        cls_p6 => match crate::prelude::get(&lx_p0.g_p.traits_p, cls_p6) {
            ::std::option::Option::Some(tr_p7) => crate::prelude::Array::from(vec![crate::lower::path_in_f(lx_p0, &tr_p7.home_p, &crate::lower::trait_name_f(cls_p6))]),
            ::std::option::Option::None => crate::prelude::Array::new(),
        },
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// SchemeGenerics: fn Lx, Scheme -> [((Text, [Text]))]
/// ```
pub fn scheme_generics_f(lx_p0: &crate::lower::Lx, sc_p1: &crate::check::types::Scheme) -> crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>)> {
    crate::prelude::each(&sc_p1.qs_p, &(|q_p2: &crate::prelude::Text| {
        let bs_p3 = crate::prelude::fold(&sc_p1.bounds_p, &crate::prelude::Array::from(vec![crate::prelude::Text::lit("std::Clone")]), &(|acc_p5: &crate::prelude::Array<crate::prelude::Text>, (v_p6, cls_p7): &(crate::prelude::Text, crate::prelude::Text)| if v_p6 == q_p2 {
            crate::check::types::union_texts_f(acc_p5, &bound_of_f(lx_p0, cls_p7))
        } else {
            acc_p5.clone()
        }));
        let keyed_p4 = if keys_by_f(&sc_p1.ty_p, q_p2) {
            crate::check::types::union_texts_f(&bs_p3, &crate::prelude::Array::from(vec![crate::prelude::Text::lit("std::Ord")]))
        } else {
            bs_p3.clone()
        };
        (crate::lower::camel_f(q_p2), keyed_p4.clone())
    }))
}

/// ```prism
/// KeysBy: fn Ty, Text -> Bool
/// ```
pub fn keys_by_f(t_p0: &crate::check::types::Ty, q_p1: &crate::prelude::Text) -> bool {
    match t_p0 {
        crate::check::types::Ty::TyMap(k_p2, v_p3) => ((&**k_p2 == &crate::check::types::Ty::TyQ(q_p1.clone())) || keys_by_f(&**k_p2, q_p1)) || keys_by_f(&**v_p3, q_p1),
        crate::check::types::Ty::TyCon(_, ts_p4) => crate::prelude::fold(ts_p4, &false, &(|found_p5: &bool, x_p6: &crate::check::types::Ty| *found_p5 || keys_by_f(x_p6, q_p1))),
        crate::check::types::Ty::TyFn(_, ps_p7, r_p8) => crate::prelude::fold(ps_p7, &false, &(|found_p9: &bool, x_pa: &crate::check::types::Ty| *found_p9 || keys_by_f(x_pa, q_p1))) || keys_by_f(&**r_p8, q_p1),
        crate::check::types::Ty::TyTuple(ts_pb) => crate::prelude::fold(ts_pb, &false, &(|found_pc: &bool, x_pd: &crate::check::types::Ty| *found_pc || keys_by_f(x_pd, q_p1))),
        crate::check::types::Ty::TyArray(x_pe) => keys_by_f(&**x_pe, q_p1),
        crate::check::types::Ty::TySig(_, x_pf) => keys_by_f(&**x_pf, q_p1),
        crate::check::types::Ty::TyAt(x_pg, _) => keys_by_f(&**x_pg, q_p1),
        _ => false,
    }
}

/// ```prism
/// ParamNames: unbounded fn Lx, [FnClause], [OutTy] -> [((Text, Bool))]
/// ```
pub fn param_names_f(lx_p0: &crate::lower::Lx, clauses_p1: &crate::prelude::Array<crate::syntax::decls::FnClause>, pts_p2: &crate::prelude::Array<crate::lower::model::OutTy>) -> crate::prelude::Array<(crate::prelude::Text, bool)> {
    crate::prelude::run_to_end(crate::prelude::each_job(crate::check::errors::range0_f(&crate::prelude::len(pts_p2)), {
        let clauses_p1x = clauses_p1.clone();
        let lx_p0x = lx_p0.clone();
        let pts_p2x = pts_p2.clone();
        ::std::rc::Rc::new(move |p0: crate::prelude::Nat| {
            let clauses_p1xy = clauses_p1x.clone();
            let lx_p0xy = lx_p0x.clone();
            let pts_p2xy = pts_p2x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let i_p3 = p0;
                {
                    let names_p4 = crate::prelude::each(&clauses_p1xy, &(|c_p8: &crate::syntax::decls::FnClause| plain_binder_f(&lx_p0xy, &crate::prelude::or(&crate::prelude::index(&c_p8.params_p, &i_p3), &crate::lower::patterns::dummy_pat_p()))));
                    let first_p5 = crate::prelude::or(&crate::prelude::index(&names_p4, &crate::prelude::Nat::from(0u32)), &crate::prelude::Text::lit(""));
                    let same_p6 = (&first_p5 != &crate::prelude::Text::lit("")) && crate::prelude::fold(&names_p4, &true, &(|ok_p9: &bool, n_pa: &crate::prelude::Text| *ok_p9 && (n_pa == &first_p5)));
                    let span_p7 = match &*crate::prelude::or(&crate::prelude::index(&crate::prelude::or(&crate::prelude::index(&clauses_p1xy, &crate::prelude::Nat::from(0u32)), &dummy_clause_p()).params_p, &i_p3), &crate::lower::patterns::dummy_pat_p()).kind_p {
                        crate::syntax::PatternKind::PName(n_pb) => n_pb.span_p.clone(),
                        _ => crate::syntax::Range { start_p: crate::prelude::Nat::from(0u32), end_p: crate::prelude::Nat::from(0u32) },
                    };
                    if same_p6 {
                        crate::prelude::call_then(crate::lower::start_local_name_at_f(lx_p0xy.clone(), first_p5.clone(), span_p7.clone()), move |local_name_at_f_3582: crate::prelude::Text| ::prism_rtl::Turn::Finished((local_name_at_f_3582, false)))
                    } else {
                        ::prism_rtl::Turn::Finished((param_word_f(&crate::prelude::or(&crate::prelude::index(&pts_p2xy, &i_p3), &crate::lower::model::OutTy::OutUnit), &i_p3), true))
                    }
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Text, bool)>>>
    }))
}

/// The step machine of `ParamNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParamNames: unbounded fn Lx, [FnClause], [OutTy] -> [((Text, Bool))]
/// ```
pub struct ParamNames {
    pub lx_p0: crate::lower::Lx,
    pub clauses_p1: crate::prelude::Array<crate::syntax::decls::FnClause>,
    pub pts_p2: crate::prelude::Array<crate::lower::model::OutTy>,
}

impl ::prism_rtl::Job<crate::prelude::Array<(crate::prelude::Text, bool)>> for ParamNames {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<(crate::prelude::Text, bool)>> {
        let lx_p0 = &self.lx_p0;
        let clauses_p1 = &self.clauses_p1;
        let pts_p2 = &self.pts_p2;
        crate::prelude::each_job(crate::check::errors::range0_f(&crate::prelude::len(pts_p2)), {
            let clauses_p1x = clauses_p1.clone();
            let lx_p0x = lx_p0.clone();
            let pts_p2x = pts_p2.clone();
            ::std::rc::Rc::new(move |p0: crate::prelude::Nat| {
                let clauses_p1xy = clauses_p1x.clone();
                let lx_p0xy = lx_p0x.clone();
                let pts_p2xy = pts_p2x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let i_p3 = p0;
                    {
                        let names_p4 = crate::prelude::each(&clauses_p1xy, &(|c_p8: &crate::syntax::decls::FnClause| plain_binder_f(&lx_p0xy, &crate::prelude::or(&crate::prelude::index(&c_p8.params_p, &i_p3), &crate::lower::patterns::dummy_pat_p()))));
                        let first_p5 = crate::prelude::or(&crate::prelude::index(&names_p4, &crate::prelude::Nat::from(0u32)), &crate::prelude::Text::lit(""));
                        let same_p6 = (&first_p5 != &crate::prelude::Text::lit("")) && crate::prelude::fold(&names_p4, &true, &(|ok_p9: &bool, n_pa: &crate::prelude::Text| *ok_p9 && (n_pa == &first_p5)));
                        let span_p7 = match &*crate::prelude::or(&crate::prelude::index(&crate::prelude::or(&crate::prelude::index(&clauses_p1xy, &crate::prelude::Nat::from(0u32)), &dummy_clause_p()).params_p, &i_p3), &crate::lower::patterns::dummy_pat_p()).kind_p {
                            crate::syntax::PatternKind::PName(n_pb) => n_pb.span_p.clone(),
                            _ => crate::syntax::Range { start_p: crate::prelude::Nat::from(0u32), end_p: crate::prelude::Nat::from(0u32) },
                        };
                        if same_p6 {
                            crate::prelude::call_then(crate::lower::start_local_name_at_f(lx_p0xy.clone(), first_p5.clone(), span_p7.clone()), move |local_name_at_f_3582: crate::prelude::Text| ::prism_rtl::Turn::Finished((local_name_at_f_3582, false)))
                        } else {
                            ::prism_rtl::Turn::Finished((param_word_f(&crate::prelude::or(&crate::prelude::index(&pts_p2xy, &i_p3), &crate::lower::model::OutTy::OutUnit), &i_p3), true))
                        }
                    }
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Text, bool)>>>
        }).cycle()
    }
}

/// `Start ParamNames, x`: what the function value is when passed to `@Run`.
pub fn start_param_names_f(lx_p0: crate::lower::Lx, clauses_p1: crate::prelude::Array<crate::syntax::decls::FnClause>, pts_p2: crate::prelude::Array<crate::lower::model::OutTy>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<(crate::prelude::Text, bool)>>> {
    ::std::rc::Rc::new(ParamNames { lx_p0, clauses_p1, pts_p2 })
}

/// ```prism
/// PlainBinder: fn Lx, Pattern -> Text
/// ```
pub fn plain_binder_f(lx_p0: &crate::lower::Lx, p_p1: &crate::syntax::Pattern) -> crate::prelude::Text {
    match &*p_p1.kind_p {
        crate::syntax::PatternKind::PName(n_p2) => {
            let (qk_o4, why_p5) = crate::check::env::names::resolve_value_f(&lx_p0.g_p, &lx_p0.home_p, n_p2);
            let is_ctor_p3 = match &qk_o4 {
                ::std::option::Option::Some(qk_p6) => crate::check::env::has_key_f(&lx_p0.g_p.ctors_p, qk_p6) && (crate::check::env::is_upper_text_f(&crate::lower::base_f(&crate::check::env::sname_key_f(n_p2))) || crate::lower::patterns::is_unit_ctor_f(lx_p0, qk_p6)),
                ::std::option::Option::None => false,
            };
            if is_ctor_p3 {
                crate::prelude::Text::lit("")
            } else {
                crate::check::env::sname_key_f(n_p2)
            }
        },
        crate::syntax::PatternKind::PGroup(q_p7) => plain_binder_f(lx_p0, &**q_p7),
        _ => crate::prelude::Text::lit(""),
    }
}

/// ```prism
/// ParamWord: fn OutTy, Nat -> Text
/// ```
pub fn param_word_f(t_p0: &crate::lower::model::OutTy, i_p1: &crate::prelude::Nat) -> crate::prelude::Text {
    let base_p2 = match t_p0 {
        crate::lower::model::OutTy::OutNamed(n_p3, _) => crate::lower::snake_f(&crate::lower::model::ref_last_f(n_p3)),
        crate::lower::model::OutTy::OutText => crate::prelude::Text::lit("text"),
        crate::lower::model::OutTy::OutNat => crate::prelude::Text::lit("n"),
        crate::lower::model::OutTy::OutInt => crate::prelude::Text::lit("i"),
        crate::lower::model::OutTy::OutArray(_) => crate::prelude::Text::lit("xs"),
        crate::lower::model::OutTy::OutMap(_, _) => crate::prelude::Text::lit("map"),
        crate::lower::model::OutTy::OutOpt(_) => crate::prelude::Text::lit("opt"),
        _ => crate::prelude::Text::lit("arg"),
    };
    crate::prelude::Text::from(format!("{}{}", &base_p2, i_p1))
}

/// ```prism
/// PeelUnlessWhole: fn Lx, Ty -> Ty
/// ```
pub fn peel_unless_whole_f(lx_p0: &crate::lower::Lx, t_p1: &crate::check::types::Ty) -> crate::check::types::Ty {
    if lx_p0.whole_p { t_p1.clone() } else { crate::lower::types::peel_f(t_p1) }
}

/// ```prism
/// ClausesBody: unbounded fn Lx, Env, [FnClause], [((Text, Bool))], [Ty], (fn Lx, Env, FnBody -> Ex), Text, OutTy -> Ex
/// ```
pub fn clauses_body_f(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, clauses_p2: &crate::prelude::Array<crate::syntax::decls::FnClause>, names_p3: &crate::prelude::Array<(crate::prelude::Text, bool)>, ptys_p4: &crate::prelude::Array<crate::check::types::Ty>, body_f5: &::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::Lx, crate::lower::types::Env, crate::syntax::decls::FnBody)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>>>, label_p6: &crate::prelude::Text, t_p7: &crate::lower::model::OutTy) -> crate::lower::model::Ex {
    let env1_p8 = crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(names_p3)), env_p1.clone(), {
        let names_p3x = names_p3.clone();
        let lx_p0x = lx_p0.clone();
        let clauses_p2x = clauses_p2.clone();
        let ptys_p4x = ptys_p4.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::lower::types::Env, crate::prelude::Nat)| {
            let names_p3xy = names_p3x.clone();
            let lx_p0xy = lx_p0x.clone();
            let clauses_p2xy = clauses_p2x.clone();
            let ptys_p4xy = ptys_p4x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let en_pa = p0;
                let i_pb = p1;
                {
                    let (rs_pc, matched_pd) = crate::prelude::or(&crate::prelude::index(&names_p3xy, &i_pb), &(crate::prelude::Text::lit(""), true));
                    if matched_pd {
                        ::prism_rtl::Turn::Finished(en_pa.clone())
                    } else {
                        crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0xy.clone(), peel_unless_whole_f(&lx_p0xy, &crate::prelude::or(&crate::prelude::index(&ptys_p4xy, &i_pb), &crate::check::types::Ty::TyErr))), move |out_ty_of_f_5271: crate::lower::model::OutTy| ::prism_rtl::Turn::Finished(crate::lower::types::bind_f(&en_pa, &plain_binder_f(&lx_p0xy, &crate::prelude::or(&crate::prelude::index(&crate::prelude::or(&crate::prelude::index(&clauses_p2xy, &crate::prelude::Nat::from(0u32)), &dummy_clause_p()).params_p, &i_pb), &crate::lower::patterns::dummy_pat_p())), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(rs_pc.clone()), crate::lower::types::Holding::ByRef, out_ty_of_f_5271))))
                    }
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::types::Env, crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::types::Env>>>
    }));
    let scrut_ix_p9 = crate::prelude::filter(&crate::check::errors::range0_f(&crate::prelude::len(names_p3)), &(|i_pe: &crate::prelude::Nat| match crate::prelude::index(names_p3, i_pe) {
        ::std::option::Option::Some((_, true)) => true,
        _ => false,
    }));
    if &crate::prelude::len(&scrut_ix_p9) == &crate::prelude::Nat::from(0u32) {
        {
            let c_pf = crate::prelude::or(&crate::prelude::index(clauses_p2, &crate::prelude::Nat::from(0u32)), &dummy_clause_p());
            crate::prelude::run_to_end(body_f5((lx_p0.clone(), env1_p8.clone(), c_pf.body_p.clone())))
        }
    } else {
        {
            let scrut_pg = 'm5583: {
                if let m5583_0 = &scrut_ix_p9 && (m5583_0.len() == 1) && let ::std::option::Option::Some(i_pi) = crate::prelude::index(m5583_0, &crate::prelude::Nat::from(0u32)) {
                    break 'm5583 crate::lower::model::Ex::XVar(crate::prelude::or(&crate::prelude::index(&crate::prelude::each(names_p3, &(|(n_pj, _): &(crate::prelude::Text, bool)| n_pj.clone())), &i_pi), &crate::prelude::Text::lit("arg")));
                }
                crate::lower::model::Ex::XTuple(crate::prelude::each(&scrut_ix_p9, &(|i_pk: &crate::prelude::Nat| crate::lower::model::Ex::XVar(crate::prelude::or(&crate::prelude::index(&crate::prelude::each(names_p3, &(|(n_pl, _): &(crate::prelude::Text, bool)| n_pl.clone())), i_pk), &crate::prelude::Text::lit("arg"))))))
            };
            let arms_ph = crate::prelude::run_to_end(crate::prelude::each_job(crate::check::errors::range0_f(&crate::prelude::len(clauses_p2)), {
                let clauses_p2x = clauses_p2.clone();
                let scrut_ix_p9x = scrut_ix_p9.clone();
                let lx_p0x = lx_p0.clone();
                let ptys_p4x = ptys_p4.clone();
                let label_p6x = label_p6.clone();
                let body_f5x = body_f5.clone();
                let env1_p8x = env1_p8.clone();
                ::std::rc::Rc::new(move |p0: crate::prelude::Nat| {
                    let clauses_p2xy = clauses_p2x.clone();
                    let scrut_ix_p9xy = scrut_ix_p9x.clone();
                    let lx_p0xy = lx_p0x.clone();
                    let ptys_p4xy = ptys_p4x.clone();
                    let label_p6xy = label_p6x.clone();
                    let body_f5xy = body_f5x.clone();
                    let env1_p8xy = env1_p8x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let ci_pm = p0;
                        {
                            let c_pn = crate::prelude::or(&crate::prelude::index(&clauses_p2xy, &ci_pm), &dummy_clause_p());
                            crate::prelude::call_value(crate::prelude::each_job(scrut_ix_p9xy.clone(), {
                                let lx_p0xyx = lx_p0xy.clone();
                                let c_pnx = c_pn.clone();
                                let ptys_p4xyx = ptys_p4xy.clone();
                                let label_p6xyx = label_p6xy.clone();
                                let ci_pmx = ci_pm.clone();
                                ::std::rc::Rc::new(move |p0: crate::prelude::Nat| {
                                    let lx_p0xyxy = lx_p0xyx.clone();
                                    let c_pnxy = c_pnx.clone();
                                    let ptys_p4xyxy = ptys_p4xyx.clone();
                                    let label_p6xyxy = label_p6xyx.clone();
                                    let ci_pmxy = ci_pmx.clone();
                                    crate::prelude::entered(crate::prelude::once_job(move || {
                                        let i_ps = p0;
                                        ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::lower::patterns::RustPat { lx_p0: lx_p0xyxy.clone(), p_p1: crate::prelude::or(&crate::prelude::index(&c_pnxy.params_p, &i_ps), &crate::lower::patterns::dummy_pat_p()), ty_p2: crate::prelude::or(&crate::prelude::index(&ptys_p4xyxy, &i_ps), &crate::check::types::Ty::TyErr), mode_p3: crate::lower::types::Holding::ByRef, fresh_p4: crate::prelude::Text::from(format!("{}{}_{}", &label_p6xyxy, &ci_pmxy, &i_ps)) }))
                                    }))
                                }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::patterns::PatOut>>>
                            }), move |each_5898: crate::prelude::Array<crate::lower::patterns::PatOut>| {
                                let pos_po = each_5898;
                                let pa_pp = 'm6024: {
                                    if let m6024_0 = &pos_po && (m6024_0.len() == 1) && let ::std::option::Option::Some(o_pt) = crate::prelude::index(m6024_0, &crate::prelude::Nat::from(0u32)) {
                                        break 'm6024 o_pt.pa_p.clone();
                                    }
                                    crate::lower::model::Pa::PaTuple(crate::prelude::each(&pos_po, &(|o_pu: &crate::lower::patterns::PatOut| o_pu.pa_p.clone())))
                                };
                                let conds_pq = crate::prelude::fold(&pos_po, &crate::prelude::Array::new(), &(|acc_pv: &crate::prelude::Array<crate::lower::model::Cc>, o_p10: &crate::lower::patterns::PatOut| crate::prelude::append(acc_pv, &o_p10.conds_p)));
                                let binds_pr = crate::prelude::fold(&pos_po, &crate::prelude::Array::new(), &(|acc_p11: &crate::prelude::Array<(crate::prelude::Text, crate::lower::types::Bn)>, o_p12: &crate::lower::patterns::PatOut| crate::prelude::append(acc_p11, &o_p12.binds_p)));
                                crate::prelude::call_value((&body_f5xy)((lx_p0xy.clone(), crate::lower::expr::bind_all_f(&env1_p8xy, &binds_pr), c_pn.body_p.clone())), move |body_6304: crate::lower::model::Ex| ::prism_rtl::Turn::Finished(crate::lower::model::XArm { pat_p: pa_pp.clone(), conds_p: conds_pq.clone(), body_p: body_6304 }))
                            })
                        }
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::XArm>>>
            }));
            crate::lower::types::own_f(&crate::lower::expr::arms_value_f(&scrut_pg, &arms_ph, &crate::prelude::Text::from(format!("\'{}", label_p6)), t_p7))
        }
    }
}

/// The step machine of `ClausesBody`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ClausesBody: unbounded fn Lx, Env, [FnClause], [((Text, Bool))], [Ty], (fn Lx, Env, FnBody -> Ex), Text, OutTy -> Ex
/// ```
pub struct ClausesBody {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub clauses_p2: crate::prelude::Array<crate::syntax::decls::FnClause>,
    pub names_p3: crate::prelude::Array<(crate::prelude::Text, bool)>,
    pub ptys_p4: crate::prelude::Array<crate::check::types::Ty>,
    pub body_f5: ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::Lx, crate::lower::types::Env, crate::syntax::decls::FnBody)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>>>,
    pub label_p6: crate::prelude::Text,
    pub t_p7: crate::lower::model::OutTy,
}

impl ::prism_rtl::Job<crate::lower::model::Ex> for ClausesBody {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::lower::model::Ex> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let clauses_p2 = &self.clauses_p2;
        let names_p3 = &self.names_p3;
        let ptys_p4 = &self.ptys_p4;
        let body_f5 = &self.body_f5;
        let label_p6 = &self.label_p6;
        let t_p7 = &self.t_p7;
        let body_f5x = body_f5.clone();
        let clauses_p2x = clauses_p2.clone();
        let env_p1x = env_p1.clone();
        let label_p6x = label_p6.clone();
        let lx_p0x = lx_p0.clone();
        let names_p3x = names_p3.clone();
        let ptys_p4x = ptys_p4.clone();
        let t_p7x = t_p7.clone();
        crate::prelude::call_value(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(&names_p3x)), env_p1x.clone(), {
            let names_p3xx = names_p3x.clone();
            let lx_p0xx = lx_p0x.clone();
            let clauses_p2xx = clauses_p2x.clone();
            let ptys_p4xx = ptys_p4x.clone();
            ::std::rc::Rc::new(move |(p0, p1): (crate::lower::types::Env, crate::prelude::Nat)| {
                let names_p3xxy = names_p3xx.clone();
                let lx_p0xxy = lx_p0xx.clone();
                let clauses_p2xxy = clauses_p2xx.clone();
                let ptys_p4xxy = ptys_p4xx.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let en_pa = p0;
                    let i_pb = p1;
                    {
                        let (rs_pc, matched_pd) = crate::prelude::or(&crate::prelude::index(&names_p3xxy, &i_pb), &(crate::prelude::Text::lit(""), true));
                        if matched_pd {
                            ::prism_rtl::Turn::Finished(en_pa.clone())
                        } else {
                            crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0xxy.clone(), peel_unless_whole_f(&lx_p0xxy, &crate::prelude::or(&crate::prelude::index(&ptys_p4xxy, &i_pb), &crate::check::types::Ty::TyErr))), move |out_ty_of_f_5271: crate::lower::model::OutTy| ::prism_rtl::Turn::Finished(crate::lower::types::bind_f(&en_pa, &plain_binder_f(&lx_p0xxy, &crate::prelude::or(&crate::prelude::index(&crate::prelude::or(&crate::prelude::index(&clauses_p2xxy, &crate::prelude::Nat::from(0u32)), &dummy_clause_p()).params_p, &i_pb), &crate::lower::patterns::dummy_pat_p())), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(rs_pc.clone()), crate::lower::types::Holding::ByRef, out_ty_of_f_5271))))
                        }
                    }
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::types::Env, crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::types::Env>>>
        }), move |fold_5027: crate::lower::types::Env| {
            let env1_p8 = fold_5027;
            let scrut_ix_p9 = crate::prelude::filter(&crate::check::errors::range0_f(&crate::prelude::len(&names_p3x)), &(|i_pe: &crate::prelude::Nat| match crate::prelude::index(&names_p3x, i_pe) {
                ::std::option::Option::Some((_, true)) => true,
                _ => false,
            }));
            if &crate::prelude::len(&scrut_ix_p9) == &crate::prelude::Nat::from(0u32) {
                {
                    let c_pf = crate::prelude::or(&crate::prelude::index(&clauses_p2x, &crate::prelude::Nat::from(0u32)), &dummy_clause_p());
                    (&body_f5x)((lx_p0x.clone(), env1_p8.clone(), c_pf.body_p.clone())).cycle()
                }
            } else {
                {
                    let scrut_pg = 'm5583: {
                        if let m5583_0 = &scrut_ix_p9 && (m5583_0.len() == 1) && let ::std::option::Option::Some(i_pi) = crate::prelude::index(m5583_0, &crate::prelude::Nat::from(0u32)) {
                            break 'm5583 crate::lower::model::Ex::XVar(crate::prelude::or(&crate::prelude::index(&crate::prelude::each(&names_p3x, &(|(n_pj, _): &(crate::prelude::Text, bool)| n_pj.clone())), &i_pi), &crate::prelude::Text::lit("arg")));
                        }
                        crate::lower::model::Ex::XTuple(crate::prelude::each(&scrut_ix_p9, &(|i_pk: &crate::prelude::Nat| crate::lower::model::Ex::XVar(crate::prelude::or(&crate::prelude::index(&crate::prelude::each(&names_p3x, &(|(n_pl, _): &(crate::prelude::Text, bool)| n_pl.clone())), i_pk), &crate::prelude::Text::lit("arg"))))))
                    };
                    crate::prelude::call_value(crate::prelude::each_job(crate::check::errors::range0_f(&crate::prelude::len(&clauses_p2x)), {
                        let clauses_p2xx = clauses_p2x.clone();
                        let scrut_ix_p9x = scrut_ix_p9.clone();
                        let lx_p0xx = lx_p0x.clone();
                        let ptys_p4xx = ptys_p4x.clone();
                        let label_p6xx = label_p6x.clone();
                        let body_f5xx = body_f5x.clone();
                        let env1_p8x = env1_p8.clone();
                        ::std::rc::Rc::new(move |p0: crate::prelude::Nat| {
                            let clauses_p2xxy = clauses_p2xx.clone();
                            let scrut_ix_p9xy = scrut_ix_p9x.clone();
                            let lx_p0xxy = lx_p0xx.clone();
                            let ptys_p4xxy = ptys_p4xx.clone();
                            let label_p6xxy = label_p6xx.clone();
                            let body_f5xxy = body_f5xx.clone();
                            let env1_p8xy = env1_p8x.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let ci_pm = p0;
                                {
                                    let c_pn = crate::prelude::or(&crate::prelude::index(&clauses_p2xxy, &ci_pm), &dummy_clause_p());
                                    crate::prelude::call_value(crate::prelude::each_job(scrut_ix_p9xy.clone(), {
                                        let lx_p0xxyx = lx_p0xxy.clone();
                                        let c_pnx = c_pn.clone();
                                        let ptys_p4xxyx = ptys_p4xxy.clone();
                                        let label_p6xxyx = label_p6xxy.clone();
                                        let ci_pmx = ci_pm.clone();
                                        ::std::rc::Rc::new(move |p0: crate::prelude::Nat| {
                                            let lx_p0xxyxy = lx_p0xxyx.clone();
                                            let c_pnxy = c_pnx.clone();
                                            let ptys_p4xxyxy = ptys_p4xxyx.clone();
                                            let label_p6xxyxy = label_p6xxyx.clone();
                                            let ci_pmxy = ci_pmx.clone();
                                            crate::prelude::entered(crate::prelude::once_job(move || {
                                                let i_ps = p0;
                                                ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::lower::patterns::RustPat { lx_p0: lx_p0xxyxy.clone(), p_p1: crate::prelude::or(&crate::prelude::index(&c_pnxy.params_p, &i_ps), &crate::lower::patterns::dummy_pat_p()), ty_p2: crate::prelude::or(&crate::prelude::index(&ptys_p4xxyxy, &i_ps), &crate::check::types::Ty::TyErr), mode_p3: crate::lower::types::Holding::ByRef, fresh_p4: crate::prelude::Text::from(format!("{}{}_{}", &label_p6xxyxy, &ci_pmxy, &i_ps)) }))
                                            }))
                                        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::patterns::PatOut>>>
                                    }), move |each_5898: crate::prelude::Array<crate::lower::patterns::PatOut>| {
                                        let pos_po = each_5898;
                                        let pa_pp = 'm6024: {
                                            if let m6024_0 = &pos_po && (m6024_0.len() == 1) && let ::std::option::Option::Some(o_pt) = crate::prelude::index(m6024_0, &crate::prelude::Nat::from(0u32)) {
                                                break 'm6024 o_pt.pa_p.clone();
                                            }
                                            crate::lower::model::Pa::PaTuple(crate::prelude::each(&pos_po, &(|o_pu: &crate::lower::patterns::PatOut| o_pu.pa_p.clone())))
                                        };
                                        let conds_pq = crate::prelude::fold(&pos_po, &crate::prelude::Array::new(), &(|acc_pv: &crate::prelude::Array<crate::lower::model::Cc>, o_p10: &crate::lower::patterns::PatOut| crate::prelude::append(acc_pv, &o_p10.conds_p)));
                                        let binds_pr = crate::prelude::fold(&pos_po, &crate::prelude::Array::new(), &(|acc_p11: &crate::prelude::Array<(crate::prelude::Text, crate::lower::types::Bn)>, o_p12: &crate::lower::patterns::PatOut| crate::prelude::append(acc_p11, &o_p12.binds_p)));
                                        crate::prelude::call_value((&body_f5xxy)((lx_p0xxy.clone(), crate::lower::expr::bind_all_f(&env1_p8xy, &binds_pr), c_pn.body_p.clone())), move |body_6304: crate::lower::model::Ex| ::prism_rtl::Turn::Finished(crate::lower::model::XArm { pat_p: pa_pp.clone(), conds_p: conds_pq.clone(), body_p: body_6304 }))
                                    })
                                }
                            }))
                        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::XArm>>>
                    }), move |each_5793: crate::prelude::Array<crate::lower::model::XArm>| {
                        let arms_ph = each_5793;
                        ::prism_rtl::Turn::Finished(crate::lower::types::own_f(&crate::lower::expr::arms_value_f(&scrut_pg, &arms_ph, &crate::prelude::Text::from(format!("\'{}", &label_p6x)), &t_p7x)))
                    })
                }
            }
        })
    }
}

/// `Start ClausesBody, x`: what the function value is when passed to `@Run`.
pub fn start_clauses_body_f(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, clauses_p2: crate::prelude::Array<crate::syntax::decls::FnClause>, names_p3: crate::prelude::Array<(crate::prelude::Text, bool)>, ptys_p4: crate::prelude::Array<crate::check::types::Ty>, body_f5: ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::Lx, crate::lower::types::Env, crate::syntax::decls::FnBody)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>>>, label_p6: crate::prelude::Text, t_p7: crate::lower::model::OutTy) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>> {
    ::std::rc::Rc::new(ClausesBody { lx_p0, env_p1, clauses_p2, names_p3, ptys_p4, body_f5, label_p6, t_p7 })
}

/// ```prism
/// let dummyClause
/// ```
pub fn dummy_clause_p() -> crate::syntax::decls::FnClause {
    crate::syntax::decls::FnClause { name_p: crate::syntax::decls::DefName::DefOp(crate::prelude::Text::lit(""), crate::syntax::Range { start_p: crate::prelude::Nat::from(0u32), end_p: crate::prelude::Nat::from(0u32) }), params_p: crate::prelude::Array::new(), body_p: crate::syntax::decls::FnBody::BodyExpr(crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::EError), span_p: crate::syntax::Range { start_p: crate::prelude::Nat::from(0u32), end_p: crate::prelude::Nat::from(0u32) } }), span_p: crate::syntax::Range { start_p: crate::prelude::Nat::from(0u32), end_p: crate::prelude::Nat::from(0u32) } }
}

/// ```prism
/// FnBodyValue: unbounded fn Lx, Env, FnBody -> Ex
/// ```
pub fn fn_body_value_f(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, fn_body2: &crate::syntax::decls::FnBody) -> crate::lower::model::Ex {
    match fn_body2 {
        crate::syntax::decls::FnBody::BodyExpr(x_p2) => crate::lower::types::own_f(&crate::lower::expr::value_of_f(lx_p0, env_p1, x_p2)),
        crate::syntax::decls::FnBody::BodyBlock(b_p5) => crate::lower::types::own_f(&crate::lower::expr::block_value_f(lx_p0, env_p1, b_p5)),
    }
}

/// The step machine of `FnBodyValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FnBodyValue: unbounded fn Lx, Env, FnBody -> Ex
/// ```
pub struct FnBodyValue {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub fn_body2: crate::syntax::decls::FnBody,
}

impl ::prism_rtl::Job<crate::lower::model::Ex> for FnBodyValue {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::lower::model::Ex> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let fn_body2 = &self.fn_body2;
        match fn_body2 {
            crate::syntax::decls::FnBody::BodyExpr(x_p2) => {
                let env_p1x = env_p1.clone();
                let lx_p0x = lx_p0.clone();
                let x_p2x = x_p2.clone();
                crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p0x.clone(), env_p1x.clone(), x_p2x.clone()), move |value_of_f_6663: crate::lower::types::Vl| ::prism_rtl::Turn::Finished(crate::lower::types::own_f(&value_of_f_6663)))
            },
            crate::syntax::decls::FnBody::BodyBlock(b_p5) => {
                let b_p5x = b_p5.clone();
                let env_p1x = env_p1.clone();
                let lx_p0x = lx_p0.clone();
                crate::prelude::call_then(crate::lower::expr::start_block_value_f(lx_p0x.clone(), env_p1x.clone(), b_p5x.clone()), move |block_value_f_6728: crate::lower::types::Vl| ::prism_rtl::Turn::Finished(crate::lower::types::own_f(&block_value_f_6728)))
            },
        }
    }
}

/// `Start FnBodyValue, x`: what the function value is when passed to `@Run`.
pub fn start_fn_body_value_f(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, fn_body2: crate::syntax::decls::FnBody) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>> {
    ::std::rc::Rc::new(FnBodyValue { lx_p0, env_p1, fn_body2 })
}

/// ```prism
/// SignatureTys: fn Scheme -> (([Ty], Ty))
/// ```
pub fn signature_tys_f(sc_p0: &crate::check::types::Scheme) -> (crate::prelude::Array<crate::check::types::Ty>, crate::check::types::Ty) {
    let (ptys0_p5, res_p6) = match &sc_p0.ty_p {
        crate::check::types::Ty::TyFn(_, ps_p2, r_p3) => (ps_p2.clone(), (**r_p3).clone()),
        other_p4 => (crate::prelude::Array::new(), other_p4.clone()),
    };
    let ptys_p1 = if crate::lower::types::has_blueprint_f(&res_p6) {
        crate::prelude::each(&ptys0_p5, &(|p_p7: &crate::check::types::Ty| crate::lower::types::event_param_f(p_p7)))
    } else {
        ptys0_p5.clone()
    };
    (ptys_p1.clone(), res_p6.clone())
}

/// ```prism
/// SignatureOut: unbounded fn Lx, Text, Scheme -> (([OutTy], OutTy))
/// ```
pub fn signature_out_f(lx_p0: &crate::lower::Lx, qk_p1: &crate::prelude::Text, sc_p2: &crate::check::types::Scheme) -> (crate::prelude::Array<crate::lower::model::OutTy>, crate::lower::model::OutTy) {
    let (ptys_p6, res_p7) = signature_tys_f(sc_p2);
    let whole_p3 = crate::lower::expr::is_whole_fn_f(lx_p0, qk_p1);
    let pts_p4 = crate::prelude::run_to_end(crate::prelude::each_job(ptys_p6.clone(), {
        let lx_p0x = lx_p0.clone();
        let whole_p3x = whole_p3;
        ::std::rc::Rc::new(move |p0: crate::check::types::Ty| {
            let lx_p0xy = lx_p0x.clone();
            let whole_p3xy = whole_p3x;
            crate::prelude::entered(crate::prelude::once_job(move || {
                let p_p8 = p0;
                ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::lower::types::OutTyOf { lx_p0: lx_p0xy.clone(), t_p1: if whole_p3xy { p_p8.clone() } else { crate::lower::types::peel_f(&p_p8) } }))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::OutTy>>>
    }));
    let ret_p5 = crate::lower::types::out_ty_of_f(lx_p0, &(if whole_p3 { res_p7.clone() } else { crate::lower::types::peel_f(&res_p7) }));
    (pts_p4.clone(), ret_p5.clone())
}

/// The step machine of `SignatureOut`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SignatureOut: unbounded fn Lx, Text, Scheme -> (([OutTy], OutTy))
/// ```
pub struct SignatureOut {
    pub lx_p0: crate::lower::Lx,
    pub qk_p1: crate::prelude::Text,
    pub sc_p2: crate::check::types::Scheme,
}

impl ::prism_rtl::Job<(crate::prelude::Array<crate::lower::model::OutTy>, crate::lower::model::OutTy)> for SignatureOut {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::prelude::Array<crate::lower::model::OutTy>, crate::lower::model::OutTy)> {
        let lx_p0 = &self.lx_p0;
        let qk_p1 = &self.qk_p1;
        let sc_p2 = &self.sc_p2;
        let (ptys_p6, res_p7) = signature_tys_f(sc_p2);
        let whole_p3 = crate::lower::expr::is_whole_fn_f(lx_p0, qk_p1);
        let lx_p0x = lx_p0.clone();
        crate::prelude::call_value(crate::prelude::each_job(ptys_p6.clone(), {
            let lx_p0xx = lx_p0x.clone();
            let whole_p3x = whole_p3;
            ::std::rc::Rc::new(move |p0: crate::check::types::Ty| {
                let lx_p0xxy = lx_p0xx.clone();
                let whole_p3xy = whole_p3x;
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let p_p8 = p0;
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::lower::types::OutTyOf { lx_p0: lx_p0xxy.clone(), t_p1: if whole_p3xy { p_p8.clone() } else { crate::lower::types::peel_f(&p_p8) } }))
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::OutTy>>>
        }), move |each_7534: crate::prelude::Array<crate::lower::model::OutTy>| {
            let pts_p4 = each_7534;
            crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0x.clone(), if whole_p3 { res_p7.clone() } else { crate::lower::types::peel_f(&res_p7) }), move |out_ty_of_f_7603: crate::lower::model::OutTy| {
                let ret_p5 = out_ty_of_f_7603;
                ::prism_rtl::Turn::Finished((pts_p4.clone(), ret_p5.clone()))
            })
        })
    }
}

/// `Start SignatureOut, x`: what the function value is when passed to `@Run`.
pub fn start_signature_out_f(lx_p0: crate::lower::Lx, qk_p1: crate::prelude::Text, sc_p2: crate::check::types::Scheme) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<crate::lower::model::OutTy>, crate::lower::model::OutTy)>> {
    ::std::rc::Rc::new(SignatureOut { lx_p0, qk_p1, sc_p2 })
}

/// ```prism
/// FnGenerics: unbounded fn Lx, Text, Scheme -> [((Text, [Text]))]
/// ```
pub fn fn_generics_f(lx_p0: &crate::lower::Lx, qk_p1: &crate::prelude::Text, sc_p2: &crate::check::types::Scheme) -> crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>)> {
    let (pts_p4, ret_p5) = signature_out_f(lx_p0, qk_p1, sc_p2);
    let used_p3 = crate::prelude::fold(&crate::prelude::push(&pts_p4, &ret_p5), &crate::prelude::Array::new(), &(|acc_p6: &crate::prelude::Array<crate::prelude::Text>, t_p7: &crate::lower::model::OutTy| crate::check::types::union_texts_f(acc_p6, &ty_params_in_f(t_p7))));
    crate::prelude::filter(&scheme_generics_f(lx_p0, sc_p2), &(|(g_p8, _): &(crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>)| crate::check::types::has_text_f(&used_p3, g_p8)))
}

/// The step machine of `FnGenerics`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FnGenerics: unbounded fn Lx, Text, Scheme -> [((Text, [Text]))]
/// ```
pub struct FnGenerics {
    pub lx_p0: crate::lower::Lx,
    pub qk_p1: crate::prelude::Text,
    pub sc_p2: crate::check::types::Scheme,
}

impl ::prism_rtl::Job<crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>)>> for FnGenerics {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>)>> {
        let lx_p0 = &self.lx_p0;
        let qk_p1 = &self.qk_p1;
        let sc_p2 = &self.sc_p2;
        let lx_p0x = lx_p0.clone();
        let qk_p1x = qk_p1.clone();
        let sc_p2x = sc_p2.clone();
        crate::prelude::call_then(start_signature_out_f(lx_p0x.clone(), qk_p1x.clone(), sc_p2x.clone()), move |signature_out_f_7988: (crate::prelude::Array<crate::lower::model::OutTy>, crate::lower::model::OutTy)| {
            let (pts_p4, ret_p5) = signature_out_f_7988;
            let used_p3 = crate::prelude::fold(&crate::prelude::push(&pts_p4, &ret_p5), &crate::prelude::Array::new(), &(|acc_p6: &crate::prelude::Array<crate::prelude::Text>, t_p7: &crate::lower::model::OutTy| crate::check::types::union_texts_f(acc_p6, &ty_params_in_f(t_p7))));
            ::prism_rtl::Turn::Finished(crate::prelude::filter(&scheme_generics_f(&lx_p0x, &sc_p2x), &(|(g_p8, _): &(crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>)| crate::check::types::has_text_f(&used_p3, g_p8))))
        })
    }
}

/// `Start FnGenerics, x`: what the function value is when passed to `@Run`.
pub fn start_fn_generics_f(lx_p0: crate::lower::Lx, qk_p1: crate::prelude::Text, sc_p2: crate::check::types::Scheme) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>)>>> {
    ::std::rc::Rc::new(FnGenerics { lx_p0, qk_p1, sc_p2 })
}

/// ```prism
/// FnDefOf: unbounded fn Lx, Text, [FnClause], Scheme -> FnDef
/// ```
pub fn fn_def_of_f(lx_p0: &crate::lower::Lx, qk_p1: &crate::prelude::Text, clauses_p2: &crate::prelude::Array<crate::syntax::decls::FnClause>, sc_p3: &crate::check::types::Scheme) -> crate::lower::model::FnDef {
    fn_def_in_f(lx_p0, qk_p1, qk_p1, clauses_p2, sc_p3)
}

/// The step machine of `FnDefOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FnDefOf: unbounded fn Lx, Text, [FnClause], Scheme -> FnDef
/// ```
pub struct FnDefOf {
    pub lx_p0: crate::lower::Lx,
    pub qk_p1: crate::prelude::Text,
    pub clauses_p2: crate::prelude::Array<crate::syntax::decls::FnClause>,
    pub sc_p3: crate::check::types::Scheme,
}

impl ::prism_rtl::Job<crate::lower::model::FnDef> for FnDefOf {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::lower::model::FnDef> {
        let lx_p0 = &self.lx_p0;
        let qk_p1 = &self.qk_p1;
        let clauses_p2 = &self.clauses_p2;
        let sc_p3 = &self.sc_p3;
        ::prism_rtl::Turn::More(::std::rc::Rc::new(FnDefIn { lx_p0: lx_p0.clone(), definition_p1: qk_p1.clone(), qk_p2: qk_p1.clone(), clauses_p3: clauses_p2.clone(), sc_p4: sc_p3.clone() }))
    }
}

/// `Start FnDefOf, x`: what the function value is when passed to `@Run`.
pub fn start_fn_def_of_f(lx_p0: crate::lower::Lx, qk_p1: crate::prelude::Text, clauses_p2: crate::prelude::Array<crate::syntax::decls::FnClause>, sc_p3: crate::check::types::Scheme) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::FnDef>> {
    ::std::rc::Rc::new(FnDefOf { lx_p0, qk_p1, clauses_p2, sc_p3 })
}

/// ```prism
/// FnDefIn: unbounded fn Lx, Text, Text, [FnClause], Scheme -> FnDef
/// ```
pub fn fn_def_in_f(lx_p0: &crate::lower::Lx, definition_p1: &crate::prelude::Text, qk_p2: &crate::prelude::Text, clauses_p3: &crate::prelude::Array<crate::syntax::decls::FnClause>, sc_p4: &crate::check::types::Scheme) -> crate::lower::model::FnDef {
    let (ptys_pb, res_pc) = signature_tys_f(sc_p4);
    let whole_p5 = crate::lower::expr::is_whole_fn_f(lx_p0, qk_p2);
    let lxb_p6 = {
        let mut this: crate::lower::Lx = lx_p0.clone();
        this.whole_p = whole_p5;
        this.no_cx_p = true;
        this.in_definition_p = definition_p1.clone();
        this
    };
    let (pts_pd, ret_pe) = signature_out_f(lx_p0, qk_p2, sc_p4);
    let names_p7 = param_names_f(lx_p0, clauses_p3, &pts_pd);
    let body_p8 = clauses_body_f(&lxb_p6, &crate::lower::types::empty_env_p(), clauses_p3, &names_p7, &ptys_pb, &(::std::rc::Rc::new(|(a0, a1, a2): (crate::lower::Lx, crate::lower::types::Env, crate::syntax::decls::FnBody)| crate::prelude::entered(start_fn_body_value_f(a0, a1, a2))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::Lx, crate::lower::types::Env, crate::syntax::decls::FnBody)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>>>), &crate::prelude::Text::lit("c"), &ret_pe);
    let params_p9 = crate::prelude::each(&crate::check::errors::range0_f(&crate::prelude::len(&pts_pd)), &(|i_pf: &crate::prelude::Nat| (crate::prelude::or(&crate::prelude::index(&crate::prelude::each(&names_p7, &(|(n_pg, _): &(crate::prelude::Text, bool)| n_pg.clone())), i_pf), &crate::prelude::Text::lit("arg")), crate::lower::model::OutTy::OutRef(::std::rc::Rc::new(crate::prelude::or(&crate::prelude::index(&pts_pd, i_pf), &crate::lower::model::OutTy::OutUnit))))));
    let generics_pa = fn_generics_f(lx_p0, qk_p2, sc_p4);
    crate::lower::model::FnDef { name_p: crate::prelude::or(&crate::prelude::get(&lx_p0.rs_names_p, qk_p2), &crate::lower::snake_f(&crate::check::types::bare_name_f(qk_p2))), generics_p: generics_pa.clone(), params_p: params_p9.clone(), ret_p: ret_pe.clone(), body_p: body_p8.clone(), doc_p: signature_text_f(lx_p0, qk_p2), public_p: true }
}

/// The step machine of `FnDefIn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FnDefIn: unbounded fn Lx, Text, Text, [FnClause], Scheme -> FnDef
/// ```
pub struct FnDefIn {
    pub lx_p0: crate::lower::Lx,
    pub definition_p1: crate::prelude::Text,
    pub qk_p2: crate::prelude::Text,
    pub clauses_p3: crate::prelude::Array<crate::syntax::decls::FnClause>,
    pub sc_p4: crate::check::types::Scheme,
}

impl ::prism_rtl::Job<crate::lower::model::FnDef> for FnDefIn {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::lower::model::FnDef> {
        let lx_p0 = &self.lx_p0;
        let definition_p1 = &self.definition_p1;
        let qk_p2 = &self.qk_p2;
        let clauses_p3 = &self.clauses_p3;
        let sc_p4 = &self.sc_p4;
        let (ptys_pb, res_pc) = signature_tys_f(sc_p4);
        let whole_p5 = crate::lower::expr::is_whole_fn_f(lx_p0, qk_p2);
        let lxb_p6 = {
            let mut this: crate::lower::Lx = lx_p0.clone();
            this.whole_p = whole_p5;
            this.no_cx_p = true;
            this.in_definition_p = definition_p1.clone();
            this
        };
        let clauses_p3x = clauses_p3.clone();
        let lx_p0x = lx_p0.clone();
        let qk_p2x = qk_p2.clone();
        let sc_p4x = sc_p4.clone();
        crate::prelude::call_then(start_signature_out_f(lx_p0x.clone(), qk_p2x.clone(), sc_p4x.clone()), move |signature_out_f_9301: (crate::prelude::Array<crate::lower::model::OutTy>, crate::lower::model::OutTy)| {
            let (pts_pd, ret_pe) = signature_out_f_9301;
            crate::prelude::call_then(start_param_names_f(lx_p0x.clone(), clauses_p3x.clone(), pts_pd.clone()), move |param_names_f_9341: crate::prelude::Array<(crate::prelude::Text, bool)>| {
                let names_p7 = param_names_f_9341;
                crate::prelude::call_then(start_clauses_body_f(lxb_p6.clone(), crate::lower::types::empty_env_p(), clauses_p3x.clone(), names_p7.clone(), ptys_pb.clone(), ::std::rc::Rc::new(|(a0, a1, a2): (crate::lower::Lx, crate::lower::types::Env, crate::syntax::decls::FnBody)| crate::prelude::entered(start_fn_body_value_f(a0, a1, a2))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::Lx, crate::lower::types::Env, crate::syntax::decls::FnBody)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>>>, crate::prelude::Text::lit("c"), ret_pe.clone()), move |clauses_body_f_9384: crate::lower::model::Ex| {
                    let body_p8 = clauses_body_f_9384;
                    let params_p9 = crate::prelude::each(&crate::check::errors::range0_f(&crate::prelude::len(&pts_pd)), &(|i_pf: &crate::prelude::Nat| (crate::prelude::or(&crate::prelude::index(&crate::prelude::each(&names_p7, &(|(n_pg, _): &(crate::prelude::Text, bool)| n_pg.clone())), i_pf), &crate::prelude::Text::lit("arg")), crate::lower::model::OutTy::OutRef(::std::rc::Rc::new(crate::prelude::or(&crate::prelude::index(&pts_pd, i_pf), &crate::lower::model::OutTy::OutUnit))))));
                    crate::prelude::call_then(start_fn_generics_f(lx_p0x.clone(), qk_p2x.clone(), sc_p4x.clone()), move |fn_generics_f_9604: crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>)>| {
                        let generics_pa = fn_generics_f_9604;
                        ::prism_rtl::Turn::Finished(crate::lower::model::FnDef { name_p: crate::prelude::or(&crate::prelude::get(&lx_p0x.rs_names_p, &qk_p2x), &crate::lower::snake_f(&crate::check::types::bare_name_f(&qk_p2x))), generics_p: generics_pa.clone(), params_p: params_p9.clone(), ret_p: ret_pe.clone(), body_p: body_p8.clone(), doc_p: signature_text_f(&lx_p0x, &qk_p2x), public_p: true })
                    })
                })
            })
        })
    }
}

/// `Start FnDefIn, x`: what the function value is when passed to `@Run`.
pub fn start_fn_def_in_f(lx_p0: crate::lower::Lx, definition_p1: crate::prelude::Text, qk_p2: crate::prelude::Text, clauses_p3: crate::prelude::Array<crate::syntax::decls::FnClause>, sc_p4: crate::check::types::Scheme) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::FnDef>> {
    ::std::rc::Rc::new(FnDefIn { lx_p0, definition_p1, qk_p2, clauses_p3, sc_p4 })
}

/// ```prism
/// TyParamsIn: fn OutTy -> [Text]
/// ```
pub fn ty_params_in_f(t_p0: &crate::lower::model::OutTy) -> crate::prelude::Array<crate::prelude::Text> {
    match t_p0 {
        crate::lower::model::OutTy::OutGen(n_p1) => crate::prelude::Array::from(vec![n_p1.clone()]),
        crate::lower::model::OutTy::OutNamed(_, ts_p2) => crate::prelude::fold(ts_p2, &crate::prelude::Array::new(), &(|acc_p3: &crate::prelude::Array<crate::prelude::Text>, x_p4: &crate::lower::model::OutTy| crate::check::types::union_texts_f(acc_p3, &ty_params_in_f(x_p4)))),
        crate::lower::model::OutTy::OutTuple(ts_p5) => crate::prelude::fold(ts_p5, &crate::prelude::Array::new(), &(|acc_p6: &crate::prelude::Array<crate::prelude::Text>, x_p7: &crate::lower::model::OutTy| crate::check::types::union_texts_f(acc_p6, &ty_params_in_f(x_p7)))),
        crate::lower::model::OutTy::OutFn(ts_p8, r_p9) => crate::prelude::fold(ts_p8, &ty_params_in_f(&**r_p9), &(|acc_pa: &crate::prelude::Array<crate::prelude::Text>, x_pb: &crate::lower::model::OutTy| crate::check::types::union_texts_f(acc_pa, &ty_params_in_f(x_pb)))),
        crate::lower::model::OutTy::OutJobFn(a_pc, r_pd) => crate::check::types::union_texts_f(&ty_params_in_f(&**a_pc), &ty_params_in_f(&**r_pd)),
        crate::lower::model::OutTy::OutMap(k_pe, v_pf) => crate::check::types::union_texts_f(&ty_params_in_f(&**k_pe), &ty_params_in_f(&**v_pf)),
        crate::lower::model::OutTy::OutOpt(x_pg) => ty_params_in_f(&**x_pg),
        crate::lower::model::OutTy::OutRes(x_ph) => ty_params_in_f(&**x_ph),
        crate::lower::model::OutTy::OutArray(x_pi) => ty_params_in_f(&**x_pi),
        crate::lower::model::OutTy::OutJob(x_pj) => ty_params_in_f(&**x_pj),
        crate::lower::model::OutTy::OutEvent(x_pk) => ty_params_in_f(&**x_pk),
        crate::lower::model::OutTy::OutDyn(x_pl) => ty_params_in_f(&**x_pl),
        crate::lower::model::OutTy::OutRc(x_pm) => ty_params_in_f(&**x_pm),
        crate::lower::model::OutTy::OutRef(x_pn) => ty_params_in_f(&**x_pn),
        crate::lower::model::OutTy::OutRefMut(x_po) => ty_params_in_f(&**x_po),
        crate::lower::model::OutTy::OutHold(x_pp) => ty_params_in_f(&**x_pp),
        crate::lower::model::OutTy::OutCell(x_pq) => ty_params_in_f(&**x_pq),
        crate::lower::model::OutTy::OutLive(x_pr) => ty_params_in_f(&**x_pr),
        _ => crate::prelude::Array::new(),
    }
}

/// ```prism
/// SignatureText: fn Lx, Text -> Text
/// ```
pub fn signature_text_f(lx_p0: &crate::lower::Lx, qk_p1: &crate::prelude::Text) -> crate::prelude::Text {
    match crate::prelude::get(&lx_p0.g_p.vals_p, qk_p1) {
        ::std::option::Option::Some(v_p2) => match crate::prelude::index(&lx_p0.g_p.srcs_p, &v_p2.file_p) {
            ::std::option::Option::Some(src_p3) => crate::syntax::lexer::chars::trim_f(&crate::check::errors::span_text_f(&src_p3, &v_p2.span_p)),
            ::std::option::Option::None => crate::check::types::bare_name_f(qk_p1),
        },
        ::std::option::Option::None => crate::check::types::bare_name_f(qk_p1),
    }
}

/// ```prism
/// DefinitionText: fn Lx, Text -> Text
/// ```
pub fn definition_text_f(lx_p0: &crate::lower::Lx, qk_p1: &crate::prelude::Text) -> crate::prelude::Text {
    let spans_p2 = crate::prelude::fold(&lx_p0.g_p.defs_p, &crate::prelude::Array::new(), &(|acc_p4: &crate::prelude::Array<(crate::prelude::Nat, crate::syntax::Range)>, d_p5: &crate::check::env::Def| if &d_p5.qk_p == qk_p1 {
        crate::prelude::push(acc_p4, &(d_p5.file_p.clone(), d_p5.span_p.clone()))
    } else {
        acc_p4.clone()
    }));
    let sig_p3 = match crate::prelude::get(&lx_p0.g_p.vals_p, qk_p1) {
        ::std::option::Option::Some(v_p6) => if &v_p6.span_p.start_p < &crate::prelude::or(&crate::prelude::index(&crate::prelude::each(&spans_p2, &(|(_, r_p7): &(crate::prelude::Nat, crate::syntax::Range)| r_p7.start_p.clone())), &crate::prelude::Nat::from(0u32)), &crate::prelude::Nat::from(0u32)) {
            crate::prelude::Array::from(vec![(v_p6.file_p.clone(), v_p6.span_p.clone())])
        } else {
            crate::prelude::Array::new()
        },
        ::std::option::Option::None => crate::prelude::Array::new(),
    };
    crate::syntax::lexer::chars::join_f(&crate::prelude::each(&crate::prelude::append(&sig_p3, &spans_p2), &(|(f_p8, r_p9): &(crate::prelude::Nat, crate::syntax::Range)| src_text_f(lx_p0, f_p8, r_p9))), &crate::prelude::Text::lit("\n"))
}

/// ```prism
/// SrcText: fn Lx, Nat, Range -> Text
/// ```
pub fn src_text_f(lx_p0: &crate::lower::Lx, f_p1: &crate::prelude::Nat, r_p2: &crate::syntax::Range) -> crate::prelude::Text {
    match crate::prelude::index(&lx_p0.g_p.srcs_p, f_p1) {
        ::std::option::Option::Some(src_p3) => drop_trailing_comments_f(&crate::check::errors::span_text_f(&src_p3, r_p2)),
        ::std::option::Option::None => crate::prelude::Text::lit(""),
    }
}

/// ```prism
/// DropTrailingComments: fn Text -> Text
/// ```
pub fn drop_trailing_comments_f(t_p0: &crate::prelude::Text) -> crate::prelude::Text {
    let lines_p1 = crate::prelude::split_on(t_p0, &crate::prelude::Text::lit("\n"));
    let keep_p2 = crate::prelude::fold(&crate::check::errors::range0_f(&crate::prelude::len(&lines_p1)), &crate::prelude::Nat::from(0u32), &(|k_p3: &crate::prelude::Nat, i_p4: &crate::prelude::Nat| if is_code_line_f(&crate::prelude::or(&crate::prelude::index(&lines_p1, i_p4), &crate::prelude::Text::lit(""))) {
        i_p4 + &crate::prelude::Nat::from(1u32)
    } else {
        k_p3.clone()
    }));
    crate::syntax::lexer::chars::trim_end_f(&crate::syntax::lexer::chars::join_f(&crate::prelude::take(&lines_p1, &keep_p2), &crate::prelude::Text::lit("\n")))
}

/// ```prism
/// IsCodeLine: fn Text -> Bool
/// ```
pub fn is_code_line_f(l_p0: &crate::prelude::Text) -> bool {
    let s_p1 = crate::syntax::lexer::chars::trim_f(l_p0);
    (&s_p1 != &crate::prelude::Text::lit("")) && !crate::syntax::lexer::chars::has_prefix_f(&s_p1, &crate::prelude::Text::lit("#"))
}

/// ```prism
/// LetGetter: unbounded fn Lx, Text, LetDecl -> FnDef
/// ```
pub fn let_getter_f(lx_p0: &crate::lower::Lx, qk_p1: &crate::prelude::Text, l_p2: &crate::syntax::decls::LetDecl) -> crate::lower::model::FnDef {
    let lxg_p3 = generalized_lx_f(lx_p0, qk_p1);
    let t_p4 = crate::lower::types::out_ty_of_f(&lxg_p3, &crate::lower::types::peel_f(&crate::lower::type_at_f(&lxg_p3, &l_p2.value_p.span_p)));
    let v_p5 = crate::lower::expr::value_of_f(&lxg_p3, &crate::lower::types::empty_env_p(), &l_p2.value_p);
    crate::lower::model::FnDef { name_p: crate::prelude::or(&crate::prelude::get(&lx_p0.rs_names_p, qk_p1), &crate::lower::snake_f(&crate::check::types::bare_name_f(qk_p1))), generics_p: let_generics_f(lx_p0, qk_p1), params_p: crate::prelude::Array::new(), ret_p: t_p4.clone(), body_p: crate::lower::types::own_f(&v_p5), doc_p: crate::prelude::Text::from(format!("let {}", &crate::check::types::bare_name_f(qk_p1))), public_p: true }
}

/// The step machine of `LetGetter`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LetGetter: unbounded fn Lx, Text, LetDecl -> FnDef
/// ```
pub struct LetGetter {
    pub lx_p0: crate::lower::Lx,
    pub qk_p1: crate::prelude::Text,
    pub l_p2: crate::syntax::decls::LetDecl,
}

impl ::prism_rtl::Job<crate::lower::model::FnDef> for LetGetter {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::lower::model::FnDef> {
        let lx_p0 = &self.lx_p0;
        let qk_p1 = &self.qk_p1;
        let l_p2 = &self.l_p2;
        let lxg_p3 = generalized_lx_f(lx_p0, qk_p1);
        let l_p2x = l_p2.clone();
        let lx_p0x = lx_p0.clone();
        let qk_p1x = qk_p1.clone();
        crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lxg_p3.clone(), crate::lower::types::peel_f(&crate::lower::type_at_f(&lxg_p3, &l_p2x.value_p.span_p))), move |out_ty_of_f_12543: crate::lower::model::OutTy| {
            let t_p4 = out_ty_of_f_12543;
            crate::prelude::call_then(crate::lower::expr::start_value_of_f(lxg_p3.clone(), crate::lower::types::empty_env_p(), l_p2x.value_p.clone()), move |value_of_f_12602: crate::lower::types::Vl| {
                let v_p5 = value_of_f_12602;
                crate::prelude::call_then(start_let_generics_f(lx_p0x.clone(), qk_p1x.clone()), move |let_generics_f_12702: crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>)>| ::prism_rtl::Turn::Finished(crate::lower::model::FnDef { name_p: crate::prelude::or(&crate::prelude::get(&lx_p0x.rs_names_p, &qk_p1x), &crate::lower::snake_f(&crate::check::types::bare_name_f(&qk_p1x))), generics_p: let_generics_f_12702, params_p: crate::prelude::Array::new(), ret_p: t_p4.clone(), body_p: crate::lower::types::own_f(&v_p5), doc_p: crate::prelude::Text::from(format!("let {}", &crate::check::types::bare_name_f(&qk_p1x))), public_p: true }))
            })
        })
    }
}

/// `Start LetGetter, x`: what the function value is when passed to `@Run`.
pub fn start_let_getter_f(lx_p0: crate::lower::Lx, qk_p1: crate::prelude::Text, l_p2: crate::syntax::decls::LetDecl) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::FnDef>> {
    ::std::rc::Rc::new(LetGetter { lx_p0, qk_p1, l_p2 })
}

/// ```prism
/// GeneralizedParameters: fn Lx, Text -> [((Text, Text))]
/// ```
pub fn generalized_parameters_f(lx_p0: &crate::lower::Lx, qk_p1: &crate::prelude::Text) -> crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text)> {
    match crate::prelude::get(&lx_p0.g_p.vals_p, qk_p1) {
        ::std::option::Option::Some(v_p2) => if v_p2.has_sig_p {
            crate::prelude::Array::new()
        } else {
            crate::prelude::each(&v_p2.scheme_p.qs_p, &(|q_p3: &crate::prelude::Text| (q_p3.clone(), crate::prelude::Text::from(format!("generalized{}", &crate::prelude::or(&crate::syntax::lexer::chars::after_prefix_o(q_p3, &crate::prelude::Text::lit("\'")), q_p3))))))
        },
        ::std::option::Option::None => crate::prelude::Array::new(),
    }
}

/// ```prism
/// GeneralizedLx: fn Lx, Text -> Lx
/// ```
pub fn generalized_lx_f(lx_p0: &crate::lower::Lx, qk_p1: &crate::prelude::Text) -> crate::lower::Lx {
    let mut this: crate::lower::Lx = lx_p0.clone();
    this.subst_p = crate::prelude::fold(&generalized_parameters_f(lx_p0, qk_p1), &this.subst_p, &(|m_p2: &crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>, (q_p3, parameter_p4): &(crate::prelude::Text, crate::prelude::Text)| crate::prelude::insert(m_p2, q_p3, &crate::check::types::Ty::TyRigid(parameter_p4.clone()))));
    this
}

/// ```prism
/// LetGenerics: unbounded fn Lx, Text -> [((Text, [Text]))]
/// ```
pub fn let_generics_f(lx_p0: &crate::lower::Lx, qk_p1: &crate::prelude::Text) -> crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>)> {
    match crate::prelude::get(&lx_p0.g_p.vals_p, qk_p1) {
        ::std::option::Option::Some(v_p2) => {
            let parameters_p3 = generalized_parameters_f(lx_p0, qk_p1);
            let named_f4 = {
                let parameters_p3x = parameters_p3.clone();
                ::std::rc::Rc::new(move |q_p6: &crate::prelude::Text| crate::prelude::fold(&parameters_p3x, q_p6, &(|found_p7: &crate::prelude::Text, (from_p8, to_p9): &(crate::prelude::Text, crate::prelude::Text)| if from_p8 == q_p6 { to_p9.clone() } else { found_p7.clone() }))) as ::std::rc::Rc<dyn ::std::ops::Fn(&crate::prelude::Text) -> crate::prelude::Text>
            };
            let renamed_p5 = {
                let mut this: crate::check::types::Scheme = v_p2.scheme_p.clone();
                this.qs_p = crate::prelude::each(&parameters_p3, &(|(_, to_pa): &(crate::prelude::Text, crate::prelude::Text)| to_pa.clone()));
                this.bounds_p = crate::prelude::each(&this.bounds_p, &(|(q_pb, cls_pc): &(crate::prelude::Text, crate::prelude::Text)| ((&named_f4)(q_pb), cls_pc.clone())));
                this.ty_p = crate::lower::expr::instantiated_f(&this.ty_p, &crate::prelude::each(&parameters_p3, &(|(from_pd, _): &(crate::prelude::Text, crate::prelude::Text)| from_pd.clone())), &crate::prelude::each(&parameters_p3, &(|(_, to_pe): &(crate::prelude::Text, crate::prelude::Text)| crate::check::types::Ty::TyQ(to_pe.clone()))));
                this
            };
            if &crate::prelude::len(&parameters_p3) == &crate::prelude::Nat::from(0u32) {
                crate::prelude::Array::new()
            } else {
                scheme_generics_f(lx_p0, &renamed_p5)
            }
        },
        ::std::option::Option::None => crate::prelude::Array::new(),
    }
}

/// The step machine of `LetGenerics`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LetGenerics: unbounded fn Lx, Text -> [((Text, [Text]))]
/// ```
pub struct LetGenerics {
    pub lx_p0: crate::lower::Lx,
    pub qk_p1: crate::prelude::Text,
}

impl ::prism_rtl::Job<crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>)>> for LetGenerics {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>)>> {
        let lx_p0 = &self.lx_p0;
        let qk_p1 = &self.qk_p1;
        match crate::prelude::get(&lx_p0.g_p.vals_p, qk_p1) {
            ::std::option::Option::Some(v_p2) => {
                let parameters_p3 = generalized_parameters_f(lx_p0, qk_p1);
                let named_f4 = {
                    let parameters_p3x = parameters_p3.clone();
                    ::std::rc::Rc::new(move |q_p6: &crate::prelude::Text| crate::prelude::fold(&parameters_p3x, q_p6, &(|found_p7: &crate::prelude::Text, (from_p8, to_p9): &(crate::prelude::Text, crate::prelude::Text)| if from_p8 == q_p6 { to_p9.clone() } else { found_p7.clone() }))) as ::std::rc::Rc<dyn ::std::ops::Fn(&crate::prelude::Text) -> crate::prelude::Text>
                };
                let renamed_p5 = {
                    let mut this: crate::check::types::Scheme = v_p2.scheme_p.clone();
                    this.qs_p = crate::prelude::each(&parameters_p3, &(|(_, to_pa): &(crate::prelude::Text, crate::prelude::Text)| to_pa.clone()));
                    this.bounds_p = crate::prelude::each(&this.bounds_p, &(|(q_pb, cls_pc): &(crate::prelude::Text, crate::prelude::Text)| ((&named_f4)(q_pb), cls_pc.clone())));
                    this.ty_p = crate::lower::expr::instantiated_f(&this.ty_p, &crate::prelude::each(&parameters_p3, &(|(from_pd, _): &(crate::prelude::Text, crate::prelude::Text)| from_pd.clone())), &crate::prelude::each(&parameters_p3, &(|(_, to_pe): &(crate::prelude::Text, crate::prelude::Text)| crate::check::types::Ty::TyQ(to_pe.clone()))));
                    this
                };
                if &crate::prelude::len(&parameters_p3) == &crate::prelude::Nat::from(0u32) {
                    ::prism_rtl::Turn::Finished(crate::prelude::Array::new())
                } else {
                    ::prism_rtl::Turn::Finished(scheme_generics_f(lx_p0, &renamed_p5))
                }
            },
            ::std::option::Option::None => ::prism_rtl::Turn::Finished(crate::prelude::Array::new()),
        }
    }
}

/// `Start LetGenerics, x`: what the function value is when passed to `@Run`.
pub fn start_let_generics_f(lx_p0: crate::lower::Lx, qk_p1: crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>)>>> {
    ::std::rc::Rc::new(LetGenerics { lx_p0, qk_p1 })
}

/// ```prism
/// HasOwnShow: fn Lx, Text -> Bool
/// ```
pub fn has_own_show_f(lx_p0: &crate::lower::Lx, tn_p1: &crate::prelude::Text) -> bool {
    crate::prelude::fold(&crate::prelude::or(&crate::prelude::get(&lx_p0.g_p.impls_p, &crate::prelude::Text::lit("Prelude.Show")), &crate::prelude::Array::new()), &false, &(|f_p2: &bool, im_p3: &crate::check::env::ImplInfo| *f_p2 || (!im_p3.derived_p && (&head_name_f(&im_p3.head_p) == tn_p1))))
}

/// ```prism
/// HeadName: fn Ty -> Text
/// ```
pub fn head_name_f(ty0: &crate::check::types::Ty) -> crate::prelude::Text {
    match ty0 {
        crate::check::types::Ty::TyCon(n_p0, _) => n_p0.clone(),
        other_p1 => crate::prelude::Text::lit(""),
    }
}

/// ```prism
/// HeadWord: unbounded fn Ty -> Text
/// ```
pub fn head_word_f(t_p0: &crate::check::types::Ty) -> crate::prelude::Text {
    'm15139: {
        if let crate::check::types::Ty::TyCon(m15139_0_0, m15139_0_1) = t_p0 && (m15139_0_0 == &crate::prelude::Text::lit("Prelude.NonEmpty")) && (m15139_0_1.len() == 1) && let ::std::option::Option::Some(c_p1) = crate::prelude::index(m15139_0_1, &crate::prelude::Nat::from(0u32)) {
            break 'm15139 crate::prelude::Text::from(format!("non_empty_{}", &head_word_f(&c_p1)));
        }
        if let crate::check::types::Ty::TyCon(n_p2, _) = t_p0 {
            break 'm15139 crate::lower::snake_f(&crate::check::types::bare_name_f(n_p2));
        }
        if let crate::check::types::Ty::TyArray(x_p3) = t_p0 {
            break 'm15139 crate::prelude::Text::from(format!("array_of_{}", &head_word_f(&**x_p3)));
        }
        if let crate::check::types::Ty::TyMap(k_p4, v_p5) = t_p0 {
            break 'm15139 crate::prelude::Text::from(format!("map_of_{}_to_{}", &head_word_f(&**k_p4), &head_word_f(&**v_p5)));
        }
        if let crate::check::types::Ty::TyTuple(xs_p6) = t_p0 {
            break 'm15139 crate::prelude::Text::from(format!("tuple_of_{}", &crate::syntax::lexer::chars::join_f(&crate::prelude::run_to_end(crate::prelude::each_job(xs_p6.clone(), ::std::rc::Rc::new(move |p0: crate::check::types::Ty| crate::prelude::entered(crate::prelude::once_job(move || {
                let x_p7 = p0;
                ::prism_rtl::Turn::More(::std::rc::Rc::new(HeadWord { t_p0: x_p7.clone() }))
            }))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>)), &crate::prelude::Text::lit("_and_"))));
        }
        if let crate::check::types::Ty::TyQ(q_p8) = t_p0 {
            break 'm15139 crate::lower::snake_f(q_p8);
        }
        if let crate::check::types::Ty::TyRigid(q_p9) = t_p0 {
            break 'm15139 crate::lower::snake_f(q_p9);
        }
        crate::prelude::Text::lit("value")
    }
}

/// The step machine of `HeadWord`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// HeadWord: unbounded fn Ty -> Text
/// ```
pub struct HeadWord {
    pub t_p0: crate::check::types::Ty,
}

impl ::prism_rtl::Job<crate::prelude::Text> for HeadWord {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let t_p0 = &self.t_p0;
        'm15139: {
            if let crate::check::types::Ty::TyCon(m15139_0_0, m15139_0_1) = t_p0 && (m15139_0_0 == &crate::prelude::Text::lit("Prelude.NonEmpty")) && (m15139_0_1.len() == 1) && let ::std::option::Option::Some(c_p1) = crate::prelude::index(m15139_0_1, &crate::prelude::Nat::from(0u32)) {
                break 'm15139 crate::prelude::call_then(start_head_word_f(c_p1.clone()), move |head_word_f_15197: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("non_empty_{}", &head_word_f_15197))));
            }
            if let crate::check::types::Ty::TyCon(n_p2, _) = t_p0 {
                break 'm15139 ::prism_rtl::Turn::Finished(crate::lower::snake_f(&crate::check::types::bare_name_f(n_p2)));
            }
            if let crate::check::types::Ty::TyArray(x_p3) = t_p0 {
                break 'm15139 {
                    let x_p3x = (**x_p3).clone();
                    crate::prelude::call_then(start_head_word_f(x_p3x.clone()), move |head_word_f_15276: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("array_of_{}", &head_word_f_15276))))
                };
            }
            if let crate::check::types::Ty::TyMap(k_p4, v_p5) = t_p0 {
                break 'm15139 {
                    let k_p4x = (**k_p4).clone();
                    let v_p5x = (**v_p5).clone();
                    crate::prelude::call_then(start_head_word_f(k_p4x.clone()), move |head_word_f_15314: crate::prelude::Text| crate::prelude::call_then(start_head_word_f(v_p5x.clone()), move |head_word_f_15330: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("map_of_{}_to_{}", &head_word_f_15314, &head_word_f_15330)))))
                };
            }
            if let crate::check::types::Ty::TyTuple(xs_p6) = t_p0 {
                break 'm15139 {
                    let xs_p6x = xs_p6.clone();
                    crate::prelude::call_value(crate::prelude::each_job(xs_p6x.clone(), ::std::rc::Rc::new(move |p0: crate::check::types::Ty| crate::prelude::entered(crate::prelude::once_job(move || {
                        let x_p7 = p0;
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(HeadWord { t_p0: x_p7.clone() }))
                    }))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>), move |each_15376: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("tuple_of_{}", &crate::syntax::lexer::chars::join_f(&each_15376, &crate::prelude::Text::lit("_and_"))))))
                };
            }
            if let crate::check::types::Ty::TyQ(q_p8) = t_p0 {
                break 'm15139 ::prism_rtl::Turn::Finished(crate::lower::snake_f(q_p8));
            }
            if let crate::check::types::Ty::TyRigid(q_p9) = t_p0 {
                break 'm15139 ::prism_rtl::Turn::Finished(crate::lower::snake_f(q_p9));
            }
            ::prism_rtl::Turn::Finished(crate::prelude::Text::lit("value"))
        }
    }
}

/// `Start HeadWord, x`: what the function value is when passed to `@Run`.
pub fn start_head_word_f(t_p0: crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(HeadWord { t_p0 })
}

/// ```prism
/// SelfIn: unbounded fn Ty, Text -> Ty
/// ```
pub fn self_in_f(t_p0: &crate::check::types::Ty, param_p1: &crate::prelude::Text) -> crate::check::types::Ty {
    crate::lower::expr::instantiated_f(t_p0, &crate::prelude::Array::from(vec![param_p1.clone()]), &crate::prelude::Array::from(vec![crate::check::types::Ty::TyCon(crate::prelude::Text::lit("\0Self"), crate::prelude::Array::new())]))
}

/// The step machine of `SelfIn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SelfIn: unbounded fn Ty, Text -> Ty
/// ```
pub struct SelfIn {
    pub t_p0: crate::check::types::Ty,
    pub param_p1: crate::prelude::Text,
}

impl ::prism_rtl::Job<crate::check::types::Ty> for SelfIn {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::types::Ty> {
        let t_p0 = &self.t_p0;
        let param_p1 = &self.param_p1;
        ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::lower::expr::Instantiated { t_p0: t_p0.clone(), params_p1: crate::prelude::Array::from(vec![param_p1.clone()]), args_p2: crate::prelude::Array::from(vec![crate::check::types::Ty::TyCon(crate::prelude::Text::lit("\0Self"), crate::prelude::Array::new())]) }))
    }
}

/// `Start SelfIn, x`: what the function value is when passed to `@Run`.
pub fn start_self_in_f(t_p0: crate::check::types::Ty, param_p1: crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::Ty>> {
    ::std::rc::Rc::new(SelfIn { t_p0, param_p1 })
}

/// ```prism
/// IsResultOnly: fn Lx, Text, Text -> Bool
/// ```
pub fn is_result_only_f(lx_p0: &crate::lower::Lx, mq_p1: &crate::prelude::Text, param_p2: &crate::prelude::Text) -> bool {
    match crate::prelude::get(&lx_p0.g_p.vals_p, mq_p1) {
        ::std::option::Option::Some(v_p3) => match &v_p3.scheme_p.ty_p {
            crate::check::types::Ty::TyFn(_, ps_p4, _) => !crate::prelude::fold(ps_p4, &false, &(|f_p5: &bool, p_p6: &crate::check::types::Ty| *f_p5 || crate::check::types::has_text_f(&deducible_qs_f(p_p6), param_p2))),
            _ => true,
        },
        ::std::option::Option::None => false,
    }
}

/// ```prism
/// DeducibleQs: fn Ty -> [Text]
/// ```
pub fn deducible_qs_f(t_p0: &crate::check::types::Ty) -> crate::prelude::Array<crate::prelude::Text> {
    match t_p0 {
        crate::check::types::Ty::TyQ(q_p1) => crate::prelude::Array::from(vec![q_p1.clone()]),
        crate::check::types::Ty::TyRigid(q_p2) => crate::prelude::Array::from(vec![q_p2.clone()]),
        crate::check::types::Ty::TyCon(_, xs_p3) => crate::prelude::fold(xs_p3, &crate::prelude::Array::new(), &(|acc_p4: &crate::prelude::Array<crate::prelude::Text>, x_p5: &crate::check::types::Ty| crate::check::types::union_texts_f(acc_p4, &deducible_qs_f(x_p5)))),
        crate::check::types::Ty::TyFn(_, ps_p6, r_p7) => crate::prelude::fold(ps_p6, &deducible_qs_f(&**r_p7), &(|acc_p8: &crate::prelude::Array<crate::prelude::Text>, x_p9: &crate::check::types::Ty| crate::check::types::union_texts_f(acc_p8, &deducible_qs_f(x_p9)))),
        crate::check::types::Ty::TyTuple(xs_pa) => crate::prelude::fold(xs_pa, &crate::prelude::Array::new(), &(|acc_pb: &crate::prelude::Array<crate::prelude::Text>, x_pc: &crate::check::types::Ty| crate::check::types::union_texts_f(acc_pb, &deducible_qs_f(x_pc)))),
        crate::check::types::Ty::TyArray(x_pd) => deducible_qs_f(&**x_pd),
        crate::check::types::Ty::TyMap(k_pe, v_pf) => crate::check::types::union_texts_f(&deducible_qs_f(&**k_pe), &deducible_qs_f(&**v_pf)),
        crate::check::types::Ty::TySig(_, x_pg) => deducible_qs_f(&**x_pg),
        crate::check::types::Ty::TyAt(x_ph, _) => deducible_qs_f(&**x_ph),
        crate::check::types::Ty::TyElem(_, x_pi) => deducible_qs_f(&**x_pi),
        crate::check::types::Ty::TyAssoc(_, _, _) => crate::prelude::Array::new(),
        _ => crate::prelude::Array::new(),
    }
}

/// ```prism
/// ResultOnlyNames: fn Lx, TraitInfo -> [Text]
/// ```
pub fn result_only_names_f(lx_p0: &crate::lower::Lx, tr_p1: &crate::check::env::TraitInfo) -> crate::prelude::Array<crate::prelude::Text> {
    crate::prelude::each(&crate::prelude::filter(&tr_p1.methods_p, &(|mq_p2: &crate::prelude::Text| is_result_only_f(lx_p0, mq_p2, &tr_p1.param_p))), &(|mq_p3: &crate::prelude::Text| crate::prelude::or(&crate::prelude::get(&lx_p0.rs_names_p, mq_p3), &crate::lower::snake_f(&crate::check::types::bare_name_f(mq_p3)))))
}

/// ```prism
/// TraitDefOf: unbounded fn Lx, TraitInfo -> TraitDef
/// ```
pub fn trait_def_of_f(lx0_p0: &crate::lower::Lx, tr_p1: &crate::check::env::TraitInfo) -> crate::lower::model::TraitDef {
    let lx_p2 = {
        let mut this: crate::lower::Lx = crate::lower::program::in_module_f(lx0_p0, &tr_p1.file_p, &tr_p1.home_p);
        this.subst_p = crate::prelude::insert(&this.subst_p, &tr_p1.param_p, &crate::check::types::Ty::TyCon(crate::prelude::Text::lit("\0Self"), crate::prelude::Array::new()));
        this
    };
    let methods_p3 = crate::prelude::run_to_end(crate::prelude::each_job(tr_p1.methods_p.clone(), {
        let lx_p2x = lx_p2.clone();
        let tr_p1x = tr_p1.clone();
        ::std::rc::Rc::new(move |p0: crate::prelude::Text| {
            let lx_p2xy = lx_p2x.clone();
            let tr_p1xy = tr_p1x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let mq_p4 = p0;
                {
                    let v_p5 = crate::prelude::or(&crate::prelude::get(&lx_p2xy.g_p.vals_p, &mq_p4), &crate::check::env::builtin_f(&mq_p4, &crate::check::types::schemes::mono_f(&crate::check::types::Ty::TyErr)));
                    let sc_p6 = {
                        let mut this: crate::check::types::Scheme = v_p5.scheme_p.clone();
                        this.ty_p = self_in_f(&this.ty_p, &tr_p1xy.param_p);
                        this.qs_p = crate::prelude::filter(&this.qs_p, &(|q_pa: &crate::prelude::Text| q_pa != &tr_p1xy.param_p));
                        this.bounds_p = crate::prelude::filter(&this.bounds_p, &(|(q_pb, _): &(crate::prelude::Text, crate::prelude::Text)| q_pb != &tr_p1xy.param_p));
                        this
                    };
                    let default_qk_p7 = crate::prelude::fold(&tr_p1xy.defaults_p, &crate::prelude::Text::lit(""), &(|f_pc: &crate::prelude::Text, dq_pd: &crate::prelude::Text| if &crate::check::types::bare_name_f(dq_pd) == &crate::check::types::bare_name_f(&mq_p4) {
                        dq_pd.clone()
                    } else {
                        f_pc.clone()
                    }));
                    let clauses_p8 = if &default_qk_p7 == &crate::prelude::Text::lit("") {
                        crate::prelude::Array::new()
                    } else {
                        default_clauses_f(&lx_p2xy.g_p, &default_qk_p7)
                    };
                    crate::prelude::call_then(start_fn_def_in_f(lx_p2xy.clone(), if &default_qk_p7 == &crate::prelude::Text::lit("") {
                        mq_p4.clone()
                    } else {
                        default_qk_p7.clone()
                    }, mq_p4.clone(), if &crate::prelude::len(&clauses_p8) == &crate::prelude::Nat::from(0u32) {
                        crate::prelude::Array::from(vec![dummy_clause_p()])
                    } else {
                        clauses_p8.clone()
                    }, sc_p6.clone()), move |fn_def_in_f_18020: crate::lower::model::FnDef| {
                        let fd_p9 = fn_def_in_f_18020;
                        ::prism_rtl::Turn::Finished({
                            let mut this: crate::lower::model::FnDef = fd_p9.clone();
                            this.public_p = &crate::prelude::len(&clauses_p8) > &crate::prelude::Nat::from(0u32);
                            this
                        })
                    })
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::FnDef>>>
    }));
    crate::lower::model::TraitDef { name_p: crate::lower::trait_name_f(&tr_p1.name_p), result_only_p: result_only_names_f(&lx_p2, tr_p1), assocs_p: crate::prelude::each(&tr_p1.assocs_p, &(|a_pe: &crate::prelude::Text| crate::lower::camel_f(a_pe))), methods_p: methods_p3.clone(), defaults_p: tr_p1.defaults_p.clone(), doc_p: crate::lower::program::type_doc_f(&lx_p2, &crate::check::env::TyInfo { name_p: tr_p1.name_p.clone(), home_p: tr_p1.home_p.clone(), params_p: crate::prelude::Array::new(), body_p: crate::check::env::TyBody::BOpaque, derives_p: crate::prelude::Array::new(), file_p: tr_p1.file_p.clone(), span_p: tr_p1.span_p.clone() }) }
}

/// The step machine of `TraitDefOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TraitDefOf: unbounded fn Lx, TraitInfo -> TraitDef
/// ```
pub struct TraitDefOf {
    pub lx0_p0: crate::lower::Lx,
    pub tr_p1: crate::check::env::TraitInfo,
}

impl ::prism_rtl::Job<crate::lower::model::TraitDef> for TraitDefOf {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::lower::model::TraitDef> {
        let lx0_p0 = &self.lx0_p0;
        let tr_p1 = &self.tr_p1;
        let lx_p2 = {
            let mut this: crate::lower::Lx = crate::lower::program::in_module_f(lx0_p0, &tr_p1.file_p, &tr_p1.home_p);
            this.subst_p = crate::prelude::insert(&this.subst_p, &tr_p1.param_p, &crate::check::types::Ty::TyCon(crate::prelude::Text::lit("\0Self"), crate::prelude::Array::new()));
            this
        };
        let tr_p1x = tr_p1.clone();
        crate::prelude::call_value(crate::prelude::each_job(tr_p1x.methods_p.clone(), {
            let lx_p2x = lx_p2.clone();
            let tr_p1xx = tr_p1x.clone();
            ::std::rc::Rc::new(move |p0: crate::prelude::Text| {
                let lx_p2xy = lx_p2x.clone();
                let tr_p1xxy = tr_p1xx.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let mq_p4 = p0;
                    {
                        let v_p5 = crate::prelude::or(&crate::prelude::get(&lx_p2xy.g_p.vals_p, &mq_p4), &crate::check::env::builtin_f(&mq_p4, &crate::check::types::schemes::mono_f(&crate::check::types::Ty::TyErr)));
                        let sc_p6 = {
                            let mut this: crate::check::types::Scheme = v_p5.scheme_p.clone();
                            this.ty_p = self_in_f(&this.ty_p, &tr_p1xxy.param_p);
                            this.qs_p = crate::prelude::filter(&this.qs_p, &(|q_pa: &crate::prelude::Text| q_pa != &tr_p1xxy.param_p));
                            this.bounds_p = crate::prelude::filter(&this.bounds_p, &(|(q_pb, _): &(crate::prelude::Text, crate::prelude::Text)| q_pb != &tr_p1xxy.param_p));
                            this
                        };
                        let default_qk_p7 = crate::prelude::fold(&tr_p1xxy.defaults_p, &crate::prelude::Text::lit(""), &(|f_pc: &crate::prelude::Text, dq_pd: &crate::prelude::Text| if &crate::check::types::bare_name_f(dq_pd) == &crate::check::types::bare_name_f(&mq_p4) {
                            dq_pd.clone()
                        } else {
                            f_pc.clone()
                        }));
                        let clauses_p8 = if &default_qk_p7 == &crate::prelude::Text::lit("") {
                            crate::prelude::Array::new()
                        } else {
                            default_clauses_f(&lx_p2xy.g_p, &default_qk_p7)
                        };
                        crate::prelude::call_then(start_fn_def_in_f(lx_p2xy.clone(), if &default_qk_p7 == &crate::prelude::Text::lit("") {
                            mq_p4.clone()
                        } else {
                            default_qk_p7.clone()
                        }, mq_p4.clone(), if &crate::prelude::len(&clauses_p8) == &crate::prelude::Nat::from(0u32) {
                            crate::prelude::Array::from(vec![dummy_clause_p()])
                        } else {
                            clauses_p8.clone()
                        }, sc_p6.clone()), move |fn_def_in_f_18020: crate::lower::model::FnDef| {
                            let fd_p9 = fn_def_in_f_18020;
                            ::prism_rtl::Turn::Finished({
                                let mut this: crate::lower::model::FnDef = fd_p9.clone();
                                this.public_p = &crate::prelude::len(&clauses_p8) > &crate::prelude::Nat::from(0u32);
                                this
                            })
                        })
                    }
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::FnDef>>>
        }), move |each_17528: crate::prelude::Array<crate::lower::model::FnDef>| {
            let methods_p3 = each_17528;
            ::prism_rtl::Turn::Finished(crate::lower::model::TraitDef { name_p: crate::lower::trait_name_f(&tr_p1x.name_p), result_only_p: result_only_names_f(&lx_p2, &tr_p1x), assocs_p: crate::prelude::each(&tr_p1x.assocs_p, &(|a_pe: &crate::prelude::Text| crate::lower::camel_f(a_pe))), methods_p: methods_p3.clone(), defaults_p: tr_p1x.defaults_p.clone(), doc_p: crate::lower::program::type_doc_f(&lx_p2, &crate::check::env::TyInfo { name_p: tr_p1x.name_p.clone(), home_p: tr_p1x.home_p.clone(), params_p: crate::prelude::Array::new(), body_p: crate::check::env::TyBody::BOpaque, derives_p: crate::prelude::Array::new(), file_p: tr_p1x.file_p.clone(), span_p: tr_p1x.span_p.clone() }) })
        })
    }
}

/// `Start TraitDefOf, x`: what the function value is when passed to `@Run`.
pub fn start_trait_def_of_f(lx0_p0: crate::lower::Lx, tr_p1: crate::check::env::TraitInfo) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::TraitDef>> {
    ::std::rc::Rc::new(TraitDefOf { lx0_p0, tr_p1 })
}

/// ```prism
/// DefaultClauses: fn G, Text -> [FnClause]
/// ```
pub fn default_clauses_f(g_p0: &crate::check::env::G, qk_p1: &crate::prelude::Text) -> crate::prelude::Array<crate::syntax::decls::FnClause> {
    crate::prelude::fold(&g_p0.defs_p, &crate::prelude::Array::new(), &(|acc_p2: &crate::prelude::Array<crate::syntax::decls::FnClause>, d_p3: &crate::check::env::Def| if &d_p3.qk_p == qk_p1 { default_of_f(d_p3, acc_p2) } else { acc_p2.clone() }))
}

/// ```prism
/// DefaultOf: fn Def, [FnClause] -> [FnClause]
/// ```
pub fn default_of_f(d_p0: &crate::check::env::Def, other_p1: &crate::prelude::Array<crate::syntax::decls::FnClause>) -> crate::prelude::Array<crate::syntax::decls::FnClause> {
    match &d_p0.body_p {
        crate::check::env::DefBody::DbDefault(cs_p2, _) => cs_p2.clone(),
        _ => other_p1.clone(),
    }
}

/// ```prism
/// ?PackedDefOf: unbounded fn Lx, TraitInfo -> ?PackedDef
/// ```
pub fn packed_def_of_o(lx0_p0: &crate::lower::Lx, tr_p1: &crate::check::env::TraitInfo) -> ::std::option::Option<crate::lower::model::PackedDef> {
    let lx_p2 = crate::lower::program::in_module_f(lx0_p0, &tr_p1.file_p, &tr_p1.home_p);
    let hidden_ty_p3 = crate::check::types::Ty::TyCon(crate::prelude::Text::lit("\0Self"), crate::prelude::Array::new());
    let methods_or = crate::prelude::run_to_end(crate::prelude::fold_job(tr_p1.methods_p.clone(), ::std::option::Option::Some(crate::prelude::Array::new()), {
        let lx_p2x = lx_p2.clone();
        let tr_p1x = tr_p1.clone();
        let hidden_ty_p3x = hidden_ty_p3.clone();
        ::std::rc::Rc::new(move |(p0, p1): (::std::option::Option<crate::prelude::Array<crate::lower::model::PackedMethod>>, crate::prelude::Text)| {
            let lx_p2xy = lx_p2x.clone();
            let tr_p1xy = tr_p1x.clone();
            let hidden_ty_p3xy = hidden_ty_p3x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_o4 = p0;
                let mq_p5 = p1;
                match &acc_o4 {
                    ::std::option::Option::None => ::prism_rtl::Turn::Finished(::std::option::Option::None),
                    ::std::option::Option::Some(acc_p6) => {
                        let v_p7 = crate::prelude::or(&crate::prelude::get(&lx_p2xy.g_p.vals_p, &mq_p5), &crate::check::env::builtin_f(&mq_p5, &crate::check::types::schemes::mono_f(&crate::check::types::Ty::TyErr)));
                        let (ps_pg, r_ph) = match &v_p7.scheme_p.ty_p {
                            crate::check::types::Ty::TyFn(_, ps_pd, r_pe) => (ps_pd.clone(), (**r_pe).clone()),
                            other_pf => (crate::prelude::Array::new(), other_pf.clone()),
                        };
                        let acc_p6x = acc_p6.clone();
                        crate::prelude::call_value(crate::prelude::each_job(ps_pg.clone(), {
                            let tr_p1xyx = tr_p1xy.clone();
                            let hidden_ty_p3xyx = hidden_ty_p3xy.clone();
                            ::std::rc::Rc::new(move |p0: crate::check::types::Ty| {
                                let tr_p1xyxy = tr_p1xyx.clone();
                                let hidden_ty_p3xyxy = hidden_ty_p3xyx.clone();
                                crate::prelude::entered(crate::prelude::once_job(move || {
                                    let p_pi = p0;
                                    ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::lower::expr::Instantiated { t_p0: p_pi.clone(), params_p1: crate::prelude::Array::from(vec![tr_p1xyxy.param_p.clone()]), args_p2: crate::prelude::Array::from(vec![hidden_ty_p3xyxy.clone()]) }))
                                }))
                            }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::Ty>>>
                        }), move |each_19689: crate::prelude::Array<crate::check::types::Ty>| {
                            let marked_p8 = each_19689;
                            let hidden_p9 = crate::prelude::each(&marked_p8, &(|m_pj: &crate::check::types::Ty| m_pj == &hidden_ty_p3xy));
                            crate::prelude::call_then(crate::lower::expr::start_instantiated_f(r_ph.clone(), crate::prelude::Array::from(vec![tr_p1xy.param_p.clone()]), crate::prelude::Array::from(vec![hidden_ty_p3xy.clone()])), move |instantiated_f_19834: crate::check::types::Ty| {
                                let marked_result_pa = instantiated_f_19834;
                                let whole_pb = crate::prelude::fold(&crate::check::errors::range0_f(&crate::prelude::len(&ps_pg)), &true, &(|ok_pk: &bool, i_pl: &crate::prelude::Nat| *ok_pk && (crate::prelude::or(&crate::prelude::index(&hidden_p9, i_pl), &false) || (&crate::prelude::or(&crate::prelude::index(&marked_p8, i_pl), &crate::check::types::Ty::TyErr) == &crate::prelude::or(&crate::prelude::index(&ps_pg, i_pl), &crate::check::types::Ty::TyErr)))));
                                let own_qs_pc = crate::prelude::filter(&v_p7.scheme_p.qs_p, &(|q_pm: &crate::prelude::Text| q_pm != &tr_p1xy.param_p));
                                if (((&crate::prelude::len(&own_qs_pc) > &crate::prelude::Nat::from(0u32)) || !whole_pb) || !crate::prelude::fold(&hidden_p9, &false, &(|f_pn: &bool, h_po: &bool| *f_pn || *h_po))) || !((&marked_result_pa == &hidden_ty_p3xy) || (&marked_result_pa == &r_ph)) {
                                    ::prism_rtl::Turn::Finished(::std::option::Option::None)
                                } else {
                                    {
                                        let sc_pp = {
                                            let mut this: crate::check::types::Scheme = v_p7.scheme_p.clone();
                                            this.ty_p = crate::lower::expr::instantiated_f(&this.ty_p, &crate::prelude::Array::from(vec![tr_p1xy.param_p.clone()]), &crate::prelude::Array::from(vec![crate::check::types::Ty::TyAny(crate::prelude::Array::from(vec![tr_p1xy.name_p.clone()]))]));
                                            this.qs_p = own_qs_pc.clone();
                                            this.bounds_p = crate::prelude::filter(&this.bounds_p, &(|(q_pq, _): &(crate::prelude::Text, crate::prelude::Text)| q_pq != &tr_p1xy.param_p));
                                            this
                                        };
                                        ::prism_rtl::Turn::Finished(::std::option::Option::Some(crate::prelude::push(&acc_p6x, &crate::lower::model::PackedMethod { method_p: fn_def_of_f(&lx_p2xy, &mq_p5, &crate::prelude::Array::from(vec![dummy_clause_p()]), &sc_pp), hidden_p: hidden_p9.clone(), hidden_result_p: &marked_result_pa == &hidden_ty_p3xy })))
                                    }
                                }
                            })
                        })
                    },
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((::std::option::Option<crate::prelude::Array<crate::lower::model::PackedMethod>>, crate::prelude::Text)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<::std::option::Option<crate::prelude::Array<crate::lower::model::PackedMethod>>>>>
    }));
    if crate::syntax::lexer::chars::has_prefix_f(&tr_p1.name_p, &crate::prelude::Text::lit("Prelude.")) || (&crate::prelude::len(&tr_p1.assocs_p) > &crate::prelude::Nat::from(0u32)) {
        ::std::option::Option::None
    } else {
        match &methods_or {
            ::std::option::Option::Some(methods_ps) => ::std::option::Option::Some(crate::lower::model::PackedDef { name_p: crate::lower::trait_name_f(&tr_p1.name_p), tr_p: crate::lower::path_in_f(&lx_p2, &tr_p1.home_p, &crate::lower::trait_name_f(&tr_p1.name_p)), methods_p: methods_ps.clone() }),
            ::std::option::Option::None => ::std::option::Option::None,
        }
    }
}

/// The step machine of `PackedDefOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?PackedDefOf: unbounded fn Lx, TraitInfo -> ?PackedDef
/// ```
pub struct PackedDefOf {
    pub lx0_p0: crate::lower::Lx,
    pub tr_p1: crate::check::env::TraitInfo,
}

impl ::prism_rtl::Job<::std::option::Option<crate::lower::model::PackedDef>> for PackedDefOf {
    fn cycle(&self) -> ::prism_rtl::Turn<::std::option::Option<crate::lower::model::PackedDef>> {
        let lx0_p0 = &self.lx0_p0;
        let tr_p1 = &self.tr_p1;
        let lx_p2 = crate::lower::program::in_module_f(lx0_p0, &tr_p1.file_p, &tr_p1.home_p);
        let hidden_ty_p3 = crate::check::types::Ty::TyCon(crate::prelude::Text::lit("\0Self"), crate::prelude::Array::new());
        let tr_p1x = tr_p1.clone();
        crate::prelude::call_value(crate::prelude::fold_job(tr_p1x.methods_p.clone(), ::std::option::Option::Some(crate::prelude::Array::new()), {
            let lx_p2x = lx_p2.clone();
            let tr_p1xx = tr_p1x.clone();
            let hidden_ty_p3x = hidden_ty_p3.clone();
            ::std::rc::Rc::new(move |(p0, p1): (::std::option::Option<crate::prelude::Array<crate::lower::model::PackedMethod>>, crate::prelude::Text)| {
                let lx_p2xy = lx_p2x.clone();
                let tr_p1xxy = tr_p1xx.clone();
                let hidden_ty_p3xy = hidden_ty_p3x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let acc_o4 = p0;
                    let mq_p5 = p1;
                    match &acc_o4 {
                        ::std::option::Option::None => ::prism_rtl::Turn::Finished(::std::option::Option::None),
                        ::std::option::Option::Some(acc_p6) => {
                            let v_p7 = crate::prelude::or(&crate::prelude::get(&lx_p2xy.g_p.vals_p, &mq_p5), &crate::check::env::builtin_f(&mq_p5, &crate::check::types::schemes::mono_f(&crate::check::types::Ty::TyErr)));
                            let (ps_pg, r_ph) = match &v_p7.scheme_p.ty_p {
                                crate::check::types::Ty::TyFn(_, ps_pd, r_pe) => (ps_pd.clone(), (**r_pe).clone()),
                                other_pf => (crate::prelude::Array::new(), other_pf.clone()),
                            };
                            let acc_p6x = acc_p6.clone();
                            crate::prelude::call_value(crate::prelude::each_job(ps_pg.clone(), {
                                let tr_p1xxyx = tr_p1xxy.clone();
                                let hidden_ty_p3xyx = hidden_ty_p3xy.clone();
                                ::std::rc::Rc::new(move |p0: crate::check::types::Ty| {
                                    let tr_p1xxyxy = tr_p1xxyx.clone();
                                    let hidden_ty_p3xyxy = hidden_ty_p3xyx.clone();
                                    crate::prelude::entered(crate::prelude::once_job(move || {
                                        let p_pi = p0;
                                        ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::lower::expr::Instantiated { t_p0: p_pi.clone(), params_p1: crate::prelude::Array::from(vec![tr_p1xxyxy.param_p.clone()]), args_p2: crate::prelude::Array::from(vec![hidden_ty_p3xyxy.clone()]) }))
                                    }))
                                }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::Ty>>>
                            }), move |each_19689: crate::prelude::Array<crate::check::types::Ty>| {
                                let marked_p8 = each_19689;
                                let hidden_p9 = crate::prelude::each(&marked_p8, &(|m_pj: &crate::check::types::Ty| m_pj == &hidden_ty_p3xy));
                                crate::prelude::call_then(crate::lower::expr::start_instantiated_f(r_ph.clone(), crate::prelude::Array::from(vec![tr_p1xxy.param_p.clone()]), crate::prelude::Array::from(vec![hidden_ty_p3xy.clone()])), move |instantiated_f_19834: crate::check::types::Ty| {
                                    let marked_result_pa = instantiated_f_19834;
                                    let whole_pb = crate::prelude::fold(&crate::check::errors::range0_f(&crate::prelude::len(&ps_pg)), &true, &(|ok_pk: &bool, i_pl: &crate::prelude::Nat| *ok_pk && (crate::prelude::or(&crate::prelude::index(&hidden_p9, i_pl), &false) || (&crate::prelude::or(&crate::prelude::index(&marked_p8, i_pl), &crate::check::types::Ty::TyErr) == &crate::prelude::or(&crate::prelude::index(&ps_pg, i_pl), &crate::check::types::Ty::TyErr)))));
                                    let own_qs_pc = crate::prelude::filter(&v_p7.scheme_p.qs_p, &(|q_pm: &crate::prelude::Text| q_pm != &tr_p1xxy.param_p));
                                    if (((&crate::prelude::len(&own_qs_pc) > &crate::prelude::Nat::from(0u32)) || !whole_pb) || !crate::prelude::fold(&hidden_p9, &false, &(|f_pn: &bool, h_po: &bool| *f_pn || *h_po))) || !((&marked_result_pa == &hidden_ty_p3xy) || (&marked_result_pa == &r_ph)) {
                                        ::prism_rtl::Turn::Finished(::std::option::Option::None)
                                    } else {
                                        {
                                            let sc_pp = {
                                                let mut this: crate::check::types::Scheme = v_p7.scheme_p.clone();
                                                this.ty_p = crate::lower::expr::instantiated_f(&this.ty_p, &crate::prelude::Array::from(vec![tr_p1xxy.param_p.clone()]), &crate::prelude::Array::from(vec![crate::check::types::Ty::TyAny(crate::prelude::Array::from(vec![tr_p1xxy.name_p.clone()]))]));
                                                this.qs_p = own_qs_pc.clone();
                                                this.bounds_p = crate::prelude::filter(&this.bounds_p, &(|(q_pq, _): &(crate::prelude::Text, crate::prelude::Text)| q_pq != &tr_p1xxy.param_p));
                                                this
                                            };
                                            ::prism_rtl::Turn::Finished(::std::option::Option::Some(crate::prelude::push(&acc_p6x, &crate::lower::model::PackedMethod { method_p: fn_def_of_f(&lx_p2xy, &mq_p5, &crate::prelude::Array::from(vec![dummy_clause_p()]), &sc_pp), hidden_p: hidden_p9.clone(), hidden_result_p: &marked_result_pa == &hidden_ty_p3xy })))
                                        }
                                    }
                                })
                            })
                        },
                    }
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((::std::option::Option<crate::prelude::Array<crate::lower::model::PackedMethod>>, crate::prelude::Text)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<::std::option::Option<crate::prelude::Array<crate::lower::model::PackedMethod>>>>>
        }), move |fold_19384: ::std::option::Option<crate::prelude::Array<crate::lower::model::PackedMethod>>| {
            let methods_or = fold_19384;
            if crate::syntax::lexer::chars::has_prefix_f(&tr_p1x.name_p, &crate::prelude::Text::lit("Prelude.")) || (&crate::prelude::len(&tr_p1x.assocs_p) > &crate::prelude::Nat::from(0u32)) {
                ::prism_rtl::Turn::Finished(::std::option::Option::None)
            } else {
                match &methods_or {
                    ::std::option::Option::Some(methods_ps) => ::prism_rtl::Turn::Finished(::std::option::Option::Some(crate::lower::model::PackedDef { name_p: crate::lower::trait_name_f(&tr_p1x.name_p), tr_p: crate::lower::path_in_f(&lx_p2, &tr_p1x.home_p, &crate::lower::trait_name_f(&tr_p1x.name_p)), methods_p: methods_ps.clone() })),
                    ::std::option::Option::None => ::prism_rtl::Turn::Finished(::std::option::Option::None),
                }
            }
        })
    }
}

/// `Start PackedDefOf, x`: what the function value is when passed to `@Run`.
pub fn start_packed_def_of_o(lx0_p0: crate::lower::Lx, tr_p1: crate::check::env::TraitInfo) -> ::std::rc::Rc<dyn ::prism_rtl::Job<::std::option::Option<crate::lower::model::PackedDef>>> {
    ::std::rc::Rc::new(PackedDefOf { lx0_p0, tr_p1 })
}

/// ```prism
/// PackedDictionaryOf: fn Lx, TraitInfo -> Ref
/// ```
pub fn packed_dictionary_of_f(lx_p0: &crate::lower::Lx, tr_p1: &crate::check::env::TraitInfo) -> crate::lower::model::Ref {
    crate::lower::ref_in_f(lx_p0, &tr_p1.home_p, &crate::prelude::Text::from(format!("{}_packed_of", &crate::prelude::lower(&crate::lower::trait_name_f(&tr_p1.name_p)))))
}

/// ```prism
/// ImplDefOf: unbounded fn Lx, ImplInfo -> ImplDef
/// ```
pub fn impl_def_of_f(lx_p0: &crate::lower::Lx, im_p1: &crate::check::env::ImplInfo) -> crate::lower::model::ImplDef {
    let tr_p2 = crate::prelude::or(&crate::prelude::get(&lx_p0.g_p.traits_p, &im_p1.cls_p), &crate::lower::expr::dummy_trait_info_p());
    let head_p3 = crate::lower::types::out_ty_of_f(lx_p0, &im_p1.head_p);
    let defs_p4 = crate::prelude::filter(&lx_p0.g_p.defs_p, &(|d_p7: &crate::check::env::Def| is_method_of_f(d_p7, im_p1)));
    let methods_p5 = crate::prelude::run_to_end(crate::prelude::each_job(defs_p4.clone(), {
        let tr_p2x = tr_p2.clone();
        let lx_p0x = lx_p0.clone();
        let im_p1x = im_p1.clone();
        ::std::rc::Rc::new(move |p0: crate::check::env::Def| {
            let tr_p2xy = tr_p2x.clone();
            let lx_p0xy = lx_p0x.clone();
            let im_p1xy = im_p1x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let d_p8 = p0;
                {
                    let mq_p9 = crate::prelude::fold(&tr_p2xy.methods_p, &crate::prelude::Text::lit(""), &(|found_pe: &crate::prelude::Text, q_pf: &crate::prelude::Text| if &crate::check::types::bare_name_f(q_pf) == &d_p8.name_p {
                        q_pf.clone()
                    } else {
                        found_pe.clone()
                    }));
                    let v_pa = crate::prelude::or(&crate::prelude::get(&lx_p0xy.g_p.vals_p, &mq_p9), &crate::check::env::builtin_f(&mq_p9, &crate::check::types::schemes::mono_f(&crate::check::types::Ty::TyErr)));
                    let own_pb = {
                        let mut this: crate::check::types::Scheme = v_pa.scheme_p.clone();
                        this.qs_p = crate::prelude::filter(&this.qs_p, &(|q_pg: &crate::prelude::Text| q_pg != &tr_p2xy.param_p));
                        this.bounds_p = crate::prelude::filter(&this.bounds_p, &(|(q_ph, _): &(crate::prelude::Text, crate::prelude::Text)| q_ph != &tr_p2xy.param_p));
                        this
                    };
                    let sc_pc = {
                        let mut this: crate::check::types::Scheme = crate::check::types::schemes::scheme_apart_f(&own_pb, &im_p1xy.qs_p);
                        this.ty_p = crate::lower::expr::instantiated_f(&this.ty_p, &crate::prelude::Array::from(vec![tr_p2xy.param_p.clone()]), &crate::prelude::Array::from(vec![im_p1xy.head_p.clone()]));
                        this
                    };
                    crate::prelude::call_then(start_fn_def_in_f(lx_p0xy.clone(), crate::lower::program::instance_key_f(&d_p8), mq_p9.clone(), method_clauses_f(&d_p8), sc_pc.clone()), move |fn_def_in_f_22041: crate::lower::model::FnDef| {
                        let fd_pd = fn_def_in_f_22041;
                        if crate::syntax::lexer::chars::has_prefix_f(&im_p1xy.cls_p, &crate::prelude::Text::lit("Prelude.")) {
                            crate::prelude::call_then(start_head_word_f(im_p1xy.head_p.clone()), move |head_word_f_22168: crate::prelude::Text| ::prism_rtl::Turn::Finished(renamed_f(&fd_pd, &crate::prelude::Text::from(format!("{}_{}", &crate::lower::snake_f(&d_p8.name_p), &head_word_f_22168)))))
                        } else {
                            ::prism_rtl::Turn::Finished(fd_pd.clone())
                        }
                    })
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::env::Def) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::FnDef>>>
    }));
    let generics_p6 = crate::prelude::run_to_end(crate::prelude::each_job(im_p1.qs_p.clone(), {
        let lx_p0x = lx_p0.clone();
        let im_p1x = im_p1.clone();
        ::std::rc::Rc::new(move |p0: crate::prelude::Text| {
            let lx_p0xy = lx_p0x.clone();
            let im_p1xy = im_p1x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let q_pi = p0;
                crate::prelude::call_then(start_impl_bounds_f(lx_p0xy.clone(), im_p1xy.clone(), q_pi.clone()), move |impl_bounds_f_22322: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished((crate::lower::camel_f(&q_pi), impl_bounds_f_22322)))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>)>>>
    }));
    crate::lower::model::ImplDef { cls_p: im_p1.cls_p.clone(), tr_p: crate::lower::path_in_f(lx_p0, &tr_p2.home_p, &crate::lower::trait_name_f(&im_p1.cls_p)), head_p: head_p3.clone(), generics_p: generics_p6.clone(), assocs_p: crate::prelude::run_to_end(crate::prelude::each_job(im_p1.assocs_p.clone(), {
        let lx_p0x = lx_p0.clone();
        ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::check::types::Ty)| {
            let lx_p0xy = lx_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (an_pj, at_pk) = p0;
                crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0xy.clone(), at_pk.clone()), move |out_ty_of_f_22498: crate::lower::model::OutTy| ::prism_rtl::Turn::Finished((crate::lower::camel_f(&an_pj), out_ty_of_f_22498)))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::check::types::Ty)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Text, crate::lower::model::OutTy)>>>
    })), result_only_p: result_only_names_f(lx_p0, &tr_p2), methods_p: methods_p5.clone(), doc_p: crate::prelude::Text::lit("") }
}

/// The step machine of `ImplDefOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ImplDefOf: unbounded fn Lx, ImplInfo -> ImplDef
/// ```
pub struct ImplDefOf {
    pub lx_p0: crate::lower::Lx,
    pub im_p1: crate::check::env::ImplInfo,
}

impl ::prism_rtl::Job<crate::lower::model::ImplDef> for ImplDefOf {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::lower::model::ImplDef> {
        let lx_p0 = &self.lx_p0;
        let im_p1 = &self.im_p1;
        let tr_p2 = crate::prelude::or(&crate::prelude::get(&lx_p0.g_p.traits_p, &im_p1.cls_p), &crate::lower::expr::dummy_trait_info_p());
        let im_p1x = im_p1.clone();
        let lx_p0x = lx_p0.clone();
        crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0x.clone(), im_p1x.head_p.clone()), move |out_ty_of_f_21346: crate::lower::model::OutTy| {
            let head_p3 = out_ty_of_f_21346;
            let defs_p4 = crate::prelude::filter(&lx_p0x.g_p.defs_p, &(|d_p7: &crate::check::env::Def| is_method_of_f(d_p7, &im_p1x)));
            crate::prelude::call_value(crate::prelude::each_job(defs_p4.clone(), {
                let tr_p2x = tr_p2.clone();
                let lx_p0xx = lx_p0x.clone();
                let im_p1xx = im_p1x.clone();
                ::std::rc::Rc::new(move |p0: crate::check::env::Def| {
                    let tr_p2xy = tr_p2x.clone();
                    let lx_p0xxy = lx_p0xx.clone();
                    let im_p1xxy = im_p1xx.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let d_p8 = p0;
                        {
                            let mq_p9 = crate::prelude::fold(&tr_p2xy.methods_p, &crate::prelude::Text::lit(""), &(|found_pe: &crate::prelude::Text, q_pf: &crate::prelude::Text| if &crate::check::types::bare_name_f(q_pf) == &d_p8.name_p {
                                q_pf.clone()
                            } else {
                                found_pe.clone()
                            }));
                            let v_pa = crate::prelude::or(&crate::prelude::get(&lx_p0xxy.g_p.vals_p, &mq_p9), &crate::check::env::builtin_f(&mq_p9, &crate::check::types::schemes::mono_f(&crate::check::types::Ty::TyErr)));
                            let own_pb = {
                                let mut this: crate::check::types::Scheme = v_pa.scheme_p.clone();
                                this.qs_p = crate::prelude::filter(&this.qs_p, &(|q_pg: &crate::prelude::Text| q_pg != &tr_p2xy.param_p));
                                this.bounds_p = crate::prelude::filter(&this.bounds_p, &(|(q_ph, _): &(crate::prelude::Text, crate::prelude::Text)| q_ph != &tr_p2xy.param_p));
                                this
                            };
                            let sc_pc = {
                                let mut this: crate::check::types::Scheme = crate::check::types::schemes::scheme_apart_f(&own_pb, &im_p1xxy.qs_p);
                                this.ty_p = crate::lower::expr::instantiated_f(&this.ty_p, &crate::prelude::Array::from(vec![tr_p2xy.param_p.clone()]), &crate::prelude::Array::from(vec![im_p1xxy.head_p.clone()]));
                                this
                            };
                            crate::prelude::call_then(start_fn_def_in_f(lx_p0xxy.clone(), crate::lower::program::instance_key_f(&d_p8), mq_p9.clone(), method_clauses_f(&d_p8), sc_pc.clone()), move |fn_def_in_f_22041: crate::lower::model::FnDef| {
                                let fd_pd = fn_def_in_f_22041;
                                if crate::syntax::lexer::chars::has_prefix_f(&im_p1xxy.cls_p, &crate::prelude::Text::lit("Prelude.")) {
                                    crate::prelude::call_then(start_head_word_f(im_p1xxy.head_p.clone()), move |head_word_f_22168: crate::prelude::Text| ::prism_rtl::Turn::Finished(renamed_f(&fd_pd, &crate::prelude::Text::from(format!("{}_{}", &crate::lower::snake_f(&d_p8.name_p), &head_word_f_22168)))))
                                } else {
                                    ::prism_rtl::Turn::Finished(fd_pd.clone())
                                }
                            })
                        }
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::env::Def) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::FnDef>>>
            }), move |each_21439: crate::prelude::Array<crate::lower::model::FnDef>| {
                let methods_p5 = each_21439;
                crate::prelude::call_value(crate::prelude::each_job(im_p1x.qs_p.clone(), {
                    let lx_p0xx = lx_p0x.clone();
                    let im_p1xx = im_p1x.clone();
                    ::std::rc::Rc::new(move |p0: crate::prelude::Text| {
                        let lx_p0xxy = lx_p0xx.clone();
                        let im_p1xxy = im_p1xx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let q_pi = p0;
                            crate::prelude::call_then(start_impl_bounds_f(lx_p0xxy.clone(), im_p1xxy.clone(), q_pi.clone()), move |impl_bounds_f_22322: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished((crate::lower::camel_f(&q_pi), impl_bounds_f_22322)))
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>)>>>
                }), move |each_22293: crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>)>| {
                    let generics_p6 = each_22293;
                    crate::prelude::call_value(crate::prelude::each_job(im_p1x.assocs_p.clone(), {
                        let lx_p0xx = lx_p0x.clone();
                        ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::check::types::Ty)| {
                            let lx_p0xxy = lx_p0xx.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let (an_pj, at_pk) = p0;
                                crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0xxy.clone(), at_pk.clone()), move |out_ty_of_f_22498: crate::lower::model::OutTy| ::prism_rtl::Turn::Finished((crate::lower::camel_f(&an_pj), out_ty_of_f_22498)))
                            }))
                        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::check::types::Ty)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Text, crate::lower::model::OutTy)>>>
                    }), move |each_22453: crate::prelude::Array<(crate::prelude::Text, crate::lower::model::OutTy)>| ::prism_rtl::Turn::Finished(crate::lower::model::ImplDef { cls_p: im_p1x.cls_p.clone(), tr_p: crate::lower::path_in_f(&lx_p0x, &tr_p2.home_p, &crate::lower::trait_name_f(&im_p1x.cls_p)), head_p: head_p3.clone(), generics_p: generics_p6.clone(), assocs_p: each_22453, result_only_p: result_only_names_f(&lx_p0x, &tr_p2), methods_p: methods_p5.clone(), doc_p: crate::prelude::Text::lit("") }))
                })
            })
        })
    }
}

/// `Start ImplDefOf, x`: what the function value is when passed to `@Run`.
pub fn start_impl_def_of_f(lx_p0: crate::lower::Lx, im_p1: crate::check::env::ImplInfo) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::ImplDef>> {
    ::std::rc::Rc::new(ImplDefOf { lx_p0, im_p1 })
}

/// ```prism
/// ImplBounds: unbounded fn Lx, ImplInfo, Text -> [Text]
/// ```
pub fn impl_bounds_f(lx_p0: &crate::lower::Lx, im_p1: &crate::check::env::ImplInfo, q_p2: &crate::prelude::Text) -> crate::prelude::Array<crate::prelude::Text> {
    crate::prelude::fold(&im_p1.bounds_p, &crate::prelude::Array::from(vec![crate::prelude::Text::lit("std::Clone")]), &(|acc_p3: &crate::prelude::Array<crate::prelude::Text>, (v_p4, cls_p5): &(crate::prelude::Text, crate::prelude::Text)| if v_p4 == q_p2 {
        crate::check::types::union_texts_f(acc_p3, &bound_of_f(lx_p0, cls_p5))
    } else {
        acc_p3.clone()
    }))
}

/// The step machine of `ImplBounds`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ImplBounds: unbounded fn Lx, ImplInfo, Text -> [Text]
/// ```
pub struct ImplBounds {
    pub lx_p0: crate::lower::Lx,
    pub im_p1: crate::check::env::ImplInfo,
    pub q_p2: crate::prelude::Text,
}

impl ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>> for ImplBounds {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<crate::prelude::Text>> {
        let lx_p0 = &self.lx_p0;
        let im_p1 = &self.im_p1;
        let q_p2 = &self.q_p2;
        ::prism_rtl::Turn::Finished(crate::prelude::fold(&im_p1.bounds_p, &crate::prelude::Array::from(vec![crate::prelude::Text::lit("std::Clone")]), &(|acc_p3: &crate::prelude::Array<crate::prelude::Text>, (v_p4, cls_p5): &(crate::prelude::Text, crate::prelude::Text)| if v_p4 == q_p2 {
            crate::check::types::union_texts_f(acc_p3, &bound_of_f(lx_p0, cls_p5))
        } else {
            acc_p3.clone()
        })))
    }
}

/// `Start ImplBounds, x`: what the function value is when passed to `@Run`.
pub fn start_impl_bounds_f(lx_p0: crate::lower::Lx, im_p1: crate::check::env::ImplInfo, q_p2: crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>> {
    ::std::rc::Rc::new(ImplBounds { lx_p0, im_p1, q_p2 })
}

/// ```prism
/// Renamed: fn FnDef, Text -> FnDef
/// ```
pub fn renamed_f(fd_p0: &crate::lower::model::FnDef, n_p1: &crate::prelude::Text) -> crate::lower::model::FnDef {
    let mut this: crate::lower::model::FnDef = fd_p0.clone();
    this.name_p = n_p1.clone();
    this
}

/// ```prism
/// IsMethodOf: fn Def, ImplInfo -> Bool
/// ```
pub fn is_method_of_f(d_p0: &crate::check::env::Def, im_p1: &crate::check::env::ImplInfo) -> bool {
    match &d_p0.body_p {
        crate::check::env::DefBody::DbMethod(_, cls_p2, other_p3) => ((cls_p2 == &im_p1.cls_p) && (&other_p3.span_p == &im_p1.span_p)) && (&other_p3.file_p == &im_p1.file_p),
        _ => false,
    }
}

/// ```prism
/// MethodClauses: fn Def -> [FnClause]
/// ```
pub fn method_clauses_f(d_p0: &crate::check::env::Def) -> crate::prelude::Array<crate::syntax::decls::FnClause> {
    match &d_p0.body_p {
        crate::check::env::DefBody::DbMethod(cs_p1, _, _) => cs_p1.clone(),
        _ => crate::prelude::Array::new(),
    }
}
