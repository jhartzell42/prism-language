//! The module `Lower.Functions`, from `target/bootstrap/src/prismc/lower/functions.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// ```prism
/// BoundOf: fn Lx, Text -> [Text]
/// ```
pub fn bound_of(lx: &crate::lower::Lx, text1: &Text) -> Array<Text> {
    match text1 {
        c0_1 if (c0_1 == &Text::lit("Prelude.Eq")) => Array::from(vec![Text::lit("Eq")]),
        c1_1 if (c1_1 == &Text::lit("Prelude.Ord")) => Array::from(vec![Text::lit("Ord")]),
        c2_1 if (c2_1 == &Text::lit("Prelude.Show")) => Array::from(vec![Text::lit("Show")]),
        c3_1 if (c3_1 == &Text::lit("Prelude.Num")) => Array::from(vec![Text::lit("Num")]),
        c4_1 if (c4_1 == &Text::lit("Prelude.Pod")) => Array::from(vec![Text::lit("ToPod"), Text::lit("FromPod")]),
        cls => match get(&lx.g.traits, cls) {
            Some(tr) => Array::from(vec![crate::lower::path_in(lx, &tr.home, &crate::lower::camel(&crate::check::types::bare_name(cls)))]),
            None => Array::new(),
        },
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// SchemeGenerics: fn Lx, Scheme -> [((Text, [Text]))]
/// ```
pub fn scheme_generics(lx: &crate::lower::Lx, sc: &crate::check::types::Scheme) -> Array<(Text, Array<Text>)> {
    each(&sc.qs, &(|q: &Text| {
        let bs = fold(&sc.bounds, &Array::from(vec![Text::lit("Clone")]), &(|acc: &Array<Text>, (v_, cls): &(Text, Text)| if v_ == q {
            crate::check::types::union_texts(acc, &bound_of(lx, cls))
        } else {
            acc.clone()
        }));
        let keyed = if keys_by(&sc.ty, q) {
            crate::check::types::union_texts(&bs, &Array::from(vec![Text::lit("Ord")]))
        } else {
            bs.clone()
        };
        (crate::lower::camel(q), keyed.clone())
    }))
}

/// ```prism
/// KeysBy: fn Ty, Text -> Bool
/// ```
pub fn keys_by(t: &crate::check::types::Ty, q: &Text) -> bool {
    match t {
        crate::check::types::Ty::TyMap(k, v_) => ((&**k == &crate::check::types::Ty::TyQ(q.clone())) || keys_by(&**k, q)) || keys_by(&**v_, q),
        crate::check::types::Ty::TyCon(_, ts) => fold(ts, &false, &(|found: &bool, x: &crate::check::types::Ty| *found || keys_by(x, q))),
        crate::check::types::Ty::TyFn(_, ps, r) => fold(ps, &false, &(|found: &bool, x: &crate::check::types::Ty| *found || keys_by(x, q))) || keys_by(&**r, q),
        crate::check::types::Ty::TyTuple(ts) => fold(ts, &false, &(|found: &bool, x: &crate::check::types::Ty| *found || keys_by(x, q))),
        crate::check::types::Ty::TyArray(x) => keys_by(&**x, q),
        crate::check::types::Ty::TySig(_, x) => keys_by(&**x, q),
        crate::check::types::Ty::TyAt(x, _) => keys_by(&**x, q),
        _ => false,
    }
}

/// ```prism
/// ParamNames: fn Lx, [FnClause], [OutTy] -> [((Text, Bool))]
/// ```
pub fn param_names(lx: &crate::lower::Lx, clauses: &Array<crate::syntax::decls::FnClause>, pts: &Array<crate::lower::model::OutTy>) -> Array<(Text, bool)> {
    each(&crate::check::errors::range0(&len(pts)), &(|i: &Nat| {
        let names = each(clauses, &(|c: &crate::syntax::decls::FnClause| plain_binder(lx, &or(&index(&c.params, i), &crate::lower::patterns::dummy_pat()))));
        let first_ = or(&index(&names, &Nat::from(0u32)), &Text::lit(""));
        let same = (&first_ != &Text::lit("")) && fold(&names, &true, &(|ok_: &bool, n: &Text| *ok_ && (n == &first_)));
        if same {
            (crate::lower::local_name(lx, &first_), false)
        } else {
            (param_word(&or(&index(pts, i), &crate::lower::model::OutTy::OutUnit), i), true)
        }
    }))
}

/// ```prism
/// PlainBinder: fn Lx, Pattern -> Text
/// ```
pub fn plain_binder(lx: &crate::lower::Lx, p_: &crate::syntax::Pattern_) -> Text {
    match &*p_.kind {
        crate::syntax::PatternKind::PName(n) => {
            let (qk_opt, why) = crate::check::env::names::resolve_value(&lx.g, &lx.home, n);
            let is_ctor = match &qk_opt {
                Some(qk) => crate::check::env::has_key(&lx.g.ctors, qk) && (crate::check::env::is_upper_text(&crate::lower::base(&crate::check::env::sname_key(n))) || crate::lower::patterns::is_unit_ctor(lx, qk)),
                None => false,
            };
            if is_ctor { Text::lit("") } else { crate::check::env::sname_key(n) }
        },
        crate::syntax::PatternKind::PGroup(q) => plain_binder(lx, &**q),
        _ => Text::lit(""),
    }
}

/// ```prism
/// ParamWord: fn OutTy, Nat -> Text
/// ```
pub fn param_word(t: &crate::lower::model::OutTy, i: &Nat) -> Text {
    let base = match t {
        crate::lower::model::OutTy::OutNamed(n, _) => crate::lower::snake(&or(&crate::syntax::lexer::chars::last(&split_on(n, &Text::lit("::"))), &Text::lit("arg"))),
        crate::lower::model::OutTy::OutText => Text::lit("text"),
        crate::lower::model::OutTy::OutNat => Text::lit("n"),
        crate::lower::model::OutTy::OutInt => Text::lit("i"),
        crate::lower::model::OutTy::OutArray(_) => Text::lit("xs"),
        crate::lower::model::OutTy::OutMap(_, _) => Text::lit("map"),
        crate::lower::model::OutTy::OutOpt(_) => Text::lit("opt"),
        _ => Text::lit("arg"),
    };
    Text::from(format!("{}{}", &base, i))
}

/// ```prism
/// ClausesBody: unbounded fn Lx, Env, [FnClause], [((Text, Bool))], [Ty], (fn Lx, Env, FnBody -> Ex), Text, OutTy -> Ex
/// ```
pub fn clauses_body(lx: &crate::lower::Lx, env: &crate::lower::types::Env, clauses: &Array<crate::syntax::decls::FnClause>, names: &Array<(Text, bool)>, ptys: &Array<crate::check::types::Ty>, body_fn: &Rc<dyn Fn((crate::lower::Lx, crate::lower::types::Env, crate::syntax::decls::FnBody)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>, label: &Text, t: &crate::lower::model::OutTy) -> crate::lower::model::Ex {
    let env1 = run_to_end(fold_job(crate::check::errors::range0(&len(names)), env.clone(), {
        let names = names.clone();
        let lx = lx.clone();
        let clauses = clauses.clone();
        let ptys = ptys.clone();
        Rc::new(move |(p0, p1): (crate::lower::types::Env, Nat)| {
            let names = names.clone();
            let lx = lx.clone();
            let clauses = clauses.clone();
            let ptys = ptys.clone();
            entered(once_job(move || {
                let en = p0;
                let i = p1;
                {
                    let (rs, matched) = or(&index(&names, &i), &(Text::lit(""), true));
                    if matched {
                        prism_rtl::Turn::Finished(en.clone())
                    } else {
                        call_then(crate::lower::types::start_out_ty_of(lx.clone(), crate::lower::types::peel(&or(&index(&ptys, &i), &crate::check::types::Ty::TyErr))), move |out_ty_of_4892: crate::lower::model::OutTy| prism_rtl::Turn::Finished(crate::lower::types::bind(&en, &plain_binder(&lx, &or(&index(&or(&index(&clauses, &Nat::from(0u32)), &dummy_clause()).params, &i), &crate::lower::patterns::dummy_pat())), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(rs.clone()), crate::lower::types::Holding::ByRef, out_ty_of_4892))))
                    }
                }
            }))
        }) as Rc<dyn Fn((crate::lower::types::Env, Nat)) -> Rc<dyn prism_rtl::Job<crate::lower::types::Env>>>
    }));
    let scrut_ix = filter(&crate::check::errors::range0(&len(names)), &(|i: &Nat| match index(names, i) {
        Some((_, true)) => true,
        _ => false,
    }));
    if &len(&scrut_ix) == &Nat::from(0u32) {
        {
            let c = or(&index(clauses, &Nat::from(0u32)), &dummy_clause());
            run_to_end(body_fn((lx.clone(), env1.clone(), c.body.clone())))
        }
    } else {
        {
            let scrut = 'm5189: {
                if let m5189_0 = &scrut_ix && (m5189_0.len() == 1) && let Some(i) = index(m5189_0, &Nat::from(0u32)) {
                    break 'm5189 crate::lower::model::Ex::XVar(or(&index(&each(names, &(|(n, _): &(Text, bool)| n.clone())), &i), &Text::lit("arg")));
                }
                crate::lower::model::Ex::XTuple(each(&scrut_ix, &(|i: &Nat| crate::lower::model::Ex::XVar(or(&index(&each(names, &(|(n, _): &(Text, bool)| n.clone())), i), &Text::lit("arg"))))))
            };
            let arms = run_to_end(each_job(crate::check::errors::range0(&len(clauses)), {
                let clauses = clauses.clone();
                let scrut_ix = scrut_ix.clone();
                let lx = lx.clone();
                let ptys = ptys.clone();
                let label = label.clone();
                let body_fn = body_fn.clone();
                let env1 = env1.clone();
                Rc::new(move |p0: Nat| {
                    let clauses = clauses.clone();
                    let scrut_ix = scrut_ix.clone();
                    let lx = lx.clone();
                    let ptys = ptys.clone();
                    let label = label.clone();
                    let body_fn = body_fn.clone();
                    let env1 = env1.clone();
                    entered(once_job(move || {
                        let ci = p0;
                        {
                            let c = or(&index(&clauses, &ci), &dummy_clause());
                            call_value(each_job(scrut_ix.clone(), {
                                let lx = lx.clone();
                                let c = c.clone();
                                let ptys = ptys.clone();
                                let label = label.clone();
                                let ci = ci.clone();
                                Rc::new(move |p0: Nat| {
                                    let lx = lx.clone();
                                    let c = c.clone();
                                    let ptys = ptys.clone();
                                    let label = label.clone();
                                    let ci = ci.clone();
                                    entered(once_job(move || {
                                        let i = p0;
                                        prism_rtl::Turn::More(Rc::new(crate::lower::patterns::RustPat { lx: lx.clone(), p_: or(&index(&c.params, &i), &crate::lower::patterns::dummy_pat()), ty: or(&index(&ptys, &i), &crate::check::types::Ty::TyErr), mode: crate::lower::types::Holding::ByRef, fresh: Text::from(format!("{}{}_{}", &label, &ci, &i)) }))
                                    }))
                                }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<crate::lower::patterns::PatOut>>>
                            }), move |each_5504: Array<crate::lower::patterns::PatOut>| {
                                let pos = each_5504;
                                let pa = 'm5630: {
                                    if let m5630_0 = &pos && (m5630_0.len() == 1) && let Some(o) = index(m5630_0, &Nat::from(0u32)) {
                                        break 'm5630 o.pa.clone();
                                    }
                                    crate::lower::model::Pa::PaTuple(each(&pos, &(|o: &crate::lower::patterns::PatOut| o.pa.clone())))
                                };
                                let conds = fold(&pos, &Array::new(), &(|acc: &Array<crate::lower::model::Cc>, o: &crate::lower::patterns::PatOut| append(acc, &o.conds)));
                                let binds = fold(&pos, &Array::new(), &(|acc: &Array<(Text, crate::lower::types::Bn)>, o: &crate::lower::patterns::PatOut| append(acc, &o.binds)));
                                call_value((&body_fn)((lx.clone(), crate::lower::expr::bind_all(&env1, &binds), c.body.clone())), move |body_5910: crate::lower::model::Ex| prism_rtl::Turn::Finished(crate::lower::model::XArm { pat: pa.clone(), conds: conds.clone(), body: body_5910 }))
                            })
                        }
                    }))
                }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<crate::lower::model::XArm>>>
            }));
            crate::lower::types::own(&crate::lower::expr::arms_value(&scrut, &arms, &Text::from(format!("\'{}", label)), t))
        }
    }
}

/// The step machine of `ClausesBody`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ClausesBody: unbounded fn Lx, Env, [FnClause], [((Text, Bool))], [Ty], (fn Lx, Env, FnBody -> Ex), Text, OutTy -> Ex
/// ```
pub struct ClausesBody {
    pub lx: crate::lower::Lx,
    pub env: crate::lower::types::Env,
    pub clauses: Array<crate::syntax::decls::FnClause>,
    pub names: Array<(Text, bool)>,
    pub ptys: Array<crate::check::types::Ty>,
    pub body_fn: Rc<dyn Fn((crate::lower::Lx, crate::lower::types::Env, crate::syntax::decls::FnBody)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>,
    pub label: Text,
    pub t: crate::lower::model::OutTy,
}

impl prism_rtl::Job<crate::lower::model::Ex> for ClausesBody {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::Ex> {
        let lx = &self.lx;
        let env = &self.env;
        let clauses = &self.clauses;
        let names = &self.names;
        let ptys = &self.ptys;
        let body_fn = &self.body_fn;
        let label = &self.label;
        let t = &self.t;
        let body_fn = body_fn.clone();
        let clauses = clauses.clone();
        let env = env.clone();
        let label = label.clone();
        let lx = lx.clone();
        let names = names.clone();
        let ptys = ptys.clone();
        let t = t.clone();
        call_value(fold_job(crate::check::errors::range0(&len(&names)), env.clone(), {
            let names = names.clone();
            let lx = lx.clone();
            let clauses = clauses.clone();
            let ptys = ptys.clone();
            Rc::new(move |(p0, p1): (crate::lower::types::Env, Nat)| {
                let names = names.clone();
                let lx = lx.clone();
                let clauses = clauses.clone();
                let ptys = ptys.clone();
                entered(once_job(move || {
                    let en = p0;
                    let i = p1;
                    {
                        let (rs, matched) = or(&index(&names, &i), &(Text::lit(""), true));
                        if matched {
                            prism_rtl::Turn::Finished(en.clone())
                        } else {
                            call_then(crate::lower::types::start_out_ty_of(lx.clone(), crate::lower::types::peel(&or(&index(&ptys, &i), &crate::check::types::Ty::TyErr))), move |out_ty_of_4892: crate::lower::model::OutTy| prism_rtl::Turn::Finished(crate::lower::types::bind(&en, &plain_binder(&lx, &or(&index(&or(&index(&clauses, &Nat::from(0u32)), &dummy_clause()).params, &i), &crate::lower::patterns::dummy_pat())), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(rs.clone()), crate::lower::types::Holding::ByRef, out_ty_of_4892))))
                        }
                    }
                }))
            }) as Rc<dyn Fn((crate::lower::types::Env, Nat)) -> Rc<dyn prism_rtl::Job<crate::lower::types::Env>>>
        }), move |fold_4648: crate::lower::types::Env| {
            let env1 = fold_4648;
            let scrut_ix = filter(&crate::check::errors::range0(&len(&names)), &(|i: &Nat| match index(&names, i) {
                Some((_, true)) => true,
                _ => false,
            }));
            if &len(&scrut_ix) == &Nat::from(0u32) {
                {
                    let c = or(&index(&clauses, &Nat::from(0u32)), &dummy_clause());
                    (&body_fn)((lx.clone(), env1.clone(), c.body.clone())).cycle()
                }
            } else {
                {
                    let scrut = 'm5189: {
                        if let m5189_0 = &scrut_ix && (m5189_0.len() == 1) && let Some(i) = index(m5189_0, &Nat::from(0u32)) {
                            break 'm5189 crate::lower::model::Ex::XVar(or(&index(&each(&names, &(|(n, _): &(Text, bool)| n.clone())), &i), &Text::lit("arg")));
                        }
                        crate::lower::model::Ex::XTuple(each(&scrut_ix, &(|i: &Nat| crate::lower::model::Ex::XVar(or(&index(&each(&names, &(|(n, _): &(Text, bool)| n.clone())), i), &Text::lit("arg"))))))
                    };
                    call_value(each_job(crate::check::errors::range0(&len(&clauses)), {
                        let clauses = clauses.clone();
                        let scrut_ix = scrut_ix.clone();
                        let lx = lx.clone();
                        let ptys = ptys.clone();
                        let label = label.clone();
                        let body_fn = body_fn.clone();
                        let env1 = env1.clone();
                        Rc::new(move |p0: Nat| {
                            let clauses = clauses.clone();
                            let scrut_ix = scrut_ix.clone();
                            let lx = lx.clone();
                            let ptys = ptys.clone();
                            let label = label.clone();
                            let body_fn = body_fn.clone();
                            let env1 = env1.clone();
                            entered(once_job(move || {
                                let ci = p0;
                                {
                                    let c = or(&index(&clauses, &ci), &dummy_clause());
                                    call_value(each_job(scrut_ix.clone(), {
                                        let lx = lx.clone();
                                        let c = c.clone();
                                        let ptys = ptys.clone();
                                        let label = label.clone();
                                        let ci = ci.clone();
                                        Rc::new(move |p0: Nat| {
                                            let lx = lx.clone();
                                            let c = c.clone();
                                            let ptys = ptys.clone();
                                            let label = label.clone();
                                            let ci = ci.clone();
                                            entered(once_job(move || {
                                                let i = p0;
                                                prism_rtl::Turn::More(Rc::new(crate::lower::patterns::RustPat { lx: lx.clone(), p_: or(&index(&c.params, &i), &crate::lower::patterns::dummy_pat()), ty: or(&index(&ptys, &i), &crate::check::types::Ty::TyErr), mode: crate::lower::types::Holding::ByRef, fresh: Text::from(format!("{}{}_{}", &label, &ci, &i)) }))
                                            }))
                                        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<crate::lower::patterns::PatOut>>>
                                    }), move |each_5504: Array<crate::lower::patterns::PatOut>| {
                                        let pos = each_5504;
                                        let pa = 'm5630: {
                                            if let m5630_0 = &pos && (m5630_0.len() == 1) && let Some(o) = index(m5630_0, &Nat::from(0u32)) {
                                                break 'm5630 o.pa.clone();
                                            }
                                            crate::lower::model::Pa::PaTuple(each(&pos, &(|o: &crate::lower::patterns::PatOut| o.pa.clone())))
                                        };
                                        let conds = fold(&pos, &Array::new(), &(|acc: &Array<crate::lower::model::Cc>, o: &crate::lower::patterns::PatOut| append(acc, &o.conds)));
                                        let binds = fold(&pos, &Array::new(), &(|acc: &Array<(Text, crate::lower::types::Bn)>, o: &crate::lower::patterns::PatOut| append(acc, &o.binds)));
                                        call_value((&body_fn)((lx.clone(), crate::lower::expr::bind_all(&env1, &binds), c.body.clone())), move |body_5910: crate::lower::model::Ex| prism_rtl::Turn::Finished(crate::lower::model::XArm { pat: pa.clone(), conds: conds.clone(), body: body_5910 }))
                                    })
                                }
                            }))
                        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<crate::lower::model::XArm>>>
                    }), move |each_5399: Array<crate::lower::model::XArm>| {
                        let arms = each_5399;
                        prism_rtl::Turn::Finished(crate::lower::types::own(&crate::lower::expr::arms_value(&scrut, &arms, &Text::from(format!("\'{}", &label)), &t)))
                    })
                }
            }
        })
    }
}

/// `Start ClausesBody, x`: what the function value is when passed to `@Run`.
pub fn start_clauses_body(lx: crate::lower::Lx, env: crate::lower::types::Env, clauses: Array<crate::syntax::decls::FnClause>, names: Array<(Text, bool)>, ptys: Array<crate::check::types::Ty>, body_fn: Rc<dyn Fn((crate::lower::Lx, crate::lower::types::Env, crate::syntax::decls::FnBody)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>, label: Text, t: crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>> {
    Rc::new(ClausesBody { lx, env, clauses, names, ptys, body_fn, label, t })
}

/// ```prism
/// let dummyClause
/// ```
pub fn dummy_clause() -> crate::syntax::decls::FnClause {
    crate::syntax::decls::FnClause { name: crate::syntax::decls::DefName::DefOp(Text::lit(""), crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) }), params: Array::new(), body: crate::syntax::decls::FnBody::BodyExpr(crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EError), span: crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) } }), span: crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) } }
}

/// ```prism
/// FnBodyValue: unbounded fn Lx, Env, FnBody -> Ex
/// ```
pub fn fn_body_value(lx: &crate::lower::Lx, env: &crate::lower::types::Env, fn_body2: &crate::syntax::decls::FnBody) -> crate::lower::model::Ex {
    match fn_body2 {
        crate::syntax::decls::FnBody::BodyExpr(x) => crate::lower::types::own(&crate::lower::expr::value_of(lx, env, x)),
        crate::syntax::decls::FnBody::BodyBlock(b) => crate::lower::types::own(&crate::lower::expr::block_value(lx, env, b)),
    }
}

/// The step machine of `FnBodyValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FnBodyValue: unbounded fn Lx, Env, FnBody -> Ex
/// ```
pub struct FnBodyValue {
    pub lx: crate::lower::Lx,
    pub env: crate::lower::types::Env,
    pub fn_body2: crate::syntax::decls::FnBody,
}

impl prism_rtl::Job<crate::lower::model::Ex> for FnBodyValue {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::Ex> {
        let lx = &self.lx;
        let env = &self.env;
        let fn_body2 = &self.fn_body2;
        match fn_body2 {
            crate::syntax::decls::FnBody::BodyExpr(x) => {
                let env = env.clone();
                let lx = lx.clone();
                let x = x.clone();
                call_then(crate::lower::expr::start_value_of(lx.clone(), env.clone(), x.clone()), move |value_of_6269: crate::lower::types::Vl| prism_rtl::Turn::Finished(crate::lower::types::own(&value_of_6269)))
            },
            crate::syntax::decls::FnBody::BodyBlock(b) => {
                let b = b.clone();
                let env = env.clone();
                let lx = lx.clone();
                call_then(crate::lower::expr::start_block_value(lx.clone(), env.clone(), b.clone()), move |block_value_6334: crate::lower::types::Vl| prism_rtl::Turn::Finished(crate::lower::types::own(&block_value_6334)))
            },
        }
    }
}

/// `Start FnBodyValue, x`: what the function value is when passed to `@Run`.
pub fn start_fn_body_value(lx: crate::lower::Lx, env: crate::lower::types::Env, fn_body2: crate::syntax::decls::FnBody) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>> {
    Rc::new(FnBodyValue { lx, env, fn_body2 })
}

/// ```prism
/// FnDefOf: unbounded fn Lx, Text, [FnClause], Scheme -> FnDef
/// ```
pub fn fn_def_of(lx: &crate::lower::Lx, qk: &Text, clauses: &Array<crate::syntax::decls::FnClause>, sc: &crate::check::types::Scheme) -> crate::lower::model::FnDef {
    let (ptys0, res) = match &sc.ty {
        crate::check::types::Ty::TyFn(_, ps, r) => (ps.clone(), (**r).clone()),
        other => (Array::new(), other.clone()),
    };
    let ptys = if crate::lower::types::has_blueprint(&res) {
        each(&ptys0, &(|p_: &crate::check::types::Ty| crate::lower::types::event_param(p_)))
    } else {
        ptys0.clone()
    };
    let pts = run_to_end(each_job(ptys.clone(), {
        let lx = lx.clone();
        Rc::new(move |p0: crate::check::types::Ty| {
            let lx = lx.clone();
            entered(once_job(move || {
                let p_ = p0;
                prism_rtl::Turn::More(Rc::new(crate::lower::types::OutTyOf { lx: lx.clone(), t: crate::lower::types::peel(&p_) }))
            }))
        }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::lower::model::OutTy>>>
    }));
    let names = param_names(lx, clauses, &pts);
    let body = clauses_body(lx, &crate::lower::types::empty_env(), clauses, &names, &ptys, &(Rc::new(|(a0, a1, a2): (crate::lower::Lx, crate::lower::types::Env, crate::syntax::decls::FnBody)| entered(start_fn_body_value(a0, a1, a2))) as Rc<dyn Fn((crate::lower::Lx, crate::lower::types::Env, crate::syntax::decls::FnBody)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>), &Text::lit("c"), &crate::lower::types::out_ty_of(lx, &crate::lower::types::peel(&res)));
    let params = each(&crate::check::errors::range0(&len(&pts)), &(|i: &Nat| (or(&index(&each(&names, &(|(n, _): &(Text, bool)| n.clone())), i), &Text::lit("arg")), crate::lower::model::OutTy::OutRef(Rc::new(or(&index(&pts, i), &crate::lower::model::OutTy::OutUnit))))));
    let ret = crate::lower::types::out_ty_of(lx, &crate::lower::types::peel(&res));
    let used = fold(&push(&pts, &ret), &Array::new(), &(|acc: &Array<Text>, t: &crate::lower::model::OutTy| crate::check::types::union_texts(acc, &ty_params_in(t))));
    let generics = filter(&scheme_generics(lx, sc), &(|(g, _): &(Text, Array<Text>)| crate::check::types::has_text(&used, g)));
    crate::lower::model::FnDef { name: or(&get(&lx.rs_names, qk), &crate::lower::snake(&crate::check::types::bare_name(qk))), generics: generics.clone(), params: params.clone(), ret: ret.clone(), body: body.clone(), doc: signature_text(lx, qk), public: true }
}

/// The step machine of `FnDefOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FnDefOf: unbounded fn Lx, Text, [FnClause], Scheme -> FnDef
/// ```
pub struct FnDefOf {
    pub lx: crate::lower::Lx,
    pub qk: Text,
    pub clauses: Array<crate::syntax::decls::FnClause>,
    pub sc: crate::check::types::Scheme,
}

impl prism_rtl::Job<crate::lower::model::FnDef> for FnDefOf {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::FnDef> {
        let lx = &self.lx;
        let qk = &self.qk;
        let clauses = &self.clauses;
        let sc = &self.sc;
        let (ptys0, res) = match &sc.ty {
            crate::check::types::Ty::TyFn(_, ps, r) => (ps.clone(), (**r).clone()),
            other => (Array::new(), other.clone()),
        };
        let ptys = if crate::lower::types::has_blueprint(&res) {
            each(&ptys0, &(|p_: &crate::check::types::Ty| crate::lower::types::event_param(p_)))
        } else {
            ptys0.clone()
        };
        let clauses = clauses.clone();
        let lx = lx.clone();
        let qk = qk.clone();
        let sc = sc.clone();
        call_value(each_job(ptys.clone(), {
            let lx = lx.clone();
            Rc::new(move |p0: crate::check::types::Ty| {
                let lx = lx.clone();
                entered(once_job(move || {
                    let p_ = p0;
                    prism_rtl::Turn::More(Rc::new(crate::lower::types::OutTyOf { lx: lx.clone(), t: crate::lower::types::peel(&p_) }))
                }))
            }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::lower::model::OutTy>>>
        }), move |each_6891: Array<crate::lower::model::OutTy>| {
            let pts = each_6891;
            let names = param_names(&lx, &clauses, &pts);
            call_then(crate::lower::types::start_out_ty_of(lx.clone(), crate::lower::types::peel(&res)), move |out_ty_of_7054: crate::lower::model::OutTy| call_then(start_clauses_body(lx.clone(), crate::lower::types::empty_env(), clauses.clone(), names.clone(), ptys.clone(), Rc::new(|(a0, a1, a2): (crate::lower::Lx, crate::lower::types::Env, crate::syntax::decls::FnBody)| entered(start_fn_body_value(a0, a1, a2))) as Rc<dyn Fn((crate::lower::Lx, crate::lower::types::Env, crate::syntax::decls::FnBody)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>, Text::lit("c"), out_ty_of_7054), move |clauses_body_6987: crate::lower::model::Ex| {
                let body = clauses_body_6987;
                let params = each(&crate::check::errors::range0(&len(&pts)), &(|i: &Nat| (or(&index(&each(&names, &(|(n, _): &(Text, bool)| n.clone())), i), &Text::lit("arg")), crate::lower::model::OutTy::OutRef(Rc::new(or(&index(&pts, i), &crate::lower::model::OutTy::OutUnit))))));
                call_then(crate::lower::types::start_out_ty_of(lx.clone(), crate::lower::types::peel(&res)), move |out_ty_of_7222: crate::lower::model::OutTy| {
                    let ret = out_ty_of_7222;
                    let used = fold(&push(&pts, &ret), &Array::new(), &(|acc: &Array<Text>, t: &crate::lower::model::OutTy| crate::check::types::union_texts(acc, &ty_params_in(t))));
                    let generics = filter(&scheme_generics(&lx, &sc), &(|(g, _): &(Text, Array<Text>)| crate::check::types::has_text(&used, g)));
                    prism_rtl::Turn::Finished(crate::lower::model::FnDef { name: or(&get(&lx.rs_names, &qk), &crate::lower::snake(&crate::check::types::bare_name(&qk))), generics: generics.clone(), params: params.clone(), ret: ret.clone(), body: body.clone(), doc: signature_text(&lx, &qk), public: true })
                })
            }))
        })
    }
}

/// `Start FnDefOf, x`: what the function value is when passed to `@Run`.
pub fn start_fn_def_of(lx: crate::lower::Lx, qk: Text, clauses: Array<crate::syntax::decls::FnClause>, sc: crate::check::types::Scheme) -> Rc<dyn prism_rtl::Job<crate::lower::model::FnDef>> {
    Rc::new(FnDefOf { lx, qk, clauses, sc })
}

/// ```prism
/// TyParamsIn: fn OutTy -> [Text]
/// ```
pub fn ty_params_in(t: &crate::lower::model::OutTy) -> Array<Text> {
    match t {
        crate::lower::model::OutTy::OutGen(n) => Array::from(vec![n.clone()]),
        crate::lower::model::OutTy::OutNamed(_, ts) => fold(ts, &Array::new(), &(|acc: &Array<Text>, x: &crate::lower::model::OutTy| crate::check::types::union_texts(acc, &ty_params_in(x)))),
        crate::lower::model::OutTy::OutTuple(ts) => fold(ts, &Array::new(), &(|acc: &Array<Text>, x: &crate::lower::model::OutTy| crate::check::types::union_texts(acc, &ty_params_in(x)))),
        crate::lower::model::OutTy::OutFn(ts, r) => fold(ts, &ty_params_in(&**r), &(|acc: &Array<Text>, x: &crate::lower::model::OutTy| crate::check::types::union_texts(acc, &ty_params_in(x)))),
        crate::lower::model::OutTy::OutJobFn(a, r) => crate::check::types::union_texts(&ty_params_in(&**a), &ty_params_in(&**r)),
        crate::lower::model::OutTy::OutMap(k, v_) => crate::check::types::union_texts(&ty_params_in(&**k), &ty_params_in(&**v_)),
        crate::lower::model::OutTy::OutOpt(x) => ty_params_in(&**x),
        crate::lower::model::OutTy::OutRes(x) => ty_params_in(&**x),
        crate::lower::model::OutTy::OutArray(x) => ty_params_in(&**x),
        crate::lower::model::OutTy::OutJob(x) => ty_params_in(&**x),
        crate::lower::model::OutTy::OutEvent(x) => ty_params_in(&**x),
        crate::lower::model::OutTy::OutDyn(x) => ty_params_in(&**x),
        crate::lower::model::OutTy::OutRc(x) => ty_params_in(&**x),
        crate::lower::model::OutTy::OutRef(x) => ty_params_in(&**x),
        crate::lower::model::OutTy::OutHold(x) => ty_params_in(&**x),
        crate::lower::model::OutTy::OutCell(x) => ty_params_in(&**x),
        crate::lower::model::OutTy::OutLive(x) => ty_params_in(&**x),
        _ => Array::new(),
    }
}

/// ```prism
/// SignatureText: fn Lx, Text -> Text
/// ```
pub fn signature_text(lx: &crate::lower::Lx, qk: &Text) -> Text {
    match get(&lx.g.vals, qk) {
        Some(v_) => match index(&lx.g.srcs, &v_.file) {
            Some(src) => crate::syntax::lexer::chars::trim(&crate::check::errors::span_text(&src, &v_.span)),
            None => crate::check::types::bare_name(qk),
        },
        None => crate::check::types::bare_name(qk),
    }
}

/// ```prism
/// DefinitionText: fn Lx, Text -> Text
/// ```
pub fn definition_text(lx: &crate::lower::Lx, qk: &Text) -> Text {
    let spans = fold(&lx.g.defs, &Array::new(), &(|acc: &Array<(Nat, crate::syntax::Range)>, d: &crate::check::env::Def| if &d.qk == qk { push(acc, &(d.file.clone(), d.span.clone())) } else { acc.clone() }));
    let sig = match get(&lx.g.vals, qk) {
        Some(v_) => if &v_.span.start < &or(&index(&each(&spans, &(|(_, r): &(Nat, crate::syntax::Range)| r.start.clone())), &Nat::from(0u32)), &Nat::from(0u32)) {
            Array::from(vec![(v_.file.clone(), v_.span.clone())])
        } else {
            Array::new()
        },
        None => Array::new(),
    };
    crate::syntax::lexer::chars::join(&each(&append(&sig, &spans), &(|(f, r): &(Nat, crate::syntax::Range)| src_text(lx, f, r))), &Text::lit("\n"))
}

/// ```prism
/// SrcText: fn Lx, Nat, Range -> Text
/// ```
pub fn src_text(lx: &crate::lower::Lx, f: &Nat, r: &crate::syntax::Range) -> Text {
    match index(&lx.g.srcs, f) {
        Some(src) => drop_trailing_comments(&crate::check::errors::span_text(&src, r)),
        None => Text::lit(""),
    }
}

/// ```prism
/// DropTrailingComments: fn Text -> Text
/// ```
pub fn drop_trailing_comments(t: &Text) -> Text {
    let lines = split_on(t, &Text::lit("\n"));
    let keep = fold(&crate::check::errors::range0(&len(&lines)), &Nat::from(0u32), &(|k: &Nat, i: &Nat| if is_code_line(&or(&index(&lines, i), &Text::lit(""))) {
        i + &Nat::from(1u32)
    } else {
        k.clone()
    }));
    crate::syntax::lexer::chars::trim_end(&crate::syntax::lexer::chars::join(&take(&lines, &keep), &Text::lit("\n")))
}

/// ```prism
/// IsCodeLine: fn Text -> Bool
/// ```
pub fn is_code_line(l: &Text) -> bool {
    let s = crate::syntax::lexer::chars::trim(l);
    (&s != &Text::lit("")) && !crate::syntax::lexer::chars::has_prefix(&s, &Text::lit("#"))
}

/// ```prism
/// LetGetter: unbounded fn Lx, Text, LetDecl -> FnDef
/// ```
pub fn let_getter(lx: &crate::lower::Lx, qk: &Text, l: &crate::syntax::decls::LetDecl) -> crate::lower::model::FnDef {
    let t = crate::lower::types::out_ty_of(lx, &crate::lower::types::peel(&crate::lower::type_at(lx, &l.value.span)));
    let v_ = crate::lower::expr::value_of(lx, &crate::lower::types::empty_env(), &l.value);
    crate::lower::model::FnDef { name: or(&get(&lx.rs_names, qk), &crate::lower::snake(&crate::check::types::bare_name(qk))), generics: Array::new(), params: Array::new(), ret: t.clone(), body: crate::lower::types::own(&v_), doc: Text::from(format!("let {}", &crate::check::types::bare_name(qk))), public: true }
}

/// The step machine of `LetGetter`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LetGetter: unbounded fn Lx, Text, LetDecl -> FnDef
/// ```
pub struct LetGetter {
    pub lx: crate::lower::Lx,
    pub qk: Text,
    pub l: crate::syntax::decls::LetDecl,
}

impl prism_rtl::Job<crate::lower::model::FnDef> for LetGetter {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::FnDef> {
        let lx = &self.lx;
        let qk = &self.qk;
        let l = &self.l;
        let l = l.clone();
        let lx = lx.clone();
        let qk = qk.clone();
        call_then(crate::lower::types::start_out_ty_of(lx.clone(), crate::lower::types::peel(&crate::lower::type_at(&lx, &l.value.span))), move |out_ty_of_10073: crate::lower::model::OutTy| {
            let t = out_ty_of_10073;
            call_then(crate::lower::expr::start_value_of(lx.clone(), crate::lower::types::empty_env(), l.value.clone()), move |value_of_10130: crate::lower::types::Vl| {
                let v_ = value_of_10130;
                prism_rtl::Turn::Finished(crate::lower::model::FnDef { name: or(&get(&lx.rs_names, &qk), &crate::lower::snake(&crate::check::types::bare_name(&qk))), generics: Array::new(), params: Array::new(), ret: t.clone(), body: crate::lower::types::own(&v_), doc: Text::from(format!("let {}", &crate::check::types::bare_name(&qk))), public: true })
            })
        })
    }
}

/// `Start LetGetter, x`: what the function value is when passed to `@Run`.
pub fn start_let_getter(lx: crate::lower::Lx, qk: Text, l: crate::syntax::decls::LetDecl) -> Rc<dyn prism_rtl::Job<crate::lower::model::FnDef>> {
    Rc::new(LetGetter { lx, qk, l })
}

/// ```prism
/// HasOwnShow: fn Lx, Text -> Bool
/// ```
pub fn has_own_show(lx: &crate::lower::Lx, tn: &Text) -> bool {
    fold(&or(&get(&lx.g.impls, &Text::lit("Prelude.Show")), &Array::new()), &false, &(|f: &bool, im: &crate::check::env::ImplInfo| *f || (!im.derived && (&head_name(&im.head) == tn))))
}

/// ```prism
/// HeadName: fn Ty -> Text
/// ```
pub fn head_name(ty0: &crate::check::types::Ty) -> Text {
    match ty0 {
        crate::check::types::Ty::TyCon(n, _) => n.clone(),
        other => Text::lit(""),
    }
}

/// ```prism
/// SelfIn: unbounded fn Ty, Text -> Ty
/// ```
pub fn self_in(t: &crate::check::types::Ty, param: &Text) -> crate::check::types::Ty {
    crate::lower::expr::instantiated(t, &Array::from(vec![param.clone()]), &Array::from(vec![crate::check::types::Ty::TyCon(Text::lit("\0Self"), Array::new())]))
}

/// The step machine of `SelfIn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SelfIn: unbounded fn Ty, Text -> Ty
/// ```
pub struct SelfIn {
    pub t: crate::check::types::Ty,
    pub param: Text,
}

impl prism_rtl::Job<crate::check::types::Ty> for SelfIn {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::Ty> {
        let t = &self.t;
        let param = &self.param;
        prism_rtl::Turn::More(Rc::new(crate::lower::expr::Instantiated { t: t.clone(), params: Array::from(vec![param.clone()]), args: Array::from(vec![crate::check::types::Ty::TyCon(Text::lit("\0Self"), Array::new())]) }))
    }
}

/// `Start SelfIn, x`: what the function value is when passed to `@Run`.
pub fn start_self_in(t: crate::check::types::Ty, param: Text) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>> {
    Rc::new(SelfIn { t, param })
}

/// ```prism
/// TraitDefOf: unbounded fn Lx, TraitInfo -> TraitDef
/// ```
pub fn trait_def_of(lx0: &crate::lower::Lx, tr: &crate::check::env::TraitInfo) -> crate::lower::model::TraitDef {
    let lx = crate::lower::program::in_module(lx0, &tr.file, &tr.home);
    let methods = run_to_end(each_job(tr.methods.clone(), {
        let lx = lx.clone();
        let tr = tr.clone();
        Rc::new(move |p0: Text| {
            let lx = lx.clone();
            let tr = tr.clone();
            entered(once_job(move || {
                let mq = p0;
                {
                    let v_ = or(&get(&lx.g.vals, &mq), &crate::check::env::builtin(&mq, &crate::check::types::schemes::mono(&crate::check::types::Ty::TyErr)));
                    let sc = {
                        let mut this: crate::check::types::Scheme = v_.scheme.clone();
                        this.ty = self_in(&this.ty, &tr.param);
                        this.qs = filter(&this.qs, &(|q: &Text| q != &tr.param));
                        this.bounds = filter(&this.bounds, &(|(q, _): &(Text, Text)| q != &tr.param));
                        this
                    };
                    let default_qk = fold(&tr.defaults, &Text::lit(""), &(|f: &Text, dq: &Text| if &crate::check::types::bare_name(dq) == &crate::check::types::bare_name(&mq) {
                        dq.clone()
                    } else {
                        f.clone()
                    }));
                    let clauses = if &default_qk == &Text::lit("") {
                        Array::new()
                    } else {
                        default_clauses(&lx.g, &default_qk)
                    };
                    call_then(start_fn_def_of(lx.clone(), mq.clone(), if &len(&clauses) == &Nat::from(0u32) {
                        Array::from(vec![dummy_clause()])
                    } else {
                        clauses.clone()
                    }, sc.clone()), move |fn_def_of_11667: crate::lower::model::FnDef| {
                        let fd = fn_def_of_11667;
                        prism_rtl::Turn::Finished({
                            let mut this: crate::lower::model::FnDef = fd.clone();
                            this.public = &len(&clauses) > &Nat::from(0u32);
                            this
                        })
                    })
                }
            }))
        }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<crate::lower::model::FnDef>>>
    }));
    crate::lower::model::TraitDef { name: crate::lower::camel(&crate::check::types::bare_name(&tr.name)), methods: methods.clone(), defaults: tr.defaults.clone(), doc: crate::lower::program::type_doc(&lx, &crate::check::env::TyInfo { name: tr.name.clone(), home: tr.home.clone(), params: Array::new(), body: crate::check::env::TyBody::BOpaque, derives: Array::new(), file: tr.file.clone(), span: tr.span.clone() }) }
}

/// The step machine of `TraitDefOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TraitDefOf: unbounded fn Lx, TraitInfo -> TraitDef
/// ```
pub struct TraitDefOf {
    pub lx0: crate::lower::Lx,
    pub tr: crate::check::env::TraitInfo,
}

impl prism_rtl::Job<crate::lower::model::TraitDef> for TraitDefOf {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::TraitDef> {
        let lx0 = &self.lx0;
        let tr = &self.tr;
        let lx = crate::lower::program::in_module(lx0, &tr.file, &tr.home);
        let tr = tr.clone();
        call_value(each_job(tr.methods.clone(), {
            let lx = lx.clone();
            let tr = tr.clone();
            Rc::new(move |p0: Text| {
                let lx = lx.clone();
                let tr = tr.clone();
                entered(once_job(move || {
                    let mq = p0;
                    {
                        let v_ = or(&get(&lx.g.vals, &mq), &crate::check::env::builtin(&mq, &crate::check::types::schemes::mono(&crate::check::types::Ty::TyErr)));
                        let sc = {
                            let mut this: crate::check::types::Scheme = v_.scheme.clone();
                            this.ty = self_in(&this.ty, &tr.param);
                            this.qs = filter(&this.qs, &(|q: &Text| q != &tr.param));
                            this.bounds = filter(&this.bounds, &(|(q, _): &(Text, Text)| q != &tr.param));
                            this
                        };
                        let default_qk = fold(&tr.defaults, &Text::lit(""), &(|f: &Text, dq: &Text| if &crate::check::types::bare_name(dq) == &crate::check::types::bare_name(&mq) {
                            dq.clone()
                        } else {
                            f.clone()
                        }));
                        let clauses = if &default_qk == &Text::lit("") {
                            Array::new()
                        } else {
                            default_clauses(&lx.g, &default_qk)
                        };
                        call_then(start_fn_def_of(lx.clone(), mq.clone(), if &len(&clauses) == &Nat::from(0u32) {
                            Array::from(vec![dummy_clause()])
                        } else {
                            clauses.clone()
                        }, sc.clone()), move |fn_def_of_11667: crate::lower::model::FnDef| {
                            let fd = fn_def_of_11667;
                            prism_rtl::Turn::Finished({
                                let mut this: crate::lower::model::FnDef = fd.clone();
                                this.public = &len(&clauses) > &Nat::from(0u32);
                                this
                            })
                        })
                    }
                }))
            }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<crate::lower::model::FnDef>>>
        }), move |each_11175: Array<crate::lower::model::FnDef>| {
            let methods = each_11175;
            prism_rtl::Turn::Finished(crate::lower::model::TraitDef { name: crate::lower::camel(&crate::check::types::bare_name(&tr.name)), methods: methods.clone(), defaults: tr.defaults.clone(), doc: crate::lower::program::type_doc(&lx, &crate::check::env::TyInfo { name: tr.name.clone(), home: tr.home.clone(), params: Array::new(), body: crate::check::env::TyBody::BOpaque, derives: Array::new(), file: tr.file.clone(), span: tr.span.clone() }) })
        })
    }
}

/// `Start TraitDefOf, x`: what the function value is when passed to `@Run`.
pub fn start_trait_def_of(lx0: crate::lower::Lx, tr: crate::check::env::TraitInfo) -> Rc<dyn prism_rtl::Job<crate::lower::model::TraitDef>> {
    Rc::new(TraitDefOf { lx0, tr })
}

/// ```prism
/// DefaultClauses: fn G, Text -> [FnClause]
/// ```
pub fn default_clauses(g: &crate::check::env::G, qk: &Text) -> Array<crate::syntax::decls::FnClause> {
    fold(&g.defs, &Array::new(), &(|acc: &Array<crate::syntax::decls::FnClause>, d: &crate::check::env::Def| if &d.qk == qk { default_of(d, acc) } else { acc.clone() }))
}

/// ```prism
/// DefaultOf: fn Def, [FnClause] -> [FnClause]
/// ```
pub fn default_of(d: &crate::check::env::Def, other: &Array<crate::syntax::decls::FnClause>) -> Array<crate::syntax::decls::FnClause> {
    match &d.body {
        crate::check::env::DefBody::DbDefault(cs, _) => cs.clone(),
        _ => other.clone(),
    }
}

/// ```prism
/// ImplDefOf: unbounded fn Lx, ImplInfo -> ImplDef
/// ```
pub fn impl_def_of(lx: &crate::lower::Lx, im: &crate::check::env::ImplInfo) -> crate::lower::model::ImplDef {
    let tr = or(&get(&lx.g.traits, &im.cls), &crate::lower::expr::dummy_trait_info());
    let head = crate::lower::types::out_ty_of(lx, &im.head);
    let defs = filter(&lx.g.defs, &(|d: &crate::check::env::Def| is_method_of(d, im)));
    let methods = run_to_end(each_job(defs.clone(), {
        let tr = tr.clone();
        let lx = lx.clone();
        let im = im.clone();
        Rc::new(move |p0: crate::check::env::Def| {
            let tr = tr.clone();
            let lx = lx.clone();
            let im = im.clone();
            entered(once_job(move || {
                let d = p0;
                {
                    let mq = fold(&tr.methods, &Text::lit(""), &(|found: &Text, q: &Text| if &crate::check::types::bare_name(q) == &d.name { q.clone() } else { found.clone() }));
                    let v_ = or(&get(&lx.g.vals, &mq), &crate::check::env::builtin(&mq, &crate::check::types::schemes::mono(&crate::check::types::Ty::TyErr)));
                    let sc = {
                        let mut this: crate::check::types::Scheme = v_.scheme.clone();
                        this.ty = crate::lower::expr::instantiated(&this.ty, &Array::from(vec![tr.param.clone()]), &Array::from(vec![im.head.clone()]));
                        this.qs = filter(&this.qs, &(|q: &Text| q != &tr.param));
                        this.bounds = filter(&this.bounds, &(|(q, _): &(Text, Text)| q != &tr.param));
                        this
                    };
                    call_then(start_fn_def_of(lx.clone(), mq.clone(), method_clauses(&d), sc.clone()), move |fn_def_of_13000: crate::lower::model::FnDef| {
                        let fd = fn_def_of_13000;
                        if crate::syntax::lexer::chars::has_prefix(&im.cls, &Text::lit("Prelude.")) {
                            prism_rtl::Turn::Finished(renamed(&fd, &Text::from(format!("{}_{}", &crate::lower::snake(&d.name), &crate::lower::snake(&crate::check::types::bare_name(&head_name(&im.head)))))))
                        } else {
                            prism_rtl::Turn::Finished(fd.clone())
                        }
                    })
                }
            }))
        }) as Rc<dyn Fn(crate::check::env::Def) -> Rc<dyn prism_rtl::Job<crate::lower::model::FnDef>>>
    }));
    let generics = each(&im.qs, &(|q: &Text| (crate::lower::camel(q), Array::from(vec![Text::lit("Clone")]))));
    crate::lower::model::ImplDef { cls: im.cls.clone(), tr: crate::lower::path_in(lx, &tr.home, &crate::lower::camel(&crate::check::types::bare_name(&im.cls))), head: head.clone(), generics: generics.clone(), methods: methods.clone(), doc: Text::lit("") }
}

/// The step machine of `ImplDefOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ImplDefOf: unbounded fn Lx, ImplInfo -> ImplDef
/// ```
pub struct ImplDefOf {
    pub lx: crate::lower::Lx,
    pub im: crate::check::env::ImplInfo,
}

impl prism_rtl::Job<crate::lower::model::ImplDef> for ImplDefOf {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::ImplDef> {
        let lx = &self.lx;
        let im = &self.im;
        let tr = or(&get(&lx.g.traits, &im.cls), &crate::lower::expr::dummy_trait_info());
        let im = im.clone();
        let lx = lx.clone();
        call_then(crate::lower::types::start_out_ty_of(lx.clone(), im.head.clone()), move |out_ty_of_12493: crate::lower::model::OutTy| {
            let head = out_ty_of_12493;
            let defs = filter(&lx.g.defs, &(|d: &crate::check::env::Def| is_method_of(d, &im)));
            call_value(each_job(defs.clone(), {
                let tr = tr.clone();
                let lx = lx.clone();
                let im = im.clone();
                Rc::new(move |p0: crate::check::env::Def| {
                    let tr = tr.clone();
                    let lx = lx.clone();
                    let im = im.clone();
                    entered(once_job(move || {
                        let d = p0;
                        {
                            let mq = fold(&tr.methods, &Text::lit(""), &(|found: &Text, q: &Text| if &crate::check::types::bare_name(q) == &d.name { q.clone() } else { found.clone() }));
                            let v_ = or(&get(&lx.g.vals, &mq), &crate::check::env::builtin(&mq, &crate::check::types::schemes::mono(&crate::check::types::Ty::TyErr)));
                            let sc = {
                                let mut this: crate::check::types::Scheme = v_.scheme.clone();
                                this.ty = crate::lower::expr::instantiated(&this.ty, &Array::from(vec![tr.param.clone()]), &Array::from(vec![im.head.clone()]));
                                this.qs = filter(&this.qs, &(|q: &Text| q != &tr.param));
                                this.bounds = filter(&this.bounds, &(|(q, _): &(Text, Text)| q != &tr.param));
                                this
                            };
                            call_then(start_fn_def_of(lx.clone(), mq.clone(), method_clauses(&d), sc.clone()), move |fn_def_of_13000: crate::lower::model::FnDef| {
                                let fd = fn_def_of_13000;
                                if crate::syntax::lexer::chars::has_prefix(&im.cls, &Text::lit("Prelude.")) {
                                    prism_rtl::Turn::Finished(renamed(&fd, &Text::from(format!("{}_{}", &crate::lower::snake(&d.name), &crate::lower::snake(&crate::check::types::bare_name(&head_name(&im.head)))))))
                                } else {
                                    prism_rtl::Turn::Finished(fd.clone())
                                }
                            })
                        }
                    }))
                }) as Rc<dyn Fn(crate::check::env::Def) -> Rc<dyn prism_rtl::Job<crate::lower::model::FnDef>>>
            }), move |each_12586: Array<crate::lower::model::FnDef>| {
                let methods = each_12586;
                let generics = each(&im.qs, &(|q: &Text| (crate::lower::camel(q), Array::from(vec![Text::lit("Clone")]))));
                prism_rtl::Turn::Finished(crate::lower::model::ImplDef { cls: im.cls.clone(), tr: crate::lower::path_in(&lx, &tr.home, &crate::lower::camel(&crate::check::types::bare_name(&im.cls))), head: head.clone(), generics: generics.clone(), methods: methods.clone(), doc: Text::lit("") })
            })
        })
    }
}

/// `Start ImplDefOf, x`: what the function value is when passed to `@Run`.
pub fn start_impl_def_of(lx: crate::lower::Lx, im: crate::check::env::ImplInfo) -> Rc<dyn prism_rtl::Job<crate::lower::model::ImplDef>> {
    Rc::new(ImplDefOf { lx, im })
}

/// ```prism
/// Renamed: fn FnDef, Text -> FnDef
/// ```
pub fn renamed(fd: &crate::lower::model::FnDef, n: &Text) -> crate::lower::model::FnDef {
    let mut this: crate::lower::model::FnDef = fd.clone();
    this.name = n.clone();
    this
}

/// ```prism
/// IsMethodOf: fn Def, ImplInfo -> Bool
/// ```
pub fn is_method_of(d: &crate::check::env::Def, im: &crate::check::env::ImplInfo) -> bool {
    match &d.body {
        crate::check::env::DefBody::DbMethod(_, cls, other) => ((cls == &im.cls) && (&other.span == &im.span)) && (&other.file == &im.file),
        _ => false,
    }
}

/// ```prism
/// MethodClauses: fn Def -> [FnClause]
/// ```
pub fn method_clauses(d: &crate::check::env::Def) -> Array<crate::syntax::decls::FnClause> {
    match &d.body {
        crate::check::env::DefBody::DbMethod(cs, _, _) => cs.clone(),
        _ => Array::new(),
    }
}

/// ```prism
/// IfGenLine: unbounded fn Wx, Env, Expr, Block, Block, Expr -> ((Wx, Wres))
/// ```
pub fn if_gen_line(wx: &crate::lower::node_::Wx, menv: &crate::lower::types::Env, c: &crate::syntax::Expr, then_b: &crate::syntax::Block, else_b: &crate::syntax::Block, e: &crate::syntax::Expr) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    let lx = wx.lx.clone();
    let pos = wx.pos.clone();
    let wx1 = {
        let mut this: crate::lower::node_::Wx = wx.clone();
        this.pos = crate::lower::model::next_pos(&this.pos);
        this
    };
    let (name, wx2) = crate::lower::node_::fresh_name(&wx1, &Text::lit("arm"));
    let base = Text::from(format!("{}{}{}", &wx.node_, &crate::lower::camel(&name), &crate::lower::node_::keyed::row_suffix(wx)));
    let yes = crate::lower::node_::switch_::gen_row_of(&wx2, menv, then_b, &crate::lower::model::OutTy::OutUnit, &Text::from(format!("{}Then", &base)), &name);
    let no = crate::lower::node_::switch_::gen_row_of(&yes.parent, menv, else_b, &crate::lower::model::OutTy::OutUnit, &Text::from(format!("{}Else", &base)), &name);
    let cond = crate::lower::types::as_bool(&crate::lower::expr::value_of(&lx, menv, c));
    let tail = append(&append(&Array::from(vec![crate::lower::model::Ex::XWeak(Rc::new(crate::lower::model::Ex::XSelf))]), &crate::lower::node_::keyed::hosted_passed(wx)), &Array::from(vec![crate::lower::model::Ex::XCx]));
    let mk_fn = {
        let tail = tail.clone();
        Rc::new(move |n: &crate::lower::model::NodeDef| crate::lower::model::Ex::XCast(Rc::new(crate::lower::expr::try_of(&crate::lower::model::Ex::XCall(Text::from(format!("{}::build", &n.name)), append(&Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("path")), crate::lower::model::Ex::XVar(Text::lit("value"))]), &tail)))), crate::lower::model::OutTy::OutObj(Rc::new(crate::lower::model::OutTy::OutNamed(Text::lit("Row"), Array::new())))))
    };
    let select = crate::lower::model::Ex::XIf(Rc::new(cond.clone()), Rc::new((&mk_fn)(&yes.node_)), Rc::new((&mk_fn)(&no.node_)));
    let wx3 = {
        let mut this: crate::lower::node_::Wx = no.parent.clone();
        this.gens = push(&this.gens, &crate::lower::model::GenDef { name: name.clone(), pos: pos.clone(), at: crate::lower::node_::finish::place_at(wx, &Text::lit("self"), &pos), source: crate::lower::model::Ex::XUnit, value_ty: crate::lower::model::OutTy::OutUnit, select: select.clone(), transparent: false, width: Nat::from(0u32), moved: or(&crate::lower::node_::finish::hosted_rows(wx), &Text::lit("")) });
        this.gen_holds = push(&this.gen_holds, &(name.clone(), Array::new()));
        this.rows = append(&append(&append(&push(&this.rows, &yes.node_), &yes.node_.children), &Array::from(vec![no.node_.clone()])), &no.node_.children);
        this.getters = push(&this.getters, &crate::lower::model::MethDef { name: Text::from(format!("{}_up", &name)), recv: crate::lower::model::Recv::RecvRc, params: Array::from(vec![(Text::lit("v"), crate::lower::model::OutTy::OutUnit)]), cx_: crate::lower::model::CxArg::CxMut, ret: crate::lower::model::OutTy::OutUnit, body: Array::new(), tail: crate::lower::model::Ex::XUnit, doc: Text::lit("An arm\'s result, which a building `if` of widgets drops.") });
        this
    };
    (wx3.clone(), crate::lower::node_::Wres::WrUnit)
}

/// The step machine of `IfGenLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// IfGenLine: unbounded fn Wx, Env, Expr, Block, Block, Expr -> ((Wx, Wres))
/// ```
pub struct IfGenLine {
    pub wx: crate::lower::node_::Wx,
    pub menv: crate::lower::types::Env,
    pub c: crate::syntax::Expr,
    pub then_b: crate::syntax::Block,
    pub else_b: crate::syntax::Block,
    pub e: crate::syntax::Expr,
}

impl prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::node_::Wres)> for IfGenLine {
    fn cycle(&self) -> prism_rtl::Turn<(crate::lower::node_::Wx, crate::lower::node_::Wres)> {
        let wx = &self.wx;
        let menv = &self.menv;
        let c = &self.c;
        let then_b = &self.then_b;
        let else_b = &self.else_b;
        let e = &self.e;
        let lx = wx.lx.clone();
        let pos = wx.pos.clone();
        let wx1 = {
            let mut this: crate::lower::node_::Wx = wx.clone();
            this.pos = crate::lower::model::next_pos(&this.pos);
            this
        };
        let (name, wx2) = crate::lower::node_::fresh_name(&wx1, &Text::lit("arm"));
        let base = Text::from(format!("{}{}{}", &wx.node_, &crate::lower::camel(&name), &crate::lower::node_::keyed::row_suffix(wx)));
        let yes = crate::lower::node_::switch_::gen_row_of(&wx2, menv, then_b, &crate::lower::model::OutTy::OutUnit, &Text::from(format!("{}Then", &base)), &name);
        let no = crate::lower::node_::switch_::gen_row_of(&yes.parent, menv, else_b, &crate::lower::model::OutTy::OutUnit, &Text::from(format!("{}Else", &base)), &name);
        let c = c.clone();
        let menv = menv.clone();
        let wx = wx.clone();
        call_then(crate::lower::expr::start_value_of(lx.clone(), menv.clone(), c.clone()), move |value_of_14466: crate::lower::types::Vl| {
            let cond = crate::lower::types::as_bool(&value_of_14466);
            let tail = append(&append(&Array::from(vec![crate::lower::model::Ex::XWeak(Rc::new(crate::lower::model::Ex::XSelf))]), &crate::lower::node_::keyed::hosted_passed(&wx)), &Array::from(vec![crate::lower::model::Ex::XCx]));
            let mk_fn = {
                let tail = tail.clone();
                Rc::new(move |n: &crate::lower::model::NodeDef| crate::lower::model::Ex::XCast(Rc::new(crate::lower::expr::try_of(&crate::lower::model::Ex::XCall(Text::from(format!("{}::build", &n.name)), append(&Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("path")), crate::lower::model::Ex::XVar(Text::lit("value"))]), &tail)))), crate::lower::model::OutTy::OutObj(Rc::new(crate::lower::model::OutTy::OutNamed(Text::lit("Row"), Array::new())))))
            };
            let select = crate::lower::model::Ex::XIf(Rc::new(cond.clone()), Rc::new((&mk_fn)(&yes.node_)), Rc::new((&mk_fn)(&no.node_)));
            let wx3 = {
                let mut this: crate::lower::node_::Wx = no.parent.clone();
                this.gens = push(&this.gens, &crate::lower::model::GenDef { name: name.clone(), pos: pos.clone(), at: crate::lower::node_::finish::place_at(&wx, &Text::lit("self"), &pos), source: crate::lower::model::Ex::XUnit, value_ty: crate::lower::model::OutTy::OutUnit, select: select.clone(), transparent: false, width: Nat::from(0u32), moved: or(&crate::lower::node_::finish::hosted_rows(&wx), &Text::lit("")) });
                this.gen_holds = push(&this.gen_holds, &(name.clone(), Array::new()));
                this.rows = append(&append(&append(&push(&this.rows, &yes.node_), &yes.node_.children), &Array::from(vec![no.node_.clone()])), &no.node_.children);
                this.getters = push(&this.getters, &crate::lower::model::MethDef { name: Text::from(format!("{}_up", &name)), recv: crate::lower::model::Recv::RecvRc, params: Array::from(vec![(Text::lit("v"), crate::lower::model::OutTy::OutUnit)]), cx_: crate::lower::model::CxArg::CxMut, ret: crate::lower::model::OutTy::OutUnit, body: Array::new(), tail: crate::lower::model::Ex::XUnit, doc: Text::lit("An arm\'s result, which a building `if` of widgets drops.") });
                this
            };
            prism_rtl::Turn::Finished((wx3.clone(), crate::lower::node_::Wres::WrUnit))
        })
    }
}

/// `Start IfGenLine, x`: what the function value is when passed to `@Run`.
pub fn start_if_gen_line(wx: crate::lower::node_::Wx, menv: crate::lower::types::Env, c: crate::syntax::Expr, then_b: crate::syntax::Block, else_b: crate::syntax::Block, e: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::node_::Wres)>> {
    Rc::new(IfGenLine { wx, menv, c, then_b, else_b, e })
}
