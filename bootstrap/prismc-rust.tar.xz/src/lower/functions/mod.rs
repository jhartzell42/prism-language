//! The module `Lower.Functions`, from `target/bootstrap/src/prismc/lower/functions.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// ```prism
/// BoundOf: fn Lx, Text -> [Text]
/// ```
pub fn bound_of(lx_p0: &crate::lower::Lx, text1: &Text) -> Array<Text> {
    match text1 {
        c0_1 if (c0_1 == &Text::lit("Prelude.Eq")) => Array::from(vec![Text::lit("Eq")]),
        c1_1 if (c1_1 == &Text::lit("Prelude.Ord")) => Array::from(vec![Text::lit("Ord")]),
        c2_1 if (c2_1 == &Text::lit("Prelude.Show")) => Array::from(vec![Text::lit("Show")]),
        c3_1 if (c3_1 == &Text::lit("Prelude.Num")) => Array::from(vec![Text::lit("Num")]),
        c4_1 if (c4_1 == &Text::lit("Prelude.Pod")) => Array::from(vec![Text::lit("ToPod"), Text::lit("FromPod")]),
        cls_p6 => match get(&lx_p0.g.traits, cls_p6) {
            Some(tr_p7) => Array::from(vec![crate::lower::path_in(lx_p0, &tr_p7.home, &crate::lower::camel(&crate::check::types::bare_name(cls_p6)))]),
            None => Array::new(),
        },
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// SchemeGenerics: fn Lx, Scheme -> [((Text, [Text]))]
/// ```
pub fn scheme_generics(lx_p0: &crate::lower::Lx, sc_p1: &crate::check::types::Scheme) -> Array<(Text, Array<Text>)> {
    each(&sc_p1.qs, &(|q_p2: &Text| {
        let bs_p3 = fold(&sc_p1.bounds, &Array::from(vec![Text::lit("Clone")]), &(|acc_p5: &Array<Text>, (v_p6, cls_p7): &(Text, Text)| if v_p6 == q_p2 {
            crate::check::types::union_texts(acc_p5, &bound_of(lx_p0, cls_p7))
        } else {
            acc_p5.clone()
        }));
        let keyed_p4 = if keys_by(&sc_p1.ty, q_p2) {
            crate::check::types::union_texts(&bs_p3, &Array::from(vec![Text::lit("Ord")]))
        } else {
            bs_p3.clone()
        };
        (crate::lower::camel(q_p2), keyed_p4.clone())
    }))
}

/// ```prism
/// KeysBy: fn Ty, Text -> Bool
/// ```
pub fn keys_by(t_p0: &crate::check::types::Ty, q_p1: &Text) -> bool {
    match t_p0 {
        crate::check::types::Ty::TyMap(k_p2, v_p3) => ((&**k_p2 == &crate::check::types::Ty::TyQ(q_p1.clone())) || keys_by(&**k_p2, q_p1)) || keys_by(&**v_p3, q_p1),
        crate::check::types::Ty::TyCon(_, ts_p4) => fold(ts_p4, &false, &(|found_p5: &bool, x_p6: &crate::check::types::Ty| *found_p5 || keys_by(x_p6, q_p1))),
        crate::check::types::Ty::TyFn(_, ps_p7, r_p8) => fold(ps_p7, &false, &(|found_p9: &bool, x_pa: &crate::check::types::Ty| *found_p9 || keys_by(x_pa, q_p1))) || keys_by(&**r_p8, q_p1),
        crate::check::types::Ty::TyTuple(ts_pb) => fold(ts_pb, &false, &(|found_pc: &bool, x_pd: &crate::check::types::Ty| *found_pc || keys_by(x_pd, q_p1))),
        crate::check::types::Ty::TyArray(x_pe) => keys_by(&**x_pe, q_p1),
        crate::check::types::Ty::TySig(_, x_pf) => keys_by(&**x_pf, q_p1),
        crate::check::types::Ty::TyAt(x_pg, _) => keys_by(&**x_pg, q_p1),
        _ => false,
    }
}

/// ```prism
/// ParamNames: unbounded fn Lx, [FnClause], [OutTy] -> [((Text, Bool))]
/// ```
pub fn param_names(lx_p0: &crate::lower::Lx, clauses_p1: &Array<crate::syntax::decls::FnClause>, pts_p2: &Array<crate::lower::model::OutTy>) -> Array<(Text, bool)> {
    run_to_end(each_job(crate::check::errors::range0(&len(pts_p2)), {
        let clauses_p1 = clauses_p1.clone();
        let lx_p0 = lx_p0.clone();
        let pts_p2 = pts_p2.clone();
        Rc::new(move |p0: Nat| {
            let clauses_p1 = clauses_p1.clone();
            let lx_p0 = lx_p0.clone();
            let pts_p2 = pts_p2.clone();
            entered(once_job(move || {
                let i_p3 = p0;
                {
                    let names_p4 = each(&clauses_p1, &(|c_p8: &crate::syntax::decls::FnClause| plain_binder(&lx_p0, &or(&index(&c_p8.params, &i_p3), &crate::lower::patterns::dummy_pat()))));
                    let first_p5 = or(&index(&names_p4, &Nat::from(0u32)), &Text::lit(""));
                    let same_p6 = (&first_p5 != &Text::lit("")) && fold(&names_p4, &true, &(|ok_p9: &bool, n_pa: &Text| *ok_p9 && (n_pa == &first_p5)));
                    let span_p7 = match &*or(&index(&or(&index(&clauses_p1, &Nat::from(0u32)), &dummy_clause()).params, &i_p3), &crate::lower::patterns::dummy_pat()).kind {
                        crate::syntax::PatternKind::PName(n_pb) => n_pb.span.clone(),
                        _ => crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) },
                    };
                    if same_p6 {
                        call_then(crate::lower::start_local_name_at(lx_p0.clone(), first_p5.clone(), span_p7.clone()), move |local_name_at_3553: Text| prism_rtl::Turn::Finished((local_name_at_3553, false)))
                    } else {
                        prism_rtl::Turn::Finished((param_word(&or(&index(&pts_p2, &i_p3), &crate::lower::model::OutTy::OutUnit), &i_p3), true))
                    }
                }
            }))
        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<(Text, bool)>>>
    }))
}

/// The step machine of `ParamNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParamNames: unbounded fn Lx, [FnClause], [OutTy] -> [((Text, Bool))]
/// ```
pub struct ParamNames {
    pub lx_p0: crate::lower::Lx,
    pub clauses_p1: Array<crate::syntax::decls::FnClause>,
    pub pts_p2: Array<crate::lower::model::OutTy>,
}

impl prism_rtl::Job<Array<(Text, bool)>> for ParamNames {
    fn cycle(&self) -> prism_rtl::Turn<Array<(Text, bool)>> {
        let lx_p0 = &self.lx_p0;
        let clauses_p1 = &self.clauses_p1;
        let pts_p2 = &self.pts_p2;
        each_job(crate::check::errors::range0(&len(pts_p2)), {
            let clauses_p1 = clauses_p1.clone();
            let lx_p0 = lx_p0.clone();
            let pts_p2 = pts_p2.clone();
            Rc::new(move |p0: Nat| {
                let clauses_p1 = clauses_p1.clone();
                let lx_p0 = lx_p0.clone();
                let pts_p2 = pts_p2.clone();
                entered(once_job(move || {
                    let i_p3 = p0;
                    {
                        let names_p4 = each(&clauses_p1, &(|c_p8: &crate::syntax::decls::FnClause| plain_binder(&lx_p0, &or(&index(&c_p8.params, &i_p3), &crate::lower::patterns::dummy_pat()))));
                        let first_p5 = or(&index(&names_p4, &Nat::from(0u32)), &Text::lit(""));
                        let same_p6 = (&first_p5 != &Text::lit("")) && fold(&names_p4, &true, &(|ok_p9: &bool, n_pa: &Text| *ok_p9 && (n_pa == &first_p5)));
                        let span_p7 = match &*or(&index(&or(&index(&clauses_p1, &Nat::from(0u32)), &dummy_clause()).params, &i_p3), &crate::lower::patterns::dummy_pat()).kind {
                            crate::syntax::PatternKind::PName(n_pb) => n_pb.span.clone(),
                            _ => crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) },
                        };
                        if same_p6 {
                            call_then(crate::lower::start_local_name_at(lx_p0.clone(), first_p5.clone(), span_p7.clone()), move |local_name_at_3553: Text| prism_rtl::Turn::Finished((local_name_at_3553, false)))
                        } else {
                            prism_rtl::Turn::Finished((param_word(&or(&index(&pts_p2, &i_p3), &crate::lower::model::OutTy::OutUnit), &i_p3), true))
                        }
                    }
                }))
            }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<(Text, bool)>>>
        }).cycle()
    }
}

/// `Start ParamNames, x`: what the function value is when passed to `@Run`.
pub fn start_param_names(lx_p0: crate::lower::Lx, clauses_p1: Array<crate::syntax::decls::FnClause>, pts_p2: Array<crate::lower::model::OutTy>) -> Rc<dyn prism_rtl::Job<Array<(Text, bool)>>> {
    Rc::new(ParamNames { lx_p0, clauses_p1, pts_p2 })
}

/// ```prism
/// PlainBinder: fn Lx, Pattern -> Text
/// ```
pub fn plain_binder(lx_p0: &crate::lower::Lx, p_p1: &crate::syntax::Pattern_) -> Text {
    match &*p_p1.kind {
        crate::syntax::PatternKind::PName(n_p2) => {
            let (qk_o4, why_p5) = crate::check::env::names::resolve_value(&lx_p0.g, &lx_p0.home, n_p2);
            let is_ctor_p3 = match &qk_o4 {
                Some(qk_p6) => crate::check::env::has_key(&lx_p0.g.ctors, qk_p6) && (crate::check::env::is_upper_text(&crate::lower::base(&crate::check::env::sname_key(n_p2))) || crate::lower::patterns::is_unit_ctor(lx_p0, qk_p6)),
                None => false,
            };
            if is_ctor_p3 { Text::lit("") } else { crate::check::env::sname_key(n_p2) }
        },
        crate::syntax::PatternKind::PGroup(q_p7) => plain_binder(lx_p0, &**q_p7),
        _ => Text::lit(""),
    }
}

/// ```prism
/// ParamWord: fn OutTy, Nat -> Text
/// ```
pub fn param_word(t_p0: &crate::lower::model::OutTy, i_p1: &Nat) -> Text {
    let base_p2 = match t_p0 {
        crate::lower::model::OutTy::OutNamed(n_p3, _) => crate::lower::snake(&or(&crate::syntax::lexer::chars::last(&split_on(n_p3, &Text::lit("::"))), &Text::lit("arg"))),
        crate::lower::model::OutTy::OutText => Text::lit("text"),
        crate::lower::model::OutTy::OutNat => Text::lit("n"),
        crate::lower::model::OutTy::OutInt => Text::lit("i"),
        crate::lower::model::OutTy::OutArray(_) => Text::lit("xs"),
        crate::lower::model::OutTy::OutMap(_, _) => Text::lit("map"),
        crate::lower::model::OutTy::OutOpt(_) => Text::lit("opt"),
        _ => Text::lit("arg"),
    };
    Text::from(format!("{}{}", &base_p2, i_p1))
}

/// ```prism
/// ClausesBody: unbounded fn Lx, Env, [FnClause], [((Text, Bool))], [Ty], (fn Lx, Env, FnBody -> Ex), Text, OutTy -> Ex
/// ```
pub fn clauses_body(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, clauses_p2: &Array<crate::syntax::decls::FnClause>, names_p3: &Array<(Text, bool)>, ptys_p4: &Array<crate::check::types::Ty>, body_f5: &Rc<dyn Fn((crate::lower::Lx, crate::lower::types::Env, crate::syntax::decls::FnBody)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>, label_p6: &Text, t_p7: &crate::lower::model::OutTy) -> crate::lower::model::Ex {
    let env1_p8 = run_to_end(fold_job(crate::check::errors::range0(&len(names_p3)), env_p1.clone(), {
        let names_p3 = names_p3.clone();
        let lx_p0 = lx_p0.clone();
        let clauses_p2 = clauses_p2.clone();
        let ptys_p4 = ptys_p4.clone();
        Rc::new(move |(p0, p1): (crate::lower::types::Env, Nat)| {
            let names_p3 = names_p3.clone();
            let lx_p0 = lx_p0.clone();
            let clauses_p2 = clauses_p2.clone();
            let ptys_p4 = ptys_p4.clone();
            entered(once_job(move || {
                let en_pa = p0;
                let i_pb = p1;
                {
                    let (rs_pc, matched_pd) = or(&index(&names_p3, &i_pb), &(Text::lit(""), true));
                    if matched_pd {
                        prism_rtl::Turn::Finished(en_pa.clone())
                    } else {
                        call_then(crate::lower::types::start_out_ty_of(lx_p0.clone(), crate::lower::types::peel(&or(&index(&ptys_p4, &i_pb), &crate::check::types::Ty::TyErr))), move |out_ty_of_5056: crate::lower::model::OutTy| prism_rtl::Turn::Finished(crate::lower::types::bind(&en_pa, &plain_binder(&lx_p0, &or(&index(&or(&index(&clauses_p2, &Nat::from(0u32)), &dummy_clause()).params, &i_pb), &crate::lower::patterns::dummy_pat())), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(rs_pc.clone()), crate::lower::types::Holding::ByRef, out_ty_of_5056))))
                    }
                }
            }))
        }) as Rc<dyn Fn((crate::lower::types::Env, Nat)) -> Rc<dyn prism_rtl::Job<crate::lower::types::Env>>>
    }));
    let scrut_ix_p9 = filter(&crate::check::errors::range0(&len(names_p3)), &(|i_pe: &Nat| match index(names_p3, i_pe) {
        Some((_, true)) => true,
        _ => false,
    }));
    if &len(&scrut_ix_p9) == &Nat::from(0u32) {
        {
            let c_pf = or(&index(clauses_p2, &Nat::from(0u32)), &dummy_clause());
            run_to_end(body_f5((lx_p0.clone(), env1_p8.clone(), c_pf.body.clone())))
        }
    } else {
        {
            let scrut_pg = 'm5353: {
                if let m5353_0 = &scrut_ix_p9 && (m5353_0.len() == 1) && let Some(i_pi) = index(m5353_0, &Nat::from(0u32)) {
                    break 'm5353 crate::lower::model::Ex::XVar(or(&index(&each(names_p3, &(|(n_pj, _): &(Text, bool)| n_pj.clone())), &i_pi), &Text::lit("arg")));
                }
                crate::lower::model::Ex::XTuple(each(&scrut_ix_p9, &(|i_pk: &Nat| crate::lower::model::Ex::XVar(or(&index(&each(names_p3, &(|(n_pl, _): &(Text, bool)| n_pl.clone())), i_pk), &Text::lit("arg"))))))
            };
            let arms_ph = run_to_end(each_job(crate::check::errors::range0(&len(clauses_p2)), {
                let clauses_p2 = clauses_p2.clone();
                let scrut_ix_p9 = scrut_ix_p9.clone();
                let lx_p0 = lx_p0.clone();
                let ptys_p4 = ptys_p4.clone();
                let label_p6 = label_p6.clone();
                let body_f5 = body_f5.clone();
                let env1_p8 = env1_p8.clone();
                Rc::new(move |p0: Nat| {
                    let clauses_p2 = clauses_p2.clone();
                    let scrut_ix_p9 = scrut_ix_p9.clone();
                    let lx_p0 = lx_p0.clone();
                    let ptys_p4 = ptys_p4.clone();
                    let label_p6 = label_p6.clone();
                    let body_f5 = body_f5.clone();
                    let env1_p8 = env1_p8.clone();
                    entered(once_job(move || {
                        let ci_pm = p0;
                        {
                            let c_pn = or(&index(&clauses_p2, &ci_pm), &dummy_clause());
                            call_value(each_job(scrut_ix_p9.clone(), {
                                let lx_p0 = lx_p0.clone();
                                let c_pn = c_pn.clone();
                                let ptys_p4 = ptys_p4.clone();
                                let label_p6 = label_p6.clone();
                                let ci_pm = ci_pm.clone();
                                Rc::new(move |p0: Nat| {
                                    let lx_p0 = lx_p0.clone();
                                    let c_pn = c_pn.clone();
                                    let ptys_p4 = ptys_p4.clone();
                                    let label_p6 = label_p6.clone();
                                    let ci_pm = ci_pm.clone();
                                    entered(once_job(move || {
                                        let i_ps = p0;
                                        prism_rtl::Turn::More(Rc::new(crate::lower::patterns::RustPat { lx_p0: lx_p0.clone(), p_p1: or(&index(&c_pn.params, &i_ps), &crate::lower::patterns::dummy_pat()), ty_p2: or(&index(&ptys_p4, &i_ps), &crate::check::types::Ty::TyErr), mode_p3: crate::lower::types::Holding::ByRef, fresh_p4: Text::from(format!("{}{}_{}", &label_p6, &ci_pm, &i_ps)) }))
                                    }))
                                }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<crate::lower::patterns::PatOut>>>
                            }), move |each_5668: Array<crate::lower::patterns::PatOut>| {
                                let pos_po = each_5668;
                                let pa_pp = 'm5794: {
                                    if let m5794_0 = &pos_po && (m5794_0.len() == 1) && let Some(o_pt) = index(m5794_0, &Nat::from(0u32)) {
                                        break 'm5794 o_pt.pa.clone();
                                    }
                                    crate::lower::model::Pa::PaTuple(each(&pos_po, &(|o_pu: &crate::lower::patterns::PatOut| o_pu.pa.clone())))
                                };
                                let conds_pq = fold(&pos_po, &Array::new(), &(|acc_pv: &Array<crate::lower::model::Cc>, o_p10: &crate::lower::patterns::PatOut| append(acc_pv, &o_p10.conds)));
                                let binds_pr = fold(&pos_po, &Array::new(), &(|acc_p11: &Array<(Text, crate::lower::types::Bn)>, o_p12: &crate::lower::patterns::PatOut| append(acc_p11, &o_p12.binds)));
                                call_value((&body_f5)((lx_p0.clone(), crate::lower::expr::bind_all(&env1_p8, &binds_pr), c_pn.body.clone())), move |body_6074: crate::lower::model::Ex| prism_rtl::Turn::Finished(crate::lower::model::XArm { pat: pa_pp.clone(), conds: conds_pq.clone(), body: body_6074 }))
                            })
                        }
                    }))
                }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<crate::lower::model::XArm>>>
            }));
            crate::lower::types::own(&crate::lower::expr::arms_value(&scrut_pg, &arms_ph, &Text::from(format!("\'{}", label_p6)), t_p7))
        }
    }
}

/// The step machine of `ClausesBody`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ClausesBody: unbounded fn Lx, Env, [FnClause], [((Text, Bool))], [Ty], (fn Lx, Env, FnBody -> Ex), Text, OutTy -> Ex
/// ```
pub struct ClausesBody {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub clauses_p2: Array<crate::syntax::decls::FnClause>,
    pub names_p3: Array<(Text, bool)>,
    pub ptys_p4: Array<crate::check::types::Ty>,
    pub body_f5: Rc<dyn Fn((crate::lower::Lx, crate::lower::types::Env, crate::syntax::decls::FnBody)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>,
    pub label_p6: Text,
    pub t_p7: crate::lower::model::OutTy,
}

impl prism_rtl::Job<crate::lower::model::Ex> for ClausesBody {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::Ex> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let clauses_p2 = &self.clauses_p2;
        let names_p3 = &self.names_p3;
        let ptys_p4 = &self.ptys_p4;
        let body_f5 = &self.body_f5;
        let label_p6 = &self.label_p6;
        let t_p7 = &self.t_p7;
        let body_f5 = body_f5.clone();
        let clauses_p2 = clauses_p2.clone();
        let env_p1 = env_p1.clone();
        let label_p6 = label_p6.clone();
        let lx_p0 = lx_p0.clone();
        let names_p3 = names_p3.clone();
        let ptys_p4 = ptys_p4.clone();
        let t_p7 = t_p7.clone();
        call_value(fold_job(crate::check::errors::range0(&len(&names_p3)), env_p1.clone(), {
            let names_p3 = names_p3.clone();
            let lx_p0 = lx_p0.clone();
            let clauses_p2 = clauses_p2.clone();
            let ptys_p4 = ptys_p4.clone();
            Rc::new(move |(p0, p1): (crate::lower::types::Env, Nat)| {
                let names_p3 = names_p3.clone();
                let lx_p0 = lx_p0.clone();
                let clauses_p2 = clauses_p2.clone();
                let ptys_p4 = ptys_p4.clone();
                entered(once_job(move || {
                    let en_pa = p0;
                    let i_pb = p1;
                    {
                        let (rs_pc, matched_pd) = or(&index(&names_p3, &i_pb), &(Text::lit(""), true));
                        if matched_pd {
                            prism_rtl::Turn::Finished(en_pa.clone())
                        } else {
                            call_then(crate::lower::types::start_out_ty_of(lx_p0.clone(), crate::lower::types::peel(&or(&index(&ptys_p4, &i_pb), &crate::check::types::Ty::TyErr))), move |out_ty_of_5056: crate::lower::model::OutTy| prism_rtl::Turn::Finished(crate::lower::types::bind(&en_pa, &plain_binder(&lx_p0, &or(&index(&or(&index(&clauses_p2, &Nat::from(0u32)), &dummy_clause()).params, &i_pb), &crate::lower::patterns::dummy_pat())), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(rs_pc.clone()), crate::lower::types::Holding::ByRef, out_ty_of_5056))))
                        }
                    }
                }))
            }) as Rc<dyn Fn((crate::lower::types::Env, Nat)) -> Rc<dyn prism_rtl::Job<crate::lower::types::Env>>>
        }), move |fold_4812: crate::lower::types::Env| {
            let env1_p8 = fold_4812;
            let scrut_ix_p9 = filter(&crate::check::errors::range0(&len(&names_p3)), &(|i_pe: &Nat| match index(&names_p3, i_pe) {
                Some((_, true)) => true,
                _ => false,
            }));
            if &len(&scrut_ix_p9) == &Nat::from(0u32) {
                {
                    let c_pf = or(&index(&clauses_p2, &Nat::from(0u32)), &dummy_clause());
                    (&body_f5)((lx_p0.clone(), env1_p8.clone(), c_pf.body.clone())).cycle()
                }
            } else {
                {
                    let scrut_pg = 'm5353: {
                        if let m5353_0 = &scrut_ix_p9 && (m5353_0.len() == 1) && let Some(i_pi) = index(m5353_0, &Nat::from(0u32)) {
                            break 'm5353 crate::lower::model::Ex::XVar(or(&index(&each(&names_p3, &(|(n_pj, _): &(Text, bool)| n_pj.clone())), &i_pi), &Text::lit("arg")));
                        }
                        crate::lower::model::Ex::XTuple(each(&scrut_ix_p9, &(|i_pk: &Nat| crate::lower::model::Ex::XVar(or(&index(&each(&names_p3, &(|(n_pl, _): &(Text, bool)| n_pl.clone())), i_pk), &Text::lit("arg"))))))
                    };
                    call_value(each_job(crate::check::errors::range0(&len(&clauses_p2)), {
                        let clauses_p2 = clauses_p2.clone();
                        let scrut_ix_p9 = scrut_ix_p9.clone();
                        let lx_p0 = lx_p0.clone();
                        let ptys_p4 = ptys_p4.clone();
                        let label_p6 = label_p6.clone();
                        let body_f5 = body_f5.clone();
                        let env1_p8 = env1_p8.clone();
                        Rc::new(move |p0: Nat| {
                            let clauses_p2 = clauses_p2.clone();
                            let scrut_ix_p9 = scrut_ix_p9.clone();
                            let lx_p0 = lx_p0.clone();
                            let ptys_p4 = ptys_p4.clone();
                            let label_p6 = label_p6.clone();
                            let body_f5 = body_f5.clone();
                            let env1_p8 = env1_p8.clone();
                            entered(once_job(move || {
                                let ci_pm = p0;
                                {
                                    let c_pn = or(&index(&clauses_p2, &ci_pm), &dummy_clause());
                                    call_value(each_job(scrut_ix_p9.clone(), {
                                        let lx_p0 = lx_p0.clone();
                                        let c_pn = c_pn.clone();
                                        let ptys_p4 = ptys_p4.clone();
                                        let label_p6 = label_p6.clone();
                                        let ci_pm = ci_pm.clone();
                                        Rc::new(move |p0: Nat| {
                                            let lx_p0 = lx_p0.clone();
                                            let c_pn = c_pn.clone();
                                            let ptys_p4 = ptys_p4.clone();
                                            let label_p6 = label_p6.clone();
                                            let ci_pm = ci_pm.clone();
                                            entered(once_job(move || {
                                                let i_ps = p0;
                                                prism_rtl::Turn::More(Rc::new(crate::lower::patterns::RustPat { lx_p0: lx_p0.clone(), p_p1: or(&index(&c_pn.params, &i_ps), &crate::lower::patterns::dummy_pat()), ty_p2: or(&index(&ptys_p4, &i_ps), &crate::check::types::Ty::TyErr), mode_p3: crate::lower::types::Holding::ByRef, fresh_p4: Text::from(format!("{}{}_{}", &label_p6, &ci_pm, &i_ps)) }))
                                            }))
                                        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<crate::lower::patterns::PatOut>>>
                                    }), move |each_5668: Array<crate::lower::patterns::PatOut>| {
                                        let pos_po = each_5668;
                                        let pa_pp = 'm5794: {
                                            if let m5794_0 = &pos_po && (m5794_0.len() == 1) && let Some(o_pt) = index(m5794_0, &Nat::from(0u32)) {
                                                break 'm5794 o_pt.pa.clone();
                                            }
                                            crate::lower::model::Pa::PaTuple(each(&pos_po, &(|o_pu: &crate::lower::patterns::PatOut| o_pu.pa.clone())))
                                        };
                                        let conds_pq = fold(&pos_po, &Array::new(), &(|acc_pv: &Array<crate::lower::model::Cc>, o_p10: &crate::lower::patterns::PatOut| append(acc_pv, &o_p10.conds)));
                                        let binds_pr = fold(&pos_po, &Array::new(), &(|acc_p11: &Array<(Text, crate::lower::types::Bn)>, o_p12: &crate::lower::patterns::PatOut| append(acc_p11, &o_p12.binds)));
                                        call_value((&body_f5)((lx_p0.clone(), crate::lower::expr::bind_all(&env1_p8, &binds_pr), c_pn.body.clone())), move |body_6074: crate::lower::model::Ex| prism_rtl::Turn::Finished(crate::lower::model::XArm { pat: pa_pp.clone(), conds: conds_pq.clone(), body: body_6074 }))
                                    })
                                }
                            }))
                        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<crate::lower::model::XArm>>>
                    }), move |each_5563: Array<crate::lower::model::XArm>| {
                        let arms_ph = each_5563;
                        prism_rtl::Turn::Finished(crate::lower::types::own(&crate::lower::expr::arms_value(&scrut_pg, &arms_ph, &Text::from(format!("\'{}", &label_p6)), &t_p7)))
                    })
                }
            }
        })
    }
}

/// `Start ClausesBody, x`: what the function value is when passed to `@Run`.
pub fn start_clauses_body(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, clauses_p2: Array<crate::syntax::decls::FnClause>, names_p3: Array<(Text, bool)>, ptys_p4: Array<crate::check::types::Ty>, body_f5: Rc<dyn Fn((crate::lower::Lx, crate::lower::types::Env, crate::syntax::decls::FnBody)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>, label_p6: Text, t_p7: crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>> {
    Rc::new(ClausesBody { lx_p0, env_p1, clauses_p2, names_p3, ptys_p4, body_f5, label_p6, t_p7 })
}

/// ```prism
/// let dummyClause
/// ```
pub fn dummy_clause() -> crate::syntax::decls::FnClause {
    crate::syntax::decls::FnClause { name: crate::syntax::decls::DefName::DefOp(Text::lit(""), crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) }), params: Array::new(), body: crate::syntax::decls::FnBody::BodyExpr(crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EError), span: crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) } }), span: crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) } }
}

/// ```prism
/// FnBodyValue: unbounded fn Lx, Env, FnBody -> Ex
/// ```
pub fn fn_body_value(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, fn_body2: &crate::syntax::decls::FnBody) -> crate::lower::model::Ex {
    match fn_body2 {
        crate::syntax::decls::FnBody::BodyExpr(x_p2) => crate::lower::types::own(&crate::lower::expr::value_of(lx_p0, env_p1, x_p2)),
        crate::syntax::decls::FnBody::BodyBlock(b_p5) => crate::lower::types::own(&crate::lower::expr::block_value(lx_p0, env_p1, b_p5)),
    }
}

/// The step machine of `FnBodyValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FnBodyValue: unbounded fn Lx, Env, FnBody -> Ex
/// ```
pub struct FnBodyValue {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub fn_body2: crate::syntax::decls::FnBody,
}

impl prism_rtl::Job<crate::lower::model::Ex> for FnBodyValue {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::Ex> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let fn_body2 = &self.fn_body2;
        match fn_body2 {
            crate::syntax::decls::FnBody::BodyExpr(x_p2) => {
                let env_p1 = env_p1.clone();
                let lx_p0 = lx_p0.clone();
                let x_p2 = x_p2.clone();
                call_then(crate::lower::expr::start_value_of(lx_p0.clone(), env_p1.clone(), x_p2.clone()), move |value_of_6433: crate::lower::types::Vl| prism_rtl::Turn::Finished(crate::lower::types::own(&value_of_6433)))
            },
            crate::syntax::decls::FnBody::BodyBlock(b_p5) => {
                let b_p5 = b_p5.clone();
                let env_p1 = env_p1.clone();
                let lx_p0 = lx_p0.clone();
                call_then(crate::lower::expr::start_block_value(lx_p0.clone(), env_p1.clone(), b_p5.clone()), move |block_value_6498: crate::lower::types::Vl| prism_rtl::Turn::Finished(crate::lower::types::own(&block_value_6498)))
            },
        }
    }
}

/// `Start FnBodyValue, x`: what the function value is when passed to `@Run`.
pub fn start_fn_body_value(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, fn_body2: crate::syntax::decls::FnBody) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>> {
    Rc::new(FnBodyValue { lx_p0, env_p1, fn_body2 })
}

/// ```prism
/// FnDefOf: unbounded fn Lx, Text, [FnClause], Scheme -> FnDef
/// ```
pub fn fn_def_of(lx_p0: &crate::lower::Lx, qk_p1: &Text, clauses_p2: &Array<crate::syntax::decls::FnClause>, sc_p3: &crate::check::types::Scheme) -> crate::lower::model::FnDef {
    let (ptys0_pf, res_pg) = match &sc_p3.ty {
        crate::check::types::Ty::TyFn(_, ps_pc, r_pd) => (ps_pc.clone(), (**r_pd).clone()),
        other_pe => (Array::new(), other_pe.clone()),
    };
    let ptys_p4 = if crate::lower::types::has_blueprint(&res_pg) {
        each(&ptys0_pf, &(|p_ph: &crate::check::types::Ty| crate::lower::types::event_param(p_ph)))
    } else {
        ptys0_pf.clone()
    };
    let pts_p5 = run_to_end(each_job(ptys_p4.clone(), {
        let lx_p0 = lx_p0.clone();
        Rc::new(move |p0: crate::check::types::Ty| {
            let lx_p0 = lx_p0.clone();
            entered(once_job(move || {
                let p_pi = p0;
                prism_rtl::Turn::More(Rc::new(crate::lower::types::OutTyOf { lx_p0: lx_p0.clone(), t_p1: crate::lower::types::peel(&p_pi) }))
            }))
        }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::lower::model::OutTy>>>
    }));
    let names_p6 = param_names(lx_p0, clauses_p2, &pts_p5);
    let body_p7 = clauses_body(lx_p0, &crate::lower::types::empty_env(), clauses_p2, &names_p6, &ptys_p4, &(Rc::new(|(a0, a1, a2): (crate::lower::Lx, crate::lower::types::Env, crate::syntax::decls::FnBody)| entered(start_fn_body_value(a0, a1, a2))) as Rc<dyn Fn((crate::lower::Lx, crate::lower::types::Env, crate::syntax::decls::FnBody)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>), &Text::lit("c"), &crate::lower::types::out_ty_of(lx_p0, &crate::lower::types::peel(&res_pg)));
    let params_p8 = each(&crate::check::errors::range0(&len(&pts_p5)), &(|i_pj: &Nat| (or(&index(&each(&names_p6, &(|(n_pk, _): &(Text, bool)| n_pk.clone())), i_pj), &Text::lit("arg")), crate::lower::model::OutTy::OutRef(Rc::new(or(&index(&pts_p5, i_pj), &crate::lower::model::OutTy::OutUnit))))));
    let ret_p9 = crate::lower::types::out_ty_of(lx_p0, &crate::lower::types::peel(&res_pg));
    let used_pa = fold(&push(&pts_p5, &ret_p9), &Array::new(), &(|acc_pl: &Array<Text>, t_pm: &crate::lower::model::OutTy| crate::check::types::union_texts(acc_pl, &ty_params_in(t_pm))));
    let generics_pb = filter(&scheme_generics(lx_p0, sc_p3), &(|(g_pn, _): &(Text, Array<Text>)| crate::check::types::has_text(&used_pa, g_pn)));
    crate::lower::model::FnDef { name: or(&get(&lx_p0.rs_names, qk_p1), &crate::lower::snake(&crate::check::types::bare_name(qk_p1))), generics: generics_pb.clone(), params: params_p8.clone(), ret: ret_p9.clone(), body: body_p7.clone(), doc: signature_text(lx_p0, qk_p1), public: true }
}

/// The step machine of `FnDefOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FnDefOf: unbounded fn Lx, Text, [FnClause], Scheme -> FnDef
/// ```
pub struct FnDefOf {
    pub lx_p0: crate::lower::Lx,
    pub qk_p1: Text,
    pub clauses_p2: Array<crate::syntax::decls::FnClause>,
    pub sc_p3: crate::check::types::Scheme,
}

impl prism_rtl::Job<crate::lower::model::FnDef> for FnDefOf {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::FnDef> {
        let lx_p0 = &self.lx_p0;
        let qk_p1 = &self.qk_p1;
        let clauses_p2 = &self.clauses_p2;
        let sc_p3 = &self.sc_p3;
        let (ptys0_pf, res_pg) = match &sc_p3.ty {
            crate::check::types::Ty::TyFn(_, ps_pc, r_pd) => (ps_pc.clone(), (**r_pd).clone()),
            other_pe => (Array::new(), other_pe.clone()),
        };
        let ptys_p4 = if crate::lower::types::has_blueprint(&res_pg) {
            each(&ptys0_pf, &(|p_ph: &crate::check::types::Ty| crate::lower::types::event_param(p_ph)))
        } else {
            ptys0_pf.clone()
        };
        let clauses_p2 = clauses_p2.clone();
        let lx_p0 = lx_p0.clone();
        let qk_p1 = qk_p1.clone();
        let sc_p3 = sc_p3.clone();
        call_value(each_job(ptys_p4.clone(), {
            let lx_p0 = lx_p0.clone();
            Rc::new(move |p0: crate::check::types::Ty| {
                let lx_p0 = lx_p0.clone();
                entered(once_job(move || {
                    let p_pi = p0;
                    prism_rtl::Turn::More(Rc::new(crate::lower::types::OutTyOf { lx_p0: lx_p0.clone(), t_p1: crate::lower::types::peel(&p_pi) }))
                }))
            }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::lower::model::OutTy>>>
        }), move |each_7055: Array<crate::lower::model::OutTy>| {
            let pts_p5 = each_7055;
            call_then(start_param_names(lx_p0.clone(), clauses_p2.clone(), pts_p5.clone()), move |param_names_7108: Array<(Text, bool)>| {
                let names_p6 = param_names_7108;
                call_then(crate::lower::types::start_out_ty_of(lx_p0.clone(), crate::lower::types::peel(&res_pg)), move |out_ty_of_7218: crate::lower::model::OutTy| call_then(start_clauses_body(lx_p0.clone(), crate::lower::types::empty_env(), clauses_p2.clone(), names_p6.clone(), ptys_p4.clone(), Rc::new(|(a0, a1, a2): (crate::lower::Lx, crate::lower::types::Env, crate::syntax::decls::FnBody)| entered(start_fn_body_value(a0, a1, a2))) as Rc<dyn Fn((crate::lower::Lx, crate::lower::types::Env, crate::syntax::decls::FnBody)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>, Text::lit("c"), out_ty_of_7218), move |clauses_body_7151: crate::lower::model::Ex| {
                    let body_p7 = clauses_body_7151;
                    let params_p8 = each(&crate::check::errors::range0(&len(&pts_p5)), &(|i_pj: &Nat| (or(&index(&each(&names_p6, &(|(n_pk, _): &(Text, bool)| n_pk.clone())), i_pj), &Text::lit("arg")), crate::lower::model::OutTy::OutRef(Rc::new(or(&index(&pts_p5, i_pj), &crate::lower::model::OutTy::OutUnit))))));
                    call_then(crate::lower::types::start_out_ty_of(lx_p0.clone(), crate::lower::types::peel(&res_pg)), move |out_ty_of_7386: crate::lower::model::OutTy| {
                        let ret_p9 = out_ty_of_7386;
                        let used_pa = fold(&push(&pts_p5, &ret_p9), &Array::new(), &(|acc_pl: &Array<Text>, t_pm: &crate::lower::model::OutTy| crate::check::types::union_texts(acc_pl, &ty_params_in(t_pm))));
                        let generics_pb = filter(&scheme_generics(&lx_p0, &sc_p3), &(|(g_pn, _): &(Text, Array<Text>)| crate::check::types::has_text(&used_pa, g_pn)));
                        prism_rtl::Turn::Finished(crate::lower::model::FnDef { name: or(&get(&lx_p0.rs_names, &qk_p1), &crate::lower::snake(&crate::check::types::bare_name(&qk_p1))), generics: generics_pb.clone(), params: params_p8.clone(), ret: ret_p9.clone(), body: body_p7.clone(), doc: signature_text(&lx_p0, &qk_p1), public: true })
                    })
                }))
            })
        })
    }
}

/// `Start FnDefOf, x`: what the function value is when passed to `@Run`.
pub fn start_fn_def_of(lx_p0: crate::lower::Lx, qk_p1: Text, clauses_p2: Array<crate::syntax::decls::FnClause>, sc_p3: crate::check::types::Scheme) -> Rc<dyn prism_rtl::Job<crate::lower::model::FnDef>> {
    Rc::new(FnDefOf { lx_p0, qk_p1, clauses_p2, sc_p3 })
}

/// ```prism
/// TyParamsIn: fn OutTy -> [Text]
/// ```
pub fn ty_params_in(t_p0: &crate::lower::model::OutTy) -> Array<Text> {
    match t_p0 {
        crate::lower::model::OutTy::OutGen(n_p1) => Array::from(vec![n_p1.clone()]),
        crate::lower::model::OutTy::OutNamed(_, ts_p2) => fold(ts_p2, &Array::new(), &(|acc_p3: &Array<Text>, x_p4: &crate::lower::model::OutTy| crate::check::types::union_texts(acc_p3, &ty_params_in(x_p4)))),
        crate::lower::model::OutTy::OutTuple(ts_p5) => fold(ts_p5, &Array::new(), &(|acc_p6: &Array<Text>, x_p7: &crate::lower::model::OutTy| crate::check::types::union_texts(acc_p6, &ty_params_in(x_p7)))),
        crate::lower::model::OutTy::OutFn(ts_p8, r_p9) => fold(ts_p8, &ty_params_in(&**r_p9), &(|acc_pa: &Array<Text>, x_pb: &crate::lower::model::OutTy| crate::check::types::union_texts(acc_pa, &ty_params_in(x_pb)))),
        crate::lower::model::OutTy::OutJobFn(a_pc, r_pd) => crate::check::types::union_texts(&ty_params_in(&**a_pc), &ty_params_in(&**r_pd)),
        crate::lower::model::OutTy::OutMap(k_pe, v_pf) => crate::check::types::union_texts(&ty_params_in(&**k_pe), &ty_params_in(&**v_pf)),
        crate::lower::model::OutTy::OutOpt(x_pg) => ty_params_in(&**x_pg),
        crate::lower::model::OutTy::OutRes(x_ph) => ty_params_in(&**x_ph),
        crate::lower::model::OutTy::OutArray(x_pi) => ty_params_in(&**x_pi),
        crate::lower::model::OutTy::OutJob(x_pj) => ty_params_in(&**x_pj),
        crate::lower::model::OutTy::OutEvent(x_pk) => ty_params_in(&**x_pk),
        crate::lower::model::OutTy::OutDyn(x_pl) => ty_params_in(&**x_pl),
        crate::lower::model::OutTy::OutRc(x_pm) => ty_params_in(&**x_pm),
        crate::lower::model::OutTy::OutRef(x_pn) => ty_params_in(&**x_pn),
        crate::lower::model::OutTy::OutHold(x_po) => ty_params_in(&**x_po),
        crate::lower::model::OutTy::OutCell(x_pp) => ty_params_in(&**x_pp),
        crate::lower::model::OutTy::OutLive(x_pq) => ty_params_in(&**x_pq),
        _ => Array::new(),
    }
}

/// ```prism
/// SignatureText: fn Lx, Text -> Text
/// ```
pub fn signature_text(lx_p0: &crate::lower::Lx, qk_p1: &Text) -> Text {
    match get(&lx_p0.g.vals, qk_p1) {
        Some(v_p2) => match index(&lx_p0.g.srcs, &v_p2.file) {
            Some(src_p3) => crate::syntax::lexer::chars::trim(&crate::check::errors::span_text(&src_p3, &v_p2.span)),
            None => crate::check::types::bare_name(qk_p1),
        },
        None => crate::check::types::bare_name(qk_p1),
    }
}

/// ```prism
/// DefinitionText: fn Lx, Text -> Text
/// ```
pub fn definition_text(lx_p0: &crate::lower::Lx, qk_p1: &Text) -> Text {
    let spans_p2 = fold(&lx_p0.g.defs, &Array::new(), &(|acc_p4: &Array<(Nat, crate::syntax::Range)>, d_p5: &crate::check::env::Def| if &d_p5.qk == qk_p1 {
        push(acc_p4, &(d_p5.file.clone(), d_p5.span.clone()))
    } else {
        acc_p4.clone()
    }));
    let sig_p3 = match get(&lx_p0.g.vals, qk_p1) {
        Some(v_p6) => if &v_p6.span.start < &or(&index(&each(&spans_p2, &(|(_, r_p7): &(Nat, crate::syntax::Range)| r_p7.start.clone())), &Nat::from(0u32)), &Nat::from(0u32)) {
            Array::from(vec![(v_p6.file.clone(), v_p6.span.clone())])
        } else {
            Array::new()
        },
        None => Array::new(),
    };
    crate::syntax::lexer::chars::join(&each(&append(&sig_p3, &spans_p2), &(|(f_p8, r_p9): &(Nat, crate::syntax::Range)| src_text(lx_p0, f_p8, r_p9))), &Text::lit("\n"))
}

/// ```prism
/// SrcText: fn Lx, Nat, Range -> Text
/// ```
pub fn src_text(lx_p0: &crate::lower::Lx, f_p1: &Nat, r_p2: &crate::syntax::Range) -> Text {
    match index(&lx_p0.g.srcs, f_p1) {
        Some(src_p3) => drop_trailing_comments(&crate::check::errors::span_text(&src_p3, r_p2)),
        None => Text::lit(""),
    }
}

/// ```prism
/// DropTrailingComments: fn Text -> Text
/// ```
pub fn drop_trailing_comments(t_p0: &Text) -> Text {
    let lines_p1 = split_on(t_p0, &Text::lit("\n"));
    let keep_p2 = fold(&crate::check::errors::range0(&len(&lines_p1)), &Nat::from(0u32), &(|k_p3: &Nat, i_p4: &Nat| if is_code_line(&or(&index(&lines_p1, i_p4), &Text::lit(""))) {
        i_p4 + &Nat::from(1u32)
    } else {
        k_p3.clone()
    }));
    crate::syntax::lexer::chars::trim_end(&crate::syntax::lexer::chars::join(&take(&lines_p1, &keep_p2), &Text::lit("\n")))
}

/// ```prism
/// IsCodeLine: fn Text -> Bool
/// ```
pub fn is_code_line(l_p0: &Text) -> bool {
    let s_p1 = crate::syntax::lexer::chars::trim(l_p0);
    (&s_p1 != &Text::lit("")) && !crate::syntax::lexer::chars::has_prefix(&s_p1, &Text::lit("#"))
}

/// ```prism
/// LetGetter: unbounded fn Lx, Text, LetDecl -> FnDef
/// ```
pub fn let_getter(lx_p0: &crate::lower::Lx, qk_p1: &Text, l_p2: &crate::syntax::decls::LetDecl) -> crate::lower::model::FnDef {
    let t_p3 = crate::lower::types::out_ty_of(lx_p0, &crate::lower::types::peel(&crate::lower::type_at(lx_p0, &l_p2.value.span)));
    let v_p4 = crate::lower::expr::value_of(lx_p0, &crate::lower::types::empty_env(), &l_p2.value);
    crate::lower::model::FnDef { name: or(&get(&lx_p0.rs_names, qk_p1), &crate::lower::snake(&crate::check::types::bare_name(qk_p1))), generics: Array::new(), params: Array::new(), ret: t_p3.clone(), body: crate::lower::types::own(&v_p4), doc: Text::from(format!("let {}", &crate::check::types::bare_name(qk_p1))), public: true }
}

/// The step machine of `LetGetter`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LetGetter: unbounded fn Lx, Text, LetDecl -> FnDef
/// ```
pub struct LetGetter {
    pub lx_p0: crate::lower::Lx,
    pub qk_p1: Text,
    pub l_p2: crate::syntax::decls::LetDecl,
}

impl prism_rtl::Job<crate::lower::model::FnDef> for LetGetter {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::FnDef> {
        let lx_p0 = &self.lx_p0;
        let qk_p1 = &self.qk_p1;
        let l_p2 = &self.l_p2;
        let l_p2 = l_p2.clone();
        let lx_p0 = lx_p0.clone();
        let qk_p1 = qk_p1.clone();
        call_then(crate::lower::types::start_out_ty_of(lx_p0.clone(), crate::lower::types::peel(&crate::lower::type_at(&lx_p0, &l_p2.value.span))), move |out_ty_of_10237: crate::lower::model::OutTy| {
            let t_p3 = out_ty_of_10237;
            call_then(crate::lower::expr::start_value_of(lx_p0.clone(), crate::lower::types::empty_env(), l_p2.value.clone()), move |value_of_10294: crate::lower::types::Vl| {
                let v_p4 = value_of_10294;
                prism_rtl::Turn::Finished(crate::lower::model::FnDef { name: or(&get(&lx_p0.rs_names, &qk_p1), &crate::lower::snake(&crate::check::types::bare_name(&qk_p1))), generics: Array::new(), params: Array::new(), ret: t_p3.clone(), body: crate::lower::types::own(&v_p4), doc: Text::from(format!("let {}", &crate::check::types::bare_name(&qk_p1))), public: true })
            })
        })
    }
}

/// `Start LetGetter, x`: what the function value is when passed to `@Run`.
pub fn start_let_getter(lx_p0: crate::lower::Lx, qk_p1: Text, l_p2: crate::syntax::decls::LetDecl) -> Rc<dyn prism_rtl::Job<crate::lower::model::FnDef>> {
    Rc::new(LetGetter { lx_p0, qk_p1, l_p2 })
}

/// ```prism
/// HasOwnShow: fn Lx, Text -> Bool
/// ```
pub fn has_own_show(lx_p0: &crate::lower::Lx, tn_p1: &Text) -> bool {
    fold(&or(&get(&lx_p0.g.impls, &Text::lit("Prelude.Show")), &Array::new()), &false, &(|f_p2: &bool, im_p3: &crate::check::env::ImplInfo| *f_p2 || (!im_p3.derived && (&head_name(&im_p3.head) == tn_p1))))
}

/// ```prism
/// HeadName: fn Ty -> Text
/// ```
pub fn head_name(ty0: &crate::check::types::Ty) -> Text {
    match ty0 {
        crate::check::types::Ty::TyCon(n_p0, _) => n_p0.clone(),
        other_p1 => Text::lit(""),
    }
}

/// ```prism
/// SelfIn: unbounded fn Ty, Text -> Ty
/// ```
pub fn self_in(t_p0: &crate::check::types::Ty, param_p1: &Text) -> crate::check::types::Ty {
    crate::lower::expr::instantiated(t_p0, &Array::from(vec![param_p1.clone()]), &Array::from(vec![crate::check::types::Ty::TyCon(Text::lit("\0Self"), Array::new())]))
}

/// The step machine of `SelfIn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SelfIn: unbounded fn Ty, Text -> Ty
/// ```
pub struct SelfIn {
    pub t_p0: crate::check::types::Ty,
    pub param_p1: Text,
}

impl prism_rtl::Job<crate::check::types::Ty> for SelfIn {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::Ty> {
        let t_p0 = &self.t_p0;
        let param_p1 = &self.param_p1;
        prism_rtl::Turn::More(Rc::new(crate::lower::expr::Instantiated { t_p0: t_p0.clone(), params_p1: Array::from(vec![param_p1.clone()]), args_p2: Array::from(vec![crate::check::types::Ty::TyCon(Text::lit("\0Self"), Array::new())]) }))
    }
}

/// `Start SelfIn, x`: what the function value is when passed to `@Run`.
pub fn start_self_in(t_p0: crate::check::types::Ty, param_p1: Text) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>> {
    Rc::new(SelfIn { t_p0, param_p1 })
}

/// ```prism
/// TraitDefOf: unbounded fn Lx, TraitInfo -> TraitDef
/// ```
pub fn trait_def_of(lx0_p0: &crate::lower::Lx, tr_p1: &crate::check::env::TraitInfo) -> crate::lower::model::TraitDef {
    let lx_p2 = crate::lower::program::in_module(lx0_p0, &tr_p1.file, &tr_p1.home);
    let methods_p3 = run_to_end(each_job(tr_p1.methods.clone(), {
        let lx_p2 = lx_p2.clone();
        let tr_p1 = tr_p1.clone();
        Rc::new(move |p0: Text| {
            let lx_p2 = lx_p2.clone();
            let tr_p1 = tr_p1.clone();
            entered(once_job(move || {
                let mq_p4 = p0;
                {
                    let v_p5 = or(&get(&lx_p2.g.vals, &mq_p4), &crate::check::env::builtin(&mq_p4, &crate::check::types::schemes::mono(&crate::check::types::Ty::TyErr)));
                    let sc_p6 = {
                        let mut this: crate::check::types::Scheme = v_p5.scheme.clone();
                        this.ty = self_in(&this.ty, &tr_p1.param);
                        this.qs = filter(&this.qs, &(|q_pa: &Text| q_pa != &tr_p1.param));
                        this.bounds = filter(&this.bounds, &(|(q_pb, _): &(Text, Text)| q_pb != &tr_p1.param));
                        this
                    };
                    let default_qk_p7 = fold(&tr_p1.defaults, &Text::lit(""), &(|f_pc: &Text, dq_pd: &Text| if &crate::check::types::bare_name(dq_pd) == &crate::check::types::bare_name(&mq_p4) {
                        dq_pd.clone()
                    } else {
                        f_pc.clone()
                    }));
                    let clauses_p8 = if &default_qk_p7 == &Text::lit("") {
                        Array::new()
                    } else {
                        default_clauses(&lx_p2.g, &default_qk_p7)
                    };
                    call_then(start_fn_def_of(lx_p2.clone(), mq_p4.clone(), if &len(&clauses_p8) == &Nat::from(0u32) {
                        Array::from(vec![dummy_clause()])
                    } else {
                        clauses_p8.clone()
                    }, sc_p6.clone()), move |fn_def_of_11831: crate::lower::model::FnDef| {
                        let fd_p9 = fn_def_of_11831;
                        prism_rtl::Turn::Finished({
                            let mut this: crate::lower::model::FnDef = fd_p9.clone();
                            this.public = &len(&clauses_p8) > &Nat::from(0u32);
                            this
                        })
                    })
                }
            }))
        }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<crate::lower::model::FnDef>>>
    }));
    crate::lower::model::TraitDef { name: crate::lower::camel(&crate::check::types::bare_name(&tr_p1.name)), methods: methods_p3.clone(), defaults: tr_p1.defaults.clone(), doc: crate::lower::program::type_doc(&lx_p2, &crate::check::env::TyInfo { name: tr_p1.name.clone(), home: tr_p1.home.clone(), params: Array::new(), body: crate::check::env::TyBody::BOpaque, derives: Array::new(), file: tr_p1.file.clone(), span: tr_p1.span.clone() }) }
}

/// The step machine of `TraitDefOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TraitDefOf: unbounded fn Lx, TraitInfo -> TraitDef
/// ```
pub struct TraitDefOf {
    pub lx0_p0: crate::lower::Lx,
    pub tr_p1: crate::check::env::TraitInfo,
}

impl prism_rtl::Job<crate::lower::model::TraitDef> for TraitDefOf {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::TraitDef> {
        let lx0_p0 = &self.lx0_p0;
        let tr_p1 = &self.tr_p1;
        let lx_p2 = crate::lower::program::in_module(lx0_p0, &tr_p1.file, &tr_p1.home);
        let tr_p1 = tr_p1.clone();
        call_value(each_job(tr_p1.methods.clone(), {
            let lx_p2 = lx_p2.clone();
            let tr_p1 = tr_p1.clone();
            Rc::new(move |p0: Text| {
                let lx_p2 = lx_p2.clone();
                let tr_p1 = tr_p1.clone();
                entered(once_job(move || {
                    let mq_p4 = p0;
                    {
                        let v_p5 = or(&get(&lx_p2.g.vals, &mq_p4), &crate::check::env::builtin(&mq_p4, &crate::check::types::schemes::mono(&crate::check::types::Ty::TyErr)));
                        let sc_p6 = {
                            let mut this: crate::check::types::Scheme = v_p5.scheme.clone();
                            this.ty = self_in(&this.ty, &tr_p1.param);
                            this.qs = filter(&this.qs, &(|q_pa: &Text| q_pa != &tr_p1.param));
                            this.bounds = filter(&this.bounds, &(|(q_pb, _): &(Text, Text)| q_pb != &tr_p1.param));
                            this
                        };
                        let default_qk_p7 = fold(&tr_p1.defaults, &Text::lit(""), &(|f_pc: &Text, dq_pd: &Text| if &crate::check::types::bare_name(dq_pd) == &crate::check::types::bare_name(&mq_p4) {
                            dq_pd.clone()
                        } else {
                            f_pc.clone()
                        }));
                        let clauses_p8 = if &default_qk_p7 == &Text::lit("") {
                            Array::new()
                        } else {
                            default_clauses(&lx_p2.g, &default_qk_p7)
                        };
                        call_then(start_fn_def_of(lx_p2.clone(), mq_p4.clone(), if &len(&clauses_p8) == &Nat::from(0u32) {
                            Array::from(vec![dummy_clause()])
                        } else {
                            clauses_p8.clone()
                        }, sc_p6.clone()), move |fn_def_of_11831: crate::lower::model::FnDef| {
                            let fd_p9 = fn_def_of_11831;
                            prism_rtl::Turn::Finished({
                                let mut this: crate::lower::model::FnDef = fd_p9.clone();
                                this.public = &len(&clauses_p8) > &Nat::from(0u32);
                                this
                            })
                        })
                    }
                }))
            }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<crate::lower::model::FnDef>>>
        }), move |each_11339: Array<crate::lower::model::FnDef>| {
            let methods_p3 = each_11339;
            prism_rtl::Turn::Finished(crate::lower::model::TraitDef { name: crate::lower::camel(&crate::check::types::bare_name(&tr_p1.name)), methods: methods_p3.clone(), defaults: tr_p1.defaults.clone(), doc: crate::lower::program::type_doc(&lx_p2, &crate::check::env::TyInfo { name: tr_p1.name.clone(), home: tr_p1.home.clone(), params: Array::new(), body: crate::check::env::TyBody::BOpaque, derives: Array::new(), file: tr_p1.file.clone(), span: tr_p1.span.clone() }) })
        })
    }
}

/// `Start TraitDefOf, x`: what the function value is when passed to `@Run`.
pub fn start_trait_def_of(lx0_p0: crate::lower::Lx, tr_p1: crate::check::env::TraitInfo) -> Rc<dyn prism_rtl::Job<crate::lower::model::TraitDef>> {
    Rc::new(TraitDefOf { lx0_p0, tr_p1 })
}

/// ```prism
/// DefaultClauses: fn G, Text -> [FnClause]
/// ```
pub fn default_clauses(g_p0: &crate::check::env::G, qk_p1: &Text) -> Array<crate::syntax::decls::FnClause> {
    fold(&g_p0.defs, &Array::new(), &(|acc_p2: &Array<crate::syntax::decls::FnClause>, d_p3: &crate::check::env::Def| if &d_p3.qk == qk_p1 { default_of(d_p3, acc_p2) } else { acc_p2.clone() }))
}

/// ```prism
/// DefaultOf: fn Def, [FnClause] -> [FnClause]
/// ```
pub fn default_of(d_p0: &crate::check::env::Def, other_p1: &Array<crate::syntax::decls::FnClause>) -> Array<crate::syntax::decls::FnClause> {
    match &d_p0.body {
        crate::check::env::DefBody::DbDefault(cs_p2, _) => cs_p2.clone(),
        _ => other_p1.clone(),
    }
}

/// ```prism
/// ImplDefOf: unbounded fn Lx, ImplInfo -> ImplDef
/// ```
pub fn impl_def_of(lx_p0: &crate::lower::Lx, im_p1: &crate::check::env::ImplInfo) -> crate::lower::model::ImplDef {
    let tr_p2 = or(&get(&lx_p0.g.traits, &im_p1.cls), &crate::lower::expr::dummy_trait_info());
    let head_p3 = crate::lower::types::out_ty_of(lx_p0, &im_p1.head);
    let defs_p4 = filter(&lx_p0.g.defs, &(|d_p7: &crate::check::env::Def| is_method_of(d_p7, im_p1)));
    let methods_p5 = run_to_end(each_job(defs_p4.clone(), {
        let tr_p2 = tr_p2.clone();
        let lx_p0 = lx_p0.clone();
        let im_p1 = im_p1.clone();
        Rc::new(move |p0: crate::check::env::Def| {
            let tr_p2 = tr_p2.clone();
            let lx_p0 = lx_p0.clone();
            let im_p1 = im_p1.clone();
            entered(once_job(move || {
                let d_p8 = p0;
                {
                    let mq_p9 = fold(&tr_p2.methods, &Text::lit(""), &(|found_pd: &Text, q_pe: &Text| if &crate::check::types::bare_name(q_pe) == &d_p8.name {
                        q_pe.clone()
                    } else {
                        found_pd.clone()
                    }));
                    let v_pa = or(&get(&lx_p0.g.vals, &mq_p9), &crate::check::env::builtin(&mq_p9, &crate::check::types::schemes::mono(&crate::check::types::Ty::TyErr)));
                    let sc_pb = {
                        let mut this: crate::check::types::Scheme = v_pa.scheme.clone();
                        this.ty = crate::lower::expr::instantiated(&this.ty, &Array::from(vec![tr_p2.param.clone()]), &Array::from(vec![im_p1.head.clone()]));
                        this.qs = filter(&this.qs, &(|q_pf: &Text| q_pf != &tr_p2.param));
                        this.bounds = filter(&this.bounds, &(|(q_pg, _): &(Text, Text)| q_pg != &tr_p2.param));
                        this
                    };
                    call_then(start_fn_def_of(lx_p0.clone(), mq_p9.clone(), method_clauses(&d_p8), sc_pb.clone()), move |fn_def_of_13164: crate::lower::model::FnDef| {
                        let fd_pc = fn_def_of_13164;
                        if crate::syntax::lexer::chars::has_prefix(&im_p1.cls, &Text::lit("Prelude.")) {
                            prism_rtl::Turn::Finished(renamed(&fd_pc, &Text::from(format!("{}_{}", &crate::lower::snake(&d_p8.name), &crate::lower::snake(&crate::check::types::bare_name(&head_name(&im_p1.head)))))))
                        } else {
                            prism_rtl::Turn::Finished(fd_pc.clone())
                        }
                    })
                }
            }))
        }) as Rc<dyn Fn(crate::check::env::Def) -> Rc<dyn prism_rtl::Job<crate::lower::model::FnDef>>>
    }));
    let generics_p6 = each(&im_p1.qs, &(|q_ph: &Text| (crate::lower::camel(q_ph), Array::from(vec![Text::lit("Clone")]))));
    crate::lower::model::ImplDef { cls: im_p1.cls.clone(), tr: crate::lower::path_in(lx_p0, &tr_p2.home, &crate::lower::camel(&crate::check::types::bare_name(&im_p1.cls))), head: head_p3.clone(), generics: generics_p6.clone(), methods: methods_p5.clone(), doc: Text::lit("") }
}

/// The step machine of `ImplDefOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ImplDefOf: unbounded fn Lx, ImplInfo -> ImplDef
/// ```
pub struct ImplDefOf {
    pub lx_p0: crate::lower::Lx,
    pub im_p1: crate::check::env::ImplInfo,
}

impl prism_rtl::Job<crate::lower::model::ImplDef> for ImplDefOf {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::ImplDef> {
        let lx_p0 = &self.lx_p0;
        let im_p1 = &self.im_p1;
        let tr_p2 = or(&get(&lx_p0.g.traits, &im_p1.cls), &crate::lower::expr::dummy_trait_info());
        let im_p1 = im_p1.clone();
        let lx_p0 = lx_p0.clone();
        call_then(crate::lower::types::start_out_ty_of(lx_p0.clone(), im_p1.head.clone()), move |out_ty_of_12657: crate::lower::model::OutTy| {
            let head_p3 = out_ty_of_12657;
            let defs_p4 = filter(&lx_p0.g.defs, &(|d_p7: &crate::check::env::Def| is_method_of(d_p7, &im_p1)));
            call_value(each_job(defs_p4.clone(), {
                let tr_p2 = tr_p2.clone();
                let lx_p0 = lx_p0.clone();
                let im_p1 = im_p1.clone();
                Rc::new(move |p0: crate::check::env::Def| {
                    let tr_p2 = tr_p2.clone();
                    let lx_p0 = lx_p0.clone();
                    let im_p1 = im_p1.clone();
                    entered(once_job(move || {
                        let d_p8 = p0;
                        {
                            let mq_p9 = fold(&tr_p2.methods, &Text::lit(""), &(|found_pd: &Text, q_pe: &Text| if &crate::check::types::bare_name(q_pe) == &d_p8.name {
                                q_pe.clone()
                            } else {
                                found_pd.clone()
                            }));
                            let v_pa = or(&get(&lx_p0.g.vals, &mq_p9), &crate::check::env::builtin(&mq_p9, &crate::check::types::schemes::mono(&crate::check::types::Ty::TyErr)));
                            let sc_pb = {
                                let mut this: crate::check::types::Scheme = v_pa.scheme.clone();
                                this.ty = crate::lower::expr::instantiated(&this.ty, &Array::from(vec![tr_p2.param.clone()]), &Array::from(vec![im_p1.head.clone()]));
                                this.qs = filter(&this.qs, &(|q_pf: &Text| q_pf != &tr_p2.param));
                                this.bounds = filter(&this.bounds, &(|(q_pg, _): &(Text, Text)| q_pg != &tr_p2.param));
                                this
                            };
                            call_then(start_fn_def_of(lx_p0.clone(), mq_p9.clone(), method_clauses(&d_p8), sc_pb.clone()), move |fn_def_of_13164: crate::lower::model::FnDef| {
                                let fd_pc = fn_def_of_13164;
                                if crate::syntax::lexer::chars::has_prefix(&im_p1.cls, &Text::lit("Prelude.")) {
                                    prism_rtl::Turn::Finished(renamed(&fd_pc, &Text::from(format!("{}_{}", &crate::lower::snake(&d_p8.name), &crate::lower::snake(&crate::check::types::bare_name(&head_name(&im_p1.head)))))))
                                } else {
                                    prism_rtl::Turn::Finished(fd_pc.clone())
                                }
                            })
                        }
                    }))
                }) as Rc<dyn Fn(crate::check::env::Def) -> Rc<dyn prism_rtl::Job<crate::lower::model::FnDef>>>
            }), move |each_12750: Array<crate::lower::model::FnDef>| {
                let methods_p5 = each_12750;
                let generics_p6 = each(&im_p1.qs, &(|q_ph: &Text| (crate::lower::camel(q_ph), Array::from(vec![Text::lit("Clone")]))));
                prism_rtl::Turn::Finished(crate::lower::model::ImplDef { cls: im_p1.cls.clone(), tr: crate::lower::path_in(&lx_p0, &tr_p2.home, &crate::lower::camel(&crate::check::types::bare_name(&im_p1.cls))), head: head_p3.clone(), generics: generics_p6.clone(), methods: methods_p5.clone(), doc: Text::lit("") })
            })
        })
    }
}

/// `Start ImplDefOf, x`: what the function value is when passed to `@Run`.
pub fn start_impl_def_of(lx_p0: crate::lower::Lx, im_p1: crate::check::env::ImplInfo) -> Rc<dyn prism_rtl::Job<crate::lower::model::ImplDef>> {
    Rc::new(ImplDefOf { lx_p0, im_p1 })
}

/// ```prism
/// Renamed: fn FnDef, Text -> FnDef
/// ```
pub fn renamed(fd_p0: &crate::lower::model::FnDef, n_p1: &Text) -> crate::lower::model::FnDef {
    let mut this: crate::lower::model::FnDef = fd_p0.clone();
    this.name = n_p1.clone();
    this
}

/// ```prism
/// IsMethodOf: fn Def, ImplInfo -> Bool
/// ```
pub fn is_method_of(d_p0: &crate::check::env::Def, im_p1: &crate::check::env::ImplInfo) -> bool {
    match &d_p0.body {
        crate::check::env::DefBody::DbMethod(_, cls_p2, other_p3) => ((cls_p2 == &im_p1.cls) && (&other_p3.span == &im_p1.span)) && (&other_p3.file == &im_p1.file),
        _ => false,
    }
}

/// ```prism
/// MethodClauses: fn Def -> [FnClause]
/// ```
pub fn method_clauses(d_p0: &crate::check::env::Def) -> Array<crate::syntax::decls::FnClause> {
    match &d_p0.body {
        crate::check::env::DefBody::DbMethod(cs_p1, _, _) => cs_p1.clone(),
        _ => Array::new(),
    }
}

/// ```prism
/// IfGenLine: unbounded fn Wx, Env, Expr, Block, Block, Expr -> ((Wx, Wres))
/// ```
pub fn if_gen_line(wx_p0: &crate::lower::node_::Wx, menv_p1: &crate::lower::types::Env, c_p2: &crate::syntax::Expr, then_b_p3: &crate::syntax::Block, else_b_p4: &crate::syntax::Block, e_p5: &crate::syntax::Expr) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    let lx_p6 = wx_p0.lx.clone();
    let pos_p7 = wx_p0.pos.clone();
    let wx1_p8 = {
        let mut this: crate::lower::node_::Wx = wx_p0.clone();
        this.pos = crate::lower::model::next_pos(&this.pos);
        this
    };
    let (name_ph, wx2_pi) = crate::lower::node_::fresh_name(&wx1_p8, &Text::lit("arm"));
    let base_p9 = Text::from(format!("{}{}{}", &wx_p0.node_, &crate::lower::camel(&name_ph), &crate::lower::node_::keyed::row_suffix(wx_p0)));
    let yes_pa = crate::lower::node_::switch_::gen_row_of(&wx2_pi, menv_p1, then_b_p3, &crate::lower::model::OutTy::OutUnit, &Text::from(format!("{}Then", &base_p9)), &name_ph);
    let no_pb = crate::lower::node_::switch_::gen_row_of(&yes_pa.parent, menv_p1, else_b_p4, &crate::lower::model::OutTy::OutUnit, &Text::from(format!("{}Else", &base_p9)), &name_ph);
    let cond_pc = crate::lower::types::as_bool(&crate::lower::expr::value_of(&lx_p6, menv_p1, c_p2));
    let tail_pd = append(&append(&Array::from(vec![crate::lower::model::Ex::XWeak(Rc::new(crate::lower::model::Ex::XSelf))]), &crate::lower::node_::keyed::hosted_passed(wx_p0)), &Array::from(vec![crate::lower::model::Ex::XCx]));
    let mk_fe = {
        let tail_pd = tail_pd.clone();
        Rc::new(move |n_pj: &crate::lower::model::NodeDef| crate::lower::model::Ex::XCast(Rc::new(crate::lower::expr::try_of(&crate::lower::model::Ex::XCall(Text::from(format!("{}::build", &n_pj.name)), append(&Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("path")), crate::lower::model::Ex::XVar(Text::lit("value"))]), &tail_pd)))), crate::lower::model::OutTy::OutObj(Rc::new(crate::lower::model::OutTy::OutNamed(Text::lit("Row"), Array::new()))))) as Rc<dyn Fn(&crate::lower::model::NodeDef) -> crate::lower::model::Ex>
    };
    let select_pf = crate::lower::model::Ex::XIf(Rc::new(cond_pc.clone()), Rc::new((&mk_fe)(&yes_pa.node_)), Rc::new((&mk_fe)(&no_pb.node_)));
    let wx3_pg = {
        let mut this: crate::lower::node_::Wx = no_pb.parent.clone();
        this.gens = push(&this.gens, &crate::lower::model::GenDef { name: name_ph.clone(), pos: pos_p7.clone(), at: crate::lower::node_::finish::place_at(wx_p0, &Text::lit("self"), &pos_p7), source: crate::lower::model::Ex::XUnit, value_ty: crate::lower::model::OutTy::OutUnit, select: select_pf.clone(), transparent: false, width: Nat::from(0u32), moved: or(&crate::lower::node_::finish::hosted_rows(wx_p0), &Text::lit("")) });
        this.gen_holds = push(&this.gen_holds, &(name_ph.clone(), Array::new()));
        this.rows = append(&append(&append(&push(&this.rows, &yes_pa.node_), &yes_pa.node_.children), &Array::from(vec![no_pb.node_.clone()])), &no_pb.node_.children);
        this.getters = push(&this.getters, &crate::lower::model::MethDef { name: Text::from(format!("{}_up", &name_ph)), recv: crate::lower::model::Recv::RecvRc, params: Array::from(vec![(Text::lit("v"), crate::lower::model::OutTy::OutUnit)]), cx_: crate::lower::model::CxArg::CxMut, ret: crate::lower::model::OutTy::OutUnit, body: Array::new(), tail: crate::lower::model::Ex::XUnit, doc: Text::lit("An arm\'s result, which a building `if` of widgets drops.") });
        this
    };
    (wx3_pg.clone(), crate::lower::node_::Wres::WrUnit)
}

/// The step machine of `IfGenLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// IfGenLine: unbounded fn Wx, Env, Expr, Block, Block, Expr -> ((Wx, Wres))
/// ```
pub struct IfGenLine {
    pub wx_p0: crate::lower::node_::Wx,
    pub menv_p1: crate::lower::types::Env,
    pub c_p2: crate::syntax::Expr,
    pub then_b_p3: crate::syntax::Block,
    pub else_b_p4: crate::syntax::Block,
    pub e_p5: crate::syntax::Expr,
}

impl prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::node_::Wres)> for IfGenLine {
    fn cycle(&self) -> prism_rtl::Turn<(crate::lower::node_::Wx, crate::lower::node_::Wres)> {
        let wx_p0 = &self.wx_p0;
        let menv_p1 = &self.menv_p1;
        let c_p2 = &self.c_p2;
        let then_b_p3 = &self.then_b_p3;
        let else_b_p4 = &self.else_b_p4;
        let e_p5 = &self.e_p5;
        let lx_p6 = wx_p0.lx.clone();
        let pos_p7 = wx_p0.pos.clone();
        let wx1_p8 = {
            let mut this: crate::lower::node_::Wx = wx_p0.clone();
            this.pos = crate::lower::model::next_pos(&this.pos);
            this
        };
        let (name_ph, wx2_pi) = crate::lower::node_::fresh_name(&wx1_p8, &Text::lit("arm"));
        let base_p9 = Text::from(format!("{}{}{}", &wx_p0.node_, &crate::lower::camel(&name_ph), &crate::lower::node_::keyed::row_suffix(wx_p0)));
        let yes_pa = crate::lower::node_::switch_::gen_row_of(&wx2_pi, menv_p1, then_b_p3, &crate::lower::model::OutTy::OutUnit, &Text::from(format!("{}Then", &base_p9)), &name_ph);
        let no_pb = crate::lower::node_::switch_::gen_row_of(&yes_pa.parent, menv_p1, else_b_p4, &crate::lower::model::OutTy::OutUnit, &Text::from(format!("{}Else", &base_p9)), &name_ph);
        let c_p2 = c_p2.clone();
        let menv_p1 = menv_p1.clone();
        let wx_p0 = wx_p0.clone();
        call_then(crate::lower::expr::start_value_of(lx_p6.clone(), menv_p1.clone(), c_p2.clone()), move |value_of_14630: crate::lower::types::Vl| {
            let cond_pc = crate::lower::types::as_bool(&value_of_14630);
            let tail_pd = append(&append(&Array::from(vec![crate::lower::model::Ex::XWeak(Rc::new(crate::lower::model::Ex::XSelf))]), &crate::lower::node_::keyed::hosted_passed(&wx_p0)), &Array::from(vec![crate::lower::model::Ex::XCx]));
            let mk_fe = {
                let tail_pd = tail_pd.clone();
                Rc::new(move |n_pj: &crate::lower::model::NodeDef| crate::lower::model::Ex::XCast(Rc::new(crate::lower::expr::try_of(&crate::lower::model::Ex::XCall(Text::from(format!("{}::build", &n_pj.name)), append(&Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("path")), crate::lower::model::Ex::XVar(Text::lit("value"))]), &tail_pd)))), crate::lower::model::OutTy::OutObj(Rc::new(crate::lower::model::OutTy::OutNamed(Text::lit("Row"), Array::new()))))) as Rc<dyn Fn(&crate::lower::model::NodeDef) -> crate::lower::model::Ex>
            };
            let select_pf = crate::lower::model::Ex::XIf(Rc::new(cond_pc.clone()), Rc::new((&mk_fe)(&yes_pa.node_)), Rc::new((&mk_fe)(&no_pb.node_)));
            let wx3_pg = {
                let mut this: crate::lower::node_::Wx = no_pb.parent.clone();
                this.gens = push(&this.gens, &crate::lower::model::GenDef { name: name_ph.clone(), pos: pos_p7.clone(), at: crate::lower::node_::finish::place_at(&wx_p0, &Text::lit("self"), &pos_p7), source: crate::lower::model::Ex::XUnit, value_ty: crate::lower::model::OutTy::OutUnit, select: select_pf.clone(), transparent: false, width: Nat::from(0u32), moved: or(&crate::lower::node_::finish::hosted_rows(&wx_p0), &Text::lit("")) });
                this.gen_holds = push(&this.gen_holds, &(name_ph.clone(), Array::new()));
                this.rows = append(&append(&append(&push(&this.rows, &yes_pa.node_), &yes_pa.node_.children), &Array::from(vec![no_pb.node_.clone()])), &no_pb.node_.children);
                this.getters = push(&this.getters, &crate::lower::model::MethDef { name: Text::from(format!("{}_up", &name_ph)), recv: crate::lower::model::Recv::RecvRc, params: Array::from(vec![(Text::lit("v"), crate::lower::model::OutTy::OutUnit)]), cx_: crate::lower::model::CxArg::CxMut, ret: crate::lower::model::OutTy::OutUnit, body: Array::new(), tail: crate::lower::model::Ex::XUnit, doc: Text::lit("An arm\'s result, which a building `if` of widgets drops.") });
                this
            };
            prism_rtl::Turn::Finished((wx3_pg.clone(), crate::lower::node_::Wres::WrUnit))
        })
    }
}

/// `Start IfGenLine, x`: what the function value is when passed to `@Run`.
pub fn start_if_gen_line(wx_p0: crate::lower::node_::Wx, menv_p1: crate::lower::types::Env, c_p2: crate::syntax::Expr, then_b_p3: crate::syntax::Block, else_b_p4: crate::syntax::Block, e_p5: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::node_::Wres)>> {
    Rc::new(IfGenLine { wx_p0, menv_p1, c_p2, then_b_p3, else_b_p4, e_p5 })
}
