//! The module `Lower.Model`, from `target/bootstrap/src/prismc/lower/model.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// `AnswerCase`:
///
/// ```prism
/// type AnswerCase = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct AnswerCase {
    pub variant: Text,
    pub accessor: Text,
    pub struct_path: Text,
    pub tag_name: Text,
    pub ty: OutTy,
}

impl Show for AnswerCase {
    fn show(&self, p: &mut Printer) {
        p.record("AnswerCase", &[("variant", &self.variant), ("accessor", &self.accessor), ("struct_path", &self.struct_path), ("tag_name", &self.tag_name), ("ty", &self.ty)]);
    }
}

impl ToPod for AnswerCase {
    fn to_pod(&self) -> Pod {
        Pod::record("AnswerCase", vec![("variant", self.variant.to_pod()), ("accessor", self.accessor.to_pod()), ("struct_path", self.struct_path.to_pod()), ("tag_name", self.tag_name.to_pod()), ("ty", self.ty.to_pod())])
    }
}

impl FromPod for AnswerCase {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(AnswerCase { variant: FromPod::from_pod(field(p, "variant")?)?, accessor: FromPod::from_pod(field(p, "accessor")?)?, struct_path: FromPod::from_pod(field(p, "struct_path")?)?, tag_name: FromPod::from_pod(field(p, "tag_name")?)?, ty: FromPod::from_pod(field(p, "ty")?)? })
    }
}

/// `AnswerDef`:
///
/// ```prism
/// type AnswerDef = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct AnswerDef {
    pub cases: Array<AnswerCase>,
}

impl Show for AnswerDef {
    fn show(&self, p: &mut Printer) {
        p.record("AnswerDef", &[("cases", &self.cases)]);
    }
}

impl ToPod for AnswerDef {
    fn to_pod(&self) -> Pod {
        Pod::record("AnswerDef", vec![("cases", self.cases.to_pod())])
    }
}

impl FromPod for AnswerDef {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(AnswerDef { cases: FromPod::from_pod(field(p, "cases")?)? })
    }
}

/// `CaseDef`:
///
/// ```prism
/// type CaseDef = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct CaseDef {
    pub name: Text,
    pub prism: Text,
    pub fields: Array<(Text, OutTy)>,
}

impl Show for CaseDef {
    fn show(&self, p: &mut Printer) {
        p.record("CaseDef", &[("name", &self.name), ("prism", &self.prism), ("fields", &self.fields)]);
    }
}

impl ToPod for CaseDef {
    fn to_pod(&self) -> Pod {
        Pod::record("CaseDef", vec![("name", self.name.to_pod()), ("prism", self.prism.to_pod()), ("fields", self.fields.to_pod())])
    }
}

impl FromPod for CaseDef {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(CaseDef { name: FromPod::from_pod(field(p, "name")?)?, prism: FromPod::from_pod(field(p, "prism")?)?, fields: FromPod::from_pod(field(p, "fields")?)? })
    }
}

/// `Cc`:
///
/// ```prism
/// type Cc = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum Cc {
    CcIf(Ex),
    CcLet(Pa, Ex),
}

impl Show for Cc {
    fn show(&self, p: &mut Printer) {
        match self {
            Cc::CcIf(a0) => p.choice("CcIf", &[a0]),
            Cc::CcLet(a0, a1) => p.choice("CcLet", &[a0, a1]),
        }
    }
}

impl ToPod for Cc {
    fn to_pod(&self) -> Pod {
        match self {
            Cc::CcIf(a0) => Pod::Choice("CcIf".into(), vec![a0.to_pod()]),
            Cc::CcLet(a0, a1) => Pod::Choice("CcLet".into(), vec![a0.to_pod(), a1.to_pod()]),
        }
    }
}

impl FromPod for Cc {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "CcIf" && a.len() == 1 => Ok(Cc::CcIf(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "CcLet" && a.len() == 2 => Ok(Cc::CcLet(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            other => mismatch("a Cc", other),
        }
    }
}

/// `CheckDef`:
///
/// ```prism
/// type CheckDef = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct CheckDef {
    pub name: Text,
    pub lines: Array<Ex>,
}

impl Show for CheckDef {
    fn show(&self, p: &mut Printer) {
        p.record("CheckDef", &[("name", &self.name), ("lines", &self.lines)]);
    }
}

impl ToPod for CheckDef {
    fn to_pod(&self) -> Pod {
        Pod::record("CheckDef", vec![("name", self.name.to_pod()), ("lines", self.lines.to_pod())])
    }
}

impl FromPod for CheckDef {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(CheckDef { name: FromPod::from_pod(field(p, "name")?)?, lines: FromPod::from_pod(field(p, "lines")?)? })
    }
}

/// `CxArg`:
///
/// ```prism
/// type CxArg = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum CxArg {
    CxMut,
    CxRef,
    CxNone,
}

impl Show for CxArg {
    fn show(&self, p: &mut Printer) {
        match self {
            CxArg::CxMut => p.choice("CxMut", &[]),
            CxArg::CxRef => p.choice("CxRef", &[]),
            CxArg::CxNone => p.choice("CxNone", &[]),
        }
    }
}

impl ToPod for CxArg {
    fn to_pod(&self) -> Pod {
        match self {
            CxArg::CxMut => Pod::Choice("CxMut".into(), vec![]),
            CxArg::CxRef => Pod::Choice("CxRef".into(), vec![]),
            CxArg::CxNone => Pod::Choice("CxNone".into(), vec![]),
        }
    }
}

impl FromPod for CxArg {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "CxMut" && a.len() == 0 => Ok(CxArg::CxMut),
            Pod::Choice(c, a) if &**c == "CxRef" && a.len() == 0 => Ok(CxArg::CxRef),
            Pod::Choice(c, a) if &**c == "CxNone" && a.len() == 0 => Ok(CxArg::CxNone),
            other => mismatch("a CxArg", other),
        }
    }
}

/// `Do`:
///
/// ```prism
/// type Do = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum Do {
    DoLet(Pa, Ex),
    DoLetElse(Pa, Ex, Ex),
    DoAssign(Ex, Ex),
    DoWhile(Ex, Array<Do>),
    DoWhileLet(Pa, Ex, Array<Do>),
    DoFor(Pa, Ex, Array<Do>),
    DoExpr(Ex),
    DoIf(Ex, Array<Do>, Array<Do>),
    DoIfLet(Pa, Ex, Array<Do>, Array<Do>),
    DoMatch(Ex, Array<(Pa, Array<Do>)>),
    DoReturn(Ex),
    DoBlock(Array<Do>),
    DoScope(Array<Do>),
    DoLine(Array<Do>),
    DoNote(Text),
}

impl Show for Do {
    fn show(&self, p: &mut Printer) {
        match self {
            Do::DoLet(a0, a1) => p.choice("DoLet", &[a0, a1]),
            Do::DoLetElse(a0, a1, a2) => p.choice("DoLetElse", &[a0, a1, a2]),
            Do::DoAssign(a0, a1) => p.choice("DoAssign", &[a0, a1]),
            Do::DoWhile(a0, a1) => p.choice("DoWhile", &[a0, a1]),
            Do::DoWhileLet(a0, a1, a2) => p.choice("DoWhileLet", &[a0, a1, a2]),
            Do::DoFor(a0, a1, a2) => p.choice("DoFor", &[a0, a1, a2]),
            Do::DoExpr(a0) => p.choice("DoExpr", &[a0]),
            Do::DoIf(a0, a1, a2) => p.choice("DoIf", &[a0, a1, a2]),
            Do::DoIfLet(a0, a1, a2, a3) => p.choice("DoIfLet", &[a0, a1, a2, a3]),
            Do::DoMatch(a0, a1) => p.choice("DoMatch", &[a0, a1]),
            Do::DoReturn(a0) => p.choice("DoReturn", &[a0]),
            Do::DoBlock(a0) => p.choice("DoBlock", &[a0]),
            Do::DoScope(a0) => p.choice("DoScope", &[a0]),
            Do::DoLine(a0) => p.choice("DoLine", &[a0]),
            Do::DoNote(a0) => p.choice("DoNote", &[a0]),
        }
    }
}

impl ToPod for Do {
    fn to_pod(&self) -> Pod {
        match self {
            Do::DoLet(a0, a1) => Pod::Choice("DoLet".into(), vec![a0.to_pod(), a1.to_pod()]),
            Do::DoLetElse(a0, a1, a2) => Pod::Choice("DoLetElse".into(), vec![a0.to_pod(), a1.to_pod(), a2.to_pod()]),
            Do::DoAssign(a0, a1) => Pod::Choice("DoAssign".into(), vec![a0.to_pod(), a1.to_pod()]),
            Do::DoWhile(a0, a1) => Pod::Choice("DoWhile".into(), vec![a0.to_pod(), a1.to_pod()]),
            Do::DoWhileLet(a0, a1, a2) => Pod::Choice("DoWhileLet".into(), vec![a0.to_pod(), a1.to_pod(), a2.to_pod()]),
            Do::DoFor(a0, a1, a2) => Pod::Choice("DoFor".into(), vec![a0.to_pod(), a1.to_pod(), a2.to_pod()]),
            Do::DoExpr(a0) => Pod::Choice("DoExpr".into(), vec![a0.to_pod()]),
            Do::DoIf(a0, a1, a2) => Pod::Choice("DoIf".into(), vec![a0.to_pod(), a1.to_pod(), a2.to_pod()]),
            Do::DoIfLet(a0, a1, a2, a3) => Pod::Choice("DoIfLet".into(), vec![a0.to_pod(), a1.to_pod(), a2.to_pod(), a3.to_pod()]),
            Do::DoMatch(a0, a1) => Pod::Choice("DoMatch".into(), vec![a0.to_pod(), a1.to_pod()]),
            Do::DoReturn(a0) => Pod::Choice("DoReturn".into(), vec![a0.to_pod()]),
            Do::DoBlock(a0) => Pod::Choice("DoBlock".into(), vec![a0.to_pod()]),
            Do::DoScope(a0) => Pod::Choice("DoScope".into(), vec![a0.to_pod()]),
            Do::DoLine(a0) => Pod::Choice("DoLine".into(), vec![a0.to_pod()]),
            Do::DoNote(a0) => Pod::Choice("DoNote".into(), vec![a0.to_pod()]),
        }
    }
}

impl FromPod for Do {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "DoLet" && a.len() == 2 => Ok(Do::DoLet(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "DoLetElse" && a.len() == 3 => Ok(Do::DoLetElse(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?, FromPod::from_pod(&a[2])?)),
            Pod::Choice(c, a) if &**c == "DoAssign" && a.len() == 2 => Ok(Do::DoAssign(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "DoWhile" && a.len() == 2 => Ok(Do::DoWhile(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "DoWhileLet" && a.len() == 3 => Ok(Do::DoWhileLet(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?, FromPod::from_pod(&a[2])?)),
            Pod::Choice(c, a) if &**c == "DoFor" && a.len() == 3 => Ok(Do::DoFor(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?, FromPod::from_pod(&a[2])?)),
            Pod::Choice(c, a) if &**c == "DoExpr" && a.len() == 1 => Ok(Do::DoExpr(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "DoIf" && a.len() == 3 => Ok(Do::DoIf(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?, FromPod::from_pod(&a[2])?)),
            Pod::Choice(c, a) if &**c == "DoIfLet" && a.len() == 4 => Ok(Do::DoIfLet(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?, FromPod::from_pod(&a[2])?, FromPod::from_pod(&a[3])?)),
            Pod::Choice(c, a) if &**c == "DoMatch" && a.len() == 2 => Ok(Do::DoMatch(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "DoReturn" && a.len() == 1 => Ok(Do::DoReturn(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "DoBlock" && a.len() == 1 => Ok(Do::DoBlock(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "DoScope" && a.len() == 1 => Ok(Do::DoScope(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "DoLine" && a.len() == 1 => Ok(Do::DoLine(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "DoNote" && a.len() == 1 => Ok(Do::DoNote(FromPod::from_pod(&a[0])?)),
            other => mismatch("a Do", other),
        }
    }
}

/// `Ex`:
///
/// ```prism
/// type Ex = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum Ex {
    XVar(Text),
    XPath(Text),
    XSelf,
    XCx,
    XConst(Text),
    XUnit,
    XNone,
    XBool(bool),
    XNat(Text),
    XInt(Text),
    XByte(Text),
    XFloat(Text),
    XIndex(Nat),
    XChar(Text),
    XStr(Text),
    XRegex(Text, Text),
    XReplacement(Text, Text, Text),
    XRef(Rc<Ex>),
    XRefMut(Rc<Ex>),
    XDeref(Rc<Ex>),
    XTarget(Rc<Ex>),
    XClone(Rc<Ex>),
    XWeak(Rc<Ex>),
    XUpgrade(Rc<Ex>),
    XBreak(Text, Rc<Ex>),
    XBreakLoop,
    XLater(Rc<Ex>),
    XFormatStr(Array<Ex>),
    XIsCase(Rc<Ex>, Array<Text>),
    XRefusal(Text),
    XUnreachable,
    XCall(Text, Array<Ex>),
    XApply(Rc<Ex>, Array<Ex>),
    XMethod(Rc<Ex>, Text, Array<Ex>),
    XBin(Text, Rc<Ex>, Rc<Ex>),
    XUnary(Text, Rc<Ex>),
    XCtor(Text, Array<Ex>),
    XRecord(Text, Array<(Text, Ex)>),
    XTuple(Array<Ex>),
    XVec(Array<Ex>),
    XText(Text),
    XFormat(Array<Ex>),
    XMatch(Rc<Ex>, Array<XArm>, bool, OutTy),
    XChain(Text, Rc<Ex>, Array<XArm>, OutTy),
    XIf(Rc<Ex>, Rc<Ex>, Rc<Ex>),
    XBlock(Array<Do>, Rc<Ex>),
    XLabeled(Text, Array<Do>, Rc<Ex>, OutTy),
    XClosure(bool, Array<Pa>, Rc<Ex>),
    XTry(Rc<Ex>),
    XField(Rc<Ex>, Text),
    XPart(Rc<Ex>, Nat),
    XDecode(OutTy, Rc<Ex>),
    XCast(Rc<Ex>, OutTy),
    XTyped(Rc<Ex>, OutTy),
}

impl Show for Ex {
    fn show(&self, p: &mut Printer) {
        match self {
            Ex::XVar(a0) => p.choice("XVar", &[a0]),
            Ex::XPath(a0) => p.choice("XPath", &[a0]),
            Ex::XSelf => p.choice("XSelf", &[]),
            Ex::XCx => p.choice("XCx", &[]),
            Ex::XConst(a0) => p.choice("XConst", &[a0]),
            Ex::XUnit => p.choice("XUnit", &[]),
            Ex::XNone => p.choice("XNone", &[]),
            Ex::XBool(a0) => p.choice("XBool", &[a0]),
            Ex::XNat(a0) => p.choice("XNat", &[a0]),
            Ex::XInt(a0) => p.choice("XInt", &[a0]),
            Ex::XByte(a0) => p.choice("XByte", &[a0]),
            Ex::XFloat(a0) => p.choice("XFloat", &[a0]),
            Ex::XIndex(a0) => p.choice("XIndex", &[a0]),
            Ex::XChar(a0) => p.choice("XChar", &[a0]),
            Ex::XStr(a0) => p.choice("XStr", &[a0]),
            Ex::XRegex(a0, a1) => p.choice("XRegex", &[a0, a1]),
            Ex::XReplacement(a0, a1, a2) => p.choice("XReplacement", &[a0, a1, a2]),
            Ex::XRef(a0) => p.choice("XRef", &[a0]),
            Ex::XRefMut(a0) => p.choice("XRefMut", &[a0]),
            Ex::XDeref(a0) => p.choice("XDeref", &[a0]),
            Ex::XTarget(a0) => p.choice("XTarget", &[a0]),
            Ex::XClone(a0) => p.choice("XClone", &[a0]),
            Ex::XWeak(a0) => p.choice("XWeak", &[a0]),
            Ex::XUpgrade(a0) => p.choice("XUpgrade", &[a0]),
            Ex::XBreak(a0, a1) => p.choice("XBreak", &[a0, a1]),
            Ex::XBreakLoop => p.choice("XBreakLoop", &[]),
            Ex::XLater(a0) => p.choice("XLater", &[a0]),
            Ex::XFormatStr(a0) => p.choice("XFormatStr", &[a0]),
            Ex::XIsCase(a0, a1) => p.choice("XIsCase", &[a0, a1]),
            Ex::XRefusal(a0) => p.choice("XRefusal", &[a0]),
            Ex::XUnreachable => p.choice("XUnreachable", &[]),
            Ex::XCall(a0, a1) => p.choice("XCall", &[a0, a1]),
            Ex::XApply(a0, a1) => p.choice("XApply", &[a0, a1]),
            Ex::XMethod(a0, a1, a2) => p.choice("XMethod", &[a0, a1, a2]),
            Ex::XBin(a0, a1, a2) => p.choice("XBin", &[a0, a1, a2]),
            Ex::XUnary(a0, a1) => p.choice("XUnary", &[a0, a1]),
            Ex::XCtor(a0, a1) => p.choice("XCtor", &[a0, a1]),
            Ex::XRecord(a0, a1) => p.choice("XRecord", &[a0, a1]),
            Ex::XTuple(a0) => p.choice("XTuple", &[a0]),
            Ex::XVec(a0) => p.choice("XVec", &[a0]),
            Ex::XText(a0) => p.choice("XText", &[a0]),
            Ex::XFormat(a0) => p.choice("XFormat", &[a0]),
            Ex::XMatch(a0, a1, a2, a3) => p.choice("XMatch", &[a0, a1, a2, a3]),
            Ex::XChain(a0, a1, a2, a3) => p.choice("XChain", &[a0, a1, a2, a3]),
            Ex::XIf(a0, a1, a2) => p.choice("XIf", &[a0, a1, a2]),
            Ex::XBlock(a0, a1) => p.choice("XBlock", &[a0, a1]),
            Ex::XLabeled(a0, a1, a2, a3) => p.choice("XLabeled", &[a0, a1, a2, a3]),
            Ex::XClosure(a0, a1, a2) => p.choice("XClosure", &[a0, a1, a2]),
            Ex::XTry(a0) => p.choice("XTry", &[a0]),
            Ex::XField(a0, a1) => p.choice("XField", &[a0, a1]),
            Ex::XPart(a0, a1) => p.choice("XPart", &[a0, a1]),
            Ex::XDecode(a0, a1) => p.choice("XDecode", &[a0, a1]),
            Ex::XCast(a0, a1) => p.choice("XCast", &[a0, a1]),
            Ex::XTyped(a0, a1) => p.choice("XTyped", &[a0, a1]),
        }
    }
}

impl ToPod for Ex {
    fn to_pod(&self) -> Pod {
        match self {
            Ex::XVar(a0) => Pod::Choice("XVar".into(), vec![a0.to_pod()]),
            Ex::XPath(a0) => Pod::Choice("XPath".into(), vec![a0.to_pod()]),
            Ex::XSelf => Pod::Choice("XSelf".into(), vec![]),
            Ex::XCx => Pod::Choice("XCx".into(), vec![]),
            Ex::XConst(a0) => Pod::Choice("XConst".into(), vec![a0.to_pod()]),
            Ex::XUnit => Pod::Choice("XUnit".into(), vec![]),
            Ex::XNone => Pod::Choice("XNone".into(), vec![]),
            Ex::XBool(a0) => Pod::Choice("XBool".into(), vec![a0.to_pod()]),
            Ex::XNat(a0) => Pod::Choice("XNat".into(), vec![a0.to_pod()]),
            Ex::XInt(a0) => Pod::Choice("XInt".into(), vec![a0.to_pod()]),
            Ex::XByte(a0) => Pod::Choice("XByte".into(), vec![a0.to_pod()]),
            Ex::XFloat(a0) => Pod::Choice("XFloat".into(), vec![a0.to_pod()]),
            Ex::XIndex(a0) => Pod::Choice("XIndex".into(), vec![a0.to_pod()]),
            Ex::XChar(a0) => Pod::Choice("XChar".into(), vec![a0.to_pod()]),
            Ex::XStr(a0) => Pod::Choice("XStr".into(), vec![a0.to_pod()]),
            Ex::XRegex(a0, a1) => Pod::Choice("XRegex".into(), vec![a0.to_pod(), a1.to_pod()]),
            Ex::XReplacement(a0, a1, a2) => Pod::Choice("XReplacement".into(), vec![a0.to_pod(), a1.to_pod(), a2.to_pod()]),
            Ex::XRef(a0) => Pod::Choice("XRef".into(), vec![a0.to_pod()]),
            Ex::XRefMut(a0) => Pod::Choice("XRefMut".into(), vec![a0.to_pod()]),
            Ex::XDeref(a0) => Pod::Choice("XDeref".into(), vec![a0.to_pod()]),
            Ex::XTarget(a0) => Pod::Choice("XTarget".into(), vec![a0.to_pod()]),
            Ex::XClone(a0) => Pod::Choice("XClone".into(), vec![a0.to_pod()]),
            Ex::XWeak(a0) => Pod::Choice("XWeak".into(), vec![a0.to_pod()]),
            Ex::XUpgrade(a0) => Pod::Choice("XUpgrade".into(), vec![a0.to_pod()]),
            Ex::XBreak(a0, a1) => Pod::Choice("XBreak".into(), vec![a0.to_pod(), a1.to_pod()]),
            Ex::XBreakLoop => Pod::Choice("XBreakLoop".into(), vec![]),
            Ex::XLater(a0) => Pod::Choice("XLater".into(), vec![a0.to_pod()]),
            Ex::XFormatStr(a0) => Pod::Choice("XFormatStr".into(), vec![a0.to_pod()]),
            Ex::XIsCase(a0, a1) => Pod::Choice("XIsCase".into(), vec![a0.to_pod(), a1.to_pod()]),
            Ex::XRefusal(a0) => Pod::Choice("XRefusal".into(), vec![a0.to_pod()]),
            Ex::XUnreachable => Pod::Choice("XUnreachable".into(), vec![]),
            Ex::XCall(a0, a1) => Pod::Choice("XCall".into(), vec![a0.to_pod(), a1.to_pod()]),
            Ex::XApply(a0, a1) => Pod::Choice("XApply".into(), vec![a0.to_pod(), a1.to_pod()]),
            Ex::XMethod(a0, a1, a2) => Pod::Choice("XMethod".into(), vec![a0.to_pod(), a1.to_pod(), a2.to_pod()]),
            Ex::XBin(a0, a1, a2) => Pod::Choice("XBin".into(), vec![a0.to_pod(), a1.to_pod(), a2.to_pod()]),
            Ex::XUnary(a0, a1) => Pod::Choice("XUnary".into(), vec![a0.to_pod(), a1.to_pod()]),
            Ex::XCtor(a0, a1) => Pod::Choice("XCtor".into(), vec![a0.to_pod(), a1.to_pod()]),
            Ex::XRecord(a0, a1) => Pod::Choice("XRecord".into(), vec![a0.to_pod(), a1.to_pod()]),
            Ex::XTuple(a0) => Pod::Choice("XTuple".into(), vec![a0.to_pod()]),
            Ex::XVec(a0) => Pod::Choice("XVec".into(), vec![a0.to_pod()]),
            Ex::XText(a0) => Pod::Choice("XText".into(), vec![a0.to_pod()]),
            Ex::XFormat(a0) => Pod::Choice("XFormat".into(), vec![a0.to_pod()]),
            Ex::XMatch(a0, a1, a2, a3) => Pod::Choice("XMatch".into(), vec![a0.to_pod(), a1.to_pod(), a2.to_pod(), a3.to_pod()]),
            Ex::XChain(a0, a1, a2, a3) => Pod::Choice("XChain".into(), vec![a0.to_pod(), a1.to_pod(), a2.to_pod(), a3.to_pod()]),
            Ex::XIf(a0, a1, a2) => Pod::Choice("XIf".into(), vec![a0.to_pod(), a1.to_pod(), a2.to_pod()]),
            Ex::XBlock(a0, a1) => Pod::Choice("XBlock".into(), vec![a0.to_pod(), a1.to_pod()]),
            Ex::XLabeled(a0, a1, a2, a3) => Pod::Choice("XLabeled".into(), vec![a0.to_pod(), a1.to_pod(), a2.to_pod(), a3.to_pod()]),
            Ex::XClosure(a0, a1, a2) => Pod::Choice("XClosure".into(), vec![a0.to_pod(), a1.to_pod(), a2.to_pod()]),
            Ex::XTry(a0) => Pod::Choice("XTry".into(), vec![a0.to_pod()]),
            Ex::XField(a0, a1) => Pod::Choice("XField".into(), vec![a0.to_pod(), a1.to_pod()]),
            Ex::XPart(a0, a1) => Pod::Choice("XPart".into(), vec![a0.to_pod(), a1.to_pod()]),
            Ex::XDecode(a0, a1) => Pod::Choice("XDecode".into(), vec![a0.to_pod(), a1.to_pod()]),
            Ex::XCast(a0, a1) => Pod::Choice("XCast".into(), vec![a0.to_pod(), a1.to_pod()]),
            Ex::XTyped(a0, a1) => Pod::Choice("XTyped".into(), vec![a0.to_pod(), a1.to_pod()]),
        }
    }
}

impl FromPod for Ex {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "XVar" && a.len() == 1 => Ok(Ex::XVar(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "XPath" && a.len() == 1 => Ok(Ex::XPath(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "XSelf" && a.len() == 0 => Ok(Ex::XSelf),
            Pod::Choice(c, a) if &**c == "XCx" && a.len() == 0 => Ok(Ex::XCx),
            Pod::Choice(c, a) if &**c == "XConst" && a.len() == 1 => Ok(Ex::XConst(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "XUnit" && a.len() == 0 => Ok(Ex::XUnit),
            Pod::Choice(c, a) if &**c == "XNone" && a.len() == 0 => Ok(Ex::XNone),
            Pod::Choice(c, a) if &**c == "XBool" && a.len() == 1 => Ok(Ex::XBool(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "XNat" && a.len() == 1 => Ok(Ex::XNat(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "XInt" && a.len() == 1 => Ok(Ex::XInt(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "XByte" && a.len() == 1 => Ok(Ex::XByte(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "XFloat" && a.len() == 1 => Ok(Ex::XFloat(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "XIndex" && a.len() == 1 => Ok(Ex::XIndex(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "XChar" && a.len() == 1 => Ok(Ex::XChar(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "XStr" && a.len() == 1 => Ok(Ex::XStr(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "XRegex" && a.len() == 2 => Ok(Ex::XRegex(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "XReplacement" && a.len() == 3 => Ok(Ex::XReplacement(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?, FromPod::from_pod(&a[2])?)),
            Pod::Choice(c, a) if &**c == "XRef" && a.len() == 1 => Ok(Ex::XRef(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "XRefMut" && a.len() == 1 => Ok(Ex::XRefMut(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "XDeref" && a.len() == 1 => Ok(Ex::XDeref(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "XTarget" && a.len() == 1 => Ok(Ex::XTarget(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "XClone" && a.len() == 1 => Ok(Ex::XClone(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "XWeak" && a.len() == 1 => Ok(Ex::XWeak(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "XUpgrade" && a.len() == 1 => Ok(Ex::XUpgrade(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "XBreak" && a.len() == 2 => Ok(Ex::XBreak(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "XBreakLoop" && a.len() == 0 => Ok(Ex::XBreakLoop),
            Pod::Choice(c, a) if &**c == "XLater" && a.len() == 1 => Ok(Ex::XLater(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "XFormatStr" && a.len() == 1 => Ok(Ex::XFormatStr(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "XIsCase" && a.len() == 2 => Ok(Ex::XIsCase(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "XRefusal" && a.len() == 1 => Ok(Ex::XRefusal(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "XUnreachable" && a.len() == 0 => Ok(Ex::XUnreachable),
            Pod::Choice(c, a) if &**c == "XCall" && a.len() == 2 => Ok(Ex::XCall(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "XApply" && a.len() == 2 => Ok(Ex::XApply(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "XMethod" && a.len() == 3 => Ok(Ex::XMethod(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?, FromPod::from_pod(&a[2])?)),
            Pod::Choice(c, a) if &**c == "XBin" && a.len() == 3 => Ok(Ex::XBin(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?, FromPod::from_pod(&a[2])?)),
            Pod::Choice(c, a) if &**c == "XUnary" && a.len() == 2 => Ok(Ex::XUnary(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "XCtor" && a.len() == 2 => Ok(Ex::XCtor(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "XRecord" && a.len() == 2 => Ok(Ex::XRecord(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "XTuple" && a.len() == 1 => Ok(Ex::XTuple(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "XVec" && a.len() == 1 => Ok(Ex::XVec(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "XText" && a.len() == 1 => Ok(Ex::XText(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "XFormat" && a.len() == 1 => Ok(Ex::XFormat(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "XMatch" && a.len() == 4 => Ok(Ex::XMatch(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?, FromPod::from_pod(&a[2])?, FromPod::from_pod(&a[3])?)),
            Pod::Choice(c, a) if &**c == "XChain" && a.len() == 4 => Ok(Ex::XChain(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?, FromPod::from_pod(&a[2])?, FromPod::from_pod(&a[3])?)),
            Pod::Choice(c, a) if &**c == "XIf" && a.len() == 3 => Ok(Ex::XIf(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?, FromPod::from_pod(&a[2])?)),
            Pod::Choice(c, a) if &**c == "XBlock" && a.len() == 2 => Ok(Ex::XBlock(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "XLabeled" && a.len() == 4 => Ok(Ex::XLabeled(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?, FromPod::from_pod(&a[2])?, FromPod::from_pod(&a[3])?)),
            Pod::Choice(c, a) if &**c == "XClosure" && a.len() == 3 => Ok(Ex::XClosure(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?, FromPod::from_pod(&a[2])?)),
            Pod::Choice(c, a) if &**c == "XTry" && a.len() == 1 => Ok(Ex::XTry(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "XField" && a.len() == 2 => Ok(Ex::XField(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "XPart" && a.len() == 2 => Ok(Ex::XPart(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "XDecode" && a.len() == 2 => Ok(Ex::XDecode(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "XCast" && a.len() == 2 => Ok(Ex::XCast(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "XTyped" && a.len() == 2 => Ok(Ex::XTyped(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            other => mismatch("a Ex", other),
        }
    }
}

/// `FnDef`:
///
/// ```prism
/// type FnDef = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct FnDef {
    pub name: Text,
    pub generics: Array<(Text, Array<Text>)>,
    pub params: Array<(Text, OutTy)>,
    pub ret: OutTy,
    pub body: Ex,
    pub doc: Text,
    pub public: bool,
}

impl Show for FnDef {
    fn show(&self, p: &mut Printer) {
        p.record("FnDef", &[("name", &self.name), ("generics", &self.generics), ("params", &self.params), ("ret", &self.ret), ("body", &self.body), ("doc", &self.doc), ("public", &self.public)]);
    }
}

impl ToPod for FnDef {
    fn to_pod(&self) -> Pod {
        Pod::record("FnDef", vec![("name", self.name.to_pod()), ("generics", self.generics.to_pod()), ("params", self.params.to_pod()), ("ret", self.ret.to_pod()), ("body", self.body.to_pod()), ("doc", self.doc.to_pod()), ("public", self.public.to_pod())])
    }
}

impl FromPod for FnDef {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(FnDef { name: FromPod::from_pod(field(p, "name")?)?, generics: FromPod::from_pod(field(p, "generics")?)?, params: FromPod::from_pod(field(p, "params")?)?, ret: FromPod::from_pod(field(p, "ret")?)?, body: FromPod::from_pod(field(p, "body")?)?, doc: FromPod::from_pod(field(p, "doc")?)?, public: FromPod::from_pod(field(p, "public")?)? })
    }
}

/// `ForDef`:
///
/// ```prism
/// type ForDef = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct ForDef {
    pub name: Text,
    pub pos: Pos_,
    pub at: Ex,
    pub key_ty: OutTy,
    pub value_ty: OutTy,
    pub row_node: Text,
    pub keyed: bool,
    pub source: Text,
    pub parent: Ex,
    pub passed: Array<Ex>,
    pub moved: Text,
    pub replaced: Array<Text>,
}

impl Show for ForDef {
    fn show(&self, p: &mut Printer) {
        p.record("ForDef", &[("name", &self.name), ("pos", &self.pos), ("at", &self.at), ("key_ty", &self.key_ty), ("value_ty", &self.value_ty), ("row_node", &self.row_node), ("keyed", &self.keyed), ("source", &self.source), ("parent", &self.parent), ("passed", &self.passed), ("moved", &self.moved), ("replaced", &self.replaced)]);
    }
}

impl ToPod for ForDef {
    fn to_pod(&self) -> Pod {
        Pod::record("ForDef", vec![("name", self.name.to_pod()), ("pos", self.pos.to_pod()), ("at", self.at.to_pod()), ("key_ty", self.key_ty.to_pod()), ("value_ty", self.value_ty.to_pod()), ("row_node", self.row_node.to_pod()), ("keyed", self.keyed.to_pod()), ("source", self.source.to_pod()), ("parent", self.parent.to_pod()), ("passed", self.passed.to_pod()), ("moved", self.moved.to_pod()), ("replaced", self.replaced.to_pod())])
    }
}

impl FromPod for ForDef {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(ForDef { name: FromPod::from_pod(field(p, "name")?)?, pos: FromPod::from_pod(field(p, "pos")?)?, at: FromPod::from_pod(field(p, "at")?)?, key_ty: FromPod::from_pod(field(p, "key_ty")?)?, value_ty: FromPod::from_pod(field(p, "value_ty")?)?, row_node: FromPod::from_pod(field(p, "row_node")?)?, keyed: FromPod::from_pod(field(p, "keyed")?)?, source: FromPod::from_pod(field(p, "source")?)?, parent: FromPod::from_pod(field(p, "parent")?)?, passed: FromPod::from_pod(field(p, "passed")?)?, moved: FromPod::from_pod(field(p, "moved")?)?, replaced: FromPod::from_pod(field(p, "replaced")?)? })
    }
}

/// `GenDef`:
///
/// ```prism
/// type GenDef = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct GenDef {
    pub name: Text,
    pub pos: Pos_,
    pub at: Ex,
    pub source: Ex,
    pub value_ty: OutTy,
    pub select: Ex,
    pub transparent: bool,
    pub width: Nat,
    pub moved: Text,
}

impl Show for GenDef {
    fn show(&self, p: &mut Printer) {
        p.record("GenDef", &[("name", &self.name), ("pos", &self.pos), ("at", &self.at), ("source", &self.source), ("value_ty", &self.value_ty), ("select", &self.select), ("transparent", &self.transparent), ("width", &self.width), ("moved", &self.moved)]);
    }
}

impl ToPod for GenDef {
    fn to_pod(&self) -> Pod {
        Pod::record("GenDef", vec![("name", self.name.to_pod()), ("pos", self.pos.to_pod()), ("at", self.at.to_pod()), ("source", self.source.to_pod()), ("value_ty", self.value_ty.to_pod()), ("select", self.select.to_pod()), ("transparent", self.transparent.to_pod()), ("width", self.width.to_pod()), ("moved", self.moved.to_pod())])
    }
}

impl FromPod for GenDef {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(GenDef { name: FromPod::from_pod(field(p, "name")?)?, pos: FromPod::from_pod(field(p, "pos")?)?, at: FromPod::from_pod(field(p, "at")?)?, source: FromPod::from_pod(field(p, "source")?)?, value_ty: FromPod::from_pod(field(p, "value_ty")?)?, select: FromPod::from_pod(field(p, "select")?)?, transparent: FromPod::from_pod(field(p, "transparent")?)?, width: FromPod::from_pod(field(p, "width")?)?, moved: FromPod::from_pod(field(p, "moved")?)? })
    }
}

/// `ImplDef`:
///
/// ```prism
/// type ImplDef = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct ImplDef {
    pub cls: Text,
    pub tr: Text,
    pub head: OutTy,
    pub generics: Array<(Text, Array<Text>)>,
    pub methods: Array<FnDef>,
    pub doc: Text,
}

impl Show for ImplDef {
    fn show(&self, p: &mut Printer) {
        p.record("ImplDef", &[("cls", &self.cls), ("tr", &self.tr), ("head", &self.head), ("generics", &self.generics), ("methods", &self.methods), ("doc", &self.doc)]);
    }
}

impl ToPod for ImplDef {
    fn to_pod(&self) -> Pod {
        Pod::record("ImplDef", vec![("cls", self.cls.to_pod()), ("tr", self.tr.to_pod()), ("head", self.head.to_pod()), ("generics", self.generics.to_pod()), ("methods", self.methods.to_pod()), ("doc", self.doc.to_pod())])
    }
}

impl FromPod for ImplDef {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(ImplDef { cls: FromPod::from_pod(field(p, "cls")?)?, tr: FromPod::from_pod(field(p, "tr")?)?, head: FromPod::from_pod(field(p, "head")?)?, generics: FromPod::from_pod(field(p, "generics")?)?, methods: FromPod::from_pod(field(p, "methods")?)?, doc: FromPod::from_pod(field(p, "doc")?)? })
    }
}

/// `Item`:
///
/// ```prism
/// type Item = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum Item {
    ItTrait(TraitDef),
    ItImpl(ImplDef),
    ItType(TyDef),
    ItTag(TagDef),
    ItRow(RowDef),
    ItFn(FnDef),
    ItJob(JobDef),
    ItNode(NodeDef),
    ItNote(Text),
    ItRefused(Text),
}

impl Show for Item {
    fn show(&self, p: &mut Printer) {
        match self {
            Item::ItTrait(a0) => p.choice("ItTrait", &[a0]),
            Item::ItImpl(a0) => p.choice("ItImpl", &[a0]),
            Item::ItType(a0) => p.choice("ItType", &[a0]),
            Item::ItTag(a0) => p.choice("ItTag", &[a0]),
            Item::ItRow(a0) => p.choice("ItRow", &[a0]),
            Item::ItFn(a0) => p.choice("ItFn", &[a0]),
            Item::ItJob(a0) => p.choice("ItJob", &[a0]),
            Item::ItNode(a0) => p.choice("ItNode", &[a0]),
            Item::ItNote(a0) => p.choice("ItNote", &[a0]),
            Item::ItRefused(a0) => p.choice("ItRefused", &[a0]),
        }
    }
}

impl ToPod for Item {
    fn to_pod(&self) -> Pod {
        match self {
            Item::ItTrait(a0) => Pod::Choice("ItTrait".into(), vec![a0.to_pod()]),
            Item::ItImpl(a0) => Pod::Choice("ItImpl".into(), vec![a0.to_pod()]),
            Item::ItType(a0) => Pod::Choice("ItType".into(), vec![a0.to_pod()]),
            Item::ItTag(a0) => Pod::Choice("ItTag".into(), vec![a0.to_pod()]),
            Item::ItRow(a0) => Pod::Choice("ItRow".into(), vec![a0.to_pod()]),
            Item::ItFn(a0) => Pod::Choice("ItFn".into(), vec![a0.to_pod()]),
            Item::ItJob(a0) => Pod::Choice("ItJob".into(), vec![a0.to_pod()]),
            Item::ItNode(a0) => Pod::Choice("ItNode".into(), vec![a0.to_pod()]),
            Item::ItNote(a0) => Pod::Choice("ItNote".into(), vec![a0.to_pod()]),
            Item::ItRefused(a0) => Pod::Choice("ItRefused".into(), vec![a0.to_pod()]),
        }
    }
}

impl FromPod for Item {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "ItTrait" && a.len() == 1 => Ok(Item::ItTrait(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "ItImpl" && a.len() == 1 => Ok(Item::ItImpl(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "ItType" && a.len() == 1 => Ok(Item::ItType(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "ItTag" && a.len() == 1 => Ok(Item::ItTag(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "ItRow" && a.len() == 1 => Ok(Item::ItRow(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "ItFn" && a.len() == 1 => Ok(Item::ItFn(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "ItJob" && a.len() == 1 => Ok(Item::ItJob(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "ItNode" && a.len() == 1 => Ok(Item::ItNode(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "ItNote" && a.len() == 1 => Ok(Item::ItNote(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "ItRefused" && a.len() == 1 => Ok(Item::ItRefused(FromPod::from_pod(&a[0])?)),
            other => mismatch("a Item", other),
        }
    }
}

/// `JobDef`:
///
/// ```prism
/// type JobDef = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct JobDef {
    pub name: Text,
    pub start: Text,
    pub generics: Array<(Text, Array<Text>)>,
    pub fields: Array<(Text, OutTy)>,
    pub ret: OutTy,
    pub body: Ex,
    pub doc: Text,
}

impl Show for JobDef {
    fn show(&self, p: &mut Printer) {
        p.record("JobDef", &[("name", &self.name), ("start", &self.start), ("generics", &self.generics), ("fields", &self.fields), ("ret", &self.ret), ("body", &self.body), ("doc", &self.doc)]);
    }
}

impl ToPod for JobDef {
    fn to_pod(&self) -> Pod {
        Pod::record("JobDef", vec![("name", self.name.to_pod()), ("start", self.start.to_pod()), ("generics", self.generics.to_pod()), ("fields", self.fields.to_pod()), ("ret", self.ret.to_pod()), ("body", self.body.to_pod()), ("doc", self.doc.to_pod())])
    }
}

impl FromPod for JobDef {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(JobDef { name: FromPod::from_pod(field(p, "name")?)?, start: FromPod::from_pod(field(p, "start")?)?, generics: FromPod::from_pod(field(p, "generics")?)?, fields: FromPod::from_pod(field(p, "fields")?)?, ret: FromPod::from_pod(field(p, "ret")?)?, body: FromPod::from_pod(field(p, "body")?)?, doc: FromPod::from_pod(field(p, "doc")?)? })
    }
}

/// `MethDef`:
///
/// ```prism
/// type MethDef = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct MethDef {
    pub name: Text,
    pub recv: Recv,
    pub params: Array<(Text, OutTy)>,
    pub cx_: CxArg,
    pub ret: OutTy,
    pub body: Array<Do>,
    pub tail: Ex,
    pub doc: Text,
}

impl Show for MethDef {
    fn show(&self, p: &mut Printer) {
        p.record("MethDef", &[("name", &self.name), ("recv", &self.recv), ("params", &self.params), ("cx", &self.cx_), ("ret", &self.ret), ("body", &self.body), ("tail", &self.tail), ("doc", &self.doc)]);
    }
}

impl ToPod for MethDef {
    fn to_pod(&self) -> Pod {
        Pod::record("MethDef", vec![("name", self.name.to_pod()), ("recv", self.recv.to_pod()), ("params", self.params.to_pod()), ("cx", self.cx_.to_pod()), ("ret", self.ret.to_pod()), ("body", self.body.to_pod()), ("tail", self.tail.to_pod()), ("doc", self.doc.to_pod())])
    }
}

impl FromPod for MethDef {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(MethDef { name: FromPod::from_pod(field(p, "name")?)?, recv: FromPod::from_pod(field(p, "recv")?)?, params: FromPod::from_pod(field(p, "params")?)?, cx_: FromPod::from_pod(field(p, "cx")?)?, ret: FromPod::from_pod(field(p, "ret")?)?, body: FromPod::from_pod(field(p, "body")?)?, tail: FromPod::from_pod(field(p, "tail")?)?, doc: FromPod::from_pod(field(p, "doc")?)? })
    }
}

/// `ModDef`:
///
/// ```prism
/// type ModDef = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct ModDef {
    pub name: Text,
    pub prism: Text,
    pub path_: Text,
    pub uses: Array<Text>,
    pub complete: Array<Text>,
    pub declared: Array<Text>,
    pub types_with: Array<Text>,
    pub items: Array<Item>,
}

impl Show for ModDef {
    fn show(&self, p: &mut Printer) {
        p.record("ModDef", &[("name", &self.name), ("prism", &self.prism), ("path", &self.path_), ("uses", &self.uses), ("complete", &self.complete), ("declared", &self.declared), ("types_with", &self.types_with), ("items", &self.items)]);
    }
}

impl ToPod for ModDef {
    fn to_pod(&self) -> Pod {
        Pod::record("ModDef", vec![("name", self.name.to_pod()), ("prism", self.prism.to_pod()), ("path", self.path_.to_pod()), ("uses", self.uses.to_pod()), ("complete", self.complete.to_pod()), ("declared", self.declared.to_pod()), ("types_with", self.types_with.to_pod()), ("items", self.items.to_pod())])
    }
}

impl FromPod for ModDef {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(ModDef { name: FromPod::from_pod(field(p, "name")?)?, prism: FromPod::from_pod(field(p, "prism")?)?, path_: FromPod::from_pod(field(p, "path")?)?, uses: FromPod::from_pod(field(p, "uses")?)?, complete: FromPod::from_pod(field(p, "complete")?)?, declared: FromPod::from_pod(field(p, "declared")?)?, types_with: FromPod::from_pod(field(p, "types_with")?)?, items: FromPod::from_pod(field(p, "items")?)? })
    }
}

/// `Model`:
///
/// ```prism
/// type Model = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Model {
    pub name: Text,
    pub mods: Array<ModDef>,
    pub programs: Array<ProgDef>,
    pub root: Option<ProgDef>,
    pub checks: Array<CheckDef>,
    pub elem: RowDef,
    pub answer: AnswerDef,
    pub elem_complete: Array<Text>,
    pub elem_declared: Array<Text>,
    pub scripts: Array<Text>,
    pub notes: Array<Text>,
}

impl Show for Model {
    fn show(&self, p: &mut Printer) {
        p.record("Model", &[("name", &self.name), ("mods", &self.mods), ("programs", &self.programs), ("root", &self.root), ("checks", &self.checks), ("elem", &self.elem), ("answer", &self.answer), ("elem_complete", &self.elem_complete), ("elem_declared", &self.elem_declared), ("scripts", &self.scripts), ("notes", &self.notes)]);
    }
}

impl ToPod for Model {
    fn to_pod(&self) -> Pod {
        Pod::record("Model", vec![("name", self.name.to_pod()), ("mods", self.mods.to_pod()), ("programs", self.programs.to_pod()), ("root", self.root.to_pod()), ("checks", self.checks.to_pod()), ("elem", self.elem.to_pod()), ("answer", self.answer.to_pod()), ("elem_complete", self.elem_complete.to_pod()), ("elem_declared", self.elem_declared.to_pod()), ("scripts", self.scripts.to_pod()), ("notes", self.notes.to_pod())])
    }
}

impl FromPod for Model {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Model { name: FromPod::from_pod(field(p, "name")?)?, mods: FromPod::from_pod(field(p, "mods")?)?, programs: FromPod::from_pod(field(p, "programs")?)?, root: FromPod::from_pod(field(p, "root")?)?, checks: FromPod::from_pod(field(p, "checks")?)?, elem: FromPod::from_pod(field(p, "elem")?)?, answer: FromPod::from_pod(field(p, "answer")?)?, elem_complete: FromPod::from_pod(field(p, "elem_complete")?)?, elem_declared: FromPod::from_pod(field(p, "elem_declared")?)?, scripts: FromPod::from_pod(field(p, "scripts")?)?, notes: FromPod::from_pod(field(p, "notes")?)? })
    }
}

/// `NodeDef`:
///
/// ```prism
/// type NodeDef = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct NodeDef {
    pub name: Text,
    pub prism: Text,
    pub doc: Text,
    pub params: Array<(Text, OutTy)>,
    pub fields: Array<(Text, OutTy, Text)>,
    pub consts: Array<(Text, Nat, Text)>,
    pub lets: Array<Do>,
    pub inits: Array<(Text, Ex)>,
    pub build: Array<Do>,
    pub fallible: bool,
    pub methods: Array<MethDef>,
    pub answers: Array<(Pa, Ex)>,
    pub hooks: Array<(Text, Array<Do>)>,
    pub builders: Array<ForDef>,
    pub wakes: bool,
    pub children: Array<NodeDef>,
    pub gens: Array<GenDef>,
    pub subs: Array<(Text, Text, OutTy)>,
    pub top: Nat,
    pub row_kind: RowKind,
    pub hosted: Array<MethDef>,
}

impl Show for NodeDef {
    fn show(&self, p: &mut Printer) {
        p.record("NodeDef", &[("name", &self.name), ("prism", &self.prism), ("doc", &self.doc), ("params", &self.params), ("fields", &self.fields), ("consts", &self.consts), ("lets", &self.lets), ("inits", &self.inits), ("build", &self.build), ("fallible", &self.fallible), ("methods", &self.methods), ("answers", &self.answers), ("hooks", &self.hooks), ("builders", &self.builders), ("wakes", &self.wakes), ("children", &self.children), ("gens", &self.gens), ("subs", &self.subs), ("top", &self.top), ("row_kind", &self.row_kind), ("hosted", &self.hosted)]);
    }
}

impl ToPod for NodeDef {
    fn to_pod(&self) -> Pod {
        Pod::record("NodeDef", vec![("name", self.name.to_pod()), ("prism", self.prism.to_pod()), ("doc", self.doc.to_pod()), ("params", self.params.to_pod()), ("fields", self.fields.to_pod()), ("consts", self.consts.to_pod()), ("lets", self.lets.to_pod()), ("inits", self.inits.to_pod()), ("build", self.build.to_pod()), ("fallible", self.fallible.to_pod()), ("methods", self.methods.to_pod()), ("answers", self.answers.to_pod()), ("hooks", self.hooks.to_pod()), ("builders", self.builders.to_pod()), ("wakes", self.wakes.to_pod()), ("children", self.children.to_pod()), ("gens", self.gens.to_pod()), ("subs", self.subs.to_pod()), ("top", self.top.to_pod()), ("row_kind", self.row_kind.to_pod()), ("hosted", self.hosted.to_pod())])
    }
}

impl FromPod for NodeDef {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(NodeDef { name: FromPod::from_pod(field(p, "name")?)?, prism: FromPod::from_pod(field(p, "prism")?)?, doc: FromPod::from_pod(field(p, "doc")?)?, params: FromPod::from_pod(field(p, "params")?)?, fields: FromPod::from_pod(field(p, "fields")?)?, consts: FromPod::from_pod(field(p, "consts")?)?, lets: FromPod::from_pod(field(p, "lets")?)?, inits: FromPod::from_pod(field(p, "inits")?)?, build: FromPod::from_pod(field(p, "build")?)?, fallible: FromPod::from_pod(field(p, "fallible")?)?, methods: FromPod::from_pod(field(p, "methods")?)?, answers: FromPod::from_pod(field(p, "answers")?)?, hooks: FromPod::from_pod(field(p, "hooks")?)?, builders: FromPod::from_pod(field(p, "builders")?)?, wakes: FromPod::from_pod(field(p, "wakes")?)?, children: FromPod::from_pod(field(p, "children")?)?, gens: FromPod::from_pod(field(p, "gens")?)?, subs: FromPod::from_pod(field(p, "subs")?)?, top: FromPod::from_pod(field(p, "top")?)?, row_kind: FromPod::from_pod(field(p, "row_kind")?)?, hosted: FromPod::from_pod(field(p, "hosted")?)? })
    }
}

/// `OutTy`:
///
/// ```prism
/// type OutTy = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum OutTy {
    OutNat,
    OutInt,
    OutU8,
    OutFloat,
    OutBool,
    OutChar,
    OutText,
    OutCursor,
    OutRegex,
    OutReplacement,
    OutUnit,
    OutPath,
    OutDuration,
    OutError,
    OutNamed(Text, Array<OutTy>),
    OutOpt(Rc<OutTy>),
    OutRes(Rc<OutTy>),
    OutTuple(Array<OutTy>),
    OutArray(Rc<OutTy>),
    OutMap(Rc<OutTy>, Rc<OutTy>),
    OutFn(Array<OutTy>, Rc<OutTy>),
    OutJobFn(Rc<OutTy>, Rc<OutTy>),
    OutJob(Rc<OutTy>),
    OutEvent(Rc<OutTy>),
    OutDyn(Rc<OutTy>),
    OutGen(Text),
    OutRc(Rc<OutTy>),
    OutRef(Rc<OutTy>),
    OutPod,
    OutShowAny,
    OutHold(Rc<OutTy>),
    OutStamped(Rc<OutTy>),
    OutSnapshot(Rc<OutTy>),
    OutDefer(Rc<OutTy>),
    OutWeak(Text),
    OutCell(Rc<OutTy>),
    OutWakes,
    OutCount,
    OutObj(Rc<OutTy>),
    OutSlice(Rc<OutTy>),
    OutPort(Rc<OutTy>),
    OutLive(Rc<OutTy>),
    OutQuantified(Text),
    OutUnknown(Text),
}

impl Show for OutTy {
    fn show(&self, p: &mut Printer) {
        match self {
            OutTy::OutNat => p.choice("OutNat", &[]),
            OutTy::OutInt => p.choice("OutInt", &[]),
            OutTy::OutU8 => p.choice("OutU8", &[]),
            OutTy::OutFloat => p.choice("OutFloat", &[]),
            OutTy::OutBool => p.choice("OutBool", &[]),
            OutTy::OutChar => p.choice("OutChar", &[]),
            OutTy::OutText => p.choice("OutText", &[]),
            OutTy::OutCursor => p.choice("OutCursor", &[]),
            OutTy::OutRegex => p.choice("OutRegex", &[]),
            OutTy::OutReplacement => p.choice("OutReplacement", &[]),
            OutTy::OutUnit => p.choice("OutUnit", &[]),
            OutTy::OutPath => p.choice("OutPath", &[]),
            OutTy::OutDuration => p.choice("OutDuration", &[]),
            OutTy::OutError => p.choice("OutError", &[]),
            OutTy::OutNamed(a0, a1) => p.choice("OutNamed", &[a0, a1]),
            OutTy::OutOpt(a0) => p.choice("OutOpt", &[a0]),
            OutTy::OutRes(a0) => p.choice("OutRes", &[a0]),
            OutTy::OutTuple(a0) => p.choice("OutTuple", &[a0]),
            OutTy::OutArray(a0) => p.choice("OutArray", &[a0]),
            OutTy::OutMap(a0, a1) => p.choice("OutMap", &[a0, a1]),
            OutTy::OutFn(a0, a1) => p.choice("OutFn", &[a0, a1]),
            OutTy::OutJobFn(a0, a1) => p.choice("OutJobFn", &[a0, a1]),
            OutTy::OutJob(a0) => p.choice("OutJob", &[a0]),
            OutTy::OutEvent(a0) => p.choice("OutEvent", &[a0]),
            OutTy::OutDyn(a0) => p.choice("OutDyn", &[a0]),
            OutTy::OutGen(a0) => p.choice("OutGen", &[a0]),
            OutTy::OutRc(a0) => p.choice("OutRc", &[a0]),
            OutTy::OutRef(a0) => p.choice("OutRef", &[a0]),
            OutTy::OutPod => p.choice("OutPod", &[]),
            OutTy::OutShowAny => p.choice("OutShowAny", &[]),
            OutTy::OutHold(a0) => p.choice("OutHold", &[a0]),
            OutTy::OutStamped(a0) => p.choice("OutStamped", &[a0]),
            OutTy::OutSnapshot(a0) => p.choice("OutSnapshot", &[a0]),
            OutTy::OutDefer(a0) => p.choice("OutDefer", &[a0]),
            OutTy::OutWeak(a0) => p.choice("OutWeak", &[a0]),
            OutTy::OutCell(a0) => p.choice("OutCell", &[a0]),
            OutTy::OutWakes => p.choice("OutWakes", &[]),
            OutTy::OutCount => p.choice("OutCount", &[]),
            OutTy::OutObj(a0) => p.choice("OutObj", &[a0]),
            OutTy::OutSlice(a0) => p.choice("OutSlice", &[a0]),
            OutTy::OutPort(a0) => p.choice("OutPort", &[a0]),
            OutTy::OutLive(a0) => p.choice("OutLive", &[a0]),
            OutTy::OutQuantified(a0) => p.choice("OutQuantified", &[a0]),
            OutTy::OutUnknown(a0) => p.choice("OutUnknown", &[a0]),
        }
    }
}

impl ToPod for OutTy {
    fn to_pod(&self) -> Pod {
        match self {
            OutTy::OutNat => Pod::Choice("OutNat".into(), vec![]),
            OutTy::OutInt => Pod::Choice("OutInt".into(), vec![]),
            OutTy::OutU8 => Pod::Choice("OutU8".into(), vec![]),
            OutTy::OutFloat => Pod::Choice("OutFloat".into(), vec![]),
            OutTy::OutBool => Pod::Choice("OutBool".into(), vec![]),
            OutTy::OutChar => Pod::Choice("OutChar".into(), vec![]),
            OutTy::OutText => Pod::Choice("OutText".into(), vec![]),
            OutTy::OutCursor => Pod::Choice("OutCursor".into(), vec![]),
            OutTy::OutRegex => Pod::Choice("OutRegex".into(), vec![]),
            OutTy::OutReplacement => Pod::Choice("OutReplacement".into(), vec![]),
            OutTy::OutUnit => Pod::Choice("OutUnit".into(), vec![]),
            OutTy::OutPath => Pod::Choice("OutPath".into(), vec![]),
            OutTy::OutDuration => Pod::Choice("OutDuration".into(), vec![]),
            OutTy::OutError => Pod::Choice("OutError".into(), vec![]),
            OutTy::OutNamed(a0, a1) => Pod::Choice("OutNamed".into(), vec![a0.to_pod(), a1.to_pod()]),
            OutTy::OutOpt(a0) => Pod::Choice("OutOpt".into(), vec![a0.to_pod()]),
            OutTy::OutRes(a0) => Pod::Choice("OutRes".into(), vec![a0.to_pod()]),
            OutTy::OutTuple(a0) => Pod::Choice("OutTuple".into(), vec![a0.to_pod()]),
            OutTy::OutArray(a0) => Pod::Choice("OutArray".into(), vec![a0.to_pod()]),
            OutTy::OutMap(a0, a1) => Pod::Choice("OutMap".into(), vec![a0.to_pod(), a1.to_pod()]),
            OutTy::OutFn(a0, a1) => Pod::Choice("OutFn".into(), vec![a0.to_pod(), a1.to_pod()]),
            OutTy::OutJobFn(a0, a1) => Pod::Choice("OutJobFn".into(), vec![a0.to_pod(), a1.to_pod()]),
            OutTy::OutJob(a0) => Pod::Choice("OutJob".into(), vec![a0.to_pod()]),
            OutTy::OutEvent(a0) => Pod::Choice("OutEvent".into(), vec![a0.to_pod()]),
            OutTy::OutDyn(a0) => Pod::Choice("OutDyn".into(), vec![a0.to_pod()]),
            OutTy::OutGen(a0) => Pod::Choice("OutGen".into(), vec![a0.to_pod()]),
            OutTy::OutRc(a0) => Pod::Choice("OutRc".into(), vec![a0.to_pod()]),
            OutTy::OutRef(a0) => Pod::Choice("OutRef".into(), vec![a0.to_pod()]),
            OutTy::OutPod => Pod::Choice("OutPod".into(), vec![]),
            OutTy::OutShowAny => Pod::Choice("OutShowAny".into(), vec![]),
            OutTy::OutHold(a0) => Pod::Choice("OutHold".into(), vec![a0.to_pod()]),
            OutTy::OutStamped(a0) => Pod::Choice("OutStamped".into(), vec![a0.to_pod()]),
            OutTy::OutSnapshot(a0) => Pod::Choice("OutSnapshot".into(), vec![a0.to_pod()]),
            OutTy::OutDefer(a0) => Pod::Choice("OutDefer".into(), vec![a0.to_pod()]),
            OutTy::OutWeak(a0) => Pod::Choice("OutWeak".into(), vec![a0.to_pod()]),
            OutTy::OutCell(a0) => Pod::Choice("OutCell".into(), vec![a0.to_pod()]),
            OutTy::OutWakes => Pod::Choice("OutWakes".into(), vec![]),
            OutTy::OutCount => Pod::Choice("OutCount".into(), vec![]),
            OutTy::OutObj(a0) => Pod::Choice("OutObj".into(), vec![a0.to_pod()]),
            OutTy::OutSlice(a0) => Pod::Choice("OutSlice".into(), vec![a0.to_pod()]),
            OutTy::OutPort(a0) => Pod::Choice("OutPort".into(), vec![a0.to_pod()]),
            OutTy::OutLive(a0) => Pod::Choice("OutLive".into(), vec![a0.to_pod()]),
            OutTy::OutQuantified(a0) => Pod::Choice("OutQuantified".into(), vec![a0.to_pod()]),
            OutTy::OutUnknown(a0) => Pod::Choice("OutUnknown".into(), vec![a0.to_pod()]),
        }
    }
}

impl FromPod for OutTy {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "OutNat" && a.len() == 0 => Ok(OutTy::OutNat),
            Pod::Choice(c, a) if &**c == "OutInt" && a.len() == 0 => Ok(OutTy::OutInt),
            Pod::Choice(c, a) if &**c == "OutU8" && a.len() == 0 => Ok(OutTy::OutU8),
            Pod::Choice(c, a) if &**c == "OutFloat" && a.len() == 0 => Ok(OutTy::OutFloat),
            Pod::Choice(c, a) if &**c == "OutBool" && a.len() == 0 => Ok(OutTy::OutBool),
            Pod::Choice(c, a) if &**c == "OutChar" && a.len() == 0 => Ok(OutTy::OutChar),
            Pod::Choice(c, a) if &**c == "OutText" && a.len() == 0 => Ok(OutTy::OutText),
            Pod::Choice(c, a) if &**c == "OutCursor" && a.len() == 0 => Ok(OutTy::OutCursor),
            Pod::Choice(c, a) if &**c == "OutRegex" && a.len() == 0 => Ok(OutTy::OutRegex),
            Pod::Choice(c, a) if &**c == "OutReplacement" && a.len() == 0 => Ok(OutTy::OutReplacement),
            Pod::Choice(c, a) if &**c == "OutUnit" && a.len() == 0 => Ok(OutTy::OutUnit),
            Pod::Choice(c, a) if &**c == "OutPath" && a.len() == 0 => Ok(OutTy::OutPath),
            Pod::Choice(c, a) if &**c == "OutDuration" && a.len() == 0 => Ok(OutTy::OutDuration),
            Pod::Choice(c, a) if &**c == "OutError" && a.len() == 0 => Ok(OutTy::OutError),
            Pod::Choice(c, a) if &**c == "OutNamed" && a.len() == 2 => Ok(OutTy::OutNamed(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "OutOpt" && a.len() == 1 => Ok(OutTy::OutOpt(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "OutRes" && a.len() == 1 => Ok(OutTy::OutRes(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "OutTuple" && a.len() == 1 => Ok(OutTy::OutTuple(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "OutArray" && a.len() == 1 => Ok(OutTy::OutArray(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "OutMap" && a.len() == 2 => Ok(OutTy::OutMap(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "OutFn" && a.len() == 2 => Ok(OutTy::OutFn(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "OutJobFn" && a.len() == 2 => Ok(OutTy::OutJobFn(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "OutJob" && a.len() == 1 => Ok(OutTy::OutJob(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "OutEvent" && a.len() == 1 => Ok(OutTy::OutEvent(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "OutDyn" && a.len() == 1 => Ok(OutTy::OutDyn(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "OutGen" && a.len() == 1 => Ok(OutTy::OutGen(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "OutRc" && a.len() == 1 => Ok(OutTy::OutRc(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "OutRef" && a.len() == 1 => Ok(OutTy::OutRef(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "OutPod" && a.len() == 0 => Ok(OutTy::OutPod),
            Pod::Choice(c, a) if &**c == "OutShowAny" && a.len() == 0 => Ok(OutTy::OutShowAny),
            Pod::Choice(c, a) if &**c == "OutHold" && a.len() == 1 => Ok(OutTy::OutHold(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "OutStamped" && a.len() == 1 => Ok(OutTy::OutStamped(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "OutSnapshot" && a.len() == 1 => Ok(OutTy::OutSnapshot(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "OutDefer" && a.len() == 1 => Ok(OutTy::OutDefer(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "OutWeak" && a.len() == 1 => Ok(OutTy::OutWeak(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "OutCell" && a.len() == 1 => Ok(OutTy::OutCell(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "OutWakes" && a.len() == 0 => Ok(OutTy::OutWakes),
            Pod::Choice(c, a) if &**c == "OutCount" && a.len() == 0 => Ok(OutTy::OutCount),
            Pod::Choice(c, a) if &**c == "OutObj" && a.len() == 1 => Ok(OutTy::OutObj(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "OutSlice" && a.len() == 1 => Ok(OutTy::OutSlice(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "OutPort" && a.len() == 1 => Ok(OutTy::OutPort(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "OutLive" && a.len() == 1 => Ok(OutTy::OutLive(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "OutQuantified" && a.len() == 1 => Ok(OutTy::OutQuantified(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "OutUnknown" && a.len() == 1 => Ok(OutTy::OutUnknown(FromPod::from_pod(&a[0])?)),
            other => mismatch("a OutTy", other),
        }
    }
}

/// `Pa`:
///
/// ```prism
/// type Pa = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum Pa {
    PaWild,
    PaBind(Text),
    PaMut(Text),
    PaCtor(Text, Array<Pa>),
    PaUnit(Text),
    PaRecord(Text, Array<(Text, Pa)>, bool),
    PaTuple(Array<Pa>),
    PaChar(Text),
    PaBool(bool),
    PaIndex(Nat),
    PaConst(Text),
    PaSlice(Array<Pa>),
    PaRest(Text),
    PaTyped(Rc<Pa>, OutTy),
}

impl Show for Pa {
    fn show(&self, p: &mut Printer) {
        match self {
            Pa::PaWild => p.choice("PaWild", &[]),
            Pa::PaBind(a0) => p.choice("PaBind", &[a0]),
            Pa::PaMut(a0) => p.choice("PaMut", &[a0]),
            Pa::PaCtor(a0, a1) => p.choice("PaCtor", &[a0, a1]),
            Pa::PaUnit(a0) => p.choice("PaUnit", &[a0]),
            Pa::PaRecord(a0, a1, a2) => p.choice("PaRecord", &[a0, a1, a2]),
            Pa::PaTuple(a0) => p.choice("PaTuple", &[a0]),
            Pa::PaChar(a0) => p.choice("PaChar", &[a0]),
            Pa::PaBool(a0) => p.choice("PaBool", &[a0]),
            Pa::PaIndex(a0) => p.choice("PaIndex", &[a0]),
            Pa::PaConst(a0) => p.choice("PaConst", &[a0]),
            Pa::PaSlice(a0) => p.choice("PaSlice", &[a0]),
            Pa::PaRest(a0) => p.choice("PaRest", &[a0]),
            Pa::PaTyped(a0, a1) => p.choice("PaTyped", &[a0, a1]),
        }
    }
}

impl ToPod for Pa {
    fn to_pod(&self) -> Pod {
        match self {
            Pa::PaWild => Pod::Choice("PaWild".into(), vec![]),
            Pa::PaBind(a0) => Pod::Choice("PaBind".into(), vec![a0.to_pod()]),
            Pa::PaMut(a0) => Pod::Choice("PaMut".into(), vec![a0.to_pod()]),
            Pa::PaCtor(a0, a1) => Pod::Choice("PaCtor".into(), vec![a0.to_pod(), a1.to_pod()]),
            Pa::PaUnit(a0) => Pod::Choice("PaUnit".into(), vec![a0.to_pod()]),
            Pa::PaRecord(a0, a1, a2) => Pod::Choice("PaRecord".into(), vec![a0.to_pod(), a1.to_pod(), a2.to_pod()]),
            Pa::PaTuple(a0) => Pod::Choice("PaTuple".into(), vec![a0.to_pod()]),
            Pa::PaChar(a0) => Pod::Choice("PaChar".into(), vec![a0.to_pod()]),
            Pa::PaBool(a0) => Pod::Choice("PaBool".into(), vec![a0.to_pod()]),
            Pa::PaIndex(a0) => Pod::Choice("PaIndex".into(), vec![a0.to_pod()]),
            Pa::PaConst(a0) => Pod::Choice("PaConst".into(), vec![a0.to_pod()]),
            Pa::PaSlice(a0) => Pod::Choice("PaSlice".into(), vec![a0.to_pod()]),
            Pa::PaRest(a0) => Pod::Choice("PaRest".into(), vec![a0.to_pod()]),
            Pa::PaTyped(a0, a1) => Pod::Choice("PaTyped".into(), vec![a0.to_pod(), a1.to_pod()]),
        }
    }
}

impl FromPod for Pa {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "PaWild" && a.len() == 0 => Ok(Pa::PaWild),
            Pod::Choice(c, a) if &**c == "PaBind" && a.len() == 1 => Ok(Pa::PaBind(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "PaMut" && a.len() == 1 => Ok(Pa::PaMut(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "PaCtor" && a.len() == 2 => Ok(Pa::PaCtor(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "PaUnit" && a.len() == 1 => Ok(Pa::PaUnit(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "PaRecord" && a.len() == 3 => Ok(Pa::PaRecord(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?, FromPod::from_pod(&a[2])?)),
            Pod::Choice(c, a) if &**c == "PaTuple" && a.len() == 1 => Ok(Pa::PaTuple(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "PaChar" && a.len() == 1 => Ok(Pa::PaChar(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "PaBool" && a.len() == 1 => Ok(Pa::PaBool(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "PaIndex" && a.len() == 1 => Ok(Pa::PaIndex(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "PaConst" && a.len() == 1 => Ok(Pa::PaConst(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "PaSlice" && a.len() == 1 => Ok(Pa::PaSlice(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "PaRest" && a.len() == 1 => Ok(Pa::PaRest(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "PaTyped" && a.len() == 2 => Ok(Pa::PaTyped(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            other => mismatch("a Pa", other),
        }
    }
}

/// `Pos`:
///
/// ```prism
/// type Pos = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Pos_ {
    pub scope: Nat,
    pub at: Nat,
}

impl Show for Pos_ {
    fn show(&self, p: &mut Printer) {
        p.record("Pos", &[("scope", &self.scope), ("at", &self.at)]);
    }
}

impl ToPod for Pos_ {
    fn to_pod(&self) -> Pod {
        Pod::record("Pos", vec![("scope", self.scope.to_pod()), ("at", self.at.to_pod())])
    }
}

impl FromPod for Pos_ {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Pos_ { scope: FromPod::from_pod(field(p, "scope")?)?, at: FromPod::from_pod(field(p, "at")?)? })
    }
}

/// `ProgDef`:
///
/// ```prism
/// type ProgDef = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct ProgDef {
    pub name: Text,
    pub prism: Text,
    pub node_: Text,
    pub params: Array<(Text, OutTy)>,
    pub fallible: bool,
    pub world: Text,
}

impl Show for ProgDef {
    fn show(&self, p: &mut Printer) {
        p.record("ProgDef", &[("name", &self.name), ("prism", &self.prism), ("node", &self.node_), ("params", &self.params), ("fallible", &self.fallible), ("world", &self.world)]);
    }
}

impl ToPod for ProgDef {
    fn to_pod(&self) -> Pod {
        Pod::record("ProgDef", vec![("name", self.name.to_pod()), ("prism", self.prism.to_pod()), ("node", self.node_.to_pod()), ("params", self.params.to_pod()), ("fallible", self.fallible.to_pod()), ("world", self.world.to_pod())])
    }
}

impl FromPod for ProgDef {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(ProgDef { name: FromPod::from_pod(field(p, "name")?)?, prism: FromPod::from_pod(field(p, "prism")?)?, node_: FromPod::from_pod(field(p, "node")?)?, params: FromPod::from_pod(field(p, "params")?)?, fallible: FromPod::from_pod(field(p, "fallible")?)?, world: FromPod::from_pod(field(p, "world")?)? })
    }
}

/// `Recv`:
///
/// ```prism
/// type Recv = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum Recv {
    RecvRc,
    RecvRef,
    RecvOwned,
}

impl Show for Recv {
    fn show(&self, p: &mut Printer) {
        match self {
            Recv::RecvRc => p.choice("RecvRc", &[]),
            Recv::RecvRef => p.choice("RecvRef", &[]),
            Recv::RecvOwned => p.choice("RecvOwned", &[]),
        }
    }
}

impl ToPod for Recv {
    fn to_pod(&self) -> Pod {
        match self {
            Recv::RecvRc => Pod::Choice("RecvRc".into(), vec![]),
            Recv::RecvRef => Pod::Choice("RecvRef".into(), vec![]),
            Recv::RecvOwned => Pod::Choice("RecvOwned".into(), vec![]),
        }
    }
}

impl FromPod for Recv {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "RecvRc" && a.len() == 0 => Ok(Recv::RecvRc),
            Pod::Choice(c, a) if &**c == "RecvRef" && a.len() == 0 => Ok(Recv::RecvRef),
            Pod::Choice(c, a) if &**c == "RecvOwned" && a.len() == 0 => Ok(Recv::RecvOwned),
            other => mismatch("a Recv", other),
        }
    }
}

/// `RowDef`:
///
/// ```prism
/// type RowDef = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct RowDef {
    pub name: Text,
    pub prism: Text,
    pub cases: Array<(Text, Text)>,
    pub pod: bool,
    pub doc: Text,
    pub eq: bool,
    pub level: bool,
    pub deep: Array<Text>,
}

impl Show for RowDef {
    fn show(&self, p: &mut Printer) {
        p.record("RowDef", &[("name", &self.name), ("prism", &self.prism), ("cases", &self.cases), ("pod", &self.pod), ("doc", &self.doc), ("eq", &self.eq), ("level", &self.level), ("deep", &self.deep)]);
    }
}

impl ToPod for RowDef {
    fn to_pod(&self) -> Pod {
        Pod::record("RowDef", vec![("name", self.name.to_pod()), ("prism", self.prism.to_pod()), ("cases", self.cases.to_pod()), ("pod", self.pod.to_pod()), ("doc", self.doc.to_pod()), ("eq", self.eq.to_pod()), ("level", self.level.to_pod()), ("deep", self.deep.to_pod())])
    }
}

impl FromPod for RowDef {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(RowDef { name: FromPod::from_pod(field(p, "name")?)?, prism: FromPod::from_pod(field(p, "prism")?)?, cases: FromPod::from_pod(field(p, "cases")?)?, pod: FromPod::from_pod(field(p, "pod")?)?, doc: FromPod::from_pod(field(p, "doc")?)?, eq: FromPod::from_pod(field(p, "eq")?)?, level: FromPod::from_pod(field(p, "level")?)?, deep: FromPod::from_pod(field(p, "deep")?)? })
    }
}

/// `RowKind`:
///
/// ```prism
/// type RowKind = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum RowKind {
    ForRow,
    GenerationRow,
    NotARow,
}

impl Show for RowKind {
    fn show(&self, p: &mut Printer) {
        match self {
            RowKind::ForRow => p.choice("ForRow", &[]),
            RowKind::GenerationRow => p.choice("GenerationRow", &[]),
            RowKind::NotARow => p.choice("NotARow", &[]),
        }
    }
}

impl ToPod for RowKind {
    fn to_pod(&self) -> Pod {
        match self {
            RowKind::ForRow => Pod::Choice("ForRow".into(), vec![]),
            RowKind::GenerationRow => Pod::Choice("GenerationRow".into(), vec![]),
            RowKind::NotARow => Pod::Choice("NotARow".into(), vec![]),
        }
    }
}

impl FromPod for RowKind {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "ForRow" && a.len() == 0 => Ok(RowKind::ForRow),
            Pod::Choice(c, a) if &**c == "GenerationRow" && a.len() == 0 => Ok(RowKind::GenerationRow),
            Pod::Choice(c, a) if &**c == "NotARow" && a.len() == 0 => Ok(RowKind::NotARow),
            other => mismatch("a RowKind", other),
        }
    }
}

/// `Shown`:
///
/// ```prism
/// type Shown = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum Shown {
    ShownOwn,
    ShownDerived,
    NotShown,
}

impl Show for Shown {
    fn show(&self, p: &mut Printer) {
        match self {
            Shown::ShownOwn => p.choice("ShownOwn", &[]),
            Shown::ShownDerived => p.choice("ShownDerived", &[]),
            Shown::NotShown => p.choice("NotShown", &[]),
        }
    }
}

impl ToPod for Shown {
    fn to_pod(&self) -> Pod {
        match self {
            Shown::ShownOwn => Pod::Choice("ShownOwn".into(), vec![]),
            Shown::ShownDerived => Pod::Choice("ShownDerived".into(), vec![]),
            Shown::NotShown => Pod::Choice("NotShown".into(), vec![]),
        }
    }
}

impl FromPod for Shown {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "ShownOwn" && a.len() == 0 => Ok(Shown::ShownOwn),
            Pod::Choice(c, a) if &**c == "ShownDerived" && a.len() == 0 => Ok(Shown::ShownDerived),
            Pod::Choice(c, a) if &**c == "NotShown" && a.len() == 0 => Ok(Shown::NotShown),
            other => mismatch("a Shown", other),
        }
    }
}

/// `TagDef`:
///
/// ```prism
/// type TagDef = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct TagDef {
    pub name: Text,
    pub tag_name: Text,
    pub fields: Array<(Text, Text, OutTy)>,
    pub doc: Text,
    pub pod: bool,
    pub eq: bool,
}

impl Show for TagDef {
    fn show(&self, p: &mut Printer) {
        p.record("TagDef", &[("name", &self.name), ("tag_name", &self.tag_name), ("fields", &self.fields), ("doc", &self.doc), ("pod", &self.pod), ("eq", &self.eq)]);
    }
}

impl ToPod for TagDef {
    fn to_pod(&self) -> Pod {
        Pod::record("TagDef", vec![("name", self.name.to_pod()), ("tag_name", self.tag_name.to_pod()), ("fields", self.fields.to_pod()), ("doc", self.doc.to_pod()), ("pod", self.pod.to_pod()), ("eq", self.eq.to_pod())])
    }
}

impl FromPod for TagDef {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(TagDef { name: FromPod::from_pod(field(p, "name")?)?, tag_name: FromPod::from_pod(field(p, "tag_name")?)?, fields: FromPod::from_pod(field(p, "fields")?)?, doc: FromPod::from_pod(field(p, "doc")?)?, pod: FromPod::from_pod(field(p, "pod")?)?, eq: FromPod::from_pod(field(p, "eq")?)? })
    }
}

/// `TraitDef`:
///
/// ```prism
/// type TraitDef = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct TraitDef {
    pub name: Text,
    pub methods: Array<FnDef>,
    pub defaults: Array<Text>,
    pub doc: Text,
}

impl Show for TraitDef {
    fn show(&self, p: &mut Printer) {
        p.record("TraitDef", &[("name", &self.name), ("methods", &self.methods), ("defaults", &self.defaults), ("doc", &self.doc)]);
    }
}

impl ToPod for TraitDef {
    fn to_pod(&self) -> Pod {
        Pod::record("TraitDef", vec![("name", self.name.to_pod()), ("methods", self.methods.to_pod()), ("defaults", self.defaults.to_pod()), ("doc", self.doc.to_pod())])
    }
}

impl FromPod for TraitDef {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(TraitDef { name: FromPod::from_pod(field(p, "name")?)?, methods: FromPod::from_pod(field(p, "methods")?)?, defaults: FromPod::from_pod(field(p, "defaults")?)?, doc: FromPod::from_pod(field(p, "doc")?)? })
    }
}

/// `TyDef`:
///
/// ```prism
/// type TyDef = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct TyDef {
    pub name: Text,
    pub prism: Text,
    pub params: Array<Text>,
    pub shape: TyShape,
    pub cases: Array<CaseDef>,
    pub eq: bool,
    pub ord: bool,
    pub floaty: bool,
    pub show: Shown,
    pub pod: bool,
    pub doc: Text,
}

impl Show for TyDef {
    fn show(&self, p: &mut Printer) {
        p.record("TyDef", &[("name", &self.name), ("prism", &self.prism), ("params", &self.params), ("shape", &self.shape), ("cases", &self.cases), ("eq", &self.eq), ("ord", &self.ord), ("floaty", &self.floaty), ("show", &self.show), ("pod", &self.pod), ("doc", &self.doc)]);
    }
}

impl ToPod for TyDef {
    fn to_pod(&self) -> Pod {
        Pod::record("TyDef", vec![("name", self.name.to_pod()), ("prism", self.prism.to_pod()), ("params", self.params.to_pod()), ("shape", self.shape.to_pod()), ("cases", self.cases.to_pod()), ("eq", self.eq.to_pod()), ("ord", self.ord.to_pod()), ("floaty", self.floaty.to_pod()), ("show", self.show.to_pod()), ("pod", self.pod.to_pod()), ("doc", self.doc.to_pod())])
    }
}

impl FromPod for TyDef {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(TyDef { name: FromPod::from_pod(field(p, "name")?)?, prism: FromPod::from_pod(field(p, "prism")?)?, params: FromPod::from_pod(field(p, "params")?)?, shape: FromPod::from_pod(field(p, "shape")?)?, cases: FromPod::from_pod(field(p, "cases")?)?, eq: FromPod::from_pod(field(p, "eq")?)?, ord: FromPod::from_pod(field(p, "ord")?)?, floaty: FromPod::from_pod(field(p, "floaty")?)?, show: FromPod::from_pod(field(p, "show")?)?, pod: FromPod::from_pod(field(p, "pod")?)?, doc: FromPod::from_pod(field(p, "doc")?)? })
    }
}

/// `TyShape`:
///
/// ```prism
/// type TyShape = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum TyShape {
    ShapeRecord,
    ShapeChoice,
    ShapeNewtype,
    ShapeUnit,
}

impl Show for TyShape {
    fn show(&self, p: &mut Printer) {
        match self {
            TyShape::ShapeRecord => p.choice("ShapeRecord", &[]),
            TyShape::ShapeChoice => p.choice("ShapeChoice", &[]),
            TyShape::ShapeNewtype => p.choice("ShapeNewtype", &[]),
            TyShape::ShapeUnit => p.choice("ShapeUnit", &[]),
        }
    }
}

impl ToPod for TyShape {
    fn to_pod(&self) -> Pod {
        match self {
            TyShape::ShapeRecord => Pod::Choice("ShapeRecord".into(), vec![]),
            TyShape::ShapeChoice => Pod::Choice("ShapeChoice".into(), vec![]),
            TyShape::ShapeNewtype => Pod::Choice("ShapeNewtype".into(), vec![]),
            TyShape::ShapeUnit => Pod::Choice("ShapeUnit".into(), vec![]),
        }
    }
}

impl FromPod for TyShape {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "ShapeRecord" && a.len() == 0 => Ok(TyShape::ShapeRecord),
            Pod::Choice(c, a) if &**c == "ShapeChoice" && a.len() == 0 => Ok(TyShape::ShapeChoice),
            Pod::Choice(c, a) if &**c == "ShapeNewtype" && a.len() == 0 => Ok(TyShape::ShapeNewtype),
            Pod::Choice(c, a) if &**c == "ShapeUnit" && a.len() == 0 => Ok(TyShape::ShapeUnit),
            other => mismatch("a TyShape", other),
        }
    }
}

/// `XArm`:
///
/// ```prism
/// type XArm = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct XArm {
    pub pat: Pa,
    pub conds: Array<Cc>,
    pub body: Ex,
}

impl Show for XArm {
    fn show(&self, p: &mut Printer) {
        p.record("XArm", &[("pat", &self.pat), ("conds", &self.conds), ("body", &self.body)]);
    }
}

impl ToPod for XArm {
    fn to_pod(&self) -> Pod {
        Pod::record("XArm", vec![("pat", self.pat.to_pod()), ("conds", self.conds.to_pod()), ("body", self.body.to_pod())])
    }
}

impl FromPod for XArm {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(XArm { pat: FromPod::from_pod(field(p, "pat")?)?, conds: FromPod::from_pod(field(p, "conds")?)?, body: FromPod::from_pod(field(p, "body")?)? })
    }
}

/// ```prism
/// let pos0
/// ```
pub fn pos0() -> Pos_ {
    Pos_ { scope: Nat::from(0u32), at: Nat::from(0u32) }
}

/// ```prism
/// NextPos: fn Pos -> Pos
/// ```
pub fn next_pos(p_: &Pos_) -> Pos_ {
    let mut this: Pos_ = p_.clone();
    this.at = &this.at + &Nat::from(1u32);
    this
}

/// ```prism
/// ScopePos: fn Nat -> Pos
/// ```
pub fn scope_pos(k: &Nat) -> Pos_ {
    Pos_ { scope: k.clone(), at: Nat::from(0u32) }
}

/// ```prism
/// PlaceText: fn Pos -> Text
/// ```
pub fn place_text(p_: &Pos_) -> Text {
    if &p_.scope == &Nat::from(0u32) {
        Text::from(format!("{}", &p_.at))
    } else {
        Text::from(format!("h{}_{}", &p_.scope, &p_.at))
    }
}
