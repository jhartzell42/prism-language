//! The module `Lower.Model`, from `target/bootstrap/src/prismc/lower/model.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// `AnswerCase`:
///
/// ```prism
/// type AnswerCase = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct AnswerCase {
    pub variant_p: Text,
    pub accessor_p: Text,
    pub struct_path_p: Text,
    pub tag_name_p: Text,
    pub ty_p: OutTy,
}

impl Show for AnswerCase {
    fn show(&self, p: &mut Printer) {
        p.record("AnswerCase", &[("variant", &self.variant_p), ("accessor", &self.accessor_p), ("structPath", &self.struct_path_p), ("tagName", &self.tag_name_p), ("ty", &self.ty_p)]);
    }
}

impl ToPod for AnswerCase {
    fn to_pod(&self) -> Pod {
        Pod::record("AnswerCase", vec![("variant", self.variant_p.to_pod()), ("accessor", self.accessor_p.to_pod()), ("structPath", self.struct_path_p.to_pod()), ("tagName", self.tag_name_p.to_pod()), ("ty", self.ty_p.to_pod())])
    }
}

impl FromPod for AnswerCase {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(AnswerCase { variant_p: FromPod::from_pod(field(p, "variant")?)?, accessor_p: FromPod::from_pod(field(p, "accessor")?)?, struct_path_p: FromPod::from_pod(field(p, "structPath")?)?, tag_name_p: FromPod::from_pod(field(p, "tagName")?)?, ty_p: FromPod::from_pod(field(p, "ty")?)? })
    }
}

/// `AnswerDef`:
///
/// ```prism
/// type AnswerDef = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct AnswerDef {
    pub cases_p: Array<AnswerCase>,
}

impl Show for AnswerDef {
    fn show(&self, p: &mut Printer) {
        p.record("AnswerDef", &[("cases", &self.cases_p)]);
    }
}

impl ToPod for AnswerDef {
    fn to_pod(&self) -> Pod {
        Pod::record("AnswerDef", vec![("cases", self.cases_p.to_pod())])
    }
}

impl FromPod for AnswerDef {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(AnswerDef { cases_p: FromPod::from_pod(field(p, "cases")?)? })
    }
}

/// `BinOp`:
///
/// ```prism
/// type BinOp = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum BinOp {
    OpAdd,
    OpSub,
    OpMul,
    OpDiv,
    OpEq,
    OpNe,
    OpLt,
    OpLe,
    OpGt,
    OpGe,
    OpAnd,
    OpOr,
}

impl Show for BinOp {
    fn show(&self, p: &mut Printer) {
        match self {
            BinOp::OpAdd => p.choice("OpAdd", &[]),
            BinOp::OpSub => p.choice("OpSub", &[]),
            BinOp::OpMul => p.choice("OpMul", &[]),
            BinOp::OpDiv => p.choice("OpDiv", &[]),
            BinOp::OpEq => p.choice("OpEq", &[]),
            BinOp::OpNe => p.choice("OpNe", &[]),
            BinOp::OpLt => p.choice("OpLt", &[]),
            BinOp::OpLe => p.choice("OpLe", &[]),
            BinOp::OpGt => p.choice("OpGt", &[]),
            BinOp::OpGe => p.choice("OpGe", &[]),
            BinOp::OpAnd => p.choice("OpAnd", &[]),
            BinOp::OpOr => p.choice("OpOr", &[]),
        }
    }
}

impl ToPod for BinOp {
    fn to_pod(&self) -> Pod {
        match self {
            BinOp::OpAdd => Pod::Choice("OpAdd".into(), vec![]),
            BinOp::OpSub => Pod::Choice("OpSub".into(), vec![]),
            BinOp::OpMul => Pod::Choice("OpMul".into(), vec![]),
            BinOp::OpDiv => Pod::Choice("OpDiv".into(), vec![]),
            BinOp::OpEq => Pod::Choice("OpEq".into(), vec![]),
            BinOp::OpNe => Pod::Choice("OpNe".into(), vec![]),
            BinOp::OpLt => Pod::Choice("OpLt".into(), vec![]),
            BinOp::OpLe => Pod::Choice("OpLe".into(), vec![]),
            BinOp::OpGt => Pod::Choice("OpGt".into(), vec![]),
            BinOp::OpGe => Pod::Choice("OpGe".into(), vec![]),
            BinOp::OpAnd => Pod::Choice("OpAnd".into(), vec![]),
            BinOp::OpOr => Pod::Choice("OpOr".into(), vec![]),
        }
    }
}

impl FromPod for BinOp {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "OpAdd" && a.len() == 0 => Ok(BinOp::OpAdd),
            Pod::Choice(c, a) if &**c == "OpSub" && a.len() == 0 => Ok(BinOp::OpSub),
            Pod::Choice(c, a) if &**c == "OpMul" && a.len() == 0 => Ok(BinOp::OpMul),
            Pod::Choice(c, a) if &**c == "OpDiv" && a.len() == 0 => Ok(BinOp::OpDiv),
            Pod::Choice(c, a) if &**c == "OpEq" && a.len() == 0 => Ok(BinOp::OpEq),
            Pod::Choice(c, a) if &**c == "OpNe" && a.len() == 0 => Ok(BinOp::OpNe),
            Pod::Choice(c, a) if &**c == "OpLt" && a.len() == 0 => Ok(BinOp::OpLt),
            Pod::Choice(c, a) if &**c == "OpLe" && a.len() == 0 => Ok(BinOp::OpLe),
            Pod::Choice(c, a) if &**c == "OpGt" && a.len() == 0 => Ok(BinOp::OpGt),
            Pod::Choice(c, a) if &**c == "OpGe" && a.len() == 0 => Ok(BinOp::OpGe),
            Pod::Choice(c, a) if &**c == "OpAnd" && a.len() == 0 => Ok(BinOp::OpAnd),
            Pod::Choice(c, a) if &**c == "OpOr" && a.len() == 0 => Ok(BinOp::OpOr),
            other => mismatch("a BinOp", other),
        }
    }
}

/// `CaseDef`:
///
/// ```prism
/// type CaseDef = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct CaseDef {
    pub name_p: Text,
    pub prism_p: Text,
    pub fields_p: Array<(Text, OutTy)>,
    pub labels_p: Array<Text>,
}

impl Show for CaseDef {
    fn show(&self, p: &mut Printer) {
        p.record("CaseDef", &[("name", &self.name_p), ("prism", &self.prism_p), ("fields", &self.fields_p), ("labels", &self.labels_p)]);
    }
}

impl ToPod for CaseDef {
    fn to_pod(&self) -> Pod {
        Pod::record("CaseDef", vec![("name", self.name_p.to_pod()), ("prism", self.prism_p.to_pod()), ("fields", self.fields_p.to_pod()), ("labels", self.labels_p.to_pod())])
    }
}

impl FromPod for CaseDef {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(CaseDef { name_p: FromPod::from_pod(field(p, "name")?)?, prism_p: FromPod::from_pod(field(p, "prism")?)?, fields_p: FromPod::from_pod(field(p, "fields")?)?, labels_p: FromPod::from_pod(field(p, "labels")?)? })
    }
}

/// `Cc`:
///
/// ```prism
/// type Cc = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum Cc {
    CcIf(Ex),
    CcLet(Pa, Ex),
}

impl Show for Cc {
    fn show(&self, p: &mut Printer) {
        match self {
            Cc::CcIf(a0) => p.choice("CcIf", &[a0]),
            Cc::CcLet(a0, a1) => p.choice("CcLet", &[a0, a1]),
        }
    }
}

impl ToPod for Cc {
    fn to_pod(&self) -> Pod {
        match self {
            Cc::CcIf(a0) => Pod::Choice("CcIf".into(), vec![a0.to_pod()]),
            Cc::CcLet(a0, a1) => Pod::Choice("CcLet".into(), vec![a0.to_pod(), a1.to_pod()]),
        }
    }
}

impl FromPod for Cc {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "CcIf" && a.len() == 1 => Ok(Cc::CcIf(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "CcLet" && a.len() == 2 => Ok(Cc::CcLet(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            other => mismatch("a Cc", other),
        }
    }
}

/// `CheckDef`:
///
/// ```prism
/// type CheckDef = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct CheckDef {
    pub name_p: Text,
    pub lines_p: Array<Ex>,
}

impl Show for CheckDef {
    fn show(&self, p: &mut Printer) {
        p.record("CheckDef", &[("name", &self.name_p), ("lines", &self.lines_p)]);
    }
}

impl ToPod for CheckDef {
    fn to_pod(&self) -> Pod {
        Pod::record("CheckDef", vec![("name", self.name_p.to_pod()), ("lines", self.lines_p.to_pod())])
    }
}

impl FromPod for CheckDef {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(CheckDef { name_p: FromPod::from_pod(field(p, "name")?)?, lines_p: FromPod::from_pod(field(p, "lines")?)? })
    }
}

/// `CxArg`:
///
/// ```prism
/// type CxArg = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum CxArg {
    CxMut,
    CxRef,
    CxNone,
}

impl Show for CxArg {
    fn show(&self, p: &mut Printer) {
        match self {
            CxArg::CxMut => p.choice("CxMut", &[]),
            CxArg::CxRef => p.choice("CxRef", &[]),
            CxArg::CxNone => p.choice("CxNone", &[]),
        }
    }
}

impl ToPod for CxArg {
    fn to_pod(&self) -> Pod {
        match self {
            CxArg::CxMut => Pod::Choice("CxMut".into(), vec![]),
            CxArg::CxRef => Pod::Choice("CxRef".into(), vec![]),
            CxArg::CxNone => Pod::Choice("CxNone".into(), vec![]),
        }
    }
}

impl FromPod for CxArg {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "CxMut" && a.len() == 0 => Ok(CxArg::CxMut),
            Pod::Choice(c, a) if &**c == "CxRef" && a.len() == 0 => Ok(CxArg::CxRef),
            Pod::Choice(c, a) if &**c == "CxNone" && a.len() == 0 => Ok(CxArg::CxNone),
            other => mismatch("a CxArg", other),
        }
    }
}

/// `Do`:
///
/// ```prism
/// type Do = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum Do {
    DoLet(Pa, Ex),
    DoLetElse(Pa, Ex, Ex),
    DoAssign(Ex, Ex),
    DoWhile(Ex, Array<Do>),
    DoWhileLet(Pa, Ex, Array<Do>),
    DoFor(Pa, Ex, Array<Do>),
    DoExpr(Ex),
    DoIf(Ex, Array<Do>, Array<Do>),
    DoIfLet(Pa, Ex, Array<Do>, Array<Do>),
    DoMatch(Ex, Array<(Pa, Array<Do>)>),
    DoReturn(Ex),
    DoBlock(Array<Do>),
    DoScope(Array<Do>),
    DoLine(Array<Do>),
    DoNote(Text),
}

impl Show for Do {
    fn show(&self, p: &mut Printer) {
        match self {
            Do::DoLet(a0, a1) => p.choice("DoLet", &[a0, a1]),
            Do::DoLetElse(a0, a1, a2) => p.choice("DoLetElse", &[a0, a1, a2]),
            Do::DoAssign(a0, a1) => p.choice("DoAssign", &[a0, a1]),
            Do::DoWhile(a0, a1) => p.choice("DoWhile", &[a0, a1]),
            Do::DoWhileLet(a0, a1, a2) => p.choice("DoWhileLet", &[a0, a1, a2]),
            Do::DoFor(a0, a1, a2) => p.choice("DoFor", &[a0, a1, a2]),
            Do::DoExpr(a0) => p.choice("DoExpr", &[a0]),
            Do::DoIf(a0, a1, a2) => p.choice("DoIf", &[a0, a1, a2]),
            Do::DoIfLet(a0, a1, a2, a3) => p.choice("DoIfLet", &[a0, a1, a2, a3]),
            Do::DoMatch(a0, a1) => p.choice("DoMatch", &[a0, a1]),
            Do::DoReturn(a0) => p.choice("DoReturn", &[a0]),
            Do::DoBlock(a0) => p.choice("DoBlock", &[a0]),
            Do::DoScope(a0) => p.choice("DoScope", &[a0]),
            Do::DoLine(a0) => p.choice("DoLine", &[a0]),
            Do::DoNote(a0) => p.choice("DoNote", &[a0]),
        }
    }
}

impl ToPod for Do {
    fn to_pod(&self) -> Pod {
        match self {
            Do::DoLet(a0, a1) => Pod::Choice("DoLet".into(), vec![a0.to_pod(), a1.to_pod()]),
            Do::DoLetElse(a0, a1, a2) => Pod::Choice("DoLetElse".into(), vec![a0.to_pod(), a1.to_pod(), a2.to_pod()]),
            Do::DoAssign(a0, a1) => Pod::Choice("DoAssign".into(), vec![a0.to_pod(), a1.to_pod()]),
            Do::DoWhile(a0, a1) => Pod::Choice("DoWhile".into(), vec![a0.to_pod(), a1.to_pod()]),
            Do::DoWhileLet(a0, a1, a2) => Pod::Choice("DoWhileLet".into(), vec![a0.to_pod(), a1.to_pod(), a2.to_pod()]),
            Do::DoFor(a0, a1, a2) => Pod::Choice("DoFor".into(), vec![a0.to_pod(), a1.to_pod(), a2.to_pod()]),
            Do::DoExpr(a0) => Pod::Choice("DoExpr".into(), vec![a0.to_pod()]),
            Do::DoIf(a0, a1, a2) => Pod::Choice("DoIf".into(), vec![a0.to_pod(), a1.to_pod(), a2.to_pod()]),
            Do::DoIfLet(a0, a1, a2, a3) => Pod::Choice("DoIfLet".into(), vec![a0.to_pod(), a1.to_pod(), a2.to_pod(), a3.to_pod()]),
            Do::DoMatch(a0, a1) => Pod::Choice("DoMatch".into(), vec![a0.to_pod(), a1.to_pod()]),
            Do::DoReturn(a0) => Pod::Choice("DoReturn".into(), vec![a0.to_pod()]),
            Do::DoBlock(a0) => Pod::Choice("DoBlock".into(), vec![a0.to_pod()]),
            Do::DoScope(a0) => Pod::Choice("DoScope".into(), vec![a0.to_pod()]),
            Do::DoLine(a0) => Pod::Choice("DoLine".into(), vec![a0.to_pod()]),
            Do::DoNote(a0) => Pod::Choice("DoNote".into(), vec![a0.to_pod()]),
        }
    }
}

impl FromPod for Do {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "DoLet" && a.len() == 2 => Ok(Do::DoLet(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "DoLetElse" && a.len() == 3 => Ok(Do::DoLetElse(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?, FromPod::from_pod(&a[2])?)),
            Pod::Choice(c, a) if &**c == "DoAssign" && a.len() == 2 => Ok(Do::DoAssign(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "DoWhile" && a.len() == 2 => Ok(Do::DoWhile(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "DoWhileLet" && a.len() == 3 => Ok(Do::DoWhileLet(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?, FromPod::from_pod(&a[2])?)),
            Pod::Choice(c, a) if &**c == "DoFor" && a.len() == 3 => Ok(Do::DoFor(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?, FromPod::from_pod(&a[2])?)),
            Pod::Choice(c, a) if &**c == "DoExpr" && a.len() == 1 => Ok(Do::DoExpr(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "DoIf" && a.len() == 3 => Ok(Do::DoIf(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?, FromPod::from_pod(&a[2])?)),
            Pod::Choice(c, a) if &**c == "DoIfLet" && a.len() == 4 => Ok(Do::DoIfLet(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?, FromPod::from_pod(&a[2])?, FromPod::from_pod(&a[3])?)),
            Pod::Choice(c, a) if &**c == "DoMatch" && a.len() == 2 => Ok(Do::DoMatch(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "DoReturn" && a.len() == 1 => Ok(Do::DoReturn(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "DoBlock" && a.len() == 1 => Ok(Do::DoBlock(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "DoScope" && a.len() == 1 => Ok(Do::DoScope(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "DoLine" && a.len() == 1 => Ok(Do::DoLine(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "DoNote" && a.len() == 1 => Ok(Do::DoNote(FromPod::from_pod(&a[0])?)),
            other => mismatch("a Do", other),
        }
    }
}

/// `Ex`:
///
/// ```prism
/// type Ex = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum Ex {
    XVar(Text),
    XPath(Text),
    XSelf,
    XCx,
    XConst(Text),
    XUnit,
    XNone,
    XBool(bool),
    XNat(Text),
    XInt(Text),
    XByte(Text),
    XFloat(Text),
    XIndex(Nat),
    XChar(Text),
    XStr(Text),
    XRegex(Text, Text),
    XReplacement(Text, Text, Text),
    XRef(Rc<Ex>),
    XRefMut(Rc<Ex>),
    XDeref(Rc<Ex>),
    XTarget(Rc<Ex>),
    XClone(Rc<Ex>),
    XWeak(Rc<Ex>),
    XUpgrade(Rc<Ex>),
    XBreak(Text, Rc<Ex>),
    XBreakLoop,
    XLater(Rc<Ex>),
    XFormatStr(Array<Ex>),
    XIsCase(Rc<Ex>, Array<Text>),
    XRefusal(Text),
    XUnreachable,
    XCall(Text, Array<Ex>),
    XApply(Rc<Ex>, Array<Ex>),
    XMethod(Rc<Ex>, Text, Array<Ex>),
    XBin(BinOp, Rc<Ex>, Rc<Ex>),
    XUnary(UnOp, Rc<Ex>),
    XCtor(Text, Array<Ex>),
    XRecord(Text, Array<(Text, Ex)>),
    XTuple(Array<Ex>),
    XVec(Array<Ex>),
    XText(Text),
    XFormat(Array<Ex>),
    XMatch(Rc<Ex>, Array<XArm>, bool, OutTy),
    XChain(Text, Rc<Ex>, Array<XArm>, OutTy),
    XIf(Rc<Ex>, Rc<Ex>, Rc<Ex>),
    XBlock(Array<Do>, Rc<Ex>),
    XLabeled(Text, Array<Do>, Rc<Ex>, OutTy),
    XClosure(bool, Array<Pa>, Rc<Ex>),
    XTry(Rc<Ex>),
    XField(Rc<Ex>, Text),
    XPart(Rc<Ex>, Nat),
    XDecode(OutTy, Rc<Ex>),
    XCast(Rc<Ex>, OutTy),
    XTyped(Rc<Ex>, OutTy),
}

impl Show for Ex {
    fn show(&self, p: &mut Printer) {
        match self {
            Ex::XVar(a0) => p.choice("XVar", &[a0]),
            Ex::XPath(a0) => p.choice("XPath", &[a0]),
            Ex::XSelf => p.choice("XSelf", &[]),
            Ex::XCx => p.choice("XCx", &[]),
            Ex::XConst(a0) => p.choice("XConst", &[a0]),
            Ex::XUnit => p.choice("XUnit", &[]),
            Ex::XNone => p.choice("XNone", &[]),
            Ex::XBool(a0) => p.choice("XBool", &[a0]),
            Ex::XNat(a0) => p.choice("XNat", &[a0]),
            Ex::XInt(a0) => p.choice("XInt", &[a0]),
            Ex::XByte(a0) => p.choice("XByte", &[a0]),
            Ex::XFloat(a0) => p.choice("XFloat", &[a0]),
            Ex::XIndex(a0) => p.choice("XIndex", &[a0]),
            Ex::XChar(a0) => p.choice("XChar", &[a0]),
            Ex::XStr(a0) => p.choice("XStr", &[a0]),
            Ex::XRegex(a0, a1) => p.choice("XRegex", &[a0, a1]),
            Ex::XReplacement(a0, a1, a2) => p.choice("XReplacement", &[a0, a1, a2]),
            Ex::XRef(a0) => p.choice("XRef", &[a0]),
            Ex::XRefMut(a0) => p.choice("XRefMut", &[a0]),
            Ex::XDeref(a0) => p.choice("XDeref", &[a0]),
            Ex::XTarget(a0) => p.choice("XTarget", &[a0]),
            Ex::XClone(a0) => p.choice("XClone", &[a0]),
            Ex::XWeak(a0) => p.choice("XWeak", &[a0]),
            Ex::XUpgrade(a0) => p.choice("XUpgrade", &[a0]),
            Ex::XBreak(a0, a1) => p.choice("XBreak", &[a0, a1]),
            Ex::XBreakLoop => p.choice("XBreakLoop", &[]),
            Ex::XLater(a0) => p.choice("XLater", &[a0]),
            Ex::XFormatStr(a0) => p.choice("XFormatStr", &[a0]),
            Ex::XIsCase(a0, a1) => p.choice("XIsCase", &[a0, a1]),
            Ex::XRefusal(a0) => p.choice("XRefusal", &[a0]),
            Ex::XUnreachable => p.choice("XUnreachable", &[]),
            Ex::XCall(a0, a1) => p.choice("XCall", &[a0, a1]),
            Ex::XApply(a0, a1) => p.choice("XApply", &[a0, a1]),
            Ex::XMethod(a0, a1, a2) => p.choice("XMethod", &[a0, a1, a2]),
            Ex::XBin(a0, a1, a2) => p.choice("XBin", &[a0, a1, a2]),
            Ex::XUnary(a0, a1) => p.choice("XUnary", &[a0, a1]),
            Ex::XCtor(a0, a1) => p.choice("XCtor", &[a0, a1]),
            Ex::XRecord(a0, a1) => p.choice("XRecord", &[a0, a1]),
            Ex::XTuple(a0) => p.choice("XTuple", &[a0]),
            Ex::XVec(a0) => p.choice("XVec", &[a0]),
            Ex::XText(a0) => p.choice("XText", &[a0]),
            Ex::XFormat(a0) => p.choice("XFormat", &[a0]),
            Ex::XMatch(a0, a1, a2, a3) => p.choice("XMatch", &[a0, a1, a2, a3]),
            Ex::XChain(a0, a1, a2, a3) => p.choice("XChain", &[a0, a1, a2, a3]),
            Ex::XIf(a0, a1, a2) => p.choice("XIf", &[a0, a1, a2]),
            Ex::XBlock(a0, a1) => p.choice("XBlock", &[a0, a1]),
            Ex::XLabeled(a0, a1, a2, a3) => p.choice("XLabeled", &[a0, a1, a2, a3]),
            Ex::XClosure(a0, a1, a2) => p.choice("XClosure", &[a0, a1, a2]),
            Ex::XTry(a0) => p.choice("XTry", &[a0]),
            Ex::XField(a0, a1) => p.choice("XField", &[a0, a1]),
            Ex::XPart(a0, a1) => p.choice("XPart", &[a0, a1]),
            Ex::XDecode(a0, a1) => p.choice("XDecode", &[a0, a1]),
            Ex::XCast(a0, a1) => p.choice("XCast", &[a0, a1]),
            Ex::XTyped(a0, a1) => p.choice("XTyped", &[a0, a1]),
        }
    }
}

impl ToPod for Ex {
    fn to_pod(&self) -> Pod {
        match self {
            Ex::XVar(a0) => Pod::Choice("XVar".into(), vec![a0.to_pod()]),
            Ex::XPath(a0) => Pod::Choice("XPath".into(), vec![a0.to_pod()]),
            Ex::XSelf => Pod::Choice("XSelf".into(), vec![]),
            Ex::XCx => Pod::Choice("XCx".into(), vec![]),
            Ex::XConst(a0) => Pod::Choice("XConst".into(), vec![a0.to_pod()]),
            Ex::XUnit => Pod::Choice("XUnit".into(), vec![]),
            Ex::XNone => Pod::Choice("XNone".into(), vec![]),
            Ex::XBool(a0) => Pod::Choice("XBool".into(), vec![a0.to_pod()]),
            Ex::XNat(a0) => Pod::Choice("XNat".into(), vec![a0.to_pod()]),
            Ex::XInt(a0) => Pod::Choice("XInt".into(), vec![a0.to_pod()]),
            Ex::XByte(a0) => Pod::Choice("XByte".into(), vec![a0.to_pod()]),
            Ex::XFloat(a0) => Pod::Choice("XFloat".into(), vec![a0.to_pod()]),
            Ex::XIndex(a0) => Pod::Choice("XIndex".into(), vec![a0.to_pod()]),
            Ex::XChar(a0) => Pod::Choice("XChar".into(), vec![a0.to_pod()]),
            Ex::XStr(a0) => Pod::Choice("XStr".into(), vec![a0.to_pod()]),
            Ex::XRegex(a0, a1) => Pod::Choice("XRegex".into(), vec![a0.to_pod(), a1.to_pod()]),
            Ex::XReplacement(a0, a1, a2) => Pod::Choice("XReplacement".into(), vec![a0.to_pod(), a1.to_pod(), a2.to_pod()]),
            Ex::XRef(a0) => Pod::Choice("XRef".into(), vec![a0.to_pod()]),
            Ex::XRefMut(a0) => Pod::Choice("XRefMut".into(), vec![a0.to_pod()]),
            Ex::XDeref(a0) => Pod::Choice("XDeref".into(), vec![a0.to_pod()]),
            Ex::XTarget(a0) => Pod::Choice("XTarget".into(), vec![a0.to_pod()]),
            Ex::XClone(a0) => Pod::Choice("XClone".into(), vec![a0.to_pod()]),
            Ex::XWeak(a0) => Pod::Choice("XWeak".into(), vec![a0.to_pod()]),
            Ex::XUpgrade(a0) => Pod::Choice("XUpgrade".into(), vec![a0.to_pod()]),
            Ex::XBreak(a0, a1) => Pod::Choice("XBreak".into(), vec![a0.to_pod(), a1.to_pod()]),
            Ex::XBreakLoop => Pod::Choice("XBreakLoop".into(), vec![]),
            Ex::XLater(a0) => Pod::Choice("XLater".into(), vec![a0.to_pod()]),
            Ex::XFormatStr(a0) => Pod::Choice("XFormatStr".into(), vec![a0.to_pod()]),
            Ex::XIsCase(a0, a1) => Pod::Choice("XIsCase".into(), vec![a0.to_pod(), a1.to_pod()]),
            Ex::XRefusal(a0) => Pod::Choice("XRefusal".into(), vec![a0.to_pod()]),
            Ex::XUnreachable => Pod::Choice("XUnreachable".into(), vec![]),
            Ex::XCall(a0, a1) => Pod::Choice("XCall".into(), vec![a0.to_pod(), a1.to_pod()]),
            Ex::XApply(a0, a1) => Pod::Choice("XApply".into(), vec![a0.to_pod(), a1.to_pod()]),
            Ex::XMethod(a0, a1, a2) => Pod::Choice("XMethod".into(), vec![a0.to_pod(), a1.to_pod(), a2.to_pod()]),
            Ex::XBin(a0, a1, a2) => Pod::Choice("XBin".into(), vec![a0.to_pod(), a1.to_pod(), a2.to_pod()]),
            Ex::XUnary(a0, a1) => Pod::Choice("XUnary".into(), vec![a0.to_pod(), a1.to_pod()]),
            Ex::XCtor(a0, a1) => Pod::Choice("XCtor".into(), vec![a0.to_pod(), a1.to_pod()]),
            Ex::XRecord(a0, a1) => Pod::Choice("XRecord".into(), vec![a0.to_pod(), a1.to_pod()]),
            Ex::XTuple(a0) => Pod::Choice("XTuple".into(), vec![a0.to_pod()]),
            Ex::XVec(a0) => Pod::Choice("XVec".into(), vec![a0.to_pod()]),
            Ex::XText(a0) => Pod::Choice("XText".into(), vec![a0.to_pod()]),
            Ex::XFormat(a0) => Pod::Choice("XFormat".into(), vec![a0.to_pod()]),
            Ex::XMatch(a0, a1, a2, a3) => Pod::Choice("XMatch".into(), vec![a0.to_pod(), a1.to_pod(), a2.to_pod(), a3.to_pod()]),
            Ex::XChain(a0, a1, a2, a3) => Pod::Choice("XChain".into(), vec![a0.to_pod(), a1.to_pod(), a2.to_pod(), a3.to_pod()]),
            Ex::XIf(a0, a1, a2) => Pod::Choice("XIf".into(), vec![a0.to_pod(), a1.to_pod(), a2.to_pod()]),
            Ex::XBlock(a0, a1) => Pod::Choice("XBlock".into(), vec![a0.to_pod(), a1.to_pod()]),
            Ex::XLabeled(a0, a1, a2, a3) => Pod::Choice("XLabeled".into(), vec![a0.to_pod(), a1.to_pod(), a2.to_pod(), a3.to_pod()]),
            Ex::XClosure(a0, a1, a2) => Pod::Choice("XClosure".into(), vec![a0.to_pod(), a1.to_pod(), a2.to_pod()]),
            Ex::XTry(a0) => Pod::Choice("XTry".into(), vec![a0.to_pod()]),
            Ex::XField(a0, a1) => Pod::Choice("XField".into(), vec![a0.to_pod(), a1.to_pod()]),
            Ex::XPart(a0, a1) => Pod::Choice("XPart".into(), vec![a0.to_pod(), a1.to_pod()]),
            Ex::XDecode(a0, a1) => Pod::Choice("XDecode".into(), vec![a0.to_pod(), a1.to_pod()]),
            Ex::XCast(a0, a1) => Pod::Choice("XCast".into(), vec![a0.to_pod(), a1.to_pod()]),
            Ex::XTyped(a0, a1) => Pod::Choice("XTyped".into(), vec![a0.to_pod(), a1.to_pod()]),
        }
    }
}

impl FromPod for Ex {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "XVar" && a.len() == 1 => Ok(Ex::XVar(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "XPath" && a.len() == 1 => Ok(Ex::XPath(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "XSelf" && a.len() == 0 => Ok(Ex::XSelf),
            Pod::Choice(c, a) if &**c == "XCx" && a.len() == 0 => Ok(Ex::XCx),
            Pod::Choice(c, a) if &**c == "XConst" && a.len() == 1 => Ok(Ex::XConst(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "XUnit" && a.len() == 0 => Ok(Ex::XUnit),
            Pod::Choice(c, a) if &**c == "XNone" && a.len() == 0 => Ok(Ex::XNone),
            Pod::Choice(c, a) if &**c == "XBool" && a.len() == 1 => Ok(Ex::XBool(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "XNat" && a.len() == 1 => Ok(Ex::XNat(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "XInt" && a.len() == 1 => Ok(Ex::XInt(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "XByte" && a.len() == 1 => Ok(Ex::XByte(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "XFloat" && a.len() == 1 => Ok(Ex::XFloat(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "XIndex" && a.len() == 1 => Ok(Ex::XIndex(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "XChar" && a.len() == 1 => Ok(Ex::XChar(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "XStr" && a.len() == 1 => Ok(Ex::XStr(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "XRegex" && a.len() == 2 => Ok(Ex::XRegex(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "XReplacement" && a.len() == 3 => Ok(Ex::XReplacement(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?, FromPod::from_pod(&a[2])?)),
            Pod::Choice(c, a) if &**c == "XRef" && a.len() == 1 => Ok(Ex::XRef(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "XRefMut" && a.len() == 1 => Ok(Ex::XRefMut(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "XDeref" && a.len() == 1 => Ok(Ex::XDeref(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "XTarget" && a.len() == 1 => Ok(Ex::XTarget(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "XClone" && a.len() == 1 => Ok(Ex::XClone(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "XWeak" && a.len() == 1 => Ok(Ex::XWeak(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "XUpgrade" && a.len() == 1 => Ok(Ex::XUpgrade(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "XBreak" && a.len() == 2 => Ok(Ex::XBreak(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "XBreakLoop" && a.len() == 0 => Ok(Ex::XBreakLoop),
            Pod::Choice(c, a) if &**c == "XLater" && a.len() == 1 => Ok(Ex::XLater(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "XFormatStr" && a.len() == 1 => Ok(Ex::XFormatStr(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "XIsCase" && a.len() == 2 => Ok(Ex::XIsCase(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "XRefusal" && a.len() == 1 => Ok(Ex::XRefusal(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "XUnreachable" && a.len() == 0 => Ok(Ex::XUnreachable),
            Pod::Choice(c, a) if &**c == "XCall" && a.len() == 2 => Ok(Ex::XCall(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "XApply" && a.len() == 2 => Ok(Ex::XApply(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "XMethod" && a.len() == 3 => Ok(Ex::XMethod(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?, FromPod::from_pod(&a[2])?)),
            Pod::Choice(c, a) if &**c == "XBin" && a.len() == 3 => Ok(Ex::XBin(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?, FromPod::from_pod(&a[2])?)),
            Pod::Choice(c, a) if &**c == "XUnary" && a.len() == 2 => Ok(Ex::XUnary(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "XCtor" && a.len() == 2 => Ok(Ex::XCtor(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "XRecord" && a.len() == 2 => Ok(Ex::XRecord(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "XTuple" && a.len() == 1 => Ok(Ex::XTuple(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "XVec" && a.len() == 1 => Ok(Ex::XVec(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "XText" && a.len() == 1 => Ok(Ex::XText(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "XFormat" && a.len() == 1 => Ok(Ex::XFormat(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "XMatch" && a.len() == 4 => Ok(Ex::XMatch(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?, FromPod::from_pod(&a[2])?, FromPod::from_pod(&a[3])?)),
            Pod::Choice(c, a) if &**c == "XChain" && a.len() == 4 => Ok(Ex::XChain(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?, FromPod::from_pod(&a[2])?, FromPod::from_pod(&a[3])?)),
            Pod::Choice(c, a) if &**c == "XIf" && a.len() == 3 => Ok(Ex::XIf(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?, FromPod::from_pod(&a[2])?)),
            Pod::Choice(c, a) if &**c == "XBlock" && a.len() == 2 => Ok(Ex::XBlock(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "XLabeled" && a.len() == 4 => Ok(Ex::XLabeled(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?, FromPod::from_pod(&a[2])?, FromPod::from_pod(&a[3])?)),
            Pod::Choice(c, a) if &**c == "XClosure" && a.len() == 3 => Ok(Ex::XClosure(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?, FromPod::from_pod(&a[2])?)),
            Pod::Choice(c, a) if &**c == "XTry" && a.len() == 1 => Ok(Ex::XTry(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "XField" && a.len() == 2 => Ok(Ex::XField(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "XPart" && a.len() == 2 => Ok(Ex::XPart(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "XDecode" && a.len() == 2 => Ok(Ex::XDecode(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "XCast" && a.len() == 2 => Ok(Ex::XCast(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "XTyped" && a.len() == 2 => Ok(Ex::XTyped(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            other => mismatch("a Ex", other),
        }
    }
}

/// `FnDef`:
///
/// ```prism
/// type FnDef = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct FnDef {
    pub name_p: Text,
    pub generics_p: Array<(Text, Array<Text>)>,
    pub params_p: Array<(Text, OutTy)>,
    pub ret_p: OutTy,
    pub body_p: Ex,
    pub doc_p: Text,
    pub public_p: bool,
}

impl Show for FnDef {
    fn show(&self, p: &mut Printer) {
        p.record("FnDef", &[("name", &self.name_p), ("generics", &self.generics_p), ("params", &self.params_p), ("ret", &self.ret_p), ("body", &self.body_p), ("doc", &self.doc_p), ("public", &self.public_p)]);
    }
}

impl ToPod for FnDef {
    fn to_pod(&self) -> Pod {
        Pod::record("FnDef", vec![("name", self.name_p.to_pod()), ("generics", self.generics_p.to_pod()), ("params", self.params_p.to_pod()), ("ret", self.ret_p.to_pod()), ("body", self.body_p.to_pod()), ("doc", self.doc_p.to_pod()), ("public", self.public_p.to_pod())])
    }
}

impl FromPod for FnDef {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(FnDef { name_p: FromPod::from_pod(field(p, "name")?)?, generics_p: FromPod::from_pod(field(p, "generics")?)?, params_p: FromPod::from_pod(field(p, "params")?)?, ret_p: FromPod::from_pod(field(p, "ret")?)?, body_p: FromPod::from_pod(field(p, "body")?)?, doc_p: FromPod::from_pod(field(p, "doc")?)?, public_p: FromPod::from_pod(field(p, "public")?)? })
    }
}

/// `ForDef`:
///
/// ```prism
/// type ForDef = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct ForDef {
    pub name_p: Text,
    pub pos_p: Pos_,
    pub at_p: Ex,
    pub key_ty_p: OutTy,
    pub value_ty_p: OutTy,
    pub row_node_p: Text,
    pub keyed_p: bool,
    pub source_p: Text,
    pub parent_p: Ex,
    pub passed_p: Array<Ex>,
    pub moved_p: Text,
    pub replaced_p: Array<Text>,
}

impl Show for ForDef {
    fn show(&self, p: &mut Printer) {
        p.record("ForDef", &[("name", &self.name_p), ("pos", &self.pos_p), ("at", &self.at_p), ("keyTy", &self.key_ty_p), ("valueTy", &self.value_ty_p), ("rowNode", &self.row_node_p), ("keyed", &self.keyed_p), ("source", &self.source_p), ("parent", &self.parent_p), ("passed", &self.passed_p), ("moved", &self.moved_p), ("replaced", &self.replaced_p)]);
    }
}

impl ToPod for ForDef {
    fn to_pod(&self) -> Pod {
        Pod::record("ForDef", vec![("name", self.name_p.to_pod()), ("pos", self.pos_p.to_pod()), ("at", self.at_p.to_pod()), ("keyTy", self.key_ty_p.to_pod()), ("valueTy", self.value_ty_p.to_pod()), ("rowNode", self.row_node_p.to_pod()), ("keyed", self.keyed_p.to_pod()), ("source", self.source_p.to_pod()), ("parent", self.parent_p.to_pod()), ("passed", self.passed_p.to_pod()), ("moved", self.moved_p.to_pod()), ("replaced", self.replaced_p.to_pod())])
    }
}

impl FromPod for ForDef {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(ForDef { name_p: FromPod::from_pod(field(p, "name")?)?, pos_p: FromPod::from_pod(field(p, "pos")?)?, at_p: FromPod::from_pod(field(p, "at")?)?, key_ty_p: FromPod::from_pod(field(p, "keyTy")?)?, value_ty_p: FromPod::from_pod(field(p, "valueTy")?)?, row_node_p: FromPod::from_pod(field(p, "rowNode")?)?, keyed_p: FromPod::from_pod(field(p, "keyed")?)?, source_p: FromPod::from_pod(field(p, "source")?)?, parent_p: FromPod::from_pod(field(p, "parent")?)?, passed_p: FromPod::from_pod(field(p, "passed")?)?, moved_p: FromPod::from_pod(field(p, "moved")?)?, replaced_p: FromPod::from_pod(field(p, "replaced")?)? })
    }
}

/// `GenDef`:
///
/// ```prism
/// type GenDef = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct GenDef {
    pub name_p: Text,
    pub pos_p: Pos_,
    pub at_p: Ex,
    pub source_p: Ex,
    pub value_ty_p: OutTy,
    pub select_p: Ex,
    pub transparent_p: bool,
    pub width_p: Nat,
    pub moved_p: Text,
}

impl Show for GenDef {
    fn show(&self, p: &mut Printer) {
        p.record("GenDef", &[("name", &self.name_p), ("pos", &self.pos_p), ("at", &self.at_p), ("source", &self.source_p), ("valueTy", &self.value_ty_p), ("select", &self.select_p), ("transparent", &self.transparent_p), ("width", &self.width_p), ("moved", &self.moved_p)]);
    }
}

impl ToPod for GenDef {
    fn to_pod(&self) -> Pod {
        Pod::record("GenDef", vec![("name", self.name_p.to_pod()), ("pos", self.pos_p.to_pod()), ("at", self.at_p.to_pod()), ("source", self.source_p.to_pod()), ("valueTy", self.value_ty_p.to_pod()), ("select", self.select_p.to_pod()), ("transparent", self.transparent_p.to_pod()), ("width", self.width_p.to_pod()), ("moved", self.moved_p.to_pod())])
    }
}

impl FromPod for GenDef {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(GenDef { name_p: FromPod::from_pod(field(p, "name")?)?, pos_p: FromPod::from_pod(field(p, "pos")?)?, at_p: FromPod::from_pod(field(p, "at")?)?, source_p: FromPod::from_pod(field(p, "source")?)?, value_ty_p: FromPod::from_pod(field(p, "valueTy")?)?, select_p: FromPod::from_pod(field(p, "select")?)?, transparent_p: FromPod::from_pod(field(p, "transparent")?)?, width_p: FromPod::from_pod(field(p, "width")?)?, moved_p: FromPod::from_pod(field(p, "moved")?)? })
    }
}

/// `ImplDef`:
///
/// ```prism
/// type ImplDef = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct ImplDef {
    pub cls_p: Text,
    pub tr_p: Text,
    pub head_p: OutTy,
    pub generics_p: Array<(Text, Array<Text>)>,
    pub methods_p: Array<FnDef>,
    pub doc_p: Text,
}

impl Show for ImplDef {
    fn show(&self, p: &mut Printer) {
        p.record("ImplDef", &[("cls", &self.cls_p), ("tr", &self.tr_p), ("head", &self.head_p), ("generics", &self.generics_p), ("methods", &self.methods_p), ("doc", &self.doc_p)]);
    }
}

impl ToPod for ImplDef {
    fn to_pod(&self) -> Pod {
        Pod::record("ImplDef", vec![("cls", self.cls_p.to_pod()), ("tr", self.tr_p.to_pod()), ("head", self.head_p.to_pod()), ("generics", self.generics_p.to_pod()), ("methods", self.methods_p.to_pod()), ("doc", self.doc_p.to_pod())])
    }
}

impl FromPod for ImplDef {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(ImplDef { cls_p: FromPod::from_pod(field(p, "cls")?)?, tr_p: FromPod::from_pod(field(p, "tr")?)?, head_p: FromPod::from_pod(field(p, "head")?)?, generics_p: FromPod::from_pod(field(p, "generics")?)?, methods_p: FromPod::from_pod(field(p, "methods")?)?, doc_p: FromPod::from_pod(field(p, "doc")?)? })
    }
}

/// `Item`:
///
/// ```prism
/// type Item = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum Item {
    ItTrait(TraitDef),
    ItImpl(ImplDef),
    ItType(TyDef),
    ItTag(TagDef),
    ItRow(RowDef),
    ItFn(FnDef),
    ItJob(JobDef),
    ItNode(NodeDef),
    ItNote(Text),
    ItRefused(Text),
}

impl Show for Item {
    fn show(&self, p: &mut Printer) {
        match self {
            Item::ItTrait(a0) => p.choice("ItTrait", &[a0]),
            Item::ItImpl(a0) => p.choice("ItImpl", &[a0]),
            Item::ItType(a0) => p.choice("ItType", &[a0]),
            Item::ItTag(a0) => p.choice("ItTag", &[a0]),
            Item::ItRow(a0) => p.choice("ItRow", &[a0]),
            Item::ItFn(a0) => p.choice("ItFn", &[a0]),
            Item::ItJob(a0) => p.choice("ItJob", &[a0]),
            Item::ItNode(a0) => p.choice("ItNode", &[a0]),
            Item::ItNote(a0) => p.choice("ItNote", &[a0]),
            Item::ItRefused(a0) => p.choice("ItRefused", &[a0]),
        }
    }
}

impl ToPod for Item {
    fn to_pod(&self) -> Pod {
        match self {
            Item::ItTrait(a0) => Pod::Choice("ItTrait".into(), vec![a0.to_pod()]),
            Item::ItImpl(a0) => Pod::Choice("ItImpl".into(), vec![a0.to_pod()]),
            Item::ItType(a0) => Pod::Choice("ItType".into(), vec![a0.to_pod()]),
            Item::ItTag(a0) => Pod::Choice("ItTag".into(), vec![a0.to_pod()]),
            Item::ItRow(a0) => Pod::Choice("ItRow".into(), vec![a0.to_pod()]),
            Item::ItFn(a0) => Pod::Choice("ItFn".into(), vec![a0.to_pod()]),
            Item::ItJob(a0) => Pod::Choice("ItJob".into(), vec![a0.to_pod()]),
            Item::ItNode(a0) => Pod::Choice("ItNode".into(), vec![a0.to_pod()]),
            Item::ItNote(a0) => Pod::Choice("ItNote".into(), vec![a0.to_pod()]),
            Item::ItRefused(a0) => Pod::Choice("ItRefused".into(), vec![a0.to_pod()]),
        }
    }
}

impl FromPod for Item {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "ItTrait" && a.len() == 1 => Ok(Item::ItTrait(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "ItImpl" && a.len() == 1 => Ok(Item::ItImpl(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "ItType" && a.len() == 1 => Ok(Item::ItType(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "ItTag" && a.len() == 1 => Ok(Item::ItTag(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "ItRow" && a.len() == 1 => Ok(Item::ItRow(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "ItFn" && a.len() == 1 => Ok(Item::ItFn(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "ItJob" && a.len() == 1 => Ok(Item::ItJob(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "ItNode" && a.len() == 1 => Ok(Item::ItNode(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "ItNote" && a.len() == 1 => Ok(Item::ItNote(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "ItRefused" && a.len() == 1 => Ok(Item::ItRefused(FromPod::from_pod(&a[0])?)),
            other => mismatch("a Item", other),
        }
    }
}

/// `JobDef`:
///
/// ```prism
/// type JobDef = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct JobDef {
    pub name_p: Text,
    pub start_p: Text,
    pub generics_p: Array<(Text, Array<Text>)>,
    pub fields_p: Array<(Text, OutTy)>,
    pub ret_p: OutTy,
    pub body_p: Ex,
    pub doc_p: Text,
}

impl Show for JobDef {
    fn show(&self, p: &mut Printer) {
        p.record("JobDef", &[("name", &self.name_p), ("start", &self.start_p), ("generics", &self.generics_p), ("fields", &self.fields_p), ("ret", &self.ret_p), ("body", &self.body_p), ("doc", &self.doc_p)]);
    }
}

impl ToPod for JobDef {
    fn to_pod(&self) -> Pod {
        Pod::record("JobDef", vec![("name", self.name_p.to_pod()), ("start", self.start_p.to_pod()), ("generics", self.generics_p.to_pod()), ("fields", self.fields_p.to_pod()), ("ret", self.ret_p.to_pod()), ("body", self.body_p.to_pod()), ("doc", self.doc_p.to_pod())])
    }
}

impl FromPod for JobDef {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(JobDef { name_p: FromPod::from_pod(field(p, "name")?)?, start_p: FromPod::from_pod(field(p, "start")?)?, generics_p: FromPod::from_pod(field(p, "generics")?)?, fields_p: FromPod::from_pod(field(p, "fields")?)?, ret_p: FromPod::from_pod(field(p, "ret")?)?, body_p: FromPod::from_pod(field(p, "body")?)?, doc_p: FromPod::from_pod(field(p, "doc")?)? })
    }
}

/// `MethDef`:
///
/// ```prism
/// type MethDef = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct MethDef {
    pub name_p: Text,
    pub recv_p: Recv,
    pub params_p: Array<(Text, OutTy)>,
    pub cx_p: CxArg,
    pub ret_p: OutTy,
    pub body_p: Array<Do>,
    pub tail_p: Ex,
    pub doc_p: Text,
}

impl Show for MethDef {
    fn show(&self, p: &mut Printer) {
        p.record("MethDef", &[("name", &self.name_p), ("recv", &self.recv_p), ("params", &self.params_p), ("cx", &self.cx_p), ("ret", &self.ret_p), ("body", &self.body_p), ("tail", &self.tail_p), ("doc", &self.doc_p)]);
    }
}

impl ToPod for MethDef {
    fn to_pod(&self) -> Pod {
        Pod::record("MethDef", vec![("name", self.name_p.to_pod()), ("recv", self.recv_p.to_pod()), ("params", self.params_p.to_pod()), ("cx", self.cx_p.to_pod()), ("ret", self.ret_p.to_pod()), ("body", self.body_p.to_pod()), ("tail", self.tail_p.to_pod()), ("doc", self.doc_p.to_pod())])
    }
}

impl FromPod for MethDef {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(MethDef { name_p: FromPod::from_pod(field(p, "name")?)?, recv_p: FromPod::from_pod(field(p, "recv")?)?, params_p: FromPod::from_pod(field(p, "params")?)?, cx_p: FromPod::from_pod(field(p, "cx")?)?, ret_p: FromPod::from_pod(field(p, "ret")?)?, body_p: FromPod::from_pod(field(p, "body")?)?, tail_p: FromPod::from_pod(field(p, "tail")?)?, doc_p: FromPod::from_pod(field(p, "doc")?)? })
    }
}

/// `ModDef`:
///
/// ```prism
/// type ModDef = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct ModDef {
    pub name_p: Text,
    pub prism_p: Text,
    pub path_p: Text,
    pub uses_p: Array<Text>,
    pub complete_p: Array<Text>,
    pub declared_p: Array<Text>,
    pub types_with_p: Array<Text>,
    pub items_p: Array<Item>,
}

impl Show for ModDef {
    fn show(&self, p: &mut Printer) {
        p.record("ModDef", &[("name", &self.name_p), ("prism", &self.prism_p), ("path", &self.path_p), ("uses", &self.uses_p), ("complete", &self.complete_p), ("declared", &self.declared_p), ("typesWith", &self.types_with_p), ("items", &self.items_p)]);
    }
}

impl ToPod for ModDef {
    fn to_pod(&self) -> Pod {
        Pod::record("ModDef", vec![("name", self.name_p.to_pod()), ("prism", self.prism_p.to_pod()), ("path", self.path_p.to_pod()), ("uses", self.uses_p.to_pod()), ("complete", self.complete_p.to_pod()), ("declared", self.declared_p.to_pod()), ("typesWith", self.types_with_p.to_pod()), ("items", self.items_p.to_pod())])
    }
}

impl FromPod for ModDef {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(ModDef { name_p: FromPod::from_pod(field(p, "name")?)?, prism_p: FromPod::from_pod(field(p, "prism")?)?, path_p: FromPod::from_pod(field(p, "path")?)?, uses_p: FromPod::from_pod(field(p, "uses")?)?, complete_p: FromPod::from_pod(field(p, "complete")?)?, declared_p: FromPod::from_pod(field(p, "declared")?)?, types_with_p: FromPod::from_pod(field(p, "typesWith")?)?, items_p: FromPod::from_pod(field(p, "items")?)? })
    }
}

/// `Model`:
///
/// ```prism
/// type Model = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Model {
    pub name_p: Text,
    pub mods_p: Array<ModDef>,
    pub programs_p: Array<ProgDef>,
    pub root_o: Option<ProgDef>,
    pub checks_p: Array<CheckDef>,
    pub elem_p: RowDef,
    pub answer_p: AnswerDef,
    pub elem_complete_p: Array<Text>,
    pub elem_declared_p: Array<Text>,
    pub scripts_p: Array<Text>,
    pub notes_p: Array<Text>,
}

impl Show for Model {
    fn show(&self, p: &mut Printer) {
        p.record("Model", &[("name", &self.name_p), ("mods", &self.mods_p), ("programs", &self.programs_p), ("root", &self.root_o), ("checks", &self.checks_p), ("elem", &self.elem_p), ("answer", &self.answer_p), ("elemComplete", &self.elem_complete_p), ("elemDeclared", &self.elem_declared_p), ("scripts", &self.scripts_p), ("notes", &self.notes_p)]);
    }
}

impl ToPod for Model {
    fn to_pod(&self) -> Pod {
        Pod::record("Model", vec![("name", self.name_p.to_pod()), ("mods", self.mods_p.to_pod()), ("programs", self.programs_p.to_pod()), ("root", self.root_o.to_pod()), ("checks", self.checks_p.to_pod()), ("elem", self.elem_p.to_pod()), ("answer", self.answer_p.to_pod()), ("elemComplete", self.elem_complete_p.to_pod()), ("elemDeclared", self.elem_declared_p.to_pod()), ("scripts", self.scripts_p.to_pod()), ("notes", self.notes_p.to_pod())])
    }
}

impl FromPod for Model {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Model { name_p: FromPod::from_pod(field(p, "name")?)?, mods_p: FromPod::from_pod(field(p, "mods")?)?, programs_p: FromPod::from_pod(field(p, "programs")?)?, root_o: FromPod::from_pod(field(p, "root")?)?, checks_p: FromPod::from_pod(field(p, "checks")?)?, elem_p: FromPod::from_pod(field(p, "elem")?)?, answer_p: FromPod::from_pod(field(p, "answer")?)?, elem_complete_p: FromPod::from_pod(field(p, "elemComplete")?)?, elem_declared_p: FromPod::from_pod(field(p, "elemDeclared")?)?, scripts_p: FromPod::from_pod(field(p, "scripts")?)?, notes_p: FromPod::from_pod(field(p, "notes")?)? })
    }
}

/// `NodeDef`:
///
/// ```prism
/// type NodeDef = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct NodeDef {
    pub name_p: Text,
    pub prism_p: Text,
    pub doc_p: Text,
    pub params_p: Array<(Text, OutTy)>,
    pub fields_p: Array<(Text, OutTy, Text)>,
    pub consts_p: Array<(Text, Nat, Text)>,
    pub lets_p: Array<Do>,
    pub inits_p: Array<(Text, Ex)>,
    pub build_p: Array<Do>,
    pub fallible_p: bool,
    pub methods_p: Array<MethDef>,
    pub answers_p: Array<(Pa, Ex)>,
    pub hooks_p: Array<(Text, Array<Do>)>,
    pub builders_p: Array<ForDef>,
    pub wakes_p: bool,
    pub children_p: Array<NodeDef>,
    pub gens_p: Array<GenDef>,
    pub subs_p: Array<(Text, Text, OutTy)>,
    pub top_p: Nat,
    pub row_kind_p: RowKind,
    pub hosted_p: Array<MethDef>,
}

impl Show for NodeDef {
    fn show(&self, p: &mut Printer) {
        p.record("NodeDef", &[("name", &self.name_p), ("prism", &self.prism_p), ("doc", &self.doc_p), ("params", &self.params_p), ("fields", &self.fields_p), ("consts", &self.consts_p), ("lets", &self.lets_p), ("inits", &self.inits_p), ("build", &self.build_p), ("fallible", &self.fallible_p), ("methods", &self.methods_p), ("answers", &self.answers_p), ("hooks", &self.hooks_p), ("builders", &self.builders_p), ("wakes", &self.wakes_p), ("children", &self.children_p), ("gens", &self.gens_p), ("subs", &self.subs_p), ("top", &self.top_p), ("rowKind", &self.row_kind_p), ("hosted", &self.hosted_p)]);
    }
}

impl ToPod for NodeDef {
    fn to_pod(&self) -> Pod {
        Pod::record("NodeDef", vec![("name", self.name_p.to_pod()), ("prism", self.prism_p.to_pod()), ("doc", self.doc_p.to_pod()), ("params", self.params_p.to_pod()), ("fields", self.fields_p.to_pod()), ("consts", self.consts_p.to_pod()), ("lets", self.lets_p.to_pod()), ("inits", self.inits_p.to_pod()), ("build", self.build_p.to_pod()), ("fallible", self.fallible_p.to_pod()), ("methods", self.methods_p.to_pod()), ("answers", self.answers_p.to_pod()), ("hooks", self.hooks_p.to_pod()), ("builders", self.builders_p.to_pod()), ("wakes", self.wakes_p.to_pod()), ("children", self.children_p.to_pod()), ("gens", self.gens_p.to_pod()), ("subs", self.subs_p.to_pod()), ("top", self.top_p.to_pod()), ("rowKind", self.row_kind_p.to_pod()), ("hosted", self.hosted_p.to_pod())])
    }
}

impl FromPod for NodeDef {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(NodeDef { name_p: FromPod::from_pod(field(p, "name")?)?, prism_p: FromPod::from_pod(field(p, "prism")?)?, doc_p: FromPod::from_pod(field(p, "doc")?)?, params_p: FromPod::from_pod(field(p, "params")?)?, fields_p: FromPod::from_pod(field(p, "fields")?)?, consts_p: FromPod::from_pod(field(p, "consts")?)?, lets_p: FromPod::from_pod(field(p, "lets")?)?, inits_p: FromPod::from_pod(field(p, "inits")?)?, build_p: FromPod::from_pod(field(p, "build")?)?, fallible_p: FromPod::from_pod(field(p, "fallible")?)?, methods_p: FromPod::from_pod(field(p, "methods")?)?, answers_p: FromPod::from_pod(field(p, "answers")?)?, hooks_p: FromPod::from_pod(field(p, "hooks")?)?, builders_p: FromPod::from_pod(field(p, "builders")?)?, wakes_p: FromPod::from_pod(field(p, "wakes")?)?, children_p: FromPod::from_pod(field(p, "children")?)?, gens_p: FromPod::from_pod(field(p, "gens")?)?, subs_p: FromPod::from_pod(field(p, "subs")?)?, top_p: FromPod::from_pod(field(p, "top")?)?, row_kind_p: FromPod::from_pod(field(p, "rowKind")?)?, hosted_p: FromPod::from_pod(field(p, "hosted")?)? })
    }
}

/// `OutTy`:
///
/// ```prism
/// type OutTy = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum OutTy {
    OutNat,
    OutInt,
    OutU8,
    OutFloat,
    OutBool,
    OutChar,
    OutText,
    OutCursor,
    OutRegex,
    OutReplacement,
    OutUnit,
    OutPath,
    OutDuration,
    OutError,
    OutNamed(Text, Array<OutTy>),
    OutOpt(Rc<OutTy>),
    OutRes(Rc<OutTy>),
    OutTuple(Array<OutTy>),
    OutArray(Rc<OutTy>),
    OutMap(Rc<OutTy>, Rc<OutTy>),
    OutFn(Array<OutTy>, Rc<OutTy>),
    OutJobFn(Rc<OutTy>, Rc<OutTy>),
    OutJob(Rc<OutTy>),
    OutEvent(Rc<OutTy>),
    OutDyn(Rc<OutTy>),
    OutGen(Text),
    OutRc(Rc<OutTy>),
    OutRef(Rc<OutTy>),
    OutPod,
    OutShowAny,
    OutHold(Rc<OutTy>),
    OutStamped(Rc<OutTy>),
    OutSnapshot(Rc<OutTy>),
    OutDefer(Rc<OutTy>),
    OutWeak(Text),
    OutCell(Rc<OutTy>),
    OutWakes,
    OutCount,
    OutObj(Rc<OutTy>),
    OutSlice(Rc<OutTy>),
    OutPort(Rc<OutTy>),
    OutLive(Rc<OutTy>),
    OutQuantified(Text),
    OutTurn,
    OutRefused(Text),
}

impl Show for OutTy {
    fn show(&self, p: &mut Printer) {
        match self {
            OutTy::OutNat => p.choice("OutNat", &[]),
            OutTy::OutInt => p.choice("OutInt", &[]),
            OutTy::OutU8 => p.choice("OutU8", &[]),
            OutTy::OutFloat => p.choice("OutFloat", &[]),
            OutTy::OutBool => p.choice("OutBool", &[]),
            OutTy::OutChar => p.choice("OutChar", &[]),
            OutTy::OutText => p.choice("OutText", &[]),
            OutTy::OutCursor => p.choice("OutCursor", &[]),
            OutTy::OutRegex => p.choice("OutRegex", &[]),
            OutTy::OutReplacement => p.choice("OutReplacement", &[]),
            OutTy::OutUnit => p.choice("OutUnit", &[]),
            OutTy::OutPath => p.choice("OutPath", &[]),
            OutTy::OutDuration => p.choice("OutDuration", &[]),
            OutTy::OutError => p.choice("OutError", &[]),
            OutTy::OutNamed(a0, a1) => p.choice("OutNamed", &[a0, a1]),
            OutTy::OutOpt(a0) => p.choice("OutOpt", &[a0]),
            OutTy::OutRes(a0) => p.choice("OutRes", &[a0]),
            OutTy::OutTuple(a0) => p.choice("OutTuple", &[a0]),
            OutTy::OutArray(a0) => p.choice("OutArray", &[a0]),
            OutTy::OutMap(a0, a1) => p.choice("OutMap", &[a0, a1]),
            OutTy::OutFn(a0, a1) => p.choice("OutFn", &[a0, a1]),
            OutTy::OutJobFn(a0, a1) => p.choice("OutJobFn", &[a0, a1]),
            OutTy::OutJob(a0) => p.choice("OutJob", &[a0]),
            OutTy::OutEvent(a0) => p.choice("OutEvent", &[a0]),
            OutTy::OutDyn(a0) => p.choice("OutDyn", &[a0]),
            OutTy::OutGen(a0) => p.choice("OutGen", &[a0]),
            OutTy::OutRc(a0) => p.choice("OutRc", &[a0]),
            OutTy::OutRef(a0) => p.choice("OutRef", &[a0]),
            OutTy::OutPod => p.choice("OutPod", &[]),
            OutTy::OutShowAny => p.choice("OutShowAny", &[]),
            OutTy::OutHold(a0) => p.choice("OutHold", &[a0]),
            OutTy::OutStamped(a0) => p.choice("OutStamped", &[a0]),
            OutTy::OutSnapshot(a0) => p.choice("OutSnapshot", &[a0]),
            OutTy::OutDefer(a0) => p.choice("OutDefer", &[a0]),
            OutTy::OutWeak(a0) => p.choice("OutWeak", &[a0]),
            OutTy::OutCell(a0) => p.choice("OutCell", &[a0]),
            OutTy::OutWakes => p.choice("OutWakes", &[]),
            OutTy::OutCount => p.choice("OutCount", &[]),
            OutTy::OutObj(a0) => p.choice("OutObj", &[a0]),
            OutTy::OutSlice(a0) => p.choice("OutSlice", &[a0]),
            OutTy::OutPort(a0) => p.choice("OutPort", &[a0]),
            OutTy::OutLive(a0) => p.choice("OutLive", &[a0]),
            OutTy::OutQuantified(a0) => p.choice("OutQuantified", &[a0]),
            OutTy::OutTurn => p.choice("OutTurn", &[]),
            OutTy::OutRefused(a0) => p.choice("OutRefused", &[a0]),
        }
    }
}

impl ToPod for OutTy {
    fn to_pod(&self) -> Pod {
        match self {
            OutTy::OutNat => Pod::Choice("OutNat".into(), vec![]),
            OutTy::OutInt => Pod::Choice("OutInt".into(), vec![]),
            OutTy::OutU8 => Pod::Choice("OutU8".into(), vec![]),
            OutTy::OutFloat => Pod::Choice("OutFloat".into(), vec![]),
            OutTy::OutBool => Pod::Choice("OutBool".into(), vec![]),
            OutTy::OutChar => Pod::Choice("OutChar".into(), vec![]),
            OutTy::OutText => Pod::Choice("OutText".into(), vec![]),
            OutTy::OutCursor => Pod::Choice("OutCursor".into(), vec![]),
            OutTy::OutRegex => Pod::Choice("OutRegex".into(), vec![]),
            OutTy::OutReplacement => Pod::Choice("OutReplacement".into(), vec![]),
            OutTy::OutUnit => Pod::Choice("OutUnit".into(), vec![]),
            OutTy::OutPath => Pod::Choice("OutPath".into(), vec![]),
            OutTy::OutDuration => Pod::Choice("OutDuration".into(), vec![]),
            OutTy::OutError => Pod::Choice("OutError".into(), vec![]),
            OutTy::OutNamed(a0, a1) => Pod::Choice("OutNamed".into(), vec![a0.to_pod(), a1.to_pod()]),
            OutTy::OutOpt(a0) => Pod::Choice("OutOpt".into(), vec![a0.to_pod()]),
            OutTy::OutRes(a0) => Pod::Choice("OutRes".into(), vec![a0.to_pod()]),
            OutTy::OutTuple(a0) => Pod::Choice("OutTuple".into(), vec![a0.to_pod()]),
            OutTy::OutArray(a0) => Pod::Choice("OutArray".into(), vec![a0.to_pod()]),
            OutTy::OutMap(a0, a1) => Pod::Choice("OutMap".into(), vec![a0.to_pod(), a1.to_pod()]),
            OutTy::OutFn(a0, a1) => Pod::Choice("OutFn".into(), vec![a0.to_pod(), a1.to_pod()]),
            OutTy::OutJobFn(a0, a1) => Pod::Choice("OutJobFn".into(), vec![a0.to_pod(), a1.to_pod()]),
            OutTy::OutJob(a0) => Pod::Choice("OutJob".into(), vec![a0.to_pod()]),
            OutTy::OutEvent(a0) => Pod::Choice("OutEvent".into(), vec![a0.to_pod()]),
            OutTy::OutDyn(a0) => Pod::Choice("OutDyn".into(), vec![a0.to_pod()]),
            OutTy::OutGen(a0) => Pod::Choice("OutGen".into(), vec![a0.to_pod()]),
            OutTy::OutRc(a0) => Pod::Choice("OutRc".into(), vec![a0.to_pod()]),
            OutTy::OutRef(a0) => Pod::Choice("OutRef".into(), vec![a0.to_pod()]),
            OutTy::OutPod => Pod::Choice("OutPod".into(), vec![]),
            OutTy::OutShowAny => Pod::Choice("OutShowAny".into(), vec![]),
            OutTy::OutHold(a0) => Pod::Choice("OutHold".into(), vec![a0.to_pod()]),
            OutTy::OutStamped(a0) => Pod::Choice("OutStamped".into(), vec![a0.to_pod()]),
            OutTy::OutSnapshot(a0) => Pod::Choice("OutSnapshot".into(), vec![a0.to_pod()]),
            OutTy::OutDefer(a0) => Pod::Choice("OutDefer".into(), vec![a0.to_pod()]),
            OutTy::OutWeak(a0) => Pod::Choice("OutWeak".into(), vec![a0.to_pod()]),
            OutTy::OutCell(a0) => Pod::Choice("OutCell".into(), vec![a0.to_pod()]),
            OutTy::OutWakes => Pod::Choice("OutWakes".into(), vec![]),
            OutTy::OutCount => Pod::Choice("OutCount".into(), vec![]),
            OutTy::OutObj(a0) => Pod::Choice("OutObj".into(), vec![a0.to_pod()]),
            OutTy::OutSlice(a0) => Pod::Choice("OutSlice".into(), vec![a0.to_pod()]),
            OutTy::OutPort(a0) => Pod::Choice("OutPort".into(), vec![a0.to_pod()]),
            OutTy::OutLive(a0) => Pod::Choice("OutLive".into(), vec![a0.to_pod()]),
            OutTy::OutQuantified(a0) => Pod::Choice("OutQuantified".into(), vec![a0.to_pod()]),
            OutTy::OutTurn => Pod::Choice("OutTurn".into(), vec![]),
            OutTy::OutRefused(a0) => Pod::Choice("OutRefused".into(), vec![a0.to_pod()]),
        }
    }
}

impl FromPod for OutTy {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "OutNat" && a.len() == 0 => Ok(OutTy::OutNat),
            Pod::Choice(c, a) if &**c == "OutInt" && a.len() == 0 => Ok(OutTy::OutInt),
            Pod::Choice(c, a) if &**c == "OutU8" && a.len() == 0 => Ok(OutTy::OutU8),
            Pod::Choice(c, a) if &**c == "OutFloat" && a.len() == 0 => Ok(OutTy::OutFloat),
            Pod::Choice(c, a) if &**c == "OutBool" && a.len() == 0 => Ok(OutTy::OutBool),
            Pod::Choice(c, a) if &**c == "OutChar" && a.len() == 0 => Ok(OutTy::OutChar),
            Pod::Choice(c, a) if &**c == "OutText" && a.len() == 0 => Ok(OutTy::OutText),
            Pod::Choice(c, a) if &**c == "OutCursor" && a.len() == 0 => Ok(OutTy::OutCursor),
            Pod::Choice(c, a) if &**c == "OutRegex" && a.len() == 0 => Ok(OutTy::OutRegex),
            Pod::Choice(c, a) if &**c == "OutReplacement" && a.len() == 0 => Ok(OutTy::OutReplacement),
            Pod::Choice(c, a) if &**c == "OutUnit" && a.len() == 0 => Ok(OutTy::OutUnit),
            Pod::Choice(c, a) if &**c == "OutPath" && a.len() == 0 => Ok(OutTy::OutPath),
            Pod::Choice(c, a) if &**c == "OutDuration" && a.len() == 0 => Ok(OutTy::OutDuration),
            Pod::Choice(c, a) if &**c == "OutError" && a.len() == 0 => Ok(OutTy::OutError),
            Pod::Choice(c, a) if &**c == "OutNamed" && a.len() == 2 => Ok(OutTy::OutNamed(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "OutOpt" && a.len() == 1 => Ok(OutTy::OutOpt(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "OutRes" && a.len() == 1 => Ok(OutTy::OutRes(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "OutTuple" && a.len() == 1 => Ok(OutTy::OutTuple(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "OutArray" && a.len() == 1 => Ok(OutTy::OutArray(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "OutMap" && a.len() == 2 => Ok(OutTy::OutMap(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "OutFn" && a.len() == 2 => Ok(OutTy::OutFn(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "OutJobFn" && a.len() == 2 => Ok(OutTy::OutJobFn(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "OutJob" && a.len() == 1 => Ok(OutTy::OutJob(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "OutEvent" && a.len() == 1 => Ok(OutTy::OutEvent(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "OutDyn" && a.len() == 1 => Ok(OutTy::OutDyn(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "OutGen" && a.len() == 1 => Ok(OutTy::OutGen(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "OutRc" && a.len() == 1 => Ok(OutTy::OutRc(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "OutRef" && a.len() == 1 => Ok(OutTy::OutRef(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "OutPod" && a.len() == 0 => Ok(OutTy::OutPod),
            Pod::Choice(c, a) if &**c == "OutShowAny" && a.len() == 0 => Ok(OutTy::OutShowAny),
            Pod::Choice(c, a) if &**c == "OutHold" && a.len() == 1 => Ok(OutTy::OutHold(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "OutStamped" && a.len() == 1 => Ok(OutTy::OutStamped(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "OutSnapshot" && a.len() == 1 => Ok(OutTy::OutSnapshot(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "OutDefer" && a.len() == 1 => Ok(OutTy::OutDefer(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "OutWeak" && a.len() == 1 => Ok(OutTy::OutWeak(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "OutCell" && a.len() == 1 => Ok(OutTy::OutCell(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "OutWakes" && a.len() == 0 => Ok(OutTy::OutWakes),
            Pod::Choice(c, a) if &**c == "OutCount" && a.len() == 0 => Ok(OutTy::OutCount),
            Pod::Choice(c, a) if &**c == "OutObj" && a.len() == 1 => Ok(OutTy::OutObj(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "OutSlice" && a.len() == 1 => Ok(OutTy::OutSlice(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "OutPort" && a.len() == 1 => Ok(OutTy::OutPort(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "OutLive" && a.len() == 1 => Ok(OutTy::OutLive(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "OutQuantified" && a.len() == 1 => Ok(OutTy::OutQuantified(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "OutTurn" && a.len() == 0 => Ok(OutTy::OutTurn),
            Pod::Choice(c, a) if &**c == "OutRefused" && a.len() == 1 => Ok(OutTy::OutRefused(FromPod::from_pod(&a[0])?)),
            other => mismatch("a OutTy", other),
        }
    }
}

/// `Pa`:
///
/// ```prism
/// type Pa = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum Pa {
    PaWild,
    PaBind(Text),
    PaMut(Text),
    PaCtor(Text, Array<Pa>),
    PaUnit(Text),
    PaRecord(Text, Array<(Text, Pa)>, bool),
    PaTuple(Array<Pa>),
    PaChar(Text),
    PaBool(bool),
    PaIndex(Nat),
    PaConst(Text),
    PaSlice(Array<Pa>),
    PaRest(Text),
    PaTyped(Rc<Pa>, OutTy),
}

impl Show for Pa {
    fn show(&self, p: &mut Printer) {
        match self {
            Pa::PaWild => p.choice("PaWild", &[]),
            Pa::PaBind(a0) => p.choice("PaBind", &[a0]),
            Pa::PaMut(a0) => p.choice("PaMut", &[a0]),
            Pa::PaCtor(a0, a1) => p.choice("PaCtor", &[a0, a1]),
            Pa::PaUnit(a0) => p.choice("PaUnit", &[a0]),
            Pa::PaRecord(a0, a1, a2) => p.choice("PaRecord", &[a0, a1, a2]),
            Pa::PaTuple(a0) => p.choice("PaTuple", &[a0]),
            Pa::PaChar(a0) => p.choice("PaChar", &[a0]),
            Pa::PaBool(a0) => p.choice("PaBool", &[a0]),
            Pa::PaIndex(a0) => p.choice("PaIndex", &[a0]),
            Pa::PaConst(a0) => p.choice("PaConst", &[a0]),
            Pa::PaSlice(a0) => p.choice("PaSlice", &[a0]),
            Pa::PaRest(a0) => p.choice("PaRest", &[a0]),
            Pa::PaTyped(a0, a1) => p.choice("PaTyped", &[a0, a1]),
        }
    }
}

impl ToPod for Pa {
    fn to_pod(&self) -> Pod {
        match self {
            Pa::PaWild => Pod::Choice("PaWild".into(), vec![]),
            Pa::PaBind(a0) => Pod::Choice("PaBind".into(), vec![a0.to_pod()]),
            Pa::PaMut(a0) => Pod::Choice("PaMut".into(), vec![a0.to_pod()]),
            Pa::PaCtor(a0, a1) => Pod::Choice("PaCtor".into(), vec![a0.to_pod(), a1.to_pod()]),
            Pa::PaUnit(a0) => Pod::Choice("PaUnit".into(), vec![a0.to_pod()]),
            Pa::PaRecord(a0, a1, a2) => Pod::Choice("PaRecord".into(), vec![a0.to_pod(), a1.to_pod(), a2.to_pod()]),
            Pa::PaTuple(a0) => Pod::Choice("PaTuple".into(), vec![a0.to_pod()]),
            Pa::PaChar(a0) => Pod::Choice("PaChar".into(), vec![a0.to_pod()]),
            Pa::PaBool(a0) => Pod::Choice("PaBool".into(), vec![a0.to_pod()]),
            Pa::PaIndex(a0) => Pod::Choice("PaIndex".into(), vec![a0.to_pod()]),
            Pa::PaConst(a0) => Pod::Choice("PaConst".into(), vec![a0.to_pod()]),
            Pa::PaSlice(a0) => Pod::Choice("PaSlice".into(), vec![a0.to_pod()]),
            Pa::PaRest(a0) => Pod::Choice("PaRest".into(), vec![a0.to_pod()]),
            Pa::PaTyped(a0, a1) => Pod::Choice("PaTyped".into(), vec![a0.to_pod(), a1.to_pod()]),
        }
    }
}

impl FromPod for Pa {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "PaWild" && a.len() == 0 => Ok(Pa::PaWild),
            Pod::Choice(c, a) if &**c == "PaBind" && a.len() == 1 => Ok(Pa::PaBind(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "PaMut" && a.len() == 1 => Ok(Pa::PaMut(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "PaCtor" && a.len() == 2 => Ok(Pa::PaCtor(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "PaUnit" && a.len() == 1 => Ok(Pa::PaUnit(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "PaRecord" && a.len() == 3 => Ok(Pa::PaRecord(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?, FromPod::from_pod(&a[2])?)),
            Pod::Choice(c, a) if &**c == "PaTuple" && a.len() == 1 => Ok(Pa::PaTuple(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "PaChar" && a.len() == 1 => Ok(Pa::PaChar(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "PaBool" && a.len() == 1 => Ok(Pa::PaBool(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "PaIndex" && a.len() == 1 => Ok(Pa::PaIndex(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "PaConst" && a.len() == 1 => Ok(Pa::PaConst(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "PaSlice" && a.len() == 1 => Ok(Pa::PaSlice(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "PaRest" && a.len() == 1 => Ok(Pa::PaRest(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "PaTyped" && a.len() == 2 => Ok(Pa::PaTyped(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            other => mismatch("a Pa", other),
        }
    }
}

/// `Pos`:
///
/// ```prism
/// type Pos = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Pos_ {
    pub scope_p: Nat,
    pub at_p: Nat,
}

impl Show for Pos_ {
    fn show(&self, p: &mut Printer) {
        p.record("Pos", &[("scope", &self.scope_p), ("at", &self.at_p)]);
    }
}

impl ToPod for Pos_ {
    fn to_pod(&self) -> Pod {
        Pod::record("Pos", vec![("scope", self.scope_p.to_pod()), ("at", self.at_p.to_pod())])
    }
}

impl FromPod for Pos_ {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Pos_ { scope_p: FromPod::from_pod(field(p, "scope")?)?, at_p: FromPod::from_pod(field(p, "at")?)? })
    }
}

/// `ProgDef`:
///
/// ```prism
/// type ProgDef = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct ProgDef {
    pub name_p: Text,
    pub prism_p: Text,
    pub node_p: Text,
    pub params_p: Array<(Text, OutTy)>,
    pub fallible_p: bool,
    pub world_p: Text,
}

impl Show for ProgDef {
    fn show(&self, p: &mut Printer) {
        p.record("ProgDef", &[("name", &self.name_p), ("prism", &self.prism_p), ("node", &self.node_p), ("params", &self.params_p), ("fallible", &self.fallible_p), ("world", &self.world_p)]);
    }
}

impl ToPod for ProgDef {
    fn to_pod(&self) -> Pod {
        Pod::record("ProgDef", vec![("name", self.name_p.to_pod()), ("prism", self.prism_p.to_pod()), ("node", self.node_p.to_pod()), ("params", self.params_p.to_pod()), ("fallible", self.fallible_p.to_pod()), ("world", self.world_p.to_pod())])
    }
}

impl FromPod for ProgDef {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(ProgDef { name_p: FromPod::from_pod(field(p, "name")?)?, prism_p: FromPod::from_pod(field(p, "prism")?)?, node_p: FromPod::from_pod(field(p, "node")?)?, params_p: FromPod::from_pod(field(p, "params")?)?, fallible_p: FromPod::from_pod(field(p, "fallible")?)?, world_p: FromPod::from_pod(field(p, "world")?)? })
    }
}

/// `Recv`:
///
/// ```prism
/// type Recv = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum Recv {
    RecvRc,
    RecvRef,
    RecvOwned,
}

impl Show for Recv {
    fn show(&self, p: &mut Printer) {
        match self {
            Recv::RecvRc => p.choice("RecvRc", &[]),
            Recv::RecvRef => p.choice("RecvRef", &[]),
            Recv::RecvOwned => p.choice("RecvOwned", &[]),
        }
    }
}

impl ToPod for Recv {
    fn to_pod(&self) -> Pod {
        match self {
            Recv::RecvRc => Pod::Choice("RecvRc".into(), vec![]),
            Recv::RecvRef => Pod::Choice("RecvRef".into(), vec![]),
            Recv::RecvOwned => Pod::Choice("RecvOwned".into(), vec![]),
        }
    }
}

impl FromPod for Recv {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "RecvRc" && a.len() == 0 => Ok(Recv::RecvRc),
            Pod::Choice(c, a) if &**c == "RecvRef" && a.len() == 0 => Ok(Recv::RecvRef),
            Pod::Choice(c, a) if &**c == "RecvOwned" && a.len() == 0 => Ok(Recv::RecvOwned),
            other => mismatch("a Recv", other),
        }
    }
}

/// `RowDef`:
///
/// ```prism
/// type RowDef = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct RowDef {
    pub name_p: Text,
    pub prism_p: Text,
    pub cases_p: Array<(Text, Text)>,
    pub pod_p: bool,
    pub doc_p: Text,
    pub eq_p: bool,
    pub level_p: bool,
    pub deep_p: Array<Text>,
}

impl Show for RowDef {
    fn show(&self, p: &mut Printer) {
        p.record("RowDef", &[("name", &self.name_p), ("prism", &self.prism_p), ("cases", &self.cases_p), ("pod", &self.pod_p), ("doc", &self.doc_p), ("eq", &self.eq_p), ("level", &self.level_p), ("deep", &self.deep_p)]);
    }
}

impl ToPod for RowDef {
    fn to_pod(&self) -> Pod {
        Pod::record("RowDef", vec![("name", self.name_p.to_pod()), ("prism", self.prism_p.to_pod()), ("cases", self.cases_p.to_pod()), ("pod", self.pod_p.to_pod()), ("doc", self.doc_p.to_pod()), ("eq", self.eq_p.to_pod()), ("level", self.level_p.to_pod()), ("deep", self.deep_p.to_pod())])
    }
}

impl FromPod for RowDef {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(RowDef { name_p: FromPod::from_pod(field(p, "name")?)?, prism_p: FromPod::from_pod(field(p, "prism")?)?, cases_p: FromPod::from_pod(field(p, "cases")?)?, pod_p: FromPod::from_pod(field(p, "pod")?)?, doc_p: FromPod::from_pod(field(p, "doc")?)?, eq_p: FromPod::from_pod(field(p, "eq")?)?, level_p: FromPod::from_pod(field(p, "level")?)?, deep_p: FromPod::from_pod(field(p, "deep")?)? })
    }
}

/// `RowKind`:
///
/// ```prism
/// type RowKind = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum RowKind {
    ForRow,
    GenerationRow,
    NotARow,
}

impl Show for RowKind {
    fn show(&self, p: &mut Printer) {
        match self {
            RowKind::ForRow => p.choice("ForRow", &[]),
            RowKind::GenerationRow => p.choice("GenerationRow", &[]),
            RowKind::NotARow => p.choice("NotARow", &[]),
        }
    }
}

impl ToPod for RowKind {
    fn to_pod(&self) -> Pod {
        match self {
            RowKind::ForRow => Pod::Choice("ForRow".into(), vec![]),
            RowKind::GenerationRow => Pod::Choice("GenerationRow".into(), vec![]),
            RowKind::NotARow => Pod::Choice("NotARow".into(), vec![]),
        }
    }
}

impl FromPod for RowKind {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "ForRow" && a.len() == 0 => Ok(RowKind::ForRow),
            Pod::Choice(c, a) if &**c == "GenerationRow" && a.len() == 0 => Ok(RowKind::GenerationRow),
            Pod::Choice(c, a) if &**c == "NotARow" && a.len() == 0 => Ok(RowKind::NotARow),
            other => mismatch("a RowKind", other),
        }
    }
}

/// `Shown`:
///
/// ```prism
/// type Shown = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum Shown {
    ShownOwn,
    ShownDerived,
    NotShown,
}

impl Show for Shown {
    fn show(&self, p: &mut Printer) {
        match self {
            Shown::ShownOwn => p.choice("ShownOwn", &[]),
            Shown::ShownDerived => p.choice("ShownDerived", &[]),
            Shown::NotShown => p.choice("NotShown", &[]),
        }
    }
}

impl ToPod for Shown {
    fn to_pod(&self) -> Pod {
        match self {
            Shown::ShownOwn => Pod::Choice("ShownOwn".into(), vec![]),
            Shown::ShownDerived => Pod::Choice("ShownDerived".into(), vec![]),
            Shown::NotShown => Pod::Choice("NotShown".into(), vec![]),
        }
    }
}

impl FromPod for Shown {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "ShownOwn" && a.len() == 0 => Ok(Shown::ShownOwn),
            Pod::Choice(c, a) if &**c == "ShownDerived" && a.len() == 0 => Ok(Shown::ShownDerived),
            Pod::Choice(c, a) if &**c == "NotShown" && a.len() == 0 => Ok(Shown::NotShown),
            other => mismatch("a Shown", other),
        }
    }
}

/// `TagDef`:
///
/// ```prism
/// type TagDef = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct TagDef {
    pub name_p: Text,
    pub tag_name_p: Text,
    pub fields_p: Array<(Text, Text, OutTy)>,
    pub doc_p: Text,
    pub pod_p: bool,
    pub eq_p: bool,
}

impl Show for TagDef {
    fn show(&self, p: &mut Printer) {
        p.record("TagDef", &[("name", &self.name_p), ("tagName", &self.tag_name_p), ("fields", &self.fields_p), ("doc", &self.doc_p), ("pod", &self.pod_p), ("eq", &self.eq_p)]);
    }
}

impl ToPod for TagDef {
    fn to_pod(&self) -> Pod {
        Pod::record("TagDef", vec![("name", self.name_p.to_pod()), ("tagName", self.tag_name_p.to_pod()), ("fields", self.fields_p.to_pod()), ("doc", self.doc_p.to_pod()), ("pod", self.pod_p.to_pod()), ("eq", self.eq_p.to_pod())])
    }
}

impl FromPod for TagDef {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(TagDef { name_p: FromPod::from_pod(field(p, "name")?)?, tag_name_p: FromPod::from_pod(field(p, "tagName")?)?, fields_p: FromPod::from_pod(field(p, "fields")?)?, doc_p: FromPod::from_pod(field(p, "doc")?)?, pod_p: FromPod::from_pod(field(p, "pod")?)?, eq_p: FromPod::from_pod(field(p, "eq")?)? })
    }
}

/// `TraitDef`:
///
/// ```prism
/// type TraitDef = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct TraitDef {
    pub name_p: Text,
    pub methods_p: Array<FnDef>,
    pub defaults_p: Array<Text>,
    pub doc_p: Text,
}

impl Show for TraitDef {
    fn show(&self, p: &mut Printer) {
        p.record("TraitDef", &[("name", &self.name_p), ("methods", &self.methods_p), ("defaults", &self.defaults_p), ("doc", &self.doc_p)]);
    }
}

impl ToPod for TraitDef {
    fn to_pod(&self) -> Pod {
        Pod::record("TraitDef", vec![("name", self.name_p.to_pod()), ("methods", self.methods_p.to_pod()), ("defaults", self.defaults_p.to_pod()), ("doc", self.doc_p.to_pod())])
    }
}

impl FromPod for TraitDef {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(TraitDef { name_p: FromPod::from_pod(field(p, "name")?)?, methods_p: FromPod::from_pod(field(p, "methods")?)?, defaults_p: FromPod::from_pod(field(p, "defaults")?)?, doc_p: FromPod::from_pod(field(p, "doc")?)? })
    }
}

/// `TyDef`:
///
/// ```prism
/// type TyDef = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct TyDef {
    pub name_p: Text,
    pub prism_p: Text,
    pub params_p: Array<Text>,
    pub shape_p: TyShape,
    pub cases_p: Array<CaseDef>,
    pub eq_p: bool,
    pub ord_p: bool,
    pub show_p: Shown,
    pub pod_p: bool,
    pub doc_p: Text,
}

impl Show for TyDef {
    fn show(&self, p: &mut Printer) {
        p.record("TyDef", &[("name", &self.name_p), ("prism", &self.prism_p), ("params", &self.params_p), ("shape", &self.shape_p), ("cases", &self.cases_p), ("eq", &self.eq_p), ("ord", &self.ord_p), ("show", &self.show_p), ("pod", &self.pod_p), ("doc", &self.doc_p)]);
    }
}

impl ToPod for TyDef {
    fn to_pod(&self) -> Pod {
        Pod::record("TyDef", vec![("name", self.name_p.to_pod()), ("prism", self.prism_p.to_pod()), ("params", self.params_p.to_pod()), ("shape", self.shape_p.to_pod()), ("cases", self.cases_p.to_pod()), ("eq", self.eq_p.to_pod()), ("ord", self.ord_p.to_pod()), ("show", self.show_p.to_pod()), ("pod", self.pod_p.to_pod()), ("doc", self.doc_p.to_pod())])
    }
}

impl FromPod for TyDef {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(TyDef { name_p: FromPod::from_pod(field(p, "name")?)?, prism_p: FromPod::from_pod(field(p, "prism")?)?, params_p: FromPod::from_pod(field(p, "params")?)?, shape_p: FromPod::from_pod(field(p, "shape")?)?, cases_p: FromPod::from_pod(field(p, "cases")?)?, eq_p: FromPod::from_pod(field(p, "eq")?)?, ord_p: FromPod::from_pod(field(p, "ord")?)?, show_p: FromPod::from_pod(field(p, "show")?)?, pod_p: FromPod::from_pod(field(p, "pod")?)?, doc_p: FromPod::from_pod(field(p, "doc")?)? })
    }
}

/// `TyShape`:
///
/// ```prism
/// type TyShape = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum TyShape {
    ShapeRecord,
    ShapeChoice,
    ShapeNewtype,
    ShapeUnit,
}

impl Show for TyShape {
    fn show(&self, p: &mut Printer) {
        match self {
            TyShape::ShapeRecord => p.choice("ShapeRecord", &[]),
            TyShape::ShapeChoice => p.choice("ShapeChoice", &[]),
            TyShape::ShapeNewtype => p.choice("ShapeNewtype", &[]),
            TyShape::ShapeUnit => p.choice("ShapeUnit", &[]),
        }
    }
}

impl ToPod for TyShape {
    fn to_pod(&self) -> Pod {
        match self {
            TyShape::ShapeRecord => Pod::Choice("ShapeRecord".into(), vec![]),
            TyShape::ShapeChoice => Pod::Choice("ShapeChoice".into(), vec![]),
            TyShape::ShapeNewtype => Pod::Choice("ShapeNewtype".into(), vec![]),
            TyShape::ShapeUnit => Pod::Choice("ShapeUnit".into(), vec![]),
        }
    }
}

impl FromPod for TyShape {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "ShapeRecord" && a.len() == 0 => Ok(TyShape::ShapeRecord),
            Pod::Choice(c, a) if &**c == "ShapeChoice" && a.len() == 0 => Ok(TyShape::ShapeChoice),
            Pod::Choice(c, a) if &**c == "ShapeNewtype" && a.len() == 0 => Ok(TyShape::ShapeNewtype),
            Pod::Choice(c, a) if &**c == "ShapeUnit" && a.len() == 0 => Ok(TyShape::ShapeUnit),
            other => mismatch("a TyShape", other),
        }
    }
}

/// `UnOp`:
///
/// ```prism
/// type UnOp = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum UnOp {
    OpNot,
    OpNeg,
}

impl Show for UnOp {
    fn show(&self, p: &mut Printer) {
        match self {
            UnOp::OpNot => p.choice("OpNot", &[]),
            UnOp::OpNeg => p.choice("OpNeg", &[]),
        }
    }
}

impl ToPod for UnOp {
    fn to_pod(&self) -> Pod {
        match self {
            UnOp::OpNot => Pod::Choice("OpNot".into(), vec![]),
            UnOp::OpNeg => Pod::Choice("OpNeg".into(), vec![]),
        }
    }
}

impl FromPod for UnOp {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "OpNot" && a.len() == 0 => Ok(UnOp::OpNot),
            Pod::Choice(c, a) if &**c == "OpNeg" && a.len() == 0 => Ok(UnOp::OpNeg),
            other => mismatch("a UnOp", other),
        }
    }
}

/// `XArm`:
///
/// ```prism
/// type XArm = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct XArm {
    pub pat_p: Pa,
    pub conds_p: Array<Cc>,
    pub body_p: Ex,
}

impl Show for XArm {
    fn show(&self, p: &mut Printer) {
        p.record("XArm", &[("pat", &self.pat_p), ("conds", &self.conds_p), ("body", &self.body_p)]);
    }
}

impl ToPod for XArm {
    fn to_pod(&self) -> Pod {
        Pod::record("XArm", vec![("pat", self.pat_p.to_pod()), ("conds", self.conds_p.to_pod()), ("body", self.body_p.to_pod())])
    }
}

impl FromPod for XArm {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(XArm { pat_p: FromPod::from_pod(field(p, "pat")?)?, conds_p: FromPod::from_pod(field(p, "conds")?)?, body_p: FromPod::from_pod(field(p, "body")?)? })
    }
}

/// ```prism
/// BinOpText: fn BinOp -> Text
/// ```
pub fn bin_op_text_f(bin_op0: &BinOp) -> Text {
    match bin_op0 {
        BinOp::OpAdd => Text::lit("+"),
        BinOp::OpSub => Text::lit("-"),
        BinOp::OpMul => Text::lit("*"),
        BinOp::OpDiv => Text::lit("/"),
        BinOp::OpEq => Text::lit("=="),
        BinOp::OpNe => Text::lit("!="),
        BinOp::OpLt => Text::lit("<"),
        BinOp::OpLe => Text::lit("<="),
        BinOp::OpGt => Text::lit(">"),
        BinOp::OpGe => Text::lit(">="),
        BinOp::OpAnd => Text::lit("&&"),
        BinOp::OpOr => Text::lit("||"),
    }
}

/// ```prism
/// UnOpText: fn UnOp -> Text
/// ```
pub fn un_op_text_f(un_op0: &UnOp) -> Text {
    match un_op0 {
        UnOp::OpNot => Text::lit("!"),
        UnOp::OpNeg => Text::lit("-"),
    }
}

/// ```prism
/// ?BinOpOf: fn Text -> ?BinOp
/// ```
pub fn bin_op_of_o(text0: &Text) -> Option<BinOp> {
    match text0 {
        c0_0 if (c0_0 == &Text::lit("+")) => Some(BinOp::OpAdd),
        c1_0 if (c1_0 == &Text::lit("-")) => Some(BinOp::OpSub),
        c2_0 if (c2_0 == &Text::lit("*")) => Some(BinOp::OpMul),
        c3_0 if (c3_0 == &Text::lit("/")) => Some(BinOp::OpDiv),
        c4_0 if (c4_0 == &Text::lit("==")) => Some(BinOp::OpEq),
        c5_0 if (c5_0 == &Text::lit("!=")) => Some(BinOp::OpNe),
        c6_0 if (c6_0 == &Text::lit("<")) => Some(BinOp::OpLt),
        c7_0 if (c7_0 == &Text::lit("<=")) => Some(BinOp::OpLe),
        c8_0 if (c8_0 == &Text::lit(">")) => Some(BinOp::OpGt),
        c9_0 if (c9_0 == &Text::lit(">=")) => Some(BinOp::OpGe),
        _ => None,
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// let pos0
/// ```
pub fn pos0_p() -> Pos_ {
    Pos_ { scope_p: Nat::from(0u32), at_p: Nat::from(0u32) }
}

/// ```prism
/// NextPos: fn Pos -> Pos
/// ```
pub fn next_pos_f(p_p0: &Pos_) -> Pos_ {
    let mut this: Pos_ = p_p0.clone();
    this.at_p = &this.at_p + &Nat::from(1u32);
    this
}

/// ```prism
/// ScopePos: fn Nat -> Pos
/// ```
pub fn scope_pos_f(k_p0: &Nat) -> Pos_ {
    Pos_ { scope_p: k_p0.clone(), at_p: Nat::from(0u32) }
}

/// ```prism
/// PlaceText: fn Pos -> Text
/// ```
pub fn place_text_f(p_p0: &Pos_) -> Text {
    if &p_p0.scope_p == &Nat::from(0u32) {
        Text::from(format!("{}", &p_p0.at_p))
    } else {
        Text::from(format!("h{}_{}", &p_p0.scope_p, &p_p0.at_p))
    }
}

/// ```prism
/// ExReads: unbounded fn Ex, Text -> Bool
/// ```
pub fn ex_reads_f(x_p0: &Ex, n_p1: &Text) -> bool {
    match x_p0 {
        Ex::XVar(m_p2) => m_p2 == n_p1,
        Ex::XRef(y_p3) => ex_reads_f(&**y_p3, n_p1),
        Ex::XRefMut(y_p4) => ex_reads_f(&**y_p4, n_p1),
        Ex::XDeref(y_p5) => ex_reads_f(&**y_p5, n_p1),
        Ex::XTarget(y_p6) => ex_reads_f(&**y_p6, n_p1),
        Ex::XClone(y_p7) => ex_reads_f(&**y_p7, n_p1),
        Ex::XWeak(y_p8) => ex_reads_f(&**y_p8, n_p1),
        Ex::XUpgrade(y_p9) => ex_reads_f(&**y_p9, n_p1),
        Ex::XBreak(_, y_pa) => ex_reads_f(&**y_pa, n_p1),
        Ex::XLater(y_pb) => ex_reads_f(&**y_pb, n_p1),
        Ex::XFormatStr(ys_pc) => any_reads_f(ys_pc, n_p1),
        Ex::XIsCase(y_pd, _) => ex_reads_f(&**y_pd, n_p1),
        Ex::XCall(_, ys_pe) => any_reads_f(ys_pe, n_p1),
        Ex::XApply(f_pf, ys_pg) => ex_reads_f(&**f_pf, n_p1) || any_reads_f(ys_pg, n_p1),
        Ex::XMethod(y_ph, _, ys_pi) => ex_reads_f(&**y_ph, n_p1) || any_reads_f(ys_pi, n_p1),
        Ex::XBin(_, a_pj, b_pk) => ex_reads_f(&**a_pj, n_p1) || ex_reads_f(&**b_pk, n_p1),
        Ex::XUnary(_, y_pl) => ex_reads_f(&**y_pl, n_p1),
        Ex::XCtor(_, ys_pm) => any_reads_f(ys_pm, n_p1),
        Ex::XRecord(_, fs_pn) => crate::prelude::run_to_end(crate::prelude::fold_job(fs_pn.clone(), false, {
            let n_p1x = n_p1.clone();
            Rc::new(move |(p0, p1): (bool, (Text, Ex))| {
                let n_p1xy = n_p1x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let f_po = p0;
                    let (_, y_pp) = p1;
                    prism_rtl::Turn::Finished(f_po || ex_reads_f(&y_pp, &n_p1xy))
                }))
            }) as Rc<dyn Fn((bool, (Text, Ex))) -> Rc<dyn prism_rtl::Job<bool>>>
        })),
        Ex::XTuple(ys_pq) => any_reads_f(ys_pq, n_p1),
        Ex::XVec(ys_pr) => any_reads_f(ys_pr, n_p1),
        Ex::XFormat(ys_ps) => any_reads_f(ys_ps, n_p1),
        Ex::XMatch(y_pt, arms_pu, _, _) => ex_reads_f(&**y_pt, n_p1) || arms_read_f(arms_pu, n_p1),
        Ex::XChain(_, y_pv, arms_p10, _) => ex_reads_f(&**y_pv, n_p1) || arms_read_f(arms_p10, n_p1),
        Ex::XIf(c_p11, a_p12, b_p13) => (ex_reads_f(&**c_p11, n_p1) || ex_reads_f(&**a_p12, n_p1)) || ex_reads_f(&**b_p13, n_p1),
        Ex::XBlock(ds_p14, y_p15) => dos_read_f(ds_p14, n_p1) || ex_reads_f(&**y_p15, n_p1),
        Ex::XLabeled(_, ds_p16, y_p17, _) => dos_read_f(ds_p16, n_p1) || ex_reads_f(&**y_p17, n_p1),
        Ex::XClosure(_, _, y_p18) => ex_reads_f(&**y_p18, n_p1),
        Ex::XTry(y_p19) => ex_reads_f(&**y_p19, n_p1),
        Ex::XField(y_p1a, _) => ex_reads_f(&**y_p1a, n_p1),
        Ex::XPart(y_p1b, _) => ex_reads_f(&**y_p1b, n_p1),
        Ex::XDecode(_, y_p1c) => ex_reads_f(&**y_p1c, n_p1),
        Ex::XCast(y_p1d, _) => ex_reads_f(&**y_p1d, n_p1),
        Ex::XTyped(y_p1e, _) => ex_reads_f(&**y_p1e, n_p1),
        _ => false,
    }
}

/// The step machine of `ExReads`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ExReads: unbounded fn Ex, Text -> Bool
/// ```
pub struct ExReads {
    pub x_p0: Ex,
    pub n_p1: Text,
}

impl prism_rtl::Job<bool> for ExReads {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let x_p0 = &self.x_p0;
        let n_p1 = &self.n_p1;
        match x_p0 {
            Ex::XVar(m_p2) => prism_rtl::Turn::Finished(m_p2 == n_p1),
            Ex::XRef(y_p3) => prism_rtl::Turn::More(Rc::new(ExReads { x_p0: (**y_p3).clone(), n_p1: n_p1.clone() })),
            Ex::XRefMut(y_p4) => prism_rtl::Turn::More(Rc::new(ExReads { x_p0: (**y_p4).clone(), n_p1: n_p1.clone() })),
            Ex::XDeref(y_p5) => prism_rtl::Turn::More(Rc::new(ExReads { x_p0: (**y_p5).clone(), n_p1: n_p1.clone() })),
            Ex::XTarget(y_p6) => prism_rtl::Turn::More(Rc::new(ExReads { x_p0: (**y_p6).clone(), n_p1: n_p1.clone() })),
            Ex::XClone(y_p7) => prism_rtl::Turn::More(Rc::new(ExReads { x_p0: (**y_p7).clone(), n_p1: n_p1.clone() })),
            Ex::XWeak(y_p8) => prism_rtl::Turn::More(Rc::new(ExReads { x_p0: (**y_p8).clone(), n_p1: n_p1.clone() })),
            Ex::XUpgrade(y_p9) => prism_rtl::Turn::More(Rc::new(ExReads { x_p0: (**y_p9).clone(), n_p1: n_p1.clone() })),
            Ex::XBreak(_, y_pa) => prism_rtl::Turn::More(Rc::new(ExReads { x_p0: (**y_pa).clone(), n_p1: n_p1.clone() })),
            Ex::XLater(y_pb) => prism_rtl::Turn::More(Rc::new(ExReads { x_p0: (**y_pb).clone(), n_p1: n_p1.clone() })),
            Ex::XFormatStr(ys_pc) => prism_rtl::Turn::More(Rc::new(AnyReads { xs_p0: ys_pc.clone(), n_p1: n_p1.clone() })),
            Ex::XIsCase(y_pd, _) => prism_rtl::Turn::More(Rc::new(ExReads { x_p0: (**y_pd).clone(), n_p1: n_p1.clone() })),
            Ex::XCall(_, ys_pe) => prism_rtl::Turn::More(Rc::new(AnyReads { xs_p0: ys_pe.clone(), n_p1: n_p1.clone() })),
            Ex::XApply(f_pf, ys_pg) => {
                let f_pfx = (**f_pf).clone();
                let n_p1x = n_p1.clone();
                let ys_pgx = ys_pg.clone();
                crate::prelude::call_then(start_ex_reads_f(f_pfx.clone(), n_p1x.clone()), move |ex_reads_f_20115: bool| prism_rtl::Turn::Finished(ex_reads_f_20115 || any_reads_f(&ys_pgx, &n_p1x)))
            },
            Ex::XMethod(y_ph, _, ys_pi) => {
                let n_p1x = n_p1.clone();
                let y_phx = (**y_ph).clone();
                let ys_pix = ys_pi.clone();
                crate::prelude::call_then(start_ex_reads_f(y_phx.clone(), n_p1x.clone()), move |ex_reads_f_20175: bool| prism_rtl::Turn::Finished(ex_reads_f_20175 || any_reads_f(&ys_pix, &n_p1x)))
            },
            Ex::XBin(_, a_pj, b_pk) => {
                let a_pjx = (**a_pj).clone();
                let b_pkx = (**b_pk).clone();
                let n_p1x = n_p1.clone();
                crate::prelude::call_then(start_ex_reads_f(a_pjx.clone(), n_p1x.clone()), move |ex_reads_f_20231: bool| prism_rtl::Turn::Finished(ex_reads_f_20231 || ex_reads_f(&b_pkx, &n_p1x)))
            },
            Ex::XUnary(_, y_pl) => prism_rtl::Turn::More(Rc::new(ExReads { x_p0: (**y_pl).clone(), n_p1: n_p1.clone() })),
            Ex::XCtor(_, ys_pm) => prism_rtl::Turn::More(Rc::new(AnyReads { xs_p0: ys_pm.clone(), n_p1: n_p1.clone() })),
            Ex::XRecord(_, fs_pn) => crate::prelude::fold_job(fs_pn.clone(), false, {
                let n_p1x = n_p1.clone();
                Rc::new(move |(p0, p1): (bool, (Text, Ex))| {
                    let n_p1xy = n_p1x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let f_po = p0;
                        let (_, y_pp) = p1;
                        prism_rtl::Turn::Finished(f_po || ex_reads_f(&y_pp, &n_p1xy))
                    }))
                }) as Rc<dyn Fn((bool, (Text, Ex))) -> Rc<dyn prism_rtl::Job<bool>>>
            }).cycle(),
            Ex::XTuple(ys_pq) => prism_rtl::Turn::More(Rc::new(AnyReads { xs_p0: ys_pq.clone(), n_p1: n_p1.clone() })),
            Ex::XVec(ys_pr) => prism_rtl::Turn::More(Rc::new(AnyReads { xs_p0: ys_pr.clone(), n_p1: n_p1.clone() })),
            Ex::XFormat(ys_ps) => prism_rtl::Turn::More(Rc::new(AnyReads { xs_p0: ys_ps.clone(), n_p1: n_p1.clone() })),
            Ex::XMatch(y_pt, arms_pu, _, _) => {
                let arms_pux = arms_pu.clone();
                let n_p1x = n_p1.clone();
                let y_ptx = (**y_pt).clone();
                crate::prelude::call_then(start_ex_reads_f(y_ptx.clone(), n_p1x.clone()), move |ex_reads_f_20537: bool| prism_rtl::Turn::Finished(ex_reads_f_20537 || arms_read_f(&arms_pux, &n_p1x)))
            },
            Ex::XChain(_, y_pv, arms_p10, _) => {
                let arms_p10x = arms_p10.clone();
                let n_p1x = n_p1.clone();
                let y_pvx = (**y_pv).clone();
                crate::prelude::call_then(start_ex_reads_f(y_pvx.clone(), n_p1x.clone()), move |ex_reads_f_20608: bool| prism_rtl::Turn::Finished(ex_reads_f_20608 || arms_read_f(&arms_p10x, &n_p1x)))
            },
            Ex::XIf(c_p11, a_p12, b_p13) => {
                let a_p12x = (**a_p12).clone();
                let b_p13x = (**b_p13).clone();
                let c_p11x = (**c_p11).clone();
                let n_p1x = n_p1.clone();
                crate::prelude::call_then(start_ex_reads_f(c_p11x.clone(), n_p1x.clone()), move |ex_reads_f_20660: bool| prism_rtl::Turn::Finished((ex_reads_f_20660 || ex_reads_f(&a_p12x, &n_p1x)) || ex_reads_f(&b_p13x, &n_p1x)))
            },
            Ex::XBlock(ds_p14, y_p15) => {
                let ds_p14x = ds_p14.clone();
                let n_p1x = n_p1.clone();
                let y_p15x = (**y_p15).clone();
                crate::prelude::call_then(start_dos_read_f(ds_p14x.clone(), n_p1x.clone()), move |dos_read_f_20727: bool| prism_rtl::Turn::Finished(dos_read_f_20727 || ex_reads_f(&y_p15x, &n_p1x)))
            },
            Ex::XLabeled(_, ds_p16, y_p17, _) => {
                let ds_p16x = ds_p16.clone();
                let n_p1x = n_p1.clone();
                let y_p17x = (**y_p17).clone();
                crate::prelude::call_then(start_dos_read_f(ds_p16x.clone(), n_p1x.clone()), move |dos_read_f_20795: bool| prism_rtl::Turn::Finished(dos_read_f_20795 || ex_reads_f(&y_p17x, &n_p1x)))
            },
            Ex::XClosure(_, _, y_p18) => prism_rtl::Turn::More(Rc::new(ExReads { x_p0: (**y_p18).clone(), n_p1: n_p1.clone() })),
            Ex::XTry(y_p19) => prism_rtl::Turn::More(Rc::new(ExReads { x_p0: (**y_p19).clone(), n_p1: n_p1.clone() })),
            Ex::XField(y_p1a, _) => prism_rtl::Turn::More(Rc::new(ExReads { x_p0: (**y_p1a).clone(), n_p1: n_p1.clone() })),
            Ex::XPart(y_p1b, _) => prism_rtl::Turn::More(Rc::new(ExReads { x_p0: (**y_p1b).clone(), n_p1: n_p1.clone() })),
            Ex::XDecode(_, y_p1c) => prism_rtl::Turn::More(Rc::new(ExReads { x_p0: (**y_p1c).clone(), n_p1: n_p1.clone() })),
            Ex::XCast(y_p1d, _) => prism_rtl::Turn::More(Rc::new(ExReads { x_p0: (**y_p1d).clone(), n_p1: n_p1.clone() })),
            Ex::XTyped(y_p1e, _) => prism_rtl::Turn::More(Rc::new(ExReads { x_p0: (**y_p1e).clone(), n_p1: n_p1.clone() })),
            _ => prism_rtl::Turn::Finished(false),
        }
    }
}

/// `Start ExReads, x`: what the function value is when passed to `@Run`.
pub fn start_ex_reads_f(x_p0: Ex, n_p1: Text) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(ExReads { x_p0, n_p1 })
}

/// ```prism
/// AnyReads: unbounded fn [Ex], Text -> Bool
/// ```
pub fn any_reads_f(xs_p0: &Array<Ex>, n_p1: &Text) -> bool {
    crate::prelude::run_to_end(crate::prelude::fold_job(xs_p0.clone(), false, {
        let n_p1x = n_p1.clone();
        Rc::new(move |(p0, p1): (bool, Ex)| {
            let n_p1xy = n_p1x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let f_p2 = p0;
                let y_p3 = p1;
                prism_rtl::Turn::Finished(f_p2 || ex_reads_f(&y_p3, &n_p1xy))
            }))
        }) as Rc<dyn Fn((bool, Ex)) -> Rc<dyn prism_rtl::Job<bool>>>
    }))
}

/// The step machine of `AnyReads`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// AnyReads: unbounded fn [Ex], Text -> Bool
/// ```
pub struct AnyReads {
    pub xs_p0: Array<Ex>,
    pub n_p1: Text,
}

impl prism_rtl::Job<bool> for AnyReads {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let xs_p0 = &self.xs_p0;
        let n_p1 = &self.n_p1;
        crate::prelude::fold_job(xs_p0.clone(), false, {
            let n_p1x = n_p1.clone();
            Rc::new(move |(p0, p1): (bool, Ex)| {
                let n_p1xy = n_p1x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let f_p2 = p0;
                    let y_p3 = p1;
                    prism_rtl::Turn::Finished(f_p2 || ex_reads_f(&y_p3, &n_p1xy))
                }))
            }) as Rc<dyn Fn((bool, Ex)) -> Rc<dyn prism_rtl::Job<bool>>>
        }).cycle()
    }
}

/// `Start AnyReads, x`: what the function value is when passed to `@Run`.
pub fn start_any_reads_f(xs_p0: Array<Ex>, n_p1: Text) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(AnyReads { xs_p0, n_p1 })
}

/// ```prism
/// ArmsRead: unbounded fn [XArm], Text -> Bool
/// ```
pub fn arms_read_f(arms_p0: &Array<XArm>, n_p1: &Text) -> bool {
    crate::prelude::run_to_end(crate::prelude::fold_job(arms_p0.clone(), false, {
        let n_p1x = n_p1.clone();
        Rc::new(move |(p0, p1): (bool, XArm)| {
            let n_p1xy = n_p1x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let f_p2 = p0;
                let a_p3 = p1;
                prism_rtl::Turn::Finished((f_p2 || ex_reads_f(&a_p3.body_p, &n_p1xy)) || crate::prelude::run_to_end(crate::prelude::fold_job(a_p3.conds_p.clone(), false, {
                    let n_p1xyx = n_p1xy.clone();
                    Rc::new(move |(p0, p1): (bool, Cc)| {
                        let n_p1xyxy = n_p1xyx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let g_p4 = p0;
                            let c_p5 = p1;
                            prism_rtl::Turn::Finished(g_p4 || match &c_p5 {
                                Cc::CcIf(y_p6) => ex_reads_f(y_p6, &n_p1xyxy),
                                Cc::CcLet(_, y_p7) => ex_reads_f(y_p7, &n_p1xyxy),
                            })
                        }))
                    }) as Rc<dyn Fn((bool, Cc)) -> Rc<dyn prism_rtl::Job<bool>>>
                })))
            }))
        }) as Rc<dyn Fn((bool, XArm)) -> Rc<dyn prism_rtl::Job<bool>>>
    }))
}

/// The step machine of `ArmsRead`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ArmsRead: unbounded fn [XArm], Text -> Bool
/// ```
pub struct ArmsRead {
    pub arms_p0: Array<XArm>,
    pub n_p1: Text,
}

impl prism_rtl::Job<bool> for ArmsRead {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let arms_p0 = &self.arms_p0;
        let n_p1 = &self.n_p1;
        crate::prelude::fold_job(arms_p0.clone(), false, {
            let n_p1x = n_p1.clone();
            Rc::new(move |(p0, p1): (bool, XArm)| {
                let n_p1xy = n_p1x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let f_p2 = p0;
                    let a_p3 = p1;
                    prism_rtl::Turn::Finished((f_p2 || ex_reads_f(&a_p3.body_p, &n_p1xy)) || crate::prelude::run_to_end(crate::prelude::fold_job(a_p3.conds_p.clone(), false, {
                        let n_p1xyx = n_p1xy.clone();
                        Rc::new(move |(p0, p1): (bool, Cc)| {
                            let n_p1xyxy = n_p1xyx.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let g_p4 = p0;
                                let c_p5 = p1;
                                prism_rtl::Turn::Finished(g_p4 || match &c_p5 {
                                    Cc::CcIf(y_p6) => ex_reads_f(y_p6, &n_p1xyxy),
                                    Cc::CcLet(_, y_p7) => ex_reads_f(y_p7, &n_p1xyxy),
                                })
                            }))
                        }) as Rc<dyn Fn((bool, Cc)) -> Rc<dyn prism_rtl::Job<bool>>>
                    })))
                }))
            }) as Rc<dyn Fn((bool, XArm)) -> Rc<dyn prism_rtl::Job<bool>>>
        }).cycle()
    }
}

/// `Start ArmsRead, x`: what the function value is when passed to `@Run`.
pub fn start_arms_read_f(arms_p0: Array<XArm>, n_p1: Text) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(ArmsRead { arms_p0, n_p1 })
}

/// ```prism
/// DosRead: unbounded fn [Do], Text -> Bool
/// ```
pub fn dos_read_f(ds_p0: &Array<Do>, n_p1: &Text) -> bool {
    crate::prelude::run_to_end(crate::prelude::fold_job(ds_p0.clone(), false, {
        let n_p1x = n_p1.clone();
        Rc::new(move |(p0, p1): (bool, Do)| {
            let n_p1xy = n_p1x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let f_p2 = p0;
                let d_p3 = p1;
                prism_rtl::Turn::Finished(f_p2 || do_reads_f(&d_p3, &n_p1xy))
            }))
        }) as Rc<dyn Fn((bool, Do)) -> Rc<dyn prism_rtl::Job<bool>>>
    }))
}

/// The step machine of `DosRead`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// DosRead: unbounded fn [Do], Text -> Bool
/// ```
pub struct DosRead {
    pub ds_p0: Array<Do>,
    pub n_p1: Text,
}

impl prism_rtl::Job<bool> for DosRead {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let ds_p0 = &self.ds_p0;
        let n_p1 = &self.n_p1;
        crate::prelude::fold_job(ds_p0.clone(), false, {
            let n_p1x = n_p1.clone();
            Rc::new(move |(p0, p1): (bool, Do)| {
                let n_p1xy = n_p1x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let f_p2 = p0;
                    let d_p3 = p1;
                    prism_rtl::Turn::Finished(f_p2 || do_reads_f(&d_p3, &n_p1xy))
                }))
            }) as Rc<dyn Fn((bool, Do)) -> Rc<dyn prism_rtl::Job<bool>>>
        }).cycle()
    }
}

/// `Start DosRead, x`: what the function value is when passed to `@Run`.
pub fn start_dos_read_f(ds_p0: Array<Do>, n_p1: Text) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(DosRead { ds_p0, n_p1 })
}

/// ```prism
/// DoReads: unbounded fn Do, Text -> Bool
/// ```
pub fn do_reads_f(d_p0: &Do, n_p1: &Text) -> bool {
    match d_p0 {
        Do::DoLet(_, y_p2) => ex_reads_f(y_p2, n_p1),
        Do::DoLetElse(_, y_p3, z_p4) => ex_reads_f(y_p3, n_p1) || ex_reads_f(z_p4, n_p1),
        Do::DoAssign(a_p5, b_p6) => ex_reads_f(a_p5, n_p1) || ex_reads_f(b_p6, n_p1),
        Do::DoWhile(c_p7, ds_p8) => ex_reads_f(c_p7, n_p1) || dos_read_f(ds_p8, n_p1),
        Do::DoWhileLet(_, y_p9, ds_pa) => ex_reads_f(y_p9, n_p1) || dos_read_f(ds_pa, n_p1),
        Do::DoFor(_, y_pb, ds_pc) => ex_reads_f(y_pb, n_p1) || dos_read_f(ds_pc, n_p1),
        Do::DoExpr(y_pd) => ex_reads_f(y_pd, n_p1),
        Do::DoIf(c_pe, a_pf, b_pg) => (ex_reads_f(c_pe, n_p1) || dos_read_f(a_pf, n_p1)) || dos_read_f(b_pg, n_p1),
        Do::DoIfLet(_, y_ph, a_pi, b_pj) => (ex_reads_f(y_ph, n_p1) || dos_read_f(a_pi, n_p1)) || dos_read_f(b_pj, n_p1),
        Do::DoMatch(y_pk, arms_pl) => ex_reads_f(y_pk, n_p1) || crate::prelude::run_to_end(crate::prelude::fold_job(arms_pl.clone(), false, {
            let n_p1x = n_p1.clone();
            Rc::new(move |(p0, p1): (bool, (Pa, Array<Do>))| {
                let n_p1xy = n_p1x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let f_pm = p0;
                    let (_, ds_pn) = p1;
                    prism_rtl::Turn::Finished(f_pm || dos_read_f(&ds_pn, &n_p1xy))
                }))
            }) as Rc<dyn Fn((bool, (Pa, Array<Do>))) -> Rc<dyn prism_rtl::Job<bool>>>
        })),
        Do::DoReturn(y_po) => ex_reads_f(y_po, n_p1),
        Do::DoBlock(ds_pp) => dos_read_f(ds_pp, n_p1),
        Do::DoScope(ds_pq) => dos_read_f(ds_pq, n_p1),
        Do::DoLine(ds_pr) => dos_read_f(ds_pr, n_p1),
        Do::DoNote(_) => false,
    }
}

/// The step machine of `DoReads`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// DoReads: unbounded fn Do, Text -> Bool
/// ```
pub struct DoReads {
    pub d_p0: Do,
    pub n_p1: Text,
}

impl prism_rtl::Job<bool> for DoReads {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let d_p0 = &self.d_p0;
        let n_p1 = &self.n_p1;
        match d_p0 {
            Do::DoLet(_, y_p2) => prism_rtl::Turn::More(Rc::new(ExReads { x_p0: y_p2.clone(), n_p1: n_p1.clone() })),
            Do::DoLetElse(_, y_p3, z_p4) => {
                let n_p1x = n_p1.clone();
                let y_p3x = y_p3.clone();
                let z_p4x = z_p4.clone();
                crate::prelude::call_then(start_ex_reads_f(y_p3x.clone(), n_p1x.clone()), move |ex_reads_f_21652: bool| prism_rtl::Turn::Finished(ex_reads_f_21652 || ex_reads_f(&z_p4x, &n_p1x)))
            },
            Do::DoAssign(a_p5, b_p6) => {
                let a_p5x = a_p5.clone();
                let b_p6x = b_p6.clone();
                let n_p1x = n_p1.clone();
                crate::prelude::call_then(start_ex_reads_f(a_p5x.clone(), n_p1x.clone()), move |ex_reads_f_21702: bool| prism_rtl::Turn::Finished(ex_reads_f_21702 || ex_reads_f(&b_p6x, &n_p1x)))
            },
            Do::DoWhile(c_p7, ds_p8) => {
                let c_p7x = c_p7.clone();
                let ds_p8x = ds_p8.clone();
                let n_p1x = n_p1.clone();
                crate::prelude::call_then(start_ex_reads_f(c_p7x.clone(), n_p1x.clone()), move |ex_reads_f_21752: bool| prism_rtl::Turn::Finished(ex_reads_f_21752 || dos_read_f(&ds_p8x, &n_p1x)))
            },
            Do::DoWhileLet(_, y_p9, ds_pa) => {
                let ds_pax = ds_pa.clone();
                let n_p1x = n_p1.clone();
                let y_p9x = y_p9.clone();
                crate::prelude::call_then(start_ex_reads_f(y_p9x.clone(), n_p1x.clone()), move |ex_reads_f_21814: bool| prism_rtl::Turn::Finished(ex_reads_f_21814 || dos_read_f(&ds_pax, &n_p1x)))
            },
            Do::DoFor(_, y_pb, ds_pc) => {
                let ds_pcx = ds_pc.clone();
                let n_p1x = n_p1.clone();
                let y_pbx = y_pb.clone();
                crate::prelude::call_then(start_ex_reads_f(y_pbx.clone(), n_p1x.clone()), move |ex_reads_f_21871: bool| prism_rtl::Turn::Finished(ex_reads_f_21871 || dos_read_f(&ds_pcx, &n_p1x)))
            },
            Do::DoExpr(y_pd) => prism_rtl::Turn::More(Rc::new(ExReads { x_p0: y_pd.clone(), n_p1: n_p1.clone() })),
            Do::DoIf(c_pe, a_pf, b_pg) => {
                let a_pfx = a_pf.clone();
                let b_pgx = b_pg.clone();
                let c_pex = c_pe.clone();
                let n_p1x = n_p1.clone();
                crate::prelude::call_then(start_ex_reads_f(c_pex.clone(), n_p1x.clone()), move |ex_reads_f_21948: bool| prism_rtl::Turn::Finished((ex_reads_f_21948 || dos_read_f(&a_pfx, &n_p1x)) || dos_read_f(&b_pgx, &n_p1x)))
            },
            Do::DoIfLet(_, y_ph, a_pi, b_pj) => {
                let a_pix = a_pi.clone();
                let b_pjx = b_pj.clone();
                let n_p1x = n_p1.clone();
                let y_phx = y_ph.clone();
                crate::prelude::call_then(start_ex_reads_f(y_phx.clone(), n_p1x.clone()), move |ex_reads_f_22026: bool| prism_rtl::Turn::Finished((ex_reads_f_22026 || dos_read_f(&a_pix, &n_p1x)) || dos_read_f(&b_pjx, &n_p1x)))
            },
            Do::DoMatch(y_pk, arms_pl) => {
                let arms_plx = arms_pl.clone();
                let n_p1x = n_p1.clone();
                let y_pkx = y_pk.clone();
                crate::prelude::call_then(start_ex_reads_f(y_pkx.clone(), n_p1x.clone()), move |ex_reads_f_22096: bool| prism_rtl::Turn::Finished(ex_reads_f_22096 || crate::prelude::run_to_end(crate::prelude::fold_job(arms_plx.clone(), false, {
                    let n_p1xx = n_p1x.clone();
                    Rc::new(move |(p0, p1): (bool, (Pa, Array<Do>))| {
                        let n_p1xxy = n_p1xx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let f_pm = p0;
                            let (_, ds_pn) = p1;
                            prism_rtl::Turn::Finished(f_pm || dos_read_f(&ds_pn, &n_p1xxy))
                        }))
                    }) as Rc<dyn Fn((bool, (Pa, Array<Do>))) -> Rc<dyn prism_rtl::Job<bool>>>
                }))))
            },
            Do::DoReturn(y_po) => prism_rtl::Turn::More(Rc::new(ExReads { x_p0: y_po.clone(), n_p1: n_p1.clone() })),
            Do::DoBlock(ds_pp) => prism_rtl::Turn::More(Rc::new(DosRead { ds_p0: ds_pp.clone(), n_p1: n_p1.clone() })),
            Do::DoScope(ds_pq) => prism_rtl::Turn::More(Rc::new(DosRead { ds_p0: ds_pq.clone(), n_p1: n_p1.clone() })),
            Do::DoLine(ds_pr) => prism_rtl::Turn::More(Rc::new(DosRead { ds_p0: ds_pr.clone(), n_p1: n_p1.clone() })),
            Do::DoNote(_) => prism_rtl::Turn::Finished(false),
        }
    }
}

/// `Start DoReads, x`: what the function value is when passed to `@Run`.
pub fn start_do_reads_f(d_p0: Do, n_p1: Text) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(DoReads { d_p0, n_p1 })
}
