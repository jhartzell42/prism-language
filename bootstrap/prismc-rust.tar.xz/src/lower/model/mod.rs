//! The module `Lower.Model`, from `target/bootstrap/src/prismc/lower/model.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file. The runtime
//! side is reached from the crate, `crate::prelude` (and through it `::prism_rtl`), the
//! standard library from `::std`, and nothing is imported by name: a program's own type
//! (`Row`, `Option`) hides none of theirs. The traits are in scope unnamed, for their methods.

use crate::prelude::traits::*;

/// `AnswerCase`:
///
/// ```prism
/// type AnswerCase = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct AnswerCase {
    pub variant_p: crate::prelude::Text,
    pub accessor_p: crate::prelude::Text,
    pub struct_path_p: Ref,
    pub tag_name_p: crate::prelude::Text,
    pub ty_p: OutTy,
    pub first_o: ::std::option::Option<OutTy>,
    pub held_whole_o: ::std::option::Option<OutTy>,
    pub held_parts_o: ::std::option::Option<Ex>,
}

impl crate::prelude::Show for AnswerCase {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("AnswerCase", &[("variant", &self.variant_p), ("accessor", &self.accessor_p), ("structPath", &self.struct_path_p), ("tagName", &self.tag_name_p), ("ty", &self.ty_p), ("first", &self.first_o), ("heldWhole", &self.held_whole_o), ("heldParts", &self.held_parts_o)]);
    }
}

impl crate::prelude::ToPod for AnswerCase {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("AnswerCase", vec![("variant", self.variant_p.to_pod()), ("accessor", self.accessor_p.to_pod()), ("structPath", self.struct_path_p.to_pod()), ("tagName", self.tag_name_p.to_pod()), ("ty", self.ty_p.to_pod()), ("first", self.first_o.to_pod()), ("heldWhole", self.held_whole_o.to_pod()), ("heldParts", self.held_parts_o.to_pod())])
    }
}

impl crate::prelude::FromPod for AnswerCase {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(AnswerCase { variant_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "variant")?)?, accessor_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "accessor")?)?, struct_path_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "structPath")?)?, tag_name_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "tagName")?)?, ty_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "ty")?)?, first_o: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "first")?)?, held_whole_o: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "heldWhole")?)?, held_parts_o: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "heldParts")?)? })
    }
}

/// `AnswerDef`:
///
/// ```prism
/// type AnswerDef = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct AnswerDef {
    pub cases_p: crate::prelude::Array<AnswerCase>,
}

impl crate::prelude::Show for AnswerDef {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("AnswerDef", &[("cases", &self.cases_p)]);
    }
}

impl crate::prelude::ToPod for AnswerDef {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("AnswerDef", vec![("cases", self.cases_p.to_pod())])
    }
}

impl crate::prelude::FromPod for AnswerDef {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(AnswerDef { cases_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "cases")?)? })
    }
}

/// `BinOp`:
///
/// ```prism
/// type BinOp = choice:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub enum BinOp {
    OpAdd,
    OpSub,
    OpMul,
    OpDiv,
    OpEq,
    OpNe,
    OpLt,
    OpLe,
    OpGt,
    OpGe,
    OpAnd,
    OpOr,
}

impl crate::prelude::Show for BinOp {
    fn show(&self, p: &mut crate::prelude::Printer) {
        match self {
            BinOp::OpAdd => p.choice("OpAdd", &[]),
            BinOp::OpSub => p.choice("OpSub", &[]),
            BinOp::OpMul => p.choice("OpMul", &[]),
            BinOp::OpDiv => p.choice("OpDiv", &[]),
            BinOp::OpEq => p.choice("OpEq", &[]),
            BinOp::OpNe => p.choice("OpNe", &[]),
            BinOp::OpLt => p.choice("OpLt", &[]),
            BinOp::OpLe => p.choice("OpLe", &[]),
            BinOp::OpGt => p.choice("OpGt", &[]),
            BinOp::OpGe => p.choice("OpGe", &[]),
            BinOp::OpAnd => p.choice("OpAnd", &[]),
            BinOp::OpOr => p.choice("OpOr", &[]),
        }
    }
}

impl crate::prelude::ToPod for BinOp {
    fn to_pod(&self) -> crate::prelude::Pod {
        match self {
            BinOp::OpAdd => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("OpAdd", 0), vec![]),
            BinOp::OpSub => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("OpSub", 1), vec![]),
            BinOp::OpMul => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("OpMul", 2), vec![]),
            BinOp::OpDiv => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("OpDiv", 3), vec![]),
            BinOp::OpEq => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("OpEq", 4), vec![]),
            BinOp::OpNe => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("OpNe", 5), vec![]),
            BinOp::OpLt => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("OpLt", 6), vec![]),
            BinOp::OpLe => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("OpLe", 7), vec![]),
            BinOp::OpGt => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("OpGt", 8), vec![]),
            BinOp::OpGe => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("OpGe", 9), vec![]),
            BinOp::OpAnd => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("OpAnd", 10), vec![]),
            BinOp::OpOr => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("OpOr", 11), vec![]),
        }
    }
}

impl crate::prelude::FromPod for BinOp {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        match p.structure() {
            crate::prelude::Pod::Choice(c, a) if &**c == "OpAdd" && a.len() == 0 => ::std::result::Result::Ok(BinOp::OpAdd),
            crate::prelude::Pod::Choice(c, a) if &**c == "OpSub" && a.len() == 0 => ::std::result::Result::Ok(BinOp::OpSub),
            crate::prelude::Pod::Choice(c, a) if &**c == "OpMul" && a.len() == 0 => ::std::result::Result::Ok(BinOp::OpMul),
            crate::prelude::Pod::Choice(c, a) if &**c == "OpDiv" && a.len() == 0 => ::std::result::Result::Ok(BinOp::OpDiv),
            crate::prelude::Pod::Choice(c, a) if &**c == "OpEq" && a.len() == 0 => ::std::result::Result::Ok(BinOp::OpEq),
            crate::prelude::Pod::Choice(c, a) if &**c == "OpNe" && a.len() == 0 => ::std::result::Result::Ok(BinOp::OpNe),
            crate::prelude::Pod::Choice(c, a) if &**c == "OpLt" && a.len() == 0 => ::std::result::Result::Ok(BinOp::OpLt),
            crate::prelude::Pod::Choice(c, a) if &**c == "OpLe" && a.len() == 0 => ::std::result::Result::Ok(BinOp::OpLe),
            crate::prelude::Pod::Choice(c, a) if &**c == "OpGt" && a.len() == 0 => ::std::result::Result::Ok(BinOp::OpGt),
            crate::prelude::Pod::Choice(c, a) if &**c == "OpGe" && a.len() == 0 => ::std::result::Result::Ok(BinOp::OpGe),
            crate::prelude::Pod::Choice(c, a) if &**c == "OpAnd" && a.len() == 0 => ::std::result::Result::Ok(BinOp::OpAnd),
            crate::prelude::Pod::Choice(c, a) if &**c == "OpOr" && a.len() == 0 => ::std::result::Result::Ok(BinOp::OpOr),
            other => ::prism_rtl::pod::mismatch("a BinOp", other),
        }
    }
}

/// `CaseDef`:
///
/// ```prism
/// type CaseDef = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct CaseDef {
    pub name_p: crate::prelude::Text,
    pub prism_p: crate::prelude::Text,
    pub fields_p: crate::prelude::Array<(crate::prelude::Text, OutTy)>,
    pub labels_p: crate::prelude::Array<crate::prelude::Text>,
}

impl crate::prelude::Show for CaseDef {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("CaseDef", &[("name", &self.name_p), ("prism", &self.prism_p), ("fields", &self.fields_p), ("labels", &self.labels_p)]);
    }
}

impl crate::prelude::ToPod for CaseDef {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("CaseDef", vec![("name", self.name_p.to_pod()), ("prism", self.prism_p.to_pod()), ("fields", self.fields_p.to_pod()), ("labels", self.labels_p.to_pod())])
    }
}

impl crate::prelude::FromPod for CaseDef {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(CaseDef { name_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "name")?)?, prism_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "prism")?)?, fields_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "fields")?)?, labels_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "labels")?)? })
    }
}

/// `Cc`:
///
/// ```prism
/// type Cc = choice:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub enum Cc {
    CcIf(Ex),
    CcLet(Pa, Ex),
}

impl crate::prelude::Show for Cc {
    fn show(&self, p: &mut crate::prelude::Printer) {
        match self {
            Cc::CcIf(a0) => p.choice("CcIf", &[a0]),
            Cc::CcLet(a0, a1) => p.choice("CcLet", &[a0, a1]),
        }
    }
}

impl crate::prelude::ToPod for Cc {
    fn to_pod(&self) -> crate::prelude::Pod {
        match self {
            Cc::CcIf(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("CcIf", 0), vec![a0.to_pod()]),
            Cc::CcLet(a0, a1) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("CcLet", 1), vec![a0.to_pod(), a1.to_pod()]),
        }
    }
}

impl crate::prelude::FromPod for Cc {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        match p.structure() {
            crate::prelude::Pod::Choice(c, a) if &**c == "CcIf" && a.len() == 1 => ::std::result::Result::Ok(Cc::CcIf(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "CcLet" && a.len() == 2 => ::std::result::Result::Ok(Cc::CcLet(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?)),
            other => ::prism_rtl::pod::mismatch("a Cc", other),
        }
    }
}

/// `CheckDef`:
///
/// ```prism
/// type CheckDef = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct CheckDef {
    pub name_p: crate::prelude::Text,
    pub lines_p: crate::prelude::Array<Ex>,
}

impl crate::prelude::Show for CheckDef {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("CheckDef", &[("name", &self.name_p), ("lines", &self.lines_p)]);
    }
}

impl crate::prelude::ToPod for CheckDef {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("CheckDef", vec![("name", self.name_p.to_pod()), ("lines", self.lines_p.to_pod())])
    }
}

impl crate::prelude::FromPod for CheckDef {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(CheckDef { name_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "name")?)?, lines_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "lines")?)? })
    }
}

/// `CxArg`:
///
/// ```prism
/// type CxArg = choice:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub enum CxArg {
    CxMut,
    CxRef,
    CxNone,
}

impl crate::prelude::Show for CxArg {
    fn show(&self, p: &mut crate::prelude::Printer) {
        match self {
            CxArg::CxMut => p.choice("CxMut", &[]),
            CxArg::CxRef => p.choice("CxRef", &[]),
            CxArg::CxNone => p.choice("CxNone", &[]),
        }
    }
}

impl crate::prelude::ToPod for CxArg {
    fn to_pod(&self) -> crate::prelude::Pod {
        match self {
            CxArg::CxMut => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("CxMut", 0), vec![]),
            CxArg::CxRef => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("CxRef", 1), vec![]),
            CxArg::CxNone => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("CxNone", 2), vec![]),
        }
    }
}

impl crate::prelude::FromPod for CxArg {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        match p.structure() {
            crate::prelude::Pod::Choice(c, a) if &**c == "CxMut" && a.len() == 0 => ::std::result::Result::Ok(CxArg::CxMut),
            crate::prelude::Pod::Choice(c, a) if &**c == "CxRef" && a.len() == 0 => ::std::result::Result::Ok(CxArg::CxRef),
            crate::prelude::Pod::Choice(c, a) if &**c == "CxNone" && a.len() == 0 => ::std::result::Result::Ok(CxArg::CxNone),
            other => ::prism_rtl::pod::mismatch("a CxArg", other),
        }
    }
}

/// `Do`:
///
/// ```prism
/// type Do = choice:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub enum Do {
    DoLet(Pa, Ex),
    DoLetElse(Pa, Ex, Ex),
    DoAssign(Ex, Ex),
    DoWhile(Ex, crate::prelude::Array<Do>),
    DoWhileLet(Pa, Ex, crate::prelude::Array<Do>),
    DoFor(Pa, Ex, crate::prelude::Array<Do>),
    DoExpr(Ex),
    DoIf(Ex, crate::prelude::Array<Do>, crate::prelude::Array<Do>),
    DoIfLet(Pa, Ex, crate::prelude::Array<Do>, crate::prelude::Array<Do>),
    DoMatch(Ex, crate::prelude::Array<(Pa, crate::prelude::Array<Do>)>),
    DoReturn(Ex),
    DoBlock(crate::prelude::Array<Do>),
    DoScope(crate::prelude::Array<Do>),
    DoLine(crate::prelude::Array<Do>),
    DoNote(crate::prelude::Text),
}

impl crate::prelude::Show for Do {
    fn show(&self, p: &mut crate::prelude::Printer) {
        match self {
            Do::DoLet(a0, a1) => p.choice("DoLet", &[a0, a1]),
            Do::DoLetElse(a0, a1, a2) => p.choice("DoLetElse", &[a0, a1, a2]),
            Do::DoAssign(a0, a1) => p.choice("DoAssign", &[a0, a1]),
            Do::DoWhile(a0, a1) => p.choice("DoWhile", &[a0, a1]),
            Do::DoWhileLet(a0, a1, a2) => p.choice("DoWhileLet", &[a0, a1, a2]),
            Do::DoFor(a0, a1, a2) => p.choice("DoFor", &[a0, a1, a2]),
            Do::DoExpr(a0) => p.choice("DoExpr", &[a0]),
            Do::DoIf(a0, a1, a2) => p.choice("DoIf", &[a0, a1, a2]),
            Do::DoIfLet(a0, a1, a2, a3) => p.choice("DoIfLet", &[a0, a1, a2, a3]),
            Do::DoMatch(a0, a1) => p.choice("DoMatch", &[a0, a1]),
            Do::DoReturn(a0) => p.choice("DoReturn", &[a0]),
            Do::DoBlock(a0) => p.choice("DoBlock", &[a0]),
            Do::DoScope(a0) => p.choice("DoScope", &[a0]),
            Do::DoLine(a0) => p.choice("DoLine", &[a0]),
            Do::DoNote(a0) => p.choice("DoNote", &[a0]),
        }
    }
}

impl crate::prelude::ToPod for Do {
    fn to_pod(&self) -> crate::prelude::Pod {
        match self {
            Do::DoLet(a0, a1) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("DoLet", 0), vec![a0.to_pod(), a1.to_pod()]),
            Do::DoLetElse(a0, a1, a2) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("DoLetElse", 1), vec![a0.to_pod(), a1.to_pod(), a2.to_pod()]),
            Do::DoAssign(a0, a1) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("DoAssign", 2), vec![a0.to_pod(), a1.to_pod()]),
            Do::DoWhile(a0, a1) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("DoWhile", 3), vec![a0.to_pod(), a1.to_pod()]),
            Do::DoWhileLet(a0, a1, a2) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("DoWhileLet", 4), vec![a0.to_pod(), a1.to_pod(), a2.to_pod()]),
            Do::DoFor(a0, a1, a2) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("DoFor", 5), vec![a0.to_pod(), a1.to_pod(), a2.to_pod()]),
            Do::DoExpr(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("DoExpr", 6), vec![a0.to_pod()]),
            Do::DoIf(a0, a1, a2) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("DoIf", 7), vec![a0.to_pod(), a1.to_pod(), a2.to_pod()]),
            Do::DoIfLet(a0, a1, a2, a3) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("DoIfLet", 8), vec![a0.to_pod(), a1.to_pod(), a2.to_pod(), a3.to_pod()]),
            Do::DoMatch(a0, a1) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("DoMatch", 9), vec![a0.to_pod(), a1.to_pod()]),
            Do::DoReturn(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("DoReturn", 10), vec![a0.to_pod()]),
            Do::DoBlock(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("DoBlock", 11), vec![a0.to_pod()]),
            Do::DoScope(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("DoScope", 12), vec![a0.to_pod()]),
            Do::DoLine(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("DoLine", 13), vec![a0.to_pod()]),
            Do::DoNote(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("DoNote", 14), vec![a0.to_pod()]),
        }
    }
}

impl crate::prelude::FromPod for Do {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        match p.structure() {
            crate::prelude::Pod::Choice(c, a) if &**c == "DoLet" && a.len() == 2 => ::std::result::Result::Ok(Do::DoLet(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "DoLetElse" && a.len() == 3 => ::std::result::Result::Ok(Do::DoLetElse(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?, crate::prelude::FromPod::from_pod(&a[2])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "DoAssign" && a.len() == 2 => ::std::result::Result::Ok(Do::DoAssign(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "DoWhile" && a.len() == 2 => ::std::result::Result::Ok(Do::DoWhile(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "DoWhileLet" && a.len() == 3 => ::std::result::Result::Ok(Do::DoWhileLet(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?, crate::prelude::FromPod::from_pod(&a[2])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "DoFor" && a.len() == 3 => ::std::result::Result::Ok(Do::DoFor(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?, crate::prelude::FromPod::from_pod(&a[2])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "DoExpr" && a.len() == 1 => ::std::result::Result::Ok(Do::DoExpr(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "DoIf" && a.len() == 3 => ::std::result::Result::Ok(Do::DoIf(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?, crate::prelude::FromPod::from_pod(&a[2])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "DoIfLet" && a.len() == 4 => ::std::result::Result::Ok(Do::DoIfLet(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?, crate::prelude::FromPod::from_pod(&a[2])?, crate::prelude::FromPod::from_pod(&a[3])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "DoMatch" && a.len() == 2 => ::std::result::Result::Ok(Do::DoMatch(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "DoReturn" && a.len() == 1 => ::std::result::Result::Ok(Do::DoReturn(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "DoBlock" && a.len() == 1 => ::std::result::Result::Ok(Do::DoBlock(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "DoScope" && a.len() == 1 => ::std::result::Result::Ok(Do::DoScope(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "DoLine" && a.len() == 1 => ::std::result::Result::Ok(Do::DoLine(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "DoNote" && a.len() == 1 => ::std::result::Result::Ok(Do::DoNote(crate::prelude::FromPod::from_pod(&a[0])?)),
            other => ::prism_rtl::pod::mismatch("a Do", other),
        }
    }
}

/// `Ex`:
///
/// ```prism
/// type Ex = choice:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub enum Ex {
    XVar(crate::prelude::Text),
    XPath(Ref),
    XSelf,
    XCx,
    XConst(crate::prelude::Text),
    XUnit,
    XNone,
    XBool(bool),
    XNat(crate::prelude::Text),
    XInt(crate::prelude::Text),
    XByte(crate::prelude::Text),
    XFloat(crate::prelude::Text),
    XDuration(crate::prelude::Text),
    XIndex(crate::prelude::Nat),
    XChar(crate::prelude::Text),
    XStr(crate::prelude::Text),
    XRegex(crate::prelude::Text, crate::prelude::Text),
    XReplacement(crate::prelude::Text, crate::prelude::Text, crate::prelude::Text),
    XRef(::std::rc::Rc<Ex>),
    XRefMut(::std::rc::Rc<Ex>),
    XDeref(::std::rc::Rc<Ex>),
    XTarget(::std::rc::Rc<Ex>),
    XClone(::std::rc::Rc<Ex>),
    XWeak(::std::rc::Rc<Ex>),
    XUpgrade(::std::rc::Rc<Ex>),
    XBreak(crate::prelude::Text, ::std::rc::Rc<Ex>),
    XBreakLoop,
    XLater(::std::rc::Rc<Ex>),
    XFormatStr(crate::prelude::Array<Ex>),
    XIsCase(::std::rc::Rc<Ex>, crate::prelude::Array<Ref>),
    XRefusal(crate::prelude::Text),
    XUnreachable,
    XCall(Ref, crate::prelude::Array<Ex>),
    XCallAt(Ref, crate::prelude::Array<OutTy>, crate::prelude::Array<Ex>),
    XCallSelf(Ref, crate::prelude::Text, OutTy, crate::prelude::Array<Ex>),
    XApply(::std::rc::Rc<Ex>, crate::prelude::Array<Ex>),
    XMethod(::std::rc::Rc<Ex>, crate::prelude::Text, crate::prelude::Array<Ex>),
    XBin(BinOp, ::std::rc::Rc<Ex>, ::std::rc::Rc<Ex>),
    XUnary(UnOp, ::std::rc::Rc<Ex>),
    XCtor(Ref, crate::prelude::Array<Ex>),
    XRecord(Ref, crate::prelude::Array<(crate::prelude::Text, Ex)>),
    XTuple(crate::prelude::Array<Ex>),
    XVec(crate::prelude::Array<Ex>),
    XText(crate::prelude::Text),
    XFormat(crate::prelude::Array<Ex>),
    XMatch(::std::rc::Rc<Ex>, crate::prelude::Array<XArm>, bool, OutTy),
    XChain(crate::prelude::Text, ::std::rc::Rc<Ex>, crate::prelude::Array<XArm>, OutTy),
    XIf(::std::rc::Rc<Ex>, ::std::rc::Rc<Ex>, ::std::rc::Rc<Ex>),
    XBlock(crate::prelude::Array<Do>, ::std::rc::Rc<Ex>),
    XLabeled(crate::prelude::Text, crate::prelude::Array<Do>, ::std::rc::Rc<Ex>, OutTy),
    XClosure(bool, crate::prelude::Array<Pa>, ::std::rc::Rc<Ex>),
    XTry(::std::rc::Rc<Ex>),
    XField(::std::rc::Rc<Ex>, crate::prelude::Text),
    XFieldOf(::std::rc::Rc<Ex>, Ref, crate::prelude::Text),
    XPart(::std::rc::Rc<Ex>, crate::prelude::Nat),
    XDecode(OutTy, ::std::rc::Rc<Ex>),
    XCast(::std::rc::Rc<Ex>, OutTy),
    XTyped(::std::rc::Rc<Ex>, OutTy),
}

impl crate::prelude::Show for Ex {
    fn show(&self, p: &mut crate::prelude::Printer) {
        match self {
            Ex::XVar(a0) => p.choice("XVar", &[a0]),
            Ex::XPath(a0) => p.choice("XPath", &[a0]),
            Ex::XSelf => p.choice("XSelf", &[]),
            Ex::XCx => p.choice("XCx", &[]),
            Ex::XConst(a0) => p.choice("XConst", &[a0]),
            Ex::XUnit => p.choice("XUnit", &[]),
            Ex::XNone => p.choice("XNone", &[]),
            Ex::XBool(a0) => p.choice("XBool", &[a0]),
            Ex::XNat(a0) => p.choice("XNat", &[a0]),
            Ex::XInt(a0) => p.choice("XInt", &[a0]),
            Ex::XByte(a0) => p.choice("XByte", &[a0]),
            Ex::XFloat(a0) => p.choice("XFloat", &[a0]),
            Ex::XDuration(a0) => p.choice("XDuration", &[a0]),
            Ex::XIndex(a0) => p.choice("XIndex", &[a0]),
            Ex::XChar(a0) => p.choice("XChar", &[a0]),
            Ex::XStr(a0) => p.choice("XStr", &[a0]),
            Ex::XRegex(a0, a1) => p.choice("XRegex", &[a0, a1]),
            Ex::XReplacement(a0, a1, a2) => p.choice("XReplacement", &[a0, a1, a2]),
            Ex::XRef(a0) => p.choice("XRef", &[a0]),
            Ex::XRefMut(a0) => p.choice("XRefMut", &[a0]),
            Ex::XDeref(a0) => p.choice("XDeref", &[a0]),
            Ex::XTarget(a0) => p.choice("XTarget", &[a0]),
            Ex::XClone(a0) => p.choice("XClone", &[a0]),
            Ex::XWeak(a0) => p.choice("XWeak", &[a0]),
            Ex::XUpgrade(a0) => p.choice("XUpgrade", &[a0]),
            Ex::XBreak(a0, a1) => p.choice("XBreak", &[a0, a1]),
            Ex::XBreakLoop => p.choice("XBreakLoop", &[]),
            Ex::XLater(a0) => p.choice("XLater", &[a0]),
            Ex::XFormatStr(a0) => p.choice("XFormatStr", &[a0]),
            Ex::XIsCase(a0, a1) => p.choice("XIsCase", &[a0, a1]),
            Ex::XRefusal(a0) => p.choice("XRefusal", &[a0]),
            Ex::XUnreachable => p.choice("XUnreachable", &[]),
            Ex::XCall(a0, a1) => p.choice("XCall", &[a0, a1]),
            Ex::XCallAt(a0, a1, a2) => p.choice("XCallAt", &[a0, a1, a2]),
            Ex::XCallSelf(a0, a1, a2, a3) => p.choice("XCallSelf", &[a0, a1, a2, a3]),
            Ex::XApply(a0, a1) => p.choice("XApply", &[a0, a1]),
            Ex::XMethod(a0, a1, a2) => p.choice("XMethod", &[a0, a1, a2]),
            Ex::XBin(a0, a1, a2) => p.choice("XBin", &[a0, a1, a2]),
            Ex::XUnary(a0, a1) => p.choice("XUnary", &[a0, a1]),
            Ex::XCtor(a0, a1) => p.choice("XCtor", &[a0, a1]),
            Ex::XRecord(a0, a1) => p.choice("XRecord", &[a0, a1]),
            Ex::XTuple(a0) => p.choice("XTuple", &[a0]),
            Ex::XVec(a0) => p.choice("XVec", &[a0]),
            Ex::XText(a0) => p.choice("XText", &[a0]),
            Ex::XFormat(a0) => p.choice("XFormat", &[a0]),
            Ex::XMatch(a0, a1, a2, a3) => p.choice("XMatch", &[a0, a1, a2, a3]),
            Ex::XChain(a0, a1, a2, a3) => p.choice("XChain", &[a0, a1, a2, a3]),
            Ex::XIf(a0, a1, a2) => p.choice("XIf", &[a0, a1, a2]),
            Ex::XBlock(a0, a1) => p.choice("XBlock", &[a0, a1]),
            Ex::XLabeled(a0, a1, a2, a3) => p.choice("XLabeled", &[a0, a1, a2, a3]),
            Ex::XClosure(a0, a1, a2) => p.choice("XClosure", &[a0, a1, a2]),
            Ex::XTry(a0) => p.choice("XTry", &[a0]),
            Ex::XField(a0, a1) => p.choice("XField", &[a0, a1]),
            Ex::XFieldOf(a0, a1, a2) => p.choice("XFieldOf", &[a0, a1, a2]),
            Ex::XPart(a0, a1) => p.choice("XPart", &[a0, a1]),
            Ex::XDecode(a0, a1) => p.choice("XDecode", &[a0, a1]),
            Ex::XCast(a0, a1) => p.choice("XCast", &[a0, a1]),
            Ex::XTyped(a0, a1) => p.choice("XTyped", &[a0, a1]),
        }
    }
}

impl crate::prelude::ToPod for Ex {
    fn to_pod(&self) -> crate::prelude::Pod {
        match self {
            Ex::XVar(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("XVar", 0), vec![a0.to_pod()]),
            Ex::XPath(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("XPath", 1), vec![a0.to_pod()]),
            Ex::XSelf => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("XSelf", 2), vec![]),
            Ex::XCx => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("XCx", 3), vec![]),
            Ex::XConst(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("XConst", 4), vec![a0.to_pod()]),
            Ex::XUnit => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("XUnit", 5), vec![]),
            Ex::XNone => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("XNone", 6), vec![]),
            Ex::XBool(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("XBool", 7), vec![a0.to_pod()]),
            Ex::XNat(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("XNat", 8), vec![a0.to_pod()]),
            Ex::XInt(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("XInt", 9), vec![a0.to_pod()]),
            Ex::XByte(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("XByte", 10), vec![a0.to_pod()]),
            Ex::XFloat(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("XFloat", 11), vec![a0.to_pod()]),
            Ex::XDuration(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("XDuration", 12), vec![a0.to_pod()]),
            Ex::XIndex(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("XIndex", 13), vec![a0.to_pod()]),
            Ex::XChar(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("XChar", 14), vec![a0.to_pod()]),
            Ex::XStr(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("XStr", 15), vec![a0.to_pod()]),
            Ex::XRegex(a0, a1) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("XRegex", 16), vec![a0.to_pod(), a1.to_pod()]),
            Ex::XReplacement(a0, a1, a2) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("XReplacement", 17), vec![a0.to_pod(), a1.to_pod(), a2.to_pod()]),
            Ex::XRef(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("XRef", 18), vec![a0.to_pod()]),
            Ex::XRefMut(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("XRefMut", 19), vec![a0.to_pod()]),
            Ex::XDeref(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("XDeref", 20), vec![a0.to_pod()]),
            Ex::XTarget(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("XTarget", 21), vec![a0.to_pod()]),
            Ex::XClone(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("XClone", 22), vec![a0.to_pod()]),
            Ex::XWeak(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("XWeak", 23), vec![a0.to_pod()]),
            Ex::XUpgrade(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("XUpgrade", 24), vec![a0.to_pod()]),
            Ex::XBreak(a0, a1) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("XBreak", 25), vec![a0.to_pod(), a1.to_pod()]),
            Ex::XBreakLoop => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("XBreakLoop", 26), vec![]),
            Ex::XLater(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("XLater", 27), vec![a0.to_pod()]),
            Ex::XFormatStr(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("XFormatStr", 28), vec![a0.to_pod()]),
            Ex::XIsCase(a0, a1) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("XIsCase", 29), vec![a0.to_pod(), a1.to_pod()]),
            Ex::XRefusal(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("XRefusal", 30), vec![a0.to_pod()]),
            Ex::XUnreachable => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("XUnreachable", 31), vec![]),
            Ex::XCall(a0, a1) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("XCall", 32), vec![a0.to_pod(), a1.to_pod()]),
            Ex::XCallAt(a0, a1, a2) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("XCallAt", 33), vec![a0.to_pod(), a1.to_pod(), a2.to_pod()]),
            Ex::XCallSelf(a0, a1, a2, a3) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("XCallSelf", 34), vec![a0.to_pod(), a1.to_pod(), a2.to_pod(), a3.to_pod()]),
            Ex::XApply(a0, a1) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("XApply", 35), vec![a0.to_pod(), a1.to_pod()]),
            Ex::XMethod(a0, a1, a2) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("XMethod", 36), vec![a0.to_pod(), a1.to_pod(), a2.to_pod()]),
            Ex::XBin(a0, a1, a2) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("XBin", 37), vec![a0.to_pod(), a1.to_pod(), a2.to_pod()]),
            Ex::XUnary(a0, a1) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("XUnary", 38), vec![a0.to_pod(), a1.to_pod()]),
            Ex::XCtor(a0, a1) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("XCtor", 39), vec![a0.to_pod(), a1.to_pod()]),
            Ex::XRecord(a0, a1) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("XRecord", 40), vec![a0.to_pod(), a1.to_pod()]),
            Ex::XTuple(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("XTuple", 41), vec![a0.to_pod()]),
            Ex::XVec(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("XVec", 42), vec![a0.to_pod()]),
            Ex::XText(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("XText", 43), vec![a0.to_pod()]),
            Ex::XFormat(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("XFormat", 44), vec![a0.to_pod()]),
            Ex::XMatch(a0, a1, a2, a3) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("XMatch", 45), vec![a0.to_pod(), a1.to_pod(), a2.to_pod(), a3.to_pod()]),
            Ex::XChain(a0, a1, a2, a3) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("XChain", 46), vec![a0.to_pod(), a1.to_pod(), a2.to_pod(), a3.to_pod()]),
            Ex::XIf(a0, a1, a2) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("XIf", 47), vec![a0.to_pod(), a1.to_pod(), a2.to_pod()]),
            Ex::XBlock(a0, a1) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("XBlock", 48), vec![a0.to_pod(), a1.to_pod()]),
            Ex::XLabeled(a0, a1, a2, a3) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("XLabeled", 49), vec![a0.to_pod(), a1.to_pod(), a2.to_pod(), a3.to_pod()]),
            Ex::XClosure(a0, a1, a2) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("XClosure", 50), vec![a0.to_pod(), a1.to_pod(), a2.to_pod()]),
            Ex::XTry(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("XTry", 51), vec![a0.to_pod()]),
            Ex::XField(a0, a1) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("XField", 52), vec![a0.to_pod(), a1.to_pod()]),
            Ex::XFieldOf(a0, a1, a2) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("XFieldOf", 53), vec![a0.to_pod(), a1.to_pod(), a2.to_pod()]),
            Ex::XPart(a0, a1) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("XPart", 54), vec![a0.to_pod(), a1.to_pod()]),
            Ex::XDecode(a0, a1) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("XDecode", 55), vec![a0.to_pod(), a1.to_pod()]),
            Ex::XCast(a0, a1) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("XCast", 56), vec![a0.to_pod(), a1.to_pod()]),
            Ex::XTyped(a0, a1) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("XTyped", 57), vec![a0.to_pod(), a1.to_pod()]),
        }
    }
}

impl crate::prelude::FromPod for Ex {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        match p.structure() {
            crate::prelude::Pod::Choice(c, a) if &**c == "XVar" && a.len() == 1 => ::std::result::Result::Ok(Ex::XVar(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "XPath" && a.len() == 1 => ::std::result::Result::Ok(Ex::XPath(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "XSelf" && a.len() == 0 => ::std::result::Result::Ok(Ex::XSelf),
            crate::prelude::Pod::Choice(c, a) if &**c == "XCx" && a.len() == 0 => ::std::result::Result::Ok(Ex::XCx),
            crate::prelude::Pod::Choice(c, a) if &**c == "XConst" && a.len() == 1 => ::std::result::Result::Ok(Ex::XConst(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "XUnit" && a.len() == 0 => ::std::result::Result::Ok(Ex::XUnit),
            crate::prelude::Pod::Choice(c, a) if &**c == "XNone" && a.len() == 0 => ::std::result::Result::Ok(Ex::XNone),
            crate::prelude::Pod::Choice(c, a) if &**c == "XBool" && a.len() == 1 => ::std::result::Result::Ok(Ex::XBool(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "XNat" && a.len() == 1 => ::std::result::Result::Ok(Ex::XNat(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "XInt" && a.len() == 1 => ::std::result::Result::Ok(Ex::XInt(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "XByte" && a.len() == 1 => ::std::result::Result::Ok(Ex::XByte(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "XFloat" && a.len() == 1 => ::std::result::Result::Ok(Ex::XFloat(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "XDuration" && a.len() == 1 => ::std::result::Result::Ok(Ex::XDuration(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "XIndex" && a.len() == 1 => ::std::result::Result::Ok(Ex::XIndex(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "XChar" && a.len() == 1 => ::std::result::Result::Ok(Ex::XChar(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "XStr" && a.len() == 1 => ::std::result::Result::Ok(Ex::XStr(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "XRegex" && a.len() == 2 => ::std::result::Result::Ok(Ex::XRegex(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "XReplacement" && a.len() == 3 => ::std::result::Result::Ok(Ex::XReplacement(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?, crate::prelude::FromPod::from_pod(&a[2])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "XRef" && a.len() == 1 => ::std::result::Result::Ok(Ex::XRef(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "XRefMut" && a.len() == 1 => ::std::result::Result::Ok(Ex::XRefMut(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "XDeref" && a.len() == 1 => ::std::result::Result::Ok(Ex::XDeref(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "XTarget" && a.len() == 1 => ::std::result::Result::Ok(Ex::XTarget(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "XClone" && a.len() == 1 => ::std::result::Result::Ok(Ex::XClone(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "XWeak" && a.len() == 1 => ::std::result::Result::Ok(Ex::XWeak(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "XUpgrade" && a.len() == 1 => ::std::result::Result::Ok(Ex::XUpgrade(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "XBreak" && a.len() == 2 => ::std::result::Result::Ok(Ex::XBreak(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "XBreakLoop" && a.len() == 0 => ::std::result::Result::Ok(Ex::XBreakLoop),
            crate::prelude::Pod::Choice(c, a) if &**c == "XLater" && a.len() == 1 => ::std::result::Result::Ok(Ex::XLater(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "XFormatStr" && a.len() == 1 => ::std::result::Result::Ok(Ex::XFormatStr(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "XIsCase" && a.len() == 2 => ::std::result::Result::Ok(Ex::XIsCase(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "XRefusal" && a.len() == 1 => ::std::result::Result::Ok(Ex::XRefusal(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "XUnreachable" && a.len() == 0 => ::std::result::Result::Ok(Ex::XUnreachable),
            crate::prelude::Pod::Choice(c, a) if &**c == "XCall" && a.len() == 2 => ::std::result::Result::Ok(Ex::XCall(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "XCallAt" && a.len() == 3 => ::std::result::Result::Ok(Ex::XCallAt(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?, crate::prelude::FromPod::from_pod(&a[2])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "XCallSelf" && a.len() == 4 => ::std::result::Result::Ok(Ex::XCallSelf(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?, crate::prelude::FromPod::from_pod(&a[2])?, crate::prelude::FromPod::from_pod(&a[3])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "XApply" && a.len() == 2 => ::std::result::Result::Ok(Ex::XApply(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "XMethod" && a.len() == 3 => ::std::result::Result::Ok(Ex::XMethod(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?, crate::prelude::FromPod::from_pod(&a[2])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "XBin" && a.len() == 3 => ::std::result::Result::Ok(Ex::XBin(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?, crate::prelude::FromPod::from_pod(&a[2])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "XUnary" && a.len() == 2 => ::std::result::Result::Ok(Ex::XUnary(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "XCtor" && a.len() == 2 => ::std::result::Result::Ok(Ex::XCtor(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "XRecord" && a.len() == 2 => ::std::result::Result::Ok(Ex::XRecord(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "XTuple" && a.len() == 1 => ::std::result::Result::Ok(Ex::XTuple(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "XVec" && a.len() == 1 => ::std::result::Result::Ok(Ex::XVec(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "XText" && a.len() == 1 => ::std::result::Result::Ok(Ex::XText(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "XFormat" && a.len() == 1 => ::std::result::Result::Ok(Ex::XFormat(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "XMatch" && a.len() == 4 => ::std::result::Result::Ok(Ex::XMatch(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?, crate::prelude::FromPod::from_pod(&a[2])?, crate::prelude::FromPod::from_pod(&a[3])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "XChain" && a.len() == 4 => ::std::result::Result::Ok(Ex::XChain(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?, crate::prelude::FromPod::from_pod(&a[2])?, crate::prelude::FromPod::from_pod(&a[3])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "XIf" && a.len() == 3 => ::std::result::Result::Ok(Ex::XIf(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?, crate::prelude::FromPod::from_pod(&a[2])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "XBlock" && a.len() == 2 => ::std::result::Result::Ok(Ex::XBlock(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "XLabeled" && a.len() == 4 => ::std::result::Result::Ok(Ex::XLabeled(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?, crate::prelude::FromPod::from_pod(&a[2])?, crate::prelude::FromPod::from_pod(&a[3])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "XClosure" && a.len() == 3 => ::std::result::Result::Ok(Ex::XClosure(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?, crate::prelude::FromPod::from_pod(&a[2])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "XTry" && a.len() == 1 => ::std::result::Result::Ok(Ex::XTry(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "XField" && a.len() == 2 => ::std::result::Result::Ok(Ex::XField(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "XFieldOf" && a.len() == 3 => ::std::result::Result::Ok(Ex::XFieldOf(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?, crate::prelude::FromPod::from_pod(&a[2])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "XPart" && a.len() == 2 => ::std::result::Result::Ok(Ex::XPart(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "XDecode" && a.len() == 2 => ::std::result::Result::Ok(Ex::XDecode(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "XCast" && a.len() == 2 => ::std::result::Result::Ok(Ex::XCast(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "XTyped" && a.len() == 2 => ::std::result::Result::Ok(Ex::XTyped(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?)),
            other => ::prism_rtl::pod::mismatch("a Ex", other),
        }
    }
}

/// `FnDef`:
///
/// ```prism
/// type FnDef = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct FnDef {
    pub name_p: crate::prelude::Text,
    pub generics_p: crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>)>,
    pub params_p: crate::prelude::Array<(crate::prelude::Text, OutTy)>,
    pub ret_p: OutTy,
    pub body_p: Ex,
    pub doc_p: crate::prelude::Text,
    pub public_p: bool,
}

impl crate::prelude::Show for FnDef {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("FnDef", &[("name", &self.name_p), ("generics", &self.generics_p), ("params", &self.params_p), ("ret", &self.ret_p), ("body", &self.body_p), ("doc", &self.doc_p), ("public", &self.public_p)]);
    }
}

impl crate::prelude::ToPod for FnDef {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("FnDef", vec![("name", self.name_p.to_pod()), ("generics", self.generics_p.to_pod()), ("params", self.params_p.to_pod()), ("ret", self.ret_p.to_pod()), ("body", self.body_p.to_pod()), ("doc", self.doc_p.to_pod()), ("public", self.public_p.to_pod())])
    }
}

impl crate::prelude::FromPod for FnDef {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(FnDef { name_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "name")?)?, generics_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "generics")?)?, params_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "params")?)?, ret_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "ret")?)?, body_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "body")?)?, doc_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "doc")?)?, public_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "public")?)? })
    }
}

/// `ForDef`:
///
/// ```prism
/// type ForDef = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct ForDef {
    pub name_p: crate::prelude::Text,
    pub pos_p: Pos,
    pub at_p: Ex,
    pub key_ty_p: OutTy,
    pub value_ty_p: OutTy,
    pub row_node_p: crate::prelude::Text,
    pub keyed_p: bool,
    pub source_p: crate::prelude::Text,
    pub parent_p: Ex,
    pub passed_p: crate::prelude::Array<Ex>,
    pub moved_p: crate::prelude::Text,
    pub replaced_p: crate::prelude::Array<crate::prelude::Text>,
}

impl crate::prelude::Show for ForDef {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("ForDef", &[("name", &self.name_p), ("pos", &self.pos_p), ("at", &self.at_p), ("keyTy", &self.key_ty_p), ("valueTy", &self.value_ty_p), ("rowNode", &self.row_node_p), ("keyed", &self.keyed_p), ("source", &self.source_p), ("parent", &self.parent_p), ("passed", &self.passed_p), ("moved", &self.moved_p), ("replaced", &self.replaced_p)]);
    }
}

impl crate::prelude::ToPod for ForDef {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("ForDef", vec![("name", self.name_p.to_pod()), ("pos", self.pos_p.to_pod()), ("at", self.at_p.to_pod()), ("keyTy", self.key_ty_p.to_pod()), ("valueTy", self.value_ty_p.to_pod()), ("rowNode", self.row_node_p.to_pod()), ("keyed", self.keyed_p.to_pod()), ("source", self.source_p.to_pod()), ("parent", self.parent_p.to_pod()), ("passed", self.passed_p.to_pod()), ("moved", self.moved_p.to_pod()), ("replaced", self.replaced_p.to_pod())])
    }
}

impl crate::prelude::FromPod for ForDef {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(ForDef { name_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "name")?)?, pos_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "pos")?)?, at_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "at")?)?, key_ty_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "keyTy")?)?, value_ty_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "valueTy")?)?, row_node_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "rowNode")?)?, keyed_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "keyed")?)?, source_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "source")?)?, parent_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "parent")?)?, passed_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "passed")?)?, moved_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "moved")?)?, replaced_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "replaced")?)? })
    }
}

/// `GenDef`:
///
/// ```prism
/// type GenDef = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct GenDef {
    pub name_p: crate::prelude::Text,
    pub pos_p: Pos,
    pub at_p: Ex,
    pub source_p: Ex,
    pub value_ty_p: OutTy,
    pub select_p: Ex,
    pub transparent_p: bool,
    pub width_p: crate::prelude::Nat,
    pub moved_p: crate::prelude::Text,
    pub early_p: bool,
    pub gappy_p: bool,
    pub rebased_p: bool,
}

impl crate::prelude::Show for GenDef {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("GenDef", &[("name", &self.name_p), ("pos", &self.pos_p), ("at", &self.at_p), ("source", &self.source_p), ("valueTy", &self.value_ty_p), ("select", &self.select_p), ("transparent", &self.transparent_p), ("width", &self.width_p), ("moved", &self.moved_p), ("early", &self.early_p), ("gappy", &self.gappy_p), ("rebased", &self.rebased_p)]);
    }
}

impl crate::prelude::ToPod for GenDef {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("GenDef", vec![("name", self.name_p.to_pod()), ("pos", self.pos_p.to_pod()), ("at", self.at_p.to_pod()), ("source", self.source_p.to_pod()), ("valueTy", self.value_ty_p.to_pod()), ("select", self.select_p.to_pod()), ("transparent", self.transparent_p.to_pod()), ("width", self.width_p.to_pod()), ("moved", self.moved_p.to_pod()), ("early", self.early_p.to_pod()), ("gappy", self.gappy_p.to_pod()), ("rebased", self.rebased_p.to_pod())])
    }
}

impl crate::prelude::FromPod for GenDef {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(GenDef { name_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "name")?)?, pos_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "pos")?)?, at_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "at")?)?, source_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "source")?)?, value_ty_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "valueTy")?)?, select_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "select")?)?, transparent_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "transparent")?)?, width_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "width")?)?, moved_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "moved")?)?, early_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "early")?)?, gappy_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "gappy")?)?, rebased_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "rebased")?)? })
    }
}

/// `ImplDef`:
///
/// ```prism
/// type ImplDef = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct ImplDef {
    pub cls_p: crate::prelude::Text,
    pub tr_p: crate::prelude::Text,
    pub head_p: OutTy,
    pub generics_p: crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>)>,
    pub assocs_p: crate::prelude::Array<(crate::prelude::Text, OutTy)>,
    pub result_only_p: crate::prelude::Array<crate::prelude::Text>,
    pub methods_p: crate::prelude::Array<FnDef>,
    pub doc_p: crate::prelude::Text,
}

impl crate::prelude::Show for ImplDef {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("ImplDef", &[("cls", &self.cls_p), ("tr", &self.tr_p), ("head", &self.head_p), ("generics", &self.generics_p), ("assocs", &self.assocs_p), ("resultOnly", &self.result_only_p), ("methods", &self.methods_p), ("doc", &self.doc_p)]);
    }
}

impl crate::prelude::ToPod for ImplDef {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("ImplDef", vec![("cls", self.cls_p.to_pod()), ("tr", self.tr_p.to_pod()), ("head", self.head_p.to_pod()), ("generics", self.generics_p.to_pod()), ("assocs", self.assocs_p.to_pod()), ("resultOnly", self.result_only_p.to_pod()), ("methods", self.methods_p.to_pod()), ("doc", self.doc_p.to_pod())])
    }
}

impl crate::prelude::FromPod for ImplDef {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(ImplDef { cls_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "cls")?)?, tr_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "tr")?)?, head_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "head")?)?, generics_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "generics")?)?, assocs_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "assocs")?)?, result_only_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "resultOnly")?)?, methods_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "methods")?)?, doc_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "doc")?)? })
    }
}

/// `Item`:
///
/// ```prism
/// type Item = choice:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub enum Item {
    ItTrait(TraitDef),
    ItImpl(ImplDef),
    ItPacked(PackedDef),
    ItType(TyDef),
    ItTag(TagDef),
    ItRow(RowDef),
    ItFn(FnDef),
    ItJob(JobDef),
    ItNode(NodeDef),
    ItNote(crate::prelude::Text),
    ItRefused(crate::prelude::Text),
}

impl crate::prelude::Show for Item {
    fn show(&self, p: &mut crate::prelude::Printer) {
        match self {
            Item::ItTrait(a0) => p.choice("ItTrait", &[a0]),
            Item::ItImpl(a0) => p.choice("ItImpl", &[a0]),
            Item::ItPacked(a0) => p.choice("ItPacked", &[a0]),
            Item::ItType(a0) => p.choice("ItType", &[a0]),
            Item::ItTag(a0) => p.choice("ItTag", &[a0]),
            Item::ItRow(a0) => p.choice("ItRow", &[a0]),
            Item::ItFn(a0) => p.choice("ItFn", &[a0]),
            Item::ItJob(a0) => p.choice("ItJob", &[a0]),
            Item::ItNode(a0) => p.choice("ItNode", &[a0]),
            Item::ItNote(a0) => p.choice("ItNote", &[a0]),
            Item::ItRefused(a0) => p.choice("ItRefused", &[a0]),
        }
    }
}

impl crate::prelude::ToPod for Item {
    fn to_pod(&self) -> crate::prelude::Pod {
        match self {
            Item::ItTrait(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("ItTrait", 0), vec![a0.to_pod()]),
            Item::ItImpl(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("ItImpl", 1), vec![a0.to_pod()]),
            Item::ItPacked(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("ItPacked", 2), vec![a0.to_pod()]),
            Item::ItType(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("ItType", 3), vec![a0.to_pod()]),
            Item::ItTag(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("ItTag", 4), vec![a0.to_pod()]),
            Item::ItRow(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("ItRow", 5), vec![a0.to_pod()]),
            Item::ItFn(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("ItFn", 6), vec![a0.to_pod()]),
            Item::ItJob(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("ItJob", 7), vec![a0.to_pod()]),
            Item::ItNode(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("ItNode", 8), vec![a0.to_pod()]),
            Item::ItNote(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("ItNote", 9), vec![a0.to_pod()]),
            Item::ItRefused(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("ItRefused", 10), vec![a0.to_pod()]),
        }
    }
}

impl crate::prelude::FromPod for Item {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        match p.structure() {
            crate::prelude::Pod::Choice(c, a) if &**c == "ItTrait" && a.len() == 1 => ::std::result::Result::Ok(Item::ItTrait(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "ItImpl" && a.len() == 1 => ::std::result::Result::Ok(Item::ItImpl(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "ItPacked" && a.len() == 1 => ::std::result::Result::Ok(Item::ItPacked(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "ItType" && a.len() == 1 => ::std::result::Result::Ok(Item::ItType(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "ItTag" && a.len() == 1 => ::std::result::Result::Ok(Item::ItTag(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "ItRow" && a.len() == 1 => ::std::result::Result::Ok(Item::ItRow(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "ItFn" && a.len() == 1 => ::std::result::Result::Ok(Item::ItFn(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "ItJob" && a.len() == 1 => ::std::result::Result::Ok(Item::ItJob(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "ItNode" && a.len() == 1 => ::std::result::Result::Ok(Item::ItNode(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "ItNote" && a.len() == 1 => ::std::result::Result::Ok(Item::ItNote(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "ItRefused" && a.len() == 1 => ::std::result::Result::Ok(Item::ItRefused(crate::prelude::FromPod::from_pod(&a[0])?)),
            other => ::prism_rtl::pod::mismatch("a Item", other),
        }
    }
}

/// `JobDef`:
///
/// ```prism
/// type JobDef = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct JobDef {
    pub name_p: crate::prelude::Text,
    pub start_p: crate::prelude::Text,
    pub generics_p: crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>)>,
    pub fields_p: crate::prelude::Array<(crate::prelude::Text, OutTy)>,
    pub ret_p: OutTy,
    pub body_p: Ex,
    pub doc_p: crate::prelude::Text,
}

impl crate::prelude::Show for JobDef {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("JobDef", &[("name", &self.name_p), ("start", &self.start_p), ("generics", &self.generics_p), ("fields", &self.fields_p), ("ret", &self.ret_p), ("body", &self.body_p), ("doc", &self.doc_p)]);
    }
}

impl crate::prelude::ToPod for JobDef {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("JobDef", vec![("name", self.name_p.to_pod()), ("start", self.start_p.to_pod()), ("generics", self.generics_p.to_pod()), ("fields", self.fields_p.to_pod()), ("ret", self.ret_p.to_pod()), ("body", self.body_p.to_pod()), ("doc", self.doc_p.to_pod())])
    }
}

impl crate::prelude::FromPod for JobDef {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(JobDef { name_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "name")?)?, start_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "start")?)?, generics_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "generics")?)?, fields_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "fields")?)?, ret_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "ret")?)?, body_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "body")?)?, doc_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "doc")?)? })
    }
}

/// `MethDef`:
///
/// ```prism
/// type MethDef = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct MethDef {
    pub name_p: crate::prelude::Text,
    pub recv_p: Recv,
    pub params_p: crate::prelude::Array<(crate::prelude::Text, OutTy)>,
    pub cx_p: CxArg,
    pub ret_p: OutTy,
    pub body_p: crate::prelude::Array<Do>,
    pub tail_p: Ex,
    pub doc_p: crate::prelude::Text,
}

impl crate::prelude::Show for MethDef {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("MethDef", &[("name", &self.name_p), ("recv", &self.recv_p), ("params", &self.params_p), ("cx", &self.cx_p), ("ret", &self.ret_p), ("body", &self.body_p), ("tail", &self.tail_p), ("doc", &self.doc_p)]);
    }
}

impl crate::prelude::ToPod for MethDef {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("MethDef", vec![("name", self.name_p.to_pod()), ("recv", self.recv_p.to_pod()), ("params", self.params_p.to_pod()), ("cx", self.cx_p.to_pod()), ("ret", self.ret_p.to_pod()), ("body", self.body_p.to_pod()), ("tail", self.tail_p.to_pod()), ("doc", self.doc_p.to_pod())])
    }
}

impl crate::prelude::FromPod for MethDef {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(MethDef { name_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "name")?)?, recv_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "recv")?)?, params_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "params")?)?, cx_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "cx")?)?, ret_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "ret")?)?, body_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "body")?)?, tail_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "tail")?)?, doc_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "doc")?)? })
    }
}

/// `ModDef`:
///
/// ```prism
/// type ModDef = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct ModDef {
    pub name_p: crate::prelude::Text,
    pub prism_p: crate::prelude::Text,
    pub path_p: crate::prelude::Text,
    pub uses_p: crate::prelude::Array<crate::prelude::Text>,
    pub complete_p: crate::prelude::Array<crate::prelude::Text>,
    pub declared_p: crate::prelude::Array<crate::prelude::Text>,
    pub types_with_p: crate::prelude::Array<crate::prelude::Text>,
    pub items_p: crate::prelude::Array<Item>,
}

impl crate::prelude::Show for ModDef {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("ModDef", &[("name", &self.name_p), ("prism", &self.prism_p), ("path", &self.path_p), ("uses", &self.uses_p), ("complete", &self.complete_p), ("declared", &self.declared_p), ("typesWith", &self.types_with_p), ("items", &self.items_p)]);
    }
}

impl crate::prelude::ToPod for ModDef {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("ModDef", vec![("name", self.name_p.to_pod()), ("prism", self.prism_p.to_pod()), ("path", self.path_p.to_pod()), ("uses", self.uses_p.to_pod()), ("complete", self.complete_p.to_pod()), ("declared", self.declared_p.to_pod()), ("typesWith", self.types_with_p.to_pod()), ("items", self.items_p.to_pod())])
    }
}

impl crate::prelude::FromPod for ModDef {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(ModDef { name_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "name")?)?, prism_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "prism")?)?, path_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "path")?)?, uses_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "uses")?)?, complete_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "complete")?)?, declared_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "declared")?)?, types_with_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "typesWith")?)?, items_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "items")?)? })
    }
}

/// `Model`:
///
/// ```prism
/// type Model = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct Model {
    pub name_p: crate::prelude::Text,
    pub mods_p: crate::prelude::Array<ModDef>,
    pub programs_p: crate::prelude::Array<ProgDef>,
    pub root_o: ::std::option::Option<ProgDef>,
    pub checks_p: crate::prelude::Array<CheckDef>,
    pub elem_p: RowDef,
    pub answer_p: AnswerDef,
    pub elem_complete_p: crate::prelude::Array<crate::prelude::Text>,
    pub elem_declared_p: crate::prelude::Array<crate::prelude::Text>,
    pub scripts_p: crate::prelude::Array<crate::prelude::Text>,
    pub notes_p: crate::prelude::Array<crate::prelude::Text>,
}

impl crate::prelude::Show for Model {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("Model", &[("name", &self.name_p), ("mods", &self.mods_p), ("programs", &self.programs_p), ("root", &self.root_o), ("checks", &self.checks_p), ("elem", &self.elem_p), ("answer", &self.answer_p), ("elemComplete", &self.elem_complete_p), ("elemDeclared", &self.elem_declared_p), ("scripts", &self.scripts_p), ("notes", &self.notes_p)]);
    }
}

impl crate::prelude::ToPod for Model {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("Model", vec![("name", self.name_p.to_pod()), ("mods", self.mods_p.to_pod()), ("programs", self.programs_p.to_pod()), ("root", self.root_o.to_pod()), ("checks", self.checks_p.to_pod()), ("elem", self.elem_p.to_pod()), ("answer", self.answer_p.to_pod()), ("elemComplete", self.elem_complete_p.to_pod()), ("elemDeclared", self.elem_declared_p.to_pod()), ("scripts", self.scripts_p.to_pod()), ("notes", self.notes_p.to_pod())])
    }
}

impl crate::prelude::FromPod for Model {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(Model { name_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "name")?)?, mods_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "mods")?)?, programs_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "programs")?)?, root_o: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "root")?)?, checks_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "checks")?)?, elem_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "elem")?)?, answer_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "answer")?)?, elem_complete_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "elemComplete")?)?, elem_declared_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "elemDeclared")?)?, scripts_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "scripts")?)?, notes_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "notes")?)? })
    }
}

/// `NodeDef`:
///
/// ```prism
/// type NodeDef = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct NodeDef {
    pub name_p: crate::prelude::Text,
    pub prism_p: crate::prelude::Text,
    pub doc_p: crate::prelude::Text,
    pub params_p: crate::prelude::Array<(crate::prelude::Text, OutTy)>,
    pub fields_p: crate::prelude::Array<(crate::prelude::Text, OutTy, crate::prelude::Text)>,
    pub consts_p: crate::prelude::Array<(crate::prelude::Text, crate::prelude::Nat, crate::prelude::Text)>,
    pub lets_p: crate::prelude::Array<Do>,
    pub inits_p: crate::prelude::Array<(crate::prelude::Text, Ex)>,
    pub build_p: crate::prelude::Array<Do>,
    pub fallible_p: bool,
    pub methods_p: crate::prelude::Array<MethDef>,
    pub answers_p: crate::prelude::Array<(Pa, Ex)>,
    pub hooks_p: crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<Do>)>,
    pub builders_p: crate::prelude::Array<ForDef>,
    pub wakes_p: bool,
    pub children_p: crate::prelude::Array<NodeDef>,
    pub gens_p: crate::prelude::Array<GenDef>,
    pub subs_p: crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text, OutTy)>,
    pub top_p: crate::prelude::Nat,
    pub row_kind_p: RowKind,
    pub hosted_p: crate::prelude::Array<MethDef>,
}

impl crate::prelude::Show for NodeDef {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("NodeDef", &[("name", &self.name_p), ("prism", &self.prism_p), ("doc", &self.doc_p), ("params", &self.params_p), ("fields", &self.fields_p), ("consts", &self.consts_p), ("lets", &self.lets_p), ("inits", &self.inits_p), ("build", &self.build_p), ("fallible", &self.fallible_p), ("methods", &self.methods_p), ("answers", &self.answers_p), ("hooks", &self.hooks_p), ("builders", &self.builders_p), ("wakes", &self.wakes_p), ("children", &self.children_p), ("gens", &self.gens_p), ("subs", &self.subs_p), ("top", &self.top_p), ("rowKind", &self.row_kind_p), ("hosted", &self.hosted_p)]);
    }
}

impl crate::prelude::ToPod for NodeDef {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("NodeDef", vec![("name", self.name_p.to_pod()), ("prism", self.prism_p.to_pod()), ("doc", self.doc_p.to_pod()), ("params", self.params_p.to_pod()), ("fields", self.fields_p.to_pod()), ("consts", self.consts_p.to_pod()), ("lets", self.lets_p.to_pod()), ("inits", self.inits_p.to_pod()), ("build", self.build_p.to_pod()), ("fallible", self.fallible_p.to_pod()), ("methods", self.methods_p.to_pod()), ("answers", self.answers_p.to_pod()), ("hooks", self.hooks_p.to_pod()), ("builders", self.builders_p.to_pod()), ("wakes", self.wakes_p.to_pod()), ("children", self.children_p.to_pod()), ("gens", self.gens_p.to_pod()), ("subs", self.subs_p.to_pod()), ("top", self.top_p.to_pod()), ("rowKind", self.row_kind_p.to_pod()), ("hosted", self.hosted_p.to_pod())])
    }
}

impl crate::prelude::FromPod for NodeDef {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(NodeDef { name_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "name")?)?, prism_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "prism")?)?, doc_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "doc")?)?, params_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "params")?)?, fields_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "fields")?)?, consts_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "consts")?)?, lets_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "lets")?)?, inits_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "inits")?)?, build_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "build")?)?, fallible_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "fallible")?)?, methods_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "methods")?)?, answers_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "answers")?)?, hooks_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "hooks")?)?, builders_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "builders")?)?, wakes_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "wakes")?)?, children_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "children")?)?, gens_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "gens")?)?, subs_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "subs")?)?, top_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "top")?)?, row_kind_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "rowKind")?)?, hosted_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "hosted")?)? })
    }
}

/// `OutTy`:
///
/// ```prism
/// type OutTy = choice:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub enum OutTy {
    OutNat,
    OutInt,
    OutU8,
    OutFloat,
    OutBool,
    OutChar,
    OutText,
    OutCursor,
    OutRegex,
    OutReplacement,
    OutUnit,
    OutPath,
    OutDuration,
    OutError,
    OutNamed(Ref, crate::prelude::Array<OutTy>),
    OutOpt(::std::rc::Rc<OutTy>),
    OutRes(::std::rc::Rc<OutTy>),
    OutTuple(crate::prelude::Array<OutTy>),
    OutArray(::std::rc::Rc<OutTy>),
    OutMap(::std::rc::Rc<OutTy>, ::std::rc::Rc<OutTy>),
    OutFn(crate::prelude::Array<OutTy>, ::std::rc::Rc<OutTy>),
    OutJobFn(::std::rc::Rc<OutTy>, ::std::rc::Rc<OutTy>),
    OutJob(::std::rc::Rc<OutTy>),
    OutEvent(::std::rc::Rc<OutTy>),
    OutDyn(::std::rc::Rc<OutTy>),
    OutGen(crate::prelude::Text),
    OutRc(::std::rc::Rc<OutTy>),
    OutRef(::std::rc::Rc<OutTy>),
    OutRefMut(::std::rc::Rc<OutTy>),
    OutPod,
    OutShowAny,
    OutHold(::std::rc::Rc<OutTy>),
    OutStamped(::std::rc::Rc<OutTy>),
    OutSnapshot(::std::rc::Rc<OutTy>),
    OutDefer(::std::rc::Rc<OutTy>),
    OutWeak(crate::prelude::Text),
    OutCell(::std::rc::Rc<OutTy>),
    OutWakes,
    OutCount,
    OutObj(::std::rc::Rc<OutTy>),
    OutSlice(::std::rc::Rc<OutTy>),
    OutPort(::std::rc::Rc<OutTy>),
    OutLive(::std::rc::Rc<OutTy>),
    OutQuantified(crate::prelude::Text),
    OutTurn,
    OutAssoc(crate::prelude::Text, crate::prelude::Text, ::std::rc::Rc<OutTy>),
    OutRefused(crate::prelude::Text),
}

impl crate::prelude::Show for OutTy {
    fn show(&self, p: &mut crate::prelude::Printer) {
        match self {
            OutTy::OutNat => p.choice("OutNat", &[]),
            OutTy::OutInt => p.choice("OutInt", &[]),
            OutTy::OutU8 => p.choice("OutU8", &[]),
            OutTy::OutFloat => p.choice("OutFloat", &[]),
            OutTy::OutBool => p.choice("OutBool", &[]),
            OutTy::OutChar => p.choice("OutChar", &[]),
            OutTy::OutText => p.choice("OutText", &[]),
            OutTy::OutCursor => p.choice("OutCursor", &[]),
            OutTy::OutRegex => p.choice("OutRegex", &[]),
            OutTy::OutReplacement => p.choice("OutReplacement", &[]),
            OutTy::OutUnit => p.choice("OutUnit", &[]),
            OutTy::OutPath => p.choice("OutPath", &[]),
            OutTy::OutDuration => p.choice("OutDuration", &[]),
            OutTy::OutError => p.choice("OutError", &[]),
            OutTy::OutNamed(a0, a1) => p.choice("OutNamed", &[a0, a1]),
            OutTy::OutOpt(a0) => p.choice("OutOpt", &[a0]),
            OutTy::OutRes(a0) => p.choice("OutRes", &[a0]),
            OutTy::OutTuple(a0) => p.choice("OutTuple", &[a0]),
            OutTy::OutArray(a0) => p.choice("OutArray", &[a0]),
            OutTy::OutMap(a0, a1) => p.choice("OutMap", &[a0, a1]),
            OutTy::OutFn(a0, a1) => p.choice("OutFn", &[a0, a1]),
            OutTy::OutJobFn(a0, a1) => p.choice("OutJobFn", &[a0, a1]),
            OutTy::OutJob(a0) => p.choice("OutJob", &[a0]),
            OutTy::OutEvent(a0) => p.choice("OutEvent", &[a0]),
            OutTy::OutDyn(a0) => p.choice("OutDyn", &[a0]),
            OutTy::OutGen(a0) => p.choice("OutGen", &[a0]),
            OutTy::OutRc(a0) => p.choice("OutRc", &[a0]),
            OutTy::OutRef(a0) => p.choice("OutRef", &[a0]),
            OutTy::OutRefMut(a0) => p.choice("OutRefMut", &[a0]),
            OutTy::OutPod => p.choice("OutPod", &[]),
            OutTy::OutShowAny => p.choice("OutShowAny", &[]),
            OutTy::OutHold(a0) => p.choice("OutHold", &[a0]),
            OutTy::OutStamped(a0) => p.choice("OutStamped", &[a0]),
            OutTy::OutSnapshot(a0) => p.choice("OutSnapshot", &[a0]),
            OutTy::OutDefer(a0) => p.choice("OutDefer", &[a0]),
            OutTy::OutWeak(a0) => p.choice("OutWeak", &[a0]),
            OutTy::OutCell(a0) => p.choice("OutCell", &[a0]),
            OutTy::OutWakes => p.choice("OutWakes", &[]),
            OutTy::OutCount => p.choice("OutCount", &[]),
            OutTy::OutObj(a0) => p.choice("OutObj", &[a0]),
            OutTy::OutSlice(a0) => p.choice("OutSlice", &[a0]),
            OutTy::OutPort(a0) => p.choice("OutPort", &[a0]),
            OutTy::OutLive(a0) => p.choice("OutLive", &[a0]),
            OutTy::OutQuantified(a0) => p.choice("OutQuantified", &[a0]),
            OutTy::OutTurn => p.choice("OutTurn", &[]),
            OutTy::OutAssoc(a0, a1, a2) => p.choice("OutAssoc", &[a0, a1, a2]),
            OutTy::OutRefused(a0) => p.choice("OutRefused", &[a0]),
        }
    }
}

impl crate::prelude::ToPod for OutTy {
    fn to_pod(&self) -> crate::prelude::Pod {
        match self {
            OutTy::OutNat => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("OutNat", 0), vec![]),
            OutTy::OutInt => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("OutInt", 1), vec![]),
            OutTy::OutU8 => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("OutU8", 2), vec![]),
            OutTy::OutFloat => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("OutFloat", 3), vec![]),
            OutTy::OutBool => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("OutBool", 4), vec![]),
            OutTy::OutChar => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("OutChar", 5), vec![]),
            OutTy::OutText => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("OutText", 6), vec![]),
            OutTy::OutCursor => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("OutCursor", 7), vec![]),
            OutTy::OutRegex => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("OutRegex", 8), vec![]),
            OutTy::OutReplacement => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("OutReplacement", 9), vec![]),
            OutTy::OutUnit => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("OutUnit", 10), vec![]),
            OutTy::OutPath => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("OutPath", 11), vec![]),
            OutTy::OutDuration => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("OutDuration", 12), vec![]),
            OutTy::OutError => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("OutError", 13), vec![]),
            OutTy::OutNamed(a0, a1) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("OutNamed", 14), vec![a0.to_pod(), a1.to_pod()]),
            OutTy::OutOpt(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("OutOpt", 15), vec![a0.to_pod()]),
            OutTy::OutRes(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("OutRes", 16), vec![a0.to_pod()]),
            OutTy::OutTuple(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("OutTuple", 17), vec![a0.to_pod()]),
            OutTy::OutArray(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("OutArray", 18), vec![a0.to_pod()]),
            OutTy::OutMap(a0, a1) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("OutMap", 19), vec![a0.to_pod(), a1.to_pod()]),
            OutTy::OutFn(a0, a1) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("OutFn", 20), vec![a0.to_pod(), a1.to_pod()]),
            OutTy::OutJobFn(a0, a1) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("OutJobFn", 21), vec![a0.to_pod(), a1.to_pod()]),
            OutTy::OutJob(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("OutJob", 22), vec![a0.to_pod()]),
            OutTy::OutEvent(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("OutEvent", 23), vec![a0.to_pod()]),
            OutTy::OutDyn(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("OutDyn", 24), vec![a0.to_pod()]),
            OutTy::OutGen(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("OutGen", 25), vec![a0.to_pod()]),
            OutTy::OutRc(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("OutRc", 26), vec![a0.to_pod()]),
            OutTy::OutRef(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("OutRef", 27), vec![a0.to_pod()]),
            OutTy::OutRefMut(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("OutRefMut", 28), vec![a0.to_pod()]),
            OutTy::OutPod => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("OutPod", 29), vec![]),
            OutTy::OutShowAny => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("OutShowAny", 30), vec![]),
            OutTy::OutHold(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("OutHold", 31), vec![a0.to_pod()]),
            OutTy::OutStamped(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("OutStamped", 32), vec![a0.to_pod()]),
            OutTy::OutSnapshot(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("OutSnapshot", 33), vec![a0.to_pod()]),
            OutTy::OutDefer(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("OutDefer", 34), vec![a0.to_pod()]),
            OutTy::OutWeak(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("OutWeak", 35), vec![a0.to_pod()]),
            OutTy::OutCell(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("OutCell", 36), vec![a0.to_pod()]),
            OutTy::OutWakes => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("OutWakes", 37), vec![]),
            OutTy::OutCount => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("OutCount", 38), vec![]),
            OutTy::OutObj(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("OutObj", 39), vec![a0.to_pod()]),
            OutTy::OutSlice(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("OutSlice", 40), vec![a0.to_pod()]),
            OutTy::OutPort(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("OutPort", 41), vec![a0.to_pod()]),
            OutTy::OutLive(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("OutLive", 42), vec![a0.to_pod()]),
            OutTy::OutQuantified(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("OutQuantified", 43), vec![a0.to_pod()]),
            OutTy::OutTurn => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("OutTurn", 44), vec![]),
            OutTy::OutAssoc(a0, a1, a2) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("OutAssoc", 45), vec![a0.to_pod(), a1.to_pod(), a2.to_pod()]),
            OutTy::OutRefused(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("OutRefused", 46), vec![a0.to_pod()]),
        }
    }
}

impl crate::prelude::FromPod for OutTy {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        match p.structure() {
            crate::prelude::Pod::Choice(c, a) if &**c == "OutNat" && a.len() == 0 => ::std::result::Result::Ok(OutTy::OutNat),
            crate::prelude::Pod::Choice(c, a) if &**c == "OutInt" && a.len() == 0 => ::std::result::Result::Ok(OutTy::OutInt),
            crate::prelude::Pod::Choice(c, a) if &**c == "OutU8" && a.len() == 0 => ::std::result::Result::Ok(OutTy::OutU8),
            crate::prelude::Pod::Choice(c, a) if &**c == "OutFloat" && a.len() == 0 => ::std::result::Result::Ok(OutTy::OutFloat),
            crate::prelude::Pod::Choice(c, a) if &**c == "OutBool" && a.len() == 0 => ::std::result::Result::Ok(OutTy::OutBool),
            crate::prelude::Pod::Choice(c, a) if &**c == "OutChar" && a.len() == 0 => ::std::result::Result::Ok(OutTy::OutChar),
            crate::prelude::Pod::Choice(c, a) if &**c == "OutText" && a.len() == 0 => ::std::result::Result::Ok(OutTy::OutText),
            crate::prelude::Pod::Choice(c, a) if &**c == "OutCursor" && a.len() == 0 => ::std::result::Result::Ok(OutTy::OutCursor),
            crate::prelude::Pod::Choice(c, a) if &**c == "OutRegex" && a.len() == 0 => ::std::result::Result::Ok(OutTy::OutRegex),
            crate::prelude::Pod::Choice(c, a) if &**c == "OutReplacement" && a.len() == 0 => ::std::result::Result::Ok(OutTy::OutReplacement),
            crate::prelude::Pod::Choice(c, a) if &**c == "OutUnit" && a.len() == 0 => ::std::result::Result::Ok(OutTy::OutUnit),
            crate::prelude::Pod::Choice(c, a) if &**c == "OutPath" && a.len() == 0 => ::std::result::Result::Ok(OutTy::OutPath),
            crate::prelude::Pod::Choice(c, a) if &**c == "OutDuration" && a.len() == 0 => ::std::result::Result::Ok(OutTy::OutDuration),
            crate::prelude::Pod::Choice(c, a) if &**c == "OutError" && a.len() == 0 => ::std::result::Result::Ok(OutTy::OutError),
            crate::prelude::Pod::Choice(c, a) if &**c == "OutNamed" && a.len() == 2 => ::std::result::Result::Ok(OutTy::OutNamed(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "OutOpt" && a.len() == 1 => ::std::result::Result::Ok(OutTy::OutOpt(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "OutRes" && a.len() == 1 => ::std::result::Result::Ok(OutTy::OutRes(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "OutTuple" && a.len() == 1 => ::std::result::Result::Ok(OutTy::OutTuple(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "OutArray" && a.len() == 1 => ::std::result::Result::Ok(OutTy::OutArray(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "OutMap" && a.len() == 2 => ::std::result::Result::Ok(OutTy::OutMap(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "OutFn" && a.len() == 2 => ::std::result::Result::Ok(OutTy::OutFn(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "OutJobFn" && a.len() == 2 => ::std::result::Result::Ok(OutTy::OutJobFn(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "OutJob" && a.len() == 1 => ::std::result::Result::Ok(OutTy::OutJob(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "OutEvent" && a.len() == 1 => ::std::result::Result::Ok(OutTy::OutEvent(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "OutDyn" && a.len() == 1 => ::std::result::Result::Ok(OutTy::OutDyn(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "OutGen" && a.len() == 1 => ::std::result::Result::Ok(OutTy::OutGen(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "OutRc" && a.len() == 1 => ::std::result::Result::Ok(OutTy::OutRc(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "OutRef" && a.len() == 1 => ::std::result::Result::Ok(OutTy::OutRef(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "OutRefMut" && a.len() == 1 => ::std::result::Result::Ok(OutTy::OutRefMut(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "OutPod" && a.len() == 0 => ::std::result::Result::Ok(OutTy::OutPod),
            crate::prelude::Pod::Choice(c, a) if &**c == "OutShowAny" && a.len() == 0 => ::std::result::Result::Ok(OutTy::OutShowAny),
            crate::prelude::Pod::Choice(c, a) if &**c == "OutHold" && a.len() == 1 => ::std::result::Result::Ok(OutTy::OutHold(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "OutStamped" && a.len() == 1 => ::std::result::Result::Ok(OutTy::OutStamped(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "OutSnapshot" && a.len() == 1 => ::std::result::Result::Ok(OutTy::OutSnapshot(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "OutDefer" && a.len() == 1 => ::std::result::Result::Ok(OutTy::OutDefer(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "OutWeak" && a.len() == 1 => ::std::result::Result::Ok(OutTy::OutWeak(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "OutCell" && a.len() == 1 => ::std::result::Result::Ok(OutTy::OutCell(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "OutWakes" && a.len() == 0 => ::std::result::Result::Ok(OutTy::OutWakes),
            crate::prelude::Pod::Choice(c, a) if &**c == "OutCount" && a.len() == 0 => ::std::result::Result::Ok(OutTy::OutCount),
            crate::prelude::Pod::Choice(c, a) if &**c == "OutObj" && a.len() == 1 => ::std::result::Result::Ok(OutTy::OutObj(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "OutSlice" && a.len() == 1 => ::std::result::Result::Ok(OutTy::OutSlice(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "OutPort" && a.len() == 1 => ::std::result::Result::Ok(OutTy::OutPort(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "OutLive" && a.len() == 1 => ::std::result::Result::Ok(OutTy::OutLive(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "OutQuantified" && a.len() == 1 => ::std::result::Result::Ok(OutTy::OutQuantified(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "OutTurn" && a.len() == 0 => ::std::result::Result::Ok(OutTy::OutTurn),
            crate::prelude::Pod::Choice(c, a) if &**c == "OutAssoc" && a.len() == 3 => ::std::result::Result::Ok(OutTy::OutAssoc(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?, crate::prelude::FromPod::from_pod(&a[2])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "OutRefused" && a.len() == 1 => ::std::result::Result::Ok(OutTy::OutRefused(crate::prelude::FromPod::from_pod(&a[0])?)),
            other => ::prism_rtl::pod::mismatch("a OutTy", other),
        }
    }
}

/// `Pa`:
///
/// ```prism
/// type Pa = choice:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub enum Pa {
    PaWild,
    PaBind(crate::prelude::Text),
    PaMut(crate::prelude::Text),
    PaCtor(Ref, crate::prelude::Array<Pa>),
    PaUnit(Ref),
    PaRecord(Ref, crate::prelude::Array<(crate::prelude::Text, Pa)>, bool),
    PaTuple(crate::prelude::Array<Pa>),
    PaChar(crate::prelude::Text),
    PaBool(bool),
    PaIndex(crate::prelude::Nat),
    PaConst(crate::prelude::Text),
    PaSlice(crate::prelude::Array<Pa>),
    PaRest(crate::prelude::Text),
    PaTyped(::std::rc::Rc<Pa>, OutTy),
}

impl crate::prelude::Show for Pa {
    fn show(&self, p: &mut crate::prelude::Printer) {
        match self {
            Pa::PaWild => p.choice("PaWild", &[]),
            Pa::PaBind(a0) => p.choice("PaBind", &[a0]),
            Pa::PaMut(a0) => p.choice("PaMut", &[a0]),
            Pa::PaCtor(a0, a1) => p.choice("PaCtor", &[a0, a1]),
            Pa::PaUnit(a0) => p.choice("PaUnit", &[a0]),
            Pa::PaRecord(a0, a1, a2) => p.choice("PaRecord", &[a0, a1, a2]),
            Pa::PaTuple(a0) => p.choice("PaTuple", &[a0]),
            Pa::PaChar(a0) => p.choice("PaChar", &[a0]),
            Pa::PaBool(a0) => p.choice("PaBool", &[a0]),
            Pa::PaIndex(a0) => p.choice("PaIndex", &[a0]),
            Pa::PaConst(a0) => p.choice("PaConst", &[a0]),
            Pa::PaSlice(a0) => p.choice("PaSlice", &[a0]),
            Pa::PaRest(a0) => p.choice("PaRest", &[a0]),
            Pa::PaTyped(a0, a1) => p.choice("PaTyped", &[a0, a1]),
        }
    }
}

impl crate::prelude::ToPod for Pa {
    fn to_pod(&self) -> crate::prelude::Pod {
        match self {
            Pa::PaWild => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("PaWild", 0), vec![]),
            Pa::PaBind(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("PaBind", 1), vec![a0.to_pod()]),
            Pa::PaMut(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("PaMut", 2), vec![a0.to_pod()]),
            Pa::PaCtor(a0, a1) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("PaCtor", 3), vec![a0.to_pod(), a1.to_pod()]),
            Pa::PaUnit(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("PaUnit", 4), vec![a0.to_pod()]),
            Pa::PaRecord(a0, a1, a2) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("PaRecord", 5), vec![a0.to_pod(), a1.to_pod(), a2.to_pod()]),
            Pa::PaTuple(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("PaTuple", 6), vec![a0.to_pod()]),
            Pa::PaChar(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("PaChar", 7), vec![a0.to_pod()]),
            Pa::PaBool(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("PaBool", 8), vec![a0.to_pod()]),
            Pa::PaIndex(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("PaIndex", 9), vec![a0.to_pod()]),
            Pa::PaConst(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("PaConst", 10), vec![a0.to_pod()]),
            Pa::PaSlice(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("PaSlice", 11), vec![a0.to_pod()]),
            Pa::PaRest(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("PaRest", 12), vec![a0.to_pod()]),
            Pa::PaTyped(a0, a1) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("PaTyped", 13), vec![a0.to_pod(), a1.to_pod()]),
        }
    }
}

impl crate::prelude::FromPod for Pa {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        match p.structure() {
            crate::prelude::Pod::Choice(c, a) if &**c == "PaWild" && a.len() == 0 => ::std::result::Result::Ok(Pa::PaWild),
            crate::prelude::Pod::Choice(c, a) if &**c == "PaBind" && a.len() == 1 => ::std::result::Result::Ok(Pa::PaBind(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "PaMut" && a.len() == 1 => ::std::result::Result::Ok(Pa::PaMut(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "PaCtor" && a.len() == 2 => ::std::result::Result::Ok(Pa::PaCtor(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "PaUnit" && a.len() == 1 => ::std::result::Result::Ok(Pa::PaUnit(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "PaRecord" && a.len() == 3 => ::std::result::Result::Ok(Pa::PaRecord(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?, crate::prelude::FromPod::from_pod(&a[2])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "PaTuple" && a.len() == 1 => ::std::result::Result::Ok(Pa::PaTuple(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "PaChar" && a.len() == 1 => ::std::result::Result::Ok(Pa::PaChar(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "PaBool" && a.len() == 1 => ::std::result::Result::Ok(Pa::PaBool(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "PaIndex" && a.len() == 1 => ::std::result::Result::Ok(Pa::PaIndex(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "PaConst" && a.len() == 1 => ::std::result::Result::Ok(Pa::PaConst(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "PaSlice" && a.len() == 1 => ::std::result::Result::Ok(Pa::PaSlice(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "PaRest" && a.len() == 1 => ::std::result::Result::Ok(Pa::PaRest(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "PaTyped" && a.len() == 2 => ::std::result::Result::Ok(Pa::PaTyped(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?)),
            other => ::prism_rtl::pod::mismatch("a Pa", other),
        }
    }
}

/// `PackedDef`:
///
/// ```prism
/// type PackedDef = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct PackedDef {
    pub name_p: crate::prelude::Text,
    pub tr_p: crate::prelude::Text,
    pub methods_p: crate::prelude::Array<PackedMethod>,
}

impl crate::prelude::Show for PackedDef {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("PackedDef", &[("name", &self.name_p), ("tr", &self.tr_p), ("methods", &self.methods_p)]);
    }
}

impl crate::prelude::ToPod for PackedDef {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("PackedDef", vec![("name", self.name_p.to_pod()), ("tr", self.tr_p.to_pod()), ("methods", self.methods_p.to_pod())])
    }
}

impl crate::prelude::FromPod for PackedDef {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(PackedDef { name_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "name")?)?, tr_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "tr")?)?, methods_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "methods")?)? })
    }
}

/// `PackedMethod`:
///
/// ```prism
/// type PackedMethod = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct PackedMethod {
    pub method_p: FnDef,
    pub hidden_p: crate::prelude::Array<bool>,
    pub hidden_result_p: bool,
}

impl crate::prelude::Show for PackedMethod {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("PackedMethod", &[("method", &self.method_p), ("hidden", &self.hidden_p), ("hiddenResult", &self.hidden_result_p)]);
    }
}

impl crate::prelude::ToPod for PackedMethod {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("PackedMethod", vec![("method", self.method_p.to_pod()), ("hidden", self.hidden_p.to_pod()), ("hiddenResult", self.hidden_result_p.to_pod())])
    }
}

impl crate::prelude::FromPod for PackedMethod {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(PackedMethod { method_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "method")?)?, hidden_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "hidden")?)?, hidden_result_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "hiddenResult")?)? })
    }
}

/// `Pos`:
///
/// ```prism
/// type Pos = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct Pos {
    pub scope_p: crate::prelude::Nat,
    pub at_p: crate::prelude::Nat,
}

impl crate::prelude::Show for Pos {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("Pos", &[("scope", &self.scope_p), ("at", &self.at_p)]);
    }
}

impl crate::prelude::ToPod for Pos {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("Pos", vec![("scope", self.scope_p.to_pod()), ("at", self.at_p.to_pod())])
    }
}

impl crate::prelude::FromPod for Pos {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(Pos { scope_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "scope")?)?, at_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "at")?)? })
    }
}

/// `ProgDef`:
///
/// ```prism
/// type ProgDef = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct ProgDef {
    pub name_p: crate::prelude::Text,
    pub prism_p: crate::prelude::Text,
    pub node_p: crate::prelude::Text,
    pub params_p: crate::prelude::Array<(crate::prelude::Text, OutTy)>,
    pub fallible_p: bool,
    pub world_p: crate::prelude::Text,
}

impl crate::prelude::Show for ProgDef {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("ProgDef", &[("name", &self.name_p), ("prism", &self.prism_p), ("node", &self.node_p), ("params", &self.params_p), ("fallible", &self.fallible_p), ("world", &self.world_p)]);
    }
}

impl crate::prelude::ToPod for ProgDef {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("ProgDef", vec![("name", self.name_p.to_pod()), ("prism", self.prism_p.to_pod()), ("node", self.node_p.to_pod()), ("params", self.params_p.to_pod()), ("fallible", self.fallible_p.to_pod()), ("world", self.world_p.to_pod())])
    }
}

impl crate::prelude::FromPod for ProgDef {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(ProgDef { name_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "name")?)?, prism_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "prism")?)?, node_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "node")?)?, params_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "params")?)?, fallible_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "fallible")?)?, world_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "world")?)? })
    }
}

/// `Recv`:
///
/// ```prism
/// type Recv = choice:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub enum Recv {
    RecvRc,
    RecvRef,
    RecvOwned,
}

impl crate::prelude::Show for Recv {
    fn show(&self, p: &mut crate::prelude::Printer) {
        match self {
            Recv::RecvRc => p.choice("RecvRc", &[]),
            Recv::RecvRef => p.choice("RecvRef", &[]),
            Recv::RecvOwned => p.choice("RecvOwned", &[]),
        }
    }
}

impl crate::prelude::ToPod for Recv {
    fn to_pod(&self) -> crate::prelude::Pod {
        match self {
            Recv::RecvRc => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("RecvRc", 0), vec![]),
            Recv::RecvRef => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("RecvRef", 1), vec![]),
            Recv::RecvOwned => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("RecvOwned", 2), vec![]),
        }
    }
}

impl crate::prelude::FromPod for Recv {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        match p.structure() {
            crate::prelude::Pod::Choice(c, a) if &**c == "RecvRc" && a.len() == 0 => ::std::result::Result::Ok(Recv::RecvRc),
            crate::prelude::Pod::Choice(c, a) if &**c == "RecvRef" && a.len() == 0 => ::std::result::Result::Ok(Recv::RecvRef),
            crate::prelude::Pod::Choice(c, a) if &**c == "RecvOwned" && a.len() == 0 => ::std::result::Result::Ok(Recv::RecvOwned),
            other => ::prism_rtl::pod::mismatch("a Recv", other),
        }
    }
}

/// `Ref`:
///
/// ```prism
/// type Ref = choice:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub enum Ref {
    RefItem(crate::prelude::Text, crate::prelude::Text, crate::prelude::Text),
    RefRuntime(crate::prelude::Text),
}

impl crate::prelude::Show for Ref {
    fn show(&self, p: &mut crate::prelude::Printer) {
        match self {
            Ref::RefItem(a0, a1, a2) => p.choice("RefItem", &[a0, a1, a2]),
            Ref::RefRuntime(a0) => p.choice("RefRuntime", &[a0]),
        }
    }
}

impl crate::prelude::ToPod for Ref {
    fn to_pod(&self) -> crate::prelude::Pod {
        match self {
            Ref::RefItem(a0, a1, a2) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("RefItem", 0), vec![a0.to_pod(), a1.to_pod(), a2.to_pod()]),
            Ref::RefRuntime(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("RefRuntime", 1), vec![a0.to_pod()]),
        }
    }
}

impl crate::prelude::FromPod for Ref {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        match p.structure() {
            crate::prelude::Pod::Choice(c, a) if &**c == "RefItem" && a.len() == 3 => ::std::result::Result::Ok(Ref::RefItem(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?, crate::prelude::FromPod::from_pod(&a[2])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "RefRuntime" && a.len() == 1 => ::std::result::Result::Ok(Ref::RefRuntime(crate::prelude::FromPod::from_pod(&a[0])?)),
            other => ::prism_rtl::pod::mismatch("a Ref", other),
        }
    }
}

/// `RowDef`:
///
/// ```prism
/// type RowDef = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct RowDef {
    pub name_p: crate::prelude::Text,
    pub prism_p: crate::prelude::Text,
    pub cases_p: crate::prelude::Array<(crate::prelude::Text, Ref)>,
    pub pod_p: bool,
    pub doc_p: crate::prelude::Text,
    pub eq_p: bool,
    pub level_p: bool,
    pub deep_p: crate::prelude::Array<crate::prelude::Text>,
}

impl crate::prelude::Show for RowDef {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("RowDef", &[("name", &self.name_p), ("prism", &self.prism_p), ("cases", &self.cases_p), ("pod", &self.pod_p), ("doc", &self.doc_p), ("eq", &self.eq_p), ("level", &self.level_p), ("deep", &self.deep_p)]);
    }
}

impl crate::prelude::ToPod for RowDef {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("RowDef", vec![("name", self.name_p.to_pod()), ("prism", self.prism_p.to_pod()), ("cases", self.cases_p.to_pod()), ("pod", self.pod_p.to_pod()), ("doc", self.doc_p.to_pod()), ("eq", self.eq_p.to_pod()), ("level", self.level_p.to_pod()), ("deep", self.deep_p.to_pod())])
    }
}

impl crate::prelude::FromPod for RowDef {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(RowDef { name_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "name")?)?, prism_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "prism")?)?, cases_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "cases")?)?, pod_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "pod")?)?, doc_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "doc")?)?, eq_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "eq")?)?, level_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "level")?)?, deep_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "deep")?)? })
    }
}

/// `RowKind`:
///
/// ```prism
/// type RowKind = choice:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub enum RowKind {
    ForRow,
    GenerationRow,
    ValueRow,
    NotARow,
}

impl crate::prelude::Show for RowKind {
    fn show(&self, p: &mut crate::prelude::Printer) {
        match self {
            RowKind::ForRow => p.choice("ForRow", &[]),
            RowKind::GenerationRow => p.choice("GenerationRow", &[]),
            RowKind::ValueRow => p.choice("ValueRow", &[]),
            RowKind::NotARow => p.choice("NotARow", &[]),
        }
    }
}

impl crate::prelude::ToPod for RowKind {
    fn to_pod(&self) -> crate::prelude::Pod {
        match self {
            RowKind::ForRow => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("ForRow", 0), vec![]),
            RowKind::GenerationRow => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("GenerationRow", 1), vec![]),
            RowKind::ValueRow => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("ValueRow", 2), vec![]),
            RowKind::NotARow => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("NotARow", 3), vec![]),
        }
    }
}

impl crate::prelude::FromPod for RowKind {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        match p.structure() {
            crate::prelude::Pod::Choice(c, a) if &**c == "ForRow" && a.len() == 0 => ::std::result::Result::Ok(RowKind::ForRow),
            crate::prelude::Pod::Choice(c, a) if &**c == "GenerationRow" && a.len() == 0 => ::std::result::Result::Ok(RowKind::GenerationRow),
            crate::prelude::Pod::Choice(c, a) if &**c == "ValueRow" && a.len() == 0 => ::std::result::Result::Ok(RowKind::ValueRow),
            crate::prelude::Pod::Choice(c, a) if &**c == "NotARow" && a.len() == 0 => ::std::result::Result::Ok(RowKind::NotARow),
            other => ::prism_rtl::pod::mismatch("a RowKind", other),
        }
    }
}

/// `Shown`:
///
/// ```prism
/// type Shown = choice:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub enum Shown {
    ShownOwn,
    ShownDerived,
    NotShown,
}

impl crate::prelude::Show for Shown {
    fn show(&self, p: &mut crate::prelude::Printer) {
        match self {
            Shown::ShownOwn => p.choice("ShownOwn", &[]),
            Shown::ShownDerived => p.choice("ShownDerived", &[]),
            Shown::NotShown => p.choice("NotShown", &[]),
        }
    }
}

impl crate::prelude::ToPod for Shown {
    fn to_pod(&self) -> crate::prelude::Pod {
        match self {
            Shown::ShownOwn => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("ShownOwn", 0), vec![]),
            Shown::ShownDerived => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("ShownDerived", 1), vec![]),
            Shown::NotShown => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("NotShown", 2), vec![]),
        }
    }
}

impl crate::prelude::FromPod for Shown {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        match p.structure() {
            crate::prelude::Pod::Choice(c, a) if &**c == "ShownOwn" && a.len() == 0 => ::std::result::Result::Ok(Shown::ShownOwn),
            crate::prelude::Pod::Choice(c, a) if &**c == "ShownDerived" && a.len() == 0 => ::std::result::Result::Ok(Shown::ShownDerived),
            crate::prelude::Pod::Choice(c, a) if &**c == "NotShown" && a.len() == 0 => ::std::result::Result::Ok(Shown::NotShown),
            other => ::prism_rtl::pod::mismatch("a Shown", other),
        }
    }
}

/// `TagDef`:
///
/// ```prism
/// type TagDef = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct TagDef {
    pub name_p: crate::prelude::Text,
    pub tag_name_p: crate::prelude::Text,
    pub fields_p: crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text, OutTy)>,
    pub events_p: crate::prelude::Array<(crate::prelude::Text, OutTy)>,
    pub doc_p: crate::prelude::Text,
    pub pod_p: bool,
    pub eq_p: bool,
}

impl crate::prelude::Show for TagDef {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("TagDef", &[("name", &self.name_p), ("tagName", &self.tag_name_p), ("fields", &self.fields_p), ("events", &self.events_p), ("doc", &self.doc_p), ("pod", &self.pod_p), ("eq", &self.eq_p)]);
    }
}

impl crate::prelude::ToPod for TagDef {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("TagDef", vec![("name", self.name_p.to_pod()), ("tagName", self.tag_name_p.to_pod()), ("fields", self.fields_p.to_pod()), ("events", self.events_p.to_pod()), ("doc", self.doc_p.to_pod()), ("pod", self.pod_p.to_pod()), ("eq", self.eq_p.to_pod())])
    }
}

impl crate::prelude::FromPod for TagDef {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(TagDef { name_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "name")?)?, tag_name_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "tagName")?)?, fields_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "fields")?)?, events_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "events")?)?, doc_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "doc")?)?, pod_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "pod")?)?, eq_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "eq")?)? })
    }
}

/// `TraitDef`:
///
/// ```prism
/// type TraitDef = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct TraitDef {
    pub name_p: crate::prelude::Text,
    pub result_only_p: crate::prelude::Array<crate::prelude::Text>,
    pub assocs_p: crate::prelude::Array<crate::prelude::Text>,
    pub methods_p: crate::prelude::Array<FnDef>,
    pub defaults_p: crate::prelude::Array<crate::prelude::Text>,
    pub doc_p: crate::prelude::Text,
}

impl crate::prelude::Show for TraitDef {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("TraitDef", &[("name", &self.name_p), ("resultOnly", &self.result_only_p), ("assocs", &self.assocs_p), ("methods", &self.methods_p), ("defaults", &self.defaults_p), ("doc", &self.doc_p)]);
    }
}

impl crate::prelude::ToPod for TraitDef {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("TraitDef", vec![("name", self.name_p.to_pod()), ("resultOnly", self.result_only_p.to_pod()), ("assocs", self.assocs_p.to_pod()), ("methods", self.methods_p.to_pod()), ("defaults", self.defaults_p.to_pod()), ("doc", self.doc_p.to_pod())])
    }
}

impl crate::prelude::FromPod for TraitDef {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(TraitDef { name_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "name")?)?, result_only_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "resultOnly")?)?, assocs_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "assocs")?)?, methods_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "methods")?)?, defaults_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "defaults")?)?, doc_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "doc")?)? })
    }
}

/// `TyDef`:
///
/// ```prism
/// type TyDef = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct TyDef {
    pub name_p: crate::prelude::Text,
    pub prism_p: crate::prelude::Text,
    pub params_p: crate::prelude::Array<crate::prelude::Text>,
    pub keyed_p: crate::prelude::Array<crate::prelude::Text>,
    pub shape_p: TyShape,
    pub cases_p: crate::prelude::Array<CaseDef>,
    pub eq_p: bool,
    pub ord_p: bool,
    pub show_p: Shown,
    pub pod_p: bool,
    pub doc_p: crate::prelude::Text,
}

impl crate::prelude::Show for TyDef {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("TyDef", &[("name", &self.name_p), ("prism", &self.prism_p), ("params", &self.params_p), ("keyed", &self.keyed_p), ("shape", &self.shape_p), ("cases", &self.cases_p), ("eq", &self.eq_p), ("ord", &self.ord_p), ("show", &self.show_p), ("pod", &self.pod_p), ("doc", &self.doc_p)]);
    }
}

impl crate::prelude::ToPod for TyDef {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("TyDef", vec![("name", self.name_p.to_pod()), ("prism", self.prism_p.to_pod()), ("params", self.params_p.to_pod()), ("keyed", self.keyed_p.to_pod()), ("shape", self.shape_p.to_pod()), ("cases", self.cases_p.to_pod()), ("eq", self.eq_p.to_pod()), ("ord", self.ord_p.to_pod()), ("show", self.show_p.to_pod()), ("pod", self.pod_p.to_pod()), ("doc", self.doc_p.to_pod())])
    }
}

impl crate::prelude::FromPod for TyDef {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(TyDef { name_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "name")?)?, prism_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "prism")?)?, params_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "params")?)?, keyed_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "keyed")?)?, shape_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "shape")?)?, cases_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "cases")?)?, eq_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "eq")?)?, ord_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "ord")?)?, show_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "show")?)?, pod_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "pod")?)?, doc_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "doc")?)? })
    }
}

/// `TyShape`:
///
/// ```prism
/// type TyShape = choice:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub enum TyShape {
    ShapeRecord,
    ShapeChoice,
    ShapeNewtype,
    ShapeUnit,
}

impl crate::prelude::Show for TyShape {
    fn show(&self, p: &mut crate::prelude::Printer) {
        match self {
            TyShape::ShapeRecord => p.choice("ShapeRecord", &[]),
            TyShape::ShapeChoice => p.choice("ShapeChoice", &[]),
            TyShape::ShapeNewtype => p.choice("ShapeNewtype", &[]),
            TyShape::ShapeUnit => p.choice("ShapeUnit", &[]),
        }
    }
}

impl crate::prelude::ToPod for TyShape {
    fn to_pod(&self) -> crate::prelude::Pod {
        match self {
            TyShape::ShapeRecord => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("ShapeRecord", 0), vec![]),
            TyShape::ShapeChoice => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("ShapeChoice", 1), vec![]),
            TyShape::ShapeNewtype => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("ShapeNewtype", 2), vec![]),
            TyShape::ShapeUnit => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("ShapeUnit", 3), vec![]),
        }
    }
}

impl crate::prelude::FromPod for TyShape {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        match p.structure() {
            crate::prelude::Pod::Choice(c, a) if &**c == "ShapeRecord" && a.len() == 0 => ::std::result::Result::Ok(TyShape::ShapeRecord),
            crate::prelude::Pod::Choice(c, a) if &**c == "ShapeChoice" && a.len() == 0 => ::std::result::Result::Ok(TyShape::ShapeChoice),
            crate::prelude::Pod::Choice(c, a) if &**c == "ShapeNewtype" && a.len() == 0 => ::std::result::Result::Ok(TyShape::ShapeNewtype),
            crate::prelude::Pod::Choice(c, a) if &**c == "ShapeUnit" && a.len() == 0 => ::std::result::Result::Ok(TyShape::ShapeUnit),
            other => ::prism_rtl::pod::mismatch("a TyShape", other),
        }
    }
}

/// `UnOp`:
///
/// ```prism
/// type UnOp = choice:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub enum UnOp {
    OpNot,
    OpNeg,
}

impl crate::prelude::Show for UnOp {
    fn show(&self, p: &mut crate::prelude::Printer) {
        match self {
            UnOp::OpNot => p.choice("OpNot", &[]),
            UnOp::OpNeg => p.choice("OpNeg", &[]),
        }
    }
}

impl crate::prelude::ToPod for UnOp {
    fn to_pod(&self) -> crate::prelude::Pod {
        match self {
            UnOp::OpNot => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("OpNot", 0), vec![]),
            UnOp::OpNeg => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("OpNeg", 1), vec![]),
        }
    }
}

impl crate::prelude::FromPod for UnOp {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        match p.structure() {
            crate::prelude::Pod::Choice(c, a) if &**c == "OpNot" && a.len() == 0 => ::std::result::Result::Ok(UnOp::OpNot),
            crate::prelude::Pod::Choice(c, a) if &**c == "OpNeg" && a.len() == 0 => ::std::result::Result::Ok(UnOp::OpNeg),
            other => ::prism_rtl::pod::mismatch("a UnOp", other),
        }
    }
}

/// `XArm`:
///
/// ```prism
/// type XArm = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct XArm {
    pub pat_p: Pa,
    pub conds_p: crate::prelude::Array<Cc>,
    pub body_p: Ex,
}

impl crate::prelude::Show for XArm {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("XArm", &[("pat", &self.pat_p), ("conds", &self.conds_p), ("body", &self.body_p)]);
    }
}

impl crate::prelude::ToPod for XArm {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("XArm", vec![("pat", self.pat_p.to_pod()), ("conds", self.conds_p.to_pod()), ("body", self.body_p.to_pod())])
    }
}

impl crate::prelude::FromPod for XArm {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(XArm { pat_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "pat")?)?, conds_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "conds")?)?, body_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "body")?)? })
    }
}

/// ```prism
/// ?RefKey: fn Ref -> ?Text
/// ```
pub fn ref_key_o(ref_0: &Ref) -> ::std::option::Option<crate::prelude::Text> {
    match ref_0 {
        Ref::RefItem(c0_0_0, p_p0, _) if (c0_0_0 == &crate::prelude::Text::lit("")) => ::std::option::Option::Some(p_p0.clone()),
        Ref::RefItem(m_p1, p_p2, _) => ::std::option::Option::Some(crate::prelude::Text::from(format!("{}::{}", m_p1, p_p2))),
        other_p3 => ::std::option::Option::None,
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// RefSpelled: fn Ref -> Text
/// ```
pub fn ref_spelled_f(ref_0: &Ref) -> crate::prelude::Text {
    match ref_0 {
        Ref::RefItem(_, _, s_p0) => s_p0.clone(),
        Ref::RefRuntime(t_p1) => t_p1.clone(),
    }
}

/// ```prism
/// RuntimePath: fn Text -> Text
/// ```
pub fn runtime_path_f(t_p0: &crate::prelude::Text) -> crate::prelude::Text {
    if crate::syntax::lexer::chars::has_prefix_f(t_p0, &crate::prelude::Text::lit("rt::")) {
        crate::prelude::Text::from(format!("crate::prelude::{}", &crate::syntax::lexer::chars::drop_prefix_f(t_p0, &crate::prelude::Text::lit("rt::"))))
    } else {
        if crate::syntax::lexer::chars::has_prefix_f(t_p0, &crate::prelude::Text::lit("prism_rtl::")) {
            crate::prelude::Text::from(format!("::{}", t_p0))
        } else {
            t_p0.clone()
        }
    }
}

/// ```prism
/// RefLast: fn Ref -> Text
/// ```
pub fn ref_last_f(ref_0: &Ref) -> crate::prelude::Text {
    match ref_0 {
        Ref::RefItem(_, p_p0, _) => crate::prelude::or(&crate::syntax::lexer::chars::last_o(&crate::prelude::split_on(p_p0, &crate::prelude::Text::lit("::"))), p_p0),
        Ref::RefRuntime(t_p1) => crate::prelude::or(&crate::syntax::lexer::chars::last_o(&crate::prelude::split_on(t_p1, &crate::prelude::Text::lit("::"))), t_p1),
    }
}

/// ```prism
/// RefChild: fn Ref, Text -> Ref
/// ```
pub fn ref_child_f(ref_0: &Ref, n_p3: &crate::prelude::Text) -> Ref {
    match ref_0 {
        Ref::RefItem(m_p0, p_p1, s_p2) => Ref::RefItem(m_p0.clone(), crate::prelude::Text::from(format!("{}::{}", p_p1, n_p3)), crate::prelude::Text::from(format!("{}::{}", s_p2, n_p3))),
        Ref::RefRuntime(t_p4) => Ref::RefRuntime(crate::prelude::Text::from(format!("{}::{}", t_p4, n_p3))),
    }
}

/// ```prism
/// RefParent: fn Ref -> Ref
/// ```
pub fn ref_parent_f(ref_0: &Ref) -> Ref {
    match ref_0 {
        Ref::RefItem(m_p0, p_p1, s_p2) => Ref::RefItem(m_p0.clone(), drop_last_segment_f(p_p1), drop_last_segment_f(s_p2)),
        Ref::RefRuntime(t_p3) => Ref::RefRuntime(drop_last_segment_f(t_p3)),
    }
}

/// ```prism
/// DropLastSegment: fn Text -> Text
/// ```
pub fn drop_last_segment_f(p_p0: &crate::prelude::Text) -> crate::prelude::Text {
    let segs_p1 = crate::prelude::split_on(p_p0, &crate::prelude::Text::lit("::"));
    crate::syntax::lexer::chars::join_f(&crate::prelude::take(&segs_p1, &crate::syntax::lexer::chars::dec_f(&crate::prelude::len(&segs_p1))), &crate::prelude::Text::lit("::"))
}

/// ```prism
/// let elemRef
/// ```
pub fn elem_ref_p() -> Ref {
    Ref::RefItem(crate::prelude::Text::lit(""), crate::prelude::Text::lit("Elem"), crate::prelude::Text::lit("crate::Elem"))
}

/// ```prism
/// let answerRef
/// ```
pub fn answer_ref_p() -> Ref {
    Ref::RefItem(crate::prelude::Text::lit(""), crate::prelude::Text::lit("Answer"), crate::prelude::Text::lit("crate::Answer"))
}

/// ```prism
/// let untaggedRef
/// ```
pub fn untagged_ref_p() -> Ref {
    ref_child_f(&answer_ref_p(), &crate::prelude::Text::lit("Untagged_a"))
}

/// ```prism
/// BinOpText: fn BinOp -> Text
/// ```
pub fn bin_op_text_f(bin_op0: &BinOp) -> crate::prelude::Text {
    match bin_op0 {
        BinOp::OpAdd => crate::prelude::Text::lit("+"),
        BinOp::OpSub => crate::prelude::Text::lit("-"),
        BinOp::OpMul => crate::prelude::Text::lit("*"),
        BinOp::OpDiv => crate::prelude::Text::lit("/"),
        BinOp::OpEq => crate::prelude::Text::lit("=="),
        BinOp::OpNe => crate::prelude::Text::lit("!="),
        BinOp::OpLt => crate::prelude::Text::lit("<"),
        BinOp::OpLe => crate::prelude::Text::lit("<="),
        BinOp::OpGt => crate::prelude::Text::lit(">"),
        BinOp::OpGe => crate::prelude::Text::lit(">="),
        BinOp::OpAnd => crate::prelude::Text::lit("&&"),
        BinOp::OpOr => crate::prelude::Text::lit("||"),
    }
}

/// ```prism
/// UnOpText: fn UnOp -> Text
/// ```
pub fn un_op_text_f(un_op0: &UnOp) -> crate::prelude::Text {
    match un_op0 {
        UnOp::OpNot => crate::prelude::Text::lit("!"),
        UnOp::OpNeg => crate::prelude::Text::lit("-"),
    }
}

/// ```prism
/// ?BinOpOf: fn Text -> ?BinOp
/// ```
pub fn bin_op_of_o(text0: &crate::prelude::Text) -> ::std::option::Option<BinOp> {
    match text0 {
        c0_0 if (c0_0 == &crate::prelude::Text::lit("+")) => ::std::option::Option::Some(BinOp::OpAdd),
        c1_0 if (c1_0 == &crate::prelude::Text::lit("-")) => ::std::option::Option::Some(BinOp::OpSub),
        c2_0 if (c2_0 == &crate::prelude::Text::lit("*")) => ::std::option::Option::Some(BinOp::OpMul),
        c3_0 if (c3_0 == &crate::prelude::Text::lit("/")) => ::std::option::Option::Some(BinOp::OpDiv),
        c4_0 if (c4_0 == &crate::prelude::Text::lit("==")) => ::std::option::Option::Some(BinOp::OpEq),
        c5_0 if (c5_0 == &crate::prelude::Text::lit("!=")) => ::std::option::Option::Some(BinOp::OpNe),
        c6_0 if (c6_0 == &crate::prelude::Text::lit("<")) => ::std::option::Option::Some(BinOp::OpLt),
        c7_0 if (c7_0 == &crate::prelude::Text::lit("<=")) => ::std::option::Option::Some(BinOp::OpLe),
        c8_0 if (c8_0 == &crate::prelude::Text::lit(">")) => ::std::option::Option::Some(BinOp::OpGt),
        c9_0 if (c9_0 == &crate::prelude::Text::lit(">=")) => ::std::option::Option::Some(BinOp::OpGe),
        _ => ::std::option::Option::None,
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// let pos0
/// ```
pub fn pos0_p() -> Pos {
    Pos { scope_p: crate::prelude::Nat::from(0u32), at_p: crate::prelude::Nat::from(0u32) }
}

/// ```prism
/// NextPos: fn Pos -> Pos
/// ```
pub fn next_pos_f(p_p0: &Pos) -> Pos {
    let mut this: Pos = p_p0.clone();
    this.at_p = &this.at_p + &crate::prelude::Nat::from(1u32);
    this
}

/// ```prism
/// ScopePos: fn Nat -> Pos
/// ```
pub fn scope_pos_f(k_p0: &crate::prelude::Nat) -> Pos {
    Pos { scope_p: k_p0.clone(), at_p: crate::prelude::Nat::from(0u32) }
}

/// ```prism
/// PlaceText: fn Pos -> Text
/// ```
pub fn place_text_f(p_p0: &Pos) -> crate::prelude::Text {
    if &p_p0.scope_p == &crate::prelude::Nat::from(0u32) {
        crate::prelude::Text::from(format!("{}", &p_p0.at_p))
    } else {
        crate::prelude::Text::from(format!("h{}_{}", &p_p0.scope_p, &p_p0.at_p))
    }
}

/// ```prism
/// ExReads: unbounded fn Ex, Text -> Bool
/// ```
pub fn ex_reads_f(x_p0: &Ex, n_p1: &crate::prelude::Text) -> bool {
    match x_p0 {
        Ex::XVar(m_p2) => m_p2 == n_p1,
        Ex::XRef(y_p3) => ex_reads_f(&**y_p3, n_p1),
        Ex::XRefMut(y_p4) => ex_reads_f(&**y_p4, n_p1),
        Ex::XDeref(y_p5) => ex_reads_f(&**y_p5, n_p1),
        Ex::XTarget(y_p6) => ex_reads_f(&**y_p6, n_p1),
        Ex::XClone(y_p7) => ex_reads_f(&**y_p7, n_p1),
        Ex::XWeak(y_p8) => ex_reads_f(&**y_p8, n_p1),
        Ex::XUpgrade(y_p9) => ex_reads_f(&**y_p9, n_p1),
        Ex::XBreak(_, y_pa) => ex_reads_f(&**y_pa, n_p1),
        Ex::XLater(y_pb) => ex_reads_f(&**y_pb, n_p1),
        Ex::XFormatStr(ys_pc) => any_reads_f(ys_pc, n_p1),
        Ex::XIsCase(y_pd, _) => ex_reads_f(&**y_pd, n_p1),
        Ex::XCall(_, ys_pe) => any_reads_f(ys_pe, n_p1),
        Ex::XCallAt(_, _, ys_pf) => any_reads_f(ys_pf, n_p1),
        Ex::XCallSelf(_, _, _, ys_pg) => any_reads_f(ys_pg, n_p1),
        Ex::XApply(f_ph, ys_pi) => ex_reads_f(&**f_ph, n_p1) || any_reads_f(ys_pi, n_p1),
        Ex::XMethod(y_pj, _, ys_pk) => ex_reads_f(&**y_pj, n_p1) || any_reads_f(ys_pk, n_p1),
        Ex::XBin(_, a_pl, b_pm) => ex_reads_f(&**a_pl, n_p1) || ex_reads_f(&**b_pm, n_p1),
        Ex::XUnary(_, y_pn) => ex_reads_f(&**y_pn, n_p1),
        Ex::XCtor(_, ys_po) => any_reads_f(ys_po, n_p1),
        Ex::XRecord(_, fs_pp) => crate::prelude::run_to_end(crate::prelude::fold_job(fs_pp.clone(), false, {
            let n_p1x = n_p1.clone();
            ::std::rc::Rc::new(move |(p0, p1): (bool, (crate::prelude::Text, Ex))| {
                let n_p1xy = n_p1x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let f_pq = p0;
                    let (_, y_pr) = p1;
                    if f_pq {
                        ::prism_rtl::Turn::Finished(true)
                    } else {
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(ExReads { x_p0: y_pr.clone(), n_p1: n_p1xy.clone() }))
                    }
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, (crate::prelude::Text, Ex))) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
        })),
        Ex::XTuple(ys_ps) => any_reads_f(ys_ps, n_p1),
        Ex::XVec(ys_pt) => any_reads_f(ys_pt, n_p1),
        Ex::XFormat(ys_pu) => any_reads_f(ys_pu, n_p1),
        Ex::XMatch(y_pv, arms_p10, _, _) => ex_reads_f(&**y_pv, n_p1) || arms_read_f(arms_p10, n_p1),
        Ex::XChain(_, y_p11, arms_p12, _) => ex_reads_f(&**y_p11, n_p1) || arms_read_f(arms_p12, n_p1),
        Ex::XIf(c_p13, a_p14, b_p15) => (ex_reads_f(&**c_p13, n_p1) || ex_reads_f(&**a_p14, n_p1)) || ex_reads_f(&**b_p15, n_p1),
        Ex::XBlock(ds_p16, y_p17) => dos_read_f(ds_p16, n_p1) || ex_reads_f(&**y_p17, n_p1),
        Ex::XLabeled(_, ds_p18, y_p19, _) => dos_read_f(ds_p18, n_p1) || ex_reads_f(&**y_p19, n_p1),
        Ex::XClosure(_, _, y_p1a) => ex_reads_f(&**y_p1a, n_p1),
        Ex::XTry(y_p1b) => ex_reads_f(&**y_p1b, n_p1),
        Ex::XField(y_p1c, _) => ex_reads_f(&**y_p1c, n_p1),
        Ex::XFieldOf(y_p1d, _, _) => ex_reads_f(&**y_p1d, n_p1),
        Ex::XPart(y_p1e, _) => ex_reads_f(&**y_p1e, n_p1),
        Ex::XDecode(_, y_p1f) => ex_reads_f(&**y_p1f, n_p1),
        Ex::XCast(y_p1g, _) => ex_reads_f(&**y_p1g, n_p1),
        Ex::XTyped(y_p1h, _) => ex_reads_f(&**y_p1h, n_p1),
        _ => false,
    }
}

/// The step machine of `ExReads`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ExReads: unbounded fn Ex, Text -> Bool
/// ```
pub struct ExReads {
    pub x_p0: Ex,
    pub n_p1: crate::prelude::Text,
}

impl ::prism_rtl::Job<bool> for ExReads {
    fn cycle(&self) -> ::prism_rtl::Turn<bool> {
        let x_p0 = &self.x_p0;
        let n_p1 = &self.n_p1;
        match x_p0 {
            Ex::XVar(m_p2) => ::prism_rtl::Turn::Finished(m_p2 == n_p1),
            Ex::XRef(y_p3) => ::prism_rtl::Turn::More(::std::rc::Rc::new(ExReads { x_p0: (**y_p3).clone(), n_p1: n_p1.clone() })),
            Ex::XRefMut(y_p4) => ::prism_rtl::Turn::More(::std::rc::Rc::new(ExReads { x_p0: (**y_p4).clone(), n_p1: n_p1.clone() })),
            Ex::XDeref(y_p5) => ::prism_rtl::Turn::More(::std::rc::Rc::new(ExReads { x_p0: (**y_p5).clone(), n_p1: n_p1.clone() })),
            Ex::XTarget(y_p6) => ::prism_rtl::Turn::More(::std::rc::Rc::new(ExReads { x_p0: (**y_p6).clone(), n_p1: n_p1.clone() })),
            Ex::XClone(y_p7) => ::prism_rtl::Turn::More(::std::rc::Rc::new(ExReads { x_p0: (**y_p7).clone(), n_p1: n_p1.clone() })),
            Ex::XWeak(y_p8) => ::prism_rtl::Turn::More(::std::rc::Rc::new(ExReads { x_p0: (**y_p8).clone(), n_p1: n_p1.clone() })),
            Ex::XUpgrade(y_p9) => ::prism_rtl::Turn::More(::std::rc::Rc::new(ExReads { x_p0: (**y_p9).clone(), n_p1: n_p1.clone() })),
            Ex::XBreak(_, y_pa) => ::prism_rtl::Turn::More(::std::rc::Rc::new(ExReads { x_p0: (**y_pa).clone(), n_p1: n_p1.clone() })),
            Ex::XLater(y_pb) => ::prism_rtl::Turn::More(::std::rc::Rc::new(ExReads { x_p0: (**y_pb).clone(), n_p1: n_p1.clone() })),
            Ex::XFormatStr(ys_pc) => ::prism_rtl::Turn::More(::std::rc::Rc::new(AnyReads { xs_p0: ys_pc.clone(), n_p1: n_p1.clone() })),
            Ex::XIsCase(y_pd, _) => ::prism_rtl::Turn::More(::std::rc::Rc::new(ExReads { x_p0: (**y_pd).clone(), n_p1: n_p1.clone() })),
            Ex::XCall(_, ys_pe) => ::prism_rtl::Turn::More(::std::rc::Rc::new(AnyReads { xs_p0: ys_pe.clone(), n_p1: n_p1.clone() })),
            Ex::XCallAt(_, _, ys_pf) => ::prism_rtl::Turn::More(::std::rc::Rc::new(AnyReads { xs_p0: ys_pf.clone(), n_p1: n_p1.clone() })),
            Ex::XCallSelf(_, _, _, ys_pg) => ::prism_rtl::Turn::More(::std::rc::Rc::new(AnyReads { xs_p0: ys_pg.clone(), n_p1: n_p1.clone() })),
            Ex::XApply(f_ph, ys_pi) => {
                let f_phx = (**f_ph).clone();
                let n_p1x = n_p1.clone();
                let ys_pix = ys_pi.clone();
                crate::prelude::call_then(start_ex_reads_f(f_phx.clone(), n_p1x.clone()), move |ex_reads_f_28256: bool| if ex_reads_f_28256 {
                    ::prism_rtl::Turn::Finished(true)
                } else {
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(AnyReads { xs_p0: ys_pix.clone(), n_p1: n_p1x.clone() }))
                })
            },
            Ex::XMethod(y_pj, _, ys_pk) => {
                let n_p1x = n_p1.clone();
                let y_pjx = (**y_pj).clone();
                let ys_pkx = ys_pk.clone();
                crate::prelude::call_then(start_ex_reads_f(y_pjx.clone(), n_p1x.clone()), move |ex_reads_f_28316: bool| if ex_reads_f_28316 {
                    ::prism_rtl::Turn::Finished(true)
                } else {
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(AnyReads { xs_p0: ys_pkx.clone(), n_p1: n_p1x.clone() }))
                })
            },
            Ex::XBin(_, a_pl, b_pm) => {
                let a_plx = (**a_pl).clone();
                let b_pmx = (**b_pm).clone();
                let n_p1x = n_p1.clone();
                crate::prelude::call_then(start_ex_reads_f(a_plx.clone(), n_p1x.clone()), move |ex_reads_f_28372: bool| if ex_reads_f_28372 {
                    ::prism_rtl::Turn::Finished(true)
                } else {
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(ExReads { x_p0: b_pmx.clone(), n_p1: n_p1x.clone() }))
                })
            },
            Ex::XUnary(_, y_pn) => ::prism_rtl::Turn::More(::std::rc::Rc::new(ExReads { x_p0: (**y_pn).clone(), n_p1: n_p1.clone() })),
            Ex::XCtor(_, ys_po) => ::prism_rtl::Turn::More(::std::rc::Rc::new(AnyReads { xs_p0: ys_po.clone(), n_p1: n_p1.clone() })),
            Ex::XRecord(_, fs_pp) => crate::prelude::fold_job(fs_pp.clone(), false, {
                let n_p1x = n_p1.clone();
                ::std::rc::Rc::new(move |(p0, p1): (bool, (crate::prelude::Text, Ex))| {
                    let n_p1xy = n_p1x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let f_pq = p0;
                        let (_, y_pr) = p1;
                        if f_pq {
                            ::prism_rtl::Turn::Finished(true)
                        } else {
                            ::prism_rtl::Turn::More(::std::rc::Rc::new(ExReads { x_p0: y_pr.clone(), n_p1: n_p1xy.clone() }))
                        }
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, (crate::prelude::Text, Ex))) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
            }).cycle(),
            Ex::XTuple(ys_ps) => ::prism_rtl::Turn::More(::std::rc::Rc::new(AnyReads { xs_p0: ys_ps.clone(), n_p1: n_p1.clone() })),
            Ex::XVec(ys_pt) => ::prism_rtl::Turn::More(::std::rc::Rc::new(AnyReads { xs_p0: ys_pt.clone(), n_p1: n_p1.clone() })),
            Ex::XFormat(ys_pu) => ::prism_rtl::Turn::More(::std::rc::Rc::new(AnyReads { xs_p0: ys_pu.clone(), n_p1: n_p1.clone() })),
            Ex::XMatch(y_pv, arms_p10, _, _) => {
                let arms_p10x = arms_p10.clone();
                let n_p1x = n_p1.clone();
                let y_pvx = (**y_pv).clone();
                crate::prelude::call_then(start_ex_reads_f(y_pvx.clone(), n_p1x.clone()), move |ex_reads_f_28678: bool| if ex_reads_f_28678 {
                    ::prism_rtl::Turn::Finished(true)
                } else {
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(ArmsRead { arms_p0: arms_p10x.clone(), n_p1: n_p1x.clone() }))
                })
            },
            Ex::XChain(_, y_p11, arms_p12, _) => {
                let arms_p12x = arms_p12.clone();
                let n_p1x = n_p1.clone();
                let y_p11x = (**y_p11).clone();
                crate::prelude::call_then(start_ex_reads_f(y_p11x.clone(), n_p1x.clone()), move |ex_reads_f_28749: bool| if ex_reads_f_28749 {
                    ::prism_rtl::Turn::Finished(true)
                } else {
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(ArmsRead { arms_p0: arms_p12x.clone(), n_p1: n_p1x.clone() }))
                })
            },
            Ex::XIf(c_p13, a_p14, b_p15) => {
                let a_p14x = (**a_p14).clone();
                let b_p15x = (**b_p15).clone();
                let c_p13x = (**c_p13).clone();
                let n_p1x = n_p1.clone();
                crate::prelude::call_then(start_ex_reads_f(c_p13x.clone(), n_p1x.clone()), move |ex_reads_f_28801: bool| if ex_reads_f_28801 || ex_reads_f(&a_p14x, &n_p1x) {
                    ::prism_rtl::Turn::Finished(true)
                } else {
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(ExReads { x_p0: b_p15x.clone(), n_p1: n_p1x.clone() }))
                })
            },
            Ex::XBlock(ds_p16, y_p17) => {
                let ds_p16x = ds_p16.clone();
                let n_p1x = n_p1.clone();
                let y_p17x = (**y_p17).clone();
                crate::prelude::call_then(start_dos_read_f(ds_p16x.clone(), n_p1x.clone()), move |dos_read_f_28868: bool| if dos_read_f_28868 {
                    ::prism_rtl::Turn::Finished(true)
                } else {
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(ExReads { x_p0: y_p17x.clone(), n_p1: n_p1x.clone() }))
                })
            },
            Ex::XLabeled(_, ds_p18, y_p19, _) => {
                let ds_p18x = ds_p18.clone();
                let n_p1x = n_p1.clone();
                let y_p19x = (**y_p19).clone();
                crate::prelude::call_then(start_dos_read_f(ds_p18x.clone(), n_p1x.clone()), move |dos_read_f_28936: bool| if dos_read_f_28936 {
                    ::prism_rtl::Turn::Finished(true)
                } else {
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(ExReads { x_p0: y_p19x.clone(), n_p1: n_p1x.clone() }))
                })
            },
            Ex::XClosure(_, _, y_p1a) => ::prism_rtl::Turn::More(::std::rc::Rc::new(ExReads { x_p0: (**y_p1a).clone(), n_p1: n_p1.clone() })),
            Ex::XTry(y_p1b) => ::prism_rtl::Turn::More(::std::rc::Rc::new(ExReads { x_p0: (**y_p1b).clone(), n_p1: n_p1.clone() })),
            Ex::XField(y_p1c, _) => ::prism_rtl::Turn::More(::std::rc::Rc::new(ExReads { x_p0: (**y_p1c).clone(), n_p1: n_p1.clone() })),
            Ex::XFieldOf(y_p1d, _, _) => ::prism_rtl::Turn::More(::std::rc::Rc::new(ExReads { x_p0: (**y_p1d).clone(), n_p1: n_p1.clone() })),
            Ex::XPart(y_p1e, _) => ::prism_rtl::Turn::More(::std::rc::Rc::new(ExReads { x_p0: (**y_p1e).clone(), n_p1: n_p1.clone() })),
            Ex::XDecode(_, y_p1f) => ::prism_rtl::Turn::More(::std::rc::Rc::new(ExReads { x_p0: (**y_p1f).clone(), n_p1: n_p1.clone() })),
            Ex::XCast(y_p1g, _) => ::prism_rtl::Turn::More(::std::rc::Rc::new(ExReads { x_p0: (**y_p1g).clone(), n_p1: n_p1.clone() })),
            Ex::XTyped(y_p1h, _) => ::prism_rtl::Turn::More(::std::rc::Rc::new(ExReads { x_p0: (**y_p1h).clone(), n_p1: n_p1.clone() })),
            _ => ::prism_rtl::Turn::Finished(false),
        }
    }
}

/// `Start ExReads, x`: what the function value is when passed to `@Run`.
pub fn start_ex_reads_f(x_p0: Ex, n_p1: crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>> {
    ::std::rc::Rc::new(ExReads { x_p0, n_p1 })
}

/// ```prism
/// AnyReads: unbounded fn [Ex], Text -> Bool
/// ```
pub fn any_reads_f(xs_p0: &crate::prelude::Array<Ex>, n_p1: &crate::prelude::Text) -> bool {
    crate::prelude::run_to_end(crate::prelude::fold_job(xs_p0.clone(), false, {
        let n_p1x = n_p1.clone();
        ::std::rc::Rc::new(move |(p0, p1): (bool, Ex)| {
            let n_p1xy = n_p1x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let f_p2 = p0;
                let y_p3 = p1;
                if f_p2 {
                    ::prism_rtl::Turn::Finished(true)
                } else {
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(ExReads { x_p0: y_p3.clone(), n_p1: n_p1xy.clone() }))
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, Ex)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
    }))
}

/// The step machine of `AnyReads`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// AnyReads: unbounded fn [Ex], Text -> Bool
/// ```
pub struct AnyReads {
    pub xs_p0: crate::prelude::Array<Ex>,
    pub n_p1: crate::prelude::Text,
}

impl ::prism_rtl::Job<bool> for AnyReads {
    fn cycle(&self) -> ::prism_rtl::Turn<bool> {
        let xs_p0 = &self.xs_p0;
        let n_p1 = &self.n_p1;
        crate::prelude::fold_job(xs_p0.clone(), false, {
            let n_p1x = n_p1.clone();
            ::std::rc::Rc::new(move |(p0, p1): (bool, Ex)| {
                let n_p1xy = n_p1x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let f_p2 = p0;
                    let y_p3 = p1;
                    if f_p2 {
                        ::prism_rtl::Turn::Finished(true)
                    } else {
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(ExReads { x_p0: y_p3.clone(), n_p1: n_p1xy.clone() }))
                    }
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, Ex)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
        }).cycle()
    }
}

/// `Start AnyReads, x`: what the function value is when passed to `@Run`.
pub fn start_any_reads_f(xs_p0: crate::prelude::Array<Ex>, n_p1: crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>> {
    ::std::rc::Rc::new(AnyReads { xs_p0, n_p1 })
}

/// ```prism
/// ArmsRead: unbounded fn [XArm], Text -> Bool
/// ```
pub fn arms_read_f(arms_p0: &crate::prelude::Array<XArm>, n_p1: &crate::prelude::Text) -> bool {
    crate::prelude::run_to_end(crate::prelude::fold_job(arms_p0.clone(), false, {
        let n_p1x = n_p1.clone();
        ::std::rc::Rc::new(move |(p0, p1): (bool, XArm)| {
            let n_p1xy = n_p1x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let f_p2 = p0;
                let a_p3 = p1;
                if f_p2 || ex_reads_f(&a_p3.body_p, &n_p1xy) {
                    ::prism_rtl::Turn::Finished(true)
                } else {
                    crate::prelude::fold_job(a_p3.conds_p.clone(), false, {
                        let n_p1xyx = n_p1xy.clone();
                        ::std::rc::Rc::new(move |(p0, p1): (bool, Cc)| {
                            let n_p1xyxy = n_p1xyx.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let g_p4 = p0;
                                let c_p5 = p1;
                                if g_p4 {
                                    ::prism_rtl::Turn::Finished(true)
                                } else {
                                    match &c_p5 {
                                        Cc::CcIf(y_p6) => ::prism_rtl::Turn::More(::std::rc::Rc::new(ExReads { x_p0: y_p6.clone(), n_p1: n_p1xyxy.clone() })),
                                        Cc::CcLet(_, y_p7) => ::prism_rtl::Turn::More(::std::rc::Rc::new(ExReads { x_p0: y_p7.clone(), n_p1: n_p1xyxy.clone() })),
                                    }
                                }
                            }))
                        }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, Cc)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
                    }).cycle()
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, XArm)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
    }))
}

/// The step machine of `ArmsRead`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ArmsRead: unbounded fn [XArm], Text -> Bool
/// ```
pub struct ArmsRead {
    pub arms_p0: crate::prelude::Array<XArm>,
    pub n_p1: crate::prelude::Text,
}

impl ::prism_rtl::Job<bool> for ArmsRead {
    fn cycle(&self) -> ::prism_rtl::Turn<bool> {
        let arms_p0 = &self.arms_p0;
        let n_p1 = &self.n_p1;
        crate::prelude::fold_job(arms_p0.clone(), false, {
            let n_p1x = n_p1.clone();
            ::std::rc::Rc::new(move |(p0, p1): (bool, XArm)| {
                let n_p1xy = n_p1x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let f_p2 = p0;
                    let a_p3 = p1;
                    if f_p2 || ex_reads_f(&a_p3.body_p, &n_p1xy) {
                        ::prism_rtl::Turn::Finished(true)
                    } else {
                        crate::prelude::fold_job(a_p3.conds_p.clone(), false, {
                            let n_p1xyx = n_p1xy.clone();
                            ::std::rc::Rc::new(move |(p0, p1): (bool, Cc)| {
                                let n_p1xyxy = n_p1xyx.clone();
                                crate::prelude::entered(crate::prelude::once_job(move || {
                                    let g_p4 = p0;
                                    let c_p5 = p1;
                                    if g_p4 {
                                        ::prism_rtl::Turn::Finished(true)
                                    } else {
                                        match &c_p5 {
                                            Cc::CcIf(y_p6) => ::prism_rtl::Turn::More(::std::rc::Rc::new(ExReads { x_p0: y_p6.clone(), n_p1: n_p1xyxy.clone() })),
                                            Cc::CcLet(_, y_p7) => ::prism_rtl::Turn::More(::std::rc::Rc::new(ExReads { x_p0: y_p7.clone(), n_p1: n_p1xyxy.clone() })),
                                        }
                                    }
                                }))
                            }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, Cc)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
                        }).cycle()
                    }
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, XArm)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
        }).cycle()
    }
}

/// `Start ArmsRead, x`: what the function value is when passed to `@Run`.
pub fn start_arms_read_f(arms_p0: crate::prelude::Array<XArm>, n_p1: crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>> {
    ::std::rc::Rc::new(ArmsRead { arms_p0, n_p1 })
}

/// ```prism
/// DosRead: unbounded fn [Do], Text -> Bool
/// ```
pub fn dos_read_f(ds_p0: &crate::prelude::Array<Do>, n_p1: &crate::prelude::Text) -> bool {
    crate::prelude::run_to_end(crate::prelude::fold_job(ds_p0.clone(), false, {
        let n_p1x = n_p1.clone();
        ::std::rc::Rc::new(move |(p0, p1): (bool, Do)| {
            let n_p1xy = n_p1x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let f_p2 = p0;
                let d_p3 = p1;
                if f_p2 {
                    ::prism_rtl::Turn::Finished(true)
                } else {
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(DoReads { d_p0: d_p3.clone(), n_p1: n_p1xy.clone() }))
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, Do)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
    }))
}

/// The step machine of `DosRead`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// DosRead: unbounded fn [Do], Text -> Bool
/// ```
pub struct DosRead {
    pub ds_p0: crate::prelude::Array<Do>,
    pub n_p1: crate::prelude::Text,
}

impl ::prism_rtl::Job<bool> for DosRead {
    fn cycle(&self) -> ::prism_rtl::Turn<bool> {
        let ds_p0 = &self.ds_p0;
        let n_p1 = &self.n_p1;
        crate::prelude::fold_job(ds_p0.clone(), false, {
            let n_p1x = n_p1.clone();
            ::std::rc::Rc::new(move |(p0, p1): (bool, Do)| {
                let n_p1xy = n_p1x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let f_p2 = p0;
                    let d_p3 = p1;
                    if f_p2 {
                        ::prism_rtl::Turn::Finished(true)
                    } else {
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(DoReads { d_p0: d_p3.clone(), n_p1: n_p1xy.clone() }))
                    }
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, Do)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
        }).cycle()
    }
}

/// `Start DosRead, x`: what the function value is when passed to `@Run`.
pub fn start_dos_read_f(ds_p0: crate::prelude::Array<Do>, n_p1: crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>> {
    ::std::rc::Rc::new(DosRead { ds_p0, n_p1 })
}

/// ```prism
/// DoReads: unbounded fn Do, Text -> Bool
/// ```
pub fn do_reads_f(d_p0: &Do, n_p1: &crate::prelude::Text) -> bool {
    match d_p0 {
        Do::DoLet(_, y_p2) => ex_reads_f(y_p2, n_p1),
        Do::DoLetElse(_, y_p3, z_p4) => ex_reads_f(y_p3, n_p1) || ex_reads_f(z_p4, n_p1),
        Do::DoAssign(a_p5, b_p6) => ex_reads_f(a_p5, n_p1) || ex_reads_f(b_p6, n_p1),
        Do::DoWhile(c_p7, ds_p8) => ex_reads_f(c_p7, n_p1) || dos_read_f(ds_p8, n_p1),
        Do::DoWhileLet(_, y_p9, ds_pa) => ex_reads_f(y_p9, n_p1) || dos_read_f(ds_pa, n_p1),
        Do::DoFor(_, y_pb, ds_pc) => ex_reads_f(y_pb, n_p1) || dos_read_f(ds_pc, n_p1),
        Do::DoExpr(y_pd) => ex_reads_f(y_pd, n_p1),
        Do::DoIf(c_pe, a_pf, b_pg) => (ex_reads_f(c_pe, n_p1) || dos_read_f(a_pf, n_p1)) || dos_read_f(b_pg, n_p1),
        Do::DoIfLet(_, y_ph, a_pi, b_pj) => (ex_reads_f(y_ph, n_p1) || dos_read_f(a_pi, n_p1)) || dos_read_f(b_pj, n_p1),
        Do::DoMatch(y_pk, arms_pl) => ex_reads_f(y_pk, n_p1) || crate::prelude::run_to_end(crate::prelude::fold_job(arms_pl.clone(), false, {
            let n_p1x = n_p1.clone();
            ::std::rc::Rc::new(move |(p0, p1): (bool, (Pa, crate::prelude::Array<Do>))| {
                let n_p1xy = n_p1x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let f_pm = p0;
                    let (_, ds_pn) = p1;
                    if f_pm {
                        ::prism_rtl::Turn::Finished(true)
                    } else {
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(DosRead { ds_p0: ds_pn.clone(), n_p1: n_p1xy.clone() }))
                    }
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, (Pa, crate::prelude::Array<Do>))) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
        })),
        Do::DoReturn(y_po) => ex_reads_f(y_po, n_p1),
        Do::DoBlock(ds_pp) => dos_read_f(ds_pp, n_p1),
        Do::DoScope(ds_pq) => dos_read_f(ds_pq, n_p1),
        Do::DoLine(ds_pr) => dos_read_f(ds_pr, n_p1),
        Do::DoNote(_) => false,
    }
}

/// The step machine of `DoReads`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// DoReads: unbounded fn Do, Text -> Bool
/// ```
pub struct DoReads {
    pub d_p0: Do,
    pub n_p1: crate::prelude::Text,
}

impl ::prism_rtl::Job<bool> for DoReads {
    fn cycle(&self) -> ::prism_rtl::Turn<bool> {
        let d_p0 = &self.d_p0;
        let n_p1 = &self.n_p1;
        match d_p0 {
            Do::DoLet(_, y_p2) => ::prism_rtl::Turn::More(::std::rc::Rc::new(ExReads { x_p0: y_p2.clone(), n_p1: n_p1.clone() })),
            Do::DoLetElse(_, y_p3, z_p4) => {
                let n_p1x = n_p1.clone();
                let y_p3x = y_p3.clone();
                let z_p4x = z_p4.clone();
                crate::prelude::call_then(start_ex_reads_f(y_p3x.clone(), n_p1x.clone()), move |ex_reads_f_29838: bool| if ex_reads_f_29838 {
                    ::prism_rtl::Turn::Finished(true)
                } else {
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(ExReads { x_p0: z_p4x.clone(), n_p1: n_p1x.clone() }))
                })
            },
            Do::DoAssign(a_p5, b_p6) => {
                let a_p5x = a_p5.clone();
                let b_p6x = b_p6.clone();
                let n_p1x = n_p1.clone();
                crate::prelude::call_then(start_ex_reads_f(a_p5x.clone(), n_p1x.clone()), move |ex_reads_f_29888: bool| if ex_reads_f_29888 {
                    ::prism_rtl::Turn::Finished(true)
                } else {
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(ExReads { x_p0: b_p6x.clone(), n_p1: n_p1x.clone() }))
                })
            },
            Do::DoWhile(c_p7, ds_p8) => {
                let c_p7x = c_p7.clone();
                let ds_p8x = ds_p8.clone();
                let n_p1x = n_p1.clone();
                crate::prelude::call_then(start_ex_reads_f(c_p7x.clone(), n_p1x.clone()), move |ex_reads_f_29938: bool| if ex_reads_f_29938 {
                    ::prism_rtl::Turn::Finished(true)
                } else {
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(DosRead { ds_p0: ds_p8x.clone(), n_p1: n_p1x.clone() }))
                })
            },
            Do::DoWhileLet(_, y_p9, ds_pa) => {
                let ds_pax = ds_pa.clone();
                let n_p1x = n_p1.clone();
                let y_p9x = y_p9.clone();
                crate::prelude::call_then(start_ex_reads_f(y_p9x.clone(), n_p1x.clone()), move |ex_reads_f_30000: bool| if ex_reads_f_30000 {
                    ::prism_rtl::Turn::Finished(true)
                } else {
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(DosRead { ds_p0: ds_pax.clone(), n_p1: n_p1x.clone() }))
                })
            },
            Do::DoFor(_, y_pb, ds_pc) => {
                let ds_pcx = ds_pc.clone();
                let n_p1x = n_p1.clone();
                let y_pbx = y_pb.clone();
                crate::prelude::call_then(start_ex_reads_f(y_pbx.clone(), n_p1x.clone()), move |ex_reads_f_30057: bool| if ex_reads_f_30057 {
                    ::prism_rtl::Turn::Finished(true)
                } else {
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(DosRead { ds_p0: ds_pcx.clone(), n_p1: n_p1x.clone() }))
                })
            },
            Do::DoExpr(y_pd) => ::prism_rtl::Turn::More(::std::rc::Rc::new(ExReads { x_p0: y_pd.clone(), n_p1: n_p1.clone() })),
            Do::DoIf(c_pe, a_pf, b_pg) => {
                let a_pfx = a_pf.clone();
                let b_pgx = b_pg.clone();
                let c_pex = c_pe.clone();
                let n_p1x = n_p1.clone();
                crate::prelude::call_then(start_ex_reads_f(c_pex.clone(), n_p1x.clone()), move |ex_reads_f_30134: bool| if ex_reads_f_30134 || dos_read_f(&a_pfx, &n_p1x) {
                    ::prism_rtl::Turn::Finished(true)
                } else {
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(DosRead { ds_p0: b_pgx.clone(), n_p1: n_p1x.clone() }))
                })
            },
            Do::DoIfLet(_, y_ph, a_pi, b_pj) => {
                let a_pix = a_pi.clone();
                let b_pjx = b_pj.clone();
                let n_p1x = n_p1.clone();
                let y_phx = y_ph.clone();
                crate::prelude::call_then(start_ex_reads_f(y_phx.clone(), n_p1x.clone()), move |ex_reads_f_30212: bool| if ex_reads_f_30212 || dos_read_f(&a_pix, &n_p1x) {
                    ::prism_rtl::Turn::Finished(true)
                } else {
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(DosRead { ds_p0: b_pjx.clone(), n_p1: n_p1x.clone() }))
                })
            },
            Do::DoMatch(y_pk, arms_pl) => {
                let arms_plx = arms_pl.clone();
                let n_p1x = n_p1.clone();
                let y_pkx = y_pk.clone();
                crate::prelude::call_then(start_ex_reads_f(y_pkx.clone(), n_p1x.clone()), move |ex_reads_f_30282: bool| if ex_reads_f_30282 {
                    ::prism_rtl::Turn::Finished(true)
                } else {
                    crate::prelude::fold_job(arms_plx.clone(), false, {
                        let n_p1xx = n_p1x.clone();
                        ::std::rc::Rc::new(move |(p0, p1): (bool, (Pa, crate::prelude::Array<Do>))| {
                            let n_p1xxy = n_p1xx.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let f_pm = p0;
                                let (_, ds_pn) = p1;
                                if f_pm {
                                    ::prism_rtl::Turn::Finished(true)
                                } else {
                                    ::prism_rtl::Turn::More(::std::rc::Rc::new(DosRead { ds_p0: ds_pn.clone(), n_p1: n_p1xxy.clone() }))
                                }
                            }))
                        }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, (Pa, crate::prelude::Array<Do>))) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
                    }).cycle()
                })
            },
            Do::DoReturn(y_po) => ::prism_rtl::Turn::More(::std::rc::Rc::new(ExReads { x_p0: y_po.clone(), n_p1: n_p1.clone() })),
            Do::DoBlock(ds_pp) => ::prism_rtl::Turn::More(::std::rc::Rc::new(DosRead { ds_p0: ds_pp.clone(), n_p1: n_p1.clone() })),
            Do::DoScope(ds_pq) => ::prism_rtl::Turn::More(::std::rc::Rc::new(DosRead { ds_p0: ds_pq.clone(), n_p1: n_p1.clone() })),
            Do::DoLine(ds_pr) => ::prism_rtl::Turn::More(::std::rc::Rc::new(DosRead { ds_p0: ds_pr.clone(), n_p1: n_p1.clone() })),
            Do::DoNote(_) => ::prism_rtl::Turn::Finished(false),
        }
    }
}

/// `Start DoReads, x`: what the function value is when passed to `@Run`.
pub fn start_do_reads_f(d_p0: Do, n_p1: crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>> {
    ::std::rc::Rc::new(DoReads { d_p0, n_p1 })
}
