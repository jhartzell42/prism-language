//! The module `Lower.Program`, from `target/bootstrap/src/prismc/lower/program.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// ```prism
/// InModule: fn Lx, Nat, Text -> Lx
/// ```
pub fn in_module_f(lx_p0: &crate::lower::Lx, file_p1: &Nat, home_p2: &Text) -> crate::lower::Lx {
    let mut this: crate::lower::Lx = lx_p0.clone();
    this.file_p = file_p1.clone();
    this.home_p = home_p2.clone();
    this.site_p = home_p2.clone();
    this
}

/// ```prism
/// InModuleAt: fn Lx, Nat, Text, Text -> Lx
/// ```
pub fn in_module_at_f(lx_p0: &crate::lower::Lx, file_p1: &Nat, home_p2: &Text, site_p3: &Text) -> crate::lower::Lx {
    let mut this: crate::lower::Lx = lx_p0.clone();
    this.file_p = file_p1.clone();
    this.home_p = home_p2.clone();
    this.site_p = site_p3.clone();
    this
}

/// ```prism
/// LowerProgram: unbounded fn [Src], [Module], Nat, TProgram, Text -> Model
/// ```
pub fn lower_program_f(srcs_p0: &Array<crate::check::errors::Src>, trees_p1: &Array<crate::syntax::Module>, shown_p2: &Nat, tp_p3: &crate::check::typed::TProgram, name_p4: &Text) -> crate::lower::model::Model {
    let (g_pt, _) = crate::check::env::build_g_f(srcs_p0, trees_p1);
    let (tys_pu, apps_pv, bs_p10, ims_p11) = crate::lower::typed_tables_f(tp_p3);
    let gens_p5 = crate::prelude::fold(&tp_p3.gens_p, &Map::new(), &(|m_p12: &Map<Text, crate::check::typed::GenNote>, n_p13: &crate::check::typed::GenNote| crate::prelude::insert(m_p12, &crate::check::typed::at_key_f(&n_p13.at_p), n_p13)));
    let insts_p6 = crate::prelude::fold(&tp_p3.insts_p, &Map::new(), &(|m_p14: &Map<Text, Array<crate::check::typed::InstNote>>, n_p15: &crate::check::typed::InstNote| crate::prelude::insert(m_p14, &crate::lower::expr::inst_key_f(n_p15), &crate::prelude::push(&crate::prelude::or(&crate::prelude::get(m_p14, &crate::lower::expr::inst_key_f(n_p15)), &Array::new()), n_p15))));
    let quants_p7 = crate::prelude::fold(&tp_p3.gens_p, &Map::new(), &(|m_p16: &Map<Text, Text>, n_p17: &crate::check::typed::GenNote| crate::prelude::fold(&crate::prelude::append(&n_p17.tys_p, &n_p17.cols_p), m_p16, &(|m2_p18: &Map<Text, Text>, q_p19: &Text| crate::prelude::insert(m2_p18, q_p19, &n_p17.name_p)))));
    let gen_of_q_p8 = crate::prelude::fold(&tp_p3.gens_p, &Map::new(), &(|m_p1a: &Map<Text, crate::check::typed::GenNote>, n_p1b: &crate::check::typed::GenNote| crate::prelude::fold(&crate::prelude::append(&n_p1b.tys_p, &n_p1b.cols_p), m_p1a, &(|m2_p1c: &Map<Text, crate::check::typed::GenNote>, q_p1d: &Text| crate::prelude::insert(m2_p1c, q_p1d, n_p1b)))));
    let use_insts_p9 = crate::prelude::fold(&tp_p3.insts_p, &Map::new(), &(|m_p1e: &Map<Text, crate::check::typed::InstNote>, n_p1f: &crate::check::typed::InstNote| crate::prelude::insert(m_p1e, &crate::check::typed::at_key_f(&n_p1f.at_p), n_p1f)));
    let mods_pa = needed_mods_f(&g_pt, shown_p2);
    let rs_mods_pb = crate::prelude::fold(&mods_pa, &Map::new(), &(|acc_p1g: &Map<Text, Text>, m_p1h: &Text| crate::prelude::insert(acc_p1g, m_p1h, &crate::lower::rust_mod_name_f(m_p1h))));
    let mod_segments_pc = crate::prelude::fold(&crate::prelude::values(&rs_mods_pb), &Map::new(), &(|acc_p1i: &Map<Text, bool>, p_p1j: &Text| crate::prelude::fold(&crate::prelude::split_on(p_p1j, &Text::lit("::")), acc_p1i, &(|a2_p1k: &Map<Text, bool>, seg_p1l: &Text| crate::prelude::insert(a2_p1k, seg_p1l, &true)))));
    let lx0_pd = crate::lower::Lx { g_p: g_pt.clone(), tys_p: tys_pu.clone(), apps_p: apps_pv.clone(), lifts_p: crate::prelude::fold(&tp_p3.lifts_p, &Map::new(), &(|m_p1m: &Map<Text, crate::check::typed::LiftNote>, n_p1n: &crate::check::typed::LiftNote| crate::prelude::insert(m_p1m, &crate::check::typed::at_key_f(&n_p1n.at_p), n_p1n))), binders_p: bs_p10.clone(), impls_p: ims_p11.clone(), file_p: Nat::from(0u32), home_p: Text::lit(""), site_p: Text::lit(""), rs_mods_p: rs_mods_pb.clone(), mod_segments_p: mod_segments_pc.clone(), rs_names_p: crate::lower::value_names_f(&g_pt), layouts_p: crate::lower::types::layouts_f(&g_pt), unbs_p: Array::new(), notes_p: Array::new(), globals_p: crate::lower::global_names_f(&g_pt), in_node_p: false, unshrunk_p: crate::prelude::fold(&tp_p3.unshrunk_p, &Map::new(), &(|m_p1o: &Map<Text, bool>, a_p1p: &crate::check::typed::SrcAt| crate::prelude::insert(m_p1o, &crate::check::typed::at_key_f(a_p1p), &true))), gens_p: gens_p5.clone(), insts_p: insts_p6.clone(), quants_p: quants_p7.clone(), gen_of_q_p: gen_of_q_p8.clone(), use_insts_p: use_insts_p9.clone(), local_ids_p: crate::prelude::fold(&tp_p3.locals_p, &Map::new(), &(|m_p1q: &Map<Text, Nat>, n_p1r: &crate::check::typed::LocalNote| crate::prelude::insert(m_p1q, &crate::check::typed::at_key_f(&n_p1r.at_p), &n_p1r.id_p))), use_ids_p: crate::prelude::fold(&tp_p3.uses_p, &Map::new(), &(|m_p1s: &Map<Text, Nat>, n_p1t: &crate::check::typed::LocalNote| crate::prelude::insert(m_p1s, &crate::check::typed::at_key_f(&n_p1t.at_p), &n_p1t.id_p))), call_ids_p: crate::prelude::fold(&tp_p3.calls_p, &Map::new(), &(|m_p1u: &Map<Text, Nat>, n_p1v: &crate::check::typed::LocalNote| crate::prelude::insert(m_p1u, &crate::check::typed::at_key_f(&n_p1v.at_p), &n_p1v.id_p))), inlined_p: Text::lit(""), subst_p: Map::new(), csubst_p: Map::new() };
    let lx_pe = {
        let mut this: crate::lower::Lx = lx0_pd.clone();
        this.unbs_p = job_roots_f(&lx0_pd);
        this
    };
    let roots_pf = root_widgets_f(&lx_pe);
    let mod_defs_pg = crate::prelude::run_to_end(crate::prelude::each_job(mods_pa.clone(), {
        let lx_pex = lx_pe.clone();
        let roots_pfx = roots_pf.clone();
        let g_ptx = g_pt.clone();
        let mods_pax = mods_pa.clone();
        Rc::new(move |p0: Text| {
            let lx_pexy = lx_pex.clone();
            let roots_pfxy = roots_pfx.clone();
            let g_ptxy = g_ptx.clone();
            let mods_paxy = mods_pax.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let m_p20 = p0;
                prism_rtl::Turn::More(Rc::new(ModDefOf { lx0_p0: lx_pexy.clone(), m_p1: m_p20.clone(), roots_p2: roots_pfxy.clone(), info_p3: crate::prelude::or(&crate::prelude::get(&g_ptxy.mods_p, &m_p20), &crate::check::env::reading::dummy_mod_p()), mods_p4: mods_paxy.clone() }))
            }))
        }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<crate::lower::model::ModDef>>>
    }));
    let programs_ph = crate::prelude::run_to_end(crate::prelude::each_job(roots_pf.clone(), {
        let lx_pex = lx_pe.clone();
        Rc::new(move |p0: (Text, bool)| {
            let lx_pexy = lx_pex.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (qk_p21, _) = p0;
                prism_rtl::Turn::More(Rc::new(ProgDefOf { lx_p0: lx_pexy.clone(), qk_p1: qk_p21.clone() }))
            }))
        }) as Rc<dyn Fn((Text, bool)) -> Rc<dyn prism_rtl::Job<crate::lower::model::ProgDef>>>
    }));
    let main_qk_pi = crate::prelude::fold(&g_pt.defs_p, &Text::lit(""), &(|found_p22: &Text, d_p23: &crate::check::env::Def| if (found_p22 == &Text::lit("")) && is_main_f(&d_p23.qk_p) {
        d_p23.qk_p.clone()
    } else {
        found_p22.clone()
    }));
    let root_oj = if &main_qk_pi == &Text::lit("") {
        None
    } else {
        Some(prog_def_of_f(&lx_pe, &main_qk_pi))
    };
    let checks_pk = crate::prelude::run_to_end(crate::prelude::fold_job(g_pt.defs_p.clone(), Array::new(), {
        let lx_pex = lx_pe.clone();
        Rc::new(move |(p0, p1): (Array<crate::lower::model::CheckDef>, crate::check::env::Def)| {
            let lx_pexy = lx_pex.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_p24 = p0;
                let d_p25 = p1;
                match &d_p25.body_p {
                    crate::check::env::DefBody::DbCheck(c_p26) => {
                        let c_p26x = c_p26.clone();
                        crate::prelude::call_then(start_check_def_of_f(in_module_at_f(&lx_pexy, &d_p25.file_p, &d_p25.home_p, &Text::lit("\0main")), c_p26x.clone()), move |check_def_of_f_3830: crate::lower::model::CheckDef| prism_rtl::Turn::Finished(crate::prelude::push(&acc_p24, &check_def_of_f_3830)))
                    },
                    _ => prism_rtl::Turn::Finished(acc_p24.clone()),
                }
            }))
        }) as Rc<dyn Fn((Array<crate::lower::model::CheckDef>, crate::check::env::Def)) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::CheckDef>>>>
    }));
    let with_needs_pl = with_groups_f(&with_needs_f(&g_pt, srcs_p0, tp_p3, &mod_defs_pg));
    let elem_pm = elem_row_f(&lx_pe, &mods_pa);
    let answer_pn = answer_enum_f(&in_module_at_f(&lx_pe, &Nat::from(0u32), &Text::lit(""), &Text::lit("\0main")), &mods_pa);
    let names_po = crate::prelude::each(&with_needs_pl, &(|d_p27: &crate::lower::model::ModDef| d_p27.name_p.clone()));
    let value_tys_pp = value_types_f(&with_needs_pl);
    let elem_held_pq = crate::prelude::fold(&elem_pm.cases_p, &Array::new(), &(|acc_p28: &Array<Text>, (_, sp_p29): &(Text, Text)| crate::check::types::union_texts_f(acc_p28, &held_in_f(&names_po, &value_tys_pp, &Text::lit(""), &crate::lower::model::OutTy::OutNamed(sp_p29.clone(), Array::new())))));
    let answer_held_pr = crate::prelude::fold(&answer_pn.cases_p, &elem_held_pq, &(|acc_p2a: &Array<Text>, k_p2b: &crate::lower::model::AnswerCase| crate::check::types::union_texts_f(acc_p2a, &held_in_f(&names_po, &value_tys_pp, &Text::lit(""), &k_p2b.ty_p))));
    let answer_named_ps = crate::prelude::fold(&answer_pn.cases_p, &Array::new(), &(|acc_p2c: &Array<Text>, k_p2d: &crate::lower::model::AnswerCase| crate::check::types::union_texts_f(acc_p2c, &named_in_f(&names_po, &Text::lit(""), &k_p2d.ty_p))));
    crate::lower::model::Model { name_p: name_p4.clone(), mods_p: with_needs_pl.clone(), programs_p: programs_ph.clone(), root_o: root_oj.clone(), checks_p: checks_pk.clone(), elem_p: elem_pm.clone(), answer_p: answer_pn.clone(), elem_complete_p: answer_held_pr.clone(), elem_declared_p: crate::check::types::minus_texts_f(&answer_named_ps, &answer_held_pr), scripts_p: Array::new(), notes_p: Array::new() }
}

/// The step machine of `LowerProgram`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LowerProgram: unbounded fn [Src], [Module], Nat, TProgram, Text -> Model
/// ```
pub struct LowerProgram {
    pub srcs_p0: Array<crate::check::errors::Src>,
    pub trees_p1: Array<crate::syntax::Module>,
    pub shown_p2: Nat,
    pub tp_p3: crate::check::typed::TProgram,
    pub name_p4: Text,
}

impl prism_rtl::Job<crate::lower::model::Model> for LowerProgram {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::Model> {
        let srcs_p0 = &self.srcs_p0;
        let trees_p1 = &self.trees_p1;
        let shown_p2 = &self.shown_p2;
        let tp_p3 = &self.tp_p3;
        let name_p4 = &self.name_p4;
        let name_p4x = name_p4.clone();
        let shown_p2x = shown_p2.clone();
        let srcs_p0x = srcs_p0.clone();
        let tp_p3x = tp_p3.clone();
        let trees_p1x = trees_p1.clone();
        crate::prelude::call_then(crate::check::env::start_build_g_f(srcs_p0x.clone(), trees_p1x.clone()), move |build_g_f_1920: (crate::check::env::G, crate::check::types::St)| {
            let (g_pt, _) = build_g_f_1920;
            let (tys_pu, apps_pv, bs_p10, ims_p11) = crate::lower::typed_tables_f(&tp_p3x);
            let gens_p5 = crate::prelude::fold(&tp_p3x.gens_p, &Map::new(), &(|m_p12: &Map<Text, crate::check::typed::GenNote>, n_p13: &crate::check::typed::GenNote| crate::prelude::insert(m_p12, &crate::check::typed::at_key_f(&n_p13.at_p), n_p13)));
            let insts_p6 = crate::prelude::fold(&tp_p3x.insts_p, &Map::new(), &(|m_p14: &Map<Text, Array<crate::check::typed::InstNote>>, n_p15: &crate::check::typed::InstNote| crate::prelude::insert(m_p14, &crate::lower::expr::inst_key_f(n_p15), &crate::prelude::push(&crate::prelude::or(&crate::prelude::get(m_p14, &crate::lower::expr::inst_key_f(n_p15)), &Array::new()), n_p15))));
            let quants_p7 = crate::prelude::fold(&tp_p3x.gens_p, &Map::new(), &(|m_p16: &Map<Text, Text>, n_p17: &crate::check::typed::GenNote| crate::prelude::fold(&crate::prelude::append(&n_p17.tys_p, &n_p17.cols_p), m_p16, &(|m2_p18: &Map<Text, Text>, q_p19: &Text| crate::prelude::insert(m2_p18, q_p19, &n_p17.name_p)))));
            let gen_of_q_p8 = crate::prelude::fold(&tp_p3x.gens_p, &Map::new(), &(|m_p1a: &Map<Text, crate::check::typed::GenNote>, n_p1b: &crate::check::typed::GenNote| crate::prelude::fold(&crate::prelude::append(&n_p1b.tys_p, &n_p1b.cols_p), m_p1a, &(|m2_p1c: &Map<Text, crate::check::typed::GenNote>, q_p1d: &Text| crate::prelude::insert(m2_p1c, q_p1d, n_p1b)))));
            let use_insts_p9 = crate::prelude::fold(&tp_p3x.insts_p, &Map::new(), &(|m_p1e: &Map<Text, crate::check::typed::InstNote>, n_p1f: &crate::check::typed::InstNote| crate::prelude::insert(m_p1e, &crate::check::typed::at_key_f(&n_p1f.at_p), n_p1f)));
            crate::prelude::call_then(start_needed_mods_f(g_pt.clone(), shown_p2x.clone()), move |needed_mods_f_2446: Array<Text>| {
                let mods_pa = needed_mods_f_2446;
                let rs_mods_pb = crate::prelude::fold(&mods_pa, &Map::new(), &(|acc_p1g: &Map<Text, Text>, m_p1h: &Text| crate::prelude::insert(acc_p1g, m_p1h, &crate::lower::rust_mod_name_f(m_p1h))));
                let mod_segments_pc = crate::prelude::fold(&crate::prelude::values(&rs_mods_pb), &Map::new(), &(|acc_p1i: &Map<Text, bool>, p_p1j: &Text| crate::prelude::fold(&crate::prelude::split_on(p_p1j, &Text::lit("::")), acc_p1i, &(|a2_p1k: &Map<Text, bool>, seg_p1l: &Text| crate::prelude::insert(a2_p1k, seg_p1l, &true)))));
                crate::prelude::call_then(crate::lower::start_value_names_f(g_pt.clone()), move |value_names_f_2860: Map<Text, Text>| crate::prelude::call_then(crate::lower::types::start_layouts_f(g_pt.clone()), move |layouts_f_2884: Map<Text, Array<bool>>| crate::prelude::call_then(crate::lower::start_global_names_f(g_pt.clone()), move |global_names_f_2928: Map<Text, bool>| {
                    let lx0_pd = crate::lower::Lx { g_p: g_pt.clone(), tys_p: tys_pu.clone(), apps_p: apps_pv.clone(), lifts_p: crate::prelude::fold(&tp_p3x.lifts_p, &Map::new(), &(|m_p1m: &Map<Text, crate::check::typed::LiftNote>, n_p1n: &crate::check::typed::LiftNote| crate::prelude::insert(m_p1m, &crate::check::typed::at_key_f(&n_p1n.at_p), n_p1n))), binders_p: bs_p10.clone(), impls_p: ims_p11.clone(), file_p: Nat::from(0u32), home_p: Text::lit(""), site_p: Text::lit(""), rs_mods_p: rs_mods_pb.clone(), mod_segments_p: mod_segments_pc.clone(), rs_names_p: value_names_f_2860, layouts_p: layouts_f_2884, unbs_p: Array::new(), notes_p: Array::new(), globals_p: global_names_f_2928, in_node_p: false, unshrunk_p: crate::prelude::fold(&tp_p3x.unshrunk_p, &Map::new(), &(|m_p1o: &Map<Text, bool>, a_p1p: &crate::check::typed::SrcAt| crate::prelude::insert(m_p1o, &crate::check::typed::at_key_f(a_p1p), &true))), gens_p: gens_p5.clone(), insts_p: insts_p6.clone(), quants_p: quants_p7.clone(), gen_of_q_p: gen_of_q_p8.clone(), use_insts_p: use_insts_p9.clone(), local_ids_p: crate::prelude::fold(&tp_p3x.locals_p, &Map::new(), &(|m_p1q: &Map<Text, Nat>, n_p1r: &crate::check::typed::LocalNote| crate::prelude::insert(m_p1q, &crate::check::typed::at_key_f(&n_p1r.at_p), &n_p1r.id_p))), use_ids_p: crate::prelude::fold(&tp_p3x.uses_p, &Map::new(), &(|m_p1s: &Map<Text, Nat>, n_p1t: &crate::check::typed::LocalNote| crate::prelude::insert(m_p1s, &crate::check::typed::at_key_f(&n_p1t.at_p), &n_p1t.id_p))), call_ids_p: crate::prelude::fold(&tp_p3x.calls_p, &Map::new(), &(|m_p1u: &Map<Text, Nat>, n_p1v: &crate::check::typed::LocalNote| crate::prelude::insert(m_p1u, &crate::check::typed::at_key_f(&n_p1v.at_p), &n_p1v.id_p))), inlined_p: Text::lit(""), subst_p: Map::new(), csubst_p: Map::new() };
                    let lx_pe = {
                        let mut this: crate::lower::Lx = lx0_pd.clone();
                        this.unbs_p = job_roots_f(&lx0_pd);
                        this
                    };
                    let roots_pf = root_widgets_f(&lx_pe);
                    crate::prelude::call_value(crate::prelude::each_job(mods_pa.clone(), {
                        let lx_pex = lx_pe.clone();
                        let roots_pfx = roots_pf.clone();
                        let g_ptx = g_pt.clone();
                        let mods_pax = mods_pa.clone();
                        Rc::new(move |p0: Text| {
                            let lx_pexy = lx_pex.clone();
                            let roots_pfxy = roots_pfx.clone();
                            let g_ptxy = g_ptx.clone();
                            let mods_paxy = mods_pax.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let m_p20 = p0;
                                prism_rtl::Turn::More(Rc::new(ModDefOf { lx0_p0: lx_pexy.clone(), m_p1: m_p20.clone(), roots_p2: roots_pfxy.clone(), info_p3: crate::prelude::or(&crate::prelude::get(&g_ptxy.mods_p, &m_p20), &crate::check::env::reading::dummy_mod_p()), mods_p4: mods_paxy.clone() }))
                            }))
                        }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<crate::lower::model::ModDef>>>
                    }), move |each_3439: Array<crate::lower::model::ModDef>| {
                        let mod_defs_pg = each_3439;
                        crate::prelude::call_value(crate::prelude::each_job(roots_pf.clone(), {
                            let lx_pex = lx_pe.clone();
                            Rc::new(move |p0: (Text, bool)| {
                                let lx_pexy = lx_pex.clone();
                                crate::prelude::entered(crate::prelude::once_job(move || {
                                    let (qk_p21, _) = p0;
                                    prism_rtl::Turn::More(Rc::new(ProgDefOf { lx_p0: lx_pexy.clone(), qk_p1: qk_p21.clone() }))
                                }))
                            }) as Rc<dyn Fn((Text, bool)) -> Rc<dyn prism_rtl::Job<crate::lower::model::ProgDef>>>
                        }), move |each_3528: Array<crate::lower::model::ProgDef>| {
                            let programs_ph = each_3528;
                            let main_qk_pi = crate::prelude::fold(&g_pt.defs_p, &Text::lit(""), &(|found_p22: &Text, d_p23: &crate::check::env::Def| if (found_p22 == &Text::lit("")) && is_main_f(&d_p23.qk_p) {
                                d_p23.qk_p.clone()
                            } else {
                                found_p22.clone()
                            }));
                            let root_oj = if &main_qk_pi == &Text::lit("") {
                                None
                            } else {
                                Some(prog_def_of_f(&lx_pe, &main_qk_pi))
                            };
                            crate::prelude::call_value(crate::prelude::fold_job(g_pt.defs_p.clone(), Array::new(), {
                                let lx_pex = lx_pe.clone();
                                Rc::new(move |(p0, p1): (Array<crate::lower::model::CheckDef>, crate::check::env::Def)| {
                                    let lx_pexy = lx_pex.clone();
                                    crate::prelude::entered(crate::prelude::once_job(move || {
                                        let acc_p24 = p0;
                                        let d_p25 = p1;
                                        match &d_p25.body_p {
                                            crate::check::env::DefBody::DbCheck(c_p26) => {
                                                let c_p26x = c_p26.clone();
                                                crate::prelude::call_then(start_check_def_of_f(in_module_at_f(&lx_pexy, &d_p25.file_p, &d_p25.home_p, &Text::lit("\0main")), c_p26x.clone()), move |check_def_of_f_3830: crate::lower::model::CheckDef| prism_rtl::Turn::Finished(crate::prelude::push(&acc_p24, &check_def_of_f_3830)))
                                            },
                                            _ => prism_rtl::Turn::Finished(acc_p24.clone()),
                                        }
                                    }))
                                }) as Rc<dyn Fn((Array<crate::lower::model::CheckDef>, crate::check::env::Def)) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::CheckDef>>>>
                            }), move |fold_3757: Array<crate::lower::model::CheckDef>| {
                                let checks_pk = fold_3757;
                                crate::prelude::call_then(start_with_needs_f(g_pt.clone(), srcs_p0x.clone(), tp_p3x.clone(), mod_defs_pg.clone()), move |with_needs_f_3945: Array<crate::lower::model::ModDef>| crate::prelude::call_then(start_with_groups_f(with_needs_f_3945), move |with_groups_f_3933: Array<crate::lower::model::ModDef>| {
                                    let with_needs_pl = with_groups_f_3933;
                                    crate::prelude::call_then(start_elem_row_f(lx_pe.clone(), mods_pa.clone()), move |elem_row_f_3992: crate::lower::model::RowDef| {
                                        let elem_pm = elem_row_f_3992;
                                        crate::prelude::call_then(start_answer_enum_f(in_module_at_f(&lx_pe, &Nat::from(0u32), &Text::lit(""), &Text::lit("\0main")), mods_pa.clone()), move |answer_enum_f_4026: crate::lower::model::AnswerDef| {
                                            let answer_pn = answer_enum_f_4026;
                                            let names_po = crate::prelude::each(&with_needs_pl, &(|d_p27: &crate::lower::model::ModDef| d_p27.name_p.clone()));
                                            let value_tys_pp = value_types_f(&with_needs_pl);
                                            let elem_held_pq = crate::prelude::fold(&elem_pm.cases_p, &Array::new(), &(|acc_p28: &Array<Text>, (_, sp_p29): &(Text, Text)| crate::check::types::union_texts_f(acc_p28, &held_in_f(&names_po, &value_tys_pp, &Text::lit(""), &crate::lower::model::OutTy::OutNamed(sp_p29.clone(), Array::new())))));
                                            let answer_held_pr = crate::prelude::fold(&answer_pn.cases_p, &elem_held_pq, &(|acc_p2a: &Array<Text>, k_p2b: &crate::lower::model::AnswerCase| crate::check::types::union_texts_f(acc_p2a, &held_in_f(&names_po, &value_tys_pp, &Text::lit(""), &k_p2b.ty_p))));
                                            let answer_named_ps = crate::prelude::fold(&answer_pn.cases_p, &Array::new(), &(|acc_p2c: &Array<Text>, k_p2d: &crate::lower::model::AnswerCase| crate::check::types::union_texts_f(acc_p2c, &named_in_f(&names_po, &Text::lit(""), &k_p2d.ty_p))));
                                            prism_rtl::Turn::Finished(crate::lower::model::Model { name_p: name_p4x.clone(), mods_p: with_needs_pl.clone(), programs_p: programs_ph.clone(), root_o: root_oj.clone(), checks_p: checks_pk.clone(), elem_p: elem_pm.clone(), answer_p: answer_pn.clone(), elem_complete_p: answer_held_pr.clone(), elem_declared_p: crate::check::types::minus_texts_f(&answer_named_ps, &answer_held_pr), scripts_p: Array::new(), notes_p: Array::new() })
                                        })
                                    })
                                }))
                            })
                        })
                    })
                })))
            })
        })
    }
}

/// `Start LowerProgram, x`: what the function value is when passed to `@Run`.
pub fn start_lower_program_f(srcs_p0: Array<crate::check::errors::Src>, trees_p1: Array<crate::syntax::Module>, shown_p2: Nat, tp_p3: crate::check::typed::TProgram, name_p4: Text) -> Rc<dyn prism_rtl::Job<crate::lower::model::Model>> {
    Rc::new(LowerProgram { srcs_p0, trees_p1, shown_p2, tp_p3, name_p4 })
}

/// ```prism
/// WithNeeds: unbounded fn G, [Src], TProgram, [ModDef] -> [ModDef]
/// ```
pub fn with_needs_f(g_p0: &crate::check::env::G, srcs_p1: &Array<crate::check::errors::Src>, tp_p2: &crate::check::typed::TProgram, defs_p3: &Array<crate::lower::model::ModDef>) -> Array<crate::lower::model::ModDef> {
    let names_p4 = crate::prelude::each(defs_p3, &(|d_p7: &crate::lower::model::ModDef| d_p7.name_p.clone()));
    let value_tys_p5 = value_types_f(defs_p3);
    let refs_p6 = named_mods_f(g_p0, srcs_p1, tp_p2, &crate::prelude::each(defs_p3, &(|d_p8: &crate::lower::model::ModDef| d_p8.prism_p.clone())));
    crate::prelude::run_to_end(crate::prelude::each_job(defs_p3.clone(), {
        let names_p4x = names_p4.clone();
        let value_tys_p5x = value_tys_p5.clone();
        let refs_p6x = refs_p6.clone();
        Rc::new(move |p0: crate::lower::model::ModDef| {
            let names_p4xy = names_p4x.clone();
            let value_tys_p5xy = value_tys_p5x.clone();
            let refs_p6xy = refs_p6x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let d_p9 = p0;
                {
                    let held_pa = crate::prelude::fold(&d_p9.items_p, &Array::new(), &(|acc_pe: &Array<Text>, it_pf: &crate::lower::model::Item| crate::check::types::union_texts_f(acc_pe, &item_held_f(&names_p4xy, &value_tys_p5xy, &d_p9.name_p, it_pf))));
                    let complete_pb = crate::prelude::filter(&held_pa, &(|n_pg: &Text| n_pg != &d_p9.name_p));
                    crate::prelude::call_then(start_reached_by_f(refs_p6xy.clone(), Array::from(vec![d_p9.prism_p.clone()]), Array::new()), move |reached_by_f_5240: Array<Text>| {
                        let reached_pc = crate::prelude::each(&reached_by_f_5240, &(|m_ph: &Text| crate::lower::rust_mod_name_f(m_ph)));
                        let declared_pd = crate::prelude::filter(&names_p4xy, &(|n_pi: &Text| ((n_pi != &d_p9.name_p) && crate::check::types::has_text_f(&reached_pc, n_pi)) && !crate::check::types::has_text_f(&complete_pb, n_pi)));
                        prism_rtl::Turn::Finished({
                            let mut this: crate::lower::model::ModDef = d_p9.clone();
                            this.complete_p = complete_pb.clone();
                            this.declared_p = declared_pd.clone();
                            this
                        })
                    })
                }
            }))
        }) as Rc<dyn Fn(crate::lower::model::ModDef) -> Rc<dyn prism_rtl::Job<crate::lower::model::ModDef>>>
    }))
}

/// The step machine of `WithNeeds`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// WithNeeds: unbounded fn G, [Src], TProgram, [ModDef] -> [ModDef]
/// ```
pub struct WithNeeds {
    pub g_p0: crate::check::env::G,
    pub srcs_p1: Array<crate::check::errors::Src>,
    pub tp_p2: crate::check::typed::TProgram,
    pub defs_p3: Array<crate::lower::model::ModDef>,
}

impl prism_rtl::Job<Array<crate::lower::model::ModDef>> for WithNeeds {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::lower::model::ModDef>> {
        let g_p0 = &self.g_p0;
        let srcs_p1 = &self.srcs_p1;
        let tp_p2 = &self.tp_p2;
        let defs_p3 = &self.defs_p3;
        let names_p4 = crate::prelude::each(defs_p3, &(|d_p7: &crate::lower::model::ModDef| d_p7.name_p.clone()));
        let value_tys_p5 = value_types_f(defs_p3);
        let defs_p3x = defs_p3.clone();
        let g_p0x = g_p0.clone();
        let srcs_p1x = srcs_p1.clone();
        let tp_p2x = tp_p2.clone();
        crate::prelude::call_then(start_named_mods_f(g_p0x.clone(), srcs_p1x.clone(), tp_p2x.clone(), crate::prelude::each(&defs_p3x, &(|d_p8: &crate::lower::model::ModDef| d_p8.prism_p.clone()))), move |named_mods_f_4985: Map<Text, Array<Text>>| {
            let refs_p6 = named_mods_f_4985;
            crate::prelude::each_job(defs_p3x.clone(), {
                let names_p4x = names_p4.clone();
                let value_tys_p5x = value_tys_p5.clone();
                let refs_p6x = refs_p6.clone();
                Rc::new(move |p0: crate::lower::model::ModDef| {
                    let names_p4xy = names_p4x.clone();
                    let value_tys_p5xy = value_tys_p5x.clone();
                    let refs_p6xy = refs_p6x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let d_p9 = p0;
                        {
                            let held_pa = crate::prelude::fold(&d_p9.items_p, &Array::new(), &(|acc_pe: &Array<Text>, it_pf: &crate::lower::model::Item| crate::check::types::union_texts_f(acc_pe, &item_held_f(&names_p4xy, &value_tys_p5xy, &d_p9.name_p, it_pf))));
                            let complete_pb = crate::prelude::filter(&held_pa, &(|n_pg: &Text| n_pg != &d_p9.name_p));
                            crate::prelude::call_then(start_reached_by_f(refs_p6xy.clone(), Array::from(vec![d_p9.prism_p.clone()]), Array::new()), move |reached_by_f_5240: Array<Text>| {
                                let reached_pc = crate::prelude::each(&reached_by_f_5240, &(|m_ph: &Text| crate::lower::rust_mod_name_f(m_ph)));
                                let declared_pd = crate::prelude::filter(&names_p4xy, &(|n_pi: &Text| ((n_pi != &d_p9.name_p) && crate::check::types::has_text_f(&reached_pc, n_pi)) && !crate::check::types::has_text_f(&complete_pb, n_pi)));
                                prism_rtl::Turn::Finished({
                                    let mut this: crate::lower::model::ModDef = d_p9.clone();
                                    this.complete_p = complete_pb.clone();
                                    this.declared_p = declared_pd.clone();
                                    this
                                })
                            })
                        }
                    }))
                }) as Rc<dyn Fn(crate::lower::model::ModDef) -> Rc<dyn prism_rtl::Job<crate::lower::model::ModDef>>>
            }).cycle()
        })
    }
}

/// `Start WithNeeds, x`: what the function value is when passed to `@Run`.
pub fn start_with_needs_f(g_p0: crate::check::env::G, srcs_p1: Array<crate::check::errors::Src>, tp_p2: crate::check::typed::TProgram, defs_p3: Array<crate::lower::model::ModDef>) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::ModDef>>> {
    Rc::new(WithNeeds { g_p0, srcs_p1, tp_p2, defs_p3 })
}

/// ```prism
/// NamedMods: unbounded fn G, [Src], TProgram, [Text] -> (Text ==> [Text])
/// ```
pub fn named_mods_f(g_p0: &crate::check::env::G, srcs_p1: &Array<crate::check::errors::Src>, tp_p2: &crate::check::typed::TProgram, ms_p3: &Array<Text>) -> Map<Text, Array<Text>> {
    let by_path_p4 = crate::prelude::fold(&crate::prelude::values(&g_p0.mods_p), &Map::new(), &(|acc_p7: &Map<Text, Text>, info_p8: &crate::check::env::ModInfo| crate::prelude::insert(acc_p7, &crate::prelude::or(&crate::prelude::index(srcs_p1, &info_p8.file_p), &crate::check::errors::mk_src_f(&Text::lit(""), &Text::lit(""))).path_p, &info_p8.name_p)));
    let by_file_p5 = crate::prelude::fold(&crate::prelude::values(&g_p0.mods_p), &Map::new(), &(|acc_p9: &Map<Nat, Text>, info_pa: &crate::check::env::ModInfo| crate::prelude::insert(acc_p9, &info_pa.file_p, &info_pa.name_p)));
    let solved_p6 = crate::prelude::fold(&tp_p2.impls_p, &Map::new(), &(|acc_pb: &Map<Text, Array<Text>>, n_pc: &crate::check::typed::ImplNote| match crate::prelude::get(&by_file_p5, &n_pc.at_p.file_p) {
        Some(site_pd) => match crate::prelude::get(&by_path_p4, &impl_path_f(&n_pc.how_p)) {
            Some(home_pe) => if (&home_pe == &site_pd) || crate::check::types::has_text_f(&crate::prelude::or(&crate::prelude::get(acc_pb, &site_pd), &Array::new()), &home_pe) {
                acc_pb.clone()
            } else {
                crate::prelude::insert(acc_pb, &site_pd, &crate::prelude::push(&crate::prelude::or(&crate::prelude::get(acc_pb, &site_pd), &Array::new()), &home_pe))
            },
            None => acc_pb.clone(),
        },
        None => acc_pb.clone(),
    }));
    crate::prelude::run_to_end(crate::prelude::fold_job(ms_p3.clone(), Map::new(), {
        let g_p0x = g_p0.clone();
        let tp_p2x = tp_p2.clone();
        let ms_p3x = ms_p3.clone();
        let solved_p6x = solved_p6.clone();
        Rc::new(move |(p0, p1): (Map<Text, Array<Text>>, Text)| {
            let g_p0xy = g_p0x.clone();
            let tp_p2xy = tp_p2x.clone();
            let ms_p3xy = ms_p3x.clone();
            let solved_p6xy = solved_p6x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_pf = p0;
                let m_pg = p1;
                match crate::prelude::get(&g_p0xy.mods_p, &m_pg) {
                    Some(info_ph) => crate::prelude::call_then(start_types_named_in_f(tp_p2xy.clone(), info_ph.file_p.clone()), move |types_named_in_f_6710: Array<Text>| {
                        let named_pi = crate::prelude::append(&crate::prelude::each(&crate::prelude::filter(&tp_p2xy.globals_p, &(|n_pk: &crate::check::typed::GlobalNote| &n_pk.at_p.file_p == &info_ph.file_p)), &(|n_pl: &crate::check::typed::GlobalNote| n_pl.target_p.clone())), &types_named_in_f_6710);
                        let qualified_pj = crate::prelude::filter(&ms_p3xy, &(|o_pm: &Text| ((o_pm != &m_pg) && (o_pm != &Text::lit(""))) && crate::prelude::fold(&named_pi, &false, &(|f_pn: &bool, k_po: &Text| *f_pn || (&crate::lower::owner_of_f(k_po) == o_pm)))));
                        crate::prelude::call_then(start_mod_refs_f(g_p0xy.clone(), m_pg.clone()), move |mod_refs_f_6906: Array<Text>| prism_rtl::Turn::Finished(crate::prelude::insert(&acc_pf, &m_pg, &crate::check::types::union_texts_f(&crate::check::types::union_texts_f(&mod_refs_f_6906, &qualified_pj), &crate::prelude::or(&crate::prelude::get(&solved_p6xy, &m_pg), &Array::new())))))
                    }),
                    None => prism_rtl::Turn::Finished(acc_pf.clone()),
                }
            }))
        }) as Rc<dyn Fn((Map<Text, Array<Text>>, Text)) -> Rc<dyn prism_rtl::Job<Map<Text, Array<Text>>>>>
    }))
}

/// The step machine of `NamedMods`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// NamedMods: unbounded fn G, [Src], TProgram, [Text] -> (Text ==> [Text])
/// ```
pub struct NamedMods {
    pub g_p0: crate::check::env::G,
    pub srcs_p1: Array<crate::check::errors::Src>,
    pub tp_p2: crate::check::typed::TProgram,
    pub ms_p3: Array<Text>,
}

impl prism_rtl::Job<Map<Text, Array<Text>>> for NamedMods {
    fn cycle(&self) -> prism_rtl::Turn<Map<Text, Array<Text>>> {
        let g_p0 = &self.g_p0;
        let srcs_p1 = &self.srcs_p1;
        let tp_p2 = &self.tp_p2;
        let ms_p3 = &self.ms_p3;
        let by_path_p4 = crate::prelude::fold(&crate::prelude::values(&g_p0.mods_p), &Map::new(), &(|acc_p7: &Map<Text, Text>, info_p8: &crate::check::env::ModInfo| crate::prelude::insert(acc_p7, &crate::prelude::or(&crate::prelude::index(srcs_p1, &info_p8.file_p), &crate::check::errors::mk_src_f(&Text::lit(""), &Text::lit(""))).path_p, &info_p8.name_p)));
        let by_file_p5 = crate::prelude::fold(&crate::prelude::values(&g_p0.mods_p), &Map::new(), &(|acc_p9: &Map<Nat, Text>, info_pa: &crate::check::env::ModInfo| crate::prelude::insert(acc_p9, &info_pa.file_p, &info_pa.name_p)));
        let solved_p6 = crate::prelude::fold(&tp_p2.impls_p, &Map::new(), &(|acc_pb: &Map<Text, Array<Text>>, n_pc: &crate::check::typed::ImplNote| match crate::prelude::get(&by_file_p5, &n_pc.at_p.file_p) {
            Some(site_pd) => match crate::prelude::get(&by_path_p4, &impl_path_f(&n_pc.how_p)) {
                Some(home_pe) => if (&home_pe == &site_pd) || crate::check::types::has_text_f(&crate::prelude::or(&crate::prelude::get(acc_pb, &site_pd), &Array::new()), &home_pe) {
                    acc_pb.clone()
                } else {
                    crate::prelude::insert(acc_pb, &site_pd, &crate::prelude::push(&crate::prelude::or(&crate::prelude::get(acc_pb, &site_pd), &Array::new()), &home_pe))
                },
                None => acc_pb.clone(),
            },
            None => acc_pb.clone(),
        }));
        crate::prelude::fold_job(ms_p3.clone(), Map::new(), {
            let g_p0x = g_p0.clone();
            let tp_p2x = tp_p2.clone();
            let ms_p3x = ms_p3.clone();
            let solved_p6x = solved_p6.clone();
            Rc::new(move |(p0, p1): (Map<Text, Array<Text>>, Text)| {
                let g_p0xy = g_p0x.clone();
                let tp_p2xy = tp_p2x.clone();
                let ms_p3xy = ms_p3x.clone();
                let solved_p6xy = solved_p6x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let acc_pf = p0;
                    let m_pg = p1;
                    match crate::prelude::get(&g_p0xy.mods_p, &m_pg) {
                        Some(info_ph) => crate::prelude::call_then(start_types_named_in_f(tp_p2xy.clone(), info_ph.file_p.clone()), move |types_named_in_f_6710: Array<Text>| {
                            let named_pi = crate::prelude::append(&crate::prelude::each(&crate::prelude::filter(&tp_p2xy.globals_p, &(|n_pk: &crate::check::typed::GlobalNote| &n_pk.at_p.file_p == &info_ph.file_p)), &(|n_pl: &crate::check::typed::GlobalNote| n_pl.target_p.clone())), &types_named_in_f_6710);
                            let qualified_pj = crate::prelude::filter(&ms_p3xy, &(|o_pm: &Text| ((o_pm != &m_pg) && (o_pm != &Text::lit(""))) && crate::prelude::fold(&named_pi, &false, &(|f_pn: &bool, k_po: &Text| *f_pn || (&crate::lower::owner_of_f(k_po) == o_pm)))));
                            crate::prelude::call_then(start_mod_refs_f(g_p0xy.clone(), m_pg.clone()), move |mod_refs_f_6906: Array<Text>| prism_rtl::Turn::Finished(crate::prelude::insert(&acc_pf, &m_pg, &crate::check::types::union_texts_f(&crate::check::types::union_texts_f(&mod_refs_f_6906, &qualified_pj), &crate::prelude::or(&crate::prelude::get(&solved_p6xy, &m_pg), &Array::new())))))
                        }),
                        None => prism_rtl::Turn::Finished(acc_pf.clone()),
                    }
                }))
            }) as Rc<dyn Fn((Map<Text, Array<Text>>, Text)) -> Rc<dyn prism_rtl::Job<Map<Text, Array<Text>>>>>
        }).cycle()
    }
}

/// `Start NamedMods, x`: what the function value is when passed to `@Run`.
pub fn start_named_mods_f(g_p0: crate::check::env::G, srcs_p1: Array<crate::check::errors::Src>, tp_p2: crate::check::typed::TProgram, ms_p3: Array<Text>) -> Rc<dyn prism_rtl::Job<Map<Text, Array<Text>>>> {
    Rc::new(NamedMods { g_p0, srcs_p1, tp_p2, ms_p3 })
}

/// ```prism
/// TypesNamedIn: unbounded fn TProgram, Nat -> [Text]
/// ```
pub fn types_named_in_f(tp_p0: &crate::check::typed::TProgram, file_p1: &Nat) -> Array<Text> {
    let from_exprs_p2 = crate::prelude::run_to_end(crate::prelude::fold_job(crate::prelude::filter(&tp_p0.exprs_p, &(|n_p4: &crate::check::typed::TyNote| &n_p4.at_p.file_p == file_p1)), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::check::typed::TyNote)| crate::prelude::entered(crate::prelude::once_job(move || {
        let acc_p5 = p0;
        let n_p6 = p1;
        crate::prelude::call_then(start_ty_con_names_f(n_p6.ty_p.clone()), move |ty_con_names_f_7321: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_p5, &ty_con_names_f_7321)))
    }))) as Rc<dyn Fn((Array<Text>, crate::check::typed::TyNote)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>));
    let from_binders_p3 = crate::prelude::run_to_end(crate::prelude::fold_job(crate::prelude::filter(&tp_p0.binders_p, &(|n_p7: &crate::check::typed::BinderNote| &n_p7.at_p.file_p == file_p1)), from_exprs_p2.clone(), Rc::new(move |(p0, p1): (Array<Text>, crate::check::typed::BinderNote)| crate::prelude::entered(crate::prelude::once_job(move || {
        let acc_p8 = p0;
        let n_p9 = p1;
        crate::prelude::call_then(start_ty_con_names_f(n_p9.ty_p.clone()), move |ty_con_names_f_7448: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_p8, &ty_con_names_f_7448)))
    }))) as Rc<dyn Fn((Array<Text>, crate::check::typed::BinderNote)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>));
    crate::prelude::run_to_end(crate::prelude::fold_job(crate::prelude::filter(&tp_p0.defs_p, &(|n_pa: &crate::check::typed::DefNote| &n_pa.at_p.file_p == file_p1)), from_binders_p3.clone(), Rc::new(move |(p0, p1): (Array<Text>, crate::check::typed::DefNote)| crate::prelude::entered(crate::prelude::once_job(move || {
        let acc_pb = p0;
        let n_pc = p1;
        crate::prelude::call_then(start_ty_con_names_f(n_pc.scheme_p.ty_p.clone()), move |ty_con_names_f_7556: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_pb, &ty_con_names_f_7556)))
    }))) as Rc<dyn Fn((Array<Text>, crate::check::typed::DefNote)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>))
}

/// The step machine of `TypesNamedIn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TypesNamedIn: unbounded fn TProgram, Nat -> [Text]
/// ```
pub struct TypesNamedIn {
    pub tp_p0: crate::check::typed::TProgram,
    pub file_p1: Nat,
}

impl prism_rtl::Job<Array<Text>> for TypesNamedIn {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let tp_p0 = &self.tp_p0;
        let file_p1 = &self.file_p1;
        let file_p1x = file_p1.clone();
        let tp_p0x = tp_p0.clone();
        crate::prelude::call_value(crate::prelude::fold_job(crate::prelude::filter(&tp_p0x.exprs_p, &(|n_p4: &crate::check::typed::TyNote| &n_p4.at_p.file_p == &file_p1x)), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::check::typed::TyNote)| crate::prelude::entered(crate::prelude::once_job(move || {
            let acc_p5 = p0;
            let n_p6 = p1;
            crate::prelude::call_then(start_ty_con_names_f(n_p6.ty_p.clone()), move |ty_con_names_f_7321: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_p5, &ty_con_names_f_7321)))
        }))) as Rc<dyn Fn((Array<Text>, crate::check::typed::TyNote)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>), move |fold_7240: Array<Text>| {
            let from_exprs_p2 = fold_7240;
            crate::prelude::call_value(crate::prelude::fold_job(crate::prelude::filter(&tp_p0x.binders_p, &(|n_p7: &crate::check::typed::BinderNote| &n_p7.at_p.file_p == &file_p1x)), from_exprs_p2.clone(), Rc::new(move |(p0, p1): (Array<Text>, crate::check::typed::BinderNote)| crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_p8 = p0;
                let n_p9 = p1;
                crate::prelude::call_then(start_ty_con_names_f(n_p9.ty_p.clone()), move |ty_con_names_f_7448: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_p8, &ty_con_names_f_7448)))
            }))) as Rc<dyn Fn((Array<Text>, crate::check::typed::BinderNote)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>), move |fold_7360: Array<Text>| {
                let from_binders_p3 = fold_7360;
                crate::prelude::fold_job(crate::prelude::filter(&tp_p0x.defs_p, &(|n_pa: &crate::check::typed::DefNote| &n_pa.at_p.file_p == &file_p1x)), from_binders_p3.clone(), Rc::new(move |(p0, p1): (Array<Text>, crate::check::typed::DefNote)| crate::prelude::entered(crate::prelude::once_job(move || {
                    let acc_pb = p0;
                    let n_pc = p1;
                    crate::prelude::call_then(start_ty_con_names_f(n_pc.scheme_p.ty_p.clone()), move |ty_con_names_f_7556: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_pb, &ty_con_names_f_7556)))
                }))) as Rc<dyn Fn((Array<Text>, crate::check::typed::DefNote)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>).cycle()
            })
        })
    }
}

/// `Start TypesNamedIn, x`: what the function value is when passed to `@Run`.
pub fn start_types_named_in_f(tp_p0: crate::check::typed::TProgram, file_p1: Nat) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(TypesNamedIn { tp_p0, file_p1 })
}

/// ```prism
/// TyConNames: unbounded fn Ty -> [Text]
/// ```
pub fn ty_con_names_f(t_p0: &crate::check::types::Ty) -> Array<Text> {
    match t_p0 {
        crate::check::types::Ty::TyCon(n_p1, args_p2) => crate::prelude::run_to_end(crate::prelude::fold_job(args_p2.clone(), Array::from(vec![n_p1.clone()]), Rc::new(move |(p0, p1): (Array<Text>, crate::check::types::Ty)| crate::prelude::entered(crate::prelude::once_job(move || {
            let acc_p3 = p0;
            let a_p4 = p1;
            crate::prelude::call_then(start_ty_con_names_f(a_p4.clone()), move |ty_con_names_f_7710: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_p3, &ty_con_names_f_7710)))
        }))) as Rc<dyn Fn((Array<Text>, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>)),
        crate::check::types::Ty::TyFn(_, ps_p5, r_p6) => crate::prelude::run_to_end(crate::prelude::fold_job(ps_p5.clone(), ty_con_names_f(&**r_p6), Rc::new(move |(p0, p1): (Array<Text>, crate::check::types::Ty)| crate::prelude::entered(crate::prelude::once_job(move || {
            let acc_p7 = p0;
            let a_p8 = p1;
            crate::prelude::call_then(start_ty_con_names_f(a_p8.clone()), move |ty_con_names_f_7800: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_p7, &ty_con_names_f_7800)))
        }))) as Rc<dyn Fn((Array<Text>, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>)),
        crate::check::types::Ty::TyTuple(ts_p9) => crate::prelude::run_to_end(crate::prelude::fold_job(ts_p9.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::check::types::Ty)| crate::prelude::entered(crate::prelude::once_job(move || {
            let acc_pa = p0;
            let a_pb = p1;
            crate::prelude::call_then(start_ty_con_names_f(a_pb.clone()), move |ty_con_names_f_7872: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_pa, &ty_con_names_f_7872)))
        }))) as Rc<dyn Fn((Array<Text>, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>)),
        crate::check::types::Ty::TyArray(x_pc) => ty_con_names_f(&**x_pc),
        crate::check::types::Ty::TyMap(k_pd, v_pe) => crate::check::types::union_texts_f(&ty_con_names_f(&**k_pd), &ty_con_names_f(&**v_pe)),
        crate::check::types::Ty::TySig(_, x_pf) => ty_con_names_f(&**x_pf),
        crate::check::types::Ty::TyAt(x_pg, _) => ty_con_names_f(&**x_pg),
        crate::check::types::Ty::TyElem(_, x_ph) => ty_con_names_f(&**x_ph),
        crate::check::types::Ty::TyAssoc(_, x_pi) => ty_con_names_f(&**x_pi),
        _ => Array::new(),
    }
}

/// The step machine of `TyConNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TyConNames: unbounded fn Ty -> [Text]
/// ```
pub struct TyConNames {
    pub t_p0: crate::check::types::Ty,
}

impl prism_rtl::Job<Array<Text>> for TyConNames {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let t_p0 = &self.t_p0;
        match t_p0 {
            crate::check::types::Ty::TyCon(n_p1, args_p2) => crate::prelude::fold_job(args_p2.clone(), Array::from(vec![n_p1.clone()]), Rc::new(move |(p0, p1): (Array<Text>, crate::check::types::Ty)| crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_p3 = p0;
                let a_p4 = p1;
                crate::prelude::call_then(start_ty_con_names_f(a_p4.clone()), move |ty_con_names_f_7710: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_p3, &ty_con_names_f_7710)))
            }))) as Rc<dyn Fn((Array<Text>, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>).cycle(),
            crate::check::types::Ty::TyFn(_, ps_p5, r_p6) => {
                let ps_p5x = ps_p5.clone();
                let r_p6x = (**r_p6).clone();
                crate::prelude::call_then(start_ty_con_names_f(r_p6x.clone()), move |ty_con_names_f_7758: Array<Text>| crate::prelude::fold_job(ps_p5x.clone(), ty_con_names_f_7758, Rc::new(move |(p0, p1): (Array<Text>, crate::check::types::Ty)| crate::prelude::entered(crate::prelude::once_job(move || {
                    let acc_p7 = p0;
                    let a_p8 = p1;
                    crate::prelude::call_then(start_ty_con_names_f(a_p8.clone()), move |ty_con_names_f_7800: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_p7, &ty_con_names_f_7800)))
                }))) as Rc<dyn Fn((Array<Text>, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>).cycle())
            },
            crate::check::types::Ty::TyTuple(ts_p9) => crate::prelude::fold_job(ts_p9.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::check::types::Ty)| crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_pa = p0;
                let a_pb = p1;
                crate::prelude::call_then(start_ty_con_names_f(a_pb.clone()), move |ty_con_names_f_7872: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_pa, &ty_con_names_f_7872)))
            }))) as Rc<dyn Fn((Array<Text>, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>).cycle(),
            crate::check::types::Ty::TyArray(x_pc) => prism_rtl::Turn::More(Rc::new(TyConNames { t_p0: (**x_pc).clone() })),
            crate::check::types::Ty::TyMap(k_pd, v_pe) => {
                let k_pdx = (**k_pd).clone();
                let v_pex = (**v_pe).clone();
                crate::prelude::call_then(start_ty_con_names_f(k_pdx.clone()), move |ty_con_names_f_7942: Array<Text>| crate::prelude::call_then(start_ty_con_names_f(v_pex.clone()), move |ty_con_names_f_7958: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&ty_con_names_f_7942, &ty_con_names_f_7958))))
            },
            crate::check::types::Ty::TySig(_, x_pf) => prism_rtl::Turn::More(Rc::new(TyConNames { t_p0: (**x_pf).clone() })),
            crate::check::types::Ty::TyAt(x_pg, _) => prism_rtl::Turn::More(Rc::new(TyConNames { t_p0: (**x_pg).clone() })),
            crate::check::types::Ty::TyElem(_, x_ph) => prism_rtl::Turn::More(Rc::new(TyConNames { t_p0: (**x_ph).clone() })),
            crate::check::types::Ty::TyAssoc(_, x_pi) => prism_rtl::Turn::More(Rc::new(TyConNames { t_p0: (**x_pi).clone() })),
            _ => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start TyConNames, x`: what the function value is when passed to `@Run`.
pub fn start_ty_con_names_f(t_p0: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(TyConNames { t_p0 })
}

/// ```prism
/// ImplPath: fn Text -> Text
/// ```
pub fn impl_path_f(how_p0: &Text) -> Text {
    let rest_p1 = crate::prelude::or(&crate::syntax::lexer::chars::after_prefix_o(how_p0, &Text::lit("impl ")), &crate::prelude::or(&crate::syntax::lexer::chars::after_prefix_o(how_p0, &Text::lit("derived ")), &Text::lit("")));
    let parts_p2 = crate::prelude::split_on(&rest_p1, &Text::lit(":"));
    crate::syntax::lexer::chars::join_f(&crate::prelude::take(&parts_p2, &crate::syntax::lexer::chars::dec_f(&crate::prelude::len(&parts_p2))), &Text::lit(":"))
}

/// ```prism
/// ValueTypes: fn [ModDef] -> (Text ==> Bool)
/// ```
pub fn value_types_f(defs_p0: &Array<crate::lower::model::ModDef>) -> Map<Text, bool> {
    crate::prelude::fold(defs_p0, &Map::new(), &(|acc_p1: &Map<Text, bool>, d_p2: &crate::lower::model::ModDef| crate::prelude::fold(&d_p2.items_p, acc_p1, &(|a_p3: &Map<Text, bool>, it_p4: &crate::lower::model::Item| match it_p4 {
        crate::lower::model::Item::ItType(t_p5) => crate::prelude::insert(a_p3, &Text::from(format!("{}::{}", &d_p2.name_p, &t_p5.name_p)), &true),
        crate::lower::model::Item::ItTag(t_p6) => crate::prelude::insert(a_p3, &Text::from(format!("{}::{}", &d_p2.name_p, &t_p6.name_p)), &true),
        _ => a_p3.clone(),
    }))))
}

/// ```prism
/// ItemHeld: fn [Text], (Text ==> Bool), Text, Item -> [Text]
/// ```
pub fn item_held_f(names_p0: &Array<Text>, value_tys_p1: &Map<Text, bool>, home_p2: &Text, it_p3: &crate::lower::model::Item) -> Array<Text> {
    match it_p3 {
        crate::lower::model::Item::ItType(t_p4) => crate::prelude::fold(&t_p4.cases_p, &Array::new(), &(|acc_p5: &Array<Text>, c_p6: &crate::lower::model::CaseDef| crate::prelude::fold(&c_p6.fields_p, acc_p5, &(|a_p7: &Array<Text>, (_, ft_p8): &(Text, crate::lower::model::OutTy)| crate::check::types::union_texts_f(a_p7, &held_in_f(names_p0, value_tys_p1, home_p2, ft_p8)))))),
        crate::lower::model::Item::ItTag(t_p9) => crate::prelude::fold(&t_p9.fields_p, &Array::new(), &(|acc_pa: &Array<Text>, (_, _, ft_pb): &(Text, Text, crate::lower::model::OutTy)| crate::check::types::union_texts_f(acc_pa, &held_in_f(names_p0, value_tys_p1, home_p2, ft_pb)))),
        crate::lower::model::Item::ItRow(r_pc) => crate::prelude::fold(&r_pc.cases_p, &Array::new(), &(|acc_pd: &Array<Text>, (_, sp_pe): &(Text, Text)| crate::check::types::union_texts_f(acc_pd, &held_in_f(names_p0, value_tys_p1, home_p2, &crate::lower::model::OutTy::OutNamed(sp_pe.clone(), Array::new()))))),
        _ => Array::new(),
    }
}

/// ```prism
/// HeldIn: fn [Text], (Text ==> Bool), Text, OutTy -> [Text]
/// ```
pub fn held_in_f(names_p0: &Array<Text>, value_tys_p1: &Map<Text, bool>, home_p2: &Text, t_p3: &crate::lower::model::OutTy) -> Array<Text> {
    match t_p3 {
        crate::lower::model::OutTy::OutNamed(n_p4, args_p5) => {
            let p_p6 = path_from_f(names_p0, home_p2, n_p4);
            let own_p7 = if crate::check::env::has_key_f(value_tys_p1, &p_p6) {
                Array::from(vec![parent_of_f(&p_p6)])
            } else {
                Array::new()
            };
            crate::prelude::fold(args_p5, &own_p7, &(|acc_p8: &Array<Text>, a_p9: &crate::lower::model::OutTy| crate::check::types::union_texts_f(acc_p8, &held_in_f(names_p0, value_tys_p1, home_p2, a_p9))))
        },
        crate::lower::model::OutTy::OutOpt(i_pa) => held_in_f(names_p0, value_tys_p1, home_p2, &**i_pa),
        crate::lower::model::OutTy::OutRes(i_pb) => held_in_f(names_p0, value_tys_p1, home_p2, &**i_pb),
        crate::lower::model::OutTy::OutCell(i_pc) => held_in_f(names_p0, value_tys_p1, home_p2, &**i_pc),
        crate::lower::model::OutTy::OutTuple(ts_pd) => crate::prelude::fold(ts_pd, &Array::new(), &(|acc_pe: &Array<Text>, a_pf: &crate::lower::model::OutTy| crate::check::types::union_texts_f(acc_pe, &held_in_f(names_p0, value_tys_p1, home_p2, a_pf)))),
        _ => Array::new(),
    }
}

/// ```prism
/// NamedIn: fn [Text], Text, OutTy -> [Text]
/// ```
pub fn named_in_f(names_p0: &Array<Text>, home_p1: &Text, t_p2: &crate::lower::model::OutTy) -> Array<Text> {
    match t_p2 {
        crate::lower::model::OutTy::OutNamed(n_p3, args_p4) => {
            let p_p5 = path_from_f(names_p0, home_p1, n_p3);
            let own_p6 = if crate::check::types::has_text_f(names_p0, &parent_of_f(&p_p5)) {
                Array::from(vec![parent_of_f(&p_p5)])
            } else {
                Array::new()
            };
            crate::prelude::fold(args_p4, &own_p6, &(|acc_p7: &Array<Text>, a_p8: &crate::lower::model::OutTy| crate::check::types::union_texts_f(acc_p7, &named_in_f(names_p0, home_p1, a_p8))))
        },
        crate::lower::model::OutTy::OutOpt(i_p9) => named_in_f(names_p0, home_p1, &**i_p9),
        crate::lower::model::OutTy::OutRes(i_pa) => named_in_f(names_p0, home_p1, &**i_pa),
        crate::lower::model::OutTy::OutCell(i_pb) => named_in_f(names_p0, home_p1, &**i_pb),
        crate::lower::model::OutTy::OutArray(i_pc) => named_in_f(names_p0, home_p1, &**i_pc),
        crate::lower::model::OutTy::OutRc(i_pd) => named_in_f(names_p0, home_p1, &**i_pd),
        crate::lower::model::OutTy::OutEvent(i_pe) => named_in_f(names_p0, home_p1, &**i_pe),
        crate::lower::model::OutTy::OutDyn(i_pf) => named_in_f(names_p0, home_p1, &**i_pf),
        crate::lower::model::OutTy::OutMap(k_pg, v_ph) => crate::check::types::union_texts_f(&named_in_f(names_p0, home_p1, &**k_pg), &named_in_f(names_p0, home_p1, &**v_ph)),
        crate::lower::model::OutTy::OutTuple(ts_pi) => crate::prelude::fold(ts_pi, &Array::new(), &(|acc_pj: &Array<Text>, a_pk: &crate::lower::model::OutTy| crate::check::types::union_texts_f(acc_pj, &named_in_f(names_p0, home_p1, a_pk)))),
        crate::lower::model::OutTy::OutFn(ps_pl, r_pm) => crate::prelude::fold(ps_pl, &named_in_f(names_p0, home_p1, &**r_pm), &(|acc_pn: &Array<Text>, a_po: &crate::lower::model::OutTy| crate::check::types::union_texts_f(acc_pn, &named_in_f(names_p0, home_p1, a_po)))),
        _ => Array::new(),
    }
}

/// ```prism
/// PathFrom: fn [Text], Text, Text -> Text
/// ```
pub fn path_from_f(names_p0: &Array<Text>, home_p1: &Text, n_p2: &Text) -> Text {
    let q_p3 = crate::syntax::lexer::chars::drop_prefix_f(n_p2, &Text::lit("crate::"));
    if starts_with_module_f(names_p0, &q_p3) {
        q_p3.clone()
    } else {
        if home_p1 == &Text::lit("") {
            q_p3.clone()
        } else {
            Text::from(format!("{}::{}", home_p1, &q_p3))
        }
    }
}

/// ```prism
/// StartsWithModule: fn [Text], Text -> Bool
/// ```
pub fn starts_with_module_f(names_p0: &Array<Text>, q_p1: &Text) -> bool {
    crate::prelude::fold(names_p0, &false, &(|f_p2: &bool, n_p3: &Text| *f_p2 || ((n_p3 != &Text::lit("")) && crate::syntax::lexer::chars::has_prefix_f(q_p1, &Text::from(format!("{}::", n_p3))))))
}

/// ```prism
/// ParentOf: fn Text -> Text
/// ```
pub fn parent_of_f(p_p0: &Text) -> Text {
    let segs_p1 = crate::prelude::split_on(p_p0, &Text::lit("::"));
    crate::syntax::lexer::chars::join_f(&crate::prelude::take(&segs_p1, &crate::syntax::lexer::chars::dec_f(&crate::prelude::len(&segs_p1))), &Text::lit("::"))
}

/// ```prism
/// WithGroups: unbounded fn [ModDef] -> [ModDef]
/// ```
pub fn with_groups_f(defs_p0: &Array<crate::lower::model::ModDef>) -> Array<crate::lower::model::ModDef> {
    let edges_p1 = crate::prelude::fold(defs_p0, &Map::new(), &(|m_p3: &Map<Text, Array<Text>>, d_p4: &crate::lower::model::ModDef| crate::prelude::insert(m_p3, &d_p4.name_p, &d_p4.complete_p)));
    let reach_p2 = crate::prelude::run_to_end(crate::prelude::fold_job(defs_p0.clone(), Map::new(), {
        let edges_p1x = edges_p1.clone();
        Rc::new(move |(p0, p1): (Map<Text, Array<Text>>, crate::lower::model::ModDef)| {
            let edges_p1xy = edges_p1x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let m_p5 = p0;
                let d_p6 = p1;
                crate::prelude::call_then(start_reached_by_f(edges_p1xy.clone(), Array::from(vec![d_p6.name_p.clone()]), Array::new()), move |reached_by_f_12517: Array<Text>| prism_rtl::Turn::Finished(crate::prelude::insert(&m_p5, &d_p6.name_p, &reached_by_f_12517)))
            }))
        }) as Rc<dyn Fn((Map<Text, Array<Text>>, crate::lower::model::ModDef)) -> Rc<dyn prism_rtl::Job<Map<Text, Array<Text>>>>>
    }));
    crate::prelude::each(defs_p0, &(|d_p7: &crate::lower::model::ModDef| {
        let mine_p8 = crate::prelude::or(&crate::prelude::get(&reach_p2, &d_p7.name_p), &Array::new());
        {
            let mut this: crate::lower::model::ModDef = d_p7.clone();
            this.types_with_p = crate::prelude::filter(&crate::prelude::each(defs_p0, &(|o_p9: &crate::lower::model::ModDef| o_p9.name_p.clone())), &(|n_pa: &Text| (n_pa == &d_p7.name_p) || (crate::check::types::has_text_f(&mine_p8, n_pa) && crate::check::types::has_text_f(&crate::prelude::or(&crate::prelude::get(&reach_p2, n_pa), &Array::new()), &d_p7.name_p))));
            this
        }
    }))
}

/// The step machine of `WithGroups`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// WithGroups: unbounded fn [ModDef] -> [ModDef]
/// ```
pub struct WithGroups {
    pub defs_p0: Array<crate::lower::model::ModDef>,
}

impl prism_rtl::Job<Array<crate::lower::model::ModDef>> for WithGroups {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::lower::model::ModDef>> {
        let defs_p0 = &self.defs_p0;
        let edges_p1 = crate::prelude::fold(defs_p0, &Map::new(), &(|m_p3: &Map<Text, Array<Text>>, d_p4: &crate::lower::model::ModDef| crate::prelude::insert(m_p3, &d_p4.name_p, &d_p4.complete_p)));
        let defs_p0x = defs_p0.clone();
        crate::prelude::call_value(crate::prelude::fold_job(defs_p0x.clone(), Map::new(), {
            let edges_p1x = edges_p1.clone();
            Rc::new(move |(p0, p1): (Map<Text, Array<Text>>, crate::lower::model::ModDef)| {
                let edges_p1xy = edges_p1x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let m_p5 = p0;
                    let d_p6 = p1;
                    crate::prelude::call_then(start_reached_by_f(edges_p1xy.clone(), Array::from(vec![d_p6.name_p.clone()]), Array::new()), move |reached_by_f_12517: Array<Text>| prism_rtl::Turn::Finished(crate::prelude::insert(&m_p5, &d_p6.name_p, &reached_by_f_12517)))
                }))
            }) as Rc<dyn Fn((Map<Text, Array<Text>>, crate::lower::model::ModDef)) -> Rc<dyn prism_rtl::Job<Map<Text, Array<Text>>>>>
        }), move |fold_12475: Map<Text, Array<Text>>| {
            let reach_p2 = fold_12475;
            prism_rtl::Turn::Finished(crate::prelude::each(&defs_p0x, &(|d_p7: &crate::lower::model::ModDef| {
                let mine_p8 = crate::prelude::or(&crate::prelude::get(&reach_p2, &d_p7.name_p), &Array::new());
                {
                    let mut this: crate::lower::model::ModDef = d_p7.clone();
                    this.types_with_p = crate::prelude::filter(&crate::prelude::each(&defs_p0x, &(|o_p9: &crate::lower::model::ModDef| o_p9.name_p.clone())), &(|n_pa: &Text| (n_pa == &d_p7.name_p) || (crate::check::types::has_text_f(&mine_p8, n_pa) && crate::check::types::has_text_f(&crate::prelude::or(&crate::prelude::get(&reach_p2, n_pa), &Array::new()), &d_p7.name_p))));
                    this
                }
            })))
        })
    }
}

/// `Start WithGroups, x`: what the function value is when passed to `@Run`.
pub fn start_with_groups_f(defs_p0: Array<crate::lower::model::ModDef>) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::ModDef>>> {
    Rc::new(WithGroups { defs_p0 })
}

/// ```prism
/// ReachedBy: unbounded fn (Text ==> [Text]), [Text], [Text] -> [Text]
/// ```
pub fn reached_by_f(edges_p0: &Map<Text, Array<Text>>, todo_p1: &Array<Text>, seen_p2: &Array<Text>) -> Array<Text> {
    match crate::prelude::index(todo_p1, &Nat::from(0u32)) {
        None => seen_p2.clone(),
        Some(m_p3) => if crate::check::types::has_text_f(seen_p2, &m_p3) {
            reached_by_f(edges_p0, &crate::prelude::drop(todo_p1, &Nat::from(1u32)), seen_p2)
        } else {
            reached_by_f(edges_p0, &crate::prelude::append(&crate::prelude::drop(todo_p1, &Nat::from(1u32)), &crate::prelude::or(&crate::prelude::get(edges_p0, &m_p3), &Array::new())), &crate::prelude::push(seen_p2, &m_p3))
        },
    }
}

/// The step machine of `ReachedBy`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ReachedBy: unbounded fn (Text ==> [Text]), [Text], [Text] -> [Text]
/// ```
pub struct ReachedBy {
    pub edges_p0: Map<Text, Array<Text>>,
    pub todo_p1: Array<Text>,
    pub seen_p2: Array<Text>,
}

impl prism_rtl::Job<Array<Text>> for ReachedBy {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let edges_p0 = &self.edges_p0;
        let todo_p1 = &self.todo_p1;
        let seen_p2 = &self.seen_p2;
        match crate::prelude::index(todo_p1, &Nat::from(0u32)) {
            None => prism_rtl::Turn::Finished(seen_p2.clone()),
            Some(m_p3) => if crate::check::types::has_text_f(seen_p2, &m_p3) {
                prism_rtl::Turn::More(Rc::new(ReachedBy { edges_p0: edges_p0.clone(), todo_p1: crate::prelude::drop(todo_p1, &Nat::from(1u32)), seen_p2: seen_p2.clone() }))
            } else {
                prism_rtl::Turn::More(Rc::new(ReachedBy { edges_p0: edges_p0.clone(), todo_p1: crate::prelude::append(&crate::prelude::drop(todo_p1, &Nat::from(1u32)), &crate::prelude::or(&crate::prelude::get(edges_p0, &m_p3), &Array::new())), seen_p2: crate::prelude::push(seen_p2, &m_p3) }))
            },
        }
    }
}

/// `Start ReachedBy, x`: what the function value is when passed to `@Run`.
pub fn start_reached_by_f(edges_p0: Map<Text, Array<Text>>, todo_p1: Array<Text>, seen_p2: Array<Text>) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(ReachedBy { edges_p0, todo_p1, seen_p2 })
}

/// ```prism
/// NeededMods: unbounded fn G, Nat -> [Text]
/// ```
pub fn needed_mods_f(g_p0: &crate::check::env::G, shown_p1: &Nat) -> Array<Text> {
    let own_p2 = crate::prelude::filter(&crate::prelude::keys(&g_p0.mods_p), &(|m_p4: &Text| (&crate::prelude::or(&crate::prelude::get(&g_p0.mods_p, m_p4), &crate::check::env::reading::dummy_mod_p()).file_p < shown_p1) && (m_p4 != &Text::lit("Prelude"))));
    let grown_p3 = crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(&Nat::from(6u32)), own_p2.clone(), {
        let g_p0x = g_p0.clone();
        Rc::new(move |(p0, p1): (Array<Text>, Nat)| {
            let g_p0xy = g_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_p5 = p0;
                let _ = p1;
                crate::prelude::fold_job(acc_p5.clone(), acc_p5.clone(), {
                    let g_p0xyx = g_p0xy.clone();
                    Rc::new(move |(p0, p1): (Array<Text>, Text)| {
                        let g_p0xyxy = g_p0xyx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let a_p6 = p0;
                            let m_p7 = p1;
                            crate::prelude::call_then(start_mod_refs_f(g_p0xyxy.clone(), m_p7.clone()), move |mod_refs_f_13540: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&a_p6, &mod_refs_f_13540)))
                        }))
                    }) as Rc<dyn Fn((Array<Text>, Text)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
                }).cycle()
            }))
        }) as Rc<dyn Fn((Array<Text>, Nat)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
    }));
    crate::prelude::filter(&crate::prelude::keys(&g_p0.mods_p), &(|m_p8: &Text| (m_p8 != &Text::lit("Prelude")) && crate::check::types::has_text_f(&grown_p3, m_p8)))
}

/// The step machine of `NeededMods`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// NeededMods: unbounded fn G, Nat -> [Text]
/// ```
pub struct NeededMods {
    pub g_p0: crate::check::env::G,
    pub shown_p1: Nat,
}

impl prism_rtl::Job<Array<Text>> for NeededMods {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let g_p0 = &self.g_p0;
        let shown_p1 = &self.shown_p1;
        let own_p2 = crate::prelude::filter(&crate::prelude::keys(&g_p0.mods_p), &(|m_p4: &Text| (&crate::prelude::or(&crate::prelude::get(&g_p0.mods_p, m_p4), &crate::check::env::reading::dummy_mod_p()).file_p < shown_p1) && (m_p4 != &Text::lit("Prelude"))));
        let g_p0x = g_p0.clone();
        crate::prelude::call_value(crate::prelude::fold_job(crate::check::errors::range0_f(&Nat::from(6u32)), own_p2.clone(), {
            let g_p0xx = g_p0x.clone();
            Rc::new(move |(p0, p1): (Array<Text>, Nat)| {
                let g_p0xxy = g_p0xx.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let acc_p5 = p0;
                    let _ = p1;
                    crate::prelude::fold_job(acc_p5.clone(), acc_p5.clone(), {
                        let g_p0xxyx = g_p0xxy.clone();
                        Rc::new(move |(p0, p1): (Array<Text>, Text)| {
                            let g_p0xxyxy = g_p0xxyx.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let a_p6 = p0;
                                let m_p7 = p1;
                                crate::prelude::call_then(start_mod_refs_f(g_p0xxyxy.clone(), m_p7.clone()), move |mod_refs_f_13540: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&a_p6, &mod_refs_f_13540)))
                            }))
                        }) as Rc<dyn Fn((Array<Text>, Text)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
                    }).cycle()
                }))
            }) as Rc<dyn Fn((Array<Text>, Nat)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
        }), move |fold_13465: Array<Text>| {
            let grown_p3 = fold_13465;
            prism_rtl::Turn::Finished(crate::prelude::filter(&crate::prelude::keys(&g_p0x.mods_p), &(|m_p8: &Text| (m_p8 != &Text::lit("Prelude")) && crate::check::types::has_text_f(&grown_p3, m_p8))))
        })
    }
}

/// `Start NeededMods, x`: what the function value is when passed to `@Run`.
pub fn start_needed_mods_f(g_p0: crate::check::env::G, shown_p1: Nat) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(NeededMods { g_p0, shown_p1 })
}

/// ```prism
/// ModRefs: unbounded fn G, Text -> [Text]
/// ```
pub fn mod_refs_f(g_p0: &crate::check::env::G, m_p1: &Text) -> Array<Text> {
    match crate::prelude::get(&g_p0.mods_p, m_p1) {
        Some(info_p2) => {
            let used_p3 = crate::prelude::each(&info_p2.uses_p, &(|(u_p5, _): &(Text, bool)| u_p5.clone()));
            let fams_p4 = match &info_p2.tree_p.emit_row_o {
                Some(rw_p6) => crate::prelude::fold(&rw_p6.terms_p, &Array::new(), &(|acc_p7: &Array<Text>, t_p8: &crate::syntax::RowTerm| match t_p8 {
                    crate::syntax::RowTerm::RFamily(q_p9) => crate::prelude::push(acc_p7, &crate::prelude::or(&crate::prelude::get(&g_p0.fam_owner_p, &crate::check::env::dotted_f(&q_p9.path_p)), &crate::check::env::dotted_f(&q_p9.path_p))),
                    _ => acc_p7.clone(),
                })),
                None => Array::new(),
            };
            crate::prelude::filter(&crate::prelude::append(&used_p3, &fams_p4), &(|x_pa: &Text| crate::check::env::has_key_f(&g_p0.mods_p, x_pa)))
        },
        None => Array::new(),
    }
}

/// The step machine of `ModRefs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ModRefs: unbounded fn G, Text -> [Text]
/// ```
pub struct ModRefs {
    pub g_p0: crate::check::env::G,
    pub m_p1: Text,
}

impl prism_rtl::Job<Array<Text>> for ModRefs {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let g_p0 = &self.g_p0;
        let m_p1 = &self.m_p1;
        match crate::prelude::get(&g_p0.mods_p, m_p1) {
            Some(info_p2) => {
                let used_p3 = crate::prelude::each(&info_p2.uses_p, &(|(u_p5, _): &(Text, bool)| u_p5.clone()));
                let fams_p4 = match &info_p2.tree_p.emit_row_o {
                    Some(rw_p6) => crate::prelude::fold(&rw_p6.terms_p, &Array::new(), &(|acc_p7: &Array<Text>, t_p8: &crate::syntax::RowTerm| match t_p8 {
                        crate::syntax::RowTerm::RFamily(q_p9) => crate::prelude::push(acc_p7, &crate::prelude::or(&crate::prelude::get(&g_p0.fam_owner_p, &crate::check::env::dotted_f(&q_p9.path_p)), &crate::check::env::dotted_f(&q_p9.path_p))),
                        _ => acc_p7.clone(),
                    })),
                    None => Array::new(),
                };
                prism_rtl::Turn::Finished(crate::prelude::filter(&crate::prelude::append(&used_p3, &fams_p4), &(|x_pa: &Text| crate::check::env::has_key_f(&g_p0.mods_p, x_pa))))
            },
            None => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start ModRefs, x`: what the function value is when passed to `@Run`.
pub fn start_mod_refs_f(g_p0: crate::check::env::G, m_p1: Text) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(ModRefs { g_p0, m_p1 })
}

/// ```prism
/// RootWidgets: fn Lx -> [((Text, Bool))]
/// ```
pub fn root_widgets_f(lx_p0: &crate::lower::Lx) -> Array<(Text, bool)> {
    let tested_p1 = crate::prelude::fold(&lx_p0.g_p.defs_p, &Array::new(), &(|acc_p3: &Array<(Text, bool)>, d_p4: &crate::check::env::Def| match &d_p4.body_p {
        crate::check::env::DefBody::DbTest(t_p5) => match blueprint_qk_f(&in_module_f(lx_p0, &d_p4.file_p, &d_p4.home_p), &t_p5.blueprint_p) {
            m14294_0 if (&m14294_0 == &Text::lit("")) => acc_p3.clone(),
            qk_p6 => if crate::check::types::has_text_f(&crate::prelude::each(acc_p3, &(|(q_p7, _): &(Text, bool)| q_p7.clone())), &qk_p6) {
                acc_p3.clone()
            } else {
                crate::prelude::push(acc_p3, &(qk_p6.clone(), true))
            },
            _ => unreachable!("no arm matched"),
        },
        _ => acc_p3.clone(),
    }));
    let main_p2 = crate::prelude::fold(&lx_p0.g_p.defs_p, &Array::new(), &(|acc_p8: &Array<(Text, bool)>, d_p9: &crate::check::env::Def| if is_main_f(&d_p9.qk_p) {
        crate::prelude::push(acc_p8, &(d_p9.qk_p.clone(), false))
    } else {
        acc_p8.clone()
    }));
    crate::prelude::fold(&main_p2, &tested_p1, &(|acc_pa: &Array<(Text, bool)>, (k_pb, b_pc): &(Text, bool)| if crate::check::types::has_text_f(&crate::prelude::each(acc_pa, &(|(q_pd, _): &(Text, bool)| q_pd.clone())), k_pb) {
        acc_pa.clone()
    } else {
        crate::prelude::push(acc_pa, &(k_pb.clone(), *b_pc))
    }))
}

/// ```prism
/// IsMain: fn Text -> Bool
/// ```
pub fn is_main_f(qk_p0: &Text) -> bool {
    ((&crate::lower::owner_of_f(qk_p0) == &Text::lit("")) && (&crate::lower::base_f(&crate::check::types::bare_name_f(qk_p0)) == &Text::lit("main"))) && crate::syntax::lexer::chars::has_prefix_f(&crate::check::types::bare_name_f(qk_p0), &Text::lit("@"))
}

/// ```prism
/// BlueprintQk: fn Lx, Expr -> Text
/// ```
pub fn blueprint_qk_f(lx_p0: &crate::lower::Lx, e_p1: &crate::syntax::Expr) -> Text {
    match &*e_p1.kind_p {
        crate::syntax::ExprKind::ECall(c_p2, _, _, _) => blueprint_qk_f(lx_p0, &**c_p2),
        crate::syntax::ExprKind::EGroup(x_p3) => blueprint_qk_f(lx_p0, &**x_p3),
        crate::syntax::ExprKind::EName(n_p4) => {
            let (q_o5, _) = crate::check::env::names::resolve_value_f(&lx_p0.g_p, &lx_p0.home_p, n_p4);
            crate::prelude::or(&q_o5, &Text::lit(""))
        },
        _ => Text::lit(""),
    }
}

/// ```prism
/// ValOf: fn Lx, Text -> ValInfo
/// ```
pub fn val_of_f(lx_p0: &crate::lower::Lx, qk_p1: &Text) -> crate::check::env::ValInfo {
    match crate::prelude::get(&lx_p0.g_p.vals_p, qk_p1) {
        Some(v_p2) => v_p2,
        None => {
            let d_p3 = crate::prelude::fold(&lx_p0.g_p.defs_p, &crate::check::env::decls::dummy_def_p(), &(|found_p4: &crate::check::env::Def, df_p5: &crate::check::env::Def| if &df_p5.qk_p == qk_p1 { df_p5.clone() } else { found_p4.clone() }));
            crate::check::env::ValInfo { qk_p: qk_p1.clone(), scheme_p: crate::check::types::schemes::mono_f(&crate::check::types::Ty::TyErr), sort_p: Text::lit("fn"), has_sig_p: false, home_p: d_p3.home_p.clone(), file_p: d_p3.file_p.clone(), span_p: d_p3.span_p.clone() }
        },
    }
}

/// ```prism
/// ProgDefOf: unbounded fn Lx, Text -> ProgDef
/// ```
pub fn prog_def_of_f(lx_p0: &crate::lower::Lx, qk_p1: &Text) -> crate::lower::model::ProgDef {
    let v_p2 = val_of_f(lx_p0, qk_p1);
    let ptys_p3 = match &v_p2.scheme_p.ty_p {
        crate::check::types::Ty::TyFn(_, ps_p9, _) => ps_p9.clone(),
        _ => Array::new(),
    };
    let lxm_p4 = in_module_at_f(lx_p0, &v_p2.file_p, &v_p2.home_p, &Text::lit("\0main"));
    let params_p5 = crate::prelude::run_to_end(crate::prelude::each_job(crate::check::errors::range0_f(&crate::prelude::len(&ptys_p3)), {
        let lxm_p4x = lxm_p4.clone();
        let ptys_p3x = ptys_p3.clone();
        Rc::new(move |p0: Nat| {
            let lxm_p4xy = lxm_p4x.clone();
            let ptys_p3xy = ptys_p3x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let i_pa = p0;
                crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lxm_p4xy.clone(), crate::lower::types::peel_f(&crate::prelude::or(&crate::prelude::index(&ptys_p3xy, &i_pa), &crate::check::types::Ty::TyErr))), move |out_ty_of_f_15869: crate::lower::model::OutTy| prism_rtl::Turn::Finished((Text::from(format!("arg{}", &i_pa)), out_ty_of_f_15869)))
            }))
        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<(Text, crate::lower::model::OutTy)>>>
    }));
    let node_p6 = Text::from(format!("{}::{}", &crate::lower::rust_mod_name_f(&v_p2.home_p), &crate::lower::camel_f(&crate::check::types::bare_name_f(qk_p1))));
    let fams_p7 = crate::prelude::or(&crate::prelude::get(&lx_p0.g_p.mods_p, &v_p2.home_p), &crate::check::env::reading::dummy_mod_p()).emit_rw_p.fams_p.clone();
    let world_p8 = if crate::check::types::has_text_f(&fams_p7, &Text::lit("Gui")) {
        Text::lit("canvas")
    } else {
        if crate::check::types::has_text_f(&fams_p7, &Text::lit("Ui")) {
            Text::lit("none")
        } else {
            Text::lit("cli")
        }
    };
    crate::lower::model::ProgDef { name_p: Text::from(format!("{}Program", &crate::lower::camel_f(&crate::check::types::bare_name_f(qk_p1)))), prism_p: crate::syntax::lexer::chars::after_first_f(&crate::check::types::bare_name_f(qk_p1)), node_p: node_p6.clone(), params_p: params_p5.clone(), fallible_p: true, world_p: world_p8.clone() }
}

/// The step machine of `ProgDefOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ProgDefOf: unbounded fn Lx, Text -> ProgDef
/// ```
pub struct ProgDefOf {
    pub lx_p0: crate::lower::Lx,
    pub qk_p1: Text,
}

impl prism_rtl::Job<crate::lower::model::ProgDef> for ProgDefOf {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::ProgDef> {
        let lx_p0 = &self.lx_p0;
        let qk_p1 = &self.qk_p1;
        let v_p2 = val_of_f(lx_p0, qk_p1);
        let ptys_p3 = match &v_p2.scheme_p.ty_p {
            crate::check::types::Ty::TyFn(_, ps_p9, _) => ps_p9.clone(),
            _ => Array::new(),
        };
        let lxm_p4 = in_module_at_f(lx_p0, &v_p2.file_p, &v_p2.home_p, &Text::lit("\0main"));
        let lx_p0x = lx_p0.clone();
        let qk_p1x = qk_p1.clone();
        crate::prelude::call_value(crate::prelude::each_job(crate::check::errors::range0_f(&crate::prelude::len(&ptys_p3)), {
            let lxm_p4x = lxm_p4.clone();
            let ptys_p3x = ptys_p3.clone();
            Rc::new(move |p0: Nat| {
                let lxm_p4xy = lxm_p4x.clone();
                let ptys_p3xy = ptys_p3x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let i_pa = p0;
                    crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lxm_p4xy.clone(), crate::lower::types::peel_f(&crate::prelude::or(&crate::prelude::index(&ptys_p3xy, &i_pa), &crate::check::types::Ty::TyErr))), move |out_ty_of_f_15869: crate::lower::model::OutTy| prism_rtl::Turn::Finished((Text::from(format!("arg{}", &i_pa)), out_ty_of_f_15869)))
                }))
            }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<(Text, crate::lower::model::OutTy)>>>
        }), move |each_15825: Array<(Text, crate::lower::model::OutTy)>| {
            let params_p5 = each_15825;
            let node_p6 = Text::from(format!("{}::{}", &crate::lower::rust_mod_name_f(&v_p2.home_p), &crate::lower::camel_f(&crate::check::types::bare_name_f(&qk_p1x))));
            let fams_p7 = crate::prelude::or(&crate::prelude::get(&lx_p0x.g_p.mods_p, &v_p2.home_p), &crate::check::env::reading::dummy_mod_p()).emit_rw_p.fams_p.clone();
            let world_p8 = if crate::check::types::has_text_f(&fams_p7, &Text::lit("Gui")) {
                Text::lit("canvas")
            } else {
                if crate::check::types::has_text_f(&fams_p7, &Text::lit("Ui")) {
                    Text::lit("none")
                } else {
                    Text::lit("cli")
                }
            };
            prism_rtl::Turn::Finished(crate::lower::model::ProgDef { name_p: Text::from(format!("{}Program", &crate::lower::camel_f(&crate::check::types::bare_name_f(&qk_p1x)))), prism_p: crate::syntax::lexer::chars::after_first_f(&crate::check::types::bare_name_f(&qk_p1x)), node_p: node_p6.clone(), params_p: params_p5.clone(), fallible_p: true, world_p: world_p8.clone() })
        })
    }
}

/// `Start ProgDefOf, x`: what the function value is when passed to `@Run`.
pub fn start_prog_def_of_f(lx_p0: crate::lower::Lx, qk_p1: Text) -> Rc<dyn prism_rtl::Job<crate::lower::model::ProgDef>> {
    Rc::new(ProgDefOf { lx_p0, qk_p1 })
}

/// ```prism
/// JobRoots: unbounded fn Lx -> [Text]
/// ```
pub fn job_roots_f(lx_p0: &crate::lower::Lx) -> Array<Text> {
    let direct_p1 = crate::prelude::run_to_end(crate::prelude::fold_job(lx_p0.g_p.defs_p.clone(), Array::new(), {
        let lx_p0x = lx_p0.clone();
        Rc::new(move |(p0, p1): (Array<Text>, crate::check::env::Def)| {
            let lx_p0xy = lx_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_p2 = p0;
                let d_p3 = p1;
                {
                    let lxd_p4 = in_module_f(&lx_p0xy, &d_p3.file_p, &d_p3.home_p);
                    crate::prelude::call_then(start_run_targets_f(lxd_p4.clone(), d_p3.clone()), move |run_targets_f_16704: Array<Text>| crate::prelude::call_then(start_unbounded_values_f(lxd_p4.clone(), d_p3.clone()), move |unbounded_values_f_16726: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&crate::check::types::union_texts_f(&acc_p2, &run_targets_f_16704), &unbounded_values_f_16726))))
                }
            }))
        }) as Rc<dyn Fn((Array<Text>, crate::check::env::Def)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
    }));
    crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(&Nat::from(8u32)), direct_p1.clone(), {
        let lx_p0x = lx_p0.clone();
        Rc::new(move |(p0, p1): (Array<Text>, Nat)| {
            let lx_p0xy = lx_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_p5 = p0;
                let _ = p1;
                crate::prelude::fold_job(acc_p5.clone(), acc_p5.clone(), {
                    let lx_p0xyx = lx_p0xy.clone();
                    Rc::new(move |(p0, p1): (Array<Text>, Text)| {
                        let lx_p0xyxy = lx_p0xyx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let a_p6 = p0;
                            let qk_p7 = p1;
                            crate::prelude::call_then(start_tail_targets_f(lx_p0xyxy.clone(), qk_p7.clone()), move |tail_targets_f_16833: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&a_p6, &tail_targets_f_16833)))
                        }))
                    }) as Rc<dyn Fn((Array<Text>, Text)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
                }).cycle()
            }))
        }) as Rc<dyn Fn((Array<Text>, Nat)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
    }))
}

/// The step machine of `JobRoots`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// JobRoots: unbounded fn Lx -> [Text]
/// ```
pub struct JobRoots {
    pub lx_p0: crate::lower::Lx,
}

impl prism_rtl::Job<Array<Text>> for JobRoots {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let lx_p0 = &self.lx_p0;
        let lx_p0x = lx_p0.clone();
        crate::prelude::call_value(crate::prelude::fold_job(lx_p0x.g_p.defs_p.clone(), Array::new(), {
            let lx_p0xx = lx_p0x.clone();
            Rc::new(move |(p0, p1): (Array<Text>, crate::check::env::Def)| {
                let lx_p0xxy = lx_p0xx.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let acc_p2 = p0;
                    let d_p3 = p1;
                    {
                        let lxd_p4 = in_module_f(&lx_p0xxy, &d_p3.file_p, &d_p3.home_p);
                        crate::prelude::call_then(start_run_targets_f(lxd_p4.clone(), d_p3.clone()), move |run_targets_f_16704: Array<Text>| crate::prelude::call_then(start_unbounded_values_f(lxd_p4.clone(), d_p3.clone()), move |unbounded_values_f_16726: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&crate::check::types::union_texts_f(&acc_p2, &run_targets_f_16704), &unbounded_values_f_16726))))
                    }
                }))
            }) as Rc<dyn Fn((Array<Text>, crate::check::env::Def)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
        }), move |fold_16589: Array<Text>| {
            let direct_p1 = fold_16589;
            crate::prelude::fold_job(crate::check::errors::range0_f(&Nat::from(8u32)), direct_p1.clone(), {
                let lx_p0xx = lx_p0x.clone();
                Rc::new(move |(p0, p1): (Array<Text>, Nat)| {
                    let lx_p0xxy = lx_p0xx.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let acc_p5 = p0;
                        let _ = p1;
                        crate::prelude::fold_job(acc_p5.clone(), acc_p5.clone(), {
                            let lx_p0xxyx = lx_p0xxy.clone();
                            Rc::new(move |(p0, p1): (Array<Text>, Text)| {
                                let lx_p0xxyxy = lx_p0xxyx.clone();
                                crate::prelude::entered(crate::prelude::once_job(move || {
                                    let a_p6 = p0;
                                    let qk_p7 = p1;
                                    crate::prelude::call_then(start_tail_targets_f(lx_p0xxyxy.clone(), qk_p7.clone()), move |tail_targets_f_16833: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&a_p6, &tail_targets_f_16833)))
                                }))
                            }) as Rc<dyn Fn((Array<Text>, Text)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
                        }).cycle()
                    }))
                }) as Rc<dyn Fn((Array<Text>, Nat)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
            }).cycle()
        })
    }
}

/// `Start JobRoots, x`: what the function value is when passed to `@Run`.
pub fn start_job_roots_f(lx_p0: crate::lower::Lx) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(JobRoots { lx_p0 })
}

/// ```prism
/// UnboundedValues: unbounded fn Lx, Def -> [Text]
/// ```
pub fn unbounded_values_f(lx_p0: &crate::lower::Lx, d_p1: &crate::check::env::Def) -> Array<Text> {
    let es_p2 = match &d_p1.body_p {
        crate::check::env::DefBody::DbWidget(w_p4) => crate::check::typed::print::block_exprs_f(&w_p4.body_p),
        crate::check::env::DefBody::DbFn(cs_p5) => crate::prelude::run_to_end(crate::prelude::fold_job(cs_p5.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<crate::syntax::Expr>, crate::syntax::decls::FnClause)| crate::prelude::entered(crate::prelude::once_job(move || {
            let acc_p6 = p0;
            let c_p7 = p1;
            crate::prelude::call_then(crate::check::typed::print::start_body_exprs_f(c_p7.body_p.clone()), move |body_exprs_f_17184: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(crate::prelude::append(&acc_p6, &body_exprs_f_17184)))
        }))) as Rc<dyn Fn((Array<crate::syntax::Expr>, crate::syntax::decls::FnClause)) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>>>)),
        crate::check::env::DefBody::DbLet(l_p8) => crate::check::typed::print::exprs_in_f(&l_p8.value_p),
        _ => Array::new(),
    };
    let callees_p3 = crate::prelude::fold(&es_p2, &Array::new(), &(|acc_p9: &Array<Text>, e_pa: &crate::syntax::Expr| match &*e_pa.kind_p {
        crate::syntax::ExprKind::ECall(c_pb, _, _, _) => crate::prelude::push(acc_p9, &crate::lower::place_key_f(lx_p0, &c_pb.span_p)),
        _ => acc_p9.clone(),
    }));
    crate::prelude::fold(&es_p2, &Array::new(), &(|acc_pc: &Array<Text>, e_pd: &crate::syntax::Expr| match &*e_pd.kind_p {
        crate::syntax::ExprKind::EName(n_pe) => if crate::check::types::has_text_f(&callees_p3, &crate::lower::place_key_f(lx_p0, &e_pd.span_p)) {
            acc_pc.clone()
        } else {
            {
                let (q_of, _) = crate::check::env::names::resolve_value_f(&lx_p0.g_p, &lx_p0.home_p, n_pe);
                match &q_of {
                    Some(q_pg) => if is_unbounded_f(lx_p0, q_pg) {
                        crate::check::types::add_text_f(acc_pc, q_pg)
                    } else {
                        acc_pc.clone()
                    },
                    None => acc_pc.clone(),
                }
            }
        },
        _ => acc_pc.clone(),
    }))
}

/// The step machine of `UnboundedValues`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UnboundedValues: unbounded fn Lx, Def -> [Text]
/// ```
pub struct UnboundedValues {
    pub lx_p0: crate::lower::Lx,
    pub d_p1: crate::check::env::Def,
}

impl prism_rtl::Job<Array<Text>> for UnboundedValues {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let lx_p0 = &self.lx_p0;
        let d_p1 = &self.d_p1;
        let es_p2 = match &d_p1.body_p {
            crate::check::env::DefBody::DbWidget(w_p4) => crate::check::typed::print::block_exprs_f(&w_p4.body_p),
            crate::check::env::DefBody::DbFn(cs_p5) => crate::prelude::run_to_end(crate::prelude::fold_job(cs_p5.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<crate::syntax::Expr>, crate::syntax::decls::FnClause)| crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_p6 = p0;
                let c_p7 = p1;
                crate::prelude::call_then(crate::check::typed::print::start_body_exprs_f(c_p7.body_p.clone()), move |body_exprs_f_17184: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(crate::prelude::append(&acc_p6, &body_exprs_f_17184)))
            }))) as Rc<dyn Fn((Array<crate::syntax::Expr>, crate::syntax::decls::FnClause)) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>>>)),
            crate::check::env::DefBody::DbLet(l_p8) => crate::check::typed::print::exprs_in_f(&l_p8.value_p),
            _ => Array::new(),
        };
        let callees_p3 = crate::prelude::fold(&es_p2, &Array::new(), &(|acc_p9: &Array<Text>, e_pa: &crate::syntax::Expr| match &*e_pa.kind_p {
            crate::syntax::ExprKind::ECall(c_pb, _, _, _) => crate::prelude::push(acc_p9, &crate::lower::place_key_f(lx_p0, &c_pb.span_p)),
            _ => acc_p9.clone(),
        }));
        prism_rtl::Turn::Finished(crate::prelude::fold(&es_p2, &Array::new(), &(|acc_pc: &Array<Text>, e_pd: &crate::syntax::Expr| match &*e_pd.kind_p {
            crate::syntax::ExprKind::EName(n_pe) => if crate::check::types::has_text_f(&callees_p3, &crate::lower::place_key_f(lx_p0, &e_pd.span_p)) {
                acc_pc.clone()
            } else {
                {
                    let (q_of, _) = crate::check::env::names::resolve_value_f(&lx_p0.g_p, &lx_p0.home_p, n_pe);
                    match &q_of {
                        Some(q_pg) => if is_unbounded_f(lx_p0, q_pg) {
                            crate::check::types::add_text_f(acc_pc, q_pg)
                        } else {
                            acc_pc.clone()
                        },
                        None => acc_pc.clone(),
                    }
                }
            },
            _ => acc_pc.clone(),
        })))
    }
}

/// `Start UnboundedValues, x`: what the function value is when passed to `@Run`.
pub fn start_unbounded_values_f(lx_p0: crate::lower::Lx, d_p1: crate::check::env::Def) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(UnboundedValues { lx_p0, d_p1 })
}

/// ```prism
/// InPrelude: fn Lx, Text -> Bool
/// ```
pub fn in_prelude_f(lx_p0: &crate::lower::Lx, q_p1: &Text) -> bool {
    match crate::prelude::get(&lx_p0.g_p.vals_p, q_p1) {
        Some(v_p2) => &v_p2.home_p == &Text::lit("Prelude"),
        None => false,
    }
}

/// ```prism
/// IsColorPoly: fn Lx, Text -> Bool
/// ```
pub fn is_color_poly_f(lx_p0: &crate::lower::Lx, q_p1: &Text) -> bool {
    match crate::prelude::get(&lx_p0.g_p.vals_p, q_p1) {
        Some(v_p2) => match &v_p2.scheme_p.ty_p {
            crate::check::types::Ty::TyFn(crate::check::types::Col::CQ(_), _, _) => true,
            crate::check::types::Ty::TyFn(crate::check::types::Col::CRigid(_), _, _) => true,
            _ => false,
        },
        None => false,
    }
}

/// ```prism
/// EntersAtOnce: fn Lx, Text, [Arg] -> Bool
/// ```
pub fn enters_at_once_f(lx_p0: &crate::lower::Lx, q_p1: &Text, args_p2: &Array<crate::syntax::Arg>) -> bool {
    is_color_poly_f(lx_p0, q_p1) && !crate::prelude::fold(args_p2, &false, &(|seen_p3: &bool, a_p4: &crate::syntax::Arg| *seen_p3 || is_unbounded_arg_f(lx_p0, a_p4)))
}

/// ```prism
/// IsUnboundedArg: fn Lx, Arg -> Bool
/// ```
pub fn is_unbounded_arg_f(lx_p0: &crate::lower::Lx, a_p1: &crate::syntax::Arg) -> bool {
    match crate::lower::types::peel_f(&crate::lower::type_at_f(lx_p0, &a_p1.value_p.span_p)) {
        crate::check::types::Ty::TyFn(crate::check::types::Col::CUnbound, _, _) => true,
        _ => false,
    }
}

/// ```prism
/// IsUnbounded: fn Lx, Text -> Bool
/// ```
pub fn is_unbounded_f(lx_p0: &crate::lower::Lx, q_p1: &Text) -> bool {
    match crate::prelude::get(&lx_p0.g_p.vals_p, q_p1) {
        Some(v_p2) => match &v_p2.scheme_p.ty_p {
            crate::check::types::Ty::TyFn(crate::check::types::Col::CBound, _, _) => false,
            crate::check::types::Ty::TyFn(_, _, _) => true,
            _ => false,
        },
        None => false,
    }
}

/// ```prism
/// RunTargets: unbounded fn Lx, Def -> [Text]
/// ```
pub fn run_targets_f(lx_p0: &crate::lower::Lx, d_p1: &crate::check::env::Def) -> Array<Text> {
    let es_p2 = match &d_p1.body_p {
        crate::check::env::DefBody::DbWidget(w_p3) => crate::check::typed::print::block_exprs_f(&w_p3.body_p),
        crate::check::env::DefBody::DbFn(cs_p4) => crate::prelude::run_to_end(crate::prelude::fold_job(cs_p4.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<crate::syntax::Expr>, crate::syntax::decls::FnClause)| crate::prelude::entered(crate::prelude::once_job(move || {
            let acc_p5 = p0;
            let c_p6 = p1;
            crate::prelude::call_then(crate::check::typed::print::start_body_exprs_f(c_p6.body_p.clone()), move |body_exprs_f_19413: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(crate::prelude::append(&acc_p5, &body_exprs_f_19413)))
        }))) as Rc<dyn Fn((Array<crate::syntax::Expr>, crate::syntax::decls::FnClause)) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>>>)),
        _ => Array::new(),
    };
    crate::prelude::fold(&es_p2, &Array::new(), &(|acc_p7: &Array<Text>, e_p8: &crate::syntax::Expr| match &*e_p8.kind_p {
        crate::syntax::ExprKind::ECall(c_p9, args_pa, _, _) => if &blueprint_qk_f(lx_p0, &**c_p9) == &Text::lit("Prelude.@Run") {
            match crate::prelude::index(args_pa, &Nat::from(0u32)) {
                Some(a_pb) => match &*a_pb.value_p.kind_p {
                    crate::syntax::ExprKind::EName(n_pc) => {
                        let (q_od, _) = crate::check::env::names::resolve_value_f(&lx_p0.g_p, &lx_p0.home_p, n_pc);
                        match &q_od {
                            Some(q_pe) => crate::check::types::add_text_f(acc_p7, q_pe),
                            None => acc_p7.clone(),
                        }
                    },
                    _ => acc_p7.clone(),
                },
                None => acc_p7.clone(),
            }
        } else {
            acc_p7.clone()
        },
        _ => acc_p7.clone(),
    }))
}

/// The step machine of `RunTargets`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RunTargets: unbounded fn Lx, Def -> [Text]
/// ```
pub struct RunTargets {
    pub lx_p0: crate::lower::Lx,
    pub d_p1: crate::check::env::Def,
}

impl prism_rtl::Job<Array<Text>> for RunTargets {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let lx_p0 = &self.lx_p0;
        let d_p1 = &self.d_p1;
        let es_p2 = match &d_p1.body_p {
            crate::check::env::DefBody::DbWidget(w_p3) => crate::check::typed::print::block_exprs_f(&w_p3.body_p),
            crate::check::env::DefBody::DbFn(cs_p4) => crate::prelude::run_to_end(crate::prelude::fold_job(cs_p4.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<crate::syntax::Expr>, crate::syntax::decls::FnClause)| crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_p5 = p0;
                let c_p6 = p1;
                crate::prelude::call_then(crate::check::typed::print::start_body_exprs_f(c_p6.body_p.clone()), move |body_exprs_f_19413: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(crate::prelude::append(&acc_p5, &body_exprs_f_19413)))
            }))) as Rc<dyn Fn((Array<crate::syntax::Expr>, crate::syntax::decls::FnClause)) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>>>)),
            _ => Array::new(),
        };
        prism_rtl::Turn::Finished(crate::prelude::fold(&es_p2, &Array::new(), &(|acc_p7: &Array<Text>, e_p8: &crate::syntax::Expr| match &*e_p8.kind_p {
            crate::syntax::ExprKind::ECall(c_p9, args_pa, _, _) => if &blueprint_qk_f(lx_p0, &**c_p9) == &Text::lit("Prelude.@Run") {
                match crate::prelude::index(args_pa, &Nat::from(0u32)) {
                    Some(a_pb) => match &*a_pb.value_p.kind_p {
                        crate::syntax::ExprKind::EName(n_pc) => {
                            let (q_od, _) = crate::check::env::names::resolve_value_f(&lx_p0.g_p, &lx_p0.home_p, n_pc);
                            match &q_od {
                                Some(q_pe) => crate::check::types::add_text_f(acc_p7, q_pe),
                                None => acc_p7.clone(),
                            }
                        },
                        _ => acc_p7.clone(),
                    },
                    None => acc_p7.clone(),
                }
            } else {
                acc_p7.clone()
            },
            _ => acc_p7.clone(),
        })))
    }
}

/// `Start RunTargets, x`: what the function value is when passed to `@Run`.
pub fn start_run_targets_f(lx_p0: crate::lower::Lx, d_p1: crate::check::env::Def) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(RunTargets { lx_p0, d_p1 })
}

/// ```prism
/// TailTargets: unbounded fn Lx, Text -> [Text]
/// ```
pub fn tail_targets_f(lx_p0: &crate::lower::Lx, qk_p1: &Text) -> Array<Text> {
    let v_p2 = crate::prelude::or(&crate::prelude::get(&lx_p0.g_p.vals_p, qk_p1), &crate::check::env::builtin_f(qk_p1, &crate::check::types::schemes::mono_f(&crate::check::types::Ty::TyErr)));
    let lxm_p3 = in_module_f(lx_p0, &v_p2.file_p, &v_p2.home_p);
    crate::prelude::run_to_end(crate::prelude::fold_job(crate::lower::jobs::clauses_of_f(&lx_p0.g_p, qk_p1), Array::new(), {
        let lxm_p3x = lxm_p3.clone();
        Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::decls::FnClause)| {
            let lxm_p3xy = lxm_p3x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_p4 = p0;
                let c_p5 = p1;
                crate::prelude::call_then(start_tails_of_body_f(lxm_p3xy.clone(), c_p5.body_p.clone()), move |tails_of_body_f_20292: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_p4, &tails_of_body_f_20292)))
            }))
        }) as Rc<dyn Fn((Array<Text>, crate::syntax::decls::FnClause)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
    }))
}

/// The step machine of `TailTargets`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TailTargets: unbounded fn Lx, Text -> [Text]
/// ```
pub struct TailTargets {
    pub lx_p0: crate::lower::Lx,
    pub qk_p1: Text,
}

impl prism_rtl::Job<Array<Text>> for TailTargets {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let lx_p0 = &self.lx_p0;
        let qk_p1 = &self.qk_p1;
        let v_p2 = crate::prelude::or(&crate::prelude::get(&lx_p0.g_p.vals_p, qk_p1), &crate::check::env::builtin_f(qk_p1, &crate::check::types::schemes::mono_f(&crate::check::types::Ty::TyErr)));
        let lxm_p3 = in_module_f(lx_p0, &v_p2.file_p, &v_p2.home_p);
        crate::prelude::fold_job(crate::lower::jobs::clauses_of_f(&lx_p0.g_p, qk_p1), Array::new(), {
            let lxm_p3x = lxm_p3.clone();
            Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::decls::FnClause)| {
                let lxm_p3xy = lxm_p3x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let acc_p4 = p0;
                    let c_p5 = p1;
                    crate::prelude::call_then(start_tails_of_body_f(lxm_p3xy.clone(), c_p5.body_p.clone()), move |tails_of_body_f_20292: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_p4, &tails_of_body_f_20292)))
                }))
            }) as Rc<dyn Fn((Array<Text>, crate::syntax::decls::FnClause)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
        }).cycle()
    }
}

/// `Start TailTargets, x`: what the function value is when passed to `@Run`.
pub fn start_tail_targets_f(lx_p0: crate::lower::Lx, qk_p1: Text) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(TailTargets { lx_p0, qk_p1 })
}

/// ```prism
/// TailsOfBody: unbounded fn Lx, FnBody -> [Text]
/// ```
pub fn tails_of_body_f(lx_p0: &crate::lower::Lx, body_p1: &crate::syntax::decls::FnBody) -> Array<Text> {
    crate::prelude::fold(&crate::check::typed::print::body_exprs_f(body_p1), &Array::new(), &(|acc_p2: &Array<Text>, e_p3: &crate::syntax::Expr| match &*e_p3.kind_p {
        crate::syntax::ExprKind::ECall(c_p4, _, _, _) => {
            let q_p5 = blueprint_qk_f(lx_p0, &**c_p4);
            match crate::prelude::get(&lx_p0.g_p.vals_p, &q_p5) {
                Some(v_p6) => match &v_p6.scheme_p.ty_p {
                    crate::check::types::Ty::TyFn(crate::check::types::Col::CBound, _, _) => acc_p2.clone(),
                    crate::check::types::Ty::TyFn(_, _, _) => crate::check::types::add_text_f(acc_p2, &q_p5),
                    _ => acc_p2.clone(),
                },
                None => acc_p2.clone(),
            }
        },
        _ => acc_p2.clone(),
    }))
}

/// The step machine of `TailsOfBody`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TailsOfBody: unbounded fn Lx, FnBody -> [Text]
/// ```
pub struct TailsOfBody {
    pub lx_p0: crate::lower::Lx,
    pub body_p1: crate::syntax::decls::FnBody,
}

impl prism_rtl::Job<Array<Text>> for TailsOfBody {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let lx_p0 = &self.lx_p0;
        let body_p1 = &self.body_p1;
        let body_p1x = body_p1.clone();
        let lx_p0x = lx_p0.clone();
        crate::prelude::call_then(crate::check::typed::print::start_body_exprs_f(body_p1x.clone()), move |body_exprs_f_20397: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(crate::prelude::fold(&body_exprs_f_20397, &Array::new(), &(|acc_p2: &Array<Text>, e_p3: &crate::syntax::Expr| match &*e_p3.kind_p {
            crate::syntax::ExprKind::ECall(c_p4, _, _, _) => {
                let q_p5 = blueprint_qk_f(&lx_p0x, &**c_p4);
                match crate::prelude::get(&lx_p0x.g_p.vals_p, &q_p5) {
                    Some(v_p6) => match &v_p6.scheme_p.ty_p {
                        crate::check::types::Ty::TyFn(crate::check::types::Col::CBound, _, _) => acc_p2.clone(),
                        crate::check::types::Ty::TyFn(_, _, _) => crate::check::types::add_text_f(acc_p2, &q_p5),
                        _ => acc_p2.clone(),
                    },
                    None => acc_p2.clone(),
                }
            },
            _ => acc_p2.clone(),
        }))))
    }
}

/// `Start TailsOfBody, x`: what the function value is when passed to `@Run`.
pub fn start_tails_of_body_f(lx_p0: crate::lower::Lx, body_p1: crate::syntax::decls::FnBody) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(TailsOfBody { lx_p0, body_p1 })
}

/// ```prism
/// ModDefOf: unbounded fn Lx, Text, [((Text, Bool))], ModInfo, [Text] -> ModDef
/// ```
pub fn mod_def_of_f(lx0_p0: &crate::lower::Lx, m_p1: &Text, roots_p2: &Array<(Text, bool)>, info_p3: &crate::check::env::ModInfo, mods_p4: &Array<Text>) -> crate::lower::model::ModDef {
    let lx_p5 = in_module_f(lx0_p0, &info_p3.file_p, m_p1);
    let path_p6 = match crate::prelude::index(&lx_p5.g_p.srcs_p, &info_p3.file_p) {
        Some(src_pd) => src_pd.path_p.clone(),
        None => Text::lit(""),
    };
    let types_p7 = crate::prelude::run_to_end(crate::prelude::fold_job(crate::prelude::values(&lx_p5.g_p.types_p), Array::new(), {
        let m_p1x = m_p1.clone();
        let lx_p5x = lx_p5.clone();
        Rc::new(move |(p0, p1): (Array<crate::lower::model::Item>, crate::check::env::TyInfo)| {
            let m_p1xy = m_p1x.clone();
            let lx_p5xy = lx_p5x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_pe = p0;
                let ti_pf = p1;
                if &ti_pf.home_p == &m_p1xy {
                    crate::prelude::call_then(start_ty_defs_f(lx_p5xy.clone(), ti_pf.clone()), move |ty_defs_f_21122: Array<crate::lower::model::Item>| prism_rtl::Turn::Finished(crate::prelude::append(&acc_pe, &ty_defs_f_21122)))
                } else {
                    prism_rtl::Turn::Finished(acc_pe.clone())
                }
            }))
        }) as Rc<dyn Fn((Array<crate::lower::model::Item>, crate::check::env::TyInfo)) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Item>>>>
    }));
    let tags_p8 = crate::prelude::run_to_end(crate::prelude::fold_job(crate::prelude::values(&lx_p5.g_p.tags_p), Array::new(), {
        let m_p1x = m_p1.clone();
        let lx_p5x = lx_p5.clone();
        Rc::new(move |(p0, p1): (Array<crate::lower::model::Item>, crate::check::env::TagInfo)| {
            let m_p1xy = m_p1x.clone();
            let lx_p5xy = lx_p5x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_pg = p0;
                let tg_ph = p1;
                if (&tg_ph.home_p == &m_p1xy) && (&tg_ph.kind_p != &Text::lit("Prelude.Fault")) {
                    crate::prelude::call_then(start_tag_def_of_f(lx_p5xy.clone(), tg_ph.clone()), move |tag_def_of_f_21270: crate::lower::model::TagDef| prism_rtl::Turn::Finished(crate::prelude::push(&acc_pg, &crate::lower::model::Item::ItTag(tag_def_of_f_21270))))
                } else {
                    prism_rtl::Turn::Finished(acc_pg.clone())
                }
            }))
        }) as Rc<dyn Fn((Array<crate::lower::model::Item>, crate::check::env::TagInfo)) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Item>>>>
    }));
    let defs_p9 = crate::prelude::run_to_end(crate::prelude::fold_job(lx_p5.g_p.defs_p.clone(), Array::new(), {
        let m_p1x = m_p1.clone();
        let lx_p5x = lx_p5.clone();
        let roots_p2x = roots_p2.clone();
        Rc::new(move |(p0, p1): (Array<crate::lower::model::Item>, crate::check::env::Def)| {
            let m_p1xy = m_p1x.clone();
            let lx_p5xy = lx_p5x.clone();
            let roots_p2xy = roots_p2x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_pi = p0;
                let d_pj = p1;
                if &d_pj.home_p == &m_p1xy {
                    crate::prelude::call_then(start_def_items_f(in_module_f(&lx_p5xy, &d_pj.file_p, &m_p1xy), d_pj.clone(), roots_p2xy.clone()), move |def_items_f_21374: Array<crate::lower::model::Item>| prism_rtl::Turn::Finished(crate::prelude::append(&acc_pi, &def_items_f_21374)))
                } else {
                    prism_rtl::Turn::Finished(acc_pi.clone())
                }
            }))
        }) as Rc<dyn Fn((Array<crate::lower::model::Item>, crate::check::env::Def)) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Item>>>>
    }));
    let traits_pa = crate::prelude::run_to_end(crate::prelude::fold_job(crate::prelude::values(&lx_p5.g_p.traits_p), Array::new(), {
        let m_p1x = m_p1.clone();
        let lx_p5x = lx_p5.clone();
        Rc::new(move |(p0, p1): (Array<crate::lower::model::Item>, crate::check::env::TraitInfo)| {
            let m_p1xy = m_p1x.clone();
            let lx_p5xy = lx_p5x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_pk = p0;
                let tr_pl = p1;
                if &tr_pl.home_p == &m_p1xy {
                    crate::prelude::call_then(crate::lower::functions::start_trait_def_of_f(lx_p5xy.clone(), tr_pl.clone()), move |trait_def_of_f_21527: crate::lower::model::TraitDef| prism_rtl::Turn::Finished(crate::prelude::push(&acc_pk, &crate::lower::model::Item::ItTrait(trait_def_of_f_21527))))
                } else {
                    prism_rtl::Turn::Finished(acc_pk.clone())
                }
            }))
        }) as Rc<dyn Fn((Array<crate::lower::model::Item>, crate::check::env::TraitInfo)) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Item>>>>
    }));
    let impls_pb = crate::prelude::run_to_end(crate::prelude::fold_job(crate::prelude::values(&lx_p5.g_p.impls_p), Array::new(), {
        let m_p1x = m_p1.clone();
        let lx_p5x = lx_p5.clone();
        Rc::new(move |(p0, p1): (Array<crate::lower::model::Item>, Array<crate::check::env::ImplInfo>)| {
            let m_p1xy = m_p1x.clone();
            let lx_p5xy = lx_p5x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_pm = p0;
                let ims_pn = p1;
                crate::prelude::fold_job(ims_pn.clone(), acc_pm.clone(), {
                    let m_p1xyx = m_p1xy.clone();
                    let lx_p5xyx = lx_p5xy.clone();
                    Rc::new(move |(p0, p1): (Array<crate::lower::model::Item>, crate::check::env::ImplInfo)| {
                        let m_p1xyxy = m_p1xyx.clone();
                        let lx_p5xyxy = lx_p5xyx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let a_po = p0;
                            let im_pp = p1;
                            if (&im_pp.home_p == &m_p1xyxy) && !im_pp.derived_p {
                                crate::prelude::call_then(crate::lower::functions::start_impl_def_of_f(in_module_f(&lx_p5xyxy, &im_pp.file_p, &m_p1xyxy), im_pp.clone()), move |impl_def_of_f_21694: crate::lower::model::ImplDef| prism_rtl::Turn::Finished(crate::prelude::push(&a_po, &crate::lower::model::Item::ItImpl(impl_def_of_f_21694))))
                            } else {
                                prism_rtl::Turn::Finished(a_po.clone())
                            }
                        }))
                    }) as Rc<dyn Fn((Array<crate::lower::model::Item>, crate::check::env::ImplInfo)) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Item>>>>
                }).cycle()
            }))
        }) as Rc<dyn Fn((Array<crate::lower::model::Item>, Array<crate::check::env::ImplInfo>)) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Item>>>>
    }));
    let uses_pc = crate::prelude::filter(&crate::prelude::each(mods_p4, &(|o_pq: &Text| crate::lower::rust_mod_name_f(o_pq))), &(|o_pr: &Text| o_pr != &crate::lower::rust_mod_name_f(m_p1)));
    crate::lower::model::ModDef { name_p: crate::lower::rust_mod_name_f(m_p1), prism_p: m_p1.clone(), path_p: path_p6.clone(), uses_p: uses_pc.clone(), complete_p: Array::new(), declared_p: Array::new(), types_with_p: Array::new(), items_p: crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&types_p7, &tags_p8), &traits_pa), &impls_pb), &defs_p9) }
}

/// The step machine of `ModDefOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ModDefOf: unbounded fn Lx, Text, [((Text, Bool))], ModInfo, [Text] -> ModDef
/// ```
pub struct ModDefOf {
    pub lx0_p0: crate::lower::Lx,
    pub m_p1: Text,
    pub roots_p2: Array<(Text, bool)>,
    pub info_p3: crate::check::env::ModInfo,
    pub mods_p4: Array<Text>,
}

impl prism_rtl::Job<crate::lower::model::ModDef> for ModDefOf {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::ModDef> {
        let lx0_p0 = &self.lx0_p0;
        let m_p1 = &self.m_p1;
        let roots_p2 = &self.roots_p2;
        let info_p3 = &self.info_p3;
        let mods_p4 = &self.mods_p4;
        let lx_p5 = in_module_f(lx0_p0, &info_p3.file_p, m_p1);
        let path_p6 = match crate::prelude::index(&lx_p5.g_p.srcs_p, &info_p3.file_p) {
            Some(src_pd) => src_pd.path_p.clone(),
            None => Text::lit(""),
        };
        let m_p1x = m_p1.clone();
        let mods_p4x = mods_p4.clone();
        let roots_p2x = roots_p2.clone();
        crate::prelude::call_value(crate::prelude::fold_job(crate::prelude::values(&lx_p5.g_p.types_p), Array::new(), {
            let m_p1xx = m_p1x.clone();
            let lx_p5x = lx_p5.clone();
            Rc::new(move |(p0, p1): (Array<crate::lower::model::Item>, crate::check::env::TyInfo)| {
                let m_p1xxy = m_p1xx.clone();
                let lx_p5xy = lx_p5x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let acc_pe = p0;
                    let ti_pf = p1;
                    if &ti_pf.home_p == &m_p1xxy {
                        crate::prelude::call_then(start_ty_defs_f(lx_p5xy.clone(), ti_pf.clone()), move |ty_defs_f_21122: Array<crate::lower::model::Item>| prism_rtl::Turn::Finished(crate::prelude::append(&acc_pe, &ty_defs_f_21122)))
                    } else {
                        prism_rtl::Turn::Finished(acc_pe.clone())
                    }
                }))
            }) as Rc<dyn Fn((Array<crate::lower::model::Item>, crate::check::env::TyInfo)) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Item>>>>
        }), move |fold_21049: Array<crate::lower::model::Item>| {
            let types_p7 = fold_21049;
            crate::prelude::call_value(crate::prelude::fold_job(crate::prelude::values(&lx_p5.g_p.tags_p), Array::new(), {
                let m_p1xx = m_p1x.clone();
                let lx_p5x = lx_p5.clone();
                Rc::new(move |(p0, p1): (Array<crate::lower::model::Item>, crate::check::env::TagInfo)| {
                    let m_p1xxy = m_p1xx.clone();
                    let lx_p5xy = lx_p5x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let acc_pg = p0;
                        let tg_ph = p1;
                        if (&tg_ph.home_p == &m_p1xxy) && (&tg_ph.kind_p != &Text::lit("Prelude.Fault")) {
                            crate::prelude::call_then(start_tag_def_of_f(lx_p5xy.clone(), tg_ph.clone()), move |tag_def_of_f_21270: crate::lower::model::TagDef| prism_rtl::Turn::Finished(crate::prelude::push(&acc_pg, &crate::lower::model::Item::ItTag(tag_def_of_f_21270))))
                        } else {
                            prism_rtl::Turn::Finished(acc_pg.clone())
                        }
                    }))
                }) as Rc<dyn Fn((Array<crate::lower::model::Item>, crate::check::env::TagInfo)) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Item>>>>
            }), move |fold_21162: Array<crate::lower::model::Item>| {
                let tags_p8 = fold_21162;
                crate::prelude::call_value(crate::prelude::fold_job(lx_p5.g_p.defs_p.clone(), Array::new(), {
                    let m_p1xx = m_p1x.clone();
                    let lx_p5x = lx_p5.clone();
                    let roots_p2xx = roots_p2x.clone();
                    Rc::new(move |(p0, p1): (Array<crate::lower::model::Item>, crate::check::env::Def)| {
                        let m_p1xxy = m_p1xx.clone();
                        let lx_p5xy = lx_p5x.clone();
                        let roots_p2xxy = roots_p2xx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let acc_pi = p0;
                            let d_pj = p1;
                            if &d_pj.home_p == &m_p1xxy {
                                crate::prelude::call_then(start_def_items_f(in_module_f(&lx_p5xy, &d_pj.file_p, &m_p1xxy), d_pj.clone(), roots_p2xxy.clone()), move |def_items_f_21374: Array<crate::lower::model::Item>| prism_rtl::Turn::Finished(crate::prelude::append(&acc_pi, &def_items_f_21374)))
                            } else {
                                prism_rtl::Turn::Finished(acc_pi.clone())
                            }
                        }))
                    }) as Rc<dyn Fn((Array<crate::lower::model::Item>, crate::check::env::Def)) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Item>>>>
                }), move |fold_21313: Array<crate::lower::model::Item>| {
                    let defs_p9 = fold_21313;
                    crate::prelude::call_value(crate::prelude::fold_job(crate::prelude::values(&lx_p5.g_p.traits_p), Array::new(), {
                        let m_p1xx = m_p1x.clone();
                        let lx_p5x = lx_p5.clone();
                        Rc::new(move |(p0, p1): (Array<crate::lower::model::Item>, crate::check::env::TraitInfo)| {
                            let m_p1xxy = m_p1xx.clone();
                            let lx_p5xy = lx_p5x.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let acc_pk = p0;
                                let tr_pl = p1;
                                if &tr_pl.home_p == &m_p1xxy {
                                    crate::prelude::call_then(crate::lower::functions::start_trait_def_of_f(lx_p5xy.clone(), tr_pl.clone()), move |trait_def_of_f_21527: crate::lower::model::TraitDef| prism_rtl::Turn::Finished(crate::prelude::push(&acc_pk, &crate::lower::model::Item::ItTrait(trait_def_of_f_21527))))
                                } else {
                                    prism_rtl::Turn::Finished(acc_pk.clone())
                                }
                            }))
                        }) as Rc<dyn Fn((Array<crate::lower::model::Item>, crate::check::env::TraitInfo)) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Item>>>>
                    }), move |fold_21446: Array<crate::lower::model::Item>| {
                        let traits_pa = fold_21446;
                        crate::prelude::call_value(crate::prelude::fold_job(crate::prelude::values(&lx_p5.g_p.impls_p), Array::new(), {
                            let m_p1xx = m_p1x.clone();
                            let lx_p5x = lx_p5.clone();
                            Rc::new(move |(p0, p1): (Array<crate::lower::model::Item>, Array<crate::check::env::ImplInfo>)| {
                                let m_p1xxy = m_p1xx.clone();
                                let lx_p5xy = lx_p5x.clone();
                                crate::prelude::entered(crate::prelude::once_job(move || {
                                    let acc_pm = p0;
                                    let ims_pn = p1;
                                    crate::prelude::fold_job(ims_pn.clone(), acc_pm.clone(), {
                                        let m_p1xxyx = m_p1xxy.clone();
                                        let lx_p5xyx = lx_p5xy.clone();
                                        Rc::new(move |(p0, p1): (Array<crate::lower::model::Item>, crate::check::env::ImplInfo)| {
                                            let m_p1xxyxy = m_p1xxyx.clone();
                                            let lx_p5xyxy = lx_p5xyx.clone();
                                            crate::prelude::entered(crate::prelude::once_job(move || {
                                                let a_po = p0;
                                                let im_pp = p1;
                                                if (&im_pp.home_p == &m_p1xxyxy) && !im_pp.derived_p {
                                                    crate::prelude::call_then(crate::lower::functions::start_impl_def_of_f(in_module_f(&lx_p5xyxy, &im_pp.file_p, &m_p1xxyxy), im_pp.clone()), move |impl_def_of_f_21694: crate::lower::model::ImplDef| prism_rtl::Turn::Finished(crate::prelude::push(&a_po, &crate::lower::model::Item::ItImpl(impl_def_of_f_21694))))
                                                } else {
                                                    prism_rtl::Turn::Finished(a_po.clone())
                                                }
                                            }))
                                        }) as Rc<dyn Fn((Array<crate::lower::model::Item>, crate::check::env::ImplInfo)) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Item>>>>
                                    }).cycle()
                                }))
                            }) as Rc<dyn Fn((Array<crate::lower::model::Item>, Array<crate::check::env::ImplInfo>)) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Item>>>>
                        }), move |fold_21573: Array<crate::lower::model::Item>| {
                            let impls_pb = fold_21573;
                            let uses_pc = crate::prelude::filter(&crate::prelude::each(&mods_p4x, &(|o_pq: &Text| crate::lower::rust_mod_name_f(o_pq))), &(|o_pr: &Text| o_pr != &crate::lower::rust_mod_name_f(&m_p1x)));
                            prism_rtl::Turn::Finished(crate::lower::model::ModDef { name_p: crate::lower::rust_mod_name_f(&m_p1x), prism_p: m_p1x.clone(), path_p: path_p6.clone(), uses_p: uses_pc.clone(), complete_p: Array::new(), declared_p: Array::new(), types_with_p: Array::new(), items_p: crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&types_p7, &tags_p8), &traits_pa), &impls_pb), &defs_p9) })
                        })
                    })
                })
            })
        })
    }
}

/// `Start ModDefOf, x`: what the function value is when passed to `@Run`.
pub fn start_mod_def_of_f(lx0_p0: crate::lower::Lx, m_p1: Text, roots_p2: Array<(Text, bool)>, info_p3: crate::check::env::ModInfo, mods_p4: Array<Text>) -> Rc<dyn prism_rtl::Job<crate::lower::model::ModDef>> {
    Rc::new(ModDefOf { lx0_p0, m_p1, roots_p2, info_p3, mods_p4 })
}

/// ```prism
/// DefItems: unbounded fn Lx, Def, [((Text, Bool))] -> [Item]
/// ```
pub fn def_items_f(lx_p0: &crate::lower::Lx, d_p1: &crate::check::env::Def, roots_p2: &Array<(Text, bool)>) -> Array<crate::lower::model::Item> {
    let is_root_p3 = crate::check::types::has_text_f(&crate::prelude::each(roots_p2, &(|(q_p4, _): &(Text, bool)| q_p4.clone())), &d_p1.qk_p);
    match &d_p1.body_p {
        crate::check::env::DefBody::DbWidget(w_p5) => if is_root_p3 {
            node_items_f(&crate::lower::node_::def::node_def_of_f(lx_p0, &d_p1.qk_p, &Array::new(), &w_p5.body_p, &crate::prelude::or(&crate::prelude::get(&lx_p0.g_p.vals_p, &d_p1.qk_p), &crate::check::env::builtin_f(&d_p1.qk_p, &crate::check::types::schemes::mono_f(&crate::check::types::Ty::TyErr))).scheme_p, &true))
        } else {
            Array::from(vec![crate::lower::model::Item::ItNote(Text::from(format!("`{}` is inlined where it is applied.", &d_p1.name_p)))])
        },
        crate::check::env::DefBody::DbFn(clauses_p6) => match crate::prelude::get(&lx_p0.g_p.vals_p, &d_p1.qk_p) {
            None => Array::new(),
            Some(v_p7) => 'm22612: {
                let scrutinee = &v_p7.scheme_p.ty_p;
                if let crate::check::types::Ty::TyFn(_, _, m22612_0_2) = scrutinee && let crate::check::types::Ty::TyAt(_, _) = &**m22612_0_2 {
                    break 'm22612 if !is_root_p3 {
                        Array::from(vec![crate::lower::model::Item::ItNote(Text::from(format!("`{}` is inlined where it is applied.", &d_p1.name_p)))])
                    } else {
                        'm22808: {
                            if let m22808_0 = clauses_p6 && (m22808_0.len() == 1) && let Some(c_p8) = crate::prelude::index(m22808_0, &Nat::from(0u32)) {
                                break 'm22808 match &c_p8.body_p {
                                    crate::syntax::decls::FnBody::BodyBlock(b_p9) => node_items_f(&crate::lower::node_::def::node_def_of_f(lx_p0, &d_p1.qk_p, &c_p8.params_p, b_p9, &v_p7.scheme_p, &true)),
                                    _ => Array::from(vec![crate::lower::model::Item::ItRefused(Text::from(format!("`{}`, a root widget whose body is one expression", &d_p1.name_p)))]),
                                };
                            }
                            Array::from(vec![crate::lower::model::Item::ItRefused(Text::from(format!("`{}`, a root widget of several clauses", &d_p1.name_p)))])
                        }
                    };
                }
                {
                    let f_pa = crate::lower::model::Item::ItFn(crate::lower::functions::fn_def_of_f(lx_p0, &d_p1.qk_p, clauses_p6, &v_p7.scheme_p));
                    if crate::check::types::has_text_f(&lx_p0.unbs_p, &d_p1.qk_p) {
                        Array::from(vec![f_pa.clone(), crate::lower::model::Item::ItJob(crate::lower::jobs::job_def_of_f(lx_p0, &d_p1.qk_p, clauses_p6, &v_p7.scheme_p))])
                    } else {
                        Array::from(vec![f_pa.clone()])
                    }
                }
            },
        },
        crate::check::env::DefBody::DbLet(l_pb) => Array::from(vec![crate::lower::model::Item::ItFn(crate::lower::functions::let_getter_f(lx_p0, &d_p1.qk_p, l_pb))]),
        _ => Array::new(),
    }
}

/// The step machine of `DefItems`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// DefItems: unbounded fn Lx, Def, [((Text, Bool))] -> [Item]
/// ```
pub struct DefItems {
    pub lx_p0: crate::lower::Lx,
    pub d_p1: crate::check::env::Def,
    pub roots_p2: Array<(Text, bool)>,
}

impl prism_rtl::Job<Array<crate::lower::model::Item>> for DefItems {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::lower::model::Item>> {
        let lx_p0 = &self.lx_p0;
        let d_p1 = &self.d_p1;
        let roots_p2 = &self.roots_p2;
        let is_root_p3 = crate::check::types::has_text_f(&crate::prelude::each(roots_p2, &(|(q_p4, _): &(Text, bool)| q_p4.clone())), &d_p1.qk_p);
        match &d_p1.body_p {
            crate::check::env::DefBody::DbWidget(w_p5) => if is_root_p3 {
                {
                    let d_p1x = d_p1.clone();
                    let lx_p0x = lx_p0.clone();
                    let w_p5x = w_p5.clone();
                    crate::prelude::call_then(crate::lower::node_::def::start_node_def_of_f(lx_p0x.clone(), d_p1x.qk_p.clone(), Array::new(), w_p5x.body_p.clone(), crate::prelude::or(&crate::prelude::get(&lx_p0x.g_p.vals_p, &d_p1x.qk_p), &crate::check::env::builtin_f(&d_p1x.qk_p, &crate::check::types::schemes::mono_f(&crate::check::types::Ty::TyErr))).scheme_p.clone(), true), move |node_def_of_f_22355: crate::lower::model::NodeDef| prism_rtl::Turn::Finished(node_items_f(&node_def_of_f_22355)))
                }
            } else {
                prism_rtl::Turn::Finished(Array::from(vec![crate::lower::model::Item::ItNote(Text::from(format!("`{}` is inlined where it is applied.", &d_p1.name_p)))]))
            },
            crate::check::env::DefBody::DbFn(clauses_p6) => match crate::prelude::get(&lx_p0.g_p.vals_p, &d_p1.qk_p) {
                None => prism_rtl::Turn::Finished(Array::new()),
                Some(v_p7) => 'm22612: {
                    let scrutinee = &v_p7.scheme_p.ty_p;
                    if let crate::check::types::Ty::TyFn(_, _, m22612_0_2) = scrutinee && let crate::check::types::Ty::TyAt(_, _) = &**m22612_0_2 {
                        break 'm22612 if !is_root_p3 {
                            prism_rtl::Turn::Finished(Array::from(vec![crate::lower::model::Item::ItNote(Text::from(format!("`{}` is inlined where it is applied.", &d_p1.name_p)))]))
                        } else {
                            'm22808: {
                                if let m22808_0 = clauses_p6 && (m22808_0.len() == 1) && let Some(c_p8) = crate::prelude::index(m22808_0, &Nat::from(0u32)) {
                                    break 'm22808 match &c_p8.body_p {
                                        crate::syntax::decls::FnBody::BodyBlock(b_p9) => {
                                            let b_p9x = b_p9.clone();
                                            let d_p1x = d_p1.clone();
                                            let lx_p0x = lx_p0.clone();
                                            crate::prelude::call_then(crate::lower::node_::def::start_node_def_of_f(lx_p0x.clone(), d_p1x.qk_p.clone(), c_p8.params_p.clone(), b_p9x.clone(), v_p7.scheme_p.clone(), true), move |node_def_of_f_22920: crate::lower::model::NodeDef| prism_rtl::Turn::Finished(node_items_f(&node_def_of_f_22920)))
                                        },
                                        _ => prism_rtl::Turn::Finished(Array::from(vec![crate::lower::model::Item::ItRefused(Text::from(format!("`{}`, a root widget whose body is one expression", &d_p1.name_p)))])),
                                    };
                                }
                                prism_rtl::Turn::Finished(Array::from(vec![crate::lower::model::Item::ItRefused(Text::from(format!("`{}`, a root widget of several clauses", &d_p1.name_p)))]))
                            }
                        };
                    }
                    {
                        let clauses_p6x = clauses_p6.clone();
                        let d_p1x = d_p1.clone();
                        let lx_p0x = lx_p0.clone();
                        crate::prelude::call_then(crate::lower::functions::start_fn_def_of_f(lx_p0x.clone(), d_p1x.qk_p.clone(), clauses_p6x.clone(), v_p7.scheme_p.clone()), move |fn_def_of_f_23236: crate::lower::model::FnDef| {
                            let f_pa = crate::lower::model::Item::ItFn(fn_def_of_f_23236);
                            if crate::check::types::has_text_f(&lx_p0x.unbs_p, &d_p1x.qk_p) {
                                crate::prelude::call_then(crate::lower::jobs::start_job_def_of_f(lx_p0x.clone(), d_p1x.qk_p.clone(), clauses_p6x.clone(), v_p7.scheme_p.clone()), move |job_def_of_f_23331: crate::lower::model::JobDef| prism_rtl::Turn::Finished(Array::from(vec![f_pa.clone(), crate::lower::model::Item::ItJob(job_def_of_f_23331)])))
                            } else {
                                prism_rtl::Turn::Finished(Array::from(vec![f_pa.clone()]))
                            }
                        })
                    }
                },
            },
            crate::check::env::DefBody::DbLet(l_pb) => {
                let d_p1x = d_p1.clone();
                let l_pbx = l_pb.clone();
                let lx_p0x = lx_p0.clone();
                crate::prelude::call_then(crate::lower::functions::start_let_getter_f(lx_p0x.clone(), d_p1x.qk_p.clone(), l_pbx.clone()), move |let_getter_f_23408: crate::lower::model::FnDef| prism_rtl::Turn::Finished(Array::from(vec![crate::lower::model::Item::ItFn(let_getter_f_23408)])))
            },
            _ => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start DefItems, x`: what the function value is when passed to `@Run`.
pub fn start_def_items_f(lx_p0: crate::lower::Lx, d_p1: crate::check::env::Def, roots_p2: Array<(Text, bool)>) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Item>>> {
    Rc::new(DefItems { lx_p0, d_p1, roots_p2 })
}

/// ```prism
/// NodeItems: fn NodeDef -> [Item]
/// ```
pub fn node_items_f(n_p0: &crate::lower::model::NodeDef) -> Array<crate::lower::model::Item> {
    crate::prelude::append(&Array::from(vec![crate::lower::model::Item::ItNode(n_p0.clone())]), &crate::prelude::each(&n_p0.children_p, &(|c_p1: &crate::lower::model::NodeDef| crate::lower::model::Item::ItNode(c_p1.clone()))))
}

/// ```prism
/// TyDefs: unbounded fn Lx, TyInfo -> [Item]
/// ```
pub fn ty_defs_f(lx_p0: &crate::lower::Lx, ti_p1: &crate::check::env::TyInfo) -> Array<crate::lower::model::Item> {
    let derives_p2 = crate::prelude::fold(&ti_p1.derives_p, &Array::new(), &(|acc_p6: &Array<Text>, dn_p7: &Text| match crate::check::env::names::resolve_trait_o(&lx_p0.g_p, &ti_p1.home_p, &crate::prelude::split_on(dn_p7, &Text::lit("."))) {
        Some(cls_p8) => crate::prelude::push(acc_p6, &cls_p8),
        None => acc_p6.clone(),
    }));
    let params_p3 = crate::prelude::each(&ti_p1.params_p, &(|p_p9: &Text| crate::lower::camel_f(p_p9)));
    let bare_p4 = crate::check::types::bare_name_f(&ti_p1.name_p);
    let mk_f5 = {
        let bare_p4x = bare_p4.clone();
        let params_p3x = params_p3.clone();
        let derives_p2x = derives_p2.clone();
        let lx_p0x = lx_p0.clone();
        let ti_p1x = ti_p1.clone();
        Rc::new(move |(p0, p1): (crate::lower::model::TyShape, Array<crate::lower::model::CaseDef>)| {
            let bare_p4xy = bare_p4x.clone();
            let params_p3xy = params_p3x.clone();
            let derives_p2xy = derives_p2x.clone();
            let lx_p0xy = lx_p0x.clone();
            let ti_p1xy = ti_p1x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let shape_pa = p0;
                let cases_pb = p1;
                crate::prelude::call_then(start_ty_podable_f(lx_p0xy.clone(), crate::check::types::Ty::TyCon(ti_p1xy.name_p.clone(), Array::new()), Array::new()), move |ty_podable_f_24340: bool| prism_rtl::Turn::Finished(crate::lower::model::TyDef { name_p: crate::lower::camel_f(&bare_p4xy), prism_p: bare_p4xy.clone(), params_p: params_p3xy.clone(), shape_p: shape_pa.clone(), cases_p: cases_pb.clone(), eq_p: crate::check::types::has_text_f(&derives_p2xy, &Text::lit("Prelude.Eq")), ord_p: crate::check::types::has_text_f(&derives_p2xy, &Text::lit("Prelude.Ord")), show_p: if crate::lower::functions::has_own_show_f(&lx_p0xy, &ti_p1xy.name_p) {
                    crate::lower::model::Shown::ShownOwn
                } else {
                    if crate::check::types::has_text_f(&derives_p2xy, &Text::lit("Prelude.Show")) {
                        crate::lower::model::Shown::ShownDerived
                    } else {
                        crate::lower::model::Shown::NotShown
                    }
                }, pod_p: ty_podable_f_24340 && crate::prelude::run_to_end(crate::prelude::fold_job(cases_pb.clone(), true, Rc::new(move |(p0, p1): (bool, crate::lower::model::CaseDef)| crate::prelude::entered(crate::prelude::once_job(move || {
                    let ok_pc = p0;
                    let c_pd = p1;
                    prism_rtl::Turn::Finished(ok_pc && crate::prelude::run_to_end(crate::prelude::fold_job(c_pd.fields_p.clone(), true, Rc::new(move |(p0, p1): (bool, (Text, crate::lower::model::OutTy))| crate::prelude::entered(crate::prelude::once_job(move || {
                        let ok2_pe = p0;
                        let (_, ft_pf) = p1;
                        prism_rtl::Turn::Finished(ok2_pe && crate::lower::types::podable_f(&ft_pf))
                    }))) as Rc<dyn Fn((bool, (Text, crate::lower::model::OutTy))) -> Rc<dyn prism_rtl::Job<bool>>>)))
                }))) as Rc<dyn Fn((bool, crate::lower::model::CaseDef)) -> Rc<dyn prism_rtl::Job<bool>>>)), doc_p: type_doc_f(&lx_p0xy, &ti_p1xy) }))
            }))
        }) as Rc<dyn Fn((crate::lower::model::TyShape, Array<crate::lower::model::CaseDef>)) -> Rc<dyn prism_rtl::Job<crate::lower::model::TyDef>>>
    };
    match &ti_p1.body_p {
        crate::check::env::TyBody::BRecord(fs_pg) => {
            let fields_ph = crate::prelude::run_to_end(crate::prelude::each_job(crate::check::errors::range0_f(&crate::prelude::len(fs_pg)), {
                let fs_pgx = fs_pg.clone();
                let lx_p0x = lx_p0.clone();
                let ti_p1x = ti_p1.clone();
                Rc::new(move |p0: Nat| {
                    let fs_pgxy = fs_pgx.clone();
                    let lx_p0xy = lx_p0x.clone();
                    let ti_p1xy = ti_p1x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let i_pi = p0;
                        {
                            let (fname_pk, ft_pl) = crate::prelude::or(&crate::prelude::index(&fs_pgxy, &i_pi), &(Text::lit(""), crate::check::types::Ty::TyErr));
                            crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0xy.clone(), ft_pl.clone()), move |out_ty_of_f_24686: crate::lower::model::OutTy| {
                                let rt_pj = out_ty_of_f_24686;
                                crate::prelude::call_then(crate::lower::start_field_spell_f(ti_p1xy.home_p.clone(), fname_pk.clone(), ft_pl.clone()), move |field_spell_f_24720: Text| prism_rtl::Turn::Finished((field_spell_f_24720, if crate::lower::types::rc_field_f(&lx_p0xy, &ti_p1xy.name_p, &i_pi) {
                                    crate::lower::model::OutTy::OutRc(Rc::new(rt_pj.clone()))
                                } else {
                                    rt_pj.clone()
                                })))
                            })
                        }
                    }))
                }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<(Text, crate::lower::model::OutTy)>>>
            }));
            Array::from(vec![crate::lower::model::Item::ItType(crate::prelude::run_to_end((&mk_f5)((crate::lower::model::TyShape::ShapeRecord, Array::from(vec![crate::lower::model::CaseDef { name_p: crate::lower::camel_f(&bare_p4), prism_p: bare_p4.clone(), fields_p: fields_ph.clone(), labels_p: crate::prelude::each(fs_pg, &(|(fname_pm, _): &(Text, crate::check::types::Ty)| fname_pm.clone())) }])))))])
        },
        crate::check::env::TyBody::BChoice(cases_pn) => {
            let defs_po = crate::prelude::run_to_end(crate::prelude::each_job(cases_pn.clone(), {
                let ti_p1x = ti_p1.clone();
                let lx_p0x = lx_p0.clone();
                Rc::new(move |p0: (Text, Array<crate::check::types::Ty>)| {
                    let ti_p1xy = ti_p1x.clone();
                    let lx_p0xy = lx_p0x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let (cn_pq, ats_pr) = p0;
                        {
                            let ck_ps = crate::check::env::qual_key_f(&ti_p1xy.home_p, &cn_pq);
                            crate::prelude::call_value(crate::prelude::each_job(crate::check::errors::range0_f(&crate::prelude::len(&ats_pr)), {
                                let lx_p0xyx = lx_p0xy.clone();
                                let ck_psx = ck_ps.clone();
                                let ats_prx = ats_pr.clone();
                                Rc::new(move |p0: Nat| {
                                    let lx_p0xyxy = lx_p0xyx.clone();
                                    let ck_psxy = ck_psx.clone();
                                    let ats_prxy = ats_prx.clone();
                                    crate::prelude::entered(crate::prelude::once_job(move || {
                                        let i_pt = p0;
                                        crate::prelude::call_then(start_case_field_f(lx_p0xyxy.clone(), ck_psxy.clone(), i_pt.clone(), crate::prelude::or(&crate::prelude::index(&ats_prxy, &i_pt), &crate::check::types::Ty::TyErr)), move |case_field_f_25160: crate::lower::model::OutTy| prism_rtl::Turn::Finished((Text::lit(""), case_field_f_25160)))
                                    }))
                                }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<(Text, crate::lower::model::OutTy)>>>
                            }), move |each_25123: Array<(Text, crate::lower::model::OutTy)>| prism_rtl::Turn::Finished(crate::lower::model::CaseDef { name_p: crate::lower::camel_f(&cn_pq), prism_p: cn_pq.clone(), fields_p: each_25123, labels_p: Array::new() }))
                        }
                    }))
                }) as Rc<dyn Fn((Text, Array<crate::check::types::Ty>)) -> Rc<dyn prism_rtl::Job<crate::lower::model::CaseDef>>>
            }));
            let shape_pp = 'm25242: {
                if let m25242_0 = cases_pn && (m25242_0.len() == 1) && let Some((cn_pu, m25242_0_0_1)) = crate::prelude::index(m25242_0, &Nat::from(0u32)) && ((&m25242_0_0_1).len() == 0) {
                    break 'm25242 if crate::check::env::is_lower_text_f(&cn_pu) {
                        crate::lower::model::TyShape::ShapeUnit
                    } else {
                        crate::lower::model::TyShape::ShapeChoice
                    };
                }
                if let m25242_1 = cases_pn && (m25242_1.len() == 1) && let Some((cn_pv, _)) = crate::prelude::index(m25242_1, &Nat::from(0u32)) {
                    break 'm25242 if &cn_pv == &bare_p4 {
                        crate::lower::model::TyShape::ShapeNewtype
                    } else {
                        crate::lower::model::TyShape::ShapeChoice
                    };
                }
                crate::lower::model::TyShape::ShapeChoice
            };
            Array::from(vec![crate::lower::model::Item::ItType(crate::prelude::run_to_end((&mk_f5)((shape_pp.clone(), defs_po.clone()))))])
        },
        crate::check::env::TyBody::BRowKind => if &ti_p1.name_p == &Text::lit("Prelude.Fault") {
            Array::new()
        } else {
            Array::from(vec![crate::lower::model::Item::ItRow(row_def_of_f(lx_p0, ti_p1))])
        },
        _ => Array::new(),
    }
}

/// The step machine of `TyDefs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TyDefs: unbounded fn Lx, TyInfo -> [Item]
/// ```
pub struct TyDefs {
    pub lx_p0: crate::lower::Lx,
    pub ti_p1: crate::check::env::TyInfo,
}

impl prism_rtl::Job<Array<crate::lower::model::Item>> for TyDefs {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::lower::model::Item>> {
        let lx_p0 = &self.lx_p0;
        let ti_p1 = &self.ti_p1;
        let derives_p2 = crate::prelude::fold(&ti_p1.derives_p, &Array::new(), &(|acc_p6: &Array<Text>, dn_p7: &Text| match crate::check::env::names::resolve_trait_o(&lx_p0.g_p, &ti_p1.home_p, &crate::prelude::split_on(dn_p7, &Text::lit("."))) {
            Some(cls_p8) => crate::prelude::push(acc_p6, &cls_p8),
            None => acc_p6.clone(),
        }));
        let params_p3 = crate::prelude::each(&ti_p1.params_p, &(|p_p9: &Text| crate::lower::camel_f(p_p9)));
        let bare_p4 = crate::check::types::bare_name_f(&ti_p1.name_p);
        let mk_f5 = {
            let bare_p4x = bare_p4.clone();
            let params_p3x = params_p3.clone();
            let derives_p2x = derives_p2.clone();
            let lx_p0x = lx_p0.clone();
            let ti_p1x = ti_p1.clone();
            Rc::new(move |(p0, p1): (crate::lower::model::TyShape, Array<crate::lower::model::CaseDef>)| {
                let bare_p4xy = bare_p4x.clone();
                let params_p3xy = params_p3x.clone();
                let derives_p2xy = derives_p2x.clone();
                let lx_p0xy = lx_p0x.clone();
                let ti_p1xy = ti_p1x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let shape_pa = p0;
                    let cases_pb = p1;
                    crate::prelude::call_then(start_ty_podable_f(lx_p0xy.clone(), crate::check::types::Ty::TyCon(ti_p1xy.name_p.clone(), Array::new()), Array::new()), move |ty_podable_f_24340: bool| prism_rtl::Turn::Finished(crate::lower::model::TyDef { name_p: crate::lower::camel_f(&bare_p4xy), prism_p: bare_p4xy.clone(), params_p: params_p3xy.clone(), shape_p: shape_pa.clone(), cases_p: cases_pb.clone(), eq_p: crate::check::types::has_text_f(&derives_p2xy, &Text::lit("Prelude.Eq")), ord_p: crate::check::types::has_text_f(&derives_p2xy, &Text::lit("Prelude.Ord")), show_p: if crate::lower::functions::has_own_show_f(&lx_p0xy, &ti_p1xy.name_p) {
                        crate::lower::model::Shown::ShownOwn
                    } else {
                        if crate::check::types::has_text_f(&derives_p2xy, &Text::lit("Prelude.Show")) {
                            crate::lower::model::Shown::ShownDerived
                        } else {
                            crate::lower::model::Shown::NotShown
                        }
                    }, pod_p: ty_podable_f_24340 && crate::prelude::run_to_end(crate::prelude::fold_job(cases_pb.clone(), true, Rc::new(move |(p0, p1): (bool, crate::lower::model::CaseDef)| crate::prelude::entered(crate::prelude::once_job(move || {
                        let ok_pc = p0;
                        let c_pd = p1;
                        prism_rtl::Turn::Finished(ok_pc && crate::prelude::run_to_end(crate::prelude::fold_job(c_pd.fields_p.clone(), true, Rc::new(move |(p0, p1): (bool, (Text, crate::lower::model::OutTy))| crate::prelude::entered(crate::prelude::once_job(move || {
                            let ok2_pe = p0;
                            let (_, ft_pf) = p1;
                            prism_rtl::Turn::Finished(ok2_pe && crate::lower::types::podable_f(&ft_pf))
                        }))) as Rc<dyn Fn((bool, (Text, crate::lower::model::OutTy))) -> Rc<dyn prism_rtl::Job<bool>>>)))
                    }))) as Rc<dyn Fn((bool, crate::lower::model::CaseDef)) -> Rc<dyn prism_rtl::Job<bool>>>)), doc_p: type_doc_f(&lx_p0xy, &ti_p1xy) }))
                }))
            }) as Rc<dyn Fn((crate::lower::model::TyShape, Array<crate::lower::model::CaseDef>)) -> Rc<dyn prism_rtl::Job<crate::lower::model::TyDef>>>
        };
        match &ti_p1.body_p {
            crate::check::env::TyBody::BRecord(fs_pg) => {
                let fs_pgx = fs_pg.clone();
                let lx_p0x = lx_p0.clone();
                let ti_p1x = ti_p1.clone();
                crate::prelude::call_value(crate::prelude::each_job(crate::check::errors::range0_f(&crate::prelude::len(&fs_pgx)), {
                    let fs_pgxx = fs_pgx.clone();
                    let lx_p0xx = lx_p0x.clone();
                    let ti_p1xx = ti_p1x.clone();
                    Rc::new(move |p0: Nat| {
                        let fs_pgxxy = fs_pgxx.clone();
                        let lx_p0xxy = lx_p0xx.clone();
                        let ti_p1xxy = ti_p1xx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let i_pi = p0;
                            {
                                let (fname_pk, ft_pl) = crate::prelude::or(&crate::prelude::index(&fs_pgxxy, &i_pi), &(Text::lit(""), crate::check::types::Ty::TyErr));
                                crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0xxy.clone(), ft_pl.clone()), move |out_ty_of_f_24686: crate::lower::model::OutTy| {
                                    let rt_pj = out_ty_of_f_24686;
                                    crate::prelude::call_then(crate::lower::start_field_spell_f(ti_p1xxy.home_p.clone(), fname_pk.clone(), ft_pl.clone()), move |field_spell_f_24720: Text| prism_rtl::Turn::Finished((field_spell_f_24720, if crate::lower::types::rc_field_f(&lx_p0xxy, &ti_p1xxy.name_p, &i_pi) {
                                        crate::lower::model::OutTy::OutRc(Rc::new(rt_pj.clone()))
                                    } else {
                                        rt_pj.clone()
                                    })))
                                })
                            }
                        }))
                    }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<(Text, crate::lower::model::OutTy)>>>
                }), move |each_24572: Array<(Text, crate::lower::model::OutTy)>| {
                    let fields_ph = each_24572;
                    crate::prelude::call_value((&mk_f5)((crate::lower::model::TyShape::ShapeRecord, Array::from(vec![crate::lower::model::CaseDef { name_p: crate::lower::camel_f(&bare_p4), prism_p: bare_p4.clone(), fields_p: fields_ph.clone(), labels_p: crate::prelude::each(&fs_pgx, &(|(fname_pm, _): &(Text, crate::check::types::Ty)| fname_pm.clone())) }]))), move |mk_24823: crate::lower::model::TyDef| prism_rtl::Turn::Finished(Array::from(vec![crate::lower::model::Item::ItType(mk_24823)])))
                })
            },
            crate::check::env::TyBody::BChoice(cases_pn) => {
                let cases_pnx = cases_pn.clone();
                let lx_p0x = lx_p0.clone();
                let ti_p1x = ti_p1.clone();
                crate::prelude::call_value(crate::prelude::each_job(cases_pnx.clone(), {
                    let ti_p1xx = ti_p1x.clone();
                    let lx_p0xx = lx_p0x.clone();
                    Rc::new(move |p0: (Text, Array<crate::check::types::Ty>)| {
                        let ti_p1xxy = ti_p1xx.clone();
                        let lx_p0xxy = lx_p0xx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let (cn_pq, ats_pr) = p0;
                            {
                                let ck_ps = crate::check::env::qual_key_f(&ti_p1xxy.home_p, &cn_pq);
                                crate::prelude::call_value(crate::prelude::each_job(crate::check::errors::range0_f(&crate::prelude::len(&ats_pr)), {
                                    let lx_p0xxyx = lx_p0xxy.clone();
                                    let ck_psx = ck_ps.clone();
                                    let ats_prx = ats_pr.clone();
                                    Rc::new(move |p0: Nat| {
                                        let lx_p0xxyxy = lx_p0xxyx.clone();
                                        let ck_psxy = ck_psx.clone();
                                        let ats_prxy = ats_prx.clone();
                                        crate::prelude::entered(crate::prelude::once_job(move || {
                                            let i_pt = p0;
                                            crate::prelude::call_then(start_case_field_f(lx_p0xxyxy.clone(), ck_psxy.clone(), i_pt.clone(), crate::prelude::or(&crate::prelude::index(&ats_prxy, &i_pt), &crate::check::types::Ty::TyErr)), move |case_field_f_25160: crate::lower::model::OutTy| prism_rtl::Turn::Finished((Text::lit(""), case_field_f_25160)))
                                        }))
                                    }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<(Text, crate::lower::model::OutTy)>>>
                                }), move |each_25123: Array<(Text, crate::lower::model::OutTy)>| prism_rtl::Turn::Finished(crate::lower::model::CaseDef { name_p: crate::lower::camel_f(&cn_pq), prism_p: cn_pq.clone(), fields_p: each_25123, labels_p: Array::new() }))
                            }
                        }))
                    }) as Rc<dyn Fn((Text, Array<crate::check::types::Ty>)) -> Rc<dyn prism_rtl::Job<crate::lower::model::CaseDef>>>
                }), move |each_24992: Array<crate::lower::model::CaseDef>| {
                    let defs_po = each_24992;
                    let shape_pp = 'm25242: {
                        if let m25242_0 = &cases_pnx && (m25242_0.len() == 1) && let Some((cn_pu, m25242_0_0_1)) = crate::prelude::index(m25242_0, &Nat::from(0u32)) && ((&m25242_0_0_1).len() == 0) {
                            break 'm25242 if crate::check::env::is_lower_text_f(&cn_pu) {
                                crate::lower::model::TyShape::ShapeUnit
                            } else {
                                crate::lower::model::TyShape::ShapeChoice
                            };
                        }
                        if let m25242_1 = &cases_pnx && (m25242_1.len() == 1) && let Some((cn_pv, _)) = crate::prelude::index(m25242_1, &Nat::from(0u32)) {
                            break 'm25242 if &cn_pv == &bare_p4 {
                                crate::lower::model::TyShape::ShapeNewtype
                            } else {
                                crate::lower::model::TyShape::ShapeChoice
                            };
                        }
                        crate::lower::model::TyShape::ShapeChoice
                    };
                    crate::prelude::call_value((&mk_f5)((shape_pp.clone(), defs_po.clone())), move |mk_25479: crate::lower::model::TyDef| prism_rtl::Turn::Finished(Array::from(vec![crate::lower::model::Item::ItType(mk_25479)])))
                })
            },
            crate::check::env::TyBody::BRowKind => if &ti_p1.name_p == &Text::lit("Prelude.Fault") {
                prism_rtl::Turn::Finished(Array::new())
            } else {
                {
                    let lx_p0x = lx_p0.clone();
                    let ti_p1x = ti_p1.clone();
                    crate::prelude::call_then(start_row_def_of_f(lx_p0x.clone(), ti_p1x.clone()), move |row_def_of_f_25566: crate::lower::model::RowDef| prism_rtl::Turn::Finished(Array::from(vec![crate::lower::model::Item::ItRow(row_def_of_f_25566)])))
                }
            },
            _ => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start TyDefs, x`: what the function value is when passed to `@Run`.
pub fn start_ty_defs_f(lx_p0: crate::lower::Lx, ti_p1: crate::check::env::TyInfo) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Item>>> {
    Rc::new(TyDefs { lx_p0, ti_p1 })
}

/// ```prism
/// TyPodable: unbounded fn Lx, Ty, [Text] -> Bool
/// ```
pub fn ty_podable_f(lx_p0: &crate::lower::Lx, t_p1: &crate::check::types::Ty, seen_p2: &Array<Text>) -> bool {
    match t_p1 {
        crate::check::types::Ty::TyFn(_, _, _) => false,
        crate::check::types::Ty::TyAt(_, _) => false,
        crate::check::types::Ty::TySig(m25887_2_0, _) if (m25887_2_0 == &Text::lit("!")) => false,
        crate::check::types::Ty::TySig(m25887_3_0, _) if (m25887_3_0 == &Text::lit("$")) => false,
        crate::check::types::Ty::TySig(_, i_p3) => ty_podable_f(lx_p0, &**i_p3, seen_p2),
        crate::check::types::Ty::TyTuple(ts_p4) => crate::prelude::run_to_end(crate::prelude::fold_job(ts_p4.clone(), true, {
            let lx_p0x = lx_p0.clone();
            let seen_p2x = seen_p2.clone();
            Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| {
                let lx_p0xy = lx_p0x.clone();
                let seen_p2xy = seen_p2x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let ok_p5 = p0;
                    let x_p6 = p1;
                    prism_rtl::Turn::Finished(ok_p5 && ty_podable_f(&lx_p0xy, &x_p6, &seen_p2xy))
                }))
            }) as Rc<dyn Fn((bool, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<bool>>>
        })),
        crate::check::types::Ty::TyArray(e_p7) => ty_podable_f(lx_p0, &**e_p7, seen_p2),
        crate::check::types::Ty::TyMap(k_p8, v_p9) => ty_podable_f(lx_p0, &**k_p8, seen_p2) && ty_podable_f(lx_p0, &**v_p9, seen_p2),
        crate::check::types::Ty::TyCon(n_pa, args_pb) => if crate::check::types::has_text_f(seen_p2, n_pa) {
            true
        } else {
            {
                let more_pc = crate::prelude::push(seen_p2, n_pa);
                let args_ok_pd = crate::prelude::run_to_end(crate::prelude::fold_job(args_pb.clone(), true, {
                    let lx_p0x = lx_p0.clone();
                    let more_pcx = more_pc.clone();
                    Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| {
                        let lx_p0xy = lx_p0x.clone();
                        let more_pcxy = more_pcx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let ok_pe = p0;
                            let x_pf = p1;
                            prism_rtl::Turn::Finished(ok_pe && ty_podable_f(&lx_p0xy, &x_pf, &more_pcxy))
                        }))
                    }) as Rc<dyn Fn((bool, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<bool>>>
                }));
                args_ok_pd && match crate::prelude::get(&lx_p0.g_p.types_p, n_pa) {
                    Some(ti_pg) => match &ti_pg.body_p {
                        crate::check::env::TyBody::BRecord(fs_ph) => crate::prelude::run_to_end(crate::prelude::fold_job(fs_ph.clone(), true, {
                            let lx_p0x = lx_p0.clone();
                            let more_pcx = more_pc.clone();
                            Rc::new(move |(p0, p1): (bool, (Text, crate::check::types::Ty))| {
                                let lx_p0xy = lx_p0x.clone();
                                let more_pcxy = more_pcx.clone();
                                crate::prelude::entered(crate::prelude::once_job(move || {
                                    let ok_pi = p0;
                                    let (_, ft_pj) = p1;
                                    prism_rtl::Turn::Finished(ok_pi && ty_podable_f(&lx_p0xy, &ft_pj, &more_pcxy))
                                }))
                            }) as Rc<dyn Fn((bool, (Text, crate::check::types::Ty))) -> Rc<dyn prism_rtl::Job<bool>>>
                        })),
                        crate::check::env::TyBody::BChoice(cs_pk) => crate::prelude::run_to_end(crate::prelude::fold_job(cs_pk.clone(), true, {
                            let lx_p0x = lx_p0.clone();
                            let more_pcx = more_pc.clone();
                            Rc::new(move |(p0, p1): (bool, (Text, Array<crate::check::types::Ty>))| {
                                let lx_p0xy = lx_p0x.clone();
                                let more_pcxy = more_pcx.clone();
                                crate::prelude::entered(crate::prelude::once_job(move || {
                                    let ok_pl = p0;
                                    let (_, ats_pm) = p1;
                                    prism_rtl::Turn::Finished(ok_pl && crate::prelude::run_to_end(crate::prelude::fold_job(ats_pm.clone(), true, {
                                        let lx_p0xyx = lx_p0xy.clone();
                                        let more_pcxyx = more_pcxy.clone();
                                        Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| {
                                            let lx_p0xyxy = lx_p0xyx.clone();
                                            let more_pcxyxy = more_pcxyx.clone();
                                            crate::prelude::entered(crate::prelude::once_job(move || {
                                                let ok2_pn = p0;
                                                let x_po = p1;
                                                prism_rtl::Turn::Finished(ok2_pn && ty_podable_f(&lx_p0xyxy, &x_po, &more_pcxyxy))
                                            }))
                                        }) as Rc<dyn Fn((bool, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<bool>>>
                                    })))
                                }))
                            }) as Rc<dyn Fn((bool, (Text, Array<crate::check::types::Ty>))) -> Rc<dyn prism_rtl::Job<bool>>>
                        })),
                        crate::check::env::TyBody::BAlias(a_pp) => ty_podable_f(lx_p0, a_pp, &more_pc),
                        _ => true,
                    },
                    None => true,
                }
            }
        },
        _ => true,
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `TyPodable`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TyPodable: unbounded fn Lx, Ty, [Text] -> Bool
/// ```
pub struct TyPodable {
    pub lx_p0: crate::lower::Lx,
    pub t_p1: crate::check::types::Ty,
    pub seen_p2: Array<Text>,
}

impl prism_rtl::Job<bool> for TyPodable {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let lx_p0 = &self.lx_p0;
        let t_p1 = &self.t_p1;
        let seen_p2 = &self.seen_p2;
        match t_p1 {
            crate::check::types::Ty::TyFn(_, _, _) => prism_rtl::Turn::Finished(false),
            crate::check::types::Ty::TyAt(_, _) => prism_rtl::Turn::Finished(false),
            crate::check::types::Ty::TySig(m25887_2_0, _) if (m25887_2_0 == &Text::lit("!")) => prism_rtl::Turn::Finished(false),
            crate::check::types::Ty::TySig(m25887_3_0, _) if (m25887_3_0 == &Text::lit("$")) => prism_rtl::Turn::Finished(false),
            crate::check::types::Ty::TySig(_, i_p3) => prism_rtl::Turn::More(Rc::new(TyPodable { lx_p0: lx_p0.clone(), t_p1: (**i_p3).clone(), seen_p2: seen_p2.clone() })),
            crate::check::types::Ty::TyTuple(ts_p4) => crate::prelude::fold_job(ts_p4.clone(), true, {
                let lx_p0x = lx_p0.clone();
                let seen_p2x = seen_p2.clone();
                Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| {
                    let lx_p0xy = lx_p0x.clone();
                    let seen_p2xy = seen_p2x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let ok_p5 = p0;
                        let x_p6 = p1;
                        prism_rtl::Turn::Finished(ok_p5 && ty_podable_f(&lx_p0xy, &x_p6, &seen_p2xy))
                    }))
                }) as Rc<dyn Fn((bool, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<bool>>>
            }).cycle(),
            crate::check::types::Ty::TyArray(e_p7) => prism_rtl::Turn::More(Rc::new(TyPodable { lx_p0: lx_p0.clone(), t_p1: (**e_p7).clone(), seen_p2: seen_p2.clone() })),
            crate::check::types::Ty::TyMap(k_p8, v_p9) => {
                let k_p8x = (**k_p8).clone();
                let lx_p0x = lx_p0.clone();
                let seen_p2x = seen_p2.clone();
                let v_p9x = (**v_p9).clone();
                crate::prelude::call_then(start_ty_podable_f(lx_p0x.clone(), k_p8x.clone(), seen_p2x.clone()), move |ty_podable_f_26190: bool| prism_rtl::Turn::Finished(ty_podable_f_26190 && ty_podable_f(&lx_p0x, &v_p9x, &seen_p2x)))
            },
            crate::check::types::Ty::TyCon(n_pa, args_pb) => if crate::check::types::has_text_f(seen_p2, n_pa) {
                prism_rtl::Turn::Finished(true)
            } else {
                {
                    let more_pc = crate::prelude::push(seen_p2, n_pa);
                    let args_pbx = args_pb.clone();
                    let lx_p0x = lx_p0.clone();
                    let n_pax = n_pa.clone();
                    crate::prelude::call_value(crate::prelude::fold_job(args_pbx.clone(), true, {
                        let lx_p0xx = lx_p0x.clone();
                        let more_pcx = more_pc.clone();
                        Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| {
                            let lx_p0xxy = lx_p0xx.clone();
                            let more_pcxy = more_pcx.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let ok_pe = p0;
                                let x_pf = p1;
                                prism_rtl::Turn::Finished(ok_pe && ty_podable_f(&lx_p0xxy, &x_pf, &more_pcxy))
                            }))
                        }) as Rc<dyn Fn((bool, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<bool>>>
                    }), move |fold_26366: bool| {
                        let args_ok_pd = fold_26366;
                        prism_rtl::Turn::Finished(args_ok_pd && match crate::prelude::get(&lx_p0x.g_p.types_p, &n_pax) {
                            Some(ti_pg) => match &ti_pg.body_p {
                                crate::check::env::TyBody::BRecord(fs_ph) => crate::prelude::run_to_end(crate::prelude::fold_job(fs_ph.clone(), true, {
                                    let lx_p0xx = lx_p0x.clone();
                                    let more_pcx = more_pc.clone();
                                    Rc::new(move |(p0, p1): (bool, (Text, crate::check::types::Ty))| {
                                        let lx_p0xxy = lx_p0xx.clone();
                                        let more_pcxy = more_pcx.clone();
                                        crate::prelude::entered(crate::prelude::once_job(move || {
                                            let ok_pi = p0;
                                            let (_, ft_pj) = p1;
                                            prism_rtl::Turn::Finished(ok_pi && ty_podable_f(&lx_p0xxy, &ft_pj, &more_pcxy))
                                        }))
                                    }) as Rc<dyn Fn((bool, (Text, crate::check::types::Ty))) -> Rc<dyn prism_rtl::Job<bool>>>
                                })),
                                crate::check::env::TyBody::BChoice(cs_pk) => crate::prelude::run_to_end(crate::prelude::fold_job(cs_pk.clone(), true, {
                                    let lx_p0xx = lx_p0x.clone();
                                    let more_pcx = more_pc.clone();
                                    Rc::new(move |(p0, p1): (bool, (Text, Array<crate::check::types::Ty>))| {
                                        let lx_p0xxy = lx_p0xx.clone();
                                        let more_pcxy = more_pcx.clone();
                                        crate::prelude::entered(crate::prelude::once_job(move || {
                                            let ok_pl = p0;
                                            let (_, ats_pm) = p1;
                                            prism_rtl::Turn::Finished(ok_pl && crate::prelude::run_to_end(crate::prelude::fold_job(ats_pm.clone(), true, {
                                                let lx_p0xxyx = lx_p0xxy.clone();
                                                let more_pcxyx = more_pcxy.clone();
                                                Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| {
                                                    let lx_p0xxyxy = lx_p0xxyx.clone();
                                                    let more_pcxyxy = more_pcxyx.clone();
                                                    crate::prelude::entered(crate::prelude::once_job(move || {
                                                        let ok2_pn = p0;
                                                        let x_po = p1;
                                                        prism_rtl::Turn::Finished(ok2_pn && ty_podable_f(&lx_p0xxyxy, &x_po, &more_pcxyxy))
                                                    }))
                                                }) as Rc<dyn Fn((bool, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<bool>>>
                                            })))
                                        }))
                                    }) as Rc<dyn Fn((bool, (Text, Array<crate::check::types::Ty>))) -> Rc<dyn prism_rtl::Job<bool>>>
                                })),
                                crate::check::env::TyBody::BAlias(a_pp) => ty_podable_f(&lx_p0x, a_pp, &more_pc),
                                _ => true,
                            },
                            None => true,
                        })
                    })
                }
            },
            _ => prism_rtl::Turn::Finished(true),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start TyPodable, x`: what the function value is when passed to `@Run`.
pub fn start_ty_podable_f(lx_p0: crate::lower::Lx, t_p1: crate::check::types::Ty, seen_p2: Array<Text>) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(TyPodable { lx_p0, t_p1, seen_p2 })
}

/// ```prism
/// TyHasEq: unbounded fn Lx, Ty, [Text] -> Bool
/// ```
pub fn ty_has_eq_f(lx_p0: &crate::lower::Lx, t_p1: &crate::check::types::Ty, seen_p2: &Array<Text>) -> bool {
    match t_p1 {
        crate::check::types::Ty::TyFn(_, _, _) => false,
        crate::check::types::Ty::TyAt(_, _) => false,
        crate::check::types::Ty::TySig(m27320_2_0, _) if (m27320_2_0 == &Text::lit("!")) => false,
        crate::check::types::Ty::TySig(m27320_3_0, _) if (m27320_3_0 == &Text::lit("$")) => false,
        crate::check::types::Ty::TySig(_, i_p3) => ty_has_eq_f(lx_p0, &**i_p3, seen_p2),
        crate::check::types::Ty::TyTuple(ts_p4) => crate::prelude::run_to_end(crate::prelude::fold_job(ts_p4.clone(), true, {
            let lx_p0x = lx_p0.clone();
            let seen_p2x = seen_p2.clone();
            Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| {
                let lx_p0xy = lx_p0x.clone();
                let seen_p2xy = seen_p2x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let ok_p5 = p0;
                    let x_p6 = p1;
                    prism_rtl::Turn::Finished(ok_p5 && ty_has_eq_f(&lx_p0xy, &x_p6, &seen_p2xy))
                }))
            }) as Rc<dyn Fn((bool, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<bool>>>
        })),
        crate::check::types::Ty::TyArray(e_p7) => ty_has_eq_f(lx_p0, &**e_p7, seen_p2),
        crate::check::types::Ty::TyMap(k_p8, v_p9) => ty_has_eq_f(lx_p0, &**k_p8, seen_p2) && ty_has_eq_f(lx_p0, &**v_p9, seen_p2),
        crate::check::types::Ty::TyElem(_, _) => true,
        crate::check::types::Ty::TyElemAny(_) => true,
        crate::check::types::Ty::TyCon(n_pa, args_pb) => if crate::check::types::has_text_f(seen_p2, n_pa) {
            true
        } else {
            {
                let args_ok_pc = crate::prelude::run_to_end(crate::prelude::fold_job(args_pb.clone(), true, {
                    let lx_p0x = lx_p0.clone();
                    let seen_p2x = seen_p2.clone();
                    let n_pax = n_pa.clone();
                    Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| {
                        let lx_p0xy = lx_p0x.clone();
                        let seen_p2xy = seen_p2x.clone();
                        let n_paxy = n_pax.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let ok_pd = p0;
                            let x_pe = p1;
                            prism_rtl::Turn::Finished(ok_pd && ty_has_eq_f(&lx_p0xy, &x_pe, &crate::prelude::push(&seen_p2xy, &n_paxy)))
                        }))
                    }) as Rc<dyn Fn((bool, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<bool>>>
                }));
                args_ok_pc && match crate::prelude::get(&lx_p0.g_p.types_p, n_pa) {
                    Some(ti_pf) => crate::prelude::fold(&ti_pf.derives_p, &false, &(|f_pg: &bool, d_ph: &Text| *f_pg || (&crate::check::env::names::resolve_trait_o(&lx_p0.g_p, &ti_pf.home_p, &crate::prelude::split_on(d_ph, &Text::lit("."))) == &Some(Text::lit("Prelude.Eq"))))) || has_own_eq_f(lx_p0, n_pa),
                    None => true,
                }
            }
        },
        _ => false,
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// HasOwnEq: fn Lx, Text -> Bool
/// ```
pub fn has_own_eq_f(lx_p0: &crate::lower::Lx, tn_p1: &Text) -> bool {
    crate::prelude::fold(&crate::prelude::or(&crate::prelude::get(&lx_p0.g_p.impls_p, &Text::lit("Prelude.Eq")), &Array::new()), &false, &(|f_p2: &bool, im_p3: &crate::check::env::ImplInfo| *f_p2 || (&crate::lower::functions::head_name_f(&im_p3.head_p) == tn_p1)))
}

/// ```prism
/// CaseField: unbounded fn Lx, Text, Nat, Ty -> OutTy
/// ```
pub fn case_field_f(lx_p0: &crate::lower::Lx, ck_p1: &Text, i_p2: &Nat, t_p3: &crate::check::types::Ty) -> crate::lower::model::OutTy {
    let rt_p4 = crate::lower::types::out_ty_of_f(lx_p0, t_p3);
    if crate::lower::types::rc_field_f(lx_p0, ck_p1, i_p2) {
        crate::lower::model::OutTy::OutRc(Rc::new(rt_p4.clone()))
    } else {
        rt_p4.clone()
    }
}

/// The step machine of `CaseField`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CaseField: unbounded fn Lx, Text, Nat, Ty -> OutTy
/// ```
pub struct CaseField {
    pub lx_p0: crate::lower::Lx,
    pub ck_p1: Text,
    pub i_p2: Nat,
    pub t_p3: crate::check::types::Ty,
}

impl prism_rtl::Job<crate::lower::model::OutTy> for CaseField {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::OutTy> {
        let lx_p0 = &self.lx_p0;
        let ck_p1 = &self.ck_p1;
        let i_p2 = &self.i_p2;
        let t_p3 = &self.t_p3;
        let ck_p1x = ck_p1.clone();
        let i_p2x = i_p2.clone();
        let lx_p0x = lx_p0.clone();
        let t_p3x = t_p3.clone();
        crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0x.clone(), t_p3x.clone()), move |out_ty_of_f_28343: crate::lower::model::OutTy| {
            let rt_p4 = out_ty_of_f_28343;
            if crate::lower::types::rc_field_f(&lx_p0x, &ck_p1x, &i_p2x) {
                prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutRc(Rc::new(rt_p4.clone())))
            } else {
                prism_rtl::Turn::Finished(rt_p4.clone())
            }
        })
    }
}

/// `Start CaseField, x`: what the function value is when passed to `@Run`.
pub fn start_case_field_f(lx_p0: crate::lower::Lx, ck_p1: Text, i_p2: Nat, t_p3: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::lower::model::OutTy>> {
    Rc::new(CaseField { lx_p0, ck_p1, i_p2, t_p3 })
}

/// ```prism
/// TypeDoc: fn Lx, TyInfo -> Text
/// ```
pub fn type_doc_f(lx_p0: &crate::lower::Lx, ti_p1: &crate::check::env::TyInfo) -> Text {
    match crate::prelude::index(&lx_p0.g_p.srcs_p, &ti_p1.file_p) {
        Some(src_p2) => crate::syntax::lexer::chars::trim_f(&crate::check::errors::line_text_f(&src_p2, &crate::check::errors::cline_of_f(&src_p2.starts_p, &ti_p1.span_p.start_p))),
        None => ti_p1.name_p.clone(),
    }
}

/// ```prism
/// TagDefOf: unbounded fn Lx, TagInfo -> TagDef
/// ```
pub fn tag_def_of_f(lx_p0: &crate::lower::Lx, tg_p1: &crate::check::env::TagInfo) -> crate::lower::model::TagDef {
    let fields_p2 = crate::prelude::run_to_end(crate::prelude::each_job(level_fields_f(tg_p1), {
        let tg_p1x = tg_p1.clone();
        let lx_p0x = lx_p0.clone();
        Rc::new(move |p0: (Text, crate::check::types::Ty)| {
            let tg_p1xy = tg_p1x.clone();
            let lx_p0xy = lx_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (fname_p3, ft_p4) = p0;
                crate::prelude::call_then(crate::lower::start_field_spell_f(tg_p1xy.home_p.clone(), fname_p3.clone(), ft_p4.clone()), move |field_spell_f_28838: Text| crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0xy.clone(), crate::lower::types::peel_f(&ft_p4)), move |out_ty_of_f_28871: crate::lower::model::OutTy| prism_rtl::Turn::Finished((fname_p3.clone(), field_spell_f_28838, out_ty_of_f_28871))))
            }))
        }) as Rc<dyn Fn((Text, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<(Text, Text, crate::lower::model::OutTy)>>>
    }));
    crate::lower::model::TagDef { name_p: crate::lower::tag_struct_f(&tg_p1.name_p), tag_name_p: tg_p1.name_p.clone(), fields_p: fields_p2.clone(), doc_p: type_doc_f(lx_p0, &crate::check::env::TyInfo { name_p: tg_p1.name_p.clone(), home_p: tg_p1.home_p.clone(), params_p: Array::new(), body_p: crate::check::env::TyBody::BOpaque, derives_p: Array::new(), file_p: tg_p1.file_p.clone(), span_p: tg_p1.span_p.clone() }), pod_p: crate::prelude::run_to_end(crate::prelude::fold_job(fields_p2.clone(), true, Rc::new(move |(p0, p1): (bool, (Text, Text, crate::lower::model::OutTy))| crate::prelude::entered(crate::prelude::once_job(move || {
        let ok_p5 = p0;
        let (_, _, t_p6) = p1;
        prism_rtl::Turn::Finished(ok_p5 && crate::lower::types::podable_f(&t_p6))
    }))) as Rc<dyn Fn((bool, (Text, Text, crate::lower::model::OutTy))) -> Rc<dyn prism_rtl::Job<bool>>>)), eq_p: crate::prelude::run_to_end(crate::prelude::fold_job(fields_p2.clone(), true, Rc::new(move |(p0, p1): (bool, (Text, Text, crate::lower::model::OutTy))| crate::prelude::entered(crate::prelude::once_job(move || {
        let ok_p7 = p0;
        let (_, _, t_p8) = p1;
        prism_rtl::Turn::Finished(ok_p7 && crate::lower::types::runtime_eq_f(&t_p8))
    }))) as Rc<dyn Fn((bool, (Text, Text, crate::lower::model::OutTy))) -> Rc<dyn prism_rtl::Job<bool>>>)) }
}

/// The step machine of `TagDefOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TagDefOf: unbounded fn Lx, TagInfo -> TagDef
/// ```
pub struct TagDefOf {
    pub lx_p0: crate::lower::Lx,
    pub tg_p1: crate::check::env::TagInfo,
}

impl prism_rtl::Job<crate::lower::model::TagDef> for TagDefOf {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::TagDef> {
        let lx_p0 = &self.lx_p0;
        let tg_p1 = &self.tg_p1;
        let lx_p0x = lx_p0.clone();
        let tg_p1x = tg_p1.clone();
        crate::prelude::call_value(crate::prelude::each_job(level_fields_f(&tg_p1x), {
            let tg_p1xx = tg_p1x.clone();
            let lx_p0xx = lx_p0x.clone();
            Rc::new(move |p0: (Text, crate::check::types::Ty)| {
                let tg_p1xxy = tg_p1xx.clone();
                let lx_p0xxy = lx_p0xx.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let (fname_p3, ft_p4) = p0;
                    crate::prelude::call_then(crate::lower::start_field_spell_f(tg_p1xxy.home_p.clone(), fname_p3.clone(), ft_p4.clone()), move |field_spell_f_28838: Text| crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0xxy.clone(), crate::lower::types::peel_f(&ft_p4)), move |out_ty_of_f_28871: crate::lower::model::OutTy| prism_rtl::Turn::Finished((fname_p3.clone(), field_spell_f_28838, out_ty_of_f_28871))))
                }))
            }) as Rc<dyn Fn((Text, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<(Text, Text, crate::lower::model::OutTy)>>>
        }), move |each_28788: Array<(Text, Text, crate::lower::model::OutTy)>| {
            let fields_p2 = each_28788;
            crate::prelude::call_value(crate::prelude::fold_job(fields_p2.clone(), true, Rc::new(move |(p0, p1): (bool, (Text, Text, crate::lower::model::OutTy))| crate::prelude::entered(crate::prelude::once_job(move || {
                let ok_p5 = p0;
                let (_, _, t_p6) = p1;
                prism_rtl::Turn::Finished(ok_p5 && crate::lower::types::podable_f(&t_p6))
            }))) as Rc<dyn Fn((bool, (Text, Text, crate::lower::model::OutTy))) -> Rc<dyn prism_rtl::Job<bool>>>), move |fold_29095: bool| crate::prelude::call_value(crate::prelude::fold_job(fields_p2.clone(), true, Rc::new(move |(p0, p1): (bool, (Text, Text, crate::lower::model::OutTy))| crate::prelude::entered(crate::prelude::once_job(move || {
                let ok_p7 = p0;
                let (_, _, t_p8) = p1;
                prism_rtl::Turn::Finished(ok_p7 && crate::lower::types::runtime_eq_f(&t_p8))
            }))) as Rc<dyn Fn((bool, (Text, Text, crate::lower::model::OutTy))) -> Rc<dyn prism_rtl::Job<bool>>>), move |fold_29166: bool| prism_rtl::Turn::Finished(crate::lower::model::TagDef { name_p: crate::lower::tag_struct_f(&tg_p1x.name_p), tag_name_p: tg_p1x.name_p.clone(), fields_p: fields_p2.clone(), doc_p: type_doc_f(&lx_p0x, &crate::check::env::TyInfo { name_p: tg_p1x.name_p.clone(), home_p: tg_p1x.home_p.clone(), params_p: Array::new(), body_p: crate::check::env::TyBody::BOpaque, derives_p: Array::new(), file_p: tg_p1x.file_p.clone(), span_p: tg_p1x.span_p.clone() }), pod_p: fold_29095, eq_p: fold_29166 })))
        })
    }
}

/// `Start TagDefOf, x`: what the function value is when passed to `@Run`.
pub fn start_tag_def_of_f(lx_p0: crate::lower::Lx, tg_p1: crate::check::env::TagInfo) -> Rc<dyn prism_rtl::Job<crate::lower::model::TagDef>> {
    Rc::new(TagDefOf { lx_p0, tg_p1 })
}

/// ```prism
/// LevelFields: fn TagInfo -> [((Text, Ty))]
/// ```
pub fn level_fields_f(tg_p0: &crate::check::env::TagInfo) -> Array<(Text, crate::check::types::Ty)> {
    crate::prelude::filter(&tg_p0.fields_p, &(|(_, ft_p1): &(Text, crate::check::types::Ty)| &crate::lower::types::layer_of_f(ft_p1) != &crate::lower::types::Layer::LyEv))
}

/// ```prism
/// KindTags: fn Lx, Text, [Text] -> [TagInfo]
/// ```
pub fn kind_tags_f(lx_p0: &crate::lower::Lx, kind_p1: &Text, mods_p2: &Array<Text>) -> Array<crate::check::env::TagInfo> {
    crate::prelude::filter(&crate::prelude::values(&lx_p0.g_p.tags_p), &(|tg_p3: &crate::check::env::TagInfo| (&tg_p3.kind_p == kind_p1) && crate::check::types::has_text_f(mods_p2, &tg_p3.home_p)))
}

/// ```prism
/// RowDefOf: unbounded fn Lx, TyInfo -> RowDef
/// ```
pub fn row_def_of_f(lx_p0: &crate::lower::Lx, ti_p1: &crate::check::env::TyInfo) -> crate::lower::model::RowDef {
    let tags_p2 = kind_tags_f(lx_p0, &ti_p1.name_p, &crate::prelude::keys(&lx_p0.rs_mods_p));
    let cases_p3 = crate::prelude::each(&tags_p2, &(|tg_p6: &crate::check::env::TagInfo| (crate::lower::tag_struct_f(&tg_p6.name_p), crate::lower::path_in_f(lx_p0, &tg_p6.home_p, &crate::lower::tag_struct_f(&tg_p6.name_p)))));
    let pod_p4 = crate::prelude::run_to_end(crate::prelude::fold_job(tags_p2.clone(), true, {
        let lx_p0x = lx_p0.clone();
        Rc::new(move |(p0, p1): (bool, crate::check::env::TagInfo)| {
            let lx_p0xy = lx_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let ok_p7 = p0;
                let tg_p8 = p1;
                prism_rtl::Turn::Finished(ok_p7 && tag_def_of_f(&lx_p0xy, &tg_p8).pod_p)
            }))
        }) as Rc<dyn Fn((bool, crate::check::env::TagInfo)) -> Rc<dyn prism_rtl::Job<bool>>>
    }));
    let eq_p5 = crate::prelude::run_to_end(crate::prelude::fold_job(tags_p2.clone(), true, {
        let lx_p0x = lx_p0.clone();
        Rc::new(move |(p0, p1): (bool, crate::check::env::TagInfo)| {
            let lx_p0xy = lx_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let ok_p9 = p0;
                let tg_pa = p1;
                prism_rtl::Turn::Finished(ok_p9 && tag_def_of_f(&lx_p0xy, &tg_pa).eq_p)
            }))
        }) as Rc<dyn Fn((bool, crate::check::env::TagInfo)) -> Rc<dyn prism_rtl::Job<bool>>>
    }));
    crate::lower::model::RowDef { name_p: crate::lower::camel_f(&crate::check::types::bare_name_f(&ti_p1.name_p)), prism_p: ti_p1.name_p.clone(), cases_p: cases_p3.clone(), pod_p: pod_p4, doc_p: type_doc_f(lx_p0, ti_p1), eq_p: eq_p5, level_p: false, deep_p: Array::new() }
}

/// The step machine of `RowDefOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RowDefOf: unbounded fn Lx, TyInfo -> RowDef
/// ```
pub struct RowDefOf {
    pub lx_p0: crate::lower::Lx,
    pub ti_p1: crate::check::env::TyInfo,
}

impl prism_rtl::Job<crate::lower::model::RowDef> for RowDefOf {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::RowDef> {
        let lx_p0 = &self.lx_p0;
        let ti_p1 = &self.ti_p1;
        let tags_p2 = kind_tags_f(lx_p0, &ti_p1.name_p, &crate::prelude::keys(&lx_p0.rs_mods_p));
        let cases_p3 = crate::prelude::each(&tags_p2, &(|tg_p6: &crate::check::env::TagInfo| (crate::lower::tag_struct_f(&tg_p6.name_p), crate::lower::path_in_f(lx_p0, &tg_p6.home_p, &crate::lower::tag_struct_f(&tg_p6.name_p)))));
        let lx_p0x = lx_p0.clone();
        let ti_p1x = ti_p1.clone();
        crate::prelude::call_value(crate::prelude::fold_job(tags_p2.clone(), true, {
            let lx_p0xx = lx_p0x.clone();
            Rc::new(move |(p0, p1): (bool, crate::check::env::TagInfo)| {
                let lx_p0xxy = lx_p0xx.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let ok_p7 = p0;
                    let tg_p8 = p1;
                    prism_rtl::Turn::Finished(ok_p7 && tag_def_of_f(&lx_p0xxy, &tg_p8).pod_p)
                }))
            }) as Rc<dyn Fn((bool, crate::check::env::TagInfo)) -> Rc<dyn prism_rtl::Job<bool>>>
        }), move |fold_29882: bool| {
            let pod_p4 = fold_29882;
            crate::prelude::call_value(crate::prelude::fold_job(tags_p2.clone(), true, {
                let lx_p0xx = lx_p0x.clone();
                Rc::new(move |(p0, p1): (bool, crate::check::env::TagInfo)| {
                    let lx_p0xxy = lx_p0xx.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let ok_p9 = p0;
                        let tg_pa = p1;
                        prism_rtl::Turn::Finished(ok_p9 && tag_def_of_f(&lx_p0xxy, &tg_pa).eq_p)
                    }))
                }) as Rc<dyn Fn((bool, crate::check::env::TagInfo)) -> Rc<dyn prism_rtl::Job<bool>>>
            }), move |fold_29951: bool| {
                let eq_p5 = fold_29951;
                prism_rtl::Turn::Finished(crate::lower::model::RowDef { name_p: crate::lower::camel_f(&crate::check::types::bare_name_f(&ti_p1x.name_p)), prism_p: ti_p1x.name_p.clone(), cases_p: cases_p3.clone(), pod_p: pod_p4, doc_p: type_doc_f(&lx_p0x, &ti_p1x), eq_p: eq_p5, level_p: false, deep_p: Array::new() })
            })
        })
    }
}

/// `Start RowDefOf, x`: what the function value is when passed to `@Run`.
pub fn start_row_def_of_f(lx_p0: crate::lower::Lx, ti_p1: crate::check::env::TyInfo) -> Rc<dyn prism_rtl::Job<crate::lower::model::RowDef>> {
    Rc::new(RowDefOf { lx_p0, ti_p1 })
}

/// ```prism
/// ElemRow: unbounded fn Lx, [Text] -> RowDef
/// ```
pub fn elem_row_f(lx_p0: &crate::lower::Lx, mods_p1: &Array<Text>) -> crate::lower::model::RowDef {
    let tags_p2 = kind_tags_f(lx_p0, &Text::lit("Element"), &crate::prelude::push(mods_p1, &Text::lit("Prelude")));
    let cases_p3 = crate::prelude::each(&tags_p2, &(|tg_p7: &crate::check::env::TagInfo| (crate::lower::tag_struct_f(&tg_p7.name_p), Text::from(format!("{}::{}", &crate::lower::rust_mod_name_f(&tg_p7.home_p), &crate::lower::tag_struct_f(&tg_p7.name_p))))));
    let pod_p4 = crate::prelude::run_to_end(crate::prelude::fold_job(tags_p2.clone(), true, {
        let lx_p0x = lx_p0.clone();
        Rc::new(move |(p0, p1): (bool, crate::check::env::TagInfo)| {
            let lx_p0xy = lx_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let ok_p8 = p0;
                let tg_p9 = p1;
                prism_rtl::Turn::Finished(ok_p8 && tag_def_of_f(&lx_p0xy, &tg_p9).pod_p)
            }))
        }) as Rc<dyn Fn((bool, crate::check::env::TagInfo)) -> Rc<dyn prism_rtl::Job<bool>>>
    }));
    let eq_p5 = crate::prelude::run_to_end(crate::prelude::fold_job(tags_p2.clone(), true, {
        let lx_p0x = lx_p0.clone();
        Rc::new(move |(p0, p1): (bool, crate::check::env::TagInfo)| {
            let lx_p0xy = lx_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let ok_pa = p0;
                let tg_pb = p1;
                prism_rtl::Turn::Finished(ok_pa && tag_def_of_f(&lx_p0xy, &tg_pb).eq_p)
            }))
        }) as Rc<dyn Fn((bool, crate::check::env::TagInfo)) -> Rc<dyn prism_rtl::Job<bool>>>
    }));
    let deep_p6 = crate::prelude::run_to_end(crate::prelude::fold_job(tags_p2.clone(), Array::new(), {
        let lx_p0x = lx_p0.clone();
        Rc::new(move |(p0, p1): (Array<Text>, crate::check::env::TagInfo)| {
            let lx_p0xy = lx_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_pc = p0;
                let tg_pd = p1;
                crate::prelude::call_then(start_tag_holds_dyn_f(lx_p0xy.clone(), tg_pd.clone()), move |tag_holds_dyn_f_30753: bool| if tag_holds_dyn_f_30753 {
                    prism_rtl::Turn::Finished(crate::prelude::push(&acc_pc, &crate::lower::tag_struct_f(&tg_pd.name_p)))
                } else {
                    prism_rtl::Turn::Finished(acc_pc.clone())
                })
            }))
        }) as Rc<dyn Fn((Array<Text>, crate::check::env::TagInfo)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
    }));
    crate::lower::model::RowDef { name_p: Text::lit("Elem"), prism_p: Text::lit("Elem"), cases_p: cases_p3.clone(), pod_p: pod_p4, doc_p: Text::lit("`Elem r`: an element as a document holds it, its `Level` in a tick."), eq_p: eq_p5, level_p: true, deep_p: deep_p6.clone() }
}

/// The step machine of `ElemRow`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ElemRow: unbounded fn Lx, [Text] -> RowDef
/// ```
pub struct ElemRow {
    pub lx_p0: crate::lower::Lx,
    pub mods_p1: Array<Text>,
}

impl prism_rtl::Job<crate::lower::model::RowDef> for ElemRow {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::RowDef> {
        let lx_p0 = &self.lx_p0;
        let mods_p1 = &self.mods_p1;
        let tags_p2 = kind_tags_f(lx_p0, &Text::lit("Element"), &crate::prelude::push(mods_p1, &Text::lit("Prelude")));
        let cases_p3 = crate::prelude::each(&tags_p2, &(|tg_p7: &crate::check::env::TagInfo| (crate::lower::tag_struct_f(&tg_p7.name_p), Text::from(format!("{}::{}", &crate::lower::rust_mod_name_f(&tg_p7.home_p), &crate::lower::tag_struct_f(&tg_p7.name_p))))));
        let lx_p0x = lx_p0.clone();
        crate::prelude::call_value(crate::prelude::fold_job(tags_p2.clone(), true, {
            let lx_p0xx = lx_p0x.clone();
            Rc::new(move |(p0, p1): (bool, crate::check::env::TagInfo)| {
                let lx_p0xxy = lx_p0xx.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let ok_p8 = p0;
                    let tg_p9 = p1;
                    prism_rtl::Turn::Finished(ok_p8 && tag_def_of_f(&lx_p0xxy, &tg_p9).pod_p)
                }))
            }) as Rc<dyn Fn((bool, crate::check::env::TagInfo)) -> Rc<dyn prism_rtl::Job<bool>>>
        }), move |fold_30583: bool| {
            let pod_p4 = fold_30583;
            crate::prelude::call_value(crate::prelude::fold_job(tags_p2.clone(), true, {
                let lx_p0xx = lx_p0x.clone();
                Rc::new(move |(p0, p1): (bool, crate::check::env::TagInfo)| {
                    let lx_p0xxy = lx_p0xx.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let ok_pa = p0;
                        let tg_pb = p1;
                        prism_rtl::Turn::Finished(ok_pa && tag_def_of_f(&lx_p0xxy, &tg_pb).eq_p)
                    }))
                }) as Rc<dyn Fn((bool, crate::check::env::TagInfo)) -> Rc<dyn prism_rtl::Job<bool>>>
            }), move |fold_30652: bool| {
                let eq_p5 = fold_30652;
                crate::prelude::call_value(crate::prelude::fold_job(tags_p2.clone(), Array::new(), {
                    let lx_p0xx = lx_p0x.clone();
                    Rc::new(move |(p0, p1): (Array<Text>, crate::check::env::TagInfo)| {
                        let lx_p0xxy = lx_p0xx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let acc_pc = p0;
                            let tg_pd = p1;
                            crate::prelude::call_then(start_tag_holds_dyn_f(lx_p0xxy.clone(), tg_pd.clone()), move |tag_holds_dyn_f_30753: bool| if tag_holds_dyn_f_30753 {
                                prism_rtl::Turn::Finished(crate::prelude::push(&acc_pc, &crate::lower::tag_struct_f(&tg_pd.name_p)))
                            } else {
                                prism_rtl::Turn::Finished(acc_pc.clone())
                            })
                        }))
                    }) as Rc<dyn Fn((Array<Text>, crate::check::env::TagInfo)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
                }), move |fold_30722: Array<Text>| {
                    let deep_p6 = fold_30722;
                    prism_rtl::Turn::Finished(crate::lower::model::RowDef { name_p: Text::lit("Elem"), prism_p: Text::lit("Elem"), cases_p: cases_p3.clone(), pod_p: pod_p4, doc_p: Text::lit("`Elem r`: an element as a document holds it, its `Level` in a tick."), eq_p: eq_p5, level_p: true, deep_p: deep_p6.clone() })
                })
            })
        })
    }
}

/// `Start ElemRow, x`: what the function value is when passed to `@Run`.
pub fn start_elem_row_f(lx_p0: crate::lower::Lx, mods_p1: Array<Text>) -> Rc<dyn prism_rtl::Job<crate::lower::model::RowDef>> {
    Rc::new(ElemRow { lx_p0, mods_p1 })
}

/// ```prism
/// TagHoldsDyn: unbounded fn Lx, TagInfo -> Bool
/// ```
pub fn tag_holds_dyn_f(lx_p0: &crate::lower::Lx, tg_p1: &crate::check::env::TagInfo) -> bool {
    crate::prelude::run_to_end(crate::prelude::fold_job(tag_def_of_f(lx_p0, tg_p1).fields_p.clone(), false, Rc::new(move |(p0, p1): (bool, (Text, Text, crate::lower::model::OutTy))| crate::prelude::entered(crate::prelude::once_job(move || {
        let f_p2 = p0;
        let (_, _, t_p3) = p1;
        prism_rtl::Turn::Finished(f_p2 || crate::lower::types::holds_dyn_f(&t_p3))
    }))) as Rc<dyn Fn((bool, (Text, Text, crate::lower::model::OutTy))) -> Rc<dyn prism_rtl::Job<bool>>>))
}

/// The step machine of `TagHoldsDyn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TagHoldsDyn: unbounded fn Lx, TagInfo -> Bool
/// ```
pub struct TagHoldsDyn {
    pub lx_p0: crate::lower::Lx,
    pub tg_p1: crate::check::env::TagInfo,
}

impl prism_rtl::Job<bool> for TagHoldsDyn {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let lx_p0 = &self.lx_p0;
        let tg_p1 = &self.tg_p1;
        let lx_p0x = lx_p0.clone();
        let tg_p1x = tg_p1.clone();
        crate::prelude::call_then(start_tag_def_of_f(lx_p0x.clone(), tg_p1x.clone()), move |tag_def_of_f_31174: crate::lower::model::TagDef| crate::prelude::fold_job(tag_def_of_f_31174.fields_p.clone(), false, Rc::new(move |(p0, p1): (bool, (Text, Text, crate::lower::model::OutTy))| crate::prelude::entered(crate::prelude::once_job(move || {
            let f_p2 = p0;
            let (_, _, t_p3) = p1;
            prism_rtl::Turn::Finished(f_p2 || crate::lower::types::holds_dyn_f(&t_p3))
        }))) as Rc<dyn Fn((bool, (Text, Text, crate::lower::model::OutTy))) -> Rc<dyn prism_rtl::Job<bool>>>).cycle())
    }
}

/// `Start TagHoldsDyn, x`: what the function value is when passed to `@Run`.
pub fn start_tag_holds_dyn_f(lx_p0: crate::lower::Lx, tg_p1: crate::check::env::TagInfo) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(TagHoldsDyn { lx_p0, tg_p1 })
}

/// ```prism
/// AnswerEnum: unbounded fn Lx, [Text] -> AnswerDef
/// ```
pub fn answer_enum_f(lx_p0: &crate::lower::Lx, mods_p1: &Array<Text>) -> crate::lower::model::AnswerDef {
    let tags_p2 = kind_tags_f(lx_p0, &Text::lit("Element"), &crate::prelude::push(mods_p1, &Text::lit("Prelude")));
    crate::lower::model::AnswerDef { cases_p: crate::prelude::run_to_end(crate::prelude::each_job(tags_p2.clone(), {
        let lx_p0x = lx_p0.clone();
        Rc::new(move |p0: crate::check::env::TagInfo| {
            let lx_p0xy = lx_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let tg_p3 = p0;
                crate::prelude::call_then(start_answer_ty_f(lx_p0xy.clone(), tg_p3.clone()), move |answer_ty_f_31650: crate::lower::model::OutTy| prism_rtl::Turn::Finished(crate::lower::model::AnswerCase { variant_p: crate::lower::tag_struct_f(&tg_p3.name_p), accessor_p: crate::lower::node_::elements::answer_accessor_f(&tg_p3), struct_path_p: Text::from(format!("{}::{}", &crate::lower::rust_mod_name_f(&tg_p3.home_p), &crate::lower::tag_struct_f(&tg_p3.name_p))), tag_name_p: tg_p3.name_p.clone(), ty_p: answer_ty_f_31650 }))
            }))
        }) as Rc<dyn Fn(crate::check::env::TagInfo) -> Rc<dyn prism_rtl::Job<crate::lower::model::AnswerCase>>>
    })) }
}

/// The step machine of `AnswerEnum`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// AnswerEnum: unbounded fn Lx, [Text] -> AnswerDef
/// ```
pub struct AnswerEnum {
    pub lx_p0: crate::lower::Lx,
    pub mods_p1: Array<Text>,
}

impl prism_rtl::Job<crate::lower::model::AnswerDef> for AnswerEnum {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::AnswerDef> {
        let lx_p0 = &self.lx_p0;
        let mods_p1 = &self.mods_p1;
        let tags_p2 = kind_tags_f(lx_p0, &Text::lit("Element"), &crate::prelude::push(mods_p1, &Text::lit("Prelude")));
        let lx_p0x = lx_p0.clone();
        crate::prelude::call_value(crate::prelude::each_job(tags_p2.clone(), {
            let lx_p0xx = lx_p0x.clone();
            Rc::new(move |p0: crate::check::env::TagInfo| {
                let lx_p0xxy = lx_p0xx.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let tg_p3 = p0;
                    crate::prelude::call_then(start_answer_ty_f(lx_p0xxy.clone(), tg_p3.clone()), move |answer_ty_f_31650: crate::lower::model::OutTy| prism_rtl::Turn::Finished(crate::lower::model::AnswerCase { variant_p: crate::lower::tag_struct_f(&tg_p3.name_p), accessor_p: crate::lower::node_::elements::answer_accessor_f(&tg_p3), struct_path_p: Text::from(format!("{}::{}", &crate::lower::rust_mod_name_f(&tg_p3.home_p), &crate::lower::tag_struct_f(&tg_p3.name_p))), tag_name_p: tg_p3.name_p.clone(), ty_p: answer_ty_f_31650 }))
                }))
            }) as Rc<dyn Fn(crate::check::env::TagInfo) -> Rc<dyn prism_rtl::Job<crate::lower::model::AnswerCase>>>
        }), move |each_31485: Array<crate::lower::model::AnswerCase>| prism_rtl::Turn::Finished(crate::lower::model::AnswerDef { cases_p: each_31485 }))
    }
}

/// `Start AnswerEnum, x`: what the function value is when passed to `@Run`.
pub fn start_answer_enum_f(lx_p0: crate::lower::Lx, mods_p1: Array<Text>) -> Rc<dyn prism_rtl::Job<crate::lower::model::AnswerDef>> {
    Rc::new(AnswerEnum { lx_p0, mods_p1 })
}

/// ```prism
/// AnswerTy: unbounded fn Lx, TagInfo -> OutTy
/// ```
pub fn answer_ty_f(lx_p0: &crate::lower::Lx, tg_p1: &crate::check::env::TagInfo) -> crate::lower::model::OutTy {
    let out_p2 = crate::lower::types::peel_f(&tg_p1.out_p);
    let part_p3 = match &out_p2 {
        crate::check::types::Ty::TyTuple(cs_p4) => crate::prelude::fold(cs_p4, &out_p2, &(|found_p5: &crate::check::types::Ty, c_p6: &crate::check::types::Ty| if &crate::lower::types::layer_of_f(c_p6) == &crate::lower::types::Layer::LyEv {
            crate::lower::types::peel_f(c_p6)
        } else {
            found_p5.clone()
        })),
        _ => out_p2.clone(),
    };
    match crate::lower::types::out_ty_of_f(lx_p0, &part_p3) {
        crate::lower::model::OutTy::OutGen(_) => crate::lower::model::OutTy::OutPod,
        t_p7 => t_p7,
    }
}

/// The step machine of `AnswerTy`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// AnswerTy: unbounded fn Lx, TagInfo -> OutTy
/// ```
pub struct AnswerTy {
    pub lx_p0: crate::lower::Lx,
    pub tg_p1: crate::check::env::TagInfo,
}

impl prism_rtl::Job<crate::lower::model::OutTy> for AnswerTy {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::OutTy> {
        let lx_p0 = &self.lx_p0;
        let tg_p1 = &self.tg_p1;
        let out_p2 = crate::lower::types::peel_f(&tg_p1.out_p);
        let part_p3 = match &out_p2 {
            crate::check::types::Ty::TyTuple(cs_p4) => crate::prelude::fold(cs_p4, &out_p2, &(|found_p5: &crate::check::types::Ty, c_p6: &crate::check::types::Ty| if &crate::lower::types::layer_of_f(c_p6) == &crate::lower::types::Layer::LyEv {
                crate::lower::types::peel_f(c_p6)
            } else {
                found_p5.clone()
            })),
            _ => out_p2.clone(),
        };
        let lx_p0x = lx_p0.clone();
        crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0x.clone(), part_p3.clone()), move |out_ty_of_f_32177: crate::lower::model::OutTy| match out_ty_of_f_32177 {
            crate::lower::model::OutTy::OutGen(_) => prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutPod),
            t_p7 => prism_rtl::Turn::Finished(t_p7.clone()),
        })
    }
}

/// `Start AnswerTy, x`: what the function value is when passed to `@Run`.
pub fn start_answer_ty_f(lx_p0: crate::lower::Lx, tg_p1: crate::check::env::TagInfo) -> Rc<dyn prism_rtl::Job<crate::lower::model::OutTy>> {
    Rc::new(AnswerTy { lx_p0, tg_p1 })
}

/// ```prism
/// TagPaths: fn Lx, TagInfo -> ((Text, Text))
/// ```
pub fn tag_paths_f(lx_p0: &crate::lower::Lx, tg_p1: &crate::check::env::TagInfo) -> (Text, Text) {
    let st_p2 = crate::lower::tag_struct_f(&tg_p1.name_p);
    let struct_path_p3 = crate::lower::path_in_f(lx_p0, &tg_p1.home_p, &st_p2);
    (Text::from(format!("{}::{}", &kind_path_f(lx_p0, &tg_p1.kind_p), &st_p2)), struct_path_p3.clone())
}

/// ```prism
/// VariantOf: fn Lx, TagInfo -> Text
/// ```
pub fn variant_of_f(lx_p0: &crate::lower::Lx, tg_p1: &crate::check::env::TagInfo) -> Text {
    Text::from(format!("{}::{}", &kind_path_f(lx_p0, &tg_p1.kind_p), &crate::lower::tag_struct_f(&tg_p1.name_p)))
}

/// ```prism
/// KindPath: fn Lx, Text -> Text
/// ```
pub fn kind_path_f(lx_p0: &crate::lower::Lx, kind_p1: &Text) -> Text {
    if kind_p1 == &Text::lit("Element") {
        Text::lit("crate::Elem")
    } else {
        crate::lower::path_in_f(lx_p0, &crate::prelude::or(&crate::prelude::get(&lx_p0.g_p.types_p, kind_p1), &crate::check::env::names::dummy_ty_info_p()).home_p, &crate::lower::camel_f(&crate::check::types::bare_name_f(kind_p1)))
    }
}

/// ```prism
/// CheckDefOf: unbounded fn Lx, CheckDecl -> CheckDef
/// ```
pub fn check_def_of_f(lx_p0: &crate::lower::Lx, c_p1: &crate::syntax::decls::CheckDecl) -> crate::lower::model::CheckDef {
    crate::lower::model::CheckDef { name_p: c_p1.name_p.name_p.clone(), lines_p: crate::prelude::run_to_end(crate::prelude::each_job(c_p1.lines_p.clone(), {
        let lx_p0x = lx_p0.clone();
        Rc::new(move |p0: crate::syntax::decls::CheckLine| {
            let lx_p0xy = lx_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let l_p2 = p0;
                crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p0xy.clone(), crate::lower::types::empty_env_p(), l_p2.expr_p.clone()), move |value_of_f_33025: crate::lower::types::Vl| prism_rtl::Turn::Finished(crate::lower::model::Ex::XCtor(Text::lit("Ok"), Array::from(vec![crate::lower::model::Ex::XMethod(Rc::new(crate::lower::types::own_f(&value_of_f_33025)), Text::lit("to_pod"), Array::new())]))))
            }))
        }) as Rc<dyn Fn(crate::syntax::decls::CheckLine) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
    })) }
}

/// The step machine of `CheckDefOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CheckDefOf: unbounded fn Lx, CheckDecl -> CheckDef
/// ```
pub struct CheckDefOf {
    pub lx_p0: crate::lower::Lx,
    pub c_p1: crate::syntax::decls::CheckDecl,
}

impl prism_rtl::Job<crate::lower::model::CheckDef> for CheckDefOf {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::CheckDef> {
        let lx_p0 = &self.lx_p0;
        let c_p1 = &self.c_p1;
        let c_p1x = c_p1.clone();
        let lx_p0x = lx_p0.clone();
        crate::prelude::call_value(crate::prelude::each_job(c_p1x.lines_p.clone(), {
            let lx_p0xx = lx_p0x.clone();
            Rc::new(move |p0: crate::syntax::decls::CheckLine| {
                let lx_p0xxy = lx_p0xx.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let l_p2 = p0;
                    crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p0xxy.clone(), crate::lower::types::empty_env_p(), l_p2.expr_p.clone()), move |value_of_f_33025: crate::lower::types::Vl| prism_rtl::Turn::Finished(crate::lower::model::Ex::XCtor(Text::lit("Ok"), Array::from(vec![crate::lower::model::Ex::XMethod(Rc::new(crate::lower::types::own_f(&value_of_f_33025)), Text::lit("to_pod"), Array::new())]))))
                }))
            }) as Rc<dyn Fn(crate::syntax::decls::CheckLine) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
        }), move |each_32977: Array<crate::lower::model::Ex>| prism_rtl::Turn::Finished(crate::lower::model::CheckDef { name_p: c_p1x.name_p.name_p.clone(), lines_p: each_32977 }))
    }
}

/// `Start CheckDefOf, x`: what the function value is when passed to `@Run`.
pub fn start_check_def_of_f(lx_p0: crate::lower::Lx, c_p1: crate::syntax::decls::CheckDecl) -> Rc<dyn prism_rtl::Job<crate::lower::model::CheckDef>> {
    Rc::new(CheckDefOf { lx_p0, c_p1 })
}
