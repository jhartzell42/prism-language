//! The module `Lower.Program`, from `target/bootstrap/src/prismc/lower/program.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file. The runtime
//! side is reached from the crate, `crate::prelude` (and through it `::prism_rtl`), the
//! standard library from `::std`, and nothing is imported by name: a program's own type
//! (`Row`, `Option`) hides none of theirs. The traits are in scope unnamed, for their methods.

use crate::prelude::traits::*;

/// `InstanceUse`:
///
/// ```prism
/// type InstanceUse = choice:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub enum InstanceUse {
    UseOfDefinition(crate::prelude::Text, crate::prelude::Text, crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>),
    UseOfImpl(crate::prelude::Text, crate::prelude::Text, crate::check::types::Ty),
    UseOfMethod(crate::prelude::Text, crate::prelude::Text, crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>),
}

impl crate::prelude::Show for InstanceUse {
    fn show(&self, p: &mut crate::prelude::Printer) {
        match self {
            InstanceUse::UseOfDefinition(a0, a1, a2) => p.choice("UseOfDefinition", &[a0, a1, a2]),
            InstanceUse::UseOfImpl(a0, a1, a2) => p.choice("UseOfImpl", &[a0, a1, a2]),
            InstanceUse::UseOfMethod(a0, a1, a2) => p.choice("UseOfMethod", &[a0, a1, a2]),
        }
    }
}

impl crate::prelude::ToPod for InstanceUse {
    fn to_pod(&self) -> crate::prelude::Pod {
        match self {
            InstanceUse::UseOfDefinition(a0, a1, a2) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("UseOfDefinition", 0), vec![a0.to_pod(), a1.to_pod(), a2.to_pod()]),
            InstanceUse::UseOfImpl(a0, a1, a2) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("UseOfImpl", 1), vec![a0.to_pod(), a1.to_pod(), a2.to_pod()]),
            InstanceUse::UseOfMethod(a0, a1, a2) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("UseOfMethod", 2), vec![a0.to_pod(), a1.to_pod(), a2.to_pod()]),
        }
    }
}

impl crate::prelude::FromPod for InstanceUse {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        match p.structure() {
            crate::prelude::Pod::Choice(c, a) if &**c == "UseOfDefinition" && a.len() == 3 => ::std::result::Result::Ok(InstanceUse::UseOfDefinition(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?, crate::prelude::FromPod::from_pod(&a[2])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "UseOfImpl" && a.len() == 3 => ::std::result::Result::Ok(InstanceUse::UseOfImpl(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?, crate::prelude::FromPod::from_pod(&a[2])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "UseOfMethod" && a.len() == 3 => ::std::result::Result::Ok(InstanceUse::UseOfMethod(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?, crate::prelude::FromPod::from_pod(&a[2])?)),
            other => ::prism_rtl::pod::mismatch("a InstanceUse", other),
        }
    }
}

/// `InstancesAnswer`:
///
/// ```prism
/// type InstancesAnswer = choice:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub enum InstancesAnswer {
    InstancesReached(crate::prelude::Array<Instantiation>),
    EndlessByName,
    EndlessThroughImpl,
    UndecidedParameter,
    NoDefinition,
}

impl crate::prelude::Show for InstancesAnswer {
    fn show(&self, p: &mut crate::prelude::Printer) {
        match self {
            InstancesAnswer::InstancesReached(a0) => p.choice("InstancesReached", &[a0]),
            InstancesAnswer::EndlessByName => p.choice("EndlessByName", &[]),
            InstancesAnswer::EndlessThroughImpl => p.choice("EndlessThroughImpl", &[]),
            InstancesAnswer::UndecidedParameter => p.choice("UndecidedParameter", &[]),
            InstancesAnswer::NoDefinition => p.choice("NoDefinition", &[]),
        }
    }
}

impl crate::prelude::ToPod for InstancesAnswer {
    fn to_pod(&self) -> crate::prelude::Pod {
        match self {
            InstancesAnswer::InstancesReached(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("InstancesReached", 0), vec![a0.to_pod()]),
            InstancesAnswer::EndlessByName => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("EndlessByName", 1), vec![]),
            InstancesAnswer::EndlessThroughImpl => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("EndlessThroughImpl", 2), vec![]),
            InstancesAnswer::UndecidedParameter => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("UndecidedParameter", 3), vec![]),
            InstancesAnswer::NoDefinition => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("NoDefinition", 4), vec![]),
        }
    }
}

impl crate::prelude::FromPod for InstancesAnswer {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        match p.structure() {
            crate::prelude::Pod::Choice(c, a) if &**c == "InstancesReached" && a.len() == 1 => ::std::result::Result::Ok(InstancesAnswer::InstancesReached(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "EndlessByName" && a.len() == 0 => ::std::result::Result::Ok(InstancesAnswer::EndlessByName),
            crate::prelude::Pod::Choice(c, a) if &**c == "EndlessThroughImpl" && a.len() == 0 => ::std::result::Result::Ok(InstancesAnswer::EndlessThroughImpl),
            crate::prelude::Pod::Choice(c, a) if &**c == "UndecidedParameter" && a.len() == 0 => ::std::result::Result::Ok(InstancesAnswer::UndecidedParameter),
            crate::prelude::Pod::Choice(c, a) if &**c == "NoDefinition" && a.len() == 0 => ::std::result::Result::Ok(InstancesAnswer::NoDefinition),
            other => ::prism_rtl::pod::mismatch("a InstancesAnswer", other),
        }
    }
}

/// `Instantiation`:
///
/// ```prism
/// type Instantiation = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct Instantiation {
    pub definition_p: crate::prelude::Text,
    pub types_p: crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>,
    pub parent_o: ::std::option::Option<crate::prelude::Nat>,
    pub step_o: ::std::option::Option<crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>>,
}

impl crate::prelude::Show for Instantiation {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("Instantiation", &[("definition", &self.definition_p), ("types", &self.types_p), ("parent", &self.parent_o), ("step", &self.step_o)]);
    }
}

impl crate::prelude::ToPod for Instantiation {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("Instantiation", vec![("definition", self.definition_p.to_pod()), ("types", self.types_p.to_pod()), ("parent", self.parent_o.to_pod()), ("step", self.step_o.to_pod())])
    }
}

impl crate::prelude::FromPod for Instantiation {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(Instantiation { definition_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "definition")?)?, types_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "types")?)?, parent_o: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "parent")?)?, step_o: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "step")?)? })
    }
}

/// ```prism
/// InModule: fn Lx, Nat, Text -> Lx
/// ```
pub fn in_module_f(lx_p0: &crate::lower::Lx, file_p1: &crate::prelude::Nat, home_p2: &crate::prelude::Text) -> crate::lower::Lx {
    let mut this: crate::lower::Lx = lx_p0.clone();
    this.file_p = file_p1.clone();
    this.home_p = home_p2.clone();
    this.site_p = home_p2.clone();
    this
}

/// ```prism
/// InModuleAt: fn Lx, Nat, Text, Text -> Lx
/// ```
pub fn in_module_at_f(lx_p0: &crate::lower::Lx, file_p1: &crate::prelude::Nat, home_p2: &crate::prelude::Text, site_p3: &crate::prelude::Text) -> crate::lower::Lx {
    let mut this: crate::lower::Lx = lx_p0.clone();
    this.file_p = file_p1.clone();
    this.home_p = home_p2.clone();
    this.site_p = site_p3.clone();
    this
}

/// ```prism
/// WithInferredLets: unbounded fn G, TProgram -> G
/// ```
pub fn with_inferred_lets_f(g_p0: &crate::check::env::G, tp_p1: &crate::check::typed::TProgram) -> crate::check::env::G {
    let schemes_p2 = crate::prelude::fold(&tp_p1.defs_p, &crate::prelude::Map::new(), &(|m_p3: &crate::prelude::Map<crate::prelude::Text, crate::check::types::Scheme>, n_p4: &crate::check::typed::DefNote| crate::prelude::insert(m_p3, &n_p4.name_p, &n_p4.scheme_p)));
    crate::prelude::fold(&g_p0.defs_p, g_p0, &(|sofar_p5: &crate::check::env::G, d_p6: &crate::check::env::Def| match (d_p6.body_p.clone(), crate::prelude::get(&schemes_p2, &d_p6.qk_p)) {
        (crate::check::env::DefBody::DbLet(_), ::std::option::Option::Some(scheme_p7)) => if crate::check::env::has_key_f(&sofar_p5.vals_p, &d_p6.qk_p) {
            sofar_p5.clone()
        } else {
            {
                let mut this: crate::check::env::G = sofar_p5.clone();
                this.vals_p = crate::prelude::insert(&this.vals_p, &d_p6.qk_p, &crate::check::env::ValInfo { qk_p: d_p6.qk_p.clone(), scheme_p: scheme_p7.clone(), sort_p: crate::prelude::Text::lit("let"), has_sig_p: false, home_p: d_p6.home_p.clone(), file_p: d_p6.file_p.clone(), span_p: d_p6.span_p.clone() });
                this
            }
        },
        _ => sofar_p5.clone(),
    }))
}

/// The step machine of `WithInferredLets`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// WithInferredLets: unbounded fn G, TProgram -> G
/// ```
pub struct WithInferredLets {
    pub g_p0: crate::check::env::G,
    pub tp_p1: crate::check::typed::TProgram,
}

impl ::prism_rtl::Job<crate::check::env::G> for WithInferredLets {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::env::G> {
        let g_p0 = &self.g_p0;
        let tp_p1 = &self.tp_p1;
        let schemes_p2 = crate::prelude::fold(&tp_p1.defs_p, &crate::prelude::Map::new(), &(|m_p3: &crate::prelude::Map<crate::prelude::Text, crate::check::types::Scheme>, n_p4: &crate::check::typed::DefNote| crate::prelude::insert(m_p3, &n_p4.name_p, &n_p4.scheme_p)));
        ::prism_rtl::Turn::Finished(crate::prelude::fold(&g_p0.defs_p, g_p0, &(|sofar_p5: &crate::check::env::G, d_p6: &crate::check::env::Def| match (d_p6.body_p.clone(), crate::prelude::get(&schemes_p2, &d_p6.qk_p)) {
            (crate::check::env::DefBody::DbLet(_), ::std::option::Option::Some(scheme_p7)) => if crate::check::env::has_key_f(&sofar_p5.vals_p, &d_p6.qk_p) {
                sofar_p5.clone()
            } else {
                {
                    let mut this: crate::check::env::G = sofar_p5.clone();
                    this.vals_p = crate::prelude::insert(&this.vals_p, &d_p6.qk_p, &crate::check::env::ValInfo { qk_p: d_p6.qk_p.clone(), scheme_p: scheme_p7.clone(), sort_p: crate::prelude::Text::lit("let"), has_sig_p: false, home_p: d_p6.home_p.clone(), file_p: d_p6.file_p.clone(), span_p: d_p6.span_p.clone() });
                    this
                }
            },
            _ => sofar_p5.clone(),
        })))
    }
}

/// `Start WithInferredLets, x`: what the function value is when passed to `@Run`.
pub fn start_with_inferred_lets_f(g_p0: crate::check::env::G, tp_p1: crate::check::typed::TProgram) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::env::G>> {
    ::std::rc::Rc::new(WithInferredLets { g_p0, tp_p1 })
}

/// ```prism
/// LowerProgram: unbounded fn [Src], [Module], Nat, TProgram, Text -> Model
/// ```
pub fn lower_program_f(srcs_p0: &crate::prelude::Array<crate::check::errors::Src>, trees_p1: &crate::prelude::Array<crate::syntax::Module>, shown_p2: &crate::prelude::Nat, tp_p3: &crate::check::typed::TProgram, name_p4: &crate::prelude::Text) -> crate::lower::model::Model {
    let (declared_pu, _) = crate::check::env::build_g_f(srcs_p0, trees_p1);
    let g_p5 = with_inferred_lets_f(&declared_pu, tp_p3);
    let (tys_pv, apps_p10, bs_p11, ims_p12) = crate::lower::typed_tables_f(tp_p3);
    let gens_p6 = crate::prelude::fold(&tp_p3.gens_p, &crate::prelude::Map::new(), &(|m_p13: &crate::prelude::Map<crate::prelude::Text, crate::check::typed::GenNote>, n_p14: &crate::check::typed::GenNote| crate::prelude::insert(m_p13, &crate::check::typed::at_key_f(&n_p14.at_p), n_p14)));
    let insts_p7 = crate::prelude::fold(&tp_p3.insts_p, &crate::prelude::Map::new(), &(|m_p15: &crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::check::typed::InstNote>>, n_p16: &crate::check::typed::InstNote| crate::prelude::insert(m_p15, &crate::lower::expr::inst_key_f(n_p16), &crate::prelude::push(&crate::prelude::or(&crate::prelude::get(m_p15, &crate::lower::expr::inst_key_f(n_p16)), &crate::prelude::Array::new()), n_p16))));
    let quants_p8 = crate::prelude::fold(&tp_p3.gens_p, &crate::prelude::Map::new(), &(|m_p17: &crate::prelude::Map<crate::prelude::Text, crate::prelude::Text>, n_p18: &crate::check::typed::GenNote| crate::prelude::fold(&crate::prelude::append(&n_p18.tys_p, &n_p18.cols_p), m_p17, &(|m2_p19: &crate::prelude::Map<crate::prelude::Text, crate::prelude::Text>, q_p1a: &crate::prelude::Text| crate::prelude::insert(m2_p19, q_p1a, &n_p18.name_p)))));
    let gen_of_q_p9 = crate::prelude::fold(&tp_p3.gens_p, &crate::prelude::Map::new(), &(|m_p1b: &crate::prelude::Map<crate::prelude::Text, crate::check::typed::GenNote>, n_p1c: &crate::check::typed::GenNote| crate::prelude::fold(&crate::prelude::append(&n_p1c.tys_p, &n_p1c.cols_p), m_p1b, &(|m2_p1d: &crate::prelude::Map<crate::prelude::Text, crate::check::typed::GenNote>, q_p1e: &crate::prelude::Text| crate::prelude::insert(m2_p1d, q_p1e, n_p1c)))));
    let use_insts_pa = crate::prelude::fold(&tp_p3.insts_p, &crate::prelude::Map::new(), &(|m_p1f: &crate::prelude::Map<crate::prelude::Text, crate::check::typed::InstNote>, n_p1g: &crate::check::typed::InstNote| crate::prelude::insert(m_p1f, &crate::check::typed::at_key_f(&n_p1g.at_p), n_p1g)));
    let mods_pb = needed_mods_f(&g_p5, shown_p2);
    let rs_mods_pc = crate::prelude::fold(&mods_pb, &crate::prelude::Map::new(), &(|acc_p1h: &crate::prelude::Map<crate::prelude::Text, crate::prelude::Text>, m_p1i: &crate::prelude::Text| crate::prelude::insert(acc_p1h, m_p1i, &crate::lower::rust_mod_name_f(m_p1i))));
    let mod_segments_pd = crate::prelude::fold(&crate::prelude::values(&rs_mods_pc), &crate::prelude::Map::new(), &(|acc_p1j: &crate::prelude::Map<crate::prelude::Text, bool>, p_p1k: &crate::prelude::Text| crate::prelude::fold(&crate::prelude::split_on(p_p1k, &crate::prelude::Text::lit("::")), acc_p1j, &(|a2_p1l: &crate::prelude::Map<crate::prelude::Text, bool>, seg_p1m: &crate::prelude::Text| crate::prelude::insert(a2_p1l, seg_p1m, &true)))));
    let lx0_pe = crate::lower::Lx { g_p: g_p5.clone(), tys_p: tys_pv.clone(), apps_p: apps_p10.clone(), lifts_p: crate::prelude::fold(&tp_p3.lifts_p, &crate::prelude::Map::new(), &(|m_p1n: &crate::prelude::Map<crate::prelude::Text, crate::check::typed::LiftNote>, n_p1o: &crate::check::typed::LiftNote| crate::prelude::insert(m_p1n, &crate::check::typed::at_key_f(&n_p1o.at_p), n_p1o))), binders_p: bs_p11.clone(), impls_p: ims_p12.clone(), file_p: crate::prelude::Nat::from(0u32), home_p: crate::prelude::Text::lit(""), site_p: crate::prelude::Text::lit(""), rs_mods_p: rs_mods_pc.clone(), mod_segments_p: mod_segments_pd.clone(), rs_names_p: crate::lower::value_names_f(&g_p5), layouts_p: crate::lower::types::layouts_f(&g_p5), unbs_p: crate::prelude::Array::new(), notes_p: crate::prelude::Array::new(), globals_p: crate::lower::global_names_f(&g_p5), in_node_p: false, whole_p: false, whole_fns_p: crate::prelude::Map::new(), no_cx_p: false, unshrunk_p: crate::prelude::fold(&tp_p3.unshrunk_p, &crate::prelude::Map::new(), &(|m_p1p: &crate::prelude::Map<crate::prelude::Text, bool>, a_p1q: &crate::check::typed::SrcAt| crate::prelude::insert(m_p1p, &crate::check::typed::at_key_f(a_p1q), &true))), gens_p: gens_p6.clone(), insts_p: insts_p7.clone(), quants_p: quants_p8.clone(), gen_of_q_p: gen_of_q_p9.clone(), use_insts_p: use_insts_pa.clone(), local_ids_p: crate::prelude::fold(&tp_p3.locals_p, &crate::prelude::Map::new(), &(|m_p1r: &crate::prelude::Map<crate::prelude::Text, crate::prelude::Nat>, n_p1s: &crate::check::typed::LocalNote| crate::prelude::insert(m_p1r, &crate::check::typed::at_key_f(&n_p1s.at_p), &n_p1s.id_p))), use_ids_p: crate::prelude::fold(&tp_p3.uses_p, &crate::prelude::Map::new(), &(|m_p1t: &crate::prelude::Map<crate::prelude::Text, crate::prelude::Nat>, n_p1u: &crate::check::typed::LocalNote| crate::prelude::insert(m_p1t, &crate::check::typed::at_key_f(&n_p1u.at_p), &n_p1u.id_p))), use_names_p: crate::prelude::fold(&tp_p3.uses_p, &crate::prelude::Map::new(), &(|m_p1v: &crate::prelude::Map<crate::prelude::Nat, crate::prelude::Array<(crate::prelude::Nat, crate::prelude::Text)>>, n_p20: &crate::check::typed::LocalNote| crate::prelude::insert(m_p1v, &n_p20.at_p.file_p, &crate::prelude::push(&crate::prelude::or(&crate::prelude::get(m_p1v, &n_p20.at_p.file_p), &crate::prelude::Array::new()), &(n_p20.at_p.span_p.start_p.clone(), n_p20.name_p.clone()))))), call_ids_p: crate::prelude::fold(&tp_p3.calls_p, &crate::prelude::Map::new(), &(|m_p21: &crate::prelude::Map<crate::prelude::Text, crate::prelude::Nat>, n_p22: &crate::check::typed::LocalNote| crate::prelude::insert(m_p21, &crate::check::typed::at_key_f(&n_p22.at_p), &n_p22.id_p))), inlined_p: crate::prelude::Text::lit(""), subst_p: crate::prelude::Map::new(), csubst_p: crate::prelude::Map::new(), faults_p: crate::prelude::fold(&tp_p3.faults_p, &crate::prelude::Map::new(), &(|m_p23: &crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>, n_p24: &crate::check::typed::TyNote| crate::prelude::insert(m_p23, &crate::check::typed::at_key_f(&n_p24.at_p), &n_p24.ty_p))), plains_p: crate::prelude::fold(&tp_p3.plains_p, &crate::prelude::Map::new(), &(|m_p25: &crate::prelude::Map<crate::prelude::Text, bool>, at_p26: &crate::check::typed::SrcAt| crate::prelude::insert(m_p25, &crate::check::typed::at_key_f(at_p26), &true))), shared_p: crate::prelude::Map::new(), recursing_p: crate::prelude::Array::new(), valued_p: crate::prelude::Map::new(), valued_at_p: crate::prelude::Map::new(), in_definition_p: crate::prelude::Text::lit("") };
    let (valued_cases_p27, valued_instances_p28) = valued_widgets_f(&lx0_pe);
    let lx_pf = {
        let mut this: crate::lower::Lx = lx0_pe.clone();
        this.unbs_p = job_roots_f(&lx0_pe);
        this.whole_fns_p = crate::lower::expr::whole_fns_f(&lx0_pe);
        this.valued_p = valued_cases_p27.clone();
        this.valued_at_p = valued_instances_p28.clone();
        this
    };
    let roots_pg = root_widgets_f(&lx_pf);
    let mod_defs_ph = crate::prelude::run_to_end(crate::prelude::each_job(mods_pb.clone(), {
        let lx_pfx = lx_pf.clone();
        let roots_pgx = roots_pg.clone();
        let g_p5x = g_p5.clone();
        let mods_pbx = mods_pb.clone();
        ::std::rc::Rc::new(move |p0: crate::prelude::Text| {
            let lx_pfxy = lx_pfx.clone();
            let roots_pgxy = roots_pgx.clone();
            let g_p5xy = g_p5x.clone();
            let mods_pbxy = mods_pbx.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let m_p29 = p0;
                ::prism_rtl::Turn::More(::std::rc::Rc::new(ModDefOf { lx0_p0: lx_pfxy.clone(), m_p1: m_p29.clone(), roots_p2: roots_pgxy.clone(), info_p3: crate::prelude::or(&crate::prelude::get(&g_p5xy.mods_p, &m_p29), &crate::check::env::reading::dummy_mod_p()), mods_p4: mods_pbxy.clone() }))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::ModDef>>>
    }));
    let programs_pi = crate::prelude::run_to_end(crate::prelude::each_job(roots_pg.clone(), {
        let lx_pfx = lx_pf.clone();
        ::std::rc::Rc::new(move |p0: (crate::prelude::Text, bool)| {
            let lx_pfxy = lx_pfx.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (qk_p2a, _) = p0;
                ::prism_rtl::Turn::More(::std::rc::Rc::new(ProgDefOf { lx_p0: lx_pfxy.clone(), qk_p1: qk_p2a.clone() }))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, bool)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::ProgDef>>>
    }));
    let main_qk_pj = crate::prelude::fold(&g_p5.defs_p, &crate::prelude::Text::lit(""), &(|found_p2b: &crate::prelude::Text, d_p2c: &crate::check::env::Def| if (found_p2b == &crate::prelude::Text::lit("")) && is_main_f(&d_p2c.qk_p) {
        d_p2c.qk_p.clone()
    } else {
        found_p2b.clone()
    }));
    let root_ok = if &main_qk_pj == &crate::prelude::Text::lit("") {
        ::std::option::Option::None
    } else {
        ::std::option::Option::Some(prog_def_of_f(&lx_pf, &main_qk_pj))
    };
    let checks_pl = crate::prelude::run_to_end(crate::prelude::fold_job(g_p5.defs_p.clone(), crate::prelude::Array::new(), {
        let lx_pfx = lx_pf.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::lower::model::CheckDef>, crate::check::env::Def)| {
            let lx_pfxy = lx_pfx.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_p2d = p0;
                let d_p2e = p1;
                match &d_p2e.body_p {
                    crate::check::env::DefBody::DbCheck(c_p2f) => {
                        let c_p2fx = c_p2f.clone();
                        crate::prelude::call_then(start_check_def_of_f(in_module_at_f(&lx_pfxy, &d_p2e.file_p, &d_p2e.home_p, &crate::prelude::Text::lit("\0main")), c_p2fx.clone()), move |check_def_of_f_5104: crate::lower::model::CheckDef| ::prism_rtl::Turn::Finished(crate::prelude::push(&acc_p2d, &check_def_of_f_5104)))
                    },
                    _ => ::prism_rtl::Turn::Finished(acc_p2d.clone()),
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::lower::model::CheckDef>, crate::check::env::Def)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::lower::model::CheckDef>>>>
    }));
    let with_needs_pm = with_groups_f(&with_needs_f(&g_p5, srcs_p0, tp_p3, &mod_defs_ph));
    let elem_pn = elem_row_f(&lx_pf, &mods_pb);
    let answer_po = answer_enum_f(&in_module_at_f(&lx_pf, &crate::prelude::Nat::from(0u32), &crate::prelude::Text::lit(""), &crate::prelude::Text::lit("\0main")), &mods_pb);
    let names_pp = crate::prelude::each(&with_needs_pm, &(|d_p2g: &crate::lower::model::ModDef| d_p2g.name_p.clone()));
    let value_tys_pq = value_types_f(&with_needs_pm);
    let elem_held_pr = crate::prelude::fold(&elem_pn.cases_p, &crate::prelude::Array::new(), &(|acc_p2h: &crate::prelude::Array<crate::prelude::Text>, (_, sp_p2i): &(crate::prelude::Text, crate::lower::model::Ref)| crate::check::types::union_texts_f(acc_p2h, &held_in_f(&names_pp, &value_tys_pq, &crate::prelude::Text::lit(""), &crate::lower::model::OutTy::OutNamed(sp_p2i.clone(), crate::prelude::Array::new())))));
    let answer_held_ps = crate::prelude::fold(&answer_po.cases_p, &elem_held_pr, &(|acc_p2j: &crate::prelude::Array<crate::prelude::Text>, k_p2k: &crate::lower::model::AnswerCase| crate::check::types::union_texts_f(acc_p2j, &held_in_f(&names_pp, &value_tys_pq, &crate::prelude::Text::lit(""), &k_p2k.ty_p))));
    let answer_named_pt = crate::prelude::fold(&answer_po.cases_p, &crate::prelude::Array::new(), &(|acc_p2l: &crate::prelude::Array<crate::prelude::Text>, k_p2m: &crate::lower::model::AnswerCase| crate::check::types::union_texts_f(acc_p2l, &named_in_f(&names_pp, &crate::prelude::Text::lit(""), &k_p2m.ty_p))));
    crate::lower::model::Model { name_p: name_p4.clone(), mods_p: with_needs_pm.clone(), programs_p: programs_pi.clone(), root_o: root_ok.clone(), checks_p: checks_pl.clone(), elem_p: elem_pn.clone(), answer_p: answer_po.clone(), elem_complete_p: answer_held_ps.clone(), elem_declared_p: crate::check::types::minus_texts_f(&answer_named_pt, &answer_held_ps), scripts_p: crate::prelude::Array::new(), notes_p: crate::prelude::Array::new() }
}

/// The step machine of `LowerProgram`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LowerProgram: unbounded fn [Src], [Module], Nat, TProgram, Text -> Model
/// ```
pub struct LowerProgram {
    pub srcs_p0: crate::prelude::Array<crate::check::errors::Src>,
    pub trees_p1: crate::prelude::Array<crate::syntax::Module>,
    pub shown_p2: crate::prelude::Nat,
    pub tp_p3: crate::check::typed::TProgram,
    pub name_p4: crate::prelude::Text,
}

impl ::prism_rtl::Job<crate::lower::model::Model> for LowerProgram {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::lower::model::Model> {
        let srcs_p0 = &self.srcs_p0;
        let trees_p1 = &self.trees_p1;
        let shown_p2 = &self.shown_p2;
        let tp_p3 = &self.tp_p3;
        let name_p4 = &self.name_p4;
        let name_p4x = name_p4.clone();
        let shown_p2x = shown_p2.clone();
        let srcs_p0x = srcs_p0.clone();
        let tp_p3x = tp_p3.clone();
        let trees_p1x = trees_p1.clone();
        crate::prelude::call_then(crate::check::env::start_build_g_f(srcs_p0x.clone(), trees_p1x.clone()), move |build_g_f_2625: (crate::check::env::G, crate::check::types::St)| {
            let (declared_pu, _) = build_g_f_2625;
            crate::prelude::call_then(start_with_inferred_lets_f(declared_pu.clone(), tp_p3x.clone()), move |with_inferred_lets_f_2656: crate::check::env::G| {
                let g_p5 = with_inferred_lets_f_2656;
                crate::prelude::call_then(crate::lower::start_typed_tables_f(tp_p3x.clone()), move |typed_tables_f_2719: (crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>, crate::prelude::Map<crate::prelude::Text, crate::check::typed::AppNote>, crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>, crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::check::typed::ImplNote>>)| {
                    let (tys_pv, apps_p10, bs_p11, ims_p12) = typed_tables_f_2719;
                    let gens_p6 = crate::prelude::fold(&tp_p3x.gens_p, &crate::prelude::Map::new(), &(|m_p13: &crate::prelude::Map<crate::prelude::Text, crate::check::typed::GenNote>, n_p14: &crate::check::typed::GenNote| crate::prelude::insert(m_p13, &crate::check::typed::at_key_f(&n_p14.at_p), n_p14)));
                    let insts_p7 = crate::prelude::fold(&tp_p3x.insts_p, &crate::prelude::Map::new(), &(|m_p15: &crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::check::typed::InstNote>>, n_p16: &crate::check::typed::InstNote| crate::prelude::insert(m_p15, &crate::lower::expr::inst_key_f(n_p16), &crate::prelude::push(&crate::prelude::or(&crate::prelude::get(m_p15, &crate::lower::expr::inst_key_f(n_p16)), &crate::prelude::Array::new()), n_p16))));
                    let quants_p8 = crate::prelude::fold(&tp_p3x.gens_p, &crate::prelude::Map::new(), &(|m_p17: &crate::prelude::Map<crate::prelude::Text, crate::prelude::Text>, n_p18: &crate::check::typed::GenNote| crate::prelude::fold(&crate::prelude::append(&n_p18.tys_p, &n_p18.cols_p), m_p17, &(|m2_p19: &crate::prelude::Map<crate::prelude::Text, crate::prelude::Text>, q_p1a: &crate::prelude::Text| crate::prelude::insert(m2_p19, q_p1a, &n_p18.name_p)))));
                    let gen_of_q_p9 = crate::prelude::fold(&tp_p3x.gens_p, &crate::prelude::Map::new(), &(|m_p1b: &crate::prelude::Map<crate::prelude::Text, crate::check::typed::GenNote>, n_p1c: &crate::check::typed::GenNote| crate::prelude::fold(&crate::prelude::append(&n_p1c.tys_p, &n_p1c.cols_p), m_p1b, &(|m2_p1d: &crate::prelude::Map<crate::prelude::Text, crate::check::typed::GenNote>, q_p1e: &crate::prelude::Text| crate::prelude::insert(m2_p1d, q_p1e, n_p1c)))));
                    let use_insts_pa = crate::prelude::fold(&tp_p3x.insts_p, &crate::prelude::Map::new(), &(|m_p1f: &crate::prelude::Map<crate::prelude::Text, crate::check::typed::InstNote>, n_p1g: &crate::check::typed::InstNote| crate::prelude::insert(m_p1f, &crate::check::typed::at_key_f(&n_p1g.at_p), n_p1g)));
                    crate::prelude::call_then(start_needed_mods_f(g_p5.clone(), shown_p2x.clone()), move |needed_mods_f_3193: crate::prelude::Array<crate::prelude::Text>| {
                        let mods_pb = needed_mods_f_3193;
                        let rs_mods_pc = crate::prelude::fold(&mods_pb, &crate::prelude::Map::new(), &(|acc_p1h: &crate::prelude::Map<crate::prelude::Text, crate::prelude::Text>, m_p1i: &crate::prelude::Text| crate::prelude::insert(acc_p1h, m_p1i, &crate::lower::rust_mod_name_f(m_p1i))));
                        let mod_segments_pd = crate::prelude::fold(&crate::prelude::values(&rs_mods_pc), &crate::prelude::Map::new(), &(|acc_p1j: &crate::prelude::Map<crate::prelude::Text, bool>, p_p1k: &crate::prelude::Text| crate::prelude::fold(&crate::prelude::split_on(p_p1k, &crate::prelude::Text::lit("::")), acc_p1j, &(|a2_p1l: &crate::prelude::Map<crate::prelude::Text, bool>, seg_p1m: &crate::prelude::Text| crate::prelude::insert(a2_p1l, seg_p1m, &true)))));
                        crate::prelude::call_then(crate::lower::start_value_names_f(g_p5.clone()), move |value_names_f_3607: crate::prelude::Map<crate::prelude::Text, crate::prelude::Text>| crate::prelude::call_then(crate::lower::types::start_layouts_f(g_p5.clone()), move |layouts_f_3631: crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<bool>>| crate::prelude::call_then(crate::lower::start_global_names_f(g_p5.clone()), move |global_names_f_3675: crate::prelude::Map<crate::prelude::Text, bool>| {
                            let lx0_pe = crate::lower::Lx { g_p: g_p5.clone(), tys_p: tys_pv.clone(), apps_p: apps_p10.clone(), lifts_p: crate::prelude::fold(&tp_p3x.lifts_p, &crate::prelude::Map::new(), &(|m_p1n: &crate::prelude::Map<crate::prelude::Text, crate::check::typed::LiftNote>, n_p1o: &crate::check::typed::LiftNote| crate::prelude::insert(m_p1n, &crate::check::typed::at_key_f(&n_p1o.at_p), n_p1o))), binders_p: bs_p11.clone(), impls_p: ims_p12.clone(), file_p: crate::prelude::Nat::from(0u32), home_p: crate::prelude::Text::lit(""), site_p: crate::prelude::Text::lit(""), rs_mods_p: rs_mods_pc.clone(), mod_segments_p: mod_segments_pd.clone(), rs_names_p: value_names_f_3607, layouts_p: layouts_f_3631, unbs_p: crate::prelude::Array::new(), notes_p: crate::prelude::Array::new(), globals_p: global_names_f_3675, in_node_p: false, whole_p: false, whole_fns_p: crate::prelude::Map::new(), no_cx_p: false, unshrunk_p: crate::prelude::fold(&tp_p3x.unshrunk_p, &crate::prelude::Map::new(), &(|m_p1p: &crate::prelude::Map<crate::prelude::Text, bool>, a_p1q: &crate::check::typed::SrcAt| crate::prelude::insert(m_p1p, &crate::check::typed::at_key_f(a_p1q), &true))), gens_p: gens_p6.clone(), insts_p: insts_p7.clone(), quants_p: quants_p8.clone(), gen_of_q_p: gen_of_q_p9.clone(), use_insts_p: use_insts_pa.clone(), local_ids_p: crate::prelude::fold(&tp_p3x.locals_p, &crate::prelude::Map::new(), &(|m_p1r: &crate::prelude::Map<crate::prelude::Text, crate::prelude::Nat>, n_p1s: &crate::check::typed::LocalNote| crate::prelude::insert(m_p1r, &crate::check::typed::at_key_f(&n_p1s.at_p), &n_p1s.id_p))), use_ids_p: crate::prelude::fold(&tp_p3x.uses_p, &crate::prelude::Map::new(), &(|m_p1t: &crate::prelude::Map<crate::prelude::Text, crate::prelude::Nat>, n_p1u: &crate::check::typed::LocalNote| crate::prelude::insert(m_p1t, &crate::check::typed::at_key_f(&n_p1u.at_p), &n_p1u.id_p))), use_names_p: crate::prelude::fold(&tp_p3x.uses_p, &crate::prelude::Map::new(), &(|m_p1v: &crate::prelude::Map<crate::prelude::Nat, crate::prelude::Array<(crate::prelude::Nat, crate::prelude::Text)>>, n_p20: &crate::check::typed::LocalNote| crate::prelude::insert(m_p1v, &n_p20.at_p.file_p, &crate::prelude::push(&crate::prelude::or(&crate::prelude::get(m_p1v, &n_p20.at_p.file_p), &crate::prelude::Array::new()), &(n_p20.at_p.span_p.start_p.clone(), n_p20.name_p.clone()))))), call_ids_p: crate::prelude::fold(&tp_p3x.calls_p, &crate::prelude::Map::new(), &(|m_p21: &crate::prelude::Map<crate::prelude::Text, crate::prelude::Nat>, n_p22: &crate::check::typed::LocalNote| crate::prelude::insert(m_p21, &crate::check::typed::at_key_f(&n_p22.at_p), &n_p22.id_p))), inlined_p: crate::prelude::Text::lit(""), subst_p: crate::prelude::Map::new(), csubst_p: crate::prelude::Map::new(), faults_p: crate::prelude::fold(&tp_p3x.faults_p, &crate::prelude::Map::new(), &(|m_p23: &crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>, n_p24: &crate::check::typed::TyNote| crate::prelude::insert(m_p23, &crate::check::typed::at_key_f(&n_p24.at_p), &n_p24.ty_p))), plains_p: crate::prelude::fold(&tp_p3x.plains_p, &crate::prelude::Map::new(), &(|m_p25: &crate::prelude::Map<crate::prelude::Text, bool>, at_p26: &crate::check::typed::SrcAt| crate::prelude::insert(m_p25, &crate::check::typed::at_key_f(at_p26), &true))), shared_p: crate::prelude::Map::new(), recursing_p: crate::prelude::Array::new(), valued_p: crate::prelude::Map::new(), valued_at_p: crate::prelude::Map::new(), in_definition_p: crate::prelude::Text::lit("") };
                            crate::prelude::call_then(start_valued_widgets_f(lx0_pe.clone()), move |valued_widgets_f_4481: (crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::lower::model::Pa, crate::prelude::Array<crate::lower::model::Cc>, crate::prelude::Array<crate::lower::model::Ex>)>>, crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>>)| {
                                let (valued_cases_p27, valued_instances_p28) = valued_widgets_f_4481;
                                let lx_pf = {
                                    let mut this: crate::lower::Lx = lx0_pe.clone();
                                    this.unbs_p = job_roots_f(&lx0_pe);
                                    this.whole_fns_p = crate::lower::expr::whole_fns_f(&lx0_pe);
                                    this.valued_p = valued_cases_p27.clone();
                                    this.valued_at_p = valued_instances_p28.clone();
                                    this
                                };
                                let roots_pg = root_widgets_f(&lx_pf);
                                crate::prelude::call_value(crate::prelude::each_job(mods_pb.clone(), {
                                    let lx_pfx = lx_pf.clone();
                                    let roots_pgx = roots_pg.clone();
                                    let g_p5x = g_p5.clone();
                                    let mods_pbx = mods_pb.clone();
                                    ::std::rc::Rc::new(move |p0: crate::prelude::Text| {
                                        let lx_pfxy = lx_pfx.clone();
                                        let roots_pgxy = roots_pgx.clone();
                                        let g_p5xy = g_p5x.clone();
                                        let mods_pbxy = mods_pbx.clone();
                                        crate::prelude::entered(crate::prelude::once_job(move || {
                                            let m_p29 = p0;
                                            ::prism_rtl::Turn::More(::std::rc::Rc::new(ModDefOf { lx0_p0: lx_pfxy.clone(), m_p1: m_p29.clone(), roots_p2: roots_pgxy.clone(), info_p3: crate::prelude::or(&crate::prelude::get(&g_p5xy.mods_p, &m_p29), &crate::check::env::reading::dummy_mod_p()), mods_p4: mods_pbxy.clone() }))
                                        }))
                                    }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::ModDef>>>
                                }), move |each_4713: crate::prelude::Array<crate::lower::model::ModDef>| {
                                    let mod_defs_ph = each_4713;
                                    crate::prelude::call_value(crate::prelude::each_job(roots_pg.clone(), {
                                        let lx_pfx = lx_pf.clone();
                                        ::std::rc::Rc::new(move |p0: (crate::prelude::Text, bool)| {
                                            let lx_pfxy = lx_pfx.clone();
                                            crate::prelude::entered(crate::prelude::once_job(move || {
                                                let (qk_p2a, _) = p0;
                                                ::prism_rtl::Turn::More(::std::rc::Rc::new(ProgDefOf { lx_p0: lx_pfxy.clone(), qk_p1: qk_p2a.clone() }))
                                            }))
                                        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, bool)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::ProgDef>>>
                                    }), move |each_4802: crate::prelude::Array<crate::lower::model::ProgDef>| {
                                        let programs_pi = each_4802;
                                        let main_qk_pj = crate::prelude::fold(&g_p5.defs_p, &crate::prelude::Text::lit(""), &(|found_p2b: &crate::prelude::Text, d_p2c: &crate::check::env::Def| if (found_p2b == &crate::prelude::Text::lit("")) && is_main_f(&d_p2c.qk_p) {
                                            d_p2c.qk_p.clone()
                                        } else {
                                            found_p2b.clone()
                                        }));
                                        let root_ok = if &main_qk_pj == &crate::prelude::Text::lit("") {
                                            ::std::option::Option::None
                                        } else {
                                            ::std::option::Option::Some(prog_def_of_f(&lx_pf, &main_qk_pj))
                                        };
                                        crate::prelude::call_value(crate::prelude::fold_job(g_p5.defs_p.clone(), crate::prelude::Array::new(), {
                                            let lx_pfx = lx_pf.clone();
                                            ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::lower::model::CheckDef>, crate::check::env::Def)| {
                                                let lx_pfxy = lx_pfx.clone();
                                                crate::prelude::entered(crate::prelude::once_job(move || {
                                                    let acc_p2d = p0;
                                                    let d_p2e = p1;
                                                    match &d_p2e.body_p {
                                                        crate::check::env::DefBody::DbCheck(c_p2f) => {
                                                            let c_p2fx = c_p2f.clone();
                                                            crate::prelude::call_then(start_check_def_of_f(in_module_at_f(&lx_pfxy, &d_p2e.file_p, &d_p2e.home_p, &crate::prelude::Text::lit("\0main")), c_p2fx.clone()), move |check_def_of_f_5104: crate::lower::model::CheckDef| ::prism_rtl::Turn::Finished(crate::prelude::push(&acc_p2d, &check_def_of_f_5104)))
                                                        },
                                                        _ => ::prism_rtl::Turn::Finished(acc_p2d.clone()),
                                                    }
                                                }))
                                            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::lower::model::CheckDef>, crate::check::env::Def)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::lower::model::CheckDef>>>>
                                        }), move |fold_5031: crate::prelude::Array<crate::lower::model::CheckDef>| {
                                            let checks_pl = fold_5031;
                                            crate::prelude::call_then(start_with_needs_f(g_p5.clone(), srcs_p0x.clone(), tp_p3x.clone(), mod_defs_ph.clone()), move |with_needs_f_5219: crate::prelude::Array<crate::lower::model::ModDef>| crate::prelude::call_then(start_with_groups_f(with_needs_f_5219), move |with_groups_f_5207: crate::prelude::Array<crate::lower::model::ModDef>| {
                                                let with_needs_pm = with_groups_f_5207;
                                                crate::prelude::call_then(start_elem_row_f(lx_pf.clone(), mods_pb.clone()), move |elem_row_f_5266: crate::lower::model::RowDef| {
                                                    let elem_pn = elem_row_f_5266;
                                                    crate::prelude::call_then(start_answer_enum_f(in_module_at_f(&lx_pf, &crate::prelude::Nat::from(0u32), &crate::prelude::Text::lit(""), &crate::prelude::Text::lit("\0main")), mods_pb.clone()), move |answer_enum_f_5300: crate::lower::model::AnswerDef| {
                                                        let answer_po = answer_enum_f_5300;
                                                        let names_pp = crate::prelude::each(&with_needs_pm, &(|d_p2g: &crate::lower::model::ModDef| d_p2g.name_p.clone()));
                                                        let value_tys_pq = value_types_f(&with_needs_pm);
                                                        let elem_held_pr = crate::prelude::fold(&elem_pn.cases_p, &crate::prelude::Array::new(), &(|acc_p2h: &crate::prelude::Array<crate::prelude::Text>, (_, sp_p2i): &(crate::prelude::Text, crate::lower::model::Ref)| crate::check::types::union_texts_f(acc_p2h, &held_in_f(&names_pp, &value_tys_pq, &crate::prelude::Text::lit(""), &crate::lower::model::OutTy::OutNamed(sp_p2i.clone(), crate::prelude::Array::new())))));
                                                        let answer_held_ps = crate::prelude::fold(&answer_po.cases_p, &elem_held_pr, &(|acc_p2j: &crate::prelude::Array<crate::prelude::Text>, k_p2k: &crate::lower::model::AnswerCase| crate::check::types::union_texts_f(acc_p2j, &held_in_f(&names_pp, &value_tys_pq, &crate::prelude::Text::lit(""), &k_p2k.ty_p))));
                                                        let answer_named_pt = crate::prelude::fold(&answer_po.cases_p, &crate::prelude::Array::new(), &(|acc_p2l: &crate::prelude::Array<crate::prelude::Text>, k_p2m: &crate::lower::model::AnswerCase| crate::check::types::union_texts_f(acc_p2l, &named_in_f(&names_pp, &crate::prelude::Text::lit(""), &k_p2m.ty_p))));
                                                        ::prism_rtl::Turn::Finished(crate::lower::model::Model { name_p: name_p4x.clone(), mods_p: with_needs_pm.clone(), programs_p: programs_pi.clone(), root_o: root_ok.clone(), checks_p: checks_pl.clone(), elem_p: elem_pn.clone(), answer_p: answer_po.clone(), elem_complete_p: answer_held_ps.clone(), elem_declared_p: crate::check::types::minus_texts_f(&answer_named_pt, &answer_held_ps), scripts_p: crate::prelude::Array::new(), notes_p: crate::prelude::Array::new() })
                                                    })
                                                })
                                            }))
                                        })
                                    })
                                })
                            })
                        })))
                    })
                })
            })
        })
    }
}

/// `Start LowerProgram, x`: what the function value is when passed to `@Run`.
pub fn start_lower_program_f(srcs_p0: crate::prelude::Array<crate::check::errors::Src>, trees_p1: crate::prelude::Array<crate::syntax::Module>, shown_p2: crate::prelude::Nat, tp_p3: crate::check::typed::TProgram, name_p4: crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Model>> {
    ::std::rc::Rc::new(LowerProgram { srcs_p0, trees_p1, shown_p2, tp_p3, name_p4 })
}

/// ```prism
/// WithNeeds: unbounded fn G, [Src], TProgram, [ModDef] -> [ModDef]
/// ```
pub fn with_needs_f(g_p0: &crate::check::env::G, srcs_p1: &crate::prelude::Array<crate::check::errors::Src>, tp_p2: &crate::check::typed::TProgram, defs_p3: &crate::prelude::Array<crate::lower::model::ModDef>) -> crate::prelude::Array<crate::lower::model::ModDef> {
    let names_p4 = crate::prelude::each(defs_p3, &(|d_p7: &crate::lower::model::ModDef| d_p7.name_p.clone()));
    let value_tys_p5 = value_types_f(defs_p3);
    let refs_p6 = named_mods_f(g_p0, srcs_p1, tp_p2, &crate::prelude::each(defs_p3, &(|d_p8: &crate::lower::model::ModDef| d_p8.prism_p.clone())));
    crate::prelude::run_to_end(crate::prelude::each_job(defs_p3.clone(), {
        let names_p4x = names_p4.clone();
        let value_tys_p5x = value_tys_p5.clone();
        let refs_p6x = refs_p6.clone();
        ::std::rc::Rc::new(move |p0: crate::lower::model::ModDef| {
            let names_p4xy = names_p4x.clone();
            let value_tys_p5xy = value_tys_p5x.clone();
            let refs_p6xy = refs_p6x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let d_p9 = p0;
                {
                    let held_pa = crate::prelude::fold(&d_p9.items_p, &crate::prelude::Array::new(), &(|acc_pe: &crate::prelude::Array<crate::prelude::Text>, it_pf: &crate::lower::model::Item| crate::check::types::union_texts_f(acc_pe, &item_held_f(&names_p4xy, &value_tys_p5xy, &d_p9.name_p, it_pf))));
                    let complete_pb = crate::prelude::filter(&held_pa, &(|n_pg: &crate::prelude::Text| n_pg != &d_p9.name_p));
                    crate::prelude::call_then(start_reached_by_f(refs_p6xy.clone(), crate::prelude::Array::from(vec![d_p9.prism_p.clone()]), crate::prelude::Array::new()), move |reached_by_f_6515: crate::prelude::Array<crate::prelude::Text>| {
                        let reached_pc = crate::prelude::each(&reached_by_f_6515, &(|m_ph: &crate::prelude::Text| crate::lower::rust_mod_name_f(m_ph)));
                        let declared_pd = crate::prelude::filter(&names_p4xy, &(|n_pi: &crate::prelude::Text| ((n_pi != &d_p9.name_p) && crate::check::types::has_text_f(&reached_pc, n_pi)) && !crate::check::types::has_text_f(&complete_pb, n_pi)));
                        ::prism_rtl::Turn::Finished({
                            let mut this: crate::lower::model::ModDef = d_p9.clone();
                            this.complete_p = complete_pb.clone();
                            this.declared_p = declared_pd.clone();
                            this
                        })
                    })
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::ModDef) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::ModDef>>>
    }))
}

/// The step machine of `WithNeeds`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// WithNeeds: unbounded fn G, [Src], TProgram, [ModDef] -> [ModDef]
/// ```
pub struct WithNeeds {
    pub g_p0: crate::check::env::G,
    pub srcs_p1: crate::prelude::Array<crate::check::errors::Src>,
    pub tp_p2: crate::check::typed::TProgram,
    pub defs_p3: crate::prelude::Array<crate::lower::model::ModDef>,
}

impl ::prism_rtl::Job<crate::prelude::Array<crate::lower::model::ModDef>> for WithNeeds {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<crate::lower::model::ModDef>> {
        let g_p0 = &self.g_p0;
        let srcs_p1 = &self.srcs_p1;
        let tp_p2 = &self.tp_p2;
        let defs_p3 = &self.defs_p3;
        let names_p4 = crate::prelude::each(defs_p3, &(|d_p7: &crate::lower::model::ModDef| d_p7.name_p.clone()));
        let value_tys_p5 = value_types_f(defs_p3);
        let defs_p3x = defs_p3.clone();
        let g_p0x = g_p0.clone();
        let srcs_p1x = srcs_p1.clone();
        let tp_p2x = tp_p2.clone();
        crate::prelude::call_then(start_named_mods_f(g_p0x.clone(), srcs_p1x.clone(), tp_p2x.clone(), crate::prelude::each(&defs_p3x, &(|d_p8: &crate::lower::model::ModDef| d_p8.prism_p.clone()))), move |named_mods_f_6260: crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>>| {
            let refs_p6 = named_mods_f_6260;
            crate::prelude::each_job(defs_p3x.clone(), {
                let names_p4x = names_p4.clone();
                let value_tys_p5x = value_tys_p5.clone();
                let refs_p6x = refs_p6.clone();
                ::std::rc::Rc::new(move |p0: crate::lower::model::ModDef| {
                    let names_p4xy = names_p4x.clone();
                    let value_tys_p5xy = value_tys_p5x.clone();
                    let refs_p6xy = refs_p6x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let d_p9 = p0;
                        {
                            let held_pa = crate::prelude::fold(&d_p9.items_p, &crate::prelude::Array::new(), &(|acc_pe: &crate::prelude::Array<crate::prelude::Text>, it_pf: &crate::lower::model::Item| crate::check::types::union_texts_f(acc_pe, &item_held_f(&names_p4xy, &value_tys_p5xy, &d_p9.name_p, it_pf))));
                            let complete_pb = crate::prelude::filter(&held_pa, &(|n_pg: &crate::prelude::Text| n_pg != &d_p9.name_p));
                            crate::prelude::call_then(start_reached_by_f(refs_p6xy.clone(), crate::prelude::Array::from(vec![d_p9.prism_p.clone()]), crate::prelude::Array::new()), move |reached_by_f_6515: crate::prelude::Array<crate::prelude::Text>| {
                                let reached_pc = crate::prelude::each(&reached_by_f_6515, &(|m_ph: &crate::prelude::Text| crate::lower::rust_mod_name_f(m_ph)));
                                let declared_pd = crate::prelude::filter(&names_p4xy, &(|n_pi: &crate::prelude::Text| ((n_pi != &d_p9.name_p) && crate::check::types::has_text_f(&reached_pc, n_pi)) && !crate::check::types::has_text_f(&complete_pb, n_pi)));
                                ::prism_rtl::Turn::Finished({
                                    let mut this: crate::lower::model::ModDef = d_p9.clone();
                                    this.complete_p = complete_pb.clone();
                                    this.declared_p = declared_pd.clone();
                                    this
                                })
                            })
                        }
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::ModDef) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::ModDef>>>
            }).cycle()
        })
    }
}

/// `Start WithNeeds, x`: what the function value is when passed to `@Run`.
pub fn start_with_needs_f(g_p0: crate::check::env::G, srcs_p1: crate::prelude::Array<crate::check::errors::Src>, tp_p2: crate::check::typed::TProgram, defs_p3: crate::prelude::Array<crate::lower::model::ModDef>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::lower::model::ModDef>>> {
    ::std::rc::Rc::new(WithNeeds { g_p0, srcs_p1, tp_p2, defs_p3 })
}

/// ```prism
/// NamedMods: unbounded fn G, [Src], TProgram, [Text] -> (Text ==> [Text])
/// ```
pub fn named_mods_f(g_p0: &crate::check::env::G, srcs_p1: &crate::prelude::Array<crate::check::errors::Src>, tp_p2: &crate::check::typed::TProgram, ms_p3: &crate::prelude::Array<crate::prelude::Text>) -> crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>> {
    let by_path_p4 = crate::prelude::fold(&crate::prelude::values(&g_p0.mods_p), &crate::prelude::Map::new(), &(|acc_p7: &crate::prelude::Map<crate::prelude::Text, crate::prelude::Text>, info_p8: &crate::check::env::ModInfo| crate::prelude::insert(acc_p7, &crate::prelude::or(&crate::prelude::index(srcs_p1, &info_p8.file_p), &crate::check::errors::mk_src_f(&crate::prelude::Text::lit(""), &crate::prelude::Text::lit(""))).path_p, &info_p8.name_p)));
    let by_file_p5 = crate::prelude::fold(&crate::prelude::values(&g_p0.mods_p), &crate::prelude::Map::new(), &(|acc_p9: &crate::prelude::Map<crate::prelude::Nat, crate::prelude::Text>, info_pa: &crate::check::env::ModInfo| crate::prelude::insert(acc_p9, &info_pa.file_p, &info_pa.name_p)));
    let solved_p6 = crate::prelude::fold(&tp_p2.impls_p, &crate::prelude::Map::new(), &(|acc_pb: &crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>>, n_pc: &crate::check::typed::ImplNote| match crate::prelude::get(&by_file_p5, &n_pc.at_p.file_p) {
        ::std::option::Option::Some(site_pd) => match crate::prelude::get(&by_path_p4, &impl_path_f(&n_pc.how_p)) {
            ::std::option::Option::Some(home_pe) => if (&home_pe == &site_pd) || crate::check::types::has_text_f(&crate::prelude::or(&crate::prelude::get(acc_pb, &site_pd), &crate::prelude::Array::new()), &home_pe) {
                acc_pb.clone()
            } else {
                crate::prelude::insert(acc_pb, &site_pd, &crate::prelude::push(&crate::prelude::or(&crate::prelude::get(acc_pb, &site_pd), &crate::prelude::Array::new()), &home_pe))
            },
            ::std::option::Option::None => acc_pb.clone(),
        },
        ::std::option::Option::None => acc_pb.clone(),
    }));
    crate::prelude::run_to_end(crate::prelude::fold_job(ms_p3.clone(), crate::prelude::Map::new(), {
        let g_p0x = g_p0.clone();
        let tp_p2x = tp_p2.clone();
        let ms_p3x = ms_p3.clone();
        let solved_p6x = solved_p6.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>>, crate::prelude::Text)| {
            let g_p0xy = g_p0x.clone();
            let tp_p2xy = tp_p2x.clone();
            let ms_p3xy = ms_p3x.clone();
            let solved_p6xy = solved_p6x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_pf = p0;
                let m_pg = p1;
                match crate::prelude::get(&g_p0xy.mods_p, &m_pg) {
                    ::std::option::Option::Some(info_ph) => crate::prelude::call_then(start_types_named_in_f(tp_p2xy.clone(), info_ph.file_p.clone()), move |types_named_in_f_7985: crate::prelude::Array<crate::prelude::Text>| {
                        let named_pi = crate::prelude::append(&crate::prelude::each(&crate::prelude::filter(&tp_p2xy.globals_p, &(|n_pk: &crate::check::typed::GlobalNote| &n_pk.at_p.file_p == &info_ph.file_p)), &(|n_pl: &crate::check::typed::GlobalNote| n_pl.target_p.clone())), &types_named_in_f_7985);
                        let qualified_pj = crate::prelude::filter(&ms_p3xy, &(|o_pm: &crate::prelude::Text| ((o_pm != &m_pg) && (o_pm != &crate::prelude::Text::lit(""))) && crate::prelude::fold(&named_pi, &false, &(|f_pn: &bool, k_po: &crate::prelude::Text| *f_pn || (&crate::lower::owner_of_f(k_po) == o_pm)))));
                        crate::prelude::call_then(start_mod_refs_f(g_p0xy.clone(), m_pg.clone()), move |mod_refs_f_8181: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::prelude::insert(&acc_pf, &m_pg, &crate::check::types::union_texts_f(&crate::check::types::union_texts_f(&mod_refs_f_8181, &qualified_pj), &crate::prelude::or(&crate::prelude::get(&solved_p6xy, &m_pg), &crate::prelude::Array::new())))))
                    }),
                    ::std::option::Option::None => ::prism_rtl::Turn::Finished(acc_pf.clone()),
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>>, crate::prelude::Text)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>>>>>
    }))
}

/// The step machine of `NamedMods`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// NamedMods: unbounded fn G, [Src], TProgram, [Text] -> (Text ==> [Text])
/// ```
pub struct NamedMods {
    pub g_p0: crate::check::env::G,
    pub srcs_p1: crate::prelude::Array<crate::check::errors::Src>,
    pub tp_p2: crate::check::typed::TProgram,
    pub ms_p3: crate::prelude::Array<crate::prelude::Text>,
}

impl ::prism_rtl::Job<crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>>> for NamedMods {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>>> {
        let g_p0 = &self.g_p0;
        let srcs_p1 = &self.srcs_p1;
        let tp_p2 = &self.tp_p2;
        let ms_p3 = &self.ms_p3;
        let by_path_p4 = crate::prelude::fold(&crate::prelude::values(&g_p0.mods_p), &crate::prelude::Map::new(), &(|acc_p7: &crate::prelude::Map<crate::prelude::Text, crate::prelude::Text>, info_p8: &crate::check::env::ModInfo| crate::prelude::insert(acc_p7, &crate::prelude::or(&crate::prelude::index(srcs_p1, &info_p8.file_p), &crate::check::errors::mk_src_f(&crate::prelude::Text::lit(""), &crate::prelude::Text::lit(""))).path_p, &info_p8.name_p)));
        let by_file_p5 = crate::prelude::fold(&crate::prelude::values(&g_p0.mods_p), &crate::prelude::Map::new(), &(|acc_p9: &crate::prelude::Map<crate::prelude::Nat, crate::prelude::Text>, info_pa: &crate::check::env::ModInfo| crate::prelude::insert(acc_p9, &info_pa.file_p, &info_pa.name_p)));
        let solved_p6 = crate::prelude::fold(&tp_p2.impls_p, &crate::prelude::Map::new(), &(|acc_pb: &crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>>, n_pc: &crate::check::typed::ImplNote| match crate::prelude::get(&by_file_p5, &n_pc.at_p.file_p) {
            ::std::option::Option::Some(site_pd) => match crate::prelude::get(&by_path_p4, &impl_path_f(&n_pc.how_p)) {
                ::std::option::Option::Some(home_pe) => if (&home_pe == &site_pd) || crate::check::types::has_text_f(&crate::prelude::or(&crate::prelude::get(acc_pb, &site_pd), &crate::prelude::Array::new()), &home_pe) {
                    acc_pb.clone()
                } else {
                    crate::prelude::insert(acc_pb, &site_pd, &crate::prelude::push(&crate::prelude::or(&crate::prelude::get(acc_pb, &site_pd), &crate::prelude::Array::new()), &home_pe))
                },
                ::std::option::Option::None => acc_pb.clone(),
            },
            ::std::option::Option::None => acc_pb.clone(),
        }));
        crate::prelude::fold_job(ms_p3.clone(), crate::prelude::Map::new(), {
            let g_p0x = g_p0.clone();
            let tp_p2x = tp_p2.clone();
            let ms_p3x = ms_p3.clone();
            let solved_p6x = solved_p6.clone();
            ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>>, crate::prelude::Text)| {
                let g_p0xy = g_p0x.clone();
                let tp_p2xy = tp_p2x.clone();
                let ms_p3xy = ms_p3x.clone();
                let solved_p6xy = solved_p6x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let acc_pf = p0;
                    let m_pg = p1;
                    match crate::prelude::get(&g_p0xy.mods_p, &m_pg) {
                        ::std::option::Option::Some(info_ph) => crate::prelude::call_then(start_types_named_in_f(tp_p2xy.clone(), info_ph.file_p.clone()), move |types_named_in_f_7985: crate::prelude::Array<crate::prelude::Text>| {
                            let named_pi = crate::prelude::append(&crate::prelude::each(&crate::prelude::filter(&tp_p2xy.globals_p, &(|n_pk: &crate::check::typed::GlobalNote| &n_pk.at_p.file_p == &info_ph.file_p)), &(|n_pl: &crate::check::typed::GlobalNote| n_pl.target_p.clone())), &types_named_in_f_7985);
                            let qualified_pj = crate::prelude::filter(&ms_p3xy, &(|o_pm: &crate::prelude::Text| ((o_pm != &m_pg) && (o_pm != &crate::prelude::Text::lit(""))) && crate::prelude::fold(&named_pi, &false, &(|f_pn: &bool, k_po: &crate::prelude::Text| *f_pn || (&crate::lower::owner_of_f(k_po) == o_pm)))));
                            crate::prelude::call_then(start_mod_refs_f(g_p0xy.clone(), m_pg.clone()), move |mod_refs_f_8181: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::prelude::insert(&acc_pf, &m_pg, &crate::check::types::union_texts_f(&crate::check::types::union_texts_f(&mod_refs_f_8181, &qualified_pj), &crate::prelude::or(&crate::prelude::get(&solved_p6xy, &m_pg), &crate::prelude::Array::new())))))
                        }),
                        ::std::option::Option::None => ::prism_rtl::Turn::Finished(acc_pf.clone()),
                    }
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>>, crate::prelude::Text)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>>>>>
        }).cycle()
    }
}

/// `Start NamedMods, x`: what the function value is when passed to `@Run`.
pub fn start_named_mods_f(g_p0: crate::check::env::G, srcs_p1: crate::prelude::Array<crate::check::errors::Src>, tp_p2: crate::check::typed::TProgram, ms_p3: crate::prelude::Array<crate::prelude::Text>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>>>> {
    ::std::rc::Rc::new(NamedMods { g_p0, srcs_p1, tp_p2, ms_p3 })
}

/// ```prism
/// TypesNamedIn: unbounded fn TProgram, Nat -> [Text]
/// ```
pub fn types_named_in_f(tp_p0: &crate::check::typed::TProgram, file_p1: &crate::prelude::Nat) -> crate::prelude::Array<crate::prelude::Text> {
    let from_exprs_p2 = crate::prelude::run_to_end(crate::prelude::fold_job(crate::prelude::filter(&tp_p0.exprs_p, &(|n_p4: &crate::check::typed::TyNote| &n_p4.at_p.file_p == file_p1)), crate::prelude::Array::new(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::check::typed::TyNote)| crate::prelude::entered(crate::prelude::once_job(move || {
        let acc_p5 = p0;
        let n_p6 = p1;
        crate::prelude::call_then(start_ty_con_names_f(n_p6.ty_p.clone()), move |ty_con_names_f_8596: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_p5, &ty_con_names_f_8596)))
    }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::check::typed::TyNote)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>));
    let from_binders_p3 = crate::prelude::run_to_end(crate::prelude::fold_job(crate::prelude::filter(&tp_p0.binders_p, &(|n_p7: &crate::check::typed::BinderNote| &n_p7.at_p.file_p == file_p1)), from_exprs_p2.clone(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::check::typed::BinderNote)| crate::prelude::entered(crate::prelude::once_job(move || {
        let acc_p8 = p0;
        let n_p9 = p1;
        crate::prelude::call_then(start_ty_con_names_f(n_p9.ty_p.clone()), move |ty_con_names_f_8723: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_p8, &ty_con_names_f_8723)))
    }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::check::typed::BinderNote)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>));
    crate::prelude::run_to_end(crate::prelude::fold_job(crate::prelude::filter(&tp_p0.defs_p, &(|n_pa: &crate::check::typed::DefNote| &n_pa.at_p.file_p == file_p1)), from_binders_p3.clone(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::check::typed::DefNote)| crate::prelude::entered(crate::prelude::once_job(move || {
        let acc_pb = p0;
        let n_pc = p1;
        crate::prelude::call_then(start_ty_con_names_f(n_pc.scheme_p.ty_p.clone()), move |ty_con_names_f_8831: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_pb, &ty_con_names_f_8831)))
    }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::check::typed::DefNote)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>))
}

/// The step machine of `TypesNamedIn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TypesNamedIn: unbounded fn TProgram, Nat -> [Text]
/// ```
pub struct TypesNamedIn {
    pub tp_p0: crate::check::typed::TProgram,
    pub file_p1: crate::prelude::Nat,
}

impl ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>> for TypesNamedIn {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<crate::prelude::Text>> {
        let tp_p0 = &self.tp_p0;
        let file_p1 = &self.file_p1;
        let file_p1x = file_p1.clone();
        let tp_p0x = tp_p0.clone();
        crate::prelude::call_value(crate::prelude::fold_job(crate::prelude::filter(&tp_p0x.exprs_p, &(|n_p4: &crate::check::typed::TyNote| &n_p4.at_p.file_p == &file_p1x)), crate::prelude::Array::new(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::check::typed::TyNote)| crate::prelude::entered(crate::prelude::once_job(move || {
            let acc_p5 = p0;
            let n_p6 = p1;
            crate::prelude::call_then(start_ty_con_names_f(n_p6.ty_p.clone()), move |ty_con_names_f_8596: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_p5, &ty_con_names_f_8596)))
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::check::typed::TyNote)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>), move |fold_8515: crate::prelude::Array<crate::prelude::Text>| {
            let from_exprs_p2 = fold_8515;
            crate::prelude::call_value(crate::prelude::fold_job(crate::prelude::filter(&tp_p0x.binders_p, &(|n_p7: &crate::check::typed::BinderNote| &n_p7.at_p.file_p == &file_p1x)), from_exprs_p2.clone(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::check::typed::BinderNote)| crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_p8 = p0;
                let n_p9 = p1;
                crate::prelude::call_then(start_ty_con_names_f(n_p9.ty_p.clone()), move |ty_con_names_f_8723: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_p8, &ty_con_names_f_8723)))
            }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::check::typed::BinderNote)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>), move |fold_8635: crate::prelude::Array<crate::prelude::Text>| {
                let from_binders_p3 = fold_8635;
                crate::prelude::fold_job(crate::prelude::filter(&tp_p0x.defs_p, &(|n_pa: &crate::check::typed::DefNote| &n_pa.at_p.file_p == &file_p1x)), from_binders_p3.clone(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::check::typed::DefNote)| crate::prelude::entered(crate::prelude::once_job(move || {
                    let acc_pb = p0;
                    let n_pc = p1;
                    crate::prelude::call_then(start_ty_con_names_f(n_pc.scheme_p.ty_p.clone()), move |ty_con_names_f_8831: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_pb, &ty_con_names_f_8831)))
                }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::check::typed::DefNote)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>).cycle()
            })
        })
    }
}

/// `Start TypesNamedIn, x`: what the function value is when passed to `@Run`.
pub fn start_types_named_in_f(tp_p0: crate::check::typed::TProgram, file_p1: crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>> {
    ::std::rc::Rc::new(TypesNamedIn { tp_p0, file_p1 })
}

/// ```prism
/// TyConNames: unbounded fn Ty -> [Text]
/// ```
pub fn ty_con_names_f(t_p0: &crate::check::types::Ty) -> crate::prelude::Array<crate::prelude::Text> {
    'm8912: {
        if let crate::check::types::Ty::TyCon(m8912_0_0, m8912_0_1) = t_p0 && (m8912_0_0 == &crate::prelude::Text::lit("Prelude.NonEmpty")) && (m8912_0_1.len() == 1) && let ::std::option::Option::Some(c_p1) = crate::prelude::index(m8912_0_1, &crate::prelude::Nat::from(0u32)) {
            break 'm8912 ty_con_names_f(&c_p1);
        }
        if let crate::check::types::Ty::TyCon(n_p2, args_p3) = t_p0 {
            break 'm8912 crate::prelude::run_to_end(crate::prelude::fold_job(args_p3.clone(), crate::prelude::Array::from(vec![n_p2.clone()]), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::check::types::Ty)| crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_p4 = p0;
                let a_p5 = p1;
                crate::prelude::call_then(start_ty_con_names_f(a_p5.clone()), move |ty_con_names_f_9035: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_p4, &ty_con_names_f_9035)))
            }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::check::types::Ty)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>));
        }
        if let crate::check::types::Ty::TyFn(_, ps_p6, r_p7) = t_p0 {
            break 'm8912 crate::prelude::run_to_end(crate::prelude::fold_job(ps_p6.clone(), ty_con_names_f(&**r_p7), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::check::types::Ty)| crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_p8 = p0;
                let a_p9 = p1;
                crate::prelude::call_then(start_ty_con_names_f(a_p9.clone()), move |ty_con_names_f_9125: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_p8, &ty_con_names_f_9125)))
            }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::check::types::Ty)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>));
        }
        if let crate::check::types::Ty::TyTuple(ts_pa) = t_p0 {
            break 'm8912 crate::prelude::run_to_end(crate::prelude::fold_job(ts_pa.clone(), crate::prelude::Array::new(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::check::types::Ty)| crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_pb = p0;
                let a_pc = p1;
                crate::prelude::call_then(start_ty_con_names_f(a_pc.clone()), move |ty_con_names_f_9197: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_pb, &ty_con_names_f_9197)))
            }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::check::types::Ty)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>));
        }
        if let crate::check::types::Ty::TyArray(x_pd) = t_p0 {
            break 'm8912 ty_con_names_f(&**x_pd);
        }
        if let crate::check::types::Ty::TyMap(k_pe, v_pf) = t_p0 {
            break 'm8912 crate::check::types::union_texts_f(&ty_con_names_f(&**k_pe), &ty_con_names_f(&**v_pf));
        }
        if let crate::check::types::Ty::TySig(_, x_pg) = t_p0 {
            break 'm8912 ty_con_names_f(&**x_pg);
        }
        if let crate::check::types::Ty::TyAt(x_ph, _) = t_p0 {
            break 'm8912 ty_con_names_f(&**x_ph);
        }
        if let crate::check::types::Ty::TyElem(_, x_pi) = t_p0 {
            break 'm8912 ty_con_names_f(&**x_pi);
        }
        if let crate::check::types::Ty::TyAssoc(_, _, x_pj) = t_p0 {
            break 'm8912 ty_con_names_f(&**x_pj);
        }
        crate::prelude::Array::new()
    }
}

/// The step machine of `TyConNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TyConNames: unbounded fn Ty -> [Text]
/// ```
pub struct TyConNames {
    pub t_p0: crate::check::types::Ty,
}

impl ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>> for TyConNames {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<crate::prelude::Text>> {
        let t_p0 = &self.t_p0;
        'm8912: {
            if let crate::check::types::Ty::TyCon(m8912_0_0, m8912_0_1) = t_p0 && (m8912_0_0 == &crate::prelude::Text::lit("Prelude.NonEmpty")) && (m8912_0_1.len() == 1) && let ::std::option::Option::Some(c_p1) = crate::prelude::index(m8912_0_1, &crate::prelude::Nat::from(0u32)) {
                break 'm8912 ::prism_rtl::Turn::More(::std::rc::Rc::new(TyConNames { t_p0: c_p1.clone() }));
            }
            if let crate::check::types::Ty::TyCon(n_p2, args_p3) = t_p0 {
                break 'm8912 crate::prelude::fold_job(args_p3.clone(), crate::prelude::Array::from(vec![n_p2.clone()]), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::check::types::Ty)| crate::prelude::entered(crate::prelude::once_job(move || {
                    let acc_p4 = p0;
                    let a_p5 = p1;
                    crate::prelude::call_then(start_ty_con_names_f(a_p5.clone()), move |ty_con_names_f_9035: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_p4, &ty_con_names_f_9035)))
                }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::check::types::Ty)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>).cycle();
            }
            if let crate::check::types::Ty::TyFn(_, ps_p6, r_p7) = t_p0 {
                break 'm8912 {
                    let ps_p6x = ps_p6.clone();
                    let r_p7x = (**r_p7).clone();
                    crate::prelude::call_then(start_ty_con_names_f(r_p7x.clone()), move |ty_con_names_f_9083: crate::prelude::Array<crate::prelude::Text>| crate::prelude::fold_job(ps_p6x.clone(), ty_con_names_f_9083, ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::check::types::Ty)| crate::prelude::entered(crate::prelude::once_job(move || {
                        let acc_p8 = p0;
                        let a_p9 = p1;
                        crate::prelude::call_then(start_ty_con_names_f(a_p9.clone()), move |ty_con_names_f_9125: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_p8, &ty_con_names_f_9125)))
                    }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::check::types::Ty)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>).cycle())
                };
            }
            if let crate::check::types::Ty::TyTuple(ts_pa) = t_p0 {
                break 'm8912 crate::prelude::fold_job(ts_pa.clone(), crate::prelude::Array::new(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::check::types::Ty)| crate::prelude::entered(crate::prelude::once_job(move || {
                    let acc_pb = p0;
                    let a_pc = p1;
                    crate::prelude::call_then(start_ty_con_names_f(a_pc.clone()), move |ty_con_names_f_9197: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_pb, &ty_con_names_f_9197)))
                }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::check::types::Ty)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>).cycle();
            }
            if let crate::check::types::Ty::TyArray(x_pd) = t_p0 {
                break 'm8912 ::prism_rtl::Turn::More(::std::rc::Rc::new(TyConNames { t_p0: (**x_pd).clone() }));
            }
            if let crate::check::types::Ty::TyMap(k_pe, v_pf) = t_p0 {
                break 'm8912 {
                    let k_pex = (**k_pe).clone();
                    let v_pfx = (**v_pf).clone();
                    crate::prelude::call_then(start_ty_con_names_f(k_pex.clone()), move |ty_con_names_f_9267: crate::prelude::Array<crate::prelude::Text>| crate::prelude::call_then(start_ty_con_names_f(v_pfx.clone()), move |ty_con_names_f_9283: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&ty_con_names_f_9267, &ty_con_names_f_9283))))
                };
            }
            if let crate::check::types::Ty::TySig(_, x_pg) = t_p0 {
                break 'm8912 ::prism_rtl::Turn::More(::std::rc::Rc::new(TyConNames { t_p0: (**x_pg).clone() }));
            }
            if let crate::check::types::Ty::TyAt(x_ph, _) = t_p0 {
                break 'm8912 ::prism_rtl::Turn::More(::std::rc::Rc::new(TyConNames { t_p0: (**x_ph).clone() }));
            }
            if let crate::check::types::Ty::TyElem(_, x_pi) = t_p0 {
                break 'm8912 ::prism_rtl::Turn::More(::std::rc::Rc::new(TyConNames { t_p0: (**x_pi).clone() }));
            }
            if let crate::check::types::Ty::TyAssoc(_, _, x_pj) = t_p0 {
                break 'm8912 ::prism_rtl::Turn::More(::std::rc::Rc::new(TyConNames { t_p0: (**x_pj).clone() }));
            }
            ::prism_rtl::Turn::Finished(crate::prelude::Array::new())
        }
    }
}

/// `Start TyConNames, x`: what the function value is when passed to `@Run`.
pub fn start_ty_con_names_f(t_p0: crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>> {
    ::std::rc::Rc::new(TyConNames { t_p0 })
}

/// ```prism
/// ImplPath: fn Text -> Text
/// ```
pub fn impl_path_f(how_p0: &crate::prelude::Text) -> crate::prelude::Text {
    let rest_p1 = crate::prelude::or(&crate::syntax::lexer::chars::after_prefix_o(how_p0, &crate::prelude::Text::lit("impl ")), &crate::prelude::or(&crate::syntax::lexer::chars::after_prefix_o(how_p0, &crate::prelude::Text::lit("derived ")), &crate::prelude::Text::lit("")));
    let parts_p2 = crate::prelude::split_on(&rest_p1, &crate::prelude::Text::lit(":"));
    crate::syntax::lexer::chars::join_f(&crate::prelude::take(&parts_p2, &crate::syntax::lexer::chars::dec_f(&crate::prelude::len(&parts_p2))), &crate::prelude::Text::lit(":"))
}

/// ```prism
/// ValueTypes: fn [ModDef] -> (Text ==> Bool)
/// ```
pub fn value_types_f(defs_p0: &crate::prelude::Array<crate::lower::model::ModDef>) -> crate::prelude::Map<crate::prelude::Text, bool> {
    crate::prelude::fold(defs_p0, &crate::prelude::Map::new(), &(|acc_p1: &crate::prelude::Map<crate::prelude::Text, bool>, d_p2: &crate::lower::model::ModDef| crate::prelude::fold(&d_p2.items_p, acc_p1, &(|a_p3: &crate::prelude::Map<crate::prelude::Text, bool>, it_p4: &crate::lower::model::Item| match it_p4 {
        crate::lower::model::Item::ItType(t_p5) => crate::prelude::insert(a_p3, &crate::prelude::Text::from(format!("{}::{}", &d_p2.name_p, &t_p5.name_p)), &true),
        crate::lower::model::Item::ItTag(t_p6) => crate::prelude::insert(a_p3, &crate::prelude::Text::from(format!("{}::{}", &d_p2.name_p, &t_p6.name_p)), &true),
        _ => a_p3.clone(),
    }))))
}

/// ```prism
/// RootRef: fn Text, Text -> Ref
/// ```
pub fn root_ref_f(home_p0: &crate::prelude::Text, name_p1: &crate::prelude::Text) -> crate::lower::model::Ref {
    crate::lower::model::Ref::RefItem(crate::lower::rust_mod_name_f(home_p0), name_p1.clone(), crate::prelude::Text::from(format!("{}::{}", &crate::lower::rust_mod_name_f(home_p0), name_p1)))
}

/// ```prism
/// ItemHeld: fn [Text], (Text ==> Bool), Text, Item -> [Text]
/// ```
pub fn item_held_f(names_p0: &crate::prelude::Array<crate::prelude::Text>, value_tys_p1: &crate::prelude::Map<crate::prelude::Text, bool>, home_p2: &crate::prelude::Text, it_p3: &crate::lower::model::Item) -> crate::prelude::Array<crate::prelude::Text> {
    match it_p3 {
        crate::lower::model::Item::ItType(t_p4) => crate::prelude::fold(&t_p4.cases_p, &crate::prelude::Array::new(), &(|acc_p5: &crate::prelude::Array<crate::prelude::Text>, c_p6: &crate::lower::model::CaseDef| crate::prelude::fold(&c_p6.fields_p, acc_p5, &(|a_p7: &crate::prelude::Array<crate::prelude::Text>, (_, ft_p8): &(crate::prelude::Text, crate::lower::model::OutTy)| crate::check::types::union_texts_f(a_p7, &held_in_f(names_p0, value_tys_p1, home_p2, ft_p8)))))),
        crate::lower::model::Item::ItTag(t_p9) => crate::prelude::fold(&t_p9.fields_p, &crate::prelude::Array::new(), &(|acc_pa: &crate::prelude::Array<crate::prelude::Text>, (_, _, ft_pb): &(crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy)| crate::check::types::union_texts_f(acc_pa, &held_in_f(names_p0, value_tys_p1, home_p2, ft_pb)))),
        crate::lower::model::Item::ItRow(r_pc) => crate::prelude::fold(&r_pc.cases_p, &crate::prelude::Array::new(), &(|acc_pd: &crate::prelude::Array<crate::prelude::Text>, (_, sp_pe): &(crate::prelude::Text, crate::lower::model::Ref)| crate::check::types::union_texts_f(acc_pd, &held_in_f(names_p0, value_tys_p1, home_p2, &crate::lower::model::OutTy::OutNamed(sp_pe.clone(), crate::prelude::Array::new()))))),
        _ => crate::prelude::Array::new(),
    }
}

/// ```prism
/// HeldIn: fn [Text], (Text ==> Bool), Text, OutTy -> [Text]
/// ```
pub fn held_in_f(names_p0: &crate::prelude::Array<crate::prelude::Text>, value_tys_p1: &crate::prelude::Map<crate::prelude::Text, bool>, home_p2: &crate::prelude::Text, t_p3: &crate::lower::model::OutTy) -> crate::prelude::Array<crate::prelude::Text> {
    match t_p3 {
        crate::lower::model::OutTy::OutNamed(n_p4, args_p5) => {
            let own_p6 = match n_p4 {
                crate::lower::model::Ref::RefItem(m_p7, _, _) => if crate::check::env::has_key_f(value_tys_p1, &crate::prelude::or(&crate::lower::model::ref_key_o(n_p4), &crate::prelude::Text::lit(""))) {
                    crate::prelude::Array::from(vec![m_p7.clone()])
                } else {
                    crate::prelude::Array::new()
                },
                _ => crate::prelude::Array::new(),
            };
            crate::prelude::fold(args_p5, &own_p6, &(|acc_p8: &crate::prelude::Array<crate::prelude::Text>, a_p9: &crate::lower::model::OutTy| crate::check::types::union_texts_f(acc_p8, &held_in_f(names_p0, value_tys_p1, home_p2, a_p9))))
        },
        crate::lower::model::OutTy::OutOpt(i_pa) => held_in_f(names_p0, value_tys_p1, home_p2, &**i_pa),
        crate::lower::model::OutTy::OutRes(i_pb) => held_in_f(names_p0, value_tys_p1, home_p2, &**i_pb),
        crate::lower::model::OutTy::OutCell(i_pc) => held_in_f(names_p0, value_tys_p1, home_p2, &**i_pc),
        crate::lower::model::OutTy::OutTuple(ts_pd) => crate::prelude::fold(ts_pd, &crate::prelude::Array::new(), &(|acc_pe: &crate::prelude::Array<crate::prelude::Text>, a_pf: &crate::lower::model::OutTy| crate::check::types::union_texts_f(acc_pe, &held_in_f(names_p0, value_tys_p1, home_p2, a_pf)))),
        _ => crate::prelude::Array::new(),
    }
}

/// ```prism
/// NamedIn: fn [Text], Text, OutTy -> [Text]
/// ```
pub fn named_in_f(names_p0: &crate::prelude::Array<crate::prelude::Text>, home_p1: &crate::prelude::Text, t_p2: &crate::lower::model::OutTy) -> crate::prelude::Array<crate::prelude::Text> {
    match t_p2 {
        crate::lower::model::OutTy::OutNamed(n_p3, args_p4) => {
            let own_p5 = match n_p3 {
                crate::lower::model::Ref::RefItem(m_p6, _, _) => if crate::check::types::has_text_f(names_p0, m_p6) {
                    crate::prelude::Array::from(vec![m_p6.clone()])
                } else {
                    crate::prelude::Array::new()
                },
                _ => crate::prelude::Array::new(),
            };
            crate::prelude::fold(args_p4, &own_p5, &(|acc_p7: &crate::prelude::Array<crate::prelude::Text>, a_p8: &crate::lower::model::OutTy| crate::check::types::union_texts_f(acc_p7, &named_in_f(names_p0, home_p1, a_p8))))
        },
        crate::lower::model::OutTy::OutOpt(i_p9) => named_in_f(names_p0, home_p1, &**i_p9),
        crate::lower::model::OutTy::OutRes(i_pa) => named_in_f(names_p0, home_p1, &**i_pa),
        crate::lower::model::OutTy::OutCell(i_pb) => named_in_f(names_p0, home_p1, &**i_pb),
        crate::lower::model::OutTy::OutArray(i_pc) => named_in_f(names_p0, home_p1, &**i_pc),
        crate::lower::model::OutTy::OutRc(i_pd) => named_in_f(names_p0, home_p1, &**i_pd),
        crate::lower::model::OutTy::OutEvent(i_pe) => named_in_f(names_p0, home_p1, &**i_pe),
        crate::lower::model::OutTy::OutDyn(i_pf) => named_in_f(names_p0, home_p1, &**i_pf),
        crate::lower::model::OutTy::OutMap(k_pg, v_ph) => crate::check::types::union_texts_f(&named_in_f(names_p0, home_p1, &**k_pg), &named_in_f(names_p0, home_p1, &**v_ph)),
        crate::lower::model::OutTy::OutTuple(ts_pi) => crate::prelude::fold(ts_pi, &crate::prelude::Array::new(), &(|acc_pj: &crate::prelude::Array<crate::prelude::Text>, a_pk: &crate::lower::model::OutTy| crate::check::types::union_texts_f(acc_pj, &named_in_f(names_p0, home_p1, a_pk)))),
        crate::lower::model::OutTy::OutFn(ps_pl, r_pm) => crate::prelude::fold(ps_pl, &named_in_f(names_p0, home_p1, &**r_pm), &(|acc_pn: &crate::prelude::Array<crate::prelude::Text>, a_po: &crate::lower::model::OutTy| crate::check::types::union_texts_f(acc_pn, &named_in_f(names_p0, home_p1, a_po)))),
        _ => crate::prelude::Array::new(),
    }
}

/// ```prism
/// WithGroups: unbounded fn [ModDef] -> [ModDef]
/// ```
pub fn with_groups_f(defs_p0: &crate::prelude::Array<crate::lower::model::ModDef>) -> crate::prelude::Array<crate::lower::model::ModDef> {
    let edges_p1 = crate::prelude::fold(defs_p0, &crate::prelude::Map::new(), &(|m_p3: &crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>>, d_p4: &crate::lower::model::ModDef| crate::prelude::insert(m_p3, &d_p4.name_p, &d_p4.complete_p)));
    let reach_p2 = crate::prelude::run_to_end(crate::prelude::fold_job(defs_p0.clone(), crate::prelude::Map::new(), {
        let edges_p1x = edges_p1.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>>, crate::lower::model::ModDef)| {
            let edges_p1xy = edges_p1x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let m_p5 = p0;
                let d_p6 = p1;
                crate::prelude::call_then(start_reached_by_f(edges_p1xy.clone(), crate::prelude::Array::from(vec![d_p6.name_p.clone()]), crate::prelude::Array::new()), move |reached_by_f_13477: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::prelude::insert(&m_p5, &d_p6.name_p, &reached_by_f_13477)))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>>, crate::lower::model::ModDef)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>>>>>
    }));
    crate::prelude::each(defs_p0, &(|d_p7: &crate::lower::model::ModDef| {
        let mine_p8 = crate::prelude::or(&crate::prelude::get(&reach_p2, &d_p7.name_p), &crate::prelude::Array::new());
        {
            let mut this: crate::lower::model::ModDef = d_p7.clone();
            this.types_with_p = crate::prelude::filter(&crate::prelude::each(defs_p0, &(|o_p9: &crate::lower::model::ModDef| o_p9.name_p.clone())), &(|n_pa: &crate::prelude::Text| (n_pa == &d_p7.name_p) || (crate::check::types::has_text_f(&mine_p8, n_pa) && crate::check::types::has_text_f(&crate::prelude::or(&crate::prelude::get(&reach_p2, n_pa), &crate::prelude::Array::new()), &d_p7.name_p))));
            this
        }
    }))
}

/// The step machine of `WithGroups`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// WithGroups: unbounded fn [ModDef] -> [ModDef]
/// ```
pub struct WithGroups {
    pub defs_p0: crate::prelude::Array<crate::lower::model::ModDef>,
}

impl ::prism_rtl::Job<crate::prelude::Array<crate::lower::model::ModDef>> for WithGroups {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<crate::lower::model::ModDef>> {
        let defs_p0 = &self.defs_p0;
        let edges_p1 = crate::prelude::fold(defs_p0, &crate::prelude::Map::new(), &(|m_p3: &crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>>, d_p4: &crate::lower::model::ModDef| crate::prelude::insert(m_p3, &d_p4.name_p, &d_p4.complete_p)));
        let defs_p0x = defs_p0.clone();
        crate::prelude::call_value(crate::prelude::fold_job(defs_p0x.clone(), crate::prelude::Map::new(), {
            let edges_p1x = edges_p1.clone();
            ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>>, crate::lower::model::ModDef)| {
                let edges_p1xy = edges_p1x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let m_p5 = p0;
                    let d_p6 = p1;
                    crate::prelude::call_then(start_reached_by_f(edges_p1xy.clone(), crate::prelude::Array::from(vec![d_p6.name_p.clone()]), crate::prelude::Array::new()), move |reached_by_f_13477: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::prelude::insert(&m_p5, &d_p6.name_p, &reached_by_f_13477)))
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>>, crate::lower::model::ModDef)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>>>>>
        }), move |fold_13435: crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>>| {
            let reach_p2 = fold_13435;
            ::prism_rtl::Turn::Finished(crate::prelude::each(&defs_p0x, &(|d_p7: &crate::lower::model::ModDef| {
                let mine_p8 = crate::prelude::or(&crate::prelude::get(&reach_p2, &d_p7.name_p), &crate::prelude::Array::new());
                {
                    let mut this: crate::lower::model::ModDef = d_p7.clone();
                    this.types_with_p = crate::prelude::filter(&crate::prelude::each(&defs_p0x, &(|o_p9: &crate::lower::model::ModDef| o_p9.name_p.clone())), &(|n_pa: &crate::prelude::Text| (n_pa == &d_p7.name_p) || (crate::check::types::has_text_f(&mine_p8, n_pa) && crate::check::types::has_text_f(&crate::prelude::or(&crate::prelude::get(&reach_p2, n_pa), &crate::prelude::Array::new()), &d_p7.name_p))));
                    this
                }
            })))
        })
    }
}

/// `Start WithGroups, x`: what the function value is when passed to `@Run`.
pub fn start_with_groups_f(defs_p0: crate::prelude::Array<crate::lower::model::ModDef>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::lower::model::ModDef>>> {
    ::std::rc::Rc::new(WithGroups { defs_p0 })
}

/// ```prism
/// ReachedBy: unbounded fn (Text ==> [Text]), [Text], [Text] -> [Text]
/// ```
pub fn reached_by_f(edges_p0: &crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>>, todo_p1: &crate::prelude::Array<crate::prelude::Text>, seen_p2: &crate::prelude::Array<crate::prelude::Text>) -> crate::prelude::Array<crate::prelude::Text> {
    match crate::prelude::index(todo_p1, &crate::prelude::Nat::from(0u32)) {
        ::std::option::Option::None => seen_p2.clone(),
        ::std::option::Option::Some(m_p3) => if crate::check::types::has_text_f(seen_p2, &m_p3) {
            reached_by_f(edges_p0, &crate::prelude::drop(todo_p1, &crate::prelude::Nat::from(1u32)), seen_p2)
        } else {
            reached_by_f(edges_p0, &crate::prelude::append(&crate::prelude::drop(todo_p1, &crate::prelude::Nat::from(1u32)), &crate::prelude::or(&crate::prelude::get(edges_p0, &m_p3), &crate::prelude::Array::new())), &crate::prelude::push(seen_p2, &m_p3))
        },
    }
}

/// The step machine of `ReachedBy`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ReachedBy: unbounded fn (Text ==> [Text]), [Text], [Text] -> [Text]
/// ```
pub struct ReachedBy {
    pub edges_p0: crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>>,
    pub todo_p1: crate::prelude::Array<crate::prelude::Text>,
    pub seen_p2: crate::prelude::Array<crate::prelude::Text>,
}

impl ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>> for ReachedBy {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<crate::prelude::Text>> {
        let edges_p0 = &self.edges_p0;
        let todo_p1 = &self.todo_p1;
        let seen_p2 = &self.seen_p2;
        match crate::prelude::index(todo_p1, &crate::prelude::Nat::from(0u32)) {
            ::std::option::Option::None => ::prism_rtl::Turn::Finished(seen_p2.clone()),
            ::std::option::Option::Some(m_p3) => if crate::check::types::has_text_f(seen_p2, &m_p3) {
                ::prism_rtl::Turn::More(::std::rc::Rc::new(ReachedBy { edges_p0: edges_p0.clone(), todo_p1: crate::prelude::drop(todo_p1, &crate::prelude::Nat::from(1u32)), seen_p2: seen_p2.clone() }))
            } else {
                ::prism_rtl::Turn::More(::std::rc::Rc::new(ReachedBy { edges_p0: edges_p0.clone(), todo_p1: crate::prelude::append(&crate::prelude::drop(todo_p1, &crate::prelude::Nat::from(1u32)), &crate::prelude::or(&crate::prelude::get(edges_p0, &m_p3), &crate::prelude::Array::new())), seen_p2: crate::prelude::push(seen_p2, &m_p3) }))
            },
        }
    }
}

/// `Start ReachedBy, x`: what the function value is when passed to `@Run`.
pub fn start_reached_by_f(edges_p0: crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>>, todo_p1: crate::prelude::Array<crate::prelude::Text>, seen_p2: crate::prelude::Array<crate::prelude::Text>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>> {
    ::std::rc::Rc::new(ReachedBy { edges_p0, todo_p1, seen_p2 })
}

/// ```prism
/// NeededMods: unbounded fn G, Nat -> [Text]
/// ```
pub fn needed_mods_f(g_p0: &crate::check::env::G, shown_p1: &crate::prelude::Nat) -> crate::prelude::Array<crate::prelude::Text> {
    let own_p2 = crate::prelude::filter(&crate::prelude::keys(&g_p0.mods_p), &(|m_p4: &crate::prelude::Text| (&crate::prelude::or(&crate::prelude::get(&g_p0.mods_p, m_p4), &crate::check::env::reading::dummy_mod_p()).file_p < shown_p1) && (m_p4 != &crate::prelude::Text::lit("Prelude"))));
    let grown_p3 = crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::Nat::from(6u32)), own_p2.clone(), {
        let g_p0x = g_p0.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::prelude::Nat)| {
            let g_p0xy = g_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_p5 = p0;
                let _ = p1;
                crate::prelude::fold_job(acc_p5.clone(), acc_p5.clone(), {
                    let g_p0xyx = g_p0xy.clone();
                    ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::prelude::Text)| {
                        let g_p0xyxy = g_p0xyx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let a_p6 = p0;
                            let m_p7 = p1;
                            crate::prelude::call_then(start_mod_refs_f(g_p0xyxy.clone(), m_p7.clone()), move |mod_refs_f_14500: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&a_p6, &mod_refs_f_14500)))
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::prelude::Text)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>
                }).cycle()
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>
    }));
    crate::prelude::filter(&crate::prelude::keys(&g_p0.mods_p), &(|m_p8: &crate::prelude::Text| (m_p8 != &crate::prelude::Text::lit("Prelude")) && crate::check::types::has_text_f(&grown_p3, m_p8)))
}

/// The step machine of `NeededMods`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// NeededMods: unbounded fn G, Nat -> [Text]
/// ```
pub struct NeededMods {
    pub g_p0: crate::check::env::G,
    pub shown_p1: crate::prelude::Nat,
}

impl ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>> for NeededMods {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<crate::prelude::Text>> {
        let g_p0 = &self.g_p0;
        let shown_p1 = &self.shown_p1;
        let own_p2 = crate::prelude::filter(&crate::prelude::keys(&g_p0.mods_p), &(|m_p4: &crate::prelude::Text| (&crate::prelude::or(&crate::prelude::get(&g_p0.mods_p, m_p4), &crate::check::env::reading::dummy_mod_p()).file_p < shown_p1) && (m_p4 != &crate::prelude::Text::lit("Prelude"))));
        let g_p0x = g_p0.clone();
        crate::prelude::call_value(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::Nat::from(6u32)), own_p2.clone(), {
            let g_p0xx = g_p0x.clone();
            ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::prelude::Nat)| {
                let g_p0xxy = g_p0xx.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let acc_p5 = p0;
                    let _ = p1;
                    crate::prelude::fold_job(acc_p5.clone(), acc_p5.clone(), {
                        let g_p0xxyx = g_p0xxy.clone();
                        ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::prelude::Text)| {
                            let g_p0xxyxy = g_p0xxyx.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let a_p6 = p0;
                                let m_p7 = p1;
                                crate::prelude::call_then(start_mod_refs_f(g_p0xxyxy.clone(), m_p7.clone()), move |mod_refs_f_14500: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&a_p6, &mod_refs_f_14500)))
                            }))
                        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::prelude::Text)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>
                    }).cycle()
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>
        }), move |fold_14425: crate::prelude::Array<crate::prelude::Text>| {
            let grown_p3 = fold_14425;
            ::prism_rtl::Turn::Finished(crate::prelude::filter(&crate::prelude::keys(&g_p0x.mods_p), &(|m_p8: &crate::prelude::Text| (m_p8 != &crate::prelude::Text::lit("Prelude")) && crate::check::types::has_text_f(&grown_p3, m_p8))))
        })
    }
}

/// `Start NeededMods, x`: what the function value is when passed to `@Run`.
pub fn start_needed_mods_f(g_p0: crate::check::env::G, shown_p1: crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>> {
    ::std::rc::Rc::new(NeededMods { g_p0, shown_p1 })
}

/// ```prism
/// ModRefs: unbounded fn G, Text -> [Text]
/// ```
pub fn mod_refs_f(g_p0: &crate::check::env::G, m_p1: &crate::prelude::Text) -> crate::prelude::Array<crate::prelude::Text> {
    match crate::prelude::get(&g_p0.mods_p, m_p1) {
        ::std::option::Option::Some(info_p2) => {
            let used_p3 = crate::prelude::each(&info_p2.uses_p, &(|(u_p5, _): &(crate::prelude::Text, bool)| u_p5.clone()));
            let fams_p4 = match &info_p2.tree_p.emit_row_o {
                ::std::option::Option::Some(rw_p6) => crate::prelude::fold(&rw_p6.terms_p, &crate::prelude::Array::new(), &(|acc_p7: &crate::prelude::Array<crate::prelude::Text>, t_p8: &crate::syntax::RowTerm| match t_p8 {
                    crate::syntax::RowTerm::RFamily(q_p9) => crate::prelude::push(acc_p7, &crate::prelude::or(&crate::prelude::get(&g_p0.fam_owner_p, &crate::check::env::dotted_f(&q_p9.path_p)), &crate::check::env::dotted_f(&q_p9.path_p))),
                    _ => acc_p7.clone(),
                })),
                ::std::option::Option::None => crate::prelude::Array::new(),
            };
            crate::prelude::filter(&crate::prelude::append(&used_p3, &fams_p4), &(|x_pa: &crate::prelude::Text| crate::check::env::has_key_f(&g_p0.mods_p, x_pa)))
        },
        ::std::option::Option::None => crate::prelude::Array::new(),
    }
}

/// The step machine of `ModRefs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ModRefs: unbounded fn G, Text -> [Text]
/// ```
pub struct ModRefs {
    pub g_p0: crate::check::env::G,
    pub m_p1: crate::prelude::Text,
}

impl ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>> for ModRefs {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<crate::prelude::Text>> {
        let g_p0 = &self.g_p0;
        let m_p1 = &self.m_p1;
        match crate::prelude::get(&g_p0.mods_p, m_p1) {
            ::std::option::Option::Some(info_p2) => {
                let used_p3 = crate::prelude::each(&info_p2.uses_p, &(|(u_p5, _): &(crate::prelude::Text, bool)| u_p5.clone()));
                let fams_p4 = match &info_p2.tree_p.emit_row_o {
                    ::std::option::Option::Some(rw_p6) => crate::prelude::fold(&rw_p6.terms_p, &crate::prelude::Array::new(), &(|acc_p7: &crate::prelude::Array<crate::prelude::Text>, t_p8: &crate::syntax::RowTerm| match t_p8 {
                        crate::syntax::RowTerm::RFamily(q_p9) => crate::prelude::push(acc_p7, &crate::prelude::or(&crate::prelude::get(&g_p0.fam_owner_p, &crate::check::env::dotted_f(&q_p9.path_p)), &crate::check::env::dotted_f(&q_p9.path_p))),
                        _ => acc_p7.clone(),
                    })),
                    ::std::option::Option::None => crate::prelude::Array::new(),
                };
                ::prism_rtl::Turn::Finished(crate::prelude::filter(&crate::prelude::append(&used_p3, &fams_p4), &(|x_pa: &crate::prelude::Text| crate::check::env::has_key_f(&g_p0.mods_p, x_pa))))
            },
            ::std::option::Option::None => ::prism_rtl::Turn::Finished(crate::prelude::Array::new()),
        }
    }
}

/// `Start ModRefs, x`: what the function value is when passed to `@Run`.
pub fn start_mod_refs_f(g_p0: crate::check::env::G, m_p1: crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>> {
    ::std::rc::Rc::new(ModRefs { g_p0, m_p1 })
}

/// ```prism
/// RootWidgets: fn Lx -> [((Text, Bool))]
/// ```
pub fn root_widgets_f(lx_p0: &crate::lower::Lx) -> crate::prelude::Array<(crate::prelude::Text, bool)> {
    let tested_p1 = crate::prelude::fold(&lx_p0.g_p.defs_p, &crate::prelude::Array::new(), &(|acc_p3: &crate::prelude::Array<(crate::prelude::Text, bool)>, d_p4: &crate::check::env::Def| match &d_p4.body_p {
        crate::check::env::DefBody::DbTest(t_p5) => match blueprint_qk_f(&in_module_f(lx_p0, &d_p4.file_p, &d_p4.home_p), &t_p5.blueprint_p) {
            m15254_0 if (&m15254_0 == &crate::prelude::Text::lit("")) => acc_p3.clone(),
            qk_p6 => if crate::check::types::has_text_f(&crate::prelude::each(acc_p3, &(|(q_p7, _): &(crate::prelude::Text, bool)| q_p7.clone())), &qk_p6) {
                acc_p3.clone()
            } else {
                crate::prelude::push(acc_p3, &(qk_p6.clone(), true))
            },
            _ => unreachable!("no arm matched"),
        },
        _ => acc_p3.clone(),
    }));
    let main_p2 = crate::prelude::fold(&lx_p0.g_p.defs_p, &crate::prelude::Array::new(), &(|acc_p8: &crate::prelude::Array<(crate::prelude::Text, bool)>, d_p9: &crate::check::env::Def| if is_main_f(&d_p9.qk_p) {
        crate::prelude::push(acc_p8, &(d_p9.qk_p.clone(), false))
    } else {
        acc_p8.clone()
    }));
    crate::prelude::fold(&main_p2, &tested_p1, &(|acc_pa: &crate::prelude::Array<(crate::prelude::Text, bool)>, (k_pb, b_pc): &(crate::prelude::Text, bool)| if crate::check::types::has_text_f(&crate::prelude::each(acc_pa, &(|(q_pd, _): &(crate::prelude::Text, bool)| q_pd.clone())), k_pb) {
        acc_pa.clone()
    } else {
        crate::prelude::push(acc_pa, &(k_pb.clone(), *b_pc))
    }))
}

/// ```prism
/// ValuedWidgets: unbounded fn Lx -> (((Text ==> [((Text, Pa, [Cc], [Ex]))]), (Text ==> [((Text, [((Text, Ty))]))])))
/// ```
pub fn valued_widgets_f(lx_p0: &crate::lower::Lx) -> (crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::lower::model::Pa, crate::prelude::Array<crate::lower::model::Cc>, crate::prelude::Array<crate::lower::model::Ex>)>>, crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>>) {
    crate::prelude::run_to_end(crate::prelude::fold_job(lx_p0.g_p.defs_p.clone(), (crate::prelude::Map::new(), crate::prelude::Map::new()), {
        let lx_p0x = lx_p0.clone();
        ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::lower::model::Pa, crate::prelude::Array<crate::lower::model::Cc>, crate::prelude::Array<crate::lower::model::Ex>)>>, crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>>), crate::check::env::Def)| {
            let lx_p0xy = lx_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_p1 = p0;
                let d_p2 = p1;
                {
                    let lxd_p3 = {
                        let mut this: crate::lower::Lx = in_module_f(&lx_p0xy, &d_p2.file_p, &d_p2.home_p);
                        this.in_definition_p = instance_key_f(&d_p2);
                        this
                    };
                    crate::prelude::call_then(crate::lower::expr::start_def_exprs_f(d_p2.clone()), move |def_exprs_f_16760: crate::prelude::Array<crate::syntax::Expr>| crate::prelude::call_value(crate::prelude::fold_job(def_exprs_f_16760, crate::prelude::Array::new(), {
                        let lxd_p3x = lxd_p3.clone();
                        ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>, crate::syntax::Expr)| {
                            let lxd_p3xy = lxd_p3x.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let sites_p6 = p0;
                                let e_p7 = p1;
                                crate::prelude::call_then(start_value_widgets_in_f(lxd_p3xy.clone(), e_p7.clone()), move |value_widgets_in_f_16806: crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>| ::prism_rtl::Turn::Finished(crate::prelude::append(&sites_p6, &value_widgets_in_f_16806)))
                            }))
                        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>, crate::syntax::Expr)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>>>>
                    }), move |fold_16754: crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>| {
                        let held_p4 = fold_16754;
                        crate::prelude::call_then(start_let_values_f(d_p2.clone()), move |let_values_f_16933: crate::prelude::Array<crate::syntax::Expr>| crate::prelude::call_value(crate::prelude::fold_job(let_values_f_16933, held_p4.clone(), {
                            let lxd_p3x = lxd_p3.clone();
                            ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>, crate::syntax::Expr)| {
                                let lxd_p3xy = lxd_p3x.clone();
                                crate::prelude::entered(crate::prelude::once_job(move || {
                                    let sites_p8 = p0;
                                    let e_p9 = p1;
                                    crate::prelude::call_then(start_value_widgets_at_f(lxd_p3xy.clone(), e_p9.clone()), move |value_widgets_at_f_16980: crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>| ::prism_rtl::Turn::Finished(crate::prelude::append(&sites_p8, &value_widgets_at_f_16980)))
                                }))
                            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>, crate::syntax::Expr)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>>>>
                        }), move |fold_16927: crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>| {
                            let named_p5 = fold_16927;
                            crate::prelude::fold_job(named_p5.clone(), acc_p1.clone(), {
                                let lx_p0xyx = lx_p0xy.clone();
                                ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::lower::model::Pa, crate::prelude::Array<crate::lower::model::Cc>, crate::prelude::Array<crate::lower::model::Ex>)>>, crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>>), (crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>))| {
                                    let lx_p0xyxy = lx_p0xyx.clone();
                                    crate::prelude::entered(crate::prelude::once_job(move || {
                                        let (cases_pa, instances_pb) = p0;
                                        let (qk_pc, types_pd) = p1;
                                        {
                                            let valued_key_pe = valued_key_f(&qk_pc, &types_pd);
                                            let known_pf = crate::prelude::or(&crate::prelude::get(&instances_pb, &qk_pc), &crate::prelude::Array::new());
                                            if crate::check::env::has_key_f(&cases_pa, &valued_key_pe) {
                                                ::prism_rtl::Turn::Finished((cases_pa.clone(), instances_pb.clone()))
                                            } else {
                                                crate::prelude::call_then(start_valued_cases_o(lx_p0xyxy.clone(), qk_pc.clone(), types_pd.clone(), valued_stem_at_f(&qk_pc, &crate::prelude::len(&known_pf), &types_pd)), move |valued_cases_o_17219: ::std::option::Option<crate::prelude::Array<(crate::prelude::Text, crate::lower::model::Pa, crate::prelude::Array<crate::lower::model::Cc>, crate::prelude::Array<crate::lower::model::Ex>)>>| match valued_cases_o_17219 {
                                                    ::std::option::Option::Some(found_pg) => ::prism_rtl::Turn::Finished((crate::prelude::insert(&cases_pa, &valued_key_pe, &found_pg), crate::prelude::insert(&instances_pb, &qk_pc, &crate::prelude::push(&known_pf, &(valued_key_pe.clone(), types_pd.clone()))))),
                                                    ::std::option::Option::None => ::prism_rtl::Turn::Finished((cases_pa.clone(), instances_pb.clone())),
                                                })
                                            }
                                        }
                                    }))
                                }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::lower::model::Pa, crate::prelude::Array<crate::lower::model::Cc>, crate::prelude::Array<crate::lower::model::Ex>)>>, crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>>), (crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>))) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::lower::model::Pa, crate::prelude::Array<crate::lower::model::Cc>, crate::prelude::Array<crate::lower::model::Ex>)>>, crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>>)>>>
                            }).cycle()
                        }))
                    }))
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::lower::model::Pa, crate::prelude::Array<crate::lower::model::Cc>, crate::prelude::Array<crate::lower::model::Ex>)>>, crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>>), crate::check::env::Def)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::lower::model::Pa, crate::prelude::Array<crate::lower::model::Cc>, crate::prelude::Array<crate::lower::model::Ex>)>>, crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>>)>>>
    }))
}

/// The step machine of `ValuedWidgets`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ValuedWidgets: unbounded fn Lx -> (((Text ==> [((Text, Pa, [Cc], [Ex]))]), (Text ==> [((Text, [((Text, Ty))]))])))
/// ```
pub struct ValuedWidgets {
    pub lx_p0: crate::lower::Lx,
}

impl ::prism_rtl::Job<(crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::lower::model::Pa, crate::prelude::Array<crate::lower::model::Cc>, crate::prelude::Array<crate::lower::model::Ex>)>>, crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>>)> for ValuedWidgets {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::lower::model::Pa, crate::prelude::Array<crate::lower::model::Cc>, crate::prelude::Array<crate::lower::model::Ex>)>>, crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>>)> {
        let lx_p0 = &self.lx_p0;
        crate::prelude::fold_job(lx_p0.g_p.defs_p.clone(), (crate::prelude::Map::new(), crate::prelude::Map::new()), {
            let lx_p0x = lx_p0.clone();
            ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::lower::model::Pa, crate::prelude::Array<crate::lower::model::Cc>, crate::prelude::Array<crate::lower::model::Ex>)>>, crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>>), crate::check::env::Def)| {
                let lx_p0xy = lx_p0x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let acc_p1 = p0;
                    let d_p2 = p1;
                    {
                        let lxd_p3 = {
                            let mut this: crate::lower::Lx = in_module_f(&lx_p0xy, &d_p2.file_p, &d_p2.home_p);
                            this.in_definition_p = instance_key_f(&d_p2);
                            this
                        };
                        crate::prelude::call_then(crate::lower::expr::start_def_exprs_f(d_p2.clone()), move |def_exprs_f_16760: crate::prelude::Array<crate::syntax::Expr>| crate::prelude::call_value(crate::prelude::fold_job(def_exprs_f_16760, crate::prelude::Array::new(), {
                            let lxd_p3x = lxd_p3.clone();
                            ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>, crate::syntax::Expr)| {
                                let lxd_p3xy = lxd_p3x.clone();
                                crate::prelude::entered(crate::prelude::once_job(move || {
                                    let sites_p6 = p0;
                                    let e_p7 = p1;
                                    crate::prelude::call_then(start_value_widgets_in_f(lxd_p3xy.clone(), e_p7.clone()), move |value_widgets_in_f_16806: crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>| ::prism_rtl::Turn::Finished(crate::prelude::append(&sites_p6, &value_widgets_in_f_16806)))
                                }))
                            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>, crate::syntax::Expr)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>>>>
                        }), move |fold_16754: crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>| {
                            let held_p4 = fold_16754;
                            crate::prelude::call_then(start_let_values_f(d_p2.clone()), move |let_values_f_16933: crate::prelude::Array<crate::syntax::Expr>| crate::prelude::call_value(crate::prelude::fold_job(let_values_f_16933, held_p4.clone(), {
                                let lxd_p3x = lxd_p3.clone();
                                ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>, crate::syntax::Expr)| {
                                    let lxd_p3xy = lxd_p3x.clone();
                                    crate::prelude::entered(crate::prelude::once_job(move || {
                                        let sites_p8 = p0;
                                        let e_p9 = p1;
                                        crate::prelude::call_then(start_value_widgets_at_f(lxd_p3xy.clone(), e_p9.clone()), move |value_widgets_at_f_16980: crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>| ::prism_rtl::Turn::Finished(crate::prelude::append(&sites_p8, &value_widgets_at_f_16980)))
                                    }))
                                }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>, crate::syntax::Expr)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>>>>
                            }), move |fold_16927: crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>| {
                                let named_p5 = fold_16927;
                                crate::prelude::fold_job(named_p5.clone(), acc_p1.clone(), {
                                    let lx_p0xyx = lx_p0xy.clone();
                                    ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::lower::model::Pa, crate::prelude::Array<crate::lower::model::Cc>, crate::prelude::Array<crate::lower::model::Ex>)>>, crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>>), (crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>))| {
                                        let lx_p0xyxy = lx_p0xyx.clone();
                                        crate::prelude::entered(crate::prelude::once_job(move || {
                                            let (cases_pa, instances_pb) = p0;
                                            let (qk_pc, types_pd) = p1;
                                            {
                                                let valued_key_pe = valued_key_f(&qk_pc, &types_pd);
                                                let known_pf = crate::prelude::or(&crate::prelude::get(&instances_pb, &qk_pc), &crate::prelude::Array::new());
                                                if crate::check::env::has_key_f(&cases_pa, &valued_key_pe) {
                                                    ::prism_rtl::Turn::Finished((cases_pa.clone(), instances_pb.clone()))
                                                } else {
                                                    crate::prelude::call_then(start_valued_cases_o(lx_p0xyxy.clone(), qk_pc.clone(), types_pd.clone(), valued_stem_at_f(&qk_pc, &crate::prelude::len(&known_pf), &types_pd)), move |valued_cases_o_17219: ::std::option::Option<crate::prelude::Array<(crate::prelude::Text, crate::lower::model::Pa, crate::prelude::Array<crate::lower::model::Cc>, crate::prelude::Array<crate::lower::model::Ex>)>>| match valued_cases_o_17219 {
                                                        ::std::option::Option::Some(found_pg) => ::prism_rtl::Turn::Finished((crate::prelude::insert(&cases_pa, &valued_key_pe, &found_pg), crate::prelude::insert(&instances_pb, &qk_pc, &crate::prelude::push(&known_pf, &(valued_key_pe.clone(), types_pd.clone()))))),
                                                        ::std::option::Option::None => ::prism_rtl::Turn::Finished((cases_pa.clone(), instances_pb.clone())),
                                                    })
                                                }
                                            }
                                        }))
                                    }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::lower::model::Pa, crate::prelude::Array<crate::lower::model::Cc>, crate::prelude::Array<crate::lower::model::Ex>)>>, crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>>), (crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>))) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::lower::model::Pa, crate::prelude::Array<crate::lower::model::Cc>, crate::prelude::Array<crate::lower::model::Ex>)>>, crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>>)>>>
                                }).cycle()
                            }))
                        }))
                    }
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::lower::model::Pa, crate::prelude::Array<crate::lower::model::Cc>, crate::prelude::Array<crate::lower::model::Ex>)>>, crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>>), crate::check::env::Def)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::lower::model::Pa, crate::prelude::Array<crate::lower::model::Cc>, crate::prelude::Array<crate::lower::model::Ex>)>>, crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>>)>>>
        }).cycle()
    }
}

/// `Start ValuedWidgets, x`: what the function value is when passed to `@Run`.
pub fn start_valued_widgets_f(lx_p0: crate::lower::Lx) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::lower::model::Pa, crate::prelude::Array<crate::lower::model::Cc>, crate::prelude::Array<crate::lower::model::Ex>)>>, crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>>)>> {
    ::std::rc::Rc::new(ValuedWidgets { lx_p0 })
}

/// ```prism
/// ValuedKey: fn Text, [((Text, Ty))] -> Text
/// ```
pub fn valued_key_f(qk_p0: &crate::prelude::Text, types_p1: &crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>) -> crate::prelude::Text {
    if &crate::prelude::len(types_p1) == &crate::prelude::Nat::from(0u32) {
        qk_p0.clone()
    } else {
        crate::prelude::Text::from(format!("{}#{}", qk_p0, &crate::prelude::show_text(types_p1)))
    }
}

/// ```prism
/// ?ValuedTypes: unbounded fn Lx, ValInfo, Range, [Arg] -> ?[((Text, Ty))]
/// ```
pub fn valued_types_o(lx_p0: &crate::lower::Lx, v_p1: &crate::check::env::ValInfo, callee_span_p2: &crate::syntax::Range, args_p3: &crate::prelude::Array<crate::syntax::Arg>) -> ::std::option::Option<crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>> {
    let rigids_p4 = crate::lower::node_::static_::rigids_in_f(&v_p1.scheme_p.ty_p);
    if &crate::prelude::len(&rigids_p4) == &crate::prelude::Nat::from(0u32) {
        ::std::option::Option::Some(crate::prelude::Array::new())
    } else {
        {
            let ptys_p5 = match &v_p1.scheme_p.ty_p {
                crate::check::types::Ty::TyFn(_, ps_p8, _) => ps_p8.clone(),
                _ => crate::prelude::Array::new(),
            };
            let from_arguments_p6 = crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(&ptys_p5)), crate::prelude::Map::new(), {
                let args_p3x = args_p3.clone();
                let ptys_p5x = ptys_p5.clone();
                let lx_p0x = lx_p0.clone();
                ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>, crate::prelude::Nat)| {
                    let args_p3xy = args_p3x.clone();
                    let ptys_p5xy = ptys_p5x.clone();
                    let lx_p0xy = lx_p0x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let m_p9 = p0;
                        let i_pa = p1;
                        match crate::prelude::index(&args_p3xy, &i_pa) {
                            ::std::option::Option::Some(a_pb) => crate::prelude::call_then(crate::lower::node_::static_::start_param_instance_o(crate::prelude::or(&crate::prelude::index(&ptys_p5xy, &i_pa), &crate::check::types::Ty::TyErr), crate::lower::type_at_f(&lx_p0xy, &a_pb.value_p.span_p), m_p9.clone()), move |param_instance_o_18518: ::std::option::Option<crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>>| ::prism_rtl::Turn::Finished(crate::prelude::or(&param_instance_o_18518, &m_p9))),
                            ::std::option::Option::None => ::prism_rtl::Turn::Finished(m_p9.clone()),
                        }
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>, crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>>>>
            }));
            let found_p7 = if crate::prelude::fold(&rigids_p4, &true, &(|all_pc: &bool, q_pd: &crate::prelude::Text| *all_pc && crate::check::env::has_key_f(&from_arguments_p6, q_pd))) {
                from_arguments_p6.clone()
            } else {
                crate::prelude::or(&crate::lower::node_::static_::param_match_o(&crate::lower::node_::static_::unrigid_f(&v_p1.scheme_p.ty_p), &crate::lower::type_at_f(lx_p0, callee_span_p2), &from_arguments_p6), &from_arguments_p6)
            };
            closed_types_o(&rigids_p4, &found_p7)
        }
    }
}

/// The step machine of `ValuedTypes`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?ValuedTypes: unbounded fn Lx, ValInfo, Range, [Arg] -> ?[((Text, Ty))]
/// ```
pub struct ValuedTypes {
    pub lx_p0: crate::lower::Lx,
    pub v_p1: crate::check::env::ValInfo,
    pub callee_span_p2: crate::syntax::Range,
    pub args_p3: crate::prelude::Array<crate::syntax::Arg>,
}

impl ::prism_rtl::Job<::std::option::Option<crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>>> for ValuedTypes {
    fn cycle(&self) -> ::prism_rtl::Turn<::std::option::Option<crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>>> {
        let lx_p0 = &self.lx_p0;
        let v_p1 = &self.v_p1;
        let callee_span_p2 = &self.callee_span_p2;
        let args_p3 = &self.args_p3;
        let args_p3x = args_p3.clone();
        let callee_span_p2x = callee_span_p2.clone();
        let lx_p0x = lx_p0.clone();
        let v_p1x = v_p1.clone();
        crate::prelude::call_then(crate::lower::node_::static_::start_rigids_in_f(v_p1x.scheme_p.ty_p.clone()), move |rigids_in_f_18246: crate::prelude::Array<crate::prelude::Text>| {
            let rigids_p4 = rigids_in_f_18246;
            if &crate::prelude::len(&rigids_p4) == &crate::prelude::Nat::from(0u32) {
                ::prism_rtl::Turn::Finished(::std::option::Option::Some(crate::prelude::Array::new()))
            } else {
                {
                    let ptys_p5 = match &v_p1x.scheme_p.ty_p {
                        crate::check::types::Ty::TyFn(_, ps_p8, _) => ps_p8.clone(),
                        _ => crate::prelude::Array::new(),
                    };
                    crate::prelude::call_value(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(&ptys_p5)), crate::prelude::Map::new(), {
                        let args_p3xx = args_p3x.clone();
                        let ptys_p5x = ptys_p5.clone();
                        let lx_p0xx = lx_p0x.clone();
                        ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>, crate::prelude::Nat)| {
                            let args_p3xxy = args_p3xx.clone();
                            let ptys_p5xy = ptys_p5x.clone();
                            let lx_p0xxy = lx_p0xx.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let m_p9 = p0;
                                let i_pa = p1;
                                match crate::prelude::index(&args_p3xxy, &i_pa) {
                                    ::std::option::Option::Some(a_pb) => crate::prelude::call_then(crate::lower::node_::static_::start_param_instance_o(crate::prelude::or(&crate::prelude::index(&ptys_p5xy, &i_pa), &crate::check::types::Ty::TyErr), crate::lower::type_at_f(&lx_p0xxy, &a_pb.value_p.span_p), m_p9.clone()), move |param_instance_o_18518: ::std::option::Option<crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>>| ::prism_rtl::Turn::Finished(crate::prelude::or(&param_instance_o_18518, &m_p9))),
                                    ::std::option::Option::None => ::prism_rtl::Turn::Finished(m_p9.clone()),
                                }
                            }))
                        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>, crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>>>>
                    }), move |fold_18444: crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>| {
                        let from_arguments_p6 = fold_18444;
                        let rigids_p4z = rigids_p4.clone();
                        let k_let18614 = move |v18614: crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>| {
                            let found_p7 = v18614;
                            ::prism_rtl::Turn::More(::std::rc::Rc::new(ClosedTypes { rigids_p0: rigids_p4z.clone(), found_p1: found_p7.clone() }))
                        };
                        if crate::prelude::fold(&rigids_p4, &true, &(|all_pc: &bool, q_pd: &crate::prelude::Text| *all_pc && crate::check::env::has_key_f(&from_arguments_p6, q_pd))) {
                            k_let18614(from_arguments_p6.clone())
                        } else {
                            crate::prelude::call_then(crate::lower::node_::static_::start_unrigid_f(v_p1x.scheme_p.ty_p.clone()), move |unrigid_f_18728: crate::check::types::Ty| crate::prelude::call_then(crate::lower::node_::static_::start_param_match_o(unrigid_f_18728, crate::lower::type_at_f(&lx_p0x, &callee_span_p2x), from_arguments_p6.clone()), move |param_match_o_18715: ::std::option::Option<crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>>| k_let18614(crate::prelude::or(&param_match_o_18715, &from_arguments_p6))))
                        }
                    })
                }
            }
        })
    }
}

/// `Start ValuedTypes, x`: what the function value is when passed to `@Run`.
pub fn start_valued_types_o(lx_p0: crate::lower::Lx, v_p1: crate::check::env::ValInfo, callee_span_p2: crate::syntax::Range, args_p3: crate::prelude::Array<crate::syntax::Arg>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<::std::option::Option<crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>>>> {
    ::std::rc::Rc::new(ValuedTypes { lx_p0, v_p1, callee_span_p2, args_p3 })
}

/// ```prism
/// ?ClosedTypes: unbounded fn [Text], (Text ==> Ty) -> ?[((Text, Ty))]
/// ```
pub fn closed_types_o(rigids_p0: &crate::prelude::Array<crate::prelude::Text>, found_p1: &crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>) -> ::std::option::Option<crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>> {
    let closed_p5 = crate::prelude::run_to_end(crate::prelude::fold_job(rigids_p0.clone(), true, {
        let found_p1x = found_p1.clone();
        ::std::rc::Rc::new(move |(p0, p1): (bool, crate::prelude::Text)| {
            let found_p1xy = found_p1x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let all_p2 = p0;
                let q_p3 = p1;
                if all_p2 {
                    match crate::prelude::get(&found_p1xy, &q_p3) {
                        ::std::option::Option::Some(t_p4) => crate::prelude::call_then(crate::lower::node_::static_::start_rigids_in_f(t_p4.clone()), move |rigids_in_f_19170: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(&crate::prelude::len(&rigids_in_f_19170) == &crate::prelude::Nat::from(0u32))),
                        ::std::option::Option::None => ::prism_rtl::Turn::Finished(false),
                    }
                } else {
                    ::prism_rtl::Turn::Finished(false)
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::prelude::Text)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
    }));
    if closed_p5 {
        ::std::option::Option::Some(crate::prelude::each(&crate::check::types::sort_texts_f(rigids_p0), &(|q_p6: &crate::prelude::Text| (q_p6.clone(), crate::prelude::or(&crate::prelude::get(found_p1, q_p6), &crate::check::types::Ty::TyErr)))))
    } else {
        ::std::option::Option::None
    }
}

/// The step machine of `ClosedTypes`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?ClosedTypes: unbounded fn [Text], (Text ==> Ty) -> ?[((Text, Ty))]
/// ```
pub struct ClosedTypes {
    pub rigids_p0: crate::prelude::Array<crate::prelude::Text>,
    pub found_p1: crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>,
}

impl ::prism_rtl::Job<::std::option::Option<crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>>> for ClosedTypes {
    fn cycle(&self) -> ::prism_rtl::Turn<::std::option::Option<crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>>> {
        let rigids_p0 = &self.rigids_p0;
        let found_p1 = &self.found_p1;
        let found_p1x = found_p1.clone();
        let rigids_p0x = rigids_p0.clone();
        crate::prelude::call_value(crate::prelude::fold_job(rigids_p0x.clone(), true, {
            let found_p1xx = found_p1x.clone();
            ::std::rc::Rc::new(move |(p0, p1): (bool, crate::prelude::Text)| {
                let found_p1xxy = found_p1xx.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let all_p2 = p0;
                    let q_p3 = p1;
                    if all_p2 {
                        match crate::prelude::get(&found_p1xxy, &q_p3) {
                            ::std::option::Option::Some(t_p4) => crate::prelude::call_then(crate::lower::node_::static_::start_rigids_in_f(t_p4.clone()), move |rigids_in_f_19170: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(&crate::prelude::len(&rigids_in_f_19170) == &crate::prelude::Nat::from(0u32))),
                            ::std::option::Option::None => ::prism_rtl::Turn::Finished(false),
                        }
                    } else {
                        ::prism_rtl::Turn::Finished(false)
                    }
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::prelude::Text)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
        }), move |fold_19098: bool| {
            let closed_p5 = fold_19098;
            if closed_p5 {
                ::prism_rtl::Turn::Finished(::std::option::Option::Some(crate::prelude::each(&crate::check::types::sort_texts_f(&rigids_p0x), &(|q_p6: &crate::prelude::Text| (q_p6.clone(), crate::prelude::or(&crate::prelude::get(&found_p1x, q_p6), &crate::check::types::Ty::TyErr))))))
            } else {
                ::prism_rtl::Turn::Finished(::std::option::Option::None)
            }
        })
    }
}

/// `Start ClosedTypes, x`: what the function value is when passed to `@Run`.
pub fn start_closed_types_o(rigids_p0: crate::prelude::Array<crate::prelude::Text>, found_p1: crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<::std::option::Option<crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>>>> {
    ::std::rc::Rc::new(ClosedTypes { rigids_p0, found_p1 })
}

/// ```prism
/// ?DefInstances: unbounded fn Lx, Text -> ?[ [((Text, Ty))] ]
/// ```
pub fn def_instances_o(lx_p0: &crate::lower::Lx, wanted_p1: &crate::prelude::Text) -> ::std::option::Option<crate::prelude::Array<crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>>> {
    match def_instances_answer_f(lx_p0, wanted_p1) {
        InstancesAnswer::InstancesReached(all_p2) => ::std::option::Option::Some(crate::prelude::each(&all_p2, &(|instantiation_p3: &Instantiation| instantiation_p3.types_p.clone()))),
        _ => ::std::option::Option::None,
    }
}

/// The step machine of `DefInstances`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?DefInstances: unbounded fn Lx, Text -> ?[ [((Text, Ty))] ]
/// ```
pub struct DefInstances {
    pub lx_p0: crate::lower::Lx,
    pub wanted_p1: crate::prelude::Text,
}

impl ::prism_rtl::Job<::std::option::Option<crate::prelude::Array<crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>>>> for DefInstances {
    fn cycle(&self) -> ::prism_rtl::Turn<::std::option::Option<crate::prelude::Array<crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>>>> {
        let lx_p0 = &self.lx_p0;
        let wanted_p1 = &self.wanted_p1;
        let lx_p0x = lx_p0.clone();
        let wanted_p1x = wanted_p1.clone();
        crate::prelude::call_then(start_def_instances_answer_f(lx_p0x.clone(), wanted_p1x.clone()), move |def_instances_answer_f_20262: InstancesAnswer| match def_instances_answer_f_20262 {
            InstancesAnswer::InstancesReached(all_p2) => ::prism_rtl::Turn::Finished(::std::option::Option::Some(crate::prelude::each(&all_p2, &(|instantiation_p3: &Instantiation| instantiation_p3.types_p.clone())))),
            _ => ::prism_rtl::Turn::Finished(::std::option::Option::None),
        })
    }
}

/// `Start DefInstances, x`: what the function value is when passed to `@Run`.
pub fn start_def_instances_o(lx_p0: crate::lower::Lx, wanted_p1: crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<::std::option::Option<crate::prelude::Array<crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>>>>> {
    ::std::rc::Rc::new(DefInstances { lx_p0, wanted_p1 })
}

/// ```prism
/// DefInstancesAnswer: unbounded fn Lx, Text -> InstancesAnswer
/// ```
pub fn def_instances_answer_f(lx_at_p0: &crate::lower::Lx, wanted_p1: &crate::prelude::Text) -> InstancesAnswer {
    let lx_p2 = {
        let mut this: crate::lower::Lx = lx_at_p0.clone();
        this.subst_p = crate::prelude::Map::new();
        this
    };
    let definitions_p3 = crate::prelude::filter(&lx_p2.g_p.defs_p, &(|d_p5: &crate::check::env::Def| &instance_key_f(d_p5) == wanted_p1));
    let rigids_p4 = crate::prelude::run_to_end(crate::prelude::fold_job(definitions_p3.clone(), crate::prelude::Array::new(), {
        let lx_p2x = lx_p2.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::check::env::Def)| {
            let lx_p2xy = lx_p2x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_p6 = p0;
                let d_p7 = p1;
                crate::prelude::call_then(start_definition_rigids_f(lx_p2xy.clone(), d_p7.clone()), move |definition_rigids_f_21532: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_p6, &definition_rigids_f_21532)))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::check::env::Def)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>
    }));
    if &crate::prelude::len(&definitions_p3) == &crate::prelude::Nat::from(0u32) {
        InstancesAnswer::NoDefinition
    } else {
        if &crate::prelude::len(&rigids_p4) == &crate::prelude::Nat::from(0u32) {
            InstancesAnswer::InstancesReached(crate::prelude::Array::from(vec![Instantiation { definition_p: wanted_p1.clone(), types_p: crate::prelude::Array::new(), parent_o: ::std::option::Option::None, step_o: ::std::option::Option::None }]))
        } else {
            {
                let uses_p8 = instance_uses_f(&lx_p2);
                let relevant_p9 = relevant_definitions_f(&lx_p2, &uses_p8, &crate::prelude::Array::from(vec![wanted_p1.clone()]));
                let reaching_pa = crate::prelude::run_to_end(crate::prelude::filter_job(uses_p8.clone(), {
                    let lx_p2x = lx_p2.clone();
                    let relevant_p9x = relevant_p9.clone();
                    ::std::rc::Rc::new(move |p0: InstanceUse| {
                        let lx_p2xy = lx_p2x.clone();
                        let relevant_p9xy = relevant_p9x.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let site_pd = p0;
                            ::prism_rtl::Turn::More(::std::rc::Rc::new(ReachesRelevant { lx_p0: lx_p2xy.clone(), relevant_p1: relevant_p9xy.clone(), site_p2: site_pd.clone() }))
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn(InstanceUse) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
                }));
                let closed_pb = crate::prelude::run_to_end(crate::prelude::fold_job(lx_p2.g_p.defs_p.clone(), crate::prelude::Array::new(), {
                    let lx_p2x = lx_p2.clone();
                    ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::check::env::Def)| {
                        let lx_p2xy = lx_p2x.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let acc_pe = p0;
                            let d_pf = p1;
                            crate::prelude::call_then(start_definition_rigids_f(lx_p2xy.clone(), d_pf.clone()), move |definition_rigids_f_22057: crate::prelude::Array<crate::prelude::Text>| if (&crate::prelude::len(&definition_rigids_f_22057) == &crate::prelude::Nat::from(0u32)) && !crate::check::types::has_text_f(&acc_pe, &instance_key_f(&d_pf)) {
                                ::prism_rtl::Turn::Finished(crate::prelude::push(&acc_pe, &instance_key_f(&d_pf)))
                            } else {
                                ::prism_rtl::Turn::Finished(acc_pe.clone())
                            })
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::check::env::Def)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>
                }));
                let seeded_pc = crate::prelude::run_to_end(crate::prelude::fold_job(closed_pb.clone(), InstancesAnswer::InstancesReached(crate::prelude::Array::new()), {
                    let lx_p2x = lx_p2.clone();
                    let reaching_pax = reaching_pa.clone();
                    let relevant_p9x = relevant_p9.clone();
                    ::std::rc::Rc::new(move |(p0, p1): (InstancesAnswer, crate::prelude::Text)| {
                        let lx_p2xy = lx_p2x.clone();
                        let reaching_paxy = reaching_pax.clone();
                        let relevant_p9xy = relevant_p9x.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let answer_pg = p0;
                            let user_ph = p1;
                            match &answer_pg {
                                InstancesAnswer::InstancesReached(acc_pi) => ::prism_rtl::Turn::More(::std::rc::Rc::new(AddTargets { lx_p0: lx_p2xy.clone(), uses_p1: reaching_paxy.clone(), relevant_p2: relevant_p9xy.clone(), all_p3: acc_pi.clone(), user_p4: user_ph.clone(), types_p5: crate::prelude::Array::new(), parent_o6: ::std::option::Option::None })),
                                _ => ::prism_rtl::Turn::Finished(answer_pg.clone()),
                            }
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn((InstancesAnswer, crate::prelude::Text)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<InstancesAnswer>>>
                }));
                match &seeded_pc {
                    InstancesAnswer::InstancesReached(seeds_pj) => match grow_instances_f(&lx_p2, &reaching_pa, &relevant_p9, seeds_pj, &crate::prelude::Nat::from(0u32)) {
                        InstancesAnswer::InstancesReached(all_pk) => InstancesAnswer::InstancesReached(crate::prelude::filter(&all_pk, &(|instantiation_pl: &Instantiation| &instantiation_pl.definition_p == wanted_p1))),
                        other_pm => other_pm,
                    },
                    other_pn => other_pn.clone(),
                }
            }
        }
    }
}

/// The step machine of `DefInstancesAnswer`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// DefInstancesAnswer: unbounded fn Lx, Text -> InstancesAnswer
/// ```
pub struct DefInstancesAnswer {
    pub lx_at_p0: crate::lower::Lx,
    pub wanted_p1: crate::prelude::Text,
}

impl ::prism_rtl::Job<InstancesAnswer> for DefInstancesAnswer {
    fn cycle(&self) -> ::prism_rtl::Turn<InstancesAnswer> {
        let lx_at_p0 = &self.lx_at_p0;
        let wanted_p1 = &self.wanted_p1;
        let lx_p2 = {
            let mut this: crate::lower::Lx = lx_at_p0.clone();
            this.subst_p = crate::prelude::Map::new();
            this
        };
        let definitions_p3 = crate::prelude::filter(&lx_p2.g_p.defs_p, &(|d_p5: &crate::check::env::Def| &instance_key_f(d_p5) == wanted_p1));
        let wanted_p1x = wanted_p1.clone();
        crate::prelude::call_value(crate::prelude::fold_job(definitions_p3.clone(), crate::prelude::Array::new(), {
            let lx_p2x = lx_p2.clone();
            ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::check::env::Def)| {
                let lx_p2xy = lx_p2x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let acc_p6 = p0;
                    let d_p7 = p1;
                    crate::prelude::call_then(start_definition_rigids_f(lx_p2xy.clone(), d_p7.clone()), move |definition_rigids_f_21532: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_p6, &definition_rigids_f_21532)))
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::check::env::Def)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>
        }), move |fold_21481: crate::prelude::Array<crate::prelude::Text>| {
            let rigids_p4 = fold_21481;
            if &crate::prelude::len(&definitions_p3) == &crate::prelude::Nat::from(0u32) {
                ::prism_rtl::Turn::Finished(InstancesAnswer::NoDefinition)
            } else {
                if &crate::prelude::len(&rigids_p4) == &crate::prelude::Nat::from(0u32) {
                    ::prism_rtl::Turn::Finished(InstancesAnswer::InstancesReached(crate::prelude::Array::from(vec![Instantiation { definition_p: wanted_p1x.clone(), types_p: crate::prelude::Array::new(), parent_o: ::std::option::Option::None, step_o: ::std::option::Option::None }])))
                } else {
                    crate::prelude::call_then(start_instance_uses_f(lx_p2.clone()), move |instance_uses_f_21751: crate::prelude::Array<InstanceUse>| {
                        let uses_p8 = instance_uses_f_21751;
                        crate::prelude::call_then(start_relevant_definitions_f(lx_p2.clone(), uses_p8.clone(), crate::prelude::Array::from(vec![wanted_p1x.clone()])), move |relevant_definitions_f_21790: crate::prelude::Array<crate::prelude::Text>| {
                            let relevant_p9 = relevant_definitions_f_21790;
                            crate::prelude::call_value(crate::prelude::filter_job(uses_p8.clone(), {
                                let lx_p2x = lx_p2.clone();
                                let relevant_p9x = relevant_p9.clone();
                                ::std::rc::Rc::new(move |p0: InstanceUse| {
                                    let lx_p2xy = lx_p2x.clone();
                                    let relevant_p9xy = relevant_p9x.clone();
                                    crate::prelude::entered(crate::prelude::once_job(move || {
                                        let site_pd = p0;
                                        ::prism_rtl::Turn::More(::std::rc::Rc::new(ReachesRelevant { lx_p0: lx_p2xy.clone(), relevant_p1: relevant_p9xy.clone(), site_p2: site_pd.clone() }))
                                    }))
                                }) as ::std::rc::Rc<dyn ::std::ops::Fn(InstanceUse) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
                            }), move |filter_21854: crate::prelude::Array<InstanceUse>| {
                                let reaching_pa = filter_21854;
                                crate::prelude::call_value(crate::prelude::fold_job(lx_p2.g_p.defs_p.clone(), crate::prelude::Array::new(), {
                                    let lx_p2x = lx_p2.clone();
                                    ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::check::env::Def)| {
                                        let lx_p2xy = lx_p2x.clone();
                                        crate::prelude::entered(crate::prelude::once_job(move || {
                                            let acc_pe = p0;
                                            let d_pf = p1;
                                            crate::prelude::call_then(start_definition_rigids_f(lx_p2xy.clone(), d_pf.clone()), move |definition_rigids_f_22057: crate::prelude::Array<crate::prelude::Text>| if (&crate::prelude::len(&definition_rigids_f_22057) == &crate::prelude::Nat::from(0u32)) && !crate::check::types::has_text_f(&acc_pe, &instance_key_f(&d_pf)) {
                                                ::prism_rtl::Turn::Finished(crate::prelude::push(&acc_pe, &instance_key_f(&d_pf)))
                                            } else {
                                                ::prism_rtl::Turn::Finished(acc_pe.clone())
                                            })
                                        }))
                                    }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::check::env::Def)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>
                                }), move |fold_22016: crate::prelude::Array<crate::prelude::Text>| {
                                    let closed_pb = fold_22016;
                                    crate::prelude::call_value(crate::prelude::fold_job(closed_pb.clone(), InstancesAnswer::InstancesReached(crate::prelude::Array::new()), {
                                        let lx_p2x = lx_p2.clone();
                                        let reaching_pax = reaching_pa.clone();
                                        let relevant_p9x = relevant_p9.clone();
                                        ::std::rc::Rc::new(move |(p0, p1): (InstancesAnswer, crate::prelude::Text)| {
                                            let lx_p2xy = lx_p2x.clone();
                                            let reaching_paxy = reaching_pax.clone();
                                            let relevant_p9xy = relevant_p9x.clone();
                                            crate::prelude::entered(crate::prelude::once_job(move || {
                                                let answer_pg = p0;
                                                let user_ph = p1;
                                                match &answer_pg {
                                                    InstancesAnswer::InstancesReached(acc_pi) => ::prism_rtl::Turn::More(::std::rc::Rc::new(AddTargets { lx_p0: lx_p2xy.clone(), uses_p1: reaching_paxy.clone(), relevant_p2: relevant_p9xy.clone(), all_p3: acc_pi.clone(), user_p4: user_ph.clone(), types_p5: crate::prelude::Array::new(), parent_o6: ::std::option::Option::None })),
                                                    _ => ::prism_rtl::Turn::Finished(answer_pg.clone()),
                                                }
                                            }))
                                        }) as ::std::rc::Rc<dyn ::std::ops::Fn((InstancesAnswer, crate::prelude::Text)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<InstancesAnswer>>>
                                    }), move |fold_22184: InstancesAnswer| {
                                        let seeded_pc = fold_22184;
                                        match &seeded_pc {
                                            InstancesAnswer::InstancesReached(seeds_pj) => {
                                                let seeds_pjx = seeds_pj.clone();
                                                crate::prelude::call_then(start_grow_instances_f(lx_p2.clone(), reaching_pa.clone(), relevant_p9.clone(), seeds_pjx.clone(), crate::prelude::Nat::from(0u32)), move |grow_instances_f_22436: InstancesAnswer| match grow_instances_f_22436 {
                                                    InstancesAnswer::InstancesReached(all_pk) => ::prism_rtl::Turn::Finished(InstancesAnswer::InstancesReached(crate::prelude::filter(&all_pk, &(|instantiation_pl: &Instantiation| &instantiation_pl.definition_p == &wanted_p1x)))),
                                                    other_pm => ::prism_rtl::Turn::Finished(other_pm.clone()),
                                                })
                                            },
                                            other_pn => ::prism_rtl::Turn::Finished(other_pn.clone()),
                                        }
                                    })
                                })
                            })
                        })
                    })
                }
            }
        })
    }
}

/// `Start DefInstancesAnswer, x`: what the function value is when passed to `@Run`.
pub fn start_def_instances_answer_f(lx_at_p0: crate::lower::Lx, wanted_p1: crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<InstancesAnswer>> {
    ::std::rc::Rc::new(DefInstancesAnswer { lx_at_p0, wanted_p1 })
}

/// ```prism
/// InstanceKey: fn Def -> Text
/// ```
pub fn instance_key_f(d_p0: &crate::check::env::Def) -> crate::prelude::Text {
    match &d_p0.body_p {
        crate::check::env::DefBody::DbMethod(_, _, _) => crate::prelude::Text::from(format!("{} at {}:{}", &d_p0.qk_p, &d_p0.file_p, &d_p0.span_p.start_p)),
        _ => d_p0.qk_p.clone(),
    }
}

/// ```prism
/// DefinitionRigids: unbounded fn Lx, Def -> [Text]
/// ```
pub fn definition_rigids_f(lx_p0: &crate::lower::Lx, d_p1: &crate::check::env::Def) -> crate::prelude::Array<crate::prelude::Text> {
    match &d_p1.body_p {
        crate::check::env::DefBody::DbMethod(_, cls_p2, im_p3) => crate::check::types::sort_texts_f(&crate::check::types::union_texts_f(&im_p3.qs_p, &crate::prelude::run_to_end(crate::prelude::each_job(method_own_rigids_f(lx_p0, cls_p2, &trait_method_key_f(lx_p0, cls_p2, &d_p1.name_p)), {
            let lx_p0x = lx_p0.clone();
            let cls_p2x = cls_p2.clone();
            let d_p1x = d_p1.clone();
            let im_p3x = im_p3.clone();
            ::std::rc::Rc::new(move |p0: crate::prelude::Text| {
                let lx_p0xy = lx_p0x.clone();
                let cls_p2xy = cls_p2x.clone();
                let d_p1xy = d_p1x.clone();
                let im_p3xy = im_p3x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let q_p4 = p0;
                    ::prism_rtl::Turn::Finished(method_own_name_f(&lx_p0xy, &cls_p2xy, &trait_method_key_f(&lx_p0xy, &cls_p2xy, &d_p1xy.name_p), &im_p3xy, &q_p4))
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
        })))),
        crate::check::env::DefBody::DbDefault(_, cls_p5) => match crate::prelude::get(&lx_p0.g_p.traits_p, cls_p5) {
            ::std::option::Option::Some(tr_p6) => crate::check::types::sort_texts_f(&crate::check::types::union_texts_f(&crate::prelude::Array::from(vec![tr_p6.param_p.clone()]), &method_own_rigids_f(lx_p0, cls_p5, &d_p1.qk_p))),
            ::std::option::Option::None => crate::prelude::Array::new(),
        },
        crate::check::env::DefBody::DbFn(_) => match crate::prelude::get(&lx_p0.g_p.vals_p, &d_p1.qk_p) {
            ::std::option::Option::Some(v_p7) => crate::check::types::sort_texts_f(&crate::lower::node_::static_::rigids_in_f(&v_p7.scheme_p.ty_p)),
            ::std::option::Option::None => crate::prelude::Array::new(),
        },
        crate::check::env::DefBody::DbWidget(_) => match crate::prelude::get(&lx_p0.g_p.vals_p, &d_p1.qk_p) {
            ::std::option::Option::Some(v_p8) => crate::check::types::sort_texts_f(&crate::lower::node_::static_::rigids_in_f(&v_p8.scheme_p.ty_p)),
            ::std::option::Option::None => crate::prelude::Array::new(),
        },
        _ => crate::prelude::Array::new(),
    }
}

/// The step machine of `DefinitionRigids`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// DefinitionRigids: unbounded fn Lx, Def -> [Text]
/// ```
pub struct DefinitionRigids {
    pub lx_p0: crate::lower::Lx,
    pub d_p1: crate::check::env::Def,
}

impl ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>> for DefinitionRigids {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<crate::prelude::Text>> {
        let lx_p0 = &self.lx_p0;
        let d_p1 = &self.d_p1;
        match &d_p1.body_p {
            crate::check::env::DefBody::DbMethod(_, cls_p2, im_p3) => {
                let cls_p2x = cls_p2.clone();
                let d_p1x = d_p1.clone();
                let im_p3x = im_p3.clone();
                let lx_p0x = lx_p0.clone();
                crate::prelude::call_value(crate::prelude::each_job(method_own_rigids_f(&lx_p0x, &cls_p2x, &trait_method_key_f(&lx_p0x, &cls_p2x, &d_p1x.name_p)), {
                    let lx_p0xx = lx_p0x.clone();
                    let cls_p2xx = cls_p2x.clone();
                    let d_p1xx = d_p1x.clone();
                    let im_p3xx = im_p3x.clone();
                    ::std::rc::Rc::new(move |p0: crate::prelude::Text| {
                        let lx_p0xxy = lx_p0xx.clone();
                        let cls_p2xxy = cls_p2xx.clone();
                        let d_p1xxy = d_p1xx.clone();
                        let im_p3xxy = im_p3xx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let q_p4 = p0;
                            ::prism_rtl::Turn::Finished(method_own_name_f(&lx_p0xxy, &cls_p2xxy, &trait_method_key_f(&lx_p0xxy, &cls_p2xxy, &d_p1xxy.name_p), &im_p3xxy, &q_p4))
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
                }), move |each_23318: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::sort_texts_f(&crate::check::types::union_texts_f(&im_p3x.qs_p, &each_23318))))
            },
            crate::check::env::DefBody::DbDefault(_, cls_p5) => match crate::prelude::get(&lx_p0.g_p.traits_p, cls_p5) {
                ::std::option::Option::Some(tr_p6) => ::prism_rtl::Turn::Finished(crate::check::types::sort_texts_f(&crate::check::types::union_texts_f(&crate::prelude::Array::from(vec![tr_p6.param_p.clone()]), &method_own_rigids_f(lx_p0, cls_p5, &d_p1.qk_p)))),
                ::std::option::Option::None => ::prism_rtl::Turn::Finished(crate::prelude::Array::new()),
            },
            crate::check::env::DefBody::DbFn(_) => match crate::prelude::get(&lx_p0.g_p.vals_p, &d_p1.qk_p) {
                ::std::option::Option::Some(v_p7) => crate::prelude::call_then(crate::lower::node_::static_::start_rigids_in_f(v_p7.scheme_p.ty_p.clone()), move |rigids_in_f_23670: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::sort_texts_f(&rigids_in_f_23670))),
                ::std::option::Option::None => ::prism_rtl::Turn::Finished(crate::prelude::Array::new()),
            },
            crate::check::env::DefBody::DbWidget(_) => match crate::prelude::get(&lx_p0.g_p.vals_p, &d_p1.qk_p) {
                ::std::option::Option::Some(v_p8) => crate::prelude::call_then(crate::lower::node_::static_::start_rigids_in_f(v_p8.scheme_p.ty_p.clone()), move |rigids_in_f_23778: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::sort_texts_f(&rigids_in_f_23778))),
                ::std::option::Option::None => ::prism_rtl::Turn::Finished(crate::prelude::Array::new()),
            },
            _ => ::prism_rtl::Turn::Finished(crate::prelude::Array::new()),
        }
    }
}

/// `Start DefinitionRigids, x`: what the function value is when passed to `@Run`.
pub fn start_definition_rigids_f(lx_p0: crate::lower::Lx, d_p1: crate::check::env::Def) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>> {
    ::std::rc::Rc::new(DefinitionRigids { lx_p0, d_p1 })
}

/// ```prism
/// InstanceUses: unbounded fn Lx -> [InstanceUse]
/// ```
pub fn instance_uses_f(lx_p0: &crate::lower::Lx) -> crate::prelude::Array<InstanceUse> {
    crate::prelude::run_to_end(crate::prelude::fold_job(lx_p0.g_p.defs_p.clone(), crate::prelude::Array::new(), {
        let lx_p0x = lx_p0.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<InstanceUse>, crate::check::env::Def)| {
            let lx_p0xy = lx_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_p1 = p0;
                let d_p2 = p1;
                {
                    let lxd_p3 = in_module_f(&lx_p0xy, &d_p2.file_p, &d_p2.home_p);
                    let user_p4 = instance_key_f(&d_p2);
                    let exprs_p5 = instantiating_exprs_f(&d_p2);
                    crate::prelude::call_value(crate::prelude::fold_job(exprs_p5.clone(), (acc_p1.clone(), crate::prelude::Array::new()), {
                        let lx_p0xyx = lx_p0xy.clone();
                        let lxd_p3x = lxd_p3.clone();
                        let user_p4x = user_p4.clone();
                        ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Array<InstanceUse>, crate::prelude::Array<crate::prelude::Nat>), crate::syntax::Expr)| {
                            let lx_p0xyxy = lx_p0xyx.clone();
                            let lxd_p3xy = lxd_p3x.clone();
                            let user_p4xy = user_p4x.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let (uses_p6, spans_p7) = p0;
                                let x_p8 = p1;
                                match &*x_p8.kind_p {
                                    crate::syntax::ExprKind::ECall(c_p9, args_pa, _, _) => match crate::prelude::get(&lx_p0xyxy.g_p.vals_p, &crate::lower::node_::dynamics::callee_key_f(&lxd_p3xy, &**c_p9)) {
                                        ::std::option::Option::Some(v_pb) if ((&crate::prelude::len(&crate::lower::node_::static_::rigids_in_f(&v_pb.scheme_p.ty_p)) > &crate::prelude::Nat::from(0u32)) && (&v_pb.sort_p != &crate::prelude::Text::lit("method"))) => {
                                            let ptys_pc = match &v_pb.scheme_p.ty_p {
                                                crate::check::types::Ty::TyFn(_, ps_pf, _) => ps_pf.clone(),
                                                _ => crate::prelude::Array::new(),
                                            };
                                            let args_pax = args_pa.clone();
                                            let c_p9x = (**c_p9).clone();
                                            crate::prelude::call_value(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(&ptys_pc)), crate::prelude::Map::new(), {
                                                let args_paxx = args_pax.clone();
                                                let ptys_pcx = ptys_pc.clone();
                                                let lxd_p3xyx = lxd_p3xy.clone();
                                                ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>, crate::prelude::Nat)| {
                                                    let args_paxxy = args_paxx.clone();
                                                    let ptys_pcxy = ptys_pcx.clone();
                                                    let lxd_p3xyxy = lxd_p3xyx.clone();
                                                    crate::prelude::entered(crate::prelude::once_job(move || {
                                                        let m_pg = p0;
                                                        let i_ph = p1;
                                                        match crate::prelude::index(&args_paxxy, &i_ph) {
                                                            ::std::option::Option::Some(a_pi) => crate::prelude::call_then(crate::lower::node_::static_::start_param_instance_o(crate::prelude::or(&crate::prelude::index(&ptys_pcxy, &i_ph), &crate::check::types::Ty::TyErr), crate::lower::type_at_f(&lxd_p3xyxy, &a_pi.value_p.span_p), m_pg.clone()), move |param_instance_o_25953: ::std::option::Option<crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>>| ::prism_rtl::Turn::Finished(crate::prelude::or(&param_instance_o_25953, &m_pg))),
                                                            ::std::option::Option::None => ::prism_rtl::Turn::Finished(m_pg.clone()),
                                                        }
                                                    }))
                                                }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>, crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>>>>
                                            }), move |fold_25871: crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>| {
                                                let from_arguments_pd = fold_25871;
                                                crate::prelude::call_then(crate::lower::node_::static_::start_unrigid_f(v_pb.scheme_p.ty_p.clone()), move |unrigid_f_26095: crate::check::types::Ty| crate::prelude::call_then(crate::lower::node_::static_::start_param_match_o(unrigid_f_26095, crate::lower::type_at_f(&lxd_p3xy, &c_p9x.span_p), crate::prelude::Map::new()), move |param_match_o_26082: ::std::option::Option<crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>>| {
                                                    let found_pe = crate::prelude::or(&param_match_o_26082, &from_arguments_pd);
                                                    ::prism_rtl::Turn::Finished((crate::prelude::push(&uses_p6, &InstanceUse::UseOfDefinition(user_p4xy.clone(), crate::lower::node_::dynamics::callee_key_f(&lxd_p3xy, &c_p9x), found_pe.clone())), crate::prelude::push(&spans_p7, &c_p9x.span_p.start_p)))
                                                }))
                                            })
                                        },
                                        _ => ::prism_rtl::Turn::Finished((uses_p6.clone(), spans_p7.clone())),
                                        _ => unreachable!("no arm matched"),
                                    },
                                    _ => ::prism_rtl::Turn::Finished((uses_p6.clone(), spans_p7.clone())),
                                }
                            }))
                        }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Array<InstanceUse>, crate::prelude::Array<crate::prelude::Nat>), crate::syntax::Expr)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<InstanceUse>, crate::prelude::Array<crate::prelude::Nat>)>>>
                    }), move |fold_25492: (crate::prelude::Array<InstanceUse>, crate::prelude::Array<crate::prelude::Nat>)| {
                        let (called_pj, callees_pk) = fold_25492;
                        crate::prelude::fold_job(exprs_p5.clone(), called_pj.clone(), {
                            let lxd_p3x = lxd_p3.clone();
                            let user_p4x = user_p4.clone();
                            let lx_p0xyx = lx_p0xy.clone();
                            let callees_pkx = callees_pk.clone();
                            ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<InstanceUse>, crate::syntax::Expr)| {
                                let lxd_p3xy = lxd_p3x.clone();
                                let user_p4xy = user_p4x.clone();
                                let lx_p0xyxy = lx_p0xyx.clone();
                                let callees_pkxy = callees_pkx.clone();
                                crate::prelude::entered(crate::prelude::once_job(move || {
                                    let uses_pl = p0;
                                    let x_pm = p1;
                                    {
                                        let solved_pn = crate::prelude::fold(&crate::prelude::or(&crate::prelude::get(&lxd_p3xy.impls_p, &crate::lower::place_key_f(&lxd_p3xy, &x_pm.span_p)), &crate::prelude::Array::new()), &uses_pl, &(|more_po: &crate::prelude::Array<InstanceUse>, note_pp: &crate::check::typed::ImplNote| if crate::syntax::lexer::chars::has_prefix_f(&note_pp.how_p, &crate::prelude::Text::lit("impl ")) {
                                            crate::prelude::push(more_po, &InstanceUse::UseOfImpl(user_p4xy.clone(), note_pp.cls_p.clone(), note_pp.ty_p.clone()))
                                        } else {
                                            more_po.clone()
                                        }));
                                        match &*x_pm.kind_p {
                                            crate::syntax::ExprKind::EName(n_pq) => {
                                                let (named_or, _) = crate::check::env::names::resolve_value_f(&lx_p0xyxy.g_p, &lxd_p3xy.home_p, n_pq);
                                                match crate::prelude::get(&lx_p0xyxy.g_p.vals_p, &crate::prelude::or(&named_or, &crate::prelude::Text::lit(""))) {
                                                    ::std::option::Option::Some(v_ps) if ((&v_ps.sort_p == &crate::prelude::Text::lit("method")) && (&crate::prelude::len(&method_own_rigids_f(&lx_p0xyxy, &crate::prelude::or(&crate::prelude::index(&crate::prelude::each(&v_ps.scheme_p.bounds_p, &(|(_, bound_pt): &(crate::prelude::Text, crate::prelude::Text)| bound_pt.clone())), &crate::prelude::Nat::from(0u32)), &crate::prelude::Text::lit("")), &crate::prelude::or(&named_or, &crate::prelude::Text::lit("")))) > &crate::prelude::Nat::from(0u32))) => crate::prelude::call_then(crate::lower::node_::static_::start_unrigid_f(v_ps.scheme_p.ty_p.clone()), move |unrigid_f_27086: crate::check::types::Ty| crate::prelude::call_then(crate::lower::node_::static_::start_param_match_o(unrigid_f_27086, crate::lower::type_at_f(&lxd_p3xy, &x_pm.span_p), crate::prelude::Map::new()), move |param_match_o_27073: ::std::option::Option<crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>>| ::prism_rtl::Turn::Finished(crate::prelude::push(&solved_pn, &InstanceUse::UseOfMethod(user_p4xy.clone(), crate::prelude::or(&named_or, &crate::prelude::Text::lit("")), crate::prelude::or(&param_match_o_27073, &crate::prelude::Map::new())))))),
                                                    ::std::option::Option::Some(v_pu) if (((&crate::prelude::len(&crate::lower::node_::static_::rigids_in_f(&v_pu.scheme_p.ty_p)) > &crate::prelude::Nat::from(0u32)) && (&v_pu.sort_p != &crate::prelude::Text::lit("method"))) && !crate::check::types::has_nat_f(&callees_pkxy, &x_pm.span_p.start_p)) => crate::prelude::call_then(crate::lower::node_::static_::start_unrigid_f(v_pu.scheme_p.ty_p.clone()), move |unrigid_f_27334: crate::check::types::Ty| crate::prelude::call_then(crate::lower::node_::static_::start_param_match_o(unrigid_f_27334, crate::lower::type_at_f(&lxd_p3xy, &x_pm.span_p), crate::prelude::Map::new()), move |param_match_o_27321: ::std::option::Option<crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>>| ::prism_rtl::Turn::Finished(crate::prelude::push(&solved_pn, &InstanceUse::UseOfDefinition(user_p4xy.clone(), crate::prelude::or(&named_or, &crate::prelude::Text::lit("")), crate::prelude::or(&param_match_o_27321, &crate::prelude::Map::new())))))),
                                                    _ => ::prism_rtl::Turn::Finished(solved_pn.clone()),
                                                    _ => unreachable!("no arm matched"),
                                                }
                                            },
                                            _ => ::prism_rtl::Turn::Finished(solved_pn.clone()),
                                        }
                                    }
                                }))
                            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<InstanceUse>, crate::syntax::Expr)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<InstanceUse>>>>
                        }).cycle()
                    })
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<InstanceUse>, crate::check::env::Def)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<InstanceUse>>>>
    }))
}

/// The step machine of `InstanceUses`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InstanceUses: unbounded fn Lx -> [InstanceUse]
/// ```
pub struct InstanceUses {
    pub lx_p0: crate::lower::Lx,
}

impl ::prism_rtl::Job<crate::prelude::Array<InstanceUse>> for InstanceUses {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<InstanceUse>> {
        let lx_p0 = &self.lx_p0;
        crate::prelude::fold_job(lx_p0.g_p.defs_p.clone(), crate::prelude::Array::new(), {
            let lx_p0x = lx_p0.clone();
            ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<InstanceUse>, crate::check::env::Def)| {
                let lx_p0xy = lx_p0x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let acc_p1 = p0;
                    let d_p2 = p1;
                    {
                        let lxd_p3 = in_module_f(&lx_p0xy, &d_p2.file_p, &d_p2.home_p);
                        let user_p4 = instance_key_f(&d_p2);
                        let exprs_p5 = instantiating_exprs_f(&d_p2);
                        crate::prelude::call_value(crate::prelude::fold_job(exprs_p5.clone(), (acc_p1.clone(), crate::prelude::Array::new()), {
                            let lx_p0xyx = lx_p0xy.clone();
                            let lxd_p3x = lxd_p3.clone();
                            let user_p4x = user_p4.clone();
                            ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Array<InstanceUse>, crate::prelude::Array<crate::prelude::Nat>), crate::syntax::Expr)| {
                                let lx_p0xyxy = lx_p0xyx.clone();
                                let lxd_p3xy = lxd_p3x.clone();
                                let user_p4xy = user_p4x.clone();
                                crate::prelude::entered(crate::prelude::once_job(move || {
                                    let (uses_p6, spans_p7) = p0;
                                    let x_p8 = p1;
                                    match &*x_p8.kind_p {
                                        crate::syntax::ExprKind::ECall(c_p9, args_pa, _, _) => match crate::prelude::get(&lx_p0xyxy.g_p.vals_p, &crate::lower::node_::dynamics::callee_key_f(&lxd_p3xy, &**c_p9)) {
                                            ::std::option::Option::Some(v_pb) if ((&crate::prelude::len(&crate::lower::node_::static_::rigids_in_f(&v_pb.scheme_p.ty_p)) > &crate::prelude::Nat::from(0u32)) && (&v_pb.sort_p != &crate::prelude::Text::lit("method"))) => {
                                                let ptys_pc = match &v_pb.scheme_p.ty_p {
                                                    crate::check::types::Ty::TyFn(_, ps_pf, _) => ps_pf.clone(),
                                                    _ => crate::prelude::Array::new(),
                                                };
                                                let args_pax = args_pa.clone();
                                                let c_p9x = (**c_p9).clone();
                                                crate::prelude::call_value(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(&ptys_pc)), crate::prelude::Map::new(), {
                                                    let args_paxx = args_pax.clone();
                                                    let ptys_pcx = ptys_pc.clone();
                                                    let lxd_p3xyx = lxd_p3xy.clone();
                                                    ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>, crate::prelude::Nat)| {
                                                        let args_paxxy = args_paxx.clone();
                                                        let ptys_pcxy = ptys_pcx.clone();
                                                        let lxd_p3xyxy = lxd_p3xyx.clone();
                                                        crate::prelude::entered(crate::prelude::once_job(move || {
                                                            let m_pg = p0;
                                                            let i_ph = p1;
                                                            match crate::prelude::index(&args_paxxy, &i_ph) {
                                                                ::std::option::Option::Some(a_pi) => crate::prelude::call_then(crate::lower::node_::static_::start_param_instance_o(crate::prelude::or(&crate::prelude::index(&ptys_pcxy, &i_ph), &crate::check::types::Ty::TyErr), crate::lower::type_at_f(&lxd_p3xyxy, &a_pi.value_p.span_p), m_pg.clone()), move |param_instance_o_25953: ::std::option::Option<crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>>| ::prism_rtl::Turn::Finished(crate::prelude::or(&param_instance_o_25953, &m_pg))),
                                                                ::std::option::Option::None => ::prism_rtl::Turn::Finished(m_pg.clone()),
                                                            }
                                                        }))
                                                    }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>, crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>>>>
                                                }), move |fold_25871: crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>| {
                                                    let from_arguments_pd = fold_25871;
                                                    crate::prelude::call_then(crate::lower::node_::static_::start_unrigid_f(v_pb.scheme_p.ty_p.clone()), move |unrigid_f_26095: crate::check::types::Ty| crate::prelude::call_then(crate::lower::node_::static_::start_param_match_o(unrigid_f_26095, crate::lower::type_at_f(&lxd_p3xy, &c_p9x.span_p), crate::prelude::Map::new()), move |param_match_o_26082: ::std::option::Option<crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>>| {
                                                        let found_pe = crate::prelude::or(&param_match_o_26082, &from_arguments_pd);
                                                        ::prism_rtl::Turn::Finished((crate::prelude::push(&uses_p6, &InstanceUse::UseOfDefinition(user_p4xy.clone(), crate::lower::node_::dynamics::callee_key_f(&lxd_p3xy, &c_p9x), found_pe.clone())), crate::prelude::push(&spans_p7, &c_p9x.span_p.start_p)))
                                                    }))
                                                })
                                            },
                                            _ => ::prism_rtl::Turn::Finished((uses_p6.clone(), spans_p7.clone())),
                                            _ => unreachable!("no arm matched"),
                                        },
                                        _ => ::prism_rtl::Turn::Finished((uses_p6.clone(), spans_p7.clone())),
                                    }
                                }))
                            }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Array<InstanceUse>, crate::prelude::Array<crate::prelude::Nat>), crate::syntax::Expr)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<InstanceUse>, crate::prelude::Array<crate::prelude::Nat>)>>>
                        }), move |fold_25492: (crate::prelude::Array<InstanceUse>, crate::prelude::Array<crate::prelude::Nat>)| {
                            let (called_pj, callees_pk) = fold_25492;
                            crate::prelude::fold_job(exprs_p5.clone(), called_pj.clone(), {
                                let lxd_p3x = lxd_p3.clone();
                                let user_p4x = user_p4.clone();
                                let lx_p0xyx = lx_p0xy.clone();
                                let callees_pkx = callees_pk.clone();
                                ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<InstanceUse>, crate::syntax::Expr)| {
                                    let lxd_p3xy = lxd_p3x.clone();
                                    let user_p4xy = user_p4x.clone();
                                    let lx_p0xyxy = lx_p0xyx.clone();
                                    let callees_pkxy = callees_pkx.clone();
                                    crate::prelude::entered(crate::prelude::once_job(move || {
                                        let uses_pl = p0;
                                        let x_pm = p1;
                                        {
                                            let solved_pn = crate::prelude::fold(&crate::prelude::or(&crate::prelude::get(&lxd_p3xy.impls_p, &crate::lower::place_key_f(&lxd_p3xy, &x_pm.span_p)), &crate::prelude::Array::new()), &uses_pl, &(|more_po: &crate::prelude::Array<InstanceUse>, note_pp: &crate::check::typed::ImplNote| if crate::syntax::lexer::chars::has_prefix_f(&note_pp.how_p, &crate::prelude::Text::lit("impl ")) {
                                                crate::prelude::push(more_po, &InstanceUse::UseOfImpl(user_p4xy.clone(), note_pp.cls_p.clone(), note_pp.ty_p.clone()))
                                            } else {
                                                more_po.clone()
                                            }));
                                            match &*x_pm.kind_p {
                                                crate::syntax::ExprKind::EName(n_pq) => {
                                                    let (named_or, _) = crate::check::env::names::resolve_value_f(&lx_p0xyxy.g_p, &lxd_p3xy.home_p, n_pq);
                                                    match crate::prelude::get(&lx_p0xyxy.g_p.vals_p, &crate::prelude::or(&named_or, &crate::prelude::Text::lit(""))) {
                                                        ::std::option::Option::Some(v_ps) if ((&v_ps.sort_p == &crate::prelude::Text::lit("method")) && (&crate::prelude::len(&method_own_rigids_f(&lx_p0xyxy, &crate::prelude::or(&crate::prelude::index(&crate::prelude::each(&v_ps.scheme_p.bounds_p, &(|(_, bound_pt): &(crate::prelude::Text, crate::prelude::Text)| bound_pt.clone())), &crate::prelude::Nat::from(0u32)), &crate::prelude::Text::lit("")), &crate::prelude::or(&named_or, &crate::prelude::Text::lit("")))) > &crate::prelude::Nat::from(0u32))) => crate::prelude::call_then(crate::lower::node_::static_::start_unrigid_f(v_ps.scheme_p.ty_p.clone()), move |unrigid_f_27086: crate::check::types::Ty| crate::prelude::call_then(crate::lower::node_::static_::start_param_match_o(unrigid_f_27086, crate::lower::type_at_f(&lxd_p3xy, &x_pm.span_p), crate::prelude::Map::new()), move |param_match_o_27073: ::std::option::Option<crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>>| ::prism_rtl::Turn::Finished(crate::prelude::push(&solved_pn, &InstanceUse::UseOfMethod(user_p4xy.clone(), crate::prelude::or(&named_or, &crate::prelude::Text::lit("")), crate::prelude::or(&param_match_o_27073, &crate::prelude::Map::new())))))),
                                                        ::std::option::Option::Some(v_pu) if (((&crate::prelude::len(&crate::lower::node_::static_::rigids_in_f(&v_pu.scheme_p.ty_p)) > &crate::prelude::Nat::from(0u32)) && (&v_pu.sort_p != &crate::prelude::Text::lit("method"))) && !crate::check::types::has_nat_f(&callees_pkxy, &x_pm.span_p.start_p)) => crate::prelude::call_then(crate::lower::node_::static_::start_unrigid_f(v_pu.scheme_p.ty_p.clone()), move |unrigid_f_27334: crate::check::types::Ty| crate::prelude::call_then(crate::lower::node_::static_::start_param_match_o(unrigid_f_27334, crate::lower::type_at_f(&lxd_p3xy, &x_pm.span_p), crate::prelude::Map::new()), move |param_match_o_27321: ::std::option::Option<crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>>| ::prism_rtl::Turn::Finished(crate::prelude::push(&solved_pn, &InstanceUse::UseOfDefinition(user_p4xy.clone(), crate::prelude::or(&named_or, &crate::prelude::Text::lit("")), crate::prelude::or(&param_match_o_27321, &crate::prelude::Map::new())))))),
                                                        _ => ::prism_rtl::Turn::Finished(solved_pn.clone()),
                                                        _ => unreachable!("no arm matched"),
                                                    }
                                                },
                                                _ => ::prism_rtl::Turn::Finished(solved_pn.clone()),
                                            }
                                        }
                                    }))
                                }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<InstanceUse>, crate::syntax::Expr)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<InstanceUse>>>>
                            }).cycle()
                        })
                    }
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<InstanceUse>, crate::check::env::Def)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<InstanceUse>>>>
        }).cycle()
    }
}

/// `Start InstanceUses, x`: what the function value is when passed to `@Run`.
pub fn start_instance_uses_f(lx_p0: crate::lower::Lx) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<InstanceUse>>> {
    ::std::rc::Rc::new(InstanceUses { lx_p0 })
}

/// ```prism
/// InstantiatingExprs: unbounded fn Def -> [Expr]
/// ```
pub fn instantiating_exprs_f(d_p0: &crate::check::env::Def) -> crate::prelude::Array<crate::syntax::Expr> {
    match &d_p0.body_p {
        crate::check::env::DefBody::DbTest(t_p1) => crate::check::typed::print::exprs_in_f(&t_p1.blueprint_p),
        crate::check::env::DefBody::DbCheck(c_p2) => crate::prelude::run_to_end(crate::prelude::fold_job(c_p2.lines_p.clone(), crate::prelude::Array::new(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::syntax::Expr>, crate::syntax::decls::CheckLine)| crate::prelude::entered(crate::prelude::once_job(move || {
            let acc_p3 = p0;
            let line_p4 = p1;
            crate::prelude::call_then(crate::check::typed::print::start_exprs_in_f(line_p4.expr_p.clone()), move |exprs_in_f_27755: crate::prelude::Array<crate::syntax::Expr>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_p3, &exprs_in_f_27755)))
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::syntax::Expr>, crate::syntax::decls::CheckLine)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::syntax::Expr>>>>)),
        _ => crate::lower::expr::def_exprs_f(d_p0),
    }
}

/// ```prism
/// UseUser: fn InstanceUse -> Text
/// ```
pub fn use_user_f(site_p0: &InstanceUse) -> crate::prelude::Text {
    match site_p0 {
        InstanceUse::UseOfDefinition(user_p1, _, _) => user_p1.clone(),
        InstanceUse::UseOfImpl(user_p2, _, _) => user_p2.clone(),
        InstanceUse::UseOfMethod(user_p3, _, _) => user_p3.clone(),
    }
}

/// ```prism
/// ReachesRelevant: unbounded fn Lx, [Text], InstanceUse -> Bool
/// ```
pub fn reaches_relevant_f(lx_p0: &crate::lower::Lx, relevant_p1: &crate::prelude::Array<crate::prelude::Text>, site_p2: &InstanceUse) -> bool {
    match site_p2 {
        InstanceUse::UseOfDefinition(_, target_p3, _) => crate::check::types::has_text_f(relevant_p1, target_p3),
        InstanceUse::UseOfImpl(_, _, _) => holds_method_f(lx_p0, relevant_p1),
        InstanceUse::UseOfMethod(_, _, _) => holds_method_f(lx_p0, relevant_p1),
    }
}

/// The step machine of `ReachesRelevant`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ReachesRelevant: unbounded fn Lx, [Text], InstanceUse -> Bool
/// ```
pub struct ReachesRelevant {
    pub lx_p0: crate::lower::Lx,
    pub relevant_p1: crate::prelude::Array<crate::prelude::Text>,
    pub site_p2: InstanceUse,
}

impl ::prism_rtl::Job<bool> for ReachesRelevant {
    fn cycle(&self) -> ::prism_rtl::Turn<bool> {
        let lx_p0 = &self.lx_p0;
        let relevant_p1 = &self.relevant_p1;
        let site_p2 = &self.site_p2;
        match site_p2 {
            InstanceUse::UseOfDefinition(_, target_p3, _) => ::prism_rtl::Turn::Finished(crate::check::types::has_text_f(relevant_p1, target_p3)),
            InstanceUse::UseOfImpl(_, _, _) => ::prism_rtl::Turn::Finished(holds_method_f(lx_p0, relevant_p1)),
            InstanceUse::UseOfMethod(_, _, _) => ::prism_rtl::Turn::Finished(holds_method_f(lx_p0, relevant_p1)),
        }
    }
}

/// `Start ReachesRelevant, x`: what the function value is when passed to `@Run`.
pub fn start_reaches_relevant_f(lx_p0: crate::lower::Lx, relevant_p1: crate::prelude::Array<crate::prelude::Text>, site_p2: InstanceUse) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>> {
    ::std::rc::Rc::new(ReachesRelevant { lx_p0, relevant_p1, site_p2 })
}

/// ```prism
/// HoldsMethod: unbounded fn Lx, [Text] -> Bool
/// ```
pub fn holds_method_f(lx_p0: &crate::lower::Lx, relevant_p1: &crate::prelude::Array<crate::prelude::Text>) -> bool {
    crate::prelude::fold(&lx_p0.g_p.defs_p, &false, &(|found_p2: &bool, d_p3: &crate::check::env::Def| *found_p2 || match &d_p3.body_p {
        crate::check::env::DefBody::DbMethod(_, _, _) => crate::check::types::has_text_f(relevant_p1, &instance_key_f(d_p3)),
        crate::check::env::DefBody::DbDefault(_, _) => crate::check::types::has_text_f(relevant_p1, &instance_key_f(d_p3)),
        _ => false,
    }))
}

/// ```prism
/// TraitMethodKey: unbounded fn Lx, Text, Text -> Text
/// ```
pub fn trait_method_key_f(lx_p0: &crate::lower::Lx, cls_p1: &crate::prelude::Text, name_p2: &crate::prelude::Text) -> crate::prelude::Text {
    match crate::prelude::get(&lx_p0.g_p.traits_p, cls_p1) {
        ::std::option::Option::Some(tr_p3) => crate::prelude::fold(&tr_p3.methods_p, &crate::prelude::Text::lit(""), &(|found_p4: &crate::prelude::Text, k_p5: &crate::prelude::Text| if (found_p4 == &crate::prelude::Text::lit("")) && ((&crate::check::types::bare_name_f(k_p5) == name_p2) || (&crate::syntax::lexer::chars::drop_prefix_f(k_p5, &crate::prelude::Text::from(format!("{}.", &tr_p3.home_p))) == name_p2)) {
            k_p5.clone()
        } else {
            found_p4.clone()
        })),
        ::std::option::Option::None => crate::prelude::Text::lit(""),
    }
}

/// ```prism
/// MethodOwnRigids: unbounded fn Lx, Text, Text -> [Text]
/// ```
pub fn method_own_rigids_f(lx_p0: &crate::lower::Lx, cls_p1: &crate::prelude::Text, method_qk_p2: &crate::prelude::Text) -> crate::prelude::Array<crate::prelude::Text> {
    match (crate::prelude::get(&lx_p0.g_p.traits_p, cls_p1), crate::prelude::get(&lx_p0.g_p.vals_p, method_qk_p2)) {
        (::std::option::Option::Some(tr_p3), ::std::option::Option::Some(v_p4)) => crate::check::types::sort_texts_f(&crate::prelude::filter(&crate::lower::node_::static_::rigids_in_f(&v_p4.scheme_p.ty_p), &(|q_p5: &crate::prelude::Text| q_p5 != &tr_p3.param_p))),
        _ => crate::prelude::Array::new(),
    }
}

/// ```prism
/// MethodOwnName: unbounded fn Lx, Text, Text, ImplInfo, Text -> Text
/// ```
pub fn method_own_name_f(lx_p0: &crate::lower::Lx, cls_p1: &crate::prelude::Text, method_qk_p2: &crate::prelude::Text, im_p3: &crate::check::env::ImplInfo, q_p4: &crate::prelude::Text) -> crate::prelude::Text {
    match (crate::prelude::get(&lx_p0.g_p.traits_p, cls_p1), crate::prelude::get(&lx_p0.g_p.vals_p, method_qk_p2)) {
        (::std::option::Option::Some(tr_p5), ::std::option::Option::Some(v_p6)) => crate::check::types::schemes::apart_name_f(q_p4, &im_p3.qs_p, &crate::prelude::filter(&v_p6.scheme_p.qs_p, &(|own_p7: &crate::prelude::Text| own_p7 != &tr_p5.param_p))),
        _ => q_p4.clone(),
    }
}

/// ```prism
/// RelevantDefinitions: unbounded fn Lx, [InstanceUse], [Text] -> [Text]
/// ```
pub fn relevant_definitions_f(lx_p0: &crate::lower::Lx, uses_p1: &crate::prelude::Array<InstanceUse>, relevant_p2: &crate::prelude::Array<crate::prelude::Text>) -> crate::prelude::Array<crate::prelude::Text> {
    let grown_p3 = crate::prelude::run_to_end(crate::prelude::fold_job(uses_p1.clone(), relevant_p2.clone(), {
        let lx_p0x = lx_p0.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, InstanceUse)| {
            let lx_p0xy = lx_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_p4 = p0;
                let site_p5 = p1;
                if crate::check::types::has_text_f(&acc_p4, &use_user_f(&site_p5)) || !reaches_relevant_f(&lx_p0xy, &acc_p4, &site_p5) {
                    ::prism_rtl::Turn::Finished(acc_p4.clone())
                } else {
                    ::prism_rtl::Turn::Finished(crate::prelude::push(&acc_p4, &use_user_f(&site_p5)))
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, InstanceUse)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>
    }));
    if &crate::prelude::len(&grown_p3) == &crate::prelude::len(relevant_p2) {
        relevant_p2.clone()
    } else {
        relevant_definitions_f(lx_p0, uses_p1, &grown_p3)
    }
}

/// The step machine of `RelevantDefinitions`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RelevantDefinitions: unbounded fn Lx, [InstanceUse], [Text] -> [Text]
/// ```
pub struct RelevantDefinitions {
    pub lx_p0: crate::lower::Lx,
    pub uses_p1: crate::prelude::Array<InstanceUse>,
    pub relevant_p2: crate::prelude::Array<crate::prelude::Text>,
}

impl ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>> for RelevantDefinitions {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<crate::prelude::Text>> {
        let lx_p0 = &self.lx_p0;
        let uses_p1 = &self.uses_p1;
        let relevant_p2 = &self.relevant_p2;
        let lx_p0x = lx_p0.clone();
        let relevant_p2x = relevant_p2.clone();
        let uses_p1x = uses_p1.clone();
        crate::prelude::call_value(crate::prelude::fold_job(uses_p1x.clone(), relevant_p2x.clone(), {
            let lx_p0xx = lx_p0x.clone();
            ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, InstanceUse)| {
                let lx_p0xxy = lx_p0xx.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let acc_p4 = p0;
                    let site_p5 = p1;
                    if crate::check::types::has_text_f(&acc_p4, &use_user_f(&site_p5)) || !reaches_relevant_f(&lx_p0xxy, &acc_p4, &site_p5) {
                        ::prism_rtl::Turn::Finished(acc_p4.clone())
                    } else {
                        ::prism_rtl::Turn::Finished(crate::prelude::push(&acc_p4, &use_user_f(&site_p5)))
                    }
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, InstanceUse)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>
        }), move |fold_30550: crate::prelude::Array<crate::prelude::Text>| {
            let grown_p3 = fold_30550;
            if &crate::prelude::len(&grown_p3) == &crate::prelude::len(&relevant_p2x) {
                ::prism_rtl::Turn::Finished(relevant_p2x.clone())
            } else {
                ::prism_rtl::Turn::More(::std::rc::Rc::new(RelevantDefinitions { lx_p0: lx_p0x.clone(), uses_p1: uses_p1x.clone(), relevant_p2: grown_p3.clone() }))
            }
        })
    }
}

/// `Start RelevantDefinitions, x`: what the function value is when passed to `@Run`.
pub fn start_relevant_definitions_f(lx_p0: crate::lower::Lx, uses_p1: crate::prelude::Array<InstanceUse>, relevant_p2: crate::prelude::Array<crate::prelude::Text>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>> {
    ::std::rc::Rc::new(RelevantDefinitions { lx_p0, uses_p1, relevant_p2 })
}

/// ```prism
/// GrowInstances: unbounded fn Lx, [InstanceUse], [Text], [Instantiation], Nat -> InstancesAnswer
/// ```
pub fn grow_instances_f(lx_p0: &crate::lower::Lx, uses_p1: &crate::prelude::Array<InstanceUse>, relevant_p2: &crate::prelude::Array<crate::prelude::Text>, all_p3: &crate::prelude::Array<Instantiation>, next_p4: &crate::prelude::Nat) -> InstancesAnswer {
    match crate::prelude::index(all_p3, next_p4) {
        ::std::option::Option::None => InstancesAnswer::InstancesReached(all_p3.clone()),
        ::std::option::Option::Some(instantiation_p5) => match add_targets_f(lx_p0, uses_p1, relevant_p2, all_p3, &instantiation_p5.definition_p, &instantiation_p5.types_p, &::std::option::Option::Some(next_p4.clone())) {
            InstancesAnswer::InstancesReached(more_p6) => grow_instances_f(lx_p0, uses_p1, relevant_p2, &more_p6, &(next_p4 + &crate::prelude::Nat::from(1u32))),
            other_p7 => other_p7,
        },
    }
}

/// The step machine of `GrowInstances`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// GrowInstances: unbounded fn Lx, [InstanceUse], [Text], [Instantiation], Nat -> InstancesAnswer
/// ```
pub struct GrowInstances {
    pub lx_p0: crate::lower::Lx,
    pub uses_p1: crate::prelude::Array<InstanceUse>,
    pub relevant_p2: crate::prelude::Array<crate::prelude::Text>,
    pub all_p3: crate::prelude::Array<Instantiation>,
    pub next_p4: crate::prelude::Nat,
}

impl ::prism_rtl::Job<InstancesAnswer> for GrowInstances {
    fn cycle(&self) -> ::prism_rtl::Turn<InstancesAnswer> {
        let lx_p0 = &self.lx_p0;
        let uses_p1 = &self.uses_p1;
        let relevant_p2 = &self.relevant_p2;
        let all_p3 = &self.all_p3;
        let next_p4 = &self.next_p4;
        match crate::prelude::index(all_p3, next_p4) {
            ::std::option::Option::None => ::prism_rtl::Turn::Finished(InstancesAnswer::InstancesReached(all_p3.clone())),
            ::std::option::Option::Some(instantiation_p5) => {
                let all_p3x = all_p3.clone();
                let lx_p0x = lx_p0.clone();
                let next_p4x = next_p4.clone();
                let relevant_p2x = relevant_p2.clone();
                let uses_p1x = uses_p1.clone();
                crate::prelude::call_then(start_add_targets_f(lx_p0x.clone(), uses_p1x.clone(), relevant_p2x.clone(), all_p3x.clone(), instantiation_p5.definition_p.clone(), instantiation_p5.types_p.clone(), ::std::option::Option::Some(next_p4x.clone())), move |add_targets_f_31170: InstancesAnswer| match add_targets_f_31170 {
                    InstancesAnswer::InstancesReached(more_p6) => ::prism_rtl::Turn::More(::std::rc::Rc::new(GrowInstances { lx_p0: lx_p0x.clone(), uses_p1: uses_p1x.clone(), relevant_p2: relevant_p2x.clone(), all_p3: more_p6.clone(), next_p4: &next_p4x + &crate::prelude::Nat::from(1u32) })),
                    other_p7 => ::prism_rtl::Turn::Finished(other_p7.clone()),
                })
            },
        }
    }
}

/// `Start GrowInstances, x`: what the function value is when passed to `@Run`.
pub fn start_grow_instances_f(lx_p0: crate::lower::Lx, uses_p1: crate::prelude::Array<InstanceUse>, relevant_p2: crate::prelude::Array<crate::prelude::Text>, all_p3: crate::prelude::Array<Instantiation>, next_p4: crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<InstancesAnswer>> {
    ::std::rc::Rc::new(GrowInstances { lx_p0, uses_p1, relevant_p2, all_p3, next_p4 })
}

/// ```prism
/// AddTargets: unbounded fn Lx, [InstanceUse], [Text], [Instantiation], Text, [((Text, Ty))], ?Nat -> InstancesAnswer
/// ```
pub fn add_targets_f(lx_p0: &crate::lower::Lx, uses_p1: &crate::prelude::Array<InstanceUse>, relevant_p2: &crate::prelude::Array<crate::prelude::Text>, all_p3: &crate::prelude::Array<Instantiation>, user_p4: &crate::prelude::Text, types_p5: &crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>, parent_o6: &::std::option::Option<crate::prelude::Nat>) -> InstancesAnswer {
    crate::prelude::run_to_end(crate::prelude::fold_job(uses_p1.clone(), InstancesAnswer::InstancesReached(all_p3.clone()), {
        let user_p4x = user_p4.clone();
        let lx_p0x = lx_p0.clone();
        let types_p5x = types_p5.clone();
        let relevant_p2x = relevant_p2.clone();
        let parent_o6x = parent_o6.clone();
        ::std::rc::Rc::new(move |(p0, p1): (InstancesAnswer, InstanceUse)| {
            let user_p4xy = user_p4x.clone();
            let lx_p0xy = lx_p0x.clone();
            let types_p5xy = types_p5x.clone();
            let relevant_p2xy = relevant_p2x.clone();
            let parent_o6xy = parent_o6x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let answer_p7 = p0;
                let site_p8 = p1;
                match &answer_p7 {
                    InstancesAnswer::InstancesReached(acc_p9) => if &use_user_f(&site_p8) != &user_p4xy {
                        ::prism_rtl::Turn::Finished(answer_p7.clone())
                    } else {
                        match use_targets_o(&lx_p0xy, &site_p8, &types_p5xy) {
                            ::std::option::Option::None => ::prism_rtl::Turn::Finished(InstancesAnswer::UndecidedParameter),
                            ::std::option::Option::Some(targets_pa) => crate::prelude::fold_job(targets_pa.clone(), answer_p7.clone(), {
                                let relevant_p2xyx = relevant_p2xy.clone();
                                let lx_p0xyx = lx_p0xy.clone();
                                let parent_o6xyx = parent_o6xy.clone();
                                ::std::rc::Rc::new(move |(p0, p1): (InstancesAnswer, (crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>, ::std::option::Option<crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>>))| {
                                    let relevant_p2xyxy = relevant_p2xyx.clone();
                                    let lx_p0xyxy = lx_p0xyx.clone();
                                    let parent_o6xyxy = parent_o6xyx.clone();
                                    crate::prelude::entered(crate::prelude::once_job(move || {
                                        let inner_pb = p0;
                                        let (definition_pc, taken_pd, step_oe) = p1;
                                        match &inner_pb {
                                            InstancesAnswer::InstancesReached(sofar_pf) => {
                                                let known_pg = crate::prelude::fold(sofar_pf, &false, &(|seen_ph: &bool, other_pi: &Instantiation| *seen_ph || ((&other_pi.definition_p == &definition_pc) && (&crate::prelude::show_text(&other_pi.types_p) == &crate::prelude::show_text(&taken_pd)))));
                                                if known_pg || !crate::check::types::has_text_f(&relevant_p2xyxy, &definition_pc) {
                                                    ::prism_rtl::Turn::Finished(inner_pb.clone())
                                                } else {
                                                    match grows_from_o(&lx_p0xyxy, sofar_pf, &parent_o6xyxy, &definition_pc, &taken_pd, &step_oe) {
                                                        ::std::option::Option::Some(endless_pj) => ::prism_rtl::Turn::Finished(endless_pj.clone()),
                                                        ::std::option::Option::None => ::prism_rtl::Turn::Finished(InstancesAnswer::InstancesReached(crate::prelude::push(sofar_pf, &Instantiation { definition_p: definition_pc.clone(), types_p: taken_pd.clone(), parent_o: parent_o6xyxy.clone(), step_o: step_oe.clone() }))),
                                                    }
                                                }
                                            },
                                            _ => ::prism_rtl::Turn::Finished(inner_pb.clone()),
                                        }
                                    }))
                                }) as ::std::rc::Rc<dyn ::std::ops::Fn((InstancesAnswer, (crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>, ::std::option::Option<crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>>))) -> ::std::rc::Rc<dyn ::prism_rtl::Job<InstancesAnswer>>>
                            }).cycle(),
                        }
                    },
                    _ => ::prism_rtl::Turn::Finished(answer_p7.clone()),
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((InstancesAnswer, InstanceUse)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<InstancesAnswer>>>
    }))
}

/// The step machine of `AddTargets`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// AddTargets: unbounded fn Lx, [InstanceUse], [Text], [Instantiation], Text, [((Text, Ty))], ?Nat -> InstancesAnswer
/// ```
pub struct AddTargets {
    pub lx_p0: crate::lower::Lx,
    pub uses_p1: crate::prelude::Array<InstanceUse>,
    pub relevant_p2: crate::prelude::Array<crate::prelude::Text>,
    pub all_p3: crate::prelude::Array<Instantiation>,
    pub user_p4: crate::prelude::Text,
    pub types_p5: crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>,
    pub parent_o6: ::std::option::Option<crate::prelude::Nat>,
}

impl ::prism_rtl::Job<InstancesAnswer> for AddTargets {
    fn cycle(&self) -> ::prism_rtl::Turn<InstancesAnswer> {
        let lx_p0 = &self.lx_p0;
        let uses_p1 = &self.uses_p1;
        let relevant_p2 = &self.relevant_p2;
        let all_p3 = &self.all_p3;
        let user_p4 = &self.user_p4;
        let types_p5 = &self.types_p5;
        let parent_o6 = &self.parent_o6;
        crate::prelude::fold_job(uses_p1.clone(), InstancesAnswer::InstancesReached(all_p3.clone()), {
            let user_p4x = user_p4.clone();
            let lx_p0x = lx_p0.clone();
            let types_p5x = types_p5.clone();
            let relevant_p2x = relevant_p2.clone();
            let parent_o6x = parent_o6.clone();
            ::std::rc::Rc::new(move |(p0, p1): (InstancesAnswer, InstanceUse)| {
                let user_p4xy = user_p4x.clone();
                let lx_p0xy = lx_p0x.clone();
                let types_p5xy = types_p5x.clone();
                let relevant_p2xy = relevant_p2x.clone();
                let parent_o6xy = parent_o6x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let answer_p7 = p0;
                    let site_p8 = p1;
                    match &answer_p7 {
                        InstancesAnswer::InstancesReached(acc_p9) => if &use_user_f(&site_p8) != &user_p4xy {
                            ::prism_rtl::Turn::Finished(answer_p7.clone())
                        } else {
                            match use_targets_o(&lx_p0xy, &site_p8, &types_p5xy) {
                                ::std::option::Option::None => ::prism_rtl::Turn::Finished(InstancesAnswer::UndecidedParameter),
                                ::std::option::Option::Some(targets_pa) => crate::prelude::fold_job(targets_pa.clone(), answer_p7.clone(), {
                                    let relevant_p2xyx = relevant_p2xy.clone();
                                    let lx_p0xyx = lx_p0xy.clone();
                                    let parent_o6xyx = parent_o6xy.clone();
                                    ::std::rc::Rc::new(move |(p0, p1): (InstancesAnswer, (crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>, ::std::option::Option<crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>>))| {
                                        let relevant_p2xyxy = relevant_p2xyx.clone();
                                        let lx_p0xyxy = lx_p0xyx.clone();
                                        let parent_o6xyxy = parent_o6xyx.clone();
                                        crate::prelude::entered(crate::prelude::once_job(move || {
                                            let inner_pb = p0;
                                            let (definition_pc, taken_pd, step_oe) = p1;
                                            match &inner_pb {
                                                InstancesAnswer::InstancesReached(sofar_pf) => {
                                                    let known_pg = crate::prelude::fold(sofar_pf, &false, &(|seen_ph: &bool, other_pi: &Instantiation| *seen_ph || ((&other_pi.definition_p == &definition_pc) && (&crate::prelude::show_text(&other_pi.types_p) == &crate::prelude::show_text(&taken_pd)))));
                                                    if known_pg || !crate::check::types::has_text_f(&relevant_p2xyxy, &definition_pc) {
                                                        ::prism_rtl::Turn::Finished(inner_pb.clone())
                                                    } else {
                                                        match grows_from_o(&lx_p0xyxy, sofar_pf, &parent_o6xyxy, &definition_pc, &taken_pd, &step_oe) {
                                                            ::std::option::Option::Some(endless_pj) => ::prism_rtl::Turn::Finished(endless_pj.clone()),
                                                            ::std::option::Option::None => ::prism_rtl::Turn::Finished(InstancesAnswer::InstancesReached(crate::prelude::push(sofar_pf, &Instantiation { definition_p: definition_pc.clone(), types_p: taken_pd.clone(), parent_o: parent_o6xyxy.clone(), step_o: step_oe.clone() }))),
                                                        }
                                                    }
                                                },
                                                _ => ::prism_rtl::Turn::Finished(inner_pb.clone()),
                                            }
                                        }))
                                    }) as ::std::rc::Rc<dyn ::std::ops::Fn((InstancesAnswer, (crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>, ::std::option::Option<crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>>))) -> ::std::rc::Rc<dyn ::prism_rtl::Job<InstancesAnswer>>>
                                }).cycle(),
                            }
                        },
                        _ => ::prism_rtl::Turn::Finished(answer_p7.clone()),
                    }
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((InstancesAnswer, InstanceUse)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<InstancesAnswer>>>
        }).cycle()
    }
}

/// `Start AddTargets, x`: what the function value is when passed to `@Run`.
pub fn start_add_targets_f(lx_p0: crate::lower::Lx, uses_p1: crate::prelude::Array<InstanceUse>, relevant_p2: crate::prelude::Array<crate::prelude::Text>, all_p3: crate::prelude::Array<Instantiation>, user_p4: crate::prelude::Text, types_p5: crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>, parent_o6: ::std::option::Option<crate::prelude::Nat>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<InstancesAnswer>> {
    ::std::rc::Rc::new(AddTargets { lx_p0, uses_p1, relevant_p2, all_p3, user_p4, types_p5, parent_o6 })
}

/// ```prism
/// ?GrowsFrom: unbounded fn Lx, [Instantiation], ?Nat, Text, [((Text, Ty))], ?[((Text, Ty))] -> ?InstancesAnswer
/// ```
pub fn grows_from_o(lx_p0: &crate::lower::Lx, all_p1: &crate::prelude::Array<Instantiation>, at_o2: &::std::option::Option<crate::prelude::Nat>, definition_p3: &crate::prelude::Text, types_p4: &crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>, composed_o5: &::std::option::Option<crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>>) -> ::std::option::Option<InstancesAnswer> {
    match at_o2 {
        ::std::option::Option::None => ::std::option::Option::None,
        ::std::option::Option::Some(at_p6) => match crate::prelude::index(all_p1, at_p6) {
            ::std::option::Option::None => ::std::option::Option::None,
            ::std::option::Option::Some(above_p7) => {
                let grows_o8 = if &above_p7.definition_p != definition_p3 {
                    ::std::option::Option::None
                } else {
                    match composed_o5 {
                        ::std::option::Option::Some(composed_pa) => if crate::prelude::run_to_end(crate::prelude::fold_job(composed_pa.clone(), false, ::std::rc::Rc::new(move |(p0, p1): (bool, (crate::prelude::Text, crate::check::types::Ty))| crate::prelude::entered(crate::prelude::once_job(move || {
                            let found_pb = p0;
                            let (q_pc, t_pd) = p1;
                            if found_pb {
                                ::prism_rtl::Turn::Finished(true)
                            } else {
                                if &t_pd != &crate::check::types::Ty::TyRigid(q_pc.clone()) {
                                    crate::prelude::call_then(crate::lower::node_::static_::start_rigids_in_f(t_pd.clone()), move |rigids_in_f_34906: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::has_text_f(&rigids_in_f_34906, &q_pc)))
                                } else {
                                    ::prism_rtl::Turn::Finished(false)
                                }
                            }
                        }))) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, (crate::prelude::Text, crate::check::types::Ty))) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>)) {
                            ::std::option::Option::Some(InstancesAnswer::EndlessByName)
                        } else {
                            ::std::option::Option::None
                        },
                        ::std::option::Option::None => {
                            let embedded_pe = (&crate::prelude::len(&above_p7.types_p) == &crate::prelude::len(types_p4)) && crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(types_p4)), true, {
                                let above_p7x = above_p7.clone();
                                let types_p4x = types_p4.clone();
                                ::std::rc::Rc::new(move |(p0, p1): (bool, crate::prelude::Nat)| {
                                    let above_p7xy = above_p7x.clone();
                                    let types_p4xy = types_p4x.clone();
                                    crate::prelude::entered(crate::prelude::once_job(move || {
                                        let every_pf = p0;
                                        let i_pg = p1;
                                        ::prism_rtl::Turn::Finished(every_pf && match (crate::prelude::index(&above_p7xy.types_p, &i_pg), crate::prelude::index(&types_p4xy, &i_pg)) {
                                            (::std::option::Option::Some((_, small_ph)), ::std::option::Option::Some((ignore2_pi, large_pj))) => embeds_f(&small_ph, &large_pj),
                                            _ => false,
                                        })
                                    }))
                                }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
                            }));
                            if embedded_pe {
                                ::std::option::Option::Some(InstancesAnswer::EndlessThroughImpl)
                            } else {
                                ::std::option::Option::None
                            }
                        },
                    }
                };
                let further_o9 = match (composed_o5.clone(), above_p7.step_o.clone()) {
                    (::std::option::Option::Some(composed_pk), ::std::option::Option::Some(step_pl)) => {
                        let lx_step_pm = {
                            let mut this: crate::lower::Lx = lx_p0.clone();
                            this.subst_p = crate::prelude::fold(&step_pl, &crate::prelude::Map::new(), &(|m_pn: &crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>, (q_po, t_pp): &(crate::prelude::Text, crate::check::types::Ty)| crate::prelude::insert(m_pn, q_po, t_pp)));
                            this.csubst_p = crate::prelude::Map::new();
                            this
                        };
                        ::std::option::Option::Some(crate::prelude::each(&composed_pk, &(|(q_pq, t_pr): &(crate::prelude::Text, crate::check::types::Ty)| (q_pq.clone(), crate::lower::subst_ty_in_f(&lx_step_pm, t_pr)))))
                    },
                    _ => ::std::option::Option::None,
                };
                match &grows_o8 {
                    ::std::option::Option::Some(endless_ps) => ::std::option::Option::Some(endless_ps.clone()),
                    ::std::option::Option::None => grows_from_o(lx_p0, all_p1, &above_p7.parent_o, definition_p3, types_p4, &further_o9),
                }
            },
        },
    }
}

/// ```prism
/// HoldsAssociated: unbounded fn Ty -> Bool
/// ```
pub fn holds_associated_f(t_p0: &crate::check::types::Ty) -> bool {
    match t_p0 {
        crate::check::types::Ty::TyAssoc(_, _, ignore2_p1) => true,
        _ => crate::prelude::run_to_end(crate::prelude::fold_job(parts_of_type_f(t_p0), false, ::std::rc::Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| crate::prelude::entered(crate::prelude::once_job(move || {
            let found_p2 = p0;
            let part_p3 = p1;
            ::prism_rtl::Turn::Finished(found_p2 || holds_associated_f(&part_p3))
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::check::types::Ty)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>)),
    }
}

/// ```prism
/// Embeds: unbounded fn Ty, Ty -> Bool
/// ```
pub fn embeds_f(small_p0: &crate::check::types::Ty, large_p1: &crate::check::types::Ty) -> bool {
    let small_parts_p2 = parts_of_type_f(small_p0);
    let large_parts_p3 = parts_of_type_f(large_p1);
    let inside_p4 = crate::prelude::run_to_end(crate::prelude::fold_job(large_parts_p3.clone(), false, {
        let small_p0x = small_p0.clone();
        ::std::rc::Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| {
            let small_p0xy = small_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let found_p6 = p0;
                let part_p7 = p1;
                ::prism_rtl::Turn::Finished(found_p6 || embeds_f(&small_p0xy, &part_p7))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::check::types::Ty)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
    }));
    let same_former_p5 = (&crate::prelude::len(&small_parts_p2) == &crate::prelude::len(&large_parts_p3)) && (&type_former_f(small_p0) == &type_former_f(large_p1));
    ((small_p0 == large_p1) || inside_p4) || (same_former_p5 && crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(&small_parts_p2)), true, {
        let small_parts_p2x = small_parts_p2.clone();
        let large_parts_p3x = large_parts_p3.clone();
        ::std::rc::Rc::new(move |(p0, p1): (bool, crate::prelude::Nat)| {
            let small_parts_p2xy = small_parts_p2x.clone();
            let large_parts_p3xy = large_parts_p3x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let every_p8 = p0;
                let i_p9 = p1;
                ::prism_rtl::Turn::Finished(every_p8 && embeds_f(&crate::prelude::or(&crate::prelude::index(&small_parts_p2xy, &i_p9), &crate::check::types::Ty::TyErr), &crate::prelude::or(&crate::prelude::index(&large_parts_p3xy, &i_p9), &crate::check::types::Ty::TyErr)))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
    })))
}

/// ```prism
/// PartsOfType: fn Ty -> [Ty]
/// ```
pub fn parts_of_type_f(t_p0: &crate::check::types::Ty) -> crate::prelude::Array<crate::check::types::Ty> {
    match t_p0 {
        crate::check::types::Ty::TyCon(_, args_p1) => args_p1.clone(),
        crate::check::types::Ty::TyFn(_, ps_p2, r_p3) => crate::prelude::push(ps_p2, &**r_p3),
        crate::check::types::Ty::TyTuple(ts_p4) => ts_p4.clone(),
        crate::check::types::Ty::TyArray(e_p5) => crate::prelude::Array::from(vec![(**e_p5).clone()]),
        crate::check::types::Ty::TyMap(k_p6, v_p7) => crate::prelude::Array::from(vec![(**k_p6).clone(), (**v_p7).clone()]),
        crate::check::types::Ty::TySig(_, i_p8) => crate::prelude::Array::from(vec![(**i_p8).clone()]),
        crate::check::types::Ty::TyAt(i_p9, _) => crate::prelude::Array::from(vec![(**i_p9).clone()]),
        crate::check::types::Ty::TyElem(_, o_pa) => crate::prelude::Array::from(vec![(**o_pa).clone()]),
        crate::check::types::Ty::TyAssoc(_, _, x_pb) => crate::prelude::Array::from(vec![(**x_pb).clone()]),
        _ => crate::prelude::Array::new(),
    }
}

/// ```prism
/// TypeFormer: fn Ty -> Ty
/// ```
pub fn type_former_f(t_p0: &crate::check::types::Ty) -> crate::check::types::Ty {
    match t_p0 {
        crate::check::types::Ty::TyCon(n_p1, args_p2) => crate::check::types::Ty::TyCon(n_p1.clone(), crate::prelude::each(args_p2, &(|_: &crate::check::types::Ty| crate::check::types::Ty::TyErr))),
        crate::check::types::Ty::TyFn(c_p3, ps_p4, _) => crate::check::types::Ty::TyFn(c_p3.clone(), crate::prelude::each(ps_p4, &(|ignore2_p5: &crate::check::types::Ty| crate::check::types::Ty::TyErr)), ::std::rc::Rc::new(crate::check::types::Ty::TyErr)),
        crate::check::types::Ty::TyTuple(ts_p6) => crate::check::types::Ty::TyTuple(crate::prelude::each(ts_p6, &(|_: &crate::check::types::Ty| crate::check::types::Ty::TyErr))),
        crate::check::types::Ty::TyArray(_) => crate::check::types::Ty::TyArray(::std::rc::Rc::new(crate::check::types::Ty::TyErr)),
        crate::check::types::Ty::TyMap(_, ignore2_p7) => crate::check::types::Ty::TyMap(::std::rc::Rc::new(crate::check::types::Ty::TyErr), ::std::rc::Rc::new(crate::check::types::Ty::TyErr)),
        crate::check::types::Ty::TySig(s_p8, _) => crate::check::types::Ty::TySig(s_p8.clone(), ::std::rc::Rc::new(crate::check::types::Ty::TyErr)),
        crate::check::types::Ty::TyAt(_, r_p9) => crate::check::types::Ty::TyAt(::std::rc::Rc::new(crate::check::types::Ty::TyErr), r_p9.clone()),
        crate::check::types::Ty::TyElem(r_pa, _) => crate::check::types::Ty::TyElem(r_pa.clone(), ::std::rc::Rc::new(crate::check::types::Ty::TyErr)),
        crate::check::types::Ty::TyAssoc(cls_pb, n_pc, _) => crate::check::types::Ty::TyAssoc(cls_pb.clone(), n_pc.clone(), ::std::rc::Rc::new(crate::check::types::Ty::TyErr)),
        other_pd => other_pd.clone(),
    }
}

/// ```prism
/// ?UseTargets: unbounded fn Lx, InstanceUse, [((Text, Ty))] -> ?[((Text, [((Text, Ty))], ?[((Text, Ty))]))]
/// ```
pub fn use_targets_o(lx_p0: &crate::lower::Lx, site_p1: &InstanceUse, types_p2: &crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>) -> ::std::option::Option<crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>, ::std::option::Option<crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>>)>> {
    let lxu_p6 = {
        let mut this: crate::lower::Lx = lx_p0.clone();
        this.subst_p = crate::prelude::fold(types_p2, &crate::prelude::Map::new(), &(|m_p3: &crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>, (q_p4, t_p5): &(crate::prelude::Text, crate::check::types::Ty)| crate::prelude::insert(m_p3, q_p4, t_p5)));
        this
    };
    match site_p1 {
        InstanceUse::UseOfDefinition(_, target_p7, found_p8) => match crate::prelude::get(&lx_p0.g_p.vals_p, target_p7) {
            ::std::option::Option::Some(v_p9) => {
                let rigids_pa = crate::lower::node_::static_::rigids_in_f(&v_p9.scheme_p.ty_p);
                let read_pb = crate::prelude::fold(&rigids_pa, &crate::prelude::Map::new(), &(|m_pe: &crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>, q_pf: &crate::prelude::Text| match crate::prelude::get(found_p8, q_pf) {
                    ::std::option::Option::Some(t_pg) => crate::prelude::insert(m_pe, q_pf, &crate::lower::subst_ty_f(&lxu_p6, &t_pg)),
                    ::std::option::Option::None => m_pe.clone(),
                }));
                let written_pc = crate::prelude::fold(&crate::check::types::sort_texts_f(&rigids_pa), &crate::prelude::Array::new(), &(|acc_ph: &crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>, q_pi: &crate::prelude::Text| match crate::prelude::get(found_p8, q_pi) {
                    ::std::option::Option::Some(t_pj) => crate::prelude::push(acc_ph, &(q_pi.clone(), t_pj)),
                    ::std::option::Option::None => acc_ph.clone(),
                }));
                let step_od = if crate::prelude::run_to_end(crate::prelude::fold_job(written_pc.clone(), false, ::std::rc::Rc::new(move |(p0, p1): (bool, (crate::prelude::Text, crate::check::types::Ty))| crate::prelude::entered(crate::prelude::once_job(move || {
                    let held_pk = p0;
                    let (_, t_pl) = p1;
                    ::prism_rtl::Turn::Finished(held_pk || holds_associated_f(&t_pl))
                }))) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, (crate::prelude::Text, crate::check::types::Ty))) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>)) {
                    ::std::option::Option::None
                } else {
                    ::std::option::Option::Some(written_pc.clone())
                };
                match closed_types_o(&rigids_pa, &read_pb) {
                    ::std::option::Option::Some(taken_pm) => ::std::option::Option::Some(crate::prelude::Array::from(vec![(target_p7.clone(), taken_pm, step_od.clone())])),
                    ::std::option::Option::None => ::std::option::Option::None,
                }
            },
            ::std::option::Option::None => ::std::option::Option::None,
        },
        InstanceUse::UseOfImpl(_, cls_pn, ty_po) => {
            let at_pp = crate::lower::subst_ty_f(&lxu_p6, ty_po);
            if &crate::prelude::len(&crate::lower::node_::static_::rigids_in_f(&at_pp)) > &crate::prelude::Nat::from(0u32) {
                ::std::option::Option::None
            } else {
                ::std::option::Option::Some(crate::prelude::each(&impl_targets_f(lx_p0, cls_pn, &at_pp), &(|(definition_pq, taken_pr): &(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)| (definition_pq.clone(), taken_pr.clone(), ::std::option::Option::None))))
            }
        },
        InstanceUse::UseOfMethod(_, method_qk_ps, found_pt) => match crate::prelude::get(&lx_p0.g_p.vals_p, method_qk_ps) {
            ::std::option::Option::Some(v_pu) => {
                let cls_pv = crate::prelude::or(&crate::prelude::index(&crate::prelude::each(&v_pu.scheme_p.bounds_p, &(|(_, bound_p14): &(crate::prelude::Text, crate::prelude::Text)| bound_p14.clone())), &crate::prelude::Nat::from(0u32)), &crate::prelude::Text::lit(""));
                let own_p10 = method_own_rigids_f(lx_p0, &cls_pv, method_qk_ps);
                let own_read_p11 = crate::prelude::fold(&own_p10, &crate::prelude::Map::new(), &(|m_p15: &crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>, q_p16: &crate::prelude::Text| match crate::prelude::get(found_pt, q_p16) {
                    ::std::option::Option::Some(t_p17) => crate::prelude::insert(m_p15, q_p16, &crate::lower::subst_ty_f(&lxu_p6, &t_p17)),
                    ::std::option::Option::None => m_p15.clone(),
                }));
                let own_types_o12 = closed_types_o(&own_p10, &own_read_p11);
                let at_o13 = match crate::prelude::get(&lx_p0.g_p.traits_p, &cls_pv) {
                    ::std::option::Option::Some(tr_p18) => match crate::prelude::get(found_pt, &tr_p18.param_p) {
                        ::std::option::Option::Some(t_p19) => ::std::option::Option::Some(crate::lower::subst_ty_f(&lxu_p6, &t_p19)),
                        ::std::option::Option::None => ::std::option::Option::None,
                    },
                    ::std::option::Option::None => ::std::option::Option::None,
                };
                match (own_types_o12.clone(), at_o13.clone()) {
                    (::std::option::Option::Some(own_types_p1a), ::std::option::Option::Some(at_p1b)) => if &crate::prelude::len(&crate::lower::node_::static_::rigids_in_f(&at_p1b)) > &crate::prelude::Nat::from(0u32) {
                        ::std::option::Option::None
                    } else {
                        ::std::option::Option::Some(crate::prelude::each(&method_targets_f(lx_p0, &cls_pv, method_qk_ps, &at_p1b, &own_types_p1a), &(|(definition_p1c, taken_p1d): &(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)| (definition_p1c.clone(), taken_p1d.clone(), ::std::option::Option::None))))
                    },
                    _ => ::std::option::Option::None,
                }
            },
            ::std::option::Option::None => ::std::option::Option::None,
        },
    }
}

/// ```prism
/// MethodTargets: unbounded fn Lx, Text, Text, Ty, [((Text, Ty))] -> [((Text, [((Text, Ty))]))]
/// ```
pub fn method_targets_f(lx_p0: &crate::lower::Lx, cls_p1: &crate::prelude::Text, method_qk_p2: &crate::prelude::Text, ty_p3: &crate::check::types::Ty, own_types_p4: &crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>) -> crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)> {
    crate::prelude::run_to_end(crate::prelude::fold_job(crate::prelude::or(&crate::prelude::get(&lx_p0.g_p.impls_p, cls_p1), &crate::prelude::Array::new()), crate::prelude::Array::new(), {
        let ty_p3x = ty_p3.clone();
        let lx_p0x = lx_p0.clone();
        let cls_p1x = cls_p1.clone();
        let method_qk_p2x = method_qk_p2.clone();
        let own_types_p4x = own_types_p4.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>, crate::check::env::ImplInfo)| {
            let ty_p3xy = ty_p3x.clone();
            let lx_p0xy = lx_p0x.clone();
            let cls_p1xy = cls_p1x.clone();
            let method_qk_p2xy = method_qk_p2x.clone();
            let own_types_p4xy = own_types_p4x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_p5 = p0;
                let im_p6 = p1;
                crate::prelude::call_then(crate::lower::node_::static_::start_unrigid_f(im_p6.head_p.clone()), move |unrigid_f_41052: crate::check::types::Ty| crate::prelude::call_then(crate::lower::node_::static_::start_param_match_o(unrigid_f_41052, ty_p3xy.clone(), crate::prelude::Map::new()), move |param_match_o_41039: ::std::option::Option<crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>>| match param_match_o_41039 {
                    ::std::option::Option::None => ::prism_rtl::Turn::Finished(acc_p5.clone()),
                    ::std::option::Option::Some(matched_p7) => {
                        let taken_p8 = crate::prelude::each(&crate::check::types::sort_texts_f(&im_p6.qs_p), &(|q_pc: &crate::prelude::Text| (q_pc.clone(), crate::prelude::or(&crate::prelude::get(&matched_p7, q_pc), &crate::check::types::Ty::TyErr))));
                        crate::prelude::call_value(crate::prelude::filter_job(lx_p0xy.g_p.defs_p.clone(), {
                            let im_p6x = im_p6.clone();
                            let lx_p0xyx = lx_p0xy.clone();
                            let cls_p1xyx = cls_p1xy.clone();
                            let method_qk_p2xyx = method_qk_p2xy.clone();
                            ::std::rc::Rc::new(move |p0: crate::check::env::Def| {
                                let im_p6xy = im_p6x.clone();
                                let lx_p0xyxy = lx_p0xyx.clone();
                                let cls_p1xyxy = cls_p1xyx.clone();
                                let method_qk_p2xyxy = method_qk_p2xyx.clone();
                                crate::prelude::entered(crate::prelude::once_job(move || {
                                    let d_pd = p0;
                                    ::prism_rtl::Turn::Finished(crate::lower::functions::is_method_of_f(&d_pd, &im_p6xy) && (&trait_method_key_f(&lx_p0xyxy, &cls_p1xyxy, &d_pd.name_p) == &method_qk_p2xyxy))
                                }))
                            }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::env::Def) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
                        }), move |filter_41207: crate::prelude::Array<crate::check::env::Def>| {
                            let written_p9 = filter_41207;
                            crate::prelude::call_value(crate::prelude::each_job(own_types_p4xy.clone(), {
                                let lx_p0xyx = lx_p0xy.clone();
                                let cls_p1xyx = cls_p1xy.clone();
                                let method_qk_p2xyx = method_qk_p2xy.clone();
                                let im_p6x = im_p6.clone();
                                ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::check::types::Ty)| {
                                    let lx_p0xyxy = lx_p0xyx.clone();
                                    let cls_p1xyxy = cls_p1xyx.clone();
                                    let method_qk_p2xyxy = method_qk_p2xyx.clone();
                                    let im_p6xy = im_p6x.clone();
                                    crate::prelude::entered(crate::prelude::once_job(move || {
                                        let (q_pe, t_pf) = p0;
                                        ::prism_rtl::Turn::Finished((method_own_name_f(&lx_p0xyxy, &cls_p1xyxy, &method_qk_p2xyxy, &im_p6xy, &q_pe), t_pf.clone()))
                                    }))
                                }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::check::types::Ty)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Text, crate::check::types::Ty)>>>
                            }), move |each_41321: crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>| {
                                let own_there_pa = each_41321;
                                let methods_pb = crate::prelude::fold(&written_p9, &acc_p5, &(|more_pg: &crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>, d_ph: &crate::check::env::Def| crate::prelude::push(more_pg, &(instance_key_f(d_ph), instance_types_f(&taken_p8, &own_there_pa)))));
                                if &crate::prelude::len(&written_p9) > &crate::prelude::Nat::from(0u32) {
                                    ::prism_rtl::Turn::Finished(methods_pb.clone())
                                } else {
                                    match crate::prelude::get(&lx_p0xy.g_p.traits_p, &cls_p1xy) {
                                        ::std::option::Option::Some(tr_pi) => if crate::check::types::has_text_f(&tr_pi.defaults_p, &method_qk_p2xy) {
                                            ::prism_rtl::Turn::Finished(crate::prelude::push(&methods_pb, &(method_qk_p2xy.clone(), instance_types_f(&crate::prelude::Array::from(vec![(tr_pi.param_p.clone(), ty_p3xy.clone())]), &own_types_p4xy))))
                                        } else {
                                            ::prism_rtl::Turn::Finished(methods_pb.clone())
                                        },
                                        ::std::option::Option::None => ::prism_rtl::Turn::Finished(methods_pb.clone()),
                                    }
                                }
                            })
                        })
                    },
                }))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>, crate::check::env::ImplInfo)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>>>>
    }))
}

/// ```prism
/// InstanceTypes: fn [((Text, Ty))], [((Text, Ty))] -> [((Text, Ty))]
/// ```
pub fn instance_types_f(outer_p0: &crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>, own_p1: &crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>) -> crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)> {
    let all_p2 = crate::prelude::append(outer_p0, own_p1);
    crate::prelude::fold(&crate::check::types::sort_texts_f(&crate::prelude::each(&all_p2, &(|(q_p3, _): &(crate::prelude::Text, crate::check::types::Ty)| q_p3.clone()))), &crate::prelude::Array::new(), &(|acc_p4: &crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>, q_p5: &crate::prelude::Text| match crate::prelude::index(&crate::prelude::filter(&all_p2, &(|(other_p6, _): &(crate::prelude::Text, crate::check::types::Ty)| other_p6 == q_p5)), &crate::prelude::Nat::from(0u32)) {
        ::std::option::Option::Some(found_p7) => crate::prelude::push(acc_p4, &found_p7),
        ::std::option::Option::None => acc_p4.clone(),
    }))
}

/// ```prism
/// ImplTargets: unbounded fn Lx, Text, Ty -> [((Text, [((Text, Ty))]))]
/// ```
pub fn impl_targets_f(lx_p0: &crate::lower::Lx, cls_p1: &crate::prelude::Text, ty_p2: &crate::check::types::Ty) -> crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)> {
    crate::prelude::run_to_end(crate::prelude::fold_job(crate::prelude::or(&crate::prelude::get(&lx_p0.g_p.impls_p, cls_p1), &crate::prelude::Array::new()), crate::prelude::Array::new(), {
        let ty_p2x = ty_p2.clone();
        let lx_p0x = lx_p0.clone();
        let cls_p1x = cls_p1.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>, crate::check::env::ImplInfo)| {
            let ty_p2xy = ty_p2x.clone();
            let lx_p0xy = lx_p0x.clone();
            let cls_p1xy = cls_p1x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_p3 = p0;
                let im_p4 = p1;
                crate::prelude::call_then(crate::lower::node_::static_::start_unrigid_f(im_p4.head_p.clone()), move |unrigid_f_42706: crate::check::types::Ty| crate::prelude::call_then(crate::lower::node_::static_::start_param_match_o(unrigid_f_42706, ty_p2xy.clone(), crate::prelude::Map::new()), move |param_match_o_42693: ::std::option::Option<crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>>| match param_match_o_42693 {
                    ::std::option::Option::None => ::prism_rtl::Turn::Finished(acc_p3.clone()),
                    ::std::option::Option::Some(matched_p5) => {
                        let taken_p6 = crate::prelude::each(&crate::check::types::sort_texts_f(&im_p4.qs_p), &(|q_pa: &crate::prelude::Text| (q_pa.clone(), crate::prelude::or(&crate::prelude::get(&matched_p5, q_pa), &crate::check::types::Ty::TyErr))));
                        let written_p7 = crate::prelude::filter(&lx_p0xy.g_p.defs_p, &(|d_pb: &crate::check::env::Def| crate::lower::functions::is_method_of_f(d_pb, &im_p4)));
                        crate::prelude::call_value(crate::prelude::fold_job(written_p7.clone(), acc_p3.clone(), {
                            let lx_p0xyx = lx_p0xy.clone();
                            let cls_p1xyx = cls_p1xy.clone();
                            let taken_p6x = taken_p6.clone();
                            ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>, crate::check::env::Def)| {
                                let lx_p0xyxy = lx_p0xyx.clone();
                                let cls_p1xyxy = cls_p1xyx.clone();
                                let taken_p6xy = taken_p6x.clone();
                                crate::prelude::entered(crate::prelude::once_job(move || {
                                    let more_pc = p0;
                                    let d_pd = p1;
                                    if &crate::prelude::len(&method_own_rigids_f(&lx_p0xyxy, &cls_p1xyxy, &trait_method_key_f(&lx_p0xyxy, &cls_p1xyxy, &d_pd.name_p))) > &crate::prelude::Nat::from(0u32) {
                                        ::prism_rtl::Turn::Finished(more_pc.clone())
                                    } else {
                                        ::prism_rtl::Turn::Finished(crate::prelude::push(&more_pc, &(instance_key_f(&d_pd), taken_p6xy.clone())))
                                    }
                                }))
                            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>, crate::check::env::Def)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>>>>
                        }), move |fold_43036: crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>| {
                            let methods_p8 = fold_43036;
                            let im_p4z = im_p4.clone();
                            let lx_p0xyz = lx_p0xy.clone();
                            let matched_p5z = matched_p5.clone();
                            let k_let43197 = move |v43197: crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>| {
                                let defaults_p9 = v43197;
                                crate::prelude::fold_job(im_p4z.bounds_p.clone(), defaults_p9.clone(), {
                                    let matched_p5zx = matched_p5z.clone();
                                    let lx_p0xyzx = lx_p0xyz.clone();
                                    ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>, (crate::prelude::Text, crate::prelude::Text))| {
                                        let matched_p5zxy = matched_p5zx.clone();
                                        let lx_p0xyzxy = lx_p0xyzx.clone();
                                        crate::prelude::entered(crate::prelude::once_job(move || {
                                            let more_pj = p0;
                                            let (q_pk, bound_pl) = p1;
                                            match crate::prelude::get(&matched_p5zxy, &q_pk) {
                                                ::std::option::Option::Some(part_pm) => ::prism_rtl::Turn::Finished(crate::prelude::append(&more_pj, &impl_targets_f(&lx_p0xyzxy, &bound_pl, &part_pm))),
                                                ::std::option::Option::None => ::prism_rtl::Turn::Finished(more_pj.clone()),
                                            }
                                        }))
                                    }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>, (crate::prelude::Text, crate::prelude::Text))) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>>>>
                                }).cycle()
                            };
                            match crate::prelude::get(&lx_p0xy.g_p.traits_p, &cls_p1xy) {
                                ::std::option::Option::Some(tr_pe) => crate::prelude::call_value(crate::prelude::fold_job(tr_pe.defaults_p.clone(), methods_p8.clone(), {
                                    let lx_p0xyx = lx_p0xy.clone();
                                    let cls_p1xyx = cls_p1xy.clone();
                                    let written_p7x = written_p7.clone();
                                    let tr_pex = tr_pe.clone();
                                    let ty_p2xyx = ty_p2xy.clone();
                                    ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>, crate::prelude::Text)| {
                                        let lx_p0xyxy = lx_p0xyx.clone();
                                        let cls_p1xyxy = cls_p1xyx.clone();
                                        let written_p7xy = written_p7x.clone();
                                        let tr_pexy = tr_pex.clone();
                                        let ty_p2xyxy = ty_p2xyx.clone();
                                        crate::prelude::entered(crate::prelude::once_job(move || {
                                            let more_pf = p0;
                                            let default_qk_pg = p1;
                                            if (&crate::prelude::len(&method_own_rigids_f(&lx_p0xyxy, &cls_p1xyxy, &default_qk_pg)) > &crate::prelude::Nat::from(0u32)) || crate::prelude::fold(&written_p7xy, &false, &(|found_ph: &bool, d_pi: &crate::check::env::Def| *found_ph || (&d_pi.name_p == &crate::check::types::bare_name_f(&default_qk_pg)))) {
                                                ::prism_rtl::Turn::Finished(more_pf.clone())
                                            } else {
                                                ::prism_rtl::Turn::Finished(crate::prelude::push(&more_pf, &(default_qk_pg.clone(), crate::prelude::Array::from(vec![(tr_pexy.param_p.clone(), ty_p2xyxy.clone())]))))
                                            }
                                        }))
                                    }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>, crate::prelude::Text)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>>>>
                                }), move |fold_43254: crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>| k_let43197(fold_43254)),
                                ::std::option::Option::None => k_let43197(methods_p8.clone()),
                            }
                        })
                    },
                }))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>, crate::check::env::ImplInfo)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>>>>
    }))
}

/// ```prism
/// ?EnclosingInstances: unbounded fn Lx -> ?[ [((Text, Ty))] ]
/// ```
pub fn enclosing_instances_o(lx_p0: &crate::lower::Lx) -> ::std::option::Option<crate::prelude::Array<crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>>> {
    if &lx_p0.in_definition_p == &crate::prelude::Text::lit("") {
        ::std::option::Option::None
    } else {
        def_instances_o(lx_p0, &lx_p0.in_definition_p)
    }
}

/// The step machine of `EnclosingInstances`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?EnclosingInstances: unbounded fn Lx -> ?[ [((Text, Ty))] ]
/// ```
pub struct EnclosingInstances {
    pub lx_p0: crate::lower::Lx,
}

impl ::prism_rtl::Job<::std::option::Option<crate::prelude::Array<crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>>>> for EnclosingInstances {
    fn cycle(&self) -> ::prism_rtl::Turn<::std::option::Option<crate::prelude::Array<crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>>>> {
        let lx_p0 = &self.lx_p0;
        if &lx_p0.in_definition_p == &crate::prelude::Text::lit("") {
            ::prism_rtl::Turn::Finished(::std::option::Option::None)
        } else {
            ::prism_rtl::Turn::More(::std::rc::Rc::new(DefInstances { lx_p0: lx_p0.clone(), wanted_p1: lx_p0.in_definition_p.clone() }))
        }
    }
}

/// `Start EnclosingInstances, x`: what the function value is when passed to `@Run`.
pub fn start_enclosing_instances_o(lx_p0: crate::lower::Lx) -> ::std::rc::Rc<dyn ::prism_rtl::Job<::std::option::Option<crate::prelude::Array<crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>>>>> {
    ::std::rc::Rc::new(EnclosingInstances { lx_p0 })
}

/// ```prism
/// EnclosingAnswer: unbounded fn Lx -> InstancesAnswer
/// ```
pub fn enclosing_answer_f(lx_p0: &crate::lower::Lx) -> InstancesAnswer {
    if &lx_p0.in_definition_p == &crate::prelude::Text::lit("") {
        InstancesAnswer::NoDefinition
    } else {
        def_instances_answer_f(lx_p0, &lx_p0.in_definition_p)
    }
}

/// ```prism
/// ValuedKeyAt: unbounded fn Lx, Text, Range, [Arg] -> Text
/// ```
pub fn valued_key_at_f(lx_p0: &crate::lower::Lx, qk_p1: &crate::prelude::Text, callee_span_p2: &crate::syntax::Range, args_p3: &crate::prelude::Array<crate::syntax::Arg>) -> crate::prelude::Text {
    match crate::prelude::get(&lx_p0.g_p.vals_p, qk_p1) {
        ::std::option::Option::Some(v_p4) => match valued_types_o(lx_p0, &v_p4, callee_span_p2, args_p3) {
            ::std::option::Option::Some(types_p5) => valued_key_f(qk_p1, &types_p5),
            ::std::option::Option::None => crate::prelude::Text::lit(""),
        },
        ::std::option::Option::None => crate::prelude::Text::lit(""),
    }
}

/// The step machine of `ValuedKeyAt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ValuedKeyAt: unbounded fn Lx, Text, Range, [Arg] -> Text
/// ```
pub struct ValuedKeyAt {
    pub lx_p0: crate::lower::Lx,
    pub qk_p1: crate::prelude::Text,
    pub callee_span_p2: crate::syntax::Range,
    pub args_p3: crate::prelude::Array<crate::syntax::Arg>,
}

impl ::prism_rtl::Job<crate::prelude::Text> for ValuedKeyAt {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let lx_p0 = &self.lx_p0;
        let qk_p1 = &self.qk_p1;
        let callee_span_p2 = &self.callee_span_p2;
        let args_p3 = &self.args_p3;
        match crate::prelude::get(&lx_p0.g_p.vals_p, qk_p1) {
            ::std::option::Option::Some(v_p4) => {
                let args_p3x = args_p3.clone();
                let callee_span_p2x = callee_span_p2.clone();
                let lx_p0x = lx_p0.clone();
                let qk_p1x = qk_p1.clone();
                crate::prelude::call_then(start_valued_types_o(lx_p0x.clone(), v_p4.clone(), callee_span_p2x.clone(), args_p3x.clone()), move |valued_types_o_44475: ::std::option::Option<crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>>| match valued_types_o_44475 {
                    ::std::option::Option::Some(types_p5) => ::prism_rtl::Turn::Finished(valued_key_f(&qk_p1x, &types_p5)),
                    ::std::option::Option::None => ::prism_rtl::Turn::Finished(crate::prelude::Text::lit("")),
                })
            },
            ::std::option::Option::None => ::prism_rtl::Turn::Finished(crate::prelude::Text::lit("")),
        }
    }
}

/// `Start ValuedKeyAt, x`: what the function value is when passed to `@Run`.
pub fn start_valued_key_at_f(lx_p0: crate::lower::Lx, qk_p1: crate::prelude::Text, callee_span_p2: crate::syntax::Range, args_p3: crate::prelude::Array<crate::syntax::Arg>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(ValuedKeyAt { lx_p0, qk_p1, callee_span_p2, args_p3 })
}

/// ```prism
/// ValInfoAt: fn Lx, ValInfo -> ValInfo
/// ```
pub fn val_info_at_f(lx_p0: &crate::lower::Lx, v_p1: &crate::check::env::ValInfo) -> crate::check::env::ValInfo {
    let scheme_p2 = {
        let mut this: crate::check::types::Scheme = v_p1.scheme_p.clone();
        this.ty_p = crate::lower::subst_ty_f(lx_p0, &this.ty_p);
        this
    };
    let mut this: crate::check::env::ValInfo = v_p1.clone();
    this.scheme_p = scheme_p2.clone();
    this
}

/// ```prism
/// LetValues: unbounded fn Def -> [Expr]
/// ```
pub fn let_values_f(d_p0: &crate::check::env::Def) -> crate::prelude::Array<crate::syntax::Expr> {
    let own_p1 = match &d_p0.body_p {
        crate::check::env::DefBody::DbFn(clauses_p2) => crate::prelude::run_to_end(crate::prelude::fold_job(clauses_p2.clone(), crate::prelude::Array::new(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::syntax::Expr>, crate::syntax::decls::FnClause)| crate::prelude::entered(crate::prelude::once_job(move || {
            let acc_p3 = p0;
            let c_p4 = p1;
            crate::prelude::call_then(start_body_lets_f(c_p4.body_p.clone()), move |body_lets_f_45141: crate::prelude::Array<crate::syntax::Expr>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_p3, &body_lets_f_45141)))
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::syntax::Expr>, crate::syntax::decls::FnClause)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::syntax::Expr>>>>)),
        crate::check::env::DefBody::DbMethod(clauses_p5, _, _) => crate::prelude::run_to_end(crate::prelude::fold_job(clauses_p5.clone(), crate::prelude::Array::new(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::syntax::Expr>, crate::syntax::decls::FnClause)| crate::prelude::entered(crate::prelude::once_job(move || {
            let acc_p6 = p0;
            let c_p7 = p1;
            crate::prelude::call_then(start_body_lets_f(c_p7.body_p.clone()), move |body_lets_f_45243: crate::prelude::Array<crate::syntax::Expr>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_p6, &body_lets_f_45243)))
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::syntax::Expr>, crate::syntax::decls::FnClause)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::syntax::Expr>>>>)),
        crate::check::env::DefBody::DbDefault(clauses_p8, _) => crate::prelude::run_to_end(crate::prelude::fold_job(clauses_p8.clone(), crate::prelude::Array::new(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::syntax::Expr>, crate::syntax::decls::FnClause)| crate::prelude::entered(crate::prelude::once_job(move || {
            let acc_p9 = p0;
            let c_pa = p1;
            crate::prelude::call_then(start_body_lets_f(c_pa.body_p.clone()), move |body_lets_f_45338: crate::prelude::Array<crate::syntax::Expr>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_p9, &body_lets_f_45338)))
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::syntax::Expr>, crate::syntax::decls::FnClause)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::syntax::Expr>>>>)),
        crate::check::env::DefBody::DbWidget(w_pb) => statement_lets_f(&w_pb.body_p.stmts_p),
        _ => crate::prelude::Array::new(),
    };
    crate::prelude::run_to_end(crate::prelude::fold_job(crate::lower::expr::def_exprs_f(d_p0), own_p1.clone(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::syntax::Expr>, crate::syntax::Expr)| crate::prelude::entered(crate::prelude::once_job(move || {
        let acc_pc = p0;
        let e_pd = p1;
        crate::prelude::fold_job(blocks_held_f(&e_pd), acc_pc.clone(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::syntax::Expr>, crate::syntax::Block)| crate::prelude::entered(crate::prelude::once_job(move || {
            let acc2_pe = p0;
            let b_pf = p1;
            crate::prelude::call_then(start_statement_lets_f(b_pf.stmts_p.clone()), move |statement_lets_f_45515: crate::prelude::Array<crate::syntax::Expr>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc2_pe, &statement_lets_f_45515)))
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::syntax::Expr>, crate::syntax::Block)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::syntax::Expr>>>>).cycle()
    }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::syntax::Expr>, crate::syntax::Expr)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::syntax::Expr>>>>))
}

/// The step machine of `LetValues`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LetValues: unbounded fn Def -> [Expr]
/// ```
pub struct LetValues {
    pub d_p0: crate::check::env::Def,
}

impl ::prism_rtl::Job<crate::prelude::Array<crate::syntax::Expr>> for LetValues {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<crate::syntax::Expr>> {
        let d_p0 = &self.d_p0;
        let d_p0z = d_p0.clone();
        let k_let45052 = move |v45052: crate::prelude::Array<crate::syntax::Expr>| {
            let own_p1 = v45052;
            crate::prelude::call_then(crate::lower::expr::start_def_exprs_f(d_p0z.clone()), move |def_exprs_f_45436: crate::prelude::Array<crate::syntax::Expr>| crate::prelude::fold_job(def_exprs_f_45436, own_p1.clone(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::syntax::Expr>, crate::syntax::Expr)| crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_pc = p0;
                let e_pd = p1;
                crate::prelude::fold_job(blocks_held_f(&e_pd), acc_pc.clone(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::syntax::Expr>, crate::syntax::Block)| crate::prelude::entered(crate::prelude::once_job(move || {
                    let acc2_pe = p0;
                    let b_pf = p1;
                    crate::prelude::call_then(start_statement_lets_f(b_pf.stmts_p.clone()), move |statement_lets_f_45515: crate::prelude::Array<crate::syntax::Expr>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc2_pe, &statement_lets_f_45515)))
                }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::syntax::Expr>, crate::syntax::Block)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::syntax::Expr>>>>).cycle()
            }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::syntax::Expr>, crate::syntax::Expr)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::syntax::Expr>>>>).cycle())
        };
        match d_p0.body_p.clone() {
            crate::check::env::DefBody::DbFn(clauses_p2) => crate::prelude::call_value(crate::prelude::fold_job(clauses_p2.clone(), crate::prelude::Array::new(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::syntax::Expr>, crate::syntax::decls::FnClause)| crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_p3 = p0;
                let c_p4 = p1;
                crate::prelude::call_then(start_body_lets_f(c_p4.body_p.clone()), move |body_lets_f_45141: crate::prelude::Array<crate::syntax::Expr>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_p3, &body_lets_f_45141)))
            }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::syntax::Expr>, crate::syntax::decls::FnClause)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::syntax::Expr>>>>), move |fold_45098: crate::prelude::Array<crate::syntax::Expr>| k_let45052(fold_45098)),
            crate::check::env::DefBody::DbMethod(clauses_p5, _, _) => crate::prelude::call_value(crate::prelude::fold_job(clauses_p5.clone(), crate::prelude::Array::new(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::syntax::Expr>, crate::syntax::decls::FnClause)| crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_p6 = p0;
                let c_p7 = p1;
                crate::prelude::call_then(start_body_lets_f(c_p7.body_p.clone()), move |body_lets_f_45243: crate::prelude::Array<crate::syntax::Expr>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_p6, &body_lets_f_45243)))
            }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::syntax::Expr>, crate::syntax::decls::FnClause)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::syntax::Expr>>>>), move |fold_45200: crate::prelude::Array<crate::syntax::Expr>| k_let45052(fold_45200)),
            crate::check::env::DefBody::DbDefault(clauses_p8, _) => crate::prelude::call_value(crate::prelude::fold_job(clauses_p8.clone(), crate::prelude::Array::new(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::syntax::Expr>, crate::syntax::decls::FnClause)| crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_p9 = p0;
                let c_pa = p1;
                crate::prelude::call_then(start_body_lets_f(c_pa.body_p.clone()), move |body_lets_f_45338: crate::prelude::Array<crate::syntax::Expr>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_p9, &body_lets_f_45338)))
            }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::syntax::Expr>, crate::syntax::decls::FnClause)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::syntax::Expr>>>>), move |fold_45295: crate::prelude::Array<crate::syntax::Expr>| k_let45052(fold_45295)),
            crate::check::env::DefBody::DbWidget(w_pb) => crate::prelude::call_then(start_statement_lets_f(w_pb.body_p.stmts_p.clone()), move |statement_lets_f_45375: crate::prelude::Array<crate::syntax::Expr>| k_let45052(statement_lets_f_45375)),
            _ => k_let45052(crate::prelude::Array::new()),
        }
    }
}

/// `Start LetValues, x`: what the function value is when passed to `@Run`.
pub fn start_let_values_f(d_p0: crate::check::env::Def) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::syntax::Expr>>> {
    ::std::rc::Rc::new(LetValues { d_p0 })
}

/// ```prism
/// BodyLets: unbounded fn FnBody -> [Expr]
/// ```
pub fn body_lets_f(fn_body0: &crate::syntax::decls::FnBody) -> crate::prelude::Array<crate::syntax::Expr> {
    match fn_body0 {
        crate::syntax::decls::FnBody::BodyExpr(_) => crate::prelude::Array::new(),
        crate::syntax::decls::FnBody::BodyBlock(b_p0) => statement_lets_f(&b_p0.stmts_p),
    }
}

/// The step machine of `BodyLets`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BodyLets: unbounded fn FnBody -> [Expr]
/// ```
pub struct BodyLets {
    pub fn_body0: crate::syntax::decls::FnBody,
}

impl ::prism_rtl::Job<crate::prelude::Array<crate::syntax::Expr>> for BodyLets {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<crate::syntax::Expr>> {
        let fn_body0 = &self.fn_body0;
        match fn_body0 {
            crate::syntax::decls::FnBody::BodyExpr(_) => ::prism_rtl::Turn::Finished(crate::prelude::Array::new()),
            crate::syntax::decls::FnBody::BodyBlock(b_p0) => ::prism_rtl::Turn::More(::std::rc::Rc::new(StatementLets { stmts_p0: b_p0.stmts_p.clone() })),
        }
    }
}

/// `Start BodyLets, x`: what the function value is when passed to `@Run`.
pub fn start_body_lets_f(fn_body0: crate::syntax::decls::FnBody) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::syntax::Expr>>> {
    ::std::rc::Rc::new(BodyLets { fn_body0 })
}

/// ```prism
/// StatementLets: unbounded fn [Stmt] -> [Expr]
/// ```
pub fn statement_lets_f(stmts_p0: &crate::prelude::Array<crate::syntax::Stmt>) -> crate::prelude::Array<crate::syntax::Expr> {
    crate::prelude::run_to_end(crate::prelude::fold_job(stmts_p0.clone(), crate::prelude::Array::new(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::syntax::Expr>, crate::syntax::Stmt)| crate::prelude::entered(crate::prelude::once_job(move || {
        let acc_p1 = p0;
        let s_p2 = p1;
        match &s_p2.kind_p {
            crate::syntax::StmtKind::SLet(_, _, e_p3) => ::prism_rtl::Turn::Finished(crate::prelude::push(&acc_p1, e_p3)),
            crate::syntax::StmtKind::SSet(_, e_p4) => ::prism_rtl::Turn::Finished(crate::prelude::push(&acc_p1, e_p4)),
            crate::syntax::StmtKind::SFn(f_p5) => {
                let f_p5x = f_p5.clone();
                crate::prelude::call_then(start_body_lets_f(f_p5x.body_p.clone()), move |body_lets_f_46053: crate::prelude::Array<crate::syntax::Expr>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_p1, &body_lets_f_46053)))
            },
            crate::syntax::StmtKind::SWidget(w_p6) => {
                let w_p6x = w_p6.clone();
                crate::prelude::call_then(start_statement_lets_f(w_p6x.body_p.stmts_p.clone()), move |statement_lets_f_46098: crate::prelude::Array<crate::syntax::Expr>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_p1, &statement_lets_f_46098)))
            },
            crate::syntax::StmtKind::SWhile(_, b_p7) => {
                let b_p7x = b_p7.clone();
                crate::prelude::call_then(start_statement_lets_f(b_p7x.stmts_p.clone()), move |statement_lets_f_46161: crate::prelude::Array<crate::syntax::Expr>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_p1, &statement_lets_f_46161)))
            },
            _ => ::prism_rtl::Turn::Finished(acc_p1.clone()),
        }
    }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::syntax::Expr>, crate::syntax::Stmt)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::syntax::Expr>>>>))
}

/// The step machine of `StatementLets`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// StatementLets: unbounded fn [Stmt] -> [Expr]
/// ```
pub struct StatementLets {
    pub stmts_p0: crate::prelude::Array<crate::syntax::Stmt>,
}

impl ::prism_rtl::Job<crate::prelude::Array<crate::syntax::Expr>> for StatementLets {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<crate::syntax::Expr>> {
        let stmts_p0 = &self.stmts_p0;
        crate::prelude::fold_job(stmts_p0.clone(), crate::prelude::Array::new(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::syntax::Expr>, crate::syntax::Stmt)| crate::prelude::entered(crate::prelude::once_job(move || {
            let acc_p1 = p0;
            let s_p2 = p1;
            match &s_p2.kind_p {
                crate::syntax::StmtKind::SLet(_, _, e_p3) => ::prism_rtl::Turn::Finished(crate::prelude::push(&acc_p1, e_p3)),
                crate::syntax::StmtKind::SSet(_, e_p4) => ::prism_rtl::Turn::Finished(crate::prelude::push(&acc_p1, e_p4)),
                crate::syntax::StmtKind::SFn(f_p5) => {
                    let f_p5x = f_p5.clone();
                    crate::prelude::call_then(start_body_lets_f(f_p5x.body_p.clone()), move |body_lets_f_46053: crate::prelude::Array<crate::syntax::Expr>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_p1, &body_lets_f_46053)))
                },
                crate::syntax::StmtKind::SWidget(w_p6) => {
                    let w_p6x = w_p6.clone();
                    crate::prelude::call_then(start_statement_lets_f(w_p6x.body_p.stmts_p.clone()), move |statement_lets_f_46098: crate::prelude::Array<crate::syntax::Expr>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_p1, &statement_lets_f_46098)))
                },
                crate::syntax::StmtKind::SWhile(_, b_p7) => {
                    let b_p7x = b_p7.clone();
                    crate::prelude::call_then(start_statement_lets_f(b_p7x.stmts_p.clone()), move |statement_lets_f_46161: crate::prelude::Array<crate::syntax::Expr>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_p1, &statement_lets_f_46161)))
                },
                _ => ::prism_rtl::Turn::Finished(acc_p1.clone()),
            }
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::syntax::Expr>, crate::syntax::Stmt)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::syntax::Expr>>>>).cycle()
    }
}

/// `Start StatementLets, x`: what the function value is when passed to `@Run`.
pub fn start_statement_lets_f(stmts_p0: crate::prelude::Array<crate::syntax::Stmt>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::syntax::Expr>>> {
    ::std::rc::Rc::new(StatementLets { stmts_p0 })
}

/// ```prism
/// BlocksHeld: fn Expr -> [Block]
/// ```
pub fn blocks_held_f(e_p0: &crate::syntax::Expr) -> crate::prelude::Array<crate::syntax::Block> {
    'm46336: {
        let scrutinee = &*e_p0.kind_p;
        if let crate::syntax::ExprKind::ELambda(_, m46336_0_1) = scrutinee && let crate::syntax::LambdaBody::LbBlock(b_p1) = &**m46336_0_1 {
            break 'm46336 crate::prelude::Array::from(vec![b_p1.clone()]);
        }
        if let crate::syntax::ExprKind::EIf(_, yes_p2, ::std::option::Option::Some(no_p3)) = scrutinee {
            break 'm46336 crate::prelude::Array::from(vec![yes_p2.clone(), no_p3.clone()]);
        }
        if let crate::syntax::ExprKind::EIf(_, yes_p4, ::std::option::Option::None) = scrutinee {
            break 'm46336 crate::prelude::Array::from(vec![yes_p4.clone()]);
        }
        if let crate::syntax::ExprKind::EMatch(_, arms_p5) = scrutinee {
            break 'm46336 crate::prelude::each(arms_p5, &(|a_p6: &crate::syntax::Arm| a_p6.body_p.clone()));
        }
        if let crate::syntax::ExprKind::ERebuild(_, b_p7) = scrutinee {
            break 'm46336 crate::prelude::Array::from(vec![b_p7.clone()]);
        }
        if let crate::syntax::ExprKind::EFor(_, _, b_p8) = scrutinee {
            break 'm46336 crate::prelude::Array::from(vec![b_p8.clone()]);
        }
        if let crate::syntax::ExprKind::EGiven(b_p9) = scrutinee {
            break 'm46336 crate::prelude::Array::from(vec![b_p9.clone()]);
        }
        if let crate::syntax::ExprKind::EUpdate(_, b_pa) = scrutinee {
            break 'm46336 crate::prelude::Array::from(vec![b_pa.clone()]);
        }
        if let crate::syntax::ExprKind::EWidgetBlock(b_pb) = scrutinee {
            break 'm46336 crate::prelude::Array::from(vec![b_pb.clone()]);
        }
        crate::prelude::Array::new()
    }
}

/// ```prism
/// ValueWidgetsIn: unbounded fn Lx, Expr -> [((Text, [((Text, Ty))]))]
/// ```
pub fn value_widgets_in_f(lx_p0: &crate::lower::Lx, e_p1: &crate::syntax::Expr) -> crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)> {
    'm46821: {
        let scrutinee = &*e_p1.kind_p;
        if let crate::syntax::ExprKind::ECall(c_p2, args_p3, _, _) = scrutinee {
            break 'm46821 {
                let qk_p4 = blueprint_qk_f(lx_p0, &**c_p2);
                let hosts_p5 = ((&qk_p4 == &crate::prelude::Text::lit("Prelude.@HostDocument")) || (&qk_p4 == &crate::prelude::Text::lit("Prelude.@HostSome"))) || (&qk_p4 == &crate::prelude::Text::lit("Prelude.@HostList"));
                let applies_p6 = match crate::prelude::get(&lx_p0.g_p.vals_p, &qk_p4) {
                    ::std::option::Option::Some(v_p7) => crate::lower::node_::def::is_widget_ty_f(&crate::lower::node_::static_::widget_result_of_f(&v_p7.scheme_p.ty_p)),
                    ::std::option::Option::None => false,
                };
                if hosts_p5 {
                    crate::prelude::run_to_end(crate::prelude::fold_job(crate::prelude::drop(args_p3, &crate::prelude::Nat::from(1u32)), crate::prelude::Array::new(), {
                        let lx_p0x = lx_p0.clone();
                        ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>, crate::syntax::Arg)| {
                            let lx_p0xy = lx_p0x.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let acc_p8 = p0;
                                let a_p9 = p1;
                                crate::prelude::call_then(start_value_widgets_at_f(lx_p0xy.clone(), a_p9.value_p.clone()), move |value_widgets_at_f_47204: crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_p8, &value_widgets_at_f_47204)))
                            }))
                        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>, crate::syntax::Arg)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>>>>
                    }))
                } else {
                    if applies_p6 {
                        if calls_itself_f(lx_p0, &qk_p4) {
                            crate::prelude::run_to_end(crate::prelude::fold_job(args_p3.clone(), crate::prelude::Array::new(), {
                                let lx_p0x = lx_p0.clone();
                                ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>, crate::syntax::Arg)| {
                                    let lx_p0xy = lx_p0x.clone();
                                    crate::prelude::entered(crate::prelude::once_job(move || {
                                        let acc_pa = p0;
                                        let a_pb = p1;
                                        if &crate::lower::types::layer_of_f(&crate::lower::type_at_f(&lx_p0xy, &a_pb.value_p.span_p)) == &crate::lower::types::Layer::LyBlueprint {
                                            crate::prelude::call_then(start_value_widgets_at_f(lx_p0xy.clone(), a_pb.value_p.clone()), move |value_widgets_at_f_47500: crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_pa, &value_widgets_at_f_47500)))
                                        } else {
                                            ::prism_rtl::Turn::Finished(acc_pa.clone())
                                        }
                                    }))
                                }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>, crate::syntax::Arg)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>>>>
                            }))
                        } else {
                            crate::prelude::Array::new()
                        }
                    } else {
                        crate::prelude::run_to_end(crate::prelude::fold_job(args_p3.clone(), crate::prelude::Array::new(), {
                            let lx_p0x = lx_p0.clone();
                            ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>, crate::syntax::Arg)| {
                                let lx_p0xy = lx_p0x.clone();
                                crate::prelude::entered(crate::prelude::once_job(move || {
                                    let acc_pc = p0;
                                    let a_pd = p1;
                                    crate::prelude::call_then(start_value_widgets_at_f(lx_p0xy.clone(), a_pd.value_p.clone()), move |value_widgets_at_f_47604: crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_pc, &value_widgets_at_f_47604)))
                                }))
                            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>, crate::syntax::Arg)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>>>>
                        }))
                    }
                }
            };
        }
        if let crate::syntax::ExprKind::ELambda(_, m46821_1_1) = scrutinee && let crate::syntax::LambdaBody::LbExpr(x_pe) = &**m46821_1_1 {
            break 'm46821 value_widgets_at_f(lx_p0, &**x_pe);
        }
        if let crate::syntax::ExprKind::ELambda(_, m46821_2_1) = scrutinee && let crate::syntax::LambdaBody::LbBlock(b_pf) = &**m46821_2_1 {
            break 'm46821 value_widgets_of_block_f(lx_p0, b_pf);
        }
        if let crate::syntax::ExprKind::EFreeSigil(m46821_3_0, x_pg) = scrutinee && (m46821_3_0 == &crate::prelude::Text::lit("?")) {
            break 'm46821 value_widgets_at_f(lx_p0, &**x_pg);
        }
        if let crate::syntax::ExprKind::ETuple(xs_ph) = scrutinee {
            break 'm46821 crate::prelude::run_to_end(crate::prelude::fold_job(xs_ph.clone(), crate::prelude::Array::new(), {
                let lx_p0x = lx_p0.clone();
                ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>, crate::syntax::Expr)| {
                    let lx_p0xy = lx_p0x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let acc_pi = p0;
                        let x_pj = p1;
                        crate::prelude::call_then(start_value_widgets_at_f(lx_p0xy.clone(), x_pj.clone()), move |value_widgets_at_f_47841: crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_pi, &value_widgets_at_f_47841)))
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>, crate::syntax::Expr)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>>>>
            }));
        }
        if let crate::syntax::ExprKind::EArray(xs_pk) = scrutinee {
            break 'm46821 crate::prelude::run_to_end(crate::prelude::fold_job(xs_pk.clone(), crate::prelude::Array::new(), {
                let lx_p0x = lx_p0.clone();
                ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>, crate::syntax::Expr)| {
                    let lx_p0xy = lx_p0x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let acc_pl = p0;
                        let x_pm = p1;
                        crate::prelude::call_then(start_value_widgets_at_f(lx_p0xy.clone(), x_pm.clone()), move |value_widgets_at_f_47916: crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_pl, &value_widgets_at_f_47916)))
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>, crate::syntax::Expr)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>>>>
            }));
        }
        crate::prelude::Array::new()
    }
}

/// The step machine of `ValueWidgetsIn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ValueWidgetsIn: unbounded fn Lx, Expr -> [((Text, [((Text, Ty))]))]
/// ```
pub struct ValueWidgetsIn {
    pub lx_p0: crate::lower::Lx,
    pub e_p1: crate::syntax::Expr,
}

impl ::prism_rtl::Job<crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>> for ValueWidgetsIn {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>> {
        let lx_p0 = &self.lx_p0;
        let e_p1 = &self.e_p1;
        'm46821: {
            let scrutinee = &*e_p1.kind_p;
            if let crate::syntax::ExprKind::ECall(c_p2, args_p3, _, _) = scrutinee {
                break 'm46821 {
                    let qk_p4 = blueprint_qk_f(lx_p0, &**c_p2);
                    let hosts_p5 = ((&qk_p4 == &crate::prelude::Text::lit("Prelude.@HostDocument")) || (&qk_p4 == &crate::prelude::Text::lit("Prelude.@HostSome"))) || (&qk_p4 == &crate::prelude::Text::lit("Prelude.@HostList"));
                    let applies_p6 = match crate::prelude::get(&lx_p0.g_p.vals_p, &qk_p4) {
                        ::std::option::Option::Some(v_p7) => crate::lower::node_::def::is_widget_ty_f(&crate::lower::node_::static_::widget_result_of_f(&v_p7.scheme_p.ty_p)),
                        ::std::option::Option::None => false,
                    };
                    if hosts_p5 {
                        crate::prelude::fold_job(crate::prelude::drop(args_p3, &crate::prelude::Nat::from(1u32)), crate::prelude::Array::new(), {
                            let lx_p0x = lx_p0.clone();
                            ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>, crate::syntax::Arg)| {
                                let lx_p0xy = lx_p0x.clone();
                                crate::prelude::entered(crate::prelude::once_job(move || {
                                    let acc_p8 = p0;
                                    let a_p9 = p1;
                                    crate::prelude::call_then(start_value_widgets_at_f(lx_p0xy.clone(), a_p9.value_p.clone()), move |value_widgets_at_f_47204: crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_p8, &value_widgets_at_f_47204)))
                                }))
                            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>, crate::syntax::Arg)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>>>>
                        }).cycle()
                    } else {
                        if applies_p6 {
                            {
                                let args_p3x = args_p3.clone();
                                let lx_p0x = lx_p0.clone();
                                crate::prelude::call_then(start_calls_itself_f(lx_p0x.clone(), qk_p4.clone()), move |calls_itself_f_47385: bool| if calls_itself_f_47385 {
                                    crate::prelude::fold_job(args_p3x.clone(), crate::prelude::Array::new(), {
                                        let lx_p0xx = lx_p0x.clone();
                                        ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>, crate::syntax::Arg)| {
                                            let lx_p0xxy = lx_p0xx.clone();
                                            crate::prelude::entered(crate::prelude::once_job(move || {
                                                let acc_pa = p0;
                                                let a_pb = p1;
                                                if &crate::lower::types::layer_of_f(&crate::lower::type_at_f(&lx_p0xxy, &a_pb.value_p.span_p)) == &crate::lower::types::Layer::LyBlueprint {
                                                    crate::prelude::call_then(start_value_widgets_at_f(lx_p0xxy.clone(), a_pb.value_p.clone()), move |value_widgets_at_f_47500: crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_pa, &value_widgets_at_f_47500)))
                                                } else {
                                                    ::prism_rtl::Turn::Finished(acc_pa.clone())
                                                }
                                            }))
                                        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>, crate::syntax::Arg)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>>>>
                                    }).cycle()
                                } else {
                                    ::prism_rtl::Turn::Finished(crate::prelude::Array::new())
                                })
                            }
                        } else {
                            crate::prelude::fold_job(args_p3.clone(), crate::prelude::Array::new(), {
                                let lx_p0x = lx_p0.clone();
                                ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>, crate::syntax::Arg)| {
                                    let lx_p0xy = lx_p0x.clone();
                                    crate::prelude::entered(crate::prelude::once_job(move || {
                                        let acc_pc = p0;
                                        let a_pd = p1;
                                        crate::prelude::call_then(start_value_widgets_at_f(lx_p0xy.clone(), a_pd.value_p.clone()), move |value_widgets_at_f_47604: crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_pc, &value_widgets_at_f_47604)))
                                    }))
                                }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>, crate::syntax::Arg)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>>>>
                            }).cycle()
                        }
                    }
                };
            }
            if let crate::syntax::ExprKind::ELambda(_, m46821_1_1) = scrutinee && let crate::syntax::LambdaBody::LbExpr(x_pe) = &**m46821_1_1 {
                break 'm46821 ::prism_rtl::Turn::More(::std::rc::Rc::new(ValueWidgetsAt { lx_p0: lx_p0.clone(), e_p1: (**x_pe).clone() }));
            }
            if let crate::syntax::ExprKind::ELambda(_, m46821_2_1) = scrutinee && let crate::syntax::LambdaBody::LbBlock(b_pf) = &**m46821_2_1 {
                break 'm46821 ::prism_rtl::Turn::More(::std::rc::Rc::new(ValueWidgetsOfBlock { lx_p0: lx_p0.clone(), b_p1: b_pf.clone() }));
            }
            if let crate::syntax::ExprKind::EFreeSigil(m46821_3_0, x_pg) = scrutinee && (m46821_3_0 == &crate::prelude::Text::lit("?")) {
                break 'm46821 ::prism_rtl::Turn::More(::std::rc::Rc::new(ValueWidgetsAt { lx_p0: lx_p0.clone(), e_p1: (**x_pg).clone() }));
            }
            if let crate::syntax::ExprKind::ETuple(xs_ph) = scrutinee {
                break 'm46821 crate::prelude::fold_job(xs_ph.clone(), crate::prelude::Array::new(), {
                    let lx_p0x = lx_p0.clone();
                    ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>, crate::syntax::Expr)| {
                        let lx_p0xy = lx_p0x.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let acc_pi = p0;
                            let x_pj = p1;
                            crate::prelude::call_then(start_value_widgets_at_f(lx_p0xy.clone(), x_pj.clone()), move |value_widgets_at_f_47841: crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_pi, &value_widgets_at_f_47841)))
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>, crate::syntax::Expr)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>>>>
                }).cycle();
            }
            if let crate::syntax::ExprKind::EArray(xs_pk) = scrutinee {
                break 'm46821 crate::prelude::fold_job(xs_pk.clone(), crate::prelude::Array::new(), {
                    let lx_p0x = lx_p0.clone();
                    ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>, crate::syntax::Expr)| {
                        let lx_p0xy = lx_p0x.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let acc_pl = p0;
                            let x_pm = p1;
                            crate::prelude::call_then(start_value_widgets_at_f(lx_p0xy.clone(), x_pm.clone()), move |value_widgets_at_f_47916: crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_pl, &value_widgets_at_f_47916)))
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>, crate::syntax::Expr)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>>>>
                }).cycle();
            }
            ::prism_rtl::Turn::Finished(crate::prelude::Array::new())
        }
    }
}

/// `Start ValueWidgetsIn, x`: what the function value is when passed to `@Run`.
pub fn start_value_widgets_in_f(lx_p0: crate::lower::Lx, e_p1: crate::syntax::Expr) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>>> {
    ::std::rc::Rc::new(ValueWidgetsIn { lx_p0, e_p1 })
}

/// ```prism
/// CallsItself: unbounded fn Lx, Text -> Bool
/// ```
pub fn calls_itself_f(lx_p0: &crate::lower::Lx, qk_p1: &crate::prelude::Text) -> bool {
    match crate::prelude::get(&lx_p0.g_p.vals_p, qk_p1) {
        ::std::option::Option::None => false,
        ::std::option::Option::Some(v_p2) => {
            let lxv_p3 = in_module_f(lx_p0, &v_p2.file_p, &v_p2.home_p);
            crate::prelude::run_to_end(crate::prelude::fold_job(crate::lower::jobs::clauses_of_f(&lx_p0.g_p, qk_p1), false, {
                let lxv_p3x = lxv_p3.clone();
                let qk_p1x = qk_p1.clone();
                ::std::rc::Rc::new(move |(p0, p1): (bool, crate::syntax::decls::FnClause)| {
                    let lxv_p3xy = lxv_p3x.clone();
                    let qk_p1xy = qk_p1x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let found_p4 = p0;
                        let c_p5 = p1;
                        if found_p4 {
                            ::prism_rtl::Turn::Finished(true)
                        } else {
                            crate::prelude::call_then(crate::check::typed::print::start_body_exprs_f(c_p5.body_p.clone()), move |body_exprs_f_48229: crate::prelude::Array<crate::syntax::Expr>| ::prism_rtl::Turn::Finished(crate::prelude::fold(&body_exprs_f_48229, &false, &(|found2_p6: &bool, x_p7: &crate::syntax::Expr| *found2_p6 || match &*x_p7.kind_p {
                                crate::syntax::ExprKind::ECall(callee_p8, _, _, _) => &blueprint_qk_f(&lxv_p3xy, &**callee_p8) == &qk_p1xy,
                                _ => false,
                            }))))
                        }
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::syntax::decls::FnClause)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
            }))
        },
    }
}

/// The step machine of `CallsItself`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CallsItself: unbounded fn Lx, Text -> Bool
/// ```
pub struct CallsItself {
    pub lx_p0: crate::lower::Lx,
    pub qk_p1: crate::prelude::Text,
}

impl ::prism_rtl::Job<bool> for CallsItself {
    fn cycle(&self) -> ::prism_rtl::Turn<bool> {
        let lx_p0 = &self.lx_p0;
        let qk_p1 = &self.qk_p1;
        match crate::prelude::get(&lx_p0.g_p.vals_p, qk_p1) {
            ::std::option::Option::None => ::prism_rtl::Turn::Finished(false),
            ::std::option::Option::Some(v_p2) => {
                let lxv_p3 = in_module_f(lx_p0, &v_p2.file_p, &v_p2.home_p);
                crate::prelude::fold_job(crate::lower::jobs::clauses_of_f(&lx_p0.g_p, qk_p1), false, {
                    let lxv_p3x = lxv_p3.clone();
                    let qk_p1x = qk_p1.clone();
                    ::std::rc::Rc::new(move |(p0, p1): (bool, crate::syntax::decls::FnClause)| {
                        let lxv_p3xy = lxv_p3x.clone();
                        let qk_p1xy = qk_p1x.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let found_p4 = p0;
                            let c_p5 = p1;
                            if found_p4 {
                                ::prism_rtl::Turn::Finished(true)
                            } else {
                                crate::prelude::call_then(crate::check::typed::print::start_body_exprs_f(c_p5.body_p.clone()), move |body_exprs_f_48229: crate::prelude::Array<crate::syntax::Expr>| ::prism_rtl::Turn::Finished(crate::prelude::fold(&body_exprs_f_48229, &false, &(|found2_p6: &bool, x_p7: &crate::syntax::Expr| *found2_p6 || match &*x_p7.kind_p {
                                    crate::syntax::ExprKind::ECall(callee_p8, _, _, _) => &blueprint_qk_f(&lxv_p3xy, &**callee_p8) == &qk_p1xy,
                                    _ => false,
                                }))))
                            }
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::syntax::decls::FnClause)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
                }).cycle()
            },
        }
    }
}

/// `Start CallsItself, x`: what the function value is when passed to `@Run`.
pub fn start_calls_itself_f(lx_p0: crate::lower::Lx, qk_p1: crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>> {
    ::std::rc::Rc::new(CallsItself { lx_p0, qk_p1 })
}

/// ```prism
/// ValueWidgetsAt: unbounded fn Lx, Expr -> [((Text, [((Text, Ty))]))]
/// ```
pub fn value_widgets_at_f(lx_p0: &crate::lower::Lx, e_p1: &crate::syntax::Expr) -> crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)> {
    match &*e_p1.kind_p {
        crate::syntax::ExprKind::EGroup(x_p2) => value_widgets_at_f(lx_p0, &**x_p2),
        crate::syntax::ExprKind::EMatch(_, arms_p3) => crate::prelude::run_to_end(crate::prelude::fold_job(arms_p3.clone(), crate::prelude::Array::new(), {
            let lx_p0x = lx_p0.clone();
            ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>, crate::syntax::Arm)| {
                let lx_p0xy = lx_p0x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let acc_p4 = p0;
                    let a_p5 = p1;
                    crate::prelude::call_then(start_value_widgets_of_block_f(lx_p0xy.clone(), a_p5.body_p.clone()), move |value_widgets_of_block_f_48696: crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_p4, &value_widgets_of_block_f_48696)))
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>, crate::syntax::Arm)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>>>>
        })),
        crate::syntax::ExprKind::EIf(_, yes_p6, ::std::option::Option::Some(no_p7)) => crate::prelude::append(&value_widgets_of_block_f(lx_p0, yes_p6), &value_widgets_of_block_f(lx_p0, no_p7)),
        crate::syntax::ExprKind::EIf(_, yes_p8, ::std::option::Option::None) => value_widgets_of_block_f(lx_p0, yes_p8),
        crate::syntax::ExprKind::ECall(c_p9, args_pa, _, _) => crate::prelude::run_to_end(crate::prelude::fold_job(args_pa.clone(), placed_widget_f(lx_p0, &blueprint_qk_f(lx_p0, &**c_p9), &c_p9.span_p, args_pa), {
            let lx_p0x = lx_p0.clone();
            ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>, crate::syntax::Arg)| {
                let lx_p0xy = lx_p0x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let acc_pb = p0;
                    let a_pc = p1;
                    if (&crate::lower::types::layer_of_f(&crate::lower::type_at_f(&lx_p0xy, &a_pc.value_p.span_p)) == &crate::lower::types::Layer::LyBlueprint) || crate::lower::node_::static_::is_widget_fn_ty_f(&crate::lower::types::peel_f(&crate::lower::type_at_f(&lx_p0xy, &a_pc.value_p.span_p))) {
                        crate::prelude::call_then(start_value_widgets_at_f(lx_p0xy.clone(), a_pc.value_p.clone()), move |value_widgets_at_f_49357: crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_pb, &value_widgets_at_f_49357)))
                    } else {
                        ::prism_rtl::Turn::Finished(acc_pb.clone())
                    }
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>, crate::syntax::Arg)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>>>>
        })),
        crate::syntax::ExprKind::EName(_) => placed_widget_f(lx_p0, &blueprint_qk_f(lx_p0, e_p1), &e_p1.span_p, &crate::prelude::Array::new()),
        crate::syntax::ExprKind::EField(_, ignore2_pd, ignore3_pe) => placed_widget_f(lx_p0, &blueprint_qk_f(lx_p0, e_p1), &e_p1.span_p, &crate::prelude::Array::new()),
        _ => crate::prelude::Array::new(),
    }
}

/// The step machine of `ValueWidgetsAt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ValueWidgetsAt: unbounded fn Lx, Expr -> [((Text, [((Text, Ty))]))]
/// ```
pub struct ValueWidgetsAt {
    pub lx_p0: crate::lower::Lx,
    pub e_p1: crate::syntax::Expr,
}

impl ::prism_rtl::Job<crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>> for ValueWidgetsAt {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>> {
        let lx_p0 = &self.lx_p0;
        let e_p1 = &self.e_p1;
        match &*e_p1.kind_p {
            crate::syntax::ExprKind::EGroup(x_p2) => ::prism_rtl::Turn::More(::std::rc::Rc::new(ValueWidgetsAt { lx_p0: lx_p0.clone(), e_p1: (**x_p2).clone() })),
            crate::syntax::ExprKind::EMatch(_, arms_p3) => crate::prelude::fold_job(arms_p3.clone(), crate::prelude::Array::new(), {
                let lx_p0x = lx_p0.clone();
                ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>, crate::syntax::Arm)| {
                    let lx_p0xy = lx_p0x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let acc_p4 = p0;
                        let a_p5 = p1;
                        crate::prelude::call_then(start_value_widgets_of_block_f(lx_p0xy.clone(), a_p5.body_p.clone()), move |value_widgets_of_block_f_48696: crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_p4, &value_widgets_of_block_f_48696)))
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>, crate::syntax::Arm)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>>>>
            }).cycle(),
            crate::syntax::ExprKind::EIf(_, yes_p6, ::std::option::Option::Some(no_p7)) => {
                let lx_p0x = lx_p0.clone();
                let no_p7x = no_p7.clone();
                let yes_p6x = yes_p6.clone();
                crate::prelude::call_then(start_value_widgets_of_block_f(lx_p0x.clone(), yes_p6x.clone()), move |value_widgets_of_block_f_48765: crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>| crate::prelude::call_then(start_value_widgets_of_block_f(lx_p0x.clone(), no_p7x.clone()), move |value_widgets_of_block_f_48796: crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>| ::prism_rtl::Turn::Finished(crate::prelude::append(&value_widgets_of_block_f_48765, &value_widgets_of_block_f_48796))))
            },
            crate::syntax::ExprKind::EIf(_, yes_p8, ::std::option::Option::None) => ::prism_rtl::Turn::More(::std::rc::Rc::new(ValueWidgetsOfBlock { lx_p0: lx_p0.clone(), b_p1: yes_p8.clone() })),
            crate::syntax::ExprKind::ECall(c_p9, args_pa, _, _) => {
                let args_pax = args_pa.clone();
                let c_p9x = (**c_p9).clone();
                let lx_p0x = lx_p0.clone();
                crate::prelude::call_then(start_placed_widget_f(lx_p0x.clone(), blueprint_qk_f(&lx_p0x, &c_p9x), c_p9x.span_p.clone(), args_pax.clone()), move |placed_widget_f_49177: crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>| crate::prelude::fold_job(args_pax.clone(), placed_widget_f_49177, {
                    let lx_p0xx = lx_p0x.clone();
                    ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>, crate::syntax::Arg)| {
                        let lx_p0xxy = lx_p0xx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let acc_pb = p0;
                            let a_pc = p1;
                            if (&crate::lower::types::layer_of_f(&crate::lower::type_at_f(&lx_p0xxy, &a_pc.value_p.span_p)) == &crate::lower::types::Layer::LyBlueprint) || crate::lower::node_::static_::is_widget_fn_ty_f(&crate::lower::types::peel_f(&crate::lower::type_at_f(&lx_p0xxy, &a_pc.value_p.span_p))) {
                                crate::prelude::call_then(start_value_widgets_at_f(lx_p0xxy.clone(), a_pc.value_p.clone()), move |value_widgets_at_f_49357: crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_pb, &value_widgets_at_f_49357)))
                            } else {
                                ::prism_rtl::Turn::Finished(acc_pb.clone())
                            }
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>, crate::syntax::Arg)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>>>>
                }).cycle())
            },
            crate::syntax::ExprKind::EName(_) => ::prism_rtl::Turn::More(::std::rc::Rc::new(PlacedWidget { lx_p0: lx_p0.clone(), qk_p1: blueprint_qk_f(lx_p0, e_p1), callee_span_p2: e_p1.span_p.clone(), args_p3: crate::prelude::Array::new() })),
            crate::syntax::ExprKind::EField(_, ignore2_pd, ignore3_pe) => ::prism_rtl::Turn::More(::std::rc::Rc::new(PlacedWidget { lx_p0: lx_p0.clone(), qk_p1: blueprint_qk_f(lx_p0, e_p1), callee_span_p2: e_p1.span_p.clone(), args_p3: crate::prelude::Array::new() })),
            _ => ::prism_rtl::Turn::Finished(crate::prelude::Array::new()),
        }
    }
}

/// `Start ValueWidgetsAt, x`: what the function value is when passed to `@Run`.
pub fn start_value_widgets_at_f(lx_p0: crate::lower::Lx, e_p1: crate::syntax::Expr) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>>> {
    ::std::rc::Rc::new(ValueWidgetsAt { lx_p0, e_p1 })
}

/// ```prism
/// ValueWidgetsOfBlock: unbounded fn Lx, Block -> [((Text, [((Text, Ty))]))]
/// ```
pub fn value_widgets_of_block_f(lx_p0: &crate::lower::Lx, b_p1: &crate::syntax::Block) -> crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)> {
    match &crate::prelude::or(&crate::prelude::index(&b_p1.stmts_p, &crate::syntax::lexer::chars::dec_f(&crate::prelude::len(&b_p1.stmts_p))), &crate::lower::expr::dummy_stmt_l_p()).kind_p {
        crate::syntax::StmtKind::SExpr(x_p2) => value_widgets_at_f(lx_p0, x_p2),
        _ => crate::prelude::Array::new(),
    }
}

/// The step machine of `ValueWidgetsOfBlock`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ValueWidgetsOfBlock: unbounded fn Lx, Block -> [((Text, [((Text, Ty))]))]
/// ```
pub struct ValueWidgetsOfBlock {
    pub lx_p0: crate::lower::Lx,
    pub b_p1: crate::syntax::Block,
}

impl ::prism_rtl::Job<crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>> for ValueWidgetsOfBlock {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>> {
        let lx_p0 = &self.lx_p0;
        let b_p1 = &self.b_p1;
        match &crate::prelude::or(&crate::prelude::index(&b_p1.stmts_p, &crate::syntax::lexer::chars::dec_f(&crate::prelude::len(&b_p1.stmts_p))), &crate::lower::expr::dummy_stmt_l_p()).kind_p {
            crate::syntax::StmtKind::SExpr(x_p2) => ::prism_rtl::Turn::More(::std::rc::Rc::new(ValueWidgetsAt { lx_p0: lx_p0.clone(), e_p1: x_p2.clone() })),
            _ => ::prism_rtl::Turn::Finished(crate::prelude::Array::new()),
        }
    }
}

/// `Start ValueWidgetsOfBlock, x`: what the function value is when passed to `@Run`.
pub fn start_value_widgets_of_block_f(lx_p0: crate::lower::Lx, b_p1: crate::syntax::Block) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>>> {
    ::std::rc::Rc::new(ValueWidgetsOfBlock { lx_p0, b_p1 })
}

/// ```prism
/// PlacedWidget: unbounded fn Lx, Text, Range, [Arg] -> [((Text, [((Text, Ty))]))]
/// ```
pub fn placed_widget_f(lx_p0: &crate::lower::Lx, qk_p1: &crate::prelude::Text, callee_span_p2: &crate::syntax::Range, args_p3: &crate::prelude::Array<crate::syntax::Arg>) -> crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)> {
    match crate::prelude::get(&lx_p0.g_p.vals_p, qk_p1) {
        ::std::option::Option::Some(v_p4) => {
            let defined_p5 = crate::prelude::fold(&lx_p0.g_p.defs_p, &false, &(|f_p7: &bool, d_p8: &crate::check::env::Def| *f_p7 || ((&d_p8.qk_p == qk_p1) && is_widget_def_f(d_p8))));
            let closed_f6 = {
                let v_p4x = v_p4.clone();
                let callee_span_p2x = callee_span_p2.clone();
                let args_p3x = args_p3.clone();
                let qk_p1x = qk_p1.clone();
                ::std::rc::Rc::new(move |(p0, p1): (crate::lower::Lx, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)| {
                    let v_p4xy = v_p4x.clone();
                    let callee_span_p2xy = callee_span_p2x.clone();
                    let args_p3xy = args_p3x.clone();
                    let qk_p1xy = qk_p1x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let lx_at_p9 = p0;
                        let types_pa = p1;
                        crate::prelude::call_then(start_at_let_instantiations_f(lx_at_p9.clone(), types_pa.clone()), move |at_let_instantiations_f_50529: crate::prelude::Array<crate::lower::Lx>| crate::prelude::fold_job(at_let_instantiations_f_50529, crate::prelude::Array::new(), {
                            let v_p4xyx = v_p4xy.clone();
                            let callee_span_p2xyx = callee_span_p2xy.clone();
                            let args_p3xyx = args_p3xy.clone();
                            let qk_p1xyx = qk_p1xy.clone();
                            ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>, crate::lower::Lx)| {
                                let v_p4xyxy = v_p4xyx.clone();
                                let callee_span_p2xyxy = callee_span_p2xyx.clone();
                                let args_p3xyxy = args_p3xyx.clone();
                                let qk_p1xyxy = qk_p1xyx.clone();
                                crate::prelude::entered(crate::prelude::once_job(move || {
                                    let acc_pb = p0;
                                    let lxk_pc = p1;
                                    crate::prelude::call_then(start_valued_types_o(lxk_pc.clone(), v_p4xyxy.clone(), callee_span_p2xyxy.clone(), args_p3xyxy.clone()), move |valued_types_o_50587: ::std::option::Option<crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>>| match valued_types_o_50587 {
                                        ::std::option::Option::Some(closed_pd) => ::prism_rtl::Turn::Finished(crate::prelude::push(&acc_pb, &(qk_p1xyxy.clone(), closed_pd.clone()))),
                                        ::std::option::Option::None => ::prism_rtl::Turn::Finished(acc_pb.clone()),
                                    })
                                }))
                            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>, crate::lower::Lx)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>>>>
                        }).cycle())
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::Lx, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>>>>
            };
            if (defined_p5 && crate::lower::node_::def::is_widget_ty_f(&crate::lower::node_::static_::widget_result_of_f(&v_p4.scheme_p.ty_p))) && !is_value_widget_f(lx_p0, qk_p1) {
                match valued_types_o(lx_p0, &v_p4, callee_span_p2, args_p3) {
                    ::std::option::Option::Some(types_pe) => crate::prelude::run_to_end((&closed_f6)((lx_p0.clone(), types_pe))),
                    ::std::option::Option::None => crate::prelude::run_to_end(crate::prelude::fold_job(crate::prelude::or(&enclosing_instances_o(lx_p0), &crate::prelude::Array::new()), crate::prelude::Array::new(), {
                        let lx_p0x = lx_p0.clone();
                        let v_p4x = v_p4.clone();
                        let callee_span_p2x = callee_span_p2.clone();
                        let args_p3x = args_p3.clone();
                        let closed_f6x = closed_f6.clone();
                        ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)| {
                            let lx_p0xy = lx_p0x.clone();
                            let v_p4xy = v_p4x.clone();
                            let callee_span_p2xy = callee_span_p2x.clone();
                            let args_p3xy = args_p3x.clone();
                            let closed_f6xy = closed_f6x.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let acc_pf = p0;
                                let user_pg = p1;
                                {
                                    let lxu_ph = {
                                        let mut this: crate::lower::Lx = lx_p0xy.clone();
                                        this.subst_p = crate::prelude::fold(&user_pg, &this.subst_p, &(|m_pi: &crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>, (q_pj, t_pk): &(crate::prelude::Text, crate::check::types::Ty)| crate::prelude::insert(m_pi, q_pj, t_pk)));
                                        this
                                    };
                                    crate::prelude::call_then(start_valued_types_o(lxu_ph.clone(), v_p4xy.clone(), callee_span_p2xy.clone(), args_p3xy.clone()), move |valued_types_o_51246: ::std::option::Option<crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>>| match valued_types_o_51246 {
                                        ::std::option::Option::Some(types_pl) => crate::prelude::call_value((&closed_f6xy)((lxu_ph.clone(), types_pl.clone())), move |closed_51327: crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_pf, &closed_51327))),
                                        ::std::option::Option::None => ::prism_rtl::Turn::Finished(acc_pf.clone()),
                                    })
                                }
                            }))
                        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>>>>
                    })),
                }
            } else {
                crate::prelude::Array::new()
            }
        },
        ::std::option::Option::None => crate::prelude::Array::new(),
    }
}

/// The step machine of `PlacedWidget`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PlacedWidget: unbounded fn Lx, Text, Range, [Arg] -> [((Text, [((Text, Ty))]))]
/// ```
pub struct PlacedWidget {
    pub lx_p0: crate::lower::Lx,
    pub qk_p1: crate::prelude::Text,
    pub callee_span_p2: crate::syntax::Range,
    pub args_p3: crate::prelude::Array<crate::syntax::Arg>,
}

impl ::prism_rtl::Job<crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>> for PlacedWidget {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>> {
        let lx_p0 = &self.lx_p0;
        let qk_p1 = &self.qk_p1;
        let callee_span_p2 = &self.callee_span_p2;
        let args_p3 = &self.args_p3;
        match crate::prelude::get(&lx_p0.g_p.vals_p, qk_p1) {
            ::std::option::Option::Some(v_p4) => {
                let defined_p5 = crate::prelude::fold(&lx_p0.g_p.defs_p, &false, &(|f_p7: &bool, d_p8: &crate::check::env::Def| *f_p7 || ((&d_p8.qk_p == qk_p1) && is_widget_def_f(d_p8))));
                let closed_f6 = {
                    let v_p4x = v_p4.clone();
                    let callee_span_p2x = callee_span_p2.clone();
                    let args_p3x = args_p3.clone();
                    let qk_p1x = qk_p1.clone();
                    ::std::rc::Rc::new(move |(p0, p1): (crate::lower::Lx, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)| {
                        let v_p4xy = v_p4x.clone();
                        let callee_span_p2xy = callee_span_p2x.clone();
                        let args_p3xy = args_p3x.clone();
                        let qk_p1xy = qk_p1x.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let lx_at_p9 = p0;
                            let types_pa = p1;
                            crate::prelude::call_then(start_at_let_instantiations_f(lx_at_p9.clone(), types_pa.clone()), move |at_let_instantiations_f_50529: crate::prelude::Array<crate::lower::Lx>| crate::prelude::fold_job(at_let_instantiations_f_50529, crate::prelude::Array::new(), {
                                let v_p4xyx = v_p4xy.clone();
                                let callee_span_p2xyx = callee_span_p2xy.clone();
                                let args_p3xyx = args_p3xy.clone();
                                let qk_p1xyx = qk_p1xy.clone();
                                ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>, crate::lower::Lx)| {
                                    let v_p4xyxy = v_p4xyx.clone();
                                    let callee_span_p2xyxy = callee_span_p2xyx.clone();
                                    let args_p3xyxy = args_p3xyx.clone();
                                    let qk_p1xyxy = qk_p1xyx.clone();
                                    crate::prelude::entered(crate::prelude::once_job(move || {
                                        let acc_pb = p0;
                                        let lxk_pc = p1;
                                        crate::prelude::call_then(start_valued_types_o(lxk_pc.clone(), v_p4xyxy.clone(), callee_span_p2xyxy.clone(), args_p3xyxy.clone()), move |valued_types_o_50587: ::std::option::Option<crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>>| match valued_types_o_50587 {
                                            ::std::option::Option::Some(closed_pd) => ::prism_rtl::Turn::Finished(crate::prelude::push(&acc_pb, &(qk_p1xyxy.clone(), closed_pd.clone()))),
                                            ::std::option::Option::None => ::prism_rtl::Turn::Finished(acc_pb.clone()),
                                        })
                                    }))
                                }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>, crate::lower::Lx)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>>>>
                            }).cycle())
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::Lx, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>>>>
                };
                if (defined_p5 && crate::lower::node_::def::is_widget_ty_f(&crate::lower::node_::static_::widget_result_of_f(&v_p4.scheme_p.ty_p))) && !is_value_widget_f(lx_p0, qk_p1) {
                    {
                        let args_p3x = args_p3.clone();
                        let callee_span_p2x = callee_span_p2.clone();
                        let lx_p0x = lx_p0.clone();
                        crate::prelude::call_then(start_valued_types_o(lx_p0x.clone(), v_p4.clone(), callee_span_p2x.clone(), args_p3x.clone()), move |valued_types_o_50797: ::std::option::Option<crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>>| match valued_types_o_50797 {
                            ::std::option::Option::Some(types_pe) => (&closed_f6)((lx_p0x.clone(), types_pe.clone())).cycle(),
                            ::std::option::Option::None => crate::prelude::call_then(start_enclosing_instances_o(lx_p0x.clone()), move |enclosing_instances_o_51053: ::std::option::Option<crate::prelude::Array<crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>>>| crate::prelude::fold_job(crate::prelude::or(&enclosing_instances_o_51053, &crate::prelude::Array::new()), crate::prelude::Array::new(), {
                                let lx_p0xx = lx_p0x.clone();
                                let v_p4x = v_p4.clone();
                                let callee_span_p2xx = callee_span_p2x.clone();
                                let args_p3xx = args_p3x.clone();
                                let closed_f6x = closed_f6.clone();
                                ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)| {
                                    let lx_p0xxy = lx_p0xx.clone();
                                    let v_p4xy = v_p4x.clone();
                                    let callee_span_p2xxy = callee_span_p2xx.clone();
                                    let args_p3xxy = args_p3xx.clone();
                                    let closed_f6xy = closed_f6x.clone();
                                    crate::prelude::entered(crate::prelude::once_job(move || {
                                        let acc_pf = p0;
                                        let user_pg = p1;
                                        {
                                            let lxu_ph = {
                                                let mut this: crate::lower::Lx = lx_p0xxy.clone();
                                                this.subst_p = crate::prelude::fold(&user_pg, &this.subst_p, &(|m_pi: &crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>, (q_pj, t_pk): &(crate::prelude::Text, crate::check::types::Ty)| crate::prelude::insert(m_pi, q_pj, t_pk)));
                                                this
                                            };
                                            crate::prelude::call_then(start_valued_types_o(lxu_ph.clone(), v_p4xy.clone(), callee_span_p2xxy.clone(), args_p3xxy.clone()), move |valued_types_o_51246: ::std::option::Option<crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>>| match valued_types_o_51246 {
                                                ::std::option::Option::Some(types_pl) => crate::prelude::call_value((&closed_f6xy)((lxu_ph.clone(), types_pl.clone())), move |closed_51327: crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_pf, &closed_51327))),
                                                ::std::option::Option::None => ::prism_rtl::Turn::Finished(acc_pf.clone()),
                                            })
                                        }
                                    }))
                                }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>>>>
                            }).cycle()),
                        })
                    }
                } else {
                    ::prism_rtl::Turn::Finished(crate::prelude::Array::new())
                }
            },
            ::std::option::Option::None => ::prism_rtl::Turn::Finished(crate::prelude::Array::new()),
        }
    }
}

/// `Start PlacedWidget, x`: what the function value is when passed to `@Run`.
pub fn start_placed_widget_f(lx_p0: crate::lower::Lx, qk_p1: crate::prelude::Text, callee_span_p2: crate::syntax::Range, args_p3: crate::prelude::Array<crate::syntax::Arg>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>>> {
    ::std::rc::Rc::new(PlacedWidget { lx_p0, qk_p1, callee_span_p2, args_p3 })
}

/// ```prism
/// AtLetInstantiations: unbounded fn Lx, [((Text, Ty))] -> [Lx]
/// ```
pub fn at_let_instantiations_f(lx_p0: &crate::lower::Lx, types_p1: &crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>) -> crate::prelude::Array<crate::lower::Lx> {
    let unclosed_p2 = crate::prelude::run_to_end(crate::prelude::fold_job(types_p1.clone(), crate::prelude::Array::new(), {
        let lx_p0x = lx_p0.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, (crate::prelude::Text, crate::check::types::Ty))| {
            let lx_p0xy = lx_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_p3 = p0;
                let (_, t_p4) = p1;
                crate::prelude::call_then(crate::lower::expr::start_open_ty_qs_f(lx_p0xy.clone(), t_p4.clone()), move |open_ty_qs_f_51915: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_p3, &open_ty_qs_f_51915)))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, (crate::prelude::Text, crate::check::types::Ty))) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>
    }));
    match crate::prelude::index(&unclosed_p2, &crate::prelude::Nat::from(0u32)) {
        ::std::option::Option::None => crate::prelude::Array::from(vec![lx_p0.clone()]),
        ::std::option::Option::Some(q_p5) => match crate::prelude::get(&lx_p0.gen_of_q_p, &q_p5) {
            ::std::option::Option::None => crate::prelude::Array::from(vec![lx_p0.clone()]),
            ::std::option::Option::Some(gn_p6) => {
                let read_p7 = crate::lower::expr::instantiations_f(lx_p0, &gn_p6);
                let instantiations_p8 = if &crate::prelude::len(&read_p7) > &crate::prelude::Nat::from(0u32) {
                    read_p7.clone()
                } else {
                    crate::prelude::Array::from(vec![(crate::prelude::each(&gn_p6.tys_p, &(|variable_p9: &crate::prelude::Text| (variable_p9.clone(), crate::check::types::Ty::TyTuple(crate::prelude::Array::new())))), crate::prelude::each(&gn_p6.cols_p, &(|c_pa: &crate::prelude::Text| (c_pa.clone(), crate::check::types::Col::CBound))))])
                };
                crate::prelude::run_to_end(crate::prelude::fold_job(instantiations_p8.clone(), crate::prelude::Array::new(), {
                    let lx_p0x = lx_p0.clone();
                    let types_p1x = types_p1.clone();
                    ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::lower::Lx>, (crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Col)>))| {
                        let lx_p0xy = lx_p0x.clone();
                        let types_p1xy = types_p1x.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let acc_pb = p0;
                            let instantiation_pc = p1;
                            {
                                let lxk_pd = crate::lower::expr::at_instance_f(&lx_p0xy, &instantiation_pc);
                                crate::prelude::call_then(start_at_let_instantiations_f(lxk_pd.clone(), crate::prelude::each(&types_p1xy, &(|(name_pe, t_pf): &(crate::prelude::Text, crate::check::types::Ty)| (name_pe.clone(), crate::lower::subst_ty_f(&lxk_pd, t_pf))))), move |at_let_instantiations_f_52422: crate::prelude::Array<crate::lower::Lx>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_pb, &at_let_instantiations_f_52422)))
                            }
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::lower::Lx>, (crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Col)>))) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::lower::Lx>>>>
                }))
            },
        },
    }
}

/// The step machine of `AtLetInstantiations`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// AtLetInstantiations: unbounded fn Lx, [((Text, Ty))] -> [Lx]
/// ```
pub struct AtLetInstantiations {
    pub lx_p0: crate::lower::Lx,
    pub types_p1: crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>,
}

impl ::prism_rtl::Job<crate::prelude::Array<crate::lower::Lx>> for AtLetInstantiations {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<crate::lower::Lx>> {
        let lx_p0 = &self.lx_p0;
        let types_p1 = &self.types_p1;
        let lx_p0x = lx_p0.clone();
        let types_p1x = types_p1.clone();
        crate::prelude::call_value(crate::prelude::fold_job(types_p1x.clone(), crate::prelude::Array::new(), {
            let lx_p0xx = lx_p0x.clone();
            ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, (crate::prelude::Text, crate::check::types::Ty))| {
                let lx_p0xxy = lx_p0xx.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let acc_p3 = p0;
                    let (_, t_p4) = p1;
                    crate::prelude::call_then(crate::lower::expr::start_open_ty_qs_f(lx_p0xxy.clone(), t_p4.clone()), move |open_ty_qs_f_51915: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_p3, &open_ty_qs_f_51915)))
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, (crate::prelude::Text, crate::check::types::Ty))) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>
        }), move |fold_51862: crate::prelude::Array<crate::prelude::Text>| {
            let unclosed_p2 = fold_51862;
            match crate::prelude::index(&unclosed_p2, &crate::prelude::Nat::from(0u32)) {
                ::std::option::Option::None => ::prism_rtl::Turn::Finished(crate::prelude::Array::from(vec![lx_p0x.clone()])),
                ::std::option::Option::Some(q_p5) => match crate::prelude::get(&lx_p0x.gen_of_q_p, &q_p5) {
                    ::std::option::Option::None => ::prism_rtl::Turn::Finished(crate::prelude::Array::from(vec![lx_p0x.clone()])),
                    ::std::option::Option::Some(gn_p6) => crate::prelude::call_then(crate::lower::expr::start_instantiations_f(lx_p0x.clone(), gn_p6.clone()), move |instantiations_f_52076: crate::prelude::Array<(crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Col)>)>| {
                        let read_p7 = instantiations_f_52076;
                        let instantiations_p8 = if &crate::prelude::len(&read_p7) > &crate::prelude::Nat::from(0u32) {
                            read_p7.clone()
                        } else {
                            crate::prelude::Array::from(vec![(crate::prelude::each(&gn_p6.tys_p, &(|variable_p9: &crate::prelude::Text| (variable_p9.clone(), crate::check::types::Ty::TyTuple(crate::prelude::Array::new())))), crate::prelude::each(&gn_p6.cols_p, &(|c_pa: &crate::prelude::Text| (c_pa.clone(), crate::check::types::Col::CBound))))])
                        };
                        crate::prelude::fold_job(instantiations_p8.clone(), crate::prelude::Array::new(), {
                            let lx_p0xx = lx_p0x.clone();
                            let types_p1xx = types_p1x.clone();
                            ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::lower::Lx>, (crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Col)>))| {
                                let lx_p0xxy = lx_p0xx.clone();
                                let types_p1xxy = types_p1xx.clone();
                                crate::prelude::entered(crate::prelude::once_job(move || {
                                    let acc_pb = p0;
                                    let instantiation_pc = p1;
                                    {
                                        let lxk_pd = crate::lower::expr::at_instance_f(&lx_p0xxy, &instantiation_pc);
                                        crate::prelude::call_then(start_at_let_instantiations_f(lxk_pd.clone(), crate::prelude::each(&types_p1xxy, &(|(name_pe, t_pf): &(crate::prelude::Text, crate::check::types::Ty)| (name_pe.clone(), crate::lower::subst_ty_f(&lxk_pd, t_pf))))), move |at_let_instantiations_f_52422: crate::prelude::Array<crate::lower::Lx>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_pb, &at_let_instantiations_f_52422)))
                                    }
                                }))
                            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::lower::Lx>, (crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Col)>))) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::lower::Lx>>>>
                        }).cycle()
                    }),
                },
            }
        })
    }
}

/// `Start AtLetInstantiations, x`: what the function value is when passed to `@Run`.
pub fn start_at_let_instantiations_f(lx_p0: crate::lower::Lx, types_p1: crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::lower::Lx>>> {
    ::std::rc::Rc::new(AtLetInstantiations { lx_p0, types_p1 })
}

/// ```prism
/// IsWidgetDef: fn Def -> Bool
/// ```
pub fn is_widget_def_f(d_p0: &crate::check::env::Def) -> bool {
    match &d_p0.body_p {
        crate::check::env::DefBody::DbWidget(_) => true,
        crate::check::env::DefBody::DbFn(_) => true,
        _ => false,
    }
}

/// ```prism
/// ValuedStem: fn Text -> Text
/// ```
pub fn valued_stem_f(qk_p0: &crate::prelude::Text) -> crate::prelude::Text {
    crate::prelude::Text::from(format!("{}_value", &crate::lower::camel_f(&crate::check::types::bare_name_f(qk_p0))))
}

/// ```prism
/// ValuedStemAt: fn Text, Nat, [((Text, Ty))] -> Text
/// ```
pub fn valued_stem_at_f(qk_p0: &crate::prelude::Text, k_p1: &crate::prelude::Nat, types_p2: &crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>) -> crate::prelude::Text {
    if &crate::prelude::len(types_p2) == &crate::prelude::Nat::from(0u32) {
        valued_stem_f(qk_p0)
    } else {
        crate::prelude::Text::from(format!("{}_at{}_", &valued_stem_f(qk_p0), k_p1))
    }
}

/// ```prism
/// ?ValuedCases: unbounded fn Lx, Text, [((Text, Ty))], Text -> ?[((Text, Pa, [Cc], [Ex]))]
/// ```
pub fn valued_cases_o(lx_p0: &crate::lower::Lx, qk_p1: &crate::prelude::Text, types_p2: &crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>, stem_p3: &crate::prelude::Text) -> ::std::option::Option<crate::prelude::Array<(crate::prelude::Text, crate::lower::model::Pa, crate::prelude::Array<crate::lower::model::Cc>, crate::prelude::Array<crate::lower::model::Ex>)>> {
    match crate::prelude::get(&lx_p0.g_p.vals_p, qk_p1) {
        ::std::option::Option::None => ::std::option::Option::None,
        ::std::option::Option::Some(declared_p4) => {
            let lxv_p5 = crate::lower::expr::at_instance_f(&in_module_at_f(lx_p0, &declared_p4.file_p, &declared_p4.home_p, &declared_p4.home_p), &(types_p2.clone(), crate::prelude::Array::new()));
            let v_p6 = val_info_at_f(&lxv_p5, &declared_p4);
            let ptys_p7 = match &v_p6.scheme_p.ty_p {
                crate::check::types::Ty::TyFn(_, ps_pa, _) => ps_pa.clone(),
                _ => crate::prelude::Array::new(),
            };
            let plain_result_p8 = match crate::lower::node_::static_::widget_result_of_f(&v_p6.scheme_p.ty_p) {
                crate::check::types::Ty::TyAt(_, _) => true,
                _ => false,
            };
            let plain_params_p9 = crate::prelude::fold(&ptys_p7, &true, &(|ok_pb: &bool, pt_pc: &crate::check::types::Ty| *ok_pb && (((crate::lower::node_::static_::is_widget_fn_ty_f(pt_pc) || (&crate::lower::types::layer_of_f(pt_pc) == &crate::lower::types::Layer::LyPlain)) || (&crate::lower::types::layer_of_f(pt_pc) == &crate::lower::types::Layer::LyBlueprint)) || crate::lower::node_::switch_::is_live_param_f(pt_pc))));
            if !(plain_result_p8 && plain_params_p9) {
                ::std::option::Option::None
            } else {
                {
                    let clauses_pd = crate::lower::jobs::clauses_of_f(&lx_p0.g_p, qk_p1);
                    if &crate::prelude::len(&clauses_pd) == &crate::prelude::Nat::from(0u32) {
                        ::std::option::Option::Some(crate::prelude::Array::from(vec![(crate::prelude::Text::from(format!("{}0", stem_p3)), crate::lower::model::Pa::PaTuple(crate::prelude::Array::new()), crate::prelude::Array::new(), crate::prelude::Array::from(vec![crate::lower::model::Ex::XVar(crate::prelude::Text::lit("row_base"))]))]))
                    } else {
                        ::std::option::Option::Some(crate::prelude::run_to_end(crate::prelude::each_job(crate::check::errors::range0_f(&crate::prelude::len(&clauses_pd)), {
                            let lxv_p5x = lxv_p5.clone();
                            let v_p6x = v_p6.clone();
                            let clauses_pdx = clauses_pd.clone();
                            let stem_p3x = stem_p3.clone();
                            ::std::rc::Rc::new(move |p0: crate::prelude::Nat| {
                                let lxv_p5xy = lxv_p5x.clone();
                                let v_p6xy = v_p6x.clone();
                                let clauses_pdxy = clauses_pdx.clone();
                                let stem_p3xy = stem_p3x.clone();
                                crate::prelude::entered(crate::prelude::once_job(move || {
                                    let i_pe = p0;
                                    ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::lower::node_::switch_::SharedCaseOf { lx_p0: lxv_p5xy.clone(), v_p1: v_p6xy.clone(), c_p2: crate::prelude::or(&crate::prelude::index(&clauses_pdxy, &i_pe), &crate::lower::functions::dummy_clause_p()), row_name_p3: crate::prelude::Text::from(format!("{}{}", &stem_p3xy, &i_pe)) }))
                                }))
                            }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Text, crate::lower::model::Pa, crate::prelude::Array<crate::lower::model::Cc>, crate::prelude::Array<crate::lower::model::Ex>)>>>
                        })))
                    }
                }
            }
        },
    }
}

/// The step machine of `ValuedCases`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?ValuedCases: unbounded fn Lx, Text, [((Text, Ty))], Text -> ?[((Text, Pa, [Cc], [Ex]))]
/// ```
pub struct ValuedCases {
    pub lx_p0: crate::lower::Lx,
    pub qk_p1: crate::prelude::Text,
    pub types_p2: crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>,
    pub stem_p3: crate::prelude::Text,
}

impl ::prism_rtl::Job<::std::option::Option<crate::prelude::Array<(crate::prelude::Text, crate::lower::model::Pa, crate::prelude::Array<crate::lower::model::Cc>, crate::prelude::Array<crate::lower::model::Ex>)>>> for ValuedCases {
    fn cycle(&self) -> ::prism_rtl::Turn<::std::option::Option<crate::prelude::Array<(crate::prelude::Text, crate::lower::model::Pa, crate::prelude::Array<crate::lower::model::Cc>, crate::prelude::Array<crate::lower::model::Ex>)>>> {
        let lx_p0 = &self.lx_p0;
        let qk_p1 = &self.qk_p1;
        let types_p2 = &self.types_p2;
        let stem_p3 = &self.stem_p3;
        match crate::prelude::get(&lx_p0.g_p.vals_p, qk_p1) {
            ::std::option::Option::None => ::prism_rtl::Turn::Finished(::std::option::Option::None),
            ::std::option::Option::Some(declared_p4) => {
                let lxv_p5 = crate::lower::expr::at_instance_f(&in_module_at_f(lx_p0, &declared_p4.file_p, &declared_p4.home_p, &declared_p4.home_p), &(types_p2.clone(), crate::prelude::Array::new()));
                let v_p6 = val_info_at_f(&lxv_p5, &declared_p4);
                let ptys_p7 = match &v_p6.scheme_p.ty_p {
                    crate::check::types::Ty::TyFn(_, ps_pa, _) => ps_pa.clone(),
                    _ => crate::prelude::Array::new(),
                };
                let plain_result_p8 = match crate::lower::node_::static_::widget_result_of_f(&v_p6.scheme_p.ty_p) {
                    crate::check::types::Ty::TyAt(_, _) => true,
                    _ => false,
                };
                let plain_params_p9 = crate::prelude::fold(&ptys_p7, &true, &(|ok_pb: &bool, pt_pc: &crate::check::types::Ty| *ok_pb && (((crate::lower::node_::static_::is_widget_fn_ty_f(pt_pc) || (&crate::lower::types::layer_of_f(pt_pc) == &crate::lower::types::Layer::LyPlain)) || (&crate::lower::types::layer_of_f(pt_pc) == &crate::lower::types::Layer::LyBlueprint)) || crate::lower::node_::switch_::is_live_param_f(pt_pc))));
                if !(plain_result_p8 && plain_params_p9) {
                    ::prism_rtl::Turn::Finished(::std::option::Option::None)
                } else {
                    {
                        let clauses_pd = crate::lower::jobs::clauses_of_f(&lx_p0.g_p, qk_p1);
                        if &crate::prelude::len(&clauses_pd) == &crate::prelude::Nat::from(0u32) {
                            ::prism_rtl::Turn::Finished(::std::option::Option::Some(crate::prelude::Array::from(vec![(crate::prelude::Text::from(format!("{}0", stem_p3)), crate::lower::model::Pa::PaTuple(crate::prelude::Array::new()), crate::prelude::Array::new(), crate::prelude::Array::from(vec![crate::lower::model::Ex::XVar(crate::prelude::Text::lit("row_base"))]))])))
                        } else {
                            ::prism_rtl::Turn::Finished(::std::option::Option::Some(crate::prelude::run_to_end(crate::prelude::each_job(crate::check::errors::range0_f(&crate::prelude::len(&clauses_pd)), {
                                let lxv_p5x = lxv_p5.clone();
                                let v_p6x = v_p6.clone();
                                let clauses_pdx = clauses_pd.clone();
                                let stem_p3x = stem_p3.clone();
                                ::std::rc::Rc::new(move |p0: crate::prelude::Nat| {
                                    let lxv_p5xy = lxv_p5x.clone();
                                    let v_p6xy = v_p6x.clone();
                                    let clauses_pdxy = clauses_pdx.clone();
                                    let stem_p3xy = stem_p3x.clone();
                                    crate::prelude::entered(crate::prelude::once_job(move || {
                                        let i_pe = p0;
                                        ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::lower::node_::switch_::SharedCaseOf { lx_p0: lxv_p5xy.clone(), v_p1: v_p6xy.clone(), c_p2: crate::prelude::or(&crate::prelude::index(&clauses_pdxy, &i_pe), &crate::lower::functions::dummy_clause_p()), row_name_p3: crate::prelude::Text::from(format!("{}{}", &stem_p3xy, &i_pe)) }))
                                    }))
                                }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Text, crate::lower::model::Pa, crate::prelude::Array<crate::lower::model::Cc>, crate::prelude::Array<crate::lower::model::Ex>)>>>
                            }))))
                        }
                    }
                }
            },
        }
    }
}

/// `Start ValuedCases, x`: what the function value is when passed to `@Run`.
pub fn start_valued_cases_o(lx_p0: crate::lower::Lx, qk_p1: crate::prelude::Text, types_p2: crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>, stem_p3: crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<::std::option::Option<crate::prelude::Array<(crate::prelude::Text, crate::lower::model::Pa, crate::prelude::Array<crate::lower::model::Cc>, crate::prelude::Array<crate::lower::model::Ex>)>>>> {
    ::std::rc::Rc::new(ValuedCases { lx_p0, qk_p1, types_p2, stem_p3 })
}

/// ```prism
/// ValuedRows: unbounded fn Lx, Text, ?Block -> [Item]
/// ```
pub fn valued_rows_f(lx_p0: &crate::lower::Lx, qk_p1: &crate::prelude::Text, body_o2: &::std::option::Option<crate::syntax::Block>) -> crate::prelude::Array<crate::lower::model::Item> {
    match crate::prelude::get(&lx_p0.g_p.vals_p, qk_p1) {
        ::std::option::Option::Some(v_p3) => {
            let instances_p4 = crate::prelude::or(&crate::prelude::get(&lx_p0.valued_at_p, qk_p1), &crate::prelude::Array::new());
            crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(&instances_p4)), crate::prelude::Array::new(), {
                let instances_p4x = instances_p4.clone();
                let lx_p0x = lx_p0.clone();
                let qk_p1x = qk_p1.clone();
                let body_o2x = body_o2.clone();
                let v_p3x = v_p3.clone();
                ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::lower::model::Item>, crate::prelude::Nat)| {
                    let instances_p4xy = instances_p4x.clone();
                    let lx_p0xy = lx_p0x.clone();
                    let qk_p1xy = qk_p1x.clone();
                    let body_o2xy = body_o2x.clone();
                    let v_p3xy = v_p3x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let acc_p5 = p0;
                        let k_p6 = p1;
                        {
                            let (_, types_p9) = crate::prelude::or(&crate::prelude::index(&instances_p4xy, &k_p6), &(crate::prelude::Text::lit(""), crate::prelude::Array::new()));
                            let lxk_p7 = crate::lower::expr::at_instance_f(&lx_p0xy, &(types_p9.clone(), crate::prelude::Array::new()));
                            let stem_p8 = valued_stem_at_f(&qk_p1xy, &k_p6, &types_p9);
                            crate::prelude::call_then(start_valued_rows_in_f(lxk_p7.clone(), qk_p1xy.clone(), stem_p8.clone(), body_o2xy.clone(), val_info_at_f(&lxk_p7, &v_p3xy), false), move |valued_rows_in_f_56051: crate::prelude::Array<crate::lower::model::Item>| crate::prelude::call_then(start_valued_rows_in_f(lxk_p7.clone(), qk_p1xy.clone(), stem_p8.clone(), body_o2xy.clone(), val_info_at_f(&lxk_p7, &v_p3xy), true), move |valued_rows_in_f_56116: crate::prelude::Array<crate::lower::model::Item>| ::prism_rtl::Turn::Finished(crate::prelude::append(&crate::prelude::append(&acc_p5, &valued_rows_in_f_56051), &valued_rows_in_f_56116))))
                        }
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::lower::model::Item>, crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::lower::model::Item>>>>
            }))
        },
        ::std::option::Option::None => crate::prelude::Array::new(),
    }
}

/// The step machine of `ValuedRows`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ValuedRows: unbounded fn Lx, Text, ?Block -> [Item]
/// ```
pub struct ValuedRows {
    pub lx_p0: crate::lower::Lx,
    pub qk_p1: crate::prelude::Text,
    pub body_o2: ::std::option::Option<crate::syntax::Block>,
}

impl ::prism_rtl::Job<crate::prelude::Array<crate::lower::model::Item>> for ValuedRows {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<crate::lower::model::Item>> {
        let lx_p0 = &self.lx_p0;
        let qk_p1 = &self.qk_p1;
        let body_o2 = &self.body_o2;
        match crate::prelude::get(&lx_p0.g_p.vals_p, qk_p1) {
            ::std::option::Option::Some(v_p3) => {
                let instances_p4 = crate::prelude::or(&crate::prelude::get(&lx_p0.valued_at_p, qk_p1), &crate::prelude::Array::new());
                crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(&instances_p4)), crate::prelude::Array::new(), {
                    let instances_p4x = instances_p4.clone();
                    let lx_p0x = lx_p0.clone();
                    let qk_p1x = qk_p1.clone();
                    let body_o2x = body_o2.clone();
                    let v_p3x = v_p3.clone();
                    ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::lower::model::Item>, crate::prelude::Nat)| {
                        let instances_p4xy = instances_p4x.clone();
                        let lx_p0xy = lx_p0x.clone();
                        let qk_p1xy = qk_p1x.clone();
                        let body_o2xy = body_o2x.clone();
                        let v_p3xy = v_p3x.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let acc_p5 = p0;
                            let k_p6 = p1;
                            {
                                let (_, types_p9) = crate::prelude::or(&crate::prelude::index(&instances_p4xy, &k_p6), &(crate::prelude::Text::lit(""), crate::prelude::Array::new()));
                                let lxk_p7 = crate::lower::expr::at_instance_f(&lx_p0xy, &(types_p9.clone(), crate::prelude::Array::new()));
                                let stem_p8 = valued_stem_at_f(&qk_p1xy, &k_p6, &types_p9);
                                crate::prelude::call_then(start_valued_rows_in_f(lxk_p7.clone(), qk_p1xy.clone(), stem_p8.clone(), body_o2xy.clone(), val_info_at_f(&lxk_p7, &v_p3xy), false), move |valued_rows_in_f_56051: crate::prelude::Array<crate::lower::model::Item>| crate::prelude::call_then(start_valued_rows_in_f(lxk_p7.clone(), qk_p1xy.clone(), stem_p8.clone(), body_o2xy.clone(), val_info_at_f(&lxk_p7, &v_p3xy), true), move |valued_rows_in_f_56116: crate::prelude::Array<crate::lower::model::Item>| ::prism_rtl::Turn::Finished(crate::prelude::append(&crate::prelude::append(&acc_p5, &valued_rows_in_f_56051), &valued_rows_in_f_56116))))
                            }
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::lower::model::Item>, crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::lower::model::Item>>>>
                }).cycle()
            },
            ::std::option::Option::None => ::prism_rtl::Turn::Finished(crate::prelude::Array::new()),
        }
    }
}

/// `Start ValuedRows, x`: what the function value is when passed to `@Run`.
pub fn start_valued_rows_f(lx_p0: crate::lower::Lx, qk_p1: crate::prelude::Text, body_o2: ::std::option::Option<crate::syntax::Block>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::lower::model::Item>>> {
    ::std::rc::Rc::new(ValuedRows { lx_p0, qk_p1, body_o2 })
}

/// ```prism
/// ValuedRowsIn: unbounded fn Lx, Text, Text, ?Block, ValInfo, Bool -> [Item]
/// ```
pub fn valued_rows_in_f(lx_p0: &crate::lower::Lx, qk_p1: &crate::prelude::Text, stem_p2: &crate::prelude::Text, body_o3: &::std::option::Option<crate::syntax::Block>, v_p4: &crate::check::env::ValInfo, hosted_p5: &bool) -> crate::prelude::Array<crate::lower::model::Item> {
    let named_f6w0 = {
        let hosted_p5x = *hosted_p5;
        let stem_p2x = stem_p2.clone();
        ::std::rc::Rc::new(move |i_pb: &crate::prelude::Int| if hosted_p5x {
            crate::lower::expr::hosted_valued_row_f(&crate::prelude::Text::from(format!("{}{}", &stem_p2x, i_pb)))
        } else {
            crate::prelude::Text::from(format!("{}{}", &stem_p2x, i_pb))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(&crate::prelude::Int) -> crate::prelude::Text>
    };
    let named_f6w1 = {
        let hosted_p5x = *hosted_p5;
        let stem_p2x = stem_p2.clone();
        ::std::rc::Rc::new(move |i_pb: &crate::prelude::Nat| if hosted_p5x {
            crate::lower::expr::hosted_valued_row_f(&crate::prelude::Text::from(format!("{}{}", &stem_p2x, i_pb)))
        } else {
            crate::prelude::Text::from(format!("{}{}", &stem_p2x, i_pb))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(&crate::prelude::Nat) -> crate::prelude::Text>
    };
    let hosted_by_o7 = if *hosted_p5 {
        ::std::option::Option::Some(crate::lower::node_::switch_::shared_moved_p())
    } else {
        ::std::option::Option::None
    };
    let wx0_p8 = crate::lower::node_::new_wx_f(lx_p0, &crate::prelude::Text::from(format!("{}s", stem_p2)), &crate::prelude::Array::new(), &crate::prelude::Array::new(), &crate::prelude::Array::new(), &crate::prelude::Array::new(), &crate::prelude::Map::new(), &crate::lower::node_::node_hooks_p(), &crate::prelude::Array::new(), &hosted_by_o7);
    let clauses_p9 = crate::lower::jobs::clauses_of_f(&lx_p0.g_p, qk_p1);
    let rows_pa = match body_o3 {
        ::std::option::Option::Some(b_pc) => if &crate::prelude::len(&clauses_p9) > &crate::prelude::Nat::from(0u32) {
            crate::prelude::Array::new()
        } else {
            crate::prelude::Array::from(vec![crate::lower::node_::switch_::arm_row_of_f(&wx0_p8, &crate::lower::types::empty_env_p(), lx_p0, &crate::prelude::Array::new(), &crate::prelude::Array::new(), &::std::option::Option::None, b_pc, &(&named_f6w0)(&crate::prelude::Int::from(0)), &crate::prelude::Text::lit("valued"), &true, &false, &crate::lower::model::OutTy::OutUnit, &crate::prelude::Array::new(), &crate::prelude::Array::new(), &crate::prelude::Array::new(), &true)])
        },
        ::std::option::Option::None => crate::prelude::run_to_end(crate::prelude::each_job(crate::check::errors::range0_f(&crate::prelude::len(&clauses_p9)), {
            let wx0_p8x = wx0_p8.clone();
            let clauses_p9x = clauses_p9.clone();
            let v_p4x = v_p4.clone();
            let named_f6w0x = named_f6w0.clone();
            let named_f6w1x = named_f6w1.clone();
            ::std::rc::Rc::new(move |p0: crate::prelude::Nat| {
                let wx0_p8xy = wx0_p8x.clone();
                let clauses_p9xy = clauses_p9x.clone();
                let v_p4xy = v_p4x.clone();
                let named_f6w0xy = named_f6w0x.clone();
                let named_f6w1xy = named_f6w1x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let i_pd = p0;
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::lower::node_::switch_::ClauseRowOf { wx_p0: wx0_p8xy.clone(), menv_p1: crate::lower::types::empty_env_p(), c_p2: crate::prelude::or(&crate::prelude::index(&clauses_p9xy, &i_pd), &crate::lower::functions::dummy_clause_p()), v_p3: v_p4xy.clone(), row_name_p4: (&named_f6w1xy)(&i_pd), gen_name_p5: crate::prelude::Text::lit("valued"), transparent_p6: true, parent_ty_p7: crate::lower::model::OutTy::OutUnit, args_p8: crate::prelude::Array::new(), zero_based_p9: true }))
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::node_::switch_::ClauseRow>>>
        })),
    };
    crate::prelude::fold(&rows_pa, &crate::prelude::Array::new(), &(|acc_pe: &crate::prelude::Array<crate::lower::model::Item>, cr_pf: &crate::lower::node_::switch_::ClauseRow| crate::prelude::append(&crate::prelude::push(acc_pe, &crate::lower::model::Item::ItNode(cr_pf.case_p.node_p.clone())), &crate::prelude::each(&cr_pf.case_p.node_p.children_p, &(|c_pg: &crate::lower::model::NodeDef| crate::lower::model::Item::ItNode(c_pg.clone()))))))
}

/// The step machine of `ValuedRowsIn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ValuedRowsIn: unbounded fn Lx, Text, Text, ?Block, ValInfo, Bool -> [Item]
/// ```
pub struct ValuedRowsIn {
    pub lx_p0: crate::lower::Lx,
    pub qk_p1: crate::prelude::Text,
    pub stem_p2: crate::prelude::Text,
    pub body_o3: ::std::option::Option<crate::syntax::Block>,
    pub v_p4: crate::check::env::ValInfo,
    pub hosted_p5: bool,
}

impl ::prism_rtl::Job<crate::prelude::Array<crate::lower::model::Item>> for ValuedRowsIn {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<crate::lower::model::Item>> {
        let lx_p0 = &self.lx_p0;
        let qk_p1 = &self.qk_p1;
        let stem_p2 = &self.stem_p2;
        let body_o3 = &self.body_o3;
        let v_p4 = &self.v_p4;
        let hosted_p5 = &self.hosted_p5;
        let named_f6w0 = {
            let hosted_p5x = *hosted_p5;
            let stem_p2x = stem_p2.clone();
            ::std::rc::Rc::new(move |i_pb: &crate::prelude::Int| if hosted_p5x {
                crate::lower::expr::hosted_valued_row_f(&crate::prelude::Text::from(format!("{}{}", &stem_p2x, i_pb)))
            } else {
                crate::prelude::Text::from(format!("{}{}", &stem_p2x, i_pb))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(&crate::prelude::Int) -> crate::prelude::Text>
        };
        let named_f6w1 = {
            let hosted_p5x = *hosted_p5;
            let stem_p2x = stem_p2.clone();
            ::std::rc::Rc::new(move |i_pb: &crate::prelude::Nat| if hosted_p5x {
                crate::lower::expr::hosted_valued_row_f(&crate::prelude::Text::from(format!("{}{}", &stem_p2x, i_pb)))
            } else {
                crate::prelude::Text::from(format!("{}{}", &stem_p2x, i_pb))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(&crate::prelude::Nat) -> crate::prelude::Text>
        };
        let hosted_by_o7 = if *hosted_p5 {
            ::std::option::Option::Some(crate::lower::node_::switch_::shared_moved_p())
        } else {
            ::std::option::Option::None
        };
        let wx0_p8 = crate::lower::node_::new_wx_f(lx_p0, &crate::prelude::Text::from(format!("{}s", stem_p2)), &crate::prelude::Array::new(), &crate::prelude::Array::new(), &crate::prelude::Array::new(), &crate::prelude::Array::new(), &crate::prelude::Map::new(), &crate::lower::node_::node_hooks_p(), &crate::prelude::Array::new(), &hosted_by_o7);
        let clauses_p9 = crate::lower::jobs::clauses_of_f(&lx_p0.g_p, qk_p1);
        let k_let56579 = move |v56579: crate::prelude::Array<crate::lower::node_::switch_::ClauseRow>| {
            let rows_pa = v56579;
            ::prism_rtl::Turn::Finished(crate::prelude::fold(&rows_pa, &crate::prelude::Array::new(), &(|acc_pe: &crate::prelude::Array<crate::lower::model::Item>, cr_pf: &crate::lower::node_::switch_::ClauseRow| crate::prelude::append(&crate::prelude::push(acc_pe, &crate::lower::model::Item::ItNode(cr_pf.case_p.node_p.clone())), &crate::prelude::each(&cr_pf.case_p.node_p.children_p, &(|c_pg: &crate::lower::model::NodeDef| crate::lower::model::Item::ItNode(c_pg.clone())))))))
        };
        match body_o3.clone() {
            ::std::option::Option::Some(b_pc) => if &crate::prelude::len(&clauses_p9) > &crate::prelude::Nat::from(0u32) {
                k_let56579(crate::prelude::Array::new())
            } else {
                {
                    let lx_p0x = lx_p0.clone();
                    crate::prelude::call_then(crate::lower::node_::switch_::start_arm_row_of_f(wx0_p8.clone(), crate::lower::types::empty_env_p(), lx_p0x.clone(), crate::prelude::Array::new(), crate::prelude::Array::new(), ::std::option::Option::None, b_pc.clone(), (&named_f6w0)(&crate::prelude::Int::from(0)), crate::prelude::Text::lit("valued"), true, false, crate::lower::model::OutTy::OutUnit, crate::prelude::Array::new(), crate::prelude::Array::new(), crate::prelude::Array::new(), true), move |arm_row_of_f_56652: crate::lower::node_::switch_::ClauseRow| k_let56579(crate::prelude::Array::from(vec![arm_row_of_f_56652])))
                }
            },
            ::std::option::Option::None => {
                let v_p4x = v_p4.clone();
                crate::prelude::call_value(crate::prelude::each_job(crate::check::errors::range0_f(&crate::prelude::len(&clauses_p9)), {
                    let wx0_p8x = wx0_p8.clone();
                    let clauses_p9x = clauses_p9.clone();
                    let v_p4xx = v_p4x.clone();
                    let named_f6w0x = named_f6w0.clone();
                    let named_f6w1x = named_f6w1.clone();
                    ::std::rc::Rc::new(move |p0: crate::prelude::Nat| {
                        let wx0_p8xy = wx0_p8x.clone();
                        let clauses_p9xy = clauses_p9x.clone();
                        let v_p4xxy = v_p4xx.clone();
                        let named_f6w0xy = named_f6w0x.clone();
                        let named_f6w1xy = named_f6w1x.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let i_pd = p0;
                            ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::lower::node_::switch_::ClauseRowOf { wx_p0: wx0_p8xy.clone(), menv_p1: crate::lower::types::empty_env_p(), c_p2: crate::prelude::or(&crate::prelude::index(&clauses_p9xy, &i_pd), &crate::lower::functions::dummy_clause_p()), v_p3: v_p4xxy.clone(), row_name_p4: (&named_f6w1xy)(&i_pd), gen_name_p5: crate::prelude::Text::lit("valued"), transparent_p6: true, parent_ty_p7: crate::lower::model::OutTy::OutUnit, args_p8: crate::prelude::Array::new(), zero_based_p9: true }))
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::node_::switch_::ClauseRow>>>
                }), move |each_56782: crate::prelude::Array<crate::lower::node_::switch_::ClauseRow>| k_let56579(each_56782))
            },
        }
    }
}

/// `Start ValuedRowsIn, x`: what the function value is when passed to `@Run`.
pub fn start_valued_rows_in_f(lx_p0: crate::lower::Lx, qk_p1: crate::prelude::Text, stem_p2: crate::prelude::Text, body_o3: ::std::option::Option<crate::syntax::Block>, v_p4: crate::check::env::ValInfo, hosted_p5: bool) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::lower::model::Item>>> {
    ::std::rc::Rc::new(ValuedRowsIn { lx_p0, qk_p1, stem_p2, body_o3, v_p4, hosted_p5 })
}

/// ```prism
/// IsMain: fn Text -> Bool
/// ```
pub fn is_main_f(qk_p0: &crate::prelude::Text) -> bool {
    ((&crate::lower::owner_of_f(qk_p0) == &crate::prelude::Text::lit("")) && (&crate::lower::base_f(&crate::check::types::bare_name_f(qk_p0)) == &crate::prelude::Text::lit("main"))) && crate::syntax::lexer::chars::has_prefix_f(&crate::check::types::bare_name_f(qk_p0), &crate::prelude::Text::lit("@"))
}

/// ```prism
/// BlueprintQk: fn Lx, Expr -> Text
/// ```
pub fn blueprint_qk_f(lx_p0: &crate::lower::Lx, e_p1: &crate::syntax::Expr) -> crate::prelude::Text {
    match &*e_p1.kind_p {
        crate::syntax::ExprKind::ECall(c_p2, _, _, _) => blueprint_qk_f(lx_p0, &**c_p2),
        crate::syntax::ExprKind::EGroup(x_p3) => blueprint_qk_f(lx_p0, &**x_p3),
        crate::syntax::ExprKind::EName(n_p4) => {
            let (q_o5, _) = crate::check::env::names::resolve_value_f(&lx_p0.g_p, &lx_p0.home_p, n_p4);
            crate::prelude::or(&q_o5, &crate::prelude::Text::lit(""))
        },
        crate::syntax::ExprKind::EField(r_p6, sigils_p7, name_p8) => match crate::check::env::names::qualified_field_o(&lx_p0.g_p, &lx_p0.home_p, &**r_p6, sigils_p7, name_p8) {
            ::std::option::Option::Some(n_p9) => {
                let (q_oa, _) = crate::check::env::names::resolve_value_f(&lx_p0.g_p, &lx_p0.home_p, &n_p9);
                crate::prelude::or(&q_oa, &crate::prelude::Text::lit(""))
            },
            ::std::option::Option::None => crate::prelude::Text::lit(""),
        },
        _ => crate::prelude::Text::lit(""),
    }
}

/// ```prism
/// IsValueWidget: unbounded fn Lx, Text -> Bool
/// ```
pub fn is_value_widget_f(lx_p0: &crate::lower::Lx, qk_p1: &crate::prelude::Text) -> bool {
    pure_widget_fn_f(lx_p0, qk_p1, &crate::prelude::Array::new())
}

/// The step machine of `IsValueWidget`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// IsValueWidget: unbounded fn Lx, Text -> Bool
/// ```
pub struct IsValueWidget {
    pub lx_p0: crate::lower::Lx,
    pub qk_p1: crate::prelude::Text,
}

impl ::prism_rtl::Job<bool> for IsValueWidget {
    fn cycle(&self) -> ::prism_rtl::Turn<bool> {
        let lx_p0 = &self.lx_p0;
        let qk_p1 = &self.qk_p1;
        ::prism_rtl::Turn::More(::std::rc::Rc::new(PureWidgetFn { lx_p0: lx_p0.clone(), qk_p1: qk_p1.clone(), seen_p2: crate::prelude::Array::new() }))
    }
}

/// `Start IsValueWidget, x`: what the function value is when passed to `@Run`.
pub fn start_is_value_widget_f(lx_p0: crate::lower::Lx, qk_p1: crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>> {
    ::std::rc::Rc::new(IsValueWidget { lx_p0, qk_p1 })
}

/// ```prism
/// PureWidgetFn: unbounded fn Lx, Text, [Text] -> Bool
/// ```
pub fn pure_widget_fn_f(lx_p0: &crate::lower::Lx, qk_p1: &crate::prelude::Text, seen_p2: &crate::prelude::Array<crate::prelude::Text>) -> bool {
    if crate::check::types::has_text_f(seen_p2, qk_p1) {
        true
    } else {
        {
            let is_widget_p3 = match crate::prelude::get(&lx_p0.g_p.vals_p, qk_p1) {
                ::std::option::Option::Some(v_p6) => 'm58737: {
                    let scrutinee = &v_p6.scheme_p.ty_p;
                    if let crate::check::types::Ty::TyFn(_, ps_p7, m58737_0_2) = scrutinee && let crate::check::types::Ty::TyAt(o_p8, _) = &**m58737_0_2 {
                        break 'm58737 crate::prelude::fold(ps_p7, &false, &(|found_p9: &bool, p_pa: &crate::check::types::Ty| *found_p9 || match p_pa {
                            crate::check::types::Ty::TyElem(_, po_pb) => &**po_pb == &**o_p8,
                            _ => false,
                        }));
                    }
                    false
                },
                ::std::option::Option::None => false,
            };
            let defs_p4 = crate::prelude::filter(&lx_p0.g_p.defs_p, &(|d_pc: &crate::check::env::Def| &d_pc.qk_p == qk_p1));
            let clauses_p5 = crate::lower::jobs::clauses_of_f(&lx_p0.g_p, qk_p1);
            ((is_widget_p3 && (&crate::prelude::len(&defs_p4) > &crate::prelude::Nat::from(0u32))) && (&crate::prelude::len(&clauses_p5) > &crate::prelude::Nat::from(0u32))) && crate::prelude::run_to_end(crate::prelude::fold_job(defs_p4.clone(), true, {
                let lx_p0x = lx_p0.clone();
                let seen_p2x = seen_p2.clone();
                let qk_p1x = qk_p1.clone();
                ::std::rc::Rc::new(move |(p0, p1): (bool, crate::check::env::Def)| {
                    let lx_p0xy = lx_p0x.clone();
                    let seen_p2xy = seen_p2x.clone();
                    let qk_p1xy = qk_p1x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let ok_pd = p0;
                        let d_pe = p1;
                        if ok_pd {
                            crate::prelude::fold_job(crate::lower::jobs::def_clauses_f(&d_pe, &crate::prelude::Array::new()), true, {
                                let lx_p0xyx = lx_p0xy.clone();
                                let d_pex = d_pe.clone();
                                let seen_p2xyx = seen_p2xy.clone();
                                let qk_p1xyx = qk_p1xy.clone();
                                ::std::rc::Rc::new(move |(p0, p1): (bool, crate::syntax::decls::FnClause)| {
                                    let lx_p0xyxy = lx_p0xyx.clone();
                                    let d_pexy = d_pex.clone();
                                    let seen_p2xyxy = seen_p2xyx.clone();
                                    let qk_p1xyxy = qk_p1xyx.clone();
                                    crate::prelude::entered(crate::prelude::once_job(move || {
                                        let ok2_pf = p0;
                                        let c_pg = p1;
                                        if ok2_pf {
                                            match &c_pg.body_p {
                                                crate::syntax::decls::FnBody::BodyExpr(x_ph) => ::prism_rtl::Turn::More(::std::rc::Rc::new(PureBlueprintExpr { lx_p0: in_module_f(&lx_p0xyxy, &d_pexy.file_p, &d_pexy.home_p), e_p1: x_ph.clone(), seen_p2: crate::prelude::push(&seen_p2xyxy, &qk_p1xyxy) })),
                                                crate::syntax::decls::FnBody::BodyBlock(b_pi) => ::prism_rtl::Turn::More(::std::rc::Rc::new(PureBlueprintBlock { lx_p0: in_module_f(&lx_p0xyxy, &d_pexy.file_p, &d_pexy.home_p), b_p1: b_pi.clone(), seen_p2: crate::prelude::push(&seen_p2xyxy, &qk_p1xyxy) })),
                                            }
                                        } else {
                                            ::prism_rtl::Turn::Finished(false)
                                        }
                                    }))
                                }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::syntax::decls::FnClause)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
                            }).cycle()
                        } else {
                            ::prism_rtl::Turn::Finished(false)
                        }
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::check::env::Def)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
            }))
        }
    }
}

/// The step machine of `PureWidgetFn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PureWidgetFn: unbounded fn Lx, Text, [Text] -> Bool
/// ```
pub struct PureWidgetFn {
    pub lx_p0: crate::lower::Lx,
    pub qk_p1: crate::prelude::Text,
    pub seen_p2: crate::prelude::Array<crate::prelude::Text>,
}

impl ::prism_rtl::Job<bool> for PureWidgetFn {
    fn cycle(&self) -> ::prism_rtl::Turn<bool> {
        let lx_p0 = &self.lx_p0;
        let qk_p1 = &self.qk_p1;
        let seen_p2 = &self.seen_p2;
        if crate::check::types::has_text_f(seen_p2, qk_p1) {
            ::prism_rtl::Turn::Finished(true)
        } else {
            {
                let is_widget_p3 = match crate::prelude::get(&lx_p0.g_p.vals_p, qk_p1) {
                    ::std::option::Option::Some(v_p6) => 'm58737: {
                        let scrutinee = &v_p6.scheme_p.ty_p;
                        if let crate::check::types::Ty::TyFn(_, ps_p7, m58737_0_2) = scrutinee && let crate::check::types::Ty::TyAt(o_p8, _) = &**m58737_0_2 {
                            break 'm58737 crate::prelude::fold(ps_p7, &false, &(|found_p9: &bool, p_pa: &crate::check::types::Ty| *found_p9 || match p_pa {
                                crate::check::types::Ty::TyElem(_, po_pb) => &**po_pb == &**o_p8,
                                _ => false,
                            }));
                        }
                        false
                    },
                    ::std::option::Option::None => false,
                };
                let defs_p4 = crate::prelude::filter(&lx_p0.g_p.defs_p, &(|d_pc: &crate::check::env::Def| &d_pc.qk_p == qk_p1));
                let clauses_p5 = crate::lower::jobs::clauses_of_f(&lx_p0.g_p, qk_p1);
                if (is_widget_p3 && (&crate::prelude::len(&defs_p4) > &crate::prelude::Nat::from(0u32))) && (&crate::prelude::len(&clauses_p5) > &crate::prelude::Nat::from(0u32)) {
                    crate::prelude::fold_job(defs_p4.clone(), true, {
                        let lx_p0x = lx_p0.clone();
                        let seen_p2x = seen_p2.clone();
                        let qk_p1x = qk_p1.clone();
                        ::std::rc::Rc::new(move |(p0, p1): (bool, crate::check::env::Def)| {
                            let lx_p0xy = lx_p0x.clone();
                            let seen_p2xy = seen_p2x.clone();
                            let qk_p1xy = qk_p1x.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let ok_pd = p0;
                                let d_pe = p1;
                                if ok_pd {
                                    crate::prelude::fold_job(crate::lower::jobs::def_clauses_f(&d_pe, &crate::prelude::Array::new()), true, {
                                        let lx_p0xyx = lx_p0xy.clone();
                                        let d_pex = d_pe.clone();
                                        let seen_p2xyx = seen_p2xy.clone();
                                        let qk_p1xyx = qk_p1xy.clone();
                                        ::std::rc::Rc::new(move |(p0, p1): (bool, crate::syntax::decls::FnClause)| {
                                            let lx_p0xyxy = lx_p0xyx.clone();
                                            let d_pexy = d_pex.clone();
                                            let seen_p2xyxy = seen_p2xyx.clone();
                                            let qk_p1xyxy = qk_p1xyx.clone();
                                            crate::prelude::entered(crate::prelude::once_job(move || {
                                                let ok2_pf = p0;
                                                let c_pg = p1;
                                                if ok2_pf {
                                                    match &c_pg.body_p {
                                                        crate::syntax::decls::FnBody::BodyExpr(x_ph) => ::prism_rtl::Turn::More(::std::rc::Rc::new(PureBlueprintExpr { lx_p0: in_module_f(&lx_p0xyxy, &d_pexy.file_p, &d_pexy.home_p), e_p1: x_ph.clone(), seen_p2: crate::prelude::push(&seen_p2xyxy, &qk_p1xyxy) })),
                                                        crate::syntax::decls::FnBody::BodyBlock(b_pi) => ::prism_rtl::Turn::More(::std::rc::Rc::new(PureBlueprintBlock { lx_p0: in_module_f(&lx_p0xyxy, &d_pexy.file_p, &d_pexy.home_p), b_p1: b_pi.clone(), seen_p2: crate::prelude::push(&seen_p2xyxy, &qk_p1xyxy) })),
                                                    }
                                                } else {
                                                    ::prism_rtl::Turn::Finished(false)
                                                }
                                            }))
                                        }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::syntax::decls::FnClause)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
                                    }).cycle()
                                } else {
                                    ::prism_rtl::Turn::Finished(false)
                                }
                            }))
                        }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::check::env::Def)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
                    }).cycle()
                } else {
                    ::prism_rtl::Turn::Finished(false)
                }
            }
        }
    }
}

/// `Start PureWidgetFn, x`: what the function value is when passed to `@Run`.
pub fn start_pure_widget_fn_f(lx_p0: crate::lower::Lx, qk_p1: crate::prelude::Text, seen_p2: crate::prelude::Array<crate::prelude::Text>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>> {
    ::std::rc::Rc::new(PureWidgetFn { lx_p0, qk_p1, seen_p2 })
}

/// ```prism
/// PureBlueprintExpr: unbounded fn Lx, Expr, [Text] -> Bool
/// ```
pub fn pure_blueprint_expr_f(lx_p0: &crate::lower::Lx, e_p1: &crate::syntax::Expr, seen_p2: &crate::prelude::Array<crate::prelude::Text>) -> bool {
    match &*e_p1.kind_p {
        crate::syntax::ExprKind::EFreeSigil(m59526_0_0, _) if (m59526_0_0 == &crate::prelude::Text::lit("@")) => true,
        crate::syntax::ExprKind::EGroup(x_p3) => pure_blueprint_expr_f(lx_p0, &**x_p3, seen_p2),
        crate::syntax::ExprKind::EMatch(_, arms_p4) => crate::prelude::run_to_end(crate::prelude::fold_job(arms_p4.clone(), true, {
            let lx_p0x = lx_p0.clone();
            let seen_p2x = seen_p2.clone();
            ::std::rc::Rc::new(move |(p0, p1): (bool, crate::syntax::Arm)| {
                let lx_p0xy = lx_p0x.clone();
                let seen_p2xy = seen_p2x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let ok_p5 = p0;
                    let a_p6 = p1;
                    if ok_p5 {
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(PureBlueprintBlock { lx_p0: lx_p0xy.clone(), b_p1: a_p6.body_p.clone(), seen_p2: seen_p2xy.clone() }))
                    } else {
                        ::prism_rtl::Turn::Finished(false)
                    }
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::syntax::Arm)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
        })),
        crate::syntax::ExprKind::EIf(_, yes_p7, ::std::option::Option::Some(no_p8)) => pure_blueprint_block_f(lx_p0, yes_p7, seen_p2) && pure_blueprint_block_f(lx_p0, no_p8, seen_p2),
        crate::syntax::ExprKind::ECall(c_p9, _, _, _) => {
            let qk_pa = blueprint_qk_f(lx_p0, &**c_p9);
            (&qk_pa == &crate::prelude::Text::lit("Prelude.@Element")) || pure_widget_fn_f(lx_p0, &qk_pa, seen_p2)
        },
        _ => false,
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `PureBlueprintExpr`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PureBlueprintExpr: unbounded fn Lx, Expr, [Text] -> Bool
/// ```
pub struct PureBlueprintExpr {
    pub lx_p0: crate::lower::Lx,
    pub e_p1: crate::syntax::Expr,
    pub seen_p2: crate::prelude::Array<crate::prelude::Text>,
}

impl ::prism_rtl::Job<bool> for PureBlueprintExpr {
    fn cycle(&self) -> ::prism_rtl::Turn<bool> {
        let lx_p0 = &self.lx_p0;
        let e_p1 = &self.e_p1;
        let seen_p2 = &self.seen_p2;
        match &*e_p1.kind_p {
            crate::syntax::ExprKind::EFreeSigil(m59526_0_0, _) if (m59526_0_0 == &crate::prelude::Text::lit("@")) => ::prism_rtl::Turn::Finished(true),
            crate::syntax::ExprKind::EGroup(x_p3) => ::prism_rtl::Turn::More(::std::rc::Rc::new(PureBlueprintExpr { lx_p0: lx_p0.clone(), e_p1: (**x_p3).clone(), seen_p2: seen_p2.clone() })),
            crate::syntax::ExprKind::EMatch(_, arms_p4) => crate::prelude::fold_job(arms_p4.clone(), true, {
                let lx_p0x = lx_p0.clone();
                let seen_p2x = seen_p2.clone();
                ::std::rc::Rc::new(move |(p0, p1): (bool, crate::syntax::Arm)| {
                    let lx_p0xy = lx_p0x.clone();
                    let seen_p2xy = seen_p2x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let ok_p5 = p0;
                        let a_p6 = p1;
                        if ok_p5 {
                            ::prism_rtl::Turn::More(::std::rc::Rc::new(PureBlueprintBlock { lx_p0: lx_p0xy.clone(), b_p1: a_p6.body_p.clone(), seen_p2: seen_p2xy.clone() }))
                        } else {
                            ::prism_rtl::Turn::Finished(false)
                        }
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::syntax::Arm)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
            }).cycle(),
            crate::syntax::ExprKind::EIf(_, yes_p7, ::std::option::Option::Some(no_p8)) => {
                let lx_p0x = lx_p0.clone();
                let no_p8x = no_p8.clone();
                let seen_p2x = seen_p2.clone();
                let yes_p7x = yes_p7.clone();
                crate::prelude::call_then(start_pure_blueprint_block_f(lx_p0x.clone(), yes_p7x.clone(), seen_p2x.clone()), move |pure_blueprint_block_f_59741: bool| if pure_blueprint_block_f_59741 {
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(PureBlueprintBlock { lx_p0: lx_p0x.clone(), b_p1: no_p8x.clone(), seen_p2: seen_p2x.clone() }))
                } else {
                    ::prism_rtl::Turn::Finished(false)
                })
            },
            crate::syntax::ExprKind::ECall(c_p9, _, _, _) => {
                let qk_pa = blueprint_qk_f(lx_p0, &**c_p9);
                if &qk_pa == &crate::prelude::Text::lit("Prelude.@Element") {
                    ::prism_rtl::Turn::Finished(true)
                } else {
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(PureWidgetFn { lx_p0: lx_p0.clone(), qk_p1: qk_pa.clone(), seen_p2: seen_p2.clone() }))
                }
            },
            _ => ::prism_rtl::Turn::Finished(false),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start PureBlueprintExpr, x`: what the function value is when passed to `@Run`.
pub fn start_pure_blueprint_expr_f(lx_p0: crate::lower::Lx, e_p1: crate::syntax::Expr, seen_p2: crate::prelude::Array<crate::prelude::Text>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>> {
    ::std::rc::Rc::new(PureBlueprintExpr { lx_p0, e_p1, seen_p2 })
}

/// ```prism
/// PureBlueprintBlock: unbounded fn Lx, Block, [Text] -> Bool
/// ```
pub fn pure_blueprint_block_f(lx_p0: &crate::lower::Lx, b_p1: &crate::syntax::Block, seen_p2: &crate::prelude::Array<crate::prelude::Text>) -> bool {
    let n_p3 = crate::prelude::len(&b_p1.stmts_p);
    let k_p4 = crate::prelude::or(&(&n_p3).checked_sub(&crate::prelude::Nat::from(1u32)), &crate::prelude::Nat::from(0u32));
    let lets_p5 = crate::prelude::fold(&crate::prelude::take(&b_p1.stmts_p, &k_p4), &true, &(|ok_p7: &bool, st_p8: &crate::syntax::Stmt| *ok_p7 && match &st_p8.kind_p {
        crate::syntax::StmtKind::SLet(_, _, _) => true,
        _ => false,
    }));
    let last_p6 = crate::prelude::or(&crate::prelude::index(&b_p1.stmts_p, &k_p4), &crate::syntax::Stmt { kind_p: crate::syntax::StmtKind::SExpr(crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::EError), span_p: b_p1.span_p.clone() }), span_p: b_p1.span_p.clone() });
    ((&n_p3 > &crate::prelude::Nat::from(0u32)) && lets_p5) && match &last_p6.kind_p {
        crate::syntax::StmtKind::SExpr(x_p9) => pure_blueprint_expr_f(lx_p0, x_p9, seen_p2),
        _ => false,
    }
}

/// The step machine of `PureBlueprintBlock`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PureBlueprintBlock: unbounded fn Lx, Block, [Text] -> Bool
/// ```
pub struct PureBlueprintBlock {
    pub lx_p0: crate::lower::Lx,
    pub b_p1: crate::syntax::Block,
    pub seen_p2: crate::prelude::Array<crate::prelude::Text>,
}

impl ::prism_rtl::Job<bool> for PureBlueprintBlock {
    fn cycle(&self) -> ::prism_rtl::Turn<bool> {
        let lx_p0 = &self.lx_p0;
        let b_p1 = &self.b_p1;
        let seen_p2 = &self.seen_p2;
        let n_p3 = crate::prelude::len(&b_p1.stmts_p);
        let k_p4 = crate::prelude::or(&(&n_p3).checked_sub(&crate::prelude::Nat::from(1u32)), &crate::prelude::Nat::from(0u32));
        let lets_p5 = crate::prelude::fold(&crate::prelude::take(&b_p1.stmts_p, &k_p4), &true, &(|ok_p7: &bool, st_p8: &crate::syntax::Stmt| *ok_p7 && match &st_p8.kind_p {
            crate::syntax::StmtKind::SLet(_, _, _) => true,
            _ => false,
        }));
        let last_p6 = crate::prelude::or(&crate::prelude::index(&b_p1.stmts_p, &k_p4), &crate::syntax::Stmt { kind_p: crate::syntax::StmtKind::SExpr(crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::EError), span_p: b_p1.span_p.clone() }), span_p: b_p1.span_p.clone() });
        if (&n_p3 > &crate::prelude::Nat::from(0u32)) && lets_p5 {
            match &last_p6.kind_p {
                crate::syntax::StmtKind::SExpr(x_p9) => ::prism_rtl::Turn::More(::std::rc::Rc::new(PureBlueprintExpr { lx_p0: lx_p0.clone(), e_p1: x_p9.clone(), seen_p2: seen_p2.clone() })),
                _ => ::prism_rtl::Turn::Finished(false),
            }
        } else {
            ::prism_rtl::Turn::Finished(false)
        }
    }
}

/// `Start PureBlueprintBlock, x`: what the function value is when passed to `@Run`.
pub fn start_pure_blueprint_block_f(lx_p0: crate::lower::Lx, b_p1: crate::syntax::Block, seen_p2: crate::prelude::Array<crate::prelude::Text>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>> {
    ::std::rc::Rc::new(PureBlueprintBlock { lx_p0, b_p1, seen_p2 })
}

/// ```prism
/// ValOf: fn Lx, Text -> ValInfo
/// ```
pub fn val_of_f(lx_p0: &crate::lower::Lx, qk_p1: &crate::prelude::Text) -> crate::check::env::ValInfo {
    match crate::prelude::get(&lx_p0.g_p.vals_p, qk_p1) {
        ::std::option::Option::Some(v_p2) => v_p2,
        ::std::option::Option::None => {
            let d_p3 = crate::prelude::fold(&lx_p0.g_p.defs_p, &crate::check::env::decls::dummy_def_p(), &(|found_p4: &crate::check::env::Def, df_p5: &crate::check::env::Def| if &df_p5.qk_p == qk_p1 { df_p5.clone() } else { found_p4.clone() }));
            crate::check::env::ValInfo { qk_p: qk_p1.clone(), scheme_p: crate::check::types::schemes::mono_f(&crate::check::types::Ty::TyErr), sort_p: crate::prelude::Text::lit("fn"), has_sig_p: false, home_p: d_p3.home_p.clone(), file_p: d_p3.file_p.clone(), span_p: d_p3.span_p.clone() }
        },
    }
}

/// ```prism
/// ProgDefOf: unbounded fn Lx, Text -> ProgDef
/// ```
pub fn prog_def_of_f(lx_p0: &crate::lower::Lx, qk_p1: &crate::prelude::Text) -> crate::lower::model::ProgDef {
    let v_p2 = val_of_f(lx_p0, qk_p1);
    let ptys_p3 = match &v_p2.scheme_p.ty_p {
        crate::check::types::Ty::TyFn(_, ps_p9, _) => ps_p9.clone(),
        _ => crate::prelude::Array::new(),
    };
    let lxm_p4 = in_module_at_f(lx_p0, &v_p2.file_p, &v_p2.home_p, &crate::prelude::Text::lit("\0main"));
    let params_p5 = crate::prelude::run_to_end(crate::prelude::each_job(crate::check::errors::range0_f(&crate::prelude::len(&ptys_p3)), {
        let lxm_p4x = lxm_p4.clone();
        let ptys_p3x = ptys_p3.clone();
        ::std::rc::Rc::new(move |p0: crate::prelude::Nat| {
            let lxm_p4xy = lxm_p4x.clone();
            let ptys_p3xy = ptys_p3x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let i_pa = p0;
                crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lxm_p4xy.clone(), crate::lower::types::peel_f(&crate::prelude::or(&crate::prelude::index(&ptys_p3xy, &i_pa), &crate::check::types::Ty::TyErr))), move |out_ty_of_f_61169: crate::lower::model::OutTy| ::prism_rtl::Turn::Finished((crate::prelude::Text::from(format!("arg{}", &i_pa)), out_ty_of_f_61169)))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Text, crate::lower::model::OutTy)>>>
    }));
    let node_p6 = crate::prelude::Text::from(format!("{}::{}", &crate::lower::rust_mod_name_f(&v_p2.home_p), &crate::lower::node_name_f(qk_p1)));
    let fams_p7 = crate::prelude::or(&crate::prelude::get(&lx_p0.g_p.mods_p, &v_p2.home_p), &crate::check::env::reading::dummy_mod_p()).emit_rw_p.fams_p.clone();
    let world_p8 = if crate::check::types::has_text_f(&fams_p7, &crate::prelude::Text::lit("Gui")) {
        crate::prelude::Text::lit("canvas")
    } else {
        if crate::check::types::has_text_f(&fams_p7, &crate::prelude::Text::lit("Ui")) {
            crate::prelude::Text::lit("none")
        } else {
            crate::prelude::Text::lit("cli")
        }
    };
    crate::lower::model::ProgDef { name_p: crate::prelude::Text::from(format!("{}Program", &crate::lower::camel_f(&crate::check::types::bare_name_f(qk_p1)))), prism_p: crate::syntax::lexer::chars::after_first_f(&crate::check::types::bare_name_f(qk_p1)), node_p: node_p6.clone(), params_p: params_p5.clone(), fallible_p: true, world_p: world_p8.clone() }
}

/// The step machine of `ProgDefOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ProgDefOf: unbounded fn Lx, Text -> ProgDef
/// ```
pub struct ProgDefOf {
    pub lx_p0: crate::lower::Lx,
    pub qk_p1: crate::prelude::Text,
}

impl ::prism_rtl::Job<crate::lower::model::ProgDef> for ProgDefOf {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::lower::model::ProgDef> {
        let lx_p0 = &self.lx_p0;
        let qk_p1 = &self.qk_p1;
        let v_p2 = val_of_f(lx_p0, qk_p1);
        let ptys_p3 = match &v_p2.scheme_p.ty_p {
            crate::check::types::Ty::TyFn(_, ps_p9, _) => ps_p9.clone(),
            _ => crate::prelude::Array::new(),
        };
        let lxm_p4 = in_module_at_f(lx_p0, &v_p2.file_p, &v_p2.home_p, &crate::prelude::Text::lit("\0main"));
        let lx_p0x = lx_p0.clone();
        let qk_p1x = qk_p1.clone();
        crate::prelude::call_value(crate::prelude::each_job(crate::check::errors::range0_f(&crate::prelude::len(&ptys_p3)), {
            let lxm_p4x = lxm_p4.clone();
            let ptys_p3x = ptys_p3.clone();
            ::std::rc::Rc::new(move |p0: crate::prelude::Nat| {
                let lxm_p4xy = lxm_p4x.clone();
                let ptys_p3xy = ptys_p3x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let i_pa = p0;
                    crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lxm_p4xy.clone(), crate::lower::types::peel_f(&crate::prelude::or(&crate::prelude::index(&ptys_p3xy, &i_pa), &crate::check::types::Ty::TyErr))), move |out_ty_of_f_61169: crate::lower::model::OutTy| ::prism_rtl::Turn::Finished((crate::prelude::Text::from(format!("arg{}", &i_pa)), out_ty_of_f_61169)))
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Text, crate::lower::model::OutTy)>>>
        }), move |each_61125: crate::prelude::Array<(crate::prelude::Text, crate::lower::model::OutTy)>| {
            let params_p5 = each_61125;
            let node_p6 = crate::prelude::Text::from(format!("{}::{}", &crate::lower::rust_mod_name_f(&v_p2.home_p), &crate::lower::node_name_f(&qk_p1x)));
            let fams_p7 = crate::prelude::or(&crate::prelude::get(&lx_p0x.g_p.mods_p, &v_p2.home_p), &crate::check::env::reading::dummy_mod_p()).emit_rw_p.fams_p.clone();
            let world_p8 = if crate::check::types::has_text_f(&fams_p7, &crate::prelude::Text::lit("Gui")) {
                crate::prelude::Text::lit("canvas")
            } else {
                if crate::check::types::has_text_f(&fams_p7, &crate::prelude::Text::lit("Ui")) {
                    crate::prelude::Text::lit("none")
                } else {
                    crate::prelude::Text::lit("cli")
                }
            };
            ::prism_rtl::Turn::Finished(crate::lower::model::ProgDef { name_p: crate::prelude::Text::from(format!("{}Program", &crate::lower::camel_f(&crate::check::types::bare_name_f(&qk_p1x)))), prism_p: crate::syntax::lexer::chars::after_first_f(&crate::check::types::bare_name_f(&qk_p1x)), node_p: node_p6.clone(), params_p: params_p5.clone(), fallible_p: true, world_p: world_p8.clone() })
        })
    }
}

/// `Start ProgDefOf, x`: what the function value is when passed to `@Run`.
pub fn start_prog_def_of_f(lx_p0: crate::lower::Lx, qk_p1: crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::ProgDef>> {
    ::std::rc::Rc::new(ProgDefOf { lx_p0, qk_p1 })
}

/// ```prism
/// JobRoots: unbounded fn Lx -> [Text]
/// ```
pub fn job_roots_f(lx_p0: &crate::lower::Lx) -> crate::prelude::Array<crate::prelude::Text> {
    let direct_p1 = crate::prelude::run_to_end(crate::prelude::fold_job(lx_p0.g_p.defs_p.clone(), crate::prelude::Array::new(), {
        let lx_p0x = lx_p0.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::check::env::Def)| {
            let lx_p0xy = lx_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_p2 = p0;
                let d_p3 = p1;
                {
                    let lxd_p4 = in_module_f(&lx_p0xy, &d_p3.file_p, &d_p3.home_p);
                    crate::prelude::call_then(start_run_targets_f(lxd_p4.clone(), d_p3.clone()), move |run_targets_f_61996: crate::prelude::Array<crate::prelude::Text>| crate::prelude::call_then(start_unbounded_values_f(lxd_p4.clone(), d_p3.clone()), move |unbounded_values_f_62018: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&crate::check::types::union_texts_f(&acc_p2, &run_targets_f_61996), &unbounded_values_f_62018))))
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::check::env::Def)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>
    }));
    crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::Nat::from(8u32)), direct_p1.clone(), {
        let lx_p0x = lx_p0.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::prelude::Nat)| {
            let lx_p0xy = lx_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_p5 = p0;
                let _ = p1;
                crate::prelude::fold_job(acc_p5.clone(), acc_p5.clone(), {
                    let lx_p0xyx = lx_p0xy.clone();
                    ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::prelude::Text)| {
                        let lx_p0xyxy = lx_p0xyx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let a_p6 = p0;
                            let qk_p7 = p1;
                            crate::prelude::call_then(start_tail_targets_f(lx_p0xyxy.clone(), qk_p7.clone()), move |tail_targets_f_62125: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&a_p6, &tail_targets_f_62125)))
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::prelude::Text)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>
                }).cycle()
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>
    }))
}

/// The step machine of `JobRoots`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// JobRoots: unbounded fn Lx -> [Text]
/// ```
pub struct JobRoots {
    pub lx_p0: crate::lower::Lx,
}

impl ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>> for JobRoots {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<crate::prelude::Text>> {
        let lx_p0 = &self.lx_p0;
        let lx_p0x = lx_p0.clone();
        crate::prelude::call_value(crate::prelude::fold_job(lx_p0x.g_p.defs_p.clone(), crate::prelude::Array::new(), {
            let lx_p0xx = lx_p0x.clone();
            ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::check::env::Def)| {
                let lx_p0xxy = lx_p0xx.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let acc_p2 = p0;
                    let d_p3 = p1;
                    {
                        let lxd_p4 = in_module_f(&lx_p0xxy, &d_p3.file_p, &d_p3.home_p);
                        crate::prelude::call_then(start_run_targets_f(lxd_p4.clone(), d_p3.clone()), move |run_targets_f_61996: crate::prelude::Array<crate::prelude::Text>| crate::prelude::call_then(start_unbounded_values_f(lxd_p4.clone(), d_p3.clone()), move |unbounded_values_f_62018: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&crate::check::types::union_texts_f(&acc_p2, &run_targets_f_61996), &unbounded_values_f_62018))))
                    }
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::check::env::Def)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>
        }), move |fold_61881: crate::prelude::Array<crate::prelude::Text>| {
            let direct_p1 = fold_61881;
            crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::Nat::from(8u32)), direct_p1.clone(), {
                let lx_p0xx = lx_p0x.clone();
                ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::prelude::Nat)| {
                    let lx_p0xxy = lx_p0xx.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let acc_p5 = p0;
                        let _ = p1;
                        crate::prelude::fold_job(acc_p5.clone(), acc_p5.clone(), {
                            let lx_p0xxyx = lx_p0xxy.clone();
                            ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::prelude::Text)| {
                                let lx_p0xxyxy = lx_p0xxyx.clone();
                                crate::prelude::entered(crate::prelude::once_job(move || {
                                    let a_p6 = p0;
                                    let qk_p7 = p1;
                                    crate::prelude::call_then(start_tail_targets_f(lx_p0xxyxy.clone(), qk_p7.clone()), move |tail_targets_f_62125: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&a_p6, &tail_targets_f_62125)))
                                }))
                            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::prelude::Text)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>
                        }).cycle()
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>
            }).cycle()
        })
    }
}

/// `Start JobRoots, x`: what the function value is when passed to `@Run`.
pub fn start_job_roots_f(lx_p0: crate::lower::Lx) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>> {
    ::std::rc::Rc::new(JobRoots { lx_p0 })
}

/// ```prism
/// UnboundedValues: unbounded fn Lx, Def -> [Text]
/// ```
pub fn unbounded_values_f(lx_p0: &crate::lower::Lx, d_p1: &crate::check::env::Def) -> crate::prelude::Array<crate::prelude::Text> {
    let es_p2 = match &d_p1.body_p {
        crate::check::env::DefBody::DbWidget(w_p4) => crate::check::typed::print::block_exprs_f(&w_p4.body_p),
        crate::check::env::DefBody::DbFn(cs_p5) => crate::prelude::run_to_end(crate::prelude::fold_job(cs_p5.clone(), crate::prelude::Array::new(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::syntax::Expr>, crate::syntax::decls::FnClause)| crate::prelude::entered(crate::prelude::once_job(move || {
            let acc_p6 = p0;
            let c_p7 = p1;
            crate::prelude::call_then(crate::check::typed::print::start_body_exprs_f(c_p7.body_p.clone()), move |body_exprs_f_62476: crate::prelude::Array<crate::syntax::Expr>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_p6, &body_exprs_f_62476)))
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::syntax::Expr>, crate::syntax::decls::FnClause)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::syntax::Expr>>>>)),
        crate::check::env::DefBody::DbLet(l_p8) => crate::check::typed::print::exprs_in_f(&l_p8.value_p),
        _ => crate::prelude::Array::new(),
    };
    let callees_p3 = crate::prelude::fold(&es_p2, &crate::prelude::Array::new(), &(|acc_p9: &crate::prelude::Array<crate::prelude::Text>, e_pa: &crate::syntax::Expr| match &*e_pa.kind_p {
        crate::syntax::ExprKind::ECall(c_pb, _, _, _) => crate::prelude::push(acc_p9, &crate::lower::place_key_f(lx_p0, &c_pb.span_p)),
        _ => acc_p9.clone(),
    }));
    crate::prelude::fold(&es_p2, &crate::prelude::Array::new(), &(|acc_pc: &crate::prelude::Array<crate::prelude::Text>, e_pd: &crate::syntax::Expr| match &*e_pd.kind_p {
        crate::syntax::ExprKind::EName(n_pe) => if crate::check::types::has_text_f(&callees_p3, &crate::lower::place_key_f(lx_p0, &e_pd.span_p)) {
            acc_pc.clone()
        } else {
            {
                let (q_of, _) = crate::check::env::names::resolve_value_f(&lx_p0.g_p, &lx_p0.home_p, n_pe);
                match &q_of {
                    ::std::option::Option::Some(q_pg) => if is_unbounded_f(lx_p0, q_pg) {
                        crate::check::types::add_text_f(acc_pc, q_pg)
                    } else {
                        acc_pc.clone()
                    },
                    ::std::option::Option::None => acc_pc.clone(),
                }
            }
        },
        _ => acc_pc.clone(),
    }))
}

/// The step machine of `UnboundedValues`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UnboundedValues: unbounded fn Lx, Def -> [Text]
/// ```
pub struct UnboundedValues {
    pub lx_p0: crate::lower::Lx,
    pub d_p1: crate::check::env::Def,
}

impl ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>> for UnboundedValues {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<crate::prelude::Text>> {
        let lx_p0 = &self.lx_p0;
        let d_p1 = &self.d_p1;
        let lx_p0z = lx_p0.clone();
        let k_let62360 = move |v62360: crate::prelude::Array<crate::syntax::Expr>| {
            let es_p2 = v62360;
            let callees_p3 = crate::prelude::fold(&es_p2, &crate::prelude::Array::new(), &(|acc_p9: &crate::prelude::Array<crate::prelude::Text>, e_pa: &crate::syntax::Expr| match &*e_pa.kind_p {
                crate::syntax::ExprKind::ECall(c_pb, _, _, _) => crate::prelude::push(acc_p9, &crate::lower::place_key_f(&lx_p0z, &c_pb.span_p)),
                _ => acc_p9.clone(),
            }));
            ::prism_rtl::Turn::Finished(crate::prelude::fold(&es_p2, &crate::prelude::Array::new(), &(|acc_pc: &crate::prelude::Array<crate::prelude::Text>, e_pd: &crate::syntax::Expr| match &*e_pd.kind_p {
                crate::syntax::ExprKind::EName(n_pe) => if crate::check::types::has_text_f(&callees_p3, &crate::lower::place_key_f(&lx_p0z, &e_pd.span_p)) {
                    acc_pc.clone()
                } else {
                    {
                        let (q_of, _) = crate::check::env::names::resolve_value_f(&lx_p0z.g_p, &lx_p0z.home_p, n_pe);
                        match &q_of {
                            ::std::option::Option::Some(q_pg) => if is_unbounded_f(&lx_p0z, q_pg) {
                                crate::check::types::add_text_f(acc_pc, q_pg)
                            } else {
                                acc_pc.clone()
                            },
                            ::std::option::Option::None => acc_pc.clone(),
                        }
                    }
                },
                _ => acc_pc.clone(),
            })))
        };
        match d_p1.body_p.clone() {
            crate::check::env::DefBody::DbWidget(w_p4) => crate::prelude::call_then(crate::check::typed::print::start_block_exprs_f(w_p4.body_p.clone()), move |block_exprs_f_62403: crate::prelude::Array<crate::syntax::Expr>| k_let62360(block_exprs_f_62403)),
            crate::check::env::DefBody::DbFn(cs_p5) => crate::prelude::call_value(crate::prelude::fold_job(cs_p5.clone(), crate::prelude::Array::new(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::syntax::Expr>, crate::syntax::decls::FnClause)| crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_p6 = p0;
                let c_p7 = p1;
                crate::prelude::call_then(crate::check::typed::print::start_body_exprs_f(c_p7.body_p.clone()), move |body_exprs_f_62476: crate::prelude::Array<crate::syntax::Expr>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_p6, &body_exprs_f_62476)))
            }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::syntax::Expr>, crate::syntax::decls::FnClause)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::syntax::Expr>>>>), move |fold_62438: crate::prelude::Array<crate::syntax::Expr>| k_let62360(fold_62438)),
            crate::check::env::DefBody::DbLet(l_p8) => crate::prelude::call_then(crate::check::typed::print::start_exprs_in_f(l_p8.value_p.clone()), move |exprs_in_f_62511: crate::prelude::Array<crate::syntax::Expr>| k_let62360(exprs_in_f_62511)),
            _ => k_let62360(crate::prelude::Array::new()),
        }
    }
}

/// `Start UnboundedValues, x`: what the function value is when passed to `@Run`.
pub fn start_unbounded_values_f(lx_p0: crate::lower::Lx, d_p1: crate::check::env::Def) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>> {
    ::std::rc::Rc::new(UnboundedValues { lx_p0, d_p1 })
}

/// ```prism
/// InPrelude: fn Lx, Text -> Bool
/// ```
pub fn in_prelude_f(lx_p0: &crate::lower::Lx, q_p1: &crate::prelude::Text) -> bool {
    match crate::prelude::get(&lx_p0.g_p.vals_p, q_p1) {
        ::std::option::Option::Some(v_p2) => &v_p2.home_p == &crate::prelude::Text::lit("Prelude"),
        ::std::option::Option::None => false,
    }
}

/// ```prism
/// IsColorPoly: fn Lx, Text -> Bool
/// ```
pub fn is_color_poly_f(lx_p0: &crate::lower::Lx, q_p1: &crate::prelude::Text) -> bool {
    match crate::prelude::get(&lx_p0.g_p.vals_p, q_p1) {
        ::std::option::Option::Some(v_p2) => match &v_p2.scheme_p.ty_p {
            crate::check::types::Ty::TyFn(crate::check::types::Col::CQ(_), _, _) => true,
            crate::check::types::Ty::TyFn(crate::check::types::Col::CRigid(_), _, _) => true,
            _ => false,
        },
        ::std::option::Option::None => false,
    }
}

/// ```prism
/// EntersAtOnce: fn Lx, Text, [Arg] -> Bool
/// ```
pub fn enters_at_once_f(lx_p0: &crate::lower::Lx, q_p1: &crate::prelude::Text, args_p2: &crate::prelude::Array<crate::syntax::Arg>) -> bool {
    is_color_poly_f(lx_p0, q_p1) && !crate::prelude::fold(args_p2, &false, &(|seen_p3: &bool, a_p4: &crate::syntax::Arg| *seen_p3 || is_unbounded_arg_f(lx_p0, a_p4)))
}

/// ```prism
/// IsUnboundedArg: fn Lx, Arg -> Bool
/// ```
pub fn is_unbounded_arg_f(lx_p0: &crate::lower::Lx, a_p1: &crate::syntax::Arg) -> bool {
    match crate::lower::types::peel_f(&crate::lower::type_at_f(lx_p0, &a_p1.value_p.span_p)) {
        crate::check::types::Ty::TyFn(crate::check::types::Col::CUnbound, _, _) => true,
        _ => false,
    }
}

/// ```prism
/// IsUnbounded: fn Lx, Text -> Bool
/// ```
pub fn is_unbounded_f(lx_p0: &crate::lower::Lx, q_p1: &crate::prelude::Text) -> bool {
    match crate::prelude::get(&lx_p0.g_p.vals_p, q_p1) {
        ::std::option::Option::Some(v_p2) => match &v_p2.scheme_p.ty_p {
            crate::check::types::Ty::TyFn(crate::check::types::Col::CBound, _, _) => false,
            crate::check::types::Ty::TyFn(_, _, _) => true,
            _ => false,
        },
        ::std::option::Option::None => false,
    }
}

/// ```prism
/// RunTargets: unbounded fn Lx, Def -> [Text]
/// ```
pub fn run_targets_f(lx_p0: &crate::lower::Lx, d_p1: &crate::check::env::Def) -> crate::prelude::Array<crate::prelude::Text> {
    let es_p2 = match &d_p1.body_p {
        crate::check::env::DefBody::DbWidget(w_p3) => crate::check::typed::print::block_exprs_f(&w_p3.body_p),
        crate::check::env::DefBody::DbFn(cs_p4) => crate::prelude::run_to_end(crate::prelude::fold_job(cs_p4.clone(), crate::prelude::Array::new(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::syntax::Expr>, crate::syntax::decls::FnClause)| crate::prelude::entered(crate::prelude::once_job(move || {
            let acc_p5 = p0;
            let c_p6 = p1;
            crate::prelude::call_then(crate::check::typed::print::start_body_exprs_f(c_p6.body_p.clone()), move |body_exprs_f_64705: crate::prelude::Array<crate::syntax::Expr>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_p5, &body_exprs_f_64705)))
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::syntax::Expr>, crate::syntax::decls::FnClause)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::syntax::Expr>>>>)),
        _ => crate::prelude::Array::new(),
    };
    crate::prelude::fold(&es_p2, &crate::prelude::Array::new(), &(|acc_p7: &crate::prelude::Array<crate::prelude::Text>, e_p8: &crate::syntax::Expr| match &*e_p8.kind_p {
        crate::syntax::ExprKind::ECall(c_p9, args_pa, _, _) => if &blueprint_qk_f(lx_p0, &**c_p9) == &crate::prelude::Text::lit("Prelude.@Run") {
            match crate::prelude::index(args_pa, &crate::prelude::Nat::from(0u32)) {
                ::std::option::Option::Some(a_pb) => match &*a_pb.value_p.kind_p {
                    crate::syntax::ExprKind::EName(n_pc) => {
                        let (q_od, _) = crate::check::env::names::resolve_value_f(&lx_p0.g_p, &lx_p0.home_p, n_pc);
                        match &q_od {
                            ::std::option::Option::Some(q_pe) => crate::check::types::add_text_f(acc_p7, q_pe),
                            ::std::option::Option::None => acc_p7.clone(),
                        }
                    },
                    _ => acc_p7.clone(),
                },
                ::std::option::Option::None => acc_p7.clone(),
            }
        } else {
            acc_p7.clone()
        },
        _ => acc_p7.clone(),
    }))
}

/// The step machine of `RunTargets`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RunTargets: unbounded fn Lx, Def -> [Text]
/// ```
pub struct RunTargets {
    pub lx_p0: crate::lower::Lx,
    pub d_p1: crate::check::env::Def,
}

impl ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>> for RunTargets {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<crate::prelude::Text>> {
        let lx_p0 = &self.lx_p0;
        let d_p1 = &self.d_p1;
        let lx_p0z = lx_p0.clone();
        let k_let64589 = move |v64589: crate::prelude::Array<crate::syntax::Expr>| {
            let es_p2 = v64589;
            ::prism_rtl::Turn::Finished(crate::prelude::fold(&es_p2, &crate::prelude::Array::new(), &(|acc_p7: &crate::prelude::Array<crate::prelude::Text>, e_p8: &crate::syntax::Expr| match &*e_p8.kind_p {
                crate::syntax::ExprKind::ECall(c_p9, args_pa, _, _) => if &blueprint_qk_f(&lx_p0z, &**c_p9) == &crate::prelude::Text::lit("Prelude.@Run") {
                    match crate::prelude::index(args_pa, &crate::prelude::Nat::from(0u32)) {
                        ::std::option::Option::Some(a_pb) => match &*a_pb.value_p.kind_p {
                            crate::syntax::ExprKind::EName(n_pc) => {
                                let (q_od, _) = crate::check::env::names::resolve_value_f(&lx_p0z.g_p, &lx_p0z.home_p, n_pc);
                                match &q_od {
                                    ::std::option::Option::Some(q_pe) => crate::check::types::add_text_f(acc_p7, q_pe),
                                    ::std::option::Option::None => acc_p7.clone(),
                                }
                            },
                            _ => acc_p7.clone(),
                        },
                        ::std::option::Option::None => acc_p7.clone(),
                    }
                } else {
                    acc_p7.clone()
                },
                _ => acc_p7.clone(),
            })))
        };
        match d_p1.body_p.clone() {
            crate::check::env::DefBody::DbWidget(w_p3) => crate::prelude::call_then(crate::check::typed::print::start_block_exprs_f(w_p3.body_p.clone()), move |block_exprs_f_64632: crate::prelude::Array<crate::syntax::Expr>| k_let64589(block_exprs_f_64632)),
            crate::check::env::DefBody::DbFn(cs_p4) => crate::prelude::call_value(crate::prelude::fold_job(cs_p4.clone(), crate::prelude::Array::new(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::syntax::Expr>, crate::syntax::decls::FnClause)| crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_p5 = p0;
                let c_p6 = p1;
                crate::prelude::call_then(crate::check::typed::print::start_body_exprs_f(c_p6.body_p.clone()), move |body_exprs_f_64705: crate::prelude::Array<crate::syntax::Expr>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_p5, &body_exprs_f_64705)))
            }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::syntax::Expr>, crate::syntax::decls::FnClause)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::syntax::Expr>>>>), move |fold_64667: crate::prelude::Array<crate::syntax::Expr>| k_let64589(fold_64667)),
            _ => k_let64589(crate::prelude::Array::new()),
        }
    }
}

/// `Start RunTargets, x`: what the function value is when passed to `@Run`.
pub fn start_run_targets_f(lx_p0: crate::lower::Lx, d_p1: crate::check::env::Def) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>> {
    ::std::rc::Rc::new(RunTargets { lx_p0, d_p1 })
}

/// ```prism
/// TailTargets: unbounded fn Lx, Text -> [Text]
/// ```
pub fn tail_targets_f(lx_p0: &crate::lower::Lx, qk_p1: &crate::prelude::Text) -> crate::prelude::Array<crate::prelude::Text> {
    let v_p2 = crate::prelude::or(&crate::prelude::get(&lx_p0.g_p.vals_p, qk_p1), &crate::check::env::builtin_f(qk_p1, &crate::check::types::schemes::mono_f(&crate::check::types::Ty::TyErr)));
    let lxm_p3 = in_module_f(lx_p0, &v_p2.file_p, &v_p2.home_p);
    crate::prelude::run_to_end(crate::prelude::fold_job(crate::lower::jobs::clauses_of_f(&lx_p0.g_p, qk_p1), crate::prelude::Array::new(), {
        let lxm_p3x = lxm_p3.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::syntax::decls::FnClause)| {
            let lxm_p3xy = lxm_p3x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_p4 = p0;
                let c_p5 = p1;
                crate::prelude::call_then(start_tails_of_body_f(lxm_p3xy.clone(), c_p5.body_p.clone()), move |tails_of_body_f_65584: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_p4, &tails_of_body_f_65584)))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::syntax::decls::FnClause)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>
    }))
}

/// The step machine of `TailTargets`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TailTargets: unbounded fn Lx, Text -> [Text]
/// ```
pub struct TailTargets {
    pub lx_p0: crate::lower::Lx,
    pub qk_p1: crate::prelude::Text,
}

impl ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>> for TailTargets {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<crate::prelude::Text>> {
        let lx_p0 = &self.lx_p0;
        let qk_p1 = &self.qk_p1;
        let v_p2 = crate::prelude::or(&crate::prelude::get(&lx_p0.g_p.vals_p, qk_p1), &crate::check::env::builtin_f(qk_p1, &crate::check::types::schemes::mono_f(&crate::check::types::Ty::TyErr)));
        let lxm_p3 = in_module_f(lx_p0, &v_p2.file_p, &v_p2.home_p);
        crate::prelude::fold_job(crate::lower::jobs::clauses_of_f(&lx_p0.g_p, qk_p1), crate::prelude::Array::new(), {
            let lxm_p3x = lxm_p3.clone();
            ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::syntax::decls::FnClause)| {
                let lxm_p3xy = lxm_p3x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let acc_p4 = p0;
                    let c_p5 = p1;
                    crate::prelude::call_then(start_tails_of_body_f(lxm_p3xy.clone(), c_p5.body_p.clone()), move |tails_of_body_f_65584: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_p4, &tails_of_body_f_65584)))
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::syntax::decls::FnClause)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>
        }).cycle()
    }
}

/// `Start TailTargets, x`: what the function value is when passed to `@Run`.
pub fn start_tail_targets_f(lx_p0: crate::lower::Lx, qk_p1: crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>> {
    ::std::rc::Rc::new(TailTargets { lx_p0, qk_p1 })
}

/// ```prism
/// TailsOfBody: unbounded fn Lx, FnBody -> [Text]
/// ```
pub fn tails_of_body_f(lx_p0: &crate::lower::Lx, body_p1: &crate::syntax::decls::FnBody) -> crate::prelude::Array<crate::prelude::Text> {
    crate::prelude::fold(&crate::check::typed::print::body_exprs_f(body_p1), &crate::prelude::Array::new(), &(|acc_p2: &crate::prelude::Array<crate::prelude::Text>, e_p3: &crate::syntax::Expr| match &*e_p3.kind_p {
        crate::syntax::ExprKind::ECall(c_p4, _, _, _) => {
            let q_p5 = blueprint_qk_f(lx_p0, &**c_p4);
            match crate::prelude::get(&lx_p0.g_p.vals_p, &q_p5) {
                ::std::option::Option::Some(v_p6) => match &v_p6.scheme_p.ty_p {
                    crate::check::types::Ty::TyFn(crate::check::types::Col::CBound, _, _) => acc_p2.clone(),
                    crate::check::types::Ty::TyFn(_, _, _) => crate::check::types::add_text_f(acc_p2, &q_p5),
                    _ => acc_p2.clone(),
                },
                ::std::option::Option::None => acc_p2.clone(),
            }
        },
        _ => acc_p2.clone(),
    }))
}

/// The step machine of `TailsOfBody`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TailsOfBody: unbounded fn Lx, FnBody -> [Text]
/// ```
pub struct TailsOfBody {
    pub lx_p0: crate::lower::Lx,
    pub body_p1: crate::syntax::decls::FnBody,
}

impl ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>> for TailsOfBody {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<crate::prelude::Text>> {
        let lx_p0 = &self.lx_p0;
        let body_p1 = &self.body_p1;
        let body_p1x = body_p1.clone();
        let lx_p0x = lx_p0.clone();
        crate::prelude::call_then(crate::check::typed::print::start_body_exprs_f(body_p1x.clone()), move |body_exprs_f_65689: crate::prelude::Array<crate::syntax::Expr>| ::prism_rtl::Turn::Finished(crate::prelude::fold(&body_exprs_f_65689, &crate::prelude::Array::new(), &(|acc_p2: &crate::prelude::Array<crate::prelude::Text>, e_p3: &crate::syntax::Expr| match &*e_p3.kind_p {
            crate::syntax::ExprKind::ECall(c_p4, _, _, _) => {
                let q_p5 = blueprint_qk_f(&lx_p0x, &**c_p4);
                match crate::prelude::get(&lx_p0x.g_p.vals_p, &q_p5) {
                    ::std::option::Option::Some(v_p6) => match &v_p6.scheme_p.ty_p {
                        crate::check::types::Ty::TyFn(crate::check::types::Col::CBound, _, _) => acc_p2.clone(),
                        crate::check::types::Ty::TyFn(_, _, _) => crate::check::types::add_text_f(acc_p2, &q_p5),
                        _ => acc_p2.clone(),
                    },
                    ::std::option::Option::None => acc_p2.clone(),
                }
            },
            _ => acc_p2.clone(),
        }))))
    }
}

/// `Start TailsOfBody, x`: what the function value is when passed to `@Run`.
pub fn start_tails_of_body_f(lx_p0: crate::lower::Lx, body_p1: crate::syntax::decls::FnBody) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>> {
    ::std::rc::Rc::new(TailsOfBody { lx_p0, body_p1 })
}

/// ```prism
/// ModDefOf: unbounded fn Lx, Text, [((Text, Bool))], ModInfo, [Text] -> ModDef
/// ```
pub fn mod_def_of_f(lx0_p0: &crate::lower::Lx, m_p1: &crate::prelude::Text, roots_p2: &crate::prelude::Array<(crate::prelude::Text, bool)>, info_p3: &crate::check::env::ModInfo, mods_p4: &crate::prelude::Array<crate::prelude::Text>) -> crate::lower::model::ModDef {
    let lx_p5 = in_module_f(lx0_p0, &info_p3.file_p, m_p1);
    let path_p6 = match crate::prelude::index(&lx_p5.g_p.srcs_p, &info_p3.file_p) {
        ::std::option::Option::Some(src_pd) => src_pd.path_p.clone(),
        ::std::option::Option::None => crate::prelude::Text::lit(""),
    };
    let types_p7 = crate::prelude::run_to_end(crate::prelude::fold_job(crate::prelude::values(&lx_p5.g_p.types_p), crate::prelude::Array::new(), {
        let m_p1x = m_p1.clone();
        let lx_p5x = lx_p5.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::lower::model::Item>, crate::check::env::TyInfo)| {
            let m_p1xy = m_p1x.clone();
            let lx_p5xy = lx_p5x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_pe = p0;
                let ti_pf = p1;
                if &ti_pf.home_p == &m_p1xy {
                    crate::prelude::call_then(start_ty_defs_f(lx_p5xy.clone(), ti_pf.clone()), move |ty_defs_f_66414: crate::prelude::Array<crate::lower::model::Item>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_pe, &ty_defs_f_66414)))
                } else {
                    ::prism_rtl::Turn::Finished(acc_pe.clone())
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::lower::model::Item>, crate::check::env::TyInfo)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::lower::model::Item>>>>
    }));
    let tags_p8 = crate::prelude::run_to_end(crate::prelude::fold_job(crate::prelude::values(&lx_p5.g_p.tags_p), crate::prelude::Array::new(), {
        let m_p1x = m_p1.clone();
        let lx_p5x = lx_p5.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::lower::model::Item>, crate::check::env::TagInfo)| {
            let m_p1xy = m_p1x.clone();
            let lx_p5xy = lx_p5x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_pg = p0;
                let tg_ph = p1;
                if (&tg_ph.home_p == &m_p1xy) && (&tg_ph.kind_p != &crate::prelude::Text::lit("Prelude.Fault")) {
                    crate::prelude::call_then(start_tag_items_f(lx_p5xy.clone(), tg_ph.clone()), move |tag_items_f_66557: crate::prelude::Array<crate::lower::model::Item>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_pg, &tag_items_f_66557)))
                } else {
                    ::prism_rtl::Turn::Finished(acc_pg.clone())
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::lower::model::Item>, crate::check::env::TagInfo)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::lower::model::Item>>>>
    }));
    let defs_p9 = crate::prelude::run_to_end(crate::prelude::fold_job(lx_p5.g_p.defs_p.clone(), crate::prelude::Array::new(), {
        let m_p1x = m_p1.clone();
        let lx_p5x = lx_p5.clone();
        let roots_p2x = roots_p2.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::lower::model::Item>, crate::check::env::Def)| {
            let m_p1xy = m_p1x.clone();
            let lx_p5xy = lx_p5x.clone();
            let roots_p2xy = roots_p2x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_pi = p0;
                let d_pj = p1;
                if &d_pj.home_p == &m_p1xy {
                    crate::prelude::call_then(start_def_items_f(in_module_f(&lx_p5xy, &d_pj.file_p, &m_p1xy), d_pj.clone(), roots_p2xy.clone()), move |def_items_f_66660: crate::prelude::Array<crate::lower::model::Item>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_pi, &def_items_f_66660)))
                } else {
                    ::prism_rtl::Turn::Finished(acc_pi.clone())
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::lower::model::Item>, crate::check::env::Def)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::lower::model::Item>>>>
    }));
    let traits_pa = crate::prelude::run_to_end(crate::prelude::fold_job(crate::prelude::values(&lx_p5.g_p.traits_p), crate::prelude::Array::new(), {
        let m_p1x = m_p1.clone();
        let lx_p5x = lx_p5.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::lower::model::Item>, crate::check::env::TraitInfo)| {
            let m_p1xy = m_p1x.clone();
            let lx_p5xy = lx_p5x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_pk = p0;
                let tr_pl = p1;
                if &tr_pl.home_p == &m_p1xy {
                    crate::prelude::call_then(crate::lower::functions::start_trait_def_of_f(lx_p5xy.clone(), tr_pl.clone()), move |trait_def_of_f_66821: crate::lower::model::TraitDef| crate::prelude::call_then(start_packed_items_f(lx_p5xy.clone(), tr_pl.clone()), move |packed_items_f_66844: crate::prelude::Array<crate::lower::model::Item>| ::prism_rtl::Turn::Finished(crate::prelude::append(&crate::prelude::push(&acc_pk, &crate::lower::model::Item::ItTrait(trait_def_of_f_66821)), &packed_items_f_66844))))
                } else {
                    ::prism_rtl::Turn::Finished(acc_pk.clone())
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::lower::model::Item>, crate::check::env::TraitInfo)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::lower::model::Item>>>>
    }));
    let impls_pb = crate::prelude::run_to_end(crate::prelude::fold_job(crate::prelude::values(&lx_p5.g_p.impls_p), crate::prelude::Array::new(), {
        let m_p1x = m_p1.clone();
        let lx_p5x = lx_p5.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::lower::model::Item>, crate::prelude::Array<crate::check::env::ImplInfo>)| {
            let m_p1xy = m_p1x.clone();
            let lx_p5xy = lx_p5x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_pm = p0;
                let ims_pn = p1;
                crate::prelude::fold_job(ims_pn.clone(), acc_pm.clone(), {
                    let m_p1xyx = m_p1xy.clone();
                    let lx_p5xyx = lx_p5xy.clone();
                    ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::lower::model::Item>, crate::check::env::ImplInfo)| {
                        let m_p1xyxy = m_p1xyx.clone();
                        let lx_p5xyxy = lx_p5xyx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let a_po = p0;
                            let im_pp = p1;
                            if (&im_pp.home_p == &m_p1xyxy) && !im_pp.derived_p {
                                crate::prelude::call_then(crate::lower::functions::start_impl_def_of_f(in_module_f(&lx_p5xyxy, &im_pp.file_p, &m_p1xyxy), im_pp.clone()), move |impl_def_of_f_67011: crate::lower::model::ImplDef| ::prism_rtl::Turn::Finished(crate::prelude::push(&a_po, &crate::lower::model::Item::ItImpl(impl_def_of_f_67011))))
                            } else {
                                ::prism_rtl::Turn::Finished(a_po.clone())
                            }
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::lower::model::Item>, crate::check::env::ImplInfo)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::lower::model::Item>>>>
                }).cycle()
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::lower::model::Item>, crate::prelude::Array<crate::check::env::ImplInfo>)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::lower::model::Item>>>>
    }));
    let uses_pc = crate::prelude::filter(&crate::prelude::each(mods_p4, &(|o_pq: &crate::prelude::Text| crate::lower::rust_mod_name_f(o_pq))), &(|o_pr: &crate::prelude::Text| o_pr != &crate::lower::rust_mod_name_f(m_p1)));
    crate::lower::model::ModDef { name_p: crate::lower::rust_mod_name_f(m_p1), prism_p: m_p1.clone(), path_p: path_p6.clone(), uses_p: uses_pc.clone(), complete_p: crate::prelude::Array::new(), declared_p: crate::prelude::Array::new(), types_with_p: crate::prelude::Array::new(), items_p: crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&types_p7, &tags_p8), &traits_pa), &impls_pb), &defs_p9) }
}

/// The step machine of `ModDefOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ModDefOf: unbounded fn Lx, Text, [((Text, Bool))], ModInfo, [Text] -> ModDef
/// ```
pub struct ModDefOf {
    pub lx0_p0: crate::lower::Lx,
    pub m_p1: crate::prelude::Text,
    pub roots_p2: crate::prelude::Array<(crate::prelude::Text, bool)>,
    pub info_p3: crate::check::env::ModInfo,
    pub mods_p4: crate::prelude::Array<crate::prelude::Text>,
}

impl ::prism_rtl::Job<crate::lower::model::ModDef> for ModDefOf {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::lower::model::ModDef> {
        let lx0_p0 = &self.lx0_p0;
        let m_p1 = &self.m_p1;
        let roots_p2 = &self.roots_p2;
        let info_p3 = &self.info_p3;
        let mods_p4 = &self.mods_p4;
        let lx_p5 = in_module_f(lx0_p0, &info_p3.file_p, m_p1);
        let path_p6 = match crate::prelude::index(&lx_p5.g_p.srcs_p, &info_p3.file_p) {
            ::std::option::Option::Some(src_pd) => src_pd.path_p.clone(),
            ::std::option::Option::None => crate::prelude::Text::lit(""),
        };
        let m_p1x = m_p1.clone();
        let mods_p4x = mods_p4.clone();
        let roots_p2x = roots_p2.clone();
        crate::prelude::call_value(crate::prelude::fold_job(crate::prelude::values(&lx_p5.g_p.types_p), crate::prelude::Array::new(), {
            let m_p1xx = m_p1x.clone();
            let lx_p5x = lx_p5.clone();
            ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::lower::model::Item>, crate::check::env::TyInfo)| {
                let m_p1xxy = m_p1xx.clone();
                let lx_p5xy = lx_p5x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let acc_pe = p0;
                    let ti_pf = p1;
                    if &ti_pf.home_p == &m_p1xxy {
                        crate::prelude::call_then(start_ty_defs_f(lx_p5xy.clone(), ti_pf.clone()), move |ty_defs_f_66414: crate::prelude::Array<crate::lower::model::Item>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_pe, &ty_defs_f_66414)))
                    } else {
                        ::prism_rtl::Turn::Finished(acc_pe.clone())
                    }
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::lower::model::Item>, crate::check::env::TyInfo)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::lower::model::Item>>>>
        }), move |fold_66341: crate::prelude::Array<crate::lower::model::Item>| {
            let types_p7 = fold_66341;
            crate::prelude::call_value(crate::prelude::fold_job(crate::prelude::values(&lx_p5.g_p.tags_p), crate::prelude::Array::new(), {
                let m_p1xx = m_p1x.clone();
                let lx_p5x = lx_p5.clone();
                ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::lower::model::Item>, crate::check::env::TagInfo)| {
                    let m_p1xxy = m_p1xx.clone();
                    let lx_p5xy = lx_p5x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let acc_pg = p0;
                        let tg_ph = p1;
                        if (&tg_ph.home_p == &m_p1xxy) && (&tg_ph.kind_p != &crate::prelude::Text::lit("Prelude.Fault")) {
                            crate::prelude::call_then(start_tag_items_f(lx_p5xy.clone(), tg_ph.clone()), move |tag_items_f_66557: crate::prelude::Array<crate::lower::model::Item>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_pg, &tag_items_f_66557)))
                        } else {
                            ::prism_rtl::Turn::Finished(acc_pg.clone())
                        }
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::lower::model::Item>, crate::check::env::TagInfo)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::lower::model::Item>>>>
            }), move |fold_66454: crate::prelude::Array<crate::lower::model::Item>| {
                let tags_p8 = fold_66454;
                crate::prelude::call_value(crate::prelude::fold_job(lx_p5.g_p.defs_p.clone(), crate::prelude::Array::new(), {
                    let m_p1xx = m_p1x.clone();
                    let lx_p5x = lx_p5.clone();
                    let roots_p2xx = roots_p2x.clone();
                    ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::lower::model::Item>, crate::check::env::Def)| {
                        let m_p1xxy = m_p1xx.clone();
                        let lx_p5xy = lx_p5x.clone();
                        let roots_p2xxy = roots_p2xx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let acc_pi = p0;
                            let d_pj = p1;
                            if &d_pj.home_p == &m_p1xxy {
                                crate::prelude::call_then(start_def_items_f(in_module_f(&lx_p5xy, &d_pj.file_p, &m_p1xxy), d_pj.clone(), roots_p2xxy.clone()), move |def_items_f_66660: crate::prelude::Array<crate::lower::model::Item>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_pi, &def_items_f_66660)))
                            } else {
                                ::prism_rtl::Turn::Finished(acc_pi.clone())
                            }
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::lower::model::Item>, crate::check::env::Def)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::lower::model::Item>>>>
                }), move |fold_66599: crate::prelude::Array<crate::lower::model::Item>| {
                    let defs_p9 = fold_66599;
                    crate::prelude::call_value(crate::prelude::fold_job(crate::prelude::values(&lx_p5.g_p.traits_p), crate::prelude::Array::new(), {
                        let m_p1xx = m_p1x.clone();
                        let lx_p5x = lx_p5.clone();
                        ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::lower::model::Item>, crate::check::env::TraitInfo)| {
                            let m_p1xxy = m_p1xx.clone();
                            let lx_p5xy = lx_p5x.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let acc_pk = p0;
                                let tr_pl = p1;
                                if &tr_pl.home_p == &m_p1xxy {
                                    crate::prelude::call_then(crate::lower::functions::start_trait_def_of_f(lx_p5xy.clone(), tr_pl.clone()), move |trait_def_of_f_66821: crate::lower::model::TraitDef| crate::prelude::call_then(start_packed_items_f(lx_p5xy.clone(), tr_pl.clone()), move |packed_items_f_66844: crate::prelude::Array<crate::lower::model::Item>| ::prism_rtl::Turn::Finished(crate::prelude::append(&crate::prelude::push(&acc_pk, &crate::lower::model::Item::ItTrait(trait_def_of_f_66821)), &packed_items_f_66844))))
                                } else {
                                    ::prism_rtl::Turn::Finished(acc_pk.clone())
                                }
                            }))
                        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::lower::model::Item>, crate::check::env::TraitInfo)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::lower::model::Item>>>>
                    }), move |fold_66732: crate::prelude::Array<crate::lower::model::Item>| {
                        let traits_pa = fold_66732;
                        crate::prelude::call_value(crate::prelude::fold_job(crate::prelude::values(&lx_p5.g_p.impls_p), crate::prelude::Array::new(), {
                            let m_p1xx = m_p1x.clone();
                            let lx_p5x = lx_p5.clone();
                            ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::lower::model::Item>, crate::prelude::Array<crate::check::env::ImplInfo>)| {
                                let m_p1xxy = m_p1xx.clone();
                                let lx_p5xy = lx_p5x.clone();
                                crate::prelude::entered(crate::prelude::once_job(move || {
                                    let acc_pm = p0;
                                    let ims_pn = p1;
                                    crate::prelude::fold_job(ims_pn.clone(), acc_pm.clone(), {
                                        let m_p1xxyx = m_p1xxy.clone();
                                        let lx_p5xyx = lx_p5xy.clone();
                                        ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::lower::model::Item>, crate::check::env::ImplInfo)| {
                                            let m_p1xxyxy = m_p1xxyx.clone();
                                            let lx_p5xyxy = lx_p5xyx.clone();
                                            crate::prelude::entered(crate::prelude::once_job(move || {
                                                let a_po = p0;
                                                let im_pp = p1;
                                                if (&im_pp.home_p == &m_p1xxyxy) && !im_pp.derived_p {
                                                    crate::prelude::call_then(crate::lower::functions::start_impl_def_of_f(in_module_f(&lx_p5xyxy, &im_pp.file_p, &m_p1xxyxy), im_pp.clone()), move |impl_def_of_f_67011: crate::lower::model::ImplDef| ::prism_rtl::Turn::Finished(crate::prelude::push(&a_po, &crate::lower::model::Item::ItImpl(impl_def_of_f_67011))))
                                                } else {
                                                    ::prism_rtl::Turn::Finished(a_po.clone())
                                                }
                                            }))
                                        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::lower::model::Item>, crate::check::env::ImplInfo)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::lower::model::Item>>>>
                                    }).cycle()
                                }))
                            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::lower::model::Item>, crate::prelude::Array<crate::check::env::ImplInfo>)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::lower::model::Item>>>>
                        }), move |fold_66890: crate::prelude::Array<crate::lower::model::Item>| {
                            let impls_pb = fold_66890;
                            let uses_pc = crate::prelude::filter(&crate::prelude::each(&mods_p4x, &(|o_pq: &crate::prelude::Text| crate::lower::rust_mod_name_f(o_pq))), &(|o_pr: &crate::prelude::Text| o_pr != &crate::lower::rust_mod_name_f(&m_p1x)));
                            ::prism_rtl::Turn::Finished(crate::lower::model::ModDef { name_p: crate::lower::rust_mod_name_f(&m_p1x), prism_p: m_p1x.clone(), path_p: path_p6.clone(), uses_p: uses_pc.clone(), complete_p: crate::prelude::Array::new(), declared_p: crate::prelude::Array::new(), types_with_p: crate::prelude::Array::new(), items_p: crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&types_p7, &tags_p8), &traits_pa), &impls_pb), &defs_p9) })
                        })
                    })
                })
            })
        })
    }
}

/// `Start ModDefOf, x`: what the function value is when passed to `@Run`.
pub fn start_mod_def_of_f(lx0_p0: crate::lower::Lx, m_p1: crate::prelude::Text, roots_p2: crate::prelude::Array<(crate::prelude::Text, bool)>, info_p3: crate::check::env::ModInfo, mods_p4: crate::prelude::Array<crate::prelude::Text>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::ModDef>> {
    ::std::rc::Rc::new(ModDefOf { lx0_p0, m_p1, roots_p2, info_p3, mods_p4 })
}

/// ```prism
/// PackedItems: unbounded fn Lx, TraitInfo -> [Item]
/// ```
pub fn packed_items_f(lx_p0: &crate::lower::Lx, tr_p1: &crate::check::env::TraitInfo) -> crate::prelude::Array<crate::lower::model::Item> {
    match crate::lower::functions::packed_def_of_o(lx_p0, tr_p1) {
        ::std::option::Option::Some(pd_p2) => crate::prelude::Array::from(vec![crate::lower::model::Item::ItPacked(pd_p2)]),
        ::std::option::Option::None => crate::prelude::Array::new(),
    }
}

/// The step machine of `PackedItems`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PackedItems: unbounded fn Lx, TraitInfo -> [Item]
/// ```
pub struct PackedItems {
    pub lx_p0: crate::lower::Lx,
    pub tr_p1: crate::check::env::TraitInfo,
}

impl ::prism_rtl::Job<crate::prelude::Array<crate::lower::model::Item>> for PackedItems {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<crate::lower::model::Item>> {
        let lx_p0 = &self.lx_p0;
        let tr_p1 = &self.tr_p1;
        let lx_p0x = lx_p0.clone();
        let tr_p1x = tr_p1.clone();
        crate::prelude::call_then(crate::lower::functions::start_packed_def_of_o(lx_p0x.clone(), tr_p1x.clone()), move |packed_def_of_o_67495: ::std::option::Option<crate::lower::model::PackedDef>| match packed_def_of_o_67495 {
            ::std::option::Option::Some(pd_p2) => ::prism_rtl::Turn::Finished(crate::prelude::Array::from(vec![crate::lower::model::Item::ItPacked(pd_p2.clone())])),
            ::std::option::Option::None => ::prism_rtl::Turn::Finished(crate::prelude::Array::new()),
        })
    }
}

/// `Start PackedItems, x`: what the function value is when passed to `@Run`.
pub fn start_packed_items_f(lx_p0: crate::lower::Lx, tr_p1: crate::check::env::TraitInfo) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::lower::model::Item>>> {
    ::std::rc::Rc::new(PackedItems { lx_p0, tr_p1 })
}

/// ```prism
/// DefItems: unbounded fn Lx, Def, [((Text, Bool))] -> [Item]
/// ```
pub fn def_items_f(lx_p0: &crate::lower::Lx, d_p1: &crate::check::env::Def, roots_p2: &crate::prelude::Array<(crate::prelude::Text, bool)>) -> crate::prelude::Array<crate::lower::model::Item> {
    let is_root_p3 = crate::check::types::has_text_f(&crate::prelude::each(roots_p2, &(|(q_p4, _): &(crate::prelude::Text, bool)| q_p4.clone())), &d_p1.qk_p);
    match &d_p1.body_p {
        crate::check::env::DefBody::DbWidget(w_p5) => {
            let valued_p6 = valued_rows_f(lx_p0, &d_p1.qk_p, &::std::option::Option::Some(w_p5.body_p.clone()));
            if is_root_p3 {
                crate::prelude::append(&node_items_f(&crate::lower::node_::def::node_def_of_f(lx_p0, &d_p1.qk_p, &crate::prelude::Array::new(), &w_p5.body_p, &crate::prelude::or(&crate::prelude::get(&lx_p0.g_p.vals_p, &d_p1.qk_p), &crate::check::env::builtin_f(&d_p1.qk_p, &crate::check::types::schemes::mono_f(&crate::check::types::Ty::TyErr))).scheme_p, &true)), &valued_p6)
            } else {
                crate::prelude::push(&valued_p6, &crate::lower::model::Item::ItNote(crate::prelude::Text::from(format!("`{}` is inlined where it is applied.", &d_p1.name_p))))
            }
        },
        crate::check::env::DefBody::DbFn(clauses_p7) => match crate::prelude::get(&lx_p0.g_p.vals_p, &d_p1.qk_p) {
            ::std::option::Option::None => crate::prelude::Array::new(),
            ::std::option::Option::Some(v_p8) => 'm68242: {
                let scrutinee = &v_p8.scheme_p.ty_p;
                if let crate::check::types::Ty::TyFn(_, _, m68242_0_2) = scrutinee && let crate::check::types::Ty::TyAt(_, _) = &**m68242_0_2 {
                    break 'm68242 if !is_root_p3 {
                        if is_value_widget_f(lx_p0, &d_p1.qk_p) {
                            crate::prelude::Array::from(vec![crate::lower::model::Item::ItFn(crate::lower::functions::fn_def_of_f(lx_p0, &d_p1.qk_p, clauses_p7, &v_p8.scheme_p))])
                        } else {
                            crate::prelude::push(&valued_rows_f(lx_p0, &d_p1.qk_p, &::std::option::Option::None), &crate::lower::model::Item::ItNote(crate::prelude::Text::from(format!("`{}` is inlined where it is applied.", &d_p1.name_p))))
                        }
                    } else {
                        crate::prelude::append(&valued_rows_f(lx_p0, &d_p1.qk_p, &::std::option::Option::None), &'m68632: {
                            if let m68632_0 = clauses_p7 && (m68632_0.len() == 1) && let ::std::option::Option::Some(c_p9) = crate::prelude::index(m68632_0, &crate::prelude::Nat::from(0u32)) {
                                break 'm68632 match &c_p9.body_p {
                                    crate::syntax::decls::FnBody::BodyBlock(b_pa) => node_items_f(&crate::lower::node_::def::node_def_of_f(lx_p0, &d_p1.qk_p, &c_p9.params_p, b_pa, &v_p8.scheme_p, &true)),
                                    _ => crate::prelude::Array::from(vec![crate::lower::model::Item::ItRefused(crate::prelude::Text::from(format!("`{}`, a root widget whose body is one expression", &d_p1.name_p)))]),
                                };
                            }
                            crate::prelude::Array::from(vec![crate::lower::model::Item::ItRefused(crate::prelude::Text::from(format!("`{}`, a root widget of several clauses", &d_p1.name_p)))])
                        })
                    };
                }
                if crate::check::env::decls::is_lens_text_f(&d_p1.qk_p) {
                    crate::prelude::each(&crate::lower::templates::lens_defs_f(lx_p0, &d_p1.qk_p, clauses_p7, &v_p8.scheme_p), &(|f_pb: &crate::lower::model::FnDef| crate::lower::model::Item::ItFn(f_pb.clone())))
                } else {
                    {
                        let f_pc = crate::lower::model::Item::ItFn(crate::lower::functions::fn_def_of_f(lx_p0, &d_p1.qk_p, clauses_p7, &v_p8.scheme_p));
                        if crate::check::types::has_text_f(&lx_p0.unbs_p, &d_p1.qk_p) {
                            crate::prelude::Array::from(vec![f_pc.clone(), crate::lower::model::Item::ItJob(crate::lower::jobs::job_def_of_f(lx_p0, &d_p1.qk_p, clauses_p7, &v_p8.scheme_p))])
                        } else {
                            crate::prelude::Array::from(vec![f_pc.clone()])
                        }
                    }
                }
            },
        },
        crate::check::env::DefBody::DbLet(l_pd) => crate::prelude::Array::from(vec![crate::lower::model::Item::ItFn(crate::lower::functions::let_getter_f(lx_p0, &d_p1.qk_p, l_pd))]),
        _ => crate::prelude::Array::new(),
    }
}

/// The step machine of `DefItems`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// DefItems: unbounded fn Lx, Def, [((Text, Bool))] -> [Item]
/// ```
pub struct DefItems {
    pub lx_p0: crate::lower::Lx,
    pub d_p1: crate::check::env::Def,
    pub roots_p2: crate::prelude::Array<(crate::prelude::Text, bool)>,
}

impl ::prism_rtl::Job<crate::prelude::Array<crate::lower::model::Item>> for DefItems {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<crate::lower::model::Item>> {
        let lx_p0 = &self.lx_p0;
        let d_p1 = &self.d_p1;
        let roots_p2 = &self.roots_p2;
        let is_root_p3 = crate::check::types::has_text_f(&crate::prelude::each(roots_p2, &(|(q_p4, _): &(crate::prelude::Text, bool)| q_p4.clone())), &d_p1.qk_p);
        match &d_p1.body_p {
            crate::check::env::DefBody::DbWidget(w_p5) => {
                let d_p1x = d_p1.clone();
                let lx_p0x = lx_p0.clone();
                let w_p5x = w_p5.clone();
                crate::prelude::call_then(start_valued_rows_f(lx_p0x.clone(), d_p1x.qk_p.clone(), ::std::option::Option::Some(w_p5x.body_p.clone())), move |valued_rows_f_67891: crate::prelude::Array<crate::lower::model::Item>| {
                    let valued_p6 = valued_rows_f_67891;
                    if is_root_p3 {
                        crate::prelude::call_then(crate::lower::node_::def::start_node_def_of_f(lx_p0x.clone(), d_p1x.qk_p.clone(), crate::prelude::Array::new(), w_p5x.body_p.clone(), crate::prelude::or(&crate::prelude::get(&lx_p0x.g_p.vals_p, &d_p1x.qk_p), &crate::check::env::builtin_f(&d_p1x.qk_p, &crate::check::types::schemes::mono_f(&crate::check::types::Ty::TyErr))).scheme_p.clone(), true), move |node_def_of_f_67965: crate::lower::model::NodeDef| ::prism_rtl::Turn::Finished(crate::prelude::append(&node_items_f(&node_def_of_f_67965), &valued_p6)))
                    } else {
                        ::prism_rtl::Turn::Finished(crate::prelude::push(&valued_p6, &crate::lower::model::Item::ItNote(crate::prelude::Text::from(format!("`{}` is inlined where it is applied.", &d_p1x.name_p)))))
                    }
                })
            },
            crate::check::env::DefBody::DbFn(clauses_p7) => match crate::prelude::get(&lx_p0.g_p.vals_p, &d_p1.qk_p) {
                ::std::option::Option::None => ::prism_rtl::Turn::Finished(crate::prelude::Array::new()),
                ::std::option::Option::Some(v_p8) => 'm68242: {
                    let scrutinee = &v_p8.scheme_p.ty_p;
                    if let crate::check::types::Ty::TyFn(_, _, m68242_0_2) = scrutinee && let crate::check::types::Ty::TyAt(_, _) = &**m68242_0_2 {
                        break 'm68242 if !is_root_p3 {
                            {
                                let clauses_p7x = clauses_p7.clone();
                                let d_p1x = d_p1.clone();
                                let lx_p0x = lx_p0.clone();
                                crate::prelude::call_then(start_is_value_widget_f(lx_p0x.clone(), d_p1x.qk_p.clone()), move |is_value_widget_f_68383: bool| if is_value_widget_f_68383 {
                                    crate::prelude::call_then(crate::lower::functions::start_fn_def_of_f(lx_p0x.clone(), d_p1x.qk_p.clone(), clauses_p7x.clone(), v_p8.scheme_p.clone()), move |fn_def_of_f_68415: crate::lower::model::FnDef| ::prism_rtl::Turn::Finished(crate::prelude::Array::from(vec![crate::lower::model::Item::ItFn(fn_def_of_f_68415)])))
                                } else {
                                    crate::prelude::call_then(start_valued_rows_f(lx_p0x.clone(), d_p1x.qk_p.clone(), ::std::option::Option::None), move |valued_rows_f_68490: crate::prelude::Array<crate::lower::model::Item>| ::prism_rtl::Turn::Finished(crate::prelude::push(&valued_rows_f_68490, &crate::lower::model::Item::ItNote(crate::prelude::Text::from(format!("`{}` is inlined where it is applied.", &d_p1x.name_p))))))
                                })
                            }
                        } else {
                            {
                                let clauses_p7x = clauses_p7.clone();
                                let d_p1x = d_p1.clone();
                                let lx_p0x = lx_p0.clone();
                                crate::prelude::call_then(start_valued_rows_f(lx_p0x.clone(), d_p1x.qk_p.clone(), ::std::option::Option::None), move |valued_rows_f_68605: crate::prelude::Array<crate::lower::model::Item>| ::prism_rtl::Turn::Finished(crate::prelude::append(&valued_rows_f_68605, &'m68632: {
                                    if let m68632_0 = &clauses_p7x && (m68632_0.len() == 1) && let ::std::option::Option::Some(c_p9) = crate::prelude::index(m68632_0, &crate::prelude::Nat::from(0u32)) {
                                        break 'm68632 match &c_p9.body_p {
                                            crate::syntax::decls::FnBody::BodyBlock(b_pa) => node_items_f(&crate::lower::node_::def::node_def_of_f(&lx_p0x, &d_p1x.qk_p, &c_p9.params_p, b_pa, &v_p8.scheme_p, &true)),
                                            _ => crate::prelude::Array::from(vec![crate::lower::model::Item::ItRefused(crate::prelude::Text::from(format!("`{}`, a root widget whose body is one expression", &d_p1x.name_p)))]),
                                        };
                                    }
                                    crate::prelude::Array::from(vec![crate::lower::model::Item::ItRefused(crate::prelude::Text::from(format!("`{}`, a root widget of several clauses", &d_p1x.name_p)))])
                                })))
                            }
                        };
                    }
                    if crate::check::env::decls::is_lens_text_f(&d_p1.qk_p) {
                        {
                            let clauses_p7x = clauses_p7.clone();
                            let d_p1x = d_p1.clone();
                            let lx_p0x = lx_p0.clone();
                            crate::prelude::call_then(crate::lower::templates::start_lens_defs_f(lx_p0x.clone(), d_p1x.qk_p.clone(), clauses_p7x.clone(), v_p8.scheme_p.clone()), move |lens_defs_f_69052: crate::prelude::Array<crate::lower::model::FnDef>| ::prism_rtl::Turn::Finished(crate::prelude::each(&lens_defs_f_69052, &(|f_pb: &crate::lower::model::FnDef| crate::lower::model::Item::ItFn(f_pb.clone())))))
                        }
                    } else {
                        {
                            let clauses_p7x = clauses_p7.clone();
                            let d_p1x = d_p1.clone();
                            let lx_p0x = lx_p0.clone();
                            crate::prelude::call_then(crate::lower::functions::start_fn_def_of_f(lx_p0x.clone(), d_p1x.qk_p.clone(), clauses_p7x.clone(), v_p8.scheme_p.clone()), move |fn_def_of_f_69143: crate::lower::model::FnDef| {
                                let f_pc = crate::lower::model::Item::ItFn(fn_def_of_f_69143);
                                if crate::check::types::has_text_f(&lx_p0x.unbs_p, &d_p1x.qk_p) {
                                    crate::prelude::call_then(crate::lower::jobs::start_job_def_of_f(lx_p0x.clone(), d_p1x.qk_p.clone(), clauses_p7x.clone(), v_p8.scheme_p.clone()), move |job_def_of_f_69238: crate::lower::model::JobDef| ::prism_rtl::Turn::Finished(crate::prelude::Array::from(vec![f_pc.clone(), crate::lower::model::Item::ItJob(job_def_of_f_69238)])))
                                } else {
                                    ::prism_rtl::Turn::Finished(crate::prelude::Array::from(vec![f_pc.clone()]))
                                }
                            })
                        }
                    }
                },
            },
            crate::check::env::DefBody::DbLet(l_pd) => {
                let d_p1x = d_p1.clone();
                let l_pdx = l_pd.clone();
                let lx_p0x = lx_p0.clone();
                crate::prelude::call_then(crate::lower::functions::start_let_getter_f(lx_p0x.clone(), d_p1x.qk_p.clone(), l_pdx.clone()), move |let_getter_f_69315: crate::lower::model::FnDef| ::prism_rtl::Turn::Finished(crate::prelude::Array::from(vec![crate::lower::model::Item::ItFn(let_getter_f_69315)])))
            },
            _ => ::prism_rtl::Turn::Finished(crate::prelude::Array::new()),
        }
    }
}

/// `Start DefItems, x`: what the function value is when passed to `@Run`.
pub fn start_def_items_f(lx_p0: crate::lower::Lx, d_p1: crate::check::env::Def, roots_p2: crate::prelude::Array<(crate::prelude::Text, bool)>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::lower::model::Item>>> {
    ::std::rc::Rc::new(DefItems { lx_p0, d_p1, roots_p2 })
}

/// ```prism
/// NodeItems: fn NodeDef -> [Item]
/// ```
pub fn node_items_f(n_p0: &crate::lower::model::NodeDef) -> crate::prelude::Array<crate::lower::model::Item> {
    crate::prelude::append(&crate::prelude::Array::from(vec![crate::lower::model::Item::ItNode(n_p0.clone())]), &crate::prelude::each(&n_p0.children_p, &(|c_p1: &crate::lower::model::NodeDef| crate::lower::model::Item::ItNode(c_p1.clone()))))
}

/// ```prism
/// TyDefs: unbounded fn Lx, TyInfo -> [Item]
/// ```
pub fn ty_defs_f(lx_p0: &crate::lower::Lx, ti_p1: &crate::check::env::TyInfo) -> crate::prelude::Array<crate::lower::model::Item> {
    let derives_p2 = crate::prelude::fold(&ti_p1.derives_p, &crate::prelude::Array::new(), &(|acc_p6: &crate::prelude::Array<crate::prelude::Text>, dn_p7: &crate::prelude::Text| match crate::check::env::names::resolve_trait_o(&lx_p0.g_p, &ti_p1.home_p, &crate::prelude::split_on(dn_p7, &crate::prelude::Text::lit("."))) {
        ::std::option::Option::Some(cls_p8) => crate::prelude::push(acc_p6, &cls_p8),
        ::std::option::Option::None => acc_p6.clone(),
    }));
    let params_p3 = crate::prelude::each(&ti_p1.params_p, &(|p_p9: &crate::prelude::Text| crate::lower::camel_f(p_p9)));
    let bare_p4 = crate::check::types::bare_name_f(&ti_p1.name_p);
    let mk_f5 = {
        let bare_p4x = bare_p4.clone();
        let params_p3x = params_p3.clone();
        let lx_p0x = lx_p0.clone();
        let ti_p1x = ti_p1.clone();
        let derives_p2x = derives_p2.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::lower::model::TyShape, crate::prelude::Array<crate::lower::model::CaseDef>)| {
            let bare_p4xy = bare_p4x.clone();
            let params_p3xy = params_p3x.clone();
            let lx_p0xy = lx_p0x.clone();
            let ti_p1xy = ti_p1x.clone();
            let derives_p2xy = derives_p2x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let shape_pa = p0;
                let cases_pb = p1;
                crate::prelude::call_then(start_keyed_parameters_f(lx_p0xy.clone(), ti_p1xy.name_p.clone()), move |keyed_parameters_f_70040: crate::prelude::Array<crate::prelude::Text>| crate::prelude::call_then(start_ty_podable_f(lx_p0xy.clone(), crate::check::types::Ty::TyCon(ti_p1xy.name_p.clone(), crate::prelude::Array::new()), crate::prelude::Array::new()), move |ty_podable_f_70305: bool| ::prism_rtl::Turn::Finished(crate::lower::model::TyDef { name_p: crate::lower::camel_f(&bare_p4xy), prism_p: bare_p4xy.clone(), params_p: params_p3xy.clone(), keyed_p: crate::prelude::each(&keyed_parameters_f_70040, &(|q_pc: &crate::prelude::Text| crate::lower::camel_f(q_pc))), shape_p: shape_pa.clone(), cases_p: cases_pb.clone(), eq_p: crate::check::types::has_text_f(&derives_p2xy, &crate::prelude::Text::lit("Prelude.Eq")), ord_p: crate::check::types::has_text_f(&derives_p2xy, &crate::prelude::Text::lit("Prelude.Ord")), show_p: if crate::lower::functions::has_own_show_f(&lx_p0xy, &ti_p1xy.name_p) {
                    crate::lower::model::Shown::ShownOwn
                } else {
                    if crate::check::types::has_text_f(&derives_p2xy, &crate::prelude::Text::lit("Prelude.Show")) {
                        crate::lower::model::Shown::ShownDerived
                    } else {
                        crate::lower::model::Shown::NotShown
                    }
                }, pod_p: ty_podable_f_70305 && crate::prelude::run_to_end(crate::prelude::fold_job(cases_pb.clone(), true, ::std::rc::Rc::new(move |(p0, p1): (bool, crate::lower::model::CaseDef)| crate::prelude::entered(crate::prelude::once_job(move || {
                    let ok_pd = p0;
                    let c_pe = p1;
                    if ok_pd {
                        crate::prelude::fold_job(c_pe.fields_p.clone(), true, ::std::rc::Rc::new(move |(p0, p1): (bool, (crate::prelude::Text, crate::lower::model::OutTy))| crate::prelude::entered(crate::prelude::once_job(move || {
                            let ok2_pf = p0;
                            let (_, ft_pg) = p1;
                            if ok2_pf {
                                ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::lower::types::Podable { t_p0: ft_pg.clone() }))
                            } else {
                                ::prism_rtl::Turn::Finished(false)
                            }
                        }))) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, (crate::prelude::Text, crate::lower::model::OutTy))) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>).cycle()
                    } else {
                        ::prism_rtl::Turn::Finished(false)
                    }
                }))) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::lower::model::CaseDef)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>)), doc_p: type_doc_f(&lx_p0xy, &ti_p1xy) })))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::model::TyShape, crate::prelude::Array<crate::lower::model::CaseDef>)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::TyDef>>>
    };
    match &ti_p1.body_p {
        crate::check::env::TyBody::BRecord(fs_ph) => {
            let fields_pi = crate::prelude::run_to_end(crate::prelude::each_job(crate::check::errors::range0_f(&crate::prelude::len(fs_ph)), {
                let fs_phx = fs_ph.clone();
                let lx_p0x = lx_p0.clone();
                let ti_p1x = ti_p1.clone();
                ::std::rc::Rc::new(move |p0: crate::prelude::Nat| {
                    let fs_phxy = fs_phx.clone();
                    let lx_p0xy = lx_p0x.clone();
                    let ti_p1xy = ti_p1x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let i_pj = p0;
                        {
                            let (fname_pl, ft_pm) = crate::prelude::or(&crate::prelude::index(&fs_phxy, &i_pj), &(crate::prelude::Text::lit(""), crate::check::types::Ty::TyErr));
                            crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0xy.clone(), ft_pm.clone()), move |out_ty_of_f_70651: crate::lower::model::OutTy| {
                                let rt_pk = out_ty_of_f_70651;
                                crate::prelude::call_then(crate::lower::start_field_spell_f(ti_p1xy.home_p.clone(), fname_pl.clone(), ft_pm.clone()), move |field_spell_f_70685: crate::prelude::Text| ::prism_rtl::Turn::Finished((field_spell_f_70685, if crate::lower::types::rc_field_f(&lx_p0xy, &ti_p1xy.name_p, &i_pj) {
                                    crate::lower::model::OutTy::OutRc(::std::rc::Rc::new(rt_pk.clone()))
                                } else {
                                    rt_pk.clone()
                                })))
                            })
                        }
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Text, crate::lower::model::OutTy)>>>
            }));
            crate::prelude::Array::from(vec![crate::lower::model::Item::ItType(crate::prelude::run_to_end((&mk_f5)((crate::lower::model::TyShape::ShapeRecord, crate::prelude::Array::from(vec![crate::lower::model::CaseDef { name_p: crate::lower::camel_f(&bare_p4), prism_p: bare_p4.clone(), fields_p: fields_pi.clone(), labels_p: crate::prelude::each(fs_ph, &(|(fname_pn, _): &(crate::prelude::Text, crate::check::types::Ty)| fname_pn.clone())) }])))))])
        },
        crate::check::env::TyBody::BChoice(cases_po) => {
            let defs_pp = crate::prelude::run_to_end(crate::prelude::each_job(cases_po.clone(), {
                let ti_p1x = ti_p1.clone();
                let lx_p0x = lx_p0.clone();
                ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::prelude::Array<crate::check::types::Ty>)| {
                    let ti_p1xy = ti_p1x.clone();
                    let lx_p0xy = lx_p0x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let (cn_pr, ats_ps) = p0;
                        {
                            let ck_pt = crate::check::env::qual_key_f(&ti_p1xy.home_p, &cn_pr);
                            crate::prelude::call_value(crate::prelude::each_job(crate::check::errors::range0_f(&crate::prelude::len(&ats_ps)), {
                                let lx_p0xyx = lx_p0xy.clone();
                                let ck_ptx = ck_pt.clone();
                                let ats_psx = ats_ps.clone();
                                ::std::rc::Rc::new(move |p0: crate::prelude::Nat| {
                                    let lx_p0xyxy = lx_p0xyx.clone();
                                    let ck_ptxy = ck_ptx.clone();
                                    let ats_psxy = ats_psx.clone();
                                    crate::prelude::entered(crate::prelude::once_job(move || {
                                        let i_pu = p0;
                                        crate::prelude::call_then(start_case_field_f(lx_p0xyxy.clone(), ck_ptxy.clone(), i_pu.clone(), crate::prelude::or(&crate::prelude::index(&ats_psxy, &i_pu), &crate::check::types::Ty::TyErr)), move |case_field_f_71125: crate::lower::model::OutTy| ::prism_rtl::Turn::Finished((crate::prelude::Text::lit(""), case_field_f_71125)))
                                    }))
                                }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Text, crate::lower::model::OutTy)>>>
                            }), move |each_71088: crate::prelude::Array<(crate::prelude::Text, crate::lower::model::OutTy)>| ::prism_rtl::Turn::Finished(crate::lower::model::CaseDef { name_p: crate::lower::camel_f(&cn_pr), prism_p: cn_pr.clone(), fields_p: each_71088, labels_p: crate::prelude::Array::new() }))
                        }
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::prelude::Array<crate::check::types::Ty>)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::CaseDef>>>
            }));
            let shape_pq = 'm71207: {
                if let m71207_0 = cases_po && (m71207_0.len() == 1) && let ::std::option::Option::Some((cn_pv, m71207_0_0_1)) = crate::prelude::index(m71207_0, &crate::prelude::Nat::from(0u32)) && ((&m71207_0_0_1).len() == 0) {
                    break 'm71207 if crate::check::env::is_lower_text_f(&cn_pv) {
                        crate::lower::model::TyShape::ShapeUnit
                    } else {
                        crate::lower::model::TyShape::ShapeChoice
                    };
                }
                if let m71207_1 = cases_po && (m71207_1.len() == 1) && let ::std::option::Option::Some((cn_p10, _)) = crate::prelude::index(m71207_1, &crate::prelude::Nat::from(0u32)) {
                    break 'm71207 if &cn_p10 == &bare_p4 {
                        crate::lower::model::TyShape::ShapeNewtype
                    } else {
                        crate::lower::model::TyShape::ShapeChoice
                    };
                }
                crate::lower::model::TyShape::ShapeChoice
            };
            crate::prelude::Array::from(vec![crate::lower::model::Item::ItType(crate::prelude::run_to_end((&mk_f5)((shape_pq.clone(), defs_pp.clone()))))])
        },
        crate::check::env::TyBody::BRowKind => if &ti_p1.name_p == &crate::prelude::Text::lit("Prelude.Fault") {
            crate::prelude::Array::new()
        } else {
            crate::prelude::Array::from(vec![crate::lower::model::Item::ItRow(row_def_of_f(lx_p0, ti_p1))])
        },
        _ => crate::prelude::Array::new(),
    }
}

/// The step machine of `TyDefs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TyDefs: unbounded fn Lx, TyInfo -> [Item]
/// ```
pub struct TyDefs {
    pub lx_p0: crate::lower::Lx,
    pub ti_p1: crate::check::env::TyInfo,
}

impl ::prism_rtl::Job<crate::prelude::Array<crate::lower::model::Item>> for TyDefs {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<crate::lower::model::Item>> {
        let lx_p0 = &self.lx_p0;
        let ti_p1 = &self.ti_p1;
        let derives_p2 = crate::prelude::fold(&ti_p1.derives_p, &crate::prelude::Array::new(), &(|acc_p6: &crate::prelude::Array<crate::prelude::Text>, dn_p7: &crate::prelude::Text| match crate::check::env::names::resolve_trait_o(&lx_p0.g_p, &ti_p1.home_p, &crate::prelude::split_on(dn_p7, &crate::prelude::Text::lit("."))) {
            ::std::option::Option::Some(cls_p8) => crate::prelude::push(acc_p6, &cls_p8),
            ::std::option::Option::None => acc_p6.clone(),
        }));
        let params_p3 = crate::prelude::each(&ti_p1.params_p, &(|p_p9: &crate::prelude::Text| crate::lower::camel_f(p_p9)));
        let bare_p4 = crate::check::types::bare_name_f(&ti_p1.name_p);
        let mk_f5 = {
            let bare_p4x = bare_p4.clone();
            let params_p3x = params_p3.clone();
            let lx_p0x = lx_p0.clone();
            let ti_p1x = ti_p1.clone();
            let derives_p2x = derives_p2.clone();
            ::std::rc::Rc::new(move |(p0, p1): (crate::lower::model::TyShape, crate::prelude::Array<crate::lower::model::CaseDef>)| {
                let bare_p4xy = bare_p4x.clone();
                let params_p3xy = params_p3x.clone();
                let lx_p0xy = lx_p0x.clone();
                let ti_p1xy = ti_p1x.clone();
                let derives_p2xy = derives_p2x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let shape_pa = p0;
                    let cases_pb = p1;
                    crate::prelude::call_then(start_keyed_parameters_f(lx_p0xy.clone(), ti_p1xy.name_p.clone()), move |keyed_parameters_f_70040: crate::prelude::Array<crate::prelude::Text>| crate::prelude::call_then(start_ty_podable_f(lx_p0xy.clone(), crate::check::types::Ty::TyCon(ti_p1xy.name_p.clone(), crate::prelude::Array::new()), crate::prelude::Array::new()), move |ty_podable_f_70305: bool| ::prism_rtl::Turn::Finished(crate::lower::model::TyDef { name_p: crate::lower::camel_f(&bare_p4xy), prism_p: bare_p4xy.clone(), params_p: params_p3xy.clone(), keyed_p: crate::prelude::each(&keyed_parameters_f_70040, &(|q_pc: &crate::prelude::Text| crate::lower::camel_f(q_pc))), shape_p: shape_pa.clone(), cases_p: cases_pb.clone(), eq_p: crate::check::types::has_text_f(&derives_p2xy, &crate::prelude::Text::lit("Prelude.Eq")), ord_p: crate::check::types::has_text_f(&derives_p2xy, &crate::prelude::Text::lit("Prelude.Ord")), show_p: if crate::lower::functions::has_own_show_f(&lx_p0xy, &ti_p1xy.name_p) {
                        crate::lower::model::Shown::ShownOwn
                    } else {
                        if crate::check::types::has_text_f(&derives_p2xy, &crate::prelude::Text::lit("Prelude.Show")) {
                            crate::lower::model::Shown::ShownDerived
                        } else {
                            crate::lower::model::Shown::NotShown
                        }
                    }, pod_p: ty_podable_f_70305 && crate::prelude::run_to_end(crate::prelude::fold_job(cases_pb.clone(), true, ::std::rc::Rc::new(move |(p0, p1): (bool, crate::lower::model::CaseDef)| crate::prelude::entered(crate::prelude::once_job(move || {
                        let ok_pd = p0;
                        let c_pe = p1;
                        if ok_pd {
                            crate::prelude::fold_job(c_pe.fields_p.clone(), true, ::std::rc::Rc::new(move |(p0, p1): (bool, (crate::prelude::Text, crate::lower::model::OutTy))| crate::prelude::entered(crate::prelude::once_job(move || {
                                let ok2_pf = p0;
                                let (_, ft_pg) = p1;
                                if ok2_pf {
                                    ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::lower::types::Podable { t_p0: ft_pg.clone() }))
                                } else {
                                    ::prism_rtl::Turn::Finished(false)
                                }
                            }))) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, (crate::prelude::Text, crate::lower::model::OutTy))) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>).cycle()
                        } else {
                            ::prism_rtl::Turn::Finished(false)
                        }
                    }))) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::lower::model::CaseDef)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>)), doc_p: type_doc_f(&lx_p0xy, &ti_p1xy) })))
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::model::TyShape, crate::prelude::Array<crate::lower::model::CaseDef>)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::TyDef>>>
        };
        match &ti_p1.body_p {
            crate::check::env::TyBody::BRecord(fs_ph) => {
                let fs_phx = fs_ph.clone();
                let lx_p0x = lx_p0.clone();
                let ti_p1x = ti_p1.clone();
                crate::prelude::call_value(crate::prelude::each_job(crate::check::errors::range0_f(&crate::prelude::len(&fs_phx)), {
                    let fs_phxx = fs_phx.clone();
                    let lx_p0xx = lx_p0x.clone();
                    let ti_p1xx = ti_p1x.clone();
                    ::std::rc::Rc::new(move |p0: crate::prelude::Nat| {
                        let fs_phxxy = fs_phxx.clone();
                        let lx_p0xxy = lx_p0xx.clone();
                        let ti_p1xxy = ti_p1xx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let i_pj = p0;
                            {
                                let (fname_pl, ft_pm) = crate::prelude::or(&crate::prelude::index(&fs_phxxy, &i_pj), &(crate::prelude::Text::lit(""), crate::check::types::Ty::TyErr));
                                crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0xxy.clone(), ft_pm.clone()), move |out_ty_of_f_70651: crate::lower::model::OutTy| {
                                    let rt_pk = out_ty_of_f_70651;
                                    crate::prelude::call_then(crate::lower::start_field_spell_f(ti_p1xxy.home_p.clone(), fname_pl.clone(), ft_pm.clone()), move |field_spell_f_70685: crate::prelude::Text| ::prism_rtl::Turn::Finished((field_spell_f_70685, if crate::lower::types::rc_field_f(&lx_p0xxy, &ti_p1xxy.name_p, &i_pj) {
                                        crate::lower::model::OutTy::OutRc(::std::rc::Rc::new(rt_pk.clone()))
                                    } else {
                                        rt_pk.clone()
                                    })))
                                })
                            }
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Text, crate::lower::model::OutTy)>>>
                }), move |each_70537: crate::prelude::Array<(crate::prelude::Text, crate::lower::model::OutTy)>| {
                    let fields_pi = each_70537;
                    crate::prelude::call_value((&mk_f5)((crate::lower::model::TyShape::ShapeRecord, crate::prelude::Array::from(vec![crate::lower::model::CaseDef { name_p: crate::lower::camel_f(&bare_p4), prism_p: bare_p4.clone(), fields_p: fields_pi.clone(), labels_p: crate::prelude::each(&fs_phx, &(|(fname_pn, _): &(crate::prelude::Text, crate::check::types::Ty)| fname_pn.clone())) }]))), move |mk_70788: crate::lower::model::TyDef| ::prism_rtl::Turn::Finished(crate::prelude::Array::from(vec![crate::lower::model::Item::ItType(mk_70788)])))
                })
            },
            crate::check::env::TyBody::BChoice(cases_po) => {
                let cases_pox = cases_po.clone();
                let lx_p0x = lx_p0.clone();
                let ti_p1x = ti_p1.clone();
                crate::prelude::call_value(crate::prelude::each_job(cases_pox.clone(), {
                    let ti_p1xx = ti_p1x.clone();
                    let lx_p0xx = lx_p0x.clone();
                    ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::prelude::Array<crate::check::types::Ty>)| {
                        let ti_p1xxy = ti_p1xx.clone();
                        let lx_p0xxy = lx_p0xx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let (cn_pr, ats_ps) = p0;
                            {
                                let ck_pt = crate::check::env::qual_key_f(&ti_p1xxy.home_p, &cn_pr);
                                crate::prelude::call_value(crate::prelude::each_job(crate::check::errors::range0_f(&crate::prelude::len(&ats_ps)), {
                                    let lx_p0xxyx = lx_p0xxy.clone();
                                    let ck_ptx = ck_pt.clone();
                                    let ats_psx = ats_ps.clone();
                                    ::std::rc::Rc::new(move |p0: crate::prelude::Nat| {
                                        let lx_p0xxyxy = lx_p0xxyx.clone();
                                        let ck_ptxy = ck_ptx.clone();
                                        let ats_psxy = ats_psx.clone();
                                        crate::prelude::entered(crate::prelude::once_job(move || {
                                            let i_pu = p0;
                                            crate::prelude::call_then(start_case_field_f(lx_p0xxyxy.clone(), ck_ptxy.clone(), i_pu.clone(), crate::prelude::or(&crate::prelude::index(&ats_psxy, &i_pu), &crate::check::types::Ty::TyErr)), move |case_field_f_71125: crate::lower::model::OutTy| ::prism_rtl::Turn::Finished((crate::prelude::Text::lit(""), case_field_f_71125)))
                                        }))
                                    }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Text, crate::lower::model::OutTy)>>>
                                }), move |each_71088: crate::prelude::Array<(crate::prelude::Text, crate::lower::model::OutTy)>| ::prism_rtl::Turn::Finished(crate::lower::model::CaseDef { name_p: crate::lower::camel_f(&cn_pr), prism_p: cn_pr.clone(), fields_p: each_71088, labels_p: crate::prelude::Array::new() }))
                            }
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::prelude::Array<crate::check::types::Ty>)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::CaseDef>>>
                }), move |each_70957: crate::prelude::Array<crate::lower::model::CaseDef>| {
                    let defs_pp = each_70957;
                    let shape_pq = 'm71207: {
                        if let m71207_0 = &cases_pox && (m71207_0.len() == 1) && let ::std::option::Option::Some((cn_pv, m71207_0_0_1)) = crate::prelude::index(m71207_0, &crate::prelude::Nat::from(0u32)) && ((&m71207_0_0_1).len() == 0) {
                            break 'm71207 if crate::check::env::is_lower_text_f(&cn_pv) {
                                crate::lower::model::TyShape::ShapeUnit
                            } else {
                                crate::lower::model::TyShape::ShapeChoice
                            };
                        }
                        if let m71207_1 = &cases_pox && (m71207_1.len() == 1) && let ::std::option::Option::Some((cn_p10, _)) = crate::prelude::index(m71207_1, &crate::prelude::Nat::from(0u32)) {
                            break 'm71207 if &cn_p10 == &bare_p4 {
                                crate::lower::model::TyShape::ShapeNewtype
                            } else {
                                crate::lower::model::TyShape::ShapeChoice
                            };
                        }
                        crate::lower::model::TyShape::ShapeChoice
                    };
                    crate::prelude::call_value((&mk_f5)((shape_pq.clone(), defs_pp.clone())), move |mk_71444: crate::lower::model::TyDef| ::prism_rtl::Turn::Finished(crate::prelude::Array::from(vec![crate::lower::model::Item::ItType(mk_71444)])))
                })
            },
            crate::check::env::TyBody::BRowKind => if &ti_p1.name_p == &crate::prelude::Text::lit("Prelude.Fault") {
                ::prism_rtl::Turn::Finished(crate::prelude::Array::new())
            } else {
                {
                    let lx_p0x = lx_p0.clone();
                    let ti_p1x = ti_p1.clone();
                    crate::prelude::call_then(start_row_def_of_f(lx_p0x.clone(), ti_p1x.clone()), move |row_def_of_f_71531: crate::lower::model::RowDef| ::prism_rtl::Turn::Finished(crate::prelude::Array::from(vec![crate::lower::model::Item::ItRow(row_def_of_f_71531)])))
                }
            },
            _ => ::prism_rtl::Turn::Finished(crate::prelude::Array::new()),
        }
    }
}

/// `Start TyDefs, x`: what the function value is when passed to `@Run`.
pub fn start_ty_defs_f(lx_p0: crate::lower::Lx, ti_p1: crate::check::env::TyInfo) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::lower::model::Item>>> {
    ::std::rc::Rc::new(TyDefs { lx_p0, ti_p1 })
}

/// ```prism
/// KeyedParameters: unbounded fn Lx, Text -> [Text]
/// ```
pub fn keyed_parameters_f(lx_p0: &crate::lower::Lx, name_p1: &crate::prelude::Text) -> crate::prelude::Array<crate::prelude::Text> {
    match crate::prelude::get(&lx_p0.g_p.types_p, name_p1) {
        ::std::option::Option::Some(ti_p2) => if &crate::prelude::len(&ti_p2.params_p) == &crate::prelude::Nat::from(0u32) {
            crate::prelude::Array::new()
        } else {
            crate::prelude::or(&crate::prelude::get(&keyed_rounds_f(lx_p0, &crate::prelude::Map::new()), name_p1), &crate::prelude::Array::new())
        },
        ::std::option::Option::None => crate::prelude::Array::new(),
    }
}

/// The step machine of `KeyedParameters`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// KeyedParameters: unbounded fn Lx, Text -> [Text]
/// ```
pub struct KeyedParameters {
    pub lx_p0: crate::lower::Lx,
    pub name_p1: crate::prelude::Text,
}

impl ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>> for KeyedParameters {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<crate::prelude::Text>> {
        let lx_p0 = &self.lx_p0;
        let name_p1 = &self.name_p1;
        match crate::prelude::get(&lx_p0.g_p.types_p, name_p1) {
            ::std::option::Option::Some(ti_p2) => if &crate::prelude::len(&ti_p2.params_p) == &crate::prelude::Nat::from(0u32) {
                ::prism_rtl::Turn::Finished(crate::prelude::Array::new())
            } else {
                {
                    let lx_p0x = lx_p0.clone();
                    let name_p1x = name_p1.clone();
                    crate::prelude::call_then(start_keyed_rounds_f(lx_p0x.clone(), crate::prelude::Map::new()), move |keyed_rounds_f_72067: crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>>| ::prism_rtl::Turn::Finished(crate::prelude::or(&crate::prelude::get(&keyed_rounds_f_72067, &name_p1x), &crate::prelude::Array::new())))
                }
            },
            ::std::option::Option::None => ::prism_rtl::Turn::Finished(crate::prelude::Array::new()),
        }
    }
}

/// `Start KeyedParameters, x`: what the function value is when passed to `@Run`.
pub fn start_keyed_parameters_f(lx_p0: crate::lower::Lx, name_p1: crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>> {
    ::std::rc::Rc::new(KeyedParameters { lx_p0, name_p1 })
}

/// ```prism
/// KeyedRounds: unbounded fn Lx, (Text ==> [Text]) -> (Text ==> [Text])
/// ```
pub fn keyed_rounds_f(lx_p0: &crate::lower::Lx, known_p1: &crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>>) -> crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>> {
    let next_p2 = crate::prelude::run_to_end(crate::prelude::fold_job(crate::prelude::values(&lx_p0.g_p.types_p), known_p1.clone(), {
        let lx_p0x = lx_p0.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>>, crate::check::env::TyInfo)| {
            let lx_p0xy = lx_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let m_p3 = p0;
                let ti_p4 = p1;
                if &crate::prelude::len(&ti_p4.params_p) == &crate::prelude::Nat::from(0u32) {
                    ::prism_rtl::Turn::Finished(m_p3.clone())
                } else {
                    {
                        let fields_p5 = match &ti_p4.body_p {
                            crate::check::env::TyBody::BRecord(fs_p7) => crate::prelude::each(fs_p7, &(|(_, ft_p8): &(crate::prelude::Text, crate::check::types::Ty)| ft_p8.clone())),
                            crate::check::env::TyBody::BChoice(cases_p9) => crate::prelude::fold(cases_p9, &crate::prelude::Array::new(), &(|acc_pa: &crate::prelude::Array<crate::check::types::Ty>, (_, ats_pb): &(crate::prelude::Text, crate::prelude::Array<crate::check::types::Ty>)| crate::prelude::append(acc_pa, ats_pb))),
                            _ => crate::prelude::Array::new(),
                        };
                        crate::prelude::call_value(crate::prelude::fold_job(fields_p5.clone(), crate::prelude::or(&crate::prelude::get(&m_p3, &ti_p4.name_p), &crate::prelude::Array::new()), {
                            let lx_p0xyx = lx_p0xy.clone();
                            let m_p3x = m_p3.clone();
                            ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::check::types::Ty)| {
                                let lx_p0xyxy = lx_p0xyx.clone();
                                let m_p3xy = m_p3x.clone();
                                crate::prelude::entered(crate::prelude::once_job(move || {
                                    let acc_pc = p0;
                                    let ft_pd = p1;
                                    crate::prelude::call_then(start_keyed_in_f(lx_p0xyxy.clone(), m_p3xy.clone(), ft_pd.clone(), false), move |keyed_in_f_72622: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_pc, &keyed_in_f_72622)))
                                }))
                            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::check::types::Ty)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>
                        }), move |fold_72558: crate::prelude::Array<crate::prelude::Text>| {
                            let found_p6 = fold_72558;
                            ::prism_rtl::Turn::Finished(crate::prelude::insert(&m_p3, &ti_p4.name_p, &crate::prelude::filter(&found_p6, &(|q_pe: &crate::prelude::Text| crate::check::types::has_text_f(&ti_p4.params_p, q_pe)))))
                        })
                    }
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>>, crate::check::env::TyInfo)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>>>>>
    }));
    if &crate::prelude::show_text(&next_p2) == &crate::prelude::show_text(known_p1) {
        known_p1.clone()
    } else {
        keyed_rounds_f(lx_p0, &next_p2)
    }
}

/// The step machine of `KeyedRounds`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// KeyedRounds: unbounded fn Lx, (Text ==> [Text]) -> (Text ==> [Text])
/// ```
pub struct KeyedRounds {
    pub lx_p0: crate::lower::Lx,
    pub known_p1: crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>>,
}

impl ::prism_rtl::Job<crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>>> for KeyedRounds {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>>> {
        let lx_p0 = &self.lx_p0;
        let known_p1 = &self.known_p1;
        let known_p1x = known_p1.clone();
        let lx_p0x = lx_p0.clone();
        crate::prelude::call_value(crate::prelude::fold_job(crate::prelude::values(&lx_p0x.g_p.types_p), known_p1x.clone(), {
            let lx_p0xx = lx_p0x.clone();
            ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>>, crate::check::env::TyInfo)| {
                let lx_p0xxy = lx_p0xx.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let m_p3 = p0;
                    let ti_p4 = p1;
                    if &crate::prelude::len(&ti_p4.params_p) == &crate::prelude::Nat::from(0u32) {
                        ::prism_rtl::Turn::Finished(m_p3.clone())
                    } else {
                        {
                            let fields_p5 = match &ti_p4.body_p {
                                crate::check::env::TyBody::BRecord(fs_p7) => crate::prelude::each(fs_p7, &(|(_, ft_p8): &(crate::prelude::Text, crate::check::types::Ty)| ft_p8.clone())),
                                crate::check::env::TyBody::BChoice(cases_p9) => crate::prelude::fold(cases_p9, &crate::prelude::Array::new(), &(|acc_pa: &crate::prelude::Array<crate::check::types::Ty>, (_, ats_pb): &(crate::prelude::Text, crate::prelude::Array<crate::check::types::Ty>)| crate::prelude::append(acc_pa, ats_pb))),
                                _ => crate::prelude::Array::new(),
                            };
                            crate::prelude::call_value(crate::prelude::fold_job(fields_p5.clone(), crate::prelude::or(&crate::prelude::get(&m_p3, &ti_p4.name_p), &crate::prelude::Array::new()), {
                                let lx_p0xxyx = lx_p0xxy.clone();
                                let m_p3x = m_p3.clone();
                                ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::check::types::Ty)| {
                                    let lx_p0xxyxy = lx_p0xxyx.clone();
                                    let m_p3xy = m_p3x.clone();
                                    crate::prelude::entered(crate::prelude::once_job(move || {
                                        let acc_pc = p0;
                                        let ft_pd = p1;
                                        crate::prelude::call_then(start_keyed_in_f(lx_p0xxyxy.clone(), m_p3xy.clone(), ft_pd.clone(), false), move |keyed_in_f_72622: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_pc, &keyed_in_f_72622)))
                                    }))
                                }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::check::types::Ty)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>
                            }), move |fold_72558: crate::prelude::Array<crate::prelude::Text>| {
                                let found_p6 = fold_72558;
                                ::prism_rtl::Turn::Finished(crate::prelude::insert(&m_p3, &ti_p4.name_p, &crate::prelude::filter(&found_p6, &(|q_pe: &crate::prelude::Text| crate::check::types::has_text_f(&ti_p4.params_p, q_pe)))))
                            })
                        }
                    }
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>>, crate::check::env::TyInfo)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>>>>>
        }), move |fold_72224: crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>>| {
            let next_p2 = fold_72224;
            if &crate::prelude::show_text(&next_p2) == &crate::prelude::show_text(&known_p1x) {
                ::prism_rtl::Turn::Finished(known_p1x.clone())
            } else {
                ::prism_rtl::Turn::More(::std::rc::Rc::new(KeyedRounds { lx_p0: lx_p0x.clone(), known_p1: next_p2.clone() }))
            }
        })
    }
}

/// `Start KeyedRounds, x`: what the function value is when passed to `@Run`.
pub fn start_keyed_rounds_f(lx_p0: crate::lower::Lx, known_p1: crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>>>> {
    ::std::rc::Rc::new(KeyedRounds { lx_p0, known_p1 })
}

/// ```prism
/// KeyedIn: unbounded fn Lx, (Text ==> [Text]), Ty, Bool -> [Text]
/// ```
pub fn keyed_in_f(lx_p0: &crate::lower::Lx, known_p1: &crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>>, t_p2: &crate::check::types::Ty, in_key_p3: &bool) -> crate::prelude::Array<crate::prelude::Text> {
    match t_p2 {
        crate::check::types::Ty::TyQ(q_p4) => if *in_key_p3 {
            crate::prelude::Array::from(vec![q_p4.clone()])
        } else {
            crate::prelude::Array::new()
        },
        crate::check::types::Ty::TyRigid(q_p5) => if *in_key_p3 {
            crate::prelude::Array::from(vec![q_p5.clone()])
        } else {
            crate::prelude::Array::new()
        },
        crate::check::types::Ty::TyMap(k_p6, v_p7) => crate::check::types::union_texts_f(&keyed_in_f(lx_p0, known_p1, &**k_p6, &true), &keyed_in_f(lx_p0, known_p1, &**v_p7, in_key_p3)),
        crate::check::types::Ty::TyCon(n_p8, args_p9) => {
            let params_pa = match crate::prelude::get(&lx_p0.g_p.types_p, n_p8) {
                ::std::option::Option::Some(ti_pc) => ti_pc.params_p.clone(),
                ::std::option::Option::None => crate::prelude::Array::new(),
            };
            let keyed_pb = crate::prelude::or(&crate::prelude::get(known_p1, n_p8), &crate::prelude::Array::new());
            crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(args_p9)), crate::prelude::Array::new(), {
                let lx_p0x = lx_p0.clone();
                let known_p1x = known_p1.clone();
                let args_p9x = args_p9.clone();
                let in_key_p3x = *in_key_p3;
                let keyed_pbx = keyed_pb.clone();
                let params_pax = params_pa.clone();
                ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::prelude::Nat)| {
                    let lx_p0xy = lx_p0x.clone();
                    let known_p1xy = known_p1x.clone();
                    let args_p9xy = args_p9x.clone();
                    let in_key_p3xy = in_key_p3x;
                    let keyed_pbxy = keyed_pbx.clone();
                    let params_paxy = params_pax.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let acc_pd = p0;
                        let i_pe = p1;
                        crate::prelude::call_then(start_keyed_in_f(lx_p0xy.clone(), known_p1xy.clone(), crate::prelude::or(&crate::prelude::index(&args_p9xy, &i_pe), &crate::check::types::Ty::TyErr), in_key_p3xy || crate::check::types::has_text_f(&keyed_pbxy, &crate::prelude::or(&crate::prelude::index(&params_paxy, &i_pe), &crate::prelude::Text::lit("")))), move |keyed_in_f_73442: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_pd, &keyed_in_f_73442)))
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>
            }))
        },
        other_pf => crate::prelude::run_to_end(crate::prelude::fold_job(parts_of_type_f(other_pf), crate::prelude::Array::new(), {
            let lx_p0x = lx_p0.clone();
            let known_p1x = known_p1.clone();
            let in_key_p3x = *in_key_p3;
            ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::check::types::Ty)| {
                let lx_p0xy = lx_p0x.clone();
                let known_p1xy = known_p1x.clone();
                let in_key_p3xy = in_key_p3x;
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let acc_pg = p0;
                    let part_ph = p1;
                    crate::prelude::call_then(start_keyed_in_f(lx_p0xy.clone(), known_p1xy.clone(), part_ph.clone(), in_key_p3xy), move |keyed_in_f_73601: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_pg, &keyed_in_f_73601)))
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::check::types::Ty)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>
        })),
    }
}

/// The step machine of `KeyedIn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// KeyedIn: unbounded fn Lx, (Text ==> [Text]), Ty, Bool -> [Text]
/// ```
pub struct KeyedIn {
    pub lx_p0: crate::lower::Lx,
    pub known_p1: crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>>,
    pub t_p2: crate::check::types::Ty,
    pub in_key_p3: bool,
}

impl ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>> for KeyedIn {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<crate::prelude::Text>> {
        let lx_p0 = &self.lx_p0;
        let known_p1 = &self.known_p1;
        let t_p2 = &self.t_p2;
        let in_key_p3 = &self.in_key_p3;
        match t_p2 {
            crate::check::types::Ty::TyQ(q_p4) => if *in_key_p3 {
                ::prism_rtl::Turn::Finished(crate::prelude::Array::from(vec![q_p4.clone()]))
            } else {
                ::prism_rtl::Turn::Finished(crate::prelude::Array::new())
            },
            crate::check::types::Ty::TyRigid(q_p5) => if *in_key_p3 {
                ::prism_rtl::Turn::Finished(crate::prelude::Array::from(vec![q_p5.clone()]))
            } else {
                ::prism_rtl::Turn::Finished(crate::prelude::Array::new())
            },
            crate::check::types::Ty::TyMap(k_p6, v_p7) => {
                let in_key_p3x = *in_key_p3;
                let k_p6x = (**k_p6).clone();
                let known_p1x = known_p1.clone();
                let lx_p0x = lx_p0.clone();
                let v_p7x = (**v_p7).clone();
                crate::prelude::call_then(start_keyed_in_f(lx_p0x.clone(), known_p1x.clone(), k_p6x.clone(), true), move |keyed_in_f_73167: crate::prelude::Array<crate::prelude::Text>| crate::prelude::call_then(start_keyed_in_f(lx_p0x.clone(), known_p1x.clone(), v_p7x.clone(), in_key_p3x), move |keyed_in_f_73197: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&keyed_in_f_73167, &keyed_in_f_73197))))
            },
            crate::check::types::Ty::TyCon(n_p8, args_p9) => {
                let params_pa = match crate::prelude::get(&lx_p0.g_p.types_p, n_p8) {
                    ::std::option::Option::Some(ti_pc) => ti_pc.params_p.clone(),
                    ::std::option::Option::None => crate::prelude::Array::new(),
                };
                let keyed_pb = crate::prelude::or(&crate::prelude::get(known_p1, n_p8), &crate::prelude::Array::new());
                crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(args_p9)), crate::prelude::Array::new(), {
                    let lx_p0x = lx_p0.clone();
                    let known_p1x = known_p1.clone();
                    let args_p9x = args_p9.clone();
                    let in_key_p3x = *in_key_p3;
                    let keyed_pbx = keyed_pb.clone();
                    let params_pax = params_pa.clone();
                    ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::prelude::Nat)| {
                        let lx_p0xy = lx_p0x.clone();
                        let known_p1xy = known_p1x.clone();
                        let args_p9xy = args_p9x.clone();
                        let in_key_p3xy = in_key_p3x;
                        let keyed_pbxy = keyed_pbx.clone();
                        let params_paxy = params_pax.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let acc_pd = p0;
                            let i_pe = p1;
                            crate::prelude::call_then(start_keyed_in_f(lx_p0xy.clone(), known_p1xy.clone(), crate::prelude::or(&crate::prelude::index(&args_p9xy, &i_pe), &crate::check::types::Ty::TyErr), in_key_p3xy || crate::check::types::has_text_f(&keyed_pbxy, &crate::prelude::or(&crate::prelude::index(&params_paxy, &i_pe), &crate::prelude::Text::lit("")))), move |keyed_in_f_73442: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_pd, &keyed_in_f_73442)))
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>
                }).cycle()
            },
            other_pf => crate::prelude::fold_job(parts_of_type_f(other_pf), crate::prelude::Array::new(), {
                let lx_p0x = lx_p0.clone();
                let known_p1x = known_p1.clone();
                let in_key_p3x = *in_key_p3;
                ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::check::types::Ty)| {
                    let lx_p0xy = lx_p0x.clone();
                    let known_p1xy = known_p1x.clone();
                    let in_key_p3xy = in_key_p3x;
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let acc_pg = p0;
                        let part_ph = p1;
                        crate::prelude::call_then(start_keyed_in_f(lx_p0xy.clone(), known_p1xy.clone(), part_ph.clone(), in_key_p3xy), move |keyed_in_f_73601: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_pg, &keyed_in_f_73601)))
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::check::types::Ty)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>
            }).cycle(),
        }
    }
}

/// `Start KeyedIn, x`: what the function value is when passed to `@Run`.
pub fn start_keyed_in_f(lx_p0: crate::lower::Lx, known_p1: crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>>, t_p2: crate::check::types::Ty, in_key_p3: bool) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>> {
    ::std::rc::Rc::new(KeyedIn { lx_p0, known_p1, t_p2, in_key_p3 })
}

/// ```prism
/// TyPodable: unbounded fn Lx, Ty, [Text] -> Bool
/// ```
pub fn ty_podable_f(lx_p0: &crate::lower::Lx, t_p1: &crate::check::types::Ty, seen_p2: &crate::prelude::Array<crate::prelude::Text>) -> bool {
    'm73911: {
        if let crate::check::types::Ty::TyFn(_, _, _) = t_p1 {
            break 'm73911 false;
        }
        if let crate::check::types::Ty::TyAt(_, _) = t_p1 {
            break 'm73911 false;
        }
        if let crate::check::types::Ty::TySig(m73911_2_0, _) = t_p1 && (m73911_2_0 == &crate::prelude::Text::lit("!")) {
            break 'm73911 false;
        }
        if let crate::check::types::Ty::TySig(m73911_3_0, _) = t_p1 && (m73911_3_0 == &crate::prelude::Text::lit("$")) {
            break 'm73911 false;
        }
        if let crate::check::types::Ty::TySig(_, i_p3) = t_p1 {
            break 'm73911 ty_podable_f(lx_p0, &**i_p3, seen_p2);
        }
        if let crate::check::types::Ty::TyTuple(ts_p4) = t_p1 {
            break 'm73911 crate::prelude::run_to_end(crate::prelude::fold_job(ts_p4.clone(), true, {
                let lx_p0x = lx_p0.clone();
                let seen_p2x = seen_p2.clone();
                ::std::rc::Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| {
                    let lx_p0xy = lx_p0x.clone();
                    let seen_p2xy = seen_p2x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let ok_p5 = p0;
                        let x_p6 = p1;
                        if ok_p5 {
                            ::prism_rtl::Turn::More(::std::rc::Rc::new(TyPodable { lx_p0: lx_p0xy.clone(), t_p1: x_p6.clone(), seen_p2: seen_p2xy.clone() }))
                        } else {
                            ::prism_rtl::Turn::Finished(false)
                        }
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::check::types::Ty)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
            }));
        }
        if let crate::check::types::Ty::TyArray(e_p7) = t_p1 {
            break 'm73911 ty_podable_f(lx_p0, &**e_p7, seen_p2);
        }
        if let crate::check::types::Ty::TyMap(k_p8, v_p9) = t_p1 {
            break 'm73911 ty_podable_f(lx_p0, &**k_p8, seen_p2) && ty_podable_f(lx_p0, &**v_p9, seen_p2);
        }
        if let crate::check::types::Ty::TyCon(m73911_8_0, m73911_8_1) = t_p1 && (m73911_8_0 == &crate::prelude::Text::lit("Prelude.NonEmpty")) && (m73911_8_1.len() == 1) && let ::std::option::Option::Some(c_pa) = crate::prelude::index(m73911_8_1, &crate::prelude::Nat::from(0u32)) {
            break 'm73911 ty_podable_f(lx_p0, &c_pa, seen_p2);
        }
        if let crate::check::types::Ty::TyCon(n_pb, args_pc) = t_p1 {
            break 'm73911 if crate::check::types::has_text_f(seen_p2, n_pb) {
                true
            } else {
                {
                    let more_pd = crate::prelude::push(seen_p2, n_pb);
                    let args_ok_pe = crate::prelude::run_to_end(crate::prelude::fold_job(args_pc.clone(), true, {
                        let lx_p0x = lx_p0.clone();
                        let more_pdx = more_pd.clone();
                        ::std::rc::Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| {
                            let lx_p0xy = lx_p0x.clone();
                            let more_pdxy = more_pdx.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let ok_pf = p0;
                                let x_pg = p1;
                                if ok_pf {
                                    ::prism_rtl::Turn::More(::std::rc::Rc::new(TyPodable { lx_p0: lx_p0xy.clone(), t_p1: x_pg.clone(), seen_p2: more_pdxy.clone() }))
                                } else {
                                    ::prism_rtl::Turn::Finished(false)
                                }
                            }))
                        }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::check::types::Ty)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
                    }));
                    args_ok_pe && match crate::prelude::get(&lx_p0.g_p.types_p, n_pb) {
                        ::std::option::Option::Some(ti_ph) => match &ti_ph.body_p {
                            crate::check::env::TyBody::BRecord(fs_pi) => crate::prelude::run_to_end(crate::prelude::fold_job(fs_pi.clone(), true, {
                                let lx_p0x = lx_p0.clone();
                                let more_pdx = more_pd.clone();
                                ::std::rc::Rc::new(move |(p0, p1): (bool, (crate::prelude::Text, crate::check::types::Ty))| {
                                    let lx_p0xy = lx_p0x.clone();
                                    let more_pdxy = more_pdx.clone();
                                    crate::prelude::entered(crate::prelude::once_job(move || {
                                        let ok_pj = p0;
                                        let (_, ft_pk) = p1;
                                        if ok_pj {
                                            ::prism_rtl::Turn::More(::std::rc::Rc::new(TyPodable { lx_p0: lx_p0xy.clone(), t_p1: ft_pk.clone(), seen_p2: more_pdxy.clone() }))
                                        } else {
                                            ::prism_rtl::Turn::Finished(false)
                                        }
                                    }))
                                }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, (crate::prelude::Text, crate::check::types::Ty))) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
                            })),
                            crate::check::env::TyBody::BChoice(cs_pl) => crate::prelude::run_to_end(crate::prelude::fold_job(cs_pl.clone(), true, {
                                let lx_p0x = lx_p0.clone();
                                let more_pdx = more_pd.clone();
                                ::std::rc::Rc::new(move |(p0, p1): (bool, (crate::prelude::Text, crate::prelude::Array<crate::check::types::Ty>))| {
                                    let lx_p0xy = lx_p0x.clone();
                                    let more_pdxy = more_pdx.clone();
                                    crate::prelude::entered(crate::prelude::once_job(move || {
                                        let ok_pm = p0;
                                        let (_, ats_pn) = p1;
                                        if ok_pm {
                                            crate::prelude::fold_job(ats_pn.clone(), true, {
                                                let lx_p0xyx = lx_p0xy.clone();
                                                let more_pdxyx = more_pdxy.clone();
                                                ::std::rc::Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| {
                                                    let lx_p0xyxy = lx_p0xyx.clone();
                                                    let more_pdxyxy = more_pdxyx.clone();
                                                    crate::prelude::entered(crate::prelude::once_job(move || {
                                                        let ok2_po = p0;
                                                        let x_pp = p1;
                                                        if ok2_po {
                                                            ::prism_rtl::Turn::More(::std::rc::Rc::new(TyPodable { lx_p0: lx_p0xyxy.clone(), t_p1: x_pp.clone(), seen_p2: more_pdxyxy.clone() }))
                                                        } else {
                                                            ::prism_rtl::Turn::Finished(false)
                                                        }
                                                    }))
                                                }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::check::types::Ty)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
                                            }).cycle()
                                        } else {
                                            ::prism_rtl::Turn::Finished(false)
                                        }
                                    }))
                                }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, (crate::prelude::Text, crate::prelude::Array<crate::check::types::Ty>))) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
                            })),
                            crate::check::env::TyBody::BAlias(a_pq) => ty_podable_f(lx_p0, a_pq, &more_pd),
                            _ => true,
                        },
                        ::std::option::Option::None => true,
                    }
                }
            };
        }
        true
    }
}

/// The step machine of `TyPodable`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TyPodable: unbounded fn Lx, Ty, [Text] -> Bool
/// ```
pub struct TyPodable {
    pub lx_p0: crate::lower::Lx,
    pub t_p1: crate::check::types::Ty,
    pub seen_p2: crate::prelude::Array<crate::prelude::Text>,
}

impl ::prism_rtl::Job<bool> for TyPodable {
    fn cycle(&self) -> ::prism_rtl::Turn<bool> {
        let lx_p0 = &self.lx_p0;
        let t_p1 = &self.t_p1;
        let seen_p2 = &self.seen_p2;
        'm73911: {
            if let crate::check::types::Ty::TyFn(_, _, _) = t_p1 {
                break 'm73911 ::prism_rtl::Turn::Finished(false);
            }
            if let crate::check::types::Ty::TyAt(_, _) = t_p1 {
                break 'm73911 ::prism_rtl::Turn::Finished(false);
            }
            if let crate::check::types::Ty::TySig(m73911_2_0, _) = t_p1 && (m73911_2_0 == &crate::prelude::Text::lit("!")) {
                break 'm73911 ::prism_rtl::Turn::Finished(false);
            }
            if let crate::check::types::Ty::TySig(m73911_3_0, _) = t_p1 && (m73911_3_0 == &crate::prelude::Text::lit("$")) {
                break 'm73911 ::prism_rtl::Turn::Finished(false);
            }
            if let crate::check::types::Ty::TySig(_, i_p3) = t_p1 {
                break 'm73911 ::prism_rtl::Turn::More(::std::rc::Rc::new(TyPodable { lx_p0: lx_p0.clone(), t_p1: (**i_p3).clone(), seen_p2: seen_p2.clone() }));
            }
            if let crate::check::types::Ty::TyTuple(ts_p4) = t_p1 {
                break 'm73911 crate::prelude::fold_job(ts_p4.clone(), true, {
                    let lx_p0x = lx_p0.clone();
                    let seen_p2x = seen_p2.clone();
                    ::std::rc::Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| {
                        let lx_p0xy = lx_p0x.clone();
                        let seen_p2xy = seen_p2x.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let ok_p5 = p0;
                            let x_p6 = p1;
                            if ok_p5 {
                                ::prism_rtl::Turn::More(::std::rc::Rc::new(TyPodable { lx_p0: lx_p0xy.clone(), t_p1: x_p6.clone(), seen_p2: seen_p2xy.clone() }))
                            } else {
                                ::prism_rtl::Turn::Finished(false)
                            }
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::check::types::Ty)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
                }).cycle();
            }
            if let crate::check::types::Ty::TyArray(e_p7) = t_p1 {
                break 'm73911 ::prism_rtl::Turn::More(::std::rc::Rc::new(TyPodable { lx_p0: lx_p0.clone(), t_p1: (**e_p7).clone(), seen_p2: seen_p2.clone() }));
            }
            if let crate::check::types::Ty::TyMap(k_p8, v_p9) = t_p1 {
                break 'm73911 {
                    let k_p8x = (**k_p8).clone();
                    let lx_p0x = lx_p0.clone();
                    let seen_p2x = seen_p2.clone();
                    let v_p9x = (**v_p9).clone();
                    crate::prelude::call_then(start_ty_podable_f(lx_p0x.clone(), k_p8x.clone(), seen_p2x.clone()), move |ty_podable_f_74214: bool| if ty_podable_f_74214 {
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(TyPodable { lx_p0: lx_p0x.clone(), t_p1: v_p9x.clone(), seen_p2: seen_p2x.clone() }))
                    } else {
                        ::prism_rtl::Turn::Finished(false)
                    })
                };
            }
            if let crate::check::types::Ty::TyCon(m73911_8_0, m73911_8_1) = t_p1 && (m73911_8_0 == &crate::prelude::Text::lit("Prelude.NonEmpty")) && (m73911_8_1.len() == 1) && let ::std::option::Option::Some(c_pa) = crate::prelude::index(m73911_8_1, &crate::prelude::Nat::from(0u32)) {
                break 'm73911 ::prism_rtl::Turn::More(::std::rc::Rc::new(TyPodable { lx_p0: lx_p0.clone(), t_p1: c_pa.clone(), seen_p2: seen_p2.clone() }));
            }
            if let crate::check::types::Ty::TyCon(n_pb, args_pc) = t_p1 {
                break 'm73911 if crate::check::types::has_text_f(seen_p2, n_pb) {
                    ::prism_rtl::Turn::Finished(true)
                } else {
                    {
                        let more_pd = crate::prelude::push(seen_p2, n_pb);
                        let args_pcx = args_pc.clone();
                        let lx_p0x = lx_p0.clone();
                        let n_pbx = n_pb.clone();
                        crate::prelude::call_value(crate::prelude::fold_job(args_pcx.clone(), true, {
                            let lx_p0xx = lx_p0x.clone();
                            let more_pdx = more_pd.clone();
                            ::std::rc::Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| {
                                let lx_p0xxy = lx_p0xx.clone();
                                let more_pdxy = more_pdx.clone();
                                crate::prelude::entered(crate::prelude::once_job(move || {
                                    let ok_pf = p0;
                                    let x_pg = p1;
                                    if ok_pf {
                                        ::prism_rtl::Turn::More(::std::rc::Rc::new(TyPodable { lx_p0: lx_p0xxy.clone(), t_p1: x_pg.clone(), seen_p2: more_pdxy.clone() }))
                                    } else {
                                        ::prism_rtl::Turn::Finished(false)
                                    }
                                }))
                            }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::check::types::Ty)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
                        }), move |fold_74449: bool| {
                            let args_ok_pe = fold_74449;
                            if args_ok_pe {
                                match crate::prelude::get(&lx_p0x.g_p.types_p, &n_pbx) {
                                    ::std::option::Option::Some(ti_ph) => match &ti_ph.body_p {
                                        crate::check::env::TyBody::BRecord(fs_pi) => crate::prelude::fold_job(fs_pi.clone(), true, {
                                            let lx_p0xx = lx_p0x.clone();
                                            let more_pdx = more_pd.clone();
                                            ::std::rc::Rc::new(move |(p0, p1): (bool, (crate::prelude::Text, crate::check::types::Ty))| {
                                                let lx_p0xxy = lx_p0xx.clone();
                                                let more_pdxy = more_pdx.clone();
                                                crate::prelude::entered(crate::prelude::once_job(move || {
                                                    let ok_pj = p0;
                                                    let (_, ft_pk) = p1;
                                                    if ok_pj {
                                                        ::prism_rtl::Turn::More(::std::rc::Rc::new(TyPodable { lx_p0: lx_p0xxy.clone(), t_p1: ft_pk.clone(), seen_p2: more_pdxy.clone() }))
                                                    } else {
                                                        ::prism_rtl::Turn::Finished(false)
                                                    }
                                                }))
                                            }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, (crate::prelude::Text, crate::check::types::Ty))) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
                                        }).cycle(),
                                        crate::check::env::TyBody::BChoice(cs_pl) => crate::prelude::fold_job(cs_pl.clone(), true, {
                                            let lx_p0xx = lx_p0x.clone();
                                            let more_pdx = more_pd.clone();
                                            ::std::rc::Rc::new(move |(p0, p1): (bool, (crate::prelude::Text, crate::prelude::Array<crate::check::types::Ty>))| {
                                                let lx_p0xxy = lx_p0xx.clone();
                                                let more_pdxy = more_pdx.clone();
                                                crate::prelude::entered(crate::prelude::once_job(move || {
                                                    let ok_pm = p0;
                                                    let (_, ats_pn) = p1;
                                                    if ok_pm {
                                                        crate::prelude::fold_job(ats_pn.clone(), true, {
                                                            let lx_p0xxyx = lx_p0xxy.clone();
                                                            let more_pdxyx = more_pdxy.clone();
                                                            ::std::rc::Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| {
                                                                let lx_p0xxyxy = lx_p0xxyx.clone();
                                                                let more_pdxyxy = more_pdxyx.clone();
                                                                crate::prelude::entered(crate::prelude::once_job(move || {
                                                                    let ok2_po = p0;
                                                                    let x_pp = p1;
                                                                    if ok2_po {
                                                                        ::prism_rtl::Turn::More(::std::rc::Rc::new(TyPodable { lx_p0: lx_p0xxyxy.clone(), t_p1: x_pp.clone(), seen_p2: more_pdxyxy.clone() }))
                                                                    } else {
                                                                        ::prism_rtl::Turn::Finished(false)
                                                                    }
                                                                }))
                                                            }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::check::types::Ty)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
                                                        }).cycle()
                                                    } else {
                                                        ::prism_rtl::Turn::Finished(false)
                                                    }
                                                }))
                                            }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, (crate::prelude::Text, crate::prelude::Array<crate::check::types::Ty>))) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
                                        }).cycle(),
                                        crate::check::env::TyBody::BAlias(a_pq) => ::prism_rtl::Turn::More(::std::rc::Rc::new(TyPodable { lx_p0: lx_p0x.clone(), t_p1: a_pq.clone(), seen_p2: more_pd.clone() })),
                                        _ => ::prism_rtl::Turn::Finished(true),
                                    },
                                    ::std::option::Option::None => ::prism_rtl::Turn::Finished(true),
                                }
                            } else {
                                ::prism_rtl::Turn::Finished(false)
                            }
                        })
                    }
                };
            }
            ::prism_rtl::Turn::Finished(true)
        }
    }
}

/// `Start TyPodable, x`: what the function value is when passed to `@Run`.
pub fn start_ty_podable_f(lx_p0: crate::lower::Lx, t_p1: crate::check::types::Ty, seen_p2: crate::prelude::Array<crate::prelude::Text>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>> {
    ::std::rc::Rc::new(TyPodable { lx_p0, t_p1, seen_p2 })
}

/// ```prism
/// TyHasEq: unbounded fn Lx, Ty, [Text] -> Bool
/// ```
pub fn ty_has_eq_f(lx_p0: &crate::lower::Lx, t_p1: &crate::check::types::Ty, seen_p2: &crate::prelude::Array<crate::prelude::Text>) -> bool {
    'm75403: {
        if let crate::check::types::Ty::TyFn(_, _, _) = t_p1 {
            break 'm75403 false;
        }
        if let crate::check::types::Ty::TyAt(_, _) = t_p1 {
            break 'm75403 false;
        }
        if let crate::check::types::Ty::TySig(m75403_2_0, _) = t_p1 && (m75403_2_0 == &crate::prelude::Text::lit("!")) {
            break 'm75403 false;
        }
        if let crate::check::types::Ty::TySig(m75403_3_0, _) = t_p1 && (m75403_3_0 == &crate::prelude::Text::lit("$")) {
            break 'm75403 false;
        }
        if let crate::check::types::Ty::TySig(_, i_p3) = t_p1 {
            break 'm75403 ty_has_eq_f(lx_p0, &**i_p3, seen_p2);
        }
        if let crate::check::types::Ty::TyTuple(ts_p4) = t_p1 {
            break 'm75403 crate::prelude::run_to_end(crate::prelude::fold_job(ts_p4.clone(), true, {
                let lx_p0x = lx_p0.clone();
                let seen_p2x = seen_p2.clone();
                ::std::rc::Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| {
                    let lx_p0xy = lx_p0x.clone();
                    let seen_p2xy = seen_p2x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let ok_p5 = p0;
                        let x_p6 = p1;
                        ::prism_rtl::Turn::Finished(ok_p5 && ty_has_eq_f(&lx_p0xy, &x_p6, &seen_p2xy))
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::check::types::Ty)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
            }));
        }
        if let crate::check::types::Ty::TyArray(e_p7) = t_p1 {
            break 'm75403 ty_has_eq_f(lx_p0, &**e_p7, seen_p2);
        }
        if let crate::check::types::Ty::TyMap(k_p8, v_p9) = t_p1 {
            break 'm75403 ty_has_eq_f(lx_p0, &**k_p8, seen_p2) && ty_has_eq_f(lx_p0, &**v_p9, seen_p2);
        }
        if let crate::check::types::Ty::TyElem(_, _) = t_p1 {
            break 'm75403 true;
        }
        if let crate::check::types::Ty::TyElemAny(_) = t_p1 {
            break 'm75403 true;
        }
        if let crate::check::types::Ty::TyCon(m75403_10_0, m75403_10_1) = t_p1 && (m75403_10_0 == &crate::prelude::Text::lit("Prelude.NonEmpty")) && (m75403_10_1.len() == 1) && let ::std::option::Option::Some(c_pa) = crate::prelude::index(m75403_10_1, &crate::prelude::Nat::from(0u32)) {
            break 'm75403 ty_has_eq_f(lx_p0, &c_pa, seen_p2);
        }
        if let crate::check::types::Ty::TyCon(n_pb, args_pc) = t_p1 {
            break 'm75403 if crate::check::types::has_text_f(seen_p2, n_pb) {
                true
            } else {
                {
                    let args_ok_pd = crate::prelude::run_to_end(crate::prelude::fold_job(args_pc.clone(), true, {
                        let lx_p0x = lx_p0.clone();
                        let seen_p2x = seen_p2.clone();
                        let n_pbx = n_pb.clone();
                        ::std::rc::Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| {
                            let lx_p0xy = lx_p0x.clone();
                            let seen_p2xy = seen_p2x.clone();
                            let n_pbxy = n_pbx.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let ok_pe = p0;
                                let x_pf = p1;
                                ::prism_rtl::Turn::Finished(ok_pe && ty_has_eq_f(&lx_p0xy, &x_pf, &crate::prelude::push(&seen_p2xy, &n_pbxy)))
                            }))
                        }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::check::types::Ty)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
                    }));
                    args_ok_pd && match crate::prelude::get(&lx_p0.g_p.types_p, n_pb) {
                        ::std::option::Option::Some(ti_pg) => crate::prelude::fold(&ti_pg.derives_p, &false, &(|f_ph: &bool, d_pi: &crate::prelude::Text| *f_ph || (&crate::check::env::names::resolve_trait_o(&lx_p0.g_p, &ti_pg.home_p, &crate::prelude::split_on(d_pi, &crate::prelude::Text::lit("."))) == &::std::option::Option::Some(crate::prelude::Text::lit("Prelude.Eq"))))) || has_own_eq_f(lx_p0, n_pb),
                        ::std::option::Option::None => true,
                    }
                }
            };
        }
        false
    }
}

/// ```prism
/// HasOwnEq: fn Lx, Text -> Bool
/// ```
pub fn has_own_eq_f(lx_p0: &crate::lower::Lx, tn_p1: &crate::prelude::Text) -> bool {
    crate::prelude::fold(&crate::prelude::or(&crate::prelude::get(&lx_p0.g_p.impls_p, &crate::prelude::Text::lit("Prelude.Eq")), &crate::prelude::Array::new()), &false, &(|f_p2: &bool, im_p3: &crate::check::env::ImplInfo| *f_p2 || (&crate::lower::functions::head_name_f(&im_p3.head_p) == tn_p1)))
}

/// ```prism
/// CaseField: unbounded fn Lx, Text, Nat, Ty -> OutTy
/// ```
pub fn case_field_f(lx_p0: &crate::lower::Lx, ck_p1: &crate::prelude::Text, i_p2: &crate::prelude::Nat, t_p3: &crate::check::types::Ty) -> crate::lower::model::OutTy {
    let rt_p4 = crate::lower::types::out_ty_of_f(lx_p0, t_p3);
    if crate::lower::types::rc_field_f(lx_p0, ck_p1, i_p2) {
        crate::lower::model::OutTy::OutRc(::std::rc::Rc::new(rt_p4.clone()))
    } else {
        rt_p4.clone()
    }
}

/// The step machine of `CaseField`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CaseField: unbounded fn Lx, Text, Nat, Ty -> OutTy
/// ```
pub struct CaseField {
    pub lx_p0: crate::lower::Lx,
    pub ck_p1: crate::prelude::Text,
    pub i_p2: crate::prelude::Nat,
    pub t_p3: crate::check::types::Ty,
}

impl ::prism_rtl::Job<crate::lower::model::OutTy> for CaseField {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::lower::model::OutTy> {
        let lx_p0 = &self.lx_p0;
        let ck_p1 = &self.ck_p1;
        let i_p2 = &self.i_p2;
        let t_p3 = &self.t_p3;
        let ck_p1x = ck_p1.clone();
        let i_p2x = i_p2.clone();
        let lx_p0x = lx_p0.clone();
        let t_p3x = t_p3.clone();
        crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0x.clone(), t_p3x.clone()), move |out_ty_of_f_76483: crate::lower::model::OutTy| {
            let rt_p4 = out_ty_of_f_76483;
            if crate::lower::types::rc_field_f(&lx_p0x, &ck_p1x, &i_p2x) {
                ::prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutRc(::std::rc::Rc::new(rt_p4.clone())))
            } else {
                ::prism_rtl::Turn::Finished(rt_p4.clone())
            }
        })
    }
}

/// `Start CaseField, x`: what the function value is when passed to `@Run`.
pub fn start_case_field_f(lx_p0: crate::lower::Lx, ck_p1: crate::prelude::Text, i_p2: crate::prelude::Nat, t_p3: crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::OutTy>> {
    ::std::rc::Rc::new(CaseField { lx_p0, ck_p1, i_p2, t_p3 })
}

/// ```prism
/// TypeDoc: fn Lx, TyInfo -> Text
/// ```
pub fn type_doc_f(lx_p0: &crate::lower::Lx, ti_p1: &crate::check::env::TyInfo) -> crate::prelude::Text {
    match crate::prelude::index(&lx_p0.g_p.srcs_p, &ti_p1.file_p) {
        ::std::option::Option::Some(src_p2) => crate::syntax::lexer::chars::trim_f(&crate::check::errors::line_text_f(&src_p2, &crate::check::errors::cline_of_f(&src_p2.starts_p, &ti_p1.span_p.start_p))),
        ::std::option::Option::None => ti_p1.name_p.clone(),
    }
}

/// ```prism
/// TagDefOf: unbounded fn Lx, TagInfo -> TagDef
/// ```
pub fn tag_def_of_f(lx_p0: &crate::lower::Lx, tg_p1: &crate::check::env::TagInfo) -> crate::lower::model::TagDef {
    let fields_p2 = crate::prelude::run_to_end(crate::prelude::each_job(level_fields_f(tg_p1), {
        let tg_p1x = tg_p1.clone();
        let lx_p0x = lx_p0.clone();
        ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::check::types::Ty)| {
            let tg_p1xy = tg_p1x.clone();
            let lx_p0xy = lx_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (fname_p4, ft_p5) = p0;
                crate::prelude::call_then(crate::lower::start_field_spell_f(tg_p1xy.home_p.clone(), fname_p4.clone(), ft_p5.clone()), move |field_spell_f_77028: crate::prelude::Text| crate::prelude::call_then(crate::lower::types::start_tag_field_out_f(lx_p0xy.clone(), ft_p5.clone()), move |tag_field_out_f_77061: crate::lower::model::OutTy| ::prism_rtl::Turn::Finished((fname_p4.clone(), field_spell_f_77028, tag_field_out_f_77061))))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::check::types::Ty)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy)>>>
    }));
    let events_p3 = crate::prelude::run_to_end(crate::prelude::each_job(level_events_f(tg_p1), {
        let tg_p1x = tg_p1.clone();
        let lx_p0x = lx_p0.clone();
        ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::check::types::Ty)| {
            let tg_p1xy = tg_p1x.clone();
            let lx_p0xy = lx_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (fname_p6, ft_p7) = p0;
                crate::prelude::call_then(crate::lower::start_field_spell_f(tg_p1xy.home_p.clone(), fname_p6.clone(), ft_p7.clone()), move |field_spell_f_77143: crate::prelude::Text| crate::prelude::call_then(crate::lower::types::start_tag_field_out_f(lx_p0xy.clone(), ft_p7.clone()), move |tag_field_out_f_77176: crate::lower::model::OutTy| ::prism_rtl::Turn::Finished((field_spell_f_77143, tag_field_out_f_77176))))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::check::types::Ty)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Text, crate::lower::model::OutTy)>>>
    }));
    crate::lower::model::TagDef { name_p: crate::lower::tag_struct_of_f(tg_p1), tag_name_p: tg_p1.name_p.clone(), fields_p: fields_p2.clone(), events_p: events_p3.clone(), doc_p: type_doc_f(lx_p0, &crate::check::env::TyInfo { name_p: tg_p1.name_p.clone(), home_p: tg_p1.home_p.clone(), params_p: crate::prelude::Array::new(), body_p: crate::check::env::TyBody::BOpaque, derives_p: crate::prelude::Array::new(), file_p: tg_p1.file_p.clone(), span_p: tg_p1.span_p.clone() }), pod_p: crate::prelude::run_to_end(crate::prelude::fold_job(fields_p2.clone(), true, ::std::rc::Rc::new(move |(p0, p1): (bool, (crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy))| crate::prelude::entered(crate::prelude::once_job(move || {
        let ok_p8 = p0;
        let (_, _, t_p9) = p1;
        if ok_p8 {
            ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::lower::types::Podable { t_p0: t_p9.clone() }))
        } else {
            ::prism_rtl::Turn::Finished(false)
        }
    }))) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, (crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy))) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>)), eq_p: crate::prelude::run_to_end(crate::prelude::fold_job(fields_p2.clone(), true, ::std::rc::Rc::new(move |(p0, p1): (bool, (crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy))| crate::prelude::entered(crate::prelude::once_job(move || {
        let ok_pa = p0;
        let (_, _, t_pb) = p1;
        if ok_pa {
            ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::lower::types::RuntimeEq { t_p0: t_pb.clone() }))
        } else {
            ::prism_rtl::Turn::Finished(false)
        }
    }))) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, (crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy))) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>)) }
}

/// The step machine of `TagDefOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TagDefOf: unbounded fn Lx, TagInfo -> TagDef
/// ```
pub struct TagDefOf {
    pub lx_p0: crate::lower::Lx,
    pub tg_p1: crate::check::env::TagInfo,
}

impl ::prism_rtl::Job<crate::lower::model::TagDef> for TagDefOf {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::lower::model::TagDef> {
        let lx_p0 = &self.lx_p0;
        let tg_p1 = &self.tg_p1;
        let lx_p0x = lx_p0.clone();
        let tg_p1x = tg_p1.clone();
        crate::prelude::call_value(crate::prelude::each_job(level_fields_f(&tg_p1x), {
            let tg_p1xx = tg_p1x.clone();
            let lx_p0xx = lx_p0x.clone();
            ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::check::types::Ty)| {
                let tg_p1xxy = tg_p1xx.clone();
                let lx_p0xxy = lx_p0xx.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let (fname_p4, ft_p5) = p0;
                    crate::prelude::call_then(crate::lower::start_field_spell_f(tg_p1xxy.home_p.clone(), fname_p4.clone(), ft_p5.clone()), move |field_spell_f_77028: crate::prelude::Text| crate::prelude::call_then(crate::lower::types::start_tag_field_out_f(lx_p0xxy.clone(), ft_p5.clone()), move |tag_field_out_f_77061: crate::lower::model::OutTy| ::prism_rtl::Turn::Finished((fname_p4.clone(), field_spell_f_77028, tag_field_out_f_77061))))
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::check::types::Ty)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy)>>>
        }), move |each_76978: crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy)>| {
            let fields_p2 = each_76978;
            crate::prelude::call_value(crate::prelude::each_job(level_events_f(&tg_p1x), {
                let tg_p1xx = tg_p1x.clone();
                let lx_p0xx = lx_p0x.clone();
                ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::check::types::Ty)| {
                    let tg_p1xxy = tg_p1xx.clone();
                    let lx_p0xxy = lx_p0xx.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let (fname_p6, ft_p7) = p0;
                        crate::prelude::call_then(crate::lower::start_field_spell_f(tg_p1xxy.home_p.clone(), fname_p6.clone(), ft_p7.clone()), move |field_spell_f_77143: crate::prelude::Text| crate::prelude::call_then(crate::lower::types::start_tag_field_out_f(lx_p0xxy.clone(), ft_p7.clone()), move |tag_field_out_f_77176: crate::lower::model::OutTy| ::prism_rtl::Turn::Finished((field_spell_f_77143, tag_field_out_f_77176))))
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::check::types::Ty)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Text, crate::lower::model::OutTy)>>>
            }), move |each_77100: crate::prelude::Array<(crate::prelude::Text, crate::lower::model::OutTy)>| {
                let events_p3 = each_77100;
                crate::prelude::call_value(crate::prelude::fold_job(fields_p2.clone(), true, ::std::rc::Rc::new(move |(p0, p1): (bool, (crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy))| crate::prelude::entered(crate::prelude::once_job(move || {
                    let ok_p8 = p0;
                    let (_, _, t_p9) = p1;
                    if ok_p8 {
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::lower::types::Podable { t_p0: t_p9.clone() }))
                    } else {
                        ::prism_rtl::Turn::Finished(false)
                    }
                }))) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, (crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy))) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>), move |fold_77409: bool| crate::prelude::call_value(crate::prelude::fold_job(fields_p2.clone(), true, ::std::rc::Rc::new(move |(p0, p1): (bool, (crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy))| crate::prelude::entered(crate::prelude::once_job(move || {
                    let ok_pa = p0;
                    let (_, _, t_pb) = p1;
                    if ok_pa {
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::lower::types::RuntimeEq { t_p0: t_pb.clone() }))
                    } else {
                        ::prism_rtl::Turn::Finished(false)
                    }
                }))) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, (crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy))) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>), move |fold_77480: bool| ::prism_rtl::Turn::Finished(crate::lower::model::TagDef { name_p: crate::lower::tag_struct_of_f(&tg_p1x), tag_name_p: tg_p1x.name_p.clone(), fields_p: fields_p2.clone(), events_p: events_p3.clone(), doc_p: type_doc_f(&lx_p0x, &crate::check::env::TyInfo { name_p: tg_p1x.name_p.clone(), home_p: tg_p1x.home_p.clone(), params_p: crate::prelude::Array::new(), body_p: crate::check::env::TyBody::BOpaque, derives_p: crate::prelude::Array::new(), file_p: tg_p1x.file_p.clone(), span_p: tg_p1x.span_p.clone() }), pod_p: fold_77409, eq_p: fold_77480 })))
            })
        })
    }
}

/// `Start TagDefOf, x`: what the function value is when passed to `@Run`.
pub fn start_tag_def_of_f(lx_p0: crate::lower::Lx, tg_p1: crate::check::env::TagInfo) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::TagDef>> {
    ::std::rc::Rc::new(TagDefOf { lx_p0, tg_p1 })
}

/// ```prism
/// TagItems: unbounded fn Lx, TagInfo -> [Item]
/// ```
pub fn tag_items_f(lx_p0: &crate::lower::Lx, tg_p1: &crate::check::env::TagInfo) -> crate::prelude::Array<crate::lower::model::Item> {
    if &tg_p1.kind_p == &crate::prelude::Text::lit("Element") {
        crate::prelude::Array::from(vec![crate::lower::model::Item::ItTag(tag_def_of_f(lx_p0, tg_p1)), crate::lower::model::Item::ItType(desc_def_of_f(lx_p0, tg_p1))])
    } else {
        crate::prelude::Array::from(vec![crate::lower::model::Item::ItTag(tag_def_of_f(lx_p0, tg_p1))])
    }
}

/// The step machine of `TagItems`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TagItems: unbounded fn Lx, TagInfo -> [Item]
/// ```
pub struct TagItems {
    pub lx_p0: crate::lower::Lx,
    pub tg_p1: crate::check::env::TagInfo,
}

impl ::prism_rtl::Job<crate::prelude::Array<crate::lower::model::Item>> for TagItems {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<crate::lower::model::Item>> {
        let lx_p0 = &self.lx_p0;
        let tg_p1 = &self.tg_p1;
        if &tg_p1.kind_p == &crate::prelude::Text::lit("Element") {
            {
                let lx_p0x = lx_p0.clone();
                let tg_p1x = tg_p1.clone();
                crate::prelude::call_then(start_tag_def_of_f(lx_p0x.clone(), tg_p1x.clone()), move |tag_def_of_f_77724: crate::lower::model::TagDef| crate::prelude::call_then(start_desc_def_of_f(lx_p0x.clone(), tg_p1x.clone()), move |desc_def_of_f_77752: crate::lower::model::TyDef| ::prism_rtl::Turn::Finished(crate::prelude::Array::from(vec![crate::lower::model::Item::ItTag(tag_def_of_f_77724), crate::lower::model::Item::ItType(desc_def_of_f_77752)]))))
            }
        } else {
            {
                let lx_p0x = lx_p0.clone();
                let tg_p1x = tg_p1.clone();
                crate::prelude::call_then(start_tag_def_of_f(lx_p0x.clone(), tg_p1x.clone()), move |tag_def_of_f_77788: crate::lower::model::TagDef| ::prism_rtl::Turn::Finished(crate::prelude::Array::from(vec![crate::lower::model::Item::ItTag(tag_def_of_f_77788)])))
            }
        }
    }
}

/// `Start TagItems, x`: what the function value is when passed to `@Run`.
pub fn start_tag_items_f(lx_p0: crate::lower::Lx, tg_p1: crate::check::env::TagInfo) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::lower::model::Item>>> {
    ::std::rc::Rc::new(TagItems { lx_p0, tg_p1 })
}

/// ```prism
/// DescDefOf: unbounded fn Lx, TagInfo -> TyDef
/// ```
pub fn desc_def_of_f(lx_p0: &crate::lower::Lx, tg_p1: &crate::check::env::TagInfo) -> crate::lower::model::TyDef {
    let name_p2 = crate::lower::desc_struct_of_f(tg_p1);
    let fields_p3 = crate::prelude::run_to_end(crate::prelude::each_job(tg_p1.fields_p.clone(), {
        let tg_p1x = tg_p1.clone();
        let lx_p0x = lx_p0.clone();
        ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::check::types::Ty)| {
            let tg_p1xy = tg_p1x.clone();
            let lx_p0xy = lx_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (fname_p4, ft_p5) = p0;
                crate::prelude::call_then(crate::lower::start_field_spell_f(tg_p1xy.home_p.clone(), fname_p4.clone(), ft_p5.clone()), move |field_spell_f_78307: crate::prelude::Text| crate::prelude::call_then(start_desc_field_ty_f(lx_p0xy.clone(), ft_p5.clone()), move |desc_field_ty_f_78340: crate::lower::model::OutTy| ::prism_rtl::Turn::Finished((field_spell_f_78307, desc_field_ty_f_78340))))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::check::types::Ty)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Text, crate::lower::model::OutTy)>>>
    }));
    crate::lower::model::TyDef { name_p: name_p2.clone(), prism_p: name_p2.clone(), params_p: crate::prelude::Array::new(), keyed_p: crate::prelude::Array::new(), shape_p: crate::lower::model::TyShape::ShapeRecord, cases_p: crate::prelude::Array::from(vec![crate::lower::model::CaseDef { name_p: name_p2.clone(), prism_p: name_p2.clone(), fields_p: fields_p3.clone(), labels_p: crate::prelude::each(&tg_p1.fields_p, &(|(fname_p6, _): &(crate::prelude::Text, crate::check::types::Ty)| fname_p6.clone())) }]), eq_p: false, ord_p: false, show_p: crate::lower::model::Shown::NotShown, pod_p: false, doc_p: crate::prelude::Text::from(format!("The description of `{}`: an element applied as a plain value, its fields as given.", &tg_p1.name_p)) }
}

/// The step machine of `DescDefOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// DescDefOf: unbounded fn Lx, TagInfo -> TyDef
/// ```
pub struct DescDefOf {
    pub lx_p0: crate::lower::Lx,
    pub tg_p1: crate::check::env::TagInfo,
}

impl ::prism_rtl::Job<crate::lower::model::TyDef> for DescDefOf {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::lower::model::TyDef> {
        let lx_p0 = &self.lx_p0;
        let tg_p1 = &self.tg_p1;
        let name_p2 = crate::lower::desc_struct_of_f(tg_p1);
        let lx_p0x = lx_p0.clone();
        let tg_p1x = tg_p1.clone();
        crate::prelude::call_value(crate::prelude::each_job(tg_p1x.fields_p.clone(), {
            let tg_p1xx = tg_p1x.clone();
            let lx_p0xx = lx_p0x.clone();
            ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::check::types::Ty)| {
                let tg_p1xxy = tg_p1xx.clone();
                let lx_p0xxy = lx_p0xx.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let (fname_p4, ft_p5) = p0;
                    crate::prelude::call_then(crate::lower::start_field_spell_f(tg_p1xxy.home_p.clone(), fname_p4.clone(), ft_p5.clone()), move |field_spell_f_78307: crate::prelude::Text| crate::prelude::call_then(start_desc_field_ty_f(lx_p0xxy.clone(), ft_p5.clone()), move |desc_field_ty_f_78340: crate::lower::model::OutTy| ::prism_rtl::Turn::Finished((field_spell_f_78307, desc_field_ty_f_78340))))
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::check::types::Ty)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Text, crate::lower::model::OutTy)>>>
        }), move |each_78271: crate::prelude::Array<(crate::prelude::Text, crate::lower::model::OutTy)>| {
            let fields_p3 = each_78271;
            ::prism_rtl::Turn::Finished(crate::lower::model::TyDef { name_p: name_p2.clone(), prism_p: name_p2.clone(), params_p: crate::prelude::Array::new(), keyed_p: crate::prelude::Array::new(), shape_p: crate::lower::model::TyShape::ShapeRecord, cases_p: crate::prelude::Array::from(vec![crate::lower::model::CaseDef { name_p: name_p2.clone(), prism_p: name_p2.clone(), fields_p: fields_p3.clone(), labels_p: crate::prelude::each(&tg_p1x.fields_p, &(|(fname_p6, _): &(crate::prelude::Text, crate::check::types::Ty)| fname_p6.clone())) }]), eq_p: false, ord_p: false, show_p: crate::lower::model::Shown::NotShown, pod_p: false, doc_p: crate::prelude::Text::from(format!("The description of `{}`: an element applied as a plain value, its fields as given.", &tg_p1x.name_p)) })
        })
    }
}

/// `Start DescDefOf, x`: what the function value is when passed to `@Run`.
pub fn start_desc_def_of_f(lx_p0: crate::lower::Lx, tg_p1: crate::check::env::TagInfo) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::TyDef>> {
    ::std::rc::Rc::new(DescDefOf { lx_p0, tg_p1 })
}

/// ```prism
/// DescFieldTy: unbounded fn Lx, Ty -> OutTy
/// ```
pub fn desc_field_ty_f(lx_p0: &crate::lower::Lx, ft_p1: &crate::check::types::Ty) -> crate::lower::model::OutTy {
    match crate::lower::types::layer_of_f(ft_p1) {
        crate::lower::types::Layer::LyDyn => crate::lower::model::OutTy::OutDyn(::std::rc::Rc::new(crate::lower::types::tag_field_out_f(lx_p0, ft_p1))),
        crate::lower::types::Layer::LyEv => crate::lower::model::OutTy::OutEvent(::std::rc::Rc::new(crate::lower::types::tag_field_out_f(lx_p0, ft_p1))),
        _ => crate::lower::types::tag_field_out_f(lx_p0, ft_p1),
    }
}

/// The step machine of `DescFieldTy`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// DescFieldTy: unbounded fn Lx, Ty -> OutTy
/// ```
pub struct DescFieldTy {
    pub lx_p0: crate::lower::Lx,
    pub ft_p1: crate::check::types::Ty,
}

impl ::prism_rtl::Job<crate::lower::model::OutTy> for DescFieldTy {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::lower::model::OutTy> {
        let lx_p0 = &self.lx_p0;
        let ft_p1 = &self.ft_p1;
        match crate::lower::types::layer_of_f(ft_p1) {
            crate::lower::types::Layer::LyDyn => {
                let ft_p1x = ft_p1.clone();
                let lx_p0x = lx_p0.clone();
                crate::prelude::call_then(crate::lower::types::start_tag_field_out_f(lx_p0x.clone(), ft_p1x.clone()), move |tag_field_out_f_78797: crate::lower::model::OutTy| ::prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutDyn(::std::rc::Rc::new(tag_field_out_f_78797))))
            },
            crate::lower::types::Layer::LyEv => {
                let ft_p1x = ft_p1.clone();
                let lx_p0x = lx_p0.clone();
                crate::prelude::call_then(crate::lower::types::start_tag_field_out_f(lx_p0x.clone(), ft_p1x.clone()), move |tag_field_out_f_78837: crate::lower::model::OutTy| ::prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutEvent(::std::rc::Rc::new(tag_field_out_f_78837))))
            },
            _ => ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::lower::types::TagFieldOut { lx_p0: lx_p0.clone(), ft_p1: ft_p1.clone() })),
        }
    }
}

/// `Start DescFieldTy, x`: what the function value is when passed to `@Run`.
pub fn start_desc_field_ty_f(lx_p0: crate::lower::Lx, ft_p1: crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::OutTy>> {
    ::std::rc::Rc::new(DescFieldTy { lx_p0, ft_p1 })
}

/// ```prism
/// LevelEvents: fn TagInfo -> [((Text, Ty))]
/// ```
pub fn level_events_f(tg_p0: &crate::check::env::TagInfo) -> crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)> {
    if (&tg_p0.kind_p != &crate::prelude::Text::lit("Element")) || (&tg_p0.home_p == &crate::prelude::Text::lit("Prelude")) {
        crate::prelude::Array::new()
    } else {
        crate::prelude::filter(&tg_p0.fields_p, &(|(_, ft_p1): &(crate::prelude::Text, crate::check::types::Ty)| &crate::lower::types::layer_of_f(ft_p1) == &crate::lower::types::Layer::LyEv))
    }
}

/// ```prism
/// LevelFields: fn TagInfo -> [((Text, Ty))]
/// ```
pub fn level_fields_f(tg_p0: &crate::check::env::TagInfo) -> crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)> {
    crate::prelude::filter(&tg_p0.fields_p, &(|(_, ft_p1): &(crate::prelude::Text, crate::check::types::Ty)| &crate::lower::types::layer_of_f(ft_p1) != &crate::lower::types::Layer::LyEv))
}

/// ```prism
/// KindTags: fn Lx, Text, [Text] -> [TagInfo]
/// ```
pub fn kind_tags_f(lx_p0: &crate::lower::Lx, kind_p1: &crate::prelude::Text, mods_p2: &crate::prelude::Array<crate::prelude::Text>) -> crate::prelude::Array<crate::check::env::TagInfo> {
    crate::prelude::filter(&crate::prelude::values(&lx_p0.g_p.tags_p), &(|tg_p3: &crate::check::env::TagInfo| (&tg_p3.kind_p == kind_p1) && crate::check::types::has_text_f(mods_p2, &tg_p3.home_p)))
}

/// ```prism
/// RowDefOf: unbounded fn Lx, TyInfo -> RowDef
/// ```
pub fn row_def_of_f(lx_p0: &crate::lower::Lx, ti_p1: &crate::check::env::TyInfo) -> crate::lower::model::RowDef {
    let tags_p2 = kind_tags_f(lx_p0, &ti_p1.name_p, &crate::prelude::keys(&lx_p0.rs_mods_p));
    let cases_p3 = crate::prelude::each(&tags_p2, &(|tg_p6: &crate::check::env::TagInfo| (crate::lower::tag_struct_f(&tg_p6.name_p), crate::lower::ref_in_f(lx_p0, &tg_p6.home_p, &crate::lower::tag_struct_of_f(tg_p6)))));
    let pod_p4 = crate::prelude::run_to_end(crate::prelude::fold_job(tags_p2.clone(), true, {
        let lx_p0x = lx_p0.clone();
        ::std::rc::Rc::new(move |(p0, p1): (bool, crate::check::env::TagInfo)| {
            let lx_p0xy = lx_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let ok_p7 = p0;
                let tg_p8 = p1;
                if ok_p7 {
                    crate::prelude::call_then(start_tag_def_of_f(lx_p0xy.clone(), tg_p8.clone()), move |tag_def_of_f_80167: crate::lower::model::TagDef| ::prism_rtl::Turn::Finished(tag_def_of_f_80167.pod_p))
                } else {
                    ::prism_rtl::Turn::Finished(false)
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::check::env::TagInfo)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
    }));
    let eq_p5 = crate::prelude::run_to_end(crate::prelude::fold_job(tags_p2.clone(), true, {
        let lx_p0x = lx_p0.clone();
        ::std::rc::Rc::new(move |(p0, p1): (bool, crate::check::env::TagInfo)| {
            let lx_p0xy = lx_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let ok_p9 = p0;
                let tg_pa = p1;
                if ok_p9 {
                    crate::prelude::call_then(start_tag_def_of_f(lx_p0xy.clone(), tg_pa.clone()), move |tag_def_of_f_80236: crate::lower::model::TagDef| ::prism_rtl::Turn::Finished(tag_def_of_f_80236.eq_p))
                } else {
                    ::prism_rtl::Turn::Finished(false)
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::check::env::TagInfo)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
    }));
    crate::lower::model::RowDef { name_p: crate::lower::camel_f(&crate::check::types::bare_name_f(&ti_p1.name_p)), prism_p: ti_p1.name_p.clone(), cases_p: cases_p3.clone(), pod_p: pod_p4, doc_p: type_doc_f(lx_p0, ti_p1), eq_p: eq_p5, level_p: false, deep_p: crate::prelude::Array::new() }
}

/// The step machine of `RowDefOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RowDefOf: unbounded fn Lx, TyInfo -> RowDef
/// ```
pub struct RowDefOf {
    pub lx_p0: crate::lower::Lx,
    pub ti_p1: crate::check::env::TyInfo,
}

impl ::prism_rtl::Job<crate::lower::model::RowDef> for RowDefOf {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::lower::model::RowDef> {
        let lx_p0 = &self.lx_p0;
        let ti_p1 = &self.ti_p1;
        let tags_p2 = kind_tags_f(lx_p0, &ti_p1.name_p, &crate::prelude::keys(&lx_p0.rs_mods_p));
        let cases_p3 = crate::prelude::each(&tags_p2, &(|tg_p6: &crate::check::env::TagInfo| (crate::lower::tag_struct_f(&tg_p6.name_p), crate::lower::ref_in_f(lx_p0, &tg_p6.home_p, &crate::lower::tag_struct_of_f(tg_p6)))));
        let lx_p0x = lx_p0.clone();
        let ti_p1x = ti_p1.clone();
        crate::prelude::call_value(crate::prelude::fold_job(tags_p2.clone(), true, {
            let lx_p0xx = lx_p0x.clone();
            ::std::rc::Rc::new(move |(p0, p1): (bool, crate::check::env::TagInfo)| {
                let lx_p0xxy = lx_p0xx.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let ok_p7 = p0;
                    let tg_p8 = p1;
                    if ok_p7 {
                        crate::prelude::call_then(start_tag_def_of_f(lx_p0xxy.clone(), tg_p8.clone()), move |tag_def_of_f_80167: crate::lower::model::TagDef| ::prism_rtl::Turn::Finished(tag_def_of_f_80167.pod_p))
                    } else {
                        ::prism_rtl::Turn::Finished(false)
                    }
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::check::env::TagInfo)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
        }), move |fold_80132: bool| {
            let pod_p4 = fold_80132;
            crate::prelude::call_value(crate::prelude::fold_job(tags_p2.clone(), true, {
                let lx_p0xx = lx_p0x.clone();
                ::std::rc::Rc::new(move |(p0, p1): (bool, crate::check::env::TagInfo)| {
                    let lx_p0xxy = lx_p0xx.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let ok_p9 = p0;
                        let tg_pa = p1;
                        if ok_p9 {
                            crate::prelude::call_then(start_tag_def_of_f(lx_p0xxy.clone(), tg_pa.clone()), move |tag_def_of_f_80236: crate::lower::model::TagDef| ::prism_rtl::Turn::Finished(tag_def_of_f_80236.eq_p))
                        } else {
                            ::prism_rtl::Turn::Finished(false)
                        }
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::check::env::TagInfo)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
            }), move |fold_80201: bool| {
                let eq_p5 = fold_80201;
                ::prism_rtl::Turn::Finished(crate::lower::model::RowDef { name_p: crate::lower::camel_f(&crate::check::types::bare_name_f(&ti_p1x.name_p)), prism_p: ti_p1x.name_p.clone(), cases_p: cases_p3.clone(), pod_p: pod_p4, doc_p: type_doc_f(&lx_p0x, &ti_p1x), eq_p: eq_p5, level_p: false, deep_p: crate::prelude::Array::new() })
            })
        })
    }
}

/// `Start RowDefOf, x`: what the function value is when passed to `@Run`.
pub fn start_row_def_of_f(lx_p0: crate::lower::Lx, ti_p1: crate::check::env::TyInfo) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::RowDef>> {
    ::std::rc::Rc::new(RowDefOf { lx_p0, ti_p1 })
}

/// ```prism
/// ElemRow: unbounded fn Lx, [Text] -> RowDef
/// ```
pub fn elem_row_f(lx_p0: &crate::lower::Lx, mods_p1: &crate::prelude::Array<crate::prelude::Text>) -> crate::lower::model::RowDef {
    let tags_p2 = kind_tags_f(lx_p0, &crate::prelude::Text::lit("Element"), &crate::prelude::push(mods_p1, &crate::prelude::Text::lit("Prelude")));
    let cases_p3 = crate::prelude::each(&tags_p2, &(|tg_p7: &crate::check::env::TagInfo| (crate::lower::tag_struct_f(&tg_p7.name_p), root_ref_f(&tg_p7.home_p, &crate::lower::tag_struct_of_f(tg_p7)))));
    let pod_p4 = crate::prelude::run_to_end(crate::prelude::fold_job(tags_p2.clone(), true, {
        let lx_p0x = lx_p0.clone();
        ::std::rc::Rc::new(move |(p0, p1): (bool, crate::check::env::TagInfo)| {
            let lx_p0xy = lx_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let ok_p8 = p0;
                let tg_p9 = p1;
                if ok_p8 {
                    crate::prelude::call_then(start_tag_def_of_f(lx_p0xy.clone(), tg_p9.clone()), move |tag_def_of_f_80859: crate::lower::model::TagDef| ::prism_rtl::Turn::Finished(tag_def_of_f_80859.pod_p))
                } else {
                    ::prism_rtl::Turn::Finished(false)
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::check::env::TagInfo)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
    }));
    let eq_p5 = crate::prelude::run_to_end(crate::prelude::fold_job(tags_p2.clone(), true, {
        let lx_p0x = lx_p0.clone();
        ::std::rc::Rc::new(move |(p0, p1): (bool, crate::check::env::TagInfo)| {
            let lx_p0xy = lx_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let ok_pa = p0;
                let tg_pb = p1;
                if ok_pa {
                    crate::prelude::call_then(start_tag_def_of_f(lx_p0xy.clone(), tg_pb.clone()), move |tag_def_of_f_80928: crate::lower::model::TagDef| ::prism_rtl::Turn::Finished(tag_def_of_f_80928.eq_p))
                } else {
                    ::prism_rtl::Turn::Finished(false)
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::check::env::TagInfo)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
    }));
    let deep_p6 = crate::prelude::run_to_end(crate::prelude::fold_job(tags_p2.clone(), crate::prelude::Array::new(), {
        let lx_p0x = lx_p0.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::check::env::TagInfo)| {
            let lx_p0xy = lx_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_pc = p0;
                let tg_pd = p1;
                crate::prelude::call_then(start_tag_holds_dyn_f(lx_p0xy.clone(), tg_pd.clone()), move |tag_holds_dyn_f_80994: bool| if tag_holds_dyn_f_80994 {
                    ::prism_rtl::Turn::Finished(crate::prelude::push(&acc_pc, &crate::lower::tag_struct_f(&tg_pd.name_p)))
                } else {
                    ::prism_rtl::Turn::Finished(acc_pc.clone())
                })
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::check::env::TagInfo)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>
    }));
    crate::lower::model::RowDef { name_p: crate::prelude::Text::lit("Elem"), prism_p: crate::prelude::Text::lit("Elem"), cases_p: cases_p3.clone(), pod_p: pod_p4, doc_p: crate::prelude::Text::lit("`Elem r`: an element as a document holds it, its `Level` in a tick."), eq_p: eq_p5, level_p: true, deep_p: deep_p6.clone() }
}

/// The step machine of `ElemRow`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ElemRow: unbounded fn Lx, [Text] -> RowDef
/// ```
pub struct ElemRow {
    pub lx_p0: crate::lower::Lx,
    pub mods_p1: crate::prelude::Array<crate::prelude::Text>,
}

impl ::prism_rtl::Job<crate::lower::model::RowDef> for ElemRow {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::lower::model::RowDef> {
        let lx_p0 = &self.lx_p0;
        let mods_p1 = &self.mods_p1;
        let tags_p2 = kind_tags_f(lx_p0, &crate::prelude::Text::lit("Element"), &crate::prelude::push(mods_p1, &crate::prelude::Text::lit("Prelude")));
        let cases_p3 = crate::prelude::each(&tags_p2, &(|tg_p7: &crate::check::env::TagInfo| (crate::lower::tag_struct_f(&tg_p7.name_p), root_ref_f(&tg_p7.home_p, &crate::lower::tag_struct_of_f(tg_p7)))));
        let lx_p0x = lx_p0.clone();
        crate::prelude::call_value(crate::prelude::fold_job(tags_p2.clone(), true, {
            let lx_p0xx = lx_p0x.clone();
            ::std::rc::Rc::new(move |(p0, p1): (bool, crate::check::env::TagInfo)| {
                let lx_p0xxy = lx_p0xx.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let ok_p8 = p0;
                    let tg_p9 = p1;
                    if ok_p8 {
                        crate::prelude::call_then(start_tag_def_of_f(lx_p0xxy.clone(), tg_p9.clone()), move |tag_def_of_f_80859: crate::lower::model::TagDef| ::prism_rtl::Turn::Finished(tag_def_of_f_80859.pod_p))
                    } else {
                        ::prism_rtl::Turn::Finished(false)
                    }
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::check::env::TagInfo)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
        }), move |fold_80824: bool| {
            let pod_p4 = fold_80824;
            crate::prelude::call_value(crate::prelude::fold_job(tags_p2.clone(), true, {
                let lx_p0xx = lx_p0x.clone();
                ::std::rc::Rc::new(move |(p0, p1): (bool, crate::check::env::TagInfo)| {
                    let lx_p0xxy = lx_p0xx.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let ok_pa = p0;
                        let tg_pb = p1;
                        if ok_pa {
                            crate::prelude::call_then(start_tag_def_of_f(lx_p0xxy.clone(), tg_pb.clone()), move |tag_def_of_f_80928: crate::lower::model::TagDef| ::prism_rtl::Turn::Finished(tag_def_of_f_80928.eq_p))
                        } else {
                            ::prism_rtl::Turn::Finished(false)
                        }
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::check::env::TagInfo)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
            }), move |fold_80893: bool| {
                let eq_p5 = fold_80893;
                crate::prelude::call_value(crate::prelude::fold_job(tags_p2.clone(), crate::prelude::Array::new(), {
                    let lx_p0xx = lx_p0x.clone();
                    ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::check::env::TagInfo)| {
                        let lx_p0xxy = lx_p0xx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let acc_pc = p0;
                            let tg_pd = p1;
                            crate::prelude::call_then(start_tag_holds_dyn_f(lx_p0xxy.clone(), tg_pd.clone()), move |tag_holds_dyn_f_80994: bool| if tag_holds_dyn_f_80994 {
                                ::prism_rtl::Turn::Finished(crate::prelude::push(&acc_pc, &crate::lower::tag_struct_f(&tg_pd.name_p)))
                            } else {
                                ::prism_rtl::Turn::Finished(acc_pc.clone())
                            })
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::check::env::TagInfo)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>
                }), move |fold_80963: crate::prelude::Array<crate::prelude::Text>| {
                    let deep_p6 = fold_80963;
                    ::prism_rtl::Turn::Finished(crate::lower::model::RowDef { name_p: crate::prelude::Text::lit("Elem"), prism_p: crate::prelude::Text::lit("Elem"), cases_p: cases_p3.clone(), pod_p: pod_p4, doc_p: crate::prelude::Text::lit("`Elem r`: an element as a document holds it, its `Level` in a tick."), eq_p: eq_p5, level_p: true, deep_p: deep_p6.clone() })
                })
            })
        })
    }
}

/// `Start ElemRow, x`: what the function value is when passed to `@Run`.
pub fn start_elem_row_f(lx_p0: crate::lower::Lx, mods_p1: crate::prelude::Array<crate::prelude::Text>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::RowDef>> {
    ::std::rc::Rc::new(ElemRow { lx_p0, mods_p1 })
}

/// ```prism
/// TagHoldsDyn: unbounded fn Lx, TagInfo -> Bool
/// ```
pub fn tag_holds_dyn_f(lx_p0: &crate::lower::Lx, tg_p1: &crate::check::env::TagInfo) -> bool {
    crate::prelude::run_to_end(crate::prelude::fold_job(tag_def_of_f(lx_p0, tg_p1).fields_p.clone(), false, ::std::rc::Rc::new(move |(p0, p1): (bool, (crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy))| crate::prelude::entered(crate::prelude::once_job(move || {
        let f_p2 = p0;
        let (_, _, t_p3) = p1;
        if f_p2 {
            ::prism_rtl::Turn::Finished(true)
        } else {
            ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::lower::types::HoldsDyn { t_p0: t_p3.clone() }))
        }
    }))) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, (crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy))) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>))
}

/// The step machine of `TagHoldsDyn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TagHoldsDyn: unbounded fn Lx, TagInfo -> Bool
/// ```
pub struct TagHoldsDyn {
    pub lx_p0: crate::lower::Lx,
    pub tg_p1: crate::check::env::TagInfo,
}

impl ::prism_rtl::Job<bool> for TagHoldsDyn {
    fn cycle(&self) -> ::prism_rtl::Turn<bool> {
        let lx_p0 = &self.lx_p0;
        let tg_p1 = &self.tg_p1;
        let lx_p0x = lx_p0.clone();
        let tg_p1x = tg_p1.clone();
        crate::prelude::call_then(start_tag_def_of_f(lx_p0x.clone(), tg_p1x.clone()), move |tag_def_of_f_81415: crate::lower::model::TagDef| crate::prelude::fold_job(tag_def_of_f_81415.fields_p.clone(), false, ::std::rc::Rc::new(move |(p0, p1): (bool, (crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy))| crate::prelude::entered(crate::prelude::once_job(move || {
            let f_p2 = p0;
            let (_, _, t_p3) = p1;
            if f_p2 {
                ::prism_rtl::Turn::Finished(true)
            } else {
                ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::lower::types::HoldsDyn { t_p0: t_p3.clone() }))
            }
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, (crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy))) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>).cycle())
    }
}

/// `Start TagHoldsDyn, x`: what the function value is when passed to `@Run`.
pub fn start_tag_holds_dyn_f(lx_p0: crate::lower::Lx, tg_p1: crate::check::env::TagInfo) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>> {
    ::std::rc::Rc::new(TagHoldsDyn { lx_p0, tg_p1 })
}

/// ```prism
/// AnswerEnum: unbounded fn Lx, [Text] -> AnswerDef
/// ```
pub fn answer_enum_f(lx_p0: &crate::lower::Lx, mods_p1: &crate::prelude::Array<crate::prelude::Text>) -> crate::lower::model::AnswerDef {
    let tags_p2 = kind_tags_f(lx_p0, &crate::prelude::Text::lit("Element"), &crate::prelude::push(mods_p1, &crate::prelude::Text::lit("Prelude")));
    crate::lower::model::AnswerDef { cases_p: crate::prelude::run_to_end(crate::prelude::each_job(tags_p2.clone(), {
        let lx_p0x = lx_p0.clone();
        ::std::rc::Rc::new(move |p0: crate::check::env::TagInfo| {
            let lx_p0xy = lx_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let tg_p3 = p0;
                crate::prelude::call_then(start_answer_ty_f(lx_p0xy.clone(), tg_p3.clone()), move |answer_ty_f_81882: crate::lower::model::OutTy| crate::prelude::call_then(start_bundle_first_ty_o(lx_p0xy.clone(), tg_p3.clone()), move |bundle_first_ty_o_81908: ::std::option::Option<crate::lower::model::OutTy>| crate::prelude::call_then(start_held_whole_ty_o(lx_p0xy.clone(), tg_p3.clone()), move |held_whole_ty_o_81944: ::std::option::Option<crate::lower::model::OutTy>| crate::prelude::call_then(start_held_parts_of_o(lx_p0xy.clone(), tg_p3.clone()), move |held_parts_of_o_81978: ::std::option::Option<crate::lower::model::Ex>| ::prism_rtl::Turn::Finished(crate::lower::model::AnswerCase { variant_p: crate::lower::tag_struct_f(&tg_p3.name_p), accessor_p: crate::lower::node_::elements::answer_accessor_f(&tg_p3), struct_path_p: root_ref_f(&tg_p3.home_p, &crate::lower::tag_struct_of_f(&tg_p3)), tag_name_p: tg_p3.name_p.clone(), ty_p: answer_ty_f_81882, first_o: bundle_first_ty_o_81908, held_whole_o: held_whole_ty_o_81944, held_parts_o: held_parts_of_o_81978 })))))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::env::TagInfo) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::AnswerCase>>>
    })) }
}

/// The step machine of `AnswerEnum`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// AnswerEnum: unbounded fn Lx, [Text] -> AnswerDef
/// ```
pub struct AnswerEnum {
    pub lx_p0: crate::lower::Lx,
    pub mods_p1: crate::prelude::Array<crate::prelude::Text>,
}

impl ::prism_rtl::Job<crate::lower::model::AnswerDef> for AnswerEnum {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::lower::model::AnswerDef> {
        let lx_p0 = &self.lx_p0;
        let mods_p1 = &self.mods_p1;
        let tags_p2 = kind_tags_f(lx_p0, &crate::prelude::Text::lit("Element"), &crate::prelude::push(mods_p1, &crate::prelude::Text::lit("Prelude")));
        let lx_p0x = lx_p0.clone();
        crate::prelude::call_value(crate::prelude::each_job(tags_p2.clone(), {
            let lx_p0xx = lx_p0x.clone();
            ::std::rc::Rc::new(move |p0: crate::check::env::TagInfo| {
                let lx_p0xxy = lx_p0xx.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let tg_p3 = p0;
                    crate::prelude::call_then(start_answer_ty_f(lx_p0xxy.clone(), tg_p3.clone()), move |answer_ty_f_81882: crate::lower::model::OutTy| crate::prelude::call_then(start_bundle_first_ty_o(lx_p0xxy.clone(), tg_p3.clone()), move |bundle_first_ty_o_81908: ::std::option::Option<crate::lower::model::OutTy>| crate::prelude::call_then(start_held_whole_ty_o(lx_p0xxy.clone(), tg_p3.clone()), move |held_whole_ty_o_81944: ::std::option::Option<crate::lower::model::OutTy>| crate::prelude::call_then(start_held_parts_of_o(lx_p0xxy.clone(), tg_p3.clone()), move |held_parts_of_o_81978: ::std::option::Option<crate::lower::model::Ex>| ::prism_rtl::Turn::Finished(crate::lower::model::AnswerCase { variant_p: crate::lower::tag_struct_f(&tg_p3.name_p), accessor_p: crate::lower::node_::elements::answer_accessor_f(&tg_p3), struct_path_p: root_ref_f(&tg_p3.home_p, &crate::lower::tag_struct_of_f(&tg_p3)), tag_name_p: tg_p3.name_p.clone(), ty_p: answer_ty_f_81882, first_o: bundle_first_ty_o_81908, held_whole_o: held_whole_ty_o_81944, held_parts_o: held_parts_of_o_81978 })))))
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::env::TagInfo) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::AnswerCase>>>
        }), move |each_81726: crate::prelude::Array<crate::lower::model::AnswerCase>| ::prism_rtl::Turn::Finished(crate::lower::model::AnswerDef { cases_p: each_81726 }))
    }
}

/// `Start AnswerEnum, x`: what the function value is when passed to `@Run`.
pub fn start_answer_enum_f(lx_p0: crate::lower::Lx, mods_p1: crate::prelude::Array<crate::prelude::Text>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::AnswerDef>> {
    ::std::rc::Rc::new(AnswerEnum { lx_p0, mods_p1 })
}

/// ```prism
/// ?HeldWholeTy: unbounded fn Lx, TagInfo -> ?OutTy
/// ```
pub fn held_whole_ty_o(lx_p0: &crate::lower::Lx, tg_p1: &crate::check::env::TagInfo) -> ::std::option::Option<crate::lower::model::OutTy> {
    match crate::lower::types::peel_f(&tg_p1.out_p) {
        crate::check::types::Ty::TyTuple(parts_p2) => if crate::prelude::run_to_end(crate::prelude::fold_job(parts_p2.clone(), false, {
            let lx_p0x = lx_p0.clone();
            ::std::rc::Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| {
                let lx_p0xy = lx_p0x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let found_p3 = p0;
                    let part_p4 = p1;
                    if found_p3 {
                        ::prism_rtl::Turn::Finished(true)
                    } else {
                        crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0xy.clone(), crate::lower::types::peel_f(&part_p4)), move |out_ty_of_f_82422: crate::lower::model::OutTy| crate::prelude::call_then(crate::lower::types::start_podable_f(out_ty_of_f_82422), move |podable_f_82413: bool| ::prism_rtl::Turn::Finished(!podable_f_82413)))
                    }
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::check::types::Ty)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
        })) {
            ::std::option::Option::Some(crate::lower::types::out_ty_of_f(lx_p0, &crate::check::types::Ty::TyTuple(parts_p2.clone())))
        } else {
            ::std::option::Option::None
        },
        _ => ::std::option::Option::None,
    }
}

/// The step machine of `HeldWholeTy`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?HeldWholeTy: unbounded fn Lx, TagInfo -> ?OutTy
/// ```
pub struct HeldWholeTy {
    pub lx_p0: crate::lower::Lx,
    pub tg_p1: crate::check::env::TagInfo,
}

impl ::prism_rtl::Job<::std::option::Option<crate::lower::model::OutTy>> for HeldWholeTy {
    fn cycle(&self) -> ::prism_rtl::Turn<::std::option::Option<crate::lower::model::OutTy>> {
        let lx_p0 = &self.lx_p0;
        let tg_p1 = &self.tg_p1;
        match crate::lower::types::peel_f(&tg_p1.out_p) {
            crate::check::types::Ty::TyTuple(parts_p2) => {
                let lx_p0x = lx_p0.clone();
                crate::prelude::call_value(crate::prelude::fold_job(parts_p2.clone(), false, {
                    let lx_p0xx = lx_p0x.clone();
                    ::std::rc::Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| {
                        let lx_p0xxy = lx_p0xx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let found_p3 = p0;
                            let part_p4 = p1;
                            if found_p3 {
                                ::prism_rtl::Turn::Finished(true)
                            } else {
                                crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0xxy.clone(), crate::lower::types::peel_f(&part_p4)), move |out_ty_of_f_82422: crate::lower::model::OutTy| crate::prelude::call_then(crate::lower::types::start_podable_f(out_ty_of_f_82422), move |podable_f_82413: bool| ::prism_rtl::Turn::Finished(!podable_f_82413)))
                            }
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::check::types::Ty)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
                }), move |fold_82365: bool| if fold_82365 {
                    ::prism_rtl::Turn::Finished(::std::option::Option::Some(crate::lower::types::out_ty_of_f(&lx_p0x, &crate::check::types::Ty::TyTuple(parts_p2.clone()))))
                } else {
                    ::prism_rtl::Turn::Finished(::std::option::Option::None)
                })
            },
            _ => ::prism_rtl::Turn::Finished(::std::option::Option::None),
        }
    }
}

/// `Start HeldWholeTy, x`: what the function value is when passed to `@Run`.
pub fn start_held_whole_ty_o(lx_p0: crate::lower::Lx, tg_p1: crate::check::env::TagInfo) -> ::std::rc::Rc<dyn ::prism_rtl::Job<::std::option::Option<crate::lower::model::OutTy>>> {
    ::std::rc::Rc::new(HeldWholeTy { lx_p0, tg_p1 })
}

/// ```prism
/// ?HeldPartsOf: unbounded fn Lx, TagInfo -> ?Ex
/// ```
pub fn held_parts_of_o(lx_p0: &crate::lower::Lx, tg_p1: &crate::check::env::TagInfo) -> ::std::option::Option<crate::lower::model::Ex> {
    match (held_whole_ty_o(lx_p0, tg_p1), crate::lower::types::peel_f(&tg_p1.out_p)) {
        (::std::option::Option::Some(whole_p2), crate::check::types::Ty::TyTuple(parts_p3)) => {
            let read_p4 = crate::prelude::run_to_end(crate::prelude::each_job(crate::check::errors::range0_f(&crate::prelude::len(&parts_p3)), {
                let parts_p3x = parts_p3.clone();
                let lx_p0x = lx_p0.clone();
                ::std::rc::Rc::new(move |p0: crate::prelude::Nat| {
                    let parts_p3xy = parts_p3x.clone();
                    let lx_p0xy = lx_p0x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let i_p6 = p0;
                        {
                            let part_p7 = crate::prelude::or(&crate::prelude::index(&parts_p3xy, &i_p6), &crate::check::types::Ty::TyErr);
                            let value_p8 = crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XPart(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("held_whole"))), i_p6.clone())));
                            match crate::lower::types::layer_of_f(&part_p7) {
                                crate::lower::types::Layer::LyEv => crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0xy.clone(), crate::lower::types::peel_f(&part_p7)), move |out_ty_of_f_83057: crate::lower::model::OutTy| ::prism_rtl::Turn::Finished(crate::lower::expr::AnswerPart::PartEvent(value_p8.clone(), out_ty_of_f_83057))),
                                crate::lower::types::Layer::LyDyn => ::prism_rtl::Turn::Finished(crate::lower::expr::AnswerPart::PartLive(value_p8.clone())),
                                _ => ::prism_rtl::Turn::Finished(crate::lower::expr::AnswerPart::PartPlain(value_p8.clone())),
                            }
                        }
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::expr::AnswerPart>>>
            }));
            let env_p5 = crate::lower::types::bind_f(&crate::lower::types::bind_f(&crate::lower::types::empty_env_p(), &crate::prelude::Text::lit("#tag"), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XPath(crate::lower::node_::elements::answer_variant_f(tg_p1)), crate::lower::types::Holding::Owned, crate::lower::model::OutTy::OutUnit)), &crate::prelude::Text::lit("#tagfirst"), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XPath(crate::lower::node_::elements::answer_first_variant_f(tg_p1)), crate::lower::types::Holding::Owned, crate::lower::model::OutTy::OutUnit));
            ::std::option::Option::Some(crate::lower::model::Ex::XClosure(false, crate::prelude::Array::from(vec![crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("held_whole"))), crate::lower::model::OutTy::OutRef(::std::rc::Rc::new(whole_p2.clone())))]), ::std::rc::Rc::new(crate::lower::expr::parts_answer_of_f(lx_p0, &env_p5, &crate::prelude::Text::from(format!("a bundle held whole as {}\'s answer", &tg_p1.name_p)), &read_p4, &crate::lower::node_::elements::answer_variant_f(tg_p1)))))
        },
        _ => ::std::option::Option::None,
    }
}

/// The step machine of `HeldPartsOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?HeldPartsOf: unbounded fn Lx, TagInfo -> ?Ex
/// ```
pub struct HeldPartsOf {
    pub lx_p0: crate::lower::Lx,
    pub tg_p1: crate::check::env::TagInfo,
}

impl ::prism_rtl::Job<::std::option::Option<crate::lower::model::Ex>> for HeldPartsOf {
    fn cycle(&self) -> ::prism_rtl::Turn<::std::option::Option<crate::lower::model::Ex>> {
        let lx_p0 = &self.lx_p0;
        let tg_p1 = &self.tg_p1;
        let lx_p0x = lx_p0.clone();
        let tg_p1x = tg_p1.clone();
        crate::prelude::call_then(start_held_whole_ty_o(lx_p0x.clone(), tg_p1x.clone()), move |held_whole_ty_o_82759: ::std::option::Option<crate::lower::model::OutTy>| match (held_whole_ty_o_82759, crate::lower::types::peel_f(&tg_p1x.out_p)) {
            (::std::option::Option::Some(whole_p2), crate::check::types::Ty::TyTuple(parts_p3)) => crate::prelude::call_value(crate::prelude::each_job(crate::check::errors::range0_f(&crate::prelude::len(&parts_p3)), {
                let parts_p3x = parts_p3.clone();
                let lx_p0xx = lx_p0x.clone();
                ::std::rc::Rc::new(move |p0: crate::prelude::Nat| {
                    let parts_p3xy = parts_p3x.clone();
                    let lx_p0xxy = lx_p0xx.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let i_p6 = p0;
                        {
                            let part_p7 = crate::prelude::or(&crate::prelude::index(&parts_p3xy, &i_p6), &crate::check::types::Ty::TyErr);
                            let value_p8 = crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XPart(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("held_whole"))), i_p6.clone())));
                            match crate::lower::types::layer_of_f(&part_p7) {
                                crate::lower::types::Layer::LyEv => crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0xxy.clone(), crate::lower::types::peel_f(&part_p7)), move |out_ty_of_f_83057: crate::lower::model::OutTy| ::prism_rtl::Turn::Finished(crate::lower::expr::AnswerPart::PartEvent(value_p8.clone(), out_ty_of_f_83057))),
                                crate::lower::types::Layer::LyDyn => ::prism_rtl::Turn::Finished(crate::lower::expr::AnswerPart::PartLive(value_p8.clone())),
                                _ => ::prism_rtl::Turn::Finished(crate::lower::expr::AnswerPart::PartPlain(value_p8.clone())),
                            }
                        }
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::expr::AnswerPart>>>
            }), move |each_82849: crate::prelude::Array<crate::lower::expr::AnswerPart>| {
                let read_p4 = each_82849;
                let env_p5 = crate::lower::types::bind_f(&crate::lower::types::bind_f(&crate::lower::types::empty_env_p(), &crate::prelude::Text::lit("#tag"), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XPath(crate::lower::node_::elements::answer_variant_f(&tg_p1x)), crate::lower::types::Holding::Owned, crate::lower::model::OutTy::OutUnit)), &crate::prelude::Text::lit("#tagfirst"), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XPath(crate::lower::node_::elements::answer_first_variant_f(&tg_p1x)), crate::lower::types::Holding::Owned, crate::lower::model::OutTy::OutUnit));
                ::prism_rtl::Turn::Finished(::std::option::Option::Some(crate::lower::model::Ex::XClosure(false, crate::prelude::Array::from(vec![crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("held_whole"))), crate::lower::model::OutTy::OutRef(::std::rc::Rc::new(whole_p2.clone())))]), ::std::rc::Rc::new(crate::lower::expr::parts_answer_of_f(&lx_p0x, &env_p5, &crate::prelude::Text::from(format!("a bundle held whole as {}\'s answer", &tg_p1x.name_p)), &read_p4, &crate::lower::node_::elements::answer_variant_f(&tg_p1x))))))
            }),
            _ => ::prism_rtl::Turn::Finished(::std::option::Option::None),
        })
    }
}

/// `Start HeldPartsOf, x`: what the function value is when passed to `@Run`.
pub fn start_held_parts_of_o(lx_p0: crate::lower::Lx, tg_p1: crate::check::env::TagInfo) -> ::std::rc::Rc<dyn ::prism_rtl::Job<::std::option::Option<crate::lower::model::Ex>>> {
    ::std::rc::Rc::new(HeldPartsOf { lx_p0, tg_p1 })
}

/// ```prism
/// ?BundleStateTy: unbounded fn Lx, TagInfo -> ?OutTy
/// ```
pub fn bundle_state_ty_o(lx_p0: &crate::lower::Lx, tg_p1: &crate::check::env::TagInfo) -> ::std::option::Option<crate::lower::model::OutTy> {
    match crate::lower::types::peel_f(&tg_p1.out_p) {
        crate::check::types::Ty::TyTuple(cs_p2) => 'm83860: {
            let scrutinee = &crate::prelude::filter(&cs_p2, &(|c_p3: &crate::check::types::Ty| &crate::lower::types::layer_of_f(c_p3) != &crate::lower::types::Layer::LyEv));
            if let m83860_0 = scrutinee && (m83860_0.len() == 0) {
                break 'm83860 ::std::option::Option::None;
            }
            if let m83860_1 = scrutinee && (m83860_1.len() == 1) && let ::std::option::Option::Some(c_p4) = crate::prelude::index(m83860_1, &crate::prelude::Nat::from(0u32)) {
                break 'm83860 ::std::option::Option::Some(crate::lower::types::tag_field_out_f(lx_p0, &c_p4));
            }
            if let state_p5 = scrutinee {
                break 'm83860 ::std::option::Option::Some(crate::lower::model::OutTy::OutTuple(crate::prelude::run_to_end(crate::prelude::each_job(state_p5.clone(), {
                    let lx_p0x = lx_p0.clone();
                    ::std::rc::Rc::new(move |p0: crate::check::types::Ty| {
                        let lx_p0xy = lx_p0x.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let c_p6 = p0;
                            ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::lower::types::TagFieldOut { lx_p0: lx_p0xy.clone(), ft_p1: c_p6.clone() }))
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::OutTy>>>
                }))));
            }
            unreachable!("no clause matched")
        },
        _ => ::std::option::Option::None,
    }
}

/// The step machine of `BundleStateTy`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?BundleStateTy: unbounded fn Lx, TagInfo -> ?OutTy
/// ```
pub struct BundleStateTy {
    pub lx_p0: crate::lower::Lx,
    pub tg_p1: crate::check::env::TagInfo,
}

impl ::prism_rtl::Job<::std::option::Option<crate::lower::model::OutTy>> for BundleStateTy {
    fn cycle(&self) -> ::prism_rtl::Turn<::std::option::Option<crate::lower::model::OutTy>> {
        let lx_p0 = &self.lx_p0;
        let tg_p1 = &self.tg_p1;
        match crate::lower::types::peel_f(&tg_p1.out_p) {
            crate::check::types::Ty::TyTuple(cs_p2) => 'm83860: {
                let scrutinee = &crate::prelude::filter(&cs_p2, &(|c_p3: &crate::check::types::Ty| &crate::lower::types::layer_of_f(c_p3) != &crate::lower::types::Layer::LyEv));
                if let m83860_0 = scrutinee && (m83860_0.len() == 0) {
                    break 'm83860 ::prism_rtl::Turn::Finished(::std::option::Option::None);
                }
                if let m83860_1 = scrutinee && (m83860_1.len() == 1) && let ::std::option::Option::Some(c_p4) = crate::prelude::index(m83860_1, &crate::prelude::Nat::from(0u32)) {
                    break 'm83860 ::prism_rtl::Turn::Finished(::std::option::Option::Some(crate::lower::types::tag_field_out_f(lx_p0, &c_p4)));
                }
                if let state_p5 = scrutinee {
                    break 'm83860 ::prism_rtl::Turn::Finished(::std::option::Option::Some(crate::lower::model::OutTy::OutTuple(crate::prelude::run_to_end(crate::prelude::each_job(state_p5.clone(), {
                        let lx_p0x = lx_p0.clone();
                        ::std::rc::Rc::new(move |p0: crate::check::types::Ty| {
                            let lx_p0xy = lx_p0x.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let c_p6 = p0;
                                ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::lower::types::TagFieldOut { lx_p0: lx_p0xy.clone(), ft_p1: c_p6.clone() }))
                            }))
                        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::OutTy>>>
                    })))));
                }
                unreachable!("no clause matched")
            },
            _ => ::prism_rtl::Turn::Finished(::std::option::Option::None),
        }
    }
}

/// `Start BundleStateTy, x`: what the function value is when passed to `@Run`.
pub fn start_bundle_state_ty_o(lx_p0: crate::lower::Lx, tg_p1: crate::check::env::TagInfo) -> ::std::rc::Rc<dyn ::prism_rtl::Job<::std::option::Option<crate::lower::model::OutTy>>> {
    ::std::rc::Rc::new(BundleStateTy { lx_p0, tg_p1 })
}

/// ```prism
/// ?BundleFirstTy: unbounded fn Lx, TagInfo -> ?OutTy
/// ```
pub fn bundle_first_ty_o(lx_p0: &crate::lower::Lx, tg_p1: &crate::check::env::TagInfo) -> ::std::option::Option<crate::lower::model::OutTy> {
    match crate::lower::types::peel_f(&tg_p1.out_p) {
        crate::check::types::Ty::TyTuple(cs_p2) => if crate::prelude::fold(&cs_p2, &false, &(|f_p3: &bool, c_p4: &crate::check::types::Ty| *f_p3 || (&crate::lower::types::layer_of_f(c_p4) == &crate::lower::types::Layer::LyEv))) {
            bundle_state_ty_o(lx_p0, tg_p1)
        } else {
            ::std::option::Option::None
        },
        _ => ::std::option::Option::None,
    }
}

/// The step machine of `BundleFirstTy`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?BundleFirstTy: unbounded fn Lx, TagInfo -> ?OutTy
/// ```
pub struct BundleFirstTy {
    pub lx_p0: crate::lower::Lx,
    pub tg_p1: crate::check::env::TagInfo,
}

impl ::prism_rtl::Job<::std::option::Option<crate::lower::model::OutTy>> for BundleFirstTy {
    fn cycle(&self) -> ::prism_rtl::Turn<::std::option::Option<crate::lower::model::OutTy>> {
        let lx_p0 = &self.lx_p0;
        let tg_p1 = &self.tg_p1;
        match crate::lower::types::peel_f(&tg_p1.out_p) {
            crate::check::types::Ty::TyTuple(cs_p2) => if crate::prelude::fold(&cs_p2, &false, &(|f_p3: &bool, c_p4: &crate::check::types::Ty| *f_p3 || (&crate::lower::types::layer_of_f(c_p4) == &crate::lower::types::Layer::LyEv))) {
                ::prism_rtl::Turn::More(::std::rc::Rc::new(BundleStateTy { lx_p0: lx_p0.clone(), tg_p1: tg_p1.clone() }))
            } else {
                ::prism_rtl::Turn::Finished(::std::option::Option::None)
            },
            _ => ::prism_rtl::Turn::Finished(::std::option::Option::None),
        }
    }
}

/// `Start BundleFirstTy, x`: what the function value is when passed to `@Run`.
pub fn start_bundle_first_ty_o(lx_p0: crate::lower::Lx, tg_p1: crate::check::env::TagInfo) -> ::std::rc::Rc<dyn ::prism_rtl::Job<::std::option::Option<crate::lower::model::OutTy>>> {
    ::std::rc::Rc::new(BundleFirstTy { lx_p0, tg_p1 })
}

/// ```prism
/// SparsePartTy: fn OutTy -> OutTy
/// ```
pub fn sparse_part_ty_f(t_p0: &crate::lower::model::OutTy) -> crate::lower::model::OutTy {
    crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("prism_rtl::SparsePart")), crate::prelude::Array::from(vec![t_p0.clone()]))
}

/// ```prism
/// AnswerTy: unbounded fn Lx, TagInfo -> OutTy
/// ```
pub fn answer_ty_f(lx_p0: &crate::lower::Lx, tg_p1: &crate::check::env::TagInfo) -> crate::lower::model::OutTy {
    let out_p2 = crate::lower::types::peel_f(&tg_p1.out_p);
    match &out_p2 {
        crate::check::types::Ty::TyTuple(cs_p3) => if !crate::lower::types::is_bundle_f(&out_p2) {
            crate::lower::types::tag_field_out_f(lx_p0, &out_p2)
        } else {
            'm85431: {
                let scrutinee = &crate::prelude::filter(cs_p3, &(|c_p4: &crate::check::types::Ty| &crate::lower::types::layer_of_f(c_p4) == &crate::lower::types::Layer::LyEv));
                if let m85431_0 = scrutinee && (m85431_0.len() == 0) {
                    break 'm85431 crate::prelude::or(&bundle_state_ty_o(lx_p0, tg_p1), &crate::lower::model::OutTy::OutUnit);
                }
                if let m85431_1 = scrutinee && (m85431_1.len() == 1) && let ::std::option::Option::Some(c_p5) = crate::prelude::index(m85431_1, &crate::prelude::Nat::from(0u32)) {
                    break 'm85431 crate::lower::types::tag_field_out_f(lx_p0, &c_p5);
                }
                if let evs_p6 = scrutinee {
                    break 'm85431 crate::lower::model::OutTy::OutTuple(crate::prelude::run_to_end(crate::prelude::each_job(evs_p6.clone(), {
                        let lx_p0x = lx_p0.clone();
                        ::std::rc::Rc::new(move |p0: crate::check::types::Ty| {
                            let lx_p0xy = lx_p0x.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let c_p7 = p0;
                                crate::prelude::call_then(crate::lower::types::start_tag_field_out_f(lx_p0xy.clone(), c_p7.clone()), move |tag_field_out_f_85621: crate::lower::model::OutTy| ::prism_rtl::Turn::Finished(sparse_part_ty_f(&tag_field_out_f_85621)))
                            }))
                        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::OutTy>>>
                    })));
                }
                unreachable!("no clause matched")
            }
        },
        _ => crate::lower::types::tag_field_out_f(lx_p0, &out_p2),
    }
}

/// The step machine of `AnswerTy`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// AnswerTy: unbounded fn Lx, TagInfo -> OutTy
/// ```
pub struct AnswerTy {
    pub lx_p0: crate::lower::Lx,
    pub tg_p1: crate::check::env::TagInfo,
}

impl ::prism_rtl::Job<crate::lower::model::OutTy> for AnswerTy {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::lower::model::OutTy> {
        let lx_p0 = &self.lx_p0;
        let tg_p1 = &self.tg_p1;
        let out_p2 = crate::lower::types::peel_f(&tg_p1.out_p);
        match &out_p2 {
            crate::check::types::Ty::TyTuple(cs_p3) => if !crate::lower::types::is_bundle_f(&out_p2) {
                ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::lower::types::TagFieldOut { lx_p0: lx_p0.clone(), ft_p1: out_p2.clone() }))
            } else {
                'm85431: {
                    let scrutinee = &crate::prelude::filter(cs_p3, &(|c_p4: &crate::check::types::Ty| &crate::lower::types::layer_of_f(c_p4) == &crate::lower::types::Layer::LyEv));
                    if let m85431_0 = scrutinee && (m85431_0.len() == 0) {
                        break 'm85431 {
                            let lx_p0x = lx_p0.clone();
                            let tg_p1x = tg_p1.clone();
                            crate::prelude::call_then(start_bundle_state_ty_o(lx_p0x.clone(), tg_p1x.clone()), move |bundle_state_ty_o_85496: ::std::option::Option<crate::lower::model::OutTy>| ::prism_rtl::Turn::Finished(crate::prelude::or(&bundle_state_ty_o_85496, &crate::lower::model::OutTy::OutUnit)))
                        };
                    }
                    if let m85431_1 = scrutinee && (m85431_1.len() == 1) && let ::std::option::Option::Some(c_p5) = crate::prelude::index(m85431_1, &crate::prelude::Nat::from(0u32)) {
                        break 'm85431 ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::lower::types::TagFieldOut { lx_p0: lx_p0.clone(), ft_p1: c_p5.clone() }));
                    }
                    if let evs_p6 = scrutinee {
                        break 'm85431 {
                            let evs_p6x = evs_p6.clone();
                            let lx_p0x = lx_p0.clone();
                            crate::prelude::call_value(crate::prelude::each_job(evs_p6x.clone(), {
                                let lx_p0xx = lx_p0x.clone();
                                ::std::rc::Rc::new(move |p0: crate::check::types::Ty| {
                                    let lx_p0xxy = lx_p0xx.clone();
                                    crate::prelude::entered(crate::prelude::once_job(move || {
                                        let c_p7 = p0;
                                        crate::prelude::call_then(crate::lower::types::start_tag_field_out_f(lx_p0xxy.clone(), c_p7.clone()), move |tag_field_out_f_85621: crate::lower::model::OutTy| ::prism_rtl::Turn::Finished(sparse_part_ty_f(&tag_field_out_f_85621)))
                                    }))
                                }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::OutTy>>>
                            }), move |each_85592: crate::prelude::Array<crate::lower::model::OutTy>| ::prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutTuple(each_85592)))
                        };
                    }
                    unreachable!("no clause matched")
                }
            },
            _ => ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::lower::types::TagFieldOut { lx_p0: lx_p0.clone(), ft_p1: out_p2.clone() })),
        }
    }
}

/// `Start AnswerTy, x`: what the function value is when passed to `@Run`.
pub fn start_answer_ty_f(lx_p0: crate::lower::Lx, tg_p1: crate::check::env::TagInfo) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::OutTy>> {
    ::std::rc::Rc::new(AnswerTy { lx_p0, tg_p1 })
}

/// ```prism
/// AnswerTaken: unbounded fn Lx, Text, OutTy, Ex -> Ex
/// ```
pub fn answer_taken_f(lx_p0: &crate::lower::Lx, accessor_p1: &crate::prelude::Text, placed_p2: &crate::lower::model::OutTy, taken_p3: &crate::lower::model::Ex) -> crate::lower::model::Ex {
    let named_o4 = crate::prelude::fold(&crate::prelude::values(&lx_p0.g_p.tags_p), &::std::option::Option::None, &(|found_o6: &::std::option::Option<crate::check::env::TagInfo>, tg_p7: &crate::check::env::TagInfo| if (&tg_p7.kind_p == &crate::prelude::Text::lit("Element")) && (&crate::lower::node_::elements::answer_accessor_f(tg_p7) == accessor_p1) {
        ::std::option::Option::Some(tg_p7.clone())
    } else {
        found_o6.clone()
    }));
    let first_o5 = crate::prelude::fold(&crate::prelude::values(&lx_p0.g_p.tags_p), &::std::option::Option::None, &(|found_o8: &::std::option::Option<crate::check::env::TagInfo>, tg_p9: &crate::check::env::TagInfo| if (&tg_p9.kind_p == &crate::prelude::Text::lit("Element")) && (&crate::prelude::Text::from(format!("{}_first", &crate::lower::node_::elements::answer_accessor_f(tg_p9))) == accessor_p1) {
        ::std::option::Option::Some(tg_p9.clone())
    } else {
        found_o8.clone()
    }));
    match (named_o4.clone(), first_o5.clone()) {
        (::std::option::Option::Some(tg_pa), _) => recoded_answer_f(&answer_open_f(lx_p0, &tg_pa), &answer_ty_f(lx_p0, &tg_pa), placed_p2, taken_p3),
        (::std::option::Option::None, ::std::option::Option::Some(tg_pb)) => recoded_answer_f(&answer_open_f(lx_p0, &tg_pb), &crate::prelude::or(&bundle_first_ty_o(lx_p0, &tg_pb), &crate::lower::model::OutTy::OutUnit), placed_p2, taken_p3),
        _ => crate::lower::expr::internal_bug_f(&crate::prelude::Text::from(format!("an answer taken by `{}`, which is no tag\'s accessor", accessor_p1))),
    }
}

/// The step machine of `AnswerTaken`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// AnswerTaken: unbounded fn Lx, Text, OutTy, Ex -> Ex
/// ```
pub struct AnswerTaken {
    pub lx_p0: crate::lower::Lx,
    pub accessor_p1: crate::prelude::Text,
    pub placed_p2: crate::lower::model::OutTy,
    pub taken_p3: crate::lower::model::Ex,
}

impl ::prism_rtl::Job<crate::lower::model::Ex> for AnswerTaken {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::lower::model::Ex> {
        let lx_p0 = &self.lx_p0;
        let accessor_p1 = &self.accessor_p1;
        let placed_p2 = &self.placed_p2;
        let taken_p3 = &self.taken_p3;
        let named_o4 = crate::prelude::fold(&crate::prelude::values(&lx_p0.g_p.tags_p), &::std::option::Option::None, &(|found_o6: &::std::option::Option<crate::check::env::TagInfo>, tg_p7: &crate::check::env::TagInfo| if (&tg_p7.kind_p == &crate::prelude::Text::lit("Element")) && (&crate::lower::node_::elements::answer_accessor_f(tg_p7) == accessor_p1) {
            ::std::option::Option::Some(tg_p7.clone())
        } else {
            found_o6.clone()
        }));
        let first_o5 = crate::prelude::fold(&crate::prelude::values(&lx_p0.g_p.tags_p), &::std::option::Option::None, &(|found_o8: &::std::option::Option<crate::check::env::TagInfo>, tg_p9: &crate::check::env::TagInfo| if (&tg_p9.kind_p == &crate::prelude::Text::lit("Element")) && (&crate::prelude::Text::from(format!("{}_first", &crate::lower::node_::elements::answer_accessor_f(tg_p9))) == accessor_p1) {
            ::std::option::Option::Some(tg_p9.clone())
        } else {
            found_o8.clone()
        }));
        match (named_o4.clone(), first_o5.clone()) {
            (::std::option::Option::Some(tg_pa), _) => {
                let lx_p0x = lx_p0.clone();
                let placed_p2x = placed_p2.clone();
                let taken_p3x = taken_p3.clone();
                crate::prelude::call_then(start_answer_ty_f(lx_p0x.clone(), tg_pa.clone()), move |answer_ty_f_86454: crate::lower::model::OutTy| ::prism_rtl::Turn::Finished(recoded_answer_f(&answer_open_f(&lx_p0x, &tg_pa), &answer_ty_f_86454, &placed_p2x, &taken_p3x)))
            },
            (::std::option::Option::None, ::std::option::Option::Some(tg_pb)) => {
                let lx_p0x = lx_p0.clone();
                let placed_p2x = placed_p2.clone();
                let taken_p3x = taken_p3.clone();
                crate::prelude::call_then(start_bundle_first_ty_o(lx_p0x.clone(), tg_pb.clone()), move |bundle_first_ty_o_86549: ::std::option::Option<crate::lower::model::OutTy>| ::prism_rtl::Turn::Finished(recoded_answer_f(&answer_open_f(&lx_p0x, &tg_pb), &crate::prelude::or(&bundle_first_ty_o_86549, &crate::lower::model::OutTy::OutUnit), &placed_p2x, &taken_p3x)))
            },
            _ => ::prism_rtl::Turn::Finished(crate::lower::expr::internal_bug_f(&crate::prelude::Text::from(format!("an answer taken by `{}`, which is no tag\'s accessor", accessor_p1)))),
        }
    }
}

/// `Start AnswerTaken, x`: what the function value is when passed to `@Run`.
pub fn start_answer_taken_f(lx_p0: crate::lower::Lx, accessor_p1: crate::prelude::Text, placed_p2: crate::lower::model::OutTy, taken_p3: crate::lower::model::Ex) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>> {
    ::std::rc::Rc::new(AnswerTaken { lx_p0, accessor_p1, placed_p2, taken_p3 })
}

/// ```prism
/// AnswerOpen: unbounded fn Lx, TagInfo -> Bool
/// ```
pub fn answer_open_f(lx_p0: &crate::lower::Lx, tg_p1: &crate::check::env::TagInfo) -> bool {
    crate::lower::types::tag_field_open_f(lx_p0, &tg_p1.out_p)
}

/// ```prism
/// RecodedAnswer: fn Bool, OutTy, OutTy, Ex -> Ex
/// ```
pub fn recoded_answer_f(open_p0: &bool, carried_p1: &crate::lower::model::OutTy, placed_p2: &crate::lower::model::OutTy, taken_p3: &crate::lower::model::Ex) -> crate::lower::model::Ex {
    if *open_p0 && (carried_p1 != placed_p2) {
        crate::lower::model::Ex::XCallAt(crate::lower::helper_ref_f(&crate::prelude::Text::lit("recode")), crate::prelude::Array::from(vec![placed_p2.clone()]), crate::prelude::Array::from(vec![crate::lower::model::Ex::XRef(::std::rc::Rc::new(taken_p3.clone()))]))
    } else {
        taken_p3.clone()
    }
}

/// ```prism
/// TagPaths: fn Lx, TagInfo -> ((Ref, Ref))
/// ```
pub fn tag_paths_f(lx_p0: &crate::lower::Lx, tg_p1: &crate::check::env::TagInfo) -> (crate::lower::model::Ref, crate::lower::model::Ref) {
    (variant_of_f(lx_p0, tg_p1), crate::lower::ref_in_f(lx_p0, &tg_p1.home_p, &crate::lower::tag_struct_of_f(tg_p1)))
}

/// ```prism
/// VariantOf: fn Lx, TagInfo -> Ref
/// ```
pub fn variant_of_f(lx_p0: &crate::lower::Lx, tg_p1: &crate::check::env::TagInfo) -> crate::lower::model::Ref {
    crate::lower::model::ref_child_f(&kind_ref_f(lx_p0, &tg_p1.kind_p), &crate::lower::tag_struct_f(&tg_p1.name_p))
}

/// ```prism
/// KindRef: fn Lx, Text -> Ref
/// ```
pub fn kind_ref_f(lx_p0: &crate::lower::Lx, kind_p1: &crate::prelude::Text) -> crate::lower::model::Ref {
    if kind_p1 == &crate::prelude::Text::lit("Element") {
        crate::lower::model::elem_ref_p()
    } else {
        crate::lower::ref_in_f(lx_p0, &crate::prelude::or(&crate::prelude::get(&lx_p0.g_p.types_p, kind_p1), &crate::check::env::names::dummy_ty_info_p()).home_p, &crate::lower::camel_f(&crate::check::types::bare_name_f(kind_p1)))
    }
}

/// ```prism
/// CheckDefOf: unbounded fn Lx, CheckDecl -> CheckDef
/// ```
pub fn check_def_of_f(lx_p0: &crate::lower::Lx, c_p1: &crate::syntax::decls::CheckDecl) -> crate::lower::model::CheckDef {
    crate::lower::model::CheckDef { name_p: c_p1.name_p.name_p.clone(), lines_p: crate::prelude::run_to_end(crate::prelude::each_job(c_p1.lines_p.clone(), {
        let lx_p0x = lx_p0.clone();
        ::std::rc::Rc::new(move |p0: crate::syntax::decls::CheckLine| {
            let lx_p0xy = lx_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let l_p2 = p0;
                crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p0xy.clone(), crate::lower::types::empty_env_p(), l_p2.expr_p.clone()), move |value_of_f_87766: crate::lower::types::Vl| ::prism_rtl::Turn::Finished(crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Ok")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::types::own_f(&value_of_f_87766)), crate::prelude::Text::lit("to_pod"), crate::prelude::Array::new())]))))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::syntax::decls::CheckLine) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>>>
    })) }
}

/// The step machine of `CheckDefOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CheckDefOf: unbounded fn Lx, CheckDecl -> CheckDef
/// ```
pub struct CheckDefOf {
    pub lx_p0: crate::lower::Lx,
    pub c_p1: crate::syntax::decls::CheckDecl,
}

impl ::prism_rtl::Job<crate::lower::model::CheckDef> for CheckDefOf {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::lower::model::CheckDef> {
        let lx_p0 = &self.lx_p0;
        let c_p1 = &self.c_p1;
        let c_p1x = c_p1.clone();
        let lx_p0x = lx_p0.clone();
        crate::prelude::call_value(crate::prelude::each_job(c_p1x.lines_p.clone(), {
            let lx_p0xx = lx_p0x.clone();
            ::std::rc::Rc::new(move |p0: crate::syntax::decls::CheckLine| {
                let lx_p0xxy = lx_p0xx.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let l_p2 = p0;
                    crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p0xxy.clone(), crate::lower::types::empty_env_p(), l_p2.expr_p.clone()), move |value_of_f_87766: crate::lower::types::Vl| ::prism_rtl::Turn::Finished(crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Ok")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::types::own_f(&value_of_f_87766)), crate::prelude::Text::lit("to_pod"), crate::prelude::Array::new())]))))
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::syntax::decls::CheckLine) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>>>
        }), move |each_87700: crate::prelude::Array<crate::lower::model::Ex>| ::prism_rtl::Turn::Finished(crate::lower::model::CheckDef { name_p: c_p1x.name_p.name_p.clone(), lines_p: each_87700 }))
    }
}

/// `Start CheckDefOf, x`: what the function value is when passed to `@Run`.
pub fn start_check_def_of_f(lx_p0: crate::lower::Lx, c_p1: crate::syntax::decls::CheckDecl) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::CheckDef>> {
    ::std::rc::Rc::new(CheckDefOf { lx_p0, c_p1 })
}
