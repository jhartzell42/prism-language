//! The module `Lower.Program`, from `target/bootstrap/src/prismc/lower/program.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// ```prism
/// InModule: fn Lx, Nat, Text -> Lx
/// ```
pub fn in_module(lx: &crate::lower::Lx, file: &Nat, home: &Text) -> crate::lower::Lx {
    let mut this: crate::lower::Lx = lx.clone();
    this.file = file.clone();
    this.home = home.clone();
    this.site = home.clone();
    this
}

/// ```prism
/// InModuleAt: fn Lx, Nat, Text, Text -> Lx
/// ```
pub fn in_module_at(lx: &crate::lower::Lx, file: &Nat, home: &Text, site: &Text) -> crate::lower::Lx {
    let mut this: crate::lower::Lx = lx.clone();
    this.file = file.clone();
    this.home = home.clone();
    this.site = site.clone();
    this
}

/// ```prism
/// LowerProgram: unbounded fn [Src], [Module], Nat, TProgram, Text -> Model
/// ```
pub fn lower_program(srcs: &Array<crate::check::errors::Src>, trees: &Array<crate::syntax::Module>, shown: &Nat, tp: &crate::check::typed::TProgram, name: &Text) -> crate::lower::model::Model {
    let (g, _) = crate::check::env::build_g(srcs, trees);
    let (tys, apps, bs, ims) = crate::lower::typed_tables(tp);
    let gens = fold(&tp.gens, &Map::new(), &(|m: &Map<Text, crate::check::typed::GenNote>, n: &crate::check::typed::GenNote| insert(m, &crate::check::typed::at_key(&n.at), n)));
    let insts = fold(&tp.insts, &Map::new(), &(|m: &Map<Text, Array<crate::check::typed::InstNote>>, n: &crate::check::typed::InstNote| insert(m, &crate::lower::expr::inst_key(n), &push(&or(&get(m, &crate::lower::expr::inst_key(n)), &Array::new()), n))));
    let quants = fold(&tp.gens, &Map::new(), &(|m: &Map<Text, Text>, n: &crate::check::typed::GenNote| fold(&append(&n.tys, &n.cols), m, &(|m2: &Map<Text, Text>, q: &Text| insert(m2, q, &n.name)))));
    let gen_of_q = fold(&tp.gens, &Map::new(), &(|m: &Map<Text, crate::check::typed::GenNote>, n: &crate::check::typed::GenNote| fold(&append(&n.tys, &n.cols), m, &(|m2: &Map<Text, crate::check::typed::GenNote>, q: &Text| insert(m2, q, n)))));
    let use_insts = fold(&tp.insts, &Map::new(), &(|m: &Map<Text, crate::check::typed::InstNote>, n: &crate::check::typed::InstNote| insert(m, &crate::check::typed::at_key(&n.at), n)));
    let mods = needed_mods(&g, shown);
    let rs_mods = fold(&mods, &Map::new(), &(|acc: &Map<Text, Text>, m: &Text| insert(acc, m, &crate::lower::rust_mod_name(m))));
    let lx0 = crate::lower::Lx { g: g.clone(), tys: tys.clone(), apps: apps.clone(), binders: bs.clone(), impls: ims.clone(), file: Nat::from(0u32), home: Text::lit(""), site: Text::lit(""), rs_mods: rs_mods.clone(), rs_names: crate::lower::value_names(&g), layouts: crate::lower::types::layouts(&g), unbs: Array::new(), notes: Array::new(), globals: crate::lower::global_names(&g), in_node: false, unshrunk: fold(&tp.unshrunk, &Map::new(), &(|m: &Map<Text, bool>, a: &crate::check::typed::SrcAt| insert(m, &crate::check::typed::at_key(a), &true))), gens: gens.clone(), insts: insts.clone(), quants: quants.clone(), gen_of_q: gen_of_q.clone(), use_insts: use_insts.clone(), subst: Map::new(), csubst: Map::new() };
    let lx = {
        let mut this: crate::lower::Lx = lx0.clone();
        this.unbs = job_roots(&lx0);
        this
    };
    let roots = root_widgets(&lx);
    let mod_defs = run_to_end(each_job(mods.clone(), {
        let lx = lx.clone();
        let roots = roots.clone();
        let g = g.clone();
        let mods = mods.clone();
        Rc::new(move |p0: Text| {
            let lx = lx.clone();
            let roots = roots.clone();
            let g = g.clone();
            let mods = mods.clone();
            entered(once_job(move || {
                let m = p0;
                prism_rtl::Turn::More(Rc::new(ModDefOf { lx0: lx.clone(), m: m.clone(), roots: roots.clone(), info: or(&get(&g.mods, &m), &crate::check::env::reading::dummy_mod()), mods: mods.clone() }))
            }))
        }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<crate::lower::model::ModDef>>>
    }));
    let programs = run_to_end(each_job(roots.clone(), {
        let lx = lx.clone();
        Rc::new(move |p0: (Text, bool)| {
            let lx = lx.clone();
            entered(once_job(move || {
                let (qk, _) = p0;
                prism_rtl::Turn::More(Rc::new(ProgDefOf { lx: lx.clone(), qk: qk.clone() }))
            }))
        }) as Rc<dyn Fn((Text, bool)) -> Rc<dyn prism_rtl::Job<crate::lower::model::ProgDef>>>
    }));
    let main_qk = fold(&g.defs, &Text::lit(""), &(|found: &Text, d: &crate::check::env::Def| if (found == &Text::lit("")) && is_main(&d.qk) { d.qk.clone() } else { found.clone() }));
    let root_opt = if &main_qk == &Text::lit("") { None } else { Some(prog_def_of(&lx, &main_qk)) };
    let checks = run_to_end(fold_job(g.defs.clone(), Array::new(), {
        let lx = lx.clone();
        Rc::new(move |(p0, p1): (Array<crate::lower::model::CheckDef>, crate::check::env::Def)| {
            let lx = lx.clone();
            entered(once_job(move || {
                let acc = p0;
                let d = p1;
                match &d.body {
                    crate::check::env::DefBody::DbCheck(c) => {
                        let c = c.clone();
                        call_then(start_check_def_of(in_module_at(&lx, &d.file, &d.home, &Text::lit("\0main")), c.clone()), move |check_def_of_3411: crate::lower::model::CheckDef| prism_rtl::Turn::Finished(push(&acc, &check_def_of_3411)))
                    },
                    _ => prism_rtl::Turn::Finished(acc.clone()),
                }
            }))
        }) as Rc<dyn Fn((Array<crate::lower::model::CheckDef>, crate::check::env::Def)) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::CheckDef>>>>
    }));
    let with_needs_ = with_groups(&with_needs(&g, srcs, tp, &mod_defs));
    let elem = elem_row(&lx, &mods);
    let answer = answer_enum(&in_module_at(&lx, &Nat::from(0u32), &Text::lit(""), &Text::lit("\0main")), &mods);
    let names = each(&with_needs_, &(|d: &crate::lower::model::ModDef| d.name.clone()));
    let value_tys = value_types(&with_needs_);
    let elem_held = fold(&elem.cases, &Array::new(), &(|acc: &Array<Text>, (_, sp): &(Text, Text)| crate::check::types::union_texts(acc, &held_in(&names, &value_tys, &Text::lit(""), &crate::lower::model::OutTy::OutNamed(sp.clone(), Array::new())))));
    let answer_held = fold(&answer.cases, &elem_held, &(|acc: &Array<Text>, k: &crate::lower::model::AnswerCase| crate::check::types::union_texts(acc, &held_in(&names, &value_tys, &Text::lit(""), &k.ty))));
    let answer_named = fold(&answer.cases, &Array::new(), &(|acc: &Array<Text>, k: &crate::lower::model::AnswerCase| crate::check::types::union_texts(acc, &named_in(&names, &Text::lit(""), &k.ty))));
    crate::lower::model::Model { name: name.clone(), mods: with_needs_.clone(), programs: programs.clone(), root: root_opt.clone(), checks: checks.clone(), elem: elem.clone(), answer: answer.clone(), elem_complete: answer_held.clone(), elem_declared: crate::check::types::minus_texts(&answer_named, &answer_held), scripts: Array::new(), notes: Array::new() }
}

/// The step machine of `LowerProgram`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LowerProgram: unbounded fn [Src], [Module], Nat, TProgram, Text -> Model
/// ```
pub struct LowerProgram {
    pub srcs: Array<crate::check::errors::Src>,
    pub trees: Array<crate::syntax::Module>,
    pub shown: Nat,
    pub tp: crate::check::typed::TProgram,
    pub name: Text,
}

impl prism_rtl::Job<crate::lower::model::Model> for LowerProgram {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::Model> {
        let srcs = &self.srcs;
        let trees = &self.trees;
        let shown = &self.shown;
        let tp = &self.tp;
        let name = &self.name;
        let name = name.clone();
        let shown = shown.clone();
        let srcs = srcs.clone();
        let tp = tp.clone();
        let trees = trees.clone();
        call_then(crate::check::env::start_build_g(srcs.clone(), trees.clone()), move |build_g_1920: (crate::check::env::G, crate::check::types::St)| {
            let (g, _) = build_g_1920;
            let (tys, apps, bs, ims) = crate::lower::typed_tables(&tp);
            let gens = fold(&tp.gens, &Map::new(), &(|m: &Map<Text, crate::check::typed::GenNote>, n: &crate::check::typed::GenNote| insert(m, &crate::check::typed::at_key(&n.at), n)));
            let insts = fold(&tp.insts, &Map::new(), &(|m: &Map<Text, Array<crate::check::typed::InstNote>>, n: &crate::check::typed::InstNote| insert(m, &crate::lower::expr::inst_key(n), &push(&or(&get(m, &crate::lower::expr::inst_key(n)), &Array::new()), n))));
            let quants = fold(&tp.gens, &Map::new(), &(|m: &Map<Text, Text>, n: &crate::check::typed::GenNote| fold(&append(&n.tys, &n.cols), m, &(|m2: &Map<Text, Text>, q: &Text| insert(m2, q, &n.name)))));
            let gen_of_q = fold(&tp.gens, &Map::new(), &(|m: &Map<Text, crate::check::typed::GenNote>, n: &crate::check::typed::GenNote| fold(&append(&n.tys, &n.cols), m, &(|m2: &Map<Text, crate::check::typed::GenNote>, q: &Text| insert(m2, q, n)))));
            let use_insts = fold(&tp.insts, &Map::new(), &(|m: &Map<Text, crate::check::typed::InstNote>, n: &crate::check::typed::InstNote| insert(m, &crate::check::typed::at_key(&n.at), n)));
            call_then(start_needed_mods(g.clone(), shown.clone()), move |needed_mods_2446: Array<Text>| {
                let mods = needed_mods_2446;
                let rs_mods = fold(&mods, &Map::new(), &(|acc: &Map<Text, Text>, m: &Text| insert(acc, m, &crate::lower::rust_mod_name(m))));
                call_then(crate::lower::types::start_layouts(g.clone()), move |layouts_2678: Map<Text, Array<bool>>| {
                    let lx0 = crate::lower::Lx { g: g.clone(), tys: tys.clone(), apps: apps.clone(), binders: bs.clone(), impls: ims.clone(), file: Nat::from(0u32), home: Text::lit(""), site: Text::lit(""), rs_mods: rs_mods.clone(), rs_names: crate::lower::value_names(&g), layouts: layouts_2678, unbs: Array::new(), notes: Array::new(), globals: crate::lower::global_names(&g), in_node: false, unshrunk: fold(&tp.unshrunk, &Map::new(), &(|m: &Map<Text, bool>, a: &crate::check::typed::SrcAt| insert(m, &crate::check::typed::at_key(a), &true))), gens: gens.clone(), insts: insts.clone(), quants: quants.clone(), gen_of_q: gen_of_q.clone(), use_insts: use_insts.clone(), subst: Map::new(), csubst: Map::new() };
                    let lx = {
                        let mut this: crate::lower::Lx = lx0.clone();
                        this.unbs = job_roots(&lx0);
                        this
                    };
                    let roots = root_widgets(&lx);
                    call_value(each_job(mods.clone(), {
                        let lx = lx.clone();
                        let roots = roots.clone();
                        let g = g.clone();
                        let mods = mods.clone();
                        Rc::new(move |p0: Text| {
                            let lx = lx.clone();
                            let roots = roots.clone();
                            let g = g.clone();
                            let mods = mods.clone();
                            entered(once_job(move || {
                                let m = p0;
                                prism_rtl::Turn::More(Rc::new(ModDefOf { lx0: lx.clone(), m: m.clone(), roots: roots.clone(), info: or(&get(&g.mods, &m), &crate::check::env::reading::dummy_mod()), mods: mods.clone() }))
                            }))
                        }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<crate::lower::model::ModDef>>>
                    }), move |each_3020: Array<crate::lower::model::ModDef>| {
                        let mod_defs = each_3020;
                        call_value(each_job(roots.clone(), {
                            let lx = lx.clone();
                            Rc::new(move |p0: (Text, bool)| {
                                let lx = lx.clone();
                                entered(once_job(move || {
                                    let (qk, _) = p0;
                                    prism_rtl::Turn::More(Rc::new(ProgDefOf { lx: lx.clone(), qk: qk.clone() }))
                                }))
                            }) as Rc<dyn Fn((Text, bool)) -> Rc<dyn prism_rtl::Job<crate::lower::model::ProgDef>>>
                        }), move |each_3109: Array<crate::lower::model::ProgDef>| {
                            let programs = each_3109;
                            let main_qk = fold(&g.defs, &Text::lit(""), &(|found: &Text, d: &crate::check::env::Def| if (found == &Text::lit("")) && is_main(&d.qk) { d.qk.clone() } else { found.clone() }));
                            let root_opt = if &main_qk == &Text::lit("") { None } else { Some(prog_def_of(&lx, &main_qk)) };
                            call_value(fold_job(g.defs.clone(), Array::new(), {
                                let lx = lx.clone();
                                Rc::new(move |(p0, p1): (Array<crate::lower::model::CheckDef>, crate::check::env::Def)| {
                                    let lx = lx.clone();
                                    entered(once_job(move || {
                                        let acc = p0;
                                        let d = p1;
                                        match &d.body {
                                            crate::check::env::DefBody::DbCheck(c) => {
                                                let c = c.clone();
                                                call_then(start_check_def_of(in_module_at(&lx, &d.file, &d.home, &Text::lit("\0main")), c.clone()), move |check_def_of_3411: crate::lower::model::CheckDef| prism_rtl::Turn::Finished(push(&acc, &check_def_of_3411)))
                                            },
                                            _ => prism_rtl::Turn::Finished(acc.clone()),
                                        }
                                    }))
                                }) as Rc<dyn Fn((Array<crate::lower::model::CheckDef>, crate::check::env::Def)) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::CheckDef>>>>
                            }), move |fold_3338: Array<crate::lower::model::CheckDef>| {
                                let checks = fold_3338;
                                call_then(start_with_needs(g.clone(), srcs.clone(), tp.clone(), mod_defs.clone()), move |with_needs_3526: Array<crate::lower::model::ModDef>| call_then(start_with_groups(with_needs_3526), move |with_groups_3514: Array<crate::lower::model::ModDef>| {
                                    let with_needs_ = with_groups_3514;
                                    call_then(start_elem_row(lx.clone(), mods.clone()), move |elem_row_3573: crate::lower::model::RowDef| {
                                        let elem = elem_row_3573;
                                        call_then(start_answer_enum(in_module_at(&lx, &Nat::from(0u32), &Text::lit(""), &Text::lit("\0main")), mods.clone()), move |answer_enum_3607: crate::lower::model::AnswerDef| {
                                            let answer = answer_enum_3607;
                                            let names = each(&with_needs_, &(|d: &crate::lower::model::ModDef| d.name.clone()));
                                            let value_tys = value_types(&with_needs_);
                                            let elem_held = fold(&elem.cases, &Array::new(), &(|acc: &Array<Text>, (_, sp): &(Text, Text)| crate::check::types::union_texts(acc, &held_in(&names, &value_tys, &Text::lit(""), &crate::lower::model::OutTy::OutNamed(sp.clone(), Array::new())))));
                                            let answer_held = fold(&answer.cases, &elem_held, &(|acc: &Array<Text>, k: &crate::lower::model::AnswerCase| crate::check::types::union_texts(acc, &held_in(&names, &value_tys, &Text::lit(""), &k.ty))));
                                            let answer_named = fold(&answer.cases, &Array::new(), &(|acc: &Array<Text>, k: &crate::lower::model::AnswerCase| crate::check::types::union_texts(acc, &named_in(&names, &Text::lit(""), &k.ty))));
                                            prism_rtl::Turn::Finished(crate::lower::model::Model { name: name.clone(), mods: with_needs_.clone(), programs: programs.clone(), root: root_opt.clone(), checks: checks.clone(), elem: elem.clone(), answer: answer.clone(), elem_complete: answer_held.clone(), elem_declared: crate::check::types::minus_texts(&answer_named, &answer_held), scripts: Array::new(), notes: Array::new() })
                                        })
                                    })
                                }))
                            })
                        })
                    })
                })
            })
        })
    }
}

/// `Start LowerProgram, x`: what the function value is when passed to `@Run`.
pub fn start_lower_program(srcs: Array<crate::check::errors::Src>, trees: Array<crate::syntax::Module>, shown: Nat, tp: crate::check::typed::TProgram, name: Text) -> Rc<dyn prism_rtl::Job<crate::lower::model::Model>> {
    Rc::new(LowerProgram { srcs, trees, shown, tp, name })
}

/// ```prism
/// WithNeeds: unbounded fn G, [Src], TProgram, [ModDef] -> [ModDef]
/// ```
pub fn with_needs(g: &crate::check::env::G, srcs: &Array<crate::check::errors::Src>, tp: &crate::check::typed::TProgram, defs: &Array<crate::lower::model::ModDef>) -> Array<crate::lower::model::ModDef> {
    let names = each(defs, &(|d: &crate::lower::model::ModDef| d.name.clone()));
    let value_tys = value_types(defs);
    let refs = named_mods(g, srcs, tp, &each(defs, &(|d: &crate::lower::model::ModDef| d.prism.clone())));
    run_to_end(each_job(defs.clone(), {
        let names = names.clone();
        let value_tys = value_tys.clone();
        let refs = refs.clone();
        Rc::new(move |p0: crate::lower::model::ModDef| {
            let names = names.clone();
            let value_tys = value_tys.clone();
            let refs = refs.clone();
            entered(once_job(move || {
                let d = p0;
                {
                    let held = fold(&d.items, &Array::new(), &(|acc: &Array<Text>, it: &crate::lower::model::Item| crate::check::types::union_texts(acc, &item_held(&names, &value_tys, &d.name, it))));
                    let complete = filter(&held, &(|n: &Text| n != &d.name));
                    call_then(start_reached_by(refs.clone(), Array::from(vec![d.prism.clone()]), Array::new()), move |reached_by_4821: Array<Text>| {
                        let reached = each(&reached_by_4821, &(|m: &Text| crate::lower::rust_mod_name(m)));
                        let declared = filter(&names, &(|n: &Text| ((n != &d.name) && crate::check::types::has_text(&reached, n)) && !crate::check::types::has_text(&complete, n)));
                        prism_rtl::Turn::Finished({
                            let mut this: crate::lower::model::ModDef = d.clone();
                            this.complete = complete.clone();
                            this.declared = declared.clone();
                            this
                        })
                    })
                }
            }))
        }) as Rc<dyn Fn(crate::lower::model::ModDef) -> Rc<dyn prism_rtl::Job<crate::lower::model::ModDef>>>
    }))
}

/// The step machine of `WithNeeds`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// WithNeeds: unbounded fn G, [Src], TProgram, [ModDef] -> [ModDef]
/// ```
pub struct WithNeeds {
    pub g: crate::check::env::G,
    pub srcs: Array<crate::check::errors::Src>,
    pub tp: crate::check::typed::TProgram,
    pub defs: Array<crate::lower::model::ModDef>,
}

impl prism_rtl::Job<Array<crate::lower::model::ModDef>> for WithNeeds {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::lower::model::ModDef>> {
        let g = &self.g;
        let srcs = &self.srcs;
        let tp = &self.tp;
        let defs = &self.defs;
        let names = each(defs, &(|d: &crate::lower::model::ModDef| d.name.clone()));
        let value_tys = value_types(defs);
        let defs = defs.clone();
        let g = g.clone();
        let srcs = srcs.clone();
        let tp = tp.clone();
        call_then(start_named_mods(g.clone(), srcs.clone(), tp.clone(), each(&defs, &(|d: &crate::lower::model::ModDef| d.prism.clone()))), move |named_mods_4566: Map<Text, Array<Text>>| {
            let refs = named_mods_4566;
            each_job(defs.clone(), {
                let names = names.clone();
                let value_tys = value_tys.clone();
                let refs = refs.clone();
                Rc::new(move |p0: crate::lower::model::ModDef| {
                    let names = names.clone();
                    let value_tys = value_tys.clone();
                    let refs = refs.clone();
                    entered(once_job(move || {
                        let d = p0;
                        {
                            let held = fold(&d.items, &Array::new(), &(|acc: &Array<Text>, it: &crate::lower::model::Item| crate::check::types::union_texts(acc, &item_held(&names, &value_tys, &d.name, it))));
                            let complete = filter(&held, &(|n: &Text| n != &d.name));
                            call_then(start_reached_by(refs.clone(), Array::from(vec![d.prism.clone()]), Array::new()), move |reached_by_4821: Array<Text>| {
                                let reached = each(&reached_by_4821, &(|m: &Text| crate::lower::rust_mod_name(m)));
                                let declared = filter(&names, &(|n: &Text| ((n != &d.name) && crate::check::types::has_text(&reached, n)) && !crate::check::types::has_text(&complete, n)));
                                prism_rtl::Turn::Finished({
                                    let mut this: crate::lower::model::ModDef = d.clone();
                                    this.complete = complete.clone();
                                    this.declared = declared.clone();
                                    this
                                })
                            })
                        }
                    }))
                }) as Rc<dyn Fn(crate::lower::model::ModDef) -> Rc<dyn prism_rtl::Job<crate::lower::model::ModDef>>>
            }).cycle()
        })
    }
}

/// `Start WithNeeds, x`: what the function value is when passed to `@Run`.
pub fn start_with_needs(g: crate::check::env::G, srcs: Array<crate::check::errors::Src>, tp: crate::check::typed::TProgram, defs: Array<crate::lower::model::ModDef>) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::ModDef>>> {
    Rc::new(WithNeeds { g, srcs, tp, defs })
}

/// ```prism
/// NamedMods: unbounded fn G, [Src], TProgram, [Text] -> (Text ==> [Text])
/// ```
pub fn named_mods(g: &crate::check::env::G, srcs: &Array<crate::check::errors::Src>, tp: &crate::check::typed::TProgram, ms: &Array<Text>) -> Map<Text, Array<Text>> {
    let by_path = fold(&values(&g.mods), &Map::new(), &(|acc: &Map<Text, Text>, info: &crate::check::env::ModInfo| insert(acc, &or(&index(srcs, &info.file), &crate::check::errors::mk_src(&Text::lit(""), &Text::lit(""))).path_, &info.name)));
    let by_file = fold(&values(&g.mods), &Map::new(), &(|acc: &Map<Nat, Text>, info: &crate::check::env::ModInfo| insert(acc, &info.file, &info.name)));
    let solved = fold(&tp.impls, &Map::new(), &(|acc: &Map<Text, Array<Text>>, n: &crate::check::typed::ImplNote| match get(&by_file, &n.at.file) {
        Some(site) => match get(&by_path, &impl_path(&n.how)) {
            Some(home) => if (&home == &site) || crate::check::types::has_text(&or(&get(acc, &site), &Array::new()), &home) {
                acc.clone()
            } else {
                insert(acc, &site, &push(&or(&get(acc, &site), &Array::new()), &home))
            },
            None => acc.clone(),
        },
        None => acc.clone(),
    }));
    run_to_end(fold_job(ms.clone(), Map::new(), {
        let g = g.clone();
        let srcs = srcs.clone();
        let ms = ms.clone();
        let solved = solved.clone();
        Rc::new(move |(p0, p1): (Map<Text, Array<Text>>, Text)| {
            let g = g.clone();
            let srcs = srcs.clone();
            let ms = ms.clone();
            let solved = solved.clone();
            entered(once_job(move || {
                let acc = p0;
                let m = p1;
                match get(&g.mods, &m) {
                    Some(info) => {
                        let code = crate::syntax::lexer::chars::join(&filter(&split(&or(&index(&srcs, &info.file), &crate::check::errors::mk_src(&Text::lit(""), &Text::lit(""))).text, &Text::lit("\n")), &(|l: &Text| !crate::syntax::lexer::chars::has_prefix(&crate::syntax::lexer::chars::trim_start(l), &Text::lit("#")))), &Text::lit("\n"));
                        let qualified = filter(&ms, &(|o: &Text| ((o != &m) && (o != &Text::lit(""))) && crate::syntax::lexer::chars::contains(&code, &Text::from(format!("{}.", o)))));
                        call_then(start_mod_refs(g.clone(), m.clone()), move |mod_refs_6468: Array<Text>| prism_rtl::Turn::Finished(insert(&acc, &m, &crate::check::types::union_texts(&crate::check::types::union_texts(&mod_refs_6468, &qualified), &or(&get(&solved, &m), &Array::new())))))
                    },
                    None => prism_rtl::Turn::Finished(acc.clone()),
                }
            }))
        }) as Rc<dyn Fn((Map<Text, Array<Text>>, Text)) -> Rc<dyn prism_rtl::Job<Map<Text, Array<Text>>>>>
    }))
}

/// The step machine of `NamedMods`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// NamedMods: unbounded fn G, [Src], TProgram, [Text] -> (Text ==> [Text])
/// ```
pub struct NamedMods {
    pub g: crate::check::env::G,
    pub srcs: Array<crate::check::errors::Src>,
    pub tp: crate::check::typed::TProgram,
    pub ms: Array<Text>,
}

impl prism_rtl::Job<Map<Text, Array<Text>>> for NamedMods {
    fn cycle(&self) -> prism_rtl::Turn<Map<Text, Array<Text>>> {
        let g = &self.g;
        let srcs = &self.srcs;
        let tp = &self.tp;
        let ms = &self.ms;
        let by_path = fold(&values(&g.mods), &Map::new(), &(|acc: &Map<Text, Text>, info: &crate::check::env::ModInfo| insert(acc, &or(&index(srcs, &info.file), &crate::check::errors::mk_src(&Text::lit(""), &Text::lit(""))).path_, &info.name)));
        let by_file = fold(&values(&g.mods), &Map::new(), &(|acc: &Map<Nat, Text>, info: &crate::check::env::ModInfo| insert(acc, &info.file, &info.name)));
        let solved = fold(&tp.impls, &Map::new(), &(|acc: &Map<Text, Array<Text>>, n: &crate::check::typed::ImplNote| match get(&by_file, &n.at.file) {
            Some(site) => match get(&by_path, &impl_path(&n.how)) {
                Some(home) => if (&home == &site) || crate::check::types::has_text(&or(&get(acc, &site), &Array::new()), &home) {
                    acc.clone()
                } else {
                    insert(acc, &site, &push(&or(&get(acc, &site), &Array::new()), &home))
                },
                None => acc.clone(),
            },
            None => acc.clone(),
        }));
        fold_job(ms.clone(), Map::new(), {
            let g = g.clone();
            let srcs = srcs.clone();
            let ms = ms.clone();
            let solved = solved.clone();
            Rc::new(move |(p0, p1): (Map<Text, Array<Text>>, Text)| {
                let g = g.clone();
                let srcs = srcs.clone();
                let ms = ms.clone();
                let solved = solved.clone();
                entered(once_job(move || {
                    let acc = p0;
                    let m = p1;
                    match get(&g.mods, &m) {
                        Some(info) => {
                            let code = crate::syntax::lexer::chars::join(&filter(&split(&or(&index(&srcs, &info.file), &crate::check::errors::mk_src(&Text::lit(""), &Text::lit(""))).text, &Text::lit("\n")), &(|l: &Text| !crate::syntax::lexer::chars::has_prefix(&crate::syntax::lexer::chars::trim_start(l), &Text::lit("#")))), &Text::lit("\n"));
                            let qualified = filter(&ms, &(|o: &Text| ((o != &m) && (o != &Text::lit(""))) && crate::syntax::lexer::chars::contains(&code, &Text::from(format!("{}.", o)))));
                            call_then(start_mod_refs(g.clone(), m.clone()), move |mod_refs_6468: Array<Text>| prism_rtl::Turn::Finished(insert(&acc, &m, &crate::check::types::union_texts(&crate::check::types::union_texts(&mod_refs_6468, &qualified), &or(&get(&solved, &m), &Array::new())))))
                        },
                        None => prism_rtl::Turn::Finished(acc.clone()),
                    }
                }))
            }) as Rc<dyn Fn((Map<Text, Array<Text>>, Text)) -> Rc<dyn prism_rtl::Job<Map<Text, Array<Text>>>>>
        }).cycle()
    }
}

/// `Start NamedMods, x`: what the function value is when passed to `@Run`.
pub fn start_named_mods(g: crate::check::env::G, srcs: Array<crate::check::errors::Src>, tp: crate::check::typed::TProgram, ms: Array<Text>) -> Rc<dyn prism_rtl::Job<Map<Text, Array<Text>>>> {
    Rc::new(NamedMods { g, srcs, tp, ms })
}

/// ```prism
/// ImplPath: fn Text -> Text
/// ```
pub fn impl_path(how: &Text) -> Text {
    let rest = or(&crate::syntax::lexer::chars::after_prefix(how, &Text::lit("impl ")), &or(&crate::syntax::lexer::chars::after_prefix(how, &Text::lit("derived ")), &Text::lit("")));
    let parts = split(&rest, &Text::lit(":"));
    crate::syntax::lexer::chars::join(&take(&parts, &crate::syntax::lexer::chars::dec(&len(&parts))), &Text::lit(":"))
}

/// ```prism
/// ValueTypes: fn [ModDef] -> (Text ==> Bool)
/// ```
pub fn value_types(defs: &Array<crate::lower::model::ModDef>) -> Map<Text, bool> {
    fold(defs, &Map::new(), &(|acc: &Map<Text, bool>, d: &crate::lower::model::ModDef| fold(&d.items, acc, &(|a: &Map<Text, bool>, it: &crate::lower::model::Item| match it {
        crate::lower::model::Item::ItType(t) => match &t.shape {
            crate::lower::model::TyShape::ShapeChoice => a.clone(),
            _ => insert(a, &Text::from(format!("{}::{}", &d.name, &t.name)), &true),
        },
        crate::lower::model::Item::ItTag(t) => insert(a, &Text::from(format!("{}::{}", &d.name, &t.name)), &true),
        _ => a.clone(),
    }))))
}

/// ```prism
/// ItemHeld: fn [Text], (Text ==> Bool), Text, Item -> [Text]
/// ```
pub fn item_held(names: &Array<Text>, value_tys: &Map<Text, bool>, home: &Text, it: &crate::lower::model::Item) -> Array<Text> {
    match it {
        crate::lower::model::Item::ItType(t) => fold(&t.cases, &Array::new(), &(|acc: &Array<Text>, c: &crate::lower::model::CaseDef| fold(&c.fields, acc, &(|a: &Array<Text>, (_, ft): &(Text, crate::lower::model::OutTy)| crate::check::types::union_texts(a, &held_in(names, value_tys, home, ft)))))),
        crate::lower::model::Item::ItTag(t) => fold(&t.fields, &Array::new(), &(|acc: &Array<Text>, (_, _, ft): &(Text, Text, crate::lower::model::OutTy)| crate::check::types::union_texts(acc, &held_in(names, value_tys, home, ft)))),
        crate::lower::model::Item::ItRow(r) => fold(&r.cases, &Array::new(), &(|acc: &Array<Text>, (_, sp): &(Text, Text)| crate::check::types::union_texts(acc, &held_in(names, value_tys, home, &crate::lower::model::OutTy::OutNamed(sp.clone(), Array::new()))))),
        _ => Array::new(),
    }
}

/// ```prism
/// HeldIn: fn [Text], (Text ==> Bool), Text, OutTy -> [Text]
/// ```
pub fn held_in(names: &Array<Text>, value_tys: &Map<Text, bool>, home: &Text, t: &crate::lower::model::OutTy) -> Array<Text> {
    match t {
        crate::lower::model::OutTy::OutNamed(n, args) => {
            let p_ = path_from(names, home, n);
            let own = if crate::check::env::has_key(value_tys, &p_) {
                Array::from(vec![parent_of(&p_)])
            } else {
                Array::new()
            };
            fold(args, &own, &(|acc: &Array<Text>, a: &crate::lower::model::OutTy| crate::check::types::union_texts(acc, &held_in(names, value_tys, home, a))))
        },
        crate::lower::model::OutTy::OutOpt(i) => held_in(names, value_tys, home, &**i),
        crate::lower::model::OutTy::OutRes(i) => held_in(names, value_tys, home, &**i),
        crate::lower::model::OutTy::OutCell(i) => held_in(names, value_tys, home, &**i),
        crate::lower::model::OutTy::OutRc(i) => held_in(names, value_tys, home, &**i),
        crate::lower::model::OutTy::OutTuple(ts) => fold(ts, &Array::new(), &(|acc: &Array<Text>, a: &crate::lower::model::OutTy| crate::check::types::union_texts(acc, &held_in(names, value_tys, home, a)))),
        _ => Array::new(),
    }
}

/// ```prism
/// NamedIn: fn [Text], Text, OutTy -> [Text]
/// ```
pub fn named_in(names: &Array<Text>, home: &Text, t: &crate::lower::model::OutTy) -> Array<Text> {
    match t {
        crate::lower::model::OutTy::OutNamed(n, args) => {
            let p_ = path_from(names, home, n);
            let own = if crate::check::types::has_text(names, &parent_of(&p_)) {
                Array::from(vec![parent_of(&p_)])
            } else {
                Array::new()
            };
            fold(args, &own, &(|acc: &Array<Text>, a: &crate::lower::model::OutTy| crate::check::types::union_texts(acc, &named_in(names, home, a))))
        },
        crate::lower::model::OutTy::OutOpt(i) => named_in(names, home, &**i),
        crate::lower::model::OutTy::OutRes(i) => named_in(names, home, &**i),
        crate::lower::model::OutTy::OutCell(i) => named_in(names, home, &**i),
        crate::lower::model::OutTy::OutArray(i) => named_in(names, home, &**i),
        crate::lower::model::OutTy::OutRc(i) => named_in(names, home, &**i),
        crate::lower::model::OutTy::OutEvent(i) => named_in(names, home, &**i),
        crate::lower::model::OutTy::OutDyn(i) => named_in(names, home, &**i),
        crate::lower::model::OutTy::OutMap(k, v_) => crate::check::types::union_texts(&named_in(names, home, &**k), &named_in(names, home, &**v_)),
        crate::lower::model::OutTy::OutTuple(ts) => fold(ts, &Array::new(), &(|acc: &Array<Text>, a: &crate::lower::model::OutTy| crate::check::types::union_texts(acc, &named_in(names, home, a)))),
        crate::lower::model::OutTy::OutFn(ps, r) => fold(ps, &named_in(names, home, &**r), &(|acc: &Array<Text>, a: &crate::lower::model::OutTy| crate::check::types::union_texts(acc, &named_in(names, home, a)))),
        _ => Array::new(),
    }
}

/// ```prism
/// PathFrom: fn [Text], Text, Text -> Text
/// ```
pub fn path_from(names: &Array<Text>, home: &Text, n: &Text) -> Text {
    let q = crate::syntax::lexer::chars::drop_prefix(n, &Text::lit("crate::"));
    if starts_with_module(names, &q) {
        q.clone()
    } else {
        if home == &Text::lit("") {
            q.clone()
        } else {
            Text::from(format!("{}::{}", home, &q))
        }
    }
}

/// ```prism
/// StartsWithModule: fn [Text], Text -> Bool
/// ```
pub fn starts_with_module(names: &Array<Text>, q: &Text) -> bool {
    fold(names, &false, &(|f: &bool, n: &Text| *f || ((n != &Text::lit("")) && crate::syntax::lexer::chars::has_prefix(q, &Text::from(format!("{}::", n))))))
}

/// ```prism
/// ParentOf: fn Text -> Text
/// ```
pub fn parent_of(p_: &Text) -> Text {
    let segs = split(p_, &Text::lit("::"));
    crate::syntax::lexer::chars::join(&take(&segs, &crate::syntax::lexer::chars::dec(&len(&segs))), &Text::lit("::"))
}

/// ```prism
/// WithGroups: unbounded fn [ModDef] -> [ModDef]
/// ```
pub fn with_groups(defs: &Array<crate::lower::model::ModDef>) -> Array<crate::lower::model::ModDef> {
    let edges = fold(defs, &Map::new(), &(|m: &Map<Text, Array<Text>>, d: &crate::lower::model::ModDef| insert(m, &d.name, &d.complete)));
    let reach = run_to_end(fold_job(defs.clone(), Map::new(), {
        let edges = edges.clone();
        Rc::new(move |(p0, p1): (Map<Text, Array<Text>>, crate::lower::model::ModDef)| {
            let edges = edges.clone();
            entered(once_job(move || {
                let m = p0;
                let d = p1;
                call_then(start_reached_by(edges.clone(), Array::from(vec![d.name.clone()]), Array::new()), move |reached_by_10754: Array<Text>| prism_rtl::Turn::Finished(insert(&m, &d.name, &reached_by_10754)))
            }))
        }) as Rc<dyn Fn((Map<Text, Array<Text>>, crate::lower::model::ModDef)) -> Rc<dyn prism_rtl::Job<Map<Text, Array<Text>>>>>
    }));
    each(defs, &(|d: &crate::lower::model::ModDef| {
        let mine = or(&get(&reach, &d.name), &Array::new());
        {
            let mut this: crate::lower::model::ModDef = d.clone();
            this.types_with = filter(&each(defs, &(|o: &crate::lower::model::ModDef| o.name.clone())), &(|n: &Text| (n == &d.name) || (crate::check::types::has_text(&mine, n) && crate::check::types::has_text(&or(&get(&reach, n), &Array::new()), &d.name))));
            this
        }
    }))
}

/// The step machine of `WithGroups`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// WithGroups: unbounded fn [ModDef] -> [ModDef]
/// ```
pub struct WithGroups {
    pub defs: Array<crate::lower::model::ModDef>,
}

impl prism_rtl::Job<Array<crate::lower::model::ModDef>> for WithGroups {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::lower::model::ModDef>> {
        let defs = &self.defs;
        let edges = fold(defs, &Map::new(), &(|m: &Map<Text, Array<Text>>, d: &crate::lower::model::ModDef| insert(m, &d.name, &d.complete)));
        let defs = defs.clone();
        call_value(fold_job(defs.clone(), Map::new(), {
            let edges = edges.clone();
            Rc::new(move |(p0, p1): (Map<Text, Array<Text>>, crate::lower::model::ModDef)| {
                let edges = edges.clone();
                entered(once_job(move || {
                    let m = p0;
                    let d = p1;
                    call_then(start_reached_by(edges.clone(), Array::from(vec![d.name.clone()]), Array::new()), move |reached_by_10754: Array<Text>| prism_rtl::Turn::Finished(insert(&m, &d.name, &reached_by_10754)))
                }))
            }) as Rc<dyn Fn((Map<Text, Array<Text>>, crate::lower::model::ModDef)) -> Rc<dyn prism_rtl::Job<Map<Text, Array<Text>>>>>
        }), move |fold_10712: Map<Text, Array<Text>>| {
            let reach = fold_10712;
            prism_rtl::Turn::Finished(each(&defs, &(|d: &crate::lower::model::ModDef| {
                let mine = or(&get(&reach, &d.name), &Array::new());
                {
                    let mut this: crate::lower::model::ModDef = d.clone();
                    this.types_with = filter(&each(&defs, &(|o: &crate::lower::model::ModDef| o.name.clone())), &(|n: &Text| (n == &d.name) || (crate::check::types::has_text(&mine, n) && crate::check::types::has_text(&or(&get(&reach, n), &Array::new()), &d.name))));
                    this
                }
            })))
        })
    }
}

/// `Start WithGroups, x`: what the function value is when passed to `@Run`.
pub fn start_with_groups(defs: Array<crate::lower::model::ModDef>) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::ModDef>>> {
    Rc::new(WithGroups { defs })
}

/// ```prism
/// ReachedBy: unbounded fn (Text ==> [Text]), [Text], [Text] -> [Text]
/// ```
pub fn reached_by(edges: &Map<Text, Array<Text>>, todo: &Array<Text>, seen: &Array<Text>) -> Array<Text> {
    match index(todo, &Nat::from(0u32)) {
        None => seen.clone(),
        Some(m) => if crate::check::types::has_text(seen, &m) {
            reached_by(edges, &drop(todo, &Nat::from(1u32)), seen)
        } else {
            reached_by(edges, &append(&drop(todo, &Nat::from(1u32)), &or(&get(edges, &m), &Array::new())), &push(seen, &m))
        },
    }
}

/// The step machine of `ReachedBy`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ReachedBy: unbounded fn (Text ==> [Text]), [Text], [Text] -> [Text]
/// ```
pub struct ReachedBy {
    pub edges: Map<Text, Array<Text>>,
    pub todo: Array<Text>,
    pub seen: Array<Text>,
}

impl prism_rtl::Job<Array<Text>> for ReachedBy {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let edges = &self.edges;
        let todo = &self.todo;
        let seen = &self.seen;
        match index(todo, &Nat::from(0u32)) {
            None => prism_rtl::Turn::Finished(seen.clone()),
            Some(m) => if crate::check::types::has_text(seen, &m) {
                prism_rtl::Turn::More(Rc::new(ReachedBy { edges: edges.clone(), todo: drop(todo, &Nat::from(1u32)), seen: seen.clone() }))
            } else {
                prism_rtl::Turn::More(Rc::new(ReachedBy { edges: edges.clone(), todo: append(&drop(todo, &Nat::from(1u32)), &or(&get(edges, &m), &Array::new())), seen: push(seen, &m) }))
            },
        }
    }
}

/// `Start ReachedBy, x`: what the function value is when passed to `@Run`.
pub fn start_reached_by(edges: Map<Text, Array<Text>>, todo: Array<Text>, seen: Array<Text>) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(ReachedBy { edges, todo, seen })
}

/// ```prism
/// NeededMods: unbounded fn G, Nat -> [Text]
/// ```
pub fn needed_mods(g: &crate::check::env::G, shown: &Nat) -> Array<Text> {
    let own = filter(&keys(&g.mods), &(|m: &Text| (&or(&get(&g.mods, m), &crate::check::env::reading::dummy_mod()).file < shown) && (m != &Text::lit("Prelude"))));
    let grown = run_to_end(fold_job(crate::check::errors::range0(&Nat::from(6u32)), own.clone(), {
        let g = g.clone();
        Rc::new(move |(p0, p1): (Array<Text>, Nat)| {
            let g = g.clone();
            entered(once_job(move || {
                let acc = p0;
                let _ = p1;
                fold_job(acc.clone(), acc.clone(), {
                    let g = g.clone();
                    Rc::new(move |(p0, p1): (Array<Text>, Text)| {
                        let g = g.clone();
                        entered(once_job(move || {
                            let a = p0;
                            let m = p1;
                            call_then(start_mod_refs(g.clone(), m.clone()), move |mod_refs_11777: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&a, &mod_refs_11777)))
                        }))
                    }) as Rc<dyn Fn((Array<Text>, Text)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
                }).cycle()
            }))
        }) as Rc<dyn Fn((Array<Text>, Nat)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
    }));
    filter(&keys(&g.mods), &(|m: &Text| (m != &Text::lit("Prelude")) && crate::check::types::has_text(&grown, m)))
}

/// The step machine of `NeededMods`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// NeededMods: unbounded fn G, Nat -> [Text]
/// ```
pub struct NeededMods {
    pub g: crate::check::env::G,
    pub shown: Nat,
}

impl prism_rtl::Job<Array<Text>> for NeededMods {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let g = &self.g;
        let shown = &self.shown;
        let own = filter(&keys(&g.mods), &(|m: &Text| (&or(&get(&g.mods, m), &crate::check::env::reading::dummy_mod()).file < shown) && (m != &Text::lit("Prelude"))));
        let g = g.clone();
        call_value(fold_job(crate::check::errors::range0(&Nat::from(6u32)), own.clone(), {
            let g = g.clone();
            Rc::new(move |(p0, p1): (Array<Text>, Nat)| {
                let g = g.clone();
                entered(once_job(move || {
                    let acc = p0;
                    let _ = p1;
                    fold_job(acc.clone(), acc.clone(), {
                        let g = g.clone();
                        Rc::new(move |(p0, p1): (Array<Text>, Text)| {
                            let g = g.clone();
                            entered(once_job(move || {
                                let a = p0;
                                let m = p1;
                                call_then(start_mod_refs(g.clone(), m.clone()), move |mod_refs_11777: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&a, &mod_refs_11777)))
                            }))
                        }) as Rc<dyn Fn((Array<Text>, Text)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
                    }).cycle()
                }))
            }) as Rc<dyn Fn((Array<Text>, Nat)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
        }), move |fold_11702: Array<Text>| {
            let grown = fold_11702;
            prism_rtl::Turn::Finished(filter(&keys(&g.mods), &(|m: &Text| (m != &Text::lit("Prelude")) && crate::check::types::has_text(&grown, m))))
        })
    }
}

/// `Start NeededMods, x`: what the function value is when passed to `@Run`.
pub fn start_needed_mods(g: crate::check::env::G, shown: Nat) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(NeededMods { g, shown })
}

/// ```prism
/// ModRefs: unbounded fn G, Text -> [Text]
/// ```
pub fn mod_refs(g: &crate::check::env::G, m: &Text) -> Array<Text> {
    match get(&g.mods, m) {
        Some(info) => {
            let used = each(&info.uses, &(|(u, _): &(Text, bool)| u.clone()));
            let fams = match &info.tree.emit_row {
                Some(rw) => fold(&rw.terms, &Array::new(), &(|acc: &Array<Text>, t: &crate::syntax::RowTerm| match t {
                    crate::syntax::RowTerm::RFamily(q) => push(acc, &or(&get(&g.fam_owner, &crate::check::env::dotted(&q.path_)), &crate::check::env::dotted(&q.path_))),
                    _ => acc.clone(),
                })),
                None => Array::new(),
            };
            filter(&append(&used, &fams), &(|x: &Text| crate::check::env::has_key(&g.mods, x)))
        },
        None => Array::new(),
    }
}

/// The step machine of `ModRefs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ModRefs: unbounded fn G, Text -> [Text]
/// ```
pub struct ModRefs {
    pub g: crate::check::env::G,
    pub m: Text,
}

impl prism_rtl::Job<Array<Text>> for ModRefs {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let g = &self.g;
        let m = &self.m;
        match get(&g.mods, m) {
            Some(info) => {
                let used = each(&info.uses, &(|(u, _): &(Text, bool)| u.clone()));
                let fams = match &info.tree.emit_row {
                    Some(rw) => fold(&rw.terms, &Array::new(), &(|acc: &Array<Text>, t: &crate::syntax::RowTerm| match t {
                        crate::syntax::RowTerm::RFamily(q) => push(acc, &or(&get(&g.fam_owner, &crate::check::env::dotted(&q.path_)), &crate::check::env::dotted(&q.path_))),
                        _ => acc.clone(),
                    })),
                    None => Array::new(),
                };
                prism_rtl::Turn::Finished(filter(&append(&used, &fams), &(|x: &Text| crate::check::env::has_key(&g.mods, x))))
            },
            None => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start ModRefs, x`: what the function value is when passed to `@Run`.
pub fn start_mod_refs(g: crate::check::env::G, m: Text) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(ModRefs { g, m })
}

/// ```prism
/// RootWidgets: fn Lx -> [((Text, Bool))]
/// ```
pub fn root_widgets(lx: &crate::lower::Lx) -> Array<(Text, bool)> {
    let tested = fold(&lx.g.defs, &Array::new(), &(|acc: &Array<(Text, bool)>, d: &crate::check::env::Def| match &d.body {
        crate::check::env::DefBody::DbTest(t) => match blueprint_qk(&in_module(lx, &d.file, &d.home), &t.blueprint) {
            m12531_0 if (&m12531_0 == &Text::lit("")) => acc.clone(),
            qk => if crate::check::types::has_text(&each(acc, &(|(q, _): &(Text, bool)| q.clone())), &qk) {
                acc.clone()
            } else {
                push(acc, &(qk.clone(), true))
            },
            _ => unreachable!("no arm matched"),
        },
        _ => acc.clone(),
    }));
    let main = fold(&lx.g.defs, &Array::new(), &(|acc: &Array<(Text, bool)>, d: &crate::check::env::Def| if is_main(&d.qk) { push(acc, &(d.qk.clone(), false)) } else { acc.clone() }));
    fold(&main, &tested, &(|acc: &Array<(Text, bool)>, (k, b): &(Text, bool)| if crate::check::types::has_text(&each(acc, &(|(q, _): &(Text, bool)| q.clone())), k) {
        acc.clone()
    } else {
        push(acc, &(k.clone(), *b))
    }))
}

/// ```prism
/// IsMain: fn Text -> Bool
/// ```
pub fn is_main(qk: &Text) -> bool {
    ((&crate::lower::owner_of(qk) == &Text::lit("")) && (&crate::lower::base(&crate::check::types::bare_name(qk)) == &Text::lit("main"))) && crate::syntax::lexer::chars::has_prefix(&crate::check::types::bare_name(qk), &Text::lit("@"))
}

/// ```prism
/// BlueprintQk: fn Lx, Expr -> Text
/// ```
pub fn blueprint_qk(lx: &crate::lower::Lx, e: &crate::syntax::Expr) -> Text {
    match &*e.kind {
        crate::syntax::ExprKind::ECall(c, _, _, _) => blueprint_qk(lx, &**c),
        crate::syntax::ExprKind::EGroup(x) => blueprint_qk(lx, &**x),
        crate::syntax::ExprKind::EName(n) => {
            let (q_opt, _) = crate::check::env::names::resolve_value(&lx.g, &lx.home, n);
            or(&q_opt, &Text::lit(""))
        },
        _ => Text::lit(""),
    }
}

/// ```prism
/// ValOf: fn Lx, Text -> ValInfo
/// ```
pub fn val_of(lx: &crate::lower::Lx, qk: &Text) -> crate::check::env::ValInfo {
    match get(&lx.g.vals, qk) {
        Some(v_) => v_.clone(),
        None => {
            let d = fold(&lx.g.defs, &crate::check::env::decls::dummy_def(), &(|found: &crate::check::env::Def, df: &crate::check::env::Def| if &df.qk == qk { df.clone() } else { found.clone() }));
            crate::check::env::ValInfo { qk: qk.clone(), scheme: crate::check::types::schemes::mono(&crate::check::types::Ty::TyErr), sort: Text::lit("fn"), has_sig: false, home: d.home.clone(), file: d.file.clone(), span: d.span.clone() }
        },
    }
}

/// ```prism
/// ProgDefOf: unbounded fn Lx, Text -> ProgDef
/// ```
pub fn prog_def_of(lx: &crate::lower::Lx, qk: &Text) -> crate::lower::model::ProgDef {
    let v_ = val_of(lx, qk);
    let ptys = match &v_.scheme.ty {
        crate::check::types::Ty::TyFn(_, ps, _) => ps.clone(),
        _ => Array::new(),
    };
    let lxm = in_module_at(lx, &v_.file, &v_.home, &Text::lit("\0main"));
    let params = run_to_end(each_job(crate::check::errors::range0(&len(&ptys)), {
        let lxm = lxm.clone();
        let ptys = ptys.clone();
        Rc::new(move |p0: Nat| {
            let lxm = lxm.clone();
            let ptys = ptys.clone();
            entered(once_job(move || {
                let i = p0;
                call_then(crate::lower::types::start_out_ty_of(lxm.clone(), crate::lower::types::peel(&or(&index(&ptys, &i), &crate::check::types::Ty::TyErr))), move |out_ty_of_14106: crate::lower::model::OutTy| prism_rtl::Turn::Finished((Text::from(format!("arg{}", &i)), out_ty_of_14106)))
            }))
        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<(Text, crate::lower::model::OutTy)>>>
    }));
    let node_ = Text::from(format!("{}::{}", &crate::lower::rust_mod_name(&v_.home), &crate::lower::camel(&crate::check::types::bare_name(qk))));
    let fams = or(&get(&lx.g.mods, &v_.home), &crate::check::env::reading::dummy_mod()).emit_rw.fams.clone();
    let world = if crate::check::types::has_text(&fams, &Text::lit("Gui")) {
        Text::lit("canvas")
    } else {
        if crate::check::types::has_text(&fams, &Text::lit("Ui")) {
            Text::lit("none")
        } else {
            Text::lit("cli")
        }
    };
    crate::lower::model::ProgDef { name: Text::from(format!("{}Program", &crate::lower::camel(&crate::check::types::bare_name(qk)))), prism: crate::syntax::lexer::chars::after_first(&crate::check::types::bare_name(qk)), node_: node_.clone(), params: params.clone(), fallible: true, world: world.clone() }
}

/// The step machine of `ProgDefOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ProgDefOf: unbounded fn Lx, Text -> ProgDef
/// ```
pub struct ProgDefOf {
    pub lx: crate::lower::Lx,
    pub qk: Text,
}

impl prism_rtl::Job<crate::lower::model::ProgDef> for ProgDefOf {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::ProgDef> {
        let lx = &self.lx;
        let qk = &self.qk;
        let v_ = val_of(lx, qk);
        let ptys = match &v_.scheme.ty {
            crate::check::types::Ty::TyFn(_, ps, _) => ps.clone(),
            _ => Array::new(),
        };
        let lxm = in_module_at(lx, &v_.file, &v_.home, &Text::lit("\0main"));
        let lx = lx.clone();
        let qk = qk.clone();
        call_value(each_job(crate::check::errors::range0(&len(&ptys)), {
            let lxm = lxm.clone();
            let ptys = ptys.clone();
            Rc::new(move |p0: Nat| {
                let lxm = lxm.clone();
                let ptys = ptys.clone();
                entered(once_job(move || {
                    let i = p0;
                    call_then(crate::lower::types::start_out_ty_of(lxm.clone(), crate::lower::types::peel(&or(&index(&ptys, &i), &crate::check::types::Ty::TyErr))), move |out_ty_of_14106: crate::lower::model::OutTy| prism_rtl::Turn::Finished((Text::from(format!("arg{}", &i)), out_ty_of_14106)))
                }))
            }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<(Text, crate::lower::model::OutTy)>>>
        }), move |each_14062: Array<(Text, crate::lower::model::OutTy)>| {
            let params = each_14062;
            let node_ = Text::from(format!("{}::{}", &crate::lower::rust_mod_name(&v_.home), &crate::lower::camel(&crate::check::types::bare_name(&qk))));
            let fams = or(&get(&lx.g.mods, &v_.home), &crate::check::env::reading::dummy_mod()).emit_rw.fams.clone();
            let world = if crate::check::types::has_text(&fams, &Text::lit("Gui")) {
                Text::lit("canvas")
            } else {
                if crate::check::types::has_text(&fams, &Text::lit("Ui")) {
                    Text::lit("none")
                } else {
                    Text::lit("cli")
                }
            };
            prism_rtl::Turn::Finished(crate::lower::model::ProgDef { name: Text::from(format!("{}Program", &crate::lower::camel(&crate::check::types::bare_name(&qk)))), prism: crate::syntax::lexer::chars::after_first(&crate::check::types::bare_name(&qk)), node_: node_.clone(), params: params.clone(), fallible: true, world: world.clone() })
        })
    }
}

/// `Start ProgDefOf, x`: what the function value is when passed to `@Run`.
pub fn start_prog_def_of(lx: crate::lower::Lx, qk: Text) -> Rc<dyn prism_rtl::Job<crate::lower::model::ProgDef>> {
    Rc::new(ProgDefOf { lx, qk })
}

/// ```prism
/// JobRoots: unbounded fn Lx -> [Text]
/// ```
pub fn job_roots(lx: &crate::lower::Lx) -> Array<Text> {
    let direct = run_to_end(fold_job(lx.g.defs.clone(), Array::new(), {
        let lx = lx.clone();
        Rc::new(move |(p0, p1): (Array<Text>, crate::check::env::Def)| {
            let lx = lx.clone();
            entered(once_job(move || {
                let acc = p0;
                let d = p1;
                {
                    let lxd = in_module(&lx, &d.file, &d.home);
                    call_then(start_run_targets(lxd.clone(), d.clone()), move |run_targets_14941: Array<Text>| call_then(start_unbounded_values(lxd.clone(), d.clone()), move |unbounded_values_14963: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&crate::check::types::union_texts(&acc, &run_targets_14941), &unbounded_values_14963))))
                }
            }))
        }) as Rc<dyn Fn((Array<Text>, crate::check::env::Def)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
    }));
    run_to_end(fold_job(crate::check::errors::range0(&Nat::from(8u32)), direct.clone(), {
        let lx = lx.clone();
        Rc::new(move |(p0, p1): (Array<Text>, Nat)| {
            let lx = lx.clone();
            entered(once_job(move || {
                let acc = p0;
                let _ = p1;
                fold_job(acc.clone(), acc.clone(), {
                    let lx = lx.clone();
                    Rc::new(move |(p0, p1): (Array<Text>, Text)| {
                        let lx = lx.clone();
                        entered(once_job(move || {
                            let a = p0;
                            let qk = p1;
                            call_then(start_tail_targets(lx.clone(), qk.clone()), move |tail_targets_15070: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&a, &tail_targets_15070)))
                        }))
                    }) as Rc<dyn Fn((Array<Text>, Text)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
                }).cycle()
            }))
        }) as Rc<dyn Fn((Array<Text>, Nat)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
    }))
}

/// The step machine of `JobRoots`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// JobRoots: unbounded fn Lx -> [Text]
/// ```
pub struct JobRoots {
    pub lx: crate::lower::Lx,
}

impl prism_rtl::Job<Array<Text>> for JobRoots {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let lx = &self.lx;
        let lx = lx.clone();
        call_value(fold_job(lx.g.defs.clone(), Array::new(), {
            let lx = lx.clone();
            Rc::new(move |(p0, p1): (Array<Text>, crate::check::env::Def)| {
                let lx = lx.clone();
                entered(once_job(move || {
                    let acc = p0;
                    let d = p1;
                    {
                        let lxd = in_module(&lx, &d.file, &d.home);
                        call_then(start_run_targets(lxd.clone(), d.clone()), move |run_targets_14941: Array<Text>| call_then(start_unbounded_values(lxd.clone(), d.clone()), move |unbounded_values_14963: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&crate::check::types::union_texts(&acc, &run_targets_14941), &unbounded_values_14963))))
                    }
                }))
            }) as Rc<dyn Fn((Array<Text>, crate::check::env::Def)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
        }), move |fold_14826: Array<Text>| {
            let direct = fold_14826;
            fold_job(crate::check::errors::range0(&Nat::from(8u32)), direct.clone(), {
                let lx = lx.clone();
                Rc::new(move |(p0, p1): (Array<Text>, Nat)| {
                    let lx = lx.clone();
                    entered(once_job(move || {
                        let acc = p0;
                        let _ = p1;
                        fold_job(acc.clone(), acc.clone(), {
                            let lx = lx.clone();
                            Rc::new(move |(p0, p1): (Array<Text>, Text)| {
                                let lx = lx.clone();
                                entered(once_job(move || {
                                    let a = p0;
                                    let qk = p1;
                                    call_then(start_tail_targets(lx.clone(), qk.clone()), move |tail_targets_15070: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&a, &tail_targets_15070)))
                                }))
                            }) as Rc<dyn Fn((Array<Text>, Text)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
                        }).cycle()
                    }))
                }) as Rc<dyn Fn((Array<Text>, Nat)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
            }).cycle()
        })
    }
}

/// `Start JobRoots, x`: what the function value is when passed to `@Run`.
pub fn start_job_roots(lx: crate::lower::Lx) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(JobRoots { lx })
}

/// ```prism
/// UnboundedValues: unbounded fn Lx, Def -> [Text]
/// ```
pub fn unbounded_values(lx: &crate::lower::Lx, d: &crate::check::env::Def) -> Array<Text> {
    let es = match &d.body {
        crate::check::env::DefBody::DbWidget(w) => crate::check::typed::print::block_exprs(&w.body),
        crate::check::env::DefBody::DbFn(cs) => run_to_end(fold_job(cs.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<crate::syntax::Expr>, crate::syntax::decls::FnClause)| entered(once_job(move || {
            let acc = p0;
            let c = p1;
            call_then(crate::check::typed::print::start_body_exprs(c.body.clone()), move |body_exprs_15421: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(append(&acc, &body_exprs_15421)))
        }))) as Rc<dyn Fn((Array<crate::syntax::Expr>, crate::syntax::decls::FnClause)) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>>>)),
        crate::check::env::DefBody::DbLet(l) => crate::check::typed::print::exprs_in(&l.value),
        _ => Array::new(),
    };
    let callees = fold(&es, &Array::new(), &(|acc: &Array<Text>, e: &crate::syntax::Expr| match &*e.kind {
        crate::syntax::ExprKind::ECall(c, _, _, _) => push(acc, &crate::lower::place_key(lx, &c.span)),
        _ => acc.clone(),
    }));
    fold(&es, &Array::new(), &(|acc: &Array<Text>, e: &crate::syntax::Expr| match &*e.kind {
        crate::syntax::ExprKind::EName(n) => if crate::check::types::has_text(&callees, &crate::lower::place_key(lx, &e.span)) {
            acc.clone()
        } else {
            {
                let (q_opt, _) = crate::check::env::names::resolve_value(&lx.g, &lx.home, n);
                match &q_opt {
                    Some(q) => if is_unbounded(lx, q) { crate::check::types::add_text(acc, q) } else { acc.clone() },
                    None => acc.clone(),
                }
            }
        },
        _ => acc.clone(),
    }))
}

/// The step machine of `UnboundedValues`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UnboundedValues: unbounded fn Lx, Def -> [Text]
/// ```
pub struct UnboundedValues {
    pub lx: crate::lower::Lx,
    pub d: crate::check::env::Def,
}

impl prism_rtl::Job<Array<Text>> for UnboundedValues {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let lx = &self.lx;
        let d = &self.d;
        let es = match &d.body {
            crate::check::env::DefBody::DbWidget(w) => crate::check::typed::print::block_exprs(&w.body),
            crate::check::env::DefBody::DbFn(cs) => run_to_end(fold_job(cs.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<crate::syntax::Expr>, crate::syntax::decls::FnClause)| entered(once_job(move || {
                let acc = p0;
                let c = p1;
                call_then(crate::check::typed::print::start_body_exprs(c.body.clone()), move |body_exprs_15421: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(append(&acc, &body_exprs_15421)))
            }))) as Rc<dyn Fn((Array<crate::syntax::Expr>, crate::syntax::decls::FnClause)) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>>>)),
            crate::check::env::DefBody::DbLet(l) => crate::check::typed::print::exprs_in(&l.value),
            _ => Array::new(),
        };
        let callees = fold(&es, &Array::new(), &(|acc: &Array<Text>, e: &crate::syntax::Expr| match &*e.kind {
            crate::syntax::ExprKind::ECall(c, _, _, _) => push(acc, &crate::lower::place_key(lx, &c.span)),
            _ => acc.clone(),
        }));
        prism_rtl::Turn::Finished(fold(&es, &Array::new(), &(|acc: &Array<Text>, e: &crate::syntax::Expr| match &*e.kind {
            crate::syntax::ExprKind::EName(n) => if crate::check::types::has_text(&callees, &crate::lower::place_key(lx, &e.span)) {
                acc.clone()
            } else {
                {
                    let (q_opt, _) = crate::check::env::names::resolve_value(&lx.g, &lx.home, n);
                    match &q_opt {
                        Some(q) => if is_unbounded(lx, q) { crate::check::types::add_text(acc, q) } else { acc.clone() },
                        None => acc.clone(),
                    }
                }
            },
            _ => acc.clone(),
        })))
    }
}

/// `Start UnboundedValues, x`: what the function value is when passed to `@Run`.
pub fn start_unbounded_values(lx: crate::lower::Lx, d: crate::check::env::Def) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(UnboundedValues { lx, d })
}

/// ```prism
/// InPrelude: fn Lx, Text -> Bool
/// ```
pub fn in_prelude(lx: &crate::lower::Lx, q: &Text) -> bool {
    match get(&lx.g.vals, q) {
        Some(v_) => &v_.home == &Text::lit("Prelude"),
        None => false,
    }
}

/// ```prism
/// IsColorPoly: fn Lx, Text -> Bool
/// ```
pub fn is_color_poly(lx: &crate::lower::Lx, q: &Text) -> bool {
    match get(&lx.g.vals, q) {
        Some(v_) => match &v_.scheme.ty {
            crate::check::types::Ty::TyFn(crate::check::types::Col::CQ(_), _, _) => true,
            crate::check::types::Ty::TyFn(crate::check::types::Col::CRigid(_), _, _) => true,
            _ => false,
        },
        None => false,
    }
}

/// ```prism
/// EntersAtOnce: fn Lx, Text, [Arg] -> Bool
/// ```
pub fn enters_at_once(lx: &crate::lower::Lx, q: &Text, args: &Array<crate::syntax::Arg>) -> bool {
    is_color_poly(lx, q) && !fold(args, &false, &(|seen: &bool, a: &crate::syntax::Arg| *seen || is_unbounded_arg(lx, a)))
}

/// ```prism
/// IsUnboundedArg: fn Lx, Arg -> Bool
/// ```
pub fn is_unbounded_arg(lx: &crate::lower::Lx, a: &crate::syntax::Arg) -> bool {
    match crate::lower::types::peel(&crate::lower::type_at(lx, &a.value.span)) {
        crate::check::types::Ty::TyFn(crate::check::types::Col::CUnbound, _, _) => true,
        _ => false,
    }
}

/// ```prism
/// IsUnbounded: fn Lx, Text -> Bool
/// ```
pub fn is_unbounded(lx: &crate::lower::Lx, q: &Text) -> bool {
    match get(&lx.g.vals, q) {
        Some(v_) => match &v_.scheme.ty {
            crate::check::types::Ty::TyFn(crate::check::types::Col::CBound, _, _) => false,
            crate::check::types::Ty::TyFn(_, _, _) => true,
            _ => false,
        },
        None => false,
    }
}

/// ```prism
/// RunTargets: unbounded fn Lx, Def -> [Text]
/// ```
pub fn run_targets(lx: &crate::lower::Lx, d: &crate::check::env::Def) -> Array<Text> {
    let es = match &d.body {
        crate::check::env::DefBody::DbWidget(w) => crate::check::typed::print::block_exprs(&w.body),
        crate::check::env::DefBody::DbFn(cs) => run_to_end(fold_job(cs.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<crate::syntax::Expr>, crate::syntax::decls::FnClause)| entered(once_job(move || {
            let acc = p0;
            let c = p1;
            call_then(crate::check::typed::print::start_body_exprs(c.body.clone()), move |body_exprs_17650: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(append(&acc, &body_exprs_17650)))
        }))) as Rc<dyn Fn((Array<crate::syntax::Expr>, crate::syntax::decls::FnClause)) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>>>)),
        _ => Array::new(),
    };
    fold(&es, &Array::new(), &(|acc: &Array<Text>, e: &crate::syntax::Expr| match &*e.kind {
        crate::syntax::ExprKind::ECall(c, args, _, _) => if &blueprint_qk(lx, &**c) == &Text::lit("Prelude.@Run") {
            match index(args, &Nat::from(0u32)) {
                Some(a) => match &*a.value.kind {
                    crate::syntax::ExprKind::EName(n) => {
                        let (q_opt, _) = crate::check::env::names::resolve_value(&lx.g, &lx.home, n);
                        match &q_opt {
                            Some(q) => crate::check::types::add_text(acc, q),
                            None => acc.clone(),
                        }
                    },
                    _ => acc.clone(),
                },
                None => acc.clone(),
            }
        } else {
            acc.clone()
        },
        _ => acc.clone(),
    }))
}

/// The step machine of `RunTargets`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RunTargets: unbounded fn Lx, Def -> [Text]
/// ```
pub struct RunTargets {
    pub lx: crate::lower::Lx,
    pub d: crate::check::env::Def,
}

impl prism_rtl::Job<Array<Text>> for RunTargets {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let lx = &self.lx;
        let d = &self.d;
        let es = match &d.body {
            crate::check::env::DefBody::DbWidget(w) => crate::check::typed::print::block_exprs(&w.body),
            crate::check::env::DefBody::DbFn(cs) => run_to_end(fold_job(cs.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<crate::syntax::Expr>, crate::syntax::decls::FnClause)| entered(once_job(move || {
                let acc = p0;
                let c = p1;
                call_then(crate::check::typed::print::start_body_exprs(c.body.clone()), move |body_exprs_17650: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(append(&acc, &body_exprs_17650)))
            }))) as Rc<dyn Fn((Array<crate::syntax::Expr>, crate::syntax::decls::FnClause)) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>>>)),
            _ => Array::new(),
        };
        prism_rtl::Turn::Finished(fold(&es, &Array::new(), &(|acc: &Array<Text>, e: &crate::syntax::Expr| match &*e.kind {
            crate::syntax::ExprKind::ECall(c, args, _, _) => if &blueprint_qk(lx, &**c) == &Text::lit("Prelude.@Run") {
                match index(args, &Nat::from(0u32)) {
                    Some(a) => match &*a.value.kind {
                        crate::syntax::ExprKind::EName(n) => {
                            let (q_opt, _) = crate::check::env::names::resolve_value(&lx.g, &lx.home, n);
                            match &q_opt {
                                Some(q) => crate::check::types::add_text(acc, q),
                                None => acc.clone(),
                            }
                        },
                        _ => acc.clone(),
                    },
                    None => acc.clone(),
                }
            } else {
                acc.clone()
            },
            _ => acc.clone(),
        })))
    }
}

/// `Start RunTargets, x`: what the function value is when passed to `@Run`.
pub fn start_run_targets(lx: crate::lower::Lx, d: crate::check::env::Def) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(RunTargets { lx, d })
}

/// ```prism
/// TailTargets: unbounded fn Lx, Text -> [Text]
/// ```
pub fn tail_targets(lx: &crate::lower::Lx, qk: &Text) -> Array<Text> {
    let v_ = or(&get(&lx.g.vals, qk), &crate::check::env::builtin(qk, &crate::check::types::schemes::mono(&crate::check::types::Ty::TyErr)));
    let lxm = in_module(lx, &v_.file, &v_.home);
    run_to_end(fold_job(crate::lower::jobs::clauses_of(&lx.g, qk), Array::new(), {
        let lxm = lxm.clone();
        Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::decls::FnClause)| {
            let lxm = lxm.clone();
            entered(once_job(move || {
                let acc = p0;
                let c = p1;
                call_then(start_tails_of_body(lxm.clone(), c.body.clone()), move |tails_of_body_18529: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc, &tails_of_body_18529)))
            }))
        }) as Rc<dyn Fn((Array<Text>, crate::syntax::decls::FnClause)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
    }))
}

/// The step machine of `TailTargets`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TailTargets: unbounded fn Lx, Text -> [Text]
/// ```
pub struct TailTargets {
    pub lx: crate::lower::Lx,
    pub qk: Text,
}

impl prism_rtl::Job<Array<Text>> for TailTargets {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let lx = &self.lx;
        let qk = &self.qk;
        let v_ = or(&get(&lx.g.vals, qk), &crate::check::env::builtin(qk, &crate::check::types::schemes::mono(&crate::check::types::Ty::TyErr)));
        let lxm = in_module(lx, &v_.file, &v_.home);
        fold_job(crate::lower::jobs::clauses_of(&lx.g, qk), Array::new(), {
            let lxm = lxm.clone();
            Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::decls::FnClause)| {
                let lxm = lxm.clone();
                entered(once_job(move || {
                    let acc = p0;
                    let c = p1;
                    call_then(start_tails_of_body(lxm.clone(), c.body.clone()), move |tails_of_body_18529: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc, &tails_of_body_18529)))
                }))
            }) as Rc<dyn Fn((Array<Text>, crate::syntax::decls::FnClause)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
        }).cycle()
    }
}

/// `Start TailTargets, x`: what the function value is when passed to `@Run`.
pub fn start_tail_targets(lx: crate::lower::Lx, qk: Text) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(TailTargets { lx, qk })
}

/// ```prism
/// TailsOfBody: unbounded fn Lx, FnBody -> [Text]
/// ```
pub fn tails_of_body(lx: &crate::lower::Lx, body: &crate::syntax::decls::FnBody) -> Array<Text> {
    fold(&crate::check::typed::print::body_exprs(body), &Array::new(), &(|acc: &Array<Text>, e: &crate::syntax::Expr| match &*e.kind {
        crate::syntax::ExprKind::ECall(c, _, _, _) => {
            let q = blueprint_qk(lx, &**c);
            match get(&lx.g.vals, &q) {
                Some(v_) => match &v_.scheme.ty {
                    crate::check::types::Ty::TyFn(crate::check::types::Col::CBound, _, _) => acc.clone(),
                    crate::check::types::Ty::TyFn(_, _, _) => crate::check::types::add_text(acc, &q),
                    _ => acc.clone(),
                },
                None => acc.clone(),
            }
        },
        _ => acc.clone(),
    }))
}

/// The step machine of `TailsOfBody`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TailsOfBody: unbounded fn Lx, FnBody -> [Text]
/// ```
pub struct TailsOfBody {
    pub lx: crate::lower::Lx,
    pub body: crate::syntax::decls::FnBody,
}

impl prism_rtl::Job<Array<Text>> for TailsOfBody {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let lx = &self.lx;
        let body = &self.body;
        let body = body.clone();
        let lx = lx.clone();
        call_then(crate::check::typed::print::start_body_exprs(body.clone()), move |body_exprs_18634: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(fold(&body_exprs_18634, &Array::new(), &(|acc: &Array<Text>, e: &crate::syntax::Expr| match &*e.kind {
            crate::syntax::ExprKind::ECall(c, _, _, _) => {
                let q = blueprint_qk(&lx, &**c);
                match get(&lx.g.vals, &q) {
                    Some(v_) => match &v_.scheme.ty {
                        crate::check::types::Ty::TyFn(crate::check::types::Col::CBound, _, _) => acc.clone(),
                        crate::check::types::Ty::TyFn(_, _, _) => crate::check::types::add_text(acc, &q),
                        _ => acc.clone(),
                    },
                    None => acc.clone(),
                }
            },
            _ => acc.clone(),
        }))))
    }
}

/// `Start TailsOfBody, x`: what the function value is when passed to `@Run`.
pub fn start_tails_of_body(lx: crate::lower::Lx, body: crate::syntax::decls::FnBody) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(TailsOfBody { lx, body })
}

/// ```prism
/// ModDefOf: unbounded fn Lx, Text, [((Text, Bool))], ModInfo, [Text] -> ModDef
/// ```
pub fn mod_def_of(lx0: &crate::lower::Lx, m: &Text, roots: &Array<(Text, bool)>, info: &crate::check::env::ModInfo, mods: &Array<Text>) -> crate::lower::model::ModDef {
    let lx = in_module(lx0, &info.file, m);
    let path_ = match index(&lx.g.srcs, &info.file) {
        Some(src) => src.path_.clone(),
        None => Text::lit(""),
    };
    let types = run_to_end(fold_job(values(&lx.g.types), Array::new(), {
        let m = m.clone();
        let lx = lx.clone();
        Rc::new(move |(p0, p1): (Array<crate::lower::model::Item>, crate::check::env::TyInfo)| {
            let m = m.clone();
            let lx = lx.clone();
            entered(once_job(move || {
                let acc = p0;
                let ti = p1;
                if &ti.home == &m {
                    call_then(start_ty_defs(lx.clone(), ti.clone()), move |ty_defs_19359: Array<crate::lower::model::Item>| prism_rtl::Turn::Finished(append(&acc, &ty_defs_19359)))
                } else {
                    prism_rtl::Turn::Finished(acc.clone())
                }
            }))
        }) as Rc<dyn Fn((Array<crate::lower::model::Item>, crate::check::env::TyInfo)) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Item>>>>
    }));
    let tags = run_to_end(fold_job(values(&lx.g.tags), Array::new(), {
        let m = m.clone();
        let lx = lx.clone();
        Rc::new(move |(p0, p1): (Array<crate::lower::model::Item>, crate::check::env::TagInfo)| {
            let m = m.clone();
            let lx = lx.clone();
            entered(once_job(move || {
                let acc = p0;
                let tg = p1;
                if (&tg.home == &m) && (&tg.kind != &Text::lit("Prelude.Fault")) {
                    call_then(start_tag_def_of(lx.clone(), tg.clone()), move |tag_def_of_19507: crate::lower::model::TagDef| prism_rtl::Turn::Finished(push(&acc, &crate::lower::model::Item::ItTag(tag_def_of_19507))))
                } else {
                    prism_rtl::Turn::Finished(acc.clone())
                }
            }))
        }) as Rc<dyn Fn((Array<crate::lower::model::Item>, crate::check::env::TagInfo)) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Item>>>>
    }));
    let defs = run_to_end(fold_job(lx.g.defs.clone(), Array::new(), {
        let m = m.clone();
        let lx = lx.clone();
        let roots = roots.clone();
        Rc::new(move |(p0, p1): (Array<crate::lower::model::Item>, crate::check::env::Def)| {
            let m = m.clone();
            let lx = lx.clone();
            let roots = roots.clone();
            entered(once_job(move || {
                let acc = p0;
                let d = p1;
                if &d.home == &m {
                    call_then(start_def_items(in_module(&lx, &d.file, &m), d.clone(), roots.clone()), move |def_items_19611: Array<crate::lower::model::Item>| prism_rtl::Turn::Finished(append(&acc, &def_items_19611)))
                } else {
                    prism_rtl::Turn::Finished(acc.clone())
                }
            }))
        }) as Rc<dyn Fn((Array<crate::lower::model::Item>, crate::check::env::Def)) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Item>>>>
    }));
    let traits = run_to_end(fold_job(values(&lx.g.traits), Array::new(), {
        let m = m.clone();
        let lx = lx.clone();
        Rc::new(move |(p0, p1): (Array<crate::lower::model::Item>, crate::check::env::TraitInfo)| {
            let m = m.clone();
            let lx = lx.clone();
            entered(once_job(move || {
                let acc = p0;
                let tr = p1;
                if &tr.home == &m {
                    call_then(crate::lower::functions::start_trait_def_of(lx.clone(), tr.clone()), move |trait_def_of_19764: crate::lower::model::TraitDef| prism_rtl::Turn::Finished(push(&acc, &crate::lower::model::Item::ItTrait(trait_def_of_19764))))
                } else {
                    prism_rtl::Turn::Finished(acc.clone())
                }
            }))
        }) as Rc<dyn Fn((Array<crate::lower::model::Item>, crate::check::env::TraitInfo)) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Item>>>>
    }));
    let impls = run_to_end(fold_job(values(&lx.g.impls), Array::new(), {
        let m = m.clone();
        let lx = lx.clone();
        Rc::new(move |(p0, p1): (Array<crate::lower::model::Item>, Array<crate::check::env::ImplInfo>)| {
            let m = m.clone();
            let lx = lx.clone();
            entered(once_job(move || {
                let acc = p0;
                let ims = p1;
                fold_job(ims.clone(), acc.clone(), {
                    let m = m.clone();
                    let lx = lx.clone();
                    Rc::new(move |(p0, p1): (Array<crate::lower::model::Item>, crate::check::env::ImplInfo)| {
                        let m = m.clone();
                        let lx = lx.clone();
                        entered(once_job(move || {
                            let a = p0;
                            let im = p1;
                            if (&im.home == &m) && !im.derived {
                                call_then(crate::lower::functions::start_impl_def_of(in_module(&lx, &im.file, &m), im.clone()), move |impl_def_of_19931: crate::lower::model::ImplDef| prism_rtl::Turn::Finished(push(&a, &crate::lower::model::Item::ItImpl(impl_def_of_19931))))
                            } else {
                                prism_rtl::Turn::Finished(a.clone())
                            }
                        }))
                    }) as Rc<dyn Fn((Array<crate::lower::model::Item>, crate::check::env::ImplInfo)) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Item>>>>
                }).cycle()
            }))
        }) as Rc<dyn Fn((Array<crate::lower::model::Item>, Array<crate::check::env::ImplInfo>)) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Item>>>>
    }));
    let uses = filter(&each(mods, &(|o: &Text| crate::lower::rust_mod_name(o))), &(|o: &Text| o != &crate::lower::rust_mod_name(m)));
    crate::lower::model::ModDef { name: crate::lower::rust_mod_name(m), prism: m.clone(), path_: path_.clone(), uses: uses.clone(), complete: Array::new(), declared: Array::new(), types_with: Array::new(), items: append(&append(&append(&append(&types, &tags), &traits), &impls), &defs) }
}

/// The step machine of `ModDefOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ModDefOf: unbounded fn Lx, Text, [((Text, Bool))], ModInfo, [Text] -> ModDef
/// ```
pub struct ModDefOf {
    pub lx0: crate::lower::Lx,
    pub m: Text,
    pub roots: Array<(Text, bool)>,
    pub info: crate::check::env::ModInfo,
    pub mods: Array<Text>,
}

impl prism_rtl::Job<crate::lower::model::ModDef> for ModDefOf {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::ModDef> {
        let lx0 = &self.lx0;
        let m = &self.m;
        let roots = &self.roots;
        let info = &self.info;
        let mods = &self.mods;
        let lx = in_module(lx0, &info.file, m);
        let path_ = match index(&lx.g.srcs, &info.file) {
            Some(src) => src.path_.clone(),
            None => Text::lit(""),
        };
        let m = m.clone();
        let mods = mods.clone();
        let roots = roots.clone();
        call_value(fold_job(values(&lx.g.types), Array::new(), {
            let m = m.clone();
            let lx = lx.clone();
            Rc::new(move |(p0, p1): (Array<crate::lower::model::Item>, crate::check::env::TyInfo)| {
                let m = m.clone();
                let lx = lx.clone();
                entered(once_job(move || {
                    let acc = p0;
                    let ti = p1;
                    if &ti.home == &m {
                        call_then(start_ty_defs(lx.clone(), ti.clone()), move |ty_defs_19359: Array<crate::lower::model::Item>| prism_rtl::Turn::Finished(append(&acc, &ty_defs_19359)))
                    } else {
                        prism_rtl::Turn::Finished(acc.clone())
                    }
                }))
            }) as Rc<dyn Fn((Array<crate::lower::model::Item>, crate::check::env::TyInfo)) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Item>>>>
        }), move |fold_19286: Array<crate::lower::model::Item>| {
            let types = fold_19286;
            call_value(fold_job(values(&lx.g.tags), Array::new(), {
                let m = m.clone();
                let lx = lx.clone();
                Rc::new(move |(p0, p1): (Array<crate::lower::model::Item>, crate::check::env::TagInfo)| {
                    let m = m.clone();
                    let lx = lx.clone();
                    entered(once_job(move || {
                        let acc = p0;
                        let tg = p1;
                        if (&tg.home == &m) && (&tg.kind != &Text::lit("Prelude.Fault")) {
                            call_then(start_tag_def_of(lx.clone(), tg.clone()), move |tag_def_of_19507: crate::lower::model::TagDef| prism_rtl::Turn::Finished(push(&acc, &crate::lower::model::Item::ItTag(tag_def_of_19507))))
                        } else {
                            prism_rtl::Turn::Finished(acc.clone())
                        }
                    }))
                }) as Rc<dyn Fn((Array<crate::lower::model::Item>, crate::check::env::TagInfo)) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Item>>>>
            }), move |fold_19399: Array<crate::lower::model::Item>| {
                let tags = fold_19399;
                call_value(fold_job(lx.g.defs.clone(), Array::new(), {
                    let m = m.clone();
                    let lx = lx.clone();
                    let roots = roots.clone();
                    Rc::new(move |(p0, p1): (Array<crate::lower::model::Item>, crate::check::env::Def)| {
                        let m = m.clone();
                        let lx = lx.clone();
                        let roots = roots.clone();
                        entered(once_job(move || {
                            let acc = p0;
                            let d = p1;
                            if &d.home == &m {
                                call_then(start_def_items(in_module(&lx, &d.file, &m), d.clone(), roots.clone()), move |def_items_19611: Array<crate::lower::model::Item>| prism_rtl::Turn::Finished(append(&acc, &def_items_19611)))
                            } else {
                                prism_rtl::Turn::Finished(acc.clone())
                            }
                        }))
                    }) as Rc<dyn Fn((Array<crate::lower::model::Item>, crate::check::env::Def)) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Item>>>>
                }), move |fold_19550: Array<crate::lower::model::Item>| {
                    let defs = fold_19550;
                    call_value(fold_job(values(&lx.g.traits), Array::new(), {
                        let m = m.clone();
                        let lx = lx.clone();
                        Rc::new(move |(p0, p1): (Array<crate::lower::model::Item>, crate::check::env::TraitInfo)| {
                            let m = m.clone();
                            let lx = lx.clone();
                            entered(once_job(move || {
                                let acc = p0;
                                let tr = p1;
                                if &tr.home == &m {
                                    call_then(crate::lower::functions::start_trait_def_of(lx.clone(), tr.clone()), move |trait_def_of_19764: crate::lower::model::TraitDef| prism_rtl::Turn::Finished(push(&acc, &crate::lower::model::Item::ItTrait(trait_def_of_19764))))
                                } else {
                                    prism_rtl::Turn::Finished(acc.clone())
                                }
                            }))
                        }) as Rc<dyn Fn((Array<crate::lower::model::Item>, crate::check::env::TraitInfo)) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Item>>>>
                    }), move |fold_19683: Array<crate::lower::model::Item>| {
                        let traits = fold_19683;
                        call_value(fold_job(values(&lx.g.impls), Array::new(), {
                            let m = m.clone();
                            let lx = lx.clone();
                            Rc::new(move |(p0, p1): (Array<crate::lower::model::Item>, Array<crate::check::env::ImplInfo>)| {
                                let m = m.clone();
                                let lx = lx.clone();
                                entered(once_job(move || {
                                    let acc = p0;
                                    let ims = p1;
                                    fold_job(ims.clone(), acc.clone(), {
                                        let m = m.clone();
                                        let lx = lx.clone();
                                        Rc::new(move |(p0, p1): (Array<crate::lower::model::Item>, crate::check::env::ImplInfo)| {
                                            let m = m.clone();
                                            let lx = lx.clone();
                                            entered(once_job(move || {
                                                let a = p0;
                                                let im = p1;
                                                if (&im.home == &m) && !im.derived {
                                                    call_then(crate::lower::functions::start_impl_def_of(in_module(&lx, &im.file, &m), im.clone()), move |impl_def_of_19931: crate::lower::model::ImplDef| prism_rtl::Turn::Finished(push(&a, &crate::lower::model::Item::ItImpl(impl_def_of_19931))))
                                                } else {
                                                    prism_rtl::Turn::Finished(a.clone())
                                                }
                                            }))
                                        }) as Rc<dyn Fn((Array<crate::lower::model::Item>, crate::check::env::ImplInfo)) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Item>>>>
                                    }).cycle()
                                }))
                            }) as Rc<dyn Fn((Array<crate::lower::model::Item>, Array<crate::check::env::ImplInfo>)) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Item>>>>
                        }), move |fold_19810: Array<crate::lower::model::Item>| {
                            let impls = fold_19810;
                            let uses = filter(&each(&mods, &(|o: &Text| crate::lower::rust_mod_name(o))), &(|o: &Text| o != &crate::lower::rust_mod_name(&m)));
                            prism_rtl::Turn::Finished(crate::lower::model::ModDef { name: crate::lower::rust_mod_name(&m), prism: m.clone(), path_: path_.clone(), uses: uses.clone(), complete: Array::new(), declared: Array::new(), types_with: Array::new(), items: append(&append(&append(&append(&types, &tags), &traits), &impls), &defs) })
                        })
                    })
                })
            })
        })
    }
}

/// `Start ModDefOf, x`: what the function value is when passed to `@Run`.
pub fn start_mod_def_of(lx0: crate::lower::Lx, m: Text, roots: Array<(Text, bool)>, info: crate::check::env::ModInfo, mods: Array<Text>) -> Rc<dyn prism_rtl::Job<crate::lower::model::ModDef>> {
    Rc::new(ModDefOf { lx0, m, roots, info, mods })
}

/// ```prism
/// DefItems: unbounded fn Lx, Def, [((Text, Bool))] -> [Item]
/// ```
pub fn def_items(lx: &crate::lower::Lx, d: &crate::check::env::Def, roots: &Array<(Text, bool)>) -> Array<crate::lower::model::Item> {
    let is_root = crate::check::types::has_text(&each(roots, &(|(q, _): &(Text, bool)| q.clone())), &d.qk);
    match &d.body {
        crate::check::env::DefBody::DbWidget(w) => if is_root {
            node_items(&crate::lower::node_::def::node_def_of(lx, &d.qk, &Array::new(), &w.body, &or(&get(&lx.g.vals, &d.qk), &crate::check::env::builtin(&d.qk, &crate::check::types::schemes::mono(&crate::check::types::Ty::TyErr))).scheme, &true))
        } else {
            Array::from(vec![crate::lower::model::Item::ItNote(Text::from(format!("`{}` is inlined where it is applied.", &d.name)))])
        },
        crate::check::env::DefBody::DbFn(clauses) => match get(&lx.g.vals, &d.qk) {
            None => Array::new(),
            Some(v_) => 'm20849: {
                let scrutinee = &v_.scheme.ty;
                if let crate::check::types::Ty::TyFn(_, _, m20849_0_2) = scrutinee && let crate::check::types::Ty::TyAt(_, _) = &**m20849_0_2 {
                    break 'm20849 if !is_root {
                        Array::from(vec![crate::lower::model::Item::ItNote(Text::from(format!("`{}` is inlined where it is applied.", &d.name)))])
                    } else {
                        'm21045: {
                            if let m21045_0 = clauses && (m21045_0.len() == 1) && let Some(c) = index(m21045_0, &Nat::from(0u32)) {
                                break 'm21045 match &c.body {
                                    crate::syntax::decls::FnBody::BodyBlock(b) => node_items(&crate::lower::node_::def::node_def_of(lx, &d.qk, &c.params, b, &v_.scheme, &true)),
                                    _ => Array::from(vec![crate::lower::model::Item::ItRefused(Text::from(format!("`{}`, a root widget whose body is one expression", &d.name)))]),
                                };
                            }
                            Array::from(vec![crate::lower::model::Item::ItRefused(Text::from(format!("`{}`, a root widget of several clauses", &d.name)))])
                        }
                    };
                }
                {
                    let f = crate::lower::model::Item::ItFn(crate::lower::functions::fn_def_of(lx, &d.qk, clauses, &v_.scheme));
                    if crate::check::types::has_text(&lx.unbs, &d.qk) {
                        Array::from(vec![f.clone(), crate::lower::model::Item::ItJob(crate::lower::jobs::job_def_of(lx, &d.qk, clauses, &v_.scheme))])
                    } else {
                        Array::from(vec![f.clone()])
                    }
                }
            },
        },
        crate::check::env::DefBody::DbLet(l) => Array::from(vec![crate::lower::model::Item::ItFn(crate::lower::functions::let_getter(lx, &d.qk, l))]),
        _ => Array::new(),
    }
}

/// The step machine of `DefItems`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// DefItems: unbounded fn Lx, Def, [((Text, Bool))] -> [Item]
/// ```
pub struct DefItems {
    pub lx: crate::lower::Lx,
    pub d: crate::check::env::Def,
    pub roots: Array<(Text, bool)>,
}

impl prism_rtl::Job<Array<crate::lower::model::Item>> for DefItems {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::lower::model::Item>> {
        let lx = &self.lx;
        let d = &self.d;
        let roots = &self.roots;
        let is_root = crate::check::types::has_text(&each(roots, &(|(q, _): &(Text, bool)| q.clone())), &d.qk);
        match &d.body {
            crate::check::env::DefBody::DbWidget(w) => if is_root {
                {
                    let d = d.clone();
                    let lx = lx.clone();
                    let w = w.clone();
                    call_then(crate::lower::node_::def::start_node_def_of(lx.clone(), d.qk.clone(), Array::new(), w.body.clone(), or(&get(&lx.g.vals, &d.qk), &crate::check::env::builtin(&d.qk, &crate::check::types::schemes::mono(&crate::check::types::Ty::TyErr))).scheme.clone(), true), move |node_def_of_20592: crate::lower::model::NodeDef| prism_rtl::Turn::Finished(node_items(&node_def_of_20592)))
                }
            } else {
                prism_rtl::Turn::Finished(Array::from(vec![crate::lower::model::Item::ItNote(Text::from(format!("`{}` is inlined where it is applied.", &d.name)))]))
            },
            crate::check::env::DefBody::DbFn(clauses) => match get(&lx.g.vals, &d.qk) {
                None => prism_rtl::Turn::Finished(Array::new()),
                Some(v_) => 'm20849: {
                    let scrutinee = &v_.scheme.ty;
                    if let crate::check::types::Ty::TyFn(_, _, m20849_0_2) = scrutinee && let crate::check::types::Ty::TyAt(_, _) = &**m20849_0_2 {
                        break 'm20849 if !is_root {
                            prism_rtl::Turn::Finished(Array::from(vec![crate::lower::model::Item::ItNote(Text::from(format!("`{}` is inlined where it is applied.", &d.name)))]))
                        } else {
                            'm21045: {
                                if let m21045_0 = clauses && (m21045_0.len() == 1) && let Some(c) = index(m21045_0, &Nat::from(0u32)) {
                                    break 'm21045 match &c.body {
                                        crate::syntax::decls::FnBody::BodyBlock(b) => {
                                            let b = b.clone();
                                            let d = d.clone();
                                            let lx = lx.clone();
                                            call_then(crate::lower::node_::def::start_node_def_of(lx.clone(), d.qk.clone(), c.params.clone(), b.clone(), v_.scheme.clone(), true), move |node_def_of_21157: crate::lower::model::NodeDef| prism_rtl::Turn::Finished(node_items(&node_def_of_21157)))
                                        },
                                        _ => prism_rtl::Turn::Finished(Array::from(vec![crate::lower::model::Item::ItRefused(Text::from(format!("`{}`, a root widget whose body is one expression", &d.name)))])),
                                    };
                                }
                                prism_rtl::Turn::Finished(Array::from(vec![crate::lower::model::Item::ItRefused(Text::from(format!("`{}`, a root widget of several clauses", &d.name)))]))
                            }
                        };
                    }
                    {
                        let clauses = clauses.clone();
                        let d = d.clone();
                        let lx = lx.clone();
                        call_then(crate::lower::functions::start_fn_def_of(lx.clone(), d.qk.clone(), clauses.clone(), v_.scheme.clone()), move |fn_def_of_21473: crate::lower::model::FnDef| {
                            let f = crate::lower::model::Item::ItFn(fn_def_of_21473);
                            if crate::check::types::has_text(&lx.unbs, &d.qk) {
                                call_then(crate::lower::jobs::start_job_def_of(lx.clone(), d.qk.clone(), clauses.clone(), v_.scheme.clone()), move |job_def_of_21568: crate::lower::model::JobDef| prism_rtl::Turn::Finished(Array::from(vec![f.clone(), crate::lower::model::Item::ItJob(job_def_of_21568)])))
                            } else {
                                prism_rtl::Turn::Finished(Array::from(vec![f.clone()]))
                            }
                        })
                    }
                },
            },
            crate::check::env::DefBody::DbLet(l) => {
                let d = d.clone();
                let l = l.clone();
                let lx = lx.clone();
                call_then(crate::lower::functions::start_let_getter(lx.clone(), d.qk.clone(), l.clone()), move |let_getter_21645: crate::lower::model::FnDef| prism_rtl::Turn::Finished(Array::from(vec![crate::lower::model::Item::ItFn(let_getter_21645)])))
            },
            _ => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start DefItems, x`: what the function value is when passed to `@Run`.
pub fn start_def_items(lx: crate::lower::Lx, d: crate::check::env::Def, roots: Array<(Text, bool)>) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Item>>> {
    Rc::new(DefItems { lx, d, roots })
}

/// ```prism
/// NodeItems: fn NodeDef -> [Item]
/// ```
pub fn node_items(n: &crate::lower::model::NodeDef) -> Array<crate::lower::model::Item> {
    append(&Array::from(vec![crate::lower::model::Item::ItNode(n.clone())]), &each(&n.children, &(|c: &crate::lower::model::NodeDef| crate::lower::model::Item::ItNode(c.clone()))))
}

/// ```prism
/// TyDefs: unbounded fn Lx, TyInfo -> [Item]
/// ```
pub fn ty_defs(lx: &crate::lower::Lx, ti: &crate::check::env::TyInfo) -> Array<crate::lower::model::Item> {
    let derives = each(&ti.derives, &(|dn: &Text| crate::check::types::bare_name(dn)));
    let params = each(&ti.params, &(|p_: &Text| crate::lower::camel(p_)));
    let floaty = crate::lower::types::floaty(&lx.g, &crate::check::types::Ty::TyCon(ti.name.clone(), Array::new()), &Array::new());
    let bare = crate::check::types::bare_name(&ti.name);
    let mk_fn = {
        let bare = bare.clone();
        let params = params.clone();
        let derives = derives.clone();
        let floaty = floaty;
        let lx = lx.clone();
        let ti = ti.clone();
        Rc::new(move |(p0, p1): (crate::lower::model::TyShape, Array<crate::lower::model::CaseDef>)| {
            let bare = bare.clone();
            let params = params.clone();
            let derives = derives.clone();
            let floaty = floaty;
            let lx = lx.clone();
            let ti = ti.clone();
            entered(once_job(move || {
                let shape = p0;
                let cases = p1;
                call_then(start_ty_podable(lx.clone(), crate::check::types::Ty::TyCon(ti.name.clone(), Array::new()), Array::new()), move |ty_podable_22437: bool| prism_rtl::Turn::Finished(crate::lower::model::TyDef { name: crate::lower::camel(&bare), prism: bare.clone(), params: params.clone(), shape: shape.clone(), cases: cases.clone(), eq: crate::check::types::has_text(&derives, &Text::lit("Eq")), ord: crate::check::types::has_text(&derives, &Text::lit("Ord")), floaty, show: if crate::lower::functions::has_own_show(&lx, &ti.name) {
                    crate::lower::model::Shown::ShownOwn
                } else {
                    if crate::check::types::has_text(&derives, &Text::lit("Show")) {
                        crate::lower::model::Shown::ShownDerived
                    } else {
                        crate::lower::model::Shown::NotShown
                    }
                }, pod: ty_podable_22437 && run_to_end(fold_job(cases.clone(), true, Rc::new(move |(p0, p1): (bool, crate::lower::model::CaseDef)| entered(once_job(move || {
                    let ok = p0;
                    let c = p1;
                    prism_rtl::Turn::Finished(ok && run_to_end(fold_job(c.fields.clone(), true, Rc::new(move |(p0, p1): (bool, (Text, crate::lower::model::OutTy))| entered(once_job(move || {
                        let ok2 = p0;
                        let (_, ft) = p1;
                        prism_rtl::Turn::Finished(ok2 && crate::lower::types::podable(&ft))
                    }))) as Rc<dyn Fn((bool, (Text, crate::lower::model::OutTy))) -> Rc<dyn prism_rtl::Job<bool>>>)))
                }))) as Rc<dyn Fn((bool, crate::lower::model::CaseDef)) -> Rc<dyn prism_rtl::Job<bool>>>)), doc: type_doc(&lx, &ti) }))
            }))
        }) as Rc<dyn Fn((crate::lower::model::TyShape, Array<crate::lower::model::CaseDef>)) -> Rc<dyn prism_rtl::Job<crate::lower::model::TyDef>>>
    };
    match &ti.body {
        crate::check::env::TyBody::BRecord(fs) => {
            let fields = run_to_end(each_job(crate::check::errors::range0(&len(fs)), {
                let fs = fs.clone();
                let lx = lx.clone();
                let ti = ti.clone();
                Rc::new(move |p0: Nat| {
                    let fs = fs.clone();
                    let lx = lx.clone();
                    let ti = ti.clone();
                    entered(once_job(move || {
                        let i = p0;
                        {
                            let (fname, ft) = or(&index(&fs, &i), &(Text::lit(""), crate::check::types::Ty::TyErr));
                            call_then(crate::lower::types::start_out_ty_of(lx.clone(), ft.clone()), move |out_ty_of_22783: crate::lower::model::OutTy| {
                                let rt = out_ty_of_22783;
                                prism_rtl::Turn::Finished((crate::lower::snake(&fname), if crate::lower::types::rc_field(&lx, &ti.name, &i) {
                                    crate::lower::model::OutTy::OutRc(Rc::new(rt.clone()))
                                } else {
                                    rt.clone()
                                }))
                            })
                        }
                    }))
                }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<(Text, crate::lower::model::OutTy)>>>
            }));
            Array::from(vec![crate::lower::model::Item::ItType(run_to_end((&mk_fn)((crate::lower::model::TyShape::ShapeRecord, Array::from(vec![crate::lower::model::CaseDef { name: crate::lower::camel(&bare), prism: bare.clone(), fields: fields.clone() }])))))])
        },
        crate::check::env::TyBody::BChoice(cases) => {
            let defs = run_to_end(each_job(cases.clone(), {
                let ti = ti.clone();
                let lx = lx.clone();
                Rc::new(move |p0: (Text, Array<crate::check::types::Ty>)| {
                    let ti = ti.clone();
                    let lx = lx.clone();
                    entered(once_job(move || {
                        let (cn, ats) = p0;
                        {
                            let ck = crate::check::env::qual_key(&ti.home, &cn);
                            call_value(each_job(crate::check::errors::range0(&len(&ats)), {
                                let lx = lx.clone();
                                let ck = ck.clone();
                                let ats = ats.clone();
                                Rc::new(move |p0: Nat| {
                                    let lx = lx.clone();
                                    let ck = ck.clone();
                                    let ats = ats.clone();
                                    entered(once_job(move || {
                                        let i = p0;
                                        call_then(start_case_field(lx.clone(), ck.clone(), i.clone(), or(&index(&ats, &i), &crate::check::types::Ty::TyErr)), move |case_field_23191: crate::lower::model::OutTy| prism_rtl::Turn::Finished((Text::lit(""), case_field_23191)))
                                    }))
                                }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<(Text, crate::lower::model::OutTy)>>>
                            }), move |each_23154: Array<(Text, crate::lower::model::OutTy)>| prism_rtl::Turn::Finished(crate::lower::model::CaseDef { name: crate::lower::camel(&cn), prism: cn.clone(), fields: each_23154 }))
                        }
                    }))
                }) as Rc<dyn Fn((Text, Array<crate::check::types::Ty>)) -> Rc<dyn prism_rtl::Job<crate::lower::model::CaseDef>>>
            }));
            let shape = 'm23260: {
                if let m23260_0 = cases && (m23260_0.len() == 1) && let Some((cn, m23260_0_0_1)) = index(m23260_0, &Nat::from(0u32)) && ((&m23260_0_0_1).len() == 0) {
                    break 'm23260 if crate::check::env::is_lower_text(&cn) {
                        crate::lower::model::TyShape::ShapeUnit
                    } else {
                        crate::lower::model::TyShape::ShapeChoice
                    };
                }
                if let m23260_1 = cases && (m23260_1.len() == 1) && let Some((cn, _)) = index(m23260_1, &Nat::from(0u32)) {
                    break 'm23260 if &cn == &bare {
                        crate::lower::model::TyShape::ShapeNewtype
                    } else {
                        crate::lower::model::TyShape::ShapeChoice
                    };
                }
                crate::lower::model::TyShape::ShapeChoice
            };
            Array::from(vec![crate::lower::model::Item::ItType(run_to_end((&mk_fn)((shape.clone(), defs.clone()))))])
        },
        crate::check::env::TyBody::BRowKind => if &ti.name == &Text::lit("Prelude.Fault") {
            Array::new()
        } else {
            Array::from(vec![crate::lower::model::Item::ItRow(row_def_of(lx, ti))])
        },
        _ => Array::new(),
    }
}

/// The step machine of `TyDefs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TyDefs: unbounded fn Lx, TyInfo -> [Item]
/// ```
pub struct TyDefs {
    pub lx: crate::lower::Lx,
    pub ti: crate::check::env::TyInfo,
}

impl prism_rtl::Job<Array<crate::lower::model::Item>> for TyDefs {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::lower::model::Item>> {
        let lx = &self.lx;
        let ti = &self.ti;
        let derives = each(&ti.derives, &(|dn: &Text| crate::check::types::bare_name(dn)));
        let params = each(&ti.params, &(|p_: &Text| crate::lower::camel(p_)));
        let lx = lx.clone();
        let ti = ti.clone();
        call_then(crate::lower::types::start_floaty(lx.g.clone(), crate::check::types::Ty::TyCon(ti.name.clone(), Array::new()), Array::new()), move |floaty_22072: bool| {
            let floaty = floaty_22072;
            let bare = crate::check::types::bare_name(&ti.name);
            let mk_fn = {
                let bare = bare.clone();
                let params = params.clone();
                let derives = derives.clone();
                let floaty = floaty;
                let lx = lx.clone();
                let ti = ti.clone();
                Rc::new(move |(p0, p1): (crate::lower::model::TyShape, Array<crate::lower::model::CaseDef>)| {
                    let bare = bare.clone();
                    let params = params.clone();
                    let derives = derives.clone();
                    let floaty = floaty;
                    let lx = lx.clone();
                    let ti = ti.clone();
                    entered(once_job(move || {
                        let shape = p0;
                        let cases = p1;
                        call_then(start_ty_podable(lx.clone(), crate::check::types::Ty::TyCon(ti.name.clone(), Array::new()), Array::new()), move |ty_podable_22437: bool| prism_rtl::Turn::Finished(crate::lower::model::TyDef { name: crate::lower::camel(&bare), prism: bare.clone(), params: params.clone(), shape: shape.clone(), cases: cases.clone(), eq: crate::check::types::has_text(&derives, &Text::lit("Eq")), ord: crate::check::types::has_text(&derives, &Text::lit("Ord")), floaty, show: if crate::lower::functions::has_own_show(&lx, &ti.name) {
                            crate::lower::model::Shown::ShownOwn
                        } else {
                            if crate::check::types::has_text(&derives, &Text::lit("Show")) {
                                crate::lower::model::Shown::ShownDerived
                            } else {
                                crate::lower::model::Shown::NotShown
                            }
                        }, pod: ty_podable_22437 && run_to_end(fold_job(cases.clone(), true, Rc::new(move |(p0, p1): (bool, crate::lower::model::CaseDef)| entered(once_job(move || {
                            let ok = p0;
                            let c = p1;
                            prism_rtl::Turn::Finished(ok && run_to_end(fold_job(c.fields.clone(), true, Rc::new(move |(p0, p1): (bool, (Text, crate::lower::model::OutTy))| entered(once_job(move || {
                                let ok2 = p0;
                                let (_, ft) = p1;
                                prism_rtl::Turn::Finished(ok2 && crate::lower::types::podable(&ft))
                            }))) as Rc<dyn Fn((bool, (Text, crate::lower::model::OutTy))) -> Rc<dyn prism_rtl::Job<bool>>>)))
                        }))) as Rc<dyn Fn((bool, crate::lower::model::CaseDef)) -> Rc<dyn prism_rtl::Job<bool>>>)), doc: type_doc(&lx, &ti) }))
                    }))
                }) as Rc<dyn Fn((crate::lower::model::TyShape, Array<crate::lower::model::CaseDef>)) -> Rc<dyn prism_rtl::Job<crate::lower::model::TyDef>>>
            };
            match &ti.body {
                crate::check::env::TyBody::BRecord(fs) => {
                    let fs = fs.clone();
                    call_value(each_job(crate::check::errors::range0(&len(&fs)), {
                        let fs = fs.clone();
                        let lx = lx.clone();
                        let ti = ti.clone();
                        Rc::new(move |p0: Nat| {
                            let fs = fs.clone();
                            let lx = lx.clone();
                            let ti = ti.clone();
                            entered(once_job(move || {
                                let i = p0;
                                {
                                    let (fname, ft) = or(&index(&fs, &i), &(Text::lit(""), crate::check::types::Ty::TyErr));
                                    call_then(crate::lower::types::start_out_ty_of(lx.clone(), ft.clone()), move |out_ty_of_22783: crate::lower::model::OutTy| {
                                        let rt = out_ty_of_22783;
                                        prism_rtl::Turn::Finished((crate::lower::snake(&fname), if crate::lower::types::rc_field(&lx, &ti.name, &i) {
                                            crate::lower::model::OutTy::OutRc(Rc::new(rt.clone()))
                                        } else {
                                            rt.clone()
                                        }))
                                    })
                                }
                            }))
                        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<(Text, crate::lower::model::OutTy)>>>
                    }), move |each_22669: Array<(Text, crate::lower::model::OutTy)>| {
                        let fields = each_22669;
                        call_value((&mk_fn)((crate::lower::model::TyShape::ShapeRecord, Array::from(vec![crate::lower::model::CaseDef { name: crate::lower::camel(&bare), prism: bare.clone(), fields: fields.clone() }]))), move |mk_22900: crate::lower::model::TyDef| prism_rtl::Turn::Finished(Array::from(vec![crate::lower::model::Item::ItType(mk_22900)])))
                    })
                },
                crate::check::env::TyBody::BChoice(cases) => {
                    let cases = cases.clone();
                    call_value(each_job(cases.clone(), {
                        let ti = ti.clone();
                        let lx = lx.clone();
                        Rc::new(move |p0: (Text, Array<crate::check::types::Ty>)| {
                            let ti = ti.clone();
                            let lx = lx.clone();
                            entered(once_job(move || {
                                let (cn, ats) = p0;
                                {
                                    let ck = crate::check::env::qual_key(&ti.home, &cn);
                                    call_value(each_job(crate::check::errors::range0(&len(&ats)), {
                                        let lx = lx.clone();
                                        let ck = ck.clone();
                                        let ats = ats.clone();
                                        Rc::new(move |p0: Nat| {
                                            let lx = lx.clone();
                                            let ck = ck.clone();
                                            let ats = ats.clone();
                                            entered(once_job(move || {
                                                let i = p0;
                                                call_then(start_case_field(lx.clone(), ck.clone(), i.clone(), or(&index(&ats, &i), &crate::check::types::Ty::TyErr)), move |case_field_23191: crate::lower::model::OutTy| prism_rtl::Turn::Finished((Text::lit(""), case_field_23191)))
                                            }))
                                        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<(Text, crate::lower::model::OutTy)>>>
                                    }), move |each_23154: Array<(Text, crate::lower::model::OutTy)>| prism_rtl::Turn::Finished(crate::lower::model::CaseDef { name: crate::lower::camel(&cn), prism: cn.clone(), fields: each_23154 }))
                                }
                            }))
                        }) as Rc<dyn Fn((Text, Array<crate::check::types::Ty>)) -> Rc<dyn prism_rtl::Job<crate::lower::model::CaseDef>>>
                    }), move |each_23023: Array<crate::lower::model::CaseDef>| {
                        let defs = each_23023;
                        let shape = 'm23260: {
                            if let m23260_0 = &cases && (m23260_0.len() == 1) && let Some((cn, m23260_0_0_1)) = index(m23260_0, &Nat::from(0u32)) && ((&m23260_0_0_1).len() == 0) {
                                break 'm23260 if crate::check::env::is_lower_text(&cn) {
                                    crate::lower::model::TyShape::ShapeUnit
                                } else {
                                    crate::lower::model::TyShape::ShapeChoice
                                };
                            }
                            if let m23260_1 = &cases && (m23260_1.len() == 1) && let Some((cn, _)) = index(m23260_1, &Nat::from(0u32)) {
                                break 'm23260 if &cn == &bare {
                                    crate::lower::model::TyShape::ShapeNewtype
                                } else {
                                    crate::lower::model::TyShape::ShapeChoice
                                };
                            }
                            crate::lower::model::TyShape::ShapeChoice
                        };
                        call_value((&mk_fn)((shape.clone(), defs.clone())), move |mk_23497: crate::lower::model::TyDef| prism_rtl::Turn::Finished(Array::from(vec![crate::lower::model::Item::ItType(mk_23497)])))
                    })
                },
                crate::check::env::TyBody::BRowKind => if &ti.name == &Text::lit("Prelude.Fault") {
                    prism_rtl::Turn::Finished(Array::new())
                } else {
                    call_then(start_row_def_of(lx.clone(), ti.clone()), move |row_def_of_23584: crate::lower::model::RowDef| prism_rtl::Turn::Finished(Array::from(vec![crate::lower::model::Item::ItRow(row_def_of_23584)])))
                },
                _ => prism_rtl::Turn::Finished(Array::new()),
            }
        })
    }
}

/// `Start TyDefs, x`: what the function value is when passed to `@Run`.
pub fn start_ty_defs(lx: crate::lower::Lx, ti: crate::check::env::TyInfo) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Item>>> {
    Rc::new(TyDefs { lx, ti })
}

/// ```prism
/// TyPodable: unbounded fn Lx, Ty, [Text] -> Bool
/// ```
pub fn ty_podable(lx: &crate::lower::Lx, t: &crate::check::types::Ty, seen: &Array<Text>) -> bool {
    match t {
        crate::check::types::Ty::TyFn(_, _, _) => false,
        crate::check::types::Ty::TyAt(_, _) => false,
        crate::check::types::Ty::TySig(m23905_2_0, _) if (m23905_2_0 == &Text::lit("!")) => false,
        crate::check::types::Ty::TySig(m23905_3_0, _) if (m23905_3_0 == &Text::lit("$")) => false,
        crate::check::types::Ty::TySig(_, i) => ty_podable(lx, &**i, seen),
        crate::check::types::Ty::TyTuple(ts) => run_to_end(fold_job(ts.clone(), true, {
            let lx = lx.clone();
            let seen = seen.clone();
            Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| {
                let lx = lx.clone();
                let seen = seen.clone();
                entered(once_job(move || {
                    let ok = p0;
                    let x = p1;
                    prism_rtl::Turn::Finished(ok && ty_podable(&lx, &x, &seen))
                }))
            }) as Rc<dyn Fn((bool, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<bool>>>
        })),
        crate::check::types::Ty::TyArray(e) => ty_podable(lx, &**e, seen),
        crate::check::types::Ty::TyMap(k, v_) => ty_podable(lx, &**k, seen) && ty_podable(lx, &**v_, seen),
        crate::check::types::Ty::TyCon(n, args) => if crate::check::types::has_text(seen, n) {
            true
        } else {
            {
                let more = push(seen, n);
                let args_ok = run_to_end(fold_job(args.clone(), true, {
                    let lx = lx.clone();
                    let more = more.clone();
                    Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| {
                        let lx = lx.clone();
                        let more = more.clone();
                        entered(once_job(move || {
                            let ok = p0;
                            let x = p1;
                            prism_rtl::Turn::Finished(ok && ty_podable(&lx, &x, &more))
                        }))
                    }) as Rc<dyn Fn((bool, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<bool>>>
                }));
                args_ok && match get(&lx.g.types, n) {
                    Some(ti) => match &ti.body {
                        crate::check::env::TyBody::BRecord(fs) => run_to_end(fold_job(fs.clone(), true, {
                            let lx = lx.clone();
                            let more = more.clone();
                            Rc::new(move |(p0, p1): (bool, (Text, crate::check::types::Ty))| {
                                let lx = lx.clone();
                                let more = more.clone();
                                entered(once_job(move || {
                                    let ok = p0;
                                    let (_, ft) = p1;
                                    prism_rtl::Turn::Finished(ok && ty_podable(&lx, &ft, &more))
                                }))
                            }) as Rc<dyn Fn((bool, (Text, crate::check::types::Ty))) -> Rc<dyn prism_rtl::Job<bool>>>
                        })),
                        crate::check::env::TyBody::BChoice(cs) => run_to_end(fold_job(cs.clone(), true, {
                            let lx = lx.clone();
                            let more = more.clone();
                            Rc::new(move |(p0, p1): (bool, (Text, Array<crate::check::types::Ty>))| {
                                let lx = lx.clone();
                                let more = more.clone();
                                entered(once_job(move || {
                                    let ok = p0;
                                    let (_, ats) = p1;
                                    prism_rtl::Turn::Finished(ok && run_to_end(fold_job(ats.clone(), true, {
                                        let lx = lx.clone();
                                        let more = more.clone();
                                        Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| {
                                            let lx = lx.clone();
                                            let more = more.clone();
                                            entered(once_job(move || {
                                                let ok2 = p0;
                                                let x = p1;
                                                prism_rtl::Turn::Finished(ok2 && ty_podable(&lx, &x, &more))
                                            }))
                                        }) as Rc<dyn Fn((bool, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<bool>>>
                                    })))
                                }))
                            }) as Rc<dyn Fn((bool, (Text, Array<crate::check::types::Ty>))) -> Rc<dyn prism_rtl::Job<bool>>>
                        })),
                        crate::check::env::TyBody::BAlias(a) => ty_podable(lx, a, &more),
                        _ => true,
                    },
                    None => true,
                }
            }
        },
        _ => true,
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `TyPodable`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TyPodable: unbounded fn Lx, Ty, [Text] -> Bool
/// ```
pub struct TyPodable {
    pub lx: crate::lower::Lx,
    pub t: crate::check::types::Ty,
    pub seen: Array<Text>,
}

impl prism_rtl::Job<bool> for TyPodable {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let lx = &self.lx;
        let t = &self.t;
        let seen = &self.seen;
        match t {
            crate::check::types::Ty::TyFn(_, _, _) => prism_rtl::Turn::Finished(false),
            crate::check::types::Ty::TyAt(_, _) => prism_rtl::Turn::Finished(false),
            crate::check::types::Ty::TySig(m23905_2_0, _) if (m23905_2_0 == &Text::lit("!")) => prism_rtl::Turn::Finished(false),
            crate::check::types::Ty::TySig(m23905_3_0, _) if (m23905_3_0 == &Text::lit("$")) => prism_rtl::Turn::Finished(false),
            crate::check::types::Ty::TySig(_, i) => prism_rtl::Turn::More(Rc::new(TyPodable { lx: lx.clone(), t: (**i).clone(), seen: seen.clone() })),
            crate::check::types::Ty::TyTuple(ts) => fold_job(ts.clone(), true, {
                let lx = lx.clone();
                let seen = seen.clone();
                Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| {
                    let lx = lx.clone();
                    let seen = seen.clone();
                    entered(once_job(move || {
                        let ok = p0;
                        let x = p1;
                        prism_rtl::Turn::Finished(ok && ty_podable(&lx, &x, &seen))
                    }))
                }) as Rc<dyn Fn((bool, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<bool>>>
            }).cycle(),
            crate::check::types::Ty::TyArray(e) => prism_rtl::Turn::More(Rc::new(TyPodable { lx: lx.clone(), t: (**e).clone(), seen: seen.clone() })),
            crate::check::types::Ty::TyMap(k, v_) => {
                let k = (**k).clone();
                let lx = lx.clone();
                let seen = seen.clone();
                let v_ = (**v_).clone();
                call_then(start_ty_podable(lx.clone(), k.clone(), seen.clone()), move |ty_podable_24208: bool| prism_rtl::Turn::Finished(ty_podable_24208 && ty_podable(&lx, &v_, &seen)))
            },
            crate::check::types::Ty::TyCon(n, args) => if crate::check::types::has_text(seen, n) {
                prism_rtl::Turn::Finished(true)
            } else {
                {
                    let more = push(seen, n);
                    let args = args.clone();
                    let lx = lx.clone();
                    let n = n.clone();
                    call_value(fold_job(args.clone(), true, {
                        let lx = lx.clone();
                        let more = more.clone();
                        Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| {
                            let lx = lx.clone();
                            let more = more.clone();
                            entered(once_job(move || {
                                let ok = p0;
                                let x = p1;
                                prism_rtl::Turn::Finished(ok && ty_podable(&lx, &x, &more))
                            }))
                        }) as Rc<dyn Fn((bool, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<bool>>>
                    }), move |fold_24384: bool| {
                        let args_ok = fold_24384;
                        prism_rtl::Turn::Finished(args_ok && match get(&lx.g.types, &n) {
                            Some(ti) => match &ti.body {
                                crate::check::env::TyBody::BRecord(fs) => run_to_end(fold_job(fs.clone(), true, {
                                    let lx = lx.clone();
                                    let more = more.clone();
                                    Rc::new(move |(p0, p1): (bool, (Text, crate::check::types::Ty))| {
                                        let lx = lx.clone();
                                        let more = more.clone();
                                        entered(once_job(move || {
                                            let ok = p0;
                                            let (_, ft) = p1;
                                            prism_rtl::Turn::Finished(ok && ty_podable(&lx, &ft, &more))
                                        }))
                                    }) as Rc<dyn Fn((bool, (Text, crate::check::types::Ty))) -> Rc<dyn prism_rtl::Job<bool>>>
                                })),
                                crate::check::env::TyBody::BChoice(cs) => run_to_end(fold_job(cs.clone(), true, {
                                    let lx = lx.clone();
                                    let more = more.clone();
                                    Rc::new(move |(p0, p1): (bool, (Text, Array<crate::check::types::Ty>))| {
                                        let lx = lx.clone();
                                        let more = more.clone();
                                        entered(once_job(move || {
                                            let ok = p0;
                                            let (_, ats) = p1;
                                            prism_rtl::Turn::Finished(ok && run_to_end(fold_job(ats.clone(), true, {
                                                let lx = lx.clone();
                                                let more = more.clone();
                                                Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| {
                                                    let lx = lx.clone();
                                                    let more = more.clone();
                                                    entered(once_job(move || {
                                                        let ok2 = p0;
                                                        let x = p1;
                                                        prism_rtl::Turn::Finished(ok2 && ty_podable(&lx, &x, &more))
                                                    }))
                                                }) as Rc<dyn Fn((bool, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<bool>>>
                                            })))
                                        }))
                                    }) as Rc<dyn Fn((bool, (Text, Array<crate::check::types::Ty>))) -> Rc<dyn prism_rtl::Job<bool>>>
                                })),
                                crate::check::env::TyBody::BAlias(a) => ty_podable(&lx, a, &more),
                                _ => true,
                            },
                            None => true,
                        })
                    })
                }
            },
            _ => prism_rtl::Turn::Finished(true),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start TyPodable, x`: what the function value is when passed to `@Run`.
pub fn start_ty_podable(lx: crate::lower::Lx, t: crate::check::types::Ty, seen: Array<Text>) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(TyPodable { lx, t, seen })
}

/// ```prism
/// TyHasEq: unbounded fn Lx, Ty, [Text] -> Bool
/// ```
pub fn ty_has_eq(lx: &crate::lower::Lx, t: &crate::check::types::Ty, seen: &Array<Text>) -> bool {
    match t {
        crate::check::types::Ty::TyFn(_, _, _) => false,
        crate::check::types::Ty::TyAt(_, _) => false,
        crate::check::types::Ty::TySig(m25338_2_0, _) if (m25338_2_0 == &Text::lit("!")) => false,
        crate::check::types::Ty::TySig(m25338_3_0, _) if (m25338_3_0 == &Text::lit("$")) => false,
        crate::check::types::Ty::TySig(_, i) => ty_has_eq(lx, &**i, seen),
        crate::check::types::Ty::TyTuple(ts) => run_to_end(fold_job(ts.clone(), true, {
            let lx = lx.clone();
            let seen = seen.clone();
            Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| {
                let lx = lx.clone();
                let seen = seen.clone();
                entered(once_job(move || {
                    let ok = p0;
                    let x = p1;
                    prism_rtl::Turn::Finished(ok && ty_has_eq(&lx, &x, &seen))
                }))
            }) as Rc<dyn Fn((bool, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<bool>>>
        })),
        crate::check::types::Ty::TyArray(e) => ty_has_eq(lx, &**e, seen),
        crate::check::types::Ty::TyMap(k, v_) => ty_has_eq(lx, &**k, seen) && ty_has_eq(lx, &**v_, seen),
        crate::check::types::Ty::TyElem(_, _) => true,
        crate::check::types::Ty::TyElemAny(_) => true,
        crate::check::types::Ty::TyCon(n, args) => if crate::check::types::has_text(seen, n) {
            true
        } else {
            {
                let args_ok = run_to_end(fold_job(args.clone(), true, {
                    let lx = lx.clone();
                    let seen = seen.clone();
                    let n = n.clone();
                    Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| {
                        let lx = lx.clone();
                        let seen = seen.clone();
                        let n = n.clone();
                        entered(once_job(move || {
                            let ok = p0;
                            let x = p1;
                            prism_rtl::Turn::Finished(ok && ty_has_eq(&lx, &x, &push(&seen, &n)))
                        }))
                    }) as Rc<dyn Fn((bool, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<bool>>>
                }));
                args_ok && match get(&lx.g.types, n) {
                    Some(ti) => fold(&ti.derives, &false, &(|f: &bool, d: &Text| *f || (&crate::check::types::bare_name(d) == &Text::lit("Eq")))) || has_own_eq(lx, n),
                    None => true,
                }
            }
        },
        _ => false,
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// HasOwnEq: fn Lx, Text -> Bool
/// ```
pub fn has_own_eq(lx: &crate::lower::Lx, tn: &Text) -> bool {
    fold(&or(&get(&lx.g.impls, &Text::lit("Prelude.Eq")), &Array::new()), &false, &(|f: &bool, im: &crate::check::env::ImplInfo| *f || (&crate::lower::functions::head_name(&im.head) == tn)))
}

/// ```prism
/// CaseField: unbounded fn Lx, Text, Nat, Ty -> OutTy
/// ```
pub fn case_field(lx: &crate::lower::Lx, ck: &Text, i: &Nat, t: &crate::check::types::Ty) -> crate::lower::model::OutTy {
    let rt = crate::lower::types::out_ty_of(lx, t);
    if crate::lower::types::rc_field(lx, ck, i) {
        crate::lower::model::OutTy::OutRc(Rc::new(rt.clone()))
    } else {
        rt.clone()
    }
}

/// The step machine of `CaseField`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CaseField: unbounded fn Lx, Text, Nat, Ty -> OutTy
/// ```
pub struct CaseField {
    pub lx: crate::lower::Lx,
    pub ck: Text,
    pub i: Nat,
    pub t: crate::check::types::Ty,
}

impl prism_rtl::Job<crate::lower::model::OutTy> for CaseField {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::OutTy> {
        let lx = &self.lx;
        let ck = &self.ck;
        let i = &self.i;
        let t = &self.t;
        let ck = ck.clone();
        let i = i.clone();
        let lx = lx.clone();
        let t = t.clone();
        call_then(crate::lower::types::start_out_ty_of(lx.clone(), t.clone()), move |out_ty_of_26316: crate::lower::model::OutTy| {
            let rt = out_ty_of_26316;
            if crate::lower::types::rc_field(&lx, &ck, &i) {
                prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutRc(Rc::new(rt.clone())))
            } else {
                prism_rtl::Turn::Finished(rt.clone())
            }
        })
    }
}

/// `Start CaseField, x`: what the function value is when passed to `@Run`.
pub fn start_case_field(lx: crate::lower::Lx, ck: Text, i: Nat, t: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::lower::model::OutTy>> {
    Rc::new(CaseField { lx, ck, i, t })
}

/// ```prism
/// TypeDoc: fn Lx, TyInfo -> Text
/// ```
pub fn type_doc(lx: &crate::lower::Lx, ti: &crate::check::env::TyInfo) -> Text {
    match index(&lx.g.srcs, &ti.file) {
        Some(src) => crate::syntax::lexer::chars::trim(&crate::check::errors::line_text(&src, &crate::check::errors::cline_of(&src.starts, &ti.span.start))),
        None => ti.name.clone(),
    }
}

/// ```prism
/// TagDefOf: unbounded fn Lx, TagInfo -> TagDef
/// ```
pub fn tag_def_of(lx: &crate::lower::Lx, tg: &crate::check::env::TagInfo) -> crate::lower::model::TagDef {
    let fields = run_to_end(each_job(level_fields(tg), {
        let lx = lx.clone();
        Rc::new(move |p0: (Text, crate::check::types::Ty)| {
            let lx = lx.clone();
            entered(once_job(move || {
                let (fname, ft) = p0;
                call_then(crate::lower::types::start_out_ty_of(lx.clone(), crate::lower::types::peel(&ft)), move |out_ty_of_26826: crate::lower::model::OutTy| prism_rtl::Turn::Finished((fname.clone(), crate::lower::snake(&fname), out_ty_of_26826)))
            }))
        }) as Rc<dyn Fn((Text, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<(Text, Text, crate::lower::model::OutTy)>>>
    }));
    crate::lower::model::TagDef { name: crate::lower::tag_struct(&tg.name), tag_name: tg.name.clone(), fields: fields.clone(), doc: type_doc(lx, &crate::check::env::TyInfo { name: tg.name.clone(), home: tg.home.clone(), params: Array::new(), body: crate::check::env::TyBody::BOpaque, derives: Array::new(), file: tg.file.clone(), span: tg.span.clone() }), pod: run_to_end(fold_job(fields.clone(), true, Rc::new(move |(p0, p1): (bool, (Text, Text, crate::lower::model::OutTy))| entered(once_job(move || {
        let ok = p0;
        let (_, _, t) = p1;
        prism_rtl::Turn::Finished(ok && crate::lower::types::podable(&t))
    }))) as Rc<dyn Fn((bool, (Text, Text, crate::lower::model::OutTy))) -> Rc<dyn prism_rtl::Job<bool>>>)) }
}

/// The step machine of `TagDefOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TagDefOf: unbounded fn Lx, TagInfo -> TagDef
/// ```
pub struct TagDefOf {
    pub lx: crate::lower::Lx,
    pub tg: crate::check::env::TagInfo,
}

impl prism_rtl::Job<crate::lower::model::TagDef> for TagDefOf {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::TagDef> {
        let lx = &self.lx;
        let tg = &self.tg;
        let lx = lx.clone();
        let tg = tg.clone();
        call_value(each_job(level_fields(&tg), {
            let lx = lx.clone();
            Rc::new(move |p0: (Text, crate::check::types::Ty)| {
                let lx = lx.clone();
                entered(once_job(move || {
                    let (fname, ft) = p0;
                    call_then(crate::lower::types::start_out_ty_of(lx.clone(), crate::lower::types::peel(&ft)), move |out_ty_of_26826: crate::lower::model::OutTy| prism_rtl::Turn::Finished((fname.clone(), crate::lower::snake(&fname), out_ty_of_26826)))
                }))
            }) as Rc<dyn Fn((Text, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<(Text, Text, crate::lower::model::OutTy)>>>
        }), move |each_26761: Array<(Text, Text, crate::lower::model::OutTy)>| {
            let fields = each_26761;
            call_value(fold_job(fields.clone(), true, Rc::new(move |(p0, p1): (bool, (Text, Text, crate::lower::model::OutTy))| entered(once_job(move || {
                let ok = p0;
                let (_, _, t) = p1;
                prism_rtl::Turn::Finished(ok && crate::lower::types::podable(&t))
            }))) as Rc<dyn Fn((bool, (Text, Text, crate::lower::model::OutTy))) -> Rc<dyn prism_rtl::Job<bool>>>), move |fold_27050: bool| prism_rtl::Turn::Finished(crate::lower::model::TagDef { name: crate::lower::tag_struct(&tg.name), tag_name: tg.name.clone(), fields: fields.clone(), doc: type_doc(&lx, &crate::check::env::TyInfo { name: tg.name.clone(), home: tg.home.clone(), params: Array::new(), body: crate::check::env::TyBody::BOpaque, derives: Array::new(), file: tg.file.clone(), span: tg.span.clone() }), pod: fold_27050 }))
        })
    }
}

/// `Start TagDefOf, x`: what the function value is when passed to `@Run`.
pub fn start_tag_def_of(lx: crate::lower::Lx, tg: crate::check::env::TagInfo) -> Rc<dyn prism_rtl::Job<crate::lower::model::TagDef>> {
    Rc::new(TagDefOf { lx, tg })
}

/// ```prism
/// LevelFields: fn TagInfo -> [((Text, Ty))]
/// ```
pub fn level_fields(tg: &crate::check::env::TagInfo) -> Array<(Text, crate::check::types::Ty)> {
    filter(&tg.fields, &(|(_, ft): &(Text, crate::check::types::Ty)| &crate::lower::types::layer_of(ft) != &crate::lower::types::Layer::LyEv))
}

/// ```prism
/// KindTags: fn Lx, Text, [Text] -> [TagInfo]
/// ```
pub fn kind_tags(lx: &crate::lower::Lx, kind: &Text, mods: &Array<Text>) -> Array<crate::check::env::TagInfo> {
    filter(&values(&lx.g.tags), &(|tg: &crate::check::env::TagInfo| (&tg.kind == kind) && crate::check::types::has_text(mods, &tg.home)))
}

/// ```prism
/// RowDefOf: unbounded fn Lx, TyInfo -> RowDef
/// ```
pub fn row_def_of(lx: &crate::lower::Lx, ti: &crate::check::env::TyInfo) -> crate::lower::model::RowDef {
    let tags = kind_tags(lx, &ti.name, &keys(&lx.rs_mods));
    let cases = each(&tags, &(|tg: &crate::check::env::TagInfo| (crate::lower::tag_struct(&tg.name), crate::lower::path_in(lx, &tg.home, &crate::lower::tag_struct(&tg.name)))));
    let pod = run_to_end(fold_job(tags.clone(), true, {
        let lx = lx.clone();
        Rc::new(move |(p0, p1): (bool, crate::check::env::TagInfo)| {
            let lx = lx.clone();
            entered(once_job(move || {
                let ok = p0;
                let tg = p1;
                prism_rtl::Turn::Finished(ok && tag_def_of(&lx, &tg).pod)
            }))
        }) as Rc<dyn Fn((bool, crate::check::env::TagInfo)) -> Rc<dyn prism_rtl::Job<bool>>>
    }));
    crate::lower::model::RowDef { name: crate::lower::camel(&crate::check::types::bare_name(&ti.name)), prism: ti.name.clone(), cases: cases.clone(), pod, doc: type_doc(lx, ti) }
}

/// The step machine of `RowDefOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RowDefOf: unbounded fn Lx, TyInfo -> RowDef
/// ```
pub struct RowDefOf {
    pub lx: crate::lower::Lx,
    pub ti: crate::check::env::TyInfo,
}

impl prism_rtl::Job<crate::lower::model::RowDef> for RowDefOf {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::RowDef> {
        let lx = &self.lx;
        let ti = &self.ti;
        let tags = kind_tags(lx, &ti.name, &keys(&lx.rs_mods));
        let cases = each(&tags, &(|tg: &crate::check::env::TagInfo| (crate::lower::tag_struct(&tg.name), crate::lower::path_in(lx, &tg.home, &crate::lower::tag_struct(&tg.name)))));
        let lx = lx.clone();
        let ti = ti.clone();
        call_value(fold_job(tags.clone(), true, {
            let lx = lx.clone();
            Rc::new(move |(p0, p1): (bool, crate::check::env::TagInfo)| {
                let lx = lx.clone();
                entered(once_job(move || {
                    let ok = p0;
                    let tg = p1;
                    prism_rtl::Turn::Finished(ok && tag_def_of(&lx, &tg).pod)
                }))
            }) as Rc<dyn Fn((bool, crate::check::env::TagInfo)) -> Rc<dyn prism_rtl::Job<bool>>>
        }), move |fold_27764: bool| {
            let pod = fold_27764;
            prism_rtl::Turn::Finished(crate::lower::model::RowDef { name: crate::lower::camel(&crate::check::types::bare_name(&ti.name)), prism: ti.name.clone(), cases: cases.clone(), pod, doc: type_doc(&lx, &ti) })
        })
    }
}

/// `Start RowDefOf, x`: what the function value is when passed to `@Run`.
pub fn start_row_def_of(lx: crate::lower::Lx, ti: crate::check::env::TyInfo) -> Rc<dyn prism_rtl::Job<crate::lower::model::RowDef>> {
    Rc::new(RowDefOf { lx, ti })
}

/// ```prism
/// ElemRow: unbounded fn Lx, [Text] -> RowDef
/// ```
pub fn elem_row(lx: &crate::lower::Lx, mods: &Array<Text>) -> crate::lower::model::RowDef {
    let tags = kind_tags(lx, &Text::lit("Element"), &push(mods, &Text::lit("Prelude")));
    let cases = each(&tags, &(|tg: &crate::check::env::TagInfo| (crate::lower::tag_struct(&tg.name), Text::from(format!("{}::{}", &crate::lower::rust_mod_name(&tg.home), &crate::lower::tag_struct(&tg.name))))));
    let pod = run_to_end(fold_job(tags.clone(), true, {
        let lx = lx.clone();
        Rc::new(move |(p0, p1): (bool, crate::check::env::TagInfo)| {
            let lx = lx.clone();
            entered(once_job(move || {
                let ok = p0;
                let tg = p1;
                prism_rtl::Turn::Finished(ok && tag_def_of(&lx, &tg).pod)
            }))
        }) as Rc<dyn Fn((bool, crate::check::env::TagInfo)) -> Rc<dyn prism_rtl::Job<bool>>>
    }));
    crate::lower::model::RowDef { name: Text::lit("Elem"), prism: Text::lit("Elem"), cases: cases.clone(), pod, doc: Text::lit("`Elem r`: an element as a document holds it, its `Level` in a tick.") }
}

/// The step machine of `ElemRow`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ElemRow: unbounded fn Lx, [Text] -> RowDef
/// ```
pub struct ElemRow {
    pub lx: crate::lower::Lx,
    pub mods: Array<Text>,
}

impl prism_rtl::Job<crate::lower::model::RowDef> for ElemRow {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::RowDef> {
        let lx = &self.lx;
        let mods = &self.mods;
        let tags = kind_tags(lx, &Text::lit("Element"), &push(mods, &Text::lit("Prelude")));
        let cases = each(&tags, &(|tg: &crate::check::env::TagInfo| (crate::lower::tag_struct(&tg.name), Text::from(format!("{}::{}", &crate::lower::rust_mod_name(&tg.home), &crate::lower::tag_struct(&tg.name))))));
        let lx = lx.clone();
        call_value(fold_job(tags.clone(), true, {
            let lx = lx.clone();
            Rc::new(move |(p0, p1): (bool, crate::check::env::TagInfo)| {
                let lx = lx.clone();
                entered(once_job(move || {
                    let ok = p0;
                    let tg = p1;
                    prism_rtl::Turn::Finished(ok && tag_def_of(&lx, &tg).pod)
                }))
            }) as Rc<dyn Fn((bool, crate::check::env::TagInfo)) -> Rc<dyn prism_rtl::Job<bool>>>
        }), move |fold_28366: bool| {
            let pod = fold_28366;
            prism_rtl::Turn::Finished(crate::lower::model::RowDef { name: Text::lit("Elem"), prism: Text::lit("Elem"), cases: cases.clone(), pod, doc: Text::lit("`Elem r`: an element as a document holds it, its `Level` in a tick.") })
        })
    }
}

/// `Start ElemRow, x`: what the function value is when passed to `@Run`.
pub fn start_elem_row(lx: crate::lower::Lx, mods: Array<Text>) -> Rc<dyn prism_rtl::Job<crate::lower::model::RowDef>> {
    Rc::new(ElemRow { lx, mods })
}

/// ```prism
/// AnswerEnum: unbounded fn Lx, [Text] -> AnswerDef
/// ```
pub fn answer_enum(lx: &crate::lower::Lx, mods: &Array<Text>) -> crate::lower::model::AnswerDef {
    let tags = kind_tags(lx, &Text::lit("Element"), &push(mods, &Text::lit("Prelude")));
    crate::lower::model::AnswerDef { cases: run_to_end(each_job(tags.clone(), {
        let lx = lx.clone();
        Rc::new(move |p0: crate::check::env::TagInfo| {
            let lx = lx.clone();
            entered(once_job(move || {
                let tg = p0;
                call_then(start_answer_ty(lx.clone(), tg.clone()), move |answer_ty_28957: crate::lower::model::OutTy| prism_rtl::Turn::Finished(crate::lower::model::AnswerCase { variant: crate::lower::tag_struct(&tg.name), accessor: crate::lower::node_::elements::answer_accessor(&tg), struct_path: Text::from(format!("{}::{}", &crate::lower::rust_mod_name(&tg.home), &crate::lower::tag_struct(&tg.name))), tag_name: tg.name.clone(), ty: answer_ty_28957 }))
            }))
        }) as Rc<dyn Fn(crate::check::env::TagInfo) -> Rc<dyn prism_rtl::Job<crate::lower::model::AnswerCase>>>
    })) }
}

/// The step machine of `AnswerEnum`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// AnswerEnum: unbounded fn Lx, [Text] -> AnswerDef
/// ```
pub struct AnswerEnum {
    pub lx: crate::lower::Lx,
    pub mods: Array<Text>,
}

impl prism_rtl::Job<crate::lower::model::AnswerDef> for AnswerEnum {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::AnswerDef> {
        let lx = &self.lx;
        let mods = &self.mods;
        let tags = kind_tags(lx, &Text::lit("Element"), &push(mods, &Text::lit("Prelude")));
        let lx = lx.clone();
        call_value(each_job(tags.clone(), {
            let lx = lx.clone();
            Rc::new(move |p0: crate::check::env::TagInfo| {
                let lx = lx.clone();
                entered(once_job(move || {
                    let tg = p0;
                    call_then(start_answer_ty(lx.clone(), tg.clone()), move |answer_ty_28957: crate::lower::model::OutTy| prism_rtl::Turn::Finished(crate::lower::model::AnswerCase { variant: crate::lower::tag_struct(&tg.name), accessor: crate::lower::node_::elements::answer_accessor(&tg), struct_path: Text::from(format!("{}::{}", &crate::lower::rust_mod_name(&tg.home), &crate::lower::tag_struct(&tg.name))), tag_name: tg.name.clone(), ty: answer_ty_28957 }))
                }))
            }) as Rc<dyn Fn(crate::check::env::TagInfo) -> Rc<dyn prism_rtl::Job<crate::lower::model::AnswerCase>>>
        }), move |each_28792: Array<crate::lower::model::AnswerCase>| prism_rtl::Turn::Finished(crate::lower::model::AnswerDef { cases: each_28792 }))
    }
}

/// `Start AnswerEnum, x`: what the function value is when passed to `@Run`.
pub fn start_answer_enum(lx: crate::lower::Lx, mods: Array<Text>) -> Rc<dyn prism_rtl::Job<crate::lower::model::AnswerDef>> {
    Rc::new(AnswerEnum { lx, mods })
}

/// ```prism
/// AnswerTy: unbounded fn Lx, TagInfo -> OutTy
/// ```
pub fn answer_ty(lx: &crate::lower::Lx, tg: &crate::check::env::TagInfo) -> crate::lower::model::OutTy {
    let out = crate::lower::types::peel(&tg.out);
    let part = match &out {
        crate::check::types::Ty::TyTuple(cs) => fold(cs, &out, &(|found: &crate::check::types::Ty, c: &crate::check::types::Ty| if &crate::lower::types::layer_of(c) == &crate::lower::types::Layer::LyEv {
            crate::lower::types::peel(c)
        } else {
            found.clone()
        })),
        _ => out.clone(),
    };
    match crate::lower::types::out_ty_of(lx, &part) {
        crate::lower::model::OutTy::OutGen(_) => crate::lower::model::OutTy::OutPod,
        t => t.clone(),
    }
}

/// The step machine of `AnswerTy`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// AnswerTy: unbounded fn Lx, TagInfo -> OutTy
/// ```
pub struct AnswerTy {
    pub lx: crate::lower::Lx,
    pub tg: crate::check::env::TagInfo,
}

impl prism_rtl::Job<crate::lower::model::OutTy> for AnswerTy {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::OutTy> {
        let lx = &self.lx;
        let tg = &self.tg;
        let out = crate::lower::types::peel(&tg.out);
        let part = match &out {
            crate::check::types::Ty::TyTuple(cs) => fold(cs, &out, &(|found: &crate::check::types::Ty, c: &crate::check::types::Ty| if &crate::lower::types::layer_of(c) == &crate::lower::types::Layer::LyEv {
                crate::lower::types::peel(c)
            } else {
                found.clone()
            })),
            _ => out.clone(),
        };
        let lx = lx.clone();
        call_then(crate::lower::types::start_out_ty_of(lx.clone(), part.clone()), move |out_ty_of_29484: crate::lower::model::OutTy| match out_ty_of_29484 {
            crate::lower::model::OutTy::OutGen(_) => prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutPod),
            t => prism_rtl::Turn::Finished(t.clone()),
        })
    }
}

/// `Start AnswerTy, x`: what the function value is when passed to `@Run`.
pub fn start_answer_ty(lx: crate::lower::Lx, tg: crate::check::env::TagInfo) -> Rc<dyn prism_rtl::Job<crate::lower::model::OutTy>> {
    Rc::new(AnswerTy { lx, tg })
}

/// ```prism
/// TagPaths: fn Lx, TagInfo -> ((Text, Text))
/// ```
pub fn tag_paths(lx: &crate::lower::Lx, tg: &crate::check::env::TagInfo) -> (Text, Text) {
    let st = crate::lower::tag_struct(&tg.name);
    let struct_path = crate::lower::path_in(lx, &tg.home, &st);
    (Text::from(format!("{}::{}", &kind_path(lx, &tg.kind), &st)), struct_path.clone())
}

/// ```prism
/// VariantOf: fn Lx, TagInfo -> Text
/// ```
pub fn variant_of(lx: &crate::lower::Lx, tg: &crate::check::env::TagInfo) -> Text {
    Text::from(format!("{}::{}", &kind_path(lx, &tg.kind), &crate::lower::tag_struct(&tg.name)))
}

/// ```prism
/// KindPath: fn Lx, Text -> Text
/// ```
pub fn kind_path(lx: &crate::lower::Lx, kind: &Text) -> Text {
    if kind == &Text::lit("Element") {
        Text::lit("crate::Elem")
    } else {
        crate::lower::path_in(lx, &or(&get(&lx.g.types, kind), &crate::check::env::names::dummy_ty_info()).home, &crate::lower::camel(&crate::check::types::bare_name(kind)))
    }
}

/// ```prism
/// CheckDefOf: unbounded fn Lx, CheckDecl -> CheckDef
/// ```
pub fn check_def_of(lx: &crate::lower::Lx, c: &crate::syntax::decls::CheckDecl) -> crate::lower::model::CheckDef {
    crate::lower::model::CheckDef { name: c.name.name.clone(), lines: run_to_end(each_job(c.lines.clone(), {
        let lx = lx.clone();
        Rc::new(move |p0: crate::syntax::decls::CheckLine| {
            let lx = lx.clone();
            entered(once_job(move || {
                let l = p0;
                call_then(crate::lower::expr::start_value_of(lx.clone(), crate::lower::types::empty_env(), l.expr.clone()), move |value_of_30332: crate::lower::types::Vl| prism_rtl::Turn::Finished(crate::lower::model::Ex::XCtor(Text::lit("Ok"), Array::from(vec![crate::lower::model::Ex::XMethod(Rc::new(crate::lower::types::own(&value_of_30332)), Text::lit("to_pod"), Array::new())]))))
            }))
        }) as Rc<dyn Fn(crate::syntax::decls::CheckLine) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
    })) }
}

/// The step machine of `CheckDefOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CheckDefOf: unbounded fn Lx, CheckDecl -> CheckDef
/// ```
pub struct CheckDefOf {
    pub lx: crate::lower::Lx,
    pub c: crate::syntax::decls::CheckDecl,
}

impl prism_rtl::Job<crate::lower::model::CheckDef> for CheckDefOf {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::CheckDef> {
        let lx = &self.lx;
        let c = &self.c;
        let c = c.clone();
        let lx = lx.clone();
        call_value(each_job(c.lines.clone(), {
            let lx = lx.clone();
            Rc::new(move |p0: crate::syntax::decls::CheckLine| {
                let lx = lx.clone();
                entered(once_job(move || {
                    let l = p0;
                    call_then(crate::lower::expr::start_value_of(lx.clone(), crate::lower::types::empty_env(), l.expr.clone()), move |value_of_30332: crate::lower::types::Vl| prism_rtl::Turn::Finished(crate::lower::model::Ex::XCtor(Text::lit("Ok"), Array::from(vec![crate::lower::model::Ex::XMethod(Rc::new(crate::lower::types::own(&value_of_30332)), Text::lit("to_pod"), Array::new())]))))
                }))
            }) as Rc<dyn Fn(crate::syntax::decls::CheckLine) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
        }), move |each_30284: Array<crate::lower::model::Ex>| prism_rtl::Turn::Finished(crate::lower::model::CheckDef { name: c.name.name.clone(), lines: each_30284 }))
    }
}

/// `Start CheckDefOf, x`: what the function value is when passed to `@Run`.
pub fn start_check_def_of(lx: crate::lower::Lx, c: crate::syntax::decls::CheckDecl) -> Rc<dyn prism_rtl::Job<crate::lower::model::CheckDef>> {
    Rc::new(CheckDefOf { lx, c })
}
