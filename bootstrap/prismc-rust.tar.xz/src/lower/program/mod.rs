//! The module `Lower.Program`, from `target/bootstrap/src/prismc/lower/program.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// ```prism
/// InModule: fn Lx, Nat, Text -> Lx
/// ```
pub fn in_module(lx_p0: &crate::lower::Lx, file_p1: &Nat, home_p2: &Text) -> crate::lower::Lx {
    let mut this: crate::lower::Lx = lx_p0.clone();
    this.file = file_p1.clone();
    this.home = home_p2.clone();
    this.site = home_p2.clone();
    this
}

/// ```prism
/// InModuleAt: fn Lx, Nat, Text, Text -> Lx
/// ```
pub fn in_module_at(lx_p0: &crate::lower::Lx, file_p1: &Nat, home_p2: &Text, site_p3: &Text) -> crate::lower::Lx {
    let mut this: crate::lower::Lx = lx_p0.clone();
    this.file = file_p1.clone();
    this.home = home_p2.clone();
    this.site = site_p3.clone();
    this
}

/// ```prism
/// LowerProgram: unbounded fn [Src], [Module], Nat, TProgram, Text -> Model
/// ```
pub fn lower_program(srcs_p0: &Array<crate::check::errors::Src>, trees_p1: &Array<crate::syntax::Module>, shown_p2: &Nat, tp_p3: &crate::check::typed::TProgram, name_p4: &Text) -> crate::lower::model::Model {
    let (g_pt, _) = crate::check::env::build_g(srcs_p0, trees_p1);
    let (tys_pu, apps_pv, bs_p10, ims_p11) = crate::lower::typed_tables(tp_p3);
    let gens_p5 = fold(&tp_p3.gens, &Map::new(), &(|m_p12: &Map<Text, crate::check::typed::GenNote>, n_p13: &crate::check::typed::GenNote| insert(m_p12, &crate::check::typed::at_key(&n_p13.at), n_p13)));
    let insts_p6 = fold(&tp_p3.insts, &Map::new(), &(|m_p14: &Map<Text, Array<crate::check::typed::InstNote>>, n_p15: &crate::check::typed::InstNote| insert(m_p14, &crate::lower::expr::inst_key(n_p15), &push(&or(&get(m_p14, &crate::lower::expr::inst_key(n_p15)), &Array::new()), n_p15))));
    let quants_p7 = fold(&tp_p3.gens, &Map::new(), &(|m_p16: &Map<Text, Text>, n_p17: &crate::check::typed::GenNote| fold(&append(&n_p17.tys, &n_p17.cols), m_p16, &(|m2_p18: &Map<Text, Text>, q_p19: &Text| insert(m2_p18, q_p19, &n_p17.name)))));
    let gen_of_q_p8 = fold(&tp_p3.gens, &Map::new(), &(|m_p1a: &Map<Text, crate::check::typed::GenNote>, n_p1b: &crate::check::typed::GenNote| fold(&append(&n_p1b.tys, &n_p1b.cols), m_p1a, &(|m2_p1c: &Map<Text, crate::check::typed::GenNote>, q_p1d: &Text| insert(m2_p1c, q_p1d, n_p1b)))));
    let use_insts_p9 = fold(&tp_p3.insts, &Map::new(), &(|m_p1e: &Map<Text, crate::check::typed::InstNote>, n_p1f: &crate::check::typed::InstNote| insert(m_p1e, &crate::check::typed::at_key(&n_p1f.at), n_p1f)));
    let mods_pa = needed_mods(&g_pt, shown_p2);
    let rs_mods_pb = fold(&mods_pa, &Map::new(), &(|acc_p1g: &Map<Text, Text>, m_p1h: &Text| insert(acc_p1g, m_p1h, &crate::lower::rust_mod_name(m_p1h))));
    let mod_segments_pc = fold(&values(&rs_mods_pb), &Map::new(), &(|acc_p1i: &Map<Text, bool>, p_p1j: &Text| fold(&split_on(p_p1j, &Text::lit("::")), acc_p1i, &(|a2_p1k: &Map<Text, bool>, seg_p1l: &Text| insert(a2_p1k, seg_p1l, &true)))));
    let lx0_pd = crate::lower::Lx { g: g_pt.clone(), tys: tys_pu.clone(), apps: apps_pv.clone(), lifts: fold(&tp_p3.lifts, &Map::new(), &(|m_p1m: &Map<Text, crate::check::typed::LiftNote>, n_p1n: &crate::check::typed::LiftNote| insert(m_p1m, &crate::check::typed::at_key(&n_p1n.at), n_p1n))), binders: bs_p10.clone(), impls: ims_p11.clone(), file: Nat::from(0u32), home: Text::lit(""), site: Text::lit(""), rs_mods: rs_mods_pb.clone(), mod_segments: mod_segments_pc.clone(), rs_names: crate::lower::value_names(&g_pt), layouts: crate::lower::types::layouts(&g_pt), unbs: Array::new(), notes: Array::new(), globals: crate::lower::global_names(&g_pt), in_node: false, unshrunk: fold(&tp_p3.unshrunk, &Map::new(), &(|m_p1o: &Map<Text, bool>, a_p1p: &crate::check::typed::SrcAt| insert(m_p1o, &crate::check::typed::at_key(a_p1p), &true))), gens: gens_p5.clone(), insts: insts_p6.clone(), quants: quants_p7.clone(), gen_of_q: gen_of_q_p8.clone(), use_insts: use_insts_p9.clone(), local_ids: fold(&tp_p3.locals, &Map::new(), &(|m_p1q: &Map<Text, Nat>, n_p1r: &crate::check::typed::LocalNote| insert(m_p1q, &crate::check::typed::at_key(&n_p1r.at), &n_p1r.id))), use_ids: fold(&tp_p3.uses, &Map::new(), &(|m_p1s: &Map<Text, Nat>, n_p1t: &crate::check::typed::LocalNote| insert(m_p1s, &crate::check::typed::at_key(&n_p1t.at), &n_p1t.id))), subst: Map::new(), csubst: Map::new() };
    let lx_pe = {
        let mut this: crate::lower::Lx = lx0_pd.clone();
        this.unbs = job_roots(&lx0_pd);
        this
    };
    let roots_pf = root_widgets(&lx_pe);
    let mod_defs_pg = run_to_end(each_job(mods_pa.clone(), {
        let lx_pe = lx_pe.clone();
        let roots_pf = roots_pf.clone();
        let g_pt = g_pt.clone();
        let mods_pa = mods_pa.clone();
        Rc::new(move |p0: Text| {
            let lx_pe = lx_pe.clone();
            let roots_pf = roots_pf.clone();
            let g_pt = g_pt.clone();
            let mods_pa = mods_pa.clone();
            entered(once_job(move || {
                let m_p1u = p0;
                prism_rtl::Turn::More(Rc::new(ModDefOf { lx0_p0: lx_pe.clone(), m_p1: m_p1u.clone(), roots_p2: roots_pf.clone(), info_p3: or(&get(&g_pt.mods, &m_p1u), &crate::check::env::reading::dummy_mod()), mods_p4: mods_pa.clone() }))
            }))
        }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<crate::lower::model::ModDef>>>
    }));
    let programs_ph = run_to_end(each_job(roots_pf.clone(), {
        let lx_pe = lx_pe.clone();
        Rc::new(move |p0: (Text, bool)| {
            let lx_pe = lx_pe.clone();
            entered(once_job(move || {
                let (qk_p1v, _) = p0;
                prism_rtl::Turn::More(Rc::new(ProgDefOf { lx_p0: lx_pe.clone(), qk_p1: qk_p1v.clone() }))
            }))
        }) as Rc<dyn Fn((Text, bool)) -> Rc<dyn prism_rtl::Job<crate::lower::model::ProgDef>>>
    }));
    let main_qk_pi = fold(&g_pt.defs, &Text::lit(""), &(|found_p20: &Text, d_p21: &crate::check::env::Def| if (found_p20 == &Text::lit("")) && is_main(&d_p21.qk) {
        d_p21.qk.clone()
    } else {
        found_p20.clone()
    }));
    let root_oj = if &main_qk_pi == &Text::lit("") {
        None
    } else {
        Some(prog_def_of(&lx_pe, &main_qk_pi))
    };
    let checks_pk = run_to_end(fold_job(g_pt.defs.clone(), Array::new(), {
        let lx_pe = lx_pe.clone();
        Rc::new(move |(p0, p1): (Array<crate::lower::model::CheckDef>, crate::check::env::Def)| {
            let lx_pe = lx_pe.clone();
            entered(once_job(move || {
                let acc_p22 = p0;
                let d_p23 = p1;
                match &d_p23.body {
                    crate::check::env::DefBody::DbCheck(c_p24) => {
                        let c_p24 = c_p24.clone();
                        call_then(start_check_def_of(in_module_at(&lx_pe, &d_p23.file, &d_p23.home, &Text::lit("\0main")), c_p24.clone()), move |check_def_of_3751: crate::lower::model::CheckDef| prism_rtl::Turn::Finished(push(&acc_p22, &check_def_of_3751)))
                    },
                    _ => prism_rtl::Turn::Finished(acc_p22.clone()),
                }
            }))
        }) as Rc<dyn Fn((Array<crate::lower::model::CheckDef>, crate::check::env::Def)) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::CheckDef>>>>
    }));
    let with_needs_pl = with_groups(&with_needs(&g_pt, srcs_p0, tp_p3, &mod_defs_pg));
    let elem_pm = elem_row(&lx_pe, &mods_pa);
    let answer_pn = answer_enum(&in_module_at(&lx_pe, &Nat::from(0u32), &Text::lit(""), &Text::lit("\0main")), &mods_pa);
    let names_po = each(&with_needs_pl, &(|d_p25: &crate::lower::model::ModDef| d_p25.name.clone()));
    let value_tys_pp = value_types(&with_needs_pl);
    let elem_held_pq = fold(&elem_pm.cases, &Array::new(), &(|acc_p26: &Array<Text>, (_, sp_p27): &(Text, Text)| crate::check::types::union_texts(acc_p26, &held_in(&names_po, &value_tys_pp, &Text::lit(""), &crate::lower::model::OutTy::OutNamed(sp_p27.clone(), Array::new())))));
    let answer_held_pr = fold(&answer_pn.cases, &elem_held_pq, &(|acc_p28: &Array<Text>, k_p29: &crate::lower::model::AnswerCase| crate::check::types::union_texts(acc_p28, &held_in(&names_po, &value_tys_pp, &Text::lit(""), &k_p29.ty))));
    let answer_named_ps = fold(&answer_pn.cases, &Array::new(), &(|acc_p2a: &Array<Text>, k_p2b: &crate::lower::model::AnswerCase| crate::check::types::union_texts(acc_p2a, &named_in(&names_po, &Text::lit(""), &k_p2b.ty))));
    crate::lower::model::Model { name: name_p4.clone(), mods: with_needs_pl.clone(), programs: programs_ph.clone(), root: root_oj.clone(), checks: checks_pk.clone(), elem: elem_pm.clone(), answer: answer_pn.clone(), elem_complete: answer_held_pr.clone(), elem_declared: crate::check::types::minus_texts(&answer_named_ps, &answer_held_pr), scripts: Array::new(), notes: Array::new() }
}

/// The step machine of `LowerProgram`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LowerProgram: unbounded fn [Src], [Module], Nat, TProgram, Text -> Model
/// ```
pub struct LowerProgram {
    pub srcs_p0: Array<crate::check::errors::Src>,
    pub trees_p1: Array<crate::syntax::Module>,
    pub shown_p2: Nat,
    pub tp_p3: crate::check::typed::TProgram,
    pub name_p4: Text,
}

impl prism_rtl::Job<crate::lower::model::Model> for LowerProgram {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::Model> {
        let srcs_p0 = &self.srcs_p0;
        let trees_p1 = &self.trees_p1;
        let shown_p2 = &self.shown_p2;
        let tp_p3 = &self.tp_p3;
        let name_p4 = &self.name_p4;
        let name_p4 = name_p4.clone();
        let shown_p2 = shown_p2.clone();
        let srcs_p0 = srcs_p0.clone();
        let tp_p3 = tp_p3.clone();
        let trees_p1 = trees_p1.clone();
        call_then(crate::check::env::start_build_g(srcs_p0.clone(), trees_p1.clone()), move |build_g_1920: (crate::check::env::G, crate::check::types::St)| {
            let (g_pt, _) = build_g_1920;
            let (tys_pu, apps_pv, bs_p10, ims_p11) = crate::lower::typed_tables(&tp_p3);
            let gens_p5 = fold(&tp_p3.gens, &Map::new(), &(|m_p12: &Map<Text, crate::check::typed::GenNote>, n_p13: &crate::check::typed::GenNote| insert(m_p12, &crate::check::typed::at_key(&n_p13.at), n_p13)));
            let insts_p6 = fold(&tp_p3.insts, &Map::new(), &(|m_p14: &Map<Text, Array<crate::check::typed::InstNote>>, n_p15: &crate::check::typed::InstNote| insert(m_p14, &crate::lower::expr::inst_key(n_p15), &push(&or(&get(m_p14, &crate::lower::expr::inst_key(n_p15)), &Array::new()), n_p15))));
            let quants_p7 = fold(&tp_p3.gens, &Map::new(), &(|m_p16: &Map<Text, Text>, n_p17: &crate::check::typed::GenNote| fold(&append(&n_p17.tys, &n_p17.cols), m_p16, &(|m2_p18: &Map<Text, Text>, q_p19: &Text| insert(m2_p18, q_p19, &n_p17.name)))));
            let gen_of_q_p8 = fold(&tp_p3.gens, &Map::new(), &(|m_p1a: &Map<Text, crate::check::typed::GenNote>, n_p1b: &crate::check::typed::GenNote| fold(&append(&n_p1b.tys, &n_p1b.cols), m_p1a, &(|m2_p1c: &Map<Text, crate::check::typed::GenNote>, q_p1d: &Text| insert(m2_p1c, q_p1d, n_p1b)))));
            let use_insts_p9 = fold(&tp_p3.insts, &Map::new(), &(|m_p1e: &Map<Text, crate::check::typed::InstNote>, n_p1f: &crate::check::typed::InstNote| insert(m_p1e, &crate::check::typed::at_key(&n_p1f.at), n_p1f)));
            call_then(start_needed_mods(g_pt.clone(), shown_p2.clone()), move |needed_mods_2446: Array<Text>| {
                let mods_pa = needed_mods_2446;
                let rs_mods_pb = fold(&mods_pa, &Map::new(), &(|acc_p1g: &Map<Text, Text>, m_p1h: &Text| insert(acc_p1g, m_p1h, &crate::lower::rust_mod_name(m_p1h))));
                let mod_segments_pc = fold(&values(&rs_mods_pb), &Map::new(), &(|acc_p1i: &Map<Text, bool>, p_p1j: &Text| fold(&split_on(p_p1j, &Text::lit("::")), acc_p1i, &(|a2_p1k: &Map<Text, bool>, seg_p1l: &Text| insert(a2_p1k, seg_p1l, &true)))));
                call_then(crate::lower::types::start_layouts(g_pt.clone()), move |layouts_2884: Map<Text, Array<bool>>| {
                    let lx0_pd = crate::lower::Lx { g: g_pt.clone(), tys: tys_pu.clone(), apps: apps_pv.clone(), lifts: fold(&tp_p3.lifts, &Map::new(), &(|m_p1m: &Map<Text, crate::check::typed::LiftNote>, n_p1n: &crate::check::typed::LiftNote| insert(m_p1m, &crate::check::typed::at_key(&n_p1n.at), n_p1n))), binders: bs_p10.clone(), impls: ims_p11.clone(), file: Nat::from(0u32), home: Text::lit(""), site: Text::lit(""), rs_mods: rs_mods_pb.clone(), mod_segments: mod_segments_pc.clone(), rs_names: crate::lower::value_names(&g_pt), layouts: layouts_2884, unbs: Array::new(), notes: Array::new(), globals: crate::lower::global_names(&g_pt), in_node: false, unshrunk: fold(&tp_p3.unshrunk, &Map::new(), &(|m_p1o: &Map<Text, bool>, a_p1p: &crate::check::typed::SrcAt| insert(m_p1o, &crate::check::typed::at_key(a_p1p), &true))), gens: gens_p5.clone(), insts: insts_p6.clone(), quants: quants_p7.clone(), gen_of_q: gen_of_q_p8.clone(), use_insts: use_insts_p9.clone(), local_ids: fold(&tp_p3.locals, &Map::new(), &(|m_p1q: &Map<Text, Nat>, n_p1r: &crate::check::typed::LocalNote| insert(m_p1q, &crate::check::typed::at_key(&n_p1r.at), &n_p1r.id))), use_ids: fold(&tp_p3.uses, &Map::new(), &(|m_p1s: &Map<Text, Nat>, n_p1t: &crate::check::typed::LocalNote| insert(m_p1s, &crate::check::typed::at_key(&n_p1t.at), &n_p1t.id))), subst: Map::new(), csubst: Map::new() };
                    let lx_pe = {
                        let mut this: crate::lower::Lx = lx0_pd.clone();
                        this.unbs = job_roots(&lx0_pd);
                        this
                    };
                    let roots_pf = root_widgets(&lx_pe);
                    call_value(each_job(mods_pa.clone(), {
                        let lx_pe = lx_pe.clone();
                        let roots_pf = roots_pf.clone();
                        let g_pt = g_pt.clone();
                        let mods_pa = mods_pa.clone();
                        Rc::new(move |p0: Text| {
                            let lx_pe = lx_pe.clone();
                            let roots_pf = roots_pf.clone();
                            let g_pt = g_pt.clone();
                            let mods_pa = mods_pa.clone();
                            entered(once_job(move || {
                                let m_p1u = p0;
                                prism_rtl::Turn::More(Rc::new(ModDefOf { lx0_p0: lx_pe.clone(), m_p1: m_p1u.clone(), roots_p2: roots_pf.clone(), info_p3: or(&get(&g_pt.mods, &m_p1u), &crate::check::env::reading::dummy_mod()), mods_p4: mods_pa.clone() }))
                            }))
                        }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<crate::lower::model::ModDef>>>
                    }), move |each_3360: Array<crate::lower::model::ModDef>| {
                        let mod_defs_pg = each_3360;
                        call_value(each_job(roots_pf.clone(), {
                            let lx_pe = lx_pe.clone();
                            Rc::new(move |p0: (Text, bool)| {
                                let lx_pe = lx_pe.clone();
                                entered(once_job(move || {
                                    let (qk_p1v, _) = p0;
                                    prism_rtl::Turn::More(Rc::new(ProgDefOf { lx_p0: lx_pe.clone(), qk_p1: qk_p1v.clone() }))
                                }))
                            }) as Rc<dyn Fn((Text, bool)) -> Rc<dyn prism_rtl::Job<crate::lower::model::ProgDef>>>
                        }), move |each_3449: Array<crate::lower::model::ProgDef>| {
                            let programs_ph = each_3449;
                            let main_qk_pi = fold(&g_pt.defs, &Text::lit(""), &(|found_p20: &Text, d_p21: &crate::check::env::Def| if (found_p20 == &Text::lit("")) && is_main(&d_p21.qk) {
                                d_p21.qk.clone()
                            } else {
                                found_p20.clone()
                            }));
                            let root_oj = if &main_qk_pi == &Text::lit("") {
                                None
                            } else {
                                Some(prog_def_of(&lx_pe, &main_qk_pi))
                            };
                            call_value(fold_job(g_pt.defs.clone(), Array::new(), {
                                let lx_pe = lx_pe.clone();
                                Rc::new(move |(p0, p1): (Array<crate::lower::model::CheckDef>, crate::check::env::Def)| {
                                    let lx_pe = lx_pe.clone();
                                    entered(once_job(move || {
                                        let acc_p22 = p0;
                                        let d_p23 = p1;
                                        match &d_p23.body {
                                            crate::check::env::DefBody::DbCheck(c_p24) => {
                                                let c_p24 = c_p24.clone();
                                                call_then(start_check_def_of(in_module_at(&lx_pe, &d_p23.file, &d_p23.home, &Text::lit("\0main")), c_p24.clone()), move |check_def_of_3751: crate::lower::model::CheckDef| prism_rtl::Turn::Finished(push(&acc_p22, &check_def_of_3751)))
                                            },
                                            _ => prism_rtl::Turn::Finished(acc_p22.clone()),
                                        }
                                    }))
                                }) as Rc<dyn Fn((Array<crate::lower::model::CheckDef>, crate::check::env::Def)) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::CheckDef>>>>
                            }), move |fold_3678: Array<crate::lower::model::CheckDef>| {
                                let checks_pk = fold_3678;
                                call_then(start_with_needs(g_pt.clone(), srcs_p0.clone(), tp_p3.clone(), mod_defs_pg.clone()), move |with_needs_3866: Array<crate::lower::model::ModDef>| call_then(start_with_groups(with_needs_3866), move |with_groups_3854: Array<crate::lower::model::ModDef>| {
                                    let with_needs_pl = with_groups_3854;
                                    call_then(start_elem_row(lx_pe.clone(), mods_pa.clone()), move |elem_row_3913: crate::lower::model::RowDef| {
                                        let elem_pm = elem_row_3913;
                                        call_then(start_answer_enum(in_module_at(&lx_pe, &Nat::from(0u32), &Text::lit(""), &Text::lit("\0main")), mods_pa.clone()), move |answer_enum_3947: crate::lower::model::AnswerDef| {
                                            let answer_pn = answer_enum_3947;
                                            let names_po = each(&with_needs_pl, &(|d_p25: &crate::lower::model::ModDef| d_p25.name.clone()));
                                            let value_tys_pp = value_types(&with_needs_pl);
                                            let elem_held_pq = fold(&elem_pm.cases, &Array::new(), &(|acc_p26: &Array<Text>, (_, sp_p27): &(Text, Text)| crate::check::types::union_texts(acc_p26, &held_in(&names_po, &value_tys_pp, &Text::lit(""), &crate::lower::model::OutTy::OutNamed(sp_p27.clone(), Array::new())))));
                                            let answer_held_pr = fold(&answer_pn.cases, &elem_held_pq, &(|acc_p28: &Array<Text>, k_p29: &crate::lower::model::AnswerCase| crate::check::types::union_texts(acc_p28, &held_in(&names_po, &value_tys_pp, &Text::lit(""), &k_p29.ty))));
                                            let answer_named_ps = fold(&answer_pn.cases, &Array::new(), &(|acc_p2a: &Array<Text>, k_p2b: &crate::lower::model::AnswerCase| crate::check::types::union_texts(acc_p2a, &named_in(&names_po, &Text::lit(""), &k_p2b.ty))));
                                            prism_rtl::Turn::Finished(crate::lower::model::Model { name: name_p4.clone(), mods: with_needs_pl.clone(), programs: programs_ph.clone(), root: root_oj.clone(), checks: checks_pk.clone(), elem: elem_pm.clone(), answer: answer_pn.clone(), elem_complete: answer_held_pr.clone(), elem_declared: crate::check::types::minus_texts(&answer_named_ps, &answer_held_pr), scripts: Array::new(), notes: Array::new() })
                                        })
                                    })
                                }))
                            })
                        })
                    })
                })
            })
        })
    }
}

/// `Start LowerProgram, x`: what the function value is when passed to `@Run`.
pub fn start_lower_program(srcs_p0: Array<crate::check::errors::Src>, trees_p1: Array<crate::syntax::Module>, shown_p2: Nat, tp_p3: crate::check::typed::TProgram, name_p4: Text) -> Rc<dyn prism_rtl::Job<crate::lower::model::Model>> {
    Rc::new(LowerProgram { srcs_p0, trees_p1, shown_p2, tp_p3, name_p4 })
}

/// ```prism
/// WithNeeds: unbounded fn G, [Src], TProgram, [ModDef] -> [ModDef]
/// ```
pub fn with_needs(g_p0: &crate::check::env::G, srcs_p1: &Array<crate::check::errors::Src>, tp_p2: &crate::check::typed::TProgram, defs_p3: &Array<crate::lower::model::ModDef>) -> Array<crate::lower::model::ModDef> {
    let names_p4 = each(defs_p3, &(|d_p7: &crate::lower::model::ModDef| d_p7.name.clone()));
    let value_tys_p5 = value_types(defs_p3);
    let refs_p6 = named_mods(g_p0, srcs_p1, tp_p2, &each(defs_p3, &(|d_p8: &crate::lower::model::ModDef| d_p8.prism.clone())));
    run_to_end(each_job(defs_p3.clone(), {
        let names_p4 = names_p4.clone();
        let value_tys_p5 = value_tys_p5.clone();
        let refs_p6 = refs_p6.clone();
        Rc::new(move |p0: crate::lower::model::ModDef| {
            let names_p4 = names_p4.clone();
            let value_tys_p5 = value_tys_p5.clone();
            let refs_p6 = refs_p6.clone();
            entered(once_job(move || {
                let d_p9 = p0;
                {
                    let held_pa = fold(&d_p9.items, &Array::new(), &(|acc_pe: &Array<Text>, it_pf: &crate::lower::model::Item| crate::check::types::union_texts(acc_pe, &item_held(&names_p4, &value_tys_p5, &d_p9.name, it_pf))));
                    let complete_pb = filter(&held_pa, &(|n_pg: &Text| n_pg != &d_p9.name));
                    call_then(start_reached_by(refs_p6.clone(), Array::from(vec![d_p9.prism.clone()]), Array::new()), move |reached_by_5161: Array<Text>| {
                        let reached_pc = each(&reached_by_5161, &(|m_ph: &Text| crate::lower::rust_mod_name(m_ph)));
                        let declared_pd = filter(&names_p4, &(|n_pi: &Text| ((n_pi != &d_p9.name) && crate::check::types::has_text(&reached_pc, n_pi)) && !crate::check::types::has_text(&complete_pb, n_pi)));
                        prism_rtl::Turn::Finished({
                            let mut this: crate::lower::model::ModDef = d_p9.clone();
                            this.complete = complete_pb.clone();
                            this.declared = declared_pd.clone();
                            this
                        })
                    })
                }
            }))
        }) as Rc<dyn Fn(crate::lower::model::ModDef) -> Rc<dyn prism_rtl::Job<crate::lower::model::ModDef>>>
    }))
}

/// The step machine of `WithNeeds`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// WithNeeds: unbounded fn G, [Src], TProgram, [ModDef] -> [ModDef]
/// ```
pub struct WithNeeds {
    pub g_p0: crate::check::env::G,
    pub srcs_p1: Array<crate::check::errors::Src>,
    pub tp_p2: crate::check::typed::TProgram,
    pub defs_p3: Array<crate::lower::model::ModDef>,
}

impl prism_rtl::Job<Array<crate::lower::model::ModDef>> for WithNeeds {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::lower::model::ModDef>> {
        let g_p0 = &self.g_p0;
        let srcs_p1 = &self.srcs_p1;
        let tp_p2 = &self.tp_p2;
        let defs_p3 = &self.defs_p3;
        let names_p4 = each(defs_p3, &(|d_p7: &crate::lower::model::ModDef| d_p7.name.clone()));
        let value_tys_p5 = value_types(defs_p3);
        let defs_p3 = defs_p3.clone();
        let g_p0 = g_p0.clone();
        let srcs_p1 = srcs_p1.clone();
        let tp_p2 = tp_p2.clone();
        call_then(start_named_mods(g_p0.clone(), srcs_p1.clone(), tp_p2.clone(), each(&defs_p3, &(|d_p8: &crate::lower::model::ModDef| d_p8.prism.clone()))), move |named_mods_4906: Map<Text, Array<Text>>| {
            let refs_p6 = named_mods_4906;
            each_job(defs_p3.clone(), {
                let names_p4 = names_p4.clone();
                let value_tys_p5 = value_tys_p5.clone();
                let refs_p6 = refs_p6.clone();
                Rc::new(move |p0: crate::lower::model::ModDef| {
                    let names_p4 = names_p4.clone();
                    let value_tys_p5 = value_tys_p5.clone();
                    let refs_p6 = refs_p6.clone();
                    entered(once_job(move || {
                        let d_p9 = p0;
                        {
                            let held_pa = fold(&d_p9.items, &Array::new(), &(|acc_pe: &Array<Text>, it_pf: &crate::lower::model::Item| crate::check::types::union_texts(acc_pe, &item_held(&names_p4, &value_tys_p5, &d_p9.name, it_pf))));
                            let complete_pb = filter(&held_pa, &(|n_pg: &Text| n_pg != &d_p9.name));
                            call_then(start_reached_by(refs_p6.clone(), Array::from(vec![d_p9.prism.clone()]), Array::new()), move |reached_by_5161: Array<Text>| {
                                let reached_pc = each(&reached_by_5161, &(|m_ph: &Text| crate::lower::rust_mod_name(m_ph)));
                                let declared_pd = filter(&names_p4, &(|n_pi: &Text| ((n_pi != &d_p9.name) && crate::check::types::has_text(&reached_pc, n_pi)) && !crate::check::types::has_text(&complete_pb, n_pi)));
                                prism_rtl::Turn::Finished({
                                    let mut this: crate::lower::model::ModDef = d_p9.clone();
                                    this.complete = complete_pb.clone();
                                    this.declared = declared_pd.clone();
                                    this
                                })
                            })
                        }
                    }))
                }) as Rc<dyn Fn(crate::lower::model::ModDef) -> Rc<dyn prism_rtl::Job<crate::lower::model::ModDef>>>
            }).cycle()
        })
    }
}

/// `Start WithNeeds, x`: what the function value is when passed to `@Run`.
pub fn start_with_needs(g_p0: crate::check::env::G, srcs_p1: Array<crate::check::errors::Src>, tp_p2: crate::check::typed::TProgram, defs_p3: Array<crate::lower::model::ModDef>) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::ModDef>>> {
    Rc::new(WithNeeds { g_p0, srcs_p1, tp_p2, defs_p3 })
}

/// ```prism
/// NamedMods: unbounded fn G, [Src], TProgram, [Text] -> (Text ==> [Text])
/// ```
pub fn named_mods(g_p0: &crate::check::env::G, srcs_p1: &Array<crate::check::errors::Src>, tp_p2: &crate::check::typed::TProgram, ms_p3: &Array<Text>) -> Map<Text, Array<Text>> {
    let by_path_p4 = fold(&values(&g_p0.mods), &Map::new(), &(|acc_p7: &Map<Text, Text>, info_p8: &crate::check::env::ModInfo| insert(acc_p7, &or(&index(srcs_p1, &info_p8.file), &crate::check::errors::mk_src(&Text::lit(""), &Text::lit(""))).path_, &info_p8.name)));
    let by_file_p5 = fold(&values(&g_p0.mods), &Map::new(), &(|acc_p9: &Map<Nat, Text>, info_pa: &crate::check::env::ModInfo| insert(acc_p9, &info_pa.file, &info_pa.name)));
    let solved_p6 = fold(&tp_p2.impls, &Map::new(), &(|acc_pb: &Map<Text, Array<Text>>, n_pc: &crate::check::typed::ImplNote| match get(&by_file_p5, &n_pc.at.file) {
        Some(site_pd) => match get(&by_path_p4, &impl_path(&n_pc.how)) {
            Some(home_pe) => if (&home_pe == &site_pd) || crate::check::types::has_text(&or(&get(acc_pb, &site_pd), &Array::new()), &home_pe) {
                acc_pb.clone()
            } else {
                insert(acc_pb, &site_pd, &push(&or(&get(acc_pb, &site_pd), &Array::new()), &home_pe))
            },
            None => acc_pb.clone(),
        },
        None => acc_pb.clone(),
    }));
    run_to_end(fold_job(ms_p3.clone(), Map::new(), {
        let g_p0 = g_p0.clone();
        let srcs_p1 = srcs_p1.clone();
        let ms_p3 = ms_p3.clone();
        let solved_p6 = solved_p6.clone();
        Rc::new(move |(p0, p1): (Map<Text, Array<Text>>, Text)| {
            let g_p0 = g_p0.clone();
            let srcs_p1 = srcs_p1.clone();
            let ms_p3 = ms_p3.clone();
            let solved_p6 = solved_p6.clone();
            entered(once_job(move || {
                let acc_pf = p0;
                let m_pg = p1;
                match get(&g_p0.mods, &m_pg) {
                    Some(info_ph) => {
                        let code_pi = crate::syntax::lexer::chars::join(&filter(&split_on(&or(&index(&srcs_p1, &info_ph.file), &crate::check::errors::mk_src(&Text::lit(""), &Text::lit(""))).text, &Text::lit("\n")), &(|l_pk: &Text| !crate::syntax::lexer::chars::has_prefix(&crate::syntax::lexer::chars::trim_start(l_pk), &Text::lit("#")))), &Text::lit("\n"));
                        let qualified_pj = filter(&ms_p3, &(|o_pl: &Text| ((o_pl != &m_pg) && (o_pl != &Text::lit(""))) && crate::syntax::lexer::chars::contains(&code_pi, &Text::from(format!("{}.", o_pl)))));
                        call_then(start_mod_refs(g_p0.clone(), m_pg.clone()), move |mod_refs_6810: Array<Text>| prism_rtl::Turn::Finished(insert(&acc_pf, &m_pg, &crate::check::types::union_texts(&crate::check::types::union_texts(&mod_refs_6810, &qualified_pj), &or(&get(&solved_p6, &m_pg), &Array::new())))))
                    },
                    None => prism_rtl::Turn::Finished(acc_pf.clone()),
                }
            }))
        }) as Rc<dyn Fn((Map<Text, Array<Text>>, Text)) -> Rc<dyn prism_rtl::Job<Map<Text, Array<Text>>>>>
    }))
}

/// The step machine of `NamedMods`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// NamedMods: unbounded fn G, [Src], TProgram, [Text] -> (Text ==> [Text])
/// ```
pub struct NamedMods {
    pub g_p0: crate::check::env::G,
    pub srcs_p1: Array<crate::check::errors::Src>,
    pub tp_p2: crate::check::typed::TProgram,
    pub ms_p3: Array<Text>,
}

impl prism_rtl::Job<Map<Text, Array<Text>>> for NamedMods {
    fn cycle(&self) -> prism_rtl::Turn<Map<Text, Array<Text>>> {
        let g_p0 = &self.g_p0;
        let srcs_p1 = &self.srcs_p1;
        let tp_p2 = &self.tp_p2;
        let ms_p3 = &self.ms_p3;
        let by_path_p4 = fold(&values(&g_p0.mods), &Map::new(), &(|acc_p7: &Map<Text, Text>, info_p8: &crate::check::env::ModInfo| insert(acc_p7, &or(&index(srcs_p1, &info_p8.file), &crate::check::errors::mk_src(&Text::lit(""), &Text::lit(""))).path_, &info_p8.name)));
        let by_file_p5 = fold(&values(&g_p0.mods), &Map::new(), &(|acc_p9: &Map<Nat, Text>, info_pa: &crate::check::env::ModInfo| insert(acc_p9, &info_pa.file, &info_pa.name)));
        let solved_p6 = fold(&tp_p2.impls, &Map::new(), &(|acc_pb: &Map<Text, Array<Text>>, n_pc: &crate::check::typed::ImplNote| match get(&by_file_p5, &n_pc.at.file) {
            Some(site_pd) => match get(&by_path_p4, &impl_path(&n_pc.how)) {
                Some(home_pe) => if (&home_pe == &site_pd) || crate::check::types::has_text(&or(&get(acc_pb, &site_pd), &Array::new()), &home_pe) {
                    acc_pb.clone()
                } else {
                    insert(acc_pb, &site_pd, &push(&or(&get(acc_pb, &site_pd), &Array::new()), &home_pe))
                },
                None => acc_pb.clone(),
            },
            None => acc_pb.clone(),
        }));
        fold_job(ms_p3.clone(), Map::new(), {
            let g_p0 = g_p0.clone();
            let srcs_p1 = srcs_p1.clone();
            let ms_p3 = ms_p3.clone();
            let solved_p6 = solved_p6.clone();
            Rc::new(move |(p0, p1): (Map<Text, Array<Text>>, Text)| {
                let g_p0 = g_p0.clone();
                let srcs_p1 = srcs_p1.clone();
                let ms_p3 = ms_p3.clone();
                let solved_p6 = solved_p6.clone();
                entered(once_job(move || {
                    let acc_pf = p0;
                    let m_pg = p1;
                    match get(&g_p0.mods, &m_pg) {
                        Some(info_ph) => {
                            let code_pi = crate::syntax::lexer::chars::join(&filter(&split_on(&or(&index(&srcs_p1, &info_ph.file), &crate::check::errors::mk_src(&Text::lit(""), &Text::lit(""))).text, &Text::lit("\n")), &(|l_pk: &Text| !crate::syntax::lexer::chars::has_prefix(&crate::syntax::lexer::chars::trim_start(l_pk), &Text::lit("#")))), &Text::lit("\n"));
                            let qualified_pj = filter(&ms_p3, &(|o_pl: &Text| ((o_pl != &m_pg) && (o_pl != &Text::lit(""))) && crate::syntax::lexer::chars::contains(&code_pi, &Text::from(format!("{}.", o_pl)))));
                            call_then(start_mod_refs(g_p0.clone(), m_pg.clone()), move |mod_refs_6810: Array<Text>| prism_rtl::Turn::Finished(insert(&acc_pf, &m_pg, &crate::check::types::union_texts(&crate::check::types::union_texts(&mod_refs_6810, &qualified_pj), &or(&get(&solved_p6, &m_pg), &Array::new())))))
                        },
                        None => prism_rtl::Turn::Finished(acc_pf.clone()),
                    }
                }))
            }) as Rc<dyn Fn((Map<Text, Array<Text>>, Text)) -> Rc<dyn prism_rtl::Job<Map<Text, Array<Text>>>>>
        }).cycle()
    }
}

/// `Start NamedMods, x`: what the function value is when passed to `@Run`.
pub fn start_named_mods(g_p0: crate::check::env::G, srcs_p1: Array<crate::check::errors::Src>, tp_p2: crate::check::typed::TProgram, ms_p3: Array<Text>) -> Rc<dyn prism_rtl::Job<Map<Text, Array<Text>>>> {
    Rc::new(NamedMods { g_p0, srcs_p1, tp_p2, ms_p3 })
}

/// ```prism
/// ImplPath: fn Text -> Text
/// ```
pub fn impl_path(how_p0: &Text) -> Text {
    let rest_p1 = or(&crate::syntax::lexer::chars::after_prefix(how_p0, &Text::lit("impl ")), &or(&crate::syntax::lexer::chars::after_prefix(how_p0, &Text::lit("derived ")), &Text::lit("")));
    let parts_p2 = split_on(&rest_p1, &Text::lit(":"));
    crate::syntax::lexer::chars::join(&take(&parts_p2, &crate::syntax::lexer::chars::dec(&len(&parts_p2))), &Text::lit(":"))
}

/// ```prism
/// ValueTypes: fn [ModDef] -> (Text ==> Bool)
/// ```
pub fn value_types(defs_p0: &Array<crate::lower::model::ModDef>) -> Map<Text, bool> {
    fold(defs_p0, &Map::new(), &(|acc_p1: &Map<Text, bool>, d_p2: &crate::lower::model::ModDef| fold(&d_p2.items, acc_p1, &(|a_p3: &Map<Text, bool>, it_p4: &crate::lower::model::Item| match it_p4 {
        crate::lower::model::Item::ItType(t_p5) => insert(a_p3, &Text::from(format!("{}::{}", &d_p2.name, &t_p5.name)), &true),
        crate::lower::model::Item::ItTag(t_p6) => insert(a_p3, &Text::from(format!("{}::{}", &d_p2.name, &t_p6.name)), &true),
        _ => a_p3.clone(),
    }))))
}

/// ```prism
/// ItemHeld: fn [Text], (Text ==> Bool), Text, Item -> [Text]
/// ```
pub fn item_held(names_p0: &Array<Text>, value_tys_p1: &Map<Text, bool>, home_p2: &Text, it_p3: &crate::lower::model::Item) -> Array<Text> {
    match it_p3 {
        crate::lower::model::Item::ItType(t_p4) => fold(&t_p4.cases, &Array::new(), &(|acc_p5: &Array<Text>, c_p6: &crate::lower::model::CaseDef| fold(&c_p6.fields, acc_p5, &(|a_p7: &Array<Text>, (_, ft_p8): &(Text, crate::lower::model::OutTy)| crate::check::types::union_texts(a_p7, &held_in(names_p0, value_tys_p1, home_p2, ft_p8)))))),
        crate::lower::model::Item::ItTag(t_p9) => fold(&t_p9.fields, &Array::new(), &(|acc_pa: &Array<Text>, (_, _, ft_pb): &(Text, Text, crate::lower::model::OutTy)| crate::check::types::union_texts(acc_pa, &held_in(names_p0, value_tys_p1, home_p2, ft_pb)))),
        crate::lower::model::Item::ItRow(r_pc) => fold(&r_pc.cases, &Array::new(), &(|acc_pd: &Array<Text>, (_, sp_pe): &(Text, Text)| crate::check::types::union_texts(acc_pd, &held_in(names_p0, value_tys_p1, home_p2, &crate::lower::model::OutTy::OutNamed(sp_pe.clone(), Array::new()))))),
        _ => Array::new(),
    }
}

/// ```prism
/// HeldIn: fn [Text], (Text ==> Bool), Text, OutTy -> [Text]
/// ```
pub fn held_in(names_p0: &Array<Text>, value_tys_p1: &Map<Text, bool>, home_p2: &Text, t_p3: &crate::lower::model::OutTy) -> Array<Text> {
    match t_p3 {
        crate::lower::model::OutTy::OutNamed(n_p4, args_p5) => {
            let p_p6 = path_from(names_p0, home_p2, n_p4);
            let own_p7 = if crate::check::env::has_key(value_tys_p1, &p_p6) {
                Array::from(vec![parent_of(&p_p6)])
            } else {
                Array::new()
            };
            fold(args_p5, &own_p7, &(|acc_p8: &Array<Text>, a_p9: &crate::lower::model::OutTy| crate::check::types::union_texts(acc_p8, &held_in(names_p0, value_tys_p1, home_p2, a_p9))))
        },
        crate::lower::model::OutTy::OutOpt(i_pa) => held_in(names_p0, value_tys_p1, home_p2, &**i_pa),
        crate::lower::model::OutTy::OutRes(i_pb) => held_in(names_p0, value_tys_p1, home_p2, &**i_pb),
        crate::lower::model::OutTy::OutCell(i_pc) => held_in(names_p0, value_tys_p1, home_p2, &**i_pc),
        crate::lower::model::OutTy::OutTuple(ts_pd) => fold(ts_pd, &Array::new(), &(|acc_pe: &Array<Text>, a_pf: &crate::lower::model::OutTy| crate::check::types::union_texts(acc_pe, &held_in(names_p0, value_tys_p1, home_p2, a_pf)))),
        _ => Array::new(),
    }
}

/// ```prism
/// NamedIn: fn [Text], Text, OutTy -> [Text]
/// ```
pub fn named_in(names_p0: &Array<Text>, home_p1: &Text, t_p2: &crate::lower::model::OutTy) -> Array<Text> {
    match t_p2 {
        crate::lower::model::OutTy::OutNamed(n_p3, args_p4) => {
            let p_p5 = path_from(names_p0, home_p1, n_p3);
            let own_p6 = if crate::check::types::has_text(names_p0, &parent_of(&p_p5)) {
                Array::from(vec![parent_of(&p_p5)])
            } else {
                Array::new()
            };
            fold(args_p4, &own_p6, &(|acc_p7: &Array<Text>, a_p8: &crate::lower::model::OutTy| crate::check::types::union_texts(acc_p7, &named_in(names_p0, home_p1, a_p8))))
        },
        crate::lower::model::OutTy::OutOpt(i_p9) => named_in(names_p0, home_p1, &**i_p9),
        crate::lower::model::OutTy::OutRes(i_pa) => named_in(names_p0, home_p1, &**i_pa),
        crate::lower::model::OutTy::OutCell(i_pb) => named_in(names_p0, home_p1, &**i_pb),
        crate::lower::model::OutTy::OutArray(i_pc) => named_in(names_p0, home_p1, &**i_pc),
        crate::lower::model::OutTy::OutRc(i_pd) => named_in(names_p0, home_p1, &**i_pd),
        crate::lower::model::OutTy::OutEvent(i_pe) => named_in(names_p0, home_p1, &**i_pe),
        crate::lower::model::OutTy::OutDyn(i_pf) => named_in(names_p0, home_p1, &**i_pf),
        crate::lower::model::OutTy::OutMap(k_pg, v_ph) => crate::check::types::union_texts(&named_in(names_p0, home_p1, &**k_pg), &named_in(names_p0, home_p1, &**v_ph)),
        crate::lower::model::OutTy::OutTuple(ts_pi) => fold(ts_pi, &Array::new(), &(|acc_pj: &Array<Text>, a_pk: &crate::lower::model::OutTy| crate::check::types::union_texts(acc_pj, &named_in(names_p0, home_p1, a_pk)))),
        crate::lower::model::OutTy::OutFn(ps_pl, r_pm) => fold(ps_pl, &named_in(names_p0, home_p1, &**r_pm), &(|acc_pn: &Array<Text>, a_po: &crate::lower::model::OutTy| crate::check::types::union_texts(acc_pn, &named_in(names_p0, home_p1, a_po)))),
        _ => Array::new(),
    }
}

/// ```prism
/// PathFrom: fn [Text], Text, Text -> Text
/// ```
pub fn path_from(names_p0: &Array<Text>, home_p1: &Text, n_p2: &Text) -> Text {
    let q_p3 = crate::syntax::lexer::chars::drop_prefix(n_p2, &Text::lit("crate::"));
    if starts_with_module(names_p0, &q_p3) {
        q_p3.clone()
    } else {
        if home_p1 == &Text::lit("") {
            q_p3.clone()
        } else {
            Text::from(format!("{}::{}", home_p1, &q_p3))
        }
    }
}

/// ```prism
/// StartsWithModule: fn [Text], Text -> Bool
/// ```
pub fn starts_with_module(names_p0: &Array<Text>, q_p1: &Text) -> bool {
    fold(names_p0, &false, &(|f_p2: &bool, n_p3: &Text| *f_p2 || ((n_p3 != &Text::lit("")) && crate::syntax::lexer::chars::has_prefix(q_p1, &Text::from(format!("{}::", n_p3))))))
}

/// ```prism
/// ParentOf: fn Text -> Text
/// ```
pub fn parent_of(p_p0: &Text) -> Text {
    let segs_p1 = split_on(p_p0, &Text::lit("::"));
    crate::syntax::lexer::chars::join(&take(&segs_p1, &crate::syntax::lexer::chars::dec(&len(&segs_p1))), &Text::lit("::"))
}

/// ```prism
/// WithGroups: unbounded fn [ModDef] -> [ModDef]
/// ```
pub fn with_groups(defs_p0: &Array<crate::lower::model::ModDef>) -> Array<crate::lower::model::ModDef> {
    let edges_p1 = fold(defs_p0, &Map::new(), &(|m_p3: &Map<Text, Array<Text>>, d_p4: &crate::lower::model::ModDef| insert(m_p3, &d_p4.name, &d_p4.complete)));
    let reach_p2 = run_to_end(fold_job(defs_p0.clone(), Map::new(), {
        let edges_p1 = edges_p1.clone();
        Rc::new(move |(p0, p1): (Map<Text, Array<Text>>, crate::lower::model::ModDef)| {
            let edges_p1 = edges_p1.clone();
            entered(once_job(move || {
                let m_p5 = p0;
                let d_p6 = p1;
                call_then(start_reached_by(edges_p1.clone(), Array::from(vec![d_p6.name.clone()]), Array::new()), move |reached_by_11263: Array<Text>| prism_rtl::Turn::Finished(insert(&m_p5, &d_p6.name, &reached_by_11263)))
            }))
        }) as Rc<dyn Fn((Map<Text, Array<Text>>, crate::lower::model::ModDef)) -> Rc<dyn prism_rtl::Job<Map<Text, Array<Text>>>>>
    }));
    each(defs_p0, &(|d_p7: &crate::lower::model::ModDef| {
        let mine_p8 = or(&get(&reach_p2, &d_p7.name), &Array::new());
        {
            let mut this: crate::lower::model::ModDef = d_p7.clone();
            this.types_with = filter(&each(defs_p0, &(|o_p9: &crate::lower::model::ModDef| o_p9.name.clone())), &(|n_pa: &Text| (n_pa == &d_p7.name) || (crate::check::types::has_text(&mine_p8, n_pa) && crate::check::types::has_text(&or(&get(&reach_p2, n_pa), &Array::new()), &d_p7.name))));
            this
        }
    }))
}

/// The step machine of `WithGroups`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// WithGroups: unbounded fn [ModDef] -> [ModDef]
/// ```
pub struct WithGroups {
    pub defs_p0: Array<crate::lower::model::ModDef>,
}

impl prism_rtl::Job<Array<crate::lower::model::ModDef>> for WithGroups {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::lower::model::ModDef>> {
        let defs_p0 = &self.defs_p0;
        let edges_p1 = fold(defs_p0, &Map::new(), &(|m_p3: &Map<Text, Array<Text>>, d_p4: &crate::lower::model::ModDef| insert(m_p3, &d_p4.name, &d_p4.complete)));
        let defs_p0 = defs_p0.clone();
        call_value(fold_job(defs_p0.clone(), Map::new(), {
            let edges_p1 = edges_p1.clone();
            Rc::new(move |(p0, p1): (Map<Text, Array<Text>>, crate::lower::model::ModDef)| {
                let edges_p1 = edges_p1.clone();
                entered(once_job(move || {
                    let m_p5 = p0;
                    let d_p6 = p1;
                    call_then(start_reached_by(edges_p1.clone(), Array::from(vec![d_p6.name.clone()]), Array::new()), move |reached_by_11263: Array<Text>| prism_rtl::Turn::Finished(insert(&m_p5, &d_p6.name, &reached_by_11263)))
                }))
            }) as Rc<dyn Fn((Map<Text, Array<Text>>, crate::lower::model::ModDef)) -> Rc<dyn prism_rtl::Job<Map<Text, Array<Text>>>>>
        }), move |fold_11221: Map<Text, Array<Text>>| {
            let reach_p2 = fold_11221;
            prism_rtl::Turn::Finished(each(&defs_p0, &(|d_p7: &crate::lower::model::ModDef| {
                let mine_p8 = or(&get(&reach_p2, &d_p7.name), &Array::new());
                {
                    let mut this: crate::lower::model::ModDef = d_p7.clone();
                    this.types_with = filter(&each(&defs_p0, &(|o_p9: &crate::lower::model::ModDef| o_p9.name.clone())), &(|n_pa: &Text| (n_pa == &d_p7.name) || (crate::check::types::has_text(&mine_p8, n_pa) && crate::check::types::has_text(&or(&get(&reach_p2, n_pa), &Array::new()), &d_p7.name))));
                    this
                }
            })))
        })
    }
}

/// `Start WithGroups, x`: what the function value is when passed to `@Run`.
pub fn start_with_groups(defs_p0: Array<crate::lower::model::ModDef>) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::ModDef>>> {
    Rc::new(WithGroups { defs_p0 })
}

/// ```prism
/// ReachedBy: unbounded fn (Text ==> [Text]), [Text], [Text] -> [Text]
/// ```
pub fn reached_by(edges_p0: &Map<Text, Array<Text>>, todo_p1: &Array<Text>, seen_p2: &Array<Text>) -> Array<Text> {
    match index(todo_p1, &Nat::from(0u32)) {
        None => seen_p2.clone(),
        Some(m_p3) => if crate::check::types::has_text(seen_p2, &m_p3) {
            reached_by(edges_p0, &drop(todo_p1, &Nat::from(1u32)), seen_p2)
        } else {
            reached_by(edges_p0, &append(&drop(todo_p1, &Nat::from(1u32)), &or(&get(edges_p0, &m_p3), &Array::new())), &push(seen_p2, &m_p3))
        },
    }
}

/// The step machine of `ReachedBy`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ReachedBy: unbounded fn (Text ==> [Text]), [Text], [Text] -> [Text]
/// ```
pub struct ReachedBy {
    pub edges_p0: Map<Text, Array<Text>>,
    pub todo_p1: Array<Text>,
    pub seen_p2: Array<Text>,
}

impl prism_rtl::Job<Array<Text>> for ReachedBy {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let edges_p0 = &self.edges_p0;
        let todo_p1 = &self.todo_p1;
        let seen_p2 = &self.seen_p2;
        match index(todo_p1, &Nat::from(0u32)) {
            None => prism_rtl::Turn::Finished(seen_p2.clone()),
            Some(m_p3) => if crate::check::types::has_text(seen_p2, &m_p3) {
                prism_rtl::Turn::More(Rc::new(ReachedBy { edges_p0: edges_p0.clone(), todo_p1: drop(todo_p1, &Nat::from(1u32)), seen_p2: seen_p2.clone() }))
            } else {
                prism_rtl::Turn::More(Rc::new(ReachedBy { edges_p0: edges_p0.clone(), todo_p1: append(&drop(todo_p1, &Nat::from(1u32)), &or(&get(edges_p0, &m_p3), &Array::new())), seen_p2: push(seen_p2, &m_p3) }))
            },
        }
    }
}

/// `Start ReachedBy, x`: what the function value is when passed to `@Run`.
pub fn start_reached_by(edges_p0: Map<Text, Array<Text>>, todo_p1: Array<Text>, seen_p2: Array<Text>) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(ReachedBy { edges_p0, todo_p1, seen_p2 })
}

/// ```prism
/// NeededMods: unbounded fn G, Nat -> [Text]
/// ```
pub fn needed_mods(g_p0: &crate::check::env::G, shown_p1: &Nat) -> Array<Text> {
    let own_p2 = filter(&keys(&g_p0.mods), &(|m_p4: &Text| (&or(&get(&g_p0.mods, m_p4), &crate::check::env::reading::dummy_mod()).file < shown_p1) && (m_p4 != &Text::lit("Prelude"))));
    let grown_p3 = run_to_end(fold_job(crate::check::errors::range0(&Nat::from(6u32)), own_p2.clone(), {
        let g_p0 = g_p0.clone();
        Rc::new(move |(p0, p1): (Array<Text>, Nat)| {
            let g_p0 = g_p0.clone();
            entered(once_job(move || {
                let acc_p5 = p0;
                let _ = p1;
                fold_job(acc_p5.clone(), acc_p5.clone(), {
                    let g_p0 = g_p0.clone();
                    Rc::new(move |(p0, p1): (Array<Text>, Text)| {
                        let g_p0 = g_p0.clone();
                        entered(once_job(move || {
                            let a_p6 = p0;
                            let m_p7 = p1;
                            call_then(start_mod_refs(g_p0.clone(), m_p7.clone()), move |mod_refs_12286: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&a_p6, &mod_refs_12286)))
                        }))
                    }) as Rc<dyn Fn((Array<Text>, Text)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
                }).cycle()
            }))
        }) as Rc<dyn Fn((Array<Text>, Nat)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
    }));
    filter(&keys(&g_p0.mods), &(|m_p8: &Text| (m_p8 != &Text::lit("Prelude")) && crate::check::types::has_text(&grown_p3, m_p8)))
}

/// The step machine of `NeededMods`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// NeededMods: unbounded fn G, Nat -> [Text]
/// ```
pub struct NeededMods {
    pub g_p0: crate::check::env::G,
    pub shown_p1: Nat,
}

impl prism_rtl::Job<Array<Text>> for NeededMods {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let g_p0 = &self.g_p0;
        let shown_p1 = &self.shown_p1;
        let own_p2 = filter(&keys(&g_p0.mods), &(|m_p4: &Text| (&or(&get(&g_p0.mods, m_p4), &crate::check::env::reading::dummy_mod()).file < shown_p1) && (m_p4 != &Text::lit("Prelude"))));
        let g_p0 = g_p0.clone();
        call_value(fold_job(crate::check::errors::range0(&Nat::from(6u32)), own_p2.clone(), {
            let g_p0 = g_p0.clone();
            Rc::new(move |(p0, p1): (Array<Text>, Nat)| {
                let g_p0 = g_p0.clone();
                entered(once_job(move || {
                    let acc_p5 = p0;
                    let _ = p1;
                    fold_job(acc_p5.clone(), acc_p5.clone(), {
                        let g_p0 = g_p0.clone();
                        Rc::new(move |(p0, p1): (Array<Text>, Text)| {
                            let g_p0 = g_p0.clone();
                            entered(once_job(move || {
                                let a_p6 = p0;
                                let m_p7 = p1;
                                call_then(start_mod_refs(g_p0.clone(), m_p7.clone()), move |mod_refs_12286: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&a_p6, &mod_refs_12286)))
                            }))
                        }) as Rc<dyn Fn((Array<Text>, Text)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
                    }).cycle()
                }))
            }) as Rc<dyn Fn((Array<Text>, Nat)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
        }), move |fold_12211: Array<Text>| {
            let grown_p3 = fold_12211;
            prism_rtl::Turn::Finished(filter(&keys(&g_p0.mods), &(|m_p8: &Text| (m_p8 != &Text::lit("Prelude")) && crate::check::types::has_text(&grown_p3, m_p8))))
        })
    }
}

/// `Start NeededMods, x`: what the function value is when passed to `@Run`.
pub fn start_needed_mods(g_p0: crate::check::env::G, shown_p1: Nat) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(NeededMods { g_p0, shown_p1 })
}

/// ```prism
/// ModRefs: unbounded fn G, Text -> [Text]
/// ```
pub fn mod_refs(g_p0: &crate::check::env::G, m_p1: &Text) -> Array<Text> {
    match get(&g_p0.mods, m_p1) {
        Some(info_p2) => {
            let used_p3 = each(&info_p2.uses, &(|(u_p5, _): &(Text, bool)| u_p5.clone()));
            let fams_p4 = match &info_p2.tree.emit_row {
                Some(rw_p6) => fold(&rw_p6.terms, &Array::new(), &(|acc_p7: &Array<Text>, t_p8: &crate::syntax::RowTerm| match t_p8 {
                    crate::syntax::RowTerm::RFamily(q_p9) => push(acc_p7, &or(&get(&g_p0.fam_owner, &crate::check::env::dotted(&q_p9.path_)), &crate::check::env::dotted(&q_p9.path_))),
                    _ => acc_p7.clone(),
                })),
                None => Array::new(),
            };
            filter(&append(&used_p3, &fams_p4), &(|x_pa: &Text| crate::check::env::has_key(&g_p0.mods, x_pa)))
        },
        None => Array::new(),
    }
}

/// The step machine of `ModRefs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ModRefs: unbounded fn G, Text -> [Text]
/// ```
pub struct ModRefs {
    pub g_p0: crate::check::env::G,
    pub m_p1: Text,
}

impl prism_rtl::Job<Array<Text>> for ModRefs {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let g_p0 = &self.g_p0;
        let m_p1 = &self.m_p1;
        match get(&g_p0.mods, m_p1) {
            Some(info_p2) => {
                let used_p3 = each(&info_p2.uses, &(|(u_p5, _): &(Text, bool)| u_p5.clone()));
                let fams_p4 = match &info_p2.tree.emit_row {
                    Some(rw_p6) => fold(&rw_p6.terms, &Array::new(), &(|acc_p7: &Array<Text>, t_p8: &crate::syntax::RowTerm| match t_p8 {
                        crate::syntax::RowTerm::RFamily(q_p9) => push(acc_p7, &or(&get(&g_p0.fam_owner, &crate::check::env::dotted(&q_p9.path_)), &crate::check::env::dotted(&q_p9.path_))),
                        _ => acc_p7.clone(),
                    })),
                    None => Array::new(),
                };
                prism_rtl::Turn::Finished(filter(&append(&used_p3, &fams_p4), &(|x_pa: &Text| crate::check::env::has_key(&g_p0.mods, x_pa))))
            },
            None => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start ModRefs, x`: what the function value is when passed to `@Run`.
pub fn start_mod_refs(g_p0: crate::check::env::G, m_p1: Text) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(ModRefs { g_p0, m_p1 })
}

/// ```prism
/// RootWidgets: fn Lx -> [((Text, Bool))]
/// ```
pub fn root_widgets(lx_p0: &crate::lower::Lx) -> Array<(Text, bool)> {
    let tested_p1 = fold(&lx_p0.g.defs, &Array::new(), &(|acc_p3: &Array<(Text, bool)>, d_p4: &crate::check::env::Def| match &d_p4.body {
        crate::check::env::DefBody::DbTest(t_p5) => match blueprint_qk(&in_module(lx_p0, &d_p4.file, &d_p4.home), &t_p5.blueprint) {
            m13040_0 if (&m13040_0 == &Text::lit("")) => acc_p3.clone(),
            qk_p6 => if crate::check::types::has_text(&each(acc_p3, &(|(q_p7, _): &(Text, bool)| q_p7.clone())), &qk_p6) {
                acc_p3.clone()
            } else {
                push(acc_p3, &(qk_p6.clone(), true))
            },
            _ => unreachable!("no arm matched"),
        },
        _ => acc_p3.clone(),
    }));
    let main_p2 = fold(&lx_p0.g.defs, &Array::new(), &(|acc_p8: &Array<(Text, bool)>, d_p9: &crate::check::env::Def| if is_main(&d_p9.qk) {
        push(acc_p8, &(d_p9.qk.clone(), false))
    } else {
        acc_p8.clone()
    }));
    fold(&main_p2, &tested_p1, &(|acc_pa: &Array<(Text, bool)>, (k_pb, b_pc): &(Text, bool)| if crate::check::types::has_text(&each(acc_pa, &(|(q_pd, _): &(Text, bool)| q_pd.clone())), k_pb) {
        acc_pa.clone()
    } else {
        push(acc_pa, &(k_pb.clone(), *b_pc))
    }))
}

/// ```prism
/// IsMain: fn Text -> Bool
/// ```
pub fn is_main(qk_p0: &Text) -> bool {
    ((&crate::lower::owner_of(qk_p0) == &Text::lit("")) && (&crate::lower::base(&crate::check::types::bare_name(qk_p0)) == &Text::lit("main"))) && crate::syntax::lexer::chars::has_prefix(&crate::check::types::bare_name(qk_p0), &Text::lit("@"))
}

/// ```prism
/// BlueprintQk: fn Lx, Expr -> Text
/// ```
pub fn blueprint_qk(lx_p0: &crate::lower::Lx, e_p1: &crate::syntax::Expr) -> Text {
    match &*e_p1.kind {
        crate::syntax::ExprKind::ECall(c_p2, _, _, _) => blueprint_qk(lx_p0, &**c_p2),
        crate::syntax::ExprKind::EGroup(x_p3) => blueprint_qk(lx_p0, &**x_p3),
        crate::syntax::ExprKind::EName(n_p4) => {
            let (q_o5, _) = crate::check::env::names::resolve_value(&lx_p0.g, &lx_p0.home, n_p4);
            or(&q_o5, &Text::lit(""))
        },
        _ => Text::lit(""),
    }
}

/// ```prism
/// ValOf: fn Lx, Text -> ValInfo
/// ```
pub fn val_of(lx_p0: &crate::lower::Lx, qk_p1: &Text) -> crate::check::env::ValInfo {
    match get(&lx_p0.g.vals, qk_p1) {
        Some(v_p2) => v_p2,
        None => {
            let d_p3 = fold(&lx_p0.g.defs, &crate::check::env::decls::dummy_def(), &(|found_p4: &crate::check::env::Def, df_p5: &crate::check::env::Def| if &df_p5.qk == qk_p1 { df_p5.clone() } else { found_p4.clone() }));
            crate::check::env::ValInfo { qk: qk_p1.clone(), scheme: crate::check::types::schemes::mono(&crate::check::types::Ty::TyErr), sort: Text::lit("fn"), has_sig: false, home: d_p3.home.clone(), file: d_p3.file.clone(), span: d_p3.span.clone() }
        },
    }
}

/// ```prism
/// ProgDefOf: unbounded fn Lx, Text -> ProgDef
/// ```
pub fn prog_def_of(lx_p0: &crate::lower::Lx, qk_p1: &Text) -> crate::lower::model::ProgDef {
    let v_p2 = val_of(lx_p0, qk_p1);
    let ptys_p3 = match &v_p2.scheme.ty {
        crate::check::types::Ty::TyFn(_, ps_p9, _) => ps_p9.clone(),
        _ => Array::new(),
    };
    let lxm_p4 = in_module_at(lx_p0, &v_p2.file, &v_p2.home, &Text::lit("\0main"));
    let params_p5 = run_to_end(each_job(crate::check::errors::range0(&len(&ptys_p3)), {
        let lxm_p4 = lxm_p4.clone();
        let ptys_p3 = ptys_p3.clone();
        Rc::new(move |p0: Nat| {
            let lxm_p4 = lxm_p4.clone();
            let ptys_p3 = ptys_p3.clone();
            entered(once_job(move || {
                let i_pa = p0;
                call_then(crate::lower::types::start_out_ty_of(lxm_p4.clone(), crate::lower::types::peel(&or(&index(&ptys_p3, &i_pa), &crate::check::types::Ty::TyErr))), move |out_ty_of_14615: crate::lower::model::OutTy| prism_rtl::Turn::Finished((Text::from(format!("arg{}", &i_pa)), out_ty_of_14615)))
            }))
        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<(Text, crate::lower::model::OutTy)>>>
    }));
    let node_p6 = Text::from(format!("{}::{}", &crate::lower::rust_mod_name(&v_p2.home), &crate::lower::camel(&crate::check::types::bare_name(qk_p1))));
    let fams_p7 = or(&get(&lx_p0.g.mods, &v_p2.home), &crate::check::env::reading::dummy_mod()).emit_rw.fams.clone();
    let world_p8 = if crate::check::types::has_text(&fams_p7, &Text::lit("Gui")) {
        Text::lit("canvas")
    } else {
        if crate::check::types::has_text(&fams_p7, &Text::lit("Ui")) {
            Text::lit("none")
        } else {
            Text::lit("cli")
        }
    };
    crate::lower::model::ProgDef { name: Text::from(format!("{}Program", &crate::lower::camel(&crate::check::types::bare_name(qk_p1)))), prism: crate::syntax::lexer::chars::after_first(&crate::check::types::bare_name(qk_p1)), node_: node_p6.clone(), params: params_p5.clone(), fallible: true, world: world_p8.clone() }
}

/// The step machine of `ProgDefOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ProgDefOf: unbounded fn Lx, Text -> ProgDef
/// ```
pub struct ProgDefOf {
    pub lx_p0: crate::lower::Lx,
    pub qk_p1: Text,
}

impl prism_rtl::Job<crate::lower::model::ProgDef> for ProgDefOf {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::ProgDef> {
        let lx_p0 = &self.lx_p0;
        let qk_p1 = &self.qk_p1;
        let v_p2 = val_of(lx_p0, qk_p1);
        let ptys_p3 = match &v_p2.scheme.ty {
            crate::check::types::Ty::TyFn(_, ps_p9, _) => ps_p9.clone(),
            _ => Array::new(),
        };
        let lxm_p4 = in_module_at(lx_p0, &v_p2.file, &v_p2.home, &Text::lit("\0main"));
        let lx_p0 = lx_p0.clone();
        let qk_p1 = qk_p1.clone();
        call_value(each_job(crate::check::errors::range0(&len(&ptys_p3)), {
            let lxm_p4 = lxm_p4.clone();
            let ptys_p3 = ptys_p3.clone();
            Rc::new(move |p0: Nat| {
                let lxm_p4 = lxm_p4.clone();
                let ptys_p3 = ptys_p3.clone();
                entered(once_job(move || {
                    let i_pa = p0;
                    call_then(crate::lower::types::start_out_ty_of(lxm_p4.clone(), crate::lower::types::peel(&or(&index(&ptys_p3, &i_pa), &crate::check::types::Ty::TyErr))), move |out_ty_of_14615: crate::lower::model::OutTy| prism_rtl::Turn::Finished((Text::from(format!("arg{}", &i_pa)), out_ty_of_14615)))
                }))
            }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<(Text, crate::lower::model::OutTy)>>>
        }), move |each_14571: Array<(Text, crate::lower::model::OutTy)>| {
            let params_p5 = each_14571;
            let node_p6 = Text::from(format!("{}::{}", &crate::lower::rust_mod_name(&v_p2.home), &crate::lower::camel(&crate::check::types::bare_name(&qk_p1))));
            let fams_p7 = or(&get(&lx_p0.g.mods, &v_p2.home), &crate::check::env::reading::dummy_mod()).emit_rw.fams.clone();
            let world_p8 = if crate::check::types::has_text(&fams_p7, &Text::lit("Gui")) {
                Text::lit("canvas")
            } else {
                if crate::check::types::has_text(&fams_p7, &Text::lit("Ui")) {
                    Text::lit("none")
                } else {
                    Text::lit("cli")
                }
            };
            prism_rtl::Turn::Finished(crate::lower::model::ProgDef { name: Text::from(format!("{}Program", &crate::lower::camel(&crate::check::types::bare_name(&qk_p1)))), prism: crate::syntax::lexer::chars::after_first(&crate::check::types::bare_name(&qk_p1)), node_: node_p6.clone(), params: params_p5.clone(), fallible: true, world: world_p8.clone() })
        })
    }
}

/// `Start ProgDefOf, x`: what the function value is when passed to `@Run`.
pub fn start_prog_def_of(lx_p0: crate::lower::Lx, qk_p1: Text) -> Rc<dyn prism_rtl::Job<crate::lower::model::ProgDef>> {
    Rc::new(ProgDefOf { lx_p0, qk_p1 })
}

/// ```prism
/// JobRoots: unbounded fn Lx -> [Text]
/// ```
pub fn job_roots(lx_p0: &crate::lower::Lx) -> Array<Text> {
    let direct_p1 = run_to_end(fold_job(lx_p0.g.defs.clone(), Array::new(), {
        let lx_p0 = lx_p0.clone();
        Rc::new(move |(p0, p1): (Array<Text>, crate::check::env::Def)| {
            let lx_p0 = lx_p0.clone();
            entered(once_job(move || {
                let acc_p2 = p0;
                let d_p3 = p1;
                {
                    let lxd_p4 = in_module(&lx_p0, &d_p3.file, &d_p3.home);
                    call_then(start_run_targets(lxd_p4.clone(), d_p3.clone()), move |run_targets_15450: Array<Text>| call_then(start_unbounded_values(lxd_p4.clone(), d_p3.clone()), move |unbounded_values_15472: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&crate::check::types::union_texts(&acc_p2, &run_targets_15450), &unbounded_values_15472))))
                }
            }))
        }) as Rc<dyn Fn((Array<Text>, crate::check::env::Def)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
    }));
    run_to_end(fold_job(crate::check::errors::range0(&Nat::from(8u32)), direct_p1.clone(), {
        let lx_p0 = lx_p0.clone();
        Rc::new(move |(p0, p1): (Array<Text>, Nat)| {
            let lx_p0 = lx_p0.clone();
            entered(once_job(move || {
                let acc_p5 = p0;
                let _ = p1;
                fold_job(acc_p5.clone(), acc_p5.clone(), {
                    let lx_p0 = lx_p0.clone();
                    Rc::new(move |(p0, p1): (Array<Text>, Text)| {
                        let lx_p0 = lx_p0.clone();
                        entered(once_job(move || {
                            let a_p6 = p0;
                            let qk_p7 = p1;
                            call_then(start_tail_targets(lx_p0.clone(), qk_p7.clone()), move |tail_targets_15579: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&a_p6, &tail_targets_15579)))
                        }))
                    }) as Rc<dyn Fn((Array<Text>, Text)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
                }).cycle()
            }))
        }) as Rc<dyn Fn((Array<Text>, Nat)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
    }))
}

/// The step machine of `JobRoots`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// JobRoots: unbounded fn Lx -> [Text]
/// ```
pub struct JobRoots {
    pub lx_p0: crate::lower::Lx,
}

impl prism_rtl::Job<Array<Text>> for JobRoots {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let lx_p0 = &self.lx_p0;
        let lx_p0 = lx_p0.clone();
        call_value(fold_job(lx_p0.g.defs.clone(), Array::new(), {
            let lx_p0 = lx_p0.clone();
            Rc::new(move |(p0, p1): (Array<Text>, crate::check::env::Def)| {
                let lx_p0 = lx_p0.clone();
                entered(once_job(move || {
                    let acc_p2 = p0;
                    let d_p3 = p1;
                    {
                        let lxd_p4 = in_module(&lx_p0, &d_p3.file, &d_p3.home);
                        call_then(start_run_targets(lxd_p4.clone(), d_p3.clone()), move |run_targets_15450: Array<Text>| call_then(start_unbounded_values(lxd_p4.clone(), d_p3.clone()), move |unbounded_values_15472: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&crate::check::types::union_texts(&acc_p2, &run_targets_15450), &unbounded_values_15472))))
                    }
                }))
            }) as Rc<dyn Fn((Array<Text>, crate::check::env::Def)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
        }), move |fold_15335: Array<Text>| {
            let direct_p1 = fold_15335;
            fold_job(crate::check::errors::range0(&Nat::from(8u32)), direct_p1.clone(), {
                let lx_p0 = lx_p0.clone();
                Rc::new(move |(p0, p1): (Array<Text>, Nat)| {
                    let lx_p0 = lx_p0.clone();
                    entered(once_job(move || {
                        let acc_p5 = p0;
                        let _ = p1;
                        fold_job(acc_p5.clone(), acc_p5.clone(), {
                            let lx_p0 = lx_p0.clone();
                            Rc::new(move |(p0, p1): (Array<Text>, Text)| {
                                let lx_p0 = lx_p0.clone();
                                entered(once_job(move || {
                                    let a_p6 = p0;
                                    let qk_p7 = p1;
                                    call_then(start_tail_targets(lx_p0.clone(), qk_p7.clone()), move |tail_targets_15579: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&a_p6, &tail_targets_15579)))
                                }))
                            }) as Rc<dyn Fn((Array<Text>, Text)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
                        }).cycle()
                    }))
                }) as Rc<dyn Fn((Array<Text>, Nat)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
            }).cycle()
        })
    }
}

/// `Start JobRoots, x`: what the function value is when passed to `@Run`.
pub fn start_job_roots(lx_p0: crate::lower::Lx) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(JobRoots { lx_p0 })
}

/// ```prism
/// UnboundedValues: unbounded fn Lx, Def -> [Text]
/// ```
pub fn unbounded_values(lx_p0: &crate::lower::Lx, d_p1: &crate::check::env::Def) -> Array<Text> {
    let es_p2 = match &d_p1.body {
        crate::check::env::DefBody::DbWidget(w_p4) => crate::check::typed::print::block_exprs(&w_p4.body),
        crate::check::env::DefBody::DbFn(cs_p5) => run_to_end(fold_job(cs_p5.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<crate::syntax::Expr>, crate::syntax::decls::FnClause)| entered(once_job(move || {
            let acc_p6 = p0;
            let c_p7 = p1;
            call_then(crate::check::typed::print::start_body_exprs(c_p7.body.clone()), move |body_exprs_15930: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(append(&acc_p6, &body_exprs_15930)))
        }))) as Rc<dyn Fn((Array<crate::syntax::Expr>, crate::syntax::decls::FnClause)) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>>>)),
        crate::check::env::DefBody::DbLet(l_p8) => crate::check::typed::print::exprs_in(&l_p8.value),
        _ => Array::new(),
    };
    let callees_p3 = fold(&es_p2, &Array::new(), &(|acc_p9: &Array<Text>, e_pa: &crate::syntax::Expr| match &*e_pa.kind {
        crate::syntax::ExprKind::ECall(c_pb, _, _, _) => push(acc_p9, &crate::lower::place_key(lx_p0, &c_pb.span)),
        _ => acc_p9.clone(),
    }));
    fold(&es_p2, &Array::new(), &(|acc_pc: &Array<Text>, e_pd: &crate::syntax::Expr| match &*e_pd.kind {
        crate::syntax::ExprKind::EName(n_pe) => if crate::check::types::has_text(&callees_p3, &crate::lower::place_key(lx_p0, &e_pd.span)) {
            acc_pc.clone()
        } else {
            {
                let (q_of, _) = crate::check::env::names::resolve_value(&lx_p0.g, &lx_p0.home, n_pe);
                match &q_of {
                    Some(q_pg) => if is_unbounded(lx_p0, q_pg) {
                        crate::check::types::add_text(acc_pc, q_pg)
                    } else {
                        acc_pc.clone()
                    },
                    None => acc_pc.clone(),
                }
            }
        },
        _ => acc_pc.clone(),
    }))
}

/// The step machine of `UnboundedValues`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UnboundedValues: unbounded fn Lx, Def -> [Text]
/// ```
pub struct UnboundedValues {
    pub lx_p0: crate::lower::Lx,
    pub d_p1: crate::check::env::Def,
}

impl prism_rtl::Job<Array<Text>> for UnboundedValues {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let lx_p0 = &self.lx_p0;
        let d_p1 = &self.d_p1;
        let es_p2 = match &d_p1.body {
            crate::check::env::DefBody::DbWidget(w_p4) => crate::check::typed::print::block_exprs(&w_p4.body),
            crate::check::env::DefBody::DbFn(cs_p5) => run_to_end(fold_job(cs_p5.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<crate::syntax::Expr>, crate::syntax::decls::FnClause)| entered(once_job(move || {
                let acc_p6 = p0;
                let c_p7 = p1;
                call_then(crate::check::typed::print::start_body_exprs(c_p7.body.clone()), move |body_exprs_15930: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(append(&acc_p6, &body_exprs_15930)))
            }))) as Rc<dyn Fn((Array<crate::syntax::Expr>, crate::syntax::decls::FnClause)) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>>>)),
            crate::check::env::DefBody::DbLet(l_p8) => crate::check::typed::print::exprs_in(&l_p8.value),
            _ => Array::new(),
        };
        let callees_p3 = fold(&es_p2, &Array::new(), &(|acc_p9: &Array<Text>, e_pa: &crate::syntax::Expr| match &*e_pa.kind {
            crate::syntax::ExprKind::ECall(c_pb, _, _, _) => push(acc_p9, &crate::lower::place_key(lx_p0, &c_pb.span)),
            _ => acc_p9.clone(),
        }));
        prism_rtl::Turn::Finished(fold(&es_p2, &Array::new(), &(|acc_pc: &Array<Text>, e_pd: &crate::syntax::Expr| match &*e_pd.kind {
            crate::syntax::ExprKind::EName(n_pe) => if crate::check::types::has_text(&callees_p3, &crate::lower::place_key(lx_p0, &e_pd.span)) {
                acc_pc.clone()
            } else {
                {
                    let (q_of, _) = crate::check::env::names::resolve_value(&lx_p0.g, &lx_p0.home, n_pe);
                    match &q_of {
                        Some(q_pg) => if is_unbounded(lx_p0, q_pg) {
                            crate::check::types::add_text(acc_pc, q_pg)
                        } else {
                            acc_pc.clone()
                        },
                        None => acc_pc.clone(),
                    }
                }
            },
            _ => acc_pc.clone(),
        })))
    }
}

/// `Start UnboundedValues, x`: what the function value is when passed to `@Run`.
pub fn start_unbounded_values(lx_p0: crate::lower::Lx, d_p1: crate::check::env::Def) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(UnboundedValues { lx_p0, d_p1 })
}

/// ```prism
/// InPrelude: fn Lx, Text -> Bool
/// ```
pub fn in_prelude(lx_p0: &crate::lower::Lx, q_p1: &Text) -> bool {
    match get(&lx_p0.g.vals, q_p1) {
        Some(v_p2) => &v_p2.home == &Text::lit("Prelude"),
        None => false,
    }
}

/// ```prism
/// IsColorPoly: fn Lx, Text -> Bool
/// ```
pub fn is_color_poly(lx_p0: &crate::lower::Lx, q_p1: &Text) -> bool {
    match get(&lx_p0.g.vals, q_p1) {
        Some(v_p2) => match &v_p2.scheme.ty {
            crate::check::types::Ty::TyFn(crate::check::types::Col::CQ(_), _, _) => true,
            crate::check::types::Ty::TyFn(crate::check::types::Col::CRigid(_), _, _) => true,
            _ => false,
        },
        None => false,
    }
}

/// ```prism
/// EntersAtOnce: fn Lx, Text, [Arg] -> Bool
/// ```
pub fn enters_at_once(lx_p0: &crate::lower::Lx, q_p1: &Text, args_p2: &Array<crate::syntax::Arg>) -> bool {
    is_color_poly(lx_p0, q_p1) && !fold(args_p2, &false, &(|seen_p3: &bool, a_p4: &crate::syntax::Arg| *seen_p3 || is_unbounded_arg(lx_p0, a_p4)))
}

/// ```prism
/// IsUnboundedArg: fn Lx, Arg -> Bool
/// ```
pub fn is_unbounded_arg(lx_p0: &crate::lower::Lx, a_p1: &crate::syntax::Arg) -> bool {
    match crate::lower::types::peel(&crate::lower::type_at(lx_p0, &a_p1.value.span)) {
        crate::check::types::Ty::TyFn(crate::check::types::Col::CUnbound, _, _) => true,
        _ => false,
    }
}

/// ```prism
/// IsUnbounded: fn Lx, Text -> Bool
/// ```
pub fn is_unbounded(lx_p0: &crate::lower::Lx, q_p1: &Text) -> bool {
    match get(&lx_p0.g.vals, q_p1) {
        Some(v_p2) => match &v_p2.scheme.ty {
            crate::check::types::Ty::TyFn(crate::check::types::Col::CBound, _, _) => false,
            crate::check::types::Ty::TyFn(_, _, _) => true,
            _ => false,
        },
        None => false,
    }
}

/// ```prism
/// RunTargets: unbounded fn Lx, Def -> [Text]
/// ```
pub fn run_targets(lx_p0: &crate::lower::Lx, d_p1: &crate::check::env::Def) -> Array<Text> {
    let es_p2 = match &d_p1.body {
        crate::check::env::DefBody::DbWidget(w_p3) => crate::check::typed::print::block_exprs(&w_p3.body),
        crate::check::env::DefBody::DbFn(cs_p4) => run_to_end(fold_job(cs_p4.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<crate::syntax::Expr>, crate::syntax::decls::FnClause)| entered(once_job(move || {
            let acc_p5 = p0;
            let c_p6 = p1;
            call_then(crate::check::typed::print::start_body_exprs(c_p6.body.clone()), move |body_exprs_18159: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(append(&acc_p5, &body_exprs_18159)))
        }))) as Rc<dyn Fn((Array<crate::syntax::Expr>, crate::syntax::decls::FnClause)) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>>>)),
        _ => Array::new(),
    };
    fold(&es_p2, &Array::new(), &(|acc_p7: &Array<Text>, e_p8: &crate::syntax::Expr| match &*e_p8.kind {
        crate::syntax::ExprKind::ECall(c_p9, args_pa, _, _) => if &blueprint_qk(lx_p0, &**c_p9) == &Text::lit("Prelude.@Run") {
            match index(args_pa, &Nat::from(0u32)) {
                Some(a_pb) => match &*a_pb.value.kind {
                    crate::syntax::ExprKind::EName(n_pc) => {
                        let (q_od, _) = crate::check::env::names::resolve_value(&lx_p0.g, &lx_p0.home, n_pc);
                        match &q_od {
                            Some(q_pe) => crate::check::types::add_text(acc_p7, q_pe),
                            None => acc_p7.clone(),
                        }
                    },
                    _ => acc_p7.clone(),
                },
                None => acc_p7.clone(),
            }
        } else {
            acc_p7.clone()
        },
        _ => acc_p7.clone(),
    }))
}

/// The step machine of `RunTargets`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RunTargets: unbounded fn Lx, Def -> [Text]
/// ```
pub struct RunTargets {
    pub lx_p0: crate::lower::Lx,
    pub d_p1: crate::check::env::Def,
}

impl prism_rtl::Job<Array<Text>> for RunTargets {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let lx_p0 = &self.lx_p0;
        let d_p1 = &self.d_p1;
        let es_p2 = match &d_p1.body {
            crate::check::env::DefBody::DbWidget(w_p3) => crate::check::typed::print::block_exprs(&w_p3.body),
            crate::check::env::DefBody::DbFn(cs_p4) => run_to_end(fold_job(cs_p4.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<crate::syntax::Expr>, crate::syntax::decls::FnClause)| entered(once_job(move || {
                let acc_p5 = p0;
                let c_p6 = p1;
                call_then(crate::check::typed::print::start_body_exprs(c_p6.body.clone()), move |body_exprs_18159: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(append(&acc_p5, &body_exprs_18159)))
            }))) as Rc<dyn Fn((Array<crate::syntax::Expr>, crate::syntax::decls::FnClause)) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>>>)),
            _ => Array::new(),
        };
        prism_rtl::Turn::Finished(fold(&es_p2, &Array::new(), &(|acc_p7: &Array<Text>, e_p8: &crate::syntax::Expr| match &*e_p8.kind {
            crate::syntax::ExprKind::ECall(c_p9, args_pa, _, _) => if &blueprint_qk(lx_p0, &**c_p9) == &Text::lit("Prelude.@Run") {
                match index(args_pa, &Nat::from(0u32)) {
                    Some(a_pb) => match &*a_pb.value.kind {
                        crate::syntax::ExprKind::EName(n_pc) => {
                            let (q_od, _) = crate::check::env::names::resolve_value(&lx_p0.g, &lx_p0.home, n_pc);
                            match &q_od {
                                Some(q_pe) => crate::check::types::add_text(acc_p7, q_pe),
                                None => acc_p7.clone(),
                            }
                        },
                        _ => acc_p7.clone(),
                    },
                    None => acc_p7.clone(),
                }
            } else {
                acc_p7.clone()
            },
            _ => acc_p7.clone(),
        })))
    }
}

/// `Start RunTargets, x`: what the function value is when passed to `@Run`.
pub fn start_run_targets(lx_p0: crate::lower::Lx, d_p1: crate::check::env::Def) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(RunTargets { lx_p0, d_p1 })
}

/// ```prism
/// TailTargets: unbounded fn Lx, Text -> [Text]
/// ```
pub fn tail_targets(lx_p0: &crate::lower::Lx, qk_p1: &Text) -> Array<Text> {
    let v_p2 = or(&get(&lx_p0.g.vals, qk_p1), &crate::check::env::builtin(qk_p1, &crate::check::types::schemes::mono(&crate::check::types::Ty::TyErr)));
    let lxm_p3 = in_module(lx_p0, &v_p2.file, &v_p2.home);
    run_to_end(fold_job(crate::lower::jobs::clauses_of(&lx_p0.g, qk_p1), Array::new(), {
        let lxm_p3 = lxm_p3.clone();
        Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::decls::FnClause)| {
            let lxm_p3 = lxm_p3.clone();
            entered(once_job(move || {
                let acc_p4 = p0;
                let c_p5 = p1;
                call_then(start_tails_of_body(lxm_p3.clone(), c_p5.body.clone()), move |tails_of_body_19038: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc_p4, &tails_of_body_19038)))
            }))
        }) as Rc<dyn Fn((Array<Text>, crate::syntax::decls::FnClause)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
    }))
}

/// The step machine of `TailTargets`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TailTargets: unbounded fn Lx, Text -> [Text]
/// ```
pub struct TailTargets {
    pub lx_p0: crate::lower::Lx,
    pub qk_p1: Text,
}

impl prism_rtl::Job<Array<Text>> for TailTargets {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let lx_p0 = &self.lx_p0;
        let qk_p1 = &self.qk_p1;
        let v_p2 = or(&get(&lx_p0.g.vals, qk_p1), &crate::check::env::builtin(qk_p1, &crate::check::types::schemes::mono(&crate::check::types::Ty::TyErr)));
        let lxm_p3 = in_module(lx_p0, &v_p2.file, &v_p2.home);
        fold_job(crate::lower::jobs::clauses_of(&lx_p0.g, qk_p1), Array::new(), {
            let lxm_p3 = lxm_p3.clone();
            Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::decls::FnClause)| {
                let lxm_p3 = lxm_p3.clone();
                entered(once_job(move || {
                    let acc_p4 = p0;
                    let c_p5 = p1;
                    call_then(start_tails_of_body(lxm_p3.clone(), c_p5.body.clone()), move |tails_of_body_19038: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc_p4, &tails_of_body_19038)))
                }))
            }) as Rc<dyn Fn((Array<Text>, crate::syntax::decls::FnClause)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
        }).cycle()
    }
}

/// `Start TailTargets, x`: what the function value is when passed to `@Run`.
pub fn start_tail_targets(lx_p0: crate::lower::Lx, qk_p1: Text) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(TailTargets { lx_p0, qk_p1 })
}

/// ```prism
/// TailsOfBody: unbounded fn Lx, FnBody -> [Text]
/// ```
pub fn tails_of_body(lx_p0: &crate::lower::Lx, body_p1: &crate::syntax::decls::FnBody) -> Array<Text> {
    fold(&crate::check::typed::print::body_exprs(body_p1), &Array::new(), &(|acc_p2: &Array<Text>, e_p3: &crate::syntax::Expr| match &*e_p3.kind {
        crate::syntax::ExprKind::ECall(c_p4, _, _, _) => {
            let q_p5 = blueprint_qk(lx_p0, &**c_p4);
            match get(&lx_p0.g.vals, &q_p5) {
                Some(v_p6) => match &v_p6.scheme.ty {
                    crate::check::types::Ty::TyFn(crate::check::types::Col::CBound, _, _) => acc_p2.clone(),
                    crate::check::types::Ty::TyFn(_, _, _) => crate::check::types::add_text(acc_p2, &q_p5),
                    _ => acc_p2.clone(),
                },
                None => acc_p2.clone(),
            }
        },
        _ => acc_p2.clone(),
    }))
}

/// The step machine of `TailsOfBody`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TailsOfBody: unbounded fn Lx, FnBody -> [Text]
/// ```
pub struct TailsOfBody {
    pub lx_p0: crate::lower::Lx,
    pub body_p1: crate::syntax::decls::FnBody,
}

impl prism_rtl::Job<Array<Text>> for TailsOfBody {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let lx_p0 = &self.lx_p0;
        let body_p1 = &self.body_p1;
        let body_p1 = body_p1.clone();
        let lx_p0 = lx_p0.clone();
        call_then(crate::check::typed::print::start_body_exprs(body_p1.clone()), move |body_exprs_19143: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(fold(&body_exprs_19143, &Array::new(), &(|acc_p2: &Array<Text>, e_p3: &crate::syntax::Expr| match &*e_p3.kind {
            crate::syntax::ExprKind::ECall(c_p4, _, _, _) => {
                let q_p5 = blueprint_qk(&lx_p0, &**c_p4);
                match get(&lx_p0.g.vals, &q_p5) {
                    Some(v_p6) => match &v_p6.scheme.ty {
                        crate::check::types::Ty::TyFn(crate::check::types::Col::CBound, _, _) => acc_p2.clone(),
                        crate::check::types::Ty::TyFn(_, _, _) => crate::check::types::add_text(acc_p2, &q_p5),
                        _ => acc_p2.clone(),
                    },
                    None => acc_p2.clone(),
                }
            },
            _ => acc_p2.clone(),
        }))))
    }
}

/// `Start TailsOfBody, x`: what the function value is when passed to `@Run`.
pub fn start_tails_of_body(lx_p0: crate::lower::Lx, body_p1: crate::syntax::decls::FnBody) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(TailsOfBody { lx_p0, body_p1 })
}

/// ```prism
/// ModDefOf: unbounded fn Lx, Text, [((Text, Bool))], ModInfo, [Text] -> ModDef
/// ```
pub fn mod_def_of(lx0_p0: &crate::lower::Lx, m_p1: &Text, roots_p2: &Array<(Text, bool)>, info_p3: &crate::check::env::ModInfo, mods_p4: &Array<Text>) -> crate::lower::model::ModDef {
    let lx_p5 = in_module(lx0_p0, &info_p3.file, m_p1);
    let path_p6 = match index(&lx_p5.g.srcs, &info_p3.file) {
        Some(src_pd) => src_pd.path_.clone(),
        None => Text::lit(""),
    };
    let types_p7 = run_to_end(fold_job(values(&lx_p5.g.types), Array::new(), {
        let m_p1 = m_p1.clone();
        let lx_p5 = lx_p5.clone();
        Rc::new(move |(p0, p1): (Array<crate::lower::model::Item>, crate::check::env::TyInfo)| {
            let m_p1 = m_p1.clone();
            let lx_p5 = lx_p5.clone();
            entered(once_job(move || {
                let acc_pe = p0;
                let ti_pf = p1;
                if &ti_pf.home == &m_p1 {
                    call_then(start_ty_defs(lx_p5.clone(), ti_pf.clone()), move |ty_defs_19868: Array<crate::lower::model::Item>| prism_rtl::Turn::Finished(append(&acc_pe, &ty_defs_19868)))
                } else {
                    prism_rtl::Turn::Finished(acc_pe.clone())
                }
            }))
        }) as Rc<dyn Fn((Array<crate::lower::model::Item>, crate::check::env::TyInfo)) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Item>>>>
    }));
    let tags_p8 = run_to_end(fold_job(values(&lx_p5.g.tags), Array::new(), {
        let m_p1 = m_p1.clone();
        let lx_p5 = lx_p5.clone();
        Rc::new(move |(p0, p1): (Array<crate::lower::model::Item>, crate::check::env::TagInfo)| {
            let m_p1 = m_p1.clone();
            let lx_p5 = lx_p5.clone();
            entered(once_job(move || {
                let acc_pg = p0;
                let tg_ph = p1;
                if (&tg_ph.home == &m_p1) && (&tg_ph.kind != &Text::lit("Prelude.Fault")) {
                    call_then(start_tag_def_of(lx_p5.clone(), tg_ph.clone()), move |tag_def_of_20016: crate::lower::model::TagDef| prism_rtl::Turn::Finished(push(&acc_pg, &crate::lower::model::Item::ItTag(tag_def_of_20016))))
                } else {
                    prism_rtl::Turn::Finished(acc_pg.clone())
                }
            }))
        }) as Rc<dyn Fn((Array<crate::lower::model::Item>, crate::check::env::TagInfo)) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Item>>>>
    }));
    let defs_p9 = run_to_end(fold_job(lx_p5.g.defs.clone(), Array::new(), {
        let m_p1 = m_p1.clone();
        let lx_p5 = lx_p5.clone();
        let roots_p2 = roots_p2.clone();
        Rc::new(move |(p0, p1): (Array<crate::lower::model::Item>, crate::check::env::Def)| {
            let m_p1 = m_p1.clone();
            let lx_p5 = lx_p5.clone();
            let roots_p2 = roots_p2.clone();
            entered(once_job(move || {
                let acc_pi = p0;
                let d_pj = p1;
                if &d_pj.home == &m_p1 {
                    call_then(start_def_items(in_module(&lx_p5, &d_pj.file, &m_p1), d_pj.clone(), roots_p2.clone()), move |def_items_20120: Array<crate::lower::model::Item>| prism_rtl::Turn::Finished(append(&acc_pi, &def_items_20120)))
                } else {
                    prism_rtl::Turn::Finished(acc_pi.clone())
                }
            }))
        }) as Rc<dyn Fn((Array<crate::lower::model::Item>, crate::check::env::Def)) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Item>>>>
    }));
    let traits_pa = run_to_end(fold_job(values(&lx_p5.g.traits), Array::new(), {
        let m_p1 = m_p1.clone();
        let lx_p5 = lx_p5.clone();
        Rc::new(move |(p0, p1): (Array<crate::lower::model::Item>, crate::check::env::TraitInfo)| {
            let m_p1 = m_p1.clone();
            let lx_p5 = lx_p5.clone();
            entered(once_job(move || {
                let acc_pk = p0;
                let tr_pl = p1;
                if &tr_pl.home == &m_p1 {
                    call_then(crate::lower::functions::start_trait_def_of(lx_p5.clone(), tr_pl.clone()), move |trait_def_of_20273: crate::lower::model::TraitDef| prism_rtl::Turn::Finished(push(&acc_pk, &crate::lower::model::Item::ItTrait(trait_def_of_20273))))
                } else {
                    prism_rtl::Turn::Finished(acc_pk.clone())
                }
            }))
        }) as Rc<dyn Fn((Array<crate::lower::model::Item>, crate::check::env::TraitInfo)) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Item>>>>
    }));
    let impls_pb = run_to_end(fold_job(values(&lx_p5.g.impls), Array::new(), {
        let m_p1 = m_p1.clone();
        let lx_p5 = lx_p5.clone();
        Rc::new(move |(p0, p1): (Array<crate::lower::model::Item>, Array<crate::check::env::ImplInfo>)| {
            let m_p1 = m_p1.clone();
            let lx_p5 = lx_p5.clone();
            entered(once_job(move || {
                let acc_pm = p0;
                let ims_pn = p1;
                fold_job(ims_pn.clone(), acc_pm.clone(), {
                    let m_p1 = m_p1.clone();
                    let lx_p5 = lx_p5.clone();
                    Rc::new(move |(p0, p1): (Array<crate::lower::model::Item>, crate::check::env::ImplInfo)| {
                        let m_p1 = m_p1.clone();
                        let lx_p5 = lx_p5.clone();
                        entered(once_job(move || {
                            let a_po = p0;
                            let im_pp = p1;
                            if (&im_pp.home == &m_p1) && !im_pp.derived {
                                call_then(crate::lower::functions::start_impl_def_of(in_module(&lx_p5, &im_pp.file, &m_p1), im_pp.clone()), move |impl_def_of_20440: crate::lower::model::ImplDef| prism_rtl::Turn::Finished(push(&a_po, &crate::lower::model::Item::ItImpl(impl_def_of_20440))))
                            } else {
                                prism_rtl::Turn::Finished(a_po.clone())
                            }
                        }))
                    }) as Rc<dyn Fn((Array<crate::lower::model::Item>, crate::check::env::ImplInfo)) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Item>>>>
                }).cycle()
            }))
        }) as Rc<dyn Fn((Array<crate::lower::model::Item>, Array<crate::check::env::ImplInfo>)) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Item>>>>
    }));
    let uses_pc = filter(&each(mods_p4, &(|o_pq: &Text| crate::lower::rust_mod_name(o_pq))), &(|o_pr: &Text| o_pr != &crate::lower::rust_mod_name(m_p1)));
    crate::lower::model::ModDef { name: crate::lower::rust_mod_name(m_p1), prism: m_p1.clone(), path_: path_p6.clone(), uses: uses_pc.clone(), complete: Array::new(), declared: Array::new(), types_with: Array::new(), items: append(&append(&append(&append(&types_p7, &tags_p8), &traits_pa), &impls_pb), &defs_p9) }
}

/// The step machine of `ModDefOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ModDefOf: unbounded fn Lx, Text, [((Text, Bool))], ModInfo, [Text] -> ModDef
/// ```
pub struct ModDefOf {
    pub lx0_p0: crate::lower::Lx,
    pub m_p1: Text,
    pub roots_p2: Array<(Text, bool)>,
    pub info_p3: crate::check::env::ModInfo,
    pub mods_p4: Array<Text>,
}

impl prism_rtl::Job<crate::lower::model::ModDef> for ModDefOf {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::ModDef> {
        let lx0_p0 = &self.lx0_p0;
        let m_p1 = &self.m_p1;
        let roots_p2 = &self.roots_p2;
        let info_p3 = &self.info_p3;
        let mods_p4 = &self.mods_p4;
        let lx_p5 = in_module(lx0_p0, &info_p3.file, m_p1);
        let path_p6 = match index(&lx_p5.g.srcs, &info_p3.file) {
            Some(src_pd) => src_pd.path_.clone(),
            None => Text::lit(""),
        };
        let m_p1 = m_p1.clone();
        let mods_p4 = mods_p4.clone();
        let roots_p2 = roots_p2.clone();
        call_value(fold_job(values(&lx_p5.g.types), Array::new(), {
            let m_p1 = m_p1.clone();
            let lx_p5 = lx_p5.clone();
            Rc::new(move |(p0, p1): (Array<crate::lower::model::Item>, crate::check::env::TyInfo)| {
                let m_p1 = m_p1.clone();
                let lx_p5 = lx_p5.clone();
                entered(once_job(move || {
                    let acc_pe = p0;
                    let ti_pf = p1;
                    if &ti_pf.home == &m_p1 {
                        call_then(start_ty_defs(lx_p5.clone(), ti_pf.clone()), move |ty_defs_19868: Array<crate::lower::model::Item>| prism_rtl::Turn::Finished(append(&acc_pe, &ty_defs_19868)))
                    } else {
                        prism_rtl::Turn::Finished(acc_pe.clone())
                    }
                }))
            }) as Rc<dyn Fn((Array<crate::lower::model::Item>, crate::check::env::TyInfo)) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Item>>>>
        }), move |fold_19795: Array<crate::lower::model::Item>| {
            let types_p7 = fold_19795;
            call_value(fold_job(values(&lx_p5.g.tags), Array::new(), {
                let m_p1 = m_p1.clone();
                let lx_p5 = lx_p5.clone();
                Rc::new(move |(p0, p1): (Array<crate::lower::model::Item>, crate::check::env::TagInfo)| {
                    let m_p1 = m_p1.clone();
                    let lx_p5 = lx_p5.clone();
                    entered(once_job(move || {
                        let acc_pg = p0;
                        let tg_ph = p1;
                        if (&tg_ph.home == &m_p1) && (&tg_ph.kind != &Text::lit("Prelude.Fault")) {
                            call_then(start_tag_def_of(lx_p5.clone(), tg_ph.clone()), move |tag_def_of_20016: crate::lower::model::TagDef| prism_rtl::Turn::Finished(push(&acc_pg, &crate::lower::model::Item::ItTag(tag_def_of_20016))))
                        } else {
                            prism_rtl::Turn::Finished(acc_pg.clone())
                        }
                    }))
                }) as Rc<dyn Fn((Array<crate::lower::model::Item>, crate::check::env::TagInfo)) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Item>>>>
            }), move |fold_19908: Array<crate::lower::model::Item>| {
                let tags_p8 = fold_19908;
                call_value(fold_job(lx_p5.g.defs.clone(), Array::new(), {
                    let m_p1 = m_p1.clone();
                    let lx_p5 = lx_p5.clone();
                    let roots_p2 = roots_p2.clone();
                    Rc::new(move |(p0, p1): (Array<crate::lower::model::Item>, crate::check::env::Def)| {
                        let m_p1 = m_p1.clone();
                        let lx_p5 = lx_p5.clone();
                        let roots_p2 = roots_p2.clone();
                        entered(once_job(move || {
                            let acc_pi = p0;
                            let d_pj = p1;
                            if &d_pj.home == &m_p1 {
                                call_then(start_def_items(in_module(&lx_p5, &d_pj.file, &m_p1), d_pj.clone(), roots_p2.clone()), move |def_items_20120: Array<crate::lower::model::Item>| prism_rtl::Turn::Finished(append(&acc_pi, &def_items_20120)))
                            } else {
                                prism_rtl::Turn::Finished(acc_pi.clone())
                            }
                        }))
                    }) as Rc<dyn Fn((Array<crate::lower::model::Item>, crate::check::env::Def)) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Item>>>>
                }), move |fold_20059: Array<crate::lower::model::Item>| {
                    let defs_p9 = fold_20059;
                    call_value(fold_job(values(&lx_p5.g.traits), Array::new(), {
                        let m_p1 = m_p1.clone();
                        let lx_p5 = lx_p5.clone();
                        Rc::new(move |(p0, p1): (Array<crate::lower::model::Item>, crate::check::env::TraitInfo)| {
                            let m_p1 = m_p1.clone();
                            let lx_p5 = lx_p5.clone();
                            entered(once_job(move || {
                                let acc_pk = p0;
                                let tr_pl = p1;
                                if &tr_pl.home == &m_p1 {
                                    call_then(crate::lower::functions::start_trait_def_of(lx_p5.clone(), tr_pl.clone()), move |trait_def_of_20273: crate::lower::model::TraitDef| prism_rtl::Turn::Finished(push(&acc_pk, &crate::lower::model::Item::ItTrait(trait_def_of_20273))))
                                } else {
                                    prism_rtl::Turn::Finished(acc_pk.clone())
                                }
                            }))
                        }) as Rc<dyn Fn((Array<crate::lower::model::Item>, crate::check::env::TraitInfo)) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Item>>>>
                    }), move |fold_20192: Array<crate::lower::model::Item>| {
                        let traits_pa = fold_20192;
                        call_value(fold_job(values(&lx_p5.g.impls), Array::new(), {
                            let m_p1 = m_p1.clone();
                            let lx_p5 = lx_p5.clone();
                            Rc::new(move |(p0, p1): (Array<crate::lower::model::Item>, Array<crate::check::env::ImplInfo>)| {
                                let m_p1 = m_p1.clone();
                                let lx_p5 = lx_p5.clone();
                                entered(once_job(move || {
                                    let acc_pm = p0;
                                    let ims_pn = p1;
                                    fold_job(ims_pn.clone(), acc_pm.clone(), {
                                        let m_p1 = m_p1.clone();
                                        let lx_p5 = lx_p5.clone();
                                        Rc::new(move |(p0, p1): (Array<crate::lower::model::Item>, crate::check::env::ImplInfo)| {
                                            let m_p1 = m_p1.clone();
                                            let lx_p5 = lx_p5.clone();
                                            entered(once_job(move || {
                                                let a_po = p0;
                                                let im_pp = p1;
                                                if (&im_pp.home == &m_p1) && !im_pp.derived {
                                                    call_then(crate::lower::functions::start_impl_def_of(in_module(&lx_p5, &im_pp.file, &m_p1), im_pp.clone()), move |impl_def_of_20440: crate::lower::model::ImplDef| prism_rtl::Turn::Finished(push(&a_po, &crate::lower::model::Item::ItImpl(impl_def_of_20440))))
                                                } else {
                                                    prism_rtl::Turn::Finished(a_po.clone())
                                                }
                                            }))
                                        }) as Rc<dyn Fn((Array<crate::lower::model::Item>, crate::check::env::ImplInfo)) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Item>>>>
                                    }).cycle()
                                }))
                            }) as Rc<dyn Fn((Array<crate::lower::model::Item>, Array<crate::check::env::ImplInfo>)) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Item>>>>
                        }), move |fold_20319: Array<crate::lower::model::Item>| {
                            let impls_pb = fold_20319;
                            let uses_pc = filter(&each(&mods_p4, &(|o_pq: &Text| crate::lower::rust_mod_name(o_pq))), &(|o_pr: &Text| o_pr != &crate::lower::rust_mod_name(&m_p1)));
                            prism_rtl::Turn::Finished(crate::lower::model::ModDef { name: crate::lower::rust_mod_name(&m_p1), prism: m_p1.clone(), path_: path_p6.clone(), uses: uses_pc.clone(), complete: Array::new(), declared: Array::new(), types_with: Array::new(), items: append(&append(&append(&append(&types_p7, &tags_p8), &traits_pa), &impls_pb), &defs_p9) })
                        })
                    })
                })
            })
        })
    }
}

/// `Start ModDefOf, x`: what the function value is when passed to `@Run`.
pub fn start_mod_def_of(lx0_p0: crate::lower::Lx, m_p1: Text, roots_p2: Array<(Text, bool)>, info_p3: crate::check::env::ModInfo, mods_p4: Array<Text>) -> Rc<dyn prism_rtl::Job<crate::lower::model::ModDef>> {
    Rc::new(ModDefOf { lx0_p0, m_p1, roots_p2, info_p3, mods_p4 })
}

/// ```prism
/// DefItems: unbounded fn Lx, Def, [((Text, Bool))] -> [Item]
/// ```
pub fn def_items(lx_p0: &crate::lower::Lx, d_p1: &crate::check::env::Def, roots_p2: &Array<(Text, bool)>) -> Array<crate::lower::model::Item> {
    let is_root_p3 = crate::check::types::has_text(&each(roots_p2, &(|(q_p4, _): &(Text, bool)| q_p4.clone())), &d_p1.qk);
    match &d_p1.body {
        crate::check::env::DefBody::DbWidget(w_p5) => if is_root_p3 {
            node_items(&crate::lower::node_::def::node_def_of(lx_p0, &d_p1.qk, &Array::new(), &w_p5.body, &or(&get(&lx_p0.g.vals, &d_p1.qk), &crate::check::env::builtin(&d_p1.qk, &crate::check::types::schemes::mono(&crate::check::types::Ty::TyErr))).scheme, &true))
        } else {
            Array::from(vec![crate::lower::model::Item::ItNote(Text::from(format!("`{}` is inlined where it is applied.", &d_p1.name)))])
        },
        crate::check::env::DefBody::DbFn(clauses_p6) => match get(&lx_p0.g.vals, &d_p1.qk) {
            None => Array::new(),
            Some(v_p7) => 'm21358: {
                let scrutinee = &v_p7.scheme.ty;
                if let crate::check::types::Ty::TyFn(_, _, m21358_0_2) = scrutinee && let crate::check::types::Ty::TyAt(_, _) = &**m21358_0_2 {
                    break 'm21358 if !is_root_p3 {
                        Array::from(vec![crate::lower::model::Item::ItNote(Text::from(format!("`{}` is inlined where it is applied.", &d_p1.name)))])
                    } else {
                        'm21554: {
                            if let m21554_0 = clauses_p6 && (m21554_0.len() == 1) && let Some(c_p8) = index(m21554_0, &Nat::from(0u32)) {
                                break 'm21554 match &c_p8.body {
                                    crate::syntax::decls::FnBody::BodyBlock(b_p9) => node_items(&crate::lower::node_::def::node_def_of(lx_p0, &d_p1.qk, &c_p8.params, b_p9, &v_p7.scheme, &true)),
                                    _ => Array::from(vec![crate::lower::model::Item::ItRefused(Text::from(format!("`{}`, a root widget whose body is one expression", &d_p1.name)))]),
                                };
                            }
                            Array::from(vec![crate::lower::model::Item::ItRefused(Text::from(format!("`{}`, a root widget of several clauses", &d_p1.name)))])
                        }
                    };
                }
                {
                    let f_pa = crate::lower::model::Item::ItFn(crate::lower::functions::fn_def_of(lx_p0, &d_p1.qk, clauses_p6, &v_p7.scheme));
                    if crate::check::types::has_text(&lx_p0.unbs, &d_p1.qk) {
                        Array::from(vec![f_pa.clone(), crate::lower::model::Item::ItJob(crate::lower::jobs::job_def_of(lx_p0, &d_p1.qk, clauses_p6, &v_p7.scheme))])
                    } else {
                        Array::from(vec![f_pa.clone()])
                    }
                }
            },
        },
        crate::check::env::DefBody::DbLet(l_pb) => Array::from(vec![crate::lower::model::Item::ItFn(crate::lower::functions::let_getter(lx_p0, &d_p1.qk, l_pb))]),
        _ => Array::new(),
    }
}

/// The step machine of `DefItems`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// DefItems: unbounded fn Lx, Def, [((Text, Bool))] -> [Item]
/// ```
pub struct DefItems {
    pub lx_p0: crate::lower::Lx,
    pub d_p1: crate::check::env::Def,
    pub roots_p2: Array<(Text, bool)>,
}

impl prism_rtl::Job<Array<crate::lower::model::Item>> for DefItems {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::lower::model::Item>> {
        let lx_p0 = &self.lx_p0;
        let d_p1 = &self.d_p1;
        let roots_p2 = &self.roots_p2;
        let is_root_p3 = crate::check::types::has_text(&each(roots_p2, &(|(q_p4, _): &(Text, bool)| q_p4.clone())), &d_p1.qk);
        match &d_p1.body {
            crate::check::env::DefBody::DbWidget(w_p5) => if is_root_p3 {
                {
                    let d_p1 = d_p1.clone();
                    let lx_p0 = lx_p0.clone();
                    let w_p5 = w_p5.clone();
                    call_then(crate::lower::node_::def::start_node_def_of(lx_p0.clone(), d_p1.qk.clone(), Array::new(), w_p5.body.clone(), or(&get(&lx_p0.g.vals, &d_p1.qk), &crate::check::env::builtin(&d_p1.qk, &crate::check::types::schemes::mono(&crate::check::types::Ty::TyErr))).scheme.clone(), true), move |node_def_of_21101: crate::lower::model::NodeDef| prism_rtl::Turn::Finished(node_items(&node_def_of_21101)))
                }
            } else {
                prism_rtl::Turn::Finished(Array::from(vec![crate::lower::model::Item::ItNote(Text::from(format!("`{}` is inlined where it is applied.", &d_p1.name)))]))
            },
            crate::check::env::DefBody::DbFn(clauses_p6) => match get(&lx_p0.g.vals, &d_p1.qk) {
                None => prism_rtl::Turn::Finished(Array::new()),
                Some(v_p7) => 'm21358: {
                    let scrutinee = &v_p7.scheme.ty;
                    if let crate::check::types::Ty::TyFn(_, _, m21358_0_2) = scrutinee && let crate::check::types::Ty::TyAt(_, _) = &**m21358_0_2 {
                        break 'm21358 if !is_root_p3 {
                            prism_rtl::Turn::Finished(Array::from(vec![crate::lower::model::Item::ItNote(Text::from(format!("`{}` is inlined where it is applied.", &d_p1.name)))]))
                        } else {
                            'm21554: {
                                if let m21554_0 = clauses_p6 && (m21554_0.len() == 1) && let Some(c_p8) = index(m21554_0, &Nat::from(0u32)) {
                                    break 'm21554 match &c_p8.body {
                                        crate::syntax::decls::FnBody::BodyBlock(b_p9) => {
                                            let b_p9 = b_p9.clone();
                                            let d_p1 = d_p1.clone();
                                            let lx_p0 = lx_p0.clone();
                                            call_then(crate::lower::node_::def::start_node_def_of(lx_p0.clone(), d_p1.qk.clone(), c_p8.params.clone(), b_p9.clone(), v_p7.scheme.clone(), true), move |node_def_of_21666: crate::lower::model::NodeDef| prism_rtl::Turn::Finished(node_items(&node_def_of_21666)))
                                        },
                                        _ => prism_rtl::Turn::Finished(Array::from(vec![crate::lower::model::Item::ItRefused(Text::from(format!("`{}`, a root widget whose body is one expression", &d_p1.name)))])),
                                    };
                                }
                                prism_rtl::Turn::Finished(Array::from(vec![crate::lower::model::Item::ItRefused(Text::from(format!("`{}`, a root widget of several clauses", &d_p1.name)))]))
                            }
                        };
                    }
                    {
                        let clauses_p6 = clauses_p6.clone();
                        let d_p1 = d_p1.clone();
                        let lx_p0 = lx_p0.clone();
                        call_then(crate::lower::functions::start_fn_def_of(lx_p0.clone(), d_p1.qk.clone(), clauses_p6.clone(), v_p7.scheme.clone()), move |fn_def_of_21982: crate::lower::model::FnDef| {
                            let f_pa = crate::lower::model::Item::ItFn(fn_def_of_21982);
                            if crate::check::types::has_text(&lx_p0.unbs, &d_p1.qk) {
                                call_then(crate::lower::jobs::start_job_def_of(lx_p0.clone(), d_p1.qk.clone(), clauses_p6.clone(), v_p7.scheme.clone()), move |job_def_of_22077: crate::lower::model::JobDef| prism_rtl::Turn::Finished(Array::from(vec![f_pa.clone(), crate::lower::model::Item::ItJob(job_def_of_22077)])))
                            } else {
                                prism_rtl::Turn::Finished(Array::from(vec![f_pa.clone()]))
                            }
                        })
                    }
                },
            },
            crate::check::env::DefBody::DbLet(l_pb) => {
                let d_p1 = d_p1.clone();
                let l_pb = l_pb.clone();
                let lx_p0 = lx_p0.clone();
                call_then(crate::lower::functions::start_let_getter(lx_p0.clone(), d_p1.qk.clone(), l_pb.clone()), move |let_getter_22154: crate::lower::model::FnDef| prism_rtl::Turn::Finished(Array::from(vec![crate::lower::model::Item::ItFn(let_getter_22154)])))
            },
            _ => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start DefItems, x`: what the function value is when passed to `@Run`.
pub fn start_def_items(lx_p0: crate::lower::Lx, d_p1: crate::check::env::Def, roots_p2: Array<(Text, bool)>) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Item>>> {
    Rc::new(DefItems { lx_p0, d_p1, roots_p2 })
}

/// ```prism
/// NodeItems: fn NodeDef -> [Item]
/// ```
pub fn node_items(n_p0: &crate::lower::model::NodeDef) -> Array<crate::lower::model::Item> {
    append(&Array::from(vec![crate::lower::model::Item::ItNode(n_p0.clone())]), &each(&n_p0.children, &(|c_p1: &crate::lower::model::NodeDef| crate::lower::model::Item::ItNode(c_p1.clone()))))
}

/// ```prism
/// TyDefs: unbounded fn Lx, TyInfo -> [Item]
/// ```
pub fn ty_defs(lx_p0: &crate::lower::Lx, ti_p1: &crate::check::env::TyInfo) -> Array<crate::lower::model::Item> {
    let derives_p2 = each(&ti_p1.derives, &(|dn_p6: &Text| crate::check::types::bare_name(dn_p6)));
    let params_p3 = each(&ti_p1.params, &(|p_p7: &Text| crate::lower::camel(p_p7)));
    let bare_p4 = crate::check::types::bare_name(&ti_p1.name);
    let mk_f5 = {
        let bare_p4 = bare_p4.clone();
        let params_p3 = params_p3.clone();
        let derives_p2 = derives_p2.clone();
        let lx_p0 = lx_p0.clone();
        let ti_p1 = ti_p1.clone();
        Rc::new(move |(p0, p1): (crate::lower::model::TyShape, Array<crate::lower::model::CaseDef>)| {
            let bare_p4 = bare_p4.clone();
            let params_p3 = params_p3.clone();
            let derives_p2 = derives_p2.clone();
            let lx_p0 = lx_p0.clone();
            let ti_p1 = ti_p1.clone();
            entered(once_job(move || {
                let shape_p8 = p0;
                let cases_p9 = p1;
                call_then(start_ty_podable(lx_p0.clone(), crate::check::types::Ty::TyCon(ti_p1.name.clone(), Array::new()), Array::new()), move |ty_podable_22873: bool| prism_rtl::Turn::Finished(crate::lower::model::TyDef { name: crate::lower::camel(&bare_p4), prism: bare_p4.clone(), params: params_p3.clone(), shape: shape_p8.clone(), cases: cases_p9.clone(), eq: crate::check::types::has_text(&derives_p2, &Text::lit("Eq")), ord: crate::check::types::has_text(&derives_p2, &Text::lit("Ord")), show: if crate::lower::functions::has_own_show(&lx_p0, &ti_p1.name) {
                    crate::lower::model::Shown::ShownOwn
                } else {
                    if crate::check::types::has_text(&derives_p2, &Text::lit("Show")) {
                        crate::lower::model::Shown::ShownDerived
                    } else {
                        crate::lower::model::Shown::NotShown
                    }
                }, pod: ty_podable_22873 && run_to_end(fold_job(cases_p9.clone(), true, Rc::new(move |(p0, p1): (bool, crate::lower::model::CaseDef)| entered(once_job(move || {
                    let ok_pa = p0;
                    let c_pb = p1;
                    prism_rtl::Turn::Finished(ok_pa && run_to_end(fold_job(c_pb.fields.clone(), true, Rc::new(move |(p0, p1): (bool, (Text, crate::lower::model::OutTy))| entered(once_job(move || {
                        let ok2_pc = p0;
                        let (_, ft_pd) = p1;
                        prism_rtl::Turn::Finished(ok2_pc && crate::lower::types::podable(&ft_pd))
                    }))) as Rc<dyn Fn((bool, (Text, crate::lower::model::OutTy))) -> Rc<dyn prism_rtl::Job<bool>>>)))
                }))) as Rc<dyn Fn((bool, crate::lower::model::CaseDef)) -> Rc<dyn prism_rtl::Job<bool>>>)), doc: type_doc(&lx_p0, &ti_p1) }))
            }))
        }) as Rc<dyn Fn((crate::lower::model::TyShape, Array<crate::lower::model::CaseDef>)) -> Rc<dyn prism_rtl::Job<crate::lower::model::TyDef>>>
    };
    match &ti_p1.body {
        crate::check::env::TyBody::BRecord(fs_pe) => {
            let fields_pf = run_to_end(each_job(crate::check::errors::range0(&len(fs_pe)), {
                let fs_pe = fs_pe.clone();
                let lx_p0 = lx_p0.clone();
                let ti_p1 = ti_p1.clone();
                Rc::new(move |p0: Nat| {
                    let fs_pe = fs_pe.clone();
                    let lx_p0 = lx_p0.clone();
                    let ti_p1 = ti_p1.clone();
                    entered(once_job(move || {
                        let i_pg = p0;
                        {
                            let (fname_pi, ft_pj) = or(&index(&fs_pe, &i_pg), &(Text::lit(""), crate::check::types::Ty::TyErr));
                            call_then(crate::lower::types::start_out_ty_of(lx_p0.clone(), ft_pj.clone()), move |out_ty_of_23219: crate::lower::model::OutTy| {
                                let rt_ph = out_ty_of_23219;
                                prism_rtl::Turn::Finished((crate::lower::snake(&fname_pi), if crate::lower::types::rc_field(&lx_p0, &ti_p1.name, &i_pg) {
                                    crate::lower::model::OutTy::OutRc(Rc::new(rt_ph.clone()))
                                } else {
                                    rt_ph.clone()
                                }))
                            })
                        }
                    }))
                }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<(Text, crate::lower::model::OutTy)>>>
            }));
            Array::from(vec![crate::lower::model::Item::ItType(run_to_end((&mk_f5)((crate::lower::model::TyShape::ShapeRecord, Array::from(vec![crate::lower::model::CaseDef { name: crate::lower::camel(&bare_p4), prism: bare_p4.clone(), fields: fields_pf.clone() }])))))])
        },
        crate::check::env::TyBody::BChoice(cases_pk) => {
            let defs_pl = run_to_end(each_job(cases_pk.clone(), {
                let ti_p1 = ti_p1.clone();
                let lx_p0 = lx_p0.clone();
                Rc::new(move |p0: (Text, Array<crate::check::types::Ty>)| {
                    let ti_p1 = ti_p1.clone();
                    let lx_p0 = lx_p0.clone();
                    entered(once_job(move || {
                        let (cn_pn, ats_po) = p0;
                        {
                            let ck_pp = crate::check::env::qual_key(&ti_p1.home, &cn_pn);
                            call_value(each_job(crate::check::errors::range0(&len(&ats_po)), {
                                let lx_p0 = lx_p0.clone();
                                let ck_pp = ck_pp.clone();
                                let ats_po = ats_po.clone();
                                Rc::new(move |p0: Nat| {
                                    let lx_p0 = lx_p0.clone();
                                    let ck_pp = ck_pp.clone();
                                    let ats_po = ats_po.clone();
                                    entered(once_job(move || {
                                        let i_pq = p0;
                                        call_then(start_case_field(lx_p0.clone(), ck_pp.clone(), i_pq.clone(), or(&index(&ats_po, &i_pq), &crate::check::types::Ty::TyErr)), move |case_field_23627: crate::lower::model::OutTy| prism_rtl::Turn::Finished((Text::lit(""), case_field_23627)))
                                    }))
                                }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<(Text, crate::lower::model::OutTy)>>>
                            }), move |each_23590: Array<(Text, crate::lower::model::OutTy)>| prism_rtl::Turn::Finished(crate::lower::model::CaseDef { name: crate::lower::camel(&cn_pn), prism: cn_pn.clone(), fields: each_23590 }))
                        }
                    }))
                }) as Rc<dyn Fn((Text, Array<crate::check::types::Ty>)) -> Rc<dyn prism_rtl::Job<crate::lower::model::CaseDef>>>
            }));
            let shape_pm = 'm23696: {
                if let m23696_0 = cases_pk && (m23696_0.len() == 1) && let Some((cn_pr, m23696_0_0_1)) = index(m23696_0, &Nat::from(0u32)) && ((&m23696_0_0_1).len() == 0) {
                    break 'm23696 if crate::check::env::is_lower_text(&cn_pr) {
                        crate::lower::model::TyShape::ShapeUnit
                    } else {
                        crate::lower::model::TyShape::ShapeChoice
                    };
                }
                if let m23696_1 = cases_pk && (m23696_1.len() == 1) && let Some((cn_ps, _)) = index(m23696_1, &Nat::from(0u32)) {
                    break 'm23696 if &cn_ps == &bare_p4 {
                        crate::lower::model::TyShape::ShapeNewtype
                    } else {
                        crate::lower::model::TyShape::ShapeChoice
                    };
                }
                crate::lower::model::TyShape::ShapeChoice
            };
            Array::from(vec![crate::lower::model::Item::ItType(run_to_end((&mk_f5)((shape_pm.clone(), defs_pl.clone()))))])
        },
        crate::check::env::TyBody::BRowKind => if &ti_p1.name == &Text::lit("Prelude.Fault") {
            Array::new()
        } else {
            Array::from(vec![crate::lower::model::Item::ItRow(row_def_of(lx_p0, ti_p1))])
        },
        _ => Array::new(),
    }
}

/// The step machine of `TyDefs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TyDefs: unbounded fn Lx, TyInfo -> [Item]
/// ```
pub struct TyDefs {
    pub lx_p0: crate::lower::Lx,
    pub ti_p1: crate::check::env::TyInfo,
}

impl prism_rtl::Job<Array<crate::lower::model::Item>> for TyDefs {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::lower::model::Item>> {
        let lx_p0 = &self.lx_p0;
        let ti_p1 = &self.ti_p1;
        let derives_p2 = each(&ti_p1.derives, &(|dn_p6: &Text| crate::check::types::bare_name(dn_p6)));
        let params_p3 = each(&ti_p1.params, &(|p_p7: &Text| crate::lower::camel(p_p7)));
        let bare_p4 = crate::check::types::bare_name(&ti_p1.name);
        let mk_f5 = {
            let bare_p4 = bare_p4.clone();
            let params_p3 = params_p3.clone();
            let derives_p2 = derives_p2.clone();
            let lx_p0 = lx_p0.clone();
            let ti_p1 = ti_p1.clone();
            Rc::new(move |(p0, p1): (crate::lower::model::TyShape, Array<crate::lower::model::CaseDef>)| {
                let bare_p4 = bare_p4.clone();
                let params_p3 = params_p3.clone();
                let derives_p2 = derives_p2.clone();
                let lx_p0 = lx_p0.clone();
                let ti_p1 = ti_p1.clone();
                entered(once_job(move || {
                    let shape_p8 = p0;
                    let cases_p9 = p1;
                    call_then(start_ty_podable(lx_p0.clone(), crate::check::types::Ty::TyCon(ti_p1.name.clone(), Array::new()), Array::new()), move |ty_podable_22873: bool| prism_rtl::Turn::Finished(crate::lower::model::TyDef { name: crate::lower::camel(&bare_p4), prism: bare_p4.clone(), params: params_p3.clone(), shape: shape_p8.clone(), cases: cases_p9.clone(), eq: crate::check::types::has_text(&derives_p2, &Text::lit("Eq")), ord: crate::check::types::has_text(&derives_p2, &Text::lit("Ord")), show: if crate::lower::functions::has_own_show(&lx_p0, &ti_p1.name) {
                        crate::lower::model::Shown::ShownOwn
                    } else {
                        if crate::check::types::has_text(&derives_p2, &Text::lit("Show")) {
                            crate::lower::model::Shown::ShownDerived
                        } else {
                            crate::lower::model::Shown::NotShown
                        }
                    }, pod: ty_podable_22873 && run_to_end(fold_job(cases_p9.clone(), true, Rc::new(move |(p0, p1): (bool, crate::lower::model::CaseDef)| entered(once_job(move || {
                        let ok_pa = p0;
                        let c_pb = p1;
                        prism_rtl::Turn::Finished(ok_pa && run_to_end(fold_job(c_pb.fields.clone(), true, Rc::new(move |(p0, p1): (bool, (Text, crate::lower::model::OutTy))| entered(once_job(move || {
                            let ok2_pc = p0;
                            let (_, ft_pd) = p1;
                            prism_rtl::Turn::Finished(ok2_pc && crate::lower::types::podable(&ft_pd))
                        }))) as Rc<dyn Fn((bool, (Text, crate::lower::model::OutTy))) -> Rc<dyn prism_rtl::Job<bool>>>)))
                    }))) as Rc<dyn Fn((bool, crate::lower::model::CaseDef)) -> Rc<dyn prism_rtl::Job<bool>>>)), doc: type_doc(&lx_p0, &ti_p1) }))
                }))
            }) as Rc<dyn Fn((crate::lower::model::TyShape, Array<crate::lower::model::CaseDef>)) -> Rc<dyn prism_rtl::Job<crate::lower::model::TyDef>>>
        };
        match &ti_p1.body {
            crate::check::env::TyBody::BRecord(fs_pe) => {
                let fs_pe = fs_pe.clone();
                let lx_p0 = lx_p0.clone();
                let ti_p1 = ti_p1.clone();
                call_value(each_job(crate::check::errors::range0(&len(&fs_pe)), {
                    let fs_pe = fs_pe.clone();
                    let lx_p0 = lx_p0.clone();
                    let ti_p1 = ti_p1.clone();
                    Rc::new(move |p0: Nat| {
                        let fs_pe = fs_pe.clone();
                        let lx_p0 = lx_p0.clone();
                        let ti_p1 = ti_p1.clone();
                        entered(once_job(move || {
                            let i_pg = p0;
                            {
                                let (fname_pi, ft_pj) = or(&index(&fs_pe, &i_pg), &(Text::lit(""), crate::check::types::Ty::TyErr));
                                call_then(crate::lower::types::start_out_ty_of(lx_p0.clone(), ft_pj.clone()), move |out_ty_of_23219: crate::lower::model::OutTy| {
                                    let rt_ph = out_ty_of_23219;
                                    prism_rtl::Turn::Finished((crate::lower::snake(&fname_pi), if crate::lower::types::rc_field(&lx_p0, &ti_p1.name, &i_pg) {
                                        crate::lower::model::OutTy::OutRc(Rc::new(rt_ph.clone()))
                                    } else {
                                        rt_ph.clone()
                                    }))
                                })
                            }
                        }))
                    }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<(Text, crate::lower::model::OutTy)>>>
                }), move |each_23105: Array<(Text, crate::lower::model::OutTy)>| {
                    let fields_pf = each_23105;
                    call_value((&mk_f5)((crate::lower::model::TyShape::ShapeRecord, Array::from(vec![crate::lower::model::CaseDef { name: crate::lower::camel(&bare_p4), prism: bare_p4.clone(), fields: fields_pf.clone() }]))), move |mk_23336: crate::lower::model::TyDef| prism_rtl::Turn::Finished(Array::from(vec![crate::lower::model::Item::ItType(mk_23336)])))
                })
            },
            crate::check::env::TyBody::BChoice(cases_pk) => {
                let cases_pk = cases_pk.clone();
                let lx_p0 = lx_p0.clone();
                let ti_p1 = ti_p1.clone();
                call_value(each_job(cases_pk.clone(), {
                    let ti_p1 = ti_p1.clone();
                    let lx_p0 = lx_p0.clone();
                    Rc::new(move |p0: (Text, Array<crate::check::types::Ty>)| {
                        let ti_p1 = ti_p1.clone();
                        let lx_p0 = lx_p0.clone();
                        entered(once_job(move || {
                            let (cn_pn, ats_po) = p0;
                            {
                                let ck_pp = crate::check::env::qual_key(&ti_p1.home, &cn_pn);
                                call_value(each_job(crate::check::errors::range0(&len(&ats_po)), {
                                    let lx_p0 = lx_p0.clone();
                                    let ck_pp = ck_pp.clone();
                                    let ats_po = ats_po.clone();
                                    Rc::new(move |p0: Nat| {
                                        let lx_p0 = lx_p0.clone();
                                        let ck_pp = ck_pp.clone();
                                        let ats_po = ats_po.clone();
                                        entered(once_job(move || {
                                            let i_pq = p0;
                                            call_then(start_case_field(lx_p0.clone(), ck_pp.clone(), i_pq.clone(), or(&index(&ats_po, &i_pq), &crate::check::types::Ty::TyErr)), move |case_field_23627: crate::lower::model::OutTy| prism_rtl::Turn::Finished((Text::lit(""), case_field_23627)))
                                        }))
                                    }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<(Text, crate::lower::model::OutTy)>>>
                                }), move |each_23590: Array<(Text, crate::lower::model::OutTy)>| prism_rtl::Turn::Finished(crate::lower::model::CaseDef { name: crate::lower::camel(&cn_pn), prism: cn_pn.clone(), fields: each_23590 }))
                            }
                        }))
                    }) as Rc<dyn Fn((Text, Array<crate::check::types::Ty>)) -> Rc<dyn prism_rtl::Job<crate::lower::model::CaseDef>>>
                }), move |each_23459: Array<crate::lower::model::CaseDef>| {
                    let defs_pl = each_23459;
                    let shape_pm = 'm23696: {
                        if let m23696_0 = &cases_pk && (m23696_0.len() == 1) && let Some((cn_pr, m23696_0_0_1)) = index(m23696_0, &Nat::from(0u32)) && ((&m23696_0_0_1).len() == 0) {
                            break 'm23696 if crate::check::env::is_lower_text(&cn_pr) {
                                crate::lower::model::TyShape::ShapeUnit
                            } else {
                                crate::lower::model::TyShape::ShapeChoice
                            };
                        }
                        if let m23696_1 = &cases_pk && (m23696_1.len() == 1) && let Some((cn_ps, _)) = index(m23696_1, &Nat::from(0u32)) {
                            break 'm23696 if &cn_ps == &bare_p4 {
                                crate::lower::model::TyShape::ShapeNewtype
                            } else {
                                crate::lower::model::TyShape::ShapeChoice
                            };
                        }
                        crate::lower::model::TyShape::ShapeChoice
                    };
                    call_value((&mk_f5)((shape_pm.clone(), defs_pl.clone())), move |mk_23933: crate::lower::model::TyDef| prism_rtl::Turn::Finished(Array::from(vec![crate::lower::model::Item::ItType(mk_23933)])))
                })
            },
            crate::check::env::TyBody::BRowKind => if &ti_p1.name == &Text::lit("Prelude.Fault") {
                prism_rtl::Turn::Finished(Array::new())
            } else {
                {
                    let lx_p0 = lx_p0.clone();
                    let ti_p1 = ti_p1.clone();
                    call_then(start_row_def_of(lx_p0.clone(), ti_p1.clone()), move |row_def_of_24020: crate::lower::model::RowDef| prism_rtl::Turn::Finished(Array::from(vec![crate::lower::model::Item::ItRow(row_def_of_24020)])))
                }
            },
            _ => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start TyDefs, x`: what the function value is when passed to `@Run`.
pub fn start_ty_defs(lx_p0: crate::lower::Lx, ti_p1: crate::check::env::TyInfo) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Item>>> {
    Rc::new(TyDefs { lx_p0, ti_p1 })
}

/// ```prism
/// TyPodable: unbounded fn Lx, Ty, [Text] -> Bool
/// ```
pub fn ty_podable(lx_p0: &crate::lower::Lx, t_p1: &crate::check::types::Ty, seen_p2: &Array<Text>) -> bool {
    match t_p1 {
        crate::check::types::Ty::TyFn(_, _, _) => false,
        crate::check::types::Ty::TyAt(_, _) => false,
        crate::check::types::Ty::TySig(m24341_2_0, _) if (m24341_2_0 == &Text::lit("!")) => false,
        crate::check::types::Ty::TySig(m24341_3_0, _) if (m24341_3_0 == &Text::lit("$")) => false,
        crate::check::types::Ty::TySig(_, i_p3) => ty_podable(lx_p0, &**i_p3, seen_p2),
        crate::check::types::Ty::TyTuple(ts_p4) => run_to_end(fold_job(ts_p4.clone(), true, {
            let lx_p0 = lx_p0.clone();
            let seen_p2 = seen_p2.clone();
            Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| {
                let lx_p0 = lx_p0.clone();
                let seen_p2 = seen_p2.clone();
                entered(once_job(move || {
                    let ok_p5 = p0;
                    let x_p6 = p1;
                    prism_rtl::Turn::Finished(ok_p5 && ty_podable(&lx_p0, &x_p6, &seen_p2))
                }))
            }) as Rc<dyn Fn((bool, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<bool>>>
        })),
        crate::check::types::Ty::TyArray(e_p7) => ty_podable(lx_p0, &**e_p7, seen_p2),
        crate::check::types::Ty::TyMap(k_p8, v_p9) => ty_podable(lx_p0, &**k_p8, seen_p2) && ty_podable(lx_p0, &**v_p9, seen_p2),
        crate::check::types::Ty::TyCon(n_pa, args_pb) => if crate::check::types::has_text(seen_p2, n_pa) {
            true
        } else {
            {
                let more_pc = push(seen_p2, n_pa);
                let args_ok_pd = run_to_end(fold_job(args_pb.clone(), true, {
                    let lx_p0 = lx_p0.clone();
                    let more_pc = more_pc.clone();
                    Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| {
                        let lx_p0 = lx_p0.clone();
                        let more_pc = more_pc.clone();
                        entered(once_job(move || {
                            let ok_pe = p0;
                            let x_pf = p1;
                            prism_rtl::Turn::Finished(ok_pe && ty_podable(&lx_p0, &x_pf, &more_pc))
                        }))
                    }) as Rc<dyn Fn((bool, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<bool>>>
                }));
                args_ok_pd && match get(&lx_p0.g.types, n_pa) {
                    Some(ti_pg) => match &ti_pg.body {
                        crate::check::env::TyBody::BRecord(fs_ph) => run_to_end(fold_job(fs_ph.clone(), true, {
                            let lx_p0 = lx_p0.clone();
                            let more_pc = more_pc.clone();
                            Rc::new(move |(p0, p1): (bool, (Text, crate::check::types::Ty))| {
                                let lx_p0 = lx_p0.clone();
                                let more_pc = more_pc.clone();
                                entered(once_job(move || {
                                    let ok_pi = p0;
                                    let (_, ft_pj) = p1;
                                    prism_rtl::Turn::Finished(ok_pi && ty_podable(&lx_p0, &ft_pj, &more_pc))
                                }))
                            }) as Rc<dyn Fn((bool, (Text, crate::check::types::Ty))) -> Rc<dyn prism_rtl::Job<bool>>>
                        })),
                        crate::check::env::TyBody::BChoice(cs_pk) => run_to_end(fold_job(cs_pk.clone(), true, {
                            let lx_p0 = lx_p0.clone();
                            let more_pc = more_pc.clone();
                            Rc::new(move |(p0, p1): (bool, (Text, Array<crate::check::types::Ty>))| {
                                let lx_p0 = lx_p0.clone();
                                let more_pc = more_pc.clone();
                                entered(once_job(move || {
                                    let ok_pl = p0;
                                    let (_, ats_pm) = p1;
                                    prism_rtl::Turn::Finished(ok_pl && run_to_end(fold_job(ats_pm.clone(), true, {
                                        let lx_p0 = lx_p0.clone();
                                        let more_pc = more_pc.clone();
                                        Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| {
                                            let lx_p0 = lx_p0.clone();
                                            let more_pc = more_pc.clone();
                                            entered(once_job(move || {
                                                let ok2_pn = p0;
                                                let x_po = p1;
                                                prism_rtl::Turn::Finished(ok2_pn && ty_podable(&lx_p0, &x_po, &more_pc))
                                            }))
                                        }) as Rc<dyn Fn((bool, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<bool>>>
                                    })))
                                }))
                            }) as Rc<dyn Fn((bool, (Text, Array<crate::check::types::Ty>))) -> Rc<dyn prism_rtl::Job<bool>>>
                        })),
                        crate::check::env::TyBody::BAlias(a_pp) => ty_podable(lx_p0, a_pp, &more_pc),
                        _ => true,
                    },
                    None => true,
                }
            }
        },
        _ => true,
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `TyPodable`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TyPodable: unbounded fn Lx, Ty, [Text] -> Bool
/// ```
pub struct TyPodable {
    pub lx_p0: crate::lower::Lx,
    pub t_p1: crate::check::types::Ty,
    pub seen_p2: Array<Text>,
}

impl prism_rtl::Job<bool> for TyPodable {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let lx_p0 = &self.lx_p0;
        let t_p1 = &self.t_p1;
        let seen_p2 = &self.seen_p2;
        match t_p1 {
            crate::check::types::Ty::TyFn(_, _, _) => prism_rtl::Turn::Finished(false),
            crate::check::types::Ty::TyAt(_, _) => prism_rtl::Turn::Finished(false),
            crate::check::types::Ty::TySig(m24341_2_0, _) if (m24341_2_0 == &Text::lit("!")) => prism_rtl::Turn::Finished(false),
            crate::check::types::Ty::TySig(m24341_3_0, _) if (m24341_3_0 == &Text::lit("$")) => prism_rtl::Turn::Finished(false),
            crate::check::types::Ty::TySig(_, i_p3) => prism_rtl::Turn::More(Rc::new(TyPodable { lx_p0: lx_p0.clone(), t_p1: (**i_p3).clone(), seen_p2: seen_p2.clone() })),
            crate::check::types::Ty::TyTuple(ts_p4) => fold_job(ts_p4.clone(), true, {
                let lx_p0 = lx_p0.clone();
                let seen_p2 = seen_p2.clone();
                Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| {
                    let lx_p0 = lx_p0.clone();
                    let seen_p2 = seen_p2.clone();
                    entered(once_job(move || {
                        let ok_p5 = p0;
                        let x_p6 = p1;
                        prism_rtl::Turn::Finished(ok_p5 && ty_podable(&lx_p0, &x_p6, &seen_p2))
                    }))
                }) as Rc<dyn Fn((bool, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<bool>>>
            }).cycle(),
            crate::check::types::Ty::TyArray(e_p7) => prism_rtl::Turn::More(Rc::new(TyPodable { lx_p0: lx_p0.clone(), t_p1: (**e_p7).clone(), seen_p2: seen_p2.clone() })),
            crate::check::types::Ty::TyMap(k_p8, v_p9) => {
                let k_p8 = (**k_p8).clone();
                let lx_p0 = lx_p0.clone();
                let seen_p2 = seen_p2.clone();
                let v_p9 = (**v_p9).clone();
                call_then(start_ty_podable(lx_p0.clone(), k_p8.clone(), seen_p2.clone()), move |ty_podable_24644: bool| prism_rtl::Turn::Finished(ty_podable_24644 && ty_podable(&lx_p0, &v_p9, &seen_p2)))
            },
            crate::check::types::Ty::TyCon(n_pa, args_pb) => if crate::check::types::has_text(seen_p2, n_pa) {
                prism_rtl::Turn::Finished(true)
            } else {
                {
                    let more_pc = push(seen_p2, n_pa);
                    let args_pb = args_pb.clone();
                    let lx_p0 = lx_p0.clone();
                    let n_pa = n_pa.clone();
                    call_value(fold_job(args_pb.clone(), true, {
                        let lx_p0 = lx_p0.clone();
                        let more_pc = more_pc.clone();
                        Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| {
                            let lx_p0 = lx_p0.clone();
                            let more_pc = more_pc.clone();
                            entered(once_job(move || {
                                let ok_pe = p0;
                                let x_pf = p1;
                                prism_rtl::Turn::Finished(ok_pe && ty_podable(&lx_p0, &x_pf, &more_pc))
                            }))
                        }) as Rc<dyn Fn((bool, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<bool>>>
                    }), move |fold_24820: bool| {
                        let args_ok_pd = fold_24820;
                        prism_rtl::Turn::Finished(args_ok_pd && match get(&lx_p0.g.types, &n_pa) {
                            Some(ti_pg) => match &ti_pg.body {
                                crate::check::env::TyBody::BRecord(fs_ph) => run_to_end(fold_job(fs_ph.clone(), true, {
                                    let lx_p0 = lx_p0.clone();
                                    let more_pc = more_pc.clone();
                                    Rc::new(move |(p0, p1): (bool, (Text, crate::check::types::Ty))| {
                                        let lx_p0 = lx_p0.clone();
                                        let more_pc = more_pc.clone();
                                        entered(once_job(move || {
                                            let ok_pi = p0;
                                            let (_, ft_pj) = p1;
                                            prism_rtl::Turn::Finished(ok_pi && ty_podable(&lx_p0, &ft_pj, &more_pc))
                                        }))
                                    }) as Rc<dyn Fn((bool, (Text, crate::check::types::Ty))) -> Rc<dyn prism_rtl::Job<bool>>>
                                })),
                                crate::check::env::TyBody::BChoice(cs_pk) => run_to_end(fold_job(cs_pk.clone(), true, {
                                    let lx_p0 = lx_p0.clone();
                                    let more_pc = more_pc.clone();
                                    Rc::new(move |(p0, p1): (bool, (Text, Array<crate::check::types::Ty>))| {
                                        let lx_p0 = lx_p0.clone();
                                        let more_pc = more_pc.clone();
                                        entered(once_job(move || {
                                            let ok_pl = p0;
                                            let (_, ats_pm) = p1;
                                            prism_rtl::Turn::Finished(ok_pl && run_to_end(fold_job(ats_pm.clone(), true, {
                                                let lx_p0 = lx_p0.clone();
                                                let more_pc = more_pc.clone();
                                                Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| {
                                                    let lx_p0 = lx_p0.clone();
                                                    let more_pc = more_pc.clone();
                                                    entered(once_job(move || {
                                                        let ok2_pn = p0;
                                                        let x_po = p1;
                                                        prism_rtl::Turn::Finished(ok2_pn && ty_podable(&lx_p0, &x_po, &more_pc))
                                                    }))
                                                }) as Rc<dyn Fn((bool, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<bool>>>
                                            })))
                                        }))
                                    }) as Rc<dyn Fn((bool, (Text, Array<crate::check::types::Ty>))) -> Rc<dyn prism_rtl::Job<bool>>>
                                })),
                                crate::check::env::TyBody::BAlias(a_pp) => ty_podable(&lx_p0, a_pp, &more_pc),
                                _ => true,
                            },
                            None => true,
                        })
                    })
                }
            },
            _ => prism_rtl::Turn::Finished(true),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start TyPodable, x`: what the function value is when passed to `@Run`.
pub fn start_ty_podable(lx_p0: crate::lower::Lx, t_p1: crate::check::types::Ty, seen_p2: Array<Text>) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(TyPodable { lx_p0, t_p1, seen_p2 })
}

/// ```prism
/// TyHasEq: unbounded fn Lx, Ty, [Text] -> Bool
/// ```
pub fn ty_has_eq(lx_p0: &crate::lower::Lx, t_p1: &crate::check::types::Ty, seen_p2: &Array<Text>) -> bool {
    match t_p1 {
        crate::check::types::Ty::TyFn(_, _, _) => false,
        crate::check::types::Ty::TyAt(_, _) => false,
        crate::check::types::Ty::TySig(m25774_2_0, _) if (m25774_2_0 == &Text::lit("!")) => false,
        crate::check::types::Ty::TySig(m25774_3_0, _) if (m25774_3_0 == &Text::lit("$")) => false,
        crate::check::types::Ty::TySig(_, i_p3) => ty_has_eq(lx_p0, &**i_p3, seen_p2),
        crate::check::types::Ty::TyTuple(ts_p4) => run_to_end(fold_job(ts_p4.clone(), true, {
            let lx_p0 = lx_p0.clone();
            let seen_p2 = seen_p2.clone();
            Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| {
                let lx_p0 = lx_p0.clone();
                let seen_p2 = seen_p2.clone();
                entered(once_job(move || {
                    let ok_p5 = p0;
                    let x_p6 = p1;
                    prism_rtl::Turn::Finished(ok_p5 && ty_has_eq(&lx_p0, &x_p6, &seen_p2))
                }))
            }) as Rc<dyn Fn((bool, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<bool>>>
        })),
        crate::check::types::Ty::TyArray(e_p7) => ty_has_eq(lx_p0, &**e_p7, seen_p2),
        crate::check::types::Ty::TyMap(k_p8, v_p9) => ty_has_eq(lx_p0, &**k_p8, seen_p2) && ty_has_eq(lx_p0, &**v_p9, seen_p2),
        crate::check::types::Ty::TyElem(_, _) => true,
        crate::check::types::Ty::TyElemAny(_) => true,
        crate::check::types::Ty::TyCon(n_pa, args_pb) => if crate::check::types::has_text(seen_p2, n_pa) {
            true
        } else {
            {
                let args_ok_pc = run_to_end(fold_job(args_pb.clone(), true, {
                    let lx_p0 = lx_p0.clone();
                    let seen_p2 = seen_p2.clone();
                    let n_pa = n_pa.clone();
                    Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| {
                        let lx_p0 = lx_p0.clone();
                        let seen_p2 = seen_p2.clone();
                        let n_pa = n_pa.clone();
                        entered(once_job(move || {
                            let ok_pd = p0;
                            let x_pe = p1;
                            prism_rtl::Turn::Finished(ok_pd && ty_has_eq(&lx_p0, &x_pe, &push(&seen_p2, &n_pa)))
                        }))
                    }) as Rc<dyn Fn((bool, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<bool>>>
                }));
                args_ok_pc && match get(&lx_p0.g.types, n_pa) {
                    Some(ti_pf) => fold(&ti_pf.derives, &false, &(|f_pg: &bool, d_ph: &Text| *f_pg || (&crate::check::types::bare_name(d_ph) == &Text::lit("Eq")))) || has_own_eq(lx_p0, n_pa),
                    None => true,
                }
            }
        },
        _ => false,
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// HasOwnEq: fn Lx, Text -> Bool
/// ```
pub fn has_own_eq(lx_p0: &crate::lower::Lx, tn_p1: &Text) -> bool {
    fold(&or(&get(&lx_p0.g.impls, &Text::lit("Prelude.Eq")), &Array::new()), &false, &(|f_p2: &bool, im_p3: &crate::check::env::ImplInfo| *f_p2 || (&crate::lower::functions::head_name(&im_p3.head) == tn_p1)))
}

/// ```prism
/// CaseField: unbounded fn Lx, Text, Nat, Ty -> OutTy
/// ```
pub fn case_field(lx_p0: &crate::lower::Lx, ck_p1: &Text, i_p2: &Nat, t_p3: &crate::check::types::Ty) -> crate::lower::model::OutTy {
    let rt_p4 = crate::lower::types::out_ty_of(lx_p0, t_p3);
    if crate::lower::types::rc_field(lx_p0, ck_p1, i_p2) {
        crate::lower::model::OutTy::OutRc(Rc::new(rt_p4.clone()))
    } else {
        rt_p4.clone()
    }
}

/// The step machine of `CaseField`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CaseField: unbounded fn Lx, Text, Nat, Ty -> OutTy
/// ```
pub struct CaseField {
    pub lx_p0: crate::lower::Lx,
    pub ck_p1: Text,
    pub i_p2: Nat,
    pub t_p3: crate::check::types::Ty,
}

impl prism_rtl::Job<crate::lower::model::OutTy> for CaseField {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::OutTy> {
        let lx_p0 = &self.lx_p0;
        let ck_p1 = &self.ck_p1;
        let i_p2 = &self.i_p2;
        let t_p3 = &self.t_p3;
        let ck_p1 = ck_p1.clone();
        let i_p2 = i_p2.clone();
        let lx_p0 = lx_p0.clone();
        let t_p3 = t_p3.clone();
        call_then(crate::lower::types::start_out_ty_of(lx_p0.clone(), t_p3.clone()), move |out_ty_of_26752: crate::lower::model::OutTy| {
            let rt_p4 = out_ty_of_26752;
            if crate::lower::types::rc_field(&lx_p0, &ck_p1, &i_p2) {
                prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutRc(Rc::new(rt_p4.clone())))
            } else {
                prism_rtl::Turn::Finished(rt_p4.clone())
            }
        })
    }
}

/// `Start CaseField, x`: what the function value is when passed to `@Run`.
pub fn start_case_field(lx_p0: crate::lower::Lx, ck_p1: Text, i_p2: Nat, t_p3: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::lower::model::OutTy>> {
    Rc::new(CaseField { lx_p0, ck_p1, i_p2, t_p3 })
}

/// ```prism
/// TypeDoc: fn Lx, TyInfo -> Text
/// ```
pub fn type_doc(lx_p0: &crate::lower::Lx, ti_p1: &crate::check::env::TyInfo) -> Text {
    match index(&lx_p0.g.srcs, &ti_p1.file) {
        Some(src_p2) => crate::syntax::lexer::chars::trim(&crate::check::errors::line_text(&src_p2, &crate::check::errors::cline_of(&src_p2.starts, &ti_p1.span.start))),
        None => ti_p1.name.clone(),
    }
}

/// ```prism
/// TagDefOf: unbounded fn Lx, TagInfo -> TagDef
/// ```
pub fn tag_def_of(lx_p0: &crate::lower::Lx, tg_p1: &crate::check::env::TagInfo) -> crate::lower::model::TagDef {
    let fields_p2 = run_to_end(each_job(level_fields(tg_p1), {
        let lx_p0 = lx_p0.clone();
        Rc::new(move |p0: (Text, crate::check::types::Ty)| {
            let lx_p0 = lx_p0.clone();
            entered(once_job(move || {
                let (fname_p3, ft_p4) = p0;
                call_then(crate::lower::types::start_out_ty_of(lx_p0.clone(), crate::lower::types::peel(&ft_p4)), move |out_ty_of_27262: crate::lower::model::OutTy| prism_rtl::Turn::Finished((fname_p3.clone(), crate::lower::snake(&fname_p3), out_ty_of_27262)))
            }))
        }) as Rc<dyn Fn((Text, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<(Text, Text, crate::lower::model::OutTy)>>>
    }));
    crate::lower::model::TagDef { name: crate::lower::tag_struct(&tg_p1.name), tag_name: tg_p1.name.clone(), fields: fields_p2.clone(), doc: type_doc(lx_p0, &crate::check::env::TyInfo { name: tg_p1.name.clone(), home: tg_p1.home.clone(), params: Array::new(), body: crate::check::env::TyBody::BOpaque, derives: Array::new(), file: tg_p1.file.clone(), span: tg_p1.span.clone() }), pod: run_to_end(fold_job(fields_p2.clone(), true, Rc::new(move |(p0, p1): (bool, (Text, Text, crate::lower::model::OutTy))| entered(once_job(move || {
        let ok_p5 = p0;
        let (_, _, t_p6) = p1;
        prism_rtl::Turn::Finished(ok_p5 && crate::lower::types::podable(&t_p6))
    }))) as Rc<dyn Fn((bool, (Text, Text, crate::lower::model::OutTy))) -> Rc<dyn prism_rtl::Job<bool>>>)), eq: run_to_end(fold_job(fields_p2.clone(), true, Rc::new(move |(p0, p1): (bool, (Text, Text, crate::lower::model::OutTy))| entered(once_job(move || {
        let ok_p7 = p0;
        let (_, _, t_p8) = p1;
        prism_rtl::Turn::Finished(ok_p7 && crate::lower::types::runtime_eq(&t_p8))
    }))) as Rc<dyn Fn((bool, (Text, Text, crate::lower::model::OutTy))) -> Rc<dyn prism_rtl::Job<bool>>>)) }
}

/// The step machine of `TagDefOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TagDefOf: unbounded fn Lx, TagInfo -> TagDef
/// ```
pub struct TagDefOf {
    pub lx_p0: crate::lower::Lx,
    pub tg_p1: crate::check::env::TagInfo,
}

impl prism_rtl::Job<crate::lower::model::TagDef> for TagDefOf {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::TagDef> {
        let lx_p0 = &self.lx_p0;
        let tg_p1 = &self.tg_p1;
        let lx_p0 = lx_p0.clone();
        let tg_p1 = tg_p1.clone();
        call_value(each_job(level_fields(&tg_p1), {
            let lx_p0 = lx_p0.clone();
            Rc::new(move |p0: (Text, crate::check::types::Ty)| {
                let lx_p0 = lx_p0.clone();
                entered(once_job(move || {
                    let (fname_p3, ft_p4) = p0;
                    call_then(crate::lower::types::start_out_ty_of(lx_p0.clone(), crate::lower::types::peel(&ft_p4)), move |out_ty_of_27262: crate::lower::model::OutTy| prism_rtl::Turn::Finished((fname_p3.clone(), crate::lower::snake(&fname_p3), out_ty_of_27262)))
                }))
            }) as Rc<dyn Fn((Text, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<(Text, Text, crate::lower::model::OutTy)>>>
        }), move |each_27197: Array<(Text, Text, crate::lower::model::OutTy)>| {
            let fields_p2 = each_27197;
            call_value(fold_job(fields_p2.clone(), true, Rc::new(move |(p0, p1): (bool, (Text, Text, crate::lower::model::OutTy))| entered(once_job(move || {
                let ok_p5 = p0;
                let (_, _, t_p6) = p1;
                prism_rtl::Turn::Finished(ok_p5 && crate::lower::types::podable(&t_p6))
            }))) as Rc<dyn Fn((bool, (Text, Text, crate::lower::model::OutTy))) -> Rc<dyn prism_rtl::Job<bool>>>), move |fold_27486: bool| call_value(fold_job(fields_p2.clone(), true, Rc::new(move |(p0, p1): (bool, (Text, Text, crate::lower::model::OutTy))| entered(once_job(move || {
                let ok_p7 = p0;
                let (_, _, t_p8) = p1;
                prism_rtl::Turn::Finished(ok_p7 && crate::lower::types::runtime_eq(&t_p8))
            }))) as Rc<dyn Fn((bool, (Text, Text, crate::lower::model::OutTy))) -> Rc<dyn prism_rtl::Job<bool>>>), move |fold_27557: bool| prism_rtl::Turn::Finished(crate::lower::model::TagDef { name: crate::lower::tag_struct(&tg_p1.name), tag_name: tg_p1.name.clone(), fields: fields_p2.clone(), doc: type_doc(&lx_p0, &crate::check::env::TyInfo { name: tg_p1.name.clone(), home: tg_p1.home.clone(), params: Array::new(), body: crate::check::env::TyBody::BOpaque, derives: Array::new(), file: tg_p1.file.clone(), span: tg_p1.span.clone() }), pod: fold_27486, eq: fold_27557 })))
        })
    }
}

/// `Start TagDefOf, x`: what the function value is when passed to `@Run`.
pub fn start_tag_def_of(lx_p0: crate::lower::Lx, tg_p1: crate::check::env::TagInfo) -> Rc<dyn prism_rtl::Job<crate::lower::model::TagDef>> {
    Rc::new(TagDefOf { lx_p0, tg_p1 })
}

/// ```prism
/// LevelFields: fn TagInfo -> [((Text, Ty))]
/// ```
pub fn level_fields(tg_p0: &crate::check::env::TagInfo) -> Array<(Text, crate::check::types::Ty)> {
    filter(&tg_p0.fields, &(|(_, ft_p1): &(Text, crate::check::types::Ty)| &crate::lower::types::layer_of(ft_p1) != &crate::lower::types::Layer::LyEv))
}

/// ```prism
/// KindTags: fn Lx, Text, [Text] -> [TagInfo]
/// ```
pub fn kind_tags(lx_p0: &crate::lower::Lx, kind_p1: &Text, mods_p2: &Array<Text>) -> Array<crate::check::env::TagInfo> {
    filter(&values(&lx_p0.g.tags), &(|tg_p3: &crate::check::env::TagInfo| (&tg_p3.kind == kind_p1) && crate::check::types::has_text(mods_p2, &tg_p3.home)))
}

/// ```prism
/// RowDefOf: unbounded fn Lx, TyInfo -> RowDef
/// ```
pub fn row_def_of(lx_p0: &crate::lower::Lx, ti_p1: &crate::check::env::TyInfo) -> crate::lower::model::RowDef {
    let tags_p2 = kind_tags(lx_p0, &ti_p1.name, &keys(&lx_p0.rs_mods));
    let cases_p3 = each(&tags_p2, &(|tg_p6: &crate::check::env::TagInfo| (crate::lower::tag_struct(&tg_p6.name), crate::lower::path_in(lx_p0, &tg_p6.home, &crate::lower::tag_struct(&tg_p6.name)))));
    let pod_p4 = run_to_end(fold_job(tags_p2.clone(), true, {
        let lx_p0 = lx_p0.clone();
        Rc::new(move |(p0, p1): (bool, crate::check::env::TagInfo)| {
            let lx_p0 = lx_p0.clone();
            entered(once_job(move || {
                let ok_p7 = p0;
                let tg_p8 = p1;
                prism_rtl::Turn::Finished(ok_p7 && tag_def_of(&lx_p0, &tg_p8).pod)
            }))
        }) as Rc<dyn Fn((bool, crate::check::env::TagInfo)) -> Rc<dyn prism_rtl::Job<bool>>>
    }));
    let eq_p5 = run_to_end(fold_job(tags_p2.clone(), true, {
        let lx_p0 = lx_p0.clone();
        Rc::new(move |(p0, p1): (bool, crate::check::env::TagInfo)| {
            let lx_p0 = lx_p0.clone();
            entered(once_job(move || {
                let ok_p9 = p0;
                let tg_pa = p1;
                prism_rtl::Turn::Finished(ok_p9 && tag_def_of(&lx_p0, &tg_pa).eq)
            }))
        }) as Rc<dyn Fn((bool, crate::check::env::TagInfo)) -> Rc<dyn prism_rtl::Job<bool>>>
    }));
    crate::lower::model::RowDef { name: crate::lower::camel(&crate::check::types::bare_name(&ti_p1.name)), prism: ti_p1.name.clone(), cases: cases_p3.clone(), pod: pod_p4, doc: type_doc(lx_p0, ti_p1), eq: eq_p5, level: false, deep: Array::new() }
}

/// The step machine of `RowDefOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RowDefOf: unbounded fn Lx, TyInfo -> RowDef
/// ```
pub struct RowDefOf {
    pub lx_p0: crate::lower::Lx,
    pub ti_p1: crate::check::env::TyInfo,
}

impl prism_rtl::Job<crate::lower::model::RowDef> for RowDefOf {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::RowDef> {
        let lx_p0 = &self.lx_p0;
        let ti_p1 = &self.ti_p1;
        let tags_p2 = kind_tags(lx_p0, &ti_p1.name, &keys(&lx_p0.rs_mods));
        let cases_p3 = each(&tags_p2, &(|tg_p6: &crate::check::env::TagInfo| (crate::lower::tag_struct(&tg_p6.name), crate::lower::path_in(lx_p0, &tg_p6.home, &crate::lower::tag_struct(&tg_p6.name)))));
        let lx_p0 = lx_p0.clone();
        let ti_p1 = ti_p1.clone();
        call_value(fold_job(tags_p2.clone(), true, {
            let lx_p0 = lx_p0.clone();
            Rc::new(move |(p0, p1): (bool, crate::check::env::TagInfo)| {
                let lx_p0 = lx_p0.clone();
                entered(once_job(move || {
                    let ok_p7 = p0;
                    let tg_p8 = p1;
                    prism_rtl::Turn::Finished(ok_p7 && tag_def_of(&lx_p0, &tg_p8).pod)
                }))
            }) as Rc<dyn Fn((bool, crate::check::env::TagInfo)) -> Rc<dyn prism_rtl::Job<bool>>>
        }), move |fold_28273: bool| {
            let pod_p4 = fold_28273;
            call_value(fold_job(tags_p2.clone(), true, {
                let lx_p0 = lx_p0.clone();
                Rc::new(move |(p0, p1): (bool, crate::check::env::TagInfo)| {
                    let lx_p0 = lx_p0.clone();
                    entered(once_job(move || {
                        let ok_p9 = p0;
                        let tg_pa = p1;
                        prism_rtl::Turn::Finished(ok_p9 && tag_def_of(&lx_p0, &tg_pa).eq)
                    }))
                }) as Rc<dyn Fn((bool, crate::check::env::TagInfo)) -> Rc<dyn prism_rtl::Job<bool>>>
            }), move |fold_28342: bool| {
                let eq_p5 = fold_28342;
                prism_rtl::Turn::Finished(crate::lower::model::RowDef { name: crate::lower::camel(&crate::check::types::bare_name(&ti_p1.name)), prism: ti_p1.name.clone(), cases: cases_p3.clone(), pod: pod_p4, doc: type_doc(&lx_p0, &ti_p1), eq: eq_p5, level: false, deep: Array::new() })
            })
        })
    }
}

/// `Start RowDefOf, x`: what the function value is when passed to `@Run`.
pub fn start_row_def_of(lx_p0: crate::lower::Lx, ti_p1: crate::check::env::TyInfo) -> Rc<dyn prism_rtl::Job<crate::lower::model::RowDef>> {
    Rc::new(RowDefOf { lx_p0, ti_p1 })
}

/// ```prism
/// ElemRow: unbounded fn Lx, [Text] -> RowDef
/// ```
pub fn elem_row(lx_p0: &crate::lower::Lx, mods_p1: &Array<Text>) -> crate::lower::model::RowDef {
    let tags_p2 = kind_tags(lx_p0, &Text::lit("Element"), &push(mods_p1, &Text::lit("Prelude")));
    let cases_p3 = each(&tags_p2, &(|tg_p7: &crate::check::env::TagInfo| (crate::lower::tag_struct(&tg_p7.name), Text::from(format!("{}::{}", &crate::lower::rust_mod_name(&tg_p7.home), &crate::lower::tag_struct(&tg_p7.name))))));
    let pod_p4 = run_to_end(fold_job(tags_p2.clone(), true, {
        let lx_p0 = lx_p0.clone();
        Rc::new(move |(p0, p1): (bool, crate::check::env::TagInfo)| {
            let lx_p0 = lx_p0.clone();
            entered(once_job(move || {
                let ok_p8 = p0;
                let tg_p9 = p1;
                prism_rtl::Turn::Finished(ok_p8 && tag_def_of(&lx_p0, &tg_p9).pod)
            }))
        }) as Rc<dyn Fn((bool, crate::check::env::TagInfo)) -> Rc<dyn prism_rtl::Job<bool>>>
    }));
    let eq_p5 = run_to_end(fold_job(tags_p2.clone(), true, {
        let lx_p0 = lx_p0.clone();
        Rc::new(move |(p0, p1): (bool, crate::check::env::TagInfo)| {
            let lx_p0 = lx_p0.clone();
            entered(once_job(move || {
                let ok_pa = p0;
                let tg_pb = p1;
                prism_rtl::Turn::Finished(ok_pa && tag_def_of(&lx_p0, &tg_pb).eq)
            }))
        }) as Rc<dyn Fn((bool, crate::check::env::TagInfo)) -> Rc<dyn prism_rtl::Job<bool>>>
    }));
    let deep_p6 = run_to_end(fold_job(tags_p2.clone(), Array::new(), {
        let lx_p0 = lx_p0.clone();
        Rc::new(move |(p0, p1): (Array<Text>, crate::check::env::TagInfo)| {
            let lx_p0 = lx_p0.clone();
            entered(once_job(move || {
                let acc_pc = p0;
                let tg_pd = p1;
                call_then(start_tag_holds_dyn(lx_p0.clone(), tg_pd.clone()), move |tag_holds_dyn_29144: bool| if tag_holds_dyn_29144 {
                    prism_rtl::Turn::Finished(push(&acc_pc, &crate::lower::tag_struct(&tg_pd.name)))
                } else {
                    prism_rtl::Turn::Finished(acc_pc.clone())
                })
            }))
        }) as Rc<dyn Fn((Array<Text>, crate::check::env::TagInfo)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
    }));
    crate::lower::model::RowDef { name: Text::lit("Elem"), prism: Text::lit("Elem"), cases: cases_p3.clone(), pod: pod_p4, doc: Text::lit("`Elem r`: an element as a document holds it, its `Level` in a tick."), eq: eq_p5, level: true, deep: deep_p6.clone() }
}

/// The step machine of `ElemRow`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ElemRow: unbounded fn Lx, [Text] -> RowDef
/// ```
pub struct ElemRow {
    pub lx_p0: crate::lower::Lx,
    pub mods_p1: Array<Text>,
}

impl prism_rtl::Job<crate::lower::model::RowDef> for ElemRow {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::RowDef> {
        let lx_p0 = &self.lx_p0;
        let mods_p1 = &self.mods_p1;
        let tags_p2 = kind_tags(lx_p0, &Text::lit("Element"), &push(mods_p1, &Text::lit("Prelude")));
        let cases_p3 = each(&tags_p2, &(|tg_p7: &crate::check::env::TagInfo| (crate::lower::tag_struct(&tg_p7.name), Text::from(format!("{}::{}", &crate::lower::rust_mod_name(&tg_p7.home), &crate::lower::tag_struct(&tg_p7.name))))));
        let lx_p0 = lx_p0.clone();
        call_value(fold_job(tags_p2.clone(), true, {
            let lx_p0 = lx_p0.clone();
            Rc::new(move |(p0, p1): (bool, crate::check::env::TagInfo)| {
                let lx_p0 = lx_p0.clone();
                entered(once_job(move || {
                    let ok_p8 = p0;
                    let tg_p9 = p1;
                    prism_rtl::Turn::Finished(ok_p8 && tag_def_of(&lx_p0, &tg_p9).pod)
                }))
            }) as Rc<dyn Fn((bool, crate::check::env::TagInfo)) -> Rc<dyn prism_rtl::Job<bool>>>
        }), move |fold_28974: bool| {
            let pod_p4 = fold_28974;
            call_value(fold_job(tags_p2.clone(), true, {
                let lx_p0 = lx_p0.clone();
                Rc::new(move |(p0, p1): (bool, crate::check::env::TagInfo)| {
                    let lx_p0 = lx_p0.clone();
                    entered(once_job(move || {
                        let ok_pa = p0;
                        let tg_pb = p1;
                        prism_rtl::Turn::Finished(ok_pa && tag_def_of(&lx_p0, &tg_pb).eq)
                    }))
                }) as Rc<dyn Fn((bool, crate::check::env::TagInfo)) -> Rc<dyn prism_rtl::Job<bool>>>
            }), move |fold_29043: bool| {
                let eq_p5 = fold_29043;
                call_value(fold_job(tags_p2.clone(), Array::new(), {
                    let lx_p0 = lx_p0.clone();
                    Rc::new(move |(p0, p1): (Array<Text>, crate::check::env::TagInfo)| {
                        let lx_p0 = lx_p0.clone();
                        entered(once_job(move || {
                            let acc_pc = p0;
                            let tg_pd = p1;
                            call_then(start_tag_holds_dyn(lx_p0.clone(), tg_pd.clone()), move |tag_holds_dyn_29144: bool| if tag_holds_dyn_29144 {
                                prism_rtl::Turn::Finished(push(&acc_pc, &crate::lower::tag_struct(&tg_pd.name)))
                            } else {
                                prism_rtl::Turn::Finished(acc_pc.clone())
                            })
                        }))
                    }) as Rc<dyn Fn((Array<Text>, crate::check::env::TagInfo)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
                }), move |fold_29113: Array<Text>| {
                    let deep_p6 = fold_29113;
                    prism_rtl::Turn::Finished(crate::lower::model::RowDef { name: Text::lit("Elem"), prism: Text::lit("Elem"), cases: cases_p3.clone(), pod: pod_p4, doc: Text::lit("`Elem r`: an element as a document holds it, its `Level` in a tick."), eq: eq_p5, level: true, deep: deep_p6.clone() })
                })
            })
        })
    }
}

/// `Start ElemRow, x`: what the function value is when passed to `@Run`.
pub fn start_elem_row(lx_p0: crate::lower::Lx, mods_p1: Array<Text>) -> Rc<dyn prism_rtl::Job<crate::lower::model::RowDef>> {
    Rc::new(ElemRow { lx_p0, mods_p1 })
}

/// ```prism
/// TagHoldsDyn: unbounded fn Lx, TagInfo -> Bool
/// ```
pub fn tag_holds_dyn(lx_p0: &crate::lower::Lx, tg_p1: &crate::check::env::TagInfo) -> bool {
    run_to_end(fold_job(tag_def_of(lx_p0, tg_p1).fields.clone(), false, Rc::new(move |(p0, p1): (bool, (Text, Text, crate::lower::model::OutTy))| entered(once_job(move || {
        let f_p2 = p0;
        let (_, _, t_p3) = p1;
        prism_rtl::Turn::Finished(f_p2 || crate::lower::types::holds_dyn(&t_p3))
    }))) as Rc<dyn Fn((bool, (Text, Text, crate::lower::model::OutTy))) -> Rc<dyn prism_rtl::Job<bool>>>))
}

/// The step machine of `TagHoldsDyn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TagHoldsDyn: unbounded fn Lx, TagInfo -> Bool
/// ```
pub struct TagHoldsDyn {
    pub lx_p0: crate::lower::Lx,
    pub tg_p1: crate::check::env::TagInfo,
}

impl prism_rtl::Job<bool> for TagHoldsDyn {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let lx_p0 = &self.lx_p0;
        let tg_p1 = &self.tg_p1;
        let lx_p0 = lx_p0.clone();
        let tg_p1 = tg_p1.clone();
        call_then(start_tag_def_of(lx_p0.clone(), tg_p1.clone()), move |tag_def_of_29565: crate::lower::model::TagDef| fold_job(tag_def_of_29565.fields.clone(), false, Rc::new(move |(p0, p1): (bool, (Text, Text, crate::lower::model::OutTy))| entered(once_job(move || {
            let f_p2 = p0;
            let (_, _, t_p3) = p1;
            prism_rtl::Turn::Finished(f_p2 || crate::lower::types::holds_dyn(&t_p3))
        }))) as Rc<dyn Fn((bool, (Text, Text, crate::lower::model::OutTy))) -> Rc<dyn prism_rtl::Job<bool>>>).cycle())
    }
}

/// `Start TagHoldsDyn, x`: what the function value is when passed to `@Run`.
pub fn start_tag_holds_dyn(lx_p0: crate::lower::Lx, tg_p1: crate::check::env::TagInfo) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(TagHoldsDyn { lx_p0, tg_p1 })
}

/// ```prism
/// AnswerEnum: unbounded fn Lx, [Text] -> AnswerDef
/// ```
pub fn answer_enum(lx_p0: &crate::lower::Lx, mods_p1: &Array<Text>) -> crate::lower::model::AnswerDef {
    let tags_p2 = kind_tags(lx_p0, &Text::lit("Element"), &push(mods_p1, &Text::lit("Prelude")));
    crate::lower::model::AnswerDef { cases: run_to_end(each_job(tags_p2.clone(), {
        let lx_p0 = lx_p0.clone();
        Rc::new(move |p0: crate::check::env::TagInfo| {
            let lx_p0 = lx_p0.clone();
            entered(once_job(move || {
                let tg_p3 = p0;
                call_then(start_answer_ty(lx_p0.clone(), tg_p3.clone()), move |answer_ty_30041: crate::lower::model::OutTy| prism_rtl::Turn::Finished(crate::lower::model::AnswerCase { variant: crate::lower::tag_struct(&tg_p3.name), accessor: crate::lower::node_::elements::answer_accessor(&tg_p3), struct_path: Text::from(format!("{}::{}", &crate::lower::rust_mod_name(&tg_p3.home), &crate::lower::tag_struct(&tg_p3.name))), tag_name: tg_p3.name.clone(), ty: answer_ty_30041 }))
            }))
        }) as Rc<dyn Fn(crate::check::env::TagInfo) -> Rc<dyn prism_rtl::Job<crate::lower::model::AnswerCase>>>
    })) }
}

/// The step machine of `AnswerEnum`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// AnswerEnum: unbounded fn Lx, [Text] -> AnswerDef
/// ```
pub struct AnswerEnum {
    pub lx_p0: crate::lower::Lx,
    pub mods_p1: Array<Text>,
}

impl prism_rtl::Job<crate::lower::model::AnswerDef> for AnswerEnum {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::AnswerDef> {
        let lx_p0 = &self.lx_p0;
        let mods_p1 = &self.mods_p1;
        let tags_p2 = kind_tags(lx_p0, &Text::lit("Element"), &push(mods_p1, &Text::lit("Prelude")));
        let lx_p0 = lx_p0.clone();
        call_value(each_job(tags_p2.clone(), {
            let lx_p0 = lx_p0.clone();
            Rc::new(move |p0: crate::check::env::TagInfo| {
                let lx_p0 = lx_p0.clone();
                entered(once_job(move || {
                    let tg_p3 = p0;
                    call_then(start_answer_ty(lx_p0.clone(), tg_p3.clone()), move |answer_ty_30041: crate::lower::model::OutTy| prism_rtl::Turn::Finished(crate::lower::model::AnswerCase { variant: crate::lower::tag_struct(&tg_p3.name), accessor: crate::lower::node_::elements::answer_accessor(&tg_p3), struct_path: Text::from(format!("{}::{}", &crate::lower::rust_mod_name(&tg_p3.home), &crate::lower::tag_struct(&tg_p3.name))), tag_name: tg_p3.name.clone(), ty: answer_ty_30041 }))
                }))
            }) as Rc<dyn Fn(crate::check::env::TagInfo) -> Rc<dyn prism_rtl::Job<crate::lower::model::AnswerCase>>>
        }), move |each_29876: Array<crate::lower::model::AnswerCase>| prism_rtl::Turn::Finished(crate::lower::model::AnswerDef { cases: each_29876 }))
    }
}

/// `Start AnswerEnum, x`: what the function value is when passed to `@Run`.
pub fn start_answer_enum(lx_p0: crate::lower::Lx, mods_p1: Array<Text>) -> Rc<dyn prism_rtl::Job<crate::lower::model::AnswerDef>> {
    Rc::new(AnswerEnum { lx_p0, mods_p1 })
}

/// ```prism
/// AnswerTy: unbounded fn Lx, TagInfo -> OutTy
/// ```
pub fn answer_ty(lx_p0: &crate::lower::Lx, tg_p1: &crate::check::env::TagInfo) -> crate::lower::model::OutTy {
    let out_p2 = crate::lower::types::peel(&tg_p1.out);
    let part_p3 = match &out_p2 {
        crate::check::types::Ty::TyTuple(cs_p4) => fold(cs_p4, &out_p2, &(|found_p5: &crate::check::types::Ty, c_p6: &crate::check::types::Ty| if &crate::lower::types::layer_of(c_p6) == &crate::lower::types::Layer::LyEv {
            crate::lower::types::peel(c_p6)
        } else {
            found_p5.clone()
        })),
        _ => out_p2.clone(),
    };
    match crate::lower::types::out_ty_of(lx_p0, &part_p3) {
        crate::lower::model::OutTy::OutGen(_) => crate::lower::model::OutTy::OutPod,
        t_p7 => t_p7,
    }
}

/// The step machine of `AnswerTy`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// AnswerTy: unbounded fn Lx, TagInfo -> OutTy
/// ```
pub struct AnswerTy {
    pub lx_p0: crate::lower::Lx,
    pub tg_p1: crate::check::env::TagInfo,
}

impl prism_rtl::Job<crate::lower::model::OutTy> for AnswerTy {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::OutTy> {
        let lx_p0 = &self.lx_p0;
        let tg_p1 = &self.tg_p1;
        let out_p2 = crate::lower::types::peel(&tg_p1.out);
        let part_p3 = match &out_p2 {
            crate::check::types::Ty::TyTuple(cs_p4) => fold(cs_p4, &out_p2, &(|found_p5: &crate::check::types::Ty, c_p6: &crate::check::types::Ty| if &crate::lower::types::layer_of(c_p6) == &crate::lower::types::Layer::LyEv {
                crate::lower::types::peel(c_p6)
            } else {
                found_p5.clone()
            })),
            _ => out_p2.clone(),
        };
        let lx_p0 = lx_p0.clone();
        call_then(crate::lower::types::start_out_ty_of(lx_p0.clone(), part_p3.clone()), move |out_ty_of_30568: crate::lower::model::OutTy| match out_ty_of_30568 {
            crate::lower::model::OutTy::OutGen(_) => prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutPod),
            t_p7 => prism_rtl::Turn::Finished(t_p7.clone()),
        })
    }
}

/// `Start AnswerTy, x`: what the function value is when passed to `@Run`.
pub fn start_answer_ty(lx_p0: crate::lower::Lx, tg_p1: crate::check::env::TagInfo) -> Rc<dyn prism_rtl::Job<crate::lower::model::OutTy>> {
    Rc::new(AnswerTy { lx_p0, tg_p1 })
}

/// ```prism
/// TagPaths: fn Lx, TagInfo -> ((Text, Text))
/// ```
pub fn tag_paths(lx_p0: &crate::lower::Lx, tg_p1: &crate::check::env::TagInfo) -> (Text, Text) {
    let st_p2 = crate::lower::tag_struct(&tg_p1.name);
    let struct_path_p3 = crate::lower::path_in(lx_p0, &tg_p1.home, &st_p2);
    (Text::from(format!("{}::{}", &kind_path(lx_p0, &tg_p1.kind), &st_p2)), struct_path_p3.clone())
}

/// ```prism
/// VariantOf: fn Lx, TagInfo -> Text
/// ```
pub fn variant_of(lx_p0: &crate::lower::Lx, tg_p1: &crate::check::env::TagInfo) -> Text {
    Text::from(format!("{}::{}", &kind_path(lx_p0, &tg_p1.kind), &crate::lower::tag_struct(&tg_p1.name)))
}

/// ```prism
/// KindPath: fn Lx, Text -> Text
/// ```
pub fn kind_path(lx_p0: &crate::lower::Lx, kind_p1: &Text) -> Text {
    if kind_p1 == &Text::lit("Element") {
        Text::lit("crate::Elem")
    } else {
        crate::lower::path_in(lx_p0, &or(&get(&lx_p0.g.types, kind_p1), &crate::check::env::names::dummy_ty_info()).home, &crate::lower::camel(&crate::check::types::bare_name(kind_p1)))
    }
}

/// ```prism
/// CheckDefOf: unbounded fn Lx, CheckDecl -> CheckDef
/// ```
pub fn check_def_of(lx_p0: &crate::lower::Lx, c_p1: &crate::syntax::decls::CheckDecl) -> crate::lower::model::CheckDef {
    crate::lower::model::CheckDef { name: c_p1.name.name.clone(), lines: run_to_end(each_job(c_p1.lines.clone(), {
        let lx_p0 = lx_p0.clone();
        Rc::new(move |p0: crate::syntax::decls::CheckLine| {
            let lx_p0 = lx_p0.clone();
            entered(once_job(move || {
                let l_p2 = p0;
                call_then(crate::lower::expr::start_value_of(lx_p0.clone(), crate::lower::types::empty_env(), l_p2.expr.clone()), move |value_of_31416: crate::lower::types::Vl| prism_rtl::Turn::Finished(crate::lower::model::Ex::XCtor(Text::lit("Ok"), Array::from(vec![crate::lower::model::Ex::XMethod(Rc::new(crate::lower::types::own(&value_of_31416)), Text::lit("to_pod"), Array::new())]))))
            }))
        }) as Rc<dyn Fn(crate::syntax::decls::CheckLine) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
    })) }
}

/// The step machine of `CheckDefOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CheckDefOf: unbounded fn Lx, CheckDecl -> CheckDef
/// ```
pub struct CheckDefOf {
    pub lx_p0: crate::lower::Lx,
    pub c_p1: crate::syntax::decls::CheckDecl,
}

impl prism_rtl::Job<crate::lower::model::CheckDef> for CheckDefOf {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::CheckDef> {
        let lx_p0 = &self.lx_p0;
        let c_p1 = &self.c_p1;
        let c_p1 = c_p1.clone();
        let lx_p0 = lx_p0.clone();
        call_value(each_job(c_p1.lines.clone(), {
            let lx_p0 = lx_p0.clone();
            Rc::new(move |p0: crate::syntax::decls::CheckLine| {
                let lx_p0 = lx_p0.clone();
                entered(once_job(move || {
                    let l_p2 = p0;
                    call_then(crate::lower::expr::start_value_of(lx_p0.clone(), crate::lower::types::empty_env(), l_p2.expr.clone()), move |value_of_31416: crate::lower::types::Vl| prism_rtl::Turn::Finished(crate::lower::model::Ex::XCtor(Text::lit("Ok"), Array::from(vec![crate::lower::model::Ex::XMethod(Rc::new(crate::lower::types::own(&value_of_31416)), Text::lit("to_pod"), Array::new())]))))
                }))
            }) as Rc<dyn Fn(crate::syntax::decls::CheckLine) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
        }), move |each_31368: Array<crate::lower::model::Ex>| prism_rtl::Turn::Finished(crate::lower::model::CheckDef { name: c_p1.name.name.clone(), lines: each_31368 }))
    }
}

/// `Start CheckDefOf, x`: what the function value is when passed to `@Run`.
pub fn start_check_def_of(lx_p0: crate::lower::Lx, c_p1: crate::syntax::decls::CheckDecl) -> Rc<dyn prism_rtl::Job<crate::lower::model::CheckDef>> {
    Rc::new(CheckDefOf { lx_p0, c_p1 })
}
