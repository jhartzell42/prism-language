//! The module `Lower.Expr`, from `target/bootstrap/src/prismc/lower/expr.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// ```prism
/// Escape: fn Text -> Text
/// ```
pub fn escape(t_p0: &Text) -> Text {
    crate::syntax::lexer::chars::map_chars(t_p0, &(Rc::new(move |p0: Text| once_job(move || {
        let c_p1 = p0;
        prism_rtl::Turn::Finished(char_escape(&c_p1))
    })) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<Text>>>))
}

/// ```prism
/// CharEscape: fn Text -> Text
/// ```
pub fn char_escape(text0: &Text) -> Text {
    match text0 {
        c0_0 if (c0_0 == &Text::lit("\\")) => Text::lit("\\\\"),
        c1_0 if (c1_0 == &Text::lit("\"")) => Text::lit("\\\""),
        c2_0 if (c2_0 == &Text::lit("\n")) => Text::lit("\\n"),
        c3_0 if (c3_0 == &Text::lit("\t")) => Text::lit("\\t"),
        c4_0 if (c4_0 == &Text::lit("\r")) => Text::lit("\\r"),
        c5_0 if (c5_0 == &Text::lit("\0")) => Text::lit("\\0"),
        c6_0 if (c6_0 == &Text::lit("\'")) => Text::lit("\\\'"),
        c_p0 => c_p0.clone(),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// Number: fn OutTy, Text, Bool -> Ex
/// ```
pub fn number(t_p0: &crate::lower::model::OutTy, digits_p1: &Text, neg_p2: &bool) -> crate::lower::model::Ex {
    let clean_p3 = decimal_digits(&concat(&split_on(digits_p1, &Text::lit("_"))));
    let signed_p4 = if *neg_p2 { Text::from(format!("-{}", &clean_p3)) } else { clean_p3.clone() };
    match t_p0 {
        crate::lower::model::OutTy::OutNat => crate::lower::model::Ex::XNat(clean_p3.clone()),
        crate::lower::model::OutTy::OutInt => crate::lower::model::Ex::XInt(signed_p4.clone()),
        crate::lower::model::OutTy::OutU8 => crate::lower::model::Ex::XByte(clean_p3.clone()),
        crate::lower::model::OutTy::OutFloat => crate::lower::model::Ex::XFloat(if crate::syntax::lexer::chars::contains(&clean_p3, &Text::lit(".")) {
            signed_p4.clone()
        } else {
            Text::from(format!("{}.0", &signed_p4))
        }),
        _ => crate::lower::model::Ex::XInt(signed_p4.clone()),
    }
}

/// ```prism
/// DecimalDigits: fn Text -> Text
/// ```
pub fn decimal_digits(d_p0: &Text) -> Text {
    let r_p1 = if &crate::syntax::lexer::chars::head(d_p0) == &Text::lit("0") {
        crate::syntax::lexer::chars::head(&crate::syntax::lexer::chars::after_first(d_p0))
    } else {
        Text::lit("")
    };
    let base_p2 = if &r_p1 == &Text::lit("x") {
        Nat::from(16u32)
    } else {
        if &r_p1 == &Text::lit("o") {
            Nat::from(8u32)
        } else {
            if &r_p1 == &Text::lit("b") { Nat::from(2u32) } else { Nat::from(10u32) }
        }
    };
    let ds_p3 = if &base_p2 == &Nat::from(10u32) {
        d_p0.clone()
    } else {
        crate::syntax::lexer::chars::after_first(&crate::syntax::lexer::chars::after_first(d_p0))
    };
    if (crate::syntax::lexer::chars::contains(d_p0, &Text::lit(".")) || (&crate::syntax::lexer::chars::head(d_p0) != &Text::lit("0"))) || (d_p0 == &Text::lit("0")) {
        d_p0.clone()
    } else {
        Text::from(format!("{}", &crate::syntax::lexer::chars::fold_chars(&ds_p3, &Nat::from(0u32), &{
            let base_p2 = base_p2.clone();
            Rc::new(move |(p0, p1): (Nat, Text)| {
                let base_p2 = base_p2.clone();
                once_job(move || {
                    let n_p4 = p0;
                    let c_p5 = p1;
                    prism_rtl::Turn::Finished(&(&n_p4 * &base_p2) + &crate::syntax::lexer::chars::hex_value(&c_p5))
                })
            }) as Rc<dyn Fn((Nat, Text)) -> Rc<dyn prism_rtl::Job<Nat>>>
        })))
    }
}

/// ```prism
/// LiteralValue: unbounded fn Lx, Env, Literal, Range, Bool -> Vl
/// ```
pub fn literal_value(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, l_p2: &crate::syntax::Literal, span_p3: &crate::syntax::Range, neg_p4: &bool) -> crate::lower::types::Vl {
    let t_p5 = crate::lower::types::out_ty_of(lx_p0, &crate::lower::types::peel(&crate::lower::type_at(lx_p0, span_p3)));
    match &l_p2.kind {
        crate::syntax::LitKind::LInt(d_p6) => crate::lower::types::Vl::VlOwned(number(&t_p5, d_p6, neg_p4), t_p5.clone()),
        crate::syntax::LitKind::LFloat(d_p7) => crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XFloat(if *neg_p4 { Text::from(format!("-{}", d_p7)) } else { d_p7.clone() }), crate::lower::model::OutTy::OutFloat),
        crate::syntax::LitKind::LChar(c_p8) => crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XChar(c_p8.clone()), crate::lower::model::OutTy::OutChar),
        crate::syntax::LitKind::LDuration(d_p9, u_pa) => crate::lower::types::Vl::VlOwned(refusal(&Text::lit("a Duration literal")), crate::lower::model::OutTy::OutDuration),
        crate::syntax::LitKind::LText(segs_pb) => text_value(lx_p0, env_p1, segs_pb),
        crate::syntax::LitKind::LRegex(r_pc) => match &r_pc.replacement {
            None => crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XRegex(r_pc.pattern.clone(), r_pc.flags.clone()), crate::lower::model::OutTy::OutRegex),
            Some(t_pd) => crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XReplacement(r_pc.pattern.clone(), t_pd.clone(), r_pc.flags.clone()), crate::lower::model::OutTy::OutReplacement),
        },
    }
}

/// The step machine of `LiteralValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LiteralValue: unbounded fn Lx, Env, Literal, Range, Bool -> Vl
/// ```
pub struct LiteralValue {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub l_p2: crate::syntax::Literal,
    pub span_p3: crate::syntax::Range,
    pub neg_p4: bool,
}

impl prism_rtl::Job<crate::lower::types::Vl> for LiteralValue {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::types::Vl> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let l_p2 = &self.l_p2;
        let span_p3 = &self.span_p3;
        let neg_p4 = &self.neg_p4;
        let env_p1 = env_p1.clone();
        let l_p2 = l_p2.clone();
        let lx_p0 = lx_p0.clone();
        let neg_p4 = *neg_p4;
        let span_p3 = span_p3.clone();
        call_then(crate::lower::types::start_out_ty_of(lx_p0.clone(), crate::lower::types::peel(&crate::lower::type_at(&lx_p0, &span_p3))), move |out_ty_of_2743: crate::lower::model::OutTy| {
            let t_p5 = out_ty_of_2743;
            match &l_p2.kind {
                crate::syntax::LitKind::LInt(d_p6) => prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(number(&t_p5, d_p6, &neg_p4), t_p5.clone())),
                crate::syntax::LitKind::LFloat(d_p7) => prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XFloat(if neg_p4 { Text::from(format!("-{}", d_p7)) } else { d_p7.clone() }), crate::lower::model::OutTy::OutFloat)),
                crate::syntax::LitKind::LChar(c_p8) => prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XChar(c_p8.clone()), crate::lower::model::OutTy::OutChar)),
                crate::syntax::LitKind::LDuration(d_p9, u_pa) => prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(refusal(&Text::lit("a Duration literal")), crate::lower::model::OutTy::OutDuration)),
                crate::syntax::LitKind::LText(segs_pb) => prism_rtl::Turn::More(Rc::new(TextValue { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), segs_p2: segs_pb.clone() })),
                crate::syntax::LitKind::LRegex(r_pc) => match &r_pc.replacement {
                    None => prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XRegex(r_pc.pattern.clone(), r_pc.flags.clone()), crate::lower::model::OutTy::OutRegex)),
                    Some(t_pd) => prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XReplacement(r_pc.pattern.clone(), t_pd.clone(), r_pc.flags.clone()), crate::lower::model::OutTy::OutReplacement)),
                },
            }
        })
    }
}

/// `Start LiteralValue, x`: what the function value is when passed to `@Run`.
pub fn start_literal_value(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, l_p2: crate::syntax::Literal, span_p3: crate::syntax::Range, neg_p4: bool) -> Rc<dyn prism_rtl::Job<crate::lower::types::Vl>> {
    Rc::new(LiteralValue { lx_p0, env_p1, l_p2, span_p3, neg_p4 })
}

/// ```prism
/// TextValue: unbounded fn Lx, Env, [TextSeg] -> Vl
/// ```
pub fn text_value(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, segs_p2: &Array<crate::syntax::TextSeg>) -> crate::lower::types::Vl {
    let plain_p3 = fold(segs_p2, &true, &(|ok_p4: &bool, s_p5: &crate::syntax::TextSeg| *ok_p4 && is_plain_seg(s_p5)));
    if plain_p3 {
        crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XText(concat(&each(segs_p2, &(|s_p6: &crate::syntax::TextSeg| plain_text(s_p6))))), crate::lower::model::OutTy::OutText)
    } else {
        crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XFormat(run_to_end(each_job(segs_p2.clone(), {
            let lx_p0 = lx_p0.clone();
            let env_p1 = env_p1.clone();
            Rc::new(move |p0: crate::syntax::TextSeg| {
                let lx_p0 = lx_p0.clone();
                let env_p1 = env_p1.clone();
                entered(once_job(move || {
                    let s_p7 = p0;
                    prism_rtl::Turn::More(Rc::new(SegEx { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), text_seg2: s_p7.clone() }))
                }))
            }) as Rc<dyn Fn(crate::syntax::TextSeg) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
        }))), crate::lower::model::OutTy::OutText)
    }
}

/// The step machine of `TextValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TextValue: unbounded fn Lx, Env, [TextSeg] -> Vl
/// ```
pub struct TextValue {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub segs_p2: Array<crate::syntax::TextSeg>,
}

impl prism_rtl::Job<crate::lower::types::Vl> for TextValue {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::types::Vl> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let segs_p2 = &self.segs_p2;
        let plain_p3 = fold(segs_p2, &true, &(|ok_p4: &bool, s_p5: &crate::syntax::TextSeg| *ok_p4 && is_plain_seg(s_p5)));
        if plain_p3 {
            prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XText(concat(&each(segs_p2, &(|s_p6: &crate::syntax::TextSeg| plain_text(s_p6))))), crate::lower::model::OutTy::OutText))
        } else {
            {
                let env_p1 = env_p1.clone();
                let lx_p0 = lx_p0.clone();
                let segs_p2 = segs_p2.clone();
                call_value(each_job(segs_p2.clone(), {
                    let lx_p0 = lx_p0.clone();
                    let env_p1 = env_p1.clone();
                    Rc::new(move |p0: crate::syntax::TextSeg| {
                        let lx_p0 = lx_p0.clone();
                        let env_p1 = env_p1.clone();
                        entered(once_job(move || {
                            let s_p7 = p0;
                            prism_rtl::Turn::More(Rc::new(SegEx { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), text_seg2: s_p7.clone() }))
                        }))
                    }) as Rc<dyn Fn(crate::syntax::TextSeg) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
                }), move |each_3675: Array<crate::lower::model::Ex>| prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XFormat(each_3675), crate::lower::model::OutTy::OutText)))
            }
        }
    }
}

/// `Start TextValue, x`: what the function value is when passed to `@Run`.
pub fn start_text_value(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, segs_p2: Array<crate::syntax::TextSeg>) -> Rc<dyn prism_rtl::Job<crate::lower::types::Vl>> {
    Rc::new(TextValue { lx_p0, env_p1, segs_p2 })
}

/// ```prism
/// IsPlainSeg: fn TextSeg -> Bool
/// ```
pub fn is_plain_seg(text_seg0: &crate::syntax::TextSeg) -> bool {
    match text_seg0 {
        crate::syntax::TextSeg::SegPlain(_) => true,
        crate::syntax::TextSeg::SegPlaceholder(_) => false,
    }
}

/// ```prism
/// PlainText: fn TextSeg -> Text
/// ```
pub fn plain_text(text_seg0: &crate::syntax::TextSeg) -> Text {
    match text_seg0 {
        crate::syntax::TextSeg::SegPlain(t_p0) => t_p0.clone(),
        crate::syntax::TextSeg::SegPlaceholder(_) => Text::lit(""),
    }
}

/// ```prism
/// SegEx: unbounded fn Lx, Env, TextSeg -> Ex
/// ```
pub fn seg_ex(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, text_seg2: &crate::syntax::TextSeg) -> crate::lower::model::Ex {
    match text_seg2 {
        crate::syntax::TextSeg::SegPlain(t_p2) => crate::lower::model::Ex::XText(t_p2.clone()),
        crate::syntax::TextSeg::SegPlaceholder(e_p5) => {
            let v_p6 = value_of(lx_p0, env_p1, e_p5);
            shown_part(&v_p6)
        },
    }
}

/// The step machine of `SegEx`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SegEx: unbounded fn Lx, Env, TextSeg -> Ex
/// ```
pub struct SegEx {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub text_seg2: crate::syntax::TextSeg,
}

impl prism_rtl::Job<crate::lower::model::Ex> for SegEx {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::Ex> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let text_seg2 = &self.text_seg2;
        match text_seg2 {
            crate::syntax::TextSeg::SegPlain(t_p2) => prism_rtl::Turn::Finished(crate::lower::model::Ex::XText(t_p2.clone())),
            crate::syntax::TextSeg::SegPlaceholder(e_p5) => {
                let e_p5 = e_p5.clone();
                let env_p1 = env_p1.clone();
                let lx_p0 = lx_p0.clone();
                call_then(start_value_of(lx_p0.clone(), env_p1.clone(), e_p5.clone()), move |value_of_4074: crate::lower::types::Vl| {
                    let v_p6 = value_of_4074;
                    prism_rtl::Turn::Finished(shown_part(&v_p6))
                })
            },
        }
    }
}

/// `Start SegEx, x`: what the function value is when passed to `@Run`.
pub fn start_seg_ex(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, text_seg2: crate::syntax::TextSeg) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>> {
    Rc::new(SegEx { lx_p0, env_p1, text_seg2 })
}

/// ```prism
/// ShownPart: fn Vl -> Ex
/// ```
pub fn shown_part(v_p0: &crate::lower::types::Vl) -> crate::lower::model::Ex {
    match crate::lower::types::value_ty(v_p0) {
        crate::lower::model::OutTy::OutText => crate::lower::types::ref_(v_p0),
        crate::lower::model::OutTy::OutChar => crate::lower::types::ref_(v_p0),
        crate::lower::model::OutTy::OutNat => crate::lower::types::ref_(v_p0),
        crate::lower::model::OutTy::OutInt => crate::lower::types::ref_(v_p0),
        crate::lower::model::OutTy::OutU8 => crate::lower::types::ref_(v_p0),
        _ => crate::lower::model::Ex::XCall(Text::lit("show"), Array::from(vec![crate::lower::types::ref_(v_p0)])),
    }
}

/// ```prism
/// Refusal: fn Text -> Ex
/// ```
pub fn refusal(what_p0: &Text) -> crate::lower::model::Ex {
    crate::lower::model::Ex::XRefusal(what_p0.clone())
}

/// ```prism
/// TryOf: fn Ex -> Ex
/// ```
pub fn try_of(x_p0: &crate::lower::model::Ex) -> crate::lower::model::Ex {
    if is_named_place(x_p0) {
        refusal(&Text::from(format!("`?` of the place `{}`, which C++\'s TRY would move out of (only a temporary may be tried)", &crate::lower::types::place_stem(x_p0))))
    } else {
        crate::lower::model::Ex::XTry(Rc::new(x_p0.clone()))
    }
}

/// ```prism
/// IsNamedPlace: fn Ex -> Bool
/// ```
pub fn is_named_place(x_p0: &crate::lower::model::Ex) -> bool {
    match x_p0 {
        crate::lower::model::Ex::XVar(_) => true,
        crate::lower::model::Ex::XField(_, _) => true,
        crate::lower::model::Ex::XPart(_, _) => true,
        crate::lower::model::Ex::XTarget(_) => true,
        crate::lower::model::Ex::XRef(y_p1) => is_named_place(&**y_p1),
        crate::lower::model::Ex::XDeref(y_p2) => is_named_place(&**y_p2),
        _ => false,
    }
}

/// ```prism
/// let loweringRefusal
/// ```
pub fn lowering_refusal() -> Text {
    Text::lit("prismc does not lower ")
}

/// ```prism
/// RefusalDo: fn Text -> Do
/// ```
pub fn refusal_do(what_p0: &Text) -> crate::lower::model::Do {
    crate::lower::model::Do::DoExpr(refusal(what_p0))
}

/// ```prism
/// ValueOf: unbounded fn Lx, Env, Expr -> Vl
/// ```
pub fn value_of(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, e_p2: &crate::syntax::Expr) -> crate::lower::types::Vl {
    match get(&env_p1.spans, &crate::lower::place_key(lx_p0, &e_p2.span)) {
        Some(v_p3) => v_p3,
        None => unbound_value_of(lx_p0, env_p1, e_p2),
    }
}

/// The step machine of `ValueOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ValueOf: unbounded fn Lx, Env, Expr -> Vl
/// ```
pub struct ValueOf {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub e_p2: crate::syntax::Expr,
}

impl prism_rtl::Job<crate::lower::types::Vl> for ValueOf {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::types::Vl> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let e_p2 = &self.e_p2;
        match get(&env_p1.spans, &crate::lower::place_key(lx_p0, &e_p2.span)) {
            Some(v_p3) => prism_rtl::Turn::Finished(v_p3.clone()),
            None => prism_rtl::Turn::More(Rc::new(UnboundValueOf { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), e_p2: e_p2.clone() })),
        }
    }
}

/// `Start ValueOf, x`: what the function value is when passed to `@Run`.
pub fn start_value_of(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, e_p2: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<crate::lower::types::Vl>> {
    Rc::new(ValueOf { lx_p0, env_p1, e_p2 })
}

/// ```prism
/// UnboundValueOf: unbounded fn Lx, Env, Expr -> Vl
/// ```
pub fn unbound_value_of(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, e_p2: &crate::syntax::Expr) -> crate::lower::types::Vl {
    if is_event_value(lx_p0, env_p1, e_p2) {
        event_value_of(lx_p0, env_p1, e_p2)
    } else {
        value_by_kind(lx_p0, env_p1, e_p2)
    }
}

/// The step machine of `UnboundValueOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UnboundValueOf: unbounded fn Lx, Env, Expr -> Vl
/// ```
pub struct UnboundValueOf {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub e_p2: crate::syntax::Expr,
}

impl prism_rtl::Job<crate::lower::types::Vl> for UnboundValueOf {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::types::Vl> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let e_p2 = &self.e_p2;
        let e_p2 = e_p2.clone();
        let env_p1 = env_p1.clone();
        let lx_p0 = lx_p0.clone();
        call_then(start_is_event_value(lx_p0.clone(), env_p1.clone(), e_p2.clone()), move |is_event_value_6176: bool| if is_event_value_6176 {
            prism_rtl::Turn::More(Rc::new(EventValueOf { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), e_p2: e_p2.clone() }))
        } else {
            prism_rtl::Turn::More(Rc::new(ValueByKind { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), e_p2: e_p2.clone() }))
        })
    }
}

/// `Start UnboundValueOf, x`: what the function value is when passed to `@Run`.
pub fn start_unbound_value_of(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, e_p2: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<crate::lower::types::Vl>> {
    Rc::new(UnboundValueOf { lx_p0, env_p1, e_p2 })
}

/// ```prism
/// IsEventValue: unbounded fn Lx, Env, Expr -> Bool
/// ```
pub fn is_event_value(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, e_p2: &crate::syntax::Expr) -> bool {
    match &*e_p2.kind {
        crate::syntax::ExprKind::EName(_) => false,
        crate::syntax::ExprKind::EGroup(_) => false,
        _ => ((&crate::lower::types::layer_of(&crate::lower::type_at(lx_p0, &e_p2.span)) == &crate::lower::types::Layer::LyEv) && !fold(&crate::lower::node_::dynamics::operands(e_p2), &false, &(|bound_p3: &bool, c_p4: &crate::syntax::Expr| *bound_p3 || crate::check::env::has_key(&env_p1.spans, &crate::lower::place_key(lx_p0, &c_p4.span))))) && has_event_source(lx_p0, env_p1, e_p2),
    }
}

/// The step machine of `IsEventValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// IsEventValue: unbounded fn Lx, Env, Expr -> Bool
/// ```
pub struct IsEventValue {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub e_p2: crate::syntax::Expr,
}

impl prism_rtl::Job<bool> for IsEventValue {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let e_p2 = &self.e_p2;
        match &*e_p2.kind {
            crate::syntax::ExprKind::EName(_) => prism_rtl::Turn::Finished(false),
            crate::syntax::ExprKind::EGroup(_) => prism_rtl::Turn::Finished(false),
            _ => prism_rtl::Turn::Finished(((&crate::lower::types::layer_of(&crate::lower::type_at(lx_p0, &e_p2.span)) == &crate::lower::types::Layer::LyEv) && !fold(&crate::lower::node_::dynamics::operands(e_p2), &false, &(|bound_p3: &bool, c_p4: &crate::syntax::Expr| *bound_p3 || crate::check::env::has_key(&env_p1.spans, &crate::lower::place_key(lx_p0, &c_p4.span))))) && has_event_source(lx_p0, env_p1, e_p2)),
        }
    }
}

/// `Start IsEventValue, x`: what the function value is when passed to `@Run`.
pub fn start_is_event_value(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, e_p2: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(IsEventValue { lx_p0, env_p1, e_p2 })
}

/// ```prism
/// HasEventSource: unbounded fn Lx, Env, Expr -> Bool
/// ```
pub fn has_event_source(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, e_p2: &crate::syntax::Expr) -> bool {
    run_to_end(fold_job(crate::lower::node_::dynamics::operands(e_p2), false, {
        let lx_p0 = lx_p0.clone();
        let env_p1 = env_p1.clone();
        Rc::new(move |(p0, p1): (bool, crate::syntax::Expr)| {
            let lx_p0 = lx_p0.clone();
            let env_p1 = env_p1.clone();
            entered(once_job(move || {
                let found_p3 = p0;
                let c_p4 = p1;
                prism_rtl::Turn::Finished(found_p3 || is_event_source(&lx_p0, &env_p1, &c_p4))
            }))
        }) as Rc<dyn Fn((bool, crate::syntax::Expr)) -> Rc<dyn prism_rtl::Job<bool>>>
    }))
}

/// The step machine of `HasEventSource`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// HasEventSource: unbounded fn Lx, Env, Expr -> Bool
/// ```
pub struct HasEventSource {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub e_p2: crate::syntax::Expr,
}

impl prism_rtl::Job<bool> for HasEventSource {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let e_p2 = &self.e_p2;
        fold_job(crate::lower::node_::dynamics::operands(e_p2), false, {
            let lx_p0 = lx_p0.clone();
            let env_p1 = env_p1.clone();
            Rc::new(move |(p0, p1): (bool, crate::syntax::Expr)| {
                let lx_p0 = lx_p0.clone();
                let env_p1 = env_p1.clone();
                entered(once_job(move || {
                    let found_p3 = p0;
                    let c_p4 = p1;
                    prism_rtl::Turn::Finished(found_p3 || is_event_source(&lx_p0, &env_p1, &c_p4))
                }))
            }) as Rc<dyn Fn((bool, crate::syntax::Expr)) -> Rc<dyn prism_rtl::Job<bool>>>
        }).cycle()
    }
}

/// `Start HasEventSource, x`: what the function value is when passed to `@Run`.
pub fn start_has_event_source(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, e_p2: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(HasEventSource { lx_p0, env_p1, e_p2 })
}

/// ```prism
/// IsEventSource: unbounded fn Lx, Env, Expr -> Bool
/// ```
pub fn is_event_source(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, c_p2: &crate::syntax::Expr) -> bool {
    if &crate::lower::types::layer_of(&crate::lower::type_at(lx_p0, &c_p2.span)) != &crate::lower::types::Layer::LyEv {
        false
    } else {
        match &*c_p2.kind {
            crate::syntax::ExprKind::EName(n_p3) => match get(&env_p1.names, &crate::check::env::sname_key(n_p3)) {
                Some(crate::lower::types::Bn::BnLocal(_, _, crate::lower::model::OutTy::OutEvent(_))) => true,
                Some(crate::lower::types::Bn::BnEv(_, _)) => crate::check::env::has_key(&env_p1.names, &Text::from(format!("{}#port", &crate::check::env::sname_key(n_p3)))),
                _ => false,
            },
            crate::syntax::ExprKind::EGroup(x_p4) => is_event_source(lx_p0, env_p1, &**x_p4),
            _ => has_event_source(lx_p0, env_p1, c_p2),
        }
    }
}

/// The step machine of `IsEventSource`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// IsEventSource: unbounded fn Lx, Env, Expr -> Bool
/// ```
pub struct IsEventSource {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub c_p2: crate::syntax::Expr,
}

impl prism_rtl::Job<bool> for IsEventSource {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let c_p2 = &self.c_p2;
        if &crate::lower::types::layer_of(&crate::lower::type_at(lx_p0, &c_p2.span)) != &crate::lower::types::Layer::LyEv {
            prism_rtl::Turn::Finished(false)
        } else {
            match &*c_p2.kind {
                crate::syntax::ExprKind::EName(n_p3) => match get(&env_p1.names, &crate::check::env::sname_key(n_p3)) {
                    Some(crate::lower::types::Bn::BnLocal(_, _, crate::lower::model::OutTy::OutEvent(_))) => prism_rtl::Turn::Finished(true),
                    Some(crate::lower::types::Bn::BnEv(_, _)) => prism_rtl::Turn::Finished(crate::check::env::has_key(&env_p1.names, &Text::from(format!("{}#port", &crate::check::env::sname_key(n_p3))))),
                    _ => prism_rtl::Turn::Finished(false),
                },
                crate::syntax::ExprKind::EGroup(x_p4) => prism_rtl::Turn::More(Rc::new(IsEventSource { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), c_p2: (**x_p4).clone() })),
                _ => prism_rtl::Turn::More(Rc::new(HasEventSource { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), e_p2: c_p2.clone() })),
            }
        }
    }
}

/// `Start IsEventSource, x`: what the function value is when passed to `@Run`.
pub fn start_is_event_source(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, c_p2: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(IsEventSource { lx_p0, env_p1, c_p2 })
}

/// ```prism
/// EventValueOf: unbounded fn Lx, Env, Expr -> Vl
/// ```
pub fn event_value_of(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, e_p2: &crate::syntax::Expr) -> crate::lower::types::Vl {
    let t_p3 = crate::lower::types::out_ty_of(lx_p0, &crate::lower::types::peel(&crate::lower::type_at(lx_p0, &e_p2.span)));
    let et_p4 = crate::lower::model::OutTy::OutEvent(Rc::new(t_p3.clone()));
    let filtered_o5 = match &*e_p2.kind {
        crate::syntax::ExprKind::ECall(c_p6, args_p7, _, _) => if &crate::lower::node_::dynamics::callee_key(lx_p0, &**c_p6) == &Text::lit("Prelude.!Filter") {
            index(args_p7, &Nat::from(0u32))
        } else {
            None
        },
        _ => None,
    };
    match &filtered_o5 {
        Some(a_p8) => crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::types::own(&value_of(lx_p0, env_p1, &a_p8.value))), Text::lit("filter_some"), Array::new()), et_p4.clone()),
        None => {
            let evs_p9 = filter(&crate::lower::node_::dynamics::operands(e_p2), &(|x_pa: &crate::syntax::Expr| &crate::lower::types::layer_of(&crate::lower::type_at(lx_p0, &x_pa.span)) == &crate::lower::types::Layer::LyEv));
            'm8243: {
                if let m8243_0 = &evs_p9 && (m8243_0.len() == 1) && let Some(one_pb) = index(m8243_0, &Nat::from(0u32)) {
                    break 'm8243 {
                        let src_pc = crate::lower::types::own(&value_of(lx_p0, env_p1, &one_pb));
                        let it_pd = crate::lower::types::out_ty_of(lx_p0, &crate::lower::types::peel(&crate::lower::type_at(lx_p0, &one_pb.span)));
                        let caps_pe = filter(&crate::lower::types::with_instances(env_p1, &read_names(&crate::check::typed::print::exprs_in(e_p2))), &(|n_pi: &Text| match get(&env_p1.names, n_pi) {
                            Some(crate::lower::types::Bn::BnLocal(_, _, _)) => true,
                            _ => false,
                        }));
                        let (dos_pq, env1_pr) = fold(&caps_pe, &(Array::new(), env_p1.clone()), &(|(acc_pj, en_pk): &(Array<crate::lower::model::Do>, crate::lower::types::Env), n_pl: &Text| match get(&env_p1.names, n_pl) {
                            Some(crate::lower::types::Bn::BnLocal(rs_pm, mode_pn, ct_po)) => {
                                let local_pp = Text::from(format!("{}_c", &crate::lower::types::place_stem(&rs_pm)));
                                (push(acc_pj, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(local_pp.clone()), crate::lower::types::own(&crate::lower::types::local_place(&rs_pm, &mode_pn, &ct_po)))), crate::lower::types::bind(en_pk, n_pl, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(local_pp.clone()), crate::lower::types::Holding::Owned, ct_po.clone())))
                            },
                            _ => (acc_pj.clone(), en_pk.clone()),
                        }));
                        let env2_pf = crate::lower::types::bind_span(&env1_pr, &crate::lower::place_key(lx_p0, &one_pb.span), &crate::lower::types::Vl::VlPlace(crate::lower::model::Ex::XVar(Text::lit("y_ev")), crate::lower::types::Holding::ByRef, it_pd.clone()));
                        let body_pg = crate::lower::types::own(&value_by_kind(lx_p0, &env2_pf, e_p2));
                        let mapped_ph = crate::lower::model::Ex::XMethod(Rc::new(src_pc.clone()), Text::lit("map"), Array::from(vec![crate::lower::model::Ex::XClosure(true, Array::from(vec![crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaBind(Text::lit("y_ev"))), crate::lower::model::OutTy::OutRef(Rc::new(it_pd.clone())))]), Rc::new(body_pg.clone()))]));
                        crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XBlock(push(&dos_pq, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(Text::lit("src_ev")), src_pc.clone())), Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("src_ev"))), Text::lit("map"), Array::from(vec![crate::lower::model::Ex::XClosure(true, Array::from(vec![crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaBind(Text::lit("y_ev"))), crate::lower::model::OutTy::OutRef(Rc::new(it_pd.clone())))]), Rc::new(body_pg.clone()))])))), et_p4.clone())
                    };
                }
                crate::lower::types::Vl::VlOwned(refusal(&Text::lit("an event value of several events")), et_p4.clone())
            }
        },
    }
}

/// The step machine of `EventValueOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// EventValueOf: unbounded fn Lx, Env, Expr -> Vl
/// ```
pub struct EventValueOf {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub e_p2: crate::syntax::Expr,
}

impl prism_rtl::Job<crate::lower::types::Vl> for EventValueOf {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::types::Vl> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let e_p2 = &self.e_p2;
        let e_p2 = e_p2.clone();
        let env_p1 = env_p1.clone();
        let lx_p0 = lx_p0.clone();
        call_then(crate::lower::types::start_out_ty_of(lx_p0.clone(), crate::lower::types::peel(&crate::lower::type_at(&lx_p0, &e_p2.span))), move |out_ty_of_7802: crate::lower::model::OutTy| {
            let t_p3 = out_ty_of_7802;
            let et_p4 = crate::lower::model::OutTy::OutEvent(Rc::new(t_p3.clone()));
            let filtered_o5 = match &*e_p2.kind {
                crate::syntax::ExprKind::ECall(c_p6, args_p7, _, _) => if &crate::lower::node_::dynamics::callee_key(&lx_p0, &**c_p6) == &Text::lit("Prelude.!Filter") {
                    index(args_p7, &Nat::from(0u32))
                } else {
                    None
                },
                _ => None,
            };
            match &filtered_o5 {
                Some(a_p8) => {
                    let a_p8 = a_p8.clone();
                    call_then(start_value_of(lx_p0.clone(), env_p1.clone(), a_p8.value.clone()), move |value_of_8079: crate::lower::types::Vl| prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::types::own(&value_of_8079)), Text::lit("filter_some"), Array::new()), et_p4.clone())))
                },
                None => {
                    let evs_p9 = filter(&crate::lower::node_::dynamics::operands(&e_p2), &(|x_pa: &crate::syntax::Expr| &crate::lower::types::layer_of(&crate::lower::type_at(&lx_p0, &x_pa.span)) == &crate::lower::types::Layer::LyEv));
                    'm8243: {
                        if let m8243_0 = &evs_p9 && (m8243_0.len() == 1) && let Some(one_pb) = index(m8243_0, &Nat::from(0u32)) {
                            break 'm8243 call_then(start_value_of(lx_p0.clone(), env_p1.clone(), one_pb.clone()), move |value_of_8314: crate::lower::types::Vl| {
                                let src_pc = crate::lower::types::own(&value_of_8314);
                                call_then(crate::lower::types::start_out_ty_of(lx_p0.clone(), crate::lower::types::peel(&crate::lower::type_at(&lx_p0, &one_pb.span))), move |out_ty_of_8365: crate::lower::model::OutTy| {
                                    let it_pd = out_ty_of_8365;
                                    call_then(crate::check::typed::print::start_exprs_in(e_p2.clone()), move |exprs_in_8476: Array<crate::syntax::Expr>| call_then(start_read_names(exprs_in_8476), move |read_names_8465: Array<Text>| {
                                        let caps_pe = filter(&crate::lower::types::with_instances(&env_p1, &read_names_8465), &(|n_pi: &Text| match get(&env_p1.names, n_pi) {
                                            Some(crate::lower::types::Bn::BnLocal(_, _, _)) => true,
                                            _ => false,
                                        }));
                                        let (dos_pq, env1_pr) = fold(&caps_pe, &(Array::new(), env_p1.clone()), &(|(acc_pj, en_pk): &(Array<crate::lower::model::Do>, crate::lower::types::Env), n_pl: &Text| match get(&env_p1.names, n_pl) {
                                            Some(crate::lower::types::Bn::BnLocal(rs_pm, mode_pn, ct_po)) => {
                                                let local_pp = Text::from(format!("{}_c", &crate::lower::types::place_stem(&rs_pm)));
                                                (push(acc_pj, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(local_pp.clone()), crate::lower::types::own(&crate::lower::types::local_place(&rs_pm, &mode_pn, &ct_po)))), crate::lower::types::bind(en_pk, n_pl, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(local_pp.clone()), crate::lower::types::Holding::Owned, ct_po.clone())))
                                            },
                                            _ => (acc_pj.clone(), en_pk.clone()),
                                        }));
                                        let env2_pf = crate::lower::types::bind_span(&env1_pr, &crate::lower::place_key(&lx_p0, &one_pb.span), &crate::lower::types::Vl::VlPlace(crate::lower::model::Ex::XVar(Text::lit("y_ev")), crate::lower::types::Holding::ByRef, it_pd.clone()));
                                        call_then(start_value_by_kind(lx_p0.clone(), env2_pf.clone(), e_p2.clone()), move |value_by_kind_9172: crate::lower::types::Vl| {
                                            let body_pg = crate::lower::types::own(&value_by_kind_9172);
                                            let mapped_ph = crate::lower::model::Ex::XMethod(Rc::new(src_pc.clone()), Text::lit("map"), Array::from(vec![crate::lower::model::Ex::XClosure(true, Array::from(vec![crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaBind(Text::lit("y_ev"))), crate::lower::model::OutTy::OutRef(Rc::new(it_pd.clone())))]), Rc::new(body_pg.clone()))]));
                                            prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XBlock(push(&dos_pq, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(Text::lit("src_ev")), src_pc.clone())), Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("src_ev"))), Text::lit("map"), Array::from(vec![crate::lower::model::Ex::XClosure(true, Array::from(vec![crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaBind(Text::lit("y_ev"))), crate::lower::model::OutTy::OutRef(Rc::new(it_pd.clone())))]), Rc::new(body_pg.clone()))])))), et_p4.clone()))
                                        })
                                    }))
                                })
                            });
                        }
                        prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(refusal(&Text::lit("an event value of several events")), et_p4.clone()))
                    }
                },
            }
        })
    }
}

/// `Start EventValueOf, x`: what the function value is when passed to `@Run`.
pub fn start_event_value_of(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, e_p2: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<crate::lower::types::Vl>> {
    Rc::new(EventValueOf { lx_p0, env_p1, e_p2 })
}

/// ```prism
/// ValueByKind: unbounded fn Lx, Env, Expr -> Vl
/// ```
pub fn value_by_kind(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, e_p2: &crate::syntax::Expr) -> crate::lower::types::Vl {
    match get(&lx_p0.lifts, &crate::lower::place_key(lx_p0, &e_p2.span)) {
        Some(ln_p3) if (&len(&ln_p3.operands) > &Nat::from(0u32)) => lifted_value(lx_p0, env_p1, e_p2, &ln_p3),
        _ => plain_value_by_kind(lx_p0, env_p1, e_p2),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `ValueByKind`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ValueByKind: unbounded fn Lx, Env, Expr -> Vl
/// ```
pub struct ValueByKind {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub e_p2: crate::syntax::Expr,
}

impl prism_rtl::Job<crate::lower::types::Vl> for ValueByKind {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::types::Vl> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let e_p2 = &self.e_p2;
        match get(&lx_p0.lifts, &crate::lower::place_key(lx_p0, &e_p2.span)) {
            Some(ln_p3) if (&len(&ln_p3.operands) > &Nat::from(0u32)) => prism_rtl::Turn::More(Rc::new(LiftedValue { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), e_p2: e_p2.clone(), ln_p3: ln_p3.clone() })),
            _ => prism_rtl::Turn::More(Rc::new(PlainValueByKind { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), e_p2: e_p2.clone() })),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start ValueByKind, x`: what the function value is when passed to `@Run`.
pub fn start_value_by_kind(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, e_p2: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<crate::lower::types::Vl>> {
    Rc::new(ValueByKind { lx_p0, env_p1, e_p2 })
}

/// ```prism
/// LiftedValue: unbounded fn Lx, Env, Expr, LiftNote -> Vl
/// ```
pub fn lifted_value(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, e_p2: &crate::syntax::Expr, ln_p3: &crate::check::typed::LiftNote) -> crate::lower::types::Vl {
    let at_p4 = crate::lower::place_key(lx_p0, &e_p2.span);
    let t_p5 = crate::lower::types::out_ty_of(lx_p0, &crate::lower::types::peel(&crate::lower::type_at(lx_p0, &e_p2.span)));
    let inner_p6 = crate::lower::patterns::inner_ty(&crate::lower::type_at(lx_p0, &e_p2.span));
    let self_operand_p7 = fold(&ln_p3.operands, &false, &(|f_p9: &bool, r_pa: &crate::syntax::Range| *f_p9 || (r_pa == &e_p2.span)));
    let missing_p8 = fold(&ln_p3.operands, &false, &(|f_pb: &bool, r_pc: &crate::syntax::Range| *f_pb || (&operand_at(e_p2, r_pc) == &None)));
    if ((&inner_p6 == &crate::check::types::Ty::TyErr) || self_operand_p7) || missing_p8 {
        crate::lower::types::Vl::VlOwned(refusal(&Text::from(format!("a lift over `{}` at `{}` of {}", &ln_p3.sigil, &crate::lower::functions::src_text(lx_p0, &lx_p0.file, &e_p2.span), &kind_words(&*e_p2.kind)))), t_p5.clone())
    } else {
        {
            let lx1_pd = {
                let mut this: crate::lower::Lx = lx_p0.clone();
                this.tys = insert(&this.tys, &at_p4, &inner_p6);
                this.lifts = insert(&this.lifts, &at_p4, &crate::check::typed::LiftNote { at: ln_p3.at.clone(), sigil: ln_p3.sigil.clone(), operands: Array::new() });
                this
            };
            let lx2_pe = fold(&ln_p3.operands, &lx1_pd, &(|l_pf: &crate::lower::Lx, r_pg: &crate::syntax::Range| {
                let mut this: crate::lower::Lx = l_pf.clone();
                this.tys = insert(&this.tys, &crate::lower::place_key(lx_p0, r_pg), &crate::lower::patterns::inner_ty(&crate::lower::type_at(lx_p0, r_pg)));
                this
            }));
            crate::lower::types::Vl::VlOwned(lift_operands(lx_p0, &lx2_pe, env_p1, e_p2, &ln_p3.sigil, &ln_p3.operands, &t_p5), t_p5.clone())
        }
    }
}

/// The step machine of `LiftedValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LiftedValue: unbounded fn Lx, Env, Expr, LiftNote -> Vl
/// ```
pub struct LiftedValue {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub e_p2: crate::syntax::Expr,
    pub ln_p3: crate::check::typed::LiftNote,
}

impl prism_rtl::Job<crate::lower::types::Vl> for LiftedValue {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::types::Vl> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let e_p2 = &self.e_p2;
        let ln_p3 = &self.ln_p3;
        let at_p4 = crate::lower::place_key(lx_p0, &e_p2.span);
        let e_p2 = e_p2.clone();
        let env_p1 = env_p1.clone();
        let ln_p3 = ln_p3.clone();
        let lx_p0 = lx_p0.clone();
        call_then(crate::lower::types::start_out_ty_of(lx_p0.clone(), crate::lower::types::peel(&crate::lower::type_at(&lx_p0, &e_p2.span))), move |out_ty_of_10518: crate::lower::model::OutTy| {
            let t_p5 = out_ty_of_10518;
            let inner_p6 = crate::lower::patterns::inner_ty(&crate::lower::type_at(&lx_p0, &e_p2.span));
            let self_operand_p7 = fold(&ln_p3.operands, &false, &(|f_p9: &bool, r_pa: &crate::syntax::Range| *f_p9 || (r_pa == &e_p2.span)));
            let missing_p8 = fold(&ln_p3.operands, &false, &(|f_pb: &bool, r_pc: &crate::syntax::Range| *f_pb || (&operand_at(&e_p2, r_pc) == &None)));
            if ((&inner_p6 == &crate::check::types::Ty::TyErr) || self_operand_p7) || missing_p8 {
                prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(refusal(&Text::from(format!("a lift over `{}` at `{}` of {}", &ln_p3.sigil, &crate::lower::functions::src_text(&lx_p0, &lx_p0.file, &e_p2.span), &kind_words(&*e_p2.kind)))), t_p5.clone()))
            } else {
                {
                    let lx1_pd = {
                        let mut this: crate::lower::Lx = lx_p0.clone();
                        this.tys = insert(&this.tys, &at_p4, &inner_p6);
                        this.lifts = insert(&this.lifts, &at_p4, &crate::check::typed::LiftNote { at: ln_p3.at.clone(), sigil: ln_p3.sigil.clone(), operands: Array::new() });
                        this
                    };
                    let lx2_pe = fold(&ln_p3.operands, &lx1_pd, &(|l_pf: &crate::lower::Lx, r_pg: &crate::syntax::Range| {
                        let mut this: crate::lower::Lx = l_pf.clone();
                        this.tys = insert(&this.tys, &crate::lower::place_key(&lx_p0, r_pg), &crate::lower::patterns::inner_ty(&crate::lower::type_at(&lx_p0, r_pg)));
                        this
                    }));
                    call_then(start_lift_operands(lx_p0.clone(), lx2_pe.clone(), env_p1.clone(), e_p2.clone(), ln_p3.sigil.clone(), ln_p3.operands.clone(), t_p5.clone()), move |lift_operands_11245: crate::lower::model::Ex| prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(lift_operands_11245, t_p5.clone())))
                }
            }
        })
    }
}

/// `Start LiftedValue, x`: what the function value is when passed to `@Run`.
pub fn start_lifted_value(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, e_p2: crate::syntax::Expr, ln_p3: crate::check::typed::LiftNote) -> Rc<dyn prism_rtl::Job<crate::lower::types::Vl>> {
    Rc::new(LiftedValue { lx_p0, env_p1, e_p2, ln_p3 })
}

/// ```prism
/// LiftOperands: unbounded fn Lx, Lx, Env, Expr, Text, [Range], OutTy -> Ex
/// ```
pub fn lift_operands(lx_p0: &crate::lower::Lx, lx_in_p1: &crate::lower::Lx, env_p2: &crate::lower::types::Env, e_p3: &crate::syntax::Expr, sigil_p4: &Text, operands_p5: &Array<crate::syntax::Range>, t_p6: &crate::lower::model::OutTy) -> crate::lower::model::Ex {
    match operands_p5 {
        m11508_0 if (m11508_0.len() == 0) => crate::lower::model::Ex::XCtor(if sigil_p4 == &Text::lit("~") { Text::lit("Ok") } else { Text::lit("Some") }, Array::from(vec![crate::lower::types::own(&plain_value_by_kind(lx_in_p1, env_p2, e_p3))])),
        _ => {
            let r_p7 = or(&index(operands_p5, &Nat::from(0u32)), &e_p3.span);
            let sv_p8 = value_of(lx_p0, env_p2, &or(&operand_at(e_p3, &r_p7), &dummy_expr()));
            let it_p9 = crate::lower::types::out_ty_of(lx_p0, &crate::lower::patterns::inner_ty(&crate::lower::type_at(lx_p0, &r_p7)));
            let owned_pa = match &sv_p8 {
                crate::lower::types::Vl::VlOwned(_, _) => true,
                _ => false,
            };
            let mode_pb = if owned_pa {
                crate::lower::types::Holding::Owned
            } else {
                crate::lower::types::Holding::ByRef
            };
            let x_pc = Text::from(format!("o{}_{}", &r_p7.start, &r_p7.end));
            let env2_pd = crate::lower::types::bind_span(env_p2, &crate::lower::place_key(lx_p0, &r_p7), &crate::lower::types::Vl::VlPlace(crate::lower::model::Ex::XVar(x_pc.clone()), mode_pb.clone(), it_p9.clone()));
            let body_pe = lift_operands(lx_p0, lx_in_p1, &env2_pd, e_p3, sigil_p4, &drop(operands_p5, &Nat::from(1u32)), t_p6);
            let fail_arm_pf = if sigil_p4 == &Text::lit("~") {
                crate::lower::model::XArm { pat: crate::lower::model::Pa::PaCtor(Text::lit("Err"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::from(format!("{}_e", &x_pc)))])), conds: Array::new(), body: crate::lower::model::Ex::XCtor(Text::lit("Err"), Array::from(vec![crate::lower::types::own(&crate::lower::types::Vl::VlPlace(crate::lower::model::Ex::XVar(Text::from(format!("{}_e", &x_pc))), mode_pb.clone(), crate::lower::model::OutTy::OutError))])) }
            } else {
                crate::lower::model::XArm { pat: crate::lower::model::Pa::PaUnit(Text::lit("None")), conds: Array::new(), body: crate::lower::model::Ex::XTyped(Rc::new(crate::lower::model::Ex::XNone), t_p6.clone()) }
            };
            let arms_pg = Array::from(vec![crate::lower::model::XArm { pat: crate::lower::model::Pa::PaCtor(if sigil_p4 == &Text::lit("~") { Text::lit("Ok") } else { Text::lit("Some") }, Array::from(vec![crate::lower::model::Pa::PaBind(x_pc.clone())])), conds: Array::new(), body: body_pe.clone() }, fail_arm_pf.clone()]);
            crate::lower::model::Ex::XMatch(Rc::new(if owned_pa {
                crate::lower::types::own(&sv_p8)
            } else {
                crate::lower::types::ref_(&sv_p8)
            }), arms_pg.clone(), false, t_p6.clone())
        },
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `LiftOperands`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LiftOperands: unbounded fn Lx, Lx, Env, Expr, Text, [Range], OutTy -> Ex
/// ```
pub struct LiftOperands {
    pub lx_p0: crate::lower::Lx,
    pub lx_in_p1: crate::lower::Lx,
    pub env_p2: crate::lower::types::Env,
    pub e_p3: crate::syntax::Expr,
    pub sigil_p4: Text,
    pub operands_p5: Array<crate::syntax::Range>,
    pub t_p6: crate::lower::model::OutTy,
}

impl prism_rtl::Job<crate::lower::model::Ex> for LiftOperands {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::Ex> {
        let lx_p0 = &self.lx_p0;
        let lx_in_p1 = &self.lx_in_p1;
        let env_p2 = &self.env_p2;
        let e_p3 = &self.e_p3;
        let sigil_p4 = &self.sigil_p4;
        let operands_p5 = &self.operands_p5;
        let t_p6 = &self.t_p6;
        match operands_p5 {
            m11508_0 if (m11508_0.len() == 0) => {
                let e_p3 = e_p3.clone();
                let env_p2 = env_p2.clone();
                let lx_in_p1 = lx_in_p1.clone();
                let sigil_p4 = sigil_p4.clone();
                call_then(start_plain_value_by_kind(lx_in_p1.clone(), env_p2.clone(), e_p3.clone()), move |plain_value_by_kind_11585: crate::lower::types::Vl| prism_rtl::Turn::Finished(crate::lower::model::Ex::XCtor(if &sigil_p4 == &Text::lit("~") { Text::lit("Ok") } else { Text::lit("Some") }, Array::from(vec![crate::lower::types::own(&plain_value_by_kind_11585)]))))
            },
            _ => {
                let r_p7 = or(&index(operands_p5, &Nat::from(0u32)), &e_p3.span);
                let e_p3 = e_p3.clone();
                let env_p2 = env_p2.clone();
                let lx_p0 = lx_p0.clone();
                let lx_in_p1 = lx_in_p1.clone();
                let operands_p5 = operands_p5.clone();
                let sigil_p4 = sigil_p4.clone();
                let t_p6 = t_p6.clone();
                call_then(start_value_of(lx_p0.clone(), env_p2.clone(), or(&operand_at(&e_p3, &r_p7), &dummy_expr())), move |value_of_11689: crate::lower::types::Vl| {
                    let sv_p8 = value_of_11689;
                    call_then(crate::lower::types::start_out_ty_of(lx_p0.clone(), crate::lower::patterns::inner_ty(&crate::lower::type_at(&lx_p0, &r_p7))), move |out_ty_of_11757: crate::lower::model::OutTy| {
                        let it_p9 = out_ty_of_11757;
                        let owned_pa = match &sv_p8 {
                            crate::lower::types::Vl::VlOwned(_, _) => true,
                            _ => false,
                        };
                        let mode_pb = if owned_pa {
                            crate::lower::types::Holding::Owned
                        } else {
                            crate::lower::types::Holding::ByRef
                        };
                        let x_pc = Text::from(format!("o{}_{}", &r_p7.start, &r_p7.end));
                        let env2_pd = crate::lower::types::bind_span(&env_p2, &crate::lower::place_key(&lx_p0, &r_p7), &crate::lower::types::Vl::VlPlace(crate::lower::model::Ex::XVar(x_pc.clone()), mode_pb.clone(), it_p9.clone()));
                        call_then(start_lift_operands(lx_p0.clone(), lx_in_p1.clone(), env2_pd.clone(), e_p3.clone(), sigil_p4.clone(), drop(&operands_p5, &Nat::from(1u32)), t_p6.clone()), move |lift_operands_12077: crate::lower::model::Ex| {
                            let body_pe = lift_operands_12077;
                            let fail_arm_pf = if &sigil_p4 == &Text::lit("~") {
                                crate::lower::model::XArm { pat: crate::lower::model::Pa::PaCtor(Text::lit("Err"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::from(format!("{}_e", &x_pc)))])), conds: Array::new(), body: crate::lower::model::Ex::XCtor(Text::lit("Err"), Array::from(vec![crate::lower::types::own(&crate::lower::types::Vl::VlPlace(crate::lower::model::Ex::XVar(Text::from(format!("{}_e", &x_pc))), mode_pb.clone(), crate::lower::model::OutTy::OutError))])) }
                            } else {
                                crate::lower::model::XArm { pat: crate::lower::model::Pa::PaUnit(Text::lit("None")), conds: Array::new(), body: crate::lower::model::Ex::XTyped(Rc::new(crate::lower::model::Ex::XNone), t_p6.clone()) }
                            };
                            let arms_pg = Array::from(vec![crate::lower::model::XArm { pat: crate::lower::model::Pa::PaCtor(if &sigil_p4 == &Text::lit("~") { Text::lit("Ok") } else { Text::lit("Some") }, Array::from(vec![crate::lower::model::Pa::PaBind(x_pc.clone())])), conds: Array::new(), body: body_pe.clone() }, fail_arm_pf.clone()]);
                            prism_rtl::Turn::Finished(crate::lower::model::Ex::XMatch(Rc::new(if owned_pa {
                                crate::lower::types::own(&sv_p8)
                            } else {
                                crate::lower::types::ref_(&sv_p8)
                            }), arms_pg.clone(), false, t_p6.clone()))
                        })
                    })
                })
            },
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start LiftOperands, x`: what the function value is when passed to `@Run`.
pub fn start_lift_operands(lx_p0: crate::lower::Lx, lx_in_p1: crate::lower::Lx, env_p2: crate::lower::types::Env, e_p3: crate::syntax::Expr, sigil_p4: Text, operands_p5: Array<crate::syntax::Range>, t_p6: crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>> {
    Rc::new(LiftOperands { lx_p0, lx_in_p1, env_p2, e_p3, sigil_p4, operands_p5, t_p6 })
}

/// ```prism
/// IsLiftedAt: fn Lx, Range -> Bool
/// ```
pub fn is_lifted_at(lx_p0: &crate::lower::Lx, r_p1: &crate::syntax::Range) -> bool {
    match get(&lx_p0.lifts, &crate::lower::place_key(lx_p0, r_p1)) {
        Some(ln_p2) => &len(&ln_p2.operands) > &Nat::from(0u32),
        None => false,
    }
}

/// ```prism
/// ?OperandAt: fn Expr, Range -> ?Expr
/// ```
pub fn operand_at(e_p0: &crate::syntax::Expr, r_p1: &crate::syntax::Range) -> Option<crate::syntax::Expr> {
    fold(&direct_operands(e_p0), &None, &(|found_o2: &Option<crate::syntax::Expr>, x_p3: &crate::syntax::Expr| if (found_o2 == &None) && (&x_p3.span == r_p1) {
        Some(x_p3.clone())
    } else {
        found_o2.clone()
    }))
}

/// ```prism
/// DirectOperands: fn Expr -> [Expr]
/// ```
pub fn direct_operands(e_p0: &crate::syntax::Expr) -> Array<crate::syntax::Expr> {
    match &*e_p0.kind {
        crate::syntax::ExprKind::EGroup(x_p1) => direct_operands(&**x_p1),
        crate::syntax::ExprKind::ECall(_, args_p2, _, _) => each(args_p2, &(|a_p3: &crate::syntax::Arg| a_p3.value.clone())),
        crate::syntax::ExprKind::EMethod(r_p4, _, args_p5) => append(&Array::from(vec![(**r_p4).clone()]), &each(args_p5, &(|a_p6: &crate::syntax::Arg| a_p6.value.clone()))),
        crate::syntax::ExprKind::EBinary(_, l_p7, r_p8) => Array::from(vec![(**l_p7).clone(), (**r_p8).clone()]),
        crate::syntax::ExprKind::EUnary(_, x_p9) => Array::from(vec![(**x_p9).clone()]),
        crate::syntax::ExprKind::EFreeSigil(_, x_pa) => Array::from(vec![(**x_pa).clone()]),
        crate::syntax::ExprKind::EField(r_pb, _, _) => Array::from(vec![(**r_pb).clone()]),
        crate::syntax::ExprKind::EIndex(r_pc, i_pd) => Array::from(vec![(**r_pc).clone(), (**i_pd).clone()]),
        crate::syntax::ExprKind::EMap(kvs_pe) => fold(kvs_pe, &Array::new(), &(|acc_pf: &Array<crate::syntax::Expr>, (k_pg, v_ph): &(crate::syntax::Expr, crate::syntax::Expr)| append(acc_pf, &Array::from(vec![k_pg.clone(), v_ph.clone()])))),
        _ => Array::new(),
    }
}

/// ```prism
/// PlainValueByKind: unbounded fn Lx, Env, Expr -> Vl
/// ```
pub fn plain_value_by_kind(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, e_p2: &crate::syntax::Expr) -> crate::lower::types::Vl {
    let t_p3 = crate::lower::types::out_ty_of(lx_p0, &crate::lower::types::peel(&crate::lower::type_at(lx_p0, &e_p2.span)));
    match &*e_p2.kind {
        crate::syntax::ExprKind::EName(n_p4) => name_value(lx_p0, env_p1, n_p4, &e_p2.span),
        crate::syntax::ExprKind::ELit(l_p5) => literal_value(lx_p0, env_p1, l_p5, &e_p2.span, &false),
        crate::syntax::ExprKind::EUnit(_) => crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XUnit, crate::lower::model::OutTy::OutUnit),
        crate::syntax::ExprKind::EBound(b_p6) => match get(&env_p1.names, b_p6) {
            Some(crate::lower::types::Bn::BnLocal(rs_p7, mode_p8, bt_p9)) => crate::lower::types::local_place(&rs_p7, &mode_p8, &bt_p9),
            _ => crate::lower::types::Vl::VlOwned(refusal(&Text::from(format!("`{}` outside a `for`", b_p6))), t_p3.clone()),
        },
        crate::syntax::ExprKind::ENil(_) => crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XTyped(Rc::new(crate::lower::model::Ex::XNone), t_p3.clone()), t_p3.clone()),
        crate::syntax::ExprKind::ETuple(es_pa) => crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XTuple(run_to_end(each_job(es_pa.clone(), {
            let lx_p0 = lx_p0.clone();
            let env_p1 = env_p1.clone();
            Rc::new(move |p0: crate::syntax::Expr| {
                let lx_p0 = lx_p0.clone();
                let env_p1 = env_p1.clone();
                entered(once_job(move || {
                    let x_pb = p0;
                    call_then(start_value_of(lx_p0.clone(), env_p1.clone(), x_pb.clone()), move |value_of_14019: crate::lower::types::Vl| prism_rtl::Turn::Finished(crate::lower::types::own(&value_of_14019)))
                }))
            }) as Rc<dyn Fn(crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
        }))), t_p3.clone()),
        crate::syntax::ExprKind::EArray(m13582_6_0) if (m13582_6_0.len() == 0) => crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XTyped(Rc::new(crate::lower::model::Ex::XCall(Text::lit("Array::new"), Array::new())), t_p3.clone()), t_p3.clone()),
        crate::syntax::ExprKind::EArray(es_pc) => crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCall(Text::lit("Array::from"), Array::from(vec![crate::lower::model::Ex::XVec(run_to_end(each_job(es_pc.clone(), {
            let lx_p0 = lx_p0.clone();
            let env_p1 = env_p1.clone();
            Rc::new(move |p0: crate::syntax::Expr| {
                let lx_p0 = lx_p0.clone();
                let env_p1 = env_p1.clone();
                entered(once_job(move || {
                    let x_pd = p0;
                    call_then(start_value_of(lx_p0.clone(), env_p1.clone(), x_pd.clone()), move |value_of_14191: crate::lower::types::Vl| prism_rtl::Turn::Finished(crate::lower::types::own(&value_of_14191)))
                }))
            }) as Rc<dyn Fn(crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
        })))])), t_p3.clone()),
        crate::syntax::ExprKind::EMap(m13582_8_0) if (m13582_8_0.len() == 0) => crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XTyped(Rc::new(crate::lower::model::Ex::XCall(Text::lit("Map::new"), Array::new())), t_p3.clone()), t_p3.clone()),
        crate::syntax::ExprKind::EMap(kvs_pe) => crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCall(Text::lit("map_of"), Array::from(vec![crate::lower::model::Ex::XVec(run_to_end(each_job(kvs_pe.clone(), {
            let lx_p0 = lx_p0.clone();
            let env_p1 = env_p1.clone();
            Rc::new(move |p0: (crate::syntax::Expr, crate::syntax::Expr)| {
                let lx_p0 = lx_p0.clone();
                let env_p1 = env_p1.clone();
                entered(once_job(move || {
                    let (k_pf, v_pg) = p0;
                    call_then(start_value_of(lx_p0.clone(), env_p1.clone(), k_pf.clone()), move |value_of_14372: crate::lower::types::Vl| call_then(start_value_of(lx_p0.clone(), env_p1.clone(), v_pg.clone()), move |value_of_14398: crate::lower::types::Vl| prism_rtl::Turn::Finished(crate::lower::model::Ex::XTuple(Array::from(vec![crate::lower::types::own(&value_of_14372), crate::lower::types::own(&value_of_14398)])))))
                }))
            }) as Rc<dyn Fn((crate::syntax::Expr, crate::syntax::Expr)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
        })))])), t_p3.clone()),
        crate::syntax::ExprKind::EGroup(x_ph) => value_of(lx_p0, env_p1, &**x_ph),
        crate::syntax::ExprKind::ECall(c_pi, args_pj, _, _) => application(lx_p0, env_p1, &**c_pi, args_pj, &e_p2.span),
        crate::syntax::ExprKind::EMethod(r_pk, m_pl, args_pm) => application(lx_p0, env_p1, &crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EName(m_pl.clone())), span: m_pl.span.clone() }, &append(&Array::from(vec![crate::syntax::Arg { name: None, value: (**r_pk).clone(), span: r_pk.span.clone() }]), args_pm), &e_p2.span),
        crate::syntax::ExprKind::EBinary(op_pn, l_po, r_pp) => binary_value(lx_p0, env_p1, op_pn, &**l_po, &**r_pp, &e_p2.span),
        crate::syntax::ExprKind::EUnary(m13582_14_0, x_pq) if (m13582_14_0 == &Text::lit("not")) => crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XUnary(Text::lit("!"), Rc::new(crate::lower::types::as_bool(&value_of(lx_p0, env_p1, &**x_pq)))), crate::lower::model::OutTy::OutBool),
        crate::syntax::ExprKind::EUnary(m13582_15_0, x_pr) if (m13582_15_0 == &Text::lit("neg")) => match &*x_pr.kind {
            crate::syntax::ExprKind::ELit(l_ps) => literal_value(lx_p0, env_p1, l_ps, &x_pr.span, &true),
            _ => {
                let v_pt = value_of(lx_p0, env_p1, &**x_pr);
                if crate::lower::types::is_copy(&t_p3) {
                    crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XUnary(Text::lit("-"), Rc::new(crate::lower::types::copy(&v_pt))), t_p3.clone())
                } else {
                    crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XUnary(Text::lit("-"), Rc::new(crate::lower::types::ref_(&v_pt))), t_p3.clone())
                }
            },
        },
        crate::syntax::ExprKind::EUnary(_, x_pu) => value_of(lx_p0, env_p1, &**x_pu),
        crate::syntax::ExprKind::EFreeSigil(m13582_17_0, x_pv) if (m13582_17_0 == &Text::lit("?")) => crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCtor(Text::lit("Some"), Array::from(vec![crate::lower::types::own(&value_of(lx_p0, env_p1, &**x_pv))])), t_p3.clone()),
        crate::syntax::ExprKind::EFreeSigil(m13582_18_0, x_p10) if (m13582_18_0 == &Text::lit("~")) => crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCtor(Text::lit("Ok"), Array::from(vec![crate::lower::types::own(&value_of(lx_p0, env_p1, &**x_p10))])), t_p3.clone()),
        crate::syntax::ExprKind::EFreeSigil(m13582_19_0, x_p11) if (m13582_19_0 == &Text::lit("@")) => pure_blueprint(lx_p0, env_p1, &**x_p11, &t_p3),
        crate::syntax::ExprKind::EFreeSigil(_, x_p12) => value_of(lx_p0, env_p1, &**x_p12),
        crate::syntax::ExprKind::EField(r_p13, _, name_p14) => field_value(lx_p0, env_p1, &**r_p13, &name_p14.name),
        crate::syntax::ExprKind::EIndex(r_p15, i_p16) => index_value(lx_p0, env_p1, &**r_p15, &**i_p16, &t_p3),
        crate::syntax::ExprKind::ELambda(ps_o17, body_p18) => lambda_value(lx_p0, env_p1, e_p2, &or(ps_o17, &Array::new()), &**body_p18),
        crate::syntax::ExprKind::EIf(c_p19, then_b_p1a, else_b_o1b) => if_value(lx_p0, env_p1, &**c_p19, then_b_p1a, else_b_o1b, &t_p3),
        crate::syntax::ExprKind::EMatch(s_p1c, arms_p1d) => match_value(lx_p0, env_p1, &**s_p1c, arms_p1d, &t_p3, &e_p2.span),
        crate::syntax::ExprKind::ETemplate(tp_p1e) => crate::lower::templates::template_value(lx_p0, env_p1, tp_p1e),
        crate::syntax::ExprKind::ECast(x_p1f, _, _) => value_of(lx_p0, env_p1, &**x_p1f),
        crate::syntax::ExprKind::ETypeArgs(x_p1g, _) => value_of(lx_p0, env_p1, &**x_p1g),
        crate::syntax::ExprKind::EGiven(b_p1h) => crate::lower::templates::given_value(lx_p0, env_p1, b_p1h, &t_p3, &e_p2.span),
        crate::syntax::ExprKind::EUpdate(target_p1i, b_p1j) => crate::lower::templates::update_value(lx_p0, env_p1, &**target_p1i, b_p1j, &t_p3, &e_p2.span),
        crate::syntax::ExprKind::EAny(x_p1k) => crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCall(Text::lit("Rc::new"), Array::from(vec![crate::lower::types::own(&value_of(lx_p0, env_p1, &**x_p1k))])), crate::lower::model::OutTy::OutShowAny),
        _ => crate::lower::types::Vl::VlOwned(refusal(&Text::from(format!("{} as a value", &kind_words(&*e_p2.kind)))), t_p3.clone()),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `PlainValueByKind`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PlainValueByKind: unbounded fn Lx, Env, Expr -> Vl
/// ```
pub struct PlainValueByKind {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub e_p2: crate::syntax::Expr,
}

impl prism_rtl::Job<crate::lower::types::Vl> for PlainValueByKind {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::types::Vl> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let e_p2 = &self.e_p2;
        let e_p2 = e_p2.clone();
        let env_p1 = env_p1.clone();
        let lx_p0 = lx_p0.clone();
        call_then(crate::lower::types::start_out_ty_of(lx_p0.clone(), crate::lower::types::peel(&crate::lower::type_at(&lx_p0, &e_p2.span))), move |out_ty_of_13539: crate::lower::model::OutTy| {
            let t_p3 = out_ty_of_13539;
            match &*e_p2.kind {
                crate::syntax::ExprKind::EName(n_p4) => prism_rtl::Turn::More(Rc::new(NameValue { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), n_p2: n_p4.clone(), span_p3: e_p2.span.clone() })),
                crate::syntax::ExprKind::ELit(l_p5) => prism_rtl::Turn::More(Rc::new(LiteralValue { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), l_p2: l_p5.clone(), span_p3: e_p2.span.clone(), neg_p4: false })),
                crate::syntax::ExprKind::EUnit(_) => prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XUnit, crate::lower::model::OutTy::OutUnit)),
                crate::syntax::ExprKind::EBound(b_p6) => match get(&env_p1.names, b_p6) {
                    Some(crate::lower::types::Bn::BnLocal(rs_p7, mode_p8, bt_p9)) => prism_rtl::Turn::Finished(crate::lower::types::local_place(&rs_p7, &mode_p8, &bt_p9)),
                    _ => prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(refusal(&Text::from(format!("`{}` outside a `for`", b_p6))), t_p3.clone())),
                },
                crate::syntax::ExprKind::ENil(_) => prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XTyped(Rc::new(crate::lower::model::Ex::XNone), t_p3.clone()), t_p3.clone())),
                crate::syntax::ExprKind::ETuple(es_pa) => {
                    let es_pa = es_pa.clone();
                    call_value(each_job(es_pa.clone(), {
                        let lx_p0 = lx_p0.clone();
                        let env_p1 = env_p1.clone();
                        Rc::new(move |p0: crate::syntax::Expr| {
                            let lx_p0 = lx_p0.clone();
                            let env_p1 = env_p1.clone();
                            entered(once_job(move || {
                                let x_pb = p0;
                                call_then(start_value_of(lx_p0.clone(), env_p1.clone(), x_pb.clone()), move |value_of_14019: crate::lower::types::Vl| prism_rtl::Turn::Finished(crate::lower::types::own(&value_of_14019)))
                            }))
                        }) as Rc<dyn Fn(crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
                    }), move |each_14000: Array<crate::lower::model::Ex>| prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XTuple(each_14000), t_p3.clone())))
                },
                crate::syntax::ExprKind::EArray(m13582_6_0) if (m13582_6_0.len() == 0) => prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XTyped(Rc::new(crate::lower::model::Ex::XCall(Text::lit("Array::new"), Array::new())), t_p3.clone()), t_p3.clone())),
                crate::syntax::ExprKind::EArray(es_pc) => {
                    let es_pc = es_pc.clone();
                    call_value(each_job(es_pc.clone(), {
                        let lx_p0 = lx_p0.clone();
                        let env_p1 = env_p1.clone();
                        Rc::new(move |p0: crate::syntax::Expr| {
                            let lx_p0 = lx_p0.clone();
                            let env_p1 = env_p1.clone();
                            entered(once_job(move || {
                                let x_pd = p0;
                                call_then(start_value_of(lx_p0.clone(), env_p1.clone(), x_pd.clone()), move |value_of_14191: crate::lower::types::Vl| prism_rtl::Turn::Finished(crate::lower::types::own(&value_of_14191)))
                            }))
                        }) as Rc<dyn Fn(crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
                    }), move |each_14172: Array<crate::lower::model::Ex>| prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCall(Text::lit("Array::from"), Array::from(vec![crate::lower::model::Ex::XVec(each_14172)])), t_p3.clone())))
                },
                crate::syntax::ExprKind::EMap(m13582_8_0) if (m13582_8_0.len() == 0) => prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XTyped(Rc::new(crate::lower::model::Ex::XCall(Text::lit("Map::new"), Array::new())), t_p3.clone()), t_p3.clone())),
                crate::syntax::ExprKind::EMap(kvs_pe) => {
                    let kvs_pe = kvs_pe.clone();
                    call_value(each_job(kvs_pe.clone(), {
                        let lx_p0 = lx_p0.clone();
                        let env_p1 = env_p1.clone();
                        Rc::new(move |p0: (crate::syntax::Expr, crate::syntax::Expr)| {
                            let lx_p0 = lx_p0.clone();
                            let env_p1 = env_p1.clone();
                            entered(once_job(move || {
                                let (k_pf, v_pg) = p0;
                                call_then(start_value_of(lx_p0.clone(), env_p1.clone(), k_pf.clone()), move |value_of_14372: crate::lower::types::Vl| call_then(start_value_of(lx_p0.clone(), env_p1.clone(), v_pg.clone()), move |value_of_14398: crate::lower::types::Vl| prism_rtl::Turn::Finished(crate::lower::model::Ex::XTuple(Array::from(vec![crate::lower::types::own(&value_of_14372), crate::lower::types::own(&value_of_14398)])))))
                            }))
                        }) as Rc<dyn Fn((crate::syntax::Expr, crate::syntax::Expr)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
                    }), move |each_14336: Array<crate::lower::model::Ex>| prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCall(Text::lit("map_of"), Array::from(vec![crate::lower::model::Ex::XVec(each_14336)])), t_p3.clone())))
                },
                crate::syntax::ExprKind::EGroup(x_ph) => prism_rtl::Turn::More(Rc::new(ValueOf { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), e_p2: (**x_ph).clone() })),
                crate::syntax::ExprKind::ECall(c_pi, args_pj, _, _) => prism_rtl::Turn::More(Rc::new(Application { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), callee_p2: (**c_pi).clone(), args_p3: args_pj.clone(), span_p4: e_p2.span.clone() })),
                crate::syntax::ExprKind::EMethod(r_pk, m_pl, args_pm) => prism_rtl::Turn::More(Rc::new(Application { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), callee_p2: crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EName(m_pl.clone())), span: m_pl.span.clone() }, args_p3: append(&Array::from(vec![crate::syntax::Arg { name: None, value: (**r_pk).clone(), span: r_pk.span.clone() }]), args_pm), span_p4: e_p2.span.clone() })),
                crate::syntax::ExprKind::EBinary(op_pn, l_po, r_pp) => prism_rtl::Turn::More(Rc::new(BinaryValue { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), op_p2: op_pn.clone(), l_p3: (**l_po).clone(), r_p4: (**r_pp).clone(), span_p5: e_p2.span.clone() })),
                crate::syntax::ExprKind::EUnary(m13582_14_0, x_pq) if (m13582_14_0 == &Text::lit("not")) => {
                    let x_pq = (**x_pq).clone();
                    call_then(start_value_of(lx_p0.clone(), env_p1.clone(), x_pq.clone()), move |value_of_14808: crate::lower::types::Vl| prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XUnary(Text::lit("!"), Rc::new(crate::lower::types::as_bool(&value_of_14808))), crate::lower::model::OutTy::OutBool)))
                },
                crate::syntax::ExprKind::EUnary(m13582_15_0, x_pr) if (m13582_15_0 == &Text::lit("neg")) => match &*x_pr.kind {
                    crate::syntax::ExprKind::ELit(l_ps) => prism_rtl::Turn::More(Rc::new(LiteralValue { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), l_p2: l_ps.clone(), span_p3: x_pr.span.clone(), neg_p4: true })),
                    _ => {
                        let x_pr = (**x_pr).clone();
                        call_then(start_value_of(lx_p0.clone(), env_p1.clone(), x_pr.clone()), move |value_of_14983: crate::lower::types::Vl| {
                            let v_pt = value_of_14983;
                            if crate::lower::types::is_copy(&t_p3) {
                                prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XUnary(Text::lit("-"), Rc::new(crate::lower::types::copy(&v_pt))), t_p3.clone()))
                            } else {
                                prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XUnary(Text::lit("-"), Rc::new(crate::lower::types::ref_(&v_pt))), t_p3.clone()))
                            }
                        })
                    },
                },
                crate::syntax::ExprKind::EUnary(_, x_pu) => prism_rtl::Turn::More(Rc::new(ValueOf { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), e_p2: (**x_pu).clone() })),
                crate::syntax::ExprKind::EFreeSigil(m13582_17_0, x_pv) if (m13582_17_0 == &Text::lit("?")) => {
                    let x_pv = (**x_pv).clone();
                    call_then(start_value_of(lx_p0.clone(), env_p1.clone(), x_pv.clone()), move |value_of_15206: crate::lower::types::Vl| prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCtor(Text::lit("Some"), Array::from(vec![crate::lower::types::own(&value_of_15206)])), t_p3.clone())))
                },
                crate::syntax::ExprKind::EFreeSigil(m13582_18_0, x_p10) if (m13582_18_0 == &Text::lit("~")) => {
                    let x_p10 = (**x_p10).clone();
                    call_then(start_value_of(lx_p0.clone(), env_p1.clone(), x_p10.clone()), move |value_of_15287: crate::lower::types::Vl| prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCtor(Text::lit("Ok"), Array::from(vec![crate::lower::types::own(&value_of_15287)])), t_p3.clone())))
                },
                crate::syntax::ExprKind::EFreeSigil(m13582_19_0, x_p11) if (m13582_19_0 == &Text::lit("@")) => prism_rtl::Turn::More(Rc::new(PureBlueprint { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), x_p2: (**x_p11).clone(), t_p3: t_p3.clone() })),
                crate::syntax::ExprKind::EFreeSigil(_, x_p12) => prism_rtl::Turn::More(Rc::new(ValueOf { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), e_p2: (**x_p12).clone() })),
                crate::syntax::ExprKind::EField(r_p13, _, name_p14) => prism_rtl::Turn::More(Rc::new(FieldValue { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), r_p2: (**r_p13).clone(), name_p3: name_p14.name.clone() })),
                crate::syntax::ExprKind::EIndex(r_p15, i_p16) => prism_rtl::Turn::More(Rc::new(IndexValue { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), r_p2: (**r_p15).clone(), i_p3: (**i_p16).clone(), t_p4: t_p3.clone() })),
                crate::syntax::ExprKind::ELambda(ps_o17, body_p18) => prism_rtl::Turn::More(Rc::new(LambdaValue { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), e_p2: e_p2.clone(), ps_p3: or(ps_o17, &Array::new()), body_p4: (**body_p18).clone() })),
                crate::syntax::ExprKind::EIf(c_p19, then_b_p1a, else_b_o1b) => prism_rtl::Turn::More(Rc::new(IfValue { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), c_p2: (**c_p19).clone(), then_b_p3: then_b_p1a.clone(), else_b_o4: else_b_o1b.clone(), t_p5: t_p3.clone() })),
                crate::syntax::ExprKind::EMatch(s_p1c, arms_p1d) => prism_rtl::Turn::More(Rc::new(MatchValue { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), s_p2: (**s_p1c).clone(), arms_p3: arms_p1d.clone(), t_p4: t_p3.clone(), span_p5: e_p2.span.clone() })),
                crate::syntax::ExprKind::ETemplate(tp_p1e) => prism_rtl::Turn::More(Rc::new(crate::lower::templates::TemplateValue { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), tp_p2: tp_p1e.clone() })),
                crate::syntax::ExprKind::ECast(x_p1f, _, _) => prism_rtl::Turn::More(Rc::new(ValueOf { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), e_p2: (**x_p1f).clone() })),
                crate::syntax::ExprKind::ETypeArgs(x_p1g, _) => prism_rtl::Turn::More(Rc::new(ValueOf { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), e_p2: (**x_p1g).clone() })),
                crate::syntax::ExprKind::EGiven(b_p1h) => prism_rtl::Turn::More(Rc::new(crate::lower::templates::GivenValue { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), b_p2: b_p1h.clone(), t_p3: t_p3.clone(), span_p4: e_p2.span.clone() })),
                crate::syntax::ExprKind::EUpdate(target_p1i, b_p1j) => prism_rtl::Turn::More(Rc::new(crate::lower::templates::UpdateValue { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), target_p2: (**target_p1i).clone(), b_p3: b_p1j.clone(), t_p4: t_p3.clone(), span_p5: e_p2.span.clone() })),
                crate::syntax::ExprKind::EAny(x_p1k) => {
                    let x_p1k = (**x_p1k).clone();
                    call_then(start_value_of(lx_p0.clone(), env_p1.clone(), x_p1k.clone()), move |value_of_16050: crate::lower::types::Vl| prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCall(Text::lit("Rc::new"), Array::from(vec![crate::lower::types::own(&value_of_16050)])), crate::lower::model::OutTy::OutShowAny)))
                },
                _ => prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(refusal(&Text::from(format!("{} as a value", &kind_words(&*e_p2.kind)))), t_p3.clone())),
                _ => unreachable!("no arm matched"),
            }
        })
    }
}

/// `Start PlainValueByKind, x`: what the function value is when passed to `@Run`.
pub fn start_plain_value_by_kind(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, e_p2: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<crate::lower::types::Vl>> {
    Rc::new(PlainValueByKind { lx_p0, env_p1, e_p2 })
}

/// ```prism
/// PureBlueprint: unbounded fn Lx, Env, Expr, OutTy -> Vl
/// ```
pub fn pure_blueprint(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, x_p2: &crate::syntax::Expr, t_p3: &crate::lower::model::OutTy) -> crate::lower::types::Vl {
    let is_never_p4 = match &*x_p2.kind {
        crate::syntax::ExprKind::EName(n_p5) => {
            let (qk_o6, _) = crate::check::env::names::resolve_value(&lx_p0.g, &lx_p0.home, n_p5);
            &qk_o6 == &Some(Text::lit("Prelude.never"))
        },
        _ => false,
    };
    if is_never_p4 {
        crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCall(Text::lit("prism_rtl::never_blueprint::<crate::Elem, crate::Answer>"), Array::new()), t_p3.clone())
    } else {
        match get(&env_p1.names, &Text::lit("#tag")) {
            None => crate::lower::types::Vl::VlOwned(refusal(&Text::from(format!("`@ {}` as a supplier\'s answer outside a tag arm: which tag\'s output it answers cannot be known", &crate::lower::functions::src_text(lx_p0, &lx_p0.file, &x_p2.span)))), t_p3.clone()),
            Some(crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XPath(variant_p7), _, _)) => match crate::lower::types::layer_of(&crate::lower::type_at(lx_p0, &x_p2.span)) {
                crate::lower::types::Layer::LyEv => {
                    let wrapped_p8 = crate::lower::model::Ex::XMethod(Rc::new(crate::lower::types::own(&value_of(lx_p0, env_p1, x_p2))), Text::lit("map"), Array::from(vec![crate::lower::model::Ex::XClosure(false, Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("v"))]), Rc::new(crate::lower::model::Ex::XCtor(variant_p7.clone(), Array::from(vec![crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(Text::lit("v"))))]))))]));
                    crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCall(Text::lit("prism_rtl::event_blueprint::<crate::Elem, _>"), Array::from(vec![wrapped_p8.clone()])), t_p3.clone())
                },
                crate::lower::types::Layer::LyDyn => match crate::lower::node_::static_::dynamic_answer(lx_p0, x_p2) {
                    None => match &*x_p2.kind {
                        crate::syntax::ExprKind::EFreeSigil(m17752_0_0, inner_p9) if (m17752_0_0 == &Text::lit("$")) => plain_blueprint_(lx_p0, env_p1, &**inner_p9, &variant_p7, t_p3),
                        _ => crate::lower::types::Vl::VlOwned(refusal(&Text::from(format!("`@ {}`, a supplier\'s dynamic answer of no known form", &crate::lower::functions::src_text(lx_p0, &lx_p0.file, &x_p2.span)))), t_p3.clone()),
                        _ => unreachable!("no arm matched"),
                    },
                    Some(d_pa) => dynamic_blueprint_(lx_p0, env_p1, x_p2, &d_pa, &variant_p7, t_p3),
                },
                _ => plain_blueprint_(lx_p0, env_p1, x_p2, &variant_p7, t_p3),
            },
            _ => crate::lower::types::Vl::VlOwned(refusal(&Text::lit("a supplier\'s answer under a tag the arm does not name")), t_p3.clone()),
        }
    }
}

/// The step machine of `PureBlueprint`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PureBlueprint: unbounded fn Lx, Env, Expr, OutTy -> Vl
/// ```
pub struct PureBlueprint {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub x_p2: crate::syntax::Expr,
    pub t_p3: crate::lower::model::OutTy,
}

impl prism_rtl::Job<crate::lower::types::Vl> for PureBlueprint {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::types::Vl> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let x_p2 = &self.x_p2;
        let t_p3 = &self.t_p3;
        let is_never_p4 = match &*x_p2.kind {
            crate::syntax::ExprKind::EName(n_p5) => {
                let (qk_o6, _) = crate::check::env::names::resolve_value(&lx_p0.g, &lx_p0.home, n_p5);
                &qk_o6 == &Some(Text::lit("Prelude.never"))
            },
            _ => false,
        };
        if is_never_p4 {
            prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCall(Text::lit("prism_rtl::never_blueprint::<crate::Elem, crate::Answer>"), Array::new()), t_p3.clone()))
        } else {
            match get(&env_p1.names, &Text::lit("#tag")) {
                None => prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(refusal(&Text::from(format!("`@ {}` as a supplier\'s answer outside a tag arm: which tag\'s output it answers cannot be known", &crate::lower::functions::src_text(lx_p0, &lx_p0.file, &x_p2.span)))), t_p3.clone())),
                Some(crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XPath(variant_p7), _, _)) => match crate::lower::types::layer_of(&crate::lower::type_at(lx_p0, &x_p2.span)) {
                    crate::lower::types::Layer::LyEv => {
                        let env_p1 = env_p1.clone();
                        let lx_p0 = lx_p0.clone();
                        let t_p3 = t_p3.clone();
                        let x_p2 = x_p2.clone();
                        call_then(start_value_of(lx_p0.clone(), env_p1.clone(), x_p2.clone()), move |value_of_17481: crate::lower::types::Vl| {
                            let wrapped_p8 = crate::lower::model::Ex::XMethod(Rc::new(crate::lower::types::own(&value_of_17481)), Text::lit("map"), Array::from(vec![crate::lower::model::Ex::XClosure(false, Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("v"))]), Rc::new(crate::lower::model::Ex::XCtor(variant_p7.clone(), Array::from(vec![crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(Text::lit("v"))))]))))]));
                            prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCall(Text::lit("prism_rtl::event_blueprint::<crate::Elem, _>"), Array::from(vec![wrapped_p8.clone()])), t_p3.clone()))
                        })
                    },
                    crate::lower::types::Layer::LyDyn => match crate::lower::node_::static_::dynamic_answer(lx_p0, x_p2) {
                        None => match &*x_p2.kind {
                            crate::syntax::ExprKind::EFreeSigil(m17752_0_0, inner_p9) if (m17752_0_0 == &Text::lit("$")) => prism_rtl::Turn::More(Rc::new(PlainBlueprint { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), x_p2: (**inner_p9).clone(), variant_p3: variant_p7.clone(), t_p4: t_p3.clone() })),
                            _ => prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(refusal(&Text::from(format!("`@ {}`, a supplier\'s dynamic answer of no known form", &crate::lower::functions::src_text(lx_p0, &lx_p0.file, &x_p2.span)))), t_p3.clone())),
                            _ => unreachable!("no arm matched"),
                        },
                        Some(d_pa) => prism_rtl::Turn::More(Rc::new(DynamicBlueprint { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), x_p2: x_p2.clone(), d_p3: d_pa.clone(), variant_p4: variant_p7.clone(), t_p5: t_p3.clone() })),
                    },
                    _ => prism_rtl::Turn::More(Rc::new(PlainBlueprint { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), x_p2: x_p2.clone(), variant_p3: variant_p7.clone(), t_p4: t_p3.clone() })),
                },
                _ => prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(refusal(&Text::lit("a supplier\'s answer under a tag the arm does not name")), t_p3.clone())),
            }
        }
    }
}

/// `Start PureBlueprint, x`: what the function value is when passed to `@Run`.
pub fn start_pure_blueprint(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, x_p2: crate::syntax::Expr, t_p3: crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<crate::lower::types::Vl>> {
    Rc::new(PureBlueprint { lx_p0, env_p1, x_p2, t_p3 })
}

/// ```prism
/// PlainBlueprint: unbounded fn Lx, Env, Expr, Text, OutTy -> Vl
/// ```
pub fn plain_blueprint_(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, x_p2: &crate::syntax::Expr, variant_p3: &Text, t_p4: &crate::lower::model::OutTy) -> crate::lower::types::Vl {
    crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCall(Text::lit("prism_rtl::plain_blueprint::<crate::Elem, _>"), Array::from(vec![crate::lower::model::Ex::XCtor(variant_p3.clone(), Array::from(vec![crate::lower::types::own(&value_of(lx_p0, env_p1, x_p2))]))])), t_p4.clone())
}

/// The step machine of `PlainBlueprint`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PlainBlueprint: unbounded fn Lx, Env, Expr, Text, OutTy -> Vl
/// ```
pub struct PlainBlueprint {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub x_p2: crate::syntax::Expr,
    pub variant_p3: Text,
    pub t_p4: crate::lower::model::OutTy,
}

impl prism_rtl::Job<crate::lower::types::Vl> for PlainBlueprint {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::types::Vl> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let x_p2 = &self.x_p2;
        let variant_p3 = &self.variant_p3;
        let t_p4 = &self.t_p4;
        let env_p1 = env_p1.clone();
        let lx_p0 = lx_p0.clone();
        let t_p4 = t_p4.clone();
        let variant_p3 = variant_p3.clone();
        let x_p2 = x_p2.clone();
        call_then(start_value_of(lx_p0.clone(), env_p1.clone(), x_p2.clone()), move |value_of_18400: crate::lower::types::Vl| prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCall(Text::lit("prism_rtl::plain_blueprint::<crate::Elem, _>"), Array::from(vec![crate::lower::model::Ex::XCtor(variant_p3.clone(), Array::from(vec![crate::lower::types::own(&value_of_18400)]))])), t_p4.clone())))
    }
}

/// `Start PlainBlueprint, x`: what the function value is when passed to `@Run`.
pub fn start_plain_blueprint_(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, x_p2: crate::syntax::Expr, variant_p3: Text, t_p4: crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<crate::lower::types::Vl>> {
    Rc::new(PlainBlueprint { lx_p0, env_p1, x_p2, variant_p3, t_p4 })
}

/// ```prism
/// DynamicBlueprint: unbounded fn Lx, Env, Expr, Expr, Text, OutTy -> Vl
/// ```
pub fn dynamic_blueprint_(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, x_p2: &crate::syntax::Expr, d_p3: &crate::syntax::Expr, variant_p4: &Text, t_p5: &crate::lower::model::OutTy) -> crate::lower::types::Vl {
    match (get(&env_p1.names, &Text::from(format!("#dyn{}", &crate::lower::node_::static_::dyn_key(x_p2)))), get(&env_p1.names, &Text::lit("#owner"))) {
        (Some(crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(getter_p6), _, dt_p7)), Some(crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(owner_p8), _, _))) => {
            let at_build_p9 = crate::lower::types::own(&value_of(lx_p0, &crate::lower::node_::def::init_env(env_p1), d_p3));
            let arms_pa = Array::from(vec![crate::lower::model::XArm { pat: crate::lower::model::Pa::PaCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("owner"))])), conds: Array::new(), body: crate::lower::model::Ex::XCtor(variant_p4.clone(), Array::from(vec![crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("owner"))), getter_p6.clone(), Array::from(vec![crate::lower::model::Ex::XCx]))])) }, crate::lower::model::XArm { pat: crate::lower::model::Pa::PaUnit(Text::lit("None")), conds: Array::new(), body: crate::lower::model::Ex::XCtor(variant_p4.clone(), Array::from(vec![crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(Text::lit("at_build"))))])) }]);
            let read_pb = crate::lower::model::Ex::XClosure(true, Array::from(vec![crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaBind(Text::lit("cx"))), crate::lower::model::OutTy::OutRef(Rc::new(crate::lower::model::OutTy::OutNamed(Text::lit("Cx"), Array::new()))))]), Rc::new(crate::lower::model::Ex::XMatch(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("link"))), Text::lit("owner"), Array::new())), arms_pa.clone(), false, crate::lower::model::OutTy::OutNamed(Text::lit("crate::Answer"), Array::new()))));
            let dynamic_pc = crate::lower::model::Ex::XBlock(Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(Text::lit("link")), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(owner_p8.clone())))), crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(Text::lit("at_build")), at_build_p9.clone())]), Rc::new(crate::lower::model::Ex::XCall(Text::lit("prism_rtl::Dynamic::of"), Array::from(vec![read_pb.clone(), crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XVar(Text::from(format!("{}_port", &getter_p6)))))]))));
            crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCall(Text::lit("prism_rtl::dynamic_blueprint::<crate::Elem, _>"), Array::from(vec![dynamic_pc.clone()])), t_p5.clone())
        },
        _ => crate::lower::types::Vl::VlOwned(refusal(&Text::from(format!("`@ {}`, a supplier\'s dynamic answer that reads what has no value at the owner\'s build (a pushed place, a structural dynamic, or a `let` after the host\'s line)", &crate::lower::functions::src_text(lx_p0, &lx_p0.file, &x_p2.span)))), t_p5.clone()),
    }
}

/// The step machine of `DynamicBlueprint`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// DynamicBlueprint: unbounded fn Lx, Env, Expr, Expr, Text, OutTy -> Vl
/// ```
pub struct DynamicBlueprint {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub x_p2: crate::syntax::Expr,
    pub d_p3: crate::syntax::Expr,
    pub variant_p4: Text,
    pub t_p5: crate::lower::model::OutTy,
}

impl prism_rtl::Job<crate::lower::types::Vl> for DynamicBlueprint {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::types::Vl> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let x_p2 = &self.x_p2;
        let d_p3 = &self.d_p3;
        let variant_p4 = &self.variant_p4;
        let t_p5 = &self.t_p5;
        match (get(&env_p1.names, &Text::from(format!("#dyn{}", &crate::lower::node_::static_::dyn_key(x_p2)))), get(&env_p1.names, &Text::lit("#owner"))) {
            (Some(crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(getter_p6), _, dt_p7)), Some(crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(owner_p8), _, _))) => {
                let d_p3 = d_p3.clone();
                let env_p1 = env_p1.clone();
                let lx_p0 = lx_p0.clone();
                let t_p5 = t_p5.clone();
                let variant_p4 = variant_p4.clone();
                call_then(start_value_of(lx_p0.clone(), crate::lower::node_::def::init_env(&env_p1), d_p3.clone()), move |value_of_19212: crate::lower::types::Vl| {
                    let at_build_p9 = crate::lower::types::own(&value_of_19212);
                    let arms_pa = Array::from(vec![crate::lower::model::XArm { pat: crate::lower::model::Pa::PaCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("owner"))])), conds: Array::new(), body: crate::lower::model::Ex::XCtor(variant_p4.clone(), Array::from(vec![crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("owner"))), getter_p6.clone(), Array::from(vec![crate::lower::model::Ex::XCx]))])) }, crate::lower::model::XArm { pat: crate::lower::model::Pa::PaUnit(Text::lit("None")), conds: Array::new(), body: crate::lower::model::Ex::XCtor(variant_p4.clone(), Array::from(vec![crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(Text::lit("at_build"))))])) }]);
                    let read_pb = crate::lower::model::Ex::XClosure(true, Array::from(vec![crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaBind(Text::lit("cx"))), crate::lower::model::OutTy::OutRef(Rc::new(crate::lower::model::OutTy::OutNamed(Text::lit("Cx"), Array::new()))))]), Rc::new(crate::lower::model::Ex::XMatch(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("link"))), Text::lit("owner"), Array::new())), arms_pa.clone(), false, crate::lower::model::OutTy::OutNamed(Text::lit("crate::Answer"), Array::new()))));
                    let dynamic_pc = crate::lower::model::Ex::XBlock(Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(Text::lit("link")), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(owner_p8.clone())))), crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(Text::lit("at_build")), at_build_p9.clone())]), Rc::new(crate::lower::model::Ex::XCall(Text::lit("prism_rtl::Dynamic::of"), Array::from(vec![read_pb.clone(), crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XVar(Text::from(format!("{}_port", &getter_p6)))))]))));
                    prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCall(Text::lit("prism_rtl::dynamic_blueprint::<crate::Elem, _>"), Array::from(vec![dynamic_pc.clone()])), t_p5.clone()))
                })
            },
            _ => prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(refusal(&Text::from(format!("`@ {}`, a supplier\'s dynamic answer that reads what has no value at the owner\'s build (a pushed place, a structural dynamic, or a `let` after the host\'s line)", &crate::lower::functions::src_text(lx_p0, &lx_p0.file, &x_p2.span)))), t_p5.clone())),
        }
    }
}

/// `Start DynamicBlueprint, x`: what the function value is when passed to `@Run`.
pub fn start_dynamic_blueprint_(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, x_p2: crate::syntax::Expr, d_p3: crate::syntax::Expr, variant_p4: Text, t_p5: crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<crate::lower::types::Vl>> {
    Rc::new(DynamicBlueprint { lx_p0, env_p1, x_p2, d_p3, variant_p4, t_p5 })
}

/// ```prism
/// ElementBlueprint: unbounded fn Lx, Env, [Arg], OutTy -> Vl
/// ```
pub fn element_blueprint_(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, args_p2: &Array<crate::syntax::Arg>, t_p3: &crate::lower::model::OutTy) -> crate::lower::types::Vl {
    match index(args_p2, &Nat::from(0u32)) {
        Some(a_p4) => crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCall(Text::lit("prism_rtl::element_blueprint::<crate::Elem, crate::Answer>"), Array::from(vec![crate::lower::types::ref_(&value_of(lx_p0, env_p1, &a_p4.value))])), t_p3.clone()),
        None => crate::lower::types::Vl::VlOwned(refusal(&Text::lit("`@Element` without its element")), t_p3.clone()),
    }
}

/// The step machine of `ElementBlueprint`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ElementBlueprint: unbounded fn Lx, Env, [Arg], OutTy -> Vl
/// ```
pub struct ElementBlueprint {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub args_p2: Array<crate::syntax::Arg>,
    pub t_p3: crate::lower::model::OutTy,
}

impl prism_rtl::Job<crate::lower::types::Vl> for ElementBlueprint {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::types::Vl> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let args_p2 = &self.args_p2;
        let t_p3 = &self.t_p3;
        match index(args_p2, &Nat::from(0u32)) {
            Some(a_p4) => {
                let env_p1 = env_p1.clone();
                let lx_p0 = lx_p0.clone();
                let t_p3 = t_p3.clone();
                call_then(start_value_of(lx_p0.clone(), env_p1.clone(), a_p4.value.clone()), move |value_of_20495: crate::lower::types::Vl| prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCall(Text::lit("prism_rtl::element_blueprint::<crate::Elem, crate::Answer>"), Array::from(vec![crate::lower::types::ref_(&value_of_20495)])), t_p3.clone())))
            },
            None => prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(refusal(&Text::lit("`@Element` without its element")), t_p3.clone())),
        }
    }
}

/// `Start ElementBlueprint, x`: what the function value is when passed to `@Run`.
pub fn start_element_blueprint_(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, args_p2: Array<crate::syntax::Arg>, t_p3: crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<crate::lower::types::Vl>> {
    Rc::new(ElementBlueprint { lx_p0, env_p1, args_p2, t_p3 })
}

/// ```prism
/// KindWords: fn ExprKind -> Text
/// ```
pub fn kind_words(k_p0: &crate::syntax::ExprKind) -> Text {
    match k_p0 {
        crate::syntax::ExprKind::ESuffixed(op_p1, _, _, _) => Text::from(format!("a suffixed `{}`", op_p1)),
        crate::syntax::ExprKind::EFreeSigil(sg_p2, _) => Text::from(format!("a free `{}`", sg_p2)),
        crate::syntax::ExprKind::ETopicField(_) => Text::lit("a topic field (`&_.f` outside an `update`)"),
        crate::syntax::ExprKind::ETopicIndex(_) => Text::lit("a topic index"),
        crate::syntax::ExprKind::ENonEmpty(_) => Text::lit("a non-empty literal"),
        crate::syntax::ExprKind::EAbsent => Text::lit("an absent value"),
        crate::syntax::ExprKind::ERest => Text::lit("a `..` rest"),
        crate::syntax::ExprKind::ELambda(_, _) => Text::lit("a lambda"),
        crate::syntax::ExprKind::ERebuild(_, _) => Text::lit("a `rebuild` outside a widget block"),
        crate::syntax::ExprKind::EFor(_, _, _) => Text::lit("a `for` outside a widget block"),
        crate::syntax::ExprKind::EWidgetBlock(_) => Text::lit("a widget block"),
        crate::syntax::ExprKind::EMonad(_, _) => Text::lit("a monadic block"),
        crate::syntax::ExprKind::ELens(_) => Text::lit("a lens"),
        crate::syntax::ExprKind::EError => Text::lit("an expression the parser could not read"),
        _ => Text::lit("an expression"),
    }
}

/// ```prism
/// NameValue: unbounded fn Lx, Env, SName, Range -> Vl
/// ```
pub fn name_value(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, n_p2: &crate::syntax::SName, span_p3: &crate::syntax::Range) -> crate::lower::types::Vl {
    let nkey_p4 = crate::lower::types::name_key_at(lx_p0, env_p1, n_p2, span_p3);
    let t_p5 = crate::lower::types::out_ty_of(lx_p0, &crate::lower::types::peel(&crate::lower::type_at(lx_p0, span_p3)));
    let local_o6 = if &len(&n_p2.path_) == &Nat::from(1u32) { get(&env_p1.names, &nkey_p4) } else { None };
    match &local_o6 {
        Some(crate::lower::types::Bn::BnLocal(rs_p7, mode_p8, lt_p9)) => crate::lower::types::local_place(rs_p7, mode_p8, lt_p9),
        Some(crate::lower::types::Bn::BnHold(f_pa, ht_pb)) => crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", f_pa)))), Text::lit("get"), Array::from(vec![crate::lower::model::Ex::XCx])), ht_pb.clone()),
        Some(crate::lower::types::Bn::BnDyn(x_pc, _, dt_pd)) => crate::lower::types::Vl::VlOwned(x_pc.clone(), dt_pd.clone()),
        Some(crate::lower::types::Bn::BnEv(_, et_pe)) => match get(&env_p1.names, &Text::from(format!("{}#port", &nkey_p4))) {
            Some(crate::lower::types::Bn::BnLocal(pf_pf, _, _)) => crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCall(Text::lit("prism_rtl::Event::of"), Array::from(vec![crate::lower::model::Ex::XRef(Rc::new(pf_pf))])), crate::lower::model::OutTy::OutEvent(Rc::new(crate::lower::types::out_ty_of(lx_p0, &crate::lower::types::peel(&crate::lower::types::peel(&crate::lower::type_at(lx_p0, span_p3))))))),
            _ => crate::lower::types::Vl::VlOwned(refusal(&Text::lit("an event read as a value")), et_pe.clone()),
        },
        Some(crate::lower::types::Bn::BnParts(_)) => crate::lower::types::Vl::VlOwned(refusal(&Text::lit("a tuple pattern\'s binding as a value")), t_p5.clone()),
        Some(crate::lower::types::Bn::BnWidget(_, _, _, _)) => crate::lower::types::Vl::VlOwned(refusal(&Text::lit("a widget parameter read as a plain value")), t_p5.clone()),
        Some(crate::lower::types::Bn::BnLocalFn(_)) => crate::lower::types::Vl::VlOwned(refusal(&Text::lit("a local function as a value")), t_p5.clone()),
        None => {
            let (qk_og, why_ph) = crate::check::env::names::resolve_value(&lx_p0.g, &lx_p0.home, n_p2);
            match &qk_og {
                Some(m22571_0) if (m22571_0 == &Text::lit("True")) => crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XBool(true), crate::lower::model::OutTy::OutBool),
                Some(m22571_1) if (m22571_1 == &Text::lit("False")) => crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XBool(false), crate::lower::model::OutTy::OutBool),
                Some(m22571_2) if (m22571_2 == &Text::lit("Prelude.never")) => crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCall(Text::lit("Event::never"), Array::new()), t_p5.clone()),
                Some(qk_pi) => match get(&lx_p0.g.tags, qk_pi) {
                    Some(tg_pj) if ((&tg_pj.kind != &Text::lit("Prelude.Fault")) && (&why_ph == &Text::lit("tag"))) => tag_value(lx_p0, env_p1, &tg_pj, &Array::new()),
                    _ => global_value(lx_p0, qk_pi, span_p3, &t_p5),
                    _ => unreachable!("no arm matched"),
                },
                None => crate::lower::types::Vl::VlOwned(refusal(&Text::from(format!("the name {}, which nothing declares", &nkey_p4))), t_p5.clone()),
                _ => unreachable!("no arm matched"),
            }
        },
    }
}

/// The step machine of `NameValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// NameValue: unbounded fn Lx, Env, SName, Range -> Vl
/// ```
pub struct NameValue {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub n_p2: crate::syntax::SName,
    pub span_p3: crate::syntax::Range,
}

impl prism_rtl::Job<crate::lower::types::Vl> for NameValue {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::types::Vl> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let n_p2 = &self.n_p2;
        let span_p3 = &self.span_p3;
        let nkey_p4 = crate::lower::types::name_key_at(lx_p0, env_p1, n_p2, span_p3);
        let env_p1 = env_p1.clone();
        let lx_p0 = lx_p0.clone();
        let n_p2 = n_p2.clone();
        let span_p3 = span_p3.clone();
        call_then(crate::lower::types::start_out_ty_of(lx_p0.clone(), crate::lower::types::peel(&crate::lower::type_at(&lx_p0, &span_p3))), move |out_ty_of_21601: crate::lower::model::OutTy| {
            let t_p5 = out_ty_of_21601;
            let local_o6 = if &len(&n_p2.path_) == &Nat::from(1u32) { get(&env_p1.names, &nkey_p4) } else { None };
            match &local_o6 {
                Some(crate::lower::types::Bn::BnLocal(rs_p7, mode_p8, lt_p9)) => prism_rtl::Turn::Finished(crate::lower::types::local_place(rs_p7, mode_p8, lt_p9)),
                Some(crate::lower::types::Bn::BnHold(f_pa, ht_pb)) => prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", f_pa)))), Text::lit("get"), Array::from(vec![crate::lower::model::Ex::XCx])), ht_pb.clone())),
                Some(crate::lower::types::Bn::BnDyn(x_pc, _, dt_pd)) => prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(x_pc.clone(), dt_pd.clone())),
                Some(crate::lower::types::Bn::BnEv(_, et_pe)) => match get(&env_p1.names, &Text::from(format!("{}#port", &nkey_p4))) {
                    Some(crate::lower::types::Bn::BnLocal(pf_pf, _, _)) => call_then(crate::lower::types::start_out_ty_of(lx_p0.clone(), crate::lower::types::peel(&crate::lower::types::peel(&crate::lower::type_at(&lx_p0, &span_p3)))), move |out_ty_of_22081: crate::lower::model::OutTy| prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCall(Text::lit("prism_rtl::Event::of"), Array::from(vec![crate::lower::model::Ex::XRef(Rc::new(pf_pf.clone()))])), crate::lower::model::OutTy::OutEvent(Rc::new(out_ty_of_22081))))),
                    _ => prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(refusal(&Text::lit("an event read as a value")), et_pe.clone())),
                },
                Some(crate::lower::types::Bn::BnParts(_)) => prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(refusal(&Text::lit("a tuple pattern\'s binding as a value")), t_p5.clone())),
                Some(crate::lower::types::Bn::BnWidget(_, _, _, _)) => prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(refusal(&Text::lit("a widget parameter read as a plain value")), t_p5.clone())),
                Some(crate::lower::types::Bn::BnLocalFn(_)) => prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(refusal(&Text::lit("a local function as a value")), t_p5.clone())),
                None => {
                    let (qk_og, why_ph) = crate::check::env::names::resolve_value(&lx_p0.g, &lx_p0.home, &n_p2);
                    match &qk_og {
                        Some(m22571_0) if (m22571_0 == &Text::lit("True")) => prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XBool(true), crate::lower::model::OutTy::OutBool)),
                        Some(m22571_1) if (m22571_1 == &Text::lit("False")) => prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XBool(false), crate::lower::model::OutTy::OutBool)),
                        Some(m22571_2) if (m22571_2 == &Text::lit("Prelude.never")) => prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCall(Text::lit("Event::never"), Array::new()), t_p5.clone())),
                        Some(qk_pi) => match get(&lx_p0.g.tags, qk_pi) {
                            Some(tg_pj) if ((&tg_pj.kind != &Text::lit("Prelude.Fault")) && (&why_ph == &Text::lit("tag"))) => prism_rtl::Turn::More(Rc::new(TagValue { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), tg_p2: tg_pj.clone(), args_p3: Array::new() })),
                            _ => prism_rtl::Turn::More(Rc::new(GlobalValue { lx_p0: lx_p0.clone(), qk_p1: qk_pi.clone(), span_p2: span_p3.clone(), t_p3: t_p5.clone() })),
                            _ => unreachable!("no arm matched"),
                        },
                        None => prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(refusal(&Text::from(format!("the name {}, which nothing declares", &nkey_p4))), t_p5.clone())),
                        _ => unreachable!("no arm matched"),
                    }
                },
            }
        })
    }
}

/// `Start NameValue, x`: what the function value is when passed to `@Run`.
pub fn start_name_value(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, n_p2: crate::syntax::SName, span_p3: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<crate::lower::types::Vl>> {
    Rc::new(NameValue { lx_p0, env_p1, n_p2, span_p3 })
}

/// ```prism
/// GlobalValue: unbounded fn Lx, Text, Range, OutTy -> Vl
/// ```
pub fn global_value(lx_p0: &crate::lower::Lx, qk_p1: &Text, span_p2: &crate::syntax::Range, t_p3: &crate::lower::model::OutTy) -> crate::lower::types::Vl {
    match get(&lx_p0.g.ctors, qk_p1) {
        Some(c_p4) => {
            let arity_p5 = if &len(&c_p4.fields) > &Nat::from(0u32) { len(&c_p4.fields) } else { len(&c_p4.args) };
            match t_p3 {
                crate::lower::model::OutTy::OutFn(pts_p6, _) => if &arity_p5 > &Nat::from(0u32) {
                    ctor_fn(lx_p0, &c_p4, pts_p6, span_p2, t_p3, &false)
                } else {
                    ctor_app(lx_p0, &crate::lower::types::empty_env(), &c_p4, &Array::new(), span_p2)
                },
                crate::lower::model::OutTy::OutJobFn(a_p7, _) => {
                    let pts_p8 = match &**a_p7 {
                        crate::lower::model::OutTy::OutTuple(ts_p9) => if &arity_p5 == &Nat::from(1u32) {
                            Array::from(vec![(**a_p7).clone()])
                        } else {
                            ts_p9.clone()
                        },
                        _ => Array::from(vec![(**a_p7).clone()]),
                    };
                    if &arity_p5 > &Nat::from(0u32) {
                        ctor_fn(lx_p0, &c_p4, &pts_p8, span_p2, t_p3, &true)
                    } else {
                        ctor_app(lx_p0, &crate::lower::types::empty_env(), &c_p4, &Array::new(), span_p2)
                    }
                },
                _ => ctor_app(lx_p0, &crate::lower::types::empty_env(), &c_p4, &Array::new(), span_p2),
            }
        },
        None => match get(&lx_p0.g.tags, qk_p1) {
            Some(tg_pa) => crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XStr(tg_pa.name.clone()), t_p3.clone()),
            None => if fold(&lx_p0.g.defs, &false, &(|f_pb: &bool, d_pc: &crate::check::env::Def| *f_pb || ((&d_pc.qk == qk_p1) && is_let_def(d_pc)))) {
                crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCall(crate::lower::value_path(lx_p0, qk_p1), Array::new()), t_p3.clone())
            } else {
                match get(&lx_p0.g.vals, qk_p1) {
                    Some(v_pd) => {
                        let is_let_pe = fold(&lx_p0.g.defs, &false, &(|f_pf: &bool, d_pg: &crate::check::env::Def| *f_pf || ((&d_pg.qk == qk_p1) && is_let_def(d_pg))));
                        if is_let_pe {
                            crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCall(crate::lower::value_path(lx_p0, qk_p1), Array::new()), t_p3.clone())
                        } else {
                            match t_p3 {
                                crate::lower::model::OutTy::OutJobFn(a_ph, _) => {
                                    let (ps_pl, ignore2_pm) = crate::lower::jobs::scheme_parts(lx_p0, qk_p1);
                                    let names_pi = each(&crate::check::errors::range0(&len(&ps_pl)), &(|i_pn: &Nat| Text::from(format!("a{}", i_pn))));
                                    let pa_pj = if &len(&ps_pl) == &Nat::from(1u32) {
                                        crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaBind(Text::lit("a0"))), (**a_ph).clone())
                                    } else {
                                        crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaTuple(each(&names_pi, &(|nm_po: &Text| crate::lower::model::Pa::PaBind(nm_po.clone()))))), (**a_ph).clone())
                                    };
                                    let f_pk = crate::lower::model::Ex::XClosure(false, Array::from(vec![pa_pj.clone()]), Rc::new(crate::lower::model::Ex::XCall(Text::lit("entered"), Array::from(vec![crate::lower::model::Ex::XCall(start_path(lx_p0, qk_p1), each(&names_pi, &(|nm_pp: &Text| crate::lower::model::Ex::XVar(nm_pp.clone()))))]))));
                                    crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCast(Rc::new(crate::lower::model::Ex::XCall(Text::lit("Rc::new"), Array::from(vec![f_pk.clone()]))), t_p3.clone()), t_p3.clone())
                                },
                                _ => crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCall(Text::lit("Rc::new"), Array::from(vec![crate::lower::model::Ex::XPath(crate::lower::value_path(lx_p0, qk_p1))])), t_p3.clone()),
                            }
                        }
                    },
                    None => crate::lower::types::Vl::VlOwned(refusal(&Text::from(format!("the global {}", qk_p1))), t_p3.clone()),
                }
            },
        },
    }
}

/// The step machine of `GlobalValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// GlobalValue: unbounded fn Lx, Text, Range, OutTy -> Vl
/// ```
pub struct GlobalValue {
    pub lx_p0: crate::lower::Lx,
    pub qk_p1: Text,
    pub span_p2: crate::syntax::Range,
    pub t_p3: crate::lower::model::OutTy,
}

impl prism_rtl::Job<crate::lower::types::Vl> for GlobalValue {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::types::Vl> {
        let lx_p0 = &self.lx_p0;
        let qk_p1 = &self.qk_p1;
        let span_p2 = &self.span_p2;
        let t_p3 = &self.t_p3;
        match get(&lx_p0.g.ctors, qk_p1) {
            Some(c_p4) => {
                let arity_p5 = if &len(&c_p4.fields) > &Nat::from(0u32) { len(&c_p4.fields) } else { len(&c_p4.args) };
                match t_p3 {
                    crate::lower::model::OutTy::OutFn(pts_p6, _) => if &arity_p5 > &Nat::from(0u32) {
                        prism_rtl::Turn::More(Rc::new(CtorFn { lx_p0: lx_p0.clone(), c_p1: c_p4.clone(), pts_p2: pts_p6.clone(), span_p3: span_p2.clone(), t_p4: t_p3.clone(), job_p5: false }))
                    } else {
                        prism_rtl::Turn::More(Rc::new(CtorApp { lx_p0: lx_p0.clone(), env_p1: crate::lower::types::empty_env(), c_p2: c_p4.clone(), args_p3: Array::new(), span_p4: span_p2.clone() }))
                    },
                    crate::lower::model::OutTy::OutJobFn(a_p7, _) => {
                        let pts_p8 = match &**a_p7 {
                            crate::lower::model::OutTy::OutTuple(ts_p9) => if &arity_p5 == &Nat::from(1u32) {
                                Array::from(vec![(**a_p7).clone()])
                            } else {
                                ts_p9.clone()
                            },
                            _ => Array::from(vec![(**a_p7).clone()]),
                        };
                        if &arity_p5 > &Nat::from(0u32) {
                            prism_rtl::Turn::More(Rc::new(CtorFn { lx_p0: lx_p0.clone(), c_p1: c_p4.clone(), pts_p2: pts_p8.clone(), span_p3: span_p2.clone(), t_p4: t_p3.clone(), job_p5: true }))
                        } else {
                            prism_rtl::Turn::More(Rc::new(CtorApp { lx_p0: lx_p0.clone(), env_p1: crate::lower::types::empty_env(), c_p2: c_p4.clone(), args_p3: Array::new(), span_p4: span_p2.clone() }))
                        }
                    },
                    _ => prism_rtl::Turn::More(Rc::new(CtorApp { lx_p0: lx_p0.clone(), env_p1: crate::lower::types::empty_env(), c_p2: c_p4.clone(), args_p3: Array::new(), span_p4: span_p2.clone() })),
                }
            },
            None => match get(&lx_p0.g.tags, qk_p1) {
                Some(tg_pa) => prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XStr(tg_pa.name.clone()), t_p3.clone())),
                None => if fold(&lx_p0.g.defs, &false, &(|f_pb: &bool, d_pc: &crate::check::env::Def| *f_pb || ((&d_pc.qk == qk_p1) && is_let_def(d_pc)))) {
                    prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCall(crate::lower::value_path(lx_p0, qk_p1), Array::new()), t_p3.clone()))
                } else {
                    match get(&lx_p0.g.vals, qk_p1) {
                        Some(v_pd) => {
                            let is_let_pe = fold(&lx_p0.g.defs, &false, &(|f_pf: &bool, d_pg: &crate::check::env::Def| *f_pf || ((&d_pg.qk == qk_p1) && is_let_def(d_pg))));
                            if is_let_pe {
                                prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCall(crate::lower::value_path(lx_p0, qk_p1), Array::new()), t_p3.clone()))
                            } else {
                                match t_p3 {
                                    crate::lower::model::OutTy::OutJobFn(a_ph, _) => {
                                        let (ps_pl, ignore2_pm) = crate::lower::jobs::scheme_parts(lx_p0, qk_p1);
                                        let names_pi = each(&crate::check::errors::range0(&len(&ps_pl)), &(|i_pn: &Nat| Text::from(format!("a{}", i_pn))));
                                        let pa_pj = if &len(&ps_pl) == &Nat::from(1u32) {
                                            crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaBind(Text::lit("a0"))), (**a_ph).clone())
                                        } else {
                                            crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaTuple(each(&names_pi, &(|nm_po: &Text| crate::lower::model::Pa::PaBind(nm_po.clone()))))), (**a_ph).clone())
                                        };
                                        let f_pk = crate::lower::model::Ex::XClosure(false, Array::from(vec![pa_pj.clone()]), Rc::new(crate::lower::model::Ex::XCall(Text::lit("entered"), Array::from(vec![crate::lower::model::Ex::XCall(start_path(lx_p0, qk_p1), each(&names_pi, &(|nm_pp: &Text| crate::lower::model::Ex::XVar(nm_pp.clone()))))]))));
                                        prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCast(Rc::new(crate::lower::model::Ex::XCall(Text::lit("Rc::new"), Array::from(vec![f_pk.clone()]))), t_p3.clone()), t_p3.clone()))
                                    },
                                    _ => prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCall(Text::lit("Rc::new"), Array::from(vec![crate::lower::model::Ex::XPath(crate::lower::value_path(lx_p0, qk_p1))])), t_p3.clone())),
                                }
                            }
                        },
                        None => prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(refusal(&Text::from(format!("the global {}", qk_p1))), t_p3.clone())),
                    }
                },
            },
        }
    }
}

/// `Start GlobalValue, x`: what the function value is when passed to `@Run`.
pub fn start_global_value(lx_p0: crate::lower::Lx, qk_p1: Text, span_p2: crate::syntax::Range, t_p3: crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<crate::lower::types::Vl>> {
    Rc::new(GlobalValue { lx_p0, qk_p1, span_p2, t_p3 })
}

/// ```prism
/// IsLetDef: fn Def -> Bool
/// ```
pub fn is_let_def(d_p0: &crate::check::env::Def) -> bool {
    match &d_p0.body {
        crate::check::env::DefBody::DbLet(_) => true,
        _ => false,
    }
}

/// ```prism
/// StartPath: fn Lx, Text -> Text
/// ```
pub fn start_path(lx_p0: &crate::lower::Lx, qk_p1: &Text) -> Text {
    let owner_p2 = match get(&lx_p0.g.vals, qk_p1) {
        Some(v_p3) => v_p3.home.clone(),
        None => crate::lower::owner_of(qk_p1),
    };
    crate::lower::path_in(lx_p0, &owner_p2, &Text::from(format!("start_{}", &or(&get(&lx_p0.rs_names, qk_p1), &crate::lower::snake(&crate::check::types::bare_name(qk_p1))))))
}

/// ```prism
/// Application: unbounded fn Lx, Env, Expr, [Arg], Range -> Vl
/// ```
pub fn application(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, callee_p2: &crate::syntax::Expr, args_p3: &Array<crate::syntax::Arg>, span_p4: &crate::syntax::Range) -> crate::lower::types::Vl {
    let t_p5 = crate::lower::types::out_ty_of(lx_p0, &crate::lower::types::peel(&crate::lower::type_at(lx_p0, span_p4)));
    match &*callee_p2.kind {
        crate::syntax::ExprKind::EName(n_p6) => {
            let nkey_p7 = crate::lower::types::name_key_at(lx_p0, env_p1, n_p6, &callee_p2.span);
            let local_o8 = if &len(&n_p6.path_) == &Nat::from(1u32) { get(&env_p1.names, &nkey_p7) } else { None };
            match &local_o8 {
                Some(crate::lower::types::Bn::BnLocalFn(c_p9)) => inline_local_fn(lx_p0, env_p1, c_p9, args_p3, &t_p5),
                Some(b_pa) => {
                    let f_pb = name_value(lx_p0, env_p1, n_p6, &callee_p2.span);
                    match crate::lower::types::value_ty(&f_pb) {
                        crate::lower::model::OutTy::OutJobFn(_, _) => crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCall(Text::lit("run_to_end"), Array::from(vec![crate::lower::jobs::start_call(&f_pb, &start_args(lx_p0, env_p1, &f_pb, args_p3))])), t_p5.clone()),
                        _ => crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XApply(Rc::new(crate::lower::types::ref_(&f_pb)), run_to_end(each_job(args_p3.clone(), {
                            let lx_p0 = lx_p0.clone();
                            let env_p1 = env_p1.clone();
                            Rc::new(move |p0: crate::syntax::Arg| {
                                let lx_p0 = lx_p0.clone();
                                let env_p1 = env_p1.clone();
                                entered(once_job(move || {
                                    let a_pc = p0;
                                    prism_rtl::Turn::More(Rc::new(Argument { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), e_p2: a_pc.value.clone() }))
                                }))
                            }) as Rc<dyn Fn(crate::syntax::Arg) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
                        }))), t_p5.clone()),
                    }
                },
                None => {
                    let (qk_od, why_pe) = crate::check::env::names::resolve_value(&lx_p0.g, &lx_p0.home, n_p6);
                    match &qk_od {
                        Some(qk_pf) => match get(&lx_p0.g.tags, qk_pf) {
                            Some(tg_pg) if (&why_pe == &Text::lit("tag")) => tag_value(lx_p0, env_p1, &tg_pg, args_p3),
                            _ => if qk_pf == &Text::lit("Prelude.@Element") {
                                element_blueprint_(lx_p0, env_p1, args_p3, &t_p5)
                            } else {
                                global_call(lx_p0, env_p1, qk_pf, args_p3, span_p4, &t_p5)
                            },
                            _ => unreachable!("no arm matched"),
                        },
                        None => crate::lower::types::Vl::VlOwned(refusal(&Text::from(format!("a call of {}, which nothing declares", &nkey_p7))), t_p5.clone()),
                    }
                },
            }
        },
        crate::syntax::ExprKind::EGroup(x_ph) => application(lx_p0, env_p1, &**x_ph, args_p3, span_p4),
        _ => {
            let f_pi = value_of(lx_p0, env_p1, callee_p2);
            match crate::lower::types::value_ty(&f_pi) {
                crate::lower::model::OutTy::OutJobFn(_, _) => crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCall(Text::lit("run_to_end"), Array::from(vec![crate::lower::jobs::start_call(&f_pi, &start_args(lx_p0, env_p1, &f_pi, args_p3))])), t_p5.clone()),
                _ => crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XApply(Rc::new(crate::lower::types::ref_(&f_pi)), run_to_end(each_job(args_p3.clone(), {
                    let lx_p0 = lx_p0.clone();
                    let env_p1 = env_p1.clone();
                    Rc::new(move |p0: crate::syntax::Arg| {
                        let lx_p0 = lx_p0.clone();
                        let env_p1 = env_p1.clone();
                        entered(once_job(move || {
                            let a_pj = p0;
                            prism_rtl::Turn::More(Rc::new(Argument { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), e_p2: a_pj.value.clone() }))
                        }))
                    }) as Rc<dyn Fn(crate::syntax::Arg) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
                }))), t_p5.clone()),
            }
        },
    }
}

/// The step machine of `Application`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Application: unbounded fn Lx, Env, Expr, [Arg], Range -> Vl
/// ```
pub struct Application {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub callee_p2: crate::syntax::Expr,
    pub args_p3: Array<crate::syntax::Arg>,
    pub span_p4: crate::syntax::Range,
}

impl prism_rtl::Job<crate::lower::types::Vl> for Application {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::types::Vl> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let callee_p2 = &self.callee_p2;
        let args_p3 = &self.args_p3;
        let span_p4 = &self.span_p4;
        let args_p3 = args_p3.clone();
        let callee_p2 = callee_p2.clone();
        let env_p1 = env_p1.clone();
        let lx_p0 = lx_p0.clone();
        let span_p4 = span_p4.clone();
        call_then(crate::lower::types::start_out_ty_of(lx_p0.clone(), crate::lower::types::peel(&crate::lower::type_at(&lx_p0, &span_p4))), move |out_ty_of_25472: crate::lower::model::OutTy| {
            let t_p5 = out_ty_of_25472;
            match &*callee_p2.kind {
                crate::syntax::ExprKind::EName(n_p6) => {
                    let nkey_p7 = crate::lower::types::name_key_at(&lx_p0, &env_p1, n_p6, &callee_p2.span);
                    let local_o8 = if &len(&n_p6.path_) == &Nat::from(1u32) { get(&env_p1.names, &nkey_p7) } else { None };
                    match &local_o8 {
                        Some(crate::lower::types::Bn::BnLocalFn(c_p9)) => prism_rtl::Turn::More(Rc::new(InlineLocalFn { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), c_p2: c_p9.clone(), args_p3: args_p3.clone(), t_p4: t_p5.clone() })),
                        Some(b_pa) => {
                            let n_p6 = n_p6.clone();
                            call_then(start_name_value(lx_p0.clone(), env_p1.clone(), n_p6.clone(), callee_p2.span.clone()), move |name_value_25821: crate::lower::types::Vl| {
                                let f_pb = name_value_25821;
                                match crate::lower::types::value_ty(&f_pb) {
                                    crate::lower::model::OutTy::OutJobFn(_, _) => call_then(start_start_args(lx_p0.clone(), env_p1.clone(), f_pb.clone(), args_p3.clone()), move |start_args_26015: Array<crate::lower::model::Ex>| prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCall(Text::lit("run_to_end"), Array::from(vec![crate::lower::jobs::start_call(&f_pb, &start_args_26015)])), t_p5.clone()))),
                                    _ => call_value(each_job(args_p3.clone(), {
                                        let lx_p0 = lx_p0.clone();
                                        let env_p1 = env_p1.clone();
                                        Rc::new(move |p0: crate::syntax::Arg| {
                                            let lx_p0 = lx_p0.clone();
                                            let env_p1 = env_p1.clone();
                                            entered(once_job(move || {
                                                let a_pc = p0;
                                                prism_rtl::Turn::More(Rc::new(Argument { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), e_p2: a_pc.value.clone() }))
                                            }))
                                        }) as Rc<dyn Fn(crate::syntax::Arg) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
                                    }), move |each_26111: Array<crate::lower::model::Ex>| prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XApply(Rc::new(crate::lower::types::ref_(&f_pb)), each_26111), t_p5.clone()))),
                                }
                            })
                        },
                        None => {
                            let (qk_od, why_pe) = crate::check::env::names::resolve_value(&lx_p0.g, &lx_p0.home, n_p6);
                            match &qk_od {
                                Some(qk_pf) => match get(&lx_p0.g.tags, qk_pf) {
                                    Some(tg_pg) if (&why_pe == &Text::lit("tag")) => prism_rtl::Turn::More(Rc::new(TagValue { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), tg_p2: tg_pg.clone(), args_p3: args_p3.clone() })),
                                    _ => if qk_pf == &Text::lit("Prelude.@Element") {
                                        prism_rtl::Turn::More(Rc::new(ElementBlueprint { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), args_p2: args_p3.clone(), t_p3: t_p5.clone() }))
                                    } else {
                                        prism_rtl::Turn::More(Rc::new(GlobalCall { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), qk_p2: qk_pf.clone(), args_p3: args_p3.clone(), span_p4: span_p4.clone(), t_p5: t_p5.clone() }))
                                    },
                                    _ => unreachable!("no arm matched"),
                                },
                                None => prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(refusal(&Text::from(format!("a call of {}, which nothing declares", &nkey_p7))), t_p5.clone())),
                            }
                        },
                    }
                },
                crate::syntax::ExprKind::EGroup(x_ph) => prism_rtl::Turn::More(Rc::new(Application { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), callee_p2: (**x_ph).clone(), args_p3: args_p3.clone(), span_p4: span_p4.clone() })),
                _ => call_then(start_value_of(lx_p0.clone(), env_p1.clone(), callee_p2.clone()), move |value_of_26934: crate::lower::types::Vl| {
                    let f_pi = value_of_26934;
                    match crate::lower::types::value_ty(&f_pi) {
                        crate::lower::model::OutTy::OutJobFn(_, _) => call_then(start_start_args(lx_p0.clone(), env_p1.clone(), f_pi.clone(), args_p3.clone()), move |start_args_27074: Array<crate::lower::model::Ex>| prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCall(Text::lit("run_to_end"), Array::from(vec![crate::lower::jobs::start_call(&f_pi, &start_args_27074)])), t_p5.clone()))),
                        _ => call_value(each_job(args_p3.clone(), {
                            let lx_p0 = lx_p0.clone();
                            let env_p1 = env_p1.clone();
                            Rc::new(move |p0: crate::syntax::Arg| {
                                let lx_p0 = lx_p0.clone();
                                let env_p1 = env_p1.clone();
                                entered(once_job(move || {
                                    let a_pj = p0;
                                    prism_rtl::Turn::More(Rc::new(Argument { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), e_p2: a_pj.value.clone() }))
                                }))
                            }) as Rc<dyn Fn(crate::syntax::Arg) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
                        }), move |each_27162: Array<crate::lower::model::Ex>| prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XApply(Rc::new(crate::lower::types::ref_(&f_pi)), each_27162), t_p5.clone()))),
                    }
                }),
            }
        })
    }
}

/// `Start Application, x`: what the function value is when passed to `@Run`.
pub fn start_application(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, callee_p2: crate::syntax::Expr, args_p3: Array<crate::syntax::Arg>, span_p4: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<crate::lower::types::Vl>> {
    Rc::new(Application { lx_p0, env_p1, callee_p2, args_p3, span_p4 })
}

/// ```prism
/// InlineLocalFn: unbounded fn Lx, Env, FnClause, [Arg], OutTy -> Vl
/// ```
pub fn inline_local_fn(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, c_p2: &crate::syntax::decls::FnClause, args_p3: &Array<crate::syntax::Arg>, t_p4: &crate::lower::model::OutTy) -> crate::lower::types::Vl {
    let names_p5 = each(&c_p2.params, &(|p_p6: &crate::syntax::Pattern_| crate::lower::functions::plain_binder(lx_p0, p_p6)));
    if fold(&names_p5, &false, &(|bad_p7: &bool, nm_p8: &Text| *bad_p7 || (nm_p8 == &Text::lit("")))) {
        crate::lower::types::Vl::VlOwned(refusal(&Text::lit("a local function whose parameters are not names")), t_p4.clone())
    } else {
        {
            let (dos_ph, env2_pi) = run_to_end(fold_job(crate::check::errors::range0(&len(&names_p5)), (Array::new(), env_p1.clone()), {
                let names_p5 = names_p5.clone();
                let lx_p0 = lx_p0.clone();
                let c_p2 = c_p2.clone();
                let args_p3 = args_p3.clone();
                let env_p1 = env_p1.clone();
                Rc::new(move |(p0, p1): ((Array<crate::lower::model::Do>, crate::lower::types::Env), Nat)| {
                    let names_p5 = names_p5.clone();
                    let lx_p0 = lx_p0.clone();
                    let c_p2 = c_p2.clone();
                    let args_p3 = args_p3.clone();
                    let env_p1 = env_p1.clone();
                    entered(once_job(move || {
                        let (acc_p9, en_pa) = p0;
                        let i_pb = p1;
                        {
                            let nm_pc = or(&index(&names_p5, &i_pb), &Text::lit(""));
                            let rs_pd = Text::from(format!("{}_{}", &crate::lower::local_name(&lx_p0, &nm_pc), &c_p2.span.start));
                            let v_pe = match index(&args_p3, &i_pb) {
                                Some(a_pg) => value_of(&lx_p0, &env_p1, &a_pg.value),
                                None => crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XUnit, crate::lower::model::OutTy::OutUnit),
                            };
                            let bt_pf = crate::lower::types::value_ty(&v_pe);
                            prism_rtl::Turn::Finished((push(&acc_p9, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(rs_pd.clone()), crate::lower::types::own(&v_pe))), crate::lower::types::bind(&en_pa, &nm_pc, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(rs_pd.clone()), crate::lower::types::Holding::Owned, bt_pf.clone()))))
                        }
                    }))
                }) as Rc<dyn Fn(((Array<crate::lower::model::Do>, crate::lower::types::Env), Nat)) -> Rc<dyn prism_rtl::Job<(Array<crate::lower::model::Do>, crate::lower::types::Env)>>>
            }));
            crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XBlock(dos_ph.clone(), Rc::new(crate::lower::functions::fn_body_value(lx_p0, &env2_pi, &c_p2.body))), t_p4.clone())
        }
    }
}

/// The step machine of `InlineLocalFn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InlineLocalFn: unbounded fn Lx, Env, FnClause, [Arg], OutTy -> Vl
/// ```
pub struct InlineLocalFn {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub c_p2: crate::syntax::decls::FnClause,
    pub args_p3: Array<crate::syntax::Arg>,
    pub t_p4: crate::lower::model::OutTy,
}

impl prism_rtl::Job<crate::lower::types::Vl> for InlineLocalFn {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::types::Vl> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let c_p2 = &self.c_p2;
        let args_p3 = &self.args_p3;
        let t_p4 = &self.t_p4;
        let names_p5 = each(&c_p2.params, &(|p_p6: &crate::syntax::Pattern_| crate::lower::functions::plain_binder(lx_p0, p_p6)));
        if fold(&names_p5, &false, &(|bad_p7: &bool, nm_p8: &Text| *bad_p7 || (nm_p8 == &Text::lit("")))) {
            prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(refusal(&Text::lit("a local function whose parameters are not names")), t_p4.clone()))
        } else {
            {
                let args_p3 = args_p3.clone();
                let c_p2 = c_p2.clone();
                let env_p1 = env_p1.clone();
                let lx_p0 = lx_p0.clone();
                let t_p4 = t_p4.clone();
                call_value(fold_job(crate::check::errors::range0(&len(&names_p5)), (Array::new(), env_p1.clone()), {
                    let names_p5 = names_p5.clone();
                    let lx_p0 = lx_p0.clone();
                    let c_p2 = c_p2.clone();
                    let args_p3 = args_p3.clone();
                    let env_p1 = env_p1.clone();
                    Rc::new(move |(p0, p1): ((Array<crate::lower::model::Do>, crate::lower::types::Env), Nat)| {
                        let names_p5 = names_p5.clone();
                        let lx_p0 = lx_p0.clone();
                        let c_p2 = c_p2.clone();
                        let args_p3 = args_p3.clone();
                        let env_p1 = env_p1.clone();
                        entered(once_job(move || {
                            let (acc_p9, en_pa) = p0;
                            let i_pb = p1;
                            {
                                let nm_pc = or(&index(&names_p5, &i_pb), &Text::lit(""));
                                let rs_pd = Text::from(format!("{}_{}", &crate::lower::local_name(&lx_p0, &nm_pc), &c_p2.span.start));
                                let v_pe = match index(&args_p3, &i_pb) {
                                    Some(a_pg) => value_of(&lx_p0, &env_p1, &a_pg.value),
                                    None => crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XUnit, crate::lower::model::OutTy::OutUnit),
                                };
                                let bt_pf = crate::lower::types::value_ty(&v_pe);
                                prism_rtl::Turn::Finished((push(&acc_p9, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(rs_pd.clone()), crate::lower::types::own(&v_pe))), crate::lower::types::bind(&en_pa, &nm_pc, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(rs_pd.clone()), crate::lower::types::Holding::Owned, bt_pf.clone()))))
                            }
                        }))
                    }) as Rc<dyn Fn(((Array<crate::lower::model::Do>, crate::lower::types::Env), Nat)) -> Rc<dyn prism_rtl::Job<(Array<crate::lower::model::Do>, crate::lower::types::Env)>>>
                }), move |fold_27748: (Array<crate::lower::model::Do>, crate::lower::types::Env)| {
                    let (dos_ph, env2_pi) = fold_27748;
                    call_then(crate::lower::functions::start_fn_body_value(lx_p0.clone(), env2_pi.clone(), c_p2.body.clone()), move |fn_body_value_28194: crate::lower::model::Ex| prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XBlock(dos_ph.clone(), Rc::new(fn_body_value_28194)), t_p4.clone())))
                })
            }
        }
    }
}

/// `Start InlineLocalFn, x`: what the function value is when passed to `@Run`.
pub fn start_inline_local_fn(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, c_p2: crate::syntax::decls::FnClause, args_p3: Array<crate::syntax::Arg>, t_p4: crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<crate::lower::types::Vl>> {
    Rc::new(InlineLocalFn { lx_p0, env_p1, c_p2, args_p3, t_p4 })
}

/// ```prism
/// Argument: unbounded fn Lx, Env, Expr -> Ex
/// ```
pub fn argument(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, e_p2: &crate::syntax::Expr) -> crate::lower::model::Ex {
    match get(&env_p1.spans, &crate::lower::place_key(lx_p0, &e_p2.span)) {
        Some(v_p3) => crate::lower::types::ref_(&v_p3),
        None => argument_by_kind(lx_p0, env_p1, e_p2),
    }
}

/// The step machine of `Argument`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Argument: unbounded fn Lx, Env, Expr -> Ex
/// ```
pub struct Argument {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub e_p2: crate::syntax::Expr,
}

impl prism_rtl::Job<crate::lower::model::Ex> for Argument {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::Ex> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let e_p2 = &self.e_p2;
        match get(&env_p1.spans, &crate::lower::place_key(lx_p0, &e_p2.span)) {
            Some(v_p3) => prism_rtl::Turn::Finished(crate::lower::types::ref_(&v_p3)),
            None => prism_rtl::Turn::More(Rc::new(ArgumentByKind { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), e_p2: e_p2.clone() })),
        }
    }
}

/// `Start Argument, x`: what the function value is when passed to `@Run`.
pub fn start_argument(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, e_p2: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>> {
    Rc::new(Argument { lx_p0, env_p1, e_p2 })
}

/// ```prism
/// ArgumentByKind: unbounded fn Lx, Env, Expr -> Ex
/// ```
pub fn argument_by_kind(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, e_p2: &crate::syntax::Expr) -> crate::lower::model::Ex {
    match &*e_p2.kind {
        crate::syntax::ExprKind::ELambda(ps_o3, body_p4) => crate::lower::model::Ex::XRef(Rc::new(lambda_arg(lx_p0, env_p1, &or(ps_o3, &Array::new()), &**body_p4, &lambda_param_tys(lx_p0, e_p2, &len(&or(ps_o3, &Array::new())))))),
        crate::syntax::ExprKind::EGroup(x_p5) => argument(lx_p0, env_p1, &**x_p5),
        crate::syntax::ExprKind::EName(n_p6) => {
            let t_p7 = crate::lower::type_at(lx_p0, &e_p2.span);
            match crate::lower::types::peel(&t_p7) {
                crate::check::types::Ty::TyFn(crate::check::types::Col::CBound, _, _) => {
                    let local_o8 = if &len(&n_p6.path_) == &Nat::from(1u32) {
                        get(&env_p1.names, &crate::lower::types::name_key_at(lx_p0, env_p1, n_p6, &e_p2.span))
                    } else {
                        None
                    };
                    match &local_o8 {
                        Some(_) => closure_ref(&value_of(lx_p0, env_p1, e_p2)),
                        None => {
                            let (qk_o9, _) = crate::check::env::names::resolve_value(&lx_p0.g, &lx_p0.home, n_p6);
                            match &qk_o9 {
                                Some(qk_pa) => if crate::check::env::has_key(&lx_p0.g.ctors, qk_pa) {
                                    closure_ref(&value_of(lx_p0, env_p1, e_p2))
                                } else {
                                    crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XPath(crate::lower::value_path(lx_p0, qk_pa))))
                                },
                                None => crate::lower::types::ref_(&value_of(lx_p0, env_p1, e_p2)),
                            }
                        },
                    }
                },
                _ => crate::lower::types::ref_(&value_of(lx_p0, env_p1, e_p2)),
            }
        },
        _ => crate::lower::types::ref_(&value_of(lx_p0, env_p1, e_p2)),
    }
}

/// The step machine of `ArgumentByKind`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ArgumentByKind: unbounded fn Lx, Env, Expr -> Ex
/// ```
pub struct ArgumentByKind {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub e_p2: crate::syntax::Expr,
}

impl prism_rtl::Job<crate::lower::model::Ex> for ArgumentByKind {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::Ex> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let e_p2 = &self.e_p2;
        match &*e_p2.kind {
            crate::syntax::ExprKind::ELambda(ps_o3, body_p4) => {
                let ps_o3 = ps_o3.clone();
                let body_p4 = (**body_p4).clone();
                let e_p2 = e_p2.clone();
                let env_p1 = env_p1.clone();
                let lx_p0 = lx_p0.clone();
                call_then(start_lambda_param_tys(lx_p0.clone(), e_p2.clone(), len(&or(&ps_o3, &Array::new()))), move |lambda_param_tys_28632: Array<crate::lower::model::OutTy>| call_then(start_lambda_arg(lx_p0.clone(), env_p1.clone(), or(&ps_o3, &Array::new()), body_p4.clone(), lambda_param_tys_28632), move |lambda_arg_28590: crate::lower::model::Ex| prism_rtl::Turn::Finished(crate::lower::model::Ex::XRef(Rc::new(lambda_arg_28590)))))
            },
            crate::syntax::ExprKind::EGroup(x_p5) => prism_rtl::Turn::More(Rc::new(Argument { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), e_p2: (**x_p5).clone() })),
            crate::syntax::ExprKind::EName(n_p6) => {
                let t_p7 = crate::lower::type_at(lx_p0, &e_p2.span);
                match crate::lower::types::peel(&t_p7) {
                    crate::check::types::Ty::TyFn(crate::check::types::Col::CBound, _, _) => {
                        let local_o8 = if &len(&n_p6.path_) == &Nat::from(1u32) {
                            get(&env_p1.names, &crate::lower::types::name_key_at(lx_p0, env_p1, n_p6, &e_p2.span))
                        } else {
                            None
                        };
                        match &local_o8 {
                            Some(_) => {
                                let e_p2 = e_p2.clone();
                                let env_p1 = env_p1.clone();
                                let lx_p0 = lx_p0.clone();
                                call_then(start_value_of(lx_p0.clone(), env_p1.clone(), e_p2.clone()), move |value_of_28994: crate::lower::types::Vl| prism_rtl::Turn::Finished(closure_ref(&value_of_28994)))
                            },
                            None => {
                                let (qk_o9, _) = crate::check::env::names::resolve_value(&lx_p0.g, &lx_p0.home, n_p6);
                                match &qk_o9 {
                                    Some(qk_pa) => if crate::check::env::has_key(&lx_p0.g.ctors, qk_pa) {
                                        {
                                            let e_p2 = e_p2.clone();
                                            let env_p1 = env_p1.clone();
                                            let lx_p0 = lx_p0.clone();
                                            call_then(start_value_of(lx_p0.clone(), env_p1.clone(), e_p2.clone()), move |value_of_29222: crate::lower::types::Vl| prism_rtl::Turn::Finished(closure_ref(&value_of_29222)))
                                        }
                                    } else {
                                        prism_rtl::Turn::Finished(crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XPath(crate::lower::value_path(lx_p0, qk_pa)))))
                                    },
                                    None => {
                                        let e_p2 = e_p2.clone();
                                        let env_p1 = env_p1.clone();
                                        let lx_p0 = lx_p0.clone();
                                        call_then(start_value_of(lx_p0.clone(), env_p1.clone(), e_p2.clone()), move |value_of_29318: crate::lower::types::Vl| prism_rtl::Turn::Finished(crate::lower::types::ref_(&value_of_29318)))
                                    },
                                }
                            },
                        }
                    },
                    _ => {
                        let e_p2 = e_p2.clone();
                        let env_p1 = env_p1.clone();
                        let lx_p0 = lx_p0.clone();
                        call_then(start_value_of(lx_p0.clone(), env_p1.clone(), e_p2.clone()), move |value_of_29366: crate::lower::types::Vl| prism_rtl::Turn::Finished(crate::lower::types::ref_(&value_of_29366)))
                    },
                }
            },
            _ => {
                let e_p2 = e_p2.clone();
                let env_p1 = env_p1.clone();
                let lx_p0 = lx_p0.clone();
                call_then(start_value_of(lx_p0.clone(), env_p1.clone(), e_p2.clone()), move |value_of_29406: crate::lower::types::Vl| prism_rtl::Turn::Finished(crate::lower::types::ref_(&value_of_29406)))
            },
        }
    }
}

/// `Start ArgumentByKind, x`: what the function value is when passed to `@Run`.
pub fn start_argument_by_kind(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, e_p2: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>> {
    Rc::new(ArgumentByKind { lx_p0, env_p1, e_p2 })
}

/// ```prism
/// ClosureRef: fn Vl -> Ex
/// ```
pub fn closure_ref(vl0: &crate::lower::types::Vl) -> crate::lower::model::Ex {
    match vl0 {
        crate::lower::types::Vl::VlPlace(x_p0, crate::lower::types::Holding::ByRef, t_p1) => x_p0.clone(),
        crate::lower::types::Vl::VlPlace(x_p2, _, t_p3) => crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XDeref(Rc::new(x_p2.clone())))),
        crate::lower::types::Vl::VlOwned(x_p4, t_p5) => crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XDeref(Rc::new(x_p4.clone())))),
    }
}

/// ```prism
/// TagValue: unbounded fn Lx, Env, TagInfo, [Arg] -> Vl
/// ```
pub fn tag_value(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, tg_p2: &crate::check::env::TagInfo, args_p3: &Array<crate::syntax::Arg>) -> crate::lower::types::Vl {
    let (variant_p5, struct_path_p6) = crate::lower::program::tag_paths(lx_p0, tg_p2);
    let t_p4 = crate::lower::model::OutTy::OutNamed(crate::lower::program::kind_path(lx_p0, &tg_p2.kind), Array::new());
    match &tg_p2.kind {
        m30157_0 if (m30157_0 == &Text::lit("Element")) => crate::lower::types::Vl::VlOwned(refusal(&Text::from(format!("an element as a plain value ({}): a live element comes from its host", &tg_p2.name))), t_p4.clone()),
        m30157_1 if (m30157_1 == &Text::lit("Prelude.Fault")) => crate::lower::types::Vl::VlOwned(refusal(&Text::from(format!("a fault kind applied ({})", &tg_p2.name))), t_p4.clone()),
        _ => {
            let named_p7 = fold(args_p3, &false, &(|f_p9: &bool, a_pa: &crate::syntax::Arg| *f_p9 || is_named_arg(a_pa)));
            let fields_p8 = run_to_end(each_job(crate::check::errors::range0(&len(&tg_p2.fields)), {
                let tg_p2 = tg_p2.clone();
                let named_p7 = named_p7;
                let args_p3 = args_p3.clone();
                let lx_p0 = lx_p0.clone();
                let env_p1 = env_p1.clone();
                Rc::new(move |p0: Nat| {
                    let tg_p2 = tg_p2.clone();
                    let named_p7 = named_p7;
                    let args_p3 = args_p3.clone();
                    let lx_p0 = lx_p0.clone();
                    let env_p1 = env_p1.clone();
                    entered(once_job(move || {
                        let i_pb = p0;
                        {
                            let (fname_pe, _) = or(&index(&tg_p2.fields, &i_pb), &(Text::lit(""), crate::check::types::Ty::TyErr));
                            let arg_oc = if named_p7 {
                                crate::lower::node_::elements::tag_arg(&args_p3, &fname_pe)
                            } else {
                                match index(&args_p3, &i_pb) {
                                    Some(a_pf) => Some(a_pf.value.clone()),
                                    None => None,
                                }
                            };
                            let v_pd = match &arg_oc {
                                Some(x_pg) => crate::lower::types::own(&value_of(&lx_p0, &env_p1, x_pg)),
                                None => crate::lower::model::Ex::XCall(Text::lit("Default::default"), Array::new()),
                            };
                            prism_rtl::Turn::Finished((crate::lower::snake(&fname_pe), v_pd.clone()))
                        }
                    }))
                }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<(Text, crate::lower::model::Ex)>>>
            }));
            crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCtor(variant_p5.clone(), Array::from(vec![crate::lower::model::Ex::XRecord(struct_path_p6.clone(), fields_p8.clone())])), t_p4.clone())
        },
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `TagValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TagValue: unbounded fn Lx, Env, TagInfo, [Arg] -> Vl
/// ```
pub struct TagValue {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub tg_p2: crate::check::env::TagInfo,
    pub args_p3: Array<crate::syntax::Arg>,
}

impl prism_rtl::Job<crate::lower::types::Vl> for TagValue {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::types::Vl> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let tg_p2 = &self.tg_p2;
        let args_p3 = &self.args_p3;
        let (variant_p5, struct_path_p6) = crate::lower::program::tag_paths(lx_p0, tg_p2);
        let t_p4 = crate::lower::model::OutTy::OutNamed(crate::lower::program::kind_path(lx_p0, &tg_p2.kind), Array::new());
        match &tg_p2.kind {
            m30157_0 if (m30157_0 == &Text::lit("Element")) => prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(refusal(&Text::from(format!("an element as a plain value ({}): a live element comes from its host", &tg_p2.name))), t_p4.clone())),
            m30157_1 if (m30157_1 == &Text::lit("Prelude.Fault")) => prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(refusal(&Text::from(format!("a fault kind applied ({})", &tg_p2.name))), t_p4.clone())),
            _ => {
                let named_p7 = fold(args_p3, &false, &(|f_p9: &bool, a_pa: &crate::syntax::Arg| *f_p9 || is_named_arg(a_pa)));
                let args_p3 = args_p3.clone();
                let env_p1 = env_p1.clone();
                let lx_p0 = lx_p0.clone();
                let tg_p2 = tg_p2.clone();
                call_value(each_job(crate::check::errors::range0(&len(&tg_p2.fields)), {
                    let tg_p2 = tg_p2.clone();
                    let named_p7 = named_p7;
                    let args_p3 = args_p3.clone();
                    let lx_p0 = lx_p0.clone();
                    let env_p1 = env_p1.clone();
                    Rc::new(move |p0: Nat| {
                        let tg_p2 = tg_p2.clone();
                        let named_p7 = named_p7;
                        let args_p3 = args_p3.clone();
                        let lx_p0 = lx_p0.clone();
                        let env_p1 = env_p1.clone();
                        entered(once_job(move || {
                            let i_pb = p0;
                            {
                                let (fname_pe, _) = or(&index(&tg_p2.fields, &i_pb), &(Text::lit(""), crate::check::types::Ty::TyErr));
                                let arg_oc = if named_p7 {
                                    crate::lower::node_::elements::tag_arg(&args_p3, &fname_pe)
                                } else {
                                    match index(&args_p3, &i_pb) {
                                        Some(a_pf) => Some(a_pf.value.clone()),
                                        None => None,
                                    }
                                };
                                let v_pd = match &arg_oc {
                                    Some(x_pg) => crate::lower::types::own(&value_of(&lx_p0, &env_p1, x_pg)),
                                    None => crate::lower::model::Ex::XCall(Text::lit("Default::default"), Array::new()),
                                };
                                prism_rtl::Turn::Finished((crate::lower::snake(&fname_pe), v_pd.clone()))
                            }
                        }))
                    }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<(Text, crate::lower::model::Ex)>>>
                }), move |each_30483: Array<(Text, crate::lower::model::Ex)>| {
                    let fields_p8 = each_30483;
                    prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCtor(variant_p5.clone(), Array::from(vec![crate::lower::model::Ex::XRecord(struct_path_p6.clone(), fields_p8.clone())])), t_p4.clone()))
                })
            },
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start TagValue, x`: what the function value is when passed to `@Run`.
pub fn start_tag_value(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, tg_p2: crate::check::env::TagInfo, args_p3: Array<crate::syntax::Arg>) -> Rc<dyn prism_rtl::Job<crate::lower::types::Vl>> {
    Rc::new(TagValue { lx_p0, env_p1, tg_p2, args_p3 })
}

/// ```prism
/// GlobalCall: unbounded fn Lx, Env, Text, [Arg], Range, OutTy -> Vl
/// ```
pub fn global_call(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, qk_p2: &Text, args_p3: &Array<crate::syntax::Arg>, span_p4: &crate::syntax::Range, t_p5: &crate::lower::model::OutTy) -> crate::lower::types::Vl {
    match get(&lx_p0.g.ctors, qk_p2) {
        Some(c_p6) => ctor_app(lx_p0, env_p1, &c_p6, args_p3, span_p4),
        None => match get(&lx_p0.g.vals, qk_p2) {
            Some(v_p7) => if &v_p7.sort == &Text::lit("method") {
                method_call(lx_p0, env_p1, &v_p7, args_p3, span_p4, t_p5)
            } else {
                if &v_p7.home == &Text::lit("Prelude") {
                    prelude_call(lx_p0, env_p1, qk_p2, args_p3, span_p4, t_p5)
                } else {
                    as_instance(&crate::lower::model::Ex::XCall(crate::lower::value_path(lx_p0, qk_p2), args_for(lx_p0, env_p1, &v_p7, args_p3)), &result_repr(lx_p0, &v_p7), t_p5)
                }
            },
            None => crate::lower::types::Vl::VlOwned(refusal(&Text::from(format!("a call of {}", qk_p2))), t_p5.clone()),
        },
    }
}

/// The step machine of `GlobalCall`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// GlobalCall: unbounded fn Lx, Env, Text, [Arg], Range, OutTy -> Vl
/// ```
pub struct GlobalCall {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub qk_p2: Text,
    pub args_p3: Array<crate::syntax::Arg>,
    pub span_p4: crate::syntax::Range,
    pub t_p5: crate::lower::model::OutTy,
}

impl prism_rtl::Job<crate::lower::types::Vl> for GlobalCall {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::types::Vl> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let qk_p2 = &self.qk_p2;
        let args_p3 = &self.args_p3;
        let span_p4 = &self.span_p4;
        let t_p5 = &self.t_p5;
        match get(&lx_p0.g.ctors, qk_p2) {
            Some(c_p6) => prism_rtl::Turn::More(Rc::new(CtorApp { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), c_p2: c_p6.clone(), args_p3: args_p3.clone(), span_p4: span_p4.clone() })),
            None => match get(&lx_p0.g.vals, qk_p2) {
                Some(v_p7) => if &v_p7.sort == &Text::lit("method") {
                    prism_rtl::Turn::More(Rc::new(MethodCall { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), v_p2: v_p7.clone(), args_p3: args_p3.clone(), span_p4: span_p4.clone(), t_p5: t_p5.clone() }))
                } else {
                    if &v_p7.home == &Text::lit("Prelude") {
                        prism_rtl::Turn::More(Rc::new(PreludeCall { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), qk_p2: qk_p2.clone(), args_p3: args_p3.clone(), span_p4: span_p4.clone(), t_p5: t_p5.clone() }))
                    } else {
                        {
                            let args_p3 = args_p3.clone();
                            let env_p1 = env_p1.clone();
                            let lx_p0 = lx_p0.clone();
                            let qk_p2 = qk_p2.clone();
                            let t_p5 = t_p5.clone();
                            call_then(start_args_for(lx_p0.clone(), env_p1.clone(), v_p7.clone(), args_p3.clone()), move |args_for_31526: Array<crate::lower::model::Ex>| call_then(start_result_repr(lx_p0.clone(), v_p7.clone()), move |result_repr_31555: crate::lower::model::OutTy| prism_rtl::Turn::More(Rc::new(AsInstance { call_p0: crate::lower::model::Ex::XCall(crate::lower::value_path(&lx_p0, &qk_p2), args_for_31526), declared_p1: result_repr_31555, t_p2: t_p5.clone() }))))
                        }
                    }
                },
                None => prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(refusal(&Text::from(format!("a call of {}", qk_p2))), t_p5.clone())),
            },
        }
    }
}

/// `Start GlobalCall, x`: what the function value is when passed to `@Run`.
pub fn start_global_call(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, qk_p2: Text, args_p3: Array<crate::syntax::Arg>, span_p4: crate::syntax::Range, t_p5: crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<crate::lower::types::Vl>> {
    Rc::new(GlobalCall { lx_p0, env_p1, qk_p2, args_p3, span_p4, t_p5 })
}

/// ```prism
/// ResultRepr: unbounded fn Lx, ValInfo -> OutTy
/// ```
pub fn result_repr(lx_p0: &crate::lower::Lx, v_p1: &crate::check::env::ValInfo) -> crate::lower::model::OutTy {
    match &v_p1.scheme.ty {
        crate::check::types::Ty::TyFn(_, _, r_p2) => crate::lower::types::out_ty_of(lx_p0, &crate::lower::types::peel(&**r_p2)),
        other_p3 => crate::lower::types::out_ty_of(lx_p0, &crate::lower::types::peel(other_p3)),
    }
}

/// The step machine of `ResultRepr`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ResultRepr: unbounded fn Lx, ValInfo -> OutTy
/// ```
pub struct ResultRepr {
    pub lx_p0: crate::lower::Lx,
    pub v_p1: crate::check::env::ValInfo,
}

impl prism_rtl::Job<crate::lower::model::OutTy> for ResultRepr {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::OutTy> {
        let lx_p0 = &self.lx_p0;
        let v_p1 = &self.v_p1;
        match &v_p1.scheme.ty {
            crate::check::types::Ty::TyFn(_, _, r_p2) => prism_rtl::Turn::More(Rc::new(crate::lower::types::OutTyOf { lx_p0: lx_p0.clone(), t_p1: crate::lower::types::peel(&**r_p2) })),
            other_p3 => prism_rtl::Turn::More(Rc::new(crate::lower::types::OutTyOf { lx_p0: lx_p0.clone(), t_p1: crate::lower::types::peel(other_p3) })),
        }
    }
}

/// `Start ResultRepr, x`: what the function value is when passed to `@Run`.
pub fn start_result_repr(lx_p0: crate::lower::Lx, v_p1: crate::check::env::ValInfo) -> Rc<dyn prism_rtl::Job<crate::lower::model::OutTy>> {
    Rc::new(ResultRepr { lx_p0, v_p1 })
}

/// ```prism
/// AsInstance: unbounded fn Ex, OutTy, OutTy -> Vl
/// ```
pub fn as_instance(call_p0: &crate::lower::model::Ex, declared_p1: &crate::lower::model::OutTy, t_p2: &crate::lower::model::OutTy) -> crate::lower::types::Vl {
    match (declared_p1.clone(), t_p2.clone()) {
        (crate::lower::model::OutTy::OutJobFn(_, _), crate::lower::model::OutTy::OutFn(pts_p3, _)) => crate::lower::types::Vl::VlOwned(wrap_as_bounded(call_p0, &pts_p3, t_p2), t_p2.clone()),
        _ => if has_job_fn(declared_p1) && !has_job_fn(t_p2) {
            crate::lower::types::Vl::VlOwned(refusal(&Text::lit("a function value of its callee\'s own color inside the value a call returns, at a call that makes the color bounded")), t_p2.clone())
        } else {
            crate::lower::types::Vl::VlOwned(call_p0.clone(), t_p2.clone())
        },
    }
}

/// The step machine of `AsInstance`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// AsInstance: unbounded fn Ex, OutTy, OutTy -> Vl
/// ```
pub struct AsInstance {
    pub call_p0: crate::lower::model::Ex,
    pub declared_p1: crate::lower::model::OutTy,
    pub t_p2: crate::lower::model::OutTy,
}

impl prism_rtl::Job<crate::lower::types::Vl> for AsInstance {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::types::Vl> {
        let call_p0 = &self.call_p0;
        let declared_p1 = &self.declared_p1;
        let t_p2 = &self.t_p2;
        match (declared_p1.clone(), t_p2.clone()) {
            (crate::lower::model::OutTy::OutJobFn(_, _), crate::lower::model::OutTy::OutFn(pts_p3, _)) => prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(wrap_as_bounded(call_p0, &pts_p3, t_p2), t_p2.clone())),
            _ => {
                let call_p0 = call_p0.clone();
                let declared_p1 = declared_p1.clone();
                let t_p2 = t_p2.clone();
                call_then(start_has_job_fn(declared_p1.clone()), move |has_job_fn_32542: bool| if has_job_fn_32542 && !has_job_fn(&t_p2) {
                    prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(refusal(&Text::lit("a function value of its callee\'s own color inside the value a call returns, at a call that makes the color bounded")), t_p2.clone()))
                } else {
                    prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(call_p0.clone(), t_p2.clone()))
                })
            },
        }
    }
}

/// `Start AsInstance, x`: what the function value is when passed to `@Run`.
pub fn start_as_instance(call_p0: crate::lower::model::Ex, declared_p1: crate::lower::model::OutTy, t_p2: crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<crate::lower::types::Vl>> {
    Rc::new(AsInstance { call_p0, declared_p1, t_p2 })
}

/// ```prism
/// HasJobFn: unbounded fn OutTy -> Bool
/// ```
pub fn has_job_fn(t_p0: &crate::lower::model::OutTy) -> bool {
    match t_p0 {
        crate::lower::model::OutTy::OutJobFn(_, _) => true,
        crate::lower::model::OutTy::OutOpt(i_p1) => has_job_fn(&**i_p1),
        crate::lower::model::OutTy::OutRes(i_p2) => has_job_fn(&**i_p2),
        crate::lower::model::OutTy::OutArray(i_p3) => has_job_fn(&**i_p3),
        crate::lower::model::OutTy::OutMap(k_p4, v_p5) => has_job_fn(&**k_p4) || has_job_fn(&**v_p5),
        crate::lower::model::OutTy::OutTuple(ts_p6) => run_to_end(fold_job(ts_p6.clone(), false, Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| entered(once_job(move || {
            let f_p7 = p0;
            let x_p8 = p1;
            prism_rtl::Turn::Finished(f_p7 || has_job_fn(&x_p8))
        }))) as Rc<dyn Fn((bool, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<bool>>>)),
        crate::lower::model::OutTy::OutNamed(_, ts_p9) => run_to_end(fold_job(ts_p9.clone(), false, Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| entered(once_job(move || {
            let f_pa = p0;
            let x_pb = p1;
            prism_rtl::Turn::Finished(f_pa || has_job_fn(&x_pb))
        }))) as Rc<dyn Fn((bool, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<bool>>>)),
        crate::lower::model::OutTy::OutFn(ps_pc, r_pd) => run_to_end(fold_job(ps_pc.clone(), has_job_fn(&**r_pd), Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| entered(once_job(move || {
            let f_pe = p0;
            let x_pf = p1;
            prism_rtl::Turn::Finished(f_pe || has_job_fn(&x_pf))
        }))) as Rc<dyn Fn((bool, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<bool>>>)),
        _ => false,
    }
}

/// The step machine of `HasJobFn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// HasJobFn: unbounded fn OutTy -> Bool
/// ```
pub struct HasJobFn {
    pub t_p0: crate::lower::model::OutTy,
}

impl prism_rtl::Job<bool> for HasJobFn {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let t_p0 = &self.t_p0;
        match t_p0 {
            crate::lower::model::OutTy::OutJobFn(_, _) => prism_rtl::Turn::Finished(true),
            crate::lower::model::OutTy::OutOpt(i_p1) => prism_rtl::Turn::More(Rc::new(HasJobFn { t_p0: (**i_p1).clone() })),
            crate::lower::model::OutTy::OutRes(i_p2) => prism_rtl::Turn::More(Rc::new(HasJobFn { t_p0: (**i_p2).clone() })),
            crate::lower::model::OutTy::OutArray(i_p3) => prism_rtl::Turn::More(Rc::new(HasJobFn { t_p0: (**i_p3).clone() })),
            crate::lower::model::OutTy::OutMap(k_p4, v_p5) => {
                let k_p4 = (**k_p4).clone();
                let v_p5 = (**v_p5).clone();
                call_then(start_has_job_fn(k_p4.clone()), move |has_job_fn_32943: bool| prism_rtl::Turn::Finished(has_job_fn_32943 || has_job_fn(&v_p5)))
            },
            crate::lower::model::OutTy::OutTuple(ts_p6) => fold_job(ts_p6.clone(), false, Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| entered(once_job(move || {
                let f_p7 = p0;
                let x_p8 = p1;
                prism_rtl::Turn::Finished(f_p7 || has_job_fn(&x_p8))
            }))) as Rc<dyn Fn((bool, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<bool>>>).cycle(),
            crate::lower::model::OutTy::OutNamed(_, ts_p9) => fold_job(ts_p9.clone(), false, Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| entered(once_job(move || {
                let f_pa = p0;
                let x_pb = p1;
                prism_rtl::Turn::Finished(f_pa || has_job_fn(&x_pb))
            }))) as Rc<dyn Fn((bool, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<bool>>>).cycle(),
            crate::lower::model::OutTy::OutFn(ps_pc, r_pd) => {
                let ps_pc = ps_pc.clone();
                let r_pd = (**r_pd).clone();
                call_then(start_has_job_fn(r_pd.clone()), move |has_job_fn_33118: bool| fold_job(ps_pc.clone(), has_job_fn_33118, Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| entered(once_job(move || {
                    let f_pe = p0;
                    let x_pf = p1;
                    prism_rtl::Turn::Finished(f_pe || has_job_fn(&x_pf))
                }))) as Rc<dyn Fn((bool, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<bool>>>).cycle())
            },
            _ => prism_rtl::Turn::Finished(false),
        }
    }
}

/// `Start HasJobFn, x`: what the function value is when passed to `@Run`.
pub fn start_has_job_fn(t_p0: crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(HasJobFn { t_p0 })
}

/// ```prism
/// WrapAsBounded: fn Ex, [OutTy], OutTy -> Ex
/// ```
pub fn wrap_as_bounded(f_p0: &crate::lower::model::Ex, pts_p1: &Array<crate::lower::model::OutTy>, target_p2: &crate::lower::model::OutTy) -> crate::lower::model::Ex {
    let names_p3 = each(&crate::check::errors::range0(&len(pts_p1)), &(|i_p7: &Nat| Text::from(format!("a{}", i_p7))));
    let pas_p4 = each(&crate::check::errors::range0(&len(pts_p1)), &(|i_p8: &Nat| crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaBind(or(&index(&names_p3, i_p8), &Text::lit("a")))), crate::lower::model::OutTy::OutRef(Rc::new(or(&index(pts_p1, i_p8), &crate::lower::model::OutTy::OutUnit))))));
    let arg_p5 = if &len(pts_p1) == &Nat::from(1u32) {
        crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(Text::lit("a0"))))
    } else {
        crate::lower::model::Ex::XTuple(each(&names_p3, &(|nm_p9: &Text| crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(nm_p9.clone()))))))
    };
    let body_p6 = crate::lower::model::Ex::XCall(Text::lit("run_to_end"), Array::from(vec![crate::lower::model::Ex::XApply(Rc::new(crate::lower::model::Ex::XVar(Text::lit("job_fn"))), Array::from(vec![arg_p5.clone()]))]));
    crate::lower::model::Ex::XBlock(Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(Text::lit("job_fn")), f_p0.clone())]), Rc::new(crate::lower::model::Ex::XCast(Rc::new(crate::lower::model::Ex::XCall(Text::lit("Rc::new"), Array::from(vec![crate::lower::model::Ex::XClosure(true, pas_p4.clone(), Rc::new(body_p6.clone()))]))), target_p2.clone())))
}

/// ```prism
/// ArgsFor: unbounded fn Lx, Env, ValInfo, [Arg] -> [Ex]
/// ```
pub fn args_for(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, v_p2: &crate::check::env::ValInfo, args_p3: &Array<crate::syntax::Arg>) -> Array<crate::lower::model::Ex> {
    let ps_p4 = match &v_p2.scheme.ty {
        crate::check::types::Ty::TyFn(_, xs_p5, _) => xs_p5.clone(),
        _ => Array::new(),
    };
    run_to_end(each_job(crate::check::errors::range0(&len(args_p3)), {
        let args_p3 = args_p3.clone();
        let ps_p4 = ps_p4.clone();
        let lx_p0 = lx_p0.clone();
        let env_p1 = env_p1.clone();
        Rc::new(move |p0: Nat| {
            let args_p3 = args_p3.clone();
            let ps_p4 = ps_p4.clone();
            let lx_p0 = lx_p0.clone();
            let env_p1 = env_p1.clone();
            entered(once_job(move || {
                let i_p6 = p0;
                {
                    let a_p7 = or(&index(&args_p3, &i_p6), &crate::syntax::Arg { name: None, value: dummy_expr(), span: crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) } });
                    let is_try_p8 = match crate::lower::types::peel(&or(&index(&ps_p4, &i_p6), &crate::check::types::Ty::TyErr)) {
                        crate::check::types::Ty::TySig(m34282_0_0, _) if (&m34282_0_0 == &Text::lit("~")) => true,
                        _ => false,
                        _ => unreachable!("no arm matched"),
                    };
                    let is_error_p9 = match crate::lower::types::peel(&crate::lower::type_at(&lx_p0, &a_p7.value.span)) {
                        crate::check::types::Ty::TyCon(m34399_0_0, _) if (&m34399_0_0 == &Text::lit("Prelude.Error")) => true,
                        _ => false,
                        _ => unreachable!("no arm matched"),
                    };
                    let to_unbounded_pa = match crate::lower::types::peel(&or(&index(&ps_p4, &i_p6), &crate::check::types::Ty::TyErr)) {
                        crate::check::types::Ty::TyFn(crate::check::types::Col::CBound, _, _) => false,
                        crate::check::types::Ty::TyFn(_, _, _) => true,
                        _ => false,
                    };
                    if is_try_p8 && is_error_p9 {
                        call_then(start_value_of(lx_p0.clone(), env_p1.clone(), a_p7.value.clone()), move |value_of_34748: crate::lower::types::Vl| prism_rtl::Turn::Finished(crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XCtor(Text::lit("Err"), Array::from(vec![crate::lower::types::own(&value_of_34748)]))))))
                    } else {
                        if to_unbounded_pa {
                            call_then(start_as_job_value(lx_p0.clone(), env_p1.clone(), a_p7.value.clone()), move |as_job_value_34813: crate::lower::model::Ex| prism_rtl::Turn::Finished(crate::lower::model::Ex::XRef(Rc::new(as_job_value_34813))))
                        } else {
                            prism_rtl::Turn::More(Rc::new(Argument { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), e_p2: a_p7.value.clone() }))
                        }
                    }
                }
            }))
        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
    }))
}

/// The step machine of `ArgsFor`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ArgsFor: unbounded fn Lx, Env, ValInfo, [Arg] -> [Ex]
/// ```
pub struct ArgsFor {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub v_p2: crate::check::env::ValInfo,
    pub args_p3: Array<crate::syntax::Arg>,
}

impl prism_rtl::Job<Array<crate::lower::model::Ex>> for ArgsFor {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::lower::model::Ex>> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let v_p2 = &self.v_p2;
        let args_p3 = &self.args_p3;
        let ps_p4 = match &v_p2.scheme.ty {
            crate::check::types::Ty::TyFn(_, xs_p5, _) => xs_p5.clone(),
            _ => Array::new(),
        };
        each_job(crate::check::errors::range0(&len(args_p3)), {
            let args_p3 = args_p3.clone();
            let ps_p4 = ps_p4.clone();
            let lx_p0 = lx_p0.clone();
            let env_p1 = env_p1.clone();
            Rc::new(move |p0: Nat| {
                let args_p3 = args_p3.clone();
                let ps_p4 = ps_p4.clone();
                let lx_p0 = lx_p0.clone();
                let env_p1 = env_p1.clone();
                entered(once_job(move || {
                    let i_p6 = p0;
                    {
                        let a_p7 = or(&index(&args_p3, &i_p6), &crate::syntax::Arg { name: None, value: dummy_expr(), span: crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) } });
                        let is_try_p8 = match crate::lower::types::peel(&or(&index(&ps_p4, &i_p6), &crate::check::types::Ty::TyErr)) {
                            crate::check::types::Ty::TySig(m34282_0_0, _) if (&m34282_0_0 == &Text::lit("~")) => true,
                            _ => false,
                            _ => unreachable!("no arm matched"),
                        };
                        let is_error_p9 = match crate::lower::types::peel(&crate::lower::type_at(&lx_p0, &a_p7.value.span)) {
                            crate::check::types::Ty::TyCon(m34399_0_0, _) if (&m34399_0_0 == &Text::lit("Prelude.Error")) => true,
                            _ => false,
                            _ => unreachable!("no arm matched"),
                        };
                        let to_unbounded_pa = match crate::lower::types::peel(&or(&index(&ps_p4, &i_p6), &crate::check::types::Ty::TyErr)) {
                            crate::check::types::Ty::TyFn(crate::check::types::Col::CBound, _, _) => false,
                            crate::check::types::Ty::TyFn(_, _, _) => true,
                            _ => false,
                        };
                        if is_try_p8 && is_error_p9 {
                            call_then(start_value_of(lx_p0.clone(), env_p1.clone(), a_p7.value.clone()), move |value_of_34748: crate::lower::types::Vl| prism_rtl::Turn::Finished(crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XCtor(Text::lit("Err"), Array::from(vec![crate::lower::types::own(&value_of_34748)]))))))
                        } else {
                            if to_unbounded_pa {
                                call_then(start_as_job_value(lx_p0.clone(), env_p1.clone(), a_p7.value.clone()), move |as_job_value_34813: crate::lower::model::Ex| prism_rtl::Turn::Finished(crate::lower::model::Ex::XRef(Rc::new(as_job_value_34813))))
                            } else {
                                prism_rtl::Turn::More(Rc::new(Argument { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), e_p2: a_p7.value.clone() }))
                            }
                        }
                    }
                }))
            }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
        }).cycle()
    }
}

/// `Start ArgsFor, x`: what the function value is when passed to `@Run`.
pub fn start_args_for(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, v_p2: crate::check::env::ValInfo, args_p3: Array<crate::syntax::Arg>) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Ex>>> {
    Rc::new(ArgsFor { lx_p0, env_p1, v_p2, args_p3 })
}

/// ```prism
/// let dummyExpr
/// ```
pub fn dummy_expr() -> crate::syntax::Expr {
    crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EError), span: crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) } }
}

/// ```prism
/// CtorApp: unbounded fn Lx, Env, CtorInfo, [Arg], Range -> Vl
/// ```
pub fn ctor_app(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, c_p2: &crate::check::env::CtorInfo, args_p3: &Array<crate::syntax::Arg>, span_p4: &crate::syntax::Range) -> crate::lower::types::Vl {
    let t_p5 = crate::lower::types::out_ty_of(lx_p0, &crate::lower::types::peel(&crate::lower::type_at(lx_p0, span_p4)));
    let owner_p6 = or(&get(&lx_p0.g.types, &c_p2.owner), &crate::check::env::names::dummy_ty_info());
    let ty_path_p7 = crate::lower::path_in(lx_p0, &owner_p6.home, &crate::lower::camel(&crate::check::types::bare_name(&c_p2.owner)));
    let vals_p8 = ctor_args(lx_p0, env_p1, c_p2, args_p3);
    match &c_p2.owner {
        m35430_0 if (m35430_0 == &Text::lit("Bool")) => crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XBool(&c_p2.name == &Text::lit("True")), crate::lower::model::OutTy::OutBool),
        m35430_1 if (m35430_1 == &Text::lit("Prelude.Error")) => {
            let kind_p9 = or(&index(&vals_p8, &Nat::from(0u32)), &crate::lower::model::Ex::XStr(Text::lit("")));
            let msg_pa = or(&index(&vals_p8, &Nat::from(1u32)), &crate::lower::model::Ex::XText(Text::lit("")));
            let made_pb = crate::lower::model::Ex::XCall(Text::lit("Error::new"), Array::from(vec![kind_p9.clone(), msg_pa.clone()]));
            match &t_p5 {
                crate::lower::model::OutTy::OutRes(_) => crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCtor(Text::lit("Err"), Array::from(vec![made_pb.clone()])), t_p5.clone()),
                _ => crate::lower::types::Vl::VlOwned(made_pb.clone(), crate::lower::model::OutTy::OutError),
            }
        },
        _ => match &owner_p6.body {
            crate::check::env::TyBody::BRecord(fs_pc) => if &len(&c_p2.fields) == &Nat::from(0u32) {
                crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XPath(ty_path_p7.clone()), t_p5.clone())
            } else {
                crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XRecord(ty_path_p7.clone(), each(&crate::check::errors::range0(&len(&c_p2.fields)), &(|i_pd: &Nat| (crate::lower::snake(&or(&index(&c_p2.fields, i_pd), &Text::lit(""))), or(&index(&vals_p8, i_pd), &crate::lower::model::Ex::XCall(Text::lit("Default::default"), Array::new())))))), t_p5.clone())
            },
            crate::check::env::TyBody::BChoice(cases_pe) => {
                let is_unit_type_pf = ((&len(cases_pe) == &Nat::from(1u32)) && (&len(&c_p2.args) == &Nat::from(0u32))) && crate::check::env::is_lower_text(&crate::check::types::bare_name(&c_p2.name));
                let is_newtype_pg = (&len(cases_pe) == &Nat::from(1u32)) && (&crate::check::types::bare_name(&c_p2.name) == &crate::check::types::bare_name(&c_p2.owner));
                let path_ph = if is_unit_type_pf || is_newtype_pg {
                    ty_path_p7.clone()
                } else {
                    Text::from(format!("{}::{}", &ty_path_p7, &crate::lower::camel(&crate::check::types::bare_name(&c_p2.name))))
                };
                let made_pi = if &len(&c_p2.args) == &Nat::from(0u32) {
                    crate::lower::model::Ex::XPath(path_ph.clone())
                } else {
                    crate::lower::model::Ex::XCtor(path_ph.clone(), vals_p8.clone())
                };
                if ((&len(&owner_p6.params) > &Nat::from(0u32)) && !is_unit_type_pf) && !is_newtype_pg {
                    crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XTyped(Rc::new(made_pi.clone()), built_ty(&t_p5)), t_p5.clone())
                } else {
                    crate::lower::types::Vl::VlOwned(made_pi.clone(), t_p5.clone())
                }
            },
            _ => crate::lower::types::Vl::VlOwned(refusal(&Text::from(format!("a constructor of {}", &c_p2.owner))), t_p5.clone()),
        },
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `CtorApp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CtorApp: unbounded fn Lx, Env, CtorInfo, [Arg], Range -> Vl
/// ```
pub struct CtorApp {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub c_p2: crate::check::env::CtorInfo,
    pub args_p3: Array<crate::syntax::Arg>,
    pub span_p4: crate::syntax::Range,
}

impl prism_rtl::Job<crate::lower::types::Vl> for CtorApp {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::types::Vl> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let c_p2 = &self.c_p2;
        let args_p3 = &self.args_p3;
        let span_p4 = &self.span_p4;
        let args_p3 = args_p3.clone();
        let c_p2 = c_p2.clone();
        let env_p1 = env_p1.clone();
        let lx_p0 = lx_p0.clone();
        let span_p4 = span_p4.clone();
        call_then(crate::lower::types::start_out_ty_of(lx_p0.clone(), crate::lower::types::peel(&crate::lower::type_at(&lx_p0, &span_p4))), move |out_ty_of_35229: crate::lower::model::OutTy| {
            let t_p5 = out_ty_of_35229;
            let owner_p6 = or(&get(&lx_p0.g.types, &c_p2.owner), &crate::check::env::names::dummy_ty_info());
            let ty_path_p7 = crate::lower::path_in(&lx_p0, &owner_p6.home, &crate::lower::camel(&crate::check::types::bare_name(&c_p2.owner)));
            call_then(start_ctor_args(lx_p0.clone(), env_p1.clone(), c_p2.clone(), args_p3.clone()), move |ctor_args_35400: Array<crate::lower::model::Ex>| {
                let vals_p8 = ctor_args_35400;
                match &c_p2.owner {
                    m35430_0 if (m35430_0 == &Text::lit("Bool")) => prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XBool(&c_p2.name == &Text::lit("True")), crate::lower::model::OutTy::OutBool)),
                    m35430_1 if (m35430_1 == &Text::lit("Prelude.Error")) => {
                        let kind_p9 = or(&index(&vals_p8, &Nat::from(0u32)), &crate::lower::model::Ex::XStr(Text::lit("")));
                        let msg_pa = or(&index(&vals_p8, &Nat::from(1u32)), &crate::lower::model::Ex::XText(Text::lit("")));
                        let made_pb = crate::lower::model::Ex::XCall(Text::lit("Error::new"), Array::from(vec![kind_p9.clone(), msg_pa.clone()]));
                        match &t_p5 {
                            crate::lower::model::OutTy::OutRes(_) => prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCtor(Text::lit("Err"), Array::from(vec![made_pb.clone()])), t_p5.clone())),
                            _ => prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(made_pb.clone(), crate::lower::model::OutTy::OutError)),
                        }
                    },
                    _ => match &owner_p6.body {
                        crate::check::env::TyBody::BRecord(fs_pc) => if &len(&c_p2.fields) == &Nat::from(0u32) {
                            prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XPath(ty_path_p7.clone()), t_p5.clone()))
                        } else {
                            prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XRecord(ty_path_p7.clone(), each(&crate::check::errors::range0(&len(&c_p2.fields)), &(|i_pd: &Nat| (crate::lower::snake(&or(&index(&c_p2.fields, i_pd), &Text::lit(""))), or(&index(&vals_p8, i_pd), &crate::lower::model::Ex::XCall(Text::lit("Default::default"), Array::new())))))), t_p5.clone()))
                        },
                        crate::check::env::TyBody::BChoice(cases_pe) => {
                            let is_unit_type_pf = ((&len(cases_pe) == &Nat::from(1u32)) && (&len(&c_p2.args) == &Nat::from(0u32))) && crate::check::env::is_lower_text(&crate::check::types::bare_name(&c_p2.name));
                            let is_newtype_pg = (&len(cases_pe) == &Nat::from(1u32)) && (&crate::check::types::bare_name(&c_p2.name) == &crate::check::types::bare_name(&c_p2.owner));
                            let path_ph = if is_unit_type_pf || is_newtype_pg {
                                ty_path_p7.clone()
                            } else {
                                Text::from(format!("{}::{}", &ty_path_p7, &crate::lower::camel(&crate::check::types::bare_name(&c_p2.name))))
                            };
                            let made_pi = if &len(&c_p2.args) == &Nat::from(0u32) {
                                crate::lower::model::Ex::XPath(path_ph.clone())
                            } else {
                                crate::lower::model::Ex::XCtor(path_ph.clone(), vals_p8.clone())
                            };
                            if ((&len(&owner_p6.params) > &Nat::from(0u32)) && !is_unit_type_pf) && !is_newtype_pg {
                                prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XTyped(Rc::new(made_pi.clone()), built_ty(&t_p5)), t_p5.clone()))
                            } else {
                                prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(made_pi.clone(), t_p5.clone()))
                            }
                        },
                        _ => prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(refusal(&Text::from(format!("a constructor of {}", &c_p2.owner))), t_p5.clone())),
                    },
                    _ => unreachable!("no arm matched"),
                }
            })
        })
    }
}

/// `Start CtorApp, x`: what the function value is when passed to `@Run`.
pub fn start_ctor_app(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, c_p2: crate::check::env::CtorInfo, args_p3: Array<crate::syntax::Arg>, span_p4: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<crate::lower::types::Vl>> {
    Rc::new(CtorApp { lx_p0, env_p1, c_p2, args_p3, span_p4 })
}

/// ```prism
/// BuiltTy: fn OutTy -> OutTy
/// ```
pub fn built_ty(t_p0: &crate::lower::model::OutTy) -> crate::lower::model::OutTy {
    match t_p0 {
        crate::lower::model::OutTy::OutFn(_, r_p1) => (**r_p1).clone(),
        crate::lower::model::OutTy::OutJobFn(_, r_p2) => (**r_p2).clone(),
        _ => t_p0.clone(),
    }
}

/// ```prism
/// CtorFn: unbounded fn Lx, CtorInfo, [OutTy], Range, OutTy, Bool -> Vl
/// ```
pub fn ctor_fn(lx_p0: &crate::lower::Lx, c_p1: &crate::check::env::CtorInfo, pts_p2: &Array<crate::lower::model::OutTy>, span_p3: &crate::syntax::Range, t_p4: &crate::lower::model::OutTy, job_p5: &bool) -> crate::lower::types::Vl {
    let names_p6 = each(&crate::check::errors::range0(&len(pts_p2)), &(|i_pa: &Nat| Text::from(format!("a{}", i_pa))));
    let fakes_p7 = each(&crate::check::errors::range0(&len(pts_p2)), &(|i_pb: &Nat| crate::syntax::Arg { name: None, value: crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EAbsent), span: crate::syntax::Range { start: &Nat::from_int(Int::from(4000000000i64)).unwrap() + i_pb, end: &Nat::from_int(Int::from(4000000000i64)).unwrap() + i_pb } }, span: crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) } }));
    let env_p8 = fold(&crate::check::errors::range0(&len(pts_p2)), &crate::lower::types::empty_env(), &(|en_pc: &crate::lower::types::Env, i_pd: &Nat| crate::lower::types::bind_span(en_pc, &crate::lower::place_key(lx_p0, &crate::syntax::Range { start: &Nat::from_int(Int::from(4000000000i64)).unwrap() + i_pd, end: &Nat::from_int(Int::from(4000000000i64)).unwrap() + i_pd }), &crate::lower::types::Vl::VlPlace(crate::lower::model::Ex::XVar(or(&index(&names_p6, i_pd), &Text::lit("a"))), if *job_p5 {
        crate::lower::types::Holding::Owned
    } else {
        crate::lower::types::Holding::ByRef
    }, or(&index(pts_p2, i_pd), &crate::lower::model::OutTy::OutUnit)))));
    let made_p9 = crate::lower::types::own(&ctor_app(lx_p0, &env_p8, c_p1, &fakes_p7, span_p3));
    if *job_p5 {
        {
            let a_pe = match t_p4 {
                crate::lower::model::OutTy::OutJobFn(x_pg, _) => (**x_pg).clone(),
                _ => crate::lower::model::OutTy::OutUnit,
            };
            let pa_pf = if &len(pts_p2) == &Nat::from(1u32) {
                crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaBind(Text::lit("a0"))), a_pe.clone())
            } else {
                crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaTuple(each(&names_p6, &(|nm_ph: &Text| crate::lower::model::Pa::PaBind(nm_ph.clone()))))), a_pe.clone())
            };
            crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCast(Rc::new(crate::lower::model::Ex::XCall(Text::lit("Rc::new"), Array::from(vec![crate::lower::model::Ex::XClosure(true, Array::from(vec![pa_pf.clone()]), Rc::new(crate::lower::model::Ex::XCall(Text::lit("once_job"), Array::from(vec![crate::lower::model::Ex::XClosure(true, Array::new(), Rc::new(crate::lower::model::Ex::XCtor(Text::lit("prism_rtl::Turn::Finished"), Array::from(vec![made_p9.clone()]))))]))))]))), t_p4.clone()), t_p4.clone())
        }
    } else {
        {
            let pas_pi = each(&crate::check::errors::range0(&len(pts_p2)), &(|i_pj: &Nat| crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaBind(or(&index(&names_p6, i_pj), &Text::lit("a")))), crate::lower::model::OutTy::OutRef(Rc::new(or(&index(pts_p2, i_pj), &crate::lower::model::OutTy::OutUnit))))));
            crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCall(Text::lit("Rc::new"), Array::from(vec![crate::lower::model::Ex::XClosure(false, pas_pi.clone(), Rc::new(made_p9.clone()))])), t_p4.clone())
        }
    }
}

/// The step machine of `CtorFn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CtorFn: unbounded fn Lx, CtorInfo, [OutTy], Range, OutTy, Bool -> Vl
/// ```
pub struct CtorFn {
    pub lx_p0: crate::lower::Lx,
    pub c_p1: crate::check::env::CtorInfo,
    pub pts_p2: Array<crate::lower::model::OutTy>,
    pub span_p3: crate::syntax::Range,
    pub t_p4: crate::lower::model::OutTy,
    pub job_p5: bool,
}

impl prism_rtl::Job<crate::lower::types::Vl> for CtorFn {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::types::Vl> {
        let lx_p0 = &self.lx_p0;
        let c_p1 = &self.c_p1;
        let pts_p2 = &self.pts_p2;
        let span_p3 = &self.span_p3;
        let t_p4 = &self.t_p4;
        let job_p5 = &self.job_p5;
        let names_p6 = each(&crate::check::errors::range0(&len(pts_p2)), &(|i_pa: &Nat| Text::from(format!("a{}", i_pa))));
        let fakes_p7 = each(&crate::check::errors::range0(&len(pts_p2)), &(|i_pb: &Nat| crate::syntax::Arg { name: None, value: crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EAbsent), span: crate::syntax::Range { start: &Nat::from_int(Int::from(4000000000i64)).unwrap() + i_pb, end: &Nat::from_int(Int::from(4000000000i64)).unwrap() + i_pb } }, span: crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) } }));
        let env_p8 = fold(&crate::check::errors::range0(&len(pts_p2)), &crate::lower::types::empty_env(), &(|en_pc: &crate::lower::types::Env, i_pd: &Nat| crate::lower::types::bind_span(en_pc, &crate::lower::place_key(lx_p0, &crate::syntax::Range { start: &Nat::from_int(Int::from(4000000000i64)).unwrap() + i_pd, end: &Nat::from_int(Int::from(4000000000i64)).unwrap() + i_pd }), &crate::lower::types::Vl::VlPlace(crate::lower::model::Ex::XVar(or(&index(&names_p6, i_pd), &Text::lit("a"))), if *job_p5 {
            crate::lower::types::Holding::Owned
        } else {
            crate::lower::types::Holding::ByRef
        }, or(&index(pts_p2, i_pd), &crate::lower::model::OutTy::OutUnit)))));
        let c_p1 = c_p1.clone();
        let job_p5 = *job_p5;
        let lx_p0 = lx_p0.clone();
        let pts_p2 = pts_p2.clone();
        let span_p3 = span_p3.clone();
        let t_p4 = t_p4.clone();
        call_then(start_ctor_app(lx_p0.clone(), env_p8.clone(), c_p1.clone(), fakes_p7.clone(), span_p3.clone()), move |ctor_app_38041: crate::lower::types::Vl| {
            let made_p9 = crate::lower::types::own(&ctor_app_38041);
            if job_p5 {
                {
                    let a_pe = match &t_p4 {
                        crate::lower::model::OutTy::OutJobFn(x_pg, _) => (**x_pg).clone(),
                        _ => crate::lower::model::OutTy::OutUnit,
                    };
                    let pa_pf = if &len(&pts_p2) == &Nat::from(1u32) {
                        crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaBind(Text::lit("a0"))), a_pe.clone())
                    } else {
                        crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaTuple(each(&names_p6, &(|nm_ph: &Text| crate::lower::model::Pa::PaBind(nm_ph.clone()))))), a_pe.clone())
                    };
                    prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCast(Rc::new(crate::lower::model::Ex::XCall(Text::lit("Rc::new"), Array::from(vec![crate::lower::model::Ex::XClosure(true, Array::from(vec![pa_pf.clone()]), Rc::new(crate::lower::model::Ex::XCall(Text::lit("once_job"), Array::from(vec![crate::lower::model::Ex::XClosure(true, Array::new(), Rc::new(crate::lower::model::Ex::XCtor(Text::lit("prism_rtl::Turn::Finished"), Array::from(vec![made_p9.clone()]))))]))))]))), t_p4.clone()), t_p4.clone()))
                }
            } else {
                {
                    let pas_pi = each(&crate::check::errors::range0(&len(&pts_p2)), &(|i_pj: &Nat| crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaBind(or(&index(&names_p6, i_pj), &Text::lit("a")))), crate::lower::model::OutTy::OutRef(Rc::new(or(&index(&pts_p2, i_pj), &crate::lower::model::OutTy::OutUnit))))));
                    prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCall(Text::lit("Rc::new"), Array::from(vec![crate::lower::model::Ex::XClosure(false, pas_pi.clone(), Rc::new(made_p9.clone()))])), t_p4.clone()))
                }
            }
        })
    }
}

/// `Start CtorFn, x`: what the function value is when passed to `@Run`.
pub fn start_ctor_fn(lx_p0: crate::lower::Lx, c_p1: crate::check::env::CtorInfo, pts_p2: Array<crate::lower::model::OutTy>, span_p3: crate::syntax::Range, t_p4: crate::lower::model::OutTy, job_p5: bool) -> Rc<dyn prism_rtl::Job<crate::lower::types::Vl>> {
    Rc::new(CtorFn { lx_p0, c_p1, pts_p2, span_p3, t_p4, job_p5 })
}

/// ```prism
/// IsNamedArg: fn Arg -> Bool
/// ```
pub fn is_named_arg(a_p0: &crate::syntax::Arg) -> bool {
    match &a_p0.name {
        Some(_) => true,
        None => false,
    }
}

/// ```prism
/// CtorArgs: unbounded fn Lx, Env, CtorInfo, [Arg] -> [Ex]
/// ```
pub fn ctor_args(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, c_p2: &crate::check::env::CtorInfo, args_p3: &Array<crate::syntax::Arg>) -> Array<crate::lower::model::Ex> {
    let named_p4 = fold(args_p3, &false, &(|f_p6: &bool, a_p7: &crate::syntax::Arg| *f_p6 || is_named_arg(a_p7)));
    let ordered_p5 = if named_p4 {
        each(&c_p2.fields, &(|f_p8: &Text| fold(args_p3, &None, &(|found_o9: &Option<crate::syntax::Expr>, a_pa: &crate::syntax::Arg| match &a_pa.name {
            Some(n_pb) => if &n_pb.name == f_p8 { Some(a_pa.value.clone()) } else { found_o9.clone() },
            None => found_o9.clone(),
        }))))
    } else {
        each(args_p3, &(|a_pc: &crate::syntax::Arg| Some(a_pc.value.clone())))
    };
    run_to_end(each_job(crate::check::errors::range0(&len(&ordered_p5)), {
        let ordered_p5 = ordered_p5.clone();
        let lx_p0 = lx_p0.clone();
        let env_p1 = env_p1.clone();
        let c_p2 = c_p2.clone();
        Rc::new(move |p0: Nat| {
            let ordered_p5 = ordered_p5.clone();
            let lx_p0 = lx_p0.clone();
            let env_p1 = env_p1.clone();
            let c_p2 = c_p2.clone();
            entered(once_job(move || {
                let i_pd = p0;
                match index(&ordered_p5, &i_pd) {
                    Some(Some(x_pe)) => call_then(start_value_of(lx_p0.clone(), env_p1.clone(), x_pe.clone()), move |value_of_39306: crate::lower::types::Vl| {
                        let v_pf = crate::lower::types::own(&value_of_39306);
                        if (&c_p2.owner == &Text::lit("Prelude.Error")) && (&i_pd == &Nat::from(0u32)) {
                            prism_rtl::Turn::Finished(v_pf.clone())
                        } else {
                            if crate::lower::types::rc_field(&lx_p0, &c_p2.name, &i_pd) {
                                prism_rtl::Turn::Finished(crate::lower::model::Ex::XCall(Text::lit("Rc::new"), Array::from(vec![v_pf.clone()])))
                            } else {
                                prism_rtl::Turn::Finished(v_pf.clone())
                            }
                        }
                    }),
                    _ => prism_rtl::Turn::Finished(crate::lower::model::Ex::XCall(Text::lit("Default::default"), Array::new())),
                }
            }))
        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
    }))
}

/// The step machine of `CtorArgs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CtorArgs: unbounded fn Lx, Env, CtorInfo, [Arg] -> [Ex]
/// ```
pub struct CtorArgs {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub c_p2: crate::check::env::CtorInfo,
    pub args_p3: Array<crate::syntax::Arg>,
}

impl prism_rtl::Job<Array<crate::lower::model::Ex>> for CtorArgs {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::lower::model::Ex>> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let c_p2 = &self.c_p2;
        let args_p3 = &self.args_p3;
        let named_p4 = fold(args_p3, &false, &(|f_p6: &bool, a_p7: &crate::syntax::Arg| *f_p6 || is_named_arg(a_p7)));
        let ordered_p5 = if named_p4 {
            each(&c_p2.fields, &(|f_p8: &Text| fold(args_p3, &None, &(|found_o9: &Option<crate::syntax::Expr>, a_pa: &crate::syntax::Arg| match &a_pa.name {
                Some(n_pb) => if &n_pb.name == f_p8 { Some(a_pa.value.clone()) } else { found_o9.clone() },
                None => found_o9.clone(),
            }))))
        } else {
            each(args_p3, &(|a_pc: &crate::syntax::Arg| Some(a_pc.value.clone())))
        };
        each_job(crate::check::errors::range0(&len(&ordered_p5)), {
            let ordered_p5 = ordered_p5.clone();
            let lx_p0 = lx_p0.clone();
            let env_p1 = env_p1.clone();
            let c_p2 = c_p2.clone();
            Rc::new(move |p0: Nat| {
                let ordered_p5 = ordered_p5.clone();
                let lx_p0 = lx_p0.clone();
                let env_p1 = env_p1.clone();
                let c_p2 = c_p2.clone();
                entered(once_job(move || {
                    let i_pd = p0;
                    match index(&ordered_p5, &i_pd) {
                        Some(Some(x_pe)) => call_then(start_value_of(lx_p0.clone(), env_p1.clone(), x_pe.clone()), move |value_of_39306: crate::lower::types::Vl| {
                            let v_pf = crate::lower::types::own(&value_of_39306);
                            if (&c_p2.owner == &Text::lit("Prelude.Error")) && (&i_pd == &Nat::from(0u32)) {
                                prism_rtl::Turn::Finished(v_pf.clone())
                            } else {
                                if crate::lower::types::rc_field(&lx_p0, &c_p2.name, &i_pd) {
                                    prism_rtl::Turn::Finished(crate::lower::model::Ex::XCall(Text::lit("Rc::new"), Array::from(vec![v_pf.clone()])))
                                } else {
                                    prism_rtl::Turn::Finished(v_pf.clone())
                                }
                            }
                        }),
                        _ => prism_rtl::Turn::Finished(crate::lower::model::Ex::XCall(Text::lit("Default::default"), Array::new())),
                    }
                }))
            }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
        }).cycle()
    }
}

/// `Start CtorArgs, x`: what the function value is when passed to `@Run`.
pub fn start_ctor_args(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, c_p2: crate::check::env::CtorInfo, args_p3: Array<crate::syntax::Arg>) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Ex>>> {
    Rc::new(CtorArgs { lx_p0, env_p1, c_p2, args_p3 })
}

/// ```prism
/// MethodCall: unbounded fn Lx, Env, ValInfo, [Arg], Range, OutTy -> Vl
/// ```
pub fn method_call(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, v_p2: &crate::check::env::ValInfo, args_p3: &Array<crate::syntax::Arg>, span_p4: &crate::syntax::Range, t_p5: &crate::lower::model::OutTy) -> crate::lower::types::Vl {
    let cls_p6 = or(&index(&each(&v_p2.scheme.bounds, &(|(_, c_p9): &(Text, Text)| c_p9.clone())), &Nat::from(0u32)), &Text::lit(""));
    let m_p7 = crate::check::types::bare_name(&v_p2.qk);
    let vals_p8 = run_to_end(each_job(args_p3.clone(), {
        let lx_p0 = lx_p0.clone();
        let env_p1 = env_p1.clone();
        Rc::new(move |p0: crate::syntax::Arg| {
            let lx_p0 = lx_p0.clone();
            let env_p1 = env_p1.clone();
            entered(once_job(move || {
                let a_pa = p0;
                prism_rtl::Turn::More(Rc::new(ValueOf { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), e_p2: a_pa.value.clone() }))
            }))
        }) as Rc<dyn Fn(crate::syntax::Arg) -> Rc<dyn prism_rtl::Job<crate::lower::types::Vl>>>
    }));
    if crate::syntax::lexer::chars::has_prefix(&cls_p6, &Text::lit("Prelude.")) {
        prelude_method(lx_p0, &cls_p6, &m_p7, &vals_p8, span_p4, t_p5)
    } else {
        {
            let tr_pb = or(&get(&lx_p0.g.traits, &cls_p6), &dummy_trait_info());
            let path_pc = crate::lower::path_in(lx_p0, &tr_pb.home, &Text::from(format!("{}::{}", &crate::lower::camel(&crate::check::types::bare_name(&cls_p6)), &crate::lower::snake(&m_p7))));
            crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCall(path_pc.clone(), run_to_end(each_job(args_p3.clone(), {
                let lx_p0 = lx_p0.clone();
                let env_p1 = env_p1.clone();
                Rc::new(move |p0: crate::syntax::Arg| {
                    let lx_p0 = lx_p0.clone();
                    let env_p1 = env_p1.clone();
                    entered(once_job(move || {
                        let a_pd = p0;
                        prism_rtl::Turn::More(Rc::new(Argument { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), e_p2: a_pd.value.clone() }))
                    }))
                }) as Rc<dyn Fn(crate::syntax::Arg) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
            }))), t_p5.clone())
        }
    }
}

/// The step machine of `MethodCall`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// MethodCall: unbounded fn Lx, Env, ValInfo, [Arg], Range, OutTy -> Vl
/// ```
pub struct MethodCall {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub v_p2: crate::check::env::ValInfo,
    pub args_p3: Array<crate::syntax::Arg>,
    pub span_p4: crate::syntax::Range,
    pub t_p5: crate::lower::model::OutTy,
}

impl prism_rtl::Job<crate::lower::types::Vl> for MethodCall {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::types::Vl> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let v_p2 = &self.v_p2;
        let args_p3 = &self.args_p3;
        let span_p4 = &self.span_p4;
        let t_p5 = &self.t_p5;
        let cls_p6 = or(&index(&each(&v_p2.scheme.bounds, &(|(_, c_p9): &(Text, Text)| c_p9.clone())), &Nat::from(0u32)), &Text::lit(""));
        let m_p7 = crate::check::types::bare_name(&v_p2.qk);
        let args_p3 = args_p3.clone();
        let env_p1 = env_p1.clone();
        let lx_p0 = lx_p0.clone();
        let span_p4 = span_p4.clone();
        let t_p5 = t_p5.clone();
        call_value(each_job(args_p3.clone(), {
            let lx_p0 = lx_p0.clone();
            let env_p1 = env_p1.clone();
            Rc::new(move |p0: crate::syntax::Arg| {
                let lx_p0 = lx_p0.clone();
                let env_p1 = env_p1.clone();
                entered(once_job(move || {
                    let a_pa = p0;
                    prism_rtl::Turn::More(Rc::new(ValueOf { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), e_p2: a_pa.value.clone() }))
                }))
            }) as Rc<dyn Fn(crate::syntax::Arg) -> Rc<dyn prism_rtl::Job<crate::lower::types::Vl>>>
        }), move |each_39933: Array<crate::lower::types::Vl>| {
            let vals_p8 = each_39933;
            if crate::syntax::lexer::chars::has_prefix(&cls_p6, &Text::lit("Prelude.")) {
                prism_rtl::Turn::More(Rc::new(PreludeMethod { lx_p0: lx_p0.clone(), cls_p1: cls_p6.clone(), m_p2: m_p7.clone(), vals_p3: vals_p8.clone(), span_p4: span_p4.clone(), t_p5: t_p5.clone() }))
            } else {
                {
                    let tr_pb = or(&get(&lx_p0.g.traits, &cls_p6), &dummy_trait_info());
                    let path_pc = crate::lower::path_in(&lx_p0, &tr_pb.home, &Text::from(format!("{}::{}", &crate::lower::camel(&crate::check::types::bare_name(&cls_p6)), &crate::lower::snake(&m_p7))));
                    call_value(each_job(args_p3.clone(), {
                        let lx_p0 = lx_p0.clone();
                        let env_p1 = env_p1.clone();
                        Rc::new(move |p0: crate::syntax::Arg| {
                            let lx_p0 = lx_p0.clone();
                            let env_p1 = env_p1.clone();
                            entered(once_job(move || {
                                let a_pd = p0;
                                prism_rtl::Turn::More(Rc::new(Argument { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), e_p2: a_pd.value.clone() }))
                            }))
                        }) as Rc<dyn Fn(crate::syntax::Arg) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
                    }), move |each_40218: Array<crate::lower::model::Ex>| prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCall(path_pc.clone(), each_40218), t_p5.clone())))
                }
            }
        })
    }
}

/// `Start MethodCall, x`: what the function value is when passed to `@Run`.
pub fn start_method_call(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, v_p2: crate::check::env::ValInfo, args_p3: Array<crate::syntax::Arg>, span_p4: crate::syntax::Range, t_p5: crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<crate::lower::types::Vl>> {
    Rc::new(MethodCall { lx_p0, env_p1, v_p2, args_p3, span_p4, t_p5 })
}

/// ```prism
/// let dummyTraitInfo
/// ```
pub fn dummy_trait_info() -> crate::check::env::TraitInfo {
    crate::check::env::TraitInfo { name: Text::lit(""), home: Text::lit(""), param: Text::lit("a"), supers: Array::new(), methods: Array::new(), defaults: Array::new(), assocs: Array::new(), file: Nat::from(0u32), span: crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) } }
}

/// ```prism
/// PreludeMethod: unbounded fn Lx, Text, Text, [Vl], Range, OutTy -> Vl
/// ```
pub fn prelude_method(lx_p0: &crate::lower::Lx, cls_p1: &Text, m_p2: &Text, vals_p3: &Array<crate::lower::types::Vl>, span_p4: &crate::syntax::Range, t_p5: &crate::lower::model::OutTy) -> crate::lower::types::Vl {
    let a_p6 = or(&index(vals_p3, &Nat::from(0u32)), &crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XUnit, crate::lower::model::OutTy::OutUnit));
    let b_p7 = or(&index(vals_p3, &Nat::from(1u32)), &crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XUnit, crate::lower::model::OutTy::OutUnit));
    match m_p2 {
        m40637_0 if (m40637_0 == &Text::lit("Show")) => crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCall(Text::lit("show_text"), Array::from(vec![crate::lower::types::ref_(&a_p6)])), crate::lower::model::OutTy::OutText),
        m40637_1 if (m40637_1 == &Text::lit("Compare")) => crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCall(Text::lit("compare"), Array::from(vec![crate::lower::types::ref_(&a_p6), crate::lower::types::ref_(&b_p7)])), t_p5.clone()),
        m40637_2 if (m40637_2 == &Text::lit("Children")) => crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCall(Text::lit("children"), Array::from(vec![crate::lower::types::ref_(&a_p6)])), t_p5.clone()),
        _ => op_value(lx_p0, m_p2, &a_p6, &b_p7, span_p4, t_p5),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `PreludeMethod`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PreludeMethod: unbounded fn Lx, Text, Text, [Vl], Range, OutTy -> Vl
/// ```
pub struct PreludeMethod {
    pub lx_p0: crate::lower::Lx,
    pub cls_p1: Text,
    pub m_p2: Text,
    pub vals_p3: Array<crate::lower::types::Vl>,
    pub span_p4: crate::syntax::Range,
    pub t_p5: crate::lower::model::OutTy,
}

impl prism_rtl::Job<crate::lower::types::Vl> for PreludeMethod {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::types::Vl> {
        let lx_p0 = &self.lx_p0;
        let cls_p1 = &self.cls_p1;
        let m_p2 = &self.m_p2;
        let vals_p3 = &self.vals_p3;
        let span_p4 = &self.span_p4;
        let t_p5 = &self.t_p5;
        let a_p6 = or(&index(vals_p3, &Nat::from(0u32)), &crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XUnit, crate::lower::model::OutTy::OutUnit));
        let b_p7 = or(&index(vals_p3, &Nat::from(1u32)), &crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XUnit, crate::lower::model::OutTy::OutUnit));
        match m_p2 {
            m40637_0 if (m40637_0 == &Text::lit("Show")) => prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCall(Text::lit("show_text"), Array::from(vec![crate::lower::types::ref_(&a_p6)])), crate::lower::model::OutTy::OutText)),
            m40637_1 if (m40637_1 == &Text::lit("Compare")) => prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCall(Text::lit("compare"), Array::from(vec![crate::lower::types::ref_(&a_p6), crate::lower::types::ref_(&b_p7)])), t_p5.clone())),
            m40637_2 if (m40637_2 == &Text::lit("Children")) => prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCall(Text::lit("children"), Array::from(vec![crate::lower::types::ref_(&a_p6)])), t_p5.clone())),
            _ => prism_rtl::Turn::Finished(op_value(lx_p0, m_p2, &a_p6, &b_p7, span_p4, t_p5)),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start PreludeMethod, x`: what the function value is when passed to `@Run`.
pub fn start_prelude_method(lx_p0: crate::lower::Lx, cls_p1: Text, m_p2: Text, vals_p3: Array<crate::lower::types::Vl>, span_p4: crate::syntax::Range, t_p5: crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<crate::lower::types::Vl>> {
    Rc::new(PreludeMethod { lx_p0, cls_p1, m_p2, vals_p3, span_p4, t_p5 })
}

/// ```prism
/// BinaryValue: unbounded fn Lx, Env, Text, Expr, Expr, Range -> Vl
/// ```
pub fn binary_value(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, op_p2: &Text, l_p3: &crate::syntax::Expr, r_p4: &crate::syntax::Expr, span_p5: &crate::syntax::Range) -> crate::lower::types::Vl {
    let t_p6 = crate::lower::types::out_ty_of(lx_p0, &crate::lower::types::peel(&crate::lower::type_at(lx_p0, span_p5)));
    match op_p2 {
        m41065_0 if (m41065_0 == &Text::lit("and")) => crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XBin(Text::lit("&&"), Rc::new(crate::lower::types::as_bool(&value_of(lx_p0, env_p1, l_p3))), Rc::new(crate::lower::types::as_bool(&value_of(lx_p0, env_p1, r_p4)))), crate::lower::model::OutTy::OutBool),
        m41065_1 if (m41065_1 == &Text::lit("or")) => crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XBin(Text::lit("||"), Rc::new(crate::lower::types::as_bool(&value_of(lx_p0, env_p1, l_p3))), Rc::new(crate::lower::types::as_bool(&value_of(lx_p0, env_p1, r_p4)))), crate::lower::model::OutTy::OutBool),
        m41065_2 if (m41065_2 == &Text::lit("on")) => value_of(lx_p0, env_p1, l_p3),
        _ => op_value(lx_p0, op_p2, &value_of(lx_p0, env_p1, l_p3), &value_of(lx_p0, env_p1, r_p4), span_p5, &t_p6),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `BinaryValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BinaryValue: unbounded fn Lx, Env, Text, Expr, Expr, Range -> Vl
/// ```
pub struct BinaryValue {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub op_p2: Text,
    pub l_p3: crate::syntax::Expr,
    pub r_p4: crate::syntax::Expr,
    pub span_p5: crate::syntax::Range,
}

impl prism_rtl::Job<crate::lower::types::Vl> for BinaryValue {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::types::Vl> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let op_p2 = &self.op_p2;
        let l_p3 = &self.l_p3;
        let r_p4 = &self.r_p4;
        let span_p5 = &self.span_p5;
        let env_p1 = env_p1.clone();
        let l_p3 = l_p3.clone();
        let lx_p0 = lx_p0.clone();
        let op_p2 = op_p2.clone();
        let r_p4 = r_p4.clone();
        let span_p5 = span_p5.clone();
        call_then(crate::lower::types::start_out_ty_of(lx_p0.clone(), crate::lower::types::peel(&crate::lower::type_at(&lx_p0, &span_p5))), move |out_ty_of_41024: crate::lower::model::OutTy| {
            let t_p6 = out_ty_of_41024;
            match &op_p2 {
                m41065_0 if (m41065_0 == &Text::lit("and")) => call_then(start_value_of(lx_p0.clone(), env_p1.clone(), l_p3.clone()), move |value_of_41119: crate::lower::types::Vl| call_then(start_value_of(lx_p0.clone(), env_p1.clone(), r_p4.clone()), move |value_of_41150: crate::lower::types::Vl| prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XBin(Text::lit("&&"), Rc::new(crate::lower::types::as_bool(&value_of_41119)), Rc::new(crate::lower::types::as_bool(&value_of_41150))), crate::lower::model::OutTy::OutBool)))),
                m41065_1 if (m41065_1 == &Text::lit("or")) => call_then(start_value_of(lx_p0.clone(), env_p1.clone(), l_p3.clone()), move |value_of_41224: crate::lower::types::Vl| call_then(start_value_of(lx_p0.clone(), env_p1.clone(), r_p4.clone()), move |value_of_41255: crate::lower::types::Vl| prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XBin(Text::lit("||"), Rc::new(crate::lower::types::as_bool(&value_of_41224)), Rc::new(crate::lower::types::as_bool(&value_of_41255))), crate::lower::model::OutTy::OutBool)))),
                m41065_2 if (m41065_2 == &Text::lit("on")) => prism_rtl::Turn::More(Rc::new(ValueOf { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), e_p2: l_p3.clone() })),
                _ => call_then(start_value_of(lx_p0.clone(), env_p1.clone(), l_p3.clone()), move |value_of_41521: crate::lower::types::Vl| call_then(start_value_of(lx_p0.clone(), env_p1.clone(), r_p4.clone()), move |value_of_41543: crate::lower::types::Vl| prism_rtl::Turn::Finished(op_value(&lx_p0, &op_p2, &value_of_41521, &value_of_41543, &span_p5, &t_p6)))),
                _ => unreachable!("no arm matched"),
            }
        })
    }
}

/// `Start BinaryValue, x`: what the function value is when passed to `@Run`.
pub fn start_binary_value(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, op_p2: Text, l_p3: crate::syntax::Expr, r_p4: crate::syntax::Expr, span_p5: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<crate::lower::types::Vl>> {
    Rc::new(BinaryValue { lx_p0, env_p1, op_p2, l_p3, r_p4, span_p5 })
}

/// ```prism
/// OpValue: fn Lx, Text, Vl, Vl, Range, OutTy -> Vl
/// ```
pub fn op_value(lx_p0: &crate::lower::Lx, op_p1: &Text, a_p2: &crate::lower::types::Vl, b_p3: &crate::lower::types::Vl, span_p4: &crate::syntax::Range, t_p5: &crate::lower::model::OutTy) -> crate::lower::types::Vl {
    let at_p6 = crate::lower::types::value_ty(a_p2);
    let generic_p7 = match &at_p6 {
        crate::lower::model::OutTy::OutGen(_) => true,
        _ => false,
    };
    if crate::check::types::has_text(&Array::from(vec![Text::lit("=="), Text::lit("!="), Text::lit("<"), Text::lit("<="), Text::lit(">"), Text::lit(">=")]), op_p1) {
        crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XBin(op_p1.clone(), Rc::new(crate::lower::types::ref_(a_p2)), Rc::new(crate::lower::types::ref_(b_p3))), crate::lower::model::OutTy::OutBool)
    } else {
        if op_p1 == &Text::lit("mod") {
            crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::types::ref_(a_p2)), Text::lit("modulo"), Array::from(vec![crate::lower::types::ref_(b_p3)])), t_p5.clone())
        } else {
            if generic_p7 {
                crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCall(Text::from(format!("Num::{}", &num_method(op_p1))), Array::from(vec![crate::lower::types::ref_(a_p2), crate::lower::types::ref_(b_p3)])), t_p5.clone())
            } else {
                if op_p1 == &Text::lit("/") {
                    if &at_p6 == &crate::lower::model::OutTy::OutFloat {
                        crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XBin(Text::lit("/"), Rc::new(crate::lower::types::copy(a_p2)), Rc::new(crate::lower::types::copy(b_p3))), t_p5.clone())
                    } else {
                        crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::types::ref_(a_p2)), Text::lit("div"), Array::from(vec![crate::lower::types::ref_(b_p3)])), t_p5.clone())
                    }
                } else {
                    if op_p1 == &Text::lit("-?") {
                        if &at_p6 == &crate::lower::model::OutTy::OutNat {
                            crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::types::ref_(a_p2)), Text::lit("checked_sub"), Array::from(vec![crate::lower::types::ref_(b_p3)])), t_p5.clone())
                        } else {
                            crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Ex::XBin(Text::lit("-"), Rc::new(crate::lower::types::ref_(a_p2)), Rc::new(crate::lower::types::ref_(b_p3)))])), t_p5.clone())
                        }
                    } else {
                        if op_p1 == &Text::lit("+?") {
                            crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Ex::XBin(Text::lit("+"), Rc::new(crate::lower::types::ref_(a_p2)), Rc::new(crate::lower::types::ref_(b_p3)))])), t_p5.clone())
                        } else {
                            if op_p1 == &Text::lit("*?") {
                                crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Ex::XBin(Text::lit("*"), Rc::new(crate::lower::types::ref_(a_p2)), Rc::new(crate::lower::types::ref_(b_p3)))])), t_p5.clone())
                            } else {
                                if crate::lower::types::is_copy(&at_p6) {
                                    crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XBin(op_p1.clone(), Rc::new(crate::lower::types::copy(a_p2)), Rc::new(crate::lower::types::copy(b_p3))), t_p5.clone())
                                } else {
                                    crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XBin(op_p1.clone(), Rc::new(crate::lower::types::ref_(a_p2)), Rc::new(crate::lower::types::ref_(b_p3))), t_p5.clone())
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

/// ```prism
/// NumMethod: fn Text -> Text
/// ```
pub fn num_method(text0: &Text) -> Text {
    match text0 {
        c0_0 if (c0_0 == &Text::lit("+")) => Text::lit("add"),
        c1_0 if (c1_0 == &Text::lit("-")) => Text::lit("sub"),
        c2_0 if (c2_0 == &Text::lit("*")) => Text::lit("mul"),
        c3_0 if (c3_0 == &Text::lit("/")) => Text::lit("div_opt"),
        c4_0 if (c4_0 == &Text::lit("+?")) => Text::lit("add_opt"),
        c5_0 if (c5_0 == &Text::lit("-?")) => Text::lit("sub_opt"),
        c6_0 if (c6_0 == &Text::lit("*?")) => Text::lit("mul_opt"),
        other_p0 => Text::lit("add"),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// PreludeCall: unbounded fn Lx, Env, Text, [Arg], Range, OutTy -> Vl
/// ```
pub fn prelude_call(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, qk_p2: &Text, args_p3: &Array<crate::syntax::Arg>, span_p4: &crate::syntax::Range, t_p5: &crate::lower::model::OutTy) -> crate::lower::types::Vl {
    let name_p6 = or(&get(&lx_p0.rs_names, qk_p2), &crate::lower::snake(&crate::check::types::bare_name(qk_p2)));
    let first_p7 = match index(args_p3, &Nat::from(0u32)) {
        Some(a_p9) => crate::lower::types::out_ty_of(lx_p0, &crate::lower::types::peel(&crate::lower::type_at(lx_p0, &a_p9.value.span))),
        None => crate::lower::model::OutTy::OutUnit,
    };
    let variant_p8 = prelude_variant(&name_p6, &first_p7);
    match prelude_job(lx_p0, env_p1, &variant_p8, args_p3) {
        Some(job_pa) => crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCall(Text::lit("run_to_end"), Array::from(vec![job_pa])), t_p5.clone()),
        None => crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCall(crate::lower::prelude_path(lx_p0, &variant_p8), run_to_end(each_job(args_p3.clone(), {
            let lx_p0 = lx_p0.clone();
            let env_p1 = env_p1.clone();
            Rc::new(move |p0: crate::syntax::Arg| {
                let lx_p0 = lx_p0.clone();
                let env_p1 = env_p1.clone();
                entered(once_job(move || {
                    let a_pb = p0;
                    prism_rtl::Turn::More(Rc::new(Argument { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), e_p2: a_pb.value.clone() }))
                }))
            }) as Rc<dyn Fn(crate::syntax::Arg) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
        }))), t_p5.clone()),
    }
}

/// The step machine of `PreludeCall`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PreludeCall: unbounded fn Lx, Env, Text, [Arg], Range, OutTy -> Vl
/// ```
pub struct PreludeCall {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub qk_p2: Text,
    pub args_p3: Array<crate::syntax::Arg>,
    pub span_p4: crate::syntax::Range,
    pub t_p5: crate::lower::model::OutTy,
}

impl prism_rtl::Job<crate::lower::types::Vl> for PreludeCall {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::types::Vl> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let qk_p2 = &self.qk_p2;
        let args_p3 = &self.args_p3;
        let span_p4 = &self.span_p4;
        let t_p5 = &self.t_p5;
        let name_p6 = or(&get(&lx_p0.rs_names, qk_p2), &crate::lower::snake(&crate::check::types::bare_name(qk_p2)));
        let first_p7 = match index(args_p3, &Nat::from(0u32)) {
            Some(a_p9) => crate::lower::types::out_ty_of(lx_p0, &crate::lower::types::peel(&crate::lower::type_at(lx_p0, &a_p9.value.span))),
            None => crate::lower::model::OutTy::OutUnit,
        };
        let variant_p8 = prelude_variant(&name_p6, &first_p7);
        let args_p3 = args_p3.clone();
        let env_p1 = env_p1.clone();
        let lx_p0 = lx_p0.clone();
        let t_p5 = t_p5.clone();
        call_then(start_prelude_job(lx_p0.clone(), env_p1.clone(), variant_p8.clone(), args_p3.clone()), move |prelude_job_43557: Option<crate::lower::model::Ex>| match prelude_job_43557 {
            Some(job_pa) => prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCall(Text::lit("run_to_end"), Array::from(vec![job_pa.clone()])), t_p5.clone())),
            None => call_value(each_job(args_p3.clone(), {
                let lx_p0 = lx_p0.clone();
                let env_p1 = env_p1.clone();
                Rc::new(move |p0: crate::syntax::Arg| {
                    let lx_p0 = lx_p0.clone();
                    let env_p1 = env_p1.clone();
                    entered(once_job(move || {
                        let a_pb = p0;
                        prism_rtl::Turn::More(Rc::new(Argument { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), e_p2: a_pb.value.clone() }))
                    }))
                }) as Rc<dyn Fn(crate::syntax::Arg) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
            }), move |each_43705: Array<crate::lower::model::Ex>| prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCall(crate::lower::prelude_path(&lx_p0, &variant_p8), each_43705), t_p5.clone()))),
        })
    }
}

/// `Start PreludeCall, x`: what the function value is when passed to `@Run`.
pub fn start_prelude_call(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, qk_p2: Text, args_p3: Array<crate::syntax::Arg>, span_p4: crate::syntax::Range, t_p5: crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<crate::lower::types::Vl>> {
    Rc::new(PreludeCall { lx_p0, env_p1, qk_p2, args_p3, span_p4, t_p5 })
}

/// ```prism
/// ?PreludeJob: unbounded fn Lx, Env, Text, [Arg] -> ?Ex
/// ```
pub fn prelude_job(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, variant_p2: &Text, args_p3: &Array<crate::syntax::Arg>) -> Option<crate::lower::model::Ex> {
    if crate::check::types::has_text(&Array::from(vec![Text::lit("fold"), Text::lit("fold_map"), Text::lit("each"), Text::lit("each_map"), Text::lit("filter"), Text::lit("filter_map")]), variant_p2) {
        {
            let last_p4 = or(&index(args_p3, &crate::syntax::lexer::chars::dec(&len(args_p3))), &crate::syntax::Arg { name: None, value: dummy_expr(), span: crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) } });
            match crate::lower::types::out_ty_of(lx_p0, &crate::lower::types::peel(&crate::lower::type_at(lx_p0, &last_p4.value.span))) {
                crate::lower::model::OutTy::OutJobFn(_, _) => {
                    let front_p5 = run_to_end(each_job(take(args_p3, &crate::syntax::lexer::chars::dec(&len(args_p3))), {
                        let lx_p0 = lx_p0.clone();
                        let env_p1 = env_p1.clone();
                        Rc::new(move |p0: crate::syntax::Arg| {
                            let lx_p0 = lx_p0.clone();
                            let env_p1 = env_p1.clone();
                            entered(once_job(move || {
                                let a_p6 = p0;
                                call_then(start_value_of(lx_p0.clone(), env_p1.clone(), a_p6.value.clone()), move |value_of_44571: crate::lower::types::Vl| prism_rtl::Turn::Finished(crate::lower::types::own(&value_of_44571)))
                            }))
                        }) as Rc<dyn Fn(crate::syntax::Arg) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
                    }));
                    Some(crate::lower::model::Ex::XCall(Text::from(format!("{}_job", variant_p2)), push(&front_p5, &as_job_value(lx_p0, env_p1, &last_p4.value))))
                },
                _ => None,
            }
        }
    } else {
        None
    }
}

/// The step machine of `PreludeJob`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?PreludeJob: unbounded fn Lx, Env, Text, [Arg] -> ?Ex
/// ```
pub struct PreludeJob {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub variant_p2: Text,
    pub args_p3: Array<crate::syntax::Arg>,
}

impl prism_rtl::Job<Option<crate::lower::model::Ex>> for PreludeJob {
    fn cycle(&self) -> prism_rtl::Turn<Option<crate::lower::model::Ex>> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let variant_p2 = &self.variant_p2;
        let args_p3 = &self.args_p3;
        if crate::check::types::has_text(&Array::from(vec![Text::lit("fold"), Text::lit("fold_map"), Text::lit("each"), Text::lit("each_map"), Text::lit("filter"), Text::lit("filter_map")]), variant_p2) {
            {
                let last_p4 = or(&index(args_p3, &crate::syntax::lexer::chars::dec(&len(args_p3))), &crate::syntax::Arg { name: None, value: dummy_expr(), span: crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) } });
                let args_p3 = args_p3.clone();
                let env_p1 = env_p1.clone();
                let lx_p0 = lx_p0.clone();
                let variant_p2 = variant_p2.clone();
                call_then(crate::lower::types::start_out_ty_of(lx_p0.clone(), crate::lower::types::peel(&crate::lower::type_at(&lx_p0, &last_p4.value.span))), move |out_ty_of_44411: crate::lower::model::OutTy| match out_ty_of_44411 {
                    crate::lower::model::OutTy::OutJobFn(_, _) => call_value(each_job(take(&args_p3, &crate::syntax::lexer::chars::dec(&len(&args_p3))), {
                        let lx_p0 = lx_p0.clone();
                        let env_p1 = env_p1.clone();
                        Rc::new(move |p0: crate::syntax::Arg| {
                            let lx_p0 = lx_p0.clone();
                            let env_p1 = env_p1.clone();
                            entered(once_job(move || {
                                let a_p6 = p0;
                                call_then(start_value_of(lx_p0.clone(), env_p1.clone(), a_p6.value.clone()), move |value_of_44571: crate::lower::types::Vl| prism_rtl::Turn::Finished(crate::lower::types::own(&value_of_44571)))
                            }))
                        }) as Rc<dyn Fn(crate::syntax::Arg) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
                    }), move |each_44525: Array<crate::lower::model::Ex>| {
                        let front_p5 = each_44525;
                        prism_rtl::Turn::Finished(Some(crate::lower::model::Ex::XCall(Text::from(format!("{}_job", &variant_p2)), push(&front_p5, &as_job_value(&lx_p0, &env_p1, &last_p4.value)))))
                    }),
                    _ => prism_rtl::Turn::Finished(None),
                })
            }
        } else {
            prism_rtl::Turn::Finished(None)
        }
    }
}

/// `Start PreludeJob, x`: what the function value is when passed to `@Run`.
pub fn start_prelude_job(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, variant_p2: Text, args_p3: Array<crate::syntax::Arg>) -> Rc<dyn prism_rtl::Job<Option<crate::lower::model::Ex>>> {
    Rc::new(PreludeJob { lx_p0, env_p1, variant_p2, args_p3 })
}

/// ```prism
/// ?PreludeJobCall: unbounded fn Lx, Env, Expr -> ?Ex
/// ```
pub fn prelude_job_call(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, e_p2: &crate::syntax::Expr) -> Option<crate::lower::model::Ex> {
    match &*e_p2.kind {
        crate::syntax::ExprKind::ECall(c_p3, args_p4, _, _) => match &*c_p3.kind {
            crate::syntax::ExprKind::EName(n_p5) => if (&len(&n_p5.path_) == &Nat::from(1u32)) && crate::check::env::has_key(&env_p1.names, &crate::check::env::sname_key(n_p5)) {
                None
            } else {
                {
                    let (qk_o6, _) = crate::check::env::names::resolve_value(&lx_p0.g, &lx_p0.home, n_p5);
                    match &qk_o6 {
                        Some(qk_p7) => match get(&lx_p0.g.vals, qk_p7) {
                            Some(v_p8) => if &v_p8.home == &Text::lit("Prelude") {
                                {
                                    let name_p9 = or(&get(&lx_p0.rs_names, qk_p7), &crate::lower::snake(&crate::check::types::bare_name(qk_p7)));
                                    let first_pa = match index(args_p4, &Nat::from(0u32)) {
                                        Some(a_pb) => crate::lower::types::out_ty_of(lx_p0, &crate::lower::types::peel(&crate::lower::type_at(lx_p0, &a_pb.value.span))),
                                        None => crate::lower::model::OutTy::OutUnit,
                                    };
                                    prelude_job(lx_p0, env_p1, &prelude_variant(&name_p9, &first_pa), args_p4)
                                }
                            } else {
                                None
                            },
                            None => None,
                        },
                        None => None,
                    }
                }
            },
            _ => None,
        },
        _ => None,
    }
}

/// The step machine of `PreludeJobCall`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?PreludeJobCall: unbounded fn Lx, Env, Expr -> ?Ex
/// ```
pub struct PreludeJobCall {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub e_p2: crate::syntax::Expr,
}

impl prism_rtl::Job<Option<crate::lower::model::Ex>> for PreludeJobCall {
    fn cycle(&self) -> prism_rtl::Turn<Option<crate::lower::model::Ex>> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let e_p2 = &self.e_p2;
        match &*e_p2.kind {
            crate::syntax::ExprKind::ECall(c_p3, args_p4, _, _) => match &*c_p3.kind {
                crate::syntax::ExprKind::EName(n_p5) => if (&len(&n_p5.path_) == &Nat::from(1u32)) && crate::check::env::has_key(&env_p1.names, &crate::check::env::sname_key(n_p5)) {
                    prism_rtl::Turn::Finished(None)
                } else {
                    {
                        let (qk_o6, _) = crate::check::env::names::resolve_value(&lx_p0.g, &lx_p0.home, n_p5);
                        match &qk_o6 {
                            Some(qk_p7) => match get(&lx_p0.g.vals, qk_p7) {
                                Some(v_p8) => if &v_p8.home == &Text::lit("Prelude") {
                                    {
                                        let name_p9 = or(&get(&lx_p0.rs_names, qk_p7), &crate::lower::snake(&crate::check::types::bare_name(qk_p7)));
                                        let first_pa = match index(args_p4, &Nat::from(0u32)) {
                                            Some(a_pb) => crate::lower::types::out_ty_of(lx_p0, &crate::lower::types::peel(&crate::lower::type_at(lx_p0, &a_pb.value.span))),
                                            None => crate::lower::model::OutTy::OutUnit,
                                        };
                                        prism_rtl::Turn::More(Rc::new(PreludeJob { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), variant_p2: prelude_variant(&name_p9, &first_pa), args_p3: args_p4.clone() }))
                                    }
                                } else {
                                    prism_rtl::Turn::Finished(None)
                                },
                                None => prism_rtl::Turn::Finished(None),
                            },
                            None => prism_rtl::Turn::Finished(None),
                        }
                    }
                },
                _ => prism_rtl::Turn::Finished(None),
            },
            _ => prism_rtl::Turn::Finished(None),
        }
    }
}

/// `Start PreludeJobCall, x`: what the function value is when passed to `@Run`.
pub fn start_prelude_job_call(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, e_p2: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<Option<crate::lower::model::Ex>>> {
    Rc::new(PreludeJobCall { lx_p0, env_p1, e_p2 })
}

/// ```prism
/// AsJobValue: unbounded fn Lx, Env, Expr -> Ex
/// ```
pub fn as_job_value(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, e_p2: &crate::syntax::Expr) -> crate::lower::model::Ex {
    match &*e_p2.kind {
        crate::syntax::ExprKind::EGroup(x_p3) => as_job_value(lx_p0, env_p1, &**x_p3),
        _ => {
            let target_p4 = match crate::lower::types::peel(&crate::lower::type_at(lx_p0, &e_p2.span)) {
                crate::check::types::Ty::TyFn(_, ps_p6, r_p7) => crate::lower::model::OutTy::OutJobFn(Rc::new(crate::lower::types::rust_ty_of_params(lx_p0, &ps_p6)), Rc::new(crate::lower::types::out_ty_of(lx_p0, &*r_p7))),
                other_p8 => crate::lower::types::out_ty_of(lx_p0, &other_p8),
            };
            let a_p5 = match &target_p4 {
                crate::lower::model::OutTy::OutJobFn(x_p9, _) => (**x_p9).clone(),
                _ => crate::lower::model::OutTy::OutUnit,
            };
            match &*e_p2.kind {
                crate::syntax::ExprKind::ELambda(ps_oa, body_pb) => crate::lower::types::own(&job_lambda(lx_p0, env_p1, &or(ps_oa, &Array::new()), &**body_pb, &target_p4, &a_p5, &enters_lambda(lx_p0, e_p2))),
                _ => {
                    let v_pc = value_of(lx_p0, env_p1, e_p2);
                    match crate::lower::types::value_ty(&v_pc) {
                        crate::lower::model::OutTy::OutFn(pts_pd, _) => wrap_as_job(&crate::lower::types::own(&v_pc), &pts_pd, &target_p4, &a_p5),
                        _ => crate::lower::types::own(&v_pc),
                    }
                },
            }
        },
    }
}

/// The step machine of `AsJobValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// AsJobValue: unbounded fn Lx, Env, Expr -> Ex
/// ```
pub struct AsJobValue {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub e_p2: crate::syntax::Expr,
}

impl prism_rtl::Job<crate::lower::model::Ex> for AsJobValue {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::Ex> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let e_p2 = &self.e_p2;
        match &*e_p2.kind {
            crate::syntax::ExprKind::EGroup(x_p3) => prism_rtl::Turn::More(Rc::new(AsJobValue { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), e_p2: (**x_p3).clone() })),
            _ => {
                let target_p4 = match crate::lower::types::peel(&crate::lower::type_at(lx_p0, &e_p2.span)) {
                    crate::check::types::Ty::TyFn(_, ps_p6, r_p7) => crate::lower::model::OutTy::OutJobFn(Rc::new(crate::lower::types::rust_ty_of_params(lx_p0, &ps_p6)), Rc::new(crate::lower::types::out_ty_of(lx_p0, &*r_p7))),
                    other_p8 => crate::lower::types::out_ty_of(lx_p0, &other_p8),
                };
                let a_p5 = match &target_p4 {
                    crate::lower::model::OutTy::OutJobFn(x_p9, _) => (**x_p9).clone(),
                    _ => crate::lower::model::OutTy::OutUnit,
                };
                match &*e_p2.kind {
                    crate::syntax::ExprKind::ELambda(ps_oa, body_pb) => {
                        let ps_oa = ps_oa.clone();
                        let body_pb = (**body_pb).clone();
                        let e_p2 = e_p2.clone();
                        let env_p1 = env_p1.clone();
                        let lx_p0 = lx_p0.clone();
                        call_then(start_job_lambda(lx_p0.clone(), env_p1.clone(), or(&ps_oa, &Array::new()), body_pb.clone(), target_p4.clone(), a_p5.clone(), enters_lambda(&lx_p0, &e_p2)), move |job_lambda_46460: crate::lower::types::Vl| prism_rtl::Turn::Finished(crate::lower::types::own(&job_lambda_46460)))
                    },
                    _ => {
                        let e_p2 = e_p2.clone();
                        let env_p1 = env_p1.clone();
                        let lx_p0 = lx_p0.clone();
                        call_then(start_value_of(lx_p0.clone(), env_p1.clone(), e_p2.clone()), move |value_of_46581: crate::lower::types::Vl| {
                            let v_pc = value_of_46581;
                            match crate::lower::types::value_ty(&v_pc) {
                                crate::lower::model::OutTy::OutFn(pts_pd, _) => prism_rtl::Turn::Finished(wrap_as_job(&crate::lower::types::own(&v_pc), &pts_pd, &target_p4, &a_p5)),
                                _ => prism_rtl::Turn::Finished(crate::lower::types::own(&v_pc)),
                            }
                        })
                    },
                }
            },
        }
    }
}

/// `Start AsJobValue, x`: what the function value is when passed to `@Run`.
pub fn start_as_job_value(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, e_p2: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>> {
    Rc::new(AsJobValue { lx_p0, env_p1, e_p2 })
}

/// ```prism
/// WrapAsJob: fn Ex, [OutTy], OutTy, OutTy -> Ex
/// ```
pub fn wrap_as_job(f_p0: &crate::lower::model::Ex, pts_p1: &Array<crate::lower::model::OutTy>, target_p2: &crate::lower::model::OutTy, a_p3: &crate::lower::model::OutTy) -> crate::lower::model::Ex {
    let names_p4 = each(&crate::check::errors::range0(&len(pts_p1)), &(|i_p8: &Nat| Text::from(format!("a{}", i_p8))));
    let pa_p5 = if &len(pts_p1) == &Nat::from(1u32) {
        crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaBind(Text::lit("a0"))), a_p3.clone())
    } else {
        crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaTuple(each(&names_p4, &(|nm_p9: &Text| crate::lower::model::Pa::PaBind(nm_p9.clone()))))), a_p3.clone())
    };
    let call_p6 = crate::lower::model::Ex::XApply(Rc::new(crate::lower::model::Ex::XVar(Text::lit("f"))), each(&names_p4, &(|nm_pa: &Text| crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XVar(nm_pa.clone()))))));
    let body_p7 = crate::lower::model::Ex::XBlock(Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(Text::lit("f")), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(Text::lit("f")))))]), Rc::new(crate::lower::model::Ex::XCall(Text::lit("once_job"), Array::from(vec![crate::lower::model::Ex::XClosure(true, Array::new(), Rc::new(crate::lower::model::Ex::XCtor(Text::lit("prism_rtl::Turn::Finished"), Array::from(vec![call_p6.clone()]))))]))));
    crate::lower::model::Ex::XBlock(Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(Text::lit("f")), f_p0.clone())]), Rc::new(crate::lower::model::Ex::XCast(Rc::new(crate::lower::model::Ex::XCall(Text::lit("Rc::new"), Array::from(vec![crate::lower::model::Ex::XClosure(true, Array::from(vec![pa_p5.clone()]), Rc::new(body_p7.clone()))]))), target_p2.clone())))
}

/// ```prism
/// NamedArgsOwned: unbounded fn Lx, Env, Text, [Arg] -> [Ex]
/// ```
pub fn named_args_owned(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, qk_p2: &Text, args_p3: &Array<crate::syntax::Arg>) -> Array<crate::lower::model::Ex> {
    let (ps_p4, _) = crate::lower::jobs::scheme_parts(lx_p0, qk_p2);
    run_to_end(each_job(crate::check::errors::range0(&len(args_p3)), {
        let args_p3 = args_p3.clone();
        let ps_p4 = ps_p4.clone();
        let lx_p0 = lx_p0.clone();
        let env_p1 = env_p1.clone();
        Rc::new(move |p0: Nat| {
            let args_p3 = args_p3.clone();
            let ps_p4 = ps_p4.clone();
            let lx_p0 = lx_p0.clone();
            let env_p1 = env_p1.clone();
            entered(once_job(move || {
                let i_p5 = p0;
                {
                    let a_p6 = or(&index(&args_p3, &i_p5), &crate::syntax::Arg { name: None, value: dummy_expr(), span: crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) } });
                    match crate::lower::types::peel(&or(&index(&ps_p4, &i_p5), &crate::check::types::Ty::TyErr)) {
                        crate::check::types::Ty::TyFn(crate::check::types::Col::CBound, _, _) => call_then(start_value_of(lx_p0.clone(), env_p1.clone(), a_p6.value.clone()), move |value_of_47884: crate::lower::types::Vl| prism_rtl::Turn::Finished(crate::lower::types::own(&value_of_47884))),
                        crate::check::types::Ty::TyFn(_, _, _) => prism_rtl::Turn::More(Rc::new(AsJobValue { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), e_p2: a_p6.value.clone() })),
                        _ => call_then(start_value_of(lx_p0.clone(), env_p1.clone(), a_p6.value.clone()), move |value_of_48007: crate::lower::types::Vl| prism_rtl::Turn::Finished(crate::lower::types::own(&value_of_48007))),
                    }
                }
            }))
        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
    }))
}

/// The step machine of `NamedArgsOwned`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// NamedArgsOwned: unbounded fn Lx, Env, Text, [Arg] -> [Ex]
/// ```
pub struct NamedArgsOwned {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub qk_p2: Text,
    pub args_p3: Array<crate::syntax::Arg>,
}

impl prism_rtl::Job<Array<crate::lower::model::Ex>> for NamedArgsOwned {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::lower::model::Ex>> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let qk_p2 = &self.qk_p2;
        let args_p3 = &self.args_p3;
        let (ps_p4, _) = crate::lower::jobs::scheme_parts(lx_p0, qk_p2);
        each_job(crate::check::errors::range0(&len(args_p3)), {
            let args_p3 = args_p3.clone();
            let ps_p4 = ps_p4.clone();
            let lx_p0 = lx_p0.clone();
            let env_p1 = env_p1.clone();
            Rc::new(move |p0: Nat| {
                let args_p3 = args_p3.clone();
                let ps_p4 = ps_p4.clone();
                let lx_p0 = lx_p0.clone();
                let env_p1 = env_p1.clone();
                entered(once_job(move || {
                    let i_p5 = p0;
                    {
                        let a_p6 = or(&index(&args_p3, &i_p5), &crate::syntax::Arg { name: None, value: dummy_expr(), span: crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) } });
                        match crate::lower::types::peel(&or(&index(&ps_p4, &i_p5), &crate::check::types::Ty::TyErr)) {
                            crate::check::types::Ty::TyFn(crate::check::types::Col::CBound, _, _) => call_then(start_value_of(lx_p0.clone(), env_p1.clone(), a_p6.value.clone()), move |value_of_47884: crate::lower::types::Vl| prism_rtl::Turn::Finished(crate::lower::types::own(&value_of_47884))),
                            crate::check::types::Ty::TyFn(_, _, _) => prism_rtl::Turn::More(Rc::new(AsJobValue { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), e_p2: a_p6.value.clone() })),
                            _ => call_then(start_value_of(lx_p0.clone(), env_p1.clone(), a_p6.value.clone()), move |value_of_48007: crate::lower::types::Vl| prism_rtl::Turn::Finished(crate::lower::types::own(&value_of_48007))),
                        }
                    }
                }))
            }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
        }).cycle()
    }
}

/// `Start NamedArgsOwned, x`: what the function value is when passed to `@Run`.
pub fn start_named_args_owned(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, qk_p2: Text, args_p3: Array<crate::syntax::Arg>) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Ex>>> {
    Rc::new(NamedArgsOwned { lx_p0, env_p1, qk_p2, args_p3 })
}

/// ```prism
/// StartArgs: unbounded fn Lx, Env, Vl, [Arg] -> [Ex]
/// ```
pub fn start_args(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, f_p2: &crate::lower::types::Vl, args_p3: &Array<crate::syntax::Arg>) -> Array<crate::lower::model::Ex> {
    let pts_p4 = 'm48219: {
        let scrutinee = &crate::lower::types::value_ty(f_p2);
        if let crate::lower::model::OutTy::OutJobFn(m48219_0_0, _) = scrutinee && let crate::lower::model::OutTy::OutTuple(ts_p5) = &**m48219_0_0 {
            break 'm48219 if &len(args_p3) == &Nat::from(1u32) {
                Array::from(vec![crate::lower::model::OutTy::OutTuple(ts_p5.clone())])
            } else {
                ts_p5.clone()
            };
        }
        if let crate::lower::model::OutTy::OutJobFn(a_p6, _) = scrutinee {
            break 'm48219 Array::from(vec![(**a_p6).clone()]);
        }
        Array::new()
    };
    run_to_end(each_job(crate::check::errors::range0(&len(args_p3)), {
        let args_p3 = args_p3.clone();
        let pts_p4 = pts_p4.clone();
        let lx_p0 = lx_p0.clone();
        let env_p1 = env_p1.clone();
        Rc::new(move |p0: Nat| {
            let args_p3 = args_p3.clone();
            let pts_p4 = pts_p4.clone();
            let lx_p0 = lx_p0.clone();
            let env_p1 = env_p1.clone();
            entered(once_job(move || {
                let i_p7 = p0;
                {
                    let a_p8 = or(&index(&args_p3, &i_p7), &crate::syntax::Arg { name: None, value: dummy_expr(), span: crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) } });
                    match or(&index(&pts_p4, &i_p7), &crate::lower::model::OutTy::OutUnit) {
                        crate::lower::model::OutTy::OutJobFn(_, _) => prism_rtl::Turn::More(Rc::new(AsJobValue { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), e_p2: a_p8.value.clone() })),
                        _ => call_then(start_value_of(lx_p0.clone(), env_p1.clone(), a_p8.value.clone()), move |value_of_48630: crate::lower::types::Vl| prism_rtl::Turn::Finished(crate::lower::types::own(&value_of_48630))),
                    }
                }
            }))
        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
    }))
}

/// The step machine of `StartArgs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// StartArgs: unbounded fn Lx, Env, Vl, [Arg] -> [Ex]
/// ```
pub struct StartArgs {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub f_p2: crate::lower::types::Vl,
    pub args_p3: Array<crate::syntax::Arg>,
}

impl prism_rtl::Job<Array<crate::lower::model::Ex>> for StartArgs {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::lower::model::Ex>> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let f_p2 = &self.f_p2;
        let args_p3 = &self.args_p3;
        let pts_p4 = 'm48219: {
            let scrutinee = &crate::lower::types::value_ty(f_p2);
            if let crate::lower::model::OutTy::OutJobFn(m48219_0_0, _) = scrutinee && let crate::lower::model::OutTy::OutTuple(ts_p5) = &**m48219_0_0 {
                break 'm48219 if &len(args_p3) == &Nat::from(1u32) {
                    Array::from(vec![crate::lower::model::OutTy::OutTuple(ts_p5.clone())])
                } else {
                    ts_p5.clone()
                };
            }
            if let crate::lower::model::OutTy::OutJobFn(a_p6, _) = scrutinee {
                break 'm48219 Array::from(vec![(**a_p6).clone()]);
            }
            Array::new()
        };
        each_job(crate::check::errors::range0(&len(args_p3)), {
            let args_p3 = args_p3.clone();
            let pts_p4 = pts_p4.clone();
            let lx_p0 = lx_p0.clone();
            let env_p1 = env_p1.clone();
            Rc::new(move |p0: Nat| {
                let args_p3 = args_p3.clone();
                let pts_p4 = pts_p4.clone();
                let lx_p0 = lx_p0.clone();
                let env_p1 = env_p1.clone();
                entered(once_job(move || {
                    let i_p7 = p0;
                    {
                        let a_p8 = or(&index(&args_p3, &i_p7), &crate::syntax::Arg { name: None, value: dummy_expr(), span: crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) } });
                        match or(&index(&pts_p4, &i_p7), &crate::lower::model::OutTy::OutUnit) {
                            crate::lower::model::OutTy::OutJobFn(_, _) => prism_rtl::Turn::More(Rc::new(AsJobValue { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), e_p2: a_p8.value.clone() })),
                            _ => call_then(start_value_of(lx_p0.clone(), env_p1.clone(), a_p8.value.clone()), move |value_of_48630: crate::lower::types::Vl| prism_rtl::Turn::Finished(crate::lower::types::own(&value_of_48630))),
                        }
                    }
                }))
            }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
        }).cycle()
    }
}

/// `Start StartArgs, x`: what the function value is when passed to `@Run`.
pub fn start_start_args(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, f_p2: crate::lower::types::Vl, args_p3: Array<crate::syntax::Arg>) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Ex>>> {
    Rc::new(StartArgs { lx_p0, env_p1, f_p2, args_p3 })
}

/// ```prism
/// PreludeVariant: fn Text, OutTy -> Text
/// ```
pub fn prelude_variant(name_p0: &Text, first_p1: &crate::lower::model::OutTy) -> Text {
    match first_p1 {
        crate::lower::model::OutTy::OutText => if name_p0 == &Text::lit("len") { Text::lit("len_text") } else { name_p0.clone() },
        crate::lower::model::OutTy::OutMap(_, _) => if crate::check::types::has_text(&Array::from(vec![Text::lit("len"), Text::lit("fold"), Text::lit("each"), Text::lit("filter")]), name_p0) {
            Text::from(format!("{}_map", name_p0))
        } else {
            name_p0.clone()
        },
        _ => name_p0.clone(),
    }
}

/// ```prism
/// FieldValue: unbounded fn Lx, Env, Expr, Text -> Vl
/// ```
pub fn field_value(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, r_p2: &crate::syntax::Expr, name_p3: &Text) -> crate::lower::types::Vl {
    let rv_p4 = value_of(lx_p0, env_p1, r_p2);
    let rty_p5 = crate::lower::types::peel(&crate::lower::type_at(lx_p0, &r_p2.span));
    let (ft_p8, rc_p9) = field_info(lx_p0, &rty_p5, name_p3);
    let f_p6 = crate::lower::snake(name_p3);
    let mode_p7 = if rc_p9 {
        crate::lower::types::Holding::RcOwned
    } else {
        crate::lower::types::Holding::Owned
    };
    match &rv_p4 {
        crate::lower::types::Vl::VlPlace(x_pa, _, _) => crate::lower::types::Vl::VlPlace(crate::lower::model::Ex::XField(Rc::new(x_pa.clone()), f_p6.clone()), mode_p7.clone(), ft_p8.clone()),
        crate::lower::types::Vl::VlOwned(x_pb, _) => crate::lower::types::Vl::VlPlace(crate::lower::model::Ex::XField(Rc::new(x_pb.clone()), f_p6.clone()), mode_p7.clone(), ft_p8.clone()),
    }
}

/// The step machine of `FieldValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FieldValue: unbounded fn Lx, Env, Expr, Text -> Vl
/// ```
pub struct FieldValue {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub r_p2: crate::syntax::Expr,
    pub name_p3: Text,
}

impl prism_rtl::Job<crate::lower::types::Vl> for FieldValue {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::types::Vl> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let r_p2 = &self.r_p2;
        let name_p3 = &self.name_p3;
        let env_p1 = env_p1.clone();
        let lx_p0 = lx_p0.clone();
        let name_p3 = name_p3.clone();
        let r_p2 = r_p2.clone();
        call_then(start_value_of(lx_p0.clone(), env_p1.clone(), r_p2.clone()), move |value_of_49125: crate::lower::types::Vl| {
            let rv_p4 = value_of_49125;
            let rty_p5 = crate::lower::types::peel(&crate::lower::type_at(&lx_p0, &r_p2.span));
            call_then(start_field_info(lx_p0.clone(), rty_p5.clone(), name_p3.clone()), move |field_info_49204: (crate::lower::model::OutTy, bool)| {
                let (ft_p8, rc_p9) = field_info_49204;
                let f_p6 = crate::lower::snake(&name_p3);
                let mode_p7 = if rc_p9 {
                    crate::lower::types::Holding::RcOwned
                } else {
                    crate::lower::types::Holding::Owned
                };
                match &rv_p4 {
                    crate::lower::types::Vl::VlPlace(x_pa, _, _) => prism_rtl::Turn::Finished(crate::lower::types::Vl::VlPlace(crate::lower::model::Ex::XField(Rc::new(x_pa.clone()), f_p6.clone()), mode_p7.clone(), ft_p8.clone())),
                    crate::lower::types::Vl::VlOwned(x_pb, _) => prism_rtl::Turn::Finished(crate::lower::types::Vl::VlPlace(crate::lower::model::Ex::XField(Rc::new(x_pb.clone()), f_p6.clone()), mode_p7.clone(), ft_p8.clone())),
                }
            })
        })
    }
}

/// `Start FieldValue, x`: what the function value is when passed to `@Run`.
pub fn start_field_value(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, r_p2: crate::syntax::Expr, name_p3: Text) -> Rc<dyn prism_rtl::Job<crate::lower::types::Vl>> {
    Rc::new(FieldValue { lx_p0, env_p1, r_p2, name_p3 })
}

/// ```prism
/// FieldInfo: unbounded fn Lx, Ty, Text -> ((OutTy, Bool))
/// ```
pub fn field_info(lx_p0: &crate::lower::Lx, rty_p1: &crate::check::types::Ty, name_p2: &Text) -> (crate::lower::model::OutTy, bool) {
    match rty_p1 {
        crate::check::types::Ty::TyCon(n_p3, args_p4) => match get(&lx_p0.g.ctors, n_p3) {
            Some(c_p5) => {
                let fix_o6 = fold(&crate::check::errors::range0(&len(&c_p5.fields)), &None, &(|found_o7: &Option<Nat>, i_p8: &Nat| if &or(&index(&c_p5.fields, i_p8), &Text::lit("")) == name_p2 {
                    Some(i_p8.clone())
                } else {
                    found_o7.clone()
                }));
                match &fix_o6 {
                    Some(i_p9) => {
                        let ft_pa = or(&index(&c_p5.args, i_p9), &crate::check::types::Ty::TyErr);
                        let inst_pb = instantiated(&ft_pa, &c_p5.params, args_p4);
                        (crate::lower::types::out_ty_of(lx_p0, &inst_pb), crate::lower::types::rc_field(lx_p0, &c_p5.name, i_p9))
                    },
                    None => (crate::lower::model::OutTy::OutUnknown(Text::from(format!("a field {}", name_p2))), false),
                }
            },
            None => (crate::lower::model::OutTy::OutUnknown(Text::from(format!("a field {}", name_p2))), false),
        },
        _ => (crate::lower::model::OutTy::OutUnknown(Text::from(format!("a field {} of a non-record", name_p2))), false),
    }
}

/// The step machine of `FieldInfo`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FieldInfo: unbounded fn Lx, Ty, Text -> ((OutTy, Bool))
/// ```
pub struct FieldInfo {
    pub lx_p0: crate::lower::Lx,
    pub rty_p1: crate::check::types::Ty,
    pub name_p2: Text,
}

impl prism_rtl::Job<(crate::lower::model::OutTy, bool)> for FieldInfo {
    fn cycle(&self) -> prism_rtl::Turn<(crate::lower::model::OutTy, bool)> {
        let lx_p0 = &self.lx_p0;
        let rty_p1 = &self.rty_p1;
        let name_p2 = &self.name_p2;
        match rty_p1 {
            crate::check::types::Ty::TyCon(n_p3, args_p4) => match get(&lx_p0.g.ctors, n_p3) {
                Some(c_p5) => {
                    let fix_o6 = fold(&crate::check::errors::range0(&len(&c_p5.fields)), &None, &(|found_o7: &Option<Nat>, i_p8: &Nat| if &or(&index(&c_p5.fields, i_p8), &Text::lit("")) == name_p2 {
                        Some(i_p8.clone())
                    } else {
                        found_o7.clone()
                    }));
                    match &fix_o6 {
                        Some(i_p9) => {
                            let ft_pa = or(&index(&c_p5.args, i_p9), &crate::check::types::Ty::TyErr);
                            let args_p4 = args_p4.clone();
                            let i_p9 = i_p9.clone();
                            let lx_p0 = lx_p0.clone();
                            let name_p2 = name_p2.clone();
                            call_then(start_instantiated(ft_pa.clone(), c_p5.params.clone(), args_p4.clone()), move |instantiated_49892: crate::check::types::Ty| {
                                let inst_pb = instantiated_49892;
                                call_then(crate::lower::types::start_out_ty_of(lx_p0.clone(), inst_pb.clone()), move |out_ty_of_49947: crate::lower::model::OutTy| prism_rtl::Turn::Finished((out_ty_of_49947, crate::lower::types::rc_field(&lx_p0, &c_p5.name, &i_p9))))
                            })
                        },
                        None => prism_rtl::Turn::Finished((crate::lower::model::OutTy::OutUnknown(Text::from(format!("a field {}", name_p2))), false)),
                    }
                },
                None => prism_rtl::Turn::Finished((crate::lower::model::OutTy::OutUnknown(Text::from(format!("a field {}", name_p2))), false)),
            },
            _ => prism_rtl::Turn::Finished((crate::lower::model::OutTy::OutUnknown(Text::from(format!("a field {} of a non-record", name_p2))), false)),
        }
    }
}

/// `Start FieldInfo, x`: what the function value is when passed to `@Run`.
pub fn start_field_info(lx_p0: crate::lower::Lx, rty_p1: crate::check::types::Ty, name_p2: Text) -> Rc<dyn prism_rtl::Job<(crate::lower::model::OutTy, bool)>> {
    Rc::new(FieldInfo { lx_p0, rty_p1, name_p2 })
}

/// ```prism
/// Instantiated: unbounded fn Ty, [Text], [Ty] -> Ty
/// ```
pub fn instantiated(t_p0: &crate::check::types::Ty, params_p1: &Array<Text>, args_p2: &Array<crate::check::types::Ty>) -> crate::check::types::Ty {
    match t_p0 {
        crate::check::types::Ty::TyQ(q_p3) => {
            let hit_o4 = fold(&crate::check::errors::range0(&len(params_p1)), &None, &(|found_o5: &Option<crate::check::types::Ty>, i_p6: &Nat| if &or(&index(params_p1, i_p6), &Text::lit("")) == q_p3 {
                index(args_p2, i_p6)
            } else {
                found_o5.clone()
            }));
            or(&hit_o4, t_p0)
        },
        crate::check::types::Ty::TyCon(n_p7, xs_p8) => crate::check::types::Ty::TyCon(n_p7.clone(), run_to_end(each_job(xs_p8.clone(), {
            let params_p1 = params_p1.clone();
            let args_p2 = args_p2.clone();
            Rc::new(move |p0: crate::check::types::Ty| {
                let params_p1 = params_p1.clone();
                let args_p2 = args_p2.clone();
                entered(once_job(move || {
                    let x_p9 = p0;
                    prism_rtl::Turn::More(Rc::new(Instantiated { t_p0: x_p9.clone(), params_p1: params_p1.clone(), args_p2: args_p2.clone() }))
                }))
            }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
        }))),
        crate::check::types::Ty::TyFn(c_pa, ps_pb, res_pc) => crate::check::types::Ty::TyFn(c_pa.clone(), run_to_end(each_job(ps_pb.clone(), {
            let params_p1 = params_p1.clone();
            let args_p2 = args_p2.clone();
            Rc::new(move |p0: crate::check::types::Ty| {
                let params_p1 = params_p1.clone();
                let args_p2 = args_p2.clone();
                entered(once_job(move || {
                    let x_pd = p0;
                    prism_rtl::Turn::More(Rc::new(Instantiated { t_p0: x_pd.clone(), params_p1: params_p1.clone(), args_p2: args_p2.clone() }))
                }))
            }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
        })), Rc::new(instantiated(&**res_pc, params_p1, args_p2))),
        crate::check::types::Ty::TyTuple(ts_pe) => crate::check::types::Ty::TyTuple(run_to_end(each_job(ts_pe.clone(), {
            let params_p1 = params_p1.clone();
            let args_p2 = args_p2.clone();
            Rc::new(move |p0: crate::check::types::Ty| {
                let params_p1 = params_p1.clone();
                let args_p2 = args_p2.clone();
                entered(once_job(move || {
                    let x_pf = p0;
                    prism_rtl::Turn::More(Rc::new(Instantiated { t_p0: x_pf.clone(), params_p1: params_p1.clone(), args_p2: args_p2.clone() }))
                }))
            }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
        }))),
        crate::check::types::Ty::TyArray(e_pg) => crate::check::types::Ty::TyArray(Rc::new(instantiated(&**e_pg, params_p1, args_p2))),
        crate::check::types::Ty::TyMap(k_ph, v_pi) => crate::check::types::Ty::TyMap(Rc::new(instantiated(&**k_ph, params_p1, args_p2)), Rc::new(instantiated(&**v_pi, params_p1, args_p2))),
        crate::check::types::Ty::TySig(s_pj, i_pk) => crate::check::types::Ty::TySig(s_pj.clone(), Rc::new(instantiated(&**i_pk, params_p1, args_p2))),
        _ => t_p0.clone(),
    }
}

/// The step machine of `Instantiated`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Instantiated: unbounded fn Ty, [Text], [Ty] -> Ty
/// ```
pub struct Instantiated {
    pub t_p0: crate::check::types::Ty,
    pub params_p1: Array<Text>,
    pub args_p2: Array<crate::check::types::Ty>,
}

impl prism_rtl::Job<crate::check::types::Ty> for Instantiated {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::Ty> {
        let t_p0 = &self.t_p0;
        let params_p1 = &self.params_p1;
        let args_p2 = &self.args_p2;
        match t_p0 {
            crate::check::types::Ty::TyQ(q_p3) => {
                let hit_o4 = fold(&crate::check::errors::range0(&len(params_p1)), &None, &(|found_o5: &Option<crate::check::types::Ty>, i_p6: &Nat| if &or(&index(params_p1, i_p6), &Text::lit("")) == q_p3 {
                    index(args_p2, i_p6)
                } else {
                    found_o5.clone()
                }));
                prism_rtl::Turn::Finished(or(&hit_o4, t_p0))
            },
            crate::check::types::Ty::TyCon(n_p7, xs_p8) => {
                let args_p2 = args_p2.clone();
                let n_p7 = n_p7.clone();
                let params_p1 = params_p1.clone();
                let xs_p8 = xs_p8.clone();
                call_value(each_job(xs_p8.clone(), {
                    let params_p1 = params_p1.clone();
                    let args_p2 = args_p2.clone();
                    Rc::new(move |p0: crate::check::types::Ty| {
                        let params_p1 = params_p1.clone();
                        let args_p2 = args_p2.clone();
                        entered(once_job(move || {
                            let x_p9 = p0;
                            prism_rtl::Turn::More(Rc::new(Instantiated { t_p0: x_p9.clone(), params_p1: params_p1.clone(), args_p2: args_p2.clone() }))
                        }))
                    }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
                }), move |each_50527: Array<crate::check::types::Ty>| prism_rtl::Turn::Finished(crate::check::types::Ty::TyCon(n_p7.clone(), each_50527)))
            },
            crate::check::types::Ty::TyFn(c_pa, ps_pb, res_pc) => {
                let args_p2 = args_p2.clone();
                let c_pa = c_pa.clone();
                let params_p1 = params_p1.clone();
                let ps_pb = ps_pb.clone();
                let res_pc = (**res_pc).clone();
                call_value(each_job(ps_pb.clone(), {
                    let params_p1 = params_p1.clone();
                    let args_p2 = args_p2.clone();
                    Rc::new(move |p0: crate::check::types::Ty| {
                        let params_p1 = params_p1.clone();
                        let args_p2 = args_p2.clone();
                        entered(once_job(move || {
                            let x_pd = p0;
                            prism_rtl::Turn::More(Rc::new(Instantiated { t_p0: x_pd.clone(), params_p1: params_p1.clone(), args_p2: args_p2.clone() }))
                        }))
                    }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
                }), move |each_50601: Array<crate::check::types::Ty>| call_then(start_instantiated(res_pc.clone(), params_p1.clone(), args_p2.clone()), move |instantiated_50647: crate::check::types::Ty| prism_rtl::Turn::Finished(crate::check::types::Ty::TyFn(c_pa.clone(), each_50601, Rc::new(instantiated_50647)))))
            },
            crate::check::types::Ty::TyTuple(ts_pe) => {
                let args_p2 = args_p2.clone();
                let params_p1 = params_p1.clone();
                let ts_pe = ts_pe.clone();
                call_value(each_job(ts_pe.clone(), {
                    let params_p1 = params_p1.clone();
                    let args_p2 = args_p2.clone();
                    Rc::new(move |p0: crate::check::types::Ty| {
                        let params_p1 = params_p1.clone();
                        let args_p2 = args_p2.clone();
                        entered(once_job(move || {
                            let x_pf = p0;
                            prism_rtl::Turn::More(Rc::new(Instantiated { t_p0: x_pf.clone(), params_p1: params_p1.clone(), args_p2: args_p2.clone() }))
                        }))
                    }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
                }), move |each_50704: Array<crate::check::types::Ty>| prism_rtl::Turn::Finished(crate::check::types::Ty::TyTuple(each_50704)))
            },
            crate::check::types::Ty::TyArray(e_pg) => {
                let args_p2 = args_p2.clone();
                let e_pg = (**e_pg).clone();
                let params_p1 = params_p1.clone();
                call_then(start_instantiated(e_pg.clone(), params_p1.clone(), args_p2.clone()), move |instantiated_50772: crate::check::types::Ty| prism_rtl::Turn::Finished(crate::check::types::Ty::TyArray(Rc::new(instantiated_50772))))
            },
            crate::check::types::Ty::TyMap(k_ph, v_pi) => {
                let args_p2 = args_p2.clone();
                let k_ph = (**k_ph).clone();
                let params_p1 = params_p1.clone();
                let v_pi = (**v_pi).clone();
                call_then(start_instantiated(k_ph.clone(), params_p1.clone(), args_p2.clone()), move |instantiated_50825: crate::check::types::Ty| call_then(start_instantiated(v_pi.clone(), params_p1.clone(), args_p2.clone()), move |instantiated_50857: crate::check::types::Ty| prism_rtl::Turn::Finished(crate::check::types::Ty::TyMap(Rc::new(instantiated_50825), Rc::new(instantiated_50857)))))
            },
            crate::check::types::Ty::TySig(s_pj, i_pk) => {
                let args_p2 = args_p2.clone();
                let i_pk = (**i_pk).clone();
                let params_p1 = params_p1.clone();
                let s_pj = s_pj.clone();
                call_then(start_instantiated(i_pk.clone(), params_p1.clone(), args_p2.clone()), move |instantiated_50913: crate::check::types::Ty| prism_rtl::Turn::Finished(crate::check::types::Ty::TySig(s_pj.clone(), Rc::new(instantiated_50913))))
            },
            _ => prism_rtl::Turn::Finished(t_p0.clone()),
        }
    }
}

/// `Start Instantiated, x`: what the function value is when passed to `@Run`.
pub fn start_instantiated(t_p0: crate::check::types::Ty, params_p1: Array<Text>, args_p2: Array<crate::check::types::Ty>) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>> {
    Rc::new(Instantiated { t_p0, params_p1, args_p2 })
}

/// ```prism
/// IndexValue: unbounded fn Lx, Env, Expr, Expr, OutTy -> Vl
/// ```
pub fn index_value(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, r_p2: &crate::syntax::Expr, i_p3: &crate::syntax::Expr, t_p4: &crate::lower::model::OutTy) -> crate::lower::types::Vl {
    let rt_p5 = crate::lower::types::out_ty_of(lx_p0, &crate::lower::types::peel(&crate::lower::type_at(lx_p0, &r_p2.span)));
    let f_p6 = match &rt_p5 {
        crate::lower::model::OutTy::OutMap(_, _) => Text::lit("get"),
        _ => Text::lit("index"),
    };
    crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCall(f_p6.clone(), Array::from(vec![argument(lx_p0, env_p1, r_p2), argument(lx_p0, env_p1, i_p3)])), crate::lower::model::OutTy::OutOpt(Rc::new(t_p4.clone())))
}

/// The step machine of `IndexValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// IndexValue: unbounded fn Lx, Env, Expr, Expr, OutTy -> Vl
/// ```
pub struct IndexValue {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub r_p2: crate::syntax::Expr,
    pub i_p3: crate::syntax::Expr,
    pub t_p4: crate::lower::model::OutTy,
}

impl prism_rtl::Job<crate::lower::types::Vl> for IndexValue {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::types::Vl> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let r_p2 = &self.r_p2;
        let i_p3 = &self.i_p3;
        let t_p4 = &self.t_p4;
        let env_p1 = env_p1.clone();
        let i_p3 = i_p3.clone();
        let lx_p0 = lx_p0.clone();
        let r_p2 = r_p2.clone();
        let t_p4 = t_p4.clone();
        call_then(crate::lower::types::start_out_ty_of(lx_p0.clone(), crate::lower::types::peel(&crate::lower::type_at(&lx_p0, &r_p2.span))), move |out_ty_of_51156: crate::lower::model::OutTy| {
            let rt_p5 = out_ty_of_51156;
            let f_p6 = match &rt_p5 {
                crate::lower::model::OutTy::OutMap(_, _) => Text::lit("get"),
                _ => Text::lit("index"),
            };
            call_then(start_argument(lx_p0.clone(), env_p1.clone(), r_p2.clone()), move |argument_51306: crate::lower::model::Ex| call_then(start_argument(lx_p0.clone(), env_p1.clone(), i_p3.clone()), move |argument_51329: crate::lower::model::Ex| prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCall(f_p6.clone(), Array::from(vec![argument_51306, argument_51329])), crate::lower::model::OutTy::OutOpt(Rc::new(t_p4.clone()))))))
        })
    }
}

/// `Start IndexValue, x`: what the function value is when passed to `@Run`.
pub fn start_index_value(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, r_p2: crate::syntax::Expr, i_p3: crate::syntax::Expr, t_p4: crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<crate::lower::types::Vl>> {
    Rc::new(IndexValue { lx_p0, env_p1, r_p2, i_p3, t_p4 })
}

/// ```prism
/// ReadNames: unbounded fn [Expr] -> [Text]
/// ```
pub fn read_names(es_p0: &Array<crate::syntax::Expr>) -> Array<Text> {
    fold(es_p0, &Array::new(), &(|acc_p1: &Array<Text>, x_p2: &crate::syntax::Expr| match &*x_p2.kind {
        crate::syntax::ExprKind::EName(n_p3) => if &len(&n_p3.path_) == &Nat::from(1u32) {
            crate::check::types::add_text(acc_p1, &crate::check::env::sname_key(n_p3))
        } else {
            acc_p1.clone()
        },
        _ => acc_p1.clone(),
    }))
}

/// The step machine of `ReadNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ReadNames: unbounded fn [Expr] -> [Text]
/// ```
pub struct ReadNames {
    pub es_p0: Array<crate::syntax::Expr>,
}

impl prism_rtl::Job<Array<Text>> for ReadNames {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let es_p0 = &self.es_p0;
        prism_rtl::Turn::Finished(fold(es_p0, &Array::new(), &(|acc_p1: &Array<Text>, x_p2: &crate::syntax::Expr| match &*x_p2.kind {
            crate::syntax::ExprKind::EName(n_p3) => if &len(&n_p3.path_) == &Nat::from(1u32) {
                crate::check::types::add_text(acc_p1, &crate::check::env::sname_key(n_p3))
            } else {
                acc_p1.clone()
            },
            _ => acc_p1.clone(),
        })))
    }
}

/// `Start ReadNames, x`: what the function value is when passed to `@Run`.
pub fn start_read_names(es_p0: Array<crate::syntax::Expr>) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(ReadNames { es_p0 })
}

/// ```prism
/// LambdaExprs: unbounded fn LambdaBody -> [Expr]
/// ```
pub fn lambda_exprs(lambda_body0: &crate::syntax::LambdaBody) -> Array<crate::syntax::Expr> {
    match lambda_body0 {
        crate::syntax::LambdaBody::LbExpr(x_p0) => crate::check::typed::print::exprs_in(&**x_p0),
        crate::syntax::LambdaBody::LbBlock(b_p1) => crate::check::typed::print::block_exprs(b_p1),
    }
}

/// The step machine of `LambdaExprs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LambdaExprs: unbounded fn LambdaBody -> [Expr]
/// ```
pub struct LambdaExprs {
    pub lambda_body0: crate::syntax::LambdaBody,
}

impl prism_rtl::Job<Array<crate::syntax::Expr>> for LambdaExprs {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::syntax::Expr>> {
        let lambda_body0 = &self.lambda_body0;
        match lambda_body0 {
            crate::syntax::LambdaBody::LbExpr(x_p0) => prism_rtl::Turn::More(Rc::new(crate::check::typed::print::ExprsIn { e_p0: (**x_p0).clone() })),
            crate::syntax::LambdaBody::LbBlock(b_p1) => prism_rtl::Turn::More(Rc::new(crate::check::typed::print::BlockExprs { b_p0: b_p1.clone() })),
        }
    }
}

/// `Start LambdaExprs, x`: what the function value is when passed to `@Run`.
pub fn start_lambda_exprs(lambda_body0: crate::syntax::LambdaBody) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>> {
    Rc::new(LambdaExprs { lambda_body0 })
}

/// ```prism
/// FreeReads: unbounded fn [Expr], [(([Text], Range))] -> [Text]
/// ```
pub fn free_reads(es_p0: &Array<crate::syntax::Expr>, outer_p1: &Array<(Array<Text>, crate::syntax::Range)>) -> Array<Text> {
    let scopes_p2 = run_to_end(fold_job(es_p0.clone(), outer_p1.clone(), Rc::new(move |(p0, p1): (Array<(Array<Text>, crate::syntax::Range)>, crate::syntax::Expr)| entered(once_job(move || {
        let acc_p3 = p0;
        let e_p4 = p1;
        call_then(start_scopes_of(e_p4.clone()), move |scopes_of_52052: Array<(Array<Text>, crate::syntax::Range)>| prism_rtl::Turn::Finished(append(&acc_p3, &scopes_of_52052)))
    }))) as Rc<dyn Fn((Array<(Array<Text>, crate::syntax::Range)>, crate::syntax::Expr)) -> Rc<dyn prism_rtl::Job<Array<(Array<Text>, crate::syntax::Range)>>>>));
    fold(es_p0, &Array::new(), &(|acc_p5: &Array<Text>, e_p6: &crate::syntax::Expr| match &*e_p6.kind {
        crate::syntax::ExprKind::EName(n_p7) => {
            let nkey_p8 = crate::check::env::sname_key(n_p7);
            let hidden_p9 = fold(&scopes_p2, &false, &(|seen_pa: &bool, (names_pb, r_pc): &(Array<Text>, crate::syntax::Range)| *seen_pa || ((crate::check::types::has_text(names_pb, &nkey_p8) && (&r_pc.start <= &e_p6.span.start)) && (&e_p6.span.start < &r_pc.end))));
            if (&len(&n_p7.path_) != &Nat::from(1u32)) || hidden_p9 {
                acc_p5.clone()
            } else {
                crate::check::types::add_text(acc_p5, &nkey_p8)
            }
        },
        _ => acc_p5.clone(),
    }))
}

/// The step machine of `FreeReads`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FreeReads: unbounded fn [Expr], [(([Text], Range))] -> [Text]
/// ```
pub struct FreeReads {
    pub es_p0: Array<crate::syntax::Expr>,
    pub outer_p1: Array<(Array<Text>, crate::syntax::Range)>,
}

impl prism_rtl::Job<Array<Text>> for FreeReads {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let es_p0 = &self.es_p0;
        let outer_p1 = &self.outer_p1;
        let es_p0 = es_p0.clone();
        let outer_p1 = outer_p1.clone();
        call_value(fold_job(es_p0.clone(), outer_p1.clone(), Rc::new(move |(p0, p1): (Array<(Array<Text>, crate::syntax::Range)>, crate::syntax::Expr)| entered(once_job(move || {
            let acc_p3 = p0;
            let e_p4 = p1;
            call_then(start_scopes_of(e_p4.clone()), move |scopes_of_52052: Array<(Array<Text>, crate::syntax::Range)>| prism_rtl::Turn::Finished(append(&acc_p3, &scopes_of_52052)))
        }))) as Rc<dyn Fn((Array<(Array<Text>, crate::syntax::Range)>, crate::syntax::Expr)) -> Rc<dyn prism_rtl::Job<Array<(Array<Text>, crate::syntax::Range)>>>>), move |fold_52013: Array<(Array<Text>, crate::syntax::Range)>| {
            let scopes_p2 = fold_52013;
            prism_rtl::Turn::Finished(fold(&es_p0, &Array::new(), &(|acc_p5: &Array<Text>, e_p6: &crate::syntax::Expr| match &*e_p6.kind {
                crate::syntax::ExprKind::EName(n_p7) => {
                    let nkey_p8 = crate::check::env::sname_key(n_p7);
                    let hidden_p9 = fold(&scopes_p2, &false, &(|seen_pa: &bool, (names_pb, r_pc): &(Array<Text>, crate::syntax::Range)| *seen_pa || ((crate::check::types::has_text(names_pb, &nkey_p8) && (&r_pc.start <= &e_p6.span.start)) && (&e_p6.span.start < &r_pc.end))));
                    if (&len(&n_p7.path_) != &Nat::from(1u32)) || hidden_p9 {
                        acc_p5.clone()
                    } else {
                        crate::check::types::add_text(acc_p5, &nkey_p8)
                    }
                },
                _ => acc_p5.clone(),
            })))
        })
    }
}

/// `Start FreeReads, x`: what the function value is when passed to `@Run`.
pub fn start_free_reads(es_p0: Array<crate::syntax::Expr>, outer_p1: Array<(Array<Text>, crate::syntax::Range)>) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(FreeReads { es_p0, outer_p1 })
}

/// ```prism
/// ScopesOf: unbounded fn Expr -> [(([Text], Range))]
/// ```
pub fn scopes_of(e_p0: &crate::syntax::Expr) -> Array<(Array<Text>, crate::syntax::Range)> {
    match &*e_p0.kind {
        crate::syntax::ExprKind::ELambda(ps_o1, body_p2) => {
            let names_p3 = run_to_end(fold_job(or(ps_o1, &Array::new()), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Pattern_)| entered(once_job(move || {
                let acc_p5 = p0;
                let q_p6 = p1;
                call_then(crate::check::env::names::start_pattern_names(q_p6.clone()), move |pattern_names_52663: Array<Text>| prism_rtl::Turn::Finished(append(&acc_p5, &pattern_names_52663)))
            }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Pattern_)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>));
            let inner_p4 = match &**body_p2 {
                crate::syntax::LambdaBody::LbBlock(b_p7) => block_scopes(b_p7),
                _ => Array::new(),
            };
            push(&inner_p4, &(names_p3.clone(), e_p0.span.clone()))
        },
        crate::syntax::ExprKind::EMatch(_, arms_p8) => run_to_end(fold_job(arms_p8.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<(Array<Text>, crate::syntax::Range)>, crate::syntax::Arm)| entered(once_job(move || {
            let acc_p9 = p0;
            let a_pa = p1;
            {
                let names_pb = match &a_pa.pattern {
                    Some(q_pc) => crate::check::env::names::pattern_names(q_pc),
                    None => Array::new(),
                };
                prism_rtl::Turn::Finished(append(&push(&acc_p9, &(names_pb.clone(), a_pa.span.clone())), &block_scopes(&a_pa.body)))
            }
        }))) as Rc<dyn Fn((Array<(Array<Text>, crate::syntax::Range)>, crate::syntax::Arm)) -> Rc<dyn prism_rtl::Job<Array<(Array<Text>, crate::syntax::Range)>>>>)),
        crate::syntax::ExprKind::EIf(c_pd, t_pe, el_of) => {
            let bound_pg = match &**c_pd {
                crate::syntax::Cond::CondBind(q_pi, _, _) => Array::from(vec![(crate::check::env::names::pattern_names(q_pi), t_pe.span.clone())]),
                _ => Array::new(),
            };
            let else_scopes_ph = match el_of {
                Some(b_pj) => block_scopes(b_pj),
                None => Array::new(),
            };
            append(&append(&bound_pg, &block_scopes(t_pe)), &else_scopes_ph)
        },
        crate::syntax::ExprKind::EFor(binders_ok, _, b_pl) => {
            let names_pm = match binders_ok {
                Some(fb_pn) => append(&crate::check::env::names::pattern_names(&fb_pn.first), &opt_pattern_names(&fb_pn.second)),
                None => Array::new(),
            };
            push(&block_scopes(b_pl), &(names_pm.clone(), b_pl.span.clone()))
        },
        crate::syntax::ExprKind::ERebuild(_, b_po) => block_scopes(b_po),
        crate::syntax::ExprKind::EGiven(b_pp) => block_scopes(b_pp),
        crate::syntax::ExprKind::EUpdate(_, b_pq) => block_scopes(b_pq),
        crate::syntax::ExprKind::EWidgetBlock(b_pr) => block_scopes(b_pr),
        crate::syntax::ExprKind::EMonad(_, b_ps) => block_scopes(b_ps),
        _ => Array::new(),
    }
}

/// The step machine of `ScopesOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ScopesOf: unbounded fn Expr -> [(([Text], Range))]
/// ```
pub struct ScopesOf {
    pub e_p0: crate::syntax::Expr,
}

impl prism_rtl::Job<Array<(Array<Text>, crate::syntax::Range)>> for ScopesOf {
    fn cycle(&self) -> prism_rtl::Turn<Array<(Array<Text>, crate::syntax::Range)>> {
        let e_p0 = &self.e_p0;
        match &*e_p0.kind {
            crate::syntax::ExprKind::ELambda(ps_o1, body_p2) => {
                let ps_o1 = ps_o1.clone();
                let body_p2 = (**body_p2).clone();
                let e_p0 = e_p0.clone();
                call_value(fold_job(or(&ps_o1, &Array::new()), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Pattern_)| entered(once_job(move || {
                    let acc_p5 = p0;
                    let q_p6 = p1;
                    call_then(crate::check::env::names::start_pattern_names(q_p6.clone()), move |pattern_names_52663: Array<Text>| prism_rtl::Turn::Finished(append(&acc_p5, &pattern_names_52663)))
                }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Pattern_)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>), move |fold_52613: Array<Text>| {
                    let names_p3 = fold_52613;
                    let inner_p4 = match &body_p2 {
                        crate::syntax::LambdaBody::LbBlock(b_p7) => block_scopes(b_p7),
                        _ => Array::new(),
                    };
                    prism_rtl::Turn::Finished(push(&inner_p4, &(names_p3.clone(), e_p0.span.clone())))
                })
            },
            crate::syntax::ExprKind::EMatch(_, arms_p8) => fold_job(arms_p8.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<(Array<Text>, crate::syntax::Range)>, crate::syntax::Arm)| entered(once_job(move || {
                let acc_p9 = p0;
                let a_pa = p1;
                {
                    let names_pb = match &a_pa.pattern {
                        Some(q_pc) => crate::check::env::names::pattern_names(q_pc),
                        None => Array::new(),
                    };
                    prism_rtl::Turn::Finished(append(&push(&acc_p9, &(names_pb.clone(), a_pa.span.clone())), &block_scopes(&a_pa.body)))
                }
            }))) as Rc<dyn Fn((Array<(Array<Text>, crate::syntax::Range)>, crate::syntax::Arm)) -> Rc<dyn prism_rtl::Job<Array<(Array<Text>, crate::syntax::Range)>>>>).cycle(),
            crate::syntax::ExprKind::EIf(c_pd, t_pe, el_of) => {
                let bound_pg = match &**c_pd {
                    crate::syntax::Cond::CondBind(q_pi, _, _) => Array::from(vec![(crate::check::env::names::pattern_names(q_pi), t_pe.span.clone())]),
                    _ => Array::new(),
                };
                let else_scopes_ph = match el_of {
                    Some(b_pj) => block_scopes(b_pj),
                    None => Array::new(),
                };
                prism_rtl::Turn::Finished(append(&append(&bound_pg, &block_scopes(t_pe)), &else_scopes_ph))
            },
            crate::syntax::ExprKind::EFor(binders_ok, _, b_pl) => {
                let names_pm = match binders_ok {
                    Some(fb_pn) => append(&crate::check::env::names::pattern_names(&fb_pn.first), &opt_pattern_names(&fb_pn.second)),
                    None => Array::new(),
                };
                prism_rtl::Turn::Finished(push(&block_scopes(b_pl), &(names_pm.clone(), b_pl.span.clone())))
            },
            crate::syntax::ExprKind::ERebuild(_, b_po) => prism_rtl::Turn::Finished(block_scopes(b_po)),
            crate::syntax::ExprKind::EGiven(b_pp) => prism_rtl::Turn::Finished(block_scopes(b_pp)),
            crate::syntax::ExprKind::EUpdate(_, b_pq) => prism_rtl::Turn::Finished(block_scopes(b_pq)),
            crate::syntax::ExprKind::EWidgetBlock(b_pr) => prism_rtl::Turn::Finished(block_scopes(b_pr)),
            crate::syntax::ExprKind::EMonad(_, b_ps) => prism_rtl::Turn::Finished(block_scopes(b_ps)),
            _ => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start ScopesOf, x`: what the function value is when passed to `@Run`.
pub fn start_scopes_of(e_p0: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<Array<(Array<Text>, crate::syntax::Range)>>> {
    Rc::new(ScopesOf { e_p0 })
}

/// ```prism
/// OptPatternNames: unbounded fn ?Pattern -> [Text]
/// ```
pub fn opt_pattern_names(opt0: &Option<crate::syntax::Pattern_>) -> Array<Text> {
    match opt0 {
        Some(q_p0) => crate::check::env::names::pattern_names(q_p0),
        None => Array::new(),
    }
}

/// ```prism
/// BlockScopes: unbounded fn Block -> [(([Text], Range))]
/// ```
pub fn block_scopes(b_p0: &crate::syntax::Block) -> Array<(Array<Text>, crate::syntax::Range)> {
    run_to_end(fold_job(b_p0.stmts.clone(), Array::new(), {
        let b_p0 = b_p0.clone();
        Rc::new(move |(p0, p1): (Array<(Array<Text>, crate::syntax::Range)>, crate::syntax::Stmt)| {
            let b_p0 = b_p0.clone();
            entered(once_job(move || {
                let acc_p1 = p0;
                let s_p2 = p1;
                call_then(crate::check::blocks::start_group_defs(s_p2.clone()), move |group_defs_54099: Array<Text>| {
                    let own_p3 = push(&acc_p1, &(group_defs_54099, crate::syntax::Range { start: s_p2.span.start.clone(), end: b_p0.span.end.clone() }));
                    match &s_p2.kind {
                        crate::syntax::StmtKind::SFn(f_p4) => {
                            let f_p4 = f_p4.clone();
                            call_value(fold_job(f_p4.params.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Pattern_)| entered(once_job(move || {
                                let ps_p5 = p0;
                                let q_p6 = p1;
                                call_then(crate::check::env::names::start_pattern_names(q_p6.clone()), move |pattern_names_54257: Array<Text>| prism_rtl::Turn::Finished(append(&ps_p5, &pattern_names_54257)))
                            }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Pattern_)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>), move |fold_54215: Array<Text>| prism_rtl::Turn::Finished(push(&own_p3, &(fold_54215, f_p4.span.clone()))))
                        },
                        _ => prism_rtl::Turn::Finished(own_p3.clone()),
                    }
                })
            }))
        }) as Rc<dyn Fn((Array<(Array<Text>, crate::syntax::Range)>, crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<Array<(Array<Text>, crate::syntax::Range)>>>>
    }))
}

/// ```prism
/// LambdaReads: unbounded fn [Pattern], LambdaBody -> [Text]
/// ```
pub fn lambda_reads(ps_p0: &Array<crate::syntax::Pattern_>, body_p1: &crate::syntax::LambdaBody) -> Array<Text> {
    let own_p2 = run_to_end(fold_job(ps_p0.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Pattern_)| entered(once_job(move || {
        let acc_p3 = p0;
        let q_p4 = p1;
        call_then(crate::check::env::names::start_pattern_names(q_p4.clone()), move |pattern_names_54601: Array<Text>| prism_rtl::Turn::Finished(append(&acc_p3, &pattern_names_54601)))
    }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Pattern_)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>));
    filter(&free_reads(&lambda_exprs(body_p1), &Array::new()), &(|n_p5: &Text| !crate::check::types::has_text(&own_p2, n_p5)))
}

/// The step machine of `LambdaReads`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LambdaReads: unbounded fn [Pattern], LambdaBody -> [Text]
/// ```
pub struct LambdaReads {
    pub ps_p0: Array<crate::syntax::Pattern_>,
    pub body_p1: crate::syntax::LambdaBody,
}

impl prism_rtl::Job<Array<Text>> for LambdaReads {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let ps_p0 = &self.ps_p0;
        let body_p1 = &self.body_p1;
        let body_p1 = body_p1.clone();
        let ps_p0 = ps_p0.clone();
        call_value(fold_job(ps_p0.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Pattern_)| entered(once_job(move || {
            let acc_p3 = p0;
            let q_p4 = p1;
            call_then(crate::check::env::names::start_pattern_names(q_p4.clone()), move |pattern_names_54601: Array<Text>| prism_rtl::Turn::Finished(append(&acc_p3, &pattern_names_54601)))
        }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Pattern_)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>), move |fold_54563: Array<Text>| {
            let own_p2 = fold_54563;
            call_then(start_lambda_exprs(body_p1.clone()), move |lambda_exprs_54640: Array<crate::syntax::Expr>| call_then(start_free_reads(lambda_exprs_54640, Array::new()), move |free_reads_54629: Array<Text>| prism_rtl::Turn::Finished(filter(&free_reads_54629, &(|n_p5: &Text| !crate::check::types::has_text(&own_p2, n_p5))))))
        })
    }
}

/// `Start LambdaReads, x`: what the function value is when passed to `@Run`.
pub fn start_lambda_reads(ps_p0: Array<crate::syntax::Pattern_>, body_p1: crate::syntax::LambdaBody) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(LambdaReads { ps_p0, body_p1 })
}

/// ```prism
/// LambdaValue: unbounded fn Lx, Env, Expr, [Pattern], LambdaBody -> Vl
/// ```
pub fn lambda_value(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, e_p2: &crate::syntax::Expr, ps_p3: &Array<crate::syntax::Pattern_>, body_p4: &crate::syntax::LambdaBody) -> crate::lower::types::Vl {
    let ft_p5 = crate::lower::types::out_ty_of(lx_p0, &crate::lower::types::peel(&crate::lower::type_at(lx_p0, &e_p2.span)));
    match &ft_p5 {
        crate::lower::model::OutTy::OutJobFn(a_p6, _) => job_lambda(lx_p0, env_p1, ps_p3, body_p4, &ft_p5, &**a_p6, &enters_lambda(lx_p0, e_p2)),
        _ => plain_lambda(lx_p0, env_p1, ps_p3, body_p4, &ft_p5),
    }
}

/// The step machine of `LambdaValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LambdaValue: unbounded fn Lx, Env, Expr, [Pattern], LambdaBody -> Vl
/// ```
pub struct LambdaValue {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub e_p2: crate::syntax::Expr,
    pub ps_p3: Array<crate::syntax::Pattern_>,
    pub body_p4: crate::syntax::LambdaBody,
}

impl prism_rtl::Job<crate::lower::types::Vl> for LambdaValue {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::types::Vl> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let e_p2 = &self.e_p2;
        let ps_p3 = &self.ps_p3;
        let body_p4 = &self.body_p4;
        let body_p4 = body_p4.clone();
        let e_p2 = e_p2.clone();
        let env_p1 = env_p1.clone();
        let lx_p0 = lx_p0.clone();
        let ps_p3 = ps_p3.clone();
        call_then(crate::lower::types::start_out_ty_of(lx_p0.clone(), crate::lower::types::peel(&crate::lower::type_at(&lx_p0, &e_p2.span))), move |out_ty_of_54938: crate::lower::model::OutTy| {
            let ft_p5 = out_ty_of_54938;
            match &ft_p5 {
                crate::lower::model::OutTy::OutJobFn(a_p6, _) => prism_rtl::Turn::More(Rc::new(JobLambda { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), ps_p2: ps_p3.clone(), body_p3: body_p4.clone(), ft_p4: ft_p5.clone(), a_p5: (**a_p6).clone(), enter_p6: enters_lambda(&lx_p0, &e_p2) })),
                _ => prism_rtl::Turn::More(Rc::new(PlainLambda { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), ps_p2: ps_p3.clone(), body_p3: body_p4.clone(), ft_p4: ft_p5.clone() })),
            }
        })
    }
}

/// `Start LambdaValue, x`: what the function value is when passed to `@Run`.
pub fn start_lambda_value(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, e_p2: crate::syntax::Expr, ps_p3: Array<crate::syntax::Pattern_>, body_p4: crate::syntax::LambdaBody) -> Rc<dyn prism_rtl::Job<crate::lower::types::Vl>> {
    Rc::new(LambdaValue { lx_p0, env_p1, e_p2, ps_p3, body_p4 })
}

/// ```prism
/// PlainLambda: unbounded fn Lx, Env, [Pattern], LambdaBody, OutTy -> Vl
/// ```
pub fn plain_lambda(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, ps_p2: &Array<crate::syntax::Pattern_>, body_p3: &crate::syntax::LambdaBody, ft_p4: &crate::lower::model::OutTy) -> crate::lower::types::Vl {
    let pts_p5 = match ft_p4 {
        crate::lower::model::OutTy::OutFn(xs_pa, _) => xs_pa.clone(),
        _ => Array::new(),
    };
    let read_p6 = crate::lower::types::with_instances(env_p1, &lambda_reads(ps_p2, body_p3));
    let caps0_p7 = filter(&read_p6, &(|n_pb: &Text| match get(&env_p1.names, n_pb) {
        Some(crate::lower::types::Bn::BnLocal(_, _, _)) => true,
        _ => false,
    }));
    let caps_p8 = append(&append(&caps0_p7, &filter(&each(&read_p6, &(|n_pc: &Text| Text::from(format!("{}#port", n_pc)))), &(|n_pd: &Text| crate::check::env::has_key(&env_p1.names, n_pd)))), &filter(&each(&read_p6, &(|n_pe: &Text| Text::from(format!("{}#init", n_pe)))), &(|n_pf: &Text| crate::check::env::has_key(&env_p1.names, n_pf))));
    let (dos_po, env1_pp) = fold(&caps_p8, &(Array::new(), env_p1.clone()), &(|(acc_pg, en_ph): &(Array<crate::lower::model::Do>, crate::lower::types::Env), n_pi: &Text| match get(&env_p1.names, n_pi) {
        Some(crate::lower::types::Bn::BnLocal(rs_pj, mode_pk, ct_pl)) => {
            let local_pm = crate::lower::types::place_stem(&rs_pj);
            let d_pn = crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(local_pm.clone()), crate::lower::types::own(&crate::lower::types::local_place(&rs_pj, &mode_pk, &ct_pl)));
            (push(acc_pg, &d_pn), crate::lower::types::bind(en_ph, n_pi, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(local_pm.clone()), crate::lower::types::Holding::Owned, ct_pl.clone())))
        },
        _ => (acc_pg.clone(), en_ph.clone()),
    }));
    let (pas_pq, env2_pr) = closure_params(lx_p0, &env1_pp, ps_p2, &pts_p5, &true);
    let v_p9 = lambda_body_value(lx_p0, &env2_pr, body_p3);
    crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XBlock(dos_po.clone(), Rc::new(crate::lower::model::Ex::XCast(Rc::new(crate::lower::model::Ex::XCall(Text::lit("Rc::new"), Array::from(vec![crate::lower::model::Ex::XClosure(true, pas_pq.clone(), Rc::new(crate::lower::types::own(&v_p9)))]))), ft_p4.clone()))), ft_p4.clone())
}

/// The step machine of `PlainLambda`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PlainLambda: unbounded fn Lx, Env, [Pattern], LambdaBody, OutTy -> Vl
/// ```
pub struct PlainLambda {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub ps_p2: Array<crate::syntax::Pattern_>,
    pub body_p3: crate::syntax::LambdaBody,
    pub ft_p4: crate::lower::model::OutTy,
}

impl prism_rtl::Job<crate::lower::types::Vl> for PlainLambda {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::types::Vl> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let ps_p2 = &self.ps_p2;
        let body_p3 = &self.body_p3;
        let ft_p4 = &self.ft_p4;
        let pts_p5 = match ft_p4 {
            crate::lower::model::OutTy::OutFn(xs_pa, _) => xs_pa.clone(),
            _ => Array::new(),
        };
        let body_p3 = body_p3.clone();
        let env_p1 = env_p1.clone();
        let ft_p4 = ft_p4.clone();
        let lx_p0 = lx_p0.clone();
        let ps_p2 = ps_p2.clone();
        call_then(start_lambda_reads(ps_p2.clone(), body_p3.clone()), move |lambda_reads_55350: Array<Text>| {
            let read_p6 = crate::lower::types::with_instances(&env_p1, &lambda_reads_55350);
            let caps0_p7 = filter(&read_p6, &(|n_pb: &Text| match get(&env_p1.names, n_pb) {
                Some(crate::lower::types::Bn::BnLocal(_, _, _)) => true,
                _ => false,
            }));
            let caps_p8 = append(&append(&caps0_p7, &filter(&each(&read_p6, &(|n_pc: &Text| Text::from(format!("{}#port", n_pc)))), &(|n_pd: &Text| crate::check::env::has_key(&env_p1.names, n_pd)))), &filter(&each(&read_p6, &(|n_pe: &Text| Text::from(format!("{}#init", n_pe)))), &(|n_pf: &Text| crate::check::env::has_key(&env_p1.names, n_pf))));
            let (dos_po, env1_pp) = fold(&caps_p8, &(Array::new(), env_p1.clone()), &(|(acc_pg, en_ph): &(Array<crate::lower::model::Do>, crate::lower::types::Env), n_pi: &Text| match get(&env_p1.names, n_pi) {
                Some(crate::lower::types::Bn::BnLocal(rs_pj, mode_pk, ct_pl)) => {
                    let local_pm = crate::lower::types::place_stem(&rs_pj);
                    let d_pn = crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(local_pm.clone()), crate::lower::types::own(&crate::lower::types::local_place(&rs_pj, &mode_pk, &ct_pl)));
                    (push(acc_pg, &d_pn), crate::lower::types::bind(en_ph, n_pi, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(local_pm.clone()), crate::lower::types::Holding::Owned, ct_pl.clone())))
                },
                _ => (acc_pg.clone(), en_ph.clone()),
            }));
            call_then(start_closure_params(lx_p0.clone(), env1_pp.clone(), ps_p2.clone(), pts_p5.clone(), true), move |closure_params_56236: (Array<crate::lower::model::Pa>, crate::lower::types::Env)| {
                let (pas_pq, env2_pr) = closure_params_56236;
                call_then(start_lambda_body_value(lx_p0.clone(), env2_pr.clone(), body_p3.clone()), move |lambda_body_value_56286: crate::lower::types::Vl| {
                    let v_p9 = lambda_body_value_56286;
                    prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XBlock(dos_po.clone(), Rc::new(crate::lower::model::Ex::XCast(Rc::new(crate::lower::model::Ex::XCall(Text::lit("Rc::new"), Array::from(vec![crate::lower::model::Ex::XClosure(true, pas_pq.clone(), Rc::new(crate::lower::types::own(&v_p9)))]))), ft_p4.clone()))), ft_p4.clone()))
                })
            })
        })
    }
}

/// `Start PlainLambda, x`: what the function value is when passed to `@Run`.
pub fn start_plain_lambda(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, ps_p2: Array<crate::syntax::Pattern_>, body_p3: crate::syntax::LambdaBody, ft_p4: crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<crate::lower::types::Vl>> {
    Rc::new(PlainLambda { lx_p0, env_p1, ps_p2, body_p3, ft_p4 })
}

/// ```prism
/// LambdaParamTys: unbounded fn Lx, Expr, Nat -> [OutTy]
/// ```
pub fn lambda_param_tys(lx_p0: &crate::lower::Lx, e_p1: &crate::syntax::Expr, n_p2: &Nat) -> Array<crate::lower::model::OutTy> {
    let ts_p3 = match crate::lower::types::out_ty_of(lx_p0, &crate::lower::types::peel(&crate::lower::type_at(lx_p0, &e_p1.span))) {
        crate::lower::model::OutTy::OutFn(xs_p4, _) => xs_p4,
        crate::lower::model::OutTy::OutJobFn(a_p5, _) => match &*a_p5 {
            crate::lower::model::OutTy::OutTuple(xs_p6) => if n_p2 == &Nat::from(1u32) {
                Array::from(vec![(*a_p5).clone()])
            } else {
                xs_p6.clone()
            },
            _ => Array::from(vec![(*a_p5).clone()]),
        },
        _ => Array::new(),
    };
    if (&len(&ts_p3) == n_p2) && run_to_end(fold_job(ts_p3.clone(), true, Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| entered(once_job(move || {
        let ok_p7 = p0;
        let t_p8 = p1;
        prism_rtl::Turn::Finished(ok_p7 && is_known_ty(&t_p8))
    }))) as Rc<dyn Fn((bool, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<bool>>>)) {
        ts_p3.clone()
    } else {
        Array::new()
    }
}

/// The step machine of `LambdaParamTys`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LambdaParamTys: unbounded fn Lx, Expr, Nat -> [OutTy]
/// ```
pub struct LambdaParamTys {
    pub lx_p0: crate::lower::Lx,
    pub e_p1: crate::syntax::Expr,
    pub n_p2: Nat,
}

impl prism_rtl::Job<Array<crate::lower::model::OutTy>> for LambdaParamTys {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::lower::model::OutTy>> {
        let lx_p0 = &self.lx_p0;
        let e_p1 = &self.e_p1;
        let n_p2 = &self.n_p2;
        let e_p1 = e_p1.clone();
        let lx_p0 = lx_p0.clone();
        let n_p2 = n_p2.clone();
        call_then(crate::lower::types::start_out_ty_of(lx_p0.clone(), crate::lower::types::peel(&crate::lower::type_at(&lx_p0, &e_p1.span))), move |out_ty_of_56877: crate::lower::model::OutTy| {
            let ts_p3 = match out_ty_of_56877 {
                crate::lower::model::OutTy::OutFn(xs_p4, _) => xs_p4,
                crate::lower::model::OutTy::OutJobFn(a_p5, _) => match &*a_p5 {
                    crate::lower::model::OutTy::OutTuple(xs_p6) => if &n_p2 == &Nat::from(1u32) {
                        Array::from(vec![(*a_p5).clone()])
                    } else {
                        xs_p6.clone()
                    },
                    _ => Array::from(vec![(*a_p5).clone()]),
                },
                _ => Array::new(),
            };
            if (&len(&ts_p3) == &n_p2) && run_to_end(fold_job(ts_p3.clone(), true, Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| entered(once_job(move || {
                let ok_p7 = p0;
                let t_p8 = p1;
                prism_rtl::Turn::Finished(ok_p7 && is_known_ty(&t_p8))
            }))) as Rc<dyn Fn((bool, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<bool>>>)) {
                prism_rtl::Turn::Finished(ts_p3.clone())
            } else {
                prism_rtl::Turn::Finished(Array::new())
            }
        })
    }
}

/// `Start LambdaParamTys, x`: what the function value is when passed to `@Run`.
pub fn start_lambda_param_tys(lx_p0: crate::lower::Lx, e_p1: crate::syntax::Expr, n_p2: Nat) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::OutTy>>> {
    Rc::new(LambdaParamTys { lx_p0, e_p1, n_p2 })
}

/// ```prism
/// IsKnownTy: unbounded fn OutTy -> Bool
/// ```
pub fn is_known_ty(t_p0: &crate::lower::model::OutTy) -> bool {
    match t_p0 {
        crate::lower::model::OutTy::OutUnknown(_) => false,
        crate::lower::model::OutTy::OutOpt(x_p1) => is_known_ty(&**x_p1),
        crate::lower::model::OutTy::OutRes(x_p2) => is_known_ty(&**x_p2),
        crate::lower::model::OutTy::OutArray(x_p3) => is_known_ty(&**x_p3),
        crate::lower::model::OutTy::OutRc(x_p4) => is_known_ty(&**x_p4),
        crate::lower::model::OutTy::OutMap(k_p5, v_p6) => is_known_ty(&**k_p5) && is_known_ty(&**v_p6),
        crate::lower::model::OutTy::OutTuple(xs_p7) => run_to_end(fold_job(xs_p7.clone(), true, Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| entered(once_job(move || {
            let ok_p8 = p0;
            let x_p9 = p1;
            prism_rtl::Turn::Finished(ok_p8 && is_known_ty(&x_p9))
        }))) as Rc<dyn Fn((bool, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<bool>>>)),
        crate::lower::model::OutTy::OutNamed(_, xs_pa) => run_to_end(fold_job(xs_pa.clone(), true, Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| entered(once_job(move || {
            let ok_pb = p0;
            let x_pc = p1;
            prism_rtl::Turn::Finished(ok_pb && is_known_ty(&x_pc))
        }))) as Rc<dyn Fn((bool, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<bool>>>)),
        crate::lower::model::OutTy::OutFn(xs_pd, r_pe) => run_to_end(fold_job(xs_pd.clone(), true, Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| entered(once_job(move || {
            let ok_pf = p0;
            let x_pg = p1;
            prism_rtl::Turn::Finished(ok_pf && is_known_ty(&x_pg))
        }))) as Rc<dyn Fn((bool, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<bool>>>)) && is_known_ty(&**r_pe),
        crate::lower::model::OutTy::OutJobFn(a_ph, b_pi) => is_known_ty(&**a_ph) && is_known_ty(&**b_pi),
        _ => true,
    }
}

/// The step machine of `IsKnownTy`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// IsKnownTy: unbounded fn OutTy -> Bool
/// ```
pub struct IsKnownTy {
    pub t_p0: crate::lower::model::OutTy,
}

impl prism_rtl::Job<bool> for IsKnownTy {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let t_p0 = &self.t_p0;
        match t_p0 {
            crate::lower::model::OutTy::OutUnknown(_) => prism_rtl::Turn::Finished(false),
            crate::lower::model::OutTy::OutOpt(x_p1) => prism_rtl::Turn::More(Rc::new(IsKnownTy { t_p0: (**x_p1).clone() })),
            crate::lower::model::OutTy::OutRes(x_p2) => prism_rtl::Turn::More(Rc::new(IsKnownTy { t_p0: (**x_p2).clone() })),
            crate::lower::model::OutTy::OutArray(x_p3) => prism_rtl::Turn::More(Rc::new(IsKnownTy { t_p0: (**x_p3).clone() })),
            crate::lower::model::OutTy::OutRc(x_p4) => prism_rtl::Turn::More(Rc::new(IsKnownTy { t_p0: (**x_p4).clone() })),
            crate::lower::model::OutTy::OutMap(k_p5, v_p6) => {
                let k_p5 = (**k_p5).clone();
                let v_p6 = (**v_p6).clone();
                call_then(start_is_known_ty(k_p5.clone()), move |is_known_ty_57387: bool| prism_rtl::Turn::Finished(is_known_ty_57387 && is_known_ty(&v_p6)))
            },
            crate::lower::model::OutTy::OutTuple(xs_p7) => fold_job(xs_p7.clone(), true, Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| entered(once_job(move || {
                let ok_p8 = p0;
                let x_p9 = p1;
                prism_rtl::Turn::Finished(ok_p8 && is_known_ty(&x_p9))
            }))) as Rc<dyn Fn((bool, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<bool>>>).cycle(),
            crate::lower::model::OutTy::OutNamed(_, xs_pa) => fold_job(xs_pa.clone(), true, Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| entered(once_job(move || {
                let ok_pb = p0;
                let x_pc = p1;
                prism_rtl::Turn::Finished(ok_pb && is_known_ty(&x_pc))
            }))) as Rc<dyn Fn((bool, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<bool>>>).cycle(),
            crate::lower::model::OutTy::OutFn(xs_pd, r_pe) => {
                let r_pe = (**r_pe).clone();
                let xs_pd = xs_pd.clone();
                call_value(fold_job(xs_pd.clone(), true, Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| entered(once_job(move || {
                    let ok_pf = p0;
                    let x_pg = p1;
                    prism_rtl::Turn::Finished(ok_pf && is_known_ty(&x_pg))
                }))) as Rc<dyn Fn((bool, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<bool>>>), move |fold_57562: bool| prism_rtl::Turn::Finished(fold_57562 && is_known_ty(&r_pe)))
            },
            crate::lower::model::OutTy::OutJobFn(a_ph, b_pi) => {
                let a_ph = (**a_ph).clone();
                let b_pi = (**b_pi).clone();
                call_then(start_is_known_ty(a_ph.clone()), move |is_known_ty_57642: bool| prism_rtl::Turn::Finished(is_known_ty_57642 && is_known_ty(&b_pi)))
            },
            _ => prism_rtl::Turn::Finished(true),
        }
    }
}

/// `Start IsKnownTy, x`: what the function value is when passed to `@Run`.
pub fn start_is_known_ty(t_p0: crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(IsKnownTy { t_p0 })
}

/// ```prism
/// JobLambda: unbounded fn Lx, Env, [Pattern], LambdaBody, OutTy, OutTy, Bool -> Vl
/// ```
pub fn job_lambda(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, ps_p2: &Array<crate::syntax::Pattern_>, body_p3: &crate::syntax::LambdaBody, ft_p4: &crate::lower::model::OutTy, a_p5: &crate::lower::model::OutTy, enter_p6: &bool) -> crate::lower::types::Vl {
    let caps_p7 = filter(&crate::lower::types::with_instances(env_p1, &lambda_reads(ps_p2, body_p3)), &(|n_pm: &Text| match get(&env_p1.names, n_pm) {
        Some(crate::lower::types::Bn::BnLocal(_, _, _)) => true,
        _ => false,
    }));
    let (dos_pu, env1_pv) = fold(&caps_p7, &(Array::new(), env_p1.clone()), &(|(acc_pn, en_po): &(Array<crate::lower::model::Do>, crate::lower::types::Env), n_pp: &Text| match get(&env_p1.names, n_pp) {
        Some(crate::lower::types::Bn::BnLocal(rs_pq, mode_pr, ct_ps)) => {
            let d_pt = crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::lower::types::place_stem(&rs_pq)), crate::lower::types::own(&crate::lower::types::local_place(&rs_pq, &mode_pr, &ct_ps)));
            (push(acc_pn, &d_pt), crate::lower::types::bind(en_po, n_pp, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(crate::lower::types::place_stem(&rs_pq)), crate::lower::types::Holding::Owned, ct_ps.clone())))
        },
        _ => (acc_pn.clone(), en_po.clone()),
    }));
    let again_p8 = fold(&caps_p7, &Array::new(), &(|acc_p10: &Array<crate::lower::model::Do>, n_p11: &Text| match get(&env1_pv.names, n_p11) {
        Some(crate::lower::types::Bn::BnLocal(rs_p12, _, ct_p13)) => push(acc_p10, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::lower::types::place_stem(&rs_p12)), crate::lower::types::own(&crate::lower::types::local_place(&rs_p12, &crate::lower::types::Holding::Owned, &ct_p13)))),
        _ => acc_p10.clone(),
    }));
    let pts_p9 = match a_p5 {
        crate::lower::model::OutTy::OutTuple(ts_p14) => if &len(ps_p2) == &Nat::from(1u32) {
            Array::from(vec![a_p5.clone()])
        } else {
            ts_p14.clone()
        },
        _ => Array::from(vec![a_p5.clone()]),
    };
    let env1b_pa = only_captured(&env1_pv, &caps_p7);
    let pos_pb = run_to_end(each_job(crate::check::errors::range0(&len(ps_p2)), {
        let ps_p2 = ps_p2.clone();
        let lx_p0 = lx_p0.clone();
        Rc::new(move |p0: Nat| {
            let ps_p2 = ps_p2.clone();
            let lx_p0 = lx_p0.clone();
            entered(once_job(move || {
                let i_p15 = p0;
                {
                    let p_p16 = or(&index(&ps_p2, &i_p15), &crate::lower::patterns::dummy_pat());
                    prism_rtl::Turn::More(Rc::new(crate::lower::patterns::RustPat { lx_p0: lx_p0.clone(), p_p1: p_p16.clone(), ty_p2: binder_ty_of_pattern(&lx_p0, &p_p16), mode_p3: crate::lower::types::Holding::Owned, fresh_p4: Text::from(format!("p{}_", &i_p15)) }))
                }
            }))
        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<crate::lower::patterns::PatOut>>>
    }));
    let unpack_pc = fold(&crate::check::errors::range0(&len(&pos_pb)), &Array::new(), &(|acc_p17: &Array<crate::lower::model::Do>, i_p18: &Nat| match index(&pos_pb, i_p18) {
        Some(po_p19) => append(&push(acc_p17, &crate::lower::model::Do::DoLet(po_p19.pa.clone(), crate::lower::model::Ex::XVar(Text::from(format!("p{}", i_p18))))), &each(&po_p19.conds, &(|c_p1a: &crate::lower::model::Cc| cond_as_let(c_p1a)))),
        None => acc_p17.clone(),
    }));
    let pos2_pd = each(&crate::check::errors::range0(&len(&pos_pb)), &(|i_p1b: &Nat| match index(&pos_pb, i_p1b) {
        Some(po_p1c) => match &*or(&index(ps_p2, i_p1b), &crate::lower::patterns::dummy_pat()).kind {
            crate::syntax::PatternKind::PName(_) => {
                let mut this: crate::lower::patterns::PatOut = po_p1c.clone();
                this.binds = each(&this.binds, &(|(n_p1d, b_p1e): &(Text, crate::lower::types::Bn)| match b_p1e {
                    crate::lower::types::Bn::BnLocal(rs_p1f, mode_p1g, bt_p1h) => (n_p1d.clone(), crate::lower::types::Bn::BnLocal(rs_p1f.clone(), mode_p1g.clone(), or(&index(&pts_p9, i_p1b), bt_p1h))),
                    _ => (n_p1d.clone(), b_p1e.clone()),
                }));
                this
            },
            _ => po_p1c.clone(),
        },
        None => crate::lower::patterns::PatOut { pa: crate::lower::model::Pa::PaWild, conds: Array::new(), binds: Array::new() },
    }));
    let env2_pe = fold(&pos2_pd, &env1b_pa, &(|en_p1i: &crate::lower::types::Env, po_p1j: &crate::lower::patterns::PatOut| bind_all(en_p1i, &po_p1j.binds)));
    let names_pf = each(&crate::check::errors::range0(&len(ps_p2)), &(|i_p1k: &Nat| Text::from(format!("p{}", i_p1k))));
    let pa_pg = if &len(ps_p2) == &Nat::from(1u32) {
        crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaBind(Text::lit("p0"))), a_p5.clone())
    } else {
        crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaTuple(each(&names_pf, &(|nm_p1l: &Text| crate::lower::model::Pa::PaBind(nm_p1l.clone()))))), a_p5.clone())
    };
    let tail0_ph = match body_p3 {
        crate::syntax::LambdaBody::LbExpr(x_p1m) => crate::lower::jobs::tail(lx_p0, &env2_pe, &**x_p1m),
        crate::syntax::LambdaBody::LbBlock(bl_p1n) => crate::lower::jobs::tail_block(lx_p0, &env2_pe, bl_p1n),
    };
    let tail_pi = if &len(&unpack_pc) == &Nat::from(0u32) {
        tail0_ph.clone()
    } else {
        crate::lower::model::Ex::XBlock(unpack_pc.clone(), Rc::new(tail0_ph.clone()))
    };
    let job0_pj = crate::lower::model::Ex::XCall(Text::lit("once_job"), Array::from(vec![crate::lower::model::Ex::XClosure(true, Array::new(), Rc::new(tail_pi.clone()))]));
    let job_pk = if *enter_p6 {
        crate::lower::model::Ex::XCall(Text::lit("entered"), Array::from(vec![job0_pj.clone()]))
    } else {
        job0_pj.clone()
    };
    let call_pl = if &len(&again_p8) == &Nat::from(0u32) {
        job_pk.clone()
    } else {
        crate::lower::model::Ex::XBlock(again_p8.clone(), Rc::new(job_pk.clone()))
    };
    crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XBlock(dos_pu.clone(), Rc::new(crate::lower::model::Ex::XCast(Rc::new(crate::lower::model::Ex::XCall(Text::lit("Rc::new"), Array::from(vec![crate::lower::model::Ex::XClosure(true, Array::from(vec![pa_pg.clone()]), Rc::new(call_pl.clone()))]))), ft_p4.clone()))), ft_p4.clone())
}

/// The step machine of `JobLambda`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// JobLambda: unbounded fn Lx, Env, [Pattern], LambdaBody, OutTy, OutTy, Bool -> Vl
/// ```
pub struct JobLambda {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub ps_p2: Array<crate::syntax::Pattern_>,
    pub body_p3: crate::syntax::LambdaBody,
    pub ft_p4: crate::lower::model::OutTy,
    pub a_p5: crate::lower::model::OutTy,
    pub enter_p6: bool,
}

impl prism_rtl::Job<crate::lower::types::Vl> for JobLambda {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::types::Vl> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let ps_p2 = &self.ps_p2;
        let body_p3 = &self.body_p3;
        let ft_p4 = &self.ft_p4;
        let a_p5 = &self.a_p5;
        let enter_p6 = &self.enter_p6;
        let a_p5 = a_p5.clone();
        let body_p3 = body_p3.clone();
        let enter_p6 = *enter_p6;
        let env_p1 = env_p1.clone();
        let ft_p4 = ft_p4.clone();
        let lx_p0 = lx_p0.clone();
        let ps_p2 = ps_p2.clone();
        call_then(start_lambda_reads(ps_p2.clone(), body_p3.clone()), move |lambda_reads_58509: Array<Text>| {
            let caps_p7 = filter(&crate::lower::types::with_instances(&env_p1, &lambda_reads_58509), &(|n_pm: &Text| match get(&env_p1.names, n_pm) {
                Some(crate::lower::types::Bn::BnLocal(_, _, _)) => true,
                _ => false,
            }));
            let (dos_pu, env1_pv) = fold(&caps_p7, &(Array::new(), env_p1.clone()), &(|(acc_pn, en_po): &(Array<crate::lower::model::Do>, crate::lower::types::Env), n_pp: &Text| match get(&env_p1.names, n_pp) {
                Some(crate::lower::types::Bn::BnLocal(rs_pq, mode_pr, ct_ps)) => {
                    let d_pt = crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::lower::types::place_stem(&rs_pq)), crate::lower::types::own(&crate::lower::types::local_place(&rs_pq, &mode_pr, &ct_ps)));
                    (push(acc_pn, &d_pt), crate::lower::types::bind(en_po, n_pp, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(crate::lower::types::place_stem(&rs_pq)), crate::lower::types::Holding::Owned, ct_ps.clone())))
                },
                _ => (acc_pn.clone(), en_po.clone()),
            }));
            let again_p8 = fold(&caps_p7, &Array::new(), &(|acc_p10: &Array<crate::lower::model::Do>, n_p11: &Text| match get(&env1_pv.names, n_p11) {
                Some(crate::lower::types::Bn::BnLocal(rs_p12, _, ct_p13)) => push(acc_p10, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::lower::types::place_stem(&rs_p12)), crate::lower::types::own(&crate::lower::types::local_place(&rs_p12, &crate::lower::types::Holding::Owned, &ct_p13)))),
                _ => acc_p10.clone(),
            }));
            let pts_p9 = match &a_p5 {
                crate::lower::model::OutTy::OutTuple(ts_p14) => if &len(&ps_p2) == &Nat::from(1u32) {
                    Array::from(vec![a_p5.clone()])
                } else {
                    ts_p14.clone()
                },
                _ => Array::from(vec![a_p5.clone()]),
            };
            let env1b_pa = only_captured(&env1_pv, &caps_p7);
            call_value(each_job(crate::check::errors::range0(&len(&ps_p2)), {
                let ps_p2 = ps_p2.clone();
                let lx_p0 = lx_p0.clone();
                Rc::new(move |p0: Nat| {
                    let ps_p2 = ps_p2.clone();
                    let lx_p0 = lx_p0.clone();
                    entered(once_job(move || {
                        let i_p15 = p0;
                        {
                            let p_p16 = or(&index(&ps_p2, &i_p15), &crate::lower::patterns::dummy_pat());
                            prism_rtl::Turn::More(Rc::new(crate::lower::patterns::RustPat { lx_p0: lx_p0.clone(), p_p1: p_p16.clone(), ty_p2: binder_ty_of_pattern(&lx_p0, &p_p16), mode_p3: crate::lower::types::Holding::Owned, fresh_p4: Text::from(format!("p{}_", &i_p15)) }))
                        }
                    }))
                }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<crate::lower::patterns::PatOut>>>
            }), move |each_59540: Array<crate::lower::patterns::PatOut>| {
                let pos_pb = each_59540;
                let unpack_pc = fold(&crate::check::errors::range0(&len(&pos_pb)), &Array::new(), &(|acc_p17: &Array<crate::lower::model::Do>, i_p18: &Nat| match index(&pos_pb, i_p18) {
                    Some(po_p19) => append(&push(acc_p17, &crate::lower::model::Do::DoLet(po_p19.pa.clone(), crate::lower::model::Ex::XVar(Text::from(format!("p{}", i_p18))))), &each(&po_p19.conds, &(|c_p1a: &crate::lower::model::Cc| cond_as_let(c_p1a)))),
                    None => acc_p17.clone(),
                }));
                let pos2_pd = each(&crate::check::errors::range0(&len(&pos_pb)), &(|i_p1b: &Nat| match index(&pos_pb, i_p1b) {
                    Some(po_p1c) => match &*or(&index(&ps_p2, i_p1b), &crate::lower::patterns::dummy_pat()).kind {
                        crate::syntax::PatternKind::PName(_) => {
                            let mut this: crate::lower::patterns::PatOut = po_p1c.clone();
                            this.binds = each(&this.binds, &(|(n_p1d, b_p1e): &(Text, crate::lower::types::Bn)| match b_p1e {
                                crate::lower::types::Bn::BnLocal(rs_p1f, mode_p1g, bt_p1h) => (n_p1d.clone(), crate::lower::types::Bn::BnLocal(rs_p1f.clone(), mode_p1g.clone(), or(&index(&pts_p9, i_p1b), bt_p1h))),
                                _ => (n_p1d.clone(), b_p1e.clone()),
                            }));
                            this
                        },
                        _ => po_p1c.clone(),
                    },
                    None => crate::lower::patterns::PatOut { pa: crate::lower::model::Pa::PaWild, conds: Array::new(), binds: Array::new() },
                }));
                let env2_pe = fold(&pos2_pd, &env1b_pa, &(|en_p1i: &crate::lower::types::Env, po_p1j: &crate::lower::patterns::PatOut| bind_all(en_p1i, &po_p1j.binds)));
                let names_pf = each(&crate::check::errors::range0(&len(&ps_p2)), &(|i_p1k: &Nat| Text::from(format!("p{}", i_p1k))));
                let pa_pg = if &len(&ps_p2) == &Nat::from(1u32) {
                    crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaBind(Text::lit("p0"))), a_p5.clone())
                } else {
                    crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaTuple(each(&names_pf, &(|nm_p1l: &Text| crate::lower::model::Pa::PaBind(nm_p1l.clone()))))), a_p5.clone())
                };
                let tail0_ph = match &body_p3 {
                    crate::syntax::LambdaBody::LbExpr(x_p1m) => crate::lower::jobs::tail(&lx_p0, &env2_pe, &**x_p1m),
                    crate::syntax::LambdaBody::LbBlock(bl_p1n) => crate::lower::jobs::tail_block(&lx_p0, &env2_pe, bl_p1n),
                };
                let tail_pi = if &len(&unpack_pc) == &Nat::from(0u32) {
                    tail0_ph.clone()
                } else {
                    crate::lower::model::Ex::XBlock(unpack_pc.clone(), Rc::new(tail0_ph.clone()))
                };
                let job0_pj = crate::lower::model::Ex::XCall(Text::lit("once_job"), Array::from(vec![crate::lower::model::Ex::XClosure(true, Array::new(), Rc::new(tail_pi.clone()))]));
                let job_pk = if enter_p6 {
                    crate::lower::model::Ex::XCall(Text::lit("entered"), Array::from(vec![job0_pj.clone()]))
                } else {
                    job0_pj.clone()
                };
                let call_pl = if &len(&again_p8) == &Nat::from(0u32) {
                    job_pk.clone()
                } else {
                    crate::lower::model::Ex::XBlock(again_p8.clone(), Rc::new(job_pk.clone()))
                };
                prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XBlock(dos_pu.clone(), Rc::new(crate::lower::model::Ex::XCast(Rc::new(crate::lower::model::Ex::XCall(Text::lit("Rc::new"), Array::from(vec![crate::lower::model::Ex::XClosure(true, Array::from(vec![pa_pg.clone()]), Rc::new(call_pl.clone()))]))), ft_p4.clone()))), ft_p4.clone()))
            })
        })
    }
}

/// `Start JobLambda, x`: what the function value is when passed to `@Run`.
pub fn start_job_lambda(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, ps_p2: Array<crate::syntax::Pattern_>, body_p3: crate::syntax::LambdaBody, ft_p4: crate::lower::model::OutTy, a_p5: crate::lower::model::OutTy, enter_p6: bool) -> Rc<dyn prism_rtl::Job<crate::lower::types::Vl>> {
    Rc::new(JobLambda { lx_p0, env_p1, ps_p2, body_p3, ft_p4, a_p5, enter_p6 })
}

/// ```prism
/// EntersLambda: fn Lx, Expr -> Bool
/// ```
pub fn enters_lambda(lx_p0: &crate::lower::Lx, e_p1: &crate::syntax::Expr) -> bool {
    match crate::lower::types::peel(&crate::lower::type_at(lx_p0, &e_p1.span)) {
        crate::check::types::Ty::TyFn(crate::check::types::Col::CBound, _, _) => false,
        crate::check::types::Ty::TyFn(_, _, _) => true,
        _ => false,
    }
}

/// ```prism
/// OnlyCaptured: fn Env, [Text] -> Env
/// ```
pub fn only_captured(env_p0: &crate::lower::types::Env, caps_p1: &Array<Text>) -> crate::lower::types::Env {
    let mut this: crate::lower::types::Env = env_p0.clone();
    this.names = fold(&keys(&env_p0.names), &Map::new(), &(|m_p2: &Map<Text, crate::lower::types::Bn>, k_p3: &Text| match get(&env_p0.names, k_p3) {
        Some(crate::lower::types::Bn::BnLocal(rs_p4, mode_p5, t_p6)) => if crate::check::types::has_text(caps_p1, k_p3) || (&mode_p5 == &crate::lower::types::Holding::Owned) {
            insert(m_p2, k_p3, &crate::lower::types::Bn::BnLocal(rs_p4, mode_p5.clone(), t_p6))
        } else {
            m_p2.clone()
        },
        Some(b_p7) => insert(m_p2, k_p3, &b_p7),
        None => m_p2.clone(),
    }));
    this
}

/// ```prism
/// CondAsLet: fn Cc -> Do
/// ```
pub fn cond_as_let(cc0: &crate::lower::model::Cc) -> crate::lower::model::Do {
    match cc0 {
        crate::lower::model::Cc::CcLet(pa_p0, x_p1) => crate::lower::model::Do::DoLet(pa_p0.clone(), x_p1.clone()),
        crate::lower::model::Cc::CcIf(x_p2) => crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XUnit),
    }
}

/// ```prism
/// LambdaArg: unbounded fn Lx, Env, [Pattern], LambdaBody, [OutTy] -> Ex
/// ```
pub fn lambda_arg(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, ps_p2: &Array<crate::syntax::Pattern_>, body_p3: &crate::syntax::LambdaBody, pts_p4: &Array<crate::lower::model::OutTy>) -> crate::lower::model::Ex {
    let (pas_p6, env2_p7) = closure_params(lx_p0, env_p1, ps_p2, pts_p4, &(&len(pts_p4) > &Nat::from(0u32)));
    let v_p5 = lambda_body_value(lx_p0, &env2_p7, body_p3);
    crate::lower::model::Ex::XClosure(false, pas_p6.clone(), Rc::new(crate::lower::types::own(&v_p5)))
}

/// The step machine of `LambdaArg`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LambdaArg: unbounded fn Lx, Env, [Pattern], LambdaBody, [OutTy] -> Ex
/// ```
pub struct LambdaArg {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub ps_p2: Array<crate::syntax::Pattern_>,
    pub body_p3: crate::syntax::LambdaBody,
    pub pts_p4: Array<crate::lower::model::OutTy>,
}

impl prism_rtl::Job<crate::lower::model::Ex> for LambdaArg {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::Ex> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let ps_p2 = &self.ps_p2;
        let body_p3 = &self.body_p3;
        let pts_p4 = &self.pts_p4;
        let body_p3 = body_p3.clone();
        let env_p1 = env_p1.clone();
        let lx_p0 = lx_p0.clone();
        let ps_p2 = ps_p2.clone();
        let pts_p4 = pts_p4.clone();
        call_then(start_closure_params(lx_p0.clone(), env_p1.clone(), ps_p2.clone(), pts_p4.clone(), &len(&pts_p4) > &Nat::from(0u32)), move |closure_params_62280: (Array<crate::lower::model::Pa>, crate::lower::types::Env)| {
            let (pas_p6, env2_p7) = closure_params_62280;
            call_then(start_lambda_body_value(lx_p0.clone(), env2_p7.clone(), body_p3.clone()), move |lambda_body_value_62338: crate::lower::types::Vl| {
                let v_p5 = lambda_body_value_62338;
                prism_rtl::Turn::Finished(crate::lower::model::Ex::XClosure(false, pas_p6.clone(), Rc::new(crate::lower::types::own(&v_p5))))
            })
        })
    }
}

/// `Start LambdaArg, x`: what the function value is when passed to `@Run`.
pub fn start_lambda_arg(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, ps_p2: Array<crate::syntax::Pattern_>, body_p3: crate::syntax::LambdaBody, pts_p4: Array<crate::lower::model::OutTy>) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>> {
    Rc::new(LambdaArg { lx_p0, env_p1, ps_p2, body_p3, pts_p4 })
}

/// ```prism
/// LambdaBodyValue: unbounded fn Lx, Env, LambdaBody -> Vl
/// ```
pub fn lambda_body_value(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, lambda_body2: &crate::syntax::LambdaBody) -> crate::lower::types::Vl {
    match lambda_body2 {
        crate::syntax::LambdaBody::LbExpr(x_p2) => value_of(lx_p0, env_p1, &**x_p2),
        crate::syntax::LambdaBody::LbBlock(b_p5) => block_value(lx_p0, env_p1, b_p5),
    }
}

/// The step machine of `LambdaBodyValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LambdaBodyValue: unbounded fn Lx, Env, LambdaBody -> Vl
/// ```
pub struct LambdaBodyValue {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub lambda_body2: crate::syntax::LambdaBody,
}

impl prism_rtl::Job<crate::lower::types::Vl> for LambdaBodyValue {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::types::Vl> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let lambda_body2 = &self.lambda_body2;
        match lambda_body2 {
            crate::syntax::LambdaBody::LbExpr(x_p2) => prism_rtl::Turn::More(Rc::new(ValueOf { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), e_p2: (**x_p2).clone() })),
            crate::syntax::LambdaBody::LbBlock(b_p5) => prism_rtl::Turn::More(Rc::new(BlockValue { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), b_p2: b_p5.clone() })),
        }
    }
}

/// `Start LambdaBodyValue, x`: what the function value is when passed to `@Run`.
pub fn start_lambda_body_value(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, lambda_body2: crate::syntax::LambdaBody) -> Rc<dyn prism_rtl::Job<crate::lower::types::Vl>> {
    Rc::new(LambdaBodyValue { lx_p0, env_p1, lambda_body2 })
}

/// ```prism
/// ClosureParams: unbounded fn Lx, Env, [Pattern], [OutTy], Bool -> (([Pa], Env))
/// ```
pub fn closure_params(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, ps_p2: &Array<crate::syntax::Pattern_>, pts_p3: &Array<crate::lower::model::OutTy>, typed_p4: &bool) -> (Array<crate::lower::model::Pa>, crate::lower::types::Env) {
    run_to_end(fold_job(crate::check::errors::range0(&len(ps_p2)), (Array::new(), env_p1.clone()), {
        let ps_p2 = ps_p2.clone();
        let lx_p0 = lx_p0.clone();
        let typed_p4 = *typed_p4;
        let pts_p3 = pts_p3.clone();
        Rc::new(move |(p0, p1): ((Array<crate::lower::model::Pa>, crate::lower::types::Env), Nat)| {
            let ps_p2 = ps_p2.clone();
            let lx_p0 = lx_p0.clone();
            let typed_p4 = typed_p4;
            let pts_p3 = pts_p3.clone();
            entered(once_job(move || {
                let (acc_p5, en_p6) = p0;
                let i_p7 = p1;
                match index(&ps_p2, &i_p7) {
                    Some(p_p8) => call_then(crate::lower::patterns::start_rust_pat(lx_p0.clone(), p_p8.clone(), binder_ty_of_pattern(&lx_p0, &p_p8), crate::lower::types::Holding::ByRef, Text::from(format!("a{}", &p_p8.span.start))), move |rust_pat_62901: crate::lower::patterns::PatOut| {
                        let po_p9 = rust_pat_62901;
                        let en2_pa = bind_all(&en_p6, &po_p9.binds);
                        let pa_pb = if typed_p4 {
                            crate::lower::model::Pa::PaTyped(Rc::new(po_p9.pa.clone()), crate::lower::model::OutTy::OutRef(Rc::new(or(&index(&pts_p3, &i_p7), &crate::lower::model::OutTy::OutUnknown(Text::lit("a parameter"))))))
                        } else {
                            po_p9.pa.clone()
                        };
                        prism_rtl::Turn::Finished((push(&acc_p5, &pa_pb), en2_pa.clone()))
                    }),
                    None => prism_rtl::Turn::Finished((acc_p5.clone(), en_p6.clone())),
                }
            }))
        }) as Rc<dyn Fn(((Array<crate::lower::model::Pa>, crate::lower::types::Env), Nat)) -> Rc<dyn prism_rtl::Job<(Array<crate::lower::model::Pa>, crate::lower::types::Env)>>>
    }))
}

/// The step machine of `ClosureParams`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ClosureParams: unbounded fn Lx, Env, [Pattern], [OutTy], Bool -> (([Pa], Env))
/// ```
pub struct ClosureParams {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub ps_p2: Array<crate::syntax::Pattern_>,
    pub pts_p3: Array<crate::lower::model::OutTy>,
    pub typed_p4: bool,
}

impl prism_rtl::Job<(Array<crate::lower::model::Pa>, crate::lower::types::Env)> for ClosureParams {
    fn cycle(&self) -> prism_rtl::Turn<(Array<crate::lower::model::Pa>, crate::lower::types::Env)> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let ps_p2 = &self.ps_p2;
        let pts_p3 = &self.pts_p3;
        let typed_p4 = &self.typed_p4;
        fold_job(crate::check::errors::range0(&len(ps_p2)), (Array::new(), env_p1.clone()), {
            let ps_p2 = ps_p2.clone();
            let lx_p0 = lx_p0.clone();
            let typed_p4 = *typed_p4;
            let pts_p3 = pts_p3.clone();
            Rc::new(move |(p0, p1): ((Array<crate::lower::model::Pa>, crate::lower::types::Env), Nat)| {
                let ps_p2 = ps_p2.clone();
                let lx_p0 = lx_p0.clone();
                let typed_p4 = typed_p4;
                let pts_p3 = pts_p3.clone();
                entered(once_job(move || {
                    let (acc_p5, en_p6) = p0;
                    let i_p7 = p1;
                    match index(&ps_p2, &i_p7) {
                        Some(p_p8) => call_then(crate::lower::patterns::start_rust_pat(lx_p0.clone(), p_p8.clone(), binder_ty_of_pattern(&lx_p0, &p_p8), crate::lower::types::Holding::ByRef, Text::from(format!("a{}", &p_p8.span.start))), move |rust_pat_62901: crate::lower::patterns::PatOut| {
                            let po_p9 = rust_pat_62901;
                            let en2_pa = bind_all(&en_p6, &po_p9.binds);
                            let pa_pb = if typed_p4 {
                                crate::lower::model::Pa::PaTyped(Rc::new(po_p9.pa.clone()), crate::lower::model::OutTy::OutRef(Rc::new(or(&index(&pts_p3, &i_p7), &crate::lower::model::OutTy::OutUnknown(Text::lit("a parameter"))))))
                            } else {
                                po_p9.pa.clone()
                            };
                            prism_rtl::Turn::Finished((push(&acc_p5, &pa_pb), en2_pa.clone()))
                        }),
                        None => prism_rtl::Turn::Finished((acc_p5.clone(), en_p6.clone())),
                    }
                }))
            }) as Rc<dyn Fn(((Array<crate::lower::model::Pa>, crate::lower::types::Env), Nat)) -> Rc<dyn prism_rtl::Job<(Array<crate::lower::model::Pa>, crate::lower::types::Env)>>>
        }).cycle()
    }
}

/// `Start ClosureParams, x`: what the function value is when passed to `@Run`.
pub fn start_closure_params(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, ps_p2: Array<crate::syntax::Pattern_>, pts_p3: Array<crate::lower::model::OutTy>, typed_p4: bool) -> Rc<dyn prism_rtl::Job<(Array<crate::lower::model::Pa>, crate::lower::types::Env)>> {
    Rc::new(ClosureParams { lx_p0, env_p1, ps_p2, pts_p3, typed_p4 })
}

/// ```prism
/// BindAll: fn Env, [((Text, Bn))] -> Env
/// ```
pub fn bind_all(env_p0: &crate::lower::types::Env, bs_p1: &Array<(Text, crate::lower::types::Bn)>) -> crate::lower::types::Env {
    fold(bs_p1, env_p0, &(|en_p2: &crate::lower::types::Env, (n_p3, b_p4): &(Text, crate::lower::types::Bn)| crate::lower::types::bind(en_p2, n_p3, b_p4)))
}

/// ```prism
/// BinderTyOfPattern: fn Lx, Pattern -> Ty
/// ```
pub fn binder_ty_of_pattern(lx_p0: &crate::lower::Lx, p_p1: &crate::syntax::Pattern_) -> crate::check::types::Ty {
    match &*p_p1.kind {
        crate::syntax::PatternKind::PName(n_p2) => crate::lower::binder_ty(lx_p0, &n_p2.span),
        _ => crate::lower::type_at(lx_p0, &p_p1.span),
    }
}

/// ```prism
/// IfValue: unbounded fn Lx, Env, Cond, Block, ?Block, OutTy -> Vl
/// ```
pub fn if_value(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, c_p2: &crate::syntax::Cond, then_b_p3: &crate::syntax::Block, else_b_o4: &Option<crate::syntax::Block>, t_p5: &crate::lower::model::OutTy) -> crate::lower::types::Vl {
    let else_v_p6 = match else_b_o4 {
        Some(b_p7) => crate::lower::node_::def::own_as(t_p5, &block_value(lx_p0, env_p1, b_p7)),
        None => crate::lower::model::Ex::XUnit,
    };
    match c_p2 {
        crate::syntax::Cond::CondExpr(x_p8) => crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XIf(Rc::new(crate::lower::types::as_bool(&value_of(lx_p0, env_p1, &**x_p8))), Rc::new(crate::lower::node_::def::own_as(t_p5, &block_value(lx_p0, env_p1, then_b_p3))), Rc::new(else_v_p6.clone())), t_p5.clone()),
        crate::syntax::Cond::CondBind(p_p9, x_pa, g_ob) => {
            let sv_pc = value_of(lx_p0, env_p1, &**x_pa);
            let po_pd = crate::lower::patterns::rust_pat(lx_p0, p_p9, &crate::lower::type_at(lx_p0, &x_pa.span), &crate::lower::types::Holding::ByRef, &Text::from(format!("c{}", &x_pa.span.start)));
            let env2_pe = bind_all(env_p1, &po_pd.binds);
            let guard_pf = match &**g_ob {
                Some(ge_pi) => Array::from(vec![crate::lower::model::Cc::CcIf(crate::lower::types::as_bool(&value_of(lx_p0, &env2_pe, ge_pi)))]),
                None => Array::new(),
            };
            let arm_pg = crate::lower::model::XArm { pat: po_pd.pa.clone(), conds: append(&po_pd.conds, &guard_pf), body: crate::lower::node_::def::own_as(t_p5, &block_value(lx_p0, &env2_pe, then_b_p3)) };
            let other_ph = crate::lower::model::XArm { pat: crate::lower::model::Pa::PaWild, conds: Array::new(), body: else_v_p6.clone() };
            arms_value(&crate::lower::types::ref_(&sv_pc), &Array::from(vec![arm_pg.clone(), other_ph.clone()]), &Text::from(format!("c{}", &x_pa.span.start)), t_p5)
        },
    }
}

/// The step machine of `IfValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// IfValue: unbounded fn Lx, Env, Cond, Block, ?Block, OutTy -> Vl
/// ```
pub struct IfValue {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub c_p2: crate::syntax::Cond,
    pub then_b_p3: crate::syntax::Block,
    pub else_b_o4: Option<crate::syntax::Block>,
    pub t_p5: crate::lower::model::OutTy,
}

impl prism_rtl::Job<crate::lower::types::Vl> for IfValue {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::types::Vl> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let c_p2 = &self.c_p2;
        let then_b_p3 = &self.then_b_p3;
        let else_b_o4 = &self.else_b_o4;
        let t_p5 = &self.t_p5;
        let else_v_p6 = match else_b_o4 {
            Some(b_p7) => crate::lower::node_::def::own_as(t_p5, &block_value(lx_p0, env_p1, b_p7)),
            None => crate::lower::model::Ex::XUnit,
        };
        match c_p2 {
            crate::syntax::Cond::CondExpr(x_p8) => {
                let env_p1 = env_p1.clone();
                let lx_p0 = lx_p0.clone();
                let t_p5 = t_p5.clone();
                let then_b_p3 = then_b_p3.clone();
                let x_p8 = (**x_p8).clone();
                call_then(start_value_of(lx_p0.clone(), env_p1.clone(), x_p8.clone()), move |value_of_63807: crate::lower::types::Vl| call_then(start_block_value(lx_p0.clone(), env_p1.clone(), then_b_p3.clone()), move |block_value_63840: crate::lower::types::Vl| prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XIf(Rc::new(crate::lower::types::as_bool(&value_of_63807)), Rc::new(crate::lower::node_::def::own_as(&t_p5, &block_value_63840)), Rc::new(else_v_p6.clone())), t_p5.clone()))))
            },
            crate::syntax::Cond::CondBind(p_p9, x_pa, g_ob) => {
                let g_ob = (**g_ob).clone();
                let c_p2 = c_p2.clone();
                let env_p1 = env_p1.clone();
                let lx_p0 = lx_p0.clone();
                let p_p9 = p_p9.clone();
                let t_p5 = t_p5.clone();
                let then_b_p3 = then_b_p3.clone();
                let x_pa = (**x_pa).clone();
                call_then(start_value_of(lx_p0.clone(), env_p1.clone(), x_pa.clone()), move |value_of_63927: crate::lower::types::Vl| {
                    let sv_pc = value_of_63927;
                    call_then(crate::lower::patterns::start_rust_pat(lx_p0.clone(), p_p9.clone(), crate::lower::type_at(&lx_p0, &x_pa.span), crate::lower::types::Holding::ByRef, Text::from(format!("c{}", &x_pa.span.start))), move |rust_pat_63967: crate::lower::patterns::PatOut| {
                        let po_pd = rust_pat_63967;
                        let env2_pe = bind_all(&env_p1, &po_pd.binds);
                        let guard_pf = match &g_ob {
                            Some(ge_pi) => Array::from(vec![crate::lower::model::Cc::CcIf(crate::lower::types::as_bool(&value_of(&lx_p0, &env2_pe, ge_pi)))]),
                            None => Array::new(),
                        };
                        call_then(start_block_value(lx_p0.clone(), env2_pe.clone(), then_b_p3.clone()), move |block_value_64282: crate::lower::types::Vl| {
                            let arm_pg = crate::lower::model::XArm { pat: po_pd.pa.clone(), conds: append(&po_pd.conds, &guard_pf), body: crate::lower::node_::def::own_as(&t_p5, &block_value_64282) };
                            let other_ph = crate::lower::model::XArm { pat: crate::lower::model::Pa::PaWild, conds: Array::new(), body: else_v_p6.clone() };
                            prism_rtl::Turn::Finished(arms_value(&crate::lower::types::ref_(&sv_pc), &Array::from(vec![arm_pg.clone(), other_ph.clone()]), &Text::from(format!("c{}", &x_pa.span.start)), &t_p5))
                        })
                    })
                })
            },
        }
    }
}

/// `Start IfValue, x`: what the function value is when passed to `@Run`.
pub fn start_if_value(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, c_p2: crate::syntax::Cond, then_b_p3: crate::syntax::Block, else_b_o4: Option<crate::syntax::Block>, t_p5: crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<crate::lower::types::Vl>> {
    Rc::new(IfValue { lx_p0, env_p1, c_p2, then_b_p3, else_b_o4, t_p5 })
}

/// ```prism
/// ArmsValue: fn Ex, [XArm], Text, OutTy -> Vl
/// ```
pub fn arms_value(scrut_p0: &crate::lower::model::Ex, arms_p1: &Array<crate::lower::model::XArm>, label_p2: &Text, t_p3: &crate::lower::model::OutTy) -> crate::lower::types::Vl {
    let chain_p4 = fold(arms_p1, &false, &(|f_p6: &bool, a_p7: &crate::lower::model::XArm| *f_p6 || fold(&a_p7.conds, &false, &(|f2_p8: &bool, c_p9: &crate::lower::model::Cc| *f2_p8 || is_let_cond(c_p9)))));
    let guarded_p5 = fold(arms_p1, &false, &(|f_pa: &bool, a_pb: &crate::lower::model::XArm| *f_pa || (&len(&a_pb.conds) > &Nat::from(0u32))));
    if chain_p4 {
        crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XChain(label_p2.clone(), Rc::new(scrut_p0.clone()), arms_p1.clone(), t_p3.clone()), t_p3.clone())
    } else {
        crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XMatch(Rc::new(scrut_p0.clone()), arms_p1.clone(), guarded_p5, t_p3.clone()), t_p3.clone())
    }
}

/// ```prism
/// IsLetCond: fn Cc -> Bool
/// ```
pub fn is_let_cond(cc0: &crate::lower::model::Cc) -> bool {
    match cc0 {
        crate::lower::model::Cc::CcLet(_, _) => true,
        crate::lower::model::Cc::CcIf(_) => false,
    }
}

/// ```prism
/// MatchValue: unbounded fn Lx, Env, Expr, [Arm], OutTy, Range -> Vl
/// ```
pub fn match_value(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, s_p2: &crate::syntax::Expr, arms_p3: &Array<crate::syntax::Arm>, t_p4: &crate::lower::model::OutTy, span_p5: &crate::syntax::Range) -> crate::lower::types::Vl {
    let sv_p6 = value_of(lx_p0, env_p1, s_p2);
    let sty_p7 = crate::lower::type_at(lx_p0, &s_p2.span);
    let label_p8 = Text::from(format!("m{}", &span_p5.start));
    let by_ref_p9 = run_to_end(each_job(crate::check::errors::range0(&len(arms_p3)), {
        let lx_p0 = lx_p0.clone();
        let arms_p3 = arms_p3.clone();
        let sty_p7 = sty_p7.clone();
        let label_p8 = label_p8.clone();
        Rc::new(move |p0: Nat| {
            let lx_p0 = lx_p0.clone();
            let arms_p3 = arms_p3.clone();
            let sty_p7 = sty_p7.clone();
            let label_p8 = label_p8.clone();
            entered(once_job(move || {
                let i_pf = p0;
                prism_rtl::Turn::More(Rc::new(ArmPat { lx_p0: lx_p0.clone(), opt1: or(&index(&arms_p3, &i_pf), &dummy_arm()).pattern.clone(), ty_p2: sty_p7.clone(), mode_p3: crate::lower::types::Holding::ByRef, fresh_p4: Text::from(format!("{}_{}", &label_p8, &i_pf)) }))
            }))
        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<crate::lower::patterns::PatOut>>>
    }));
    let chain_pa = fold(&by_ref_p9, &false, &(|f_pg: &bool, po_ph: &crate::lower::patterns::PatOut| *f_pg || fold(&po_ph.conds, &false, &(|f2_pi: &bool, c_pj: &crate::lower::model::Cc| *f2_pi || is_let_cond(c_pj)))));
    let owned_pb = match &sv_p6 {
        crate::lower::types::Vl::VlOwned(_, _) => !chain_pa,
        _ => false,
    };
    let pats_pc = if owned_pb {
        run_to_end(each_job(crate::check::errors::range0(&len(arms_p3)), {
            let lx_p0 = lx_p0.clone();
            let arms_p3 = arms_p3.clone();
            let sty_p7 = sty_p7.clone();
            let label_p8 = label_p8.clone();
            Rc::new(move |p0: Nat| {
                let lx_p0 = lx_p0.clone();
                let arms_p3 = arms_p3.clone();
                let sty_p7 = sty_p7.clone();
                let label_p8 = label_p8.clone();
                entered(once_job(move || {
                    let i_pk = p0;
                    prism_rtl::Turn::More(Rc::new(ArmPat { lx_p0: lx_p0.clone(), opt1: or(&index(&arms_p3, &i_pk), &dummy_arm()).pattern.clone(), ty_p2: sty_p7.clone(), mode_p3: crate::lower::types::Holding::Owned, fresh_p4: Text::from(format!("{}_{}", &label_p8, &i_pk)) }))
                }))
            }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<crate::lower::patterns::PatOut>>>
        }))
    } else {
        by_ref_p9.clone()
    };
    let xarms_pd = run_to_end(each_job(crate::check::errors::range0(&len(arms_p3)), {
        let arms_p3 = arms_p3.clone();
        let pats_pc = pats_pc.clone();
        let env_p1 = env_p1.clone();
        let lx_p0 = lx_p0.clone();
        let owned_pb = owned_pb;
        Rc::new(move |p0: Nat| {
            let arms_p3 = arms_p3.clone();
            let pats_pc = pats_pc.clone();
            let env_p1 = env_p1.clone();
            let lx_p0 = lx_p0.clone();
            let owned_pb = owned_pb;
            entered(once_job(move || {
                let i_pl = p0;
                {
                    let arm_pm = or(&index(&arms_p3, &i_pl), &dummy_arm());
                    let po_pn = or(&index(&pats_pc, &i_pl), &crate::lower::patterns::PatOut { pa: crate::lower::model::Pa::PaWild, conds: Array::new(), binds: Array::new() });
                    let env2_po = bind_all(&env_p1, &po_pn.binds);
                    let guard_pp = match &arm_pm.guard {
                        Some(ge_pr) => Array::from(vec![crate::lower::model::Cc::CcIf(crate::lower::types::as_bool(&value_of(&lx_p0, &env2_po, ge_pr)))]),
                        None => Array::new(),
                    };
                    let env3_pq = if owned_pb {
                        moved_once(&lx_p0, &env2_po, &arm_pm, &po_pn.binds)
                    } else {
                        env2_po.clone()
                    };
                    call_then(start_block_value(lx_p0.clone(), env3_pq.clone(), arm_pm.body.clone()), move |block_value_66248: crate::lower::types::Vl| prism_rtl::Turn::Finished(crate::lower::model::XArm { pat: po_pn.pa.clone(), conds: append(&po_pn.conds, &guard_pp), body: crate::lower::types::own(&block_value_66248) }))
                }
            }))
        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<crate::lower::model::XArm>>>
    }));
    let scrut_pe = if owned_pb {
        crate::lower::types::own(&sv_p6)
    } else {
        crate::lower::types::ref_(&sv_p6)
    };
    arms_value(&scrut_pe, &xarms_pd, &label_p8, t_p4)
}

/// The step machine of `MatchValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// MatchValue: unbounded fn Lx, Env, Expr, [Arm], OutTy, Range -> Vl
/// ```
pub struct MatchValue {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub s_p2: crate::syntax::Expr,
    pub arms_p3: Array<crate::syntax::Arm>,
    pub t_p4: crate::lower::model::OutTy,
    pub span_p5: crate::syntax::Range,
}

impl prism_rtl::Job<crate::lower::types::Vl> for MatchValue {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::types::Vl> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let s_p2 = &self.s_p2;
        let arms_p3 = &self.arms_p3;
        let t_p4 = &self.t_p4;
        let span_p5 = &self.span_p5;
        let arms_p3 = arms_p3.clone();
        let env_p1 = env_p1.clone();
        let lx_p0 = lx_p0.clone();
        let s_p2 = s_p2.clone();
        let span_p5 = span_p5.clone();
        let t_p4 = t_p4.clone();
        call_then(start_value_of(lx_p0.clone(), env_p1.clone(), s_p2.clone()), move |value_of_65259: crate::lower::types::Vl| {
            let sv_p6 = value_of_65259;
            let sty_p7 = crate::lower::type_at(&lx_p0, &s_p2.span);
            let label_p8 = Text::from(format!("m{}", &span_p5.start));
            call_value(each_job(crate::check::errors::range0(&len(&arms_p3)), {
                let lx_p0 = lx_p0.clone();
                let arms_p3 = arms_p3.clone();
                let sty_p7 = sty_p7.clone();
                let label_p8 = label_p8.clone();
                Rc::new(move |p0: Nat| {
                    let lx_p0 = lx_p0.clone();
                    let arms_p3 = arms_p3.clone();
                    let sty_p7 = sty_p7.clone();
                    let label_p8 = label_p8.clone();
                    entered(once_job(move || {
                        let i_pf = p0;
                        prism_rtl::Turn::More(Rc::new(ArmPat { lx_p0: lx_p0.clone(), opt1: or(&index(&arms_p3, &i_pf), &dummy_arm()).pattern.clone(), ty_p2: sty_p7.clone(), mode_p3: crate::lower::types::Holding::ByRef, fresh_p4: Text::from(format!("{}_{}", &label_p8, &i_pf)) }))
                    }))
                }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<crate::lower::patterns::PatOut>>>
            }), move |each_65358: Array<crate::lower::patterns::PatOut>| {
                let by_ref_p9 = each_65358;
                let chain_pa = fold(&by_ref_p9, &false, &(|f_pg: &bool, po_ph: &crate::lower::patterns::PatOut| *f_pg || fold(&po_ph.conds, &false, &(|f2_pi: &bool, c_pj: &crate::lower::model::Cc| *f2_pi || is_let_cond(c_pj)))));
                let owned_pb = match &sv_p6 {
                    crate::lower::types::Vl::VlOwned(_, _) => !chain_pa,
                    _ => false,
                };
                let pats_pc = if owned_pb {
                    run_to_end(each_job(crate::check::errors::range0(&len(&arms_p3)), {
                        let lx_p0 = lx_p0.clone();
                        let arms_p3 = arms_p3.clone();
                        let sty_p7 = sty_p7.clone();
                        let label_p8 = label_p8.clone();
                        Rc::new(move |p0: Nat| {
                            let lx_p0 = lx_p0.clone();
                            let arms_p3 = arms_p3.clone();
                            let sty_p7 = sty_p7.clone();
                            let label_p8 = label_p8.clone();
                            entered(once_job(move || {
                                let i_pk = p0;
                                prism_rtl::Turn::More(Rc::new(ArmPat { lx_p0: lx_p0.clone(), opt1: or(&index(&arms_p3, &i_pk), &dummy_arm()).pattern.clone(), ty_p2: sty_p7.clone(), mode_p3: crate::lower::types::Holding::Owned, fresh_p4: Text::from(format!("{}_{}", &label_p8, &i_pk)) }))
                            }))
                        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<crate::lower::patterns::PatOut>>>
                    }))
                } else {
                    by_ref_p9.clone()
                };
                call_value(each_job(crate::check::errors::range0(&len(&arms_p3)), {
                    let arms_p3 = arms_p3.clone();
                    let pats_pc = pats_pc.clone();
                    let env_p1 = env_p1.clone();
                    let lx_p0 = lx_p0.clone();
                    let owned_pb = owned_pb;
                    Rc::new(move |p0: Nat| {
                        let arms_p3 = arms_p3.clone();
                        let pats_pc = pats_pc.clone();
                        let env_p1 = env_p1.clone();
                        let lx_p0 = lx_p0.clone();
                        let owned_pb = owned_pb;
                        entered(once_job(move || {
                            let i_pl = p0;
                            {
                                let arm_pm = or(&index(&arms_p3, &i_pl), &dummy_arm());
                                let po_pn = or(&index(&pats_pc, &i_pl), &crate::lower::patterns::PatOut { pa: crate::lower::model::Pa::PaWild, conds: Array::new(), binds: Array::new() });
                                let env2_po = bind_all(&env_p1, &po_pn.binds);
                                let guard_pp = match &arm_pm.guard {
                                    Some(ge_pr) => Array::from(vec![crate::lower::model::Cc::CcIf(crate::lower::types::as_bool(&value_of(&lx_p0, &env2_po, ge_pr)))]),
                                    None => Array::new(),
                                };
                                let env3_pq = if owned_pb {
                                    moved_once(&lx_p0, &env2_po, &arm_pm, &po_pn.binds)
                                } else {
                                    env2_po.clone()
                                };
                                call_then(start_block_value(lx_p0.clone(), env3_pq.clone(), arm_pm.body.clone()), move |block_value_66248: crate::lower::types::Vl| prism_rtl::Turn::Finished(crate::lower::model::XArm { pat: po_pn.pa.clone(), conds: append(&po_pn.conds, &guard_pp), body: crate::lower::types::own(&block_value_66248) }))
                            }
                        }))
                    }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<crate::lower::model::XArm>>>
                }), move |each_65804: Array<crate::lower::model::XArm>| {
                    let xarms_pd = each_65804;
                    let scrut_pe = if owned_pb {
                        crate::lower::types::own(&sv_p6)
                    } else {
                        crate::lower::types::ref_(&sv_p6)
                    };
                    prism_rtl::Turn::Finished(arms_value(&scrut_pe, &xarms_pd, &label_p8, &t_p4))
                })
            })
        })
    }
}

/// `Start MatchValue, x`: what the function value is when passed to `@Run`.
pub fn start_match_value(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, s_p2: crate::syntax::Expr, arms_p3: Array<crate::syntax::Arm>, t_p4: crate::lower::model::OutTy, span_p5: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<crate::lower::types::Vl>> {
    Rc::new(MatchValue { lx_p0, env_p1, s_p2, arms_p3, t_p4, span_p5 })
}

/// ```prism
/// MovedOnce: unbounded fn Lx, Env, Arm, [((Text, Bn))] -> Env
/// ```
pub fn moved_once(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, arm_p2: &crate::syntax::Arm, binds_p3: &Array<(Text, crate::lower::types::Bn)>) -> crate::lower::types::Env {
    run_to_end(fold_job(binds_p3.clone(), env_p1.clone(), {
        let lx_p0 = lx_p0.clone();
        let arm_p2 = arm_p2.clone();
        Rc::new(move |(p0, p1): (crate::lower::types::Env, (Text, crate::lower::types::Bn))| {
            let lx_p0 = lx_p0.clone();
            let arm_p2 = arm_p2.clone();
            entered(once_job(move || {
                let en_p4 = p0;
                let (nkey_p5, bn_p6) = p1;
                match &bn_p6 {
                    crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(rs_p7), crate::lower::types::Holding::Owned, bt_p8) => {
                        let bt_p8 = bt_p8.clone();
                        let rs_p7 = rs_p7.clone();
                        call_then(start_only_read(lx_p0.clone(), arm_p2.clone(), nkey_p5.clone()), move |only_read_66897: Option<crate::syntax::Expr>| match only_read_66897 {
                            Some(x_p9) => prism_rtl::Turn::Finished(crate::lower::types::bind_span(&en_p4, &crate::lower::place_key(&lx_p0, &x_p9.span), &crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XVar(rs_p7.clone()), bt_p8.clone()))),
                            None => prism_rtl::Turn::Finished(en_p4.clone()),
                        })
                    },
                    _ => prism_rtl::Turn::Finished(en_p4.clone()),
                }
            }))
        }) as Rc<dyn Fn((crate::lower::types::Env, (Text, crate::lower::types::Bn))) -> Rc<dyn prism_rtl::Job<crate::lower::types::Env>>>
    }))
}

/// The step machine of `MovedOnce`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// MovedOnce: unbounded fn Lx, Env, Arm, [((Text, Bn))] -> Env
/// ```
pub struct MovedOnce {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub arm_p2: crate::syntax::Arm,
    pub binds_p3: Array<(Text, crate::lower::types::Bn)>,
}

impl prism_rtl::Job<crate::lower::types::Env> for MovedOnce {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::types::Env> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let arm_p2 = &self.arm_p2;
        let binds_p3 = &self.binds_p3;
        fold_job(binds_p3.clone(), env_p1.clone(), {
            let lx_p0 = lx_p0.clone();
            let arm_p2 = arm_p2.clone();
            Rc::new(move |(p0, p1): (crate::lower::types::Env, (Text, crate::lower::types::Bn))| {
                let lx_p0 = lx_p0.clone();
                let arm_p2 = arm_p2.clone();
                entered(once_job(move || {
                    let en_p4 = p0;
                    let (nkey_p5, bn_p6) = p1;
                    match &bn_p6 {
                        crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(rs_p7), crate::lower::types::Holding::Owned, bt_p8) => {
                            let bt_p8 = bt_p8.clone();
                            let rs_p7 = rs_p7.clone();
                            call_then(start_only_read(lx_p0.clone(), arm_p2.clone(), nkey_p5.clone()), move |only_read_66897: Option<crate::syntax::Expr>| match only_read_66897 {
                                Some(x_p9) => prism_rtl::Turn::Finished(crate::lower::types::bind_span(&en_p4, &crate::lower::place_key(&lx_p0, &x_p9.span), &crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XVar(rs_p7.clone()), bt_p8.clone()))),
                                None => prism_rtl::Turn::Finished(en_p4.clone()),
                            })
                        },
                        _ => prism_rtl::Turn::Finished(en_p4.clone()),
                    }
                }))
            }) as Rc<dyn Fn((crate::lower::types::Env, (Text, crate::lower::types::Bn))) -> Rc<dyn prism_rtl::Job<crate::lower::types::Env>>>
        }).cycle()
    }
}

/// `Start MovedOnce, x`: what the function value is when passed to `@Run`.
pub fn start_moved_once(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, arm_p2: crate::syntax::Arm, binds_p3: Array<(Text, crate::lower::types::Bn)>) -> Rc<dyn prism_rtl::Job<crate::lower::types::Env>> {
    Rc::new(MovedOnce { lx_p0, env_p1, arm_p2, binds_p3 })
}

/// ```prism
/// ?OnlyRead: unbounded fn Lx, Arm, Text -> ?Expr
/// ```
pub fn only_read(lx_p0: &crate::lower::Lx, arm_p1: &crate::syntax::Arm, nkey_p2: &Text) -> Option<crate::syntax::Expr> {
    let text_p3 = crate::lower::functions::src_text(lx_p0, &lx_p0.file, &arm_p1.body.span);
    let in_guard_p5 = match &arm_p1.guard {
        Some(ge_p4) => &word_count(&crate::lower::functions::src_text(lx_p0, &lx_p0.file, &ge_p4.span), nkey_p2) > &Nat::from(0u32),
        None => false,
    };
    let reads_p8 = filter(&crate::check::typed::print::block_exprs(&arm_p1.body), &(|x_p6: &crate::syntax::Expr| match &*x_p6.kind {
        crate::syntax::ExprKind::EName(n_p7) => (&len(&n_p7.path_) == &Nat::from(1u32)) && (&crate::check::env::sname_key(n_p7) == nkey_p2),
        _ => false,
    }));
    let plain_p9 = ((!in_guard_p5 && (&word_count(&text_p3, nkey_p2) == &Nat::from(1u32))) && !crate::syntax::lexer::chars::contains(&text_p3, &Text::lit("\\|"))) && (&len(&matches(&{ thread_local!(static R: Regex = Regex::lit("\\b(while|for)\\b", "")); R.with(Regex::clone) }, &text_p3)) == &Nat::from(0u32));
    if plain_p9 && (&len(&reads_p8) == &Nat::from(1u32)) {
        index(&reads_p8, &Nat::from(0u32))
    } else {
        None
    }
}

/// The step machine of `OnlyRead`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?OnlyRead: unbounded fn Lx, Arm, Text -> ?Expr
/// ```
pub struct OnlyRead {
    pub lx_p0: crate::lower::Lx,
    pub arm_p1: crate::syntax::Arm,
    pub nkey_p2: Text,
}

impl prism_rtl::Job<Option<crate::syntax::Expr>> for OnlyRead {
    fn cycle(&self) -> prism_rtl::Turn<Option<crate::syntax::Expr>> {
        let lx_p0 = &self.lx_p0;
        let arm_p1 = &self.arm_p1;
        let nkey_p2 = &self.nkey_p2;
        let text_p3 = crate::lower::functions::src_text(lx_p0, &lx_p0.file, &arm_p1.body.span);
        let in_guard_p5 = match &arm_p1.guard {
            Some(ge_p4) => &word_count(&crate::lower::functions::src_text(lx_p0, &lx_p0.file, &ge_p4.span), nkey_p2) > &Nat::from(0u32),
            None => false,
        };
        let arm_p1 = arm_p1.clone();
        let nkey_p2 = nkey_p2.clone();
        call_then(crate::check::typed::print::start_block_exprs(arm_p1.body.clone()), move |block_exprs_67301: Array<crate::syntax::Expr>| {
            let reads_p8 = filter(&block_exprs_67301, &(|x_p6: &crate::syntax::Expr| match &*x_p6.kind {
                crate::syntax::ExprKind::EName(n_p7) => (&len(&n_p7.path_) == &Nat::from(1u32)) && (&crate::check::env::sname_key(n_p7) == &nkey_p2),
                _ => false,
            }));
            let plain_p9 = ((!in_guard_p5 && (&word_count(&text_p3, &nkey_p2) == &Nat::from(1u32))) && !crate::syntax::lexer::chars::contains(&text_p3, &Text::lit("\\|"))) && (&len(&matches(&{ thread_local!(static R: Regex = Regex::lit("\\b(while|for)\\b", "")); R.with(Regex::clone) }, &text_p3)) == &Nat::from(0u32));
            if plain_p9 && (&len(&reads_p8) == &Nat::from(1u32)) {
                prism_rtl::Turn::Finished(index(&reads_p8, &Nat::from(0u32)))
            } else {
                prism_rtl::Turn::Finished(None)
            }
        })
    }
}

/// `Start OnlyRead, x`: what the function value is when passed to `@Run`.
pub fn start_only_read(lx_p0: crate::lower::Lx, arm_p1: crate::syntax::Arm, nkey_p2: Text) -> Rc<dyn prism_rtl::Job<Option<crate::syntax::Expr>>> {
    Rc::new(OnlyRead { lx_p0, arm_p1, nkey_p2 })
}

/// ```prism
/// WordCount: fn Text, Text -> Nat
/// ```
pub fn word_count(text_p0: &Text, name_p1: &Text) -> Nat {
    len(&filter(&matches(&{ thread_local!(static R: Regex = Regex::lit("[?~$!@&]*[A-Za-z_][A-Za-z0-9_]*", "")); R.with(Regex::clone) }, text_p0), &(|m_p2: &Match| &m_p2.text == name_p1)))
}

/// ```prism
/// let dummyArm
/// ```
pub fn dummy_arm() -> crate::syntax::Arm {
    crate::syntax::Arm { pattern: None, guard: None, body: crate::syntax::Block { stmts: Array::new(), inline: true, span: crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) } }, span: crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) } }
}

/// ```prism
/// ArmPat: unbounded fn Lx, ?Pattern, Ty, Holding, Text -> PatOut
/// ```
pub fn arm_pat(lx_p0: &crate::lower::Lx, opt1: &Option<crate::syntax::Pattern_>, ty_p2: &crate::check::types::Ty, mode_p3: &crate::lower::types::Holding, fresh_p4: &Text) -> crate::lower::patterns::PatOut {
    match opt1 {
        Some(p_p1) => crate::lower::patterns::rust_pat(lx_p0, p_p1, ty_p2, mode_p3, fresh_p4),
        None => crate::lower::patterns::PatOut { pa: crate::lower::model::Pa::PaWild, conds: Array::new(), binds: Array::new() },
    }
}

/// The step machine of `ArmPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ArmPat: unbounded fn Lx, ?Pattern, Ty, Holding, Text -> PatOut
/// ```
pub struct ArmPat {
    pub lx_p0: crate::lower::Lx,
    pub opt1: Option<crate::syntax::Pattern_>,
    pub ty_p2: crate::check::types::Ty,
    pub mode_p3: crate::lower::types::Holding,
    pub fresh_p4: Text,
}

impl prism_rtl::Job<crate::lower::patterns::PatOut> for ArmPat {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::patterns::PatOut> {
        let lx_p0 = &self.lx_p0;
        let opt1 = &self.opt1;
        let ty_p2 = &self.ty_p2;
        let mode_p3 = &self.mode_p3;
        let fresh_p4 = &self.fresh_p4;
        match opt1 {
            Some(p_p1) => prism_rtl::Turn::More(Rc::new(crate::lower::patterns::RustPat { lx_p0: lx_p0.clone(), p_p1: p_p1.clone(), ty_p2: ty_p2.clone(), mode_p3: mode_p3.clone(), fresh_p4: fresh_p4.clone() })),
            None => prism_rtl::Turn::Finished(crate::lower::patterns::PatOut { pa: crate::lower::model::Pa::PaWild, conds: Array::new(), binds: Array::new() }),
        }
    }
}

/// `Start ArmPat, x`: what the function value is when passed to `@Run`.
pub fn start_arm_pat(lx_p0: crate::lower::Lx, opt1: Option<crate::syntax::Pattern_>, ty_p2: crate::check::types::Ty, mode_p3: crate::lower::types::Holding, fresh_p4: Text) -> Rc<dyn prism_rtl::Job<crate::lower::patterns::PatOut>> {
    Rc::new(ArmPat { lx_p0, opt1, ty_p2, mode_p3, fresh_p4 })
}

/// ```prism
/// BlockValue: unbounded fn Lx, Env, Block -> Vl
/// ```
pub fn block_value(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, b_p2: &crate::syntax::Block) -> crate::lower::types::Vl {
    if is_given_block(&b_p2.stmts) {
        crate::lower::templates::given_value(lx_p0, env_p1, b_p2, &block_ty(lx_p0, b_p2), &b_p2.span)
    } else {
        plain_block_value(lx_p0, env_p1, b_p2)
    }
}

/// The step machine of `BlockValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BlockValue: unbounded fn Lx, Env, Block -> Vl
/// ```
pub struct BlockValue {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub b_p2: crate::syntax::Block,
}

impl prism_rtl::Job<crate::lower::types::Vl> for BlockValue {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::types::Vl> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let b_p2 = &self.b_p2;
        if is_given_block(&b_p2.stmts) {
            {
                let b_p2 = b_p2.clone();
                let env_p1 = env_p1.clone();
                let lx_p0 = lx_p0.clone();
                call_then(start_block_ty(lx_p0.clone(), b_p2.clone()), move |block_ty_68451: crate::lower::model::OutTy| prism_rtl::Turn::More(Rc::new(crate::lower::templates::GivenValue { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), b_p2: b_p2.clone(), t_p3: block_ty_68451, span_p4: b_p2.span.clone() })))
            }
        } else {
            prism_rtl::Turn::More(Rc::new(PlainBlockValue { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), b_p2: b_p2.clone() }))
        }
    }
}

/// `Start BlockValue, x`: what the function value is when passed to `@Run`.
pub fn start_block_value(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, b_p2: crate::syntax::Block) -> Rc<dyn prism_rtl::Job<crate::lower::types::Vl>> {
    Rc::new(BlockValue { lx_p0, env_p1, b_p2 })
}

/// ```prism
/// IsGivenBlock: fn [Stmt] -> Bool
/// ```
pub fn is_given_block(stmts_p0: &Array<crate::syntax::Stmt>) -> bool {
    fold(stmts_p0, &false, &(|f_p1: &bool, s_p2: &crate::syntax::Stmt| *f_p1 || is_guardish(s_p2)))
}

/// ```prism
/// IsGuardish: fn Stmt -> Bool
/// ```
pub fn is_guardish(s_p0: &crate::syntax::Stmt) -> bool {
    match &s_p0.kind {
        crate::syntax::StmtKind::SBind(_, _, None) => true,
        crate::syntax::StmtKind::SRequire(_) => true,
        crate::syntax::StmtKind::SForbid(_) => true,
        _ => false,
    }
}

/// ```prism
/// BlockTy: unbounded fn Lx, Block -> OutTy
/// ```
pub fn block_ty(lx_p0: &crate::lower::Lx, b_p1: &crate::syntax::Block) -> crate::lower::model::OutTy {
    match &or(&index(&b_p1.stmts, &crate::syntax::lexer::chars::dec(&len(&b_p1.stmts))), &dummy_stmt_l()).kind {
        crate::syntax::StmtKind::SExpr(x_p2) => crate::lower::types::out_ty_of(lx_p0, &crate::lower::types::peel(&crate::lower::type_at(lx_p0, &x_p2.span))),
        _ => crate::lower::model::OutTy::OutUnit,
    }
}

/// The step machine of `BlockTy`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BlockTy: unbounded fn Lx, Block -> OutTy
/// ```
pub struct BlockTy {
    pub lx_p0: crate::lower::Lx,
    pub b_p1: crate::syntax::Block,
}

impl prism_rtl::Job<crate::lower::model::OutTy> for BlockTy {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::OutTy> {
        let lx_p0 = &self.lx_p0;
        let b_p1 = &self.b_p1;
        match &or(&index(&b_p1.stmts, &crate::syntax::lexer::chars::dec(&len(&b_p1.stmts))), &dummy_stmt_l()).kind {
            crate::syntax::StmtKind::SExpr(x_p2) => prism_rtl::Turn::More(Rc::new(crate::lower::types::OutTyOf { lx_p0: lx_p0.clone(), t_p1: crate::lower::types::peel(&crate::lower::type_at(lx_p0, &x_p2.span)) })),
            _ => prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutUnit),
        }
    }
}

/// `Start BlockTy, x`: what the function value is when passed to `@Run`.
pub fn start_block_ty(lx_p0: crate::lower::Lx, b_p1: crate::syntax::Block) -> Rc<dyn prism_rtl::Job<crate::lower::model::OutTy>> {
    Rc::new(BlockTy { lx_p0, b_p1 })
}

/// ```prism
/// PlainBlockValue: unbounded fn Lx, Env, Block -> Vl
/// ```
pub fn plain_block_value(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, b_p2: &crate::syntax::Block) -> crate::lower::types::Vl {
    let n_p3 = len(&b_p2.stmts);
    let (dos_pf, env2_pg, last_oh) = run_to_end(fold_job(crate::check::errors::range0(&n_p3), (Array::new(), env_p1.clone(), None), {
        let b_p2 = b_p2.clone();
        let n_p3 = n_p3.clone();
        let lx_p0 = lx_p0.clone();
        Rc::new(move |(p0, p1): ((Array<crate::lower::model::Do>, crate::lower::types::Env, Option<crate::lower::types::Vl>), Nat)| {
            let b_p2 = b_p2.clone();
            let n_p3 = n_p3.clone();
            let lx_p0 = lx_p0.clone();
            entered(once_job(move || {
                let (acc_p5, en_p6, lv_o7) = p0;
                let i_p8 = p1;
                {
                    let s_p9 = or(&index(&b_p2.stmts, &i_p8), &dummy_stmt_l());
                    if &(&i_p8 + &Nat::from(1u32)) == &n_p3 {
                        match &s_p9.kind {
                            crate::syntax::StmtKind::SExpr(x_pa) => prism_rtl::Turn::Finished((acc_p5.clone(), en_p6.clone(), Some(value_of(&lx_p0, &en_p6, x_pa)))),
                            _ => call_then(start_block_stmt(lx_p0.clone(), en_p6.clone(), s_p9.clone()), move |block_stmt_69493: (Array<crate::lower::model::Do>, crate::lower::types::Env)| {
                                let (more_pb, en2_pc) = block_stmt_69493;
                                prism_rtl::Turn::Finished((append(&acc_p5, &more_pb), en2_pc.clone(), None))
                            }),
                        }
                    } else {
                        call_then(start_block_stmt(lx_p0.clone(), en_p6.clone(), s_p9.clone()), move |block_stmt_69608: (Array<crate::lower::model::Do>, crate::lower::types::Env)| {
                            let (more_pd, en2_pe) = block_stmt_69608;
                            prism_rtl::Turn::Finished((append(&acc_p5, &more_pd), en2_pe.clone(), lv_o7.clone()))
                        })
                    }
                }
            }))
        }) as Rc<dyn Fn(((Array<crate::lower::model::Do>, crate::lower::types::Env, Option<crate::lower::types::Vl>), Nat)) -> Rc<dyn prism_rtl::Job<(Array<crate::lower::model::Do>, crate::lower::types::Env, Option<crate::lower::types::Vl>)>>>
    }));
    let last_p4 = or(&last_oh, &crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XUnit, crate::lower::model::OutTy::OutUnit));
    if &len(&dos_pf) == &Nat::from(0u32) {
        last_p4.clone()
    } else {
        crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XBlock(dos_pf.clone(), Rc::new(crate::lower::types::own(&last_p4))), crate::lower::types::value_ty(&last_p4))
    }
}

/// The step machine of `PlainBlockValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PlainBlockValue: unbounded fn Lx, Env, Block -> Vl
/// ```
pub struct PlainBlockValue {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub b_p2: crate::syntax::Block,
}

impl prism_rtl::Job<crate::lower::types::Vl> for PlainBlockValue {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::types::Vl> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let b_p2 = &self.b_p2;
        let n_p3 = len(&b_p2.stmts);
        let b_p2 = b_p2.clone();
        let env_p1 = env_p1.clone();
        let lx_p0 = lx_p0.clone();
        call_value(fold_job(crate::check::errors::range0(&n_p3), (Array::new(), env_p1.clone(), None), {
            let b_p2 = b_p2.clone();
            let n_p3 = n_p3.clone();
            let lx_p0 = lx_p0.clone();
            Rc::new(move |(p0, p1): ((Array<crate::lower::model::Do>, crate::lower::types::Env, Option<crate::lower::types::Vl>), Nat)| {
                let b_p2 = b_p2.clone();
                let n_p3 = n_p3.clone();
                let lx_p0 = lx_p0.clone();
                entered(once_job(move || {
                    let (acc_p5, en_p6, lv_o7) = p0;
                    let i_p8 = p1;
                    {
                        let s_p9 = or(&index(&b_p2.stmts, &i_p8), &dummy_stmt_l());
                        if &(&i_p8 + &Nat::from(1u32)) == &n_p3 {
                            match &s_p9.kind {
                                crate::syntax::StmtKind::SExpr(x_pa) => prism_rtl::Turn::Finished((acc_p5.clone(), en_p6.clone(), Some(value_of(&lx_p0, &en_p6, x_pa)))),
                                _ => call_then(start_block_stmt(lx_p0.clone(), en_p6.clone(), s_p9.clone()), move |block_stmt_69493: (Array<crate::lower::model::Do>, crate::lower::types::Env)| {
                                    let (more_pb, en2_pc) = block_stmt_69493;
                                    prism_rtl::Turn::Finished((append(&acc_p5, &more_pb), en2_pc.clone(), None))
                                }),
                            }
                        } else {
                            call_then(start_block_stmt(lx_p0.clone(), en_p6.clone(), s_p9.clone()), move |block_stmt_69608: (Array<crate::lower::model::Do>, crate::lower::types::Env)| {
                                let (more_pd, en2_pe) = block_stmt_69608;
                                prism_rtl::Turn::Finished((append(&acc_p5, &more_pd), en2_pe.clone(), lv_o7.clone()))
                            })
                        }
                    }
                }))
            }) as Rc<dyn Fn(((Array<crate::lower::model::Do>, crate::lower::types::Env, Option<crate::lower::types::Vl>), Nat)) -> Rc<dyn prism_rtl::Job<(Array<crate::lower::model::Do>, crate::lower::types::Env, Option<crate::lower::types::Vl>)>>>
        }), move |fold_69239: (Array<crate::lower::model::Do>, crate::lower::types::Env, Option<crate::lower::types::Vl>)| {
            let (dos_pf, env2_pg, last_oh) = fold_69239;
            let last_p4 = or(&last_oh, &crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XUnit, crate::lower::model::OutTy::OutUnit));
            if &len(&dos_pf) == &Nat::from(0u32) {
                prism_rtl::Turn::Finished(last_p4.clone())
            } else {
                prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XBlock(dos_pf.clone(), Rc::new(crate::lower::types::own(&last_p4))), crate::lower::types::value_ty(&last_p4)))
            }
        })
    }
}

/// `Start PlainBlockValue, x`: what the function value is when passed to `@Run`.
pub fn start_plain_block_value(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, b_p2: crate::syntax::Block) -> Rc<dyn prism_rtl::Job<crate::lower::types::Vl>> {
    Rc::new(PlainBlockValue { lx_p0, env_p1, b_p2 })
}

/// ```prism
/// let dummyStmtL
/// ```
pub fn dummy_stmt_l() -> crate::syntax::Stmt {
    crate::syntax::Stmt { kind: crate::syntax::StmtKind::SExpr(crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EError), span: crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) } }), span: crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) } }
}

/// ```prism
/// BlockStmt: unbounded fn Lx, Env, Stmt -> (([Do], Env))
/// ```
pub fn block_stmt(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, s_p2: &crate::syntax::Stmt) -> (Array<crate::lower::model::Do>, crate::lower::types::Env) {
    match &s_p2.kind {
        crate::syntax::StmtKind::SLet(p_p3, _, x_p4) => match &*p_p3.kind {
            crate::syntax::PatternKind::PName(n_p5) => match get(&lx_p0.gens, &crate::lower::place_key(lx_p0, &n_p5.span)) {
                Some(gn_p6) => generic_let(lx_p0, env_p1, n_p5, &gn_p6, x_p4),
                None => plain_let(lx_p0, env_p1, s_p2, p_p3, x_p4),
            },
            _ => plain_let(lx_p0, env_p1, s_p2, p_p3, x_p4),
        },
        crate::syntax::StmtKind::SExpr(x_p7) => (Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::types::own(&value_of(lx_p0, env_p1, x_p7)))]), env_p1.clone()),
        crate::syntax::StmtKind::SSignature(_) => (Array::new(), env_p1.clone()),
        crate::syntax::StmtKind::SFn(f_p8) => (Array::from(vec![refusal_do(&Text::from(format!("a local function {}: not lowered yet", &crate::check::env::def_name_text(&f_p8.name))))]), env_p1.clone()),
        _ => (Array::from(vec![refusal_do(&Text::lit("a statement this back end does not lower yet"))]), env_p1.clone()),
    }
}

/// The step machine of `BlockStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BlockStmt: unbounded fn Lx, Env, Stmt -> (([Do], Env))
/// ```
pub struct BlockStmt {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub s_p2: crate::syntax::Stmt,
}

impl prism_rtl::Job<(Array<crate::lower::model::Do>, crate::lower::types::Env)> for BlockStmt {
    fn cycle(&self) -> prism_rtl::Turn<(Array<crate::lower::model::Do>, crate::lower::types::Env)> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let s_p2 = &self.s_p2;
        match &s_p2.kind {
            crate::syntax::StmtKind::SLet(p_p3, _, x_p4) => match &*p_p3.kind {
                crate::syntax::PatternKind::PName(n_p5) => match get(&lx_p0.gens, &crate::lower::place_key(lx_p0, &n_p5.span)) {
                    Some(gn_p6) => prism_rtl::Turn::More(Rc::new(GenericLet { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), n_p2: n_p5.clone(), gn_p3: gn_p6.clone(), x_p4: x_p4.clone() })),
                    None => prism_rtl::Turn::More(Rc::new(PlainLet { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), s_p2: s_p2.clone(), p_p3: p_p3.clone(), x_p4: x_p4.clone() })),
                },
                _ => prism_rtl::Turn::More(Rc::new(PlainLet { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), s_p2: s_p2.clone(), p_p3: p_p3.clone(), x_p4: x_p4.clone() })),
            },
            crate::syntax::StmtKind::SExpr(x_p7) => {
                let env_p1 = env_p1.clone();
                let lx_p0 = lx_p0.clone();
                let x_p7 = x_p7.clone();
                call_then(start_value_of(lx_p0.clone(), env_p1.clone(), x_p7.clone()), move |value_of_70316: crate::lower::types::Vl| prism_rtl::Turn::Finished((Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::types::own(&value_of_70316))]), env_p1.clone())))
            },
            crate::syntax::StmtKind::SSignature(_) => prism_rtl::Turn::Finished((Array::new(), env_p1.clone())),
            crate::syntax::StmtKind::SFn(f_p8) => prism_rtl::Turn::Finished((Array::from(vec![refusal_do(&Text::from(format!("a local function {}: not lowered yet", &crate::check::env::def_name_text(&f_p8.name))))]), env_p1.clone())),
            _ => prism_rtl::Turn::Finished((Array::from(vec![refusal_do(&Text::lit("a statement this back end does not lower yet"))]), env_p1.clone())),
        }
    }
}

/// `Start BlockStmt, x`: what the function value is when passed to `@Run`.
pub fn start_block_stmt(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, s_p2: crate::syntax::Stmt) -> Rc<dyn prism_rtl::Job<(Array<crate::lower::model::Do>, crate::lower::types::Env)>> {
    Rc::new(BlockStmt { lx_p0, env_p1, s_p2 })
}

/// ```prism
/// GenericLet: unbounded fn Lx, Env, SName, GenNote, Expr -> (([Do], Env))
/// ```
pub fn generic_let(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, n_p2: &crate::syntax::SName, gn_p3: &crate::check::typed::GenNote, x_p4: &crate::syntax::Expr) -> (Array<crate::lower::model::Do>, crate::lower::types::Env) {
    let nkey_p5 = crate::check::env::sname_key(n_p2);
    let distinct_p6 = instantiations(lx_p0, gn_p3);
    let one_p7 = &len(&distinct_p6) == &Nat::from(1u32);
    let rs_p8 = crate::lower::local_name_at(lx_p0, &nkey_p5, &n_p2.span);
    run_to_end(fold_job(crate::check::errors::range0(&len(&distinct_p6)), (Array::new(), env_p1.clone()), {
        let distinct_p6 = distinct_p6.clone();
        let lx_p0 = lx_p0.clone();
        let one_p7 = one_p7;
        let rs_p8 = rs_p8.clone();
        let nkey_p5 = nkey_p5.clone();
        let n_p2 = n_p2.clone();
        let env_p1 = env_p1.clone();
        let x_p4 = x_p4.clone();
        Rc::new(move |(p0, p1): ((Array<crate::lower::model::Do>, crate::lower::types::Env), Nat)| {
            let distinct_p6 = distinct_p6.clone();
            let lx_p0 = lx_p0.clone();
            let one_p7 = one_p7;
            let rs_p8 = rs_p8.clone();
            let nkey_p5 = nkey_p5.clone();
            let n_p2 = n_p2.clone();
            let env_p1 = env_p1.clone();
            let x_p4 = x_p4.clone();
            entered(once_job(move || {
                let (dos_p9, en_pa) = p0;
                let k_pb = p1;
                {
                    let (tys_pk, cols_pl) = or(&index(&distinct_p6, &k_pb), &(Array::new(), Array::new()));
                    let lxk_pc = at_instance(&lx_p0, &(tys_pk.clone(), cols_pl.clone()));
                    let rk_pd = if one_p7 { rs_p8.clone() } else { Text::from(format!("{}w{}", &rs_p8, &k_pb)) };
                    let bkey_pe = if &k_pb == &Nat::from(0u32) {
                        nkey_p5.clone()
                    } else {
                        Text::from(format!("{}#inst{}", &nkey_p5, &k_pb))
                    };
                    call_then(crate::lower::types::start_out_ty_of(lxk_pc.clone(), crate::lower::types::peel(&crate::lower::binder_ty(&lxk_pc, &n_p2.span))), move |out_ty_of_71488: crate::lower::model::OutTy| {
                        let bt_pf = out_ty_of_71488;
                        call_then(start_value_of(lxk_pc.clone(), env_p1.clone(), x_p4.clone()), move |value_of_71547: crate::lower::types::Vl| {
                            let v_pg = value_of_71547;
                            let en1_ph = crate::lower::types::bind(&en_pa, &bkey_pe, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(rk_pd.clone()), crate::lower::types::Holding::Owned, bt_pf.clone()));
                            let en2_pi = {
                                let mut this: crate::lower::types::Env = en1_ph.clone();
                                this.uses = insert(&this.uses, &Text::from(format!("{}#{}", &nkey_p5, &show_text(&(tys_pk.clone(), cols_pl.clone())))), &bkey_pe);
                                this
                            };
                            let d_pj = crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(rk_pd.clone()), crate::lower::types::own(&v_pg));
                            prism_rtl::Turn::Finished((push(&dos_p9, &d_pj), en2_pi.clone()))
                        })
                    })
                }
            }))
        }) as Rc<dyn Fn(((Array<crate::lower::model::Do>, crate::lower::types::Env), Nat)) -> Rc<dyn prism_rtl::Job<(Array<crate::lower::model::Do>, crate::lower::types::Env)>>>
    }))
}

/// The step machine of `GenericLet`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// GenericLet: unbounded fn Lx, Env, SName, GenNote, Expr -> (([Do], Env))
/// ```
pub struct GenericLet {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub n_p2: crate::syntax::SName,
    pub gn_p3: crate::check::typed::GenNote,
    pub x_p4: crate::syntax::Expr,
}

impl prism_rtl::Job<(Array<crate::lower::model::Do>, crate::lower::types::Env)> for GenericLet {
    fn cycle(&self) -> prism_rtl::Turn<(Array<crate::lower::model::Do>, crate::lower::types::Env)> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let n_p2 = &self.n_p2;
        let gn_p3 = &self.gn_p3;
        let x_p4 = &self.x_p4;
        let nkey_p5 = crate::check::env::sname_key(n_p2);
        let env_p1 = env_p1.clone();
        let gn_p3 = gn_p3.clone();
        let lx_p0 = lx_p0.clone();
        let n_p2 = n_p2.clone();
        let x_p4 = x_p4.clone();
        call_then(start_instantiations(lx_p0.clone(), gn_p3.clone()), move |instantiations_71097: Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)>| {
            let distinct_p6 = instantiations_71097;
            let one_p7 = &len(&distinct_p6) == &Nat::from(1u32);
            call_then(crate::lower::start_local_name_at(lx_p0.clone(), nkey_p5.clone(), n_p2.span.clone()), move |local_name_at_71166: Text| {
                let rs_p8 = local_name_at_71166;
                fold_job(crate::check::errors::range0(&len(&distinct_p6)), (Array::new(), env_p1.clone()), {
                    let distinct_p6 = distinct_p6.clone();
                    let lx_p0 = lx_p0.clone();
                    let one_p7 = one_p7;
                    let rs_p8 = rs_p8.clone();
                    let nkey_p5 = nkey_p5.clone();
                    let n_p2 = n_p2.clone();
                    let env_p1 = env_p1.clone();
                    let x_p4 = x_p4.clone();
                    Rc::new(move |(p0, p1): ((Array<crate::lower::model::Do>, crate::lower::types::Env), Nat)| {
                        let distinct_p6 = distinct_p6.clone();
                        let lx_p0 = lx_p0.clone();
                        let one_p7 = one_p7;
                        let rs_p8 = rs_p8.clone();
                        let nkey_p5 = nkey_p5.clone();
                        let n_p2 = n_p2.clone();
                        let env_p1 = env_p1.clone();
                        let x_p4 = x_p4.clone();
                        entered(once_job(move || {
                            let (dos_p9, en_pa) = p0;
                            let k_pb = p1;
                            {
                                let (tys_pk, cols_pl) = or(&index(&distinct_p6, &k_pb), &(Array::new(), Array::new()));
                                let lxk_pc = at_instance(&lx_p0, &(tys_pk.clone(), cols_pl.clone()));
                                let rk_pd = if one_p7 { rs_p8.clone() } else { Text::from(format!("{}w{}", &rs_p8, &k_pb)) };
                                let bkey_pe = if &k_pb == &Nat::from(0u32) {
                                    nkey_p5.clone()
                                } else {
                                    Text::from(format!("{}#inst{}", &nkey_p5, &k_pb))
                                };
                                call_then(crate::lower::types::start_out_ty_of(lxk_pc.clone(), crate::lower::types::peel(&crate::lower::binder_ty(&lxk_pc, &n_p2.span))), move |out_ty_of_71488: crate::lower::model::OutTy| {
                                    let bt_pf = out_ty_of_71488;
                                    call_then(start_value_of(lxk_pc.clone(), env_p1.clone(), x_p4.clone()), move |value_of_71547: crate::lower::types::Vl| {
                                        let v_pg = value_of_71547;
                                        let en1_ph = crate::lower::types::bind(&en_pa, &bkey_pe, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(rk_pd.clone()), crate::lower::types::Holding::Owned, bt_pf.clone()));
                                        let en2_pi = {
                                            let mut this: crate::lower::types::Env = en1_ph.clone();
                                            this.uses = insert(&this.uses, &Text::from(format!("{}#{}", &nkey_p5, &show_text(&(tys_pk.clone(), cols_pl.clone())))), &bkey_pe);
                                            this
                                        };
                                        let d_pj = crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(rk_pd.clone()), crate::lower::types::own(&v_pg));
                                        prism_rtl::Turn::Finished((push(&dos_p9, &d_pj), en2_pi.clone()))
                                    })
                                })
                            }
                        }))
                    }) as Rc<dyn Fn(((Array<crate::lower::model::Do>, crate::lower::types::Env), Nat)) -> Rc<dyn prism_rtl::Job<(Array<crate::lower::model::Do>, crate::lower::types::Env)>>>
                }).cycle()
            })
        })
    }
}

/// `Start GenericLet, x`: what the function value is when passed to `@Run`.
pub fn start_generic_let(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, n_p2: crate::syntax::SName, gn_p3: crate::check::typed::GenNote, x_p4: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<(Array<crate::lower::model::Do>, crate::lower::types::Env)>> {
    Rc::new(GenericLet { lx_p0, env_p1, n_p2, gn_p3, x_p4 })
}

/// ```prism
/// Instantiations: unbounded fn Lx, GenNote -> [(([((Text, Ty))], [((Text, Col))]))]
/// ```
pub fn instantiations(lx_p0: &crate::lower::Lx, gn_p1: &crate::check::typed::GenNote) -> Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)> {
    run_to_end(fold_job(or(&get(&lx_p0.insts, &gen_key(gn_p1)), &Array::new()), Array::new(), {
        let lx_p0 = lx_p0.clone();
        Rc::new(move |(p0, p1): (Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)>, crate::check::typed::InstNote)| {
            let lx_p0 = lx_p0.clone();
            entered(once_job(move || {
                let acc_p2 = p0;
                let u_p3 = p1;
                call_then(start_expanded(lx_p0.clone(), inst_at(&lx_p0, &u_p3)), move |expanded_72212: Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)>| prism_rtl::Turn::Finished(fold(&expanded_72212, &acc_p2, &(|a_p4: &Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)>, i_p5: &(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)| if fold(a_p4, &false, &(|seen_p6: &bool, j_p7: &(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)| *seen_p6 || (&show_text(j_p7) == &show_text(i_p5)))) {
                    a_p4.clone()
                } else {
                    push(a_p4, i_p5)
                }))))
            }))
        }) as Rc<dyn Fn((Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)>, crate::check::typed::InstNote)) -> Rc<dyn prism_rtl::Job<Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)>>>>
    }))
}

/// The step machine of `Instantiations`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Instantiations: unbounded fn Lx, GenNote -> [(([((Text, Ty))], [((Text, Col))]))]
/// ```
pub struct Instantiations {
    pub lx_p0: crate::lower::Lx,
    pub gn_p1: crate::check::typed::GenNote,
}

impl prism_rtl::Job<Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)>> for Instantiations {
    fn cycle(&self) -> prism_rtl::Turn<Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)>> {
        let lx_p0 = &self.lx_p0;
        let gn_p1 = &self.gn_p1;
        fold_job(or(&get(&lx_p0.insts, &gen_key(gn_p1)), &Array::new()), Array::new(), {
            let lx_p0 = lx_p0.clone();
            Rc::new(move |(p0, p1): (Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)>, crate::check::typed::InstNote)| {
                let lx_p0 = lx_p0.clone();
                entered(once_job(move || {
                    let acc_p2 = p0;
                    let u_p3 = p1;
                    call_then(start_expanded(lx_p0.clone(), inst_at(&lx_p0, &u_p3)), move |expanded_72212: Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)>| prism_rtl::Turn::Finished(fold(&expanded_72212, &acc_p2, &(|a_p4: &Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)>, i_p5: &(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)| if fold(a_p4, &false, &(|seen_p6: &bool, j_p7: &(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)| *seen_p6 || (&show_text(j_p7) == &show_text(i_p5)))) {
                        a_p4.clone()
                    } else {
                        push(a_p4, i_p5)
                    }))))
                }))
            }) as Rc<dyn Fn((Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)>, crate::check::typed::InstNote)) -> Rc<dyn prism_rtl::Job<Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)>>>>
        }).cycle()
    }
}

/// `Start Instantiations, x`: what the function value is when passed to `@Run`.
pub fn start_instantiations(lx_p0: crate::lower::Lx, gn_p1: crate::check::typed::GenNote) -> Rc<dyn prism_rtl::Job<Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)>>> {
    Rc::new(Instantiations { lx_p0, gn_p1 })
}

/// ```prism
/// Expanded: unbounded fn Lx, (([((Text, Ty))], [((Text, Col))])) -> [(([((Text, Ty))], [((Text, Col))]))]
/// ```
pub fn expanded(lx_p0: &crate::lower::Lx, i_p1: &(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)) -> Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)> {
    match open_q(lx_p0, i_p1) {
        None => Array::from(vec![i_p1.clone()]),
        Some(q_p2) => match get(&lx_p0.gen_of_q, &q_p2) {
            Some(g_p3) => run_to_end(fold_job(instantiations(lx_p0, &g_p3), Array::new(), {
                let lx_p0 = lx_p0.clone();
                let i_p1 = i_p1.clone();
                Rc::new(move |(p0, p1): (Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)>, (Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>))| {
                    let lx_p0 = lx_p0.clone();
                    let i_p1 = i_p1.clone();
                    entered(once_job(move || {
                        let acc_p4 = p0;
                        let gi_p5 = p1;
                        {
                            let lx2_p6 = at_instance(&lx_p0, &gi_p5);
                            call_then(start_expanded(lx2_p6.clone(), subst_inst(&lx2_p6, &i_p1)), move |expanded_72645: Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)>| prism_rtl::Turn::Finished(append(&acc_p4, &expanded_72645)))
                        }
                    }))
                }) as Rc<dyn Fn((Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)>, (Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>))) -> Rc<dyn prism_rtl::Job<Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)>>>>
            })),
            None => Array::from(vec![i_p1.clone()]),
        },
    }
}

/// The step machine of `Expanded`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Expanded: unbounded fn Lx, (([((Text, Ty))], [((Text, Col))])) -> [(([((Text, Ty))], [((Text, Col))]))]
/// ```
pub struct Expanded {
    pub lx_p0: crate::lower::Lx,
    pub i_p1: (Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>),
}

impl prism_rtl::Job<Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)>> for Expanded {
    fn cycle(&self) -> prism_rtl::Turn<Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)>> {
        let lx_p0 = &self.lx_p0;
        let i_p1 = &self.i_p1;
        let i_p1 = i_p1.clone();
        let lx_p0 = lx_p0.clone();
        call_then(start_open_q(lx_p0.clone(), i_p1.clone()), move |open_q_72463: Option<Text>| match open_q_72463 {
            None => prism_rtl::Turn::Finished(Array::from(vec![i_p1.clone()])),
            Some(q_p2) => match get(&lx_p0.gen_of_q, &q_p2) {
                Some(g_p3) => call_then(start_instantiations(lx_p0.clone(), g_p3.clone()), move |instantiations_72540: Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)>| fold_job(instantiations_72540, Array::new(), {
                    let lx_p0 = lx_p0.clone();
                    let i_p1 = i_p1.clone();
                    Rc::new(move |(p0, p1): (Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)>, (Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>))| {
                        let lx_p0 = lx_p0.clone();
                        let i_p1 = i_p1.clone();
                        entered(once_job(move || {
                            let acc_p4 = p0;
                            let gi_p5 = p1;
                            {
                                let lx2_p6 = at_instance(&lx_p0, &gi_p5);
                                call_then(start_expanded(lx2_p6.clone(), subst_inst(&lx2_p6, &i_p1)), move |expanded_72645: Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)>| prism_rtl::Turn::Finished(append(&acc_p4, &expanded_72645)))
                            }
                        }))
                    }) as Rc<dyn Fn((Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)>, (Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>))) -> Rc<dyn prism_rtl::Job<Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)>>>>
                }).cycle()),
                None => prism_rtl::Turn::Finished(Array::from(vec![i_p1.clone()])),
            },
        })
    }
}

/// `Start Expanded, x`: what the function value is when passed to `@Run`.
pub fn start_expanded(lx_p0: crate::lower::Lx, i_p1: (Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)) -> Rc<dyn prism_rtl::Job<Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)>>> {
    Rc::new(Expanded { lx_p0, i_p1 })
}

/// ```prism
/// SubstInst: fn Lx, (([((Text, Ty))], [((Text, Col))])) -> (([((Text, Ty))], [((Text, Col))]))
/// ```
pub fn subst_inst(lx_p0: &crate::lower::Lx, arg1: &(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)) -> (Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>) {
    match arg1 {
        (tys_p1, cols_p2) => {
            let tys2_p3 = each(tys_p1, &(|(q_p5, t_p6): &(Text, crate::check::types::Ty)| (q_p5.clone(), crate::lower::subst_ty(lx_p0, t_p6))));
            let cols2_p4 = each(cols_p2, &(|(q_p7, c_p8): &(Text, crate::check::types::Col)| (q_p7.clone(), crate::lower::inst_col(lx_p0, c_p8))));
            (tys2_p3.clone(), cols2_p4.clone())
        },
    }
}

/// ```prism
/// ?OpenQ: unbounded fn Lx, (([((Text, Ty))], [((Text, Col))])) -> ?Text
/// ```
pub fn open_q(lx_p0: &crate::lower::Lx, arg1: &(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)) -> Option<Text> {
    match arg1 {
        (tys_p1, cols_p2) => {
            let from_cols_p5 = fold(cols_p2, &Array::new(), &(|acc_p3: &Array<Text>, (_, c_p4): &(Text, crate::check::types::Col)| append(acc_p3, &open_cols(lx_p0, c_p4))));
            let all_p8 = run_to_end(fold_job(tys_p1.clone(), from_cols_p5.clone(), {
                let lx_p0 = lx_p0.clone();
                Rc::new(move |(p0, p1): (Array<Text>, (Text, crate::check::types::Ty))| {
                    let lx_p0 = lx_p0.clone();
                    entered(once_job(move || {
                        let acc_p6 = p0;
                        let (_, t_p7) = p1;
                        call_then(start_open_ty_qs(lx_p0.clone(), t_p7.clone()), move |open_ty_qs_73326: Array<Text>| prism_rtl::Turn::Finished(append(&acc_p6, &open_ty_qs_73326)))
                    }))
                }) as Rc<dyn Fn((Array<Text>, (Text, crate::check::types::Ty))) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
            }));
            index(&all_p8, &Nat::from(0u32))
        },
    }
}

/// The step machine of `OpenQ`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?OpenQ: unbounded fn Lx, (([((Text, Ty))], [((Text, Col))])) -> ?Text
/// ```
pub struct OpenQ {
    pub lx_p0: crate::lower::Lx,
    pub arg1: (Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>),
}

impl prism_rtl::Job<Option<Text>> for OpenQ {
    fn cycle(&self) -> prism_rtl::Turn<Option<Text>> {
        let lx_p0 = &self.lx_p0;
        let arg1 = &self.arg1;
        match arg1 {
            (tys_p1, cols_p2) => {
                let from_cols_p5 = fold(cols_p2, &Array::new(), &(|acc_p3: &Array<Text>, (_, c_p4): &(Text, crate::check::types::Col)| append(acc_p3, &open_cols(lx_p0, c_p4))));
                let lx_p0 = lx_p0.clone();
                let tys_p1 = tys_p1.clone();
                call_value(fold_job(tys_p1.clone(), from_cols_p5.clone(), {
                    let lx_p0 = lx_p0.clone();
                    Rc::new(move |(p0, p1): (Array<Text>, (Text, crate::check::types::Ty))| {
                        let lx_p0 = lx_p0.clone();
                        entered(once_job(move || {
                            let acc_p6 = p0;
                            let (_, t_p7) = p1;
                            call_then(start_open_ty_qs(lx_p0.clone(), t_p7.clone()), move |open_ty_qs_73326: Array<Text>| prism_rtl::Turn::Finished(append(&acc_p6, &open_ty_qs_73326)))
                        }))
                    }) as Rc<dyn Fn((Array<Text>, (Text, crate::check::types::Ty))) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
                }), move |fold_73271: Array<Text>| {
                    let all_p8 = fold_73271;
                    prism_rtl::Turn::Finished(index(&all_p8, &Nat::from(0u32)))
                })
            },
        }
    }
}

/// `Start OpenQ, x`: what the function value is when passed to `@Run`.
pub fn start_open_q(lx_p0: crate::lower::Lx, arg1: (Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)) -> Rc<dyn prism_rtl::Job<Option<Text>>> {
    Rc::new(OpenQ { lx_p0, arg1 })
}

/// ```prism
/// OpenCols: fn Lx, Col -> [Text]
/// ```
pub fn open_cols(lx_p0: &crate::lower::Lx, col1: &crate::check::types::Col) -> Array<Text> {
    match col1 {
        crate::check::types::Col::CQ(q_p1) => if crate::check::env::has_key(&lx_p0.gen_of_q, q_p1) && !crate::check::env::has_key(&lx_p0.csubst, q_p1) {
            Array::from(vec![q_p1.clone()])
        } else {
            Array::new()
        },
        c_p3 => Array::new(),
    }
}

/// ```prism
/// OpenTyQs: unbounded fn Lx, Ty -> [Text]
/// ```
pub fn open_ty_qs(lx_p0: &crate::lower::Lx, t_p1: &crate::check::types::Ty) -> Array<Text> {
    match t_p1 {
        crate::check::types::Ty::TyFlex(n_p2) => if crate::check::env::has_key(&lx_p0.gen_of_q, &Text::from(format!("\'{}", n_p2))) && !crate::check::env::has_key(&lx_p0.subst, &Text::from(format!("\'{}", n_p2))) {
            Array::from(vec![Text::from(format!("\'{}", n_p2))])
        } else {
            Array::new()
        },
        crate::check::types::Ty::TyFn(c_p3, ps_p4, res_p5) => run_to_end(fold_job(push(ps_p4, &**res_p5), open_cols(lx_p0, c_p3), {
            let lx_p0 = lx_p0.clone();
            Rc::new(move |(p0, p1): (Array<Text>, crate::check::types::Ty)| {
                let lx_p0 = lx_p0.clone();
                entered(once_job(move || {
                    let acc_p6 = p0;
                    let x_p7 = p1;
                    call_then(start_open_ty_qs(lx_p0.clone(), x_p7.clone()), move |open_ty_qs_73762: Array<Text>| prism_rtl::Turn::Finished(append(&acc_p6, &open_ty_qs_73762)))
                }))
            }) as Rc<dyn Fn((Array<Text>, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
        })),
        crate::check::types::Ty::TyCon(_, args_p8) => run_to_end(fold_job(args_p8.clone(), Array::new(), {
            let lx_p0 = lx_p0.clone();
            Rc::new(move |(p0, p1): (Array<Text>, crate::check::types::Ty)| {
                let lx_p0 = lx_p0.clone();
                entered(once_job(move || {
                    let acc_p9 = p0;
                    let x_pa = p1;
                    call_then(start_open_ty_qs(lx_p0.clone(), x_pa.clone()), move |open_ty_qs_73842: Array<Text>| prism_rtl::Turn::Finished(append(&acc_p9, &open_ty_qs_73842)))
                }))
            }) as Rc<dyn Fn((Array<Text>, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
        })),
        crate::check::types::Ty::TyTuple(ts_pb) => run_to_end(fold_job(ts_pb.clone(), Array::new(), {
            let lx_p0 = lx_p0.clone();
            Rc::new(move |(p0, p1): (Array<Text>, crate::check::types::Ty)| {
                let lx_p0 = lx_p0.clone();
                entered(once_job(move || {
                    let acc_pc = p0;
                    let x_pd = p1;
                    call_then(start_open_ty_qs(lx_p0.clone(), x_pd.clone()), move |open_ty_qs_73912: Array<Text>| prism_rtl::Turn::Finished(append(&acc_pc, &open_ty_qs_73912)))
                }))
            }) as Rc<dyn Fn((Array<Text>, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
        })),
        crate::check::types::Ty::TyArray(e_pe) => open_ty_qs(lx_p0, &**e_pe),
        crate::check::types::Ty::TyMap(k_pf, v_pg) => append(&open_ty_qs(lx_p0, &**k_pf), &open_ty_qs(lx_p0, &**v_pg)),
        crate::check::types::Ty::TySig(_, i_ph) => open_ty_qs(lx_p0, &**i_ph),
        crate::check::types::Ty::TyAt(i_pi, _) => open_ty_qs(lx_p0, &**i_pi),
        crate::check::types::Ty::TyElem(_, o_pj) => open_ty_qs(lx_p0, &**o_pj),
        crate::check::types::Ty::TyAssoc(_, a_pk) => open_ty_qs(lx_p0, &**a_pk),
        _ => Array::new(),
    }
}

/// The step machine of `OpenTyQs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// OpenTyQs: unbounded fn Lx, Ty -> [Text]
/// ```
pub struct OpenTyQs {
    pub lx_p0: crate::lower::Lx,
    pub t_p1: crate::check::types::Ty,
}

impl prism_rtl::Job<Array<Text>> for OpenTyQs {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let lx_p0 = &self.lx_p0;
        let t_p1 = &self.t_p1;
        match t_p1 {
            crate::check::types::Ty::TyFlex(n_p2) => if crate::check::env::has_key(&lx_p0.gen_of_q, &Text::from(format!("\'{}", n_p2))) && !crate::check::env::has_key(&lx_p0.subst, &Text::from(format!("\'{}", n_p2))) {
                prism_rtl::Turn::Finished(Array::from(vec![Text::from(format!("\'{}", n_p2))]))
            } else {
                prism_rtl::Turn::Finished(Array::new())
            },
            crate::check::types::Ty::TyFn(c_p3, ps_p4, res_p5) => fold_job(push(ps_p4, &**res_p5), open_cols(lx_p0, c_p3), {
                let lx_p0 = lx_p0.clone();
                Rc::new(move |(p0, p1): (Array<Text>, crate::check::types::Ty)| {
                    let lx_p0 = lx_p0.clone();
                    entered(once_job(move || {
                        let acc_p6 = p0;
                        let x_p7 = p1;
                        call_then(start_open_ty_qs(lx_p0.clone(), x_p7.clone()), move |open_ty_qs_73762: Array<Text>| prism_rtl::Turn::Finished(append(&acc_p6, &open_ty_qs_73762)))
                    }))
                }) as Rc<dyn Fn((Array<Text>, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
            }).cycle(),
            crate::check::types::Ty::TyCon(_, args_p8) => fold_job(args_p8.clone(), Array::new(), {
                let lx_p0 = lx_p0.clone();
                Rc::new(move |(p0, p1): (Array<Text>, crate::check::types::Ty)| {
                    let lx_p0 = lx_p0.clone();
                    entered(once_job(move || {
                        let acc_p9 = p0;
                        let x_pa = p1;
                        call_then(start_open_ty_qs(lx_p0.clone(), x_pa.clone()), move |open_ty_qs_73842: Array<Text>| prism_rtl::Turn::Finished(append(&acc_p9, &open_ty_qs_73842)))
                    }))
                }) as Rc<dyn Fn((Array<Text>, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
            }).cycle(),
            crate::check::types::Ty::TyTuple(ts_pb) => fold_job(ts_pb.clone(), Array::new(), {
                let lx_p0 = lx_p0.clone();
                Rc::new(move |(p0, p1): (Array<Text>, crate::check::types::Ty)| {
                    let lx_p0 = lx_p0.clone();
                    entered(once_job(move || {
                        let acc_pc = p0;
                        let x_pd = p1;
                        call_then(start_open_ty_qs(lx_p0.clone(), x_pd.clone()), move |open_ty_qs_73912: Array<Text>| prism_rtl::Turn::Finished(append(&acc_pc, &open_ty_qs_73912)))
                    }))
                }) as Rc<dyn Fn((Array<Text>, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
            }).cycle(),
            crate::check::types::Ty::TyArray(e_pe) => prism_rtl::Turn::More(Rc::new(OpenTyQs { lx_p0: lx_p0.clone(), t_p1: (**e_pe).clone() })),
            crate::check::types::Ty::TyMap(k_pf, v_pg) => {
                let k_pf = (**k_pf).clone();
                let lx_p0 = lx_p0.clone();
                let v_pg = (**v_pg).clone();
                call_then(start_open_ty_qs(lx_p0.clone(), k_pf.clone()), move |open_ty_qs_73982: Array<Text>| call_then(start_open_ty_qs(lx_p0.clone(), v_pg.clone()), move |open_ty_qs_74000: Array<Text>| prism_rtl::Turn::Finished(append(&open_ty_qs_73982, &open_ty_qs_74000))))
            },
            crate::check::types::Ty::TySig(_, i_ph) => prism_rtl::Turn::More(Rc::new(OpenTyQs { lx_p0: lx_p0.clone(), t_p1: (**i_ph).clone() })),
            crate::check::types::Ty::TyAt(i_pi, _) => prism_rtl::Turn::More(Rc::new(OpenTyQs { lx_p0: lx_p0.clone(), t_p1: (**i_pi).clone() })),
            crate::check::types::Ty::TyElem(_, o_pj) => prism_rtl::Turn::More(Rc::new(OpenTyQs { lx_p0: lx_p0.clone(), t_p1: (**o_pj).clone() })),
            crate::check::types::Ty::TyAssoc(_, a_pk) => prism_rtl::Turn::More(Rc::new(OpenTyQs { lx_p0: lx_p0.clone(), t_p1: (**a_pk).clone() })),
            _ => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start OpenTyQs, x`: what the function value is when passed to `@Run`.
pub fn start_open_ty_qs(lx_p0: crate::lower::Lx, t_p1: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(OpenTyQs { lx_p0, t_p1 })
}

/// ```prism
/// AtInstance: fn Lx, (([((Text, Ty))], [((Text, Col))])) -> Lx
/// ```
pub fn at_instance(lx_p0: &crate::lower::Lx, arg1: &(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)) -> crate::lower::Lx {
    match arg1 {
        (tys_p1, cols_p2) => {
            let mut this: crate::lower::Lx = lx_p0.clone();
            this.subst = fold(tys_p1, &this.subst, &(|m_p3: &Map<Text, crate::check::types::Ty>, (q_p4, t_p5): &(Text, crate::check::types::Ty)| insert(m_p3, q_p4, t_p5)));
            this.csubst = fold(cols_p2, &this.csubst, &(|m_p6: &Map<Text, crate::check::types::Col>, (q_p7, c_p8): &(Text, crate::check::types::Col)| insert(m_p6, q_p7, c_p8)));
            this
        },
    }
}

/// ```prism
/// WidgetLetLx: unbounded fn Lx, Range -> Lx
/// ```
pub fn widget_let_lx(lx_p0: &crate::lower::Lx, span_p1: &crate::syntax::Range) -> crate::lower::Lx {
    match get(&lx_p0.gens, &crate::lower::place_key(lx_p0, span_p1)) {
        Some(gn_p2) => 'm74821: {
            let scrutinee = &instantiations(lx_p0, &gn_p2);
            if let m74821_0 = scrutinee && (m74821_0.len() == 1) && let Some(i_p3) = index(m74821_0, &Nat::from(0u32)) {
                break 'm74821 at_instance(lx_p0, &i_p3);
            }
            lx_p0.clone()
        },
        None => lx_p0.clone(),
    }
}

/// The step machine of `WidgetLetLx`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// WidgetLetLx: unbounded fn Lx, Range -> Lx
/// ```
pub struct WidgetLetLx {
    pub lx_p0: crate::lower::Lx,
    pub span_p1: crate::syntax::Range,
}

impl prism_rtl::Job<crate::lower::Lx> for WidgetLetLx {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::Lx> {
        let lx_p0 = &self.lx_p0;
        let span_p1 = &self.span_p1;
        match get(&lx_p0.gens, &crate::lower::place_key(lx_p0, span_p1)) {
            Some(gn_p2) => {
                let lx_p0 = lx_p0.clone();
                call_then(start_instantiations(lx_p0.clone(), gn_p2.clone()), move |instantiations_74827: Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)>| 'm74821: {
                    if let m74821_0 = &instantiations_74827 && (m74821_0.len() == 1) && let Some(i_p3) = index(m74821_0, &Nat::from(0u32)) {
                        break 'm74821 prism_rtl::Turn::Finished(at_instance(&lx_p0, &i_p3));
                    }
                    prism_rtl::Turn::Finished(lx_p0.clone())
                })
            },
            None => prism_rtl::Turn::Finished(lx_p0.clone()),
        }
    }
}

/// `Start WidgetLetLx, x`: what the function value is when passed to `@Run`.
pub fn start_widget_let_lx(lx_p0: crate::lower::Lx, span_p1: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<crate::lower::Lx>> {
    Rc::new(WidgetLetLx { lx_p0, span_p1 })
}

/// ```prism
/// InstAt: fn Lx, InstNote -> (([((Text, Ty))], [((Text, Col))]))
/// ```
pub fn inst_at(lx_p0: &crate::lower::Lx, u_p1: &crate::check::typed::InstNote) -> (Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>) {
    let tys_p2 = each(&u_p1.tys, &(|(q_p4, t_p5): &(Text, crate::check::types::Ty)| (q_p4.clone(), crate::lower::subst_ty(lx_p0, t_p5))));
    let cols_p3 = each(&u_p1.cols, &(|(q_p6, c_p7): &(Text, crate::check::types::Col)| (q_p6.clone(), crate::lower::inst_col(lx_p0, c_p7))));
    (tys_p2.clone(), cols_p3.clone())
}

/// ```prism
/// GenKey: fn GenNote -> Text
/// ```
pub fn gen_key(gn_p0: &crate::check::typed::GenNote) -> Text {
    or(&index(&append(&gn_p0.tys, &gn_p0.cols), &Nat::from(0u32)), &Text::lit(""))
}

/// ```prism
/// InstKey: fn InstNote -> Text
/// ```
pub fn inst_key(u_p0: &crate::check::typed::InstNote) -> Text {
    or(&index(&append(&each(&u_p0.tys, &(|(q_p1, _): &(Text, crate::check::types::Ty)| q_p1.clone())), &each(&u_p0.cols, &(|(q_p2, _): &(Text, crate::check::types::Col)| q_p2.clone()))), &Nat::from(0u32)), &Text::lit(""))
}

/// ```prism
/// ColName: fn Col -> Text
/// ```
pub fn col_name(col0: &crate::check::types::Col) -> Text {
    match col0 {
        crate::check::types::Col::CQ(q_p0) => q_p0.clone(),
        c_p1 => Text::lit(""),
    }
}

/// ```prism
/// PlainLet: unbounded fn Lx, Env, Stmt, Pattern, Expr -> (([Do], Env))
/// ```
pub fn plain_let(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, s_p2: &crate::syntax::Stmt, p_p3: &crate::syntax::Pattern_, x_p4: &crate::syntax::Expr) -> (Array<crate::lower::model::Do>, crate::lower::types::Env) {
    let v_p5 = value_of(lx_p0, env_p1, x_p4);
    let po_p6 = crate::lower::patterns::rust_pat(lx_p0, p_p3, &crate::lower::type_at(lx_p0, &x_p4.span), &crate::lower::types::Holding::Owned, &Text::from(format!("l{}", &s_p2.span.start)));
    (Array::from(vec![crate::lower::model::Do::DoLet(po_p6.pa.clone(), crate::lower::types::own(&v_p5))]), bind_all(env_p1, &po_p6.binds))
}

/// The step machine of `PlainLet`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PlainLet: unbounded fn Lx, Env, Stmt, Pattern, Expr -> (([Do], Env))
/// ```
pub struct PlainLet {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub s_p2: crate::syntax::Stmt,
    pub p_p3: crate::syntax::Pattern_,
    pub x_p4: crate::syntax::Expr,
}

impl prism_rtl::Job<(Array<crate::lower::model::Do>, crate::lower::types::Env)> for PlainLet {
    fn cycle(&self) -> prism_rtl::Turn<(Array<crate::lower::model::Do>, crate::lower::types::Env)> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let s_p2 = &self.s_p2;
        let p_p3 = &self.p_p3;
        let x_p4 = &self.x_p4;
        let env_p1 = env_p1.clone();
        let lx_p0 = lx_p0.clone();
        let p_p3 = p_p3.clone();
        let s_p2 = s_p2.clone();
        let x_p4 = x_p4.clone();
        call_then(start_value_of(lx_p0.clone(), env_p1.clone(), x_p4.clone()), move |value_of_75612: crate::lower::types::Vl| {
            let v_p5 = value_of_75612;
            call_then(crate::lower::patterns::start_rust_pat(lx_p0.clone(), p_p3.clone(), crate::lower::type_at(&lx_p0, &x_p4.span), crate::lower::types::Holding::Owned, Text::from(format!("l{}", &s_p2.span.start))), move |rust_pat_75648: crate::lower::patterns::PatOut| {
                let po_p6 = rust_pat_75648;
                prism_rtl::Turn::Finished((Array::from(vec![crate::lower::model::Do::DoLet(po_p6.pa.clone(), crate::lower::types::own(&v_p5))]), bind_all(&env_p1, &po_p6.binds)))
            })
        })
    }
}

/// `Start PlainLet, x`: what the function value is when passed to `@Run`.
pub fn start_plain_let(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, s_p2: crate::syntax::Stmt, p_p3: crate::syntax::Pattern_, x_p4: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<(Array<crate::lower::model::Do>, crate::lower::types::Env)>> {
    Rc::new(PlainLet { lx_p0, env_p1, s_p2, p_p3, x_p4 })
}
