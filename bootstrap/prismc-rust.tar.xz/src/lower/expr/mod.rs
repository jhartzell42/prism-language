//! The module `Lower.Expr`, from `target/bootstrap/src/prismc/lower/expr.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// ```prism
/// Escape: fn Text -> Text
/// ```
pub fn escape(t: &Text) -> Text {
    crate::syntax::lexer::chars::map_chars(t, &(Rc::new(move |p0: Text| once_job(move || {
        let c = p0;
        prism_rtl::Turn::Finished(char_escape(&c))
    })) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<Text>>>))
}

/// ```prism
/// CharEscape: fn Text -> Text
/// ```
pub fn char_escape(text0: &Text) -> Text {
    match text0 {
        c0_0 if (c0_0 == &Text::lit("\\")) => Text::lit("\\\\"),
        c1_0 if (c1_0 == &Text::lit("\"")) => Text::lit("\\\""),
        c2_0 if (c2_0 == &Text::lit("\n")) => Text::lit("\\n"),
        c3_0 if (c3_0 == &Text::lit("\t")) => Text::lit("\\t"),
        c4_0 if (c4_0 == &Text::lit("\r")) => Text::lit("\\r"),
        c5_0 if (c5_0 == &Text::lit("\0")) => Text::lit("\\0"),
        c6_0 if (c6_0 == &Text::lit("\'")) => Text::lit("\\\'"),
        c => c.clone(),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// Number: fn OutTy, Text, Bool -> Ex
/// ```
pub fn number(t: &crate::lower::model::OutTy, digits: &Text, neg: &bool) -> crate::lower::model::Ex {
    let clean = decimal_digits(&concat(&split_on(digits, &Text::lit("_"))));
    let signed = if *neg { Text::from(format!("-{}", &clean)) } else { clean.clone() };
    match t {
        crate::lower::model::OutTy::OutNat => crate::lower::model::Ex::XNat(clean.clone()),
        crate::lower::model::OutTy::OutInt => crate::lower::model::Ex::XInt(signed.clone()),
        crate::lower::model::OutTy::OutU8 => crate::lower::model::Ex::XByte(clean.clone()),
        crate::lower::model::OutTy::OutFloat => crate::lower::model::Ex::XFloat(if crate::syntax::lexer::chars::contains(&clean, &Text::lit(".")) {
            signed.clone()
        } else {
            Text::from(format!("{}.0", &signed))
        }),
        _ => crate::lower::model::Ex::XInt(signed.clone()),
    }
}

/// ```prism
/// DecimalDigits: fn Text -> Text
/// ```
pub fn decimal_digits(d: &Text) -> Text {
    let r = if &crate::syntax::lexer::chars::head(d) == &Text::lit("0") {
        crate::syntax::lexer::chars::head(&crate::syntax::lexer::chars::after_first(d))
    } else {
        Text::lit("")
    };
    let base = if &r == &Text::lit("x") {
        Nat::from(16u32)
    } else {
        if &r == &Text::lit("o") {
            Nat::from(8u32)
        } else {
            if &r == &Text::lit("b") { Nat::from(2u32) } else { Nat::from(10u32) }
        }
    };
    let ds = if &base == &Nat::from(10u32) {
        d.clone()
    } else {
        crate::syntax::lexer::chars::after_first(&crate::syntax::lexer::chars::after_first(d))
    };
    if (crate::syntax::lexer::chars::contains(d, &Text::lit(".")) || (&crate::syntax::lexer::chars::head(d) != &Text::lit("0"))) || (d == &Text::lit("0")) {
        d.clone()
    } else {
        Text::from(format!("{}", &crate::syntax::lexer::chars::fold_chars(&ds, &Nat::from(0u32), &{
            let base = base.clone();
            Rc::new(move |(p0, p1): (Nat, Text)| {
                let base = base.clone();
                once_job(move || {
                    let n = p0;
                    let c = p1;
                    prism_rtl::Turn::Finished(&(&n * &base) + &crate::syntax::lexer::chars::hex_value(&c))
                })
            }) as Rc<dyn Fn((Nat, Text)) -> Rc<dyn prism_rtl::Job<Nat>>>
        })))
    }
}

/// ```prism
/// LiteralValue: unbounded fn Lx, Env, Literal, Range, Bool -> Vl
/// ```
pub fn literal_value(lx: &crate::lower::Lx, env: &crate::lower::types::Env, l: &crate::syntax::Literal, span: &crate::syntax::Range, neg: &bool) -> crate::lower::types::Vl {
    let t = crate::lower::types::out_ty_of(lx, &crate::lower::types::peel(&crate::lower::type_at(lx, span)));
    match &l.kind {
        crate::syntax::LitKind::LInt(d) => crate::lower::types::Vl::VlOwned(number(&t, d, neg), t.clone()),
        crate::syntax::LitKind::LFloat(d) => crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XFloat(if *neg { Text::from(format!("-{}", d)) } else { d.clone() }), crate::lower::model::OutTy::OutFloat),
        crate::syntax::LitKind::LChar(c) => crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XChar(c.clone()), crate::lower::model::OutTy::OutChar),
        crate::syntax::LitKind::LDuration(d, u) => crate::lower::types::Vl::VlOwned(refusal(&Text::lit("a Duration literal")), crate::lower::model::OutTy::OutDuration),
        crate::syntax::LitKind::LText(segs) => text_value(lx, env, segs),
        crate::syntax::LitKind::LRegex(r) => match &r.replacement {
            None => crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XRegex(r.pattern.clone(), r.flags.clone()), crate::lower::model::OutTy::OutRegex),
            Some(t) => crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XReplacement(r.pattern.clone(), t.clone(), r.flags.clone()), crate::lower::model::OutTy::OutReplacement),
        },
    }
}

/// The step machine of `LiteralValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LiteralValue: unbounded fn Lx, Env, Literal, Range, Bool -> Vl
/// ```
pub struct LiteralValue {
    pub lx: crate::lower::Lx,
    pub env: crate::lower::types::Env,
    pub l: crate::syntax::Literal,
    pub span: crate::syntax::Range,
    pub neg: bool,
}

impl prism_rtl::Job<crate::lower::types::Vl> for LiteralValue {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::types::Vl> {
        let lx = &self.lx;
        let env = &self.env;
        let l = &self.l;
        let span = &self.span;
        let neg = &self.neg;
        let env = env.clone();
        let l = l.clone();
        let lx = lx.clone();
        let neg = *neg;
        let span = span.clone();
        call_then(crate::lower::types::start_out_ty_of(lx.clone(), crate::lower::types::peel(&crate::lower::type_at(&lx, &span))), move |out_ty_of_2743: crate::lower::model::OutTy| {
            let t = out_ty_of_2743;
            match &l.kind {
                crate::syntax::LitKind::LInt(d) => prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(number(&t, d, &neg), t.clone())),
                crate::syntax::LitKind::LFloat(d) => prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XFloat(if neg { Text::from(format!("-{}", d)) } else { d.clone() }), crate::lower::model::OutTy::OutFloat)),
                crate::syntax::LitKind::LChar(c) => prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XChar(c.clone()), crate::lower::model::OutTy::OutChar)),
                crate::syntax::LitKind::LDuration(d, u) => prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(refusal(&Text::lit("a Duration literal")), crate::lower::model::OutTy::OutDuration)),
                crate::syntax::LitKind::LText(segs) => prism_rtl::Turn::More(Rc::new(TextValue { lx: lx.clone(), env: env.clone(), segs: segs.clone() })),
                crate::syntax::LitKind::LRegex(r) => match &r.replacement {
                    None => prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XRegex(r.pattern.clone(), r.flags.clone()), crate::lower::model::OutTy::OutRegex)),
                    Some(t) => prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XReplacement(r.pattern.clone(), t.clone(), r.flags.clone()), crate::lower::model::OutTy::OutReplacement)),
                },
            }
        })
    }
}

/// `Start LiteralValue, x`: what the function value is when passed to `@Run`.
pub fn start_literal_value(lx: crate::lower::Lx, env: crate::lower::types::Env, l: crate::syntax::Literal, span: crate::syntax::Range, neg: bool) -> Rc<dyn prism_rtl::Job<crate::lower::types::Vl>> {
    Rc::new(LiteralValue { lx, env, l, span, neg })
}

/// ```prism
/// TextValue: unbounded fn Lx, Env, [TextSeg] -> Vl
/// ```
pub fn text_value(lx: &crate::lower::Lx, env: &crate::lower::types::Env, segs: &Array<crate::syntax::TextSeg>) -> crate::lower::types::Vl {
    let plain = fold(segs, &true, &(|ok_: &bool, s: &crate::syntax::TextSeg| *ok_ && is_plain_seg(s)));
    if plain {
        crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XText(concat(&each(segs, &(|s: &crate::syntax::TextSeg| plain_text(s))))), crate::lower::model::OutTy::OutText)
    } else {
        crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XFormat(run_to_end(each_job(segs.clone(), {
            let lx = lx.clone();
            let env = env.clone();
            Rc::new(move |p0: crate::syntax::TextSeg| {
                let lx = lx.clone();
                let env = env.clone();
                entered(once_job(move || {
                    let s = p0;
                    prism_rtl::Turn::More(Rc::new(SegEx { lx: lx.clone(), env: env.clone(), text_seg2: s.clone() }))
                }))
            }) as Rc<dyn Fn(crate::syntax::TextSeg) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
        }))), crate::lower::model::OutTy::OutText)
    }
}

/// The step machine of `TextValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TextValue: unbounded fn Lx, Env, [TextSeg] -> Vl
/// ```
pub struct TextValue {
    pub lx: crate::lower::Lx,
    pub env: crate::lower::types::Env,
    pub segs: Array<crate::syntax::TextSeg>,
}

impl prism_rtl::Job<crate::lower::types::Vl> for TextValue {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::types::Vl> {
        let lx = &self.lx;
        let env = &self.env;
        let segs = &self.segs;
        let plain = fold(segs, &true, &(|ok_: &bool, s: &crate::syntax::TextSeg| *ok_ && is_plain_seg(s)));
        if plain {
            prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XText(concat(&each(segs, &(|s: &crate::syntax::TextSeg| plain_text(s))))), crate::lower::model::OutTy::OutText))
        } else {
            {
                let env = env.clone();
                let lx = lx.clone();
                let segs = segs.clone();
                call_value(each_job(segs.clone(), {
                    let lx = lx.clone();
                    let env = env.clone();
                    Rc::new(move |p0: crate::syntax::TextSeg| {
                        let lx = lx.clone();
                        let env = env.clone();
                        entered(once_job(move || {
                            let s = p0;
                            prism_rtl::Turn::More(Rc::new(SegEx { lx: lx.clone(), env: env.clone(), text_seg2: s.clone() }))
                        }))
                    }) as Rc<dyn Fn(crate::syntax::TextSeg) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
                }), move |each_3640: Array<crate::lower::model::Ex>| prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XFormat(each_3640), crate::lower::model::OutTy::OutText)))
            }
        }
    }
}

/// `Start TextValue, x`: what the function value is when passed to `@Run`.
pub fn start_text_value(lx: crate::lower::Lx, env: crate::lower::types::Env, segs: Array<crate::syntax::TextSeg>) -> Rc<dyn prism_rtl::Job<crate::lower::types::Vl>> {
    Rc::new(TextValue { lx, env, segs })
}

/// ```prism
/// IsPlainSeg: fn TextSeg -> Bool
/// ```
pub fn is_plain_seg(text_seg0: &crate::syntax::TextSeg) -> bool {
    match text_seg0 {
        crate::syntax::TextSeg::SegPlain(_) => true,
        crate::syntax::TextSeg::SegPlaceholder(_) => false,
    }
}

/// ```prism
/// PlainText: fn TextSeg -> Text
/// ```
pub fn plain_text(text_seg0: &crate::syntax::TextSeg) -> Text {
    match text_seg0 {
        crate::syntax::TextSeg::SegPlain(t) => t.clone(),
        crate::syntax::TextSeg::SegPlaceholder(_) => Text::lit(""),
    }
}

/// ```prism
/// SegEx: unbounded fn Lx, Env, TextSeg -> Ex
/// ```
pub fn seg_ex(lx: &crate::lower::Lx, env: &crate::lower::types::Env, text_seg2: &crate::syntax::TextSeg) -> crate::lower::model::Ex {
    match text_seg2 {
        crate::syntax::TextSeg::SegPlain(t) => crate::lower::model::Ex::XText(t.clone()),
        crate::syntax::TextSeg::SegPlaceholder(e) => {
            let v_ = value_of(lx, env, e);
            shown_part(&v_)
        },
    }
}

/// The step machine of `SegEx`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SegEx: unbounded fn Lx, Env, TextSeg -> Ex
/// ```
pub struct SegEx {
    pub lx: crate::lower::Lx,
    pub env: crate::lower::types::Env,
    pub text_seg2: crate::syntax::TextSeg,
}

impl prism_rtl::Job<crate::lower::model::Ex> for SegEx {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::Ex> {
        let lx = &self.lx;
        let env = &self.env;
        let text_seg2 = &self.text_seg2;
        match text_seg2 {
            crate::syntax::TextSeg::SegPlain(t) => prism_rtl::Turn::Finished(crate::lower::model::Ex::XText(t.clone())),
            crate::syntax::TextSeg::SegPlaceholder(e) => {
                let e = e.clone();
                let env = env.clone();
                let lx = lx.clone();
                call_then(start_value_of(lx.clone(), env.clone(), e.clone()), move |value_of_4039: crate::lower::types::Vl| {
                    let v_ = value_of_4039;
                    prism_rtl::Turn::Finished(shown_part(&v_))
                })
            },
        }
    }
}

/// `Start SegEx, x`: what the function value is when passed to `@Run`.
pub fn start_seg_ex(lx: crate::lower::Lx, env: crate::lower::types::Env, text_seg2: crate::syntax::TextSeg) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>> {
    Rc::new(SegEx { lx, env, text_seg2 })
}

/// ```prism
/// ShownPart: fn Vl -> Ex
/// ```
pub fn shown_part(v_: &crate::lower::types::Vl) -> crate::lower::model::Ex {
    match crate::lower::types::value_ty(v_) {
        crate::lower::model::OutTy::OutText => crate::lower::types::ref_(v_),
        crate::lower::model::OutTy::OutNat => crate::lower::types::ref_(v_),
        crate::lower::model::OutTy::OutInt => crate::lower::types::ref_(v_),
        crate::lower::model::OutTy::OutU8 => crate::lower::types::ref_(v_),
        _ => crate::lower::model::Ex::XCall(Text::lit("show"), Array::from(vec![crate::lower::types::ref_(v_)])),
    }
}

/// ```prism
/// Refusal: fn Text -> Ex
/// ```
pub fn refusal(what: &Text) -> crate::lower::model::Ex {
    crate::lower::model::Ex::XRefusal(what.clone())
}

/// ```prism
/// TryOf: fn Ex -> Ex
/// ```
pub fn try_of(x: &crate::lower::model::Ex) -> crate::lower::model::Ex {
    if is_named_place(x) {
        refusal(&Text::from(format!("`?` of the place `{}`, which C++\'s TRY would move out of (only a temporary may be tried)", &crate::lower::types::place_stem(x))))
    } else {
        crate::lower::model::Ex::XTry(Rc::new(x.clone()))
    }
}

/// ```prism
/// IsNamedPlace: fn Ex -> Bool
/// ```
pub fn is_named_place(x: &crate::lower::model::Ex) -> bool {
    match x {
        crate::lower::model::Ex::XVar(_) => true,
        crate::lower::model::Ex::XField(_, _) => true,
        crate::lower::model::Ex::XPart(_, _) => true,
        crate::lower::model::Ex::XTarget(_) => true,
        crate::lower::model::Ex::XRef(y) => is_named_place(&**y),
        crate::lower::model::Ex::XDeref(y) => is_named_place(&**y),
        _ => false,
    }
}

/// ```prism
/// let loweringRefusal
/// ```
pub fn lowering_refusal() -> Text {
    Text::lit("prismc does not lower ")
}

/// ```prism
/// RefusalDo: fn Text -> Do
/// ```
pub fn refusal_do(what: &Text) -> crate::lower::model::Do {
    crate::lower::model::Do::DoExpr(refusal(what))
}

/// ```prism
/// ValueOf: unbounded fn Lx, Env, Expr -> Vl
/// ```
pub fn value_of(lx: &crate::lower::Lx, env: &crate::lower::types::Env, e: &crate::syntax::Expr) -> crate::lower::types::Vl {
    match get(&env.spans, &crate::lower::place_key(lx, &e.span)) {
        Some(v_) => v_,
        None => unbound_value_of(lx, env, e),
    }
}

/// The step machine of `ValueOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ValueOf: unbounded fn Lx, Env, Expr -> Vl
/// ```
pub struct ValueOf {
    pub lx: crate::lower::Lx,
    pub env: crate::lower::types::Env,
    pub e: crate::syntax::Expr,
}

impl prism_rtl::Job<crate::lower::types::Vl> for ValueOf {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::types::Vl> {
        let lx = &self.lx;
        let env = &self.env;
        let e = &self.e;
        match get(&env.spans, &crate::lower::place_key(lx, &e.span)) {
            Some(v_) => prism_rtl::Turn::Finished(v_.clone()),
            None => prism_rtl::Turn::More(Rc::new(UnboundValueOf { lx: lx.clone(), env: env.clone(), e: e.clone() })),
        }
    }
}

/// `Start ValueOf, x`: what the function value is when passed to `@Run`.
pub fn start_value_of(lx: crate::lower::Lx, env: crate::lower::types::Env, e: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<crate::lower::types::Vl>> {
    Rc::new(ValueOf { lx, env, e })
}

/// ```prism
/// UnboundValueOf: unbounded fn Lx, Env, Expr -> Vl
/// ```
pub fn unbound_value_of(lx: &crate::lower::Lx, env: &crate::lower::types::Env, e: &crate::syntax::Expr) -> crate::lower::types::Vl {
    if is_event_value(lx, env, e) {
        event_value_of(lx, env, e)
    } else {
        value_by_kind(lx, env, e)
    }
}

/// The step machine of `UnboundValueOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UnboundValueOf: unbounded fn Lx, Env, Expr -> Vl
/// ```
pub struct UnboundValueOf {
    pub lx: crate::lower::Lx,
    pub env: crate::lower::types::Env,
    pub e: crate::syntax::Expr,
}

impl prism_rtl::Job<crate::lower::types::Vl> for UnboundValueOf {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::types::Vl> {
        let lx = &self.lx;
        let env = &self.env;
        let e = &self.e;
        let e = e.clone();
        let env = env.clone();
        let lx = lx.clone();
        call_then(start_is_event_value(lx.clone(), env.clone(), e.clone()), move |is_event_value_6014: bool| if is_event_value_6014 {
            prism_rtl::Turn::More(Rc::new(EventValueOf { lx: lx.clone(), env: env.clone(), e: e.clone() }))
        } else {
            prism_rtl::Turn::More(Rc::new(ValueByKind { lx: lx.clone(), env: env.clone(), e: e.clone() }))
        })
    }
}

/// `Start UnboundValueOf, x`: what the function value is when passed to `@Run`.
pub fn start_unbound_value_of(lx: crate::lower::Lx, env: crate::lower::types::Env, e: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<crate::lower::types::Vl>> {
    Rc::new(UnboundValueOf { lx, env, e })
}

/// ```prism
/// IsEventValue: unbounded fn Lx, Env, Expr -> Bool
/// ```
pub fn is_event_value(lx: &crate::lower::Lx, env: &crate::lower::types::Env, e: &crate::syntax::Expr) -> bool {
    match &*e.kind {
        crate::syntax::ExprKind::EName(_) => false,
        crate::syntax::ExprKind::EGroup(_) => false,
        _ => ((&crate::lower::types::layer_of(&crate::lower::type_at(lx, &e.span)) == &crate::lower::types::Layer::LyEv) && !fold(&crate::lower::node_::dynamics::operands(e), &false, &(|bound: &bool, c: &crate::syntax::Expr| *bound || crate::check::env::has_key(&env.spans, &crate::lower::place_key(lx, &c.span))))) && has_event_source(lx, env, e),
    }
}

/// The step machine of `IsEventValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// IsEventValue: unbounded fn Lx, Env, Expr -> Bool
/// ```
pub struct IsEventValue {
    pub lx: crate::lower::Lx,
    pub env: crate::lower::types::Env,
    pub e: crate::syntax::Expr,
}

impl prism_rtl::Job<bool> for IsEventValue {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let lx = &self.lx;
        let env = &self.env;
        let e = &self.e;
        match &*e.kind {
            crate::syntax::ExprKind::EName(_) => prism_rtl::Turn::Finished(false),
            crate::syntax::ExprKind::EGroup(_) => prism_rtl::Turn::Finished(false),
            _ => prism_rtl::Turn::Finished(((&crate::lower::types::layer_of(&crate::lower::type_at(lx, &e.span)) == &crate::lower::types::Layer::LyEv) && !fold(&crate::lower::node_::dynamics::operands(e), &false, &(|bound: &bool, c: &crate::syntax::Expr| *bound || crate::check::env::has_key(&env.spans, &crate::lower::place_key(lx, &c.span))))) && has_event_source(lx, env, e)),
        }
    }
}

/// `Start IsEventValue, x`: what the function value is when passed to `@Run`.
pub fn start_is_event_value(lx: crate::lower::Lx, env: crate::lower::types::Env, e: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(IsEventValue { lx, env, e })
}

/// ```prism
/// HasEventSource: unbounded fn Lx, Env, Expr -> Bool
/// ```
pub fn has_event_source(lx: &crate::lower::Lx, env: &crate::lower::types::Env, e: &crate::syntax::Expr) -> bool {
    run_to_end(fold_job(crate::lower::node_::dynamics::operands(e), false, {
        let lx = lx.clone();
        let env = env.clone();
        Rc::new(move |(p0, p1): (bool, crate::syntax::Expr)| {
            let lx = lx.clone();
            let env = env.clone();
            entered(once_job(move || {
                let found = p0;
                let c = p1;
                prism_rtl::Turn::Finished(found || is_event_source(&lx, &env, &c))
            }))
        }) as Rc<dyn Fn((bool, crate::syntax::Expr)) -> Rc<dyn prism_rtl::Job<bool>>>
    }))
}

/// The step machine of `HasEventSource`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// HasEventSource: unbounded fn Lx, Env, Expr -> Bool
/// ```
pub struct HasEventSource {
    pub lx: crate::lower::Lx,
    pub env: crate::lower::types::Env,
    pub e: crate::syntax::Expr,
}

impl prism_rtl::Job<bool> for HasEventSource {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let lx = &self.lx;
        let env = &self.env;
        let e = &self.e;
        fold_job(crate::lower::node_::dynamics::operands(e), false, {
            let lx = lx.clone();
            let env = env.clone();
            Rc::new(move |(p0, p1): (bool, crate::syntax::Expr)| {
                let lx = lx.clone();
                let env = env.clone();
                entered(once_job(move || {
                    let found = p0;
                    let c = p1;
                    prism_rtl::Turn::Finished(found || is_event_source(&lx, &env, &c))
                }))
            }) as Rc<dyn Fn((bool, crate::syntax::Expr)) -> Rc<dyn prism_rtl::Job<bool>>>
        }).cycle()
    }
}

/// `Start HasEventSource, x`: what the function value is when passed to `@Run`.
pub fn start_has_event_source(lx: crate::lower::Lx, env: crate::lower::types::Env, e: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(HasEventSource { lx, env, e })
}

/// ```prism
/// IsEventSource: unbounded fn Lx, Env, Expr -> Bool
/// ```
pub fn is_event_source(lx: &crate::lower::Lx, env: &crate::lower::types::Env, c: &crate::syntax::Expr) -> bool {
    if &crate::lower::types::layer_of(&crate::lower::type_at(lx, &c.span)) != &crate::lower::types::Layer::LyEv {
        false
    } else {
        match &*c.kind {
            crate::syntax::ExprKind::EName(n) => match get(&env.names, &crate::check::env::sname_key(n)) {
                Some(crate::lower::types::Bn::BnLocal(_, _, crate::lower::model::OutTy::OutEvent(_))) => true,
                Some(crate::lower::types::Bn::BnEv(_, _)) => crate::check::env::has_key(&env.names, &Text::from(format!("{}#port", &crate::check::env::sname_key(n)))),
                _ => false,
            },
            crate::syntax::ExprKind::EGroup(x) => is_event_source(lx, env, &**x),
            _ => has_event_source(lx, env, c),
        }
    }
}

/// The step machine of `IsEventSource`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// IsEventSource: unbounded fn Lx, Env, Expr -> Bool
/// ```
pub struct IsEventSource {
    pub lx: crate::lower::Lx,
    pub env: crate::lower::types::Env,
    pub c: crate::syntax::Expr,
}

impl prism_rtl::Job<bool> for IsEventSource {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let lx = &self.lx;
        let env = &self.env;
        let c = &self.c;
        if &crate::lower::types::layer_of(&crate::lower::type_at(lx, &c.span)) != &crate::lower::types::Layer::LyEv {
            prism_rtl::Turn::Finished(false)
        } else {
            match &*c.kind {
                crate::syntax::ExprKind::EName(n) => match get(&env.names, &crate::check::env::sname_key(n)) {
                    Some(crate::lower::types::Bn::BnLocal(_, _, crate::lower::model::OutTy::OutEvent(_))) => prism_rtl::Turn::Finished(true),
                    Some(crate::lower::types::Bn::BnEv(_, _)) => prism_rtl::Turn::Finished(crate::check::env::has_key(&env.names, &Text::from(format!("{}#port", &crate::check::env::sname_key(n))))),
                    _ => prism_rtl::Turn::Finished(false),
                },
                crate::syntax::ExprKind::EGroup(x) => prism_rtl::Turn::More(Rc::new(IsEventSource { lx: lx.clone(), env: env.clone(), c: (**x).clone() })),
                _ => prism_rtl::Turn::More(Rc::new(HasEventSource { lx: lx.clone(), env: env.clone(), e: c.clone() })),
            }
        }
    }
}

/// `Start IsEventSource, x`: what the function value is when passed to `@Run`.
pub fn start_is_event_source(lx: crate::lower::Lx, env: crate::lower::types::Env, c: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(IsEventSource { lx, env, c })
}

/// ```prism
/// EventValueOf: unbounded fn Lx, Env, Expr -> Vl
/// ```
pub fn event_value_of(lx: &crate::lower::Lx, env: &crate::lower::types::Env, e: &crate::syntax::Expr) -> crate::lower::types::Vl {
    let t = crate::lower::types::out_ty_of(lx, &crate::lower::types::peel(&crate::lower::type_at(lx, &e.span)));
    let et = crate::lower::model::OutTy::OutEvent(Rc::new(t.clone()));
    let filtered_opt = match &*e.kind {
        crate::syntax::ExprKind::ECall(c, args, _, _) => if &crate::lower::node_::dynamics::callee_key(lx, &**c) == &Text::lit("Prelude.!Filter") {
            index(args, &Nat::from(0u32))
        } else {
            None
        },
        _ => None,
    };
    match &filtered_opt {
        Some(a) => crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::types::own(&value_of(lx, env, &a.value))), Text::lit("filter_some"), Array::new()), et.clone()),
        None => {
            let evs = filter(&crate::lower::node_::dynamics::operands(e), &(|x: &crate::syntax::Expr| &crate::lower::types::layer_of(&crate::lower::type_at(lx, &x.span)) == &crate::lower::types::Layer::LyEv));
            'm8081: {
                if let m8081_0 = &evs && (m8081_0.len() == 1) && let Some(one) = index(m8081_0, &Nat::from(0u32)) {
                    break 'm8081 {
                        let src = crate::lower::types::own(&value_of(lx, env, &one));
                        let it = crate::lower::types::out_ty_of(lx, &crate::lower::types::peel(&crate::lower::type_at(lx, &one.span)));
                        let caps = filter(&crate::lower::types::with_instances(env, &read_names(&crate::check::typed::print::exprs_in(e))), &(|n: &Text| match get(&env.names, n) {
                            Some(crate::lower::types::Bn::BnLocal(_, _, _)) => true,
                            _ => false,
                        }));
                        let (dos, env1) = fold(&caps, &(Array::new(), env.clone()), &(|(acc, en): &(Array<crate::lower::model::Do>, crate::lower::types::Env), n: &Text| match get(&env.names, n) {
                            Some(crate::lower::types::Bn::BnLocal(rs, mode, ct)) => {
                                let local = Text::from(format!("{}_c", &crate::lower::types::place_stem(&rs)));
                                (push(acc, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(local.clone()), crate::lower::types::own(&crate::lower::types::local_place(&rs, &mode, &ct)))), crate::lower::types::bind(en, n, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(local.clone()), crate::lower::types::Holding::Owned, ct.clone())))
                            },
                            _ => (acc.clone(), en.clone()),
                        }));
                        let env2 = crate::lower::types::bind_span(&env1, &crate::lower::place_key(lx, &one.span), &crate::lower::types::Vl::VlPlace(crate::lower::model::Ex::XVar(Text::lit("y_ev")), crate::lower::types::Holding::ByRef, it.clone()));
                        let body = crate::lower::types::own(&value_by_kind(lx, &env2, e));
                        let mapped = crate::lower::model::Ex::XMethod(Rc::new(src.clone()), Text::lit("map"), Array::from(vec![crate::lower::model::Ex::XClosure(true, Array::from(vec![crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaBind(Text::lit("y_ev"))), crate::lower::model::OutTy::OutRef(Rc::new(it.clone())))]), Rc::new(body.clone()))]));
                        crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XBlock(push(&dos, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(Text::lit("src_ev")), src.clone())), Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("src_ev"))), Text::lit("map"), Array::from(vec![crate::lower::model::Ex::XClosure(true, Array::from(vec![crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaBind(Text::lit("y_ev"))), crate::lower::model::OutTy::OutRef(Rc::new(it.clone())))]), Rc::new(body.clone()))])))), et.clone())
                    };
                }
                crate::lower::types::Vl::VlOwned(refusal(&Text::lit("an event value of several events")), et.clone())
            }
        },
    }
}

/// The step machine of `EventValueOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// EventValueOf: unbounded fn Lx, Env, Expr -> Vl
/// ```
pub struct EventValueOf {
    pub lx: crate::lower::Lx,
    pub env: crate::lower::types::Env,
    pub e: crate::syntax::Expr,
}

impl prism_rtl::Job<crate::lower::types::Vl> for EventValueOf {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::types::Vl> {
        let lx = &self.lx;
        let env = &self.env;
        let e = &self.e;
        let e = e.clone();
        let env = env.clone();
        let lx = lx.clone();
        call_then(crate::lower::types::start_out_ty_of(lx.clone(), crate::lower::types::peel(&crate::lower::type_at(&lx, &e.span))), move |out_ty_of_7640: crate::lower::model::OutTy| {
            let t = out_ty_of_7640;
            let et = crate::lower::model::OutTy::OutEvent(Rc::new(t.clone()));
            let filtered_opt = match &*e.kind {
                crate::syntax::ExprKind::ECall(c, args, _, _) => if &crate::lower::node_::dynamics::callee_key(&lx, &**c) == &Text::lit("Prelude.!Filter") {
                    index(args, &Nat::from(0u32))
                } else {
                    None
                },
                _ => None,
            };
            match &filtered_opt {
                Some(a) => {
                    let a = a.clone();
                    call_then(start_value_of(lx.clone(), env.clone(), a.value.clone()), move |value_of_7917: crate::lower::types::Vl| prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::types::own(&value_of_7917)), Text::lit("filter_some"), Array::new()), et.clone())))
                },
                None => {
                    let evs = filter(&crate::lower::node_::dynamics::operands(&e), &(|x: &crate::syntax::Expr| &crate::lower::types::layer_of(&crate::lower::type_at(&lx, &x.span)) == &crate::lower::types::Layer::LyEv));
                    'm8081: {
                        if let m8081_0 = &evs && (m8081_0.len() == 1) && let Some(one) = index(m8081_0, &Nat::from(0u32)) {
                            break 'm8081 call_then(start_value_of(lx.clone(), env.clone(), one.clone()), move |value_of_8152: crate::lower::types::Vl| {
                                let src = crate::lower::types::own(&value_of_8152);
                                call_then(crate::lower::types::start_out_ty_of(lx.clone(), crate::lower::types::peel(&crate::lower::type_at(&lx, &one.span))), move |out_ty_of_8203: crate::lower::model::OutTy| {
                                    let it = out_ty_of_8203;
                                    call_then(crate::check::typed::print::start_exprs_in(e.clone()), move |exprs_in_8314: Array<crate::syntax::Expr>| call_then(start_read_names(exprs_in_8314), move |read_names_8303: Array<Text>| {
                                        let caps = filter(&crate::lower::types::with_instances(&env, &read_names_8303), &(|n: &Text| match get(&env.names, n) {
                                            Some(crate::lower::types::Bn::BnLocal(_, _, _)) => true,
                                            _ => false,
                                        }));
                                        let (dos, env1) = fold(&caps, &(Array::new(), env.clone()), &(|(acc, en): &(Array<crate::lower::model::Do>, crate::lower::types::Env), n: &Text| match get(&env.names, n) {
                                            Some(crate::lower::types::Bn::BnLocal(rs, mode, ct)) => {
                                                let local = Text::from(format!("{}_c", &crate::lower::types::place_stem(&rs)));
                                                (push(acc, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(local.clone()), crate::lower::types::own(&crate::lower::types::local_place(&rs, &mode, &ct)))), crate::lower::types::bind(en, n, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(local.clone()), crate::lower::types::Holding::Owned, ct.clone())))
                                            },
                                            _ => (acc.clone(), en.clone()),
                                        }));
                                        let env2 = crate::lower::types::bind_span(&env1, &crate::lower::place_key(&lx, &one.span), &crate::lower::types::Vl::VlPlace(crate::lower::model::Ex::XVar(Text::lit("y_ev")), crate::lower::types::Holding::ByRef, it.clone()));
                                        call_then(start_value_by_kind(lx.clone(), env2.clone(), e.clone()), move |value_by_kind_9010: crate::lower::types::Vl| {
                                            let body = crate::lower::types::own(&value_by_kind_9010);
                                            let mapped = crate::lower::model::Ex::XMethod(Rc::new(src.clone()), Text::lit("map"), Array::from(vec![crate::lower::model::Ex::XClosure(true, Array::from(vec![crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaBind(Text::lit("y_ev"))), crate::lower::model::OutTy::OutRef(Rc::new(it.clone())))]), Rc::new(body.clone()))]));
                                            prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XBlock(push(&dos, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(Text::lit("src_ev")), src.clone())), Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("src_ev"))), Text::lit("map"), Array::from(vec![crate::lower::model::Ex::XClosure(true, Array::from(vec![crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaBind(Text::lit("y_ev"))), crate::lower::model::OutTy::OutRef(Rc::new(it.clone())))]), Rc::new(body.clone()))])))), et.clone()))
                                        })
                                    }))
                                })
                            });
                        }
                        prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(refusal(&Text::lit("an event value of several events")), et.clone()))
                    }
                },
            }
        })
    }
}

/// `Start EventValueOf, x`: what the function value is when passed to `@Run`.
pub fn start_event_value_of(lx: crate::lower::Lx, env: crate::lower::types::Env, e: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<crate::lower::types::Vl>> {
    Rc::new(EventValueOf { lx, env, e })
}

/// ```prism
/// ValueByKind: unbounded fn Lx, Env, Expr -> Vl
/// ```
pub fn value_by_kind(lx: &crate::lower::Lx, env: &crate::lower::types::Env, e: &crate::syntax::Expr) -> crate::lower::types::Vl {
    match get(&lx.lifts, &crate::lower::place_key(lx, &e.span)) {
        Some(ln) if (&len(&ln.operands) > &Nat::from(0u32)) => lifted_value(lx, env, e, &ln),
        _ => plain_value_by_kind(lx, env, e),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `ValueByKind`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ValueByKind: unbounded fn Lx, Env, Expr -> Vl
/// ```
pub struct ValueByKind {
    pub lx: crate::lower::Lx,
    pub env: crate::lower::types::Env,
    pub e: crate::syntax::Expr,
}

impl prism_rtl::Job<crate::lower::types::Vl> for ValueByKind {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::types::Vl> {
        let lx = &self.lx;
        let env = &self.env;
        let e = &self.e;
        match get(&lx.lifts, &crate::lower::place_key(lx, &e.span)) {
            Some(ln) if (&len(&ln.operands) > &Nat::from(0u32)) => prism_rtl::Turn::More(Rc::new(LiftedValue { lx: lx.clone(), env: env.clone(), e: e.clone(), ln: ln.clone() })),
            _ => prism_rtl::Turn::More(Rc::new(PlainValueByKind { lx: lx.clone(), env: env.clone(), e: e.clone() })),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start ValueByKind, x`: what the function value is when passed to `@Run`.
pub fn start_value_by_kind(lx: crate::lower::Lx, env: crate::lower::types::Env, e: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<crate::lower::types::Vl>> {
    Rc::new(ValueByKind { lx, env, e })
}

/// ```prism
/// LiftedValue: unbounded fn Lx, Env, Expr, LiftNote -> Vl
/// ```
pub fn lifted_value(lx: &crate::lower::Lx, env: &crate::lower::types::Env, e: &crate::syntax::Expr, ln: &crate::check::typed::LiftNote) -> crate::lower::types::Vl {
    let at_ = crate::lower::place_key(lx, &e.span);
    let t = crate::lower::types::out_ty_of(lx, &crate::lower::types::peel(&crate::lower::type_at(lx, &e.span)));
    let inner = crate::lower::patterns::inner_ty(&crate::lower::type_at(lx, &e.span));
    let self_operand = fold(&ln.operands, &false, &(|f: &bool, r: &crate::syntax::Range| *f || (r == &e.span)));
    let missing = fold(&ln.operands, &false, &(|f: &bool, r: &crate::syntax::Range| *f || (&operand_at(e, r) == &None)));
    if ((&inner == &crate::check::types::Ty::TyErr) || self_operand) || missing {
        crate::lower::types::Vl::VlOwned(refusal(&Text::from(format!("a lift over `{}` at `{}` of {}", &ln.sigil, &crate::lower::functions::src_text(lx, &lx.file, &e.span), &kind_words(&*e.kind)))), t.clone())
    } else {
        {
            let lx1 = {
                let mut this: crate::lower::Lx = lx.clone();
                this.tys = insert(&this.tys, &at_, &inner);
                this.lifts = insert(&this.lifts, &at_, &crate::check::typed::LiftNote { at: ln.at.clone(), sigil: ln.sigil.clone(), operands: Array::new() });
                this
            };
            let lx2 = fold(&ln.operands, &lx1, &(|l: &crate::lower::Lx, r: &crate::syntax::Range| {
                let mut this: crate::lower::Lx = l.clone();
                this.tys = insert(&this.tys, &crate::lower::place_key(lx, r), &crate::lower::patterns::inner_ty(&crate::lower::type_at(lx, r)));
                this
            }));
            crate::lower::types::Vl::VlOwned(lift_operands(lx, &lx2, env, e, &ln.sigil, &ln.operands, &t), t.clone())
        }
    }
}

/// The step machine of `LiftedValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LiftedValue: unbounded fn Lx, Env, Expr, LiftNote -> Vl
/// ```
pub struct LiftedValue {
    pub lx: crate::lower::Lx,
    pub env: crate::lower::types::Env,
    pub e: crate::syntax::Expr,
    pub ln: crate::check::typed::LiftNote,
}

impl prism_rtl::Job<crate::lower::types::Vl> for LiftedValue {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::types::Vl> {
        let lx = &self.lx;
        let env = &self.env;
        let e = &self.e;
        let ln = &self.ln;
        let at_ = crate::lower::place_key(lx, &e.span);
        let e = e.clone();
        let env = env.clone();
        let ln = ln.clone();
        let lx = lx.clone();
        call_then(crate::lower::types::start_out_ty_of(lx.clone(), crate::lower::types::peel(&crate::lower::type_at(&lx, &e.span))), move |out_ty_of_10356: crate::lower::model::OutTy| {
            let t = out_ty_of_10356;
            let inner = crate::lower::patterns::inner_ty(&crate::lower::type_at(&lx, &e.span));
            let self_operand = fold(&ln.operands, &false, &(|f: &bool, r: &crate::syntax::Range| *f || (r == &e.span)));
            let missing = fold(&ln.operands, &false, &(|f: &bool, r: &crate::syntax::Range| *f || (&operand_at(&e, r) == &None)));
            if ((&inner == &crate::check::types::Ty::TyErr) || self_operand) || missing {
                prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(refusal(&Text::from(format!("a lift over `{}` at `{}` of {}", &ln.sigil, &crate::lower::functions::src_text(&lx, &lx.file, &e.span), &kind_words(&*e.kind)))), t.clone()))
            } else {
                {
                    let lx1 = {
                        let mut this: crate::lower::Lx = lx.clone();
                        this.tys = insert(&this.tys, &at_, &inner);
                        this.lifts = insert(&this.lifts, &at_, &crate::check::typed::LiftNote { at: ln.at.clone(), sigil: ln.sigil.clone(), operands: Array::new() });
                        this
                    };
                    let lx2 = fold(&ln.operands, &lx1, &(|l: &crate::lower::Lx, r: &crate::syntax::Range| {
                        let mut this: crate::lower::Lx = l.clone();
                        this.tys = insert(&this.tys, &crate::lower::place_key(&lx, r), &crate::lower::patterns::inner_ty(&crate::lower::type_at(&lx, r)));
                        this
                    }));
                    call_then(start_lift_operands(lx.clone(), lx2.clone(), env.clone(), e.clone(), ln.sigil.clone(), ln.operands.clone(), t.clone()), move |lift_operands_11083: crate::lower::model::Ex| prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(lift_operands_11083, t.clone())))
                }
            }
        })
    }
}

/// `Start LiftedValue, x`: what the function value is when passed to `@Run`.
pub fn start_lifted_value(lx: crate::lower::Lx, env: crate::lower::types::Env, e: crate::syntax::Expr, ln: crate::check::typed::LiftNote) -> Rc<dyn prism_rtl::Job<crate::lower::types::Vl>> {
    Rc::new(LiftedValue { lx, env, e, ln })
}

/// ```prism
/// LiftOperands: unbounded fn Lx, Lx, Env, Expr, Text, [Range], OutTy -> Ex
/// ```
pub fn lift_operands(lx: &crate::lower::Lx, lx_in: &crate::lower::Lx, env: &crate::lower::types::Env, e: &crate::syntax::Expr, sigil: &Text, operands: &Array<crate::syntax::Range>, t: &crate::lower::model::OutTy) -> crate::lower::model::Ex {
    match operands {
        m11346_0 if (m11346_0.len() == 0) => crate::lower::model::Ex::XCtor(if sigil == &Text::lit("~") { Text::lit("Ok") } else { Text::lit("Some") }, Array::from(vec![crate::lower::types::own(&plain_value_by_kind(lx_in, env, e))])),
        _ => {
            let r = or(&index(operands, &Nat::from(0u32)), &e.span);
            let sv = value_of(lx, env, &or(&operand_at(e, &r), &dummy_expr()));
            let it = crate::lower::types::out_ty_of(lx, &crate::lower::patterns::inner_ty(&crate::lower::type_at(lx, &r)));
            let owned = match &sv {
                crate::lower::types::Vl::VlOwned(_, _) => true,
                _ => false,
            };
            let mode = if owned {
                crate::lower::types::Holding::Owned
            } else {
                crate::lower::types::Holding::ByRef
            };
            let x = Text::from(format!("o{}_{}", &r.start, &r.end));
            let env2 = crate::lower::types::bind_span(env, &crate::lower::place_key(lx, &r), &crate::lower::types::Vl::VlPlace(crate::lower::model::Ex::XVar(x.clone()), mode.clone(), it.clone()));
            let body = lift_operands(lx, lx_in, &env2, e, sigil, &drop(operands, &Nat::from(1u32)), t);
            let fail_arm = if sigil == &Text::lit("~") {
                crate::lower::model::XArm { pat: crate::lower::model::Pa::PaCtor(Text::lit("Err"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::from(format!("{}_e", &x)))])), conds: Array::new(), body: crate::lower::model::Ex::XCtor(Text::lit("Err"), Array::from(vec![crate::lower::types::own(&crate::lower::types::Vl::VlPlace(crate::lower::model::Ex::XVar(Text::from(format!("{}_e", &x))), mode.clone(), crate::lower::model::OutTy::OutError))])) }
            } else {
                crate::lower::model::XArm { pat: crate::lower::model::Pa::PaUnit(Text::lit("None")), conds: Array::new(), body: crate::lower::model::Ex::XTyped(Rc::new(crate::lower::model::Ex::XNone), t.clone()) }
            };
            let arms = Array::from(vec![crate::lower::model::XArm { pat: crate::lower::model::Pa::PaCtor(if sigil == &Text::lit("~") { Text::lit("Ok") } else { Text::lit("Some") }, Array::from(vec![crate::lower::model::Pa::PaBind(x.clone())])), conds: Array::new(), body: body.clone() }, fail_arm.clone()]);
            crate::lower::model::Ex::XMatch(Rc::new(if owned { crate::lower::types::own(&sv) } else { crate::lower::types::ref_(&sv) }), arms.clone(), false, t.clone())
        },
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `LiftOperands`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LiftOperands: unbounded fn Lx, Lx, Env, Expr, Text, [Range], OutTy -> Ex
/// ```
pub struct LiftOperands {
    pub lx: crate::lower::Lx,
    pub lx_in: crate::lower::Lx,
    pub env: crate::lower::types::Env,
    pub e: crate::syntax::Expr,
    pub sigil: Text,
    pub operands: Array<crate::syntax::Range>,
    pub t: crate::lower::model::OutTy,
}

impl prism_rtl::Job<crate::lower::model::Ex> for LiftOperands {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::Ex> {
        let lx = &self.lx;
        let lx_in = &self.lx_in;
        let env = &self.env;
        let e = &self.e;
        let sigil = &self.sigil;
        let operands = &self.operands;
        let t = &self.t;
        match operands {
            m11346_0 if (m11346_0.len() == 0) => {
                let e = e.clone();
                let env = env.clone();
                let lx_in = lx_in.clone();
                let sigil = sigil.clone();
                call_then(start_plain_value_by_kind(lx_in.clone(), env.clone(), e.clone()), move |plain_value_by_kind_11423: crate::lower::types::Vl| prism_rtl::Turn::Finished(crate::lower::model::Ex::XCtor(if &sigil == &Text::lit("~") { Text::lit("Ok") } else { Text::lit("Some") }, Array::from(vec![crate::lower::types::own(&plain_value_by_kind_11423)]))))
            },
            _ => {
                let r = or(&index(operands, &Nat::from(0u32)), &e.span);
                let e = e.clone();
                let env = env.clone();
                let lx = lx.clone();
                let lx_in = lx_in.clone();
                let operands = operands.clone();
                let sigil = sigil.clone();
                let t = t.clone();
                call_then(start_value_of(lx.clone(), env.clone(), or(&operand_at(&e, &r), &dummy_expr())), move |value_of_11527: crate::lower::types::Vl| {
                    let sv = value_of_11527;
                    call_then(crate::lower::types::start_out_ty_of(lx.clone(), crate::lower::patterns::inner_ty(&crate::lower::type_at(&lx, &r))), move |out_ty_of_11595: crate::lower::model::OutTy| {
                        let it = out_ty_of_11595;
                        let owned = match &sv {
                            crate::lower::types::Vl::VlOwned(_, _) => true,
                            _ => false,
                        };
                        let mode = if owned {
                            crate::lower::types::Holding::Owned
                        } else {
                            crate::lower::types::Holding::ByRef
                        };
                        let x = Text::from(format!("o{}_{}", &r.start, &r.end));
                        let env2 = crate::lower::types::bind_span(&env, &crate::lower::place_key(&lx, &r), &crate::lower::types::Vl::VlPlace(crate::lower::model::Ex::XVar(x.clone()), mode.clone(), it.clone()));
                        call_then(start_lift_operands(lx.clone(), lx_in.clone(), env2.clone(), e.clone(), sigil.clone(), drop(&operands, &Nat::from(1u32)), t.clone()), move |lift_operands_11915: crate::lower::model::Ex| {
                            let body = lift_operands_11915;
                            let fail_arm = if &sigil == &Text::lit("~") {
                                crate::lower::model::XArm { pat: crate::lower::model::Pa::PaCtor(Text::lit("Err"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::from(format!("{}_e", &x)))])), conds: Array::new(), body: crate::lower::model::Ex::XCtor(Text::lit("Err"), Array::from(vec![crate::lower::types::own(&crate::lower::types::Vl::VlPlace(crate::lower::model::Ex::XVar(Text::from(format!("{}_e", &x))), mode.clone(), crate::lower::model::OutTy::OutError))])) }
                            } else {
                                crate::lower::model::XArm { pat: crate::lower::model::Pa::PaUnit(Text::lit("None")), conds: Array::new(), body: crate::lower::model::Ex::XTyped(Rc::new(crate::lower::model::Ex::XNone), t.clone()) }
                            };
                            let arms = Array::from(vec![crate::lower::model::XArm { pat: crate::lower::model::Pa::PaCtor(if &sigil == &Text::lit("~") { Text::lit("Ok") } else { Text::lit("Some") }, Array::from(vec![crate::lower::model::Pa::PaBind(x.clone())])), conds: Array::new(), body: body.clone() }, fail_arm.clone()]);
                            prism_rtl::Turn::Finished(crate::lower::model::Ex::XMatch(Rc::new(if owned { crate::lower::types::own(&sv) } else { crate::lower::types::ref_(&sv) }), arms.clone(), false, t.clone()))
                        })
                    })
                })
            },
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start LiftOperands, x`: what the function value is when passed to `@Run`.
pub fn start_lift_operands(lx: crate::lower::Lx, lx_in: crate::lower::Lx, env: crate::lower::types::Env, e: crate::syntax::Expr, sigil: Text, operands: Array<crate::syntax::Range>, t: crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>> {
    Rc::new(LiftOperands { lx, lx_in, env, e, sigil, operands, t })
}

/// ```prism
/// IsLiftedAt: fn Lx, Range -> Bool
/// ```
pub fn is_lifted_at(lx: &crate::lower::Lx, r: &crate::syntax::Range) -> bool {
    match get(&lx.lifts, &crate::lower::place_key(lx, r)) {
        Some(ln) => &len(&ln.operands) > &Nat::from(0u32),
        None => false,
    }
}

/// ```prism
/// ?OperandAt: fn Expr, Range -> ?Expr
/// ```
pub fn operand_at(e: &crate::syntax::Expr, r: &crate::syntax::Range) -> Option<crate::syntax::Expr> {
    fold(&direct_operands(e), &None, &(|found_opt: &Option<crate::syntax::Expr>, x: &crate::syntax::Expr| if (found_opt == &None) && (&x.span == r) {
        Some(x.clone())
    } else {
        found_opt.clone()
    }))
}

/// ```prism
/// DirectOperands: fn Expr -> [Expr]
/// ```
pub fn direct_operands(e: &crate::syntax::Expr) -> Array<crate::syntax::Expr> {
    match &*e.kind {
        crate::syntax::ExprKind::EGroup(x) => direct_operands(&**x),
        crate::syntax::ExprKind::ECall(_, args, _, _) => each(args, &(|a: &crate::syntax::Arg| a.value.clone())),
        crate::syntax::ExprKind::EMethod(r, _, args) => append(&Array::from(vec![(**r).clone()]), &each(args, &(|a: &crate::syntax::Arg| a.value.clone()))),
        crate::syntax::ExprKind::EBinary(_, l, r) => Array::from(vec![(**l).clone(), (**r).clone()]),
        crate::syntax::ExprKind::EUnary(_, x) => Array::from(vec![(**x).clone()]),
        crate::syntax::ExprKind::EFreeSigil(_, x) => Array::from(vec![(**x).clone()]),
        crate::syntax::ExprKind::EField(r, _, _) => Array::from(vec![(**r).clone()]),
        crate::syntax::ExprKind::EIndex(r, i) => Array::from(vec![(**r).clone(), (**i).clone()]),
        crate::syntax::ExprKind::EMap(kvs) => fold(kvs, &Array::new(), &(|acc: &Array<crate::syntax::Expr>, (k, v_): &(crate::syntax::Expr, crate::syntax::Expr)| append(acc, &Array::from(vec![k.clone(), v_.clone()])))),
        _ => Array::new(),
    }
}

/// ```prism
/// PlainValueByKind: unbounded fn Lx, Env, Expr -> Vl
/// ```
pub fn plain_value_by_kind(lx: &crate::lower::Lx, env: &crate::lower::types::Env, e: &crate::syntax::Expr) -> crate::lower::types::Vl {
    let t = crate::lower::types::out_ty_of(lx, &crate::lower::types::peel(&crate::lower::type_at(lx, &e.span)));
    match &*e.kind {
        crate::syntax::ExprKind::EName(n) => name_value(lx, env, n, &e.span),
        crate::syntax::ExprKind::ELit(l) => literal_value(lx, env, l, &e.span, &false),
        crate::syntax::ExprKind::EUnit(_) => crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XUnit, crate::lower::model::OutTy::OutUnit),
        crate::syntax::ExprKind::EBound(b) => match get(&env.names, b) {
            Some(crate::lower::types::Bn::BnLocal(rs, mode, bt)) => crate::lower::types::local_place(&rs, &mode, &bt),
            _ => crate::lower::types::Vl::VlOwned(refusal(&Text::from(format!("`{}` outside a `for`", b))), t.clone()),
        },
        crate::syntax::ExprKind::ENil(_) => crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XTyped(Rc::new(crate::lower::model::Ex::XNone), t.clone()), t.clone()),
        crate::syntax::ExprKind::ETuple(es) => crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XTuple(run_to_end(each_job(es.clone(), {
            let lx = lx.clone();
            let env = env.clone();
            Rc::new(move |p0: crate::syntax::Expr| {
                let lx = lx.clone();
                let env = env.clone();
                entered(once_job(move || {
                    let x = p0;
                    call_then(start_value_of(lx.clone(), env.clone(), x.clone()), move |value_of_13857: crate::lower::types::Vl| prism_rtl::Turn::Finished(crate::lower::types::own(&value_of_13857)))
                }))
            }) as Rc<dyn Fn(crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
        }))), t.clone()),
        crate::syntax::ExprKind::EArray(m13420_6_0) if (m13420_6_0.len() == 0) => crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XTyped(Rc::new(crate::lower::model::Ex::XCall(Text::lit("Array::new"), Array::new())), t.clone()), t.clone()),
        crate::syntax::ExprKind::EArray(es) => crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCall(Text::lit("Array::from"), Array::from(vec![crate::lower::model::Ex::XVec(run_to_end(each_job(es.clone(), {
            let lx = lx.clone();
            let env = env.clone();
            Rc::new(move |p0: crate::syntax::Expr| {
                let lx = lx.clone();
                let env = env.clone();
                entered(once_job(move || {
                    let x = p0;
                    call_then(start_value_of(lx.clone(), env.clone(), x.clone()), move |value_of_14029: crate::lower::types::Vl| prism_rtl::Turn::Finished(crate::lower::types::own(&value_of_14029)))
                }))
            }) as Rc<dyn Fn(crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
        })))])), t.clone()),
        crate::syntax::ExprKind::EMap(m13420_8_0) if (m13420_8_0.len() == 0) => crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XTyped(Rc::new(crate::lower::model::Ex::XCall(Text::lit("Map::new"), Array::new())), t.clone()), t.clone()),
        crate::syntax::ExprKind::EMap(kvs) => crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCall(Text::lit("map_of"), Array::from(vec![crate::lower::model::Ex::XVec(run_to_end(each_job(kvs.clone(), {
            let lx = lx.clone();
            let env = env.clone();
            Rc::new(move |p0: (crate::syntax::Expr, crate::syntax::Expr)| {
                let lx = lx.clone();
                let env = env.clone();
                entered(once_job(move || {
                    let (k, v_) = p0;
                    call_then(start_value_of(lx.clone(), env.clone(), k.clone()), move |value_of_14210: crate::lower::types::Vl| call_then(start_value_of(lx.clone(), env.clone(), v_.clone()), move |value_of_14236: crate::lower::types::Vl| prism_rtl::Turn::Finished(crate::lower::model::Ex::XTuple(Array::from(vec![crate::lower::types::own(&value_of_14210), crate::lower::types::own(&value_of_14236)])))))
                }))
            }) as Rc<dyn Fn((crate::syntax::Expr, crate::syntax::Expr)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
        })))])), t.clone()),
        crate::syntax::ExprKind::EGroup(x) => value_of(lx, env, &**x),
        crate::syntax::ExprKind::ECall(c, args, _, _) => application(lx, env, &**c, args, &e.span),
        crate::syntax::ExprKind::EMethod(r, m, args) => application(lx, env, &crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EName(m.clone())), span: m.span.clone() }, &append(&Array::from(vec![crate::syntax::Arg { name: None, value: (**r).clone(), span: r.span.clone() }]), args), &e.span),
        crate::syntax::ExprKind::EBinary(op, l, r) => binary_value(lx, env, op, &**l, &**r, &e.span),
        crate::syntax::ExprKind::EUnary(m13420_14_0, x) if (m13420_14_0 == &Text::lit("not")) => crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XUnary(Text::lit("!"), Rc::new(crate::lower::types::as_bool(&value_of(lx, env, &**x)))), crate::lower::model::OutTy::OutBool),
        crate::syntax::ExprKind::EUnary(m13420_15_0, x) if (m13420_15_0 == &Text::lit("neg")) => match &*x.kind {
            crate::syntax::ExprKind::ELit(l) => literal_value(lx, env, l, &x.span, &true),
            _ => {
                let v_ = value_of(lx, env, &**x);
                if crate::lower::types::is_copy(&t) {
                    crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XUnary(Text::lit("-"), Rc::new(crate::lower::types::copy(&v_))), t.clone())
                } else {
                    crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XUnary(Text::lit("-"), Rc::new(crate::lower::types::ref_(&v_))), t.clone())
                }
            },
        },
        crate::syntax::ExprKind::EUnary(_, x) => value_of(lx, env, &**x),
        crate::syntax::ExprKind::EFreeSigil(m13420_17_0, x) if (m13420_17_0 == &Text::lit("?")) => crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCtor(Text::lit("Some"), Array::from(vec![crate::lower::types::own(&value_of(lx, env, &**x))])), t.clone()),
        crate::syntax::ExprKind::EFreeSigil(m13420_18_0, x) if (m13420_18_0 == &Text::lit("~")) => crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCtor(Text::lit("Ok"), Array::from(vec![crate::lower::types::own(&value_of(lx, env, &**x))])), t.clone()),
        crate::syntax::ExprKind::EFreeSigil(m13420_19_0, x) if (m13420_19_0 == &Text::lit("@")) => pure_blueprint(lx, env, &**x, &t),
        crate::syntax::ExprKind::EFreeSigil(_, x) => value_of(lx, env, &**x),
        crate::syntax::ExprKind::EField(r, _, name) => field_value(lx, env, &**r, &name.name),
        crate::syntax::ExprKind::EIndex(r, i) => index_value(lx, env, &**r, &**i, &t),
        crate::syntax::ExprKind::ELambda(ps_opt, body) => lambda_value(lx, env, e, &or(ps_opt, &Array::new()), &**body),
        crate::syntax::ExprKind::EIf(c, then_b, else_b_opt) => if_value(lx, env, &**c, then_b, else_b_opt, &t),
        crate::syntax::ExprKind::EMatch(s, arms) => match_value(lx, env, &**s, arms, &t, &e.span),
        crate::syntax::ExprKind::ETemplate(tp) => crate::lower::templates::template_value(lx, env, tp),
        crate::syntax::ExprKind::ECast(x, _, _) => value_of(lx, env, &**x),
        crate::syntax::ExprKind::ETypeArgs(x, _) => value_of(lx, env, &**x),
        crate::syntax::ExprKind::EGiven(b) => crate::lower::templates::given_value(lx, env, b, &t, &e.span),
        crate::syntax::ExprKind::EUpdate(target, b) => crate::lower::templates::update_value(lx, env, &**target, b, &t, &e.span),
        crate::syntax::ExprKind::EAny(x) => crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCall(Text::lit("Rc::new"), Array::from(vec![crate::lower::types::own(&value_of(lx, env, &**x))])), crate::lower::model::OutTy::OutShowAny),
        _ => crate::lower::types::Vl::VlOwned(refusal(&Text::from(format!("{} as a value", &kind_words(&*e.kind)))), t.clone()),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `PlainValueByKind`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PlainValueByKind: unbounded fn Lx, Env, Expr -> Vl
/// ```
pub struct PlainValueByKind {
    pub lx: crate::lower::Lx,
    pub env: crate::lower::types::Env,
    pub e: crate::syntax::Expr,
}

impl prism_rtl::Job<crate::lower::types::Vl> for PlainValueByKind {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::types::Vl> {
        let lx = &self.lx;
        let env = &self.env;
        let e = &self.e;
        let e = e.clone();
        let env = env.clone();
        let lx = lx.clone();
        call_then(crate::lower::types::start_out_ty_of(lx.clone(), crate::lower::types::peel(&crate::lower::type_at(&lx, &e.span))), move |out_ty_of_13377: crate::lower::model::OutTy| {
            let t = out_ty_of_13377;
            match &*e.kind {
                crate::syntax::ExprKind::EName(n) => prism_rtl::Turn::More(Rc::new(NameValue { lx: lx.clone(), env: env.clone(), n: n.clone(), span: e.span.clone() })),
                crate::syntax::ExprKind::ELit(l) => prism_rtl::Turn::More(Rc::new(LiteralValue { lx: lx.clone(), env: env.clone(), l: l.clone(), span: e.span.clone(), neg: false })),
                crate::syntax::ExprKind::EUnit(_) => prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XUnit, crate::lower::model::OutTy::OutUnit)),
                crate::syntax::ExprKind::EBound(b) => match get(&env.names, b) {
                    Some(crate::lower::types::Bn::BnLocal(rs, mode, bt)) => prism_rtl::Turn::Finished(crate::lower::types::local_place(&rs, &mode, &bt)),
                    _ => prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(refusal(&Text::from(format!("`{}` outside a `for`", b))), t.clone())),
                },
                crate::syntax::ExprKind::ENil(_) => prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XTyped(Rc::new(crate::lower::model::Ex::XNone), t.clone()), t.clone())),
                crate::syntax::ExprKind::ETuple(es) => {
                    let es = es.clone();
                    call_value(each_job(es.clone(), {
                        let lx = lx.clone();
                        let env = env.clone();
                        Rc::new(move |p0: crate::syntax::Expr| {
                            let lx = lx.clone();
                            let env = env.clone();
                            entered(once_job(move || {
                                let x = p0;
                                call_then(start_value_of(lx.clone(), env.clone(), x.clone()), move |value_of_13857: crate::lower::types::Vl| prism_rtl::Turn::Finished(crate::lower::types::own(&value_of_13857)))
                            }))
                        }) as Rc<dyn Fn(crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
                    }), move |each_13838: Array<crate::lower::model::Ex>| prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XTuple(each_13838), t.clone())))
                },
                crate::syntax::ExprKind::EArray(m13420_6_0) if (m13420_6_0.len() == 0) => prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XTyped(Rc::new(crate::lower::model::Ex::XCall(Text::lit("Array::new"), Array::new())), t.clone()), t.clone())),
                crate::syntax::ExprKind::EArray(es) => {
                    let es = es.clone();
                    call_value(each_job(es.clone(), {
                        let lx = lx.clone();
                        let env = env.clone();
                        Rc::new(move |p0: crate::syntax::Expr| {
                            let lx = lx.clone();
                            let env = env.clone();
                            entered(once_job(move || {
                                let x = p0;
                                call_then(start_value_of(lx.clone(), env.clone(), x.clone()), move |value_of_14029: crate::lower::types::Vl| prism_rtl::Turn::Finished(crate::lower::types::own(&value_of_14029)))
                            }))
                        }) as Rc<dyn Fn(crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
                    }), move |each_14010: Array<crate::lower::model::Ex>| prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCall(Text::lit("Array::from"), Array::from(vec![crate::lower::model::Ex::XVec(each_14010)])), t.clone())))
                },
                crate::syntax::ExprKind::EMap(m13420_8_0) if (m13420_8_0.len() == 0) => prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XTyped(Rc::new(crate::lower::model::Ex::XCall(Text::lit("Map::new"), Array::new())), t.clone()), t.clone())),
                crate::syntax::ExprKind::EMap(kvs) => {
                    let kvs = kvs.clone();
                    call_value(each_job(kvs.clone(), {
                        let lx = lx.clone();
                        let env = env.clone();
                        Rc::new(move |p0: (crate::syntax::Expr, crate::syntax::Expr)| {
                            let lx = lx.clone();
                            let env = env.clone();
                            entered(once_job(move || {
                                let (k, v_) = p0;
                                call_then(start_value_of(lx.clone(), env.clone(), k.clone()), move |value_of_14210: crate::lower::types::Vl| call_then(start_value_of(lx.clone(), env.clone(), v_.clone()), move |value_of_14236: crate::lower::types::Vl| prism_rtl::Turn::Finished(crate::lower::model::Ex::XTuple(Array::from(vec![crate::lower::types::own(&value_of_14210), crate::lower::types::own(&value_of_14236)])))))
                            }))
                        }) as Rc<dyn Fn((crate::syntax::Expr, crate::syntax::Expr)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
                    }), move |each_14174: Array<crate::lower::model::Ex>| prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCall(Text::lit("map_of"), Array::from(vec![crate::lower::model::Ex::XVec(each_14174)])), t.clone())))
                },
                crate::syntax::ExprKind::EGroup(x) => prism_rtl::Turn::More(Rc::new(ValueOf { lx: lx.clone(), env: env.clone(), e: (**x).clone() })),
                crate::syntax::ExprKind::ECall(c, args, _, _) => prism_rtl::Turn::More(Rc::new(Application { lx: lx.clone(), env: env.clone(), callee: (**c).clone(), args: args.clone(), span: e.span.clone() })),
                crate::syntax::ExprKind::EMethod(r, m, args) => prism_rtl::Turn::More(Rc::new(Application { lx: lx.clone(), env: env.clone(), callee: crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EName(m.clone())), span: m.span.clone() }, args: append(&Array::from(vec![crate::syntax::Arg { name: None, value: (**r).clone(), span: r.span.clone() }]), args), span: e.span.clone() })),
                crate::syntax::ExprKind::EBinary(op, l, r) => prism_rtl::Turn::More(Rc::new(BinaryValue { lx: lx.clone(), env: env.clone(), op: op.clone(), l: (**l).clone(), r: (**r).clone(), span: e.span.clone() })),
                crate::syntax::ExprKind::EUnary(m13420_14_0, x) if (m13420_14_0 == &Text::lit("not")) => {
                    let x = (**x).clone();
                    call_then(start_value_of(lx.clone(), env.clone(), x.clone()), move |value_of_14646: crate::lower::types::Vl| prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XUnary(Text::lit("!"), Rc::new(crate::lower::types::as_bool(&value_of_14646))), crate::lower::model::OutTy::OutBool)))
                },
                crate::syntax::ExprKind::EUnary(m13420_15_0, x) if (m13420_15_0 == &Text::lit("neg")) => match &*x.kind {
                    crate::syntax::ExprKind::ELit(l) => prism_rtl::Turn::More(Rc::new(LiteralValue { lx: lx.clone(), env: env.clone(), l: l.clone(), span: x.span.clone(), neg: true })),
                    _ => {
                        let x = (**x).clone();
                        call_then(start_value_of(lx.clone(), env.clone(), x.clone()), move |value_of_14821: crate::lower::types::Vl| {
                            let v_ = value_of_14821;
                            if crate::lower::types::is_copy(&t) {
                                prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XUnary(Text::lit("-"), Rc::new(crate::lower::types::copy(&v_))), t.clone()))
                            } else {
                                prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XUnary(Text::lit("-"), Rc::new(crate::lower::types::ref_(&v_))), t.clone()))
                            }
                        })
                    },
                },
                crate::syntax::ExprKind::EUnary(_, x) => prism_rtl::Turn::More(Rc::new(ValueOf { lx: lx.clone(), env: env.clone(), e: (**x).clone() })),
                crate::syntax::ExprKind::EFreeSigil(m13420_17_0, x) if (m13420_17_0 == &Text::lit("?")) => {
                    let x = (**x).clone();
                    call_then(start_value_of(lx.clone(), env.clone(), x.clone()), move |value_of_15044: crate::lower::types::Vl| prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCtor(Text::lit("Some"), Array::from(vec![crate::lower::types::own(&value_of_15044)])), t.clone())))
                },
                crate::syntax::ExprKind::EFreeSigil(m13420_18_0, x) if (m13420_18_0 == &Text::lit("~")) => {
                    let x = (**x).clone();
                    call_then(start_value_of(lx.clone(), env.clone(), x.clone()), move |value_of_15125: crate::lower::types::Vl| prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCtor(Text::lit("Ok"), Array::from(vec![crate::lower::types::own(&value_of_15125)])), t.clone())))
                },
                crate::syntax::ExprKind::EFreeSigil(m13420_19_0, x) if (m13420_19_0 == &Text::lit("@")) => prism_rtl::Turn::More(Rc::new(PureBlueprint { lx: lx.clone(), env: env.clone(), x: (**x).clone(), t: t.clone() })),
                crate::syntax::ExprKind::EFreeSigil(_, x) => prism_rtl::Turn::More(Rc::new(ValueOf { lx: lx.clone(), env: env.clone(), e: (**x).clone() })),
                crate::syntax::ExprKind::EField(r, _, name) => prism_rtl::Turn::More(Rc::new(FieldValue { lx: lx.clone(), env: env.clone(), r: (**r).clone(), name: name.name.clone() })),
                crate::syntax::ExprKind::EIndex(r, i) => prism_rtl::Turn::More(Rc::new(IndexValue { lx: lx.clone(), env: env.clone(), r: (**r).clone(), i: (**i).clone(), t: t.clone() })),
                crate::syntax::ExprKind::ELambda(ps_opt, body) => prism_rtl::Turn::More(Rc::new(LambdaValue { lx: lx.clone(), env: env.clone(), e: e.clone(), ps: or(ps_opt, &Array::new()), body: (**body).clone() })),
                crate::syntax::ExprKind::EIf(c, then_b, else_b_opt) => prism_rtl::Turn::More(Rc::new(IfValue { lx: lx.clone(), env: env.clone(), c: (**c).clone(), then_b: then_b.clone(), else_b_opt: else_b_opt.clone(), t: t.clone() })),
                crate::syntax::ExprKind::EMatch(s, arms) => prism_rtl::Turn::More(Rc::new(MatchValue { lx: lx.clone(), env: env.clone(), s: (**s).clone(), arms: arms.clone(), t: t.clone(), span: e.span.clone() })),
                crate::syntax::ExprKind::ETemplate(tp) => prism_rtl::Turn::More(Rc::new(crate::lower::templates::TemplateValue { lx: lx.clone(), env: env.clone(), tp: tp.clone() })),
                crate::syntax::ExprKind::ECast(x, _, _) => prism_rtl::Turn::More(Rc::new(ValueOf { lx: lx.clone(), env: env.clone(), e: (**x).clone() })),
                crate::syntax::ExprKind::ETypeArgs(x, _) => prism_rtl::Turn::More(Rc::new(ValueOf { lx: lx.clone(), env: env.clone(), e: (**x).clone() })),
                crate::syntax::ExprKind::EGiven(b) => prism_rtl::Turn::More(Rc::new(crate::lower::templates::GivenValue { lx: lx.clone(), env: env.clone(), b: b.clone(), t: t.clone(), span: e.span.clone() })),
                crate::syntax::ExprKind::EUpdate(target, b) => prism_rtl::Turn::More(Rc::new(crate::lower::templates::UpdateValue { lx: lx.clone(), env: env.clone(), target: (**target).clone(), b: b.clone(), t: t.clone(), span: e.span.clone() })),
                crate::syntax::ExprKind::EAny(x) => {
                    let x = (**x).clone();
                    call_then(start_value_of(lx.clone(), env.clone(), x.clone()), move |value_of_15888: crate::lower::types::Vl| prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCall(Text::lit("Rc::new"), Array::from(vec![crate::lower::types::own(&value_of_15888)])), crate::lower::model::OutTy::OutShowAny)))
                },
                _ => prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(refusal(&Text::from(format!("{} as a value", &kind_words(&*e.kind)))), t.clone())),
                _ => unreachable!("no arm matched"),
            }
        })
    }
}

/// `Start PlainValueByKind, x`: what the function value is when passed to `@Run`.
pub fn start_plain_value_by_kind(lx: crate::lower::Lx, env: crate::lower::types::Env, e: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<crate::lower::types::Vl>> {
    Rc::new(PlainValueByKind { lx, env, e })
}

/// ```prism
/// PureBlueprint: unbounded fn Lx, Env, Expr, OutTy -> Vl
/// ```
pub fn pure_blueprint(lx: &crate::lower::Lx, env: &crate::lower::types::Env, x: &crate::syntax::Expr, t: &crate::lower::model::OutTy) -> crate::lower::types::Vl {
    let is_never = match &*x.kind {
        crate::syntax::ExprKind::EName(n) => {
            let (qk_opt, _) = crate::check::env::names::resolve_value(&lx.g, &lx.home, n);
            &qk_opt == &Some(Text::lit("Prelude.never"))
        },
        _ => false,
    };
    if is_never {
        crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCall(Text::lit("prism_rtl::never_blueprint::<crate::Elem, crate::Answer>"), Array::new()), t.clone())
    } else {
        match get(&env.names, &Text::lit("#tag")) {
            None => crate::lower::types::Vl::VlOwned(refusal(&Text::from(format!("`@ {}` as a supplier\'s answer outside a tag arm: which tag\'s output it answers cannot be known", &crate::lower::functions::src_text(lx, &lx.file, &x.span)))), t.clone()),
            Some(crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XPath(variant), _, _)) => match crate::lower::types::layer_of(&crate::lower::type_at(lx, &x.span)) {
                crate::lower::types::Layer::LyEv => {
                    let wrapped = crate::lower::model::Ex::XMethod(Rc::new(crate::lower::types::own(&value_of(lx, env, x))), Text::lit("map"), Array::from(vec![crate::lower::model::Ex::XClosure(false, Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("v"))]), Rc::new(crate::lower::model::Ex::XCtor(variant.clone(), Array::from(vec![crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(Text::lit("v"))))]))))]));
                    crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCall(Text::lit("prism_rtl::event_blueprint::<crate::Elem, _>"), Array::from(vec![wrapped.clone()])), t.clone())
                },
                crate::lower::types::Layer::LyDyn => match crate::lower::node_::static_::dynamic_answer(lx, x) {
                    None => match &*x.kind {
                        crate::syntax::ExprKind::EFreeSigil(m17590_0_0, inner) if (m17590_0_0 == &Text::lit("$")) => plain_blueprint_(lx, env, &**inner, &variant, t),
                        _ => crate::lower::types::Vl::VlOwned(refusal(&Text::from(format!("`@ {}`, a supplier\'s dynamic answer of no known form", &crate::lower::functions::src_text(lx, &lx.file, &x.span)))), t.clone()),
                        _ => unreachable!("no arm matched"),
                    },
                    Some(d) => dynamic_blueprint_(lx, env, x, &d, &variant, t),
                },
                _ => plain_blueprint_(lx, env, x, &variant, t),
            },
            _ => crate::lower::types::Vl::VlOwned(refusal(&Text::lit("a supplier\'s answer under a tag the arm does not name")), t.clone()),
        }
    }
}

/// The step machine of `PureBlueprint`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PureBlueprint: unbounded fn Lx, Env, Expr, OutTy -> Vl
/// ```
pub struct PureBlueprint {
    pub lx: crate::lower::Lx,
    pub env: crate::lower::types::Env,
    pub x: crate::syntax::Expr,
    pub t: crate::lower::model::OutTy,
}

impl prism_rtl::Job<crate::lower::types::Vl> for PureBlueprint {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::types::Vl> {
        let lx = &self.lx;
        let env = &self.env;
        let x = &self.x;
        let t = &self.t;
        let is_never = match &*x.kind {
            crate::syntax::ExprKind::EName(n) => {
                let (qk_opt, _) = crate::check::env::names::resolve_value(&lx.g, &lx.home, n);
                &qk_opt == &Some(Text::lit("Prelude.never"))
            },
            _ => false,
        };
        if is_never {
            prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCall(Text::lit("prism_rtl::never_blueprint::<crate::Elem, crate::Answer>"), Array::new()), t.clone()))
        } else {
            match get(&env.names, &Text::lit("#tag")) {
                None => prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(refusal(&Text::from(format!("`@ {}` as a supplier\'s answer outside a tag arm: which tag\'s output it answers cannot be known", &crate::lower::functions::src_text(lx, &lx.file, &x.span)))), t.clone())),
                Some(crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XPath(variant), _, _)) => match crate::lower::types::layer_of(&crate::lower::type_at(lx, &x.span)) {
                    crate::lower::types::Layer::LyEv => {
                        let env = env.clone();
                        let lx = lx.clone();
                        let t = t.clone();
                        let x = x.clone();
                        call_then(start_value_of(lx.clone(), env.clone(), x.clone()), move |value_of_17319: crate::lower::types::Vl| {
                            let wrapped = crate::lower::model::Ex::XMethod(Rc::new(crate::lower::types::own(&value_of_17319)), Text::lit("map"), Array::from(vec![crate::lower::model::Ex::XClosure(false, Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("v"))]), Rc::new(crate::lower::model::Ex::XCtor(variant.clone(), Array::from(vec![crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(Text::lit("v"))))]))))]));
                            prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCall(Text::lit("prism_rtl::event_blueprint::<crate::Elem, _>"), Array::from(vec![wrapped.clone()])), t.clone()))
                        })
                    },
                    crate::lower::types::Layer::LyDyn => match crate::lower::node_::static_::dynamic_answer(lx, x) {
                        None => match &*x.kind {
                            crate::syntax::ExprKind::EFreeSigil(m17590_0_0, inner) if (m17590_0_0 == &Text::lit("$")) => prism_rtl::Turn::More(Rc::new(PlainBlueprint { lx: lx.clone(), env: env.clone(), x: (**inner).clone(), variant: variant.clone(), t: t.clone() })),
                            _ => prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(refusal(&Text::from(format!("`@ {}`, a supplier\'s dynamic answer of no known form", &crate::lower::functions::src_text(lx, &lx.file, &x.span)))), t.clone())),
                            _ => unreachable!("no arm matched"),
                        },
                        Some(d) => prism_rtl::Turn::More(Rc::new(DynamicBlueprint { lx: lx.clone(), env: env.clone(), x: x.clone(), d: d.clone(), variant: variant.clone(), t: t.clone() })),
                    },
                    _ => prism_rtl::Turn::More(Rc::new(PlainBlueprint { lx: lx.clone(), env: env.clone(), x: x.clone(), variant: variant.clone(), t: t.clone() })),
                },
                _ => prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(refusal(&Text::lit("a supplier\'s answer under a tag the arm does not name")), t.clone())),
            }
        }
    }
}

/// `Start PureBlueprint, x`: what the function value is when passed to `@Run`.
pub fn start_pure_blueprint(lx: crate::lower::Lx, env: crate::lower::types::Env, x: crate::syntax::Expr, t: crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<crate::lower::types::Vl>> {
    Rc::new(PureBlueprint { lx, env, x, t })
}

/// ```prism
/// PlainBlueprint: unbounded fn Lx, Env, Expr, Text, OutTy -> Vl
/// ```
pub fn plain_blueprint_(lx: &crate::lower::Lx, env: &crate::lower::types::Env, x: &crate::syntax::Expr, variant: &Text, t: &crate::lower::model::OutTy) -> crate::lower::types::Vl {
    crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCall(Text::lit("prism_rtl::plain_blueprint::<crate::Elem, _>"), Array::from(vec![crate::lower::model::Ex::XCtor(variant.clone(), Array::from(vec![crate::lower::types::own(&value_of(lx, env, x))]))])), t.clone())
}

/// The step machine of `PlainBlueprint`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PlainBlueprint: unbounded fn Lx, Env, Expr, Text, OutTy -> Vl
/// ```
pub struct PlainBlueprint {
    pub lx: crate::lower::Lx,
    pub env: crate::lower::types::Env,
    pub x: crate::syntax::Expr,
    pub variant: Text,
    pub t: crate::lower::model::OutTy,
}

impl prism_rtl::Job<crate::lower::types::Vl> for PlainBlueprint {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::types::Vl> {
        let lx = &self.lx;
        let env = &self.env;
        let x = &self.x;
        let variant = &self.variant;
        let t = &self.t;
        let env = env.clone();
        let lx = lx.clone();
        let t = t.clone();
        let variant = variant.clone();
        let x = x.clone();
        call_then(start_value_of(lx.clone(), env.clone(), x.clone()), move |value_of_18238: crate::lower::types::Vl| prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCall(Text::lit("prism_rtl::plain_blueprint::<crate::Elem, _>"), Array::from(vec![crate::lower::model::Ex::XCtor(variant.clone(), Array::from(vec![crate::lower::types::own(&value_of_18238)]))])), t.clone())))
    }
}

/// `Start PlainBlueprint, x`: what the function value is when passed to `@Run`.
pub fn start_plain_blueprint_(lx: crate::lower::Lx, env: crate::lower::types::Env, x: crate::syntax::Expr, variant: Text, t: crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<crate::lower::types::Vl>> {
    Rc::new(PlainBlueprint { lx, env, x, variant, t })
}

/// ```prism
/// DynamicBlueprint: unbounded fn Lx, Env, Expr, Expr, Text, OutTy -> Vl
/// ```
pub fn dynamic_blueprint_(lx: &crate::lower::Lx, env: &crate::lower::types::Env, x: &crate::syntax::Expr, d: &crate::syntax::Expr, variant: &Text, t: &crate::lower::model::OutTy) -> crate::lower::types::Vl {
    match (get(&env.names, &Text::from(format!("#dyn{}", &crate::lower::node_::static_::dyn_key(x)))), get(&env.names, &Text::lit("#owner"))) {
        (Some(crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(getter), _, dt)), Some(crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(owner), _, _))) => {
            let at_build = crate::lower::types::own(&value_of(lx, &crate::lower::node_::def::init_env(env), d));
            let arms = Array::from(vec![crate::lower::model::XArm { pat: crate::lower::model::Pa::PaCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("owner"))])), conds: Array::new(), body: crate::lower::model::Ex::XCtor(variant.clone(), Array::from(vec![crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("owner"))), getter.clone(), Array::from(vec![crate::lower::model::Ex::XCx]))])) }, crate::lower::model::XArm { pat: crate::lower::model::Pa::PaUnit(Text::lit("None")), conds: Array::new(), body: crate::lower::model::Ex::XCtor(variant.clone(), Array::from(vec![crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(Text::lit("at_build"))))])) }]);
            let read = crate::lower::model::Ex::XClosure(true, Array::from(vec![crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaBind(Text::lit("cx"))), crate::lower::model::OutTy::OutRef(Rc::new(crate::lower::model::OutTy::OutNamed(Text::lit("Cx"), Array::new()))))]), Rc::new(crate::lower::model::Ex::XMatch(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("link"))), Text::lit("owner"), Array::new())), arms.clone(), false, crate::lower::model::OutTy::OutNamed(Text::lit("crate::Answer"), Array::new()))));
            let dynamic = crate::lower::model::Ex::XBlock(Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(Text::lit("link")), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(owner.clone())))), crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(Text::lit("at_build")), at_build.clone())]), Rc::new(crate::lower::model::Ex::XCall(Text::lit("prism_rtl::Dynamic::of"), Array::from(vec![read.clone(), crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XVar(Text::from(format!("{}_port", &getter)))))]))));
            crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCall(Text::lit("prism_rtl::dynamic_blueprint::<crate::Elem, _>"), Array::from(vec![dynamic.clone()])), t.clone())
        },
        _ => crate::lower::types::Vl::VlOwned(refusal(&Text::from(format!("`@ {}`, a supplier\'s dynamic answer that reads what has no value at the owner\'s build (a pushed place, a structural dynamic, or a `let` after the host\'s line)", &crate::lower::functions::src_text(lx, &lx.file, &x.span)))), t.clone()),
    }
}

/// The step machine of `DynamicBlueprint`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// DynamicBlueprint: unbounded fn Lx, Env, Expr, Expr, Text, OutTy -> Vl
/// ```
pub struct DynamicBlueprint {
    pub lx: crate::lower::Lx,
    pub env: crate::lower::types::Env,
    pub x: crate::syntax::Expr,
    pub d: crate::syntax::Expr,
    pub variant: Text,
    pub t: crate::lower::model::OutTy,
}

impl prism_rtl::Job<crate::lower::types::Vl> for DynamicBlueprint {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::types::Vl> {
        let lx = &self.lx;
        let env = &self.env;
        let x = &self.x;
        let d = &self.d;
        let variant = &self.variant;
        let t = &self.t;
        match (get(&env.names, &Text::from(format!("#dyn{}", &crate::lower::node_::static_::dyn_key(x)))), get(&env.names, &Text::lit("#owner"))) {
            (Some(crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(getter), _, dt)), Some(crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(owner), _, _))) => {
                let d = d.clone();
                let env = env.clone();
                let lx = lx.clone();
                let t = t.clone();
                let variant = variant.clone();
                call_then(start_value_of(lx.clone(), crate::lower::node_::def::init_env(&env), d.clone()), move |value_of_19050: crate::lower::types::Vl| {
                    let at_build = crate::lower::types::own(&value_of_19050);
                    let arms = Array::from(vec![crate::lower::model::XArm { pat: crate::lower::model::Pa::PaCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("owner"))])), conds: Array::new(), body: crate::lower::model::Ex::XCtor(variant.clone(), Array::from(vec![crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("owner"))), getter.clone(), Array::from(vec![crate::lower::model::Ex::XCx]))])) }, crate::lower::model::XArm { pat: crate::lower::model::Pa::PaUnit(Text::lit("None")), conds: Array::new(), body: crate::lower::model::Ex::XCtor(variant.clone(), Array::from(vec![crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(Text::lit("at_build"))))])) }]);
                    let read = crate::lower::model::Ex::XClosure(true, Array::from(vec![crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaBind(Text::lit("cx"))), crate::lower::model::OutTy::OutRef(Rc::new(crate::lower::model::OutTy::OutNamed(Text::lit("Cx"), Array::new()))))]), Rc::new(crate::lower::model::Ex::XMatch(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("link"))), Text::lit("owner"), Array::new())), arms.clone(), false, crate::lower::model::OutTy::OutNamed(Text::lit("crate::Answer"), Array::new()))));
                    let dynamic = crate::lower::model::Ex::XBlock(Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(Text::lit("link")), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(owner.clone())))), crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(Text::lit("at_build")), at_build.clone())]), Rc::new(crate::lower::model::Ex::XCall(Text::lit("prism_rtl::Dynamic::of"), Array::from(vec![read.clone(), crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XVar(Text::from(format!("{}_port", &getter)))))]))));
                    prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCall(Text::lit("prism_rtl::dynamic_blueprint::<crate::Elem, _>"), Array::from(vec![dynamic.clone()])), t.clone()))
                })
            },
            _ => prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(refusal(&Text::from(format!("`@ {}`, a supplier\'s dynamic answer that reads what has no value at the owner\'s build (a pushed place, a structural dynamic, or a `let` after the host\'s line)", &crate::lower::functions::src_text(lx, &lx.file, &x.span)))), t.clone())),
        }
    }
}

/// `Start DynamicBlueprint, x`: what the function value is when passed to `@Run`.
pub fn start_dynamic_blueprint_(lx: crate::lower::Lx, env: crate::lower::types::Env, x: crate::syntax::Expr, d: crate::syntax::Expr, variant: Text, t: crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<crate::lower::types::Vl>> {
    Rc::new(DynamicBlueprint { lx, env, x, d, variant, t })
}

/// ```prism
/// ElementBlueprint: unbounded fn Lx, Env, [Arg], OutTy -> Vl
/// ```
pub fn element_blueprint_(lx: &crate::lower::Lx, env: &crate::lower::types::Env, args: &Array<crate::syntax::Arg>, t: &crate::lower::model::OutTy) -> crate::lower::types::Vl {
    match index(args, &Nat::from(0u32)) {
        Some(a) => crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCall(Text::lit("prism_rtl::element_blueprint::<crate::Elem, crate::Answer>"), Array::from(vec![crate::lower::types::ref_(&value_of(lx, env, &a.value))])), t.clone()),
        None => crate::lower::types::Vl::VlOwned(refusal(&Text::lit("`@Element` without its element")), t.clone()),
    }
}

/// The step machine of `ElementBlueprint`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ElementBlueprint: unbounded fn Lx, Env, [Arg], OutTy -> Vl
/// ```
pub struct ElementBlueprint {
    pub lx: crate::lower::Lx,
    pub env: crate::lower::types::Env,
    pub args: Array<crate::syntax::Arg>,
    pub t: crate::lower::model::OutTy,
}

impl prism_rtl::Job<crate::lower::types::Vl> for ElementBlueprint {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::types::Vl> {
        let lx = &self.lx;
        let env = &self.env;
        let args = &self.args;
        let t = &self.t;
        match index(args, &Nat::from(0u32)) {
            Some(a) => {
                let env = env.clone();
                let lx = lx.clone();
                let t = t.clone();
                call_then(start_value_of(lx.clone(), env.clone(), a.value.clone()), move |value_of_20333: crate::lower::types::Vl| prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCall(Text::lit("prism_rtl::element_blueprint::<crate::Elem, crate::Answer>"), Array::from(vec![crate::lower::types::ref_(&value_of_20333)])), t.clone())))
            },
            None => prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(refusal(&Text::lit("`@Element` without its element")), t.clone())),
        }
    }
}

/// `Start ElementBlueprint, x`: what the function value is when passed to `@Run`.
pub fn start_element_blueprint_(lx: crate::lower::Lx, env: crate::lower::types::Env, args: Array<crate::syntax::Arg>, t: crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<crate::lower::types::Vl>> {
    Rc::new(ElementBlueprint { lx, env, args, t })
}

/// ```prism
/// KindWords: fn ExprKind -> Text
/// ```
pub fn kind_words(k: &crate::syntax::ExprKind) -> Text {
    match k {
        crate::syntax::ExprKind::ESuffixed(op, _, _, _) => Text::from(format!("a suffixed `{}`", op)),
        crate::syntax::ExprKind::EFreeSigil(sg, _) => Text::from(format!("a free `{}`", sg)),
        crate::syntax::ExprKind::ETopicField(_) => Text::lit("a topic field (`&_.f` outside an `update`)"),
        crate::syntax::ExprKind::ETopicIndex(_) => Text::lit("a topic index"),
        crate::syntax::ExprKind::ENonEmpty(_) => Text::lit("a non-empty literal"),
        crate::syntax::ExprKind::EAbsent => Text::lit("an absent value"),
        crate::syntax::ExprKind::ERest => Text::lit("a `..` rest"),
        crate::syntax::ExprKind::ELambda(_, _) => Text::lit("a lambda"),
        crate::syntax::ExprKind::ERebuild(_, _) => Text::lit("a `rebuild` outside a widget block"),
        crate::syntax::ExprKind::EFor(_, _, _) => Text::lit("a `for` outside a widget block"),
        crate::syntax::ExprKind::EWidgetBlock(_) => Text::lit("a widget block"),
        crate::syntax::ExprKind::EMonad(_, _) => Text::lit("a monadic block"),
        crate::syntax::ExprKind::ELens(_) => Text::lit("a lens"),
        crate::syntax::ExprKind::EError => Text::lit("an expression the parser could not read"),
        _ => Text::lit("an expression"),
    }
}

/// ```prism
/// NameValue: unbounded fn Lx, Env, SName, Range -> Vl
/// ```
pub fn name_value(lx: &crate::lower::Lx, env: &crate::lower::types::Env, n: &crate::syntax::SName, span: &crate::syntax::Range) -> crate::lower::types::Vl {
    let nkey = crate::lower::types::name_key_at(lx, env, n, span);
    let t = crate::lower::types::out_ty_of(lx, &crate::lower::types::peel(&crate::lower::type_at(lx, span)));
    let local_opt = if &len(&n.path_) == &Nat::from(1u32) { get(&env.names, &nkey) } else { None };
    match &local_opt {
        Some(crate::lower::types::Bn::BnLocal(rs, mode, lt)) => crate::lower::types::local_place(rs, mode, lt),
        Some(crate::lower::types::Bn::BnHold(f, ht)) => crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", f)))), Text::lit("get"), Array::from(vec![crate::lower::model::Ex::XCx])), ht.clone()),
        Some(crate::lower::types::Bn::BnDyn(x, _, dt)) => crate::lower::types::Vl::VlOwned(x.clone(), dt.clone()),
        Some(crate::lower::types::Bn::BnEv(_, et)) => match get(&env.names, &Text::from(format!("{}#port", &nkey))) {
            Some(crate::lower::types::Bn::BnLocal(pf, _, _)) => crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCall(Text::lit("prism_rtl::Event::of"), Array::from(vec![crate::lower::model::Ex::XRef(Rc::new(pf))])), crate::lower::model::OutTy::OutEvent(Rc::new(crate::lower::types::out_ty_of(lx, &crate::lower::types::peel(&crate::lower::types::peel(&crate::lower::type_at(lx, span))))))),
            _ => crate::lower::types::Vl::VlOwned(refusal(&Text::lit("an event read as a value")), et.clone()),
        },
        Some(crate::lower::types::Bn::BnParts(_)) => crate::lower::types::Vl::VlOwned(refusal(&Text::lit("a tuple pattern\'s binding as a value")), t.clone()),
        Some(crate::lower::types::Bn::BnWidget(_, _, _, _)) => crate::lower::types::Vl::VlOwned(refusal(&Text::lit("a widget parameter read as a plain value")), t.clone()),
        Some(crate::lower::types::Bn::BnLocalFn(_)) => crate::lower::types::Vl::VlOwned(refusal(&Text::lit("a local function as a value")), t.clone()),
        None => {
            let (qk_opt, why) = crate::check::env::names::resolve_value(&lx.g, &lx.home, n);
            match &qk_opt {
                Some(m22409_0) if (m22409_0 == &Text::lit("True")) => crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XBool(true), crate::lower::model::OutTy::OutBool),
                Some(m22409_1) if (m22409_1 == &Text::lit("False")) => crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XBool(false), crate::lower::model::OutTy::OutBool),
                Some(m22409_2) if (m22409_2 == &Text::lit("Prelude.never")) => crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCall(Text::lit("Event::never"), Array::new()), t.clone()),
                Some(qk) => match get(&lx.g.tags, qk) {
                    Some(tg) if ((&tg.kind != &Text::lit("Prelude.Fault")) && (&why == &Text::lit("tag"))) => tag_value(lx, env, &tg, &Array::new()),
                    _ => global_value(lx, qk, span, &t),
                    _ => unreachable!("no arm matched"),
                },
                None => crate::lower::types::Vl::VlOwned(refusal(&Text::from(format!("the name {}, which nothing declares", &nkey))), t.clone()),
                _ => unreachable!("no arm matched"),
            }
        },
    }
}

/// The step machine of `NameValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// NameValue: unbounded fn Lx, Env, SName, Range -> Vl
/// ```
pub struct NameValue {
    pub lx: crate::lower::Lx,
    pub env: crate::lower::types::Env,
    pub n: crate::syntax::SName,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<crate::lower::types::Vl> for NameValue {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::types::Vl> {
        let lx = &self.lx;
        let env = &self.env;
        let n = &self.n;
        let span = &self.span;
        let nkey = crate::lower::types::name_key_at(lx, env, n, span);
        let env = env.clone();
        let lx = lx.clone();
        let n = n.clone();
        let span = span.clone();
        call_then(crate::lower::types::start_out_ty_of(lx.clone(), crate::lower::types::peel(&crate::lower::type_at(&lx, &span))), move |out_ty_of_21439: crate::lower::model::OutTy| {
            let t = out_ty_of_21439;
            let local_opt = if &len(&n.path_) == &Nat::from(1u32) { get(&env.names, &nkey) } else { None };
            match &local_opt {
                Some(crate::lower::types::Bn::BnLocal(rs, mode, lt)) => prism_rtl::Turn::Finished(crate::lower::types::local_place(rs, mode, lt)),
                Some(crate::lower::types::Bn::BnHold(f, ht)) => prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", f)))), Text::lit("get"), Array::from(vec![crate::lower::model::Ex::XCx])), ht.clone())),
                Some(crate::lower::types::Bn::BnDyn(x, _, dt)) => prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(x.clone(), dt.clone())),
                Some(crate::lower::types::Bn::BnEv(_, et)) => match get(&env.names, &Text::from(format!("{}#port", &nkey))) {
                    Some(crate::lower::types::Bn::BnLocal(pf, _, _)) => call_then(crate::lower::types::start_out_ty_of(lx.clone(), crate::lower::types::peel(&crate::lower::types::peel(&crate::lower::type_at(&lx, &span)))), move |out_ty_of_21919: crate::lower::model::OutTy| prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCall(Text::lit("prism_rtl::Event::of"), Array::from(vec![crate::lower::model::Ex::XRef(Rc::new(pf.clone()))])), crate::lower::model::OutTy::OutEvent(Rc::new(out_ty_of_21919))))),
                    _ => prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(refusal(&Text::lit("an event read as a value")), et.clone())),
                },
                Some(crate::lower::types::Bn::BnParts(_)) => prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(refusal(&Text::lit("a tuple pattern\'s binding as a value")), t.clone())),
                Some(crate::lower::types::Bn::BnWidget(_, _, _, _)) => prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(refusal(&Text::lit("a widget parameter read as a plain value")), t.clone())),
                Some(crate::lower::types::Bn::BnLocalFn(_)) => prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(refusal(&Text::lit("a local function as a value")), t.clone())),
                None => {
                    let (qk_opt, why) = crate::check::env::names::resolve_value(&lx.g, &lx.home, &n);
                    match &qk_opt {
                        Some(m22409_0) if (m22409_0 == &Text::lit("True")) => prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XBool(true), crate::lower::model::OutTy::OutBool)),
                        Some(m22409_1) if (m22409_1 == &Text::lit("False")) => prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XBool(false), crate::lower::model::OutTy::OutBool)),
                        Some(m22409_2) if (m22409_2 == &Text::lit("Prelude.never")) => prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCall(Text::lit("Event::never"), Array::new()), t.clone())),
                        Some(qk) => match get(&lx.g.tags, qk) {
                            Some(tg) if ((&tg.kind != &Text::lit("Prelude.Fault")) && (&why == &Text::lit("tag"))) => prism_rtl::Turn::More(Rc::new(TagValue { lx: lx.clone(), env: env.clone(), tg: tg.clone(), args: Array::new() })),
                            _ => prism_rtl::Turn::More(Rc::new(GlobalValue { lx: lx.clone(), qk: qk.clone(), span: span.clone(), t: t.clone() })),
                            _ => unreachable!("no arm matched"),
                        },
                        None => prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(refusal(&Text::from(format!("the name {}, which nothing declares", &nkey))), t.clone())),
                        _ => unreachable!("no arm matched"),
                    }
                },
            }
        })
    }
}

/// `Start NameValue, x`: what the function value is when passed to `@Run`.
pub fn start_name_value(lx: crate::lower::Lx, env: crate::lower::types::Env, n: crate::syntax::SName, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<crate::lower::types::Vl>> {
    Rc::new(NameValue { lx, env, n, span })
}

/// ```prism
/// GlobalValue: unbounded fn Lx, Text, Range, OutTy -> Vl
/// ```
pub fn global_value(lx: &crate::lower::Lx, qk: &Text, span: &crate::syntax::Range, t: &crate::lower::model::OutTy) -> crate::lower::types::Vl {
    match get(&lx.g.ctors, qk) {
        Some(c) => {
            let arity = if &len(&c.fields) > &Nat::from(0u32) { len(&c.fields) } else { len(&c.args) };
            match t {
                crate::lower::model::OutTy::OutFn(pts, _) => if &arity > &Nat::from(0u32) {
                    ctor_fn(lx, &c, pts, span, t, &false)
                } else {
                    ctor_app(lx, &crate::lower::types::empty_env(), &c, &Array::new(), span)
                },
                crate::lower::model::OutTy::OutJobFn(a, _) => {
                    let pts = match &**a {
                        crate::lower::model::OutTy::OutTuple(ts) => if &arity == &Nat::from(1u32) { Array::from(vec![(**a).clone()]) } else { ts.clone() },
                        _ => Array::from(vec![(**a).clone()]),
                    };
                    if &arity > &Nat::from(0u32) {
                        ctor_fn(lx, &c, &pts, span, t, &true)
                    } else {
                        ctor_app(lx, &crate::lower::types::empty_env(), &c, &Array::new(), span)
                    }
                },
                _ => ctor_app(lx, &crate::lower::types::empty_env(), &c, &Array::new(), span),
            }
        },
        None => match get(&lx.g.tags, qk) {
            Some(tg) => crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XStr(tg.name.clone()), t.clone()),
            None => if fold(&lx.g.defs, &false, &(|f: &bool, d: &crate::check::env::Def| *f || ((&d.qk == qk) && is_let_def(d)))) {
                crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCall(crate::lower::value_path(lx, qk), Array::new()), t.clone())
            } else {
                match get(&lx.g.vals, qk) {
                    Some(v_) => {
                        let is_let = fold(&lx.g.defs, &false, &(|f: &bool, d: &crate::check::env::Def| *f || ((&d.qk == qk) && is_let_def(d))));
                        if is_let {
                            crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCall(crate::lower::value_path(lx, qk), Array::new()), t.clone())
                        } else {
                            match t {
                                crate::lower::model::OutTy::OutJobFn(a, _) => {
                                    let (ps, ignore2) = crate::lower::jobs::scheme_parts(lx, qk);
                                    let names = each(&crate::check::errors::range0(&len(&ps)), &(|i: &Nat| Text::from(format!("a{}", i))));
                                    let pa = if &len(&ps) == &Nat::from(1u32) {
                                        crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaBind(Text::lit("a0"))), (**a).clone())
                                    } else {
                                        crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaTuple(each(&names, &(|nm: &Text| crate::lower::model::Pa::PaBind(nm.clone()))))), (**a).clone())
                                    };
                                    let f = crate::lower::model::Ex::XClosure(false, Array::from(vec![pa.clone()]), Rc::new(crate::lower::model::Ex::XCall(Text::lit("entered"), Array::from(vec![crate::lower::model::Ex::XCall(start_path(lx, qk), each(&names, &(|nm: &Text| crate::lower::model::Ex::XVar(nm.clone()))))]))));
                                    crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCast(Rc::new(crate::lower::model::Ex::XCall(Text::lit("Rc::new"), Array::from(vec![f.clone()]))), t.clone()), t.clone())
                                },
                                _ => crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCall(Text::lit("Rc::new"), Array::from(vec![crate::lower::model::Ex::XPath(crate::lower::value_path(lx, qk))])), t.clone()),
                            }
                        }
                    },
                    None => crate::lower::types::Vl::VlOwned(refusal(&Text::from(format!("the global {}", qk))), t.clone()),
                }
            },
        },
    }
}

/// The step machine of `GlobalValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// GlobalValue: unbounded fn Lx, Text, Range, OutTy -> Vl
/// ```
pub struct GlobalValue {
    pub lx: crate::lower::Lx,
    pub qk: Text,
    pub span: crate::syntax::Range,
    pub t: crate::lower::model::OutTy,
}

impl prism_rtl::Job<crate::lower::types::Vl> for GlobalValue {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::types::Vl> {
        let lx = &self.lx;
        let qk = &self.qk;
        let span = &self.span;
        let t = &self.t;
        match get(&lx.g.ctors, qk) {
            Some(c) => {
                let arity = if &len(&c.fields) > &Nat::from(0u32) { len(&c.fields) } else { len(&c.args) };
                match t {
                    crate::lower::model::OutTy::OutFn(pts, _) => if &arity > &Nat::from(0u32) {
                        prism_rtl::Turn::More(Rc::new(CtorFn { lx: lx.clone(), c: c.clone(), pts: pts.clone(), span: span.clone(), t: t.clone(), job: false }))
                    } else {
                        prism_rtl::Turn::More(Rc::new(CtorApp { lx: lx.clone(), env: crate::lower::types::empty_env(), c: c.clone(), args: Array::new(), span: span.clone() }))
                    },
                    crate::lower::model::OutTy::OutJobFn(a, _) => {
                        let pts = match &**a {
                            crate::lower::model::OutTy::OutTuple(ts) => if &arity == &Nat::from(1u32) { Array::from(vec![(**a).clone()]) } else { ts.clone() },
                            _ => Array::from(vec![(**a).clone()]),
                        };
                        if &arity > &Nat::from(0u32) {
                            prism_rtl::Turn::More(Rc::new(CtorFn { lx: lx.clone(), c: c.clone(), pts: pts.clone(), span: span.clone(), t: t.clone(), job: true }))
                        } else {
                            prism_rtl::Turn::More(Rc::new(CtorApp { lx: lx.clone(), env: crate::lower::types::empty_env(), c: c.clone(), args: Array::new(), span: span.clone() }))
                        }
                    },
                    _ => prism_rtl::Turn::More(Rc::new(CtorApp { lx: lx.clone(), env: crate::lower::types::empty_env(), c: c.clone(), args: Array::new(), span: span.clone() })),
                }
            },
            None => match get(&lx.g.tags, qk) {
                Some(tg) => prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XStr(tg.name.clone()), t.clone())),
                None => if fold(&lx.g.defs, &false, &(|f: &bool, d: &crate::check::env::Def| *f || ((&d.qk == qk) && is_let_def(d)))) {
                    prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCall(crate::lower::value_path(lx, qk), Array::new()), t.clone()))
                } else {
                    match get(&lx.g.vals, qk) {
                        Some(v_) => {
                            let is_let = fold(&lx.g.defs, &false, &(|f: &bool, d: &crate::check::env::Def| *f || ((&d.qk == qk) && is_let_def(d))));
                            if is_let {
                                prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCall(crate::lower::value_path(lx, qk), Array::new()), t.clone()))
                            } else {
                                match t {
                                    crate::lower::model::OutTy::OutJobFn(a, _) => {
                                        let (ps, ignore2) = crate::lower::jobs::scheme_parts(lx, qk);
                                        let names = each(&crate::check::errors::range0(&len(&ps)), &(|i: &Nat| Text::from(format!("a{}", i))));
                                        let pa = if &len(&ps) == &Nat::from(1u32) {
                                            crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaBind(Text::lit("a0"))), (**a).clone())
                                        } else {
                                            crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaTuple(each(&names, &(|nm: &Text| crate::lower::model::Pa::PaBind(nm.clone()))))), (**a).clone())
                                        };
                                        let f = crate::lower::model::Ex::XClosure(false, Array::from(vec![pa.clone()]), Rc::new(crate::lower::model::Ex::XCall(Text::lit("entered"), Array::from(vec![crate::lower::model::Ex::XCall(start_path(lx, qk), each(&names, &(|nm: &Text| crate::lower::model::Ex::XVar(nm.clone()))))]))));
                                        prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCast(Rc::new(crate::lower::model::Ex::XCall(Text::lit("Rc::new"), Array::from(vec![f.clone()]))), t.clone()), t.clone()))
                                    },
                                    _ => prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCall(Text::lit("Rc::new"), Array::from(vec![crate::lower::model::Ex::XPath(crate::lower::value_path(lx, qk))])), t.clone())),
                                }
                            }
                        },
                        None => prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(refusal(&Text::from(format!("the global {}", qk))), t.clone())),
                    }
                },
            },
        }
    }
}

/// `Start GlobalValue, x`: what the function value is when passed to `@Run`.
pub fn start_global_value(lx: crate::lower::Lx, qk: Text, span: crate::syntax::Range, t: crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<crate::lower::types::Vl>> {
    Rc::new(GlobalValue { lx, qk, span, t })
}

/// ```prism
/// IsLetDef: fn Def -> Bool
/// ```
pub fn is_let_def(d: &crate::check::env::Def) -> bool {
    match &d.body {
        crate::check::env::DefBody::DbLet(_) => true,
        _ => false,
    }
}

/// ```prism
/// StartPath: fn Lx, Text -> Text
/// ```
pub fn start_path(lx: &crate::lower::Lx, qk: &Text) -> Text {
    let owner = match get(&lx.g.vals, qk) {
        Some(v_) => v_.home.clone(),
        None => crate::lower::owner_of(qk),
    };
    crate::lower::path_in(lx, &owner, &Text::from(format!("start_{}", &or(&get(&lx.rs_names, qk), &crate::lower::snake(&crate::check::types::bare_name(qk))))))
}

/// ```prism
/// Application: unbounded fn Lx, Env, Expr, [Arg], Range -> Vl
/// ```
pub fn application(lx: &crate::lower::Lx, env: &crate::lower::types::Env, callee: &crate::syntax::Expr, args: &Array<crate::syntax::Arg>, span: &crate::syntax::Range) -> crate::lower::types::Vl {
    let t = crate::lower::types::out_ty_of(lx, &crate::lower::types::peel(&crate::lower::type_at(lx, span)));
    match &*callee.kind {
        crate::syntax::ExprKind::EName(n) => {
            let nkey = crate::lower::types::name_key_at(lx, env, n, &callee.span);
            let local_opt = if &len(&n.path_) == &Nat::from(1u32) { get(&env.names, &nkey) } else { None };
            match &local_opt {
                Some(crate::lower::types::Bn::BnLocalFn(c)) => inline_local_fn(lx, env, c, args, &t),
                Some(b) => {
                    let f = name_value(lx, env, n, &callee.span);
                    match crate::lower::types::value_ty(&f) {
                        crate::lower::model::OutTy::OutJobFn(_, _) => crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCall(Text::lit("run_to_end"), Array::from(vec![crate::lower::jobs::start_call(&f, &start_args(lx, env, &f, args))])), t.clone()),
                        _ => crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XApply(Rc::new(crate::lower::types::ref_(&f)), run_to_end(each_job(args.clone(), {
                            let lx = lx.clone();
                            let env = env.clone();
                            Rc::new(move |p0: crate::syntax::Arg| {
                                let lx = lx.clone();
                                let env = env.clone();
                                entered(once_job(move || {
                                    let a = p0;
                                    prism_rtl::Turn::More(Rc::new(Argument { lx: lx.clone(), env: env.clone(), e: a.value.clone() }))
                                }))
                            }) as Rc<dyn Fn(crate::syntax::Arg) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
                        }))), t.clone()),
                    }
                },
                None => {
                    let (qk_opt, why) = crate::check::env::names::resolve_value(&lx.g, &lx.home, n);
                    match &qk_opt {
                        Some(qk) => match get(&lx.g.tags, qk) {
                            Some(tg) if (&why == &Text::lit("tag")) => tag_value(lx, env, &tg, args),
                            _ => if qk == &Text::lit("Prelude.@Element") {
                                element_blueprint_(lx, env, args, &t)
                            } else {
                                global_call(lx, env, qk, args, span, &t)
                            },
                            _ => unreachable!("no arm matched"),
                        },
                        None => crate::lower::types::Vl::VlOwned(refusal(&Text::from(format!("a call of {}, which nothing declares", &nkey))), t.clone()),
                    }
                },
            }
        },
        crate::syntax::ExprKind::EGroup(x) => application(lx, env, &**x, args, span),
        _ => {
            let f = value_of(lx, env, callee);
            match crate::lower::types::value_ty(&f) {
                crate::lower::model::OutTy::OutJobFn(_, _) => crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCall(Text::lit("run_to_end"), Array::from(vec![crate::lower::jobs::start_call(&f, &start_args(lx, env, &f, args))])), t.clone()),
                _ => crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XApply(Rc::new(crate::lower::types::ref_(&f)), run_to_end(each_job(args.clone(), {
                    let lx = lx.clone();
                    let env = env.clone();
                    Rc::new(move |p0: crate::syntax::Arg| {
                        let lx = lx.clone();
                        let env = env.clone();
                        entered(once_job(move || {
                            let a = p0;
                            prism_rtl::Turn::More(Rc::new(Argument { lx: lx.clone(), env: env.clone(), e: a.value.clone() }))
                        }))
                    }) as Rc<dyn Fn(crate::syntax::Arg) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
                }))), t.clone()),
            }
        },
    }
}

/// The step machine of `Application`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Application: unbounded fn Lx, Env, Expr, [Arg], Range -> Vl
/// ```
pub struct Application {
    pub lx: crate::lower::Lx,
    pub env: crate::lower::types::Env,
    pub callee: crate::syntax::Expr,
    pub args: Array<crate::syntax::Arg>,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<crate::lower::types::Vl> for Application {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::types::Vl> {
        let lx = &self.lx;
        let env = &self.env;
        let callee = &self.callee;
        let args = &self.args;
        let span = &self.span;
        let args = args.clone();
        let callee = callee.clone();
        let env = env.clone();
        let lx = lx.clone();
        let span = span.clone();
        call_then(crate::lower::types::start_out_ty_of(lx.clone(), crate::lower::types::peel(&crate::lower::type_at(&lx, &span))), move |out_ty_of_25310: crate::lower::model::OutTy| {
            let t = out_ty_of_25310;
            match &*callee.kind {
                crate::syntax::ExprKind::EName(n) => {
                    let nkey = crate::lower::types::name_key_at(&lx, &env, n, &callee.span);
                    let local_opt = if &len(&n.path_) == &Nat::from(1u32) { get(&env.names, &nkey) } else { None };
                    match &local_opt {
                        Some(crate::lower::types::Bn::BnLocalFn(c)) => prism_rtl::Turn::More(Rc::new(InlineLocalFn { lx: lx.clone(), env: env.clone(), c: c.clone(), args: args.clone(), t: t.clone() })),
                        Some(b) => {
                            let n = n.clone();
                            call_then(start_name_value(lx.clone(), env.clone(), n.clone(), callee.span.clone()), move |name_value_25659: crate::lower::types::Vl| {
                                let f = name_value_25659;
                                match crate::lower::types::value_ty(&f) {
                                    crate::lower::model::OutTy::OutJobFn(_, _) => call_then(start_start_args(lx.clone(), env.clone(), f.clone(), args.clone()), move |start_args_25853: Array<crate::lower::model::Ex>| prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCall(Text::lit("run_to_end"), Array::from(vec![crate::lower::jobs::start_call(&f, &start_args_25853)])), t.clone()))),
                                    _ => call_value(each_job(args.clone(), {
                                        let lx = lx.clone();
                                        let env = env.clone();
                                        Rc::new(move |p0: crate::syntax::Arg| {
                                            let lx = lx.clone();
                                            let env = env.clone();
                                            entered(once_job(move || {
                                                let a = p0;
                                                prism_rtl::Turn::More(Rc::new(Argument { lx: lx.clone(), env: env.clone(), e: a.value.clone() }))
                                            }))
                                        }) as Rc<dyn Fn(crate::syntax::Arg) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
                                    }), move |each_25949: Array<crate::lower::model::Ex>| prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XApply(Rc::new(crate::lower::types::ref_(&f)), each_25949), t.clone()))),
                                }
                            })
                        },
                        None => {
                            let (qk_opt, why) = crate::check::env::names::resolve_value(&lx.g, &lx.home, n);
                            match &qk_opt {
                                Some(qk) => match get(&lx.g.tags, qk) {
                                    Some(tg) if (&why == &Text::lit("tag")) => prism_rtl::Turn::More(Rc::new(TagValue { lx: lx.clone(), env: env.clone(), tg: tg.clone(), args: args.clone() })),
                                    _ => if qk == &Text::lit("Prelude.@Element") {
                                        prism_rtl::Turn::More(Rc::new(ElementBlueprint { lx: lx.clone(), env: env.clone(), args: args.clone(), t: t.clone() }))
                                    } else {
                                        prism_rtl::Turn::More(Rc::new(GlobalCall { lx: lx.clone(), env: env.clone(), qk: qk.clone(), args: args.clone(), span: span.clone(), t: t.clone() }))
                                    },
                                    _ => unreachable!("no arm matched"),
                                },
                                None => prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(refusal(&Text::from(format!("a call of {}, which nothing declares", &nkey))), t.clone())),
                            }
                        },
                    }
                },
                crate::syntax::ExprKind::EGroup(x) => prism_rtl::Turn::More(Rc::new(Application { lx: lx.clone(), env: env.clone(), callee: (**x).clone(), args: args.clone(), span: span.clone() })),
                _ => call_then(start_value_of(lx.clone(), env.clone(), callee.clone()), move |value_of_26772: crate::lower::types::Vl| {
                    let f = value_of_26772;
                    match crate::lower::types::value_ty(&f) {
                        crate::lower::model::OutTy::OutJobFn(_, _) => call_then(start_start_args(lx.clone(), env.clone(), f.clone(), args.clone()), move |start_args_26912: Array<crate::lower::model::Ex>| prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCall(Text::lit("run_to_end"), Array::from(vec![crate::lower::jobs::start_call(&f, &start_args_26912)])), t.clone()))),
                        _ => call_value(each_job(args.clone(), {
                            let lx = lx.clone();
                            let env = env.clone();
                            Rc::new(move |p0: crate::syntax::Arg| {
                                let lx = lx.clone();
                                let env = env.clone();
                                entered(once_job(move || {
                                    let a = p0;
                                    prism_rtl::Turn::More(Rc::new(Argument { lx: lx.clone(), env: env.clone(), e: a.value.clone() }))
                                }))
                            }) as Rc<dyn Fn(crate::syntax::Arg) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
                        }), move |each_27000: Array<crate::lower::model::Ex>| prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XApply(Rc::new(crate::lower::types::ref_(&f)), each_27000), t.clone()))),
                    }
                }),
            }
        })
    }
}

/// `Start Application, x`: what the function value is when passed to `@Run`.
pub fn start_application(lx: crate::lower::Lx, env: crate::lower::types::Env, callee: crate::syntax::Expr, args: Array<crate::syntax::Arg>, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<crate::lower::types::Vl>> {
    Rc::new(Application { lx, env, callee, args, span })
}

/// ```prism
/// InlineLocalFn: unbounded fn Lx, Env, FnClause, [Arg], OutTy -> Vl
/// ```
pub fn inline_local_fn(lx: &crate::lower::Lx, env: &crate::lower::types::Env, c: &crate::syntax::decls::FnClause, args: &Array<crate::syntax::Arg>, t: &crate::lower::model::OutTy) -> crate::lower::types::Vl {
    let names = each(&c.params, &(|p_: &crate::syntax::Pattern_| crate::lower::functions::plain_binder(lx, p_)));
    if fold(&names, &false, &(|bad: &bool, nm: &Text| *bad || (nm == &Text::lit("")))) {
        crate::lower::types::Vl::VlOwned(refusal(&Text::lit("a local function whose parameters are not names")), t.clone())
    } else {
        {
            let (dos, env2) = run_to_end(fold_job(crate::check::errors::range0(&len(&names)), (Array::new(), env.clone()), {
                let names = names.clone();
                let lx = lx.clone();
                let c = c.clone();
                let args = args.clone();
                let env = env.clone();
                Rc::new(move |(p0, p1): ((Array<crate::lower::model::Do>, crate::lower::types::Env), Nat)| {
                    let names = names.clone();
                    let lx = lx.clone();
                    let c = c.clone();
                    let args = args.clone();
                    let env = env.clone();
                    entered(once_job(move || {
                        let (acc, en) = p0;
                        let i = p1;
                        {
                            let nm = or(&index(&names, &i), &Text::lit(""));
                            let rs = Text::from(format!("{}_{}", &crate::lower::local_name(&lx, &nm), &c.span.start));
                            let v_ = match index(&args, &i) {
                                Some(a) => value_of(&lx, &env, &a.value),
                                None => crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XUnit, crate::lower::model::OutTy::OutUnit),
                            };
                            let bt = crate::lower::types::value_ty(&v_);
                            prism_rtl::Turn::Finished((push(&acc, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(rs.clone()), crate::lower::types::own(&v_))), crate::lower::types::bind(&en, &nm, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(rs.clone()), crate::lower::types::Holding::Owned, bt.clone()))))
                        }
                    }))
                }) as Rc<dyn Fn(((Array<crate::lower::model::Do>, crate::lower::types::Env), Nat)) -> Rc<dyn prism_rtl::Job<(Array<crate::lower::model::Do>, crate::lower::types::Env)>>>
            }));
            crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XBlock(dos.clone(), Rc::new(crate::lower::functions::fn_body_value(lx, &env2, &c.body))), t.clone())
        }
    }
}

/// The step machine of `InlineLocalFn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InlineLocalFn: unbounded fn Lx, Env, FnClause, [Arg], OutTy -> Vl
/// ```
pub struct InlineLocalFn {
    pub lx: crate::lower::Lx,
    pub env: crate::lower::types::Env,
    pub c: crate::syntax::decls::FnClause,
    pub args: Array<crate::syntax::Arg>,
    pub t: crate::lower::model::OutTy,
}

impl prism_rtl::Job<crate::lower::types::Vl> for InlineLocalFn {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::types::Vl> {
        let lx = &self.lx;
        let env = &self.env;
        let c = &self.c;
        let args = &self.args;
        let t = &self.t;
        let names = each(&c.params, &(|p_: &crate::syntax::Pattern_| crate::lower::functions::plain_binder(lx, p_)));
        if fold(&names, &false, &(|bad: &bool, nm: &Text| *bad || (nm == &Text::lit("")))) {
            prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(refusal(&Text::lit("a local function whose parameters are not names")), t.clone()))
        } else {
            {
                let args = args.clone();
                let c = c.clone();
                let env = env.clone();
                let lx = lx.clone();
                let t = t.clone();
                call_value(fold_job(crate::check::errors::range0(&len(&names)), (Array::new(), env.clone()), {
                    let names = names.clone();
                    let lx = lx.clone();
                    let c = c.clone();
                    let args = args.clone();
                    let env = env.clone();
                    Rc::new(move |(p0, p1): ((Array<crate::lower::model::Do>, crate::lower::types::Env), Nat)| {
                        let names = names.clone();
                        let lx = lx.clone();
                        let c = c.clone();
                        let args = args.clone();
                        let env = env.clone();
                        entered(once_job(move || {
                            let (acc, en) = p0;
                            let i = p1;
                            {
                                let nm = or(&index(&names, &i), &Text::lit(""));
                                let rs = Text::from(format!("{}_{}", &crate::lower::local_name(&lx, &nm), &c.span.start));
                                let v_ = match index(&args, &i) {
                                    Some(a) => value_of(&lx, &env, &a.value),
                                    None => crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XUnit, crate::lower::model::OutTy::OutUnit),
                                };
                                let bt = crate::lower::types::value_ty(&v_);
                                prism_rtl::Turn::Finished((push(&acc, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(rs.clone()), crate::lower::types::own(&v_))), crate::lower::types::bind(&en, &nm, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(rs.clone()), crate::lower::types::Holding::Owned, bt.clone()))))
                            }
                        }))
                    }) as Rc<dyn Fn(((Array<crate::lower::model::Do>, crate::lower::types::Env), Nat)) -> Rc<dyn prism_rtl::Job<(Array<crate::lower::model::Do>, crate::lower::types::Env)>>>
                }), move |fold_27586: (Array<crate::lower::model::Do>, crate::lower::types::Env)| {
                    let (dos, env2) = fold_27586;
                    call_then(crate::lower::functions::start_fn_body_value(lx.clone(), env2.clone(), c.body.clone()), move |fn_body_value_28032: crate::lower::model::Ex| prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XBlock(dos.clone(), Rc::new(fn_body_value_28032)), t.clone())))
                })
            }
        }
    }
}

/// `Start InlineLocalFn, x`: what the function value is when passed to `@Run`.
pub fn start_inline_local_fn(lx: crate::lower::Lx, env: crate::lower::types::Env, c: crate::syntax::decls::FnClause, args: Array<crate::syntax::Arg>, t: crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<crate::lower::types::Vl>> {
    Rc::new(InlineLocalFn { lx, env, c, args, t })
}

/// ```prism
/// Argument: unbounded fn Lx, Env, Expr -> Ex
/// ```
pub fn argument(lx: &crate::lower::Lx, env: &crate::lower::types::Env, e: &crate::syntax::Expr) -> crate::lower::model::Ex {
    match get(&env.spans, &crate::lower::place_key(lx, &e.span)) {
        Some(v_) => crate::lower::types::ref_(&v_),
        None => argument_by_kind(lx, env, e),
    }
}

/// The step machine of `Argument`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Argument: unbounded fn Lx, Env, Expr -> Ex
/// ```
pub struct Argument {
    pub lx: crate::lower::Lx,
    pub env: crate::lower::types::Env,
    pub e: crate::syntax::Expr,
}

impl prism_rtl::Job<crate::lower::model::Ex> for Argument {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::Ex> {
        let lx = &self.lx;
        let env = &self.env;
        let e = &self.e;
        match get(&env.spans, &crate::lower::place_key(lx, &e.span)) {
            Some(v_) => prism_rtl::Turn::Finished(crate::lower::types::ref_(&v_)),
            None => prism_rtl::Turn::More(Rc::new(ArgumentByKind { lx: lx.clone(), env: env.clone(), e: e.clone() })),
        }
    }
}

/// `Start Argument, x`: what the function value is when passed to `@Run`.
pub fn start_argument(lx: crate::lower::Lx, env: crate::lower::types::Env, e: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>> {
    Rc::new(Argument { lx, env, e })
}

/// ```prism
/// ArgumentByKind: unbounded fn Lx, Env, Expr -> Ex
/// ```
pub fn argument_by_kind(lx: &crate::lower::Lx, env: &crate::lower::types::Env, e: &crate::syntax::Expr) -> crate::lower::model::Ex {
    match &*e.kind {
        crate::syntax::ExprKind::ELambda(ps_opt, body) => crate::lower::model::Ex::XRef(Rc::new(lambda_arg(lx, env, &or(ps_opt, &Array::new()), &**body, &lambda_param_tys(lx, e, &len(&or(ps_opt, &Array::new())))))),
        crate::syntax::ExprKind::EGroup(x) => argument(lx, env, &**x),
        crate::syntax::ExprKind::EName(n) => {
            let t = crate::lower::type_at(lx, &e.span);
            match crate::lower::types::peel(&t) {
                crate::check::types::Ty::TyFn(crate::check::types::Col::CBound, _, _) => {
                    let local_opt = if &len(&n.path_) == &Nat::from(1u32) {
                        get(&env.names, &crate::lower::types::name_key_at(lx, env, n, &e.span))
                    } else {
                        None
                    };
                    match &local_opt {
                        Some(_) => closure_ref(&value_of(lx, env, e)),
                        None => {
                            let (qk_opt, _) = crate::check::env::names::resolve_value(&lx.g, &lx.home, n);
                            match &qk_opt {
                                Some(qk) => if crate::check::env::has_key(&lx.g.ctors, qk) {
                                    closure_ref(&value_of(lx, env, e))
                                } else {
                                    crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XPath(crate::lower::value_path(lx, qk))))
                                },
                                None => crate::lower::types::ref_(&value_of(lx, env, e)),
                            }
                        },
                    }
                },
                _ => crate::lower::types::ref_(&value_of(lx, env, e)),
            }
        },
        _ => crate::lower::types::ref_(&value_of(lx, env, e)),
    }
}

/// The step machine of `ArgumentByKind`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ArgumentByKind: unbounded fn Lx, Env, Expr -> Ex
/// ```
pub struct ArgumentByKind {
    pub lx: crate::lower::Lx,
    pub env: crate::lower::types::Env,
    pub e: crate::syntax::Expr,
}

impl prism_rtl::Job<crate::lower::model::Ex> for ArgumentByKind {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::Ex> {
        let lx = &self.lx;
        let env = &self.env;
        let e = &self.e;
        match &*e.kind {
            crate::syntax::ExprKind::ELambda(ps_opt, body) => {
                let ps_opt = ps_opt.clone();
                let body = (**body).clone();
                let e = e.clone();
                let env = env.clone();
                let lx = lx.clone();
                call_then(start_lambda_param_tys(lx.clone(), e.clone(), len(&or(&ps_opt, &Array::new()))), move |lambda_param_tys_28470: Array<crate::lower::model::OutTy>| call_then(start_lambda_arg(lx.clone(), env.clone(), or(&ps_opt, &Array::new()), body.clone(), lambda_param_tys_28470), move |lambda_arg_28428: crate::lower::model::Ex| prism_rtl::Turn::Finished(crate::lower::model::Ex::XRef(Rc::new(lambda_arg_28428)))))
            },
            crate::syntax::ExprKind::EGroup(x) => prism_rtl::Turn::More(Rc::new(Argument { lx: lx.clone(), env: env.clone(), e: (**x).clone() })),
            crate::syntax::ExprKind::EName(n) => {
                let t = crate::lower::type_at(lx, &e.span);
                match crate::lower::types::peel(&t) {
                    crate::check::types::Ty::TyFn(crate::check::types::Col::CBound, _, _) => {
                        let local_opt = if &len(&n.path_) == &Nat::from(1u32) {
                            get(&env.names, &crate::lower::types::name_key_at(lx, env, n, &e.span))
                        } else {
                            None
                        };
                        match &local_opt {
                            Some(_) => {
                                let e = e.clone();
                                let env = env.clone();
                                let lx = lx.clone();
                                call_then(start_value_of(lx.clone(), env.clone(), e.clone()), move |value_of_28832: crate::lower::types::Vl| prism_rtl::Turn::Finished(closure_ref(&value_of_28832)))
                            },
                            None => {
                                let (qk_opt, _) = crate::check::env::names::resolve_value(&lx.g, &lx.home, n);
                                match &qk_opt {
                                    Some(qk) => if crate::check::env::has_key(&lx.g.ctors, qk) {
                                        {
                                            let e = e.clone();
                                            let env = env.clone();
                                            let lx = lx.clone();
                                            call_then(start_value_of(lx.clone(), env.clone(), e.clone()), move |value_of_29060: crate::lower::types::Vl| prism_rtl::Turn::Finished(closure_ref(&value_of_29060)))
                                        }
                                    } else {
                                        prism_rtl::Turn::Finished(crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XPath(crate::lower::value_path(lx, qk)))))
                                    },
                                    None => {
                                        let e = e.clone();
                                        let env = env.clone();
                                        let lx = lx.clone();
                                        call_then(start_value_of(lx.clone(), env.clone(), e.clone()), move |value_of_29156: crate::lower::types::Vl| prism_rtl::Turn::Finished(crate::lower::types::ref_(&value_of_29156)))
                                    },
                                }
                            },
                        }
                    },
                    _ => {
                        let e = e.clone();
                        let env = env.clone();
                        let lx = lx.clone();
                        call_then(start_value_of(lx.clone(), env.clone(), e.clone()), move |value_of_29204: crate::lower::types::Vl| prism_rtl::Turn::Finished(crate::lower::types::ref_(&value_of_29204)))
                    },
                }
            },
            _ => {
                let e = e.clone();
                let env = env.clone();
                let lx = lx.clone();
                call_then(start_value_of(lx.clone(), env.clone(), e.clone()), move |value_of_29244: crate::lower::types::Vl| prism_rtl::Turn::Finished(crate::lower::types::ref_(&value_of_29244)))
            },
        }
    }
}

/// `Start ArgumentByKind, x`: what the function value is when passed to `@Run`.
pub fn start_argument_by_kind(lx: crate::lower::Lx, env: crate::lower::types::Env, e: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>> {
    Rc::new(ArgumentByKind { lx, env, e })
}

/// ```prism
/// ClosureRef: fn Vl -> Ex
/// ```
pub fn closure_ref(vl0: &crate::lower::types::Vl) -> crate::lower::model::Ex {
    match vl0 {
        crate::lower::types::Vl::VlPlace(x, crate::lower::types::Holding::ByRef, t) => x.clone(),
        crate::lower::types::Vl::VlPlace(x, _, t) => crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XDeref(Rc::new(x.clone())))),
        crate::lower::types::Vl::VlOwned(x, t) => crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XDeref(Rc::new(x.clone())))),
    }
}

/// ```prism
/// TagValue: unbounded fn Lx, Env, TagInfo, [Arg] -> Vl
/// ```
pub fn tag_value(lx: &crate::lower::Lx, env: &crate::lower::types::Env, tg: &crate::check::env::TagInfo, args: &Array<crate::syntax::Arg>) -> crate::lower::types::Vl {
    let (variant, struct_path) = crate::lower::program::tag_paths(lx, tg);
    let t = crate::lower::model::OutTy::OutNamed(crate::lower::program::kind_path(lx, &tg.kind), Array::new());
    match &tg.kind {
        m29995_0 if (m29995_0 == &Text::lit("Element")) => crate::lower::types::Vl::VlOwned(refusal(&Text::from(format!("an element as a plain value ({}): a live element comes from its host", &tg.name))), t.clone()),
        m29995_1 if (m29995_1 == &Text::lit("Prelude.Fault")) => crate::lower::types::Vl::VlOwned(refusal(&Text::from(format!("a fault kind applied ({})", &tg.name))), t.clone()),
        _ => {
            let named_ = fold(args, &false, &(|f: &bool, a: &crate::syntax::Arg| *f || is_named_arg(a)));
            let fields = run_to_end(each_job(crate::check::errors::range0(&len(&tg.fields)), {
                let tg = tg.clone();
                let named_ = named_;
                let args = args.clone();
                let lx = lx.clone();
                let env = env.clone();
                Rc::new(move |p0: Nat| {
                    let tg = tg.clone();
                    let named_ = named_;
                    let args = args.clone();
                    let lx = lx.clone();
                    let env = env.clone();
                    entered(once_job(move || {
                        let i = p0;
                        {
                            let (fname, _) = or(&index(&tg.fields, &i), &(Text::lit(""), crate::check::types::Ty::TyErr));
                            let arg_opt = if named_ {
                                crate::lower::node_::elements::tag_arg(&args, &fname)
                            } else {
                                match index(&args, &i) {
                                    Some(a) => Some(a.value.clone()),
                                    None => None,
                                }
                            };
                            let v_ = match &arg_opt {
                                Some(x) => crate::lower::types::own(&value_of(&lx, &env, x)),
                                None => crate::lower::model::Ex::XCall(Text::lit("Default::default"), Array::new()),
                            };
                            prism_rtl::Turn::Finished((crate::lower::snake(&fname), v_.clone()))
                        }
                    }))
                }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<(Text, crate::lower::model::Ex)>>>
            }));
            crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCtor(variant.clone(), Array::from(vec![crate::lower::model::Ex::XRecord(struct_path.clone(), fields.clone())])), t.clone())
        },
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `TagValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TagValue: unbounded fn Lx, Env, TagInfo, [Arg] -> Vl
/// ```
pub struct TagValue {
    pub lx: crate::lower::Lx,
    pub env: crate::lower::types::Env,
    pub tg: crate::check::env::TagInfo,
    pub args: Array<crate::syntax::Arg>,
}

impl prism_rtl::Job<crate::lower::types::Vl> for TagValue {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::types::Vl> {
        let lx = &self.lx;
        let env = &self.env;
        let tg = &self.tg;
        let args = &self.args;
        let (variant, struct_path) = crate::lower::program::tag_paths(lx, tg);
        let t = crate::lower::model::OutTy::OutNamed(crate::lower::program::kind_path(lx, &tg.kind), Array::new());
        match &tg.kind {
            m29995_0 if (m29995_0 == &Text::lit("Element")) => prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(refusal(&Text::from(format!("an element as a plain value ({}): a live element comes from its host", &tg.name))), t.clone())),
            m29995_1 if (m29995_1 == &Text::lit("Prelude.Fault")) => prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(refusal(&Text::from(format!("a fault kind applied ({})", &tg.name))), t.clone())),
            _ => {
                let named_ = fold(args, &false, &(|f: &bool, a: &crate::syntax::Arg| *f || is_named_arg(a)));
                let args = args.clone();
                let env = env.clone();
                let lx = lx.clone();
                let tg = tg.clone();
                call_value(each_job(crate::check::errors::range0(&len(&tg.fields)), {
                    let tg = tg.clone();
                    let named_ = named_;
                    let args = args.clone();
                    let lx = lx.clone();
                    let env = env.clone();
                    Rc::new(move |p0: Nat| {
                        let tg = tg.clone();
                        let named_ = named_;
                        let args = args.clone();
                        let lx = lx.clone();
                        let env = env.clone();
                        entered(once_job(move || {
                            let i = p0;
                            {
                                let (fname, _) = or(&index(&tg.fields, &i), &(Text::lit(""), crate::check::types::Ty::TyErr));
                                let arg_opt = if named_ {
                                    crate::lower::node_::elements::tag_arg(&args, &fname)
                                } else {
                                    match index(&args, &i) {
                                        Some(a) => Some(a.value.clone()),
                                        None => None,
                                    }
                                };
                                let v_ = match &arg_opt {
                                    Some(x) => crate::lower::types::own(&value_of(&lx, &env, x)),
                                    None => crate::lower::model::Ex::XCall(Text::lit("Default::default"), Array::new()),
                                };
                                prism_rtl::Turn::Finished((crate::lower::snake(&fname), v_.clone()))
                            }
                        }))
                    }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<(Text, crate::lower::model::Ex)>>>
                }), move |each_30321: Array<(Text, crate::lower::model::Ex)>| {
                    let fields = each_30321;
                    prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCtor(variant.clone(), Array::from(vec![crate::lower::model::Ex::XRecord(struct_path.clone(), fields.clone())])), t.clone()))
                })
            },
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start TagValue, x`: what the function value is when passed to `@Run`.
pub fn start_tag_value(lx: crate::lower::Lx, env: crate::lower::types::Env, tg: crate::check::env::TagInfo, args: Array<crate::syntax::Arg>) -> Rc<dyn prism_rtl::Job<crate::lower::types::Vl>> {
    Rc::new(TagValue { lx, env, tg, args })
}

/// ```prism
/// GlobalCall: unbounded fn Lx, Env, Text, [Arg], Range, OutTy -> Vl
/// ```
pub fn global_call(lx: &crate::lower::Lx, env: &crate::lower::types::Env, qk: &Text, args: &Array<crate::syntax::Arg>, span: &crate::syntax::Range, t: &crate::lower::model::OutTy) -> crate::lower::types::Vl {
    match get(&lx.g.ctors, qk) {
        Some(c) => ctor_app(lx, env, &c, args, span),
        None => match get(&lx.g.vals, qk) {
            Some(v_) => if &v_.sort == &Text::lit("method") {
                method_call(lx, env, &v_, args, span, t)
            } else {
                if &v_.home == &Text::lit("Prelude") {
                    prelude_call(lx, env, qk, args, span, t)
                } else {
                    crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCall(crate::lower::value_path(lx, qk), args_for(lx, env, &v_, args)), t.clone())
                }
            },
            None => crate::lower::types::Vl::VlOwned(refusal(&Text::from(format!("a call of {}", qk))), t.clone()),
        },
    }
}

/// The step machine of `GlobalCall`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// GlobalCall: unbounded fn Lx, Env, Text, [Arg], Range, OutTy -> Vl
/// ```
pub struct GlobalCall {
    pub lx: crate::lower::Lx,
    pub env: crate::lower::types::Env,
    pub qk: Text,
    pub args: Array<crate::syntax::Arg>,
    pub span: crate::syntax::Range,
    pub t: crate::lower::model::OutTy,
}

impl prism_rtl::Job<crate::lower::types::Vl> for GlobalCall {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::types::Vl> {
        let lx = &self.lx;
        let env = &self.env;
        let qk = &self.qk;
        let args = &self.args;
        let span = &self.span;
        let t = &self.t;
        match get(&lx.g.ctors, qk) {
            Some(c) => prism_rtl::Turn::More(Rc::new(CtorApp { lx: lx.clone(), env: env.clone(), c: c.clone(), args: args.clone(), span: span.clone() })),
            None => match get(&lx.g.vals, qk) {
                Some(v_) => if &v_.sort == &Text::lit("method") {
                    prism_rtl::Turn::More(Rc::new(MethodCall { lx: lx.clone(), env: env.clone(), v_: v_.clone(), args: args.clone(), span: span.clone(), t: t.clone() }))
                } else {
                    if &v_.home == &Text::lit("Prelude") {
                        prism_rtl::Turn::More(Rc::new(PreludeCall { lx: lx.clone(), env: env.clone(), qk: qk.clone(), args: args.clone(), span: span.clone(), t: t.clone() }))
                    } else {
                        {
                            let args = args.clone();
                            let env = env.clone();
                            let lx = lx.clone();
                            let qk = qk.clone();
                            let t = t.clone();
                            call_then(start_args_for(lx.clone(), env.clone(), v_.clone(), args.clone()), move |args_for_31361: Array<crate::lower::model::Ex>| prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCall(crate::lower::value_path(&lx, &qk), args_for_31361), t.clone())))
                        }
                    }
                },
                None => prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(refusal(&Text::from(format!("a call of {}", qk))), t.clone())),
            },
        }
    }
}

/// `Start GlobalCall, x`: what the function value is when passed to `@Run`.
pub fn start_global_call(lx: crate::lower::Lx, env: crate::lower::types::Env, qk: Text, args: Array<crate::syntax::Arg>, span: crate::syntax::Range, t: crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<crate::lower::types::Vl>> {
    Rc::new(GlobalCall { lx, env, qk, args, span, t })
}

/// ```prism
/// ArgsFor: unbounded fn Lx, Env, ValInfo, [Arg] -> [Ex]
/// ```
pub fn args_for(lx: &crate::lower::Lx, env: &crate::lower::types::Env, v_: &crate::check::env::ValInfo, args: &Array<crate::syntax::Arg>) -> Array<crate::lower::model::Ex> {
    let ps = match &v_.scheme.ty {
        crate::check::types::Ty::TyFn(_, xs, _) => xs.clone(),
        _ => Array::new(),
    };
    run_to_end(each_job(crate::check::errors::range0(&len(args)), {
        let args = args.clone();
        let ps = ps.clone();
        let lx = lx.clone();
        let env = env.clone();
        Rc::new(move |p0: Nat| {
            let args = args.clone();
            let ps = ps.clone();
            let lx = lx.clone();
            let env = env.clone();
            entered(once_job(move || {
                let i = p0;
                {
                    let a = or(&index(&args, &i), &crate::syntax::Arg { name: None, value: dummy_expr(), span: crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) } });
                    let is_try = match crate::lower::types::peel(&or(&index(&ps, &i), &crate::check::types::Ty::TyErr)) {
                        crate::check::types::Ty::TySig(m31927_0_0, _) if (&m31927_0_0 == &Text::lit("~")) => true,
                        _ => false,
                        _ => unreachable!("no arm matched"),
                    };
                    let is_error = match crate::lower::types::peel(&crate::lower::type_at(&lx, &a.value.span)) {
                        crate::check::types::Ty::TyCon(m32044_0_0, _) if (&m32044_0_0 == &Text::lit("Prelude.Error")) => true,
                        _ => false,
                        _ => unreachable!("no arm matched"),
                    };
                    let to_unbounded = match crate::lower::types::peel(&or(&index(&ps, &i), &crate::check::types::Ty::TyErr)) {
                        crate::check::types::Ty::TyFn(crate::check::types::Col::CBound, _, _) => false,
                        crate::check::types::Ty::TyFn(_, _, _) => true,
                        _ => false,
                    };
                    if is_try && is_error {
                        call_then(start_value_of(lx.clone(), env.clone(), a.value.clone()), move |value_of_32393: crate::lower::types::Vl| prism_rtl::Turn::Finished(crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XCtor(Text::lit("Err"), Array::from(vec![crate::lower::types::own(&value_of_32393)]))))))
                    } else {
                        if to_unbounded {
                            call_then(start_as_job_value(lx.clone(), env.clone(), a.value.clone()), move |as_job_value_32458: crate::lower::model::Ex| prism_rtl::Turn::Finished(crate::lower::model::Ex::XRef(Rc::new(as_job_value_32458))))
                        } else {
                            prism_rtl::Turn::More(Rc::new(Argument { lx: lx.clone(), env: env.clone(), e: a.value.clone() }))
                        }
                    }
                }
            }))
        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
    }))
}

/// The step machine of `ArgsFor`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ArgsFor: unbounded fn Lx, Env, ValInfo, [Arg] -> [Ex]
/// ```
pub struct ArgsFor {
    pub lx: crate::lower::Lx,
    pub env: crate::lower::types::Env,
    pub v_: crate::check::env::ValInfo,
    pub args: Array<crate::syntax::Arg>,
}

impl prism_rtl::Job<Array<crate::lower::model::Ex>> for ArgsFor {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::lower::model::Ex>> {
        let lx = &self.lx;
        let env = &self.env;
        let v_ = &self.v_;
        let args = &self.args;
        let ps = match &v_.scheme.ty {
            crate::check::types::Ty::TyFn(_, xs, _) => xs.clone(),
            _ => Array::new(),
        };
        each_job(crate::check::errors::range0(&len(args)), {
            let args = args.clone();
            let ps = ps.clone();
            let lx = lx.clone();
            let env = env.clone();
            Rc::new(move |p0: Nat| {
                let args = args.clone();
                let ps = ps.clone();
                let lx = lx.clone();
                let env = env.clone();
                entered(once_job(move || {
                    let i = p0;
                    {
                        let a = or(&index(&args, &i), &crate::syntax::Arg { name: None, value: dummy_expr(), span: crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) } });
                        let is_try = match crate::lower::types::peel(&or(&index(&ps, &i), &crate::check::types::Ty::TyErr)) {
                            crate::check::types::Ty::TySig(m31927_0_0, _) if (&m31927_0_0 == &Text::lit("~")) => true,
                            _ => false,
                            _ => unreachable!("no arm matched"),
                        };
                        let is_error = match crate::lower::types::peel(&crate::lower::type_at(&lx, &a.value.span)) {
                            crate::check::types::Ty::TyCon(m32044_0_0, _) if (&m32044_0_0 == &Text::lit("Prelude.Error")) => true,
                            _ => false,
                            _ => unreachable!("no arm matched"),
                        };
                        let to_unbounded = match crate::lower::types::peel(&or(&index(&ps, &i), &crate::check::types::Ty::TyErr)) {
                            crate::check::types::Ty::TyFn(crate::check::types::Col::CBound, _, _) => false,
                            crate::check::types::Ty::TyFn(_, _, _) => true,
                            _ => false,
                        };
                        if is_try && is_error {
                            call_then(start_value_of(lx.clone(), env.clone(), a.value.clone()), move |value_of_32393: crate::lower::types::Vl| prism_rtl::Turn::Finished(crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XCtor(Text::lit("Err"), Array::from(vec![crate::lower::types::own(&value_of_32393)]))))))
                        } else {
                            if to_unbounded {
                                call_then(start_as_job_value(lx.clone(), env.clone(), a.value.clone()), move |as_job_value_32458: crate::lower::model::Ex| prism_rtl::Turn::Finished(crate::lower::model::Ex::XRef(Rc::new(as_job_value_32458))))
                            } else {
                                prism_rtl::Turn::More(Rc::new(Argument { lx: lx.clone(), env: env.clone(), e: a.value.clone() }))
                            }
                        }
                    }
                }))
            }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
        }).cycle()
    }
}

/// `Start ArgsFor, x`: what the function value is when passed to `@Run`.
pub fn start_args_for(lx: crate::lower::Lx, env: crate::lower::types::Env, v_: crate::check::env::ValInfo, args: Array<crate::syntax::Arg>) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Ex>>> {
    Rc::new(ArgsFor { lx, env, v_, args })
}

/// ```prism
/// let dummyExpr
/// ```
pub fn dummy_expr() -> crate::syntax::Expr {
    crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EError), span: crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) } }
}

/// ```prism
/// CtorApp: unbounded fn Lx, Env, CtorInfo, [Arg], Range -> Vl
/// ```
pub fn ctor_app(lx: &crate::lower::Lx, env: &crate::lower::types::Env, c: &crate::check::env::CtorInfo, args: &Array<crate::syntax::Arg>, span: &crate::syntax::Range) -> crate::lower::types::Vl {
    let t = crate::lower::types::out_ty_of(lx, &crate::lower::types::peel(&crate::lower::type_at(lx, span)));
    let owner = or(&get(&lx.g.types, &c.owner), &crate::check::env::names::dummy_ty_info());
    let ty_path = crate::lower::path_in(lx, &owner.home, &crate::lower::camel(&crate::check::types::bare_name(&c.owner)));
    let vals = ctor_args(lx, env, c, args);
    match &c.owner {
        m33075_0 if (m33075_0 == &Text::lit("Bool")) => crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XBool(&c.name == &Text::lit("True")), crate::lower::model::OutTy::OutBool),
        m33075_1 if (m33075_1 == &Text::lit("Prelude.Error")) => {
            let kind = or(&index(&vals, &Nat::from(0u32)), &crate::lower::model::Ex::XStr(Text::lit("")));
            let msg = or(&index(&vals, &Nat::from(1u32)), &crate::lower::model::Ex::XText(Text::lit("")));
            let made = crate::lower::model::Ex::XCall(Text::lit("Error::new"), Array::from(vec![kind.clone(), msg.clone()]));
            match &t {
                crate::lower::model::OutTy::OutRes(_) => crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCtor(Text::lit("Err"), Array::from(vec![made.clone()])), t.clone()),
                _ => crate::lower::types::Vl::VlOwned(made.clone(), crate::lower::model::OutTy::OutError),
            }
        },
        _ => match &owner.body {
            crate::check::env::TyBody::BRecord(fs) => if &len(&c.fields) == &Nat::from(0u32) {
                crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XPath(ty_path.clone()), t.clone())
            } else {
                crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XRecord(ty_path.clone(), each(&crate::check::errors::range0(&len(&c.fields)), &(|i: &Nat| (crate::lower::snake(&or(&index(&c.fields, i), &Text::lit(""))), or(&index(&vals, i), &crate::lower::model::Ex::XCall(Text::lit("Default::default"), Array::new())))))), t.clone())
            },
            crate::check::env::TyBody::BChoice(cases) => {
                let is_unit_type = ((&len(cases) == &Nat::from(1u32)) && (&len(&c.args) == &Nat::from(0u32))) && crate::check::env::is_lower_text(&crate::check::types::bare_name(&c.name));
                let is_newtype = (&len(cases) == &Nat::from(1u32)) && (&crate::check::types::bare_name(&c.name) == &crate::check::types::bare_name(&c.owner));
                let path_ = if is_unit_type || is_newtype {
                    ty_path.clone()
                } else {
                    Text::from(format!("{}::{}", &ty_path, &crate::lower::camel(&crate::check::types::bare_name(&c.name))))
                };
                if &len(&c.args) == &Nat::from(0u32) {
                    crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XPath(path_.clone()), t.clone())
                } else {
                    crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCtor(path_.clone(), vals.clone()), t.clone())
                }
            },
            _ => crate::lower::types::Vl::VlOwned(refusal(&Text::from(format!("a constructor of {}", &c.owner))), t.clone()),
        },
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `CtorApp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CtorApp: unbounded fn Lx, Env, CtorInfo, [Arg], Range -> Vl
/// ```
pub struct CtorApp {
    pub lx: crate::lower::Lx,
    pub env: crate::lower::types::Env,
    pub c: crate::check::env::CtorInfo,
    pub args: Array<crate::syntax::Arg>,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<crate::lower::types::Vl> for CtorApp {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::types::Vl> {
        let lx = &self.lx;
        let env = &self.env;
        let c = &self.c;
        let args = &self.args;
        let span = &self.span;
        let args = args.clone();
        let c = c.clone();
        let env = env.clone();
        let lx = lx.clone();
        let span = span.clone();
        call_then(crate::lower::types::start_out_ty_of(lx.clone(), crate::lower::types::peel(&crate::lower::type_at(&lx, &span))), move |out_ty_of_32874: crate::lower::model::OutTy| {
            let t = out_ty_of_32874;
            let owner = or(&get(&lx.g.types, &c.owner), &crate::check::env::names::dummy_ty_info());
            let ty_path = crate::lower::path_in(&lx, &owner.home, &crate::lower::camel(&crate::check::types::bare_name(&c.owner)));
            call_then(start_ctor_args(lx.clone(), env.clone(), c.clone(), args.clone()), move |ctor_args_33045: Array<crate::lower::model::Ex>| {
                let vals = ctor_args_33045;
                match &c.owner {
                    m33075_0 if (m33075_0 == &Text::lit("Bool")) => prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XBool(&c.name == &Text::lit("True")), crate::lower::model::OutTy::OutBool)),
                    m33075_1 if (m33075_1 == &Text::lit("Prelude.Error")) => {
                        let kind = or(&index(&vals, &Nat::from(0u32)), &crate::lower::model::Ex::XStr(Text::lit("")));
                        let msg = or(&index(&vals, &Nat::from(1u32)), &crate::lower::model::Ex::XText(Text::lit("")));
                        let made = crate::lower::model::Ex::XCall(Text::lit("Error::new"), Array::from(vec![kind.clone(), msg.clone()]));
                        match &t {
                            crate::lower::model::OutTy::OutRes(_) => prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCtor(Text::lit("Err"), Array::from(vec![made.clone()])), t.clone())),
                            _ => prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(made.clone(), crate::lower::model::OutTy::OutError)),
                        }
                    },
                    _ => match &owner.body {
                        crate::check::env::TyBody::BRecord(fs) => if &len(&c.fields) == &Nat::from(0u32) {
                            prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XPath(ty_path.clone()), t.clone()))
                        } else {
                            prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XRecord(ty_path.clone(), each(&crate::check::errors::range0(&len(&c.fields)), &(|i: &Nat| (crate::lower::snake(&or(&index(&c.fields, i), &Text::lit(""))), or(&index(&vals, i), &crate::lower::model::Ex::XCall(Text::lit("Default::default"), Array::new())))))), t.clone()))
                        },
                        crate::check::env::TyBody::BChoice(cases) => {
                            let is_unit_type = ((&len(cases) == &Nat::from(1u32)) && (&len(&c.args) == &Nat::from(0u32))) && crate::check::env::is_lower_text(&crate::check::types::bare_name(&c.name));
                            let is_newtype = (&len(cases) == &Nat::from(1u32)) && (&crate::check::types::bare_name(&c.name) == &crate::check::types::bare_name(&c.owner));
                            let path_ = if is_unit_type || is_newtype {
                                ty_path.clone()
                            } else {
                                Text::from(format!("{}::{}", &ty_path, &crate::lower::camel(&crate::check::types::bare_name(&c.name))))
                            };
                            if &len(&c.args) == &Nat::from(0u32) {
                                prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XPath(path_.clone()), t.clone()))
                            } else {
                                prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCtor(path_.clone(), vals.clone()), t.clone()))
                            }
                        },
                        _ => prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(refusal(&Text::from(format!("a constructor of {}", &c.owner))), t.clone())),
                    },
                    _ => unreachable!("no arm matched"),
                }
            })
        })
    }
}

/// `Start CtorApp, x`: what the function value is when passed to `@Run`.
pub fn start_ctor_app(lx: crate::lower::Lx, env: crate::lower::types::Env, c: crate::check::env::CtorInfo, args: Array<crate::syntax::Arg>, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<crate::lower::types::Vl>> {
    Rc::new(CtorApp { lx, env, c, args, span })
}

/// ```prism
/// CtorFn: unbounded fn Lx, CtorInfo, [OutTy], Range, OutTy, Bool -> Vl
/// ```
pub fn ctor_fn(lx: &crate::lower::Lx, c: &crate::check::env::CtorInfo, pts: &Array<crate::lower::model::OutTy>, span: &crate::syntax::Range, t: &crate::lower::model::OutTy, job: &bool) -> crate::lower::types::Vl {
    let names = each(&crate::check::errors::range0(&len(pts)), &(|i: &Nat| Text::from(format!("a{}", i))));
    let fakes = each(&crate::check::errors::range0(&len(pts)), &(|i: &Nat| crate::syntax::Arg { name: None, value: crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EAbsent), span: crate::syntax::Range { start: &Nat::from_int(Int::from(4000000000i64)).unwrap() + i, end: &Nat::from_int(Int::from(4000000000i64)).unwrap() + i } }, span: crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) } }));
    let env = fold(&crate::check::errors::range0(&len(pts)), &crate::lower::types::empty_env(), &(|en: &crate::lower::types::Env, i: &Nat| crate::lower::types::bind_span(en, &crate::lower::place_key(lx, &crate::syntax::Range { start: &Nat::from_int(Int::from(4000000000i64)).unwrap() + i, end: &Nat::from_int(Int::from(4000000000i64)).unwrap() + i }), &crate::lower::types::Vl::VlPlace(crate::lower::model::Ex::XVar(or(&index(&names, i), &Text::lit("a"))), if *job {
        crate::lower::types::Holding::Owned
    } else {
        crate::lower::types::Holding::ByRef
    }, or(&index(pts, i), &crate::lower::model::OutTy::OutUnit)))));
    let made = crate::lower::types::own(&ctor_app(lx, &env, c, &fakes, span));
    if *job {
        {
            let a = match t {
                crate::lower::model::OutTy::OutJobFn(x, _) => (**x).clone(),
                _ => crate::lower::model::OutTy::OutUnit,
            };
            let pa = if &len(pts) == &Nat::from(1u32) {
                crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaBind(Text::lit("a0"))), a.clone())
            } else {
                crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaTuple(each(&names, &(|nm: &Text| crate::lower::model::Pa::PaBind(nm.clone()))))), a.clone())
            };
            crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCast(Rc::new(crate::lower::model::Ex::XCall(Text::lit("Rc::new"), Array::from(vec![crate::lower::model::Ex::XClosure(true, Array::from(vec![pa.clone()]), Rc::new(crate::lower::model::Ex::XCall(Text::lit("once_job"), Array::from(vec![crate::lower::model::Ex::XClosure(true, Array::new(), Rc::new(crate::lower::model::Ex::XCtor(Text::lit("prism_rtl::Turn::Finished"), Array::from(vec![made.clone()]))))]))))]))), t.clone()), t.clone())
        }
    } else {
        {
            let pas = each(&crate::check::errors::range0(&len(pts)), &(|i: &Nat| crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaBind(or(&index(&names, i), &Text::lit("a")))), crate::lower::model::OutTy::OutRef(Rc::new(or(&index(pts, i), &crate::lower::model::OutTy::OutUnit))))));
            crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCall(Text::lit("Rc::new"), Array::from(vec![crate::lower::model::Ex::XClosure(false, pas.clone(), Rc::new(made.clone()))])), t.clone())
        }
    }
}

/// The step machine of `CtorFn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CtorFn: unbounded fn Lx, CtorInfo, [OutTy], Range, OutTy, Bool -> Vl
/// ```
pub struct CtorFn {
    pub lx: crate::lower::Lx,
    pub c: crate::check::env::CtorInfo,
    pub pts: Array<crate::lower::model::OutTy>,
    pub span: crate::syntax::Range,
    pub t: crate::lower::model::OutTy,
    pub job: bool,
}

impl prism_rtl::Job<crate::lower::types::Vl> for CtorFn {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::types::Vl> {
        let lx = &self.lx;
        let c = &self.c;
        let pts = &self.pts;
        let span = &self.span;
        let t = &self.t;
        let job = &self.job;
        let names = each(&crate::check::errors::range0(&len(pts)), &(|i: &Nat| Text::from(format!("a{}", i))));
        let fakes = each(&crate::check::errors::range0(&len(pts)), &(|i: &Nat| crate::syntax::Arg { name: None, value: crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EAbsent), span: crate::syntax::Range { start: &Nat::from_int(Int::from(4000000000i64)).unwrap() + i, end: &Nat::from_int(Int::from(4000000000i64)).unwrap() + i } }, span: crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) } }));
        let env = fold(&crate::check::errors::range0(&len(pts)), &crate::lower::types::empty_env(), &(|en: &crate::lower::types::Env, i: &Nat| crate::lower::types::bind_span(en, &crate::lower::place_key(lx, &crate::syntax::Range { start: &Nat::from_int(Int::from(4000000000i64)).unwrap() + i, end: &Nat::from_int(Int::from(4000000000i64)).unwrap() + i }), &crate::lower::types::Vl::VlPlace(crate::lower::model::Ex::XVar(or(&index(&names, i), &Text::lit("a"))), if *job {
            crate::lower::types::Holding::Owned
        } else {
            crate::lower::types::Holding::ByRef
        }, or(&index(pts, i), &crate::lower::model::OutTy::OutUnit)))));
        let c = c.clone();
        let job = *job;
        let lx = lx.clone();
        let pts = pts.clone();
        let span = span.clone();
        let t = t.clone();
        call_then(start_ctor_app(lx.clone(), env.clone(), c.clone(), fakes.clone(), span.clone()), move |ctor_app_35193: crate::lower::types::Vl| {
            let made = crate::lower::types::own(&ctor_app_35193);
            if job {
                {
                    let a = match &t {
                        crate::lower::model::OutTy::OutJobFn(x, _) => (**x).clone(),
                        _ => crate::lower::model::OutTy::OutUnit,
                    };
                    let pa = if &len(&pts) == &Nat::from(1u32) {
                        crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaBind(Text::lit("a0"))), a.clone())
                    } else {
                        crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaTuple(each(&names, &(|nm: &Text| crate::lower::model::Pa::PaBind(nm.clone()))))), a.clone())
                    };
                    prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCast(Rc::new(crate::lower::model::Ex::XCall(Text::lit("Rc::new"), Array::from(vec![crate::lower::model::Ex::XClosure(true, Array::from(vec![pa.clone()]), Rc::new(crate::lower::model::Ex::XCall(Text::lit("once_job"), Array::from(vec![crate::lower::model::Ex::XClosure(true, Array::new(), Rc::new(crate::lower::model::Ex::XCtor(Text::lit("prism_rtl::Turn::Finished"), Array::from(vec![made.clone()]))))]))))]))), t.clone()), t.clone()))
                }
            } else {
                {
                    let pas = each(&crate::check::errors::range0(&len(&pts)), &(|i: &Nat| crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaBind(or(&index(&names, i), &Text::lit("a")))), crate::lower::model::OutTy::OutRef(Rc::new(or(&index(&pts, i), &crate::lower::model::OutTy::OutUnit))))));
                    prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCall(Text::lit("Rc::new"), Array::from(vec![crate::lower::model::Ex::XClosure(false, pas.clone(), Rc::new(made.clone()))])), t.clone()))
                }
            }
        })
    }
}

/// `Start CtorFn, x`: what the function value is when passed to `@Run`.
pub fn start_ctor_fn(lx: crate::lower::Lx, c: crate::check::env::CtorInfo, pts: Array<crate::lower::model::OutTy>, span: crate::syntax::Range, t: crate::lower::model::OutTy, job: bool) -> Rc<dyn prism_rtl::Job<crate::lower::types::Vl>> {
    Rc::new(CtorFn { lx, c, pts, span, t, job })
}

/// ```prism
/// IsNamedArg: fn Arg -> Bool
/// ```
pub fn is_named_arg(a: &crate::syntax::Arg) -> bool {
    match &a.name {
        Some(_) => true,
        None => false,
    }
}

/// ```prism
/// CtorArgs: unbounded fn Lx, Env, CtorInfo, [Arg] -> [Ex]
/// ```
pub fn ctor_args(lx: &crate::lower::Lx, env: &crate::lower::types::Env, c: &crate::check::env::CtorInfo, args: &Array<crate::syntax::Arg>) -> Array<crate::lower::model::Ex> {
    let named_ = fold(args, &false, &(|f: &bool, a: &crate::syntax::Arg| *f || is_named_arg(a)));
    let ordered = if named_ {
        each(&c.fields, &(|f: &Text| fold(args, &None, &(|found_opt: &Option<crate::syntax::Expr>, a: &crate::syntax::Arg| match &a.name {
            Some(n) => if &n.name == f { Some(a.value.clone()) } else { found_opt.clone() },
            None => found_opt.clone(),
        }))))
    } else {
        each(args, &(|a: &crate::syntax::Arg| Some(a.value.clone())))
    };
    run_to_end(each_job(crate::check::errors::range0(&len(&ordered)), {
        let ordered = ordered.clone();
        let lx = lx.clone();
        let env = env.clone();
        let c = c.clone();
        Rc::new(move |p0: Nat| {
            let ordered = ordered.clone();
            let lx = lx.clone();
            let env = env.clone();
            let c = c.clone();
            entered(once_job(move || {
                let i = p0;
                match index(&ordered, &i) {
                    Some(Some(x)) => call_then(start_value_of(lx.clone(), env.clone(), x.clone()), move |value_of_36458: crate::lower::types::Vl| {
                        let v_ = crate::lower::types::own(&value_of_36458);
                        if (&c.owner == &Text::lit("Prelude.Error")) && (&i == &Nat::from(0u32)) {
                            prism_rtl::Turn::Finished(v_.clone())
                        } else {
                            if crate::lower::types::rc_field(&lx, &c.name, &i) {
                                prism_rtl::Turn::Finished(crate::lower::model::Ex::XCall(Text::lit("Rc::new"), Array::from(vec![v_.clone()])))
                            } else {
                                prism_rtl::Turn::Finished(v_.clone())
                            }
                        }
                    }),
                    _ => prism_rtl::Turn::Finished(crate::lower::model::Ex::XCall(Text::lit("Default::default"), Array::new())),
                }
            }))
        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
    }))
}

/// The step machine of `CtorArgs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CtorArgs: unbounded fn Lx, Env, CtorInfo, [Arg] -> [Ex]
/// ```
pub struct CtorArgs {
    pub lx: crate::lower::Lx,
    pub env: crate::lower::types::Env,
    pub c: crate::check::env::CtorInfo,
    pub args: Array<crate::syntax::Arg>,
}

impl prism_rtl::Job<Array<crate::lower::model::Ex>> for CtorArgs {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::lower::model::Ex>> {
        let lx = &self.lx;
        let env = &self.env;
        let c = &self.c;
        let args = &self.args;
        let named_ = fold(args, &false, &(|f: &bool, a: &crate::syntax::Arg| *f || is_named_arg(a)));
        let ordered = if named_ {
            each(&c.fields, &(|f: &Text| fold(args, &None, &(|found_opt: &Option<crate::syntax::Expr>, a: &crate::syntax::Arg| match &a.name {
                Some(n) => if &n.name == f { Some(a.value.clone()) } else { found_opt.clone() },
                None => found_opt.clone(),
            }))))
        } else {
            each(args, &(|a: &crate::syntax::Arg| Some(a.value.clone())))
        };
        each_job(crate::check::errors::range0(&len(&ordered)), {
            let ordered = ordered.clone();
            let lx = lx.clone();
            let env = env.clone();
            let c = c.clone();
            Rc::new(move |p0: Nat| {
                let ordered = ordered.clone();
                let lx = lx.clone();
                let env = env.clone();
                let c = c.clone();
                entered(once_job(move || {
                    let i = p0;
                    match index(&ordered, &i) {
                        Some(Some(x)) => call_then(start_value_of(lx.clone(), env.clone(), x.clone()), move |value_of_36458: crate::lower::types::Vl| {
                            let v_ = crate::lower::types::own(&value_of_36458);
                            if (&c.owner == &Text::lit("Prelude.Error")) && (&i == &Nat::from(0u32)) {
                                prism_rtl::Turn::Finished(v_.clone())
                            } else {
                                if crate::lower::types::rc_field(&lx, &c.name, &i) {
                                    prism_rtl::Turn::Finished(crate::lower::model::Ex::XCall(Text::lit("Rc::new"), Array::from(vec![v_.clone()])))
                                } else {
                                    prism_rtl::Turn::Finished(v_.clone())
                                }
                            }
                        }),
                        _ => prism_rtl::Turn::Finished(crate::lower::model::Ex::XCall(Text::lit("Default::default"), Array::new())),
                    }
                }))
            }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
        }).cycle()
    }
}

/// `Start CtorArgs, x`: what the function value is when passed to `@Run`.
pub fn start_ctor_args(lx: crate::lower::Lx, env: crate::lower::types::Env, c: crate::check::env::CtorInfo, args: Array<crate::syntax::Arg>) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Ex>>> {
    Rc::new(CtorArgs { lx, env, c, args })
}

/// ```prism
/// MethodCall: unbounded fn Lx, Env, ValInfo, [Arg], Range, OutTy -> Vl
/// ```
pub fn method_call(lx: &crate::lower::Lx, env: &crate::lower::types::Env, v_: &crate::check::env::ValInfo, args: &Array<crate::syntax::Arg>, span: &crate::syntax::Range, t: &crate::lower::model::OutTy) -> crate::lower::types::Vl {
    let cls = or(&index(&each(&v_.scheme.bounds, &(|(_, c): &(Text, Text)| c.clone())), &Nat::from(0u32)), &Text::lit(""));
    let m = crate::check::types::bare_name(&v_.qk);
    let vals = run_to_end(each_job(args.clone(), {
        let lx = lx.clone();
        let env = env.clone();
        Rc::new(move |p0: crate::syntax::Arg| {
            let lx = lx.clone();
            let env = env.clone();
            entered(once_job(move || {
                let a = p0;
                prism_rtl::Turn::More(Rc::new(ValueOf { lx: lx.clone(), env: env.clone(), e: a.value.clone() }))
            }))
        }) as Rc<dyn Fn(crate::syntax::Arg) -> Rc<dyn prism_rtl::Job<crate::lower::types::Vl>>>
    }));
    if crate::syntax::lexer::chars::has_prefix(&cls, &Text::lit("Prelude.")) {
        prelude_method(lx, &cls, &m, &vals, span, t)
    } else {
        {
            let tr = or(&get(&lx.g.traits, &cls), &dummy_trait_info());
            let path_ = crate::lower::path_in(lx, &tr.home, &Text::from(format!("{}::{}", &crate::lower::camel(&crate::check::types::bare_name(&cls)), &crate::lower::snake(&m))));
            crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCall(path_.clone(), run_to_end(each_job(args.clone(), {
                let lx = lx.clone();
                let env = env.clone();
                Rc::new(move |p0: crate::syntax::Arg| {
                    let lx = lx.clone();
                    let env = env.clone();
                    entered(once_job(move || {
                        let a = p0;
                        prism_rtl::Turn::More(Rc::new(Argument { lx: lx.clone(), env: env.clone(), e: a.value.clone() }))
                    }))
                }) as Rc<dyn Fn(crate::syntax::Arg) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
            }))), t.clone())
        }
    }
}

/// The step machine of `MethodCall`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// MethodCall: unbounded fn Lx, Env, ValInfo, [Arg], Range, OutTy -> Vl
/// ```
pub struct MethodCall {
    pub lx: crate::lower::Lx,
    pub env: crate::lower::types::Env,
    pub v_: crate::check::env::ValInfo,
    pub args: Array<crate::syntax::Arg>,
    pub span: crate::syntax::Range,
    pub t: crate::lower::model::OutTy,
}

impl prism_rtl::Job<crate::lower::types::Vl> for MethodCall {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::types::Vl> {
        let lx = &self.lx;
        let env = &self.env;
        let v_ = &self.v_;
        let args = &self.args;
        let span = &self.span;
        let t = &self.t;
        let cls = or(&index(&each(&v_.scheme.bounds, &(|(_, c): &(Text, Text)| c.clone())), &Nat::from(0u32)), &Text::lit(""));
        let m = crate::check::types::bare_name(&v_.qk);
        let args = args.clone();
        let env = env.clone();
        let lx = lx.clone();
        let span = span.clone();
        let t = t.clone();
        call_value(each_job(args.clone(), {
            let lx = lx.clone();
            let env = env.clone();
            Rc::new(move |p0: crate::syntax::Arg| {
                let lx = lx.clone();
                let env = env.clone();
                entered(once_job(move || {
                    let a = p0;
                    prism_rtl::Turn::More(Rc::new(ValueOf { lx: lx.clone(), env: env.clone(), e: a.value.clone() }))
                }))
            }) as Rc<dyn Fn(crate::syntax::Arg) -> Rc<dyn prism_rtl::Job<crate::lower::types::Vl>>>
        }), move |each_37076: Array<crate::lower::types::Vl>| {
            let vals = each_37076;
            if crate::syntax::lexer::chars::has_prefix(&cls, &Text::lit("Prelude.")) {
                prism_rtl::Turn::More(Rc::new(PreludeMethod { lx: lx.clone(), cls: cls.clone(), m: m.clone(), vals: vals.clone(), span: span.clone(), t: t.clone() }))
            } else {
                {
                    let tr = or(&get(&lx.g.traits, &cls), &dummy_trait_info());
                    let path_ = crate::lower::path_in(&lx, &tr.home, &Text::from(format!("{}::{}", &crate::lower::camel(&crate::check::types::bare_name(&cls)), &crate::lower::snake(&m))));
                    call_value(each_job(args.clone(), {
                        let lx = lx.clone();
                        let env = env.clone();
                        Rc::new(move |p0: crate::syntax::Arg| {
                            let lx = lx.clone();
                            let env = env.clone();
                            entered(once_job(move || {
                                let a = p0;
                                prism_rtl::Turn::More(Rc::new(Argument { lx: lx.clone(), env: env.clone(), e: a.value.clone() }))
                            }))
                        }) as Rc<dyn Fn(crate::syntax::Arg) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
                    }), move |each_37361: Array<crate::lower::model::Ex>| prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCall(path_.clone(), each_37361), t.clone())))
                }
            }
        })
    }
}

/// `Start MethodCall, x`: what the function value is when passed to `@Run`.
pub fn start_method_call(lx: crate::lower::Lx, env: crate::lower::types::Env, v_: crate::check::env::ValInfo, args: Array<crate::syntax::Arg>, span: crate::syntax::Range, t: crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<crate::lower::types::Vl>> {
    Rc::new(MethodCall { lx, env, v_, args, span, t })
}

/// ```prism
/// let dummyTraitInfo
/// ```
pub fn dummy_trait_info() -> crate::check::env::TraitInfo {
    crate::check::env::TraitInfo { name: Text::lit(""), home: Text::lit(""), param: Text::lit("a"), supers: Array::new(), methods: Array::new(), defaults: Array::new(), assocs: Array::new(), file: Nat::from(0u32), span: crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) } }
}

/// ```prism
/// PreludeMethod: unbounded fn Lx, Text, Text, [Vl], Range, OutTy -> Vl
/// ```
pub fn prelude_method(lx: &crate::lower::Lx, cls: &Text, m: &Text, vals: &Array<crate::lower::types::Vl>, span: &crate::syntax::Range, t: &crate::lower::model::OutTy) -> crate::lower::types::Vl {
    let a = or(&index(vals, &Nat::from(0u32)), &crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XUnit, crate::lower::model::OutTy::OutUnit));
    let b = or(&index(vals, &Nat::from(1u32)), &crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XUnit, crate::lower::model::OutTy::OutUnit));
    match m {
        m37780_0 if (m37780_0 == &Text::lit("Show")) => crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCall(Text::lit("show_text"), Array::from(vec![crate::lower::types::ref_(&a)])), crate::lower::model::OutTy::OutText),
        m37780_1 if (m37780_1 == &Text::lit("Compare")) => crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCall(Text::lit("compare"), Array::from(vec![crate::lower::types::ref_(&a), crate::lower::types::ref_(&b)])), t.clone()),
        m37780_2 if (m37780_2 == &Text::lit("Children")) => crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCall(Text::lit("children"), Array::from(vec![crate::lower::types::ref_(&a)])), t.clone()),
        _ => op_value(lx, m, &a, &b, span, t),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `PreludeMethod`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PreludeMethod: unbounded fn Lx, Text, Text, [Vl], Range, OutTy -> Vl
/// ```
pub struct PreludeMethod {
    pub lx: crate::lower::Lx,
    pub cls: Text,
    pub m: Text,
    pub vals: Array<crate::lower::types::Vl>,
    pub span: crate::syntax::Range,
    pub t: crate::lower::model::OutTy,
}

impl prism_rtl::Job<crate::lower::types::Vl> for PreludeMethod {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::types::Vl> {
        let lx = &self.lx;
        let cls = &self.cls;
        let m = &self.m;
        let vals = &self.vals;
        let span = &self.span;
        let t = &self.t;
        let a = or(&index(vals, &Nat::from(0u32)), &crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XUnit, crate::lower::model::OutTy::OutUnit));
        let b = or(&index(vals, &Nat::from(1u32)), &crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XUnit, crate::lower::model::OutTy::OutUnit));
        match m {
            m37780_0 if (m37780_0 == &Text::lit("Show")) => prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCall(Text::lit("show_text"), Array::from(vec![crate::lower::types::ref_(&a)])), crate::lower::model::OutTy::OutText)),
            m37780_1 if (m37780_1 == &Text::lit("Compare")) => prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCall(Text::lit("compare"), Array::from(vec![crate::lower::types::ref_(&a), crate::lower::types::ref_(&b)])), t.clone())),
            m37780_2 if (m37780_2 == &Text::lit("Children")) => prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCall(Text::lit("children"), Array::from(vec![crate::lower::types::ref_(&a)])), t.clone())),
            _ => prism_rtl::Turn::Finished(op_value(lx, m, &a, &b, span, t)),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start PreludeMethod, x`: what the function value is when passed to `@Run`.
pub fn start_prelude_method(lx: crate::lower::Lx, cls: Text, m: Text, vals: Array<crate::lower::types::Vl>, span: crate::syntax::Range, t: crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<crate::lower::types::Vl>> {
    Rc::new(PreludeMethod { lx, cls, m, vals, span, t })
}

/// ```prism
/// BinaryValue: unbounded fn Lx, Env, Text, Expr, Expr, Range -> Vl
/// ```
pub fn binary_value(lx: &crate::lower::Lx, env: &crate::lower::types::Env, op: &Text, l: &crate::syntax::Expr, r: &crate::syntax::Expr, span: &crate::syntax::Range) -> crate::lower::types::Vl {
    let t = crate::lower::types::out_ty_of(lx, &crate::lower::types::peel(&crate::lower::type_at(lx, span)));
    match op {
        m38208_0 if (m38208_0 == &Text::lit("and")) => crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XBin(Text::lit("&&"), Rc::new(crate::lower::types::as_bool(&value_of(lx, env, l))), Rc::new(crate::lower::types::as_bool(&value_of(lx, env, r)))), crate::lower::model::OutTy::OutBool),
        m38208_1 if (m38208_1 == &Text::lit("or")) => crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XBin(Text::lit("||"), Rc::new(crate::lower::types::as_bool(&value_of(lx, env, l))), Rc::new(crate::lower::types::as_bool(&value_of(lx, env, r)))), crate::lower::model::OutTy::OutBool),
        m38208_2 if (m38208_2 == &Text::lit("on")) => value_of(lx, env, l),
        _ => op_value(lx, op, &value_of(lx, env, l), &value_of(lx, env, r), span, &t),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `BinaryValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BinaryValue: unbounded fn Lx, Env, Text, Expr, Expr, Range -> Vl
/// ```
pub struct BinaryValue {
    pub lx: crate::lower::Lx,
    pub env: crate::lower::types::Env,
    pub op: Text,
    pub l: crate::syntax::Expr,
    pub r: crate::syntax::Expr,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<crate::lower::types::Vl> for BinaryValue {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::types::Vl> {
        let lx = &self.lx;
        let env = &self.env;
        let op = &self.op;
        let l = &self.l;
        let r = &self.r;
        let span = &self.span;
        let env = env.clone();
        let l = l.clone();
        let lx = lx.clone();
        let op = op.clone();
        let r = r.clone();
        let span = span.clone();
        call_then(crate::lower::types::start_out_ty_of(lx.clone(), crate::lower::types::peel(&crate::lower::type_at(&lx, &span))), move |out_ty_of_38167: crate::lower::model::OutTy| {
            let t = out_ty_of_38167;
            match &op {
                m38208_0 if (m38208_0 == &Text::lit("and")) => call_then(start_value_of(lx.clone(), env.clone(), l.clone()), move |value_of_38262: crate::lower::types::Vl| call_then(start_value_of(lx.clone(), env.clone(), r.clone()), move |value_of_38293: crate::lower::types::Vl| prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XBin(Text::lit("&&"), Rc::new(crate::lower::types::as_bool(&value_of_38262)), Rc::new(crate::lower::types::as_bool(&value_of_38293))), crate::lower::model::OutTy::OutBool)))),
                m38208_1 if (m38208_1 == &Text::lit("or")) => call_then(start_value_of(lx.clone(), env.clone(), l.clone()), move |value_of_38367: crate::lower::types::Vl| call_then(start_value_of(lx.clone(), env.clone(), r.clone()), move |value_of_38398: crate::lower::types::Vl| prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XBin(Text::lit("||"), Rc::new(crate::lower::types::as_bool(&value_of_38367)), Rc::new(crate::lower::types::as_bool(&value_of_38398))), crate::lower::model::OutTy::OutBool)))),
                m38208_2 if (m38208_2 == &Text::lit("on")) => prism_rtl::Turn::More(Rc::new(ValueOf { lx: lx.clone(), env: env.clone(), e: l.clone() })),
                _ => call_then(start_value_of(lx.clone(), env.clone(), l.clone()), move |value_of_38664: crate::lower::types::Vl| call_then(start_value_of(lx.clone(), env.clone(), r.clone()), move |value_of_38686: crate::lower::types::Vl| prism_rtl::Turn::Finished(op_value(&lx, &op, &value_of_38664, &value_of_38686, &span, &t)))),
                _ => unreachable!("no arm matched"),
            }
        })
    }
}

/// `Start BinaryValue, x`: what the function value is when passed to `@Run`.
pub fn start_binary_value(lx: crate::lower::Lx, env: crate::lower::types::Env, op: Text, l: crate::syntax::Expr, r: crate::syntax::Expr, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<crate::lower::types::Vl>> {
    Rc::new(BinaryValue { lx, env, op, l, r, span })
}

/// ```prism
/// OpValue: fn Lx, Text, Vl, Vl, Range, OutTy -> Vl
/// ```
pub fn op_value(lx: &crate::lower::Lx, op: &Text, a: &crate::lower::types::Vl, b: &crate::lower::types::Vl, span: &crate::syntax::Range, t: &crate::lower::model::OutTy) -> crate::lower::types::Vl {
    let at_ = crate::lower::types::value_ty(a);
    let generic = match &at_ {
        crate::lower::model::OutTy::OutGen(_) => true,
        _ => false,
    };
    if crate::check::types::has_text(&Array::from(vec![Text::lit("=="), Text::lit("!="), Text::lit("<"), Text::lit("<="), Text::lit(">"), Text::lit(">=")]), op) {
        crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XBin(op.clone(), Rc::new(crate::lower::types::ref_(a)), Rc::new(crate::lower::types::ref_(b))), crate::lower::model::OutTy::OutBool)
    } else {
        if op == &Text::lit("mod") {
            crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::types::ref_(a)), Text::lit("modulo"), Array::from(vec![crate::lower::types::ref_(b)])), t.clone())
        } else {
            if generic {
                crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCall(Text::from(format!("Num::{}", &num_method(op))), Array::from(vec![crate::lower::types::ref_(a), crate::lower::types::ref_(b)])), t.clone())
            } else {
                if op == &Text::lit("/") {
                    if &at_ == &crate::lower::model::OutTy::OutFloat {
                        crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XBin(Text::lit("/"), Rc::new(crate::lower::types::copy(a)), Rc::new(crate::lower::types::copy(b))), t.clone())
                    } else {
                        crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::types::ref_(a)), Text::lit("div"), Array::from(vec![crate::lower::types::ref_(b)])), t.clone())
                    }
                } else {
                    if op == &Text::lit("-?") {
                        if &at_ == &crate::lower::model::OutTy::OutNat {
                            crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::types::ref_(a)), Text::lit("checked_sub"), Array::from(vec![crate::lower::types::ref_(b)])), t.clone())
                        } else {
                            crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Ex::XBin(Text::lit("-"), Rc::new(crate::lower::types::ref_(a)), Rc::new(crate::lower::types::ref_(b)))])), t.clone())
                        }
                    } else {
                        if op == &Text::lit("+?") {
                            crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Ex::XBin(Text::lit("+"), Rc::new(crate::lower::types::ref_(a)), Rc::new(crate::lower::types::ref_(b)))])), t.clone())
                        } else {
                            if op == &Text::lit("*?") {
                                crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Ex::XBin(Text::lit("*"), Rc::new(crate::lower::types::ref_(a)), Rc::new(crate::lower::types::ref_(b)))])), t.clone())
                            } else {
                                if crate::lower::types::is_copy(&at_) {
                                    crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XBin(op.clone(), Rc::new(crate::lower::types::copy(a)), Rc::new(crate::lower::types::copy(b))), t.clone())
                                } else {
                                    crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XBin(op.clone(), Rc::new(crate::lower::types::ref_(a)), Rc::new(crate::lower::types::ref_(b))), t.clone())
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

/// ```prism
/// NumMethod: fn Text -> Text
/// ```
pub fn num_method(text0: &Text) -> Text {
    match text0 {
        c0_0 if (c0_0 == &Text::lit("+")) => Text::lit("add"),
        c1_0 if (c1_0 == &Text::lit("-")) => Text::lit("sub"),
        c2_0 if (c2_0 == &Text::lit("*")) => Text::lit("mul"),
        c3_0 if (c3_0 == &Text::lit("/")) => Text::lit("div_opt"),
        c4_0 if (c4_0 == &Text::lit("+?")) => Text::lit("add_opt"),
        c5_0 if (c5_0 == &Text::lit("-?")) => Text::lit("sub_opt"),
        c6_0 if (c6_0 == &Text::lit("*?")) => Text::lit("mul_opt"),
        other => Text::lit("add"),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// PreludeCall: unbounded fn Lx, Env, Text, [Arg], Range, OutTy -> Vl
/// ```
pub fn prelude_call(lx: &crate::lower::Lx, env: &crate::lower::types::Env, qk: &Text, args: &Array<crate::syntax::Arg>, span: &crate::syntax::Range, t: &crate::lower::model::OutTy) -> crate::lower::types::Vl {
    let name = or(&get(&lx.rs_names, qk), &crate::lower::snake(&crate::check::types::bare_name(qk)));
    let first_ = match index(args, &Nat::from(0u32)) {
        Some(a) => crate::lower::types::out_ty_of(lx, &crate::lower::types::peel(&crate::lower::type_at(lx, &a.value.span))),
        None => crate::lower::model::OutTy::OutUnit,
    };
    let variant = prelude_variant(&name, &first_);
    match prelude_job(lx, env, &variant, args) {
        Some(job) => crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCall(Text::lit("run_to_end"), Array::from(vec![job])), t.clone()),
        None => crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCall(crate::lower::prelude_path(lx, &variant), run_to_end(each_job(args.clone(), {
            let lx = lx.clone();
            let env = env.clone();
            Rc::new(move |p0: crate::syntax::Arg| {
                let lx = lx.clone();
                let env = env.clone();
                entered(once_job(move || {
                    let a = p0;
                    prism_rtl::Turn::More(Rc::new(Argument { lx: lx.clone(), env: env.clone(), e: a.value.clone() }))
                }))
            }) as Rc<dyn Fn(crate::syntax::Arg) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
        }))), t.clone()),
    }
}

/// The step machine of `PreludeCall`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PreludeCall: unbounded fn Lx, Env, Text, [Arg], Range, OutTy -> Vl
/// ```
pub struct PreludeCall {
    pub lx: crate::lower::Lx,
    pub env: crate::lower::types::Env,
    pub qk: Text,
    pub args: Array<crate::syntax::Arg>,
    pub span: crate::syntax::Range,
    pub t: crate::lower::model::OutTy,
}

impl prism_rtl::Job<crate::lower::types::Vl> for PreludeCall {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::types::Vl> {
        let lx = &self.lx;
        let env = &self.env;
        let qk = &self.qk;
        let args = &self.args;
        let span = &self.span;
        let t = &self.t;
        let name = or(&get(&lx.rs_names, qk), &crate::lower::snake(&crate::check::types::bare_name(qk)));
        let first_ = match index(args, &Nat::from(0u32)) {
            Some(a) => crate::lower::types::out_ty_of(lx, &crate::lower::types::peel(&crate::lower::type_at(lx, &a.value.span))),
            None => crate::lower::model::OutTy::OutUnit,
        };
        let variant = prelude_variant(&name, &first_);
        let args = args.clone();
        let env = env.clone();
        let lx = lx.clone();
        let t = t.clone();
        call_then(start_prelude_job(lx.clone(), env.clone(), variant.clone(), args.clone()), move |prelude_job_40700: Option<crate::lower::model::Ex>| match prelude_job_40700 {
            Some(job) => prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCall(Text::lit("run_to_end"), Array::from(vec![job.clone()])), t.clone())),
            None => call_value(each_job(args.clone(), {
                let lx = lx.clone();
                let env = env.clone();
                Rc::new(move |p0: crate::syntax::Arg| {
                    let lx = lx.clone();
                    let env = env.clone();
                    entered(once_job(move || {
                        let a = p0;
                        prism_rtl::Turn::More(Rc::new(Argument { lx: lx.clone(), env: env.clone(), e: a.value.clone() }))
                    }))
                }) as Rc<dyn Fn(crate::syntax::Arg) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
            }), move |each_40848: Array<crate::lower::model::Ex>| prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCall(crate::lower::prelude_path(&lx, &variant), each_40848), t.clone()))),
        })
    }
}

/// `Start PreludeCall, x`: what the function value is when passed to `@Run`.
pub fn start_prelude_call(lx: crate::lower::Lx, env: crate::lower::types::Env, qk: Text, args: Array<crate::syntax::Arg>, span: crate::syntax::Range, t: crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<crate::lower::types::Vl>> {
    Rc::new(PreludeCall { lx, env, qk, args, span, t })
}

/// ```prism
/// ?PreludeJob: unbounded fn Lx, Env, Text, [Arg] -> ?Ex
/// ```
pub fn prelude_job(lx: &crate::lower::Lx, env: &crate::lower::types::Env, variant: &Text, args: &Array<crate::syntax::Arg>) -> Option<crate::lower::model::Ex> {
    if crate::check::types::has_text(&Array::from(vec![Text::lit("fold"), Text::lit("fold_map"), Text::lit("each"), Text::lit("each_map"), Text::lit("filter"), Text::lit("filter_map")]), variant) {
        {
            let last = or(&index(args, &crate::syntax::lexer::chars::dec(&len(args))), &crate::syntax::Arg { name: None, value: dummy_expr(), span: crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) } });
            match crate::lower::types::out_ty_of(lx, &crate::lower::types::peel(&crate::lower::type_at(lx, &last.value.span))) {
                crate::lower::model::OutTy::OutJobFn(_, _) => {
                    let front_ = run_to_end(each_job(take(args, &crate::syntax::lexer::chars::dec(&len(args))), {
                        let lx = lx.clone();
                        let env = env.clone();
                        Rc::new(move |p0: crate::syntax::Arg| {
                            let lx = lx.clone();
                            let env = env.clone();
                            entered(once_job(move || {
                                let a = p0;
                                call_then(start_value_of(lx.clone(), env.clone(), a.value.clone()), move |value_of_41714: crate::lower::types::Vl| prism_rtl::Turn::Finished(crate::lower::types::own(&value_of_41714)))
                            }))
                        }) as Rc<dyn Fn(crate::syntax::Arg) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
                    }));
                    Some(crate::lower::model::Ex::XCall(Text::from(format!("{}_job", variant)), push(&front_, &as_job_value(lx, env, &last.value))))
                },
                _ => None,
            }
        }
    } else {
        None
    }
}

/// The step machine of `PreludeJob`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?PreludeJob: unbounded fn Lx, Env, Text, [Arg] -> ?Ex
/// ```
pub struct PreludeJob {
    pub lx: crate::lower::Lx,
    pub env: crate::lower::types::Env,
    pub variant: Text,
    pub args: Array<crate::syntax::Arg>,
}

impl prism_rtl::Job<Option<crate::lower::model::Ex>> for PreludeJob {
    fn cycle(&self) -> prism_rtl::Turn<Option<crate::lower::model::Ex>> {
        let lx = &self.lx;
        let env = &self.env;
        let variant = &self.variant;
        let args = &self.args;
        if crate::check::types::has_text(&Array::from(vec![Text::lit("fold"), Text::lit("fold_map"), Text::lit("each"), Text::lit("each_map"), Text::lit("filter"), Text::lit("filter_map")]), variant) {
            {
                let last = or(&index(args, &crate::syntax::lexer::chars::dec(&len(args))), &crate::syntax::Arg { name: None, value: dummy_expr(), span: crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) } });
                let args = args.clone();
                let env = env.clone();
                let lx = lx.clone();
                let variant = variant.clone();
                call_then(crate::lower::types::start_out_ty_of(lx.clone(), crate::lower::types::peel(&crate::lower::type_at(&lx, &last.value.span))), move |out_ty_of_41554: crate::lower::model::OutTy| match out_ty_of_41554 {
                    crate::lower::model::OutTy::OutJobFn(_, _) => call_value(each_job(take(&args, &crate::syntax::lexer::chars::dec(&len(&args))), {
                        let lx = lx.clone();
                        let env = env.clone();
                        Rc::new(move |p0: crate::syntax::Arg| {
                            let lx = lx.clone();
                            let env = env.clone();
                            entered(once_job(move || {
                                let a = p0;
                                call_then(start_value_of(lx.clone(), env.clone(), a.value.clone()), move |value_of_41714: crate::lower::types::Vl| prism_rtl::Turn::Finished(crate::lower::types::own(&value_of_41714)))
                            }))
                        }) as Rc<dyn Fn(crate::syntax::Arg) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
                    }), move |each_41668: Array<crate::lower::model::Ex>| {
                        let front_ = each_41668;
                        prism_rtl::Turn::Finished(Some(crate::lower::model::Ex::XCall(Text::from(format!("{}_job", &variant)), push(&front_, &as_job_value(&lx, &env, &last.value)))))
                    }),
                    _ => prism_rtl::Turn::Finished(None),
                })
            }
        } else {
            prism_rtl::Turn::Finished(None)
        }
    }
}

/// `Start PreludeJob, x`: what the function value is when passed to `@Run`.
pub fn start_prelude_job(lx: crate::lower::Lx, env: crate::lower::types::Env, variant: Text, args: Array<crate::syntax::Arg>) -> Rc<dyn prism_rtl::Job<Option<crate::lower::model::Ex>>> {
    Rc::new(PreludeJob { lx, env, variant, args })
}

/// ```prism
/// ?PreludeJobCall: unbounded fn Lx, Env, Expr -> ?Ex
/// ```
pub fn prelude_job_call(lx: &crate::lower::Lx, env: &crate::lower::types::Env, e: &crate::syntax::Expr) -> Option<crate::lower::model::Ex> {
    match &*e.kind {
        crate::syntax::ExprKind::ECall(c, args, _, _) => match &*c.kind {
            crate::syntax::ExprKind::EName(n) => if (&len(&n.path_) == &Nat::from(1u32)) && crate::check::env::has_key(&env.names, &crate::check::env::sname_key(n)) {
                None
            } else {
                {
                    let (qk_opt, _) = crate::check::env::names::resolve_value(&lx.g, &lx.home, n);
                    match &qk_opt {
                        Some(qk) => match get(&lx.g.vals, qk) {
                            Some(v_) => if &v_.home == &Text::lit("Prelude") {
                                {
                                    let name = or(&get(&lx.rs_names, qk), &crate::lower::snake(&crate::check::types::bare_name(qk)));
                                    let first_ = match index(args, &Nat::from(0u32)) {
                                        Some(a) => crate::lower::types::out_ty_of(lx, &crate::lower::types::peel(&crate::lower::type_at(lx, &a.value.span))),
                                        None => crate::lower::model::OutTy::OutUnit,
                                    };
                                    prelude_job(lx, env, &prelude_variant(&name, &first_), args)
                                }
                            } else {
                                None
                            },
                            None => None,
                        },
                        None => None,
                    }
                }
            },
            _ => None,
        },
        _ => None,
    }
}

/// The step machine of `PreludeJobCall`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?PreludeJobCall: unbounded fn Lx, Env, Expr -> ?Ex
/// ```
pub struct PreludeJobCall {
    pub lx: crate::lower::Lx,
    pub env: crate::lower::types::Env,
    pub e: crate::syntax::Expr,
}

impl prism_rtl::Job<Option<crate::lower::model::Ex>> for PreludeJobCall {
    fn cycle(&self) -> prism_rtl::Turn<Option<crate::lower::model::Ex>> {
        let lx = &self.lx;
        let env = &self.env;
        let e = &self.e;
        match &*e.kind {
            crate::syntax::ExprKind::ECall(c, args, _, _) => match &*c.kind {
                crate::syntax::ExprKind::EName(n) => if (&len(&n.path_) == &Nat::from(1u32)) && crate::check::env::has_key(&env.names, &crate::check::env::sname_key(n)) {
                    prism_rtl::Turn::Finished(None)
                } else {
                    {
                        let (qk_opt, _) = crate::check::env::names::resolve_value(&lx.g, &lx.home, n);
                        match &qk_opt {
                            Some(qk) => match get(&lx.g.vals, qk) {
                                Some(v_) => if &v_.home == &Text::lit("Prelude") {
                                    {
                                        let name = or(&get(&lx.rs_names, qk), &crate::lower::snake(&crate::check::types::bare_name(qk)));
                                        let first_ = match index(args, &Nat::from(0u32)) {
                                            Some(a) => crate::lower::types::out_ty_of(lx, &crate::lower::types::peel(&crate::lower::type_at(lx, &a.value.span))),
                                            None => crate::lower::model::OutTy::OutUnit,
                                        };
                                        prism_rtl::Turn::More(Rc::new(PreludeJob { lx: lx.clone(), env: env.clone(), variant: prelude_variant(&name, &first_), args: args.clone() }))
                                    }
                                } else {
                                    prism_rtl::Turn::Finished(None)
                                },
                                None => prism_rtl::Turn::Finished(None),
                            },
                            None => prism_rtl::Turn::Finished(None),
                        }
                    }
                },
                _ => prism_rtl::Turn::Finished(None),
            },
            _ => prism_rtl::Turn::Finished(None),
        }
    }
}

/// `Start PreludeJobCall, x`: what the function value is when passed to `@Run`.
pub fn start_prelude_job_call(lx: crate::lower::Lx, env: crate::lower::types::Env, e: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<Option<crate::lower::model::Ex>>> {
    Rc::new(PreludeJobCall { lx, env, e })
}

/// ```prism
/// AsJobValue: unbounded fn Lx, Env, Expr -> Ex
/// ```
pub fn as_job_value(lx: &crate::lower::Lx, env: &crate::lower::types::Env, e: &crate::syntax::Expr) -> crate::lower::model::Ex {
    match &*e.kind {
        crate::syntax::ExprKind::EGroup(x) => as_job_value(lx, env, &**x),
        _ => {
            let target = match crate::lower::types::peel(&crate::lower::type_at(lx, &e.span)) {
                crate::check::types::Ty::TyFn(_, ps, r) => crate::lower::model::OutTy::OutJobFn(Rc::new(crate::lower::types::rust_ty_of_params(lx, &ps)), Rc::new(crate::lower::types::out_ty_of(lx, &*r))),
                other => crate::lower::types::out_ty_of(lx, &other),
            };
            let a = match &target {
                crate::lower::model::OutTy::OutJobFn(x, _) => (**x).clone(),
                _ => crate::lower::model::OutTy::OutUnit,
            };
            match &*e.kind {
                crate::syntax::ExprKind::ELambda(ps_opt, body) => crate::lower::types::own(&job_lambda(lx, env, &or(ps_opt, &Array::new()), &**body, &target, &a, &enters_lambda(lx, e))),
                _ => {
                    let v_ = value_of(lx, env, e);
                    match crate::lower::types::value_ty(&v_) {
                        crate::lower::model::OutTy::OutFn(pts, _) => wrap_as_job(&crate::lower::types::own(&v_), &pts, &target, &a),
                        _ => crate::lower::types::own(&v_),
                    }
                },
            }
        },
    }
}

/// The step machine of `AsJobValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// AsJobValue: unbounded fn Lx, Env, Expr -> Ex
/// ```
pub struct AsJobValue {
    pub lx: crate::lower::Lx,
    pub env: crate::lower::types::Env,
    pub e: crate::syntax::Expr,
}

impl prism_rtl::Job<crate::lower::model::Ex> for AsJobValue {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::Ex> {
        let lx = &self.lx;
        let env = &self.env;
        let e = &self.e;
        match &*e.kind {
            crate::syntax::ExprKind::EGroup(x) => prism_rtl::Turn::More(Rc::new(AsJobValue { lx: lx.clone(), env: env.clone(), e: (**x).clone() })),
            _ => {
                let target = match crate::lower::types::peel(&crate::lower::type_at(lx, &e.span)) {
                    crate::check::types::Ty::TyFn(_, ps, r) => crate::lower::model::OutTy::OutJobFn(Rc::new(crate::lower::types::rust_ty_of_params(lx, &ps)), Rc::new(crate::lower::types::out_ty_of(lx, &*r))),
                    other => crate::lower::types::out_ty_of(lx, &other),
                };
                let a = match &target {
                    crate::lower::model::OutTy::OutJobFn(x, _) => (**x).clone(),
                    _ => crate::lower::model::OutTy::OutUnit,
                };
                match &*e.kind {
                    crate::syntax::ExprKind::ELambda(ps_opt, body) => {
                        let ps_opt = ps_opt.clone();
                        let body = (**body).clone();
                        let e = e.clone();
                        let env = env.clone();
                        let lx = lx.clone();
                        call_then(start_job_lambda(lx.clone(), env.clone(), or(&ps_opt, &Array::new()), body.clone(), target.clone(), a.clone(), enters_lambda(&lx, &e)), move |job_lambda_43603: crate::lower::types::Vl| prism_rtl::Turn::Finished(crate::lower::types::own(&job_lambda_43603)))
                    },
                    _ => {
                        let e = e.clone();
                        let env = env.clone();
                        let lx = lx.clone();
                        call_then(start_value_of(lx.clone(), env.clone(), e.clone()), move |value_of_43724: crate::lower::types::Vl| {
                            let v_ = value_of_43724;
                            match crate::lower::types::value_ty(&v_) {
                                crate::lower::model::OutTy::OutFn(pts, _) => prism_rtl::Turn::Finished(wrap_as_job(&crate::lower::types::own(&v_), &pts, &target, &a)),
                                _ => prism_rtl::Turn::Finished(crate::lower::types::own(&v_)),
                            }
                        })
                    },
                }
            },
        }
    }
}

/// `Start AsJobValue, x`: what the function value is when passed to `@Run`.
pub fn start_as_job_value(lx: crate::lower::Lx, env: crate::lower::types::Env, e: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>> {
    Rc::new(AsJobValue { lx, env, e })
}

/// ```prism
/// WrapAsJob: fn Ex, [OutTy], OutTy, OutTy -> Ex
/// ```
pub fn wrap_as_job(f: &crate::lower::model::Ex, pts: &Array<crate::lower::model::OutTy>, target: &crate::lower::model::OutTy, a: &crate::lower::model::OutTy) -> crate::lower::model::Ex {
    let names = each(&crate::check::errors::range0(&len(pts)), &(|i: &Nat| Text::from(format!("a{}", i))));
    let pa = if &len(pts) == &Nat::from(1u32) {
        crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaBind(Text::lit("a0"))), a.clone())
    } else {
        crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaTuple(each(&names, &(|nm: &Text| crate::lower::model::Pa::PaBind(nm.clone()))))), a.clone())
    };
    let call = crate::lower::model::Ex::XApply(Rc::new(crate::lower::model::Ex::XVar(Text::lit("f"))), each(&names, &(|nm: &Text| crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XVar(nm.clone()))))));
    let body = crate::lower::model::Ex::XBlock(Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(Text::lit("f")), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(Text::lit("f")))))]), Rc::new(crate::lower::model::Ex::XCall(Text::lit("once_job"), Array::from(vec![crate::lower::model::Ex::XClosure(true, Array::new(), Rc::new(crate::lower::model::Ex::XCtor(Text::lit("prism_rtl::Turn::Finished"), Array::from(vec![call.clone()]))))]))));
    crate::lower::model::Ex::XBlock(Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(Text::lit("f")), f.clone())]), Rc::new(crate::lower::model::Ex::XCast(Rc::new(crate::lower::model::Ex::XCall(Text::lit("Rc::new"), Array::from(vec![crate::lower::model::Ex::XClosure(true, Array::from(vec![pa.clone()]), Rc::new(body.clone()))]))), target.clone())))
}

/// ```prism
/// NamedArgsOwned: unbounded fn Lx, Env, Text, [Arg] -> [Ex]
/// ```
pub fn named_args_owned(lx: &crate::lower::Lx, env: &crate::lower::types::Env, qk: &Text, args: &Array<crate::syntax::Arg>) -> Array<crate::lower::model::Ex> {
    let (ps, _) = crate::lower::jobs::scheme_parts(lx, qk);
    run_to_end(each_job(crate::check::errors::range0(&len(args)), {
        let args = args.clone();
        let ps = ps.clone();
        let lx = lx.clone();
        let env = env.clone();
        Rc::new(move |p0: Nat| {
            let args = args.clone();
            let ps = ps.clone();
            let lx = lx.clone();
            let env = env.clone();
            entered(once_job(move || {
                let i = p0;
                {
                    let a = or(&index(&args, &i), &crate::syntax::Arg { name: None, value: dummy_expr(), span: crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) } });
                    match crate::lower::types::peel(&or(&index(&ps, &i), &crate::check::types::Ty::TyErr)) {
                        crate::check::types::Ty::TyFn(crate::check::types::Col::CBound, _, _) => call_then(start_value_of(lx.clone(), env.clone(), a.value.clone()), move |value_of_45027: crate::lower::types::Vl| prism_rtl::Turn::Finished(crate::lower::types::own(&value_of_45027))),
                        crate::check::types::Ty::TyFn(_, _, _) => prism_rtl::Turn::More(Rc::new(AsJobValue { lx: lx.clone(), env: env.clone(), e: a.value.clone() })),
                        _ => call_then(start_value_of(lx.clone(), env.clone(), a.value.clone()), move |value_of_45150: crate::lower::types::Vl| prism_rtl::Turn::Finished(crate::lower::types::own(&value_of_45150))),
                    }
                }
            }))
        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
    }))
}

/// The step machine of `NamedArgsOwned`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// NamedArgsOwned: unbounded fn Lx, Env, Text, [Arg] -> [Ex]
/// ```
pub struct NamedArgsOwned {
    pub lx: crate::lower::Lx,
    pub env: crate::lower::types::Env,
    pub qk: Text,
    pub args: Array<crate::syntax::Arg>,
}

impl prism_rtl::Job<Array<crate::lower::model::Ex>> for NamedArgsOwned {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::lower::model::Ex>> {
        let lx = &self.lx;
        let env = &self.env;
        let qk = &self.qk;
        let args = &self.args;
        let (ps, _) = crate::lower::jobs::scheme_parts(lx, qk);
        each_job(crate::check::errors::range0(&len(args)), {
            let args = args.clone();
            let ps = ps.clone();
            let lx = lx.clone();
            let env = env.clone();
            Rc::new(move |p0: Nat| {
                let args = args.clone();
                let ps = ps.clone();
                let lx = lx.clone();
                let env = env.clone();
                entered(once_job(move || {
                    let i = p0;
                    {
                        let a = or(&index(&args, &i), &crate::syntax::Arg { name: None, value: dummy_expr(), span: crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) } });
                        match crate::lower::types::peel(&or(&index(&ps, &i), &crate::check::types::Ty::TyErr)) {
                            crate::check::types::Ty::TyFn(crate::check::types::Col::CBound, _, _) => call_then(start_value_of(lx.clone(), env.clone(), a.value.clone()), move |value_of_45027: crate::lower::types::Vl| prism_rtl::Turn::Finished(crate::lower::types::own(&value_of_45027))),
                            crate::check::types::Ty::TyFn(_, _, _) => prism_rtl::Turn::More(Rc::new(AsJobValue { lx: lx.clone(), env: env.clone(), e: a.value.clone() })),
                            _ => call_then(start_value_of(lx.clone(), env.clone(), a.value.clone()), move |value_of_45150: crate::lower::types::Vl| prism_rtl::Turn::Finished(crate::lower::types::own(&value_of_45150))),
                        }
                    }
                }))
            }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
        }).cycle()
    }
}

/// `Start NamedArgsOwned, x`: what the function value is when passed to `@Run`.
pub fn start_named_args_owned(lx: crate::lower::Lx, env: crate::lower::types::Env, qk: Text, args: Array<crate::syntax::Arg>) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Ex>>> {
    Rc::new(NamedArgsOwned { lx, env, qk, args })
}

/// ```prism
/// StartArgs: unbounded fn Lx, Env, Vl, [Arg] -> [Ex]
/// ```
pub fn start_args(lx: &crate::lower::Lx, env: &crate::lower::types::Env, f: &crate::lower::types::Vl, args: &Array<crate::syntax::Arg>) -> Array<crate::lower::model::Ex> {
    let pts = 'm45362: {
        let scrutinee = &crate::lower::types::value_ty(f);
        if let crate::lower::model::OutTy::OutJobFn(m45362_0_0, _) = scrutinee && let crate::lower::model::OutTy::OutTuple(ts) = &**m45362_0_0 {
            break 'm45362 if &len(args) == &Nat::from(1u32) {
                Array::from(vec![crate::lower::model::OutTy::OutTuple(ts.clone())])
            } else {
                ts.clone()
            };
        }
        if let crate::lower::model::OutTy::OutJobFn(a, _) = scrutinee {
            break 'm45362 Array::from(vec![(**a).clone()]);
        }
        Array::new()
    };
    run_to_end(each_job(crate::check::errors::range0(&len(args)), {
        let args = args.clone();
        let pts = pts.clone();
        let lx = lx.clone();
        let env = env.clone();
        Rc::new(move |p0: Nat| {
            let args = args.clone();
            let pts = pts.clone();
            let lx = lx.clone();
            let env = env.clone();
            entered(once_job(move || {
                let i = p0;
                {
                    let a = or(&index(&args, &i), &crate::syntax::Arg { name: None, value: dummy_expr(), span: crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) } });
                    match or(&index(&pts, &i), &crate::lower::model::OutTy::OutUnit) {
                        crate::lower::model::OutTy::OutJobFn(_, _) => prism_rtl::Turn::More(Rc::new(AsJobValue { lx: lx.clone(), env: env.clone(), e: a.value.clone() })),
                        _ => call_then(start_value_of(lx.clone(), env.clone(), a.value.clone()), move |value_of_45773: crate::lower::types::Vl| prism_rtl::Turn::Finished(crate::lower::types::own(&value_of_45773))),
                    }
                }
            }))
        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
    }))
}

/// The step machine of `StartArgs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// StartArgs: unbounded fn Lx, Env, Vl, [Arg] -> [Ex]
/// ```
pub struct StartArgs {
    pub lx: crate::lower::Lx,
    pub env: crate::lower::types::Env,
    pub f: crate::lower::types::Vl,
    pub args: Array<crate::syntax::Arg>,
}

impl prism_rtl::Job<Array<crate::lower::model::Ex>> for StartArgs {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::lower::model::Ex>> {
        let lx = &self.lx;
        let env = &self.env;
        let f = &self.f;
        let args = &self.args;
        let pts = 'm45362: {
            let scrutinee = &crate::lower::types::value_ty(f);
            if let crate::lower::model::OutTy::OutJobFn(m45362_0_0, _) = scrutinee && let crate::lower::model::OutTy::OutTuple(ts) = &**m45362_0_0 {
                break 'm45362 if &len(args) == &Nat::from(1u32) {
                    Array::from(vec![crate::lower::model::OutTy::OutTuple(ts.clone())])
                } else {
                    ts.clone()
                };
            }
            if let crate::lower::model::OutTy::OutJobFn(a, _) = scrutinee {
                break 'm45362 Array::from(vec![(**a).clone()]);
            }
            Array::new()
        };
        each_job(crate::check::errors::range0(&len(args)), {
            let args = args.clone();
            let pts = pts.clone();
            let lx = lx.clone();
            let env = env.clone();
            Rc::new(move |p0: Nat| {
                let args = args.clone();
                let pts = pts.clone();
                let lx = lx.clone();
                let env = env.clone();
                entered(once_job(move || {
                    let i = p0;
                    {
                        let a = or(&index(&args, &i), &crate::syntax::Arg { name: None, value: dummy_expr(), span: crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) } });
                        match or(&index(&pts, &i), &crate::lower::model::OutTy::OutUnit) {
                            crate::lower::model::OutTy::OutJobFn(_, _) => prism_rtl::Turn::More(Rc::new(AsJobValue { lx: lx.clone(), env: env.clone(), e: a.value.clone() })),
                            _ => call_then(start_value_of(lx.clone(), env.clone(), a.value.clone()), move |value_of_45773: crate::lower::types::Vl| prism_rtl::Turn::Finished(crate::lower::types::own(&value_of_45773))),
                        }
                    }
                }))
            }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
        }).cycle()
    }
}

/// `Start StartArgs, x`: what the function value is when passed to `@Run`.
pub fn start_start_args(lx: crate::lower::Lx, env: crate::lower::types::Env, f: crate::lower::types::Vl, args: Array<crate::syntax::Arg>) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Ex>>> {
    Rc::new(StartArgs { lx, env, f, args })
}

/// ```prism
/// PreludeVariant: fn Text, OutTy -> Text
/// ```
pub fn prelude_variant(name: &Text, first_: &crate::lower::model::OutTy) -> Text {
    match first_ {
        crate::lower::model::OutTy::OutText => if name == &Text::lit("len") { Text::lit("len_text") } else { name.clone() },
        crate::lower::model::OutTy::OutMap(_, _) => if crate::check::types::has_text(&Array::from(vec![Text::lit("len"), Text::lit("fold"), Text::lit("each"), Text::lit("filter")]), name) {
            Text::from(format!("{}_map", name))
        } else {
            name.clone()
        },
        _ => name.clone(),
    }
}

/// ```prism
/// FieldValue: unbounded fn Lx, Env, Expr, Text -> Vl
/// ```
pub fn field_value(lx: &crate::lower::Lx, env: &crate::lower::types::Env, r: &crate::syntax::Expr, name: &Text) -> crate::lower::types::Vl {
    let rv = value_of(lx, env, r);
    let rty = crate::lower::types::peel(&crate::lower::type_at(lx, &r.span));
    let (ft, rc_) = field_info(lx, &rty, name);
    let f = crate::lower::snake(name);
    let mode = if rc_ {
        crate::lower::types::Holding::RcOwned
    } else {
        crate::lower::types::Holding::Owned
    };
    match &rv {
        crate::lower::types::Vl::VlPlace(x, _, _) => crate::lower::types::Vl::VlPlace(crate::lower::model::Ex::XField(Rc::new(x.clone()), f.clone()), mode.clone(), ft.clone()),
        crate::lower::types::Vl::VlOwned(x, _) => crate::lower::types::Vl::VlPlace(crate::lower::model::Ex::XField(Rc::new(x.clone()), f.clone()), mode.clone(), ft.clone()),
    }
}

/// The step machine of `FieldValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FieldValue: unbounded fn Lx, Env, Expr, Text -> Vl
/// ```
pub struct FieldValue {
    pub lx: crate::lower::Lx,
    pub env: crate::lower::types::Env,
    pub r: crate::syntax::Expr,
    pub name: Text,
}

impl prism_rtl::Job<crate::lower::types::Vl> for FieldValue {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::types::Vl> {
        let lx = &self.lx;
        let env = &self.env;
        let r = &self.r;
        let name = &self.name;
        let env = env.clone();
        let lx = lx.clone();
        let name = name.clone();
        let r = r.clone();
        call_then(start_value_of(lx.clone(), env.clone(), r.clone()), move |value_of_46268: crate::lower::types::Vl| {
            let rv = value_of_46268;
            let rty = crate::lower::types::peel(&crate::lower::type_at(&lx, &r.span));
            call_then(start_field_info(lx.clone(), rty.clone(), name.clone()), move |field_info_46347: (crate::lower::model::OutTy, bool)| {
                let (ft, rc_) = field_info_46347;
                let f = crate::lower::snake(&name);
                let mode = if rc_ {
                    crate::lower::types::Holding::RcOwned
                } else {
                    crate::lower::types::Holding::Owned
                };
                match &rv {
                    crate::lower::types::Vl::VlPlace(x, _, _) => prism_rtl::Turn::Finished(crate::lower::types::Vl::VlPlace(crate::lower::model::Ex::XField(Rc::new(x.clone()), f.clone()), mode.clone(), ft.clone())),
                    crate::lower::types::Vl::VlOwned(x, _) => prism_rtl::Turn::Finished(crate::lower::types::Vl::VlPlace(crate::lower::model::Ex::XField(Rc::new(x.clone()), f.clone()), mode.clone(), ft.clone())),
                }
            })
        })
    }
}

/// `Start FieldValue, x`: what the function value is when passed to `@Run`.
pub fn start_field_value(lx: crate::lower::Lx, env: crate::lower::types::Env, r: crate::syntax::Expr, name: Text) -> Rc<dyn prism_rtl::Job<crate::lower::types::Vl>> {
    Rc::new(FieldValue { lx, env, r, name })
}

/// ```prism
/// FieldInfo: unbounded fn Lx, Ty, Text -> ((OutTy, Bool))
/// ```
pub fn field_info(lx: &crate::lower::Lx, rty: &crate::check::types::Ty, name: &Text) -> (crate::lower::model::OutTy, bool) {
    match rty {
        crate::check::types::Ty::TyCon(n, args) => match get(&lx.g.ctors, n) {
            Some(c) => {
                let fix_opt = fold(&crate::check::errors::range0(&len(&c.fields)), &None, &(|found_opt: &Option<Nat>, i: &Nat| if &or(&index(&c.fields, i), &Text::lit("")) == name {
                    Some(i.clone())
                } else {
                    found_opt.clone()
                }));
                match &fix_opt {
                    Some(i) => {
                        let ft = or(&index(&c.args, i), &crate::check::types::Ty::TyErr);
                        let inst = instantiated(&ft, &c.params, args);
                        (crate::lower::types::out_ty_of(lx, &inst), crate::lower::types::rc_field(lx, &c.name, i))
                    },
                    None => (crate::lower::model::OutTy::OutUnknown(Text::from(format!("a field {}", name))), false),
                }
            },
            None => (crate::lower::model::OutTy::OutUnknown(Text::from(format!("a field {}", name))), false),
        },
        _ => (crate::lower::model::OutTy::OutUnknown(Text::from(format!("a field {} of a non-record", name))), false),
    }
}

/// The step machine of `FieldInfo`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FieldInfo: unbounded fn Lx, Ty, Text -> ((OutTy, Bool))
/// ```
pub struct FieldInfo {
    pub lx: crate::lower::Lx,
    pub rty: crate::check::types::Ty,
    pub name: Text,
}

impl prism_rtl::Job<(crate::lower::model::OutTy, bool)> for FieldInfo {
    fn cycle(&self) -> prism_rtl::Turn<(crate::lower::model::OutTy, bool)> {
        let lx = &self.lx;
        let rty = &self.rty;
        let name = &self.name;
        match rty {
            crate::check::types::Ty::TyCon(n, args) => match get(&lx.g.ctors, n) {
                Some(c) => {
                    let fix_opt = fold(&crate::check::errors::range0(&len(&c.fields)), &None, &(|found_opt: &Option<Nat>, i: &Nat| if &or(&index(&c.fields, i), &Text::lit("")) == name {
                        Some(i.clone())
                    } else {
                        found_opt.clone()
                    }));
                    match &fix_opt {
                        Some(i) => {
                            let ft = or(&index(&c.args, i), &crate::check::types::Ty::TyErr);
                            let args = args.clone();
                            let i = i.clone();
                            let lx = lx.clone();
                            let name = name.clone();
                            call_then(start_instantiated(ft.clone(), c.params.clone(), args.clone()), move |instantiated_47035: crate::check::types::Ty| {
                                let inst = instantiated_47035;
                                call_then(crate::lower::types::start_out_ty_of(lx.clone(), inst.clone()), move |out_ty_of_47090: crate::lower::model::OutTy| prism_rtl::Turn::Finished((out_ty_of_47090, crate::lower::types::rc_field(&lx, &c.name, &i))))
                            })
                        },
                        None => prism_rtl::Turn::Finished((crate::lower::model::OutTy::OutUnknown(Text::from(format!("a field {}", name))), false)),
                    }
                },
                None => prism_rtl::Turn::Finished((crate::lower::model::OutTy::OutUnknown(Text::from(format!("a field {}", name))), false)),
            },
            _ => prism_rtl::Turn::Finished((crate::lower::model::OutTy::OutUnknown(Text::from(format!("a field {} of a non-record", name))), false)),
        }
    }
}

/// `Start FieldInfo, x`: what the function value is when passed to `@Run`.
pub fn start_field_info(lx: crate::lower::Lx, rty: crate::check::types::Ty, name: Text) -> Rc<dyn prism_rtl::Job<(crate::lower::model::OutTy, bool)>> {
    Rc::new(FieldInfo { lx, rty, name })
}

/// ```prism
/// Instantiated: unbounded fn Ty, [Text], [Ty] -> Ty
/// ```
pub fn instantiated(t: &crate::check::types::Ty, params: &Array<Text>, args: &Array<crate::check::types::Ty>) -> crate::check::types::Ty {
    match t {
        crate::check::types::Ty::TyQ(q) => {
            let hit_opt = fold(&crate::check::errors::range0(&len(params)), &None, &(|found_opt: &Option<crate::check::types::Ty>, i: &Nat| if &or(&index(params, i), &Text::lit("")) == q {
                index(args, i)
            } else {
                found_opt.clone()
            }));
            or(&hit_opt, t)
        },
        crate::check::types::Ty::TyCon(n, xs) => crate::check::types::Ty::TyCon(n.clone(), run_to_end(each_job(xs.clone(), {
            let params = params.clone();
            let args = args.clone();
            Rc::new(move |p0: crate::check::types::Ty| {
                let params = params.clone();
                let args = args.clone();
                entered(once_job(move || {
                    let x = p0;
                    prism_rtl::Turn::More(Rc::new(Instantiated { t: x.clone(), params: params.clone(), args: args.clone() }))
                }))
            }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
        }))),
        crate::check::types::Ty::TyFn(c, ps, res) => crate::check::types::Ty::TyFn(c.clone(), run_to_end(each_job(ps.clone(), {
            let params = params.clone();
            let args = args.clone();
            Rc::new(move |p0: crate::check::types::Ty| {
                let params = params.clone();
                let args = args.clone();
                entered(once_job(move || {
                    let x = p0;
                    prism_rtl::Turn::More(Rc::new(Instantiated { t: x.clone(), params: params.clone(), args: args.clone() }))
                }))
            }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
        })), Rc::new(instantiated(&**res, params, args))),
        crate::check::types::Ty::TyTuple(ts) => crate::check::types::Ty::TyTuple(run_to_end(each_job(ts.clone(), {
            let params = params.clone();
            let args = args.clone();
            Rc::new(move |p0: crate::check::types::Ty| {
                let params = params.clone();
                let args = args.clone();
                entered(once_job(move || {
                    let x = p0;
                    prism_rtl::Turn::More(Rc::new(Instantiated { t: x.clone(), params: params.clone(), args: args.clone() }))
                }))
            }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
        }))),
        crate::check::types::Ty::TyArray(e) => crate::check::types::Ty::TyArray(Rc::new(instantiated(&**e, params, args))),
        crate::check::types::Ty::TyMap(k, v_) => crate::check::types::Ty::TyMap(Rc::new(instantiated(&**k, params, args)), Rc::new(instantiated(&**v_, params, args))),
        crate::check::types::Ty::TySig(s, i) => crate::check::types::Ty::TySig(s.clone(), Rc::new(instantiated(&**i, params, args))),
        _ => t.clone(),
    }
}

/// The step machine of `Instantiated`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Instantiated: unbounded fn Ty, [Text], [Ty] -> Ty
/// ```
pub struct Instantiated {
    pub t: crate::check::types::Ty,
    pub params: Array<Text>,
    pub args: Array<crate::check::types::Ty>,
}

impl prism_rtl::Job<crate::check::types::Ty> for Instantiated {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::Ty> {
        let t = &self.t;
        let params = &self.params;
        let args = &self.args;
        match t {
            crate::check::types::Ty::TyQ(q) => {
                let hit_opt = fold(&crate::check::errors::range0(&len(params)), &None, &(|found_opt: &Option<crate::check::types::Ty>, i: &Nat| if &or(&index(params, i), &Text::lit("")) == q {
                    index(args, i)
                } else {
                    found_opt.clone()
                }));
                prism_rtl::Turn::Finished(or(&hit_opt, t))
            },
            crate::check::types::Ty::TyCon(n, xs) => {
                let args = args.clone();
                let n = n.clone();
                let params = params.clone();
                let xs = xs.clone();
                call_value(each_job(xs.clone(), {
                    let params = params.clone();
                    let args = args.clone();
                    Rc::new(move |p0: crate::check::types::Ty| {
                        let params = params.clone();
                        let args = args.clone();
                        entered(once_job(move || {
                            let x = p0;
                            prism_rtl::Turn::More(Rc::new(Instantiated { t: x.clone(), params: params.clone(), args: args.clone() }))
                        }))
                    }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
                }), move |each_47670: Array<crate::check::types::Ty>| prism_rtl::Turn::Finished(crate::check::types::Ty::TyCon(n.clone(), each_47670)))
            },
            crate::check::types::Ty::TyFn(c, ps, res) => {
                let args = args.clone();
                let c = c.clone();
                let params = params.clone();
                let ps = ps.clone();
                let res = (**res).clone();
                call_value(each_job(ps.clone(), {
                    let params = params.clone();
                    let args = args.clone();
                    Rc::new(move |p0: crate::check::types::Ty| {
                        let params = params.clone();
                        let args = args.clone();
                        entered(once_job(move || {
                            let x = p0;
                            prism_rtl::Turn::More(Rc::new(Instantiated { t: x.clone(), params: params.clone(), args: args.clone() }))
                        }))
                    }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
                }), move |each_47744: Array<crate::check::types::Ty>| call_then(start_instantiated(res.clone(), params.clone(), args.clone()), move |instantiated_47790: crate::check::types::Ty| prism_rtl::Turn::Finished(crate::check::types::Ty::TyFn(c.clone(), each_47744, Rc::new(instantiated_47790)))))
            },
            crate::check::types::Ty::TyTuple(ts) => {
                let args = args.clone();
                let params = params.clone();
                let ts = ts.clone();
                call_value(each_job(ts.clone(), {
                    let params = params.clone();
                    let args = args.clone();
                    Rc::new(move |p0: crate::check::types::Ty| {
                        let params = params.clone();
                        let args = args.clone();
                        entered(once_job(move || {
                            let x = p0;
                            prism_rtl::Turn::More(Rc::new(Instantiated { t: x.clone(), params: params.clone(), args: args.clone() }))
                        }))
                    }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
                }), move |each_47847: Array<crate::check::types::Ty>| prism_rtl::Turn::Finished(crate::check::types::Ty::TyTuple(each_47847)))
            },
            crate::check::types::Ty::TyArray(e) => {
                let args = args.clone();
                let e = (**e).clone();
                let params = params.clone();
                call_then(start_instantiated(e.clone(), params.clone(), args.clone()), move |instantiated_47915: crate::check::types::Ty| prism_rtl::Turn::Finished(crate::check::types::Ty::TyArray(Rc::new(instantiated_47915))))
            },
            crate::check::types::Ty::TyMap(k, v_) => {
                let args = args.clone();
                let k = (**k).clone();
                let params = params.clone();
                let v_ = (**v_).clone();
                call_then(start_instantiated(k.clone(), params.clone(), args.clone()), move |instantiated_47968: crate::check::types::Ty| call_then(start_instantiated(v_.clone(), params.clone(), args.clone()), move |instantiated_48000: crate::check::types::Ty| prism_rtl::Turn::Finished(crate::check::types::Ty::TyMap(Rc::new(instantiated_47968), Rc::new(instantiated_48000)))))
            },
            crate::check::types::Ty::TySig(s, i) => {
                let args = args.clone();
                let i = (**i).clone();
                let params = params.clone();
                let s = s.clone();
                call_then(start_instantiated(i.clone(), params.clone(), args.clone()), move |instantiated_48056: crate::check::types::Ty| prism_rtl::Turn::Finished(crate::check::types::Ty::TySig(s.clone(), Rc::new(instantiated_48056))))
            },
            _ => prism_rtl::Turn::Finished(t.clone()),
        }
    }
}

/// `Start Instantiated, x`: what the function value is when passed to `@Run`.
pub fn start_instantiated(t: crate::check::types::Ty, params: Array<Text>, args: Array<crate::check::types::Ty>) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>> {
    Rc::new(Instantiated { t, params, args })
}

/// ```prism
/// IndexValue: unbounded fn Lx, Env, Expr, Expr, OutTy -> Vl
/// ```
pub fn index_value(lx: &crate::lower::Lx, env: &crate::lower::types::Env, r: &crate::syntax::Expr, i: &crate::syntax::Expr, t: &crate::lower::model::OutTy) -> crate::lower::types::Vl {
    let rt = crate::lower::types::out_ty_of(lx, &crate::lower::types::peel(&crate::lower::type_at(lx, &r.span)));
    let f = match &rt {
        crate::lower::model::OutTy::OutMap(_, _) => Text::lit("get"),
        _ => Text::lit("index"),
    };
    crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCall(f.clone(), Array::from(vec![argument(lx, env, r), argument(lx, env, i)])), crate::lower::model::OutTy::OutOpt(Rc::new(t.clone())))
}

/// The step machine of `IndexValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// IndexValue: unbounded fn Lx, Env, Expr, Expr, OutTy -> Vl
/// ```
pub struct IndexValue {
    pub lx: crate::lower::Lx,
    pub env: crate::lower::types::Env,
    pub r: crate::syntax::Expr,
    pub i: crate::syntax::Expr,
    pub t: crate::lower::model::OutTy,
}

impl prism_rtl::Job<crate::lower::types::Vl> for IndexValue {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::types::Vl> {
        let lx = &self.lx;
        let env = &self.env;
        let r = &self.r;
        let i = &self.i;
        let t = &self.t;
        let env = env.clone();
        let i = i.clone();
        let lx = lx.clone();
        let r = r.clone();
        let t = t.clone();
        call_then(crate::lower::types::start_out_ty_of(lx.clone(), crate::lower::types::peel(&crate::lower::type_at(&lx, &r.span))), move |out_ty_of_48299: crate::lower::model::OutTy| {
            let rt = out_ty_of_48299;
            let f = match &rt {
                crate::lower::model::OutTy::OutMap(_, _) => Text::lit("get"),
                _ => Text::lit("index"),
            };
            call_then(start_argument(lx.clone(), env.clone(), r.clone()), move |argument_48449: crate::lower::model::Ex| call_then(start_argument(lx.clone(), env.clone(), i.clone()), move |argument_48472: crate::lower::model::Ex| prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCall(f.clone(), Array::from(vec![argument_48449, argument_48472])), crate::lower::model::OutTy::OutOpt(Rc::new(t.clone()))))))
        })
    }
}

/// `Start IndexValue, x`: what the function value is when passed to `@Run`.
pub fn start_index_value(lx: crate::lower::Lx, env: crate::lower::types::Env, r: crate::syntax::Expr, i: crate::syntax::Expr, t: crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<crate::lower::types::Vl>> {
    Rc::new(IndexValue { lx, env, r, i, t })
}

/// ```prism
/// ReadNames: unbounded fn [Expr] -> [Text]
/// ```
pub fn read_names(es: &Array<crate::syntax::Expr>) -> Array<Text> {
    fold(es, &Array::new(), &(|acc: &Array<Text>, x: &crate::syntax::Expr| match &*x.kind {
        crate::syntax::ExprKind::EName(n) => if &len(&n.path_) == &Nat::from(1u32) {
            crate::check::types::add_text(acc, &crate::check::env::sname_key(n))
        } else {
            acc.clone()
        },
        _ => acc.clone(),
    }))
}

/// The step machine of `ReadNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ReadNames: unbounded fn [Expr] -> [Text]
/// ```
pub struct ReadNames {
    pub es: Array<crate::syntax::Expr>,
}

impl prism_rtl::Job<Array<Text>> for ReadNames {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let es = &self.es;
        prism_rtl::Turn::Finished(fold(es, &Array::new(), &(|acc: &Array<Text>, x: &crate::syntax::Expr| match &*x.kind {
            crate::syntax::ExprKind::EName(n) => if &len(&n.path_) == &Nat::from(1u32) {
                crate::check::types::add_text(acc, &crate::check::env::sname_key(n))
            } else {
                acc.clone()
            },
            _ => acc.clone(),
        })))
    }
}

/// `Start ReadNames, x`: what the function value is when passed to `@Run`.
pub fn start_read_names(es: Array<crate::syntax::Expr>) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(ReadNames { es })
}

/// ```prism
/// LambdaExprs: unbounded fn LambdaBody -> [Expr]
/// ```
pub fn lambda_exprs(lambda_body0: &crate::syntax::LambdaBody) -> Array<crate::syntax::Expr> {
    match lambda_body0 {
        crate::syntax::LambdaBody::LbExpr(x) => crate::check::typed::print::exprs_in(&**x),
        crate::syntax::LambdaBody::LbBlock(b) => crate::check::typed::print::block_exprs(b),
    }
}

/// The step machine of `LambdaExprs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LambdaExprs: unbounded fn LambdaBody -> [Expr]
/// ```
pub struct LambdaExprs {
    pub lambda_body0: crate::syntax::LambdaBody,
}

impl prism_rtl::Job<Array<crate::syntax::Expr>> for LambdaExprs {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::syntax::Expr>> {
        let lambda_body0 = &self.lambda_body0;
        match lambda_body0 {
            crate::syntax::LambdaBody::LbExpr(x) => prism_rtl::Turn::More(Rc::new(crate::check::typed::print::ExprsIn { e: (**x).clone() })),
            crate::syntax::LambdaBody::LbBlock(b) => prism_rtl::Turn::More(Rc::new(crate::check::typed::print::BlockExprs { b: b.clone() })),
        }
    }
}

/// `Start LambdaExprs, x`: what the function value is when passed to `@Run`.
pub fn start_lambda_exprs(lambda_body0: crate::syntax::LambdaBody) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>> {
    Rc::new(LambdaExprs { lambda_body0 })
}

/// ```prism
/// LambdaValue: unbounded fn Lx, Env, Expr, [Pattern], LambdaBody -> Vl
/// ```
pub fn lambda_value(lx: &crate::lower::Lx, env: &crate::lower::types::Env, e: &crate::syntax::Expr, ps: &Array<crate::syntax::Pattern_>, body: &crate::syntax::LambdaBody) -> crate::lower::types::Vl {
    let ft = crate::lower::types::out_ty_of(lx, &crate::lower::types::peel(&crate::lower::type_at(lx, &e.span)));
    match &ft {
        crate::lower::model::OutTy::OutJobFn(a, _) => job_lambda(lx, env, ps, body, &ft, &**a, &enters_lambda(lx, e)),
        _ => plain_lambda(lx, env, ps, body, &ft),
    }
}

/// The step machine of `LambdaValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LambdaValue: unbounded fn Lx, Env, Expr, [Pattern], LambdaBody -> Vl
/// ```
pub struct LambdaValue {
    pub lx: crate::lower::Lx,
    pub env: crate::lower::types::Env,
    pub e: crate::syntax::Expr,
    pub ps: Array<crate::syntax::Pattern_>,
    pub body: crate::syntax::LambdaBody,
}

impl prism_rtl::Job<crate::lower::types::Vl> for LambdaValue {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::types::Vl> {
        let lx = &self.lx;
        let env = &self.env;
        let e = &self.e;
        let ps = &self.ps;
        let body = &self.body;
        let body = body.clone();
        let e = e.clone();
        let env = env.clone();
        let lx = lx.clone();
        let ps = ps.clone();
        call_then(crate::lower::types::start_out_ty_of(lx.clone(), crate::lower::types::peel(&crate::lower::type_at(&lx, &e.span))), move |out_ty_of_49139: crate::lower::model::OutTy| {
            let ft = out_ty_of_49139;
            match &ft {
                crate::lower::model::OutTy::OutJobFn(a, _) => prism_rtl::Turn::More(Rc::new(JobLambda { lx: lx.clone(), env: env.clone(), ps: ps.clone(), body: body.clone(), ft: ft.clone(), a: (**a).clone(), enter: enters_lambda(&lx, &e) })),
                _ => prism_rtl::Turn::More(Rc::new(PlainLambda { lx: lx.clone(), env: env.clone(), ps: ps.clone(), body: body.clone(), ft: ft.clone() })),
            }
        })
    }
}

/// `Start LambdaValue, x`: what the function value is when passed to `@Run`.
pub fn start_lambda_value(lx: crate::lower::Lx, env: crate::lower::types::Env, e: crate::syntax::Expr, ps: Array<crate::syntax::Pattern_>, body: crate::syntax::LambdaBody) -> Rc<dyn prism_rtl::Job<crate::lower::types::Vl>> {
    Rc::new(LambdaValue { lx, env, e, ps, body })
}

/// ```prism
/// PlainLambda: unbounded fn Lx, Env, [Pattern], LambdaBody, OutTy -> Vl
/// ```
pub fn plain_lambda(lx: &crate::lower::Lx, env: &crate::lower::types::Env, ps: &Array<crate::syntax::Pattern_>, body: &crate::syntax::LambdaBody, ft: &crate::lower::model::OutTy) -> crate::lower::types::Vl {
    let pts = match ft {
        crate::lower::model::OutTy::OutFn(xs, _) => xs.clone(),
        _ => Array::new(),
    };
    let read = crate::lower::types::with_instances(env, &read_names(&lambda_exprs(body)));
    let caps0 = filter(&read, &(|n: &Text| match get(&env.names, n) {
        Some(crate::lower::types::Bn::BnLocal(_, _, _)) => true,
        _ => false,
    }));
    let caps = append(&append(&caps0, &filter(&each(&read, &(|n: &Text| Text::from(format!("{}#port", n)))), &(|n: &Text| crate::check::env::has_key(&env.names, n)))), &filter(&each(&read, &(|n: &Text| Text::from(format!("{}#init", n)))), &(|n: &Text| crate::check::env::has_key(&env.names, n))));
    let (dos, env1) = fold(&caps, &(Array::new(), env.clone()), &(|(acc, en): &(Array<crate::lower::model::Do>, crate::lower::types::Env), n: &Text| match get(&env.names, n) {
        Some(crate::lower::types::Bn::BnLocal(rs, mode, ct)) => {
            let local = crate::lower::types::place_stem(&rs);
            let d = crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(local.clone()), crate::lower::types::own(&crate::lower::types::local_place(&rs, &mode, &ct)));
            (push(acc, &d), crate::lower::types::bind(en, n, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(local.clone()), crate::lower::types::Holding::Owned, ct.clone())))
        },
        _ => (acc.clone(), en.clone()),
    }));
    let (pas, env2) = closure_params(lx, &env1, ps, &pts, &true);
    let v_ = lambda_body_value(lx, &env2, body);
    crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XBlock(dos.clone(), Rc::new(crate::lower::model::Ex::XCall(Text::lit("Rc::new"), Array::from(vec![crate::lower::model::Ex::XClosure(true, pas.clone(), Rc::new(crate::lower::types::own(&v_)))])))), ft.clone())
}

/// The step machine of `PlainLambda`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PlainLambda: unbounded fn Lx, Env, [Pattern], LambdaBody, OutTy -> Vl
/// ```
pub struct PlainLambda {
    pub lx: crate::lower::Lx,
    pub env: crate::lower::types::Env,
    pub ps: Array<crate::syntax::Pattern_>,
    pub body: crate::syntax::LambdaBody,
    pub ft: crate::lower::model::OutTy,
}

impl prism_rtl::Job<crate::lower::types::Vl> for PlainLambda {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::types::Vl> {
        let lx = &self.lx;
        let env = &self.env;
        let ps = &self.ps;
        let body = &self.body;
        let ft = &self.ft;
        let pts = match ft {
            crate::lower::model::OutTy::OutFn(xs, _) => xs.clone(),
            _ => Array::new(),
        };
        let body = body.clone();
        let env = env.clone();
        let ft = ft.clone();
        let lx = lx.clone();
        let ps = ps.clone();
        call_then(start_lambda_exprs(body.clone()), move |lambda_exprs_49562: Array<crate::syntax::Expr>| call_then(start_read_names(lambda_exprs_49562), move |read_names_49551: Array<Text>| {
            let read = crate::lower::types::with_instances(&env, &read_names_49551);
            let caps0 = filter(&read, &(|n: &Text| match get(&env.names, n) {
                Some(crate::lower::types::Bn::BnLocal(_, _, _)) => true,
                _ => false,
            }));
            let caps = append(&append(&caps0, &filter(&each(&read, &(|n: &Text| Text::from(format!("{}#port", n)))), &(|n: &Text| crate::check::env::has_key(&env.names, n)))), &filter(&each(&read, &(|n: &Text| Text::from(format!("{}#init", n)))), &(|n: &Text| crate::check::env::has_key(&env.names, n))));
            let (dos, env1) = fold(&caps, &(Array::new(), env.clone()), &(|(acc, en): &(Array<crate::lower::model::Do>, crate::lower::types::Env), n: &Text| match get(&env.names, n) {
                Some(crate::lower::types::Bn::BnLocal(rs, mode, ct)) => {
                    let local = crate::lower::types::place_stem(&rs);
                    let d = crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(local.clone()), crate::lower::types::own(&crate::lower::types::local_place(&rs, &mode, &ct)));
                    (push(acc, &d), crate::lower::types::bind(en, n, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(local.clone()), crate::lower::types::Holding::Owned, ct.clone())))
                },
                _ => (acc.clone(), en.clone()),
            }));
            call_then(start_closure_params(lx.clone(), env1.clone(), ps.clone(), pts.clone(), true), move |closure_params_50445: (Array<crate::lower::model::Pa>, crate::lower::types::Env)| {
                let (pas, env2) = closure_params_50445;
                call_then(start_lambda_body_value(lx.clone(), env2.clone(), body.clone()), move |lambda_body_value_50495: crate::lower::types::Vl| {
                    let v_ = lambda_body_value_50495;
                    prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XBlock(dos.clone(), Rc::new(crate::lower::model::Ex::XCall(Text::lit("Rc::new"), Array::from(vec![crate::lower::model::Ex::XClosure(true, pas.clone(), Rc::new(crate::lower::types::own(&v_)))])))), ft.clone()))
                })
            })
        }))
    }
}

/// `Start PlainLambda, x`: what the function value is when passed to `@Run`.
pub fn start_plain_lambda(lx: crate::lower::Lx, env: crate::lower::types::Env, ps: Array<crate::syntax::Pattern_>, body: crate::syntax::LambdaBody, ft: crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<crate::lower::types::Vl>> {
    Rc::new(PlainLambda { lx, env, ps, body, ft })
}

/// ```prism
/// LambdaParamTys: unbounded fn Lx, Expr, Nat -> [OutTy]
/// ```
pub fn lambda_param_tys(lx: &crate::lower::Lx, e: &crate::syntax::Expr, n: &Nat) -> Array<crate::lower::model::OutTy> {
    let ts = match crate::lower::types::out_ty_of(lx, &crate::lower::types::peel(&crate::lower::type_at(lx, &e.span))) {
        crate::lower::model::OutTy::OutFn(xs, _) => xs,
        crate::lower::model::OutTy::OutJobFn(a, _) => match &*a {
            crate::lower::model::OutTy::OutTuple(xs) => if n == &Nat::from(1u32) { Array::from(vec![(*a).clone()]) } else { xs.clone() },
            _ => Array::from(vec![(*a).clone()]),
        },
        _ => Array::new(),
    };
    if (&len(&ts) == n) && run_to_end(fold_job(ts.clone(), true, Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| entered(once_job(move || {
        let ok_ = p0;
        let t = p1;
        prism_rtl::Turn::Finished(ok_ && is_known_ty(&t))
    }))) as Rc<dyn Fn((bool, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<bool>>>)) {
        ts.clone()
    } else {
        Array::new()
    }
}

/// The step machine of `LambdaParamTys`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LambdaParamTys: unbounded fn Lx, Expr, Nat -> [OutTy]
/// ```
pub struct LambdaParamTys {
    pub lx: crate::lower::Lx,
    pub e: crate::syntax::Expr,
    pub n: Nat,
}

impl prism_rtl::Job<Array<crate::lower::model::OutTy>> for LambdaParamTys {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::lower::model::OutTy>> {
        let lx = &self.lx;
        let e = &self.e;
        let n = &self.n;
        let e = e.clone();
        let lx = lx.clone();
        let n = n.clone();
        call_then(crate::lower::types::start_out_ty_of(lx.clone(), crate::lower::types::peel(&crate::lower::type_at(&lx, &e.span))), move |out_ty_of_50899: crate::lower::model::OutTy| {
            let ts = match out_ty_of_50899 {
                crate::lower::model::OutTy::OutFn(xs, _) => xs,
                crate::lower::model::OutTy::OutJobFn(a, _) => match &*a {
                    crate::lower::model::OutTy::OutTuple(xs) => if &n == &Nat::from(1u32) { Array::from(vec![(*a).clone()]) } else { xs.clone() },
                    _ => Array::from(vec![(*a).clone()]),
                },
                _ => Array::new(),
            };
            if (&len(&ts) == &n) && run_to_end(fold_job(ts.clone(), true, Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| entered(once_job(move || {
                let ok_ = p0;
                let t = p1;
                prism_rtl::Turn::Finished(ok_ && is_known_ty(&t))
            }))) as Rc<dyn Fn((bool, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<bool>>>)) {
                prism_rtl::Turn::Finished(ts.clone())
            } else {
                prism_rtl::Turn::Finished(Array::new())
            }
        })
    }
}

/// `Start LambdaParamTys, x`: what the function value is when passed to `@Run`.
pub fn start_lambda_param_tys(lx: crate::lower::Lx, e: crate::syntax::Expr, n: Nat) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::OutTy>>> {
    Rc::new(LambdaParamTys { lx, e, n })
}

/// ```prism
/// IsKnownTy: unbounded fn OutTy -> Bool
/// ```
pub fn is_known_ty(t: &crate::lower::model::OutTy) -> bool {
    match t {
        crate::lower::model::OutTy::OutUnknown(_) => false,
        crate::lower::model::OutTy::OutOpt(x) => is_known_ty(&**x),
        crate::lower::model::OutTy::OutRes(x) => is_known_ty(&**x),
        crate::lower::model::OutTy::OutArray(x) => is_known_ty(&**x),
        crate::lower::model::OutTy::OutRc(x) => is_known_ty(&**x),
        crate::lower::model::OutTy::OutMap(k, v_) => is_known_ty(&**k) && is_known_ty(&**v_),
        crate::lower::model::OutTy::OutTuple(xs) => run_to_end(fold_job(xs.clone(), true, Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| entered(once_job(move || {
            let ok_ = p0;
            let x = p1;
            prism_rtl::Turn::Finished(ok_ && is_known_ty(&x))
        }))) as Rc<dyn Fn((bool, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<bool>>>)),
        crate::lower::model::OutTy::OutNamed(_, xs) => run_to_end(fold_job(xs.clone(), true, Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| entered(once_job(move || {
            let ok_ = p0;
            let x = p1;
            prism_rtl::Turn::Finished(ok_ && is_known_ty(&x))
        }))) as Rc<dyn Fn((bool, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<bool>>>)),
        crate::lower::model::OutTy::OutFn(xs, r) => run_to_end(fold_job(xs.clone(), true, Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| entered(once_job(move || {
            let ok_ = p0;
            let x = p1;
            prism_rtl::Turn::Finished(ok_ && is_known_ty(&x))
        }))) as Rc<dyn Fn((bool, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<bool>>>)) && is_known_ty(&**r),
        crate::lower::model::OutTy::OutJobFn(a, b) => is_known_ty(&**a) && is_known_ty(&**b),
        _ => true,
    }
}

/// The step machine of `IsKnownTy`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// IsKnownTy: unbounded fn OutTy -> Bool
/// ```
pub struct IsKnownTy {
    pub t: crate::lower::model::OutTy,
}

impl prism_rtl::Job<bool> for IsKnownTy {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let t = &self.t;
        match t {
            crate::lower::model::OutTy::OutUnknown(_) => prism_rtl::Turn::Finished(false),
            crate::lower::model::OutTy::OutOpt(x) => prism_rtl::Turn::More(Rc::new(IsKnownTy { t: (**x).clone() })),
            crate::lower::model::OutTy::OutRes(x) => prism_rtl::Turn::More(Rc::new(IsKnownTy { t: (**x).clone() })),
            crate::lower::model::OutTy::OutArray(x) => prism_rtl::Turn::More(Rc::new(IsKnownTy { t: (**x).clone() })),
            crate::lower::model::OutTy::OutRc(x) => prism_rtl::Turn::More(Rc::new(IsKnownTy { t: (**x).clone() })),
            crate::lower::model::OutTy::OutMap(k, v_) => {
                let k = (**k).clone();
                let v_ = (**v_).clone();
                call_then(start_is_known_ty(k.clone()), move |is_known_ty_51409: bool| prism_rtl::Turn::Finished(is_known_ty_51409 && is_known_ty(&v_)))
            },
            crate::lower::model::OutTy::OutTuple(xs) => fold_job(xs.clone(), true, Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| entered(once_job(move || {
                let ok_ = p0;
                let x = p1;
                prism_rtl::Turn::Finished(ok_ && is_known_ty(&x))
            }))) as Rc<dyn Fn((bool, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<bool>>>).cycle(),
            crate::lower::model::OutTy::OutNamed(_, xs) => fold_job(xs.clone(), true, Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| entered(once_job(move || {
                let ok_ = p0;
                let x = p1;
                prism_rtl::Turn::Finished(ok_ && is_known_ty(&x))
            }))) as Rc<dyn Fn((bool, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<bool>>>).cycle(),
            crate::lower::model::OutTy::OutFn(xs, r) => {
                let r = (**r).clone();
                let xs = xs.clone();
                call_value(fold_job(xs.clone(), true, Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| entered(once_job(move || {
                    let ok_ = p0;
                    let x = p1;
                    prism_rtl::Turn::Finished(ok_ && is_known_ty(&x))
                }))) as Rc<dyn Fn((bool, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<bool>>>), move |fold_51584: bool| prism_rtl::Turn::Finished(fold_51584 && is_known_ty(&r)))
            },
            crate::lower::model::OutTy::OutJobFn(a, b) => {
                let a = (**a).clone();
                let b = (**b).clone();
                call_then(start_is_known_ty(a.clone()), move |is_known_ty_51664: bool| prism_rtl::Turn::Finished(is_known_ty_51664 && is_known_ty(&b)))
            },
            _ => prism_rtl::Turn::Finished(true),
        }
    }
}

/// `Start IsKnownTy, x`: what the function value is when passed to `@Run`.
pub fn start_is_known_ty(t: crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(IsKnownTy { t })
}

/// ```prism
/// JobLambda: unbounded fn Lx, Env, [Pattern], LambdaBody, OutTy, OutTy, Bool -> Vl
/// ```
pub fn job_lambda(lx: &crate::lower::Lx, env: &crate::lower::types::Env, ps: &Array<crate::syntax::Pattern_>, body: &crate::syntax::LambdaBody, ft: &crate::lower::model::OutTy, a: &crate::lower::model::OutTy, enter: &bool) -> crate::lower::types::Vl {
    let caps = filter(&crate::lower::types::with_instances(env, &read_names(&lambda_exprs(body))), &(|n: &Text| match get(&env.names, n) {
        Some(crate::lower::types::Bn::BnLocal(_, _, _)) => true,
        _ => false,
    }));
    let (dos, env1) = fold(&caps, &(Array::new(), env.clone()), &(|(acc, en): &(Array<crate::lower::model::Do>, crate::lower::types::Env), n: &Text| match get(&env.names, n) {
        Some(crate::lower::types::Bn::BnLocal(rs, mode, ct)) => {
            let d = crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::lower::types::place_stem(&rs)), crate::lower::types::own(&crate::lower::types::local_place(&rs, &mode, &ct)));
            (push(acc, &d), crate::lower::types::bind(en, n, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(crate::lower::types::place_stem(&rs)), crate::lower::types::Holding::Owned, ct.clone())))
        },
        _ => (acc.clone(), en.clone()),
    }));
    let again = fold(&caps, &Array::new(), &(|acc: &Array<crate::lower::model::Do>, n: &Text| match get(&env1.names, n) {
        Some(crate::lower::types::Bn::BnLocal(rs, _, ct)) => push(acc, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::lower::types::place_stem(&rs)), crate::lower::types::own(&crate::lower::types::local_place(&rs, &crate::lower::types::Holding::Owned, &ct)))),
        _ => acc.clone(),
    }));
    let pts = match a {
        crate::lower::model::OutTy::OutTuple(ts) => if &len(ps) == &Nat::from(1u32) { Array::from(vec![a.clone()]) } else { ts.clone() },
        _ => Array::from(vec![a.clone()]),
    };
    let env1b = only_captured(&env1, &caps);
    let pos = run_to_end(each_job(crate::check::errors::range0(&len(ps)), {
        let ps = ps.clone();
        let lx = lx.clone();
        Rc::new(move |p0: Nat| {
            let ps = ps.clone();
            let lx = lx.clone();
            entered(once_job(move || {
                let i = p0;
                {
                    let p_ = or(&index(&ps, &i), &crate::lower::patterns::dummy_pat());
                    prism_rtl::Turn::More(Rc::new(crate::lower::patterns::RustPat { lx: lx.clone(), p_: p_.clone(), ty: binder_ty_of_pattern(&lx, &p_), mode: crate::lower::types::Holding::Owned, fresh: Text::from(format!("p{}_", &i)) }))
                }
            }))
        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<crate::lower::patterns::PatOut>>>
    }));
    let unpack = fold(&crate::check::errors::range0(&len(&pos)), &Array::new(), &(|acc: &Array<crate::lower::model::Do>, i: &Nat| match index(&pos, i) {
        Some(po) => append(&push(acc, &crate::lower::model::Do::DoLet(po.pa.clone(), crate::lower::model::Ex::XVar(Text::from(format!("p{}", i))))), &each(&po.conds, &(|c: &crate::lower::model::Cc| cond_as_let(c)))),
        None => acc.clone(),
    }));
    let pos2 = each(&crate::check::errors::range0(&len(&pos)), &(|i: &Nat| match index(&pos, i) {
        Some(po) => match &*or(&index(ps, i), &crate::lower::patterns::dummy_pat()).kind {
            crate::syntax::PatternKind::PName(_) => {
                let mut this: crate::lower::patterns::PatOut = po.clone();
                this.binds = each(&this.binds, &(|(n, b): &(Text, crate::lower::types::Bn)| match b {
                    crate::lower::types::Bn::BnLocal(rs, mode, bt) => (n.clone(), crate::lower::types::Bn::BnLocal(rs.clone(), mode.clone(), or(&index(&pts, i), bt))),
                    _ => (n.clone(), b.clone()),
                }));
                this
            },
            _ => po.clone(),
        },
        None => crate::lower::patterns::PatOut { pa: crate::lower::model::Pa::PaWild, conds: Array::new(), binds: Array::new() },
    }));
    let env2 = fold(&pos2, &env1b, &(|en: &crate::lower::types::Env, po: &crate::lower::patterns::PatOut| bind_all(en, &po.binds)));
    let names = each(&crate::check::errors::range0(&len(ps)), &(|i: &Nat| Text::from(format!("p{}", i))));
    let pa = if &len(ps) == &Nat::from(1u32) {
        crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaBind(Text::lit("p0"))), a.clone())
    } else {
        crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaTuple(each(&names, &(|nm: &Text| crate::lower::model::Pa::PaBind(nm.clone()))))), a.clone())
    };
    let tail0 = match body {
        crate::syntax::LambdaBody::LbExpr(x) => crate::lower::jobs::tail(lx, &env2, &**x),
        crate::syntax::LambdaBody::LbBlock(bl) => crate::lower::jobs::tail_block(lx, &env2, bl),
    };
    let tail = if &len(&unpack) == &Nat::from(0u32) {
        tail0.clone()
    } else {
        crate::lower::model::Ex::XBlock(unpack.clone(), Rc::new(tail0.clone()))
    };
    let job0 = crate::lower::model::Ex::XCall(Text::lit("once_job"), Array::from(vec![crate::lower::model::Ex::XClosure(true, Array::new(), Rc::new(tail.clone()))]));
    let job = if *enter {
        crate::lower::model::Ex::XCall(Text::lit("entered"), Array::from(vec![job0.clone()]))
    } else {
        job0.clone()
    };
    let call = if &len(&again) == &Nat::from(0u32) {
        job.clone()
    } else {
        crate::lower::model::Ex::XBlock(again.clone(), Rc::new(job.clone()))
    };
    crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XBlock(dos.clone(), Rc::new(crate::lower::model::Ex::XCast(Rc::new(crate::lower::model::Ex::XCall(Text::lit("Rc::new"), Array::from(vec![crate::lower::model::Ex::XClosure(true, Array::from(vec![pa.clone()]), Rc::new(call.clone()))]))), ft.clone()))), ft.clone())
}

/// The step machine of `JobLambda`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// JobLambda: unbounded fn Lx, Env, [Pattern], LambdaBody, OutTy, OutTy, Bool -> Vl
/// ```
pub struct JobLambda {
    pub lx: crate::lower::Lx,
    pub env: crate::lower::types::Env,
    pub ps: Array<crate::syntax::Pattern_>,
    pub body: crate::syntax::LambdaBody,
    pub ft: crate::lower::model::OutTy,
    pub a: crate::lower::model::OutTy,
    pub enter: bool,
}

impl prism_rtl::Job<crate::lower::types::Vl> for JobLambda {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::types::Vl> {
        let lx = &self.lx;
        let env = &self.env;
        let ps = &self.ps;
        let body = &self.body;
        let ft = &self.ft;
        let a = &self.a;
        let enter = &self.enter;
        let a = a.clone();
        let body = body.clone();
        let enter = *enter;
        let env = env.clone();
        let ft = ft.clone();
        let lx = lx.clone();
        let ps = ps.clone();
        call_then(start_lambda_exprs(body.clone()), move |lambda_exprs_52542: Array<crate::syntax::Expr>| call_then(start_read_names(lambda_exprs_52542), move |read_names_52531: Array<Text>| {
            let caps = filter(&crate::lower::types::with_instances(&env, &read_names_52531), &(|n: &Text| match get(&env.names, n) {
                Some(crate::lower::types::Bn::BnLocal(_, _, _)) => true,
                _ => false,
            }));
            let (dos, env1) = fold(&caps, &(Array::new(), env.clone()), &(|(acc, en): &(Array<crate::lower::model::Do>, crate::lower::types::Env), n: &Text| match get(&env.names, n) {
                Some(crate::lower::types::Bn::BnLocal(rs, mode, ct)) => {
                    let d = crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::lower::types::place_stem(&rs)), crate::lower::types::own(&crate::lower::types::local_place(&rs, &mode, &ct)));
                    (push(acc, &d), crate::lower::types::bind(en, n, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(crate::lower::types::place_stem(&rs)), crate::lower::types::Holding::Owned, ct.clone())))
                },
                _ => (acc.clone(), en.clone()),
            }));
            let again = fold(&caps, &Array::new(), &(|acc: &Array<crate::lower::model::Do>, n: &Text| match get(&env1.names, n) {
                Some(crate::lower::types::Bn::BnLocal(rs, _, ct)) => push(acc, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::lower::types::place_stem(&rs)), crate::lower::types::own(&crate::lower::types::local_place(&rs, &crate::lower::types::Holding::Owned, &ct)))),
                _ => acc.clone(),
            }));
            let pts = match &a {
                crate::lower::model::OutTy::OutTuple(ts) => if &len(&ps) == &Nat::from(1u32) { Array::from(vec![a.clone()]) } else { ts.clone() },
                _ => Array::from(vec![a.clone()]),
            };
            let env1b = only_captured(&env1, &caps);
            call_value(each_job(crate::check::errors::range0(&len(&ps)), {
                let ps = ps.clone();
                let lx = lx.clone();
                Rc::new(move |p0: Nat| {
                    let ps = ps.clone();
                    let lx = lx.clone();
                    entered(once_job(move || {
                        let i = p0;
                        {
                            let p_ = or(&index(&ps, &i), &crate::lower::patterns::dummy_pat());
                            prism_rtl::Turn::More(Rc::new(crate::lower::patterns::RustPat { lx: lx.clone(), p_: p_.clone(), ty: binder_ty_of_pattern(&lx, &p_), mode: crate::lower::types::Holding::Owned, fresh: Text::from(format!("p{}_", &i)) }))
                        }
                    }))
                }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<crate::lower::patterns::PatOut>>>
            }), move |each_53570: Array<crate::lower::patterns::PatOut>| {
                let pos = each_53570;
                let unpack = fold(&crate::check::errors::range0(&len(&pos)), &Array::new(), &(|acc: &Array<crate::lower::model::Do>, i: &Nat| match index(&pos, i) {
                    Some(po) => append(&push(acc, &crate::lower::model::Do::DoLet(po.pa.clone(), crate::lower::model::Ex::XVar(Text::from(format!("p{}", i))))), &each(&po.conds, &(|c: &crate::lower::model::Cc| cond_as_let(c)))),
                    None => acc.clone(),
                }));
                let pos2 = each(&crate::check::errors::range0(&len(&pos)), &(|i: &Nat| match index(&pos, i) {
                    Some(po) => match &*or(&index(&ps, i), &crate::lower::patterns::dummy_pat()).kind {
                        crate::syntax::PatternKind::PName(_) => {
                            let mut this: crate::lower::patterns::PatOut = po.clone();
                            this.binds = each(&this.binds, &(|(n, b): &(Text, crate::lower::types::Bn)| match b {
                                crate::lower::types::Bn::BnLocal(rs, mode, bt) => (n.clone(), crate::lower::types::Bn::BnLocal(rs.clone(), mode.clone(), or(&index(&pts, i), bt))),
                                _ => (n.clone(), b.clone()),
                            }));
                            this
                        },
                        _ => po.clone(),
                    },
                    None => crate::lower::patterns::PatOut { pa: crate::lower::model::Pa::PaWild, conds: Array::new(), binds: Array::new() },
                }));
                let env2 = fold(&pos2, &env1b, &(|en: &crate::lower::types::Env, po: &crate::lower::patterns::PatOut| bind_all(en, &po.binds)));
                let names = each(&crate::check::errors::range0(&len(&ps)), &(|i: &Nat| Text::from(format!("p{}", i))));
                let pa = if &len(&ps) == &Nat::from(1u32) {
                    crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaBind(Text::lit("p0"))), a.clone())
                } else {
                    crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaTuple(each(&names, &(|nm: &Text| crate::lower::model::Pa::PaBind(nm.clone()))))), a.clone())
                };
                let tail0 = match &body {
                    crate::syntax::LambdaBody::LbExpr(x) => crate::lower::jobs::tail(&lx, &env2, &**x),
                    crate::syntax::LambdaBody::LbBlock(bl) => crate::lower::jobs::tail_block(&lx, &env2, bl),
                };
                let tail = if &len(&unpack) == &Nat::from(0u32) {
                    tail0.clone()
                } else {
                    crate::lower::model::Ex::XBlock(unpack.clone(), Rc::new(tail0.clone()))
                };
                let job0 = crate::lower::model::Ex::XCall(Text::lit("once_job"), Array::from(vec![crate::lower::model::Ex::XClosure(true, Array::new(), Rc::new(tail.clone()))]));
                let job = if enter {
                    crate::lower::model::Ex::XCall(Text::lit("entered"), Array::from(vec![job0.clone()]))
                } else {
                    job0.clone()
                };
                let call = if &len(&again) == &Nat::from(0u32) {
                    job.clone()
                } else {
                    crate::lower::model::Ex::XBlock(again.clone(), Rc::new(job.clone()))
                };
                prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XBlock(dos.clone(), Rc::new(crate::lower::model::Ex::XCast(Rc::new(crate::lower::model::Ex::XCall(Text::lit("Rc::new"), Array::from(vec![crate::lower::model::Ex::XClosure(true, Array::from(vec![pa.clone()]), Rc::new(call.clone()))]))), ft.clone()))), ft.clone()))
            })
        }))
    }
}

/// `Start JobLambda, x`: what the function value is when passed to `@Run`.
pub fn start_job_lambda(lx: crate::lower::Lx, env: crate::lower::types::Env, ps: Array<crate::syntax::Pattern_>, body: crate::syntax::LambdaBody, ft: crate::lower::model::OutTy, a: crate::lower::model::OutTy, enter: bool) -> Rc<dyn prism_rtl::Job<crate::lower::types::Vl>> {
    Rc::new(JobLambda { lx, env, ps, body, ft, a, enter })
}

/// ```prism
/// EntersLambda: fn Lx, Expr -> Bool
/// ```
pub fn enters_lambda(lx: &crate::lower::Lx, e: &crate::syntax::Expr) -> bool {
    match crate::lower::types::peel(&crate::lower::type_at(lx, &e.span)) {
        crate::check::types::Ty::TyFn(crate::check::types::Col::CBound, _, _) => false,
        crate::check::types::Ty::TyFn(_, _, _) => true,
        _ => false,
    }
}

/// ```prism
/// OnlyCaptured: fn Env, [Text] -> Env
/// ```
pub fn only_captured(env: &crate::lower::types::Env, caps: &Array<Text>) -> crate::lower::types::Env {
    let mut this: crate::lower::types::Env = env.clone();
    this.names = fold(&keys(&env.names), &Map::new(), &(|m: &Map<Text, crate::lower::types::Bn>, k: &Text| match get(&env.names, k) {
        Some(crate::lower::types::Bn::BnLocal(rs, mode, t)) => if crate::check::types::has_text(caps, k) || (&mode == &crate::lower::types::Holding::Owned) {
            insert(m, k, &crate::lower::types::Bn::BnLocal(rs, mode.clone(), t))
        } else {
            m.clone()
        },
        Some(b) => insert(m, k, &b),
        None => m.clone(),
    }));
    this
}

/// ```prism
/// CondAsLet: fn Cc -> Do
/// ```
pub fn cond_as_let(cc0: &crate::lower::model::Cc) -> crate::lower::model::Do {
    match cc0 {
        crate::lower::model::Cc::CcLet(pa, x) => crate::lower::model::Do::DoLet(pa.clone(), x.clone()),
        crate::lower::model::Cc::CcIf(x) => crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XUnit),
    }
}

/// ```prism
/// LambdaArg: unbounded fn Lx, Env, [Pattern], LambdaBody, [OutTy] -> Ex
/// ```
pub fn lambda_arg(lx: &crate::lower::Lx, env: &crate::lower::types::Env, ps: &Array<crate::syntax::Pattern_>, body: &crate::syntax::LambdaBody, pts: &Array<crate::lower::model::OutTy>) -> crate::lower::model::Ex {
    let (pas, env2) = closure_params(lx, env, ps, pts, &(&len(pts) > &Nat::from(0u32)));
    let v_ = lambda_body_value(lx, &env2, body);
    crate::lower::model::Ex::XClosure(false, pas.clone(), Rc::new(crate::lower::types::own(&v_)))
}

/// The step machine of `LambdaArg`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LambdaArg: unbounded fn Lx, Env, [Pattern], LambdaBody, [OutTy] -> Ex
/// ```
pub struct LambdaArg {
    pub lx: crate::lower::Lx,
    pub env: crate::lower::types::Env,
    pub ps: Array<crate::syntax::Pattern_>,
    pub body: crate::syntax::LambdaBody,
    pub pts: Array<crate::lower::model::OutTy>,
}

impl prism_rtl::Job<crate::lower::model::Ex> for LambdaArg {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::Ex> {
        let lx = &self.lx;
        let env = &self.env;
        let ps = &self.ps;
        let body = &self.body;
        let pts = &self.pts;
        let body = body.clone();
        let env = env.clone();
        let lx = lx.clone();
        let ps = ps.clone();
        let pts = pts.clone();
        call_then(start_closure_params(lx.clone(), env.clone(), ps.clone(), pts.clone(), &len(&pts) > &Nat::from(0u32)), move |closure_params_56310: (Array<crate::lower::model::Pa>, crate::lower::types::Env)| {
            let (pas, env2) = closure_params_56310;
            call_then(start_lambda_body_value(lx.clone(), env2.clone(), body.clone()), move |lambda_body_value_56368: crate::lower::types::Vl| {
                let v_ = lambda_body_value_56368;
                prism_rtl::Turn::Finished(crate::lower::model::Ex::XClosure(false, pas.clone(), Rc::new(crate::lower::types::own(&v_))))
            })
        })
    }
}

/// `Start LambdaArg, x`: what the function value is when passed to `@Run`.
pub fn start_lambda_arg(lx: crate::lower::Lx, env: crate::lower::types::Env, ps: Array<crate::syntax::Pattern_>, body: crate::syntax::LambdaBody, pts: Array<crate::lower::model::OutTy>) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>> {
    Rc::new(LambdaArg { lx, env, ps, body, pts })
}

/// ```prism
/// LambdaBodyValue: unbounded fn Lx, Env, LambdaBody -> Vl
/// ```
pub fn lambda_body_value(lx: &crate::lower::Lx, env: &crate::lower::types::Env, lambda_body2: &crate::syntax::LambdaBody) -> crate::lower::types::Vl {
    match lambda_body2 {
        crate::syntax::LambdaBody::LbExpr(x) => value_of(lx, env, &**x),
        crate::syntax::LambdaBody::LbBlock(b) => block_value(lx, env, b),
    }
}

/// The step machine of `LambdaBodyValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LambdaBodyValue: unbounded fn Lx, Env, LambdaBody -> Vl
/// ```
pub struct LambdaBodyValue {
    pub lx: crate::lower::Lx,
    pub env: crate::lower::types::Env,
    pub lambda_body2: crate::syntax::LambdaBody,
}

impl prism_rtl::Job<crate::lower::types::Vl> for LambdaBodyValue {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::types::Vl> {
        let lx = &self.lx;
        let env = &self.env;
        let lambda_body2 = &self.lambda_body2;
        match lambda_body2 {
            crate::syntax::LambdaBody::LbExpr(x) => prism_rtl::Turn::More(Rc::new(ValueOf { lx: lx.clone(), env: env.clone(), e: (**x).clone() })),
            crate::syntax::LambdaBody::LbBlock(b) => prism_rtl::Turn::More(Rc::new(BlockValue { lx: lx.clone(), env: env.clone(), b: b.clone() })),
        }
    }
}

/// `Start LambdaBodyValue, x`: what the function value is when passed to `@Run`.
pub fn start_lambda_body_value(lx: crate::lower::Lx, env: crate::lower::types::Env, lambda_body2: crate::syntax::LambdaBody) -> Rc<dyn prism_rtl::Job<crate::lower::types::Vl>> {
    Rc::new(LambdaBodyValue { lx, env, lambda_body2 })
}

/// ```prism
/// ClosureParams: unbounded fn Lx, Env, [Pattern], [OutTy], Bool -> (([Pa], Env))
/// ```
pub fn closure_params(lx: &crate::lower::Lx, env: &crate::lower::types::Env, ps: &Array<crate::syntax::Pattern_>, pts: &Array<crate::lower::model::OutTy>, typed: &bool) -> (Array<crate::lower::model::Pa>, crate::lower::types::Env) {
    run_to_end(fold_job(crate::check::errors::range0(&len(ps)), (Array::new(), env.clone()), {
        let ps = ps.clone();
        let lx = lx.clone();
        let typed = *typed;
        let pts = pts.clone();
        Rc::new(move |(p0, p1): ((Array<crate::lower::model::Pa>, crate::lower::types::Env), Nat)| {
            let ps = ps.clone();
            let lx = lx.clone();
            let typed = typed;
            let pts = pts.clone();
            entered(once_job(move || {
                let (acc, en) = p0;
                let i = p1;
                match index(&ps, &i) {
                    Some(p_) => call_then(crate::lower::patterns::start_rust_pat(lx.clone(), p_.clone(), binder_ty_of_pattern(&lx, &p_), crate::lower::types::Holding::ByRef, Text::from(format!("a{}", &p_.span.start))), move |rust_pat_56931: crate::lower::patterns::PatOut| {
                        let po = rust_pat_56931;
                        let en2 = bind_all(&en, &po.binds);
                        let pa = if typed {
                            crate::lower::model::Pa::PaTyped(Rc::new(po.pa.clone()), crate::lower::model::OutTy::OutRef(Rc::new(or(&index(&pts, &i), &crate::lower::model::OutTy::OutUnknown(Text::lit("a parameter"))))))
                        } else {
                            po.pa.clone()
                        };
                        prism_rtl::Turn::Finished((push(&acc, &pa), en2.clone()))
                    }),
                    None => prism_rtl::Turn::Finished((acc.clone(), en.clone())),
                }
            }))
        }) as Rc<dyn Fn(((Array<crate::lower::model::Pa>, crate::lower::types::Env), Nat)) -> Rc<dyn prism_rtl::Job<(Array<crate::lower::model::Pa>, crate::lower::types::Env)>>>
    }))
}

/// The step machine of `ClosureParams`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ClosureParams: unbounded fn Lx, Env, [Pattern], [OutTy], Bool -> (([Pa], Env))
/// ```
pub struct ClosureParams {
    pub lx: crate::lower::Lx,
    pub env: crate::lower::types::Env,
    pub ps: Array<crate::syntax::Pattern_>,
    pub pts: Array<crate::lower::model::OutTy>,
    pub typed: bool,
}

impl prism_rtl::Job<(Array<crate::lower::model::Pa>, crate::lower::types::Env)> for ClosureParams {
    fn cycle(&self) -> prism_rtl::Turn<(Array<crate::lower::model::Pa>, crate::lower::types::Env)> {
        let lx = &self.lx;
        let env = &self.env;
        let ps = &self.ps;
        let pts = &self.pts;
        let typed = &self.typed;
        fold_job(crate::check::errors::range0(&len(ps)), (Array::new(), env.clone()), {
            let ps = ps.clone();
            let lx = lx.clone();
            let typed = *typed;
            let pts = pts.clone();
            Rc::new(move |(p0, p1): ((Array<crate::lower::model::Pa>, crate::lower::types::Env), Nat)| {
                let ps = ps.clone();
                let lx = lx.clone();
                let typed = typed;
                let pts = pts.clone();
                entered(once_job(move || {
                    let (acc, en) = p0;
                    let i = p1;
                    match index(&ps, &i) {
                        Some(p_) => call_then(crate::lower::patterns::start_rust_pat(lx.clone(), p_.clone(), binder_ty_of_pattern(&lx, &p_), crate::lower::types::Holding::ByRef, Text::from(format!("a{}", &p_.span.start))), move |rust_pat_56931: crate::lower::patterns::PatOut| {
                            let po = rust_pat_56931;
                            let en2 = bind_all(&en, &po.binds);
                            let pa = if typed {
                                crate::lower::model::Pa::PaTyped(Rc::new(po.pa.clone()), crate::lower::model::OutTy::OutRef(Rc::new(or(&index(&pts, &i), &crate::lower::model::OutTy::OutUnknown(Text::lit("a parameter"))))))
                            } else {
                                po.pa.clone()
                            };
                            prism_rtl::Turn::Finished((push(&acc, &pa), en2.clone()))
                        }),
                        None => prism_rtl::Turn::Finished((acc.clone(), en.clone())),
                    }
                }))
            }) as Rc<dyn Fn(((Array<crate::lower::model::Pa>, crate::lower::types::Env), Nat)) -> Rc<dyn prism_rtl::Job<(Array<crate::lower::model::Pa>, crate::lower::types::Env)>>>
        }).cycle()
    }
}

/// `Start ClosureParams, x`: what the function value is when passed to `@Run`.
pub fn start_closure_params(lx: crate::lower::Lx, env: crate::lower::types::Env, ps: Array<crate::syntax::Pattern_>, pts: Array<crate::lower::model::OutTy>, typed: bool) -> Rc<dyn prism_rtl::Job<(Array<crate::lower::model::Pa>, crate::lower::types::Env)>> {
    Rc::new(ClosureParams { lx, env, ps, pts, typed })
}

/// ```prism
/// BindAll: fn Env, [((Text, Bn))] -> Env
/// ```
pub fn bind_all(env: &crate::lower::types::Env, bs: &Array<(Text, crate::lower::types::Bn)>) -> crate::lower::types::Env {
    fold(bs, env, &(|en: &crate::lower::types::Env, (n, b): &(Text, crate::lower::types::Bn)| crate::lower::types::bind(en, n, b)))
}

/// ```prism
/// BinderTyOfPattern: fn Lx, Pattern -> Ty
/// ```
pub fn binder_ty_of_pattern(lx: &crate::lower::Lx, p_: &crate::syntax::Pattern_) -> crate::check::types::Ty {
    match &*p_.kind {
        crate::syntax::PatternKind::PName(n) => crate::lower::binder_ty(lx, &n.span),
        _ => crate::lower::type_at(lx, &p_.span),
    }
}

/// ```prism
/// IfValue: unbounded fn Lx, Env, Cond, Block, ?Block, OutTy -> Vl
/// ```
pub fn if_value(lx: &crate::lower::Lx, env: &crate::lower::types::Env, c: &crate::syntax::Cond, then_b: &crate::syntax::Block, else_b_opt: &Option<crate::syntax::Block>, t: &crate::lower::model::OutTy) -> crate::lower::types::Vl {
    let else_v = match else_b_opt {
        Some(b) => crate::lower::node_::def::own_as(t, &block_value(lx, env, b)),
        None => crate::lower::model::Ex::XUnit,
    };
    match c {
        crate::syntax::Cond::CondExpr(x) => crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XIf(Rc::new(crate::lower::types::as_bool(&value_of(lx, env, &**x))), Rc::new(crate::lower::node_::def::own_as(t, &block_value(lx, env, then_b))), Rc::new(else_v.clone())), t.clone()),
        crate::syntax::Cond::CondBind(p_, x, g_opt) => {
            let sv = value_of(lx, env, &**x);
            let po = crate::lower::patterns::rust_pat(lx, p_, &crate::lower::type_at(lx, &x.span), &crate::lower::types::Holding::ByRef, &Text::from(format!("c{}", &x.span.start)));
            let env2 = bind_all(env, &po.binds);
            let guard = match &**g_opt {
                Some(ge) => Array::from(vec![crate::lower::model::Cc::CcIf(crate::lower::types::as_bool(&value_of(lx, &env2, ge)))]),
                None => Array::new(),
            };
            let arm = crate::lower::model::XArm { pat: po.pa.clone(), conds: append(&po.conds, &guard), body: crate::lower::node_::def::own_as(t, &block_value(lx, &env2, then_b)) };
            let other = crate::lower::model::XArm { pat: crate::lower::model::Pa::PaWild, conds: Array::new(), body: else_v.clone() };
            arms_value(&crate::lower::types::ref_(&sv), &Array::from(vec![arm.clone(), other.clone()]), &Text::from(format!("c{}", &x.span.start)), t)
        },
    }
}

/// The step machine of `IfValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// IfValue: unbounded fn Lx, Env, Cond, Block, ?Block, OutTy -> Vl
/// ```
pub struct IfValue {
    pub lx: crate::lower::Lx,
    pub env: crate::lower::types::Env,
    pub c: crate::syntax::Cond,
    pub then_b: crate::syntax::Block,
    pub else_b_opt: Option<crate::syntax::Block>,
    pub t: crate::lower::model::OutTy,
}

impl prism_rtl::Job<crate::lower::types::Vl> for IfValue {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::types::Vl> {
        let lx = &self.lx;
        let env = &self.env;
        let c = &self.c;
        let then_b = &self.then_b;
        let else_b_opt = &self.else_b_opt;
        let t = &self.t;
        let else_v = match else_b_opt {
            Some(b) => crate::lower::node_::def::own_as(t, &block_value(lx, env, b)),
            None => crate::lower::model::Ex::XUnit,
        };
        match c {
            crate::syntax::Cond::CondExpr(x) => {
                let env = env.clone();
                let lx = lx.clone();
                let t = t.clone();
                let then_b = then_b.clone();
                let x = (**x).clone();
                call_then(start_value_of(lx.clone(), env.clone(), x.clone()), move |value_of_57837: crate::lower::types::Vl| call_then(start_block_value(lx.clone(), env.clone(), then_b.clone()), move |block_value_57870: crate::lower::types::Vl| prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XIf(Rc::new(crate::lower::types::as_bool(&value_of_57837)), Rc::new(crate::lower::node_::def::own_as(&t, &block_value_57870)), Rc::new(else_v.clone())), t.clone()))))
            },
            crate::syntax::Cond::CondBind(p_, x, g_opt) => {
                let g_opt = (**g_opt).clone();
                let c = c.clone();
                let env = env.clone();
                let lx = lx.clone();
                let p_ = p_.clone();
                let t = t.clone();
                let then_b = then_b.clone();
                let x = (**x).clone();
                call_then(start_value_of(lx.clone(), env.clone(), x.clone()), move |value_of_57957: crate::lower::types::Vl| {
                    let sv = value_of_57957;
                    call_then(crate::lower::patterns::start_rust_pat(lx.clone(), p_.clone(), crate::lower::type_at(&lx, &x.span), crate::lower::types::Holding::ByRef, Text::from(format!("c{}", &x.span.start))), move |rust_pat_57997: crate::lower::patterns::PatOut| {
                        let po = rust_pat_57997;
                        let env2 = bind_all(&env, &po.binds);
                        let guard = match &g_opt {
                            Some(ge) => Array::from(vec![crate::lower::model::Cc::CcIf(crate::lower::types::as_bool(&value_of(&lx, &env2, ge)))]),
                            None => Array::new(),
                        };
                        call_then(start_block_value(lx.clone(), env2.clone(), then_b.clone()), move |block_value_58312: crate::lower::types::Vl| {
                            let arm = crate::lower::model::XArm { pat: po.pa.clone(), conds: append(&po.conds, &guard), body: crate::lower::node_::def::own_as(&t, &block_value_58312) };
                            let other = crate::lower::model::XArm { pat: crate::lower::model::Pa::PaWild, conds: Array::new(), body: else_v.clone() };
                            prism_rtl::Turn::Finished(arms_value(&crate::lower::types::ref_(&sv), &Array::from(vec![arm.clone(), other.clone()]), &Text::from(format!("c{}", &x.span.start)), &t))
                        })
                    })
                })
            },
        }
    }
}

/// `Start IfValue, x`: what the function value is when passed to `@Run`.
pub fn start_if_value(lx: crate::lower::Lx, env: crate::lower::types::Env, c: crate::syntax::Cond, then_b: crate::syntax::Block, else_b_opt: Option<crate::syntax::Block>, t: crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<crate::lower::types::Vl>> {
    Rc::new(IfValue { lx, env, c, then_b, else_b_opt, t })
}

/// ```prism
/// ArmsValue: fn Ex, [XArm], Text, OutTy -> Vl
/// ```
pub fn arms_value(scrut: &crate::lower::model::Ex, arms: &Array<crate::lower::model::XArm>, label: &Text, t: &crate::lower::model::OutTy) -> crate::lower::types::Vl {
    let chain = fold(arms, &false, &(|f: &bool, a: &crate::lower::model::XArm| *f || fold(&a.conds, &false, &(|f2: &bool, c: &crate::lower::model::Cc| *f2 || is_let_cond(c)))));
    let guarded = fold(arms, &false, &(|f: &bool, a: &crate::lower::model::XArm| *f || (&len(&a.conds) > &Nat::from(0u32))));
    if chain {
        crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XChain(label.clone(), Rc::new(scrut.clone()), arms.clone(), t.clone()), t.clone())
    } else {
        crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XMatch(Rc::new(scrut.clone()), arms.clone(), guarded, t.clone()), t.clone())
    }
}

/// ```prism
/// IsLetCond: fn Cc -> Bool
/// ```
pub fn is_let_cond(cc0: &crate::lower::model::Cc) -> bool {
    match cc0 {
        crate::lower::model::Cc::CcLet(_, _) => true,
        crate::lower::model::Cc::CcIf(_) => false,
    }
}

/// ```prism
/// MatchValue: unbounded fn Lx, Env, Expr, [Arm], OutTy, Range -> Vl
/// ```
pub fn match_value(lx: &crate::lower::Lx, env: &crate::lower::types::Env, s: &crate::syntax::Expr, arms: &Array<crate::syntax::Arm>, t: &crate::lower::model::OutTy, span: &crate::syntax::Range) -> crate::lower::types::Vl {
    let sv = value_of(lx, env, s);
    let sty = crate::lower::type_at(lx, &s.span);
    let label = Text::from(format!("m{}", &span.start));
    let by_ref = run_to_end(each_job(crate::check::errors::range0(&len(arms)), {
        let lx = lx.clone();
        let arms = arms.clone();
        let sty = sty.clone();
        let label = label.clone();
        Rc::new(move |p0: Nat| {
            let lx = lx.clone();
            let arms = arms.clone();
            let sty = sty.clone();
            let label = label.clone();
            entered(once_job(move || {
                let i = p0;
                prism_rtl::Turn::More(Rc::new(ArmPat { lx: lx.clone(), opt1: or(&index(&arms, &i), &dummy_arm()).pattern.clone(), ty: sty.clone(), mode: crate::lower::types::Holding::ByRef, fresh: Text::from(format!("{}_{}", &label, &i)) }))
            }))
        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<crate::lower::patterns::PatOut>>>
    }));
    let chain = fold(&by_ref, &false, &(|f: &bool, po: &crate::lower::patterns::PatOut| *f || fold(&po.conds, &false, &(|f2: &bool, c: &crate::lower::model::Cc| *f2 || is_let_cond(c)))));
    let owned = match &sv {
        crate::lower::types::Vl::VlOwned(_, _) => !chain,
        _ => false,
    };
    let pats = if owned {
        run_to_end(each_job(crate::check::errors::range0(&len(arms)), {
            let lx = lx.clone();
            let arms = arms.clone();
            let sty = sty.clone();
            let label = label.clone();
            Rc::new(move |p0: Nat| {
                let lx = lx.clone();
                let arms = arms.clone();
                let sty = sty.clone();
                let label = label.clone();
                entered(once_job(move || {
                    let i = p0;
                    prism_rtl::Turn::More(Rc::new(ArmPat { lx: lx.clone(), opt1: or(&index(&arms, &i), &dummy_arm()).pattern.clone(), ty: sty.clone(), mode: crate::lower::types::Holding::Owned, fresh: Text::from(format!("{}_{}", &label, &i)) }))
                }))
            }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<crate::lower::patterns::PatOut>>>
        }))
    } else {
        by_ref.clone()
    };
    let xarms = run_to_end(each_job(crate::check::errors::range0(&len(arms)), {
        let arms = arms.clone();
        let pats = pats.clone();
        let env = env.clone();
        let lx = lx.clone();
        let owned = owned;
        Rc::new(move |p0: Nat| {
            let arms = arms.clone();
            let pats = pats.clone();
            let env = env.clone();
            let lx = lx.clone();
            let owned = owned;
            entered(once_job(move || {
                let i = p0;
                {
                    let arm = or(&index(&arms, &i), &dummy_arm());
                    let po = or(&index(&pats, &i), &crate::lower::patterns::PatOut { pa: crate::lower::model::Pa::PaWild, conds: Array::new(), binds: Array::new() });
                    let env2 = bind_all(&env, &po.binds);
                    let guard = match &arm.guard {
                        Some(ge) => Array::from(vec![crate::lower::model::Cc::CcIf(crate::lower::types::as_bool(&value_of(&lx, &env2, ge)))]),
                        None => Array::new(),
                    };
                    let env3 = if owned { moved_once(&lx, &env2, &arm, &po.binds) } else { env2.clone() };
                    call_then(start_block_value(lx.clone(), env3.clone(), arm.body.clone()), move |block_value_60278: crate::lower::types::Vl| prism_rtl::Turn::Finished(crate::lower::model::XArm { pat: po.pa.clone(), conds: append(&po.conds, &guard), body: crate::lower::types::own(&block_value_60278) }))
                }
            }))
        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<crate::lower::model::XArm>>>
    }));
    let scrut = if owned { crate::lower::types::own(&sv) } else { crate::lower::types::ref_(&sv) };
    arms_value(&scrut, &xarms, &label, t)
}

/// The step machine of `MatchValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// MatchValue: unbounded fn Lx, Env, Expr, [Arm], OutTy, Range -> Vl
/// ```
pub struct MatchValue {
    pub lx: crate::lower::Lx,
    pub env: crate::lower::types::Env,
    pub s: crate::syntax::Expr,
    pub arms: Array<crate::syntax::Arm>,
    pub t: crate::lower::model::OutTy,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<crate::lower::types::Vl> for MatchValue {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::types::Vl> {
        let lx = &self.lx;
        let env = &self.env;
        let s = &self.s;
        let arms = &self.arms;
        let t = &self.t;
        let span = &self.span;
        let arms = arms.clone();
        let env = env.clone();
        let lx = lx.clone();
        let s = s.clone();
        let span = span.clone();
        let t = t.clone();
        call_then(start_value_of(lx.clone(), env.clone(), s.clone()), move |value_of_59289: crate::lower::types::Vl| {
            let sv = value_of_59289;
            let sty = crate::lower::type_at(&lx, &s.span);
            let label = Text::from(format!("m{}", &span.start));
            call_value(each_job(crate::check::errors::range0(&len(&arms)), {
                let lx = lx.clone();
                let arms = arms.clone();
                let sty = sty.clone();
                let label = label.clone();
                Rc::new(move |p0: Nat| {
                    let lx = lx.clone();
                    let arms = arms.clone();
                    let sty = sty.clone();
                    let label = label.clone();
                    entered(once_job(move || {
                        let i = p0;
                        prism_rtl::Turn::More(Rc::new(ArmPat { lx: lx.clone(), opt1: or(&index(&arms, &i), &dummy_arm()).pattern.clone(), ty: sty.clone(), mode: crate::lower::types::Holding::ByRef, fresh: Text::from(format!("{}_{}", &label, &i)) }))
                    }))
                }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<crate::lower::patterns::PatOut>>>
            }), move |each_59388: Array<crate::lower::patterns::PatOut>| {
                let by_ref = each_59388;
                let chain = fold(&by_ref, &false, &(|f: &bool, po: &crate::lower::patterns::PatOut| *f || fold(&po.conds, &false, &(|f2: &bool, c: &crate::lower::model::Cc| *f2 || is_let_cond(c)))));
                let owned = match &sv {
                    crate::lower::types::Vl::VlOwned(_, _) => !chain,
                    _ => false,
                };
                let pats = if owned {
                    run_to_end(each_job(crate::check::errors::range0(&len(&arms)), {
                        let lx = lx.clone();
                        let arms = arms.clone();
                        let sty = sty.clone();
                        let label = label.clone();
                        Rc::new(move |p0: Nat| {
                            let lx = lx.clone();
                            let arms = arms.clone();
                            let sty = sty.clone();
                            let label = label.clone();
                            entered(once_job(move || {
                                let i = p0;
                                prism_rtl::Turn::More(Rc::new(ArmPat { lx: lx.clone(), opt1: or(&index(&arms, &i), &dummy_arm()).pattern.clone(), ty: sty.clone(), mode: crate::lower::types::Holding::Owned, fresh: Text::from(format!("{}_{}", &label, &i)) }))
                            }))
                        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<crate::lower::patterns::PatOut>>>
                    }))
                } else {
                    by_ref.clone()
                };
                call_value(each_job(crate::check::errors::range0(&len(&arms)), {
                    let arms = arms.clone();
                    let pats = pats.clone();
                    let env = env.clone();
                    let lx = lx.clone();
                    let owned = owned;
                    Rc::new(move |p0: Nat| {
                        let arms = arms.clone();
                        let pats = pats.clone();
                        let env = env.clone();
                        let lx = lx.clone();
                        let owned = owned;
                        entered(once_job(move || {
                            let i = p0;
                            {
                                let arm = or(&index(&arms, &i), &dummy_arm());
                                let po = or(&index(&pats, &i), &crate::lower::patterns::PatOut { pa: crate::lower::model::Pa::PaWild, conds: Array::new(), binds: Array::new() });
                                let env2 = bind_all(&env, &po.binds);
                                let guard = match &arm.guard {
                                    Some(ge) => Array::from(vec![crate::lower::model::Cc::CcIf(crate::lower::types::as_bool(&value_of(&lx, &env2, ge)))]),
                                    None => Array::new(),
                                };
                                let env3 = if owned { moved_once(&lx, &env2, &arm, &po.binds) } else { env2.clone() };
                                call_then(start_block_value(lx.clone(), env3.clone(), arm.body.clone()), move |block_value_60278: crate::lower::types::Vl| prism_rtl::Turn::Finished(crate::lower::model::XArm { pat: po.pa.clone(), conds: append(&po.conds, &guard), body: crate::lower::types::own(&block_value_60278) }))
                            }
                        }))
                    }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<crate::lower::model::XArm>>>
                }), move |each_59834: Array<crate::lower::model::XArm>| {
                    let xarms = each_59834;
                    let scrut = if owned { crate::lower::types::own(&sv) } else { crate::lower::types::ref_(&sv) };
                    prism_rtl::Turn::Finished(arms_value(&scrut, &xarms, &label, &t))
                })
            })
        })
    }
}

/// `Start MatchValue, x`: what the function value is when passed to `@Run`.
pub fn start_match_value(lx: crate::lower::Lx, env: crate::lower::types::Env, s: crate::syntax::Expr, arms: Array<crate::syntax::Arm>, t: crate::lower::model::OutTy, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<crate::lower::types::Vl>> {
    Rc::new(MatchValue { lx, env, s, arms, t, span })
}

/// ```prism
/// MovedOnce: unbounded fn Lx, Env, Arm, [((Text, Bn))] -> Env
/// ```
pub fn moved_once(lx: &crate::lower::Lx, env: &crate::lower::types::Env, arm: &crate::syntax::Arm, binds: &Array<(Text, crate::lower::types::Bn)>) -> crate::lower::types::Env {
    run_to_end(fold_job(binds.clone(), env.clone(), {
        let lx = lx.clone();
        let arm = arm.clone();
        Rc::new(move |(p0, p1): (crate::lower::types::Env, (Text, crate::lower::types::Bn))| {
            let lx = lx.clone();
            let arm = arm.clone();
            entered(once_job(move || {
                let en = p0;
                let (nkey, bn) = p1;
                match &bn {
                    crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(rs), crate::lower::types::Holding::Owned, bt) => {
                        let bt = bt.clone();
                        let rs = rs.clone();
                        call_then(start_only_read(lx.clone(), arm.clone(), nkey.clone()), move |only_read_60927: Option<crate::syntax::Expr>| match only_read_60927 {
                            Some(x) => prism_rtl::Turn::Finished(crate::lower::types::bind_span(&en, &crate::lower::place_key(&lx, &x.span), &crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XVar(rs.clone()), bt.clone()))),
                            None => prism_rtl::Turn::Finished(en.clone()),
                        })
                    },
                    _ => prism_rtl::Turn::Finished(en.clone()),
                }
            }))
        }) as Rc<dyn Fn((crate::lower::types::Env, (Text, crate::lower::types::Bn))) -> Rc<dyn prism_rtl::Job<crate::lower::types::Env>>>
    }))
}

/// The step machine of `MovedOnce`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// MovedOnce: unbounded fn Lx, Env, Arm, [((Text, Bn))] -> Env
/// ```
pub struct MovedOnce {
    pub lx: crate::lower::Lx,
    pub env: crate::lower::types::Env,
    pub arm: crate::syntax::Arm,
    pub binds: Array<(Text, crate::lower::types::Bn)>,
}

impl prism_rtl::Job<crate::lower::types::Env> for MovedOnce {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::types::Env> {
        let lx = &self.lx;
        let env = &self.env;
        let arm = &self.arm;
        let binds = &self.binds;
        fold_job(binds.clone(), env.clone(), {
            let lx = lx.clone();
            let arm = arm.clone();
            Rc::new(move |(p0, p1): (crate::lower::types::Env, (Text, crate::lower::types::Bn))| {
                let lx = lx.clone();
                let arm = arm.clone();
                entered(once_job(move || {
                    let en = p0;
                    let (nkey, bn) = p1;
                    match &bn {
                        crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(rs), crate::lower::types::Holding::Owned, bt) => {
                            let bt = bt.clone();
                            let rs = rs.clone();
                            call_then(start_only_read(lx.clone(), arm.clone(), nkey.clone()), move |only_read_60927: Option<crate::syntax::Expr>| match only_read_60927 {
                                Some(x) => prism_rtl::Turn::Finished(crate::lower::types::bind_span(&en, &crate::lower::place_key(&lx, &x.span), &crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XVar(rs.clone()), bt.clone()))),
                                None => prism_rtl::Turn::Finished(en.clone()),
                            })
                        },
                        _ => prism_rtl::Turn::Finished(en.clone()),
                    }
                }))
            }) as Rc<dyn Fn((crate::lower::types::Env, (Text, crate::lower::types::Bn))) -> Rc<dyn prism_rtl::Job<crate::lower::types::Env>>>
        }).cycle()
    }
}

/// `Start MovedOnce, x`: what the function value is when passed to `@Run`.
pub fn start_moved_once(lx: crate::lower::Lx, env: crate::lower::types::Env, arm: crate::syntax::Arm, binds: Array<(Text, crate::lower::types::Bn)>) -> Rc<dyn prism_rtl::Job<crate::lower::types::Env>> {
    Rc::new(MovedOnce { lx, env, arm, binds })
}

/// ```prism
/// ?OnlyRead: unbounded fn Lx, Arm, Text -> ?Expr
/// ```
pub fn only_read(lx: &crate::lower::Lx, arm: &crate::syntax::Arm, nkey: &Text) -> Option<crate::syntax::Expr> {
    let text_ = crate::lower::functions::src_text(lx, &lx.file, &arm.body.span);
    let in_guard = match &arm.guard {
        Some(ge) => &word_count(&crate::lower::functions::src_text(lx, &lx.file, &ge.span), nkey) > &Nat::from(0u32),
        None => false,
    };
    let reads = filter(&crate::check::typed::print::block_exprs(&arm.body), &(|x: &crate::syntax::Expr| match &*x.kind {
        crate::syntax::ExprKind::EName(n) => (&len(&n.path_) == &Nat::from(1u32)) && (&crate::check::env::sname_key(n) == nkey),
        _ => false,
    }));
    let plain = ((!in_guard && (&word_count(&text_, nkey) == &Nat::from(1u32))) && !crate::syntax::lexer::chars::contains(&text_, &Text::lit("\\|"))) && (&len(&matches(&{ thread_local!(static R: Regex = Regex::lit("\\b(while|for)\\b", "")); R.with(Regex::clone) }, &text_)) == &Nat::from(0u32));
    if plain && (&len(&reads) == &Nat::from(1u32)) {
        index(&reads, &Nat::from(0u32))
    } else {
        None
    }
}

/// The step machine of `OnlyRead`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?OnlyRead: unbounded fn Lx, Arm, Text -> ?Expr
/// ```
pub struct OnlyRead {
    pub lx: crate::lower::Lx,
    pub arm: crate::syntax::Arm,
    pub nkey: Text,
}

impl prism_rtl::Job<Option<crate::syntax::Expr>> for OnlyRead {
    fn cycle(&self) -> prism_rtl::Turn<Option<crate::syntax::Expr>> {
        let lx = &self.lx;
        let arm = &self.arm;
        let nkey = &self.nkey;
        let text_ = crate::lower::functions::src_text(lx, &lx.file, &arm.body.span);
        let in_guard = match &arm.guard {
            Some(ge) => &word_count(&crate::lower::functions::src_text(lx, &lx.file, &ge.span), nkey) > &Nat::from(0u32),
            None => false,
        };
        let arm = arm.clone();
        let nkey = nkey.clone();
        call_then(crate::check::typed::print::start_block_exprs(arm.body.clone()), move |block_exprs_61331: Array<crate::syntax::Expr>| {
            let reads = filter(&block_exprs_61331, &(|x: &crate::syntax::Expr| match &*x.kind {
                crate::syntax::ExprKind::EName(n) => (&len(&n.path_) == &Nat::from(1u32)) && (&crate::check::env::sname_key(n) == &nkey),
                _ => false,
            }));
            let plain = ((!in_guard && (&word_count(&text_, &nkey) == &Nat::from(1u32))) && !crate::syntax::lexer::chars::contains(&text_, &Text::lit("\\|"))) && (&len(&matches(&{ thread_local!(static R: Regex = Regex::lit("\\b(while|for)\\b", "")); R.with(Regex::clone) }, &text_)) == &Nat::from(0u32));
            if plain && (&len(&reads) == &Nat::from(1u32)) {
                prism_rtl::Turn::Finished(index(&reads, &Nat::from(0u32)))
            } else {
                prism_rtl::Turn::Finished(None)
            }
        })
    }
}

/// `Start OnlyRead, x`: what the function value is when passed to `@Run`.
pub fn start_only_read(lx: crate::lower::Lx, arm: crate::syntax::Arm, nkey: Text) -> Rc<dyn prism_rtl::Job<Option<crate::syntax::Expr>>> {
    Rc::new(OnlyRead { lx, arm, nkey })
}

/// ```prism
/// WordCount: fn Text, Text -> Nat
/// ```
pub fn word_count(text_: &Text, name: &Text) -> Nat {
    len(&filter(&matches(&{ thread_local!(static R: Regex = Regex::lit("[?~$!@&]*[A-Za-z_][A-Za-z0-9_]*", "")); R.with(Regex::clone) }, text_), &(|m: &Match| &m.text == name)))
}

/// ```prism
/// let dummyArm
/// ```
pub fn dummy_arm() -> crate::syntax::Arm {
    crate::syntax::Arm { pattern: None, guard: None, body: crate::syntax::Block { stmts: Array::new(), inline: true, span: crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) } }, span: crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) } }
}

/// ```prism
/// ArmPat: unbounded fn Lx, ?Pattern, Ty, Holding, Text -> PatOut
/// ```
pub fn arm_pat(lx: &crate::lower::Lx, opt1: &Option<crate::syntax::Pattern_>, ty: &crate::check::types::Ty, mode: &crate::lower::types::Holding, fresh: &Text) -> crate::lower::patterns::PatOut {
    match opt1 {
        Some(p_) => crate::lower::patterns::rust_pat(lx, p_, ty, mode, fresh),
        None => crate::lower::patterns::PatOut { pa: crate::lower::model::Pa::PaWild, conds: Array::new(), binds: Array::new() },
    }
}

/// The step machine of `ArmPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ArmPat: unbounded fn Lx, ?Pattern, Ty, Holding, Text -> PatOut
/// ```
pub struct ArmPat {
    pub lx: crate::lower::Lx,
    pub opt1: Option<crate::syntax::Pattern_>,
    pub ty: crate::check::types::Ty,
    pub mode: crate::lower::types::Holding,
    pub fresh: Text,
}

impl prism_rtl::Job<crate::lower::patterns::PatOut> for ArmPat {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::patterns::PatOut> {
        let lx = &self.lx;
        let opt1 = &self.opt1;
        let ty = &self.ty;
        let mode = &self.mode;
        let fresh = &self.fresh;
        match opt1 {
            Some(p_) => prism_rtl::Turn::More(Rc::new(crate::lower::patterns::RustPat { lx: lx.clone(), p_: p_.clone(), ty: ty.clone(), mode: mode.clone(), fresh: fresh.clone() })),
            None => prism_rtl::Turn::Finished(crate::lower::patterns::PatOut { pa: crate::lower::model::Pa::PaWild, conds: Array::new(), binds: Array::new() }),
        }
    }
}

/// `Start ArmPat, x`: what the function value is when passed to `@Run`.
pub fn start_arm_pat(lx: crate::lower::Lx, opt1: Option<crate::syntax::Pattern_>, ty: crate::check::types::Ty, mode: crate::lower::types::Holding, fresh: Text) -> Rc<dyn prism_rtl::Job<crate::lower::patterns::PatOut>> {
    Rc::new(ArmPat { lx, opt1, ty, mode, fresh })
}

/// ```prism
/// BlockValue: unbounded fn Lx, Env, Block -> Vl
/// ```
pub fn block_value(lx: &crate::lower::Lx, env: &crate::lower::types::Env, b: &crate::syntax::Block) -> crate::lower::types::Vl {
    if is_given_block(&b.stmts) {
        crate::lower::templates::given_value(lx, env, b, &block_ty(lx, b), &b.span)
    } else {
        plain_block_value(lx, env, b)
    }
}

/// The step machine of `BlockValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BlockValue: unbounded fn Lx, Env, Block -> Vl
/// ```
pub struct BlockValue {
    pub lx: crate::lower::Lx,
    pub env: crate::lower::types::Env,
    pub b: crate::syntax::Block,
}

impl prism_rtl::Job<crate::lower::types::Vl> for BlockValue {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::types::Vl> {
        let lx = &self.lx;
        let env = &self.env;
        let b = &self.b;
        if is_given_block(&b.stmts) {
            {
                let b = b.clone();
                let env = env.clone();
                let lx = lx.clone();
                call_then(start_block_ty(lx.clone(), b.clone()), move |block_ty_62481: crate::lower::model::OutTy| prism_rtl::Turn::More(Rc::new(crate::lower::templates::GivenValue { lx: lx.clone(), env: env.clone(), b: b.clone(), t: block_ty_62481, span: b.span.clone() })))
            }
        } else {
            prism_rtl::Turn::More(Rc::new(PlainBlockValue { lx: lx.clone(), env: env.clone(), b: b.clone() }))
        }
    }
}

/// `Start BlockValue, x`: what the function value is when passed to `@Run`.
pub fn start_block_value(lx: crate::lower::Lx, env: crate::lower::types::Env, b: crate::syntax::Block) -> Rc<dyn prism_rtl::Job<crate::lower::types::Vl>> {
    Rc::new(BlockValue { lx, env, b })
}

/// ```prism
/// IsGivenBlock: fn [Stmt] -> Bool
/// ```
pub fn is_given_block(stmts: &Array<crate::syntax::Stmt>) -> bool {
    fold(stmts, &false, &(|f: &bool, s: &crate::syntax::Stmt| *f || is_guardish(s)))
}

/// ```prism
/// IsGuardish: fn Stmt -> Bool
/// ```
pub fn is_guardish(s: &crate::syntax::Stmt) -> bool {
    match &s.kind {
        crate::syntax::StmtKind::SBind(_, _, None) => true,
        crate::syntax::StmtKind::SRequire(_) => true,
        crate::syntax::StmtKind::SForbid(_) => true,
        _ => false,
    }
}

/// ```prism
/// BlockTy: unbounded fn Lx, Block -> OutTy
/// ```
pub fn block_ty(lx: &crate::lower::Lx, b: &crate::syntax::Block) -> crate::lower::model::OutTy {
    match &or(&index(&b.stmts, &crate::syntax::lexer::chars::dec(&len(&b.stmts))), &dummy_stmt_l()).kind {
        crate::syntax::StmtKind::SExpr(x) => crate::lower::types::out_ty_of(lx, &crate::lower::types::peel(&crate::lower::type_at(lx, &x.span))),
        _ => crate::lower::model::OutTy::OutUnit,
    }
}

/// The step machine of `BlockTy`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BlockTy: unbounded fn Lx, Block -> OutTy
/// ```
pub struct BlockTy {
    pub lx: crate::lower::Lx,
    pub b: crate::syntax::Block,
}

impl prism_rtl::Job<crate::lower::model::OutTy> for BlockTy {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::OutTy> {
        let lx = &self.lx;
        let b = &self.b;
        match &or(&index(&b.stmts, &crate::syntax::lexer::chars::dec(&len(&b.stmts))), &dummy_stmt_l()).kind {
            crate::syntax::StmtKind::SExpr(x) => prism_rtl::Turn::More(Rc::new(crate::lower::types::OutTyOf { lx: lx.clone(), t: crate::lower::types::peel(&crate::lower::type_at(lx, &x.span)) })),
            _ => prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutUnit),
        }
    }
}

/// `Start BlockTy, x`: what the function value is when passed to `@Run`.
pub fn start_block_ty(lx: crate::lower::Lx, b: crate::syntax::Block) -> Rc<dyn prism_rtl::Job<crate::lower::model::OutTy>> {
    Rc::new(BlockTy { lx, b })
}

/// ```prism
/// PlainBlockValue: unbounded fn Lx, Env, Block -> Vl
/// ```
pub fn plain_block_value(lx: &crate::lower::Lx, env: &crate::lower::types::Env, b: &crate::syntax::Block) -> crate::lower::types::Vl {
    let n = len(&b.stmts);
    let (dos, env2, last_opt) = run_to_end(fold_job(crate::check::errors::range0(&n), (Array::new(), env.clone(), None), {
        let b = b.clone();
        let n = n.clone();
        let lx = lx.clone();
        Rc::new(move |(p0, p1): ((Array<crate::lower::model::Do>, crate::lower::types::Env, Option<crate::lower::types::Vl>), Nat)| {
            let b = b.clone();
            let n = n.clone();
            let lx = lx.clone();
            entered(once_job(move || {
                let (acc, en, lv_opt) = p0;
                let i = p1;
                {
                    let s = or(&index(&b.stmts, &i), &dummy_stmt_l());
                    if &(&i + &Nat::from(1u32)) == &n {
                        match &s.kind {
                            crate::syntax::StmtKind::SExpr(x) => prism_rtl::Turn::Finished((acc.clone(), en.clone(), Some(value_of(&lx, &en, x)))),
                            _ => call_then(start_block_stmt(lx.clone(), en.clone(), s.clone()), move |block_stmt_63523: (Array<crate::lower::model::Do>, crate::lower::types::Env)| {
                                let (more_, en2) = block_stmt_63523;
                                prism_rtl::Turn::Finished((append(&acc, &more_), en2.clone(), None))
                            }),
                        }
                    } else {
                        call_then(start_block_stmt(lx.clone(), en.clone(), s.clone()), move |block_stmt_63638: (Array<crate::lower::model::Do>, crate::lower::types::Env)| {
                            let (more_, en2) = block_stmt_63638;
                            prism_rtl::Turn::Finished((append(&acc, &more_), en2.clone(), lv_opt.clone()))
                        })
                    }
                }
            }))
        }) as Rc<dyn Fn(((Array<crate::lower::model::Do>, crate::lower::types::Env, Option<crate::lower::types::Vl>), Nat)) -> Rc<dyn prism_rtl::Job<(Array<crate::lower::model::Do>, crate::lower::types::Env, Option<crate::lower::types::Vl>)>>>
    }));
    let last = or(&last_opt, &crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XUnit, crate::lower::model::OutTy::OutUnit));
    if &len(&dos) == &Nat::from(0u32) {
        last.clone()
    } else {
        crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XBlock(dos.clone(), Rc::new(crate::lower::types::own(&last))), crate::lower::types::value_ty(&last))
    }
}

/// The step machine of `PlainBlockValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PlainBlockValue: unbounded fn Lx, Env, Block -> Vl
/// ```
pub struct PlainBlockValue {
    pub lx: crate::lower::Lx,
    pub env: crate::lower::types::Env,
    pub b: crate::syntax::Block,
}

impl prism_rtl::Job<crate::lower::types::Vl> for PlainBlockValue {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::types::Vl> {
        let lx = &self.lx;
        let env = &self.env;
        let b = &self.b;
        let n = len(&b.stmts);
        let b = b.clone();
        let env = env.clone();
        let lx = lx.clone();
        call_value(fold_job(crate::check::errors::range0(&n), (Array::new(), env.clone(), None), {
            let b = b.clone();
            let n = n.clone();
            let lx = lx.clone();
            Rc::new(move |(p0, p1): ((Array<crate::lower::model::Do>, crate::lower::types::Env, Option<crate::lower::types::Vl>), Nat)| {
                let b = b.clone();
                let n = n.clone();
                let lx = lx.clone();
                entered(once_job(move || {
                    let (acc, en, lv_opt) = p0;
                    let i = p1;
                    {
                        let s = or(&index(&b.stmts, &i), &dummy_stmt_l());
                        if &(&i + &Nat::from(1u32)) == &n {
                            match &s.kind {
                                crate::syntax::StmtKind::SExpr(x) => prism_rtl::Turn::Finished((acc.clone(), en.clone(), Some(value_of(&lx, &en, x)))),
                                _ => call_then(start_block_stmt(lx.clone(), en.clone(), s.clone()), move |block_stmt_63523: (Array<crate::lower::model::Do>, crate::lower::types::Env)| {
                                    let (more_, en2) = block_stmt_63523;
                                    prism_rtl::Turn::Finished((append(&acc, &more_), en2.clone(), None))
                                }),
                            }
                        } else {
                            call_then(start_block_stmt(lx.clone(), en.clone(), s.clone()), move |block_stmt_63638: (Array<crate::lower::model::Do>, crate::lower::types::Env)| {
                                let (more_, en2) = block_stmt_63638;
                                prism_rtl::Turn::Finished((append(&acc, &more_), en2.clone(), lv_opt.clone()))
                            })
                        }
                    }
                }))
            }) as Rc<dyn Fn(((Array<crate::lower::model::Do>, crate::lower::types::Env, Option<crate::lower::types::Vl>), Nat)) -> Rc<dyn prism_rtl::Job<(Array<crate::lower::model::Do>, crate::lower::types::Env, Option<crate::lower::types::Vl>)>>>
        }), move |fold_63269: (Array<crate::lower::model::Do>, crate::lower::types::Env, Option<crate::lower::types::Vl>)| {
            let (dos, env2, last_opt) = fold_63269;
            let last = or(&last_opt, &crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XUnit, crate::lower::model::OutTy::OutUnit));
            if &len(&dos) == &Nat::from(0u32) {
                prism_rtl::Turn::Finished(last.clone())
            } else {
                prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XBlock(dos.clone(), Rc::new(crate::lower::types::own(&last))), crate::lower::types::value_ty(&last)))
            }
        })
    }
}

/// `Start PlainBlockValue, x`: what the function value is when passed to `@Run`.
pub fn start_plain_block_value(lx: crate::lower::Lx, env: crate::lower::types::Env, b: crate::syntax::Block) -> Rc<dyn prism_rtl::Job<crate::lower::types::Vl>> {
    Rc::new(PlainBlockValue { lx, env, b })
}

/// ```prism
/// let dummyStmtL
/// ```
pub fn dummy_stmt_l() -> crate::syntax::Stmt {
    crate::syntax::Stmt { kind: crate::syntax::StmtKind::SExpr(crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EError), span: crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) } }), span: crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) } }
}

/// ```prism
/// BlockStmt: unbounded fn Lx, Env, Stmt -> (([Do], Env))
/// ```
pub fn block_stmt(lx: &crate::lower::Lx, env: &crate::lower::types::Env, s: &crate::syntax::Stmt) -> (Array<crate::lower::model::Do>, crate::lower::types::Env) {
    match &s.kind {
        crate::syntax::StmtKind::SLet(p_, _, x) => match &*p_.kind {
            crate::syntax::PatternKind::PName(n) => match get(&lx.gens, &crate::lower::place_key(lx, &n.span)) {
                Some(gn) => generic_let(lx, env, n, &gn, x),
                None => plain_let(lx, env, s, p_, x),
            },
            _ => plain_let(lx, env, s, p_, x),
        },
        crate::syntax::StmtKind::SExpr(x) => (Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::types::own(&value_of(lx, env, x)))]), env.clone()),
        crate::syntax::StmtKind::SSignature(_) => (Array::new(), env.clone()),
        crate::syntax::StmtKind::SFn(f) => (Array::from(vec![refusal_do(&Text::from(format!("a local function {}: not lowered yet", &crate::check::env::def_name_text(&f.name))))]), env.clone()),
        _ => (Array::from(vec![refusal_do(&Text::lit("a statement this back end does not lower yet"))]), env.clone()),
    }
}

/// The step machine of `BlockStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BlockStmt: unbounded fn Lx, Env, Stmt -> (([Do], Env))
/// ```
pub struct BlockStmt {
    pub lx: crate::lower::Lx,
    pub env: crate::lower::types::Env,
    pub s: crate::syntax::Stmt,
}

impl prism_rtl::Job<(Array<crate::lower::model::Do>, crate::lower::types::Env)> for BlockStmt {
    fn cycle(&self) -> prism_rtl::Turn<(Array<crate::lower::model::Do>, crate::lower::types::Env)> {
        let lx = &self.lx;
        let env = &self.env;
        let s = &self.s;
        match &s.kind {
            crate::syntax::StmtKind::SLet(p_, _, x) => match &*p_.kind {
                crate::syntax::PatternKind::PName(n) => match get(&lx.gens, &crate::lower::place_key(lx, &n.span)) {
                    Some(gn) => prism_rtl::Turn::More(Rc::new(GenericLet { lx: lx.clone(), env: env.clone(), n: n.clone(), gn: gn.clone(), x: x.clone() })),
                    None => prism_rtl::Turn::More(Rc::new(PlainLet { lx: lx.clone(), env: env.clone(), s: s.clone(), p_: p_.clone(), x: x.clone() })),
                },
                _ => prism_rtl::Turn::More(Rc::new(PlainLet { lx: lx.clone(), env: env.clone(), s: s.clone(), p_: p_.clone(), x: x.clone() })),
            },
            crate::syntax::StmtKind::SExpr(x) => {
                let env = env.clone();
                let lx = lx.clone();
                let x = x.clone();
                call_then(start_value_of(lx.clone(), env.clone(), x.clone()), move |value_of_64346: crate::lower::types::Vl| prism_rtl::Turn::Finished((Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::types::own(&value_of_64346))]), env.clone())))
            },
            crate::syntax::StmtKind::SSignature(_) => prism_rtl::Turn::Finished((Array::new(), env.clone())),
            crate::syntax::StmtKind::SFn(f) => prism_rtl::Turn::Finished((Array::from(vec![refusal_do(&Text::from(format!("a local function {}: not lowered yet", &crate::check::env::def_name_text(&f.name))))]), env.clone())),
            _ => prism_rtl::Turn::Finished((Array::from(vec![refusal_do(&Text::lit("a statement this back end does not lower yet"))]), env.clone())),
        }
    }
}

/// `Start BlockStmt, x`: what the function value is when passed to `@Run`.
pub fn start_block_stmt(lx: crate::lower::Lx, env: crate::lower::types::Env, s: crate::syntax::Stmt) -> Rc<dyn prism_rtl::Job<(Array<crate::lower::model::Do>, crate::lower::types::Env)>> {
    Rc::new(BlockStmt { lx, env, s })
}

/// ```prism
/// GenericLet: unbounded fn Lx, Env, SName, GenNote, Expr -> (([Do], Env))
/// ```
pub fn generic_let(lx: &crate::lower::Lx, env: &crate::lower::types::Env, n: &crate::syntax::SName, gn: &crate::check::typed::GenNote, x: &crate::syntax::Expr) -> (Array<crate::lower::model::Do>, crate::lower::types::Env) {
    let nkey = crate::check::env::sname_key(n);
    let distinct_ = instantiations(lx, gn);
    let one = &len(&distinct_) == &Nat::from(1u32);
    let rs = crate::lower::local_name(lx, &nkey);
    run_to_end(fold_job(crate::check::errors::range0(&len(&distinct_)), (Array::new(), env.clone()), {
        let distinct_ = distinct_.clone();
        let lx = lx.clone();
        let one = one;
        let rs = rs.clone();
        let nkey = nkey.clone();
        let n = n.clone();
        let env = env.clone();
        let x = x.clone();
        Rc::new(move |(p0, p1): ((Array<crate::lower::model::Do>, crate::lower::types::Env), Nat)| {
            let distinct_ = distinct_.clone();
            let lx = lx.clone();
            let one = one;
            let rs = rs.clone();
            let nkey = nkey.clone();
            let n = n.clone();
            let env = env.clone();
            let x = x.clone();
            entered(once_job(move || {
                let (dos, en) = p0;
                let k = p1;
                {
                    let (tys, cols) = or(&index(&distinct_, &k), &(Array::new(), Array::new()));
                    let lxk = at_instance(&lx, &(tys.clone(), cols.clone()));
                    let rk = if one { rs.clone() } else { Text::from(format!("{}_{}", &rs, &k)) };
                    let bkey = if &k == &Nat::from(0u32) {
                        nkey.clone()
                    } else {
                        Text::from(format!("{}#inst{}", &nkey, &k))
                    };
                    call_then(crate::lower::types::start_out_ty_of(lxk.clone(), crate::lower::types::peel(&crate::lower::binder_ty(&lxk, &n.span))), move |out_ty_of_65508: crate::lower::model::OutTy| {
                        let bt = out_ty_of_65508;
                        call_then(start_value_of(lxk.clone(), env.clone(), x.clone()), move |value_of_65567: crate::lower::types::Vl| {
                            let v_ = value_of_65567;
                            let en1 = crate::lower::types::bind(&en, &bkey, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(rk.clone()), crate::lower::types::Holding::Owned, bt.clone()));
                            let en2 = {
                                let mut this: crate::lower::types::Env = en1.clone();
                                this.uses = insert(&this.uses, &Text::from(format!("{}#{}", &nkey, &show_text(&(tys.clone(), cols.clone())))), &bkey);
                                this
                            };
                            let d = crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(rk.clone()), crate::lower::types::own(&v_));
                            prism_rtl::Turn::Finished((push(&dos, &d), en2.clone()))
                        })
                    })
                }
            }))
        }) as Rc<dyn Fn(((Array<crate::lower::model::Do>, crate::lower::types::Env), Nat)) -> Rc<dyn prism_rtl::Job<(Array<crate::lower::model::Do>, crate::lower::types::Env)>>>
    }))
}

/// The step machine of `GenericLet`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// GenericLet: unbounded fn Lx, Env, SName, GenNote, Expr -> (([Do], Env))
/// ```
pub struct GenericLet {
    pub lx: crate::lower::Lx,
    pub env: crate::lower::types::Env,
    pub n: crate::syntax::SName,
    pub gn: crate::check::typed::GenNote,
    pub x: crate::syntax::Expr,
}

impl prism_rtl::Job<(Array<crate::lower::model::Do>, crate::lower::types::Env)> for GenericLet {
    fn cycle(&self) -> prism_rtl::Turn<(Array<crate::lower::model::Do>, crate::lower::types::Env)> {
        let lx = &self.lx;
        let env = &self.env;
        let n = &self.n;
        let gn = &self.gn;
        let x = &self.x;
        let nkey = crate::check::env::sname_key(n);
        let env = env.clone();
        let gn = gn.clone();
        let lx = lx.clone();
        let n = n.clone();
        let x = x.clone();
        call_then(start_instantiations(lx.clone(), gn.clone()), move |instantiations_65127: Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)>| {
            let distinct_ = instantiations_65127;
            let one = &len(&distinct_) == &Nat::from(1u32);
            let rs = crate::lower::local_name(&lx, &nkey);
            fold_job(crate::check::errors::range0(&len(&distinct_)), (Array::new(), env.clone()), {
                let distinct_ = distinct_.clone();
                let lx = lx.clone();
                let one = one;
                let rs = rs.clone();
                let nkey = nkey.clone();
                let n = n.clone();
                let env = env.clone();
                let x = x.clone();
                Rc::new(move |(p0, p1): ((Array<crate::lower::model::Do>, crate::lower::types::Env), Nat)| {
                    let distinct_ = distinct_.clone();
                    let lx = lx.clone();
                    let one = one;
                    let rs = rs.clone();
                    let nkey = nkey.clone();
                    let n = n.clone();
                    let env = env.clone();
                    let x = x.clone();
                    entered(once_job(move || {
                        let (dos, en) = p0;
                        let k = p1;
                        {
                            let (tys, cols) = or(&index(&distinct_, &k), &(Array::new(), Array::new()));
                            let lxk = at_instance(&lx, &(tys.clone(), cols.clone()));
                            let rk = if one { rs.clone() } else { Text::from(format!("{}_{}", &rs, &k)) };
                            let bkey = if &k == &Nat::from(0u32) {
                                nkey.clone()
                            } else {
                                Text::from(format!("{}#inst{}", &nkey, &k))
                            };
                            call_then(crate::lower::types::start_out_ty_of(lxk.clone(), crate::lower::types::peel(&crate::lower::binder_ty(&lxk, &n.span))), move |out_ty_of_65508: crate::lower::model::OutTy| {
                                let bt = out_ty_of_65508;
                                call_then(start_value_of(lxk.clone(), env.clone(), x.clone()), move |value_of_65567: crate::lower::types::Vl| {
                                    let v_ = value_of_65567;
                                    let en1 = crate::lower::types::bind(&en, &bkey, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(rk.clone()), crate::lower::types::Holding::Owned, bt.clone()));
                                    let en2 = {
                                        let mut this: crate::lower::types::Env = en1.clone();
                                        this.uses = insert(&this.uses, &Text::from(format!("{}#{}", &nkey, &show_text(&(tys.clone(), cols.clone())))), &bkey);
                                        this
                                    };
                                    let d = crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(rk.clone()), crate::lower::types::own(&v_));
                                    prism_rtl::Turn::Finished((push(&dos, &d), en2.clone()))
                                })
                            })
                        }
                    }))
                }) as Rc<dyn Fn(((Array<crate::lower::model::Do>, crate::lower::types::Env), Nat)) -> Rc<dyn prism_rtl::Job<(Array<crate::lower::model::Do>, crate::lower::types::Env)>>>
            }).cycle()
        })
    }
}

/// `Start GenericLet, x`: what the function value is when passed to `@Run`.
pub fn start_generic_let(lx: crate::lower::Lx, env: crate::lower::types::Env, n: crate::syntax::SName, gn: crate::check::typed::GenNote, x: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<(Array<crate::lower::model::Do>, crate::lower::types::Env)>> {
    Rc::new(GenericLet { lx, env, n, gn, x })
}

/// ```prism
/// Instantiations: unbounded fn Lx, GenNote -> [(([((Text, Ty))], [((Text, Col))]))]
/// ```
pub fn instantiations(lx: &crate::lower::Lx, gn: &crate::check::typed::GenNote) -> Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)> {
    run_to_end(fold_job(or(&get(&lx.insts, &gen_key(gn)), &Array::new()), Array::new(), {
        let lx = lx.clone();
        Rc::new(move |(p0, p1): (Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)>, crate::check::typed::InstNote)| {
            let lx = lx.clone();
            entered(once_job(move || {
                let acc = p0;
                let u = p1;
                call_then(start_expanded(lx.clone(), inst_at(&lx, &u)), move |expanded_66232: Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)>| prism_rtl::Turn::Finished(fold(&expanded_66232, &acc, &(|a: &Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)>, i: &(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)| if fold(a, &false, &(|seen: &bool, j: &(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)| *seen || (&show_text(j) == &show_text(i)))) {
                    a.clone()
                } else {
                    push(a, i)
                }))))
            }))
        }) as Rc<dyn Fn((Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)>, crate::check::typed::InstNote)) -> Rc<dyn prism_rtl::Job<Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)>>>>
    }))
}

/// The step machine of `Instantiations`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Instantiations: unbounded fn Lx, GenNote -> [(([((Text, Ty))], [((Text, Col))]))]
/// ```
pub struct Instantiations {
    pub lx: crate::lower::Lx,
    pub gn: crate::check::typed::GenNote,
}

impl prism_rtl::Job<Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)>> for Instantiations {
    fn cycle(&self) -> prism_rtl::Turn<Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)>> {
        let lx = &self.lx;
        let gn = &self.gn;
        fold_job(or(&get(&lx.insts, &gen_key(gn)), &Array::new()), Array::new(), {
            let lx = lx.clone();
            Rc::new(move |(p0, p1): (Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)>, crate::check::typed::InstNote)| {
                let lx = lx.clone();
                entered(once_job(move || {
                    let acc = p0;
                    let u = p1;
                    call_then(start_expanded(lx.clone(), inst_at(&lx, &u)), move |expanded_66232: Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)>| prism_rtl::Turn::Finished(fold(&expanded_66232, &acc, &(|a: &Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)>, i: &(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)| if fold(a, &false, &(|seen: &bool, j: &(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)| *seen || (&show_text(j) == &show_text(i)))) {
                        a.clone()
                    } else {
                        push(a, i)
                    }))))
                }))
            }) as Rc<dyn Fn((Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)>, crate::check::typed::InstNote)) -> Rc<dyn prism_rtl::Job<Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)>>>>
        }).cycle()
    }
}

/// `Start Instantiations, x`: what the function value is when passed to `@Run`.
pub fn start_instantiations(lx: crate::lower::Lx, gn: crate::check::typed::GenNote) -> Rc<dyn prism_rtl::Job<Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)>>> {
    Rc::new(Instantiations { lx, gn })
}

/// ```prism
/// Expanded: unbounded fn Lx, (([((Text, Ty))], [((Text, Col))])) -> [(([((Text, Ty))], [((Text, Col))]))]
/// ```
pub fn expanded(lx: &crate::lower::Lx, i: &(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)) -> Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)> {
    match open_q(lx, i) {
        None => Array::from(vec![i.clone()]),
        Some(q) => match get(&lx.gen_of_q, &q) {
            Some(g) => run_to_end(fold_job(instantiations(lx, &g), Array::new(), {
                let lx = lx.clone();
                let i = i.clone();
                Rc::new(move |(p0, p1): (Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)>, (Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>))| {
                    let lx = lx.clone();
                    let i = i.clone();
                    entered(once_job(move || {
                        let acc = p0;
                        let gi = p1;
                        {
                            let lx2 = at_instance(&lx, &gi);
                            call_then(start_expanded(lx2.clone(), subst_inst(&lx2, &i)), move |expanded_66665: Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)>| prism_rtl::Turn::Finished(append(&acc, &expanded_66665)))
                        }
                    }))
                }) as Rc<dyn Fn((Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)>, (Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>))) -> Rc<dyn prism_rtl::Job<Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)>>>>
            })),
            None => Array::from(vec![i.clone()]),
        },
    }
}

/// The step machine of `Expanded`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Expanded: unbounded fn Lx, (([((Text, Ty))], [((Text, Col))])) -> [(([((Text, Ty))], [((Text, Col))]))]
/// ```
pub struct Expanded {
    pub lx: crate::lower::Lx,
    pub i: (Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>),
}

impl prism_rtl::Job<Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)>> for Expanded {
    fn cycle(&self) -> prism_rtl::Turn<Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)>> {
        let lx = &self.lx;
        let i = &self.i;
        let i = i.clone();
        let lx = lx.clone();
        call_then(start_open_q(lx.clone(), i.clone()), move |open_q_66483: Option<Text>| match open_q_66483 {
            None => prism_rtl::Turn::Finished(Array::from(vec![i.clone()])),
            Some(q) => match get(&lx.gen_of_q, &q) {
                Some(g) => call_then(start_instantiations(lx.clone(), g.clone()), move |instantiations_66560: Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)>| fold_job(instantiations_66560, Array::new(), {
                    let lx = lx.clone();
                    let i = i.clone();
                    Rc::new(move |(p0, p1): (Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)>, (Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>))| {
                        let lx = lx.clone();
                        let i = i.clone();
                        entered(once_job(move || {
                            let acc = p0;
                            let gi = p1;
                            {
                                let lx2 = at_instance(&lx, &gi);
                                call_then(start_expanded(lx2.clone(), subst_inst(&lx2, &i)), move |expanded_66665: Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)>| prism_rtl::Turn::Finished(append(&acc, &expanded_66665)))
                            }
                        }))
                    }) as Rc<dyn Fn((Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)>, (Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>))) -> Rc<dyn prism_rtl::Job<Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)>>>>
                }).cycle()),
                None => prism_rtl::Turn::Finished(Array::from(vec![i.clone()])),
            },
        })
    }
}

/// `Start Expanded, x`: what the function value is when passed to `@Run`.
pub fn start_expanded(lx: crate::lower::Lx, i: (Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)) -> Rc<dyn prism_rtl::Job<Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)>>> {
    Rc::new(Expanded { lx, i })
}

/// ```prism
/// SubstInst: fn Lx, (([((Text, Ty))], [((Text, Col))])) -> (([((Text, Ty))], [((Text, Col))]))
/// ```
pub fn subst_inst(lx: &crate::lower::Lx, arg1: &(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)) -> (Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>) {
    match arg1 {
        (tys, cols) => {
            let tys2 = each(tys, &(|(q, t): &(Text, crate::check::types::Ty)| (q.clone(), crate::lower::subst_ty(lx, t))));
            let cols2 = each(cols, &(|(q, c): &(Text, crate::check::types::Col)| (q.clone(), crate::lower::inst_col(lx, c))));
            (tys2.clone(), cols2.clone())
        },
    }
}

/// ```prism
/// ?OpenQ: unbounded fn Lx, (([((Text, Ty))], [((Text, Col))])) -> ?Text
/// ```
pub fn open_q(lx: &crate::lower::Lx, arg1: &(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)) -> Option<Text> {
    match arg1 {
        (tys, cols) => {
            let from_cols = fold(cols, &Array::new(), &(|acc: &Array<Text>, (_, c): &(Text, crate::check::types::Col)| append(acc, &open_cols(lx, c))));
            let all = run_to_end(fold_job(tys.clone(), from_cols.clone(), {
                let lx = lx.clone();
                Rc::new(move |(p0, p1): (Array<Text>, (Text, crate::check::types::Ty))| {
                    let lx = lx.clone();
                    entered(once_job(move || {
                        let acc = p0;
                        let (_, t) = p1;
                        call_then(start_open_ty_qs(lx.clone(), t.clone()), move |open_ty_qs_67346: Array<Text>| prism_rtl::Turn::Finished(append(&acc, &open_ty_qs_67346)))
                    }))
                }) as Rc<dyn Fn((Array<Text>, (Text, crate::check::types::Ty))) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
            }));
            index(&all, &Nat::from(0u32))
        },
    }
}

/// The step machine of `OpenQ`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?OpenQ: unbounded fn Lx, (([((Text, Ty))], [((Text, Col))])) -> ?Text
/// ```
pub struct OpenQ {
    pub lx: crate::lower::Lx,
    pub arg1: (Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>),
}

impl prism_rtl::Job<Option<Text>> for OpenQ {
    fn cycle(&self) -> prism_rtl::Turn<Option<Text>> {
        let lx = &self.lx;
        let arg1 = &self.arg1;
        match arg1 {
            (tys, cols) => {
                let from_cols = fold(cols, &Array::new(), &(|acc: &Array<Text>, (_, c): &(Text, crate::check::types::Col)| append(acc, &open_cols(lx, c))));
                let lx = lx.clone();
                let tys = tys.clone();
                call_value(fold_job(tys.clone(), from_cols.clone(), {
                    let lx = lx.clone();
                    Rc::new(move |(p0, p1): (Array<Text>, (Text, crate::check::types::Ty))| {
                        let lx = lx.clone();
                        entered(once_job(move || {
                            let acc = p0;
                            let (_, t) = p1;
                            call_then(start_open_ty_qs(lx.clone(), t.clone()), move |open_ty_qs_67346: Array<Text>| prism_rtl::Turn::Finished(append(&acc, &open_ty_qs_67346)))
                        }))
                    }) as Rc<dyn Fn((Array<Text>, (Text, crate::check::types::Ty))) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
                }), move |fold_67291: Array<Text>| {
                    let all = fold_67291;
                    prism_rtl::Turn::Finished(index(&all, &Nat::from(0u32)))
                })
            },
        }
    }
}

/// `Start OpenQ, x`: what the function value is when passed to `@Run`.
pub fn start_open_q(lx: crate::lower::Lx, arg1: (Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)) -> Rc<dyn prism_rtl::Job<Option<Text>>> {
    Rc::new(OpenQ { lx, arg1 })
}

/// ```prism
/// OpenCols: fn Lx, Col -> [Text]
/// ```
pub fn open_cols(lx: &crate::lower::Lx, col1: &crate::check::types::Col) -> Array<Text> {
    match col1 {
        crate::check::types::Col::CQ(q) => if crate::check::env::has_key(&lx.gen_of_q, q) && !crate::check::env::has_key(&lx.csubst, q) {
            Array::from(vec![q.clone()])
        } else {
            Array::new()
        },
        c => Array::new(),
    }
}

/// ```prism
/// OpenTyQs: unbounded fn Lx, Ty -> [Text]
/// ```
pub fn open_ty_qs(lx: &crate::lower::Lx, t: &crate::check::types::Ty) -> Array<Text> {
    match t {
        crate::check::types::Ty::TyFlex(n) => if crate::check::env::has_key(&lx.gen_of_q, &Text::from(format!("\'{}", n))) && !crate::check::env::has_key(&lx.subst, &Text::from(format!("\'{}", n))) {
            Array::from(vec![Text::from(format!("\'{}", n))])
        } else {
            Array::new()
        },
        crate::check::types::Ty::TyFn(c, ps, res) => run_to_end(fold_job(push(ps, &**res), open_cols(lx, c), {
            let lx = lx.clone();
            Rc::new(move |(p0, p1): (Array<Text>, crate::check::types::Ty)| {
                let lx = lx.clone();
                entered(once_job(move || {
                    let acc = p0;
                    let x = p1;
                    call_then(start_open_ty_qs(lx.clone(), x.clone()), move |open_ty_qs_67782: Array<Text>| prism_rtl::Turn::Finished(append(&acc, &open_ty_qs_67782)))
                }))
            }) as Rc<dyn Fn((Array<Text>, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
        })),
        crate::check::types::Ty::TyCon(_, args) => run_to_end(fold_job(args.clone(), Array::new(), {
            let lx = lx.clone();
            Rc::new(move |(p0, p1): (Array<Text>, crate::check::types::Ty)| {
                let lx = lx.clone();
                entered(once_job(move || {
                    let acc = p0;
                    let x = p1;
                    call_then(start_open_ty_qs(lx.clone(), x.clone()), move |open_ty_qs_67862: Array<Text>| prism_rtl::Turn::Finished(append(&acc, &open_ty_qs_67862)))
                }))
            }) as Rc<dyn Fn((Array<Text>, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
        })),
        crate::check::types::Ty::TyTuple(ts) => run_to_end(fold_job(ts.clone(), Array::new(), {
            let lx = lx.clone();
            Rc::new(move |(p0, p1): (Array<Text>, crate::check::types::Ty)| {
                let lx = lx.clone();
                entered(once_job(move || {
                    let acc = p0;
                    let x = p1;
                    call_then(start_open_ty_qs(lx.clone(), x.clone()), move |open_ty_qs_67932: Array<Text>| prism_rtl::Turn::Finished(append(&acc, &open_ty_qs_67932)))
                }))
            }) as Rc<dyn Fn((Array<Text>, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
        })),
        crate::check::types::Ty::TyArray(e) => open_ty_qs(lx, &**e),
        crate::check::types::Ty::TyMap(k, v_) => append(&open_ty_qs(lx, &**k), &open_ty_qs(lx, &**v_)),
        crate::check::types::Ty::TySig(_, i) => open_ty_qs(lx, &**i),
        crate::check::types::Ty::TyAt(i, _) => open_ty_qs(lx, &**i),
        crate::check::types::Ty::TyElem(_, o) => open_ty_qs(lx, &**o),
        crate::check::types::Ty::TyAssoc(_, a) => open_ty_qs(lx, &**a),
        _ => Array::new(),
    }
}

/// The step machine of `OpenTyQs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// OpenTyQs: unbounded fn Lx, Ty -> [Text]
/// ```
pub struct OpenTyQs {
    pub lx: crate::lower::Lx,
    pub t: crate::check::types::Ty,
}

impl prism_rtl::Job<Array<Text>> for OpenTyQs {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let lx = &self.lx;
        let t = &self.t;
        match t {
            crate::check::types::Ty::TyFlex(n) => if crate::check::env::has_key(&lx.gen_of_q, &Text::from(format!("\'{}", n))) && !crate::check::env::has_key(&lx.subst, &Text::from(format!("\'{}", n))) {
                prism_rtl::Turn::Finished(Array::from(vec![Text::from(format!("\'{}", n))]))
            } else {
                prism_rtl::Turn::Finished(Array::new())
            },
            crate::check::types::Ty::TyFn(c, ps, res) => fold_job(push(ps, &**res), open_cols(lx, c), {
                let lx = lx.clone();
                Rc::new(move |(p0, p1): (Array<Text>, crate::check::types::Ty)| {
                    let lx = lx.clone();
                    entered(once_job(move || {
                        let acc = p0;
                        let x = p1;
                        call_then(start_open_ty_qs(lx.clone(), x.clone()), move |open_ty_qs_67782: Array<Text>| prism_rtl::Turn::Finished(append(&acc, &open_ty_qs_67782)))
                    }))
                }) as Rc<dyn Fn((Array<Text>, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
            }).cycle(),
            crate::check::types::Ty::TyCon(_, args) => fold_job(args.clone(), Array::new(), {
                let lx = lx.clone();
                Rc::new(move |(p0, p1): (Array<Text>, crate::check::types::Ty)| {
                    let lx = lx.clone();
                    entered(once_job(move || {
                        let acc = p0;
                        let x = p1;
                        call_then(start_open_ty_qs(lx.clone(), x.clone()), move |open_ty_qs_67862: Array<Text>| prism_rtl::Turn::Finished(append(&acc, &open_ty_qs_67862)))
                    }))
                }) as Rc<dyn Fn((Array<Text>, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
            }).cycle(),
            crate::check::types::Ty::TyTuple(ts) => fold_job(ts.clone(), Array::new(), {
                let lx = lx.clone();
                Rc::new(move |(p0, p1): (Array<Text>, crate::check::types::Ty)| {
                    let lx = lx.clone();
                    entered(once_job(move || {
                        let acc = p0;
                        let x = p1;
                        call_then(start_open_ty_qs(lx.clone(), x.clone()), move |open_ty_qs_67932: Array<Text>| prism_rtl::Turn::Finished(append(&acc, &open_ty_qs_67932)))
                    }))
                }) as Rc<dyn Fn((Array<Text>, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
            }).cycle(),
            crate::check::types::Ty::TyArray(e) => prism_rtl::Turn::More(Rc::new(OpenTyQs { lx: lx.clone(), t: (**e).clone() })),
            crate::check::types::Ty::TyMap(k, v_) => {
                let k = (**k).clone();
                let lx = lx.clone();
                let v_ = (**v_).clone();
                call_then(start_open_ty_qs(lx.clone(), k.clone()), move |open_ty_qs_68002: Array<Text>| call_then(start_open_ty_qs(lx.clone(), v_.clone()), move |open_ty_qs_68020: Array<Text>| prism_rtl::Turn::Finished(append(&open_ty_qs_68002, &open_ty_qs_68020))))
            },
            crate::check::types::Ty::TySig(_, i) => prism_rtl::Turn::More(Rc::new(OpenTyQs { lx: lx.clone(), t: (**i).clone() })),
            crate::check::types::Ty::TyAt(i, _) => prism_rtl::Turn::More(Rc::new(OpenTyQs { lx: lx.clone(), t: (**i).clone() })),
            crate::check::types::Ty::TyElem(_, o) => prism_rtl::Turn::More(Rc::new(OpenTyQs { lx: lx.clone(), t: (**o).clone() })),
            crate::check::types::Ty::TyAssoc(_, a) => prism_rtl::Turn::More(Rc::new(OpenTyQs { lx: lx.clone(), t: (**a).clone() })),
            _ => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start OpenTyQs, x`: what the function value is when passed to `@Run`.
pub fn start_open_ty_qs(lx: crate::lower::Lx, t: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(OpenTyQs { lx, t })
}

/// ```prism
/// AtInstance: fn Lx, (([((Text, Ty))], [((Text, Col))])) -> Lx
/// ```
pub fn at_instance(lx: &crate::lower::Lx, arg1: &(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)) -> crate::lower::Lx {
    match arg1 {
        (tys, cols) => {
            let mut this: crate::lower::Lx = lx.clone();
            this.subst = fold(tys, &this.subst, &(|m: &Map<Text, crate::check::types::Ty>, (q, t): &(Text, crate::check::types::Ty)| insert(m, q, t)));
            this.csubst = fold(cols, &this.csubst, &(|m: &Map<Text, crate::check::types::Col>, (q, c): &(Text, crate::check::types::Col)| insert(m, q, c)));
            this
        },
    }
}

/// ```prism
/// WidgetLetLx: unbounded fn Lx, Range -> Lx
/// ```
pub fn widget_let_lx(lx: &crate::lower::Lx, span: &crate::syntax::Range) -> crate::lower::Lx {
    match get(&lx.gens, &crate::lower::place_key(lx, span)) {
        Some(gn) => 'm68841: {
            let scrutinee = &instantiations(lx, &gn);
            if let m68841_0 = scrutinee && (m68841_0.len() == 1) && let Some(i) = index(m68841_0, &Nat::from(0u32)) {
                break 'm68841 at_instance(lx, &i);
            }
            lx.clone()
        },
        None => lx.clone(),
    }
}

/// The step machine of `WidgetLetLx`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// WidgetLetLx: unbounded fn Lx, Range -> Lx
/// ```
pub struct WidgetLetLx {
    pub lx: crate::lower::Lx,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<crate::lower::Lx> for WidgetLetLx {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::Lx> {
        let lx = &self.lx;
        let span = &self.span;
        match get(&lx.gens, &crate::lower::place_key(lx, span)) {
            Some(gn) => {
                let lx = lx.clone();
                call_then(start_instantiations(lx.clone(), gn.clone()), move |instantiations_68847: Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)>| 'm68841: {
                    if let m68841_0 = &instantiations_68847 && (m68841_0.len() == 1) && let Some(i) = index(m68841_0, &Nat::from(0u32)) {
                        break 'm68841 prism_rtl::Turn::Finished(at_instance(&lx, &i));
                    }
                    prism_rtl::Turn::Finished(lx.clone())
                })
            },
            None => prism_rtl::Turn::Finished(lx.clone()),
        }
    }
}

/// `Start WidgetLetLx, x`: what the function value is when passed to `@Run`.
pub fn start_widget_let_lx(lx: crate::lower::Lx, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<crate::lower::Lx>> {
    Rc::new(WidgetLetLx { lx, span })
}

/// ```prism
/// InstAt: fn Lx, InstNote -> (([((Text, Ty))], [((Text, Col))]))
/// ```
pub fn inst_at(lx: &crate::lower::Lx, u: &crate::check::typed::InstNote) -> (Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>) {
    let tys = each(&u.tys, &(|(q, t): &(Text, crate::check::types::Ty)| (q.clone(), crate::lower::subst_ty(lx, t))));
    let cols = each(&u.cols, &(|(q, c): &(Text, crate::check::types::Col)| (q.clone(), crate::lower::inst_col(lx, c))));
    (tys.clone(), cols.clone())
}

/// ```prism
/// GenKey: fn GenNote -> Text
/// ```
pub fn gen_key(gn: &crate::check::typed::GenNote) -> Text {
    or(&index(&append(&gn.tys, &gn.cols), &Nat::from(0u32)), &Text::lit(""))
}

/// ```prism
/// InstKey: fn InstNote -> Text
/// ```
pub fn inst_key(u: &crate::check::typed::InstNote) -> Text {
    or(&index(&append(&each(&u.tys, &(|(q, _): &(Text, crate::check::types::Ty)| q.clone())), &each(&u.cols, &(|(q, _): &(Text, crate::check::types::Col)| q.clone()))), &Nat::from(0u32)), &Text::lit(""))
}

/// ```prism
/// ColName: fn Col -> Text
/// ```
pub fn col_name(col0: &crate::check::types::Col) -> Text {
    match col0 {
        crate::check::types::Col::CQ(q) => q.clone(),
        c => Text::lit(""),
    }
}

/// ```prism
/// PlainLet: unbounded fn Lx, Env, Stmt, Pattern, Expr -> (([Do], Env))
/// ```
pub fn plain_let(lx: &crate::lower::Lx, env: &crate::lower::types::Env, s: &crate::syntax::Stmt, p_: &crate::syntax::Pattern_, x: &crate::syntax::Expr) -> (Array<crate::lower::model::Do>, crate::lower::types::Env) {
    let v_ = value_of(lx, env, x);
    let po = crate::lower::patterns::rust_pat(lx, p_, &crate::lower::type_at(lx, &x.span), &crate::lower::types::Holding::Owned, &Text::from(format!("l{}", &s.span.start)));
    (Array::from(vec![crate::lower::model::Do::DoLet(po.pa.clone(), crate::lower::types::own(&v_))]), bind_all(env, &po.binds))
}

/// The step machine of `PlainLet`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PlainLet: unbounded fn Lx, Env, Stmt, Pattern, Expr -> (([Do], Env))
/// ```
pub struct PlainLet {
    pub lx: crate::lower::Lx,
    pub env: crate::lower::types::Env,
    pub s: crate::syntax::Stmt,
    pub p_: crate::syntax::Pattern_,
    pub x: crate::syntax::Expr,
}

impl prism_rtl::Job<(Array<crate::lower::model::Do>, crate::lower::types::Env)> for PlainLet {
    fn cycle(&self) -> prism_rtl::Turn<(Array<crate::lower::model::Do>, crate::lower::types::Env)> {
        let lx = &self.lx;
        let env = &self.env;
        let s = &self.s;
        let p_ = &self.p_;
        let x = &self.x;
        let env = env.clone();
        let lx = lx.clone();
        let p_ = p_.clone();
        let s = s.clone();
        let x = x.clone();
        call_then(start_value_of(lx.clone(), env.clone(), x.clone()), move |value_of_69632: crate::lower::types::Vl| {
            let v_ = value_of_69632;
            call_then(crate::lower::patterns::start_rust_pat(lx.clone(), p_.clone(), crate::lower::type_at(&lx, &x.span), crate::lower::types::Holding::Owned, Text::from(format!("l{}", &s.span.start))), move |rust_pat_69668: crate::lower::patterns::PatOut| {
                let po = rust_pat_69668;
                prism_rtl::Turn::Finished((Array::from(vec![crate::lower::model::Do::DoLet(po.pa.clone(), crate::lower::types::own(&v_))]), bind_all(&env, &po.binds)))
            })
        })
    }
}

/// `Start PlainLet, x`: what the function value is when passed to `@Run`.
pub fn start_plain_let(lx: crate::lower::Lx, env: crate::lower::types::Env, s: crate::syntax::Stmt, p_: crate::syntax::Pattern_, x: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<(Array<crate::lower::model::Do>, crate::lower::types::Env)>> {
    Rc::new(PlainLet { lx, env, s, p_, x })
}
