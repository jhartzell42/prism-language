//! The module `Lower.Node.Dynamics`, from `target/bootstrap/src/prismc/lower/node/dynamics.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// ```prism
/// DynamicExpr: unbounded fn Wx, Env, Expr -> ((Ex, [Read]))
/// ```
pub fn dynamic_expr(wx: &crate::lower::node_::Wx, menv: &crate::lower::types::Env, e: &crate::syntax::Expr) -> (crate::lower::model::Ex, Array<crate::lower::node_::Read>) {
    let v_ = crate::lower::expr::value_of(&wx.lx, menv, e);
    let reads = fold(&crate::check::typed::print::exprs_in(e), &Array::new(), &(|acc: &Array<crate::lower::node_::Read>, x: &crate::syntax::Expr| match &*x.kind {
        crate::syntax::ExprKind::EName(n) => match get(&menv.names, &crate::check::env::sname_key(n)) {
            Some(crate::lower::types::Bn::BnHold(f, _)) => crate::lower::node_::add_read(acc, &crate::lower::node_::Read::OwnRead(f.clone())),
            Some(crate::lower::types::Bn::BnDyn(_, rs, _)) => crate::lower::node_::union_reads(acc, &rs),
            _ => acc.clone(),
        },
        _ => acc.clone(),
    }));
    (crate::lower::types::own(&v_), reads.clone())
}

/// The step machine of `DynamicExpr`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// DynamicExpr: unbounded fn Wx, Env, Expr -> ((Ex, [Read]))
/// ```
pub struct DynamicExpr {
    pub wx: crate::lower::node_::Wx,
    pub menv: crate::lower::types::Env,
    pub e: crate::syntax::Expr,
}

impl prism_rtl::Job<(crate::lower::model::Ex, Array<crate::lower::node_::Read>)> for DynamicExpr {
    fn cycle(&self) -> prism_rtl::Turn<(crate::lower::model::Ex, Array<crate::lower::node_::Read>)> {
        let wx = &self.wx;
        let menv = &self.menv;
        let e = &self.e;
        let e = e.clone();
        let menv = menv.clone();
        let wx = wx.clone();
        call_then(crate::lower::expr::start_value_of(wx.lx.clone(), menv.clone(), e.clone()), move |value_of_1581: crate::lower::types::Vl| {
            let v_ = value_of_1581;
            call_then(crate::check::typed::print::start_exprs_in(e.clone()), move |exprs_in_1626: Array<crate::syntax::Expr>| {
                let reads = fold(&exprs_in_1626, &Array::new(), &(|acc: &Array<crate::lower::node_::Read>, x: &crate::syntax::Expr| match &*x.kind {
                    crate::syntax::ExprKind::EName(n) => match get(&menv.names, &crate::check::env::sname_key(n)) {
                        Some(crate::lower::types::Bn::BnHold(f, _)) => crate::lower::node_::add_read(acc, &crate::lower::node_::Read::OwnRead(f.clone())),
                        Some(crate::lower::types::Bn::BnDyn(_, rs, _)) => crate::lower::node_::union_reads(acc, &rs),
                        _ => acc.clone(),
                    },
                    _ => acc.clone(),
                }));
                prism_rtl::Turn::Finished((crate::lower::types::own(&v_), reads.clone()))
            })
        })
    }
}

/// `Start DynamicExpr, x`: what the function value is when passed to `@Run`.
pub fn start_dynamic_expr(wx: crate::lower::node_::Wx, menv: crate::lower::types::Env, e: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<(crate::lower::model::Ex, Array<crate::lower::node_::Read>)>> {
    Rc::new(DynamicExpr { wx, menv, e })
}

/// ```prism
/// NeverEvent: fn Wx, OutTy -> ((EvRef, Wx))
/// ```
pub fn never_event(wx: &crate::lower::node_::Wx, t: &crate::lower::model::OutTy) -> (crate::lower::node_::EvRef, crate::lower::node_::Wx) {
    let (id, wx2) = crate::lower::node_::add_gn(wx, &Text::lit("never"), t, &crate::lower::node_::GnKind::GnNever, &Nat::from(0u32));
    (crate::lower::node_::ev_ref_of(&wx2, &id), wx2.clone())
}

/// ```prism
/// EventRef: unbounded fn Wx, Env, Expr -> ((EvRef, Wx))
/// ```
pub fn event_ref(wx: &crate::lower::node_::Wx, menv: &crate::lower::types::Env, e: &crate::syntax::Expr) -> (crate::lower::node_::EvRef, crate::lower::node_::Wx) {
    let lx = wx.lx.clone();
    let t = crate::lower::types::out_ty_of(&lx, &crate::lower::types::peel(&crate::lower::type_at(&lx, &e.span)));
    'm2490: {
        let scrutinee = &*e.kind;
        if let crate::syntax::ExprKind::EGroup(x) = scrutinee {
            break 'm2490 event_ref(wx, menv, &**x);
        }
        if let crate::syntax::ExprKind::EName(n) = scrutinee {
            break 'm2490 match get(&menv.names, &crate::check::env::sname_key(n)) {
                Some(crate::lower::types::Bn::BnEv(r, _)) => if &r.owner == &wx.node_ {
                    (r.clone(), wx.clone())
                } else {
                    never_event(&crate::lower::node_::crossed(wx, &Text::from(format!("the event `{}`, of node `{}`,", &crate::check::env::sname_key(n), &r.owner))), &t)
                },
                _ => never_event(wx, &t),
            };
        }
        if let crate::syntax::ExprKind::EBinary(m2490_2_0, l, r) = scrutinee && (m2490_2_0 == &Text::lit("<|")) {
            break 'm2490 {
                let (lr, w1) = event_ref(wx, menv, &**l);
                let (rr, w2) = event_ref(&w1, menv, &**r);
                let (nm, w3) = crate::lower::node_::fresh_name(&w2, &Text::lit("anon"));
                let (id, w4) = merge(&w3, &nm, &t, &lr, &rr);
                (crate::lower::node_::ev_ref_of(&w4, &id), w4.clone())
            };
        }
        if let crate::syntax::ExprKind::EBinary(m2490_3_0, l, r) = scrutinee && (m2490_3_0 == &Text::lit("on")) {
            break 'm2490 {
                let (rr, w1) = event_ref(wx, menv, &**r);
                let value = crate::lower::types::own(&crate::lower::expr::value_of(&lx, menv, &**l));
                (crate::lower::node_::EvRef { node_: rr.node_.clone(), owner: rr.owner.clone(), pipe: {
                    let rr = rr.clone();
                    let value = value.clone();
                    Rc::new(move |(p0, p1): (crate::lower::model::Ex, Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>)| {
                        let rr = rr.clone();
                        let value = value.clone();
                        entered(once_job(move || {
                            let x = p0;
                            let k_fn = p1;
                            (&rr.pipe)((x.clone(), {
                                let k_fn = k_fn.clone();
                                let value = value.clone();
                                Rc::new(move |p0: crate::lower::model::Ex| {
                                    let k_fn = k_fn.clone();
                                    let value = value.clone();
                                    entered(once_job(move || {
                                        let _ = p0;
                                        (&k_fn)(value.clone()).cycle()
                                    }))
                                }) as Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>
                            })).cycle()
                        }))
                    }) as Rc<dyn Fn((crate::lower::model::Ex, Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>)) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>
                } }, w1.clone())
            };
        }
        if let crate::syntax::ExprKind::ECall(c, args, _, _) = scrutinee {
            break 'm2490 match callee_key(&lx, &**c) {
                m3346_0 if (&m3346_0 == &Text::lit("Prelude.!Filter")) => filter_event(wx, menv, args, &false),
                m3346_1 if (&m3346_1 == &Text::lit("Prelude.!Present")) => filter_event(wx, menv, args, &true),
                m3346_2 if (&m3346_2 == &Text::lit("Prelude.!Gate")) => gate_event(wx, menv, args),
                m3346_3 if (&m3346_3 == &Text::lit("Prelude.!Union")) => pair_event(wx, menv, args, &crate::lower::node_::GnKind::GnUnion, &t),
                m3346_4 if (&m3346_4 == &Text::lit("Prelude.!Both")) => pair_event(wx, menv, args, &crate::lower::node_::GnKind::GnBoth, &t),
                m3346_5 if (&m3346_5 == &Text::lit("Prelude.!Except")) => pair_event(wx, menv, args, &crate::lower::node_::GnKind::GnExcept, &t),
                m3346_6 if (&m3346_6 == &Text::lit("Prelude.!MergeAll")) => merge_all_event(wx, menv, args, &t),
                m3346_7 if (&m3346_7 == &Text::lit("Prelude.!Updated")) => updated_event(wx, menv, args, &t),
                _ => event_map(wx, menv, e),
                _ => unreachable!("no arm matched"),
            };
        }
        if let crate::syntax::ExprKind::EIf(m2490_5_0, then_b, Some(else_b)) = scrutinee && let crate::syntax::Cond::CondExpr(c) = &**m2490_5_0 {
            break 'm2490 match (block_expr(then_b), block_expr(else_b)) {
                (Some(a), Some(b)) => event_if(wx, menv, &**c, &a, &b, &t),
                _ => event_map(wx, menv, e),
            };
        }
        event_map(wx, menv, e)
    }
}

/// The step machine of `EventRef`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// EventRef: unbounded fn Wx, Env, Expr -> ((EvRef, Wx))
/// ```
pub struct EventRef {
    pub wx: crate::lower::node_::Wx,
    pub menv: crate::lower::types::Env,
    pub e: crate::syntax::Expr,
}

impl prism_rtl::Job<(crate::lower::node_::EvRef, crate::lower::node_::Wx)> for EventRef {
    fn cycle(&self) -> prism_rtl::Turn<(crate::lower::node_::EvRef, crate::lower::node_::Wx)> {
        let wx = &self.wx;
        let menv = &self.menv;
        let e = &self.e;
        let lx = wx.lx.clone();
        let e = e.clone();
        let menv = menv.clone();
        let wx = wx.clone();
        call_then(crate::lower::types::start_out_ty_of(lx.clone(), crate::lower::types::peel(&crate::lower::type_at(&lx, &e.span))), move |out_ty_of_2447: crate::lower::model::OutTy| {
            let t = out_ty_of_2447;
            'm2490: {
                let scrutinee = &*e.kind;
                if let crate::syntax::ExprKind::EGroup(x) = scrutinee {
                    break 'm2490 prism_rtl::Turn::More(Rc::new(EventRef { wx: wx.clone(), menv: menv.clone(), e: (**x).clone() }));
                }
                if let crate::syntax::ExprKind::EName(n) = scrutinee {
                    break 'm2490 match get(&menv.names, &crate::check::env::sname_key(n)) {
                        Some(crate::lower::types::Bn::BnEv(r, _)) => if &r.owner == &wx.node_ {
                            prism_rtl::Turn::Finished((r.clone(), wx.clone()))
                        } else {
                            prism_rtl::Turn::Finished(never_event(&crate::lower::node_::crossed(&wx, &Text::from(format!("the event `{}`, of node `{}`,", &crate::check::env::sname_key(n), &r.owner))), &t))
                        },
                        _ => prism_rtl::Turn::Finished(never_event(&wx, &t)),
                    };
                }
                if let crate::syntax::ExprKind::EBinary(m2490_2_0, l, r) = scrutinee && (m2490_2_0 == &Text::lit("<|")) {
                    break 'm2490 {
                        let l = (**l).clone();
                        let r = (**r).clone();
                        call_then(start_event_ref(wx.clone(), menv.clone(), l.clone()), move |event_ref_2867: (crate::lower::node_::EvRef, crate::lower::node_::Wx)| {
                            let (lr, w1) = event_ref_2867;
                            call_then(start_event_ref(w1.clone(), menv.clone(), r.clone()), move |event_ref_2917: (crate::lower::node_::EvRef, crate::lower::node_::Wx)| {
                                let (rr, w2) = event_ref_2917;
                                let (nm, w3) = crate::lower::node_::fresh_name(&w2, &Text::lit("anon"));
                                let (id, w4) = merge(&w3, &nm, &t, &lr, &rr);
                                prism_rtl::Turn::Finished((crate::lower::node_::ev_ref_of(&w4, &id), w4.clone()))
                            })
                        })
                    };
                }
                if let crate::syntax::ExprKind::EBinary(m2490_3_0, l, r) = scrutinee && (m2490_3_0 == &Text::lit("on")) {
                    break 'm2490 {
                        let l = (**l).clone();
                        let r = (**r).clone();
                        call_then(start_event_ref(wx.clone(), menv.clone(), r.clone()), move |event_ref_3135: (crate::lower::node_::EvRef, crate::lower::node_::Wx)| {
                            let (rr, w1) = event_ref_3135;
                            call_then(crate::lower::expr::start_value_of(lx.clone(), menv.clone(), l.clone()), move |value_of_3185: crate::lower::types::Vl| {
                                let value = crate::lower::types::own(&value_of_3185);
                                prism_rtl::Turn::Finished((crate::lower::node_::EvRef { node_: rr.node_.clone(), owner: rr.owner.clone(), pipe: {
                                    let rr = rr.clone();
                                    let value = value.clone();
                                    Rc::new(move |(p0, p1): (crate::lower::model::Ex, Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>)| {
                                        let rr = rr.clone();
                                        let value = value.clone();
                                        entered(once_job(move || {
                                            let x = p0;
                                            let k_fn = p1;
                                            (&rr.pipe)((x.clone(), {
                                                let k_fn = k_fn.clone();
                                                let value = value.clone();
                                                Rc::new(move |p0: crate::lower::model::Ex| {
                                                    let k_fn = k_fn.clone();
                                                    let value = value.clone();
                                                    entered(once_job(move || {
                                                        let _ = p0;
                                                        (&k_fn)(value.clone()).cycle()
                                                    }))
                                                }) as Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>
                                            })).cycle()
                                        }))
                                    }) as Rc<dyn Fn((crate::lower::model::Ex, Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>)) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>
                                } }, w1.clone()))
                            })
                        })
                    };
                }
                if let crate::syntax::ExprKind::ECall(c, args, _, _) = scrutinee {
                    break 'm2490 match callee_key(&lx, &**c) {
                        m3346_0 if (&m3346_0 == &Text::lit("Prelude.!Filter")) => prism_rtl::Turn::Finished(filter_event(&wx, &menv, args, &false)),
                        m3346_1 if (&m3346_1 == &Text::lit("Prelude.!Present")) => prism_rtl::Turn::Finished(filter_event(&wx, &menv, args, &true)),
                        m3346_2 if (&m3346_2 == &Text::lit("Prelude.!Gate")) => prism_rtl::Turn::Finished(gate_event(&wx, &menv, args)),
                        m3346_3 if (&m3346_3 == &Text::lit("Prelude.!Union")) => prism_rtl::Turn::Finished(pair_event(&wx, &menv, args, &crate::lower::node_::GnKind::GnUnion, &t)),
                        m3346_4 if (&m3346_4 == &Text::lit("Prelude.!Both")) => prism_rtl::Turn::Finished(pair_event(&wx, &menv, args, &crate::lower::node_::GnKind::GnBoth, &t)),
                        m3346_5 if (&m3346_5 == &Text::lit("Prelude.!Except")) => prism_rtl::Turn::Finished(pair_event(&wx, &menv, args, &crate::lower::node_::GnKind::GnExcept, &t)),
                        m3346_6 if (&m3346_6 == &Text::lit("Prelude.!MergeAll")) => prism_rtl::Turn::Finished(merge_all_event(&wx, &menv, args, &t)),
                        m3346_7 if (&m3346_7 == &Text::lit("Prelude.!Updated")) => prism_rtl::Turn::Finished(updated_event(&wx, &menv, args, &t)),
                        _ => prism_rtl::Turn::Finished(event_map(&wx, &menv, &e)),
                        _ => unreachable!("no arm matched"),
                    };
                }
                if let crate::syntax::ExprKind::EIf(m2490_5_0, then_b, Some(else_b)) = scrutinee && let crate::syntax::Cond::CondExpr(c) = &**m2490_5_0 {
                    break 'm2490 match (block_expr(then_b), block_expr(else_b)) {
                        (Some(a), Some(b)) => prism_rtl::Turn::Finished(event_if(&wx, &menv, &**c, &a, &b, &t)),
                        _ => prism_rtl::Turn::Finished(event_map(&wx, &menv, &e)),
                    };
                }
                prism_rtl::Turn::Finished(event_map(&wx, &menv, &e))
            }
        })
    }
}

/// `Start EventRef, x`: what the function value is when passed to `@Run`.
pub fn start_event_ref(wx: crate::lower::node_::Wx, menv: crate::lower::types::Env, e: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<(crate::lower::node_::EvRef, crate::lower::node_::Wx)>> {
    Rc::new(EventRef { wx, menv, e })
}

/// ```prism
/// EventIf: unbounded fn Wx, Env, Expr, Expr, Expr, OutTy -> ((EvRef, Wx))
/// ```
pub fn event_if(wx: &crate::lower::node_::Wx, menv: &crate::lower::types::Env, c: &crate::syntax::Expr, a: &crate::syntax::Expr, b: &crate::syntax::Expr, t: &crate::lower::model::OutTy) -> (crate::lower::node_::EvRef, crate::lower::node_::Wx) {
    let cond = crate::lower::types::as_bool(&crate::lower::expr::value_of(&wx.lx, menv, c));
    let (ra, w1) = event_ref(wx, menv, a);
    let (rb, w2) = event_ref(&w1, menv, b);
    let ga = crate::lower::node_::EvRef { node_: ra.node_.clone(), owner: ra.owner.clone(), pipe: {
        let ra = ra.clone();
        let cond = cond.clone();
        Rc::new(move |(p0, p1): (crate::lower::model::Ex, Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>)| {
            let ra = ra.clone();
            let cond = cond.clone();
            entered(once_job(move || {
                let x = p0;
                let k_fn = p1;
                (&ra.pipe)((x.clone(), {
                    let cond = cond.clone();
                    let k_fn = k_fn.clone();
                    Rc::new(move |p0: crate::lower::model::Ex| {
                        let cond = cond.clone();
                        let k_fn = k_fn.clone();
                        entered(once_job(move || {
                            let y = p0;
                            call_value((&k_fn)(y.clone()), move |k_4624: Array<crate::lower::model::Do>| prism_rtl::Turn::Finished(Array::from(vec![crate::lower::model::Do::DoIf(cond.clone(), k_4624, Array::new())])))
                        }))
                    }) as Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>
                })).cycle()
            }))
        }) as Rc<dyn Fn((crate::lower::model::Ex, Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>)) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>
    } };
    let gb = crate::lower::node_::EvRef { node_: rb.node_.clone(), owner: rb.owner.clone(), pipe: {
        let rb = rb.clone();
        let cond = cond.clone();
        Rc::new(move |(p0, p1): (crate::lower::model::Ex, Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>)| {
            let rb = rb.clone();
            let cond = cond.clone();
            entered(once_job(move || {
                let x = p0;
                let k_fn = p1;
                (&rb.pipe)((x.clone(), {
                    let cond = cond.clone();
                    let k_fn = k_fn.clone();
                    Rc::new(move |p0: crate::lower::model::Ex| {
                        let cond = cond.clone();
                        let k_fn = k_fn.clone();
                        entered(once_job(move || {
                            let y = p0;
                            call_value((&k_fn)(y.clone()), move |k_4762: Array<crate::lower::model::Do>| prism_rtl::Turn::Finished(Array::from(vec![crate::lower::model::Do::DoIf(crate::lower::model::Ex::XBin(Text::lit("=="), Rc::new(cond.clone()), Rc::new(crate::lower::model::Ex::XBool(false))), k_4762, Array::new())])))
                        }))
                    }) as Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>
                })).cycle()
            }))
        }) as Rc<dyn Fn((crate::lower::model::Ex, Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>)) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>
    } };
    let (nm, w3) = crate::lower::node_::fresh_name(&w2, &Text::lit("chosen"));
    let (id, w4) = merge(&w3, &nm, t, &ga, &gb);
    (crate::lower::node_::ev_ref_of(&w4, &id), w4.clone())
}

/// ```prism
/// ?BlockExpr: fn Block -> ?Expr
/// ```
pub fn block_expr(b: &crate::syntax::Block) -> Option<crate::syntax::Expr> {
    'm4996: {
        let scrutinee = &b.stmts;
        if let m4996_0 = scrutinee && (m4996_0.len() == 1) && let Some(st) = index(m4996_0, &Nat::from(0u32)) {
            break 'm4996 match &st.kind {
                crate::syntax::StmtKind::SExpr(x) => Some(x.clone()),
                _ => None,
            };
        }
        None
    }
}

/// ```prism
/// CalleeKey: fn Lx, Expr -> Text
/// ```
pub fn callee_key(lx: &crate::lower::Lx, c: &crate::syntax::Expr) -> Text {
    match &*c.kind {
        crate::syntax::ExprKind::EName(n) => {
            let (q_opt, _) = crate::check::env::names::resolve_value(&lx.g, &lx.home, n);
            or(&q_opt, &Text::lit(""))
        },
        _ => Text::lit(""),
    }
}

/// ```prism
/// PairEvent: unbounded fn Wx, Env, [Arg], GnKind, OutTy -> ((EvRef, Wx))
/// ```
pub fn pair_event(wx: &crate::lower::node_::Wx, menv: &crate::lower::types::Env, args: &Array<crate::syntax::Arg>, kind: &crate::lower::node_::GnKind, t: &crate::lower::model::OutTy) -> (crate::lower::node_::EvRef, crate::lower::node_::Wx) {
    match (index(args, &Nat::from(0u32)), index(args, &Nat::from(1u32))) {
        (Some(a), Some(b)) => {
            let (ra, w1) = event_ref(wx, menv, &a.value);
            let (rb, w2) = event_ref(&w1, menv, &b.value);
            let lt = crate::lower::types::out_ty_of(&wx.lx, &crate::lower::types::peel(&crate::lower::type_at(&wx.lx, &a.value.span)));
            let rt = crate::lower::types::out_ty_of(&wx.lx, &crate::lower::types::peel(&crate::lower::type_at(&wx.lx, &b.value.span)));
            let (nm, w3) = crate::lower::node_::fresh_name(&w2, &crate::lower::node_::kind_word(kind));
            let (id, w4) = combinator(&w3, &nm, t, kind, &ra, &rb, &lt, &rt);
            (crate::lower::node_::ev_ref_of(&w4, &id), w4.clone())
        },
        _ => never_event(wx, t),
    }
}

/// ```prism
/// MergeAllEvent: unbounded fn Wx, Env, [Arg], OutTy -> ((EvRef, Wx))
/// ```
pub fn merge_all_event(wx: &crate::lower::node_::Wx, menv: &crate::lower::types::Env, args: &Array<crate::syntax::Arg>, t: &crate::lower::model::OutTy) -> (crate::lower::node_::EvRef, crate::lower::node_::Wx) {
    match index(args, &Nat::from(0u32)) {
        Some(a) => match &*a.value.kind {
            crate::syntax::ExprKind::EArray(es) => {
                let et = match t {
                    crate::lower::model::OutTy::OutArray(x) => (**x).clone(),
                    _ => crate::lower::model::OutTy::OutUnit,
                };
                let (nm, w1) = crate::lower::node_::fresh_name(wx, &Text::lit("merged"));
                let (id, w2) = crate::lower::node_::add_gn(&w1, &nm, t, &crate::lower::node_::GnKind::GnMergeAll, &Nat::from(1u32));
                let ins = each(&crate::check::errors::range0(&len(es)), &(|i: &Nat| Text::from(format!("{}_{}", &nm, i))));
                let w3 = fold(&ins, &w2, &(|w: &crate::lower::node_::Wx, f: &Text| crate::lower::node_::add_field_last(w, f, &crate::lower::model::OutTy::OutStamped(Rc::new(et.clone())), &Text::lit("an input of `!MergeAll`"), &crate::lower::model::Ex::XCall(Text::lit("Stamped::new"), Array::new()))));
                let w4 = {
                    let mut this: crate::lower::node_::Wx = w3.clone();
                    this.gns = each(&this.gns, &(|n: &crate::lower::node_::Gn| if &n.id == &id { with_inputs(n, &ins) } else { n.clone() }));
                    this
                };
                let w5 = run_to_end(fold_job(crate::check::errors::range0(&len(es)), w4.clone(), {
                    let menv = menv.clone();
                    let es = es.clone();
                    let a = a.clone();
                    let id = id.clone();
                    Rc::new(move |(p0, p1): (crate::lower::node_::Wx, Nat)| {
                        let menv = menv.clone();
                        let es = es.clone();
                        let a = a.clone();
                        let id = id.clone();
                        entered(once_job(move || {
                            let w = p0;
                            let i = p1;
                            call_then(start_event_ref(w.clone(), menv.clone(), or(&index(&es, &i), &a.value)), move |event_ref_6930: (crate::lower::node_::EvRef, crate::lower::node_::Wx)| {
                                let (r, w6) = event_ref_6930;
                                prism_rtl::Turn::Finished(crate::lower::node_::connect(&w6, &r, &crate::lower::node_::Sk::SkIn(id.clone(), i.clone())))
                            })
                        }))
                    }) as Rc<dyn Fn((crate::lower::node_::Wx, Nat)) -> Rc<dyn prism_rtl::Job<crate::lower::node_::Wx>>>
                }));
                (crate::lower::node_::ev_ref_of(&w5, &id), w5.clone())
            },
            _ => {
                let (r, w1) = never_event(wx, t);
                let w2 = {
                    let mut this: crate::lower::node_::Wx = w1.clone();
                    this.build = push(&this.build, &crate::lower::expr::refusal_do(&Text::lit("`!MergeAll` of a list that is not a literal")));
                    this
                };
                (r.clone(), w2.clone())
            },
        },
        None => never_event(wx, t),
    }
}

/// ```prism
/// UpdatedEvent: unbounded fn Wx, Env, [Arg], OutTy -> ((EvRef, Wx))
/// ```
pub fn updated_event(wx: &crate::lower::node_::Wx, menv: &crate::lower::types::Env, args: &Array<crate::syntax::Arg>, t: &crate::lower::model::OutTy) -> (crate::lower::node_::EvRef, crate::lower::node_::Wx) {
    match index(args, &Nat::from(0u32)) {
        Some(a) => {
            let (ex, reads) = dynamic_expr(wx, menv, &a.value);
            let (nm, w1) = crate::lower::node_::fresh_name(wx, &Text::lit("updated"));
            let (id, w2) = crate::lower::node_::add_gn(&w1, &nm, t, &crate::lower::node_::GnKind::GnUpdated, &Nat::from(1u32));
            let w3 = crate::lower::node_::add_field_last(&w2, &Text::from(format!("{}_moved", &nm)), &crate::lower::model::OutTy::OutNamed(Text::lit("Cell"), Array::from(vec![crate::lower::model::OutTy::OutBool])), &Text::from(format!("a hold `!{}`\'s dynamic reads was written this tick", &nm)), &crate::lower::model::Ex::XCall(Text::lit("Cell::new"), Array::from(vec![crate::lower::model::Ex::XBool(false)])));
            let w4 = {
                let mut this: crate::lower::node_::Wx = w3.clone();
                this.gns = each(&this.gns, &(|n: &crate::lower::node_::Gn| if &n.id == &id { with_reads(n, &reads) } else { n.clone() }));
                this.getters = push(&this.getters, &crate::lower::model::MethDef { name: Text::from(format!("{}_value", &nm)), recv: crate::lower::model::Recv::RecvRef, params: Array::new(), cx_: crate::lower::model::CxArg::CxRef, ret: t.clone(), body: Array::new(), tail: ex.clone(), doc: Text::from(format!("The dynamic `!{}` is the event half of, which the wake reads after the tick.", &nm)) });
                this
            };
            (crate::lower::node_::ev_ref_of(&w4, &id), w4.clone())
        },
        None => never_event(wx, t),
    }
}

/// ```prism
/// FilterEvent: unbounded fn Wx, Env, [Arg], Bool -> ((EvRef, Wx))
/// ```
pub fn filter_event(wx: &crate::lower::node_::Wx, menv: &crate::lower::types::Env, args: &Array<crate::syntax::Arg>, is_unit: &bool) -> (crate::lower::node_::EvRef, crate::lower::node_::Wx) {
    match index(args, &Nat::from(0u32)) {
        None => never_event(wx, &crate::lower::model::OutTy::OutUnit),
        Some(a) => {
            let (r, w1) = event_ref(wx, menv, &a.value);
            let bound = if *is_unit {
                crate::lower::model::Pa::PaWild
            } else {
                crate::lower::model::Pa::PaBind(Text::lit("w"))
            };
            let pipe = {
                let r = r.clone();
                let bound = bound.clone();
                let is_unit = *is_unit;
                Rc::new(move |(p0, p1): (crate::lower::model::Ex, Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>)| {
                    let r = r.clone();
                    let bound = bound.clone();
                    let is_unit = is_unit;
                    entered(once_job(move || {
                        let x = p0;
                        let k_fn = p1;
                        (&r.pipe)((x.clone(), {
                            let bound = bound.clone();
                            let k_fn = k_fn.clone();
                            let is_unit = is_unit;
                            Rc::new(move |p0: crate::lower::model::Ex| {
                                let bound = bound.clone();
                                let k_fn = k_fn.clone();
                                let is_unit = is_unit;
                                entered(once_job(move || {
                                    let y = p0;
                                    call_value((&k_fn)(if is_unit {
                                        crate::lower::model::Ex::XUnit
                                    } else {
                                        crate::lower::model::Ex::XVar(Text::lit("w"))
                                    }), move |k_9292: Array<crate::lower::model::Do>| prism_rtl::Turn::Finished(Array::from(vec![crate::lower::model::Do::DoIfLet(crate::lower::model::Pa::PaCtor(Text::lit("Some"), Array::from(vec![bound.clone()])), y.clone(), k_9292, Array::new())])))
                                }))
                            }) as Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>
                        })).cycle()
                    }))
                }) as Rc<dyn Fn((crate::lower::model::Ex, Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>)) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>
            };
            (crate::lower::node_::EvRef { node_: r.node_.clone(), owner: r.owner.clone(), pipe: pipe.clone() }, w1.clone())
        },
    }
}

/// ```prism
/// GateEvent: unbounded fn Wx, Env, [Arg] -> ((EvRef, Wx))
/// ```
pub fn gate_event(wx: &crate::lower::node_::Wx, menv: &crate::lower::types::Env, args: &Array<crate::syntax::Arg>) -> (crate::lower::node_::EvRef, crate::lower::node_::Wx) {
    match index(args, &Nat::from(1u32)) {
        None => never_event(wx, &crate::lower::model::OutTy::OutUnit),
        Some(a) => {
            let (r, w1) = event_ref(wx, menv, &a.value);
            let cond = match index(args, &Nat::from(0u32)) {
                Some(b) => crate::lower::types::as_bool(&crate::lower::expr::value_of(&wx.lx, menv, &b.value)),
                None => crate::lower::model::Ex::XBool(false),
            };
            let pipe = {
                let r = r.clone();
                let cond = cond.clone();
                Rc::new(move |(p0, p1): (crate::lower::model::Ex, Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>)| {
                    let r = r.clone();
                    let cond = cond.clone();
                    entered(once_job(move || {
                        let x = p0;
                        let k_fn = p1;
                        (&r.pipe)((x.clone(), {
                            let cond = cond.clone();
                            let k_fn = k_fn.clone();
                            Rc::new(move |p0: crate::lower::model::Ex| {
                                let cond = cond.clone();
                                let k_fn = k_fn.clone();
                                entered(once_job(move || {
                                    let y = p0;
                                    call_value((&k_fn)(y.clone()), move |k_9825: Array<crate::lower::model::Do>| prism_rtl::Turn::Finished(Array::from(vec![crate::lower::model::Do::DoIf(cond.clone(), k_9825, Array::new())])))
                                }))
                            }) as Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>
                        })).cycle()
                    }))
                }) as Rc<dyn Fn((crate::lower::model::Ex, Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>)) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>
            };
            (crate::lower::node_::EvRef { node_: r.node_.clone(), owner: r.owner.clone(), pipe: pipe.clone() }, w1.clone())
        },
    }
}

/// ```prism
/// EventMap: unbounded fn Wx, Env, Expr -> ((EvRef, Wx))
/// ```
pub fn event_map(wx: &crate::lower::node_::Wx, menv: &crate::lower::types::Env, e: &crate::syntax::Expr) -> (crate::lower::node_::EvRef, crate::lower::node_::Wx) {
    let lx = wx.lx.clone();
    let t = crate::lower::types::out_ty_of(&lx, &crate::lower::types::peel(&crate::lower::type_at(&lx, &e.span)));
    let evs = filter(&operands(e), &(|x: &crate::syntax::Expr| &crate::lower::types::layer_of(&crate::lower::type_at(&lx, &x.span)) == &crate::lower::types::Layer::LyEv));
    'm10307: {
        if let m10307_0 = &evs && (m10307_0.len() == 1) && let Some(one) = index(m10307_0, &Nat::from(0u32)) {
            break 'm10307 {
                let (r, w1) = event_ref(wx, menv, &one);
                let et = crate::lower::types::out_ty_of(&lx, &crate::lower::types::peel(&crate::lower::type_at(&lx, &one.span)));
                let k = crate::lower::place_key(&lx, &one.span);
                let pipe = {
                    let r = r.clone();
                    let lx = lx.clone();
                    let menv = menv.clone();
                    let k = k.clone();
                    let et = et.clone();
                    let e = e.clone();
                    Rc::new(move |(p0, p1): (crate::lower::model::Ex, Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>)| {
                        let r = r.clone();
                        let lx = lx.clone();
                        let menv = menv.clone();
                        let k = k.clone();
                        let et = et.clone();
                        let e = e.clone();
                        entered(once_job(move || {
                            let x = p0;
                            let k_fn = p1;
                            (&r.pipe)((x.clone(), {
                                let k_fn = k_fn.clone();
                                let lx = lx.clone();
                                let menv = menv.clone();
                                let k = k.clone();
                                let et = et.clone();
                                let e = e.clone();
                                Rc::new(move |p0: crate::lower::model::Ex| {
                                    let k_fn = k_fn.clone();
                                    let lx = lx.clone();
                                    let menv = menv.clone();
                                    let k = k.clone();
                                    let et = et.clone();
                                    let e = e.clone();
                                    entered(once_job(move || {
                                        let y = p0;
                                        call_then(crate::lower::expr::start_value_of(lx.clone(), crate::lower::types::bind_span(&menv, &k, &firing_value(&y, &et)), e.clone()), move |value_of_10544: crate::lower::types::Vl| (&k_fn)(crate::lower::types::own(&value_of_10544)).cycle())
                                    }))
                                }) as Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>
                            })).cycle()
                        }))
                    }) as Rc<dyn Fn((crate::lower::model::Ex, Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>)) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>
                };
                (crate::lower::node_::EvRef { node_: r.node_.clone(), owner: r.owner.clone(), pipe: pipe.clone() }, w1.clone())
            };
        }
        never_event(wx, &t)
    }
}

/// ```prism
/// FiringValue: fn Ex, OutTy -> Vl
/// ```
pub fn firing_value(ex0: &crate::lower::model::Ex, t: &crate::lower::model::OutTy) -> crate::lower::types::Vl {
    match ex0 {
        crate::lower::model::Ex::XVar(n) => crate::lower::types::Vl::VlPlace(crate::lower::model::Ex::XVar(n.clone()), crate::lower::types::Holding::Owned, t.clone()),
        crate::lower::model::Ex::XUnit => crate::lower::types::Vl::VlPlace(crate::lower::model::Ex::XUnit, crate::lower::types::Holding::Owned, t.clone()),
        x => crate::lower::types::Vl::VlOwned(x.clone(), t.clone()),
    }
}

/// ```prism
/// Operands: fn Expr -> [Expr]
/// ```
pub fn operands(e: &crate::syntax::Expr) -> Array<crate::syntax::Expr> {
    match &*e.kind {
        crate::syntax::ExprKind::ECall(c, args, _, _) => append(&Array::from(vec![(**c).clone()]), &each(args, &(|a: &crate::syntax::Arg| a.value.clone()))),
        crate::syntax::ExprKind::EMethod(r, _, args) => append(&Array::from(vec![(**r).clone()]), &each(args, &(|a: &crate::syntax::Arg| a.value.clone()))),
        crate::syntax::ExprKind::EBinary(_, l, r) => Array::from(vec![(**l).clone(), (**r).clone()]),
        crate::syntax::ExprKind::EUnary(_, x) => Array::from(vec![(**x).clone()]),
        crate::syntax::ExprKind::EFreeSigil(_, x) => Array::from(vec![(**x).clone()]),
        crate::syntax::ExprKind::EGroup(x) => Array::from(vec![(**x).clone()]),
        crate::syntax::ExprKind::EField(r, _, _) => Array::from(vec![(**r).clone()]),
        crate::syntax::ExprKind::EIndex(r, i) => Array::from(vec![(**r).clone(), (**i).clone()]),
        crate::syntax::ExprKind::ETuple(es) => es.clone(),
        crate::syntax::ExprKind::EArray(es) => es.clone(),
        crate::syntax::ExprKind::EMap(kvs) => fold(kvs, &Array::new(), &(|acc: &Array<crate::syntax::Expr>, (k, v_): &(crate::syntax::Expr, crate::syntax::Expr)| append(acc, &Array::from(vec![k.clone(), v_.clone()])))),
        crate::syntax::ExprKind::ELit(l) => match &l.kind {
            crate::syntax::LitKind::LText(segs) => fold(segs, &Array::new(), &(|acc: &Array<crate::syntax::Expr>, sg: &crate::syntax::TextSeg| match sg {
                crate::syntax::TextSeg::SegPlaceholder(x) => push(acc, x),
                _ => acc.clone(),
            })),
            _ => Array::new(),
        },
        _ => Array::new(),
    }
}

/// ```prism
/// Merge: fn Wx, Text, OutTy, EvRef, EvRef -> ((Nat, Wx))
/// ```
pub fn merge(wx: &crate::lower::node_::Wx, name: &Text, t: &crate::lower::model::OutTy, l: &crate::lower::node_::EvRef, r: &crate::lower::node_::EvRef) -> (Nat, crate::lower::node_::Wx) {
    combinator(wx, name, t, &crate::lower::node_::GnKind::GnMerge, l, r, t, t)
}

/// ```prism
/// Combinator: fn Wx, Text, OutTy, GnKind, EvRef, EvRef, OutTy, OutTy -> ((Nat, Wx))
/// ```
pub fn combinator(wx: &crate::lower::node_::Wx, name: &Text, t: &crate::lower::model::OutTy, kind: &crate::lower::node_::GnKind, l: &crate::lower::node_::EvRef, r: &crate::lower::node_::EvRef, lt: &crate::lower::model::OutTy, rt: &crate::lower::model::OutTy) -> (Nat, crate::lower::node_::Wx) {
    let (id, wx1) = crate::lower::node_::add_gn(wx, name, t, kind, &Nat::from(1u32));
    let wx2 = crate::lower::node_::add_field_last(&wx1, &Text::from(format!("{}_left", name)), &crate::lower::model::OutTy::OutStamped(Rc::new(lt.clone())), &Text::from(format!("`{}`\'s left input", name)), &crate::lower::model::Ex::XCall(Text::lit("Stamped::new"), Array::new()));
    let wx3 = crate::lower::node_::add_field_last(&wx2, &Text::from(format!("{}_right", name)), &crate::lower::model::OutTy::OutStamped(Rc::new(rt.clone())), &Text::lit("its right input"), &crate::lower::model::Ex::XCall(Text::lit("Stamped::new"), Array::new()));
    let wx4 = {
        let mut this: crate::lower::node_::Wx = wx3.clone();
        this.gns = each(&this.gns, &(|n: &crate::lower::node_::Gn| if &n.id == &id {
            with_inputs(n, &Array::from(vec![Text::from(format!("{}_left", name)), Text::from(format!("{}_right", name))]))
        } else {
            n.clone()
        }));
        this
    };
    (id.clone(), crate::lower::node_::connect(&crate::lower::node_::connect(&wx4, l, &crate::lower::node_::Sk::SkIn(id.clone(), Nat::from(0u32))), r, &crate::lower::node_::Sk::SkIn(id.clone(), Nat::from(1u32))))
}

/// ```prism
/// WithInputs: fn Gn, [Text] -> Gn
/// ```
pub fn with_inputs(n: &crate::lower::node_::Gn, ins: &Array<Text>) -> crate::lower::node_::Gn {
    let mut this: crate::lower::node_::Gn = n.clone();
    this.inputs = ins.clone();
    this
}

/// ```prism
/// WithReads: fn Gn, [Read] -> Gn
/// ```
pub fn with_reads(n: &crate::lower::node_::Gn, reads: &Array<crate::lower::node_::Read>) -> crate::lower::node_::Gn {
    let mut this: crate::lower::node_::Gn = n.clone();
    this.reads = reads.clone();
    this
}
