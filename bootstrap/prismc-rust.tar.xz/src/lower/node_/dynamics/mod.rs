//! The module `Lower.Node.Dynamics`, from `target/bootstrap/src/prismc/lower/node/dynamics.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// ```prism
/// DynamicExpr: unbounded fn Wx, Env, Expr -> ((Ex, [Read]))
/// ```
pub fn dynamic_expr_f(wx_p0: &crate::lower::node_::Wx, menv_p1: &crate::lower::types::Env, e_p2: &crate::syntax::Expr) -> (crate::lower::model::Ex, Array<crate::lower::node_::Read>) {
    let v_p3 = crate::lower::expr::value_of_f(&wx_p0.lx_p, menv_p1, e_p2);
    let reads_p4 = crate::prelude::fold(&crate::check::typed::print::exprs_in_f(e_p2), &Array::new(), &(|acc_p5: &Array<crate::lower::node_::Read>, x_p6: &crate::syntax::Expr| match &*x_p6.kind_p {
        crate::syntax::ExprKind::EName(n_p7) => match crate::prelude::get(&menv_p1.names_p, &crate::check::env::sname_key_f(n_p7)) {
            Some(crate::lower::types::Bn::BnHold(f_p8, _)) => crate::lower::node_::add_read_f(acc_p5, &crate::lower::node_::Read::OwnRead(f_p8)),
            Some(crate::lower::types::Bn::BnDyn(_, rs_p9, _)) => crate::lower::node_::union_reads_f(acc_p5, &rs_p9),
            _ => acc_p5.clone(),
        },
        _ => acc_p5.clone(),
    }));
    (crate::lower::types::own_f(&v_p3), reads_p4.clone())
}

/// The step machine of `DynamicExpr`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// DynamicExpr: unbounded fn Wx, Env, Expr -> ((Ex, [Read]))
/// ```
pub struct DynamicExpr {
    pub wx_p0: crate::lower::node_::Wx,
    pub menv_p1: crate::lower::types::Env,
    pub e_p2: crate::syntax::Expr,
}

impl prism_rtl::Job<(crate::lower::model::Ex, Array<crate::lower::node_::Read>)> for DynamicExpr {
    fn cycle(&self) -> prism_rtl::Turn<(crate::lower::model::Ex, Array<crate::lower::node_::Read>)> {
        let wx_p0 = &self.wx_p0;
        let menv_p1 = &self.menv_p1;
        let e_p2 = &self.e_p2;
        let e_p2x = e_p2.clone();
        let menv_p1x = menv_p1.clone();
        let wx_p0x = wx_p0.clone();
        crate::prelude::call_then(crate::lower::expr::start_value_of_f(wx_p0x.lx_p.clone(), menv_p1x.clone(), e_p2x.clone()), move |value_of_f_1581: crate::lower::types::Vl| {
            let v_p3 = value_of_f_1581;
            crate::prelude::call_then(crate::check::typed::print::start_exprs_in_f(e_p2x.clone()), move |exprs_in_f_1626: Array<crate::syntax::Expr>| {
                let reads_p4 = crate::prelude::fold(&exprs_in_f_1626, &Array::new(), &(|acc_p5: &Array<crate::lower::node_::Read>, x_p6: &crate::syntax::Expr| match &*x_p6.kind_p {
                    crate::syntax::ExprKind::EName(n_p7) => match crate::prelude::get(&menv_p1x.names_p, &crate::check::env::sname_key_f(n_p7)) {
                        Some(crate::lower::types::Bn::BnHold(f_p8, _)) => crate::lower::node_::add_read_f(acc_p5, &crate::lower::node_::Read::OwnRead(f_p8)),
                        Some(crate::lower::types::Bn::BnDyn(_, rs_p9, _)) => crate::lower::node_::union_reads_f(acc_p5, &rs_p9),
                        _ => acc_p5.clone(),
                    },
                    _ => acc_p5.clone(),
                }));
                prism_rtl::Turn::Finished((crate::lower::types::own_f(&v_p3), reads_p4.clone()))
            })
        })
    }
}

/// `Start DynamicExpr, x`: what the function value is when passed to `@Run`.
pub fn start_dynamic_expr_f(wx_p0: crate::lower::node_::Wx, menv_p1: crate::lower::types::Env, e_p2: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<(crate::lower::model::Ex, Array<crate::lower::node_::Read>)>> {
    Rc::new(DynamicExpr { wx_p0, menv_p1, e_p2 })
}

/// ```prism
/// NeverEvent: fn Wx, OutTy -> ((EvRef, Wx))
/// ```
pub fn never_event_f(wx_p0: &crate::lower::node_::Wx, t_p1: &crate::lower::model::OutTy) -> (crate::lower::node_::EvRef, crate::lower::node_::Wx) {
    let (id_p2, wx2_p3) = crate::lower::node_::add_gn_f(wx_p0, &Text::lit("never"), t_p1, &crate::lower::node_::GnKind::GnNever, &Nat::from(0u32));
    (crate::lower::node_::ev_ref_of_f(&wx2_p3, &id_p2), wx2_p3.clone())
}

/// ```prism
/// EventRef: unbounded fn Wx, Env, Expr -> ((EvRef, Wx))
/// ```
pub fn event_ref_f(wx_p0: &crate::lower::node_::Wx, menv_p1: &crate::lower::types::Env, e_p2: &crate::syntax::Expr) -> (crate::lower::node_::EvRef, crate::lower::node_::Wx) {
    let lx_p3 = wx_p0.lx_p.clone();
    let t_p4 = crate::lower::types::out_ty_of_f(&lx_p3, &crate::lower::types::peel_f(&crate::lower::type_at_f(&lx_p3, &e_p2.span_p)));
    'm2490: {
        let scrutinee = &*e_p2.kind_p;
        if let crate::syntax::ExprKind::EGroup(x_p5) = scrutinee {
            break 'm2490 event_ref_f(wx_p0, menv_p1, &**x_p5);
        }
        if let crate::syntax::ExprKind::EName(n_p6) = scrutinee {
            break 'm2490 match crate::prelude::get(&menv_p1.names_p, &crate::check::env::sname_key_f(n_p6)) {
                Some(crate::lower::types::Bn::BnEv(r_p7, _)) => if &r_p7.owner_p == &wx_p0.node_p {
                    (r_p7.clone(), wx_p0.clone())
                } else {
                    never_event_f(&crate::lower::node_::crossed_f(wx_p0, &Text::from(format!("the event `{}`, of node `{}`,", &crate::check::env::sname_key_f(n_p6), &r_p7.owner_p))), &t_p4)
                },
                _ => never_event_f(wx_p0, &t_p4),
            };
        }
        if let crate::syntax::ExprKind::EBinary(m2490_2_0, l_p8, r_p9) = scrutinee && (m2490_2_0 == &Text::lit("<|")) {
            break 'm2490 {
                let (lr_pa, w1_pb) = event_ref_f(wx_p0, menv_p1, &**l_p8);
                let (rr_pc, w2_pd) = event_ref_f(&w1_pb, menv_p1, &**r_p9);
                let (nm_pe, w3_pf) = crate::lower::node_::fresh_name_f(&w2_pd, &Text::lit("anon"));
                let (id_pg, w4_ph) = merge_f(&w3_pf, &nm_pe, &t_p4, &lr_pa, &rr_pc);
                (crate::lower::node_::ev_ref_of_f(&w4_ph, &id_pg), w4_ph.clone())
            };
        }
        if let crate::syntax::ExprKind::EBinary(m2490_3_0, l_pi, r_pj) = scrutinee && (m2490_3_0 == &Text::lit("on")) {
            break 'm2490 {
                let (rr_pl, w1_pm) = event_ref_f(wx_p0, menv_p1, &**r_pj);
                let value_pk = crate::lower::types::own_f(&crate::lower::expr::value_of_f(&lx_p3, menv_p1, &**l_pi));
                (crate::lower::node_::EvRef { node_p: rr_pl.node_p.clone(), owner_p: rr_pl.owner_p.clone(), pipe_f: {
                    let rr_plx = rr_pl.clone();
                    let value_pkx = value_pk.clone();
                    Rc::new(move |(p0, p1): (crate::lower::model::Ex, Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>)| {
                        let rr_plxy = rr_plx.clone();
                        let value_pkxy = value_pkx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let x_pn = p0;
                            let k_fo = p1;
                            (&rr_plxy.pipe_f)((x_pn.clone(), {
                                let k_fox = k_fo.clone();
                                let value_pkxyx = value_pkxy.clone();
                                Rc::new(move |p0: crate::lower::model::Ex| {
                                    let k_foxy = k_fox.clone();
                                    let value_pkxyxy = value_pkxyx.clone();
                                    crate::prelude::entered(crate::prelude::once_job(move || {
                                        let _ = p0;
                                        (&k_foxy)(value_pkxyxy.clone()).cycle()
                                    }))
                                }) as Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>
                            })).cycle()
                        }))
                    }) as Rc<dyn Fn((crate::lower::model::Ex, Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>)) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>
                } }, w1_pm.clone())
            };
        }
        if let crate::syntax::ExprKind::ECall(c_pp, args_pq, _, _) = scrutinee {
            break 'm2490 match callee_key_f(&lx_p3, &**c_pp) {
                m3346_0 if (&m3346_0 == &Text::lit("Prelude.!Filter")) => filter_event_f(wx_p0, menv_p1, args_pq, &false),
                m3346_1 if (&m3346_1 == &Text::lit("Prelude.!Present")) => filter_event_f(wx_p0, menv_p1, args_pq, &true),
                m3346_2 if (&m3346_2 == &Text::lit("Prelude.!Gate")) => gate_event_f(wx_p0, menv_p1, args_pq),
                m3346_3 if (&m3346_3 == &Text::lit("Prelude.!Union")) => pair_event_f(wx_p0, menv_p1, args_pq, &crate::lower::node_::GnKind::GnUnion, &t_p4),
                m3346_4 if (&m3346_4 == &Text::lit("Prelude.!Both")) => pair_event_f(wx_p0, menv_p1, args_pq, &crate::lower::node_::GnKind::GnBoth, &t_p4),
                m3346_5 if (&m3346_5 == &Text::lit("Prelude.!Except")) => pair_event_f(wx_p0, menv_p1, args_pq, &crate::lower::node_::GnKind::GnExcept, &t_p4),
                m3346_6 if (&m3346_6 == &Text::lit("Prelude.!MergeAll")) => merge_all_event_f(wx_p0, menv_p1, args_pq, &t_p4),
                m3346_7 if (&m3346_7 == &Text::lit("Prelude.!Updated")) => updated_event_f(wx_p0, menv_p1, args_pq, &t_p4),
                _ => event_map_f(wx_p0, menv_p1, e_p2),
                _ => unreachable!("no arm matched"),
            };
        }
        if let crate::syntax::ExprKind::EIf(m2490_5_0, then_b_ps, Some(else_b_pt)) = scrutinee && let crate::syntax::Cond::CondExpr(c_pr) = &**m2490_5_0 {
            break 'm2490 match (block_expr_o(then_b_ps), block_expr_o(else_b_pt)) {
                (Some(a_pu), Some(b_pv)) => event_if_f(wx_p0, menv_p1, &**c_pr, &a_pu, &b_pv, &t_p4),
                _ => event_map_f(wx_p0, menv_p1, e_p2),
            };
        }
        event_map_f(wx_p0, menv_p1, e_p2)
    }
}

/// The step machine of `EventRef`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// EventRef: unbounded fn Wx, Env, Expr -> ((EvRef, Wx))
/// ```
pub struct EventRef {
    pub wx_p0: crate::lower::node_::Wx,
    pub menv_p1: crate::lower::types::Env,
    pub e_p2: crate::syntax::Expr,
}

impl prism_rtl::Job<(crate::lower::node_::EvRef, crate::lower::node_::Wx)> for EventRef {
    fn cycle(&self) -> prism_rtl::Turn<(crate::lower::node_::EvRef, crate::lower::node_::Wx)> {
        let wx_p0 = &self.wx_p0;
        let menv_p1 = &self.menv_p1;
        let e_p2 = &self.e_p2;
        let lx_p3 = wx_p0.lx_p.clone();
        let e_p2x = e_p2.clone();
        let menv_p1x = menv_p1.clone();
        let wx_p0x = wx_p0.clone();
        crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p3.clone(), crate::lower::types::peel_f(&crate::lower::type_at_f(&lx_p3, &e_p2x.span_p))), move |out_ty_of_f_2447: crate::lower::model::OutTy| {
            let t_p4 = out_ty_of_f_2447;
            'm2490: {
                let scrutinee = &*e_p2x.kind_p;
                if let crate::syntax::ExprKind::EGroup(x_p5) = scrutinee {
                    break 'm2490 prism_rtl::Turn::More(Rc::new(EventRef { wx_p0: wx_p0x.clone(), menv_p1: menv_p1x.clone(), e_p2: (**x_p5).clone() }));
                }
                if let crate::syntax::ExprKind::EName(n_p6) = scrutinee {
                    break 'm2490 match crate::prelude::get(&menv_p1x.names_p, &crate::check::env::sname_key_f(n_p6)) {
                        Some(crate::lower::types::Bn::BnEv(r_p7, _)) => if &r_p7.owner_p == &wx_p0x.node_p {
                            prism_rtl::Turn::Finished((r_p7.clone(), wx_p0x.clone()))
                        } else {
                            prism_rtl::Turn::Finished(never_event_f(&crate::lower::node_::crossed_f(&wx_p0x, &Text::from(format!("the event `{}`, of node `{}`,", &crate::check::env::sname_key_f(n_p6), &r_p7.owner_p))), &t_p4))
                        },
                        _ => prism_rtl::Turn::Finished(never_event_f(&wx_p0x, &t_p4)),
                    };
                }
                if let crate::syntax::ExprKind::EBinary(m2490_2_0, l_p8, r_p9) = scrutinee && (m2490_2_0 == &Text::lit("<|")) {
                    break 'm2490 {
                        let l_p8x = (**l_p8).clone();
                        let r_p9x = (**r_p9).clone();
                        crate::prelude::call_then(start_event_ref_f(wx_p0x.clone(), menv_p1x.clone(), l_p8x.clone()), move |event_ref_f_2867: (crate::lower::node_::EvRef, crate::lower::node_::Wx)| {
                            let (lr_pa, w1_pb) = event_ref_f_2867;
                            crate::prelude::call_then(start_event_ref_f(w1_pb.clone(), menv_p1x.clone(), r_p9x.clone()), move |event_ref_f_2917: (crate::lower::node_::EvRef, crate::lower::node_::Wx)| {
                                let (rr_pc, w2_pd) = event_ref_f_2917;
                                let (nm_pe, w3_pf) = crate::lower::node_::fresh_name_f(&w2_pd, &Text::lit("anon"));
                                let (id_pg, w4_ph) = merge_f(&w3_pf, &nm_pe, &t_p4, &lr_pa, &rr_pc);
                                prism_rtl::Turn::Finished((crate::lower::node_::ev_ref_of_f(&w4_ph, &id_pg), w4_ph.clone()))
                            })
                        })
                    };
                }
                if let crate::syntax::ExprKind::EBinary(m2490_3_0, l_pi, r_pj) = scrutinee && (m2490_3_0 == &Text::lit("on")) {
                    break 'm2490 {
                        let l_pix = (**l_pi).clone();
                        let r_pjx = (**r_pj).clone();
                        crate::prelude::call_then(start_event_ref_f(wx_p0x.clone(), menv_p1x.clone(), r_pjx.clone()), move |event_ref_f_3135: (crate::lower::node_::EvRef, crate::lower::node_::Wx)| {
                            let (rr_pl, w1_pm) = event_ref_f_3135;
                            crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p3.clone(), menv_p1x.clone(), l_pix.clone()), move |value_of_f_3185: crate::lower::types::Vl| {
                                let value_pk = crate::lower::types::own_f(&value_of_f_3185);
                                prism_rtl::Turn::Finished((crate::lower::node_::EvRef { node_p: rr_pl.node_p.clone(), owner_p: rr_pl.owner_p.clone(), pipe_f: {
                                    let rr_plx = rr_pl.clone();
                                    let value_pkx = value_pk.clone();
                                    Rc::new(move |(p0, p1): (crate::lower::model::Ex, Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>)| {
                                        let rr_plxy = rr_plx.clone();
                                        let value_pkxy = value_pkx.clone();
                                        crate::prelude::entered(crate::prelude::once_job(move || {
                                            let x_pn = p0;
                                            let k_fo = p1;
                                            (&rr_plxy.pipe_f)((x_pn.clone(), {
                                                let k_fox = k_fo.clone();
                                                let value_pkxyx = value_pkxy.clone();
                                                Rc::new(move |p0: crate::lower::model::Ex| {
                                                    let k_foxy = k_fox.clone();
                                                    let value_pkxyxy = value_pkxyx.clone();
                                                    crate::prelude::entered(crate::prelude::once_job(move || {
                                                        let _ = p0;
                                                        (&k_foxy)(value_pkxyxy.clone()).cycle()
                                                    }))
                                                }) as Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>
                                            })).cycle()
                                        }))
                                    }) as Rc<dyn Fn((crate::lower::model::Ex, Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>)) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>
                                } }, w1_pm.clone()))
                            })
                        })
                    };
                }
                if let crate::syntax::ExprKind::ECall(c_pp, args_pq, _, _) = scrutinee {
                    break 'm2490 match callee_key_f(&lx_p3, &**c_pp) {
                        m3346_0 if (&m3346_0 == &Text::lit("Prelude.!Filter")) => prism_rtl::Turn::Finished(filter_event_f(&wx_p0x, &menv_p1x, args_pq, &false)),
                        m3346_1 if (&m3346_1 == &Text::lit("Prelude.!Present")) => prism_rtl::Turn::Finished(filter_event_f(&wx_p0x, &menv_p1x, args_pq, &true)),
                        m3346_2 if (&m3346_2 == &Text::lit("Prelude.!Gate")) => prism_rtl::Turn::Finished(gate_event_f(&wx_p0x, &menv_p1x, args_pq)),
                        m3346_3 if (&m3346_3 == &Text::lit("Prelude.!Union")) => prism_rtl::Turn::Finished(pair_event_f(&wx_p0x, &menv_p1x, args_pq, &crate::lower::node_::GnKind::GnUnion, &t_p4)),
                        m3346_4 if (&m3346_4 == &Text::lit("Prelude.!Both")) => prism_rtl::Turn::Finished(pair_event_f(&wx_p0x, &menv_p1x, args_pq, &crate::lower::node_::GnKind::GnBoth, &t_p4)),
                        m3346_5 if (&m3346_5 == &Text::lit("Prelude.!Except")) => prism_rtl::Turn::Finished(pair_event_f(&wx_p0x, &menv_p1x, args_pq, &crate::lower::node_::GnKind::GnExcept, &t_p4)),
                        m3346_6 if (&m3346_6 == &Text::lit("Prelude.!MergeAll")) => prism_rtl::Turn::Finished(merge_all_event_f(&wx_p0x, &menv_p1x, args_pq, &t_p4)),
                        m3346_7 if (&m3346_7 == &Text::lit("Prelude.!Updated")) => prism_rtl::Turn::Finished(updated_event_f(&wx_p0x, &menv_p1x, args_pq, &t_p4)),
                        _ => prism_rtl::Turn::Finished(event_map_f(&wx_p0x, &menv_p1x, &e_p2x)),
                        _ => unreachable!("no arm matched"),
                    };
                }
                if let crate::syntax::ExprKind::EIf(m2490_5_0, then_b_ps, Some(else_b_pt)) = scrutinee && let crate::syntax::Cond::CondExpr(c_pr) = &**m2490_5_0 {
                    break 'm2490 match (block_expr_o(then_b_ps), block_expr_o(else_b_pt)) {
                        (Some(a_pu), Some(b_pv)) => prism_rtl::Turn::Finished(event_if_f(&wx_p0x, &menv_p1x, &**c_pr, &a_pu, &b_pv, &t_p4)),
                        _ => prism_rtl::Turn::Finished(event_map_f(&wx_p0x, &menv_p1x, &e_p2x)),
                    };
                }
                prism_rtl::Turn::Finished(event_map_f(&wx_p0x, &menv_p1x, &e_p2x))
            }
        })
    }
}

/// `Start EventRef, x`: what the function value is when passed to `@Run`.
pub fn start_event_ref_f(wx_p0: crate::lower::node_::Wx, menv_p1: crate::lower::types::Env, e_p2: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<(crate::lower::node_::EvRef, crate::lower::node_::Wx)>> {
    Rc::new(EventRef { wx_p0, menv_p1, e_p2 })
}

/// ```prism
/// EventIf: unbounded fn Wx, Env, Expr, Expr, Expr, OutTy -> ((EvRef, Wx))
/// ```
pub fn event_if_f(wx_p0: &crate::lower::node_::Wx, menv_p1: &crate::lower::types::Env, c_p2: &crate::syntax::Expr, a_p3: &crate::syntax::Expr, b_p4: &crate::syntax::Expr, t_p5: &crate::lower::model::OutTy) -> (crate::lower::node_::EvRef, crate::lower::node_::Wx) {
    let cond_p6 = crate::lower::types::as_bool_f(&crate::lower::expr::value_of_f(&wx_p0.lx_p, menv_p1, c_p2));
    let (ra_p9, w1_pa) = event_ref_f(wx_p0, menv_p1, a_p3);
    let (rb_pb, w2_pc) = event_ref_f(&w1_pa, menv_p1, b_p4);
    let ga_p7 = crate::lower::node_::EvRef { node_p: ra_p9.node_p.clone(), owner_p: ra_p9.owner_p.clone(), pipe_f: {
        let ra_p9x = ra_p9.clone();
        let cond_p6x = cond_p6.clone();
        Rc::new(move |(p0, p1): (crate::lower::model::Ex, Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>)| {
            let ra_p9xy = ra_p9x.clone();
            let cond_p6xy = cond_p6x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let x_pd = p0;
                let k_fe = p1;
                (&ra_p9xy.pipe_f)((x_pd.clone(), {
                    let cond_p6xyx = cond_p6xy.clone();
                    let k_fex = k_fe.clone();
                    Rc::new(move |p0: crate::lower::model::Ex| {
                        let cond_p6xyxy = cond_p6xyx.clone();
                        let k_fexy = k_fex.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let y_pf = p0;
                            crate::prelude::call_value((&k_fexy)(y_pf.clone()), move |k_4624: Array<crate::lower::model::Do>| prism_rtl::Turn::Finished(Array::from(vec![crate::lower::model::Do::DoIf(cond_p6xyxy.clone(), k_4624, Array::new())])))
                        }))
                    }) as Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>
                })).cycle()
            }))
        }) as Rc<dyn Fn((crate::lower::model::Ex, Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>)) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>
    } };
    let gb_p8 = crate::lower::node_::EvRef { node_p: rb_pb.node_p.clone(), owner_p: rb_pb.owner_p.clone(), pipe_f: {
        let rb_pbx = rb_pb.clone();
        let cond_p6x = cond_p6.clone();
        Rc::new(move |(p0, p1): (crate::lower::model::Ex, Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>)| {
            let rb_pbxy = rb_pbx.clone();
            let cond_p6xy = cond_p6x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let x_pg = p0;
                let k_fh = p1;
                (&rb_pbxy.pipe_f)((x_pg.clone(), {
                    let cond_p6xyx = cond_p6xy.clone();
                    let k_fhx = k_fh.clone();
                    Rc::new(move |p0: crate::lower::model::Ex| {
                        let cond_p6xyxy = cond_p6xyx.clone();
                        let k_fhxy = k_fhx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let y_pi = p0;
                            crate::prelude::call_value((&k_fhxy)(y_pi.clone()), move |k_4762: Array<crate::lower::model::Do>| prism_rtl::Turn::Finished(Array::from(vec![crate::lower::model::Do::DoIf(crate::lower::model::Ex::XBin(crate::lower::model::BinOp::OpEq, Rc::new(cond_p6xyxy.clone()), Rc::new(crate::lower::model::Ex::XBool(false))), k_4762, Array::new())])))
                        }))
                    }) as Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>
                })).cycle()
            }))
        }) as Rc<dyn Fn((crate::lower::model::Ex, Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>)) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>
    } };
    let (nm_pj, w3_pk) = crate::lower::node_::fresh_name_f(&w2_pc, &Text::lit("chosen"));
    let (id_pl, w4_pm) = merge_f(&w3_pk, &nm_pj, t_p5, &ga_p7, &gb_p8);
    (crate::lower::node_::ev_ref_of_f(&w4_pm, &id_pl), w4_pm.clone())
}

/// ```prism
/// ?BlockExpr: fn Block -> ?Expr
/// ```
pub fn block_expr_o(b_p0: &crate::syntax::Block) -> Option<crate::syntax::Expr> {
    'm4996: {
        let scrutinee = &b_p0.stmts_p;
        if let m4996_0 = scrutinee && (m4996_0.len() == 1) && let Some(st_p1) = crate::prelude::index(m4996_0, &Nat::from(0u32)) {
            break 'm4996 match &st_p1.kind_p {
                crate::syntax::StmtKind::SExpr(x_p2) => Some(x_p2.clone()),
                _ => None,
            };
        }
        None
    }
}

/// ```prism
/// CalleeKey: fn Lx, Expr -> Text
/// ```
pub fn callee_key_f(lx_p0: &crate::lower::Lx, c_p1: &crate::syntax::Expr) -> Text {
    match &*c_p1.kind_p {
        crate::syntax::ExprKind::EName(n_p2) => {
            let (q_o3, _) = crate::check::env::names::resolve_value_f(&lx_p0.g_p, &lx_p0.home_p, n_p2);
            crate::prelude::or(&q_o3, &Text::lit(""))
        },
        _ => Text::lit(""),
    }
}

/// ```prism
/// PairEvent: unbounded fn Wx, Env, [Arg], GnKind, OutTy -> ((EvRef, Wx))
/// ```
pub fn pair_event_f(wx_p0: &crate::lower::node_::Wx, menv_p1: &crate::lower::types::Env, args_p2: &Array<crate::syntax::Arg>, kind_p3: &crate::lower::node_::GnKind, t_p4: &crate::lower::model::OutTy) -> (crate::lower::node_::EvRef, crate::lower::node_::Wx) {
    match (crate::prelude::index(args_p2, &Nat::from(0u32)), crate::prelude::index(args_p2, &Nat::from(1u32))) {
        (Some(a_p5), Some(b_p6)) => {
            let (ra_p9, w1_pa) = event_ref_f(wx_p0, menv_p1, &a_p5.value_p);
            let (rb_pb, w2_pc) = event_ref_f(&w1_pa, menv_p1, &b_p6.value_p);
            let lt_p7 = crate::lower::types::out_ty_of_f(&wx_p0.lx_p, &crate::lower::types::peel_f(&crate::lower::type_at_f(&wx_p0.lx_p, &a_p5.value_p.span_p)));
            let rt_p8 = crate::lower::types::out_ty_of_f(&wx_p0.lx_p, &crate::lower::types::peel_f(&crate::lower::type_at_f(&wx_p0.lx_p, &b_p6.value_p.span_p)));
            let (nm_pd, w3_pe) = crate::lower::node_::fresh_name_f(&w2_pc, &crate::lower::node_::kind_word_f(kind_p3));
            let (id_pf, w4_pg) = combinator_f(&w3_pe, &nm_pd, t_p4, kind_p3, &ra_p9, &rb_pb, &lt_p7, &rt_p8);
            (crate::lower::node_::ev_ref_of_f(&w4_pg, &id_pf), w4_pg.clone())
        },
        _ => never_event_f(wx_p0, t_p4),
    }
}

/// ```prism
/// MergeAllEvent: unbounded fn Wx, Env, [Arg], OutTy -> ((EvRef, Wx))
/// ```
pub fn merge_all_event_f(wx_p0: &crate::lower::node_::Wx, menv_p1: &crate::lower::types::Env, args_p2: &Array<crate::syntax::Arg>, t_p3: &crate::lower::model::OutTy) -> (crate::lower::node_::EvRef, crate::lower::node_::Wx) {
    match crate::prelude::index(args_p2, &Nat::from(0u32)) {
        Some(a_p4) => match &*a_p4.value_p.kind_p {
            crate::syntax::ExprKind::EArray(es_p5) => {
                let et_p6 = match t_p3 {
                    crate::lower::model::OutTy::OutArray(x_pb) => (**x_pb).clone(),
                    _ => crate::lower::model::OutTy::OutUnit,
                };
                let (nm_pc, w1_pd) = crate::lower::node_::fresh_name_f(wx_p0, &Text::lit("merged"));
                let (id_pe, w2_pf) = crate::lower::node_::add_gn_f(&w1_pd, &nm_pc, t_p3, &crate::lower::node_::GnKind::GnMergeAll, &Nat::from(1u32));
                let ins_p7 = crate::prelude::each(&crate::check::errors::range0_f(&crate::prelude::len(es_p5)), &(|i_pg: &Nat| Text::from(format!("{}_{}", &nm_pc, i_pg))));
                let w3_p8 = crate::prelude::fold(&ins_p7, &w2_pf, &(|w_ph: &crate::lower::node_::Wx, f_pi: &Text| crate::lower::node_::add_field_last_f(w_ph, f_pi, &crate::lower::model::OutTy::OutStamped(Rc::new(et_p6.clone())), &Text::lit("an input of `!MergeAll`"), &crate::lower::model::Ex::XCall(Text::lit("Stamped::new"), Array::new()))));
                let w4_p9 = {
                    let mut this: crate::lower::node_::Wx = w3_p8.clone();
                    this.gns_p = crate::prelude::each(&this.gns_p, &(|n_pj: &crate::lower::node_::Gn| if &n_pj.id_p == &id_pe { with_inputs_f(n_pj, &ins_p7) } else { n_pj.clone() }));
                    this
                };
                let w5_pa = crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(es_p5)), w4_p9.clone(), {
                    let menv_p1x = menv_p1.clone();
                    let es_p5x = es_p5.clone();
                    let a_p4x = a_p4.clone();
                    let id_pex = id_pe.clone();
                    Rc::new(move |(p0, p1): (crate::lower::node_::Wx, Nat)| {
                        let menv_p1xy = menv_p1x.clone();
                        let es_p5xy = es_p5x.clone();
                        let a_p4xy = a_p4x.clone();
                        let id_pexy = id_pex.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let w_pk = p0;
                            let i_pl = p1;
                            crate::prelude::call_then(start_event_ref_f(w_pk.clone(), menv_p1xy.clone(), crate::prelude::or(&crate::prelude::index(&es_p5xy, &i_pl), &a_p4xy.value_p)), move |event_ref_f_6930: (crate::lower::node_::EvRef, crate::lower::node_::Wx)| {
                                let (r_pm, w6_pn) = event_ref_f_6930;
                                prism_rtl::Turn::Finished(crate::lower::node_::connect_f(&w6_pn, &r_pm, &crate::lower::node_::Sk::SkIn(id_pexy.clone(), i_pl.clone())))
                            })
                        }))
                    }) as Rc<dyn Fn((crate::lower::node_::Wx, Nat)) -> Rc<dyn prism_rtl::Job<crate::lower::node_::Wx>>>
                }));
                (crate::lower::node_::ev_ref_of_f(&w5_pa, &id_pe), w5_pa.clone())
            },
            _ => {
                let (r_pp, w1_pq) = never_event_f(wx_p0, t_p3);
                let w2_po = {
                    let mut this: crate::lower::node_::Wx = w1_pq.clone();
                    this.build_p = crate::prelude::push(&this.build_p, &crate::lower::expr::refusal_do_f(&Text::lit("`!MergeAll` of a list that is not a literal")));
                    this
                };
                (r_pp.clone(), w2_po.clone())
            },
        },
        None => never_event_f(wx_p0, t_p3),
    }
}

/// ```prism
/// UpdatedEvent: unbounded fn Wx, Env, [Arg], OutTy -> ((EvRef, Wx))
/// ```
pub fn updated_event_f(wx_p0: &crate::lower::node_::Wx, menv_p1: &crate::lower::types::Env, args_p2: &Array<crate::syntax::Arg>, t_p3: &crate::lower::model::OutTy) -> (crate::lower::node_::EvRef, crate::lower::node_::Wx) {
    match crate::prelude::index(args_p2, &Nat::from(0u32)) {
        Some(a_p4) => {
            let (ex_p7, reads_p8) = dynamic_expr_f(wx_p0, menv_p1, &a_p4.value_p);
            let (nm_p9, w1_pa) = crate::lower::node_::fresh_name_f(wx_p0, &Text::lit("updated"));
            let (id_pb, w2_pc) = crate::lower::node_::add_gn_f(&w1_pa, &nm_p9, t_p3, &crate::lower::node_::GnKind::GnUpdated, &Nat::from(1u32));
            let w3_p5 = crate::lower::node_::add_field_last_f(&w2_pc, &Text::from(format!("{}_moved", &nm_p9)), &crate::lower::model::OutTy::OutNamed(Text::lit("Cell"), Array::from(vec![crate::lower::model::OutTy::OutBool])), &Text::from(format!("a hold `!{}`\'s dynamic reads was written this tick", &nm_p9)), &crate::lower::model::Ex::XCall(Text::lit("Cell::new"), Array::from(vec![crate::lower::model::Ex::XBool(false)])));
            let w4_p6 = {
                let mut this: crate::lower::node_::Wx = w3_p5.clone();
                this.gns_p = crate::prelude::each(&this.gns_p, &(|n_pd: &crate::lower::node_::Gn| if &n_pd.id_p == &id_pb { with_reads_f(n_pd, &reads_p8) } else { n_pd.clone() }));
                this.getters_p = crate::prelude::push(&this.getters_p, &crate::lower::model::MethDef { name_p: Text::from(format!("{}_value", &nm_p9)), recv_p: crate::lower::model::Recv::RecvRef, params_p: Array::new(), cx_p: crate::lower::model::CxArg::CxRef, ret_p: t_p3.clone(), body_p: Array::new(), tail_p: ex_p7.clone(), doc_p: Text::from(format!("The dynamic `!{}` is the event half of, which the wake reads after the tick.", &nm_p9)) });
                this
            };
            (crate::lower::node_::ev_ref_of_f(&w4_p6, &id_pb), w4_p6.clone())
        },
        None => never_event_f(wx_p0, t_p3),
    }
}

/// ```prism
/// FilterEvent: unbounded fn Wx, Env, [Arg], Bool -> ((EvRef, Wx))
/// ```
pub fn filter_event_f(wx_p0: &crate::lower::node_::Wx, menv_p1: &crate::lower::types::Env, args_p2: &Array<crate::syntax::Arg>, is_unit_p3: &bool) -> (crate::lower::node_::EvRef, crate::lower::node_::Wx) {
    match crate::prelude::index(args_p2, &Nat::from(0u32)) {
        None => never_event_f(wx_p0, &crate::lower::model::OutTy::OutUnit),
        Some(a_p4) => {
            let (r_p7, w1_p8) = event_ref_f(wx_p0, menv_p1, &a_p4.value_p);
            let bound_p5 = if *is_unit_p3 {
                crate::lower::model::Pa::PaWild
            } else {
                crate::lower::model::Pa::PaBind(Text::lit("w"))
            };
            let pipe_f6 = {
                let r_p7x = r_p7.clone();
                let bound_p5x = bound_p5.clone();
                let is_unit_p3x = *is_unit_p3;
                Rc::new(move |(p0, p1): (crate::lower::model::Ex, Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>)| {
                    let r_p7xy = r_p7x.clone();
                    let bound_p5xy = bound_p5x.clone();
                    let is_unit_p3xy = is_unit_p3x;
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let x_p9 = p0;
                        let k_fa = p1;
                        (&r_p7xy.pipe_f)((x_p9.clone(), {
                            let bound_p5xyx = bound_p5xy.clone();
                            let k_fax = k_fa.clone();
                            let is_unit_p3xyx = is_unit_p3xy;
                            Rc::new(move |p0: crate::lower::model::Ex| {
                                let bound_p5xyxy = bound_p5xyx.clone();
                                let k_faxy = k_fax.clone();
                                let is_unit_p3xyxy = is_unit_p3xyx;
                                crate::prelude::entered(crate::prelude::once_job(move || {
                                    let y_pb = p0;
                                    crate::prelude::call_value((&k_faxy)(if is_unit_p3xyxy {
                                        crate::lower::model::Ex::XUnit
                                    } else {
                                        crate::lower::model::Ex::XVar(Text::lit("w"))
                                    }), move |k_9292: Array<crate::lower::model::Do>| prism_rtl::Turn::Finished(Array::from(vec![crate::lower::model::Do::DoIfLet(crate::lower::model::Pa::PaCtor(Text::lit("Some"), Array::from(vec![bound_p5xyxy.clone()])), y_pb.clone(), k_9292, Array::new())])))
                                }))
                            }) as Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>
                        })).cycle()
                    }))
                }) as Rc<dyn Fn((crate::lower::model::Ex, Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>)) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>
            };
            (crate::lower::node_::EvRef { node_p: r_p7.node_p.clone(), owner_p: r_p7.owner_p.clone(), pipe_f: pipe_f6.clone() }, w1_p8.clone())
        },
    }
}

/// ```prism
/// GateEvent: unbounded fn Wx, Env, [Arg] -> ((EvRef, Wx))
/// ```
pub fn gate_event_f(wx_p0: &crate::lower::node_::Wx, menv_p1: &crate::lower::types::Env, args_p2: &Array<crate::syntax::Arg>) -> (crate::lower::node_::EvRef, crate::lower::node_::Wx) {
    match crate::prelude::index(args_p2, &Nat::from(1u32)) {
        None => never_event_f(wx_p0, &crate::lower::model::OutTy::OutUnit),
        Some(a_p3) => {
            let (r_p6, w1_p7) = event_ref_f(wx_p0, menv_p1, &a_p3.value_p);
            let cond_p4 = match crate::prelude::index(args_p2, &Nat::from(0u32)) {
                Some(b_p8) => crate::lower::types::as_bool_f(&crate::lower::expr::value_of_f(&wx_p0.lx_p, menv_p1, &b_p8.value_p)),
                None => crate::lower::model::Ex::XBool(false),
            };
            let pipe_f5 = {
                let r_p6x = r_p6.clone();
                let cond_p4x = cond_p4.clone();
                Rc::new(move |(p0, p1): (crate::lower::model::Ex, Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>)| {
                    let r_p6xy = r_p6x.clone();
                    let cond_p4xy = cond_p4x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let x_p9 = p0;
                        let k_fa = p1;
                        (&r_p6xy.pipe_f)((x_p9.clone(), {
                            let cond_p4xyx = cond_p4xy.clone();
                            let k_fax = k_fa.clone();
                            Rc::new(move |p0: crate::lower::model::Ex| {
                                let cond_p4xyxy = cond_p4xyx.clone();
                                let k_faxy = k_fax.clone();
                                crate::prelude::entered(crate::prelude::once_job(move || {
                                    let y_pb = p0;
                                    crate::prelude::call_value((&k_faxy)(y_pb.clone()), move |k_9825: Array<crate::lower::model::Do>| prism_rtl::Turn::Finished(Array::from(vec![crate::lower::model::Do::DoIf(cond_p4xyxy.clone(), k_9825, Array::new())])))
                                }))
                            }) as Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>
                        })).cycle()
                    }))
                }) as Rc<dyn Fn((crate::lower::model::Ex, Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>)) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>
            };
            (crate::lower::node_::EvRef { node_p: r_p6.node_p.clone(), owner_p: r_p6.owner_p.clone(), pipe_f: pipe_f5.clone() }, w1_p7.clone())
        },
    }
}

/// ```prism
/// EventMap: unbounded fn Wx, Env, Expr -> ((EvRef, Wx))
/// ```
pub fn event_map_f(wx_p0: &crate::lower::node_::Wx, menv_p1: &crate::lower::types::Env, e_p2: &crate::syntax::Expr) -> (crate::lower::node_::EvRef, crate::lower::node_::Wx) {
    let lx_p3 = wx_p0.lx_p.clone();
    let t_p4 = crate::lower::types::out_ty_of_f(&lx_p3, &crate::lower::types::peel_f(&crate::lower::type_at_f(&lx_p3, &e_p2.span_p)));
    let evs_p5 = crate::prelude::filter(&operands_f(e_p2), &(|x_p6: &crate::syntax::Expr| &crate::lower::types::layer_of_f(&crate::lower::type_at_f(&lx_p3, &x_p6.span_p)) == &crate::lower::types::Layer::LyEv));
    'm10307: {
        if let m10307_0 = &evs_p5 && (m10307_0.len() == 1) && let Some(one_p7) = crate::prelude::index(m10307_0, &Nat::from(0u32)) {
            break 'm10307 {
                let (r_pb, w1_pc) = event_ref_f(wx_p0, menv_p1, &one_p7);
                let et_p8 = crate::lower::types::out_ty_of_f(&lx_p3, &crate::lower::types::peel_f(&crate::lower::type_at_f(&lx_p3, &one_p7.span_p)));
                let k_p9 = crate::lower::place_key_f(&lx_p3, &one_p7.span_p);
                let pipe_fa = {
                    let r_pbx = r_pb.clone();
                    let lx_p3x = lx_p3.clone();
                    let menv_p1x = menv_p1.clone();
                    let k_p9x = k_p9.clone();
                    let et_p8x = et_p8.clone();
                    let e_p2x = e_p2.clone();
                    Rc::new(move |(p0, p1): (crate::lower::model::Ex, Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>)| {
                        let r_pbxy = r_pbx.clone();
                        let lx_p3xy = lx_p3x.clone();
                        let menv_p1xy = menv_p1x.clone();
                        let k_p9xy = k_p9x.clone();
                        let et_p8xy = et_p8x.clone();
                        let e_p2xy = e_p2x.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let x_pd = p0;
                            let k_fe = p1;
                            (&r_pbxy.pipe_f)((x_pd.clone(), {
                                let k_fex = k_fe.clone();
                                let lx_p3xyx = lx_p3xy.clone();
                                let menv_p1xyx = menv_p1xy.clone();
                                let k_p9xyx = k_p9xy.clone();
                                let et_p8xyx = et_p8xy.clone();
                                let e_p2xyx = e_p2xy.clone();
                                Rc::new(move |p0: crate::lower::model::Ex| {
                                    let k_fexy = k_fex.clone();
                                    let lx_p3xyxy = lx_p3xyx.clone();
                                    let menv_p1xyxy = menv_p1xyx.clone();
                                    let k_p9xyxy = k_p9xyx.clone();
                                    let et_p8xyxy = et_p8xyx.clone();
                                    let e_p2xyxy = e_p2xyx.clone();
                                    crate::prelude::entered(crate::prelude::once_job(move || {
                                        let y_pf = p0;
                                        crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p3xyxy.clone(), crate::lower::types::bind_span_f(&menv_p1xyxy, &k_p9xyxy, &firing_value_f(&y_pf, &et_p8xyxy)), e_p2xyxy.clone()), move |value_of_f_10544: crate::lower::types::Vl| (&k_fexy)(crate::lower::types::own_f(&value_of_f_10544)).cycle())
                                    }))
                                }) as Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>
                            })).cycle()
                        }))
                    }) as Rc<dyn Fn((crate::lower::model::Ex, Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>)) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>
                };
                (crate::lower::node_::EvRef { node_p: r_pb.node_p.clone(), owner_p: r_pb.owner_p.clone(), pipe_f: pipe_fa.clone() }, w1_pc.clone())
            };
        }
        never_event_f(wx_p0, &t_p4)
    }
}

/// ```prism
/// FiringValue: fn Ex, OutTy -> Vl
/// ```
pub fn firing_value_f(ex0: &crate::lower::model::Ex, t_p1: &crate::lower::model::OutTy) -> crate::lower::types::Vl {
    match ex0 {
        crate::lower::model::Ex::XVar(n_p0) => crate::lower::types::Vl::VlPlace(crate::lower::model::Ex::XVar(n_p0.clone()), crate::lower::types::Holding::Owned, t_p1.clone()),
        crate::lower::model::Ex::XUnit => crate::lower::types::Vl::VlPlace(crate::lower::model::Ex::XUnit, crate::lower::types::Holding::Owned, t_p1.clone()),
        x_p3 => crate::lower::types::Vl::VlOwned(x_p3.clone(), t_p1.clone()),
    }
}

/// ```prism
/// Operands: fn Expr -> [Expr]
/// ```
pub fn operands_f(e_p0: &crate::syntax::Expr) -> Array<crate::syntax::Expr> {
    match &*e_p0.kind_p {
        crate::syntax::ExprKind::ECall(c_p1, args_p2, _, _) => crate::prelude::append(&Array::from(vec![(**c_p1).clone()]), &crate::prelude::each(args_p2, &(|a_p3: &crate::syntax::Arg| a_p3.value_p.clone()))),
        crate::syntax::ExprKind::EMethod(r_p4, _, args_p5) => crate::prelude::append(&Array::from(vec![(**r_p4).clone()]), &crate::prelude::each(args_p5, &(|a_p6: &crate::syntax::Arg| a_p6.value_p.clone()))),
        crate::syntax::ExprKind::EBinary(_, l_p7, r_p8) => Array::from(vec![(**l_p7).clone(), (**r_p8).clone()]),
        crate::syntax::ExprKind::EUnary(_, x_p9) => Array::from(vec![(**x_p9).clone()]),
        crate::syntax::ExprKind::EFreeSigil(_, x_pa) => Array::from(vec![(**x_pa).clone()]),
        crate::syntax::ExprKind::EGroup(x_pb) => Array::from(vec![(**x_pb).clone()]),
        crate::syntax::ExprKind::EField(r_pc, _, _) => Array::from(vec![(**r_pc).clone()]),
        crate::syntax::ExprKind::EIndex(r_pd, i_pe) => Array::from(vec![(**r_pd).clone(), (**i_pe).clone()]),
        crate::syntax::ExprKind::ETuple(es_pf) => es_pf.clone(),
        crate::syntax::ExprKind::EArray(es_pg) => es_pg.clone(),
        crate::syntax::ExprKind::EMap(kvs_ph) => crate::prelude::fold(kvs_ph, &Array::new(), &(|acc_pi: &Array<crate::syntax::Expr>, (k_pj, v_pk): &(crate::syntax::Expr, crate::syntax::Expr)| crate::prelude::append(acc_pi, &Array::from(vec![k_pj.clone(), v_pk.clone()])))),
        crate::syntax::ExprKind::ELit(l_pl) => match &l_pl.kind_p {
            crate::syntax::LitKind::LText(segs_pm) => crate::prelude::fold(segs_pm, &Array::new(), &(|acc_pn: &Array<crate::syntax::Expr>, sg_po: &crate::syntax::TextSeg| match sg_po {
                crate::syntax::TextSeg::SegPlaceholder(x_pp) => crate::prelude::push(acc_pn, x_pp),
                _ => acc_pn.clone(),
            })),
            _ => Array::new(),
        },
        _ => Array::new(),
    }
}

/// ```prism
/// Merge: fn Wx, Text, OutTy, EvRef, EvRef -> ((Nat, Wx))
/// ```
pub fn merge_f(wx_p0: &crate::lower::node_::Wx, name_p1: &Text, t_p2: &crate::lower::model::OutTy, l_p3: &crate::lower::node_::EvRef, r_p4: &crate::lower::node_::EvRef) -> (Nat, crate::lower::node_::Wx) {
    combinator_f(wx_p0, name_p1, t_p2, &crate::lower::node_::GnKind::GnMerge, l_p3, r_p4, t_p2, t_p2)
}

/// ```prism
/// Combinator: fn Wx, Text, OutTy, GnKind, EvRef, EvRef, OutTy, OutTy -> ((Nat, Wx))
/// ```
pub fn combinator_f(wx_p0: &crate::lower::node_::Wx, name_p1: &Text, t_p2: &crate::lower::model::OutTy, kind_p3: &crate::lower::node_::GnKind, l_p4: &crate::lower::node_::EvRef, r_p5: &crate::lower::node_::EvRef, lt_p6: &crate::lower::model::OutTy, rt_p7: &crate::lower::model::OutTy) -> (Nat, crate::lower::node_::Wx) {
    let (id_pb, wx1_pc) = crate::lower::node_::add_gn_f(wx_p0, name_p1, t_p2, kind_p3, &Nat::from(1u32));
    let wx2_p8 = crate::lower::node_::add_field_last_f(&wx1_pc, &Text::from(format!("{}_left", name_p1)), &crate::lower::model::OutTy::OutStamped(Rc::new(lt_p6.clone())), &Text::from(format!("`{}`\'s left input", name_p1)), &crate::lower::model::Ex::XCall(Text::lit("Stamped::new"), Array::new()));
    let wx3_p9 = crate::lower::node_::add_field_last_f(&wx2_p8, &Text::from(format!("{}_right", name_p1)), &crate::lower::model::OutTy::OutStamped(Rc::new(rt_p7.clone())), &Text::lit("its right input"), &crate::lower::model::Ex::XCall(Text::lit("Stamped::new"), Array::new()));
    let wx4_pa = {
        let mut this: crate::lower::node_::Wx = wx3_p9.clone();
        this.gns_p = crate::prelude::each(&this.gns_p, &(|n_pd: &crate::lower::node_::Gn| if &n_pd.id_p == &id_pb {
            with_inputs_f(n_pd, &Array::from(vec![Text::from(format!("{}_left", name_p1)), Text::from(format!("{}_right", name_p1))]))
        } else {
            n_pd.clone()
        }));
        this
    };
    (id_pb.clone(), crate::lower::node_::connect_f(&crate::lower::node_::connect_f(&wx4_pa, l_p4, &crate::lower::node_::Sk::SkIn(id_pb.clone(), Nat::from(0u32))), r_p5, &crate::lower::node_::Sk::SkIn(id_pb.clone(), Nat::from(1u32))))
}

/// ```prism
/// WithInputs: fn Gn, [Text] -> Gn
/// ```
pub fn with_inputs_f(n_p0: &crate::lower::node_::Gn, ins_p1: &Array<Text>) -> crate::lower::node_::Gn {
    let mut this: crate::lower::node_::Gn = n_p0.clone();
    this.inputs_p = ins_p1.clone();
    this
}

/// ```prism
/// WithReads: fn Gn, [Read] -> Gn
/// ```
pub fn with_reads_f(n_p0: &crate::lower::node_::Gn, reads_p1: &Array<crate::lower::node_::Read>) -> crate::lower::node_::Gn {
    let mut this: crate::lower::node_::Gn = n_p0.clone();
    this.reads_p = reads_p1.clone();
    this
}
