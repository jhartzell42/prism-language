//! The module `Lower.Node.Dynamics`, from `target/bootstrap/src/prismc/lower/node/dynamics.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file. The runtime
//! side is reached from the crate, `crate::prelude` (and through it `::prism_rtl`), the
//! standard library from `::std`, and nothing is imported by name: a program's own type
//! (`Row`, `Option`) hides none of theirs. The traits are in scope unnamed, for their methods.

use crate::prelude::traits::*;

/// ```prism
/// DynamicExpr: unbounded fn Wx, Env, Expr -> ((Ex, [Read]))
/// ```
pub fn dynamic_expr_f(wx_p0: &crate::lower::node_::Wx, menv_p1: &crate::lower::types::Env, e_p2: &crate::syntax::Expr) -> (crate::lower::model::Ex, crate::prelude::Array<crate::lower::node_::Read>) {
    let v_p3 = crate::lower::expr::value_of_f(&wx_p0.lx_p, menv_p1, e_p2);
    let reads_p4 = crate::prelude::fold(&crate::check::typed::print::exprs_in_f(e_p2), &crate::prelude::Array::new(), &(|acc_p5: &crate::prelude::Array<crate::lower::node_::Read>, x_p6: &crate::syntax::Expr| match &*x_p6.kind_p {
        crate::syntax::ExprKind::EName(n_p7) => match crate::prelude::get(&menv_p1.names_p, &crate::check::env::sname_key_f(n_p7)) {
            ::std::option::Option::Some(crate::lower::types::Bn::BnHold(f_p8, _)) => crate::lower::node_::add_read_f(acc_p5, &crate::lower::node_::Read::OwnRead(f_p8)),
            ::std::option::Option::Some(crate::lower::types::Bn::BnDyn(_, rs_p9, _)) => crate::lower::node_::union_reads_f(acc_p5, &rs_p9),
            _ => acc_p5.clone(),
        },
        _ => acc_p5.clone(),
    }));
    (crate::lower::types::own_f(&v_p3), reads_p4.clone())
}

/// The step machine of `DynamicExpr`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// DynamicExpr: unbounded fn Wx, Env, Expr -> ((Ex, [Read]))
/// ```
pub struct DynamicExpr {
    pub wx_p0: crate::lower::node_::Wx,
    pub menv_p1: crate::lower::types::Env,
    pub e_p2: crate::syntax::Expr,
}

impl ::prism_rtl::Job<(crate::lower::model::Ex, crate::prelude::Array<crate::lower::node_::Read>)> for DynamicExpr {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::lower::model::Ex, crate::prelude::Array<crate::lower::node_::Read>)> {
        let wx_p0 = &self.wx_p0;
        let menv_p1 = &self.menv_p1;
        let e_p2 = &self.e_p2;
        let e_p2x = e_p2.clone();
        let menv_p1x = menv_p1.clone();
        let wx_p0x = wx_p0.clone();
        crate::prelude::call_then(crate::lower::expr::start_value_of_f(wx_p0x.lx_p.clone(), menv_p1x.clone(), e_p2x.clone()), move |value_of_f_1581: crate::lower::types::Vl| {
            let v_p3 = value_of_f_1581;
            crate::prelude::call_then(crate::check::typed::print::start_exprs_in_f(e_p2x.clone()), move |exprs_in_f_1626: crate::prelude::Array<crate::syntax::Expr>| {
                let reads_p4 = crate::prelude::fold(&exprs_in_f_1626, &crate::prelude::Array::new(), &(|acc_p5: &crate::prelude::Array<crate::lower::node_::Read>, x_p6: &crate::syntax::Expr| match &*x_p6.kind_p {
                    crate::syntax::ExprKind::EName(n_p7) => match crate::prelude::get(&menv_p1x.names_p, &crate::check::env::sname_key_f(n_p7)) {
                        ::std::option::Option::Some(crate::lower::types::Bn::BnHold(f_p8, _)) => crate::lower::node_::add_read_f(acc_p5, &crate::lower::node_::Read::OwnRead(f_p8)),
                        ::std::option::Option::Some(crate::lower::types::Bn::BnDyn(_, rs_p9, _)) => crate::lower::node_::union_reads_f(acc_p5, &rs_p9),
                        _ => acc_p5.clone(),
                    },
                    _ => acc_p5.clone(),
                }));
                ::prism_rtl::Turn::Finished((crate::lower::types::own_f(&v_p3), reads_p4.clone()))
            })
        })
    }
}

/// `Start DynamicExpr, x`: what the function value is when passed to `@Run`.
pub fn start_dynamic_expr_f(wx_p0: crate::lower::node_::Wx, menv_p1: crate::lower::types::Env, e_p2: crate::syntax::Expr) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::model::Ex, crate::prelude::Array<crate::lower::node_::Read>)>> {
    ::std::rc::Rc::new(DynamicExpr { wx_p0, menv_p1, e_p2 })
}

/// ```prism
/// NeverEvent: fn Wx, OutTy -> ((EvRef, Wx))
/// ```
pub fn never_event_f(wx_p0: &crate::lower::node_::Wx, t_p1: &crate::lower::model::OutTy) -> (crate::lower::node_::EvRef, crate::lower::node_::Wx) {
    let (id_p2, wx2_p3) = crate::lower::node_::add_gn_f(wx_p0, &crate::prelude::Text::lit("never"), t_p1, &crate::lower::node_::GnKind::GnNever, &crate::prelude::Nat::from(0u32));
    (crate::lower::node_::ev_ref_of_f(&wx2_p3, &id_p2), wx2_p3.clone())
}

/// ```prism
/// EventRef: unbounded fn Wx, Env, Expr -> ((EvRef, Wx))
/// ```
pub fn event_ref_f(wx_p0: &crate::lower::node_::Wx, menv_p1: &crate::lower::types::Env, e_p2: &crate::syntax::Expr) -> (crate::lower::node_::EvRef, crate::lower::node_::Wx) {
    let lx_p3 = wx_p0.lx_p.clone();
    let t_p4 = crate::lower::types::out_ty_of_f(&lx_p3, &crate::lower::types::peel_f(&crate::lower::type_at_f(&lx_p3, &e_p2.span_p)));
    'm2490: {
        let scrutinee = &*e_p2.kind_p;
        if let crate::syntax::ExprKind::EGroup(x_p5) = scrutinee {
            break 'm2490 event_ref_f(wx_p0, menv_p1, &**x_p5);
        }
        if let crate::syntax::ExprKind::EName(n_p6) = scrutinee {
            break 'm2490 match crate::prelude::get(&menv_p1.names_p, &crate::check::env::sname_key_f(n_p6)) {
                ::std::option::Option::Some(crate::lower::types::Bn::BnEv(r_p7, _)) => if &r_p7.owner_p == &wx_p0.node_p {
                    (r_p7.clone(), wx_p0.clone())
                } else {
                    never_event_f(&crate::lower::node_::crossed_f(wx_p0, &crate::prelude::Text::from(format!("the event `{}`, of node `{}`,", &crate::check::env::sname_key_f(n_p6), &r_p7.owner_p))), &t_p4)
                },
                _ => never_event_f(wx_p0, &t_p4),
            };
        }
        if let crate::syntax::ExprKind::EBinary(m2490_2_0, l_p8, r_p9) = scrutinee && (m2490_2_0 == &crate::prelude::Text::lit("<|")) {
            break 'm2490 {
                let (lr_pa, w1_pb) = event_ref_f(wx_p0, menv_p1, &**l_p8);
                let (rr_pc, w2_pd) = event_ref_f(&w1_pb, menv_p1, &**r_p9);
                let (nm_pe, w3_pf) = crate::lower::node_::fresh_name_f(&w2_pd, &crate::prelude::Text::lit("anon"));
                let (id_pg, w4_ph) = merge_f(&w3_pf, &nm_pe, &t_p4, &lr_pa, &rr_pc);
                (crate::lower::node_::ev_ref_of_f(&w4_ph, &id_pg), w4_ph.clone())
            };
        }
        if let crate::syntax::ExprKind::EBinary(m2490_3_0, l_pi, r_pj) = scrutinee && (m2490_3_0 == &crate::prelude::Text::lit("on")) {
            break 'm2490 {
                let (rr_pm, w1_pn) = event_ref_f(wx_p0, menv_p1, &**r_pj);
                let lx_value_pk = if crate::lower::types::has_time_f(&crate::lower::types::peel_f(&crate::lower::type_at_f(&lx_p3, &e_p2.span_p))) && (&crate::lower::types::layer_of_f(&crate::lower::type_at_f(&lx_p3, &l_pi.span_p)) != &crate::lower::types::Layer::LyDyn) {
                    {
                        let mut this: crate::lower::Lx = lx_p3.clone();
                        this.whole_p = true;
                        this
                    }
                } else {
                    lx_p3.clone()
                };
                let value_pl = crate::lower::types::own_f(&crate::lower::expr::value_of_f(&lx_value_pk, menv_p1, &**l_pi));
                (crate::lower::node_::EvRef { node_p: rr_pm.node_p.clone(), owner_p: rr_pm.owner_p.clone(), pipe_f: {
                    let rr_pmx = rr_pm.clone();
                    let value_plx = value_pl.clone();
                    ::std::rc::Rc::new(move |(p0, p1): (crate::lower::model::Ex, ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::Ex) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::lower::model::Do>>>>)| {
                        let rr_pmxy = rr_pmx.clone();
                        let value_plxy = value_plx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let x_po = p0;
                            let k_fp = p1;
                            (&rr_pmxy.pipe_f)((x_po.clone(), {
                                let k_fpx = k_fp.clone();
                                let value_plxyx = value_plxy.clone();
                                ::std::rc::Rc::new(move |p0: crate::lower::model::Ex| {
                                    let k_fpxy = k_fpx.clone();
                                    let value_plxyxy = value_plxyx.clone();
                                    crate::prelude::entered(crate::prelude::once_job(move || {
                                        let _ = p0;
                                        (&k_fpxy)(value_plxyxy.clone()).cycle()
                                    }))
                                }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::Ex) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::lower::model::Do>>>>
                            })).cycle()
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::model::Ex, ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::Ex) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::lower::model::Do>>>>)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::lower::model::Do>>>>
                } }, w1_pn.clone())
            };
        }
        if let crate::syntax::ExprKind::ECall(c_pq, args_pr, _, _) = scrutinee {
            break 'm2490 match callee_key_f(&lx_p3, &**c_pq) {
                m3967_0 if (&m3967_0 == &crate::prelude::Text::lit("Prelude.!Filter")) => filter_event_f(wx_p0, menv_p1, args_pr, &false),
                m3967_1 if (&m3967_1 == &crate::prelude::Text::lit("Prelude.!Present")) => filter_event_f(wx_p0, menv_p1, args_pr, &true),
                m3967_2 if (&m3967_2 == &crate::prelude::Text::lit("Prelude.!Gate")) => gate_event_f(wx_p0, menv_p1, args_pr),
                m3967_3 if (&m3967_3 == &crate::prelude::Text::lit("Prelude.!Union")) => pair_event_f(wx_p0, menv_p1, args_pr, &crate::lower::node_::GnKind::GnUnion, &t_p4),
                m3967_4 if (&m3967_4 == &crate::prelude::Text::lit("Prelude.!Both")) => pair_event_f(wx_p0, menv_p1, args_pr, &crate::lower::node_::GnKind::GnBoth, &t_p4),
                m3967_5 if (&m3967_5 == &crate::prelude::Text::lit("Prelude.!Except")) => pair_event_f(wx_p0, menv_p1, args_pr, &crate::lower::node_::GnKind::GnExcept, &t_p4),
                m3967_6 if (&m3967_6 == &crate::prelude::Text::lit("Prelude.!MergeAll")) => merge_all_event_f(wx_p0, menv_p1, args_pr, &t_p4),
                m3967_7 if (&m3967_7 == &crate::prelude::Text::lit("Prelude.!Updated")) => updated_event_f(wx_p0, menv_p1, args_pr, &t_p4),
                _ => if crate::lower::expr::is_whole_object_f(&lx_p3, e_p2) {
                    event_object_ref_f(wx_p0, menv_p1, e_p2, &t_p4)
                } else {
                    event_map_f(wx_p0, menv_p1, e_p2)
                },
                _ => unreachable!("no arm matched"),
            };
        }
        if let crate::syntax::ExprKind::EIf(m2490_5_0, then_b_pt, ::std::option::Option::Some(else_b_pu)) = scrutinee && let crate::syntax::Cond::CondExpr(c_ps) = &**m2490_5_0 {
            break 'm2490 match (block_expr_o(then_b_pt), block_expr_o(else_b_pu)) {
                (::std::option::Option::Some(a_pv), ::std::option::Option::Some(b_p10)) => event_if_f(wx_p0, menv_p1, &**c_ps, &a_pv, &b_p10, &t_p4),
                _ => event_map_f(wx_p0, menv_p1, e_p2),
            };
        }
        event_map_f(wx_p0, menv_p1, e_p2)
    }
}

/// ```prism
/// EventObjectRef: unbounded fn Wx, Env, Expr, OutTy -> ((EvRef, Wx))
/// ```
pub fn event_object_ref_f(wx_p0: &crate::lower::node_::Wx, menv_p1: &crate::lower::types::Env, e_p2: &crate::syntax::Expr, t_p3: &crate::lower::model::OutTy) -> (crate::lower::node_::EvRef, crate::lower::node_::Wx) {
    let lx_p4 = wx_p0.lx_p.clone();
    let (rs_pb, w1_pc) = crate::lower::node_::fresh_name_f(wx_p0, &crate::prelude::Text::lit("heard"));
    let (id_pd, w2_pe) = crate::lower::node_::add_gn_f(&w1_pc, &rs_pb, t_p3, &crate::lower::node_::GnKind::GnPort, &crate::prelude::Nat::from(0u32));
    let shown_p5 = crate::lower::functions::src_text_f(&lx_p4, &lx_p4.file_p, &e_p2.span_p);
    let getter_p6 = crate::lower::model::MethDef { name_p: crate::prelude::Text::from(format!("{}_event", &rs_pb)), recv_p: crate::lower::model::Recv::RecvRef, params_p: crate::prelude::Array::new(), cx_p: crate::lower::model::CxArg::CxRef, ret_p: crate::lower::model::OutTy::OutEvent(::std::rc::Rc::new(t_p3.clone())), body_p: crate::prelude::Array::new(), tail_p: crate::lower::types::own_f(&crate::lower::expr::value_of_f(&lx_p4, menv_p1, e_p2)), doc_p: crate::prelude::Text::from(format!("`{}`, an event a function gave whole, as its value.", &shown_p5)) };
    let port_p7 = crate::lower::model::Ex::XClosure(false, crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("ev"))]), ::std::rc::Rc::new(crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("ev"))), crate::prelude::Text::lit("port"))))));
    let call_p8 = crate::lower::model::Ex::XClosure(false, crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("n")), crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("v")), crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("cx"))]), ::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("n"))), rs_pb.clone(), crate::prelude::Array::from(vec![crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("v")))), crate::lower::model::Ex::XCx]))));
    let sub_p9 = crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XCall(crate::lower::helper_ref_f(&crate::prelude::Text::lit("subscribe_row")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("node")))), crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Some")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Rc::new")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("node"))), crate::prelude::Text::from(format!("{}_event", &rs_pb)), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx]))]))])), port_p7.clone(), call_p8.clone(), crate::lower::node_::finish::heard_above_f(&rs_pb), crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("node"))), crate::prelude::Text::from(format!("{}_sub", &rs_pb)))))])));
    let w3_pa = {
        let mut this: crate::lower::node_::Wx = crate::lower::node_::add_field_f(&w2_pe, &crate::prelude::Text::from(format!("{}_sub", &rs_pb)), &crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Cell")), crate::prelude::Array::from(vec![crate::lower::model::OutTy::OutOpt(::std::rc::Rc::new(crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Handle")), crate::prelude::Array::new())))])), &crate::prelude::Text::from(format!("the subscription to `{}`", &shown_p5)), &crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Cell::new")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XNone])));
        this.getters_p = crate::prelude::push(&this.getters_p, &getter_p6);
        this.build_p = crate::prelude::push(&this.build_p, &sub_p9);
        this
    };
    (crate::lower::node_::ev_ref_of_f(&w3_pa, &id_pd), w3_pa.clone())
}

/// ```prism
/// EventIf: unbounded fn Wx, Env, Expr, Expr, Expr, OutTy -> ((EvRef, Wx))
/// ```
pub fn event_if_f(wx_p0: &crate::lower::node_::Wx, menv_p1: &crate::lower::types::Env, c_p2: &crate::syntax::Expr, a_p3: &crate::syntax::Expr, b_p4: &crate::syntax::Expr, t_p5: &crate::lower::model::OutTy) -> (crate::lower::node_::EvRef, crate::lower::node_::Wx) {
    let cond_p6 = crate::lower::types::as_bool_f(&crate::lower::expr::value_of_f(&wx_p0.lx_p, menv_p1, c_p2));
    let (ra_p9, w1_pa) = event_ref_f(wx_p0, menv_p1, a_p3);
    let (rb_pb, w2_pc) = event_ref_f(&w1_pa, menv_p1, b_p4);
    let ga_p7 = crate::lower::node_::EvRef { node_p: ra_p9.node_p.clone(), owner_p: ra_p9.owner_p.clone(), pipe_f: {
        let ra_p9x = ra_p9.clone();
        let cond_p6x = cond_p6.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::lower::model::Ex, ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::Ex) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::lower::model::Do>>>>)| {
            let ra_p9xy = ra_p9x.clone();
            let cond_p6xy = cond_p6x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let x_pd = p0;
                let k_fe = p1;
                (&ra_p9xy.pipe_f)((x_pd.clone(), {
                    let cond_p6xyx = cond_p6xy.clone();
                    let k_fex = k_fe.clone();
                    ::std::rc::Rc::new(move |p0: crate::lower::model::Ex| {
                        let cond_p6xyxy = cond_p6xyx.clone();
                        let k_fexy = k_fex.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let y_pf = p0;
                            crate::prelude::call_value((&k_fexy)(y_pf.clone()), move |k_6850: crate::prelude::Array<crate::lower::model::Do>| ::prism_rtl::Turn::Finished(crate::prelude::Array::from(vec![crate::lower::model::Do::DoIf(cond_p6xyxy.clone(), k_6850, crate::prelude::Array::new())])))
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::Ex) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::lower::model::Do>>>>
                })).cycle()
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::model::Ex, ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::Ex) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::lower::model::Do>>>>)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::lower::model::Do>>>>
    } };
    let gb_p8 = crate::lower::node_::EvRef { node_p: rb_pb.node_p.clone(), owner_p: rb_pb.owner_p.clone(), pipe_f: {
        let rb_pbx = rb_pb.clone();
        let cond_p6x = cond_p6.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::lower::model::Ex, ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::Ex) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::lower::model::Do>>>>)| {
            let rb_pbxy = rb_pbx.clone();
            let cond_p6xy = cond_p6x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let x_pg = p0;
                let k_fh = p1;
                (&rb_pbxy.pipe_f)((x_pg.clone(), {
                    let cond_p6xyx = cond_p6xy.clone();
                    let k_fhx = k_fh.clone();
                    ::std::rc::Rc::new(move |p0: crate::lower::model::Ex| {
                        let cond_p6xyxy = cond_p6xyx.clone();
                        let k_fhxy = k_fhx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let y_pi = p0;
                            crate::prelude::call_value((&k_fhxy)(y_pi.clone()), move |k_6988: crate::prelude::Array<crate::lower::model::Do>| ::prism_rtl::Turn::Finished(crate::prelude::Array::from(vec![crate::lower::model::Do::DoIf(crate::lower::model::Ex::XBin(crate::lower::model::BinOp::OpEq, ::std::rc::Rc::new(cond_p6xyxy.clone()), ::std::rc::Rc::new(crate::lower::model::Ex::XBool(false))), k_6988, crate::prelude::Array::new())])))
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::Ex) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::lower::model::Do>>>>
                })).cycle()
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::model::Ex, ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::Ex) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::lower::model::Do>>>>)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::lower::model::Do>>>>
    } };
    let (nm_pj, w3_pk) = crate::lower::node_::fresh_name_f(&w2_pc, &crate::prelude::Text::lit("chosen"));
    let (id_pl, w4_pm) = merge_f(&w3_pk, &nm_pj, t_p5, &ga_p7, &gb_p8);
    (crate::lower::node_::ev_ref_of_f(&w4_pm, &id_pl), w4_pm.clone())
}

/// ```prism
/// ?BlockExpr: fn Block -> ?Expr
/// ```
pub fn block_expr_o(b_p0: &crate::syntax::Block) -> ::std::option::Option<crate::syntax::Expr> {
    'm7222: {
        let scrutinee = &b_p0.stmts_p;
        if let m7222_0 = scrutinee && (m7222_0.len() == 1) && let ::std::option::Option::Some(st_p1) = crate::prelude::index(m7222_0, &crate::prelude::Nat::from(0u32)) {
            break 'm7222 match &st_p1.kind_p {
                crate::syntax::StmtKind::SExpr(x_p2) => ::std::option::Option::Some(x_p2.clone()),
                _ => ::std::option::Option::None,
            };
        }
        ::std::option::Option::None
    }
}

/// ```prism
/// CalleeKey: fn Lx, Expr -> Text
/// ```
pub fn callee_key_f(lx_p0: &crate::lower::Lx, c_p1: &crate::syntax::Expr) -> crate::prelude::Text {
    match &*c_p1.kind_p {
        crate::syntax::ExprKind::EName(n_p2) => {
            let (q_o3, _) = crate::check::env::names::resolve_value_f(&lx_p0.g_p, &lx_p0.home_p, n_p2);
            crate::prelude::or(&q_o3, &crate::prelude::Text::lit(""))
        },
        _ => crate::prelude::Text::lit(""),
    }
}

/// ```prism
/// PairEvent: unbounded fn Wx, Env, [Arg], GnKind, OutTy -> ((EvRef, Wx))
/// ```
pub fn pair_event_f(wx_p0: &crate::lower::node_::Wx, menv_p1: &crate::lower::types::Env, args_p2: &crate::prelude::Array<crate::syntax::Arg>, kind_p3: &crate::lower::node_::GnKind, t_p4: &crate::lower::model::OutTy) -> (crate::lower::node_::EvRef, crate::lower::node_::Wx) {
    match (crate::prelude::index(args_p2, &crate::prelude::Nat::from(0u32)), crate::prelude::index(args_p2, &crate::prelude::Nat::from(1u32))) {
        (::std::option::Option::Some(a_p5), ::std::option::Option::Some(b_p6)) => {
            let (ra_p9, w1_pa) = event_ref_f(wx_p0, menv_p1, &a_p5.value_p);
            let (rb_pb, w2_pc) = event_ref_f(&w1_pa, menv_p1, &b_p6.value_p);
            let lt_p7 = crate::lower::types::out_ty_of_f(&wx_p0.lx_p, &crate::lower::types::peel_f(&crate::lower::type_at_f(&wx_p0.lx_p, &a_p5.value_p.span_p)));
            let rt_p8 = crate::lower::types::out_ty_of_f(&wx_p0.lx_p, &crate::lower::types::peel_f(&crate::lower::type_at_f(&wx_p0.lx_p, &b_p6.value_p.span_p)));
            let (nm_pd, w3_pe) = crate::lower::node_::fresh_name_f(&w2_pc, &crate::lower::node_::kind_word_f(kind_p3));
            let (id_pf, w4_pg) = combinator_f(&w3_pe, &nm_pd, t_p4, kind_p3, &ra_p9, &rb_pb, &lt_p7, &rt_p8);
            (crate::lower::node_::ev_ref_of_f(&w4_pg, &id_pf), w4_pg.clone())
        },
        _ => never_event_f(wx_p0, t_p4),
    }
}

/// ```prism
/// MergeAllEvent: unbounded fn Wx, Env, [Arg], OutTy -> ((EvRef, Wx))
/// ```
pub fn merge_all_event_f(wx_p0: &crate::lower::node_::Wx, menv_p1: &crate::lower::types::Env, args_p2: &crate::prelude::Array<crate::syntax::Arg>, t_p3: &crate::lower::model::OutTy) -> (crate::lower::node_::EvRef, crate::lower::node_::Wx) {
    match crate::prelude::index(args_p2, &crate::prelude::Nat::from(0u32)) {
        ::std::option::Option::Some(a_p4) => match &*a_p4.value_p.kind_p {
            crate::syntax::ExprKind::EArray(es_p5) => {
                let et_p6 = match t_p3 {
                    crate::lower::model::OutTy::OutArray(x_pb) => (**x_pb).clone(),
                    _ => crate::lower::model::OutTy::OutUnit,
                };
                let (nm_pc, w1_pd) = crate::lower::node_::fresh_name_f(wx_p0, &crate::prelude::Text::lit("merged"));
                let (id_pe, w2_pf) = crate::lower::node_::add_gn_f(&w1_pd, &nm_pc, t_p3, &crate::lower::node_::GnKind::GnMergeAll, &crate::prelude::Nat::from(1u32));
                let ins_p7 = crate::prelude::each(&crate::check::errors::range0_f(&crate::prelude::len(es_p5)), &(|i_pg: &crate::prelude::Nat| crate::prelude::Text::from(format!("{}_{}", &nm_pc, i_pg))));
                let w3_p8 = crate::prelude::fold(&ins_p7, &w2_pf, &(|w_ph: &crate::lower::node_::Wx, f_pi: &crate::prelude::Text| crate::lower::node_::add_field_last_f(w_ph, f_pi, &crate::lower::model::OutTy::OutStamped(::std::rc::Rc::new(et_p6.clone())), &crate::prelude::Text::lit("an input of `!MergeAll`"), &crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Stamped::new")), crate::prelude::Array::new()))));
                let w4_p9 = {
                    let mut this: crate::lower::node_::Wx = w3_p8.clone();
                    this.gns_p = crate::prelude::each(&this.gns_p, &(|n_pj: &crate::lower::node_::Gn| if &n_pj.id_p == &id_pe { with_inputs_f(n_pj, &ins_p7) } else { n_pj.clone() }));
                    this
                };
                let w5_pa = crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(es_p5)), w4_p9.clone(), {
                    let menv_p1x = menv_p1.clone();
                    let es_p5x = es_p5.clone();
                    let a_p4x = a_p4.clone();
                    let id_pex = id_pe.clone();
                    ::std::rc::Rc::new(move |(p0, p1): (crate::lower::node_::Wx, crate::prelude::Nat)| {
                        let menv_p1xy = menv_p1x.clone();
                        let es_p5xy = es_p5x.clone();
                        let a_p4xy = a_p4x.clone();
                        let id_pexy = id_pex.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let w_pk = p0;
                            let i_pl = p1;
                            {
                                let (r_pm, w6_pn) = event_ref_f(&w_pk, &menv_p1xy, &crate::prelude::or(&crate::prelude::index(&es_p5xy, &i_pl), &a_p4xy.value_p));
                                ::prism_rtl::Turn::Finished(crate::lower::node_::connect_f(&w6_pn, &r_pm, &crate::lower::node_::Sk::SkIn(id_pexy.clone(), i_pl.clone())))
                            }
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::node_::Wx, crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::node_::Wx>>>
                }));
                (crate::lower::node_::ev_ref_of_f(&w5_pa, &id_pe), w5_pa.clone())
            },
            _ => if &crate::lower::types::layer_of_f(&crate::lower::type_at_f(&wx_p0.lx_p, &a_p4.value_p.span_p)) == &crate::lower::types::Layer::LyPlain {
                merge_list_event_f(wx_p0, menv_p1, &a_p4.value_p, t_p3)
            } else {
                {
                    let (r_pp, w1_pq) = never_event_f(wx_p0, t_p3);
                    let w2_po = {
                        let mut this: crate::lower::node_::Wx = w1_pq.clone();
                        this.build_p = crate::prelude::push(&this.build_p, &crate::lower::expr::internal_bug_do_f(&crate::prelude::Text::from(format!("`!MergeAll` of `{}`, a list that is not plain, read as an event", &crate::lower::functions::src_text_f(&wx_p0.lx_p, &wx_p0.lx_p.file_p, &a_p4.value_p.span_p)))));
                        this
                    };
                    (r_pp.clone(), w2_po.clone())
                }
            },
        },
        ::std::option::Option::None => never_event_f(wx_p0, t_p3),
    }
}

/// ```prism
/// MergeListEvent: unbounded fn Wx, Env, Expr, OutTy -> ((EvRef, Wx))
/// ```
pub fn merge_list_event_f(wx_p0: &crate::lower::node_::Wx, menv_p1: &crate::lower::types::Env, x_p2: &crate::syntax::Expr, t_p3: &crate::lower::model::OutTy) -> (crate::lower::node_::EvRef, crate::lower::node_::Wx) {
    let lx_p4 = wx_p0.lx_p.clone();
    let et_p5 = match t_p3 {
        crate::lower::model::OutTy::OutArray(y_pb) => (**y_pb).clone(),
        _ => crate::lower::model::OutTy::OutUnit,
    };
    let (nm_pc, w1_pd) = crate::lower::node_::fresh_name_f(wx_p0, &crate::prelude::Text::lit("merged"));
    let (id_pe, w2_pf) = crate::lower::node_::add_gn_f(&w1_pd, &nm_pc, t_p3, &crate::lower::node_::GnKind::GnMergeList, &crate::prelude::Nat::from(1u32));
    let list_p6 = crate::prelude::Text::from(format!("{}_list", &nm_pc));
    let shown_p7 = crate::lower::functions::src_text_f(&lx_p4, &lx_p4.file_p, &x_p2.span_p);
    let getter_p8 = crate::lower::model::MethDef { name_p: crate::prelude::Text::from(format!("{}_events", &nm_pc)), recv_p: crate::lower::model::Recv::RecvRef, params_p: crate::prelude::Array::new(), cx_p: crate::lower::model::CxArg::CxRef, ret_p: crate::lower::model::OutTy::OutArray(::std::rc::Rc::new(crate::lower::model::OutTy::OutEvent(::std::rc::Rc::new(et_p5.clone())))), body_p: crate::prelude::Array::new(), tail_p: crate::lower::types::own_f(&crate::lower::expr::value_of_f(&lx_p4, menv_p1, x_p2)), doc_p: crate::prelude::Text::from(format!("`{}`, the list `!MergeAll` merges, as its value.", &shown_p7)) };
    let listened_p9 = crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("node"))), list_p6.clone())), crate::prelude::Text::lit("listen_above"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("node"))), crate::prelude::Text::from(format!("{}_events", &nm_pc)), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx])))), crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("node")))), crate::lower::model::Ex::XPath(crate::lower::model::ref_child_f(&crate::lower::site_ref_f(&lx_p4, &wx_p0.node_p), &crate::prelude::Text::from(format!("{}_in", &nm_pc)))), crate::lower::model::Ex::XPath(crate::lower::model::ref_child_f(&crate::lower::site_ref_f(&lx_p4, &wx_p0.node_p), &crate::prelude::Text::from(format!("{}_in_above", &nm_pc))))])));
    let w3_pa = {
        let mut this: crate::lower::node_::Wx = crate::lower::node_::add_field_last_f(&w2_pf, &list_p6, &crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("prism_rtl::MergeList")), crate::prelude::Array::from(vec![et_p5.clone()])), &crate::prelude::Text::lit("`!MergeAll`\'s list, heard"), &crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Default::default")), crate::prelude::Array::new()));
        this.gns_p = crate::prelude::each(&this.gns_p, &(|n_pg: &crate::lower::node_::Gn| if &n_pg.id_p == &id_pe {
            with_inputs_f(n_pg, &crate::prelude::Array::from(vec![list_p6.clone()]))
        } else {
            n_pg.clone()
        }));
        this.getters_p = crate::prelude::push(&this.getters_p, &getter_p8);
        this.build_p = crate::prelude::push(&this.build_p, &listened_p9);
        this.taken_p = crate::prelude::append(&this.taken_p, &crate::prelude::Array::from(vec![crate::prelude::Text::from(format!("{}_events", &nm_pc)), crate::prelude::Text::from(format!("{}_in", &nm_pc))]));
        this
    };
    (crate::lower::node_::ev_ref_of_f(&w3_pa, &id_pe), w3_pa.clone())
}

/// ```prism
/// UpdatedEvent: unbounded fn Wx, Env, [Arg], OutTy -> ((EvRef, Wx))
/// ```
pub fn updated_event_f(wx_p0: &crate::lower::node_::Wx, menv_p1: &crate::lower::types::Env, args_p2: &crate::prelude::Array<crate::syntax::Arg>, t_p3: &crate::lower::model::OutTy) -> (crate::lower::node_::EvRef, crate::lower::node_::Wx) {
    match crate::prelude::index(args_p2, &crate::prelude::Nat::from(0u32)) {
        ::std::option::Option::Some(a_p4) => {
            let (ex_p7, reads_p8) = dynamic_expr_f(wx_p0, menv_p1, &a_p4.value_p);
            let (nm_p9, w1_pa) = crate::lower::node_::fresh_name_f(wx_p0, &crate::prelude::Text::lit("updated"));
            let (id_pb, w2_pc) = crate::lower::node_::add_gn_f(&w1_pa, &nm_p9, t_p3, &crate::lower::node_::GnKind::GnUpdated, &crate::prelude::Nat::from(1u32));
            let w3_p5 = crate::lower::node_::add_field_last_f(&w2_pc, &crate::prelude::Text::from(format!("{}_moved", &nm_p9)), &crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Cell")), crate::prelude::Array::from(vec![crate::lower::model::OutTy::OutBool])), &crate::prelude::Text::from(format!("a hold `!{}`\'s dynamic reads was written this tick", &nm_p9)), &crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Cell::new")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XBool(false)])));
            let w4_p6 = {
                let mut this: crate::lower::node_::Wx = w3_p5.clone();
                this.gns_p = crate::prelude::each(&this.gns_p, &(|n_pd: &crate::lower::node_::Gn| if &n_pd.id_p == &id_pb { with_reads_f(n_pd, &reads_p8) } else { n_pd.clone() }));
                this.getters_p = crate::prelude::push(&this.getters_p, &crate::lower::model::MethDef { name_p: crate::prelude::Text::from(format!("{}_value", &nm_p9)), recv_p: crate::lower::model::Recv::RecvRef, params_p: crate::prelude::Array::new(), cx_p: crate::lower::model::CxArg::CxRef, ret_p: t_p3.clone(), body_p: crate::prelude::Array::new(), tail_p: ex_p7.clone(), doc_p: crate::prelude::Text::from(format!("The dynamic `!{}` is the event half of, which the wake reads after the tick.", &nm_p9)) });
                this
            };
            (crate::lower::node_::ev_ref_of_f(&w4_p6, &id_pb), w4_p6.clone())
        },
        ::std::option::Option::None => never_event_f(wx_p0, t_p3),
    }
}

/// ```prism
/// FilterEvent: unbounded fn Wx, Env, [Arg], Bool -> ((EvRef, Wx))
/// ```
pub fn filter_event_f(wx_p0: &crate::lower::node_::Wx, menv_p1: &crate::lower::types::Env, args_p2: &crate::prelude::Array<crate::syntax::Arg>, is_unit_p3: &bool) -> (crate::lower::node_::EvRef, crate::lower::node_::Wx) {
    match crate::prelude::index(args_p2, &crate::prelude::Nat::from(0u32)) {
        ::std::option::Option::None => never_event_f(wx_p0, &crate::lower::model::OutTy::OutUnit),
        ::std::option::Option::Some(a_p4) => {
            let (r_p7, w1_p8) = event_ref_f(wx_p0, menv_p1, &a_p4.value_p);
            let bound_p5 = if *is_unit_p3 {
                crate::lower::model::Pa::PaWild
            } else {
                crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("w"))
            };
            let pipe_f6 = {
                let r_p7x = r_p7.clone();
                let bound_p5x = bound_p5.clone();
                let is_unit_p3x = *is_unit_p3;
                ::std::rc::Rc::new(move |(p0, p1): (crate::lower::model::Ex, ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::Ex) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::lower::model::Do>>>>)| {
                    let r_p7xy = r_p7x.clone();
                    let bound_p5xy = bound_p5x.clone();
                    let is_unit_p3xy = is_unit_p3x;
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let x_p9 = p0;
                        let k_fa = p1;
                        (&r_p7xy.pipe_f)((x_p9.clone(), {
                            let bound_p5xyx = bound_p5xy.clone();
                            let k_fax = k_fa.clone();
                            let is_unit_p3xyx = is_unit_p3xy;
                            ::std::rc::Rc::new(move |p0: crate::lower::model::Ex| {
                                let bound_p5xyxy = bound_p5xyx.clone();
                                let k_faxy = k_fax.clone();
                                let is_unit_p3xyxy = is_unit_p3xyx;
                                crate::prelude::entered(crate::prelude::once_job(move || {
                                    let y_pb = p0;
                                    crate::prelude::call_value((&k_faxy)(if is_unit_p3xyxy {
                                        crate::lower::model::Ex::XUnit
                                    } else {
                                        crate::lower::model::Ex::XVar(crate::prelude::Text::lit("w"))
                                    }), move |k_13642: crate::prelude::Array<crate::lower::model::Do>| ::prism_rtl::Turn::Finished(crate::prelude::Array::from(vec![crate::lower::model::Do::DoIfLet(crate::lower::model::Pa::PaCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Some")), crate::prelude::Array::from(vec![bound_p5xyxy.clone()])), y_pb.clone(), k_13642, crate::prelude::Array::new())])))
                                }))
                            }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::Ex) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::lower::model::Do>>>>
                        })).cycle()
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::model::Ex, ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::Ex) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::lower::model::Do>>>>)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::lower::model::Do>>>>
            };
            (crate::lower::node_::EvRef { node_p: r_p7.node_p.clone(), owner_p: r_p7.owner_p.clone(), pipe_f: pipe_f6.clone() }, w1_p8.clone())
        },
    }
}

/// ```prism
/// GateEvent: unbounded fn Wx, Env, [Arg] -> ((EvRef, Wx))
/// ```
pub fn gate_event_f(wx_p0: &crate::lower::node_::Wx, menv_p1: &crate::lower::types::Env, args_p2: &crate::prelude::Array<crate::syntax::Arg>) -> (crate::lower::node_::EvRef, crate::lower::node_::Wx) {
    match crate::prelude::index(args_p2, &crate::prelude::Nat::from(1u32)) {
        ::std::option::Option::None => never_event_f(wx_p0, &crate::lower::model::OutTy::OutUnit),
        ::std::option::Option::Some(a_p3) => {
            let (r_p6, w1_p7) = event_ref_f(wx_p0, menv_p1, &a_p3.value_p);
            let cond_p4 = match crate::prelude::index(args_p2, &crate::prelude::Nat::from(0u32)) {
                ::std::option::Option::Some(b_p8) => crate::lower::types::as_bool_f(&crate::lower::expr::value_of_f(&wx_p0.lx_p, menv_p1, &b_p8.value_p)),
                ::std::option::Option::None => crate::lower::model::Ex::XBool(false),
            };
            let pipe_f5 = {
                let r_p6x = r_p6.clone();
                let cond_p4x = cond_p4.clone();
                ::std::rc::Rc::new(move |(p0, p1): (crate::lower::model::Ex, ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::Ex) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::lower::model::Do>>>>)| {
                    let r_p6xy = r_p6x.clone();
                    let cond_p4xy = cond_p4x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let x_p9 = p0;
                        let k_fa = p1;
                        (&r_p6xy.pipe_f)((x_p9.clone(), {
                            let cond_p4xyx = cond_p4xy.clone();
                            let k_fax = k_fa.clone();
                            ::std::rc::Rc::new(move |p0: crate::lower::model::Ex| {
                                let cond_p4xyxy = cond_p4xyx.clone();
                                let k_faxy = k_fax.clone();
                                crate::prelude::entered(crate::prelude::once_job(move || {
                                    let y_pb = p0;
                                    crate::prelude::call_value((&k_faxy)(y_pb.clone()), move |k_14175: crate::prelude::Array<crate::lower::model::Do>| ::prism_rtl::Turn::Finished(crate::prelude::Array::from(vec![crate::lower::model::Do::DoIf(cond_p4xyxy.clone(), k_14175, crate::prelude::Array::new())])))
                                }))
                            }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::Ex) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::lower::model::Do>>>>
                        })).cycle()
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::model::Ex, ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::Ex) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::lower::model::Do>>>>)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::lower::model::Do>>>>
            };
            (crate::lower::node_::EvRef { node_p: r_p6.node_p.clone(), owner_p: r_p6.owner_p.clone(), pipe_f: pipe_f5.clone() }, w1_p7.clone())
        },
    }
}

/// ```prism
/// EventMap: unbounded fn Wx, Env, Expr -> ((EvRef, Wx))
/// ```
pub fn event_map_f(wx_p0: &crate::lower::node_::Wx, menv_p1: &crate::lower::types::Env, e_p2: &crate::syntax::Expr) -> (crate::lower::node_::EvRef, crate::lower::node_::Wx) {
    let lx_p3 = wx_p0.lx_p.clone();
    let t_p4 = crate::lower::types::out_ty_of_f(&lx_p3, &crate::lower::types::peel_f(&crate::lower::type_at_f(&lx_p3, &e_p2.span_p)));
    let evs_p5 = crate::prelude::filter(&operands_f(e_p2), &(|x_p6: &crate::syntax::Expr| &crate::lower::types::layer_of_f(&crate::lower::type_at_f(&lx_p3, &x_p6.span_p)) == &crate::lower::types::Layer::LyEv));
    'm14657: {
        if let m14657_0 = &evs_p5 && (m14657_0.len() == 1) && let ::std::option::Option::Some(one_p7) = crate::prelude::index(m14657_0, &crate::prelude::Nat::from(0u32)) {
            break 'm14657 {
                let (r_pb, w1_pc) = event_ref_f(wx_p0, menv_p1, &one_p7);
                let et_p8 = crate::lower::types::out_ty_of_f(&lx_p3, &crate::lower::types::peel_f(&crate::lower::type_at_f(&lx_p3, &one_p7.span_p)));
                let k_p9 = crate::lower::place_key_f(&lx_p3, &one_p7.span_p);
                let pipe_fa = {
                    let r_pbx = r_pb.clone();
                    let lx_p3x = lx_p3.clone();
                    let menv_p1x = menv_p1.clone();
                    let k_p9x = k_p9.clone();
                    let et_p8x = et_p8.clone();
                    let e_p2x = e_p2.clone();
                    ::std::rc::Rc::new(move |(p0, p1): (crate::lower::model::Ex, ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::Ex) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::lower::model::Do>>>>)| {
                        let r_pbxy = r_pbx.clone();
                        let lx_p3xy = lx_p3x.clone();
                        let menv_p1xy = menv_p1x.clone();
                        let k_p9xy = k_p9x.clone();
                        let et_p8xy = et_p8x.clone();
                        let e_p2xy = e_p2x.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let x_pd = p0;
                            let k_fe = p1;
                            (&r_pbxy.pipe_f)((x_pd.clone(), {
                                let k_fex = k_fe.clone();
                                let lx_p3xyx = lx_p3xy.clone();
                                let menv_p1xyx = menv_p1xy.clone();
                                let k_p9xyx = k_p9xy.clone();
                                let et_p8xyx = et_p8xy.clone();
                                let e_p2xyx = e_p2xy.clone();
                                ::std::rc::Rc::new(move |p0: crate::lower::model::Ex| {
                                    let k_fexy = k_fex.clone();
                                    let lx_p3xyxy = lx_p3xyx.clone();
                                    let menv_p1xyxy = menv_p1xyx.clone();
                                    let k_p9xyxy = k_p9xyx.clone();
                                    let et_p8xyxy = et_p8xyx.clone();
                                    let e_p2xyxy = e_p2xyx.clone();
                                    crate::prelude::entered(crate::prelude::once_job(move || {
                                        let y_pf = p0;
                                        crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p3xyxy.clone(), crate::lower::types::bind_span_f(&menv_p1xyxy, &k_p9xyxy, &firing_value_f(&y_pf, &et_p8xyxy)), e_p2xyxy.clone()), move |value_of_f_14894: crate::lower::types::Vl| (&k_fexy)(crate::lower::types::own_f(&value_of_f_14894)).cycle())
                                    }))
                                }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::Ex) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::lower::model::Do>>>>
                            })).cycle()
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::model::Ex, ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::Ex) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::lower::model::Do>>>>)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::lower::model::Do>>>>
                };
                (crate::lower::node_::EvRef { node_p: r_pb.node_p.clone(), owner_p: r_pb.owner_p.clone(), pipe_f: pipe_fa.clone() }, w1_pc.clone())
            };
        }
        never_event_f(wx_p0, &t_p4)
    }
}

/// ```prism
/// FiringValue: fn Ex, OutTy -> Vl
/// ```
pub fn firing_value_f(ex0: &crate::lower::model::Ex, t_p1: &crate::lower::model::OutTy) -> crate::lower::types::Vl {
    match ex0 {
        crate::lower::model::Ex::XVar(n_p0) => crate::lower::types::Vl::VlPlace(crate::lower::model::Ex::XVar(n_p0.clone()), crate::lower::types::Holding::Owned, t_p1.clone()),
        crate::lower::model::Ex::XUnit => crate::lower::types::Vl::VlPlace(crate::lower::model::Ex::XUnit, crate::lower::types::Holding::Owned, t_p1.clone()),
        x_p3 => crate::lower::types::Vl::VlOwned(x_p3.clone(), t_p1.clone()),
    }
}

/// ```prism
/// Operands: fn Expr -> [Expr]
/// ```
pub fn operands_f(e_p0: &crate::syntax::Expr) -> crate::prelude::Array<crate::syntax::Expr> {
    match &*e_p0.kind_p {
        crate::syntax::ExprKind::ECall(c_p1, args_p2, _, _) => crate::prelude::append(&crate::prelude::Array::from(vec![(**c_p1).clone()]), &crate::prelude::each(args_p2, &(|a_p3: &crate::syntax::Arg| a_p3.value_p.clone()))),
        crate::syntax::ExprKind::EMethod(r_p4, _, args_p5) => crate::prelude::append(&crate::prelude::Array::from(vec![(**r_p4).clone()]), &crate::prelude::each(args_p5, &(|a_p6: &crate::syntax::Arg| a_p6.value_p.clone()))),
        crate::syntax::ExprKind::EBinary(_, l_p7, r_p8) => crate::prelude::Array::from(vec![(**l_p7).clone(), (**r_p8).clone()]),
        crate::syntax::ExprKind::EUnary(_, x_p9) => crate::prelude::Array::from(vec![(**x_p9).clone()]),
        crate::syntax::ExprKind::EFreeSigil(_, x_pa) => crate::prelude::Array::from(vec![(**x_pa).clone()]),
        crate::syntax::ExprKind::EGroup(x_pb) => crate::prelude::Array::from(vec![(**x_pb).clone()]),
        crate::syntax::ExprKind::EField(r_pc, _, _) => crate::prelude::Array::from(vec![(**r_pc).clone()]),
        crate::syntax::ExprKind::EIndex(r_pd, i_pe) => crate::prelude::Array::from(vec![(**r_pd).clone(), (**i_pe).clone()]),
        crate::syntax::ExprKind::ETuple(es_pf) => es_pf.clone(),
        crate::syntax::ExprKind::EArray(es_pg) => es_pg.clone(),
        crate::syntax::ExprKind::EMap(kvs_ph) => crate::prelude::fold(kvs_ph, &crate::prelude::Array::new(), &(|acc_pi: &crate::prelude::Array<crate::syntax::Expr>, (k_pj, v_pk): &(crate::syntax::Expr, crate::syntax::Expr)| crate::prelude::append(acc_pi, &crate::prelude::Array::from(vec![k_pj.clone(), v_pk.clone()])))),
        crate::syntax::ExprKind::ELit(l_pl) => match &l_pl.kind_p {
            crate::syntax::LitKind::LText(segs_pm) => crate::prelude::fold(segs_pm, &crate::prelude::Array::new(), &(|acc_pn: &crate::prelude::Array<crate::syntax::Expr>, sg_po: &crate::syntax::TextSeg| match sg_po {
                crate::syntax::TextSeg::SegPlaceholder(x_pp) => crate::prelude::push(acc_pn, x_pp),
                _ => acc_pn.clone(),
            })),
            _ => crate::prelude::Array::new(),
        },
        _ => crate::prelude::Array::new(),
    }
}

/// ```prism
/// Merge: fn Wx, Text, OutTy, EvRef, EvRef -> ((Nat, Wx))
/// ```
pub fn merge_f(wx_p0: &crate::lower::node_::Wx, name_p1: &crate::prelude::Text, t_p2: &crate::lower::model::OutTy, l_p3: &crate::lower::node_::EvRef, r_p4: &crate::lower::node_::EvRef) -> (crate::prelude::Nat, crate::lower::node_::Wx) {
    combinator_f(wx_p0, name_p1, t_p2, &crate::lower::node_::GnKind::GnMerge, l_p3, r_p4, t_p2, t_p2)
}

/// ```prism
/// Combinator: fn Wx, Text, OutTy, GnKind, EvRef, EvRef, OutTy, OutTy -> ((Nat, Wx))
/// ```
pub fn combinator_f(wx_p0: &crate::lower::node_::Wx, name_p1: &crate::prelude::Text, t_p2: &crate::lower::model::OutTy, kind_p3: &crate::lower::node_::GnKind, l_p4: &crate::lower::node_::EvRef, r_p5: &crate::lower::node_::EvRef, lt_p6: &crate::lower::model::OutTy, rt_p7: &crate::lower::model::OutTy) -> (crate::prelude::Nat, crate::lower::node_::Wx) {
    let (id_pb, wx1_pc) = crate::lower::node_::add_gn_f(wx_p0, name_p1, t_p2, kind_p3, &crate::prelude::Nat::from(1u32));
    let wx2_p8 = crate::lower::node_::add_field_last_f(&wx1_pc, &crate::prelude::Text::from(format!("{}_left", name_p1)), &crate::lower::model::OutTy::OutStamped(::std::rc::Rc::new(lt_p6.clone())), &crate::prelude::Text::from(format!("`{}`\'s left input", name_p1)), &crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Stamped::new")), crate::prelude::Array::new()));
    let wx3_p9 = crate::lower::node_::add_field_last_f(&wx2_p8, &crate::prelude::Text::from(format!("{}_right", name_p1)), &crate::lower::model::OutTy::OutStamped(::std::rc::Rc::new(rt_p7.clone())), &crate::prelude::Text::lit("its right input"), &crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Stamped::new")), crate::prelude::Array::new()));
    let wx4_pa = {
        let mut this: crate::lower::node_::Wx = wx3_p9.clone();
        this.gns_p = crate::prelude::each(&this.gns_p, &(|n_pd: &crate::lower::node_::Gn| if &n_pd.id_p == &id_pb {
            with_inputs_f(n_pd, &crate::prelude::Array::from(vec![crate::prelude::Text::from(format!("{}_left", name_p1)), crate::prelude::Text::from(format!("{}_right", name_p1))]))
        } else {
            n_pd.clone()
        }));
        this
    };
    (id_pb.clone(), crate::lower::node_::connect_f(&crate::lower::node_::connect_f(&wx4_pa, l_p4, &crate::lower::node_::Sk::SkIn(id_pb.clone(), crate::prelude::Nat::from(0u32))), r_p5, &crate::lower::node_::Sk::SkIn(id_pb.clone(), crate::prelude::Nat::from(1u32))))
}

/// ```prism
/// WithInputs: fn Gn, [Text] -> Gn
/// ```
pub fn with_inputs_f(n_p0: &crate::lower::node_::Gn, ins_p1: &crate::prelude::Array<crate::prelude::Text>) -> crate::lower::node_::Gn {
    let mut this: crate::lower::node_::Gn = n_p0.clone();
    this.inputs_p = ins_p1.clone();
    this
}

/// ```prism
/// WithReads: fn Gn, [Read] -> Gn
/// ```
pub fn with_reads_f(n_p0: &crate::lower::node_::Gn, reads_p1: &crate::prelude::Array<crate::lower::node_::Read>) -> crate::lower::node_::Gn {
    let mut this: crate::lower::node_::Gn = n_p0.clone();
    this.reads_p = reads_p1.clone();
    this
}
