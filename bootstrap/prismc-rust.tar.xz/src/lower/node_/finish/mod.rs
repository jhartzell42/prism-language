//! The module `Lower.Node.Finish`, from `target/bootstrap/src/prismc/lower/node/finish.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// `Sinks`:
///
/// ```prism
/// type Sinks = record:
/// ```
#[derive(Clone)]
pub struct Sinks {
    pub wx: crate::lower::node_::Wx,
    pub dirty: Array<crate::lower::node_::Read>,
    pub builds: Array<crate::lower::node_::Read>,
    pub heights: Array<Nat>,
    pub many: bool,
}

/// ```prism
/// Heights: fn [Gn] -> [Gn]
/// ```
pub fn heights(gns: &Array<crate::lower::node_::Gn>) -> Array<crate::lower::node_::Gn> {
    fold(gns, gns, &(|cur: &Array<crate::lower::node_::Gn>, _: &crate::lower::node_::Gn| each(cur, &(|n: &crate::lower::node_::Gn| height_step(cur, n)))))
}

/// ```prism
/// HeightStep: fn [Gn], Gn -> Gn
/// ```
pub fn height_step(gns: &Array<crate::lower::node_::Gn>, n: &crate::lower::node_::Gn) -> crate::lower::node_::Gn {
    let feeders = filter(gns, &(|m: &crate::lower::node_::Gn| fold(&m.outs, &false, &(|f: &bool, o: &crate::lower::node_::Out| *f || feeds(&o.sink, n)))));
    let top = fold(&feeders, &Nat::from(0u32), &(|hi: &Nat, m: &crate::lower::node_::Gn| max(hi, &m.height)));
    let h = match &n.kind {
        crate::lower::node_::GnKind::GnNamed => top.clone(),
        kind => if is_comb(kind) {
            max(&(&top + &Nat::from(1u32)), &n.floor)
        } else {
            n.height.clone()
        },
    };
    let mut this: crate::lower::node_::Gn = n.clone();
    this.height = h.clone();
    this
}

/// ```prism
/// IsComb: fn GnKind -> Bool
/// ```
pub fn is_comb(k: &crate::lower::node_::GnKind) -> bool {
    match k {
        crate::lower::node_::GnKind::GnMerge => true,
        crate::lower::node_::GnKind::GnUnion => true,
        crate::lower::node_::GnKind::GnBoth => true,
        crate::lower::node_::GnKind::GnExcept => true,
        crate::lower::node_::GnKind::GnMergeAll => true,
        crate::lower::node_::GnKind::GnUpdated => true,
        _ => false,
    }
}

/// ```prism
/// Feeds: fn Sk, Gn -> Bool
/// ```
pub fn feeds(sk0: &crate::lower::node_::Sk, n: &crate::lower::node_::Gn) -> bool {
    match sk0 {
        crate::lower::node_::Sk::SkNode(m) => m == &n.id,
        crate::lower::node_::Sk::SkIn(m, _) => m == &n.id,
        crate::lower::node_::Sk::SkCycle(_, _, m) => m == &n.id,
        crate::lower::node_::Sk::SkMachine(f, _, m) => (m == &n.id) || writes(f, n),
        crate::lower::node_::Sk::SkHold(f) => writes(f, n),
        crate::lower::node_::Sk::SkDistinct(f) => writes(f, n),
        other => false,
    }
}

/// ```prism
/// Writes: fn Text, Gn -> Bool
/// ```
pub fn writes(f: &Text, n: &crate::lower::node_::Gn) -> bool {
    moves(&crate::lower::node_::Read::OwnRead(f.clone()), n)
}

/// ```prism
/// Moves: fn Read, Gn -> Bool
/// ```
pub fn moves(r: &crate::lower::node_::Read, n: &crate::lower::node_::Gn) -> bool {
    (&n.kind == &crate::lower::node_::GnKind::GnUpdated) && crate::lower::node_::has_read(&n.reads, r)
}

/// ```prism
/// ReadsClosed: fn (Text ==> [Read]), [Read] -> [Read]
/// ```
pub fn reads_closed(dyn_: &Map<Text, Array<crate::lower::node_::Read>>, reads: &Array<crate::lower::node_::Read>) -> Array<crate::lower::node_::Read> {
    fold(&crate::check::errors::range0(&Nat::from(4u32)), reads, &(|acc: &Array<crate::lower::node_::Read>, _: &Nat| fold(acc, acc, &(|a: &Array<crate::lower::node_::Read>, r: &crate::lower::node_::Read| crate::lower::node_::union_reads(a, &getter_reads(dyn_, r))))))
}

/// ```prism
/// GetterReads: fn (Text ==> [Read]), Read -> [Read]
/// ```
pub fn getter_reads(dyn_: &Map<Text, Array<crate::lower::node_::Read>>, read1: &crate::lower::node_::Read) -> Array<crate::lower::node_::Read> {
    match read1 {
        crate::lower::node_::Read::OwnRead(n) => or(&get(dyn_, n), &Array::new()),
        crate::lower::node_::Read::ParentRead(_) => Array::new(),
    }
}

/// ```prism
/// ReachesSnap: fn [Text], [Read] -> Bool
/// ```
pub fn reaches_snap(roots: &Array<Text>, reads: &Array<crate::lower::node_::Read>) -> bool {
    fold(reads, &false, &(|f: &bool, r: &crate::lower::node_::Read| *f || match r {
        crate::lower::node_::Read::OwnRead(n) => crate::check::types::has_text(roots, n),
        crate::lower::node_::Read::ParentRead(_) => false,
    }))
}

/// ```prism
/// SnapNames: fn Wx -> [Text]
/// ```
pub fn snap_names(wx: &crate::lower::node_::Wx) -> Array<Text> {
    each(&wx.snaps, &(|sn: &crate::lower::node_::SnapDef| sn.name.clone()))
}

/// ```prism
/// WakeConst: fn [Nat], Nat -> Text
/// ```
pub fn wake_const(heights_: &Array<Nat>, h: &Nat) -> Text {
    if &len(heights_) <= &Nat::from(1u32) {
        Text::lit("WAKE")
    } else {
        Text::from(format!("WAKE_{}", h))
    }
}

/// ```prism
/// SelfCall: fn Text, [Ex] -> Do
/// ```
pub fn self_call(m: &Text, args: &Array<crate::lower::model::Ex>) -> crate::lower::model::Do {
    crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XSelf), m.clone(), push(args, &crate::lower::model::Ex::XCx)))
}

/// ```prism
/// SinkCode: fn Sinks, Sk, Ex -> [Do]
/// ```
pub fn sink_code(sk: &Sinks, target: &crate::lower::node_::Sk, y: &crate::lower::model::Ex) -> Array<crate::lower::model::Do> {
    match target {
        crate::lower::node_::Sk::SkNode(m) => Array::from(vec![self_call(&crate::lower::node_::gn_of(&sk.wx, m).name, &Array::from(vec![y.clone()]))]),
        crate::lower::node_::Sk::SkIn(m, i) => {
            let g = crate::lower::node_::gn_of(&sk.wx, m);
            append(&Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", &or(&index(&g.inputs, i), &Text::lit("")))))), Text::lit("set"), Array::from(vec![y.clone(), crate::lower::model::Ex::XCx])))]), &ask_wake(sk, &g.height))
        },
        crate::lower::node_::Sk::SkHold(f) => append(&Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", f)))), Text::lit("set"), Array::from(vec![y.clone(), crate::lower::model::Ex::XCx])))]), &hold_written(sk, f)),
        crate::lower::node_::Sk::SkDistinct(f) => {
            let differs = crate::lower::model::Ex::XBin(Text::lit("!="), Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", f)))), Text::lit("get"), Array::from(vec![crate::lower::model::Ex::XCx]))), Rc::new(crate::lower::model::Ex::XCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Ex::XClone(Rc::new(y.clone()))]))));
            let write = crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", f)))), Text::lit("set"), Array::from(vec![crate::lower::model::Ex::XCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Ex::XClone(Rc::new(y.clone()))])), crate::lower::model::Ex::XCx])));
            Array::from(vec![crate::lower::model::Do::DoIf(differs.clone(), append(&Array::from(vec![write.clone()]), &hold_written(sk, f)), Array::new())])
        },
        crate::lower::node_::Sk::SkRequest(pos, field_) => {
            let field_ex = if field_ == &Text::lit("") {
                crate::lower::model::Ex::XNone
            } else {
                crate::lower::model::Ex::XCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Ex::XStr(field_.clone())]))
            };
            if emits(&sk.wx, pos) {
                Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCx), Text::lit("request"), Array::from(vec![place_at(&sk.wx, &Text::lit("self"), pos), field_ex.clone(), crate::lower::model::Ex::XMethod(Rc::new(y.clone()), Text::lit("to_pod"), Array::new())])))])
            } else {
                Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(Text::lit("requested")), crate::lower::model::Ex::XMethod(Rc::new(host_field_ex(&sk.wx, pos)), Text::lit("request"), Array::from(vec![crate::lower::model::Ex::XRef(Rc::new(place_at(&sk.wx, &Text::lit("self"), pos))), field_ex.clone(), crate::lower::model::Ex::XMethod(Rc::new(y.clone()), Text::lit("to_pod"), Array::new()), crate::lower::model::Ex::XCx]))), crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCx), Text::lit("keep"), Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("requested"))])))])
            }
        },
        crate::lower::node_::Sk::SkResult => Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCx), Text::lit("result"), Array::from(vec![crate::lower::model::Ex::XCtor(Text::lit("Outcome::Fired"), Array::from(vec![crate::lower::model::Ex::XMethod(Rc::new(y.clone()), Text::lit("to_pod"), Array::new())]))])))]),
        crate::lower::node_::Sk::SkArm(f) => Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", f)))), Text::lit("arm"), Array::from(vec![y.clone(), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XSelf)), crate::lower::model::Ex::XCx])))]),
        crate::lower::node_::Sk::SkMachine(f, step_, out) => {
            let stepped = crate::lower::model::Ex::XCall(step_.clone(), Array::from(vec![crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), f.clone())), Text::lit("get"), Array::from(vec![crate::lower::model::Ex::XCx])))), crate::lower::model::Ex::XRef(Rc::new(y.clone()))]));
            append(&Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTuple(Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("machine_s")), crate::lower::model::Pa::PaBind(Text::lit("machine_b"))])), stepped.clone()), crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", f)))), Text::lit("set"), Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("machine_s")), crate::lower::model::Ex::XCx]))), crate::lower::model::Do::DoIfLet(crate::lower::model::Pa::PaCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("machine_b"))])), crate::lower::model::Ex::XVar(Text::lit("machine_b")), Array::from(vec![self_call(&crate::lower::node_::gn_of(&sk.wx, out).name, &Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("machine_b"))]))]), Array::new())]), &moved_marks(sk, f))
        },
        crate::lower::node_::Sk::SkPort(f) => Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_port", f)))), Text::lit("fire"), Array::from(vec![y.clone(), crate::lower::model::Ex::XCx]))), Text::lit("ok"), Array::new()))]),
        crate::lower::node_::Sk::SkUp(m) => {
            let keyed = &len(&filter(&sk.wx.fields, &(|(f, _, _): &(Text, crate::lower::model::OutTy, Text)| f == &Text::lit("key")))) > &Nat::from(0u32);
            let args = if keyed {
                Array::from(vec![crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::lit("key")))), y.clone(), crate::lower::model::Ex::XCx])
            } else {
                Array::from(vec![y.clone(), crate::lower::model::Ex::XCx])
            };
            Array::from(vec![crate::lower::model::Do::DoIfLet(crate::lower::model::Pa::PaCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("parent"))])), crate::lower::model::Ex::XUpgrade(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::lit("parent")))), Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("parent"))), m.clone(), args.clone()))]), Array::new())])
        },
        crate::lower::node_::Sk::SkCycle(job, again, res) => {
            let more_ = Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", job)))), Text::lit("set"), Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("next")), crate::lower::model::Ex::XCx]))), crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", again)))), Text::lit("arm"), Array::from(vec![crate::lower::model::Ex::XUnit, crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XSelf)), crate::lower::model::Ex::XCx])))]);
            let fin = Array::from(vec![self_call(&crate::lower::node_::gn_of(&sk.wx, res).name, &Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("b"))]))]);
            Array::from(vec![crate::lower::model::Do::DoMatch(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", job)))), Text::lit("get"), Array::from(vec![crate::lower::model::Ex::XCx]))), Text::lit("cycle"), Array::new()), Array::from(vec![(crate::lower::model::Pa::PaCtor(Text::lit("prism_rtl::Turn::More"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("next"))])), more_.clone()), (crate::lower::model::Pa::PaCtor(Text::lit("prism_rtl::Turn::Finished"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("b"))])), fin.clone())]))])
        },
    }
}

/// ```prism
/// HoldWritten: fn Sinks, Text -> [Do]
/// ```
pub fn hold_written(sk: &Sinks, f: &Text) -> Array<crate::lower::model::Do> {
    let r = crate::lower::node_::Read::OwnRead(f.clone());
    let read_by_place = crate::lower::node_::has_read(&sk.dirty, &r);
    let (dirty, told) = match &sk.wx.hosted_by {
        Some(_) => (Array::new(), if read_by_place {
            Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XSelf), Text::lit("document_moved"), Array::from(vec![crate::lower::model::Ex::XCx])))])
        } else {
            Array::new()
        }),
        None => (if read_by_place {
            Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCx), Text::lit("dirty"), Array::from(vec![crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XSelf))])))])
        } else {
            Array::new()
        }, Array::new()),
    };
    let stales = fold(&sk.wx.gen_holds, &Array::new(), &(|acc: &Array<crate::lower::model::Do>, (gname, hs): &(Text, Array<crate::lower::node_::Read>)| if crate::lower::node_::has_read(&reads_closed(&sk.wx.dyn_reads, hs), &r) {
        push(acc, &crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_stale", gname)))), Text::lit("set"), Array::from(vec![crate::lower::model::Ex::XBool(true)]))))
    } else {
        acc.clone()
    }));
    let row_marks = fold(&sk.wx.row_marks, &Array::new(), &(|acc: &Array<crate::lower::model::Do>, rm: &crate::lower::node_::RowMarks| append(acc, &row_written(&sk.wx, rm, &r))));
    let builds = crate::lower::node_::has_read(&sk.builds, &r) || (&len(&stales) > &Nat::from(0u32));
    let rebuild_it = if builds && !lists_build(sk, &r) {
        append(&stales, &Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCx), Text::lit("build_later"), Array::from(vec![crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XSelf))])))]))
    } else {
        stales.clone()
    };
    let gathered = match &sk.wx.result_moved {
        Some((m, rds)) => if crate::lower::node_::has_read(rds, &r) {
            Array::from(vec![crate::lower::model::Do::DoIfLet(crate::lower::model::Pa::PaCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("parent"))])), crate::lower::model::Ex::XUpgrade(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::lit("parent")))), Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("parent"))), m.clone(), Array::from(vec![crate::lower::model::Ex::XCx])))]), Array::new())])
        } else {
            Array::new()
        },
        None => Array::new(),
    };
    append(&append(&append(&append(&append(&dirty, &told), &rebuild_it), &row_marks), &gathered), &moved_marks(sk, f))
}

/// ```prism
/// HostFieldEx: fn Wx, Pos -> Ex
/// ```
pub fn host_field_ex(wx: &crate::lower::node_::Wx, pos: &crate::lower::model::Pos_) -> crate::lower::model::Ex {
    crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), crate::lower::node_::elements::host_local(wx, pos))
}

/// ```prism
/// MovedMarks: fn Sinks, Text -> [Do]
/// ```
pub fn moved_marks(sk: &Sinks, f: &Text) -> Array<crate::lower::model::Do> {
    moved_by(sk, &crate::lower::node_::Read::OwnRead(f.clone()))
}

/// ```prism
/// MovedBy: fn Sinks, Read -> [Do]
/// ```
pub fn moved_by(sk: &Sinks, r: &crate::lower::node_::Read) -> Array<crate::lower::model::Do> {
    let moved = filter(&sk.wx.gns, &(|g: &crate::lower::node_::Gn| moves(r, g)));
    let flags = each(&moved, &(|g: &crate::lower::node_::Gn| crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_moved", &g.name)))), Text::lit("set"), Array::from(vec![crate::lower::model::Ex::XBool(true)])))));
    let heights_ = sort_nats(&fold(&moved, &Array::new(), &(|acc: &Array<Nat>, g: &crate::lower::node_::Gn| crate::check::types::add_nat(acc, &g.height))));
    let marks = each(&snaps_behind(&sk.wx, r), &(|sn: &crate::lower::node_::SnapDef| crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_snap", &sn.name)))), Text::lit("mark"), Array::from(vec![crate::lower::model::Ex::XCx])))));
    let listed = if lists_build(sk, r) {
        Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCx), Text::lit("build_later"), Array::from(vec![crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XSelf))])))])
    } else {
        Array::new()
    };
    let answers = each(&filter(&sk.wx.dyn_answers, &(|(_, rds): &(Text, Array<crate::lower::node_::Read>)| crate::lower::node_::has_read(&reads_closed(&sk.wx.dyn_reads, rds), r))), &(|(name, _): &(Text, Array<crate::lower::node_::Read>)| crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_port", name)))), Text::lit("fire"), Array::from(vec![crate::lower::model::Ex::XUnit, crate::lower::model::Ex::XCx]))), Text::lit("ok"), Array::new()))));
    let adoptions = each(&filter(&sk.wx.flattens, &(|fl: &crate::lower::node_::FlatDef| r == &crate::lower::node_::Read::OwnRead(fl.outer.clone()))), &(|fl: &crate::lower::node_::FlatDef| crate::lower::model::Do::DoScope(adoption(fl))));
    append(&append(&append(&append(&append(&fold(&heights_, &flags, &(|acc: &Array<crate::lower::model::Do>, h: &Nat| append(acc, &ask_wake(sk, h)))), &marks), &listed), &answers), &adoptions), &source_marks(&sk.wx, r))
}

/// ```prism
/// SourceMarks: fn Wx, Read -> [Do]
/// ```
pub fn source_marks(wx: &crate::lower::node_::Wx, r: &crate::lower::node_::Read) -> Array<crate::lower::model::Do> {
    let fors = fold(&wx.builders, &Array::new(), &(|acc: &Array<crate::lower::model::Do>, b: &crate::lower::model::ForDef| if crate::lower::node_::has_read(&reads_closed(&wx.dyn_reads, &or(&get(&wx.dyn_reads, &b.source), &Array::new())), r) {
        push(acc, &crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_cache", &b.source)))), Text::lit("mark"), Array::from(vec![crate::lower::model::Ex::XCx]))))
    } else {
        acc.clone()
    }));
    fold(&wx.let_caches, &fors, &(|acc: &Array<crate::lower::model::Do>, c: &Text| if crate::lower::node_::has_read(&reads_all(&wx.dyn_reads, &or(&get(&wx.dyn_reads, c), &Array::new())), r) {
        push(acc, &crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_cache", c)))), Text::lit("mark"), Array::from(vec![crate::lower::model::Ex::XCx]))))
    } else {
        acc.clone()
    }))
}

/// ```prism
/// ReadsAll: fn (Text ==> [Read]), [Read] -> [Read]
/// ```
pub fn reads_all(dyn_: &Map<Text, Array<crate::lower::node_::Read>>, reads: &Array<crate::lower::node_::Read>) -> Array<crate::lower::node_::Read> {
    fold(&crate::check::errors::range0(&(&size(dyn_) + &Nat::from(1u32))), reads, &(|acc: &Array<crate::lower::node_::Read>, _: &Nat| fold(acc, acc, &(|a: &Array<crate::lower::node_::Read>, r: &crate::lower::node_::Read| crate::lower::node_::union_reads(a, &getter_reads(dyn_, r))))))
}

/// ```prism
/// IsOwnRead: fn Read -> Bool
/// ```
pub fn is_own_read(r: &crate::lower::node_::Read) -> bool {
    match r {
        crate::lower::node_::Read::OwnRead(_) => true,
        crate::lower::node_::Read::ParentRead(_) => false,
    }
}

/// ```prism
/// SnapsBehind: fn Wx, Read -> [SnapDef]
/// ```
pub fn snaps_behind(wx: &crate::lower::node_::Wx, r: &crate::lower::node_::Read) -> Array<crate::lower::node_::SnapDef> {
    filter(&wx.snaps, &(|sn: &crate::lower::node_::SnapDef| (r == &crate::lower::node_::Read::OwnRead(sn.live.clone())) || crate::lower::node_::has_read(&reads_closed(&wx.dyn_reads, &Array::from(vec![crate::lower::node_::Read::OwnRead(sn.live.clone())])), r)))
}

/// ```prism
/// ListsBuild: fn Sinks, Read -> Bool
/// ```
pub fn lists_build(sk: &Sinks, r: &crate::lower::node_::Read) -> bool {
    &len(&snaps_behind(&sk.wx, r)) > &Nat::from(0u32)
}

/// ```prism
/// FiringCode: unbounded fn Sinks, Gn, Ex -> [Do]
/// ```
pub fn firing_code(sk: &Sinks, g: &crate::lower::node_::Gn, x: &crate::lower::model::Ex) -> Array<crate::lower::model::Do> {
    let many = (&len(&g.outs) > &Nat::from(1u32)) && !crate::lower::types::is_copy(&g.ty);
    let xv = if many { crate::lower::model::Ex::XClone(Rc::new(x.clone())) } else { x.clone() };
    run_to_end(fold_job(g.outs.clone(), Array::new(), {
        let xv = xv.clone();
        let sk = sk.clone();
        Rc::new(move |(p0, p1): (Array<crate::lower::model::Do>, crate::lower::node_::Out)| {
            let xv = xv.clone();
            let sk = sk.clone();
            entered(once_job(move || {
                let acc = p0;
                let o = p1;
                call_value((&o.pipe)((xv.clone(), {
                    let sk = sk.clone();
                    let o = o.clone();
                    Rc::new(move |p0: crate::lower::model::Ex| {
                        let sk = sk.clone();
                        let o = o.clone();
                        once_job(move || {
                            let y = p0;
                            prism_rtl::Turn::Finished(sink_code(&sk, &o.sink, &y))
                        })
                    }) as Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>
                })), move |call_13304: Array<crate::lower::model::Do>| prism_rtl::Turn::Finished(append(&acc, &call_13304)))
            }))
        }) as Rc<dyn Fn((Array<crate::lower::model::Do>, crate::lower::node_::Out)) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>
    }))
}

/// The step machine of `FiringCode`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FiringCode: unbounded fn Sinks, Gn, Ex -> [Do]
/// ```
pub struct FiringCode {
    pub sk: Sinks,
    pub g: crate::lower::node_::Gn,
    pub x: crate::lower::model::Ex,
}

impl prism_rtl::Job<Array<crate::lower::model::Do>> for FiringCode {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::lower::model::Do>> {
        let sk = &self.sk;
        let g = &self.g;
        let x = &self.x;
        let many = (&len(&g.outs) > &Nat::from(1u32)) && !crate::lower::types::is_copy(&g.ty);
        let xv = if many { crate::lower::model::Ex::XClone(Rc::new(x.clone())) } else { x.clone() };
        fold_job(g.outs.clone(), Array::new(), {
            let xv = xv.clone();
            let sk = sk.clone();
            Rc::new(move |(p0, p1): (Array<crate::lower::model::Do>, crate::lower::node_::Out)| {
                let xv = xv.clone();
                let sk = sk.clone();
                entered(once_job(move || {
                    let acc = p0;
                    let o = p1;
                    call_value((&o.pipe)((xv.clone(), {
                        let sk = sk.clone();
                        let o = o.clone();
                        Rc::new(move |p0: crate::lower::model::Ex| {
                            let sk = sk.clone();
                            let o = o.clone();
                            once_job(move || {
                                let y = p0;
                                prism_rtl::Turn::Finished(sink_code(&sk, &o.sink, &y))
                            })
                        }) as Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>
                    })), move |call_13304: Array<crate::lower::model::Do>| prism_rtl::Turn::Finished(append(&acc, &call_13304)))
                }))
            }) as Rc<dyn Fn((Array<crate::lower::model::Do>, crate::lower::node_::Out)) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>
        }).cycle()
    }
}

/// `Start FiringCode, x`: what the function value is when passed to `@Run`.
pub fn start_firing_code(sk: Sinks, g: crate::lower::node_::Gn, x: crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>> {
    Rc::new(FiringCode { sk, g, x })
}

/// ```prism
/// FinishNode: unbounded fn Wx, Text, [((Text, OutTy))], Bool -> NodeDef
/// ```
pub fn finish_node(wx0: &crate::lower::node_::Wx, qk: &Text, params: &Array<(Text, crate::lower::model::OutTy)>, is_row: &bool) -> crate::lower::model::NodeDef {
    let closed_gns = each(&wx0.gns, &(|g: &crate::lower::node_::Gn| if &g.kind == &crate::lower::node_::GnKind::GnUpdated {
        crate::lower::node_::dynamics::with_reads(g, &reads_closed(&wx0.dyn_reads, &g.reads))
    } else {
        g.clone()
    }));
    let (row_defs, gns2) = finish_pending(wx0, &heights(&closed_gns));
    let is_gen = *is_row && (&len(&filter(&wx0.fields, &(|(f, _, _): &(Text, crate::lower::model::OutTy, Text)| f == &Text::lit("key")))) == &Nat::from(0u32));
    let wx = {
        let mut this: crate::lower::node_::Wx = wx0.clone();
        this.gns = heights(&gns2);
        this.build = append(&this.build, &updated_gaps(wx0, &closed_gns, &is_gen));
        this.rows = fold(&row_defs, &this.rows, &(|acc: &Array<crate::lower::model::NodeDef>, rd: &crate::lower::model::NodeDef| append(&push(acc, rd), &rd.children)));
        this
    };
    let combs = filter(&wx.gns, &(|g: &crate::lower::node_::Gn| is_comb(&g.kind) || (&g.kind == &crate::lower::node_::GnKind::GnGather)));
    let heights_ = sort_nats(&fold(&combs, &Array::new(), &(|acc: &Array<Nat>, g: &crate::lower::node_::Gn| crate::check::types::add_nat(acc, &g.height))));
    let many = &len(&heights_) > &Nat::from(1u32);
    let consts = each(&heights_, &(|h: &Nat| (wake_const(&heights_, h), h.clone(), Text::lit("merges\' height above the node\'s inputs"))));
    let live = filter(&wx.places, &(|p_: &crate::lower::node_::Place| &p_.getter != &Text::lit("")));
    let root_reads = match &wx.root_dyn {
        Some((_, rds, _)) => reads_closed(&wx.dyn_reads, rds),
        None => Array::new(),
    };
    let dirty_holds = fold(&live, &root_reads, &(|acc: &Array<crate::lower::node_::Read>, p_: &crate::lower::node_::Place| crate::lower::node_::union_reads(acc, &reads_closed(&wx.dyn_reads, &p_.reads))));
    let build_holds = reads_closed(&wx.dyn_reads, &wx.build_holds);
    let sinks = Sinks { wx: wx.clone(), dirty: dirty_holds.clone(), builds: build_holds.clone(), heights: heights_.clone(), many };
    let ev_methods = run_to_end(each_job(filter(&wx.gns, &(|g: &crate::lower::node_::Gn| &g.kind != &crate::lower::node_::GnKind::GnNever)), {
        let sinks = sinks.clone();
        Rc::new(move |p0: crate::lower::node_::Gn| {
            let sinks = sinks.clone();
            entered(once_job(move || {
                let g = p0;
                call_then(start_firing_code(sinks.clone(), g.clone(), crate::lower::model::Ex::XVar(Text::lit("v"))), move |firing_code_15096: Array<crate::lower::model::Do>| prism_rtl::Turn::Finished(crate::lower::model::MethDef { name: g.name.clone(), recv: crate::lower::model::Recv::RecvRc, params: Array::from(vec![(Text::lit("v"), g.ty.clone())]), cx_: crate::lower::model::CxArg::CxMut, ret: crate::lower::model::OutTy::OutUnit, body: firing_code_15096, tail: crate::lower::model::Ex::XUnit, doc: gn_doc(&g) }))
            }))
        }) as Rc<dyn Fn(crate::lower::node_::Gn) -> Rc<dyn prism_rtl::Job<crate::lower::model::MethDef>>>
    }));
    let gather_ins = each(&filter(&wx.gns, &(|g: &crate::lower::node_::Gn| &g.kind == &crate::lower::node_::GnKind::GnGather)), &(|g: &crate::lower::node_::Gn| gather_in(&sinks, g)));
    let place_getters = each(&live, &(|p_: &crate::lower::node_::Place| crate::lower::model::MethDef { name: p_.getter.clone(), recv: crate::lower::model::Recv::RecvRef, params: Array::new(), cx_: crate::lower::model::CxArg::CxRef, ret: crate::lower::types::elem_ty(), body: Array::new(), tail: p_.level.clone(), doc: Text::from(format!("Place {}\'s level, read at the read point.", &crate::lower::model::place_text(&p_.pos))) }));
    let wake_body = if many {
        Array::from(vec![wake_by_height(&combs, &heights_)])
    } else {
        each(&combs, &(|g: &crate::lower::node_::Gn| decide(g)))
    };
    let started_body = each(&wx.started, &(|st: &Nat| self_call(&crate::lower::node_::gn_of(&wx, st).name, &Array::from(vec![crate::lower::model::Ex::XUnit]))));
    let deferred_body = each(&wx.defers, &(|(f, id): &(Text, Nat)| crate::lower::model::Do::DoIfLet(crate::lower::model::Pa::PaCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("v"))])), crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", f)))), Text::lit("fired"), Array::from(vec![crate::lower::model::Ex::XCx])), Array::from(vec![self_call(&crate::lower::node_::gn_of(&wx, id).name, &Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("v"))]))]), Array::new())));
    let patch_body0 = fold(&filter(&live, &(|p_: &crate::lower::node_::Place| emits(&wx, &p_.pos))), &Array::new(), &(|acc: &Array<crate::lower::model::Do>, p_: &crate::lower::node_::Place| append(acc, &patch_place(&wx, p_))));
    let patch_body = append(&patch_body0, &root_dyn_patch(&wx));
    let build_body = build_steps(&sinks, &false);
    let push_body = each(&filter(&wx.dyn_places, &(|(pos, _, _, _): &(crate::lower::model::Pos_, Text, crate::lower::model::OutTy, Text)| emits(&wx, pos))), &(|(pos, f, t, _): &(crate::lower::model::Pos_, Text, crate::lower::model::OutTy, Text)| crate::lower::model::Do::DoIf(crate::lower::model::Ex::XBin(Text::lit("=="), Rc::new(crate::lower::model::Ex::XVar(Text::lit("element"))), Rc::new(crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_element", f))))))), dyn_place_write(&sinks, f, &crate::lower::model::Ex::XDecode(t.clone(), Rc::new(crate::lower::model::Ex::XVar(Text::lit("v"))))), Array::new())));
    let hooks = filter(&Array::from(vec![(Text::lit("wake"), wake_body.clone()), (Text::lit("started"), started_body.clone()), (Text::lit("deferred"), deferred_body.clone()), (Text::lit("build"), build_body.clone()), (Text::lit("push"), push_body.clone()), (Text::lit("patch"), patch_body.clone())]), &(|(_, b): &(Text, Array<crate::lower::model::Do>)| &len(b) > &Nat::from(0u32)));
    let started_reg = if &len(&wx.started) > &Nat::from(0u32) {
        Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCx), Text::lit("on_started"), Array::from(vec![crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(Text::lit("node"))))])))])
    } else {
        Array::new()
    };
    let links = each(&wx.hosts, &(|h: &crate::lower::node_::HostDef| crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XVar(Text::lit("node"))), Text::from(format!("{}", &h.name)))), Text::lit("link"), Array::from(vec![crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XVar(Text::lit("node"))))])))));
    let rows_built = append(&links, &build_steps(&sinks, &true));
    let subscribed = each(&wx.subs, &(|(ev, m, t): &(Text, Text, crate::lower::model::OutTy)| crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XCall(Text::lit("subscribe_row"), Array::from(vec![crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XVar(Text::lit("node")))), crate::lower::model::Ex::XUpgrade(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XVar(Text::lit("node"))), Text::lit("parent")))), crate::lower::model::Ex::XClosure(false, Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("p"))]), Rc::new(crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XVar(Text::lit("p"))), Text::from(format!("{}_port", ev))))))), crate::lower::model::Ex::XClosure(false, Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("n")), crate::lower::model::Pa::PaBind(Text::lit("v")), crate::lower::model::Pa::PaBind(Text::lit("cx"))]), Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("n"))), m.clone(), Array::from(vec![crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(Text::lit("v")))), crate::lower::model::Ex::XCx])))), crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XVar(Text::lit("node"))), Text::from(format!("{}_sub", m)))))])))));
    let answers = append(&each(&filter(&wx.answers, &(|(pos, _, _, _): &(crate::lower::model::Pos_, Nat, crate::lower::model::OutTy, Text)| emits(&wx, pos))), &(|(pos, id, t, _): &(crate::lower::model::Pos_, Nat, crate::lower::model::OutTy, Text)| answer_arm(&wx, pos, id, t))), &each(&filter(&wx.dyn_places, &(|(pos, _, _, _): &(crate::lower::model::Pos_, Text, crate::lower::model::OutTy, Text)| emits(&wx, pos))), &(|(pos, f, t, _): &(crate::lower::model::Pos_, Text, crate::lower::model::OutTy, Text)| dyn_answer_arm(&sinks, pos, f, t))));
    let forwards = append(&each(&filter(&wx.builders, &(|b: &crate::lower::model::ForDef| emits(&wx, &b.pos))), &(|b: &crate::lower::model::ForDef| (pos_pat(&b.pos, &key_tail()), forward_answer(b)))), &fold(&filter(&wx.gens, &(|gd: &crate::lower::model::GenDef| emits(&wx, &gd.pos))), &Array::new(), &(|acc: &Array<(crate::lower::model::Pa, crate::lower::model::Ex)>, gd: &crate::lower::model::GenDef| append(acc, &crate::lower::node_::switch_::gen_forwards(gd)))));
    let host_methods = fold(&wx.hosts, &Array::new(), &(|acc: &Array<crate::lower::model::MethDef>, h: &crate::lower::node_::HostDef| append(acc, &Array::from(vec![typed_dispatch(&sinks, &Text::from(format!("{}_answer", &h.name)), &h.scope), host_moved(&sinks, h)]))));
    let gathered = filter(&wx.snaps, &(|sn: &crate::lower::node_::SnapDef| !(sn.before || is_generation(&wx, &sn.builder))));
    let gathered_moved_ = append(&append(&each(&gathered, &(|sn: &crate::lower::node_::SnapDef| gathered_moved(sn))), &each(&wx.snaps, &(|sn: &crate::lower::node_::SnapDef| snap_publish(&sinks, sn)))), &flatten_methods(&sinks));
    let hosted_methods = match &wx.hosted_by {
        Some(_) => Array::from(vec![typed_dispatch(&sinks, &Text::lit("deliver"), &Nat::from(0u32)), document_getter(&wx)]),
        None => Array::new(),
    };
    let moved_method = match &wx.hosted_by {
        Some(m) => Array::from(vec![document_moved(m)]),
        None => Array::new(),
    };
    let row_methods_ = if *is_row { row_methods(&wx) } else { Array::new() };
    let heard_build_fn = {
        let sinks = sinks.clone();
        Rc::new(move |m: &Text| if crate::lower::node_::has_read(&sinks.builds, &crate::lower::node_::Read::ParentRead(m.clone())) && !lists_build(&sinks, &crate::lower::node_::Read::ParentRead(m.clone())) {
            Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCx), Text::lit("build_later"), Array::from(vec![crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XSelf))])))])
        } else {
            Array::new()
        })
    };
    let heard = each(&row_hears(&wx), &(|m: &Text| crate::lower::model::MethDef { name: Text::from(format!("parent_wrote_{}", m)), recv: crate::lower::model::Recv::RecvRc, params: Array::new(), cx_: crate::lower::model::CxArg::CxMut, ret: crate::lower::model::OutTy::OutUnit, body: append(&append(&moved_by(&sinks, &crate::lower::node_::Read::ParentRead(m.clone())), &(&heard_build_fn)(m)), &fold(&wx.row_marks, &Array::new(), &(|acc: &Array<crate::lower::model::Do>, rm: &crate::lower::node_::RowMarks| append(acc, &row_written(&wx, rm, &crate::lower::node_::Read::ParentRead(m.clone())))))), tail: crate::lower::model::Ex::XUnit, doc: Text::from(format!("The block wrote behind its `{}`, which this row reads through the parent: the `!Updated` nodes over it are told and the wake asked at their heights; the row\'s own builders over it are listed for the build; the rows of this row\'s own `for`s that read it are marked.", m)) }));
    let top = fold(&wx.gns, &Nat::from(0u32), &(|hi: &Nat, g: &crate::lower::node_::Gn| max(hi, &g.height)));
    let wakes_field = if many {
        Array::from(vec![(Text::lit("wakes"), crate::lower::model::OutTy::OutWakes, Text::lit("the heights asked for this tick, lowest first"))])
    } else {
        Array::new()
    };
    let wakes_init = if many {
        Array::from(vec![(Text::lit("wakes"), crate::lower::model::Ex::XCall(Text::lit("Wakes::default"), Array::new()))])
    } else {
        Array::new()
    };
    let gen_fields = fold(&wx.gens, &Array::new(), &(|acc: &Array<(Text, crate::lower::model::OutTy, Text)>, gd: &crate::lower::model::GenDef| append(acc, &Array::from(vec![(gd.name.clone(), crate::lower::model::OutTy::OutCell(Rc::new(crate::lower::model::OutTy::OutOpt(Rc::new(crate::lower::model::OutTy::OutObj(Rc::new(crate::lower::model::OutTy::OutNamed(Text::lit("Row"), Array::new()))))))), Text::from(format!("the current generation of the `rebuild` at place {}", &crate::lower::model::place_text(&gd.pos)))), (Text::from(format!("{}_count", &gd.name)), crate::lower::model::OutTy::OutNamed(Text::lit("Cell"), Array::from(vec![crate::lower::model::OutTy::OutCount])), Text::lit("how many generations it has built")), (Text::from(format!("{}_stale", &gd.name)), crate::lower::model::OutTy::OutNamed(Text::lit("Cell"), Array::from(vec![crate::lower::model::OutTy::OutBool])), Text::lit("its source changed since it was built"))]))));
    let gen_inits = fold(&wx.gens, &Array::new(), &(|acc: &Array<(Text, crate::lower::model::Ex)>, gd: &crate::lower::model::GenDef| append(acc, &Array::from(vec![(gd.name.clone(), crate::lower::model::Ex::XCall(Text::lit("RefCell::new"), Array::from(vec![crate::lower::model::Ex::XNone]))), (Text::from(format!("{}_count", &gd.name)), crate::lower::model::Ex::XCall(Text::lit("Cell::new"), Array::from(vec![crate::lower::model::Ex::XIndex(Nat::from(0u32))]))), (Text::from(format!("{}_stale", &gd.name)), crate::lower::model::Ex::XCall(Text::lit("Cell::new"), Array::from(vec![crate::lower::model::Ex::XBool(false)])))]))));
    let port_fields = each(&wx.ports, &(|pn: &Text| (Text::from(format!("{}_port", pn)), crate::lower::model::OutTy::OutPort(Rc::new(crate::lower::node_::keyed::gn_ty_named(&wx, pn))), Text::from(format!("`!{}`, which rows subscribe to", pn)))));
    let port_inits = each(&wx.ports, &(|pn: &Text| (Text::from(format!("{}_port", pn)), crate::lower::model::Ex::XCall(Text::lit("Port::new"), Array::new()))));
    let sub_fields = each(&wx.subs, &(|(ev, m, t): &(Text, Text, crate::lower::model::OutTy)| (Text::from(format!("{}_sub", m)), crate::lower::model::OutTy::OutNamed(Text::lit("Cell"), Array::from(vec![crate::lower::model::OutTy::OutOpt(Rc::new(crate::lower::model::OutTy::OutNamed(Text::lit("Handle"), Array::new())))])), Text::from(format!("the subscription to the parent\'s `!{}`", ev)))));
    let sub_inits = each(&wx.subs, &(|(ev, m, t): &(Text, Text, crate::lower::model::OutTy)| (Text::from(format!("{}_sub", m)), crate::lower::model::Ex::XCall(Text::lit("Cell::new"), Array::from(vec![crate::lower::model::Ex::XNone])))));
    let fallible = ((wx.fallible || *is_row) || (&len(&wx.builders) > &Nat::from(0u32))) || (&len(&wx.gens) > &Nat::from(0u32));
    crate::lower::model::NodeDef { name: wx.node_.clone(), prism: crate::check::types::bare_name(qk), doc: crate::lower::functions::definition_text(&wx.lx, qk), params: params.clone(), fields: append(&append(&append(&append(&wx.fields, &wakes_field), &gen_fields), &port_fields), &sub_fields), consts: consts.clone(), lets: wx.lets.clone(), inits: append(&wx.inits, &append(&append(&append(&append(&wx.moves, &wakes_init), &gen_inits), &port_inits), &sub_inits)), build: append(&append(&append(&rows_built, &wx.build), &subscribed), &started_reg), fallible, methods: append(&append(&append(&append(&append(&append(&append(&append(&ev_methods, &gather_ins), &place_getters), &wx.getters), &row_methods_), &heard), &host_methods), &gathered_moved_), &moved_method), answers: append(&answers, &forwards), hooks: hooks.clone(), builders: wx.builders.clone(), wakes: many, children: wx.rows.clone(), gens: wx.gens.clone(), subs: wx.subs.clone(), top: top.clone(), row_kind: if *is_row {
        if is_gen {
            crate::lower::model::RowKind::GenerationRow
        } else {
            crate::lower::model::RowKind::ForRow
        }
    } else {
        crate::lower::model::RowKind::NotARow
    }, hosted: hosted_methods.clone() }
}

/// The step machine of `FinishNode`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FinishNode: unbounded fn Wx, Text, [((Text, OutTy))], Bool -> NodeDef
/// ```
pub struct FinishNode {
    pub wx0: crate::lower::node_::Wx,
    pub qk: Text,
    pub params: Array<(Text, crate::lower::model::OutTy)>,
    pub is_row: bool,
}

impl prism_rtl::Job<crate::lower::model::NodeDef> for FinishNode {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::NodeDef> {
        let wx0 = &self.wx0;
        let qk = &self.qk;
        let params = &self.params;
        let is_row = &self.is_row;
        let closed_gns = each(&wx0.gns, &(|g: &crate::lower::node_::Gn| if &g.kind == &crate::lower::node_::GnKind::GnUpdated {
            crate::lower::node_::dynamics::with_reads(g, &reads_closed(&wx0.dyn_reads, &g.reads))
        } else {
            g.clone()
        }));
        let is_row = *is_row;
        let params = params.clone();
        let qk = qk.clone();
        let wx0 = wx0.clone();
        call_then(start_finish_pending(wx0.clone(), heights(&closed_gns)), move |finish_pending_13861: (Array<crate::lower::model::NodeDef>, Array<crate::lower::node_::Gn>)| {
            let (row_defs, gns2) = finish_pending_13861;
            let is_gen = is_row && (&len(&filter(&wx0.fields, &(|(f, _, _): &(Text, crate::lower::model::OutTy, Text)| f == &Text::lit("key")))) == &Nat::from(0u32));
            let wx = {
                let mut this: crate::lower::node_::Wx = wx0.clone();
                this.gns = heights(&gns2);
                this.build = append(&this.build, &updated_gaps(&wx0, &closed_gns, &is_gen));
                this.rows = fold(&row_defs, &this.rows, &(|acc: &Array<crate::lower::model::NodeDef>, rd: &crate::lower::model::NodeDef| append(&push(acc, rd), &rd.children)));
                this
            };
            let combs = filter(&wx.gns, &(|g: &crate::lower::node_::Gn| is_comb(&g.kind) || (&g.kind == &crate::lower::node_::GnKind::GnGather)));
            let heights_ = sort_nats(&fold(&combs, &Array::new(), &(|acc: &Array<Nat>, g: &crate::lower::node_::Gn| crate::check::types::add_nat(acc, &g.height))));
            let many = &len(&heights_) > &Nat::from(1u32);
            let consts = each(&heights_, &(|h: &Nat| (wake_const(&heights_, h), h.clone(), Text::lit("merges\' height above the node\'s inputs"))));
            let live = filter(&wx.places, &(|p_: &crate::lower::node_::Place| &p_.getter != &Text::lit("")));
            let root_reads = match &wx.root_dyn {
                Some((_, rds, _)) => reads_closed(&wx.dyn_reads, rds),
                None => Array::new(),
            };
            let dirty_holds = fold(&live, &root_reads, &(|acc: &Array<crate::lower::node_::Read>, p_: &crate::lower::node_::Place| crate::lower::node_::union_reads(acc, &reads_closed(&wx.dyn_reads, &p_.reads))));
            let build_holds = reads_closed(&wx.dyn_reads, &wx.build_holds);
            let sinks = Sinks { wx: wx.clone(), dirty: dirty_holds.clone(), builds: build_holds.clone(), heights: heights_.clone(), many };
            call_value(each_job(filter(&wx.gns, &(|g: &crate::lower::node_::Gn| &g.kind != &crate::lower::node_::GnKind::GnNever)), {
                let sinks = sinks.clone();
                Rc::new(move |p0: crate::lower::node_::Gn| {
                    let sinks = sinks.clone();
                    entered(once_job(move || {
                        let g = p0;
                        call_then(start_firing_code(sinks.clone(), g.clone(), crate::lower::model::Ex::XVar(Text::lit("v"))), move |firing_code_15096: Array<crate::lower::model::Do>| prism_rtl::Turn::Finished(crate::lower::model::MethDef { name: g.name.clone(), recv: crate::lower::model::Recv::RecvRc, params: Array::from(vec![(Text::lit("v"), g.ty.clone())]), cx_: crate::lower::model::CxArg::CxMut, ret: crate::lower::model::OutTy::OutUnit, body: firing_code_15096, tail: crate::lower::model::Ex::XUnit, doc: gn_doc(&g) }))
                    }))
                }) as Rc<dyn Fn(crate::lower::node_::Gn) -> Rc<dyn prism_rtl::Job<crate::lower::model::MethDef>>>
            }), move |each_14956: Array<crate::lower::model::MethDef>| {
                let ev_methods = each_14956;
                let gather_ins = each(&filter(&wx.gns, &(|g: &crate::lower::node_::Gn| &g.kind == &crate::lower::node_::GnKind::GnGather)), &(|g: &crate::lower::node_::Gn| gather_in(&sinks, g)));
                let place_getters = each(&live, &(|p_: &crate::lower::node_::Place| crate::lower::model::MethDef { name: p_.getter.clone(), recv: crate::lower::model::Recv::RecvRef, params: Array::new(), cx_: crate::lower::model::CxArg::CxRef, ret: crate::lower::types::elem_ty(), body: Array::new(), tail: p_.level.clone(), doc: Text::from(format!("Place {}\'s level, read at the read point.", &crate::lower::model::place_text(&p_.pos))) }));
                let wake_body = if many {
                    Array::from(vec![wake_by_height(&combs, &heights_)])
                } else {
                    each(&combs, &(|g: &crate::lower::node_::Gn| decide(g)))
                };
                let started_body = each(&wx.started, &(|st: &Nat| self_call(&crate::lower::node_::gn_of(&wx, st).name, &Array::from(vec![crate::lower::model::Ex::XUnit]))));
                let deferred_body = each(&wx.defers, &(|(f, id): &(Text, Nat)| crate::lower::model::Do::DoIfLet(crate::lower::model::Pa::PaCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("v"))])), crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", f)))), Text::lit("fired"), Array::from(vec![crate::lower::model::Ex::XCx])), Array::from(vec![self_call(&crate::lower::node_::gn_of(&wx, id).name, &Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("v"))]))]), Array::new())));
                let patch_body0 = fold(&filter(&live, &(|p_: &crate::lower::node_::Place| emits(&wx, &p_.pos))), &Array::new(), &(|acc: &Array<crate::lower::model::Do>, p_: &crate::lower::node_::Place| append(acc, &patch_place(&wx, p_))));
                let patch_body = append(&patch_body0, &root_dyn_patch(&wx));
                let build_body = build_steps(&sinks, &false);
                let push_body = each(&filter(&wx.dyn_places, &(|(pos, _, _, _): &(crate::lower::model::Pos_, Text, crate::lower::model::OutTy, Text)| emits(&wx, pos))), &(|(pos, f, t, _): &(crate::lower::model::Pos_, Text, crate::lower::model::OutTy, Text)| crate::lower::model::Do::DoIf(crate::lower::model::Ex::XBin(Text::lit("=="), Rc::new(crate::lower::model::Ex::XVar(Text::lit("element"))), Rc::new(crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_element", f))))))), dyn_place_write(&sinks, f, &crate::lower::model::Ex::XDecode(t.clone(), Rc::new(crate::lower::model::Ex::XVar(Text::lit("v"))))), Array::new())));
                let hooks = filter(&Array::from(vec![(Text::lit("wake"), wake_body.clone()), (Text::lit("started"), started_body.clone()), (Text::lit("deferred"), deferred_body.clone()), (Text::lit("build"), build_body.clone()), (Text::lit("push"), push_body.clone()), (Text::lit("patch"), patch_body.clone())]), &(|(_, b): &(Text, Array<crate::lower::model::Do>)| &len(b) > &Nat::from(0u32)));
                let started_reg = if &len(&wx.started) > &Nat::from(0u32) {
                    Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCx), Text::lit("on_started"), Array::from(vec![crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(Text::lit("node"))))])))])
                } else {
                    Array::new()
                };
                let links = each(&wx.hosts, &(|h: &crate::lower::node_::HostDef| crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XVar(Text::lit("node"))), Text::from(format!("{}", &h.name)))), Text::lit("link"), Array::from(vec![crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XVar(Text::lit("node"))))])))));
                let rows_built = append(&links, &build_steps(&sinks, &true));
                let subscribed = each(&wx.subs, &(|(ev, m, t): &(Text, Text, crate::lower::model::OutTy)| crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XCall(Text::lit("subscribe_row"), Array::from(vec![crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XVar(Text::lit("node")))), crate::lower::model::Ex::XUpgrade(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XVar(Text::lit("node"))), Text::lit("parent")))), crate::lower::model::Ex::XClosure(false, Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("p"))]), Rc::new(crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XVar(Text::lit("p"))), Text::from(format!("{}_port", ev))))))), crate::lower::model::Ex::XClosure(false, Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("n")), crate::lower::model::Pa::PaBind(Text::lit("v")), crate::lower::model::Pa::PaBind(Text::lit("cx"))]), Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("n"))), m.clone(), Array::from(vec![crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(Text::lit("v")))), crate::lower::model::Ex::XCx])))), crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XVar(Text::lit("node"))), Text::from(format!("{}_sub", m)))))])))));
                let answers = append(&each(&filter(&wx.answers, &(|(pos, _, _, _): &(crate::lower::model::Pos_, Nat, crate::lower::model::OutTy, Text)| emits(&wx, pos))), &(|(pos, id, t, _): &(crate::lower::model::Pos_, Nat, crate::lower::model::OutTy, Text)| answer_arm(&wx, pos, id, t))), &each(&filter(&wx.dyn_places, &(|(pos, _, _, _): &(crate::lower::model::Pos_, Text, crate::lower::model::OutTy, Text)| emits(&wx, pos))), &(|(pos, f, t, _): &(crate::lower::model::Pos_, Text, crate::lower::model::OutTy, Text)| dyn_answer_arm(&sinks, pos, f, t))));
                let forwards = append(&each(&filter(&wx.builders, &(|b: &crate::lower::model::ForDef| emits(&wx, &b.pos))), &(|b: &crate::lower::model::ForDef| (pos_pat(&b.pos, &key_tail()), forward_answer(b)))), &fold(&filter(&wx.gens, &(|gd: &crate::lower::model::GenDef| emits(&wx, &gd.pos))), &Array::new(), &(|acc: &Array<(crate::lower::model::Pa, crate::lower::model::Ex)>, gd: &crate::lower::model::GenDef| append(acc, &crate::lower::node_::switch_::gen_forwards(gd)))));
                let host_methods = fold(&wx.hosts, &Array::new(), &(|acc: &Array<crate::lower::model::MethDef>, h: &crate::lower::node_::HostDef| append(acc, &Array::from(vec![typed_dispatch(&sinks, &Text::from(format!("{}_answer", &h.name)), &h.scope), host_moved(&sinks, h)]))));
                let gathered = filter(&wx.snaps, &(|sn: &crate::lower::node_::SnapDef| !(sn.before || is_generation(&wx, &sn.builder))));
                let gathered_moved_ = append(&append(&each(&gathered, &(|sn: &crate::lower::node_::SnapDef| gathered_moved(sn))), &each(&wx.snaps, &(|sn: &crate::lower::node_::SnapDef| snap_publish(&sinks, sn)))), &flatten_methods(&sinks));
                let hosted_methods = match &wx.hosted_by {
                    Some(_) => Array::from(vec![typed_dispatch(&sinks, &Text::lit("deliver"), &Nat::from(0u32)), document_getter(&wx)]),
                    None => Array::new(),
                };
                let moved_method = match &wx.hosted_by {
                    Some(m) => Array::from(vec![document_moved(m)]),
                    None => Array::new(),
                };
                let row_methods_ = if is_row { row_methods(&wx) } else { Array::new() };
                let heard_build_fn = {
                    let sinks = sinks.clone();
                    Rc::new(move |m: &Text| if crate::lower::node_::has_read(&sinks.builds, &crate::lower::node_::Read::ParentRead(m.clone())) && !lists_build(&sinks, &crate::lower::node_::Read::ParentRead(m.clone())) {
                        Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCx), Text::lit("build_later"), Array::from(vec![crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XSelf))])))])
                    } else {
                        Array::new()
                    })
                };
                let heard = each(&row_hears(&wx), &(|m: &Text| crate::lower::model::MethDef { name: Text::from(format!("parent_wrote_{}", m)), recv: crate::lower::model::Recv::RecvRc, params: Array::new(), cx_: crate::lower::model::CxArg::CxMut, ret: crate::lower::model::OutTy::OutUnit, body: append(&append(&moved_by(&sinks, &crate::lower::node_::Read::ParentRead(m.clone())), &(&heard_build_fn)(m)), &fold(&wx.row_marks, &Array::new(), &(|acc: &Array<crate::lower::model::Do>, rm: &crate::lower::node_::RowMarks| append(acc, &row_written(&wx, rm, &crate::lower::node_::Read::ParentRead(m.clone())))))), tail: crate::lower::model::Ex::XUnit, doc: Text::from(format!("The block wrote behind its `{}`, which this row reads through the parent: the `!Updated` nodes over it are told and the wake asked at their heights; the row\'s own builders over it are listed for the build; the rows of this row\'s own `for`s that read it are marked.", m)) }));
                let top = fold(&wx.gns, &Nat::from(0u32), &(|hi: &Nat, g: &crate::lower::node_::Gn| max(hi, &g.height)));
                let wakes_field = if many {
                    Array::from(vec![(Text::lit("wakes"), crate::lower::model::OutTy::OutWakes, Text::lit("the heights asked for this tick, lowest first"))])
                } else {
                    Array::new()
                };
                let wakes_init = if many {
                    Array::from(vec![(Text::lit("wakes"), crate::lower::model::Ex::XCall(Text::lit("Wakes::default"), Array::new()))])
                } else {
                    Array::new()
                };
                let gen_fields = fold(&wx.gens, &Array::new(), &(|acc: &Array<(Text, crate::lower::model::OutTy, Text)>, gd: &crate::lower::model::GenDef| append(acc, &Array::from(vec![(gd.name.clone(), crate::lower::model::OutTy::OutCell(Rc::new(crate::lower::model::OutTy::OutOpt(Rc::new(crate::lower::model::OutTy::OutObj(Rc::new(crate::lower::model::OutTy::OutNamed(Text::lit("Row"), Array::new()))))))), Text::from(format!("the current generation of the `rebuild` at place {}", &crate::lower::model::place_text(&gd.pos)))), (Text::from(format!("{}_count", &gd.name)), crate::lower::model::OutTy::OutNamed(Text::lit("Cell"), Array::from(vec![crate::lower::model::OutTy::OutCount])), Text::lit("how many generations it has built")), (Text::from(format!("{}_stale", &gd.name)), crate::lower::model::OutTy::OutNamed(Text::lit("Cell"), Array::from(vec![crate::lower::model::OutTy::OutBool])), Text::lit("its source changed since it was built"))]))));
                let gen_inits = fold(&wx.gens, &Array::new(), &(|acc: &Array<(Text, crate::lower::model::Ex)>, gd: &crate::lower::model::GenDef| append(acc, &Array::from(vec![(gd.name.clone(), crate::lower::model::Ex::XCall(Text::lit("RefCell::new"), Array::from(vec![crate::lower::model::Ex::XNone]))), (Text::from(format!("{}_count", &gd.name)), crate::lower::model::Ex::XCall(Text::lit("Cell::new"), Array::from(vec![crate::lower::model::Ex::XIndex(Nat::from(0u32))]))), (Text::from(format!("{}_stale", &gd.name)), crate::lower::model::Ex::XCall(Text::lit("Cell::new"), Array::from(vec![crate::lower::model::Ex::XBool(false)])))]))));
                let port_fields = each(&wx.ports, &(|pn: &Text| (Text::from(format!("{}_port", pn)), crate::lower::model::OutTy::OutPort(Rc::new(crate::lower::node_::keyed::gn_ty_named(&wx, pn))), Text::from(format!("`!{}`, which rows subscribe to", pn)))));
                let port_inits = each(&wx.ports, &(|pn: &Text| (Text::from(format!("{}_port", pn)), crate::lower::model::Ex::XCall(Text::lit("Port::new"), Array::new()))));
                let sub_fields = each(&wx.subs, &(|(ev, m, t): &(Text, Text, crate::lower::model::OutTy)| (Text::from(format!("{}_sub", m)), crate::lower::model::OutTy::OutNamed(Text::lit("Cell"), Array::from(vec![crate::lower::model::OutTy::OutOpt(Rc::new(crate::lower::model::OutTy::OutNamed(Text::lit("Handle"), Array::new())))])), Text::from(format!("the subscription to the parent\'s `!{}`", ev)))));
                let sub_inits = each(&wx.subs, &(|(ev, m, t): &(Text, Text, crate::lower::model::OutTy)| (Text::from(format!("{}_sub", m)), crate::lower::model::Ex::XCall(Text::lit("Cell::new"), Array::from(vec![crate::lower::model::Ex::XNone])))));
                let fallible = ((wx.fallible || is_row) || (&len(&wx.builders) > &Nat::from(0u32))) || (&len(&wx.gens) > &Nat::from(0u32));
                prism_rtl::Turn::Finished(crate::lower::model::NodeDef { name: wx.node_.clone(), prism: crate::check::types::bare_name(&qk), doc: crate::lower::functions::definition_text(&wx.lx, &qk), params: params.clone(), fields: append(&append(&append(&append(&wx.fields, &wakes_field), &gen_fields), &port_fields), &sub_fields), consts: consts.clone(), lets: wx.lets.clone(), inits: append(&wx.inits, &append(&append(&append(&append(&wx.moves, &wakes_init), &gen_inits), &port_inits), &sub_inits)), build: append(&append(&append(&rows_built, &wx.build), &subscribed), &started_reg), fallible, methods: append(&append(&append(&append(&append(&append(&append(&append(&ev_methods, &gather_ins), &place_getters), &wx.getters), &row_methods_), &heard), &host_methods), &gathered_moved_), &moved_method), answers: append(&answers, &forwards), hooks: hooks.clone(), builders: wx.builders.clone(), wakes: many, children: wx.rows.clone(), gens: wx.gens.clone(), subs: wx.subs.clone(), top: top.clone(), row_kind: if is_row {
                    if is_gen {
                        crate::lower::model::RowKind::GenerationRow
                    } else {
                        crate::lower::model::RowKind::ForRow
                    }
                } else {
                    crate::lower::model::RowKind::NotARow
                }, hosted: hosted_methods.clone() })
            })
        })
    }
}

/// `Start FinishNode, x`: what the function value is when passed to `@Run`.
pub fn start_finish_node(wx0: crate::lower::node_::Wx, qk: Text, params: Array<(Text, crate::lower::model::OutTy)>, is_row: bool) -> Rc<dyn prism_rtl::Job<crate::lower::model::NodeDef>> {
    Rc::new(FinishNode { wx0, qk, params, is_row })
}

/// ```prism
/// IsGeneration: fn Wx, Text -> Bool
/// ```
pub fn is_generation(wx: &crate::lower::node_::Wx, name: &Text) -> bool {
    &len(&filter(&wx.gens, &(|gd: &crate::lower::model::GenDef| &gd.name == name))) > &Nat::from(0u32)
}

/// ```prism
/// FlattenMethods: fn Sinks -> [MethDef]
/// ```
pub fn flatten_methods(sk: &Sinks) -> Array<crate::lower::model::MethDef> {
    let wx = sk.wx.clone();
    let adopts = each(&wx.flattens, &(|fl: &crate::lower::node_::FlatDef| {
        let set = crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_inner", &fl.name)))), Text::lit("set"), Array::from(vec![crate::lower::model::Ex::XCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XSelf), fl.outer.clone(), Array::from(vec![crate::lower::model::Ex::XCx]))])), crate::lower::model::Ex::XCx])));
        crate::lower::model::MethDef { name: Text::from(format!("{}_adopt", &fl.name)), recv: crate::lower::model::Recv::RecvRc, params: Array::new(), cx_: crate::lower::model::CxArg::CxMut, ret: crate::lower::model::OutTy::OutUnit, body: append(&Array::from(vec![set.clone()]), &hold_written(sk, &Text::from(format!("{}_inner", &fl.name)))), tail: crate::lower::model::Ex::XUnit, doc: Text::lit("`@Flatten` adopts the inner its `rebuild`\'s dynamic held after the tick before, among this tick\'s first firings: from here on it reads that inner (Semantics ch. 7).") }
    }));
    let dyn_gens = filter(&wx.gens, &(|gd: &crate::lower::model::GenDef| &len(&filter(&wx.snaps, &(|sn: &crate::lower::node_::SnapDef| &sn.builder == &gd.name))) > &Nat::from(0u32)));
    let moved = each(&dyn_gens, &(|gd: &crate::lower::model::GenDef| {
        let marks = fold(&filter(&wx.flattens, &(|fl: &crate::lower::node_::FlatDef| &fl.generation == &gd.name)), &Array::new(), &(|acc: &Array<crate::lower::model::Do>, fl: &crate::lower::node_::FlatDef| append(acc, &hold_written(sk, &Text::from(format!("{}_inner", &fl.name))))));
        crate::lower::model::MethDef { name: Text::from(format!("{}_result_moved", &gd.name)), recv: crate::lower::model::Recv::RecvRc, params: Array::new(), cx_: crate::lower::model::CxArg::CxMut, ret: crate::lower::model::OutTy::OutUnit, body: marks.clone(), tail: crate::lower::model::Ex::XUnit, doc: Text::lit("The current generation\'s result moved: what reads a `@Flatten` over it reads it again.") }
    }));
    append(&adopts, &moved)
}

/// ```prism
/// HostMoved: fn Sinks, HostDef -> MethDef
/// ```
pub fn host_moved(sk: &Sinks, h: &crate::lower::node_::HostDef) -> crate::lower::model::MethDef {
    crate::lower::model::MethDef { name: Text::from(format!("{}_moved", &h.name)), recv: crate::lower::model::Recv::RecvRc, params: Array::new(), cx_: crate::lower::model::CxArg::CxMut, ret: crate::lower::model::OutTy::OutUnit, body: hold_written(sk, &Text::from(format!("{}_doc_now", &h.name))), tail: crate::lower::model::Ex::XUnit, doc: Text::from(format!("A node of the child hosted at place {} wrote behind its document: the structure is marked as for a write of a hold it reads (pick HO), the snapshot listed to be taken; the program\'s `$doc` moves when it is published, the tick after (pick ST).", &crate::lower::model::place_text(&h.pos))) }
}

/// ```prism
/// BuildSteps: fn Sinks, Bool -> [Do]
/// ```
pub fn build_steps(sk: &Sinks, at_build: &bool) -> Array<crate::lower::model::Do> {
    let wx = sk.wx.clone();
    let recv = if *at_build {
        crate::lower::model::Ex::XVar(Text::lit("node"))
    } else {
        crate::lower::model::Ex::XSelf
    };
    let take_fn = {
        let at_build = *at_build;
        let sk = sk.clone();
        Rc::new(move |sn: &crate::lower::node_::SnapDef| if at_build { snap_take_at_build(sn) } else { snap_take(&sk, sn) })
    };
    let builder_fn = {
        let wx = wx.clone();
        let take_fn = take_fn.clone();
        let recv = recv.clone();
        Rc::new(move |b: &crate::lower::model::ForDef| {
            let before_ = each(&filter(&wx.snaps, &(|sn: &crate::lower::node_::SnapDef| sn.before && (&sn.builder == &b.name))), &*take_fn);
            let after_ = each(&filter(&wx.snaps, &(|sn: &crate::lower::node_::SnapDef| !sn.before && (&sn.builder == &b.name))), &*take_fn);
            append(&push(&before_, &crate::lower::model::Do::DoExpr(crate::lower::expr::try_of(&crate::lower::model::Ex::XMethod(Rc::new(recv.clone()), Text::from(format!("{}_build", &b.name)), Array::from(vec![crate::lower::model::Ex::XCx]))))), &after_)
        })
    };
    let gen__fn = {
        let at_build = *at_build;
        let recv = recv.clone();
        let wx = wx.clone();
        let take_fn = take_fn.clone();
        Rc::new(move |gd: &crate::lower::model::GenDef| {
            let built = if at_build {
                crate::lower::model::Do::DoExpr(crate::lower::expr::try_of(&crate::lower::model::Ex::XMethod(Rc::new(recv.clone()), Text::from(format!("{}_build", &gd.name)), Array::from(vec![crate::lower::model::Ex::XCx]))))
            } else {
                crate::lower::model::Do::DoIf(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_stale", &gd.name)))), Text::lit("replace"), Array::from(vec![crate::lower::model::Ex::XBool(false)])), Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::expr::try_of(&crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_build", &gd.name)), Array::from(vec![crate::lower::model::Ex::XCx]))))]), Array::new())
            };
            append(&Array::from(vec![built.clone()]), &each(&filter(&wx.snaps, &(|sn: &crate::lower::node_::SnapDef| !sn.before && (&sn.builder == &gd.name))), &*take_fn))
        })
    };
    fold(&crate::check::errors::range0(&(&len(&wx.scopes) + &Nat::from(1u32))), &Array::new(), &(|acc: &Array<crate::lower::model::Do>, i: &Nat| {
        let k = or(&(&len(&wx.scopes)).checked_sub(i), &Nat::from(0u32));
        let builders = fold(&filter(&wx.builders, &(|b: &crate::lower::model::ForDef| &b.pos.scope == &k)), &Array::new(), &(|a: &Array<crate::lower::model::Do>, b: &crate::lower::model::ForDef| append(a, &(&builder_fn)(b))));
        append(&append(acc, &builders), &fold(&filter(&wx.gens, &(|gd: &crate::lower::model::GenDef| &gd.pos.scope == &k)), &Array::new(), &(|a: &Array<crate::lower::model::Do>, gd: &crate::lower::model::GenDef| append(a, &(&gen__fn)(gd)))))
    }))
}

/// ```prism
/// SnapTakeAtBuild: fn SnapDef -> Do
/// ```
pub fn snap_take_at_build(sn: &crate::lower::node_::SnapDef) -> crate::lower::model::Do {
    crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XVar(Text::lit("node"))), Text::from(format!("{}_snap", &sn.name)))), Text::lit("take"), Array::from(vec![crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("node"))), Text::from(format!("{}_now", &sn.name)), Array::from(vec![crate::lower::model::Ex::XCx])), crate::lower::model::Ex::XCx])))
}

/// ```prism
/// SnapTake: fn Sinks, SnapDef -> Do
/// ```
pub fn snap_take(sk: &Sinks, sn: &crate::lower::node_::SnapDef) -> crate::lower::model::Do {
    let now = crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_now", &sn.name)), Array::from(vec![crate::lower::model::Ex::XCx]));
    let take_ = crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_snap", &sn.name)))), if sn.eq { Text::lit("take_compared") } else { Text::lit("take") }, Array::from(vec![now.clone(), crate::lower::model::Ex::XCx])));
    let queue = crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCx), Text::lit("answer_later"), Array::from(vec![crate::lower::model::Ex::XLater(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("node"))), Text::from(format!("{}_publish", &sn.name)), Array::from(vec![crate::lower::model::Ex::XCx]))))])));
    let queued = crate::lower::model::Do::DoIf(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_snap", &sn.name)))), Text::lit("queue"), Array::from(vec![crate::lower::model::Ex::XCx])), Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(Text::lit("node")), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XSelf))), queue.clone()]), Array::new());
    crate::lower::model::Do::DoIf(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_snap", &sn.name)))), Text::lit("marked"), Array::from(vec![crate::lower::model::Ex::XCx])), Array::from(vec![take_.clone(), queued.clone()]), Array::new())
}

/// ```prism
/// SnapPublish: fn Sinks, SnapDef -> MethDef
/// ```
pub fn snap_publish(sk: &Sinks, sn: &crate::lower::node_::SnapDef) -> crate::lower::model::MethDef {
    crate::lower::model::MethDef { name: Text::from(format!("{}_publish", &sn.name)), recv: crate::lower::model::Recv::RecvRc, params: Array::new(), cx_: crate::lower::model::CxArg::CxMut, ret: crate::lower::model::OutTy::OutUnit, body: Array::from(vec![crate::lower::model::Do::DoIf(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_snap", &sn.name)))), Text::lit("published"), Array::from(vec![crate::lower::model::Ex::XCx])), hold_written(sk, &sn.name), Array::new())]), tail: crate::lower::model::Ex::XUnit, doc: Text::from(format!("{}, published: its snapshot of the tick before moved it, written as a hold is (pick ST).", &sn.what)) }
}

/// ```prism
/// GatheredMoved: fn SnapDef -> MethDef
/// ```
pub fn gathered_moved(sn: &crate::lower::node_::SnapDef) -> crate::lower::model::MethDef {
    crate::lower::model::MethDef { name: Text::from(format!("{}_moved", &sn.name)), recv: crate::lower::model::Recv::RecvRc, params: Array::new(), cx_: crate::lower::model::CxArg::CxMut, ret: crate::lower::model::OutTy::OutUnit, body: Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_snap", &sn.name)))), Text::lit("mark"), Array::from(vec![crate::lower::model::Ex::XCx]))), crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCx), Text::lit("build_later"), Array::from(vec![crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XSelf))])))]), tail: crate::lower::model::Ex::XUnit, doc: Text::lit("A row\'s result moved: the `for`\'s gathered dynamic is marked, and its snapshot taken after the builder (pick ST).") }
}

/// ```prism
/// DocumentGetter: fn Wx -> MethDef
/// ```
pub fn document_getter(wx: &crate::lower::node_::Wx) -> crate::lower::model::MethDef {
    let is_own_fn = Rc::new(move |p_: &crate::lower::model::Pos_| &p_.scope == &Nat::from(0u32));
    let body = document_body(&{
        let f = Rc::new(vec_push);
        Rc::new(move |(a0, a1): (crate::lower::model::Ex, crate::lower::model::Ex)| {
            let f = f.clone();
            once_job(move || prism_rtl::Turn::Finished(f(&a0, &a1)))
        }) as Rc<dyn Fn((crate::lower::model::Ex, crate::lower::model::Ex)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Do>>>
    }, &filter(&wx.places, &(|pl: &crate::lower::node_::Place| (&is_own_fn)(&pl.pos))), &filter(&wx.builders, &(|b: &crate::lower::model::ForDef| (&is_own_fn)(&b.pos))), &filter(&wx.gens, &(|gd: &crate::lower::model::GenDef| (&is_own_fn)(&gd.pos))));
    crate::lower::model::MethDef { name: Text::lit("document"), recv: crate::lower::model::Recv::RecvRef, params: Array::new(), cx_: crate::lower::model::CxArg::CxRef, ret: crate::lower::model::OutTy::OutNamed(Text::lit("Vec"), Array::from(vec![crate::lower::model::OutTy::OutTuple(Array::from(vec![crate::lower::model::OutTy::OutPath, crate::lower::types::elem_ty()]))])), body: append(&Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaMut(Text::lit("doc"))), crate::lower::model::OutTy::OutNamed(Text::lit("Vec"), Array::from(vec![crate::lower::model::OutTy::OutTuple(Array::from(vec![crate::lower::model::OutTy::OutPath, crate::lower::types::elem_ty()]))]))), crate::lower::model::Ex::XCall(Text::lit("Vec::new"), Array::new()))]), &body), tail: crate::lower::model::Ex::XVar(Text::lit("doc")), doc: Text::lit("The row\'s own places, entries of its host\'s document, by their paths relative to the row (pick HO).") }
}

/// ```prism
/// DocumentMoved: fn Text -> MethDef
/// ```
pub fn document_moved(m: &Text) -> crate::lower::model::MethDef {
    crate::lower::model::MethDef { name: Text::lit("document_moved"), recv: crate::lower::model::Recv::RecvRc, params: Array::new(), cx_: crate::lower::model::CxArg::CxMut, ret: crate::lower::model::OutTy::OutUnit, body: Array::from(vec![crate::lower::model::Do::DoIfLet(crate::lower::model::Pa::PaCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("parent"))])), crate::lower::model::Ex::XUpgrade(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::lit("parent")))), Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("parent"))), m.clone(), Array::from(vec![crate::lower::model::Ex::XCx])))]), Array::new())]), tail: crate::lower::model::Ex::XUnit, doc: Text::lit("A place of this row may have moved: its host\'s document moved, and the host\'s readers and rows are marked (pick HO).") }
}

/// ```prism
/// DocumentBody: fn (fn Ex, Ex -> Do), [Place], [ForDef], [GenDef] -> [Do]
/// ```
pub fn document_body(add_fn: &Rc<dyn Fn((crate::lower::model::Ex, crate::lower::model::Ex)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Do>>>, places: &Array<crate::lower::node_::Place>, builders: &Array<crate::lower::model::ForDef>, gens: &Array<crate::lower::model::GenDef>) -> Array<crate::lower::model::Do> {
    let statics = run_to_end(each_job(places.clone(), {
        let add_fn = add_fn.clone();
        Rc::new(move |p0: crate::lower::node_::Place| {
            let add_fn = add_fn.clone();
            entered(once_job(move || {
                let pl = p0;
                {
                    let level = if &pl.getter == &Text::lit("") {
                        pl.level.clone()
                    } else {
                        crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XSelf), pl.getter.clone(), Array::from(vec![crate::lower::model::Ex::XCx]))
                    };
                    (&add_fn)((crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCall(Text::lit("Path::root"), Array::new())), Text::lit("at"), Array::from(vec![crate::lower::model::Ex::XIndex(pl.pos.at.clone())])), level.clone())).cycle()
                }
            }))
        }) as Rc<dyn Fn(crate::lower::node_::Place) -> Rc<dyn prism_rtl::Job<crate::lower::model::Do>>>
    }));
    let rows = run_to_end(each_job(builders.clone(), {
        let add_fn = add_fn.clone();
        Rc::new(move |p0: crate::lower::model::ForDef| {
            let add_fn = add_fn.clone();
            entered(once_job(move || {
                let b = p0;
                call_value((&add_fn)((crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCall(Text::lit("Path::root"), Array::new())), Text::lit("at"), Array::from(vec![crate::lower::model::Ex::XIndex(b.pos.at.clone())]))), Text::lit("child"), Array::from(vec![crate::lower::model::Ex::XCtor(Text::lit("Segment::Key"), Array::from(vec![crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("k"))), Text::lit("to_pod"), Array::new())]))]))), Text::lit("join"), Array::from(vec![crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XVar(Text::lit("p"))))])), crate::lower::model::Ex::XVar(Text::lit("e")))), move |add_30872: crate::lower::model::Do| prism_rtl::Turn::Finished(crate::lower::model::Do::DoFor(crate::lower::model::Pa::PaTuple(Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("k")), crate::lower::model::Pa::PaBind(Text::lit("row"))])), crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), b.name.clone())), Text::lit("borrow"), Array::new())), Text::lit("iter"), Array::new()), Array::from(vec![crate::lower::model::Do::DoFor(crate::lower::model::Pa::PaTuple(Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("p")), crate::lower::model::Pa::PaBind(Text::lit("e"))])), crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("row"))), Text::lit("document"), Array::from(vec![crate::lower::model::Ex::XCx])), Array::from(vec![add_30872]))]))))
            }))
        }) as Rc<dyn Fn(crate::lower::model::ForDef) -> Rc<dyn prism_rtl::Job<crate::lower::model::Do>>>
    }));
    let generations = run_to_end(each_job(gens.clone(), {
        let add_fn = add_fn.clone();
        Rc::new(move |p0: crate::lower::model::GenDef| {
            let add_fn = add_fn.clone();
            entered(once_job(move || {
                let gd = p0;
                call_value((&add_fn)((crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCall(Text::lit("Path::root"), Array::new())), Text::lit("at"), Array::from(vec![crate::lower::model::Ex::XIndex(gd.pos.at.clone())]))), Text::lit("child"), Array::from(vec![crate::lower::model::Ex::XCtor(Text::lit("Segment::Gen"), Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("g"))]))]))), Text::lit("join"), Array::from(vec![crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XVar(Text::lit("p"))))])), crate::lower::model::Ex::XVar(Text::lit("e")))), move |add_31444: crate::lower::model::Do| prism_rtl::Turn::Finished(crate::lower::model::Do::DoIfLet(crate::lower::model::Pa::PaCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("row"))])), crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), gd.name.clone())), Text::lit("borrow"), Array::new())), Text::lit("as_ref"), Array::new()), Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(Text::lit("g")), crate::lower::model::Ex::XBin(Text::lit("-"), Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_count", &gd.name)))), Text::lit("get"), Array::new())), Rc::new(crate::lower::model::Ex::XIndex(Nat::from(1u32))))), crate::lower::model::Do::DoFor(crate::lower::model::Pa::PaTuple(Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("p")), crate::lower::model::Pa::PaBind(Text::lit("e"))])), crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("row"))), Text::lit("document"), Array::from(vec![crate::lower::model::Ex::XCx])), Array::from(vec![add_31444]))]), Array::new())))
            }))
        }) as Rc<dyn Fn(crate::lower::model::GenDef) -> Rc<dyn prism_rtl::Job<crate::lower::model::Do>>>
    }));
    append(&append(&statics, &rows), &generations)
}

/// ```prism
/// MapInsert: fn Ex, Ex -> Do
/// ```
pub fn map_insert(path_: &crate::lower::model::Ex, e: &crate::lower::model::Ex) -> crate::lower::model::Do {
    crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("doc"))), Text::lit("insert"), Array::from(vec![path_.clone(), e.clone()])))
}

/// ```prism
/// VecPush: fn Ex, Ex -> Do
/// ```
pub fn vec_push(path_: &crate::lower::model::Ex, e: &crate::lower::model::Ex) -> crate::lower::model::Do {
    crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("doc"))), Text::lit("push"), Array::from(vec![crate::lower::model::Ex::XTuple(Array::from(vec![path_.clone(), e.clone()]))])))
}

/// ```prism
/// DynAnswerArm: fn Sinks, Pos, Text, OutTy -> ((Pa, Ex))
/// ```
pub fn dyn_answer_arm(sk: &Sinks, pos: &crate::lower::model::Pos_, f: &Text, t: &crate::lower::model::OutTy) -> (crate::lower::model::Pa, crate::lower::model::Ex) {
    (pos_pat(pos, &Array::new()), crate::lower::model::Ex::XBlock(dyn_place_write(sk, f, &crate::lower::model::Ex::XDecode(t.clone(), Rc::new(crate::lower::model::Ex::XVar(Text::lit("v"))))), Rc::new(crate::lower::model::Ex::XUnit)))
}

/// ```prism
/// DynPlaceWrite: fn Sinks, Text, Ex -> [Do]
/// ```
pub fn dyn_place_write(sk: &Sinks, f: &Text, value: &crate::lower::model::Ex) -> Array<crate::lower::model::Do> {
    append(&Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", f)))), Text::lit("set"), Array::from(vec![value.clone(), crate::lower::model::Ex::XCx])))]), &hold_written(sk, f))
}

/// ```prism
/// UpdatedGaps: fn Wx, [Gn], Bool -> [Do]
/// ```
pub fn updated_gaps(wx: &crate::lower::node_::Wx, gns: &Array<crate::lower::node_::Gn>, is_gen: &bool) -> Array<crate::lower::model::Do> {
    let holds = fold(&wx.fields, &Array::new(), &(|acc: &Array<Text>, (f, t, _): &(Text, crate::lower::model::OutTy, Text)| if is_hold(t) { push(acc, f) } else { acc.clone() }));
    let derived = keys(&wx.dyn_reads);
    let roots = snap_names(wx);
    let own = fold(&filter(gns, &(|g: &crate::lower::node_::Gn| &g.kind == &crate::lower::node_::GnKind::GnUpdated)), &Array::new(), &(|acc: &Array<crate::lower::model::Do>, g: &crate::lower::node_::Gn| fold(&g.reads, acc, &(|a: &Array<crate::lower::model::Do>, r: &crate::lower::node_::Read| match r {
        crate::lower::node_::Read::ParentRead(f) => if *is_gen {
            push(a, &crate::lower::expr::refusal_do(&Text::from(format!("`!Updated` of a dynamic in a generation that reads its block\'s `{}`, which the block does not tell a generation of (gap DY)", f))))
        } else {
            a.clone()
        },
        crate::lower::node_::Read::OwnRead(f) => if (crate::check::types::has_text(&holds, f) || crate::check::types::has_text(&derived, f)) || crate::check::types::has_text(&roots, f) {
            a.clone()
        } else {
            push(a, &crate::lower::expr::refusal_do(&Text::from(format!("`!Updated` of a dynamic that reads `{}`, which no sink of this node writes (no height for its event)", f))))
        },
    }))));
    fold(&wx.pending, &own, &(|acc: &Array<crate::lower::model::Do>, p_: &crate::lower::node_::PendingRow| fold(&row_hears(&p_.wx), acc, &(|a: &Array<crate::lower::model::Do>, m: &Text| {
        let behind = reads_closed(&wx.dyn_reads, &Array::from(vec![crate::lower::node_::Read::OwnRead(m.clone())]));
        let written = fold(&behind, &false, &(|w: &bool, r: &crate::lower::node_::Read| *w || match r {
            crate::lower::node_::Read::OwnRead(h) => crate::check::types::has_text(&holds, h),
            crate::lower::node_::Read::ParentRead(_) => true,
        }));
        if crate::check::types::has_text(&roots, m) || reaches_snap(&roots, &behind) {
            push(a, &crate::lower::expr::refusal_do(&Text::from(format!("`!Updated` of a dynamic in a row that reads its block\'s `{}`, a structural dynamic the block publishes at the start of a tick, not lowered for a row\'s `!Updated` (gap SU)", m))))
        } else {
            if written || crate::check::types::has_text(&derived, m) {
                a.clone()
            } else {
                push(a, &crate::lower::expr::refusal_do(&Text::from(format!("`!Updated` of a dynamic in a row that reads its block\'s `{}`, which no sink of the block writes (no height for its event)", m))))
            }
        }
    }))))
}

/// ```prism
/// FinishPending: unbounded fn Wx, [Gn] -> (([NodeDef], [Gn]))
/// ```
pub fn finish_pending(wx: &crate::lower::node_::Wx, gns: &Array<crate::lower::node_::Gn>) -> (Array<crate::lower::model::NodeDef>, Array<crate::lower::node_::Gn>) {
    run_to_end(fold_job(wx.pending.clone(), (Array::new(), gns.clone()), {
        let wx = wx.clone();
        Rc::new(move |(p0, p1): ((Array<crate::lower::model::NodeDef>, Array<crate::lower::node_::Gn>), crate::lower::node_::PendingRow)| {
            let wx = wx.clone();
            entered(once_job(move || {
                let (defs, cur) = p0;
                let p_ = p1;
                {
                    let floors = fold(&row_hears(&p_.wx), &Map::new(), &(|acc: &Map<Text, Nat>, m: &Text| insert(acc, m, &parent_floor(&wx, &cur, &Array::from(vec![crate::lower::node_::Read::ParentRead(m.clone())])))));
                    let floored = {
                        let mut this: crate::lower::node_::Wx = p_.wx.clone();
                        this.floors = floors.clone();
                        this.gns = each(&this.gns, &(|g: &crate::lower::node_::Gn| if &g.kind == &crate::lower::node_::GnKind::GnUpdated {
                            with_floor(g, &parent_floor(&wx, &cur, &reads_closed(&p_.wx.dyn_reads, &g.reads)))
                        } else {
                            g.clone()
                        }));
                        this
                    };
                    call_then(start_finish_node(floored.clone(), p_.qk.clone(), p_.params.clone(), true), move |finish_node_35710: crate::lower::model::NodeDef| {
                        let def = finish_node_35710;
                        let next_ = match &p_.gather {
                            Some(gid) => each(&cur, &(|g: &crate::lower::node_::Gn| if &g.id == gid { with_height(g, &(&def.top + &Nat::from(1u32))) } else { g.clone() })),
                            None => cur.clone(),
                        };
                        prism_rtl::Turn::Finished((push(&defs, &def), next_.clone()))
                    })
                }
            }))
        }) as Rc<dyn Fn(((Array<crate::lower::model::NodeDef>, Array<crate::lower::node_::Gn>), crate::lower::node_::PendingRow)) -> Rc<dyn prism_rtl::Job<(Array<crate::lower::model::NodeDef>, Array<crate::lower::node_::Gn>)>>>
    }))
}

/// The step machine of `FinishPending`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FinishPending: unbounded fn Wx, [Gn] -> (([NodeDef], [Gn]))
/// ```
pub struct FinishPending {
    pub wx: crate::lower::node_::Wx,
    pub gns: Array<crate::lower::node_::Gn>,
}

impl prism_rtl::Job<(Array<crate::lower::model::NodeDef>, Array<crate::lower::node_::Gn>)> for FinishPending {
    fn cycle(&self) -> prism_rtl::Turn<(Array<crate::lower::model::NodeDef>, Array<crate::lower::node_::Gn>)> {
        let wx = &self.wx;
        let gns = &self.gns;
        fold_job(wx.pending.clone(), (Array::new(), gns.clone()), {
            let wx = wx.clone();
            Rc::new(move |(p0, p1): ((Array<crate::lower::model::NodeDef>, Array<crate::lower::node_::Gn>), crate::lower::node_::PendingRow)| {
                let wx = wx.clone();
                entered(once_job(move || {
                    let (defs, cur) = p0;
                    let p_ = p1;
                    {
                        let floors = fold(&row_hears(&p_.wx), &Map::new(), &(|acc: &Map<Text, Nat>, m: &Text| insert(acc, m, &parent_floor(&wx, &cur, &Array::from(vec![crate::lower::node_::Read::ParentRead(m.clone())])))));
                        let floored = {
                            let mut this: crate::lower::node_::Wx = p_.wx.clone();
                            this.floors = floors.clone();
                            this.gns = each(&this.gns, &(|g: &crate::lower::node_::Gn| if &g.kind == &crate::lower::node_::GnKind::GnUpdated {
                                with_floor(g, &parent_floor(&wx, &cur, &reads_closed(&p_.wx.dyn_reads, &g.reads)))
                            } else {
                                g.clone()
                            }));
                            this
                        };
                        call_then(start_finish_node(floored.clone(), p_.qk.clone(), p_.params.clone(), true), move |finish_node_35710: crate::lower::model::NodeDef| {
                            let def = finish_node_35710;
                            let next_ = match &p_.gather {
                                Some(gid) => each(&cur, &(|g: &crate::lower::node_::Gn| if &g.id == gid { with_height(g, &(&def.top + &Nat::from(1u32))) } else { g.clone() })),
                                None => cur.clone(),
                            };
                            prism_rtl::Turn::Finished((push(&defs, &def), next_.clone()))
                        })
                    }
                }))
            }) as Rc<dyn Fn(((Array<crate::lower::model::NodeDef>, Array<crate::lower::node_::Gn>), crate::lower::node_::PendingRow)) -> Rc<dyn prism_rtl::Job<(Array<crate::lower::model::NodeDef>, Array<crate::lower::node_::Gn>)>>>
        }).cycle()
    }
}

/// `Start FinishPending, x`: what the function value is when passed to `@Run`.
pub fn start_finish_pending(wx: crate::lower::node_::Wx, gns: Array<crate::lower::node_::Gn>) -> Rc<dyn prism_rtl::Job<(Array<crate::lower::model::NodeDef>, Array<crate::lower::node_::Gn>)>> {
    Rc::new(FinishPending { wx, gns })
}

/// ```prism
/// ParentFloor: fn Wx, [Gn], [Read] -> Nat
/// ```
pub fn parent_floor(wx: &crate::lower::node_::Wx, gns: &Array<crate::lower::node_::Gn>, reads: &Array<crate::lower::node_::Read>) -> Nat {
    fold(reads, &Nat::from(0u32), &(|hi: &Nat, r: &crate::lower::node_::Read| match r {
        crate::lower::node_::Read::ParentRead(m) => fold(&reads_closed(&wx.dyn_reads, &Array::from(vec![crate::lower::node_::Read::OwnRead(m.clone())])), hi, &(|h2: &Nat, hr: &crate::lower::node_::Read| match hr {
            crate::lower::node_::Read::OwnRead(f) => fold(gns, h2, &(|h3: &Nat, g: &crate::lower::node_::Gn| if writes_hold(g, f) { max(h3, &(&g.height + &Nat::from(1u32))) } else { h3.clone() })),
            crate::lower::node_::Read::ParentRead(up) => max(h2, &or(&get(&wx.floors, up), &Nat::from(0u32))),
        })),
        crate::lower::node_::Read::OwnRead(_) => hi.clone(),
    }))
}

/// ```prism
/// WritesHold: fn Gn, Text -> Bool
/// ```
pub fn writes_hold(g: &crate::lower::node_::Gn, f: &Text) -> bool {
    fold(&g.outs, &false, &(|acc: &bool, o: &crate::lower::node_::Out| *acc || sink_writes_hold(&o.sink, f)))
}

/// ```prism
/// SinkWritesHold: fn Sk, Text -> Bool
/// ```
pub fn sink_writes_hold(sk0: &crate::lower::node_::Sk, f: &Text) -> bool {
    match sk0 {
        crate::lower::node_::Sk::SkHold(h) => h == f,
        crate::lower::node_::Sk::SkDistinct(h) => h == f,
        crate::lower::node_::Sk::SkMachine(h, _, _) => h == f,
        other => false,
    }
}

/// ```prism
/// WithFloor: fn Gn, Nat -> Gn
/// ```
pub fn with_floor(g: &crate::lower::node_::Gn, h: &Nat) -> crate::lower::node_::Gn {
    let mut this: crate::lower::node_::Gn = g.clone();
    this.floor = h.clone();
    this
}

/// ```prism
/// WithHeight: fn Gn, Nat -> Gn
/// ```
pub fn with_height(g: &crate::lower::node_::Gn, h: &Nat) -> crate::lower::node_::Gn {
    let mut this: crate::lower::node_::Gn = g.clone();
    this.height = h.clone();
    this
}

/// ```prism
/// RowHears: fn Wx -> [Text]
/// ```
pub fn row_hears(wx: &crate::lower::node_::Wx) -> Array<Text> {
    let from_updated = fold(&filter(&wx.gns, &(|g: &crate::lower::node_::Gn| &g.kind == &crate::lower::node_::GnKind::GnUpdated)), &Array::new(), &(|acc: &Array<crate::lower::node_::Read>, g: &crate::lower::node_::Gn| crate::lower::node_::union_reads(acc, &reads_closed(&wx.dyn_reads, &g.reads))));
    let from_rows = fold(&wx.row_marks, &Array::new(), &(|acc: &Array<crate::lower::node_::Read>, rm: &crate::lower::node_::RowMarks| crate::lower::node_::union_reads(acc, &reads_closed(&wx.dyn_reads, &append(&rm.reads, &each(&rm.wrote, &(|m: &Text| crate::lower::node_::Read::OwnRead(m.clone()))))))));
    fold(&crate::lower::node_::union_reads(&from_updated, &from_rows), &Array::new(), &(|acc: &Array<Text>, r: &crate::lower::node_::Read| match r {
        crate::lower::node_::Read::ParentRead(m) => crate::check::types::add_text(acc, m),
        crate::lower::node_::Read::OwnRead(_) => acc.clone(),
    }))
}

/// ```prism
/// RowWritten: fn Wx, RowMarks, Read -> [Do]
/// ```
pub fn row_written(wx: &crate::lower::node_::Wx, rm: &crate::lower::node_::RowMarks, r: &crate::lower::node_::Read) -> Array<crate::lower::model::Do> {
    let dirty = if crate::lower::node_::has_read(&reads_closed(&wx.dyn_reads, &rm.reads), r) {
        Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCx), Text::lit("dirty"), Array::from(vec![crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(Text::lit("row"))))])))])
    } else {
        Array::new()
    };
    let told = fold(&rm.wrote, &Array::new(), &(|acc: &Array<crate::lower::model::Do>, m: &Text| if crate::lower::node_::has_read(&reads_closed(&wx.dyn_reads, &Array::from(vec![crate::lower::node_::Read::OwnRead(m.clone())])), r) {
        push(acc, &crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("row"))), Text::from(format!("parent_wrote_{}", m)), Array::from(vec![crate::lower::model::Ex::XCx]))))
    } else {
        acc.clone()
    }));
    let body = append(&dirty, &told);
    if &len(&body) == &Nat::from(0u32) {
        Array::new()
    } else {
        match &rm.kind {
            crate::lower::model::RowKind::GenerationRow => Array::from(vec![crate::lower::model::Do::DoIfLet(crate::lower::model::Pa::PaCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("row"))])), crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), rm.builder.clone())), Text::lit("borrow"), Array::new())), Text::lit("as_ref"), Array::new()), body.clone(), Array::new())]),
            _ => Array::from(vec![crate::lower::model::Do::DoFor(crate::lower::model::Pa::PaBind(Text::lit("row")), crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), rm.builder.clone())), Text::lit("borrow"), Array::new())), Text::lit("values"), Array::new()), body.clone())]),
        }
    }
}

/// ```prism
/// PatchPlace: fn Wx, Place -> [Do]
/// ```
pub fn patch_place(wx: &crate::lower::node_::Wx, p_: &crate::lower::node_::Place) -> Array<crate::lower::model::Do> {
    let pull = crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(p_.getter.clone()), crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XSelf), p_.getter.clone(), Array::from(vec![crate::lower::model::Ex::XCx])));
    let at_ = place_at(wx, &Text::lit("self"), &p_.pos);
    Array::from(vec![pull.clone(), crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCx), Text::lit("changed"), Array::from(vec![at_.clone(), crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(p_.getter.clone())), Text::lit("to_pod"), Array::new())])))])
}

/// ```prism
/// Emits: fn Wx, Pos -> Bool
/// ```
pub fn emits(wx: &crate::lower::node_::Wx, pos: &crate::lower::model::Pos_) -> bool {
    (&pos.scope == &Nat::from(0u32)) && (&wx.hosted_by == &None)
}

/// ```prism
/// ResultTold: fn Ex -> [Do]
/// ```
pub fn result_told(node_: &crate::lower::model::Ex) -> Array<crate::lower::model::Do> {
    let r = crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(Text::lit("r")), crate::lower::model::Ex::XMethod(Rc::new(node_.clone()), Text::lit("result_value"), Array::from(vec![crate::lower::model::Ex::XCx])));
    Array::from(vec![r.clone(), result_kept(node_), result_tell()])
}

/// ```prism
/// ResultMoved: fn Ex -> [Do]
/// ```
pub fn result_moved(node_: &crate::lower::model::Ex) -> Array<crate::lower::model::Do> {
    let r = crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(Text::lit("r")), crate::lower::model::Ex::XMethod(Rc::new(node_.clone()), Text::lit("result_value"), Array::from(vec![crate::lower::model::Ex::XCx])));
    let last = crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(node_.clone()), Text::lit("result_last"))), Text::lit("borrow"), Array::new())), Text::lit("as_ref"), Array::new());
    let differs = crate::lower::model::Ex::XBin(Text::lit("!="), Rc::new(last.clone()), Rc::new(crate::lower::model::Ex::XCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XVar(Text::lit("r"))))]))));
    Array::from(vec![r.clone(), crate::lower::model::Do::DoIf(differs.clone(), Array::from(vec![result_kept(node_), result_tell()]), Array::new())])
}

/// ```prism
/// ResultKept: fn Ex -> Do
/// ```
pub fn result_kept(node_: &crate::lower::model::Ex) -> crate::lower::model::Do {
    crate::lower::model::Do::DoAssign(crate::lower::model::Ex::XDeref(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(node_.clone()), Text::lit("result_last"))), Text::lit("borrow_mut"), Array::new()))), crate::lower::model::Ex::XCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(Text::lit("r"))))])))
}

/// ```prism
/// let resultTell
/// ```
pub fn result_tell() -> crate::lower::model::Do {
    crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCx), Text::lit("result"), Array::from(vec![crate::lower::model::Ex::XCtor(Text::lit("Outcome::Value"), Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("r"))]))])))
}

/// ```prism
/// Adoption: fn FlatDef -> [Do]
/// ```
pub fn adoption(fl: &crate::lower::node_::FlatDef) -> Array<crate::lower::model::Do> {
    let adopt = crate::lower::model::Ex::XLater(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("node"))), Text::from(format!("{}_adopt", &fl.name)), Array::from(vec![crate::lower::model::Ex::XCx]))));
    Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(Text::lit("node")), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XSelf))), crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCx), Text::lit("answer_later"), Array::from(vec![adopt.clone()])))])
}

/// ```prism
/// PlaceAt: fn Wx, Text, Pos -> Ex
/// ```
pub fn place_at(wx: &crate::lower::node_::Wx, recv: &Text, pos: &crate::lower::model::Pos_) -> crate::lower::model::Ex {
    let at_ = Array::from(vec![crate::lower::model::Ex::XIndex(pos.at.clone())]);
    if emits(wx, pos) {
        crate::lower::model::Ex::XMethod(Rc::new(if recv == &Text::lit("") {
            crate::lower::model::Ex::XVar(Text::lit("path"))
        } else {
            if recv == &Text::lit("self") {
                crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::lit("path"))
            } else {
                crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XVar(recv.clone())), Text::lit("path"))
            }
        }), Text::lit("at"), at_.clone())
    } else {
        crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCall(Text::lit("Path::root"), Array::new())), Text::lit("at"), at_.clone())
    }
}

/// ```prism
/// PosPat: fn Pos, [Pa] -> Pa
/// ```
pub fn pos_pat(pos: &crate::lower::model::Pos_, tail: &Array<crate::lower::model::Pa>) -> crate::lower::model::Pa {
    crate::lower::model::Pa::PaSlice(append(&Array::from(vec![crate::lower::model::Pa::PaCtor(Text::lit("Segment::Pos"), Array::from(vec![crate::lower::model::Pa::PaIndex(pos.at.clone())]))]), tail))
}

/// ```prism
/// let keyTail
/// ```
pub fn key_tail() -> Array<crate::lower::model::Pa> {
    Array::from(vec![crate::lower::model::Pa::PaCtor(Text::lit("Segment::Key"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("k"))])), crate::lower::model::Pa::PaRest(Text::lit("rest"))])
}

/// ```prism
/// let genTail
/// ```
pub fn gen_tail() -> Array<crate::lower::model::Pa> {
    Array::from(vec![crate::lower::model::Pa::PaCtor(Text::lit("Segment::Gen"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("g"))])), crate::lower::model::Pa::PaRest(Text::lit("rest"))])
}

/// ```prism
/// ?HostedRows: fn Wx -> ?Text
/// ```
pub fn hosted_rows(wx: &crate::lower::node_::Wx) -> Option<Text> {
    if &wx.pos.scope > &Nat::from(0u32) {
        Some(Text::from(format!("{}_moved", &or(&index(&wx.scopes, &crate::syntax::lexer::chars::dec(&wx.pos.scope)), &Text::lit("")))))
    } else {
        match &wx.hosted_by {
            Some(_) => Some(Text::lit("document_moved")),
            None => None,
        }
    }
}

/// ```prism
/// RootDynPatch: fn Wx -> [Do]
/// ```
pub fn root_dyn_patch(wx: &crate::lower::node_::Wx) -> Array<crate::lower::model::Do> {
    match &wx.root_dyn {
        Some(_) => Array::from(vec![crate::lower::model::Do::DoLine(result_moved(&crate::lower::model::Ex::XSelf))]),
        None => Array::new(),
    }
}

/// ```prism
/// AnswerArm: fn Wx, Pos, Nat, OutTy -> ((Pa, Ex))
/// ```
pub fn answer_arm(wx: &crate::lower::node_::Wx, pos: &crate::lower::model::Pos_, id: &Nat, t: &crate::lower::model::OutTy) -> (crate::lower::model::Pa, crate::lower::model::Ex) {
    let call = crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XSelf), crate::lower::node_::gn_of(wx, id).name.clone(), Array::from(vec![crate::lower::model::Ex::XDecode(t.clone(), Rc::new(crate::lower::model::Ex::XVar(Text::lit("v")))), crate::lower::model::Ex::XCx]));
    (pos_pat(pos, &Array::new()), call.clone())
}

/// ```prism
/// TypedAnswerArm: fn Wx, Pos, Nat, Text -> ((Pa, [Do]))
/// ```
pub fn typed_answer_arm(wx: &crate::lower::node_::Wx, pos: &crate::lower::model::Pos_, id: &Nat, acc: &Text) -> (crate::lower::model::Pa, Array<crate::lower::model::Do>) {
    (pos_pat(pos, &Array::new()), Array::from(vec![self_call(&crate::lower::node_::gn_of(wx, id).name, &Array::from(vec![crate::lower::expr::try_of(&crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("v"))), acc.clone(), Array::new()))]))]))
}

/// ```prism
/// TypedDynArm: fn Sinks, Pos, Text, Text -> ((Pa, [Do]))
/// ```
pub fn typed_dyn_arm(sk: &Sinks, pos: &crate::lower::model::Pos_, f: &Text, acc: &Text) -> (crate::lower::model::Pa, Array<crate::lower::model::Do>) {
    (pos_pat(pos, &Array::new()), dyn_place_write(sk, f, &crate::lower::expr::try_of(&crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("v"))), acc.clone(), Array::new()))))
}

/// ```prism
/// TypedForwardArm: fn ForDef, Ex -> ((Pa, [Do]))
/// ```
pub fn typed_forward_arm(b: &crate::lower::model::ForDef, segs: &crate::lower::model::Ex) -> (crate::lower::model::Pa, Array<crate::lower::model::Do>) {
    let row_of = crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", &b.name)))), Text::lit("borrow"), Array::new())), Text::lit("get"), Array::from(vec![crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XDecode(b.key_ty.clone(), Rc::new(crate::lower::model::Ex::XVar(Text::lit("k"))))))]))), Text::lit("cloned"), Array::new());
    (pos_pat(&b.pos, &key_tail()), Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(Text::lit("row")), row_of.clone()), crate::lower::model::Do::DoMatch(crate::lower::model::Ex::XVar(Text::lit("row")), Array::from(vec![(crate::lower::model::Pa::PaCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("row"))])), Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::expr::try_of(&crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("row"))), Text::lit("deliver"), Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("rest")), crate::lower::model::Ex::XVar(Text::lit("v")), crate::lower::model::Ex::XCx]))))])), (crate::lower::model::Pa::PaUnit(Text::lit("None")), Array::from(vec![crate::lower::model::Do::DoReturn(crate::lower::model::Ex::XCtor(Text::lit("Err"), Array::from(vec![crate::lower::model::Ex::XCall(Text::lit("Fault::answer"), Array::from(vec![crate::lower::model::Ex::XFormatStr(Array::from(vec![crate::lower::model::Ex::XText(Text::lit("no row ")), crate::lower::model::Ex::XVar(Text::lit("k")), crate::lower::model::Ex::XText(Text::lit(" under the hosted place ")), crate::lower::model::Ex::XCtor(Text::lit("Path"), Array::from(vec![crate::lower::model::Ex::XMethod(Rc::new(segs.clone()), Text::lit("to_vec"), Array::new())]))]))]))])))]))]))]))
}

/// ```prism
/// TypedGenArm: fn GenDef -> ((Pa, [Do]))
/// ```
pub fn typed_gen_arm(gd: &crate::lower::model::GenDef) -> (crate::lower::model::Pa, Array<crate::lower::model::Do>) {
    let current = crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", &gd.name)))), Text::lit("borrow"), Array::new())));
    let is_current = crate::lower::model::Ex::XBin(Text::lit("=="), Rc::new(crate::lower::model::Ex::XBin(Text::lit("+"), Rc::new(crate::lower::model::Ex::XDeref(Rc::new(crate::lower::model::Ex::XVar(Text::lit("g"))))), Rc::new(crate::lower::model::Ex::XIndex(Nat::from(1u32))))), Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_count", &gd.name)))), Text::lit("get"), Array::new())));
    (pos_pat(&gd.pos, &gen_tail()), Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(Text::lit("row")), current.clone()), crate::lower::model::Do::DoIfLet(crate::lower::model::Pa::PaCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("row"))])), crate::lower::model::Ex::XVar(Text::lit("row")), Array::from(vec![crate::lower::model::Do::DoIf(is_current.clone(), Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::expr::try_of(&crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("row"))), Text::lit("deliver"), Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("rest")), crate::lower::model::Ex::XVar(Text::lit("v")), crate::lower::model::Ex::XCx]))))]), Array::new())]), Array::new())]))
}

/// ```prism
/// TypedDispatch: fn Sinks, Text, Nat -> MethDef
/// ```
pub fn typed_dispatch(sk: &Sinks, name: &Text, scope: &Nat) -> crate::lower::model::MethDef {
    let wx = sk.wx.clone();
    let in_scope_fn = {
        let scope = scope.clone();
        Rc::new(move |p_: &crate::lower::model::Pos_| &p_.scope == &scope)
    };
    let (recv, param, segs, doc) = if scope > &Nat::from(0u32) {
        (crate::lower::model::Recv::RecvRc, (Text::lit("place"), crate::lower::model::OutTy::OutRef(Rc::new(crate::lower::model::OutTy::OutPath))), crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("place"))), Text::lit("segments"), Array::new()), Text::from(format!("The host at place {} answers its child\'s place `place` (pick HO): into the child\'s input method, a hold the place\'s element answers, or the row of a `for` or `rebuild` under it.", &crate::lower::model::place_text(&or(&index(&wx.hosts, &crate::syntax::lexer::chars::dec(scope)), &dummy_host()).pos))))
    } else {
        (crate::lower::model::Recv::RecvOwned, (Text::lit("at"), crate::lower::model::OutTy::OutRef(Rc::new(crate::lower::model::OutTy::OutSlice(Rc::new(crate::lower::model::OutTy::OutNamed(Text::lit("Segment"), Array::new())))))), crate::lower::model::Ex::XVar(Text::lit("at")), Text::lit("A host\'s answer to a place of this row\'s own, `at` under the row (pick HO): into the input method, a hold, or a row under it."))
    };
    let answers = each(&filter(&wx.answers, &(|(pos, _, _, _): &(crate::lower::model::Pos_, Nat, crate::lower::model::OutTy, Text)| (&in_scope_fn)(pos))), &(|(pos, id, _, acc): &(crate::lower::model::Pos_, Nat, crate::lower::model::OutTy, Text)| typed_answer_arm(&wx, pos, id, acc)));
    let dyns = each(&filter(&wx.dyn_places, &(|(pos, _, _, _): &(crate::lower::model::Pos_, Text, crate::lower::model::OutTy, Text)| (&in_scope_fn)(pos))), &(|(pos, f, _, acc): &(crate::lower::model::Pos_, Text, crate::lower::model::OutTy, Text)| typed_dyn_arm(sk, pos, f, acc)));
    let rows = each(&filter(&wx.builders, &(|b: &crate::lower::model::ForDef| (&in_scope_fn)(&b.pos))), &(|b: &crate::lower::model::ForDef| typed_forward_arm(b, &segs)));
    let gens = each(&filter(&wx.gens, &(|gd: &crate::lower::model::GenDef| (&in_scope_fn)(&gd.pos))), &(|gd: &crate::lower::model::GenDef| typed_gen_arm(gd)));
    let none = (crate::lower::model::Pa::PaWild, Array::from(vec![crate::lower::model::Do::DoReturn(crate::lower::model::Ex::XCtor(Text::lit("Err"), Array::from(vec![crate::lower::model::Ex::XCall(Text::lit("Fault::answer"), Array::from(vec![crate::lower::model::Ex::XFormatStr(Array::from(vec![crate::lower::model::Ex::XText(Text::lit("no hosted place at ")), crate::lower::model::Ex::XCtor(Text::lit("Path"), Array::from(vec![crate::lower::model::Ex::XMethod(Rc::new(segs.clone()), Text::lit("to_vec"), Array::new())])), crate::lower::model::Ex::XText(Text::lit(" to answer"))]))]))])))]));
    let arms = push(&append(&append(&append(&answers, &dyns), &rows), &gens), &none);
    crate::lower::model::MethDef { name: name.clone(), recv: recv.clone(), params: Array::from(vec![param.clone(), (Text::lit("v"), crate::lower::model::OutTy::OutRef(Rc::new(crate::lower::types::answer_ty())))]), cx_: crate::lower::model::CxArg::CxMut, ret: crate::lower::model::OutTy::OutNamed(Text::lit("Done"), Array::new()), body: Array::from(vec![crate::lower::model::Do::DoMatch(segs.clone(), arms.clone())]), tail: crate::lower::model::Ex::XCtor(Text::lit("Ok"), Array::from(vec![crate::lower::model::Ex::XUnit])), doc: doc.clone() }
}

/// ```prism
/// let dummyHost
/// ```
pub fn dummy_host() -> crate::lower::node_::HostDef {
    crate::lower::node_::HostDef { pos: crate::lower::model::pos0(), name: Text::lit(""), scope: Nat::from(0u32) }
}

/// ```prism
/// SortNats: fn [Nat] -> [Nat]
/// ```
pub fn sort_nats(xs: &Array<Nat>) -> Array<Nat> {
    fold(xs, &Array::new(), &(|acc: &Array<Nat>, x: &Nat| append(&push(&filter(acc, &(|y: &Nat| y < x)), x), &filter(acc, &(|y: &Nat| !(y < x))))))
}

/// ```prism
/// AskWake: fn Sinks, Nat -> [Do]
/// ```
pub fn ask_wake(sk: &Sinks, h: &Nat) -> Array<crate::lower::model::Do> {
    let c = crate::lower::model::Ex::XConst(wake_const(&sk.heights, h));
    let ask_ = crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::lit("wakes"))), Text::lit("ask"), Array::from(vec![c.clone()])));
    let wake = crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCx), Text::lit("wake"), Array::from(vec![c.clone(), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XSelf))])));
    if sk.many {
        Array::from(vec![ask_.clone(), wake.clone()])
    } else {
        Array::from(vec![wake.clone()])
    }
}

/// ```prism
/// GatherIn: fn Sinks, Gn -> MethDef
/// ```
pub fn gather_in(sk: &Sinks, g: &crate::lower::node_::Gn) -> crate::lower::model::MethDef {
    let field_ = or(&index(&g.inputs, &Nat::from(0u32)), &Text::lit(""));
    let kt = match &g.ty {
        crate::lower::model::OutTy::OutMap(k, _) => (**k).clone(),
        _ => crate::lower::model::OutTy::OutUnit,
    };
    let vt = match &g.ty {
        crate::lower::model::OutTy::OutMap(_, v_) => (**v_).clone(),
        _ => crate::lower::model::OutTy::OutUnit,
    };
    let current = crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", &field_)))), Text::lit("get"), Array::from(vec![crate::lower::model::Ex::XCx]))), Text::lit("unwrap_or_default"), Array::new());
    let collect = Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaMut(Text::lit("all")), current.clone()), crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("all"))), Text::lit("insert"), Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("k")), crate::lower::model::Ex::XVar(Text::lit("v"))]))), crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", &field_)))), Text::lit("set"), Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("all")), crate::lower::model::Ex::XCx])))]);
    let body = append(&collect, &ask_wake(sk, &g.height));
    crate::lower::model::MethDef { name: Text::from(format!("{}_in", &g.name)), recv: crate::lower::model::Recv::RecvRc, params: Array::from(vec![(Text::lit("k"), kt.clone()), (Text::lit("v"), vt.clone())]), cx_: crate::lower::model::CxArg::CxMut, ret: crate::lower::model::OutTy::OutUnit, body: body.clone(), tail: crate::lower::model::Ex::XUnit, doc: Text::lit("A row\'s firing, gathered by its key.") }
}

/// ```prism
/// Decide: fn Gn -> Do
/// ```
pub fn decide(g: &crate::lower::node_::Gn) -> crate::lower::model::Do {
    match &g.kind {
        crate::lower::node_::GnKind::GnGather => crate::lower::model::Do::DoIfLet(crate::lower::model::Pa::PaCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("v"))])), crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", &or(&index(&g.inputs, &Nat::from(0u32)), &Text::lit("")))))), Text::lit("take"), Array::from(vec![crate::lower::model::Ex::XCx])), Array::from(vec![self_call(&g.name, &Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("v"))]))]), Array::new()),
        crate::lower::node_::GnKind::GnMerge => merge_decide(g),
        crate::lower::node_::GnKind::GnUpdated => updated_decide(g),
        crate::lower::node_::GnKind::GnMergeAll => {
            let pushes = each(&g.inputs, &(|f: &Text| crate::lower::model::Do::DoIfLet(crate::lower::model::Pa::PaCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("x"))])), crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", f)))), Text::lit("take"), Array::from(vec![crate::lower::model::Ex::XCx])), Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("all"))), Text::lit("push_back"), Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("x"))])))]), Array::new())));
            let start = crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaMut(Text::lit("all"))), g.ty.clone()), crate::lower::model::Ex::XCall(Text::lit("Array::new"), Array::new()));
            let fire = crate::lower::model::Do::DoIf(crate::lower::model::Ex::XUnary(Text::lit("!"), Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("all"))), Text::lit("is_empty"), Array::new()))), Array::from(vec![self_call(&g.name, &Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("all"))]))]), Array::new());
            crate::lower::model::Do::DoBlock(push(&append(&Array::from(vec![start.clone()]), &pushes), &fire))
        },
        kind => pair_decide(g, kind),
    }
}

/// ```prism
/// UpdatedDecide: fn Gn -> Do
/// ```
pub fn updated_decide(g: &crate::lower::node_::Gn) -> crate::lower::model::Do {
    crate::lower::model::Do::DoIf(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_moved", &g.name)))), Text::lit("replace"), Array::from(vec![crate::lower::model::Ex::XBool(false)])), Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(Text::lit("after")), crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCx), Text::lit("after"), Array::from(vec![crate::lower::model::Ex::XClosure(false, Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("cx"))]), Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_value", &g.name)), Array::from(vec![crate::lower::model::Ex::XCx]))))]))), self_call(&g.name, &Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("after"))]))]), Array::new())
}

/// ```prism
/// PairDecide: fn Gn, GnKind -> Do
/// ```
pub fn pair_decide(g: &crate::lower::node_::Gn, kind: &crate::lower::node_::GnKind) -> crate::lower::model::Do {
    let get_l = crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", &or(&index(&g.inputs, &Nat::from(0u32)), &Text::lit("")))))), Text::lit("take"), Array::from(vec![crate::lower::model::Ex::XCx]));
    let get_r = crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", &or(&index(&g.inputs, &Nat::from(1u32)), &Text::lit("")))))), Text::lit("take"), Array::from(vec![crate::lower::model::Ex::XCx]));
    let both_ = crate::lower::model::Ex::XTuple(Array::from(vec![get_l.clone(), get_r.clone()]));
    let fire_fn = {
        let g = g.clone();
        Rc::new(move |x: &crate::lower::model::Ex| Array::from(vec![self_call(&g.name, &Array::from(vec![x.clone()]))]))
    };
    let sa = crate::lower::model::Pa::PaCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("a"))]));
    let sb = crate::lower::model::Pa::PaCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("b"))]));
    let some2 = crate::lower::model::Pa::PaTuple(Array::from(vec![sa.clone(), sb.clone()]));
    let left = crate::lower::model::Pa::PaTuple(Array::from(vec![sa.clone(), crate::lower::model::Pa::PaUnit(Text::lit("None"))]));
    let right = crate::lower::model::Pa::PaTuple(Array::from(vec![crate::lower::model::Pa::PaUnit(Text::lit("None")), sb.clone()]));
    let cases = match kind {
        crate::lower::node_::GnKind::GnUnion => Array::from(vec![(some2.clone(), (&fire_fn)(&crate::lower::model::Ex::XCall(Text::lit("union"), Array::from(vec![crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XVar(Text::lit("a")))), crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XVar(Text::lit("b"))))])))), (left.clone(), (&fire_fn)(&crate::lower::model::Ex::XVar(Text::lit("a")))), (right.clone(), (&fire_fn)(&crate::lower::model::Ex::XVar(Text::lit("b")))), (crate::lower::model::Pa::PaWild, Array::new())]),
        crate::lower::node_::GnKind::GnBoth => Array::from(vec![(some2.clone(), (&fire_fn)(&crate::lower::model::Ex::XTuple(Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("a")), crate::lower::model::Ex::XVar(Text::lit("b"))])))), (crate::lower::model::Pa::PaWild, Array::new())]),
        _ => Array::from(vec![(left.clone(), (&fire_fn)(&crate::lower::model::Ex::XVar(Text::lit("a")))), (crate::lower::model::Pa::PaWild, Array::new())]),
    };
    crate::lower::model::Do::DoMatch(both_.clone(), cases.clone())
}

/// ```prism
/// WakeByHeight: fn [Gn], [Nat] -> Do
/// ```
pub fn wake_by_height(combs: &Array<crate::lower::node_::Gn>, heights_: &Array<Nat>) -> crate::lower::model::Do {
    crate::lower::model::Do::DoMatch(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::lit("wakes"))), Text::lit("next"), Array::new()), push(&each(heights_, &(|h: &Nat| (crate::lower::model::Pa::PaConst(wake_const(heights_, h)), each(&filter(combs, &(|g: &crate::lower::node_::Gn| &g.height == h)), &(|g: &crate::lower::node_::Gn| decide(g)))))), &(crate::lower::model::Pa::PaWild, Array::new())))
}

/// ```prism
/// ForwardAnswer: fn ForDef -> Ex
/// ```
pub fn forward_answer(b: &crate::lower::model::ForDef) -> crate::lower::model::Ex {
    let row_of = crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", &b.name)))), Text::lit("borrow"), Array::new())), Text::lit("get"), Array::from(vec![crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XDecode(b.key_ty.clone(), Rc::new(crate::lower::model::Ex::XVar(Text::lit("k"))))))]))), Text::lit("cloned"), Array::new());
    crate::lower::model::Ex::XBlock(Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(Text::lit("row")), row_of.clone()), crate::lower::model::Do::DoIfLet(crate::lower::model::Pa::PaCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("row"))])), crate::lower::model::Ex::XVar(Text::lit("row")), Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::expr::try_of(&crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("row"))), Text::lit("answer"), Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("rest")), crate::lower::model::Ex::XVar(Text::lit("v")), crate::lower::model::Ex::XCx]))))]), Array::new())]), Rc::new(crate::lower::model::Ex::XUnit))
}

/// ```prism
/// IsHold: fn OutTy -> Bool
/// ```
pub fn is_hold(out_ty0: &crate::lower::model::OutTy) -> bool {
    match out_ty0 {
        crate::lower::model::OutTy::OutHold(_) => true,
        other => false,
    }
}

/// ```prism
/// RowMethods: fn Wx -> [MethDef]
/// ```
pub fn row_methods(wx: &crate::lower::node_::Wx) -> Array<crate::lower::model::MethDef> {
    let removes = each(&filter(&wx.places, &(|p_: &crate::lower::node_::Place| emits(wx, &p_.pos))), &(|p_: &crate::lower::node_::Place| crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCx), Text::lit("removed"), Array::from(vec![place_at(wx, &Text::lit("self"), &p_.pos)])))));
    let nested = append(&each(&wx.builders, &(|b: &crate::lower::model::ForDef| crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), b.name.clone())), Text::lit("borrow"), Array::new())), Text::lit("values"), Array::new())), Text::lit("for_each"), Array::from(vec![crate::lower::model::Ex::XClosure(false, Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("row"))]), Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("row"))), Text::lit("leave_row"), Array::from(vec![crate::lower::model::Ex::XCx]))))]))))), &each(&wx.gens, &(|gd: &crate::lower::model::GenDef| crate::lower::model::Do::DoIfLet(crate::lower::model::Pa::PaCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("row"))])), crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), gd.name.clone())), Text::lit("borrow"), Array::new())), Text::lit("as_ref"), Array::new()), Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("row"))), Text::lit("leave_row"), Array::from(vec![crate::lower::model::Ex::XCx])))]), Array::new()))));
    Array::from(vec![crate::lower::model::MethDef { name: Text::lit("remove_places"), recv: crate::lower::model::Recv::RecvRef, params: Array::new(), cx_: crate::lower::model::CxArg::CxMut, ret: crate::lower::model::OutTy::OutUnit, body: append(&removes, &nested), tail: crate::lower::model::Ex::XUnit, doc: Text::lit("The row left: its places are torn down.") }])
}

/// ```prism
/// GnDoc: fn Gn -> Text
/// ```
pub fn gn_doc(g: &crate::lower::node_::Gn) -> Text {
    match &g.kind {
        crate::lower::node_::GnKind::GnAnswer => Text::from(format!("`{}`: an answer at its place.", &g.name)),
        crate::lower::node_::GnKind::GnStarted => Text::lit("`@started`, the tick after the build."),
        crate::lower::node_::GnKind::GnDeferred => Text::lit("An `@Defer` firing, the tick after it was armed."),
        crate::lower::node_::GnKind::GnMerge => Text::from(format!("The merge `{}`, decided in the wake.", &g.name)),
        crate::lower::node_::GnKind::GnUpdated => Text::lit("`!Updated`: the dynamic\'s value after the tick, fired in the wake when a hold it reads was written (or a structural dynamic it reads was published, pick ST)."),
        _ => Text::from(format!("`!{}`.", &g.name)),
    }
}

/// ```prism
/// MergeDecide: fn Gn -> Do
/// ```
pub fn merge_decide(g: &crate::lower::node_::Gn) -> crate::lower::model::Do {
    let call = Array::from(vec![self_call(&g.name, &Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("v"))]))]);
    let take_l = crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(Text::lit("left")), crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", &or(&index(&g.inputs, &Nat::from(0u32)), &Text::lit("")))))), Text::lit("take"), Array::from(vec![crate::lower::model::Ex::XCx])));
    let take_r = crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(Text::lit("right")), crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", &or(&index(&g.inputs, &Nat::from(1u32)), &Text::lit("")))))), Text::lit("take"), Array::from(vec![crate::lower::model::Ex::XCx])));
    let right = crate::lower::model::Do::DoIfLet(crate::lower::model::Pa::PaCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("v"))])), crate::lower::model::Ex::XVar(Text::lit("right")), call.clone(), Array::new());
    crate::lower::model::Do::DoBlock(Array::from(vec![take_l.clone(), take_r.clone(), crate::lower::model::Do::DoIfLet(crate::lower::model::Pa::PaCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("v"))])), crate::lower::model::Ex::XVar(Text::lit("left")), call.clone(), Array::from(vec![right.clone()]))]))
}
