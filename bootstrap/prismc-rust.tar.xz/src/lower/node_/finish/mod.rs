//! The module `Lower.Node.Finish`, from `target/bootstrap/src/prismc/lower/node/finish.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file. The runtime
//! side is reached from the crate, `crate::prelude` (and through it `::prism_rtl`), the
//! standard library from `::std`, and nothing is imported by name: a program's own type
//! (`Row`, `Option`) hides none of theirs. The traits are in scope unnamed, for their methods.

use crate::prelude::traits::*;

/// `Sinks`:
///
/// ```prism
/// type Sinks = record:
/// ```
#[derive(::std::clone::Clone)]
pub struct Sinks {
    pub wx_p: crate::lower::node_::Wx,
    pub dirty_p: crate::prelude::Array<crate::lower::node_::Read>,
    pub builds_p: crate::prelude::Array<crate::lower::node_::Read>,
    pub combs_p: crate::prelude::Array<crate::lower::node_::Gn>,
}

/// ```prism
/// Heights: fn [Gn] -> [Gn]
/// ```
pub fn heights_f(gns_p0: &crate::prelude::Array<crate::lower::node_::Gn>) -> crate::prelude::Array<crate::lower::node_::Gn> {
    crate::prelude::fold(gns_p0, gns_p0, &(|cur_p1: &crate::prelude::Array<crate::lower::node_::Gn>, _: &crate::lower::node_::Gn| crate::prelude::each(cur_p1, &(|n_p2: &crate::lower::node_::Gn| height_step_f(cur_p1, n_p2)))))
}

/// ```prism
/// HeightStep: fn [Gn], Gn -> Gn
/// ```
pub fn height_step_f(gns_p0: &crate::prelude::Array<crate::lower::node_::Gn>, n_p1: &crate::lower::node_::Gn) -> crate::lower::node_::Gn {
    let feeders_p2 = crate::prelude::filter(gns_p0, &(|m_p5: &crate::lower::node_::Gn| crate::prelude::fold(&m_p5.outs_p, &false, &(|f_p6: &bool, o_p7: &crate::lower::node_::Out| *f_p6 || feeds_f(&o_p7.sink_p, n_p1)))));
    let top_p3 = crate::prelude::fold(&feeders_p2, &crate::prelude::Nat::from(0u32), &(|hi_p8: &crate::prelude::Nat, m_p9: &crate::lower::node_::Gn| crate::prelude::max(hi_p8, &m_p9.height_p)));
    let h_p4 = match &n_p1.kind_p {
        crate::lower::node_::GnKind::GnNamed => top_p3.clone(),
        kind_pa => if is_comb_f(kind_pa) {
            crate::prelude::max(&(&top_p3 + &crate::prelude::Nat::from(1u32)), &n_p1.floor_p)
        } else {
            n_p1.height_p.clone()
        },
    };
    let mut this: crate::lower::node_::Gn = n_p1.clone();
    this.height_p = h_p4.clone();
    this
}

/// ```prism
/// IsComb: fn GnKind -> Bool
/// ```
pub fn is_comb_f(k_p0: &crate::lower::node_::GnKind) -> bool {
    match k_p0 {
        crate::lower::node_::GnKind::GnMerge => true,
        crate::lower::node_::GnKind::GnUnion => true,
        crate::lower::node_::GnKind::GnBoth => true,
        crate::lower::node_::GnKind::GnExcept => true,
        crate::lower::node_::GnKind::GnMergeAll => true,
        crate::lower::node_::GnKind::GnUpdated => true,
        _ => false,
    }
}

/// ```prism
/// Feeds: fn Sk, Gn -> Bool
/// ```
pub fn feeds_f(sk0: &crate::lower::node_::Sk, n_p1: &crate::lower::node_::Gn) -> bool {
    match sk0 {
        crate::lower::node_::Sk::SkNode(m_p0) => m_p0 == &n_p1.id_p,
        crate::lower::node_::Sk::SkIn(m_p2, _) => m_p2 == &n_p1.id_p,
        crate::lower::node_::Sk::SkCycle(_, _, m_p4) => m_p4 == &n_p1.id_p,
        crate::lower::node_::Sk::SkMachine(f_p6, _, m_p7) => (m_p7 == &n_p1.id_p) || writes_f(f_p6, n_p1),
        crate::lower::node_::Sk::SkHold(f_p9) => writes_f(f_p9, n_p1),
        crate::lower::node_::Sk::SkDistinct(f_pb) => writes_f(f_pb, n_p1),
        crate::lower::node_::Sk::SkPerKey(f_pd) => writes_f(f_pd, n_p1),
        other_pf => false,
    }
}

/// ```prism
/// Writes: fn Text, Gn -> Bool
/// ```
pub fn writes_f(f_p0: &crate::prelude::Text, n_p1: &crate::lower::node_::Gn) -> bool {
    moves_f(&crate::lower::node_::Read::OwnRead(f_p0.clone()), n_p1)
}

/// ```prism
/// Moves: fn Read, Gn -> Bool
/// ```
pub fn moves_f(r_p0: &crate::lower::node_::Read, n_p1: &crate::lower::node_::Gn) -> bool {
    (&n_p1.kind_p == &crate::lower::node_::GnKind::GnUpdated) && crate::lower::node_::has_read_f(&n_p1.reads_p, r_p0)
}

/// ```prism
/// ReadsClosed: fn (Text ==> [Read]), [Read] -> [Read]
/// ```
pub fn reads_closed_f(dyn_p0: &crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::lower::node_::Read>>, reads_p1: &crate::prelude::Array<crate::lower::node_::Read>) -> crate::prelude::Array<crate::lower::node_::Read> {
    crate::prelude::fold(&crate::check::errors::range0_f(&crate::prelude::Nat::from(4u32)), reads_p1, &(|acc_p2: &crate::prelude::Array<crate::lower::node_::Read>, _: &crate::prelude::Nat| crate::prelude::fold(acc_p2, acc_p2, &(|a_p3: &crate::prelude::Array<crate::lower::node_::Read>, r_p4: &crate::lower::node_::Read| crate::lower::node_::union_reads_f(a_p3, &getter_reads_f(dyn_p0, r_p4))))))
}

/// ```prism
/// GetterReads: fn (Text ==> [Read]), Read -> [Read]
/// ```
pub fn getter_reads_f(dyn_p0: &crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::lower::node_::Read>>, read1: &crate::lower::node_::Read) -> crate::prelude::Array<crate::lower::node_::Read> {
    match read1 {
        crate::lower::node_::Read::OwnRead(n_p1) => crate::prelude::or(&crate::prelude::get(dyn_p0, n_p1), &crate::prelude::Array::new()),
        crate::lower::node_::Read::ParentRead(_) => crate::prelude::Array::new(),
    }
}

/// ```prism
/// ReachesSnap: fn [Text], [Read] -> Bool
/// ```
pub fn reaches_snap_f(roots_p0: &crate::prelude::Array<crate::prelude::Text>, reads_p1: &crate::prelude::Array<crate::lower::node_::Read>) -> bool {
    crate::prelude::fold(reads_p1, &false, &(|f_p2: &bool, r_p3: &crate::lower::node_::Read| *f_p2 || match r_p3 {
        crate::lower::node_::Read::OwnRead(n_p4) => crate::check::types::has_text_f(roots_p0, n_p4),
        crate::lower::node_::Read::ParentRead(_) => false,
    }))
}

/// ```prism
/// SnapNames: fn Wx -> [Text]
/// ```
pub fn snap_names_f(wx_p0: &crate::lower::node_::Wx) -> crate::prelude::Array<crate::prelude::Text> {
    crate::prelude::each(&wx_p0.snaps_p, &(|sn_p1: &crate::lower::node_::SnapDef| sn_p1.name_p.clone()))
}

/// ```prism
/// SelfCall: fn Text, [Ex] -> Do
/// ```
pub fn self_call_f(m_p0: &crate::prelude::Text, args_p1: &crate::prelude::Array<crate::lower::model::Ex>) -> crate::lower::model::Do {
    crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), m_p0.clone(), crate::prelude::push(args_p1, &crate::lower::model::Ex::XCx)))
}

/// ```prism
/// RequestCode: fn Sinks, Pos, Text, Ex -> [Do]
/// ```
pub fn request_code_f(sk_p0: &Sinks, pos_p1: &crate::lower::model::Pos, field_p2: &crate::prelude::Text, y_p3: &crate::lower::model::Ex) -> crate::prelude::Array<crate::lower::model::Do> {
    let field_ex_p4 = if field_p2 == &crate::prelude::Text::lit("") {
        crate::lower::model::Ex::XNone
    } else {
        crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Some")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XStr(field_p2.clone())]))
    };
    if emits_f(&sk_p0.wx_p, pos_p1) {
        crate::prelude::Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XCx), crate::prelude::Text::lit("request"), crate::prelude::Array::from(vec![place_at_f(&sk_p0.wx_p, &crate::prelude::Text::lit("self"), pos_p1), field_ex_p4.clone(), crate::lower::model::Ex::XMethod(::std::rc::Rc::new(y_p3.clone()), crate::prelude::Text::lit("to_pod"), crate::prelude::Array::new())])))])
    } else {
        crate::prelude::Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("requested")), crate::lower::model::Ex::XMethod(::std::rc::Rc::new(host_field_ex_f(&sk_p0.wx_p, pos_p1)), if &pos_p1.scope_p == &crate::prelude::Nat::from(0u32) {
            crate::prelude::Text::lit("request_from")
        } else {
            crate::prelude::Text::lit("request")
        }, crate::prelude::Array::from(vec![crate::lower::model::Ex::XRef(::std::rc::Rc::new(place_at_f(&sk_p0.wx_p, &crate::prelude::Text::lit("self"), pos_p1))), field_ex_p4.clone(), crate::lower::model::Ex::XMethod(::std::rc::Rc::new(y_p3.clone()), crate::prelude::Text::lit("to_pod"), crate::prelude::Array::new()), crate::lower::model::Ex::XCx]))), crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XCx), crate::prelude::Text::lit("keep"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XVar(crate::prelude::Text::lit("requested"))])))])
    }
}

/// ```prism
/// SinkCode: fn Sinks, Sk, Ex -> [Do]
/// ```
pub fn sink_code_f(sk_p0: &Sinks, target_p1: &crate::lower::node_::Sk, y_p2: &crate::lower::model::Ex) -> crate::prelude::Array<crate::lower::model::Do> {
    match target_p1 {
        crate::lower::node_::Sk::SkNode(m_p3) => crate::prelude::Array::from(vec![self_call_f(&crate::lower::node_::gn_of_f(&sk_p0.wx_p, m_p3).name_p, &crate::prelude::Array::from(vec![y_p2.clone()]))]),
        crate::lower::node_::Sk::SkIn(m_p4, i_p5) => {
            let g_p6 = crate::lower::node_::gn_of_f(&sk_p0.wx_p, m_p4);
            crate::prelude::append(&crate::prelude::Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::from(format!("{}", &crate::prelude::or(&crate::prelude::index(&g_p6.inputs_p, i_p5), &crate::prelude::Text::lit("")))))), crate::prelude::Text::lit("set"), crate::prelude::Array::from(vec![y_p2.clone(), crate::lower::model::Ex::XCx])))]), &ask_wake_f(sk_p0, &g_p6))
        },
        crate::lower::node_::Sk::SkHold(f_p7) => crate::prelude::append(&crate::prelude::Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::from(format!("{}", f_p7)))), crate::prelude::Text::lit("set"), crate::prelude::Array::from(vec![y_p2.clone(), crate::lower::model::Ex::XCx])))]), &hold_written_f(sk_p0, f_p7)),
        crate::lower::node_::Sk::SkDistinct(f_p8) => {
            let differs_p9 = crate::lower::model::Ex::XBin(crate::lower::model::BinOp::OpNe, ::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::from(format!("{}", f_p8)))), crate::prelude::Text::lit("get"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx]))), ::std::rc::Rc::new(crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Some")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XClone(::std::rc::Rc::new(y_p2.clone()))]))));
            let write_pa = crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::from(format!("{}", f_p8)))), crate::prelude::Text::lit("set"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Some")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XClone(::std::rc::Rc::new(y_p2.clone()))])), crate::lower::model::Ex::XCx])));
            crate::prelude::Array::from(vec![crate::lower::model::Do::DoIf(differs_p9.clone(), crate::prelude::append(&crate::prelude::Array::from(vec![write_pa.clone()]), &hold_written_f(sk_p0, f_p8)), crate::prelude::Array::new())])
        },
        crate::lower::node_::Sk::SkPerKey(f_pb) => crate::prelude::Array::from(vec![crate::lower::model::Do::DoIf(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::from(format!("{}", f_pb)))), crate::prelude::Text::lit("written"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XClone(::std::rc::Rc::new(y_p2.clone())), crate::lower::model::Ex::XCx])), hold_written_f(sk_p0, f_pb), crate::prelude::Array::new())]),
        crate::lower::node_::Sk::SkRequest(pos_pc, field_pd) => request_code_f(sk_p0, pos_pc, field_pd, y_p2),
        crate::lower::node_::Sk::SkResult => crate::prelude::Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XCx), crate::prelude::Text::lit("result"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Outcome::Fired")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XMethod(::std::rc::Rc::new(y_p2.clone()), crate::prelude::Text::lit("to_pod"), crate::prelude::Array::new())]))])))]),
        crate::lower::node_::Sk::SkArm(f_pe) => crate::prelude::Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::from(format!("{}", f_pe)))), crate::prelude::Text::lit("arm"), crate::prelude::Array::from(vec![y_p2.clone(), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XSelf)), crate::lower::model::Ex::XCx])))]),
        crate::lower::node_::Sk::SkLater(f_pf) => crate::prelude::Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), f_pf.clone())), crate::prelude::Text::lit("queue"), crate::prelude::Array::from(vec![y_p2.clone()])))]),
        crate::lower::node_::Sk::SkMachine(f_pg, step_ph, out_pi) => {
            let stepped_pj = crate::lower::model::Ex::XApply(::std::rc::Rc::new(step_ph.clone()), crate::prelude::Array::from(vec![crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), f_pg.clone())), crate::prelude::Text::lit("get"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx])))), crate::lower::model::Ex::XRef(::std::rc::Rc::new(y_p2.clone()))]));
            crate::prelude::append(&crate::prelude::Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTuple(crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("machine_s")), crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("machine_b"))])), stepped_pj.clone()), crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::from(format!("{}", f_pg)))), crate::prelude::Text::lit("set"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XVar(crate::prelude::Text::lit("machine_s")), crate::lower::model::Ex::XCx]))), crate::lower::model::Do::DoIfLet(crate::lower::model::Pa::PaCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Some")), crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("machine_b"))])), crate::lower::model::Ex::XVar(crate::prelude::Text::lit("machine_b")), crate::prelude::Array::from(vec![self_call_f(&crate::lower::node_::gn_of_f(&sk_p0.wx_p, out_pi).name_p, &crate::prelude::Array::from(vec![crate::lower::model::Ex::XVar(crate::prelude::Text::lit("machine_b"))]))]), crate::prelude::Array::new())]), &moved_marks_f(sk_p0, f_pg))
        },
        crate::lower::node_::Sk::SkPort(f_pk) => crate::prelude::Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XCall(crate::lower::helper_ref_f(&crate::prelude::Text::lit("no_fault")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::from(format!("{}_port", f_pk)))), crate::prelude::Text::lit("fire"), crate::prelude::Array::from(vec![y_p2.clone(), crate::lower::model::Ex::XCx]))])))]),
        crate::lower::node_::Sk::SkUp(m_pl) => {
            let keyed_pm = &crate::prelude::len(&crate::prelude::filter(&sk_p0.wx_p.fields_p, &(|(f_po, _, _): &(crate::prelude::Text, crate::lower::model::OutTy, crate::prelude::Text)| f_po == &crate::prelude::Text::lit("key")))) > &crate::prelude::Nat::from(0u32);
            let args_pn = if keyed_pm {
                crate::prelude::Array::from(vec![crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::lit("key")))), y_p2.clone(), crate::lower::model::Ex::XCx])
            } else {
                crate::prelude::Array::from(vec![y_p2.clone(), crate::lower::model::Ex::XCx])
            };
            crate::prelude::Array::from(vec![crate::lower::model::Do::DoIfLet(crate::lower::model::Pa::PaCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Some")), crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("parent"))])), crate::lower::model::Ex::XUpgrade(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::lit("parent")))), crate::prelude::Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("parent"))), m_pl.clone(), args_pn.clone()))]), crate::prelude::Array::new())])
        },
        crate::lower::node_::Sk::SkCycle(job_pp, again_pq, res_pr) => {
            let more_ps = crate::prelude::Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::from(format!("{}", job_pp)))), crate::prelude::Text::lit("set"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XVar(crate::prelude::Text::lit("next")), crate::lower::model::Ex::XCx]))), crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::from(format!("{}", again_pq)))), crate::prelude::Text::lit("arm"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XUnit, crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XSelf)), crate::lower::model::Ex::XCx])))]);
            let fin_pt = crate::prelude::Array::from(vec![self_call_f(&crate::lower::node_::gn_of_f(&sk_p0.wx_p, res_pr).name_p, &crate::prelude::Array::from(vec![crate::lower::model::Ex::XVar(crate::prelude::Text::lit("b"))]))]);
            crate::prelude::Array::from(vec![crate::lower::model::Do::DoMatch(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::from(format!("{}", job_pp)))), crate::prelude::Text::lit("get"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx]))), crate::prelude::Text::lit("cycle"), crate::prelude::Array::new()), crate::prelude::Array::from(vec![(crate::lower::model::Pa::PaCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("prism_rtl::Turn::More")), crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("next"))])), more_ps.clone()), (crate::lower::model::Pa::PaCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("prism_rtl::Turn::Finished")), crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("b"))])), fin_pt.clone())]))])
        },
    }
}

/// ```prism
/// SinkAbove: fn Sinks, Sk, Ex -> [Do]
/// ```
pub fn sink_above_f(sk_p0: &Sinks, target_p1: &crate::lower::node_::Sk, h_p2: &crate::lower::model::Ex) -> crate::prelude::Array<crate::lower::model::Do> {
    match target_p1 {
        crate::lower::node_::Sk::SkNode(m_p3) => crate::prelude::Array::from(vec![above_call_f(&crate::lower::model::Ex::XSelf, &crate::lower::node_::gn_of_f(&sk_p0.wx_p, m_p3).name_p, h_p2)]),
        crate::lower::node_::Sk::SkIn(m_p4, _) => combinator_above_f(sk_p0, &crate::lower::node_::gn_of_f(&sk_p0.wx_p, m_p4), h_p2),
        crate::lower::node_::Sk::SkHold(f_p5) => hold_above_f(sk_p0, f_p5, h_p2),
        crate::lower::node_::Sk::SkDistinct(f_p6) => hold_above_f(sk_p0, f_p6, h_p2),
        crate::lower::node_::Sk::SkPerKey(f_p7) => hold_above_f(sk_p0, f_p7, h_p2),
        crate::lower::node_::Sk::SkRequest(pos_p8, _) => if emits_f(&sk_p0.wx_p, pos_p8) {
            crate::prelude::Array::new()
        } else {
            crate::prelude::Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(host_field_ex_f(&sk_p0.wx_p, pos_p8)), crate::prelude::Text::lit("request_above"), crate::prelude::Array::from(vec![h_p2.clone()])))])
        },
        crate::lower::node_::Sk::SkResult => crate::prelude::Array::new(),
        crate::lower::node_::Sk::SkArm(_) => crate::prelude::Array::new(),
        crate::lower::node_::Sk::SkLater(_) => crate::prelude::Array::new(),
        crate::lower::node_::Sk::SkMachine(f_p9, _, out_pa) => crate::prelude::push(&moved_above_f(sk_p0, &crate::lower::node_::Read::OwnRead(f_p9.clone()), h_p2), &above_call_f(&crate::lower::model::Ex::XSelf, &crate::lower::node_::gn_of_f(&sk_p0.wx_p, out_pa).name_p, h_p2)),
        crate::lower::node_::Sk::SkPort(f_pb) => crate::prelude::Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::from(format!("{}_port", f_pb)))), crate::prelude::Text::lit("raise"), crate::prelude::Array::from(vec![h_p2.clone()])))]),
        crate::lower::node_::Sk::SkUp(m_pc) => crate::prelude::Array::from(vec![crate::lower::model::Do::DoIfLet(crate::lower::model::Pa::PaCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Some")), crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("parent"))])), crate::lower::model::Ex::XUpgrade(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::lit("parent")))), crate::prelude::Array::from(vec![above_call_f(&crate::lower::model::Ex::XVar(crate::prelude::Text::lit("parent")), m_pc, h_p2)]), crate::prelude::Array::new())]),
        crate::lower::node_::Sk::SkCycle(_, _, res_pd) => crate::prelude::Array::from(vec![above_call_f(&crate::lower::model::Ex::XSelf, &crate::lower::node_::gn_of_f(&sk_p0.wx_p, res_pd).name_p, h_p2)]),
    }
}

/// ```prism
/// AboveCall: fn Ex, Text, Ex -> Do
/// ```
pub fn above_call_f(receiver_p0: &crate::lower::model::Ex, m_p1: &crate::prelude::Text, h_p2: &crate::lower::model::Ex) -> crate::lower::model::Do {
    crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(receiver_p0.clone()), crate::prelude::Text::from(format!("{}_above", m_p1)), crate::prelude::Array::from(vec![h_p2.clone()])))
}

/// ```prism
/// CombinatorAbove: fn Sinks, Gn, Ex -> [Do]
/// ```
pub fn combinator_above_f(sk_p0: &Sinks, g_p1: &crate::lower::node_::Gn, h_p2: &crate::lower::model::Ex) -> crate::prelude::Array<crate::lower::model::Do> {
    crate::prelude::Array::from(vec![crate::lower::model::Do::DoIfLet(crate::lower::model::Pa::PaCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Some")), crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("moved"))])), crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::lit("heights"))), crate::prelude::Text::lit("above"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XIndex(combinator_of_f(&sk_p0.combs_p, g_p1)), h_p2.clone()])), crate::prelude::Array::from(vec![above_call_f(&crate::lower::model::Ex::XSelf, &g_p1.name_p, &crate::lower::model::Ex::XVar(crate::prelude::Text::lit("moved")))]), crate::prelude::Array::new())])
}

/// ```prism
/// HoldAbove: fn Sinks, Text, Ex -> [Do]
/// ```
pub fn hold_above_f(sk_p0: &Sinks, f_p1: &crate::prelude::Text, h_p2: &crate::lower::model::Ex) -> crate::prelude::Array<crate::lower::model::Do> {
    crate::prelude::append(&crate::prelude::fold(&sk_p0.wx_p.row_marks_p, &crate::prelude::Array::new(), &(|acc_p3: &crate::prelude::Array<crate::lower::model::Do>, rm_p4: &crate::lower::node_::RowMarks| crate::prelude::append(acc_p3, &row_above_f(&sk_p0.wx_p, rm_p4, &crate::lower::node_::Read::OwnRead(f_p1.clone()), h_p2)))), &moved_above_f(sk_p0, &crate::lower::node_::Read::OwnRead(f_p1.clone()), h_p2))
}

/// ```prism
/// MovedAbove: fn Sinks, Read, Ex -> [Do]
/// ```
pub fn moved_above_f(sk_p0: &Sinks, r_p1: &crate::lower::node_::Read, h_p2: &crate::lower::model::Ex) -> crate::prelude::Array<crate::lower::model::Do> {
    crate::prelude::fold(&crate::prelude::filter(&sk_p0.wx_p.gns_p, &(|g_p3: &crate::lower::node_::Gn| moves_f(r_p1, g_p3))), &crate::prelude::Array::new(), &(|acc_p4: &crate::prelude::Array<crate::lower::model::Do>, g_p5: &crate::lower::node_::Gn| crate::prelude::append(acc_p4, &combinator_above_f(sk_p0, g_p5, h_p2))))
}

/// ```prism
/// RowAbove: fn Wx, RowMarks, Read, Ex -> [Do]
/// ```
pub fn row_above_f(wx_p0: &crate::lower::node_::Wx, rm_p1: &crate::lower::node_::RowMarks, r_p2: &crate::lower::node_::Read, h_p3: &crate::lower::model::Ex) -> crate::prelude::Array<crate::lower::model::Do> {
    let hit_p4 = crate::prelude::filter(&crate::prelude::append(&rm_p1.wrote_p, &rm_p1.builds_p), &(|m_p7: &crate::prelude::Text| crate::lower::node_::has_read_f(&reads_closed_f(&wx_p0.dyn_reads_p, &crate::prelude::Array::from(vec![crate::lower::node_::Read::OwnRead(m_p7.clone())])), r_p2)));
    let told_p5 = crate::prelude::each(&hit_p4, &(|m_p8: &crate::prelude::Text| above_call_f(&crate::lower::model::Ex::XVar(crate::prelude::Text::lit("row")), &crate::prelude::Text::from(format!("parent_wrote_{}", m_p8)), h_p3)));
    let raised_p6 = crate::prelude::each(&hit_p4, &(|m_p9: &crate::prelude::Text| crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::from(format!("{}_wrote_{}_port", &rm_p1.builder_p, m_p9)))), crate::prelude::Text::lit("raise"), crate::prelude::Array::from(vec![h_p3.clone()])))));
    match &rm_p1.kind_p {
        crate::lower::model::RowKind::GenerationRow => raised_p6.clone(),
        crate::lower::model::RowKind::ValueRow => raised_p6.clone(),
        _ => if &crate::prelude::len(&told_p5) == &crate::prelude::Nat::from(0u32) {
            crate::prelude::Array::new()
        } else {
            crate::prelude::Array::from(vec![crate::lower::model::Do::DoFor(crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("row")), crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), rm_p1.builder_p.clone())), crate::prelude::Text::lit("borrow"), crate::prelude::Array::new())), crate::prelude::Text::lit("values"), crate::prelude::Array::new()), told_p5.clone())])
        },
    }
}

/// ```prism
/// AboveMethod: fn Text, [Do], Text -> MethDef
/// ```
pub fn above_method_f(name_p0: &crate::prelude::Text, body_p1: &crate::prelude::Array<crate::lower::model::Do>, what_p2: &crate::prelude::Text) -> crate::lower::model::MethDef {
    crate::lower::model::MethDef { name_p: crate::prelude::Text::from(format!("{}_above", name_p0)), recv_p: crate::lower::model::Recv::RecvRc, params_p: crate::prelude::Array::from(vec![(crate::prelude::Text::lit("h"), crate::lower::model::OutTy::OutCount)]), cx_p: crate::lower::model::CxArg::CxNone, ret_p: crate::lower::model::OutTy::OutUnit, body_p: body_p1.clone(), tail_p: crate::lower::model::Ex::XUnit, doc_p: crate::prelude::Text::from(format!("The height twin of `{}`: {} at global height `h`; every combinator that reaches sits above `h`.", name_p0, what_p2)) }
}

/// ```prism
/// HoldWritten: fn Sinks, Text -> [Do]
/// ```
pub fn hold_written_f(sk_p0: &Sinks, f_p1: &crate::prelude::Text) -> crate::prelude::Array<crate::lower::model::Do> {
    let r_p2 = crate::lower::node_::Read::OwnRead(f_p1.clone());
    let read_by_place_p3 = crate::lower::node_::has_read_f(&sk_p0.dirty_p, &r_p2);
    let dirty_p4 = if read_by_place_p3 {
        crate::prelude::Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XCx), crate::prelude::Text::lit("dirty"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XSelf))])))])
    } else {
        crate::prelude::Array::new()
    };
    let told_p5 = crate::prelude::Array::new();
    let stales_p6 = crate::prelude::fold(&sk_p0.wx_p.gen_holds_p, &crate::prelude::Array::new(), &(|acc_pb: &crate::prelude::Array<crate::lower::model::Do>, (gname_pc, hs_pd): &(crate::prelude::Text, crate::prelude::Array<crate::lower::node_::Read>)| if crate::lower::node_::has_read_f(&reads_closed_f(&sk_p0.wx_p.dyn_reads_p, hs_pd), &r_p2) {
        crate::prelude::push(acc_pb, &crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::from(format!("{}_stale", gname_pc)))), crate::prelude::Text::lit("set"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XBool(true)]))))
    } else {
        acc_pb.clone()
    }));
    let row_marks_p7 = crate::prelude::fold(&sk_p0.wx_p.row_marks_p, &crate::prelude::Array::new(), &(|acc_pe: &crate::prelude::Array<crate::lower::model::Do>, rm_pf: &crate::lower::node_::RowMarks| crate::prelude::append(acc_pe, &row_written_f(&sk_p0.wx_p, rm_pf, &r_p2))));
    let builds_p8 = crate::lower::node_::has_read_f(&sk_p0.builds_p, &r_p2) || (&crate::prelude::len(&stales_p6) > &crate::prelude::Nat::from(0u32));
    let rebuild_it_p9 = if builds_p8 && !lists_build_f(sk_p0, &r_p2) {
        crate::prelude::append(&stales_p6, &crate::prelude::Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XCx), crate::prelude::Text::lit("build_later"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XSelf))])))]))
    } else {
        stales_p6.clone()
    };
    let gathered_pa = crate::prelude::fold(&sk_p0.wx_p.result_moved_p, &crate::prelude::Array::new(), &(|acc_pg: &crate::prelude::Array<crate::lower::model::Do>, (m_ph, rds_pi): &(crate::prelude::Text, crate::prelude::Array<crate::lower::node_::Read>)| if crate::lower::node_::has_read_f(rds_pi, &r_p2) {
        crate::prelude::push(acc_pg, &crate::lower::model::Do::DoIfLet(crate::lower::model::Pa::PaCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Some")), crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("parent"))])), crate::lower::model::Ex::XUpgrade(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::lit("parent")))), crate::prelude::Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("parent"))), m_ph.clone(), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx])))]), crate::prelude::Array::new()))
    } else {
        acc_pg.clone()
    }));
    crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&dirty_p4, &told_p5), &rebuild_it_p9), &row_marks_p7), &gathered_pa), &moved_marks_f(sk_p0, f_p1))
}

/// ```prism
/// HostFieldEx: fn Wx, Pos -> Ex
/// ```
pub fn host_field_ex_f(wx_p0: &crate::lower::node_::Wx, pos_p1: &crate::lower::model::Pos) -> crate::lower::model::Ex {
    crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::lower::node_::elements::host_local_f(wx_p0, pos_p1))
}

/// ```prism
/// MovedMarks: fn Sinks, Text -> [Do]
/// ```
pub fn moved_marks_f(sk_p0: &Sinks, f_p1: &crate::prelude::Text) -> crate::prelude::Array<crate::lower::model::Do> {
    moved_by_f(sk_p0, &crate::lower::node_::Read::OwnRead(f_p1.clone()))
}

/// ```prism
/// MovedBy: fn Sinks, Read -> [Do]
/// ```
pub fn moved_by_f(sk_p0: &Sinks, r_p1: &crate::lower::node_::Read) -> crate::prelude::Array<crate::lower::model::Do> {
    let moved_p2 = crate::prelude::filter(&sk_p0.wx_p.gns_p, &(|g_p8: &crate::lower::node_::Gn| moves_f(r_p1, g_p8)));
    let flags_p3 = crate::prelude::each(&moved_p2, &(|g_p9: &crate::lower::node_::Gn| crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::from(format!("{}_moved", &g_p9.name_p)))), crate::prelude::Text::lit("set"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XBool(true)])))));
    let marks_p4 = crate::prelude::each(&snaps_behind_f(&sk_p0.wx_p, r_p1), &(|sn_pa: &crate::lower::node_::SnapDef| crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::from(format!("{}_snap", &sn_pa.name_p)))), crate::prelude::Text::lit("mark"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx])))));
    let listed_p5 = if lists_build_f(sk_p0, r_p1) {
        crate::prelude::Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XCx), crate::prelude::Text::lit("build_later"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XSelf))])))])
    } else {
        crate::prelude::Array::new()
    };
    let answers_p6 = crate::prelude::each(&crate::prelude::filter(&sk_p0.wx_p.dyn_answers_p, &(|(_, rds_pb): &(crate::prelude::Text, crate::prelude::Array<crate::lower::node_::Read>)| crate::lower::node_::has_read_f(&reads_closed_f(&sk_p0.wx_p.dyn_reads_p, rds_pb), r_p1))), &(|(name_pc, _): &(crate::prelude::Text, crate::prelude::Array<crate::lower::node_::Read>)| {
        let fire_pd = crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XCall(crate::lower::helper_ref_f(&crate::prelude::Text::lit("no_fault")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::from(format!("{}_port", name_pc)))), crate::prelude::Text::lit("fire"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XUnit, crate::lower::model::Ex::XCx]))])));
        let stamp_pe = crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::from(format!("{}_once", name_pc)))), crate::prelude::Text::lit("set"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XUnit, crate::lower::model::Ex::XCx])));
        crate::lower::model::Do::DoIf(crate::lower::model::Ex::XUnary(crate::lower::model::UnOp::OpNot, ::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::from(format!("{}_once", name_pc)))), crate::prelude::Text::lit("fired"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx])))), crate::prelude::Array::from(vec![stamp_pe.clone(), fire_pd.clone()]), crate::prelude::Array::new())
    }));
    let adoptions_p7 = crate::prelude::each(&crate::prelude::filter(&sk_p0.wx_p.flattens_p, &(|fl_pf: &crate::lower::node_::FlatDef| (&fl_pf.generation_p != &crate::prelude::Text::lit("")) && (r_p1 == &crate::lower::node_::Read::OwnRead(fl_pf.outer_p.clone())))), &(|fl_pg: &crate::lower::node_::FlatDef| crate::lower::model::Do::DoScope(adoption_f(fl_pg))));
    crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&crate::prelude::fold(&moved_p2, &flags_p3, &(|acc_ph: &crate::prelude::Array<crate::lower::model::Do>, g_pi: &crate::lower::node_::Gn| crate::prelude::append(acc_ph, &ask_wake_f(sk_p0, g_pi)))), &marks_p4), &listed_p5), &answers_p6), &adoptions_p7), &source_marks_f(&sk_p0.wx_p, r_p1))
}

/// ```prism
/// SourceMarks: fn Wx, Read -> [Do]
/// ```
pub fn source_marks_f(wx_p0: &crate::lower::node_::Wx, r_p1: &crate::lower::node_::Read) -> crate::prelude::Array<crate::lower::model::Do> {
    let fors_p2 = crate::prelude::fold(&wx_p0.builders_p, &crate::prelude::Array::new(), &(|acc_p3: &crate::prelude::Array<crate::lower::model::Do>, b_p4: &crate::lower::model::ForDef| if crate::lower::node_::has_read_f(&reads_closed_f(&wx_p0.dyn_reads_p, &crate::prelude::or(&crate::prelude::get(&wx_p0.dyn_reads_p, &b_p4.source_p), &crate::prelude::Array::new())), r_p1) {
        crate::prelude::push(acc_p3, &crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::from(format!("{}_cache", &b_p4.source_p)))), crate::prelude::Text::lit("mark"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx]))))
    } else {
        acc_p3.clone()
    }));
    crate::prelude::fold(&wx_p0.let_caches_p, &fors_p2, &(|acc_p5: &crate::prelude::Array<crate::lower::model::Do>, c_p6: &crate::prelude::Text| if crate::lower::node_::has_read_f(&reads_all_f(&wx_p0.dyn_reads_p, &crate::prelude::or(&crate::prelude::get(&wx_p0.dyn_reads_p, c_p6), &crate::prelude::Array::new())), r_p1) {
        crate::prelude::push(acc_p5, &crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::from(format!("{}_cache", c_p6)))), crate::prelude::Text::lit("mark"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx]))))
    } else {
        acc_p5.clone()
    }))
}

/// ```prism
/// ReadsAll: fn (Text ==> [Read]), [Read] -> [Read]
/// ```
pub fn reads_all_f(dyn_p0: &crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::lower::node_::Read>>, reads_p1: &crate::prelude::Array<crate::lower::node_::Read>) -> crate::prelude::Array<crate::lower::node_::Read> {
    crate::prelude::fold(&crate::check::errors::range0_f(&(&crate::prelude::size(dyn_p0) + &crate::prelude::Nat::from(1u32))), reads_p1, &(|acc_p2: &crate::prelude::Array<crate::lower::node_::Read>, _: &crate::prelude::Nat| crate::prelude::fold(acc_p2, acc_p2, &(|a_p3: &crate::prelude::Array<crate::lower::node_::Read>, r_p4: &crate::lower::node_::Read| crate::lower::node_::union_reads_f(a_p3, &getter_reads_f(dyn_p0, r_p4))))))
}

/// ```prism
/// IsOwnRead: fn Read -> Bool
/// ```
pub fn is_own_read_f(r_p0: &crate::lower::node_::Read) -> bool {
    match r_p0 {
        crate::lower::node_::Read::OwnRead(_) => true,
        crate::lower::node_::Read::ParentRead(_) => false,
    }
}

/// ```prism
/// SnapsBehind: fn Wx, Read -> [SnapDef]
/// ```
pub fn snaps_behind_f(wx_p0: &crate::lower::node_::Wx, r_p1: &crate::lower::node_::Read) -> crate::prelude::Array<crate::lower::node_::SnapDef> {
    crate::prelude::filter(&wx_p0.snaps_p, &(|sn_p2: &crate::lower::node_::SnapDef| (r_p1 == &crate::lower::node_::Read::OwnRead(sn_p2.live_p.clone())) || crate::lower::node_::has_read_f(&reads_closed_f(&wx_p0.dyn_reads_p, &crate::prelude::Array::from(vec![crate::lower::node_::Read::OwnRead(sn_p2.live_p.clone())])), r_p1)))
}

/// ```prism
/// ListsBuild: fn Sinks, Read -> Bool
/// ```
pub fn lists_build_f(sk_p0: &Sinks, r_p1: &crate::lower::node_::Read) -> bool {
    &crate::prelude::len(&snaps_behind_f(&sk_p0.wx_p, r_p1)) > &crate::prelude::Nat::from(0u32)
}

/// ```prism
/// FiringCode: unbounded fn Sinks, Gn, Ex -> [Do]
/// ```
pub fn firing_code_f(sk_p0: &Sinks, g_p1: &crate::lower::node_::Gn, x_p2: &crate::lower::model::Ex) -> crate::prelude::Array<crate::lower::model::Do> {
    let many_p3 = (&crate::prelude::len(&g_p1.outs_p) > &crate::prelude::Nat::from(1u32)) && !crate::lower::types::is_copy_f(&g_p1.ty_p);
    let xv_p4 = if many_p3 {
        crate::lower::model::Ex::XClone(::std::rc::Rc::new(x_p2.clone()))
    } else {
        x_p2.clone()
    };
    crate::prelude::run_to_end(crate::prelude::fold_job(g_p1.outs_p.clone(), crate::prelude::Array::new(), {
        let xv_p4x = xv_p4.clone();
        let sk_p0x = sk_p0.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::lower::model::Do>, crate::lower::node_::Out)| {
            let xv_p4xy = xv_p4x.clone();
            let sk_p0xy = sk_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_p5 = p0;
                let o_p6 = p1;
                crate::prelude::call_value((&o_p6.pipe_f)((xv_p4xy.clone(), {
                    let sk_p0xyx = sk_p0xy.clone();
                    let o_p6x = o_p6.clone();
                    ::std::rc::Rc::new(move |p0: crate::lower::model::Ex| {
                        let sk_p0xyxy = sk_p0xyx.clone();
                        let o_p6xy = o_p6x.clone();
                        crate::prelude::once_job(move || {
                            let y_p7 = p0;
                            ::prism_rtl::Turn::Finished(sink_code_f(&sk_p0xyxy, &o_p6xy.sink_p, &y_p7))
                        })
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::Ex) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::lower::model::Do>>>>
                })), move |call_18082: crate::prelude::Array<crate::lower::model::Do>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_p5, &call_18082)))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::lower::model::Do>, crate::lower::node_::Out)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::lower::model::Do>>>>
    }))
}

/// The step machine of `FiringCode`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FiringCode: unbounded fn Sinks, Gn, Ex -> [Do]
/// ```
pub struct FiringCode {
    pub sk_p0: Sinks,
    pub g_p1: crate::lower::node_::Gn,
    pub x_p2: crate::lower::model::Ex,
}

impl ::prism_rtl::Job<crate::prelude::Array<crate::lower::model::Do>> for FiringCode {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<crate::lower::model::Do>> {
        let sk_p0 = &self.sk_p0;
        let g_p1 = &self.g_p1;
        let x_p2 = &self.x_p2;
        let many_p3 = (&crate::prelude::len(&g_p1.outs_p) > &crate::prelude::Nat::from(1u32)) && !crate::lower::types::is_copy_f(&g_p1.ty_p);
        let xv_p4 = if many_p3 {
            crate::lower::model::Ex::XClone(::std::rc::Rc::new(x_p2.clone()))
        } else {
            x_p2.clone()
        };
        crate::prelude::fold_job(g_p1.outs_p.clone(), crate::prelude::Array::new(), {
            let xv_p4x = xv_p4.clone();
            let sk_p0x = sk_p0.clone();
            ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::lower::model::Do>, crate::lower::node_::Out)| {
                let xv_p4xy = xv_p4x.clone();
                let sk_p0xy = sk_p0x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let acc_p5 = p0;
                    let o_p6 = p1;
                    crate::prelude::call_value((&o_p6.pipe_f)((xv_p4xy.clone(), {
                        let sk_p0xyx = sk_p0xy.clone();
                        let o_p6x = o_p6.clone();
                        ::std::rc::Rc::new(move |p0: crate::lower::model::Ex| {
                            let sk_p0xyxy = sk_p0xyx.clone();
                            let o_p6xy = o_p6x.clone();
                            crate::prelude::once_job(move || {
                                let y_p7 = p0;
                                ::prism_rtl::Turn::Finished(sink_code_f(&sk_p0xyxy, &o_p6xy.sink_p, &y_p7))
                            })
                        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::Ex) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::lower::model::Do>>>>
                    })), move |call_18082: crate::prelude::Array<crate::lower::model::Do>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_p5, &call_18082)))
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::lower::model::Do>, crate::lower::node_::Out)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::lower::model::Do>>>>
        }).cycle()
    }
}

/// `Start FiringCode, x`: what the function value is when passed to `@Run`.
pub fn start_firing_code_f(sk_p0: Sinks, g_p1: crate::lower::node_::Gn, x_p2: crate::lower::model::Ex) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::lower::model::Do>>> {
    ::std::rc::Rc::new(FiringCode { sk_p0, g_p1, x_p2 })
}

/// ```prism
/// FinishNode: unbounded fn Wx, Text, [((Text, OutTy))], Bool -> NodeDef
/// ```
pub fn finish_node_f(wx0_p0: &crate::lower::node_::Wx, qk_p1: &crate::prelude::Text, params_p2: &crate::prelude::Array<(crate::prelude::Text, crate::lower::model::OutTy)>, is_row_p3: &bool) -> crate::lower::model::NodeDef {
    let closed_gns_p4 = crate::prelude::each(&wx0_p0.gns_p, &(|g_p1v: &crate::lower::node_::Gn| if &g_p1v.kind_p == &crate::lower::node_::GnKind::GnUpdated {
        crate::lower::node_::dynamics::with_reads_f(g_p1v, &reads_closed_f(&wx0_p0.dyn_reads_p, &g_p1v.reads_p))
    } else {
        g_p1v.clone()
    }));
    let (row_defs_p20, gns2_p21) = finish_pending_f(wx0_p0, &heights_f(&closed_gns_p4));
    let is_gen_p5 = *is_row_p3 && (&crate::prelude::len(&crate::prelude::filter(&wx0_p0.fields_p, &(|(f_p22, _, _): &(crate::prelude::Text, crate::lower::model::OutTy, crate::prelude::Text)| f_p22 == &crate::prelude::Text::lit("key")))) == &crate::prelude::Nat::from(0u32));
    let wx_p6 = {
        let mut this: crate::lower::node_::Wx = wx0_p0.clone();
        this.gns_p = heights_f(&gns2_p21);
        this.build_p = crate::prelude::append(&this.build_p, &updated_gaps_f(wx0_p0, &closed_gns_p4));
        this.rows_p = crate::prelude::fold(&row_defs_p20, &this.rows_p, &(|acc_p23: &crate::prelude::Array<crate::lower::model::NodeDef>, rd_p24: &crate::lower::model::NodeDef| crate::prelude::append(&crate::prelude::push(acc_p23, rd_p24), &rd_p24.children_p)));
        this
    };
    let combs_p7 = crate::prelude::filter(&wx_p6.gns_p, &(|g_p25: &crate::lower::node_::Gn| (is_comb_f(&g_p25.kind_p) || (&g_p25.kind_p == &crate::lower::node_::GnKind::GnGather)) || (&g_p25.kind_p == &crate::lower::node_::GnKind::GnMergeList)));
    let wakes_p8 = &crate::prelude::len(&combs_p7) > &crate::prelude::Nat::from(0u32);
    let live_p9 = crate::prelude::filter(&wx_p6.places_p, &(|p_p26: &crate::lower::node_::Place| &p_p26.getter_p != &crate::prelude::Text::lit("")));
    let root_reads_pa = crate::prelude::fold(&wx_p6.root_dyns_p, &crate::prelude::Array::new(), &(|acc_p27: &crate::prelude::Array<crate::lower::node_::Read>, (_, rds_p28, _): &(crate::lower::model::Ex, crate::prelude::Array<crate::lower::node_::Read>, crate::lower::model::OutTy)| crate::lower::node_::union_reads_f(acc_p27, &reads_closed_f(&wx_p6.dyn_reads_p, rds_p28))));
    let dirty_holds_pb = crate::prelude::fold(&live_p9, &root_reads_pa, &(|acc_p29: &crate::prelude::Array<crate::lower::node_::Read>, p_p2a: &crate::lower::node_::Place| crate::lower::node_::union_reads_f(acc_p29, &reads_closed_f(&wx_p6.dyn_reads_p, &p_p2a.reads_p))));
    let build_holds_pc = reads_closed_f(&wx_p6.dyn_reads_p, &wx_p6.build_holds_p);
    let sinks_pd = Sinks { wx_p: wx_p6.clone(), dirty_p: dirty_holds_pb.clone(), builds_p: build_holds_pc.clone(), combs_p: combs_p7.clone() };
    let ev_methods_pe = crate::prelude::run_to_end(crate::prelude::each_job(crate::prelude::filter(&wx_p6.gns_p, &(|g_p2b: &crate::lower::node_::Gn| &g_p2b.kind_p != &crate::lower::node_::GnKind::GnNever)), {
        let sinks_pdx = sinks_pd.clone();
        ::std::rc::Rc::new(move |p0: crate::lower::node_::Gn| {
            let sinks_pdxy = sinks_pdx.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let g_p2c = p0;
                crate::prelude::call_then(start_firing_code_f(sinks_pdxy.clone(), g_p2c.clone(), crate::lower::model::Ex::XVar(crate::prelude::Text::lit("v"))), move |firing_code_f_19692: crate::prelude::Array<crate::lower::model::Do>| ::prism_rtl::Turn::Finished(crate::lower::model::MethDef { name_p: g_p2c.name_p.clone(), recv_p: crate::lower::model::Recv::RecvRc, params_p: crate::prelude::Array::from(vec![(crate::prelude::Text::lit("v"), g_p2c.ty_p.clone())]), cx_p: crate::lower::model::CxArg::CxMut, ret_p: crate::lower::model::OutTy::OutUnit, body_p: firing_code_f_19692, tail_p: crate::lower::model::Ex::XUnit, doc_p: gn_doc_f(&g_p2c) }))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::node_::Gn) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::MethDef>>>
    }));
    let gather_ins_pf = crate::prelude::append(&crate::prelude::each(&crate::prelude::filter(&wx_p6.gns_p, &(|g_p2d: &crate::lower::node_::Gn| &g_p2d.kind_p == &crate::lower::node_::GnKind::GnGather)), &(|g_p2e: &crate::lower::node_::Gn| gather_in_f(&sinks_pd, g_p2e))), &crate::prelude::each(&crate::prelude::filter(&wx_p6.gns_p, &(|g_p2f: &crate::lower::node_::Gn| &g_p2f.kind_p == &crate::lower::node_::GnKind::GnMergeList)), &(|g_p2g: &crate::lower::node_::Gn| merge_list_in_f(&sinks_pd, g_p2g))));
    let ev_above_pg = crate::prelude::each(&crate::prelude::filter(&wx_p6.gns_p, &(|g_p2h: &crate::lower::node_::Gn| &g_p2h.kind_p != &crate::lower::node_::GnKind::GnNever)), &(|g_p2i: &crate::lower::node_::Gn| above_method_f(&g_p2i.name_p, &crate::prelude::fold(&g_p2i.outs_p, &crate::prelude::Array::new(), &(|acc_p2j: &crate::prelude::Array<crate::lower::model::Do>, o_p2k: &crate::lower::node_::Out| crate::prelude::append(acc_p2j, &sink_above_f(&sinks_pd, &o_p2k.sink_p, &crate::lower::model::Ex::XVar(crate::prelude::Text::lit("h")))))), &crate::prelude::Text::from(format!("`!{}` fires", &g_p2i.name_p)))));
    let in_above_ph = crate::prelude::each(&crate::prelude::filter(&wx_p6.gns_p, &(|g_p2l: &crate::lower::node_::Gn| (&g_p2l.kind_p == &crate::lower::node_::GnKind::GnGather) || (&g_p2l.kind_p == &crate::lower::node_::GnKind::GnMergeList))), &(|g_p2m: &crate::lower::node_::Gn| above_method_f(&crate::prelude::Text::from(format!("{}_in", &g_p2m.name_p)), &combinator_above_f(&sinks_pd, g_p2m, &crate::lower::model::Ex::XVar(crate::prelude::Text::lit("h"))), &crate::prelude::Text::from(format!("an input of `{}` fires", &g_p2m.name_p)))));
    let announced_pi = crate::prelude::each(&combs_p7, &(|g_p2n: &crate::lower::node_::Gn| above_call_f(&crate::lower::model::Ex::XVar(crate::prelude::Text::lit("node")), &g_p2n.name_p, &crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("node"))), crate::prelude::Text::lit("heights"))), crate::prelude::Text::lit("of"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XIndex(combinator_of_f(&combs_p7, g_p2n))])))));
    let place_getters_pj = crate::prelude::each(&live_p9, &(|p_p2o: &crate::lower::node_::Place| crate::lower::model::MethDef { name_p: p_p2o.getter_p.clone(), recv_p: crate::lower::model::Recv::RecvRef, params_p: crate::prelude::Array::new(), cx_p: crate::lower::model::CxArg::CxRef, ret_p: crate::lower::types::elem_ty_p(), body_p: crate::prelude::Array::new(), tail_p: p_p2o.level_p.clone(), doc_p: crate::prelude::Text::from(format!("Place {}\'s level, read at the read point.", &crate::lower::model::place_text_f(&p_p2o.pos_p))) }));
    let wake_body_pk = if wakes_p8 {
        crate::prelude::Array::from(vec![wake_by_height_f(&combs_p7), crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::lit("heights"))), crate::prelude::Text::lit("again"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx, crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XSelf))])))])
    } else {
        crate::prelude::Array::new()
    };
    let started_body_pl = crate::prelude::each(&wx_p6.started_p, &(|st_p2p: &crate::prelude::Nat| self_call_f(&crate::lower::node_::gn_of_f(&wx_p6, st_p2p).name_p, &crate::prelude::Array::from(vec![crate::lower::model::Ex::XUnit]))));
    let deferred_body_pm = crate::prelude::each(&wx_p6.defers_p, &(|(f_p2q, id_p2r): &(crate::prelude::Text, crate::prelude::Nat)| crate::lower::model::Do::DoIfLet(crate::lower::model::Pa::PaCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Some")), crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("v"))])), crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::from(format!("{}", f_p2q)))), crate::prelude::Text::lit("fired"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx])), crate::prelude::Array::from(vec![self_call_f(&crate::lower::node_::gn_of_f(&wx_p6, id_p2r).name_p, &crate::prelude::Array::from(vec![crate::lower::model::Ex::XVar(crate::prelude::Text::lit("v"))]))]), crate::prelude::Array::new())));
    let patch_body0_pn = crate::prelude::fold(&live_p9, &crate::prelude::Array::new(), &(|acc_p2s: &crate::prelude::Array<crate::lower::model::Do>, p_p2t: &crate::lower::node_::Place| crate::prelude::append(acc_p2s, &(if emits_f(&wx_p6, &p_p2t.pos_p) {
        patch_place_f(&wx_p6, p_p2t)
    } else {
        crate::prelude::Array::from(vec![entry_take_f(&crate::lower::model::Ex::XSelf, p_p2t)])
    }))));
    let patch_body_po = crate::prelude::append(&patch_body0_pn, &root_dyn_patch_f(&wx_p6));
    let build_steps_pp = build_steps_f(&sinks_pd, &false);
    let build_body_pq = if (&wx_p6.gen_of_p == &crate::prelude::Text::lit("")) || (&crate::prelude::len(&build_steps_pp) == &crate::prelude::Nat::from(0u32)) {
        build_steps_pp.clone()
    } else {
        crate::prelude::Array::from(vec![crate::lower::model::Do::DoIf(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::lit("current"), crate::prelude::Array::new()), build_steps_pp.clone(), crate::prelude::Array::new())])
    };
    let push_body0_pr = crate::prelude::each(&crate::prelude::filter(&wx_p6.dyn_places_p, &(|(pos_p2u, _, _, _): &(crate::lower::model::Pos, crate::prelude::Text, crate::lower::model::OutTy, crate::prelude::Text)| emits_f(&wx_p6, pos_p2u))), &(|(pos_p2v, f_p30, t_p31, _): &(crate::lower::model::Pos, crate::prelude::Text, crate::lower::model::OutTy, crate::prelude::Text)| crate::lower::model::Do::DoIf(crate::lower::model::Ex::XBin(crate::lower::model::BinOp::OpEq, ::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("element"))), ::std::rc::Rc::new(crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::from(format!("{}_element", f_p30))))))), dyn_place_write_f(&sinks_pd, f_p30, &crate::lower::model::Ex::XDecode(t_p31.clone(), ::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("v"))))), crate::prelude::Array::new())));
    let push_body_ps = crate::prelude::append(&push_body0_pr, &crate::prelude::each(&crate::prelude::filter(&wx_p6.bundles_p, &(|bp_p32: &crate::lower::node_::BundlePlace| (&bp_p32.stem_p != &crate::prelude::Text::lit("")) && emits_f(&wx_p6, &bp_p32.pos_p))), &(|bp_p33: &crate::lower::node_::BundlePlace| crate::lower::model::Do::DoIf(crate::lower::model::Ex::XBin(crate::lower::model::BinOp::OpEq, ::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("element"))), ::std::rc::Rc::new(crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::from(format!("{}_element", &bp_p33.stem_p))))))), bundle_state_write_f(&sinks_pd, bp_p33, &crate::lower::model::Ex::XDecode(bp_p33.state_ty_p.clone(), ::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("v"))))), crate::prelude::Array::new()))));
    let hooks_pt = crate::prelude::filter(&crate::prelude::Array::from(vec![(crate::prelude::Text::lit("wake"), wake_body_pk.clone()), (crate::prelude::Text::lit("started"), started_body_pl.clone()), (crate::prelude::Text::lit("deferred"), deferred_body_pm.clone()), (crate::prelude::Text::lit("build"), build_body_pq.clone()), (crate::prelude::Text::lit("swap"), crate::lower::node_::switch_::swap_body_f(&wx_p6)), (crate::prelude::Text::lit("push"), push_body_ps.clone()), (crate::prelude::Text::lit("patch"), patch_body_po.clone())]), &(|(_, b_p34): &(crate::prelude::Text, crate::prelude::Array<crate::lower::model::Do>)| &crate::prelude::len(b_p34) > &crate::prelude::Nat::from(0u32)));
    let started_reg_pu = if &crate::prelude::len(&wx_p6.started_p) > &crate::prelude::Nat::from(0u32) {
        crate::prelude::Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XCx), crate::prelude::Text::lit("on_started"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("node"))))])))])
    } else {
        crate::prelude::Array::new()
    };
    let links_pv = crate::prelude::each(&wx_p6.hosts_p, &(|h_p35: &crate::lower::node_::HostDef| crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("node"))), crate::prelude::Text::from(format!("{}", &h_p35.name_p)))), crate::prelude::Text::lit("link"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("node"))))])))));
    let rows_built_p10 = crate::prelude::append(&links_pv, &build_steps_f(&sinks_pd, &true));
    let subscribed_p11 = crate::prelude::each(&wx_p6.subs_p, &(|(ev_p36, m_p37, t_p38): &(crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy)| crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XCall(crate::lower::helper_ref_f(&crate::prelude::Text::lit("subscribe_row")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("node")))), crate::lower::model::Ex::XUpgrade(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("node"))), crate::prelude::Text::lit("parent")))), crate::lower::model::Ex::XClosure(false, crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("p"))]), ::std::rc::Rc::new(crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("p"))), crate::prelude::Text::from(format!("{}_port", ev_p36))))))), crate::lower::model::Ex::XClosure(false, crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("n")), crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("v")), crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("cx"))]), ::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("n"))), m_p37.clone(), crate::prelude::Array::from(vec![crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("v")))), crate::lower::model::Ex::XCx])))), heard_above_f(m_p37), crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("node"))), crate::prelude::Text::from(format!("{}_sub", m_p37)))))])))));
    let answers0_p12 = crate::prelude::append(&crate::prelude::each(&crate::prelude::filter(&wx_p6.answers_p, &(|(pos_p39, _, _, _): &(crate::lower::model::Pos, crate::prelude::Nat, crate::lower::model::OutTy, crate::prelude::Text)| emits_f(&wx_p6, pos_p39))), &(|(pos_p3a, id_p3b, t_p3c, _): &(crate::lower::model::Pos, crate::prelude::Nat, crate::lower::model::OutTy, crate::prelude::Text)| answer_arm_f(&wx_p6, pos_p3a, id_p3b, t_p3c))), &crate::prelude::each(&crate::prelude::filter(&wx_p6.dyn_places_p, &(|(pos_p3d, _, _, _): &(crate::lower::model::Pos, crate::prelude::Text, crate::lower::model::OutTy, crate::prelude::Text)| emits_f(&wx_p6, pos_p3d) && !crate::prelude::fold(&wx_p6.answers_p, &false, &(|seen_p3e: &bool, (apos_p3f, _, _, _): &(crate::lower::model::Pos, crate::prelude::Nat, crate::lower::model::OutTy, crate::prelude::Text)| *seen_p3e || (apos_p3f == pos_p3d))))), &(|(pos_p3g, f_p3h, t_p3i, _): &(crate::lower::model::Pos, crate::prelude::Text, crate::lower::model::OutTy, crate::prelude::Text)| dyn_answer_arm_f(&sinks_pd, pos_p3g, f_p3h, t_p3i))));
    let answers_p13 = crate::prelude::append(&answers0_p12, &crate::prelude::each(&crate::prelude::filter(&wx_p6.bundles_p, &(|bp_p3j: &crate::lower::node_::BundlePlace| emits_f(&wx_p6, &bp_p3j.pos_p) && ((&crate::prelude::len(&bp_p3j.events_p) > &crate::prelude::Nat::from(0u32)) || (&bp_p3j.stem_p != &crate::prelude::Text::lit(""))))), &(|bp_p3k: &crate::lower::node_::BundlePlace| bundle_answer_arm_f(&sinks_pd, bp_p3k))));
    let forwards_p14 = crate::prelude::append(&crate::prelude::each(&crate::prelude::filter(&wx_p6.builders_p, &(|b_p3l: &crate::lower::model::ForDef| emits_f(&wx_p6, &b_p3l.pos_p))), &(|b_p3m: &crate::lower::model::ForDef| (pos_pat_f(&b_p3m.pos_p, &key_tail_p()), forward_answer_f(b_p3m)))), &crate::prelude::fold(&crate::prelude::filter(&wx_p6.gens_p, &(|gd_p3n: &crate::lower::model::GenDef| emits_f(&wx_p6, &gd_p3n.pos_p))), &crate::prelude::Array::new(), &(|acc_p3o: &crate::prelude::Array<(crate::lower::model::Pa, crate::lower::model::Ex)>, gd_p3p: &crate::lower::model::GenDef| crate::prelude::append(acc_p3o, &crate::lower::node_::switch_::gen_forwards_f(gd_p3p)))));
    let host_methods_p15 = crate::prelude::run_to_end(crate::prelude::fold_job(wx_p6.hosts_p.clone(), crate::prelude::Array::new(), {
        let sinks_pdx = sinks_pd.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::lower::model::MethDef>, crate::lower::node_::HostDef)| {
            let sinks_pdxy = sinks_pdx.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_p3q = p0;
                let h_p3r = p1;
                crate::prelude::call_then(start_typed_dispatch_f(sinks_pdxy.clone(), crate::prelude::Text::from(format!("{}_answer", &h_p3r.name_p)), h_p3r.scope_p.clone()), move |typed_dispatch_f_25031: crate::lower::model::MethDef| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_p3q, &crate::prelude::Array::from(vec![typed_dispatch_f_25031, host_moved_f(&sinks_pdxy, &h_p3r)]))))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::lower::model::MethDef>, crate::lower::node_::HostDef)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::lower::model::MethDef>>>>
    }));
    let gathered_p16 = crate::prelude::filter(&wx_p6.snaps_p, &(|sn_p3s: &crate::lower::node_::SnapDef| !(sn_p3s.before_p || is_generation_f(&wx_p6, &sn_p3s.builder_p))));
    let gathered_moved_p17 = crate::prelude::append(&crate::prelude::append(&crate::prelude::each(&gathered_p16, &(|sn_p3t: &crate::lower::node_::SnapDef| gathered_moved_f(sn_p3t))), &crate::prelude::each(&wx_p6.snaps_p, &(|sn_p3u: &crate::lower::node_::SnapDef| snap_publish_f(&sinks_pd, sn_p3u)))), &flatten_methods_f(&sinks_pd));
    let hosted_methods_p18 = match &wx_p6.hosted_by_o {
        ::std::option::Option::Some(_) => crate::prelude::Array::from(vec![typed_dispatch_f(&sinks_pd, &crate::prelude::Text::lit("deliver"), &crate::prelude::Nat::from(0u32)), document_getter_f(&wx_p6)]),
        ::std::option::Option::None => crate::prelude::Array::new(),
    };
    let moved_method_p19 = match &wx_p6.hosted_by_o {
        ::std::option::Option::Some(m_p3v) => crate::prelude::Array::from(vec![document_moved_f(m_p3v)]),
        ::std::option::Option::None => crate::prelude::Array::new(),
    };
    let row_methods_p1a = if *is_row_p3 { row_methods_f(&wx_p6) } else { crate::prelude::Array::new() };
    let heard_build_f1b = {
        let wx_p6x = wx_p6.clone();
        let sinks_pdx = sinks_pd.clone();
        ::std::rc::Rc::new(move |m_p40: &crate::prelude::Text| {
            let stales_p41 = crate::prelude::fold(&wx_p6x.gen_holds_p, &crate::prelude::Array::new(), &(|acc_p43: &crate::prelude::Array<crate::lower::model::Do>, (gname_p44, hs_p45): &(crate::prelude::Text, crate::prelude::Array<crate::lower::node_::Read>)| if crate::lower::node_::has_read_f(&reads_closed_f(&wx_p6x.dyn_reads_p, hs_p45), &crate::lower::node_::Read::ParentRead(m_p40.clone())) {
                crate::prelude::push(acc_p43, &crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::from(format!("{}_stale", gname_p44)))), crate::prelude::Text::lit("set"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XBool(true)]))))
            } else {
                acc_p43.clone()
            }));
            let builds_p42 = crate::lower::node_::has_read_f(&sinks_pdx.builds_p, &crate::lower::node_::Read::ParentRead(m_p40.clone())) || (&crate::prelude::len(&stales_p41) > &crate::prelude::Nat::from(0u32));
            if builds_p42 && !lists_build_f(&sinks_pdx, &crate::lower::node_::Read::ParentRead(m_p40.clone())) {
                crate::prelude::append(&stales_p41, &crate::prelude::Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XCx), crate::prelude::Text::lit("build_later"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XSelf))])))]))
            } else {
                stales_p41.clone()
            }
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(&crate::prelude::Text) -> crate::prelude::Array<crate::lower::model::Do>>
    };
    let heard_p1c = crate::prelude::each(&row_hears_f(&wx_p6), &(|m_p46: &crate::prelude::Text| crate::lower::model::MethDef { name_p: crate::prelude::Text::from(format!("parent_wrote_{}", m_p46)), recv_p: crate::lower::model::Recv::RecvRc, params_p: crate::prelude::Array::new(), cx_p: crate::lower::model::CxArg::CxMut, ret_p: crate::lower::model::OutTy::OutUnit, body_p: crate::prelude::append(&crate::prelude::append(&moved_by_f(&sinks_pd, &crate::lower::node_::Read::ParentRead(m_p46.clone())), &(&heard_build_f1b)(m_p46)), &crate::prelude::fold(&wx_p6.row_marks_p, &crate::prelude::Array::new(), &(|acc_p47: &crate::prelude::Array<crate::lower::model::Do>, rm_p48: &crate::lower::node_::RowMarks| crate::prelude::append(acc_p47, &row_written_f(&wx_p6, rm_p48, &crate::lower::node_::Read::ParentRead(m_p46.clone())))))), tail_p: crate::lower::model::Ex::XUnit, doc_p: crate::prelude::Text::from(format!("The block wrote behind its `{}`, which this row reads through the parent: the `!Updated` nodes over it are told and the wake asked at their heights; the row\'s own builders over it are listed for the build; the rows of this row\'s own `for`s that read it are marked.", m_p46)) }));
    let heard_above_p1d = crate::prelude::each(&row_hears_f(&wx_p6), &(|m_p49: &crate::prelude::Text| above_method_f(&crate::prelude::Text::from(format!("parent_wrote_{}", m_p49)), &crate::prelude::append(&moved_above_f(&sinks_pd, &crate::lower::node_::Read::ParentRead(m_p49.clone()), &crate::lower::model::Ex::XVar(crate::prelude::Text::lit("h"))), &crate::prelude::fold(&wx_p6.row_marks_p, &crate::prelude::Array::new(), &(|acc_p4a: &crate::prelude::Array<crate::lower::model::Do>, rm_p4b: &crate::lower::node_::RowMarks| crate::prelude::append(acc_p4a, &row_above_f(&wx_p6, rm_p4b, &crate::lower::node_::Read::ParentRead(m_p49.clone()), &crate::lower::model::Ex::XVar(crate::prelude::Text::lit("h"))))))), &crate::prelude::Text::from(format!("the block writes behind its `{}`", m_p49)))));
    let top_p1e = crate::prelude::fold(&wx_p6.gns_p, &crate::prelude::Nat::from(0u32), &(|hi_p4c: &crate::prelude::Nat, g_p4d: &crate::lower::node_::Gn| crate::prelude::max(hi_p4c, &g_p4d.height_p)));
    let wakes_field_p1f = if wakes_p8 {
        crate::prelude::Array::from(vec![(crate::prelude::Text::lit("heights"), crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Heights")), crate::prelude::Array::new()), crate::prelude::Text::lit("each combinator\'s global height, and the combinators asked for this tick, lowest first"))])
    } else {
        crate::prelude::Array::new()
    };
    let wakes_init_p1g = if wakes_p8 {
        crate::prelude::Array::from(vec![(crate::prelude::Text::lit("heights"), crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Heights::new")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XVec(crate::prelude::each(&combs_p7, &(|g_p4e: &crate::lower::node_::Gn| crate::lower::model::Ex::XIndex(g_p4e.height_p.clone()))))])))])
    } else {
        crate::prelude::Array::new()
    };
    let gen_fields_p1h = crate::prelude::fold(&wx_p6.gens_p, &crate::prelude::Array::new(), &(|acc_p4f: &crate::prelude::Array<(crate::prelude::Text, crate::lower::model::OutTy, crate::prelude::Text)>, gd_p4g: &crate::lower::model::GenDef| crate::prelude::append(acc_p4f, &crate::prelude::append(&crate::prelude::Array::from(vec![(gd_p4g.name_p.clone(), crate::lower::model::OutTy::OutCell(::std::rc::Rc::new(crate::lower::model::OutTy::OutOpt(::std::rc::Rc::new(crate::lower::model::OutTy::OutObj(::std::rc::Rc::new(crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Row")), crate::prelude::Array::new()))))))), crate::prelude::Text::from(format!("the current generation of the `rebuild` at place {}", &crate::lower::model::place_text_f(&gd_p4g.pos_p)))), (crate::prelude::Text::from(format!("{}_count", &gd_p4g.name_p)), crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Cell")), crate::prelude::Array::from(vec![crate::lower::model::OutTy::OutCount])), crate::prelude::Text::lit("how many generations it has built")), (crate::prelude::Text::from(format!("{}_stale", &gd_p4g.name_p)), crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Cell")), crate::prelude::Array::from(vec![crate::lower::model::OutTy::OutBool])), crate::prelude::Text::lit("its source changed since it was built"))]), &(if gd_p4g.gappy_p {
        crate::prelude::Array::from(vec![(crate::prelude::Text::from(format!("{}_gap", &gd_p4g.name_p)), crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Cell")), crate::prelude::Array::from(vec![crate::lower::model::OutTy::OutCount])), crate::prelude::Text::lit("how many of its positions the chosen row left unbuilt"))])
    } else {
        crate::prelude::Array::new()
    })))));
    let gen_inits_p1i = crate::prelude::fold(&wx_p6.gens_p, &crate::prelude::Array::new(), &(|acc_p4h: &crate::prelude::Array<(crate::prelude::Text, crate::lower::model::Ex)>, gd_p4i: &crate::lower::model::GenDef| crate::prelude::append(acc_p4h, &crate::prelude::append(&crate::prelude::Array::from(vec![(gd_p4i.name_p.clone(), crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::RefCell::new")), crate::prelude::Array::from(vec![if gd_p4i.early_p {
        crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Some")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XVar(crate::prelude::Text::from(format!("{}_row", &gd_p4i.name_p)))]))
    } else {
        crate::lower::model::Ex::XNone
    }]))), (crate::prelude::Text::from(format!("{}_count", &gd_p4i.name_p)), crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Cell::new")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XIndex(if gd_p4i.early_p {
        crate::prelude::Nat::from(1u32)
    } else {
        crate::prelude::Nat::from(0u32)
    })]))), (crate::prelude::Text::from(format!("{}_stale", &gd_p4i.name_p)), crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Cell::new")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XBool(false)])))]), &(if gd_p4i.gappy_p {
        crate::prelude::Array::from(vec![(crate::prelude::Text::from(format!("{}_gap", &gd_p4i.name_p)), crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Cell::new")), crate::prelude::Array::from(vec![if gd_p4i.early_p {
            crate::lower::model::Ex::XVar(crate::prelude::Text::from(format!("{}_gap_now", &gd_p4i.name_p)))
        } else {
            crate::lower::model::Ex::XIndex(crate::prelude::Nat::from(0u32))
        }])))])
    } else {
        crate::prelude::Array::new()
    })))));
    let port_fields_p1j = crate::prelude::each(&wx_p6.ports_p, &(|pn_p4j: &crate::prelude::Text| (crate::prelude::Text::from(format!("{}_port", pn_p4j)), crate::lower::model::OutTy::OutPort(::std::rc::Rc::new(crate::lower::node_::keyed::gn_ty_named_f(&wx_p6, pn_p4j))), crate::prelude::Text::from(format!("`!{}`, which rows subscribe to", pn_p4j)))));
    let port_inits_p1k = crate::prelude::each(&wx_p6.ports_p, &(|pn_p4k: &crate::prelude::Text| (crate::prelude::Text::from(format!("{}_port", pn_p4k)), crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Port::new")), crate::prelude::Array::new()))));
    let sub_fields_p1l = crate::prelude::each(&wx_p6.subs_p, &(|(ev_p4l, m_p4m, t_p4n): &(crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy)| (crate::prelude::Text::from(format!("{}_sub", m_p4m)), crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Cell")), crate::prelude::Array::from(vec![crate::lower::model::OutTy::OutOpt(::std::rc::Rc::new(crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Handle")), crate::prelude::Array::new())))])), crate::prelude::Text::from(format!("the subscription to the parent\'s `!{}`", ev_p4l)))));
    let sub_inits_p1m = crate::prelude::each(&wx_p6.subs_p, &(|(ev_p4o, m_p4p, t_p4q): &(crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy)| (crate::prelude::Text::from(format!("{}_sub", m_p4p)), crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Cell::new")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XNone])))));
    let fallible_p1n = ((wx_p6.fallible_p || *is_row_p3) || (&crate::prelude::len(&wx_p6.builders_p) > &crate::prelude::Nat::from(0u32))) || (&crate::prelude::len(&wx_p6.gens_p) > &crate::prelude::Nat::from(0u32));
    let late_rows_p1o = crate::prelude::filter(&wx_p6.gens_p, &(|gd_p4r: &crate::lower::model::GenDef| crate::check::types::has_text_f(&wx_p6.late_row_gens_p, &gd_p4r.name_p)));
    let number_fields_p1p = crate::prelude::append(&crate::prelude::each(&late_rows_p1o, &(|gd_p4s: &crate::lower::model::GenDef| (crate::prelude::Text::from(format!("{}_number", &gd_p4s.name_p)), crate::lower::model::OutTy::OutCell(::std::rc::Rc::new(crate::lower::model::OutTy::OutOpt(::std::rc::Rc::new(later_ty_p())))), crate::prelude::Text::from(format!("what numbers the current row of `{}`, until this row is numbered itself", &gd_p4s.name_p))))), &(if wx_p6.late_gens_p {
        crate::prelude::Array::from(vec![(crate::prelude::Text::lit("numbered"), crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Cell")), crate::prelude::Array::from(vec![crate::lower::model::OutTy::OutBool])), crate::prelude::Text::lit("whether the row is numbered yet"))])
    } else {
        crate::prelude::Array::new()
    }));
    let number_inits_p1q = crate::prelude::append(&crate::prelude::each(&late_rows_p1o, &(|gd_p4t: &crate::lower::model::GenDef| (crate::prelude::Text::from(format!("{}_number", &gd_p4t.name_p)), crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::RefCell::new")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XNone]))))), &(if wx_p6.late_gens_p {
        crate::prelude::Array::from(vec![(crate::prelude::Text::lit("numbered"), crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Cell::new")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XBool(false)])))])
    } else {
        crate::prelude::Array::new()
    }));
    let now_steps_p1r = if wx_p6.late_gens_p {
        build_steps_f(&phase_of_f(&sinks_pd, &crate::prelude::Nat::from(1u32)), &true)
    } else {
        crate::prelude::Array::new()
    };
    let later_steps_p1s = if wx_p6.late_gens_p {
        build_steps_f(&phase_of_f(&sinks_pd, &crate::prelude::Nat::from(2u32)), &true)
    } else {
        crate::prelude::Array::new()
    };
    let late_generations_p1t = crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&crate::prelude::filter(&wx_p6.build_p, &is_owner_link_f), &links_pv), &late_numbering_f(&crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&later_steps_p1s, &crate::prelude::filter(&wx_p6.build_p, &(|d_p4u: &crate::lower::model::Do| !is_owner_link_f(d_p4u)))), &subscribed_p11), &announced_pi), &started_reg_pu))), &now_steps_p1r);
    let after_node_p1u = crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&crate::prelude::filter(&wx_p6.build_p, &is_owner_link_f), &rows_built_p10), &crate::prelude::filter(&wx_p6.build_p, &(|d_p4v: &crate::lower::model::Do| !is_owner_link_f(d_p4v)))), &subscribed_p11), &announced_pi), &started_reg_pu);
    crate::lower::model::NodeDef { name_p: wx_p6.node_p.clone(), prism_p: crate::check::types::bare_name_f(qk_p1), doc_p: crate::lower::functions::definition_text_f(&wx_p6.lx_p, qk_p1), params_p: params_p2.clone(), fields_p: crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&wx_p6.fields_p, &wakes_field_p1f), &gen_fields_p1h), &port_fields_p1j), &sub_fields_p1l), &number_fields_p1p), consts_p: crate::prelude::Array::new(), lets_p: wx_p6.lets_p.clone(), inits_p: crate::prelude::append(&wx_p6.inits_p, &crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&wx_p6.moves_p, &wakes_init_p1g), &gen_inits_p1i), &port_inits_p1k), &crate::prelude::append(&sub_inits_p1m, &number_inits_p1q))), build_p: crate::prelude::append(&(if wx_p6.late_gens_p {
        late_generations_p1t.clone()
    } else {
        if wx_p6.base_late_p {
            late_numbering_f(&after_node_p1u)
        } else {
            after_node_p1u.clone()
        }
    }), &wx_p6.numbered_by_p), fallible_p: fallible_p1n, methods_p: crate::prelude::append(&(if wx_p6.base_late_p {
        crate::prelude::Array::from(vec![number_places_f(&wx_p6)])
    } else {
        crate::prelude::Array::new()
    }), &crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&ev_methods_pe, &ev_above_pg), &gather_ins_pf), &in_above_ph), &heard_above_p1d), &place_getters_pj), &wx_p6.getters_p), &row_methods_p1a), &heard_p1c), &host_methods_p15), &gathered_moved_p17), &crate::prelude::append(&moved_method_p19, &place_methods_f(&wx_p6)))), answers_p: crate::prelude::append(&crate::prelude::append(&answers_p13, &forwards_p14), &crate::lower::node_::switch_::wide_forward_f(&crate::prelude::filter(&wx_p6.gens_p, &(|gd_p50: &crate::lower::model::GenDef| crate::lower::node_::switch_::is_wide_gen_f(gd_p50) && emits_f(&wx_p6, &gd_p50.pos_p))))), hooks_p: hooks_pt.clone(), builders_p: wx_p6.builders_p.clone(), wakes_p: wakes_p8, children_p: wx_p6.rows_p.clone(), gens_p: crate::prelude::each(&wx_p6.gens_p, &(|gd_p51: &crate::lower::model::GenDef| if crate::check::types::has_text_f(&wx_p6.late_row_gens_p, &gd_p51.name_p) {
        late_row_select_f(gd_p51)
    } else {
        gd_p51.clone()
    })), subs_p: wx_p6.subs_p.clone(), top_p: top_p1e.clone(), row_kind_p: if *is_row_p3 {
        if is_gen_p5 {
            crate::lower::model::RowKind::GenerationRow
        } else {
            crate::lower::model::RowKind::ForRow
        }
    } else {
        crate::lower::model::RowKind::NotARow
    }, hosted_p: hosted_methods_p18.clone() }
}

/// The step machine of `FinishNode`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FinishNode: unbounded fn Wx, Text, [((Text, OutTy))], Bool -> NodeDef
/// ```
pub struct FinishNode {
    pub wx0_p0: crate::lower::node_::Wx,
    pub qk_p1: crate::prelude::Text,
    pub params_p2: crate::prelude::Array<(crate::prelude::Text, crate::lower::model::OutTy)>,
    pub is_row_p3: bool,
}

impl ::prism_rtl::Job<crate::lower::model::NodeDef> for FinishNode {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::lower::model::NodeDef> {
        let wx0_p0 = &self.wx0_p0;
        let qk_p1 = &self.qk_p1;
        let params_p2 = &self.params_p2;
        let is_row_p3 = &self.is_row_p3;
        let closed_gns_p4 = crate::prelude::each(&wx0_p0.gns_p, &(|g_p1v: &crate::lower::node_::Gn| if &g_p1v.kind_p == &crate::lower::node_::GnKind::GnUpdated {
            crate::lower::node_::dynamics::with_reads_f(g_p1v, &reads_closed_f(&wx0_p0.dyn_reads_p, &g_p1v.reads_p))
        } else {
            g_p1v.clone()
        }));
        let is_row_p3x = *is_row_p3;
        let params_p2x = params_p2.clone();
        let qk_p1x = qk_p1.clone();
        let wx0_p0x = wx0_p0.clone();
        crate::prelude::call_then(start_finish_pending_f(wx0_p0x.clone(), heights_f(&closed_gns_p4)), move |finish_pending_f_18639: (crate::prelude::Array<crate::lower::model::NodeDef>, crate::prelude::Array<crate::lower::node_::Gn>)| {
            let (row_defs_p20, gns2_p21) = finish_pending_f_18639;
            let is_gen_p5 = is_row_p3x && (&crate::prelude::len(&crate::prelude::filter(&wx0_p0x.fields_p, &(|(f_p22, _, _): &(crate::prelude::Text, crate::lower::model::OutTy, crate::prelude::Text)| f_p22 == &crate::prelude::Text::lit("key")))) == &crate::prelude::Nat::from(0u32));
            let wx_p6 = {
                let mut this: crate::lower::node_::Wx = wx0_p0x.clone();
                this.gns_p = heights_f(&gns2_p21);
                this.build_p = crate::prelude::append(&this.build_p, &updated_gaps_f(&wx0_p0x, &closed_gns_p4));
                this.rows_p = crate::prelude::fold(&row_defs_p20, &this.rows_p, &(|acc_p23: &crate::prelude::Array<crate::lower::model::NodeDef>, rd_p24: &crate::lower::model::NodeDef| crate::prelude::append(&crate::prelude::push(acc_p23, rd_p24), &rd_p24.children_p)));
                this
            };
            let combs_p7 = crate::prelude::filter(&wx_p6.gns_p, &(|g_p25: &crate::lower::node_::Gn| (is_comb_f(&g_p25.kind_p) || (&g_p25.kind_p == &crate::lower::node_::GnKind::GnGather)) || (&g_p25.kind_p == &crate::lower::node_::GnKind::GnMergeList)));
            let wakes_p8 = &crate::prelude::len(&combs_p7) > &crate::prelude::Nat::from(0u32);
            let live_p9 = crate::prelude::filter(&wx_p6.places_p, &(|p_p26: &crate::lower::node_::Place| &p_p26.getter_p != &crate::prelude::Text::lit("")));
            let root_reads_pa = crate::prelude::fold(&wx_p6.root_dyns_p, &crate::prelude::Array::new(), &(|acc_p27: &crate::prelude::Array<crate::lower::node_::Read>, (_, rds_p28, _): &(crate::lower::model::Ex, crate::prelude::Array<crate::lower::node_::Read>, crate::lower::model::OutTy)| crate::lower::node_::union_reads_f(acc_p27, &reads_closed_f(&wx_p6.dyn_reads_p, rds_p28))));
            let dirty_holds_pb = crate::prelude::fold(&live_p9, &root_reads_pa, &(|acc_p29: &crate::prelude::Array<crate::lower::node_::Read>, p_p2a: &crate::lower::node_::Place| crate::lower::node_::union_reads_f(acc_p29, &reads_closed_f(&wx_p6.dyn_reads_p, &p_p2a.reads_p))));
            let build_holds_pc = reads_closed_f(&wx_p6.dyn_reads_p, &wx_p6.build_holds_p);
            let sinks_pd = Sinks { wx_p: wx_p6.clone(), dirty_p: dirty_holds_pb.clone(), builds_p: build_holds_pc.clone(), combs_p: combs_p7.clone() };
            crate::prelude::call_value(crate::prelude::each_job(crate::prelude::filter(&wx_p6.gns_p, &(|g_p2b: &crate::lower::node_::Gn| &g_p2b.kind_p != &crate::lower::node_::GnKind::GnNever)), {
                let sinks_pdx = sinks_pd.clone();
                ::std::rc::Rc::new(move |p0: crate::lower::node_::Gn| {
                    let sinks_pdxy = sinks_pdx.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let g_p2c = p0;
                        crate::prelude::call_then(start_firing_code_f(sinks_pdxy.clone(), g_p2c.clone(), crate::lower::model::Ex::XVar(crate::prelude::Text::lit("v"))), move |firing_code_f_19692: crate::prelude::Array<crate::lower::model::Do>| ::prism_rtl::Turn::Finished(crate::lower::model::MethDef { name_p: g_p2c.name_p.clone(), recv_p: crate::lower::model::Recv::RecvRc, params_p: crate::prelude::Array::from(vec![(crate::prelude::Text::lit("v"), g_p2c.ty_p.clone())]), cx_p: crate::lower::model::CxArg::CxMut, ret_p: crate::lower::model::OutTy::OutUnit, body_p: firing_code_f_19692, tail_p: crate::lower::model::Ex::XUnit, doc_p: gn_doc_f(&g_p2c) }))
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::node_::Gn) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::MethDef>>>
            }), move |each_19552: crate::prelude::Array<crate::lower::model::MethDef>| {
                let ev_methods_pe = each_19552;
                let gather_ins_pf = crate::prelude::append(&crate::prelude::each(&crate::prelude::filter(&wx_p6.gns_p, &(|g_p2d: &crate::lower::node_::Gn| &g_p2d.kind_p == &crate::lower::node_::GnKind::GnGather)), &(|g_p2e: &crate::lower::node_::Gn| gather_in_f(&sinks_pd, g_p2e))), &crate::prelude::each(&crate::prelude::filter(&wx_p6.gns_p, &(|g_p2f: &crate::lower::node_::Gn| &g_p2f.kind_p == &crate::lower::node_::GnKind::GnMergeList)), &(|g_p2g: &crate::lower::node_::Gn| merge_list_in_f(&sinks_pd, g_p2g))));
                let ev_above_pg = crate::prelude::each(&crate::prelude::filter(&wx_p6.gns_p, &(|g_p2h: &crate::lower::node_::Gn| &g_p2h.kind_p != &crate::lower::node_::GnKind::GnNever)), &(|g_p2i: &crate::lower::node_::Gn| above_method_f(&g_p2i.name_p, &crate::prelude::fold(&g_p2i.outs_p, &crate::prelude::Array::new(), &(|acc_p2j: &crate::prelude::Array<crate::lower::model::Do>, o_p2k: &crate::lower::node_::Out| crate::prelude::append(acc_p2j, &sink_above_f(&sinks_pd, &o_p2k.sink_p, &crate::lower::model::Ex::XVar(crate::prelude::Text::lit("h")))))), &crate::prelude::Text::from(format!("`!{}` fires", &g_p2i.name_p)))));
                let in_above_ph = crate::prelude::each(&crate::prelude::filter(&wx_p6.gns_p, &(|g_p2l: &crate::lower::node_::Gn| (&g_p2l.kind_p == &crate::lower::node_::GnKind::GnGather) || (&g_p2l.kind_p == &crate::lower::node_::GnKind::GnMergeList))), &(|g_p2m: &crate::lower::node_::Gn| above_method_f(&crate::prelude::Text::from(format!("{}_in", &g_p2m.name_p)), &combinator_above_f(&sinks_pd, g_p2m, &crate::lower::model::Ex::XVar(crate::prelude::Text::lit("h"))), &crate::prelude::Text::from(format!("an input of `{}` fires", &g_p2m.name_p)))));
                let announced_pi = crate::prelude::each(&combs_p7, &(|g_p2n: &crate::lower::node_::Gn| above_call_f(&crate::lower::model::Ex::XVar(crate::prelude::Text::lit("node")), &g_p2n.name_p, &crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("node"))), crate::prelude::Text::lit("heights"))), crate::prelude::Text::lit("of"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XIndex(combinator_of_f(&combs_p7, g_p2n))])))));
                let place_getters_pj = crate::prelude::each(&live_p9, &(|p_p2o: &crate::lower::node_::Place| crate::lower::model::MethDef { name_p: p_p2o.getter_p.clone(), recv_p: crate::lower::model::Recv::RecvRef, params_p: crate::prelude::Array::new(), cx_p: crate::lower::model::CxArg::CxRef, ret_p: crate::lower::types::elem_ty_p(), body_p: crate::prelude::Array::new(), tail_p: p_p2o.level_p.clone(), doc_p: crate::prelude::Text::from(format!("Place {}\'s level, read at the read point.", &crate::lower::model::place_text_f(&p_p2o.pos_p))) }));
                let wake_body_pk = if wakes_p8 {
                    crate::prelude::Array::from(vec![wake_by_height_f(&combs_p7), crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::lit("heights"))), crate::prelude::Text::lit("again"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx, crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XSelf))])))])
                } else {
                    crate::prelude::Array::new()
                };
                let started_body_pl = crate::prelude::each(&wx_p6.started_p, &(|st_p2p: &crate::prelude::Nat| self_call_f(&crate::lower::node_::gn_of_f(&wx_p6, st_p2p).name_p, &crate::prelude::Array::from(vec![crate::lower::model::Ex::XUnit]))));
                let deferred_body_pm = crate::prelude::each(&wx_p6.defers_p, &(|(f_p2q, id_p2r): &(crate::prelude::Text, crate::prelude::Nat)| crate::lower::model::Do::DoIfLet(crate::lower::model::Pa::PaCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Some")), crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("v"))])), crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::from(format!("{}", f_p2q)))), crate::prelude::Text::lit("fired"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx])), crate::prelude::Array::from(vec![self_call_f(&crate::lower::node_::gn_of_f(&wx_p6, id_p2r).name_p, &crate::prelude::Array::from(vec![crate::lower::model::Ex::XVar(crate::prelude::Text::lit("v"))]))]), crate::prelude::Array::new())));
                let patch_body0_pn = crate::prelude::fold(&live_p9, &crate::prelude::Array::new(), &(|acc_p2s: &crate::prelude::Array<crate::lower::model::Do>, p_p2t: &crate::lower::node_::Place| crate::prelude::append(acc_p2s, &(if emits_f(&wx_p6, &p_p2t.pos_p) {
                    patch_place_f(&wx_p6, p_p2t)
                } else {
                    crate::prelude::Array::from(vec![entry_take_f(&crate::lower::model::Ex::XSelf, p_p2t)])
                }))));
                let patch_body_po = crate::prelude::append(&patch_body0_pn, &root_dyn_patch_f(&wx_p6));
                let build_steps_pp = build_steps_f(&sinks_pd, &false);
                let build_body_pq = if (&wx_p6.gen_of_p == &crate::prelude::Text::lit("")) || (&crate::prelude::len(&build_steps_pp) == &crate::prelude::Nat::from(0u32)) {
                    build_steps_pp.clone()
                } else {
                    crate::prelude::Array::from(vec![crate::lower::model::Do::DoIf(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::lit("current"), crate::prelude::Array::new()), build_steps_pp.clone(), crate::prelude::Array::new())])
                };
                let push_body0_pr = crate::prelude::each(&crate::prelude::filter(&wx_p6.dyn_places_p, &(|(pos_p2u, _, _, _): &(crate::lower::model::Pos, crate::prelude::Text, crate::lower::model::OutTy, crate::prelude::Text)| emits_f(&wx_p6, pos_p2u))), &(|(pos_p2v, f_p30, t_p31, _): &(crate::lower::model::Pos, crate::prelude::Text, crate::lower::model::OutTy, crate::prelude::Text)| crate::lower::model::Do::DoIf(crate::lower::model::Ex::XBin(crate::lower::model::BinOp::OpEq, ::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("element"))), ::std::rc::Rc::new(crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::from(format!("{}_element", f_p30))))))), dyn_place_write_f(&sinks_pd, f_p30, &crate::lower::model::Ex::XDecode(t_p31.clone(), ::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("v"))))), crate::prelude::Array::new())));
                let push_body_ps = crate::prelude::append(&push_body0_pr, &crate::prelude::each(&crate::prelude::filter(&wx_p6.bundles_p, &(|bp_p32: &crate::lower::node_::BundlePlace| (&bp_p32.stem_p != &crate::prelude::Text::lit("")) && emits_f(&wx_p6, &bp_p32.pos_p))), &(|bp_p33: &crate::lower::node_::BundlePlace| crate::lower::model::Do::DoIf(crate::lower::model::Ex::XBin(crate::lower::model::BinOp::OpEq, ::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("element"))), ::std::rc::Rc::new(crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::from(format!("{}_element", &bp_p33.stem_p))))))), bundle_state_write_f(&sinks_pd, bp_p33, &crate::lower::model::Ex::XDecode(bp_p33.state_ty_p.clone(), ::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("v"))))), crate::prelude::Array::new()))));
                let hooks_pt = crate::prelude::filter(&crate::prelude::Array::from(vec![(crate::prelude::Text::lit("wake"), wake_body_pk.clone()), (crate::prelude::Text::lit("started"), started_body_pl.clone()), (crate::prelude::Text::lit("deferred"), deferred_body_pm.clone()), (crate::prelude::Text::lit("build"), build_body_pq.clone()), (crate::prelude::Text::lit("swap"), crate::lower::node_::switch_::swap_body_f(&wx_p6)), (crate::prelude::Text::lit("push"), push_body_ps.clone()), (crate::prelude::Text::lit("patch"), patch_body_po.clone())]), &(|(_, b_p34): &(crate::prelude::Text, crate::prelude::Array<crate::lower::model::Do>)| &crate::prelude::len(b_p34) > &crate::prelude::Nat::from(0u32)));
                let started_reg_pu = if &crate::prelude::len(&wx_p6.started_p) > &crate::prelude::Nat::from(0u32) {
                    crate::prelude::Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XCx), crate::prelude::Text::lit("on_started"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("node"))))])))])
                } else {
                    crate::prelude::Array::new()
                };
                let links_pv = crate::prelude::each(&wx_p6.hosts_p, &(|h_p35: &crate::lower::node_::HostDef| crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("node"))), crate::prelude::Text::from(format!("{}", &h_p35.name_p)))), crate::prelude::Text::lit("link"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("node"))))])))));
                let rows_built_p10 = crate::prelude::append(&links_pv, &build_steps_f(&sinks_pd, &true));
                let subscribed_p11 = crate::prelude::each(&wx_p6.subs_p, &(|(ev_p36, m_p37, t_p38): &(crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy)| crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XCall(crate::lower::helper_ref_f(&crate::prelude::Text::lit("subscribe_row")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("node")))), crate::lower::model::Ex::XUpgrade(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("node"))), crate::prelude::Text::lit("parent")))), crate::lower::model::Ex::XClosure(false, crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("p"))]), ::std::rc::Rc::new(crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("p"))), crate::prelude::Text::from(format!("{}_port", ev_p36))))))), crate::lower::model::Ex::XClosure(false, crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("n")), crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("v")), crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("cx"))]), ::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("n"))), m_p37.clone(), crate::prelude::Array::from(vec![crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("v")))), crate::lower::model::Ex::XCx])))), heard_above_f(m_p37), crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("node"))), crate::prelude::Text::from(format!("{}_sub", m_p37)))))])))));
                let answers0_p12 = crate::prelude::append(&crate::prelude::each(&crate::prelude::filter(&wx_p6.answers_p, &(|(pos_p39, _, _, _): &(crate::lower::model::Pos, crate::prelude::Nat, crate::lower::model::OutTy, crate::prelude::Text)| emits_f(&wx_p6, pos_p39))), &(|(pos_p3a, id_p3b, t_p3c, _): &(crate::lower::model::Pos, crate::prelude::Nat, crate::lower::model::OutTy, crate::prelude::Text)| answer_arm_f(&wx_p6, pos_p3a, id_p3b, t_p3c))), &crate::prelude::each(&crate::prelude::filter(&wx_p6.dyn_places_p, &(|(pos_p3d, _, _, _): &(crate::lower::model::Pos, crate::prelude::Text, crate::lower::model::OutTy, crate::prelude::Text)| emits_f(&wx_p6, pos_p3d) && !crate::prelude::fold(&wx_p6.answers_p, &false, &(|seen_p3e: &bool, (apos_p3f, _, _, _): &(crate::lower::model::Pos, crate::prelude::Nat, crate::lower::model::OutTy, crate::prelude::Text)| *seen_p3e || (apos_p3f == pos_p3d))))), &(|(pos_p3g, f_p3h, t_p3i, _): &(crate::lower::model::Pos, crate::prelude::Text, crate::lower::model::OutTy, crate::prelude::Text)| dyn_answer_arm_f(&sinks_pd, pos_p3g, f_p3h, t_p3i))));
                let answers_p13 = crate::prelude::append(&answers0_p12, &crate::prelude::each(&crate::prelude::filter(&wx_p6.bundles_p, &(|bp_p3j: &crate::lower::node_::BundlePlace| emits_f(&wx_p6, &bp_p3j.pos_p) && ((&crate::prelude::len(&bp_p3j.events_p) > &crate::prelude::Nat::from(0u32)) || (&bp_p3j.stem_p != &crate::prelude::Text::lit(""))))), &(|bp_p3k: &crate::lower::node_::BundlePlace| bundle_answer_arm_f(&sinks_pd, bp_p3k))));
                let forwards_p14 = crate::prelude::append(&crate::prelude::each(&crate::prelude::filter(&wx_p6.builders_p, &(|b_p3l: &crate::lower::model::ForDef| emits_f(&wx_p6, &b_p3l.pos_p))), &(|b_p3m: &crate::lower::model::ForDef| (pos_pat_f(&b_p3m.pos_p, &key_tail_p()), forward_answer_f(b_p3m)))), &crate::prelude::fold(&crate::prelude::filter(&wx_p6.gens_p, &(|gd_p3n: &crate::lower::model::GenDef| emits_f(&wx_p6, &gd_p3n.pos_p))), &crate::prelude::Array::new(), &(|acc_p3o: &crate::prelude::Array<(crate::lower::model::Pa, crate::lower::model::Ex)>, gd_p3p: &crate::lower::model::GenDef| crate::prelude::append(acc_p3o, &crate::lower::node_::switch_::gen_forwards_f(gd_p3p)))));
                crate::prelude::call_value(crate::prelude::fold_job(wx_p6.hosts_p.clone(), crate::prelude::Array::new(), {
                    let sinks_pdx = sinks_pd.clone();
                    ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::lower::model::MethDef>, crate::lower::node_::HostDef)| {
                        let sinks_pdxy = sinks_pdx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let acc_p3q = p0;
                            let h_p3r = p1;
                            crate::prelude::call_then(start_typed_dispatch_f(sinks_pdxy.clone(), crate::prelude::Text::from(format!("{}_answer", &h_p3r.name_p)), h_p3r.scope_p.clone()), move |typed_dispatch_f_25031: crate::lower::model::MethDef| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_p3q, &crate::prelude::Array::from(vec![typed_dispatch_f_25031, host_moved_f(&sinks_pdxy, &h_p3r)]))))
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::lower::model::MethDef>, crate::lower::node_::HostDef)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::lower::model::MethDef>>>>
                }), move |fold_24985: crate::prelude::Array<crate::lower::model::MethDef>| {
                    let host_methods_p15 = fold_24985;
                    let gathered_p16 = crate::prelude::filter(&wx_p6.snaps_p, &(|sn_p3s: &crate::lower::node_::SnapDef| !(sn_p3s.before_p || is_generation_f(&wx_p6, &sn_p3s.builder_p))));
                    let gathered_moved_p17 = crate::prelude::append(&crate::prelude::append(&crate::prelude::each(&gathered_p16, &(|sn_p3t: &crate::lower::node_::SnapDef| gathered_moved_f(sn_p3t))), &crate::prelude::each(&wx_p6.snaps_p, &(|sn_p3u: &crate::lower::node_::SnapDef| snap_publish_f(&sinks_pd, sn_p3u)))), &flatten_methods_f(&sinks_pd));
                    let announced_piz = announced_pi.clone();
                    let answers_p13z = answers_p13.clone();
                    let combs_p7z = combs_p7.clone();
                    let ev_above_pgz = ev_above_pg.clone();
                    let ev_methods_pez = ev_methods_pe.clone();
                    let forwards_p14z = forwards_p14.clone();
                    let gather_ins_pfz = gather_ins_pf.clone();
                    let gathered_moved_p17z = gathered_moved_p17.clone();
                    let hooks_ptz = hooks_pt.clone();
                    let host_methods_p15z = host_methods_p15.clone();
                    let in_above_phz = in_above_ph.clone();
                    let is_gen_p5z = is_gen_p5;
                    let is_row_p3xz = is_row_p3x;
                    let links_pvz = links_pv.clone();
                    let params_p2xz = params_p2x.clone();
                    let place_getters_pjz = place_getters_pj.clone();
                    let qk_p1xz = qk_p1x.clone();
                    let rows_built_p10z = rows_built_p10.clone();
                    let sinks_pdz = sinks_pd.clone();
                    let started_reg_puz = started_reg_pu.clone();
                    let subscribed_p11z = subscribed_p11.clone();
                    let wakes_p8z = wakes_p8;
                    let wx_p6z = wx_p6.clone();
                    let k_let25349 = move |v25349: crate::prelude::Array<crate::lower::model::MethDef>| {
                        let hosted_methods_p18 = v25349;
                        let moved_method_p19 = match &wx_p6z.hosted_by_o {
                            ::std::option::Option::Some(m_p3v) => crate::prelude::Array::from(vec![document_moved_f(m_p3v)]),
                            ::std::option::Option::None => crate::prelude::Array::new(),
                        };
                        let row_methods_p1a = if is_row_p3xz { row_methods_f(&wx_p6z) } else { crate::prelude::Array::new() };
                        let heard_build_f1b = {
                            let wx_p6zx = wx_p6z.clone();
                            let sinks_pdzx = sinks_pdz.clone();
                            ::std::rc::Rc::new(move |m_p40: &crate::prelude::Text| {
                                let stales_p41 = crate::prelude::fold(&wx_p6zx.gen_holds_p, &crate::prelude::Array::new(), &(|acc_p43: &crate::prelude::Array<crate::lower::model::Do>, (gname_p44, hs_p45): &(crate::prelude::Text, crate::prelude::Array<crate::lower::node_::Read>)| if crate::lower::node_::has_read_f(&reads_closed_f(&wx_p6zx.dyn_reads_p, hs_p45), &crate::lower::node_::Read::ParentRead(m_p40.clone())) {
                                    crate::prelude::push(acc_p43, &crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::from(format!("{}_stale", gname_p44)))), crate::prelude::Text::lit("set"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XBool(true)]))))
                                } else {
                                    acc_p43.clone()
                                }));
                                let builds_p42 = crate::lower::node_::has_read_f(&sinks_pdzx.builds_p, &crate::lower::node_::Read::ParentRead(m_p40.clone())) || (&crate::prelude::len(&stales_p41) > &crate::prelude::Nat::from(0u32));
                                if builds_p42 && !lists_build_f(&sinks_pdzx, &crate::lower::node_::Read::ParentRead(m_p40.clone())) {
                                    crate::prelude::append(&stales_p41, &crate::prelude::Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XCx), crate::prelude::Text::lit("build_later"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XSelf))])))]))
                                } else {
                                    stales_p41.clone()
                                }
                            }) as ::std::rc::Rc<dyn ::std::ops::Fn(&crate::prelude::Text) -> crate::prelude::Array<crate::lower::model::Do>>
                        };
                        let heard_p1c = crate::prelude::each(&row_hears_f(&wx_p6z), &(|m_p46: &crate::prelude::Text| crate::lower::model::MethDef { name_p: crate::prelude::Text::from(format!("parent_wrote_{}", m_p46)), recv_p: crate::lower::model::Recv::RecvRc, params_p: crate::prelude::Array::new(), cx_p: crate::lower::model::CxArg::CxMut, ret_p: crate::lower::model::OutTy::OutUnit, body_p: crate::prelude::append(&crate::prelude::append(&moved_by_f(&sinks_pdz, &crate::lower::node_::Read::ParentRead(m_p46.clone())), &(&heard_build_f1b)(m_p46)), &crate::prelude::fold(&wx_p6z.row_marks_p, &crate::prelude::Array::new(), &(|acc_p47: &crate::prelude::Array<crate::lower::model::Do>, rm_p48: &crate::lower::node_::RowMarks| crate::prelude::append(acc_p47, &row_written_f(&wx_p6z, rm_p48, &crate::lower::node_::Read::ParentRead(m_p46.clone())))))), tail_p: crate::lower::model::Ex::XUnit, doc_p: crate::prelude::Text::from(format!("The block wrote behind its `{}`, which this row reads through the parent: the `!Updated` nodes over it are told and the wake asked at their heights; the row\'s own builders over it are listed for the build; the rows of this row\'s own `for`s that read it are marked.", m_p46)) }));
                        let heard_above_p1d = crate::prelude::each(&row_hears_f(&wx_p6z), &(|m_p49: &crate::prelude::Text| above_method_f(&crate::prelude::Text::from(format!("parent_wrote_{}", m_p49)), &crate::prelude::append(&moved_above_f(&sinks_pdz, &crate::lower::node_::Read::ParentRead(m_p49.clone()), &crate::lower::model::Ex::XVar(crate::prelude::Text::lit("h"))), &crate::prelude::fold(&wx_p6z.row_marks_p, &crate::prelude::Array::new(), &(|acc_p4a: &crate::prelude::Array<crate::lower::model::Do>, rm_p4b: &crate::lower::node_::RowMarks| crate::prelude::append(acc_p4a, &row_above_f(&wx_p6z, rm_p4b, &crate::lower::node_::Read::ParentRead(m_p49.clone()), &crate::lower::model::Ex::XVar(crate::prelude::Text::lit("h"))))))), &crate::prelude::Text::from(format!("the block writes behind its `{}`", m_p49)))));
                        let top_p1e = crate::prelude::fold(&wx_p6z.gns_p, &crate::prelude::Nat::from(0u32), &(|hi_p4c: &crate::prelude::Nat, g_p4d: &crate::lower::node_::Gn| crate::prelude::max(hi_p4c, &g_p4d.height_p)));
                        let wakes_field_p1f = if wakes_p8z {
                            crate::prelude::Array::from(vec![(crate::prelude::Text::lit("heights"), crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Heights")), crate::prelude::Array::new()), crate::prelude::Text::lit("each combinator\'s global height, and the combinators asked for this tick, lowest first"))])
                        } else {
                            crate::prelude::Array::new()
                        };
                        let wakes_init_p1g = if wakes_p8z {
                            crate::prelude::Array::from(vec![(crate::prelude::Text::lit("heights"), crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Heights::new")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XVec(crate::prelude::each(&combs_p7z, &(|g_p4e: &crate::lower::node_::Gn| crate::lower::model::Ex::XIndex(g_p4e.height_p.clone()))))])))])
                        } else {
                            crate::prelude::Array::new()
                        };
                        let gen_fields_p1h = crate::prelude::fold(&wx_p6z.gens_p, &crate::prelude::Array::new(), &(|acc_p4f: &crate::prelude::Array<(crate::prelude::Text, crate::lower::model::OutTy, crate::prelude::Text)>, gd_p4g: &crate::lower::model::GenDef| crate::prelude::append(acc_p4f, &crate::prelude::append(&crate::prelude::Array::from(vec![(gd_p4g.name_p.clone(), crate::lower::model::OutTy::OutCell(::std::rc::Rc::new(crate::lower::model::OutTy::OutOpt(::std::rc::Rc::new(crate::lower::model::OutTy::OutObj(::std::rc::Rc::new(crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Row")), crate::prelude::Array::new()))))))), crate::prelude::Text::from(format!("the current generation of the `rebuild` at place {}", &crate::lower::model::place_text_f(&gd_p4g.pos_p)))), (crate::prelude::Text::from(format!("{}_count", &gd_p4g.name_p)), crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Cell")), crate::prelude::Array::from(vec![crate::lower::model::OutTy::OutCount])), crate::prelude::Text::lit("how many generations it has built")), (crate::prelude::Text::from(format!("{}_stale", &gd_p4g.name_p)), crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Cell")), crate::prelude::Array::from(vec![crate::lower::model::OutTy::OutBool])), crate::prelude::Text::lit("its source changed since it was built"))]), &(if gd_p4g.gappy_p {
                            crate::prelude::Array::from(vec![(crate::prelude::Text::from(format!("{}_gap", &gd_p4g.name_p)), crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Cell")), crate::prelude::Array::from(vec![crate::lower::model::OutTy::OutCount])), crate::prelude::Text::lit("how many of its positions the chosen row left unbuilt"))])
                        } else {
                            crate::prelude::Array::new()
                        })))));
                        let gen_inits_p1i = crate::prelude::fold(&wx_p6z.gens_p, &crate::prelude::Array::new(), &(|acc_p4h: &crate::prelude::Array<(crate::prelude::Text, crate::lower::model::Ex)>, gd_p4i: &crate::lower::model::GenDef| crate::prelude::append(acc_p4h, &crate::prelude::append(&crate::prelude::Array::from(vec![(gd_p4i.name_p.clone(), crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::RefCell::new")), crate::prelude::Array::from(vec![if gd_p4i.early_p {
                            crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Some")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XVar(crate::prelude::Text::from(format!("{}_row", &gd_p4i.name_p)))]))
                        } else {
                            crate::lower::model::Ex::XNone
                        }]))), (crate::prelude::Text::from(format!("{}_count", &gd_p4i.name_p)), crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Cell::new")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XIndex(if gd_p4i.early_p {
                            crate::prelude::Nat::from(1u32)
                        } else {
                            crate::prelude::Nat::from(0u32)
                        })]))), (crate::prelude::Text::from(format!("{}_stale", &gd_p4i.name_p)), crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Cell::new")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XBool(false)])))]), &(if gd_p4i.gappy_p {
                            crate::prelude::Array::from(vec![(crate::prelude::Text::from(format!("{}_gap", &gd_p4i.name_p)), crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Cell::new")), crate::prelude::Array::from(vec![if gd_p4i.early_p {
                                crate::lower::model::Ex::XVar(crate::prelude::Text::from(format!("{}_gap_now", &gd_p4i.name_p)))
                            } else {
                                crate::lower::model::Ex::XIndex(crate::prelude::Nat::from(0u32))
                            }])))])
                        } else {
                            crate::prelude::Array::new()
                        })))));
                        let port_fields_p1j = crate::prelude::each(&wx_p6z.ports_p, &(|pn_p4j: &crate::prelude::Text| (crate::prelude::Text::from(format!("{}_port", pn_p4j)), crate::lower::model::OutTy::OutPort(::std::rc::Rc::new(crate::lower::node_::keyed::gn_ty_named_f(&wx_p6z, pn_p4j))), crate::prelude::Text::from(format!("`!{}`, which rows subscribe to", pn_p4j)))));
                        let port_inits_p1k = crate::prelude::each(&wx_p6z.ports_p, &(|pn_p4k: &crate::prelude::Text| (crate::prelude::Text::from(format!("{}_port", pn_p4k)), crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Port::new")), crate::prelude::Array::new()))));
                        let sub_fields_p1l = crate::prelude::each(&wx_p6z.subs_p, &(|(ev_p4l, m_p4m, t_p4n): &(crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy)| (crate::prelude::Text::from(format!("{}_sub", m_p4m)), crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Cell")), crate::prelude::Array::from(vec![crate::lower::model::OutTy::OutOpt(::std::rc::Rc::new(crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Handle")), crate::prelude::Array::new())))])), crate::prelude::Text::from(format!("the subscription to the parent\'s `!{}`", ev_p4l)))));
                        let sub_inits_p1m = crate::prelude::each(&wx_p6z.subs_p, &(|(ev_p4o, m_p4p, t_p4q): &(crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy)| (crate::prelude::Text::from(format!("{}_sub", m_p4p)), crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Cell::new")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XNone])))));
                        let fallible_p1n = ((wx_p6z.fallible_p || is_row_p3xz) || (&crate::prelude::len(&wx_p6z.builders_p) > &crate::prelude::Nat::from(0u32))) || (&crate::prelude::len(&wx_p6z.gens_p) > &crate::prelude::Nat::from(0u32));
                        let late_rows_p1o = crate::prelude::filter(&wx_p6z.gens_p, &(|gd_p4r: &crate::lower::model::GenDef| crate::check::types::has_text_f(&wx_p6z.late_row_gens_p, &gd_p4r.name_p)));
                        let number_fields_p1p = crate::prelude::append(&crate::prelude::each(&late_rows_p1o, &(|gd_p4s: &crate::lower::model::GenDef| (crate::prelude::Text::from(format!("{}_number", &gd_p4s.name_p)), crate::lower::model::OutTy::OutCell(::std::rc::Rc::new(crate::lower::model::OutTy::OutOpt(::std::rc::Rc::new(later_ty_p())))), crate::prelude::Text::from(format!("what numbers the current row of `{}`, until this row is numbered itself", &gd_p4s.name_p))))), &(if wx_p6z.late_gens_p {
                            crate::prelude::Array::from(vec![(crate::prelude::Text::lit("numbered"), crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Cell")), crate::prelude::Array::from(vec![crate::lower::model::OutTy::OutBool])), crate::prelude::Text::lit("whether the row is numbered yet"))])
                        } else {
                            crate::prelude::Array::new()
                        }));
                        let number_inits_p1q = crate::prelude::append(&crate::prelude::each(&late_rows_p1o, &(|gd_p4t: &crate::lower::model::GenDef| (crate::prelude::Text::from(format!("{}_number", &gd_p4t.name_p)), crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::RefCell::new")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XNone]))))), &(if wx_p6z.late_gens_p {
                            crate::prelude::Array::from(vec![(crate::prelude::Text::lit("numbered"), crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Cell::new")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XBool(false)])))])
                        } else {
                            crate::prelude::Array::new()
                        }));
                        let now_steps_p1r = if wx_p6z.late_gens_p {
                            build_steps_f(&phase_of_f(&sinks_pdz, &crate::prelude::Nat::from(1u32)), &true)
                        } else {
                            crate::prelude::Array::new()
                        };
                        let later_steps_p1s = if wx_p6z.late_gens_p {
                            build_steps_f(&phase_of_f(&sinks_pdz, &crate::prelude::Nat::from(2u32)), &true)
                        } else {
                            crate::prelude::Array::new()
                        };
                        let late_generations_p1t = crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&crate::prelude::filter(&wx_p6z.build_p, &is_owner_link_f), &links_pvz), &late_numbering_f(&crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&later_steps_p1s, &crate::prelude::filter(&wx_p6z.build_p, &(|d_p4u: &crate::lower::model::Do| !is_owner_link_f(d_p4u)))), &subscribed_p11z), &announced_piz), &started_reg_puz))), &now_steps_p1r);
                        let after_node_p1u = crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&crate::prelude::filter(&wx_p6z.build_p, &is_owner_link_f), &rows_built_p10z), &crate::prelude::filter(&wx_p6z.build_p, &(|d_p4v: &crate::lower::model::Do| !is_owner_link_f(d_p4v)))), &subscribed_p11z), &announced_piz), &started_reg_puz);
                        ::prism_rtl::Turn::Finished(crate::lower::model::NodeDef { name_p: wx_p6z.node_p.clone(), prism_p: crate::check::types::bare_name_f(&qk_p1xz), doc_p: crate::lower::functions::definition_text_f(&wx_p6z.lx_p, &qk_p1xz), params_p: params_p2xz.clone(), fields_p: crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&wx_p6z.fields_p, &wakes_field_p1f), &gen_fields_p1h), &port_fields_p1j), &sub_fields_p1l), &number_fields_p1p), consts_p: crate::prelude::Array::new(), lets_p: wx_p6z.lets_p.clone(), inits_p: crate::prelude::append(&wx_p6z.inits_p, &crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&wx_p6z.moves_p, &wakes_init_p1g), &gen_inits_p1i), &port_inits_p1k), &crate::prelude::append(&sub_inits_p1m, &number_inits_p1q))), build_p: crate::prelude::append(&(if wx_p6z.late_gens_p {
                            late_generations_p1t.clone()
                        } else {
                            if wx_p6z.base_late_p {
                                late_numbering_f(&after_node_p1u)
                            } else {
                                after_node_p1u.clone()
                            }
                        }), &wx_p6z.numbered_by_p), fallible_p: fallible_p1n, methods_p: crate::prelude::append(&(if wx_p6z.base_late_p {
                            crate::prelude::Array::from(vec![number_places_f(&wx_p6z)])
                        } else {
                            crate::prelude::Array::new()
                        }), &crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&ev_methods_pez, &ev_above_pgz), &gather_ins_pfz), &in_above_phz), &heard_above_p1d), &place_getters_pjz), &wx_p6z.getters_p), &row_methods_p1a), &heard_p1c), &host_methods_p15z), &gathered_moved_p17z), &crate::prelude::append(&moved_method_p19, &place_methods_f(&wx_p6z)))), answers_p: crate::prelude::append(&crate::prelude::append(&answers_p13z, &forwards_p14z), &crate::lower::node_::switch_::wide_forward_f(&crate::prelude::filter(&wx_p6z.gens_p, &(|gd_p50: &crate::lower::model::GenDef| crate::lower::node_::switch_::is_wide_gen_f(gd_p50) && emits_f(&wx_p6z, &gd_p50.pos_p))))), hooks_p: hooks_ptz.clone(), builders_p: wx_p6z.builders_p.clone(), wakes_p: wakes_p8z, children_p: wx_p6z.rows_p.clone(), gens_p: crate::prelude::each(&wx_p6z.gens_p, &(|gd_p51: &crate::lower::model::GenDef| if crate::check::types::has_text_f(&wx_p6z.late_row_gens_p, &gd_p51.name_p) {
                            late_row_select_f(gd_p51)
                        } else {
                            gd_p51.clone()
                        })), subs_p: wx_p6z.subs_p.clone(), top_p: top_p1e.clone(), row_kind_p: if is_row_p3xz {
                            if is_gen_p5z {
                                crate::lower::model::RowKind::GenerationRow
                            } else {
                                crate::lower::model::RowKind::ForRow
                            }
                        } else {
                            crate::lower::model::RowKind::NotARow
                        }, hosted_p: hosted_methods_p18.clone() })
                    };
                    match wx_p6.hosted_by_o.clone() {
                        ::std::option::Option::Some(_) => crate::prelude::call_then(start_typed_dispatch_f(sinks_pd.clone(), crate::prelude::Text::lit("deliver"), crate::prelude::Nat::from(0u32)), move |typed_dispatch_f_25410: crate::lower::model::MethDef| k_let25349(crate::prelude::Array::from(vec![typed_dispatch_f_25410, document_getter_f(&wx_p6)]))),
                        ::std::option::Option::None => k_let25349(crate::prelude::Array::new()),
                    }
                })
            })
        })
    }
}

/// `Start FinishNode, x`: what the function value is when passed to `@Run`.
pub fn start_finish_node_f(wx0_p0: crate::lower::node_::Wx, qk_p1: crate::prelude::Text, params_p2: crate::prelude::Array<(crate::prelude::Text, crate::lower::model::OutTy)>, is_row_p3: bool) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::NodeDef>> {
    ::std::rc::Rc::new(FinishNode { wx0_p0, qk_p1, params_p2, is_row_p3 })
}

/// ```prism
/// IsGeneration: fn Wx, Text -> Bool
/// ```
pub fn is_generation_f(wx_p0: &crate::lower::node_::Wx, name_p1: &crate::prelude::Text) -> bool {
    &crate::prelude::len(&crate::prelude::filter(&wx_p0.gens_p, &(|gd_p2: &crate::lower::model::GenDef| &gd_p2.name_p == name_p1))) > &crate::prelude::Nat::from(0u32)
}

/// ```prism
/// FlattenMethods: fn Sinks -> [MethDef]
/// ```
pub fn flatten_methods_f(sk_p0: &Sinks) -> crate::prelude::Array<crate::lower::model::MethDef> {
    let wx_p1 = sk_p0.wx_p.clone();
    let entries_p2 = crate::prelude::fold(&crate::prelude::filter(&wx_p1.flattens_p, &(|fl_p9: &crate::lower::node_::FlatDef| (&fl_p9.generation_p == &crate::prelude::Text::lit("")) && !fl_p9.held_p)), &crate::prelude::Array::new(), &(|acc_pa: &crate::prelude::Array<crate::lower::model::MethDef>, fl_pb: &crate::lower::node_::FlatDef| {
        let set_pc = crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::from(format!("{}_inner", &fl_pb.name_p)))), crate::prelude::Text::lit("set"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Some")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::lit("entry"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx]))])), crate::lower::model::Ex::XCx])));
        let followed_pd = crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::from(format!("{}_follow", &fl_pb.name_p)))), crate::prelude::Text::lit("follow"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::lit("entry"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx]))), crate::prelude::Text::lit("updates")))), crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XSelf)))), crate::lower::model::Ex::XPath(crate::lower::model::ref_child_f(&crate::lower::site_ref_f(&wx_p1.lx_p, &wx_p1.node_p), &crate::prelude::Text::from(format!("{}_moved", &fl_pb.name_p))))])));
        let moved_pe = crate::lower::model::MethDef { name_p: crate::prelude::Text::from(format!("{}_moved", &fl_pb.name_p)), recv_p: crate::lower::model::Recv::RecvRc, params_p: crate::prelude::Array::new(), cx_p: crate::lower::model::CxArg::CxMut, ret_p: crate::lower::model::OutTy::OutUnit, body_p: hold_written_f(sk_p0, &crate::prelude::Text::from(format!("{}_inner", &fl_pb.name_p))), tail_p: crate::lower::model::Ex::XUnit, doc_p: crate::prelude::Text::from(format!("`{}`\'s inner moved: what reads it reads it again.", &fl_pb.name_p)) };
        let replaced_pf = crate::lower::model::MethDef { name_p: crate::prelude::Text::from(format!("{}_replaced", &fl_pb.name_p)), recv_p: crate::lower::model::Recv::RecvRc, params_p: crate::prelude::Array::new(), cx_p: crate::lower::model::CxArg::CxMut, ret_p: crate::lower::model::OutTy::OutUnit, body_p: adoption_f(fl_pb), tail_p: crate::lower::model::Ex::XUnit, doc_p: crate::prelude::Text::from(format!("The `for`\'s builder found another dynamic than `{}`\'s inner under this row\'s key: the adoption is queued for the first firings of the next tick, which is owed (Semantics ch. 4).", &fl_pb.name_p)) };
        let adopt_pg = crate::lower::model::MethDef { name_p: crate::prelude::Text::from(format!("{}_adopt", &fl_pb.name_p)), recv_p: crate::lower::model::Recv::RecvRc, params_p: crate::prelude::Array::new(), cx_p: crate::lower::model::CxArg::CxMut, ret_p: crate::lower::model::OutTy::OutUnit, body_p: crate::prelude::append(&crate::prelude::Array::from(vec![set_pc.clone(), followed_pd.clone()]), &hold_written_f(sk_p0, &crate::prelude::Text::from(format!("{}_inner", &fl_pb.name_p)))), tail_p: crate::lower::model::Ex::XUnit, doc_p: crate::prelude::Text::from(format!("`{}` adopts the dynamic under its row\'s key as the tick before left it, among this tick\'s first firings: from here on it reads that inner (Semantics ch. 4).", &fl_pb.name_p)) };
        crate::prelude::append(acc_pa, &crate::prelude::Array::from(vec![moved_pe.clone(), replaced_pf.clone(), adopt_pg.clone()]))
    }));
    let adopts0_p3 = crate::prelude::each(&crate::prelude::filter(&wx_p1.flattens_p, &(|fl_ph: &crate::lower::node_::FlatDef| &fl_ph.generation_p != &crate::prelude::Text::lit(""))), &(|fl_pi: &crate::lower::node_::FlatDef| {
        let set_pj = crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::from(format!("{}_inner", &fl_pi.name_p)))), crate::prelude::Text::lit("set"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Some")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), fl_pi.outer_p.clone(), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx]))])), crate::lower::model::Ex::XCx])));
        crate::lower::model::MethDef { name_p: crate::prelude::Text::from(format!("{}_adopt", &fl_pi.name_p)), recv_p: crate::lower::model::Recv::RecvRc, params_p: crate::prelude::Array::new(), cx_p: crate::lower::model::CxArg::CxMut, ret_p: crate::lower::model::OutTy::OutUnit, body_p: crate::prelude::append(&crate::prelude::Array::from(vec![set_pj.clone()]), &hold_written_f(sk_p0, &crate::prelude::Text::from(format!("{}_inner", &fl_pi.name_p)))), tail_p: crate::lower::model::Ex::XUnit, doc_p: crate::prelude::Text::lit("`@Flatten` adopts the inner its `rebuild`\'s dynamic held after the tick before, among this tick\'s first firings: from here on it reads that inner (Semantics ch. 7).") }
    }));
    let held_p4 = crate::prelude::fold(&crate::prelude::filter(&wx_p1.flattens_p, &(|fl_pk: &crate::lower::node_::FlatDef| fl_pk.held_p)), &crate::prelude::Array::new(), &(|acc_pl: &crate::prelude::Array<crate::lower::model::MethDef>, fl_pm: &crate::lower::node_::FlatDef| {
        let inner_now_pn = crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::from(format!("{}_inner", &fl_pm.name_p)))), crate::prelude::Text::lit("get"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx]))), crate::prelude::Text::lit("expect"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XStr(crate::prelude::Text::lit("`@Flatten` adopts its first inner at the build"))]));
        let set_po = crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::from(format!("{}_inner", &fl_pm.name_p)))), crate::prelude::Text::lit("set"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Some")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), fl_pm.outer_p.clone())), crate::prelude::Text::lit("sample"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx]))])), crate::lower::model::Ex::XCx])));
        let followed_pp = crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::from(format!("{}_follow", &fl_pm.name_p)))), crate::prelude::Text::lit("follow"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(inner_now_pn.clone()), crate::prelude::Text::lit("updates")))), crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XSelf)))), crate::lower::model::Ex::XPath(crate::lower::model::ref_child_f(&crate::lower::site_ref_f(&wx_p1.lx_p, &wx_p1.node_p), &crate::prelude::Text::from(format!("{}_moved", &fl_pm.name_p))))])));
        let moved_pq = crate::lower::model::MethDef { name_p: crate::prelude::Text::from(format!("{}_moved", &fl_pm.name_p)), recv_p: crate::lower::model::Recv::RecvRc, params_p: crate::prelude::Array::new(), cx_p: crate::lower::model::CxArg::CxMut, ret_p: crate::lower::model::OutTy::OutUnit, body_p: hold_written_f(sk_p0, &crate::prelude::Text::from(format!("{}_inner", &fl_pm.name_p))), tail_p: crate::lower::model::Ex::XUnit, doc_p: crate::prelude::Text::from(format!("`{}`\'s inner moved: what reads it reads it again.", &fl_pm.name_p)) };
        let outer_moved_pr = crate::lower::model::MethDef { name_p: crate::prelude::Text::from(format!("{}_outer_moved", &fl_pm.name_p)), recv_p: crate::lower::model::Recv::RecvRc, params_p: crate::prelude::Array::new(), cx_p: crate::lower::model::CxArg::CxMut, ret_p: crate::lower::model::OutTy::OutUnit, body_p: adoption_f(fl_pm), tail_p: crate::lower::model::Ex::XUnit, doc_p: crate::prelude::Text::from(format!("`{}`\'s outer fired: the adoption is queued for the first firings of the next tick, which is owed (the Compiler seed, `@Flatten`).", &fl_pm.name_p)) };
        let adopt_ps = crate::lower::model::MethDef { name_p: crate::prelude::Text::from(format!("{}_adopt", &fl_pm.name_p)), recv_p: crate::lower::model::Recv::RecvRc, params_p: crate::prelude::Array::new(), cx_p: crate::lower::model::CxArg::CxMut, ret_p: crate::lower::model::OutTy::OutUnit, body_p: crate::prelude::append(&crate::prelude::Array::from(vec![set_po.clone(), followed_pp.clone()]), &hold_written_f(sk_p0, &crate::prelude::Text::from(format!("{}_inner", &fl_pm.name_p)))), tail_p: crate::lower::model::Ex::XUnit, doc_p: crate::prelude::Text::from(format!("`{}` adopts the inner its outer held after the tick before, among this tick\'s first firings, and fires: no dynamics are compared (ruling FV).", &fl_pm.name_p)) };
        crate::prelude::append(acc_pl, &crate::prelude::Array::from(vec![moved_pq.clone(), outer_moved_pr.clone(), adopt_ps.clone()]))
    }));
    let adopts_p5 = crate::prelude::append(&crate::prelude::append(&adopts0_p3, &entries_p2), &held_p4);
    let dyn_gens_p6 = crate::prelude::filter(&wx_p1.gens_p, &(|gd_pt: &crate::lower::model::GenDef| &crate::prelude::len(&crate::prelude::filter(&wx_p1.snaps_p, &(|sn_pu: &crate::lower::node_::SnapDef| (&sn_pu.builder_p == &gd_pt.name_p) && is_dyn_ty_f(&sn_pu.ty_p)))) > &crate::prelude::Nat::from(0u32)));
    let moved_p7 = crate::prelude::each(&dyn_gens_p6, &(|gd_pv: &crate::lower::model::GenDef| {
        let marks_p10 = crate::prelude::fold(&crate::prelude::filter(&wx_p1.flattens_p, &(|fl_p15: &crate::lower::node_::FlatDef| &fl_p15.generation_p == &gd_pv.name_p)), &crate::prelude::Array::new(), &(|acc_p16: &crate::prelude::Array<crate::lower::model::Do>, fl_p17: &crate::lower::node_::FlatDef| crate::prelude::append(acc_p16, &hold_written_f(sk_p0, &crate::prelude::Text::from(format!("{}_inner", &fl_p17.name_p))))));
        let live_p11 = crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::from(format!("{}_result_live", &gd_pv.name_p)))), crate::prelude::Text::lit("borrow"), crate::prelude::Array::new())), crate::prelude::Text::lit("as_ref"), crate::prelude::Array::new());
        let port_p12 = crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("d"))), crate::prelude::Text::lit("updates"));
        let fire_p13 = crate::lower::model::Ex::XCall(crate::lower::helper_ref_f(&crate::prelude::Text::lit("no_fault")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XMethod(::std::rc::Rc::new(port_p12.clone()), crate::prelude::Text::lit("fire"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XUnit, crate::lower::model::Ex::XCx]))]));
        let fired_p14 = crate::lower::model::Do::DoIfLet(crate::lower::model::Pa::PaCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Some")), crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("d"))])), live_p11.clone(), crate::prelude::Array::from(vec![crate::lower::model::Do::DoExpr(fire_p13.clone())]), crate::prelude::Array::new());
        crate::lower::model::MethDef { name_p: crate::prelude::Text::from(format!("{}_result_moved", &gd_pv.name_p)), recv_p: crate::lower::model::Recv::RecvRc, params_p: crate::prelude::Array::new(), cx_p: crate::lower::model::CxArg::CxMut, ret_p: crate::lower::model::OutTy::OutUnit, body_p: crate::prelude::push(&marks_p10, &fired_p14), tail_p: crate::lower::model::Ex::XUnit, doc_p: crate::prelude::Text::lit("The current generation\'s result moved: what reads a `@Flatten` over it reads it again, and the dynamic kept for it fires its update event for whoever follows it outside this node.") }
    }));
    let clause_moved_p8 = crate::prelude::each(&wx_p1.clause_results_p, &(|n_p18: &crate::prelude::Text| crate::lower::model::MethDef { name_p: crate::prelude::Text::from(format!("{}_result_moved", n_p18)), recv_p: crate::lower::model::Recv::RecvRc, params_p: crate::prelude::Array::new(), cx_p: crate::lower::model::CxArg::CxMut, ret_p: crate::lower::model::OutTy::OutUnit, body_p: hold_written_f(sk_p0, &crate::prelude::Text::from(format!("{}_res", n_p18))), tail_p: crate::lower::model::Ex::XUnit, doc_p: crate::prelude::Text::lit("A write behind the clause\'s dynamic result: what reads it reads it again.") }));
    crate::prelude::append(&crate::prelude::append(&adopts_p5, &moved_p7), &clause_moved_p8)
}

/// ```prism
/// IsDynTy: fn OutTy -> Bool
/// ```
pub fn is_dyn_ty_f(out_ty0: &crate::lower::model::OutTy) -> bool {
    match out_ty0 {
        crate::lower::model::OutTy::OutDyn(_) => true,
        other_p0 => false,
    }
}

/// ```prism
/// HostMoved: fn Sinks, HostDef -> MethDef
/// ```
pub fn host_moved_f(sk_p0: &Sinks, h_p1: &crate::lower::node_::HostDef) -> crate::lower::model::MethDef {
    crate::lower::model::MethDef { name_p: crate::prelude::Text::from(format!("{}_moved", &h_p1.name_p)), recv_p: crate::lower::model::Recv::RecvRc, params_p: crate::prelude::Array::new(), cx_p: crate::lower::model::CxArg::CxMut, ret_p: crate::lower::model::OutTy::OutUnit, body_p: hold_written_f(sk_p0, &crate::prelude::Text::from(format!("{}_doc_now", &h_p1.name_p))), tail_p: crate::lower::model::Ex::XUnit, doc_p: crate::prelude::Text::from(format!("A node of the child hosted at place {} wrote behind its document: the structure is marked as for a write of a hold it reads (pick HO), the snapshot listed to be taken; the program\'s `$doc` moves when it is published, the tick after (pick ST).", &crate::lower::model::place_text_f(&h_p1.pos_p))) }
}

/// ```prism
/// BuildSteps: fn Sinks, Bool -> [Do]
/// ```
pub fn build_steps_f(sk_p0: &Sinks, at_build_p1: &bool) -> crate::prelude::Array<crate::lower::model::Do> {
    let wx_p2 = sk_p0.wx_p.clone();
    crate::prelude::fold(&crate::check::errors::range0_f(&(&crate::prelude::len(&wx_p2.scopes_p) + &crate::prelude::Nat::from(1u32))), &crate::prelude::Array::new(), &(|acc_p3: &crate::prelude::Array<crate::lower::model::Do>, i_p4: &crate::prelude::Nat| {
        let k_p5 = crate::prelude::or(&(&crate::prelude::len(&wx_p2.scopes_p)).checked_sub(i_p4), &crate::prelude::Nat::from(0u32));
        if crate::check::types::has_nat_f(&wx_p2.late_hosts_p, &k_p5) || ((&wx_p2.gen_phase_p == &crate::prelude::Nat::from(1u32)) && (&k_p5 != &crate::prelude::Nat::from(0u32))) {
            acc_p3.clone()
        } else {
            crate::prelude::append(acc_p3, &scope_steps_f(sk_p0, at_build_p1, &k_p5, &(&crate::prelude::len(&wx_p2.scopes_p) + &crate::prelude::Nat::from(1u32))))
        }
    }))
}

/// ```prism
/// ScopeSteps: fn Sinks, Bool, Nat, Nat -> [Do]
/// ```
pub fn scope_steps_f(sk_p0: &Sinks, at_build_p1: &bool, k_p2: &crate::prelude::Nat, fuel_p3: &crate::prelude::Nat) -> crate::prelude::Array<crate::lower::model::Do> {
    match fuel_p3.checked_sub(&crate::prelude::Nat::from(1u32)) {
        ::std::option::Option::None => crate::prelude::Array::new(),
        ::std::option::Option::Some(less_p4) => {
            let wx_p5 = sk_p0.wx_p.clone();
            let recv_p6 = if *at_build_p1 {
                crate::lower::model::Ex::XVar(crate::prelude::Text::lit("node"))
            } else {
                crate::lower::model::Ex::XSelf
            };
            let take_f7 = {
                let at_build_p1x = *at_build_p1;
                let sk_p0x = sk_p0.clone();
                ::std::rc::Rc::new(move |sn_pn: &crate::lower::node_::SnapDef| if at_build_p1x { snap_take_at_build_f(sn_pn) } else { snap_take_f(&sk_p0x, sn_pn) }) as ::std::rc::Rc<dyn ::std::ops::Fn(&crate::lower::node_::SnapDef) -> crate::lower::model::Do>
            };
            let late_child_f8 = {
                let wx_p5x = wx_p5.clone();
                let at_build_p1x = *at_build_p1;
                let sk_p0x = sk_p0.clone();
                let less_p4x = less_p4.clone();
                ::std::rc::Rc::new(move |b_po: &crate::lower::model::ForDef| crate::prelude::fold(&wx_p5x.hosts_p, &crate::prelude::Array::new(), &(|a_pp: &crate::prelude::Array<crate::lower::model::Do>, h_pq: &crate::lower::node_::HostDef| if (&crate::prelude::Text::from(format!("{}_rows", &h_pq.name_p)) == &b_po.name_p) && crate::check::types::has_nat_f(&wx_p5x.late_hosts_p, &h_pq.scope_p) {
                    crate::prelude::append(&crate::prelude::append(a_pp, &(if at_build_p1x {
                        crate::prelude::fold(&crate::prelude::append(&wx_p5x.late_firsts_p, &wx_p5x.late_starts_p), &crate::prelude::Array::new(), &(|firsts_pr: &crate::prelude::Array<crate::lower::model::Do>, (scope_ps, dos_pt): &(crate::prelude::Nat, crate::prelude::Array<crate::lower::model::Do>)| if scope_ps == &h_pq.scope_p {
                            crate::prelude::append(firsts_pr, dos_pt)
                        } else {
                            firsts_pr.clone()
                        }))
                    } else {
                        crate::prelude::Array::new()
                    })), &scope_steps_f(&sk_p0x, &at_build_p1x, &h_pq.scope_p, &less_p4x))
                } else {
                    a_pp.clone()
                }))) as ::std::rc::Rc<dyn ::std::ops::Fn(&crate::lower::model::ForDef) -> crate::prelude::Array<crate::lower::model::Do>>
            };
            let builder_f9 = {
                let wx_p5x = wx_p5.clone();
                let take_f7x = take_f7.clone();
                let at_build_p1x = *at_build_p1;
                let recv_p6x = recv_p6.clone();
                let late_child_f8x = late_child_f8.clone();
                ::std::rc::Rc::new(move |b_pu: &crate::lower::model::ForDef| {
                    let before_pv = crate::prelude::each(&crate::prelude::filter(&wx_p5x.snaps_p, &(|sn_p12: &crate::lower::node_::SnapDef| sn_p12.before_p && (&sn_p12.builder_p == &b_pu.name_p))), &*take_f7x);
                    let after_p10 = crate::prelude::each(&crate::prelude::filter(&wx_p5x.snaps_p, &(|sn_p13: &crate::lower::node_::SnapDef| !sn_p13.before_p && (&sn_p13.builder_p == &b_pu.name_p))), &*take_f7x);
                    let placed_p11 = if !at_build_p1x {
                        crate::prelude::Array::new()
                    } else {
                        crate::prelude::fold(&wx_p5x.hosts_p, &crate::prelude::Array::new(), &(|a_p14: &crate::prelude::Array<crate::lower::model::Do>, h_p15: &crate::lower::node_::HostDef| if (&crate::prelude::Text::from(format!("{}_rows", &h_p15.name_p)) == &b_pu.name_p) && crate::check::types::has_text_f(&wx_p5x.unplaced_hosts_p, &h_p15.name_p) {
                            crate::prelude::push(a_p14, &crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(recv_p6x.clone()), h_p15.name_p.clone())), crate::prelude::Text::lit("place_at"), crate::prelude::Array::from(vec![place_at_f(&wx_p5x, &crate::prelude::Text::lit("node"), &h_p15.pos_p)]))))
                        } else {
                            a_p14.clone()
                        }))
                    };
                    if &wx_p5x.gen_phase_p == &crate::prelude::Nat::from(1u32) {
                        crate::prelude::Array::new()
                    } else {
                        crate::prelude::append(&placed_p11, &crate::prelude::append(&(&late_child_f8x)(b_pu), &crate::prelude::append(&crate::prelude::push(&before_pv, &crate::lower::model::Do::DoExpr(crate::lower::expr::try_of_f(&crate::lower::model::Ex::XMethod(::std::rc::Rc::new(recv_p6x.clone()), crate::prelude::Text::from(format!("{}_build", &b_pu.name_p)), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx]))))), &after_p10)))
                    }
                }) as ::std::rc::Rc<dyn ::std::ops::Fn(&crate::lower::model::ForDef) -> crate::prelude::Array<crate::lower::model::Do>>
            };
            let gen_fa = {
                let at_build_p1x = *at_build_p1;
                let wx_p5x = wx_p5.clone();
                let recv_p6x = recv_p6.clone();
                let k_p2x = k_p2.clone();
                let take_f7x = take_f7.clone();
                ::std::rc::Rc::new(move |gd_p16: &crate::lower::model::GenDef| {
                    let built_p17 = if at_build_p1x && gd_p16.early_p {
                        if crate::check::types::has_text_f(&wx_p5x.late_numbered_p, &gd_p16.name_p) {
                            crate::lower::model::Do::DoExpr(crate::lower::expr::try_of_f(&crate::lower::model::Ex::XApply(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::from(format!("{}_number", &gd_p16.name_p)))), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx]))))
                        } else {
                            crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XUnit)
                        }
                    } else {
                        if at_build_p1x {
                            crate::lower::model::Do::DoExpr(crate::lower::expr::try_of_f(&crate::lower::model::Ex::XMethod(::std::rc::Rc::new(recv_p6x.clone()), crate::prelude::Text::from(format!("{}_build", &gd_p16.name_p)), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx]))))
                        } else {
                            crate::lower::model::Do::DoIf(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::from(format!("{}_stale", &gd_p16.name_p)))), crate::prelude::Text::lit("replace"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XBool(false)])), crate::prelude::Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::expr::try_of_f(&crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::from(format!("{}_build", &gd_p16.name_p)), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx]))))]), crate::prelude::Array::new())
                        }
                    };
                    let late_row_p18 = (&k_p2x == &crate::prelude::Nat::from(0u32)) && crate::check::types::has_text_f(&wx_p5x.late_row_gens_p, &gd_p16.name_p);
                    if (&wx_p5x.gen_phase_p == &crate::prelude::Nat::from(1u32)) && !late_row_p18 {
                        crate::prelude::Array::new()
                    } else {
                        if (&wx_p5x.gen_phase_p == &crate::prelude::Nat::from(2u32)) && late_row_p18 {
                            crate::prelude::Array::from(vec![number_taken_f(&recv_p6x, &gd_p16.name_p)])
                        } else {
                            crate::prelude::append(&crate::prelude::Array::from(vec![built_p17.clone()]), &crate::prelude::each(&crate::prelude::filter(&wx_p5x.snaps_p, &(|sn_p19: &crate::lower::node_::SnapDef| !sn_p19.before_p && (&sn_p19.builder_p == &gd_p16.name_p))), &*take_f7x))
                        }
                    }
                }) as ::std::rc::Rc<dyn ::std::ops::Fn(&crate::lower::model::GenDef) -> crate::prelude::Array<crate::lower::model::Do>>
            };
            let entries_pb = if *at_build_p1 && (&wx_p5.gen_phase_p != &crate::prelude::Nat::from(1u32)) {
                crate::prelude::each(&crate::prelude::filter(&wx_p5.places_p, &(|pl_p1a: &crate::lower::node_::Place| ((&pl_p1a.pos_p.scope_p == k_p2) && (&pl_p1a.entry_p != &crate::prelude::Text::lit(""))) && (&pl_p1a.getter_p != &crate::prelude::Text::lit("")))), &(|pl_p1b: &crate::lower::node_::Place| entry_take_f(&recv_p6, pl_p1b)))
            } else {
                crate::prelude::Array::new()
            };
            let host_reads_fc = {
                let wx_p5x = wx_p5.clone();
                ::std::rc::Rc::new(move |b_p1c: &crate::lower::model::ForDef| crate::prelude::fold(&wx_p5x.hosts_p, &crate::prelude::Array::new(), &(|acc_p1d: &crate::prelude::Array<crate::lower::node_::Read>, h_p1e: &crate::lower::node_::HostDef| if (&crate::prelude::Text::from(format!("{}_rows", &h_p1e.name_p)) != &b_p1c.name_p) || !crate::check::types::has_nat_f(&wx_p5x.late_hosts_p, &h_p1e.scope_p) {
                    acc_p1d.clone()
                } else {
                    crate::prelude::fold(&wx_p5x.dyn_answers_p, acc_p1d, &(|acc2_p1f: &crate::prelude::Array<crate::lower::node_::Read>, (name_p1g, reads_p1h): &(crate::prelude::Text, crate::prelude::Array<crate::lower::node_::Read>)| if crate::syntax::lexer::chars::has_prefix_f(name_p1g, &crate::prelude::Text::from(format!("{}_dyn_", &h_p1e.name_p))) {
                        crate::lower::node_::union_reads_f(acc2_p1f, reads_p1h)
                    } else {
                        acc2_p1f.clone()
                    }))
                }))) as ::std::rc::Rc<dyn ::std::ops::Fn(&crate::lower::model::ForDef) -> crate::prelude::Array<crate::lower::node_::Read>>
            };
            let source_reads_fd = {
                let wx_p5x = wx_p5.clone();
                ::std::rc::Rc::new(move |name_p1i: &crate::prelude::Text| crate::prelude::or(&crate::prelude::get(&wx_p5x.dyn_reads_p, &crate::prelude::Text::from(format!("{}_source", name_p1i))), &crate::prelude::Array::new())) as ::std::rc::Rc<dyn ::std::ops::Fn(&crate::prelude::Text) -> crate::prelude::Array<crate::lower::node_::Read>>
            };
            let gen_reads_fe = {
                let wx_p5x = wx_p5.clone();
                ::std::rc::Rc::new(move |name_p1j: &crate::prelude::Text| crate::prelude::fold(&wx_p5x.gen_holds_p, &crate::prelude::Array::new(), &(|acc_p1k: &crate::prelude::Array<crate::lower::node_::Read>, (held_p1l, reads_p1m): &(crate::prelude::Text, crate::prelude::Array<crate::lower::node_::Read>)| if held_p1l == name_p1j {
                    crate::lower::node_::union_reads_f(acc_p1k, reads_p1m)
                } else {
                    acc_p1k.clone()
                }))) as ::std::rc::Rc<dyn ::std::ops::Fn(&crate::prelude::Text) -> crate::prelude::Array<crate::lower::node_::Read>>
            };
            let builders_read_ff = {
                let wx_p5x = wx_p5.clone();
                ::std::rc::Rc::new(move |reads_p1n: &crate::prelude::Array<crate::lower::node_::Read>| crate::prelude::fold(&reads_closed_f(&wx_p5x.dyn_reads_p, reads_p1n), &crate::prelude::Array::new(), &(|acc_p1o: &crate::prelude::Array<crate::prelude::Text>, r_p1p: &crate::lower::node_::Read| match r_p1p {
                    crate::lower::node_::Read::OwnRead(f_p1q) => crate::prelude::fold(&wx_p5x.snaps_p, acc_p1o, &(|acc2_p1r: &crate::prelude::Array<crate::prelude::Text>, sn_p1s: &crate::lower::node_::SnapDef| if (&sn_p1s.name_p != f_p1q) && (&sn_p1s.live_p != f_p1q) {
                        acc2_p1r.clone()
                    } else {
                        crate::check::types::add_text_f(acc2_p1r, &sn_p1s.builder_p)
                    })),
                    crate::lower::node_::Read::ParentRead(_) => acc_p1o.clone(),
                }))) as ::std::rc::Rc<dyn ::std::ops::Fn(&crate::prelude::Array<crate::lower::node_::Read>) -> crate::prelude::Array<crate::prelude::Text>>
            };
            let numbered_after_fg = {
                let at_build_p1x = *at_build_p1;
                let wx_p5x = wx_p5.clone();
                ::std::rc::Rc::new(move |gd_p1t: &crate::lower::model::GenDef| if at_build_p1x && crate::check::types::has_text_f(&wx_p5x.late_numbered_p, &gd_p1t.name_p) {
                    crate::prelude::each(&crate::prelude::filter(&gaps_before_f(&wx_p5x, &gd_p1t.pos_p), &(|other_p1u: &crate::lower::model::GenDef| !other_p1u.early_p || crate::check::types::has_text_f(&wx_p5x.late_numbered_p, &other_p1u.name_p))), &(|other_p1v: &crate::lower::model::GenDef| other_p1v.name_p.clone()))
                } else {
                    crate::prelude::Array::new()
                }) as ::std::rc::Rc<dyn ::std::ops::Fn(&crate::lower::model::GenDef) -> crate::prelude::Array<crate::prelude::Text>>
            };
            let deferred_fh = {
                let wx_p5x = wx_p5.clone();
                ::std::rc::Rc::new(move |gd_p20: &crate::lower::model::GenDef| crate::check::types::has_text_f(&wx_p5x.deferred_gens_p, &gd_p20.name_p) || (crate::check::types::has_text_f(&wx_p5x.late_numbered_p, &gd_p20.name_p) && (&crate::prelude::len(&crate::prelude::filter(&gaps_before_f(&wx_p5x, &gd_p20.pos_p), &(|other_p21: &crate::lower::model::GenDef| crate::check::types::has_text_f(&wx_p5x.deferred_gens_p, &other_p21.name_p)))) > &crate::prelude::Nat::from(0u32)))) as ::std::rc::Rc<dyn ::std::ops::Fn(&crate::lower::model::GenDef) -> bool>
            };
            let steps0_pi = crate::prelude::append(&crate::prelude::each(&crate::prelude::filter(&wx_p5.builders_p, &(|b_p22: &crate::lower::model::ForDef| &b_p22.pos_p.scope_p == k_p2)), &(|b_p23: &crate::lower::model::ForDef| (b_p23.name_p.clone(), b_p23.pos_p.at_p.clone(), crate::prelude::Nat::from(0u32), (&builders_read_ff)(&crate::lower::node_::union_reads_f(&(&host_reads_fc)(b_p23), &(&source_reads_fd)(&b_p23.name_p))), (&builder_f9)(b_p23)))), &crate::prelude::each(&crate::prelude::filter(&wx_p5.gens_p, &(|gd_p24: &crate::lower::model::GenDef| (&gd_p24.pos_p.scope_p == k_p2) && !(&deferred_fh)(gd_p24))), &(|gd_p25: &crate::lower::model::GenDef| (gd_p25.name_p.clone(), gd_p25.pos_p.at_p.clone(), crate::prelude::Nat::from(0u32), crate::prelude::fold(&(&numbered_after_fg)(gd_p25), &(&builders_read_ff)(&(&gen_reads_fe)(&gd_p25.name_p)), &crate::check::types::add_text_f), (&gen_fa)(gd_p25)))));
            let settle_fj = ::std::rc::Rc::new(move |steps_p26: &crate::prelude::Array<(crate::prelude::Text, crate::prelude::Nat, crate::prelude::Nat, crate::prelude::Array<crate::prelude::Text>, crate::prelude::Array<crate::lower::model::Do>)>| crate::prelude::each(steps_p26, &(|(name_p27, at_p28, rank_p29, waits_p2a, dos_p2b): &(crate::prelude::Text, crate::prelude::Nat, crate::prelude::Nat, crate::prelude::Array<crate::prelude::Text>, crate::prelude::Array<crate::lower::model::Do>)| {
                let (at2_p2h, rank2_p2i) = crate::prelude::fold(steps_p26, &(at_p28.clone(), rank_p29.clone()), &(|(a_p2c, r_p2d): &(crate::prelude::Nat, crate::prelude::Nat), (other_p2e, other_at_p2f, other_rank_p2g, _, _): &(crate::prelude::Text, crate::prelude::Nat, crate::prelude::Nat, crate::prelude::Array<crate::prelude::Text>, crate::prelude::Array<crate::lower::model::Do>)| if (other_p2e == name_p27) || !crate::check::types::has_text_f(waits_p2a, other_p2e) {
                    (a_p2c.clone(), r_p2d.clone())
                } else {
                    if (other_at_p2f > a_p2c) || ((other_at_p2f == a_p2c) && (other_rank_p2g >= r_p2d)) {
                        (other_at_p2f.clone(), other_rank_p2g + &crate::prelude::Nat::from(1u32))
                    } else {
                        (a_p2c.clone(), r_p2d.clone())
                    }
                }));
                (name_p27.clone(), at2_p2h.clone(), rank2_p2i.clone(), waits_p2a.clone(), dos_p2b.clone())
            }))) as ::std::rc::Rc<dyn ::std::ops::Fn(&crate::prelude::Array<(crate::prelude::Text, crate::prelude::Nat, crate::prelude::Nat, crate::prelude::Array<crate::prelude::Text>, crate::prelude::Array<crate::lower::model::Do>)>) -> crate::prelude::Array<(crate::prelude::Text, crate::prelude::Nat, crate::prelude::Nat, crate::prelude::Array<crate::prelude::Text>, crate::prelude::Array<crate::lower::model::Do>)>>;
            let steps_pk = crate::prelude::fold(&crate::check::errors::range0_f(&crate::prelude::len(&steps0_pi)), &steps0_pi, &(|acc_p2j: &crate::prelude::Array<(crate::prelude::Text, crate::prelude::Nat, crate::prelude::Nat, crate::prelude::Array<crate::prelude::Text>, crate::prelude::Array<crate::lower::model::Do>)>, _: &crate::prelude::Nat| (&settle_fj)(acc_p2j)));
            let deferred_pl = crate::prelude::fold(&crate::prelude::filter(&wx_p5.gens_p, &(|gd_p2k: &crate::lower::model::GenDef| (&gd_p2k.pos_p.scope_p == k_p2) && (&deferred_fh)(gd_p2k))), &crate::prelude::Array::new(), &(|a_p2l: &crate::prelude::Array<crate::lower::model::Do>, gd_p2m: &crate::lower::model::GenDef| crate::prelude::append(a_p2l, &(&gen_fa)(gd_p2m))));
            let ordered_pm = crate::prelude::fold(&sort_nats_f(&crate::prelude::fold(&steps_pk, &crate::prelude::Array::new(), &(|seen_p2n: &crate::prelude::Array<crate::prelude::Nat>, (_, at_p2o, _, _, _): &(crate::prelude::Text, crate::prelude::Nat, crate::prelude::Nat, crate::prelude::Array<crate::prelude::Text>, crate::prelude::Array<crate::lower::model::Do>)| if &crate::prelude::len(&crate::prelude::filter(seen_p2n, &(|y_p2p: &crate::prelude::Nat| y_p2p == at_p2o))) == &crate::prelude::Nat::from(0u32) {
                crate::prelude::push(seen_p2n, at_p2o)
            } else {
                seen_p2n.clone()
            }))), &crate::prelude::Array::new(), &(|a_p2q: &crate::prelude::Array<crate::lower::model::Do>, at_p2r: &crate::prelude::Nat| crate::prelude::fold(&crate::check::errors::range0_f(&(&(&crate::prelude::Nat::from(2u32) * &crate::prelude::len(&steps_pk)) + &crate::prelude::Nat::from(2u32))), a_p2q, &(|a1_p2s: &crate::prelude::Array<crate::lower::model::Do>, rank_p2t: &crate::prelude::Nat| crate::prelude::fold(&steps_pk, a1_p2s, &(|a2_p2u: &crate::prelude::Array<crate::lower::model::Do>, (_, at2_p2v, rank2_p30, _, dos_p31): &(crate::prelude::Text, crate::prelude::Nat, crate::prelude::Nat, crate::prelude::Array<crate::prelude::Text>, crate::prelude::Array<crate::lower::model::Do>)| if (at2_p2v == at_p2r) && (rank2_p30 == rank_p2t) {
                crate::prelude::append(a2_p2u, dos_p31)
            } else {
                a2_p2u.clone()
            }))))));
            crate::prelude::append(&crate::prelude::append(&ordered_pm, &deferred_pl), &entries_pb)
        },
    }
}

/// ```prism
/// EntryTake: fn Ex, Place -> Do
/// ```
pub fn entry_take_f(recv_p0: &crate::lower::model::Ex, pl_p1: &crate::lower::node_::Place) -> crate::lower::model::Do {
    crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(recv_p0.clone()), pl_p1.entry_p.clone())), crate::prelude::Text::lit("take"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XMethod(::std::rc::Rc::new(recv_p0.clone()), pl_p1.getter_p.clone(), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx])), crate::lower::model::Ex::XCx])))
}

/// ```prism
/// SnapTakeAtBuild: fn SnapDef -> Do
/// ```
pub fn snap_take_at_build_f(sn_p0: &crate::lower::node_::SnapDef) -> crate::lower::model::Do {
    crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("node"))), crate::prelude::Text::from(format!("{}_snap", &sn_p0.name_p)))), crate::prelude::Text::lit("take"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("node"))), crate::prelude::Text::from(format!("{}_now", &sn_p0.name_p)), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx])), crate::lower::model::Ex::XCx])))
}

/// ```prism
/// SnapTake: fn Sinks, SnapDef -> Do
/// ```
pub fn snap_take_f(sk_p0: &Sinks, sn_p1: &crate::lower::node_::SnapDef) -> crate::lower::model::Do {
    let now_p2 = crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::from(format!("{}_now", &sn_p1.name_p)), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx]));
    let take_p3 = crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::from(format!("{}_snap", &sn_p1.name_p)))), if sn_p1.eq_p {
        crate::prelude::Text::lit("take_compared")
    } else {
        crate::prelude::Text::lit("take")
    }, crate::prelude::Array::from(vec![now_p2.clone(), crate::lower::model::Ex::XCx])));
    let queue_p4 = crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XCx), crate::prelude::Text::lit("answer_later"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XLater(::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("node"))), crate::prelude::Text::from(format!("{}_publish", &sn_p1.name_p)), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx]))))])));
    let queued_p5 = crate::lower::model::Do::DoIf(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::from(format!("{}_snap", &sn_p1.name_p)))), crate::prelude::Text::lit("queue"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx])), crate::prelude::Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("node")), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XSelf))), queue_p4.clone()]), crate::prelude::Array::new());
    crate::lower::model::Do::DoIf(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::from(format!("{}_snap", &sn_p1.name_p)))), crate::prelude::Text::lit("marked"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx])), crate::prelude::Array::from(vec![take_p3.clone(), queued_p5.clone()]), crate::prelude::Array::new())
}

/// ```prism
/// SnapPublish: fn Sinks, SnapDef -> MethDef
/// ```
pub fn snap_publish_f(sk_p0: &Sinks, sn_p1: &crate::lower::node_::SnapDef) -> crate::lower::model::MethDef {
    crate::lower::model::MethDef { name_p: crate::prelude::Text::from(format!("{}_publish", &sn_p1.name_p)), recv_p: crate::lower::model::Recv::RecvRc, params_p: crate::prelude::Array::new(), cx_p: crate::lower::model::CxArg::CxMut, ret_p: crate::lower::model::OutTy::OutUnit, body_p: crate::prelude::Array::from(vec![crate::lower::model::Do::DoIf(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::from(format!("{}_snap", &sn_p1.name_p)))), crate::prelude::Text::lit("published"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx])), hold_written_f(sk_p0, &sn_p1.name_p), crate::prelude::Array::new())]), tail_p: crate::lower::model::Ex::XUnit, doc_p: crate::prelude::Text::from(format!("{}, published: its snapshot of the tick before moved it, written as a hold is (pick ST).", &sn_p1.what_p)) }
}

/// ```prism
/// GatheredMoved: fn SnapDef -> MethDef
/// ```
pub fn gathered_moved_f(sn_p0: &crate::lower::node_::SnapDef) -> crate::lower::model::MethDef {
    crate::lower::model::MethDef { name_p: crate::prelude::Text::from(format!("{}_moved", &sn_p0.name_p)), recv_p: crate::lower::model::Recv::RecvRc, params_p: crate::prelude::Array::new(), cx_p: crate::lower::model::CxArg::CxMut, ret_p: crate::lower::model::OutTy::OutUnit, body_p: crate::prelude::Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::from(format!("{}_snap", &sn_p0.name_p)))), crate::prelude::Text::lit("mark"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx]))), crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XCx), crate::prelude::Text::lit("build_later"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XSelf))])))]), tail_p: crate::lower::model::Ex::XUnit, doc_p: crate::prelude::Text::lit("A row\'s result moved: the `for`\'s gathered dynamic is marked, and its snapshot taken after the builder (pick ST).") }
}

/// ```prism
/// DocumentGetter: fn Wx -> MethDef
/// ```
pub fn document_getter_f(wx_p0: &crate::lower::node_::Wx) -> crate::lower::model::MethDef {
    let is_own_f1 = ::std::rc::Rc::new(move |p_p3: &crate::lower::model::Pos| &p_p3.scope_p == &crate::prelude::Nat::from(0u32)) as ::std::rc::Rc<dyn ::std::ops::Fn(&crate::lower::model::Pos) -> bool>;
    let body_p2 = document_body_f(wx_p0, &{
        let f = ::std::rc::Rc::new(vec_push_f);
        ::std::rc::Rc::new(move |(a0, a1): (crate::lower::model::Ex, crate::lower::model::Ex)| {
            let fy = f.clone();
            crate::prelude::once_job(move || ::prism_rtl::Turn::Finished(fy(&a0, &a1)))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::model::Ex, crate::lower::model::Ex)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Do>>>
    }, &crate::prelude::filter(&wx_p0.places_p, &(|pl_p4: &crate::lower::node_::Place| (&is_own_f1)(&pl_p4.pos_p))), &crate::prelude::filter(&wx_p0.builders_p, &(|b_p5: &crate::lower::model::ForDef| (&is_own_f1)(&b_p5.pos_p))), &crate::prelude::filter(&wx_p0.gens_p, &(|gd_p6: &crate::lower::model::GenDef| (&is_own_f1)(&gd_p6.pos_p))));
    crate::lower::model::MethDef { name_p: crate::prelude::Text::lit("document"), recv_p: crate::lower::model::Recv::RecvRef, params_p: crate::prelude::Array::new(), cx_p: crate::lower::model::CxArg::CxRef, ret_p: crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Vec")), crate::prelude::Array::from(vec![crate::lower::model::OutTy::OutTuple(crate::prelude::Array::from(vec![crate::lower::model::OutTy::OutPath, crate::lower::types::entry_ty_p()]))])), body_p: crate::prelude::append(&crate::prelude::Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaMut(crate::prelude::Text::lit("doc"))), crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Vec")), crate::prelude::Array::from(vec![crate::lower::model::OutTy::OutTuple(crate::prelude::Array::from(vec![crate::lower::model::OutTy::OutPath, crate::lower::types::entry_ty_p()]))]))), crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Vec::new")), crate::prelude::Array::new()))]), &body_p2), tail_p: crate::lower::model::Ex::XVar(crate::prelude::Text::lit("doc")), doc_p: crate::prelude::Text::lit("The row\'s own places, entries of its host\'s document, by their paths relative to the row (pick HO).") }
}

/// ```prism
/// DocumentMoved: fn Text -> MethDef
/// ```
pub fn document_moved_f(m_p0: &crate::prelude::Text) -> crate::lower::model::MethDef {
    if m_p0 == &crate::lower::node_::switch_::shared_moved_p() {
        crate::lower::model::MethDef { name_p: crate::prelude::Text::lit("document_moved"), recv_p: crate::lower::model::Recv::RecvRc, params_p: crate::prelude::Array::new(), cx_p: crate::lower::model::CxArg::CxMut, ret_p: crate::lower::model::OutTy::OutUnit, body_p: crate::prelude::Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XApply(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::lit("moved"))), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx])))]), tail_p: crate::lower::model::Ex::XUnit, doc_p: crate::prelude::Text::lit("A place of this row\'s may have moved: the node that built the row is told, through what it gave the row.") }
    } else {
        crate::lower::model::MethDef { name_p: crate::prelude::Text::lit("document_moved"), recv_p: crate::lower::model::Recv::RecvRc, params_p: crate::prelude::Array::new(), cx_p: crate::lower::model::CxArg::CxMut, ret_p: crate::lower::model::OutTy::OutUnit, body_p: crate::prelude::Array::from(vec![crate::lower::model::Do::DoIfLet(crate::lower::model::Pa::PaCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Some")), crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("parent"))])), crate::lower::model::Ex::XUpgrade(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::lit("parent")))), crate::prelude::Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("parent"))), m_p0.clone(), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx])))]), crate::prelude::Array::new())]), tail_p: crate::lower::model::Ex::XUnit, doc_p: crate::prelude::Text::lit("A place of this row may have moved: its host\'s document moved, and the host\'s readers and rows are marked (pick HO).") }
    }
}

/// ```prism
/// DocumentBody: fn Wx, (fn Ex, Ex -> Do), [Place], [ForDef], [GenDef] -> [Do]
/// ```
pub fn document_body_f(wx_p0: &crate::lower::node_::Wx, add_f1: &::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::model::Ex, crate::lower::model::Ex)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Do>>>, places_p2: &crate::prelude::Array<crate::lower::node_::Place>, builders_p3: &crate::prelude::Array<crate::lower::model::ForDef>, gens_p4: &crate::prelude::Array<crate::lower::model::GenDef>) -> crate::prelude::Array<crate::lower::model::Do> {
    let statics_p5 = crate::prelude::run_to_end(crate::prelude::each_job(places_p2.clone(), {
        let add_f1x = add_f1.clone();
        let wx_p0x = wx_p0.clone();
        ::std::rc::Rc::new(move |p0: crate::lower::node_::Place| {
            let add_f1xy = add_f1x.clone();
            let wx_p0xy = wx_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let pl_pa = p0;
                (&add_f1xy)((crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Path::root")), crate::prelude::Array::new())), crate::prelude::Text::lit("at"), crate::prelude::Array::from(vec![place_number_f(&wx_p0xy, &crate::prelude::Text::lit("self"), &pl_pa.pos_p)])), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), pl_pa.entry_p.clone()))))).cycle()
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::node_::Place) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Do>>>
    }));
    let row_doc_f6 = ::std::rc::Rc::new(move |p0: crate::lower::model::ForDef| crate::prelude::entered(crate::prelude::once_job(move || {
        let b_pb = p0;
        if crate::syntax::lexer::chars::has_prefix_f(&b_pb.row_node_p, &crate::prelude::Text::lit("prism_rtl::HostRow")) {
            ::prism_rtl::Turn::Finished(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("row"))), crate::prelude::Text::lit("entries"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx])))
        } else {
            ::prism_rtl::Turn::Finished(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("row"))), crate::prelude::Text::lit("document"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx])))
        }
    }))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::ForDef) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>>>;
    let rows_p7 = crate::prelude::run_to_end(crate::prelude::each_job(builders_p3.clone(), {
        let row_doc_f6x = row_doc_f6.clone();
        let add_f1x = add_f1.clone();
        let wx_p0x = wx_p0.clone();
        ::std::rc::Rc::new(move |p0: crate::lower::model::ForDef| {
            let row_doc_f6xy = row_doc_f6x.clone();
            let add_f1xy = add_f1x.clone();
            let wx_p0xy = wx_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let b_pc = p0;
                crate::prelude::call_value((&row_doc_f6xy)(b_pc.clone()), move |row_doc_54357: crate::lower::model::Ex| crate::prelude::call_value((&add_f1xy)((crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Path::root")), crate::prelude::Array::new())), crate::prelude::Text::lit("at"), crate::prelude::Array::from(vec![place_number_f(&wx_p0xy, &crate::prelude::Text::lit("self"), &b_pc.pos_p)]))), crate::prelude::Text::lit("child"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Segment::Key")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("k"))), crate::prelude::Text::lit("to_pod"), crate::prelude::Array::new())]))]))), crate::prelude::Text::lit("join"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("p"))))])), crate::lower::model::Ex::XVar(crate::prelude::Text::lit("e")))), move |add_54371: crate::lower::model::Do| ::prism_rtl::Turn::Finished(crate::lower::model::Do::DoFor(crate::lower::model::Pa::PaTuple(crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("k")), crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("row"))])), crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), b_pc.name_p.clone())), crate::prelude::Text::lit("borrow"), crate::prelude::Array::new())), crate::prelude::Text::lit("iter"), crate::prelude::Array::new()), crate::prelude::Array::from(vec![crate::lower::model::Do::DoFor(crate::lower::model::Pa::PaTuple(crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("p")), crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("e"))])), row_doc_54357, crate::prelude::Array::from(vec![add_54371]))])))))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::ForDef) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Do>>>
    }));
    let gen_path_f8 = {
        let wx_p0x = wx_p0.clone();
        ::std::rc::Rc::new(move |p0: crate::lower::model::GenDef| {
            let wx_p0xy = wx_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let gd_pd = p0;
                if gd_pd.transparent_p {
                    ::prism_rtl::Turn::Finished(crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("p")))))
                } else {
                    ::prism_rtl::Turn::Finished(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Path::root")), crate::prelude::Array::new())), crate::prelude::Text::lit("at"), crate::prelude::Array::from(vec![place_number_f(&wx_p0xy, &crate::prelude::Text::lit("self"), &gd_pd.pos_p)]))), crate::prelude::Text::lit("child"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Segment::Gen")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XVar(crate::prelude::Text::lit("g"))]))]))), crate::prelude::Text::lit("join"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("p"))))])))
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::GenDef) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>>>
    };
    let generations_p9 = crate::prelude::run_to_end(crate::prelude::each_job(gens_p4.clone(), {
        let add_f1x = add_f1.clone();
        let gen_path_f8x = gen_path_f8.clone();
        ::std::rc::Rc::new(move |p0: crate::lower::model::GenDef| {
            let add_f1xy = add_f1x.clone();
            let gen_path_f8xy = gen_path_f8x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let gd_pe = p0;
                crate::prelude::call_value((&gen_path_f8xy)(gd_pe.clone()), move |gen_path_55471: crate::lower::model::Ex| crate::prelude::call_value((&add_f1xy)((gen_path_55471, crate::lower::model::Ex::XVar(crate::prelude::Text::lit("e")))), move |add_55466: crate::lower::model::Do| ::prism_rtl::Turn::Finished(crate::lower::model::Do::DoIfLet(crate::lower::model::Pa::PaCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Some")), crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("row"))])), crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), gd_pe.name_p.clone())), crate::prelude::Text::lit("borrow"), crate::prelude::Array::new())), crate::prelude::Text::lit("as_ref"), crate::prelude::Array::new()), crate::prelude::Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("g")), crate::lower::model::Ex::XBin(crate::lower::model::BinOp::OpSub, ::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::from(format!("{}_count", &gd_pe.name_p)))), crate::prelude::Text::lit("get"), crate::prelude::Array::new())), ::std::rc::Rc::new(crate::lower::model::Ex::XIndex(crate::prelude::Nat::from(1u32))))), crate::lower::model::Do::DoFor(crate::lower::model::Pa::PaTuple(crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("p")), crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("e"))])), crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("row"))), crate::prelude::Text::lit("document"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx])), crate::prelude::Array::from(vec![add_55466]))]), crate::prelude::Array::new()))))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::GenDef) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Do>>>
    }));
    crate::prelude::append(&crate::prelude::append(&statics_p5, &rows_p7), &generations_p9)
}

/// ```prism
/// MapInsert: fn Ex, Ex -> Do
/// ```
pub fn map_insert_f(path_p0: &crate::lower::model::Ex, e_p1: &crate::lower::model::Ex) -> crate::lower::model::Do {
    crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("doc"))), crate::prelude::Text::lit("insert"), crate::prelude::Array::from(vec![path_p0.clone(), e_p1.clone()])))
}

/// ```prism
/// VecPush: fn Ex, Ex -> Do
/// ```
pub fn vec_push_f(path_p0: &crate::lower::model::Ex, e_p1: &crate::lower::model::Ex) -> crate::lower::model::Do {
    crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("doc"))), crate::prelude::Text::lit("push"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XTuple(crate::prelude::Array::from(vec![path_p0.clone(), e_p1.clone()]))])))
}

/// ```prism
/// DynAnswerArm: fn Sinks, Pos, Text, OutTy -> ((Pa, Ex))
/// ```
pub fn dyn_answer_arm_f(sk_p0: &Sinks, pos_p1: &crate::lower::model::Pos, f_p2: &crate::prelude::Text, t_p3: &crate::lower::model::OutTy) -> (crate::lower::model::Pa, crate::lower::model::Ex) {
    (pos_pat_f(pos_p1, &crate::prelude::Array::new()), crate::lower::model::Ex::XBlock(dyn_place_write_f(sk_p0, f_p2, &crate::lower::model::Ex::XDecode(t_p3.clone(), ::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("v"))))), ::std::rc::Rc::new(crate::lower::model::Ex::XUnit)))
}

/// ```prism
/// DynPlaceWrite: fn Sinks, Text, Ex -> [Do]
/// ```
pub fn dyn_place_write_f(sk_p0: &Sinks, f_p1: &crate::prelude::Text, value_p2: &crate::lower::model::Ex) -> crate::prelude::Array<crate::lower::model::Do> {
    crate::prelude::append(&crate::prelude::Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::from(format!("{}", f_p1)))), crate::prelude::Text::lit("set"), crate::prelude::Array::from(vec![if crate::check::types::has_text_f(&sk_p0.wx_p.late_places_p, f_p1) {
        crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Some")), crate::prelude::Array::from(vec![value_p2.clone()]))
    } else {
        value_p2.clone()
    }, crate::lower::model::Ex::XCx])))]), &hold_written_f(sk_p0, f_p1))
}

/// ```prism
/// UpdatedGaps: fn Wx, [Gn] -> [Do]
/// ```
pub fn updated_gaps_f(wx_p0: &crate::lower::node_::Wx, gns_p1: &crate::prelude::Array<crate::lower::node_::Gn>) -> crate::prelude::Array<crate::lower::model::Do> {
    let holds_p2 = crate::prelude::fold(&wx_p0.fields_p, &crate::prelude::Array::new(), &(|acc_p8: &crate::prelude::Array<crate::prelude::Text>, (f_p9, t_pa, _): &(crate::prelude::Text, crate::lower::model::OutTy, crate::prelude::Text)| if is_hold_f(t_pa) { crate::prelude::push(acc_p8, f_p9) } else { acc_p8.clone() }));
    let derived_p3 = crate::prelude::keys(&wx_p0.dyn_reads_p);
    let roots_p4 = snap_names_f(wx_p0);
    let kept_p5 = crate::prelude::each(&wx_p0.clause_results_p, &(|n_pb: &crate::prelude::Text| crate::prelude::Text::from(format!("{}_res", n_pb))));
    let own_p6 = crate::prelude::fold(&crate::prelude::filter(gns_p1, &(|g_pc: &crate::lower::node_::Gn| &g_pc.kind_p == &crate::lower::node_::GnKind::GnUpdated)), &crate::prelude::Array::new(), &(|acc_pd: &crate::prelude::Array<crate::lower::model::Do>, g_pe: &crate::lower::node_::Gn| crate::prelude::fold(&g_pe.reads_p, acc_pd, &(|a_pf: &crate::prelude::Array<crate::lower::model::Do>, r_pg: &crate::lower::node_::Read| match r_pg {
        crate::lower::node_::Read::ParentRead(_) => a_pf.clone(),
        crate::lower::node_::Read::OwnRead(f_ph) => if ((crate::check::types::has_text_f(&holds_p2, f_ph) || crate::check::types::has_text_f(&derived_p3, f_ph)) || crate::check::types::has_text_f(&roots_p4, f_ph)) || crate::check::types::has_text_f(&kept_p5, f_ph) {
            a_pf.clone()
        } else {
            crate::prelude::push(a_pf, &crate::lower::expr::refusal_do_f(&crate::prelude::Text::from(format!("`!Updated` of a dynamic that reads `{}`, which no sink of this node writes (no height for its event)", f_ph))))
        },
    }))));
    let hears_p7 = crate::prelude::append(&crate::prelude::each(&wx_p0.pending_p, &(|p_pi: &crate::lower::node_::PendingRow| updated_hears_f(&p_pi.wx_p))), &crate::prelude::each(&crate::prelude::filter(&wx_p0.row_marks_p, &(|rm_pj: &crate::lower::node_::RowMarks| (&rm_pj.kind_p == &crate::lower::model::RowKind::GenerationRow) || (&rm_pj.kind_p == &crate::lower::model::RowKind::ValueRow))), &(|rm_pk: &crate::lower::node_::RowMarks| rm_pk.wrote_p.clone())));
    crate::prelude::fold(&hears_p7, &own_p6, &(|acc_pl: &crate::prelude::Array<crate::lower::model::Do>, ms_pm: &crate::prelude::Array<crate::prelude::Text>| crate::prelude::fold(ms_pm, acc_pl, &(|a_pn: &crate::prelude::Array<crate::lower::model::Do>, m_po: &crate::prelude::Text| {
        let behind_pp = reads_closed_f(&wx_p0.dyn_reads_p, &crate::prelude::Array::from(vec![crate::lower::node_::Read::OwnRead(m_po.clone())]));
        let written_pq = crate::prelude::fold(&behind_pp, &false, &(|w_pr: &bool, r_ps: &crate::lower::node_::Read| *w_pr || match r_ps {
            crate::lower::node_::Read::OwnRead(h_pt) => crate::check::types::has_text_f(&holds_p2, h_pt) || crate::check::types::has_text_f(&kept_p5, h_pt),
            crate::lower::node_::Read::ParentRead(_) => true,
        }));
        if ((crate::check::types::has_text_f(&roots_p4, m_po) || reaches_snap_f(&roots_p4, &behind_pp)) || written_pq) || crate::check::types::has_text_f(&derived_p3, m_po) {
            a_pn.clone()
        } else {
            crate::prelude::push(a_pn, &crate::lower::expr::refusal_do_f(&crate::prelude::Text::from(format!("`!Updated` of a dynamic in a row that reads its block\'s `{}`, which no sink of the block writes (no height for its event)", m_po))))
        }
    }))))
}

/// ```prism
/// FinishPending: unbounded fn Wx, [Gn] -> (([NodeDef], [Gn]))
/// ```
pub fn finish_pending_f(wx_p0: &crate::lower::node_::Wx, gns_p1: &crate::prelude::Array<crate::lower::node_::Gn>) -> (crate::prelude::Array<crate::lower::model::NodeDef>, crate::prelude::Array<crate::lower::node_::Gn>) {
    crate::prelude::run_to_end(crate::prelude::fold_job(wx_p0.pending_p.clone(), (crate::prelude::Array::new(), gns_p1.clone()), {
        let wx_p0x = wx_p0.clone();
        ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Array<crate::lower::model::NodeDef>, crate::prelude::Array<crate::lower::node_::Gn>), crate::lower::node_::PendingRow)| {
            let wx_p0xy = wx_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (defs_p2, cur_p3) = p0;
                let p_p4 = p1;
                {
                    let floors_p5 = crate::prelude::fold(&row_hears_f(&p_p4.wx_p), &crate::prelude::Map::new(), &(|acc_p9: &crate::prelude::Map<crate::prelude::Text, crate::prelude::Nat>, m_pa: &crate::prelude::Text| crate::prelude::insert(acc_p9, m_pa, &parent_floor_f(&wx_p0xy, &cur_p3, &crate::prelude::Array::from(vec![crate::lower::node_::Read::ParentRead(m_pa.clone())])))));
                    let floored_p6 = {
                        let mut this: crate::lower::node_::Wx = p_p4.wx_p.clone();
                        this.floors_p = floors_p5.clone();
                        this.gns_p = crate::prelude::each(&this.gns_p, &(|g_pb: &crate::lower::node_::Gn| if &g_pb.kind_p == &crate::lower::node_::GnKind::GnUpdated {
                            with_floor_f(g_pb, &parent_floor_f(&wx_p0xy, &cur_p3, &reads_closed_f(&p_p4.wx_p.dyn_reads_p, &g_pb.reads_p)))
                        } else {
                            g_pb.clone()
                        }));
                        this
                    };
                    crate::prelude::call_then(start_finish_node_f(floored_p6.clone(), p_p4.qk_p.clone(), p_p4.params_p.clone(), true), move |finish_node_f_60126: crate::lower::model::NodeDef| {
                        let def_p7 = finish_node_f_60126;
                        let next_p8 = crate::prelude::each(&cur_p3, &(|g_pc: &crate::lower::node_::Gn| if crate::check::types::has_nat_f(&p_p4.gathers_p, &g_pc.id_p) {
                            with_height_f(g_pc, &(&def_p7.top_p + &crate::prelude::Nat::from(1u32)))
                        } else {
                            g_pc.clone()
                        }));
                        ::prism_rtl::Turn::Finished((crate::prelude::push(&defs_p2, &def_p7), next_p8.clone()))
                    })
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Array<crate::lower::model::NodeDef>, crate::prelude::Array<crate::lower::node_::Gn>), crate::lower::node_::PendingRow)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<crate::lower::model::NodeDef>, crate::prelude::Array<crate::lower::node_::Gn>)>>>
    }))
}

/// The step machine of `FinishPending`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FinishPending: unbounded fn Wx, [Gn] -> (([NodeDef], [Gn]))
/// ```
pub struct FinishPending {
    pub wx_p0: crate::lower::node_::Wx,
    pub gns_p1: crate::prelude::Array<crate::lower::node_::Gn>,
}

impl ::prism_rtl::Job<(crate::prelude::Array<crate::lower::model::NodeDef>, crate::prelude::Array<crate::lower::node_::Gn>)> for FinishPending {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::prelude::Array<crate::lower::model::NodeDef>, crate::prelude::Array<crate::lower::node_::Gn>)> {
        let wx_p0 = &self.wx_p0;
        let gns_p1 = &self.gns_p1;
        crate::prelude::fold_job(wx_p0.pending_p.clone(), (crate::prelude::Array::new(), gns_p1.clone()), {
            let wx_p0x = wx_p0.clone();
            ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Array<crate::lower::model::NodeDef>, crate::prelude::Array<crate::lower::node_::Gn>), crate::lower::node_::PendingRow)| {
                let wx_p0xy = wx_p0x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let (defs_p2, cur_p3) = p0;
                    let p_p4 = p1;
                    {
                        let floors_p5 = crate::prelude::fold(&row_hears_f(&p_p4.wx_p), &crate::prelude::Map::new(), &(|acc_p9: &crate::prelude::Map<crate::prelude::Text, crate::prelude::Nat>, m_pa: &crate::prelude::Text| crate::prelude::insert(acc_p9, m_pa, &parent_floor_f(&wx_p0xy, &cur_p3, &crate::prelude::Array::from(vec![crate::lower::node_::Read::ParentRead(m_pa.clone())])))));
                        let floored_p6 = {
                            let mut this: crate::lower::node_::Wx = p_p4.wx_p.clone();
                            this.floors_p = floors_p5.clone();
                            this.gns_p = crate::prelude::each(&this.gns_p, &(|g_pb: &crate::lower::node_::Gn| if &g_pb.kind_p == &crate::lower::node_::GnKind::GnUpdated {
                                with_floor_f(g_pb, &parent_floor_f(&wx_p0xy, &cur_p3, &reads_closed_f(&p_p4.wx_p.dyn_reads_p, &g_pb.reads_p)))
                            } else {
                                g_pb.clone()
                            }));
                            this
                        };
                        crate::prelude::call_then(start_finish_node_f(floored_p6.clone(), p_p4.qk_p.clone(), p_p4.params_p.clone(), true), move |finish_node_f_60126: crate::lower::model::NodeDef| {
                            let def_p7 = finish_node_f_60126;
                            let next_p8 = crate::prelude::each(&cur_p3, &(|g_pc: &crate::lower::node_::Gn| if crate::check::types::has_nat_f(&p_p4.gathers_p, &g_pc.id_p) {
                                with_height_f(g_pc, &(&def_p7.top_p + &crate::prelude::Nat::from(1u32)))
                            } else {
                                g_pc.clone()
                            }));
                            ::prism_rtl::Turn::Finished((crate::prelude::push(&defs_p2, &def_p7), next_p8.clone()))
                        })
                    }
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Array<crate::lower::model::NodeDef>, crate::prelude::Array<crate::lower::node_::Gn>), crate::lower::node_::PendingRow)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<crate::lower::model::NodeDef>, crate::prelude::Array<crate::lower::node_::Gn>)>>>
        }).cycle()
    }
}

/// `Start FinishPending, x`: what the function value is when passed to `@Run`.
pub fn start_finish_pending_f(wx_p0: crate::lower::node_::Wx, gns_p1: crate::prelude::Array<crate::lower::node_::Gn>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<crate::lower::model::NodeDef>, crate::prelude::Array<crate::lower::node_::Gn>)>> {
    ::std::rc::Rc::new(FinishPending { wx_p0, gns_p1 })
}

/// ```prism
/// ParentFloor: fn Wx, [Gn], [Read] -> Nat
/// ```
pub fn parent_floor_f(wx_p0: &crate::lower::node_::Wx, gns_p1: &crate::prelude::Array<crate::lower::node_::Gn>, reads_p2: &crate::prelude::Array<crate::lower::node_::Read>) -> crate::prelude::Nat {
    crate::prelude::fold(reads_p2, &crate::prelude::Nat::from(0u32), &(|hi_p3: &crate::prelude::Nat, r_p4: &crate::lower::node_::Read| match r_p4 {
        crate::lower::node_::Read::ParentRead(m_p5) => crate::prelude::fold(&reads_closed_f(&wx_p0.dyn_reads_p, &crate::prelude::Array::from(vec![crate::lower::node_::Read::OwnRead(m_p5.clone())])), hi_p3, &(|h2_p6: &crate::prelude::Nat, hr_p7: &crate::lower::node_::Read| match hr_p7 {
            crate::lower::node_::Read::OwnRead(f_p8) => crate::prelude::fold(gns_p1, h2_p6, &(|h3_p9: &crate::prelude::Nat, g_pa: &crate::lower::node_::Gn| if writes_hold_f(g_pa, f_p8) {
                crate::prelude::max(h3_p9, &(&g_pa.height_p + &crate::prelude::Nat::from(1u32)))
            } else {
                h3_p9.clone()
            })),
            crate::lower::node_::Read::ParentRead(up_pb) => crate::prelude::max(h2_p6, &crate::prelude::or(&crate::prelude::get(&wx_p0.floors_p, up_pb), &crate::prelude::Nat::from(0u32))),
        })),
        crate::lower::node_::Read::OwnRead(_) => hi_p3.clone(),
    }))
}

/// ```prism
/// WritesHold: fn Gn, Text -> Bool
/// ```
pub fn writes_hold_f(g_p0: &crate::lower::node_::Gn, f_p1: &crate::prelude::Text) -> bool {
    crate::prelude::fold(&g_p0.outs_p, &false, &(|acc_p2: &bool, o_p3: &crate::lower::node_::Out| *acc_p2 || sink_writes_hold_f(&o_p3.sink_p, f_p1)))
}

/// ```prism
/// SinkWritesHold: fn Sk, Text -> Bool
/// ```
pub fn sink_writes_hold_f(sk0: &crate::lower::node_::Sk, f_p1: &crate::prelude::Text) -> bool {
    match sk0 {
        crate::lower::node_::Sk::SkHold(h_p0) => h_p0 == f_p1,
        crate::lower::node_::Sk::SkDistinct(h_p2) => h_p2 == f_p1,
        crate::lower::node_::Sk::SkPerKey(h_p4) => h_p4 == f_p1,
        crate::lower::node_::Sk::SkMachine(h_p6, _, _) => h_p6 == f_p1,
        other_p8 => false,
    }
}

/// ```prism
/// WithFloor: fn Gn, Nat -> Gn
/// ```
pub fn with_floor_f(g_p0: &crate::lower::node_::Gn, h_p1: &crate::prelude::Nat) -> crate::lower::node_::Gn {
    let mut this: crate::lower::node_::Gn = g_p0.clone();
    this.floor_p = h_p1.clone();
    this
}

/// ```prism
/// WithHeight: fn Gn, Nat -> Gn
/// ```
pub fn with_height_f(g_p0: &crate::lower::node_::Gn, h_p1: &crate::prelude::Nat) -> crate::lower::node_::Gn {
    let mut this: crate::lower::node_::Gn = g_p0.clone();
    this.height_p = h_p1.clone();
    this
}

/// ```prism
/// IsOwnerLink: fn Do -> Bool
/// ```
pub fn is_owner_link_f(d_p0: &crate::lower::model::Do) -> bool {
    'm61627: {
        if let crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(m61627_0_0_0, m61627_0_0_1, m61627_0_0_2)) = d_p0 && let crate::lower::model::Ex::XVar(_) = &**m61627_0_0_0 && (m61627_0_0_1 == &crate::prelude::Text::lit("link")) && (m61627_0_0_2.len() == 1) && let ::std::option::Option::Some(crate::lower::model::Ex::XRef(m61627_0_0_2_0_0)) = crate::prelude::index(m61627_0_0_2, &crate::prelude::Nat::from(0u32)) && let crate::lower::model::Ex::XVar(m61627_0_0_2_0_0_r_0) = &*m61627_0_0_2_0_0 && (m61627_0_0_2_0_0_r_0 == &crate::prelude::Text::lit("node")) {
            break 'm61627 true;
        }
        false
    }
}

/// ```prism
/// RowHears: fn Wx -> [Text]
/// ```
pub fn row_hears_f(wx_p0: &crate::lower::node_::Wx) -> crate::prelude::Array<crate::prelude::Text> {
    let from_updated_p1 = crate::prelude::fold(&crate::prelude::filter(&wx_p0.gns_p, &(|g_p6: &crate::lower::node_::Gn| &g_p6.kind_p == &crate::lower::node_::GnKind::GnUpdated)), &crate::prelude::Array::new(), &(|acc_p7: &crate::prelude::Array<crate::lower::node_::Read>, g_p8: &crate::lower::node_::Gn| crate::lower::node_::union_reads_f(acc_p7, &reads_closed_f(&wx_p0.dyn_reads_p, &g_p8.reads_p))));
    let from_rows_p2 = crate::prelude::fold(&wx_p0.row_marks_p, &crate::prelude::Array::new(), &(|acc_p9: &crate::prelude::Array<crate::lower::node_::Read>, rm_pa: &crate::lower::node_::RowMarks| crate::lower::node_::union_reads_f(acc_p9, &reads_closed_f(&wx_p0.dyn_reads_p, &crate::prelude::append(&rm_pa.reads_p, &crate::prelude::each(&rm_pa.wrote_p, &(|m_pb: &crate::prelude::Text| crate::lower::node_::Read::OwnRead(m_pb.clone()))))))));
    let from_builds_p3 = reads_closed_f(&wx_p0.dyn_reads_p, &wx_p0.build_holds_p);
    let from_gens_p4 = crate::prelude::fold(&wx_p0.gen_holds_p, &crate::prelude::Array::new(), &(|acc_pc: &crate::prelude::Array<crate::lower::node_::Read>, (_, hs_pd): &(crate::prelude::Text, crate::prelude::Array<crate::lower::node_::Read>)| crate::lower::node_::union_reads_f(acc_pc, &reads_closed_f(&wx_p0.dyn_reads_p, hs_pd))));
    let from_answers_p5 = crate::prelude::fold(&wx_p0.dyn_answers_p, &crate::prelude::Array::new(), &(|acc_pe: &crate::prelude::Array<crate::lower::node_::Read>, (_, rds_pf): &(crate::prelude::Text, crate::prelude::Array<crate::lower::node_::Read>)| crate::lower::node_::union_reads_f(acc_pe, &reads_closed_f(&wx_p0.dyn_reads_p, rds_pf))));
    crate::prelude::fold(&crate::lower::node_::union_reads_f(&crate::lower::node_::union_reads_f(&crate::lower::node_::union_reads_f(&crate::lower::node_::union_reads_f(&from_updated_p1, &from_rows_p2), &from_builds_p3), &from_gens_p4), &from_answers_p5), &crate::prelude::Array::new(), &(|acc_pg: &crate::prelude::Array<crate::prelude::Text>, r_ph: &crate::lower::node_::Read| match r_ph {
        crate::lower::node_::Read::ParentRead(m_pi) => crate::check::types::add_text_f(acc_pg, m_pi),
        crate::lower::node_::Read::OwnRead(_) => acc_pg.clone(),
    }))
}

/// ```prism
/// UpdatedHears: fn Wx -> [Text]
/// ```
pub fn updated_hears_f(wx_p0: &crate::lower::node_::Wx) -> crate::prelude::Array<crate::prelude::Text> {
    crate::prelude::fold(&crate::prelude::filter(&wx_p0.gns_p, &(|g_p1: &crate::lower::node_::Gn| &g_p1.kind_p == &crate::lower::node_::GnKind::GnUpdated)), &crate::prelude::Array::new(), &(|acc_p2: &crate::prelude::Array<crate::prelude::Text>, g_p3: &crate::lower::node_::Gn| crate::prelude::fold(&reads_closed_f(&wx_p0.dyn_reads_p, &g_p3.reads_p), acc_p2, &(|a_p4: &crate::prelude::Array<crate::prelude::Text>, r_p5: &crate::lower::node_::Read| match r_p5 {
        crate::lower::node_::Read::ParentRead(m_p6) => crate::check::types::add_text_f(a_p4, m_p6),
        crate::lower::node_::Read::OwnRead(_) => a_p4.clone(),
    }))))
}

/// ```prism
/// RowWritten: fn Wx, RowMarks, Read -> [Do]
/// ```
pub fn row_written_f(wx_p0: &crate::lower::node_::Wx, rm_p1: &crate::lower::node_::RowMarks, r_p2: &crate::lower::node_::Read) -> crate::prelude::Array<crate::lower::model::Do> {
    let dirty_p3 = if crate::lower::node_::has_read_f(&reads_closed_f(&wx_p0.dyn_reads_p, &rm_p1.reads_p), r_p2) {
        crate::prelude::Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XCx), crate::prelude::Text::lit("dirty"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("row"))))])))])
    } else {
        crate::prelude::Array::new()
    };
    let hit_p4 = crate::prelude::filter(&crate::prelude::append(&rm_p1.wrote_p, &rm_p1.builds_p), &(|m_p7: &crate::prelude::Text| crate::lower::node_::has_read_f(&reads_closed_f(&wx_p0.dyn_reads_p, &crate::prelude::Array::from(vec![crate::lower::node_::Read::OwnRead(m_p7.clone())])), r_p2)));
    let told_p5 = crate::prelude::each(&hit_p4, &(|m_p8: &crate::prelude::Text| crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("row"))), crate::prelude::Text::from(format!("parent_wrote_{}", m_p8)), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx])))));
    let fired_p6 = crate::prelude::each(&hit_p4, &(|m_p9: &crate::prelude::Text| crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XCall(crate::lower::helper_ref_f(&crate::prelude::Text::lit("no_fault")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::from(format!("{}_wrote_{}_port", &rm_p1.builder_p, m_p9)))), crate::prelude::Text::lit("fire"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XUnit, crate::lower::model::Ex::XCx]))])))));
    match &rm_p1.kind_p {
        crate::lower::model::RowKind::GenerationRow => if &crate::prelude::len(&dirty_p3) == &crate::prelude::Nat::from(0u32) {
            fired_p6.clone()
        } else {
            crate::prelude::push(&fired_p6, &crate::lower::model::Do::DoIfLet(crate::lower::model::Pa::PaCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Some")), crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("row"))])), crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), rm_p1.builder_p.clone())), crate::prelude::Text::lit("borrow"), crate::prelude::Array::new())), crate::prelude::Text::lit("as_ref"), crate::prelude::Array::new()), dirty_p3.clone(), crate::prelude::Array::new()))
        },
        crate::lower::model::RowKind::ValueRow => if &crate::prelude::len(&dirty_p3) == &crate::prelude::Nat::from(0u32) {
            fired_p6.clone()
        } else {
            crate::prelude::push(&fired_p6, &crate::lower::model::Do::DoFor(crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("row")), crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::from(format!("{}_rows", &rm_p1.builder_p)))), crate::prelude::Text::lit("live"), crate::prelude::Array::new()), dirty_p3.clone()))
        },
        _ => {
            let body_pa = crate::prelude::append(&dirty_p3, &told_p5);
            if &crate::prelude::len(&body_pa) == &crate::prelude::Nat::from(0u32) {
                crate::prelude::Array::new()
            } else {
                crate::prelude::Array::from(vec![crate::lower::model::Do::DoFor(crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("row")), crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), rm_p1.builder_p.clone())), crate::prelude::Text::lit("borrow"), crate::prelude::Array::new())), crate::prelude::Text::lit("values"), crate::prelude::Array::new()), body_pa.clone())])
            }
        },
    }
}

/// ```prism
/// PatchPlace: fn Wx, Place -> [Do]
/// ```
pub fn patch_place_f(wx_p0: &crate::lower::node_::Wx, p_p1: &crate::lower::node_::Place) -> crate::prelude::Array<crate::lower::model::Do> {
    let pull_p2 = crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(p_p1.getter_p.clone()), crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), p_p1.getter_p.clone(), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx])));
    let at_p3 = place_at_f(wx_p0, &crate::prelude::Text::lit("self"), &p_p1.pos_p);
    let sent_p4 = crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XCx), crate::prelude::Text::lit("changed"), crate::prelude::Array::from(vec![at_p3.clone(), crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XVar(p_p1.getter_p.clone())), crate::prelude::Text::lit("level_pod"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx]))])));
    let renew_p5 = if &p_p1.watch_p == &crate::prelude::Text::lit("") {
        crate::prelude::Array::new()
    } else {
        crate::prelude::Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), p_p1.watch_p.clone())), crate::prelude::Text::lit("renew"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XVar(p_p1.getter_p.clone()))), crate::lower::model::Ex::XCast(::std::rc::Rc::new(crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XSelf))), crate::lower::model::OutTy::OutObj(::std::rc::Rc::new(crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Node")), crate::prelude::Array::new())))), crate::lower::model::Ex::XCx])))])
    };
    crate::prelude::append(&crate::prelude::Array::from(vec![pull_p2.clone(), sent_p4.clone()]), &renew_p5)
}

/// ```prism
/// Emits: fn Wx, Pos -> Bool
/// ```
pub fn emits_f(wx_p0: &crate::lower::node_::Wx, pos_p1: &crate::lower::model::Pos) -> bool {
    (&pos_p1.scope_p == &crate::prelude::Nat::from(0u32)) && (&wx_p0.hosted_by_o == &::std::option::Option::None)
}

/// ```prism
/// ResultTold: fn Ex, Nat -> [Do]
/// ```
pub fn result_told_f(node_p0: &crate::lower::model::Ex, k_p1: &crate::prelude::Nat) -> crate::prelude::Array<crate::lower::model::Do> {
    let r_p2 = crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("r")), crate::lower::model::Ex::XMethod(::std::rc::Rc::new(node_p0.clone()), root_result_stem_f(&crate::prelude::Text::lit("result_value"), k_p1), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx])));
    crate::prelude::Array::from(vec![r_p2.clone(), result_kept_f(node_p0, k_p1), result_tell_p()])
}

/// ```prism
/// RootResultStem: fn Text, Nat -> Text
/// ```
pub fn root_result_stem_f(stem_p0: &crate::prelude::Text, k_p1: &crate::prelude::Nat) -> crate::prelude::Text {
    if k_p1 == &crate::prelude::Nat::from(0u32) {
        stem_p0.clone()
    } else {
        crate::prelude::Text::from(format!("{}_{}", stem_p0, k_p1))
    }
}

/// ```prism
/// ResultMoved: fn Ex, Nat -> [Do]
/// ```
pub fn result_moved_f(node_p0: &crate::lower::model::Ex, k_p1: &crate::prelude::Nat) -> crate::prelude::Array<crate::lower::model::Do> {
    let r_p2 = crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("r")), crate::lower::model::Ex::XMethod(::std::rc::Rc::new(node_p0.clone()), root_result_stem_f(&crate::prelude::Text::lit("result_value"), k_p1), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx])));
    let last_p3 = crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(node_p0.clone()), root_result_stem_f(&crate::prelude::Text::lit("result_last"), k_p1))), crate::prelude::Text::lit("borrow"), crate::prelude::Array::new())), crate::prelude::Text::lit("as_ref"), crate::prelude::Array::new());
    let differs_p4 = crate::lower::model::Ex::XBin(crate::lower::model::BinOp::OpNe, ::std::rc::Rc::new(last_p3.clone()), ::std::rc::Rc::new(crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Some")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("r"))))]))));
    crate::prelude::Array::from(vec![r_p2.clone(), crate::lower::model::Do::DoIf(differs_p4.clone(), crate::prelude::Array::from(vec![result_kept_f(node_p0, k_p1), result_tell_p()]), crate::prelude::Array::new())])
}

/// ```prism
/// ResultKept: fn Ex, Nat -> Do
/// ```
pub fn result_kept_f(node_p0: &crate::lower::model::Ex, k_p1: &crate::prelude::Nat) -> crate::lower::model::Do {
    crate::lower::model::Do::DoAssign(crate::lower::model::Ex::XDeref(::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(node_p0.clone()), root_result_stem_f(&crate::prelude::Text::lit("result_last"), k_p1))), crate::prelude::Text::lit("borrow_mut"), crate::prelude::Array::new()))), crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Some")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("r"))))])))
}

/// ```prism
/// let resultTell
/// ```
pub fn result_tell_p() -> crate::lower::model::Do {
    crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XCx), crate::prelude::Text::lit("result"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Outcome::Value")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XVar(crate::prelude::Text::lit("r"))]))])))
}

/// ```prism
/// Adoption: fn FlatDef -> [Do]
/// ```
pub fn adoption_f(fl_p0: &crate::lower::node_::FlatDef) -> crate::prelude::Array<crate::lower::model::Do> {
    let adopt_p1 = crate::lower::model::Ex::XLater(::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("node"))), crate::prelude::Text::from(format!("{}_adopt", &fl_p0.name_p)), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx]))));
    crate::prelude::Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("node")), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XSelf))), crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XCx), crate::prelude::Text::lit("answer_later"), crate::prelude::Array::from(vec![adopt_p1.clone()])))])
}

/// ```prism
/// PlaceAt: fn Wx, Text, Pos -> Ex
/// ```
pub fn place_at_f(wx_p0: &crate::lower::node_::Wx, recv_p1: &crate::prelude::Text, pos_p2: &crate::lower::model::Pos) -> crate::lower::model::Ex {
    let at_p3 = crate::prelude::Array::from(vec![place_number_f(wx_p0, recv_p1, pos_p2)]);
    if emits_f(wx_p0, pos_p2) {
        crate::lower::model::Ex::XMethod(::std::rc::Rc::new(if recv_p1 == &crate::prelude::Text::lit("") {
            crate::lower::model::Ex::XVar(crate::prelude::Text::lit("path"))
        } else {
            if recv_p1 == &crate::prelude::Text::lit("self") {
                crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::lit("path"))
            } else {
                crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XVar(recv_p1.clone())), crate::prelude::Text::lit("path"))
            }
        }), crate::prelude::Text::lit("at"), at_p3.clone())
    } else {
        crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Path::root")), crate::prelude::Array::new())), crate::prelude::Text::lit("at"), at_p3.clone())
    }
}

/// ```prism
/// PlaceUnknownAtBuild: fn Wx, Pos -> Bool
/// ```
pub fn place_unknown_at_build_f(wx_p0: &crate::lower::node_::Wx, pos_p1: &crate::lower::model::Pos) -> bool {
    (((&pos_p1.scope_p == &crate::prelude::Nat::from(0u32)) && wx_p0.base_late_p) && is_some_nat_f(&wx_p0.based_o)) || (&crate::prelude::len(&crate::prelude::filter(&gaps_before_f(wx_p0, pos_p1), &(|gd_p2: &crate::lower::model::GenDef| !gd_p2.early_p || crate::check::types::has_text_f(&wx_p0.late_numbered_p, &gd_p2.name_p)))) > &crate::prelude::Nat::from(0u32))
}

/// ```prism
/// GapsBefore: fn Wx, Pos -> [GenDef]
/// ```
pub fn gaps_before_f(wx_p0: &crate::lower::node_::Wx, pos_p1: &crate::lower::model::Pos) -> crate::prelude::Array<crate::lower::model::GenDef> {
    crate::prelude::filter(&wx_p0.gens_p, &(|gd_p2: &crate::lower::model::GenDef| (gd_p2.gappy_p && (&gd_p2.pos_p.scope_p == &pos_p1.scope_p)) && (&(&gd_p2.pos_p.at_p + &gd_p2.width_p) <= &pos_p1.at_p)))
}

/// ```prism
/// NumberedLate: fn Wx, Pos -> Bool
/// ```
pub fn numbered_late_f(wx_p0: &crate::lower::node_::Wx, pos_p1: &crate::lower::model::Pos) -> bool {
    (wx_p0.base_late_p && (&pos_p1.scope_p == &crate::prelude::Nat::from(0u32))) || (&crate::prelude::len(&crate::prelude::filter(&gaps_before_f(wx_p0, pos_p1), &(|gd_p2: &crate::lower::model::GenDef| !gd_p2.early_p || crate::check::types::has_text_f(&wx_p0.late_numbered_p, &gd_p2.name_p)))) > &crate::prelude::Nat::from(0u32))
}

/// ```prism
/// LateNumbering: fn [Do] -> [Do]
/// ```
pub fn late_numbering_f(build_p0: &crate::prelude::Array<crate::lower::model::Do>) -> crate::prelude::Array<crate::lower::model::Do> {
    let kept_p1 = crate::lower::model::Ex::XBlock(crate::prelude::Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("node")), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("node"))))), crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("number"))), later_ty_p()), crate::lower::model::Ex::XLater(::std::rc::Rc::new(crate::lower::model::Ex::XBlock(build_p0.clone(), ::std::rc::Rc::new(crate::lower::model::Ex::XUnit)))))]), ::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("number"))));
    crate::prelude::Array::from(vec![crate::lower::model::Do::DoAssign(crate::lower::model::Ex::XDeref(::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("node"))), crate::prelude::Text::lit("number_later"))), crate::prelude::Text::lit("borrow_mut"), crate::prelude::Array::new()))), crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Some")), crate::prelude::Array::from(vec![kept_p1.clone()])))])
}

/// ```prism
/// NumberTaken: fn Ex, Text -> Do
/// ```
pub fn number_taken_f(recv_p0: &crate::lower::model::Ex, name_p1: &crate::prelude::Text) -> crate::lower::model::Do {
    crate::lower::model::Do::DoScope(crate::prelude::Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("number")), crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(recv_p0.clone()), crate::prelude::Text::from(format!("{}_number", name_p1)))), crate::prelude::Text::lit("borrow_mut"), crate::prelude::Array::new())), crate::prelude::Text::lit("take"), crate::prelude::Array::new())), crate::lower::model::Do::DoIfLet(crate::lower::model::Pa::PaCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Some")), crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("number"))])), crate::lower::model::Ex::XVar(crate::prelude::Text::lit("number")), crate::prelude::Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::expr::try_of_f(&crate::lower::model::Ex::XApply(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("number"))), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx]))))]), crate::prelude::Array::new())]))
}

/// ```prism
/// LateRowSelect: fn GenDef -> GenDef
/// ```
pub fn late_row_select_f(gd_p0: &crate::lower::model::GenDef) -> crate::lower::model::GenDef {
    let mut this: crate::lower::model::GenDef = gd_p0.clone();
    this.select_p = crate::lower::model::Ex::XBlock(crate::prelude::Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("row")), gd_p0.select_p.clone()), crate::lower::model::Do::DoIf(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::lit("numbered"))), crate::prelude::Text::lit("get"), crate::prelude::Array::new()), crate::prelude::Array::from(vec![number_taken_f(&crate::lower::model::Ex::XSelf, &gd_p0.name_p)]), crate::prelude::Array::new())]), ::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("row"))));
    this
}

/// ```prism
/// PhaseOf: fn Sinks, Nat -> Sinks
/// ```
pub fn phase_of_f(sk_p0: &Sinks, phase_p1: &crate::prelude::Nat) -> Sinks {
    let mut this: Sinks = sk_p0.clone();
    this.wx_p = with_gen_phase_f(&this.wx_p, phase_p1);
    this
}

/// ```prism
/// WithGenPhase: fn Wx, Nat -> Wx
/// ```
pub fn with_gen_phase_f(wx_p0: &crate::lower::node_::Wx, phase_p1: &crate::prelude::Nat) -> crate::lower::node_::Wx {
    let mut this: crate::lower::node_::Wx = wx_p0.clone();
    this.gen_phase_p = phase_p1.clone();
    this
}

/// ```prism
/// let laterTy
/// ```
pub fn later_ty_p() -> crate::lower::model::OutTy {
    crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("prism_rtl::cx::Later")), crate::prelude::Array::new())
}

/// ```prism
/// NumberPlaces: fn Wx -> MethDef
/// ```
pub fn number_places_f(wx_p0: &crate::lower::node_::Wx) -> crate::lower::model::MethDef {
    let set_p1 = crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::lit("base"))), crate::prelude::Text::lit("set"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XVar(crate::prelude::Text::lit("base"))])));
    let taken_p2 = crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("number")), crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::lit("number_later"))), crate::prelude::Text::lit("borrow_mut"), crate::prelude::Array::new())), crate::prelude::Text::lit("take"), crate::prelude::Array::new()));
    let run_p3 = crate::lower::model::Do::DoIfLet(crate::lower::model::Pa::PaCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Some")), crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("number"))])), crate::lower::model::Ex::XVar(crate::prelude::Text::lit("number")), crate::prelude::Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::expr::try_of_f(&crate::lower::model::Ex::XApply(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("number"))), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx]))))]), crate::prelude::Array::new());
    let told_p4 = if wx_p0.late_gens_p {
        crate::prelude::Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::lit("numbered"))), crate::prelude::Text::lit("set"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XBool(true)])))])
    } else {
        crate::prelude::Array::new()
    };
    crate::lower::model::MethDef { name_p: crate::prelude::Text::lit("number_places"), recv_p: crate::lower::model::Recv::RecvRc, params_p: crate::prelude::Array::from(vec![(crate::prelude::Text::lit("base"), crate::lower::model::OutTy::OutCount)]), cx_p: crate::lower::model::CxArg::CxMut, ret_p: crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Done")), crate::prelude::Array::new()), body_p: crate::prelude::append(&crate::prelude::append(&crate::prelude::Array::from(vec![set_p1.clone()]), &told_p4), &crate::prelude::Array::from(vec![taken_p2.clone(), run_p3.clone()])), tail_p: crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Ok")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XUnit])), doc_p: crate::prelude::Text::lit("The row\'s places numbered from `base`, where its first position stands as built, and sent: the row was built before its block\'s node, below a generation built after it (ruling TC: places are counted as they are built).") }
}

/// ```prism
/// PlaceMethod: fn Nat -> Text
/// ```
pub fn place_method_f(scope_p0: &crate::prelude::Nat) -> crate::prelude::Text {
    if scope_p0 == &crate::prelude::Nat::from(0u32) {
        crate::prelude::Text::lit("place")
    } else {
        crate::prelude::Text::from(format!("place_{}", scope_p0))
    }
}

/// ```prism
/// SeatMethod: fn Nat -> Text
/// ```
pub fn seat_method_f(scope_p0: &crate::prelude::Nat) -> crate::prelude::Text {
    if scope_p0 == &crate::prelude::Nat::from(0u32) {
        crate::prelude::Text::lit("seat")
    } else {
        crate::prelude::Text::from(format!("seat_{}", scope_p0))
    }
}

/// ```prism
/// PlaceNumber: fn Wx, Text, Pos -> Ex
/// ```
pub fn place_number_f(wx_p0: &crate::lower::node_::Wx, recv_p1: &crate::prelude::Text, pos_p2: &crate::lower::model::Pos) -> crate::lower::model::Ex {
    let gaps_p3 = gaps_before_f(wx_p0, pos_p2);
    let base_o4 = if &pos_p2.scope_p == &crate::prelude::Nat::from(0u32) {
        wx_p0.based_o.clone()
    } else {
        ::std::option::Option::None
    };
    if (&crate::prelude::len(&gaps_p3) == &crate::prelude::Nat::from(0u32)) && !is_some_nat_f(&base_o4) {
        crate::lower::model::Ex::XIndex(pos_p2.at_p.clone())
    } else {
        if recv_p1 == &crate::prelude::Text::lit("") {
            {
                let start_p5 = match &base_o4 {
                    ::std::option::Option::Some(s_p6) => if wx_p0.base_late_p {
                        crate::lower::expr::refusal_f(&crate::prelude::Text::from(format!("a place that is read at its row\'s build (place {}: a host\'s, or a hosted place\'s first value) in an arm or a clause that is built before its block\'s node and numbered after it", &crate::lower::model::place_text_f(pos_p2))))
                    } else {
                        crate::lower::model::Ex::XBin(crate::lower::model::BinOp::OpAdd, ::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("base"))), ::std::rc::Rc::new(crate::lower::model::Ex::XIndex(crate::prelude::or(&(&pos_p2.at_p).checked_sub(s_p6), &crate::prelude::Nat::from(0u32)))))
                    },
                    ::std::option::Option::None => crate::lower::model::Ex::XIndex(pos_p2.at_p.clone()),
                };
                crate::prelude::fold(&gaps_p3, &start_p5, &(|acc_p7: &crate::lower::model::Ex, gd_p8: &crate::lower::model::GenDef| if gd_p8.early_p && !crate::check::types::has_text_f(&wx_p0.late_numbered_p, &gd_p8.name_p) {
                    crate::lower::model::Ex::XBin(crate::lower::model::BinOp::OpSub, ::std::rc::Rc::new(acc_p7.clone()), ::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::from(format!("{}_gap_now", &gd_p8.name_p)))))
                } else {
                    crate::lower::expr::refusal_f(&crate::prelude::Text::from(format!("a place that is read at its block\'s build (place {}) after a building `match`, `if` or widget of several clauses whose rows differ in width and are built after the block\'s node", &crate::lower::model::place_text_f(pos_p2))))
                }))
            }
        } else {
            crate::lower::model::Ex::XMethod(::std::rc::Rc::new(if recv_p1 == &crate::prelude::Text::lit("self") {
                crate::lower::model::Ex::XSelf
            } else {
                crate::lower::model::Ex::XVar(recv_p1.clone())
            }), place_method_f(&pos_p2.scope_p), crate::prelude::Array::from(vec![crate::lower::model::Ex::XIndex(pos_p2.at_p.clone())]))
        }
    }
}

/// ```prism
/// IsSomeNat: fn ?Nat -> Bool
/// ```
pub fn is_some_nat_f(opt0: &::std::option::Option<crate::prelude::Nat>) -> bool {
    match opt0 {
        ::std::option::Option::Some(_) => true,
        ::std::option::Option::None => false,
    }
}

/// ```prism
/// GapGet: fn GenDef -> Ex
/// ```
pub fn gap_get_f(gd_p0: &crate::lower::model::GenDef) -> crate::lower::model::Ex {
    crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::from(format!("{}_gap", &gd_p0.name_p)))), crate::prelude::Text::lit("get"), crate::prelude::Array::new())
}

/// ```prism
/// PlaceMethods: fn Wx -> [MethDef]
/// ```
pub fn place_methods_f(wx_p0: &crate::lower::node_::Wx) -> crate::prelude::Array<crate::lower::model::MethDef> {
    let gappy_p1 = crate::prelude::filter(&wx_p0.gens_p, &(|gd_p3: &crate::lower::model::GenDef| gd_p3.gappy_p));
    let scopes_p2 = crate::prelude::fold(&gappy_p1, &(if is_some_nat_f(&wx_p0.based_o) {
        crate::prelude::Array::from(vec![crate::prelude::Nat::from(0u32)])
    } else {
        crate::prelude::Array::new()
    }), &(|acc_p4: &crate::prelude::Array<crate::prelude::Nat>, gd_p5: &crate::lower::model::GenDef| if crate::check::types::has_nat_f(acc_p4, &gd_p5.pos_p.scope_p) {
        acc_p4.clone()
    } else {
        crate::prelude::push(acc_p4, &gd_p5.pos_p.scope_p)
    }));
    crate::prelude::fold(&scopes_p2, &crate::prelude::Array::new(), &(|acc_p6: &crate::prelude::Array<crate::lower::model::MethDef>, k_p7: &crate::prelude::Nat| {
        let gaps_p8 = crate::prelude::filter(&gappy_p1, &(|gd_pf: &crate::lower::model::GenDef| &gd_pf.pos_p.scope_p == k_p7));
        let start_p9 = match if k_p7 == &crate::prelude::Nat::from(0u32) {
            wx_p0.based_o.clone()
        } else {
            ::std::option::Option::None
        } {
            ::std::option::Option::Some(s_pg) => crate::lower::model::Ex::XBin(crate::lower::model::BinOp::OpSub, ::std::rc::Rc::new(crate::lower::model::Ex::XBin(crate::lower::model::BinOp::OpAdd, ::std::rc::Rc::new(if wx_p0.base_late_p {
                crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::lit("base"))), crate::prelude::Text::lit("get"), crate::prelude::Array::new())
            } else {
                crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::lit("base"))
            }), ::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("v"))))), ::std::rc::Rc::new(crate::lower::model::Ex::XIndex(s_pg))),
            ::std::option::Option::None => crate::lower::model::Ex::XVar(crate::prelude::Text::lit("v")),
        };
        let placed_pa = crate::prelude::fold(&gaps_p8, &start_p9, &(|x_ph: &crate::lower::model::Ex, gd_pi: &crate::lower::model::GenDef| crate::lower::model::Ex::XBin(crate::lower::model::BinOp::OpSub, ::std::rc::Rc::new(x_ph.clone()), ::std::rc::Rc::new(crate::lower::model::Ex::XIf(::std::rc::Rc::new(crate::lower::model::Ex::XBin(crate::lower::model::BinOp::OpGe, ::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("v"))), ::std::rc::Rc::new(crate::lower::model::Ex::XIndex(&gd_pi.pos_p.at_p + &gd_pi.width_p)))), ::std::rc::Rc::new(gap_get_f(gd_pi)), ::std::rc::Rc::new(crate::lower::model::Ex::XIndex(crate::prelude::Nat::from(0u32))))))));
        let place_pb = crate::lower::model::MethDef { name_p: place_method_f(k_p7), recv_p: crate::lower::model::Recv::RecvRef, params_p: crate::prelude::Array::from(vec![(crate::prelude::Text::lit("v"), crate::lower::model::OutTy::OutCount)]), cx_p: crate::lower::model::CxArg::CxNone, ret_p: crate::lower::model::OutTy::OutCount, body_p: crate::prelude::Array::new(), tail_p: placed_pa.clone(), doc_p: crate::prelude::Text::lit("The position `v` as built: places are counted as they are built (ruling TC).") };
        let steps_pc = crate::prelude::each(&crate::check::errors::range0_f(&crate::prelude::len(&gaps_p8)), &(|i_pj: &crate::prelude::Nat| {
            let gd_pk = crate::prelude::or(&crate::prelude::index(&gaps_p8, i_pj), &dummy_gen_def_p());
            let before_pl = crate::lower::model::Ex::XVar(if i_pj == &crate::prelude::Nat::from(0u32) {
                crate::prelude::Text::lit("v")
            } else {
                crate::prelude::Text::from(format!("v{}", i_pj))
            });
            crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::prelude::Text::from(format!("v{}", &(i_pj + &crate::prelude::Nat::from(1u32))))), crate::lower::model::Ex::XIf(::std::rc::Rc::new(crate::lower::model::Ex::XBin(crate::lower::model::BinOp::OpGe, ::std::rc::Rc::new(before_pl.clone()), ::std::rc::Rc::new(crate::lower::model::Ex::XBin(crate::lower::model::BinOp::OpSub, ::std::rc::Rc::new(crate::lower::model::Ex::XIndex(&gd_pk.pos_p.at_p + &gd_pk.width_p)), ::std::rc::Rc::new(gap_get_f(&gd_pk)))))), ::std::rc::Rc::new(crate::lower::model::Ex::XBin(crate::lower::model::BinOp::OpAdd, ::std::rc::Rc::new(before_pl.clone()), ::std::rc::Rc::new(gap_get_f(&gd_pk)))), ::std::rc::Rc::new(before_pl.clone())))
        }));
        let seat_pd = crate::lower::model::MethDef { name_p: seat_method_f(k_p7), recv_p: crate::lower::model::Recv::RecvRef, params_p: crate::prelude::Array::from(vec![(crate::prelude::Text::lit("v"), crate::lower::model::OutTy::OutCount)]), cx_p: crate::lower::model::CxArg::CxNone, ret_p: crate::lower::model::OutTy::OutCount, body_p: steps_pc.clone(), tail_p: crate::lower::model::Ex::XVar(crate::prelude::Text::from(format!("v{}", &crate::prelude::len(&gaps_p8)))), doc_p: crate::prelude::Text::lit("The position an answer names, this node\'s gaps put back (ruling TC).") };
        let inner_pe = crate::lower::model::MethDef { name_p: crate::prelude::Text::lit("inner_gap"), recv_p: crate::lower::model::Recv::RecvRef, params_p: crate::prelude::Array::new(), cx_p: crate::lower::model::CxArg::CxNone, ret_p: crate::lower::model::OutTy::OutCount, body_p: crate::prelude::Array::new(), tail_p: crate::prelude::fold(&gaps_p8, &crate::lower::model::Ex::XIndex(crate::prelude::Nat::from(0u32)), &(|x_pm: &crate::lower::model::Ex, gd_pn: &crate::lower::model::GenDef| crate::lower::model::Ex::XBin(crate::lower::model::BinOp::OpAdd, ::std::rc::Rc::new(x_pm.clone()), ::std::rc::Rc::new(gap_get_f(gd_pn))))), doc_p: crate::prelude::Text::lit("How many positions this row\'s own generations left unbuilt.") };
        crate::prelude::append(acc_p6, &crate::prelude::append(&crate::prelude::Array::from(vec![place_pb.clone()]), &(if &crate::prelude::len(&gaps_p8) == &crate::prelude::Nat::from(0u32) {
            crate::prelude::Array::new()
        } else {
            if (k_p7 == &crate::prelude::Nat::from(0u32)) && is_some_nat_f(&wx_p0.based_o) {
                crate::prelude::Array::from(vec![seat_pd.clone(), inner_pe.clone()])
            } else {
                crate::prelude::Array::from(vec![seat_pd.clone()])
            }
        })))
    }))
}

/// ```prism
/// let dummyGenDef
/// ```
pub fn dummy_gen_def_p() -> crate::lower::model::GenDef {
    crate::lower::model::GenDef { name_p: crate::prelude::Text::lit(""), pos_p: crate::lower::model::Pos { scope_p: crate::prelude::Nat::from(0u32), at_p: crate::prelude::Nat::from(0u32) }, at_p: crate::lower::model::Ex::XUnit, source_p: crate::lower::model::Ex::XUnit, value_ty_p: crate::lower::model::OutTy::OutUnit, select_p: crate::lower::model::Ex::XUnit, transparent_p: false, width_p: crate::prelude::Nat::from(0u32), moved_p: crate::prelude::Text::lit(""), early_p: false, gappy_p: false, rebased_p: false }
}

/// ```prism
/// Seated: fn Wx, Nat, Ex -> (([Do], Ex))
/// ```
pub fn seated_f(wx_p0: &crate::lower::node_::Wx, scope_p1: &crate::prelude::Nat, segs_p2: &crate::lower::model::Ex) -> (crate::prelude::Array<crate::lower::model::Do>, crate::lower::model::Ex) {
    if &crate::prelude::len(&crate::prelude::filter(&wx_p0.gens_p, &(|gd_p3: &crate::lower::model::GenDef| gd_p3.gappy_p && (&gd_p3.pos_p.scope_p == scope_p1)))) == &crate::prelude::Nat::from(0u32) {
        (crate::prelude::Array::new(), segs_p2.clone())
    } else {
        (crate::prelude::Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("seated")), crate::lower::model::Ex::XCall(crate::lower::helper_ref_f(&crate::prelude::Text::lit("seated")), crate::prelude::Array::from(vec![segs_p2.clone(), crate::lower::model::Ex::XClosure(false, crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("a"))]), ::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), seat_method_f(scope_p1), crate::prelude::Array::from(vec![crate::lower::model::Ex::XVar(crate::prelude::Text::lit("a"))]))))])))]), crate::lower::model::Ex::XCall(crate::lower::helper_ref_f(&crate::prelude::Text::lit("segments_of")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("seated"))))])))
    }
}

/// ```prism
/// PosPat: fn Pos, [Pa] -> Pa
/// ```
pub fn pos_pat_f(pos_p0: &crate::lower::model::Pos, tail_p1: &crate::prelude::Array<crate::lower::model::Pa>) -> crate::lower::model::Pa {
    crate::lower::model::Pa::PaSlice(crate::prelude::append(&crate::prelude::Array::from(vec![crate::lower::model::Pa::PaCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Segment::Pos")), crate::prelude::Array::from(vec![crate::lower::model::Pa::PaIndex(pos_p0.at_p.clone())]))]), tail_p1))
}

/// ```prism
/// let keyTail
/// ```
pub fn key_tail_p() -> crate::prelude::Array<crate::lower::model::Pa> {
    crate::prelude::Array::from(vec![crate::lower::model::Pa::PaCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Segment::Key")), crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("k"))])), crate::lower::model::Pa::PaRest(crate::prelude::Text::lit("rest"))])
}

/// ```prism
/// let genTail
/// ```
pub fn gen_tail_p() -> crate::prelude::Array<crate::lower::model::Pa> {
    crate::prelude::Array::from(vec![crate::lower::model::Pa::PaCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Segment::Gen")), crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("g"))])), crate::lower::model::Pa::PaRest(crate::prelude::Text::lit("rest"))])
}

/// ```prism
/// ?HostedRows: fn Wx -> ?Text
/// ```
pub fn hosted_rows_o(wx_p0: &crate::lower::node_::Wx) -> ::std::option::Option<crate::prelude::Text> {
    if &wx_p0.pos_p.scope_p > &crate::prelude::Nat::from(0u32) {
        ::std::option::Option::Some(crate::prelude::Text::from(format!("{}_moved", &crate::prelude::or(&crate::prelude::index(&wx_p0.scopes_p, &crate::syntax::lexer::chars::dec_f(&wx_p0.pos_p.scope_p)), &crate::prelude::Text::lit("")))))
    } else {
        match &wx_p0.hosted_by_o {
            ::std::option::Option::Some(_) => ::std::option::Option::Some(crate::prelude::Text::lit("document_moved")),
            ::std::option::Option::None => ::std::option::Option::None,
        }
    }
}

/// ```prism
/// RootDynPatch: fn Wx -> [Do]
/// ```
pub fn root_dyn_patch_f(wx_p0: &crate::lower::node_::Wx) -> crate::prelude::Array<crate::lower::model::Do> {
    crate::prelude::each(&crate::check::errors::range0_f(&crate::prelude::len(&wx_p0.root_dyns_p)), &(|k_p1: &crate::prelude::Nat| crate::lower::model::Do::DoLine(result_moved_f(&crate::lower::model::Ex::XSelf, k_p1))))
}

/// ```prism
/// AnswerArm: fn Wx, Pos, Nat, OutTy -> ((Pa, Ex))
/// ```
pub fn answer_arm_f(wx_p0: &crate::lower::node_::Wx, pos_p1: &crate::lower::model::Pos, id_p2: &crate::prelude::Nat, t_p3: &crate::lower::model::OutTy) -> (crate::lower::model::Pa, crate::lower::model::Ex) {
    let call_p4 = crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::lower::node_::gn_of_f(wx_p0, id_p2).name_p.clone(), crate::prelude::Array::from(vec![crate::lower::model::Ex::XDecode(t_p3.clone(), ::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("v")))), crate::lower::model::Ex::XCx]));
    (pos_pat_f(pos_p1, &crate::prelude::Array::new()), call_p4.clone())
}

/// ```prism
/// TypedAnswerArm: unbounded fn Wx, Pos, Nat, OutTy, Text -> ((Pa, [Do]))
/// ```
pub fn typed_answer_arm_f(wx_p0: &crate::lower::node_::Wx, pos_p1: &crate::lower::model::Pos, id_p2: &crate::prelude::Nat, placed_p3: &crate::lower::model::OutTy, acc_p4: &crate::prelude::Text) -> (crate::lower::model::Pa, crate::prelude::Array<crate::lower::model::Do>) {
    (pos_pat_f(pos_p1, &crate::prelude::Array::new()), crate::prelude::Array::from(vec![self_call_f(&crate::lower::node_::gn_of_f(wx_p0, id_p2).name_p, &crate::prelude::Array::from(vec![crate::lower::program::answer_taken_f(&wx_p0.lx_p, acc_p4, placed_p3, &crate::lower::expr::try_of_f(&crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("v"))), acc_p4.clone(), crate::prelude::Array::new())))]))]))
}

/// The step machine of `TypedAnswerArm`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TypedAnswerArm: unbounded fn Wx, Pos, Nat, OutTy, Text -> ((Pa, [Do]))
/// ```
pub struct TypedAnswerArm {
    pub wx_p0: crate::lower::node_::Wx,
    pub pos_p1: crate::lower::model::Pos,
    pub id_p2: crate::prelude::Nat,
    pub placed_p3: crate::lower::model::OutTy,
    pub acc_p4: crate::prelude::Text,
}

impl ::prism_rtl::Job<(crate::lower::model::Pa, crate::prelude::Array<crate::lower::model::Do>)> for TypedAnswerArm {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::lower::model::Pa, crate::prelude::Array<crate::lower::model::Do>)> {
        let wx_p0 = &self.wx_p0;
        let pos_p1 = &self.pos_p1;
        let id_p2 = &self.id_p2;
        let placed_p3 = &self.placed_p3;
        let acc_p4 = &self.acc_p4;
        let acc_p4x = acc_p4.clone();
        let id_p2x = id_p2.clone();
        let placed_p3x = placed_p3.clone();
        let pos_p1x = pos_p1.clone();
        let wx_p0x = wx_p0.clone();
        crate::prelude::call_then(crate::lower::program::start_answer_taken_f(wx_p0x.lx_p.clone(), acc_p4x.clone(), placed_p3x.clone(), crate::lower::expr::try_of_f(&crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("v"))), acc_p4x.clone(), crate::prelude::Array::new()))), move |answer_taken_f_81424: crate::lower::model::Ex| ::prism_rtl::Turn::Finished((pos_pat_f(&pos_p1x, &crate::prelude::Array::new()), crate::prelude::Array::from(vec![self_call_f(&crate::lower::node_::gn_of_f(&wx_p0x, &id_p2x).name_p, &crate::prelude::Array::from(vec![answer_taken_f_81424]))]))))
    }
}

/// `Start TypedAnswerArm, x`: what the function value is when passed to `@Run`.
pub fn start_typed_answer_arm_f(wx_p0: crate::lower::node_::Wx, pos_p1: crate::lower::model::Pos, id_p2: crate::prelude::Nat, placed_p3: crate::lower::model::OutTy, acc_p4: crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::model::Pa, crate::prelude::Array<crate::lower::model::Do>)>> {
    ::std::rc::Rc::new(TypedAnswerArm { wx_p0, pos_p1, id_p2, placed_p3, acc_p4 })
}

/// ```prism
/// BundleStateWrite: fn Sinks, BundlePlace, Ex -> [Do]
/// ```
pub fn bundle_state_write_f(sk_p0: &Sinks, bp_p1: &crate::lower::node_::BundlePlace, value_p2: &crate::lower::model::Ex) -> crate::prelude::Array<crate::lower::model::Do> {
    if &bp_p1.state_parts_p == &crate::prelude::Nat::from(1u32) {
        crate::prelude::fold(&bp_p1.holds_p, &crate::prelude::Array::new(), &(|acc_p3: &crate::prelude::Array<crate::lower::model::Do>, (_, f_p4, _): &(crate::prelude::Nat, crate::prelude::Text, crate::lower::model::OutTy)| crate::prelude::append(acc_p3, &dyn_place_write_f(sk_p0, f_p4, value_p2))))
    } else {
        crate::prelude::fold(&bp_p1.holds_p, &crate::prelude::Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("state")), value_p2.clone())]), &(|acc_p5: &crate::prelude::Array<crate::lower::model::Do>, (k_p6, f_p7, _): &(crate::prelude::Nat, crate::prelude::Text, crate::lower::model::OutTy)| crate::prelude::append(acc_p5, &dyn_place_write_f(sk_p0, f_p7, &crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XPart(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("state"))), k_p6.clone())))))))
    }
}

/// ```prism
/// BundleEventsFire: fn Wx, BundlePlace, Ex -> [Do]
/// ```
pub fn bundle_events_fire_f(wx_p0: &crate::lower::node_::Wx, bp_p1: &crate::lower::node_::BundlePlace, events_p2: &crate::lower::model::Ex) -> crate::prelude::Array<crate::lower::model::Do> {
    'm82353: {
        let scrutinee = &bp_p1.events_p;
        if let m82353_0 = scrutinee && (m82353_0.len() == 0) {
            break 'm82353 crate::prelude::Array::new();
        }
        if let m82353_1 = scrutinee && (m82353_1.len() == 1) && let ::std::option::Option::Some((id_p3, _)) = crate::prelude::index(m82353_1, &crate::prelude::Nat::from(0u32)) {
            break 'm82353 crate::prelude::Array::from(vec![self_call_f(&crate::lower::node_::gn_of_f(wx_p0, &id_p3).name_p, &crate::prelude::Array::from(vec![events_p2.clone()]))]);
        }
        crate::prelude::fold(&crate::check::errors::range0_f(&crate::prelude::len(&bp_p1.events_p)), &crate::prelude::Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("events")), events_p2.clone())]), &(|acc_p4: &crate::prelude::Array<crate::lower::model::Do>, j_p5: &crate::prelude::Nat| match crate::prelude::index(&bp_p1.events_p, j_p5) {
            ::std::option::Option::Some((id_p6, _)) => crate::prelude::push(acc_p4, &crate::lower::model::Do::DoIfLet(crate::lower::model::Pa::PaCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Some")), crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("part"))])), crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XPart(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("events"))), j_p5.clone())), crate::prelude::Text::lit("present"), crate::prelude::Array::new()), crate::prelude::Array::from(vec![self_call_f(&crate::lower::node_::gn_of_f(wx_p0, &id_p6).name_p, &crate::prelude::Array::from(vec![crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("part"))))]))]), crate::prelude::Array::new())),
            ::std::option::Option::None => acc_p4.clone(),
        }))
    }
}

/// ```prism
/// BundleEventsTy: fn BundlePlace -> OutTy
/// ```
pub fn bundle_events_ty_f(bp_p0: &crate::lower::node_::BundlePlace) -> crate::lower::model::OutTy {
    'm82938: {
        let scrutinee = &bp_p0.events_p;
        if let m82938_0 = scrutinee && (m82938_0.len() == 1) && let ::std::option::Option::Some((_, t_p1)) = crate::prelude::index(m82938_0, &crate::prelude::Nat::from(0u32)) {
            break 'm82938 t_p1.clone();
        }
        crate::lower::model::OutTy::OutTuple(crate::prelude::each(&bp_p0.events_p, &(|(_, t_p2): &(crate::prelude::Nat, crate::lower::model::OutTy)| crate::lower::program::sparse_part_ty_f(t_p2))))
    }
}

/// ```prism
/// BundleAnswerArm: fn Sinks, BundlePlace -> ((Pa, Ex))
/// ```
pub fn bundle_answer_arm_f(sk_p0: &Sinks, bp_p1: &crate::lower::node_::BundlePlace) -> (crate::lower::model::Pa, crate::lower::model::Ex) {
    let dos_p2 = if &crate::prelude::len(&bp_p1.events_p) == &crate::prelude::Nat::from(0u32) {
        bundle_state_write_f(sk_p0, bp_p1, &crate::lower::model::Ex::XDecode(bp_p1.state_ty_p.clone(), ::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("v")))))
    } else {
        bundle_events_fire_f(&sk_p0.wx_p, bp_p1, &crate::lower::model::Ex::XDecode(bundle_events_ty_f(bp_p1), ::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("v")))))
    };
    (pos_pat_f(&bp_p1.pos_p, &crate::prelude::Array::new()), crate::lower::model::Ex::XBlock(dos_p2.clone(), ::std::rc::Rc::new(crate::lower::model::Ex::XUnit)))
}

/// ```prism
/// BundleTypedArm: unbounded fn Sinks, BundlePlace -> ((Pa, [Do]))
/// ```
pub fn bundle_typed_arm_f(sk_p0: &Sinks, bp_p1: &crate::lower::node_::BundlePlace) -> (crate::lower::model::Pa, crate::prelude::Array<crate::lower::model::Do>) {
    let lx_p2 = sk_p0.wx_p.lx_p.clone();
    let taken_f3 = {
        let lx_p2x = lx_p2.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Text, crate::lower::model::OutTy)| {
            let lx_p2xy = lx_p2x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_p7 = p0;
                let placed_p8 = p1;
                ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::lower::program::AnswerTaken { lx_p0: lx_p2xy.clone(), accessor_p1: acc_p7.clone(), placed_p2: placed_p8.clone(), taken_p3: crate::lower::expr::try_of_f(&crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("v"))), acc_p7.clone(), crate::prelude::Array::new())) }))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::lower::model::OutTy)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>>>
    };
    let fired_p4 = bundle_events_fire_f(&sk_p0.wx_p, bp_p1, &crate::prelude::run_to_end((&taken_f3)((bp_p1.event_accessor_p.clone(), bundle_events_ty_f(bp_p1)))));
    let pushed_p5 = if &bp_p1.stem_p == &crate::prelude::Text::lit("") {
        crate::prelude::Array::new()
    } else {
        bundle_state_write_f(sk_p0, bp_p1, &crate::prelude::run_to_end((&taken_f3)((bp_p1.state_accessor_p.clone(), bp_p1.state_ty_p.clone()))))
    };
    let dos_p6 = if &crate::prelude::len(&bp_p1.events_p) == &crate::prelude::Nat::from(0u32) {
        pushed_p5.clone()
    } else {
        if &bp_p1.stem_p == &crate::prelude::Text::lit("") {
            fired_p4.clone()
        } else {
            crate::prelude::Array::from(vec![crate::lower::model::Do::DoIf(crate::lower::model::Ex::XIsCase(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("v"))), crate::prelude::Array::from(vec![bp_p1.first_variant_p.clone()])), pushed_p5.clone(), fired_p4.clone())])
        }
    };
    (pos_pat_f(&bp_p1.pos_p, &crate::prelude::Array::new()), dos_p6.clone())
}

/// The step machine of `BundleTypedArm`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BundleTypedArm: unbounded fn Sinks, BundlePlace -> ((Pa, [Do]))
/// ```
pub struct BundleTypedArm {
    pub sk_p0: Sinks,
    pub bp_p1: crate::lower::node_::BundlePlace,
}

impl ::prism_rtl::Job<(crate::lower::model::Pa, crate::prelude::Array<crate::lower::model::Do>)> for BundleTypedArm {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::lower::model::Pa, crate::prelude::Array<crate::lower::model::Do>)> {
        let sk_p0 = &self.sk_p0;
        let bp_p1 = &self.bp_p1;
        let lx_p2 = sk_p0.wx_p.lx_p.clone();
        let taken_f3 = {
            let lx_p2x = lx_p2.clone();
            ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Text, crate::lower::model::OutTy)| {
                let lx_p2xy = lx_p2x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let acc_p7 = p0;
                    let placed_p8 = p1;
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::lower::program::AnswerTaken { lx_p0: lx_p2xy.clone(), accessor_p1: acc_p7.clone(), placed_p2: placed_p8.clone(), taken_p3: crate::lower::expr::try_of_f(&crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("v"))), acc_p7.clone(), crate::prelude::Array::new())) }))
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::lower::model::OutTy)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>>>
        };
        let bp_p1x = bp_p1.clone();
        let sk_p0x = sk_p0.clone();
        crate::prelude::call_value((&taken_f3)((bp_p1x.event_accessor_p.clone(), bundle_events_ty_f(&bp_p1x))), move |taken_84022: crate::lower::model::Ex| {
            let fired_p4 = bundle_events_fire_f(&sk_p0x.wx_p, &bp_p1x, &taken_84022);
            let bp_p1xz = bp_p1x.clone();
            let fired_p4z = fired_p4.clone();
            let k_let84071 = move |v84071: crate::prelude::Array<crate::lower::model::Do>| {
                let pushed_p5 = v84071;
                let dos_p6 = if &crate::prelude::len(&bp_p1xz.events_p) == &crate::prelude::Nat::from(0u32) {
                    pushed_p5.clone()
                } else {
                    if &bp_p1xz.stem_p == &crate::prelude::Text::lit("") {
                        fired_p4z.clone()
                    } else {
                        crate::prelude::Array::from(vec![crate::lower::model::Do::DoIf(crate::lower::model::Ex::XIsCase(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("v"))), crate::prelude::Array::from(vec![bp_p1xz.first_variant_p.clone()])), pushed_p5.clone(), fired_p4z.clone())])
                    }
                };
                ::prism_rtl::Turn::Finished((pos_pat_f(&bp_p1xz.pos_p, &crate::prelude::Array::new()), dos_p6.clone()))
            };
            if &bp_p1x.stem_p == &crate::prelude::Text::lit("") {
                k_let84071(crate::prelude::Array::new())
            } else {
                crate::prelude::call_value((&taken_f3)((bp_p1x.state_accessor_p.clone(), bp_p1x.state_ty_p.clone())), move |taken_84139: crate::lower::model::Ex| k_let84071(bundle_state_write_f(&sk_p0x, &bp_p1x, &taken_84139)))
            }
        })
    }
}

/// `Start BundleTypedArm, x`: what the function value is when passed to `@Run`.
pub fn start_bundle_typed_arm_f(sk_p0: Sinks, bp_p1: crate::lower::node_::BundlePlace) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::model::Pa, crate::prelude::Array<crate::lower::model::Do>)>> {
    ::std::rc::Rc::new(BundleTypedArm { sk_p0, bp_p1 })
}

/// ```prism
/// TypedDynArm: unbounded fn Sinks, Pos, Text, OutTy, Text -> ((Pa, [Do]))
/// ```
pub fn typed_dyn_arm_f(sk_p0: &Sinks, pos_p1: &crate::lower::model::Pos, f_p2: &crate::prelude::Text, placed_p3: &crate::lower::model::OutTy, acc_p4: &crate::prelude::Text) -> (crate::lower::model::Pa, crate::prelude::Array<crate::lower::model::Do>) {
    (pos_pat_f(pos_p1, &crate::prelude::Array::new()), dyn_place_write_f(sk_p0, f_p2, &crate::lower::program::answer_taken_f(&sk_p0.wx_p.lx_p, acc_p4, placed_p3, &crate::lower::expr::try_of_f(&crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("v"))), acc_p4.clone(), crate::prelude::Array::new())))))
}

/// The step machine of `TypedDynArm`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TypedDynArm: unbounded fn Sinks, Pos, Text, OutTy, Text -> ((Pa, [Do]))
/// ```
pub struct TypedDynArm {
    pub sk_p0: Sinks,
    pub pos_p1: crate::lower::model::Pos,
    pub f_p2: crate::prelude::Text,
    pub placed_p3: crate::lower::model::OutTy,
    pub acc_p4: crate::prelude::Text,
}

impl ::prism_rtl::Job<(crate::lower::model::Pa, crate::prelude::Array<crate::lower::model::Do>)> for TypedDynArm {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::lower::model::Pa, crate::prelude::Array<crate::lower::model::Do>)> {
        let sk_p0 = &self.sk_p0;
        let pos_p1 = &self.pos_p1;
        let f_p2 = &self.f_p2;
        let placed_p3 = &self.placed_p3;
        let acc_p4 = &self.acc_p4;
        let acc_p4x = acc_p4.clone();
        let f_p2x = f_p2.clone();
        let placed_p3x = placed_p3.clone();
        let pos_p1x = pos_p1.clone();
        let sk_p0x = sk_p0.clone();
        crate::prelude::call_then(crate::lower::program::start_answer_taken_f(sk_p0x.wx_p.lx_p.clone(), acc_p4x.clone(), placed_p3x.clone(), crate::lower::expr::try_of_f(&crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("v"))), acc_p4x.clone(), crate::prelude::Array::new()))), move |answer_taken_f_84519: crate::lower::model::Ex| ::prism_rtl::Turn::Finished((pos_pat_f(&pos_p1x, &crate::prelude::Array::new()), dyn_place_write_f(&sk_p0x, &f_p2x, &answer_taken_f_84519))))
    }
}

/// `Start TypedDynArm, x`: what the function value is when passed to `@Run`.
pub fn start_typed_dyn_arm_f(sk_p0: Sinks, pos_p1: crate::lower::model::Pos, f_p2: crate::prelude::Text, placed_p3: crate::lower::model::OutTy, acc_p4: crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::model::Pa, crate::prelude::Array<crate::lower::model::Do>)>> {
    ::std::rc::Rc::new(TypedDynArm { sk_p0, pos_p1, f_p2, placed_p3, acc_p4 })
}

/// ```prism
/// TypedForwardArm: fn ForDef, Ex -> ((Pa, [Do]))
/// ```
pub fn typed_forward_arm_f(b_p0: &crate::lower::model::ForDef, segs_p1: &crate::lower::model::Ex) -> (crate::lower::model::Pa, crate::prelude::Array<crate::lower::model::Do>) {
    let row_of_p2 = crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::from(format!("{}", &b_p0.name_p)))), crate::prelude::Text::lit("borrow"), crate::prelude::Array::new())), crate::prelude::Text::lit("get"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XDecode(b_p0.key_ty_p.clone(), ::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("k"))))))]))), crate::prelude::Text::lit("cloned"), crate::prelude::Array::new());
    (pos_pat_f(&b_p0.pos_p, &key_tail_p()), crate::prelude::Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("row")), row_of_p2.clone()), crate::lower::model::Do::DoMatch(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("row")), crate::prelude::Array::from(vec![(crate::lower::model::Pa::PaCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Some")), crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("row"))])), crate::prelude::Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::expr::try_of_f(&crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("row"))), crate::prelude::Text::lit("deliver"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XVar(crate::prelude::Text::lit("rest")), crate::lower::model::Ex::XVar(crate::prelude::Text::lit("v")), crate::lower::model::Ex::XCx]))))])), (crate::lower::model::Pa::PaUnit(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::None"))), crate::prelude::Array::from(vec![crate::lower::model::Do::DoReturn(crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Err")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Fault::answer")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XFormatStr(crate::prelude::Array::from(vec![crate::lower::model::Ex::XText(crate::prelude::Text::lit("no row ")), crate::lower::model::Ex::XVar(crate::prelude::Text::lit("k")), crate::lower::model::Ex::XText(crate::prelude::Text::lit(" under the hosted place ")), crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Path")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XMethod(::std::rc::Rc::new(segs_p1.clone()), crate::prelude::Text::lit("to_vec"), crate::prelude::Array::new())]))]))]))])))]))]))]))
}

/// ```prism
/// TypedGenArms: fn GenDef, Ex -> [((Pa, [Do]))]
/// ```
pub fn typed_gen_arms_f(gd_p0: &crate::lower::model::GenDef, segs_p1: &crate::lower::model::Ex) -> crate::prelude::Array<(crate::lower::model::Pa, crate::prelude::Array<crate::lower::model::Do>)> {
    if crate::lower::node_::switch_::is_wide_gen_f(gd_p0) {
        crate::prelude::Array::new()
    } else {
        if gd_p0.transparent_p {
            crate::prelude::each(&crate::check::errors::range0_f(&gd_p0.width_p), &(|i_p2: &crate::prelude::Nat| transparent_gen_arm_f(gd_p0, segs_p1, i_p2)))
        } else {
            crate::prelude::Array::from(vec![typed_gen_arm_f(gd_p0)])
        }
    }
}

/// ```prism
/// TransparentGenArm: fn GenDef, Ex, Nat -> ((Pa, [Do]))
/// ```
pub fn transparent_gen_arm_f(gd_p0: &crate::lower::model::GenDef, segs_p1: &crate::lower::model::Ex, i_p2: &crate::prelude::Nat) -> (crate::lower::model::Pa, crate::prelude::Array<crate::lower::model::Do>) {
    let current_p3 = crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::from(format!("{}", &gd_p0.name_p)))), crate::prelude::Text::lit("borrow"), crate::prelude::Array::new())));
    (pos_pat_f(&crate::lower::model::Pos { scope_p: gd_p0.pos_p.scope_p.clone(), at_p: &gd_p0.pos_p.at_p + i_p2 }, &crate::prelude::Array::from(vec![crate::lower::model::Pa::PaRest(crate::prelude::Text::lit(""))])), crate::prelude::Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("row")), current_p3.clone()), crate::lower::model::Do::DoIfLet(crate::lower::model::Pa::PaCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Some")), crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("row"))])), crate::lower::model::Ex::XVar(crate::prelude::Text::lit("row")), crate::prelude::Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::expr::try_of_f(&crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("row"))), crate::prelude::Text::lit("deliver"), crate::prelude::Array::from(vec![segs_p1.clone(), crate::lower::model::Ex::XVar(crate::prelude::Text::lit("v")), crate::lower::model::Ex::XCx]))))]), crate::prelude::Array::new())]))
}

/// ```prism
/// TypedGenArm: fn GenDef -> ((Pa, [Do]))
/// ```
pub fn typed_gen_arm_f(gd_p0: &crate::lower::model::GenDef) -> (crate::lower::model::Pa, crate::prelude::Array<crate::lower::model::Do>) {
    let current_p1 = crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::from(format!("{}", &gd_p0.name_p)))), crate::prelude::Text::lit("borrow"), crate::prelude::Array::new())));
    let is_current_p2 = crate::lower::model::Ex::XBin(crate::lower::model::BinOp::OpEq, ::std::rc::Rc::new(crate::lower::model::Ex::XBin(crate::lower::model::BinOp::OpAdd, ::std::rc::Rc::new(crate::lower::model::Ex::XDeref(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("g"))))), ::std::rc::Rc::new(crate::lower::model::Ex::XIndex(crate::prelude::Nat::from(1u32))))), ::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::from(format!("{}_count", &gd_p0.name_p)))), crate::prelude::Text::lit("get"), crate::prelude::Array::new())));
    (pos_pat_f(&gd_p0.pos_p, &gen_tail_p()), crate::prelude::Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("row")), current_p1.clone()), crate::lower::model::Do::DoIfLet(crate::lower::model::Pa::PaCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Some")), crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("row"))])), crate::lower::model::Ex::XVar(crate::prelude::Text::lit("row")), crate::prelude::Array::from(vec![crate::lower::model::Do::DoIf(is_current_p2.clone(), crate::prelude::Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::expr::try_of_f(&crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("row"))), crate::prelude::Text::lit("deliver"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XVar(crate::prelude::Text::lit("rest")), crate::lower::model::Ex::XVar(crate::prelude::Text::lit("v")), crate::lower::model::Ex::XCx]))))]), crate::prelude::Array::new())]), crate::prelude::Array::new())]))
}

/// ```prism
/// TypedDispatch: unbounded fn Sinks, Text, Nat -> MethDef
/// ```
pub fn typed_dispatch_f(sk_p0: &Sinks, name_p1: &crate::prelude::Text, scope_p2: &crate::prelude::Nat) -> crate::lower::model::MethDef {
    let wx_p3 = sk_p0.wx_p.clone();
    let in_scope_f4 = {
        let scope_p2x = scope_p2.clone();
        ::std::rc::Rc::new(move |p_pe: &crate::lower::model::Pos| &p_pe.scope_p == &scope_p2x) as ::std::rc::Rc<dyn ::std::ops::Fn(&crate::lower::model::Pos) -> bool>
    };
    let (recv_pf, param_pg, segs0_ph, doc_pi) = if scope_p2 > &crate::prelude::Nat::from(0u32) {
        (crate::lower::model::Recv::RecvRc, (crate::prelude::Text::lit("place"), crate::lower::model::OutTy::OutRef(::std::rc::Rc::new(crate::lower::model::OutTy::OutPath))), crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("place"))), crate::prelude::Text::lit("segments"), crate::prelude::Array::new()), crate::prelude::Text::from(format!("The host at place {} answers its child\'s place `place` (pick HO): into the child\'s input method, a hold the place\'s element answers, or the row of a `for` or `rebuild` under it.", &crate::lower::model::place_text_f(&crate::prelude::or(&crate::prelude::index(&wx_p3.hosts_p, &crate::syntax::lexer::chars::dec_f(scope_p2)), &dummy_host_p()).pos_p))))
    } else {
        (crate::lower::model::Recv::RecvOwned, (crate::prelude::Text::lit("at"), crate::lower::model::OutTy::OutRef(::std::rc::Rc::new(crate::lower::model::OutTy::OutSlice(::std::rc::Rc::new(crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Segment")), crate::prelude::Array::new())))))), crate::lower::model::Ex::XVar(crate::prelude::Text::lit("at")), crate::prelude::Text::lit("A host\'s answer to a place of this row\'s own, `at` under the row (pick HO): into the input method, a hold, or a row under it."))
    };
    let (seating_pj, segs_pk) = seated_f(&wx_p3, scope_p2, &segs0_ph);
    let answers_p5 = crate::prelude::run_to_end(crate::prelude::each_job(crate::prelude::filter(&wx_p3.answers_p, &(|(pos_pl, _, _, _): &(crate::lower::model::Pos, crate::prelude::Nat, crate::lower::model::OutTy, crate::prelude::Text)| (&in_scope_f4)(pos_pl))), {
        let wx_p3x = wx_p3.clone();
        ::std::rc::Rc::new(move |p0: (crate::lower::model::Pos, crate::prelude::Nat, crate::lower::model::OutTy, crate::prelude::Text)| {
            let wx_p3xy = wx_p3x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (pos_pm, id_pn, placed_po, acc_pp) = p0;
                ::prism_rtl::Turn::More(::std::rc::Rc::new(TypedAnswerArm { wx_p0: wx_p3xy.clone(), pos_p1: pos_pm.clone(), id_p2: id_pn.clone(), placed_p3: placed_po.clone(), acc_p4: acc_pp.clone() }))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::model::Pos, crate::prelude::Nat, crate::lower::model::OutTy, crate::prelude::Text)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::model::Pa, crate::prelude::Array<crate::lower::model::Do>)>>>
    }));
    let dyns_p6 = crate::prelude::run_to_end(crate::prelude::each_job(crate::prelude::filter(&wx_p3.dyn_places_p, &(|(pos_pq, _, _, _): &(crate::lower::model::Pos, crate::prelude::Text, crate::lower::model::OutTy, crate::prelude::Text)| (&in_scope_f4)(pos_pq))), {
        let sk_p0x = sk_p0.clone();
        ::std::rc::Rc::new(move |p0: (crate::lower::model::Pos, crate::prelude::Text, crate::lower::model::OutTy, crate::prelude::Text)| {
            let sk_p0xy = sk_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (pos_pr, f_ps, placed_pt, acc_pu) = p0;
                ::prism_rtl::Turn::More(::std::rc::Rc::new(TypedDynArm { sk_p0: sk_p0xy.clone(), pos_p1: pos_pr.clone(), f_p2: f_ps.clone(), placed_p3: placed_pt.clone(), acc_p4: acc_pu.clone() }))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::model::Pos, crate::prelude::Text, crate::lower::model::OutTy, crate::prelude::Text)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::model::Pa, crate::prelude::Array<crate::lower::model::Do>)>>>
    }));
    let bundles_p7 = crate::prelude::run_to_end(crate::prelude::each_job(crate::prelude::filter(&wx_p3.bundles_p, &(|bp_pv: &crate::lower::node_::BundlePlace| (&in_scope_f4)(&bp_pv.pos_p) && ((&crate::prelude::len(&bp_pv.events_p) > &crate::prelude::Nat::from(0u32)) || (&bp_pv.stem_p != &crate::prelude::Text::lit(""))))), {
        let sk_p0x = sk_p0.clone();
        ::std::rc::Rc::new(move |p0: crate::lower::node_::BundlePlace| {
            let sk_p0xy = sk_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let bp_p10 = p0;
                ::prism_rtl::Turn::More(::std::rc::Rc::new(BundleTypedArm { sk_p0: sk_p0xy.clone(), bp_p1: bp_p10.clone() }))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::node_::BundlePlace) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::model::Pa, crate::prelude::Array<crate::lower::model::Do>)>>>
    }));
    let rows_p8 = crate::prelude::each(&crate::prelude::filter(&wx_p3.builders_p, &(|b_p11: &crate::lower::model::ForDef| (&in_scope_f4)(&b_p11.pos_p))), &(|b_p12: &crate::lower::model::ForDef| typed_forward_arm_f(b_p12, &segs_pk)));
    let gens_p9 = crate::prelude::fold(&crate::prelude::filter(&wx_p3.gens_p, &(|gd_p13: &crate::lower::model::GenDef| (&in_scope_f4)(&gd_p13.pos_p))), &crate::prelude::Array::new(), &(|acc_p14: &crate::prelude::Array<(crate::lower::model::Pa, crate::prelude::Array<crate::lower::model::Do>)>, gd_p15: &crate::lower::model::GenDef| crate::prelude::append(acc_p14, &typed_gen_arms_f(gd_p15, &segs_pk))));
    let none_pa = (crate::lower::model::Pa::PaWild, crate::prelude::Array::from(vec![crate::lower::model::Do::DoReturn(crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Err")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Fault::answer")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XFormatStr(crate::prelude::Array::from(vec![crate::lower::model::Ex::XText(crate::prelude::Text::lit("no hosted place at ")), crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Path")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XMethod(::std::rc::Rc::new(segs_pk.clone()), crate::prelude::Text::lit("to_vec"), crate::prelude::Array::new())])), crate::lower::model::Ex::XText(crate::prelude::Text::lit(" to answer"))]))]))])))]));
    let wide_pb = crate::prelude::filter(&wx_p3.gens_p, &(|gd_p16: &crate::lower::model::GenDef| (&in_scope_f4)(&gd_p16.pos_p) && crate::lower::node_::switch_::is_wide_gen_f(gd_p16)));
    let (_, none_dos_p17) = none_pa.clone();
    let last_pc = if &crate::prelude::len(&wide_pb) == &crate::prelude::Nat::from(0u32) {
        crate::prelude::Array::from(vec![none_pa.clone()])
    } else {
        crate::lower::node_::switch_::typed_wide_forward_f(&wide_pb, &segs_pk, &none_dos_p17)
    };
    let arms_pd = crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&answers_p5, &dyns_p6), &bundles_p7), &rows_p8), &gens_p9), &last_pc);
    crate::lower::model::MethDef { name_p: name_p1.clone(), recv_p: recv_pf.clone(), params_p: crate::prelude::Array::from(vec![param_pg.clone(), (crate::prelude::Text::lit("v"), crate::lower::model::OutTy::OutRef(::std::rc::Rc::new(crate::lower::types::answer_ty_p())))]), cx_p: crate::lower::model::CxArg::CxMut, ret_p: crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Done")), crate::prelude::Array::new()), body_p: crate::prelude::push(&seating_pj, &crate::lower::model::Do::DoMatch(segs_pk.clone(), arms_pd.clone())), tail_p: crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Ok")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XUnit])), doc_p: doc_pi.clone() }
}

/// The step machine of `TypedDispatch`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TypedDispatch: unbounded fn Sinks, Text, Nat -> MethDef
/// ```
pub struct TypedDispatch {
    pub sk_p0: Sinks,
    pub name_p1: crate::prelude::Text,
    pub scope_p2: crate::prelude::Nat,
}

impl ::prism_rtl::Job<crate::lower::model::MethDef> for TypedDispatch {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::lower::model::MethDef> {
        let sk_p0 = &self.sk_p0;
        let name_p1 = &self.name_p1;
        let scope_p2 = &self.scope_p2;
        let wx_p3 = sk_p0.wx_p.clone();
        let in_scope_f4 = {
            let scope_p2x = scope_p2.clone();
            ::std::rc::Rc::new(move |p_pe: &crate::lower::model::Pos| &p_pe.scope_p == &scope_p2x) as ::std::rc::Rc<dyn ::std::ops::Fn(&crate::lower::model::Pos) -> bool>
        };
        let (recv_pf, param_pg, segs0_ph, doc_pi) = if scope_p2 > &crate::prelude::Nat::from(0u32) {
            (crate::lower::model::Recv::RecvRc, (crate::prelude::Text::lit("place"), crate::lower::model::OutTy::OutRef(::std::rc::Rc::new(crate::lower::model::OutTy::OutPath))), crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("place"))), crate::prelude::Text::lit("segments"), crate::prelude::Array::new()), crate::prelude::Text::from(format!("The host at place {} answers its child\'s place `place` (pick HO): into the child\'s input method, a hold the place\'s element answers, or the row of a `for` or `rebuild` under it.", &crate::lower::model::place_text_f(&crate::prelude::or(&crate::prelude::index(&wx_p3.hosts_p, &crate::syntax::lexer::chars::dec_f(scope_p2)), &dummy_host_p()).pos_p))))
        } else {
            (crate::lower::model::Recv::RecvOwned, (crate::prelude::Text::lit("at"), crate::lower::model::OutTy::OutRef(::std::rc::Rc::new(crate::lower::model::OutTy::OutSlice(::std::rc::Rc::new(crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Segment")), crate::prelude::Array::new())))))), crate::lower::model::Ex::XVar(crate::prelude::Text::lit("at")), crate::prelude::Text::lit("A host\'s answer to a place of this row\'s own, `at` under the row (pick HO): into the input method, a hold, or a row under it."))
        };
        let (seating_pj, segs_pk) = seated_f(&wx_p3, scope_p2, &segs0_ph);
        let name_p1x = name_p1.clone();
        let sk_p0x = sk_p0.clone();
        crate::prelude::call_value(crate::prelude::each_job(crate::prelude::filter(&wx_p3.answers_p, &(|(pos_pl, _, _, _): &(crate::lower::model::Pos, crate::prelude::Nat, crate::lower::model::OutTy, crate::prelude::Text)| (&in_scope_f4)(pos_pl))), {
            let wx_p3x = wx_p3.clone();
            ::std::rc::Rc::new(move |p0: (crate::lower::model::Pos, crate::prelude::Nat, crate::lower::model::OutTy, crate::prelude::Text)| {
                let wx_p3xy = wx_p3x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let (pos_pm, id_pn, placed_po, acc_pp) = p0;
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(TypedAnswerArm { wx_p0: wx_p3xy.clone(), pos_p1: pos_pm.clone(), id_p2: id_pn.clone(), placed_p3: placed_po.clone(), acc_p4: acc_pp.clone() }))
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::model::Pos, crate::prelude::Nat, crate::lower::model::OutTy, crate::prelude::Text)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::model::Pa, crate::prelude::Array<crate::lower::model::Do>)>>>
        }), move |each_88185: crate::prelude::Array<(crate::lower::model::Pa, crate::prelude::Array<crate::lower::model::Do>)>| {
            let answers_p5 = each_88185;
            crate::prelude::call_value(crate::prelude::each_job(crate::prelude::filter(&wx_p3.dyn_places_p, &(|(pos_pq, _, _, _): &(crate::lower::model::Pos, crate::prelude::Text, crate::lower::model::OutTy, crate::prelude::Text)| (&in_scope_f4)(pos_pq))), {
                let sk_p0xx = sk_p0x.clone();
                ::std::rc::Rc::new(move |p0: (crate::lower::model::Pos, crate::prelude::Text, crate::lower::model::OutTy, crate::prelude::Text)| {
                    let sk_p0xxy = sk_p0xx.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let (pos_pr, f_ps, placed_pt, acc_pu) = p0;
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(TypedDynArm { sk_p0: sk_p0xxy.clone(), pos_p1: pos_pr.clone(), f_p2: f_ps.clone(), placed_p3: placed_pt.clone(), acc_p4: acc_pu.clone() }))
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::model::Pos, crate::prelude::Text, crate::lower::model::OutTy, crate::prelude::Text)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::model::Pa, crate::prelude::Array<crate::lower::model::Do>)>>>
            }), move |each_88342: crate::prelude::Array<(crate::lower::model::Pa, crate::prelude::Array<crate::lower::model::Do>)>| {
                let dyns_p6 = each_88342;
                crate::prelude::call_value(crate::prelude::each_job(crate::prelude::filter(&wx_p3.bundles_p, &(|bp_pv: &crate::lower::node_::BundlePlace| (&in_scope_f4)(&bp_pv.pos_p) && ((&crate::prelude::len(&bp_pv.events_p) > &crate::prelude::Nat::from(0u32)) || (&bp_pv.stem_p != &crate::prelude::Text::lit(""))))), {
                    let sk_p0xx = sk_p0x.clone();
                    ::std::rc::Rc::new(move |p0: crate::lower::node_::BundlePlace| {
                        let sk_p0xxy = sk_p0xx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let bp_p10 = p0;
                            ::prism_rtl::Turn::More(::std::rc::Rc::new(BundleTypedArm { sk_p0: sk_p0xxy.clone(), bp_p1: bp_p10.clone() }))
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::node_::BundlePlace) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::model::Pa, crate::prelude::Array<crate::lower::model::Do>)>>>
                }), move |each_88583: crate::prelude::Array<(crate::lower::model::Pa, crate::prelude::Array<crate::lower::model::Do>)>| {
                    let bundles_p7 = each_88583;
                    let rows_p8 = crate::prelude::each(&crate::prelude::filter(&wx_p3.builders_p, &(|b_p11: &crate::lower::model::ForDef| (&in_scope_f4)(&b_p11.pos_p))), &(|b_p12: &crate::lower::model::ForDef| typed_forward_arm_f(b_p12, &segs_pk)));
                    let gens_p9 = crate::prelude::fold(&crate::prelude::filter(&wx_p3.gens_p, &(|gd_p13: &crate::lower::model::GenDef| (&in_scope_f4)(&gd_p13.pos_p))), &crate::prelude::Array::new(), &(|acc_p14: &crate::prelude::Array<(crate::lower::model::Pa, crate::prelude::Array<crate::lower::model::Do>)>, gd_p15: &crate::lower::model::GenDef| crate::prelude::append(acc_p14, &typed_gen_arms_f(gd_p15, &segs_pk))));
                    let none_pa = (crate::lower::model::Pa::PaWild, crate::prelude::Array::from(vec![crate::lower::model::Do::DoReturn(crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Err")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Fault::answer")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XFormatStr(crate::prelude::Array::from(vec![crate::lower::model::Ex::XText(crate::prelude::Text::lit("no hosted place at ")), crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Path")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XMethod(::std::rc::Rc::new(segs_pk.clone()), crate::prelude::Text::lit("to_vec"), crate::prelude::Array::new())])), crate::lower::model::Ex::XText(crate::prelude::Text::lit(" to answer"))]))]))])))]));
                    let wide_pb = crate::prelude::filter(&wx_p3.gens_p, &(|gd_p16: &crate::lower::model::GenDef| (&in_scope_f4)(&gd_p16.pos_p) && crate::lower::node_::switch_::is_wide_gen_f(gd_p16)));
                    let (_, none_dos_p17) = none_pa.clone();
                    let last_pc = if &crate::prelude::len(&wide_pb) == &crate::prelude::Nat::from(0u32) {
                        crate::prelude::Array::from(vec![none_pa.clone()])
                    } else {
                        crate::lower::node_::switch_::typed_wide_forward_f(&wide_pb, &segs_pk, &none_dos_p17)
                    };
                    let arms_pd = crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&answers_p5, &dyns_p6), &bundles_p7), &rows_p8), &gens_p9), &last_pc);
                    ::prism_rtl::Turn::Finished(crate::lower::model::MethDef { name_p: name_p1x.clone(), recv_p: recv_pf.clone(), params_p: crate::prelude::Array::from(vec![param_pg.clone(), (crate::prelude::Text::lit("v"), crate::lower::model::OutTy::OutRef(::std::rc::Rc::new(crate::lower::types::answer_ty_p())))]), cx_p: crate::lower::model::CxArg::CxMut, ret_p: crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Done")), crate::prelude::Array::new()), body_p: crate::prelude::push(&seating_pj, &crate::lower::model::Do::DoMatch(segs_pk.clone(), arms_pd.clone())), tail_p: crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Ok")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XUnit])), doc_p: doc_pi.clone() })
                })
            })
        })
    }
}

/// `Start TypedDispatch, x`: what the function value is when passed to `@Run`.
pub fn start_typed_dispatch_f(sk_p0: Sinks, name_p1: crate::prelude::Text, scope_p2: crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::MethDef>> {
    ::std::rc::Rc::new(TypedDispatch { sk_p0, name_p1, scope_p2 })
}

/// ```prism
/// let dummyHost
/// ```
pub fn dummy_host_p() -> crate::lower::node_::HostDef {
    crate::lower::node_::HostDef { pos_p: crate::lower::model::pos0_p(), name_p: crate::prelude::Text::lit(""), scope_p: crate::prelude::Nat::from(0u32) }
}

/// ```prism
/// SortNats: fn [Nat] -> [Nat]
/// ```
pub fn sort_nats_f(xs_p0: &crate::prelude::Array<crate::prelude::Nat>) -> crate::prelude::Array<crate::prelude::Nat> {
    crate::prelude::fold(xs_p0, &crate::prelude::Array::new(), &(|acc_p1: &crate::prelude::Array<crate::prelude::Nat>, x_p2: &crate::prelude::Nat| crate::prelude::append(&crate::prelude::push(&crate::prelude::filter(acc_p1, &(|y_p3: &crate::prelude::Nat| y_p3 < x_p2)), x_p2), &crate::prelude::filter(acc_p1, &(|y_p4: &crate::prelude::Nat| !(y_p4 < x_p2))))))
}

/// ```prism
/// AskWake: fn Sinks, Gn -> [Do]
/// ```
pub fn ask_wake_f(sk_p0: &Sinks, g_p1: &crate::lower::node_::Gn) -> crate::prelude::Array<crate::lower::model::Do> {
    crate::prelude::Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::lit("heights"))), crate::prelude::Text::lit("ask"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XIndex(combinator_of_f(&sk_p0.combs_p, g_p1)), crate::lower::model::Ex::XCx, crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XSelf))])))])
}

/// ```prism
/// HeardAbove: fn Text -> Ex
/// ```
pub fn heard_above_f(m_p0: &crate::prelude::Text) -> crate::lower::model::Ex {
    crate::lower::model::Ex::XClosure(false, crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("n")), crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("h"))]), ::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("n"))), crate::prelude::Text::from(format!("{}_above", m_p0)), crate::prelude::Array::from(vec![crate::lower::model::Ex::XVar(crate::prelude::Text::lit("h"))]))))
}

/// ```prism
/// CombinatorOf: fn [Gn], Gn -> Nat
/// ```
pub fn combinator_of_f(combs_p0: &crate::prelude::Array<crate::lower::node_::Gn>, g_p1: &crate::lower::node_::Gn) -> crate::prelude::Nat {
    let (before_p5, _) = crate::prelude::fold(combs_p0, &(crate::prelude::Nat::from(0u32), false), &(|(n_p2, found_p3): &(crate::prelude::Nat, bool), c_p4: &crate::lower::node_::Gn| if *found_p3 || (&c_p4.id_p == &g_p1.id_p) {
        (n_p2.clone(), true)
    } else {
        (n_p2 + &crate::prelude::Nat::from(1u32), false)
    }));
    before_p5.clone()
}

/// ```prism
/// MergeListIn: fn Sinks, Gn -> MethDef
/// ```
pub fn merge_list_in_f(sk_p0: &Sinks, g_p1: &crate::lower::node_::Gn) -> crate::lower::model::MethDef {
    crate::lower::model::MethDef { name_p: crate::prelude::Text::from(format!("{}_in", &g_p1.name_p)), recv_p: crate::lower::model::Recv::RecvRc, params_p: crate::prelude::Array::new(), cx_p: crate::lower::model::CxArg::CxMut, ret_p: crate::lower::model::OutTy::OutUnit, body_p: ask_wake_f(sk_p0, g_p1), tail_p: crate::lower::model::Ex::XUnit, doc_p: crate::prelude::Text::lit("An event of the `!MergeAll` list fired: the wake decides the tick\'s one firing.") }
}

/// ```prism
/// GatherIn: fn Sinks, Gn -> MethDef
/// ```
pub fn gather_in_f(sk_p0: &Sinks, g_p1: &crate::lower::node_::Gn) -> crate::lower::model::MethDef {
    let field_p2 = crate::prelude::or(&crate::prelude::index(&g_p1.inputs_p, &crate::prelude::Nat::from(0u32)), &crate::prelude::Text::lit(""));
    let kt_p3 = match &g_p1.ty_p {
        crate::lower::model::OutTy::OutMap(k_p8, _) => (**k_p8).clone(),
        _ => crate::lower::model::OutTy::OutUnit,
    };
    let vt_p4 = match &g_p1.ty_p {
        crate::lower::model::OutTy::OutMap(_, v_p9) => (**v_p9).clone(),
        _ => crate::lower::model::OutTy::OutUnit,
    };
    let current_p5 = crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::from(format!("{}", &field_p2)))), crate::prelude::Text::lit("get"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx]))), crate::prelude::Text::lit("unwrap_or_default"), crate::prelude::Array::new());
    let collect_p6 = crate::prelude::Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaMut(crate::prelude::Text::lit("all")), current_p5.clone()), crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("all"))), crate::prelude::Text::lit("insert"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XVar(crate::prelude::Text::lit("k")), crate::lower::model::Ex::XVar(crate::prelude::Text::lit("v"))]))), crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::from(format!("{}", &field_p2)))), crate::prelude::Text::lit("set"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XVar(crate::prelude::Text::lit("all")), crate::lower::model::Ex::XCx])))]);
    let body_p7 = crate::prelude::append(&collect_p6, &ask_wake_f(sk_p0, g_p1));
    crate::lower::model::MethDef { name_p: crate::prelude::Text::from(format!("{}_in", &g_p1.name_p)), recv_p: crate::lower::model::Recv::RecvRc, params_p: crate::prelude::Array::from(vec![(crate::prelude::Text::lit("k"), kt_p3.clone()), (crate::prelude::Text::lit("v"), vt_p4.clone())]), cx_p: crate::lower::model::CxArg::CxMut, ret_p: crate::lower::model::OutTy::OutUnit, body_p: body_p7.clone(), tail_p: crate::lower::model::Ex::XUnit, doc_p: crate::prelude::Text::lit("A row\'s firing, gathered by its key.") }
}

/// ```prism
/// Decide: fn Gn -> Do
/// ```
pub fn decide_f(g_p0: &crate::lower::node_::Gn) -> crate::lower::model::Do {
    match &g_p0.kind_p {
        crate::lower::node_::GnKind::GnGather => crate::lower::model::Do::DoIfLet(crate::lower::model::Pa::PaCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Some")), crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("v"))])), crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::from(format!("{}", &crate::prelude::or(&crate::prelude::index(&g_p0.inputs_p, &crate::prelude::Nat::from(0u32)), &crate::prelude::Text::lit("")))))), crate::prelude::Text::lit("take"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx])), crate::prelude::Array::from(vec![self_call_f(&g_p0.name_p, &crate::prelude::Array::from(vec![crate::lower::model::Ex::XVar(crate::prelude::Text::lit("v"))]))]), crate::prelude::Array::new()),
        crate::lower::node_::GnKind::GnMergeList => crate::lower::model::Do::DoIfLet(crate::lower::model::Pa::PaCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Some")), crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("v"))])), crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::from(format!("{}", &crate::prelude::or(&crate::prelude::index(&g_p0.inputs_p, &crate::prelude::Nat::from(0u32)), &crate::prelude::Text::lit("")))))), crate::prelude::Text::lit("take"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx])), crate::prelude::Array::from(vec![self_call_f(&g_p0.name_p, &crate::prelude::Array::from(vec![crate::lower::model::Ex::XVar(crate::prelude::Text::lit("v"))]))]), crate::prelude::Array::new()),
        crate::lower::node_::GnKind::GnMerge => merge_decide_f(g_p0),
        crate::lower::node_::GnKind::GnUpdated => updated_decide_f(g_p0),
        crate::lower::node_::GnKind::GnMergeAll => {
            let pushes_p1 = crate::prelude::each(&g_p0.inputs_p, &(|f_p4: &crate::prelude::Text| crate::lower::model::Do::DoIfLet(crate::lower::model::Pa::PaCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Some")), crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("x"))])), crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::from(format!("{}", f_p4)))), crate::prelude::Text::lit("take"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx])), crate::prelude::Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("all"))), crate::prelude::Text::lit("push_back"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XVar(crate::prelude::Text::lit("x"))])))]), crate::prelude::Array::new())));
            let start_p2 = crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaMut(crate::prelude::Text::lit("all"))), g_p0.ty_p.clone()), crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Array::new")), crate::prelude::Array::new()));
            let fire_p3 = crate::lower::model::Do::DoIf(crate::lower::model::Ex::XUnary(crate::lower::model::UnOp::OpNot, ::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("all"))), crate::prelude::Text::lit("is_empty"), crate::prelude::Array::new()))), crate::prelude::Array::from(vec![self_call_f(&g_p0.name_p, &crate::prelude::Array::from(vec![crate::lower::model::Ex::XVar(crate::prelude::Text::lit("all"))]))]), crate::prelude::Array::new());
            crate::lower::model::Do::DoBlock(crate::prelude::push(&crate::prelude::append(&crate::prelude::Array::from(vec![start_p2.clone()]), &pushes_p1), &fire_p3))
        },
        kind_p5 => pair_decide_f(g_p0, kind_p5),
    }
}

/// ```prism
/// UpdatedDecide: fn Gn -> Do
/// ```
pub fn updated_decide_f(g_p0: &crate::lower::node_::Gn) -> crate::lower::model::Do {
    crate::lower::model::Do::DoIf(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::from(format!("{}_moved", &g_p0.name_p)))), crate::prelude::Text::lit("replace"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XBool(false)])), crate::prelude::Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("after")), crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XCx), crate::prelude::Text::lit("after"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XClosure(false, crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("cx"))]), ::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::from(format!("{}_value", &g_p0.name_p)), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx]))))]))), self_call_f(&g_p0.name_p, &crate::prelude::Array::from(vec![crate::lower::model::Ex::XVar(crate::prelude::Text::lit("after"))]))]), crate::prelude::Array::new())
}

/// ```prism
/// PairDecide: fn Gn, GnKind -> Do
/// ```
pub fn pair_decide_f(g_p0: &crate::lower::node_::Gn, kind_p1: &crate::lower::node_::GnKind) -> crate::lower::model::Do {
    let get_l_p2 = crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::from(format!("{}", &crate::prelude::or(&crate::prelude::index(&g_p0.inputs_p, &crate::prelude::Nat::from(0u32)), &crate::prelude::Text::lit("")))))), crate::prelude::Text::lit("take"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx]));
    let get_r_p3 = crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::from(format!("{}", &crate::prelude::or(&crate::prelude::index(&g_p0.inputs_p, &crate::prelude::Nat::from(1u32)), &crate::prelude::Text::lit("")))))), crate::prelude::Text::lit("take"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx]));
    let both_p4 = crate::lower::model::Ex::XTuple(crate::prelude::Array::from(vec![get_l_p2.clone(), get_r_p3.clone()]));
    let fire_f5 = {
        let g_p0x = g_p0.clone();
        ::std::rc::Rc::new(move |x_pc: &crate::lower::model::Ex| crate::prelude::Array::from(vec![self_call_f(&g_p0x.name_p, &crate::prelude::Array::from(vec![x_pc.clone()]))])) as ::std::rc::Rc<dyn ::std::ops::Fn(&crate::lower::model::Ex) -> crate::prelude::Array<crate::lower::model::Do>>
    };
    let sa_p6 = crate::lower::model::Pa::PaCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Some")), crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("a"))]));
    let sb_p7 = crate::lower::model::Pa::PaCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Some")), crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("b"))]));
    let some2_p8 = crate::lower::model::Pa::PaTuple(crate::prelude::Array::from(vec![sa_p6.clone(), sb_p7.clone()]));
    let left_p9 = crate::lower::model::Pa::PaTuple(crate::prelude::Array::from(vec![sa_p6.clone(), crate::lower::model::Pa::PaUnit(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::None")))]));
    let right_pa = crate::lower::model::Pa::PaTuple(crate::prelude::Array::from(vec![crate::lower::model::Pa::PaUnit(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::None"))), sb_p7.clone()]));
    let cases_pb = match kind_p1 {
        crate::lower::node_::GnKind::GnUnion => crate::prelude::Array::from(vec![(some2_p8.clone(), (&fire_f5)(&crate::lower::model::Ex::XCall(crate::lower::helper_ref_f(&crate::prelude::Text::lit("union")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("a")))), crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("b"))))])))), (left_p9.clone(), (&fire_f5)(&crate::lower::model::Ex::XVar(crate::prelude::Text::lit("a")))), (right_pa.clone(), (&fire_f5)(&crate::lower::model::Ex::XVar(crate::prelude::Text::lit("b")))), (crate::lower::model::Pa::PaWild, crate::prelude::Array::new())]),
        crate::lower::node_::GnKind::GnBoth => crate::prelude::Array::from(vec![(some2_p8.clone(), (&fire_f5)(&crate::lower::model::Ex::XTuple(crate::prelude::Array::from(vec![crate::lower::model::Ex::XVar(crate::prelude::Text::lit("a")), crate::lower::model::Ex::XVar(crate::prelude::Text::lit("b"))])))), (crate::lower::model::Pa::PaWild, crate::prelude::Array::new())]),
        _ => crate::prelude::Array::from(vec![(left_p9.clone(), (&fire_f5)(&crate::lower::model::Ex::XVar(crate::prelude::Text::lit("a")))), (crate::lower::model::Pa::PaWild, crate::prelude::Array::new())]),
    };
    crate::lower::model::Do::DoMatch(both_p4.clone(), cases_pb.clone())
}

/// ```prism
/// WakeByHeight: fn [Gn] -> Do
/// ```
pub fn wake_by_height_f(combs_p0: &crate::prelude::Array<crate::lower::node_::Gn>) -> crate::lower::model::Do {
    crate::lower::model::Do::DoWhileLet(crate::lower::model::Pa::PaCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Some")), crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("combinator"))])), crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::lit("heights"))), crate::prelude::Text::lit("next"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx])), crate::prelude::Array::from(vec![crate::lower::model::Do::DoMatch(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("combinator")), crate::prelude::push(&crate::prelude::each(combs_p0, &(|g_p1: &crate::lower::node_::Gn| (crate::lower::model::Pa::PaIndex(combinator_of_f(combs_p0, g_p1)), crate::prelude::Array::from(vec![decide_f(g_p1)])))), &(crate::lower::model::Pa::PaWild, crate::prelude::Array::new())))]))
}

/// ```prism
/// ForwardAnswer: fn ForDef -> Ex
/// ```
pub fn forward_answer_f(b_p0: &crate::lower::model::ForDef) -> crate::lower::model::Ex {
    let row_of_p1 = crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::from(format!("{}", &b_p0.name_p)))), crate::prelude::Text::lit("borrow"), crate::prelude::Array::new())), crate::prelude::Text::lit("get"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XDecode(b_p0.key_ty_p.clone(), ::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("k"))))))]))), crate::prelude::Text::lit("cloned"), crate::prelude::Array::new());
    crate::lower::model::Ex::XBlock(crate::prelude::Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("row")), row_of_p1.clone()), crate::lower::model::Do::DoIfLet(crate::lower::model::Pa::PaCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Some")), crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("row"))])), crate::lower::model::Ex::XVar(crate::prelude::Text::lit("row")), crate::prelude::Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::expr::try_of_f(&crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("row"))), crate::prelude::Text::lit("answer"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XVar(crate::prelude::Text::lit("rest")), crate::lower::model::Ex::XVar(crate::prelude::Text::lit("v")), crate::lower::model::Ex::XCx]))))]), crate::prelude::Array::new())]), ::std::rc::Rc::new(crate::lower::model::Ex::XUnit))
}

/// ```prism
/// IsHold: fn OutTy -> Bool
/// ```
pub fn is_hold_f(out_ty0: &crate::lower::model::OutTy) -> bool {
    match out_ty0 {
        crate::lower::model::OutTy::OutHold(_) => true,
        crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefRuntime(c1_0_0_0), _) if (c1_0_0_0 == &crate::prelude::Text::lit("prism_rtl::PerKey")) => true,
        other_p0 => false,
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// RowMethods: fn Wx -> [MethDef]
/// ```
pub fn row_methods_f(wx_p0: &crate::lower::node_::Wx) -> crate::prelude::Array<crate::lower::model::MethDef> {
    let removes_p1 = crate::prelude::fold(&crate::prelude::filter(&wx_p0.places_p, &(|p_p4: &crate::lower::node_::Place| emits_f(wx_p0, &p_p4.pos_p))), &crate::prelude::Array::new(), &(|acc_p5: &crate::prelude::Array<crate::lower::model::Do>, p_p6: &crate::lower::node_::Place| crate::prelude::append(acc_p5, &crate::prelude::append(&crate::prelude::Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XCx), crate::prelude::Text::lit("removed"), crate::prelude::Array::from(vec![place_at_f(wx_p0, &crate::prelude::Text::lit("self"), &p_p6.pos_p)])))]), &(if &p_p6.watch_p == &crate::prelude::Text::lit("") {
        crate::prelude::Array::new()
    } else {
        crate::prelude::Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), p_p6.watch_p.clone())), crate::prelude::Text::lit("drop_all"), crate::prelude::Array::new()))])
    })))));
    let nested_p2 = crate::prelude::append(&crate::prelude::each(&wx_p0.builders_p, &(|b_p7: &crate::lower::model::ForDef| crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), b_p7.name_p.clone())), crate::prelude::Text::lit("borrow"), crate::prelude::Array::new())), crate::prelude::Text::lit("values"), crate::prelude::Array::new())), crate::prelude::Text::lit("for_each"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XClosure(false, crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("row"))]), ::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("row"))), crate::prelude::Text::lit("leave_row"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx]))))]))))), &crate::prelude::each(&wx_p0.gens_p, &(|gd_p8: &crate::lower::model::GenDef| crate::lower::model::Do::DoIfLet(crate::lower::model::Pa::PaCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Some")), crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("row"))])), crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), gd_p8.name_p.clone())), crate::prelude::Text::lit("borrow"), crate::prelude::Array::new())), crate::prelude::Text::lit("as_ref"), crate::prelude::Array::new()), crate::prelude::Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("row"))), crate::prelude::Text::lit("leave_row"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx])))]), crate::prelude::Array::new()))));
    let left_p3 = if &wx_p0.gen_of_p == &crate::prelude::Text::lit("") {
        crate::prelude::Array::new()
    } else {
        crate::prelude::Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::lit("left"))), crate::prelude::Text::lit("set"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XBool(true)])))])
    };
    crate::prelude::Array::from(vec![crate::lower::model::MethDef { name_p: crate::prelude::Text::lit("remove_places"), recv_p: crate::lower::model::Recv::RecvRef, params_p: crate::prelude::Array::new(), cx_p: crate::lower::model::CxArg::CxMut, ret_p: crate::lower::model::OutTy::OutUnit, body_p: crate::prelude::append(&crate::prelude::append(&left_p3, &removes_p1), &nested_p2), tail_p: crate::lower::model::Ex::XUnit, doc_p: crate::prelude::Text::lit("The row left: its places are torn down.") }])
}

/// ```prism
/// GnDoc: fn Gn -> Text
/// ```
pub fn gn_doc_f(g_p0: &crate::lower::node_::Gn) -> crate::prelude::Text {
    match &g_p0.kind_p {
        crate::lower::node_::GnKind::GnAnswer => crate::prelude::Text::from(format!("`{}`: an answer at its place.", &g_p0.name_p)),
        crate::lower::node_::GnKind::GnStarted => crate::prelude::Text::lit("`@started`, the tick after the build."),
        crate::lower::node_::GnKind::GnDeferred => crate::prelude::Text::lit("An `@Defer` firing, the tick after it was armed."),
        crate::lower::node_::GnKind::GnMerge => crate::prelude::Text::from(format!("The merge `{}`, decided in the wake.", &g_p0.name_p)),
        crate::lower::node_::GnKind::GnUpdated => crate::prelude::Text::lit("`!Updated`: the dynamic\'s value after the tick, fired in the wake when a hold it reads was written (or a structural dynamic it reads was published, pick ST)."),
        _ => crate::prelude::Text::from(format!("`!{}`.", &g_p0.name_p)),
    }
}

/// ```prism
/// MergeDecide: fn Gn -> Do
/// ```
pub fn merge_decide_f(g_p0: &crate::lower::node_::Gn) -> crate::lower::model::Do {
    let call_p1 = crate::prelude::Array::from(vec![self_call_f(&g_p0.name_p, &crate::prelude::Array::from(vec![crate::lower::model::Ex::XVar(crate::prelude::Text::lit("v"))]))]);
    let take_l_p2 = crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("left")), crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::from(format!("{}", &crate::prelude::or(&crate::prelude::index(&g_p0.inputs_p, &crate::prelude::Nat::from(0u32)), &crate::prelude::Text::lit("")))))), crate::prelude::Text::lit("take"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx])));
    let take_r_p3 = crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("right")), crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::from(format!("{}", &crate::prelude::or(&crate::prelude::index(&g_p0.inputs_p, &crate::prelude::Nat::from(1u32)), &crate::prelude::Text::lit("")))))), crate::prelude::Text::lit("take"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx])));
    let right_p4 = crate::lower::model::Do::DoIfLet(crate::lower::model::Pa::PaCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Some")), crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("v"))])), crate::lower::model::Ex::XVar(crate::prelude::Text::lit("right")), call_p1.clone(), crate::prelude::Array::new());
    crate::lower::model::Do::DoBlock(crate::prelude::Array::from(vec![take_l_p2.clone(), take_r_p3.clone(), crate::lower::model::Do::DoIfLet(crate::lower::model::Pa::PaCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Some")), crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("v"))])), crate::lower::model::Ex::XVar(crate::prelude::Text::lit("left")), call_p1.clone(), crate::prelude::Array::from(vec![right_p4.clone()]))]))
}
