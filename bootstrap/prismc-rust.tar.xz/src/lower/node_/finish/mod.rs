//! The module `Lower.Node.Finish`, from `target/bootstrap/src/prismc/lower/node/finish.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// `Sinks`:
///
/// ```prism
/// type Sinks = record:
/// ```
#[derive(Clone)]
pub struct Sinks {
    pub wx: crate::lower::node_::Wx,
    pub dirty: Array<crate::lower::node_::Read>,
    pub builds: Array<crate::lower::node_::Read>,
    pub heights: Array<Nat>,
    pub many: bool,
}

/// ```prism
/// Heights: fn [Gn] -> [Gn]
/// ```
pub fn heights(gns_p0: &Array<crate::lower::node_::Gn>) -> Array<crate::lower::node_::Gn> {
    fold(gns_p0, gns_p0, &(|cur_p1: &Array<crate::lower::node_::Gn>, _: &crate::lower::node_::Gn| each(cur_p1, &(|n_p2: &crate::lower::node_::Gn| height_step(cur_p1, n_p2)))))
}

/// ```prism
/// HeightStep: fn [Gn], Gn -> Gn
/// ```
pub fn height_step(gns_p0: &Array<crate::lower::node_::Gn>, n_p1: &crate::lower::node_::Gn) -> crate::lower::node_::Gn {
    let feeders_p2 = filter(gns_p0, &(|m_p5: &crate::lower::node_::Gn| fold(&m_p5.outs, &false, &(|f_p6: &bool, o_p7: &crate::lower::node_::Out| *f_p6 || feeds(&o_p7.sink, n_p1)))));
    let top_p3 = fold(&feeders_p2, &Nat::from(0u32), &(|hi_p8: &Nat, m_p9: &crate::lower::node_::Gn| max(hi_p8, &m_p9.height)));
    let h_p4 = match &n_p1.kind {
        crate::lower::node_::GnKind::GnNamed => top_p3.clone(),
        kind_pa => if is_comb(kind_pa) {
            max(&(&top_p3 + &Nat::from(1u32)), &n_p1.floor)
        } else {
            n_p1.height.clone()
        },
    };
    let mut this: crate::lower::node_::Gn = n_p1.clone();
    this.height = h_p4.clone();
    this
}

/// ```prism
/// IsComb: fn GnKind -> Bool
/// ```
pub fn is_comb(k_p0: &crate::lower::node_::GnKind) -> bool {
    match k_p0 {
        crate::lower::node_::GnKind::GnMerge => true,
        crate::lower::node_::GnKind::GnUnion => true,
        crate::lower::node_::GnKind::GnBoth => true,
        crate::lower::node_::GnKind::GnExcept => true,
        crate::lower::node_::GnKind::GnMergeAll => true,
        crate::lower::node_::GnKind::GnUpdated => true,
        _ => false,
    }
}

/// ```prism
/// Feeds: fn Sk, Gn -> Bool
/// ```
pub fn feeds(sk0: &crate::lower::node_::Sk, n_p1: &crate::lower::node_::Gn) -> bool {
    match sk0 {
        crate::lower::node_::Sk::SkNode(m_p0) => m_p0 == &n_p1.id,
        crate::lower::node_::Sk::SkIn(m_p2, _) => m_p2 == &n_p1.id,
        crate::lower::node_::Sk::SkCycle(_, _, m_p4) => m_p4 == &n_p1.id,
        crate::lower::node_::Sk::SkMachine(f_p6, _, m_p7) => (m_p7 == &n_p1.id) || writes(f_p6, n_p1),
        crate::lower::node_::Sk::SkHold(f_p9) => writes(f_p9, n_p1),
        crate::lower::node_::Sk::SkDistinct(f_pb) => writes(f_pb, n_p1),
        crate::lower::node_::Sk::SkPerKey(f_pd) => writes(f_pd, n_p1),
        other_pf => false,
    }
}

/// ```prism
/// Writes: fn Text, Gn -> Bool
/// ```
pub fn writes(f_p0: &Text, n_p1: &crate::lower::node_::Gn) -> bool {
    moves(&crate::lower::node_::Read::OwnRead(f_p0.clone()), n_p1)
}

/// ```prism
/// Moves: fn Read, Gn -> Bool
/// ```
pub fn moves(r_p0: &crate::lower::node_::Read, n_p1: &crate::lower::node_::Gn) -> bool {
    (&n_p1.kind == &crate::lower::node_::GnKind::GnUpdated) && crate::lower::node_::has_read(&n_p1.reads, r_p0)
}

/// ```prism
/// ReadsClosed: fn (Text ==> [Read]), [Read] -> [Read]
/// ```
pub fn reads_closed(dyn_p0: &Map<Text, Array<crate::lower::node_::Read>>, reads_p1: &Array<crate::lower::node_::Read>) -> Array<crate::lower::node_::Read> {
    fold(&crate::check::errors::range0(&Nat::from(4u32)), reads_p1, &(|acc_p2: &Array<crate::lower::node_::Read>, _: &Nat| fold(acc_p2, acc_p2, &(|a_p3: &Array<crate::lower::node_::Read>, r_p4: &crate::lower::node_::Read| crate::lower::node_::union_reads(a_p3, &getter_reads(dyn_p0, r_p4))))))
}

/// ```prism
/// GetterReads: fn (Text ==> [Read]), Read -> [Read]
/// ```
pub fn getter_reads(dyn_p0: &Map<Text, Array<crate::lower::node_::Read>>, read1: &crate::lower::node_::Read) -> Array<crate::lower::node_::Read> {
    match read1 {
        crate::lower::node_::Read::OwnRead(n_p1) => or(&get(dyn_p0, n_p1), &Array::new()),
        crate::lower::node_::Read::ParentRead(_) => Array::new(),
    }
}

/// ```prism
/// ReachesSnap: fn [Text], [Read] -> Bool
/// ```
pub fn reaches_snap(roots_p0: &Array<Text>, reads_p1: &Array<crate::lower::node_::Read>) -> bool {
    fold(reads_p1, &false, &(|f_p2: &bool, r_p3: &crate::lower::node_::Read| *f_p2 || match r_p3 {
        crate::lower::node_::Read::OwnRead(n_p4) => crate::check::types::has_text(roots_p0, n_p4),
        crate::lower::node_::Read::ParentRead(_) => false,
    }))
}

/// ```prism
/// SnapNames: fn Wx -> [Text]
/// ```
pub fn snap_names(wx_p0: &crate::lower::node_::Wx) -> Array<Text> {
    each(&wx_p0.snaps, &(|sn_p1: &crate::lower::node_::SnapDef| sn_p1.name.clone()))
}

/// ```prism
/// WakeConst: fn [Nat], Nat -> Text
/// ```
pub fn wake_const(heights_p0: &Array<Nat>, h_p1: &Nat) -> Text {
    if &len(heights_p0) <= &Nat::from(1u32) {
        Text::lit("WAKE")
    } else {
        Text::from(format!("WAKE_{}", h_p1))
    }
}

/// ```prism
/// SelfCall: fn Text, [Ex] -> Do
/// ```
pub fn self_call(m_p0: &Text, args_p1: &Array<crate::lower::model::Ex>) -> crate::lower::model::Do {
    crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XSelf), m_p0.clone(), push(args_p1, &crate::lower::model::Ex::XCx)))
}

/// ```prism
/// SinkCode: fn Sinks, Sk, Ex -> [Do]
/// ```
pub fn sink_code(sk_p0: &Sinks, target_p1: &crate::lower::node_::Sk, y_p2: &crate::lower::model::Ex) -> Array<crate::lower::model::Do> {
    match target_p1 {
        crate::lower::node_::Sk::SkNode(m_p3) => Array::from(vec![self_call(&crate::lower::node_::gn_of(&sk_p0.wx, m_p3).name, &Array::from(vec![y_p2.clone()]))]),
        crate::lower::node_::Sk::SkIn(m_p4, i_p5) => {
            let g_p6 = crate::lower::node_::gn_of(&sk_p0.wx, m_p4);
            append(&Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", &or(&index(&g_p6.inputs, i_p5), &Text::lit("")))))), Text::lit("set"), Array::from(vec![y_p2.clone(), crate::lower::model::Ex::XCx])))]), &ask_wake(sk_p0, &g_p6.height))
        },
        crate::lower::node_::Sk::SkHold(f_p7) => append(&Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", f_p7)))), Text::lit("set"), Array::from(vec![y_p2.clone(), crate::lower::model::Ex::XCx])))]), &hold_written(sk_p0, f_p7)),
        crate::lower::node_::Sk::SkDistinct(f_p8) => {
            let differs_p9 = crate::lower::model::Ex::XBin(Text::lit("!="), Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", f_p8)))), Text::lit("get"), Array::from(vec![crate::lower::model::Ex::XCx]))), Rc::new(crate::lower::model::Ex::XCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Ex::XClone(Rc::new(y_p2.clone()))]))));
            let write_pa = crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", f_p8)))), Text::lit("set"), Array::from(vec![crate::lower::model::Ex::XCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Ex::XClone(Rc::new(y_p2.clone()))])), crate::lower::model::Ex::XCx])));
            Array::from(vec![crate::lower::model::Do::DoIf(differs_p9.clone(), append(&Array::from(vec![write_pa.clone()]), &hold_written(sk_p0, f_p8)), Array::new())])
        },
        crate::lower::node_::Sk::SkPerKey(f_pb) => Array::from(vec![crate::lower::model::Do::DoIf(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", f_pb)))), Text::lit("written"), Array::from(vec![crate::lower::model::Ex::XClone(Rc::new(y_p2.clone())), crate::lower::model::Ex::XCx])), hold_written(sk_p0, f_pb), Array::new())]),
        crate::lower::node_::Sk::SkRequest(pos_pc, field_pd) => {
            let field_ex_pe = if field_pd == &Text::lit("") {
                crate::lower::model::Ex::XNone
            } else {
                crate::lower::model::Ex::XCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Ex::XStr(field_pd.clone())]))
            };
            if emits(&sk_p0.wx, pos_pc) {
                Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCx), Text::lit("request"), Array::from(vec![place_at(&sk_p0.wx, &Text::lit("self"), pos_pc), field_ex_pe.clone(), crate::lower::model::Ex::XMethod(Rc::new(y_p2.clone()), Text::lit("to_pod"), Array::new())])))])
            } else {
                Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(Text::lit("requested")), crate::lower::model::Ex::XMethod(Rc::new(host_field_ex(&sk_p0.wx, pos_pc)), Text::lit("request"), Array::from(vec![crate::lower::model::Ex::XRef(Rc::new(place_at(&sk_p0.wx, &Text::lit("self"), pos_pc))), field_ex_pe.clone(), crate::lower::model::Ex::XMethod(Rc::new(y_p2.clone()), Text::lit("to_pod"), Array::new()), crate::lower::model::Ex::XCx]))), crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCx), Text::lit("keep"), Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("requested"))])))])
            }
        },
        crate::lower::node_::Sk::SkResult => Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCx), Text::lit("result"), Array::from(vec![crate::lower::model::Ex::XCtor(Text::lit("Outcome::Fired"), Array::from(vec![crate::lower::model::Ex::XMethod(Rc::new(y_p2.clone()), Text::lit("to_pod"), Array::new())]))])))]),
        crate::lower::node_::Sk::SkArm(f_pf) => Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", f_pf)))), Text::lit("arm"), Array::from(vec![y_p2.clone(), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XSelf)), crate::lower::model::Ex::XCx])))]),
        crate::lower::node_::Sk::SkMachine(f_pg, step_ph, out_pi) => {
            let stepped_pj = crate::lower::model::Ex::XCall(step_ph.clone(), Array::from(vec![crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), f_pg.clone())), Text::lit("get"), Array::from(vec![crate::lower::model::Ex::XCx])))), crate::lower::model::Ex::XRef(Rc::new(y_p2.clone()))]));
            append(&Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTuple(Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("machine_s")), crate::lower::model::Pa::PaBind(Text::lit("machine_b"))])), stepped_pj.clone()), crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", f_pg)))), Text::lit("set"), Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("machine_s")), crate::lower::model::Ex::XCx]))), crate::lower::model::Do::DoIfLet(crate::lower::model::Pa::PaCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("machine_b"))])), crate::lower::model::Ex::XVar(Text::lit("machine_b")), Array::from(vec![self_call(&crate::lower::node_::gn_of(&sk_p0.wx, out_pi).name, &Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("machine_b"))]))]), Array::new())]), &moved_marks(sk_p0, f_pg))
        },
        crate::lower::node_::Sk::SkPort(f_pk) => Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_port", f_pk)))), Text::lit("fire"), Array::from(vec![y_p2.clone(), crate::lower::model::Ex::XCx]))), Text::lit("ok"), Array::new()))]),
        crate::lower::node_::Sk::SkUp(m_pl) => {
            let keyed_pm = &len(&filter(&sk_p0.wx.fields, &(|(f_po, _, _): &(Text, crate::lower::model::OutTy, Text)| f_po == &Text::lit("key")))) > &Nat::from(0u32);
            let args_pn = if keyed_pm {
                Array::from(vec![crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::lit("key")))), y_p2.clone(), crate::lower::model::Ex::XCx])
            } else {
                Array::from(vec![y_p2.clone(), crate::lower::model::Ex::XCx])
            };
            Array::from(vec![crate::lower::model::Do::DoIfLet(crate::lower::model::Pa::PaCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("parent"))])), crate::lower::model::Ex::XUpgrade(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::lit("parent")))), Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("parent"))), m_pl.clone(), args_pn.clone()))]), Array::new())])
        },
        crate::lower::node_::Sk::SkCycle(job_pp, again_pq, res_pr) => {
            let more_ps = Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", job_pp)))), Text::lit("set"), Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("next")), crate::lower::model::Ex::XCx]))), crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", again_pq)))), Text::lit("arm"), Array::from(vec![crate::lower::model::Ex::XUnit, crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XSelf)), crate::lower::model::Ex::XCx])))]);
            let fin_pt = Array::from(vec![self_call(&crate::lower::node_::gn_of(&sk_p0.wx, res_pr).name, &Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("b"))]))]);
            Array::from(vec![crate::lower::model::Do::DoMatch(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", job_pp)))), Text::lit("get"), Array::from(vec![crate::lower::model::Ex::XCx]))), Text::lit("cycle"), Array::new()), Array::from(vec![(crate::lower::model::Pa::PaCtor(Text::lit("prism_rtl::Turn::More"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("next"))])), more_ps.clone()), (crate::lower::model::Pa::PaCtor(Text::lit("prism_rtl::Turn::Finished"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("b"))])), fin_pt.clone())]))])
        },
    }
}

/// ```prism
/// HoldWritten: fn Sinks, Text -> [Do]
/// ```
pub fn hold_written(sk_p0: &Sinks, f_p1: &Text) -> Array<crate::lower::model::Do> {
    let r_p2 = crate::lower::node_::Read::OwnRead(f_p1.clone());
    let read_by_place_p3 = crate::lower::node_::has_read(&sk_p0.dirty, &r_p2);
    let dirty_p4 = if read_by_place_p3 {
        Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCx), Text::lit("dirty"), Array::from(vec![crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XSelf))])))])
    } else {
        Array::new()
    };
    let told_p5 = Array::new();
    let stales_p6 = fold(&sk_p0.wx.gen_holds, &Array::new(), &(|acc_pb: &Array<crate::lower::model::Do>, (gname_pc, hs_pd): &(Text, Array<crate::lower::node_::Read>)| if crate::lower::node_::has_read(&reads_closed(&sk_p0.wx.dyn_reads, hs_pd), &r_p2) {
        push(acc_pb, &crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_stale", gname_pc)))), Text::lit("set"), Array::from(vec![crate::lower::model::Ex::XBool(true)]))))
    } else {
        acc_pb.clone()
    }));
    let row_marks_p7 = fold(&sk_p0.wx.row_marks, &Array::new(), &(|acc_pe: &Array<crate::lower::model::Do>, rm_pf: &crate::lower::node_::RowMarks| append(acc_pe, &row_written(&sk_p0.wx, rm_pf, &r_p2))));
    let builds_p8 = crate::lower::node_::has_read(&sk_p0.builds, &r_p2) || (&len(&stales_p6) > &Nat::from(0u32));
    let rebuild_it_p9 = if builds_p8 && !lists_build(sk_p0, &r_p2) {
        append(&stales_p6, &Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCx), Text::lit("build_later"), Array::from(vec![crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XSelf))])))]))
    } else {
        stales_p6.clone()
    };
    let gathered_pa = match &sk_p0.wx.result_moved {
        Some((m_pg, rds_ph)) => if crate::lower::node_::has_read(rds_ph, &r_p2) {
            Array::from(vec![crate::lower::model::Do::DoIfLet(crate::lower::model::Pa::PaCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("parent"))])), crate::lower::model::Ex::XUpgrade(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::lit("parent")))), Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("parent"))), m_pg.clone(), Array::from(vec![crate::lower::model::Ex::XCx])))]), Array::new())])
        } else {
            Array::new()
        },
        None => Array::new(),
    };
    append(&append(&append(&append(&append(&dirty_p4, &told_p5), &rebuild_it_p9), &row_marks_p7), &gathered_pa), &moved_marks(sk_p0, f_p1))
}

/// ```prism
/// HostFieldEx: fn Wx, Pos -> Ex
/// ```
pub fn host_field_ex(wx_p0: &crate::lower::node_::Wx, pos_p1: &crate::lower::model::Pos_) -> crate::lower::model::Ex {
    crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), crate::lower::node_::elements::host_local(wx_p0, pos_p1))
}

/// ```prism
/// MovedMarks: fn Sinks, Text -> [Do]
/// ```
pub fn moved_marks(sk_p0: &Sinks, f_p1: &Text) -> Array<crate::lower::model::Do> {
    moved_by(sk_p0, &crate::lower::node_::Read::OwnRead(f_p1.clone()))
}

/// ```prism
/// MovedBy: fn Sinks, Read -> [Do]
/// ```
pub fn moved_by(sk_p0: &Sinks, r_p1: &crate::lower::node_::Read) -> Array<crate::lower::model::Do> {
    let moved_p2 = filter(&sk_p0.wx.gns, &(|g_p9: &crate::lower::node_::Gn| moves(r_p1, g_p9)));
    let flags_p3 = each(&moved_p2, &(|g_pa: &crate::lower::node_::Gn| crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_moved", &g_pa.name)))), Text::lit("set"), Array::from(vec![crate::lower::model::Ex::XBool(true)])))));
    let heights_p4 = sort_nats(&fold(&moved_p2, &Array::new(), &(|acc_pb: &Array<Nat>, g_pc: &crate::lower::node_::Gn| crate::check::types::add_nat(acc_pb, &g_pc.height))));
    let marks_p5 = each(&snaps_behind(&sk_p0.wx, r_p1), &(|sn_pd: &crate::lower::node_::SnapDef| crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_snap", &sn_pd.name)))), Text::lit("mark"), Array::from(vec![crate::lower::model::Ex::XCx])))));
    let listed_p6 = if lists_build(sk_p0, r_p1) {
        Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCx), Text::lit("build_later"), Array::from(vec![crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XSelf))])))])
    } else {
        Array::new()
    };
    let answers_p7 = each(&filter(&sk_p0.wx.dyn_answers, &(|(_, rds_pe): &(Text, Array<crate::lower::node_::Read>)| crate::lower::node_::has_read(&reads_closed(&sk_p0.wx.dyn_reads, rds_pe), r_p1))), &(|(name_pf, _): &(Text, Array<crate::lower::node_::Read>)| crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_port", name_pf)))), Text::lit("fire"), Array::from(vec![crate::lower::model::Ex::XUnit, crate::lower::model::Ex::XCx]))), Text::lit("ok"), Array::new()))));
    let adoptions_p8 = each(&filter(&sk_p0.wx.flattens, &(|fl_pg: &crate::lower::node_::FlatDef| (&fl_pg.generation != &Text::lit("")) && (r_p1 == &crate::lower::node_::Read::OwnRead(fl_pg.outer.clone())))), &(|fl_ph: &crate::lower::node_::FlatDef| crate::lower::model::Do::DoScope(adoption(fl_ph))));
    append(&append(&append(&append(&append(&fold(&heights_p4, &flags_p3, &(|acc_pi: &Array<crate::lower::model::Do>, h_pj: &Nat| append(acc_pi, &ask_wake(sk_p0, h_pj)))), &marks_p5), &listed_p6), &answers_p7), &adoptions_p8), &source_marks(&sk_p0.wx, r_p1))
}

/// ```prism
/// SourceMarks: fn Wx, Read -> [Do]
/// ```
pub fn source_marks(wx_p0: &crate::lower::node_::Wx, r_p1: &crate::lower::node_::Read) -> Array<crate::lower::model::Do> {
    let fors_p2 = fold(&wx_p0.builders, &Array::new(), &(|acc_p3: &Array<crate::lower::model::Do>, b_p4: &crate::lower::model::ForDef| if crate::lower::node_::has_read(&reads_closed(&wx_p0.dyn_reads, &or(&get(&wx_p0.dyn_reads, &b_p4.source), &Array::new())), r_p1) {
        push(acc_p3, &crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_cache", &b_p4.source)))), Text::lit("mark"), Array::from(vec![crate::lower::model::Ex::XCx]))))
    } else {
        acc_p3.clone()
    }));
    fold(&wx_p0.let_caches, &fors_p2, &(|acc_p5: &Array<crate::lower::model::Do>, c_p6: &Text| if crate::lower::node_::has_read(&reads_all(&wx_p0.dyn_reads, &or(&get(&wx_p0.dyn_reads, c_p6), &Array::new())), r_p1) {
        push(acc_p5, &crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_cache", c_p6)))), Text::lit("mark"), Array::from(vec![crate::lower::model::Ex::XCx]))))
    } else {
        acc_p5.clone()
    }))
}

/// ```prism
/// ReadsAll: fn (Text ==> [Read]), [Read] -> [Read]
/// ```
pub fn reads_all(dyn_p0: &Map<Text, Array<crate::lower::node_::Read>>, reads_p1: &Array<crate::lower::node_::Read>) -> Array<crate::lower::node_::Read> {
    fold(&crate::check::errors::range0(&(&size(dyn_p0) + &Nat::from(1u32))), reads_p1, &(|acc_p2: &Array<crate::lower::node_::Read>, _: &Nat| fold(acc_p2, acc_p2, &(|a_p3: &Array<crate::lower::node_::Read>, r_p4: &crate::lower::node_::Read| crate::lower::node_::union_reads(a_p3, &getter_reads(dyn_p0, r_p4))))))
}

/// ```prism
/// IsOwnRead: fn Read -> Bool
/// ```
pub fn is_own_read(r_p0: &crate::lower::node_::Read) -> bool {
    match r_p0 {
        crate::lower::node_::Read::OwnRead(_) => true,
        crate::lower::node_::Read::ParentRead(_) => false,
    }
}

/// ```prism
/// SnapsBehind: fn Wx, Read -> [SnapDef]
/// ```
pub fn snaps_behind(wx_p0: &crate::lower::node_::Wx, r_p1: &crate::lower::node_::Read) -> Array<crate::lower::node_::SnapDef> {
    filter(&wx_p0.snaps, &(|sn_p2: &crate::lower::node_::SnapDef| (r_p1 == &crate::lower::node_::Read::OwnRead(sn_p2.live.clone())) || crate::lower::node_::has_read(&reads_closed(&wx_p0.dyn_reads, &Array::from(vec![crate::lower::node_::Read::OwnRead(sn_p2.live.clone())])), r_p1)))
}

/// ```prism
/// ListsBuild: fn Sinks, Read -> Bool
/// ```
pub fn lists_build(sk_p0: &Sinks, r_p1: &crate::lower::node_::Read) -> bool {
    &len(&snaps_behind(&sk_p0.wx, r_p1)) > &Nat::from(0u32)
}

/// ```prism
/// FiringCode: unbounded fn Sinks, Gn, Ex -> [Do]
/// ```
pub fn firing_code(sk_p0: &Sinks, g_p1: &crate::lower::node_::Gn, x_p2: &crate::lower::model::Ex) -> Array<crate::lower::model::Do> {
    let many_p3 = (&len(&g_p1.outs) > &Nat::from(1u32)) && !crate::lower::types::is_copy(&g_p1.ty);
    let xv_p4 = if many_p3 {
        crate::lower::model::Ex::XClone(Rc::new(x_p2.clone()))
    } else {
        x_p2.clone()
    };
    run_to_end(fold_job(g_p1.outs.clone(), Array::new(), {
        let xv_p4 = xv_p4.clone();
        let sk_p0 = sk_p0.clone();
        Rc::new(move |(p0, p1): (Array<crate::lower::model::Do>, crate::lower::node_::Out)| {
            let xv_p4 = xv_p4.clone();
            let sk_p0 = sk_p0.clone();
            entered(once_job(move || {
                let acc_p5 = p0;
                let o_p6 = p1;
                call_value((&o_p6.pipe)((xv_p4.clone(), {
                    let sk_p0 = sk_p0.clone();
                    let o_p6 = o_p6.clone();
                    Rc::new(move |p0: crate::lower::model::Ex| {
                        let sk_p0 = sk_p0.clone();
                        let o_p6 = o_p6.clone();
                        once_job(move || {
                            let y_p7 = p0;
                            prism_rtl::Turn::Finished(sink_code(&sk_p0, &o_p6.sink, &y_p7))
                        })
                    }) as Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>
                })), move |call_13560: Array<crate::lower::model::Do>| prism_rtl::Turn::Finished(append(&acc_p5, &call_13560)))
            }))
        }) as Rc<dyn Fn((Array<crate::lower::model::Do>, crate::lower::node_::Out)) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>
    }))
}

/// The step machine of `FiringCode`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FiringCode: unbounded fn Sinks, Gn, Ex -> [Do]
/// ```
pub struct FiringCode {
    pub sk_p0: Sinks,
    pub g_p1: crate::lower::node_::Gn,
    pub x_p2: crate::lower::model::Ex,
}

impl prism_rtl::Job<Array<crate::lower::model::Do>> for FiringCode {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::lower::model::Do>> {
        let sk_p0 = &self.sk_p0;
        let g_p1 = &self.g_p1;
        let x_p2 = &self.x_p2;
        let many_p3 = (&len(&g_p1.outs) > &Nat::from(1u32)) && !crate::lower::types::is_copy(&g_p1.ty);
        let xv_p4 = if many_p3 {
            crate::lower::model::Ex::XClone(Rc::new(x_p2.clone()))
        } else {
            x_p2.clone()
        };
        fold_job(g_p1.outs.clone(), Array::new(), {
            let xv_p4 = xv_p4.clone();
            let sk_p0 = sk_p0.clone();
            Rc::new(move |(p0, p1): (Array<crate::lower::model::Do>, crate::lower::node_::Out)| {
                let xv_p4 = xv_p4.clone();
                let sk_p0 = sk_p0.clone();
                entered(once_job(move || {
                    let acc_p5 = p0;
                    let o_p6 = p1;
                    call_value((&o_p6.pipe)((xv_p4.clone(), {
                        let sk_p0 = sk_p0.clone();
                        let o_p6 = o_p6.clone();
                        Rc::new(move |p0: crate::lower::model::Ex| {
                            let sk_p0 = sk_p0.clone();
                            let o_p6 = o_p6.clone();
                            once_job(move || {
                                let y_p7 = p0;
                                prism_rtl::Turn::Finished(sink_code(&sk_p0, &o_p6.sink, &y_p7))
                            })
                        }) as Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>
                    })), move |call_13560: Array<crate::lower::model::Do>| prism_rtl::Turn::Finished(append(&acc_p5, &call_13560)))
                }))
            }) as Rc<dyn Fn((Array<crate::lower::model::Do>, crate::lower::node_::Out)) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>
        }).cycle()
    }
}

/// `Start FiringCode, x`: what the function value is when passed to `@Run`.
pub fn start_firing_code(sk_p0: Sinks, g_p1: crate::lower::node_::Gn, x_p2: crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>> {
    Rc::new(FiringCode { sk_p0, g_p1, x_p2 })
}

/// ```prism
/// FinishNode: unbounded fn Wx, Text, [((Text, OutTy))], Bool -> NodeDef
/// ```
pub fn finish_node(wx0_p0: &crate::lower::node_::Wx, qk_p1: &Text, params_p2: &Array<(Text, crate::lower::model::OutTy)>, is_row_p3: &bool) -> crate::lower::model::NodeDef {
    let closed_gns_p4 = each(&wx0_p0.gns, &(|g_p1j: &crate::lower::node_::Gn| if &g_p1j.kind == &crate::lower::node_::GnKind::GnUpdated {
        crate::lower::node_::dynamics::with_reads(g_p1j, &reads_closed(&wx0_p0.dyn_reads, &g_p1j.reads))
    } else {
        g_p1j.clone()
    }));
    let (row_defs_p1k, gns2_p1l) = finish_pending(wx0_p0, &heights(&closed_gns_p4));
    let is_gen_p5 = *is_row_p3 && (&len(&filter(&wx0_p0.fields, &(|(f_p1m, _, _): &(Text, crate::lower::model::OutTy, Text)| f_p1m == &Text::lit("key")))) == &Nat::from(0u32));
    let wx_p6 = {
        let mut this: crate::lower::node_::Wx = wx0_p0.clone();
        this.gns = heights(&gns2_p1l);
        this.build = append(&this.build, &updated_gaps(wx0_p0, &closed_gns_p4, &is_gen_p5));
        this.rows = fold(&row_defs_p1k, &this.rows, &(|acc_p1n: &Array<crate::lower::model::NodeDef>, rd_p1o: &crate::lower::model::NodeDef| append(&push(acc_p1n, rd_p1o), &rd_p1o.children)));
        this
    };
    let combs_p7 = filter(&wx_p6.gns, &(|g_p1p: &crate::lower::node_::Gn| is_comb(&g_p1p.kind) || (&g_p1p.kind == &crate::lower::node_::GnKind::GnGather)));
    let heights_p8 = sort_nats(&fold(&combs_p7, &Array::new(), &(|acc_p1q: &Array<Nat>, g_p1r: &crate::lower::node_::Gn| crate::check::types::add_nat(acc_p1q, &g_p1r.height))));
    let many_p9 = &len(&heights_p8) > &Nat::from(1u32);
    let consts_pa = each(&heights_p8, &(|h_p1s: &Nat| (wake_const(&heights_p8, h_p1s), h_p1s.clone(), Text::lit("merges\' height above the node\'s inputs"))));
    let live_pb = filter(&wx_p6.places, &(|p_p1t: &crate::lower::node_::Place| &p_p1t.getter != &Text::lit("")));
    let root_reads_pc = match &wx_p6.root_dyn {
        Some((_, rds_p1u, _)) => reads_closed(&wx_p6.dyn_reads, rds_p1u),
        None => Array::new(),
    };
    let dirty_holds_pd = fold(&live_pb, &root_reads_pc, &(|acc_p1v: &Array<crate::lower::node_::Read>, p_p20: &crate::lower::node_::Place| crate::lower::node_::union_reads(acc_p1v, &reads_closed(&wx_p6.dyn_reads, &p_p20.reads))));
    let build_holds_pe = reads_closed(&wx_p6.dyn_reads, &wx_p6.build_holds);
    let sinks_pf = Sinks { wx: wx_p6.clone(), dirty: dirty_holds_pd.clone(), builds: build_holds_pe.clone(), heights: heights_p8.clone(), many: many_p9 };
    let ev_methods_pg = run_to_end(each_job(filter(&wx_p6.gns, &(|g_p21: &crate::lower::node_::Gn| &g_p21.kind != &crate::lower::node_::GnKind::GnNever)), {
        let sinks_pf = sinks_pf.clone();
        Rc::new(move |p0: crate::lower::node_::Gn| {
            let sinks_pf = sinks_pf.clone();
            entered(once_job(move || {
                let g_p22 = p0;
                call_then(start_firing_code(sinks_pf.clone(), g_p22.clone(), crate::lower::model::Ex::XVar(Text::lit("v"))), move |firing_code_15352: Array<crate::lower::model::Do>| prism_rtl::Turn::Finished(crate::lower::model::MethDef { name: g_p22.name.clone(), recv: crate::lower::model::Recv::RecvRc, params: Array::from(vec![(Text::lit("v"), g_p22.ty.clone())]), cx_: crate::lower::model::CxArg::CxMut, ret: crate::lower::model::OutTy::OutUnit, body: firing_code_15352, tail: crate::lower::model::Ex::XUnit, doc: gn_doc(&g_p22) }))
            }))
        }) as Rc<dyn Fn(crate::lower::node_::Gn) -> Rc<dyn prism_rtl::Job<crate::lower::model::MethDef>>>
    }));
    let gather_ins_ph = each(&filter(&wx_p6.gns, &(|g_p23: &crate::lower::node_::Gn| &g_p23.kind == &crate::lower::node_::GnKind::GnGather)), &(|g_p24: &crate::lower::node_::Gn| gather_in(&sinks_pf, g_p24)));
    let place_getters_pi = each(&live_pb, &(|p_p25: &crate::lower::node_::Place| crate::lower::model::MethDef { name: p_p25.getter.clone(), recv: crate::lower::model::Recv::RecvRef, params: Array::new(), cx_: crate::lower::model::CxArg::CxRef, ret: crate::lower::types::elem_ty(), body: Array::new(), tail: p_p25.level.clone(), doc: Text::from(format!("Place {}\'s level, read at the read point.", &crate::lower::model::place_text(&p_p25.pos))) }));
    let wake_body_pj = if many_p9 {
        Array::from(vec![wake_by_height(&combs_p7, &heights_p8)])
    } else {
        each(&combs_p7, &(|g_p26: &crate::lower::node_::Gn| decide(g_p26)))
    };
    let started_body_pk = each(&wx_p6.started, &(|st_p27: &Nat| self_call(&crate::lower::node_::gn_of(&wx_p6, st_p27).name, &Array::from(vec![crate::lower::model::Ex::XUnit]))));
    let deferred_body_pl = each(&wx_p6.defers, &(|(f_p28, id_p29): &(Text, Nat)| crate::lower::model::Do::DoIfLet(crate::lower::model::Pa::PaCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("v"))])), crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", f_p28)))), Text::lit("fired"), Array::from(vec![crate::lower::model::Ex::XCx])), Array::from(vec![self_call(&crate::lower::node_::gn_of(&wx_p6, id_p29).name, &Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("v"))]))]), Array::new())));
    let patch_body0_pm = fold(&live_pb, &Array::new(), &(|acc_p2a: &Array<crate::lower::model::Do>, p_p2b: &crate::lower::node_::Place| append(acc_p2a, &(if emits(&wx_p6, &p_p2b.pos) {
        patch_place(&wx_p6, p_p2b)
    } else {
        Array::from(vec![entry_take(&crate::lower::model::Ex::XSelf, p_p2b)])
    }))));
    let patch_body_pn = append(&patch_body0_pm, &root_dyn_patch(&wx_p6));
    let build_body_po = build_steps(&sinks_pf, &false);
    let push_body_pp = each(&filter(&wx_p6.dyn_places, &(|(pos_p2c, _, _, _): &(crate::lower::model::Pos_, Text, crate::lower::model::OutTy, Text)| emits(&wx_p6, pos_p2c))), &(|(pos_p2d, f_p2e, t_p2f, _): &(crate::lower::model::Pos_, Text, crate::lower::model::OutTy, Text)| crate::lower::model::Do::DoIf(crate::lower::model::Ex::XBin(Text::lit("=="), Rc::new(crate::lower::model::Ex::XVar(Text::lit("element"))), Rc::new(crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_element", f_p2e))))))), dyn_place_write(&sinks_pf, f_p2e, &crate::lower::model::Ex::XDecode(t_p2f.clone(), Rc::new(crate::lower::model::Ex::XVar(Text::lit("v"))))), Array::new())));
    let hooks_pq = filter(&Array::from(vec![(Text::lit("wake"), wake_body_pj.clone()), (Text::lit("started"), started_body_pk.clone()), (Text::lit("deferred"), deferred_body_pl.clone()), (Text::lit("build"), build_body_po.clone()), (Text::lit("push"), push_body_pp.clone()), (Text::lit("patch"), patch_body_pn.clone())]), &(|(_, b_p2g): &(Text, Array<crate::lower::model::Do>)| &len(b_p2g) > &Nat::from(0u32)));
    let started_reg_pr = if &len(&wx_p6.started) > &Nat::from(0u32) {
        Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCx), Text::lit("on_started"), Array::from(vec![crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(Text::lit("node"))))])))])
    } else {
        Array::new()
    };
    let links_ps = each(&wx_p6.hosts, &(|h_p2h: &crate::lower::node_::HostDef| crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XVar(Text::lit("node"))), Text::from(format!("{}", &h_p2h.name)))), Text::lit("link"), Array::from(vec![crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XVar(Text::lit("node"))))])))));
    let rows_built_pt = append(&links_ps, &build_steps(&sinks_pf, &true));
    let subscribed_pu = each(&wx_p6.subs, &(|(ev_p2i, m_p2j, t_p2k): &(Text, Text, crate::lower::model::OutTy)| crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XCall(Text::lit("subscribe_row"), Array::from(vec![crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XVar(Text::lit("node")))), crate::lower::model::Ex::XUpgrade(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XVar(Text::lit("node"))), Text::lit("parent")))), crate::lower::model::Ex::XClosure(false, Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("p"))]), Rc::new(crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XVar(Text::lit("p"))), Text::from(format!("{}_port", ev_p2i))))))), crate::lower::model::Ex::XClosure(false, Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("n")), crate::lower::model::Pa::PaBind(Text::lit("v")), crate::lower::model::Pa::PaBind(Text::lit("cx"))]), Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("n"))), m_p2j.clone(), Array::from(vec![crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(Text::lit("v")))), crate::lower::model::Ex::XCx])))), crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XVar(Text::lit("node"))), Text::from(format!("{}_sub", m_p2j)))))])))));
    let answers_pv = append(&each(&filter(&wx_p6.answers, &(|(pos_p2l, _, _, _): &(crate::lower::model::Pos_, Nat, crate::lower::model::OutTy, Text)| emits(&wx_p6, pos_p2l))), &(|(pos_p2m, id_p2n, t_p2o, _): &(crate::lower::model::Pos_, Nat, crate::lower::model::OutTy, Text)| answer_arm(&wx_p6, pos_p2m, id_p2n, t_p2o))), &each(&filter(&wx_p6.dyn_places, &(|(pos_p2p, _, _, _): &(crate::lower::model::Pos_, Text, crate::lower::model::OutTy, Text)| emits(&wx_p6, pos_p2p))), &(|(pos_p2q, f_p2r, t_p2s, _): &(crate::lower::model::Pos_, Text, crate::lower::model::OutTy, Text)| dyn_answer_arm(&sinks_pf, pos_p2q, f_p2r, t_p2s))));
    let forwards_p10 = append(&each(&filter(&wx_p6.builders, &(|b_p2t: &crate::lower::model::ForDef| emits(&wx_p6, &b_p2t.pos))), &(|b_p2u: &crate::lower::model::ForDef| (pos_pat(&b_p2u.pos, &key_tail()), forward_answer(b_p2u)))), &fold(&filter(&wx_p6.gens, &(|gd_p2v: &crate::lower::model::GenDef| emits(&wx_p6, &gd_p2v.pos))), &Array::new(), &(|acc_p30: &Array<(crate::lower::model::Pa, crate::lower::model::Ex)>, gd_p31: &crate::lower::model::GenDef| append(acc_p30, &crate::lower::node_::switch_::gen_forwards(gd_p31)))));
    let host_methods_p11 = fold(&wx_p6.hosts, &Array::new(), &(|acc_p32: &Array<crate::lower::model::MethDef>, h_p33: &crate::lower::node_::HostDef| append(acc_p32, &Array::from(vec![typed_dispatch(&sinks_pf, &Text::from(format!("{}_answer", &h_p33.name)), &h_p33.scope), host_moved(&sinks_pf, h_p33)]))));
    let gathered_p12 = filter(&wx_p6.snaps, &(|sn_p34: &crate::lower::node_::SnapDef| !(sn_p34.before || is_generation(&wx_p6, &sn_p34.builder))));
    let gathered_moved_p13 = append(&append(&each(&gathered_p12, &(|sn_p35: &crate::lower::node_::SnapDef| gathered_moved(sn_p35))), &each(&wx_p6.snaps, &(|sn_p36: &crate::lower::node_::SnapDef| snap_publish(&sinks_pf, sn_p36)))), &flatten_methods(&sinks_pf));
    let hosted_methods_p14 = match &wx_p6.hosted_by {
        Some(_) => Array::from(vec![typed_dispatch(&sinks_pf, &Text::lit("deliver"), &Nat::from(0u32)), document_getter(&wx_p6)]),
        None => Array::new(),
    };
    let moved_method_p15 = match &wx_p6.hosted_by {
        Some(m_p37) => Array::from(vec![document_moved(m_p37)]),
        None => Array::new(),
    };
    let row_methods_p16 = if *is_row_p3 { row_methods(&wx_p6) } else { Array::new() };
    let heard_build_f17 = {
        let wx_p6 = wx_p6.clone();
        let sinks_pf = sinks_pf.clone();
        Rc::new(move |m_p38: &Text| {
            let stales_p39 = fold(&wx_p6.gen_holds, &Array::new(), &(|acc_p3b: &Array<crate::lower::model::Do>, (gname_p3c, hs_p3d): &(Text, Array<crate::lower::node_::Read>)| if crate::lower::node_::has_read(&reads_closed(&wx_p6.dyn_reads, hs_p3d), &crate::lower::node_::Read::ParentRead(m_p38.clone())) {
                push(acc_p3b, &crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_stale", gname_p3c)))), Text::lit("set"), Array::from(vec![crate::lower::model::Ex::XBool(true)]))))
            } else {
                acc_p3b.clone()
            }));
            let builds_p3a = crate::lower::node_::has_read(&sinks_pf.builds, &crate::lower::node_::Read::ParentRead(m_p38.clone())) || (&len(&stales_p39) > &Nat::from(0u32));
            if builds_p3a && !lists_build(&sinks_pf, &crate::lower::node_::Read::ParentRead(m_p38.clone())) {
                append(&stales_p39, &Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCx), Text::lit("build_later"), Array::from(vec![crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XSelf))])))]))
            } else {
                stales_p39.clone()
            }
        }) as Rc<dyn Fn(&Text) -> Array<crate::lower::model::Do>>
    };
    let heard_p18 = each(&row_hears(&wx_p6), &(|m_p3e: &Text| crate::lower::model::MethDef { name: Text::from(format!("parent_wrote_{}", m_p3e)), recv: crate::lower::model::Recv::RecvRc, params: Array::new(), cx_: crate::lower::model::CxArg::CxMut, ret: crate::lower::model::OutTy::OutUnit, body: append(&append(&moved_by(&sinks_pf, &crate::lower::node_::Read::ParentRead(m_p3e.clone())), &(&heard_build_f17)(m_p3e)), &fold(&wx_p6.row_marks, &Array::new(), &(|acc_p3f: &Array<crate::lower::model::Do>, rm_p3g: &crate::lower::node_::RowMarks| append(acc_p3f, &row_written(&wx_p6, rm_p3g, &crate::lower::node_::Read::ParentRead(m_p3e.clone())))))), tail: crate::lower::model::Ex::XUnit, doc: Text::from(format!("The block wrote behind its `{}`, which this row reads through the parent: the `!Updated` nodes over it are told and the wake asked at their heights; the row\'s own builders over it are listed for the build; the rows of this row\'s own `for`s that read it are marked.", m_p3e)) }));
    let top_p19 = fold(&wx_p6.gns, &Nat::from(0u32), &(|hi_p3h: &Nat, g_p3i: &crate::lower::node_::Gn| max(hi_p3h, &g_p3i.height)));
    let wakes_field_p1a = if many_p9 {
        Array::from(vec![(Text::lit("wakes"), crate::lower::model::OutTy::OutWakes, Text::lit("the heights asked for this tick, lowest first"))])
    } else {
        Array::new()
    };
    let wakes_init_p1b = if many_p9 {
        Array::from(vec![(Text::lit("wakes"), crate::lower::model::Ex::XCall(Text::lit("Wakes::default"), Array::new()))])
    } else {
        Array::new()
    };
    let gen_fields_p1c = fold(&wx_p6.gens, &Array::new(), &(|acc_p3j: &Array<(Text, crate::lower::model::OutTy, Text)>, gd_p3k: &crate::lower::model::GenDef| append(acc_p3j, &Array::from(vec![(gd_p3k.name.clone(), crate::lower::model::OutTy::OutCell(Rc::new(crate::lower::model::OutTy::OutOpt(Rc::new(crate::lower::model::OutTy::OutObj(Rc::new(crate::lower::model::OutTy::OutNamed(Text::lit("Row"), Array::new()))))))), Text::from(format!("the current generation of the `rebuild` at place {}", &crate::lower::model::place_text(&gd_p3k.pos)))), (Text::from(format!("{}_count", &gd_p3k.name)), crate::lower::model::OutTy::OutNamed(Text::lit("Cell"), Array::from(vec![crate::lower::model::OutTy::OutCount])), Text::lit("how many generations it has built")), (Text::from(format!("{}_stale", &gd_p3k.name)), crate::lower::model::OutTy::OutNamed(Text::lit("Cell"), Array::from(vec![crate::lower::model::OutTy::OutBool])), Text::lit("its source changed since it was built"))]))));
    let gen_inits_p1d = fold(&wx_p6.gens, &Array::new(), &(|acc_p3l: &Array<(Text, crate::lower::model::Ex)>, gd_p3m: &crate::lower::model::GenDef| append(acc_p3l, &Array::from(vec![(gd_p3m.name.clone(), crate::lower::model::Ex::XCall(Text::lit("RefCell::new"), Array::from(vec![crate::lower::model::Ex::XNone]))), (Text::from(format!("{}_count", &gd_p3m.name)), crate::lower::model::Ex::XCall(Text::lit("Cell::new"), Array::from(vec![crate::lower::model::Ex::XIndex(Nat::from(0u32))]))), (Text::from(format!("{}_stale", &gd_p3m.name)), crate::lower::model::Ex::XCall(Text::lit("Cell::new"), Array::from(vec![crate::lower::model::Ex::XBool(false)])))]))));
    let port_fields_p1e = each(&wx_p6.ports, &(|pn_p3n: &Text| (Text::from(format!("{}_port", pn_p3n)), crate::lower::model::OutTy::OutPort(Rc::new(crate::lower::node_::keyed::gn_ty_named(&wx_p6, pn_p3n))), Text::from(format!("`!{}`, which rows subscribe to", pn_p3n)))));
    let port_inits_p1f = each(&wx_p6.ports, &(|pn_p3o: &Text| (Text::from(format!("{}_port", pn_p3o)), crate::lower::model::Ex::XCall(Text::lit("Port::new"), Array::new()))));
    let sub_fields_p1g = each(&wx_p6.subs, &(|(ev_p3p, m_p3q, t_p3r): &(Text, Text, crate::lower::model::OutTy)| (Text::from(format!("{}_sub", m_p3q)), crate::lower::model::OutTy::OutNamed(Text::lit("Cell"), Array::from(vec![crate::lower::model::OutTy::OutOpt(Rc::new(crate::lower::model::OutTy::OutNamed(Text::lit("Handle"), Array::new())))])), Text::from(format!("the subscription to the parent\'s `!{}`", ev_p3p)))));
    let sub_inits_p1h = each(&wx_p6.subs, &(|(ev_p3s, m_p3t, t_p3u): &(Text, Text, crate::lower::model::OutTy)| (Text::from(format!("{}_sub", m_p3t)), crate::lower::model::Ex::XCall(Text::lit("Cell::new"), Array::from(vec![crate::lower::model::Ex::XNone])))));
    let fallible_p1i = ((wx_p6.fallible || *is_row_p3) || (&len(&wx_p6.builders) > &Nat::from(0u32))) || (&len(&wx_p6.gens) > &Nat::from(0u32));
    crate::lower::model::NodeDef { name: wx_p6.node_.clone(), prism: crate::check::types::bare_name(qk_p1), doc: crate::lower::functions::definition_text(&wx_p6.lx, qk_p1), params: params_p2.clone(), fields: append(&append(&append(&append(&wx_p6.fields, &wakes_field_p1a), &gen_fields_p1c), &port_fields_p1e), &sub_fields_p1g), consts: consts_pa.clone(), lets: wx_p6.lets.clone(), inits: append(&wx_p6.inits, &append(&append(&append(&append(&wx_p6.moves, &wakes_init_p1b), &gen_inits_p1d), &port_inits_p1f), &sub_inits_p1h)), build: append(&append(&append(&rows_built_pt, &wx_p6.build), &subscribed_pu), &started_reg_pr), fallible: fallible_p1i, methods: append(&append(&append(&append(&append(&append(&append(&append(&ev_methods_pg, &gather_ins_ph), &place_getters_pi), &wx_p6.getters), &row_methods_p16), &heard_p18), &host_methods_p11), &gathered_moved_p13), &moved_method_p15), answers: append(&answers_pv, &forwards_p10), hooks: hooks_pq.clone(), builders: wx_p6.builders.clone(), wakes: many_p9, children: wx_p6.rows.clone(), gens: wx_p6.gens.clone(), subs: wx_p6.subs.clone(), top: top_p19.clone(), row_kind: if *is_row_p3 {
        if is_gen_p5 {
            crate::lower::model::RowKind::GenerationRow
        } else {
            crate::lower::model::RowKind::ForRow
        }
    } else {
        crate::lower::model::RowKind::NotARow
    }, hosted: hosted_methods_p14.clone() }
}

/// The step machine of `FinishNode`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FinishNode: unbounded fn Wx, Text, [((Text, OutTy))], Bool -> NodeDef
/// ```
pub struct FinishNode {
    pub wx0_p0: crate::lower::node_::Wx,
    pub qk_p1: Text,
    pub params_p2: Array<(Text, crate::lower::model::OutTy)>,
    pub is_row_p3: bool,
}

impl prism_rtl::Job<crate::lower::model::NodeDef> for FinishNode {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::NodeDef> {
        let wx0_p0 = &self.wx0_p0;
        let qk_p1 = &self.qk_p1;
        let params_p2 = &self.params_p2;
        let is_row_p3 = &self.is_row_p3;
        let closed_gns_p4 = each(&wx0_p0.gns, &(|g_p1j: &crate::lower::node_::Gn| if &g_p1j.kind == &crate::lower::node_::GnKind::GnUpdated {
            crate::lower::node_::dynamics::with_reads(g_p1j, &reads_closed(&wx0_p0.dyn_reads, &g_p1j.reads))
        } else {
            g_p1j.clone()
        }));
        let is_row_p3 = *is_row_p3;
        let params_p2 = params_p2.clone();
        let qk_p1 = qk_p1.clone();
        let wx0_p0 = wx0_p0.clone();
        call_then(start_finish_pending(wx0_p0.clone(), heights(&closed_gns_p4)), move |finish_pending_14117: (Array<crate::lower::model::NodeDef>, Array<crate::lower::node_::Gn>)| {
            let (row_defs_p1k, gns2_p1l) = finish_pending_14117;
            let is_gen_p5 = is_row_p3 && (&len(&filter(&wx0_p0.fields, &(|(f_p1m, _, _): &(Text, crate::lower::model::OutTy, Text)| f_p1m == &Text::lit("key")))) == &Nat::from(0u32));
            let wx_p6 = {
                let mut this: crate::lower::node_::Wx = wx0_p0.clone();
                this.gns = heights(&gns2_p1l);
                this.build = append(&this.build, &updated_gaps(&wx0_p0, &closed_gns_p4, &is_gen_p5));
                this.rows = fold(&row_defs_p1k, &this.rows, &(|acc_p1n: &Array<crate::lower::model::NodeDef>, rd_p1o: &crate::lower::model::NodeDef| append(&push(acc_p1n, rd_p1o), &rd_p1o.children)));
                this
            };
            let combs_p7 = filter(&wx_p6.gns, &(|g_p1p: &crate::lower::node_::Gn| is_comb(&g_p1p.kind) || (&g_p1p.kind == &crate::lower::node_::GnKind::GnGather)));
            let heights_p8 = sort_nats(&fold(&combs_p7, &Array::new(), &(|acc_p1q: &Array<Nat>, g_p1r: &crate::lower::node_::Gn| crate::check::types::add_nat(acc_p1q, &g_p1r.height))));
            let many_p9 = &len(&heights_p8) > &Nat::from(1u32);
            let consts_pa = each(&heights_p8, &(|h_p1s: &Nat| (wake_const(&heights_p8, h_p1s), h_p1s.clone(), Text::lit("merges\' height above the node\'s inputs"))));
            let live_pb = filter(&wx_p6.places, &(|p_p1t: &crate::lower::node_::Place| &p_p1t.getter != &Text::lit("")));
            let root_reads_pc = match &wx_p6.root_dyn {
                Some((_, rds_p1u, _)) => reads_closed(&wx_p6.dyn_reads, rds_p1u),
                None => Array::new(),
            };
            let dirty_holds_pd = fold(&live_pb, &root_reads_pc, &(|acc_p1v: &Array<crate::lower::node_::Read>, p_p20: &crate::lower::node_::Place| crate::lower::node_::union_reads(acc_p1v, &reads_closed(&wx_p6.dyn_reads, &p_p20.reads))));
            let build_holds_pe = reads_closed(&wx_p6.dyn_reads, &wx_p6.build_holds);
            let sinks_pf = Sinks { wx: wx_p6.clone(), dirty: dirty_holds_pd.clone(), builds: build_holds_pe.clone(), heights: heights_p8.clone(), many: many_p9 };
            call_value(each_job(filter(&wx_p6.gns, &(|g_p21: &crate::lower::node_::Gn| &g_p21.kind != &crate::lower::node_::GnKind::GnNever)), {
                let sinks_pf = sinks_pf.clone();
                Rc::new(move |p0: crate::lower::node_::Gn| {
                    let sinks_pf = sinks_pf.clone();
                    entered(once_job(move || {
                        let g_p22 = p0;
                        call_then(start_firing_code(sinks_pf.clone(), g_p22.clone(), crate::lower::model::Ex::XVar(Text::lit("v"))), move |firing_code_15352: Array<crate::lower::model::Do>| prism_rtl::Turn::Finished(crate::lower::model::MethDef { name: g_p22.name.clone(), recv: crate::lower::model::Recv::RecvRc, params: Array::from(vec![(Text::lit("v"), g_p22.ty.clone())]), cx_: crate::lower::model::CxArg::CxMut, ret: crate::lower::model::OutTy::OutUnit, body: firing_code_15352, tail: crate::lower::model::Ex::XUnit, doc: gn_doc(&g_p22) }))
                    }))
                }) as Rc<dyn Fn(crate::lower::node_::Gn) -> Rc<dyn prism_rtl::Job<crate::lower::model::MethDef>>>
            }), move |each_15212: Array<crate::lower::model::MethDef>| {
                let ev_methods_pg = each_15212;
                let gather_ins_ph = each(&filter(&wx_p6.gns, &(|g_p23: &crate::lower::node_::Gn| &g_p23.kind == &crate::lower::node_::GnKind::GnGather)), &(|g_p24: &crate::lower::node_::Gn| gather_in(&sinks_pf, g_p24)));
                let place_getters_pi = each(&live_pb, &(|p_p25: &crate::lower::node_::Place| crate::lower::model::MethDef { name: p_p25.getter.clone(), recv: crate::lower::model::Recv::RecvRef, params: Array::new(), cx_: crate::lower::model::CxArg::CxRef, ret: crate::lower::types::elem_ty(), body: Array::new(), tail: p_p25.level.clone(), doc: Text::from(format!("Place {}\'s level, read at the read point.", &crate::lower::model::place_text(&p_p25.pos))) }));
                let wake_body_pj = if many_p9 {
                    Array::from(vec![wake_by_height(&combs_p7, &heights_p8)])
                } else {
                    each(&combs_p7, &(|g_p26: &crate::lower::node_::Gn| decide(g_p26)))
                };
                let started_body_pk = each(&wx_p6.started, &(|st_p27: &Nat| self_call(&crate::lower::node_::gn_of(&wx_p6, st_p27).name, &Array::from(vec![crate::lower::model::Ex::XUnit]))));
                let deferred_body_pl = each(&wx_p6.defers, &(|(f_p28, id_p29): &(Text, Nat)| crate::lower::model::Do::DoIfLet(crate::lower::model::Pa::PaCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("v"))])), crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", f_p28)))), Text::lit("fired"), Array::from(vec![crate::lower::model::Ex::XCx])), Array::from(vec![self_call(&crate::lower::node_::gn_of(&wx_p6, id_p29).name, &Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("v"))]))]), Array::new())));
                let patch_body0_pm = fold(&live_pb, &Array::new(), &(|acc_p2a: &Array<crate::lower::model::Do>, p_p2b: &crate::lower::node_::Place| append(acc_p2a, &(if emits(&wx_p6, &p_p2b.pos) {
                    patch_place(&wx_p6, p_p2b)
                } else {
                    Array::from(vec![entry_take(&crate::lower::model::Ex::XSelf, p_p2b)])
                }))));
                let patch_body_pn = append(&patch_body0_pm, &root_dyn_patch(&wx_p6));
                let build_body_po = build_steps(&sinks_pf, &false);
                let push_body_pp = each(&filter(&wx_p6.dyn_places, &(|(pos_p2c, _, _, _): &(crate::lower::model::Pos_, Text, crate::lower::model::OutTy, Text)| emits(&wx_p6, pos_p2c))), &(|(pos_p2d, f_p2e, t_p2f, _): &(crate::lower::model::Pos_, Text, crate::lower::model::OutTy, Text)| crate::lower::model::Do::DoIf(crate::lower::model::Ex::XBin(Text::lit("=="), Rc::new(crate::lower::model::Ex::XVar(Text::lit("element"))), Rc::new(crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_element", f_p2e))))))), dyn_place_write(&sinks_pf, f_p2e, &crate::lower::model::Ex::XDecode(t_p2f.clone(), Rc::new(crate::lower::model::Ex::XVar(Text::lit("v"))))), Array::new())));
                let hooks_pq = filter(&Array::from(vec![(Text::lit("wake"), wake_body_pj.clone()), (Text::lit("started"), started_body_pk.clone()), (Text::lit("deferred"), deferred_body_pl.clone()), (Text::lit("build"), build_body_po.clone()), (Text::lit("push"), push_body_pp.clone()), (Text::lit("patch"), patch_body_pn.clone())]), &(|(_, b_p2g): &(Text, Array<crate::lower::model::Do>)| &len(b_p2g) > &Nat::from(0u32)));
                let started_reg_pr = if &len(&wx_p6.started) > &Nat::from(0u32) {
                    Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCx), Text::lit("on_started"), Array::from(vec![crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(Text::lit("node"))))])))])
                } else {
                    Array::new()
                };
                let links_ps = each(&wx_p6.hosts, &(|h_p2h: &crate::lower::node_::HostDef| crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XVar(Text::lit("node"))), Text::from(format!("{}", &h_p2h.name)))), Text::lit("link"), Array::from(vec![crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XVar(Text::lit("node"))))])))));
                let rows_built_pt = append(&links_ps, &build_steps(&sinks_pf, &true));
                let subscribed_pu = each(&wx_p6.subs, &(|(ev_p2i, m_p2j, t_p2k): &(Text, Text, crate::lower::model::OutTy)| crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XCall(Text::lit("subscribe_row"), Array::from(vec![crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XVar(Text::lit("node")))), crate::lower::model::Ex::XUpgrade(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XVar(Text::lit("node"))), Text::lit("parent")))), crate::lower::model::Ex::XClosure(false, Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("p"))]), Rc::new(crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XVar(Text::lit("p"))), Text::from(format!("{}_port", ev_p2i))))))), crate::lower::model::Ex::XClosure(false, Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("n")), crate::lower::model::Pa::PaBind(Text::lit("v")), crate::lower::model::Pa::PaBind(Text::lit("cx"))]), Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("n"))), m_p2j.clone(), Array::from(vec![crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(Text::lit("v")))), crate::lower::model::Ex::XCx])))), crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XVar(Text::lit("node"))), Text::from(format!("{}_sub", m_p2j)))))])))));
                let answers_pv = append(&each(&filter(&wx_p6.answers, &(|(pos_p2l, _, _, _): &(crate::lower::model::Pos_, Nat, crate::lower::model::OutTy, Text)| emits(&wx_p6, pos_p2l))), &(|(pos_p2m, id_p2n, t_p2o, _): &(crate::lower::model::Pos_, Nat, crate::lower::model::OutTy, Text)| answer_arm(&wx_p6, pos_p2m, id_p2n, t_p2o))), &each(&filter(&wx_p6.dyn_places, &(|(pos_p2p, _, _, _): &(crate::lower::model::Pos_, Text, crate::lower::model::OutTy, Text)| emits(&wx_p6, pos_p2p))), &(|(pos_p2q, f_p2r, t_p2s, _): &(crate::lower::model::Pos_, Text, crate::lower::model::OutTy, Text)| dyn_answer_arm(&sinks_pf, pos_p2q, f_p2r, t_p2s))));
                let forwards_p10 = append(&each(&filter(&wx_p6.builders, &(|b_p2t: &crate::lower::model::ForDef| emits(&wx_p6, &b_p2t.pos))), &(|b_p2u: &crate::lower::model::ForDef| (pos_pat(&b_p2u.pos, &key_tail()), forward_answer(b_p2u)))), &fold(&filter(&wx_p6.gens, &(|gd_p2v: &crate::lower::model::GenDef| emits(&wx_p6, &gd_p2v.pos))), &Array::new(), &(|acc_p30: &Array<(crate::lower::model::Pa, crate::lower::model::Ex)>, gd_p31: &crate::lower::model::GenDef| append(acc_p30, &crate::lower::node_::switch_::gen_forwards(gd_p31)))));
                let host_methods_p11 = fold(&wx_p6.hosts, &Array::new(), &(|acc_p32: &Array<crate::lower::model::MethDef>, h_p33: &crate::lower::node_::HostDef| append(acc_p32, &Array::from(vec![typed_dispatch(&sinks_pf, &Text::from(format!("{}_answer", &h_p33.name)), &h_p33.scope), host_moved(&sinks_pf, h_p33)]))));
                let gathered_p12 = filter(&wx_p6.snaps, &(|sn_p34: &crate::lower::node_::SnapDef| !(sn_p34.before || is_generation(&wx_p6, &sn_p34.builder))));
                let gathered_moved_p13 = append(&append(&each(&gathered_p12, &(|sn_p35: &crate::lower::node_::SnapDef| gathered_moved(sn_p35))), &each(&wx_p6.snaps, &(|sn_p36: &crate::lower::node_::SnapDef| snap_publish(&sinks_pf, sn_p36)))), &flatten_methods(&sinks_pf));
                let hosted_methods_p14 = match &wx_p6.hosted_by {
                    Some(_) => Array::from(vec![typed_dispatch(&sinks_pf, &Text::lit("deliver"), &Nat::from(0u32)), document_getter(&wx_p6)]),
                    None => Array::new(),
                };
                let moved_method_p15 = match &wx_p6.hosted_by {
                    Some(m_p37) => Array::from(vec![document_moved(m_p37)]),
                    None => Array::new(),
                };
                let row_methods_p16 = if is_row_p3 { row_methods(&wx_p6) } else { Array::new() };
                let heard_build_f17 = {
                    let wx_p6 = wx_p6.clone();
                    let sinks_pf = sinks_pf.clone();
                    Rc::new(move |m_p38: &Text| {
                        let stales_p39 = fold(&wx_p6.gen_holds, &Array::new(), &(|acc_p3b: &Array<crate::lower::model::Do>, (gname_p3c, hs_p3d): &(Text, Array<crate::lower::node_::Read>)| if crate::lower::node_::has_read(&reads_closed(&wx_p6.dyn_reads, hs_p3d), &crate::lower::node_::Read::ParentRead(m_p38.clone())) {
                            push(acc_p3b, &crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_stale", gname_p3c)))), Text::lit("set"), Array::from(vec![crate::lower::model::Ex::XBool(true)]))))
                        } else {
                            acc_p3b.clone()
                        }));
                        let builds_p3a = crate::lower::node_::has_read(&sinks_pf.builds, &crate::lower::node_::Read::ParentRead(m_p38.clone())) || (&len(&stales_p39) > &Nat::from(0u32));
                        if builds_p3a && !lists_build(&sinks_pf, &crate::lower::node_::Read::ParentRead(m_p38.clone())) {
                            append(&stales_p39, &Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCx), Text::lit("build_later"), Array::from(vec![crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XSelf))])))]))
                        } else {
                            stales_p39.clone()
                        }
                    }) as Rc<dyn Fn(&Text) -> Array<crate::lower::model::Do>>
                };
                let heard_p18 = each(&row_hears(&wx_p6), &(|m_p3e: &Text| crate::lower::model::MethDef { name: Text::from(format!("parent_wrote_{}", m_p3e)), recv: crate::lower::model::Recv::RecvRc, params: Array::new(), cx_: crate::lower::model::CxArg::CxMut, ret: crate::lower::model::OutTy::OutUnit, body: append(&append(&moved_by(&sinks_pf, &crate::lower::node_::Read::ParentRead(m_p3e.clone())), &(&heard_build_f17)(m_p3e)), &fold(&wx_p6.row_marks, &Array::new(), &(|acc_p3f: &Array<crate::lower::model::Do>, rm_p3g: &crate::lower::node_::RowMarks| append(acc_p3f, &row_written(&wx_p6, rm_p3g, &crate::lower::node_::Read::ParentRead(m_p3e.clone())))))), tail: crate::lower::model::Ex::XUnit, doc: Text::from(format!("The block wrote behind its `{}`, which this row reads through the parent: the `!Updated` nodes over it are told and the wake asked at their heights; the row\'s own builders over it are listed for the build; the rows of this row\'s own `for`s that read it are marked.", m_p3e)) }));
                let top_p19 = fold(&wx_p6.gns, &Nat::from(0u32), &(|hi_p3h: &Nat, g_p3i: &crate::lower::node_::Gn| max(hi_p3h, &g_p3i.height)));
                let wakes_field_p1a = if many_p9 {
                    Array::from(vec![(Text::lit("wakes"), crate::lower::model::OutTy::OutWakes, Text::lit("the heights asked for this tick, lowest first"))])
                } else {
                    Array::new()
                };
                let wakes_init_p1b = if many_p9 {
                    Array::from(vec![(Text::lit("wakes"), crate::lower::model::Ex::XCall(Text::lit("Wakes::default"), Array::new()))])
                } else {
                    Array::new()
                };
                let gen_fields_p1c = fold(&wx_p6.gens, &Array::new(), &(|acc_p3j: &Array<(Text, crate::lower::model::OutTy, Text)>, gd_p3k: &crate::lower::model::GenDef| append(acc_p3j, &Array::from(vec![(gd_p3k.name.clone(), crate::lower::model::OutTy::OutCell(Rc::new(crate::lower::model::OutTy::OutOpt(Rc::new(crate::lower::model::OutTy::OutObj(Rc::new(crate::lower::model::OutTy::OutNamed(Text::lit("Row"), Array::new()))))))), Text::from(format!("the current generation of the `rebuild` at place {}", &crate::lower::model::place_text(&gd_p3k.pos)))), (Text::from(format!("{}_count", &gd_p3k.name)), crate::lower::model::OutTy::OutNamed(Text::lit("Cell"), Array::from(vec![crate::lower::model::OutTy::OutCount])), Text::lit("how many generations it has built")), (Text::from(format!("{}_stale", &gd_p3k.name)), crate::lower::model::OutTy::OutNamed(Text::lit("Cell"), Array::from(vec![crate::lower::model::OutTy::OutBool])), Text::lit("its source changed since it was built"))]))));
                let gen_inits_p1d = fold(&wx_p6.gens, &Array::new(), &(|acc_p3l: &Array<(Text, crate::lower::model::Ex)>, gd_p3m: &crate::lower::model::GenDef| append(acc_p3l, &Array::from(vec![(gd_p3m.name.clone(), crate::lower::model::Ex::XCall(Text::lit("RefCell::new"), Array::from(vec![crate::lower::model::Ex::XNone]))), (Text::from(format!("{}_count", &gd_p3m.name)), crate::lower::model::Ex::XCall(Text::lit("Cell::new"), Array::from(vec![crate::lower::model::Ex::XIndex(Nat::from(0u32))]))), (Text::from(format!("{}_stale", &gd_p3m.name)), crate::lower::model::Ex::XCall(Text::lit("Cell::new"), Array::from(vec![crate::lower::model::Ex::XBool(false)])))]))));
                let port_fields_p1e = each(&wx_p6.ports, &(|pn_p3n: &Text| (Text::from(format!("{}_port", pn_p3n)), crate::lower::model::OutTy::OutPort(Rc::new(crate::lower::node_::keyed::gn_ty_named(&wx_p6, pn_p3n))), Text::from(format!("`!{}`, which rows subscribe to", pn_p3n)))));
                let port_inits_p1f = each(&wx_p6.ports, &(|pn_p3o: &Text| (Text::from(format!("{}_port", pn_p3o)), crate::lower::model::Ex::XCall(Text::lit("Port::new"), Array::new()))));
                let sub_fields_p1g = each(&wx_p6.subs, &(|(ev_p3p, m_p3q, t_p3r): &(Text, Text, crate::lower::model::OutTy)| (Text::from(format!("{}_sub", m_p3q)), crate::lower::model::OutTy::OutNamed(Text::lit("Cell"), Array::from(vec![crate::lower::model::OutTy::OutOpt(Rc::new(crate::lower::model::OutTy::OutNamed(Text::lit("Handle"), Array::new())))])), Text::from(format!("the subscription to the parent\'s `!{}`", ev_p3p)))));
                let sub_inits_p1h = each(&wx_p6.subs, &(|(ev_p3s, m_p3t, t_p3u): &(Text, Text, crate::lower::model::OutTy)| (Text::from(format!("{}_sub", m_p3t)), crate::lower::model::Ex::XCall(Text::lit("Cell::new"), Array::from(vec![crate::lower::model::Ex::XNone])))));
                let fallible_p1i = ((wx_p6.fallible || is_row_p3) || (&len(&wx_p6.builders) > &Nat::from(0u32))) || (&len(&wx_p6.gens) > &Nat::from(0u32));
                prism_rtl::Turn::Finished(crate::lower::model::NodeDef { name: wx_p6.node_.clone(), prism: crate::check::types::bare_name(&qk_p1), doc: crate::lower::functions::definition_text(&wx_p6.lx, &qk_p1), params: params_p2.clone(), fields: append(&append(&append(&append(&wx_p6.fields, &wakes_field_p1a), &gen_fields_p1c), &port_fields_p1e), &sub_fields_p1g), consts: consts_pa.clone(), lets: wx_p6.lets.clone(), inits: append(&wx_p6.inits, &append(&append(&append(&append(&wx_p6.moves, &wakes_init_p1b), &gen_inits_p1d), &port_inits_p1f), &sub_inits_p1h)), build: append(&append(&append(&rows_built_pt, &wx_p6.build), &subscribed_pu), &started_reg_pr), fallible: fallible_p1i, methods: append(&append(&append(&append(&append(&append(&append(&append(&ev_methods_pg, &gather_ins_ph), &place_getters_pi), &wx_p6.getters), &row_methods_p16), &heard_p18), &host_methods_p11), &gathered_moved_p13), &moved_method_p15), answers: append(&answers_pv, &forwards_p10), hooks: hooks_pq.clone(), builders: wx_p6.builders.clone(), wakes: many_p9, children: wx_p6.rows.clone(), gens: wx_p6.gens.clone(), subs: wx_p6.subs.clone(), top: top_p19.clone(), row_kind: if is_row_p3 {
                    if is_gen_p5 {
                        crate::lower::model::RowKind::GenerationRow
                    } else {
                        crate::lower::model::RowKind::ForRow
                    }
                } else {
                    crate::lower::model::RowKind::NotARow
                }, hosted: hosted_methods_p14.clone() })
            })
        })
    }
}

/// `Start FinishNode, x`: what the function value is when passed to `@Run`.
pub fn start_finish_node(wx0_p0: crate::lower::node_::Wx, qk_p1: Text, params_p2: Array<(Text, crate::lower::model::OutTy)>, is_row_p3: bool) -> Rc<dyn prism_rtl::Job<crate::lower::model::NodeDef>> {
    Rc::new(FinishNode { wx0_p0, qk_p1, params_p2, is_row_p3 })
}

/// ```prism
/// IsGeneration: fn Wx, Text -> Bool
/// ```
pub fn is_generation(wx_p0: &crate::lower::node_::Wx, name_p1: &Text) -> bool {
    &len(&filter(&wx_p0.gens, &(|gd_p2: &crate::lower::model::GenDef| &gd_p2.name == name_p1))) > &Nat::from(0u32)
}

/// ```prism
/// FlattenMethods: fn Sinks -> [MethDef]
/// ```
pub fn flatten_methods(sk_p0: &Sinks) -> Array<crate::lower::model::MethDef> {
    let wx_p1 = sk_p0.wx.clone();
    let entries_p2 = fold(&filter(&wx_p1.flattens, &(|fl_p7: &crate::lower::node_::FlatDef| &fl_p7.generation == &Text::lit(""))), &Array::new(), &(|acc_p8: &Array<crate::lower::model::MethDef>, fl_p9: &crate::lower::node_::FlatDef| {
        let set_pa = crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_inner", &fl_p9.name)))), Text::lit("set"), Array::from(vec![crate::lower::model::Ex::XCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XSelf), Text::lit("entry"), Array::from(vec![crate::lower::model::Ex::XCx]))])), crate::lower::model::Ex::XCx])));
        let followed_pb = crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_follow", &fl_p9.name)))), Text::lit("follow"), Array::from(vec![crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XSelf), Text::lit("entry"), Array::from(vec![crate::lower::model::Ex::XCx]))), Text::lit("updates")))), crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XSelf)))), crate::lower::model::Ex::XPath(Text::from(format!("{}::{}_moved", &wx_p1.node_, &fl_p9.name)))])));
        let moved_pc = crate::lower::model::MethDef { name: Text::from(format!("{}_moved", &fl_p9.name)), recv: crate::lower::model::Recv::RecvRc, params: Array::new(), cx_: crate::lower::model::CxArg::CxMut, ret: crate::lower::model::OutTy::OutUnit, body: hold_written(sk_p0, &Text::from(format!("{}_inner", &fl_p9.name))), tail: crate::lower::model::Ex::XUnit, doc: Text::from(format!("`{}`\'s inner moved: what reads it reads it again.", &fl_p9.name)) };
        let replaced_pd = crate::lower::model::MethDef { name: Text::from(format!("{}_replaced", &fl_p9.name)), recv: crate::lower::model::Recv::RecvRc, params: Array::new(), cx_: crate::lower::model::CxArg::CxMut, ret: crate::lower::model::OutTy::OutUnit, body: adoption(fl_p9), tail: crate::lower::model::Ex::XUnit, doc: Text::from(format!("The `for`\'s builder found another dynamic than `{}`\'s inner under this row\'s key: the adoption is queued for the first firings of the next tick, which is owed (Semantics ch. 4).", &fl_p9.name)) };
        let adopt_pe = crate::lower::model::MethDef { name: Text::from(format!("{}_adopt", &fl_p9.name)), recv: crate::lower::model::Recv::RecvRc, params: Array::new(), cx_: crate::lower::model::CxArg::CxMut, ret: crate::lower::model::OutTy::OutUnit, body: append(&Array::from(vec![set_pa.clone(), followed_pb.clone()]), &hold_written(sk_p0, &Text::from(format!("{}_inner", &fl_p9.name)))), tail: crate::lower::model::Ex::XUnit, doc: Text::from(format!("`{}` adopts the dynamic under its row\'s key as the tick before left it, among this tick\'s first firings: from here on it reads that inner (Semantics ch. 4).", &fl_p9.name)) };
        append(acc_p8, &Array::from(vec![moved_pc.clone(), replaced_pd.clone(), adopt_pe.clone()]))
    }));
    let adopts0_p3 = each(&filter(&wx_p1.flattens, &(|fl_pf: &crate::lower::node_::FlatDef| &fl_pf.generation != &Text::lit(""))), &(|fl_pg: &crate::lower::node_::FlatDef| {
        let set_ph = crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_inner", &fl_pg.name)))), Text::lit("set"), Array::from(vec![crate::lower::model::Ex::XCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XSelf), fl_pg.outer.clone(), Array::from(vec![crate::lower::model::Ex::XCx]))])), crate::lower::model::Ex::XCx])));
        crate::lower::model::MethDef { name: Text::from(format!("{}_adopt", &fl_pg.name)), recv: crate::lower::model::Recv::RecvRc, params: Array::new(), cx_: crate::lower::model::CxArg::CxMut, ret: crate::lower::model::OutTy::OutUnit, body: append(&Array::from(vec![set_ph.clone()]), &hold_written(sk_p0, &Text::from(format!("{}_inner", &fl_pg.name)))), tail: crate::lower::model::Ex::XUnit, doc: Text::lit("`@Flatten` adopts the inner its `rebuild`\'s dynamic held after the tick before, among this tick\'s first firings: from here on it reads that inner (Semantics ch. 7).") }
    }));
    let adopts_p4 = append(&adopts0_p3, &entries_p2);
    let dyn_gens_p5 = filter(&wx_p1.gens, &(|gd_pi: &crate::lower::model::GenDef| &len(&filter(&wx_p1.snaps, &(|sn_pj: &crate::lower::node_::SnapDef| &sn_pj.builder == &gd_pi.name))) > &Nat::from(0u32)));
    let moved_p6 = each(&dyn_gens_p5, &(|gd_pk: &crate::lower::model::GenDef| {
        let marks_pl = fold(&filter(&wx_p1.flattens, &(|fl_pq: &crate::lower::node_::FlatDef| &fl_pq.generation == &gd_pk.name)), &Array::new(), &(|acc_pr: &Array<crate::lower::model::Do>, fl_ps: &crate::lower::node_::FlatDef| append(acc_pr, &hold_written(sk_p0, &Text::from(format!("{}_inner", &fl_ps.name))))));
        let live_pm = crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_result_live", &gd_pk.name)))), Text::lit("borrow"), Array::new())), Text::lit("as_ref"), Array::new());
        let port_pn = crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XVar(Text::lit("d"))), Text::lit("updates"));
        let fire_po = crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(port_pn.clone()), Text::lit("fire"), Array::from(vec![crate::lower::model::Ex::XUnit, crate::lower::model::Ex::XCx]))), Text::lit("ok"), Array::new());
        let fired_pp = crate::lower::model::Do::DoIfLet(crate::lower::model::Pa::PaCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("d"))])), live_pm.clone(), Array::from(vec![crate::lower::model::Do::DoExpr(fire_po.clone())]), Array::new());
        crate::lower::model::MethDef { name: Text::from(format!("{}_result_moved", &gd_pk.name)), recv: crate::lower::model::Recv::RecvRc, params: Array::new(), cx_: crate::lower::model::CxArg::CxMut, ret: crate::lower::model::OutTy::OutUnit, body: push(&marks_pl, &fired_pp), tail: crate::lower::model::Ex::XUnit, doc: Text::lit("The current generation\'s result moved: what reads a `@Flatten` over it reads it again, and the dynamic kept for it fires its update event for whoever follows it outside this node.") }
    }));
    append(&adopts_p4, &moved_p6)
}

/// ```prism
/// HostMoved: fn Sinks, HostDef -> MethDef
/// ```
pub fn host_moved(sk_p0: &Sinks, h_p1: &crate::lower::node_::HostDef) -> crate::lower::model::MethDef {
    crate::lower::model::MethDef { name: Text::from(format!("{}_moved", &h_p1.name)), recv: crate::lower::model::Recv::RecvRc, params: Array::new(), cx_: crate::lower::model::CxArg::CxMut, ret: crate::lower::model::OutTy::OutUnit, body: hold_written(sk_p0, &Text::from(format!("{}_doc_now", &h_p1.name))), tail: crate::lower::model::Ex::XUnit, doc: Text::from(format!("A node of the child hosted at place {} wrote behind its document: the structure is marked as for a write of a hold it reads (pick HO), the snapshot listed to be taken; the program\'s `$doc` moves when it is published, the tick after (pick ST).", &crate::lower::model::place_text(&h_p1.pos))) }
}

/// ```prism
/// BuildSteps: fn Sinks, Bool -> [Do]
/// ```
pub fn build_steps(sk_p0: &Sinks, at_build_p1: &bool) -> Array<crate::lower::model::Do> {
    let wx_p2 = sk_p0.wx.clone();
    let recv_p3 = if *at_build_p1 {
        crate::lower::model::Ex::XVar(Text::lit("node"))
    } else {
        crate::lower::model::Ex::XSelf
    };
    let take_f4 = {
        let at_build_p1 = *at_build_p1;
        let sk_p0 = sk_p0.clone();
        Rc::new(move |sn_p8: &crate::lower::node_::SnapDef| if at_build_p1 { snap_take_at_build(sn_p8) } else { snap_take(&sk_p0, sn_p8) }) as Rc<dyn Fn(&crate::lower::node_::SnapDef) -> crate::lower::model::Do>
    };
    let builder_f5 = {
        let wx_p2 = wx_p2.clone();
        let take_f4 = take_f4.clone();
        let recv_p3 = recv_p3.clone();
        Rc::new(move |b_p9: &crate::lower::model::ForDef| {
            let before_pa = each(&filter(&wx_p2.snaps, &(|sn_pc: &crate::lower::node_::SnapDef| sn_pc.before && (&sn_pc.builder == &b_p9.name))), &*take_f4);
            let after_pb = each(&filter(&wx_p2.snaps, &(|sn_pd: &crate::lower::node_::SnapDef| !sn_pd.before && (&sn_pd.builder == &b_p9.name))), &*take_f4);
            append(&push(&before_pa, &crate::lower::model::Do::DoExpr(crate::lower::expr::try_of(&crate::lower::model::Ex::XMethod(Rc::new(recv_p3.clone()), Text::from(format!("{}_build", &b_p9.name)), Array::from(vec![crate::lower::model::Ex::XCx]))))), &after_pb)
        }) as Rc<dyn Fn(&crate::lower::model::ForDef) -> Array<crate::lower::model::Do>>
    };
    let gen_f6 = {
        let at_build_p1 = *at_build_p1;
        let recv_p3 = recv_p3.clone();
        let wx_p2 = wx_p2.clone();
        let take_f4 = take_f4.clone();
        Rc::new(move |gd_pe: &crate::lower::model::GenDef| {
            let built_pf = if at_build_p1 {
                crate::lower::model::Do::DoExpr(crate::lower::expr::try_of(&crate::lower::model::Ex::XMethod(Rc::new(recv_p3.clone()), Text::from(format!("{}_build", &gd_pe.name)), Array::from(vec![crate::lower::model::Ex::XCx]))))
            } else {
                crate::lower::model::Do::DoIf(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_stale", &gd_pe.name)))), Text::lit("replace"), Array::from(vec![crate::lower::model::Ex::XBool(false)])), Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::expr::try_of(&crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_build", &gd_pe.name)), Array::from(vec![crate::lower::model::Ex::XCx]))))]), Array::new())
            };
            append(&Array::from(vec![built_pf.clone()]), &each(&filter(&wx_p2.snaps, &(|sn_pg: &crate::lower::node_::SnapDef| !sn_pg.before && (&sn_pg.builder == &gd_pe.name))), &*take_f4))
        }) as Rc<dyn Fn(&crate::lower::model::GenDef) -> Array<crate::lower::model::Do>>
    };
    let entries_f7 = {
        let at_build_p1 = *at_build_p1;
        let wx_p2 = wx_p2.clone();
        let recv_p3 = recv_p3.clone();
        Rc::new(move |k_ph: &Nat| if at_build_p1 {
            each(&filter(&wx_p2.places, &(|pl_pi: &crate::lower::node_::Place| ((&pl_pi.pos.scope == k_ph) && (&pl_pi.entry != &Text::lit(""))) && (&pl_pi.getter != &Text::lit("")))), &(|pl_pj: &crate::lower::node_::Place| entry_take(&recv_p3, pl_pj)))
        } else {
            Array::new()
        }) as Rc<dyn Fn(&Nat) -> Array<crate::lower::model::Do>>
    };
    fold(&crate::check::errors::range0(&(&len(&wx_p2.scopes) + &Nat::from(1u32))), &Array::new(), &(|acc_pk: &Array<crate::lower::model::Do>, i_pl: &Nat| {
        let k_pm = or(&(&len(&wx_p2.scopes)).checked_sub(i_pl), &Nat::from(0u32));
        let builders_pn = fold(&filter(&wx_p2.builders, &(|b_po: &crate::lower::model::ForDef| &b_po.pos.scope == &k_pm)), &Array::new(), &(|a_pp: &Array<crate::lower::model::Do>, b_pq: &crate::lower::model::ForDef| append(a_pp, &(&builder_f5)(b_pq))));
        append(&append(&append(acc_pk, &builders_pn), &fold(&filter(&wx_p2.gens, &(|gd_pr: &crate::lower::model::GenDef| &gd_pr.pos.scope == &k_pm)), &Array::new(), &(|a_ps: &Array<crate::lower::model::Do>, gd_pt: &crate::lower::model::GenDef| append(a_ps, &(&gen_f6)(gd_pt))))), &(&entries_f7)(&k_pm))
    }))
}

/// ```prism
/// EntryTake: fn Ex, Place -> Do
/// ```
pub fn entry_take(recv_p0: &crate::lower::model::Ex, pl_p1: &crate::lower::node_::Place) -> crate::lower::model::Do {
    crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(recv_p0.clone()), pl_p1.entry.clone())), Text::lit("take"), Array::from(vec![crate::lower::model::Ex::XMethod(Rc::new(recv_p0.clone()), pl_p1.getter.clone(), Array::from(vec![crate::lower::model::Ex::XCx])), crate::lower::model::Ex::XCx])))
}

/// ```prism
/// SnapTakeAtBuild: fn SnapDef -> Do
/// ```
pub fn snap_take_at_build(sn_p0: &crate::lower::node_::SnapDef) -> crate::lower::model::Do {
    crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XVar(Text::lit("node"))), Text::from(format!("{}_snap", &sn_p0.name)))), Text::lit("take"), Array::from(vec![crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("node"))), Text::from(format!("{}_now", &sn_p0.name)), Array::from(vec![crate::lower::model::Ex::XCx])), crate::lower::model::Ex::XCx])))
}

/// ```prism
/// SnapTake: fn Sinks, SnapDef -> Do
/// ```
pub fn snap_take(sk_p0: &Sinks, sn_p1: &crate::lower::node_::SnapDef) -> crate::lower::model::Do {
    let now_p2 = crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_now", &sn_p1.name)), Array::from(vec![crate::lower::model::Ex::XCx]));
    let take_p3 = crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_snap", &sn_p1.name)))), if sn_p1.eq { Text::lit("take_compared") } else { Text::lit("take") }, Array::from(vec![now_p2.clone(), crate::lower::model::Ex::XCx])));
    let queue_p4 = crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCx), Text::lit("answer_later"), Array::from(vec![crate::lower::model::Ex::XLater(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("node"))), Text::from(format!("{}_publish", &sn_p1.name)), Array::from(vec![crate::lower::model::Ex::XCx]))))])));
    let queued_p5 = crate::lower::model::Do::DoIf(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_snap", &sn_p1.name)))), Text::lit("queue"), Array::from(vec![crate::lower::model::Ex::XCx])), Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(Text::lit("node")), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XSelf))), queue_p4.clone()]), Array::new());
    crate::lower::model::Do::DoIf(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_snap", &sn_p1.name)))), Text::lit("marked"), Array::from(vec![crate::lower::model::Ex::XCx])), Array::from(vec![take_p3.clone(), queued_p5.clone()]), Array::new())
}

/// ```prism
/// SnapPublish: fn Sinks, SnapDef -> MethDef
/// ```
pub fn snap_publish(sk_p0: &Sinks, sn_p1: &crate::lower::node_::SnapDef) -> crate::lower::model::MethDef {
    crate::lower::model::MethDef { name: Text::from(format!("{}_publish", &sn_p1.name)), recv: crate::lower::model::Recv::RecvRc, params: Array::new(), cx_: crate::lower::model::CxArg::CxMut, ret: crate::lower::model::OutTy::OutUnit, body: Array::from(vec![crate::lower::model::Do::DoIf(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_snap", &sn_p1.name)))), Text::lit("published"), Array::from(vec![crate::lower::model::Ex::XCx])), hold_written(sk_p0, &sn_p1.name), Array::new())]), tail: crate::lower::model::Ex::XUnit, doc: Text::from(format!("{}, published: its snapshot of the tick before moved it, written as a hold is (pick ST).", &sn_p1.what)) }
}

/// ```prism
/// GatheredMoved: fn SnapDef -> MethDef
/// ```
pub fn gathered_moved(sn_p0: &crate::lower::node_::SnapDef) -> crate::lower::model::MethDef {
    crate::lower::model::MethDef { name: Text::from(format!("{}_moved", &sn_p0.name)), recv: crate::lower::model::Recv::RecvRc, params: Array::new(), cx_: crate::lower::model::CxArg::CxMut, ret: crate::lower::model::OutTy::OutUnit, body: Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_snap", &sn_p0.name)))), Text::lit("mark"), Array::from(vec![crate::lower::model::Ex::XCx]))), crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCx), Text::lit("build_later"), Array::from(vec![crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XSelf))])))]), tail: crate::lower::model::Ex::XUnit, doc: Text::lit("A row\'s result moved: the `for`\'s gathered dynamic is marked, and its snapshot taken after the builder (pick ST).") }
}

/// ```prism
/// DocumentGetter: fn Wx -> MethDef
/// ```
pub fn document_getter(wx_p0: &crate::lower::node_::Wx) -> crate::lower::model::MethDef {
    let is_own_f1 = Rc::new(move |p_p3: &crate::lower::model::Pos_| &p_p3.scope == &Nat::from(0u32)) as Rc<dyn Fn(&crate::lower::model::Pos_) -> bool>;
    let body_p2 = document_body(&{
        let f = Rc::new(vec_push);
        Rc::new(move |(a0, a1): (crate::lower::model::Ex, crate::lower::model::Ex)| {
            let f = f.clone();
            once_job(move || prism_rtl::Turn::Finished(f(&a0, &a1)))
        }) as Rc<dyn Fn((crate::lower::model::Ex, crate::lower::model::Ex)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Do>>>
    }, &filter(&wx_p0.places, &(|pl_p4: &crate::lower::node_::Place| (&is_own_f1)(&pl_p4.pos))), &filter(&wx_p0.builders, &(|b_p5: &crate::lower::model::ForDef| (&is_own_f1)(&b_p5.pos))), &filter(&wx_p0.gens, &(|gd_p6: &crate::lower::model::GenDef| (&is_own_f1)(&gd_p6.pos))));
    crate::lower::model::MethDef { name: Text::lit("document"), recv: crate::lower::model::Recv::RecvRef, params: Array::new(), cx_: crate::lower::model::CxArg::CxRef, ret: crate::lower::model::OutTy::OutNamed(Text::lit("Vec"), Array::from(vec![crate::lower::model::OutTy::OutTuple(Array::from(vec![crate::lower::model::OutTy::OutPath, crate::lower::types::entry_ty()]))])), body: append(&Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaMut(Text::lit("doc"))), crate::lower::model::OutTy::OutNamed(Text::lit("Vec"), Array::from(vec![crate::lower::model::OutTy::OutTuple(Array::from(vec![crate::lower::model::OutTy::OutPath, crate::lower::types::entry_ty()]))]))), crate::lower::model::Ex::XCall(Text::lit("Vec::new"), Array::new()))]), &body_p2), tail: crate::lower::model::Ex::XVar(Text::lit("doc")), doc: Text::lit("The row\'s own places, entries of its host\'s document, by their paths relative to the row (pick HO).") }
}

/// ```prism
/// DocumentMoved: fn Text -> MethDef
/// ```
pub fn document_moved(m_p0: &Text) -> crate::lower::model::MethDef {
    crate::lower::model::MethDef { name: Text::lit("document_moved"), recv: crate::lower::model::Recv::RecvRc, params: Array::new(), cx_: crate::lower::model::CxArg::CxMut, ret: crate::lower::model::OutTy::OutUnit, body: Array::from(vec![crate::lower::model::Do::DoIfLet(crate::lower::model::Pa::PaCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("parent"))])), crate::lower::model::Ex::XUpgrade(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::lit("parent")))), Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("parent"))), m_p0.clone(), Array::from(vec![crate::lower::model::Ex::XCx])))]), Array::new())]), tail: crate::lower::model::Ex::XUnit, doc: Text::lit("A place of this row may have moved: its host\'s document moved, and the host\'s readers and rows are marked (pick HO).") }
}

/// ```prism
/// DocumentBody: fn (fn Ex, Ex -> Do), [Place], [ForDef], [GenDef] -> [Do]
/// ```
pub fn document_body(add_f0: &Rc<dyn Fn((crate::lower::model::Ex, crate::lower::model::Ex)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Do>>>, places_p1: &Array<crate::lower::node_::Place>, builders_p2: &Array<crate::lower::model::ForDef>, gens_p3: &Array<crate::lower::model::GenDef>) -> Array<crate::lower::model::Do> {
    let statics_p4 = run_to_end(each_job(places_p1.clone(), {
        let add_f0 = add_f0.clone();
        Rc::new(move |p0: crate::lower::node_::Place| {
            let add_f0 = add_f0.clone();
            entered(once_job(move || {
                let pl_p8 = p0;
                (&add_f0)((crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCall(Text::lit("Path::root"), Array::new())), Text::lit("at"), Array::from(vec![crate::lower::model::Ex::XIndex(pl_p8.pos.at.clone())])), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), pl_p8.entry.clone()))))).cycle()
            }))
        }) as Rc<dyn Fn(crate::lower::node_::Place) -> Rc<dyn prism_rtl::Job<crate::lower::model::Do>>>
    }));
    let row_doc_f5 = Rc::new(move |p0: crate::lower::model::ForDef| entered(once_job(move || {
        let b_p9 = p0;
        if crate::syntax::lexer::chars::has_prefix(&b_p9.row_node, &Text::lit("prism_rtl::HostRow")) {
            prism_rtl::Turn::Finished(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("row"))), Text::lit("entries"), Array::new()))
        } else {
            prism_rtl::Turn::Finished(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("row"))), Text::lit("document"), Array::from(vec![crate::lower::model::Ex::XCx])))
        }
    }))) as Rc<dyn Fn(crate::lower::model::ForDef) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>;
    let rows_p6 = run_to_end(each_job(builders_p2.clone(), {
        let row_doc_f5 = row_doc_f5.clone();
        let add_f0 = add_f0.clone();
        Rc::new(move |p0: crate::lower::model::ForDef| {
            let row_doc_f5 = row_doc_f5.clone();
            let add_f0 = add_f0.clone();
            entered(once_job(move || {
                let b_pa = p0;
                call_value((&row_doc_f5)(b_pa.clone()), move |row_doc_35051: crate::lower::model::Ex| call_value((&add_f0)((crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCall(Text::lit("Path::root"), Array::new())), Text::lit("at"), Array::from(vec![crate::lower::model::Ex::XIndex(b_pa.pos.at.clone())]))), Text::lit("child"), Array::from(vec![crate::lower::model::Ex::XCtor(Text::lit("Segment::Key"), Array::from(vec![crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("k"))), Text::lit("to_pod"), Array::new())]))]))), Text::lit("join"), Array::from(vec![crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XVar(Text::lit("p"))))])), crate::lower::model::Ex::XVar(Text::lit("e")))), move |add_35065: crate::lower::model::Do| prism_rtl::Turn::Finished(crate::lower::model::Do::DoFor(crate::lower::model::Pa::PaTuple(Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("k")), crate::lower::model::Pa::PaBind(Text::lit("row"))])), crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), b_pa.name.clone())), Text::lit("borrow"), Array::new())), Text::lit("iter"), Array::new()), Array::from(vec![crate::lower::model::Do::DoFor(crate::lower::model::Pa::PaTuple(Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("p")), crate::lower::model::Pa::PaBind(Text::lit("e"))])), row_doc_35051, Array::from(vec![add_35065]))])))))
            }))
        }) as Rc<dyn Fn(crate::lower::model::ForDef) -> Rc<dyn prism_rtl::Job<crate::lower::model::Do>>>
    }));
    let generations_p7 = run_to_end(each_job(gens_p3.clone(), {
        let add_f0 = add_f0.clone();
        Rc::new(move |p0: crate::lower::model::GenDef| {
            let add_f0 = add_f0.clone();
            entered(once_job(move || {
                let gd_pb = p0;
                call_value((&add_f0)((crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCall(Text::lit("Path::root"), Array::new())), Text::lit("at"), Array::from(vec![crate::lower::model::Ex::XIndex(gd_pb.pos.at.clone())]))), Text::lit("child"), Array::from(vec![crate::lower::model::Ex::XCtor(Text::lit("Segment::Gen"), Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("g"))]))]))), Text::lit("join"), Array::from(vec![crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XVar(Text::lit("p"))))])), crate::lower::model::Ex::XVar(Text::lit("e")))), move |add_35637: crate::lower::model::Do| prism_rtl::Turn::Finished(crate::lower::model::Do::DoIfLet(crate::lower::model::Pa::PaCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("row"))])), crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), gd_pb.name.clone())), Text::lit("borrow"), Array::new())), Text::lit("as_ref"), Array::new()), Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(Text::lit("g")), crate::lower::model::Ex::XBin(Text::lit("-"), Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_count", &gd_pb.name)))), Text::lit("get"), Array::new())), Rc::new(crate::lower::model::Ex::XIndex(Nat::from(1u32))))), crate::lower::model::Do::DoFor(crate::lower::model::Pa::PaTuple(Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("p")), crate::lower::model::Pa::PaBind(Text::lit("e"))])), crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("row"))), Text::lit("document"), Array::from(vec![crate::lower::model::Ex::XCx])), Array::from(vec![add_35637]))]), Array::new())))
            }))
        }) as Rc<dyn Fn(crate::lower::model::GenDef) -> Rc<dyn prism_rtl::Job<crate::lower::model::Do>>>
    }));
    append(&append(&statics_p4, &rows_p6), &generations_p7)
}

/// ```prism
/// MapInsert: fn Ex, Ex -> Do
/// ```
pub fn map_insert(path_p0: &crate::lower::model::Ex, e_p1: &crate::lower::model::Ex) -> crate::lower::model::Do {
    crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("doc"))), Text::lit("insert"), Array::from(vec![path_p0.clone(), e_p1.clone()])))
}

/// ```prism
/// VecPush: fn Ex, Ex -> Do
/// ```
pub fn vec_push(path_p0: &crate::lower::model::Ex, e_p1: &crate::lower::model::Ex) -> crate::lower::model::Do {
    crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("doc"))), Text::lit("push"), Array::from(vec![crate::lower::model::Ex::XTuple(Array::from(vec![path_p0.clone(), e_p1.clone()]))])))
}

/// ```prism
/// DynAnswerArm: fn Sinks, Pos, Text, OutTy -> ((Pa, Ex))
/// ```
pub fn dyn_answer_arm(sk_p0: &Sinks, pos_p1: &crate::lower::model::Pos_, f_p2: &Text, t_p3: &crate::lower::model::OutTy) -> (crate::lower::model::Pa, crate::lower::model::Ex) {
    (pos_pat(pos_p1, &Array::new()), crate::lower::model::Ex::XBlock(dyn_place_write(sk_p0, f_p2, &crate::lower::model::Ex::XDecode(t_p3.clone(), Rc::new(crate::lower::model::Ex::XVar(Text::lit("v"))))), Rc::new(crate::lower::model::Ex::XUnit)))
}

/// ```prism
/// DynPlaceWrite: fn Sinks, Text, Ex -> [Do]
/// ```
pub fn dyn_place_write(sk_p0: &Sinks, f_p1: &Text, value_p2: &crate::lower::model::Ex) -> Array<crate::lower::model::Do> {
    append(&Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", f_p1)))), Text::lit("set"), Array::from(vec![value_p2.clone(), crate::lower::model::Ex::XCx])))]), &hold_written(sk_p0, f_p1))
}

/// ```prism
/// UpdatedGaps: fn Wx, [Gn], Bool -> [Do]
/// ```
pub fn updated_gaps(wx_p0: &crate::lower::node_::Wx, gns_p1: &Array<crate::lower::node_::Gn>, is_gen_p2: &bool) -> Array<crate::lower::model::Do> {
    let holds_p3 = fold(&wx_p0.fields, &Array::new(), &(|acc_p7: &Array<Text>, (f_p8, t_p9, _): &(Text, crate::lower::model::OutTy, Text)| if is_hold(t_p9) { push(acc_p7, f_p8) } else { acc_p7.clone() }));
    let derived_p4 = keys(&wx_p0.dyn_reads);
    let roots_p5 = snap_names(wx_p0);
    let own_p6 = fold(&filter(gns_p1, &(|g_pa: &crate::lower::node_::Gn| &g_pa.kind == &crate::lower::node_::GnKind::GnUpdated)), &Array::new(), &(|acc_pb: &Array<crate::lower::model::Do>, g_pc: &crate::lower::node_::Gn| fold(&g_pc.reads, acc_pb, &(|a_pd: &Array<crate::lower::model::Do>, r_pe: &crate::lower::node_::Read| match r_pe {
        crate::lower::node_::Read::ParentRead(f_pf) => if *is_gen_p2 {
            push(a_pd, &crate::lower::expr::refusal_do(&Text::from(format!("`!Updated` of a dynamic in a generation that reads its block\'s `{}`, which the block does not tell a generation of (gap DY)", f_pf))))
        } else {
            a_pd.clone()
        },
        crate::lower::node_::Read::OwnRead(f_pg) => if (crate::check::types::has_text(&holds_p3, f_pg) || crate::check::types::has_text(&derived_p4, f_pg)) || crate::check::types::has_text(&roots_p5, f_pg) {
            a_pd.clone()
        } else {
            push(a_pd, &crate::lower::expr::refusal_do(&Text::from(format!("`!Updated` of a dynamic that reads `{}`, which no sink of this node writes (no height for its event)", f_pg))))
        },
    }))));
    fold(&wx_p0.pending, &own_p6, &(|acc_ph: &Array<crate::lower::model::Do>, p_pi: &crate::lower::node_::PendingRow| fold(&updated_hears(&p_pi.wx), acc_ph, &(|a_pj: &Array<crate::lower::model::Do>, m_pk: &Text| {
        let behind_pl = reads_closed(&wx_p0.dyn_reads, &Array::from(vec![crate::lower::node_::Read::OwnRead(m_pk.clone())]));
        let written_pm = fold(&behind_pl, &false, &(|w_pn: &bool, r_po: &crate::lower::node_::Read| *w_pn || match r_po {
            crate::lower::node_::Read::OwnRead(h_pp) => crate::check::types::has_text(&holds_p3, h_pp),
            crate::lower::node_::Read::ParentRead(_) => true,
        }));
        if crate::check::types::has_text(&roots_p5, m_pk) || reaches_snap(&roots_p5, &behind_pl) {
            push(a_pj, &crate::lower::expr::refusal_do(&Text::from(format!("`!Updated` of a dynamic in a row that reads its block\'s `{}`, a structural dynamic the block publishes at the start of a tick, not lowered for a row\'s `!Updated` (gap SU)", m_pk))))
        } else {
            if written_pm || crate::check::types::has_text(&derived_p4, m_pk) {
                a_pj.clone()
            } else {
                push(a_pj, &crate::lower::expr::refusal_do(&Text::from(format!("`!Updated` of a dynamic in a row that reads its block\'s `{}`, which no sink of the block writes (no height for its event)", m_pk))))
            }
        }
    }))))
}

/// ```prism
/// FinishPending: unbounded fn Wx, [Gn] -> (([NodeDef], [Gn]))
/// ```
pub fn finish_pending(wx_p0: &crate::lower::node_::Wx, gns_p1: &Array<crate::lower::node_::Gn>) -> (Array<crate::lower::model::NodeDef>, Array<crate::lower::node_::Gn>) {
    run_to_end(fold_job(wx_p0.pending.clone(), (Array::new(), gns_p1.clone()), {
        let wx_p0 = wx_p0.clone();
        Rc::new(move |(p0, p1): ((Array<crate::lower::model::NodeDef>, Array<crate::lower::node_::Gn>), crate::lower::node_::PendingRow)| {
            let wx_p0 = wx_p0.clone();
            entered(once_job(move || {
                let (defs_p2, cur_p3) = p0;
                let p_p4 = p1;
                {
                    let floors_p5 = fold(&row_hears(&p_p4.wx), &Map::new(), &(|acc_p9: &Map<Text, Nat>, m_pa: &Text| insert(acc_p9, m_pa, &parent_floor(&wx_p0, &cur_p3, &Array::from(vec![crate::lower::node_::Read::ParentRead(m_pa.clone())])))));
                    let floored_p6 = {
                        let mut this: crate::lower::node_::Wx = p_p4.wx.clone();
                        this.floors = floors_p5.clone();
                        this.gns = each(&this.gns, &(|g_pb: &crate::lower::node_::Gn| if &g_pb.kind == &crate::lower::node_::GnKind::GnUpdated {
                            with_floor(g_pb, &parent_floor(&wx_p0, &cur_p3, &reads_closed(&p_p4.wx.dyn_reads, &g_pb.reads)))
                        } else {
                            g_pb.clone()
                        }));
                        this
                    };
                    call_then(start_finish_node(floored_p6.clone(), p_p4.qk.clone(), p_p4.params.clone(), true), move |finish_node_39907: crate::lower::model::NodeDef| {
                        let def_p7 = finish_node_39907;
                        let next_p8 = match &p_p4.gather {
                            Some(gid_pc) => each(&cur_p3, &(|g_pd: &crate::lower::node_::Gn| if &g_pd.id == gid_pc {
                                with_height(g_pd, &(&def_p7.top + &Nat::from(1u32)))
                            } else {
                                g_pd.clone()
                            })),
                            None => cur_p3.clone(),
                        };
                        prism_rtl::Turn::Finished((push(&defs_p2, &def_p7), next_p8.clone()))
                    })
                }
            }))
        }) as Rc<dyn Fn(((Array<crate::lower::model::NodeDef>, Array<crate::lower::node_::Gn>), crate::lower::node_::PendingRow)) -> Rc<dyn prism_rtl::Job<(Array<crate::lower::model::NodeDef>, Array<crate::lower::node_::Gn>)>>>
    }))
}

/// The step machine of `FinishPending`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FinishPending: unbounded fn Wx, [Gn] -> (([NodeDef], [Gn]))
/// ```
pub struct FinishPending {
    pub wx_p0: crate::lower::node_::Wx,
    pub gns_p1: Array<crate::lower::node_::Gn>,
}

impl prism_rtl::Job<(Array<crate::lower::model::NodeDef>, Array<crate::lower::node_::Gn>)> for FinishPending {
    fn cycle(&self) -> prism_rtl::Turn<(Array<crate::lower::model::NodeDef>, Array<crate::lower::node_::Gn>)> {
        let wx_p0 = &self.wx_p0;
        let gns_p1 = &self.gns_p1;
        fold_job(wx_p0.pending.clone(), (Array::new(), gns_p1.clone()), {
            let wx_p0 = wx_p0.clone();
            Rc::new(move |(p0, p1): ((Array<crate::lower::model::NodeDef>, Array<crate::lower::node_::Gn>), crate::lower::node_::PendingRow)| {
                let wx_p0 = wx_p0.clone();
                entered(once_job(move || {
                    let (defs_p2, cur_p3) = p0;
                    let p_p4 = p1;
                    {
                        let floors_p5 = fold(&row_hears(&p_p4.wx), &Map::new(), &(|acc_p9: &Map<Text, Nat>, m_pa: &Text| insert(acc_p9, m_pa, &parent_floor(&wx_p0, &cur_p3, &Array::from(vec![crate::lower::node_::Read::ParentRead(m_pa.clone())])))));
                        let floored_p6 = {
                            let mut this: crate::lower::node_::Wx = p_p4.wx.clone();
                            this.floors = floors_p5.clone();
                            this.gns = each(&this.gns, &(|g_pb: &crate::lower::node_::Gn| if &g_pb.kind == &crate::lower::node_::GnKind::GnUpdated {
                                with_floor(g_pb, &parent_floor(&wx_p0, &cur_p3, &reads_closed(&p_p4.wx.dyn_reads, &g_pb.reads)))
                            } else {
                                g_pb.clone()
                            }));
                            this
                        };
                        call_then(start_finish_node(floored_p6.clone(), p_p4.qk.clone(), p_p4.params.clone(), true), move |finish_node_39907: crate::lower::model::NodeDef| {
                            let def_p7 = finish_node_39907;
                            let next_p8 = match &p_p4.gather {
                                Some(gid_pc) => each(&cur_p3, &(|g_pd: &crate::lower::node_::Gn| if &g_pd.id == gid_pc {
                                    with_height(g_pd, &(&def_p7.top + &Nat::from(1u32)))
                                } else {
                                    g_pd.clone()
                                })),
                                None => cur_p3.clone(),
                            };
                            prism_rtl::Turn::Finished((push(&defs_p2, &def_p7), next_p8.clone()))
                        })
                    }
                }))
            }) as Rc<dyn Fn(((Array<crate::lower::model::NodeDef>, Array<crate::lower::node_::Gn>), crate::lower::node_::PendingRow)) -> Rc<dyn prism_rtl::Job<(Array<crate::lower::model::NodeDef>, Array<crate::lower::node_::Gn>)>>>
        }).cycle()
    }
}

/// `Start FinishPending, x`: what the function value is when passed to `@Run`.
pub fn start_finish_pending(wx_p0: crate::lower::node_::Wx, gns_p1: Array<crate::lower::node_::Gn>) -> Rc<dyn prism_rtl::Job<(Array<crate::lower::model::NodeDef>, Array<crate::lower::node_::Gn>)>> {
    Rc::new(FinishPending { wx_p0, gns_p1 })
}

/// ```prism
/// ParentFloor: fn Wx, [Gn], [Read] -> Nat
/// ```
pub fn parent_floor(wx_p0: &crate::lower::node_::Wx, gns_p1: &Array<crate::lower::node_::Gn>, reads_p2: &Array<crate::lower::node_::Read>) -> Nat {
    fold(reads_p2, &Nat::from(0u32), &(|hi_p3: &Nat, r_p4: &crate::lower::node_::Read| match r_p4 {
        crate::lower::node_::Read::ParentRead(m_p5) => fold(&reads_closed(&wx_p0.dyn_reads, &Array::from(vec![crate::lower::node_::Read::OwnRead(m_p5.clone())])), hi_p3, &(|h2_p6: &Nat, hr_p7: &crate::lower::node_::Read| match hr_p7 {
            crate::lower::node_::Read::OwnRead(f_p8) => fold(gns_p1, h2_p6, &(|h3_p9: &Nat, g_pa: &crate::lower::node_::Gn| if writes_hold(g_pa, f_p8) {
                max(h3_p9, &(&g_pa.height + &Nat::from(1u32)))
            } else {
                h3_p9.clone()
            })),
            crate::lower::node_::Read::ParentRead(up_pb) => max(h2_p6, &or(&get(&wx_p0.floors, up_pb), &Nat::from(0u32))),
        })),
        crate::lower::node_::Read::OwnRead(_) => hi_p3.clone(),
    }))
}

/// ```prism
/// WritesHold: fn Gn, Text -> Bool
/// ```
pub fn writes_hold(g_p0: &crate::lower::node_::Gn, f_p1: &Text) -> bool {
    fold(&g_p0.outs, &false, &(|acc_p2: &bool, o_p3: &crate::lower::node_::Out| *acc_p2 || sink_writes_hold(&o_p3.sink, f_p1)))
}

/// ```prism
/// SinkWritesHold: fn Sk, Text -> Bool
/// ```
pub fn sink_writes_hold(sk0: &crate::lower::node_::Sk, f_p1: &Text) -> bool {
    match sk0 {
        crate::lower::node_::Sk::SkHold(h_p0) => h_p0 == f_p1,
        crate::lower::node_::Sk::SkDistinct(h_p2) => h_p2 == f_p1,
        crate::lower::node_::Sk::SkPerKey(h_p4) => h_p4 == f_p1,
        crate::lower::node_::Sk::SkMachine(h_p6, _, _) => h_p6 == f_p1,
        other_p8 => false,
    }
}

/// ```prism
/// WithFloor: fn Gn, Nat -> Gn
/// ```
pub fn with_floor(g_p0: &crate::lower::node_::Gn, h_p1: &Nat) -> crate::lower::node_::Gn {
    let mut this: crate::lower::node_::Gn = g_p0.clone();
    this.floor = h_p1.clone();
    this
}

/// ```prism
/// WithHeight: fn Gn, Nat -> Gn
/// ```
pub fn with_height(g_p0: &crate::lower::node_::Gn, h_p1: &Nat) -> crate::lower::node_::Gn {
    let mut this: crate::lower::node_::Gn = g_p0.clone();
    this.height = h_p1.clone();
    this
}

/// ```prism
/// RowHears: fn Wx -> [Text]
/// ```
pub fn row_hears(wx_p0: &crate::lower::node_::Wx) -> Array<Text> {
    let from_updated_p1 = fold(&filter(&wx_p0.gns, &(|g_p5: &crate::lower::node_::Gn| &g_p5.kind == &crate::lower::node_::GnKind::GnUpdated)), &Array::new(), &(|acc_p6: &Array<crate::lower::node_::Read>, g_p7: &crate::lower::node_::Gn| crate::lower::node_::union_reads(acc_p6, &reads_closed(&wx_p0.dyn_reads, &g_p7.reads))));
    let from_rows_p2 = fold(&wx_p0.row_marks, &Array::new(), &(|acc_p8: &Array<crate::lower::node_::Read>, rm_p9: &crate::lower::node_::RowMarks| crate::lower::node_::union_reads(acc_p8, &reads_closed(&wx_p0.dyn_reads, &append(&rm_p9.reads, &each(&rm_p9.wrote, &(|m_pa: &Text| crate::lower::node_::Read::OwnRead(m_pa.clone()))))))));
    let from_builds_p3 = reads_closed(&wx_p0.dyn_reads, &wx_p0.build_holds);
    let from_gens_p4 = fold(&wx_p0.gen_holds, &Array::new(), &(|acc_pb: &Array<crate::lower::node_::Read>, (_, hs_pc): &(Text, Array<crate::lower::node_::Read>)| crate::lower::node_::union_reads(acc_pb, &reads_closed(&wx_p0.dyn_reads, hs_pc))));
    fold(&crate::lower::node_::union_reads(&crate::lower::node_::union_reads(&crate::lower::node_::union_reads(&from_updated_p1, &from_rows_p2), &from_builds_p3), &from_gens_p4), &Array::new(), &(|acc_pd: &Array<Text>, r_pe: &crate::lower::node_::Read| match r_pe {
        crate::lower::node_::Read::ParentRead(m_pf) => crate::check::types::add_text(acc_pd, m_pf),
        crate::lower::node_::Read::OwnRead(_) => acc_pd.clone(),
    }))
}

/// ```prism
/// UpdatedHears: fn Wx -> [Text]
/// ```
pub fn updated_hears(wx_p0: &crate::lower::node_::Wx) -> Array<Text> {
    fold(&filter(&wx_p0.gns, &(|g_p1: &crate::lower::node_::Gn| &g_p1.kind == &crate::lower::node_::GnKind::GnUpdated)), &Array::new(), &(|acc_p2: &Array<Text>, g_p3: &crate::lower::node_::Gn| fold(&reads_closed(&wx_p0.dyn_reads, &g_p3.reads), acc_p2, &(|a_p4: &Array<Text>, r_p5: &crate::lower::node_::Read| match r_p5 {
        crate::lower::node_::Read::ParentRead(m_p6) => crate::check::types::add_text(a_p4, m_p6),
        crate::lower::node_::Read::OwnRead(_) => a_p4.clone(),
    }))))
}

/// ```prism
/// RowWritten: fn Wx, RowMarks, Read -> [Do]
/// ```
pub fn row_written(wx_p0: &crate::lower::node_::Wx, rm_p1: &crate::lower::node_::RowMarks, r_p2: &crate::lower::node_::Read) -> Array<crate::lower::model::Do> {
    let dirty_p3 = if crate::lower::node_::has_read(&reads_closed(&wx_p0.dyn_reads, &rm_p1.reads), r_p2) {
        Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCx), Text::lit("dirty"), Array::from(vec![crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(Text::lit("row"))))])))])
    } else {
        Array::new()
    };
    let told_p4 = fold(&rm_p1.wrote, &Array::new(), &(|acc_p6: &Array<crate::lower::model::Do>, m_p7: &Text| if crate::lower::node_::has_read(&reads_closed(&wx_p0.dyn_reads, &Array::from(vec![crate::lower::node_::Read::OwnRead(m_p7.clone())])), r_p2) {
        push(acc_p6, &crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("row"))), Text::from(format!("parent_wrote_{}", m_p7)), Array::from(vec![crate::lower::model::Ex::XCx]))))
    } else {
        acc_p6.clone()
    }));
    let body_p5 = append(&dirty_p3, &told_p4);
    if &len(&body_p5) == &Nat::from(0u32) {
        Array::new()
    } else {
        match &rm_p1.kind {
            crate::lower::model::RowKind::GenerationRow => Array::from(vec![crate::lower::model::Do::DoIfLet(crate::lower::model::Pa::PaCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("row"))])), crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), rm_p1.builder.clone())), Text::lit("borrow"), Array::new())), Text::lit("as_ref"), Array::new()), body_p5.clone(), Array::new())]),
            _ => Array::from(vec![crate::lower::model::Do::DoFor(crate::lower::model::Pa::PaBind(Text::lit("row")), crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), rm_p1.builder.clone())), Text::lit("borrow"), Array::new())), Text::lit("values"), Array::new()), body_p5.clone())]),
        }
    }
}

/// ```prism
/// PatchPlace: fn Wx, Place -> [Do]
/// ```
pub fn patch_place(wx_p0: &crate::lower::node_::Wx, p_p1: &crate::lower::node_::Place) -> Array<crate::lower::model::Do> {
    let pull_p2 = crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(p_p1.getter.clone()), crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XSelf), p_p1.getter.clone(), Array::from(vec![crate::lower::model::Ex::XCx])));
    let at_p3 = place_at(wx_p0, &Text::lit("self"), &p_p1.pos);
    let sent_p4 = crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCx), Text::lit("changed"), Array::from(vec![at_p3.clone(), crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(p_p1.getter.clone())), Text::lit("level_pod"), Array::from(vec![crate::lower::model::Ex::XCx]))])));
    let renew_p5 = if &p_p1.watch == &Text::lit("") {
        Array::new()
    } else {
        Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), p_p1.watch.clone())), Text::lit("renew"), Array::from(vec![crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XVar(p_p1.getter.clone()))), crate::lower::model::Ex::XCast(Rc::new(crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XSelf))), crate::lower::model::OutTy::OutObj(Rc::new(crate::lower::model::OutTy::OutNamed(Text::lit("Node"), Array::new())))), crate::lower::model::Ex::XCx])))])
    };
    append(&Array::from(vec![pull_p2.clone(), sent_p4.clone()]), &renew_p5)
}

/// ```prism
/// Emits: fn Wx, Pos -> Bool
/// ```
pub fn emits(wx_p0: &crate::lower::node_::Wx, pos_p1: &crate::lower::model::Pos_) -> bool {
    (&pos_p1.scope == &Nat::from(0u32)) && (&wx_p0.hosted_by == &None)
}

/// ```prism
/// ResultTold: fn Ex -> [Do]
/// ```
pub fn result_told(node_p0: &crate::lower::model::Ex) -> Array<crate::lower::model::Do> {
    let r_p1 = crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(Text::lit("r")), crate::lower::model::Ex::XMethod(Rc::new(node_p0.clone()), Text::lit("result_value"), Array::from(vec![crate::lower::model::Ex::XCx])));
    Array::from(vec![r_p1.clone(), result_kept(node_p0), result_tell()])
}

/// ```prism
/// ResultMoved: fn Ex -> [Do]
/// ```
pub fn result_moved(node_p0: &crate::lower::model::Ex) -> Array<crate::lower::model::Do> {
    let r_p1 = crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(Text::lit("r")), crate::lower::model::Ex::XMethod(Rc::new(node_p0.clone()), Text::lit("result_value"), Array::from(vec![crate::lower::model::Ex::XCx])));
    let last_p2 = crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(node_p0.clone()), Text::lit("result_last"))), Text::lit("borrow"), Array::new())), Text::lit("as_ref"), Array::new());
    let differs_p3 = crate::lower::model::Ex::XBin(Text::lit("!="), Rc::new(last_p2.clone()), Rc::new(crate::lower::model::Ex::XCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XVar(Text::lit("r"))))]))));
    Array::from(vec![r_p1.clone(), crate::lower::model::Do::DoIf(differs_p3.clone(), Array::from(vec![result_kept(node_p0), result_tell()]), Array::new())])
}

/// ```prism
/// ResultKept: fn Ex -> Do
/// ```
pub fn result_kept(node_p0: &crate::lower::model::Ex) -> crate::lower::model::Do {
    crate::lower::model::Do::DoAssign(crate::lower::model::Ex::XDeref(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(node_p0.clone()), Text::lit("result_last"))), Text::lit("borrow_mut"), Array::new()))), crate::lower::model::Ex::XCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(Text::lit("r"))))])))
}

/// ```prism
/// let resultTell
/// ```
pub fn result_tell() -> crate::lower::model::Do {
    crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCx), Text::lit("result"), Array::from(vec![crate::lower::model::Ex::XCtor(Text::lit("Outcome::Value"), Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("r"))]))])))
}

/// ```prism
/// Adoption: fn FlatDef -> [Do]
/// ```
pub fn adoption(fl_p0: &crate::lower::node_::FlatDef) -> Array<crate::lower::model::Do> {
    let adopt_p1 = crate::lower::model::Ex::XLater(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("node"))), Text::from(format!("{}_adopt", &fl_p0.name)), Array::from(vec![crate::lower::model::Ex::XCx]))));
    Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(Text::lit("node")), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XSelf))), crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCx), Text::lit("answer_later"), Array::from(vec![adopt_p1.clone()])))])
}

/// ```prism
/// PlaceAt: fn Wx, Text, Pos -> Ex
/// ```
pub fn place_at(wx_p0: &crate::lower::node_::Wx, recv_p1: &Text, pos_p2: &crate::lower::model::Pos_) -> crate::lower::model::Ex {
    let at_p3 = Array::from(vec![crate::lower::model::Ex::XIndex(pos_p2.at.clone())]);
    if emits(wx_p0, pos_p2) {
        crate::lower::model::Ex::XMethod(Rc::new(if recv_p1 == &Text::lit("") {
            crate::lower::model::Ex::XVar(Text::lit("path"))
        } else {
            if recv_p1 == &Text::lit("self") {
                crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::lit("path"))
            } else {
                crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XVar(recv_p1.clone())), Text::lit("path"))
            }
        }), Text::lit("at"), at_p3.clone())
    } else {
        crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCall(Text::lit("Path::root"), Array::new())), Text::lit("at"), at_p3.clone())
    }
}

/// ```prism
/// PosPat: fn Pos, [Pa] -> Pa
/// ```
pub fn pos_pat(pos_p0: &crate::lower::model::Pos_, tail_p1: &Array<crate::lower::model::Pa>) -> crate::lower::model::Pa {
    crate::lower::model::Pa::PaSlice(append(&Array::from(vec![crate::lower::model::Pa::PaCtor(Text::lit("Segment::Pos"), Array::from(vec![crate::lower::model::Pa::PaIndex(pos_p0.at.clone())]))]), tail_p1))
}

/// ```prism
/// let keyTail
/// ```
pub fn key_tail() -> Array<crate::lower::model::Pa> {
    Array::from(vec![crate::lower::model::Pa::PaCtor(Text::lit("Segment::Key"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("k"))])), crate::lower::model::Pa::PaRest(Text::lit("rest"))])
}

/// ```prism
/// let genTail
/// ```
pub fn gen_tail() -> Array<crate::lower::model::Pa> {
    Array::from(vec![crate::lower::model::Pa::PaCtor(Text::lit("Segment::Gen"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("g"))])), crate::lower::model::Pa::PaRest(Text::lit("rest"))])
}

/// ```prism
/// ?HostedRows: fn Wx -> ?Text
/// ```
pub fn hosted_rows(wx_p0: &crate::lower::node_::Wx) -> Option<Text> {
    if &wx_p0.pos.scope > &Nat::from(0u32) {
        Some(Text::from(format!("{}_moved", &or(&index(&wx_p0.scopes, &crate::syntax::lexer::chars::dec(&wx_p0.pos.scope)), &Text::lit("")))))
    } else {
        match &wx_p0.hosted_by {
            Some(_) => Some(Text::lit("document_moved")),
            None => None,
        }
    }
}

/// ```prism
/// RootDynPatch: fn Wx -> [Do]
/// ```
pub fn root_dyn_patch(wx_p0: &crate::lower::node_::Wx) -> Array<crate::lower::model::Do> {
    match &wx_p0.root_dyn {
        Some(_) => Array::from(vec![crate::lower::model::Do::DoLine(result_moved(&crate::lower::model::Ex::XSelf))]),
        None => Array::new(),
    }
}

/// ```prism
/// AnswerArm: fn Wx, Pos, Nat, OutTy -> ((Pa, Ex))
/// ```
pub fn answer_arm(wx_p0: &crate::lower::node_::Wx, pos_p1: &crate::lower::model::Pos_, id_p2: &Nat, t_p3: &crate::lower::model::OutTy) -> (crate::lower::model::Pa, crate::lower::model::Ex) {
    let call_p4 = crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XSelf), crate::lower::node_::gn_of(wx_p0, id_p2).name.clone(), Array::from(vec![crate::lower::model::Ex::XDecode(t_p3.clone(), Rc::new(crate::lower::model::Ex::XVar(Text::lit("v")))), crate::lower::model::Ex::XCx]));
    (pos_pat(pos_p1, &Array::new()), call_p4.clone())
}

/// ```prism
/// TypedAnswerArm: fn Wx, Pos, Nat, Text -> ((Pa, [Do]))
/// ```
pub fn typed_answer_arm(wx_p0: &crate::lower::node_::Wx, pos_p1: &crate::lower::model::Pos_, id_p2: &Nat, acc_p3: &Text) -> (crate::lower::model::Pa, Array<crate::lower::model::Do>) {
    (pos_pat(pos_p1, &Array::new()), Array::from(vec![self_call(&crate::lower::node_::gn_of(wx_p0, id_p2).name, &Array::from(vec![crate::lower::expr::try_of(&crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("v"))), acc_p3.clone(), Array::new()))]))]))
}

/// ```prism
/// TypedDynArm: fn Sinks, Pos, Text, Text -> ((Pa, [Do]))
/// ```
pub fn typed_dyn_arm(sk_p0: &Sinks, pos_p1: &crate::lower::model::Pos_, f_p2: &Text, acc_p3: &Text) -> (crate::lower::model::Pa, Array<crate::lower::model::Do>) {
    (pos_pat(pos_p1, &Array::new()), dyn_place_write(sk_p0, f_p2, &crate::lower::expr::try_of(&crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("v"))), acc_p3.clone(), Array::new()))))
}

/// ```prism
/// TypedForwardArm: fn ForDef, Ex -> ((Pa, [Do]))
/// ```
pub fn typed_forward_arm(b_p0: &crate::lower::model::ForDef, segs_p1: &crate::lower::model::Ex) -> (crate::lower::model::Pa, Array<crate::lower::model::Do>) {
    let row_of_p2 = crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", &b_p0.name)))), Text::lit("borrow"), Array::new())), Text::lit("get"), Array::from(vec![crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XDecode(b_p0.key_ty.clone(), Rc::new(crate::lower::model::Ex::XVar(Text::lit("k"))))))]))), Text::lit("cloned"), Array::new());
    (pos_pat(&b_p0.pos, &key_tail()), Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(Text::lit("row")), row_of_p2.clone()), crate::lower::model::Do::DoMatch(crate::lower::model::Ex::XVar(Text::lit("row")), Array::from(vec![(crate::lower::model::Pa::PaCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("row"))])), Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::expr::try_of(&crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("row"))), Text::lit("deliver"), Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("rest")), crate::lower::model::Ex::XVar(Text::lit("v")), crate::lower::model::Ex::XCx]))))])), (crate::lower::model::Pa::PaUnit(Text::lit("None")), Array::from(vec![crate::lower::model::Do::DoReturn(crate::lower::model::Ex::XCtor(Text::lit("Err"), Array::from(vec![crate::lower::model::Ex::XCall(Text::lit("Fault::answer"), Array::from(vec![crate::lower::model::Ex::XFormatStr(Array::from(vec![crate::lower::model::Ex::XText(Text::lit("no row ")), crate::lower::model::Ex::XVar(Text::lit("k")), crate::lower::model::Ex::XText(Text::lit(" under the hosted place ")), crate::lower::model::Ex::XCtor(Text::lit("Path"), Array::from(vec![crate::lower::model::Ex::XMethod(Rc::new(segs_p1.clone()), Text::lit("to_vec"), Array::new())]))]))]))])))]))]))]))
}

/// ```prism
/// TypedGenArm: fn GenDef -> ((Pa, [Do]))
/// ```
pub fn typed_gen_arm(gd_p0: &crate::lower::model::GenDef) -> (crate::lower::model::Pa, Array<crate::lower::model::Do>) {
    let current_p1 = crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", &gd_p0.name)))), Text::lit("borrow"), Array::new())));
    let is_current_p2 = crate::lower::model::Ex::XBin(Text::lit("=="), Rc::new(crate::lower::model::Ex::XBin(Text::lit("+"), Rc::new(crate::lower::model::Ex::XDeref(Rc::new(crate::lower::model::Ex::XVar(Text::lit("g"))))), Rc::new(crate::lower::model::Ex::XIndex(Nat::from(1u32))))), Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_count", &gd_p0.name)))), Text::lit("get"), Array::new())));
    (pos_pat(&gd_p0.pos, &gen_tail()), Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(Text::lit("row")), current_p1.clone()), crate::lower::model::Do::DoIfLet(crate::lower::model::Pa::PaCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("row"))])), crate::lower::model::Ex::XVar(Text::lit("row")), Array::from(vec![crate::lower::model::Do::DoIf(is_current_p2.clone(), Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::expr::try_of(&crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("row"))), Text::lit("deliver"), Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("rest")), crate::lower::model::Ex::XVar(Text::lit("v")), crate::lower::model::Ex::XCx]))))]), Array::new())]), Array::new())]))
}

/// ```prism
/// TypedDispatch: fn Sinks, Text, Nat -> MethDef
/// ```
pub fn typed_dispatch(sk_p0: &Sinks, name_p1: &Text, scope_p2: &Nat) -> crate::lower::model::MethDef {
    let wx_p3 = sk_p0.wx.clone();
    let in_scope_f4 = {
        let scope_p2 = scope_p2.clone();
        Rc::new(move |p_pb: &crate::lower::model::Pos_| &p_pb.scope == &scope_p2) as Rc<dyn Fn(&crate::lower::model::Pos_) -> bool>
    };
    let (recv_pc, param_pd, segs_pe, doc_pf) = if scope_p2 > &Nat::from(0u32) {
        (crate::lower::model::Recv::RecvRc, (Text::lit("place"), crate::lower::model::OutTy::OutRef(Rc::new(crate::lower::model::OutTy::OutPath))), crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("place"))), Text::lit("segments"), Array::new()), Text::from(format!("The host at place {} answers its child\'s place `place` (pick HO): into the child\'s input method, a hold the place\'s element answers, or the row of a `for` or `rebuild` under it.", &crate::lower::model::place_text(&or(&index(&wx_p3.hosts, &crate::syntax::lexer::chars::dec(scope_p2)), &dummy_host()).pos))))
    } else {
        (crate::lower::model::Recv::RecvOwned, (Text::lit("at"), crate::lower::model::OutTy::OutRef(Rc::new(crate::lower::model::OutTy::OutSlice(Rc::new(crate::lower::model::OutTy::OutNamed(Text::lit("Segment"), Array::new())))))), crate::lower::model::Ex::XVar(Text::lit("at")), Text::lit("A host\'s answer to a place of this row\'s own, `at` under the row (pick HO): into the input method, a hold, or a row under it."))
    };
    let answers_p5 = each(&filter(&wx_p3.answers, &(|(pos_pg, _, _, _): &(crate::lower::model::Pos_, Nat, crate::lower::model::OutTy, Text)| (&in_scope_f4)(pos_pg))), &(|(pos_ph, id_pi, _, acc_pj): &(crate::lower::model::Pos_, Nat, crate::lower::model::OutTy, Text)| typed_answer_arm(&wx_p3, pos_ph, id_pi, acc_pj)));
    let dyns_p6 = each(&filter(&wx_p3.dyn_places, &(|(pos_pk, _, _, _): &(crate::lower::model::Pos_, Text, crate::lower::model::OutTy, Text)| (&in_scope_f4)(pos_pk))), &(|(pos_pl, f_pm, _, acc_pn): &(crate::lower::model::Pos_, Text, crate::lower::model::OutTy, Text)| typed_dyn_arm(sk_p0, pos_pl, f_pm, acc_pn)));
    let rows_p7 = each(&filter(&wx_p3.builders, &(|b_po: &crate::lower::model::ForDef| (&in_scope_f4)(&b_po.pos))), &(|b_pp: &crate::lower::model::ForDef| typed_forward_arm(b_pp, &segs_pe)));
    let gens_p8 = each(&filter(&wx_p3.gens, &(|gd_pq: &crate::lower::model::GenDef| (&in_scope_f4)(&gd_pq.pos))), &(|gd_pr: &crate::lower::model::GenDef| typed_gen_arm(gd_pr)));
    let none_p9 = (crate::lower::model::Pa::PaWild, Array::from(vec![crate::lower::model::Do::DoReturn(crate::lower::model::Ex::XCtor(Text::lit("Err"), Array::from(vec![crate::lower::model::Ex::XCall(Text::lit("Fault::answer"), Array::from(vec![crate::lower::model::Ex::XFormatStr(Array::from(vec![crate::lower::model::Ex::XText(Text::lit("no hosted place at ")), crate::lower::model::Ex::XCtor(Text::lit("Path"), Array::from(vec![crate::lower::model::Ex::XMethod(Rc::new(segs_pe.clone()), Text::lit("to_vec"), Array::new())])), crate::lower::model::Ex::XText(Text::lit(" to answer"))]))]))])))]));
    let arms_pa = push(&append(&append(&append(&answers_p5, &dyns_p6), &rows_p7), &gens_p8), &none_p9);
    crate::lower::model::MethDef { name: name_p1.clone(), recv: recv_pc.clone(), params: Array::from(vec![param_pd.clone(), (Text::lit("v"), crate::lower::model::OutTy::OutRef(Rc::new(crate::lower::types::answer_ty())))]), cx_: crate::lower::model::CxArg::CxMut, ret: crate::lower::model::OutTy::OutNamed(Text::lit("Done"), Array::new()), body: Array::from(vec![crate::lower::model::Do::DoMatch(segs_pe.clone(), arms_pa.clone())]), tail: crate::lower::model::Ex::XCtor(Text::lit("Ok"), Array::from(vec![crate::lower::model::Ex::XUnit])), doc: doc_pf.clone() }
}

/// ```prism
/// let dummyHost
/// ```
pub fn dummy_host() -> crate::lower::node_::HostDef {
    crate::lower::node_::HostDef { pos: crate::lower::model::pos0(), name: Text::lit(""), scope: Nat::from(0u32) }
}

/// ```prism
/// SortNats: fn [Nat] -> [Nat]
/// ```
pub fn sort_nats(xs_p0: &Array<Nat>) -> Array<Nat> {
    fold(xs_p0, &Array::new(), &(|acc_p1: &Array<Nat>, x_p2: &Nat| append(&push(&filter(acc_p1, &(|y_p3: &Nat| y_p3 < x_p2)), x_p2), &filter(acc_p1, &(|y_p4: &Nat| !(y_p4 < x_p2))))))
}

/// ```prism
/// AskWake: fn Sinks, Nat -> [Do]
/// ```
pub fn ask_wake(sk_p0: &Sinks, h_p1: &Nat) -> Array<crate::lower::model::Do> {
    let c_p2 = crate::lower::model::Ex::XConst(wake_const(&sk_p0.heights, h_p1));
    let ask_p3 = crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::lit("wakes"))), Text::lit("ask"), Array::from(vec![c_p2.clone()])));
    let wake_p4 = crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCx), Text::lit("wake"), Array::from(vec![c_p2.clone(), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XSelf))])));
    if sk_p0.many {
        Array::from(vec![ask_p3.clone(), wake_p4.clone()])
    } else {
        Array::from(vec![wake_p4.clone()])
    }
}

/// ```prism
/// GatherIn: fn Sinks, Gn -> MethDef
/// ```
pub fn gather_in(sk_p0: &Sinks, g_p1: &crate::lower::node_::Gn) -> crate::lower::model::MethDef {
    let field_p2 = or(&index(&g_p1.inputs, &Nat::from(0u32)), &Text::lit(""));
    let kt_p3 = match &g_p1.ty {
        crate::lower::model::OutTy::OutMap(k_p8, _) => (**k_p8).clone(),
        _ => crate::lower::model::OutTy::OutUnit,
    };
    let vt_p4 = match &g_p1.ty {
        crate::lower::model::OutTy::OutMap(_, v_p9) => (**v_p9).clone(),
        _ => crate::lower::model::OutTy::OutUnit,
    };
    let current_p5 = crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", &field_p2)))), Text::lit("get"), Array::from(vec![crate::lower::model::Ex::XCx]))), Text::lit("unwrap_or_default"), Array::new());
    let collect_p6 = Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaMut(Text::lit("all")), current_p5.clone()), crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("all"))), Text::lit("insert"), Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("k")), crate::lower::model::Ex::XVar(Text::lit("v"))]))), crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", &field_p2)))), Text::lit("set"), Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("all")), crate::lower::model::Ex::XCx])))]);
    let body_p7 = append(&collect_p6, &ask_wake(sk_p0, &g_p1.height));
    crate::lower::model::MethDef { name: Text::from(format!("{}_in", &g_p1.name)), recv: crate::lower::model::Recv::RecvRc, params: Array::from(vec![(Text::lit("k"), kt_p3.clone()), (Text::lit("v"), vt_p4.clone())]), cx_: crate::lower::model::CxArg::CxMut, ret: crate::lower::model::OutTy::OutUnit, body: body_p7.clone(), tail: crate::lower::model::Ex::XUnit, doc: Text::lit("A row\'s firing, gathered by its key.") }
}

/// ```prism
/// Decide: fn Gn -> Do
/// ```
pub fn decide(g_p0: &crate::lower::node_::Gn) -> crate::lower::model::Do {
    match &g_p0.kind {
        crate::lower::node_::GnKind::GnGather => crate::lower::model::Do::DoIfLet(crate::lower::model::Pa::PaCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("v"))])), crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", &or(&index(&g_p0.inputs, &Nat::from(0u32)), &Text::lit("")))))), Text::lit("take"), Array::from(vec![crate::lower::model::Ex::XCx])), Array::from(vec![self_call(&g_p0.name, &Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("v"))]))]), Array::new()),
        crate::lower::node_::GnKind::GnMerge => merge_decide(g_p0),
        crate::lower::node_::GnKind::GnUpdated => updated_decide(g_p0),
        crate::lower::node_::GnKind::GnMergeAll => {
            let pushes_p1 = each(&g_p0.inputs, &(|f_p4: &Text| crate::lower::model::Do::DoIfLet(crate::lower::model::Pa::PaCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("x"))])), crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", f_p4)))), Text::lit("take"), Array::from(vec![crate::lower::model::Ex::XCx])), Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("all"))), Text::lit("push_back"), Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("x"))])))]), Array::new())));
            let start_p2 = crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaMut(Text::lit("all"))), g_p0.ty.clone()), crate::lower::model::Ex::XCall(Text::lit("Array::new"), Array::new()));
            let fire_p3 = crate::lower::model::Do::DoIf(crate::lower::model::Ex::XUnary(Text::lit("!"), Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("all"))), Text::lit("is_empty"), Array::new()))), Array::from(vec![self_call(&g_p0.name, &Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("all"))]))]), Array::new());
            crate::lower::model::Do::DoBlock(push(&append(&Array::from(vec![start_p2.clone()]), &pushes_p1), &fire_p3))
        },
        kind_p5 => pair_decide(g_p0, kind_p5),
    }
}

/// ```prism
/// UpdatedDecide: fn Gn -> Do
/// ```
pub fn updated_decide(g_p0: &crate::lower::node_::Gn) -> crate::lower::model::Do {
    crate::lower::model::Do::DoIf(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_moved", &g_p0.name)))), Text::lit("replace"), Array::from(vec![crate::lower::model::Ex::XBool(false)])), Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(Text::lit("after")), crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCx), Text::lit("after"), Array::from(vec![crate::lower::model::Ex::XClosure(false, Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("cx"))]), Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_value", &g_p0.name)), Array::from(vec![crate::lower::model::Ex::XCx]))))]))), self_call(&g_p0.name, &Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("after"))]))]), Array::new())
}

/// ```prism
/// PairDecide: fn Gn, GnKind -> Do
/// ```
pub fn pair_decide(g_p0: &crate::lower::node_::Gn, kind_p1: &crate::lower::node_::GnKind) -> crate::lower::model::Do {
    let get_l_p2 = crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", &or(&index(&g_p0.inputs, &Nat::from(0u32)), &Text::lit("")))))), Text::lit("take"), Array::from(vec![crate::lower::model::Ex::XCx]));
    let get_r_p3 = crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", &or(&index(&g_p0.inputs, &Nat::from(1u32)), &Text::lit("")))))), Text::lit("take"), Array::from(vec![crate::lower::model::Ex::XCx]));
    let both_p4 = crate::lower::model::Ex::XTuple(Array::from(vec![get_l_p2.clone(), get_r_p3.clone()]));
    let fire_f5 = {
        let g_p0 = g_p0.clone();
        Rc::new(move |x_pc: &crate::lower::model::Ex| Array::from(vec![self_call(&g_p0.name, &Array::from(vec![x_pc.clone()]))])) as Rc<dyn Fn(&crate::lower::model::Ex) -> Array<crate::lower::model::Do>>
    };
    let sa_p6 = crate::lower::model::Pa::PaCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("a"))]));
    let sb_p7 = crate::lower::model::Pa::PaCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("b"))]));
    let some2_p8 = crate::lower::model::Pa::PaTuple(Array::from(vec![sa_p6.clone(), sb_p7.clone()]));
    let left_p9 = crate::lower::model::Pa::PaTuple(Array::from(vec![sa_p6.clone(), crate::lower::model::Pa::PaUnit(Text::lit("None"))]));
    let right_pa = crate::lower::model::Pa::PaTuple(Array::from(vec![crate::lower::model::Pa::PaUnit(Text::lit("None")), sb_p7.clone()]));
    let cases_pb = match kind_p1 {
        crate::lower::node_::GnKind::GnUnion => Array::from(vec![(some2_p8.clone(), (&fire_f5)(&crate::lower::model::Ex::XCall(Text::lit("union"), Array::from(vec![crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XVar(Text::lit("a")))), crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XVar(Text::lit("b"))))])))), (left_p9.clone(), (&fire_f5)(&crate::lower::model::Ex::XVar(Text::lit("a")))), (right_pa.clone(), (&fire_f5)(&crate::lower::model::Ex::XVar(Text::lit("b")))), (crate::lower::model::Pa::PaWild, Array::new())]),
        crate::lower::node_::GnKind::GnBoth => Array::from(vec![(some2_p8.clone(), (&fire_f5)(&crate::lower::model::Ex::XTuple(Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("a")), crate::lower::model::Ex::XVar(Text::lit("b"))])))), (crate::lower::model::Pa::PaWild, Array::new())]),
        _ => Array::from(vec![(left_p9.clone(), (&fire_f5)(&crate::lower::model::Ex::XVar(Text::lit("a")))), (crate::lower::model::Pa::PaWild, Array::new())]),
    };
    crate::lower::model::Do::DoMatch(both_p4.clone(), cases_pb.clone())
}

/// ```prism
/// WakeByHeight: fn [Gn], [Nat] -> Do
/// ```
pub fn wake_by_height(combs_p0: &Array<crate::lower::node_::Gn>, heights_p1: &Array<Nat>) -> crate::lower::model::Do {
    crate::lower::model::Do::DoMatch(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::lit("wakes"))), Text::lit("next"), Array::new()), push(&each(heights_p1, &(|h_p2: &Nat| (crate::lower::model::Pa::PaConst(wake_const(heights_p1, h_p2)), each(&filter(combs_p0, &(|g_p3: &crate::lower::node_::Gn| &g_p3.height == h_p2)), &(|g_p4: &crate::lower::node_::Gn| decide(g_p4)))))), &(crate::lower::model::Pa::PaWild, Array::new())))
}

/// ```prism
/// ForwardAnswer: fn ForDef -> Ex
/// ```
pub fn forward_answer(b_p0: &crate::lower::model::ForDef) -> crate::lower::model::Ex {
    let row_of_p1 = crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", &b_p0.name)))), Text::lit("borrow"), Array::new())), Text::lit("get"), Array::from(vec![crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XDecode(b_p0.key_ty.clone(), Rc::new(crate::lower::model::Ex::XVar(Text::lit("k"))))))]))), Text::lit("cloned"), Array::new());
    crate::lower::model::Ex::XBlock(Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(Text::lit("row")), row_of_p1.clone()), crate::lower::model::Do::DoIfLet(crate::lower::model::Pa::PaCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("row"))])), crate::lower::model::Ex::XVar(Text::lit("row")), Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::expr::try_of(&crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("row"))), Text::lit("answer"), Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("rest")), crate::lower::model::Ex::XVar(Text::lit("v")), crate::lower::model::Ex::XCx]))))]), Array::new())]), Rc::new(crate::lower::model::Ex::XUnit))
}

/// ```prism
/// IsHold: fn OutTy -> Bool
/// ```
pub fn is_hold(out_ty0: &crate::lower::model::OutTy) -> bool {
    match out_ty0 {
        crate::lower::model::OutTy::OutHold(_) => true,
        crate::lower::model::OutTy::OutNamed(c1_0_0, _) if (c1_0_0 == &Text::lit("prism_rtl::PerKey")) => true,
        other_p0 => false,
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// RowMethods: fn Wx -> [MethDef]
/// ```
pub fn row_methods(wx_p0: &crate::lower::node_::Wx) -> Array<crate::lower::model::MethDef> {
    let removes_p1 = fold(&filter(&wx_p0.places, &(|p_p3: &crate::lower::node_::Place| emits(wx_p0, &p_p3.pos))), &Array::new(), &(|acc_p4: &Array<crate::lower::model::Do>, p_p5: &crate::lower::node_::Place| append(acc_p4, &append(&Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCx), Text::lit("removed"), Array::from(vec![place_at(wx_p0, &Text::lit("self"), &p_p5.pos)])))]), &(if &p_p5.watch == &Text::lit("") {
        Array::new()
    } else {
        Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), p_p5.watch.clone())), Text::lit("drop_all"), Array::new()))])
    })))));
    let nested_p2 = append(&each(&wx_p0.builders, &(|b_p6: &crate::lower::model::ForDef| crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), b_p6.name.clone())), Text::lit("borrow"), Array::new())), Text::lit("values"), Array::new())), Text::lit("for_each"), Array::from(vec![crate::lower::model::Ex::XClosure(false, Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("row"))]), Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("row"))), Text::lit("leave_row"), Array::from(vec![crate::lower::model::Ex::XCx]))))]))))), &each(&wx_p0.gens, &(|gd_p7: &crate::lower::model::GenDef| crate::lower::model::Do::DoIfLet(crate::lower::model::Pa::PaCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("row"))])), crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), gd_p7.name.clone())), Text::lit("borrow"), Array::new())), Text::lit("as_ref"), Array::new()), Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("row"))), Text::lit("leave_row"), Array::from(vec![crate::lower::model::Ex::XCx])))]), Array::new()))));
    Array::from(vec![crate::lower::model::MethDef { name: Text::lit("remove_places"), recv: crate::lower::model::Recv::RecvRef, params: Array::new(), cx_: crate::lower::model::CxArg::CxMut, ret: crate::lower::model::OutTy::OutUnit, body: append(&removes_p1, &nested_p2), tail: crate::lower::model::Ex::XUnit, doc: Text::lit("The row left: its places are torn down.") }])
}

/// ```prism
/// GnDoc: fn Gn -> Text
/// ```
pub fn gn_doc(g_p0: &crate::lower::node_::Gn) -> Text {
    match &g_p0.kind {
        crate::lower::node_::GnKind::GnAnswer => Text::from(format!("`{}`: an answer at its place.", &g_p0.name)),
        crate::lower::node_::GnKind::GnStarted => Text::lit("`@started`, the tick after the build."),
        crate::lower::node_::GnKind::GnDeferred => Text::lit("An `@Defer` firing, the tick after it was armed."),
        crate::lower::node_::GnKind::GnMerge => Text::from(format!("The merge `{}`, decided in the wake.", &g_p0.name)),
        crate::lower::node_::GnKind::GnUpdated => Text::lit("`!Updated`: the dynamic\'s value after the tick, fired in the wake when a hold it reads was written (or a structural dynamic it reads was published, pick ST)."),
        _ => Text::from(format!("`!{}`.", &g_p0.name)),
    }
}

/// ```prism
/// MergeDecide: fn Gn -> Do
/// ```
pub fn merge_decide(g_p0: &crate::lower::node_::Gn) -> crate::lower::model::Do {
    let call_p1 = Array::from(vec![self_call(&g_p0.name, &Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("v"))]))]);
    let take_l_p2 = crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(Text::lit("left")), crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", &or(&index(&g_p0.inputs, &Nat::from(0u32)), &Text::lit("")))))), Text::lit("take"), Array::from(vec![crate::lower::model::Ex::XCx])));
    let take_r_p3 = crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(Text::lit("right")), crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", &or(&index(&g_p0.inputs, &Nat::from(1u32)), &Text::lit("")))))), Text::lit("take"), Array::from(vec![crate::lower::model::Ex::XCx])));
    let right_p4 = crate::lower::model::Do::DoIfLet(crate::lower::model::Pa::PaCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("v"))])), crate::lower::model::Ex::XVar(Text::lit("right")), call_p1.clone(), Array::new());
    crate::lower::model::Do::DoBlock(Array::from(vec![take_l_p2.clone(), take_r_p3.clone(), crate::lower::model::Do::DoIfLet(crate::lower::model::Pa::PaCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("v"))])), crate::lower::model::Ex::XVar(Text::lit("left")), call_p1.clone(), Array::from(vec![right_p4.clone()]))]))
}
