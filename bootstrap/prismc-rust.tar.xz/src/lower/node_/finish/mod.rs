//! The module `Lower.Node.Finish`, from `target/bootstrap/src/prismc/lower/node/finish.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// `Sinks`:
///
/// ```prism
/// type Sinks = record:
/// ```
#[derive(Clone)]
pub struct Sinks {
    pub wx_p: crate::lower::node_::Wx,
    pub dirty_p: Array<crate::lower::node_::Read>,
    pub builds_p: Array<crate::lower::node_::Read>,
    pub heights_p: Array<Nat>,
    pub many_p: bool,
}

/// ```prism
/// Heights: fn [Gn] -> [Gn]
/// ```
pub fn heights_f(gns_p0: &Array<crate::lower::node_::Gn>) -> Array<crate::lower::node_::Gn> {
    crate::prelude::fold(gns_p0, gns_p0, &(|cur_p1: &Array<crate::lower::node_::Gn>, _: &crate::lower::node_::Gn| crate::prelude::each(cur_p1, &(|n_p2: &crate::lower::node_::Gn| height_step_f(cur_p1, n_p2)))))
}

/// ```prism
/// HeightStep: fn [Gn], Gn -> Gn
/// ```
pub fn height_step_f(gns_p0: &Array<crate::lower::node_::Gn>, n_p1: &crate::lower::node_::Gn) -> crate::lower::node_::Gn {
    let feeders_p2 = crate::prelude::filter(gns_p0, &(|m_p5: &crate::lower::node_::Gn| crate::prelude::fold(&m_p5.outs_p, &false, &(|f_p6: &bool, o_p7: &crate::lower::node_::Out| *f_p6 || feeds_f(&o_p7.sink_p, n_p1)))));
    let top_p3 = crate::prelude::fold(&feeders_p2, &Nat::from(0u32), &(|hi_p8: &Nat, m_p9: &crate::lower::node_::Gn| crate::prelude::max(hi_p8, &m_p9.height_p)));
    let h_p4 = match &n_p1.kind_p {
        crate::lower::node_::GnKind::GnNamed => top_p3.clone(),
        kind_pa => if is_comb_f(kind_pa) {
            crate::prelude::max(&(&top_p3 + &Nat::from(1u32)), &n_p1.floor_p)
        } else {
            n_p1.height_p.clone()
        },
    };
    let mut this: crate::lower::node_::Gn = n_p1.clone();
    this.height_p = h_p4.clone();
    this
}

/// ```prism
/// IsComb: fn GnKind -> Bool
/// ```
pub fn is_comb_f(k_p0: &crate::lower::node_::GnKind) -> bool {
    match k_p0 {
        crate::lower::node_::GnKind::GnMerge => true,
        crate::lower::node_::GnKind::GnUnion => true,
        crate::lower::node_::GnKind::GnBoth => true,
        crate::lower::node_::GnKind::GnExcept => true,
        crate::lower::node_::GnKind::GnMergeAll => true,
        crate::lower::node_::GnKind::GnUpdated => true,
        _ => false,
    }
}

/// ```prism
/// Feeds: fn Sk, Gn -> Bool
/// ```
pub fn feeds_f(sk0: &crate::lower::node_::Sk, n_p1: &crate::lower::node_::Gn) -> bool {
    match sk0 {
        crate::lower::node_::Sk::SkNode(m_p0) => m_p0 == &n_p1.id_p,
        crate::lower::node_::Sk::SkIn(m_p2, _) => m_p2 == &n_p1.id_p,
        crate::lower::node_::Sk::SkCycle(_, _, m_p4) => m_p4 == &n_p1.id_p,
        crate::lower::node_::Sk::SkMachine(f_p6, _, m_p7) => (m_p7 == &n_p1.id_p) || writes_f(f_p6, n_p1),
        crate::lower::node_::Sk::SkHold(f_p9) => writes_f(f_p9, n_p1),
        crate::lower::node_::Sk::SkDistinct(f_pb) => writes_f(f_pb, n_p1),
        crate::lower::node_::Sk::SkPerKey(f_pd) => writes_f(f_pd, n_p1),
        other_pf => false,
    }
}

/// ```prism
/// Writes: fn Text, Gn -> Bool
/// ```
pub fn writes_f(f_p0: &Text, n_p1: &crate::lower::node_::Gn) -> bool {
    moves_f(&crate::lower::node_::Read::OwnRead(f_p0.clone()), n_p1)
}

/// ```prism
/// Moves: fn Read, Gn -> Bool
/// ```
pub fn moves_f(r_p0: &crate::lower::node_::Read, n_p1: &crate::lower::node_::Gn) -> bool {
    (&n_p1.kind_p == &crate::lower::node_::GnKind::GnUpdated) && crate::lower::node_::has_read_f(&n_p1.reads_p, r_p0)
}

/// ```prism
/// ReadsClosed: fn (Text ==> [Read]), [Read] -> [Read]
/// ```
pub fn reads_closed_f(dyn_p0: &Map<Text, Array<crate::lower::node_::Read>>, reads_p1: &Array<crate::lower::node_::Read>) -> Array<crate::lower::node_::Read> {
    crate::prelude::fold(&crate::check::errors::range0_f(&Nat::from(4u32)), reads_p1, &(|acc_p2: &Array<crate::lower::node_::Read>, _: &Nat| crate::prelude::fold(acc_p2, acc_p2, &(|a_p3: &Array<crate::lower::node_::Read>, r_p4: &crate::lower::node_::Read| crate::lower::node_::union_reads_f(a_p3, &getter_reads_f(dyn_p0, r_p4))))))
}

/// ```prism
/// GetterReads: fn (Text ==> [Read]), Read -> [Read]
/// ```
pub fn getter_reads_f(dyn_p0: &Map<Text, Array<crate::lower::node_::Read>>, read1: &crate::lower::node_::Read) -> Array<crate::lower::node_::Read> {
    match read1 {
        crate::lower::node_::Read::OwnRead(n_p1) => crate::prelude::or(&crate::prelude::get(dyn_p0, n_p1), &Array::new()),
        crate::lower::node_::Read::ParentRead(_) => Array::new(),
    }
}

/// ```prism
/// ReachesSnap: fn [Text], [Read] -> Bool
/// ```
pub fn reaches_snap_f(roots_p0: &Array<Text>, reads_p1: &Array<crate::lower::node_::Read>) -> bool {
    crate::prelude::fold(reads_p1, &false, &(|f_p2: &bool, r_p3: &crate::lower::node_::Read| *f_p2 || match r_p3 {
        crate::lower::node_::Read::OwnRead(n_p4) => crate::check::types::has_text_f(roots_p0, n_p4),
        crate::lower::node_::Read::ParentRead(_) => false,
    }))
}

/// ```prism
/// SnapNames: fn Wx -> [Text]
/// ```
pub fn snap_names_f(wx_p0: &crate::lower::node_::Wx) -> Array<Text> {
    crate::prelude::each(&wx_p0.snaps_p, &(|sn_p1: &crate::lower::node_::SnapDef| sn_p1.name_p.clone()))
}

/// ```prism
/// WakeConst: fn [Nat], Nat -> Text
/// ```
pub fn wake_const_f(heights_p0: &Array<Nat>, h_p1: &Nat) -> Text {
    if &crate::prelude::len(heights_p0) <= &Nat::from(1u32) {
        Text::lit("WAKE")
    } else {
        Text::from(format!("WAKE_{}", h_p1))
    }
}

/// ```prism
/// SelfCall: fn Text, [Ex] -> Do
/// ```
pub fn self_call_f(m_p0: &Text, args_p1: &Array<crate::lower::model::Ex>) -> crate::lower::model::Do {
    crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XSelf), m_p0.clone(), crate::prelude::push(args_p1, &crate::lower::model::Ex::XCx)))
}

/// ```prism
/// SinkCode: fn Sinks, Sk, Ex -> [Do]
/// ```
pub fn sink_code_f(sk_p0: &Sinks, target_p1: &crate::lower::node_::Sk, y_p2: &crate::lower::model::Ex) -> Array<crate::lower::model::Do> {
    match target_p1 {
        crate::lower::node_::Sk::SkNode(m_p3) => Array::from(vec![self_call_f(&crate::lower::node_::gn_of_f(&sk_p0.wx_p, m_p3).name_p, &Array::from(vec![y_p2.clone()]))]),
        crate::lower::node_::Sk::SkIn(m_p4, i_p5) => {
            let g_p6 = crate::lower::node_::gn_of_f(&sk_p0.wx_p, m_p4);
            crate::prelude::append(&Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", &crate::prelude::or(&crate::prelude::index(&g_p6.inputs_p, i_p5), &Text::lit("")))))), Text::lit("set"), Array::from(vec![y_p2.clone(), crate::lower::model::Ex::XCx])))]), &ask_wake_f(sk_p0, &g_p6.height_p))
        },
        crate::lower::node_::Sk::SkHold(f_p7) => crate::prelude::append(&Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", f_p7)))), Text::lit("set"), Array::from(vec![y_p2.clone(), crate::lower::model::Ex::XCx])))]), &hold_written_f(sk_p0, f_p7)),
        crate::lower::node_::Sk::SkDistinct(f_p8) => {
            let differs_p9 = crate::lower::model::Ex::XBin(crate::lower::model::BinOp::OpNe, Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", f_p8)))), Text::lit("get"), Array::from(vec![crate::lower::model::Ex::XCx]))), Rc::new(crate::lower::model::Ex::XCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Ex::XClone(Rc::new(y_p2.clone()))]))));
            let write_pa = crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", f_p8)))), Text::lit("set"), Array::from(vec![crate::lower::model::Ex::XCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Ex::XClone(Rc::new(y_p2.clone()))])), crate::lower::model::Ex::XCx])));
            Array::from(vec![crate::lower::model::Do::DoIf(differs_p9.clone(), crate::prelude::append(&Array::from(vec![write_pa.clone()]), &hold_written_f(sk_p0, f_p8)), Array::new())])
        },
        crate::lower::node_::Sk::SkPerKey(f_pb) => Array::from(vec![crate::lower::model::Do::DoIf(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", f_pb)))), Text::lit("written"), Array::from(vec![crate::lower::model::Ex::XClone(Rc::new(y_p2.clone())), crate::lower::model::Ex::XCx])), hold_written_f(sk_p0, f_pb), Array::new())]),
        crate::lower::node_::Sk::SkRequest(pos_pc, field_pd) => {
            let field_ex_pe = if field_pd == &Text::lit("") {
                crate::lower::model::Ex::XNone
            } else {
                crate::lower::model::Ex::XCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Ex::XStr(field_pd.clone())]))
            };
            if emits_f(&sk_p0.wx_p, pos_pc) {
                Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCx), Text::lit("request"), Array::from(vec![place_at_f(&sk_p0.wx_p, &Text::lit("self"), pos_pc), field_ex_pe.clone(), crate::lower::model::Ex::XMethod(Rc::new(y_p2.clone()), Text::lit("to_pod"), Array::new())])))])
            } else {
                Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(Text::lit("requested")), crate::lower::model::Ex::XMethod(Rc::new(host_field_ex_f(&sk_p0.wx_p, pos_pc)), Text::lit("request"), Array::from(vec![crate::lower::model::Ex::XRef(Rc::new(place_at_f(&sk_p0.wx_p, &Text::lit("self"), pos_pc))), field_ex_pe.clone(), crate::lower::model::Ex::XMethod(Rc::new(y_p2.clone()), Text::lit("to_pod"), Array::new()), crate::lower::model::Ex::XCx]))), crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCx), Text::lit("keep"), Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("requested"))])))])
            }
        },
        crate::lower::node_::Sk::SkResult => Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCx), Text::lit("result"), Array::from(vec![crate::lower::model::Ex::XCtor(Text::lit("Outcome::Fired"), Array::from(vec![crate::lower::model::Ex::XMethod(Rc::new(y_p2.clone()), Text::lit("to_pod"), Array::new())]))])))]),
        crate::lower::node_::Sk::SkArm(f_pf) => Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", f_pf)))), Text::lit("arm"), Array::from(vec![y_p2.clone(), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XSelf)), crate::lower::model::Ex::XCx])))]),
        crate::lower::node_::Sk::SkMachine(f_pg, step_ph, out_pi) => {
            let stepped_pj = crate::lower::model::Ex::XCall(step_ph.clone(), Array::from(vec![crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), f_pg.clone())), Text::lit("get"), Array::from(vec![crate::lower::model::Ex::XCx])))), crate::lower::model::Ex::XRef(Rc::new(y_p2.clone()))]));
            crate::prelude::append(&Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTuple(Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("machine_s")), crate::lower::model::Pa::PaBind(Text::lit("machine_b"))])), stepped_pj.clone()), crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", f_pg)))), Text::lit("set"), Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("machine_s")), crate::lower::model::Ex::XCx]))), crate::lower::model::Do::DoIfLet(crate::lower::model::Pa::PaCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("machine_b"))])), crate::lower::model::Ex::XVar(Text::lit("machine_b")), Array::from(vec![self_call_f(&crate::lower::node_::gn_of_f(&sk_p0.wx_p, out_pi).name_p, &Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("machine_b"))]))]), Array::new())]), &moved_marks_f(sk_p0, f_pg))
        },
        crate::lower::node_::Sk::SkPort(f_pk) => Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_port", f_pk)))), Text::lit("fire"), Array::from(vec![y_p2.clone(), crate::lower::model::Ex::XCx]))), Text::lit("ok"), Array::new()))]),
        crate::lower::node_::Sk::SkUp(m_pl) => {
            let keyed_pm = &crate::prelude::len(&crate::prelude::filter(&sk_p0.wx_p.fields_p, &(|(f_po, _, _): &(Text, crate::lower::model::OutTy, Text)| f_po == &Text::lit("key")))) > &Nat::from(0u32);
            let args_pn = if keyed_pm {
                Array::from(vec![crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::lit("key")))), y_p2.clone(), crate::lower::model::Ex::XCx])
            } else {
                Array::from(vec![y_p2.clone(), crate::lower::model::Ex::XCx])
            };
            Array::from(vec![crate::lower::model::Do::DoIfLet(crate::lower::model::Pa::PaCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("parent"))])), crate::lower::model::Ex::XUpgrade(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::lit("parent")))), Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("parent"))), m_pl.clone(), args_pn.clone()))]), Array::new())])
        },
        crate::lower::node_::Sk::SkCycle(job_pp, again_pq, res_pr) => {
            let more_ps = Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", job_pp)))), Text::lit("set"), Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("next")), crate::lower::model::Ex::XCx]))), crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", again_pq)))), Text::lit("arm"), Array::from(vec![crate::lower::model::Ex::XUnit, crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XSelf)), crate::lower::model::Ex::XCx])))]);
            let fin_pt = Array::from(vec![self_call_f(&crate::lower::node_::gn_of_f(&sk_p0.wx_p, res_pr).name_p, &Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("b"))]))]);
            Array::from(vec![crate::lower::model::Do::DoMatch(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", job_pp)))), Text::lit("get"), Array::from(vec![crate::lower::model::Ex::XCx]))), Text::lit("cycle"), Array::new()), Array::from(vec![(crate::lower::model::Pa::PaCtor(Text::lit("prism_rtl::Turn::More"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("next"))])), more_ps.clone()), (crate::lower::model::Pa::PaCtor(Text::lit("prism_rtl::Turn::Finished"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("b"))])), fin_pt.clone())]))])
        },
    }
}

/// ```prism
/// HoldWritten: fn Sinks, Text -> [Do]
/// ```
pub fn hold_written_f(sk_p0: &Sinks, f_p1: &Text) -> Array<crate::lower::model::Do> {
    let r_p2 = crate::lower::node_::Read::OwnRead(f_p1.clone());
    let read_by_place_p3 = crate::lower::node_::has_read_f(&sk_p0.dirty_p, &r_p2);
    let dirty_p4 = if read_by_place_p3 {
        Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCx), Text::lit("dirty"), Array::from(vec![crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XSelf))])))])
    } else {
        Array::new()
    };
    let told_p5 = Array::new();
    let stales_p6 = crate::prelude::fold(&sk_p0.wx_p.gen_holds_p, &Array::new(), &(|acc_pb: &Array<crate::lower::model::Do>, (gname_pc, hs_pd): &(Text, Array<crate::lower::node_::Read>)| if crate::lower::node_::has_read_f(&reads_closed_f(&sk_p0.wx_p.dyn_reads_p, hs_pd), &r_p2) {
        crate::prelude::push(acc_pb, &crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_stale", gname_pc)))), Text::lit("set"), Array::from(vec![crate::lower::model::Ex::XBool(true)]))))
    } else {
        acc_pb.clone()
    }));
    let row_marks_p7 = crate::prelude::fold(&sk_p0.wx_p.row_marks_p, &Array::new(), &(|acc_pe: &Array<crate::lower::model::Do>, rm_pf: &crate::lower::node_::RowMarks| crate::prelude::append(acc_pe, &row_written_f(&sk_p0.wx_p, rm_pf, &r_p2))));
    let builds_p8 = crate::lower::node_::has_read_f(&sk_p0.builds_p, &r_p2) || (&crate::prelude::len(&stales_p6) > &Nat::from(0u32));
    let rebuild_it_p9 = if builds_p8 && !lists_build_f(sk_p0, &r_p2) {
        crate::prelude::append(&stales_p6, &Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCx), Text::lit("build_later"), Array::from(vec![crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XSelf))])))]))
    } else {
        stales_p6.clone()
    };
    let gathered_pa = match &sk_p0.wx_p.result_moved_o {
        Some((m_pg, rds_ph)) => if crate::lower::node_::has_read_f(rds_ph, &r_p2) {
            Array::from(vec![crate::lower::model::Do::DoIfLet(crate::lower::model::Pa::PaCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("parent"))])), crate::lower::model::Ex::XUpgrade(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::lit("parent")))), Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("parent"))), m_pg.clone(), Array::from(vec![crate::lower::model::Ex::XCx])))]), Array::new())])
        } else {
            Array::new()
        },
        None => Array::new(),
    };
    crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&dirty_p4, &told_p5), &rebuild_it_p9), &row_marks_p7), &gathered_pa), &moved_marks_f(sk_p0, f_p1))
}

/// ```prism
/// HostFieldEx: fn Wx, Pos -> Ex
/// ```
pub fn host_field_ex_f(wx_p0: &crate::lower::node_::Wx, pos_p1: &crate::lower::model::Pos_) -> crate::lower::model::Ex {
    crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), crate::lower::node_::elements::host_local_f(wx_p0, pos_p1))
}

/// ```prism
/// MovedMarks: fn Sinks, Text -> [Do]
/// ```
pub fn moved_marks_f(sk_p0: &Sinks, f_p1: &Text) -> Array<crate::lower::model::Do> {
    moved_by_f(sk_p0, &crate::lower::node_::Read::OwnRead(f_p1.clone()))
}

/// ```prism
/// MovedBy: fn Sinks, Read -> [Do]
/// ```
pub fn moved_by_f(sk_p0: &Sinks, r_p1: &crate::lower::node_::Read) -> Array<crate::lower::model::Do> {
    let moved_p2 = crate::prelude::filter(&sk_p0.wx_p.gns_p, &(|g_p9: &crate::lower::node_::Gn| moves_f(r_p1, g_p9)));
    let flags_p3 = crate::prelude::each(&moved_p2, &(|g_pa: &crate::lower::node_::Gn| crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_moved", &g_pa.name_p)))), Text::lit("set"), Array::from(vec![crate::lower::model::Ex::XBool(true)])))));
    let heights_p4 = sort_nats_f(&crate::prelude::fold(&moved_p2, &Array::new(), &(|acc_pb: &Array<Nat>, g_pc: &crate::lower::node_::Gn| crate::check::types::add_nat_f(acc_pb, &g_pc.height_p))));
    let marks_p5 = crate::prelude::each(&snaps_behind_f(&sk_p0.wx_p, r_p1), &(|sn_pd: &crate::lower::node_::SnapDef| crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_snap", &sn_pd.name_p)))), Text::lit("mark"), Array::from(vec![crate::lower::model::Ex::XCx])))));
    let listed_p6 = if lists_build_f(sk_p0, r_p1) {
        Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCx), Text::lit("build_later"), Array::from(vec![crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XSelf))])))])
    } else {
        Array::new()
    };
    let answers_p7 = crate::prelude::each(&crate::prelude::filter(&sk_p0.wx_p.dyn_answers_p, &(|(_, rds_pe): &(Text, Array<crate::lower::node_::Read>)| crate::lower::node_::has_read_f(&reads_closed_f(&sk_p0.wx_p.dyn_reads_p, rds_pe), r_p1))), &(|(name_pf, _): &(Text, Array<crate::lower::node_::Read>)| crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_port", name_pf)))), Text::lit("fire"), Array::from(vec![crate::lower::model::Ex::XUnit, crate::lower::model::Ex::XCx]))), Text::lit("ok"), Array::new()))));
    let adoptions_p8 = crate::prelude::each(&crate::prelude::filter(&sk_p0.wx_p.flattens_p, &(|fl_pg: &crate::lower::node_::FlatDef| (&fl_pg.generation_p != &Text::lit("")) && (r_p1 == &crate::lower::node_::Read::OwnRead(fl_pg.outer_p.clone())))), &(|fl_ph: &crate::lower::node_::FlatDef| crate::lower::model::Do::DoScope(adoption_f(fl_ph))));
    crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&crate::prelude::fold(&heights_p4, &flags_p3, &(|acc_pi: &Array<crate::lower::model::Do>, h_pj: &Nat| crate::prelude::append(acc_pi, &ask_wake_f(sk_p0, h_pj)))), &marks_p5), &listed_p6), &answers_p7), &adoptions_p8), &source_marks_f(&sk_p0.wx_p, r_p1))
}

/// ```prism
/// SourceMarks: fn Wx, Read -> [Do]
/// ```
pub fn source_marks_f(wx_p0: &crate::lower::node_::Wx, r_p1: &crate::lower::node_::Read) -> Array<crate::lower::model::Do> {
    let fors_p2 = crate::prelude::fold(&wx_p0.builders_p, &Array::new(), &(|acc_p3: &Array<crate::lower::model::Do>, b_p4: &crate::lower::model::ForDef| if crate::lower::node_::has_read_f(&reads_closed_f(&wx_p0.dyn_reads_p, &crate::prelude::or(&crate::prelude::get(&wx_p0.dyn_reads_p, &b_p4.source_p), &Array::new())), r_p1) {
        crate::prelude::push(acc_p3, &crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_cache", &b_p4.source_p)))), Text::lit("mark"), Array::from(vec![crate::lower::model::Ex::XCx]))))
    } else {
        acc_p3.clone()
    }));
    crate::prelude::fold(&wx_p0.let_caches_p, &fors_p2, &(|acc_p5: &Array<crate::lower::model::Do>, c_p6: &Text| if crate::lower::node_::has_read_f(&reads_all_f(&wx_p0.dyn_reads_p, &crate::prelude::or(&crate::prelude::get(&wx_p0.dyn_reads_p, c_p6), &Array::new())), r_p1) {
        crate::prelude::push(acc_p5, &crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_cache", c_p6)))), Text::lit("mark"), Array::from(vec![crate::lower::model::Ex::XCx]))))
    } else {
        acc_p5.clone()
    }))
}

/// ```prism
/// ReadsAll: fn (Text ==> [Read]), [Read] -> [Read]
/// ```
pub fn reads_all_f(dyn_p0: &Map<Text, Array<crate::lower::node_::Read>>, reads_p1: &Array<crate::lower::node_::Read>) -> Array<crate::lower::node_::Read> {
    crate::prelude::fold(&crate::check::errors::range0_f(&(&crate::prelude::size(dyn_p0) + &Nat::from(1u32))), reads_p1, &(|acc_p2: &Array<crate::lower::node_::Read>, _: &Nat| crate::prelude::fold(acc_p2, acc_p2, &(|a_p3: &Array<crate::lower::node_::Read>, r_p4: &crate::lower::node_::Read| crate::lower::node_::union_reads_f(a_p3, &getter_reads_f(dyn_p0, r_p4))))))
}

/// ```prism
/// IsOwnRead: fn Read -> Bool
/// ```
pub fn is_own_read_f(r_p0: &crate::lower::node_::Read) -> bool {
    match r_p0 {
        crate::lower::node_::Read::OwnRead(_) => true,
        crate::lower::node_::Read::ParentRead(_) => false,
    }
}

/// ```prism
/// SnapsBehind: fn Wx, Read -> [SnapDef]
/// ```
pub fn snaps_behind_f(wx_p0: &crate::lower::node_::Wx, r_p1: &crate::lower::node_::Read) -> Array<crate::lower::node_::SnapDef> {
    crate::prelude::filter(&wx_p0.snaps_p, &(|sn_p2: &crate::lower::node_::SnapDef| (r_p1 == &crate::lower::node_::Read::OwnRead(sn_p2.live_p.clone())) || crate::lower::node_::has_read_f(&reads_closed_f(&wx_p0.dyn_reads_p, &Array::from(vec![crate::lower::node_::Read::OwnRead(sn_p2.live_p.clone())])), r_p1)))
}

/// ```prism
/// ListsBuild: fn Sinks, Read -> Bool
/// ```
pub fn lists_build_f(sk_p0: &Sinks, r_p1: &crate::lower::node_::Read) -> bool {
    &crate::prelude::len(&snaps_behind_f(&sk_p0.wx_p, r_p1)) > &Nat::from(0u32)
}

/// ```prism
/// FiringCode: unbounded fn Sinks, Gn, Ex -> [Do]
/// ```
pub fn firing_code_f(sk_p0: &Sinks, g_p1: &crate::lower::node_::Gn, x_p2: &crate::lower::model::Ex) -> Array<crate::lower::model::Do> {
    let many_p3 = (&crate::prelude::len(&g_p1.outs_p) > &Nat::from(1u32)) && !crate::lower::types::is_copy_f(&g_p1.ty_p);
    let xv_p4 = if many_p3 {
        crate::lower::model::Ex::XClone(Rc::new(x_p2.clone()))
    } else {
        x_p2.clone()
    };
    crate::prelude::run_to_end(crate::prelude::fold_job(g_p1.outs_p.clone(), Array::new(), {
        let xv_p4x = xv_p4.clone();
        let sk_p0x = sk_p0.clone();
        Rc::new(move |(p0, p1): (Array<crate::lower::model::Do>, crate::lower::node_::Out)| {
            let xv_p4xy = xv_p4x.clone();
            let sk_p0xy = sk_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_p5 = p0;
                let o_p6 = p1;
                crate::prelude::call_value((&o_p6.pipe_f)((xv_p4xy.clone(), {
                    let sk_p0xyx = sk_p0xy.clone();
                    let o_p6x = o_p6.clone();
                    Rc::new(move |p0: crate::lower::model::Ex| {
                        let sk_p0xyxy = sk_p0xyx.clone();
                        let o_p6xy = o_p6x.clone();
                        crate::prelude::once_job(move || {
                            let y_p7 = p0;
                            prism_rtl::Turn::Finished(sink_code_f(&sk_p0xyxy, &o_p6xy.sink_p, &y_p7))
                        })
                    }) as Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>
                })), move |call_13560: Array<crate::lower::model::Do>| prism_rtl::Turn::Finished(crate::prelude::append(&acc_p5, &call_13560)))
            }))
        }) as Rc<dyn Fn((Array<crate::lower::model::Do>, crate::lower::node_::Out)) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>
    }))
}

/// The step machine of `FiringCode`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FiringCode: unbounded fn Sinks, Gn, Ex -> [Do]
/// ```
pub struct FiringCode {
    pub sk_p0: Sinks,
    pub g_p1: crate::lower::node_::Gn,
    pub x_p2: crate::lower::model::Ex,
}

impl prism_rtl::Job<Array<crate::lower::model::Do>> for FiringCode {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::lower::model::Do>> {
        let sk_p0 = &self.sk_p0;
        let g_p1 = &self.g_p1;
        let x_p2 = &self.x_p2;
        let many_p3 = (&crate::prelude::len(&g_p1.outs_p) > &Nat::from(1u32)) && !crate::lower::types::is_copy_f(&g_p1.ty_p);
        let xv_p4 = if many_p3 {
            crate::lower::model::Ex::XClone(Rc::new(x_p2.clone()))
        } else {
            x_p2.clone()
        };
        crate::prelude::fold_job(g_p1.outs_p.clone(), Array::new(), {
            let xv_p4x = xv_p4.clone();
            let sk_p0x = sk_p0.clone();
            Rc::new(move |(p0, p1): (Array<crate::lower::model::Do>, crate::lower::node_::Out)| {
                let xv_p4xy = xv_p4x.clone();
                let sk_p0xy = sk_p0x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let acc_p5 = p0;
                    let o_p6 = p1;
                    crate::prelude::call_value((&o_p6.pipe_f)((xv_p4xy.clone(), {
                        let sk_p0xyx = sk_p0xy.clone();
                        let o_p6x = o_p6.clone();
                        Rc::new(move |p0: crate::lower::model::Ex| {
                            let sk_p0xyxy = sk_p0xyx.clone();
                            let o_p6xy = o_p6x.clone();
                            crate::prelude::once_job(move || {
                                let y_p7 = p0;
                                prism_rtl::Turn::Finished(sink_code_f(&sk_p0xyxy, &o_p6xy.sink_p, &y_p7))
                            })
                        }) as Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>
                    })), move |call_13560: Array<crate::lower::model::Do>| prism_rtl::Turn::Finished(crate::prelude::append(&acc_p5, &call_13560)))
                }))
            }) as Rc<dyn Fn((Array<crate::lower::model::Do>, crate::lower::node_::Out)) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>
        }).cycle()
    }
}

/// `Start FiringCode, x`: what the function value is when passed to `@Run`.
pub fn start_firing_code_f(sk_p0: Sinks, g_p1: crate::lower::node_::Gn, x_p2: crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>> {
    Rc::new(FiringCode { sk_p0, g_p1, x_p2 })
}

/// ```prism
/// FinishNode: unbounded fn Wx, Text, [((Text, OutTy))], Bool -> NodeDef
/// ```
pub fn finish_node_f(wx0_p0: &crate::lower::node_::Wx, qk_p1: &Text, params_p2: &Array<(Text, crate::lower::model::OutTy)>, is_row_p3: &bool) -> crate::lower::model::NodeDef {
    let closed_gns_p4 = crate::prelude::each(&wx0_p0.gns_p, &(|g_p1j: &crate::lower::node_::Gn| if &g_p1j.kind_p == &crate::lower::node_::GnKind::GnUpdated {
        crate::lower::node_::dynamics::with_reads_f(g_p1j, &reads_closed_f(&wx0_p0.dyn_reads_p, &g_p1j.reads_p))
    } else {
        g_p1j.clone()
    }));
    let (row_defs_p1k, gns2_p1l) = finish_pending_f(wx0_p0, &heights_f(&closed_gns_p4));
    let is_gen_p5 = *is_row_p3 && (&crate::prelude::len(&crate::prelude::filter(&wx0_p0.fields_p, &(|(f_p1m, _, _): &(Text, crate::lower::model::OutTy, Text)| f_p1m == &Text::lit("key")))) == &Nat::from(0u32));
    let wx_p6 = {
        let mut this: crate::lower::node_::Wx = wx0_p0.clone();
        this.gns_p = heights_f(&gns2_p1l);
        this.build_p = crate::prelude::append(&this.build_p, &updated_gaps_f(wx0_p0, &closed_gns_p4, &is_gen_p5));
        this.rows_p = crate::prelude::fold(&row_defs_p1k, &this.rows_p, &(|acc_p1n: &Array<crate::lower::model::NodeDef>, rd_p1o: &crate::lower::model::NodeDef| crate::prelude::append(&crate::prelude::push(acc_p1n, rd_p1o), &rd_p1o.children_p)));
        this
    };
    let combs_p7 = crate::prelude::filter(&wx_p6.gns_p, &(|g_p1p: &crate::lower::node_::Gn| is_comb_f(&g_p1p.kind_p) || (&g_p1p.kind_p == &crate::lower::node_::GnKind::GnGather)));
    let heights_p8 = sort_nats_f(&crate::prelude::fold(&combs_p7, &Array::new(), &(|acc_p1q: &Array<Nat>, g_p1r: &crate::lower::node_::Gn| crate::check::types::add_nat_f(acc_p1q, &g_p1r.height_p))));
    let many_p9 = &crate::prelude::len(&heights_p8) > &Nat::from(1u32);
    let consts_pa = crate::prelude::each(&heights_p8, &(|h_p1s: &Nat| (wake_const_f(&heights_p8, h_p1s), h_p1s.clone(), Text::lit("merges\' height above the node\'s inputs"))));
    let live_pb = crate::prelude::filter(&wx_p6.places_p, &(|p_p1t: &crate::lower::node_::Place| &p_p1t.getter_p != &Text::lit("")));
    let root_reads_pc = match &wx_p6.root_dyn_o {
        Some((_, rds_p1u, _)) => reads_closed_f(&wx_p6.dyn_reads_p, rds_p1u),
        None => Array::new(),
    };
    let dirty_holds_pd = crate::prelude::fold(&live_pb, &root_reads_pc, &(|acc_p1v: &Array<crate::lower::node_::Read>, p_p20: &crate::lower::node_::Place| crate::lower::node_::union_reads_f(acc_p1v, &reads_closed_f(&wx_p6.dyn_reads_p, &p_p20.reads_p))));
    let build_holds_pe = reads_closed_f(&wx_p6.dyn_reads_p, &wx_p6.build_holds_p);
    let sinks_pf = Sinks { wx_p: wx_p6.clone(), dirty_p: dirty_holds_pd.clone(), builds_p: build_holds_pe.clone(), heights_p: heights_p8.clone(), many_p: many_p9 };
    let ev_methods_pg = crate::prelude::run_to_end(crate::prelude::each_job(crate::prelude::filter(&wx_p6.gns_p, &(|g_p21: &crate::lower::node_::Gn| &g_p21.kind_p != &crate::lower::node_::GnKind::GnNever)), {
        let sinks_pfx = sinks_pf.clone();
        Rc::new(move |p0: crate::lower::node_::Gn| {
            let sinks_pfxy = sinks_pfx.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let g_p22 = p0;
                crate::prelude::call_then(start_firing_code_f(sinks_pfxy.clone(), g_p22.clone(), crate::lower::model::Ex::XVar(Text::lit("v"))), move |firing_code_f_15352: Array<crate::lower::model::Do>| prism_rtl::Turn::Finished(crate::lower::model::MethDef { name_p: g_p22.name_p.clone(), recv_p: crate::lower::model::Recv::RecvRc, params_p: Array::from(vec![(Text::lit("v"), g_p22.ty_p.clone())]), cx_p: crate::lower::model::CxArg::CxMut, ret_p: crate::lower::model::OutTy::OutUnit, body_p: firing_code_f_15352, tail_p: crate::lower::model::Ex::XUnit, doc_p: gn_doc_f(&g_p22) }))
            }))
        }) as Rc<dyn Fn(crate::lower::node_::Gn) -> Rc<dyn prism_rtl::Job<crate::lower::model::MethDef>>>
    }));
    let gather_ins_ph = crate::prelude::each(&crate::prelude::filter(&wx_p6.gns_p, &(|g_p23: &crate::lower::node_::Gn| &g_p23.kind_p == &crate::lower::node_::GnKind::GnGather)), &(|g_p24: &crate::lower::node_::Gn| gather_in_f(&sinks_pf, g_p24)));
    let place_getters_pi = crate::prelude::each(&live_pb, &(|p_p25: &crate::lower::node_::Place| crate::lower::model::MethDef { name_p: p_p25.getter_p.clone(), recv_p: crate::lower::model::Recv::RecvRef, params_p: Array::new(), cx_p: crate::lower::model::CxArg::CxRef, ret_p: crate::lower::types::elem_ty_p(), body_p: Array::new(), tail_p: p_p25.level_p.clone(), doc_p: Text::from(format!("Place {}\'s level, read at the read point.", &crate::lower::model::place_text_f(&p_p25.pos_p))) }));
    let wake_body_pj = if many_p9 {
        Array::from(vec![wake_by_height_f(&combs_p7, &heights_p8)])
    } else {
        crate::prelude::each(&combs_p7, &(|g_p26: &crate::lower::node_::Gn| decide_f(g_p26)))
    };
    let started_body_pk = crate::prelude::each(&wx_p6.started_p, &(|st_p27: &Nat| self_call_f(&crate::lower::node_::gn_of_f(&wx_p6, st_p27).name_p, &Array::from(vec![crate::lower::model::Ex::XUnit]))));
    let deferred_body_pl = crate::prelude::each(&wx_p6.defers_p, &(|(f_p28, id_p29): &(Text, Nat)| crate::lower::model::Do::DoIfLet(crate::lower::model::Pa::PaCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("v"))])), crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", f_p28)))), Text::lit("fired"), Array::from(vec![crate::lower::model::Ex::XCx])), Array::from(vec![self_call_f(&crate::lower::node_::gn_of_f(&wx_p6, id_p29).name_p, &Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("v"))]))]), Array::new())));
    let patch_body0_pm = crate::prelude::fold(&live_pb, &Array::new(), &(|acc_p2a: &Array<crate::lower::model::Do>, p_p2b: &crate::lower::node_::Place| crate::prelude::append(acc_p2a, &(if emits_f(&wx_p6, &p_p2b.pos_p) {
        patch_place_f(&wx_p6, p_p2b)
    } else {
        Array::from(vec![entry_take_f(&crate::lower::model::Ex::XSelf, p_p2b)])
    }))));
    let patch_body_pn = crate::prelude::append(&patch_body0_pm, &root_dyn_patch_f(&wx_p6));
    let build_body_po = build_steps_f(&sinks_pf, &false);
    let push_body_pp = crate::prelude::each(&crate::prelude::filter(&wx_p6.dyn_places_p, &(|(pos_p2c, _, _, _): &(crate::lower::model::Pos_, Text, crate::lower::model::OutTy, Text)| emits_f(&wx_p6, pos_p2c))), &(|(pos_p2d, f_p2e, t_p2f, _): &(crate::lower::model::Pos_, Text, crate::lower::model::OutTy, Text)| crate::lower::model::Do::DoIf(crate::lower::model::Ex::XBin(crate::lower::model::BinOp::OpEq, Rc::new(crate::lower::model::Ex::XVar(Text::lit("element"))), Rc::new(crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_element", f_p2e))))))), dyn_place_write_f(&sinks_pf, f_p2e, &crate::lower::model::Ex::XDecode(t_p2f.clone(), Rc::new(crate::lower::model::Ex::XVar(Text::lit("v"))))), Array::new())));
    let hooks_pq = crate::prelude::filter(&Array::from(vec![(Text::lit("wake"), wake_body_pj.clone()), (Text::lit("started"), started_body_pk.clone()), (Text::lit("deferred"), deferred_body_pl.clone()), (Text::lit("build"), build_body_po.clone()), (Text::lit("push"), push_body_pp.clone()), (Text::lit("patch"), patch_body_pn.clone())]), &(|(_, b_p2g): &(Text, Array<crate::lower::model::Do>)| &crate::prelude::len(b_p2g) > &Nat::from(0u32)));
    let started_reg_pr = if &crate::prelude::len(&wx_p6.started_p) > &Nat::from(0u32) {
        Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCx), Text::lit("on_started"), Array::from(vec![crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(Text::lit("node"))))])))])
    } else {
        Array::new()
    };
    let links_ps = crate::prelude::each(&wx_p6.hosts_p, &(|h_p2h: &crate::lower::node_::HostDef| crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XVar(Text::lit("node"))), Text::from(format!("{}", &h_p2h.name_p)))), Text::lit("link"), Array::from(vec![crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XVar(Text::lit("node"))))])))));
    let rows_built_pt = crate::prelude::append(&links_ps, &build_steps_f(&sinks_pf, &true));
    let subscribed_pu = crate::prelude::each(&wx_p6.subs_p, &(|(ev_p2i, m_p2j, t_p2k): &(Text, Text, crate::lower::model::OutTy)| crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XCall(crate::lower::helper_f(&Text::lit("subscribe_row")), Array::from(vec![crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XVar(Text::lit("node")))), crate::lower::model::Ex::XUpgrade(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XVar(Text::lit("node"))), Text::lit("parent")))), crate::lower::model::Ex::XClosure(false, Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("p"))]), Rc::new(crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XVar(Text::lit("p"))), Text::from(format!("{}_port", ev_p2i))))))), crate::lower::model::Ex::XClosure(false, Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("n")), crate::lower::model::Pa::PaBind(Text::lit("v")), crate::lower::model::Pa::PaBind(Text::lit("cx"))]), Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("n"))), m_p2j.clone(), Array::from(vec![crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(Text::lit("v")))), crate::lower::model::Ex::XCx])))), crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XVar(Text::lit("node"))), Text::from(format!("{}_sub", m_p2j)))))])))));
    let answers_pv = crate::prelude::append(&crate::prelude::each(&crate::prelude::filter(&wx_p6.answers_p, &(|(pos_p2l, _, _, _): &(crate::lower::model::Pos_, Nat, crate::lower::model::OutTy, Text)| emits_f(&wx_p6, pos_p2l))), &(|(pos_p2m, id_p2n, t_p2o, _): &(crate::lower::model::Pos_, Nat, crate::lower::model::OutTy, Text)| answer_arm_f(&wx_p6, pos_p2m, id_p2n, t_p2o))), &crate::prelude::each(&crate::prelude::filter(&wx_p6.dyn_places_p, &(|(pos_p2p, _, _, _): &(crate::lower::model::Pos_, Text, crate::lower::model::OutTy, Text)| emits_f(&wx_p6, pos_p2p))), &(|(pos_p2q, f_p2r, t_p2s, _): &(crate::lower::model::Pos_, Text, crate::lower::model::OutTy, Text)| dyn_answer_arm_f(&sinks_pf, pos_p2q, f_p2r, t_p2s))));
    let forwards_p10 = crate::prelude::append(&crate::prelude::each(&crate::prelude::filter(&wx_p6.builders_p, &(|b_p2t: &crate::lower::model::ForDef| emits_f(&wx_p6, &b_p2t.pos_p))), &(|b_p2u: &crate::lower::model::ForDef| (pos_pat_f(&b_p2u.pos_p, &key_tail_p()), forward_answer_f(b_p2u)))), &crate::prelude::fold(&crate::prelude::filter(&wx_p6.gens_p, &(|gd_p2v: &crate::lower::model::GenDef| emits_f(&wx_p6, &gd_p2v.pos_p))), &Array::new(), &(|acc_p30: &Array<(crate::lower::model::Pa, crate::lower::model::Ex)>, gd_p31: &crate::lower::model::GenDef| crate::prelude::append(acc_p30, &crate::lower::node_::switch_::gen_forwards_f(gd_p31)))));
    let host_methods_p11 = crate::prelude::fold(&wx_p6.hosts_p, &Array::new(), &(|acc_p32: &Array<crate::lower::model::MethDef>, h_p33: &crate::lower::node_::HostDef| crate::prelude::append(acc_p32, &Array::from(vec![typed_dispatch_f(&sinks_pf, &Text::from(format!("{}_answer", &h_p33.name_p)), &h_p33.scope_p), host_moved_f(&sinks_pf, h_p33)]))));
    let gathered_p12 = crate::prelude::filter(&wx_p6.snaps_p, &(|sn_p34: &crate::lower::node_::SnapDef| !(sn_p34.before_p || is_generation_f(&wx_p6, &sn_p34.builder_p))));
    let gathered_moved_p13 = crate::prelude::append(&crate::prelude::append(&crate::prelude::each(&gathered_p12, &(|sn_p35: &crate::lower::node_::SnapDef| gathered_moved_f(sn_p35))), &crate::prelude::each(&wx_p6.snaps_p, &(|sn_p36: &crate::lower::node_::SnapDef| snap_publish_f(&sinks_pf, sn_p36)))), &flatten_methods_f(&sinks_pf));
    let hosted_methods_p14 = match &wx_p6.hosted_by_o {
        Some(_) => Array::from(vec![typed_dispatch_f(&sinks_pf, &Text::lit("deliver"), &Nat::from(0u32)), document_getter_f(&wx_p6)]),
        None => Array::new(),
    };
    let moved_method_p15 = match &wx_p6.hosted_by_o {
        Some(m_p37) => Array::from(vec![document_moved_f(m_p37)]),
        None => Array::new(),
    };
    let row_methods_p16 = if *is_row_p3 { row_methods_f(&wx_p6) } else { Array::new() };
    let heard_build_f17 = {
        let wx_p6x = wx_p6.clone();
        let sinks_pfx = sinks_pf.clone();
        Rc::new(move |m_p38: &Text| {
            let stales_p39 = crate::prelude::fold(&wx_p6x.gen_holds_p, &Array::new(), &(|acc_p3b: &Array<crate::lower::model::Do>, (gname_p3c, hs_p3d): &(Text, Array<crate::lower::node_::Read>)| if crate::lower::node_::has_read_f(&reads_closed_f(&wx_p6x.dyn_reads_p, hs_p3d), &crate::lower::node_::Read::ParentRead(m_p38.clone())) {
                crate::prelude::push(acc_p3b, &crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_stale", gname_p3c)))), Text::lit("set"), Array::from(vec![crate::lower::model::Ex::XBool(true)]))))
            } else {
                acc_p3b.clone()
            }));
            let builds_p3a = crate::lower::node_::has_read_f(&sinks_pfx.builds_p, &crate::lower::node_::Read::ParentRead(m_p38.clone())) || (&crate::prelude::len(&stales_p39) > &Nat::from(0u32));
            if builds_p3a && !lists_build_f(&sinks_pfx, &crate::lower::node_::Read::ParentRead(m_p38.clone())) {
                crate::prelude::append(&stales_p39, &Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCx), Text::lit("build_later"), Array::from(vec![crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XSelf))])))]))
            } else {
                stales_p39.clone()
            }
        }) as Rc<dyn Fn(&Text) -> Array<crate::lower::model::Do>>
    };
    let heard_p18 = crate::prelude::each(&row_hears_f(&wx_p6), &(|m_p3e: &Text| crate::lower::model::MethDef { name_p: Text::from(format!("parent_wrote_{}", m_p3e)), recv_p: crate::lower::model::Recv::RecvRc, params_p: Array::new(), cx_p: crate::lower::model::CxArg::CxMut, ret_p: crate::lower::model::OutTy::OutUnit, body_p: crate::prelude::append(&crate::prelude::append(&moved_by_f(&sinks_pf, &crate::lower::node_::Read::ParentRead(m_p3e.clone())), &(&heard_build_f17)(m_p3e)), &crate::prelude::fold(&wx_p6.row_marks_p, &Array::new(), &(|acc_p3f: &Array<crate::lower::model::Do>, rm_p3g: &crate::lower::node_::RowMarks| crate::prelude::append(acc_p3f, &row_written_f(&wx_p6, rm_p3g, &crate::lower::node_::Read::ParentRead(m_p3e.clone())))))), tail_p: crate::lower::model::Ex::XUnit, doc_p: Text::from(format!("The block wrote behind its `{}`, which this row reads through the parent: the `!Updated` nodes over it are told and the wake asked at their heights; the row\'s own builders over it are listed for the build; the rows of this row\'s own `for`s that read it are marked.", m_p3e)) }));
    let top_p19 = crate::prelude::fold(&wx_p6.gns_p, &Nat::from(0u32), &(|hi_p3h: &Nat, g_p3i: &crate::lower::node_::Gn| crate::prelude::max(hi_p3h, &g_p3i.height_p)));
    let wakes_field_p1a = if many_p9 {
        Array::from(vec![(Text::lit("wakes"), crate::lower::model::OutTy::OutWakes, Text::lit("the heights asked for this tick, lowest first"))])
    } else {
        Array::new()
    };
    let wakes_init_p1b = if many_p9 {
        Array::from(vec![(Text::lit("wakes"), crate::lower::model::Ex::XCall(Text::lit("Wakes::default"), Array::new()))])
    } else {
        Array::new()
    };
    let gen_fields_p1c = crate::prelude::fold(&wx_p6.gens_p, &Array::new(), &(|acc_p3j: &Array<(Text, crate::lower::model::OutTy, Text)>, gd_p3k: &crate::lower::model::GenDef| crate::prelude::append(acc_p3j, &Array::from(vec![(gd_p3k.name_p.clone(), crate::lower::model::OutTy::OutCell(Rc::new(crate::lower::model::OutTy::OutOpt(Rc::new(crate::lower::model::OutTy::OutObj(Rc::new(crate::lower::model::OutTy::OutNamed(Text::lit("Row"), Array::new()))))))), Text::from(format!("the current generation of the `rebuild` at place {}", &crate::lower::model::place_text_f(&gd_p3k.pos_p)))), (Text::from(format!("{}_count", &gd_p3k.name_p)), crate::lower::model::OutTy::OutNamed(Text::lit("Cell"), Array::from(vec![crate::lower::model::OutTy::OutCount])), Text::lit("how many generations it has built")), (Text::from(format!("{}_stale", &gd_p3k.name_p)), crate::lower::model::OutTy::OutNamed(Text::lit("Cell"), Array::from(vec![crate::lower::model::OutTy::OutBool])), Text::lit("its source changed since it was built"))]))));
    let gen_inits_p1d = crate::prelude::fold(&wx_p6.gens_p, &Array::new(), &(|acc_p3l: &Array<(Text, crate::lower::model::Ex)>, gd_p3m: &crate::lower::model::GenDef| crate::prelude::append(acc_p3l, &Array::from(vec![(gd_p3m.name_p.clone(), crate::lower::model::Ex::XCall(Text::lit("RefCell::new"), Array::from(vec![crate::lower::model::Ex::XNone]))), (Text::from(format!("{}_count", &gd_p3m.name_p)), crate::lower::model::Ex::XCall(Text::lit("Cell::new"), Array::from(vec![crate::lower::model::Ex::XIndex(Nat::from(0u32))]))), (Text::from(format!("{}_stale", &gd_p3m.name_p)), crate::lower::model::Ex::XCall(Text::lit("Cell::new"), Array::from(vec![crate::lower::model::Ex::XBool(false)])))]))));
    let port_fields_p1e = crate::prelude::each(&wx_p6.ports_p, &(|pn_p3n: &Text| (Text::from(format!("{}_port", pn_p3n)), crate::lower::model::OutTy::OutPort(Rc::new(crate::lower::node_::keyed::gn_ty_named_f(&wx_p6, pn_p3n))), Text::from(format!("`!{}`, which rows subscribe to", pn_p3n)))));
    let port_inits_p1f = crate::prelude::each(&wx_p6.ports_p, &(|pn_p3o: &Text| (Text::from(format!("{}_port", pn_p3o)), crate::lower::model::Ex::XCall(Text::lit("Port::new"), Array::new()))));
    let sub_fields_p1g = crate::prelude::each(&wx_p6.subs_p, &(|(ev_p3p, m_p3q, t_p3r): &(Text, Text, crate::lower::model::OutTy)| (Text::from(format!("{}_sub", m_p3q)), crate::lower::model::OutTy::OutNamed(Text::lit("Cell"), Array::from(vec![crate::lower::model::OutTy::OutOpt(Rc::new(crate::lower::model::OutTy::OutNamed(Text::lit("Handle"), Array::new())))])), Text::from(format!("the subscription to the parent\'s `!{}`", ev_p3p)))));
    let sub_inits_p1h = crate::prelude::each(&wx_p6.subs_p, &(|(ev_p3s, m_p3t, t_p3u): &(Text, Text, crate::lower::model::OutTy)| (Text::from(format!("{}_sub", m_p3t)), crate::lower::model::Ex::XCall(Text::lit("Cell::new"), Array::from(vec![crate::lower::model::Ex::XNone])))));
    let fallible_p1i = ((wx_p6.fallible_p || *is_row_p3) || (&crate::prelude::len(&wx_p6.builders_p) > &Nat::from(0u32))) || (&crate::prelude::len(&wx_p6.gens_p) > &Nat::from(0u32));
    crate::lower::model::NodeDef { name_p: wx_p6.node_p.clone(), prism_p: crate::check::types::bare_name_f(qk_p1), doc_p: crate::lower::functions::definition_text_f(&wx_p6.lx_p, qk_p1), params_p: params_p2.clone(), fields_p: crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&wx_p6.fields_p, &wakes_field_p1a), &gen_fields_p1c), &port_fields_p1e), &sub_fields_p1g), consts_p: consts_pa.clone(), lets_p: wx_p6.lets_p.clone(), inits_p: crate::prelude::append(&wx_p6.inits_p, &crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&wx_p6.moves_p, &wakes_init_p1b), &gen_inits_p1d), &port_inits_p1f), &sub_inits_p1h)), build_p: crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&rows_built_pt, &wx_p6.build_p), &subscribed_pu), &started_reg_pr), fallible_p: fallible_p1i, methods_p: crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&ev_methods_pg, &gather_ins_ph), &place_getters_pi), &wx_p6.getters_p), &row_methods_p16), &heard_p18), &host_methods_p11), &gathered_moved_p13), &moved_method_p15), answers_p: crate::prelude::append(&answers_pv, &forwards_p10), hooks_p: hooks_pq.clone(), builders_p: wx_p6.builders_p.clone(), wakes_p: many_p9, children_p: wx_p6.rows_p.clone(), gens_p: wx_p6.gens_p.clone(), subs_p: wx_p6.subs_p.clone(), top_p: top_p19.clone(), row_kind_p: if *is_row_p3 {
        if is_gen_p5 {
            crate::lower::model::RowKind::GenerationRow
        } else {
            crate::lower::model::RowKind::ForRow
        }
    } else {
        crate::lower::model::RowKind::NotARow
    }, hosted_p: hosted_methods_p14.clone() }
}

/// The step machine of `FinishNode`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FinishNode: unbounded fn Wx, Text, [((Text, OutTy))], Bool -> NodeDef
/// ```
pub struct FinishNode {
    pub wx0_p0: crate::lower::node_::Wx,
    pub qk_p1: Text,
    pub params_p2: Array<(Text, crate::lower::model::OutTy)>,
    pub is_row_p3: bool,
}

impl prism_rtl::Job<crate::lower::model::NodeDef> for FinishNode {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::NodeDef> {
        let wx0_p0 = &self.wx0_p0;
        let qk_p1 = &self.qk_p1;
        let params_p2 = &self.params_p2;
        let is_row_p3 = &self.is_row_p3;
        let closed_gns_p4 = crate::prelude::each(&wx0_p0.gns_p, &(|g_p1j: &crate::lower::node_::Gn| if &g_p1j.kind_p == &crate::lower::node_::GnKind::GnUpdated {
            crate::lower::node_::dynamics::with_reads_f(g_p1j, &reads_closed_f(&wx0_p0.dyn_reads_p, &g_p1j.reads_p))
        } else {
            g_p1j.clone()
        }));
        let is_row_p3x = *is_row_p3;
        let params_p2x = params_p2.clone();
        let qk_p1x = qk_p1.clone();
        let wx0_p0x = wx0_p0.clone();
        crate::prelude::call_then(start_finish_pending_f(wx0_p0x.clone(), heights_f(&closed_gns_p4)), move |finish_pending_f_14117: (Array<crate::lower::model::NodeDef>, Array<crate::lower::node_::Gn>)| {
            let (row_defs_p1k, gns2_p1l) = finish_pending_f_14117;
            let is_gen_p5 = is_row_p3x && (&crate::prelude::len(&crate::prelude::filter(&wx0_p0x.fields_p, &(|(f_p1m, _, _): &(Text, crate::lower::model::OutTy, Text)| f_p1m == &Text::lit("key")))) == &Nat::from(0u32));
            let wx_p6 = {
                let mut this: crate::lower::node_::Wx = wx0_p0x.clone();
                this.gns_p = heights_f(&gns2_p1l);
                this.build_p = crate::prelude::append(&this.build_p, &updated_gaps_f(&wx0_p0x, &closed_gns_p4, &is_gen_p5));
                this.rows_p = crate::prelude::fold(&row_defs_p1k, &this.rows_p, &(|acc_p1n: &Array<crate::lower::model::NodeDef>, rd_p1o: &crate::lower::model::NodeDef| crate::prelude::append(&crate::prelude::push(acc_p1n, rd_p1o), &rd_p1o.children_p)));
                this
            };
            let combs_p7 = crate::prelude::filter(&wx_p6.gns_p, &(|g_p1p: &crate::lower::node_::Gn| is_comb_f(&g_p1p.kind_p) || (&g_p1p.kind_p == &crate::lower::node_::GnKind::GnGather)));
            let heights_p8 = sort_nats_f(&crate::prelude::fold(&combs_p7, &Array::new(), &(|acc_p1q: &Array<Nat>, g_p1r: &crate::lower::node_::Gn| crate::check::types::add_nat_f(acc_p1q, &g_p1r.height_p))));
            let many_p9 = &crate::prelude::len(&heights_p8) > &Nat::from(1u32);
            let consts_pa = crate::prelude::each(&heights_p8, &(|h_p1s: &Nat| (wake_const_f(&heights_p8, h_p1s), h_p1s.clone(), Text::lit("merges\' height above the node\'s inputs"))));
            let live_pb = crate::prelude::filter(&wx_p6.places_p, &(|p_p1t: &crate::lower::node_::Place| &p_p1t.getter_p != &Text::lit("")));
            let root_reads_pc = match &wx_p6.root_dyn_o {
                Some((_, rds_p1u, _)) => reads_closed_f(&wx_p6.dyn_reads_p, rds_p1u),
                None => Array::new(),
            };
            let dirty_holds_pd = crate::prelude::fold(&live_pb, &root_reads_pc, &(|acc_p1v: &Array<crate::lower::node_::Read>, p_p20: &crate::lower::node_::Place| crate::lower::node_::union_reads_f(acc_p1v, &reads_closed_f(&wx_p6.dyn_reads_p, &p_p20.reads_p))));
            let build_holds_pe = reads_closed_f(&wx_p6.dyn_reads_p, &wx_p6.build_holds_p);
            let sinks_pf = Sinks { wx_p: wx_p6.clone(), dirty_p: dirty_holds_pd.clone(), builds_p: build_holds_pe.clone(), heights_p: heights_p8.clone(), many_p: many_p9 };
            crate::prelude::call_value(crate::prelude::each_job(crate::prelude::filter(&wx_p6.gns_p, &(|g_p21: &crate::lower::node_::Gn| &g_p21.kind_p != &crate::lower::node_::GnKind::GnNever)), {
                let sinks_pfx = sinks_pf.clone();
                Rc::new(move |p0: crate::lower::node_::Gn| {
                    let sinks_pfxy = sinks_pfx.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let g_p22 = p0;
                        crate::prelude::call_then(start_firing_code_f(sinks_pfxy.clone(), g_p22.clone(), crate::lower::model::Ex::XVar(Text::lit("v"))), move |firing_code_f_15352: Array<crate::lower::model::Do>| prism_rtl::Turn::Finished(crate::lower::model::MethDef { name_p: g_p22.name_p.clone(), recv_p: crate::lower::model::Recv::RecvRc, params_p: Array::from(vec![(Text::lit("v"), g_p22.ty_p.clone())]), cx_p: crate::lower::model::CxArg::CxMut, ret_p: crate::lower::model::OutTy::OutUnit, body_p: firing_code_f_15352, tail_p: crate::lower::model::Ex::XUnit, doc_p: gn_doc_f(&g_p22) }))
                    }))
                }) as Rc<dyn Fn(crate::lower::node_::Gn) -> Rc<dyn prism_rtl::Job<crate::lower::model::MethDef>>>
            }), move |each_15212: Array<crate::lower::model::MethDef>| {
                let ev_methods_pg = each_15212;
                let gather_ins_ph = crate::prelude::each(&crate::prelude::filter(&wx_p6.gns_p, &(|g_p23: &crate::lower::node_::Gn| &g_p23.kind_p == &crate::lower::node_::GnKind::GnGather)), &(|g_p24: &crate::lower::node_::Gn| gather_in_f(&sinks_pf, g_p24)));
                let place_getters_pi = crate::prelude::each(&live_pb, &(|p_p25: &crate::lower::node_::Place| crate::lower::model::MethDef { name_p: p_p25.getter_p.clone(), recv_p: crate::lower::model::Recv::RecvRef, params_p: Array::new(), cx_p: crate::lower::model::CxArg::CxRef, ret_p: crate::lower::types::elem_ty_p(), body_p: Array::new(), tail_p: p_p25.level_p.clone(), doc_p: Text::from(format!("Place {}\'s level, read at the read point.", &crate::lower::model::place_text_f(&p_p25.pos_p))) }));
                let wake_body_pj = if many_p9 {
                    Array::from(vec![wake_by_height_f(&combs_p7, &heights_p8)])
                } else {
                    crate::prelude::each(&combs_p7, &(|g_p26: &crate::lower::node_::Gn| decide_f(g_p26)))
                };
                let started_body_pk = crate::prelude::each(&wx_p6.started_p, &(|st_p27: &Nat| self_call_f(&crate::lower::node_::gn_of_f(&wx_p6, st_p27).name_p, &Array::from(vec![crate::lower::model::Ex::XUnit]))));
                let deferred_body_pl = crate::prelude::each(&wx_p6.defers_p, &(|(f_p28, id_p29): &(Text, Nat)| crate::lower::model::Do::DoIfLet(crate::lower::model::Pa::PaCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("v"))])), crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", f_p28)))), Text::lit("fired"), Array::from(vec![crate::lower::model::Ex::XCx])), Array::from(vec![self_call_f(&crate::lower::node_::gn_of_f(&wx_p6, id_p29).name_p, &Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("v"))]))]), Array::new())));
                let patch_body0_pm = crate::prelude::fold(&live_pb, &Array::new(), &(|acc_p2a: &Array<crate::lower::model::Do>, p_p2b: &crate::lower::node_::Place| crate::prelude::append(acc_p2a, &(if emits_f(&wx_p6, &p_p2b.pos_p) {
                    patch_place_f(&wx_p6, p_p2b)
                } else {
                    Array::from(vec![entry_take_f(&crate::lower::model::Ex::XSelf, p_p2b)])
                }))));
                let patch_body_pn = crate::prelude::append(&patch_body0_pm, &root_dyn_patch_f(&wx_p6));
                let build_body_po = build_steps_f(&sinks_pf, &false);
                let push_body_pp = crate::prelude::each(&crate::prelude::filter(&wx_p6.dyn_places_p, &(|(pos_p2c, _, _, _): &(crate::lower::model::Pos_, Text, crate::lower::model::OutTy, Text)| emits_f(&wx_p6, pos_p2c))), &(|(pos_p2d, f_p2e, t_p2f, _): &(crate::lower::model::Pos_, Text, crate::lower::model::OutTy, Text)| crate::lower::model::Do::DoIf(crate::lower::model::Ex::XBin(crate::lower::model::BinOp::OpEq, Rc::new(crate::lower::model::Ex::XVar(Text::lit("element"))), Rc::new(crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_element", f_p2e))))))), dyn_place_write_f(&sinks_pf, f_p2e, &crate::lower::model::Ex::XDecode(t_p2f.clone(), Rc::new(crate::lower::model::Ex::XVar(Text::lit("v"))))), Array::new())));
                let hooks_pq = crate::prelude::filter(&Array::from(vec![(Text::lit("wake"), wake_body_pj.clone()), (Text::lit("started"), started_body_pk.clone()), (Text::lit("deferred"), deferred_body_pl.clone()), (Text::lit("build"), build_body_po.clone()), (Text::lit("push"), push_body_pp.clone()), (Text::lit("patch"), patch_body_pn.clone())]), &(|(_, b_p2g): &(Text, Array<crate::lower::model::Do>)| &crate::prelude::len(b_p2g) > &Nat::from(0u32)));
                let started_reg_pr = if &crate::prelude::len(&wx_p6.started_p) > &Nat::from(0u32) {
                    Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCx), Text::lit("on_started"), Array::from(vec![crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(Text::lit("node"))))])))])
                } else {
                    Array::new()
                };
                let links_ps = crate::prelude::each(&wx_p6.hosts_p, &(|h_p2h: &crate::lower::node_::HostDef| crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XVar(Text::lit("node"))), Text::from(format!("{}", &h_p2h.name_p)))), Text::lit("link"), Array::from(vec![crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XVar(Text::lit("node"))))])))));
                let rows_built_pt = crate::prelude::append(&links_ps, &build_steps_f(&sinks_pf, &true));
                let subscribed_pu = crate::prelude::each(&wx_p6.subs_p, &(|(ev_p2i, m_p2j, t_p2k): &(Text, Text, crate::lower::model::OutTy)| crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XCall(crate::lower::helper_f(&Text::lit("subscribe_row")), Array::from(vec![crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XVar(Text::lit("node")))), crate::lower::model::Ex::XUpgrade(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XVar(Text::lit("node"))), Text::lit("parent")))), crate::lower::model::Ex::XClosure(false, Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("p"))]), Rc::new(crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XVar(Text::lit("p"))), Text::from(format!("{}_port", ev_p2i))))))), crate::lower::model::Ex::XClosure(false, Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("n")), crate::lower::model::Pa::PaBind(Text::lit("v")), crate::lower::model::Pa::PaBind(Text::lit("cx"))]), Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("n"))), m_p2j.clone(), Array::from(vec![crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(Text::lit("v")))), crate::lower::model::Ex::XCx])))), crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XVar(Text::lit("node"))), Text::from(format!("{}_sub", m_p2j)))))])))));
                let answers_pv = crate::prelude::append(&crate::prelude::each(&crate::prelude::filter(&wx_p6.answers_p, &(|(pos_p2l, _, _, _): &(crate::lower::model::Pos_, Nat, crate::lower::model::OutTy, Text)| emits_f(&wx_p6, pos_p2l))), &(|(pos_p2m, id_p2n, t_p2o, _): &(crate::lower::model::Pos_, Nat, crate::lower::model::OutTy, Text)| answer_arm_f(&wx_p6, pos_p2m, id_p2n, t_p2o))), &crate::prelude::each(&crate::prelude::filter(&wx_p6.dyn_places_p, &(|(pos_p2p, _, _, _): &(crate::lower::model::Pos_, Text, crate::lower::model::OutTy, Text)| emits_f(&wx_p6, pos_p2p))), &(|(pos_p2q, f_p2r, t_p2s, _): &(crate::lower::model::Pos_, Text, crate::lower::model::OutTy, Text)| dyn_answer_arm_f(&sinks_pf, pos_p2q, f_p2r, t_p2s))));
                let forwards_p10 = crate::prelude::append(&crate::prelude::each(&crate::prelude::filter(&wx_p6.builders_p, &(|b_p2t: &crate::lower::model::ForDef| emits_f(&wx_p6, &b_p2t.pos_p))), &(|b_p2u: &crate::lower::model::ForDef| (pos_pat_f(&b_p2u.pos_p, &key_tail_p()), forward_answer_f(b_p2u)))), &crate::prelude::fold(&crate::prelude::filter(&wx_p6.gens_p, &(|gd_p2v: &crate::lower::model::GenDef| emits_f(&wx_p6, &gd_p2v.pos_p))), &Array::new(), &(|acc_p30: &Array<(crate::lower::model::Pa, crate::lower::model::Ex)>, gd_p31: &crate::lower::model::GenDef| crate::prelude::append(acc_p30, &crate::lower::node_::switch_::gen_forwards_f(gd_p31)))));
                let host_methods_p11 = crate::prelude::fold(&wx_p6.hosts_p, &Array::new(), &(|acc_p32: &Array<crate::lower::model::MethDef>, h_p33: &crate::lower::node_::HostDef| crate::prelude::append(acc_p32, &Array::from(vec![typed_dispatch_f(&sinks_pf, &Text::from(format!("{}_answer", &h_p33.name_p)), &h_p33.scope_p), host_moved_f(&sinks_pf, h_p33)]))));
                let gathered_p12 = crate::prelude::filter(&wx_p6.snaps_p, &(|sn_p34: &crate::lower::node_::SnapDef| !(sn_p34.before_p || is_generation_f(&wx_p6, &sn_p34.builder_p))));
                let gathered_moved_p13 = crate::prelude::append(&crate::prelude::append(&crate::prelude::each(&gathered_p12, &(|sn_p35: &crate::lower::node_::SnapDef| gathered_moved_f(sn_p35))), &crate::prelude::each(&wx_p6.snaps_p, &(|sn_p36: &crate::lower::node_::SnapDef| snap_publish_f(&sinks_pf, sn_p36)))), &flatten_methods_f(&sinks_pf));
                let hosted_methods_p14 = match &wx_p6.hosted_by_o {
                    Some(_) => Array::from(vec![typed_dispatch_f(&sinks_pf, &Text::lit("deliver"), &Nat::from(0u32)), document_getter_f(&wx_p6)]),
                    None => Array::new(),
                };
                let moved_method_p15 = match &wx_p6.hosted_by_o {
                    Some(m_p37) => Array::from(vec![document_moved_f(m_p37)]),
                    None => Array::new(),
                };
                let row_methods_p16 = if is_row_p3x { row_methods_f(&wx_p6) } else { Array::new() };
                let heard_build_f17 = {
                    let wx_p6x = wx_p6.clone();
                    let sinks_pfx = sinks_pf.clone();
                    Rc::new(move |m_p38: &Text| {
                        let stales_p39 = crate::prelude::fold(&wx_p6x.gen_holds_p, &Array::new(), &(|acc_p3b: &Array<crate::lower::model::Do>, (gname_p3c, hs_p3d): &(Text, Array<crate::lower::node_::Read>)| if crate::lower::node_::has_read_f(&reads_closed_f(&wx_p6x.dyn_reads_p, hs_p3d), &crate::lower::node_::Read::ParentRead(m_p38.clone())) {
                            crate::prelude::push(acc_p3b, &crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_stale", gname_p3c)))), Text::lit("set"), Array::from(vec![crate::lower::model::Ex::XBool(true)]))))
                        } else {
                            acc_p3b.clone()
                        }));
                        let builds_p3a = crate::lower::node_::has_read_f(&sinks_pfx.builds_p, &crate::lower::node_::Read::ParentRead(m_p38.clone())) || (&crate::prelude::len(&stales_p39) > &Nat::from(0u32));
                        if builds_p3a && !lists_build_f(&sinks_pfx, &crate::lower::node_::Read::ParentRead(m_p38.clone())) {
                            crate::prelude::append(&stales_p39, &Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCx), Text::lit("build_later"), Array::from(vec![crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XSelf))])))]))
                        } else {
                            stales_p39.clone()
                        }
                    }) as Rc<dyn Fn(&Text) -> Array<crate::lower::model::Do>>
                };
                let heard_p18 = crate::prelude::each(&row_hears_f(&wx_p6), &(|m_p3e: &Text| crate::lower::model::MethDef { name_p: Text::from(format!("parent_wrote_{}", m_p3e)), recv_p: crate::lower::model::Recv::RecvRc, params_p: Array::new(), cx_p: crate::lower::model::CxArg::CxMut, ret_p: crate::lower::model::OutTy::OutUnit, body_p: crate::prelude::append(&crate::prelude::append(&moved_by_f(&sinks_pf, &crate::lower::node_::Read::ParentRead(m_p3e.clone())), &(&heard_build_f17)(m_p3e)), &crate::prelude::fold(&wx_p6.row_marks_p, &Array::new(), &(|acc_p3f: &Array<crate::lower::model::Do>, rm_p3g: &crate::lower::node_::RowMarks| crate::prelude::append(acc_p3f, &row_written_f(&wx_p6, rm_p3g, &crate::lower::node_::Read::ParentRead(m_p3e.clone())))))), tail_p: crate::lower::model::Ex::XUnit, doc_p: Text::from(format!("The block wrote behind its `{}`, which this row reads through the parent: the `!Updated` nodes over it are told and the wake asked at their heights; the row\'s own builders over it are listed for the build; the rows of this row\'s own `for`s that read it are marked.", m_p3e)) }));
                let top_p19 = crate::prelude::fold(&wx_p6.gns_p, &Nat::from(0u32), &(|hi_p3h: &Nat, g_p3i: &crate::lower::node_::Gn| crate::prelude::max(hi_p3h, &g_p3i.height_p)));
                let wakes_field_p1a = if many_p9 {
                    Array::from(vec![(Text::lit("wakes"), crate::lower::model::OutTy::OutWakes, Text::lit("the heights asked for this tick, lowest first"))])
                } else {
                    Array::new()
                };
                let wakes_init_p1b = if many_p9 {
                    Array::from(vec![(Text::lit("wakes"), crate::lower::model::Ex::XCall(Text::lit("Wakes::default"), Array::new()))])
                } else {
                    Array::new()
                };
                let gen_fields_p1c = crate::prelude::fold(&wx_p6.gens_p, &Array::new(), &(|acc_p3j: &Array<(Text, crate::lower::model::OutTy, Text)>, gd_p3k: &crate::lower::model::GenDef| crate::prelude::append(acc_p3j, &Array::from(vec![(gd_p3k.name_p.clone(), crate::lower::model::OutTy::OutCell(Rc::new(crate::lower::model::OutTy::OutOpt(Rc::new(crate::lower::model::OutTy::OutObj(Rc::new(crate::lower::model::OutTy::OutNamed(Text::lit("Row"), Array::new()))))))), Text::from(format!("the current generation of the `rebuild` at place {}", &crate::lower::model::place_text_f(&gd_p3k.pos_p)))), (Text::from(format!("{}_count", &gd_p3k.name_p)), crate::lower::model::OutTy::OutNamed(Text::lit("Cell"), Array::from(vec![crate::lower::model::OutTy::OutCount])), Text::lit("how many generations it has built")), (Text::from(format!("{}_stale", &gd_p3k.name_p)), crate::lower::model::OutTy::OutNamed(Text::lit("Cell"), Array::from(vec![crate::lower::model::OutTy::OutBool])), Text::lit("its source changed since it was built"))]))));
                let gen_inits_p1d = crate::prelude::fold(&wx_p6.gens_p, &Array::new(), &(|acc_p3l: &Array<(Text, crate::lower::model::Ex)>, gd_p3m: &crate::lower::model::GenDef| crate::prelude::append(acc_p3l, &Array::from(vec![(gd_p3m.name_p.clone(), crate::lower::model::Ex::XCall(Text::lit("RefCell::new"), Array::from(vec![crate::lower::model::Ex::XNone]))), (Text::from(format!("{}_count", &gd_p3m.name_p)), crate::lower::model::Ex::XCall(Text::lit("Cell::new"), Array::from(vec![crate::lower::model::Ex::XIndex(Nat::from(0u32))]))), (Text::from(format!("{}_stale", &gd_p3m.name_p)), crate::lower::model::Ex::XCall(Text::lit("Cell::new"), Array::from(vec![crate::lower::model::Ex::XBool(false)])))]))));
                let port_fields_p1e = crate::prelude::each(&wx_p6.ports_p, &(|pn_p3n: &Text| (Text::from(format!("{}_port", pn_p3n)), crate::lower::model::OutTy::OutPort(Rc::new(crate::lower::node_::keyed::gn_ty_named_f(&wx_p6, pn_p3n))), Text::from(format!("`!{}`, which rows subscribe to", pn_p3n)))));
                let port_inits_p1f = crate::prelude::each(&wx_p6.ports_p, &(|pn_p3o: &Text| (Text::from(format!("{}_port", pn_p3o)), crate::lower::model::Ex::XCall(Text::lit("Port::new"), Array::new()))));
                let sub_fields_p1g = crate::prelude::each(&wx_p6.subs_p, &(|(ev_p3p, m_p3q, t_p3r): &(Text, Text, crate::lower::model::OutTy)| (Text::from(format!("{}_sub", m_p3q)), crate::lower::model::OutTy::OutNamed(Text::lit("Cell"), Array::from(vec![crate::lower::model::OutTy::OutOpt(Rc::new(crate::lower::model::OutTy::OutNamed(Text::lit("Handle"), Array::new())))])), Text::from(format!("the subscription to the parent\'s `!{}`", ev_p3p)))));
                let sub_inits_p1h = crate::prelude::each(&wx_p6.subs_p, &(|(ev_p3s, m_p3t, t_p3u): &(Text, Text, crate::lower::model::OutTy)| (Text::from(format!("{}_sub", m_p3t)), crate::lower::model::Ex::XCall(Text::lit("Cell::new"), Array::from(vec![crate::lower::model::Ex::XNone])))));
                let fallible_p1i = ((wx_p6.fallible_p || is_row_p3x) || (&crate::prelude::len(&wx_p6.builders_p) > &Nat::from(0u32))) || (&crate::prelude::len(&wx_p6.gens_p) > &Nat::from(0u32));
                prism_rtl::Turn::Finished(crate::lower::model::NodeDef { name_p: wx_p6.node_p.clone(), prism_p: crate::check::types::bare_name_f(&qk_p1x), doc_p: crate::lower::functions::definition_text_f(&wx_p6.lx_p, &qk_p1x), params_p: params_p2x.clone(), fields_p: crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&wx_p6.fields_p, &wakes_field_p1a), &gen_fields_p1c), &port_fields_p1e), &sub_fields_p1g), consts_p: consts_pa.clone(), lets_p: wx_p6.lets_p.clone(), inits_p: crate::prelude::append(&wx_p6.inits_p, &crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&wx_p6.moves_p, &wakes_init_p1b), &gen_inits_p1d), &port_inits_p1f), &sub_inits_p1h)), build_p: crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&rows_built_pt, &wx_p6.build_p), &subscribed_pu), &started_reg_pr), fallible_p: fallible_p1i, methods_p: crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&ev_methods_pg, &gather_ins_ph), &place_getters_pi), &wx_p6.getters_p), &row_methods_p16), &heard_p18), &host_methods_p11), &gathered_moved_p13), &moved_method_p15), answers_p: crate::prelude::append(&answers_pv, &forwards_p10), hooks_p: hooks_pq.clone(), builders_p: wx_p6.builders_p.clone(), wakes_p: many_p9, children_p: wx_p6.rows_p.clone(), gens_p: wx_p6.gens_p.clone(), subs_p: wx_p6.subs_p.clone(), top_p: top_p19.clone(), row_kind_p: if is_row_p3x {
                    if is_gen_p5 {
                        crate::lower::model::RowKind::GenerationRow
                    } else {
                        crate::lower::model::RowKind::ForRow
                    }
                } else {
                    crate::lower::model::RowKind::NotARow
                }, hosted_p: hosted_methods_p14.clone() })
            })
        })
    }
}

/// `Start FinishNode, x`: what the function value is when passed to `@Run`.
pub fn start_finish_node_f(wx0_p0: crate::lower::node_::Wx, qk_p1: Text, params_p2: Array<(Text, crate::lower::model::OutTy)>, is_row_p3: bool) -> Rc<dyn prism_rtl::Job<crate::lower::model::NodeDef>> {
    Rc::new(FinishNode { wx0_p0, qk_p1, params_p2, is_row_p3 })
}

/// ```prism
/// IsGeneration: fn Wx, Text -> Bool
/// ```
pub fn is_generation_f(wx_p0: &crate::lower::node_::Wx, name_p1: &Text) -> bool {
    &crate::prelude::len(&crate::prelude::filter(&wx_p0.gens_p, &(|gd_p2: &crate::lower::model::GenDef| &gd_p2.name_p == name_p1))) > &Nat::from(0u32)
}

/// ```prism
/// FlattenMethods: fn Sinks -> [MethDef]
/// ```
pub fn flatten_methods_f(sk_p0: &Sinks) -> Array<crate::lower::model::MethDef> {
    let wx_p1 = sk_p0.wx_p.clone();
    let entries_p2 = crate::prelude::fold(&crate::prelude::filter(&wx_p1.flattens_p, &(|fl_p7: &crate::lower::node_::FlatDef| &fl_p7.generation_p == &Text::lit(""))), &Array::new(), &(|acc_p8: &Array<crate::lower::model::MethDef>, fl_p9: &crate::lower::node_::FlatDef| {
        let set_pa = crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_inner", &fl_p9.name_p)))), Text::lit("set"), Array::from(vec![crate::lower::model::Ex::XCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XSelf), Text::lit("entry"), Array::from(vec![crate::lower::model::Ex::XCx]))])), crate::lower::model::Ex::XCx])));
        let followed_pb = crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_follow", &fl_p9.name_p)))), Text::lit("follow"), Array::from(vec![crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XSelf), Text::lit("entry"), Array::from(vec![crate::lower::model::Ex::XCx]))), Text::lit("updates")))), crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XSelf)))), crate::lower::model::Ex::XPath(Text::from(format!("{}::{}_moved", &wx_p1.node_p, &fl_p9.name_p)))])));
        let moved_pc = crate::lower::model::MethDef { name_p: Text::from(format!("{}_moved", &fl_p9.name_p)), recv_p: crate::lower::model::Recv::RecvRc, params_p: Array::new(), cx_p: crate::lower::model::CxArg::CxMut, ret_p: crate::lower::model::OutTy::OutUnit, body_p: hold_written_f(sk_p0, &Text::from(format!("{}_inner", &fl_p9.name_p))), tail_p: crate::lower::model::Ex::XUnit, doc_p: Text::from(format!("`{}`\'s inner moved: what reads it reads it again.", &fl_p9.name_p)) };
        let replaced_pd = crate::lower::model::MethDef { name_p: Text::from(format!("{}_replaced", &fl_p9.name_p)), recv_p: crate::lower::model::Recv::RecvRc, params_p: Array::new(), cx_p: crate::lower::model::CxArg::CxMut, ret_p: crate::lower::model::OutTy::OutUnit, body_p: adoption_f(fl_p9), tail_p: crate::lower::model::Ex::XUnit, doc_p: Text::from(format!("The `for`\'s builder found another dynamic than `{}`\'s inner under this row\'s key: the adoption is queued for the first firings of the next tick, which is owed (Semantics ch. 4).", &fl_p9.name_p)) };
        let adopt_pe = crate::lower::model::MethDef { name_p: Text::from(format!("{}_adopt", &fl_p9.name_p)), recv_p: crate::lower::model::Recv::RecvRc, params_p: Array::new(), cx_p: crate::lower::model::CxArg::CxMut, ret_p: crate::lower::model::OutTy::OutUnit, body_p: crate::prelude::append(&Array::from(vec![set_pa.clone(), followed_pb.clone()]), &hold_written_f(sk_p0, &Text::from(format!("{}_inner", &fl_p9.name_p)))), tail_p: crate::lower::model::Ex::XUnit, doc_p: Text::from(format!("`{}` adopts the dynamic under its row\'s key as the tick before left it, among this tick\'s first firings: from here on it reads that inner (Semantics ch. 4).", &fl_p9.name_p)) };
        crate::prelude::append(acc_p8, &Array::from(vec![moved_pc.clone(), replaced_pd.clone(), adopt_pe.clone()]))
    }));
    let adopts0_p3 = crate::prelude::each(&crate::prelude::filter(&wx_p1.flattens_p, &(|fl_pf: &crate::lower::node_::FlatDef| &fl_pf.generation_p != &Text::lit(""))), &(|fl_pg: &crate::lower::node_::FlatDef| {
        let set_ph = crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_inner", &fl_pg.name_p)))), Text::lit("set"), Array::from(vec![crate::lower::model::Ex::XCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XSelf), fl_pg.outer_p.clone(), Array::from(vec![crate::lower::model::Ex::XCx]))])), crate::lower::model::Ex::XCx])));
        crate::lower::model::MethDef { name_p: Text::from(format!("{}_adopt", &fl_pg.name_p)), recv_p: crate::lower::model::Recv::RecvRc, params_p: Array::new(), cx_p: crate::lower::model::CxArg::CxMut, ret_p: crate::lower::model::OutTy::OutUnit, body_p: crate::prelude::append(&Array::from(vec![set_ph.clone()]), &hold_written_f(sk_p0, &Text::from(format!("{}_inner", &fl_pg.name_p)))), tail_p: crate::lower::model::Ex::XUnit, doc_p: Text::lit("`@Flatten` adopts the inner its `rebuild`\'s dynamic held after the tick before, among this tick\'s first firings: from here on it reads that inner (Semantics ch. 7).") }
    }));
    let adopts_p4 = crate::prelude::append(&adopts0_p3, &entries_p2);
    let dyn_gens_p5 = crate::prelude::filter(&wx_p1.gens_p, &(|gd_pi: &crate::lower::model::GenDef| &crate::prelude::len(&crate::prelude::filter(&wx_p1.snaps_p, &(|sn_pj: &crate::lower::node_::SnapDef| &sn_pj.builder_p == &gd_pi.name_p))) > &Nat::from(0u32)));
    let moved_p6 = crate::prelude::each(&dyn_gens_p5, &(|gd_pk: &crate::lower::model::GenDef| {
        let marks_pl = crate::prelude::fold(&crate::prelude::filter(&wx_p1.flattens_p, &(|fl_pq: &crate::lower::node_::FlatDef| &fl_pq.generation_p == &gd_pk.name_p)), &Array::new(), &(|acc_pr: &Array<crate::lower::model::Do>, fl_ps: &crate::lower::node_::FlatDef| crate::prelude::append(acc_pr, &hold_written_f(sk_p0, &Text::from(format!("{}_inner", &fl_ps.name_p))))));
        let live_pm = crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_result_live", &gd_pk.name_p)))), Text::lit("borrow"), Array::new())), Text::lit("as_ref"), Array::new());
        let port_pn = crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XVar(Text::lit("d"))), Text::lit("updates"));
        let fire_po = crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(port_pn.clone()), Text::lit("fire"), Array::from(vec![crate::lower::model::Ex::XUnit, crate::lower::model::Ex::XCx]))), Text::lit("ok"), Array::new());
        let fired_pp = crate::lower::model::Do::DoIfLet(crate::lower::model::Pa::PaCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("d"))])), live_pm.clone(), Array::from(vec![crate::lower::model::Do::DoExpr(fire_po.clone())]), Array::new());
        crate::lower::model::MethDef { name_p: Text::from(format!("{}_result_moved", &gd_pk.name_p)), recv_p: crate::lower::model::Recv::RecvRc, params_p: Array::new(), cx_p: crate::lower::model::CxArg::CxMut, ret_p: crate::lower::model::OutTy::OutUnit, body_p: crate::prelude::push(&marks_pl, &fired_pp), tail_p: crate::lower::model::Ex::XUnit, doc_p: Text::lit("The current generation\'s result moved: what reads a `@Flatten` over it reads it again, and the dynamic kept for it fires its update event for whoever follows it outside this node.") }
    }));
    crate::prelude::append(&adopts_p4, &moved_p6)
}

/// ```prism
/// HostMoved: fn Sinks, HostDef -> MethDef
/// ```
pub fn host_moved_f(sk_p0: &Sinks, h_p1: &crate::lower::node_::HostDef) -> crate::lower::model::MethDef {
    crate::lower::model::MethDef { name_p: Text::from(format!("{}_moved", &h_p1.name_p)), recv_p: crate::lower::model::Recv::RecvRc, params_p: Array::new(), cx_p: crate::lower::model::CxArg::CxMut, ret_p: crate::lower::model::OutTy::OutUnit, body_p: hold_written_f(sk_p0, &Text::from(format!("{}_doc_now", &h_p1.name_p))), tail_p: crate::lower::model::Ex::XUnit, doc_p: Text::from(format!("A node of the child hosted at place {} wrote behind its document: the structure is marked as for a write of a hold it reads (pick HO), the snapshot listed to be taken; the program\'s `$doc` moves when it is published, the tick after (pick ST).", &crate::lower::model::place_text_f(&h_p1.pos_p))) }
}

/// ```prism
/// BuildSteps: fn Sinks, Bool -> [Do]
/// ```
pub fn build_steps_f(sk_p0: &Sinks, at_build_p1: &bool) -> Array<crate::lower::model::Do> {
    let wx_p2 = sk_p0.wx_p.clone();
    let recv_p3 = if *at_build_p1 {
        crate::lower::model::Ex::XVar(Text::lit("node"))
    } else {
        crate::lower::model::Ex::XSelf
    };
    let take_f4 = {
        let at_build_p1x = *at_build_p1;
        let sk_p0x = sk_p0.clone();
        Rc::new(move |sn_p8: &crate::lower::node_::SnapDef| if at_build_p1x { snap_take_at_build_f(sn_p8) } else { snap_take_f(&sk_p0x, sn_p8) }) as Rc<dyn Fn(&crate::lower::node_::SnapDef) -> crate::lower::model::Do>
    };
    let builder_f5 = {
        let wx_p2x = wx_p2.clone();
        let take_f4x = take_f4.clone();
        let recv_p3x = recv_p3.clone();
        Rc::new(move |b_p9: &crate::lower::model::ForDef| {
            let before_pa = crate::prelude::each(&crate::prelude::filter(&wx_p2x.snaps_p, &(|sn_pc: &crate::lower::node_::SnapDef| sn_pc.before_p && (&sn_pc.builder_p == &b_p9.name_p))), &*take_f4x);
            let after_pb = crate::prelude::each(&crate::prelude::filter(&wx_p2x.snaps_p, &(|sn_pd: &crate::lower::node_::SnapDef| !sn_pd.before_p && (&sn_pd.builder_p == &b_p9.name_p))), &*take_f4x);
            crate::prelude::append(&crate::prelude::push(&before_pa, &crate::lower::model::Do::DoExpr(crate::lower::expr::try_of_f(&crate::lower::model::Ex::XMethod(Rc::new(recv_p3x.clone()), Text::from(format!("{}_build", &b_p9.name_p)), Array::from(vec![crate::lower::model::Ex::XCx]))))), &after_pb)
        }) as Rc<dyn Fn(&crate::lower::model::ForDef) -> Array<crate::lower::model::Do>>
    };
    let gen_f6 = {
        let at_build_p1x = *at_build_p1;
        let recv_p3x = recv_p3.clone();
        let wx_p2x = wx_p2.clone();
        let take_f4x = take_f4.clone();
        Rc::new(move |gd_pe: &crate::lower::model::GenDef| {
            let built_pf = if at_build_p1x {
                crate::lower::model::Do::DoExpr(crate::lower::expr::try_of_f(&crate::lower::model::Ex::XMethod(Rc::new(recv_p3x.clone()), Text::from(format!("{}_build", &gd_pe.name_p)), Array::from(vec![crate::lower::model::Ex::XCx]))))
            } else {
                crate::lower::model::Do::DoIf(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_stale", &gd_pe.name_p)))), Text::lit("replace"), Array::from(vec![crate::lower::model::Ex::XBool(false)])), Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::expr::try_of_f(&crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_build", &gd_pe.name_p)), Array::from(vec![crate::lower::model::Ex::XCx]))))]), Array::new())
            };
            crate::prelude::append(&Array::from(vec![built_pf.clone()]), &crate::prelude::each(&crate::prelude::filter(&wx_p2x.snaps_p, &(|sn_pg: &crate::lower::node_::SnapDef| !sn_pg.before_p && (&sn_pg.builder_p == &gd_pe.name_p))), &*take_f4x))
        }) as Rc<dyn Fn(&crate::lower::model::GenDef) -> Array<crate::lower::model::Do>>
    };
    let entries_f7 = {
        let at_build_p1x = *at_build_p1;
        let wx_p2x = wx_p2.clone();
        let recv_p3x = recv_p3.clone();
        Rc::new(move |k_ph: &Nat| if at_build_p1x {
            crate::prelude::each(&crate::prelude::filter(&wx_p2x.places_p, &(|pl_pi: &crate::lower::node_::Place| ((&pl_pi.pos_p.scope_p == k_ph) && (&pl_pi.entry_p != &Text::lit(""))) && (&pl_pi.getter_p != &Text::lit("")))), &(|pl_pj: &crate::lower::node_::Place| entry_take_f(&recv_p3x, pl_pj)))
        } else {
            Array::new()
        }) as Rc<dyn Fn(&Nat) -> Array<crate::lower::model::Do>>
    };
    crate::prelude::fold(&crate::check::errors::range0_f(&(&crate::prelude::len(&wx_p2.scopes_p) + &Nat::from(1u32))), &Array::new(), &(|acc_pk: &Array<crate::lower::model::Do>, i_pl: &Nat| {
        let k_pm = crate::prelude::or(&(&crate::prelude::len(&wx_p2.scopes_p)).checked_sub(i_pl), &Nat::from(0u32));
        let builders_pn = crate::prelude::fold(&crate::prelude::filter(&wx_p2.builders_p, &(|b_po: &crate::lower::model::ForDef| &b_po.pos_p.scope_p == &k_pm)), &Array::new(), &(|a_pp: &Array<crate::lower::model::Do>, b_pq: &crate::lower::model::ForDef| crate::prelude::append(a_pp, &(&builder_f5)(b_pq))));
        crate::prelude::append(&crate::prelude::append(&crate::prelude::append(acc_pk, &builders_pn), &crate::prelude::fold(&crate::prelude::filter(&wx_p2.gens_p, &(|gd_pr: &crate::lower::model::GenDef| &gd_pr.pos_p.scope_p == &k_pm)), &Array::new(), &(|a_ps: &Array<crate::lower::model::Do>, gd_pt: &crate::lower::model::GenDef| crate::prelude::append(a_ps, &(&gen_f6)(gd_pt))))), &(&entries_f7)(&k_pm))
    }))
}

/// ```prism
/// EntryTake: fn Ex, Place -> Do
/// ```
pub fn entry_take_f(recv_p0: &crate::lower::model::Ex, pl_p1: &crate::lower::node_::Place) -> crate::lower::model::Do {
    crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(recv_p0.clone()), pl_p1.entry_p.clone())), Text::lit("take"), Array::from(vec![crate::lower::model::Ex::XMethod(Rc::new(recv_p0.clone()), pl_p1.getter_p.clone(), Array::from(vec![crate::lower::model::Ex::XCx])), crate::lower::model::Ex::XCx])))
}

/// ```prism
/// SnapTakeAtBuild: fn SnapDef -> Do
/// ```
pub fn snap_take_at_build_f(sn_p0: &crate::lower::node_::SnapDef) -> crate::lower::model::Do {
    crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XVar(Text::lit("node"))), Text::from(format!("{}_snap", &sn_p0.name_p)))), Text::lit("take"), Array::from(vec![crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("node"))), Text::from(format!("{}_now", &sn_p0.name_p)), Array::from(vec![crate::lower::model::Ex::XCx])), crate::lower::model::Ex::XCx])))
}

/// ```prism
/// SnapTake: fn Sinks, SnapDef -> Do
/// ```
pub fn snap_take_f(sk_p0: &Sinks, sn_p1: &crate::lower::node_::SnapDef) -> crate::lower::model::Do {
    let now_p2 = crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_now", &sn_p1.name_p)), Array::from(vec![crate::lower::model::Ex::XCx]));
    let take_p3 = crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_snap", &sn_p1.name_p)))), if sn_p1.eq_p { Text::lit("take_compared") } else { Text::lit("take") }, Array::from(vec![now_p2.clone(), crate::lower::model::Ex::XCx])));
    let queue_p4 = crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCx), Text::lit("answer_later"), Array::from(vec![crate::lower::model::Ex::XLater(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("node"))), Text::from(format!("{}_publish", &sn_p1.name_p)), Array::from(vec![crate::lower::model::Ex::XCx]))))])));
    let queued_p5 = crate::lower::model::Do::DoIf(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_snap", &sn_p1.name_p)))), Text::lit("queue"), Array::from(vec![crate::lower::model::Ex::XCx])), Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(Text::lit("node")), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XSelf))), queue_p4.clone()]), Array::new());
    crate::lower::model::Do::DoIf(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_snap", &sn_p1.name_p)))), Text::lit("marked"), Array::from(vec![crate::lower::model::Ex::XCx])), Array::from(vec![take_p3.clone(), queued_p5.clone()]), Array::new())
}

/// ```prism
/// SnapPublish: fn Sinks, SnapDef -> MethDef
/// ```
pub fn snap_publish_f(sk_p0: &Sinks, sn_p1: &crate::lower::node_::SnapDef) -> crate::lower::model::MethDef {
    crate::lower::model::MethDef { name_p: Text::from(format!("{}_publish", &sn_p1.name_p)), recv_p: crate::lower::model::Recv::RecvRc, params_p: Array::new(), cx_p: crate::lower::model::CxArg::CxMut, ret_p: crate::lower::model::OutTy::OutUnit, body_p: Array::from(vec![crate::lower::model::Do::DoIf(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_snap", &sn_p1.name_p)))), Text::lit("published"), Array::from(vec![crate::lower::model::Ex::XCx])), hold_written_f(sk_p0, &sn_p1.name_p), Array::new())]), tail_p: crate::lower::model::Ex::XUnit, doc_p: Text::from(format!("{}, published: its snapshot of the tick before moved it, written as a hold is (pick ST).", &sn_p1.what_p)) }
}

/// ```prism
/// GatheredMoved: fn SnapDef -> MethDef
/// ```
pub fn gathered_moved_f(sn_p0: &crate::lower::node_::SnapDef) -> crate::lower::model::MethDef {
    crate::lower::model::MethDef { name_p: Text::from(format!("{}_moved", &sn_p0.name_p)), recv_p: crate::lower::model::Recv::RecvRc, params_p: Array::new(), cx_p: crate::lower::model::CxArg::CxMut, ret_p: crate::lower::model::OutTy::OutUnit, body_p: Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_snap", &sn_p0.name_p)))), Text::lit("mark"), Array::from(vec![crate::lower::model::Ex::XCx]))), crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCx), Text::lit("build_later"), Array::from(vec![crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XSelf))])))]), tail_p: crate::lower::model::Ex::XUnit, doc_p: Text::lit("A row\'s result moved: the `for`\'s gathered dynamic is marked, and its snapshot taken after the builder (pick ST).") }
}

/// ```prism
/// DocumentGetter: fn Wx -> MethDef
/// ```
pub fn document_getter_f(wx_p0: &crate::lower::node_::Wx) -> crate::lower::model::MethDef {
    let is_own_f1 = Rc::new(move |p_p3: &crate::lower::model::Pos_| &p_p3.scope_p == &Nat::from(0u32)) as Rc<dyn Fn(&crate::lower::model::Pos_) -> bool>;
    let body_p2 = document_body_f(&{
        let f = Rc::new(vec_push_f);
        Rc::new(move |(a0, a1): (crate::lower::model::Ex, crate::lower::model::Ex)| {
            let fy = f.clone();
            crate::prelude::once_job(move || prism_rtl::Turn::Finished(fy(&a0, &a1)))
        }) as Rc<dyn Fn((crate::lower::model::Ex, crate::lower::model::Ex)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Do>>>
    }, &crate::prelude::filter(&wx_p0.places_p, &(|pl_p4: &crate::lower::node_::Place| (&is_own_f1)(&pl_p4.pos_p))), &crate::prelude::filter(&wx_p0.builders_p, &(|b_p5: &crate::lower::model::ForDef| (&is_own_f1)(&b_p5.pos_p))), &crate::prelude::filter(&wx_p0.gens_p, &(|gd_p6: &crate::lower::model::GenDef| (&is_own_f1)(&gd_p6.pos_p))));
    crate::lower::model::MethDef { name_p: Text::lit("document"), recv_p: crate::lower::model::Recv::RecvRef, params_p: Array::new(), cx_p: crate::lower::model::CxArg::CxRef, ret_p: crate::lower::model::OutTy::OutNamed(Text::lit("Vec"), Array::from(vec![crate::lower::model::OutTy::OutTuple(Array::from(vec![crate::lower::model::OutTy::OutPath, crate::lower::types::entry_ty_p()]))])), body_p: crate::prelude::append(&Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaMut(Text::lit("doc"))), crate::lower::model::OutTy::OutNamed(Text::lit("Vec"), Array::from(vec![crate::lower::model::OutTy::OutTuple(Array::from(vec![crate::lower::model::OutTy::OutPath, crate::lower::types::entry_ty_p()]))]))), crate::lower::model::Ex::XCall(Text::lit("Vec::new"), Array::new()))]), &body_p2), tail_p: crate::lower::model::Ex::XVar(Text::lit("doc")), doc_p: Text::lit("The row\'s own places, entries of its host\'s document, by their paths relative to the row (pick HO).") }
}

/// ```prism
/// DocumentMoved: fn Text -> MethDef
/// ```
pub fn document_moved_f(m_p0: &Text) -> crate::lower::model::MethDef {
    crate::lower::model::MethDef { name_p: Text::lit("document_moved"), recv_p: crate::lower::model::Recv::RecvRc, params_p: Array::new(), cx_p: crate::lower::model::CxArg::CxMut, ret_p: crate::lower::model::OutTy::OutUnit, body_p: Array::from(vec![crate::lower::model::Do::DoIfLet(crate::lower::model::Pa::PaCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("parent"))])), crate::lower::model::Ex::XUpgrade(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::lit("parent")))), Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("parent"))), m_p0.clone(), Array::from(vec![crate::lower::model::Ex::XCx])))]), Array::new())]), tail_p: crate::lower::model::Ex::XUnit, doc_p: Text::lit("A place of this row may have moved: its host\'s document moved, and the host\'s readers and rows are marked (pick HO).") }
}

/// ```prism
/// DocumentBody: fn (fn Ex, Ex -> Do), [Place], [ForDef], [GenDef] -> [Do]
/// ```
pub fn document_body_f(add_f0: &Rc<dyn Fn((crate::lower::model::Ex, crate::lower::model::Ex)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Do>>>, places_p1: &Array<crate::lower::node_::Place>, builders_p2: &Array<crate::lower::model::ForDef>, gens_p3: &Array<crate::lower::model::GenDef>) -> Array<crate::lower::model::Do> {
    let statics_p4 = crate::prelude::run_to_end(crate::prelude::each_job(places_p1.clone(), {
        let add_f0x = add_f0.clone();
        Rc::new(move |p0: crate::lower::node_::Place| {
            let add_f0xy = add_f0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let pl_p8 = p0;
                (&add_f0xy)((crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCall(Text::lit("Path::root"), Array::new())), Text::lit("at"), Array::from(vec![crate::lower::model::Ex::XIndex(pl_p8.pos_p.at_p.clone())])), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), pl_p8.entry_p.clone()))))).cycle()
            }))
        }) as Rc<dyn Fn(crate::lower::node_::Place) -> Rc<dyn prism_rtl::Job<crate::lower::model::Do>>>
    }));
    let row_doc_f5 = Rc::new(move |p0: crate::lower::model::ForDef| crate::prelude::entered(crate::prelude::once_job(move || {
        let b_p9 = p0;
        if crate::syntax::lexer::chars::has_prefix_f(&b_p9.row_node_p, &Text::lit("prism_rtl::HostRow")) {
            prism_rtl::Turn::Finished(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("row"))), Text::lit("entries"), Array::new()))
        } else {
            prism_rtl::Turn::Finished(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("row"))), Text::lit("document"), Array::from(vec![crate::lower::model::Ex::XCx])))
        }
    }))) as Rc<dyn Fn(crate::lower::model::ForDef) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>;
    let rows_p6 = crate::prelude::run_to_end(crate::prelude::each_job(builders_p2.clone(), {
        let row_doc_f5x = row_doc_f5.clone();
        let add_f0x = add_f0.clone();
        Rc::new(move |p0: crate::lower::model::ForDef| {
            let row_doc_f5xy = row_doc_f5x.clone();
            let add_f0xy = add_f0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let b_pa = p0;
                crate::prelude::call_value((&row_doc_f5xy)(b_pa.clone()), move |row_doc_35060: crate::lower::model::Ex| crate::prelude::call_value((&add_f0xy)((crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCall(Text::lit("Path::root"), Array::new())), Text::lit("at"), Array::from(vec![crate::lower::model::Ex::XIndex(b_pa.pos_p.at_p.clone())]))), Text::lit("child"), Array::from(vec![crate::lower::model::Ex::XCtor(Text::lit("Segment::Key"), Array::from(vec![crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("k"))), Text::lit("to_pod"), Array::new())]))]))), Text::lit("join"), Array::from(vec![crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XVar(Text::lit("p"))))])), crate::lower::model::Ex::XVar(Text::lit("e")))), move |add_35074: crate::lower::model::Do| prism_rtl::Turn::Finished(crate::lower::model::Do::DoFor(crate::lower::model::Pa::PaTuple(Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("k")), crate::lower::model::Pa::PaBind(Text::lit("row"))])), crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), b_pa.name_p.clone())), Text::lit("borrow"), Array::new())), Text::lit("iter"), Array::new()), Array::from(vec![crate::lower::model::Do::DoFor(crate::lower::model::Pa::PaTuple(Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("p")), crate::lower::model::Pa::PaBind(Text::lit("e"))])), row_doc_35060, Array::from(vec![add_35074]))])))))
            }))
        }) as Rc<dyn Fn(crate::lower::model::ForDef) -> Rc<dyn prism_rtl::Job<crate::lower::model::Do>>>
    }));
    let generations_p7 = crate::prelude::run_to_end(crate::prelude::each_job(gens_p3.clone(), {
        let add_f0x = add_f0.clone();
        Rc::new(move |p0: crate::lower::model::GenDef| {
            let add_f0xy = add_f0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let gd_pb = p0;
                crate::prelude::call_value((&add_f0xy)((crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCall(Text::lit("Path::root"), Array::new())), Text::lit("at"), Array::from(vec![crate::lower::model::Ex::XIndex(gd_pb.pos_p.at_p.clone())]))), Text::lit("child"), Array::from(vec![crate::lower::model::Ex::XCtor(Text::lit("Segment::Gen"), Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("g"))]))]))), Text::lit("join"), Array::from(vec![crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XVar(Text::lit("p"))))])), crate::lower::model::Ex::XVar(Text::lit("e")))), move |add_35648: crate::lower::model::Do| prism_rtl::Turn::Finished(crate::lower::model::Do::DoIfLet(crate::lower::model::Pa::PaCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("row"))])), crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), gd_pb.name_p.clone())), Text::lit("borrow"), Array::new())), Text::lit("as_ref"), Array::new()), Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(Text::lit("g")), crate::lower::model::Ex::XBin(crate::lower::model::BinOp::OpSub, Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_count", &gd_pb.name_p)))), Text::lit("get"), Array::new())), Rc::new(crate::lower::model::Ex::XIndex(Nat::from(1u32))))), crate::lower::model::Do::DoFor(crate::lower::model::Pa::PaTuple(Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("p")), crate::lower::model::Pa::PaBind(Text::lit("e"))])), crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("row"))), Text::lit("document"), Array::from(vec![crate::lower::model::Ex::XCx])), Array::from(vec![add_35648]))]), Array::new())))
            }))
        }) as Rc<dyn Fn(crate::lower::model::GenDef) -> Rc<dyn prism_rtl::Job<crate::lower::model::Do>>>
    }));
    crate::prelude::append(&crate::prelude::append(&statics_p4, &rows_p6), &generations_p7)
}

/// ```prism
/// MapInsert: fn Ex, Ex -> Do
/// ```
pub fn map_insert_f(path_p0: &crate::lower::model::Ex, e_p1: &crate::lower::model::Ex) -> crate::lower::model::Do {
    crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("doc"))), Text::lit("insert"), Array::from(vec![path_p0.clone(), e_p1.clone()])))
}

/// ```prism
/// VecPush: fn Ex, Ex -> Do
/// ```
pub fn vec_push_f(path_p0: &crate::lower::model::Ex, e_p1: &crate::lower::model::Ex) -> crate::lower::model::Do {
    crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("doc"))), Text::lit("push"), Array::from(vec![crate::lower::model::Ex::XTuple(Array::from(vec![path_p0.clone(), e_p1.clone()]))])))
}

/// ```prism
/// DynAnswerArm: fn Sinks, Pos, Text, OutTy -> ((Pa, Ex))
/// ```
pub fn dyn_answer_arm_f(sk_p0: &Sinks, pos_p1: &crate::lower::model::Pos_, f_p2: &Text, t_p3: &crate::lower::model::OutTy) -> (crate::lower::model::Pa, crate::lower::model::Ex) {
    (pos_pat_f(pos_p1, &Array::new()), crate::lower::model::Ex::XBlock(dyn_place_write_f(sk_p0, f_p2, &crate::lower::model::Ex::XDecode(t_p3.clone(), Rc::new(crate::lower::model::Ex::XVar(Text::lit("v"))))), Rc::new(crate::lower::model::Ex::XUnit)))
}

/// ```prism
/// DynPlaceWrite: fn Sinks, Text, Ex -> [Do]
/// ```
pub fn dyn_place_write_f(sk_p0: &Sinks, f_p1: &Text, value_p2: &crate::lower::model::Ex) -> Array<crate::lower::model::Do> {
    crate::prelude::append(&Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", f_p1)))), Text::lit("set"), Array::from(vec![value_p2.clone(), crate::lower::model::Ex::XCx])))]), &hold_written_f(sk_p0, f_p1))
}

/// ```prism
/// UpdatedGaps: fn Wx, [Gn], Bool -> [Do]
/// ```
pub fn updated_gaps_f(wx_p0: &crate::lower::node_::Wx, gns_p1: &Array<crate::lower::node_::Gn>, is_gen_p2: &bool) -> Array<crate::lower::model::Do> {
    let holds_p3 = crate::prelude::fold(&wx_p0.fields_p, &Array::new(), &(|acc_p7: &Array<Text>, (f_p8, t_p9, _): &(Text, crate::lower::model::OutTy, Text)| if is_hold_f(t_p9) { crate::prelude::push(acc_p7, f_p8) } else { acc_p7.clone() }));
    let derived_p4 = crate::prelude::keys(&wx_p0.dyn_reads_p);
    let roots_p5 = snap_names_f(wx_p0);
    let own_p6 = crate::prelude::fold(&crate::prelude::filter(gns_p1, &(|g_pa: &crate::lower::node_::Gn| &g_pa.kind_p == &crate::lower::node_::GnKind::GnUpdated)), &Array::new(), &(|acc_pb: &Array<crate::lower::model::Do>, g_pc: &crate::lower::node_::Gn| crate::prelude::fold(&g_pc.reads_p, acc_pb, &(|a_pd: &Array<crate::lower::model::Do>, r_pe: &crate::lower::node_::Read| match r_pe {
        crate::lower::node_::Read::ParentRead(f_pf) => if *is_gen_p2 {
            crate::prelude::push(a_pd, &crate::lower::expr::refusal_do_f(&Text::from(format!("`!Updated` of a dynamic in a generation that reads its block\'s `{}`, which the block does not tell a generation of (gap DY)", f_pf))))
        } else {
            a_pd.clone()
        },
        crate::lower::node_::Read::OwnRead(f_pg) => if (crate::check::types::has_text_f(&holds_p3, f_pg) || crate::check::types::has_text_f(&derived_p4, f_pg)) || crate::check::types::has_text_f(&roots_p5, f_pg) {
            a_pd.clone()
        } else {
            crate::prelude::push(a_pd, &crate::lower::expr::refusal_do_f(&Text::from(format!("`!Updated` of a dynamic that reads `{}`, which no sink of this node writes (no height for its event)", f_pg))))
        },
    }))));
    crate::prelude::fold(&wx_p0.pending_p, &own_p6, &(|acc_ph: &Array<crate::lower::model::Do>, p_pi: &crate::lower::node_::PendingRow| crate::prelude::fold(&updated_hears_f(&p_pi.wx_p), acc_ph, &(|a_pj: &Array<crate::lower::model::Do>, m_pk: &Text| {
        let behind_pl = reads_closed_f(&wx_p0.dyn_reads_p, &Array::from(vec![crate::lower::node_::Read::OwnRead(m_pk.clone())]));
        let written_pm = crate::prelude::fold(&behind_pl, &false, &(|w_pn: &bool, r_po: &crate::lower::node_::Read| *w_pn || match r_po {
            crate::lower::node_::Read::OwnRead(h_pp) => crate::check::types::has_text_f(&holds_p3, h_pp),
            crate::lower::node_::Read::ParentRead(_) => true,
        }));
        if crate::check::types::has_text_f(&roots_p5, m_pk) || reaches_snap_f(&roots_p5, &behind_pl) {
            crate::prelude::push(a_pj, &crate::lower::expr::refusal_do_f(&Text::from(format!("`!Updated` of a dynamic in a row that reads its block\'s `{}`, a structural dynamic the block publishes at the start of a tick, not lowered for a row\'s `!Updated` (gap SU)", m_pk))))
        } else {
            if written_pm || crate::check::types::has_text_f(&derived_p4, m_pk) {
                a_pj.clone()
            } else {
                crate::prelude::push(a_pj, &crate::lower::expr::refusal_do_f(&Text::from(format!("`!Updated` of a dynamic in a row that reads its block\'s `{}`, which no sink of the block writes (no height for its event)", m_pk))))
            }
        }
    }))))
}

/// ```prism
/// FinishPending: unbounded fn Wx, [Gn] -> (([NodeDef], [Gn]))
/// ```
pub fn finish_pending_f(wx_p0: &crate::lower::node_::Wx, gns_p1: &Array<crate::lower::node_::Gn>) -> (Array<crate::lower::model::NodeDef>, Array<crate::lower::node_::Gn>) {
    crate::prelude::run_to_end(crate::prelude::fold_job(wx_p0.pending_p.clone(), (Array::new(), gns_p1.clone()), {
        let wx_p0x = wx_p0.clone();
        Rc::new(move |(p0, p1): ((Array<crate::lower::model::NodeDef>, Array<crate::lower::node_::Gn>), crate::lower::node_::PendingRow)| {
            let wx_p0xy = wx_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (defs_p2, cur_p3) = p0;
                let p_p4 = p1;
                {
                    let floors_p5 = crate::prelude::fold(&row_hears_f(&p_p4.wx_p), &Map::new(), &(|acc_p9: &Map<Text, Nat>, m_pa: &Text| crate::prelude::insert(acc_p9, m_pa, &parent_floor_f(&wx_p0xy, &cur_p3, &Array::from(vec![crate::lower::node_::Read::ParentRead(m_pa.clone())])))));
                    let floored_p6 = {
                        let mut this: crate::lower::node_::Wx = p_p4.wx_p.clone();
                        this.floors_p = floors_p5.clone();
                        this.gns_p = crate::prelude::each(&this.gns_p, &(|g_pb: &crate::lower::node_::Gn| if &g_pb.kind_p == &crate::lower::node_::GnKind::GnUpdated {
                            with_floor_f(g_pb, &parent_floor_f(&wx_p0xy, &cur_p3, &reads_closed_f(&p_p4.wx_p.dyn_reads_p, &g_pb.reads_p)))
                        } else {
                            g_pb.clone()
                        }));
                        this
                    };
                    crate::prelude::call_then(start_finish_node_f(floored_p6.clone(), p_p4.qk_p.clone(), p_p4.params_p.clone(), true), move |finish_node_f_39918: crate::lower::model::NodeDef| {
                        let def_p7 = finish_node_f_39918;
                        let next_p8 = match &p_p4.gather_o {
                            Some(gid_pc) => crate::prelude::each(&cur_p3, &(|g_pd: &crate::lower::node_::Gn| if &g_pd.id_p == gid_pc {
                                with_height_f(g_pd, &(&def_p7.top_p + &Nat::from(1u32)))
                            } else {
                                g_pd.clone()
                            })),
                            None => cur_p3.clone(),
                        };
                        prism_rtl::Turn::Finished((crate::prelude::push(&defs_p2, &def_p7), next_p8.clone()))
                    })
                }
            }))
        }) as Rc<dyn Fn(((Array<crate::lower::model::NodeDef>, Array<crate::lower::node_::Gn>), crate::lower::node_::PendingRow)) -> Rc<dyn prism_rtl::Job<(Array<crate::lower::model::NodeDef>, Array<crate::lower::node_::Gn>)>>>
    }))
}

/// The step machine of `FinishPending`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FinishPending: unbounded fn Wx, [Gn] -> (([NodeDef], [Gn]))
/// ```
pub struct FinishPending {
    pub wx_p0: crate::lower::node_::Wx,
    pub gns_p1: Array<crate::lower::node_::Gn>,
}

impl prism_rtl::Job<(Array<crate::lower::model::NodeDef>, Array<crate::lower::node_::Gn>)> for FinishPending {
    fn cycle(&self) -> prism_rtl::Turn<(Array<crate::lower::model::NodeDef>, Array<crate::lower::node_::Gn>)> {
        let wx_p0 = &self.wx_p0;
        let gns_p1 = &self.gns_p1;
        crate::prelude::fold_job(wx_p0.pending_p.clone(), (Array::new(), gns_p1.clone()), {
            let wx_p0x = wx_p0.clone();
            Rc::new(move |(p0, p1): ((Array<crate::lower::model::NodeDef>, Array<crate::lower::node_::Gn>), crate::lower::node_::PendingRow)| {
                let wx_p0xy = wx_p0x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let (defs_p2, cur_p3) = p0;
                    let p_p4 = p1;
                    {
                        let floors_p5 = crate::prelude::fold(&row_hears_f(&p_p4.wx_p), &Map::new(), &(|acc_p9: &Map<Text, Nat>, m_pa: &Text| crate::prelude::insert(acc_p9, m_pa, &parent_floor_f(&wx_p0xy, &cur_p3, &Array::from(vec![crate::lower::node_::Read::ParentRead(m_pa.clone())])))));
                        let floored_p6 = {
                            let mut this: crate::lower::node_::Wx = p_p4.wx_p.clone();
                            this.floors_p = floors_p5.clone();
                            this.gns_p = crate::prelude::each(&this.gns_p, &(|g_pb: &crate::lower::node_::Gn| if &g_pb.kind_p == &crate::lower::node_::GnKind::GnUpdated {
                                with_floor_f(g_pb, &parent_floor_f(&wx_p0xy, &cur_p3, &reads_closed_f(&p_p4.wx_p.dyn_reads_p, &g_pb.reads_p)))
                            } else {
                                g_pb.clone()
                            }));
                            this
                        };
                        crate::prelude::call_then(start_finish_node_f(floored_p6.clone(), p_p4.qk_p.clone(), p_p4.params_p.clone(), true), move |finish_node_f_39918: crate::lower::model::NodeDef| {
                            let def_p7 = finish_node_f_39918;
                            let next_p8 = match &p_p4.gather_o {
                                Some(gid_pc) => crate::prelude::each(&cur_p3, &(|g_pd: &crate::lower::node_::Gn| if &g_pd.id_p == gid_pc {
                                    with_height_f(g_pd, &(&def_p7.top_p + &Nat::from(1u32)))
                                } else {
                                    g_pd.clone()
                                })),
                                None => cur_p3.clone(),
                            };
                            prism_rtl::Turn::Finished((crate::prelude::push(&defs_p2, &def_p7), next_p8.clone()))
                        })
                    }
                }))
            }) as Rc<dyn Fn(((Array<crate::lower::model::NodeDef>, Array<crate::lower::node_::Gn>), crate::lower::node_::PendingRow)) -> Rc<dyn prism_rtl::Job<(Array<crate::lower::model::NodeDef>, Array<crate::lower::node_::Gn>)>>>
        }).cycle()
    }
}

/// `Start FinishPending, x`: what the function value is when passed to `@Run`.
pub fn start_finish_pending_f(wx_p0: crate::lower::node_::Wx, gns_p1: Array<crate::lower::node_::Gn>) -> Rc<dyn prism_rtl::Job<(Array<crate::lower::model::NodeDef>, Array<crate::lower::node_::Gn>)>> {
    Rc::new(FinishPending { wx_p0, gns_p1 })
}

/// ```prism
/// ParentFloor: fn Wx, [Gn], [Read] -> Nat
/// ```
pub fn parent_floor_f(wx_p0: &crate::lower::node_::Wx, gns_p1: &Array<crate::lower::node_::Gn>, reads_p2: &Array<crate::lower::node_::Read>) -> Nat {
    crate::prelude::fold(reads_p2, &Nat::from(0u32), &(|hi_p3: &Nat, r_p4: &crate::lower::node_::Read| match r_p4 {
        crate::lower::node_::Read::ParentRead(m_p5) => crate::prelude::fold(&reads_closed_f(&wx_p0.dyn_reads_p, &Array::from(vec![crate::lower::node_::Read::OwnRead(m_p5.clone())])), hi_p3, &(|h2_p6: &Nat, hr_p7: &crate::lower::node_::Read| match hr_p7 {
            crate::lower::node_::Read::OwnRead(f_p8) => crate::prelude::fold(gns_p1, h2_p6, &(|h3_p9: &Nat, g_pa: &crate::lower::node_::Gn| if writes_hold_f(g_pa, f_p8) {
                crate::prelude::max(h3_p9, &(&g_pa.height_p + &Nat::from(1u32)))
            } else {
                h3_p9.clone()
            })),
            crate::lower::node_::Read::ParentRead(up_pb) => crate::prelude::max(h2_p6, &crate::prelude::or(&crate::prelude::get(&wx_p0.floors_p, up_pb), &Nat::from(0u32))),
        })),
        crate::lower::node_::Read::OwnRead(_) => hi_p3.clone(),
    }))
}

/// ```prism
/// WritesHold: fn Gn, Text -> Bool
/// ```
pub fn writes_hold_f(g_p0: &crate::lower::node_::Gn, f_p1: &Text) -> bool {
    crate::prelude::fold(&g_p0.outs_p, &false, &(|acc_p2: &bool, o_p3: &crate::lower::node_::Out| *acc_p2 || sink_writes_hold_f(&o_p3.sink_p, f_p1)))
}

/// ```prism
/// SinkWritesHold: fn Sk, Text -> Bool
/// ```
pub fn sink_writes_hold_f(sk0: &crate::lower::node_::Sk, f_p1: &Text) -> bool {
    match sk0 {
        crate::lower::node_::Sk::SkHold(h_p0) => h_p0 == f_p1,
        crate::lower::node_::Sk::SkDistinct(h_p2) => h_p2 == f_p1,
        crate::lower::node_::Sk::SkPerKey(h_p4) => h_p4 == f_p1,
        crate::lower::node_::Sk::SkMachine(h_p6, _, _) => h_p6 == f_p1,
        other_p8 => false,
    }
}

/// ```prism
/// WithFloor: fn Gn, Nat -> Gn
/// ```
pub fn with_floor_f(g_p0: &crate::lower::node_::Gn, h_p1: &Nat) -> crate::lower::node_::Gn {
    let mut this: crate::lower::node_::Gn = g_p0.clone();
    this.floor_p = h_p1.clone();
    this
}

/// ```prism
/// WithHeight: fn Gn, Nat -> Gn
/// ```
pub fn with_height_f(g_p0: &crate::lower::node_::Gn, h_p1: &Nat) -> crate::lower::node_::Gn {
    let mut this: crate::lower::node_::Gn = g_p0.clone();
    this.height_p = h_p1.clone();
    this
}

/// ```prism
/// RowHears: fn Wx -> [Text]
/// ```
pub fn row_hears_f(wx_p0: &crate::lower::node_::Wx) -> Array<Text> {
    let from_updated_p1 = crate::prelude::fold(&crate::prelude::filter(&wx_p0.gns_p, &(|g_p5: &crate::lower::node_::Gn| &g_p5.kind_p == &crate::lower::node_::GnKind::GnUpdated)), &Array::new(), &(|acc_p6: &Array<crate::lower::node_::Read>, g_p7: &crate::lower::node_::Gn| crate::lower::node_::union_reads_f(acc_p6, &reads_closed_f(&wx_p0.dyn_reads_p, &g_p7.reads_p))));
    let from_rows_p2 = crate::prelude::fold(&wx_p0.row_marks_p, &Array::new(), &(|acc_p8: &Array<crate::lower::node_::Read>, rm_p9: &crate::lower::node_::RowMarks| crate::lower::node_::union_reads_f(acc_p8, &reads_closed_f(&wx_p0.dyn_reads_p, &crate::prelude::append(&rm_p9.reads_p, &crate::prelude::each(&rm_p9.wrote_p, &(|m_pa: &Text| crate::lower::node_::Read::OwnRead(m_pa.clone()))))))));
    let from_builds_p3 = reads_closed_f(&wx_p0.dyn_reads_p, &wx_p0.build_holds_p);
    let from_gens_p4 = crate::prelude::fold(&wx_p0.gen_holds_p, &Array::new(), &(|acc_pb: &Array<crate::lower::node_::Read>, (_, hs_pc): &(Text, Array<crate::lower::node_::Read>)| crate::lower::node_::union_reads_f(acc_pb, &reads_closed_f(&wx_p0.dyn_reads_p, hs_pc))));
    crate::prelude::fold(&crate::lower::node_::union_reads_f(&crate::lower::node_::union_reads_f(&crate::lower::node_::union_reads_f(&from_updated_p1, &from_rows_p2), &from_builds_p3), &from_gens_p4), &Array::new(), &(|acc_pd: &Array<Text>, r_pe: &crate::lower::node_::Read| match r_pe {
        crate::lower::node_::Read::ParentRead(m_pf) => crate::check::types::add_text_f(acc_pd, m_pf),
        crate::lower::node_::Read::OwnRead(_) => acc_pd.clone(),
    }))
}

/// ```prism
/// UpdatedHears: fn Wx -> [Text]
/// ```
pub fn updated_hears_f(wx_p0: &crate::lower::node_::Wx) -> Array<Text> {
    crate::prelude::fold(&crate::prelude::filter(&wx_p0.gns_p, &(|g_p1: &crate::lower::node_::Gn| &g_p1.kind_p == &crate::lower::node_::GnKind::GnUpdated)), &Array::new(), &(|acc_p2: &Array<Text>, g_p3: &crate::lower::node_::Gn| crate::prelude::fold(&reads_closed_f(&wx_p0.dyn_reads_p, &g_p3.reads_p), acc_p2, &(|a_p4: &Array<Text>, r_p5: &crate::lower::node_::Read| match r_p5 {
        crate::lower::node_::Read::ParentRead(m_p6) => crate::check::types::add_text_f(a_p4, m_p6),
        crate::lower::node_::Read::OwnRead(_) => a_p4.clone(),
    }))))
}

/// ```prism
/// RowWritten: fn Wx, RowMarks, Read -> [Do]
/// ```
pub fn row_written_f(wx_p0: &crate::lower::node_::Wx, rm_p1: &crate::lower::node_::RowMarks, r_p2: &crate::lower::node_::Read) -> Array<crate::lower::model::Do> {
    let dirty_p3 = if crate::lower::node_::has_read_f(&reads_closed_f(&wx_p0.dyn_reads_p, &rm_p1.reads_p), r_p2) {
        Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCx), Text::lit("dirty"), Array::from(vec![crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(Text::lit("row"))))])))])
    } else {
        Array::new()
    };
    let told_p4 = crate::prelude::fold(&rm_p1.wrote_p, &Array::new(), &(|acc_p6: &Array<crate::lower::model::Do>, m_p7: &Text| if crate::lower::node_::has_read_f(&reads_closed_f(&wx_p0.dyn_reads_p, &Array::from(vec![crate::lower::node_::Read::OwnRead(m_p7.clone())])), r_p2) {
        crate::prelude::push(acc_p6, &crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("row"))), Text::from(format!("parent_wrote_{}", m_p7)), Array::from(vec![crate::lower::model::Ex::XCx]))))
    } else {
        acc_p6.clone()
    }));
    let body_p5 = crate::prelude::append(&dirty_p3, &told_p4);
    if &crate::prelude::len(&body_p5) == &Nat::from(0u32) {
        Array::new()
    } else {
        match &rm_p1.kind_p {
            crate::lower::model::RowKind::GenerationRow => Array::from(vec![crate::lower::model::Do::DoIfLet(crate::lower::model::Pa::PaCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("row"))])), crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), rm_p1.builder_p.clone())), Text::lit("borrow"), Array::new())), Text::lit("as_ref"), Array::new()), body_p5.clone(), Array::new())]),
            _ => Array::from(vec![crate::lower::model::Do::DoFor(crate::lower::model::Pa::PaBind(Text::lit("row")), crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), rm_p1.builder_p.clone())), Text::lit("borrow"), Array::new())), Text::lit("values"), Array::new()), body_p5.clone())]),
        }
    }
}

/// ```prism
/// PatchPlace: fn Wx, Place -> [Do]
/// ```
pub fn patch_place_f(wx_p0: &crate::lower::node_::Wx, p_p1: &crate::lower::node_::Place) -> Array<crate::lower::model::Do> {
    let pull_p2 = crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(p_p1.getter_p.clone()), crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XSelf), p_p1.getter_p.clone(), Array::from(vec![crate::lower::model::Ex::XCx])));
    let at_p3 = place_at_f(wx_p0, &Text::lit("self"), &p_p1.pos_p);
    let sent_p4 = crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCx), Text::lit("changed"), Array::from(vec![at_p3.clone(), crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(p_p1.getter_p.clone())), Text::lit("level_pod"), Array::from(vec![crate::lower::model::Ex::XCx]))])));
    let renew_p5 = if &p_p1.watch_p == &Text::lit("") {
        Array::new()
    } else {
        Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), p_p1.watch_p.clone())), Text::lit("renew"), Array::from(vec![crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XVar(p_p1.getter_p.clone()))), crate::lower::model::Ex::XCast(Rc::new(crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XSelf))), crate::lower::model::OutTy::OutObj(Rc::new(crate::lower::model::OutTy::OutNamed(Text::lit("Node"), Array::new())))), crate::lower::model::Ex::XCx])))])
    };
    crate::prelude::append(&Array::from(vec![pull_p2.clone(), sent_p4.clone()]), &renew_p5)
}

/// ```prism
/// Emits: fn Wx, Pos -> Bool
/// ```
pub fn emits_f(wx_p0: &crate::lower::node_::Wx, pos_p1: &crate::lower::model::Pos_) -> bool {
    (&pos_p1.scope_p == &Nat::from(0u32)) && (&wx_p0.hosted_by_o == &None)
}

/// ```prism
/// ResultTold: fn Ex -> [Do]
/// ```
pub fn result_told_f(node_p0: &crate::lower::model::Ex) -> Array<crate::lower::model::Do> {
    let r_p1 = crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(Text::lit("r")), crate::lower::model::Ex::XMethod(Rc::new(node_p0.clone()), Text::lit("result_value"), Array::from(vec![crate::lower::model::Ex::XCx])));
    Array::from(vec![r_p1.clone(), result_kept_f(node_p0), result_tell_p()])
}

/// ```prism
/// ResultMoved: fn Ex -> [Do]
/// ```
pub fn result_moved_f(node_p0: &crate::lower::model::Ex) -> Array<crate::lower::model::Do> {
    let r_p1 = crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(Text::lit("r")), crate::lower::model::Ex::XMethod(Rc::new(node_p0.clone()), Text::lit("result_value"), Array::from(vec![crate::lower::model::Ex::XCx])));
    let last_p2 = crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(node_p0.clone()), Text::lit("result_last"))), Text::lit("borrow"), Array::new())), Text::lit("as_ref"), Array::new());
    let differs_p3 = crate::lower::model::Ex::XBin(crate::lower::model::BinOp::OpNe, Rc::new(last_p2.clone()), Rc::new(crate::lower::model::Ex::XCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XVar(Text::lit("r"))))]))));
    Array::from(vec![r_p1.clone(), crate::lower::model::Do::DoIf(differs_p3.clone(), Array::from(vec![result_kept_f(node_p0), result_tell_p()]), Array::new())])
}

/// ```prism
/// ResultKept: fn Ex -> Do
/// ```
pub fn result_kept_f(node_p0: &crate::lower::model::Ex) -> crate::lower::model::Do {
    crate::lower::model::Do::DoAssign(crate::lower::model::Ex::XDeref(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(node_p0.clone()), Text::lit("result_last"))), Text::lit("borrow_mut"), Array::new()))), crate::lower::model::Ex::XCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(Text::lit("r"))))])))
}

/// ```prism
/// let resultTell
/// ```
pub fn result_tell_p() -> crate::lower::model::Do {
    crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCx), Text::lit("result"), Array::from(vec![crate::lower::model::Ex::XCtor(Text::lit("Outcome::Value"), Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("r"))]))])))
}

/// ```prism
/// Adoption: fn FlatDef -> [Do]
/// ```
pub fn adoption_f(fl_p0: &crate::lower::node_::FlatDef) -> Array<crate::lower::model::Do> {
    let adopt_p1 = crate::lower::model::Ex::XLater(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("node"))), Text::from(format!("{}_adopt", &fl_p0.name_p)), Array::from(vec![crate::lower::model::Ex::XCx]))));
    Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(Text::lit("node")), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XSelf))), crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCx), Text::lit("answer_later"), Array::from(vec![adopt_p1.clone()])))])
}

/// ```prism
/// PlaceAt: fn Wx, Text, Pos -> Ex
/// ```
pub fn place_at_f(wx_p0: &crate::lower::node_::Wx, recv_p1: &Text, pos_p2: &crate::lower::model::Pos_) -> crate::lower::model::Ex {
    let at_p3 = Array::from(vec![crate::lower::model::Ex::XIndex(pos_p2.at_p.clone())]);
    if emits_f(wx_p0, pos_p2) {
        crate::lower::model::Ex::XMethod(Rc::new(if recv_p1 == &Text::lit("") {
            crate::lower::model::Ex::XVar(Text::lit("path"))
        } else {
            if recv_p1 == &Text::lit("self") {
                crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::lit("path"))
            } else {
                crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XVar(recv_p1.clone())), Text::lit("path"))
            }
        }), Text::lit("at"), at_p3.clone())
    } else {
        crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCall(Text::lit("Path::root"), Array::new())), Text::lit("at"), at_p3.clone())
    }
}

/// ```prism
/// PosPat: fn Pos, [Pa] -> Pa
/// ```
pub fn pos_pat_f(pos_p0: &crate::lower::model::Pos_, tail_p1: &Array<crate::lower::model::Pa>) -> crate::lower::model::Pa {
    crate::lower::model::Pa::PaSlice(crate::prelude::append(&Array::from(vec![crate::lower::model::Pa::PaCtor(Text::lit("Segment::Pos"), Array::from(vec![crate::lower::model::Pa::PaIndex(pos_p0.at_p.clone())]))]), tail_p1))
}

/// ```prism
/// let keyTail
/// ```
pub fn key_tail_p() -> Array<crate::lower::model::Pa> {
    Array::from(vec![crate::lower::model::Pa::PaCtor(Text::lit("Segment::Key"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("k"))])), crate::lower::model::Pa::PaRest(Text::lit("rest"))])
}

/// ```prism
/// let genTail
/// ```
pub fn gen_tail_p() -> Array<crate::lower::model::Pa> {
    Array::from(vec![crate::lower::model::Pa::PaCtor(Text::lit("Segment::Gen"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("g"))])), crate::lower::model::Pa::PaRest(Text::lit("rest"))])
}

/// ```prism
/// ?HostedRows: fn Wx -> ?Text
/// ```
pub fn hosted_rows_o(wx_p0: &crate::lower::node_::Wx) -> Option<Text> {
    if &wx_p0.pos_p.scope_p > &Nat::from(0u32) {
        Some(Text::from(format!("{}_moved", &crate::prelude::or(&crate::prelude::index(&wx_p0.scopes_p, &crate::syntax::lexer::chars::dec_f(&wx_p0.pos_p.scope_p)), &Text::lit("")))))
    } else {
        match &wx_p0.hosted_by_o {
            Some(_) => Some(Text::lit("document_moved")),
            None => None,
        }
    }
}

/// ```prism
/// RootDynPatch: fn Wx -> [Do]
/// ```
pub fn root_dyn_patch_f(wx_p0: &crate::lower::node_::Wx) -> Array<crate::lower::model::Do> {
    match &wx_p0.root_dyn_o {
        Some(_) => Array::from(vec![crate::lower::model::Do::DoLine(result_moved_f(&crate::lower::model::Ex::XSelf))]),
        None => Array::new(),
    }
}

/// ```prism
/// AnswerArm: fn Wx, Pos, Nat, OutTy -> ((Pa, Ex))
/// ```
pub fn answer_arm_f(wx_p0: &crate::lower::node_::Wx, pos_p1: &crate::lower::model::Pos_, id_p2: &Nat, t_p3: &crate::lower::model::OutTy) -> (crate::lower::model::Pa, crate::lower::model::Ex) {
    let call_p4 = crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XSelf), crate::lower::node_::gn_of_f(wx_p0, id_p2).name_p.clone(), Array::from(vec![crate::lower::model::Ex::XDecode(t_p3.clone(), Rc::new(crate::lower::model::Ex::XVar(Text::lit("v")))), crate::lower::model::Ex::XCx]));
    (pos_pat_f(pos_p1, &Array::new()), call_p4.clone())
}

/// ```prism
/// TypedAnswerArm: fn Wx, Pos, Nat, Text -> ((Pa, [Do]))
/// ```
pub fn typed_answer_arm_f(wx_p0: &crate::lower::node_::Wx, pos_p1: &crate::lower::model::Pos_, id_p2: &Nat, acc_p3: &Text) -> (crate::lower::model::Pa, Array<crate::lower::model::Do>) {
    (pos_pat_f(pos_p1, &Array::new()), Array::from(vec![self_call_f(&crate::lower::node_::gn_of_f(wx_p0, id_p2).name_p, &Array::from(vec![crate::lower::expr::try_of_f(&crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("v"))), acc_p3.clone(), Array::new()))]))]))
}

/// ```prism
/// TypedDynArm: fn Sinks, Pos, Text, Text -> ((Pa, [Do]))
/// ```
pub fn typed_dyn_arm_f(sk_p0: &Sinks, pos_p1: &crate::lower::model::Pos_, f_p2: &Text, acc_p3: &Text) -> (crate::lower::model::Pa, Array<crate::lower::model::Do>) {
    (pos_pat_f(pos_p1, &Array::new()), dyn_place_write_f(sk_p0, f_p2, &crate::lower::expr::try_of_f(&crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("v"))), acc_p3.clone(), Array::new()))))
}

/// ```prism
/// TypedForwardArm: fn ForDef, Ex -> ((Pa, [Do]))
/// ```
pub fn typed_forward_arm_f(b_p0: &crate::lower::model::ForDef, segs_p1: &crate::lower::model::Ex) -> (crate::lower::model::Pa, Array<crate::lower::model::Do>) {
    let row_of_p2 = crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", &b_p0.name_p)))), Text::lit("borrow"), Array::new())), Text::lit("get"), Array::from(vec![crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XDecode(b_p0.key_ty_p.clone(), Rc::new(crate::lower::model::Ex::XVar(Text::lit("k"))))))]))), Text::lit("cloned"), Array::new());
    (pos_pat_f(&b_p0.pos_p, &key_tail_p()), Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(Text::lit("row")), row_of_p2.clone()), crate::lower::model::Do::DoMatch(crate::lower::model::Ex::XVar(Text::lit("row")), Array::from(vec![(crate::lower::model::Pa::PaCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("row"))])), Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::expr::try_of_f(&crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("row"))), Text::lit("deliver"), Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("rest")), crate::lower::model::Ex::XVar(Text::lit("v")), crate::lower::model::Ex::XCx]))))])), (crate::lower::model::Pa::PaUnit(Text::lit("None")), Array::from(vec![crate::lower::model::Do::DoReturn(crate::lower::model::Ex::XCtor(Text::lit("Err"), Array::from(vec![crate::lower::model::Ex::XCall(Text::lit("Fault::answer"), Array::from(vec![crate::lower::model::Ex::XFormatStr(Array::from(vec![crate::lower::model::Ex::XText(Text::lit("no row ")), crate::lower::model::Ex::XVar(Text::lit("k")), crate::lower::model::Ex::XText(Text::lit(" under the hosted place ")), crate::lower::model::Ex::XCtor(Text::lit("Path"), Array::from(vec![crate::lower::model::Ex::XMethod(Rc::new(segs_p1.clone()), Text::lit("to_vec"), Array::new())]))]))]))])))]))]))]))
}

/// ```prism
/// TypedGenArm: fn GenDef -> ((Pa, [Do]))
/// ```
pub fn typed_gen_arm_f(gd_p0: &crate::lower::model::GenDef) -> (crate::lower::model::Pa, Array<crate::lower::model::Do>) {
    let current_p1 = crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", &gd_p0.name_p)))), Text::lit("borrow"), Array::new())));
    let is_current_p2 = crate::lower::model::Ex::XBin(crate::lower::model::BinOp::OpEq, Rc::new(crate::lower::model::Ex::XBin(crate::lower::model::BinOp::OpAdd, Rc::new(crate::lower::model::Ex::XDeref(Rc::new(crate::lower::model::Ex::XVar(Text::lit("g"))))), Rc::new(crate::lower::model::Ex::XIndex(Nat::from(1u32))))), Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_count", &gd_p0.name_p)))), Text::lit("get"), Array::new())));
    (pos_pat_f(&gd_p0.pos_p, &gen_tail_p()), Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(Text::lit("row")), current_p1.clone()), crate::lower::model::Do::DoIfLet(crate::lower::model::Pa::PaCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("row"))])), crate::lower::model::Ex::XVar(Text::lit("row")), Array::from(vec![crate::lower::model::Do::DoIf(is_current_p2.clone(), Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::expr::try_of_f(&crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("row"))), Text::lit("deliver"), Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("rest")), crate::lower::model::Ex::XVar(Text::lit("v")), crate::lower::model::Ex::XCx]))))]), Array::new())]), Array::new())]))
}

/// ```prism
/// TypedDispatch: fn Sinks, Text, Nat -> MethDef
/// ```
pub fn typed_dispatch_f(sk_p0: &Sinks, name_p1: &Text, scope_p2: &Nat) -> crate::lower::model::MethDef {
    let wx_p3 = sk_p0.wx_p.clone();
    let in_scope_f4 = {
        let scope_p2x = scope_p2.clone();
        Rc::new(move |p_pb: &crate::lower::model::Pos_| &p_pb.scope_p == &scope_p2x) as Rc<dyn Fn(&crate::lower::model::Pos_) -> bool>
    };
    let (recv_pc, param_pd, segs_pe, doc_pf) = if scope_p2 > &Nat::from(0u32) {
        (crate::lower::model::Recv::RecvRc, (Text::lit("place"), crate::lower::model::OutTy::OutRef(Rc::new(crate::lower::model::OutTy::OutPath))), crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("place"))), Text::lit("segments"), Array::new()), Text::from(format!("The host at place {} answers its child\'s place `place` (pick HO): into the child\'s input method, a hold the place\'s element answers, or the row of a `for` or `rebuild` under it.", &crate::lower::model::place_text_f(&crate::prelude::or(&crate::prelude::index(&wx_p3.hosts_p, &crate::syntax::lexer::chars::dec_f(scope_p2)), &dummy_host_p()).pos_p))))
    } else {
        (crate::lower::model::Recv::RecvOwned, (Text::lit("at"), crate::lower::model::OutTy::OutRef(Rc::new(crate::lower::model::OutTy::OutSlice(Rc::new(crate::lower::model::OutTy::OutNamed(Text::lit("Segment"), Array::new())))))), crate::lower::model::Ex::XVar(Text::lit("at")), Text::lit("A host\'s answer to a place of this row\'s own, `at` under the row (pick HO): into the input method, a hold, or a row under it."))
    };
    let answers_p5 = crate::prelude::each(&crate::prelude::filter(&wx_p3.answers_p, &(|(pos_pg, _, _, _): &(crate::lower::model::Pos_, Nat, crate::lower::model::OutTy, Text)| (&in_scope_f4)(pos_pg))), &(|(pos_ph, id_pi, _, acc_pj): &(crate::lower::model::Pos_, Nat, crate::lower::model::OutTy, Text)| typed_answer_arm_f(&wx_p3, pos_ph, id_pi, acc_pj)));
    let dyns_p6 = crate::prelude::each(&crate::prelude::filter(&wx_p3.dyn_places_p, &(|(pos_pk, _, _, _): &(crate::lower::model::Pos_, Text, crate::lower::model::OutTy, Text)| (&in_scope_f4)(pos_pk))), &(|(pos_pl, f_pm, _, acc_pn): &(crate::lower::model::Pos_, Text, crate::lower::model::OutTy, Text)| typed_dyn_arm_f(sk_p0, pos_pl, f_pm, acc_pn)));
    let rows_p7 = crate::prelude::each(&crate::prelude::filter(&wx_p3.builders_p, &(|b_po: &crate::lower::model::ForDef| (&in_scope_f4)(&b_po.pos_p))), &(|b_pp: &crate::lower::model::ForDef| typed_forward_arm_f(b_pp, &segs_pe)));
    let gens_p8 = crate::prelude::each(&crate::prelude::filter(&wx_p3.gens_p, &(|gd_pq: &crate::lower::model::GenDef| (&in_scope_f4)(&gd_pq.pos_p))), &(|gd_pr: &crate::lower::model::GenDef| typed_gen_arm_f(gd_pr)));
    let none_p9 = (crate::lower::model::Pa::PaWild, Array::from(vec![crate::lower::model::Do::DoReturn(crate::lower::model::Ex::XCtor(Text::lit("Err"), Array::from(vec![crate::lower::model::Ex::XCall(Text::lit("Fault::answer"), Array::from(vec![crate::lower::model::Ex::XFormatStr(Array::from(vec![crate::lower::model::Ex::XText(Text::lit("no hosted place at ")), crate::lower::model::Ex::XCtor(Text::lit("Path"), Array::from(vec![crate::lower::model::Ex::XMethod(Rc::new(segs_pe.clone()), Text::lit("to_vec"), Array::new())])), crate::lower::model::Ex::XText(Text::lit(" to answer"))]))]))])))]));
    let arms_pa = crate::prelude::push(&crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&answers_p5, &dyns_p6), &rows_p7), &gens_p8), &none_p9);
    crate::lower::model::MethDef { name_p: name_p1.clone(), recv_p: recv_pc.clone(), params_p: Array::from(vec![param_pd.clone(), (Text::lit("v"), crate::lower::model::OutTy::OutRef(Rc::new(crate::lower::types::answer_ty_p())))]), cx_p: crate::lower::model::CxArg::CxMut, ret_p: crate::lower::model::OutTy::OutNamed(Text::lit("Done"), Array::new()), body_p: Array::from(vec![crate::lower::model::Do::DoMatch(segs_pe.clone(), arms_pa.clone())]), tail_p: crate::lower::model::Ex::XCtor(Text::lit("Ok"), Array::from(vec![crate::lower::model::Ex::XUnit])), doc_p: doc_pf.clone() }
}

/// ```prism
/// let dummyHost
/// ```
pub fn dummy_host_p() -> crate::lower::node_::HostDef {
    crate::lower::node_::HostDef { pos_p: crate::lower::model::pos0_p(), name_p: Text::lit(""), scope_p: Nat::from(0u32) }
}

/// ```prism
/// SortNats: fn [Nat] -> [Nat]
/// ```
pub fn sort_nats_f(xs_p0: &Array<Nat>) -> Array<Nat> {
    crate::prelude::fold(xs_p0, &Array::new(), &(|acc_p1: &Array<Nat>, x_p2: &Nat| crate::prelude::append(&crate::prelude::push(&crate::prelude::filter(acc_p1, &(|y_p3: &Nat| y_p3 < x_p2)), x_p2), &crate::prelude::filter(acc_p1, &(|y_p4: &Nat| !(y_p4 < x_p2))))))
}

/// ```prism
/// AskWake: fn Sinks, Nat -> [Do]
/// ```
pub fn ask_wake_f(sk_p0: &Sinks, h_p1: &Nat) -> Array<crate::lower::model::Do> {
    let c_p2 = crate::lower::model::Ex::XConst(wake_const_f(&sk_p0.heights_p, h_p1));
    let ask_p3 = crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::lit("wakes"))), Text::lit("ask"), Array::from(vec![c_p2.clone()])));
    let wake_p4 = crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCx), Text::lit("wake"), Array::from(vec![c_p2.clone(), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XSelf))])));
    if sk_p0.many_p {
        Array::from(vec![ask_p3.clone(), wake_p4.clone()])
    } else {
        Array::from(vec![wake_p4.clone()])
    }
}

/// ```prism
/// GatherIn: fn Sinks, Gn -> MethDef
/// ```
pub fn gather_in_f(sk_p0: &Sinks, g_p1: &crate::lower::node_::Gn) -> crate::lower::model::MethDef {
    let field_p2 = crate::prelude::or(&crate::prelude::index(&g_p1.inputs_p, &Nat::from(0u32)), &Text::lit(""));
    let kt_p3 = match &g_p1.ty_p {
        crate::lower::model::OutTy::OutMap(k_p8, _) => (**k_p8).clone(),
        _ => crate::lower::model::OutTy::OutUnit,
    };
    let vt_p4 = match &g_p1.ty_p {
        crate::lower::model::OutTy::OutMap(_, v_p9) => (**v_p9).clone(),
        _ => crate::lower::model::OutTy::OutUnit,
    };
    let current_p5 = crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", &field_p2)))), Text::lit("get"), Array::from(vec![crate::lower::model::Ex::XCx]))), Text::lit("unwrap_or_default"), Array::new());
    let collect_p6 = Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaMut(Text::lit("all")), current_p5.clone()), crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("all"))), Text::lit("insert"), Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("k")), crate::lower::model::Ex::XVar(Text::lit("v"))]))), crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", &field_p2)))), Text::lit("set"), Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("all")), crate::lower::model::Ex::XCx])))]);
    let body_p7 = crate::prelude::append(&collect_p6, &ask_wake_f(sk_p0, &g_p1.height_p));
    crate::lower::model::MethDef { name_p: Text::from(format!("{}_in", &g_p1.name_p)), recv_p: crate::lower::model::Recv::RecvRc, params_p: Array::from(vec![(Text::lit("k"), kt_p3.clone()), (Text::lit("v"), vt_p4.clone())]), cx_p: crate::lower::model::CxArg::CxMut, ret_p: crate::lower::model::OutTy::OutUnit, body_p: body_p7.clone(), tail_p: crate::lower::model::Ex::XUnit, doc_p: Text::lit("A row\'s firing, gathered by its key.") }
}

/// ```prism
/// Decide: fn Gn -> Do
/// ```
pub fn decide_f(g_p0: &crate::lower::node_::Gn) -> crate::lower::model::Do {
    match &g_p0.kind_p {
        crate::lower::node_::GnKind::GnGather => crate::lower::model::Do::DoIfLet(crate::lower::model::Pa::PaCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("v"))])), crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", &crate::prelude::or(&crate::prelude::index(&g_p0.inputs_p, &Nat::from(0u32)), &Text::lit("")))))), Text::lit("take"), Array::from(vec![crate::lower::model::Ex::XCx])), Array::from(vec![self_call_f(&g_p0.name_p, &Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("v"))]))]), Array::new()),
        crate::lower::node_::GnKind::GnMerge => merge_decide_f(g_p0),
        crate::lower::node_::GnKind::GnUpdated => updated_decide_f(g_p0),
        crate::lower::node_::GnKind::GnMergeAll => {
            let pushes_p1 = crate::prelude::each(&g_p0.inputs_p, &(|f_p4: &Text| crate::lower::model::Do::DoIfLet(crate::lower::model::Pa::PaCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("x"))])), crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", f_p4)))), Text::lit("take"), Array::from(vec![crate::lower::model::Ex::XCx])), Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("all"))), Text::lit("push_back"), Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("x"))])))]), Array::new())));
            let start_p2 = crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaMut(Text::lit("all"))), g_p0.ty_p.clone()), crate::lower::model::Ex::XCall(Text::lit("Array::new"), Array::new()));
            let fire_p3 = crate::lower::model::Do::DoIf(crate::lower::model::Ex::XUnary(crate::lower::model::UnOp::OpNot, Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("all"))), Text::lit("is_empty"), Array::new()))), Array::from(vec![self_call_f(&g_p0.name_p, &Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("all"))]))]), Array::new());
            crate::lower::model::Do::DoBlock(crate::prelude::push(&crate::prelude::append(&Array::from(vec![start_p2.clone()]), &pushes_p1), &fire_p3))
        },
        kind_p5 => pair_decide_f(g_p0, kind_p5),
    }
}

/// ```prism
/// UpdatedDecide: fn Gn -> Do
/// ```
pub fn updated_decide_f(g_p0: &crate::lower::node_::Gn) -> crate::lower::model::Do {
    crate::lower::model::Do::DoIf(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_moved", &g_p0.name_p)))), Text::lit("replace"), Array::from(vec![crate::lower::model::Ex::XBool(false)])), Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(Text::lit("after")), crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCx), Text::lit("after"), Array::from(vec![crate::lower::model::Ex::XClosure(false, Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("cx"))]), Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_value", &g_p0.name_p)), Array::from(vec![crate::lower::model::Ex::XCx]))))]))), self_call_f(&g_p0.name_p, &Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("after"))]))]), Array::new())
}

/// ```prism
/// PairDecide: fn Gn, GnKind -> Do
/// ```
pub fn pair_decide_f(g_p0: &crate::lower::node_::Gn, kind_p1: &crate::lower::node_::GnKind) -> crate::lower::model::Do {
    let get_l_p2 = crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", &crate::prelude::or(&crate::prelude::index(&g_p0.inputs_p, &Nat::from(0u32)), &Text::lit("")))))), Text::lit("take"), Array::from(vec![crate::lower::model::Ex::XCx]));
    let get_r_p3 = crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", &crate::prelude::or(&crate::prelude::index(&g_p0.inputs_p, &Nat::from(1u32)), &Text::lit("")))))), Text::lit("take"), Array::from(vec![crate::lower::model::Ex::XCx]));
    let both_p4 = crate::lower::model::Ex::XTuple(Array::from(vec![get_l_p2.clone(), get_r_p3.clone()]));
    let fire_f5 = {
        let g_p0x = g_p0.clone();
        Rc::new(move |x_pc: &crate::lower::model::Ex| Array::from(vec![self_call_f(&g_p0x.name_p, &Array::from(vec![x_pc.clone()]))])) as Rc<dyn Fn(&crate::lower::model::Ex) -> Array<crate::lower::model::Do>>
    };
    let sa_p6 = crate::lower::model::Pa::PaCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("a"))]));
    let sb_p7 = crate::lower::model::Pa::PaCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("b"))]));
    let some2_p8 = crate::lower::model::Pa::PaTuple(Array::from(vec![sa_p6.clone(), sb_p7.clone()]));
    let left_p9 = crate::lower::model::Pa::PaTuple(Array::from(vec![sa_p6.clone(), crate::lower::model::Pa::PaUnit(Text::lit("None"))]));
    let right_pa = crate::lower::model::Pa::PaTuple(Array::from(vec![crate::lower::model::Pa::PaUnit(Text::lit("None")), sb_p7.clone()]));
    let cases_pb = match kind_p1 {
        crate::lower::node_::GnKind::GnUnion => Array::from(vec![(some2_p8.clone(), (&fire_f5)(&crate::lower::model::Ex::XCall(crate::lower::helper_f(&Text::lit("union")), Array::from(vec![crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XVar(Text::lit("a")))), crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XVar(Text::lit("b"))))])))), (left_p9.clone(), (&fire_f5)(&crate::lower::model::Ex::XVar(Text::lit("a")))), (right_pa.clone(), (&fire_f5)(&crate::lower::model::Ex::XVar(Text::lit("b")))), (crate::lower::model::Pa::PaWild, Array::new())]),
        crate::lower::node_::GnKind::GnBoth => Array::from(vec![(some2_p8.clone(), (&fire_f5)(&crate::lower::model::Ex::XTuple(Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("a")), crate::lower::model::Ex::XVar(Text::lit("b"))])))), (crate::lower::model::Pa::PaWild, Array::new())]),
        _ => Array::from(vec![(left_p9.clone(), (&fire_f5)(&crate::lower::model::Ex::XVar(Text::lit("a")))), (crate::lower::model::Pa::PaWild, Array::new())]),
    };
    crate::lower::model::Do::DoMatch(both_p4.clone(), cases_pb.clone())
}

/// ```prism
/// WakeByHeight: fn [Gn], [Nat] -> Do
/// ```
pub fn wake_by_height_f(combs_p0: &Array<crate::lower::node_::Gn>, heights_p1: &Array<Nat>) -> crate::lower::model::Do {
    crate::lower::model::Do::DoMatch(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::lit("wakes"))), Text::lit("next"), Array::new()), crate::prelude::push(&crate::prelude::each(heights_p1, &(|h_p2: &Nat| (crate::lower::model::Pa::PaConst(wake_const_f(heights_p1, h_p2)), crate::prelude::each(&crate::prelude::filter(combs_p0, &(|g_p3: &crate::lower::node_::Gn| &g_p3.height_p == h_p2)), &(|g_p4: &crate::lower::node_::Gn| decide_f(g_p4)))))), &(crate::lower::model::Pa::PaWild, Array::new())))
}

/// ```prism
/// ForwardAnswer: fn ForDef -> Ex
/// ```
pub fn forward_answer_f(b_p0: &crate::lower::model::ForDef) -> crate::lower::model::Ex {
    let row_of_p1 = crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", &b_p0.name_p)))), Text::lit("borrow"), Array::new())), Text::lit("get"), Array::from(vec![crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XDecode(b_p0.key_ty_p.clone(), Rc::new(crate::lower::model::Ex::XVar(Text::lit("k"))))))]))), Text::lit("cloned"), Array::new());
    crate::lower::model::Ex::XBlock(Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(Text::lit("row")), row_of_p1.clone()), crate::lower::model::Do::DoIfLet(crate::lower::model::Pa::PaCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("row"))])), crate::lower::model::Ex::XVar(Text::lit("row")), Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::expr::try_of_f(&crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("row"))), Text::lit("answer"), Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("rest")), crate::lower::model::Ex::XVar(Text::lit("v")), crate::lower::model::Ex::XCx]))))]), Array::new())]), Rc::new(crate::lower::model::Ex::XUnit))
}

/// ```prism
/// IsHold: fn OutTy -> Bool
/// ```
pub fn is_hold_f(out_ty0: &crate::lower::model::OutTy) -> bool {
    match out_ty0 {
        crate::lower::model::OutTy::OutHold(_) => true,
        crate::lower::model::OutTy::OutNamed(c1_0_0, _) if (c1_0_0 == &Text::lit("prism_rtl::PerKey")) => true,
        other_p0 => false,
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// RowMethods: fn Wx -> [MethDef]
/// ```
pub fn row_methods_f(wx_p0: &crate::lower::node_::Wx) -> Array<crate::lower::model::MethDef> {
    let removes_p1 = crate::prelude::fold(&crate::prelude::filter(&wx_p0.places_p, &(|p_p3: &crate::lower::node_::Place| emits_f(wx_p0, &p_p3.pos_p))), &Array::new(), &(|acc_p4: &Array<crate::lower::model::Do>, p_p5: &crate::lower::node_::Place| crate::prelude::append(acc_p4, &crate::prelude::append(&Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCx), Text::lit("removed"), Array::from(vec![place_at_f(wx_p0, &Text::lit("self"), &p_p5.pos_p)])))]), &(if &p_p5.watch_p == &Text::lit("") {
        Array::new()
    } else {
        Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), p_p5.watch_p.clone())), Text::lit("drop_all"), Array::new()))])
    })))));
    let nested_p2 = crate::prelude::append(&crate::prelude::each(&wx_p0.builders_p, &(|b_p6: &crate::lower::model::ForDef| crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), b_p6.name_p.clone())), Text::lit("borrow"), Array::new())), Text::lit("values"), Array::new())), Text::lit("for_each"), Array::from(vec![crate::lower::model::Ex::XClosure(false, Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("row"))]), Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("row"))), Text::lit("leave_row"), Array::from(vec![crate::lower::model::Ex::XCx]))))]))))), &crate::prelude::each(&wx_p0.gens_p, &(|gd_p7: &crate::lower::model::GenDef| crate::lower::model::Do::DoIfLet(crate::lower::model::Pa::PaCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("row"))])), crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), gd_p7.name_p.clone())), Text::lit("borrow"), Array::new())), Text::lit("as_ref"), Array::new()), Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("row"))), Text::lit("leave_row"), Array::from(vec![crate::lower::model::Ex::XCx])))]), Array::new()))));
    Array::from(vec![crate::lower::model::MethDef { name_p: Text::lit("remove_places"), recv_p: crate::lower::model::Recv::RecvRef, params_p: Array::new(), cx_p: crate::lower::model::CxArg::CxMut, ret_p: crate::lower::model::OutTy::OutUnit, body_p: crate::prelude::append(&removes_p1, &nested_p2), tail_p: crate::lower::model::Ex::XUnit, doc_p: Text::lit("The row left: its places are torn down.") }])
}

/// ```prism
/// GnDoc: fn Gn -> Text
/// ```
pub fn gn_doc_f(g_p0: &crate::lower::node_::Gn) -> Text {
    match &g_p0.kind_p {
        crate::lower::node_::GnKind::GnAnswer => Text::from(format!("`{}`: an answer at its place.", &g_p0.name_p)),
        crate::lower::node_::GnKind::GnStarted => Text::lit("`@started`, the tick after the build."),
        crate::lower::node_::GnKind::GnDeferred => Text::lit("An `@Defer` firing, the tick after it was armed."),
        crate::lower::node_::GnKind::GnMerge => Text::from(format!("The merge `{}`, decided in the wake.", &g_p0.name_p)),
        crate::lower::node_::GnKind::GnUpdated => Text::lit("`!Updated`: the dynamic\'s value after the tick, fired in the wake when a hold it reads was written (or a structural dynamic it reads was published, pick ST)."),
        _ => Text::from(format!("`!{}`.", &g_p0.name_p)),
    }
}

/// ```prism
/// MergeDecide: fn Gn -> Do
/// ```
pub fn merge_decide_f(g_p0: &crate::lower::node_::Gn) -> crate::lower::model::Do {
    let call_p1 = Array::from(vec![self_call_f(&g_p0.name_p, &Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("v"))]))]);
    let take_l_p2 = crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(Text::lit("left")), crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", &crate::prelude::or(&crate::prelude::index(&g_p0.inputs_p, &Nat::from(0u32)), &Text::lit("")))))), Text::lit("take"), Array::from(vec![crate::lower::model::Ex::XCx])));
    let take_r_p3 = crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(Text::lit("right")), crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", &crate::prelude::or(&crate::prelude::index(&g_p0.inputs_p, &Nat::from(1u32)), &Text::lit("")))))), Text::lit("take"), Array::from(vec![crate::lower::model::Ex::XCx])));
    let right_p4 = crate::lower::model::Do::DoIfLet(crate::lower::model::Pa::PaCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("v"))])), crate::lower::model::Ex::XVar(Text::lit("right")), call_p1.clone(), Array::new());
    crate::lower::model::Do::DoBlock(Array::from(vec![take_l_p2.clone(), take_r_p3.clone(), crate::lower::model::Do::DoIfLet(crate::lower::model::Pa::PaCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("v"))])), crate::lower::model::Ex::XVar(Text::lit("left")), call_p1.clone(), Array::from(vec![right_p4.clone()]))]))
}
