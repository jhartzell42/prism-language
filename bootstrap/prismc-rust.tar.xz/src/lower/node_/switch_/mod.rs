//! The module `Lower.Node.Switch`, from `target/bootstrap/src/prismc/lower/node/switch.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file. The runtime
//! side is reached from the crate, `crate::prelude` (and through it `::prism_rtl`), the
//! standard library from `::std`, and nothing is imported by name: a program's own type
//! (`Row`, `Option`) hides none of theirs. The traits are in scope unnamed, for their methods.

use crate::prelude::traits::*;

/// `ClauseRow`:
///
/// ```prism
/// type ClauseRow = record:
/// ```
#[derive(::std::clone::Clone)]
pub struct ClauseRow {
    pub case_p: GenCase,
    pub parent_p: crate::lower::node_::Wx,
    pub plain_o: ::std::option::Option<crate::lower::model::OutTy>,
    pub result_reads_p: crate::prelude::Array<crate::lower::node_::Read>,
    pub result_ty_o: ::std::option::Option<crate::lower::model::OutTy>,
    pub width_p: crate::prelude::Nat,
    pub inner_p: bool,
    pub parts_p: crate::prelude::Array<RowPart>,
}

/// `GenCase`:
///
/// ```prism
/// type GenCase = record:
/// ```
#[derive(::std::clone::Clone)]
pub struct GenCase {
    pub node_p: crate::lower::model::NodeDef,
    pub params_p: crate::prelude::Array<(crate::prelude::Text, crate::lower::model::OutTy)>,
    pub pat_p: crate::lower::model::Pa,
    pub conds_p: crate::prelude::Array<crate::lower::model::Cc>,
    pub passed_p: crate::prelude::Array<crate::lower::model::Ex>,
}

impl crate::prelude::ToPod for GenCase {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("GenCase", vec![("node", self.node_p.to_pod()), ("params", self.params_p.to_pod()), ("pat", self.pat_p.to_pod()), ("conds", self.conds_p.to_pod()), ("passed", self.passed_p.to_pod())])
    }
}

impl crate::prelude::FromPod for GenCase {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(GenCase { node_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "node")?)?, params_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "params")?)?, pat_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "pat")?)?, conds_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "conds")?)?, passed_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "passed")?)? })
    }
}

/// `GenRow`:
///
/// ```prism
/// type GenRow = record:
/// ```
#[derive(::std::clone::Clone)]
pub struct GenRow {
    pub node_p: crate::lower::model::NodeDef,
    pub parent_p: crate::lower::node_::Wx,
    pub dyn_result_o: ::std::option::Option<crate::lower::model::OutTy>,
    pub plain_result_o: ::std::option::Option<crate::lower::model::OutTy>,
}

/// `KeptParts`:
///
/// ```prism
/// type KeptParts = record:
/// ```
#[derive(::std::clone::Clone)]
pub struct KeptParts {
    pub wx_p: crate::lower::node_::Wx,
    pub keeps_p: crate::prelude::Array<crate::lower::model::Do>,
    pub results_p: crate::prelude::Array<crate::lower::node_::Wres>,
}

/// `RowPart`:
///
/// ```prism
/// type RowPart = choice:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub enum RowPart {
    RowPartEvent(crate::prelude::Text),
    RowPartDynamic(crate::prelude::Text, crate::lower::model::OutTy, crate::prelude::Array<crate::lower::node_::Read>),
    RowPartPlain(crate::prelude::Text, crate::lower::model::OutTy),
    RowPartNothing,
    RowPartParts(crate::prelude::Array<RowPart>),
}

impl crate::prelude::Show for RowPart {
    fn show(&self, p: &mut crate::prelude::Printer) {
        match self {
            RowPart::RowPartEvent(a0) => p.choice("RowPartEvent", &[a0]),
            RowPart::RowPartDynamic(a0, a1, a2) => p.choice("RowPartDynamic", &[a0, a1, a2]),
            RowPart::RowPartPlain(a0, a1) => p.choice("RowPartPlain", &[a0, a1]),
            RowPart::RowPartNothing => p.choice("RowPartNothing", &[]),
            RowPart::RowPartParts(a0) => p.choice("RowPartParts", &[a0]),
        }
    }
}

impl crate::prelude::ToPod for RowPart {
    fn to_pod(&self) -> crate::prelude::Pod {
        match self {
            RowPart::RowPartEvent(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("RowPartEvent", 0), vec![a0.to_pod()]),
            RowPart::RowPartDynamic(a0, a1, a2) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("RowPartDynamic", 1), vec![a0.to_pod(), a1.to_pod(), a2.to_pod()]),
            RowPart::RowPartPlain(a0, a1) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("RowPartPlain", 2), vec![a0.to_pod(), a1.to_pod()]),
            RowPart::RowPartNothing => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("RowPartNothing", 3), vec![]),
            RowPart::RowPartParts(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("RowPartParts", 4), vec![a0.to_pod()]),
        }
    }
}

impl crate::prelude::FromPod for RowPart {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        match p.structure() {
            crate::prelude::Pod::Choice(c, a) if &**c == "RowPartEvent" && a.len() == 1 => ::std::result::Result::Ok(RowPart::RowPartEvent(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "RowPartDynamic" && a.len() == 3 => ::std::result::Result::Ok(RowPart::RowPartDynamic(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?, crate::prelude::FromPod::from_pod(&a[2])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "RowPartPlain" && a.len() == 2 => ::std::result::Result::Ok(RowPart::RowPartPlain(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "RowPartNothing" && a.len() == 0 => ::std::result::Result::Ok(RowPart::RowPartNothing),
            crate::prelude::Pod::Choice(c, a) if &**c == "RowPartParts" && a.len() == 1 => ::std::result::Result::Ok(RowPart::RowPartParts(crate::prelude::FromPod::from_pod(&a[0])?)),
            other => ::prism_rtl::pod::mismatch("a RowPart", other),
        }
    }
}

/// ```prism
/// RowEnv: unbounded fn Wx, Wx, Env, Block -> ((Wx, Wx, Env))
/// ```
pub fn row_env_f(parent_p0: &crate::lower::node_::Wx, row_wx_p1: &crate::lower::node_::Wx, menv_p2: &crate::lower::types::Env, body_p3: &crate::syntax::Block) -> (crate::lower::node_::Wx, crate::lower::node_::Wx, crate::lower::types::Env) {
    row_env_names_f(parent_p0, row_wx_p1, menv_p2, &crate::lower::expr::read_names_f(&crate::check::typed::print::block_exprs_f(body_p3)))
}

/// The step machine of `RowEnv`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RowEnv: unbounded fn Wx, Wx, Env, Block -> ((Wx, Wx, Env))
/// ```
pub struct RowEnv {
    pub parent_p0: crate::lower::node_::Wx,
    pub row_wx_p1: crate::lower::node_::Wx,
    pub menv_p2: crate::lower::types::Env,
    pub body_p3: crate::syntax::Block,
}

impl ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::node_::Wx, crate::lower::types::Env)> for RowEnv {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::lower::node_::Wx, crate::lower::node_::Wx, crate::lower::types::Env)> {
        let parent_p0 = &self.parent_p0;
        let row_wx_p1 = &self.row_wx_p1;
        let menv_p2 = &self.menv_p2;
        let body_p3 = &self.body_p3;
        let body_p3x = body_p3.clone();
        let menv_p2x = menv_p2.clone();
        let parent_p0x = parent_p0.clone();
        let row_wx_p1x = row_wx_p1.clone();
        crate::prelude::call_then(crate::check::typed::print::start_block_exprs_f(body_p3x.clone()), move |block_exprs_f_1566: crate::prelude::Array<crate::syntax::Expr>| crate::prelude::call_then(crate::lower::expr::start_read_names_f(block_exprs_f_1566), move |read_names_f_1555: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::More(::std::rc::Rc::new(RowEnvNames { parent_p0: parent_p0x.clone(), row_wx_p1: row_wx_p1x.clone(), menv_p2: menv_p2x.clone(), written_p3: read_names_f_1555 }))))
    }
}

/// `Start RowEnv, x`: what the function value is when passed to `@Run`.
pub fn start_row_env_f(parent_p0: crate::lower::node_::Wx, row_wx_p1: crate::lower::node_::Wx, menv_p2: crate::lower::types::Env, body_p3: crate::syntax::Block) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::node_::Wx, crate::lower::types::Env)>> {
    ::std::rc::Rc::new(RowEnv { parent_p0, row_wx_p1, menv_p2, body_p3 })
}

/// ```prism
/// RowNamesClosed: unbounded fn Env, [Text] -> [Text]
/// ```
pub fn row_names_closed_f(menv_p0: &crate::lower::types::Env, names_p1: &crate::prelude::Array<crate::prelude::Text>) -> crate::prelude::Array<crate::prelude::Text> {
    let more0_p2 = crate::prelude::run_to_end(crate::prelude::fold_job(names_p1.clone(), names_p1.clone(), {
        let menv_p0x = menv_p0.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::prelude::Text)| {
            let menv_p0xy = menv_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_p5 = p0;
                let n_p6 = p1;
                match crate::prelude::get(&menv_p0xy.names_p, &n_p6) {
                    ::std::option::Option::Some(crate::lower::types::Bn::BnLocalWidget(b_p7)) => crate::prelude::call_then(crate::check::typed::print::start_block_exprs_f(b_p7.clone()), move |block_exprs_f_1966: crate::prelude::Array<crate::syntax::Expr>| crate::prelude::call_then(crate::lower::expr::start_read_names_f(block_exprs_f_1966), move |read_names_f_1955: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_p5, &read_names_f_1955)))),
                    ::std::option::Option::Some(crate::lower::types::Bn::BnLocalFn(cs_p8)) => crate::prelude::fold_job(cs_p8.clone(), acc_p5.clone(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::syntax::decls::FnClause)| crate::prelude::entered(crate::prelude::once_job(move || {
                        let a_p9 = p0;
                        let c_pa = p1;
                        crate::prelude::call_then(crate::lower::expr::start_read_names_f(clause_exprs_f(&c_pa)), move |read_names_f_2044: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&a_p9, &read_names_f_2044)))
                    }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::syntax::decls::FnClause)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>).cycle(),
                    _ => ::prism_rtl::Turn::Finished(acc_p5.clone()),
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::prelude::Text)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>
    }));
    let more1_p3 = crate::prelude::run_to_end(crate::prelude::fold_job(names_p1.clone(), more0_p2.clone(), {
        let menv_p0x = menv_p0.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::prelude::Text)| {
            let menv_p0xy = menv_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_pb = p0;
                let n_pc = p1;
                match crate::prelude::get(&menv_p0xy.names_p, &crate::prelude::Text::from(format!("{}#element", &n_pc))) {
                    ::std::option::Option::Some(crate::lower::types::Bn::BnWidget(x_pd, _, _, _)) => crate::prelude::call_then(crate::check::typed::print::start_exprs_in_f(x_pd.clone()), move |exprs_in_f_2359: crate::prelude::Array<crate::syntax::Expr>| crate::prelude::call_then(crate::lower::expr::start_read_names_f(exprs_in_f_2359), move |read_names_f_2348: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_pb, &read_names_f_2348)))),
                    _ => ::prism_rtl::Turn::Finished(acc_pb.clone()),
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::prelude::Text)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>
    }));
    let more_p4 = crate::prelude::run_to_end(crate::prelude::fold_job(names_p1.clone(), more1_p3.clone(), {
        let menv_p0x = menv_p0.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::prelude::Text)| {
            let menv_p0xy = menv_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_pe = p0;
                let n_pf = p1;
                match crate::prelude::get(&menv_p0xy.names_p, &crate::prelude::Text::from(format!("{}#blueprint", &n_pf))) {
                    ::std::option::Option::Some(crate::lower::types::Bn::BnWidget(x_pg, _, _, _)) => crate::prelude::call_then(crate::check::typed::print::start_exprs_in_f(x_pg.clone()), move |exprs_in_f_2631: crate::prelude::Array<crate::syntax::Expr>| crate::prelude::call_then(crate::lower::expr::start_read_names_f(exprs_in_f_2631), move |read_names_f_2620: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_pe, &read_names_f_2620)))),
                    _ => ::prism_rtl::Turn::Finished(acc_pe.clone()),
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::prelude::Text)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>
    }));
    if &crate::prelude::len(&more_p4) == &crate::prelude::len(names_p1) {
        names_p1.clone()
    } else {
        row_names_closed_f(menv_p0, &more_p4)
    }
}

/// The step machine of `RowNamesClosed`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RowNamesClosed: unbounded fn Env, [Text] -> [Text]
/// ```
pub struct RowNamesClosed {
    pub menv_p0: crate::lower::types::Env,
    pub names_p1: crate::prelude::Array<crate::prelude::Text>,
}

impl ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>> for RowNamesClosed {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<crate::prelude::Text>> {
        let menv_p0 = &self.menv_p0;
        let names_p1 = &self.names_p1;
        let menv_p0x = menv_p0.clone();
        let names_p1x = names_p1.clone();
        crate::prelude::call_value(crate::prelude::fold_job(names_p1x.clone(), names_p1x.clone(), {
            let menv_p0xx = menv_p0x.clone();
            ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::prelude::Text)| {
                let menv_p0xxy = menv_p0xx.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let acc_p5 = p0;
                    let n_p6 = p1;
                    match crate::prelude::get(&menv_p0xxy.names_p, &n_p6) {
                        ::std::option::Option::Some(crate::lower::types::Bn::BnLocalWidget(b_p7)) => crate::prelude::call_then(crate::check::typed::print::start_block_exprs_f(b_p7.clone()), move |block_exprs_f_1966: crate::prelude::Array<crate::syntax::Expr>| crate::prelude::call_then(crate::lower::expr::start_read_names_f(block_exprs_f_1966), move |read_names_f_1955: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_p5, &read_names_f_1955)))),
                        ::std::option::Option::Some(crate::lower::types::Bn::BnLocalFn(cs_p8)) => crate::prelude::fold_job(cs_p8.clone(), acc_p5.clone(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::syntax::decls::FnClause)| crate::prelude::entered(crate::prelude::once_job(move || {
                            let a_p9 = p0;
                            let c_pa = p1;
                            crate::prelude::call_then(crate::lower::expr::start_read_names_f(clause_exprs_f(&c_pa)), move |read_names_f_2044: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&a_p9, &read_names_f_2044)))
                        }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::syntax::decls::FnClause)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>).cycle(),
                        _ => ::prism_rtl::Turn::Finished(acc_p5.clone()),
                    }
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::prelude::Text)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>
        }), move |fold_1859: crate::prelude::Array<crate::prelude::Text>| {
            let more0_p2 = fold_1859;
            crate::prelude::call_value(crate::prelude::fold_job(names_p1x.clone(), more0_p2.clone(), {
                let menv_p0xx = menv_p0x.clone();
                ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::prelude::Text)| {
                    let menv_p0xxy = menv_p0xx.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let acc_pb = p0;
                        let n_pc = p1;
                        match crate::prelude::get(&menv_p0xxy.names_p, &crate::prelude::Text::from(format!("{}#element", &n_pc))) {
                            ::std::option::Option::Some(crate::lower::types::Bn::BnWidget(x_pd, _, _, _)) => crate::prelude::call_then(crate::check::typed::print::start_exprs_in_f(x_pd.clone()), move |exprs_in_f_2359: crate::prelude::Array<crate::syntax::Expr>| crate::prelude::call_then(crate::lower::expr::start_read_names_f(exprs_in_f_2359), move |read_names_f_2348: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_pb, &read_names_f_2348)))),
                            _ => ::prism_rtl::Turn::Finished(acc_pb.clone()),
                        }
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::prelude::Text)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>
            }), move |fold_2221: crate::prelude::Array<crate::prelude::Text>| {
                let more1_p3 = fold_2221;
                crate::prelude::call_value(crate::prelude::fold_job(names_p1x.clone(), more1_p3.clone(), {
                    let menv_p0xx = menv_p0x.clone();
                    ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::prelude::Text)| {
                        let menv_p0xxy = menv_p0xx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let acc_pe = p0;
                            let n_pf = p1;
                            match crate::prelude::get(&menv_p0xxy.names_p, &crate::prelude::Text::from(format!("{}#blueprint", &n_pf))) {
                                ::std::option::Option::Some(crate::lower::types::Bn::BnWidget(x_pg, _, _, _)) => crate::prelude::call_then(crate::check::typed::print::start_exprs_in_f(x_pg.clone()), move |exprs_in_f_2631: crate::prelude::Array<crate::syntax::Expr>| crate::prelude::call_then(crate::lower::expr::start_read_names_f(exprs_in_f_2631), move |read_names_f_2620: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_pe, &read_names_f_2620)))),
                                _ => ::prism_rtl::Turn::Finished(acc_pe.clone()),
                            }
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::prelude::Text)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>
                }), move |fold_2491: crate::prelude::Array<crate::prelude::Text>| {
                    let more_p4 = fold_2491;
                    if &crate::prelude::len(&more_p4) == &crate::prelude::len(&names_p1x) {
                        ::prism_rtl::Turn::Finished(names_p1x.clone())
                    } else {
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(RowNamesClosed { menv_p0: menv_p0x.clone(), names_p1: more_p4.clone() }))
                    }
                })
            })
        })
    }
}

/// `Start RowNamesClosed, x`: what the function value is when passed to `@Run`.
pub fn start_row_names_closed_f(menv_p0: crate::lower::types::Env, names_p1: crate::prelude::Array<crate::prelude::Text>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>> {
    ::std::rc::Rc::new(RowNamesClosed { menv_p0, names_p1 })
}

/// ```prism
/// ClauseExprs: unbounded fn FnClause -> [Expr]
/// ```
pub fn clause_exprs_f(c_p0: &crate::syntax::decls::FnClause) -> crate::prelude::Array<crate::syntax::Expr> {
    match &c_p0.body_p {
        crate::syntax::decls::FnBody::BodyBlock(b_p1) => crate::check::typed::print::block_exprs_f(b_p1),
        crate::syntax::decls::FnBody::BodyExpr(x_p2) => crate::check::typed::print::exprs_in_f(x_p2),
    }
}

/// ```prism
/// RowEnvNames: unbounded fn Wx, Wx, Env, [Text] -> ((Wx, Wx, Env))
/// ```
pub fn row_env_names_f(parent_p0: &crate::lower::node_::Wx, row_wx_p1: &crate::lower::node_::Wx, menv_p2: &crate::lower::types::Env, written_p3: &crate::prelude::Array<crate::prelude::Text>) -> (crate::lower::node_::Wx, crate::lower::node_::Wx, crate::lower::types::Env) {
    let names_p4 = row_names_closed_f(menv_p2, written_p3);
    let elements0_p5 = crate::prelude::fold(&names_p4, &whole_of_block_f(menv_p2, &crate::lower::types::empty_env_p(), &false), &(|en_p7: &crate::lower::types::Env, n_p8: &crate::prelude::Text| match crate::prelude::get(&menv_p2.names_p, &crate::prelude::Text::from(format!("{}#element", n_p8))) {
        ::std::option::Option::Some(held_p9) => crate::lower::types::bind_f(en_p7, &crate::prelude::Text::from(format!("{}#element", n_p8)), &held_p9),
        ::std::option::Option::None => en_p7.clone(),
    }));
    let elements_p6 = crate::prelude::fold(&names_p4, &elements0_p5, &(|en_pa: &crate::lower::types::Env, n_pb: &crate::prelude::Text| match crate::prelude::get(&menv_p2.names_p, &crate::prelude::Text::from(format!("{}#blueprint", n_pb))) {
        ::std::option::Option::Some(held_pc) => crate::lower::types::bind_f(en_pa, &crate::prelude::Text::from(format!("{}#blueprint", n_pb)), &held_pc),
        ::std::option::Option::None => en_pa.clone(),
    }));
    crate::prelude::run_to_end(crate::prelude::fold_job(names_p4.clone(), (parent_p0.clone(), row_wx_p1.clone(), elements_p6.clone()), {
        let menv_p2x = menv_p2.clone();
        ::std::rc::Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::node_::Wx, crate::lower::types::Env), crate::prelude::Text)| {
            let menv_p2xy = menv_p2x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (p_pd, r_pe, env_pf) = p0;
                let n_pg = p1;
                match crate::prelude::get(&menv_p2xy.names_p, &n_pg) {
                    ::std::option::Option::Some(crate::lower::types::Bn::BnLocal(rs_ph, mode_pi, t_pj)) => ::prism_rtl::Turn::Finished((p_pd.clone(), r_pe.clone(), crate::lower::types::bind_f(&env_pf, &n_pg, &crate::lower::types::Bn::BnLocal(over_parent_f(&rs_ph), crate::lower::types::Holding::Owned, t_pj.clone())))),
                    ::std::option::Option::Some(crate::lower::types::Bn::BnLocalWidget(b_pk)) => ::prism_rtl::Turn::Finished((p_pd.clone(), r_pe.clone(), crate::lower::types::bind_f(&env_pf, &n_pg, &crate::lower::types::Bn::BnLocalWidget(b_pk.clone())))),
                    ::std::option::Option::Some(crate::lower::types::Bn::BnLocalFn(cs_pl)) => ::prism_rtl::Turn::Finished((p_pd.clone(), r_pe.clone(), crate::lower::types::bind_f(&env_pf, &n_pg, &crate::lower::types::Bn::BnLocalFn(cs_pl.clone())))),
                    ::std::option::Option::Some(crate::lower::types::Bn::BnWidget(x_pm, _, cmenv_pn, clx_po)) => crate::prelude::call_then(crate::check::typed::print::start_exprs_in_f(x_pm.clone()), move |exprs_in_f_4184: crate::prelude::Array<crate::syntax::Expr>| crate::prelude::call_then(crate::lower::expr::start_read_names_f(exprs_in_f_4184), move |read_names_f_4173: crate::prelude::Array<crate::prelude::Text>| crate::prelude::call_then(start_row_env_names_f(p_pd.clone(), r_pe.clone(), cmenv_pn.clone(), read_names_f_4173), move |row_env_names_f_4147: (crate::lower::node_::Wx, crate::lower::node_::Wx, crate::lower::types::Env)| {
                        let (p2_pp, r2_pq, inner_pr) = row_env_names_f_4147;
                        crate::prelude::call_then(start_build_spelling_f(inner_pr.clone()), move |build_spelling_f_4246: crate::lower::types::Env| ::prism_rtl::Turn::Finished((p2_pp.clone(), r2_pq.clone(), crate::lower::types::bind_f(&env_pf, &n_pg, &crate::lower::types::Bn::BnWidget(x_pm.clone(), build_spelling_f_4246, inner_pr.clone(), clx_po.clone())))))
                    }))),
                    ::std::option::Option::Some(crate::lower::types::Bn::BnEv(er_ps, t_pt)) => {
                        let pname_pu = crate::lower::node_::gn_of_f(&p_pd, &er_ps.node_p).name_p.clone();
                        let (rs_p11, r1_p12) = crate::lower::node_::fresh_name_f(&r_pe, &crate::lower::snake_f(&n_pg));
                        let (id_p13, r2_p14) = crate::lower::node_::add_gn_f(&r1_p12, &rs_p11, &t_pt, &crate::lower::node_::GnKind::GnPort, &crate::prelude::Nat::from(0u32));
                        let r3_pv = {
                            let mut this: crate::lower::node_::Wx = r2_p14.clone();
                            this.subs_p = crate::prelude::push(&this.subs_p, &(pname_pu.clone(), rs_p11.clone(), t_pt.clone()));
                            this
                        };
                        let p2_p10 = if crate::check::types::has_text_f(&p_pd.ports_p, &pname_pu) {
                            p_pd.clone()
                        } else {
                            crate::lower::node_::connect_f(&with_port_f(&p_pd, &pname_pu), &crate::lower::node_::ev_ref_of_f(&p_pd, &er_ps.node_p), &crate::lower::node_::Sk::SkPort(pname_pu.clone()))
                        };
                        ::prism_rtl::Turn::Finished((p2_p10.clone(), r3_pv.clone(), crate::lower::types::bind_f(&env_pf, &n_pg, &crate::lower::types::Bn::BnEv(crate::lower::node_::ev_ref_of_f(&r3_pv, &id_p13), t_pt.clone()))))
                    },
                    ::std::option::Option::Some(crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(recv_p15, m_p16, xs_p17), _, t_p18)) => if &*recv_p15 == &crate::lower::model::Ex::XSelf {
                        ::prism_rtl::Turn::Finished((p_pd.clone(), r_pe.clone(), crate::lower::types::bind_f(&env_pf, &n_pg, &crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(parent_ref_p()), m_p16.clone(), xs_p17.clone()), crate::prelude::Array::from(vec![crate::lower::node_::Read::ParentRead(m_p16.clone())]), t_p18.clone()))))
                    } else {
                        ::prism_rtl::Turn::Finished(row_param_env_f(&p_pd, &r_pe, &env_pf, &menv_p2xy, &n_pg))
                    },
                    ::std::option::Option::Some(crate::lower::types::Bn::BnDyn(_, _, _)) => ::prism_rtl::Turn::Finished(row_param_env_f(&p_pd, &r_pe, &env_pf, &menv_p2xy, &n_pg)),
                    ::std::option::Option::Some(crate::lower::types::Bn::BnHold(f_p19, t_p1a)) => ::prism_rtl::Turn::Finished((p_pd.clone(), r_pe.clone(), crate::lower::types::bind_f(&env_pf, &n_pg, &crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(parent_ref_p()), f_p19.clone())), crate::prelude::Text::lit("get"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx])), crate::prelude::Array::from(vec![crate::lower::node_::Read::ParentRead(f_p19.clone())]), t_p1a.clone())))),
                    ::std::option::Option::Some(crate::lower::types::Bn::BnParts(bs_p1b)) => crate::prelude::call_then(start_row_parts_bn_f(p_pd.clone(), r_pe.clone(), n_pg.clone(), bs_p1b.clone()), move |row_parts_bn_f_5555: (crate::lower::node_::Wx, crate::lower::node_::Wx, crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>)| {
                        let (p2_p1c, r2_p1d, over_p1e) = row_parts_bn_f_5555;
                        ::prism_rtl::Turn::Finished((p2_p1c.clone(), r2_p1d.clone(), crate::lower::types::bind_f(&env_pf, &n_pg, &crate::lower::types::Bn::BnParts(over_p1e.clone()))))
                    }),
                    _ => ::prism_rtl::Turn::Finished((p_pd.clone(), r_pe.clone(), env_pf.clone())),
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::lower::node_::Wx, crate::lower::node_::Wx, crate::lower::types::Env), crate::prelude::Text)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::node_::Wx, crate::lower::types::Env)>>>
    }))
}

/// The step machine of `RowEnvNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RowEnvNames: unbounded fn Wx, Wx, Env, [Text] -> ((Wx, Wx, Env))
/// ```
pub struct RowEnvNames {
    pub parent_p0: crate::lower::node_::Wx,
    pub row_wx_p1: crate::lower::node_::Wx,
    pub menv_p2: crate::lower::types::Env,
    pub written_p3: crate::prelude::Array<crate::prelude::Text>,
}

impl ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::node_::Wx, crate::lower::types::Env)> for RowEnvNames {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::lower::node_::Wx, crate::lower::node_::Wx, crate::lower::types::Env)> {
        let parent_p0 = &self.parent_p0;
        let row_wx_p1 = &self.row_wx_p1;
        let menv_p2 = &self.menv_p2;
        let written_p3 = &self.written_p3;
        let menv_p2x = menv_p2.clone();
        let parent_p0x = parent_p0.clone();
        let row_wx_p1x = row_wx_p1.clone();
        let written_p3x = written_p3.clone();
        crate::prelude::call_then(start_row_names_closed_f(menv_p2x.clone(), written_p3x.clone()), move |row_names_closed_f_3398: crate::prelude::Array<crate::prelude::Text>| {
            let names_p4 = row_names_closed_f_3398;
            let elements0_p5 = crate::prelude::fold(&names_p4, &whole_of_block_f(&menv_p2x, &crate::lower::types::empty_env_p(), &false), &(|en_p7: &crate::lower::types::Env, n_p8: &crate::prelude::Text| match crate::prelude::get(&menv_p2x.names_p, &crate::prelude::Text::from(format!("{}#element", n_p8))) {
                ::std::option::Option::Some(held_p9) => crate::lower::types::bind_f(en_p7, &crate::prelude::Text::from(format!("{}#element", n_p8)), &held_p9),
                ::std::option::Option::None => en_p7.clone(),
            }));
            let elements_p6 = crate::prelude::fold(&names_p4, &elements0_p5, &(|en_pa: &crate::lower::types::Env, n_pb: &crate::prelude::Text| match crate::prelude::get(&menv_p2x.names_p, &crate::prelude::Text::from(format!("{}#blueprint", n_pb))) {
                ::std::option::Option::Some(held_pc) => crate::lower::types::bind_f(en_pa, &crate::prelude::Text::from(format!("{}#blueprint", n_pb)), &held_pc),
                ::std::option::Option::None => en_pa.clone(),
            }));
            crate::prelude::fold_job(names_p4.clone(), (parent_p0x.clone(), row_wx_p1x.clone(), elements_p6.clone()), {
                let menv_p2xx = menv_p2x.clone();
                ::std::rc::Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::node_::Wx, crate::lower::types::Env), crate::prelude::Text)| {
                    let menv_p2xxy = menv_p2xx.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let (p_pd, r_pe, env_pf) = p0;
                        let n_pg = p1;
                        match crate::prelude::get(&menv_p2xxy.names_p, &n_pg) {
                            ::std::option::Option::Some(crate::lower::types::Bn::BnLocal(rs_ph, mode_pi, t_pj)) => ::prism_rtl::Turn::Finished((p_pd.clone(), r_pe.clone(), crate::lower::types::bind_f(&env_pf, &n_pg, &crate::lower::types::Bn::BnLocal(over_parent_f(&rs_ph), crate::lower::types::Holding::Owned, t_pj.clone())))),
                            ::std::option::Option::Some(crate::lower::types::Bn::BnLocalWidget(b_pk)) => ::prism_rtl::Turn::Finished((p_pd.clone(), r_pe.clone(), crate::lower::types::bind_f(&env_pf, &n_pg, &crate::lower::types::Bn::BnLocalWidget(b_pk.clone())))),
                            ::std::option::Option::Some(crate::lower::types::Bn::BnLocalFn(cs_pl)) => ::prism_rtl::Turn::Finished((p_pd.clone(), r_pe.clone(), crate::lower::types::bind_f(&env_pf, &n_pg, &crate::lower::types::Bn::BnLocalFn(cs_pl.clone())))),
                            ::std::option::Option::Some(crate::lower::types::Bn::BnWidget(x_pm, _, cmenv_pn, clx_po)) => crate::prelude::call_then(crate::check::typed::print::start_exprs_in_f(x_pm.clone()), move |exprs_in_f_4184: crate::prelude::Array<crate::syntax::Expr>| crate::prelude::call_then(crate::lower::expr::start_read_names_f(exprs_in_f_4184), move |read_names_f_4173: crate::prelude::Array<crate::prelude::Text>| crate::prelude::call_then(start_row_env_names_f(p_pd.clone(), r_pe.clone(), cmenv_pn.clone(), read_names_f_4173), move |row_env_names_f_4147: (crate::lower::node_::Wx, crate::lower::node_::Wx, crate::lower::types::Env)| {
                                let (p2_pp, r2_pq, inner_pr) = row_env_names_f_4147;
                                crate::prelude::call_then(start_build_spelling_f(inner_pr.clone()), move |build_spelling_f_4246: crate::lower::types::Env| ::prism_rtl::Turn::Finished((p2_pp.clone(), r2_pq.clone(), crate::lower::types::bind_f(&env_pf, &n_pg, &crate::lower::types::Bn::BnWidget(x_pm.clone(), build_spelling_f_4246, inner_pr.clone(), clx_po.clone())))))
                            }))),
                            ::std::option::Option::Some(crate::lower::types::Bn::BnEv(er_ps, t_pt)) => {
                                let pname_pu = crate::lower::node_::gn_of_f(&p_pd, &er_ps.node_p).name_p.clone();
                                let (rs_p11, r1_p12) = crate::lower::node_::fresh_name_f(&r_pe, &crate::lower::snake_f(&n_pg));
                                let (id_p13, r2_p14) = crate::lower::node_::add_gn_f(&r1_p12, &rs_p11, &t_pt, &crate::lower::node_::GnKind::GnPort, &crate::prelude::Nat::from(0u32));
                                let r3_pv = {
                                    let mut this: crate::lower::node_::Wx = r2_p14.clone();
                                    this.subs_p = crate::prelude::push(&this.subs_p, &(pname_pu.clone(), rs_p11.clone(), t_pt.clone()));
                                    this
                                };
                                let p2_p10 = if crate::check::types::has_text_f(&p_pd.ports_p, &pname_pu) {
                                    p_pd.clone()
                                } else {
                                    crate::lower::node_::connect_f(&with_port_f(&p_pd, &pname_pu), &crate::lower::node_::ev_ref_of_f(&p_pd, &er_ps.node_p), &crate::lower::node_::Sk::SkPort(pname_pu.clone()))
                                };
                                ::prism_rtl::Turn::Finished((p2_p10.clone(), r3_pv.clone(), crate::lower::types::bind_f(&env_pf, &n_pg, &crate::lower::types::Bn::BnEv(crate::lower::node_::ev_ref_of_f(&r3_pv, &id_p13), t_pt.clone()))))
                            },
                            ::std::option::Option::Some(crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(recv_p15, m_p16, xs_p17), _, t_p18)) => if &*recv_p15 == &crate::lower::model::Ex::XSelf {
                                ::prism_rtl::Turn::Finished((p_pd.clone(), r_pe.clone(), crate::lower::types::bind_f(&env_pf, &n_pg, &crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(parent_ref_p()), m_p16.clone(), xs_p17.clone()), crate::prelude::Array::from(vec![crate::lower::node_::Read::ParentRead(m_p16.clone())]), t_p18.clone()))))
                            } else {
                                ::prism_rtl::Turn::Finished(row_param_env_f(&p_pd, &r_pe, &env_pf, &menv_p2xxy, &n_pg))
                            },
                            ::std::option::Option::Some(crate::lower::types::Bn::BnDyn(_, _, _)) => ::prism_rtl::Turn::Finished(row_param_env_f(&p_pd, &r_pe, &env_pf, &menv_p2xxy, &n_pg)),
                            ::std::option::Option::Some(crate::lower::types::Bn::BnHold(f_p19, t_p1a)) => ::prism_rtl::Turn::Finished((p_pd.clone(), r_pe.clone(), crate::lower::types::bind_f(&env_pf, &n_pg, &crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(parent_ref_p()), f_p19.clone())), crate::prelude::Text::lit("get"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx])), crate::prelude::Array::from(vec![crate::lower::node_::Read::ParentRead(f_p19.clone())]), t_p1a.clone())))),
                            ::std::option::Option::Some(crate::lower::types::Bn::BnParts(bs_p1b)) => crate::prelude::call_then(start_row_parts_bn_f(p_pd.clone(), r_pe.clone(), n_pg.clone(), bs_p1b.clone()), move |row_parts_bn_f_5555: (crate::lower::node_::Wx, crate::lower::node_::Wx, crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>)| {
                                let (p2_p1c, r2_p1d, over_p1e) = row_parts_bn_f_5555;
                                ::prism_rtl::Turn::Finished((p2_p1c.clone(), r2_p1d.clone(), crate::lower::types::bind_f(&env_pf, &n_pg, &crate::lower::types::Bn::BnParts(over_p1e.clone()))))
                            }),
                            _ => ::prism_rtl::Turn::Finished((p_pd.clone(), r_pe.clone(), env_pf.clone())),
                        }
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::lower::node_::Wx, crate::lower::node_::Wx, crate::lower::types::Env), crate::prelude::Text)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::node_::Wx, crate::lower::types::Env)>>>
            }).cycle()
        })
    }
}

/// `Start RowEnvNames, x`: what the function value is when passed to `@Run`.
pub fn start_row_env_names_f(parent_p0: crate::lower::node_::Wx, row_wx_p1: crate::lower::node_::Wx, menv_p2: crate::lower::types::Env, written_p3: crate::prelude::Array<crate::prelude::Text>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::node_::Wx, crate::lower::types::Env)>> {
    ::std::rc::Rc::new(RowEnvNames { parent_p0, row_wx_p1, menv_p2, written_p3 })
}

/// ```prism
/// RowPartsBn: unbounded fn Wx, Wx, Text, [?Bn] -> ((Wx, Wx, [?Bn]))
/// ```
pub fn row_parts_bn_f(parent_p0: &crate::lower::node_::Wx, row_wx_p1: &crate::lower::node_::Wx, n_p2: &crate::prelude::Text, parts_p3: &crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>) -> (crate::lower::node_::Wx, crate::lower::node_::Wx, crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>) {
    crate::prelude::run_to_end(crate::prelude::fold_job(parts_p3.clone(), (parent_p0.clone(), row_wx_p1.clone(), crate::prelude::Array::new()), {
        let n_p2x = n_p2.clone();
        ::std::rc::Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::node_::Wx, crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>), ::std::option::Option<crate::lower::types::Bn>)| {
            let n_p2xy = n_p2x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (p_p4, r_p5, acc_p6) = p0;
                let b_o7 = p1;
                {
                    let (p2_p8, r2_p9, over_oa) = row_part_bn_f(&p_p4, &r_p5, &crate::prelude::Text::from(format!("{}_{}", &n_p2xy, &crate::prelude::len(&acc_p6))), &b_o7);
                    ::prism_rtl::Turn::Finished((p2_p8.clone(), r2_p9.clone(), crate::prelude::append(&acc_p6, &crate::prelude::Array::from(vec![over_oa.clone()]))))
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::lower::node_::Wx, crate::lower::node_::Wx, crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>), ::std::option::Option<crate::lower::types::Bn>)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::node_::Wx, crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>)>>>
    }))
}

/// The step machine of `RowPartsBn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RowPartsBn: unbounded fn Wx, Wx, Text, [?Bn] -> ((Wx, Wx, [?Bn]))
/// ```
pub struct RowPartsBn {
    pub parent_p0: crate::lower::node_::Wx,
    pub row_wx_p1: crate::lower::node_::Wx,
    pub n_p2: crate::prelude::Text,
    pub parts_p3: crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>,
}

impl ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::node_::Wx, crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>)> for RowPartsBn {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::lower::node_::Wx, crate::lower::node_::Wx, crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>)> {
        let parent_p0 = &self.parent_p0;
        let row_wx_p1 = &self.row_wx_p1;
        let n_p2 = &self.n_p2;
        let parts_p3 = &self.parts_p3;
        crate::prelude::fold_job(parts_p3.clone(), (parent_p0.clone(), row_wx_p1.clone(), crate::prelude::Array::new()), {
            let n_p2x = n_p2.clone();
            ::std::rc::Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::node_::Wx, crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>), ::std::option::Option<crate::lower::types::Bn>)| {
                let n_p2xy = n_p2x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let (p_p4, r_p5, acc_p6) = p0;
                    let b_o7 = p1;
                    {
                        let (p2_p8, r2_p9, over_oa) = row_part_bn_f(&p_p4, &r_p5, &crate::prelude::Text::from(format!("{}_{}", &n_p2xy, &crate::prelude::len(&acc_p6))), &b_o7);
                        ::prism_rtl::Turn::Finished((p2_p8.clone(), r2_p9.clone(), crate::prelude::append(&acc_p6, &crate::prelude::Array::from(vec![over_oa.clone()]))))
                    }
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::lower::node_::Wx, crate::lower::node_::Wx, crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>), ::std::option::Option<crate::lower::types::Bn>)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::node_::Wx, crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>)>>>
        }).cycle()
    }
}

/// `Start RowPartsBn, x`: what the function value is when passed to `@Run`.
pub fn start_row_parts_bn_f(parent_p0: crate::lower::node_::Wx, row_wx_p1: crate::lower::node_::Wx, n_p2: crate::prelude::Text, parts_p3: crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::node_::Wx, crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>)>> {
    ::std::rc::Rc::new(RowPartsBn { parent_p0, row_wx_p1, n_p2, parts_p3 })
}

/// ```prism
/// RowPartBn: unbounded fn Wx, Wx, Text, ?Bn -> ((Wx, Wx, ?Bn))
/// ```
pub fn row_part_bn_f(p_p0: &crate::lower::node_::Wx, r_p1: &crate::lower::node_::Wx, n_p2: &crate::prelude::Text, b_o3: &::std::option::Option<crate::lower::types::Bn>) -> (crate::lower::node_::Wx, crate::lower::node_::Wx, ::std::option::Option<crate::lower::types::Bn>) {
    match b_o3 {
        ::std::option::Option::Some(crate::lower::types::Bn::BnLocal(rs_p4, mode_p5, t_p6)) => (p_p0.clone(), r_p1.clone(), ::std::option::Option::Some(crate::lower::types::Bn::BnLocal(over_parent_f(rs_p4), crate::lower::types::Holding::Owned, t_p6.clone()))),
        ::std::option::Option::Some(crate::lower::types::Bn::BnEv(er_p7, _)) => {
            let pname_p8 = crate::lower::node_::gn_of_f(p_p0, &er_p7.node_p).name_p.clone();
            let t_p9 = crate::lower::node_::gn_of_f(p_p0, &er_p7.node_p).ty_p.clone();
            let (rs_pc, r1_pd) = crate::lower::node_::fresh_name_f(r_p1, &crate::lower::snake_f(n_p2));
            let (id_pe, r2_pf) = crate::lower::node_::add_gn_f(&r1_pd, &rs_pc, &t_p9, &crate::lower::node_::GnKind::GnPort, &crate::prelude::Nat::from(0u32));
            let r3_pa = {
                let mut this: crate::lower::node_::Wx = r2_pf.clone();
                this.subs_p = crate::prelude::push(&this.subs_p, &(pname_p8.clone(), rs_pc.clone(), t_p9.clone()));
                this
            };
            let p2_pb = if crate::check::types::has_text_f(&p_p0.ports_p, &pname_p8) {
                p_p0.clone()
            } else {
                crate::lower::node_::connect_f(&with_port_f(p_p0, &pname_p8), &crate::lower::node_::ev_ref_of_f(p_p0, &er_p7.node_p), &crate::lower::node_::Sk::SkPort(pname_p8.clone()))
            };
            (p2_pb.clone(), r3_pa.clone(), ::std::option::Option::Some(crate::lower::types::Bn::BnEv(crate::lower::node_::ev_ref_of_f(&r3_pa, &id_pe), t_p9.clone())))
        },
        ::std::option::Option::Some(crate::lower::types::Bn::BnDyn(ex_pg, rds_ph, t_pi)) => if on_self_rooted_f(ex_pg) && crate::prelude::fold(rds_ph, &true, &(|f_pj: &bool, rd_pk: &crate::lower::node_::Read| *f_pj && crate::lower::node_::finish::is_own_read_f(rd_pk))) {
            (p_p0.clone(), r_p1.clone(), ::std::option::Option::Some(crate::lower::types::Bn::BnDyn(over_parent_f(ex_pg), crate::prelude::each(rds_ph, &(|rd_pl: &crate::lower::node_::Read| as_parent_read_f(rd_pl))), t_pi.clone())))
        } else {
            {
                let (over_pm, p2_pn) = through_getter_f(p_p0, n_p2, ex_pg, rds_ph, t_pi);
                (p2_pn.clone(), r_p1.clone(), ::std::option::Option::Some(over_pm.clone()))
            }
        },
        ::std::option::Option::Some(crate::lower::types::Bn::BnHold(f_po, t_pp)) => (p_p0.clone(), r_p1.clone(), ::std::option::Option::Some(crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(parent_ref_p()), f_po.clone())), crate::prelude::Text::lit("get"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx])), crate::prelude::Array::from(vec![crate::lower::node_::Read::ParentRead(f_po.clone())]), t_pp.clone()))),
        ::std::option::Option::Some(crate::lower::types::Bn::BnParts(bs_pq)) => {
            let (p2_pr, r2_ps, over_pt) = row_parts_bn_f(p_p0, r_p1, n_p2, bs_pq);
            (p2_pr.clone(), r2_ps.clone(), ::std::option::Option::Some(crate::lower::types::Bn::BnParts(over_pt.clone())))
        },
        _ => (p_p0.clone(), r_p1.clone(), ::std::option::Option::None),
    }
}

/// ```prism
/// WholeOfBlock: fn Env, Env, Bool -> Env
/// ```
pub fn whole_of_block_f(menv_p0: &crate::lower::types::Env, env_p1: &crate::lower::types::Env, build_p2: &bool) -> crate::lower::types::Env {
    crate::prelude::fold(&crate::prelude::keys(&menv_p0.names_p), env_p1, &(|en_p3: &crate::lower::types::Env, k_p4: &crate::prelude::Text| if !((crate::syntax::lexer::chars::has_prefix_f(k_p4, &crate::prelude::Text::lit("#whole")) || (&crate::syntax::lexer::chars::before_suffix_o(k_p4, &crate::prelude::Text::lit("#port")) != &::std::option::Option::None)) || (&crate::syntax::lexer::chars::before_suffix_o(k_p4, &crate::prelude::Text::lit("#value")) != &::std::option::Option::None)) {
        en_p3.clone()
    } else {
        match crate::prelude::get(&menv_p0.names_p, k_p4) {
            ::std::option::Option::Some(crate::lower::types::Bn::BnLocal(rs_p5, mode_p6, t_p7)) => {
                let over_p8 = over_parent_f(&rs_p5);
                if !*build_p2 {
                    crate::lower::types::bind_f(en_p3, k_p4, &crate::lower::types::Bn::BnLocal(over_p8.clone(), crate::lower::types::Holding::Owned, t_p7.clone()))
                } else {
                    match crate::lower::types::through_parent_o(&over_p8) {
                        ::std::option::Option::Some(x_p9) => crate::lower::types::bind_f(en_p3, k_p4, &crate::lower::types::Bn::BnLocal(x_p9, crate::lower::types::Holding::Owned, t_p7.clone())),
                        ::std::option::Option::None => en_p3.clone(),
                    }
                }
            },
            _ => en_p3.clone(),
        }
    }))
}

/// ```prism
/// RowParamEnv: fn Wx, Wx, Env, Env, Text -> ((Wx, Wx, Env))
/// ```
pub fn row_param_env_f(p_p0: &crate::lower::node_::Wx, r_p1: &crate::lower::node_::Wx, env_p2: &crate::lower::types::Env, menv_p3: &crate::lower::types::Env, n_p4: &crate::prelude::Text) -> (crate::lower::node_::Wx, crate::lower::node_::Wx, crate::lower::types::Env) {
    match crate::prelude::get(&menv_p3.names_p, &crate::prelude::Text::from(format!("{}#row", n_p4))) {
        ::std::option::Option::Some(crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(_, m_p5, xs_p6), _, t_p7)) => (p_p0.clone(), r_p1.clone(), crate::lower::types::bind_f(env_p2, n_p4, &crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(parent_ref_p()), m_p5.clone(), xs_p6), crate::prelude::Array::from(vec![crate::lower::node_::Read::ParentRead(m_p5.clone())]), t_p7))),
        _ => match crate::prelude::get(&menv_p3.names_p, n_p4) {
            ::std::option::Option::Some(crate::lower::types::Bn::BnDyn(ex_p8, rds_p9, t_pa)) if (on_self_rooted_f(&ex_p8) && crate::prelude::fold(&rds_p9, &true, &(|f_pb: &bool, rd_pc: &crate::lower::node_::Read| *f_pb && crate::lower::node_::finish::is_own_read_f(rd_pc)))) => (p_p0.clone(), r_p1.clone(), crate::lower::types::bind_f(env_p2, n_p4, &crate::lower::types::Bn::BnDyn(over_parent_f(&ex_p8), crate::prelude::each(&rds_p9, &(|rd_pd: &crate::lower::node_::Read| as_parent_read_f(rd_pd))), t_pa.clone()))),
            ::std::option::Option::Some(crate::lower::types::Bn::BnDyn(ex_pe, rds_pf, t_pg)) => {
                let (over_ph, p2_pi) = through_getter_f(p_p0, n_p4, &ex_pe, &rds_pf, &t_pg);
                (p2_pi.clone(), r_p1.clone(), crate::lower::types::bind_f(env_p2, n_p4, &over_ph))
            },
            _ => (p_p0.clone(), r_p1.clone(), env_p2.clone()),
            _ => unreachable!("no arm matched"),
        },
    }
}

/// ```prism
/// ThroughGetter: fn Wx, Text, Ex, [Read], OutTy -> ((Bn, Wx))
/// ```
pub fn through_getter_f(p_p0: &crate::lower::node_::Wx, n_p1: &crate::prelude::Text, ex_p2: &crate::lower::model::Ex, rds_p3: &crate::prelude::Array<crate::lower::node_::Read>, t_p4: &crate::lower::model::OutTy) -> (crate::lower::types::Bn, crate::lower::node_::Wx) {
    let (getter_p6, p1_p7) = crate::lower::node_::fresh_name_f(p_p0, &crate::prelude::Text::from(format!("through_{}", &crate::lower::snake_f(n_p1))));
    let p2_p5 = {
        let mut this: crate::lower::node_::Wx = p1_p7.clone();
        this.getters_p = crate::prelude::push(&this.getters_p, &crate::lower::model::MethDef { name_p: getter_p6.clone(), recv_p: crate::lower::model::Recv::RecvRef, params_p: crate::prelude::Array::new(), cx_p: crate::lower::model::CxArg::CxRef, ret_p: t_p4.clone(), body_p: crate::prelude::Array::new(), tail_p: ex_p2.clone(), doc_p: crate::prelude::Text::from(format!("`{}` of a block around this one, as this block\'s rows read it through it.", n_p1)) });
        this.dyn_reads_p = crate::prelude::insert(&this.dyn_reads_p, &getter_p6, rds_p3);
        this
    };
    (crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(parent_ref_p()), getter_p6.clone(), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx])), crate::prelude::Array::from(vec![crate::lower::node_::Read::ParentRead(getter_p6.clone())]), t_p4.clone()), p2_p5.clone())
}

/// ```prism
/// OverParent: fn Ex -> Ex
/// ```
pub fn over_parent_f(x_p0: &crate::lower::model::Ex) -> crate::lower::model::Ex {
    match x_p0 {
        crate::lower::model::Ex::XSelf => parent_ref_p(),
        crate::lower::model::Ex::XField(y_p1, f_p2) => crate::lower::model::Ex::XField(::std::rc::Rc::new(over_parent_f(&**y_p1)), f_p2.clone()),
        crate::lower::model::Ex::XFieldOf(y_p3, o_p4, f_p5) => crate::lower::model::Ex::XFieldOf(::std::rc::Rc::new(over_parent_f(&**y_p3)), o_p4.clone(), f_p5.clone()),
        crate::lower::model::Ex::XPart(y_p6, k_p7) => crate::lower::model::Ex::XPart(::std::rc::Rc::new(over_parent_f(&**y_p6)), k_p7.clone()),
        crate::lower::model::Ex::XMethod(y_p8, m_p9, xs_pa) => crate::lower::model::Ex::XMethod(::std::rc::Rc::new(over_parent_f(&**y_p8)), m_p9.clone(), xs_pa.clone()),
        crate::lower::model::Ex::XUpgrade(y_pb) => crate::lower::model::Ex::XUpgrade(::std::rc::Rc::new(over_parent_f(&**y_pb))),
        _ => crate::lower::model::Ex::XField(::std::rc::Rc::new(parent_ref_p()), crate::lower::types::place_stem_f(x_p0)),
    }
}

/// ```prism
/// let parentRef
/// ```
pub fn parent_ref_p() -> crate::lower::model::Ex {
    crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XUpgrade(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::lit("parent"))))), crate::prelude::Text::lit("expect"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XStr(crate::prelude::Text::lit("the block outlives its rows"))]))
}

/// ```prism
/// let parentArg
/// ```
pub fn parent_arg_p() -> crate::lower::model::Ex {
    crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XUpgrade(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("parent"))))), crate::prelude::Text::lit("expect"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XStr(crate::prelude::Text::lit("the block outlives its rows"))]))
}

/// ```prism
/// WithPort: fn Wx, Text -> Wx
/// ```
pub fn with_port_f(wx_p0: &crate::lower::node_::Wx, pname_p1: &crate::prelude::Text) -> crate::lower::node_::Wx {
    let mut this: crate::lower::node_::Wx = wx_p0.clone();
    this.ports_p = crate::prelude::push(&this.ports_p, pname_p1);
    this
}

/// ```prism
/// RebuildLine: unbounded fn Wx, Env, Env, Expr, Block, Expr, ?Bn -> ((Wx, Wres))
/// ```
pub fn rebuild_line_f(wx_p0: &crate::lower::node_::Wx, benv_p1: &crate::lower::types::Env, menv_p2: &crate::lower::types::Env, scrut_p3: &crate::syntax::Expr, body_p4: &crate::syntax::Block, e_p5: &crate::syntax::Expr, bound_o6: &::std::option::Option<crate::lower::types::Bn>) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    let lx_p7 = wx_p0.lx_p.clone();
    let pos_p8 = wx_p0.pos_p.clone();
    let wx1_p9 = {
        let mut this: crate::lower::node_::Wx = wx_p0.clone();
        this.pos_p = crate::lower::model::next_pos_f(&this.pos_p);
        this
    };
    let (src_ex_pb, reads_pc) = crate::lower::node_::dynamics::dynamic_expr_f(&wx1_p9, menv_p2, scrut_p3);
    let vt_pa = crate::lower::types::out_ty_of_f(&lx_p7, &crate::lower::types::peel_f(&crate::lower::type_at_f(&lx_p7, &scrut_p3.span_p)));
    let (name_pd, wx2_pe) = crate::lower::node_::fresh_name_f(&wx1_p9, &crate::prelude::Text::lit("generation"));
    if gives_dynamic_f(&crate::lower::type_at_f(&lx_p7, &e_p5.span_p)) {
        rebuild_dynamic_f(&wx2_pe, menv_p2, body_p4, &src_ex_pb, &reads_pc, &vt_pa, &name_pd, &pos_p8)
    } else {
        {
            let (up_id_pj, wx3_pk) = match bound_o6 {
                ::std::option::Option::Some(crate::lower::types::Bn::BnEv(er_pi, _)) => (er_pi.node_p.clone(), wx2_pe.clone()),
                _ => crate::lower::node_::add_gn_f(&wx2_pe, &crate::prelude::Text::from(format!("{}_fired", &name_pd)), &crate::lower::types::out_ty_of_f(&lx_p7, &crate::lower::types::peel_f(&crate::lower::type_at_f(&lx_p7, &e_p5.span_p))), &crate::lower::node_::GnKind::GnNamed, &crate::prelude::Nat::from(0u32)),
            };
            let (cases_pl, wx4_pm) = gen_cases_f(&wx3_pk, menv_p2, body_p4, &vt_pa, &name_pd);
            let row_defs_pf = crate::prelude::each(&cases_pl, &(|c_pn: &GenCase| c_pn.node_p.clone()));
            let select_pg = gen_select_f(&wx4_pm, menv_p2, body_p4, &cases_pl, &pos_p8, &crate::prelude::Array::new(), &true);
            let wx5_ph = {
                let mut this: crate::lower::node_::Wx = wx4_pm.clone();
                this.gens_p = crate::prelude::push(&this.gens_p, &crate::lower::model::GenDef { name_p: name_pd.clone(), pos_p: pos_p8.clone(), at_p: crate::lower::node_::finish::place_at_f(wx_p0, &crate::prelude::Text::lit("self"), &pos_p8), source_p: src_ex_pb.clone(), value_ty_p: vt_pa.clone(), select_p: select_pg.clone(), transparent_p: false, width_p: crate::prelude::Nat::from(0u32), moved_p: crate::prelude::or(&crate::lower::node_::finish::hosted_rows_o(wx_p0), &crate::prelude::Text::lit("")), early_p: false, gappy_p: false, rebased_p: false });
                this.gen_holds_p = crate::prelude::push(&this.gen_holds_p, &(name_pd.clone(), reads_pc.clone()));
                this.rows_p = crate::prelude::fold(&row_defs_pf, &this.rows_p, &(|acc_po: &crate::prelude::Array<crate::lower::model::NodeDef>, rd_pp: &crate::lower::model::NodeDef| crate::prelude::append(&crate::prelude::push(acc_po, rd_pp), &rd_pp.children_p)));
                this.getters_p = crate::prelude::push(&crate::prelude::push(&this.getters_p, &gen_up_f(&name_pd, &crate::lower::node_::gn_of_f(&wx4_pm, &up_id_pj).name_p, &crate::lower::node_::gn_of_f(&wx4_pm, &up_id_pj).ty_p)), &gen_up_above_f(&name_pd, &crate::lower::node_::gn_of_f(&wx4_pm, &up_id_pj).name_p));
                this
            };
            (wx5_ph.clone(), crate::lower::node_::Wres::WrEv(crate::lower::node_::ev_ref_of_f(&wx5_ph, &up_id_pj)))
        }
    }
}

/// ```prism
/// GivesDynamic: fn Ty -> Bool
/// ```
pub fn gives_dynamic_f(t_p0: &crate::check::types::Ty) -> bool {
    'm13585: {
        if let crate::check::types::Ty::TySig(m13585_0_0, m13585_0_1) = t_p0 && (m13585_0_0 == &crate::prelude::Text::lit("$")) && let crate::check::types::Ty::TySig(m13585_0_1_r_0, _) = &**m13585_0_1 && (m13585_0_1_r_0 == &crate::prelude::Text::lit("$")) {
            break 'm13585 true;
        }
        if let crate::check::types::Ty::TySig(m13585_1_0, m13585_1_1) = t_p0 && (m13585_1_0 == &crate::prelude::Text::lit("$")) && let crate::check::types::Ty::TySig(m13585_1_1_r_0, _) = &**m13585_1_1 && (m13585_1_1_r_0 == &crate::prelude::Text::lit("!")) {
            break 'm13585 false;
        }
        if let crate::check::types::Ty::TySig(m13585_2_0, m13585_2_1) = t_p0 && (m13585_2_0 == &crate::prelude::Text::lit("$")) && let crate::check::types::Ty::TyCon(m13585_2_1_r_0, m13585_2_1_r_1) = &**m13585_2_1 && (m13585_2_1_r_0 == &crate::prelude::Text::lit("unit")) && (m13585_2_1_r_1.len() == 0) {
            break 'm13585 false;
        }
        if let crate::check::types::Ty::TySig(m13585_3_0, _) = t_p0 && (m13585_3_0 == &crate::prelude::Text::lit("$")) {
            break 'm13585 true;
        }
        if let crate::check::types::Ty::TyAt(i_p1, _) = t_p0 {
            break 'm13585 gives_dynamic_f(&**i_p1);
        }
        false
    }
}

/// ```prism
/// RebuildDynamic: unbounded fn Wx, Env, Block, Ex, [Read], OutTy, Text, Pos -> ((Wx, Wres))
/// ```
pub fn rebuild_dynamic_f(wx_p0: &crate::lower::node_::Wx, menv_p1: &crate::lower::types::Env, body_p2: &crate::syntax::Block, src_ex_p3: &crate::lower::model::Ex, reads_p4: &crate::prelude::Array<crate::lower::node_::Read>, vt_p5: &crate::lower::model::OutTy, name_p6: &crate::prelude::Text, pos_p7: &crate::lower::model::Pos) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    let row_name_p8 = crate::prelude::Text::from(format!("{}Gen{}", &wx_p0.node_p, &crate::lower::node_::keyed::row_suffix_f(wx_p0)));
    let whole_p9 = gen_row_of_f(wx_p0, menv_p1, body_p2, vt_p5, &row_name_p8, name_p6);
    let shape_oa = match &whole_p9.dyn_result_o {
        ::std::option::Option::Some(rt_pb) => ::std::option::Option::Some((crate::lower::model::OutTy::OutDyn(::std::rc::Rc::new(rt_pb.clone())), crate::prelude::Text::lit("result_dynamic"))),
        ::std::option::Option::None => match &whole_p9.plain_result_o {
            ::std::option::Option::Some(rt_pc) => ::std::option::Option::Some((rt_pc.clone(), crate::prelude::Text::lit("result_value"))),
            ::std::option::Option::None => ::std::option::Option::None,
        },
    };
    match &shape_oa {
        ::std::option::Option::None => {
            let wx2_pd = {
                let mut this: crate::lower::node_::Wx = whole_p9.parent_p.clone();
                this.build_p = crate::prelude::push(&this.build_p, &crate::lower::expr::refusal_do_f(&crate::prelude::Text::lit("a `rebuild` whose generation gives a dynamic it does not lower")));
                this
            };
            (wx2_pd.clone(), crate::lower::node_::Wres::WrUnit)
        },
        ::std::option::Option::Some((dyn_ty_pe, taken_pf)) => {
            let result_pg = crate::prelude::Text::from(format!("{}_result", name_p6));
            let live_ph = crate::prelude::Text::from(format!("{}_live", &result_pg));
            let what_pi = crate::prelude::Text::from(format!("the dynamic of the `rebuild` at place {}", &crate::lower::model::place_text_f(pos_p7)));
            let tail_pj = crate::prelude::append(&crate::prelude::append(&crate::prelude::Array::from(vec![crate::lower::model::Ex::XWeak(::std::rc::Rc::new(crate::lower::model::Ex::XSelf))]), &crate::lower::node_::keyed::hosted_passed_f(wx_p0)), &crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx]));
            let built_pk = crate::lower::expr::try_of_f(&crate::lower::model::Ex::XCall(crate::lower::model::ref_child_f(&crate::lower::site_ref_f(&wx_p0.lx_p, &whole_p9.node_p.name_p), &crate::prelude::Text::lit("build")), crate::prelude::append(&crate::prelude::Array::from(vec![crate::lower::model::Ex::XVar(crate::prelude::Text::lit("path")), crate::lower::model::Ex::XVar(crate::prelude::Text::lit("value"))]), &tail_pj)));
            let kept_pl = crate::lower::model::Do::DoAssign(crate::lower::model::Ex::XDeref(::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), live_ph.clone())), crate::prelude::Text::lit("borrow_mut"), crate::prelude::Array::new()))), crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Some")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("row"))), taken_pf.clone(), crate::prelude::Array::new())])));
            let marked_pm = crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::from(format!("{}_snap", &result_pg)))), crate::prelude::Text::lit("mark"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx])));
            let select_pn = crate::lower::model::Ex::XBlock(crate::prelude::Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("row")), built_pk.clone()), kept_pl.clone(), marked_pm.clone()]), ::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("row"))));
            let current_po = crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::from(format!("{}", &live_ph)))), crate::prelude::Text::lit("borrow"), crate::prelude::Array::new())))), crate::prelude::Text::lit("expect"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XStr(crate::prelude::Text::lit("a `rebuild` has a generation from its build on"))]));
            let wx2_pp = {
                let mut this: crate::lower::node_::Wx = whole_p9.parent_p.clone();
                this.gens_p = crate::prelude::push(&this.gens_p, &crate::lower::model::GenDef { name_p: name_p6.clone(), pos_p: pos_p7.clone(), at_p: crate::lower::node_::finish::place_at_f(wx_p0, &crate::prelude::Text::lit("self"), pos_p7), source_p: src_ex_p3.clone(), value_ty_p: vt_p5.clone(), select_p: select_pn.clone(), transparent_p: false, width_p: crate::prelude::Nat::from(0u32), moved_p: crate::prelude::or(&crate::lower::node_::finish::hosted_rows_o(wx_p0), &crate::prelude::Text::lit("")), early_p: false, gappy_p: false, rebased_p: false });
                this.gen_holds_p = crate::prelude::push(&this.gen_holds_p, &(name_p6.clone(), reads_p4.clone()));
                this.rows_p = crate::prelude::append(&crate::prelude::push(&this.rows_p, &whole_p9.node_p), &whole_p9.node_p.children_p);
                this.taken_p = crate::prelude::append(&this.taken_p, &crate::prelude::Array::from(vec![result_pg.clone(), live_ph.clone(), crate::prelude::Text::from(format!("{}_now", &result_pg)), crate::prelude::Text::from(format!("{}_snap", &result_pg)), crate::prelude::Text::from(format!("{}_publish", &result_pg)), crate::prelude::Text::from(format!("{}_moved", &result_pg))]));
                this.fields_p = crate::prelude::append(&this.fields_p, &crate::prelude::Array::from(vec![(live_ph.clone(), crate::lower::model::OutTy::OutCell(::std::rc::Rc::new(crate::lower::model::OutTy::OutOpt(::std::rc::Rc::new(dyn_ty_pe.clone())))), crate::prelude::Text::lit("the current generation\'s result, which the snapshot of the `rebuild`\'s dynamic is taken from")), (crate::prelude::Text::from(format!("{}_snap", &result_pg)), crate::lower::model::OutTy::OutSnapshot(::std::rc::Rc::new(dyn_ty_pe.clone())), crate::prelude::Text::from(format!("the `rebuild` at place {}\'s dynamic, structural: its snapshots, the generations\' results and the lagged dynamic (pick ST)", &crate::lower::model::place_text_f(pos_p7))))]));
                this.moves_p = crate::prelude::push(&this.moves_p, &(live_ph.clone(), crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::RefCell::new")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XNone]))));
                this.inits_p = crate::prelude::push(&this.inits_p, &(crate::prelude::Text::from(format!("{}_snap", &result_pg)), crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Snapshot::new")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XStr(what_pi.clone())]))));
                this.getters_p = crate::prelude::append(&this.getters_p, &crate::prelude::Array::from(vec![crate::lower::model::MethDef { name_p: crate::prelude::Text::from(format!("{}_now", &result_pg)), recv_p: crate::lower::model::Recv::RecvRef, params_p: crate::prelude::Array::new(), cx_p: crate::lower::model::CxArg::CxRef, ret_p: dyn_ty_pe.clone(), body_p: crate::prelude::Array::new(), tail_p: current_po.clone(), doc_p: crate::prelude::Text::lit("The current generation\'s result: what the snapshot of the `rebuild`\'s dynamic is taken from (pick ST).") }, crate::lower::node_::static_::snap_getter_f(&result_pg, dyn_ty_pe, &crate::prelude::Text::lit("The `rebuild`\'s dynamic, its generation\'s result, a structural dynamic (pick ST): one tick behind the generations, the snapshot of the tick before the tick the read point is after."))]));
                this.snaps_p = crate::prelude::push(&this.snaps_p, &crate::lower::node_::SnapDef { name_p: result_pg.clone(), live_p: crate::prelude::Text::from(format!("{}_now", &result_pg)), ty_p: dyn_ty_pe.clone(), eq_p: false, builder_p: name_p6.clone(), before_p: false, what_p: what_pi.clone() });
                this
            };
            (wx2_pp.clone(), crate::lower::node_::Wres::WrDyn(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), result_pg.clone(), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx])), crate::prelude::Array::from(vec![crate::lower::node_::Read::OwnRead(result_pg.clone())]), dyn_ty_pe.clone()))
        },
    }
}

/// ```prism
/// ClauseWidgetLine: unbounded fn Wx, Env, Env, Expr, Block, Text, ValInfo, Expr, [Arg] -> ((Wx, Wres))
/// ```
pub fn clause_widget_line_f(wx_p0: &crate::lower::node_::Wx, benv_p1: &crate::lower::types::Env, menv_p2: &crate::lower::types::Env, scrut_p3: &crate::syntax::Expr, call_p4: &crate::syntax::Block, qk_p5: &crate::prelude::Text, v_p6: &crate::check::env::ValInfo, e_p7: &crate::syntax::Expr, args_p8: &crate::prelude::Array<crate::syntax::Arg>) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    let lx_p9 = wx_p0.lx_p.clone();
    let out_ty_pa = crate::lower::types::out_ty_of_f(&lx_p9, &crate::lower::types::out_of_f(&crate::lower::type_at_f(&lx_p9, &e_p7.span_p)));
    let layer_pb = result_layer_f(&crate::lower::type_at_f(&lx_p9, &e_p7.span_p));
    if crate::lower::types::is_bundle_f(&crate::lower::node_::def::line_out_full_f(&lx_p9, e_p7)) {
        bundle_clause_line_f(wx_p0, menv_p2, scrut_p3, call_p4, qk_p5, v_p6, e_p7)
    } else {
        if (&layer_pb == &crate::lower::types::Layer::LyPlain) && (&out_ty_pa != &crate::lower::model::OutTy::OutUnit) {
            early_clause_line_f(wx_p0, benv_p1, menv_p2, scrut_p3, qk_p5, v_p6, e_p7, args_p8, &out_ty_pa)
        } else {
            if &layer_pb == &crate::lower::types::Layer::LyDyn {
                dyn_clause_line_f(wx_p0, menv_p2, scrut_p3, call_p4, qk_p5, v_p6, e_p7)
            } else {
                static_clause_line_f(wx_p0, menv_p2, scrut_p3, call_p4, qk_p5, v_p6, e_p7)
            }
        }
    }
}

/// ```prism
/// ResultLayer: fn Ty -> Layer
/// ```
pub fn result_layer_f(t_p0: &crate::check::types::Ty) -> crate::lower::types::Layer {
    match t_p0 {
        crate::check::types::Ty::TyAt(i_p1, _) => crate::lower::types::layer_of_f(&**i_p1),
        _ => crate::lower::types::layer_of_f(t_p0),
    }
}

/// ```prism
/// DynClauseLine: unbounded fn Wx, Env, Expr, Block, Text, ValInfo, Expr -> ((Wx, Wres))
/// ```
pub fn dyn_clause_line_f(wx_p0: &crate::lower::node_::Wx, menv_p1: &crate::lower::types::Env, scrut_p2: &crate::syntax::Expr, call_p3: &crate::syntax::Block, qk_p4: &crate::prelude::Text, v_p5: &crate::check::env::ValInfo, e_p6: &crate::syntax::Expr) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    let lx_p7 = wx_p0.lx_p.clone();
    let pos_p8 = wx_p0.pos_p.clone();
    let call_args_p9 = match clause_call_o(&lx_p7, call_p3) {
        ::std::option::Option::Some((_, xs_pn)) => xs_pn,
        ::std::option::Option::None => crate::prelude::Array::new(),
    };
    let (src_ex_po, reads_pp) = crate::lower::node_::dynamics::dynamic_expr_f(wx_p0, menv_p1, scrut_p2);
    let vt_pa = crate::lower::types::out_ty_of_f(&lx_p7, &crate::lower::types::peel_f(&crate::lower::type_at_f(&lx_p7, &scrut_p2.span_p)));
    let (name_pq, wx1_pr) = crate::lower::node_::fresh_name_f(wx_p0, &crate::prelude::Text::lit("generation"));
    let res_pb = crate::prelude::Text::from(format!("{}_res", &name_pq));
    let clauses_pc = crate::lower::jobs::clauses_of_f(&lx_p7.g_p, qk_p4);
    let row_name_pd = crate::prelude::Text::from(format!("{}Gen{}", &wx_p0.node_p, &crate::lower::node_::keyed::row_suffix_f(wx_p0)));
    let (rows_p11, wx2_p12) = crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(&clauses_pc)), (crate::prelude::Array::new(), wx1_pr.clone()), {
        let clauses_pcx = clauses_pc.clone();
        let menv_p1x = menv_p1.clone();
        let v_p5x = v_p5.clone();
        let row_name_pdx = row_name_pd.clone();
        let name_pqx = name_pq.clone();
        let wx_p0x = wx_p0.clone();
        let call_args_p9x = call_args_p9.clone();
        ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Array<ClauseRow>, crate::lower::node_::Wx), crate::prelude::Nat)| {
            let clauses_pcxy = clauses_pcx.clone();
            let menv_p1xy = menv_p1x.clone();
            let v_p5xy = v_p5x.clone();
            let row_name_pdxy = row_name_pdx.clone();
            let name_pqxy = name_pqx.clone();
            let wx_p0xy = wx_p0x.clone();
            let call_args_p9xy = call_args_p9x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (acc_ps, w_pt) = p0;
                let i_pu = p1;
                {
                    let c_pv = crate::prelude::or(&crate::prelude::index(&clauses_pcxy, &i_pu), &crate::lower::functions::dummy_clause_p());
                    crate::prelude::call_then(start_clause_row_of_f(w_pt.clone(), menv_p1xy.clone(), c_pv.clone(), v_p5xy.clone(), crate::prelude::Text::from(format!("{}{}", &row_name_pdxy, &i_pu)), name_pqxy.clone(), true, crate::lower::model::OutTy::OutWeak(wx_p0xy.node_p.clone()), call_args_p9xy.clone(), false), move |clause_row_of_f_20752: ClauseRow| {
                        let cr_p10 = clause_row_of_f_20752;
                        ::prism_rtl::Turn::Finished((crate::prelude::push(&acc_ps, &cr_p10), cr_p10.parent_p.clone()))
                    })
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Array<ClauseRow>, crate::lower::node_::Wx), crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<ClauseRow>, crate::lower::node_::Wx)>>>
    }));
    let width_pe = crate::prelude::fold(&rows_p11, &crate::prelude::Nat::from(0u32), &(|acc_p13: &crate::prelude::Nat, cr_p14: &ClauseRow| crate::prelude::max(acc_p13, &cr_p14.width_p)));
    let cases_pf = crate::prelude::each(&rows_p11, &(|cr_p15: &ClauseRow| cr_p15.case_p.clone()));
    let row_obj_pg = crate::lower::model::OutTy::OutObj(::std::rc::Rc::new(crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Row")), crate::prelude::Array::new())));
    let scrut_ex_ph = clause_scrutinee_f(&lx_p7, menv_p1, v_p5, &call_args_p9);
    let tail_pi = crate::prelude::append(&crate::prelude::append(&crate::prelude::Array::from(vec![crate::lower::model::Ex::XWeak(::std::rc::Rc::new(crate::lower::model::Ex::XSelf))]), &crate::lower::node_::keyed::hosted_passed_f(wx_p0)), &crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx]));
    let gaps_pj = row_gaps_f(&rows_p11, &width_pe);
    let arms_pk = crate::prelude::fold(&cases_pf, &crate::prelude::Array::new(), &(|built_p16: &crate::prelude::Array<crate::lower::model::XArm>, c_p17: &GenCase| {
        let i_p18 = crate::prelude::len(built_p16);
        let made_p19 = crate::lower::expr::try_of_f(&crate::lower::model::Ex::XCall(crate::lower::model::ref_child_f(&crate::lower::site_ref_f(&lx_p7, &c_p17.node_p.name_p), &crate::prelude::Text::lit("build")), crate::prelude::append(&crate::prelude::append(&crate::prelude::Array::from(vec![crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("path"))))]), &c_p17.passed_p), &tail_pi)));
        let kept_p1a = crate::lower::model::Do::DoAssign(crate::lower::model::Ex::XDeref(::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), res_pb.clone())), crate::prelude::Text::lit("borrow_mut"), crate::prelude::Array::new()))), crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Some")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("row"))), crate::prelude::Text::lit("result_dynamic"), crate::prelude::Array::new())])));
        crate::prelude::push(built_p16, &crate::lower::model::XArm { pat_p: c_p17.pat_p.clone(), conds_p: c_p17.conds_p.clone(), body_p: crate::lower::model::Ex::XBlock(crate::prelude::append(&crate::prelude::Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("row")), made_p19.clone()), kept_p1a.clone()]), &gap_set_f(&name_pq, &crate::prelude::or(&crate::prelude::index(&gaps_pj, &i_p18), &::std::option::Option::None))), ::std::rc::Rc::new(crate::lower::model::Ex::XCast(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("row"))), row_obj_pg.clone()))) })
    }));
    let select_pl = with_row_base_f(wx_p0, &crate::prelude::Text::lit("self"), &pos_p8, &crate::lower::types::own_f(&crate::lower::expr::arms_value_f(&scrut_ex_ph, &arms_pk, &crate::prelude::Text::lit("\'select"), &row_obj_pg)));
    let wx3_pm = {
        let mut this: crate::lower::node_::Wx = wx2_p12.clone();
        this.pos_p = crate::lower::model::Pos { scope_p: pos_p8.scope_p.clone(), at_p: &pos_p8.at_p + &width_pe };
        this.gens_p = crate::prelude::push(&this.gens_p, &crate::lower::model::GenDef { name_p: name_pq.clone(), pos_p: pos_p8.clone(), at_p: crate::lower::node_::finish::place_at_f(wx_p0, &crate::prelude::Text::lit("self"), &pos_p8), source_p: src_ex_po.clone(), value_ty_p: vt_pa.clone(), select_p: select_pl.clone(), transparent_p: true, width_p: width_pe.clone(), moved_p: crate::prelude::or(&crate::lower::node_::finish::hosted_rows_o(wx_p0), &crate::prelude::Text::lit("")), early_p: false, gappy_p: is_gappy_f(&gaps_pj), rebased_p: false });
        this.gen_holds_p = crate::prelude::push(&this.gen_holds_p, &(name_pq.clone(), reads_pp.clone()));
        this.rows_p = crate::prelude::fold(&cases_pf, &this.rows_p, &(|acc_p1b: &crate::prelude::Array<crate::lower::model::NodeDef>, gc_p1c: &GenCase| crate::prelude::append(&crate::prelude::push(acc_p1b, &gc_p1c.node_p), &gc_p1c.node_p.children_p)));
        this
    };
    kept_dyn_result_f(&wx3_pm, &name_pq, &rows_p11)
}

/// ```prism
/// BundleClauseLine: unbounded fn Wx, Env, Expr, Block, Text, ValInfo, Expr -> ((Wx, Wres))
/// ```
pub fn bundle_clause_line_f(wx_p0: &crate::lower::node_::Wx, menv_p1: &crate::lower::types::Env, scrut_p2: &crate::syntax::Expr, call_p3: &crate::syntax::Block, qk_p4: &crate::prelude::Text, v_p5: &crate::check::env::ValInfo, e_p6: &crate::syntax::Expr) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    let lx_p7 = wx_p0.lx_p.clone();
    let pos_p8 = wx_p0.pos_p.clone();
    let call_args_p9 = match clause_call_o(&lx_p7, call_p3) {
        ::std::option::Option::Some((_, xs_pn)) => xs_pn,
        ::std::option::Option::None => crate::prelude::Array::new(),
    };
    let (src_ex_po, reads_pp) = crate::lower::node_::dynamics::dynamic_expr_f(wx_p0, menv_p1, scrut_p2);
    let vt_pa = crate::lower::types::out_ty_of_f(&lx_p7, &crate::lower::types::peel_f(&crate::lower::type_at_f(&lx_p7, &scrut_p2.span_p)));
    let (name_pq, wx1_pr) = crate::lower::node_::fresh_name_f(wx_p0, &crate::prelude::Text::lit("generation"));
    let clauses_pb = crate::lower::jobs::clauses_of_f(&lx_p7.g_p, qk_p4);
    let row_name_pc = crate::prelude::Text::from(format!("{}Gen{}", &wx_p0.node_p, &crate::lower::node_::keyed::row_suffix_f(wx_p0)));
    let (rows_p11, wx2_p12) = crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(&clauses_pb)), (crate::prelude::Array::new(), wx1_pr.clone()), {
        let clauses_pbx = clauses_pb.clone();
        let menv_p1x = menv_p1.clone();
        let v_p5x = v_p5.clone();
        let row_name_pcx = row_name_pc.clone();
        let name_pqx = name_pq.clone();
        let wx_p0x = wx_p0.clone();
        let call_args_p9x = call_args_p9.clone();
        ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Array<ClauseRow>, crate::lower::node_::Wx), crate::prelude::Nat)| {
            let clauses_pbxy = clauses_pbx.clone();
            let menv_p1xy = menv_p1x.clone();
            let v_p5xy = v_p5x.clone();
            let row_name_pcxy = row_name_pcx.clone();
            let name_pqxy = name_pqx.clone();
            let wx_p0xy = wx_p0x.clone();
            let call_args_p9xy = call_args_p9x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (acc_ps, w_pt) = p0;
                let i_pu = p1;
                {
                    let c_pv = crate::prelude::or(&crate::prelude::index(&clauses_pbxy, &i_pu), &crate::lower::functions::dummy_clause_p());
                    crate::prelude::call_then(start_clause_row_of_f(w_pt.clone(), menv_p1xy.clone(), c_pv.clone(), v_p5xy.clone(), crate::prelude::Text::from(format!("{}{}", &row_name_pcxy, &i_pu)), name_pqxy.clone(), true, crate::lower::model::OutTy::OutWeak(wx_p0xy.node_p.clone()), call_args_p9xy.clone(), false), move |clause_row_of_f_23648: ClauseRow| {
                        let cr_p10 = clause_row_of_f_23648;
                        ::prism_rtl::Turn::Finished((crate::prelude::push(&acc_ps, &cr_p10), cr_p10.parent_p.clone()))
                    })
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Array<ClauseRow>, crate::lower::node_::Wx), crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<ClauseRow>, crate::lower::node_::Wx)>>>
    }));
    let width_pd = crate::prelude::fold(&rows_p11, &crate::prelude::Nat::from(0u32), &(|acc_p13: &crate::prelude::Nat, cr_p14: &ClauseRow| crate::prelude::max(acc_p13, &cr_p14.width_p)));
    let cases_pe = crate::prelude::each(&rows_p11, &(|cr_p15: &ClauseRow| cr_p15.case_p.clone()));
    let row_obj_pf = crate::lower::model::OutTy::OutObj(::std::rc::Rc::new(crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Row")), crate::prelude::Array::new())));
    let kept_pg = keep_parts_f(&wx2_p12, &name_pq, &rows_bundle_f(&rows_p11), &crate::lower::node_::keyed::bundle_part_tys_f(&crate::lower::node_::def::line_out_full_f(&lx_p7, e_p6)));
    let scrut_ex_ph = clause_scrutinee_f(&lx_p7, menv_p1, v_p5, &call_args_p9);
    let tail_pi = crate::prelude::append(&crate::prelude::append(&crate::prelude::Array::from(vec![crate::lower::model::Ex::XWeak(::std::rc::Rc::new(crate::lower::model::Ex::XSelf))]), &crate::lower::node_::keyed::hosted_passed_f(wx_p0)), &crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx]));
    let gaps_pj = row_gaps_f(&rows_p11, &width_pd);
    let arms_pk = crate::prelude::fold(&cases_pe, &crate::prelude::Array::new(), &(|built_p16: &crate::prelude::Array<crate::lower::model::XArm>, c_p17: &GenCase| {
        let i_p18 = crate::prelude::len(built_p16);
        let made_p19 = crate::lower::expr::try_of_f(&crate::lower::model::Ex::XCall(crate::lower::model::ref_child_f(&crate::lower::site_ref_f(&lx_p7, &c_p17.node_p.name_p), &crate::prelude::Text::lit("build")), crate::prelude::append(&crate::prelude::append(&crate::prelude::Array::from(vec![crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("path"))))]), &c_p17.passed_p), &tail_pi)));
        crate::prelude::push(built_p16, &crate::lower::model::XArm { pat_p: c_p17.pat_p.clone(), conds_p: c_p17.conds_p.clone(), body_p: crate::lower::model::Ex::XBlock(crate::prelude::append(&crate::prelude::append(&crate::prelude::Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("row")), made_p19.clone())]), &kept_pg.keeps_p), &gap_set_f(&name_pq, &crate::prelude::or(&crate::prelude::index(&gaps_pj, &i_p18), &::std::option::Option::None))), ::std::rc::Rc::new(crate::lower::model::Ex::XCast(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("row"))), row_obj_pf.clone()))) })
    }));
    let select_pl = with_row_base_f(wx_p0, &crate::prelude::Text::lit("self"), &pos_p8, &crate::lower::types::own_f(&crate::lower::expr::arms_value_f(&scrut_ex_ph, &arms_pk, &crate::prelude::Text::lit("\'select"), &row_obj_pf)));
    let wx3_pm = {
        let mut this: crate::lower::node_::Wx = kept_pg.wx_p.clone();
        this.pos_p = crate::lower::model::Pos { scope_p: pos_p8.scope_p.clone(), at_p: &pos_p8.at_p + &width_pd };
        this.gens_p = crate::prelude::push(&this.gens_p, &crate::lower::model::GenDef { name_p: name_pq.clone(), pos_p: pos_p8.clone(), at_p: crate::lower::node_::finish::place_at_f(wx_p0, &crate::prelude::Text::lit("self"), &pos_p8), source_p: src_ex_po.clone(), value_ty_p: vt_pa.clone(), select_p: select_pl.clone(), transparent_p: true, width_p: width_pd.clone(), moved_p: crate::prelude::or(&crate::lower::node_::finish::hosted_rows_o(wx_p0), &crate::prelude::Text::lit("")), early_p: false, gappy_p: is_gappy_f(&gaps_pj), rebased_p: false });
        this.gen_holds_p = crate::prelude::push(&this.gen_holds_p, &(name_pq.clone(), reads_pp.clone()));
        this.rows_p = crate::prelude::fold(&cases_pe, &this.rows_p, &(|acc_p1a: &crate::prelude::Array<crate::lower::model::NodeDef>, gc_p1b: &GenCase| crate::prelude::append(&crate::prelude::push(acc_p1a, &gc_p1b.node_p), &gc_p1b.node_p.children_p)));
        this
    };
    (wx3_pm.clone(), crate::lower::node_::Wres::WrParts(kept_pg.results_p.clone()))
}

/// ```prism
/// StaticClauseLine: unbounded fn Wx, Env, Expr, Block, Text, ValInfo, Expr -> ((Wx, Wres))
/// ```
pub fn static_clause_line_f(wx_p0: &crate::lower::node_::Wx, menv_p1: &crate::lower::types::Env, scrut_p2: &crate::syntax::Expr, call_p3: &crate::syntax::Block, qk_p4: &crate::prelude::Text, v_p5: &crate::check::env::ValInfo, e_p6: &crate::syntax::Expr) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    let lx_p7 = wx_p0.lx_p.clone();
    let call_args_p8 = match clause_call_o(&lx_p7, call_p3) {
        ::std::option::Option::Some((_, xs_pi)) => xs_pi,
        ::std::option::Option::None => crate::prelude::Array::new(),
    };
    let pos_p9 = wx_p0.pos_p.clone();
    let (src_ex_pj, reads_pk) = crate::lower::node_::dynamics::dynamic_expr_f(wx_p0, menv_p1, scrut_p2);
    let vt_pa = crate::lower::types::out_ty_of_f(&lx_p7, &crate::lower::types::peel_f(&crate::lower::type_at_f(&lx_p7, &scrut_p2.span_p)));
    let (name_pl, wx1_pm) = crate::lower::node_::fresh_name_f(wx_p0, &crate::prelude::Text::lit("generation"));
    let (up_id_pn, wx2_po) = crate::lower::node_::add_gn_f(&wx1_pm, &crate::prelude::Text::from(format!("{}_fired", &name_pl)), &crate::lower::types::out_ty_of_f(&lx_p7, &crate::lower::types::out_of_f(&crate::lower::type_at_f(&lx_p7, &e_p6.span_p))), &crate::lower::node_::GnKind::GnNamed, &crate::prelude::Nat::from(0u32));
    let clauses_pb = crate::lower::jobs::clauses_of_f(&lx_p7.g_p, qk_p4);
    let row_name_pc = crate::prelude::Text::from(format!("{}Gen{}", &wx_p0.node_p, &crate::lower::node_::keyed::row_suffix_f(wx_p0)));
    let (rows_pu, wx3_pv) = crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(&clauses_pb)), (crate::prelude::Array::new(), wx2_po.clone()), {
        let clauses_pbx = clauses_pb.clone();
        let menv_p1x = menv_p1.clone();
        let v_p5x = v_p5.clone();
        let row_name_pcx = row_name_pc.clone();
        let name_plx = name_pl.clone();
        let wx_p0x = wx_p0.clone();
        let call_args_p8x = call_args_p8.clone();
        ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Array<ClauseRow>, crate::lower::node_::Wx), crate::prelude::Nat)| {
            let clauses_pbxy = clauses_pbx.clone();
            let menv_p1xy = menv_p1x.clone();
            let v_p5xy = v_p5x.clone();
            let row_name_pcxy = row_name_pcx.clone();
            let name_plxy = name_plx.clone();
            let wx_p0xy = wx_p0x.clone();
            let call_args_p8xy = call_args_p8x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (acc_pp, w_pq) = p0;
                let i_pr = p1;
                {
                    let c_ps = crate::prelude::or(&crate::prelude::index(&clauses_pbxy, &i_pr), &crate::lower::functions::dummy_clause_p());
                    crate::prelude::call_then(start_clause_row_of_f(w_pq.clone(), menv_p1xy.clone(), c_ps.clone(), v_p5xy.clone(), crate::prelude::Text::from(format!("{}{}", &row_name_pcxy, &i_pr)), name_plxy.clone(), true, crate::lower::model::OutTy::OutWeak(wx_p0xy.node_p.clone()), call_args_p8xy.clone(), false), move |clause_row_of_f_26158: ClauseRow| {
                        let cr_pt = clause_row_of_f_26158;
                        ::prism_rtl::Turn::Finished((crate::prelude::push(&acc_pp, &cr_pt), cr_pt.parent_p.clone()))
                    })
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Array<ClauseRow>, crate::lower::node_::Wx), crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<ClauseRow>, crate::lower::node_::Wx)>>>
    }));
    let width_pd = crate::prelude::fold(&rows_pu, &crate::prelude::Nat::from(0u32), &(|acc_p10: &crate::prelude::Nat, cr_p11: &ClauseRow| crate::prelude::max(acc_p10, &cr_p11.width_p)));
    let cases_pe = crate::prelude::each(&rows_pu, &(|cr_p12: &ClauseRow| cr_p12.case_p.clone()));
    let gaps_pf = row_gaps_f(&rows_pu, &width_pd);
    let select_pg = with_row_base_f(wx_p0, &crate::prelude::Text::lit("self"), &pos_p9, &gen_select_f(&wx3_pv, menv_p1, call_p3, &cases_pe, &pos_p9, &crate::prelude::each(&gaps_pf, &(|g_o13: &::std::option::Option<crate::lower::model::Ex>| gap_set_f(&name_pl, g_o13))), &false));
    let wx4_ph = {
        let mut this: crate::lower::node_::Wx = wx3_pv.clone();
        this.pos_p = crate::lower::model::Pos { scope_p: pos_p9.scope_p.clone(), at_p: &pos_p9.at_p + &width_pd };
        this.gens_p = crate::prelude::push(&this.gens_p, &crate::lower::model::GenDef { name_p: name_pl.clone(), pos_p: pos_p9.clone(), at_p: crate::lower::node_::finish::place_at_f(wx_p0, &crate::prelude::Text::lit("self"), &pos_p9), source_p: src_ex_pj.clone(), value_ty_p: vt_pa.clone(), select_p: select_pg.clone(), transparent_p: true, width_p: width_pd.clone(), moved_p: crate::prelude::or(&crate::lower::node_::finish::hosted_rows_o(wx_p0), &crate::prelude::Text::lit("")), early_p: false, gappy_p: is_gappy_f(&gaps_pf), rebased_p: false });
        this.gen_holds_p = crate::prelude::push(&this.gen_holds_p, &(name_pl.clone(), reads_pk.clone()));
        this.rows_p = crate::prelude::fold(&cases_pe, &this.rows_p, &(|acc_p14: &crate::prelude::Array<crate::lower::model::NodeDef>, gc_p15: &GenCase| crate::prelude::append(&crate::prelude::push(acc_p14, &gc_p15.node_p), &gc_p15.node_p.children_p)));
        this.getters_p = crate::prelude::push(&crate::prelude::push(&this.getters_p, &gen_up_f(&name_pl, &crate::lower::node_::gn_of_f(&wx3_pv, &up_id_pn).name_p, &crate::lower::node_::gn_of_f(&wx3_pv, &up_id_pn).ty_p)), &gen_up_above_f(&name_pl, &crate::lower::node_::gn_of_f(&wx3_pv, &up_id_pn).name_p));
        this
    };
    if &crate::lower::types::out_ty_of_f(&lx_p7, &crate::lower::types::out_of_f(&crate::lower::type_at_f(&lx_p7, &e_p6.span_p))) == &crate::lower::model::OutTy::OutUnit {
        (wx4_ph.clone(), crate::lower::node_::Wres::WrUnit)
    } else {
        (wx4_ph.clone(), crate::lower::node_::Wres::WrEv(crate::lower::node_::ev_ref_of_f(&wx4_ph, &up_id_pn)))
    }
}

/// ```prism
/// EarlyClauseLine: unbounded fn Wx, Env, Env, Expr, Text, ValInfo, Expr, [Arg], OutTy -> ((Wx, Wres))
/// ```
pub fn early_clause_line_f(wx_p0: &crate::lower::node_::Wx, benv_p1: &crate::lower::types::Env, menv_p2: &crate::lower::types::Env, scrut_p3: &crate::syntax::Expr, qk_p4: &crate::prelude::Text, v_p5: &crate::check::env::ValInfo, e_p6: &crate::syntax::Expr, args_p7: &crate::prelude::Array<crate::syntax::Arg>, out_ty_p8: &crate::lower::model::OutTy) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    let lx_p9 = wx_p0.lx_p.clone();
    let pos_pa = wx_p0.pos_p.clone();
    let (name_p11, wx1_p12) = crate::lower::node_::fresh_name_f(wx_p0, &crate::prelude::Text::lit("generation"));
    let link_pb = crate::prelude::Text::from(format!("{}_link", &name_p11));
    let first_pc = crate::prelude::Text::from(format!("{}_first", &name_p11));
    let row_local_pd = crate::prelude::Text::from(format!("{}_row", &name_p11));
    let link_ty_pe = crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("prism_rtl::Link")), crate::prelude::Array::from(vec![crate::lower::model::OutTy::OutNamed(crate::lower::site_ref_f(&lx_p9, &wx_p0.node_p), crate::prelude::Array::new())]));
    let clauses_pf = crate::lower::jobs::clauses_of_f(&lx_p9.g_p, qk_p4);
    let row_name_pg = crate::prelude::Text::from(format!("{}Gen{}", &wx_p0.node_p, &crate::lower::node_::keyed::row_suffix_f(wx_p0)));
    let (rows_p18, wx2_p19) = crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(&clauses_pf)), (crate::prelude::Array::new(), wx1_p12.clone()), {
        let clauses_pfx = clauses_pf.clone();
        let menv_p2x = menv_p2.clone();
        let v_p5x = v_p5.clone();
        let row_name_pgx = row_name_pg.clone();
        let name_p11x = name_p11.clone();
        let link_ty_pex = link_ty_pe.clone();
        let args_p7x = args_p7.clone();
        ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Array<ClauseRow>, crate::lower::node_::Wx), crate::prelude::Nat)| {
            let clauses_pfxy = clauses_pfx.clone();
            let menv_p2xy = menv_p2x.clone();
            let v_p5xy = v_p5x.clone();
            let row_name_pgxy = row_name_pgx.clone();
            let name_p11xy = name_p11x.clone();
            let link_ty_pexy = link_ty_pex.clone();
            let args_p7xy = args_p7x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (acc_p13, w_p14) = p0;
                let i_p15 = p1;
                {
                    let c_p16 = crate::prelude::or(&crate::prelude::index(&clauses_pfxy, &i_p15), &crate::lower::functions::dummy_clause_p());
                    crate::prelude::call_then(start_clause_row_of_f(w_p14.clone(), menv_p2xy.clone(), c_p16.clone(), v_p5xy.clone(), crate::prelude::Text::from(format!("{}{}", &row_name_pgxy, &i_p15)), name_p11xy.clone(), true, link_ty_pexy.clone(), args_p7xy.clone(), false), move |clause_row_of_f_28759: ClauseRow| {
                        let cr_p17 = clause_row_of_f_28759;
                        ::prism_rtl::Turn::Finished((crate::prelude::push(&acc_p13, &cr_p17), cr_p17.parent_p.clone()))
                    })
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Array<ClauseRow>, crate::lower::node_::Wx), crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<ClauseRow>, crate::lower::node_::Wx)>>>
    }));
    let width_ph = crate::prelude::fold(&rows_p18, &crate::prelude::Nat::from(0u32), &(|acc_p1a: &crate::prelude::Nat, cr_p1b: &ClauseRow| crate::prelude::max(acc_p1a, &cr_p1b.width_p)));
    let cases_pi = crate::prelude::each(&rows_p18, &(|cr_p1c: &ClauseRow| cr_p1c.case_p.clone()));
    let row_obj_pj = crate::lower::model::OutTy::OutObj(::std::rc::Rc::new(crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Row")), crate::prelude::Array::new())));
    let host_at_build_pk = match crate::lower::node_::finish::hosted_rows_o(wx_p0) {
        ::std::option::Option::Some(_) => crate::prelude::Array::from(vec![crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::lower::node_::elements::host_local_f(wx_p0, &pos_pa))))]),
        ::std::option::Option::None => crate::prelude::Array::new(),
    };
    let made_fl = {
        let lx_p9x = lx_p9.clone();
        ::std::rc::Rc::new(move |c_p1d: &GenCase, parent_p1e: &crate::lower::model::Ex, host_p1f: &crate::prelude::Array<crate::lower::model::Ex>| crate::lower::expr::try_of_f(&crate::lower::model::Ex::XCall(crate::lower::model::ref_child_f(&crate::lower::site_ref_f(&lx_p9x, &c_p1d.node_p.name_p), &crate::prelude::Text::lit("build")), crate::prelude::append(&crate::prelude::append(&crate::prelude::Array::from(vec![crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("path"))))]), &c_p1d.passed_p), &crate::prelude::append(&crate::prelude::append(&crate::prelude::Array::from(vec![parent_p1e.clone()]), host_p1f), &crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx])))))) as ::std::rc::Rc<dyn ::std::ops::Fn(&GenCase, &crate::lower::model::Ex, &crate::prelude::Array<crate::lower::model::Ex>) -> crate::lower::model::Ex>
    };
    let gaps_pm = row_gaps_f(&rows_p18, &width_ph);
    let gap_now_pn = crate::prelude::Text::from(format!("{}_gap_now", &name_p11));
    let late_po = crate::lower::node_::finish::numbered_late_f(wx_p0, &pos_pa);
    let number_pp = crate::prelude::Text::from(format!("{}_number", &name_p11));
    let early_arms_pq = crate::prelude::fold(&cases_pi, &crate::prelude::Array::new(), &(|built_p1g: &crate::prelude::Array<crate::lower::model::XArm>, c_p1h: &GenCase| {
        let i_p1i = crate::prelude::len(built_p1g);
        crate::prelude::push(built_p1g, &crate::lower::model::XArm { pat_p: c_p1h.pat_p.clone(), conds_p: c_p1h.conds_p.clone(), body_p: crate::lower::model::Ex::XBlock(crate::prelude::Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("row")), (&made_fl)(c_p1h, &crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(link_pb.clone()))), &host_at_build_pk))]), ::std::rc::Rc::new(crate::lower::model::Ex::XTuple(crate::prelude::append(&crate::prelude::Array::from(vec![crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("row"))), crate::prelude::Text::lit("result_value"), crate::prelude::Array::new()), crate::lower::model::Ex::XCast(::std::rc::Rc::new(crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("row"))))), row_obj_pj.clone()), crate::prelude::or(&crate::prelude::or(&crate::prelude::index(&gaps_pm, &i_p1i), &::std::option::Option::None), &crate::lower::model::Ex::XIndex(crate::prelude::Nat::from(0u32)))]), &(if late_po {
            crate::prelude::Array::from(vec![number_of_f(wx_p0, &pos_pa, &name_p11, &link_pb, &crate::prelude::or(&crate::prelude::index(&gaps_pm, &i_p1i), &::std::option::Option::None))])
        } else {
            crate::prelude::Array::new()
        }))))) })
    }));
    let method_arms_pr = crate::prelude::each(&cases_pi, &(|c_p1j: &GenCase| crate::lower::model::XArm { pat_p: c_p1j.pat_p.clone(), conds_p: c_p1j.conds_p.clone(), body_p: if late_po {
        crate::lower::model::Ex::XBlock(crate::prelude::Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("row")), (&made_fl)(c_p1j, &crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), link_pb.clone()))), &crate::lower::node_::keyed::hosted_passed_f(wx_p0))), crate::lower::model::Do::DoExpr(crate::lower::expr::try_of_f(&crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("row"))), crate::prelude::Text::lit("number_places"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XVar(crate::prelude::Text::lit("row_base")), crate::lower::model::Ex::XCx]))))]), ::std::rc::Rc::new(crate::lower::model::Ex::XCast(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("row"))), row_obj_pj.clone())))
    } else {
        crate::lower::model::Ex::XCast(::std::rc::Rc::new((&made_fl)(c_p1j, &crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), link_pb.clone()))), &crate::lower::node_::keyed::hosted_passed_f(wx_p0))), row_obj_pj.clone())
    } }));
    let at_build_ps = clause_scrutinee_f(&lx_p9, benv_p1, v_p5, args_p7);
    let in_method_pt = clause_scrutinee_f(&lx_p9, menv_p2, v_p5, args_p7);
    let built_pu = if late_po {
        crate::lower::types::own_f(&crate::lower::expr::arms_value_f(&at_build_ps, &early_arms_pq, &crate::prelude::Text::lit("\'select"), &crate::lower::model::OutTy::OutTuple(crate::prelude::Array::from(vec![out_ty_p8.clone(), row_obj_pj.clone(), crate::lower::model::OutTy::OutCount, crate::lower::node_::finish::later_ty_p()]))))
    } else {
        with_row_base_f(wx_p0, &crate::prelude::Text::lit(""), &pos_pa, &crate::lower::types::own_f(&crate::lower::expr::arms_value_f(&at_build_ps, &early_arms_pq, &crate::prelude::Text::lit("\'select"), &crate::lower::model::OutTy::OutTuple(crate::prelude::Array::from(vec![out_ty_p8.clone(), row_obj_pj.clone(), crate::lower::model::OutTy::OutCount])))))
    };
    let select_pv = with_row_base_f(wx_p0, &crate::prelude::Text::lit("self"), &pos_pa, &crate::lower::types::own_f(&crate::lower::expr::arms_value_f(&in_method_pt, &method_arms_pr, &crate::prelude::Text::lit("\'select"), &row_obj_pj)));
    let wx3_p10 = {
        let mut this: crate::lower::node_::Wx = wx2_p19.clone();
        this.taken_p = crate::prelude::append(&this.taken_p, &crate::prelude::Array::from(vec![link_pb.clone(), first_pc.clone(), row_local_pd.clone(), gap_now_pn.clone(), number_pp.clone()]));
        this.late_numbered_p = if late_po {
            crate::prelude::push(&this.late_numbered_p, &name_p11)
        } else {
            this.late_numbered_p.clone()
        };
        this.lets_p = crate::prelude::append(&this.lets_p, &crate::prelude::Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaBind(link_pb.clone())), link_ty_pe.clone()), crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::from(format!("prism_rtl::Link::<{}>::new", &wx_p0.node_p))), crate::prelude::Array::new())), crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTuple(crate::prelude::append(&crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(first_pc.clone()), crate::lower::model::Pa::PaBind(row_local_pd.clone()), crate::lower::model::Pa::PaBind(gap_now_pn.clone())]), &(if late_po {
            crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(number_pp.clone())])
        } else {
            crate::prelude::Array::new()
        }))), built_pu.clone())]));
        this.fields_p = crate::prelude::push(&this.fields_p, &(link_pb.clone(), link_ty_pe.clone(), crate::prelude::Text::from(format!("the link the generation at place {} holds this node through, built before it", &crate::lower::model::place_text_f(&pos_pa)))));
        this.inits_p = crate::prelude::push(&this.inits_p, &(link_pb.clone(), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(link_pb.clone())))));
        this.build_p = crate::prelude::push(&this.build_p, &crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XVar(link_pb.clone())), crate::prelude::Text::lit("link"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("node"))))]))));
        this.fallible_p = true;
        this.pos_p = crate::lower::model::Pos { scope_p: pos_pa.scope_p.clone(), at_p: &pos_pa.at_p + &width_ph };
        this.gens_p = crate::prelude::push(&this.gens_p, &crate::lower::model::GenDef { name_p: name_p11.clone(), pos_p: pos_pa.clone(), at_p: crate::lower::node_::finish::place_at_f(wx_p0, &crate::prelude::Text::lit("self"), &pos_pa), source_p: crate::lower::model::Ex::XUnit, value_ty_p: crate::lower::model::OutTy::OutUnit, select_p: select_pv.clone(), transparent_p: true, width_p: width_ph.clone(), moved_p: crate::prelude::or(&crate::lower::node_::finish::hosted_rows_o(wx_p0), &crate::prelude::Text::lit("")), early_p: true, gappy_p: is_gappy_f(&gaps_pm), rebased_p: false });
        this.gen_holds_p = crate::prelude::push(&this.gen_holds_p, &(name_p11.clone(), crate::prelude::Array::new()));
        this.rows_p = crate::prelude::fold(&cases_pi, &this.rows_p, &(|acc_p1k: &crate::prelude::Array<crate::lower::model::NodeDef>, gc_p1l: &GenCase| crate::prelude::append(&crate::prelude::push(acc_p1k, &gc_p1l.node_p), &gc_p1l.node_p.children_p)));
        this
    };
    (wx3_p10.clone(), crate::lower::node_::Wres::WrPlain(crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(first_pc.clone()))), out_ty_p8.clone()))
}

/// ```prism
/// EarlyChoiceLine: unbounded fn Wx, Env, Env, Expr, [Arm], Expr -> ((Wx, Wres))
/// ```
pub fn early_choice_line_f(wx_p0: &crate::lower::node_::Wx, benv_p1: &crate::lower::types::Env, menv_p2: &crate::lower::types::Env, s_p3: &crate::syntax::Expr, arms_p4: &crate::prelude::Array<crate::syntax::Arm>, e_p5: &crate::syntax::Expr) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    let lx_p6 = wx_p0.lx_p.clone();
    let pos_p7 = wx_p0.pos_p.clone();
    let out_ty_p8 = choice_out_ty_f(&lx_p6, e_p5);
    let sty_p9 = crate::lower::type_at_f(&lx_p6, &s_p3.span_p);
    let (name_pv, wx1_p10) = crate::lower::node_::fresh_name_f(wx_p0, &crate::prelude::Text::lit("arm"));
    let link_pa = crate::prelude::Text::from(format!("{}_link", &name_pv));
    let first_pb = crate::prelude::Text::from(format!("{}_first", &name_pv));
    let row_local_pc = crate::prelude::Text::from(format!("{}_row", &name_pv));
    let link_ty_pd = crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("prism_rtl::Link")), crate::prelude::Array::from(vec![crate::lower::model::OutTy::OutNamed(crate::lower::site_ref_f(&lx_p6, &wx_p0.node_p), crate::prelude::Array::new())]));
    let row_name_pe = crate::prelude::Text::from(format!("{}Arm{}", &wx_p0.node_p, &crate::lower::node_::keyed::row_suffix_f(wx_p0)));
    let (rows_p16, wx2_p17) = crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(arms_p4)), (crate::prelude::Array::new(), wx1_p10.clone()), {
        let arms_p4x = arms_p4.clone();
        let menv_p2x = menv_p2.clone();
        let lx_p6x = lx_p6.clone();
        let sty_p9x = sty_p9.clone();
        let row_name_pex = row_name_pe.clone();
        let name_pvx = name_pv.clone();
        let link_ty_pdx = link_ty_pd.clone();
        ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Array<ClauseRow>, crate::lower::node_::Wx), crate::prelude::Nat)| {
            let arms_p4xy = arms_p4x.clone();
            let menv_p2xy = menv_p2x.clone();
            let lx_p6xy = lx_p6x.clone();
            let sty_p9xy = sty_p9x.clone();
            let row_name_pexy = row_name_pex.clone();
            let name_pvxy = name_pvx.clone();
            let link_ty_pdxy = link_ty_pdx.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (acc_p11, w_p12) = p0;
                let i_p13 = p1;
                {
                    let a_p14 = crate::prelude::or(&crate::prelude::index(&arms_p4xy, &i_p13), &dummy_arm_s_p());
                    crate::prelude::call_then(start_arm_row_of_f(w_p12.clone(), menv_p2xy.clone(), lx_p6xy.clone(), crate::prelude::Array::from(vec![a_p14.pattern_o.clone()]), crate::prelude::Array::from(vec![sty_p9xy.clone()]), ::std::option::Option::None, a_p14.body_p.clone(), crate::prelude::Text::from(format!("{}{}", &row_name_pexy, &i_p13)), name_pvxy.clone(), true, false, link_ty_pdxy.clone(), crate::prelude::Array::new(), crate::prelude::Array::new(), crate::prelude::Array::new(), false), move |arm_row_of_f_33903: ClauseRow| {
                        let cr_p15 = arm_row_of_f_33903;
                        ::prism_rtl::Turn::Finished((crate::prelude::push(&acc_p11, &cr_p15), cr_p15.parent_p.clone()))
                    })
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Array<ClauseRow>, crate::lower::node_::Wx), crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<ClauseRow>, crate::lower::node_::Wx)>>>
    }));
    let width_pf = crate::prelude::fold(&rows_p16, &crate::prelude::Nat::from(0u32), &(|acc_p18: &crate::prelude::Nat, cr_p19: &ClauseRow| crate::prelude::max(acc_p18, &cr_p19.width_p)));
    let cases_pg = crate::prelude::each(&rows_p16, &(|cr_p1a: &ClauseRow| cr_p1a.case_p.clone()));
    let row_obj_ph = crate::lower::model::OutTy::OutObj(::std::rc::Rc::new(crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Row")), crate::prelude::Array::new())));
    let host_at_build_pi = match crate::lower::node_::finish::hosted_rows_o(wx_p0) {
        ::std::option::Option::Some(_) => crate::prelude::Array::from(vec![crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::lower::node_::elements::host_local_f(wx_p0, &pos_p7))))]),
        ::std::option::Option::None => crate::prelude::Array::new(),
    };
    let made_fj = {
        let lx_p6x = lx_p6.clone();
        ::std::rc::Rc::new(move |c_p1b: &GenCase, parent_p1c: &crate::lower::model::Ex, host_p1d: &crate::prelude::Array<crate::lower::model::Ex>| crate::lower::expr::try_of_f(&crate::lower::model::Ex::XCall(crate::lower::model::ref_child_f(&crate::lower::site_ref_f(&lx_p6x, &c_p1b.node_p.name_p), &crate::prelude::Text::lit("build")), crate::prelude::append(&crate::prelude::append(&crate::prelude::Array::from(vec![crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("path"))))]), &c_p1b.passed_p), &crate::prelude::append(&crate::prelude::append(&crate::prelude::Array::from(vec![parent_p1c.clone()]), host_p1d), &crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx])))))) as ::std::rc::Rc<dyn ::std::ops::Fn(&GenCase, &crate::lower::model::Ex, &crate::prelude::Array<crate::lower::model::Ex>) -> crate::lower::model::Ex>
    };
    let gaps_pk = row_gaps_f(&rows_p16, &width_pf);
    let gap_now_pl = crate::prelude::Text::from(format!("{}_gap_now", &name_pv));
    let late_pm = crate::lower::node_::finish::numbered_late_f(wx_p0, &pos_p7);
    let number_pn = crate::prelude::Text::from(format!("{}_number", &name_pv));
    let early_arms_po = crate::prelude::fold(&cases_pg, &crate::prelude::Array::new(), &(|built_p1e: &crate::prelude::Array<crate::lower::model::XArm>, c_p1f: &GenCase| {
        let i_p1g = crate::prelude::len(built_p1e);
        crate::prelude::push(built_p1e, &crate::lower::model::XArm { pat_p: c_p1f.pat_p.clone(), conds_p: c_p1f.conds_p.clone(), body_p: crate::lower::model::Ex::XBlock(crate::prelude::Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("row")), (&made_fj)(c_p1f, &crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(link_pa.clone()))), &host_at_build_pi))]), ::std::rc::Rc::new(crate::lower::model::Ex::XTuple(crate::prelude::append(&crate::prelude::Array::from(vec![crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("row"))), crate::prelude::Text::lit("result_value"), crate::prelude::Array::new()), crate::lower::model::Ex::XCast(::std::rc::Rc::new(crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("row"))))), row_obj_ph.clone()), crate::prelude::or(&crate::prelude::or(&crate::prelude::index(&gaps_pk, &i_p1g), &::std::option::Option::None), &crate::lower::model::Ex::XIndex(crate::prelude::Nat::from(0u32)))]), &(if late_pm {
            crate::prelude::Array::from(vec![number_of_f(wx_p0, &pos_p7, &name_pv, &link_pa, &crate::prelude::or(&crate::prelude::index(&gaps_pk, &i_p1g), &::std::option::Option::None))])
        } else {
            crate::prelude::Array::new()
        }))))) })
    }));
    let method_arms_pp = crate::prelude::each(&cases_pg, &(|c_p1h: &GenCase| crate::lower::model::XArm { pat_p: c_p1h.pat_p.clone(), conds_p: c_p1h.conds_p.clone(), body_p: if late_pm {
        crate::lower::model::Ex::XBlock(crate::prelude::Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("row")), (&made_fj)(c_p1h, &crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), link_pa.clone()))), &crate::lower::node_::keyed::hosted_passed_f(wx_p0))), crate::lower::model::Do::DoExpr(crate::lower::expr::try_of_f(&crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("row"))), crate::prelude::Text::lit("number_places"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XVar(crate::prelude::Text::lit("row_base")), crate::lower::model::Ex::XCx]))))]), ::std::rc::Rc::new(crate::lower::model::Ex::XCast(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("row"))), row_obj_ph.clone())))
    } else {
        crate::lower::model::Ex::XCast(::std::rc::Rc::new((&made_fj)(c_p1h, &crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), link_pa.clone()))), &crate::lower::node_::keyed::hosted_passed_f(wx_p0))), row_obj_ph.clone())
    } }));
    let at_build_pq = crate::lower::model::Ex::XTuple(crate::prelude::Array::from(vec![crate::lower::expr::argument_f(&lx_p6, benv_p1, s_p3)]));
    let in_method_pr = crate::lower::model::Ex::XTuple(crate::prelude::Array::from(vec![crate::lower::expr::argument_f(&lx_p6, menv_p2, s_p3)]));
    let built_ps = if late_pm {
        crate::lower::types::own_f(&crate::lower::expr::arms_value_f(&at_build_pq, &early_arms_po, &crate::prelude::Text::lit("\'select"), &crate::lower::model::OutTy::OutTuple(crate::prelude::Array::from(vec![out_ty_p8.clone(), row_obj_ph.clone(), crate::lower::model::OutTy::OutCount, crate::lower::node_::finish::later_ty_p()]))))
    } else {
        with_row_base_f(wx_p0, &crate::prelude::Text::lit(""), &pos_p7, &crate::lower::types::own_f(&crate::lower::expr::arms_value_f(&at_build_pq, &early_arms_po, &crate::prelude::Text::lit("\'select"), &crate::lower::model::OutTy::OutTuple(crate::prelude::Array::from(vec![out_ty_p8.clone(), row_obj_ph.clone(), crate::lower::model::OutTy::OutCount])))))
    };
    let select_pt = with_row_base_f(wx_p0, &crate::prelude::Text::lit("self"), &pos_p7, &crate::lower::types::own_f(&crate::lower::expr::arms_value_f(&in_method_pr, &method_arms_pp, &crate::prelude::Text::lit("\'select"), &row_obj_ph)));
    let wx3_pu = {
        let mut this: crate::lower::node_::Wx = wx2_p17.clone();
        this.taken_p = crate::prelude::append(&this.taken_p, &crate::prelude::Array::from(vec![link_pa.clone(), first_pb.clone(), row_local_pc.clone(), gap_now_pl.clone(), number_pn.clone()]));
        this.late_numbered_p = if late_pm {
            crate::prelude::push(&this.late_numbered_p, &name_pv)
        } else {
            this.late_numbered_p.clone()
        };
        this.lets_p = crate::prelude::append(&this.lets_p, &crate::prelude::Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaBind(link_pa.clone())), link_ty_pd.clone()), crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::from(format!("prism_rtl::Link::<{}>::new", &wx_p0.node_p))), crate::prelude::Array::new())), crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTuple(crate::prelude::append(&crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(first_pb.clone()), crate::lower::model::Pa::PaBind(row_local_pc.clone()), crate::lower::model::Pa::PaBind(gap_now_pl.clone())]), &(if late_pm {
            crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(number_pn.clone())])
        } else {
            crate::prelude::Array::new()
        }))), built_ps.clone())]));
        this.fields_p = crate::prelude::push(&this.fields_p, &(link_pa.clone(), link_ty_pd.clone(), crate::prelude::Text::from(format!("the link the arm at place {} holds this node through, built before it", &crate::lower::model::place_text_f(&pos_p7)))));
        this.inits_p = crate::prelude::push(&this.inits_p, &(link_pa.clone(), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(link_pa.clone())))));
        this.build_p = crate::prelude::push(&this.build_p, &crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XVar(link_pa.clone())), crate::prelude::Text::lit("link"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("node"))))]))));
        this.fallible_p = true;
        this.pos_p = crate::lower::model::Pos { scope_p: pos_p7.scope_p.clone(), at_p: &pos_p7.at_p + &width_pf };
        this.gens_p = crate::prelude::push(&this.gens_p, &crate::lower::model::GenDef { name_p: name_pv.clone(), pos_p: pos_p7.clone(), at_p: crate::lower::node_::finish::place_at_f(wx_p0, &crate::prelude::Text::lit("self"), &pos_p7), source_p: crate::lower::model::Ex::XUnit, value_ty_p: crate::lower::model::OutTy::OutUnit, select_p: select_pt.clone(), transparent_p: true, width_p: width_pf.clone(), moved_p: crate::prelude::or(&crate::lower::node_::finish::hosted_rows_o(wx_p0), &crate::prelude::Text::lit("")), early_p: true, gappy_p: is_gappy_f(&gaps_pk), rebased_p: false });
        this.gen_holds_p = crate::prelude::push(&this.gen_holds_p, &(name_pv.clone(), crate::prelude::Array::new()));
        this.rows_p = crate::prelude::fold(&cases_pg, &this.rows_p, &(|acc_p1i: &crate::prelude::Array<crate::lower::model::NodeDef>, gc_p1j: &GenCase| crate::prelude::append(&crate::prelude::push(acc_p1i, &gc_p1j.node_p), &gc_p1j.node_p.children_p)));
        this
    };
    (wx3_pu.clone(), crate::lower::node_::Wres::WrPlain(crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(first_pb.clone()))), out_ty_p8.clone()))
}

/// ```prism
/// let dummyArmS
/// ```
pub fn dummy_arm_s_p() -> crate::syntax::Arm {
    crate::syntax::Arm { pattern_o: ::std::option::Option::None, guard_o: ::std::option::Option::None, body_p: dummy_block_s_p(), span_p: crate::syntax::Range { start_p: crate::prelude::Nat::from(0u32), end_p: crate::prelude::Nat::from(0u32) } }
}

/// ```prism
/// IsHostedScope: fn Wx -> Bool
/// ```
pub fn is_hosted_scope_f(wx_p0: &crate::lower::node_::Wx) -> bool {
    (&wx_p0.pos_p.scope_p > &crate::prelude::Nat::from(0u32)) || is_some_f(&wx_p0.hosted_by_o)
}

/// ```prism
/// IsSome: fn ?a -> Bool
/// ```
pub fn is_some_f<A: ::std::clone::Clone + 'static>(opt0: &::std::option::Option<A>) -> bool {
    match opt0 {
        ::std::option::Option::Some(_) => true,
        ::std::option::Option::None => false,
    }
}

/// ```prism
/// GenCases: unbounded fn Wx, Env, Block, OutTy, Text -> (([GenCase], Wx))
/// ```
pub fn gen_cases_f(wx_p0: &crate::lower::node_::Wx, menv_p1: &crate::lower::types::Env, body_p2: &crate::syntax::Block, vt_p3: &crate::lower::model::OutTy, name_p4: &crate::prelude::Text) -> (crate::prelude::Array<GenCase>, crate::lower::node_::Wx) {
    let lx_p5 = wx_p0.lx_p.clone();
    let row_name_p6 = crate::prelude::Text::from(format!("{}Gen{}", &wx_p0.node_p, &crate::lower::node_::keyed::row_suffix_f(wx_p0)));
    match clause_call_o(&lx_p5, body_p2) {
        ::std::option::Option::Some((qk_p7, args_p8)) => {
            let clauses_p9 = crate::lower::jobs::clauses_of_f(&lx_p5.g_p, &qk_p7);
            let v_pa = crate::lower::program::val_of_f(&lx_p5, &qk_p7);
            crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(&clauses_p9)), (crate::prelude::Array::new(), wx_p0.clone()), {
                let clauses_p9x = clauses_p9.clone();
                let menv_p1x = menv_p1.clone();
                let v_pax = v_pa.clone();
                let row_name_p6x = row_name_p6.clone();
                let name_p4x = name_p4.clone();
                let wx_p0x = wx_p0.clone();
                let args_p8x = args_p8.clone();
                ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Array<GenCase>, crate::lower::node_::Wx), crate::prelude::Nat)| {
                    let clauses_p9xy = clauses_p9x.clone();
                    let menv_p1xy = menv_p1x.clone();
                    let v_paxy = v_pax.clone();
                    let row_name_p6xy = row_name_p6x.clone();
                    let name_p4xy = name_p4x.clone();
                    let wx_p0xy = wx_p0x.clone();
                    let args_p8xy = args_p8x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let (acc_pb, w_pc) = p0;
                        let i_pd = p1;
                        {
                            let c_pe = crate::prelude::or(&crate::prelude::index(&clauses_p9xy, &i_pd), &crate::lower::functions::dummy_clause_p());
                            crate::prelude::call_then(start_clause_row_of_f(w_pc.clone(), menv_p1xy.clone(), c_pe.clone(), v_paxy.clone(), crate::prelude::Text::from(format!("{}{}", &row_name_p6xy, &i_pd)), name_p4xy.clone(), false, crate::lower::model::OutTy::OutWeak(wx_p0xy.node_p.clone()), args_p8xy.clone(), false), move |clause_row_of_f_38523: ClauseRow| {
                                let cr_pf = clause_row_of_f_38523;
                                let p2_pg = match &cr_pf.plain_o {
                                    ::std::option::Option::Some(_) => {
                                        let mut this: crate::lower::node_::Wx = cr_pf.parent_p.clone();
                                        this.build_p = crate::prelude::push(&this.build_p, &crate::lower::expr::internal_bug_do_f(&crate::prelude::Text::lit("a `rebuild` that hands back no dynamic whose generation is a widget of several clauses ending on a plain result")));
                                        this
                                    },
                                    ::std::option::Option::None => cr_pf.parent_p.clone(),
                                };
                                ::prism_rtl::Turn::Finished((crate::prelude::push(&acc_pb, &cr_pf.case_p), p2_pg.clone()))
                            })
                        }
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Array<GenCase>, crate::lower::node_::Wx), crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<GenCase>, crate::lower::node_::Wx)>>>
            }))
        },
        ::std::option::Option::None => {
            let whole_ph = gen_row_of_f(wx_p0, menv_p1, body_p2, vt_p3, &row_name_p6, name_p4);
            (crate::prelude::Array::from(vec![GenCase { node_p: whole_ph.node_p.clone(), params_p: crate::prelude::Array::from(vec![(crate::prelude::Text::lit("value"), vt_p3.clone())]), pat_p: crate::lower::model::Pa::PaWild, conds_p: crate::prelude::Array::new(), passed_p: crate::prelude::Array::from(vec![crate::lower::model::Ex::XVar(crate::prelude::Text::lit("value"))]) }]), whole_ph.parent_p.clone())
        },
    }
}

/// ```prism
/// ?ClauseCall: fn Lx, Block -> ?((Text, [Arg]))
/// ```
pub fn clause_call_o(lx_p0: &crate::lower::Lx, body_p1: &crate::syntax::Block) -> ::std::option::Option<(crate::prelude::Text, crate::prelude::Array<crate::syntax::Arg>)> {
    'm39437: {
        let scrutinee = &body_p1.stmts_p;
        if let m39437_0 = scrutinee && (m39437_0.len() == 1) && let ::std::option::Option::Some(st_p2) = crate::prelude::index(m39437_0, &crate::prelude::Nat::from(0u32)) {
            break 'm39437 match &st_p2.kind_p {
                crate::syntax::StmtKind::SExpr(x_p3) => clause_call_x_o(lx_p0, x_p3),
                crate::syntax::StmtKind::SIgnore(x_p4) => clause_call_x_o(lx_p0, x_p4),
                _ => ::std::option::Option::None,
            };
        }
        ::std::option::Option::None
    }
}

/// ```prism
/// ?ClauseCallX: fn Lx, Expr -> ?((Text, [Arg]))
/// ```
pub fn clause_call_x_o(lx_p0: &crate::lower::Lx, x_p1: &crate::syntax::Expr) -> ::std::option::Option<(crate::prelude::Text, crate::prelude::Array<crate::syntax::Arg>)> {
    match &*x_p1.kind_p {
        crate::syntax::ExprKind::ECall(c_p2, args_p3, _, _) => {
            let qk_p4 = crate::lower::program::blueprint_qk_f(lx_p0, &**c_p2);
            if &crate::prelude::len(&crate::lower::jobs::clauses_of_f(&lx_p0.g_p, &qk_p4)) > &crate::prelude::Nat::from(1u32) {
                ::std::option::Option::Some((qk_p4.clone(), args_p3.clone()))
            } else {
                ::std::option::Option::None
            }
        },
        _ => ::std::option::Option::None,
    }
}

/// ```prism
/// ClauseRowOf: unbounded fn Wx, Env, FnClause, ValInfo, Text, Text, Bool, OutTy, [Arg], Bool -> ClauseRow
/// ```
pub fn clause_row_of_f(wx_p0: &crate::lower::node_::Wx, menv_p1: &crate::lower::types::Env, c_p2: &crate::syntax::decls::FnClause, v_p3: &crate::check::env::ValInfo, row_name_p4: &crate::prelude::Text, gen_name_p5: &crate::prelude::Text, transparent_p6: &bool, parent_ty_p7: &crate::lower::model::OutTy, args_p8: &crate::prelude::Array<crate::syntax::Arg>, zero_based_p9: &bool) -> ClauseRow {
    let lx_pa = wx_p0.lx_p.clone();
    let lxc_pb = crate::lower::program::in_module_at_f(&lx_pa, &v_p3.file_p, &v_p3.home_p, &lx_pa.site_p);
    let ptys_pc = match &v_p3.scheme_p.ty_p {
        crate::check::types::Ty::TyFn(_, ps_ph, _) => ps_ph.clone(),
        _ => crate::prelude::Array::new(),
    };
    let valued_pd = *zero_based_p9 && (parent_ty_p7 == &crate::lower::model::OutTy::OutUnit);
    let widgets_pe = if valued_pd {
        crate::prelude::Array::new()
    } else {
        crate::prelude::fold(&crate::check::errors::range0_f(&crate::prelude::len(&c_p2.params_p)), &crate::prelude::Array::new(), &(|acc_pi: &crate::prelude::Array<(crate::prelude::Text, crate::syntax::Expr)>, i_pj: &crate::prelude::Nat| match (crate::prelude::index(&ptys_pc, i_pj), crate::prelude::index(&c_p2.params_p, i_pj), crate::prelude::index(args_p8, i_pj)) {
            (::std::option::Option::Some(pt_pk), ::std::option::Option::Some(p_pl), ::std::option::Option::Some(a_pm)) if is_blueprint_param_f(&pt_pk) => {
                let bn_pn = crate::lower::functions::plain_binder_f(&lxc_pb, &p_pl);
                if &bn_pn == &crate::prelude::Text::lit("") {
                    acc_pi.clone()
                } else {
                    crate::prelude::push(acc_pi, &(bn_pn.clone(), a_pm.value_p.clone()))
                }
            },
            _ => acc_pi.clone(),
            _ => unreachable!("no arm matched"),
        }))
    };
    let pats_pf = crate::prelude::each(&crate::check::errors::range0_f(&crate::prelude::len(&c_p2.params_p)), &(|i_po: &crate::prelude::Nat| match (crate::prelude::index(&ptys_pc, i_po), crate::prelude::index(&c_p2.params_p, i_po)) {
        (::std::option::Option::Some(pt_pp), ::std::option::Option::Some(p_pq)) if (is_blueprint_param_f(&pt_pp) && !valued_pd) => ::std::option::Option::None,
        (::std::option::Option::Some(pt_pr), ::std::option::Option::Some(p_ps)) if (valued_pd && is_live_param_f(&pt_pr)) => ::std::option::Option::None,
        (_, p_ot) => p_ot,
        _ => unreachable!("no arm matched"),
    }));
    let body_pg = match &c_p2.body_p {
        crate::syntax::decls::FnBody::BodyBlock(b_pu) => b_pu.clone(),
        crate::syntax::decls::FnBody::BodyExpr(x_pv) => crate::syntax::Block { stmts_p: crate::prelude::Array::from(vec![crate::syntax::Stmt { kind_p: crate::syntax::StmtKind::SExpr(x_pv.clone()), span_p: x_pv.span_p.clone() }]), inline_p: true, span_p: x_pv.span_p.clone() },
    };
    let (dyns_p19, wxd_p1a) = if valued_pd {
        (live_shapes_f(&lxc_pb, c_p2, &ptys_pc), wx_p0.clone())
    } else {
        crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(&c_p2.params_p)), (crate::prelude::Array::new(), wx_p0.clone()), {
            let ptys_pcx = ptys_pc.clone();
            let c_p2x = c_p2.clone();
            let args_p8x = args_p8.clone();
            let lxc_pbx = lxc_pb.clone();
            let menv_p1x = menv_p1.clone();
            ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Array<(crate::prelude::Text, crate::lower::types::Bn)>, crate::lower::node_::Wx), crate::prelude::Nat)| {
                let ptys_pcxy = ptys_pcx.clone();
                let c_p2xy = c_p2x.clone();
                let args_p8xy = args_p8x.clone();
                let lxc_pbxy = lxc_pbx.clone();
                let menv_p1xy = menv_p1x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let (acc_p10, w_p11) = p0;
                    let i_p12 = p1;
                    match (crate::prelude::index(&ptys_pcxy, &i_p12), crate::prelude::index(&c_p2xy.params_p, &i_p12), crate::prelude::index(&args_p8xy, &i_p12)) {
                        (::std::option::Option::Some(pt_p13), ::std::option::Option::Some(p_p14), ::std::option::Option::Some(a_p15)) if (&crate::lower::types::layer_of_f(&pt_p13) == &crate::lower::types::Layer::LyDyn) => {
                            let bn_p16 = crate::lower::functions::plain_binder_f(&lxc_pbxy, &p_p14);
                            if &bn_p16 == &crate::prelude::Text::lit("") {
                                ::prism_rtl::Turn::Finished((acc_p10.clone(), w_p11.clone()))
                            } else {
                                crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lxc_pbxy.clone(), crate::lower::types::peel_f(&pt_p13)), move |out_ty_of_f_43188: crate::lower::model::OutTy| crate::prelude::call_then(start_clause_dyn_arg_f(w_p11.clone(), menv_p1xy.clone(), a_p15.value_p.clone(), out_ty_of_f_43188), move |clause_dyn_arg_f_43156: (crate::lower::types::Bn, crate::lower::node_::Wx)| {
                                    let (b_p17, w2_p18) = clause_dyn_arg_f_43156;
                                    ::prism_rtl::Turn::Finished((crate::prelude::push(&acc_p10, &(bn_p16.clone(), b_p17.clone())), w2_p18.clone()))
                                }))
                            }
                        },
                        _ => ::prism_rtl::Turn::Finished((acc_p10.clone(), w_p11.clone())),
                        _ => unreachable!("no arm matched"),
                    }
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Array<(crate::prelude::Text, crate::lower::types::Bn)>, crate::lower::node_::Wx), crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<(crate::prelude::Text, crate::lower::types::Bn)>, crate::lower::node_::Wx)>>>
        }))
    };
    arm_row_of_f(&wxd_p1a, menv_p1, &lxc_pb, &pats_pf, &ptys_pc, &::std::option::Option::None, &body_pg, row_name_p4, gen_name_p5, transparent_p6, &false, parent_ty_p7, &dyns_p19, &crate::prelude::Array::new(), &widgets_pe, zero_based_p9)
}

/// The step machine of `ClauseRowOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ClauseRowOf: unbounded fn Wx, Env, FnClause, ValInfo, Text, Text, Bool, OutTy, [Arg], Bool -> ClauseRow
/// ```
pub struct ClauseRowOf {
    pub wx_p0: crate::lower::node_::Wx,
    pub menv_p1: crate::lower::types::Env,
    pub c_p2: crate::syntax::decls::FnClause,
    pub v_p3: crate::check::env::ValInfo,
    pub row_name_p4: crate::prelude::Text,
    pub gen_name_p5: crate::prelude::Text,
    pub transparent_p6: bool,
    pub parent_ty_p7: crate::lower::model::OutTy,
    pub args_p8: crate::prelude::Array<crate::syntax::Arg>,
    pub zero_based_p9: bool,
}

impl ::prism_rtl::Job<ClauseRow> for ClauseRowOf {
    fn cycle(&self) -> ::prism_rtl::Turn<ClauseRow> {
        let wx_p0 = &self.wx_p0;
        let menv_p1 = &self.menv_p1;
        let c_p2 = &self.c_p2;
        let v_p3 = &self.v_p3;
        let row_name_p4 = &self.row_name_p4;
        let gen_name_p5 = &self.gen_name_p5;
        let transparent_p6 = &self.transparent_p6;
        let parent_ty_p7 = &self.parent_ty_p7;
        let args_p8 = &self.args_p8;
        let zero_based_p9 = &self.zero_based_p9;
        let lx_pa = wx_p0.lx_p.clone();
        let lxc_pb = crate::lower::program::in_module_at_f(&lx_pa, &v_p3.file_p, &v_p3.home_p, &lx_pa.site_p);
        let ptys_pc = match &v_p3.scheme_p.ty_p {
            crate::check::types::Ty::TyFn(_, ps_ph, _) => ps_ph.clone(),
            _ => crate::prelude::Array::new(),
        };
        let valued_pd = *zero_based_p9 && (parent_ty_p7 == &crate::lower::model::OutTy::OutUnit);
        let widgets_pe = if valued_pd {
            crate::prelude::Array::new()
        } else {
            crate::prelude::fold(&crate::check::errors::range0_f(&crate::prelude::len(&c_p2.params_p)), &crate::prelude::Array::new(), &(|acc_pi: &crate::prelude::Array<(crate::prelude::Text, crate::syntax::Expr)>, i_pj: &crate::prelude::Nat| match (crate::prelude::index(&ptys_pc, i_pj), crate::prelude::index(&c_p2.params_p, i_pj), crate::prelude::index(args_p8, i_pj)) {
                (::std::option::Option::Some(pt_pk), ::std::option::Option::Some(p_pl), ::std::option::Option::Some(a_pm)) if is_blueprint_param_f(&pt_pk) => {
                    let bn_pn = crate::lower::functions::plain_binder_f(&lxc_pb, &p_pl);
                    if &bn_pn == &crate::prelude::Text::lit("") {
                        acc_pi.clone()
                    } else {
                        crate::prelude::push(acc_pi, &(bn_pn.clone(), a_pm.value_p.clone()))
                    }
                },
                _ => acc_pi.clone(),
                _ => unreachable!("no arm matched"),
            }))
        };
        let pats_pf = crate::prelude::each(&crate::check::errors::range0_f(&crate::prelude::len(&c_p2.params_p)), &(|i_po: &crate::prelude::Nat| match (crate::prelude::index(&ptys_pc, i_po), crate::prelude::index(&c_p2.params_p, i_po)) {
            (::std::option::Option::Some(pt_pp), ::std::option::Option::Some(p_pq)) if (is_blueprint_param_f(&pt_pp) && !valued_pd) => ::std::option::Option::None,
            (::std::option::Option::Some(pt_pr), ::std::option::Option::Some(p_ps)) if (valued_pd && is_live_param_f(&pt_pr)) => ::std::option::Option::None,
            (_, p_ot) => p_ot,
            _ => unreachable!("no arm matched"),
        }));
        let body_pg = match &c_p2.body_p {
            crate::syntax::decls::FnBody::BodyBlock(b_pu) => b_pu.clone(),
            crate::syntax::decls::FnBody::BodyExpr(x_pv) => crate::syntax::Block { stmts_p: crate::prelude::Array::from(vec![crate::syntax::Stmt { kind_p: crate::syntax::StmtKind::SExpr(x_pv.clone()), span_p: x_pv.span_p.clone() }]), inline_p: true, span_p: x_pv.span_p.clone() },
        };
        let body_pgz = body_pg.clone();
        let gen_name_p5z = gen_name_p5.clone();
        let lxc_pbz = lxc_pb.clone();
        let menv_p1z = menv_p1.clone();
        let parent_ty_p7z = parent_ty_p7.clone();
        let pats_pfz = pats_pf.clone();
        let ptys_pcz = ptys_pc.clone();
        let row_name_p4z = row_name_p4.clone();
        let transparent_p6z = *transparent_p6;
        let widgets_pez = widgets_pe.clone();
        let zero_based_p9z = *zero_based_p9;
        let k_let42804 = move |v42804: (crate::prelude::Array<(crate::prelude::Text, crate::lower::types::Bn)>, crate::lower::node_::Wx)| {
            let (dyns_p19, wxd_p1a) = v42804;
            ::prism_rtl::Turn::More(::std::rc::Rc::new(ArmRowOf { wx_p0: wxd_p1a.clone(), menv_p1: menv_p1z.clone(), lxc_p2: lxc_pbz.clone(), pats_p3: pats_pfz.clone(), ptys_p4: ptys_pcz.clone(), guard_o5: ::std::option::Option::None, body_p6: body_pgz.clone(), row_name_p7: row_name_p4z.clone(), gen_name_p8: gen_name_p5z.clone(), transparent_p9: transparent_p6z, reads_block_pa: false, parent_ty_pb: parent_ty_p7z.clone(), dyns_given_pc: dyns_p19.clone(), ups_pd: crate::prelude::Array::new(), widgets_pe: widgets_pez.clone(), zero_based_pf: zero_based_p9z }))
        };
        if valued_pd {
            {
                let c_p2x = c_p2.clone();
                let wx_p0x = wx_p0.clone();
                crate::prelude::call_then(start_live_shapes_f(lxc_pb.clone(), c_p2x.clone(), ptys_pc.clone()), move |live_shapes_f_42838: crate::prelude::Array<(crate::prelude::Text, crate::lower::types::Bn)>| k_let42804((live_shapes_f_42838, wx_p0x.clone())))
            }
        } else {
            {
                let args_p8x = args_p8.clone();
                let c_p2x = c_p2.clone();
                let menv_p1x = menv_p1.clone();
                let wx_p0x = wx_p0.clone();
                crate::prelude::call_value(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(&c_p2x.params_p)), (crate::prelude::Array::new(), wx_p0x.clone()), {
                    let ptys_pcx = ptys_pc.clone();
                    let c_p2xx = c_p2x.clone();
                    let args_p8xx = args_p8x.clone();
                    let lxc_pbx = lxc_pb.clone();
                    let menv_p1xx = menv_p1x.clone();
                    ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Array<(crate::prelude::Text, crate::lower::types::Bn)>, crate::lower::node_::Wx), crate::prelude::Nat)| {
                        let ptys_pcxy = ptys_pcx.clone();
                        let c_p2xxy = c_p2xx.clone();
                        let args_p8xxy = args_p8xx.clone();
                        let lxc_pbxy = lxc_pbx.clone();
                        let menv_p1xxy = menv_p1xx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let (acc_p10, w_p11) = p0;
                            let i_p12 = p1;
                            match (crate::prelude::index(&ptys_pcxy, &i_p12), crate::prelude::index(&c_p2xxy.params_p, &i_p12), crate::prelude::index(&args_p8xxy, &i_p12)) {
                                (::std::option::Option::Some(pt_p13), ::std::option::Option::Some(p_p14), ::std::option::Option::Some(a_p15)) if (&crate::lower::types::layer_of_f(&pt_p13) == &crate::lower::types::Layer::LyDyn) => {
                                    let bn_p16 = crate::lower::functions::plain_binder_f(&lxc_pbxy, &p_p14);
                                    if &bn_p16 == &crate::prelude::Text::lit("") {
                                        ::prism_rtl::Turn::Finished((acc_p10.clone(), w_p11.clone()))
                                    } else {
                                        crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lxc_pbxy.clone(), crate::lower::types::peel_f(&pt_p13)), move |out_ty_of_f_43188: crate::lower::model::OutTy| crate::prelude::call_then(start_clause_dyn_arg_f(w_p11.clone(), menv_p1xxy.clone(), a_p15.value_p.clone(), out_ty_of_f_43188), move |clause_dyn_arg_f_43156: (crate::lower::types::Bn, crate::lower::node_::Wx)| {
                                            let (b_p17, w2_p18) = clause_dyn_arg_f_43156;
                                            ::prism_rtl::Turn::Finished((crate::prelude::push(&acc_p10, &(bn_p16.clone(), b_p17.clone())), w2_p18.clone()))
                                        }))
                                    }
                                },
                                _ => ::prism_rtl::Turn::Finished((acc_p10.clone(), w_p11.clone())),
                                _ => unreachable!("no arm matched"),
                            }
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Array<(crate::prelude::Text, crate::lower::types::Bn)>, crate::lower::node_::Wx), crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<(crate::prelude::Text, crate::lower::types::Bn)>, crate::lower::node_::Wx)>>>
                }), move |fold_42875: (crate::prelude::Array<(crate::prelude::Text, crate::lower::types::Bn)>, crate::lower::node_::Wx)| k_let42804(fold_42875))
            }
        }
    }
}

/// `Start ClauseRowOf, x`: what the function value is when passed to `@Run`.
pub fn start_clause_row_of_f(wx_p0: crate::lower::node_::Wx, menv_p1: crate::lower::types::Env, c_p2: crate::syntax::decls::FnClause, v_p3: crate::check::env::ValInfo, row_name_p4: crate::prelude::Text, gen_name_p5: crate::prelude::Text, transparent_p6: bool, parent_ty_p7: crate::lower::model::OutTy, args_p8: crate::prelude::Array<crate::syntax::Arg>, zero_based_p9: bool) -> ::std::rc::Rc<dyn ::prism_rtl::Job<ClauseRow>> {
    ::std::rc::Rc::new(ClauseRowOf { wx_p0, menv_p1, c_p2, v_p3, row_name_p4, gen_name_p5, transparent_p6, parent_ty_p7, args_p8, zero_based_p9 })
}

/// ```prism
/// IsLiveParam: fn Ty -> Bool
/// ```
pub fn is_live_param_f(pt_p0: &crate::check::types::Ty) -> bool {
    (&crate::lower::types::layer_of_f(pt_p0) == &crate::lower::types::Layer::LyDyn) || (&crate::lower::types::layer_of_f(pt_p0) == &crate::lower::types::Layer::LyEv)
}

/// ```prism
/// IsShallowLiveParam: fn Ty -> Bool
/// ```
pub fn is_shallow_live_param_f(pt_p0: &crate::check::types::Ty) -> bool {
    is_live_param_f(pt_p0) && !crate::lower::types::has_time_f(&crate::lower::types::peel_f(pt_p0))
}

/// ```prism
/// HasLiveParam: fn ValInfo -> Bool
/// ```
pub fn has_live_param_f(v_p0: &crate::check::env::ValInfo) -> bool {
    match &v_p0.scheme_p.ty_p {
        crate::check::types::Ty::TyFn(_, ps_p1, _) => crate::prelude::fold(ps_p1, &false, &(|found_p2: &bool, pt_p3: &crate::check::types::Ty| *found_p2 || is_live_param_f(pt_p3))),
        _ => false,
    }
}

/// ```prism
/// LiveShapes: unbounded fn Lx, FnClause, [Ty] -> [((Text, Bn))]
/// ```
pub fn live_shapes_f(lxc_p0: &crate::lower::Lx, c_p1: &crate::syntax::decls::FnClause, ptys_p2: &crate::prelude::Array<crate::check::types::Ty>) -> crate::prelude::Array<(crate::prelude::Text, crate::lower::types::Bn)> {
    crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(&c_p1.params_p)), crate::prelude::Array::new(), {
        let ptys_p2x = ptys_p2.clone();
        let c_p1x = c_p1.clone();
        let lxc_p0x = lxc_p0.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<(crate::prelude::Text, crate::lower::types::Bn)>, crate::prelude::Nat)| {
            let ptys_p2xy = ptys_p2x.clone();
            let c_p1xy = c_p1x.clone();
            let lxc_p0xy = lxc_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_p3 = p0;
                let i_p4 = p1;
                match (crate::prelude::index(&ptys_p2xy, &i_p4), crate::prelude::index(&c_p1xy.params_p, &i_p4)) {
                    (::std::option::Option::Some(pt_p5), ::std::option::Option::Some(p_p6)) if is_live_param_f(&pt_p5) => crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lxc_p0xy.clone(), crate::lower::types::peel_f(&pt_p5)), move |out_ty_of_f_44588: crate::lower::model::OutTy| {
                        let t_p7 = out_ty_of_f_44588;
                        ::prism_rtl::Turn::Finished(crate::prelude::push(&acc_p3, &(crate::lower::functions::plain_binder_f(&lxc_p0xy, &p_p6), crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XUnit, crate::lower::types::Holding::Owned, if &crate::lower::types::layer_of_f(&pt_p5) == &crate::lower::types::Layer::LyDyn {
                            crate::lower::model::OutTy::OutDyn(::std::rc::Rc::new(t_p7.clone()))
                        } else {
                            crate::lower::model::OutTy::OutEvent(::std::rc::Rc::new(t_p7.clone()))
                        }))))
                    }),
                    _ => ::prism_rtl::Turn::Finished(acc_p3.clone()),
                    _ => unreachable!("no arm matched"),
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<(crate::prelude::Text, crate::lower::types::Bn)>, crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<(crate::prelude::Text, crate::lower::types::Bn)>>>>
    }))
}

/// The step machine of `LiveShapes`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LiveShapes: unbounded fn Lx, FnClause, [Ty] -> [((Text, Bn))]
/// ```
pub struct LiveShapes {
    pub lxc_p0: crate::lower::Lx,
    pub c_p1: crate::syntax::decls::FnClause,
    pub ptys_p2: crate::prelude::Array<crate::check::types::Ty>,
}

impl ::prism_rtl::Job<crate::prelude::Array<(crate::prelude::Text, crate::lower::types::Bn)>> for LiveShapes {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<(crate::prelude::Text, crate::lower::types::Bn)>> {
        let lxc_p0 = &self.lxc_p0;
        let c_p1 = &self.c_p1;
        let ptys_p2 = &self.ptys_p2;
        crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(&c_p1.params_p)), crate::prelude::Array::new(), {
            let ptys_p2x = ptys_p2.clone();
            let c_p1x = c_p1.clone();
            let lxc_p0x = lxc_p0.clone();
            ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<(crate::prelude::Text, crate::lower::types::Bn)>, crate::prelude::Nat)| {
                let ptys_p2xy = ptys_p2x.clone();
                let c_p1xy = c_p1x.clone();
                let lxc_p0xy = lxc_p0x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let acc_p3 = p0;
                    let i_p4 = p1;
                    match (crate::prelude::index(&ptys_p2xy, &i_p4), crate::prelude::index(&c_p1xy.params_p, &i_p4)) {
                        (::std::option::Option::Some(pt_p5), ::std::option::Option::Some(p_p6)) if is_live_param_f(&pt_p5) => crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lxc_p0xy.clone(), crate::lower::types::peel_f(&pt_p5)), move |out_ty_of_f_44588: crate::lower::model::OutTy| {
                            let t_p7 = out_ty_of_f_44588;
                            ::prism_rtl::Turn::Finished(crate::prelude::push(&acc_p3, &(crate::lower::functions::plain_binder_f(&lxc_p0xy, &p_p6), crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XUnit, crate::lower::types::Holding::Owned, if &crate::lower::types::layer_of_f(&pt_p5) == &crate::lower::types::Layer::LyDyn {
                                crate::lower::model::OutTy::OutDyn(::std::rc::Rc::new(t_p7.clone()))
                            } else {
                                crate::lower::model::OutTy::OutEvent(::std::rc::Rc::new(t_p7.clone()))
                            }))))
                        }),
                        _ => ::prism_rtl::Turn::Finished(acc_p3.clone()),
                        _ => unreachable!("no arm matched"),
                    }
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<(crate::prelude::Text, crate::lower::types::Bn)>, crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<(crate::prelude::Text, crate::lower::types::Bn)>>>>
        }).cycle()
    }
}

/// `Start LiveShapes, x`: what the function value is when passed to `@Run`.
pub fn start_live_shapes_f(lxc_p0: crate::lower::Lx, c_p1: crate::syntax::decls::FnClause, ptys_p2: crate::prelude::Array<crate::check::types::Ty>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<(crate::prelude::Text, crate::lower::types::Bn)>>> {
    ::std::rc::Rc::new(LiveShapes { lxc_p0, c_p1, ptys_p2 })
}

/// ```prism
/// LiveParams: fn Wx, [((Text, Bn))] -> ((Wx, Env, Env, [((Text, OutTy))]))
/// ```
pub fn live_params_f(r0_p0: &crate::lower::node_::Wx, lives_p1: &crate::prelude::Array<(crate::prelude::Text, crate::lower::types::Bn)>) -> (crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env, crate::prelude::Array<(crate::prelude::Text, crate::lower::model::OutTy)>) {
    crate::prelude::fold(lives_p1, &(r0_p0.clone(), crate::lower::types::empty_env_p(), crate::lower::types::empty_env_p(), crate::prelude::Array::new()), &(|(r_p2, be_p3, me_p4, params_p5): &(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env, crate::prelude::Array<(crate::prelude::Text, crate::lower::model::OutTy)>), (bn_p6, shape_p7): &(crate::prelude::Text, crate::lower::types::Bn)| match shape_p7 {
        crate::lower::types::Bn::BnLocal(_, _, crate::lower::model::OutTy::OutDyn(t_p8)) => {
            let (f_ph, r1_pi) = crate::lower::node_::fresh_name_f(r_p2, &crate::prelude::Text::from(format!("{}_param", &crate::lower::snake_f(bn_p6))));
            let res_p9 = crate::prelude::Text::from(format!("{}_res", &f_ph));
            let getter_pa = crate::prelude::Text::from(format!("{}_value", &f_ph));
            let follow_pb = crate::prelude::Text::from(format!("{}_follow", &f_ph));
            let init_pc = crate::prelude::Text::from(format!("{}_init", &f_ph));
            let followed_pd = crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("node"))), follow_pb.clone())), crate::prelude::Text::lit("follow"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("node"))), res_p9.clone())), crate::prelude::Text::lit("updates")))), crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("node")))), crate::lower::model::Ex::XPath(crate::lower::model::ref_child_f(&crate::lower::site_ref_f(&r_p2.lx_p, &r_p2.node_p), &crate::prelude::Text::from(format!("{}_result_moved", &f_ph))))])));
            let r2_pe = {
                let mut this: crate::lower::node_::Wx = r1_pi.clone();
                this.taken_p = crate::prelude::append(&this.taken_p, &crate::prelude::Array::from(vec![res_p9.clone(), getter_pa.clone(), follow_pb.clone(), init_pc.clone(), crate::prelude::Text::from(format!("{}_result_moved", &f_ph))]));
                this.fields_p = crate::prelude::append(&this.fields_p, &crate::prelude::Array::from(vec![(res_p9.clone(), crate::lower::model::OutTy::OutDyn(::std::rc::Rc::new((**t_p8).clone())), crate::prelude::Text::from(format!("`{}`, a `$` parameter of a widget that calls itself: the caller\'s dynamic", bn_p6))), (follow_pb.clone(), crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("prism_rtl::Follow")), crate::prelude::Array::new()), crate::prelude::Text::from(format!("the subscription to `{}`\'s update event", bn_p6)))]));
                this.inits_p = crate::prelude::push(&this.inits_p, &(res_p9.clone(), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(res_p9.clone())))));
                this.moves_p = crate::prelude::push(&this.moves_p, &(follow_pb.clone(), crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("prism_rtl::Follow::new")), crate::prelude::Array::new())));
                this.lets_p = crate::prelude::push(&this.lets_p, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaBind(init_pc.clone())), (**t_p8).clone()), crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XVar(res_p9.clone())), crate::prelude::Text::lit("sample"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx]))));
                this.inited_p = crate::prelude::append(&this.inited_p, &crate::prelude::Array::from(vec![res_p9.clone(), getter_pa.clone()]));
                this.build_p = crate::prelude::push(&this.build_p, &followed_pd);
                this.getters_p = crate::prelude::push(&this.getters_p, &crate::lower::model::MethDef { name_p: getter_pa.clone(), recv_p: crate::lower::model::Recv::RecvRef, params_p: crate::prelude::Array::new(), cx_p: crate::lower::model::CxArg::CxRef, ret_p: (**t_p8).clone(), body_p: crate::prelude::Array::new(), tail_p: crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), res_p9.clone())), crate::prelude::Text::lit("sample"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx])), doc_p: crate::prelude::Text::from(format!("`{}`, a `$` parameter, at the read point.", bn_p6)) });
                this.dyn_reads_p = crate::prelude::insert(&this.dyn_reads_p, &getter_pa, &crate::prelude::Array::from(vec![crate::lower::node_::Read::OwnRead(res_p9.clone())]));
                this.clause_results_p = crate::prelude::push(&this.clause_results_p, &f_ph);
                this
            };
            let be2_pf = crate::lower::types::bind_f(&crate::lower::types::bind_f(&crate::lower::types::bind_f(be_p3, bn_p6, &crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XVar(res_p9.clone())), crate::prelude::Text::lit("sample"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx])), crate::prelude::Array::from(vec![crate::lower::node_::Read::OwnRead(getter_pa.clone())]), (**t_p8).clone())), &crate::prelude::Text::from(format!("{}#init", bn_p6)), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(init_pc.clone()), crate::lower::types::Holding::Owned, (**t_p8).clone())), &crate::prelude::Text::from(format!("#whole#{}", bn_p6)), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(res_p9.clone()), crate::lower::types::Holding::Owned, crate::lower::model::OutTy::OutDyn(::std::rc::Rc::new((**t_p8).clone()))));
            let me2_pg = crate::lower::types::bind_f(&crate::lower::types::bind_f(me_p4, bn_p6, &crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), getter_pa.clone(), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx])), crate::prelude::Array::from(vec![crate::lower::node_::Read::OwnRead(getter_pa.clone())]), (**t_p8).clone())), &crate::prelude::Text::from(format!("#whole#{}", bn_p6)), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), res_p9.clone()), crate::lower::types::Holding::Owned, crate::lower::model::OutTy::OutDyn(::std::rc::Rc::new((**t_p8).clone()))));
            (r2_pe.clone(), be2_pf.clone(), me2_pg.clone(), crate::prelude::push(params_p5, &(res_p9.clone(), crate::lower::model::OutTy::OutDyn(::std::rc::Rc::new((**t_p8).clone())))))
        },
        crate::lower::types::Bn::BnLocal(_, _, crate::lower::model::OutTy::OutEvent(t_pj)) => {
            let (f_ps, r1_pt) = crate::lower::node_::fresh_name_f(r_p2, &crate::prelude::Text::from(format!("{}_param", &crate::lower::snake_f(bn_p6))));
            let ev_pk = crate::prelude::Text::from(format!("{}_ev", &f_ps));
            let (id_pu, r2_pv) = crate::lower::node_::add_gn_f(&r1_pt, &f_ps, &**t_pj, &crate::lower::node_::GnKind::GnPort, &crate::prelude::Nat::from(0u32));
            let port_pl = crate::lower::model::Ex::XClosure(false, crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("ev"))]), ::std::rc::Rc::new(crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("ev"))), crate::prelude::Text::lit("port"))))));
            let call_pm = crate::lower::model::Ex::XClosure(false, crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("n")), crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("v")), crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("cx"))]), ::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("n"))), f_ps.clone(), crate::prelude::Array::from(vec![crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("v")))), crate::lower::model::Ex::XCx]))));
            let sub_pn = crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XCall(crate::lower::helper_ref_f(&crate::prelude::Text::lit("subscribe_row")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("node")))), crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Some")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Rc::new")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("node"))), ev_pk.clone())))]))])), port_pl.clone(), call_pm.clone(), crate::lower::node_::finish::heard_above_f(&f_ps), crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("node"))), crate::prelude::Text::from(format!("{}_sub", &f_ps)))))])));
            let r3_po = {
                let mut this: crate::lower::node_::Wx = crate::lower::node_::add_field_f(&r2_pv, &crate::prelude::Text::from(format!("{}_sub", &f_ps)), &crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Cell")), crate::prelude::Array::from(vec![crate::lower::model::OutTy::OutOpt(::std::rc::Rc::new(crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Handle")), crate::prelude::Array::new())))])), &crate::prelude::Text::from(format!("the subscription to `{}`", bn_p6)), &crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Cell::new")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XNone])));
                this.taken_p = crate::prelude::append(&this.taken_p, &crate::prelude::Array::from(vec![ev_pk.clone(), crate::prelude::Text::from(format!("{}_sub", &f_ps))]));
                this.fields_p = crate::prelude::push(&this.fields_p, &(ev_pk.clone(), crate::lower::model::OutTy::OutEvent(::std::rc::Rc::new((**t_pj).clone())), crate::prelude::Text::from(format!("`{}`, an event parameter of a widget that calls itself: the caller\'s event", bn_p6))));
                this.inits_p = crate::prelude::push(&this.inits_p, &(ev_pk.clone(), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(ev_pk.clone())))));
                this.build_p = crate::prelude::push(&this.build_p, &sub_pn);
                this
            };
            let b_pp = crate::lower::types::Bn::BnEv(crate::lower::node_::ev_ref_of_f(&r3_po, &id_pu), (**t_pj).clone());
            let be2_pq = crate::lower::types::bind_f(&crate::lower::types::bind_f(be_p3, bn_p6, &b_pp), &crate::prelude::Text::from(format!("#whole#{}", bn_p6)), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(ev_pk.clone()), crate::lower::types::Holding::Owned, crate::lower::model::OutTy::OutEvent(::std::rc::Rc::new((**t_pj).clone()))));
            let me2_pr = crate::lower::types::bind_f(&crate::lower::types::bind_f(me_p4, bn_p6, &b_pp), &crate::prelude::Text::from(format!("#whole#{}", bn_p6)), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), ev_pk.clone()), crate::lower::types::Holding::Owned, crate::lower::model::OutTy::OutEvent(::std::rc::Rc::new((**t_pj).clone()))));
            (r3_po.clone(), be2_pq.clone(), me2_pr.clone(), crate::prelude::push(params_p5, &(ev_pk.clone(), crate::lower::model::OutTy::OutEvent(::std::rc::Rc::new((**t_pj).clone())))))
        },
        _ => (r_p2.clone(), be_p3.clone(), me_p4.clone(), params_p5.clone()),
    }))
}

/// ```prism
/// let wideGeneration
/// ```
pub fn wide_generation_p() -> crate::prelude::Nat {
    crate::prelude::Nat::from(1048576u32)
}

/// ```prism
/// IsSharable: unbounded fn Wx, Env, ValInfo, Expr, [Arg] -> Bool
/// ```
pub fn is_sharable_f(wx_p0: &crate::lower::node_::Wx, menv_p1: &crate::lower::types::Env, v_p2: &crate::check::env::ValInfo, e_p3: &crate::syntax::Expr, args_p4: &crate::prelude::Array<crate::syntax::Arg>) -> bool {
    let ptys_p5 = match &v_p2.scheme_p.ty_p {
        crate::check::types::Ty::TyFn(_, ps_pa, _) => ps_pa.clone(),
        _ => crate::prelude::Array::new(),
    };
    let plain_result_p6 = (&result_layer_f(&crate::lower::type_at_f(&wx_p0.lx_p, &e_p3.span_p)) == &crate::lower::types::Layer::LyPlain) && !crate::lower::types::is_bundle_f(&crate::lower::node_::def::line_out_full_f(&wx_p0.lx_p, e_p3));
    let plain_params_p7 = crate::prelude::fold(&ptys_p5, &true, &(|ok_pb: &bool, pt_pc: &crate::check::types::Ty| (*ok_pb && (&crate::lower::types::layer_of_f(pt_pc) == &crate::lower::types::Layer::LyPlain)) && !crate::lower::node_::static_::is_widget_fn_ty_f(pt_pc)));
    let valued_params_p8 = crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(&ptys_p5)), true, {
        let ptys_p5x = ptys_p5.clone();
        let wx_p0x = wx_p0.clone();
        let menv_p1x = menv_p1.clone();
        let args_p4x = args_p4.clone();
        ::std::rc::Rc::new(move |(p0, p1): (bool, crate::prelude::Nat)| {
            let ptys_p5xy = ptys_p5x.clone();
            let wx_p0xy = wx_p0x.clone();
            let menv_p1xy = menv_p1x.clone();
            let args_p4xy = args_p4x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let ok_pd = p0;
                let i_pe = p1;
                ::prism_rtl::Turn::Finished(ok_pd && match crate::prelude::index(&ptys_p5xy, &i_pe) {
                    ::std::option::Option::Some(pt_pf) => if crate::lower::node_::static_::is_widget_fn_ty_f(&pt_pf) {
                        false
                    } else {
                        if &crate::lower::types::layer_of_f(&pt_pf) == &crate::lower::types::Layer::LyBlueprint {
                            is_blueprint_valued_f(&wx_p0xy.lx_p, &menv_p1xy, &crate::prelude::index(&args_p4xy, &i_pe))
                        } else {
                            (&crate::lower::types::layer_of_f(&pt_pf) == &crate::lower::types::Layer::LyPlain) || is_shallow_live_param_f(&pt_pf)
                        }
                    },
                    ::std::option::Option::None => true,
                })
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
    }));
    let nothing_back_p9 = &crate::lower::types::out_ty_of_f(&wx_p0.lx_p, &crate::lower::types::out_of_f(&crate::lower::type_at_f(&wx_p0.lx_p, &e_p3.span_p))) == &crate::lower::model::OutTy::OutUnit;
    (plain_result_p6 && (&crate::prelude::len(&crate::lower::node_::static_::rigids_in_f(&v_p2.scheme_p.ty_p)) == &crate::prelude::Nat::from(0u32))) && (plain_params_p7 || (valued_params_p8 && nothing_back_p9))
}

/// ```prism
/// SharesAt: unbounded fn Wx, Env, Text, ValInfo, Expr, [Arg] -> Bool
/// ```
pub fn shares_at_f(wx_p0: &crate::lower::node_::Wx, menv_p1: &crate::lower::types::Env, qk_p2: &crate::prelude::Text, v_p3: &crate::check::env::ValInfo, e_p4: &crate::syntax::Expr, args_p5: &crate::prelude::Array<crate::syntax::Arg>) -> bool {
    ((&crate::lower::node_::static_::recursion_f(&wx_p0.inlining_p, qk_p2) > &crate::prelude::Nat::from(0u32)) || (has_live_param_f(v_p3) && crate::lower::program::calls_itself_f(&wx_p0.lx_p, qk_p2))) && is_sharable_f(wx_p0, menv_p1, v_p3, e_p4, args_p5)
}

/// ```prism
/// SharedLiveCalls: unbounded fn Wx, Env, Expr -> [Text]
/// ```
pub fn shared_live_calls_f(wx_p0: &crate::lower::node_::Wx, menv_p1: &crate::lower::types::Env, e_p2: &crate::syntax::Expr) -> crate::prelude::Array<crate::prelude::Text> {
    crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::typed::print::exprs_in_f(e_p2), crate::prelude::Array::new(), {
        let wx_p0x = wx_p0.clone();
        let menv_p1x = menv_p1.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::syntax::Expr)| {
            let wx_p0xy = wx_p0x.clone();
            let menv_p1xy = menv_p1x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_p3 = p0;
                let x_p4 = p1;
                match &*x_p4.kind_p {
                    crate::syntax::ExprKind::ECall(c_p5, args_p6, _, _) => {
                        let qk_p7 = crate::lower::program::blueprint_qk_f(&wx_p0xy.lx_p, &**c_p5);
                        match crate::prelude::get(&wx_p0xy.lx_p.g_p.vals_p, &qk_p7) {
                            ::std::option::Option::Some(v_p8) => if (has_live_param_f(&v_p8) && crate::lower::node_::def::is_widget_ty_f(&crate::lower::node_::static_::widget_result_of_f(&v_p8.scheme_p.ty_p))) && (crate::check::env::has_key_f(&wx_p0xy.lx_p.valued_at_p, &qk_p7) || shares_at_f(&wx_p0xy, &menv_p1xy, &qk_p7, &v_p8, &x_p4, args_p6)) {
                                ::prism_rtl::Turn::Finished(crate::prelude::push(&acc_p3, &crate::lower::node_::static_::dyn_key_f(&x_p4)))
                            } else {
                                ::prism_rtl::Turn::Finished(acc_p3.clone())
                            },
                            ::std::option::Option::None => ::prism_rtl::Turn::Finished(acc_p3.clone()),
                        }
                    },
                    _ => ::prism_rtl::Turn::Finished(acc_p3.clone()),
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::syntax::Expr)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>
    }))
}

/// ```prism
/// IsBlueprintValued: unbounded fn Lx, Env, ?Arg -> Bool
/// ```
pub fn is_blueprint_valued_f(lx_p0: &crate::lower::Lx, menv_p1: &crate::lower::types::Env, a_o2: &::std::option::Option<crate::syntax::Arg>) -> bool {
    match a_o2 {
        ::std::option::Option::None => false,
        ::std::option::Option::Some(a_p3) => match &*crate::lower::node_::static_::ungrouped_f(&a_p3.value_p).kind_p {
            crate::syntax::ExprKind::EName(n_p4) => match if &crate::prelude::len(&n_p4.path_p) == &crate::prelude::Nat::from(1u32) {
                crate::prelude::get(&menv_p1.names_p, &crate::check::env::sname_key_f(n_p4))
            } else {
                ::std::option::Option::None
            } {
                ::std::option::Option::Some(crate::lower::types::Bn::BnLocal(_, _, _)) => true,
                ::std::option::Option::Some(crate::lower::types::Bn::BnWidget(x_p5, _, _, clx_p6)) => crate::check::env::has_key_f(&lx_p0.valued_at_p, &crate::lower::program::blueprint_qk_f(&clx_p6, &x_p5)),
                ::std::option::Option::None => crate::check::env::has_key_f(&lx_p0.valued_at_p, &crate::lower::program::blueprint_qk_f(lx_p0, &a_p3.value_p)),
                _ => false,
            },
            _ => false,
        },
    }
}

/// ```prism
/// SharedScrutinee: unbounded fn Lx, Env, ValInfo, [Arg] -> Ex
/// ```
pub fn shared_scrutinee_f(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, v_p2: &crate::check::env::ValInfo, args_p3: &crate::prelude::Array<crate::syntax::Arg>) -> crate::lower::model::Ex {
    let ptys_p4 = match &v_p2.scheme_p.ty_p {
        crate::check::types::Ty::TyFn(_, ps_p6, _) => ps_p6.clone(),
        _ => crate::prelude::Array::new(),
    };
    let parts_p5 = crate::prelude::run_to_end(crate::prelude::each_job(crate::check::errors::range0_f(&crate::prelude::len(args_p3)), {
        let ptys_p4x = ptys_p4.clone();
        let args_p3x = args_p3.clone();
        let env_p1x = env_p1.clone();
        let lx_p0x = lx_p0.clone();
        ::std::rc::Rc::new(move |p0: crate::prelude::Nat| {
            let ptys_p4xy = ptys_p4x.clone();
            let args_p3xy = args_p3x.clone();
            let env_p1xy = env_p1x.clone();
            let lx_p0xy = lx_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let i_p7 = p0;
                match (crate::prelude::index(&ptys_p4xy, &i_p7), crate::prelude::index(&args_p3xy, &i_p7)) {
                    (::std::option::Option::Some(pt_p8), ::std::option::Option::Some(a_p9)) if (&crate::lower::types::layer_of_f(&pt_p8) == &crate::lower::types::Layer::LyBlueprint) => match &*crate::lower::node_::static_::ungrouped_f(&a_p9.value_p).kind_p {
                        crate::syntax::ExprKind::EName(n_pa) => match if &crate::prelude::len(&n_pa.path_p) == &crate::prelude::Nat::from(1u32) {
                            crate::prelude::get(&env_p1xy.names_p, &crate::check::env::sname_key_f(n_pa))
                        } else {
                            ::std::option::Option::None
                        } {
                            ::std::option::Option::Some(crate::lower::types::Bn::BnWidget(x_pb, _, cmenv_pc, clx_pd)) => crate::prelude::call_then(crate::lower::expr::start_value_of_f(clx_pd.clone(), cmenv_pc.clone(), x_pb.clone()), move |value_of_f_54101: crate::lower::types::Vl| ::prism_rtl::Turn::Finished(crate::lower::types::ref_f(&value_of_f_54101))),
                            _ => ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::lower::expr::Argument { lx_p0: lx_p0xy.clone(), env_p1: env_p1xy.clone(), e_p2: a_p9.value_p.clone() })),
                        },
                        _ => ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::lower::expr::Argument { lx_p0: lx_p0xy.clone(), env_p1: env_p1xy.clone(), e_p2: a_p9.value_p.clone() })),
                    },
                    (::std::option::Option::Some(pt_pe), ::std::option::Option::Some(a_pf)) if is_live_param_f(&pt_pe) => match &*crate::lower::node_::static_::ungrouped_f(&a_pf.value_p).kind_p {
                        crate::syntax::ExprKind::EName(n_pg) => match if &crate::prelude::len(&n_pg.path_p) == &crate::prelude::Nat::from(1u32) {
                            crate::prelude::get(&env_p1xy.names_p, &crate::prelude::Text::from(format!("#whole#{}", &crate::check::env::sname_key_f(n_pg))))
                        } else {
                            ::std::option::Option::None
                        } {
                            ::std::option::Option::Some(crate::lower::types::Bn::BnLocal(x_ph, mode_pi, lt_pj)) => ::prism_rtl::Turn::Finished(crate::lower::types::ref_f(&crate::lower::types::local_place_f(&x_ph, &mode_pi, &lt_pj))),
                            _ => crate::prelude::call_then(crate::lower::expr::start_value_of_f(as_whole_f(&lx_p0xy), env_p1xy.clone(), a_pf.value_p.clone()), move |value_of_f_54694: crate::lower::types::Vl| ::prism_rtl::Turn::Finished(crate::lower::types::ref_f(&value_of_f_54694))),
                        },
                        _ => crate::prelude::call_then(crate::lower::expr::start_value_of_f(as_whole_f(&lx_p0xy), env_p1xy.clone(), a_pf.value_p.clone()), move |value_of_f_54758: crate::lower::types::Vl| ::prism_rtl::Turn::Finished(crate::lower::types::ref_f(&value_of_f_54758))),
                    },
                    (_, ::std::option::Option::Some(a_pk)) => ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::lower::expr::Argument { lx_p0: lx_p0xy.clone(), env_p1: env_p1xy.clone(), e_p2: a_pk.value_p.clone() })),
                    _ => ::prism_rtl::Turn::Finished(crate::lower::model::Ex::XUnit),
                    _ => unreachable!("no arm matched"),
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>>>
    }));
    crate::lower::model::Ex::XTuple(parts_p5.clone())
}

/// ```prism
/// AsWhole: fn Lx -> Lx
/// ```
pub fn as_whole_f(lx_p0: &crate::lower::Lx) -> crate::lower::Lx {
    let mut this: crate::lower::Lx = lx_p0.clone();
    this.whole_p = true;
    this
}

/// ```prism
/// SharedClauseLine: unbounded fn Wx, Env, Expr, Text, ValInfo, Expr, [Arg] -> ((Wx, Wres))
/// ```
pub fn shared_clause_line_f(wx_p0: &crate::lower::node_::Wx, menv_p1: &crate::lower::types::Env, scrut_p2: &crate::syntax::Expr, qk_p3: &crate::prelude::Text, v_p4: &crate::check::env::ValInfo, e_p5: &crate::syntax::Expr, args_p6: &crate::prelude::Array<crate::syntax::Arg>) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    let lx_p7 = wx_p0.lx_p.clone();
    let pos_p8 = wx_p0.pos_p.clone();
    let (src_ex_pm, source_reads_pn) = crate::lower::node_::dynamics::dynamic_expr_f(wx_p0, menv_p1, scrut_p2);
    let live_first_p9 = match &v_p4.scheme_p.ty_p {
        crate::check::types::Ty::TyFn(_, ps_po, _) => is_live_param_f(&crate::prelude::or(&crate::prelude::index(ps_po, &crate::prelude::Nat::from(0u32)), &crate::check::types::Ty::TyErr)),
        _ => false,
    };
    let reads_pa = if live_first_p9 { crate::prelude::Array::new() } else { source_reads_pn.clone() };
    let vt_pb = crate::lower::types::out_ty_of_f(&lx_p7, &crate::lower::types::peel_f(&crate::lower::type_at_f(&lx_p7, &scrut_p2.span_p)));
    let (name_pp, wx1_pq) = crate::lower::node_::fresh_name_f(wx_p0, &crate::prelude::Text::lit("generation"));
    let clauses_pc = crate::lower::jobs::clauses_of_f(&lx_p7.g_p, qk_p3);
    let (cases_p19, wx2_p1a) = match crate::prelude::get(&lx_p7.shared_p, qk_p3) {
        ::std::option::Option::Some(known_pr) => (known_pr, wx1_pq.clone()),
        ::std::option::Option::None => {
            let stem_ps = crate::prelude::Text::from(format!("{}Rec{}C", &wx_p0.node_p, &crate::lower::node_::keyed::row_suffix_f(wx_p0)));
            let heads_pt = crate::prelude::run_to_end(crate::prelude::each_job(crate::check::errors::range0_f(&crate::prelude::len(&clauses_pc)), {
                let lx_p7x = lx_p7.clone();
                let v_p4x = v_p4.clone();
                let clauses_pcx = clauses_pc.clone();
                let stem_psx = stem_ps.clone();
                ::std::rc::Rc::new(move |p0: crate::prelude::Nat| {
                    let lx_p7xy = lx_p7x.clone();
                    let v_p4xy = v_p4x.clone();
                    let clauses_pcxy = clauses_pcx.clone();
                    let stem_psxy = stem_psx.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let i_p10 = p0;
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(SharedCaseOf { lx_p0: lx_p7xy.clone(), v_p1: v_p4xy.clone(), c_p2: crate::prelude::or(&crate::prelude::index(&clauses_pcxy, &i_p10), &crate::lower::functions::dummy_clause_p()), row_name_p3: crate::prelude::Text::from(format!("{}{}", &stem_psxy, &i_p10)) }))
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Text, crate::lower::model::Pa, crate::prelude::Array<crate::lower::model::Cc>, crate::prelude::Array<crate::lower::model::Ex>)>>>
            }));
            let inside_pu = {
                let mut this: crate::lower::node_::Wx = wx1_pq.clone();
                this.lx_p = with_shared_f(&lx_p7, qk_p3, &heads_pt);
                this
            };
            let (rows_p15, made_p16) = crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(&clauses_pc)), (crate::prelude::Array::new(), inside_pu.clone()), {
                let menv_p1x = menv_p1.clone();
                let clauses_pcx = clauses_pc.clone();
                let v_p4x = v_p4.clone();
                let stem_psx = stem_ps.clone();
                let name_ppx = name_pp.clone();
                let args_p6x = args_p6.clone();
                ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Array<ClauseRow>, crate::lower::node_::Wx), crate::prelude::Nat)| {
                    let menv_p1xy = menv_p1x.clone();
                    let clauses_pcxy = clauses_pcx.clone();
                    let v_p4xy = v_p4x.clone();
                    let stem_psxy = stem_psx.clone();
                    let name_ppxy = name_ppx.clone();
                    let args_p6xy = args_p6x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let (acc_p11, w_p12) = p0;
                        let i_p13 = p1;
                        crate::prelude::call_then(start_clause_row_of_f(w_p12.clone(), menv_p1xy.clone(), crate::prelude::or(&crate::prelude::index(&clauses_pcxy, &i_p13), &crate::lower::functions::dummy_clause_p()), v_p4xy.clone(), crate::prelude::Text::from(format!("{}{}", &stem_psxy, &i_p13)), name_ppxy.clone(), true, crate::lower::model::OutTy::OutUnit, args_p6xy.clone(), true), move |clause_row_of_f_57031: ClauseRow| {
                            let cr_p14 = clause_row_of_f_57031;
                            ::prism_rtl::Turn::Finished((crate::prelude::push(&acc_p11, &cr_p14), cr_p14.parent_p.clone()))
                        })
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Array<ClauseRow>, crate::lower::node_::Wx), crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<ClauseRow>, crate::lower::node_::Wx)>>>
            }));
            let back_pv = {
                let mut this: crate::lower::node_::Wx = made_p16.clone();
                this.lx_p = lx_p7.clone();
                this.rows_p = crate::prelude::fold(&rows_p15, &this.rows_p, &(|acc_p17: &crate::prelude::Array<crate::lower::model::NodeDef>, cr_p18: &ClauseRow| crate::prelude::append(&crate::prelude::push(acc_p17, &cr_p18.case_p.node_p), &cr_p18.case_p.node_p.children_p)));
                this
            };
            (heads_pt.clone(), back_pv.clone())
        },
    };
    let row_obj_pd = crate::lower::model::OutTy::OutObj(::std::rc::Rc::new(crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Row")), crate::prelude::Array::new())));
    let gap_pe = crate::lower::model::Ex::XBin(crate::lower::model::BinOp::OpSub, ::std::rc::Rc::new(crate::lower::model::Ex::XIndex(wide_generation_p())), ::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("row"))), crate::prelude::Text::lit("built"), crate::prelude::Array::new())));
    let out_ty_pf = crate::lower::types::out_ty_of_f(&lx_p7, &crate::lower::types::out_of_f(&crate::lower::type_at_f(&lx_p7, &e_p5.span_p)));
    let res_pg = crate::prelude::Text::from(format!("{}_res", &name_pp));
    let keeps_ph = if &out_ty_pf == &crate::lower::model::OutTy::OutUnit {
        crate::prelude::Array::new()
    } else {
        crate::prelude::Array::from(vec![crate::lower::model::Do::DoAssign(crate::lower::model::Ex::XDeref(::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), res_pg.clone())), crate::prelude::Text::lit("borrow_mut"), crate::prelude::Array::new()))), crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Some")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("row"))), crate::prelude::Text::lit("result_value"), crate::prelude::Array::new())])))])
    };
    let hosted_pi = match crate::lower::node_::finish::hosted_rows_o(wx_p0) {
        ::std::option::Option::Some(m_p1b) => crate::prelude::push(&crate::lower::node_::keyed::hosted_passed_f(wx_p0), &crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("prism_rtl::moved_by")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XSelf)))), crate::lower::model::Ex::XPath(crate::lower::model::ref_child_f(&crate::lower::site_ref_f(&lx_p7, &wx_p0.node_p), &m_p1b))]))),
        ::std::option::Option::None => crate::prelude::Array::new(),
    };
    let arms_pj = crate::prelude::each(&cases_p19, &(|(row_node_p1c, pat_p1d, conds_p1e, passed_p1f): &(crate::prelude::Text, crate::lower::model::Pa, crate::prelude::Array<crate::lower::model::Cc>, crate::prelude::Array<crate::lower::model::Ex>)| {
        let built_p1g = crate::lower::expr::try_of_f(&crate::lower::model::Ex::XCall(crate::lower::model::ref_child_f(&crate::lower::site_ref_f(&lx_p7, row_node_p1c), &crate::prelude::Text::lit("build")), crate::prelude::append(&crate::prelude::append(&crate::prelude::Array::from(vec![crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("path"))))]), passed_p1f), &crate::prelude::append(&crate::prelude::append(&crate::prelude::Array::from(vec![crate::lower::model::Ex::XUnit]), &hosted_pi), &crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx])))));
        crate::lower::model::XArm { pat_p: pat_p1d.clone(), conds_p: conds_p1e.clone(), body_p: crate::lower::model::Ex::XBlock(crate::prelude::append(&crate::prelude::append(&crate::prelude::Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("row")), built_p1g.clone())]), &keeps_ph), &gap_set_f(&name_pp, &::std::option::Option::Some(gap_pe.clone()))), ::std::rc::Rc::new(crate::lower::model::Ex::XCast(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("row"))), row_obj_pd.clone()))) }
    }));
    let select_pk = with_row_base_f(wx_p0, &crate::prelude::Text::lit("self"), &pos_p8, &crate::lower::types::own_f(&crate::lower::expr::arms_value_f(&shared_scrutinee_f(&lx_p7, menv_p1, v_p4, args_p6), &arms_pj, &crate::prelude::Text::lit("\'select"), &row_obj_pd)));
    let wx3_pl = {
        let mut this: crate::lower::node_::Wx = wx2_p1a.clone();
        this.pos_p = crate::lower::model::Pos { scope_p: pos_p8.scope_p.clone(), at_p: &pos_p8.at_p + &wide_generation_p() };
        this.gens_p = crate::prelude::push(&this.gens_p, &crate::lower::model::GenDef { name_p: name_pp.clone(), pos_p: pos_p8.clone(), at_p: crate::lower::node_::finish::place_at_f(wx_p0, &crate::prelude::Text::lit("self"), &pos_p8), source_p: src_ex_pm.clone(), value_ty_p: vt_pb.clone(), select_p: select_pk.clone(), transparent_p: true, width_p: wide_generation_p(), moved_p: crate::prelude::or(&crate::lower::node_::finish::hosted_rows_o(wx_p0), &crate::prelude::Text::lit("")), early_p: false, gappy_p: true, rebased_p: true });
        this.gen_holds_p = crate::prelude::push(&this.gen_holds_p, &(name_pp.clone(), reads_pa.clone()));
        this
    };
    if &out_ty_pf == &crate::lower::model::OutTy::OutUnit {
        (wx3_pl.clone(), crate::lower::node_::Wres::WrUnit)
    } else {
        {
            let read_p1h = crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), res_pg.clone())), crate::prelude::Text::lit("borrow"), crate::prelude::Array::new())), crate::prelude::Text::lit("as_ref"), crate::prelude::Array::new())), crate::prelude::Text::lit("expect"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XStr(crate::prelude::Text::lit("a row built before what reads its result"))]))));
            let wx4_p1i = {
                let mut this: crate::lower::node_::Wx = wx3_pl.clone();
                this.taken_p = crate::prelude::push(&this.taken_p, &res_pg);
                this.fields_p = crate::prelude::push(&this.fields_p, &(res_pg.clone(), crate::lower::model::OutTy::OutCell(::std::rc::Rc::new(crate::lower::model::OutTy::OutOpt(::std::rc::Rc::new(out_ty_pf.clone())))), crate::prelude::Text::lit("the plain result of the widget that calls itself, kept from its row\'s build on")));
                this.inits_p = crate::prelude::push(&this.inits_p, &(res_pg.clone(), crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::RefCell::new")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XNone]))));
                this
            };
            (wx4_p1i.clone(), crate::lower::node_::Wres::WrLate(read_p1h.clone(), out_ty_pf.clone()))
        }
    }
}

/// ```prism
/// WithShared: fn Lx, Text, [((Text, Pa, [Cc], [Ex]))] -> Lx
/// ```
pub fn with_shared_f(lx_p0: &crate::lower::Lx, qk_p1: &crate::prelude::Text, cases_p2: &crate::prelude::Array<(crate::prelude::Text, crate::lower::model::Pa, crate::prelude::Array<crate::lower::model::Cc>, crate::prelude::Array<crate::lower::model::Ex>)>) -> crate::lower::Lx {
    let mut this: crate::lower::Lx = lx_p0.clone();
    this.shared_p = crate::prelude::insert(&this.shared_p, qk_p1, cases_p2);
    this
}

/// ```prism
/// SharedCaseOf: unbounded fn Lx, ValInfo, FnClause, Text -> ((Text, Pa, [Cc], [Ex]))
/// ```
pub fn shared_case_of_f(lx_p0: &crate::lower::Lx, v_p1: &crate::check::env::ValInfo, c_p2: &crate::syntax::decls::FnClause, row_name_p3: &crate::prelude::Text) -> (crate::prelude::Text, crate::lower::model::Pa, crate::prelude::Array<crate::lower::model::Cc>, crate::prelude::Array<crate::lower::model::Ex>) {
    let lxc_p4 = crate::lower::program::in_module_at_f(lx_p0, &v_p1.file_p, &v_p1.home_p, &lx_p0.site_p);
    let ptys_p5 = match &v_p1.scheme_p.ty_p {
        crate::check::types::Ty::TyFn(_, ps_pd, _) => ps_pd.clone(),
        _ => crate::prelude::Array::new(),
    };
    let live_p6 = crate::prelude::filter(&crate::check::errors::range0_f(&crate::prelude::len(&c_p2.params_p)), &(|i_pe: &crate::prelude::Nat| is_live_param_f(&crate::prelude::or(&crate::prelude::index(&ptys_p5, i_pe), &crate::check::types::Ty::TyErr))));
    let pos_p7 = crate::prelude::run_to_end(crate::prelude::each_job(crate::check::errors::range0_f(&crate::prelude::len(&c_p2.params_p)), {
        let live_p6x = live_p6.clone();
        let lxc_p4x = lxc_p4.clone();
        let c_p2x = c_p2.clone();
        let ptys_p5x = ptys_p5.clone();
        ::std::rc::Rc::new(move |p0: crate::prelude::Nat| {
            let live_p6xy = live_p6x.clone();
            let lxc_p4xy = lxc_p4x.clone();
            let c_p2xy = c_p2x.clone();
            let ptys_p5xy = ptys_p5x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let i_pf = p0;
                if crate::check::types::has_nat_f(&live_p6xy, &i_pf) {
                    ::prism_rtl::Turn::Finished(crate::lower::patterns::PatOut { pa_p: crate::lower::model::Pa::PaBind(crate::prelude::Text::from(format!("live{}", &i_pf))), conds_p: crate::prelude::Array::new(), binds_p: crate::prelude::Array::new() })
                } else {
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::lower::expr::ArmPat { lx_p0: lxc_p4xy.clone(), opt1: crate::prelude::index(&c_p2xy.params_p, &i_pf), ty_p2: crate::prelude::or(&crate::prelude::index(&ptys_p5xy, &i_pf), &crate::check::types::Ty::TyErr), mode_p3: crate::lower::types::Holding::ByRef, fresh_p4: crate::prelude::Text::from(format!("c{}", &i_pf)) }))
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::patterns::PatOut>>>
    }));
    let binds_p8 = crate::prelude::fold(&pos_p7, &crate::prelude::Map::new(), &(|m_pg: &crate::prelude::Map<crate::prelude::Text, crate::lower::types::Bn>, o_ph: &crate::lower::patterns::PatOut| crate::prelude::fold(&o_ph.binds_p, m_pg, &(|m2_pi: &crate::prelude::Map<crate::prelude::Text, crate::lower::types::Bn>, (n_pj, b_pk): &(crate::prelude::Text, crate::lower::types::Bn)| crate::prelude::insert(m2_pi, n_pj, b_pk)))));
    let named_p9 = crate::prelude::run_to_end(crate::prelude::fold_job(c_p2.params_p.clone(), crate::prelude::Array::new(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>, crate::syntax::Pattern)| crate::prelude::entered(crate::prelude::once_job(move || {
        let acc_pl = p0;
        let p_pm = p1;
        crate::prelude::call_then(crate::check::env::names::start_pattern_binders_f(p_pm.clone()), move |pattern_binders_f_61137: crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_pl, &pattern_binders_f_61137)))
    }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>, crate::syntax::Pattern)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>>>>));
    let binders_pa = crate::prelude::filter(&named_p9, &(|(bn_pn, _): &(crate::prelude::Text, crate::syntax::Range)| crate::check::env::has_key_f(&binds_p8, bn_pn)));
    let passed_pb = crate::prelude::each(&binders_pa, &(|(bn_po, _): &(crate::prelude::Text, crate::syntax::Range)| match crate::prelude::get(&binds_p8, bn_po) {
        ::std::option::Option::Some(crate::lower::types::Bn::BnLocal(rs_pp, mode_pq, bt_pr)) => crate::lower::types::own_f(&crate::lower::types::Vl::VlPlace(rs_pp, mode_pq, bt_pr)),
        _ => crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::lower::snake_f(bn_po)))),
    }));
    let handed_pc = crate::prelude::each(&live_p6, &(|i_ps: &crate::prelude::Nat| crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::from(format!("live{}", i_ps)))))));
    (row_name_p3.clone(), crate::lower::model::Pa::PaTuple(crate::prelude::each(&pos_p7, &(|o_pt: &crate::lower::patterns::PatOut| o_pt.pa_p.clone()))), crate::prelude::fold(&pos_p7, &crate::prelude::Array::new(), &(|acc_pu: &crate::prelude::Array<crate::lower::model::Cc>, o_pv: &crate::lower::patterns::PatOut| crate::prelude::append(acc_pu, &o_pv.conds_p))), crate::prelude::push(&crate::prelude::append(&passed_pb, &handed_pc), &crate::lower::model::Ex::XVar(crate::prelude::Text::lit("row_base"))))
}

/// The step machine of `SharedCaseOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SharedCaseOf: unbounded fn Lx, ValInfo, FnClause, Text -> ((Text, Pa, [Cc], [Ex]))
/// ```
pub struct SharedCaseOf {
    pub lx_p0: crate::lower::Lx,
    pub v_p1: crate::check::env::ValInfo,
    pub c_p2: crate::syntax::decls::FnClause,
    pub row_name_p3: crate::prelude::Text,
}

impl ::prism_rtl::Job<(crate::prelude::Text, crate::lower::model::Pa, crate::prelude::Array<crate::lower::model::Cc>, crate::prelude::Array<crate::lower::model::Ex>)> for SharedCaseOf {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::prelude::Text, crate::lower::model::Pa, crate::prelude::Array<crate::lower::model::Cc>, crate::prelude::Array<crate::lower::model::Ex>)> {
        let lx_p0 = &self.lx_p0;
        let v_p1 = &self.v_p1;
        let c_p2 = &self.c_p2;
        let row_name_p3 = &self.row_name_p3;
        let lxc_p4 = crate::lower::program::in_module_at_f(lx_p0, &v_p1.file_p, &v_p1.home_p, &lx_p0.site_p);
        let ptys_p5 = match &v_p1.scheme_p.ty_p {
            crate::check::types::Ty::TyFn(_, ps_pd, _) => ps_pd.clone(),
            _ => crate::prelude::Array::new(),
        };
        let live_p6 = crate::prelude::filter(&crate::check::errors::range0_f(&crate::prelude::len(&c_p2.params_p)), &(|i_pe: &crate::prelude::Nat| is_live_param_f(&crate::prelude::or(&crate::prelude::index(&ptys_p5, i_pe), &crate::check::types::Ty::TyErr))));
        let c_p2x = c_p2.clone();
        let row_name_p3x = row_name_p3.clone();
        crate::prelude::call_value(crate::prelude::each_job(crate::check::errors::range0_f(&crate::prelude::len(&c_p2x.params_p)), {
            let live_p6x = live_p6.clone();
            let lxc_p4x = lxc_p4.clone();
            let c_p2xx = c_p2x.clone();
            let ptys_p5x = ptys_p5.clone();
            ::std::rc::Rc::new(move |p0: crate::prelude::Nat| {
                let live_p6xy = live_p6x.clone();
                let lxc_p4xy = lxc_p4x.clone();
                let c_p2xxy = c_p2xx.clone();
                let ptys_p5xy = ptys_p5x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let i_pf = p0;
                    if crate::check::types::has_nat_f(&live_p6xy, &i_pf) {
                        ::prism_rtl::Turn::Finished(crate::lower::patterns::PatOut { pa_p: crate::lower::model::Pa::PaBind(crate::prelude::Text::from(format!("live{}", &i_pf))), conds_p: crate::prelude::Array::new(), binds_p: crate::prelude::Array::new() })
                    } else {
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::lower::expr::ArmPat { lx_p0: lxc_p4xy.clone(), opt1: crate::prelude::index(&c_p2xxy.params_p, &i_pf), ty_p2: crate::prelude::or(&crate::prelude::index(&ptys_p5xy, &i_pf), &crate::check::types::Ty::TyErr), mode_p3: crate::lower::types::Holding::ByRef, fresh_p4: crate::prelude::Text::from(format!("c{}", &i_pf)) }))
                    }
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::patterns::PatOut>>>
        }), move |each_60816: crate::prelude::Array<crate::lower::patterns::PatOut>| {
            let pos_p7 = each_60816;
            let binds_p8 = crate::prelude::fold(&pos_p7, &crate::prelude::Map::new(), &(|m_pg: &crate::prelude::Map<crate::prelude::Text, crate::lower::types::Bn>, o_ph: &crate::lower::patterns::PatOut| crate::prelude::fold(&o_ph.binds_p, m_pg, &(|m2_pi: &crate::prelude::Map<crate::prelude::Text, crate::lower::types::Bn>, (n_pj, b_pk): &(crate::prelude::Text, crate::lower::types::Bn)| crate::prelude::insert(m2_pi, n_pj, b_pk)))));
            crate::prelude::call_value(crate::prelude::fold_job(c_p2x.params_p.clone(), crate::prelude::Array::new(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>, crate::syntax::Pattern)| crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_pl = p0;
                let p_pm = p1;
                crate::prelude::call_then(crate::check::env::names::start_pattern_binders_f(p_pm.clone()), move |pattern_binders_f_61137: crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_pl, &pattern_binders_f_61137)))
            }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>, crate::syntax::Pattern)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>>>>), move |fold_61093: crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>| {
                let named_p9 = fold_61093;
                let binders_pa = crate::prelude::filter(&named_p9, &(|(bn_pn, _): &(crate::prelude::Text, crate::syntax::Range)| crate::check::env::has_key_f(&binds_p8, bn_pn)));
                let passed_pb = crate::prelude::each(&binders_pa, &(|(bn_po, _): &(crate::prelude::Text, crate::syntax::Range)| match crate::prelude::get(&binds_p8, bn_po) {
                    ::std::option::Option::Some(crate::lower::types::Bn::BnLocal(rs_pp, mode_pq, bt_pr)) => crate::lower::types::own_f(&crate::lower::types::Vl::VlPlace(rs_pp, mode_pq, bt_pr)),
                    _ => crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::lower::snake_f(bn_po)))),
                }));
                let handed_pc = crate::prelude::each(&live_p6, &(|i_ps: &crate::prelude::Nat| crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::from(format!("live{}", i_ps)))))));
                ::prism_rtl::Turn::Finished((row_name_p3x.clone(), crate::lower::model::Pa::PaTuple(crate::prelude::each(&pos_p7, &(|o_pt: &crate::lower::patterns::PatOut| o_pt.pa_p.clone()))), crate::prelude::fold(&pos_p7, &crate::prelude::Array::new(), &(|acc_pu: &crate::prelude::Array<crate::lower::model::Cc>, o_pv: &crate::lower::patterns::PatOut| crate::prelude::append(acc_pu, &o_pv.conds_p))), crate::prelude::push(&crate::prelude::append(&passed_pb, &handed_pc), &crate::lower::model::Ex::XVar(crate::prelude::Text::lit("row_base")))))
            })
        })
    }
}

/// `Start SharedCaseOf, x`: what the function value is when passed to `@Run`.
pub fn start_shared_case_of_f(lx_p0: crate::lower::Lx, v_p1: crate::check::env::ValInfo, c_p2: crate::syntax::decls::FnClause, row_name_p3: crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Text, crate::lower::model::Pa, crate::prelude::Array<crate::lower::model::Cc>, crate::prelude::Array<crate::lower::model::Ex>)>> {
    ::std::rc::Rc::new(SharedCaseOf { lx_p0, v_p1, c_p2, row_name_p3 })
}

/// ```prism
/// IsBlueprintParam: fn Ty -> Bool
/// ```
pub fn is_blueprint_param_f(pt_p0: &crate::check::types::Ty) -> bool {
    (&crate::lower::types::layer_of_f(pt_p0) == &crate::lower::types::Layer::LyBlueprint) || crate::lower::node_::static_::is_widget_fn_ty_f(pt_p0)
}

/// ```prism
/// ClauseScrutinee: unbounded fn Lx, Env, ValInfo, [Arg] -> Ex
/// ```
pub fn clause_scrutinee_f(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, v_p2: &crate::check::env::ValInfo, args_p3: &crate::prelude::Array<crate::syntax::Arg>) -> crate::lower::model::Ex {
    let ptys_p4 = match &v_p2.scheme_p.ty_p {
        crate::check::types::Ty::TyFn(_, ps_p5, _) => ps_p5.clone(),
        _ => crate::prelude::Array::new(),
    };
    crate::lower::model::Ex::XTuple(crate::prelude::run_to_end(crate::prelude::each_job(crate::check::errors::range0_f(&crate::prelude::len(args_p3)), {
        let lx_p0x = lx_p0.clone();
        let env_p1x = env_p1.clone();
        let ptys_p4x = ptys_p4.clone();
        let args_p3x = args_p3.clone();
        ::std::rc::Rc::new(move |p0: crate::prelude::Nat| {
            let lx_p0xy = lx_p0x.clone();
            let env_p1xy = env_p1x.clone();
            let ptys_p4xy = ptys_p4x.clone();
            let args_p3xy = args_p3x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let i_p6 = p0;
                ::prism_rtl::Turn::Finished(clause_argument_f(&lx_p0xy, &env_p1xy, &crate::prelude::index(&ptys_p4xy, &i_p6), &crate::prelude::index(&args_p3xy, &i_p6)))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>>>
    })))
}

/// ```prism
/// ClauseArgument: unbounded fn Lx, Env, ?Ty, ?Arg -> Ex
/// ```
pub fn clause_argument_f(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, pt_o2: &::std::option::Option<crate::check::types::Ty>, a_o3: &::std::option::Option<crate::syntax::Arg>) -> crate::lower::model::Ex {
    match (pt_o2.clone(), a_o3.clone()) {
        (::std::option::Option::Some(pt_p4), ::std::option::Option::Some(a_p5)) if is_blueprint_param_f(&pt_p4) => crate::lower::model::Ex::XUnit,
        (_, ::std::option::Option::Some(a_p6)) => crate::lower::expr::argument_f(lx_p0, env_p1, &a_p6.value_p),
        _ => crate::lower::model::Ex::XUnit,
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// ClauseDynArg: unbounded fn Wx, Env, Expr, OutTy -> ((Bn, Wx))
/// ```
pub fn clause_dyn_arg_f(wx_p0: &crate::lower::node_::Wx, menv_p1: &crate::lower::types::Env, x_p2: &crate::syntax::Expr, t_p3: &crate::lower::model::OutTy) -> (crate::lower::types::Bn, crate::lower::node_::Wx) {
    let (ex_p5, reads_p6) = crate::lower::node_::dynamics::dynamic_expr_f(wx_p0, menv_p1, x_p2);
    let ok_p4 = on_self_rooted_f(&ex_p5) && crate::prelude::fold(&reads_p6, &true, &(|f_p7: &bool, r_p8: &crate::lower::node_::Read| *f_p7 && crate::lower::node_::finish::is_own_read_f(r_p8)));
    if ok_p4 {
        (crate::lower::types::Bn::BnDyn(over_parent_f(&ex_p5), crate::prelude::each(&reads_p6, &(|r_p9: &crate::lower::node_::Read| as_parent_read_f(r_p9))), t_p3.clone()), wx_p0.clone())
    } else {
        {
            let (getter_pb, w1_pc) = crate::lower::node_::fresh_name_f(wx_p0, &crate::prelude::Text::lit("clause_dynamic"));
            let w2_pa = {
                let mut this: crate::lower::node_::Wx = w1_pc.clone();
                this.getters_p = crate::prelude::push(&this.getters_p, &crate::lower::model::MethDef { name_p: getter_pb.clone(), recv_p: crate::lower::model::Recv::RecvRef, params_p: crate::prelude::Array::new(), cx_p: crate::lower::model::CxArg::CxRef, ret_p: t_p3.clone(), body_p: crate::prelude::Array::new(), tail_p: ex_p5.clone(), doc_p: crate::prelude::Text::lit("A dynamic argument of a widget of several clauses, as its row reads it through this node.") });
                this.dyn_reads_p = crate::prelude::insert(&this.dyn_reads_p, &getter_pb, &reads_p6);
                this
            };
            (crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(parent_ref_p()), getter_pb.clone(), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx])), crate::prelude::Array::from(vec![crate::lower::node_::Read::ParentRead(getter_pb.clone())]), t_p3.clone()), w2_pa.clone())
        }
    }
}

/// The step machine of `ClauseDynArg`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ClauseDynArg: unbounded fn Wx, Env, Expr, OutTy -> ((Bn, Wx))
/// ```
pub struct ClauseDynArg {
    pub wx_p0: crate::lower::node_::Wx,
    pub menv_p1: crate::lower::types::Env,
    pub x_p2: crate::syntax::Expr,
    pub t_p3: crate::lower::model::OutTy,
}

impl ::prism_rtl::Job<(crate::lower::types::Bn, crate::lower::node_::Wx)> for ClauseDynArg {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::lower::types::Bn, crate::lower::node_::Wx)> {
        let wx_p0 = &self.wx_p0;
        let menv_p1 = &self.menv_p1;
        let x_p2 = &self.x_p2;
        let t_p3 = &self.t_p3;
        let menv_p1x = menv_p1.clone();
        let t_p3x = t_p3.clone();
        let wx_p0x = wx_p0.clone();
        let x_p2x = x_p2.clone();
        crate::prelude::call_then(crate::lower::node_::dynamics::start_dynamic_expr_f(wx_p0x.clone(), menv_p1x.clone(), x_p2x.clone()), move |dynamic_expr_f_63097: (crate::lower::model::Ex, crate::prelude::Array<crate::lower::node_::Read>)| {
            let (ex_p5, reads_p6) = dynamic_expr_f_63097;
            let ok_p4 = on_self_rooted_f(&ex_p5) && crate::prelude::fold(&reads_p6, &true, &(|f_p7: &bool, r_p8: &crate::lower::node_::Read| *f_p7 && crate::lower::node_::finish::is_own_read_f(r_p8)));
            if ok_p4 {
                ::prism_rtl::Turn::Finished((crate::lower::types::Bn::BnDyn(over_parent_f(&ex_p5), crate::prelude::each(&reads_p6, &(|r_p9: &crate::lower::node_::Read| as_parent_read_f(r_p9))), t_p3x.clone()), wx_p0x.clone()))
            } else {
                {
                    let (getter_pb, w1_pc) = crate::lower::node_::fresh_name_f(&wx_p0x, &crate::prelude::Text::lit("clause_dynamic"));
                    let w2_pa = {
                        let mut this: crate::lower::node_::Wx = w1_pc.clone();
                        this.getters_p = crate::prelude::push(&this.getters_p, &crate::lower::model::MethDef { name_p: getter_pb.clone(), recv_p: crate::lower::model::Recv::RecvRef, params_p: crate::prelude::Array::new(), cx_p: crate::lower::model::CxArg::CxRef, ret_p: t_p3x.clone(), body_p: crate::prelude::Array::new(), tail_p: ex_p5.clone(), doc_p: crate::prelude::Text::lit("A dynamic argument of a widget of several clauses, as its row reads it through this node.") });
                        this.dyn_reads_p = crate::prelude::insert(&this.dyn_reads_p, &getter_pb, &reads_p6);
                        this
                    };
                    ::prism_rtl::Turn::Finished((crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(parent_ref_p()), getter_pb.clone(), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx])), crate::prelude::Array::from(vec![crate::lower::node_::Read::ParentRead(getter_pb.clone())]), t_p3x.clone()), w2_pa.clone()))
                }
            }
        })
    }
}

/// `Start ClauseDynArg, x`: what the function value is when passed to `@Run`.
pub fn start_clause_dyn_arg_f(wx_p0: crate::lower::node_::Wx, menv_p1: crate::lower::types::Env, x_p2: crate::syntax::Expr, t_p3: crate::lower::model::OutTy) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::types::Bn, crate::lower::node_::Wx)>> {
    ::std::rc::Rc::new(ClauseDynArg { wx_p0, menv_p1, x_p2, t_p3 })
}

/// ```prism
/// AsParentRead: fn Read -> Read
/// ```
pub fn as_parent_read_f(read0: &crate::lower::node_::Read) -> crate::lower::node_::Read {
    match read0 {
        crate::lower::node_::Read::OwnRead(m_p0) => crate::lower::node_::Read::ParentRead(m_p0.clone()),
        crate::lower::node_::Read::ParentRead(m_p1) => crate::lower::node_::Read::ParentRead(m_p1.clone()),
    }
}

/// ```prism
/// OnSelfRooted: fn Ex -> Bool
/// ```
pub fn on_self_rooted_f(x_p0: &crate::lower::model::Ex) -> bool {
    match x_p0 {
        crate::lower::model::Ex::XSelf => true,
        crate::lower::model::Ex::XField(y_p1, _) => on_self_rooted_f(&**y_p1),
        crate::lower::model::Ex::XFieldOf(y_p2, _, _) => on_self_rooted_f(&**y_p2),
        crate::lower::model::Ex::XPart(y_p3, _) => on_self_rooted_f(&**y_p3),
        crate::lower::model::Ex::XMethod(y_p4, _, _) => on_self_rooted_f(&**y_p4),
        _ => false,
    }
}

/// ```prism
/// ArmRowOf: unbounded fn Wx, Env, Lx, [?Pattern], [Ty], ?Expr, Block, Text, Text, Bool, Bool, OutTy, [((Text, Bn))], [((Text, Text))], [((Text, Expr))], Bool -> ClauseRow
/// ```
pub fn arm_row_of_f(wx_p0: &crate::lower::node_::Wx, menv_p1: &crate::lower::types::Env, lxc_p2: &crate::lower::Lx, pats_p3: &crate::prelude::Array<::std::option::Option<crate::syntax::Pattern>>, ptys_p4: &crate::prelude::Array<crate::check::types::Ty>, guard_o5: &::std::option::Option<crate::syntax::Expr>, body_p6: &crate::syntax::Block, row_name_p7: &crate::prelude::Text, gen_name_p8: &crate::prelude::Text, transparent_p9: &bool, reads_block_pa: &bool, parent_ty_pb: &crate::lower::model::OutTy, dyns_given_pc: &crate::prelude::Array<(crate::prelude::Text, crate::lower::types::Bn)>, ups_pd: &crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text)>, widgets_pe: &crate::prelude::Array<(crate::prelude::Text, crate::syntax::Expr)>, zero_based_pf: &bool) -> ClauseRow {
    let up_name_pg = crate::prelude::Text::from(format!("{}_up", gen_name_p8));
    let pos_ph = crate::prelude::run_to_end(crate::prelude::each_job(crate::check::errors::range0_f(&crate::prelude::len(pats_p3)), {
        let lxc_p2x = lxc_p2.clone();
        let pats_p3x = pats_p3.clone();
        let ptys_p4x = ptys_p4.clone();
        ::std::rc::Rc::new(move |p0: crate::prelude::Nat| {
            let lxc_p2xy = lxc_p2x.clone();
            let pats_p3xy = pats_p3x.clone();
            let ptys_p4xy = ptys_p4x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let i_p1u = p0;
                ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::lower::expr::ArmPat { lx_p0: lxc_p2xy.clone(), opt1: crate::prelude::or(&crate::prelude::index(&pats_p3xy, &i_p1u), &::std::option::Option::None), ty_p2: crate::prelude::or(&crate::prelude::index(&ptys_p4xy, &i_p1u), &crate::check::types::Ty::TyErr), mode_p3: crate::lower::types::Holding::ByRef, fresh_p4: crate::prelude::Text::from(format!("c{}", &i_p1u)) }))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::patterns::PatOut>>>
    }));
    let pa_pi = crate::lower::model::Pa::PaTuple(crate::prelude::each(&pos_ph, &(|o_p1v: &crate::lower::patterns::PatOut| o_p1v.pa_p.clone())));
    let binds_pj = crate::prelude::fold(&pos_ph, &crate::prelude::Map::new(), &(|m_p20: &crate::prelude::Map<crate::prelude::Text, crate::lower::types::Bn>, o_p21: &crate::lower::patterns::PatOut| crate::prelude::fold(&o_p21.binds_p, m_p20, &(|m2_p22: &crate::prelude::Map<crate::prelude::Text, crate::lower::types::Bn>, (n_p23, b_p24): &(crate::prelude::Text, crate::lower::types::Bn)| crate::prelude::insert(m2_p22, n_p23, b_p24)))));
    let guard_conds_pk = match guard_o5 {
        ::std::option::Option::Some(g_p25) => crate::prelude::Array::from(vec![crate::lower::model::Cc::CcIf(crate::lower::types::as_bool_f(&crate::lower::expr::value_of_f(lxc_p2, &crate::lower::expr::bind_all_f(menv_p1, &crate::prelude::fold(&pos_ph, &crate::prelude::Array::new(), &(|acc_p26: &crate::prelude::Array<(crate::prelude::Text, crate::lower::types::Bn)>, o_p27: &crate::lower::patterns::PatOut| crate::prelude::append(acc_p26, &o_p27.binds_p)))), g_p25)))]),
        ::std::option::Option::None => crate::prelude::Array::new(),
    };
    let named_pl = crate::prelude::run_to_end(crate::prelude::fold_job(pats_p3.clone(), crate::prelude::Array::new(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>, ::std::option::Option<crate::syntax::Pattern>)| crate::prelude::entered(crate::prelude::once_job(move || {
        let acc_p28 = p0;
        let p_o29 = p1;
        crate::prelude::call_then(start_opt_binders_f(p_o29.clone()), move |opt_binders_f_66150: crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_p28, &opt_binders_f_66150)))
    }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>, ::std::option::Option<crate::syntax::Pattern>)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>>>>));
    let lives_pm = if *zero_based_pf && (parent_ty_pb == &crate::lower::model::OutTy::OutUnit) {
        dyns_given_pc.clone()
    } else {
        crate::prelude::Array::new()
    };
    let dyns_pn = if *zero_based_pf && (parent_ty_pb == &crate::lower::model::OutTy::OutUnit) {
        crate::prelude::Array::new()
    } else {
        dyns_given_pc.clone()
    };
    let dyn_names_po = crate::prelude::append(&crate::prelude::each(&dyns_pn, &(|(n_p2a, _): &(crate::prelude::Text, crate::lower::types::Bn)| n_p2a.clone())), &crate::prelude::each(widgets_pe, &(|(n_p2b, _): &(crate::prelude::Text, crate::syntax::Expr)| n_p2b.clone())));
    let binders_pp = crate::prelude::filter(&named_pl, &(|(bn_p2c, _): &(crate::prelude::Text, crate::syntax::Range)| crate::check::env::has_key_f(&binds_pj, bn_p2c) && !crate::check::types::has_text_f(&dyn_names_po, bn_p2c)));
    let fields_pq = crate::prelude::run_to_end(crate::prelude::each_job(binders_pp.clone(), {
        let lxc_p2x = lxc_p2.clone();
        ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::syntax::Range)| {
            let lxc_p2xy = lxc_p2x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (bn_p2d, r_p2e) = p0;
                crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lxc_p2xy.clone(), crate::lower::types::peel_f(&crate::lower::binder_ty_f(&lxc_p2xy, &r_p2e))), move |out_ty_of_f_66651: crate::lower::model::OutTy| ::prism_rtl::Turn::Finished((crate::lower::snake_f(&bn_p2d), out_ty_of_f_66651, bn_p2d.clone())))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::syntax::Range)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Text, crate::lower::model::OutTy, crate::prelude::Text)>>>
    }));
    let weak_late_pr = (((*transparent_p9 && !*zero_based_pf) && is_weak_ty_f(parent_ty_pb)) && wx_p0.late_gens_p) && (&wx_p0.pos_p.scope_p == &crate::prelude::Nat::from(0u32));
    let numbered_late_ps = weak_late_pr || (((*transparent_p9 && !*zero_based_pf) && is_link_ty_f(parent_ty_pb)) && crate::lower::node_::finish::numbered_late_f(wx_p0, &wx_p0.pos_p));
    let base_field_pt = if numbered_late_ps {
        crate::prelude::Array::from(vec![(crate::prelude::Text::lit("base"), crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Cell")), crate::prelude::Array::from(vec![crate::lower::model::OutTy::OutCount])), crate::prelude::Text::lit("where the row\'s first position stands as built, set when the row is numbered")), (crate::prelude::Text::lit("number_later"), crate::lower::model::OutTy::OutCell(::std::rc::Rc::new(crate::lower::model::OutTy::OutOpt(::std::rc::Rc::new(crate::lower::node_::finish::later_ty_p())))), crate::prelude::Text::lit("what the row\'s build does once it is numbered"))])
    } else {
        if *transparent_p9 {
            crate::prelude::Array::from(vec![(crate::prelude::Text::lit("base"), crate::lower::model::OutTy::OutCount, crate::prelude::Text::lit("where the row\'s first position stands as built"))])
        } else {
            crate::prelude::Array::new()
        }
    };
    let row_fields_pu = crate::prelude::append(&crate::prelude::push(&crate::prelude::each(&fields_pq, &(|(f_p2f, t_p2g, bn_p2h): &(crate::prelude::Text, crate::lower::model::OutTy, crate::prelude::Text)| (f_p2f.clone(), t_p2g.clone(), crate::prelude::Text::from(format!("`{}`", bn_p2h))))), &(crate::prelude::Text::lit("parent"), parent_ty_pb.clone(), crate::prelude::Text::lit("the node of the `rebuild`"))), &base_field_pt);
    let row_inits_pv = crate::prelude::append(&crate::prelude::each(&fields_pq, &(|(f_p2i, _, _): &(crate::prelude::Text, crate::lower::model::OutTy, crate::prelude::Text)| (f_p2i.clone(), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(f_p2i.clone())))))), &(if numbered_late_ps {
        crate::prelude::Array::from(vec![(crate::prelude::Text::lit("base"), crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Cell::new")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XIndex(crate::prelude::Nat::from(0u32))]))), (crate::prelude::Text::lit("number_later"), crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::RefCell::new")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XNone])))])
    } else {
        if *transparent_p9 {
            crate::prelude::Array::from(vec![(crate::prelude::Text::lit("base"), crate::lower::model::Ex::XVar(crate::prelude::Text::lit("base")))])
        } else {
            crate::prelude::Array::new()
        }
    }));
    let row_taken_p10 = crate::prelude::append(&crate::prelude::append(&crate::lower::node_::node_hooks_p(), &crate::prelude::push(&crate::prelude::push(&crate::prelude::each(&fields_pq, &(|(f_p2j, _, _): &(crate::prelude::Text, crate::lower::model::OutTy, crate::prelude::Text)| f_p2j.clone())), &crate::prelude::Text::lit("parent")), &crate::prelude::Text::lit("result_value"))), &crate::prelude::Array::from(vec![crate::prelude::Text::lit("base"), crate::prelude::Text::lit("place"), crate::prelude::Text::lit("seat"), crate::prelude::Text::lit("inner_gap"), crate::prelude::Text::lit("number_later"), crate::prelude::Text::lit("number_places"), crate::prelude::Text::lit("number"), crate::prelude::Text::lit("numbered")]));
    let hosted_rows_o11 = match &wx_p0.valued_as_o {
        ::std::option::Option::Some(true) => ::std::option::Option::Some(shared_moved_p()),
        ::std::option::Option::Some(false) => ::std::option::Option::None,
        ::std::option::Option::None => crate::lower::node_::finish::hosted_rows_o(wx_p0),
    };
    let shared_p12 = (*zero_based_pf && (parent_ty_pb == &crate::lower::model::OutTy::OutUnit)) || match &wx_p0.valued_as_o {
        ::std::option::Option::Some(hosted_p2k) => *hosted_p2k,
        ::std::option::Option::None => false,
    };
    let hosted_by_o13 = match &hosted_rows_o11 {
        ::std::option::Option::Some(m_p2l) => if shared_p12 {
            ::std::option::Option::Some(shared_moved_p())
        } else {
            ::std::option::Option::Some(m_p2l.clone())
        },
        ::std::option::Option::None => ::std::option::Option::None,
    };
    let hosted_params_p14 = match &hosted_rows_o11 {
        ::std::option::Option::Some(_) => crate::prelude::Array::from(vec![(crate::prelude::Text::lit("enclosing"), crate::lower::types::host_of_ty_p())]),
        ::std::option::Option::None => crate::prelude::Array::new(),
    };
    let moved_param_p15 = if shared_p12 && is_some_f(&hosted_by_o13) {
        crate::prelude::Array::from(vec![(crate::prelude::Text::lit("moved"), moved_ty_p())])
    } else {
        crate::prelude::Array::new()
    };
    let row_fresh_p16 = crate::lower::node_::new_wx_f(lxc_p2, row_name_p7, &row_fields_pu, &row_inits_pv, &crate::prelude::Array::from(vec![(crate::prelude::Text::lit("parent"), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("parent")))))]), &crate::prelude::Array::new(), &crate::prelude::Map::new(), &row_taken_p10, &wx_p0.inlining_p, &hosted_by_o13);
    let r0000_p17 = if *zero_based_pf {
        crate::lower::node_::under_its_path_f(&row_fresh_p16, &hosted_by_o13)
    } else {
        row_fresh_p16.clone()
    };
    let r000_p18 = {
        let mut this: crate::lower::node_::Wx = r0000_p17.clone();
        this.base_late_p = numbered_late_ps;
        this.late_gens_p = numbered_late_ps && (wx_p0.late_gens_p || crate::lower::node_::def::is_late_block_f(lxc_p2, &(if *reads_block_pa { menv_p1.clone() } else { crate::lower::types::empty_env_p() }), body_p6, &crate::prelude::Nat::from(16u32)));
        this.numbered_by_p = if weak_late_pr {
            crate::prelude::Array::from(vec![numbered_by_parent_f(wx_p0, &wx_p0.pos_p, gen_name_p8)])
        } else {
            crate::prelude::Array::new()
        };
        this
    };
    let r00_p19 = if &crate::prelude::len(&moved_param_p15) == &crate::prelude::Nat::from(0u32) {
        r000_p18.clone()
    } else {
        {
            let mut this: crate::lower::node_::Wx = r000_p18.clone();
            this.taken_p = crate::prelude::push(&this.taken_p, &crate::prelude::Text::lit("moved"));
            this.fields_p = crate::prelude::push(&this.fields_p, &(crate::prelude::Text::lit("moved"), moved_ty_p(), crate::prelude::Text::lit("what tells the row\'s host that a place of the row\'s may have moved")));
            this.inits_p = crate::prelude::push(&this.inits_p, &(crate::prelude::Text::lit("moved"), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("moved"))))));
            this
        }
    };
    let first_p1a = if *zero_based_pf { crate::prelude::Nat::from(0u32) } else { wx_p0.pos_p.at_p.clone() };
    let r0p_p1b = if *transparent_p9 {
        {
            let mut this: crate::lower::node_::Wx = r00_p19.clone();
            this.pos_p = crate::lower::model::Pos { scope_p: crate::prelude::Nat::from(0u32), at_p: first_p1a.clone() };
            this
        }
    } else {
        r00_p19.clone()
    };
    let r0b_p1c = if *transparent_p9 {
        {
            let mut this: crate::lower::node_::Wx = r0p_p1b.clone();
            this.based_o = ::std::option::Option::Some(first_p1a.clone());
            this
        }
    } else {
        r0p_p1b.clone()
    };
    let (r0_p2m, live_be_p2n, live_me_p2o, live_params_p2p) = live_params_f(&r0b_p1c, &lives_pm);
    let (p1a_p2q, r1a_p2r, ports_p2s) = if *reads_block_pa {
        row_env_f(wx_p0, &r0_p2m, menv_p1, body_p6)
    } else {
        (wx_p0.clone(), r0_p2m.clone(), crate::lower::types::empty_env_p())
    };
    let (p1_p35, r1_p36, widget_env_p37) = crate::prelude::run_to_end(crate::prelude::fold_job(widgets_pe.clone(), (p1a_p2q.clone(), r1a_p2r.clone(), crate::lower::types::empty_env_p()), {
        let menv_p1x = menv_p1.clone();
        let wx_p0x = wx_p0.clone();
        ::std::rc::Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::node_::Wx, crate::lower::types::Env), (crate::prelude::Text, crate::syntax::Expr))| {
            let menv_p1xy = menv_p1x.clone();
            let wx_p0xy = wx_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (p_p2t, r_p2u, en_p2v) = p0;
                let (bn_p30, x_p31) = p1;
                crate::prelude::call_then(crate::check::typed::print::start_exprs_in_f(x_p31.clone()), move |exprs_in_f_71339: crate::prelude::Array<crate::syntax::Expr>| crate::prelude::call_then(crate::lower::expr::start_read_names_f(exprs_in_f_71339), move |read_names_f_71328: crate::prelude::Array<crate::prelude::Text>| crate::prelude::call_then(start_row_env_names_f(p_p2t.clone(), r_p2u.clone(), menv_p1xy.clone(), read_names_f_71328), move |row_env_names_f_71303: (crate::lower::node_::Wx, crate::lower::node_::Wx, crate::lower::types::Env)| {
                    let (p2_p32, r2_p33, inner_p34) = row_env_names_f_71303;
                    crate::prelude::call_then(start_build_spelling_f(inner_p34.clone()), move |build_spelling_f_71397: crate::lower::types::Env| ::prism_rtl::Turn::Finished((p2_p32.clone(), r2_p33.clone(), crate::lower::types::bind_f(&en_p2v, &bn_p30, &crate::lower::types::Bn::BnWidget(x_p31.clone(), build_spelling_f_71397, inner_p34.clone(), wx_p0xy.lx_p.clone())))))
                })))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::lower::node_::Wx, crate::lower::node_::Wx, crate::lower::types::Env), (crate::prelude::Text, crate::syntax::Expr))) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::node_::Wx, crate::lower::types::Env)>>>
    }));
    let (be0_p3d, me0_p3e) = crate::prelude::fold(&fields_pq, &(crate::lower::types::empty_env_p(), crate::lower::types::empty_env_p()), &(|(b_p38, m_p39): &(crate::lower::types::Env, crate::lower::types::Env), (f_p3a, t_p3b, bn_p3c): &(crate::prelude::Text, crate::lower::model::OutTy, crate::prelude::Text)| crate::lower::node_::bind_plain_f(b_p38, m_p39, bn_p3c, f_p3a, t_p3b)));
    let dyn_env_p1d = crate::lower::expr::bind_all_f(&crate::lower::types::empty_env_p(), &dyns_pn);
    let me_p1e = over_env_f(&over_env_f(&over_env_f(&me0_p3e, &dyn_env_p1d), &live_me_p2o), &widget_env_p37);
    let be_p1f = over_env_f(&over_env_f(&over_env_f(&be0_p3d, &build_spelling_f(&dyn_env_p1d)), &live_be_p2n), &widget_env_p37);
    let r2u_p1g = if *reads_block_pa {
        crate::lower::node_::def::block_into_f(&r1_p36, &over_env_f(&build_spelling_f(&ports_p2s), &be_p1f), &over_env_f(&ports_p2s, &me_p1e), body_p6)
    } else {
        crate::lower::node_::def::block_into_f(&r1_p36, &be_p1f, &me_p1e, body_p6)
    };
    let r2_p1h = crate::prelude::fold(ups_pd, &r2u_p1g, &(|r_p3f: &crate::lower::node_::Wx, (mine_p3g, blocks_p3h): &(crate::prelude::Text, crate::prelude::Text)| match crate::prelude::index(&crate::prelude::filter(&r_p3f.gns_p, &(|g_p3i: &crate::lower::node_::Gn| (&g_p3i.name_p == mine_p3g) && (&g_p3i.kind_p == &crate::lower::node_::GnKind::GnNamed))), &crate::prelude::Nat::from(0u32)) {
        ::std::option::Option::Some(g_p3j) => crate::lower::node_::connect_f(r_p3f, &crate::lower::node_::ev_ref_of_f(r_p3f, &g_p3j.id_p), &crate::lower::node_::Sk::SkUp(blocks_p3h.clone())),
        ::std::option::Option::None => {
            let mut this: crate::lower::node_::Wx = r_p3f.clone();
            this.build_p = crate::prelude::push(&this.build_p, &crate::lower::expr::internal_bug_do_f(&crate::prelude::Text::from(format!("the event `{}` of a split block\'s lower lines has no node in their row", mine_p3g))));
            this
        },
    }));
    let value_row_p1i = (*zero_based_pf && (parent_ty_pb == &crate::lower::model::OutTy::OutUnit)) || is_some_f(&wx_p0.valued_as_o);
    let (r2b_p3l, parts_p3m) = match &r2_p1h.result_p {
        crate::lower::node_::Wres::WrParts(ps_p3k) if !value_row_p1i => row_parts_out_f(&r2_p1h, gen_name_p8, &crate::prelude::Text::lit(""), ps_p3k),
        _ => (r2_p1h.clone(), crate::prelude::Array::new()),
        _ => unreachable!("no arm matched"),
    };
    let (r3_p42, plain_o43) = match &r2_p1h.result_p {
        crate::lower::node_::Wres::WrEv(r_p3n) => if value_row_p1i {
            (valued_event_result_f(&r2_p1h, r_p3n, &block_gives_f(lxc_p2, body_p6)), ::std::option::Option::None)
        } else {
            (crate::lower::node_::connect_f(&r2_p1h, r_p3n, &crate::lower::node_::Sk::SkUp(up_name_pg.clone())), ::std::option::Option::None)
        },
        crate::lower::node_::Wres::WrParts(_) if value_row_p1i => value_row_result_f(&r2_p1h, lxc_p2, body_p6),
        crate::lower::node_::Wres::WrDyn(_, _, _) if value_row_p1i => value_row_result_f(&r2_p1h, lxc_p2, body_p6),
        crate::lower::node_::Wres::WrHosted(_, _) if value_row_p1i => value_row_result_f(&r2_p1h, lxc_p2, body_p6),
        crate::lower::node_::Wres::WrParts(_) => (r2b_p3l.clone(), ::std::option::Option::None),
        crate::lower::node_::Wres::WrPlain(ex_p3o, rt_p3p) => {
            let (f_p3r, rf_p3s) = crate::lower::node_::fresh_name_f(&r2_p1h, &crate::prelude::Text::lit("result"));
            let r2p_p3q = {
                let mut this: crate::lower::node_::Wx = rf_p3s.clone();
                this.lets_p = crate::prelude::push(&this.lets_p, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaBind(f_p3r.clone())), rt_p3p.clone()), ex_p3o.clone()));
                this.fields_p = crate::prelude::push(&this.fields_p, &(f_p3r.clone(), rt_p3p.clone(), crate::prelude::Text::lit("the clause\'s plain result")));
                this.inits_p = crate::prelude::push(&this.inits_p, &(f_p3r.clone(), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(f_p3r.clone())))));
                this.getters_p = crate::prelude::push(&this.getters_p, &crate::lower::model::MethDef { name_p: crate::prelude::Text::lit("result_value"), recv_p: crate::lower::model::Recv::RecvRef, params_p: crate::prelude::Array::new(), cx_p: crate::lower::model::CxArg::CxNone, ret_p: rt_p3p.clone(), body_p: crate::prelude::Array::new(), tail_p: crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), f_p3r.clone()))), doc_p: crate::prelude::Text::lit("The clause\'s plain result, which the block that built the generation reads.") });
                this
            };
            (r2p_p3q.clone(), ::std::option::Option::Some(rt_p3p.clone()))
        },
        crate::lower::node_::Wres::WrLate(ex_p3t, rt_p3u) => ({
            let mut this: crate::lower::node_::Wx = r2_p1h.clone();
            this.getters_p = crate::prelude::push(&this.getters_p, &crate::lower::model::MethDef { name_p: crate::prelude::Text::lit("result_value"), recv_p: crate::lower::model::Recv::RecvRef, params_p: crate::prelude::Array::new(), cx_p: crate::lower::model::CxArg::CxNone, ret_p: rt_p3u.clone(), body_p: crate::prelude::Array::new(), tail_p: if numbered_late_ps && !(r2_p1h.late_gens_p && (&crate::prelude::len(&unnumbered_steps_f(&r2_p1h)) == &crate::prelude::Nat::from(0u32))) {
                crate::lower::expr::refusal_f(&crate::prelude::Text::lit("the plain result of an arm or a clause that is built before its block\'s node and numbered after it, read from a generation the arm builds after its own node whose rows take their numbers as they are built (a `for`, a `rebuild` or a widget that calls itself beside the building `match` whose result the arm gives)"))
            } else {
                ex_p3t.clone()
            }, doc_p: crate::prelude::Text::lit("The clause\'s plain result, which the block that built the generation reads.") });
            this
        }, ::std::option::Option::Some(rt_p3u.clone())),
        crate::lower::node_::Wres::WrDyn(ex_p3v, rds_p40, rt_p41) => (gen_result_f(&r2_p1h, gen_name_p8, ex_p3v, rds_p40, rt_p41), ::std::option::Option::None),
        _ => (r2_p1h.clone(), ::std::option::Option::None),
        _ => unreachable!("no arm matched"),
    };
    let base_param_p1j = if *transparent_p9 && !numbered_late_ps {
        crate::prelude::Array::from(vec![(crate::prelude::Text::lit("base"), crate::lower::model::OutTy::OutCount)])
    } else {
        crate::prelude::Array::new()
    };
    let r3n_p1k = if r3_p42.late_gens_p && (&crate::prelude::len(&crate::prelude::filter(&unnumbered_steps_f(&r3_p42), &(|counted_p44: &bool| *counted_p44))) > &crate::prelude::Nat::from(0u32)) {
        {
            let mut this: crate::lower::node_::Wx = r3_p42.clone();
            this.build_p = crate::prelude::push(&this.build_p, &crate::lower::expr::refusal_do_f(&crate::prelude::Text::lit("a widget that calls itself in an arm or a clause that is built before its block\'s node and numbered after it, beside a line whose plain result the arm gives or below a building `match` or `if` of that arm")));
            this
        }
    } else {
        r3_p42.clone()
    };
    let own_gaps_p1l = &crate::prelude::len(&crate::prelude::filter(&r3_p42.gens_p, &(|gd_p45: &crate::lower::model::GenDef| gd_p45.gappy_p && (&gd_p45.pos_p.scope_p == &crate::prelude::Nat::from(0u32))))) > &crate::prelude::Nat::from(0u32);
    let positions_p1m = crate::lower::model::Ex::XIndex(crate::prelude::or(&(&r2_p1h.pos_p.at_p).checked_sub(&r0_p2m.pos_p.at_p), &crate::prelude::Nat::from(0u32)));
    let r3b_p1n = if !*zero_based_pf {
        r3n_p1k.clone()
    } else {
        {
            let mut this: crate::lower::node_::Wx = r3n_p1k.clone();
            this.taken_p = crate::prelude::push(&this.taken_p, &crate::prelude::Text::lit("built"));
            this.getters_p = crate::prelude::push(&this.getters_p, &crate::lower::model::MethDef { name_p: crate::prelude::Text::lit("built"), recv_p: crate::lower::model::Recv::RecvRef, params_p: crate::prelude::Array::new(), cx_p: crate::lower::model::CxArg::CxNone, ret_p: crate::lower::model::OutTy::OutCount, body_p: crate::prelude::Array::new(), tail_p: if own_gaps_p1l {
                crate::lower::model::Ex::XBin(crate::lower::model::BinOp::OpSub, ::std::rc::Rc::new(positions_p1m.clone()), ::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::lit("inner_gap"), crate::prelude::Array::new())))
            } else {
                positions_p1m.clone()
            }, doc_p: crate::prelude::Text::lit("How many places the row built (ruling TC: places are counted as they are built).") });
            this
        }
    };
    let node_p1o = crate::lower::node_::finish::finish_node_f(&r3b_p1n, row_name_p7, &crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&crate::prelude::each(&fields_pq, &(|(f_p46, t_p47, _): &(crate::prelude::Text, crate::lower::model::OutTy, crate::prelude::Text)| (f_p46.clone(), t_p47.clone()))), &live_params_p2p), &base_param_p1j), &crate::prelude::append(&crate::prelude::append(&crate::prelude::Array::from(vec![(crate::prelude::Text::lit("parent"), parent_ty_pb.clone())]), &hosted_params_p14), &moved_param_p15)), &true);
    let p2m_p1p = gen_marked_f(&p1_p35, gen_name_p8, &r3b_p1n);
    let p2_p1q = if !weak_late_pr {
        p2m_p1p.clone()
    } else {
        {
            let mut this: crate::lower::node_::Wx = p2m_p1p.clone();
            this.late_row_gens_p = crate::check::types::add_text_f(&this.late_row_gens_p, gen_name_p8);
            this
        }
    };
    let passed0_p1r = crate::prelude::each(&fields_pq, &(|(f_p48, t_p49, bn_p4a): &(crate::prelude::Text, crate::lower::model::OutTy, crate::prelude::Text)| match crate::prelude::get(&binds_pj, bn_p4a) {
        ::std::option::Option::Some(crate::lower::types::Bn::BnLocal(rs_p4b, mode_p4c, bt_p4d)) => crate::lower::types::own_f(&crate::lower::types::Vl::VlPlace(rs_p4b, mode_p4c, bt_p4d)),
        _ => crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(f_p48.clone()))),
    }));
    let passed_p1s = if *transparent_p9 && !numbered_late_ps {
        crate::prelude::push(&passed0_p1r, &crate::lower::model::Ex::XVar(crate::prelude::Text::lit("row_base")))
    } else {
        passed0_p1r.clone()
    };
    let inner_p1t = &crate::prelude::len(&crate::prelude::filter(&r3_p42.gens_p, &(|gd_p4e: &crate::lower::model::GenDef| gd_p4e.gappy_p && (&gd_p4e.pos_p.scope_p == &crate::prelude::Nat::from(0u32))))) > &crate::prelude::Nat::from(0u32);
    ClauseRow { case_p: GenCase { node_p: node_p1o.clone(), params_p: crate::prelude::each(&fields_pq, &(|(f_p4f, t_p4g, _): &(crate::prelude::Text, crate::lower::model::OutTy, crate::prelude::Text)| (f_p4f.clone(), t_p4g.clone()))), pat_p: pa_pi.clone(), conds_p: crate::prelude::append(&crate::prelude::fold(&pos_ph, &crate::prelude::Array::new(), &(|acc_p4h: &crate::prelude::Array<crate::lower::model::Cc>, o_p4i: &crate::lower::patterns::PatOut| crate::prelude::append(acc_p4h, &o_p4i.conds_p))), &guard_conds_pk), passed_p: passed_p1s.clone() }, parent_p: p2_p1q.clone(), plain_o: plain_o43.clone(), result_reads_p: result_parent_reads_f(&r2_p1h), result_ty_o: result_dyn_ty_o(&r2_p1h), width_p: crate::prelude::or(&(&r2_p1h.pos_p.at_p).checked_sub(&r0_p2m.pos_p.at_p), &crate::prelude::Nat::from(0u32)), inner_p: inner_p1t, parts_p: parts_p3m.clone() }
}

/// The step machine of `ArmRowOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ArmRowOf: unbounded fn Wx, Env, Lx, [?Pattern], [Ty], ?Expr, Block, Text, Text, Bool, Bool, OutTy, [((Text, Bn))], [((Text, Text))], [((Text, Expr))], Bool -> ClauseRow
/// ```
pub struct ArmRowOf {
    pub wx_p0: crate::lower::node_::Wx,
    pub menv_p1: crate::lower::types::Env,
    pub lxc_p2: crate::lower::Lx,
    pub pats_p3: crate::prelude::Array<::std::option::Option<crate::syntax::Pattern>>,
    pub ptys_p4: crate::prelude::Array<crate::check::types::Ty>,
    pub guard_o5: ::std::option::Option<crate::syntax::Expr>,
    pub body_p6: crate::syntax::Block,
    pub row_name_p7: crate::prelude::Text,
    pub gen_name_p8: crate::prelude::Text,
    pub transparent_p9: bool,
    pub reads_block_pa: bool,
    pub parent_ty_pb: crate::lower::model::OutTy,
    pub dyns_given_pc: crate::prelude::Array<(crate::prelude::Text, crate::lower::types::Bn)>,
    pub ups_pd: crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text)>,
    pub widgets_pe: crate::prelude::Array<(crate::prelude::Text, crate::syntax::Expr)>,
    pub zero_based_pf: bool,
}

impl ::prism_rtl::Job<ClauseRow> for ArmRowOf {
    fn cycle(&self) -> ::prism_rtl::Turn<ClauseRow> {
        let wx_p0 = &self.wx_p0;
        let menv_p1 = &self.menv_p1;
        let lxc_p2 = &self.lxc_p2;
        let pats_p3 = &self.pats_p3;
        let ptys_p4 = &self.ptys_p4;
        let guard_o5 = &self.guard_o5;
        let body_p6 = &self.body_p6;
        let row_name_p7 = &self.row_name_p7;
        let gen_name_p8 = &self.gen_name_p8;
        let transparent_p9 = &self.transparent_p9;
        let reads_block_pa = &self.reads_block_pa;
        let parent_ty_pb = &self.parent_ty_pb;
        let dyns_given_pc = &self.dyns_given_pc;
        let ups_pd = &self.ups_pd;
        let widgets_pe = &self.widgets_pe;
        let zero_based_pf = &self.zero_based_pf;
        let up_name_pg = crate::prelude::Text::from(format!("{}_up", gen_name_p8));
        let guard_o5x = guard_o5.clone();
        let body_p6x = body_p6.clone();
        let dyns_given_pcx = dyns_given_pc.clone();
        let gen_name_p8x = gen_name_p8.clone();
        let lxc_p2x = lxc_p2.clone();
        let menv_p1x = menv_p1.clone();
        let parent_ty_pbx = parent_ty_pb.clone();
        let pats_p3x = pats_p3.clone();
        let ptys_p4x = ptys_p4.clone();
        let reads_block_pax = *reads_block_pa;
        let row_name_p7x = row_name_p7.clone();
        let transparent_p9x = *transparent_p9;
        let ups_pdx = ups_pd.clone();
        let widgets_pex = widgets_pe.clone();
        let wx_p0x = wx_p0.clone();
        let zero_based_pfx = *zero_based_pf;
        crate::prelude::call_value(crate::prelude::each_job(crate::check::errors::range0_f(&crate::prelude::len(&pats_p3x)), {
            let lxc_p2xx = lxc_p2x.clone();
            let pats_p3xx = pats_p3x.clone();
            let ptys_p4xx = ptys_p4x.clone();
            ::std::rc::Rc::new(move |p0: crate::prelude::Nat| {
                let lxc_p2xxy = lxc_p2xx.clone();
                let pats_p3xxy = pats_p3xx.clone();
                let ptys_p4xxy = ptys_p4xx.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let i_p1u = p0;
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::lower::expr::ArmPat { lx_p0: lxc_p2xxy.clone(), opt1: crate::prelude::or(&crate::prelude::index(&pats_p3xxy, &i_p1u), &::std::option::Option::None), ty_p2: crate::prelude::or(&crate::prelude::index(&ptys_p4xxy, &i_p1u), &crate::check::types::Ty::TyErr), mode_p3: crate::lower::types::Holding::ByRef, fresh_p4: crate::prelude::Text::from(format!("c{}", &i_p1u)) }))
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::patterns::PatOut>>>
        }), move |each_65615: crate::prelude::Array<crate::lower::patterns::PatOut>| {
            let pos_ph = each_65615;
            let pa_pi = crate::lower::model::Pa::PaTuple(crate::prelude::each(&pos_ph, &(|o_p1v: &crate::lower::patterns::PatOut| o_p1v.pa_p.clone())));
            let binds_pj = crate::prelude::fold(&pos_ph, &crate::prelude::Map::new(), &(|m_p20: &crate::prelude::Map<crate::prelude::Text, crate::lower::types::Bn>, o_p21: &crate::lower::patterns::PatOut| crate::prelude::fold(&o_p21.binds_p, m_p20, &(|m2_p22: &crate::prelude::Map<crate::prelude::Text, crate::lower::types::Bn>, (n_p23, b_p24): &(crate::prelude::Text, crate::lower::types::Bn)| crate::prelude::insert(m2_p22, n_p23, b_p24)))));
            let binds_pjz = binds_pj.clone();
            let body_p6xz = body_p6x.clone();
            let dyns_given_pcxz = dyns_given_pcx.clone();
            let gen_name_p8xz = gen_name_p8x.clone();
            let lxc_p2xz = lxc_p2x.clone();
            let menv_p1xz = menv_p1x.clone();
            let pa_piz = pa_pi.clone();
            let parent_ty_pbxz = parent_ty_pbx.clone();
            let pats_p3xz = pats_p3x.clone();
            let pos_phz = pos_ph.clone();
            let reads_block_paxz = reads_block_pax;
            let row_name_p7xz = row_name_p7x.clone();
            let transparent_p9xz = transparent_p9x;
            let up_name_pgz = up_name_pg.clone();
            let ups_pdxz = ups_pdx.clone();
            let widgets_pexz = widgets_pex.clone();
            let wx_p0xz = wx_p0x.clone();
            let zero_based_pfxz = zero_based_pfx;
            let k_let65846 = move |v65846: crate::prelude::Array<crate::lower::model::Cc>| {
                let guard_conds_pk = v65846;
                crate::prelude::call_value(crate::prelude::fold_job(pats_p3xz.clone(), crate::prelude::Array::new(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>, ::std::option::Option<crate::syntax::Pattern>)| crate::prelude::entered(crate::prelude::once_job(move || {
                    let acc_p28 = p0;
                    let p_o29 = p1;
                    crate::prelude::call_then(start_opt_binders_f(p_o29.clone()), move |opt_binders_f_66150: crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_p28, &opt_binders_f_66150)))
                }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>, ::std::option::Option<crate::syntax::Pattern>)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>>>>), move |fold_66109: crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>| {
                    let named_pl = fold_66109;
                    let lives_pm = if zero_based_pfxz && (&parent_ty_pbxz == &crate::lower::model::OutTy::OutUnit) {
                        dyns_given_pcxz.clone()
                    } else {
                        crate::prelude::Array::new()
                    };
                    let dyns_pn = if zero_based_pfxz && (&parent_ty_pbxz == &crate::lower::model::OutTy::OutUnit) {
                        crate::prelude::Array::new()
                    } else {
                        dyns_given_pcxz.clone()
                    };
                    let dyn_names_po = crate::prelude::append(&crate::prelude::each(&dyns_pn, &(|(n_p2a, _): &(crate::prelude::Text, crate::lower::types::Bn)| n_p2a.clone())), &crate::prelude::each(&widgets_pexz, &(|(n_p2b, _): &(crate::prelude::Text, crate::syntax::Expr)| n_p2b.clone())));
                    let binders_pp = crate::prelude::filter(&named_pl, &(|(bn_p2c, _): &(crate::prelude::Text, crate::syntax::Range)| crate::check::env::has_key_f(&binds_pjz, bn_p2c) && !crate::check::types::has_text_f(&dyn_names_po, bn_p2c)));
                    crate::prelude::call_value(crate::prelude::each_job(binders_pp.clone(), {
                        let lxc_p2xzx = lxc_p2xz.clone();
                        ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::syntax::Range)| {
                            let lxc_p2xzxy = lxc_p2xzx.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let (bn_p2d, r_p2e) = p0;
                                crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lxc_p2xzxy.clone(), crate::lower::types::peel_f(&crate::lower::binder_ty_f(&lxc_p2xzxy, &r_p2e))), move |out_ty_of_f_66651: crate::lower::model::OutTy| ::prism_rtl::Turn::Finished((crate::lower::snake_f(&bn_p2d), out_ty_of_f_66651, bn_p2d.clone())))
                            }))
                        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::syntax::Range)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Text, crate::lower::model::OutTy, crate::prelude::Text)>>>
                    }), move |each_66609: crate::prelude::Array<(crate::prelude::Text, crate::lower::model::OutTy, crate::prelude::Text)>| {
                        let fields_pq = each_66609;
                        let weak_late_pr = (((transparent_p9xz && !zero_based_pfxz) && is_weak_ty_f(&parent_ty_pbxz)) && wx_p0xz.late_gens_p) && (&wx_p0xz.pos_p.scope_p == &crate::prelude::Nat::from(0u32));
                        let numbered_late_ps = weak_late_pr || (((transparent_p9xz && !zero_based_pfxz) && is_link_ty_f(&parent_ty_pbxz)) && crate::lower::node_::finish::numbered_late_f(&wx_p0xz, &wx_p0xz.pos_p));
                        let base_field_pt = if numbered_late_ps {
                            crate::prelude::Array::from(vec![(crate::prelude::Text::lit("base"), crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Cell")), crate::prelude::Array::from(vec![crate::lower::model::OutTy::OutCount])), crate::prelude::Text::lit("where the row\'s first position stands as built, set when the row is numbered")), (crate::prelude::Text::lit("number_later"), crate::lower::model::OutTy::OutCell(::std::rc::Rc::new(crate::lower::model::OutTy::OutOpt(::std::rc::Rc::new(crate::lower::node_::finish::later_ty_p())))), crate::prelude::Text::lit("what the row\'s build does once it is numbered"))])
                        } else {
                            if transparent_p9xz {
                                crate::prelude::Array::from(vec![(crate::prelude::Text::lit("base"), crate::lower::model::OutTy::OutCount, crate::prelude::Text::lit("where the row\'s first position stands as built"))])
                            } else {
                                crate::prelude::Array::new()
                            }
                        };
                        let row_fields_pu = crate::prelude::append(&crate::prelude::push(&crate::prelude::each(&fields_pq, &(|(f_p2f, t_p2g, bn_p2h): &(crate::prelude::Text, crate::lower::model::OutTy, crate::prelude::Text)| (f_p2f.clone(), t_p2g.clone(), crate::prelude::Text::from(format!("`{}`", bn_p2h))))), &(crate::prelude::Text::lit("parent"), parent_ty_pbxz.clone(), crate::prelude::Text::lit("the node of the `rebuild`"))), &base_field_pt);
                        let row_inits_pv = crate::prelude::append(&crate::prelude::each(&fields_pq, &(|(f_p2i, _, _): &(crate::prelude::Text, crate::lower::model::OutTy, crate::prelude::Text)| (f_p2i.clone(), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(f_p2i.clone())))))), &(if numbered_late_ps {
                            crate::prelude::Array::from(vec![(crate::prelude::Text::lit("base"), crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Cell::new")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XIndex(crate::prelude::Nat::from(0u32))]))), (crate::prelude::Text::lit("number_later"), crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::RefCell::new")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XNone])))])
                        } else {
                            if transparent_p9xz {
                                crate::prelude::Array::from(vec![(crate::prelude::Text::lit("base"), crate::lower::model::Ex::XVar(crate::prelude::Text::lit("base")))])
                            } else {
                                crate::prelude::Array::new()
                            }
                        }));
                        let row_taken_p10 = crate::prelude::append(&crate::prelude::append(&crate::lower::node_::node_hooks_p(), &crate::prelude::push(&crate::prelude::push(&crate::prelude::each(&fields_pq, &(|(f_p2j, _, _): &(crate::prelude::Text, crate::lower::model::OutTy, crate::prelude::Text)| f_p2j.clone())), &crate::prelude::Text::lit("parent")), &crate::prelude::Text::lit("result_value"))), &crate::prelude::Array::from(vec![crate::prelude::Text::lit("base"), crate::prelude::Text::lit("place"), crate::prelude::Text::lit("seat"), crate::prelude::Text::lit("inner_gap"), crate::prelude::Text::lit("number_later"), crate::prelude::Text::lit("number_places"), crate::prelude::Text::lit("number"), crate::prelude::Text::lit("numbered")]));
                        let hosted_rows_o11 = match &wx_p0xz.valued_as_o {
                            ::std::option::Option::Some(true) => ::std::option::Option::Some(shared_moved_p()),
                            ::std::option::Option::Some(false) => ::std::option::Option::None,
                            ::std::option::Option::None => crate::lower::node_::finish::hosted_rows_o(&wx_p0xz),
                        };
                        let shared_p12 = (zero_based_pfxz && (&parent_ty_pbxz == &crate::lower::model::OutTy::OutUnit)) || match &wx_p0xz.valued_as_o {
                            ::std::option::Option::Some(hosted_p2k) => *hosted_p2k,
                            ::std::option::Option::None => false,
                        };
                        let hosted_by_o13 = match &hosted_rows_o11 {
                            ::std::option::Option::Some(m_p2l) => if shared_p12 {
                                ::std::option::Option::Some(shared_moved_p())
                            } else {
                                ::std::option::Option::Some(m_p2l.clone())
                            },
                            ::std::option::Option::None => ::std::option::Option::None,
                        };
                        let hosted_params_p14 = match &hosted_rows_o11 {
                            ::std::option::Option::Some(_) => crate::prelude::Array::from(vec![(crate::prelude::Text::lit("enclosing"), crate::lower::types::host_of_ty_p())]),
                            ::std::option::Option::None => crate::prelude::Array::new(),
                        };
                        let moved_param_p15 = if shared_p12 && is_some_f(&hosted_by_o13) {
                            crate::prelude::Array::from(vec![(crate::prelude::Text::lit("moved"), moved_ty_p())])
                        } else {
                            crate::prelude::Array::new()
                        };
                        let row_fresh_p16 = crate::lower::node_::new_wx_f(&lxc_p2xz, &row_name_p7xz, &row_fields_pu, &row_inits_pv, &crate::prelude::Array::from(vec![(crate::prelude::Text::lit("parent"), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("parent")))))]), &crate::prelude::Array::new(), &crate::prelude::Map::new(), &row_taken_p10, &wx_p0xz.inlining_p, &hosted_by_o13);
                        let r0000_p17 = if zero_based_pfxz {
                            crate::lower::node_::under_its_path_f(&row_fresh_p16, &hosted_by_o13)
                        } else {
                            row_fresh_p16.clone()
                        };
                        let r000_p18 = {
                            let mut this: crate::lower::node_::Wx = r0000_p17.clone();
                            this.base_late_p = numbered_late_ps;
                            this.late_gens_p = numbered_late_ps && (wx_p0xz.late_gens_p || crate::lower::node_::def::is_late_block_f(&lxc_p2xz, &(if reads_block_paxz { menv_p1xz.clone() } else { crate::lower::types::empty_env_p() }), &body_p6xz, &crate::prelude::Nat::from(16u32)));
                            this.numbered_by_p = if weak_late_pr {
                                crate::prelude::Array::from(vec![numbered_by_parent_f(&wx_p0xz, &wx_p0xz.pos_p, &gen_name_p8xz)])
                            } else {
                                crate::prelude::Array::new()
                            };
                            this
                        };
                        let r00_p19 = if &crate::prelude::len(&moved_param_p15) == &crate::prelude::Nat::from(0u32) {
                            r000_p18.clone()
                        } else {
                            {
                                let mut this: crate::lower::node_::Wx = r000_p18.clone();
                                this.taken_p = crate::prelude::push(&this.taken_p, &crate::prelude::Text::lit("moved"));
                                this.fields_p = crate::prelude::push(&this.fields_p, &(crate::prelude::Text::lit("moved"), moved_ty_p(), crate::prelude::Text::lit("what tells the row\'s host that a place of the row\'s may have moved")));
                                this.inits_p = crate::prelude::push(&this.inits_p, &(crate::prelude::Text::lit("moved"), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("moved"))))));
                                this
                            }
                        };
                        let first_p1a = if zero_based_pfxz {
                            crate::prelude::Nat::from(0u32)
                        } else {
                            wx_p0xz.pos_p.at_p.clone()
                        };
                        let r0p_p1b = if transparent_p9xz {
                            {
                                let mut this: crate::lower::node_::Wx = r00_p19.clone();
                                this.pos_p = crate::lower::model::Pos { scope_p: crate::prelude::Nat::from(0u32), at_p: first_p1a.clone() };
                                this
                            }
                        } else {
                            r00_p19.clone()
                        };
                        let r0b_p1c = if transparent_p9xz {
                            {
                                let mut this: crate::lower::node_::Wx = r0p_p1b.clone();
                                this.based_o = ::std::option::Option::Some(first_p1a.clone());
                                this
                            }
                        } else {
                            r0p_p1b.clone()
                        };
                        let (r0_p2m, live_be_p2n, live_me_p2o, live_params_p2p) = live_params_f(&r0b_p1c, &lives_pm);
                        let binds_pjzz = binds_pjz.clone();
                        let body_p6xzz = body_p6xz.clone();
                        let dyns_pnz = dyns_pn.clone();
                        let fields_pqz = fields_pq.clone();
                        let gen_name_p8xzz = gen_name_p8xz.clone();
                        let guard_conds_pkz = guard_conds_pk.clone();
                        let hosted_params_p14z = hosted_params_p14.clone();
                        let live_be_p2nz = live_be_p2n.clone();
                        let live_me_p2oz = live_me_p2o.clone();
                        let live_params_p2pz = live_params_p2p.clone();
                        let lxc_p2xzz = lxc_p2xz.clone();
                        let menv_p1xzz = menv_p1xz.clone();
                        let moved_param_p15z = moved_param_p15.clone();
                        let numbered_late_psz = numbered_late_ps;
                        let pa_pizz = pa_piz.clone();
                        let parent_ty_pbxzz = parent_ty_pbxz.clone();
                        let pos_phzz = pos_phz.clone();
                        let r0_p2mz = r0_p2m.clone();
                        let reads_block_paxzz = reads_block_paxz;
                        let row_name_p7xzz = row_name_p7xz.clone();
                        let transparent_p9xzz = transparent_p9xz;
                        let up_name_pgzz = up_name_pgz.clone();
                        let ups_pdxzz = ups_pdxz.clone();
                        let weak_late_prz = weak_late_pr;
                        let widgets_pexzz = widgets_pexz.clone();
                        let wx_p0xzz = wx_p0xz.clone();
                        let zero_based_pfxzz = zero_based_pfxz;
                        let k_let71080 = move |v71080: (crate::lower::node_::Wx, crate::lower::node_::Wx, crate::lower::types::Env)| {
                            let (p1a_p2q, r1a_p2r, ports_p2s) = v71080;
                            crate::prelude::call_value(crate::prelude::fold_job(widgets_pexzz.clone(), (p1a_p2q.clone(), r1a_p2r.clone(), crate::lower::types::empty_env_p()), {
                                let menv_p1xzzx = menv_p1xzz.clone();
                                let wx_p0xzzx = wx_p0xzz.clone();
                                ::std::rc::Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::node_::Wx, crate::lower::types::Env), (crate::prelude::Text, crate::syntax::Expr))| {
                                    let menv_p1xzzxy = menv_p1xzzx.clone();
                                    let wx_p0xzzxy = wx_p0xzzx.clone();
                                    crate::prelude::entered(crate::prelude::once_job(move || {
                                        let (p_p2t, r_p2u, en_p2v) = p0;
                                        let (bn_p30, x_p31) = p1;
                                        crate::prelude::call_then(crate::check::typed::print::start_exprs_in_f(x_p31.clone()), move |exprs_in_f_71339: crate::prelude::Array<crate::syntax::Expr>| crate::prelude::call_then(crate::lower::expr::start_read_names_f(exprs_in_f_71339), move |read_names_f_71328: crate::prelude::Array<crate::prelude::Text>| crate::prelude::call_then(start_row_env_names_f(p_p2t.clone(), r_p2u.clone(), menv_p1xzzxy.clone(), read_names_f_71328), move |row_env_names_f_71303: (crate::lower::node_::Wx, crate::lower::node_::Wx, crate::lower::types::Env)| {
                                            let (p2_p32, r2_p33, inner_p34) = row_env_names_f_71303;
                                            crate::prelude::call_then(start_build_spelling_f(inner_p34.clone()), move |build_spelling_f_71397: crate::lower::types::Env| ::prism_rtl::Turn::Finished((p2_p32.clone(), r2_p33.clone(), crate::lower::types::bind_f(&en_p2v, &bn_p30, &crate::lower::types::Bn::BnWidget(x_p31.clone(), build_spelling_f_71397, inner_p34.clone(), wx_p0xzzxy.lx_p.clone())))))
                                        })))
                                    }))
                                }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::lower::node_::Wx, crate::lower::node_::Wx, crate::lower::types::Env), (crate::prelude::Text, crate::syntax::Expr))) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::node_::Wx, crate::lower::types::Env)>>>
                            }), move |fold_71206: (crate::lower::node_::Wx, crate::lower::node_::Wx, crate::lower::types::Env)| {
                                let (p1_p35, r1_p36, widget_env_p37) = fold_71206;
                                let (be0_p3d, me0_p3e) = crate::prelude::fold(&fields_pqz, &(crate::lower::types::empty_env_p(), crate::lower::types::empty_env_p()), &(|(b_p38, m_p39): &(crate::lower::types::Env, crate::lower::types::Env), (f_p3a, t_p3b, bn_p3c): &(crate::prelude::Text, crate::lower::model::OutTy, crate::prelude::Text)| crate::lower::node_::bind_plain_f(b_p38, m_p39, bn_p3c, f_p3a, t_p3b)));
                                let dyn_env_p1d = crate::lower::expr::bind_all_f(&crate::lower::types::empty_env_p(), &dyns_pnz);
                                let me_p1e = over_env_f(&over_env_f(&over_env_f(&me0_p3e, &dyn_env_p1d), &live_me_p2oz), &widget_env_p37);
                                crate::prelude::call_then(start_build_spelling_f(dyn_env_p1d.clone()), move |build_spelling_f_71704: crate::lower::types::Env| {
                                    let be_p1f = over_env_f(&over_env_f(&over_env_f(&be0_p3d, &build_spelling_f_71704), &live_be_p2nz), &widget_env_p37);
                                    let binds_pjzzz = binds_pjzz.clone();
                                    let body_p6xzzz = body_p6xzz.clone();
                                    let fields_pqzz = fields_pqz.clone();
                                    let gen_name_p8xzzz = gen_name_p8xzz.clone();
                                    let guard_conds_pkzz = guard_conds_pkz.clone();
                                    let hosted_params_p14zz = hosted_params_p14z.clone();
                                    let live_params_p2pzz = live_params_p2pz.clone();
                                    let lxc_p2xzzz = lxc_p2xzz.clone();
                                    let moved_param_p15zz = moved_param_p15z.clone();
                                    let numbered_late_pszz = numbered_late_psz;
                                    let p1_p35z = p1_p35.clone();
                                    let pa_pizzz = pa_pizz.clone();
                                    let parent_ty_pbxzzz = parent_ty_pbxzz.clone();
                                    let pos_phzzz = pos_phzz.clone();
                                    let r0_p2mzz = r0_p2mz.clone();
                                    let row_name_p7xzzz = row_name_p7xzz.clone();
                                    let transparent_p9xzzz = transparent_p9xzz;
                                    let up_name_pgzzz = up_name_pgzz.clone();
                                    let ups_pdxzzz = ups_pdxzz.clone();
                                    let weak_late_przz = weak_late_prz;
                                    let wx_p0xzzz = wx_p0xzz.clone();
                                    let zero_based_pfxzzz = zero_based_pfxzz;
                                    let k_let71800 = move |v71800: crate::lower::node_::Wx| {
                                        let r2u_p1g = v71800;
                                        let r2_p1h = crate::prelude::fold(&ups_pdxzzz, &r2u_p1g, &(|r_p3f: &crate::lower::node_::Wx, (mine_p3g, blocks_p3h): &(crate::prelude::Text, crate::prelude::Text)| match crate::prelude::index(&crate::prelude::filter(&r_p3f.gns_p, &(|g_p3i: &crate::lower::node_::Gn| (&g_p3i.name_p == mine_p3g) && (&g_p3i.kind_p == &crate::lower::node_::GnKind::GnNamed))), &crate::prelude::Nat::from(0u32)) {
                                            ::std::option::Option::Some(g_p3j) => crate::lower::node_::connect_f(r_p3f, &crate::lower::node_::ev_ref_of_f(r_p3f, &g_p3j.id_p), &crate::lower::node_::Sk::SkUp(blocks_p3h.clone())),
                                            ::std::option::Option::None => {
                                                let mut this: crate::lower::node_::Wx = r_p3f.clone();
                                                this.build_p = crate::prelude::push(&this.build_p, &crate::lower::expr::internal_bug_do_f(&crate::prelude::Text::from(format!("the event `{}` of a split block\'s lower lines has no node in their row", mine_p3g))));
                                                this
                                            },
                                        }));
                                        let value_row_p1i = (zero_based_pfxzzz && (&parent_ty_pbxzzz == &crate::lower::model::OutTy::OutUnit)) || is_some_f(&wx_p0xzzz.valued_as_o);
                                        let binds_pjzzzz = binds_pjzzz.clone();
                                        let body_p6xzzzz = body_p6xzzz.clone();
                                        let fields_pqzzz = fields_pqzz.clone();
                                        let gen_name_p8xzzzz = gen_name_p8xzzz.clone();
                                        let guard_conds_pkzzz = guard_conds_pkzz.clone();
                                        let hosted_params_p14zzz = hosted_params_p14zz.clone();
                                        let live_params_p2pzzz = live_params_p2pzz.clone();
                                        let lxc_p2xzzzz = lxc_p2xzzz.clone();
                                        let moved_param_p15zzz = moved_param_p15zz.clone();
                                        let numbered_late_pszzz = numbered_late_pszz;
                                        let p1_p35zz = p1_p35z.clone();
                                        let pa_pizzzz = pa_pizzz.clone();
                                        let parent_ty_pbxzzzz = parent_ty_pbxzzz.clone();
                                        let pos_phzzzz = pos_phzzz.clone();
                                        let r0_p2mzzz = r0_p2mzz.clone();
                                        let r2_p1hz = r2_p1h.clone();
                                        let row_name_p7xzzzz = row_name_p7xzzz.clone();
                                        let transparent_p9xzzzz = transparent_p9xzzz;
                                        let up_name_pgzzzz = up_name_pgzzz.clone();
                                        let value_row_p1iz = value_row_p1i;
                                        let weak_late_przzz = weak_late_przz;
                                        let zero_based_pfxzzzz = zero_based_pfxzzz;
                                        let k_let72665 = move |v72665: (crate::lower::node_::Wx, crate::prelude::Array<RowPart>)| {
                                            let (r2b_p3l, parts_p3m) = v72665;
                                            let binds_pjzzzzz = binds_pjzzzz.clone();
                                            let fields_pqzzzz = fields_pqzzz.clone();
                                            let gen_name_p8xzzzzz = gen_name_p8xzzzz.clone();
                                            let guard_conds_pkzzzz = guard_conds_pkzzz.clone();
                                            let hosted_params_p14zzzz = hosted_params_p14zzz.clone();
                                            let live_params_p2pzzzz = live_params_p2pzzz.clone();
                                            let moved_param_p15zzzz = moved_param_p15zzz.clone();
                                            let numbered_late_pszzzz = numbered_late_pszzz;
                                            let p1_p35zzz = p1_p35zz.clone();
                                            let pa_pizzzzz = pa_pizzzz.clone();
                                            let parent_ty_pbxzzzzz = parent_ty_pbxzzzz.clone();
                                            let parts_p3mz = parts_p3m.clone();
                                            let pos_phzzzzz = pos_phzzzz.clone();
                                            let r0_p2mzzzz = r0_p2mzzz.clone();
                                            let r2_p1hzz = r2_p1hz.clone();
                                            let row_name_p7xzzzzz = row_name_p7xzzzz.clone();
                                            let transparent_p9xzzzzz = transparent_p9xzzzz;
                                            let weak_late_przzzz = weak_late_przzz;
                                            let zero_based_pfxzzzzz = zero_based_pfxzzzz;
                                            let k_let72807 = move |v72807: (crate::lower::node_::Wx, ::std::option::Option<crate::lower::model::OutTy>)| {
                                                let (r3_p42, plain_o43) = v72807;
                                                let base_param_p1j = if transparent_p9xzzzzz && !numbered_late_pszzzz {
                                                    crate::prelude::Array::from(vec![(crate::prelude::Text::lit("base"), crate::lower::model::OutTy::OutCount)])
                                                } else {
                                                    crate::prelude::Array::new()
                                                };
                                                let r3n_p1k = if r3_p42.late_gens_p && (&crate::prelude::len(&crate::prelude::filter(&unnumbered_steps_f(&r3_p42), &(|counted_p44: &bool| *counted_p44))) > &crate::prelude::Nat::from(0u32)) {
                                                    {
                                                        let mut this: crate::lower::node_::Wx = r3_p42.clone();
                                                        this.build_p = crate::prelude::push(&this.build_p, &crate::lower::expr::refusal_do_f(&crate::prelude::Text::lit("a widget that calls itself in an arm or a clause that is built before its block\'s node and numbered after it, beside a line whose plain result the arm gives or below a building `match` or `if` of that arm")));
                                                        this
                                                    }
                                                } else {
                                                    r3_p42.clone()
                                                };
                                                let own_gaps_p1l = &crate::prelude::len(&crate::prelude::filter(&r3_p42.gens_p, &(|gd_p45: &crate::lower::model::GenDef| gd_p45.gappy_p && (&gd_p45.pos_p.scope_p == &crate::prelude::Nat::from(0u32))))) > &crate::prelude::Nat::from(0u32);
                                                let positions_p1m = crate::lower::model::Ex::XIndex(crate::prelude::or(&(&r2_p1hzz.pos_p.at_p).checked_sub(&r0_p2mzzzz.pos_p.at_p), &crate::prelude::Nat::from(0u32)));
                                                let r3b_p1n = if !zero_based_pfxzzzzz {
                                                    r3n_p1k.clone()
                                                } else {
                                                    {
                                                        let mut this: crate::lower::node_::Wx = r3n_p1k.clone();
                                                        this.taken_p = crate::prelude::push(&this.taken_p, &crate::prelude::Text::lit("built"));
                                                        this.getters_p = crate::prelude::push(&this.getters_p, &crate::lower::model::MethDef { name_p: crate::prelude::Text::lit("built"), recv_p: crate::lower::model::Recv::RecvRef, params_p: crate::prelude::Array::new(), cx_p: crate::lower::model::CxArg::CxNone, ret_p: crate::lower::model::OutTy::OutCount, body_p: crate::prelude::Array::new(), tail_p: if own_gaps_p1l {
                                                            crate::lower::model::Ex::XBin(crate::lower::model::BinOp::OpSub, ::std::rc::Rc::new(positions_p1m.clone()), ::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::lit("inner_gap"), crate::prelude::Array::new())))
                                                        } else {
                                                            positions_p1m.clone()
                                                        }, doc_p: crate::prelude::Text::lit("How many places the row built (ruling TC: places are counted as they are built).") });
                                                        this
                                                    }
                                                };
                                                crate::prelude::call_then(crate::lower::node_::finish::start_finish_node_f(r3b_p1n.clone(), row_name_p7xzzzzz.clone(), crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&crate::prelude::each(&fields_pqzzzz, &(|(f_p46, t_p47, _): &(crate::prelude::Text, crate::lower::model::OutTy, crate::prelude::Text)| (f_p46.clone(), t_p47.clone()))), &live_params_p2pzzzz), &base_param_p1j), &crate::prelude::append(&crate::prelude::append(&crate::prelude::Array::from(vec![(crate::prelude::Text::lit("parent"), parent_ty_pbxzzzzz.clone())]), &hosted_params_p14zzzz), &moved_param_p15zzzz)), true), move |finish_node_f_77039: crate::lower::model::NodeDef| {
                                                    let node_p1o = finish_node_f_77039;
                                                    let p2m_p1p = gen_marked_f(&p1_p35zzz, &gen_name_p8xzzzzz, &r3b_p1n);
                                                    let p2_p1q = if !weak_late_przzzz {
                                                        p2m_p1p.clone()
                                                    } else {
                                                        {
                                                            let mut this: crate::lower::node_::Wx = p2m_p1p.clone();
                                                            this.late_row_gens_p = crate::check::types::add_text_f(&this.late_row_gens_p, &gen_name_p8xzzzzz);
                                                            this
                                                        }
                                                    };
                                                    let passed0_p1r = crate::prelude::each(&fields_pqzzzz, &(|(f_p48, t_p49, bn_p4a): &(crate::prelude::Text, crate::lower::model::OutTy, crate::prelude::Text)| match crate::prelude::get(&binds_pjzzzzz, bn_p4a) {
                                                        ::std::option::Option::Some(crate::lower::types::Bn::BnLocal(rs_p4b, mode_p4c, bt_p4d)) => crate::lower::types::own_f(&crate::lower::types::Vl::VlPlace(rs_p4b, mode_p4c, bt_p4d)),
                                                        _ => crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(f_p48.clone()))),
                                                    }));
                                                    let passed_p1s = if transparent_p9xzzzzz && !numbered_late_pszzzz {
                                                        crate::prelude::push(&passed0_p1r, &crate::lower::model::Ex::XVar(crate::prelude::Text::lit("row_base")))
                                                    } else {
                                                        passed0_p1r.clone()
                                                    };
                                                    let inner_p1t = &crate::prelude::len(&crate::prelude::filter(&r3_p42.gens_p, &(|gd_p4e: &crate::lower::model::GenDef| gd_p4e.gappy_p && (&gd_p4e.pos_p.scope_p == &crate::prelude::Nat::from(0u32))))) > &crate::prelude::Nat::from(0u32);
                                                    ::prism_rtl::Turn::Finished(ClauseRow { case_p: GenCase { node_p: node_p1o.clone(), params_p: crate::prelude::each(&fields_pqzzzz, &(|(f_p4f, t_p4g, _): &(crate::prelude::Text, crate::lower::model::OutTy, crate::prelude::Text)| (f_p4f.clone(), t_p4g.clone()))), pat_p: pa_pizzzzz.clone(), conds_p: crate::prelude::append(&crate::prelude::fold(&pos_phzzzzz, &crate::prelude::Array::new(), &(|acc_p4h: &crate::prelude::Array<crate::lower::model::Cc>, o_p4i: &crate::lower::patterns::PatOut| crate::prelude::append(acc_p4h, &o_p4i.conds_p))), &guard_conds_pkzzzz), passed_p: passed_p1s.clone() }, parent_p: p2_p1q.clone(), plain_o: plain_o43.clone(), result_reads_p: result_parent_reads_f(&r2_p1hzz), result_ty_o: result_dyn_ty_o(&r2_p1hzz), width_p: crate::prelude::or(&(&r2_p1hzz.pos_p.at_p).checked_sub(&r0_p2mzzzz.pos_p.at_p), &crate::prelude::Nat::from(0u32)), inner_p: inner_p1t, parts_p: parts_p3mz.clone() })
                                                })
                                            };
                                            match r2_p1hz.result_p.clone() {
                                                crate::lower::node_::Wres::WrEv(r_p3n) => if value_row_p1iz {
                                                    crate::prelude::call_then(start_block_gives_f(lxc_p2xzzzz.clone(), body_p6xzzzz.clone()), move |block_gives_f_73052: crate::lower::model::OutTy| k_let72807((valued_event_result_f(&r2_p1hz, &r_p3n, &block_gives_f_73052), ::std::option::Option::None)))
                                                } else {
                                                    k_let72807((crate::lower::node_::connect_f(&r2_p1hz, &r_p3n, &crate::lower::node_::Sk::SkUp(up_name_pgzzzz.clone())), ::std::option::Option::None))
                                                },
                                                crate::lower::node_::Wres::WrParts(_) if value_row_p1iz => crate::prelude::call_then(start_value_row_result_f(r2_p1hz.clone(), lxc_p2xzzzz.clone(), body_p6xzzzz.clone()), move |value_row_result_f_73329: (crate::lower::node_::Wx, ::std::option::Option<crate::lower::model::OutTy>)| k_let72807(value_row_result_f_73329)),
                                                crate::lower::node_::Wres::WrDyn(_, _, _) if value_row_p1iz => crate::prelude::call_then(start_value_row_result_f(r2_p1hz.clone(), lxc_p2xzzzz.clone(), body_p6xzzzz.clone()), move |value_row_result_f_73408: (crate::lower::node_::Wx, ::std::option::Option<crate::lower::model::OutTy>)| k_let72807(value_row_result_f_73408)),
                                                crate::lower::node_::Wres::WrHosted(_, _) if value_row_p1iz => crate::prelude::call_then(start_value_row_result_f(r2_p1hz.clone(), lxc_p2xzzzz.clone(), body_p6xzzzz.clone()), move |value_row_result_f_73555: (crate::lower::node_::Wx, ::std::option::Option<crate::lower::model::OutTy>)| k_let72807(value_row_result_f_73555)),
                                                crate::lower::node_::Wres::WrParts(_) => k_let72807((r2b_p3l.clone(), ::std::option::Option::None)),
                                                crate::lower::node_::Wres::WrPlain(ex_p3o, rt_p3p) => {
                                                    let (f_p3r, rf_p3s) = crate::lower::node_::fresh_name_f(&r2_p1hz, &crate::prelude::Text::lit("result"));
                                                    let r2p_p3q = {
                                                        let mut this: crate::lower::node_::Wx = rf_p3s.clone();
                                                        this.lets_p = crate::prelude::push(&this.lets_p, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaBind(f_p3r.clone())), rt_p3p.clone()), ex_p3o.clone()));
                                                        this.fields_p = crate::prelude::push(&this.fields_p, &(f_p3r.clone(), rt_p3p.clone(), crate::prelude::Text::lit("the clause\'s plain result")));
                                                        this.inits_p = crate::prelude::push(&this.inits_p, &(f_p3r.clone(), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(f_p3r.clone())))));
                                                        this.getters_p = crate::prelude::push(&this.getters_p, &crate::lower::model::MethDef { name_p: crate::prelude::Text::lit("result_value"), recv_p: crate::lower::model::Recv::RecvRef, params_p: crate::prelude::Array::new(), cx_p: crate::lower::model::CxArg::CxNone, ret_p: rt_p3p.clone(), body_p: crate::prelude::Array::new(), tail_p: crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), f_p3r.clone()))), doc_p: crate::prelude::Text::lit("The clause\'s plain result, which the block that built the generation reads.") });
                                                        this
                                                    };
                                                    k_let72807((r2p_p3q.clone(), ::std::option::Option::Some(rt_p3p.clone())))
                                                },
                                                crate::lower::node_::Wres::WrLate(ex_p3t, rt_p3u) => k_let72807(({
                                                    let mut this: crate::lower::node_::Wx = r2_p1hz.clone();
                                                    this.getters_p = crate::prelude::push(&this.getters_p, &crate::lower::model::MethDef { name_p: crate::prelude::Text::lit("result_value"), recv_p: crate::lower::model::Recv::RecvRef, params_p: crate::prelude::Array::new(), cx_p: crate::lower::model::CxArg::CxNone, ret_p: rt_p3u.clone(), body_p: crate::prelude::Array::new(), tail_p: if numbered_late_pszzz && !(r2_p1hz.late_gens_p && (&crate::prelude::len(&unnumbered_steps_f(&r2_p1hz)) == &crate::prelude::Nat::from(0u32))) {
                                                        crate::lower::expr::refusal_f(&crate::prelude::Text::lit("the plain result of an arm or a clause that is built before its block\'s node and numbered after it, read from a generation the arm builds after its own node whose rows take their numbers as they are built (a `for`, a `rebuild` or a widget that calls itself beside the building `match` whose result the arm gives)"))
                                                    } else {
                                                        ex_p3t.clone()
                                                    }, doc_p: crate::prelude::Text::lit("The clause\'s plain result, which the block that built the generation reads.") });
                                                    this
                                                }, ::std::option::Option::Some(rt_p3u.clone()))),
                                                crate::lower::node_::Wres::WrDyn(ex_p3v, rds_p40, rt_p41) => k_let72807((gen_result_f(&r2_p1hz, &gen_name_p8xzzzz, &ex_p3v, &rds_p40, &rt_p41), ::std::option::Option::None)),
                                                _ => k_let72807((r2_p1hz.clone(), ::std::option::Option::None)),
                                                _ => unreachable!("no arm matched"),
                                            }
                                        };
                                        match r2_p1h.result_p.clone() {
                                            crate::lower::node_::Wres::WrParts(ps_p3k) if !value_row_p1i => crate::prelude::call_then(start_row_parts_out_f(r2_p1h.clone(), gen_name_p8xzzz.clone(), crate::prelude::Text::lit(""), ps_p3k.clone()), move |row_parts_out_f_72739: (crate::lower::node_::Wx, crate::prelude::Array<RowPart>)| k_let72665(row_parts_out_f_72739)),
                                            _ => k_let72665((r2_p1h.clone(), crate::prelude::Array::new())),
                                            _ => unreachable!("no arm matched"),
                                        }
                                    };
                                    if reads_block_paxzz {
                                        crate::prelude::call_then(start_build_spelling_f(ports_p2s.clone()), move |build_spelling_f_71849: crate::lower::types::Env| crate::prelude::call_then(crate::lower::node_::def::start_block_into_f(r1_p36.clone(), over_env_f(&build_spelling_f_71849, &be_p1f), over_env_f(&ports_p2s, &me_p1e), body_p6xzz.clone()), move |block_into_f_71825: crate::lower::node_::Wx| k_let71800(block_into_f_71825)))
                                    } else {
                                        crate::prelude::call_then(crate::lower::node_::def::start_block_into_f(r1_p36.clone(), be_p1f.clone(), me_p1e.clone(), body_p6xzz.clone()), move |block_into_f_71908: crate::lower::node_::Wx| k_let71800(block_into_f_71908))
                                    }
                                })
                            })
                        };
                        if reads_block_paxz {
                            crate::prelude::call_then(start_row_env_f(wx_p0xz.clone(), r0_p2m.clone(), menv_p1xz.clone(), body_p6xz.clone()), move |row_env_f_71121: (crate::lower::node_::Wx, crate::lower::node_::Wx, crate::lower::types::Env)| k_let71080(row_env_f_71121))
                        } else {
                            k_let71080((wx_p0xz.clone(), r0_p2m.clone(), crate::lower::types::empty_env_p()))
                        }
                    })
                })
            };
            match guard_o5x.clone() {
                ::std::option::Option::Some(g_p25) => crate::prelude::call_then(crate::lower::expr::start_value_of_f(lxc_p2x.clone(), crate::lower::expr::bind_all_f(&menv_p1x, &crate::prelude::fold(&pos_ph, &crate::prelude::Array::new(), &(|acc_p26: &crate::prelude::Array<(crate::prelude::Text, crate::lower::types::Bn)>, o_p27: &crate::lower::patterns::PatOut| crate::prelude::append(acc_p26, &o_p27.binds_p)))), g_p25.clone()), move |value_of_f_65906: crate::lower::types::Vl| k_let65846(crate::prelude::Array::from(vec![crate::lower::model::Cc::CcIf(crate::lower::types::as_bool_f(&value_of_f_65906))]))),
                ::std::option::Option::None => k_let65846(crate::prelude::Array::new()),
            }
        })
    }
}

/// `Start ArmRowOf, x`: what the function value is when passed to `@Run`.
pub fn start_arm_row_of_f(wx_p0: crate::lower::node_::Wx, menv_p1: crate::lower::types::Env, lxc_p2: crate::lower::Lx, pats_p3: crate::prelude::Array<::std::option::Option<crate::syntax::Pattern>>, ptys_p4: crate::prelude::Array<crate::check::types::Ty>, guard_o5: ::std::option::Option<crate::syntax::Expr>, body_p6: crate::syntax::Block, row_name_p7: crate::prelude::Text, gen_name_p8: crate::prelude::Text, transparent_p9: bool, reads_block_pa: bool, parent_ty_pb: crate::lower::model::OutTy, dyns_given_pc: crate::prelude::Array<(crate::prelude::Text, crate::lower::types::Bn)>, ups_pd: crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text)>, widgets_pe: crate::prelude::Array<(crate::prelude::Text, crate::syntax::Expr)>, zero_based_pf: bool) -> ::std::rc::Rc<dyn ::prism_rtl::Job<ClauseRow>> {
    ::std::rc::Rc::new(ArmRowOf { wx_p0, menv_p1, lxc_p2, pats_p3, ptys_p4, guard_o5, body_p6, row_name_p7, gen_name_p8, transparent_p9, reads_block_pa, parent_ty_pb, dyns_given_pc, ups_pd, widgets_pe, zero_based_pf })
}

/// ```prism
/// ValuedEventResult: fn Wx, EvRef, OutTy -> Wx
/// ```
pub fn valued_event_result_f(r_p0: &crate::lower::node_::Wx, event_p1: &crate::lower::node_::EvRef, t_p2: &crate::lower::model::OutTy) -> crate::lower::node_::Wx {
    let port_ty_p3 = crate::lower::model::OutTy::OutRc(::std::rc::Rc::new(crate::lower::model::OutTy::OutPort(::std::rc::Rc::new(t_p2.clone()))));
    let port_p4 = crate::prelude::Text::lit("result_event_port");
    let mut this: crate::lower::node_::Wx = crate::lower::node_::connect_f(r_p0, event_p1, &crate::lower::node_::Sk::SkPort(crate::prelude::Text::lit("result_event")));
    this.taken_p = crate::prelude::append(&this.taken_p, &crate::prelude::Array::from(vec![crate::prelude::Text::lit("result_event"), port_p4.clone()]));
    this.lets_p = crate::prelude::push(&this.lets_p, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaBind(port_p4.clone())), port_ty_p3.clone()), crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Rc::new")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Port::new")), crate::prelude::Array::new())]))));
    this.fields_p = crate::prelude::push(&this.fields_p, &(port_p4.clone(), port_ty_p3.clone(), crate::prelude::Text::lit("the port the row\'s event result fires")));
    this.moves_p = crate::prelude::push(&this.moves_p, &(port_p4.clone(), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(port_p4.clone())))));
    this.getters_p = crate::prelude::push(&this.getters_p, &crate::lower::model::MethDef { name_p: crate::prelude::Text::lit("result_event"), recv_p: crate::lower::model::Recv::RecvRef, params_p: crate::prelude::Array::new(), cx_p: crate::lower::model::CxArg::CxNone, ret_p: port_ty_p3.clone(), body_p: crate::prelude::Array::new(), tail_p: crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), port_p4.clone()))), doc_p: crate::prelude::Text::lit("The port the row\'s event result fires, which the blueprint that built the row subscribes to.") });
    this
}

/// ```prism
/// ValueRowResult: unbounded fn Wx, Lx, Block -> ((Wx, ?OutTy))
/// ```
pub fn value_row_result_f(r_p0: &crate::lower::node_::Wx, lx_p1: &crate::lower::Lx, body_p2: &crate::syntax::Block) -> (crate::lower::node_::Wx, ::std::option::Option<crate::lower::model::OutTy>) {
    let full_p3 = match &crate::prelude::or(&crate::prelude::index(&body_p2.stmts_p, &crate::syntax::lexer::chars::dec_f(&crate::prelude::len(&body_p2.stmts_p))), &crate::lower::expr::dummy_stmt_l_p()).kind_p {
        crate::syntax::StmtKind::SExpr(x_p5) => crate::lower::node_::def::line_out_full_f(lx_p1, x_p5),
        _ => crate::check::types::Ty::TyErr,
    };
    let (r2_p6, whole_p7, t_p8) = value_row_whole_f(r_p0, lx_p1, &r_p0.result_p, &full_p3, &crate::prelude::Text::lit(""));
    let r3_p4 = {
        let mut this: crate::lower::node_::Wx = r2_p6.clone();
        this.getters_p = crate::prelude::push(&this.getters_p, &crate::lower::model::MethDef { name_p: crate::prelude::Text::lit("result_value"), recv_p: crate::lower::model::Recv::RecvRef, params_p: crate::prelude::Array::new(), cx_p: crate::lower::model::CxArg::CxNone, ret_p: t_p8.clone(), body_p: crate::prelude::Array::new(), tail_p: whole_p7.clone(), doc_p: crate::prelude::Text::lit("The row\'s result as one value, its events and dynamics whole, which the blueprint that built the row answers with.") });
        this
    };
    (r3_p4.clone(), ::std::option::Option::Some(t_p8.clone()))
}

/// The step machine of `ValueRowResult`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ValueRowResult: unbounded fn Wx, Lx, Block -> ((Wx, ?OutTy))
/// ```
pub struct ValueRowResult {
    pub r_p0: crate::lower::node_::Wx,
    pub lx_p1: crate::lower::Lx,
    pub body_p2: crate::syntax::Block,
}

impl ::prism_rtl::Job<(crate::lower::node_::Wx, ::std::option::Option<crate::lower::model::OutTy>)> for ValueRowResult {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::lower::node_::Wx, ::std::option::Option<crate::lower::model::OutTy>)> {
        let r_p0 = &self.r_p0;
        let lx_p1 = &self.lx_p1;
        let body_p2 = &self.body_p2;
        let full_p3 = match &crate::prelude::or(&crate::prelude::index(&body_p2.stmts_p, &crate::syntax::lexer::chars::dec_f(&crate::prelude::len(&body_p2.stmts_p))), &crate::lower::expr::dummy_stmt_l_p()).kind_p {
            crate::syntax::StmtKind::SExpr(x_p5) => crate::lower::node_::def::line_out_full_f(lx_p1, x_p5),
            _ => crate::check::types::Ty::TyErr,
        };
        let lx_p1x = lx_p1.clone();
        let r_p0x = r_p0.clone();
        crate::prelude::call_then(start_value_row_whole_f(r_p0x.clone(), lx_p1x.clone(), r_p0x.result_p.clone(), full_p3.clone(), crate::prelude::Text::lit("")), move |value_row_whole_f_79717: (crate::lower::node_::Wx, crate::lower::model::Ex, crate::lower::model::OutTy)| {
            let (r2_p6, whole_p7, t_p8) = value_row_whole_f_79717;
            let r3_p4 = {
                let mut this: crate::lower::node_::Wx = r2_p6.clone();
                this.getters_p = crate::prelude::push(&this.getters_p, &crate::lower::model::MethDef { name_p: crate::prelude::Text::lit("result_value"), recv_p: crate::lower::model::Recv::RecvRef, params_p: crate::prelude::Array::new(), cx_p: crate::lower::model::CxArg::CxNone, ret_p: t_p8.clone(), body_p: crate::prelude::Array::new(), tail_p: whole_p7.clone(), doc_p: crate::prelude::Text::lit("The row\'s result as one value, its events and dynamics whole, which the blueprint that built the row answers with.") });
                this
            };
            ::prism_rtl::Turn::Finished((r3_p4.clone(), ::std::option::Option::Some(t_p8.clone())))
        })
    }
}

/// `Start ValueRowResult, x`: what the function value is when passed to `@Run`.
pub fn start_value_row_result_f(r_p0: crate::lower::node_::Wx, lx_p1: crate::lower::Lx, body_p2: crate::syntax::Block) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, ::std::option::Option<crate::lower::model::OutTy>)>> {
    ::std::rc::Rc::new(ValueRowResult { r_p0, lx_p1, body_p2 })
}

/// ```prism
/// ValueRowWhole: unbounded fn Wx, Lx, Wres, Ty, Text -> ((Wx, Ex, OutTy))
/// ```
pub fn value_row_whole_f(r_p0: &crate::lower::node_::Wx, lx_p1: &crate::lower::Lx, res_p2: &crate::lower::node_::Wres, full_p3: &crate::check::types::Ty, place_p4: &crate::prelude::Text) -> (crate::lower::node_::Wx, crate::lower::model::Ex, crate::lower::model::OutTy) {
    match res_p2 {
        crate::lower::node_::Wres::WrEv(event_p5) => {
            let t_p6 = crate::lower::types::out_ty_of_f(lx_p1, &crate::lower::types::peel_f(&crate::lower::types::peel_f(full_p3)));
            let port_ty_p7 = crate::lower::model::OutTy::OutRc(::std::rc::Rc::new(crate::lower::model::OutTy::OutPort(::std::rc::Rc::new(t_p6.clone()))));
            let stem_p8 = crate::prelude::Text::from(format!("result_part{}", place_p4));
            let port_p9 = crate::prelude::Text::from(format!("{}_port", &stem_p8));
            let r2_pa = {
                let mut this: crate::lower::node_::Wx = crate::lower::node_::connect_f(r_p0, event_p5, &crate::lower::node_::Sk::SkPort(stem_p8.clone()));
                this.taken_p = crate::prelude::append(&this.taken_p, &crate::prelude::Array::from(vec![stem_p8.clone(), port_p9.clone()]));
                this.lets_p = crate::prelude::push(&this.lets_p, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaBind(port_p9.clone())), port_ty_p7.clone()), crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Rc::new")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Port::new")), crate::prelude::Array::new())]))));
                this.fields_p = crate::prelude::push(&this.fields_p, &(port_p9.clone(), port_ty_p7.clone(), crate::prelude::Text::lit("the port an event of the row\'s result fires")));
                this.moves_p = crate::prelude::push(&this.moves_p, &(port_p9.clone(), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(port_p9.clone())))));
                this
            };
            (r2_pa.clone(), crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("prism_rtl::Event::of")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), port_p9.clone())))])), crate::lower::model::OutTy::OutEvent(::std::rc::Rc::new(t_p6.clone())))
        },
        crate::lower::node_::Wres::WrDyn(ex_pb, reads_pc, t_pd) => {
            let (made_pe, r2_pf) = crate::lower::node_::def::live_dynamic_f(r_p0, &crate::prelude::Text::from(format!("result_live{}", place_p4)), ex_pb, reads_pc, t_pd, &crate::prelude::Text::lit("a dynamic of the row\'s result"));
            'm81579: {
                if let crate::lower::model::Ex::XClone(m81579_0_0) = &made_pe && let crate::lower::model::Ex::XVar(field_pg) = &**m81579_0_0 {
                    break 'm81579 (r2_pf.clone(), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), field_pg.clone()))), crate::lower::model::OutTy::OutDyn(::std::rc::Rc::new(t_pd.clone())));
                }
                (r2_pf.clone(), crate::lower::expr::internal_bug_f(&crate::prelude::Text::lit("a live dynamic of a value row\'s result that is no field of the row")), crate::lower::model::OutTy::OutDyn(::std::rc::Rc::new(t_pd.clone())))
            }
        },
        crate::lower::node_::Wres::WrPlain(ex_ph, t_pi) => {
            let (f_pk, r1_pl) = crate::lower::node_::fresh_name_f(r_p0, &crate::prelude::Text::from(format!("result_plain{}", place_p4)));
            let r2_pj = {
                let mut this: crate::lower::node_::Wx = r1_pl.clone();
                this.lets_p = crate::prelude::push(&this.lets_p, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaBind(f_pk.clone())), t_pi.clone()), ex_ph.clone()));
                this.fields_p = crate::prelude::push(&this.fields_p, &(f_pk.clone(), t_pi.clone(), crate::prelude::Text::lit("a plain part of the row\'s result")));
                this.inits_p = crate::prelude::push(&this.inits_p, &(f_pk.clone(), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(f_pk.clone())))));
                this
            };
            (r2_pj.clone(), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), f_pk.clone()))), t_pi.clone())
        },
        crate::lower::node_::Wres::WrLate(ex_pm, t_pn) => (r_p0.clone(), ex_pm.clone(), t_pn.clone()),
        crate::lower::node_::Wres::WrParts(parts_po) => {
            let tys_pp = crate::lower::node_::keyed::bundle_part_tys_f(full_p3);
            let (r2_p11, values_p12, outs_p13) = crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(parts_po)), (r_p0.clone(), crate::prelude::Array::new(), crate::prelude::Array::new()), {
                let lx_p1x = lx_p1.clone();
                let parts_pox = parts_po.clone();
                let tys_ppx = tys_pp.clone();
                let place_p4x = place_p4.clone();
                ::std::rc::Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::prelude::Array<crate::lower::model::Ex>, crate::prelude::Array<crate::lower::model::OutTy>), crate::prelude::Nat)| {
                    let lx_p1xy = lx_p1x.clone();
                    let parts_poxy = parts_pox.clone();
                    let tys_ppxy = tys_ppx.clone();
                    let place_p4xy = place_p4x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let (w_pq, vs_pr, ts_ps) = p0;
                        let i_pt = p1;
                        crate::prelude::call_then(start_value_row_whole_f(w_pq.clone(), lx_p1xy.clone(), crate::prelude::or(&crate::prelude::index(&parts_poxy, &i_pt), &crate::lower::node_::Wres::WrUnit), crate::prelude::or(&crate::prelude::index(&tys_ppxy, &i_pt), &crate::check::types::Ty::TyErr), crate::prelude::Text::from(format!("{}_{}", &place_p4xy, &i_pt))), move |value_row_whole_f_82395: (crate::lower::node_::Wx, crate::lower::model::Ex, crate::lower::model::OutTy)| {
                            let (w2_pu, v_pv, t_p10) = value_row_whole_f_82395;
                            ::prism_rtl::Turn::Finished((w2_pu.clone(), crate::prelude::push(&vs_pr, &v_pv), crate::prelude::push(&ts_ps, &t_p10)))
                        })
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::lower::node_::Wx, crate::prelude::Array<crate::lower::model::Ex>, crate::prelude::Array<crate::lower::model::OutTy>), crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::prelude::Array<crate::lower::model::Ex>, crate::prelude::Array<crate::lower::model::OutTy>)>>>
            }));
            (r2_p11.clone(), crate::lower::model::Ex::XTuple(values_p12.clone()), crate::lower::model::OutTy::OutTuple(outs_p13.clone()))
        },
        crate::lower::node_::Wres::WrHosted(inner_p14, document_p15) => {
            let tys_p16 = crate::lower::node_::keyed::bundle_part_tys_f(full_p3);
            let (r1_p17, child_p18, child_ty_p19) = value_row_whole_f(r_p0, lx_p1, &**inner_p14, &crate::prelude::or(&crate::prelude::index(&tys_p16, &crate::prelude::Nat::from(0u32)), &crate::check::types::Ty::TyErr), &crate::prelude::Text::from(format!("{}_0", place_p4)));
            match document_p15 {
                crate::lower::types::Bn::BnDyn(ex_p1a, reads_p1b, t_p1c) => {
                    let (r2_p1d, held_p1e, held_ty_p1f) = value_row_whole_f(&r1_p17, lx_p1, &crate::lower::node_::Wres::WrDyn(ex_p1a.clone(), reads_p1b.clone(), t_p1c.clone()), &crate::prelude::or(&crate::prelude::index(&tys_p16, &crate::prelude::Nat::from(1u32)), &crate::check::types::Ty::TyErr), &crate::prelude::Text::from(format!("{}_1", place_p4)));
                    (r2_p1d.clone(), crate::lower::model::Ex::XTuple(crate::prelude::Array::from(vec![child_p18.clone(), held_p1e.clone()])), crate::lower::model::OutTy::OutTuple(crate::prelude::Array::from(vec![child_ty_p19.clone(), held_ty_p1f.clone()])))
                },
                _ => (r1_p17.clone(), crate::lower::expr::internal_bug_f(&crate::prelude::Text::lit("a host\'s document that is no dynamic of its node, in the result of a row a blueprint value builds")), crate::lower::model::OutTy::OutUnit),
            }
        },
        crate::lower::node_::Wres::WrUnit => (r_p0.clone(), crate::lower::model::Ex::XUnit, crate::lower::model::OutTy::OutUnit),
    }
}

/// The step machine of `ValueRowWhole`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ValueRowWhole: unbounded fn Wx, Lx, Wres, Ty, Text -> ((Wx, Ex, OutTy))
/// ```
pub struct ValueRowWhole {
    pub r_p0: crate::lower::node_::Wx,
    pub lx_p1: crate::lower::Lx,
    pub res_p2: crate::lower::node_::Wres,
    pub full_p3: crate::check::types::Ty,
    pub place_p4: crate::prelude::Text,
}

impl ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::model::Ex, crate::lower::model::OutTy)> for ValueRowWhole {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::lower::node_::Wx, crate::lower::model::Ex, crate::lower::model::OutTy)> {
        let r_p0 = &self.r_p0;
        let lx_p1 = &self.lx_p1;
        let res_p2 = &self.res_p2;
        let full_p3 = &self.full_p3;
        let place_p4 = &self.place_p4;
        match res_p2 {
            crate::lower::node_::Wres::WrEv(event_p5) => {
                let event_p5x = event_p5.clone();
                let full_p3x = full_p3.clone();
                let lx_p1x = lx_p1.clone();
                let place_p4x = place_p4.clone();
                let r_p0x = r_p0.clone();
                crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p1x.clone(), crate::lower::types::peel_f(&crate::lower::types::peel_f(&full_p3x))), move |out_ty_of_f_80735: crate::lower::model::OutTy| {
                    let t_p6 = out_ty_of_f_80735;
                    let port_ty_p7 = crate::lower::model::OutTy::OutRc(::std::rc::Rc::new(crate::lower::model::OutTy::OutPort(::std::rc::Rc::new(t_p6.clone()))));
                    let stem_p8 = crate::prelude::Text::from(format!("result_part{}", &place_p4x));
                    let port_p9 = crate::prelude::Text::from(format!("{}_port", &stem_p8));
                    let r2_pa = {
                        let mut this: crate::lower::node_::Wx = crate::lower::node_::connect_f(&r_p0x, &event_p5x, &crate::lower::node_::Sk::SkPort(stem_p8.clone()));
                        this.taken_p = crate::prelude::append(&this.taken_p, &crate::prelude::Array::from(vec![stem_p8.clone(), port_p9.clone()]));
                        this.lets_p = crate::prelude::push(&this.lets_p, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaBind(port_p9.clone())), port_ty_p7.clone()), crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Rc::new")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Port::new")), crate::prelude::Array::new())]))));
                        this.fields_p = crate::prelude::push(&this.fields_p, &(port_p9.clone(), port_ty_p7.clone(), crate::prelude::Text::lit("the port an event of the row\'s result fires")));
                        this.moves_p = crate::prelude::push(&this.moves_p, &(port_p9.clone(), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(port_p9.clone())))));
                        this
                    };
                    ::prism_rtl::Turn::Finished((r2_pa.clone(), crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("prism_rtl::Event::of")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), port_p9.clone())))])), crate::lower::model::OutTy::OutEvent(::std::rc::Rc::new(t_p6.clone()))))
                })
            },
            crate::lower::node_::Wres::WrDyn(ex_pb, reads_pc, t_pd) => {
                let (made_pe, r2_pf) = crate::lower::node_::def::live_dynamic_f(r_p0, &crate::prelude::Text::from(format!("result_live{}", place_p4)), ex_pb, reads_pc, t_pd, &crate::prelude::Text::lit("a dynamic of the row\'s result"));
                'm81579: {
                    if let crate::lower::model::Ex::XClone(m81579_0_0) = &made_pe && let crate::lower::model::Ex::XVar(field_pg) = &**m81579_0_0 {
                        break 'm81579 ::prism_rtl::Turn::Finished((r2_pf.clone(), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), field_pg.clone()))), crate::lower::model::OutTy::OutDyn(::std::rc::Rc::new(t_pd.clone()))));
                    }
                    ::prism_rtl::Turn::Finished((r2_pf.clone(), crate::lower::expr::internal_bug_f(&crate::prelude::Text::lit("a live dynamic of a value row\'s result that is no field of the row")), crate::lower::model::OutTy::OutDyn(::std::rc::Rc::new(t_pd.clone()))))
                }
            },
            crate::lower::node_::Wres::WrPlain(ex_ph, t_pi) => {
                let (f_pk, r1_pl) = crate::lower::node_::fresh_name_f(r_p0, &crate::prelude::Text::from(format!("result_plain{}", place_p4)));
                let r2_pj = {
                    let mut this: crate::lower::node_::Wx = r1_pl.clone();
                    this.lets_p = crate::prelude::push(&this.lets_p, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaBind(f_pk.clone())), t_pi.clone()), ex_ph.clone()));
                    this.fields_p = crate::prelude::push(&this.fields_p, &(f_pk.clone(), t_pi.clone(), crate::prelude::Text::lit("a plain part of the row\'s result")));
                    this.inits_p = crate::prelude::push(&this.inits_p, &(f_pk.clone(), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(f_pk.clone())))));
                    this
                };
                ::prism_rtl::Turn::Finished((r2_pj.clone(), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), f_pk.clone()))), t_pi.clone()))
            },
            crate::lower::node_::Wres::WrLate(ex_pm, t_pn) => ::prism_rtl::Turn::Finished((r_p0.clone(), ex_pm.clone(), t_pn.clone())),
            crate::lower::node_::Wres::WrParts(parts_po) => {
                let tys_pp = crate::lower::node_::keyed::bundle_part_tys_f(full_p3);
                let lx_p1x = lx_p1.clone();
                let parts_pox = parts_po.clone();
                let place_p4x = place_p4.clone();
                let r_p0x = r_p0.clone();
                crate::prelude::call_value(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(&parts_pox)), (r_p0x.clone(), crate::prelude::Array::new(), crate::prelude::Array::new()), {
                    let lx_p1xx = lx_p1x.clone();
                    let parts_poxx = parts_pox.clone();
                    let tys_ppx = tys_pp.clone();
                    let place_p4xx = place_p4x.clone();
                    ::std::rc::Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::prelude::Array<crate::lower::model::Ex>, crate::prelude::Array<crate::lower::model::OutTy>), crate::prelude::Nat)| {
                        let lx_p1xxy = lx_p1xx.clone();
                        let parts_poxxy = parts_poxx.clone();
                        let tys_ppxy = tys_ppx.clone();
                        let place_p4xxy = place_p4xx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let (w_pq, vs_pr, ts_ps) = p0;
                            let i_pt = p1;
                            crate::prelude::call_then(start_value_row_whole_f(w_pq.clone(), lx_p1xxy.clone(), crate::prelude::or(&crate::prelude::index(&parts_poxxy, &i_pt), &crate::lower::node_::Wres::WrUnit), crate::prelude::or(&crate::prelude::index(&tys_ppxy, &i_pt), &crate::check::types::Ty::TyErr), crate::prelude::Text::from(format!("{}_{}", &place_p4xxy, &i_pt))), move |value_row_whole_f_82395: (crate::lower::node_::Wx, crate::lower::model::Ex, crate::lower::model::OutTy)| {
                                let (w2_pu, v_pv, t_p10) = value_row_whole_f_82395;
                                ::prism_rtl::Turn::Finished((w2_pu.clone(), crate::prelude::push(&vs_pr, &v_pv), crate::prelude::push(&ts_ps, &t_p10)))
                            })
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::lower::node_::Wx, crate::prelude::Array<crate::lower::model::Ex>, crate::prelude::Array<crate::lower::model::OutTy>), crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::prelude::Array<crate::lower::model::Ex>, crate::prelude::Array<crate::lower::model::OutTy>)>>>
                }), move |fold_82298: (crate::lower::node_::Wx, crate::prelude::Array<crate::lower::model::Ex>, crate::prelude::Array<crate::lower::model::OutTy>)| {
                    let (r2_p11, values_p12, outs_p13) = fold_82298;
                    ::prism_rtl::Turn::Finished((r2_p11.clone(), crate::lower::model::Ex::XTuple(values_p12.clone()), crate::lower::model::OutTy::OutTuple(outs_p13.clone())))
                })
            },
            crate::lower::node_::Wres::WrHosted(inner_p14, document_p15) => {
                let tys_p16 = crate::lower::node_::keyed::bundle_part_tys_f(full_p3);
                let document_p15x = document_p15.clone();
                let inner_p14x = (**inner_p14).clone();
                let lx_p1x = lx_p1.clone();
                let place_p4x = place_p4.clone();
                let r_p0x = r_p0.clone();
                crate::prelude::call_then(start_value_row_whole_f(r_p0x.clone(), lx_p1x.clone(), inner_p14x.clone(), crate::prelude::or(&crate::prelude::index(&tys_p16, &crate::prelude::Nat::from(0u32)), &crate::check::types::Ty::TyErr), crate::prelude::Text::from(format!("{}_0", &place_p4x))), move |value_row_whole_f_82816: (crate::lower::node_::Wx, crate::lower::model::Ex, crate::lower::model::OutTy)| {
                    let (r1_p17, child_p18, child_ty_p19) = value_row_whole_f_82816;
                    match &document_p15x {
                        crate::lower::types::Bn::BnDyn(ex_p1a, reads_p1b, t_p1c) => {
                            let ex_p1ax = ex_p1a.clone();
                            let reads_p1bx = reads_p1b.clone();
                            let t_p1cx = t_p1c.clone();
                            crate::prelude::call_then(start_value_row_whole_f(r1_p17.clone(), lx_p1x.clone(), crate::lower::node_::Wres::WrDyn(ex_p1ax.clone(), reads_p1bx.clone(), t_p1cx.clone()), crate::prelude::or(&crate::prelude::index(&tys_p16, &crate::prelude::Nat::from(1u32)), &crate::check::types::Ty::TyErr), crate::prelude::Text::from(format!("{}_1", &place_p4x))), move |value_row_whole_f_82975: (crate::lower::node_::Wx, crate::lower::model::Ex, crate::lower::model::OutTy)| {
                                let (r2_p1d, held_p1e, held_ty_p1f) = value_row_whole_f_82975;
                                ::prism_rtl::Turn::Finished((r2_p1d.clone(), crate::lower::model::Ex::XTuple(crate::prelude::Array::from(vec![child_p18.clone(), held_p1e.clone()])), crate::lower::model::OutTy::OutTuple(crate::prelude::Array::from(vec![child_ty_p19.clone(), held_ty_p1f.clone()]))))
                            })
                        },
                        _ => ::prism_rtl::Turn::Finished((r1_p17.clone(), crate::lower::expr::internal_bug_f(&crate::prelude::Text::lit("a host\'s document that is no dynamic of its node, in the result of a row a blueprint value builds")), crate::lower::model::OutTy::OutUnit)),
                    }
                })
            },
            crate::lower::node_::Wres::WrUnit => ::prism_rtl::Turn::Finished((r_p0.clone(), crate::lower::model::Ex::XUnit, crate::lower::model::OutTy::OutUnit)),
        }
    }
}

/// `Start ValueRowWhole, x`: what the function value is when passed to `@Run`.
pub fn start_value_row_whole_f(r_p0: crate::lower::node_::Wx, lx_p1: crate::lower::Lx, res_p2: crate::lower::node_::Wres, full_p3: crate::check::types::Ty, place_p4: crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::model::Ex, crate::lower::model::OutTy)>> {
    ::std::rc::Rc::new(ValueRowWhole { r_p0, lx_p1, res_p2, full_p3, place_p4 })
}

/// ```prism
/// BlockGives: unbounded fn Lx, Block -> OutTy
/// ```
pub fn block_gives_f(lx_p0: &crate::lower::Lx, b_p1: &crate::syntax::Block) -> crate::lower::model::OutTy {
    match &crate::prelude::or(&crate::prelude::index(&b_p1.stmts_p, &crate::syntax::lexer::chars::dec_f(&crate::prelude::len(&b_p1.stmts_p))), &crate::lower::expr::dummy_stmt_l_p()).kind_p {
        crate::syntax::StmtKind::SExpr(x_p2) => crate::lower::types::out_ty_of_f(lx_p0, &crate::lower::types::out_of_f(&crate::lower::type_at_f(lx_p0, &x_p2.span_p))),
        _ => crate::lower::model::OutTy::OutUnit,
    }
}

/// The step machine of `BlockGives`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BlockGives: unbounded fn Lx, Block -> OutTy
/// ```
pub struct BlockGives {
    pub lx_p0: crate::lower::Lx,
    pub b_p1: crate::syntax::Block,
}

impl ::prism_rtl::Job<crate::lower::model::OutTy> for BlockGives {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::lower::model::OutTy> {
        let lx_p0 = &self.lx_p0;
        let b_p1 = &self.b_p1;
        match &crate::prelude::or(&crate::prelude::index(&b_p1.stmts_p, &crate::syntax::lexer::chars::dec_f(&crate::prelude::len(&b_p1.stmts_p))), &crate::lower::expr::dummy_stmt_l_p()).kind_p {
            crate::syntax::StmtKind::SExpr(x_p2) => ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::lower::types::OutTyOf { lx_p0: lx_p0.clone(), t_p1: crate::lower::types::out_of_f(&crate::lower::type_at_f(lx_p0, &x_p2.span_p)) })),
            _ => ::prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutUnit),
        }
    }
}

/// `Start BlockGives, x`: what the function value is when passed to `@Run`.
pub fn start_block_gives_f(lx_p0: crate::lower::Lx, b_p1: crate::syntax::Block) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::OutTy>> {
    ::std::rc::Rc::new(BlockGives { lx_p0, b_p1 })
}

/// ```prism
/// ?ResultDynTy: fn Wx -> ?OutTy
/// ```
pub fn result_dyn_ty_o(r_p0: &crate::lower::node_::Wx) -> ::std::option::Option<crate::lower::model::OutTy> {
    match &r_p0.result_p {
        crate::lower::node_::Wres::WrDyn(_, _, rt_p1) => ::std::option::Option::Some(rt_p1.clone()),
        _ => ::std::option::Option::None,
    }
}

/// ```prism
/// ResultParentReads: fn Wx -> [Read]
/// ```
pub fn result_parent_reads_f(r_p0: &crate::lower::node_::Wx) -> crate::prelude::Array<crate::lower::node_::Read> {
    match &r_p0.result_p {
        crate::lower::node_::Wres::WrDyn(_, rds_p1, _) => crate::prelude::filter(&crate::lower::node_::finish::reads_closed_f(&r_p0.dyn_reads_p, rds_p1), &(|rd_p2: &crate::lower::node_::Read| is_parent_read_f(rd_p2))),
        _ => crate::prelude::Array::new(),
    }
}

/// ```prism
/// IsParentRead: fn Read -> Bool
/// ```
pub fn is_parent_read_f(read0: &crate::lower::node_::Read) -> bool {
    match read0 {
        crate::lower::node_::Read::ParentRead(_) => true,
        crate::lower::node_::Read::OwnRead(_) => false,
    }
}

/// ```prism
/// OptBinders: unbounded fn ?Pattern -> [((Text, Range))]
/// ```
pub fn opt_binders_f(opt0: &::std::option::Option<crate::syntax::Pattern>) -> crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)> {
    match opt0 {
        ::std::option::Option::Some(p_p0) => crate::check::env::names::pattern_binders_f(p_p0),
        ::std::option::Option::None => crate::prelude::Array::new(),
    }
}

/// The step machine of `OptBinders`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// OptBinders: unbounded fn ?Pattern -> [((Text, Range))]
/// ```
pub struct OptBinders {
    pub opt0: ::std::option::Option<crate::syntax::Pattern>,
}

impl ::prism_rtl::Job<crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>> for OptBinders {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>> {
        let opt0 = &self.opt0;
        match opt0 {
            ::std::option::Option::Some(p_p0) => ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::env::names::PatternBinders { p_p0: p_p0.clone() })),
            ::std::option::Option::None => ::prism_rtl::Turn::Finished(crate::prelude::Array::new()),
        }
    }
}

/// `Start OptBinders, x`: what the function value is when passed to `@Run`.
pub fn start_opt_binders_f(opt0: ::std::option::Option<crate::syntax::Pattern>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>>> {
    ::std::rc::Rc::new(OptBinders { opt0 })
}

/// ```prism
/// OverEnv: fn Env, Env -> Env
/// ```
pub fn over_env_f(outer_p0: &crate::lower::types::Env, inner_p1: &crate::lower::types::Env) -> crate::lower::types::Env {
    crate::prelude::fold(&crate::prelude::keys(&inner_p1.names_p), outer_p0, &(|en_p2: &crate::lower::types::Env, k_p3: &crate::prelude::Text| match crate::prelude::get(&inner_p1.names_p, k_p3) {
        ::std::option::Option::Some(b_p4) => crate::lower::types::bind_f(en_p2, k_p3, &b_p4),
        ::std::option::Option::None => en_p2.clone(),
    }))
}

/// ```prism
/// BuildingChoiceLine: unbounded fn Wx, Env, Ex, [?Pattern], Ty, [?Expr], [Block], OutTy, Layer, Ty, [((Text, Text))] -> ((Wx, Wres))
/// ```
pub fn building_choice_line_f(wx_p0: &crate::lower::node_::Wx, menv_p1: &crate::lower::types::Env, scrut_p2: &crate::lower::model::Ex, pats_p3: &crate::prelude::Array<::std::option::Option<crate::syntax::Pattern>>, sty_p4: &crate::check::types::Ty, guards_p5: &crate::prelude::Array<::std::option::Option<crate::syntax::Expr>>, bodies_p6: &crate::prelude::Array<crate::syntax::Block>, out_ty_p7: &crate::lower::model::OutTy, layer_p8: &crate::lower::types::Layer, out_full_p9: &crate::check::types::Ty, ups_pa: &crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text)>) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    let lx_pb = wx_p0.lx_p.clone();
    let pos_pc = wx_p0.pos_p.clone();
    let bundled_pd = crate::lower::types::is_bundle_f(out_full_p9);
    let (name_pu, wx1_pv) = crate::lower::node_::fresh_name_f(wx_p0, &crate::prelude::Text::lit("arm"));
    let (up_id_p10, wx2_p11) = crate::lower::node_::add_gn_f(&wx1_pv, &crate::prelude::Text::from(format!("{}_fired", &name_pu)), &(if bundled_pd { crate::lower::model::OutTy::OutUnit } else { out_ty_p7.clone() }), &crate::lower::node_::GnKind::GnNamed, &crate::prelude::Nat::from(0u32));
    let row_name_pe = crate::prelude::Text::from(format!("{}Arm{}", &wx_p0.node_p, &crate::lower::node_::keyed::row_suffix_f(wx_p0)));
    let (rows_p16, wx3_p17) = crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(bodies_p6)), (crate::prelude::Array::new(), wx2_p11.clone()), {
        let menv_p1x = menv_p1.clone();
        let lx_pbx = lx_pb.clone();
        let pats_p3x = pats_p3.clone();
        let sty_p4x = sty_p4.clone();
        let guards_p5x = guards_p5.clone();
        let bodies_p6x = bodies_p6.clone();
        let row_name_pex = row_name_pe.clone();
        let name_pux = name_pu.clone();
        let wx_p0x = wx_p0.clone();
        let ups_pax = ups_pa.clone();
        ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Array<ClauseRow>, crate::lower::node_::Wx), crate::prelude::Nat)| {
            let menv_p1xy = menv_p1x.clone();
            let lx_pbxy = lx_pbx.clone();
            let pats_p3xy = pats_p3x.clone();
            let sty_p4xy = sty_p4x.clone();
            let guards_p5xy = guards_p5x.clone();
            let bodies_p6xy = bodies_p6x.clone();
            let row_name_pexy = row_name_pex.clone();
            let name_puxy = name_pux.clone();
            let wx_p0xy = wx_p0x.clone();
            let ups_paxy = ups_pax.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (acc_p12, w_p13) = p0;
                let i_p14 = p1;
                crate::prelude::call_then(start_arm_row_of_f(w_p13.clone(), menv_p1xy.clone(), lx_pbxy.clone(), crate::prelude::Array::from(vec![crate::prelude::or(&crate::prelude::index(&pats_p3xy, &i_p14), &::std::option::Option::None)]), crate::prelude::Array::from(vec![sty_p4xy.clone()]), crate::prelude::or(&crate::prelude::index(&guards_p5xy, &i_p14), &::std::option::Option::None), crate::prelude::or(&crate::prelude::index(&bodies_p6xy, &i_p14), &dummy_block_s_p()), crate::prelude::Text::from(format!("{}{}", &row_name_pexy, &i_p14)), name_puxy.clone(), true, true, crate::lower::model::OutTy::OutWeak(wx_p0xy.node_p.clone()), crate::prelude::Array::new(), ups_paxy.clone(), crate::prelude::Array::new(), false), move |arm_row_of_f_86326: ClauseRow| {
                    let cr_p15 = arm_row_of_f_86326;
                    ::prism_rtl::Turn::Finished((crate::prelude::push(&acc_p12, &cr_p15), cr_p15.parent_p.clone()))
                })
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Array<ClauseRow>, crate::lower::node_::Wx), crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<ClauseRow>, crate::lower::node_::Wx)>>>
    }));
    let width_pf = crate::prelude::fold(&rows_p16, &crate::prelude::Nat::from(0u32), &(|acc_p18: &crate::prelude::Nat, cr_p19: &ClauseRow| crate::prelude::max(acc_p18, &cr_p19.width_p)));
    let cases_pg = crate::prelude::each(&rows_p16, &(|cr_p1a: &ClauseRow| cr_p1a.case_p.clone()));
    let is_dyn_ph = layer_p8 == &crate::lower::types::Layer::LyDyn;
    let plain_rows_pi = crate::prelude::filter(&rows_p16, &(|cr_p1b: &ClauseRow| is_some_f(&cr_p1b.plain_o)));
    let all_plain_pj = &crate::prelude::len(&plain_rows_pi) == &crate::prelude::len(&rows_p16);
    let res_pk = crate::prelude::Text::from(format!("{}_res", &name_pu));
    let tail_pl = crate::prelude::append(&crate::prelude::append(&crate::prelude::Array::from(vec![crate::lower::model::Ex::XWeak(::std::rc::Rc::new(crate::lower::model::Ex::XSelf))]), &crate::lower::node_::keyed::hosted_passed_f(wx_p0)), &crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx]));
    let row_obj_pm = crate::lower::model::OutTy::OutObj(::std::rc::Rc::new(crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Row")), crate::prelude::Array::new())));
    let kept_pn = crate::lower::model::Do::DoAssign(crate::lower::model::Ex::XDeref(::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), res_pk.clone())), crate::prelude::Text::lit("borrow_mut"), crate::prelude::Array::new()))), crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Some")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("row"))), crate::prelude::Text::lit("result_dynamic"), crate::prelude::Array::new())])));
    let kept_plain_po = crate::lower::model::Do::DoAssign(crate::lower::model::Ex::XDeref(::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), res_pk.clone())), crate::prelude::Text::lit("borrow_mut"), crate::prelude::Array::new()))), crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Some")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("row"))), crate::prelude::Text::lit("result_value"), crate::prelude::Array::new())])));
    let gaps_pp = row_gaps_f(&rows_p16, &width_pf);
    let bundle_pq = if bundled_pd {
        keep_parts_f(&wx3_p17, &name_pu, &rows_bundle_f(&rows_p16), &crate::lower::node_::keyed::bundle_part_tys_f(out_full_p9))
    } else {
        KeptParts { wx_p: wx3_p17.clone(), keeps_p: crate::prelude::Array::new(), results_p: crate::prelude::Array::new() }
    };
    let arms_pr = crate::prelude::fold(&cases_pg, &crate::prelude::Array::new(), &(|built_p1c: &crate::prelude::Array<crate::lower::model::XArm>, c_p1d: &GenCase| {
        let i_p1e = crate::prelude::len(built_p1c);
        let made_p1f = crate::lower::expr::try_of_f(&crate::lower::model::Ex::XCall(crate::lower::model::ref_child_f(&crate::lower::site_ref_f(&lx_pb, &c_p1d.node_p.name_p), &crate::prelude::Text::lit("build")), crate::prelude::append(&crate::prelude::append(&crate::prelude::Array::from(vec![crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("path"))))]), &c_p1d.passed_p), &tail_pl)));
        let set_p1g = gap_set_f(&name_pu, &crate::prelude::or(&crate::prelude::index(&gaps_pp, &i_p1e), &::std::option::Option::None));
        let keeps_p1h = crate::prelude::append(&crate::prelude::append(&(if is_dyn_ph {
            crate::prelude::Array::from(vec![kept_pn.clone()])
        } else {
            if all_plain_pj {
                crate::prelude::Array::from(vec![kept_plain_po.clone()])
            } else {
                crate::prelude::Array::new()
            }
        }), &bundle_pq.keeps_p), &set_p1g);
        let body_p1i = if &crate::prelude::len(&keeps_p1h) == &crate::prelude::Nat::from(0u32) {
            crate::lower::model::Ex::XCast(::std::rc::Rc::new(made_p1f.clone()), row_obj_pm.clone())
        } else {
            crate::lower::model::Ex::XBlock(crate::prelude::append(&crate::prelude::Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("row")), made_p1f.clone())]), &keeps_p1h), ::std::rc::Rc::new(crate::lower::model::Ex::XCast(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("row"))), row_obj_pm.clone())))
        };
        crate::prelude::push(built_p1c, &crate::lower::model::XArm { pat_p: c_p1d.pat_p.clone(), conds_p: c_p1d.conds_p.clone(), body_p: body_p1i.clone() })
    }));
    let select_ps = with_row_base_f(wx_p0, &crate::prelude::Text::lit("self"), &pos_pc, &crate::lower::types::own_f(&crate::lower::expr::arms_value_f(&crate::lower::model::Ex::XTuple(crate::prelude::Array::from(vec![scrut_p2.clone()])), &arms_pr, &crate::prelude::Text::lit("\'select"), &crate::lower::model::OutTy::OutObj(::std::rc::Rc::new(crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Row")), crate::prelude::Array::new()))))));
    let wx4_pt = {
        let mut this: crate::lower::node_::Wx = bundle_pq.wx_p.clone();
        this.pos_p = crate::lower::model::Pos { scope_p: pos_pc.scope_p.clone(), at_p: &pos_pc.at_p + &width_pf };
        this.gens_p = crate::prelude::push(&this.gens_p, &crate::lower::model::GenDef { name_p: name_pu.clone(), pos_p: pos_pc.clone(), at_p: crate::lower::node_::finish::place_at_f(wx_p0, &crate::prelude::Text::lit("self"), &pos_pc), source_p: crate::lower::model::Ex::XUnit, value_ty_p: crate::lower::model::OutTy::OutUnit, select_p: select_ps.clone(), transparent_p: true, width_p: width_pf.clone(), moved_p: crate::prelude::or(&crate::lower::node_::finish::hosted_rows_o(wx_p0), &crate::prelude::Text::lit("")), early_p: false, gappy_p: is_gappy_f(&gaps_pp), rebased_p: false });
        this.gen_holds_p = crate::prelude::push(&this.gen_holds_p, &(name_pu.clone(), crate::prelude::Array::new()));
        this.rows_p = crate::prelude::fold(&cases_pg, &this.rows_p, &(|acc_p1j: &crate::prelude::Array<crate::lower::model::NodeDef>, gc_p1k: &GenCase| crate::prelude::append(&crate::prelude::push(acc_p1j, &gc_p1k.node_p), &gc_p1k.node_p.children_p)));
        this.getters_p = crate::prelude::push(&crate::prelude::push(&this.getters_p, &gen_up_f(&name_pu, &crate::lower::node_::gn_of_f(&wx3_p17, &up_id_p10).name_p, &crate::lower::node_::gn_of_f(&wx3_p17, &up_id_p10).ty_p)), &gen_up_above_f(&name_pu, &crate::lower::node_::gn_of_f(&wx3_p17, &up_id_p10).name_p));
        this
    };
    if bundled_pd {
        (wx4_pt.clone(), crate::lower::node_::Wres::WrParts(bundle_pq.results_p.clone()))
    } else {
        if is_dyn_ph {
            kept_dyn_result_f(&wx4_pt, &name_pu, &rows_p16)
        } else {
            if &crate::prelude::len(&plain_rows_pi) > &crate::prelude::Nat::from(0u32) {
                if all_plain_pj {
                    {
                        let read_p1l = crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), res_pk.clone())), crate::prelude::Text::lit("borrow"), crate::prelude::Array::new())), crate::prelude::Text::lit("as_ref"), crate::prelude::Array::new())), crate::prelude::Text::lit("expect"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XStr(crate::prelude::Text::lit("an arm built before what reads its result"))]))));
                        let wx5_p1m = {
                            let mut this: crate::lower::node_::Wx = wx4_pt.clone();
                            this.taken_p = crate::prelude::push(&this.taken_p, &res_pk);
                            this.fields_p = crate::prelude::push(&this.fields_p, &(res_pk.clone(), crate::lower::model::OutTy::OutCell(::std::rc::Rc::new(crate::lower::model::OutTy::OutOpt(::std::rc::Rc::new(out_ty_p7.clone())))), crate::prelude::Text::lit("the arm\'s plain result, kept from its build on")));
                            this.inits_p = crate::prelude::push(&this.inits_p, &(res_pk.clone(), crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::RefCell::new")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XNone]))));
                            this
                        };
                        (wx5_p1m.clone(), crate::lower::node_::Wres::WrLate(read_p1l.clone(), out_ty_p7.clone()))
                    }
                } else {
                    {
                        let wx5_p1n = {
                            let mut this: crate::lower::node_::Wx = wx4_pt.clone();
                            this.build_p = crate::prelude::push(&this.build_p, &crate::lower::expr::internal_bug_do_f(&crate::prelude::Text::lit("a building `match` or `if` whose arms do not all end on a plain result")));
                            this
                        };
                        (wx5_p1n.clone(), crate::lower::node_::Wres::WrUnit)
                    }
                }
            } else {
                if out_ty_p7 == &crate::lower::model::OutTy::OutUnit {
                    (wx4_pt.clone(), crate::lower::node_::Wres::WrUnit)
                } else {
                    (wx4_pt.clone(), crate::lower::node_::Wres::WrEv(crate::lower::node_::ev_ref_of_f(&wx4_pt, &up_id_p10)))
                }
            }
        }
    }
}

/// The step machine of `BuildingChoiceLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BuildingChoiceLine: unbounded fn Wx, Env, Ex, [?Pattern], Ty, [?Expr], [Block], OutTy, Layer, Ty, [((Text, Text))] -> ((Wx, Wres))
/// ```
pub struct BuildingChoiceLine {
    pub wx_p0: crate::lower::node_::Wx,
    pub menv_p1: crate::lower::types::Env,
    pub scrut_p2: crate::lower::model::Ex,
    pub pats_p3: crate::prelude::Array<::std::option::Option<crate::syntax::Pattern>>,
    pub sty_p4: crate::check::types::Ty,
    pub guards_p5: crate::prelude::Array<::std::option::Option<crate::syntax::Expr>>,
    pub bodies_p6: crate::prelude::Array<crate::syntax::Block>,
    pub out_ty_p7: crate::lower::model::OutTy,
    pub layer_p8: crate::lower::types::Layer,
    pub out_full_p9: crate::check::types::Ty,
    pub ups_pa: crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text)>,
}

impl ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::node_::Wres)> for BuildingChoiceLine {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::lower::node_::Wx, crate::lower::node_::Wres)> {
        let wx_p0 = &self.wx_p0;
        let menv_p1 = &self.menv_p1;
        let scrut_p2 = &self.scrut_p2;
        let pats_p3 = &self.pats_p3;
        let sty_p4 = &self.sty_p4;
        let guards_p5 = &self.guards_p5;
        let bodies_p6 = &self.bodies_p6;
        let out_ty_p7 = &self.out_ty_p7;
        let layer_p8 = &self.layer_p8;
        let out_full_p9 = &self.out_full_p9;
        let ups_pa = &self.ups_pa;
        let lx_pb = wx_p0.lx_p.clone();
        let pos_pc = wx_p0.pos_p.clone();
        let bundled_pd = crate::lower::types::is_bundle_f(out_full_p9);
        let (name_pu, wx1_pv) = crate::lower::node_::fresh_name_f(wx_p0, &crate::prelude::Text::lit("arm"));
        let (up_id_p10, wx2_p11) = crate::lower::node_::add_gn_f(&wx1_pv, &crate::prelude::Text::from(format!("{}_fired", &name_pu)), &(if bundled_pd { crate::lower::model::OutTy::OutUnit } else { out_ty_p7.clone() }), &crate::lower::node_::GnKind::GnNamed, &crate::prelude::Nat::from(0u32));
        let row_name_pe = crate::prelude::Text::from(format!("{}Arm{}", &wx_p0.node_p, &crate::lower::node_::keyed::row_suffix_f(wx_p0)));
        let bodies_p6x = bodies_p6.clone();
        let guards_p5x = guards_p5.clone();
        let layer_p8x = layer_p8.clone();
        let menv_p1x = menv_p1.clone();
        let out_full_p9x = out_full_p9.clone();
        let out_ty_p7x = out_ty_p7.clone();
        let pats_p3x = pats_p3.clone();
        let scrut_p2x = scrut_p2.clone();
        let sty_p4x = sty_p4.clone();
        let ups_pax = ups_pa.clone();
        let wx_p0x = wx_p0.clone();
        crate::prelude::call_value(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(&bodies_p6x)), (crate::prelude::Array::new(), wx2_p11.clone()), {
            let menv_p1xx = menv_p1x.clone();
            let lx_pbx = lx_pb.clone();
            let pats_p3xx = pats_p3x.clone();
            let sty_p4xx = sty_p4x.clone();
            let guards_p5xx = guards_p5x.clone();
            let bodies_p6xx = bodies_p6x.clone();
            let row_name_pex = row_name_pe.clone();
            let name_pux = name_pu.clone();
            let wx_p0xx = wx_p0x.clone();
            let ups_paxx = ups_pax.clone();
            ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Array<ClauseRow>, crate::lower::node_::Wx), crate::prelude::Nat)| {
                let menv_p1xxy = menv_p1xx.clone();
                let lx_pbxy = lx_pbx.clone();
                let pats_p3xxy = pats_p3xx.clone();
                let sty_p4xxy = sty_p4xx.clone();
                let guards_p5xxy = guards_p5xx.clone();
                let bodies_p6xxy = bodies_p6xx.clone();
                let row_name_pexy = row_name_pex.clone();
                let name_puxy = name_pux.clone();
                let wx_p0xxy = wx_p0xx.clone();
                let ups_paxxy = ups_paxx.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let (acc_p12, w_p13) = p0;
                    let i_p14 = p1;
                    crate::prelude::call_then(start_arm_row_of_f(w_p13.clone(), menv_p1xxy.clone(), lx_pbxy.clone(), crate::prelude::Array::from(vec![crate::prelude::or(&crate::prelude::index(&pats_p3xxy, &i_p14), &::std::option::Option::None)]), crate::prelude::Array::from(vec![sty_p4xxy.clone()]), crate::prelude::or(&crate::prelude::index(&guards_p5xxy, &i_p14), &::std::option::Option::None), crate::prelude::or(&crate::prelude::index(&bodies_p6xxy, &i_p14), &dummy_block_s_p()), crate::prelude::Text::from(format!("{}{}", &row_name_pexy, &i_p14)), name_puxy.clone(), true, true, crate::lower::model::OutTy::OutWeak(wx_p0xxy.node_p.clone()), crate::prelude::Array::new(), ups_paxxy.clone(), crate::prelude::Array::new(), false), move |arm_row_of_f_86326: ClauseRow| {
                        let cr_p15 = arm_row_of_f_86326;
                        ::prism_rtl::Turn::Finished((crate::prelude::push(&acc_p12, &cr_p15), cr_p15.parent_p.clone()))
                    })
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Array<ClauseRow>, crate::lower::node_::Wx), crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<ClauseRow>, crate::lower::node_::Wx)>>>
        }), move |fold_86249: (crate::prelude::Array<ClauseRow>, crate::lower::node_::Wx)| {
            let (rows_p16, wx3_p17) = fold_86249;
            let width_pf = crate::prelude::fold(&rows_p16, &crate::prelude::Nat::from(0u32), &(|acc_p18: &crate::prelude::Nat, cr_p19: &ClauseRow| crate::prelude::max(acc_p18, &cr_p19.width_p)));
            let cases_pg = crate::prelude::each(&rows_p16, &(|cr_p1a: &ClauseRow| cr_p1a.case_p.clone()));
            let is_dyn_ph = &layer_p8x == &crate::lower::types::Layer::LyDyn;
            let plain_rows_pi = crate::prelude::filter(&rows_p16, &(|cr_p1b: &ClauseRow| is_some_f(&cr_p1b.plain_o)));
            let all_plain_pj = &crate::prelude::len(&plain_rows_pi) == &crate::prelude::len(&rows_p16);
            let res_pk = crate::prelude::Text::from(format!("{}_res", &name_pu));
            let tail_pl = crate::prelude::append(&crate::prelude::append(&crate::prelude::Array::from(vec![crate::lower::model::Ex::XWeak(::std::rc::Rc::new(crate::lower::model::Ex::XSelf))]), &crate::lower::node_::keyed::hosted_passed_f(&wx_p0x)), &crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx]));
            let row_obj_pm = crate::lower::model::OutTy::OutObj(::std::rc::Rc::new(crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Row")), crate::prelude::Array::new())));
            let kept_pn = crate::lower::model::Do::DoAssign(crate::lower::model::Ex::XDeref(::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), res_pk.clone())), crate::prelude::Text::lit("borrow_mut"), crate::prelude::Array::new()))), crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Some")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("row"))), crate::prelude::Text::lit("result_dynamic"), crate::prelude::Array::new())])));
            let kept_plain_po = crate::lower::model::Do::DoAssign(crate::lower::model::Ex::XDeref(::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), res_pk.clone())), crate::prelude::Text::lit("borrow_mut"), crate::prelude::Array::new()))), crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Some")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("row"))), crate::prelude::Text::lit("result_value"), crate::prelude::Array::new())])));
            let gaps_pp = row_gaps_f(&rows_p16, &width_pf);
            let all_plain_pjz = all_plain_pj;
            let bundled_pdz = bundled_pd;
            let cases_pgz = cases_pg.clone();
            let gaps_ppz = gaps_pp.clone();
            let is_dyn_phz = is_dyn_ph;
            let kept_pnz = kept_pn.clone();
            let kept_plain_poz = kept_plain_po.clone();
            let lx_pbz = lx_pb.clone();
            let name_puz = name_pu.clone();
            let out_ty_p7xz = out_ty_p7x.clone();
            let plain_rows_piz = plain_rows_pi.clone();
            let pos_pcz = pos_pc.clone();
            let res_pkz = res_pk.clone();
            let row_obj_pmz = row_obj_pm.clone();
            let rows_p16z = rows_p16.clone();
            let scrut_p2xz = scrut_p2x.clone();
            let tail_plz = tail_pl.clone();
            let up_id_p10z = up_id_p10.clone();
            let width_pfz = width_pf.clone();
            let wx_p0xz = wx_p0x.clone();
            let wx3_p17z = wx3_p17.clone();
            let k_let87440 = move |v87440: KeptParts| {
                let bundle_pq = v87440;
                let arms_pr = crate::prelude::fold(&cases_pgz, &crate::prelude::Array::new(), &(|built_p1c: &crate::prelude::Array<crate::lower::model::XArm>, c_p1d: &GenCase| {
                    let i_p1e = crate::prelude::len(built_p1c);
                    let made_p1f = crate::lower::expr::try_of_f(&crate::lower::model::Ex::XCall(crate::lower::model::ref_child_f(&crate::lower::site_ref_f(&lx_pbz, &c_p1d.node_p.name_p), &crate::prelude::Text::lit("build")), crate::prelude::append(&crate::prelude::append(&crate::prelude::Array::from(vec![crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("path"))))]), &c_p1d.passed_p), &tail_plz)));
                    let set_p1g = gap_set_f(&name_puz, &crate::prelude::or(&crate::prelude::index(&gaps_ppz, &i_p1e), &::std::option::Option::None));
                    let keeps_p1h = crate::prelude::append(&crate::prelude::append(&(if is_dyn_phz {
                        crate::prelude::Array::from(vec![kept_pnz.clone()])
                    } else {
                        if all_plain_pjz {
                            crate::prelude::Array::from(vec![kept_plain_poz.clone()])
                        } else {
                            crate::prelude::Array::new()
                        }
                    }), &bundle_pq.keeps_p), &set_p1g);
                    let body_p1i = if &crate::prelude::len(&keeps_p1h) == &crate::prelude::Nat::from(0u32) {
                        crate::lower::model::Ex::XCast(::std::rc::Rc::new(made_p1f.clone()), row_obj_pmz.clone())
                    } else {
                        crate::lower::model::Ex::XBlock(crate::prelude::append(&crate::prelude::Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("row")), made_p1f.clone())]), &keeps_p1h), ::std::rc::Rc::new(crate::lower::model::Ex::XCast(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("row"))), row_obj_pmz.clone())))
                    };
                    crate::prelude::push(built_p1c, &crate::lower::model::XArm { pat_p: c_p1d.pat_p.clone(), conds_p: c_p1d.conds_p.clone(), body_p: body_p1i.clone() })
                }));
                let select_ps = with_row_base_f(&wx_p0xz, &crate::prelude::Text::lit("self"), &pos_pcz, &crate::lower::types::own_f(&crate::lower::expr::arms_value_f(&crate::lower::model::Ex::XTuple(crate::prelude::Array::from(vec![scrut_p2xz.clone()])), &arms_pr, &crate::prelude::Text::lit("\'select"), &crate::lower::model::OutTy::OutObj(::std::rc::Rc::new(crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Row")), crate::prelude::Array::new()))))));
                let wx4_pt = {
                    let mut this: crate::lower::node_::Wx = bundle_pq.wx_p.clone();
                    this.pos_p = crate::lower::model::Pos { scope_p: pos_pcz.scope_p.clone(), at_p: &pos_pcz.at_p + &width_pfz };
                    this.gens_p = crate::prelude::push(&this.gens_p, &crate::lower::model::GenDef { name_p: name_puz.clone(), pos_p: pos_pcz.clone(), at_p: crate::lower::node_::finish::place_at_f(&wx_p0xz, &crate::prelude::Text::lit("self"), &pos_pcz), source_p: crate::lower::model::Ex::XUnit, value_ty_p: crate::lower::model::OutTy::OutUnit, select_p: select_ps.clone(), transparent_p: true, width_p: width_pfz.clone(), moved_p: crate::prelude::or(&crate::lower::node_::finish::hosted_rows_o(&wx_p0xz), &crate::prelude::Text::lit("")), early_p: false, gappy_p: is_gappy_f(&gaps_ppz), rebased_p: false });
                    this.gen_holds_p = crate::prelude::push(&this.gen_holds_p, &(name_puz.clone(), crate::prelude::Array::new()));
                    this.rows_p = crate::prelude::fold(&cases_pgz, &this.rows_p, &(|acc_p1j: &crate::prelude::Array<crate::lower::model::NodeDef>, gc_p1k: &GenCase| crate::prelude::append(&crate::prelude::push(acc_p1j, &gc_p1k.node_p), &gc_p1k.node_p.children_p)));
                    this.getters_p = crate::prelude::push(&crate::prelude::push(&this.getters_p, &gen_up_f(&name_puz, &crate::lower::node_::gn_of_f(&wx3_p17z, &up_id_p10z).name_p, &crate::lower::node_::gn_of_f(&wx3_p17z, &up_id_p10z).ty_p)), &gen_up_above_f(&name_puz, &crate::lower::node_::gn_of_f(&wx3_p17z, &up_id_p10z).name_p));
                    this
                };
                if bundled_pdz {
                    ::prism_rtl::Turn::Finished((wx4_pt.clone(), crate::lower::node_::Wres::WrParts(bundle_pq.results_p.clone())))
                } else {
                    if is_dyn_phz {
                        ::prism_rtl::Turn::Finished(kept_dyn_result_f(&wx4_pt, &name_puz, &rows_p16z))
                    } else {
                        if &crate::prelude::len(&plain_rows_piz) > &crate::prelude::Nat::from(0u32) {
                            if all_plain_pjz {
                                {
                                    let read_p1l = crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), res_pkz.clone())), crate::prelude::Text::lit("borrow"), crate::prelude::Array::new())), crate::prelude::Text::lit("as_ref"), crate::prelude::Array::new())), crate::prelude::Text::lit("expect"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XStr(crate::prelude::Text::lit("an arm built before what reads its result"))]))));
                                    let wx5_p1m = {
                                        let mut this: crate::lower::node_::Wx = wx4_pt.clone();
                                        this.taken_p = crate::prelude::push(&this.taken_p, &res_pkz);
                                        this.fields_p = crate::prelude::push(&this.fields_p, &(res_pkz.clone(), crate::lower::model::OutTy::OutCell(::std::rc::Rc::new(crate::lower::model::OutTy::OutOpt(::std::rc::Rc::new(out_ty_p7xz.clone())))), crate::prelude::Text::lit("the arm\'s plain result, kept from its build on")));
                                        this.inits_p = crate::prelude::push(&this.inits_p, &(res_pkz.clone(), crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::RefCell::new")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XNone]))));
                                        this
                                    };
                                    ::prism_rtl::Turn::Finished((wx5_p1m.clone(), crate::lower::node_::Wres::WrLate(read_p1l.clone(), out_ty_p7xz.clone())))
                                }
                            } else {
                                {
                                    let wx5_p1n = {
                                        let mut this: crate::lower::node_::Wx = wx4_pt.clone();
                                        this.build_p = crate::prelude::push(&this.build_p, &crate::lower::expr::internal_bug_do_f(&crate::prelude::Text::lit("a building `match` or `if` whose arms do not all end on a plain result")));
                                        this
                                    };
                                    ::prism_rtl::Turn::Finished((wx5_p1n.clone(), crate::lower::node_::Wres::WrUnit))
                                }
                            }
                        } else {
                            if &out_ty_p7xz == &crate::lower::model::OutTy::OutUnit {
                                ::prism_rtl::Turn::Finished((wx4_pt.clone(), crate::lower::node_::Wres::WrUnit))
                            } else {
                                ::prism_rtl::Turn::Finished((wx4_pt.clone(), crate::lower::node_::Wres::WrEv(crate::lower::node_::ev_ref_of_f(&wx4_pt, &up_id_p10z))))
                            }
                        }
                    }
                }
            };
            if bundled_pd {
                crate::prelude::call_then(start_rows_bundle_f(rows_p16.clone()), move |rows_bundle_f_87487: crate::prelude::Array<RowPart>| crate::prelude::call_then(start_keep_parts_f(wx3_p17.clone(), name_pu.clone(), rows_bundle_f_87487, crate::lower::node_::keyed::bundle_part_tys_f(&out_full_p9x)), move |keep_parts_f_87465: KeptParts| k_let87440(keep_parts_f_87465)))
            } else {
                k_let87440(KeptParts { wx_p: wx3_p17.clone(), keeps_p: crate::prelude::Array::new(), results_p: crate::prelude::Array::new() })
            }
        })
    }
}

/// `Start BuildingChoiceLine, x`: what the function value is when passed to `@Run`.
pub fn start_building_choice_line_f(wx_p0: crate::lower::node_::Wx, menv_p1: crate::lower::types::Env, scrut_p2: crate::lower::model::Ex, pats_p3: crate::prelude::Array<::std::option::Option<crate::syntax::Pattern>>, sty_p4: crate::check::types::Ty, guards_p5: crate::prelude::Array<::std::option::Option<crate::syntax::Expr>>, bodies_p6: crate::prelude::Array<crate::syntax::Block>, out_ty_p7: crate::lower::model::OutTy, layer_p8: crate::lower::types::Layer, out_full_p9: crate::check::types::Ty, ups_pa: crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text)>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::node_::Wres)>> {
    ::std::rc::Rc::new(BuildingChoiceLine { wx_p0, menv_p1, scrut_p2, pats_p3, sty_p4, guards_p5, bodies_p6, out_ty_p7, layer_p8, out_full_p9, ups_pa })
}

/// ```prism
/// KeptDynResult: fn Wx, Text, [ClauseRow] -> ((Wx, Wres))
/// ```
pub fn kept_dyn_result_f(wx_p0: &crate::lower::node_::Wx, name_p1: &crate::prelude::Text, rows_p2: &crate::prelude::Array<ClauseRow>) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    let t_p3 = match crate::prelude::or(&crate::prelude::index(&crate::prelude::each(rows_p2, &(|cr_p4: &ClauseRow| cr_p4.result_ty_o.clone())), &crate::prelude::Nat::from(0u32)), &::std::option::Option::None) {
        ::std::option::Option::Some(x_p5) => x_p5,
        ::std::option::Option::None => crate::lower::model::OutTy::OutUnit,
    };
    kept_dyn_f(wx_p0, name_p1, &t_p3, &crate::prelude::fold(rows_p2, &crate::prelude::Array::new(), &(|acc_p6: &crate::prelude::Array<crate::lower::node_::Read>, cr_p7: &ClauseRow| crate::lower::node_::union_reads_f(acc_p6, &cr_p7.result_reads_p))))
}

/// ```prism
/// KeptDyn: fn Wx, Text, OutTy, [Read] -> ((Wx, Wres))
/// ```
pub fn kept_dyn_f(wx_p0: &crate::lower::node_::Wx, name_p1: &crate::prelude::Text, t_p2: &crate::lower::model::OutTy, parent_reads_p3: &crate::prelude::Array<crate::lower::node_::Read>) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    let res_p4 = crate::prelude::Text::from(format!("{}_res", name_p1));
    let getter_p5 = crate::prelude::Text::from(format!("{}_value", name_p1));
    let behind_p6 = crate::prelude::fold(parent_reads_p3, &crate::prelude::Array::from(vec![crate::lower::node_::Read::OwnRead(res_p4.clone())]), &(|a_p9: &crate::prelude::Array<crate::lower::node_::Read>, rd_pa: &crate::lower::node_::Read| match rd_pa {
        crate::lower::node_::Read::ParentRead(m_pb) => crate::lower::node_::add_read_f(a_p9, &crate::lower::node_::Read::OwnRead(m_pb.clone())),
        crate::lower::node_::Read::OwnRead(m_pc) => crate::lower::node_::add_read_f(a_p9, &crate::lower::node_::Read::OwnRead(m_pc.clone())),
    }));
    let read_p7 = crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), res_p4.clone())), crate::prelude::Text::lit("borrow"), crate::prelude::Array::new())), crate::prelude::Text::lit("as_ref"), crate::prelude::Array::new())), crate::prelude::Text::lit("expect"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XStr(crate::prelude::Text::lit("a generation built with its block"))]))), crate::prelude::Text::lit("sample"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx]));
    let wx2_p8 = {
        let mut this: crate::lower::node_::Wx = wx_p0.clone();
        this.taken_p = crate::prelude::append(&this.taken_p, &crate::prelude::Array::from(vec![res_p4.clone(), getter_p5.clone(), crate::prelude::Text::from(format!("{}_result_moved", name_p1))]));
        this.fields_p = crate::prelude::push(&this.fields_p, &(res_p4.clone(), crate::lower::model::OutTy::OutCell(::std::rc::Rc::new(crate::lower::model::OutTy::OutOpt(::std::rc::Rc::new(crate::lower::model::OutTy::OutDyn(::std::rc::Rc::new(t_p2.clone())))))), crate::prelude::Text::lit("the generation\'s dynamic result")));
        this.inits_p = crate::prelude::push(&this.inits_p, &(res_p4.clone(), crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::RefCell::new")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XNone]))));
        this.getters_p = crate::prelude::push(&this.getters_p, &crate::lower::model::MethDef { name_p: getter_p5.clone(), recv_p: crate::lower::model::Recv::RecvRef, params_p: crate::prelude::Array::new(), cx_p: crate::lower::model::CxArg::CxRef, ret_p: t_p2.clone(), body_p: crate::prelude::Array::new(), tail_p: read_p7.clone(), doc_p: crate::prelude::Text::lit("The generation\'s dynamic result at the read point.") });
        this.dyn_reads_p = crate::prelude::insert(&this.dyn_reads_p, &getter_p5, &behind_p6);
        this.clause_results_p = crate::prelude::push(&this.clause_results_p, name_p1);
        this
    };
    (wx2_p8.clone(), crate::lower::node_::Wres::WrDyn(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), getter_p5.clone(), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx])), crate::prelude::Array::from(vec![crate::lower::node_::Read::OwnRead(getter_p5.clone())]), t_p2.clone()))
}

/// ```prism
/// MatchGenLine: unbounded fn Wx, Env, Expr, [Arm], Expr -> ((Wx, Wres))
/// ```
pub fn match_gen_line_f(wx_p0: &crate::lower::node_::Wx, menv_p1: &crate::lower::types::Env, s_p2: &crate::syntax::Expr, arms_p3: &crate::prelude::Array<crate::syntax::Arm>, e_p4: &crate::syntax::Expr) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    building_choice_line_f(wx_p0, menv_p1, &crate::lower::expr::argument_f(&wx_p0.lx_p, menv_p1, s_p2), &crate::prelude::each(arms_p3, &(|a_p5: &crate::syntax::Arm| a_p5.pattern_o.clone())), &crate::lower::type_at_f(&wx_p0.lx_p, &s_p2.span_p), &crate::prelude::each(arms_p3, &(|a_p6: &crate::syntax::Arm| a_p6.guard_o.clone())), &crate::prelude::each(arms_p3, &(|a_p7: &crate::syntax::Arm| a_p7.body_p.clone())), &choice_out_ty_f(&wx_p0.lx_p, e_p4), &result_layer_f(&crate::lower::type_at_f(&wx_p0.lx_p, &e_p4.span_p)), &crate::lower::node_::def::line_out_full_f(&wx_p0.lx_p, e_p4), &crate::prelude::Array::new())
}

/// ```prism
/// ChoiceOutTy: unbounded fn Lx, Expr -> OutTy
/// ```
pub fn choice_out_ty_f(lx_p0: &crate::lower::Lx, e_p1: &crate::syntax::Expr) -> crate::lower::model::OutTy {
    crate::lower::types::out_ty_of_f(lx_p0, &crate::lower::types::out_of_f(&crate::lower::type_at_f(lx_p0, &e_p1.span_p)))
}

/// ```prism
/// IfGenLine: unbounded fn Wx, Env, Cond, Block, Block, Expr -> ((Wx, Wres))
/// ```
pub fn if_gen_line_f(wx_p0: &crate::lower::node_::Wx, menv_p1: &crate::lower::types::Env, c_p2: &crate::syntax::Cond, then_b_p3: &crate::syntax::Block, else_b_p4: &crate::syntax::Block, e_p5: &crate::syntax::Expr) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    match c_p2 {
        crate::syntax::Cond::CondExpr(x_p6) => building_choice_line_f(wx_p0, menv_p1, &crate::lower::model::Ex::XUnit, &crate::prelude::Array::from(vec![::std::option::Option::None, ::std::option::Option::None]), &crate::check::types::Ty::TyCon(crate::prelude::Text::lit("unit"), crate::prelude::Array::new()), &crate::prelude::Array::from(vec![::std::option::Option::Some((**x_p6).clone()), ::std::option::Option::None]), &crate::prelude::Array::from(vec![then_b_p3.clone(), else_b_p4.clone()]), &choice_out_ty_f(&wx_p0.lx_p, e_p5), &result_layer_f(&crate::lower::type_at_f(&wx_p0.lx_p, &e_p5.span_p)), &crate::lower::node_::def::line_out_full_f(&wx_p0.lx_p, e_p5), &crate::prelude::Array::new()),
        crate::syntax::Cond::CondBind(p_p7, x_p8, g_o9) => building_choice_line_f(wx_p0, menv_p1, &crate::lower::expr::argument_f(&wx_p0.lx_p, menv_p1, &**x_p8), &crate::prelude::Array::from(vec![::std::option::Option::Some(p_p7.clone()), ::std::option::Option::None]), &crate::lower::type_at_f(&wx_p0.lx_p, &x_p8.span_p), &crate::prelude::Array::from(vec![(**g_o9).clone(), ::std::option::Option::None]), &crate::prelude::Array::from(vec![then_b_p3.clone(), else_b_p4.clone()]), &choice_out_ty_f(&wx_p0.lx_p, e_p5), &result_layer_f(&crate::lower::type_at_f(&wx_p0.lx_p, &e_p5.span_p)), &crate::lower::node_::def::line_out_full_f(&wx_p0.lx_p, e_p5), &crate::prelude::Array::new()),
    }
}

/// ```prism
/// let dummyBlockS
/// ```
pub fn dummy_block_s_p() -> crate::syntax::Block {
    crate::syntax::Block { stmts_p: crate::prelude::Array::new(), inline_p: true, span_p: crate::syntax::Range { start_p: crate::prelude::Nat::from(0u32), end_p: crate::prelude::Nat::from(0u32) } }
}

/// ```prism
/// GenRowOf: unbounded fn Wx, Env, Block, OutTy, Text, Text -> GenRow
/// ```
pub fn gen_row_of_f(wx_p0: &crate::lower::node_::Wx, menv_p1: &crate::lower::types::Env, body_p2: &crate::syntax::Block, vt_p3: &crate::lower::model::OutTy, row_name_p4: &crate::prelude::Text, gen_name_p5: &crate::prelude::Text) -> GenRow {
    let lx_p6 = wx_p0.lx_p.clone();
    let up_name_p7 = crate::prelude::Text::from(format!("{}_up", gen_name_p5));
    let r00_p8 = crate::lower::node_::under_its_path_f(&crate::lower::node_::new_wx_f(&lx_p6, row_name_p4, &crate::prelude::Array::from(vec![(crate::prelude::Text::lit("value"), vt_p3.clone(), crate::prelude::Text::lit("the generation\'s value, `_`")), (crate::prelude::Text::lit("parent"), crate::lower::model::OutTy::OutWeak(wx_p0.node_p.clone()), crate::prelude::Text::lit("the node of the `rebuild`"))]), &crate::prelude::Array::from(vec![(crate::prelude::Text::lit("value"), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("value")))))]), &crate::prelude::Array::from(vec![(crate::prelude::Text::lit("parent"), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("parent")))))]), &crate::prelude::Array::new(), &crate::prelude::Map::new(), &crate::prelude::append(&crate::lower::node_::node_hooks_p(), &crate::prelude::Array::from(vec![crate::prelude::Text::lit("value"), crate::prelude::Text::lit("parent"), crate::prelude::Text::lit("result"), crate::prelude::Text::lit("result_dynamic")])), &wx_p0.inlining_p, &crate::lower::node_::finish::hosted_rows_o(wx_p0)), &crate::lower::node_::finish::hosted_rows_o(wx_p0));
    let r0_p9 = {
        let mut this: crate::lower::node_::Wx = gen_current_f(&r00_p8, wx_p0, gen_name_p5);
        this.whole_result_at_p = bundle_result_key_f(&lx_p6, body_p2);
        this
    };
    let (p1_pe, r1_pf, ports_pg) = row_env_f(wx_p0, &r0_p9, menv_p1, body_p2);
    let be_pa = crate::lower::types::bind_f(&build_spelling_f(&ports_pg), &crate::prelude::Text::lit("_"), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("value")), crate::lower::types::Holding::Owned, vt_p3.clone()));
    let me_pb = crate::lower::types::bind_f(&ports_pg, &crate::prelude::Text::lit("_"), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::lit("value")), crate::lower::types::Holding::Owned, vt_p3.clone()));
    let r2_pc = crate::lower::node_::def::block_into_f(&r1_pf, &be_pa, &me_pb, body_p2);
    let (r3_p16, dyn_result_o17, plain_result_o18) = match &r2_pc.result_p {
        crate::lower::node_::Wres::WrEv(r_ph) => (crate::lower::node_::connect_f(&r2_pc, r_ph, &crate::lower::node_::Sk::SkUp(up_name_p7.clone())), ::std::option::Option::None, ::std::option::Option::None),
        crate::lower::node_::Wres::WrDyn(ex_pi, result_reads_pj, rt_pk) => (gen_result_f(&r2_pc, gen_name_p5, ex_pi, result_reads_pj, rt_pk), ::std::option::Option::Some(rt_pk.clone()), ::std::option::Option::None),
        crate::lower::node_::Wres::WrPlain(ex_pl, rt_pm) => {
            let (f_po, rf_pp) = crate::lower::node_::fresh_name_f(&r2_pc, &crate::prelude::Text::lit("result"));
            let r2p_pn = {
                let mut this: crate::lower::node_::Wx = rf_pp.clone();
                this.lets_p = crate::prelude::push(&this.lets_p, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaBind(f_po.clone())), rt_pm.clone()), ex_pl.clone()));
                this.fields_p = crate::prelude::push(&this.fields_p, &(f_po.clone(), rt_pm.clone(), crate::prelude::Text::lit("the generation\'s plain result")));
                this.inits_p = crate::prelude::push(&this.inits_p, &(f_po.clone(), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(f_po.clone())))));
                this.getters_p = crate::prelude::push(&this.getters_p, &crate::lower::model::MethDef { name_p: crate::prelude::Text::lit("result_value"), recv_p: crate::lower::model::Recv::RecvRef, params_p: crate::prelude::Array::new(), cx_p: crate::lower::model::CxArg::CxNone, ret_p: rt_pm.clone(), body_p: crate::prelude::Array::new(), tail_p: crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), f_po.clone()))), doc_p: crate::prelude::Text::lit("The generation\'s plain result, which the `rebuild`\'s dynamic is while the generation stands.") });
                this
            };
            (r2p_pn.clone(), ::std::option::Option::None, ::std::option::Option::Some(rt_pm.clone()))
        },
        crate::lower::node_::Wres::WrLate(ex_pq, rt_pr) => ({
            let mut this: crate::lower::node_::Wx = r2_pc.clone();
            this.getters_p = crate::prelude::push(&this.getters_p, &crate::lower::model::MethDef { name_p: crate::prelude::Text::lit("result_value"), recv_p: crate::lower::model::Recv::RecvRef, params_p: crate::prelude::Array::new(), cx_p: crate::lower::model::CxArg::CxNone, ret_p: rt_pr.clone(), body_p: crate::prelude::Array::new(), tail_p: ex_pq.clone(), doc_p: crate::prelude::Text::lit("The generation\'s plain result, which the `rebuild`\'s dynamic is while the generation stands.") });
            this
        }, ::std::option::Option::None, ::std::option::Option::Some(rt_pr.clone())),
        crate::lower::node_::Wres::WrParts(parts_ps) => {
            let full_pt = match &crate::prelude::or(&crate::prelude::index(&body_p2.stmts_p, &crate::syntax::lexer::chars::dec_f(&crate::prelude::len(&body_p2.stmts_p))), &crate::lower::expr::dummy_stmt_l_p()).kind_p {
                crate::syntax::StmtKind::SExpr(y_pv) => crate::lower::node_::def::line_out_full_f(&lx_p6, y_pv),
                _ => crate::check::types::Ty::TyErr,
            };
            let rt_pu = crate::lower::types::out_ty_of_f(&lx_p6, &full_pt);
            let (value_p10, late_p11, rw_p12) = crate::lower::node_::def::whole_of_results_f(&r2_pc, &crate::prelude::Text::lit("result"), &crate::prelude::Text::lit("the bundle the generation ends on"), &crate::lower::node_::keyed::bundle_part_tys_f(&full_pt), parts_ps);
            if late_p11 {
                ({
                    let mut this: crate::lower::node_::Wx = rw_p12.clone();
                    this.getters_p = crate::prelude::push(&this.getters_p, &crate::lower::model::MethDef { name_p: crate::prelude::Text::lit("result_value"), recv_p: crate::lower::model::Recv::RecvRef, params_p: crate::prelude::Array::new(), cx_p: crate::lower::model::CxArg::CxNone, ret_p: rt_pu.clone(), body_p: crate::prelude::Array::new(), tail_p: value_p10.clone(), doc_p: crate::prelude::Text::lit("The generation\'s plain result, which the `rebuild`\'s dynamic is while the generation stands.") });
                    this
                }, ::std::option::Option::None, ::std::option::Option::Some(rt_pu.clone()))
            } else {
                {
                    let (f_p14, rf_p15) = crate::lower::node_::fresh_name_f(&rw_p12, &crate::prelude::Text::lit("result"));
                    let r2p_p13 = {
                        let mut this: crate::lower::node_::Wx = rf_p15.clone();
                        this.lets_p = crate::prelude::push(&this.lets_p, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaBind(f_p14.clone())), rt_pu.clone()), value_p10.clone()));
                        this.fields_p = crate::prelude::push(&this.fields_p, &(f_p14.clone(), rt_pu.clone(), crate::prelude::Text::lit("the generation\'s plain result")));
                        this.inits_p = crate::prelude::push(&this.inits_p, &(f_p14.clone(), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(f_p14.clone())))));
                        this.getters_p = crate::prelude::push(&this.getters_p, &crate::lower::model::MethDef { name_p: crate::prelude::Text::lit("result_value"), recv_p: crate::lower::model::Recv::RecvRef, params_p: crate::prelude::Array::new(), cx_p: crate::lower::model::CxArg::CxNone, ret_p: rt_pu.clone(), body_p: crate::prelude::Array::new(), tail_p: crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), f_p14.clone()))), doc_p: crate::prelude::Text::lit("The generation\'s plain result, which the `rebuild`\'s dynamic is while the generation stands.") });
                        this
                    };
                    (r2p_p13.clone(), ::std::option::Option::None, ::std::option::Option::Some(rt_pu.clone()))
                }
            }
        },
        _ => (r2_pc.clone(), ::std::option::Option::None, ::std::option::Option::None),
    };
    let r4_pd = gen_hears_f(&r3_p16, gen_name_p5);
    GenRow { node_p: crate::lower::node_::finish::finish_node_f(&r4_pd, row_name_p4, &crate::prelude::append(&crate::prelude::Array::from(vec![(crate::prelude::Text::lit("value"), vt_p3.clone()), (crate::prelude::Text::lit("parent"), crate::lower::model::OutTy::OutWeak(wx_p0.node_p.clone()))]), &crate::lower::node_::keyed::hosted_params_f(wx_p0)), &true), parent_p: gen_marked_f(&p1_pe, gen_name_p5, &r3_p16), dyn_result_o: dyn_result_o17.clone(), plain_result_o: plain_result_o18.clone() }
}

/// ```prism
/// GenResult: fn Wx, Text, Ex, [Read], OutTy -> Wx
/// ```
pub fn gen_result_f(r_p0: &crate::lower::node_::Wx, gen_name_p1: &crate::prelude::Text, ex_p2: &crate::lower::model::Ex, result_reads_p3: &crate::prelude::Array<crate::lower::node_::Read>, rt_p4: &crate::lower::model::OutTy) -> crate::lower::node_::Wx {
    gen_result_named_f(r_p0, &crate::prelude::Text::lit("result"), &crate::prelude::Text::lit("result_dynamic"), &crate::prelude::Text::from(format!("{}_result_moved", gen_name_p1)), ex_p2, result_reads_p3, rt_p4)
}

/// ```prism
/// GenResultNamed: fn Wx, Text, Text, Text, Ex, [Read], OutTy -> Wx
/// ```
pub fn gen_result_named_f(r_p0: &crate::lower::node_::Wx, getter_p1: &crate::prelude::Text, dynamic_p2: &crate::prelude::Text, moved_p3: &crate::prelude::Text, ex_p4: &crate::lower::model::Ex, result_reads_p5: &crate::prelude::Array<crate::lower::node_::Read>, rt_p6: &crate::lower::model::OutTy) -> crate::lower::node_::Wx {
    let own_behind_p7 = crate::prelude::filter(&crate::lower::node_::finish::reads_closed_f(&r_p0.dyn_reads_p, result_reads_p5), &(|rd_pa: &crate::lower::node_::Read| match rd_pa {
        crate::lower::node_::Read::OwnRead(_) => true,
        crate::lower::node_::Read::ParentRead(_) => false,
    }));
    let made_p8 = crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Dynamic::of")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XClosure(true, crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("cx"))]), ::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("me"))), getter_p1.clone(), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx])))), crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Rc::new")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Port::new")), crate::prelude::Array::new())]))))]));
    let doc_p9 = crate::prelude::Text::from(format!("The generation\'s result as a dynamic, which the block keeps while the generation is current; the block hears it move through `{}`, not through the dynamic\'s port.", moved_p3));
    let mut this: crate::lower::node_::Wx = r_p0.clone();
    this.getters_p = crate::prelude::append(&this.getters_p, &crate::prelude::Array::from(vec![crate::lower::model::MethDef { name_p: getter_p1.clone(), recv_p: crate::lower::model::Recv::RecvRef, params_p: crate::prelude::Array::new(), cx_p: crate::lower::model::CxArg::CxRef, ret_p: rt_p6.clone(), body_p: crate::prelude::Array::new(), tail_p: ex_p4.clone(), doc_p: crate::prelude::Text::lit("The generation\'s result, which its block reads.") }, crate::lower::model::MethDef { name_p: dynamic_p2.clone(), recv_p: crate::lower::model::Recv::RecvRc, params_p: crate::prelude::Array::new(), cx_p: crate::lower::model::CxArg::CxNone, ret_p: crate::lower::model::OutTy::OutDyn(::std::rc::Rc::new(rt_p6.clone())), body_p: crate::prelude::Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("me")), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XSelf)))]), tail_p: made_p8.clone(), doc_p: doc_p9.clone() }]));
    this.result_moved_p = if &crate::prelude::len(&own_behind_p7) > &crate::prelude::Nat::from(0u32) {
        crate::prelude::push(&this.result_moved_p, &(moved_p3.clone(), own_behind_p7.clone()))
    } else {
        this.result_moved_p.clone()
    };
    this
}

/// ```prism
/// RowPartsOut: unbounded fn Wx, Text, Text, [Wres] -> ((Wx, [RowPart]))
/// ```
pub fn row_parts_out_f(r_p0: &crate::lower::node_::Wx, gen_name_p1: &crate::prelude::Text, prefix_p2: &crate::prelude::Text, parts_p3: &crate::prelude::Array<crate::lower::node_::Wres>) -> (crate::lower::node_::Wx, crate::prelude::Array<RowPart>) {
    crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(parts_p3)), (r_p0.clone(), crate::prelude::Array::new()), {
        let prefix_p2x = prefix_p2.clone();
        let gen_name_p1x = gen_name_p1.clone();
        let parts_p3x = parts_p3.clone();
        ::std::rc::Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::prelude::Array<RowPart>), crate::prelude::Nat)| {
            let prefix_p2xy = prefix_p2x.clone();
            let gen_name_p1xy = gen_name_p1x.clone();
            let parts_p3xy = parts_p3x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (w_p4, acc_p5) = p0;
                let i_p6 = p1;
                {
                    let place_p7 = if &prefix_p2xy == &crate::prelude::Text::lit("") {
                        crate::prelude::Text::from(format!("p{}", &i_p6))
                    } else {
                        crate::prelude::Text::from(format!("{}_{}", &prefix_p2xy, &i_p6))
                    };
                    crate::prelude::call_then(start_row_part_out_f(w_p4.clone(), gen_name_p1xy.clone(), place_p7.clone(), crate::prelude::or(&crate::prelude::index(&parts_p3xy, &i_p6), &crate::lower::node_::Wres::WrUnit)), move |row_part_out_f_100497: (crate::lower::node_::Wx, RowPart)| {
                        let (w2_p8, part_p9) = row_part_out_f_100497;
                        ::prism_rtl::Turn::Finished((w2_p8.clone(), crate::prelude::push(&acc_p5, &part_p9)))
                    })
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::lower::node_::Wx, crate::prelude::Array<RowPart>), crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::prelude::Array<RowPart>)>>>
    }))
}

/// The step machine of `RowPartsOut`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RowPartsOut: unbounded fn Wx, Text, Text, [Wres] -> ((Wx, [RowPart]))
/// ```
pub struct RowPartsOut {
    pub r_p0: crate::lower::node_::Wx,
    pub gen_name_p1: crate::prelude::Text,
    pub prefix_p2: crate::prelude::Text,
    pub parts_p3: crate::prelude::Array<crate::lower::node_::Wres>,
}

impl ::prism_rtl::Job<(crate::lower::node_::Wx, crate::prelude::Array<RowPart>)> for RowPartsOut {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::lower::node_::Wx, crate::prelude::Array<RowPart>)> {
        let r_p0 = &self.r_p0;
        let gen_name_p1 = &self.gen_name_p1;
        let prefix_p2 = &self.prefix_p2;
        let parts_p3 = &self.parts_p3;
        crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(parts_p3)), (r_p0.clone(), crate::prelude::Array::new()), {
            let prefix_p2x = prefix_p2.clone();
            let gen_name_p1x = gen_name_p1.clone();
            let parts_p3x = parts_p3.clone();
            ::std::rc::Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::prelude::Array<RowPart>), crate::prelude::Nat)| {
                let prefix_p2xy = prefix_p2x.clone();
                let gen_name_p1xy = gen_name_p1x.clone();
                let parts_p3xy = parts_p3x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let (w_p4, acc_p5) = p0;
                    let i_p6 = p1;
                    {
                        let place_p7 = if &prefix_p2xy == &crate::prelude::Text::lit("") {
                            crate::prelude::Text::from(format!("p{}", &i_p6))
                        } else {
                            crate::prelude::Text::from(format!("{}_{}", &prefix_p2xy, &i_p6))
                        };
                        crate::prelude::call_then(start_row_part_out_f(w_p4.clone(), gen_name_p1xy.clone(), place_p7.clone(), crate::prelude::or(&crate::prelude::index(&parts_p3xy, &i_p6), &crate::lower::node_::Wres::WrUnit)), move |row_part_out_f_100497: (crate::lower::node_::Wx, RowPart)| {
                            let (w2_p8, part_p9) = row_part_out_f_100497;
                            ::prism_rtl::Turn::Finished((w2_p8.clone(), crate::prelude::push(&acc_p5, &part_p9)))
                        })
                    }
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::lower::node_::Wx, crate::prelude::Array<RowPart>), crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::prelude::Array<RowPart>)>>>
        }).cycle()
    }
}

/// `Start RowPartsOut, x`: what the function value is when passed to `@Run`.
pub fn start_row_parts_out_f(r_p0: crate::lower::node_::Wx, gen_name_p1: crate::prelude::Text, prefix_p2: crate::prelude::Text, parts_p3: crate::prelude::Array<crate::lower::node_::Wres>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::prelude::Array<RowPart>)>> {
    ::std::rc::Rc::new(RowPartsOut { r_p0, gen_name_p1, prefix_p2, parts_p3 })
}

/// ```prism
/// RowPartOut: unbounded fn Wx, Text, Text, Wres -> ((Wx, RowPart))
/// ```
pub fn row_part_out_f(r_p0: &crate::lower::node_::Wx, gen_name_p1: &crate::prelude::Text, place_p2: &crate::prelude::Text, part_p3: &crate::lower::node_::Wres) -> (crate::lower::node_::Wx, RowPart) {
    match part_p3 {
        crate::lower::node_::Wres::WrEv(er_p4) => (crate::lower::node_::connect_f(r_p0, er_p4, &crate::lower::node_::Sk::SkUp(crate::prelude::Text::from(format!("{}_{}_up", gen_name_p1, place_p2)))), RowPart::RowPartEvent(place_p2.clone())),
        crate::lower::node_::Wres::WrDyn(ex_p5, rds_p6, rt_p7) => {
            let parent_reads_p8 = crate::prelude::filter(&crate::lower::node_::finish::reads_closed_f(&r_p0.dyn_reads_p, rds_p6), &(|rd_p9: &crate::lower::node_::Read| is_parent_read_f(rd_p9)));
            (gen_result_named_f(r_p0, &crate::prelude::Text::from(format!("result_{}", place_p2)), &crate::prelude::Text::from(format!("result_dynamic_{}", place_p2)), &crate::prelude::Text::from(format!("{}_{}_result_moved", gen_name_p1, place_p2)), ex_p5, rds_p6, rt_p7), RowPart::RowPartDynamic(place_p2.clone(), rt_p7.clone(), parent_reads_p8.clone()))
        },
        crate::lower::node_::Wres::WrPlain(ex_pa, rt_pb) => {
            let (f_pd, rf_pe) = crate::lower::node_::fresh_name_f(r_p0, &crate::prelude::Text::lit("result"));
            let r2_pc = {
                let mut this: crate::lower::node_::Wx = rf_pe.clone();
                this.lets_p = crate::prelude::push(&this.lets_p, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaBind(f_pd.clone())), rt_pb.clone()), ex_pa.clone()));
                this.fields_p = crate::prelude::push(&this.fields_p, &(f_pd.clone(), rt_pb.clone(), crate::prelude::Text::lit("a plain part of the row\'s bundle")));
                this.inits_p = crate::prelude::push(&this.inits_p, &(f_pd.clone(), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(f_pd.clone())))));
                this.getters_p = crate::prelude::push(&this.getters_p, &crate::lower::model::MethDef { name_p: crate::prelude::Text::from(format!("result_value_{}", place_p2)), recv_p: crate::lower::model::Recv::RecvRef, params_p: crate::prelude::Array::new(), cx_p: crate::lower::model::CxArg::CxNone, ret_p: rt_pb.clone(), body_p: crate::prelude::Array::new(), tail_p: crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), f_pd.clone()))), doc_p: crate::prelude::Text::lit("A plain part of the row\'s bundle, which the block that built the row reads.") });
                this
            };
            (r2_pc.clone(), RowPart::RowPartPlain(place_p2.clone(), rt_pb.clone()))
        },
        crate::lower::node_::Wres::WrLate(ex_pf, rt_pg) => ({
            let mut this: crate::lower::node_::Wx = r_p0.clone();
            this.getters_p = crate::prelude::push(&this.getters_p, &crate::lower::model::MethDef { name_p: crate::prelude::Text::from(format!("result_value_{}", place_p2)), recv_p: crate::lower::model::Recv::RecvRef, params_p: crate::prelude::Array::new(), cx_p: crate::lower::model::CxArg::CxNone, ret_p: rt_pg.clone(), body_p: crate::prelude::Array::new(), tail_p: ex_pf.clone(), doc_p: crate::prelude::Text::lit("A plain part of the row\'s bundle, which the block that built the row reads.") });
            this
        }, RowPart::RowPartPlain(place_p2.clone(), rt_pg.clone())),
        crate::lower::node_::Wres::WrParts(inner_ph) => {
            let (r2_pi, ps_pj) = row_parts_out_f(r_p0, gen_name_p1, place_p2, inner_ph);
            (r2_pi.clone(), RowPart::RowPartParts(ps_pj.clone()))
        },
        crate::lower::node_::Wres::WrHosted(inner_pk, _) => row_part_out_f(r_p0, gen_name_p1, place_p2, &**inner_pk),
        crate::lower::node_::Wres::WrUnit => (r_p0.clone(), RowPart::RowPartNothing),
    }
}

/// The step machine of `RowPartOut`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RowPartOut: unbounded fn Wx, Text, Text, Wres -> ((Wx, RowPart))
/// ```
pub struct RowPartOut {
    pub r_p0: crate::lower::node_::Wx,
    pub gen_name_p1: crate::prelude::Text,
    pub place_p2: crate::prelude::Text,
    pub part_p3: crate::lower::node_::Wres,
}

impl ::prism_rtl::Job<(crate::lower::node_::Wx, RowPart)> for RowPartOut {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::lower::node_::Wx, RowPart)> {
        let r_p0 = &self.r_p0;
        let gen_name_p1 = &self.gen_name_p1;
        let place_p2 = &self.place_p2;
        let part_p3 = &self.part_p3;
        match part_p3 {
            crate::lower::node_::Wres::WrEv(er_p4) => ::prism_rtl::Turn::Finished((crate::lower::node_::connect_f(r_p0, er_p4, &crate::lower::node_::Sk::SkUp(crate::prelude::Text::from(format!("{}_{}_up", gen_name_p1, place_p2)))), RowPart::RowPartEvent(place_p2.clone()))),
            crate::lower::node_::Wres::WrDyn(ex_p5, rds_p6, rt_p7) => {
                let parent_reads_p8 = crate::prelude::filter(&crate::lower::node_::finish::reads_closed_f(&r_p0.dyn_reads_p, rds_p6), &(|rd_p9: &crate::lower::node_::Read| is_parent_read_f(rd_p9)));
                ::prism_rtl::Turn::Finished((gen_result_named_f(r_p0, &crate::prelude::Text::from(format!("result_{}", place_p2)), &crate::prelude::Text::from(format!("result_dynamic_{}", place_p2)), &crate::prelude::Text::from(format!("{}_{}_result_moved", gen_name_p1, place_p2)), ex_p5, rds_p6, rt_p7), RowPart::RowPartDynamic(place_p2.clone(), rt_p7.clone(), parent_reads_p8.clone())))
            },
            crate::lower::node_::Wres::WrPlain(ex_pa, rt_pb) => {
                let (f_pd, rf_pe) = crate::lower::node_::fresh_name_f(r_p0, &crate::prelude::Text::lit("result"));
                let r2_pc = {
                    let mut this: crate::lower::node_::Wx = rf_pe.clone();
                    this.lets_p = crate::prelude::push(&this.lets_p, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaBind(f_pd.clone())), rt_pb.clone()), ex_pa.clone()));
                    this.fields_p = crate::prelude::push(&this.fields_p, &(f_pd.clone(), rt_pb.clone(), crate::prelude::Text::lit("a plain part of the row\'s bundle")));
                    this.inits_p = crate::prelude::push(&this.inits_p, &(f_pd.clone(), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(f_pd.clone())))));
                    this.getters_p = crate::prelude::push(&this.getters_p, &crate::lower::model::MethDef { name_p: crate::prelude::Text::from(format!("result_value_{}", place_p2)), recv_p: crate::lower::model::Recv::RecvRef, params_p: crate::prelude::Array::new(), cx_p: crate::lower::model::CxArg::CxNone, ret_p: rt_pb.clone(), body_p: crate::prelude::Array::new(), tail_p: crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), f_pd.clone()))), doc_p: crate::prelude::Text::lit("A plain part of the row\'s bundle, which the block that built the row reads.") });
                    this
                };
                ::prism_rtl::Turn::Finished((r2_pc.clone(), RowPart::RowPartPlain(place_p2.clone(), rt_pb.clone())))
            },
            crate::lower::node_::Wres::WrLate(ex_pf, rt_pg) => ::prism_rtl::Turn::Finished(({
                let mut this: crate::lower::node_::Wx = r_p0.clone();
                this.getters_p = crate::prelude::push(&this.getters_p, &crate::lower::model::MethDef { name_p: crate::prelude::Text::from(format!("result_value_{}", place_p2)), recv_p: crate::lower::model::Recv::RecvRef, params_p: crate::prelude::Array::new(), cx_p: crate::lower::model::CxArg::CxNone, ret_p: rt_pg.clone(), body_p: crate::prelude::Array::new(), tail_p: ex_pf.clone(), doc_p: crate::prelude::Text::lit("A plain part of the row\'s bundle, which the block that built the row reads.") });
                this
            }, RowPart::RowPartPlain(place_p2.clone(), rt_pg.clone()))),
            crate::lower::node_::Wres::WrParts(inner_ph) => {
                let gen_name_p1x = gen_name_p1.clone();
                let inner_phx = inner_ph.clone();
                let place_p2x = place_p2.clone();
                let r_p0x = r_p0.clone();
                crate::prelude::call_then(start_row_parts_out_f(r_p0x.clone(), gen_name_p1x.clone(), place_p2x.clone(), inner_phx.clone()), move |row_parts_out_f_102001: (crate::lower::node_::Wx, crate::prelude::Array<RowPart>)| {
                    let (r2_pi, ps_pj) = row_parts_out_f_102001;
                    ::prism_rtl::Turn::Finished((r2_pi.clone(), RowPart::RowPartParts(ps_pj.clone())))
                })
            },
            crate::lower::node_::Wres::WrHosted(inner_pk, _) => ::prism_rtl::Turn::More(::std::rc::Rc::new(RowPartOut { r_p0: r_p0.clone(), gen_name_p1: gen_name_p1.clone(), place_p2: place_p2.clone(), part_p3: (**inner_pk).clone() })),
            crate::lower::node_::Wres::WrUnit => ::prism_rtl::Turn::Finished((r_p0.clone(), RowPart::RowPartNothing)),
        }
    }
}

/// `Start RowPartOut, x`: what the function value is when passed to `@Run`.
pub fn start_row_part_out_f(r_p0: crate::lower::node_::Wx, gen_name_p1: crate::prelude::Text, place_p2: crate::prelude::Text, part_p3: crate::lower::node_::Wres) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, RowPart)>> {
    ::std::rc::Rc::new(RowPartOut { r_p0, gen_name_p1, place_p2, part_p3 })
}

/// ```prism
/// RowsBundle: unbounded fn [ClauseRow] -> [RowPart]
/// ```
pub fn rows_bundle_f(rows_p0: &crate::prelude::Array<ClauseRow>) -> crate::prelude::Array<RowPart> {
    crate::prelude::run_to_end(crate::prelude::fold_job(rows_p0.clone(), crate::prelude::or(&crate::prelude::index(&crate::prelude::each(rows_p0, &(|cr_p1: &ClauseRow| cr_p1.parts_p.clone())), &crate::prelude::Nat::from(0u32)), &crate::prelude::Array::new()), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<RowPart>, ClauseRow)| crate::prelude::entered(crate::prelude::once_job(move || {
        let acc_p2 = p0;
        let cr_p3 = p1;
        ::prism_rtl::Turn::Finished(merge_row_parts_f(&acc_p2, &cr_p3.parts_p))
    }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<RowPart>, ClauseRow)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<RowPart>>>>))
}

/// The step machine of `RowsBundle`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RowsBundle: unbounded fn [ClauseRow] -> [RowPart]
/// ```
pub struct RowsBundle {
    pub rows_p0: crate::prelude::Array<ClauseRow>,
}

impl ::prism_rtl::Job<crate::prelude::Array<RowPart>> for RowsBundle {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<RowPart>> {
        let rows_p0 = &self.rows_p0;
        crate::prelude::fold_job(rows_p0.clone(), crate::prelude::or(&crate::prelude::index(&crate::prelude::each(rows_p0, &(|cr_p1: &ClauseRow| cr_p1.parts_p.clone())), &crate::prelude::Nat::from(0u32)), &crate::prelude::Array::new()), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<RowPart>, ClauseRow)| crate::prelude::entered(crate::prelude::once_job(move || {
            let acc_p2 = p0;
            let cr_p3 = p1;
            ::prism_rtl::Turn::Finished(merge_row_parts_f(&acc_p2, &cr_p3.parts_p))
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<RowPart>, ClauseRow)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<RowPart>>>>).cycle()
    }
}

/// `Start RowsBundle, x`: what the function value is when passed to `@Run`.
pub fn start_rows_bundle_f(rows_p0: crate::prelude::Array<ClauseRow>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<RowPart>>> {
    ::std::rc::Rc::new(RowsBundle { rows_p0 })
}

/// ```prism
/// MergeRowParts: unbounded fn [RowPart], [RowPart] -> [RowPart]
/// ```
pub fn merge_row_parts_f(xs_p0: &crate::prelude::Array<RowPart>, ys_p1: &crate::prelude::Array<RowPart>) -> crate::prelude::Array<RowPart> {
    crate::prelude::run_to_end(crate::prelude::each_job(crate::check::errors::range0_f(&crate::prelude::len(xs_p0)), {
        let xs_p0x = xs_p0.clone();
        let ys_p1x = ys_p1.clone();
        ::std::rc::Rc::new(move |p0: crate::prelude::Nat| {
            let xs_p0xy = xs_p0x.clone();
            let ys_p1xy = ys_p1x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let i_p2 = p0;
                match (crate::prelude::or(&crate::prelude::index(&xs_p0xy, &i_p2), &RowPart::RowPartNothing), crate::prelude::or(&crate::prelude::index(&ys_p1xy, &i_p2), &RowPart::RowPartNothing)) {
                    (RowPart::RowPartDynamic(place_p3, t_p4, a_p5), RowPart::RowPartDynamic(_, _, b_p6)) => ::prism_rtl::Turn::Finished(RowPart::RowPartDynamic(place_p3.clone(), t_p4.clone(), crate::lower::node_::union_reads_f(&a_p5, &b_p6))),
                    (RowPart::RowPartParts(a_p7), RowPart::RowPartParts(b_p8)) => ::prism_rtl::Turn::Finished(RowPart::RowPartParts(merge_row_parts_f(&a_p7, &b_p8))),
                    (x_p9, _) => ::prism_rtl::Turn::Finished(x_p9.clone()),
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<RowPart>>>
    }))
}

/// ```prism
/// KeepParts: unbounded fn Wx, Text, [RowPart], [Ty] -> KeptParts
/// ```
pub fn keep_parts_f(wx_p0: &crate::lower::node_::Wx, name_p1: &crate::prelude::Text, parts_p2: &crate::prelude::Array<RowPart>, tys_p3: &crate::prelude::Array<crate::check::types::Ty>) -> KeptParts {
    crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(parts_p2)), KeptParts { wx_p: wx_p0.clone(), keeps_p: crate::prelude::Array::new(), results_p: crate::prelude::Array::new() }, {
        let name_p1x = name_p1.clone();
        let parts_p2x = parts_p2.clone();
        let tys_p3x = tys_p3.clone();
        ::std::rc::Rc::new(move |(p0, p1): (KeptParts, crate::prelude::Nat)| {
            let name_p1xy = name_p1x.clone();
            let parts_p2xy = parts_p2x.clone();
            let tys_p3xy = tys_p3x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_p4 = p0;
                let i_p5 = p1;
                {
                    let (w_p6, keeps_p7, res_p8) = keep_part_f(&acc_p4.wx_p, &name_p1xy, &crate::prelude::or(&crate::prelude::index(&parts_p2xy, &i_p5), &RowPart::RowPartNothing), &crate::prelude::or(&crate::prelude::index(&tys_p3xy, &i_p5), &crate::check::types::Ty::TyErr));
                    ::prism_rtl::Turn::Finished(KeptParts { wx_p: w_p6.clone(), keeps_p: crate::prelude::append(&acc_p4.keeps_p, &keeps_p7), results_p: crate::prelude::push(&acc_p4.results_p, &res_p8) })
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((KeptParts, crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<KeptParts>>>
    }))
}

/// The step machine of `KeepParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// KeepParts: unbounded fn Wx, Text, [RowPart], [Ty] -> KeptParts
/// ```
pub struct KeepParts {
    pub wx_p0: crate::lower::node_::Wx,
    pub name_p1: crate::prelude::Text,
    pub parts_p2: crate::prelude::Array<RowPart>,
    pub tys_p3: crate::prelude::Array<crate::check::types::Ty>,
}

impl ::prism_rtl::Job<KeptParts> for KeepParts {
    fn cycle(&self) -> ::prism_rtl::Turn<KeptParts> {
        let wx_p0 = &self.wx_p0;
        let name_p1 = &self.name_p1;
        let parts_p2 = &self.parts_p2;
        let tys_p3 = &self.tys_p3;
        crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(parts_p2)), KeptParts { wx_p: wx_p0.clone(), keeps_p: crate::prelude::Array::new(), results_p: crate::prelude::Array::new() }, {
            let name_p1x = name_p1.clone();
            let parts_p2x = parts_p2.clone();
            let tys_p3x = tys_p3.clone();
            ::std::rc::Rc::new(move |(p0, p1): (KeptParts, crate::prelude::Nat)| {
                let name_p1xy = name_p1x.clone();
                let parts_p2xy = parts_p2x.clone();
                let tys_p3xy = tys_p3x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let acc_p4 = p0;
                    let i_p5 = p1;
                    {
                        let (w_p6, keeps_p7, res_p8) = keep_part_f(&acc_p4.wx_p, &name_p1xy, &crate::prelude::or(&crate::prelude::index(&parts_p2xy, &i_p5), &RowPart::RowPartNothing), &crate::prelude::or(&crate::prelude::index(&tys_p3xy, &i_p5), &crate::check::types::Ty::TyErr));
                        ::prism_rtl::Turn::Finished(KeptParts { wx_p: w_p6.clone(), keeps_p: crate::prelude::append(&acc_p4.keeps_p, &keeps_p7), results_p: crate::prelude::push(&acc_p4.results_p, &res_p8) })
                    }
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((KeptParts, crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<KeptParts>>>
        }).cycle()
    }
}

/// `Start KeepParts, x`: what the function value is when passed to `@Run`.
pub fn start_keep_parts_f(wx_p0: crate::lower::node_::Wx, name_p1: crate::prelude::Text, parts_p2: crate::prelude::Array<RowPart>, tys_p3: crate::prelude::Array<crate::check::types::Ty>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<KeptParts>> {
    ::std::rc::Rc::new(KeepParts { wx_p0, name_p1, parts_p2, tys_p3 })
}

/// ```prism
/// KeepPart: unbounded fn Wx, Text, RowPart, Ty -> ((Wx, [Do], Wres))
/// ```
pub fn keep_part_f(wx_p0: &crate::lower::node_::Wx, name_p1: &crate::prelude::Text, part_p2: &RowPart, ty_p3: &crate::check::types::Ty) -> (crate::lower::node_::Wx, crate::prelude::Array<crate::lower::model::Do>, crate::lower::node_::Wres) {
    match part_p2 {
        RowPart::RowPartEvent(place_p4) => {
            let et_p5 = crate::lower::types::out_ty_of_f(&wx_p0.lx_p, &crate::lower::types::peel_f(ty_p3));
            let fired_p6 = crate::prelude::Text::from(format!("{}_{}_fired", name_p1, place_p4));
            let (id_p8, w1_p9) = crate::lower::node_::add_gn_f(wx_p0, &fired_p6, &et_p5, &crate::lower::node_::GnKind::GnNamed, &crate::prelude::Nat::from(0u32));
            let w2_p7 = {
                let mut this: crate::lower::node_::Wx = w1_p9.clone();
                this.taken_p = crate::prelude::append(&this.taken_p, &crate::prelude::Array::from(vec![fired_p6.clone(), crate::prelude::Text::from(format!("{}_{}_up", name_p1, place_p4))]));
                this.getters_p = crate::prelude::push(&crate::prelude::push(&this.getters_p, &gen_up_above_f(&crate::prelude::Text::from(format!("{}_{}", name_p1, place_p4)), &fired_p6)), &crate::lower::model::MethDef { name_p: crate::prelude::Text::from(format!("{}_{}_up", name_p1, place_p4)), recv_p: crate::lower::model::Recv::RecvRc, params_p: crate::prelude::Array::from(vec![(crate::prelude::Text::lit("v"), et_p5.clone())]), cx_p: crate::lower::model::CxArg::CxMut, ret_p: crate::lower::model::OutTy::OutUnit, body_p: crate::prelude::Array::from(vec![crate::lower::node_::finish::self_call_f(&fired_p6, &crate::prelude::Array::from(vec![crate::lower::model::Ex::XVar(crate::prelude::Text::lit("v"))]))]), tail_p: crate::lower::model::Ex::XUnit, doc_p: crate::prelude::Text::lit("An event part of the generation\'s bundle fires the line\'s event.") });
                this
            };
            (w2_p7.clone(), crate::prelude::Array::new(), crate::lower::node_::Wres::WrEv(crate::lower::node_::ev_ref_of_f(&w2_p7, &id_p8)))
        },
        RowPart::RowPartDynamic(place_pa, t_pb, reads_pc) => {
            let (w1_pe, res_pf) = kept_dyn_f(wx_p0, &crate::prelude::Text::from(format!("{}_{}", name_p1, place_pa)), t_pb, reads_pc);
            let kept_pd = crate::lower::model::Do::DoAssign(crate::lower::model::Ex::XDeref(::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::from(format!("{}_{}_res", name_p1, place_pa)))), crate::prelude::Text::lit("borrow_mut"), crate::prelude::Array::new()))), crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Some")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("row"))), crate::prelude::Text::from(format!("result_dynamic_{}", place_pa)), crate::prelude::Array::new())])));
            (w1_pe.clone(), crate::prelude::Array::from(vec![kept_pd.clone()]), res_pf.clone())
        },
        RowPart::RowPartPlain(place_pg, t_ph) => {
            let res_pi = crate::prelude::Text::from(format!("{}_{}_res", name_p1, place_pg));
            let kept_pj = crate::lower::model::Do::DoAssign(crate::lower::model::Ex::XDeref(::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), res_pi.clone())), crate::prelude::Text::lit("borrow_mut"), crate::prelude::Array::new()))), crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Some")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("row"))), crate::prelude::Text::from(format!("result_value_{}", place_pg)), crate::prelude::Array::new())])));
            let read_pk = crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), res_pi.clone())), crate::prelude::Text::lit("borrow"), crate::prelude::Array::new())), crate::prelude::Text::lit("as_ref"), crate::prelude::Array::new())), crate::prelude::Text::lit("expect"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XStr(crate::prelude::Text::lit("a row built before what reads its result"))]))));
            let w1_pl = {
                let mut this: crate::lower::node_::Wx = wx_p0.clone();
                this.taken_p = crate::prelude::push(&this.taken_p, &res_pi);
                this.fields_p = crate::prelude::push(&this.fields_p, &(res_pi.clone(), crate::lower::model::OutTy::OutCell(::std::rc::Rc::new(crate::lower::model::OutTy::OutOpt(::std::rc::Rc::new(t_ph.clone())))), crate::prelude::Text::lit("a plain part of the generation\'s bundle, kept from the row\'s build on")));
                this.inits_p = crate::prelude::push(&this.inits_p, &(res_pi.clone(), crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::RefCell::new")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XNone]))));
                this
            };
            (w1_pl.clone(), crate::prelude::Array::from(vec![kept_pj.clone()]), crate::lower::node_::Wres::WrLate(read_pk.clone(), t_ph.clone()))
        },
        RowPart::RowPartParts(inner_pm) => {
            let kept_pn = keep_parts_f(wx_p0, name_p1, inner_pm, &crate::lower::node_::keyed::bundle_part_tys_f(ty_p3));
            (kept_pn.wx_p.clone(), kept_pn.keeps_p.clone(), crate::lower::node_::Wres::WrParts(kept_pn.results_p.clone()))
        },
        RowPart::RowPartNothing => (wx_p0.clone(), crate::prelude::Array::new(), crate::lower::node_::Wres::WrUnit),
    }
}

/// ```prism
/// BundleResultKey: fn Lx, Block -> Text
/// ```
pub fn bundle_result_key_f(lx_p0: &crate::lower::Lx, body_p1: &crate::syntax::Block) -> crate::prelude::Text {
    match &crate::prelude::or(&crate::prelude::index(&body_p1.stmts_p, &crate::syntax::lexer::chars::dec_f(&crate::prelude::len(&body_p1.stmts_p))), &crate::lower::expr::dummy_stmt_l_p()).kind_p {
        crate::syntax::StmtKind::SExpr(y_p2) => match &*y_p2.kind_p {
            crate::syntax::ExprKind::EFreeSigil(m106208_0_0, x_p3) if (m106208_0_0 == &crate::prelude::Text::lit("@")) => if crate::lower::types::is_bundle_f(&crate::lower::type_at_f(lx_p0, &x_p3.span_p)) {
                result_key_f(lx_p0, &**x_p3)
            } else {
                crate::prelude::Text::lit("")
            },
            _ => crate::prelude::Text::lit(""),
            _ => unreachable!("no arm matched"),
        },
        _ => crate::prelude::Text::lit(""),
    }
}

/// ```prism
/// ResultKey: fn Lx, Expr -> Text
/// ```
pub fn result_key_f(lx_p0: &crate::lower::Lx, x_p1: &crate::syntax::Expr) -> crate::prelude::Text {
    crate::prelude::Text::from(format!("{}:{}:{}", &lx_p0.file_p, &x_p1.span_p.start_p, &x_p1.span_p.end_p))
}

/// ```prism
/// GenMarked: fn Wx, Text, Wx -> Wx
/// ```
pub fn gen_marked_f(parent_p0: &crate::lower::node_::Wx, gen_name_p1: &crate::prelude::Text, row_wx_p2: &crate::lower::node_::Wx) -> crate::lower::node_::Wx {
    let reads_p3 = crate::lower::node_::keyed::row_place_reads_f(row_wx_p2);
    let hears_p4 = crate::lower::node_::finish::updated_hears_f(row_wx_p2);
    let builds_p5 = crate::prelude::filter(&crate::lower::node_::finish::row_hears_f(row_wx_p2), &(|m_p7: &crate::prelude::Text| !crate::check::types::has_text_f(&hears_p4, m_p7)));
    let ported_p6 = crate::prelude::fold(&crate::prelude::append(&hears_p4, &builds_p5), parent_p0, &(|w_p8: &crate::lower::node_::Wx, m_p9: &crate::prelude::Text| crate::lower::node_::add_field_f(w_p8, &crate::prelude::Text::from(format!("{}_wrote_{}_port", gen_name_p1, m_p9)), &crate::lower::model::OutTy::OutPort(::std::rc::Rc::new(crate::lower::model::OutTy::OutUnit)), &crate::prelude::Text::from(format!("the current generation of `{}` hears a write behind `{}`", gen_name_p1, m_p9)), &crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Port::new")), crate::prelude::Array::new()))));
    if ((&crate::prelude::len(&reads_p3) == &crate::prelude::Nat::from(0u32)) && (&crate::prelude::len(&hears_p4) == &crate::prelude::Nat::from(0u32))) && (&crate::prelude::len(&builds_p5) == &crate::prelude::Nat::from(0u32)) {
        parent_p0.clone()
    } else {
        {
            let mut this: crate::lower::node_::Wx = ported_p6.clone();
            this.row_marks_p = crate::prelude::push(&this.row_marks_p, &crate::lower::node_::RowMarks { builder_p: gen_name_p1.clone(), reads_p: reads_p3.clone(), wrote_p: hears_p4.clone(), builds_p: builds_p5.clone(), kind_p: crate::lower::model::RowKind::GenerationRow });
            this
        }
    }
}

/// ```prism
/// GenHears: fn Wx, Text -> Wx
/// ```
pub fn gen_hears_f(r_p0: &crate::lower::node_::Wx, gen_name_p1: &crate::prelude::Text) -> crate::lower::node_::Wx {
    crate::prelude::fold(&crate::lower::node_::finish::row_hears_f(r_p0), r_p0, &(|w_p2: &crate::lower::node_::Wx, m_p3: &crate::prelude::Text| {
        let mut this: crate::lower::node_::Wx = w_p2.clone();
        this.subs_p = crate::prelude::push(&this.subs_p, &(crate::prelude::Text::from(format!("{}_wrote_{}", gen_name_p1, m_p3)), crate::prelude::Text::from(format!("wrote_{}", m_p3)), crate::lower::model::OutTy::OutUnit));
        this.taken_p = crate::prelude::push(&this.taken_p, &crate::prelude::Text::from(format!("wrote_{}", m_p3)));
        this.getters_p = crate::prelude::push(&this.getters_p, &crate::lower::model::MethDef { name_p: crate::prelude::Text::from(format!("wrote_{}", m_p3)), recv_p: crate::lower::model::Recv::RecvRc, params_p: crate::prelude::Array::from(vec![(crate::prelude::Text::lit("v"), crate::lower::model::OutTy::OutUnit)]), cx_p: crate::lower::model::CxArg::CxMut, ret_p: crate::lower::model::OutTy::OutUnit, body_p: crate::prelude::Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::from(format!("parent_wrote_{}", m_p3)), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx])))]), tail_p: crate::lower::model::Ex::XUnit, doc_p: crate::prelude::Text::from(format!("The block wrote behind its `{}`: as `parent_wrote_{}`.", m_p3, m_p3)) });
        this.getters_p = crate::prelude::push(&this.getters_p, &crate::lower::node_::finish::above_method_f(&crate::prelude::Text::from(format!("wrote_{}", m_p3)), &crate::prelude::Array::from(vec![crate::lower::node_::finish::above_call_f(&crate::lower::model::Ex::XSelf, &crate::prelude::Text::from(format!("parent_wrote_{}", m_p3)), &crate::lower::model::Ex::XVar(crate::prelude::Text::lit("h")))]), &crate::prelude::Text::from(format!("the block writes behind its `{}`", m_p3))));
        this
    }))
}

/// ```prism
/// GenCurrent: fn Wx, Wx, Text -> Wx
/// ```
pub fn gen_current_f(r_p0: &crate::lower::node_::Wx, parent_p1: &crate::lower::node_::Wx, gen_name_p2: &crate::prelude::Text) -> crate::lower::node_::Wx {
    let stale_p3 = crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(parent_ref_p()), crate::prelude::Text::from(format!("{}_stale", gen_name_p2)))), crate::prelude::Text::lit("get"), crate::prelude::Array::new());
    let block_current_p4 = if &parent_p1.gen_of_p == &crate::prelude::Text::lit("") {
        crate::lower::model::Ex::XUnary(crate::lower::model::UnOp::OpNot, ::std::rc::Rc::new(stale_p3.clone()))
    } else {
        crate::lower::model::Ex::XBin(crate::lower::model::BinOp::OpAnd, ::std::rc::Rc::new(crate::lower::model::Ex::XUnary(crate::lower::model::UnOp::OpNot, ::std::rc::Rc::new(stale_p3.clone()))), ::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(parent_ref_p()), crate::prelude::Text::lit("current"), crate::prelude::Array::new())))
    };
    let tail_p5 = crate::lower::model::Ex::XBin(crate::lower::model::BinOp::OpAnd, ::std::rc::Rc::new(crate::lower::model::Ex::XUnary(crate::lower::model::UnOp::OpNot, ::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::lit("left"))), crate::prelude::Text::lit("get"), crate::prelude::Array::new())))), ::std::rc::Rc::new(block_current_p4.clone()));
    let r2_p6 = crate::lower::node_::add_field_f(r_p0, &crate::prelude::Text::lit("left"), &crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Cell")), crate::prelude::Array::from(vec![crate::lower::model::OutTy::OutBool])), &crate::prelude::Text::lit("the generation left: its block replaced it"), &crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Cell::new")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XBool(false)])));
    let mut this: crate::lower::node_::Wx = r2_p6.clone();
    this.gen_of_p = gen_name_p2.clone();
    this.taken_p = crate::prelude::append(&this.taken_p, &crate::prelude::Array::from(vec![crate::prelude::Text::lit("left"), crate::prelude::Text::lit("current")]));
    this.getters_p = crate::prelude::push(&this.getters_p, &crate::lower::model::MethDef { name_p: crate::prelude::Text::lit("current"), recv_p: crate::lower::model::Recv::RecvRef, params_p: crate::prelude::Array::new(), cx_p: crate::lower::model::CxArg::CxNone, ret_p: crate::lower::model::OutTy::OutBool, body_p: crate::prelude::Array::new(), tail_p: tail_p5.clone(), doc_p: crate::prelude::Text::lit("Whether this generation is still its block\'s current one after the tick: it builds only then.") });
    this
}

/// ```prism
/// BuildSpelling: unbounded fn Env -> Env
/// ```
pub fn build_spelling_f(env_p0: &crate::lower::types::Env) -> crate::lower::types::Env {
    crate::prelude::run_to_end(crate::prelude::fold_job(crate::prelude::keys(&env_p0.names_p), env_p0.clone(), {
        let env_p0x = env_p0.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::lower::types::Env, crate::prelude::Text)| {
            let env_p0xy = env_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let en_p1 = p0;
                let k_p2 = p1;
                match crate::prelude::get(&env_p0xy.names_p, &k_p2) {
                    ::std::option::Option::Some(crate::lower::types::Bn::BnLocal(rs_p3, mode_p4, t_p5)) => match crate::lower::types::through_parent_o(&rs_p3) {
                        ::std::option::Option::Some(x_p6) => ::prism_rtl::Turn::Finished(crate::lower::types::bind_f(&en_p1, &k_p2, &crate::lower::types::Bn::BnLocal(x_p6.clone(), mode_p4.clone(), t_p5.clone()))),
                        ::std::option::Option::None => ::prism_rtl::Turn::Finished(en_p1.clone()),
                    },
                    ::std::option::Option::Some(crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(rs_p7, m_p8, xs_p9), ds_pa, t_pb)) => match crate::lower::types::through_parent_o(&*rs_p7) {
                        ::std::option::Option::Some(x_pc) => ::prism_rtl::Turn::Finished(crate::lower::types::bind_f(&en_p1, &k_p2, &crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(x_pc.clone()), m_p8.clone(), xs_p9.clone()), ds_pa.clone(), t_pb.clone()))),
                        ::std::option::Option::None => ::prism_rtl::Turn::Finished(en_p1.clone()),
                    },
                    ::std::option::Option::Some(crate::lower::types::Bn::BnParts(bs_pd)) => crate::prelude::call_then(start_parts_at_build_f(bs_pd.clone()), move |parts_at_build_f_110614: crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>| ::prism_rtl::Turn::Finished(crate::lower::types::bind_f(&en_p1, &k_p2, &crate::lower::types::Bn::BnParts(parts_at_build_f_110614)))),
                    _ => ::prism_rtl::Turn::Finished(en_p1.clone()),
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::types::Env, crate::prelude::Text)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::types::Env>>>
    }))
}

/// The step machine of `BuildSpelling`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BuildSpelling: unbounded fn Env -> Env
/// ```
pub struct BuildSpelling {
    pub env_p0: crate::lower::types::Env,
}

impl ::prism_rtl::Job<crate::lower::types::Env> for BuildSpelling {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::lower::types::Env> {
        let env_p0 = &self.env_p0;
        crate::prelude::fold_job(crate::prelude::keys(&env_p0.names_p), env_p0.clone(), {
            let env_p0x = env_p0.clone();
            ::std::rc::Rc::new(move |(p0, p1): (crate::lower::types::Env, crate::prelude::Text)| {
                let env_p0xy = env_p0x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let en_p1 = p0;
                    let k_p2 = p1;
                    match crate::prelude::get(&env_p0xy.names_p, &k_p2) {
                        ::std::option::Option::Some(crate::lower::types::Bn::BnLocal(rs_p3, mode_p4, t_p5)) => match crate::lower::types::through_parent_o(&rs_p3) {
                            ::std::option::Option::Some(x_p6) => ::prism_rtl::Turn::Finished(crate::lower::types::bind_f(&en_p1, &k_p2, &crate::lower::types::Bn::BnLocal(x_p6.clone(), mode_p4.clone(), t_p5.clone()))),
                            ::std::option::Option::None => ::prism_rtl::Turn::Finished(en_p1.clone()),
                        },
                        ::std::option::Option::Some(crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(rs_p7, m_p8, xs_p9), ds_pa, t_pb)) => match crate::lower::types::through_parent_o(&*rs_p7) {
                            ::std::option::Option::Some(x_pc) => ::prism_rtl::Turn::Finished(crate::lower::types::bind_f(&en_p1, &k_p2, &crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(x_pc.clone()), m_p8.clone(), xs_p9.clone()), ds_pa.clone(), t_pb.clone()))),
                            ::std::option::Option::None => ::prism_rtl::Turn::Finished(en_p1.clone()),
                        },
                        ::std::option::Option::Some(crate::lower::types::Bn::BnParts(bs_pd)) => crate::prelude::call_then(start_parts_at_build_f(bs_pd.clone()), move |parts_at_build_f_110614: crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>| ::prism_rtl::Turn::Finished(crate::lower::types::bind_f(&en_p1, &k_p2, &crate::lower::types::Bn::BnParts(parts_at_build_f_110614)))),
                        _ => ::prism_rtl::Turn::Finished(en_p1.clone()),
                    }
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::types::Env, crate::prelude::Text)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::types::Env>>>
        }).cycle()
    }
}

/// `Start BuildSpelling, x`: what the function value is when passed to `@Run`.
pub fn start_build_spelling_f(env_p0: crate::lower::types::Env) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::types::Env>> {
    ::std::rc::Rc::new(BuildSpelling { env_p0 })
}

/// ```prism
/// PartsAtBuild: unbounded fn [?Bn] -> [?Bn]
/// ```
pub fn parts_at_build_f(parts_p0: &crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>) -> crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>> {
    crate::prelude::run_to_end(crate::prelude::each_job(parts_p0.clone(), ::std::rc::Rc::new(move |p0: ::std::option::Option<crate::lower::types::Bn>| crate::prelude::entered(crate::prelude::once_job(move || {
        let b_o1 = p0;
        ::prism_rtl::Turn::Finished(part_spelled_at_build_o(&b_o1))
    }))) as ::std::rc::Rc<dyn ::std::ops::Fn(::std::option::Option<crate::lower::types::Bn>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<::std::option::Option<crate::lower::types::Bn>>>>))
}

/// The step machine of `PartsAtBuild`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PartsAtBuild: unbounded fn [?Bn] -> [?Bn]
/// ```
pub struct PartsAtBuild {
    pub parts_p0: crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>,
}

impl ::prism_rtl::Job<crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>> for PartsAtBuild {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>> {
        let parts_p0 = &self.parts_p0;
        crate::prelude::each_job(parts_p0.clone(), ::std::rc::Rc::new(move |p0: ::std::option::Option<crate::lower::types::Bn>| crate::prelude::entered(crate::prelude::once_job(move || {
            let b_o1 = p0;
            ::prism_rtl::Turn::Finished(part_spelled_at_build_o(&b_o1))
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn(::std::option::Option<crate::lower::types::Bn>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<::std::option::Option<crate::lower::types::Bn>>>>).cycle()
    }
}

/// `Start PartsAtBuild, x`: what the function value is when passed to `@Run`.
pub fn start_parts_at_build_f(parts_p0: crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>>> {
    ::std::rc::Rc::new(PartsAtBuild { parts_p0 })
}

/// ```prism
/// ?PartSpelledAtBuild: unbounded fn ?Bn -> ?Bn
/// ```
pub fn part_spelled_at_build_o(b_o0: &::std::option::Option<crate::lower::types::Bn>) -> ::std::option::Option<crate::lower::types::Bn> {
    match b_o0 {
        ::std::option::Option::Some(crate::lower::types::Bn::BnLocal(rs_p1, mode_p2, t_p3)) => match crate::lower::types::through_parent_o(rs_p1) {
            ::std::option::Option::Some(x_p4) => ::std::option::Option::Some(crate::lower::types::Bn::BnLocal(x_p4, mode_p2.clone(), t_p3.clone())),
            ::std::option::Option::None => b_o0.clone(),
        },
        ::std::option::Option::Some(crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(rs_p5, m_p6, xs_p7), ds_p8, t_p9)) => match crate::lower::types::through_parent_o(&**rs_p5) {
            ::std::option::Option::Some(x_pa) => ::std::option::Option::Some(crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(x_pa), m_p6.clone(), xs_p7.clone()), ds_p8.clone(), t_p9.clone())),
            ::std::option::Option::None => b_o0.clone(),
        },
        ::std::option::Option::Some(crate::lower::types::Bn::BnParts(inner_pb)) => ::std::option::Option::Some(crate::lower::types::Bn::BnParts(parts_at_build_f(inner_pb))),
        _ => b_o0.clone(),
    }
}

/// ```prism
/// GenSelect: unbounded fn Wx, Env, Block, [GenCase], Pos, [ [Do] ], Bool -> Ex
/// ```
pub fn gen_select_f(wx_p0: &crate::lower::node_::Wx, menv_p1: &crate::lower::types::Env, body_p2: &crate::syntax::Block, cases_p3: &crate::prelude::Array<GenCase>, pos_p4: &crate::lower::model::Pos, sets_p5: &crate::prelude::Array<crate::prelude::Array<crate::lower::model::Do>>, of_rebuild_p6: &bool) -> crate::lower::model::Ex {
    let tail_p7 = crate::prelude::append(&crate::prelude::append(&crate::prelude::Array::from(vec![crate::lower::model::Ex::XWeak(::std::rc::Rc::new(crate::lower::model::Ex::XSelf))]), &crate::lower::node_::keyed::hosted_passed_f(wx_p0)), &crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx]));
    match clause_call_o(&wx_p0.lx_p, body_p2) {
        ::std::option::Option::None => match crate::prelude::index(cases_p3, &crate::prelude::Nat::from(0u32)) {
            ::std::option::Option::Some(c_p8) => crate::lower::expr::try_of_f(&crate::lower::model::Ex::XCall(crate::lower::model::ref_child_f(&crate::lower::site_ref_f(&wx_p0.lx_p, &c_p8.node_p.name_p), &crate::prelude::Text::lit("build")), crate::prelude::append(&crate::prelude::Array::from(vec![crate::lower::model::Ex::XVar(crate::prelude::Text::lit("path")), crate::lower::model::Ex::XVar(crate::prelude::Text::lit("value"))]), &tail_p7))),
            ::std::option::Option::None => crate::lower::expr::internal_bug_f(&crate::prelude::Text::lit("a `rebuild` with no generation")),
        },
        ::std::option::Option::Some((qk_p9, args_pa)) => {
            let env_pb = if *of_rebuild_p6 {
                crate::lower::types::bind_f(menv_p1, &crate::prelude::Text::lit("_"), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("value")), crate::lower::types::Holding::Owned, crate::lower::model::OutTy::OutUnit))
            } else {
                menv_p1.clone()
            };
            let scrut_pc = clause_scrutinee_f(&wx_p0.lx_p, &env_pb, &crate::lower::program::val_of_f(&wx_p0.lx_p, &qk_p9), &args_pa);
            let row_obj_pd = crate::lower::model::OutTy::OutObj(::std::rc::Rc::new(crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Row")), crate::prelude::Array::new())));
            let arms_pe = crate::prelude::fold(cases_p3, &crate::prelude::Array::new(), &(|built_pf: &crate::prelude::Array<crate::lower::model::XArm>, c_pg: &GenCase| {
                let i_ph = crate::prelude::len(built_pf);
                let made_pi = crate::lower::expr::try_of_f(&crate::lower::model::Ex::XCall(crate::lower::model::ref_child_f(&crate::lower::site_ref_f(&wx_p0.lx_p, &c_pg.node_p.name_p), &crate::prelude::Text::lit("build")), crate::prelude::append(&crate::prelude::append(&crate::prelude::Array::from(vec![crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("path"))))]), &c_pg.passed_p), &tail_p7)));
                let set_pj = crate::prelude::or(&crate::prelude::index(sets_p5, &i_ph), &crate::prelude::Array::new());
                crate::prelude::push(built_pf, &crate::lower::model::XArm { pat_p: c_pg.pat_p.clone(), conds_p: c_pg.conds_p.clone(), body_p: if &crate::prelude::len(&set_pj) == &crate::prelude::Nat::from(0u32) {
                    crate::lower::model::Ex::XCast(::std::rc::Rc::new(made_pi.clone()), row_obj_pd.clone())
                } else {
                    crate::lower::model::Ex::XBlock(crate::prelude::append(&crate::prelude::Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("row")), made_pi.clone())]), &set_pj), ::std::rc::Rc::new(crate::lower::model::Ex::XCast(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("row"))), row_obj_pd.clone())))
                } })
            }));
            crate::lower::types::own_f(&crate::lower::expr::arms_value_f(&scrut_pc, &arms_pe, &crate::prelude::Text::lit("\'select"), &crate::lower::model::OutTy::OutObj(::std::rc::Rc::new(crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Row")), crate::prelude::Array::new())))))
        },
    }
}

/// ```prism
/// RowGaps: fn [ClauseRow], Nat -> [?Ex]
/// ```
pub fn row_gaps_f(rows_p0: &crate::prelude::Array<ClauseRow>, width_p1: &crate::prelude::Nat) -> crate::prelude::Array<::std::option::Option<crate::lower::model::Ex>> {
    crate::prelude::each(rows_p0, &(|cr_p2: &ClauseRow| {
        let short_p3 = crate::prelude::or(&width_p1.checked_sub(&cr_p2.width_p), &crate::prelude::Nat::from(0u32));
        if cr_p2.inner_p {
            ::std::option::Option::Some(crate::lower::model::Ex::XBin(crate::lower::model::BinOp::OpAdd, ::std::rc::Rc::new(crate::lower::model::Ex::XIndex(short_p3.clone())), ::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("row"))), crate::prelude::Text::lit("inner_gap"), crate::prelude::Array::new()))))
        } else {
            if &short_p3 > &crate::prelude::Nat::from(0u32) {
                ::std::option::Option::Some(crate::lower::model::Ex::XIndex(short_p3.clone()))
            } else {
                ::std::option::Option::None
            }
        }
    }))
}

/// ```prism
/// IsGappy: fn [?Ex] -> Bool
/// ```
pub fn is_gappy_f(gaps_p0: &crate::prelude::Array<::std::option::Option<crate::lower::model::Ex>>) -> bool {
    crate::prelude::fold(gaps_p0, &false, &(|f_p1: &bool, g_o2: &::std::option::Option<crate::lower::model::Ex>| *f_p1 || is_some_f(g_o2)))
}

/// ```prism
/// GapSet: fn Text, ?Ex -> [Do]
/// ```
pub fn gap_set_f(name_p0: &crate::prelude::Text, opt1: &::std::option::Option<crate::lower::model::Ex>) -> crate::prelude::Array<crate::lower::model::Do> {
    match opt1 {
        ::std::option::Option::Some(x_p1) => crate::prelude::Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::from(format!("{}_gap", name_p0)))), crate::prelude::Text::lit("set"), crate::prelude::Array::from(vec![x_p1.clone()])))]),
        ::std::option::Option::None => crate::prelude::Array::new(),
    }
}

/// ```prism
/// NumberOf: fn Wx, Pos, Text, Text, ?Ex -> Ex
/// ```
pub fn number_of_f(wx_p0: &crate::lower::node_::Wx, pos_p1: &crate::lower::model::Pos, name_p2: &crate::prelude::Text, link_p3: &crate::prelude::Text, gap_o4: &::std::option::Option<crate::lower::model::Ex>) -> crate::lower::model::Ex {
    let owner_p5 = crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("node")), crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("numbered_link"))), crate::prelude::Text::lit("owner"), crate::prelude::Array::new())), crate::prelude::Text::lit("expect"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XStr(crate::prelude::Text::lit("a row is numbered once its block\'s node stands"))])));
    let numbered_p6 = crate::lower::model::Do::DoExpr(crate::lower::expr::try_of_f(&crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("row"))), crate::prelude::Text::lit("number_places"), crate::prelude::Array::from(vec![crate::lower::node_::finish::place_number_f(wx_p0, &crate::prelude::Text::lit("node"), pos_p1), crate::lower::model::Ex::XCx]))));
    let gap_set_p7 = match gap_o4 {
        ::std::option::Option::Some(g_p8) => crate::prelude::Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("node"))), crate::prelude::Text::from(format!("{}_gap", name_p2)))), crate::prelude::Text::lit("set"), crate::prelude::Array::from(vec![g_p8.clone()])))]),
        ::std::option::Option::None => crate::prelude::Array::new(),
    };
    crate::lower::model::Ex::XBlock(crate::prelude::Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("row")), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("row"))))), crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("numbered_link")), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(link_p3.clone())))), crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("number"))), crate::lower::node_::finish::later_ty_p()), crate::lower::model::Ex::XLater(::std::rc::Rc::new(crate::lower::model::Ex::XBlock(crate::prelude::append(&crate::prelude::Array::from(vec![owner_p5.clone(), numbered_p6.clone()]), &gap_set_p7), ::std::rc::Rc::new(crate::lower::model::Ex::XUnit)))))]), ::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("number"))))
}

/// ```prism
/// IsWeakTy: fn OutTy -> Bool
/// ```
pub fn is_weak_ty_f(t_p0: &crate::lower::model::OutTy) -> bool {
    match t_p0 {
        crate::lower::model::OutTy::OutWeak(_) => true,
        _ => false,
    }
}

/// ```prism
/// UnnumberedSteps: fn Wx -> [Bool]
/// ```
pub fn unnumbered_steps_f(wx_p0: &crate::lower::node_::Wx) -> crate::prelude::Array<bool> {
    crate::prelude::append(&crate::prelude::each(&crate::prelude::filter(&wx_p0.builders_p, &(|b_p1: &crate::lower::model::ForDef| &b_p1.pos_p.scope_p == &crate::prelude::Nat::from(0u32))), &(|b_p2: &crate::lower::model::ForDef| false)), &crate::prelude::each(&crate::prelude::filter(&wx_p0.gens_p, &(|gd_p3: &crate::lower::model::GenDef| ((&gd_p3.pos_p.scope_p == &crate::prelude::Nat::from(0u32)) && !gd_p3.early_p) && !crate::check::types::has_text_f(&wx_p0.late_row_gens_p, &gd_p3.name_p))), &(|gd_p4: &crate::lower::model::GenDef| gd_p4.gappy_p)))
}

/// ```prism
/// NumberedByParent: fn Wx, Pos, Text -> Do
/// ```
pub fn numbered_by_parent_f(wx_p0: &crate::lower::node_::Wx, pos_p1: &crate::lower::model::Pos, gen_name_p2: &crate::prelude::Text) -> crate::lower::model::Do {
    let numbered_p3 = crate::lower::model::Do::DoIfLet(crate::lower::model::Pa::PaCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Some")), crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("parent"))])), crate::lower::model::Ex::XUpgrade(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("row"))), crate::prelude::Text::lit("parent")))), crate::prelude::Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::expr::try_of_f(&crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("row"))), crate::prelude::Text::lit("number_places"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("parent"))), crate::lower::node_::finish::place_method_f(&pos_p1.scope_p), crate::prelude::Array::from(vec![crate::lower::model::Ex::XIndex(pos_p1.at_p.clone())])), crate::lower::model::Ex::XCx]))))]), crate::prelude::Array::new());
    let step_p4 = crate::lower::model::Ex::XBlock(crate::prelude::Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("row")), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("node"))))), crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("number"))), crate::lower::node_::finish::later_ty_p()), crate::lower::model::Ex::XLater(::std::rc::Rc::new(crate::lower::model::Ex::XBlock(crate::prelude::Array::from(vec![numbered_p3.clone()]), ::std::rc::Rc::new(crate::lower::model::Ex::XUnit)))))]), ::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("number"))));
    crate::lower::model::Do::DoIfLet(crate::lower::model::Pa::PaCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Some")), crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("parent"))])), crate::lower::model::Ex::XUpgrade(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("node"))), crate::prelude::Text::lit("parent")))), crate::prelude::Array::from(vec![crate::lower::model::Do::DoAssign(crate::lower::model::Ex::XDeref(::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("parent"))), crate::prelude::Text::from(format!("{}_number", gen_name_p2)))), crate::prelude::Text::lit("borrow_mut"), crate::prelude::Array::new()))), crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Some")), crate::prelude::Array::from(vec![step_p4.clone()])))]), crate::prelude::Array::new())
}

/// ```prism
/// IsLinkTy: fn OutTy -> Bool
/// ```
pub fn is_link_ty_f(t_p0: &crate::lower::model::OutTy) -> bool {
    match t_p0 {
        crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefRuntime(m116997_0_0_0), _) if (m116997_0_0_0 == &crate::prelude::Text::lit("prism_rtl::Link")) => true,
        _ => false,
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// WithRowBase: fn Wx, Text, Pos, Ex -> Ex
/// ```
pub fn with_row_base_f(wx_p0: &crate::lower::node_::Wx, recv_p1: &crate::prelude::Text, pos_p2: &crate::lower::model::Pos, select_p3: &crate::lower::model::Ex) -> crate::lower::model::Ex {
    crate::lower::model::Ex::XBlock(crate::prelude::Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("row_base")), crate::lower::node_::finish::place_number_f(wx_p0, recv_p1, pos_p2))]), ::std::rc::Rc::new(select_p3.clone()))
}

/// ```prism
/// GenUpAbove: fn Text, Text -> MethDef
/// ```
pub fn gen_up_above_f(name_p0: &crate::prelude::Text, up_name_p1: &crate::prelude::Text) -> crate::lower::model::MethDef {
    crate::lower::node_::finish::above_method_f(&crate::prelude::Text::from(format!("{}_up", name_p0)), &crate::prelude::Array::from(vec![crate::lower::node_::finish::above_call_f(&crate::lower::model::Ex::XSelf, up_name_p1, &crate::lower::model::Ex::XVar(crate::prelude::Text::lit("h")))]), &crate::prelude::Text::lit("the current generation\'s result fires"))
}

/// ```prism
/// GenUp: fn Text, Text, OutTy -> MethDef
/// ```
pub fn gen_up_f(name_p0: &crate::prelude::Text, up_name_p1: &crate::prelude::Text, t_p2: &crate::lower::model::OutTy) -> crate::lower::model::MethDef {
    crate::lower::model::MethDef { name_p: crate::prelude::Text::from(format!("{}_up", name_p0)), recv_p: crate::lower::model::Recv::RecvRc, params_p: crate::prelude::Array::from(vec![(crate::prelude::Text::lit("v"), t_p2.clone())]), cx_p: crate::lower::model::CxArg::CxMut, ret_p: crate::lower::model::OutTy::OutUnit, body_p: crate::prelude::Array::from(vec![crate::lower::node_::finish::self_call_f(up_name_p1, &crate::prelude::Array::from(vec![crate::lower::model::Ex::XVar(crate::prelude::Text::lit("v"))]))]), tail_p: crate::lower::model::Ex::XUnit, doc_p: crate::prelude::Text::lit("The current generation\'s result fires the `rebuild`\'s.") }
}

/// ```prism
/// GenForwards: fn GenDef -> [((Pa, Ex))]
/// ```
pub fn gen_forwards_f(gd_p0: &crate::lower::model::GenDef) -> crate::prelude::Array<(crate::lower::model::Pa, crate::lower::model::Ex)> {
    if is_wide_gen_f(gd_p0) {
        crate::prelude::Array::new()
    } else {
        if gd_p0.transparent_p {
            crate::prelude::each(&crate::check::errors::range0_f(&gd_p0.width_p), &(|i_p1: &crate::prelude::Nat| {
                let current_p2 = crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::from(format!("{}", &gd_p0.name_p)))), crate::prelude::Text::lit("borrow"), crate::prelude::Array::new())));
                let body_p3 = crate::lower::model::Ex::XBlock(crate::prelude::Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("row")), current_p2.clone()), crate::lower::model::Do::DoIfLet(crate::lower::model::Pa::PaCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Some")), crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("row"))])), crate::lower::model::Ex::XVar(crate::prelude::Text::lit("row")), crate::prelude::Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::expr::try_of_f(&crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("row"))), crate::prelude::Text::lit("answer"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XVar(crate::prelude::Text::lit("at")), crate::lower::model::Ex::XVar(crate::prelude::Text::lit("v")), crate::lower::model::Ex::XCx]))))]), crate::prelude::Array::new())]), ::std::rc::Rc::new(crate::lower::model::Ex::XUnit));
                (crate::lower::node_::finish::pos_pat_f(&crate::lower::model::Pos { scope_p: gd_p0.pos_p.scope_p.clone(), at_p: &gd_p0.pos_p.at_p + i_p1 }, &crate::prelude::Array::from(vec![crate::lower::model::Pa::PaRest(crate::prelude::Text::lit(""))])), body_p3.clone())
            }))
        } else {
            crate::prelude::Array::from(vec![(crate::lower::node_::finish::pos_pat_f(&gd_p0.pos_p, &crate::lower::node_::finish::gen_tail_p()), forward_gen_f(gd_p0))])
        }
    }
}

/// ```prism
/// IsWideGen: fn GenDef -> Bool
/// ```
pub fn is_wide_gen_f(gd_p0: &crate::lower::model::GenDef) -> bool {
    gd_p0.transparent_p && (&gd_p0.width_p >= &wide_generation_p())
}

/// ```prism
/// WideForward: fn [GenDef] -> [((Pa, Ex))]
/// ```
pub fn wide_forward_f(gens_p0: &crate::prelude::Array<crate::lower::model::GenDef>) -> crate::prelude::Array<(crate::lower::model::Pa, crate::lower::model::Ex)> {
    let none_p1 = crate::prelude::Array::from(vec![crate::lower::model::Do::DoReturn(crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Err")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Fault::answer")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XStr(crate::prelude::Text::lit("no answering place at this position"))]))])))]);
    let chain_p2 = crate::prelude::fold(gens_p0, &none_p1, &(|rest_p3: &crate::prelude::Array<crate::lower::model::Do>, gd_p4: &crate::lower::model::GenDef| {
        let current_p5 = crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::from(format!("{}", &gd_p4.name_p)))), crate::prelude::Text::lit("borrow"), crate::prelude::Array::new())));
        let moved_p6 = if gd_p4.rebased_p {
            crate::prelude::Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("rebased")), crate::lower::model::Ex::XCall(crate::lower::helper_ref_f(&crate::prelude::Text::lit("rebased")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XVar(crate::prelude::Text::lit("at")), crate::lower::model::Ex::XIndex(gd_p4.pos_p.at_p.clone())])))])
        } else {
            crate::prelude::Array::new()
        };
        let path_p7 = if gd_p4.rebased_p {
            crate::lower::model::Ex::XCall(crate::lower::helper_ref_f(&crate::prelude::Text::lit("segments_of")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("rebased"))))]))
        } else {
            crate::lower::model::Ex::XVar(crate::prelude::Text::lit("at"))
        };
        let handed_p8 = crate::prelude::append(&moved_p6, &crate::prelude::Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("row")), current_p5.clone()), crate::lower::model::Do::DoIfLet(crate::lower::model::Pa::PaCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Some")), crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("row"))])), crate::lower::model::Ex::XVar(crate::prelude::Text::lit("row")), crate::prelude::Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::expr::try_of_f(&crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("row"))), crate::prelude::Text::lit("answer"), crate::prelude::Array::from(vec![path_p7.clone(), crate::lower::model::Ex::XVar(crate::prelude::Text::lit("v")), crate::lower::model::Ex::XCx]))))]), crate::prelude::Array::new())]));
        crate::prelude::Array::from(vec![crate::lower::model::Do::DoIf(crate::lower::model::Ex::XCall(crate::lower::helper_ref_f(&crate::prelude::Text::lit("within_positions")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XVar(crate::prelude::Text::lit("at")), crate::lower::model::Ex::XIndex(gd_p4.pos_p.at_p.clone()), crate::lower::model::Ex::XIndex(gd_p4.width_p.clone())])), handed_p8.clone(), rest_p3.clone())])
    }));
    if &crate::prelude::len(gens_p0) == &crate::prelude::Nat::from(0u32) {
        crate::prelude::Array::new()
    } else {
        crate::prelude::Array::from(vec![(crate::lower::model::Pa::PaSlice(crate::prelude::Array::from(vec![crate::lower::model::Pa::PaRest(crate::prelude::Text::lit(""))])), crate::lower::model::Ex::XBlock(chain_p2.clone(), ::std::rc::Rc::new(crate::lower::model::Ex::XUnit)))])
    }
}

/// ```prism
/// TypedWideForward: fn [GenDef], Ex, [Do] -> [((Pa, [Do]))]
/// ```
pub fn typed_wide_forward_f(gens_p0: &crate::prelude::Array<crate::lower::model::GenDef>, segs_p1: &crate::lower::model::Ex, none_p2: &crate::prelude::Array<crate::lower::model::Do>) -> crate::prelude::Array<(crate::lower::model::Pa, crate::prelude::Array<crate::lower::model::Do>)> {
    let chain_p3 = crate::prelude::fold(gens_p0, none_p2, &(|rest_p4: &crate::prelude::Array<crate::lower::model::Do>, gd_p5: &crate::lower::model::GenDef| {
        let current_p6 = crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::from(format!("{}", &gd_p5.name_p)))), crate::prelude::Text::lit("borrow"), crate::prelude::Array::new())));
        let moved_p7 = if gd_p5.rebased_p {
            crate::prelude::Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("rebased")), crate::lower::model::Ex::XCall(crate::lower::helper_ref_f(&crate::prelude::Text::lit("rebased")), crate::prelude::Array::from(vec![segs_p1.clone(), crate::lower::model::Ex::XIndex(gd_p5.pos_p.at_p.clone())])))])
        } else {
            crate::prelude::Array::new()
        };
        let path_p8 = if gd_p5.rebased_p {
            crate::lower::model::Ex::XCall(crate::lower::helper_ref_f(&crate::prelude::Text::lit("segments_of")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("rebased"))))]))
        } else {
            segs_p1.clone()
        };
        let handed_p9 = crate::prelude::append(&moved_p7, &crate::prelude::Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("row")), current_p6.clone()), crate::lower::model::Do::DoIfLet(crate::lower::model::Pa::PaCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Some")), crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("row"))])), crate::lower::model::Ex::XVar(crate::prelude::Text::lit("row")), crate::prelude::Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::expr::try_of_f(&crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("row"))), crate::prelude::Text::lit("deliver"), crate::prelude::Array::from(vec![path_p8.clone(), crate::lower::model::Ex::XVar(crate::prelude::Text::lit("v")), crate::lower::model::Ex::XCx]))))]), crate::prelude::Array::new())]));
        crate::prelude::Array::from(vec![crate::lower::model::Do::DoIf(crate::lower::model::Ex::XCall(crate::lower::helper_ref_f(&crate::prelude::Text::lit("within_positions")), crate::prelude::Array::from(vec![segs_p1.clone(), crate::lower::model::Ex::XIndex(gd_p5.pos_p.at_p.clone()), crate::lower::model::Ex::XIndex(gd_p5.width_p.clone())])), handed_p9.clone(), rest_p4.clone())])
    }));
    crate::prelude::Array::from(vec![(crate::lower::model::Pa::PaWild, chain_p3.clone())])
}

/// ```prism
/// let sharedMoved
/// ```
pub fn shared_moved_p() -> crate::prelude::Text {
    crate::prelude::Text::lit("#moved")
}

/// ```prism
/// let movedTy
/// ```
pub fn moved_ty_p() -> crate::lower::model::OutTy {
    crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("prism_rtl::Moved")), crate::prelude::Array::new())
}

/// ```prism
/// ForwardGen: fn GenDef -> Ex
/// ```
pub fn forward_gen_f(gd_p0: &crate::lower::model::GenDef) -> crate::lower::model::Ex {
    let current_p1 = crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::from(format!("{}", &gd_p0.name_p)))), crate::prelude::Text::lit("borrow"), crate::prelude::Array::new())));
    let is_current_p2 = crate::lower::model::Ex::XBin(crate::lower::model::BinOp::OpEq, ::std::rc::Rc::new(crate::lower::model::Ex::XBin(crate::lower::model::BinOp::OpAdd, ::std::rc::Rc::new(crate::lower::model::Ex::XDeref(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("g"))))), ::std::rc::Rc::new(crate::lower::model::Ex::XIndex(crate::prelude::Nat::from(1u32))))), ::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::from(format!("{}_count", &gd_p0.name_p)))), crate::prelude::Text::lit("get"), crate::prelude::Array::new())));
    crate::lower::model::Ex::XBlock(crate::prelude::Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("row")), current_p1.clone()), crate::lower::model::Do::DoIfLet(crate::lower::model::Pa::PaCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Some")), crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("row"))])), crate::lower::model::Ex::XVar(crate::prelude::Text::lit("row")), crate::prelude::Array::from(vec![crate::lower::model::Do::DoIf(is_current_p2.clone(), crate::prelude::Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::expr::try_of_f(&crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("row"))), crate::prelude::Text::lit("answer"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XVar(crate::prelude::Text::lit("rest")), crate::lower::model::Ex::XVar(crate::prelude::Text::lit("v")), crate::lower::model::Ex::XCx]))))]), crate::prelude::Array::new())]), crate::prelude::Array::new())]), ::std::rc::Rc::new(crate::lower::model::Ex::XUnit))
}

/// ```prism
/// FlattenLine: unbounded fn Wx, Env, [Arg], ?Bn -> ((Wx, Wres))
/// ```
pub fn flatten_line_f(wx_p0: &crate::lower::node_::Wx, menv_p1: &crate::lower::types::Env, args_p2: &crate::prelude::Array<crate::syntax::Arg>, bound_o3: &::std::option::Option<crate::lower::types::Bn>) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    let named_o4 = match crate::prelude::index(args_p2, &crate::prelude::Nat::from(0u32)) {
        ::std::option::Option::Some(a_p6) => match &*a_p6.value_p.kind_p {
            crate::syntax::ExprKind::EName(n_p7) => 'm122872: {
                let scrutinee = &crate::prelude::get(&menv_p1.names_p, &crate::check::env::sname_key_f(n_p7));
                if let ::std::option::Option::Some(crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(m122872_0_0_0, m_p8, _), _, crate::lower::model::OutTy::OutDyn(t_p9))) = scrutinee && let crate::lower::model::Ex::XSelf = &**m122872_0_0_0 {
                    break 'm122872 ::std::option::Option::Some((m_p8.clone(), (**t_p9).clone()));
                }
                ::std::option::Option::None
            },
            _ => ::std::option::Option::None,
        },
        ::std::option::Option::None => ::std::option::Option::None,
    };
    let outer_o5 = match &named_o4 {
        ::std::option::Option::Some((m_pa, t_pb)) => crate::prelude::fold(&wx_p0.gens_p, &::std::option::Option::None, &(|acc_oc: &::std::option::Option<(crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy)>, gd_pd: &crate::lower::model::GenDef| if &crate::prelude::Text::from(format!("{}_result", &gd_pd.name_p)) == m_pa {
            ::std::option::Option::Some((m_pa.clone(), gd_pd.name_p.clone(), t_pb.clone()))
        } else {
            acc_oc.clone()
        })),
        ::std::option::Option::None => ::std::option::Option::None,
    };
    match &outer_o5 {
        ::std::option::Option::None => match crate::prelude::index(args_p2, &crate::prelude::Nat::from(0u32)) {
            ::std::option::Option::Some(a_pe) => held_flatten_f(wx_p0, menv_p1, &a_pe.value_p, bound_o3),
            ::std::option::Option::None => (wx_p0.clone(), crate::lower::node_::Wres::WrUnit),
        },
        ::std::option::Option::Some((m_pf, gen_pg, t_ph)) => {
            let (name_po, wx1_pp) = 'm123412: {
                if let ::std::option::Option::Some(crate::lower::types::Bn::BnHold(f_pm, _)) = bound_o3 {
                    break 'm123412 (f_pm.clone(), wx_p0.clone());
                }
                if let ::std::option::Option::Some(crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(m123412_1_0_0, f_pn, _), _, _)) = bound_o3 && let crate::lower::model::Ex::XSelf = &**m123412_1_0_0 {
                    break 'm123412 (f_pn.clone(), wx_p0.clone());
                }
                crate::lower::node_::fresh_name_f(wx_p0, &crate::prelude::Text::lit("flatten"))
            };
            let inner_pi = crate::prelude::Text::from(format!("{}_inner", &name_po));
            let first_pj = crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("node"))), crate::prelude::Text::from(format!("{}", &inner_pi)))), crate::prelude::Text::lit("set"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Some")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("node"))), m_pf.clone(), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx]))])), crate::lower::model::Ex::XCx])));
            let sample_pk = crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::from(format!("{}", &inner_pi)))), crate::prelude::Text::lit("get"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx]))), crate::prelude::Text::lit("expect"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XStr(crate::prelude::Text::lit("`@Flatten` adopts its first inner at the build"))]))), crate::prelude::Text::lit("sample"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx]));
            let wx2_pl = {
                let mut this: crate::lower::node_::Wx = wx1_pp.clone();
                this.taken_p = crate::prelude::append(&this.taken_p, &crate::prelude::Array::from(vec![inner_pi.clone(), crate::prelude::Text::from(format!("{}_adopt", &name_po))]));
                this.fields_p = crate::prelude::push(&this.fields_p, &(inner_pi.clone(), crate::lower::model::OutTy::OutHold(::std::rc::Rc::new(crate::lower::model::OutTy::OutOpt(::std::rc::Rc::new(crate::lower::model::OutTy::OutDyn(::std::rc::Rc::new(t_ph.clone())))))), crate::prelude::Text::lit("`@Flatten`\'s current inner: the dynamic of the generation it adopted")));
                this.moves_p = crate::prelude::push(&this.moves_p, &(inner_pi.clone(), crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Hold::new")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XNone, crate::lower::model::Ex::XCx]))));
                this.build_p = crate::prelude::push(&this.build_p, &first_pj);
                this.getters_p = crate::prelude::push(&this.getters_p, &crate::lower::model::MethDef { name_p: name_po.clone(), recv_p: crate::lower::model::Recv::RecvRef, params_p: crate::prelude::Array::new(), cx_p: crate::lower::model::CxArg::CxRef, ret_p: t_ph.clone(), body_p: crate::prelude::Array::new(), tail_p: sample_pk.clone(), doc_p: crate::prelude::Text::lit("`@Flatten`\'s dynamic: its current inner at the read point.") });
                this.dyn_reads_p = crate::prelude::insert(&this.dyn_reads_p, &name_po, &crate::prelude::Array::from(vec![crate::lower::node_::Read::OwnRead(inner_pi.clone())]));
                this.flattens_p = crate::prelude::push(&this.flattens_p, &crate::lower::node_::FlatDef { name_p: name_po.clone(), outer_p: m_pf.clone(), generation_p: gen_pg.clone(), held_p: false, ty_p: t_ph.clone() });
                this
            };
            (wx2_pl.clone(), crate::lower::node_::Wres::WrDyn(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), name_po.clone(), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx])), crate::prelude::Array::from(vec![crate::lower::node_::Read::OwnRead(inner_pi.clone())]), t_ph.clone()))
        },
    }
}

/// ```prism
/// HeldFlatten: unbounded fn Wx, Env, Expr, ?Bn -> ((Wx, Wres))
/// ```
pub fn held_flatten_f(wx_p0: &crate::lower::node_::Wx, menv_p1: &crate::lower::types::Env, x_p2: &crate::syntax::Expr, bound_o3: &::std::option::Option<crate::lower::types::Bn>) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    let t_p4 = crate::lower::types::out_ty_of_f(&wx_p0.lx_p, &crate::lower::types::peel_f(&crate::lower::types::peel_f(&crate::lower::type_at_f(&wx_p0.lx_p, &x_p2.span_p))));
    'm126035: {
        let scrutinee = &crate::prelude::get(&menv_p1.names_p, &crate::prelude::Text::from(format!("#whole{}", &crate::lower::node_::static_::dyn_key_f(x_p2))));
        if let ::std::option::Option::Some(crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XField(m126035_0_0_0, dyn_p5), _, _)) = scrutinee && let crate::lower::model::Ex::XSelf = &**m126035_0_0_0 {
            break 'm126035 {
                let (name_ph, wx1_pi) = 'm126164: {
                    if let ::std::option::Option::Some(crate::lower::types::Bn::BnHold(f_pf, _)) = bound_o3 {
                        break 'm126164 (f_pf.clone(), wx_p0.clone());
                    }
                    if let ::std::option::Option::Some(crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(m126164_1_0_0, f_pg, _), _, _)) = bound_o3 && let crate::lower::model::Ex::XSelf = &**m126164_1_0_0 {
                        break 'm126164 (f_pg.clone(), wx_p0.clone());
                    }
                    crate::lower::node_::fresh_name_f(wx_p0, &crate::prelude::Text::lit("flatten"))
                };
                let inner_p6 = crate::prelude::Text::from(format!("{}_inner", &name_ph));
                let follow_p7 = crate::prelude::Text::from(format!("{}_follow", &name_ph));
                let ofollow_p8 = crate::prelude::Text::from(format!("{}_ofollow", &name_ph));
                let inner_now_p9 = crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("node"))), inner_p6.clone())), crate::prelude::Text::lit("get"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx]))), crate::prelude::Text::lit("expect"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XStr(crate::prelude::Text::lit("`@Flatten` adopts its first inner at the build"))]));
                let followed_pa = crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("node"))), follow_p7.clone())), crate::prelude::Text::lit("follow"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(inner_now_p9.clone()), crate::prelude::Text::lit("updates")))), crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("node")))), crate::lower::model::Ex::XPath(crate::lower::model::ref_child_f(&crate::lower::site_ref_f(&wx_p0.lx_p, &wx_p0.node_p), &crate::prelude::Text::from(format!("{}_moved", &name_ph))))])));
                let ofollowed_pb = crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("node"))), ofollow_p8.clone())), crate::prelude::Text::lit("follow"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("node"))), dyn_p5.clone())), crate::prelude::Text::lit("updates")))), crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("node")))), crate::lower::model::Ex::XPath(crate::lower::model::ref_child_f(&crate::lower::site_ref_f(&wx_p0.lx_p, &wx_p0.node_p), &crate::prelude::Text::from(format!("{}_outer_moved", &name_ph))))])));
                let sample_pc = crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::from(format!("{}", &inner_p6)))), crate::prelude::Text::lit("get"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx]))), crate::prelude::Text::lit("expect"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XStr(crate::prelude::Text::lit("`@Flatten` adopts its first inner at the build"))]))), crate::prelude::Text::lit("sample"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx]));
                let follow_ty_pd = crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("prism_rtl::Follow")), crate::prelude::Array::new());
                let wx2_pe = {
                    let mut this: crate::lower::node_::Wx = wx1_pi.clone();
                    this.taken_p = crate::prelude::append(&this.taken_p, &crate::prelude::Array::from(vec![inner_p6.clone(), follow_p7.clone(), ofollow_p8.clone(), crate::prelude::Text::from(format!("{}_adopt", &name_ph)), crate::prelude::Text::from(format!("{}_moved", &name_ph)), crate::prelude::Text::from(format!("{}_outer_moved", &name_ph))]));
                    this.fields_p = crate::prelude::append(&this.fields_p, &crate::prelude::Array::from(vec![(inner_p6.clone(), crate::lower::model::OutTy::OutHold(::std::rc::Rc::new(crate::lower::model::OutTy::OutOpt(::std::rc::Rc::new(crate::lower::model::OutTy::OutDyn(::std::rc::Rc::new(t_p4.clone())))))), crate::prelude::Text::lit("`@Flatten`\'s current inner: the one its outer held when it adopted")), (follow_p7.clone(), follow_ty_pd.clone(), crate::prelude::Text::lit("the subscription to the inner\'s update event")), (ofollow_p8.clone(), follow_ty_pd.clone(), crate::prelude::Text::lit("the subscription to the outer\'s update event"))]));
                    this.moves_p = crate::prelude::append(&this.moves_p, &crate::prelude::Array::from(vec![(inner_p6.clone(), crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Hold::new")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Some")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XVar(dyn_p5.clone())), crate::prelude::Text::lit("sample"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx]))])), crate::lower::model::Ex::XCx]))), (follow_p7.clone(), crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("prism_rtl::Follow::new")), crate::prelude::Array::new())), (ofollow_p8.clone(), crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("prism_rtl::Follow::new")), crate::prelude::Array::new()))]));
                    this.build_p = crate::prelude::append(&this.build_p, &crate::prelude::Array::from(vec![followed_pa.clone(), ofollowed_pb.clone()]));
                    this.getters_p = crate::prelude::push(&this.getters_p, &crate::lower::model::MethDef { name_p: name_ph.clone(), recv_p: crate::lower::model::Recv::RecvRef, params_p: crate::prelude::Array::new(), cx_p: crate::lower::model::CxArg::CxRef, ret_p: t_p4.clone(), body_p: crate::prelude::Array::new(), tail_p: sample_pc.clone(), doc_p: crate::prelude::Text::lit("`@Flatten`\'s dynamic: its current inner at the read point.") });
                    this.dyn_reads_p = crate::prelude::insert(&this.dyn_reads_p, &name_ph, &crate::prelude::Array::from(vec![crate::lower::node_::Read::OwnRead(inner_p6.clone())]));
                    this.flattens_p = crate::prelude::push(&this.flattens_p, &crate::lower::node_::FlatDef { name_p: name_ph.clone(), outer_p: dyn_p5.clone(), generation_p: crate::prelude::Text::lit(""), held_p: true, ty_p: t_p4.clone() });
                    this
                };
                (wx2_pe.clone(), crate::lower::node_::Wres::WrDyn(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), name_ph.clone(), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx])), crate::prelude::Array::from(vec![crate::lower::node_::Read::OwnRead(inner_p6.clone())]), t_p4.clone()))
            };
        }
        {
            let wx2_pj = {
                let mut this: crate::lower::node_::Wx = wx_p0.clone();
                this.build_p = crate::prelude::push(&this.build_p, &crate::lower::expr::refusal_do_f(&crate::prelude::Text::from(format!("`@Flatten` of `{}`, a dynamic of dynamics with no live dynamic at the build where the line reads it (gap LF)", &crate::lower::functions::src_text_f(&wx_p0.lx_p, &wx_p0.lx_p.file_p, &x_p2.span_p)))));
                this
            };
            (wx2_pj.clone(), crate::lower::node_::Wres::WrUnit)
        }
    }
}

/// ```prism
/// EntryFlatten: unbounded fn Wx, OutTy, ?Bn -> ((Wx, Wres))
/// ```
pub fn entry_flatten_f(wx_p0: &crate::lower::node_::Wx, t_p1: &crate::lower::model::OutTy, bound_o2: &::std::option::Option<crate::lower::types::Bn>) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    let (name_pa, wx1_pb) = 'm130056: {
        if let ::std::option::Option::Some(crate::lower::types::Bn::BnHold(f_p8, _)) = bound_o2 {
            break 'm130056 (f_p8.clone(), wx_p0.clone());
        }
        if let ::std::option::Option::Some(crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(m130056_1_0_0, f_p9, _), _, _)) = bound_o2 && let crate::lower::model::Ex::XSelf = &**m130056_1_0_0 {
            break 'm130056 (f_p9.clone(), wx_p0.clone());
        }
        crate::lower::node_::fresh_name_f(wx_p0, &crate::prelude::Text::lit("flatten"))
    };
    let inner_p3 = crate::prelude::Text::from(format!("{}_inner", &name_pa));
    let follow_p4 = crate::prelude::Text::from(format!("{}_follow", &name_pa));
    let followed_p5 = crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("node"))), follow_p4.clone())), crate::prelude::Text::lit("follow"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("node"))), crate::prelude::Text::lit("entry"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx]))), crate::prelude::Text::lit("updates")))), crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("node")))), crate::lower::model::Ex::XPath(crate::lower::model::ref_child_f(&crate::lower::site_ref_f(&wx_p0.lx_p, &wx_p0.node_p), &crate::prelude::Text::from(format!("{}_moved", &name_pa))))])));
    let sample_p6 = crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::from(format!("{}", &inner_p3)))), crate::prelude::Text::lit("get"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx]))), crate::prelude::Text::lit("expect"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XStr(crate::prelude::Text::lit("`@Flatten` adopts its first inner at the build"))]))), crate::prelude::Text::lit("sample"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx]));
    let wx2_p7 = {
        let mut this: crate::lower::node_::Wx = wx1_pb.clone();
        this.taken_p = crate::prelude::append(&this.taken_p, &crate::prelude::Array::from(vec![inner_p3.clone(), follow_p4.clone(), crate::prelude::Text::from(format!("{}_adopt", &name_pa)), crate::prelude::Text::from(format!("{}_moved", &name_pa)), crate::prelude::Text::from(format!("{}_replaced", &name_pa))]));
        this.fields_p = crate::prelude::append(&this.fields_p, &crate::prelude::Array::from(vec![(inner_p3.clone(), crate::lower::model::OutTy::OutHold(::std::rc::Rc::new(crate::lower::model::OutTy::OutOpt(::std::rc::Rc::new(crate::lower::model::OutTy::OutDyn(::std::rc::Rc::new(t_p1.clone())))))), crate::prelude::Text::lit("`@Flatten`\'s current inner: the row\'s entry it adopted")), (follow_p4.clone(), crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("prism_rtl::Follow")), crate::prelude::Array::new()), crate::prelude::Text::lit("the subscription to the inner\'s update event"))]));
        this.moves_p = crate::prelude::append(&this.moves_p, &crate::prelude::Array::from(vec![(inner_p3.clone(), crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Hold::new")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Some")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("value"))))])), crate::lower::model::Ex::XCx]))), (follow_p4.clone(), crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("prism_rtl::Follow::new")), crate::prelude::Array::new()))]));
        this.build_p = crate::prelude::push(&this.build_p, &followed_p5);
        this.getters_p = crate::prelude::push(&this.getters_p, &crate::lower::model::MethDef { name_p: name_pa.clone(), recv_p: crate::lower::model::Recv::RecvRef, params_p: crate::prelude::Array::new(), cx_p: crate::lower::model::CxArg::CxRef, ret_p: t_p1.clone(), body_p: crate::prelude::Array::new(), tail_p: sample_p6.clone(), doc_p: crate::prelude::Text::lit("`@Flatten`\'s dynamic: its current inner at the read point.") });
        this.dyn_reads_p = crate::prelude::insert(&this.dyn_reads_p, &name_pa, &crate::prelude::Array::from(vec![crate::lower::node_::Read::OwnRead(inner_p3.clone())]));
        this.flattens_p = crate::prelude::push(&this.flattens_p, &crate::lower::node_::FlatDef { name_p: name_pa.clone(), outer_p: crate::prelude::Text::lit("entry"), generation_p: crate::prelude::Text::lit(""), held_p: false, ty_p: t_p1.clone() });
        this
    };
    (wx2_p7.clone(), crate::lower::node_::Wres::WrDyn(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), name_pa.clone(), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx])), crate::prelude::Array::from(vec![crate::lower::node_::Read::OwnRead(inner_p3.clone())]), t_p1.clone()))
}

/// ```prism
/// SwitchLine: unbounded fn Wx, Env, [Arg] -> ((Wx, Wres))
/// ```
pub fn switch_line_f(wx_p0: &crate::lower::node_::Wx, menv_p1: &crate::lower::types::Env, args_p2: &crate::prelude::Array<crate::syntax::Arg>) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    match crate::prelude::index(args_p2, &crate::prelude::Nat::from(0u32)) {
        ::std::option::Option::Some(a_p3) => {
            let rebuilt_p4 = match &*a_p3.value_p.kind_p {
                crate::syntax::ExprKind::EName(n_p5) => match crate::prelude::get(&menv_p1.names_p, &crate::check::env::sname_key_f(n_p5)) {
                    ::std::option::Option::Some(crate::lower::types::Bn::BnEv(_, _)) => true,
                    _ => false,
                },
                _ => false,
            };
            if rebuilt_p4 {
                {
                    let (r_p6, wx2_p7) = crate::lower::node_::dynamics::event_ref_f(wx_p0, menv_p1, &a_p3.value_p);
                    (wx2_p7.clone(), crate::lower::node_::Wres::WrEv(r_p6.clone()))
                }
            } else {
                held_switch_f(wx_p0, menv_p1, &a_p3.value_p)
            }
        },
        ::std::option::Option::None => (wx_p0.clone(), crate::lower::node_::Wres::WrUnit),
    }
}

/// ```prism
/// HeldSwitch: unbounded fn Wx, Env, Expr -> ((Wx, Wres))
/// ```
pub fn held_switch_f(wx_p0: &crate::lower::node_::Wx, menv_p1: &crate::lower::types::Env, x_p2: &crate::syntax::Expr) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    let lx_p3 = wx_p0.lx_p.clone();
    let t_p4 = crate::lower::types::out_ty_of_f(&lx_p3, &crate::lower::types::peel_f(&crate::lower::types::peel_f(&crate::lower::type_at_f(&lx_p3, &x_p2.span_p))));
    let lxw_p5 = {
        let mut this: crate::lower::Lx = lx_p3.clone();
        this.whole_p = true;
        this
    };
    let (name_ph, w1_pi) = crate::lower::node_::fresh_name_f(wx_p0, &crate::prelude::Text::lit("switched"));
    let (id_pj, w2_pk) = crate::lower::node_::add_gn_f(&w1_pi, &name_ph, &t_p4, &crate::lower::node_::GnKind::GnPort, &crate::prelude::Nat::from(0u32));
    let outer_p6 = crate::prelude::Text::from(format!("{}_outer", &name_ph));
    let listen_p7 = crate::prelude::Text::from(format!("{}_listen", &name_ph));
    let ofollow_p8 = crate::prelude::Text::from(format!("{}_ofollow", &name_ph));
    let outer_ty_p9 = crate::lower::model::OutTy::OutDyn(::std::rc::Rc::new(crate::lower::model::OutTy::OutEvent(::std::rc::Rc::new(t_p4.clone()))));
    let made_pa = crate::lower::model::MethDef { name_p: crate::prelude::Text::from(format!("{}_made", &outer_p6)), recv_p: crate::lower::model::Recv::RecvRef, params_p: crate::prelude::Array::new(), cx_p: crate::lower::model::CxArg::CxRef, ret_p: outer_ty_p9.clone(), body_p: crate::prelude::Array::new(), tail_p: crate::lower::types::own_f(&crate::lower::expr::value_of_f(&lxw_p5, menv_p1, x_p2)), doc_p: crate::prelude::Text::from(format!("`{}`, the switch\'s outer, as a live dynamic.", &crate::lower::functions::src_text_f(&lx_p3, &lx_p3.file_p, &x_p2.span_p))) };
    let outer_now_pb = crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("node"))), outer_p6.clone())), crate::prelude::Text::lit("get"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx]))), crate::prelude::Text::lit("expect"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XStr(crate::prelude::Text::lit("`@Switch`\'s outer is made at the build"))]));
    let set_outer_pc = crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("node"))), outer_p6.clone())), crate::prelude::Text::lit("set"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Some")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("node"))), crate::prelude::Text::from(format!("{}_made", &outer_p6)), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx]))])), crate::lower::model::Ex::XCx])));
    let listened_pd = crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("node"))), listen_p7.clone())), crate::prelude::Text::lit("listen_above"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(outer_now_pb.clone()), crate::prelude::Text::lit("sample"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx])))), crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("node")))), crate::lower::model::Ex::XPath(crate::lower::model::ref_child_f(&crate::lower::site_ref_f(&lx_p3, &wx_p0.node_p), &name_ph)), crate::lower::model::Ex::XPath(crate::lower::model::ref_child_f(&crate::lower::site_ref_f(&lx_p3, &wx_p0.node_p), &crate::prelude::Text::from(format!("{}_above", &name_ph))))])));
    let followed_pe = crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("node"))), ofollow_p8.clone())), crate::prelude::Text::lit("follow"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(outer_now_pb.clone()), crate::prelude::Text::lit("updates")))), crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("node")))), crate::lower::model::Ex::XPath(crate::lower::model::ref_child_f(&crate::lower::site_ref_f(&lx_p3, &wx_p0.node_p), &crate::prelude::Text::from(format!("{}_outer_moved", &name_ph))))])));
    let moved_pf = crate::lower::model::MethDef { name_p: crate::prelude::Text::from(format!("{}_outer_moved", &name_ph)), recv_p: crate::lower::model::Recv::RecvRc, params_p: crate::prelude::Array::new(), cx_p: crate::lower::model::CxArg::CxMut, ret_p: crate::lower::model::OutTy::OutUnit, body_p: crate::prelude::Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XCx), crate::prelude::Text::lit("swap_later"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XSelf))])))]), tail_p: crate::lower::model::Ex::XUnit, doc_p: crate::prelude::Text::lit("The switch\'s outer fired: after the tick\'s propagation the switch takes the inner it then holds.") };
    let w3_pg = {
        let mut this: crate::lower::node_::Wx = w2_pk.clone();
        this.taken_p = crate::prelude::append(&this.taken_p, &crate::prelude::Array::from(vec![outer_p6.clone(), listen_p7.clone(), ofollow_p8.clone(), crate::prelude::Text::from(format!("{}_made", &outer_p6)), crate::prelude::Text::from(format!("{}_outer_moved", &name_ph))]));
        this.fields_p = crate::prelude::append(&this.fields_p, &crate::prelude::Array::from(vec![(outer_p6.clone(), crate::lower::model::OutTy::OutHold(::std::rc::Rc::new(crate::lower::model::OutTy::OutOpt(::std::rc::Rc::new(outer_ty_p9.clone())))), crate::prelude::Text::lit("`@Switch`\'s outer, made at the build")), (listen_p7.clone(), crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("prism_rtl::Listen")), crate::prelude::Array::from(vec![t_p4.clone()])), crate::prelude::Text::lit("the subscription to the switch\'s current inner")), (ofollow_p8.clone(), crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("prism_rtl::Follow")), crate::prelude::Array::new()), crate::prelude::Text::lit("the subscription to the outer\'s update event"))]));
        this.moves_p = crate::prelude::append(&this.moves_p, &crate::prelude::Array::from(vec![(outer_p6.clone(), crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Hold::new")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XNone, crate::lower::model::Ex::XCx]))), (listen_p7.clone(), crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Default::default")), crate::prelude::Array::new())), (ofollow_p8.clone(), crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("prism_rtl::Follow::new")), crate::prelude::Array::new()))]));
        this.build_p = crate::prelude::append(&this.build_p, &crate::prelude::Array::from(vec![set_outer_pc.clone(), listened_pd.clone(), followed_pe.clone()]));
        this.getters_p = crate::prelude::append(&this.getters_p, &crate::prelude::Array::from(vec![made_pa.clone(), moved_pf.clone()]));
        this.switches_p = crate::prelude::push(&this.switches_p, &name_ph);
        this
    };
    (w3_pg.clone(), crate::lower::node_::Wres::WrEv(crate::lower::node_::ev_ref_of_f(&w3_pg, &id_pj)))
}

/// ```prism
/// SwapBody: fn Wx -> [Do]
/// ```
pub fn swap_body_f(wx_p0: &crate::lower::node_::Wx) -> crate::prelude::Array<crate::lower::model::Do> {
    crate::prelude::each(&wx_p0.switches_p, &(|name_p1: &crate::prelude::Text| {
        let outer_now_p2 = crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::from(format!("{}_outer", name_p1)))), crate::prelude::Text::lit("get"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx]))), crate::prelude::Text::lit("expect"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XStr(crate::prelude::Text::lit("`@Switch`\'s outer is made at the build"))]));
        crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::from(format!("{}_listen", name_p1)))), crate::prelude::Text::lit("listen_above"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(outer_now_p2.clone()), crate::prelude::Text::lit("sample"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx])))), crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XSelf)))), crate::lower::model::Ex::XPath(crate::lower::model::ref_child_f(&crate::lower::site_ref_f(&wx_p0.lx_p, &wx_p0.node_p), name_p1)), crate::lower::model::Ex::XPath(crate::lower::model::ref_child_f(&crate::lower::site_ref_f(&wx_p0.lx_p, &wx_p0.node_p), &crate::prelude::Text::from(format!("{}_above", name_p1))))])))
    }))
}
