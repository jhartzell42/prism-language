//! The module `Lower.Node.Switch`, from `target/bootstrap/src/prismc/lower/node/switch.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// `ClauseRow`:
///
/// ```prism
/// type ClauseRow = record:
/// ```
#[derive(Clone)]
pub struct ClauseRow {
    pub case: GenCase,
    pub parent: crate::lower::node_::Wx,
    pub width: Nat,
}

/// `GenCase`:
///
/// ```prism
/// type GenCase = record:
/// ```
#[derive(Clone)]
pub struct GenCase {
    pub node_: crate::lower::model::NodeDef,
    pub params: Array<(Text, crate::lower::model::OutTy)>,
    pub pat: crate::lower::model::Pa,
    pub conds: Array<crate::lower::model::Cc>,
    pub passed: Array<crate::lower::model::Ex>,
}

impl ToPod for GenCase {
    fn to_pod(&self) -> Pod {
        Pod::record("GenCase", vec![("node", self.node_.to_pod()), ("params", self.params.to_pod()), ("pat", self.pat.to_pod()), ("conds", self.conds.to_pod()), ("passed", self.passed.to_pod())])
    }
}

impl FromPod for GenCase {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(GenCase { node_: FromPod::from_pod(field(p, "node")?)?, params: FromPod::from_pod(field(p, "params")?)?, pat: FromPod::from_pod(field(p, "pat")?)?, conds: FromPod::from_pod(field(p, "conds")?)?, passed: FromPod::from_pod(field(p, "passed")?)? })
    }
}

/// `GenRow`:
///
/// ```prism
/// type GenRow = record:
/// ```
#[derive(Clone)]
pub struct GenRow {
    pub node_: crate::lower::model::NodeDef,
    pub parent: crate::lower::node_::Wx,
    pub dyn_result: Option<crate::lower::model::OutTy>,
}

/// ```prism
/// RowEnv: unbounded fn Wx, Wx, Env, Block -> ((Wx, Wx, Env))
/// ```
pub fn row_env(parent: &crate::lower::node_::Wx, row_wx: &crate::lower::node_::Wx, menv: &crate::lower::types::Env, body: &crate::syntax::Block) -> (crate::lower::node_::Wx, crate::lower::node_::Wx, crate::lower::types::Env) {
    let names = crate::lower::expr::read_names(&crate::check::typed::print::block_exprs(body));
    fold(&names, &(parent.clone(), row_wx.clone(), crate::lower::types::empty_env()), &(|(p_, r, env): &(crate::lower::node_::Wx, crate::lower::node_::Wx, crate::lower::types::Env), n: &Text| match get(&menv.names, n) {
        Some(crate::lower::types::Bn::BnLocal(rs, mode, t)) => (p_.clone(), r.clone(), crate::lower::types::bind(env, n, &crate::lower::types::Bn::BnLocal(over_parent(&rs), crate::lower::types::Holding::Owned, t))),
        Some(crate::lower::types::Bn::BnEv(er, t)) => {
            let pname = crate::lower::node_::gn_of(p_, &er.node_).name.clone();
            let (rs, r1) = crate::lower::node_::fresh_name(r, &crate::lower::snake(n));
            let (id, r2) = crate::lower::node_::add_gn(&r1, &rs, &t, &crate::lower::node_::GnKind::GnPort, &Nat::from(0u32));
            let r3 = {
                let mut this: crate::lower::node_::Wx = r2.clone();
                this.subs = push(&this.subs, &(pname.clone(), rs.clone(), t.clone()));
                this
            };
            let p2 = if crate::check::types::has_text(&p_.ports, &pname) {
                p_.clone()
            } else {
                crate::lower::node_::connect(&with_port(p_, &pname), &crate::lower::node_::ev_ref_of(p_, &er.node_), &crate::lower::node_::Sk::SkPort(pname.clone()))
            };
            (p2.clone(), r3.clone(), crate::lower::types::bind(env, n, &crate::lower::types::Bn::BnEv(crate::lower::node_::ev_ref_of(&r3, &id), t.clone())))
        },
        Some(crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(recv, m, xs), _, t)) => if &*recv == &crate::lower::model::Ex::XSelf {
            (p_.clone(), r.clone(), crate::lower::types::bind(env, n, &crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(Rc::new(parent_ref()), m.clone(), xs), Array::from(vec![crate::lower::node_::Read::ParentRead(m.clone())]), t)))
        } else {
            row_param_env(p_, r, env, menv, n)
        },
        Some(crate::lower::types::Bn::BnDyn(_, _, _)) => row_param_env(p_, r, env, menv, n),
        Some(crate::lower::types::Bn::BnHold(f, t)) => (p_.clone(), r.clone(), crate::lower::types::bind(env, n, &crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(parent_ref()), f.clone())), Text::lit("get"), Array::from(vec![crate::lower::model::Ex::XCx])), Array::from(vec![crate::lower::node_::Read::ParentRead(f.clone())]), t))),
        _ => (p_.clone(), r.clone(), env.clone()),
    }))
}

/// ```prism
/// RowParamEnv: fn Wx, Wx, Env, Env, Text -> ((Wx, Wx, Env))
/// ```
pub fn row_param_env(p_: &crate::lower::node_::Wx, r: &crate::lower::node_::Wx, env: &crate::lower::types::Env, menv: &crate::lower::types::Env, n: &Text) -> (crate::lower::node_::Wx, crate::lower::node_::Wx, crate::lower::types::Env) {
    match get(&menv.names, &Text::from(format!("{}#row", n))) {
        Some(crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(_, m, xs), _, t)) => (p_.clone(), r.clone(), crate::lower::types::bind(env, n, &crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(Rc::new(parent_ref()), m.clone(), xs), Array::from(vec![crate::lower::node_::Read::ParentRead(m.clone())]), t))),
        _ => (p_.clone(), r.clone(), env.clone()),
    }
}

/// ```prism
/// OverParent: fn Ex -> Ex
/// ```
pub fn over_parent(x: &crate::lower::model::Ex) -> crate::lower::model::Ex {
    match x {
        crate::lower::model::Ex::XSelf => parent_ref(),
        crate::lower::model::Ex::XField(y, f) => crate::lower::model::Ex::XField(Rc::new(over_parent(&**y)), f.clone()),
        crate::lower::model::Ex::XPart(y, k) => crate::lower::model::Ex::XPart(Rc::new(over_parent(&**y)), k.clone()),
        crate::lower::model::Ex::XMethod(y, m, xs) => crate::lower::model::Ex::XMethod(Rc::new(over_parent(&**y)), m.clone(), xs.clone()),
        crate::lower::model::Ex::XUpgrade(y) => crate::lower::model::Ex::XUpgrade(Rc::new(over_parent(&**y))),
        _ => crate::lower::model::Ex::XField(Rc::new(parent_ref()), crate::lower::types::place_stem(x)),
    }
}

/// ```prism
/// let parentRef
/// ```
pub fn parent_ref() -> crate::lower::model::Ex {
    crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XUpgrade(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::lit("parent"))))), Text::lit("expect"), Array::from(vec![crate::lower::model::Ex::XStr(Text::lit("the block outlives its rows"))]))
}

/// ```prism
/// let parentArg
/// ```
pub fn parent_arg() -> crate::lower::model::Ex {
    crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XUpgrade(Rc::new(crate::lower::model::Ex::XVar(Text::lit("parent"))))), Text::lit("expect"), Array::from(vec![crate::lower::model::Ex::XStr(Text::lit("the block outlives its rows"))]))
}

/// ```prism
/// WithPort: fn Wx, Text -> Wx
/// ```
pub fn with_port(wx: &crate::lower::node_::Wx, pname: &Text) -> crate::lower::node_::Wx {
    let mut this: crate::lower::node_::Wx = wx.clone();
    this.ports = push(&this.ports, pname);
    this
}

/// ```prism
/// RebuildLine: unbounded fn Wx, Env, Env, Expr, Block, Expr, ?Bn -> ((Wx, Wres))
/// ```
pub fn rebuild_line(wx: &crate::lower::node_::Wx, benv: &crate::lower::types::Env, menv: &crate::lower::types::Env, scrut: &crate::syntax::Expr, body: &crate::syntax::Block, e: &crate::syntax::Expr, bound_opt: &Option<crate::lower::types::Bn>) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    let lx = wx.lx.clone();
    let pos = wx.pos.clone();
    let wx1 = {
        let mut this: crate::lower::node_::Wx = wx.clone();
        this.pos = crate::lower::model::next_pos(&this.pos);
        this
    };
    let (src_ex, reads) = crate::lower::node_::dynamics::dynamic_expr(&wx1, menv, scrut);
    let vt = crate::lower::types::out_ty_of(&lx, &crate::lower::types::peel(&crate::lower::type_at(&lx, &scrut.span)));
    let (name, wx2) = crate::lower::node_::fresh_name(&wx1, &Text::lit("generation"));
    if gives_dynamic(&crate::lower::type_at(&lx, &e.span)) {
        rebuild_dynamic(&wx2, menv, body, &src_ex, &reads, &vt, &name, &pos)
    } else {
        {
            let (up_id, wx3) = match bound_opt {
                Some(crate::lower::types::Bn::BnEv(er, _)) => (er.node_.clone(), wx2.clone()),
                _ => crate::lower::node_::add_gn(&wx2, &Text::from(format!("{}_fired", &name)), &crate::lower::types::out_ty_of(&lx, &crate::lower::types::peel(&crate::lower::type_at(&lx, &e.span))), &crate::lower::node_::GnKind::GnNamed, &Nat::from(0u32)),
            };
            let (cases, wx4) = gen_cases(&wx3, menv, body, &vt, &name);
            let row_defs = each(&cases, &(|c: &GenCase| c.node_.clone()));
            let select = gen_select(&wx4, menv, body, &cases, &pos);
            let wx5 = {
                let mut this: crate::lower::node_::Wx = wx4.clone();
                this.gens = push(&this.gens, &crate::lower::model::GenDef { name: name.clone(), pos: pos.clone(), at: crate::lower::node_::finish::place_at(wx, &Text::lit("self"), &pos), source: src_ex.clone(), value_ty: vt.clone(), select: select.clone(), transparent: false, width: Nat::from(0u32), moved: or(&crate::lower::node_::finish::hosted_rows(wx), &Text::lit("")) });
                this.gen_holds = push(&this.gen_holds, &(name.clone(), reads.clone()));
                this.rows = fold(&row_defs, &this.rows, &(|acc: &Array<crate::lower::model::NodeDef>, rd: &crate::lower::model::NodeDef| append(&push(acc, rd), &rd.children)));
                this.getters = push(&this.getters, &gen_up(&name, &crate::lower::node_::gn_of(&wx4, &up_id).name, &crate::lower::node_::gn_of(&wx4, &up_id).ty));
                this
            };
            (wx5.clone(), crate::lower::node_::Wres::WrEv(crate::lower::node_::ev_ref_of(&wx5, &up_id)))
        }
    }
}

/// The step machine of `RebuildLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RebuildLine: unbounded fn Wx, Env, Env, Expr, Block, Expr, ?Bn -> ((Wx, Wres))
/// ```
pub struct RebuildLine {
    pub wx: crate::lower::node_::Wx,
    pub benv: crate::lower::types::Env,
    pub menv: crate::lower::types::Env,
    pub scrut: crate::syntax::Expr,
    pub body: crate::syntax::Block,
    pub e: crate::syntax::Expr,
    pub bound_opt: Option<crate::lower::types::Bn>,
}

impl prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::node_::Wres)> for RebuildLine {
    fn cycle(&self) -> prism_rtl::Turn<(crate::lower::node_::Wx, crate::lower::node_::Wres)> {
        let wx = &self.wx;
        let benv = &self.benv;
        let menv = &self.menv;
        let scrut = &self.scrut;
        let body = &self.body;
        let e = &self.e;
        let bound_opt = &self.bound_opt;
        let lx = wx.lx.clone();
        let pos = wx.pos.clone();
        let wx1 = {
            let mut this: crate::lower::node_::Wx = wx.clone();
            this.pos = crate::lower::model::next_pos(&this.pos);
            this
        };
        let bound_opt = bound_opt.clone();
        let body = body.clone();
        let e = e.clone();
        let menv = menv.clone();
        let scrut = scrut.clone();
        let wx = wx.clone();
        call_then(crate::lower::node_::dynamics::start_dynamic_expr(wx1.clone(), menv.clone(), scrut.clone()), move |dynamic_expr_4431: (crate::lower::model::Ex, Array<crate::lower::node_::Read>)| {
            let (src_ex, reads) = dynamic_expr_4431;
            call_then(crate::lower::types::start_out_ty_of(lx.clone(), crate::lower::types::peel(&crate::lower::type_at(&lx, &scrut.span))), move |out_ty_of_4473: crate::lower::model::OutTy| {
                let vt = out_ty_of_4473;
                let (name, wx2) = crate::lower::node_::fresh_name(&wx1, &Text::lit("generation"));
                if gives_dynamic(&crate::lower::type_at(&lx, &e.span)) {
                    prism_rtl::Turn::Finished(rebuild_dynamic(&wx2, &menv, &body, &src_ex, &reads, &vt, &name, &pos))
                } else {
                    {
                        let (up_id, wx3) = match &bound_opt {
                            Some(crate::lower::types::Bn::BnEv(er, _)) => (er.node_.clone(), wx2.clone()),
                            _ => crate::lower::node_::add_gn(&wx2, &Text::from(format!("{}_fired", &name)), &crate::lower::types::out_ty_of(&lx, &crate::lower::types::peel(&crate::lower::type_at(&lx, &e.span))), &crate::lower::node_::GnKind::GnNamed, &Nat::from(0u32)),
                        };
                        let (cases, wx4) = gen_cases(&wx3, &menv, &body, &vt, &name);
                        let row_defs = each(&cases, &(|c: &GenCase| c.node_.clone()));
                        let select = gen_select(&wx4, &menv, &body, &cases, &pos);
                        let wx5 = {
                            let mut this: crate::lower::node_::Wx = wx4.clone();
                            this.gens = push(&this.gens, &crate::lower::model::GenDef { name: name.clone(), pos: pos.clone(), at: crate::lower::node_::finish::place_at(&wx, &Text::lit("self"), &pos), source: src_ex.clone(), value_ty: vt.clone(), select: select.clone(), transparent: false, width: Nat::from(0u32), moved: or(&crate::lower::node_::finish::hosted_rows(&wx), &Text::lit("")) });
                            this.gen_holds = push(&this.gen_holds, &(name.clone(), reads.clone()));
                            this.rows = fold(&row_defs, &this.rows, &(|acc: &Array<crate::lower::model::NodeDef>, rd: &crate::lower::model::NodeDef| append(&push(acc, rd), &rd.children)));
                            this.getters = push(&this.getters, &gen_up(&name, &crate::lower::node_::gn_of(&wx4, &up_id).name, &crate::lower::node_::gn_of(&wx4, &up_id).ty));
                            this
                        };
                        prism_rtl::Turn::Finished((wx5.clone(), crate::lower::node_::Wres::WrEv(crate::lower::node_::ev_ref_of(&wx5, &up_id))))
                    }
                }
            })
        })
    }
}

/// `Start RebuildLine, x`: what the function value is when passed to `@Run`.
pub fn start_rebuild_line(wx: crate::lower::node_::Wx, benv: crate::lower::types::Env, menv: crate::lower::types::Env, scrut: crate::syntax::Expr, body: crate::syntax::Block, e: crate::syntax::Expr, bound_opt: Option<crate::lower::types::Bn>) -> Rc<dyn prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::node_::Wres)>> {
    Rc::new(RebuildLine { wx, benv, menv, scrut, body, e, bound_opt })
}

/// ```prism
/// GivesDynamic: fn Ty -> Bool
/// ```
pub fn gives_dynamic(t: &crate::check::types::Ty) -> bool {
    'm5725: {
        if let crate::check::types::Ty::TySig(m5725_0_0, m5725_0_1) = t && (m5725_0_0 == &Text::lit("$")) && let crate::check::types::Ty::TySig(m5725_0_1_r_0, _) = &**m5725_0_1 && (m5725_0_1_r_0 == &Text::lit("$")) {
            break 'm5725 true;
        }
        if let crate::check::types::Ty::TyAt(i, _) = t {
            break 'm5725 gives_dynamic(&**i);
        }
        false
    }
}

/// ```prism
/// RebuildDynamic: unbounded fn Wx, Env, Block, Ex, [Read], OutTy, Text, Pos -> ((Wx, Wres))
/// ```
pub fn rebuild_dynamic(wx: &crate::lower::node_::Wx, menv: &crate::lower::types::Env, body: &crate::syntax::Block, src_ex: &crate::lower::model::Ex, reads: &Array<crate::lower::node_::Read>, vt: &crate::lower::model::OutTy, name: &Text, pos: &crate::lower::model::Pos_) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    let row_name = Text::from(format!("{}Gen{}", &wx.node_, &crate::lower::node_::keyed::row_suffix(wx)));
    let whole = gen_row_of(wx, menv, body, vt, &row_name, name);
    match &whole.dyn_result {
        None => {
            let wx2 = {
                let mut this: crate::lower::node_::Wx = whole.parent.clone();
                this.build = push(&this.build, &crate::lower::expr::refusal_do(&Text::lit("a `rebuild` whose generation gives a dynamic it does not lower")));
                this
            };
            (wx2.clone(), crate::lower::node_::Wres::WrUnit)
        },
        Some(rt) => {
            let dyn_ty = crate::lower::model::OutTy::OutDyn(Rc::new(rt.clone()));
            let result = Text::from(format!("{}_result", name));
            let live = Text::from(format!("{}_live", &result));
            let what = Text::from(format!("the dynamic of the `rebuild` at place {}", &crate::lower::model::place_text(pos)));
            let tail = append(&append(&Array::from(vec![crate::lower::model::Ex::XWeak(Rc::new(crate::lower::model::Ex::XSelf))]), &crate::lower::node_::keyed::hosted_passed(wx)), &Array::from(vec![crate::lower::model::Ex::XCx]));
            let built = crate::lower::expr::try_of(&crate::lower::model::Ex::XCall(Text::from(format!("{}::build", &whole.node_.name)), append(&Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("path")), crate::lower::model::Ex::XVar(Text::lit("value"))]), &tail)));
            let kept = crate::lower::model::Do::DoAssign(crate::lower::model::Ex::XDeref(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), live.clone())), Text::lit("borrow_mut"), Array::new()))), crate::lower::model::Ex::XCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("row"))), Text::lit("result_dynamic"), Array::new())])));
            let marked = crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_snap", &result)))), Text::lit("mark"), Array::from(vec![crate::lower::model::Ex::XCx])));
            let select = crate::lower::model::Ex::XBlock(Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(Text::lit("row")), built.clone()), kept.clone(), marked.clone()]), Rc::new(crate::lower::model::Ex::XVar(Text::lit("row"))));
            let current = crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", &live)))), Text::lit("borrow"), Array::new())))), Text::lit("expect"), Array::from(vec![crate::lower::model::Ex::XStr(Text::lit("a `rebuild` has a generation from its build on"))]));
            let wx2 = {
                let mut this: crate::lower::node_::Wx = whole.parent.clone();
                this.gens = push(&this.gens, &crate::lower::model::GenDef { name: name.clone(), pos: pos.clone(), at: crate::lower::node_::finish::place_at(wx, &Text::lit("self"), pos), source: src_ex.clone(), value_ty: vt.clone(), select: select.clone(), transparent: false, width: Nat::from(0u32), moved: or(&crate::lower::node_::finish::hosted_rows(wx), &Text::lit("")) });
                this.gen_holds = push(&this.gen_holds, &(name.clone(), reads.clone()));
                this.rows = append(&push(&this.rows, &whole.node_), &whole.node_.children);
                this.taken = append(&this.taken, &Array::from(vec![result.clone(), live.clone(), Text::from(format!("{}_now", &result)), Text::from(format!("{}_snap", &result)), Text::from(format!("{}_publish", &result)), Text::from(format!("{}_moved", &result))]));
                this.fields = append(&this.fields, &Array::from(vec![(live.clone(), crate::lower::model::OutTy::OutCell(Rc::new(crate::lower::model::OutTy::OutOpt(Rc::new(dyn_ty.clone())))), Text::lit("the current generation\'s result, which the snapshot of the `rebuild`\'s dynamic is taken from")), (Text::from(format!("{}_snap", &result)), crate::lower::model::OutTy::OutSnapshot(Rc::new(dyn_ty.clone())), Text::from(format!("the `rebuild` at place {}\'s dynamic, structural: its snapshots, the generations\' results and the lagged dynamic (pick ST)", &crate::lower::model::place_text(pos))))]));
                this.moves = push(&this.moves, &(live.clone(), crate::lower::model::Ex::XCall(Text::lit("RefCell::new"), Array::from(vec![crate::lower::model::Ex::XNone]))));
                this.inits = push(&this.inits, &(Text::from(format!("{}_snap", &result)), crate::lower::model::Ex::XCall(Text::lit("Snapshot::new"), Array::from(vec![crate::lower::model::Ex::XStr(what.clone())]))));
                this.getters = append(&this.getters, &Array::from(vec![crate::lower::model::MethDef { name: Text::from(format!("{}_now", &result)), recv: crate::lower::model::Recv::RecvRef, params: Array::new(), cx_: crate::lower::model::CxArg::CxRef, ret: dyn_ty.clone(), body: Array::new(), tail: current.clone(), doc: Text::lit("The current generation\'s result: what the snapshot of the `rebuild`\'s dynamic is taken from (pick ST).") }, crate::lower::node_::static_::snap_getter(&result, &dyn_ty, &Text::lit("The `rebuild`\'s dynamic, its generation\'s result, a structural dynamic (pick ST): one tick behind the generations, the snapshot of the tick before the tick the read point is after."))]));
                this.snaps = push(&this.snaps, &crate::lower::node_::SnapDef { name: result.clone(), live: Text::from(format!("{}_now", &result)), ty: dyn_ty.clone(), eq: false, builder: name.clone(), before: false, what: what.clone() });
                this
            };
            (wx2.clone(), crate::lower::node_::Wres::WrDyn(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XSelf), result.clone(), Array::from(vec![crate::lower::model::Ex::XCx])), Array::from(vec![crate::lower::node_::Read::OwnRead(result.clone())]), dyn_ty.clone()))
        },
    }
}

/// ```prism
/// ClauseWidgetLine: unbounded fn Wx, Env, Expr, Block, Text, ValInfo, Expr -> ((Wx, Wres))
/// ```
pub fn clause_widget_line(wx: &crate::lower::node_::Wx, menv: &crate::lower::types::Env, scrut: &crate::syntax::Expr, call: &crate::syntax::Block, qk: &Text, v_: &crate::check::env::ValInfo, e: &crate::syntax::Expr) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    let lx = wx.lx.clone();
    let pos = wx.pos.clone();
    let (src_ex, reads) = crate::lower::node_::dynamics::dynamic_expr(wx, menv, scrut);
    let vt = crate::lower::types::out_ty_of(&lx, &crate::lower::types::peel(&crate::lower::type_at(&lx, &scrut.span)));
    let (name, wx1) = crate::lower::node_::fresh_name(wx, &Text::lit("generation"));
    let (up_id, wx2) = crate::lower::node_::add_gn(&wx1, &Text::from(format!("{}_fired", &name)), &crate::lower::types::out_ty_of(&lx, &crate::lower::types::out_of(&crate::lower::type_at(&lx, &e.span))), &crate::lower::node_::GnKind::GnNamed, &Nat::from(0u32));
    let clauses = crate::lower::jobs::clauses_of(&lx.g, qk);
    let row_name = Text::from(format!("{}Gen{}", &wx.node_, &crate::lower::node_::keyed::row_suffix(wx)));
    let (rows, wx3) = run_to_end(fold_job(crate::check::errors::range0(&len(&clauses)), (Array::new(), wx2.clone()), {
        let clauses = clauses.clone();
        let menv = menv.clone();
        let v_ = v_.clone();
        let row_name = row_name.clone();
        let name = name.clone();
        Rc::new(move |(p0, p1): ((Array<ClauseRow>, crate::lower::node_::Wx), Nat)| {
            let clauses = clauses.clone();
            let menv = menv.clone();
            let v_ = v_.clone();
            let row_name = row_name.clone();
            let name = name.clone();
            entered(once_job(move || {
                let (acc, w) = p0;
                let i = p1;
                {
                    let c = or(&index(&clauses, &i), &crate::lower::functions::dummy_clause());
                    let cr = clause_row_of(&w, &menv, &c, &v_, &Text::from(format!("{}{}", &row_name, &i)), &name, &true);
                    prism_rtl::Turn::Finished((push(&acc, &cr), cr.parent.clone()))
                }
            }))
        }) as Rc<dyn Fn(((Array<ClauseRow>, crate::lower::node_::Wx), Nat)) -> Rc<dyn prism_rtl::Job<(Array<ClauseRow>, crate::lower::node_::Wx)>>>
    }));
    let width = fold(&rows, &Nat::from(0u32), &(|acc: &Nat, cr: &ClauseRow| max(acc, &cr.width)));
    let cases = each(&rows, &(|cr: &ClauseRow| cr.case.clone()));
    if is_hosted_scope(wx) {
        {
            let wx4 = {
                let mut this: crate::lower::node_::Wx = wx3.clone();
                this.build = push(&this.build, &crate::lower::expr::refusal_do(&Text::lit("a widget of several clauses in a static position of a hosted scope")));
                this
            };
            (wx4.clone(), crate::lower::node_::Wres::WrUnit)
        }
    } else {
        {
            let select = gen_select(&wx3, menv, call, &cases, &pos);
            let wx4 = {
                let mut this: crate::lower::node_::Wx = wx3.clone();
                this.pos = crate::lower::model::Pos_ { scope: pos.scope.clone(), at: &pos.at + &width };
                this.gens = push(&this.gens, &crate::lower::model::GenDef { name: name.clone(), pos: pos.clone(), at: crate::lower::node_::finish::place_at(wx, &Text::lit("self"), &pos), source: src_ex.clone(), value_ty: vt.clone(), select: select.clone(), transparent: true, width: width.clone(), moved: or(&crate::lower::node_::finish::hosted_rows(wx), &Text::lit("")) });
                this.gen_holds = push(&this.gen_holds, &(name.clone(), reads.clone()));
                this.rows = fold(&cases, &this.rows, &(|acc: &Array<crate::lower::model::NodeDef>, gc: &GenCase| append(&push(acc, &gc.node_), &gc.node_.children)));
                this.getters = push(&this.getters, &gen_up(&name, &crate::lower::node_::gn_of(&wx3, &up_id).name, &crate::lower::node_::gn_of(&wx3, &up_id).ty));
                this
            };
            (wx4.clone(), crate::lower::node_::Wres::WrEv(crate::lower::node_::ev_ref_of(&wx4, &up_id)))
        }
    }
}

/// ```prism
/// IsHostedScope: fn Wx -> Bool
/// ```
pub fn is_hosted_scope(wx: &crate::lower::node_::Wx) -> bool {
    (&wx.pos.scope > &Nat::from(0u32)) || is_some_(&wx.hosted_by)
}

/// ```prism
/// IsSome: fn ?a -> Bool
/// ```
pub fn is_some_<A: Clone + 'static>(opt0: &Option<A>) -> bool {
    match opt0 {
        Some(_) => true,
        None => false,
    }
}

/// ```prism
/// GenCases: unbounded fn Wx, Env, Block, OutTy, Text -> (([GenCase], Wx))
/// ```
pub fn gen_cases(wx: &crate::lower::node_::Wx, menv: &crate::lower::types::Env, body: &crate::syntax::Block, vt: &crate::lower::model::OutTy, name: &Text) -> (Array<GenCase>, crate::lower::node_::Wx) {
    let lx = wx.lx.clone();
    let row_name = Text::from(format!("{}Gen{}", &wx.node_, &crate::lower::node_::keyed::row_suffix(wx)));
    match clause_call(&lx, body) {
        Some((qk, args)) => {
            let clauses = crate::lower::jobs::clauses_of(&lx.g, &qk);
            let v_ = crate::lower::program::val_of(&lx, &qk);
            run_to_end(fold_job(crate::check::errors::range0(&len(&clauses)), (Array::new(), wx.clone()), {
                let clauses = clauses.clone();
                let menv = menv.clone();
                let v_ = v_.clone();
                let row_name = row_name.clone();
                let name = name.clone();
                Rc::new(move |(p0, p1): ((Array<GenCase>, crate::lower::node_::Wx), Nat)| {
                    let clauses = clauses.clone();
                    let menv = menv.clone();
                    let v_ = v_.clone();
                    let row_name = row_name.clone();
                    let name = name.clone();
                    entered(once_job(move || {
                        let (acc, w) = p0;
                        let i = p1;
                        {
                            let c = or(&index(&clauses, &i), &crate::lower::functions::dummy_clause());
                            let cr = clause_row_of(&w, &menv, &c, &v_, &Text::from(format!("{}{}", &row_name, &i)), &name, &false);
                            prism_rtl::Turn::Finished((push(&acc, &cr.case), cr.parent.clone()))
                        }
                    }))
                }) as Rc<dyn Fn(((Array<GenCase>, crate::lower::node_::Wx), Nat)) -> Rc<dyn prism_rtl::Job<(Array<GenCase>, crate::lower::node_::Wx)>>>
            }))
        },
        None => {
            let whole = gen_row_of(wx, menv, body, vt, &row_name, name);
            (Array::from(vec![GenCase { node_: whole.node_.clone(), params: Array::from(vec![(Text::lit("value"), vt.clone())]), pat: crate::lower::model::Pa::PaWild, conds: Array::new(), passed: Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("value"))]) }]), whole.parent.clone())
        },
    }
}

/// ```prism
/// ?ClauseCall: fn Lx, Block -> ?((Text, [Arg]))
/// ```
pub fn clause_call(lx: &crate::lower::Lx, body: &crate::syntax::Block) -> Option<(Text, Array<crate::syntax::Arg>)> {
    'm13740: {
        let scrutinee = &body.stmts;
        if let m13740_0 = scrutinee && (m13740_0.len() == 1) && let Some(st) = index(m13740_0, &Nat::from(0u32)) {
            break 'm13740 match &st.kind {
                crate::syntax::StmtKind::SExpr(x) => clause_call_x(lx, x),
                crate::syntax::StmtKind::SIgnore(x) => clause_call_x(lx, x),
                _ => None,
            };
        }
        None
    }
}

/// ```prism
/// ?ClauseCallX: fn Lx, Expr -> ?((Text, [Arg]))
/// ```
pub fn clause_call_x(lx: &crate::lower::Lx, x: &crate::syntax::Expr) -> Option<(Text, Array<crate::syntax::Arg>)> {
    match &*x.kind {
        crate::syntax::ExprKind::ECall(c, args, _, _) => {
            let qk = crate::lower::program::blueprint_qk(lx, &**c);
            if &len(&crate::lower::jobs::clauses_of(&lx.g, &qk)) > &Nat::from(1u32) {
                Some((qk.clone(), args.clone()))
            } else {
                None
            }
        },
        _ => None,
    }
}

/// ```prism
/// ClauseRowOf: unbounded fn Wx, Env, FnClause, ValInfo, Text, Text, Bool -> ClauseRow
/// ```
pub fn clause_row_of(wx: &crate::lower::node_::Wx, menv: &crate::lower::types::Env, c: &crate::syntax::decls::FnClause, v_: &crate::check::env::ValInfo, row_name: &Text, gen_name: &Text, transparent: &bool) -> ClauseRow {
    let up_name = Text::from(format!("{}_up", gen_name));
    let lx = wx.lx.clone();
    let lxc = crate::lower::program::in_module_at(&lx, &v_.file, &v_.home, &lx.site);
    let ptys = match &v_.scheme.ty {
        crate::check::types::Ty::TyFn(_, ps, _) => ps.clone(),
        _ => Array::new(),
    };
    let pos = run_to_end(each_job(crate::check::errors::range0(&len(&c.params)), {
        let lxc = lxc.clone();
        let c = c.clone();
        let ptys = ptys.clone();
        Rc::new(move |p0: Nat| {
            let lxc = lxc.clone();
            let c = c.clone();
            let ptys = ptys.clone();
            entered(once_job(move || {
                let i = p0;
                prism_rtl::Turn::More(Rc::new(crate::lower::patterns::RustPat { lx: lxc.clone(), p_: or(&index(&c.params, &i), &crate::lower::patterns::dummy_pat()), ty: or(&index(&ptys, &i), &crate::check::types::Ty::TyErr), mode: crate::lower::types::Holding::ByRef, fresh: Text::from(format!("c{}", &i)) }))
            }))
        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<crate::lower::patterns::PatOut>>>
    }));
    let pa = crate::lower::model::Pa::PaTuple(each(&pos, &(|o: &crate::lower::patterns::PatOut| o.pa.clone())));
    let binds = fold(&pos, &Map::new(), &(|m: &Map<Text, crate::lower::types::Bn>, o: &crate::lower::patterns::PatOut| fold(&o.binds, m, &(|m2: &Map<Text, crate::lower::types::Bn>, (n, b): &(Text, crate::lower::types::Bn)| insert(m2, n, b)))));
    let binders = filter(&run_to_end(fold_job(c.params.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<(Text, crate::syntax::Range)>, crate::syntax::Pattern_)| entered(once_job(move || {
        let acc = p0;
        let p_ = p1;
        call_then(crate::check::env::names::start_pattern_binders(p_.clone()), move |pattern_binders_15253: Array<(Text, crate::syntax::Range)>| prism_rtl::Turn::Finished(append(&acc, &pattern_binders_15253)))
    }))) as Rc<dyn Fn((Array<(Text, crate::syntax::Range)>, crate::syntax::Pattern_)) -> Rc<dyn prism_rtl::Job<Array<(Text, crate::syntax::Range)>>>>)), &(|(bn, _): &(Text, crate::syntax::Range)| crate::check::env::has_key(&binds, bn)));
    let fields = run_to_end(each_job(binders.clone(), {
        let lxc = lxc.clone();
        Rc::new(move |p0: (Text, crate::syntax::Range)| {
            let lxc = lxc.clone();
            entered(once_job(move || {
                let (bn, r) = p0;
                call_then(crate::lower::types::start_out_ty_of(lxc.clone(), crate::lower::types::peel(&crate::lower::binder_ty(&lxc, &r))), move |out_ty_of_15367: crate::lower::model::OutTy| prism_rtl::Turn::Finished((crate::lower::snake(&bn), out_ty_of_15367, bn.clone())))
            }))
        }) as Rc<dyn Fn((Text, crate::syntax::Range)) -> Rc<dyn prism_rtl::Job<(Text, crate::lower::model::OutTy, Text)>>>
    }));
    let row_fields = push(&each(&fields, &(|(f, t, bn): &(Text, crate::lower::model::OutTy, Text)| (f.clone(), t.clone(), Text::from(format!("`{}`", bn))))), &(Text::lit("parent"), crate::lower::model::OutTy::OutWeak(wx.node_.clone()), Text::lit("the node of the `rebuild`")));
    let row_inits = each(&fields, &(|(f, _, _): &(Text, crate::lower::model::OutTy, Text)| (f.clone(), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(f.clone()))))));
    let row_taken = append(&crate::lower::node_::node_hooks(), &push(&each(&fields, &(|(f, _, _): &(Text, crate::lower::model::OutTy, Text)| f.clone())), &Text::lit("parent")));
    let r00 = crate::lower::node_::new_wx(&lxc, row_name, &row_fields, &row_inits, &Array::from(vec![(Text::lit("parent"), crate::lower::model::Ex::XVar(Text::lit("parent")))]), &Array::new(), &Map::new(), &row_taken, &wx.inlining, &crate::lower::node_::finish::hosted_rows(wx));
    let r0 = if *transparent {
        {
            let mut this: crate::lower::node_::Wx = r00.clone();
            this.pos = wx.pos.clone();
            this
        }
    } else {
        r00.clone()
    };
    let body = match &c.body {
        crate::syntax::decls::FnBody::BodyBlock(b) => b.clone(),
        crate::syntax::decls::FnBody::BodyExpr(x) => crate::syntax::Block { stmts: Array::from(vec![crate::syntax::Stmt { kind: crate::syntax::StmtKind::SExpr(x.clone()), span: x.span.clone() }]), inline: true, span: x.span.clone() },
    };
    let (p1, r1, ports) = row_env(wx, &r0, menv, &body);
    let (be, me) = fold(&fields, &(crate::lower::types::empty_env(), crate::lower::types::empty_env()), &(|(b, m): &(crate::lower::types::Env, crate::lower::types::Env), (f, t, bn): &(Text, crate::lower::model::OutTy, Text)| crate::lower::node_::bind_plain(b, m, bn, f, t)));
    let r2 = crate::lower::node_::def::block_into(&r1, &be, &me, &body);
    let r3 = match &r2.result {
        crate::lower::node_::Wres::WrEv(r) => crate::lower::node_::connect(&r2, r, &crate::lower::node_::Sk::SkUp(up_name.clone())),
        crate::lower::node_::Wres::WrParts(_) => {
            let mut this: crate::lower::node_::Wx = r2.clone();
            this.build = push(&this.build, &crate::lower::expr::refusal_do(&Text::lit("a widget of several clauses whose clause ends on a bundle")));
            this
        },
        _ => r2.clone(),
    };
    let node_ = crate::lower::node_::finish::finish_node(&r3, row_name, &append(&push(&each(&fields, &(|(f, t, _): &(Text, crate::lower::model::OutTy, Text)| (f.clone(), t.clone()))), &(Text::lit("parent"), crate::lower::model::OutTy::OutWeak(wx.node_.clone()))), &crate::lower::node_::keyed::hosted_params(wx)), &true);
    let p2 = gen_marked(&p1, gen_name, &r3);
    let passed = each(&fields, &(|(f, t, bn): &(Text, crate::lower::model::OutTy, Text)| match get(&binds, bn) {
        Some(crate::lower::types::Bn::BnLocal(rs, mode, bt)) => crate::lower::types::own(&crate::lower::types::Vl::VlPlace(rs, mode, bt)),
        _ => crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(f.clone()))),
    }));
    ClauseRow { case: GenCase { node_: node_.clone(), params: each(&fields, &(|(f, t, _): &(Text, crate::lower::model::OutTy, Text)| (f.clone(), t.clone()))), pat: pa.clone(), conds: fold(&pos, &Array::new(), &(|acc: &Array<crate::lower::model::Cc>, o: &crate::lower::patterns::PatOut| append(acc, &o.conds))), passed: passed.clone() }, parent: p2.clone(), width: or(&(&r2.pos.at).checked_sub(&r0.pos.at), &Nat::from(0u32)) }
}

/// ```prism
/// GenRowOf: unbounded fn Wx, Env, Block, OutTy, Text, Text -> GenRow
/// ```
pub fn gen_row_of(wx: &crate::lower::node_::Wx, menv: &crate::lower::types::Env, body: &crate::syntax::Block, vt: &crate::lower::model::OutTy, row_name: &Text, gen_name: &Text) -> GenRow {
    let lx = wx.lx.clone();
    let up_name = Text::from(format!("{}_up", gen_name));
    let r0 = crate::lower::node_::new_wx(&lx, row_name, &Array::from(vec![(Text::lit("value"), vt.clone(), Text::lit("the generation\'s value, `_`")), (Text::lit("parent"), crate::lower::model::OutTy::OutWeak(wx.node_.clone()), Text::lit("the node of the `rebuild`"))]), &Array::from(vec![(Text::lit("value"), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(Text::lit("value")))))]), &Array::from(vec![(Text::lit("parent"), crate::lower::model::Ex::XVar(Text::lit("parent")))]), &Array::new(), &Map::new(), &append(&crate::lower::node_::node_hooks(), &Array::from(vec![Text::lit("value"), Text::lit("parent"), Text::lit("result"), Text::lit("result_dynamic")])), &wx.inlining, &crate::lower::node_::finish::hosted_rows(wx));
    let (p1, r1, ports) = row_env(wx, &r0, menv, body);
    let be = crate::lower::types::bind(&build_spelling(&ports), &Text::lit("_"), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(Text::lit("value")), crate::lower::types::Holding::Owned, vt.clone()));
    let me = crate::lower::types::bind(&ports, &Text::lit("_"), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::lit("value")), crate::lower::types::Holding::Owned, vt.clone()));
    let r2 = crate::lower::node_::def::block_into(&r1, &be, &me, body);
    let (r3, dyn_result_opt) = match &r2.result {
        crate::lower::node_::Wres::WrEv(r) => (crate::lower::node_::connect(&r2, r, &crate::lower::node_::Sk::SkUp(up_name.clone())), None),
        crate::lower::node_::Wres::WrDyn(ex, result_reads, rt) => (gen_result(&r2, gen_name, ex, result_reads, rt), Some(rt.clone())),
        crate::lower::node_::Wres::WrParts(_) => {
            let r2b = {
                let mut this: crate::lower::node_::Wx = r2.clone();
                this.build = push(&this.build, &crate::lower::expr::refusal_do(&Text::lit("a `rebuild` whose block ends on a bundle")));
                this
            };
            (r2b.clone(), None)
        },
        _ => (r2.clone(), None),
    };
    GenRow { node_: crate::lower::node_::finish::finish_node(&r3, row_name, &append(&Array::from(vec![(Text::lit("value"), vt.clone()), (Text::lit("parent"), crate::lower::model::OutTy::OutWeak(wx.node_.clone()))]), &crate::lower::node_::keyed::hosted_params(wx)), &true), parent: gen_marked(&p1, gen_name, &r3), dyn_result: dyn_result_opt.clone() }
}

/// ```prism
/// GenResult: fn Wx, Text, Ex, [Read], OutTy -> Wx
/// ```
pub fn gen_result(r: &crate::lower::node_::Wx, gen_name: &Text, ex: &crate::lower::model::Ex, result_reads: &Array<crate::lower::node_::Read>, rt: &crate::lower::model::OutTy) -> crate::lower::node_::Wx {
    let own_behind = filter(&crate::lower::node_::finish::reads_closed(&r.dyn_reads, result_reads), &(|rd: &crate::lower::node_::Read| match rd {
        crate::lower::node_::Read::OwnRead(_) => true,
        crate::lower::node_::Read::ParentRead(_) => false,
    }));
    let made = crate::lower::model::Ex::XCall(Text::lit("Dynamic::of"), Array::from(vec![crate::lower::model::Ex::XClosure(true, Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("cx"))]), Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("me"))), Text::lit("result"), Array::from(vec![crate::lower::model::Ex::XCx])))), crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XCall(Text::lit("Rc::new"), Array::from(vec![crate::lower::model::Ex::XCall(Text::lit("Port::new"), Array::new())]))))]));
    let doc = Text::from(format!("The generation\'s result as a dynamic, which the block keeps while the generation is current; the block hears it move through `{}_result_moved`, not through the dynamic\'s port.", gen_name));
    let mut this: crate::lower::node_::Wx = r.clone();
    this.getters = append(&this.getters, &Array::from(vec![crate::lower::model::MethDef { name: Text::lit("result"), recv: crate::lower::model::Recv::RecvRef, params: Array::new(), cx_: crate::lower::model::CxArg::CxRef, ret: rt.clone(), body: Array::new(), tail: ex.clone(), doc: Text::lit("The generation\'s result, which the `rebuild` hands back.") }, crate::lower::model::MethDef { name: Text::lit("result_dynamic"), recv: crate::lower::model::Recv::RecvRc, params: Array::new(), cx_: crate::lower::model::CxArg::CxNone, ret: crate::lower::model::OutTy::OutDyn(Rc::new(rt.clone())), body: Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(Text::lit("me")), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XSelf)))]), tail: made.clone(), doc: doc.clone() }]));
    this.result_moved = if &len(&own_behind) > &Nat::from(0u32) {
        Some((Text::from(format!("{}_result_moved", gen_name)), own_behind.clone()))
    } else {
        None
    };
    this
}

/// ```prism
/// GenMarked: fn Wx, Text, Wx -> Wx
/// ```
pub fn gen_marked(parent: &crate::lower::node_::Wx, gen_name: &Text, row_wx: &crate::lower::node_::Wx) -> crate::lower::node_::Wx {
    let reads = crate::lower::node_::keyed::row_place_reads(row_wx);
    if &len(&reads) == &Nat::from(0u32) {
        parent.clone()
    } else {
        {
            let mut this: crate::lower::node_::Wx = parent.clone();
            this.row_marks = push(&this.row_marks, &crate::lower::node_::RowMarks { builder: gen_name.clone(), reads: reads.clone(), wrote: Array::new(), kind: crate::lower::model::RowKind::GenerationRow });
            this
        }
    }
}

/// ```prism
/// BuildSpelling: fn Env -> Env
/// ```
pub fn build_spelling(env: &crate::lower::types::Env) -> crate::lower::types::Env {
    fold(&keys(&env.names), env, &(|en: &crate::lower::types::Env, k: &Text| match get(&env.names, k) {
        Some(crate::lower::types::Bn::BnLocal(rs, mode, t)) => match crate::lower::types::through_parent(&rs) {
            Some(x) => crate::lower::types::bind(en, k, &crate::lower::types::Bn::BnLocal(x, mode, t)),
            None => en.clone(),
        },
        Some(crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(rs, m, xs), ds, t)) => match crate::lower::types::through_parent(&*rs) {
            Some(x) => crate::lower::types::bind(en, k, &crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(Rc::new(x), m, xs), ds, t)),
            None => en.clone(),
        },
        _ => en.clone(),
    }))
}

/// ```prism
/// GenSelect: unbounded fn Wx, Env, Block, [GenCase], Pos -> Ex
/// ```
pub fn gen_select(wx: &crate::lower::node_::Wx, menv: &crate::lower::types::Env, body: &crate::syntax::Block, cases: &Array<GenCase>, pos: &crate::lower::model::Pos_) -> crate::lower::model::Ex {
    let tail = append(&append(&Array::from(vec![crate::lower::model::Ex::XWeak(Rc::new(crate::lower::model::Ex::XSelf))]), &crate::lower::node_::keyed::hosted_passed(wx)), &Array::from(vec![crate::lower::model::Ex::XCx]));
    match clause_call(&wx.lx, body) {
        None => match index(cases, &Nat::from(0u32)) {
            Some(c) => crate::lower::expr::try_of(&crate::lower::model::Ex::XCall(Text::from(format!("{}::build", &c.node_.name)), append(&Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("path")), crate::lower::model::Ex::XVar(Text::lit("value"))]), &tail))),
            None => crate::lower::expr::refusal(&Text::lit("a `rebuild` with no generation")),
        },
        Some((qk, args)) => {
            let env = crate::lower::types::bind(menv, &Text::lit("_"), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(Text::lit("value")), crate::lower::types::Holding::Owned, crate::lower::model::OutTy::OutUnit));
            let scrut = crate::lower::model::Ex::XTuple(run_to_end(each_job(args.clone(), {
                let wx = wx.clone();
                let env = env.clone();
                Rc::new(move |p0: crate::syntax::Arg| {
                    let wx = wx.clone();
                    let env = env.clone();
                    entered(once_job(move || {
                        let a = p0;
                        prism_rtl::Turn::More(Rc::new(crate::lower::expr::Argument { lx: wx.lx.clone(), env: env.clone(), e: a.value.clone() }))
                    }))
                }) as Rc<dyn Fn(crate::syntax::Arg) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
            })));
            let arms = each(cases, &(|c: &GenCase| {
                let made = crate::lower::expr::try_of(&crate::lower::model::Ex::XCall(Text::from(format!("{}::build", &c.node_.name)), append(&append(&Array::from(vec![crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(Text::lit("path"))))]), &c.passed), &tail)));
                crate::lower::model::XArm { pat: c.pat.clone(), conds: c.conds.clone(), body: crate::lower::model::Ex::XCast(Rc::new(made.clone()), crate::lower::model::OutTy::OutObj(Rc::new(crate::lower::model::OutTy::OutNamed(Text::lit("Row"), Array::new())))) }
            }));
            crate::lower::types::own(&crate::lower::expr::arms_value(&scrut, &arms, &Text::lit("\'select"), &crate::lower::model::OutTy::OutObj(Rc::new(crate::lower::model::OutTy::OutNamed(Text::lit("Row"), Array::new())))))
        },
    }
}

/// ```prism
/// GenUp: fn Text, Text, OutTy -> MethDef
/// ```
pub fn gen_up(name: &Text, up_name: &Text, t: &crate::lower::model::OutTy) -> crate::lower::model::MethDef {
    crate::lower::model::MethDef { name: Text::from(format!("{}_up", name)), recv: crate::lower::model::Recv::RecvRc, params: Array::from(vec![(Text::lit("v"), t.clone())]), cx_: crate::lower::model::CxArg::CxMut, ret: crate::lower::model::OutTy::OutUnit, body: Array::from(vec![crate::lower::node_::finish::self_call(up_name, &Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("v"))]))]), tail: crate::lower::model::Ex::XUnit, doc: Text::lit("The current generation\'s result fires the `rebuild`\'s.") }
}

/// ```prism
/// GenForwards: fn GenDef -> [((Pa, Ex))]
/// ```
pub fn gen_forwards(gd: &crate::lower::model::GenDef) -> Array<(crate::lower::model::Pa, crate::lower::model::Ex)> {
    if gd.transparent {
        each(&crate::check::errors::range0(&gd.width), &(|i: &Nat| {
            let current = crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", &gd.name)))), Text::lit("borrow"), Array::new())));
            let body = crate::lower::model::Ex::XBlock(Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(Text::lit("row")), current.clone()), crate::lower::model::Do::DoIfLet(crate::lower::model::Pa::PaCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("row"))])), crate::lower::model::Ex::XVar(Text::lit("row")), Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::expr::try_of(&crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("row"))), Text::lit("answer"), Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("at")), crate::lower::model::Ex::XVar(Text::lit("v")), crate::lower::model::Ex::XCx]))))]), Array::new())]), Rc::new(crate::lower::model::Ex::XUnit));
            (crate::lower::node_::finish::pos_pat(&crate::lower::model::Pos_ { scope: gd.pos.scope.clone(), at: &gd.pos.at + i }, &Array::from(vec![crate::lower::model::Pa::PaRest(Text::lit(""))])), body.clone())
        }))
    } else {
        Array::from(vec![(crate::lower::node_::finish::pos_pat(&gd.pos, &crate::lower::node_::finish::gen_tail()), forward_gen(gd))])
    }
}

/// ```prism
/// ForwardGen: fn GenDef -> Ex
/// ```
pub fn forward_gen(gd: &crate::lower::model::GenDef) -> crate::lower::model::Ex {
    let current = crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", &gd.name)))), Text::lit("borrow"), Array::new())));
    let is_current = crate::lower::model::Ex::XBin(Text::lit("=="), Rc::new(crate::lower::model::Ex::XBin(Text::lit("+"), Rc::new(crate::lower::model::Ex::XDeref(Rc::new(crate::lower::model::Ex::XVar(Text::lit("g"))))), Rc::new(crate::lower::model::Ex::XIndex(Nat::from(1u32))))), Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_count", &gd.name)))), Text::lit("get"), Array::new())));
    crate::lower::model::Ex::XBlock(Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(Text::lit("row")), current.clone()), crate::lower::model::Do::DoIfLet(crate::lower::model::Pa::PaCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("row"))])), crate::lower::model::Ex::XVar(Text::lit("row")), Array::from(vec![crate::lower::model::Do::DoIf(is_current.clone(), Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::expr::try_of(&crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("row"))), Text::lit("answer"), Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("rest")), crate::lower::model::Ex::XVar(Text::lit("v")), crate::lower::model::Ex::XCx]))))]), Array::new())]), Array::new())]), Rc::new(crate::lower::model::Ex::XUnit))
}

/// ```prism
/// FlattenLine: unbounded fn Wx, Env, [Arg], ?Bn -> ((Wx, Wres))
/// ```
pub fn flatten_line(wx: &crate::lower::node_::Wx, menv: &crate::lower::types::Env, args: &Array<crate::syntax::Arg>, bound_opt: &Option<crate::lower::types::Bn>) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    let named_opt = match index(args, &Nat::from(0u32)) {
        Some(a) => match &*a.value.kind {
            crate::syntax::ExprKind::EName(n) => 'm24384: {
                let scrutinee = &get(&menv.names, &crate::check::env::sname_key(n));
                if let Some(crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(m24384_0_0_0, m, _), _, crate::lower::model::OutTy::OutDyn(t))) = scrutinee && let crate::lower::model::Ex::XSelf = &**m24384_0_0_0 {
                    break 'm24384 Some((m.clone(), (**t).clone()));
                }
                None
            },
            _ => None,
        },
        None => None,
    };
    let outer_opt = match &named_opt {
        Some((m, t)) => fold(&wx.gens, &None, &(|acc_opt: &Option<(Text, Text, crate::lower::model::OutTy)>, gd: &crate::lower::model::GenDef| if &Text::from(format!("{}_result", &gd.name)) == m {
            Some((m.clone(), gd.name.clone(), t.clone()))
        } else {
            acc_opt.clone()
        })),
        None => None,
    };
    match &outer_opt {
        None => match &named_opt {
            Some((m24765_0_0, t)) if (m24765_0_0 == &Text::lit("entry")) => entry_flatten(wx, t, bound_opt),
            _ => {
                let wx2 = {
                    let mut this: crate::lower::node_::Wx = wx.clone();
                    this.build = push(&this.build, &crate::lower::expr::refusal_do(&Text::lit("`@Flatten` of a dynamic that is neither a `rebuild`\'s nor a `for` row\'s entry")));
                    this
                };
                (wx2.clone(), crate::lower::node_::Wres::WrUnit)
            },
            _ => unreachable!("no arm matched"),
        },
        Some((m, gen_, t)) => {
            let (name, wx1) = match bound_opt {
                Some(crate::lower::types::Bn::BnHold(f, _)) => (f.clone(), wx.clone()),
                _ => crate::lower::node_::fresh_name(wx, &Text::lit("flatten")),
            };
            let inner = Text::from(format!("{}_inner", &name));
            let first_ = crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XVar(Text::lit("node"))), Text::from(format!("{}", &inner)))), Text::lit("set"), Array::from(vec![crate::lower::model::Ex::XCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("node"))), m.clone(), Array::from(vec![crate::lower::model::Ex::XCx]))])), crate::lower::model::Ex::XCx])));
            let sample = crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", &inner)))), Text::lit("get"), Array::from(vec![crate::lower::model::Ex::XCx]))), Text::lit("expect"), Array::from(vec![crate::lower::model::Ex::XStr(Text::lit("`@Flatten` adopts its first inner at the build"))]))), Text::lit("sample"), Array::from(vec![crate::lower::model::Ex::XCx]));
            let wx2 = {
                let mut this: crate::lower::node_::Wx = wx1.clone();
                this.taken = append(&this.taken, &Array::from(vec![inner.clone(), Text::from(format!("{}_adopt", &name))]));
                this.fields = push(&this.fields, &(inner.clone(), crate::lower::model::OutTy::OutHold(Rc::new(crate::lower::model::OutTy::OutOpt(Rc::new(crate::lower::model::OutTy::OutDyn(Rc::new(t.clone())))))), Text::lit("`@Flatten`\'s current inner: the dynamic of the generation it adopted")));
                this.moves = push(&this.moves, &(inner.clone(), crate::lower::model::Ex::XCall(Text::lit("Hold::new"), Array::from(vec![crate::lower::model::Ex::XNone, crate::lower::model::Ex::XCx]))));
                this.build = push(&this.build, &first_);
                this.getters = push(&this.getters, &crate::lower::model::MethDef { name: name.clone(), recv: crate::lower::model::Recv::RecvRef, params: Array::new(), cx_: crate::lower::model::CxArg::CxRef, ret: t.clone(), body: Array::new(), tail: sample.clone(), doc: Text::lit("`@Flatten`\'s dynamic: its current inner at the read point.") });
                this.dyn_reads = insert(&this.dyn_reads, &name, &Array::from(vec![crate::lower::node_::Read::OwnRead(inner.clone())]));
                this.flattens = push(&this.flattens, &crate::lower::node_::FlatDef { name: name.clone(), outer: m.clone(), generation: gen_.clone(), ty: t.clone() });
                this
            };
            (wx2.clone(), crate::lower::node_::Wres::WrDyn(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XSelf), name.clone(), Array::from(vec![crate::lower::model::Ex::XCx])), Array::from(vec![crate::lower::node_::Read::OwnRead(inner.clone())]), t.clone()))
        },
    }
}

/// ```prism
/// EntryFlatten: unbounded fn Wx, OutTy, ?Bn -> ((Wx, Wres))
/// ```
pub fn entry_flatten(wx: &crate::lower::node_::Wx, t: &crate::lower::model::OutTy, bound_opt: &Option<crate::lower::types::Bn>) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    let (name, wx1) = match bound_opt {
        Some(crate::lower::types::Bn::BnHold(f, _)) => (f.clone(), wx.clone()),
        _ => crate::lower::node_::fresh_name(wx, &Text::lit("flatten")),
    };
    let inner = Text::from(format!("{}_inner", &name));
    let follow = Text::from(format!("{}_follow", &name));
    let followed = crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XVar(Text::lit("node"))), follow.clone())), Text::lit("follow"), Array::from(vec![crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("node"))), Text::lit("entry"), Array::from(vec![crate::lower::model::Ex::XCx]))), Text::lit("updates")))), crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XVar(Text::lit("node")))), crate::lower::model::Ex::XPath(Text::from(format!("{}::{}_moved", &wx.node_, &name)))])));
    let sample = crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", &inner)))), Text::lit("get"), Array::from(vec![crate::lower::model::Ex::XCx]))), Text::lit("expect"), Array::from(vec![crate::lower::model::Ex::XStr(Text::lit("`@Flatten` adopts its first inner at the build"))]))), Text::lit("sample"), Array::from(vec![crate::lower::model::Ex::XCx]));
    let wx2 = {
        let mut this: crate::lower::node_::Wx = wx1.clone();
        this.taken = append(&this.taken, &Array::from(vec![inner.clone(), follow.clone(), Text::from(format!("{}_adopt", &name)), Text::from(format!("{}_moved", &name))]));
        this.fields = append(&this.fields, &Array::from(vec![(inner.clone(), crate::lower::model::OutTy::OutHold(Rc::new(crate::lower::model::OutTy::OutOpt(Rc::new(crate::lower::model::OutTy::OutDyn(Rc::new(t.clone())))))), Text::lit("`@Flatten`\'s current inner: the row\'s entry it adopted")), (follow.clone(), crate::lower::model::OutTy::OutNamed(Text::lit("prism_rtl::Follow"), Array::new()), Text::lit("the subscription to the inner\'s update event"))]));
        this.moves = append(&this.moves, &Array::from(vec![(inner.clone(), crate::lower::model::Ex::XCall(Text::lit("Hold::new"), Array::from(vec![crate::lower::model::Ex::XCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(Text::lit("value"))))])), crate::lower::model::Ex::XCx]))), (follow.clone(), crate::lower::model::Ex::XCall(Text::lit("prism_rtl::Follow::new"), Array::new()))]));
        this.build = push(&this.build, &followed);
        this.getters = push(&this.getters, &crate::lower::model::MethDef { name: name.clone(), recv: crate::lower::model::Recv::RecvRef, params: Array::new(), cx_: crate::lower::model::CxArg::CxRef, ret: t.clone(), body: Array::new(), tail: sample.clone(), doc: Text::lit("`@Flatten`\'s dynamic: its current inner at the read point.") });
        this.dyn_reads = insert(&this.dyn_reads, &name, &Array::from(vec![crate::lower::node_::Read::OwnRead(inner.clone())]));
        this.flattens = push(&this.flattens, &crate::lower::node_::FlatDef { name: name.clone(), outer: Text::lit("entry"), generation: Text::lit(""), ty: t.clone() });
        this
    };
    (wx2.clone(), crate::lower::node_::Wres::WrDyn(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XSelf), name.clone(), Array::from(vec![crate::lower::model::Ex::XCx])), Array::from(vec![crate::lower::node_::Read::OwnRead(inner.clone())]), t.clone()))
}

/// ```prism
/// SwitchLine: unbounded fn Wx, Env, [Arg] -> ((Wx, Wres))
/// ```
pub fn switch_line(wx: &crate::lower::node_::Wx, menv: &crate::lower::types::Env, args: &Array<crate::syntax::Arg>) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    match index(args, &Nat::from(0u32)) {
        Some(a) => {
            let (r, wx2) = crate::lower::node_::dynamics::event_ref(wx, menv, &a.value);
            (wx2.clone(), crate::lower::node_::Wres::WrEv(r.clone()))
        },
        None => (wx.clone(), crate::lower::node_::Wres::WrUnit),
    }
}
