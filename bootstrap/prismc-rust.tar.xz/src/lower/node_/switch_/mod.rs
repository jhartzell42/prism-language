//! The module `Lower.Node.Switch`, from `target/bootstrap/src/prismc/lower/node/switch.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// `ClauseRow`:
///
/// ```prism
/// type ClauseRow = record:
/// ```
#[derive(Clone)]
pub struct ClauseRow {
    pub case_p: GenCase,
    pub parent_p: crate::lower::node_::Wx,
    pub width_p: Nat,
}

/// `GenCase`:
///
/// ```prism
/// type GenCase = record:
/// ```
#[derive(Clone)]
pub struct GenCase {
    pub node_p: crate::lower::model::NodeDef,
    pub params_p: Array<(Text, crate::lower::model::OutTy)>,
    pub pat_p: crate::lower::model::Pa,
    pub conds_p: Array<crate::lower::model::Cc>,
    pub passed_p: Array<crate::lower::model::Ex>,
}

impl ToPod for GenCase {
    fn to_pod(&self) -> Pod {
        Pod::record("GenCase", vec![("node", self.node_p.to_pod()), ("params", self.params_p.to_pod()), ("pat", self.pat_p.to_pod()), ("conds", self.conds_p.to_pod()), ("passed", self.passed_p.to_pod())])
    }
}

impl FromPod for GenCase {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(GenCase { node_p: FromPod::from_pod(field(p, "node")?)?, params_p: FromPod::from_pod(field(p, "params")?)?, pat_p: FromPod::from_pod(field(p, "pat")?)?, conds_p: FromPod::from_pod(field(p, "conds")?)?, passed_p: FromPod::from_pod(field(p, "passed")?)? })
    }
}

/// `GenRow`:
///
/// ```prism
/// type GenRow = record:
/// ```
#[derive(Clone)]
pub struct GenRow {
    pub node_p: crate::lower::model::NodeDef,
    pub parent_p: crate::lower::node_::Wx,
    pub dyn_result_o: Option<crate::lower::model::OutTy>,
}

/// ```prism
/// RowEnv: unbounded fn Wx, Wx, Env, Block -> ((Wx, Wx, Env))
/// ```
pub fn row_env_f(parent_p0: &crate::lower::node_::Wx, row_wx_p1: &crate::lower::node_::Wx, menv_p2: &crate::lower::types::Env, body_p3: &crate::syntax::Block) -> (crate::lower::node_::Wx, crate::lower::node_::Wx, crate::lower::types::Env) {
    let names_p4 = crate::lower::expr::read_names_f(&crate::check::typed::print::block_exprs_f(body_p3));
    crate::prelude::fold(&names_p4, &(parent_p0.clone(), row_wx_p1.clone(), crate::lower::types::empty_env_p()), &(|(p_p5, r_p6, env_p7): &(crate::lower::node_::Wx, crate::lower::node_::Wx, crate::lower::types::Env), n_p8: &Text| match crate::prelude::get(&menv_p2.names_p, n_p8) {
        Some(crate::lower::types::Bn::BnLocal(rs_p9, mode_pa, t_pb)) => (p_p5.clone(), r_p6.clone(), crate::lower::types::bind_f(env_p7, n_p8, &crate::lower::types::Bn::BnLocal(over_parent_f(&rs_p9), crate::lower::types::Holding::Owned, t_pb))),
        Some(crate::lower::types::Bn::BnEv(er_pc, t_pd)) => {
            let pname_pe = crate::lower::node_::gn_of_f(p_p5, &er_pc.node_p).name_p.clone();
            let (rs_ph, r1_pi) = crate::lower::node_::fresh_name_f(r_p6, &crate::lower::snake_f(n_p8));
            let (id_pj, r2_pk) = crate::lower::node_::add_gn_f(&r1_pi, &rs_ph, &t_pd, &crate::lower::node_::GnKind::GnPort, &Nat::from(0u32));
            let r3_pf = {
                let mut this: crate::lower::node_::Wx = r2_pk.clone();
                this.subs_p = crate::prelude::push(&this.subs_p, &(pname_pe.clone(), rs_ph.clone(), t_pd.clone()));
                this
            };
            let p2_pg = if crate::check::types::has_text_f(&p_p5.ports_p, &pname_pe) {
                p_p5.clone()
            } else {
                crate::lower::node_::connect_f(&with_port_f(p_p5, &pname_pe), &crate::lower::node_::ev_ref_of_f(p_p5, &er_pc.node_p), &crate::lower::node_::Sk::SkPort(pname_pe.clone()))
            };
            (p2_pg.clone(), r3_pf.clone(), crate::lower::types::bind_f(env_p7, n_p8, &crate::lower::types::Bn::BnEv(crate::lower::node_::ev_ref_of_f(&r3_pf, &id_pj), t_pd.clone())))
        },
        Some(crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(recv_pl, m_pm, xs_pn), _, t_po)) => if &*recv_pl == &crate::lower::model::Ex::XSelf {
            (p_p5.clone(), r_p6.clone(), crate::lower::types::bind_f(env_p7, n_p8, &crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(Rc::new(parent_ref_p()), m_pm.clone(), xs_pn), Array::from(vec![crate::lower::node_::Read::ParentRead(m_pm.clone())]), t_po)))
        } else {
            row_param_env_f(p_p5, r_p6, env_p7, menv_p2, n_p8)
        },
        Some(crate::lower::types::Bn::BnDyn(_, _, _)) => row_param_env_f(p_p5, r_p6, env_p7, menv_p2, n_p8),
        Some(crate::lower::types::Bn::BnHold(f_pp, t_pq)) => (p_p5.clone(), r_p6.clone(), crate::lower::types::bind_f(env_p7, n_p8, &crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(parent_ref_p()), f_pp.clone())), Text::lit("get"), Array::from(vec![crate::lower::model::Ex::XCx])), Array::from(vec![crate::lower::node_::Read::ParentRead(f_pp.clone())]), t_pq))),
        _ => (p_p5.clone(), r_p6.clone(), env_p7.clone()),
    }))
}

/// ```prism
/// RowParamEnv: fn Wx, Wx, Env, Env, Text -> ((Wx, Wx, Env))
/// ```
pub fn row_param_env_f(p_p0: &crate::lower::node_::Wx, r_p1: &crate::lower::node_::Wx, env_p2: &crate::lower::types::Env, menv_p3: &crate::lower::types::Env, n_p4: &Text) -> (crate::lower::node_::Wx, crate::lower::node_::Wx, crate::lower::types::Env) {
    match crate::prelude::get(&menv_p3.names_p, &Text::from(format!("{}#row", n_p4))) {
        Some(crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(_, m_p5, xs_p6), _, t_p7)) => (p_p0.clone(), r_p1.clone(), crate::lower::types::bind_f(env_p2, n_p4, &crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(Rc::new(parent_ref_p()), m_p5.clone(), xs_p6), Array::from(vec![crate::lower::node_::Read::ParentRead(m_p5.clone())]), t_p7))),
        _ => (p_p0.clone(), r_p1.clone(), env_p2.clone()),
    }
}

/// ```prism
/// OverParent: fn Ex -> Ex
/// ```
pub fn over_parent_f(x_p0: &crate::lower::model::Ex) -> crate::lower::model::Ex {
    match x_p0 {
        crate::lower::model::Ex::XSelf => parent_ref_p(),
        crate::lower::model::Ex::XField(y_p1, f_p2) => crate::lower::model::Ex::XField(Rc::new(over_parent_f(&**y_p1)), f_p2.clone()),
        crate::lower::model::Ex::XPart(y_p3, k_p4) => crate::lower::model::Ex::XPart(Rc::new(over_parent_f(&**y_p3)), k_p4.clone()),
        crate::lower::model::Ex::XMethod(y_p5, m_p6, xs_p7) => crate::lower::model::Ex::XMethod(Rc::new(over_parent_f(&**y_p5)), m_p6.clone(), xs_p7.clone()),
        crate::lower::model::Ex::XUpgrade(y_p8) => crate::lower::model::Ex::XUpgrade(Rc::new(over_parent_f(&**y_p8))),
        _ => crate::lower::model::Ex::XField(Rc::new(parent_ref_p()), crate::lower::types::place_stem_f(x_p0)),
    }
}

/// ```prism
/// let parentRef
/// ```
pub fn parent_ref_p() -> crate::lower::model::Ex {
    crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XUpgrade(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::lit("parent"))))), Text::lit("expect"), Array::from(vec![crate::lower::model::Ex::XStr(Text::lit("the block outlives its rows"))]))
}

/// ```prism
/// let parentArg
/// ```
pub fn parent_arg_p() -> crate::lower::model::Ex {
    crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XUpgrade(Rc::new(crate::lower::model::Ex::XVar(Text::lit("parent"))))), Text::lit("expect"), Array::from(vec![crate::lower::model::Ex::XStr(Text::lit("the block outlives its rows"))]))
}

/// ```prism
/// WithPort: fn Wx, Text -> Wx
/// ```
pub fn with_port_f(wx_p0: &crate::lower::node_::Wx, pname_p1: &Text) -> crate::lower::node_::Wx {
    let mut this: crate::lower::node_::Wx = wx_p0.clone();
    this.ports_p = crate::prelude::push(&this.ports_p, pname_p1);
    this
}

/// ```prism
/// RebuildLine: unbounded fn Wx, Env, Env, Expr, Block, Expr, ?Bn -> ((Wx, Wres))
/// ```
pub fn rebuild_line_f(wx_p0: &crate::lower::node_::Wx, benv_p1: &crate::lower::types::Env, menv_p2: &crate::lower::types::Env, scrut_p3: &crate::syntax::Expr, body_p4: &crate::syntax::Block, e_p5: &crate::syntax::Expr, bound_o6: &Option<crate::lower::types::Bn>) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    let lx_p7 = wx_p0.lx_p.clone();
    let pos_p8 = wx_p0.pos_p.clone();
    let wx1_p9 = {
        let mut this: crate::lower::node_::Wx = wx_p0.clone();
        this.pos_p = crate::lower::model::next_pos_f(&this.pos_p);
        this
    };
    let (src_ex_pb, reads_pc) = crate::lower::node_::dynamics::dynamic_expr_f(&wx1_p9, menv_p2, scrut_p3);
    let vt_pa = crate::lower::types::out_ty_of_f(&lx_p7, &crate::lower::types::peel_f(&crate::lower::type_at_f(&lx_p7, &scrut_p3.span_p)));
    let (name_pd, wx2_pe) = crate::lower::node_::fresh_name_f(&wx1_p9, &Text::lit("generation"));
    if gives_dynamic_f(&crate::lower::type_at_f(&lx_p7, &e_p5.span_p)) {
        rebuild_dynamic_f(&wx2_pe, menv_p2, body_p4, &src_ex_pb, &reads_pc, &vt_pa, &name_pd, &pos_p8)
    } else {
        {
            let (up_id_pj, wx3_pk) = match bound_o6 {
                Some(crate::lower::types::Bn::BnEv(er_pi, _)) => (er_pi.node_p.clone(), wx2_pe.clone()),
                _ => crate::lower::node_::add_gn_f(&wx2_pe, &Text::from(format!("{}_fired", &name_pd)), &crate::lower::types::out_ty_of_f(&lx_p7, &crate::lower::types::peel_f(&crate::lower::type_at_f(&lx_p7, &e_p5.span_p))), &crate::lower::node_::GnKind::GnNamed, &Nat::from(0u32)),
            };
            let (cases_pl, wx4_pm) = gen_cases_f(&wx3_pk, menv_p2, body_p4, &vt_pa, &name_pd);
            let row_defs_pf = crate::prelude::each(&cases_pl, &(|c_pn: &GenCase| c_pn.node_p.clone()));
            let select_pg = gen_select_f(&wx4_pm, menv_p2, body_p4, &cases_pl, &pos_p8);
            let wx5_ph = {
                let mut this: crate::lower::node_::Wx = wx4_pm.clone();
                this.gens_p = crate::prelude::push(&this.gens_p, &crate::lower::model::GenDef { name_p: name_pd.clone(), pos_p: pos_p8.clone(), at_p: crate::lower::node_::finish::place_at_f(wx_p0, &Text::lit("self"), &pos_p8), source_p: src_ex_pb.clone(), value_ty_p: vt_pa.clone(), select_p: select_pg.clone(), transparent_p: false, width_p: Nat::from(0u32), moved_p: crate::prelude::or(&crate::lower::node_::finish::hosted_rows_o(wx_p0), &Text::lit("")) });
                this.gen_holds_p = crate::prelude::push(&this.gen_holds_p, &(name_pd.clone(), reads_pc.clone()));
                this.rows_p = crate::prelude::fold(&row_defs_pf, &this.rows_p, &(|acc_po: &Array<crate::lower::model::NodeDef>, rd_pp: &crate::lower::model::NodeDef| crate::prelude::append(&crate::prelude::push(acc_po, rd_pp), &rd_pp.children_p)));
                this.getters_p = crate::prelude::push(&this.getters_p, &gen_up_f(&name_pd, &crate::lower::node_::gn_of_f(&wx4_pm, &up_id_pj).name_p, &crate::lower::node_::gn_of_f(&wx4_pm, &up_id_pj).ty_p));
                this
            };
            (wx5_ph.clone(), crate::lower::node_::Wres::WrEv(crate::lower::node_::ev_ref_of_f(&wx5_ph, &up_id_pj)))
        }
    }
}

/// The step machine of `RebuildLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RebuildLine: unbounded fn Wx, Env, Env, Expr, Block, Expr, ?Bn -> ((Wx, Wres))
/// ```
pub struct RebuildLine {
    pub wx_p0: crate::lower::node_::Wx,
    pub benv_p1: crate::lower::types::Env,
    pub menv_p2: crate::lower::types::Env,
    pub scrut_p3: crate::syntax::Expr,
    pub body_p4: crate::syntax::Block,
    pub e_p5: crate::syntax::Expr,
    pub bound_o6: Option<crate::lower::types::Bn>,
}

impl prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::node_::Wres)> for RebuildLine {
    fn cycle(&self) -> prism_rtl::Turn<(crate::lower::node_::Wx, crate::lower::node_::Wres)> {
        let wx_p0 = &self.wx_p0;
        let benv_p1 = &self.benv_p1;
        let menv_p2 = &self.menv_p2;
        let scrut_p3 = &self.scrut_p3;
        let body_p4 = &self.body_p4;
        let e_p5 = &self.e_p5;
        let bound_o6 = &self.bound_o6;
        let lx_p7 = wx_p0.lx_p.clone();
        let pos_p8 = wx_p0.pos_p.clone();
        let wx1_p9 = {
            let mut this: crate::lower::node_::Wx = wx_p0.clone();
            this.pos_p = crate::lower::model::next_pos_f(&this.pos_p);
            this
        };
        let bound_o6x = bound_o6.clone();
        let body_p4x = body_p4.clone();
        let e_p5x = e_p5.clone();
        let menv_p2x = menv_p2.clone();
        let scrut_p3x = scrut_p3.clone();
        let wx_p0x = wx_p0.clone();
        crate::prelude::call_then(crate::lower::node_::dynamics::start_dynamic_expr_f(wx1_p9.clone(), menv_p2x.clone(), scrut_p3x.clone()), move |dynamic_expr_f_4431: (crate::lower::model::Ex, Array<crate::lower::node_::Read>)| {
            let (src_ex_pb, reads_pc) = dynamic_expr_f_4431;
            crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p7.clone(), crate::lower::types::peel_f(&crate::lower::type_at_f(&lx_p7, &scrut_p3x.span_p))), move |out_ty_of_f_4473: crate::lower::model::OutTy| {
                let vt_pa = out_ty_of_f_4473;
                let (name_pd, wx2_pe) = crate::lower::node_::fresh_name_f(&wx1_p9, &Text::lit("generation"));
                if gives_dynamic_f(&crate::lower::type_at_f(&lx_p7, &e_p5x.span_p)) {
                    prism_rtl::Turn::Finished(rebuild_dynamic_f(&wx2_pe, &menv_p2x, &body_p4x, &src_ex_pb, &reads_pc, &vt_pa, &name_pd, &pos_p8))
                } else {
                    {
                        let (up_id_pj, wx3_pk) = match &bound_o6x {
                            Some(crate::lower::types::Bn::BnEv(er_pi, _)) => (er_pi.node_p.clone(), wx2_pe.clone()),
                            _ => crate::lower::node_::add_gn_f(&wx2_pe, &Text::from(format!("{}_fired", &name_pd)), &crate::lower::types::out_ty_of_f(&lx_p7, &crate::lower::types::peel_f(&crate::lower::type_at_f(&lx_p7, &e_p5x.span_p))), &crate::lower::node_::GnKind::GnNamed, &Nat::from(0u32)),
                        };
                        let (cases_pl, wx4_pm) = gen_cases_f(&wx3_pk, &menv_p2x, &body_p4x, &vt_pa, &name_pd);
                        let row_defs_pf = crate::prelude::each(&cases_pl, &(|c_pn: &GenCase| c_pn.node_p.clone()));
                        let select_pg = gen_select_f(&wx4_pm, &menv_p2x, &body_p4x, &cases_pl, &pos_p8);
                        let wx5_ph = {
                            let mut this: crate::lower::node_::Wx = wx4_pm.clone();
                            this.gens_p = crate::prelude::push(&this.gens_p, &crate::lower::model::GenDef { name_p: name_pd.clone(), pos_p: pos_p8.clone(), at_p: crate::lower::node_::finish::place_at_f(&wx_p0x, &Text::lit("self"), &pos_p8), source_p: src_ex_pb.clone(), value_ty_p: vt_pa.clone(), select_p: select_pg.clone(), transparent_p: false, width_p: Nat::from(0u32), moved_p: crate::prelude::or(&crate::lower::node_::finish::hosted_rows_o(&wx_p0x), &Text::lit("")) });
                            this.gen_holds_p = crate::prelude::push(&this.gen_holds_p, &(name_pd.clone(), reads_pc.clone()));
                            this.rows_p = crate::prelude::fold(&row_defs_pf, &this.rows_p, &(|acc_po: &Array<crate::lower::model::NodeDef>, rd_pp: &crate::lower::model::NodeDef| crate::prelude::append(&crate::prelude::push(acc_po, rd_pp), &rd_pp.children_p)));
                            this.getters_p = crate::prelude::push(&this.getters_p, &gen_up_f(&name_pd, &crate::lower::node_::gn_of_f(&wx4_pm, &up_id_pj).name_p, &crate::lower::node_::gn_of_f(&wx4_pm, &up_id_pj).ty_p));
                            this
                        };
                        prism_rtl::Turn::Finished((wx5_ph.clone(), crate::lower::node_::Wres::WrEv(crate::lower::node_::ev_ref_of_f(&wx5_ph, &up_id_pj))))
                    }
                }
            })
        })
    }
}

/// `Start RebuildLine, x`: what the function value is when passed to `@Run`.
pub fn start_rebuild_line_f(wx_p0: crate::lower::node_::Wx, benv_p1: crate::lower::types::Env, menv_p2: crate::lower::types::Env, scrut_p3: crate::syntax::Expr, body_p4: crate::syntax::Block, e_p5: crate::syntax::Expr, bound_o6: Option<crate::lower::types::Bn>) -> Rc<dyn prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::node_::Wres)>> {
    Rc::new(RebuildLine { wx_p0, benv_p1, menv_p2, scrut_p3, body_p4, e_p5, bound_o6 })
}

/// ```prism
/// GivesDynamic: fn Ty -> Bool
/// ```
pub fn gives_dynamic_f(t_p0: &crate::check::types::Ty) -> bool {
    'm5725: {
        if let crate::check::types::Ty::TySig(m5725_0_0, m5725_0_1) = t_p0 && (m5725_0_0 == &Text::lit("$")) && let crate::check::types::Ty::TySig(m5725_0_1_r_0, _) = &**m5725_0_1 && (m5725_0_1_r_0 == &Text::lit("$")) {
            break 'm5725 true;
        }
        if let crate::check::types::Ty::TyAt(i_p1, _) = t_p0 {
            break 'm5725 gives_dynamic_f(&**i_p1);
        }
        false
    }
}

/// ```prism
/// RebuildDynamic: unbounded fn Wx, Env, Block, Ex, [Read], OutTy, Text, Pos -> ((Wx, Wres))
/// ```
pub fn rebuild_dynamic_f(wx_p0: &crate::lower::node_::Wx, menv_p1: &crate::lower::types::Env, body_p2: &crate::syntax::Block, src_ex_p3: &crate::lower::model::Ex, reads_p4: &Array<crate::lower::node_::Read>, vt_p5: &crate::lower::model::OutTy, name_p6: &Text, pos_p7: &crate::lower::model::Pos_) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    let row_name_p8 = Text::from(format!("{}Gen{}", &wx_p0.node_p, &crate::lower::node_::keyed::row_suffix_f(wx_p0)));
    let whole_p9 = gen_row_of_f(wx_p0, menv_p1, body_p2, vt_p5, &row_name_p8, name_p6);
    match &whole_p9.dyn_result_o {
        None => {
            let wx2_pa = {
                let mut this: crate::lower::node_::Wx = whole_p9.parent_p.clone();
                this.build_p = crate::prelude::push(&this.build_p, &crate::lower::expr::refusal_do_f(&Text::lit("a `rebuild` whose generation gives a dynamic it does not lower")));
                this
            };
            (wx2_pa.clone(), crate::lower::node_::Wres::WrUnit)
        },
        Some(rt_pb) => {
            let dyn_ty_pc = crate::lower::model::OutTy::OutDyn(Rc::new(rt_pb.clone()));
            let result_pd = Text::from(format!("{}_result", name_p6));
            let live_pe = Text::from(format!("{}_live", &result_pd));
            let what_pf = Text::from(format!("the dynamic of the `rebuild` at place {}", &crate::lower::model::place_text_f(pos_p7)));
            let tail_pg = crate::prelude::append(&crate::prelude::append(&Array::from(vec![crate::lower::model::Ex::XWeak(Rc::new(crate::lower::model::Ex::XSelf))]), &crate::lower::node_::keyed::hosted_passed_f(wx_p0)), &Array::from(vec![crate::lower::model::Ex::XCx]));
            let built_ph = crate::lower::expr::try_of_f(&crate::lower::model::Ex::XCall(Text::from(format!("{}::build", &whole_p9.node_p.name_p)), crate::prelude::append(&Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("path")), crate::lower::model::Ex::XVar(Text::lit("value"))]), &tail_pg)));
            let kept_pi = crate::lower::model::Do::DoAssign(crate::lower::model::Ex::XDeref(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), live_pe.clone())), Text::lit("borrow_mut"), Array::new()))), crate::lower::model::Ex::XCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("row"))), Text::lit("result_dynamic"), Array::new())])));
            let marked_pj = crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_snap", &result_pd)))), Text::lit("mark"), Array::from(vec![crate::lower::model::Ex::XCx])));
            let select_pk = crate::lower::model::Ex::XBlock(Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(Text::lit("row")), built_ph.clone()), kept_pi.clone(), marked_pj.clone()]), Rc::new(crate::lower::model::Ex::XVar(Text::lit("row"))));
            let current_pl = crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", &live_pe)))), Text::lit("borrow"), Array::new())))), Text::lit("expect"), Array::from(vec![crate::lower::model::Ex::XStr(Text::lit("a `rebuild` has a generation from its build on"))]));
            let wx2_pm = {
                let mut this: crate::lower::node_::Wx = whole_p9.parent_p.clone();
                this.gens_p = crate::prelude::push(&this.gens_p, &crate::lower::model::GenDef { name_p: name_p6.clone(), pos_p: pos_p7.clone(), at_p: crate::lower::node_::finish::place_at_f(wx_p0, &Text::lit("self"), pos_p7), source_p: src_ex_p3.clone(), value_ty_p: vt_p5.clone(), select_p: select_pk.clone(), transparent_p: false, width_p: Nat::from(0u32), moved_p: crate::prelude::or(&crate::lower::node_::finish::hosted_rows_o(wx_p0), &Text::lit("")) });
                this.gen_holds_p = crate::prelude::push(&this.gen_holds_p, &(name_p6.clone(), reads_p4.clone()));
                this.rows_p = crate::prelude::append(&crate::prelude::push(&this.rows_p, &whole_p9.node_p), &whole_p9.node_p.children_p);
                this.taken_p = crate::prelude::append(&this.taken_p, &Array::from(vec![result_pd.clone(), live_pe.clone(), Text::from(format!("{}_now", &result_pd)), Text::from(format!("{}_snap", &result_pd)), Text::from(format!("{}_publish", &result_pd)), Text::from(format!("{}_moved", &result_pd))]));
                this.fields_p = crate::prelude::append(&this.fields_p, &Array::from(vec![(live_pe.clone(), crate::lower::model::OutTy::OutCell(Rc::new(crate::lower::model::OutTy::OutOpt(Rc::new(dyn_ty_pc.clone())))), Text::lit("the current generation\'s result, which the snapshot of the `rebuild`\'s dynamic is taken from")), (Text::from(format!("{}_snap", &result_pd)), crate::lower::model::OutTy::OutSnapshot(Rc::new(dyn_ty_pc.clone())), Text::from(format!("the `rebuild` at place {}\'s dynamic, structural: its snapshots, the generations\' results and the lagged dynamic (pick ST)", &crate::lower::model::place_text_f(pos_p7))))]));
                this.moves_p = crate::prelude::push(&this.moves_p, &(live_pe.clone(), crate::lower::model::Ex::XCall(Text::lit("RefCell::new"), Array::from(vec![crate::lower::model::Ex::XNone]))));
                this.inits_p = crate::prelude::push(&this.inits_p, &(Text::from(format!("{}_snap", &result_pd)), crate::lower::model::Ex::XCall(Text::lit("Snapshot::new"), Array::from(vec![crate::lower::model::Ex::XStr(what_pf.clone())]))));
                this.getters_p = crate::prelude::append(&this.getters_p, &Array::from(vec![crate::lower::model::MethDef { name_p: Text::from(format!("{}_now", &result_pd)), recv_p: crate::lower::model::Recv::RecvRef, params_p: Array::new(), cx_p: crate::lower::model::CxArg::CxRef, ret_p: dyn_ty_pc.clone(), body_p: Array::new(), tail_p: current_pl.clone(), doc_p: Text::lit("The current generation\'s result: what the snapshot of the `rebuild`\'s dynamic is taken from (pick ST).") }, crate::lower::node_::static_::snap_getter_f(&result_pd, &dyn_ty_pc, &Text::lit("The `rebuild`\'s dynamic, its generation\'s result, a structural dynamic (pick ST): one tick behind the generations, the snapshot of the tick before the tick the read point is after."))]));
                this.snaps_p = crate::prelude::push(&this.snaps_p, &crate::lower::node_::SnapDef { name_p: result_pd.clone(), live_p: Text::from(format!("{}_now", &result_pd)), ty_p: dyn_ty_pc.clone(), eq_p: false, builder_p: name_p6.clone(), before_p: false, what_p: what_pf.clone() });
                this
            };
            (wx2_pm.clone(), crate::lower::node_::Wres::WrDyn(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XSelf), result_pd.clone(), Array::from(vec![crate::lower::model::Ex::XCx])), Array::from(vec![crate::lower::node_::Read::OwnRead(result_pd.clone())]), dyn_ty_pc.clone()))
        },
    }
}

/// ```prism
/// ClauseWidgetLine: unbounded fn Wx, Env, Expr, Block, Text, ValInfo, Expr -> ((Wx, Wres))
/// ```
pub fn clause_widget_line_f(wx_p0: &crate::lower::node_::Wx, menv_p1: &crate::lower::types::Env, scrut_p2: &crate::syntax::Expr, call_p3: &crate::syntax::Block, qk_p4: &Text, v_p5: &crate::check::env::ValInfo, e_p6: &crate::syntax::Expr) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    let lx_p7 = wx_p0.lx_p.clone();
    let pos_p8 = wx_p0.pos_p.clone();
    let (src_ex_pe, reads_pf) = crate::lower::node_::dynamics::dynamic_expr_f(wx_p0, menv_p1, scrut_p2);
    let vt_p9 = crate::lower::types::out_ty_of_f(&lx_p7, &crate::lower::types::peel_f(&crate::lower::type_at_f(&lx_p7, &scrut_p2.span_p)));
    let (name_pg, wx1_ph) = crate::lower::node_::fresh_name_f(wx_p0, &Text::lit("generation"));
    let (up_id_pi, wx2_pj) = crate::lower::node_::add_gn_f(&wx1_ph, &Text::from(format!("{}_fired", &name_pg)), &crate::lower::types::out_ty_of_f(&lx_p7, &crate::lower::types::out_of_f(&crate::lower::type_at_f(&lx_p7, &e_p6.span_p))), &crate::lower::node_::GnKind::GnNamed, &Nat::from(0u32));
    let clauses_pa = crate::lower::jobs::clauses_of_f(&lx_p7.g_p, qk_p4);
    let row_name_pb = Text::from(format!("{}Gen{}", &wx_p0.node_p, &crate::lower::node_::keyed::row_suffix_f(wx_p0)));
    let (rows_pp, wx3_pq) = crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(&clauses_pa)), (Array::new(), wx2_pj.clone()), {
        let clauses_pax = clauses_pa.clone();
        let menv_p1x = menv_p1.clone();
        let v_p5x = v_p5.clone();
        let row_name_pbx = row_name_pb.clone();
        let name_pgx = name_pg.clone();
        Rc::new(move |(p0, p1): ((Array<ClauseRow>, crate::lower::node_::Wx), Nat)| {
            let clauses_paxy = clauses_pax.clone();
            let menv_p1xy = menv_p1x.clone();
            let v_p5xy = v_p5x.clone();
            let row_name_pbxy = row_name_pbx.clone();
            let name_pgxy = name_pgx.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (acc_pk, w_pl) = p0;
                let i_pm = p1;
                {
                    let c_pn = crate::prelude::or(&crate::prelude::index(&clauses_paxy, &i_pm), &crate::lower::functions::dummy_clause_p());
                    let cr_po = clause_row_of_f(&w_pl, &menv_p1xy, &c_pn, &v_p5xy, &Text::from(format!("{}{}", &row_name_pbxy, &i_pm)), &name_pgxy, &true);
                    prism_rtl::Turn::Finished((crate::prelude::push(&acc_pk, &cr_po), cr_po.parent_p.clone()))
                }
            }))
        }) as Rc<dyn Fn(((Array<ClauseRow>, crate::lower::node_::Wx), Nat)) -> Rc<dyn prism_rtl::Job<(Array<ClauseRow>, crate::lower::node_::Wx)>>>
    }));
    let width_pc = crate::prelude::fold(&rows_pp, &Nat::from(0u32), &(|acc_pr: &Nat, cr_ps: &ClauseRow| crate::prelude::max(acc_pr, &cr_ps.width_p)));
    let cases_pd = crate::prelude::each(&rows_pp, &(|cr_pt: &ClauseRow| cr_pt.case_p.clone()));
    if is_hosted_scope_f(wx_p0) {
        {
            let wx4_pu = {
                let mut this: crate::lower::node_::Wx = wx3_pq.clone();
                this.build_p = crate::prelude::push(&this.build_p, &crate::lower::expr::refusal_do_f(&Text::lit("a widget of several clauses in a static position of a hosted scope")));
                this
            };
            (wx4_pu.clone(), crate::lower::node_::Wres::WrUnit)
        }
    } else {
        {
            let select_pv = gen_select_f(&wx3_pq, menv_p1, call_p3, &cases_pd, &pos_p8);
            let wx4_p10 = {
                let mut this: crate::lower::node_::Wx = wx3_pq.clone();
                this.pos_p = crate::lower::model::Pos_ { scope_p: pos_p8.scope_p.clone(), at_p: &pos_p8.at_p + &width_pc };
                this.gens_p = crate::prelude::push(&this.gens_p, &crate::lower::model::GenDef { name_p: name_pg.clone(), pos_p: pos_p8.clone(), at_p: crate::lower::node_::finish::place_at_f(wx_p0, &Text::lit("self"), &pos_p8), source_p: src_ex_pe.clone(), value_ty_p: vt_p9.clone(), select_p: select_pv.clone(), transparent_p: true, width_p: width_pc.clone(), moved_p: crate::prelude::or(&crate::lower::node_::finish::hosted_rows_o(wx_p0), &Text::lit("")) });
                this.gen_holds_p = crate::prelude::push(&this.gen_holds_p, &(name_pg.clone(), reads_pf.clone()));
                this.rows_p = crate::prelude::fold(&cases_pd, &this.rows_p, &(|acc_p11: &Array<crate::lower::model::NodeDef>, gc_p12: &GenCase| crate::prelude::append(&crate::prelude::push(acc_p11, &gc_p12.node_p), &gc_p12.node_p.children_p)));
                this.getters_p = crate::prelude::push(&this.getters_p, &gen_up_f(&name_pg, &crate::lower::node_::gn_of_f(&wx3_pq, &up_id_pi).name_p, &crate::lower::node_::gn_of_f(&wx3_pq, &up_id_pi).ty_p));
                this
            };
            (wx4_p10.clone(), crate::lower::node_::Wres::WrEv(crate::lower::node_::ev_ref_of_f(&wx4_p10, &up_id_pi)))
        }
    }
}

/// ```prism
/// IsHostedScope: fn Wx -> Bool
/// ```
pub fn is_hosted_scope_f(wx_p0: &crate::lower::node_::Wx) -> bool {
    (&wx_p0.pos_p.scope_p > &Nat::from(0u32)) || is_some_f(&wx_p0.hosted_by_o)
}

/// ```prism
/// IsSome: fn ?a -> Bool
/// ```
pub fn is_some_f<A: Clone + 'static>(opt0: &Option<A>) -> bool {
    match opt0 {
        Some(_) => true,
        None => false,
    }
}

/// ```prism
/// GenCases: unbounded fn Wx, Env, Block, OutTy, Text -> (([GenCase], Wx))
/// ```
pub fn gen_cases_f(wx_p0: &crate::lower::node_::Wx, menv_p1: &crate::lower::types::Env, body_p2: &crate::syntax::Block, vt_p3: &crate::lower::model::OutTy, name_p4: &Text) -> (Array<GenCase>, crate::lower::node_::Wx) {
    let lx_p5 = wx_p0.lx_p.clone();
    let row_name_p6 = Text::from(format!("{}Gen{}", &wx_p0.node_p, &crate::lower::node_::keyed::row_suffix_f(wx_p0)));
    match clause_call_o(&lx_p5, body_p2) {
        Some((qk_p7, args_p8)) => {
            let clauses_p9 = crate::lower::jobs::clauses_of_f(&lx_p5.g_p, &qk_p7);
            let v_pa = crate::lower::program::val_of_f(&lx_p5, &qk_p7);
            crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(&clauses_p9)), (Array::new(), wx_p0.clone()), {
                let clauses_p9x = clauses_p9.clone();
                let menv_p1x = menv_p1.clone();
                let v_pax = v_pa.clone();
                let row_name_p6x = row_name_p6.clone();
                let name_p4x = name_p4.clone();
                Rc::new(move |(p0, p1): ((Array<GenCase>, crate::lower::node_::Wx), Nat)| {
                    let clauses_p9xy = clauses_p9x.clone();
                    let menv_p1xy = menv_p1x.clone();
                    let v_paxy = v_pax.clone();
                    let row_name_p6xy = row_name_p6x.clone();
                    let name_p4xy = name_p4x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let (acc_pb, w_pc) = p0;
                        let i_pd = p1;
                        {
                            let c_pe = crate::prelude::or(&crate::prelude::index(&clauses_p9xy, &i_pd), &crate::lower::functions::dummy_clause_p());
                            let cr_pf = clause_row_of_f(&w_pc, &menv_p1xy, &c_pe, &v_paxy, &Text::from(format!("{}{}", &row_name_p6xy, &i_pd)), &name_p4xy, &false);
                            prism_rtl::Turn::Finished((crate::prelude::push(&acc_pb, &cr_pf.case_p), cr_pf.parent_p.clone()))
                        }
                    }))
                }) as Rc<dyn Fn(((Array<GenCase>, crate::lower::node_::Wx), Nat)) -> Rc<dyn prism_rtl::Job<(Array<GenCase>, crate::lower::node_::Wx)>>>
            }))
        },
        None => {
            let whole_pg = gen_row_of_f(wx_p0, menv_p1, body_p2, vt_p3, &row_name_p6, name_p4);
            (Array::from(vec![GenCase { node_p: whole_pg.node_p.clone(), params_p: Array::from(vec![(Text::lit("value"), vt_p3.clone())]), pat_p: crate::lower::model::Pa::PaWild, conds_p: Array::new(), passed_p: Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("value"))]) }]), whole_pg.parent_p.clone())
        },
    }
}

/// ```prism
/// ?ClauseCall: fn Lx, Block -> ?((Text, [Arg]))
/// ```
pub fn clause_call_o(lx_p0: &crate::lower::Lx, body_p1: &crate::syntax::Block) -> Option<(Text, Array<crate::syntax::Arg>)> {
    'm13740: {
        let scrutinee = &body_p1.stmts_p;
        if let m13740_0 = scrutinee && (m13740_0.len() == 1) && let Some(st_p2) = crate::prelude::index(m13740_0, &Nat::from(0u32)) {
            break 'm13740 match &st_p2.kind_p {
                crate::syntax::StmtKind::SExpr(x_p3) => clause_call_x_o(lx_p0, x_p3),
                crate::syntax::StmtKind::SIgnore(x_p4) => clause_call_x_o(lx_p0, x_p4),
                _ => None,
            };
        }
        None
    }
}

/// ```prism
/// ?ClauseCallX: fn Lx, Expr -> ?((Text, [Arg]))
/// ```
pub fn clause_call_x_o(lx_p0: &crate::lower::Lx, x_p1: &crate::syntax::Expr) -> Option<(Text, Array<crate::syntax::Arg>)> {
    match &*x_p1.kind_p {
        crate::syntax::ExprKind::ECall(c_p2, args_p3, _, _) => {
            let qk_p4 = crate::lower::program::blueprint_qk_f(lx_p0, &**c_p2);
            if &crate::prelude::len(&crate::lower::jobs::clauses_of_f(&lx_p0.g_p, &qk_p4)) > &Nat::from(1u32) {
                Some((qk_p4.clone(), args_p3.clone()))
            } else {
                None
            }
        },
        _ => None,
    }
}

/// ```prism
/// ClauseRowOf: unbounded fn Wx, Env, FnClause, ValInfo, Text, Text, Bool -> ClauseRow
/// ```
pub fn clause_row_of_f(wx_p0: &crate::lower::node_::Wx, menv_p1: &crate::lower::types::Env, c_p2: &crate::syntax::decls::FnClause, v_p3: &crate::check::env::ValInfo, row_name_p4: &Text, gen_name_p5: &Text, transparent_p6: &bool) -> ClauseRow {
    let up_name_p7 = Text::from(format!("{}_up", gen_name_p5));
    let lx_p8 = wx_p0.lx_p.clone();
    let lxc_p9 = crate::lower::program::in_module_at_f(&lx_p8, &v_p3.file_p, &v_p3.home_p, &lx_p8.site_p);
    let ptys_pa = match &v_p3.scheme_p.ty_p {
        crate::check::types::Ty::TyFn(_, ps_pr, _) => ps_pr.clone(),
        _ => Array::new(),
    };
    let pos_pb = crate::prelude::run_to_end(crate::prelude::each_job(crate::check::errors::range0_f(&crate::prelude::len(&c_p2.params_p)), {
        let lxc_p9x = lxc_p9.clone();
        let c_p2x = c_p2.clone();
        let ptys_pax = ptys_pa.clone();
        Rc::new(move |p0: Nat| {
            let lxc_p9xy = lxc_p9x.clone();
            let c_p2xy = c_p2x.clone();
            let ptys_paxy = ptys_pax.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let i_ps = p0;
                prism_rtl::Turn::More(Rc::new(crate::lower::patterns::RustPat { lx_p0: lxc_p9xy.clone(), p_p1: crate::prelude::or(&crate::prelude::index(&c_p2xy.params_p, &i_ps), &crate::lower::patterns::dummy_pat_p()), ty_p2: crate::prelude::or(&crate::prelude::index(&ptys_paxy, &i_ps), &crate::check::types::Ty::TyErr), mode_p3: crate::lower::types::Holding::ByRef, fresh_p4: Text::from(format!("c{}", &i_ps)) }))
            }))
        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<crate::lower::patterns::PatOut>>>
    }));
    let pa_pc = crate::lower::model::Pa::PaTuple(crate::prelude::each(&pos_pb, &(|o_pt: &crate::lower::patterns::PatOut| o_pt.pa_p.clone())));
    let binds_pd = crate::prelude::fold(&pos_pb, &Map::new(), &(|m_pu: &Map<Text, crate::lower::types::Bn>, o_pv: &crate::lower::patterns::PatOut| crate::prelude::fold(&o_pv.binds_p, m_pu, &(|m2_p10: &Map<Text, crate::lower::types::Bn>, (n_p11, b_p12): &(Text, crate::lower::types::Bn)| crate::prelude::insert(m2_p10, n_p11, b_p12)))));
    let binders_pe = crate::prelude::filter(&crate::prelude::run_to_end(crate::prelude::fold_job(c_p2.params_p.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<(Text, crate::syntax::Range)>, crate::syntax::Pattern_)| crate::prelude::entered(crate::prelude::once_job(move || {
        let acc_p13 = p0;
        let p_p14 = p1;
        crate::prelude::call_then(crate::check::env::names::start_pattern_binders_f(p_p14.clone()), move |pattern_binders_f_15253: Array<(Text, crate::syntax::Range)>| prism_rtl::Turn::Finished(crate::prelude::append(&acc_p13, &pattern_binders_f_15253)))
    }))) as Rc<dyn Fn((Array<(Text, crate::syntax::Range)>, crate::syntax::Pattern_)) -> Rc<dyn prism_rtl::Job<Array<(Text, crate::syntax::Range)>>>>)), &(|(bn_p15, _): &(Text, crate::syntax::Range)| crate::check::env::has_key_f(&binds_pd, bn_p15)));
    let fields_pf = crate::prelude::run_to_end(crate::prelude::each_job(binders_pe.clone(), {
        let lxc_p9x = lxc_p9.clone();
        Rc::new(move |p0: (Text, crate::syntax::Range)| {
            let lxc_p9xy = lxc_p9x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (bn_p16, r_p17) = p0;
                crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lxc_p9xy.clone(), crate::lower::types::peel_f(&crate::lower::binder_ty_f(&lxc_p9xy, &r_p17))), move |out_ty_of_f_15367: crate::lower::model::OutTy| prism_rtl::Turn::Finished((crate::lower::snake_f(&bn_p16), out_ty_of_f_15367, bn_p16.clone())))
            }))
        }) as Rc<dyn Fn((Text, crate::syntax::Range)) -> Rc<dyn prism_rtl::Job<(Text, crate::lower::model::OutTy, Text)>>>
    }));
    let row_fields_pg = crate::prelude::push(&crate::prelude::each(&fields_pf, &(|(f_p18, t_p19, bn_p1a): &(Text, crate::lower::model::OutTy, Text)| (f_p18.clone(), t_p19.clone(), Text::from(format!("`{}`", bn_p1a))))), &(Text::lit("parent"), crate::lower::model::OutTy::OutWeak(wx_p0.node_p.clone()), Text::lit("the node of the `rebuild`")));
    let row_inits_ph = crate::prelude::each(&fields_pf, &(|(f_p1b, _, _): &(Text, crate::lower::model::OutTy, Text)| (f_p1b.clone(), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(f_p1b.clone()))))));
    let row_taken_pi = crate::prelude::append(&crate::lower::node_::node_hooks_p(), &crate::prelude::push(&crate::prelude::each(&fields_pf, &(|(f_p1c, _, _): &(Text, crate::lower::model::OutTy, Text)| f_p1c.clone())), &Text::lit("parent")));
    let r00_pj = crate::lower::node_::new_wx_f(&lxc_p9, row_name_p4, &row_fields_pg, &row_inits_ph, &Array::from(vec![(Text::lit("parent"), crate::lower::model::Ex::XVar(Text::lit("parent")))]), &Array::new(), &Map::new(), &row_taken_pi, &wx_p0.inlining_p, &crate::lower::node_::finish::hosted_rows_o(wx_p0));
    let r0_pk = if *transparent_p6 {
        {
            let mut this: crate::lower::node_::Wx = r00_pj.clone();
            this.pos_p = wx_p0.pos_p.clone();
            this
        }
    } else {
        r00_pj.clone()
    };
    let body_pl = match &c_p2.body_p {
        crate::syntax::decls::FnBody::BodyBlock(b_p1d) => b_p1d.clone(),
        crate::syntax::decls::FnBody::BodyExpr(x_p1e) => crate::syntax::Block { stmts_p: Array::from(vec![crate::syntax::Stmt { kind_p: crate::syntax::StmtKind::SExpr(x_p1e.clone()), span_p: x_p1e.span_p.clone() }]), inline_p: true, span_p: x_p1e.span_p.clone() },
    };
    let (p1_p1f, r1_p1g, ports_p1h) = row_env_f(wx_p0, &r0_pk, menv_p1, &body_pl);
    let (be_p1n, me_p1o) = crate::prelude::fold(&fields_pf, &(crate::lower::types::empty_env_p(), crate::lower::types::empty_env_p()), &(|(b_p1i, m_p1j): &(crate::lower::types::Env, crate::lower::types::Env), (f_p1k, t_p1l, bn_p1m): &(Text, crate::lower::model::OutTy, Text)| crate::lower::node_::bind_plain_f(b_p1i, m_p1j, bn_p1m, f_p1k, t_p1l)));
    let r2_pm = crate::lower::node_::def::block_into_f(&r1_p1g, &be_p1n, &me_p1o, &body_pl);
    let r3_pn = match &r2_pm.result_p {
        crate::lower::node_::Wres::WrEv(r_p1p) => crate::lower::node_::connect_f(&r2_pm, r_p1p, &crate::lower::node_::Sk::SkUp(up_name_p7.clone())),
        crate::lower::node_::Wres::WrParts(_) => {
            let mut this: crate::lower::node_::Wx = r2_pm.clone();
            this.build_p = crate::prelude::push(&this.build_p, &crate::lower::expr::refusal_do_f(&Text::lit("a widget of several clauses whose clause ends on a bundle")));
            this
        },
        _ => r2_pm.clone(),
    };
    let node_po = crate::lower::node_::finish::finish_node_f(&r3_pn, row_name_p4, &crate::prelude::append(&crate::prelude::push(&crate::prelude::each(&fields_pf, &(|(f_p1q, t_p1r, _): &(Text, crate::lower::model::OutTy, Text)| (f_p1q.clone(), t_p1r.clone()))), &(Text::lit("parent"), crate::lower::model::OutTy::OutWeak(wx_p0.node_p.clone()))), &crate::lower::node_::keyed::hosted_params_f(wx_p0)), &true);
    let p2_pp = gen_marked_f(&p1_p1f, gen_name_p5, &r3_pn);
    let passed_pq = crate::prelude::each(&fields_pf, &(|(f_p1s, t_p1t, bn_p1u): &(Text, crate::lower::model::OutTy, Text)| match crate::prelude::get(&binds_pd, bn_p1u) {
        Some(crate::lower::types::Bn::BnLocal(rs_p1v, mode_p20, bt_p21)) => crate::lower::types::own_f(&crate::lower::types::Vl::VlPlace(rs_p1v, mode_p20, bt_p21)),
        _ => crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(f_p1s.clone()))),
    }));
    ClauseRow { case_p: GenCase { node_p: node_po.clone(), params_p: crate::prelude::each(&fields_pf, &(|(f_p22, t_p23, _): &(Text, crate::lower::model::OutTy, Text)| (f_p22.clone(), t_p23.clone()))), pat_p: pa_pc.clone(), conds_p: crate::prelude::fold(&pos_pb, &Array::new(), &(|acc_p24: &Array<crate::lower::model::Cc>, o_p25: &crate::lower::patterns::PatOut| crate::prelude::append(acc_p24, &o_p25.conds_p))), passed_p: passed_pq.clone() }, parent_p: p2_pp.clone(), width_p: crate::prelude::or(&(&r2_pm.pos_p.at_p).checked_sub(&r0_pk.pos_p.at_p), &Nat::from(0u32)) }
}

/// ```prism
/// GenRowOf: unbounded fn Wx, Env, Block, OutTy, Text, Text -> GenRow
/// ```
pub fn gen_row_of_f(wx_p0: &crate::lower::node_::Wx, menv_p1: &crate::lower::types::Env, body_p2: &crate::syntax::Block, vt_p3: &crate::lower::model::OutTy, row_name_p4: &Text, gen_name_p5: &Text) -> GenRow {
    let lx_p6 = wx_p0.lx_p.clone();
    let up_name_p7 = Text::from(format!("{}_up", gen_name_p5));
    let r0_p8 = crate::lower::node_::new_wx_f(&lx_p6, row_name_p4, &Array::from(vec![(Text::lit("value"), vt_p3.clone(), Text::lit("the generation\'s value, `_`")), (Text::lit("parent"), crate::lower::model::OutTy::OutWeak(wx_p0.node_p.clone()), Text::lit("the node of the `rebuild`"))]), &Array::from(vec![(Text::lit("value"), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(Text::lit("value")))))]), &Array::from(vec![(Text::lit("parent"), crate::lower::model::Ex::XVar(Text::lit("parent")))]), &Array::new(), &Map::new(), &crate::prelude::append(&crate::lower::node_::node_hooks_p(), &Array::from(vec![Text::lit("value"), Text::lit("parent"), Text::lit("result"), Text::lit("result_dynamic")])), &wx_p0.inlining_p, &crate::lower::node_::finish::hosted_rows_o(wx_p0));
    let (p1_pc, r1_pd, ports_pe) = row_env_f(wx_p0, &r0_p8, menv_p1, body_p2);
    let be_p9 = crate::lower::types::bind_f(&build_spelling_f(&ports_pe), &Text::lit("_"), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(Text::lit("value")), crate::lower::types::Holding::Owned, vt_p3.clone()));
    let me_pa = crate::lower::types::bind_f(&ports_pe, &Text::lit("_"), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::lit("value")), crate::lower::types::Holding::Owned, vt_p3.clone()));
    let r2_pb = crate::lower::node_::def::block_into_f(&r1_pd, &be_p9, &me_pa, body_p2);
    let (r3_pk, dyn_result_ol) = match &r2_pb.result_p {
        crate::lower::node_::Wres::WrEv(r_pf) => (crate::lower::node_::connect_f(&r2_pb, r_pf, &crate::lower::node_::Sk::SkUp(up_name_p7.clone())), None),
        crate::lower::node_::Wres::WrDyn(ex_pg, result_reads_ph, rt_pi) => (gen_result_f(&r2_pb, gen_name_p5, ex_pg, result_reads_ph, rt_pi), Some(rt_pi.clone())),
        crate::lower::node_::Wres::WrParts(_) => {
            let r2b_pj = {
                let mut this: crate::lower::node_::Wx = r2_pb.clone();
                this.build_p = crate::prelude::push(&this.build_p, &crate::lower::expr::refusal_do_f(&Text::lit("a `rebuild` whose block ends on a bundle")));
                this
            };
            (r2b_pj.clone(), None)
        },
        _ => (r2_pb.clone(), None),
    };
    GenRow { node_p: crate::lower::node_::finish::finish_node_f(&r3_pk, row_name_p4, &crate::prelude::append(&Array::from(vec![(Text::lit("value"), vt_p3.clone()), (Text::lit("parent"), crate::lower::model::OutTy::OutWeak(wx_p0.node_p.clone()))]), &crate::lower::node_::keyed::hosted_params_f(wx_p0)), &true), parent_p: gen_marked_f(&p1_pc, gen_name_p5, &r3_pk), dyn_result_o: dyn_result_ol.clone() }
}

/// ```prism
/// GenResult: fn Wx, Text, Ex, [Read], OutTy -> Wx
/// ```
pub fn gen_result_f(r_p0: &crate::lower::node_::Wx, gen_name_p1: &Text, ex_p2: &crate::lower::model::Ex, result_reads_p3: &Array<crate::lower::node_::Read>, rt_p4: &crate::lower::model::OutTy) -> crate::lower::node_::Wx {
    let own_behind_p5 = crate::prelude::filter(&crate::lower::node_::finish::reads_closed_f(&r_p0.dyn_reads_p, result_reads_p3), &(|rd_p8: &crate::lower::node_::Read| match rd_p8 {
        crate::lower::node_::Read::OwnRead(_) => true,
        crate::lower::node_::Read::ParentRead(_) => false,
    }));
    let made_p6 = crate::lower::model::Ex::XCall(Text::lit("Dynamic::of"), Array::from(vec![crate::lower::model::Ex::XClosure(true, Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("cx"))]), Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("me"))), Text::lit("result"), Array::from(vec![crate::lower::model::Ex::XCx])))), crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XCall(Text::lit("Rc::new"), Array::from(vec![crate::lower::model::Ex::XCall(Text::lit("Port::new"), Array::new())]))))]));
    let doc_p7 = Text::from(format!("The generation\'s result as a dynamic, which the block keeps while the generation is current; the block hears it move through `{}_result_moved`, not through the dynamic\'s port.", gen_name_p1));
    let mut this: crate::lower::node_::Wx = r_p0.clone();
    this.getters_p = crate::prelude::append(&this.getters_p, &Array::from(vec![crate::lower::model::MethDef { name_p: Text::lit("result"), recv_p: crate::lower::model::Recv::RecvRef, params_p: Array::new(), cx_p: crate::lower::model::CxArg::CxRef, ret_p: rt_p4.clone(), body_p: Array::new(), tail_p: ex_p2.clone(), doc_p: Text::lit("The generation\'s result, which the `rebuild` hands back.") }, crate::lower::model::MethDef { name_p: Text::lit("result_dynamic"), recv_p: crate::lower::model::Recv::RecvRc, params_p: Array::new(), cx_p: crate::lower::model::CxArg::CxNone, ret_p: crate::lower::model::OutTy::OutDyn(Rc::new(rt_p4.clone())), body_p: Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(Text::lit("me")), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XSelf)))]), tail_p: made_p6.clone(), doc_p: doc_p7.clone() }]));
    this.result_moved_o = if &crate::prelude::len(&own_behind_p5) > &Nat::from(0u32) {
        Some((Text::from(format!("{}_result_moved", gen_name_p1)), own_behind_p5.clone()))
    } else {
        None
    };
    this
}

/// ```prism
/// GenMarked: fn Wx, Text, Wx -> Wx
/// ```
pub fn gen_marked_f(parent_p0: &crate::lower::node_::Wx, gen_name_p1: &Text, row_wx_p2: &crate::lower::node_::Wx) -> crate::lower::node_::Wx {
    let reads_p3 = crate::lower::node_::keyed::row_place_reads_f(row_wx_p2);
    if &crate::prelude::len(&reads_p3) == &Nat::from(0u32) {
        parent_p0.clone()
    } else {
        {
            let mut this: crate::lower::node_::Wx = parent_p0.clone();
            this.row_marks_p = crate::prelude::push(&this.row_marks_p, &crate::lower::node_::RowMarks { builder_p: gen_name_p1.clone(), reads_p: reads_p3.clone(), wrote_p: Array::new(), kind_p: crate::lower::model::RowKind::GenerationRow });
            this
        }
    }
}

/// ```prism
/// BuildSpelling: fn Env -> Env
/// ```
pub fn build_spelling_f(env_p0: &crate::lower::types::Env) -> crate::lower::types::Env {
    crate::prelude::fold(&crate::prelude::keys(&env_p0.names_p), env_p0, &(|en_p1: &crate::lower::types::Env, k_p2: &Text| match crate::prelude::get(&env_p0.names_p, k_p2) {
        Some(crate::lower::types::Bn::BnLocal(rs_p3, mode_p4, t_p5)) => match crate::lower::types::through_parent_o(&rs_p3) {
            Some(x_p6) => crate::lower::types::bind_f(en_p1, k_p2, &crate::lower::types::Bn::BnLocal(x_p6, mode_p4, t_p5)),
            None => en_p1.clone(),
        },
        Some(crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(rs_p7, m_p8, xs_p9), ds_pa, t_pb)) => match crate::lower::types::through_parent_o(&*rs_p7) {
            Some(x_pc) => crate::lower::types::bind_f(en_p1, k_p2, &crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(Rc::new(x_pc), m_p8, xs_p9), ds_pa, t_pb)),
            None => en_p1.clone(),
        },
        _ => en_p1.clone(),
    }))
}

/// ```prism
/// GenSelect: unbounded fn Wx, Env, Block, [GenCase], Pos -> Ex
/// ```
pub fn gen_select_f(wx_p0: &crate::lower::node_::Wx, menv_p1: &crate::lower::types::Env, body_p2: &crate::syntax::Block, cases_p3: &Array<GenCase>, pos_p4: &crate::lower::model::Pos_) -> crate::lower::model::Ex {
    let tail_p5 = crate::prelude::append(&crate::prelude::append(&Array::from(vec![crate::lower::model::Ex::XWeak(Rc::new(crate::lower::model::Ex::XSelf))]), &crate::lower::node_::keyed::hosted_passed_f(wx_p0)), &Array::from(vec![crate::lower::model::Ex::XCx]));
    match clause_call_o(&wx_p0.lx_p, body_p2) {
        None => match crate::prelude::index(cases_p3, &Nat::from(0u32)) {
            Some(c_p6) => crate::lower::expr::try_of_f(&crate::lower::model::Ex::XCall(Text::from(format!("{}::build", &c_p6.node_p.name_p)), crate::prelude::append(&Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("path")), crate::lower::model::Ex::XVar(Text::lit("value"))]), &tail_p5))),
            None => crate::lower::expr::refusal_f(&Text::lit("a `rebuild` with no generation")),
        },
        Some((qk_p7, args_p8)) => {
            let env_p9 = crate::lower::types::bind_f(menv_p1, &Text::lit("_"), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(Text::lit("value")), crate::lower::types::Holding::Owned, crate::lower::model::OutTy::OutUnit));
            let scrut_pa = crate::lower::model::Ex::XTuple(crate::prelude::run_to_end(crate::prelude::each_job(args_p8.clone(), {
                let wx_p0x = wx_p0.clone();
                let env_p9x = env_p9.clone();
                Rc::new(move |p0: crate::syntax::Arg| {
                    let wx_p0xy = wx_p0x.clone();
                    let env_p9xy = env_p9x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let a_pc = p0;
                        prism_rtl::Turn::More(Rc::new(crate::lower::expr::Argument { lx_p0: wx_p0xy.lx_p.clone(), env_p1: env_p9xy.clone(), e_p2: a_pc.value_p.clone() }))
                    }))
                }) as Rc<dyn Fn(crate::syntax::Arg) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
            })));
            let arms_pb = crate::prelude::each(cases_p3, &(|c_pd: &GenCase| {
                let made_pe = crate::lower::expr::try_of_f(&crate::lower::model::Ex::XCall(Text::from(format!("{}::build", &c_pd.node_p.name_p)), crate::prelude::append(&crate::prelude::append(&Array::from(vec![crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(Text::lit("path"))))]), &c_pd.passed_p), &tail_p5)));
                crate::lower::model::XArm { pat_p: c_pd.pat_p.clone(), conds_p: c_pd.conds_p.clone(), body_p: crate::lower::model::Ex::XCast(Rc::new(made_pe.clone()), crate::lower::model::OutTy::OutObj(Rc::new(crate::lower::model::OutTy::OutNamed(Text::lit("Row"), Array::new())))) }
            }));
            crate::lower::types::own_f(&crate::lower::expr::arms_value_f(&scrut_pa, &arms_pb, &Text::lit("\'select"), &crate::lower::model::OutTy::OutObj(Rc::new(crate::lower::model::OutTy::OutNamed(Text::lit("Row"), Array::new())))))
        },
    }
}

/// ```prism
/// GenUp: fn Text, Text, OutTy -> MethDef
/// ```
pub fn gen_up_f(name_p0: &Text, up_name_p1: &Text, t_p2: &crate::lower::model::OutTy) -> crate::lower::model::MethDef {
    crate::lower::model::MethDef { name_p: Text::from(format!("{}_up", name_p0)), recv_p: crate::lower::model::Recv::RecvRc, params_p: Array::from(vec![(Text::lit("v"), t_p2.clone())]), cx_p: crate::lower::model::CxArg::CxMut, ret_p: crate::lower::model::OutTy::OutUnit, body_p: Array::from(vec![crate::lower::node_::finish::self_call_f(up_name_p1, &Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("v"))]))]), tail_p: crate::lower::model::Ex::XUnit, doc_p: Text::lit("The current generation\'s result fires the `rebuild`\'s.") }
}

/// ```prism
/// GenForwards: fn GenDef -> [((Pa, Ex))]
/// ```
pub fn gen_forwards_f(gd_p0: &crate::lower::model::GenDef) -> Array<(crate::lower::model::Pa, crate::lower::model::Ex)> {
    if gd_p0.transparent_p {
        crate::prelude::each(&crate::check::errors::range0_f(&gd_p0.width_p), &(|i_p1: &Nat| {
            let current_p2 = crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", &gd_p0.name_p)))), Text::lit("borrow"), Array::new())));
            let body_p3 = crate::lower::model::Ex::XBlock(Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(Text::lit("row")), current_p2.clone()), crate::lower::model::Do::DoIfLet(crate::lower::model::Pa::PaCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("row"))])), crate::lower::model::Ex::XVar(Text::lit("row")), Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::expr::try_of_f(&crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("row"))), Text::lit("answer"), Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("at")), crate::lower::model::Ex::XVar(Text::lit("v")), crate::lower::model::Ex::XCx]))))]), Array::new())]), Rc::new(crate::lower::model::Ex::XUnit));
            (crate::lower::node_::finish::pos_pat_f(&crate::lower::model::Pos_ { scope_p: gd_p0.pos_p.scope_p.clone(), at_p: &gd_p0.pos_p.at_p + i_p1 }, &Array::from(vec![crate::lower::model::Pa::PaRest(Text::lit(""))])), body_p3.clone())
        }))
    } else {
        Array::from(vec![(crate::lower::node_::finish::pos_pat_f(&gd_p0.pos_p, &crate::lower::node_::finish::gen_tail_p()), forward_gen_f(gd_p0))])
    }
}

/// ```prism
/// ForwardGen: fn GenDef -> Ex
/// ```
pub fn forward_gen_f(gd_p0: &crate::lower::model::GenDef) -> crate::lower::model::Ex {
    let current_p1 = crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", &gd_p0.name_p)))), Text::lit("borrow"), Array::new())));
    let is_current_p2 = crate::lower::model::Ex::XBin(crate::lower::model::BinOp::OpEq, Rc::new(crate::lower::model::Ex::XBin(crate::lower::model::BinOp::OpAdd, Rc::new(crate::lower::model::Ex::XDeref(Rc::new(crate::lower::model::Ex::XVar(Text::lit("g"))))), Rc::new(crate::lower::model::Ex::XIndex(Nat::from(1u32))))), Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_count", &gd_p0.name_p)))), Text::lit("get"), Array::new())));
    crate::lower::model::Ex::XBlock(Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(Text::lit("row")), current_p1.clone()), crate::lower::model::Do::DoIfLet(crate::lower::model::Pa::PaCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("row"))])), crate::lower::model::Ex::XVar(Text::lit("row")), Array::from(vec![crate::lower::model::Do::DoIf(is_current_p2.clone(), Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::expr::try_of_f(&crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("row"))), Text::lit("answer"), Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("rest")), crate::lower::model::Ex::XVar(Text::lit("v")), crate::lower::model::Ex::XCx]))))]), Array::new())]), Array::new())]), Rc::new(crate::lower::model::Ex::XUnit))
}

/// ```prism
/// FlattenLine: unbounded fn Wx, Env, [Arg], ?Bn -> ((Wx, Wres))
/// ```
pub fn flatten_line_f(wx_p0: &crate::lower::node_::Wx, menv_p1: &crate::lower::types::Env, args_p2: &Array<crate::syntax::Arg>, bound_o3: &Option<crate::lower::types::Bn>) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    let named_o4 = match crate::prelude::index(args_p2, &Nat::from(0u32)) {
        Some(a_p6) => match &*a_p6.value_p.kind_p {
            crate::syntax::ExprKind::EName(n_p7) => 'm24386: {
                let scrutinee = &crate::prelude::get(&menv_p1.names_p, &crate::check::env::sname_key_f(n_p7));
                if let Some(crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(m24386_0_0_0, m_p8, _), _, crate::lower::model::OutTy::OutDyn(t_p9))) = scrutinee && let crate::lower::model::Ex::XSelf = &**m24386_0_0_0 {
                    break 'm24386 Some((m_p8.clone(), (**t_p9).clone()));
                }
                None
            },
            _ => None,
        },
        None => None,
    };
    let outer_o5 = match &named_o4 {
        Some((m_pa, t_pb)) => crate::prelude::fold(&wx_p0.gens_p, &None, &(|acc_oc: &Option<(Text, Text, crate::lower::model::OutTy)>, gd_pd: &crate::lower::model::GenDef| if &Text::from(format!("{}_result", &gd_pd.name_p)) == m_pa {
            Some((m_pa.clone(), gd_pd.name_p.clone(), t_pb.clone()))
        } else {
            acc_oc.clone()
        })),
        None => None,
    };
    match &outer_o5 {
        None => {
            let wx2_pe = {
                let mut this: crate::lower::node_::Wx = wx_p0.clone();
                this.build_p = crate::prelude::push(&this.build_p, &crate::lower::expr::refusal_do_f(&Text::lit("`@Flatten` of a dynamic that is not a `rebuild`\'s (a `for` over a map of dynamics binds the value under the key, `for k, $v <- $each:`, ruling FV)")));
                this
            };
            (wx2_pe.clone(), crate::lower::node_::Wres::WrUnit)
        },
        Some((m_pf, gen_pg, t_ph)) => {
            let (name_po, wx1_pp) = 'm25089: {
                if let Some(crate::lower::types::Bn::BnHold(f_pm, _)) = bound_o3 {
                    break 'm25089 (f_pm.clone(), wx_p0.clone());
                }
                if let Some(crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(m25089_1_0_0, f_pn, _), _, _)) = bound_o3 && let crate::lower::model::Ex::XSelf = &**m25089_1_0_0 {
                    break 'm25089 (f_pn.clone(), wx_p0.clone());
                }
                crate::lower::node_::fresh_name_f(wx_p0, &Text::lit("flatten"))
            };
            let inner_pi = Text::from(format!("{}_inner", &name_po));
            let first_pj = crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XVar(Text::lit("node"))), Text::from(format!("{}", &inner_pi)))), Text::lit("set"), Array::from(vec![crate::lower::model::Ex::XCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("node"))), m_pf.clone(), Array::from(vec![crate::lower::model::Ex::XCx]))])), crate::lower::model::Ex::XCx])));
            let sample_pk = crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", &inner_pi)))), Text::lit("get"), Array::from(vec![crate::lower::model::Ex::XCx]))), Text::lit("expect"), Array::from(vec![crate::lower::model::Ex::XStr(Text::lit("`@Flatten` adopts its first inner at the build"))]))), Text::lit("sample"), Array::from(vec![crate::lower::model::Ex::XCx]));
            let wx2_pl = {
                let mut this: crate::lower::node_::Wx = wx1_pp.clone();
                this.taken_p = crate::prelude::append(&this.taken_p, &Array::from(vec![inner_pi.clone(), Text::from(format!("{}_adopt", &name_po))]));
                this.fields_p = crate::prelude::push(&this.fields_p, &(inner_pi.clone(), crate::lower::model::OutTy::OutHold(Rc::new(crate::lower::model::OutTy::OutOpt(Rc::new(crate::lower::model::OutTy::OutDyn(Rc::new(t_ph.clone())))))), Text::lit("`@Flatten`\'s current inner: the dynamic of the generation it adopted")));
                this.moves_p = crate::prelude::push(&this.moves_p, &(inner_pi.clone(), crate::lower::model::Ex::XCall(Text::lit("Hold::new"), Array::from(vec![crate::lower::model::Ex::XNone, crate::lower::model::Ex::XCx]))));
                this.build_p = crate::prelude::push(&this.build_p, &first_pj);
                this.getters_p = crate::prelude::push(&this.getters_p, &crate::lower::model::MethDef { name_p: name_po.clone(), recv_p: crate::lower::model::Recv::RecvRef, params_p: Array::new(), cx_p: crate::lower::model::CxArg::CxRef, ret_p: t_ph.clone(), body_p: Array::new(), tail_p: sample_pk.clone(), doc_p: Text::lit("`@Flatten`\'s dynamic: its current inner at the read point.") });
                this.dyn_reads_p = crate::prelude::insert(&this.dyn_reads_p, &name_po, &Array::from(vec![crate::lower::node_::Read::OwnRead(inner_pi.clone())]));
                this.flattens_p = crate::prelude::push(&this.flattens_p, &crate::lower::node_::FlatDef { name_p: name_po.clone(), outer_p: m_pf.clone(), generation_p: gen_pg.clone(), ty_p: t_ph.clone() });
                this
            };
            (wx2_pl.clone(), crate::lower::node_::Wres::WrDyn(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XSelf), name_po.clone(), Array::from(vec![crate::lower::model::Ex::XCx])), Array::from(vec![crate::lower::node_::Read::OwnRead(inner_pi.clone())]), t_ph.clone()))
        },
    }
}

/// ```prism
/// EntryFlatten: unbounded fn Wx, OutTy, ?Bn -> ((Wx, Wres))
/// ```
pub fn entry_flatten_f(wx_p0: &crate::lower::node_::Wx, t_p1: &crate::lower::model::OutTy, bound_o2: &Option<crate::lower::types::Bn>) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    let (name_pa, wx1_pb) = 'm27626: {
        if let Some(crate::lower::types::Bn::BnHold(f_p8, _)) = bound_o2 {
            break 'm27626 (f_p8.clone(), wx_p0.clone());
        }
        if let Some(crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(m27626_1_0_0, f_p9, _), _, _)) = bound_o2 && let crate::lower::model::Ex::XSelf = &**m27626_1_0_0 {
            break 'm27626 (f_p9.clone(), wx_p0.clone());
        }
        crate::lower::node_::fresh_name_f(wx_p0, &Text::lit("flatten"))
    };
    let inner_p3 = Text::from(format!("{}_inner", &name_pa));
    let follow_p4 = Text::from(format!("{}_follow", &name_pa));
    let followed_p5 = crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XVar(Text::lit("node"))), follow_p4.clone())), Text::lit("follow"), Array::from(vec![crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("node"))), Text::lit("entry"), Array::from(vec![crate::lower::model::Ex::XCx]))), Text::lit("updates")))), crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XVar(Text::lit("node")))), crate::lower::model::Ex::XPath(Text::from(format!("{}::{}_moved", &wx_p0.node_p, &name_pa)))])));
    let sample_p6 = crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", &inner_p3)))), Text::lit("get"), Array::from(vec![crate::lower::model::Ex::XCx]))), Text::lit("expect"), Array::from(vec![crate::lower::model::Ex::XStr(Text::lit("`@Flatten` adopts its first inner at the build"))]))), Text::lit("sample"), Array::from(vec![crate::lower::model::Ex::XCx]));
    let wx2_p7 = {
        let mut this: crate::lower::node_::Wx = wx1_pb.clone();
        this.taken_p = crate::prelude::append(&this.taken_p, &Array::from(vec![inner_p3.clone(), follow_p4.clone(), Text::from(format!("{}_adopt", &name_pa)), Text::from(format!("{}_moved", &name_pa)), Text::from(format!("{}_replaced", &name_pa))]));
        this.fields_p = crate::prelude::append(&this.fields_p, &Array::from(vec![(inner_p3.clone(), crate::lower::model::OutTy::OutHold(Rc::new(crate::lower::model::OutTy::OutOpt(Rc::new(crate::lower::model::OutTy::OutDyn(Rc::new(t_p1.clone())))))), Text::lit("`@Flatten`\'s current inner: the row\'s entry it adopted")), (follow_p4.clone(), crate::lower::model::OutTy::OutNamed(Text::lit("prism_rtl::Follow"), Array::new()), Text::lit("the subscription to the inner\'s update event"))]));
        this.moves_p = crate::prelude::append(&this.moves_p, &Array::from(vec![(inner_p3.clone(), crate::lower::model::Ex::XCall(Text::lit("Hold::new"), Array::from(vec![crate::lower::model::Ex::XCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(Text::lit("value"))))])), crate::lower::model::Ex::XCx]))), (follow_p4.clone(), crate::lower::model::Ex::XCall(Text::lit("prism_rtl::Follow::new"), Array::new()))]));
        this.build_p = crate::prelude::push(&this.build_p, &followed_p5);
        this.getters_p = crate::prelude::push(&this.getters_p, &crate::lower::model::MethDef { name_p: name_pa.clone(), recv_p: crate::lower::model::Recv::RecvRef, params_p: Array::new(), cx_p: crate::lower::model::CxArg::CxRef, ret_p: t_p1.clone(), body_p: Array::new(), tail_p: sample_p6.clone(), doc_p: Text::lit("`@Flatten`\'s dynamic: its current inner at the read point.") });
        this.dyn_reads_p = crate::prelude::insert(&this.dyn_reads_p, &name_pa, &Array::from(vec![crate::lower::node_::Read::OwnRead(inner_p3.clone())]));
        this.flattens_p = crate::prelude::push(&this.flattens_p, &crate::lower::node_::FlatDef { name_p: name_pa.clone(), outer_p: Text::lit("entry"), generation_p: Text::lit(""), ty_p: t_p1.clone() });
        this
    };
    (wx2_p7.clone(), crate::lower::node_::Wres::WrDyn(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XSelf), name_pa.clone(), Array::from(vec![crate::lower::model::Ex::XCx])), Array::from(vec![crate::lower::node_::Read::OwnRead(inner_p3.clone())]), t_p1.clone()))
}

/// ```prism
/// SwitchLine: unbounded fn Wx, Env, [Arg] -> ((Wx, Wres))
/// ```
pub fn switch_line_f(wx_p0: &crate::lower::node_::Wx, menv_p1: &crate::lower::types::Env, args_p2: &Array<crate::syntax::Arg>) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    match crate::prelude::index(args_p2, &Nat::from(0u32)) {
        Some(a_p3) => {
            let (r_p4, wx2_p5) = crate::lower::node_::dynamics::event_ref_f(wx_p0, menv_p1, &a_p3.value_p);
            (wx2_p5.clone(), crate::lower::node_::Wres::WrEv(r_p4.clone()))
        },
        None => (wx_p0.clone(), crate::lower::node_::Wres::WrUnit),
    }
}
