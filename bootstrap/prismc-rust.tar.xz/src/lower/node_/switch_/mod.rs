//! The module `Lower.Node.Switch`, from `target/bootstrap/src/prismc/lower/node/switch.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// `ClauseRow`:
///
/// ```prism
/// type ClauseRow = record:
/// ```
#[derive(Clone)]
pub struct ClauseRow {
    pub case: GenCase,
    pub parent: crate::lower::node_::Wx,
    pub width: Nat,
}

/// `GenCase`:
///
/// ```prism
/// type GenCase = record:
/// ```
#[derive(Clone)]
pub struct GenCase {
    pub node_: crate::lower::model::NodeDef,
    pub params: Array<(Text, crate::lower::model::OutTy)>,
    pub pat: crate::lower::model::Pa,
    pub conds: Array<crate::lower::model::Cc>,
    pub passed: Array<crate::lower::model::Ex>,
}

impl ToPod for GenCase {
    fn to_pod(&self) -> Pod {
        Pod::record("GenCase", vec![("node", self.node_.to_pod()), ("params", self.params.to_pod()), ("pat", self.pat.to_pod()), ("conds", self.conds.to_pod()), ("passed", self.passed.to_pod())])
    }
}

impl FromPod for GenCase {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(GenCase { node_: FromPod::from_pod(field(p, "node")?)?, params: FromPod::from_pod(field(p, "params")?)?, pat: FromPod::from_pod(field(p, "pat")?)?, conds: FromPod::from_pod(field(p, "conds")?)?, passed: FromPod::from_pod(field(p, "passed")?)? })
    }
}

/// `GenRow`:
///
/// ```prism
/// type GenRow = record:
/// ```
#[derive(Clone)]
pub struct GenRow {
    pub node_: crate::lower::model::NodeDef,
    pub parent: crate::lower::node_::Wx,
    pub dyn_result: Option<crate::lower::model::OutTy>,
}

/// ```prism
/// RowEnv: unbounded fn Wx, Wx, Env, Block -> ((Wx, Wx, Env))
/// ```
pub fn row_env(parent_p0: &crate::lower::node_::Wx, row_wx_p1: &crate::lower::node_::Wx, menv_p2: &crate::lower::types::Env, body_p3: &crate::syntax::Block) -> (crate::lower::node_::Wx, crate::lower::node_::Wx, crate::lower::types::Env) {
    let names_p4 = crate::lower::expr::read_names(&crate::check::typed::print::block_exprs(body_p3));
    fold(&names_p4, &(parent_p0.clone(), row_wx_p1.clone(), crate::lower::types::empty_env()), &(|(p_p5, r_p6, env_p7): &(crate::lower::node_::Wx, crate::lower::node_::Wx, crate::lower::types::Env), n_p8: &Text| match get(&menv_p2.names, n_p8) {
        Some(crate::lower::types::Bn::BnLocal(rs_p9, mode_pa, t_pb)) => (p_p5.clone(), r_p6.clone(), crate::lower::types::bind(env_p7, n_p8, &crate::lower::types::Bn::BnLocal(over_parent(&rs_p9), crate::lower::types::Holding::Owned, t_pb))),
        Some(crate::lower::types::Bn::BnEv(er_pc, t_pd)) => {
            let pname_pe = crate::lower::node_::gn_of(p_p5, &er_pc.node_).name.clone();
            let (rs_ph, r1_pi) = crate::lower::node_::fresh_name(r_p6, &crate::lower::snake(n_p8));
            let (id_pj, r2_pk) = crate::lower::node_::add_gn(&r1_pi, &rs_ph, &t_pd, &crate::lower::node_::GnKind::GnPort, &Nat::from(0u32));
            let r3_pf = {
                let mut this: crate::lower::node_::Wx = r2_pk.clone();
                this.subs = push(&this.subs, &(pname_pe.clone(), rs_ph.clone(), t_pd.clone()));
                this
            };
            let p2_pg = if crate::check::types::has_text(&p_p5.ports, &pname_pe) {
                p_p5.clone()
            } else {
                crate::lower::node_::connect(&with_port(p_p5, &pname_pe), &crate::lower::node_::ev_ref_of(p_p5, &er_pc.node_), &crate::lower::node_::Sk::SkPort(pname_pe.clone()))
            };
            (p2_pg.clone(), r3_pf.clone(), crate::lower::types::bind(env_p7, n_p8, &crate::lower::types::Bn::BnEv(crate::lower::node_::ev_ref_of(&r3_pf, &id_pj), t_pd.clone())))
        },
        Some(crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(recv_pl, m_pm, xs_pn), _, t_po)) => if &*recv_pl == &crate::lower::model::Ex::XSelf {
            (p_p5.clone(), r_p6.clone(), crate::lower::types::bind(env_p7, n_p8, &crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(Rc::new(parent_ref()), m_pm.clone(), xs_pn), Array::from(vec![crate::lower::node_::Read::ParentRead(m_pm.clone())]), t_po)))
        } else {
            row_param_env(p_p5, r_p6, env_p7, menv_p2, n_p8)
        },
        Some(crate::lower::types::Bn::BnDyn(_, _, _)) => row_param_env(p_p5, r_p6, env_p7, menv_p2, n_p8),
        Some(crate::lower::types::Bn::BnHold(f_pp, t_pq)) => (p_p5.clone(), r_p6.clone(), crate::lower::types::bind(env_p7, n_p8, &crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(parent_ref()), f_pp.clone())), Text::lit("get"), Array::from(vec![crate::lower::model::Ex::XCx])), Array::from(vec![crate::lower::node_::Read::ParentRead(f_pp.clone())]), t_pq))),
        _ => (p_p5.clone(), r_p6.clone(), env_p7.clone()),
    }))
}

/// ```prism
/// RowParamEnv: fn Wx, Wx, Env, Env, Text -> ((Wx, Wx, Env))
/// ```
pub fn row_param_env(p_p0: &crate::lower::node_::Wx, r_p1: &crate::lower::node_::Wx, env_p2: &crate::lower::types::Env, menv_p3: &crate::lower::types::Env, n_p4: &Text) -> (crate::lower::node_::Wx, crate::lower::node_::Wx, crate::lower::types::Env) {
    match get(&menv_p3.names, &Text::from(format!("{}#row", n_p4))) {
        Some(crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(_, m_p5, xs_p6), _, t_p7)) => (p_p0.clone(), r_p1.clone(), crate::lower::types::bind(env_p2, n_p4, &crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(Rc::new(parent_ref()), m_p5.clone(), xs_p6), Array::from(vec![crate::lower::node_::Read::ParentRead(m_p5.clone())]), t_p7))),
        _ => (p_p0.clone(), r_p1.clone(), env_p2.clone()),
    }
}

/// ```prism
/// OverParent: fn Ex -> Ex
/// ```
pub fn over_parent(x_p0: &crate::lower::model::Ex) -> crate::lower::model::Ex {
    match x_p0 {
        crate::lower::model::Ex::XSelf => parent_ref(),
        crate::lower::model::Ex::XField(y_p1, f_p2) => crate::lower::model::Ex::XField(Rc::new(over_parent(&**y_p1)), f_p2.clone()),
        crate::lower::model::Ex::XPart(y_p3, k_p4) => crate::lower::model::Ex::XPart(Rc::new(over_parent(&**y_p3)), k_p4.clone()),
        crate::lower::model::Ex::XMethod(y_p5, m_p6, xs_p7) => crate::lower::model::Ex::XMethod(Rc::new(over_parent(&**y_p5)), m_p6.clone(), xs_p7.clone()),
        crate::lower::model::Ex::XUpgrade(y_p8) => crate::lower::model::Ex::XUpgrade(Rc::new(over_parent(&**y_p8))),
        _ => crate::lower::model::Ex::XField(Rc::new(parent_ref()), crate::lower::types::place_stem(x_p0)),
    }
}

/// ```prism
/// let parentRef
/// ```
pub fn parent_ref() -> crate::lower::model::Ex {
    crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XUpgrade(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::lit("parent"))))), Text::lit("expect"), Array::from(vec![crate::lower::model::Ex::XStr(Text::lit("the block outlives its rows"))]))
}

/// ```prism
/// let parentArg
/// ```
pub fn parent_arg() -> crate::lower::model::Ex {
    crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XUpgrade(Rc::new(crate::lower::model::Ex::XVar(Text::lit("parent"))))), Text::lit("expect"), Array::from(vec![crate::lower::model::Ex::XStr(Text::lit("the block outlives its rows"))]))
}

/// ```prism
/// WithPort: fn Wx, Text -> Wx
/// ```
pub fn with_port(wx_p0: &crate::lower::node_::Wx, pname_p1: &Text) -> crate::lower::node_::Wx {
    let mut this: crate::lower::node_::Wx = wx_p0.clone();
    this.ports = push(&this.ports, pname_p1);
    this
}

/// ```prism
/// RebuildLine: unbounded fn Wx, Env, Env, Expr, Block, Expr, ?Bn -> ((Wx, Wres))
/// ```
pub fn rebuild_line(wx_p0: &crate::lower::node_::Wx, benv_p1: &crate::lower::types::Env, menv_p2: &crate::lower::types::Env, scrut_p3: &crate::syntax::Expr, body_p4: &crate::syntax::Block, e_p5: &crate::syntax::Expr, bound_o6: &Option<crate::lower::types::Bn>) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    let lx_p7 = wx_p0.lx.clone();
    let pos_p8 = wx_p0.pos.clone();
    let wx1_p9 = {
        let mut this: crate::lower::node_::Wx = wx_p0.clone();
        this.pos = crate::lower::model::next_pos(&this.pos);
        this
    };
    let (src_ex_pb, reads_pc) = crate::lower::node_::dynamics::dynamic_expr(&wx1_p9, menv_p2, scrut_p3);
    let vt_pa = crate::lower::types::out_ty_of(&lx_p7, &crate::lower::types::peel(&crate::lower::type_at(&lx_p7, &scrut_p3.span)));
    let (name_pd, wx2_pe) = crate::lower::node_::fresh_name(&wx1_p9, &Text::lit("generation"));
    if gives_dynamic(&crate::lower::type_at(&lx_p7, &e_p5.span)) {
        rebuild_dynamic(&wx2_pe, menv_p2, body_p4, &src_ex_pb, &reads_pc, &vt_pa, &name_pd, &pos_p8)
    } else {
        {
            let (up_id_pj, wx3_pk) = match bound_o6 {
                Some(crate::lower::types::Bn::BnEv(er_pi, _)) => (er_pi.node_.clone(), wx2_pe.clone()),
                _ => crate::lower::node_::add_gn(&wx2_pe, &Text::from(format!("{}_fired", &name_pd)), &crate::lower::types::out_ty_of(&lx_p7, &crate::lower::types::peel(&crate::lower::type_at(&lx_p7, &e_p5.span))), &crate::lower::node_::GnKind::GnNamed, &Nat::from(0u32)),
            };
            let (cases_pl, wx4_pm) = gen_cases(&wx3_pk, menv_p2, body_p4, &vt_pa, &name_pd);
            let row_defs_pf = each(&cases_pl, &(|c_pn: &GenCase| c_pn.node_.clone()));
            let select_pg = gen_select(&wx4_pm, menv_p2, body_p4, &cases_pl, &pos_p8);
            let wx5_ph = {
                let mut this: crate::lower::node_::Wx = wx4_pm.clone();
                this.gens = push(&this.gens, &crate::lower::model::GenDef { name: name_pd.clone(), pos: pos_p8.clone(), at: crate::lower::node_::finish::place_at(wx_p0, &Text::lit("self"), &pos_p8), source: src_ex_pb.clone(), value_ty: vt_pa.clone(), select: select_pg.clone(), transparent: false, width: Nat::from(0u32), moved: or(&crate::lower::node_::finish::hosted_rows(wx_p0), &Text::lit("")) });
                this.gen_holds = push(&this.gen_holds, &(name_pd.clone(), reads_pc.clone()));
                this.rows = fold(&row_defs_pf, &this.rows, &(|acc_po: &Array<crate::lower::model::NodeDef>, rd_pp: &crate::lower::model::NodeDef| append(&push(acc_po, rd_pp), &rd_pp.children)));
                this.getters = push(&this.getters, &gen_up(&name_pd, &crate::lower::node_::gn_of(&wx4_pm, &up_id_pj).name, &crate::lower::node_::gn_of(&wx4_pm, &up_id_pj).ty));
                this
            };
            (wx5_ph.clone(), crate::lower::node_::Wres::WrEv(crate::lower::node_::ev_ref_of(&wx5_ph, &up_id_pj)))
        }
    }
}

/// The step machine of `RebuildLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RebuildLine: unbounded fn Wx, Env, Env, Expr, Block, Expr, ?Bn -> ((Wx, Wres))
/// ```
pub struct RebuildLine {
    pub wx_p0: crate::lower::node_::Wx,
    pub benv_p1: crate::lower::types::Env,
    pub menv_p2: crate::lower::types::Env,
    pub scrut_p3: crate::syntax::Expr,
    pub body_p4: crate::syntax::Block,
    pub e_p5: crate::syntax::Expr,
    pub bound_o6: Option<crate::lower::types::Bn>,
}

impl prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::node_::Wres)> for RebuildLine {
    fn cycle(&self) -> prism_rtl::Turn<(crate::lower::node_::Wx, crate::lower::node_::Wres)> {
        let wx_p0 = &self.wx_p0;
        let benv_p1 = &self.benv_p1;
        let menv_p2 = &self.menv_p2;
        let scrut_p3 = &self.scrut_p3;
        let body_p4 = &self.body_p4;
        let e_p5 = &self.e_p5;
        let bound_o6 = &self.bound_o6;
        let lx_p7 = wx_p0.lx.clone();
        let pos_p8 = wx_p0.pos.clone();
        let wx1_p9 = {
            let mut this: crate::lower::node_::Wx = wx_p0.clone();
            this.pos = crate::lower::model::next_pos(&this.pos);
            this
        };
        let bound_o6 = bound_o6.clone();
        let body_p4 = body_p4.clone();
        let e_p5 = e_p5.clone();
        let menv_p2 = menv_p2.clone();
        let scrut_p3 = scrut_p3.clone();
        let wx_p0 = wx_p0.clone();
        call_then(crate::lower::node_::dynamics::start_dynamic_expr(wx1_p9.clone(), menv_p2.clone(), scrut_p3.clone()), move |dynamic_expr_4431: (crate::lower::model::Ex, Array<crate::lower::node_::Read>)| {
            let (src_ex_pb, reads_pc) = dynamic_expr_4431;
            call_then(crate::lower::types::start_out_ty_of(lx_p7.clone(), crate::lower::types::peel(&crate::lower::type_at(&lx_p7, &scrut_p3.span))), move |out_ty_of_4473: crate::lower::model::OutTy| {
                let vt_pa = out_ty_of_4473;
                let (name_pd, wx2_pe) = crate::lower::node_::fresh_name(&wx1_p9, &Text::lit("generation"));
                if gives_dynamic(&crate::lower::type_at(&lx_p7, &e_p5.span)) {
                    prism_rtl::Turn::Finished(rebuild_dynamic(&wx2_pe, &menv_p2, &body_p4, &src_ex_pb, &reads_pc, &vt_pa, &name_pd, &pos_p8))
                } else {
                    {
                        let (up_id_pj, wx3_pk) = match &bound_o6 {
                            Some(crate::lower::types::Bn::BnEv(er_pi, _)) => (er_pi.node_.clone(), wx2_pe.clone()),
                            _ => crate::lower::node_::add_gn(&wx2_pe, &Text::from(format!("{}_fired", &name_pd)), &crate::lower::types::out_ty_of(&lx_p7, &crate::lower::types::peel(&crate::lower::type_at(&lx_p7, &e_p5.span))), &crate::lower::node_::GnKind::GnNamed, &Nat::from(0u32)),
                        };
                        let (cases_pl, wx4_pm) = gen_cases(&wx3_pk, &menv_p2, &body_p4, &vt_pa, &name_pd);
                        let row_defs_pf = each(&cases_pl, &(|c_pn: &GenCase| c_pn.node_.clone()));
                        let select_pg = gen_select(&wx4_pm, &menv_p2, &body_p4, &cases_pl, &pos_p8);
                        let wx5_ph = {
                            let mut this: crate::lower::node_::Wx = wx4_pm.clone();
                            this.gens = push(&this.gens, &crate::lower::model::GenDef { name: name_pd.clone(), pos: pos_p8.clone(), at: crate::lower::node_::finish::place_at(&wx_p0, &Text::lit("self"), &pos_p8), source: src_ex_pb.clone(), value_ty: vt_pa.clone(), select: select_pg.clone(), transparent: false, width: Nat::from(0u32), moved: or(&crate::lower::node_::finish::hosted_rows(&wx_p0), &Text::lit("")) });
                            this.gen_holds = push(&this.gen_holds, &(name_pd.clone(), reads_pc.clone()));
                            this.rows = fold(&row_defs_pf, &this.rows, &(|acc_po: &Array<crate::lower::model::NodeDef>, rd_pp: &crate::lower::model::NodeDef| append(&push(acc_po, rd_pp), &rd_pp.children)));
                            this.getters = push(&this.getters, &gen_up(&name_pd, &crate::lower::node_::gn_of(&wx4_pm, &up_id_pj).name, &crate::lower::node_::gn_of(&wx4_pm, &up_id_pj).ty));
                            this
                        };
                        prism_rtl::Turn::Finished((wx5_ph.clone(), crate::lower::node_::Wres::WrEv(crate::lower::node_::ev_ref_of(&wx5_ph, &up_id_pj))))
                    }
                }
            })
        })
    }
}

/// `Start RebuildLine, x`: what the function value is when passed to `@Run`.
pub fn start_rebuild_line(wx_p0: crate::lower::node_::Wx, benv_p1: crate::lower::types::Env, menv_p2: crate::lower::types::Env, scrut_p3: crate::syntax::Expr, body_p4: crate::syntax::Block, e_p5: crate::syntax::Expr, bound_o6: Option<crate::lower::types::Bn>) -> Rc<dyn prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::node_::Wres)>> {
    Rc::new(RebuildLine { wx_p0, benv_p1, menv_p2, scrut_p3, body_p4, e_p5, bound_o6 })
}

/// ```prism
/// GivesDynamic: fn Ty -> Bool
/// ```
pub fn gives_dynamic(t_p0: &crate::check::types::Ty) -> bool {
    'm5725: {
        if let crate::check::types::Ty::TySig(m5725_0_0, m5725_0_1) = t_p0 && (m5725_0_0 == &Text::lit("$")) && let crate::check::types::Ty::TySig(m5725_0_1_r_0, _) = &**m5725_0_1 && (m5725_0_1_r_0 == &Text::lit("$")) {
            break 'm5725 true;
        }
        if let crate::check::types::Ty::TyAt(i_p1, _) = t_p0 {
            break 'm5725 gives_dynamic(&**i_p1);
        }
        false
    }
}

/// ```prism
/// RebuildDynamic: unbounded fn Wx, Env, Block, Ex, [Read], OutTy, Text, Pos -> ((Wx, Wres))
/// ```
pub fn rebuild_dynamic(wx_p0: &crate::lower::node_::Wx, menv_p1: &crate::lower::types::Env, body_p2: &crate::syntax::Block, src_ex_p3: &crate::lower::model::Ex, reads_p4: &Array<crate::lower::node_::Read>, vt_p5: &crate::lower::model::OutTy, name_p6: &Text, pos_p7: &crate::lower::model::Pos_) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    let row_name_p8 = Text::from(format!("{}Gen{}", &wx_p0.node_, &crate::lower::node_::keyed::row_suffix(wx_p0)));
    let whole_p9 = gen_row_of(wx_p0, menv_p1, body_p2, vt_p5, &row_name_p8, name_p6);
    match &whole_p9.dyn_result {
        None => {
            let wx2_pa = {
                let mut this: crate::lower::node_::Wx = whole_p9.parent.clone();
                this.build = push(&this.build, &crate::lower::expr::refusal_do(&Text::lit("a `rebuild` whose generation gives a dynamic it does not lower")));
                this
            };
            (wx2_pa.clone(), crate::lower::node_::Wres::WrUnit)
        },
        Some(rt_pb) => {
            let dyn_ty_pc = crate::lower::model::OutTy::OutDyn(Rc::new(rt_pb.clone()));
            let result_pd = Text::from(format!("{}_result", name_p6));
            let live_pe = Text::from(format!("{}_live", &result_pd));
            let what_pf = Text::from(format!("the dynamic of the `rebuild` at place {}", &crate::lower::model::place_text(pos_p7)));
            let tail_pg = append(&append(&Array::from(vec![crate::lower::model::Ex::XWeak(Rc::new(crate::lower::model::Ex::XSelf))]), &crate::lower::node_::keyed::hosted_passed(wx_p0)), &Array::from(vec![crate::lower::model::Ex::XCx]));
            let built_ph = crate::lower::expr::try_of(&crate::lower::model::Ex::XCall(Text::from(format!("{}::build", &whole_p9.node_.name)), append(&Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("path")), crate::lower::model::Ex::XVar(Text::lit("value"))]), &tail_pg)));
            let kept_pi = crate::lower::model::Do::DoAssign(crate::lower::model::Ex::XDeref(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), live_pe.clone())), Text::lit("borrow_mut"), Array::new()))), crate::lower::model::Ex::XCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("row"))), Text::lit("result_dynamic"), Array::new())])));
            let marked_pj = crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_snap", &result_pd)))), Text::lit("mark"), Array::from(vec![crate::lower::model::Ex::XCx])));
            let select_pk = crate::lower::model::Ex::XBlock(Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(Text::lit("row")), built_ph.clone()), kept_pi.clone(), marked_pj.clone()]), Rc::new(crate::lower::model::Ex::XVar(Text::lit("row"))));
            let current_pl = crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", &live_pe)))), Text::lit("borrow"), Array::new())))), Text::lit("expect"), Array::from(vec![crate::lower::model::Ex::XStr(Text::lit("a `rebuild` has a generation from its build on"))]));
            let wx2_pm = {
                let mut this: crate::lower::node_::Wx = whole_p9.parent.clone();
                this.gens = push(&this.gens, &crate::lower::model::GenDef { name: name_p6.clone(), pos: pos_p7.clone(), at: crate::lower::node_::finish::place_at(wx_p0, &Text::lit("self"), pos_p7), source: src_ex_p3.clone(), value_ty: vt_p5.clone(), select: select_pk.clone(), transparent: false, width: Nat::from(0u32), moved: or(&crate::lower::node_::finish::hosted_rows(wx_p0), &Text::lit("")) });
                this.gen_holds = push(&this.gen_holds, &(name_p6.clone(), reads_p4.clone()));
                this.rows = append(&push(&this.rows, &whole_p9.node_), &whole_p9.node_.children);
                this.taken = append(&this.taken, &Array::from(vec![result_pd.clone(), live_pe.clone(), Text::from(format!("{}_now", &result_pd)), Text::from(format!("{}_snap", &result_pd)), Text::from(format!("{}_publish", &result_pd)), Text::from(format!("{}_moved", &result_pd))]));
                this.fields = append(&this.fields, &Array::from(vec![(live_pe.clone(), crate::lower::model::OutTy::OutCell(Rc::new(crate::lower::model::OutTy::OutOpt(Rc::new(dyn_ty_pc.clone())))), Text::lit("the current generation\'s result, which the snapshot of the `rebuild`\'s dynamic is taken from")), (Text::from(format!("{}_snap", &result_pd)), crate::lower::model::OutTy::OutSnapshot(Rc::new(dyn_ty_pc.clone())), Text::from(format!("the `rebuild` at place {}\'s dynamic, structural: its snapshots, the generations\' results and the lagged dynamic (pick ST)", &crate::lower::model::place_text(pos_p7))))]));
                this.moves = push(&this.moves, &(live_pe.clone(), crate::lower::model::Ex::XCall(Text::lit("RefCell::new"), Array::from(vec![crate::lower::model::Ex::XNone]))));
                this.inits = push(&this.inits, &(Text::from(format!("{}_snap", &result_pd)), crate::lower::model::Ex::XCall(Text::lit("Snapshot::new"), Array::from(vec![crate::lower::model::Ex::XStr(what_pf.clone())]))));
                this.getters = append(&this.getters, &Array::from(vec![crate::lower::model::MethDef { name: Text::from(format!("{}_now", &result_pd)), recv: crate::lower::model::Recv::RecvRef, params: Array::new(), cx_: crate::lower::model::CxArg::CxRef, ret: dyn_ty_pc.clone(), body: Array::new(), tail: current_pl.clone(), doc: Text::lit("The current generation\'s result: what the snapshot of the `rebuild`\'s dynamic is taken from (pick ST).") }, crate::lower::node_::static_::snap_getter(&result_pd, &dyn_ty_pc, &Text::lit("The `rebuild`\'s dynamic, its generation\'s result, a structural dynamic (pick ST): one tick behind the generations, the snapshot of the tick before the tick the read point is after."))]));
                this.snaps = push(&this.snaps, &crate::lower::node_::SnapDef { name: result_pd.clone(), live: Text::from(format!("{}_now", &result_pd)), ty: dyn_ty_pc.clone(), eq: false, builder: name_p6.clone(), before: false, what: what_pf.clone() });
                this
            };
            (wx2_pm.clone(), crate::lower::node_::Wres::WrDyn(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XSelf), result_pd.clone(), Array::from(vec![crate::lower::model::Ex::XCx])), Array::from(vec![crate::lower::node_::Read::OwnRead(result_pd.clone())]), dyn_ty_pc.clone()))
        },
    }
}

/// ```prism
/// ClauseWidgetLine: unbounded fn Wx, Env, Expr, Block, Text, ValInfo, Expr -> ((Wx, Wres))
/// ```
pub fn clause_widget_line(wx_p0: &crate::lower::node_::Wx, menv_p1: &crate::lower::types::Env, scrut_p2: &crate::syntax::Expr, call_p3: &crate::syntax::Block, qk_p4: &Text, v_p5: &crate::check::env::ValInfo, e_p6: &crate::syntax::Expr) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    let lx_p7 = wx_p0.lx.clone();
    let pos_p8 = wx_p0.pos.clone();
    let (src_ex_pe, reads_pf) = crate::lower::node_::dynamics::dynamic_expr(wx_p0, menv_p1, scrut_p2);
    let vt_p9 = crate::lower::types::out_ty_of(&lx_p7, &crate::lower::types::peel(&crate::lower::type_at(&lx_p7, &scrut_p2.span)));
    let (name_pg, wx1_ph) = crate::lower::node_::fresh_name(wx_p0, &Text::lit("generation"));
    let (up_id_pi, wx2_pj) = crate::lower::node_::add_gn(&wx1_ph, &Text::from(format!("{}_fired", &name_pg)), &crate::lower::types::out_ty_of(&lx_p7, &crate::lower::types::out_of(&crate::lower::type_at(&lx_p7, &e_p6.span))), &crate::lower::node_::GnKind::GnNamed, &Nat::from(0u32));
    let clauses_pa = crate::lower::jobs::clauses_of(&lx_p7.g, qk_p4);
    let row_name_pb = Text::from(format!("{}Gen{}", &wx_p0.node_, &crate::lower::node_::keyed::row_suffix(wx_p0)));
    let (rows_pp, wx3_pq) = run_to_end(fold_job(crate::check::errors::range0(&len(&clauses_pa)), (Array::new(), wx2_pj.clone()), {
        let clauses_pa = clauses_pa.clone();
        let menv_p1 = menv_p1.clone();
        let v_p5 = v_p5.clone();
        let row_name_pb = row_name_pb.clone();
        let name_pg = name_pg.clone();
        Rc::new(move |(p0, p1): ((Array<ClauseRow>, crate::lower::node_::Wx), Nat)| {
            let clauses_pa = clauses_pa.clone();
            let menv_p1 = menv_p1.clone();
            let v_p5 = v_p5.clone();
            let row_name_pb = row_name_pb.clone();
            let name_pg = name_pg.clone();
            entered(once_job(move || {
                let (acc_pk, w_pl) = p0;
                let i_pm = p1;
                {
                    let c_pn = or(&index(&clauses_pa, &i_pm), &crate::lower::functions::dummy_clause());
                    let cr_po = clause_row_of(&w_pl, &menv_p1, &c_pn, &v_p5, &Text::from(format!("{}{}", &row_name_pb, &i_pm)), &name_pg, &true);
                    prism_rtl::Turn::Finished((push(&acc_pk, &cr_po), cr_po.parent.clone()))
                }
            }))
        }) as Rc<dyn Fn(((Array<ClauseRow>, crate::lower::node_::Wx), Nat)) -> Rc<dyn prism_rtl::Job<(Array<ClauseRow>, crate::lower::node_::Wx)>>>
    }));
    let width_pc = fold(&rows_pp, &Nat::from(0u32), &(|acc_pr: &Nat, cr_ps: &ClauseRow| max(acc_pr, &cr_ps.width)));
    let cases_pd = each(&rows_pp, &(|cr_pt: &ClauseRow| cr_pt.case.clone()));
    if is_hosted_scope(wx_p0) {
        {
            let wx4_pu = {
                let mut this: crate::lower::node_::Wx = wx3_pq.clone();
                this.build = push(&this.build, &crate::lower::expr::refusal_do(&Text::lit("a widget of several clauses in a static position of a hosted scope")));
                this
            };
            (wx4_pu.clone(), crate::lower::node_::Wres::WrUnit)
        }
    } else {
        {
            let select_pv = gen_select(&wx3_pq, menv_p1, call_p3, &cases_pd, &pos_p8);
            let wx4_p10 = {
                let mut this: crate::lower::node_::Wx = wx3_pq.clone();
                this.pos = crate::lower::model::Pos_ { scope: pos_p8.scope.clone(), at: &pos_p8.at + &width_pc };
                this.gens = push(&this.gens, &crate::lower::model::GenDef { name: name_pg.clone(), pos: pos_p8.clone(), at: crate::lower::node_::finish::place_at(wx_p0, &Text::lit("self"), &pos_p8), source: src_ex_pe.clone(), value_ty: vt_p9.clone(), select: select_pv.clone(), transparent: true, width: width_pc.clone(), moved: or(&crate::lower::node_::finish::hosted_rows(wx_p0), &Text::lit("")) });
                this.gen_holds = push(&this.gen_holds, &(name_pg.clone(), reads_pf.clone()));
                this.rows = fold(&cases_pd, &this.rows, &(|acc_p11: &Array<crate::lower::model::NodeDef>, gc_p12: &GenCase| append(&push(acc_p11, &gc_p12.node_), &gc_p12.node_.children)));
                this.getters = push(&this.getters, &gen_up(&name_pg, &crate::lower::node_::gn_of(&wx3_pq, &up_id_pi).name, &crate::lower::node_::gn_of(&wx3_pq, &up_id_pi).ty));
                this
            };
            (wx4_p10.clone(), crate::lower::node_::Wres::WrEv(crate::lower::node_::ev_ref_of(&wx4_p10, &up_id_pi)))
        }
    }
}

/// ```prism
/// IsHostedScope: fn Wx -> Bool
/// ```
pub fn is_hosted_scope(wx_p0: &crate::lower::node_::Wx) -> bool {
    (&wx_p0.pos.scope > &Nat::from(0u32)) || is_some_(&wx_p0.hosted_by)
}

/// ```prism
/// IsSome: fn ?a -> Bool
/// ```
pub fn is_some_<A: Clone + 'static>(opt0: &Option<A>) -> bool {
    match opt0 {
        Some(_) => true,
        None => false,
    }
}

/// ```prism
/// GenCases: unbounded fn Wx, Env, Block, OutTy, Text -> (([GenCase], Wx))
/// ```
pub fn gen_cases(wx_p0: &crate::lower::node_::Wx, menv_p1: &crate::lower::types::Env, body_p2: &crate::syntax::Block, vt_p3: &crate::lower::model::OutTy, name_p4: &Text) -> (Array<GenCase>, crate::lower::node_::Wx) {
    let lx_p5 = wx_p0.lx.clone();
    let row_name_p6 = Text::from(format!("{}Gen{}", &wx_p0.node_, &crate::lower::node_::keyed::row_suffix(wx_p0)));
    match clause_call(&lx_p5, body_p2) {
        Some((qk_p7, args_p8)) => {
            let clauses_p9 = crate::lower::jobs::clauses_of(&lx_p5.g, &qk_p7);
            let v_pa = crate::lower::program::val_of(&lx_p5, &qk_p7);
            run_to_end(fold_job(crate::check::errors::range0(&len(&clauses_p9)), (Array::new(), wx_p0.clone()), {
                let clauses_p9 = clauses_p9.clone();
                let menv_p1 = menv_p1.clone();
                let v_pa = v_pa.clone();
                let row_name_p6 = row_name_p6.clone();
                let name_p4 = name_p4.clone();
                Rc::new(move |(p0, p1): ((Array<GenCase>, crate::lower::node_::Wx), Nat)| {
                    let clauses_p9 = clauses_p9.clone();
                    let menv_p1 = menv_p1.clone();
                    let v_pa = v_pa.clone();
                    let row_name_p6 = row_name_p6.clone();
                    let name_p4 = name_p4.clone();
                    entered(once_job(move || {
                        let (acc_pb, w_pc) = p0;
                        let i_pd = p1;
                        {
                            let c_pe = or(&index(&clauses_p9, &i_pd), &crate::lower::functions::dummy_clause());
                            let cr_pf = clause_row_of(&w_pc, &menv_p1, &c_pe, &v_pa, &Text::from(format!("{}{}", &row_name_p6, &i_pd)), &name_p4, &false);
                            prism_rtl::Turn::Finished((push(&acc_pb, &cr_pf.case), cr_pf.parent.clone()))
                        }
                    }))
                }) as Rc<dyn Fn(((Array<GenCase>, crate::lower::node_::Wx), Nat)) -> Rc<dyn prism_rtl::Job<(Array<GenCase>, crate::lower::node_::Wx)>>>
            }))
        },
        None => {
            let whole_pg = gen_row_of(wx_p0, menv_p1, body_p2, vt_p3, &row_name_p6, name_p4);
            (Array::from(vec![GenCase { node_: whole_pg.node_.clone(), params: Array::from(vec![(Text::lit("value"), vt_p3.clone())]), pat: crate::lower::model::Pa::PaWild, conds: Array::new(), passed: Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("value"))]) }]), whole_pg.parent.clone())
        },
    }
}

/// ```prism
/// ?ClauseCall: fn Lx, Block -> ?((Text, [Arg]))
/// ```
pub fn clause_call(lx_p0: &crate::lower::Lx, body_p1: &crate::syntax::Block) -> Option<(Text, Array<crate::syntax::Arg>)> {
    'm13740: {
        let scrutinee = &body_p1.stmts;
        if let m13740_0 = scrutinee && (m13740_0.len() == 1) && let Some(st_p2) = index(m13740_0, &Nat::from(0u32)) {
            break 'm13740 match &st_p2.kind {
                crate::syntax::StmtKind::SExpr(x_p3) => clause_call_x(lx_p0, x_p3),
                crate::syntax::StmtKind::SIgnore(x_p4) => clause_call_x(lx_p0, x_p4),
                _ => None,
            };
        }
        None
    }
}

/// ```prism
/// ?ClauseCallX: fn Lx, Expr -> ?((Text, [Arg]))
/// ```
pub fn clause_call_x(lx_p0: &crate::lower::Lx, x_p1: &crate::syntax::Expr) -> Option<(Text, Array<crate::syntax::Arg>)> {
    match &*x_p1.kind {
        crate::syntax::ExprKind::ECall(c_p2, args_p3, _, _) => {
            let qk_p4 = crate::lower::program::blueprint_qk(lx_p0, &**c_p2);
            if &len(&crate::lower::jobs::clauses_of(&lx_p0.g, &qk_p4)) > &Nat::from(1u32) {
                Some((qk_p4.clone(), args_p3.clone()))
            } else {
                None
            }
        },
        _ => None,
    }
}

/// ```prism
/// ClauseRowOf: unbounded fn Wx, Env, FnClause, ValInfo, Text, Text, Bool -> ClauseRow
/// ```
pub fn clause_row_of(wx_p0: &crate::lower::node_::Wx, menv_p1: &crate::lower::types::Env, c_p2: &crate::syntax::decls::FnClause, v_p3: &crate::check::env::ValInfo, row_name_p4: &Text, gen_name_p5: &Text, transparent_p6: &bool) -> ClauseRow {
    let up_name_p7 = Text::from(format!("{}_up", gen_name_p5));
    let lx_p8 = wx_p0.lx.clone();
    let lxc_p9 = crate::lower::program::in_module_at(&lx_p8, &v_p3.file, &v_p3.home, &lx_p8.site);
    let ptys_pa = match &v_p3.scheme.ty {
        crate::check::types::Ty::TyFn(_, ps_pr, _) => ps_pr.clone(),
        _ => Array::new(),
    };
    let pos_pb = run_to_end(each_job(crate::check::errors::range0(&len(&c_p2.params)), {
        let lxc_p9 = lxc_p9.clone();
        let c_p2 = c_p2.clone();
        let ptys_pa = ptys_pa.clone();
        Rc::new(move |p0: Nat| {
            let lxc_p9 = lxc_p9.clone();
            let c_p2 = c_p2.clone();
            let ptys_pa = ptys_pa.clone();
            entered(once_job(move || {
                let i_ps = p0;
                prism_rtl::Turn::More(Rc::new(crate::lower::patterns::RustPat { lx_p0: lxc_p9.clone(), p_p1: or(&index(&c_p2.params, &i_ps), &crate::lower::patterns::dummy_pat()), ty_p2: or(&index(&ptys_pa, &i_ps), &crate::check::types::Ty::TyErr), mode_p3: crate::lower::types::Holding::ByRef, fresh_p4: Text::from(format!("c{}", &i_ps)) }))
            }))
        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<crate::lower::patterns::PatOut>>>
    }));
    let pa_pc = crate::lower::model::Pa::PaTuple(each(&pos_pb, &(|o_pt: &crate::lower::patterns::PatOut| o_pt.pa.clone())));
    let binds_pd = fold(&pos_pb, &Map::new(), &(|m_pu: &Map<Text, crate::lower::types::Bn>, o_pv: &crate::lower::patterns::PatOut| fold(&o_pv.binds, m_pu, &(|m2_p10: &Map<Text, crate::lower::types::Bn>, (n_p11, b_p12): &(Text, crate::lower::types::Bn)| insert(m2_p10, n_p11, b_p12)))));
    let binders_pe = filter(&run_to_end(fold_job(c_p2.params.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<(Text, crate::syntax::Range)>, crate::syntax::Pattern_)| entered(once_job(move || {
        let acc_p13 = p0;
        let p_p14 = p1;
        call_then(crate::check::env::names::start_pattern_binders(p_p14.clone()), move |pattern_binders_15253: Array<(Text, crate::syntax::Range)>| prism_rtl::Turn::Finished(append(&acc_p13, &pattern_binders_15253)))
    }))) as Rc<dyn Fn((Array<(Text, crate::syntax::Range)>, crate::syntax::Pattern_)) -> Rc<dyn prism_rtl::Job<Array<(Text, crate::syntax::Range)>>>>)), &(|(bn_p15, _): &(Text, crate::syntax::Range)| crate::check::env::has_key(&binds_pd, bn_p15)));
    let fields_pf = run_to_end(each_job(binders_pe.clone(), {
        let lxc_p9 = lxc_p9.clone();
        Rc::new(move |p0: (Text, crate::syntax::Range)| {
            let lxc_p9 = lxc_p9.clone();
            entered(once_job(move || {
                let (bn_p16, r_p17) = p0;
                call_then(crate::lower::types::start_out_ty_of(lxc_p9.clone(), crate::lower::types::peel(&crate::lower::binder_ty(&lxc_p9, &r_p17))), move |out_ty_of_15367: crate::lower::model::OutTy| prism_rtl::Turn::Finished((crate::lower::snake(&bn_p16), out_ty_of_15367, bn_p16.clone())))
            }))
        }) as Rc<dyn Fn((Text, crate::syntax::Range)) -> Rc<dyn prism_rtl::Job<(Text, crate::lower::model::OutTy, Text)>>>
    }));
    let row_fields_pg = push(&each(&fields_pf, &(|(f_p18, t_p19, bn_p1a): &(Text, crate::lower::model::OutTy, Text)| (f_p18.clone(), t_p19.clone(), Text::from(format!("`{}`", bn_p1a))))), &(Text::lit("parent"), crate::lower::model::OutTy::OutWeak(wx_p0.node_.clone()), Text::lit("the node of the `rebuild`")));
    let row_inits_ph = each(&fields_pf, &(|(f_p1b, _, _): &(Text, crate::lower::model::OutTy, Text)| (f_p1b.clone(), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(f_p1b.clone()))))));
    let row_taken_pi = append(&crate::lower::node_::node_hooks(), &push(&each(&fields_pf, &(|(f_p1c, _, _): &(Text, crate::lower::model::OutTy, Text)| f_p1c.clone())), &Text::lit("parent")));
    let r00_pj = crate::lower::node_::new_wx(&lxc_p9, row_name_p4, &row_fields_pg, &row_inits_ph, &Array::from(vec![(Text::lit("parent"), crate::lower::model::Ex::XVar(Text::lit("parent")))]), &Array::new(), &Map::new(), &row_taken_pi, &wx_p0.inlining, &crate::lower::node_::finish::hosted_rows(wx_p0));
    let r0_pk = if *transparent_p6 {
        {
            let mut this: crate::lower::node_::Wx = r00_pj.clone();
            this.pos = wx_p0.pos.clone();
            this
        }
    } else {
        r00_pj.clone()
    };
    let body_pl = match &c_p2.body {
        crate::syntax::decls::FnBody::BodyBlock(b_p1d) => b_p1d.clone(),
        crate::syntax::decls::FnBody::BodyExpr(x_p1e) => crate::syntax::Block { stmts: Array::from(vec![crate::syntax::Stmt { kind: crate::syntax::StmtKind::SExpr(x_p1e.clone()), span: x_p1e.span.clone() }]), inline: true, span: x_p1e.span.clone() },
    };
    let (p1_p1f, r1_p1g, ports_p1h) = row_env(wx_p0, &r0_pk, menv_p1, &body_pl);
    let (be_p1n, me_p1o) = fold(&fields_pf, &(crate::lower::types::empty_env(), crate::lower::types::empty_env()), &(|(b_p1i, m_p1j): &(crate::lower::types::Env, crate::lower::types::Env), (f_p1k, t_p1l, bn_p1m): &(Text, crate::lower::model::OutTy, Text)| crate::lower::node_::bind_plain(b_p1i, m_p1j, bn_p1m, f_p1k, t_p1l)));
    let r2_pm = crate::lower::node_::def::block_into(&r1_p1g, &be_p1n, &me_p1o, &body_pl);
    let r3_pn = match &r2_pm.result {
        crate::lower::node_::Wres::WrEv(r_p1p) => crate::lower::node_::connect(&r2_pm, r_p1p, &crate::lower::node_::Sk::SkUp(up_name_p7.clone())),
        crate::lower::node_::Wres::WrParts(_) => {
            let mut this: crate::lower::node_::Wx = r2_pm.clone();
            this.build = push(&this.build, &crate::lower::expr::refusal_do(&Text::lit("a widget of several clauses whose clause ends on a bundle")));
            this
        },
        _ => r2_pm.clone(),
    };
    let node_po = crate::lower::node_::finish::finish_node(&r3_pn, row_name_p4, &append(&push(&each(&fields_pf, &(|(f_p1q, t_p1r, _): &(Text, crate::lower::model::OutTy, Text)| (f_p1q.clone(), t_p1r.clone()))), &(Text::lit("parent"), crate::lower::model::OutTy::OutWeak(wx_p0.node_.clone()))), &crate::lower::node_::keyed::hosted_params(wx_p0)), &true);
    let p2_pp = gen_marked(&p1_p1f, gen_name_p5, &r3_pn);
    let passed_pq = each(&fields_pf, &(|(f_p1s, t_p1t, bn_p1u): &(Text, crate::lower::model::OutTy, Text)| match get(&binds_pd, bn_p1u) {
        Some(crate::lower::types::Bn::BnLocal(rs_p1v, mode_p20, bt_p21)) => crate::lower::types::own(&crate::lower::types::Vl::VlPlace(rs_p1v, mode_p20, bt_p21)),
        _ => crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(f_p1s.clone()))),
    }));
    ClauseRow { case: GenCase { node_: node_po.clone(), params: each(&fields_pf, &(|(f_p22, t_p23, _): &(Text, crate::lower::model::OutTy, Text)| (f_p22.clone(), t_p23.clone()))), pat: pa_pc.clone(), conds: fold(&pos_pb, &Array::new(), &(|acc_p24: &Array<crate::lower::model::Cc>, o_p25: &crate::lower::patterns::PatOut| append(acc_p24, &o_p25.conds))), passed: passed_pq.clone() }, parent: p2_pp.clone(), width: or(&(&r2_pm.pos.at).checked_sub(&r0_pk.pos.at), &Nat::from(0u32)) }
}

/// ```prism
/// GenRowOf: unbounded fn Wx, Env, Block, OutTy, Text, Text -> GenRow
/// ```
pub fn gen_row_of(wx_p0: &crate::lower::node_::Wx, menv_p1: &crate::lower::types::Env, body_p2: &crate::syntax::Block, vt_p3: &crate::lower::model::OutTy, row_name_p4: &Text, gen_name_p5: &Text) -> GenRow {
    let lx_p6 = wx_p0.lx.clone();
    let up_name_p7 = Text::from(format!("{}_up", gen_name_p5));
    let r0_p8 = crate::lower::node_::new_wx(&lx_p6, row_name_p4, &Array::from(vec![(Text::lit("value"), vt_p3.clone(), Text::lit("the generation\'s value, `_`")), (Text::lit("parent"), crate::lower::model::OutTy::OutWeak(wx_p0.node_.clone()), Text::lit("the node of the `rebuild`"))]), &Array::from(vec![(Text::lit("value"), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(Text::lit("value")))))]), &Array::from(vec![(Text::lit("parent"), crate::lower::model::Ex::XVar(Text::lit("parent")))]), &Array::new(), &Map::new(), &append(&crate::lower::node_::node_hooks(), &Array::from(vec![Text::lit("value"), Text::lit("parent"), Text::lit("result"), Text::lit("result_dynamic")])), &wx_p0.inlining, &crate::lower::node_::finish::hosted_rows(wx_p0));
    let (p1_pc, r1_pd, ports_pe) = row_env(wx_p0, &r0_p8, menv_p1, body_p2);
    let be_p9 = crate::lower::types::bind(&build_spelling(&ports_pe), &Text::lit("_"), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(Text::lit("value")), crate::lower::types::Holding::Owned, vt_p3.clone()));
    let me_pa = crate::lower::types::bind(&ports_pe, &Text::lit("_"), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::lit("value")), crate::lower::types::Holding::Owned, vt_p3.clone()));
    let r2_pb = crate::lower::node_::def::block_into(&r1_pd, &be_p9, &me_pa, body_p2);
    let (r3_pk, dyn_result_ol) = match &r2_pb.result {
        crate::lower::node_::Wres::WrEv(r_pf) => (crate::lower::node_::connect(&r2_pb, r_pf, &crate::lower::node_::Sk::SkUp(up_name_p7.clone())), None),
        crate::lower::node_::Wres::WrDyn(ex_pg, result_reads_ph, rt_pi) => (gen_result(&r2_pb, gen_name_p5, ex_pg, result_reads_ph, rt_pi), Some(rt_pi.clone())),
        crate::lower::node_::Wres::WrParts(_) => {
            let r2b_pj = {
                let mut this: crate::lower::node_::Wx = r2_pb.clone();
                this.build = push(&this.build, &crate::lower::expr::refusal_do(&Text::lit("a `rebuild` whose block ends on a bundle")));
                this
            };
            (r2b_pj.clone(), None)
        },
        _ => (r2_pb.clone(), None),
    };
    GenRow { node_: crate::lower::node_::finish::finish_node(&r3_pk, row_name_p4, &append(&Array::from(vec![(Text::lit("value"), vt_p3.clone()), (Text::lit("parent"), crate::lower::model::OutTy::OutWeak(wx_p0.node_.clone()))]), &crate::lower::node_::keyed::hosted_params(wx_p0)), &true), parent: gen_marked(&p1_pc, gen_name_p5, &r3_pk), dyn_result: dyn_result_ol.clone() }
}

/// ```prism
/// GenResult: fn Wx, Text, Ex, [Read], OutTy -> Wx
/// ```
pub fn gen_result(r_p0: &crate::lower::node_::Wx, gen_name_p1: &Text, ex_p2: &crate::lower::model::Ex, result_reads_p3: &Array<crate::lower::node_::Read>, rt_p4: &crate::lower::model::OutTy) -> crate::lower::node_::Wx {
    let own_behind_p5 = filter(&crate::lower::node_::finish::reads_closed(&r_p0.dyn_reads, result_reads_p3), &(|rd_p8: &crate::lower::node_::Read| match rd_p8 {
        crate::lower::node_::Read::OwnRead(_) => true,
        crate::lower::node_::Read::ParentRead(_) => false,
    }));
    let made_p6 = crate::lower::model::Ex::XCall(Text::lit("Dynamic::of"), Array::from(vec![crate::lower::model::Ex::XClosure(true, Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("cx"))]), Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("me"))), Text::lit("result"), Array::from(vec![crate::lower::model::Ex::XCx])))), crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XCall(Text::lit("Rc::new"), Array::from(vec![crate::lower::model::Ex::XCall(Text::lit("Port::new"), Array::new())]))))]));
    let doc_p7 = Text::from(format!("The generation\'s result as a dynamic, which the block keeps while the generation is current; the block hears it move through `{}_result_moved`, not through the dynamic\'s port.", gen_name_p1));
    let mut this: crate::lower::node_::Wx = r_p0.clone();
    this.getters = append(&this.getters, &Array::from(vec![crate::lower::model::MethDef { name: Text::lit("result"), recv: crate::lower::model::Recv::RecvRef, params: Array::new(), cx_: crate::lower::model::CxArg::CxRef, ret: rt_p4.clone(), body: Array::new(), tail: ex_p2.clone(), doc: Text::lit("The generation\'s result, which the `rebuild` hands back.") }, crate::lower::model::MethDef { name: Text::lit("result_dynamic"), recv: crate::lower::model::Recv::RecvRc, params: Array::new(), cx_: crate::lower::model::CxArg::CxNone, ret: crate::lower::model::OutTy::OutDyn(Rc::new(rt_p4.clone())), body: Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(Text::lit("me")), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XSelf)))]), tail: made_p6.clone(), doc: doc_p7.clone() }]));
    this.result_moved = if &len(&own_behind_p5) > &Nat::from(0u32) {
        Some((Text::from(format!("{}_result_moved", gen_name_p1)), own_behind_p5.clone()))
    } else {
        None
    };
    this
}

/// ```prism
/// GenMarked: fn Wx, Text, Wx -> Wx
/// ```
pub fn gen_marked(parent_p0: &crate::lower::node_::Wx, gen_name_p1: &Text, row_wx_p2: &crate::lower::node_::Wx) -> crate::lower::node_::Wx {
    let reads_p3 = crate::lower::node_::keyed::row_place_reads(row_wx_p2);
    if &len(&reads_p3) == &Nat::from(0u32) {
        parent_p0.clone()
    } else {
        {
            let mut this: crate::lower::node_::Wx = parent_p0.clone();
            this.row_marks = push(&this.row_marks, &crate::lower::node_::RowMarks { builder: gen_name_p1.clone(), reads: reads_p3.clone(), wrote: Array::new(), kind: crate::lower::model::RowKind::GenerationRow });
            this
        }
    }
}

/// ```prism
/// BuildSpelling: fn Env -> Env
/// ```
pub fn build_spelling(env_p0: &crate::lower::types::Env) -> crate::lower::types::Env {
    fold(&keys(&env_p0.names), env_p0, &(|en_p1: &crate::lower::types::Env, k_p2: &Text| match get(&env_p0.names, k_p2) {
        Some(crate::lower::types::Bn::BnLocal(rs_p3, mode_p4, t_p5)) => match crate::lower::types::through_parent(&rs_p3) {
            Some(x_p6) => crate::lower::types::bind(en_p1, k_p2, &crate::lower::types::Bn::BnLocal(x_p6, mode_p4, t_p5)),
            None => en_p1.clone(),
        },
        Some(crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(rs_p7, m_p8, xs_p9), ds_pa, t_pb)) => match crate::lower::types::through_parent(&*rs_p7) {
            Some(x_pc) => crate::lower::types::bind(en_p1, k_p2, &crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(Rc::new(x_pc), m_p8, xs_p9), ds_pa, t_pb)),
            None => en_p1.clone(),
        },
        _ => en_p1.clone(),
    }))
}

/// ```prism
/// GenSelect: unbounded fn Wx, Env, Block, [GenCase], Pos -> Ex
/// ```
pub fn gen_select(wx_p0: &crate::lower::node_::Wx, menv_p1: &crate::lower::types::Env, body_p2: &crate::syntax::Block, cases_p3: &Array<GenCase>, pos_p4: &crate::lower::model::Pos_) -> crate::lower::model::Ex {
    let tail_p5 = append(&append(&Array::from(vec![crate::lower::model::Ex::XWeak(Rc::new(crate::lower::model::Ex::XSelf))]), &crate::lower::node_::keyed::hosted_passed(wx_p0)), &Array::from(vec![crate::lower::model::Ex::XCx]));
    match clause_call(&wx_p0.lx, body_p2) {
        None => match index(cases_p3, &Nat::from(0u32)) {
            Some(c_p6) => crate::lower::expr::try_of(&crate::lower::model::Ex::XCall(Text::from(format!("{}::build", &c_p6.node_.name)), append(&Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("path")), crate::lower::model::Ex::XVar(Text::lit("value"))]), &tail_p5))),
            None => crate::lower::expr::refusal(&Text::lit("a `rebuild` with no generation")),
        },
        Some((qk_p7, args_p8)) => {
            let env_p9 = crate::lower::types::bind(menv_p1, &Text::lit("_"), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(Text::lit("value")), crate::lower::types::Holding::Owned, crate::lower::model::OutTy::OutUnit));
            let scrut_pa = crate::lower::model::Ex::XTuple(run_to_end(each_job(args_p8.clone(), {
                let wx_p0 = wx_p0.clone();
                let env_p9 = env_p9.clone();
                Rc::new(move |p0: crate::syntax::Arg| {
                    let wx_p0 = wx_p0.clone();
                    let env_p9 = env_p9.clone();
                    entered(once_job(move || {
                        let a_pc = p0;
                        prism_rtl::Turn::More(Rc::new(crate::lower::expr::Argument { lx_p0: wx_p0.lx.clone(), env_p1: env_p9.clone(), e_p2: a_pc.value.clone() }))
                    }))
                }) as Rc<dyn Fn(crate::syntax::Arg) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
            })));
            let arms_pb = each(cases_p3, &(|c_pd: &GenCase| {
                let made_pe = crate::lower::expr::try_of(&crate::lower::model::Ex::XCall(Text::from(format!("{}::build", &c_pd.node_.name)), append(&append(&Array::from(vec![crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(Text::lit("path"))))]), &c_pd.passed), &tail_p5)));
                crate::lower::model::XArm { pat: c_pd.pat.clone(), conds: c_pd.conds.clone(), body: crate::lower::model::Ex::XCast(Rc::new(made_pe.clone()), crate::lower::model::OutTy::OutObj(Rc::new(crate::lower::model::OutTy::OutNamed(Text::lit("Row"), Array::new())))) }
            }));
            crate::lower::types::own(&crate::lower::expr::arms_value(&scrut_pa, &arms_pb, &Text::lit("\'select"), &crate::lower::model::OutTy::OutObj(Rc::new(crate::lower::model::OutTy::OutNamed(Text::lit("Row"), Array::new())))))
        },
    }
}

/// ```prism
/// GenUp: fn Text, Text, OutTy -> MethDef
/// ```
pub fn gen_up(name_p0: &Text, up_name_p1: &Text, t_p2: &crate::lower::model::OutTy) -> crate::lower::model::MethDef {
    crate::lower::model::MethDef { name: Text::from(format!("{}_up", name_p0)), recv: crate::lower::model::Recv::RecvRc, params: Array::from(vec![(Text::lit("v"), t_p2.clone())]), cx_: crate::lower::model::CxArg::CxMut, ret: crate::lower::model::OutTy::OutUnit, body: Array::from(vec![crate::lower::node_::finish::self_call(up_name_p1, &Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("v"))]))]), tail: crate::lower::model::Ex::XUnit, doc: Text::lit("The current generation\'s result fires the `rebuild`\'s.") }
}

/// ```prism
/// GenForwards: fn GenDef -> [((Pa, Ex))]
/// ```
pub fn gen_forwards(gd_p0: &crate::lower::model::GenDef) -> Array<(crate::lower::model::Pa, crate::lower::model::Ex)> {
    if gd_p0.transparent {
        each(&crate::check::errors::range0(&gd_p0.width), &(|i_p1: &Nat| {
            let current_p2 = crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", &gd_p0.name)))), Text::lit("borrow"), Array::new())));
            let body_p3 = crate::lower::model::Ex::XBlock(Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(Text::lit("row")), current_p2.clone()), crate::lower::model::Do::DoIfLet(crate::lower::model::Pa::PaCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("row"))])), crate::lower::model::Ex::XVar(Text::lit("row")), Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::expr::try_of(&crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("row"))), Text::lit("answer"), Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("at")), crate::lower::model::Ex::XVar(Text::lit("v")), crate::lower::model::Ex::XCx]))))]), Array::new())]), Rc::new(crate::lower::model::Ex::XUnit));
            (crate::lower::node_::finish::pos_pat(&crate::lower::model::Pos_ { scope: gd_p0.pos.scope.clone(), at: &gd_p0.pos.at + i_p1 }, &Array::from(vec![crate::lower::model::Pa::PaRest(Text::lit(""))])), body_p3.clone())
        }))
    } else {
        Array::from(vec![(crate::lower::node_::finish::pos_pat(&gd_p0.pos, &crate::lower::node_::finish::gen_tail()), forward_gen(gd_p0))])
    }
}

/// ```prism
/// ForwardGen: fn GenDef -> Ex
/// ```
pub fn forward_gen(gd_p0: &crate::lower::model::GenDef) -> crate::lower::model::Ex {
    let current_p1 = crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", &gd_p0.name)))), Text::lit("borrow"), Array::new())));
    let is_current_p2 = crate::lower::model::Ex::XBin(Text::lit("=="), Rc::new(crate::lower::model::Ex::XBin(Text::lit("+"), Rc::new(crate::lower::model::Ex::XDeref(Rc::new(crate::lower::model::Ex::XVar(Text::lit("g"))))), Rc::new(crate::lower::model::Ex::XIndex(Nat::from(1u32))))), Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_count", &gd_p0.name)))), Text::lit("get"), Array::new())));
    crate::lower::model::Ex::XBlock(Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(Text::lit("row")), current_p1.clone()), crate::lower::model::Do::DoIfLet(crate::lower::model::Pa::PaCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("row"))])), crate::lower::model::Ex::XVar(Text::lit("row")), Array::from(vec![crate::lower::model::Do::DoIf(is_current_p2.clone(), Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::expr::try_of(&crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("row"))), Text::lit("answer"), Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("rest")), crate::lower::model::Ex::XVar(Text::lit("v")), crate::lower::model::Ex::XCx]))))]), Array::new())]), Array::new())]), Rc::new(crate::lower::model::Ex::XUnit))
}

/// ```prism
/// FlattenLine: unbounded fn Wx, Env, [Arg], ?Bn -> ((Wx, Wres))
/// ```
pub fn flatten_line(wx_p0: &crate::lower::node_::Wx, menv_p1: &crate::lower::types::Env, args_p2: &Array<crate::syntax::Arg>, bound_o3: &Option<crate::lower::types::Bn>) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    let named_o4 = match index(args_p2, &Nat::from(0u32)) {
        Some(a_p6) => match &*a_p6.value.kind {
            crate::syntax::ExprKind::EName(n_p7) => 'm24384: {
                let scrutinee = &get(&menv_p1.names, &crate::check::env::sname_key(n_p7));
                if let Some(crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(m24384_0_0_0, m_p8, _), _, crate::lower::model::OutTy::OutDyn(t_p9))) = scrutinee && let crate::lower::model::Ex::XSelf = &**m24384_0_0_0 {
                    break 'm24384 Some((m_p8.clone(), (**t_p9).clone()));
                }
                None
            },
            _ => None,
        },
        None => None,
    };
    let outer_o5 = match &named_o4 {
        Some((m_pa, t_pb)) => fold(&wx_p0.gens, &None, &(|acc_oc: &Option<(Text, Text, crate::lower::model::OutTy)>, gd_pd: &crate::lower::model::GenDef| if &Text::from(format!("{}_result", &gd_pd.name)) == m_pa {
            Some((m_pa.clone(), gd_pd.name.clone(), t_pb.clone()))
        } else {
            acc_oc.clone()
        })),
        None => None,
    };
    match &outer_o5 {
        None => {
            let wx2_pe = {
                let mut this: crate::lower::node_::Wx = wx_p0.clone();
                this.build = push(&this.build, &crate::lower::expr::refusal_do(&Text::lit("`@Flatten` of a dynamic that is not a `rebuild`\'s (a `for` over a map of dynamics binds the value under the key, `for k, $v <- $each:`, ruling FV)")));
                this
            };
            (wx2_pe.clone(), crate::lower::node_::Wres::WrUnit)
        },
        Some((m_pf, gen_pg, t_ph)) => {
            let (name_po, wx1_pp) = 'm25087: {
                if let Some(crate::lower::types::Bn::BnHold(f_pm, _)) = bound_o3 {
                    break 'm25087 (f_pm.clone(), wx_p0.clone());
                }
                if let Some(crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(m25087_1_0_0, f_pn, _), _, _)) = bound_o3 && let crate::lower::model::Ex::XSelf = &**m25087_1_0_0 {
                    break 'm25087 (f_pn.clone(), wx_p0.clone());
                }
                crate::lower::node_::fresh_name(wx_p0, &Text::lit("flatten"))
            };
            let inner_pi = Text::from(format!("{}_inner", &name_po));
            let first_pj = crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XVar(Text::lit("node"))), Text::from(format!("{}", &inner_pi)))), Text::lit("set"), Array::from(vec![crate::lower::model::Ex::XCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("node"))), m_pf.clone(), Array::from(vec![crate::lower::model::Ex::XCx]))])), crate::lower::model::Ex::XCx])));
            let sample_pk = crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", &inner_pi)))), Text::lit("get"), Array::from(vec![crate::lower::model::Ex::XCx]))), Text::lit("expect"), Array::from(vec![crate::lower::model::Ex::XStr(Text::lit("`@Flatten` adopts its first inner at the build"))]))), Text::lit("sample"), Array::from(vec![crate::lower::model::Ex::XCx]));
            let wx2_pl = {
                let mut this: crate::lower::node_::Wx = wx1_pp.clone();
                this.taken = append(&this.taken, &Array::from(vec![inner_pi.clone(), Text::from(format!("{}_adopt", &name_po))]));
                this.fields = push(&this.fields, &(inner_pi.clone(), crate::lower::model::OutTy::OutHold(Rc::new(crate::lower::model::OutTy::OutOpt(Rc::new(crate::lower::model::OutTy::OutDyn(Rc::new(t_ph.clone())))))), Text::lit("`@Flatten`\'s current inner: the dynamic of the generation it adopted")));
                this.moves = push(&this.moves, &(inner_pi.clone(), crate::lower::model::Ex::XCall(Text::lit("Hold::new"), Array::from(vec![crate::lower::model::Ex::XNone, crate::lower::model::Ex::XCx]))));
                this.build = push(&this.build, &first_pj);
                this.getters = push(&this.getters, &crate::lower::model::MethDef { name: name_po.clone(), recv: crate::lower::model::Recv::RecvRef, params: Array::new(), cx_: crate::lower::model::CxArg::CxRef, ret: t_ph.clone(), body: Array::new(), tail: sample_pk.clone(), doc: Text::lit("`@Flatten`\'s dynamic: its current inner at the read point.") });
                this.dyn_reads = insert(&this.dyn_reads, &name_po, &Array::from(vec![crate::lower::node_::Read::OwnRead(inner_pi.clone())]));
                this.flattens = push(&this.flattens, &crate::lower::node_::FlatDef { name: name_po.clone(), outer: m_pf.clone(), generation: gen_pg.clone(), ty: t_ph.clone() });
                this
            };
            (wx2_pl.clone(), crate::lower::node_::Wres::WrDyn(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XSelf), name_po.clone(), Array::from(vec![crate::lower::model::Ex::XCx])), Array::from(vec![crate::lower::node_::Read::OwnRead(inner_pi.clone())]), t_ph.clone()))
        },
    }
}

/// ```prism
/// EntryFlatten: unbounded fn Wx, OutTy, ?Bn -> ((Wx, Wres))
/// ```
pub fn entry_flatten(wx_p0: &crate::lower::node_::Wx, t_p1: &crate::lower::model::OutTy, bound_o2: &Option<crate::lower::types::Bn>) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    let (name_pa, wx1_pb) = 'm27624: {
        if let Some(crate::lower::types::Bn::BnHold(f_p8, _)) = bound_o2 {
            break 'm27624 (f_p8.clone(), wx_p0.clone());
        }
        if let Some(crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(m27624_1_0_0, f_p9, _), _, _)) = bound_o2 && let crate::lower::model::Ex::XSelf = &**m27624_1_0_0 {
            break 'm27624 (f_p9.clone(), wx_p0.clone());
        }
        crate::lower::node_::fresh_name(wx_p0, &Text::lit("flatten"))
    };
    let inner_p3 = Text::from(format!("{}_inner", &name_pa));
    let follow_p4 = Text::from(format!("{}_follow", &name_pa));
    let followed_p5 = crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XVar(Text::lit("node"))), follow_p4.clone())), Text::lit("follow"), Array::from(vec![crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("node"))), Text::lit("entry"), Array::from(vec![crate::lower::model::Ex::XCx]))), Text::lit("updates")))), crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XVar(Text::lit("node")))), crate::lower::model::Ex::XPath(Text::from(format!("{}::{}_moved", &wx_p0.node_, &name_pa)))])));
    let sample_p6 = crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", &inner_p3)))), Text::lit("get"), Array::from(vec![crate::lower::model::Ex::XCx]))), Text::lit("expect"), Array::from(vec![crate::lower::model::Ex::XStr(Text::lit("`@Flatten` adopts its first inner at the build"))]))), Text::lit("sample"), Array::from(vec![crate::lower::model::Ex::XCx]));
    let wx2_p7 = {
        let mut this: crate::lower::node_::Wx = wx1_pb.clone();
        this.taken = append(&this.taken, &Array::from(vec![inner_p3.clone(), follow_p4.clone(), Text::from(format!("{}_adopt", &name_pa)), Text::from(format!("{}_moved", &name_pa)), Text::from(format!("{}_replaced", &name_pa))]));
        this.fields = append(&this.fields, &Array::from(vec![(inner_p3.clone(), crate::lower::model::OutTy::OutHold(Rc::new(crate::lower::model::OutTy::OutOpt(Rc::new(crate::lower::model::OutTy::OutDyn(Rc::new(t_p1.clone())))))), Text::lit("`@Flatten`\'s current inner: the row\'s entry it adopted")), (follow_p4.clone(), crate::lower::model::OutTy::OutNamed(Text::lit("prism_rtl::Follow"), Array::new()), Text::lit("the subscription to the inner\'s update event"))]));
        this.moves = append(&this.moves, &Array::from(vec![(inner_p3.clone(), crate::lower::model::Ex::XCall(Text::lit("Hold::new"), Array::from(vec![crate::lower::model::Ex::XCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(Text::lit("value"))))])), crate::lower::model::Ex::XCx]))), (follow_p4.clone(), crate::lower::model::Ex::XCall(Text::lit("prism_rtl::Follow::new"), Array::new()))]));
        this.build = push(&this.build, &followed_p5);
        this.getters = push(&this.getters, &crate::lower::model::MethDef { name: name_pa.clone(), recv: crate::lower::model::Recv::RecvRef, params: Array::new(), cx_: crate::lower::model::CxArg::CxRef, ret: t_p1.clone(), body: Array::new(), tail: sample_p6.clone(), doc: Text::lit("`@Flatten`\'s dynamic: its current inner at the read point.") });
        this.dyn_reads = insert(&this.dyn_reads, &name_pa, &Array::from(vec![crate::lower::node_::Read::OwnRead(inner_p3.clone())]));
        this.flattens = push(&this.flattens, &crate::lower::node_::FlatDef { name: name_pa.clone(), outer: Text::lit("entry"), generation: Text::lit(""), ty: t_p1.clone() });
        this
    };
    (wx2_p7.clone(), crate::lower::node_::Wres::WrDyn(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XSelf), name_pa.clone(), Array::from(vec![crate::lower::model::Ex::XCx])), Array::from(vec![crate::lower::node_::Read::OwnRead(inner_p3.clone())]), t_p1.clone()))
}

/// ```prism
/// SwitchLine: unbounded fn Wx, Env, [Arg] -> ((Wx, Wres))
/// ```
pub fn switch_line(wx_p0: &crate::lower::node_::Wx, menv_p1: &crate::lower::types::Env, args_p2: &Array<crate::syntax::Arg>) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    match index(args_p2, &Nat::from(0u32)) {
        Some(a_p3) => {
            let (r_p4, wx2_p5) = crate::lower::node_::dynamics::event_ref(wx_p0, menv_p1, &a_p3.value);
            (wx2_p5.clone(), crate::lower::node_::Wres::WrEv(r_p4.clone()))
        },
        None => (wx_p0.clone(), crate::lower::node_::Wres::WrUnit),
    }
}
