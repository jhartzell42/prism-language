//! The module `Lower.Node`, from `target/bootstrap/src/prismc/lower/node/mod.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;
pub mod def;
pub mod dynamics;
pub mod elements;
pub mod finish;
pub mod keyed;
pub mod static_;
pub mod switch_;

/// `EvRef`:
///
/// ```prism
/// type EvRef = record:
/// ```
#[derive(Clone)]
pub struct EvRef {
    pub node_: Nat,
    pub owner: Text,
    pub pipe: Rc<dyn Fn((crate::lower::model::Ex, Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>)) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>,
}

/// `FlatDef`:
///
/// ```prism
/// type FlatDef = record:
/// ```
#[derive(Clone)]
pub struct FlatDef {
    pub name: Text,
    pub outer: Text,
    pub generation: Text,
    pub ty: crate::lower::model::OutTy,
}

impl ToPod for FlatDef {
    fn to_pod(&self) -> Pod {
        Pod::record("FlatDef", vec![("name", self.name.to_pod()), ("outer", self.outer.to_pod()), ("generation", self.generation.to_pod()), ("ty", self.ty.to_pod())])
    }
}

impl FromPod for FlatDef {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(FlatDef { name: FromPod::from_pod(field(p, "name")?)?, outer: FromPod::from_pod(field(p, "outer")?)?, generation: FromPod::from_pod(field(p, "generation")?)?, ty: FromPod::from_pod(field(p, "ty")?)? })
    }
}

/// `Gn`:
///
/// ```prism
/// type Gn = record:
/// ```
#[derive(Clone)]
pub struct Gn {
    pub id: Nat,
    pub name: Text,
    pub ty: crate::lower::model::OutTy,
    pub kind: GnKind,
    pub height: Nat,
    pub inputs: Array<Text>,
    pub reads: Array<Read>,
    pub floor: Nat,
    pub outs: Array<Out>,
}

/// `GnKind`:
///
/// ```prism
/// type GnKind = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum GnKind {
    GnNamed,
    GnAnswer,
    GnStarted,
    GnDeferred,
    GnPort,
    GnMerge,
    GnUnion,
    GnBoth,
    GnExcept,
    GnMergeAll,
    GnGather,
    GnUpdated,
    GnNever,
}

impl Show for GnKind {
    fn show(&self, p: &mut Printer) {
        match self {
            GnKind::GnNamed => p.choice("GnNamed", &[]),
            GnKind::GnAnswer => p.choice("GnAnswer", &[]),
            GnKind::GnStarted => p.choice("GnStarted", &[]),
            GnKind::GnDeferred => p.choice("GnDeferred", &[]),
            GnKind::GnPort => p.choice("GnPort", &[]),
            GnKind::GnMerge => p.choice("GnMerge", &[]),
            GnKind::GnUnion => p.choice("GnUnion", &[]),
            GnKind::GnBoth => p.choice("GnBoth", &[]),
            GnKind::GnExcept => p.choice("GnExcept", &[]),
            GnKind::GnMergeAll => p.choice("GnMergeAll", &[]),
            GnKind::GnGather => p.choice("GnGather", &[]),
            GnKind::GnUpdated => p.choice("GnUpdated", &[]),
            GnKind::GnNever => p.choice("GnNever", &[]),
        }
    }
}

impl ToPod for GnKind {
    fn to_pod(&self) -> Pod {
        match self {
            GnKind::GnNamed => Pod::Choice("GnNamed".into(), vec![]),
            GnKind::GnAnswer => Pod::Choice("GnAnswer".into(), vec![]),
            GnKind::GnStarted => Pod::Choice("GnStarted".into(), vec![]),
            GnKind::GnDeferred => Pod::Choice("GnDeferred".into(), vec![]),
            GnKind::GnPort => Pod::Choice("GnPort".into(), vec![]),
            GnKind::GnMerge => Pod::Choice("GnMerge".into(), vec![]),
            GnKind::GnUnion => Pod::Choice("GnUnion".into(), vec![]),
            GnKind::GnBoth => Pod::Choice("GnBoth".into(), vec![]),
            GnKind::GnExcept => Pod::Choice("GnExcept".into(), vec![]),
            GnKind::GnMergeAll => Pod::Choice("GnMergeAll".into(), vec![]),
            GnKind::GnGather => Pod::Choice("GnGather".into(), vec![]),
            GnKind::GnUpdated => Pod::Choice("GnUpdated".into(), vec![]),
            GnKind::GnNever => Pod::Choice("GnNever".into(), vec![]),
        }
    }
}

impl FromPod for GnKind {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "GnNamed" && a.len() == 0 => Ok(GnKind::GnNamed),
            Pod::Choice(c, a) if &**c == "GnAnswer" && a.len() == 0 => Ok(GnKind::GnAnswer),
            Pod::Choice(c, a) if &**c == "GnStarted" && a.len() == 0 => Ok(GnKind::GnStarted),
            Pod::Choice(c, a) if &**c == "GnDeferred" && a.len() == 0 => Ok(GnKind::GnDeferred),
            Pod::Choice(c, a) if &**c == "GnPort" && a.len() == 0 => Ok(GnKind::GnPort),
            Pod::Choice(c, a) if &**c == "GnMerge" && a.len() == 0 => Ok(GnKind::GnMerge),
            Pod::Choice(c, a) if &**c == "GnUnion" && a.len() == 0 => Ok(GnKind::GnUnion),
            Pod::Choice(c, a) if &**c == "GnBoth" && a.len() == 0 => Ok(GnKind::GnBoth),
            Pod::Choice(c, a) if &**c == "GnExcept" && a.len() == 0 => Ok(GnKind::GnExcept),
            Pod::Choice(c, a) if &**c == "GnMergeAll" && a.len() == 0 => Ok(GnKind::GnMergeAll),
            Pod::Choice(c, a) if &**c == "GnGather" && a.len() == 0 => Ok(GnKind::GnGather),
            Pod::Choice(c, a) if &**c == "GnUpdated" && a.len() == 0 => Ok(GnKind::GnUpdated),
            Pod::Choice(c, a) if &**c == "GnNever" && a.len() == 0 => Ok(GnKind::GnNever),
            other => mismatch("a GnKind", other),
        }
    }
}

/// `HostDef`:
///
/// ```prism
/// type HostDef = record:
/// ```
#[derive(Clone)]
pub struct HostDef {
    pub pos: crate::lower::model::Pos_,
    pub name: Text,
    pub scope: Nat,
}

impl ToPod for HostDef {
    fn to_pod(&self) -> Pod {
        Pod::record("HostDef", vec![("pos", self.pos.to_pod()), ("name", self.name.to_pod()), ("scope", self.scope.to_pod())])
    }
}

impl FromPod for HostDef {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(HostDef { pos: FromPod::from_pod(field(p, "pos")?)?, name: FromPod::from_pod(field(p, "name")?)?, scope: FromPod::from_pod(field(p, "scope")?)? })
    }
}

/// `Out`:
///
/// ```prism
/// type Out = record:
/// ```
#[derive(Clone)]
pub struct Out {
    pub pipe: Rc<dyn Fn((crate::lower::model::Ex, Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>)) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>,
    pub sink: Sk,
}

/// `PendingRow`:
///
/// ```prism
/// type PendingRow = record:
/// ```
#[derive(Clone)]
pub struct PendingRow {
    pub wx: Wx,
    pub qk: Text,
    pub params: Array<(Text, crate::lower::model::OutTy)>,
    pub gather: Option<Nat>,
}

/// `Place`:
///
/// ```prism
/// type Place = record:
/// ```
#[derive(Clone)]
pub struct Place {
    pub pos: crate::lower::model::Pos_,
    pub level: crate::lower::model::Ex,
    pub getter: Text,
    pub reads: Array<Read>,
}

impl ToPod for Place {
    fn to_pod(&self) -> Pod {
        Pod::record("Place", vec![("pos", self.pos.to_pod()), ("level", self.level.to_pod()), ("getter", self.getter.to_pod()), ("reads", self.reads.to_pod())])
    }
}

impl FromPod for Place {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Place { pos: FromPod::from_pod(field(p, "pos")?)?, level: FromPod::from_pod(field(p, "level")?)?, getter: FromPod::from_pod(field(p, "getter")?)?, reads: FromPod::from_pod(field(p, "reads")?)? })
    }
}

/// `Read`:
///
/// ```prism
/// type Read = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum Read {
    OwnRead(Text),
    ParentRead(Text),
}

impl Show for Read {
    fn show(&self, p: &mut Printer) {
        match self {
            Read::OwnRead(a0) => p.choice("OwnRead", &[a0]),
            Read::ParentRead(a0) => p.choice("ParentRead", &[a0]),
        }
    }
}

impl ToPod for Read {
    fn to_pod(&self) -> Pod {
        match self {
            Read::OwnRead(a0) => Pod::Choice("OwnRead".into(), vec![a0.to_pod()]),
            Read::ParentRead(a0) => Pod::Choice("ParentRead".into(), vec![a0.to_pod()]),
        }
    }
}

impl FromPod for Read {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "OwnRead" && a.len() == 1 => Ok(Read::OwnRead(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "ParentRead" && a.len() == 1 => Ok(Read::ParentRead(FromPod::from_pod(&a[0])?)),
            other => mismatch("a Read", other),
        }
    }
}

/// `RowMarks`:
///
/// ```prism
/// type RowMarks = record:
/// ```
#[derive(Clone)]
pub struct RowMarks {
    pub builder: Text,
    pub reads: Array<Read>,
    pub wrote: Array<Text>,
    pub kind: crate::lower::model::RowKind,
}

impl ToPod for RowMarks {
    fn to_pod(&self) -> Pod {
        Pod::record("RowMarks", vec![("builder", self.builder.to_pod()), ("reads", self.reads.to_pod()), ("wrote", self.wrote.to_pod()), ("kind", self.kind.to_pod())])
    }
}

impl FromPod for RowMarks {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(RowMarks { builder: FromPod::from_pod(field(p, "builder")?)?, reads: FromPod::from_pod(field(p, "reads")?)?, wrote: FromPod::from_pod(field(p, "wrote")?)?, kind: FromPod::from_pod(field(p, "kind")?)? })
    }
}

/// `Sk`:
///
/// ```prism
/// type Sk = choice:
/// ```
#[derive(Clone)]
pub enum Sk {
    SkNode(Nat),
    SkIn(Nat, Nat),
    SkHold(Text),
    SkRequest(crate::lower::model::Pos_, Text),
    SkResult,
    SkArm(Text),
    SkCycle(Text, Text, Nat),
    SkUp(Text),
    SkPort(Text),
    SkMachine(Text, Text, Nat),
    SkDistinct(Text),
}

impl ToPod for Sk {
    fn to_pod(&self) -> Pod {
        match self {
            Sk::SkNode(a0) => Pod::Choice("SkNode".into(), vec![a0.to_pod()]),
            Sk::SkIn(a0, a1) => Pod::Choice("SkIn".into(), vec![a0.to_pod(), a1.to_pod()]),
            Sk::SkHold(a0) => Pod::Choice("SkHold".into(), vec![a0.to_pod()]),
            Sk::SkRequest(a0, a1) => Pod::Choice("SkRequest".into(), vec![a0.to_pod(), a1.to_pod()]),
            Sk::SkResult => Pod::Choice("SkResult".into(), vec![]),
            Sk::SkArm(a0) => Pod::Choice("SkArm".into(), vec![a0.to_pod()]),
            Sk::SkCycle(a0, a1, a2) => Pod::Choice("SkCycle".into(), vec![a0.to_pod(), a1.to_pod(), a2.to_pod()]),
            Sk::SkUp(a0) => Pod::Choice("SkUp".into(), vec![a0.to_pod()]),
            Sk::SkPort(a0) => Pod::Choice("SkPort".into(), vec![a0.to_pod()]),
            Sk::SkMachine(a0, a1, a2) => Pod::Choice("SkMachine".into(), vec![a0.to_pod(), a1.to_pod(), a2.to_pod()]),
            Sk::SkDistinct(a0) => Pod::Choice("SkDistinct".into(), vec![a0.to_pod()]),
        }
    }
}

impl FromPod for Sk {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "SkNode" && a.len() == 1 => Ok(Sk::SkNode(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "SkIn" && a.len() == 2 => Ok(Sk::SkIn(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "SkHold" && a.len() == 1 => Ok(Sk::SkHold(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "SkRequest" && a.len() == 2 => Ok(Sk::SkRequest(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "SkResult" && a.len() == 0 => Ok(Sk::SkResult),
            Pod::Choice(c, a) if &**c == "SkArm" && a.len() == 1 => Ok(Sk::SkArm(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "SkCycle" && a.len() == 3 => Ok(Sk::SkCycle(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?, FromPod::from_pod(&a[2])?)),
            Pod::Choice(c, a) if &**c == "SkUp" && a.len() == 1 => Ok(Sk::SkUp(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "SkPort" && a.len() == 1 => Ok(Sk::SkPort(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "SkMachine" && a.len() == 3 => Ok(Sk::SkMachine(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?, FromPod::from_pod(&a[2])?)),
            Pod::Choice(c, a) if &**c == "SkDistinct" && a.len() == 1 => Ok(Sk::SkDistinct(FromPod::from_pod(&a[0])?)),
            other => mismatch("a Sk", other),
        }
    }
}

/// `SnapDef`:
///
/// ```prism
/// type SnapDef = record:
/// ```
#[derive(Clone)]
pub struct SnapDef {
    pub name: Text,
    pub live: Text,
    pub ty: crate::lower::model::OutTy,
    pub eq: bool,
    pub builder: Text,
    pub before: bool,
    pub what: Text,
}

impl ToPod for SnapDef {
    fn to_pod(&self) -> Pod {
        Pod::record("SnapDef", vec![("name", self.name.to_pod()), ("live", self.live.to_pod()), ("ty", self.ty.to_pod()), ("eq", self.eq.to_pod()), ("builder", self.builder.to_pod()), ("before", self.before.to_pod()), ("what", self.what.to_pod())])
    }
}

impl FromPod for SnapDef {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(SnapDef { name: FromPod::from_pod(field(p, "name")?)?, live: FromPod::from_pod(field(p, "live")?)?, ty: FromPod::from_pod(field(p, "ty")?)?, eq: FromPod::from_pod(field(p, "eq")?)?, builder: FromPod::from_pod(field(p, "builder")?)?, before: FromPod::from_pod(field(p, "before")?)?, what: FromPod::from_pod(field(p, "what")?)? })
    }
}

/// `Wres`:
///
/// ```prism
/// type Wres = choice:
/// ```
#[derive(Clone)]
pub enum Wres {
    WrEv(EvRef),
    WrDyn(crate::lower::model::Ex, Array<Read>, crate::lower::model::OutTy),
    WrPlain(crate::lower::model::Ex, crate::lower::model::OutTy),
    WrUnit,
    WrHosted(Rc<Wres>, crate::lower::types::Bn),
}

/// `Wx`:
///
/// ```prism
/// type Wx = record:
/// ```
#[derive(Clone)]
pub struct Wx {
    pub lx: crate::lower::Lx,
    pub node_: Text,
    pub pos: crate::lower::model::Pos_,
    pub gns: Array<Gn>,
    pub fields: Array<(Text, crate::lower::model::OutTy, Text)>,
    pub inits: Array<(Text, crate::lower::model::Ex)>,
    pub moves: Array<(Text, crate::lower::model::Ex)>,
    pub lets: Array<crate::lower::model::Do>,
    pub build: Array<crate::lower::model::Do>,
    pub places: Array<Place>,
    pub answers: Array<(crate::lower::model::Pos_, Nat, crate::lower::model::OutTy, Text)>,
    pub started: Array<Nat>,
    pub defers: Array<(Text, Nat)>,
    pub getters: Array<crate::lower::model::MethDef>,
    pub dyn_reads: Map<Text, Array<Read>>,
    pub taken: Array<Text>,
    pub fallible: bool,
    pub depth: Nat,
    pub result: Wres,
    pub rows: Array<crate::lower::model::NodeDef>,
    pub builders: Array<crate::lower::model::ForDef>,
    pub let_caches: Array<Text>,
    pub build_holds: Array<Read>,
    pub up_sink: Text,
    pub gens: Array<crate::lower::model::GenDef>,
    pub gen_holds: Array<(Text, Array<Read>)>,
    pub ports: Array<Text>,
    pub subs: Array<(Text, Text, crate::lower::model::OutTy)>,
    pub parent_env: crate::lower::types::Env,
    pub hosts: Array<HostDef>,
    pub dyn_places: Array<(crate::lower::model::Pos_, Text, crate::lower::model::OutTy, Text)>,
    pub scopes: Array<Text>,
    pub hosted_by: Option<Text>,
    pub root_dyn: Option<(crate::lower::model::Ex, Array<Read>, crate::lower::model::OutTy)>,
    pub row_marks: Array<RowMarks>,
    pub pending: Array<PendingRow>,
    pub floors: Map<Text, Nat>,
    pub snaps: Array<SnapDef>,
    pub result_moved: Option<(Text, Array<Read>)>,
    pub dyn_answers: Array<(Text, Array<Read>)>,
    pub inited: Array<Text>,
    pub flattens: Array<FlatDef>,
}

/// ```prism
/// IdPipe: unbounded fn Ex, (unbounded fn Ex -> [Do]) -> [Do]
/// ```
pub fn id_pipe(x: &crate::lower::model::Ex, k_fn: &Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>) -> Array<crate::lower::model::Do> {
    run_to_end(k_fn(x.clone()))
}

/// The step machine of `IdPipe`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// IdPipe: unbounded fn Ex, (unbounded fn Ex -> [Do]) -> [Do]
/// ```
pub struct IdPipe {
    pub x: crate::lower::model::Ex,
    pub k_fn: Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>,
}

impl prism_rtl::Job<Array<crate::lower::model::Do>> for IdPipe {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::lower::model::Do>> {
        let x = &self.x;
        let k_fn = &self.k_fn;
        k_fn(x.clone()).cycle()
    }
}

/// `Start IdPipe, x`: what the function value is when passed to `@Run`.
pub fn start_id_pipe(x: crate::lower::model::Ex, k_fn: Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>> {
    Rc::new(IdPipe { x, k_fn })
}

/// ```prism
/// EvRefOf: fn Wx, Nat -> EvRef
/// ```
pub fn ev_ref_of(wx: &Wx, n: &Nat) -> EvRef {
    EvRef { node_: n.clone(), owner: wx.node_.clone(), pipe: Rc::new(|(a0, a1): (crate::lower::model::Ex, Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>)| entered(start_id_pipe(a0, a1))) as Rc<dyn Fn((crate::lower::model::Ex, Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>)) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>> }
}

/// ```prism
/// KindWord: fn GnKind -> Text
/// ```
pub fn kind_word(k: &GnKind) -> Text {
    match k {
        GnKind::GnNamed => Text::lit("named"),
        GnKind::GnAnswer => Text::lit("answer"),
        GnKind::GnStarted => Text::lit("started"),
        GnKind::GnDeferred => Text::lit("deferred"),
        GnKind::GnPort => Text::lit("port"),
        GnKind::GnMerge => Text::lit("merge"),
        GnKind::GnUnion => Text::lit("union"),
        GnKind::GnBoth => Text::lit("both"),
        GnKind::GnExcept => Text::lit("except"),
        GnKind::GnMergeAll => Text::lit("mergeall"),
        GnKind::GnGather => Text::lit("gather"),
        GnKind::GnUpdated => Text::lit("updated"),
        GnKind::GnNever => Text::lit("never"),
    }
}

/// ```prism
/// HasRead: fn [Read], Read -> Bool
/// ```
pub fn has_read(rs: &Array<Read>, r: &Read) -> bool {
    fold(rs, &false, &(|seen: &bool, x: &Read| *seen || (x == r)))
}

/// ```prism
/// AddRead: fn [Read], Read -> [Read]
/// ```
pub fn add_read(rs: &Array<Read>, r: &Read) -> Array<Read> {
    if has_read(rs, r) { rs.clone() } else { push(rs, r) }
}

/// ```prism
/// UnionReads: fn [Read], [Read] -> [Read]
/// ```
pub fn union_reads(xs: &Array<Read>, ys: &Array<Read>) -> Array<Read> {
    fold(ys, xs, &(|acc: &Array<Read>, y: &Read| add_read(acc, y)))
}

/// ```prism
/// let nodeHooks
/// ```
pub fn node_hooks() -> Array<Text> {
    Array::from(vec![Text::lit("path"), Text::lit("build"), Text::lit("wake"), Text::lit("started"), Text::lit("deferred"), Text::lit("answer"), Text::lit("push"), Text::lit("swap"), Text::lit("leave"), Text::lit("patch"), Text::lit("clean_up"), Text::lit("edges"), Text::lit("release"), Text::lit("leave_row"), Text::lit("remove_places")])
}

/// ```prism
/// NewWx: fn Lx, Text, [((Text, OutTy, Text))], [((Text, Ex))], [((Text, Ex))], [MethDef], (Text ==> [Read]), [Text], Nat, ?Text -> Wx
/// ```
pub fn new_wx(lx: &crate::lower::Lx, name: &Text, fields: &Array<(Text, crate::lower::model::OutTy, Text)>, inits: &Array<(Text, crate::lower::model::Ex)>, moves: &Array<(Text, crate::lower::model::Ex)>, getters: &Array<crate::lower::model::MethDef>, dyn_reads: &Map<Text, Array<Read>>, taken: &Array<Text>, depth: &Nat, hosted_by_opt: &Option<Text>) -> Wx {
    let hosted_fields = match hosted_by_opt {
        Some(_) => Array::from(vec![(Text::lit("enclosing"), crate::lower::types::host_of_ty(), Text::lit("the host whose document this row\'s places are entries of (pick HO)"))]),
        None => Array::new(),
    };
    let hosted_inits = match hosted_by_opt {
        Some(_) => Array::from(vec![(Text::lit("enclosing"), crate::lower::model::Ex::XVar(Text::lit("enclosing")))]),
        None => Array::new(),
    };
    Wx { lx: lx.clone(), node_: name.clone(), pos: crate::lower::model::pos0(), gns: Array::new(), fields: append(fields, &hosted_fields), inits: inits.clone(), moves: append(moves, &hosted_inits), lets: Array::new(), build: Array::new(), places: Array::new(), answers: Array::new(), started: Array::new(), defers: Array::new(), getters: getters.clone(), dyn_reads: dyn_reads.clone(), taken: push(taken, &Text::lit("enclosing")), fallible: false, depth: depth.clone(), result: Wres::WrUnit, rows: Array::new(), builders: Array::new(), let_caches: Array::new(), build_holds: Array::new(), up_sink: Text::lit(""), gens: Array::new(), gen_holds: Array::new(), ports: Array::new(), subs: Array::new(), parent_env: crate::lower::types::empty_env(), hosts: Array::new(), dyn_places: Array::new(), scopes: Array::new(), hosted_by: hosted_by_opt.clone(), root_dyn: None, row_marks: Array::new(), pending: Array::new(), floors: Map::new(), snaps: Array::new(), result_moved: None, dyn_answers: Array::new(), inited: Array::new(), flattens: Array::new() }
}

/// ```prism
/// FreshName: fn Wx, Text -> ((Text, Wx))
/// ```
pub fn fresh_name(wx: &Wx, base: &Text) -> (Text, Wx) {
    let pick = if !crate::check::types::has_text(&wx.taken, base) {
        base.clone()
    } else {
        Text::from(format!("{}_{}", base, &first_free(&wx.taken, base, &Nat::from(2u32))))
    };
    let wx2 = {
        let mut this: Wx = wx.clone();
        this.taken = push(&this.taken, &pick);
        this
    };
    (pick.clone(), wx2.clone())
}

/// ```prism
/// FirstFree: fn [Text], Text, Nat -> Nat
/// ```
pub fn first_free(taken: &Array<Text>, base: &Text, from: &Nat) -> Nat {
    fold(&crate::check::errors::range0(&len(taken)), from, &(|n: &Nat, _: &Nat| if crate::check::types::has_text(taken, &Text::from(format!("{}_{}", base, n))) {
        n + &Nat::from(1u32)
    } else {
        n.clone()
    }))
}

/// ```prism
/// AddGn: fn Wx, Text, OutTy, GnKind, Nat -> ((Nat, Wx))
/// ```
pub fn add_gn(wx: &Wx, name: &Text, ty: &crate::lower::model::OutTy, kind: &GnKind, height: &Nat) -> (Nat, Wx) {
    let id = len(&wx.gns);
    let wx2 = {
        let mut this: Wx = wx.clone();
        this.gns = push(&this.gns, &Gn { id: id.clone(), name: name.clone(), ty: ty.clone(), kind: kind.clone(), height: height.clone(), inputs: Array::new(), reads: Array::new(), floor: Nat::from(0u32), outs: Array::new() });
        this
    };
    (id.clone(), wx2.clone())
}

/// ```prism
/// Connect: fn Wx, EvRef, Sk -> Wx
/// ```
pub fn connect(wx: &Wx, r: &EvRef, sink: &Sk) -> Wx {
    if &r.owner != &wx.node_ {
        crossed(wx, &Text::from(format!("an event of node `{}` (its graph node {})", &r.owner, &r.node_)))
    } else {
        {
            let mut this: Wx = wx.clone();
            this.gns = each(&this.gns, &(|n: &Gn| if &n.id == &r.node_ {
                add_out(n, &Out { pipe: r.pipe.clone(), sink: sink.clone() })
            } else {
                n.clone()
            }));
            this
        }
    }
}

/// ```prism
/// Crossed: fn Wx, Text -> Wx
/// ```
pub fn crossed(wx: &Wx, what: &Text) -> Wx {
    let mut this: Wx = wx.clone();
    this.build = push(&this.build, &crate::lower::model::Do::DoExpr(crate::lower::expr::refusal(&Text::from(format!("{} read in node `{}` without a port (a lowering bug)", what, &wx.node_)))));
    this
}

/// ```prism
/// AddOut: fn Gn, Out -> Gn
/// ```
pub fn add_out(n: &Gn, o: &Out) -> Gn {
    let mut this: Gn = n.clone();
    this.outs = push(&this.outs, o);
    this
}

/// ```prism
/// AddField: fn Wx, Text, OutTy, Text, Ex -> Wx
/// ```
pub fn add_field(wx: &Wx, name: &Text, t: &crate::lower::model::OutTy, doc: &Text, init: &crate::lower::model::Ex) -> Wx {
    let mut this: Wx = wx.clone();
    this.fields = push(&this.fields, &(name.clone(), t.clone(), doc.clone()));
    this.inits = push(&this.inits, &(name.clone(), init.clone()));
    this
}

/// ```prism
/// AddFieldLast: fn Wx, Text, OutTy, Text, Ex -> Wx
/// ```
pub fn add_field_last(wx: &Wx, name: &Text, t: &crate::lower::model::OutTy, doc: &Text, init: &crate::lower::model::Ex) -> Wx {
    let mut this: Wx = wx.clone();
    this.fields = push(&this.fields, &(name.clone(), t.clone(), doc.clone()));
    this.moves = push(&this.moves, &(name.clone(), init.clone()));
    this
}

/// ```prism
/// GnOf: fn Wx, Nat -> Gn
/// ```
pub fn gn_of(wx: &Wx, n: &Nat) -> Gn {
    or(&index(&wx.gns, n), &Gn { id: n.clone(), name: Text::lit("never"), ty: crate::lower::model::OutTy::OutUnit, kind: GnKind::GnNever, height: Nat::from(0u32), inputs: Array::new(), reads: Array::new(), floor: Nat::from(0u32), outs: Array::new() })
}

/// ```prism
/// BindPlain: fn Env, Env, Text, Text, OutTy -> ((Env, Env))
/// ```
pub fn bind_plain(benv: &crate::lower::types::Env, menv: &crate::lower::types::Env, nkey: &Text, rs: &Text, t: &crate::lower::model::OutTy) -> (crate::lower::types::Env, crate::lower::types::Env) {
    (crate::lower::types::bind(benv, nkey, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(rs.clone()), crate::lower::types::Holding::Owned, t.clone())), crate::lower::types::bind(menv, nkey, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), rs.clone()), crate::lower::types::Holding::Owned, t.clone())))
}
