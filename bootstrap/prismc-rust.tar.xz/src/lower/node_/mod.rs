//! The module `Lower.Node`, from `target/bootstrap/src/prismc/lower/node/mod.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;
pub mod def;
pub mod dynamics;
pub mod elements;
pub mod finish;
pub mod keyed;
pub mod static_;
pub mod switch_;

/// `EvRef`:
///
/// ```prism
/// type EvRef = record:
/// ```
#[derive(Clone)]
pub struct EvRef {
    pub node_p: Nat,
    pub owner_p: Text,
    pub pipe_f: Rc<dyn Fn((crate::lower::model::Ex, Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>)) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>,
}

/// `FlatDef`:
///
/// ```prism
/// type FlatDef = record:
/// ```
#[derive(Clone)]
pub struct FlatDef {
    pub name_p: Text,
    pub outer_p: Text,
    pub generation_p: Text,
    pub ty_p: crate::lower::model::OutTy,
}

impl ToPod for FlatDef {
    fn to_pod(&self) -> Pod {
        Pod::record("FlatDef", vec![("name", self.name_p.to_pod()), ("outer", self.outer_p.to_pod()), ("generation", self.generation_p.to_pod()), ("ty", self.ty_p.to_pod())])
    }
}

impl FromPod for FlatDef {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(FlatDef { name_p: FromPod::from_pod(field(p, "name")?)?, outer_p: FromPod::from_pod(field(p, "outer")?)?, generation_p: FromPod::from_pod(field(p, "generation")?)?, ty_p: FromPod::from_pod(field(p, "ty")?)? })
    }
}

/// `Gn`:
///
/// ```prism
/// type Gn = record:
/// ```
#[derive(Clone)]
pub struct Gn {
    pub id_p: Nat,
    pub name_p: Text,
    pub ty_p: crate::lower::model::OutTy,
    pub kind_p: GnKind,
    pub height_p: Nat,
    pub inputs_p: Array<Text>,
    pub reads_p: Array<Read>,
    pub floor_p: Nat,
    pub outs_p: Array<Out>,
}

/// `GnKind`:
///
/// ```prism
/// type GnKind = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum GnKind {
    GnNamed,
    GnAnswer,
    GnStarted,
    GnDeferred,
    GnPort,
    GnMerge,
    GnUnion,
    GnBoth,
    GnExcept,
    GnMergeAll,
    GnGather,
    GnUpdated,
    GnNever,
}

impl Show for GnKind {
    fn show(&self, p: &mut Printer) {
        match self {
            GnKind::GnNamed => p.choice("GnNamed", &[]),
            GnKind::GnAnswer => p.choice("GnAnswer", &[]),
            GnKind::GnStarted => p.choice("GnStarted", &[]),
            GnKind::GnDeferred => p.choice("GnDeferred", &[]),
            GnKind::GnPort => p.choice("GnPort", &[]),
            GnKind::GnMerge => p.choice("GnMerge", &[]),
            GnKind::GnUnion => p.choice("GnUnion", &[]),
            GnKind::GnBoth => p.choice("GnBoth", &[]),
            GnKind::GnExcept => p.choice("GnExcept", &[]),
            GnKind::GnMergeAll => p.choice("GnMergeAll", &[]),
            GnKind::GnGather => p.choice("GnGather", &[]),
            GnKind::GnUpdated => p.choice("GnUpdated", &[]),
            GnKind::GnNever => p.choice("GnNever", &[]),
        }
    }
}

impl ToPod for GnKind {
    fn to_pod(&self) -> Pod {
        match self {
            GnKind::GnNamed => Pod::Choice("GnNamed".into(), vec![]),
            GnKind::GnAnswer => Pod::Choice("GnAnswer".into(), vec![]),
            GnKind::GnStarted => Pod::Choice("GnStarted".into(), vec![]),
            GnKind::GnDeferred => Pod::Choice("GnDeferred".into(), vec![]),
            GnKind::GnPort => Pod::Choice("GnPort".into(), vec![]),
            GnKind::GnMerge => Pod::Choice("GnMerge".into(), vec![]),
            GnKind::GnUnion => Pod::Choice("GnUnion".into(), vec![]),
            GnKind::GnBoth => Pod::Choice("GnBoth".into(), vec![]),
            GnKind::GnExcept => Pod::Choice("GnExcept".into(), vec![]),
            GnKind::GnMergeAll => Pod::Choice("GnMergeAll".into(), vec![]),
            GnKind::GnGather => Pod::Choice("GnGather".into(), vec![]),
            GnKind::GnUpdated => Pod::Choice("GnUpdated".into(), vec![]),
            GnKind::GnNever => Pod::Choice("GnNever".into(), vec![]),
        }
    }
}

impl FromPod for GnKind {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "GnNamed" && a.len() == 0 => Ok(GnKind::GnNamed),
            Pod::Choice(c, a) if &**c == "GnAnswer" && a.len() == 0 => Ok(GnKind::GnAnswer),
            Pod::Choice(c, a) if &**c == "GnStarted" && a.len() == 0 => Ok(GnKind::GnStarted),
            Pod::Choice(c, a) if &**c == "GnDeferred" && a.len() == 0 => Ok(GnKind::GnDeferred),
            Pod::Choice(c, a) if &**c == "GnPort" && a.len() == 0 => Ok(GnKind::GnPort),
            Pod::Choice(c, a) if &**c == "GnMerge" && a.len() == 0 => Ok(GnKind::GnMerge),
            Pod::Choice(c, a) if &**c == "GnUnion" && a.len() == 0 => Ok(GnKind::GnUnion),
            Pod::Choice(c, a) if &**c == "GnBoth" && a.len() == 0 => Ok(GnKind::GnBoth),
            Pod::Choice(c, a) if &**c == "GnExcept" && a.len() == 0 => Ok(GnKind::GnExcept),
            Pod::Choice(c, a) if &**c == "GnMergeAll" && a.len() == 0 => Ok(GnKind::GnMergeAll),
            Pod::Choice(c, a) if &**c == "GnGather" && a.len() == 0 => Ok(GnKind::GnGather),
            Pod::Choice(c, a) if &**c == "GnUpdated" && a.len() == 0 => Ok(GnKind::GnUpdated),
            Pod::Choice(c, a) if &**c == "GnNever" && a.len() == 0 => Ok(GnKind::GnNever),
            other => mismatch("a GnKind", other),
        }
    }
}

/// `HostDef`:
///
/// ```prism
/// type HostDef = record:
/// ```
#[derive(Clone)]
pub struct HostDef {
    pub pos_p: crate::lower::model::Pos_,
    pub name_p: Text,
    pub scope_p: Nat,
}

impl ToPod for HostDef {
    fn to_pod(&self) -> Pod {
        Pod::record("HostDef", vec![("pos", self.pos_p.to_pod()), ("name", self.name_p.to_pod()), ("scope", self.scope_p.to_pod())])
    }
}

impl FromPod for HostDef {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(HostDef { pos_p: FromPod::from_pod(field(p, "pos")?)?, name_p: FromPod::from_pod(field(p, "name")?)?, scope_p: FromPod::from_pod(field(p, "scope")?)? })
    }
}

/// `Out`:
///
/// ```prism
/// type Out = record:
/// ```
#[derive(Clone)]
pub struct Out {
    pub pipe_f: Rc<dyn Fn((crate::lower::model::Ex, Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>)) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>,
    pub sink_p: Sk,
}

/// `PendingRow`:
///
/// ```prism
/// type PendingRow = record:
/// ```
#[derive(Clone)]
pub struct PendingRow {
    pub wx_p: Wx,
    pub qk_p: Text,
    pub params_p: Array<(Text, crate::lower::model::OutTy)>,
    pub gather_o: Option<Nat>,
}

/// `Place`:
///
/// ```prism
/// type Place = record:
/// ```
#[derive(Clone)]
pub struct Place {
    pub pos_p: crate::lower::model::Pos_,
    pub level_p: crate::lower::model::Ex,
    pub getter_p: Text,
    pub reads_p: Array<Read>,
    pub entry_p: Text,
    pub watch_p: Text,
}

impl ToPod for Place {
    fn to_pod(&self) -> Pod {
        Pod::record("Place", vec![("pos", self.pos_p.to_pod()), ("level", self.level_p.to_pod()), ("getter", self.getter_p.to_pod()), ("reads", self.reads_p.to_pod()), ("entry", self.entry_p.to_pod()), ("watch", self.watch_p.to_pod())])
    }
}

impl FromPod for Place {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Place { pos_p: FromPod::from_pod(field(p, "pos")?)?, level_p: FromPod::from_pod(field(p, "level")?)?, getter_p: FromPod::from_pod(field(p, "getter")?)?, reads_p: FromPod::from_pod(field(p, "reads")?)?, entry_p: FromPod::from_pod(field(p, "entry")?)?, watch_p: FromPod::from_pod(field(p, "watch")?)? })
    }
}

/// `Read`:
///
/// ```prism
/// type Read = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum Read {
    OwnRead(Text),
    ParentRead(Text),
}

impl Show for Read {
    fn show(&self, p: &mut Printer) {
        match self {
            Read::OwnRead(a0) => p.choice("OwnRead", &[a0]),
            Read::ParentRead(a0) => p.choice("ParentRead", &[a0]),
        }
    }
}

impl ToPod for Read {
    fn to_pod(&self) -> Pod {
        match self {
            Read::OwnRead(a0) => Pod::Choice("OwnRead".into(), vec![a0.to_pod()]),
            Read::ParentRead(a0) => Pod::Choice("ParentRead".into(), vec![a0.to_pod()]),
        }
    }
}

impl FromPod for Read {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "OwnRead" && a.len() == 1 => Ok(Read::OwnRead(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "ParentRead" && a.len() == 1 => Ok(Read::ParentRead(FromPod::from_pod(&a[0])?)),
            other => mismatch("a Read", other),
        }
    }
}

/// `RowMarks`:
///
/// ```prism
/// type RowMarks = record:
/// ```
#[derive(Clone)]
pub struct RowMarks {
    pub builder_p: Text,
    pub reads_p: Array<Read>,
    pub wrote_p: Array<Text>,
    pub kind_p: crate::lower::model::RowKind,
}

impl ToPod for RowMarks {
    fn to_pod(&self) -> Pod {
        Pod::record("RowMarks", vec![("builder", self.builder_p.to_pod()), ("reads", self.reads_p.to_pod()), ("wrote", self.wrote_p.to_pod()), ("kind", self.kind_p.to_pod())])
    }
}

impl FromPod for RowMarks {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(RowMarks { builder_p: FromPod::from_pod(field(p, "builder")?)?, reads_p: FromPod::from_pod(field(p, "reads")?)?, wrote_p: FromPod::from_pod(field(p, "wrote")?)?, kind_p: FromPod::from_pod(field(p, "kind")?)? })
    }
}

/// `Sk`:
///
/// ```prism
/// type Sk = choice:
/// ```
#[derive(Clone)]
pub enum Sk {
    SkNode(Nat),
    SkIn(Nat, Nat),
    SkHold(Text),
    SkRequest(crate::lower::model::Pos_, Text),
    SkResult,
    SkArm(Text),
    SkCycle(Text, Text, Nat),
    SkUp(Text),
    SkPort(Text),
    SkMachine(Text, Text, Nat),
    SkDistinct(Text),
    SkPerKey(Text),
}

impl ToPod for Sk {
    fn to_pod(&self) -> Pod {
        match self {
            Sk::SkNode(a0) => Pod::Choice("SkNode".into(), vec![a0.to_pod()]),
            Sk::SkIn(a0, a1) => Pod::Choice("SkIn".into(), vec![a0.to_pod(), a1.to_pod()]),
            Sk::SkHold(a0) => Pod::Choice("SkHold".into(), vec![a0.to_pod()]),
            Sk::SkRequest(a0, a1) => Pod::Choice("SkRequest".into(), vec![a0.to_pod(), a1.to_pod()]),
            Sk::SkResult => Pod::Choice("SkResult".into(), vec![]),
            Sk::SkArm(a0) => Pod::Choice("SkArm".into(), vec![a0.to_pod()]),
            Sk::SkCycle(a0, a1, a2) => Pod::Choice("SkCycle".into(), vec![a0.to_pod(), a1.to_pod(), a2.to_pod()]),
            Sk::SkUp(a0) => Pod::Choice("SkUp".into(), vec![a0.to_pod()]),
            Sk::SkPort(a0) => Pod::Choice("SkPort".into(), vec![a0.to_pod()]),
            Sk::SkMachine(a0, a1, a2) => Pod::Choice("SkMachine".into(), vec![a0.to_pod(), a1.to_pod(), a2.to_pod()]),
            Sk::SkDistinct(a0) => Pod::Choice("SkDistinct".into(), vec![a0.to_pod()]),
            Sk::SkPerKey(a0) => Pod::Choice("SkPerKey".into(), vec![a0.to_pod()]),
        }
    }
}

impl FromPod for Sk {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "SkNode" && a.len() == 1 => Ok(Sk::SkNode(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "SkIn" && a.len() == 2 => Ok(Sk::SkIn(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "SkHold" && a.len() == 1 => Ok(Sk::SkHold(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "SkRequest" && a.len() == 2 => Ok(Sk::SkRequest(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "SkResult" && a.len() == 0 => Ok(Sk::SkResult),
            Pod::Choice(c, a) if &**c == "SkArm" && a.len() == 1 => Ok(Sk::SkArm(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "SkCycle" && a.len() == 3 => Ok(Sk::SkCycle(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?, FromPod::from_pod(&a[2])?)),
            Pod::Choice(c, a) if &**c == "SkUp" && a.len() == 1 => Ok(Sk::SkUp(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "SkPort" && a.len() == 1 => Ok(Sk::SkPort(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "SkMachine" && a.len() == 3 => Ok(Sk::SkMachine(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?, FromPod::from_pod(&a[2])?)),
            Pod::Choice(c, a) if &**c == "SkDistinct" && a.len() == 1 => Ok(Sk::SkDistinct(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "SkPerKey" && a.len() == 1 => Ok(Sk::SkPerKey(FromPod::from_pod(&a[0])?)),
            other => mismatch("a Sk", other),
        }
    }
}

/// `SnapDef`:
///
/// ```prism
/// type SnapDef = record:
/// ```
#[derive(Clone)]
pub struct SnapDef {
    pub name_p: Text,
    pub live_p: Text,
    pub ty_p: crate::lower::model::OutTy,
    pub eq_p: bool,
    pub builder_p: Text,
    pub before_p: bool,
    pub what_p: Text,
}

impl ToPod for SnapDef {
    fn to_pod(&self) -> Pod {
        Pod::record("SnapDef", vec![("name", self.name_p.to_pod()), ("live", self.live_p.to_pod()), ("ty", self.ty_p.to_pod()), ("eq", self.eq_p.to_pod()), ("builder", self.builder_p.to_pod()), ("before", self.before_p.to_pod()), ("what", self.what_p.to_pod())])
    }
}

impl FromPod for SnapDef {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(SnapDef { name_p: FromPod::from_pod(field(p, "name")?)?, live_p: FromPod::from_pod(field(p, "live")?)?, ty_p: FromPod::from_pod(field(p, "ty")?)?, eq_p: FromPod::from_pod(field(p, "eq")?)?, builder_p: FromPod::from_pod(field(p, "builder")?)?, before_p: FromPod::from_pod(field(p, "before")?)?, what_p: FromPod::from_pod(field(p, "what")?)? })
    }
}

/// `Wres`:
///
/// ```prism
/// type Wres = choice:
/// ```
#[derive(Clone)]
pub enum Wres {
    WrEv(EvRef),
    WrDyn(crate::lower::model::Ex, Array<Read>, crate::lower::model::OutTy),
    WrPlain(crate::lower::model::Ex, crate::lower::model::OutTy),
    WrUnit,
    WrHosted(Rc<Wres>, crate::lower::types::Bn),
    WrParts(Array<Wres>),
}

/// `Wx`:
///
/// ```prism
/// type Wx = record:
/// ```
#[derive(Clone)]
pub struct Wx {
    pub lx_p: crate::lower::Lx,
    pub node_p: Text,
    pub pos_p: crate::lower::model::Pos_,
    pub gns_p: Array<Gn>,
    pub fields_p: Array<(Text, crate::lower::model::OutTy, Text)>,
    pub inits_p: Array<(Text, crate::lower::model::Ex)>,
    pub moves_p: Array<(Text, crate::lower::model::Ex)>,
    pub lets_p: Array<crate::lower::model::Do>,
    pub build_p: Array<crate::lower::model::Do>,
    pub places_p: Array<Place>,
    pub answers_p: Array<(crate::lower::model::Pos_, Nat, crate::lower::model::OutTy, Text)>,
    pub started_p: Array<Nat>,
    pub defers_p: Array<(Text, Nat)>,
    pub getters_p: Array<crate::lower::model::MethDef>,
    pub dyn_reads_p: Map<Text, Array<Read>>,
    pub taken_p: Array<Text>,
    pub fallible_p: bool,
    pub inlining_p: Array<Text>,
    pub result_p: Wres,
    pub rows_p: Array<crate::lower::model::NodeDef>,
    pub builders_p: Array<crate::lower::model::ForDef>,
    pub let_caches_p: Array<Text>,
    pub build_holds_p: Array<Read>,
    pub up_sink_p: Text,
    pub gens_p: Array<crate::lower::model::GenDef>,
    pub gen_holds_p: Array<(Text, Array<Read>)>,
    pub ports_p: Array<Text>,
    pub subs_p: Array<(Text, Text, crate::lower::model::OutTy)>,
    pub parent_env_p: crate::lower::types::Env,
    pub hosts_p: Array<HostDef>,
    pub dyn_places_p: Array<(crate::lower::model::Pos_, Text, crate::lower::model::OutTy, Text)>,
    pub scopes_p: Array<Text>,
    pub hosted_by_o: Option<Text>,
    pub root_dyn_o: Option<(crate::lower::model::Ex, Array<Read>, crate::lower::model::OutTy)>,
    pub row_marks_p: Array<RowMarks>,
    pub pending_p: Array<PendingRow>,
    pub floors_p: Map<Text, Nat>,
    pub snaps_p: Array<SnapDef>,
    pub result_moved_o: Option<(Text, Array<Read>)>,
    pub dyn_answers_p: Array<(Text, Array<Read>)>,
    pub inited_p: Array<Text>,
    pub flattens_p: Array<FlatDef>,
}

/// ```prism
/// IdPipe: unbounded fn Ex, (unbounded fn Ex -> [Do]) -> [Do]
/// ```
pub fn id_pipe_f(x_p0: &crate::lower::model::Ex, k_f1: &Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>) -> Array<crate::lower::model::Do> {
    crate::prelude::run_to_end(k_f1(x_p0.clone()))
}

/// The step machine of `IdPipe`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// IdPipe: unbounded fn Ex, (unbounded fn Ex -> [Do]) -> [Do]
/// ```
pub struct IdPipe {
    pub x_p0: crate::lower::model::Ex,
    pub k_f1: Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>,
}

impl prism_rtl::Job<Array<crate::lower::model::Do>> for IdPipe {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::lower::model::Do>> {
        let x_p0 = &self.x_p0;
        let k_f1 = &self.k_f1;
        k_f1(x_p0.clone()).cycle()
    }
}

/// `Start IdPipe, x`: what the function value is when passed to `@Run`.
pub fn start_id_pipe_f(x_p0: crate::lower::model::Ex, k_f1: Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>> {
    Rc::new(IdPipe { x_p0, k_f1 })
}

/// ```prism
/// EvRefOf: fn Wx, Nat -> EvRef
/// ```
pub fn ev_ref_of_f(wx_p0: &Wx, n_p1: &Nat) -> EvRef {
    EvRef { node_p: n_p1.clone(), owner_p: wx_p0.node_p.clone(), pipe_f: Rc::new(|(a0, a1): (crate::lower::model::Ex, Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>)| crate::prelude::entered(start_id_pipe_f(a0, a1))) as Rc<dyn Fn((crate::lower::model::Ex, Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>)) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>> }
}

/// ```prism
/// KindWord: fn GnKind -> Text
/// ```
pub fn kind_word_f(k_p0: &GnKind) -> Text {
    match k_p0 {
        GnKind::GnNamed => Text::lit("named"),
        GnKind::GnAnswer => Text::lit("answer"),
        GnKind::GnStarted => Text::lit("started"),
        GnKind::GnDeferred => Text::lit("deferred"),
        GnKind::GnPort => Text::lit("port"),
        GnKind::GnMerge => Text::lit("merge"),
        GnKind::GnUnion => Text::lit("union"),
        GnKind::GnBoth => Text::lit("both"),
        GnKind::GnExcept => Text::lit("except"),
        GnKind::GnMergeAll => Text::lit("mergeall"),
        GnKind::GnGather => Text::lit("gather"),
        GnKind::GnUpdated => Text::lit("updated"),
        GnKind::GnNever => Text::lit("never"),
    }
}

/// ```prism
/// HasRead: fn [Read], Read -> Bool
/// ```
pub fn has_read_f(rs_p0: &Array<Read>, r_p1: &Read) -> bool {
    crate::prelude::fold(rs_p0, &false, &(|seen_p2: &bool, x_p3: &Read| *seen_p2 || (x_p3 == r_p1)))
}

/// ```prism
/// AddRead: fn [Read], Read -> [Read]
/// ```
pub fn add_read_f(rs_p0: &Array<Read>, r_p1: &Read) -> Array<Read> {
    if has_read_f(rs_p0, r_p1) { rs_p0.clone() } else { crate::prelude::push(rs_p0, r_p1) }
}

/// ```prism
/// UnionReads: fn [Read], [Read] -> [Read]
/// ```
pub fn union_reads_f(xs_p0: &Array<Read>, ys_p1: &Array<Read>) -> Array<Read> {
    crate::prelude::fold(ys_p1, xs_p0, &(|acc_p2: &Array<Read>, y_p3: &Read| add_read_f(acc_p2, y_p3)))
}

/// ```prism
/// let nodeHooks
/// ```
pub fn node_hooks_p() -> Array<Text> {
    Array::from(vec![Text::lit("path"), Text::lit("build"), Text::lit("wake"), Text::lit("started"), Text::lit("deferred"), Text::lit("answer"), Text::lit("push"), Text::lit("swap"), Text::lit("leave"), Text::lit("patch"), Text::lit("clean_up"), Text::lit("edges"), Text::lit("release"), Text::lit("leave_row"), Text::lit("remove_places")])
}

/// ```prism
/// NewWx: fn Lx, Text, [((Text, OutTy, Text))], [((Text, Ex))], [((Text, Ex))], [MethDef], (Text ==> [Read]), [Text], [Text], ?Text -> Wx
/// ```
pub fn new_wx_f(lx_p0: &crate::lower::Lx, name_p1: &Text, fields_p2: &Array<(Text, crate::lower::model::OutTy, Text)>, inits_p3: &Array<(Text, crate::lower::model::Ex)>, moves_p4: &Array<(Text, crate::lower::model::Ex)>, getters_p5: &Array<crate::lower::model::MethDef>, dyn_reads_p6: &Map<Text, Array<Read>>, taken_p7: &Array<Text>, inlining_p8: &Array<Text>, hosted_by_o9: &Option<Text>) -> Wx {
    let hosted_fields_pa = match hosted_by_o9 {
        Some(_) => Array::from(vec![(Text::lit("enclosing"), crate::lower::types::host_of_ty_p(), Text::lit("the host whose document this row\'s places are entries of (pick HO)"))]),
        None => Array::new(),
    };
    let hosted_inits_pb = match hosted_by_o9 {
        Some(_) => Array::from(vec![(Text::lit("enclosing"), crate::lower::model::Ex::XVar(Text::lit("enclosing")))]),
        None => Array::new(),
    };
    Wx { lx_p: lx_p0.clone(), node_p: name_p1.clone(), pos_p: crate::lower::model::pos0_p(), gns_p: Array::new(), fields_p: crate::prelude::append(fields_p2, &hosted_fields_pa), inits_p: inits_p3.clone(), moves_p: crate::prelude::append(moves_p4, &hosted_inits_pb), lets_p: Array::new(), build_p: Array::new(), places_p: Array::new(), answers_p: Array::new(), started_p: Array::new(), defers_p: Array::new(), getters_p: getters_p5.clone(), dyn_reads_p: dyn_reads_p6.clone(), taken_p: crate::prelude::push(taken_p7, &Text::lit("enclosing")), fallible_p: false, inlining_p: inlining_p8.clone(), result_p: Wres::WrUnit, rows_p: Array::new(), builders_p: Array::new(), let_caches_p: Array::new(), build_holds_p: Array::new(), up_sink_p: Text::lit(""), gens_p: Array::new(), gen_holds_p: Array::new(), ports_p: Array::new(), subs_p: Array::new(), parent_env_p: crate::lower::types::empty_env_p(), hosts_p: Array::new(), dyn_places_p: Array::new(), scopes_p: Array::new(), hosted_by_o: hosted_by_o9.clone(), root_dyn_o: None, row_marks_p: Array::new(), pending_p: Array::new(), floors_p: Map::new(), snaps_p: Array::new(), result_moved_o: None, dyn_answers_p: Array::new(), inited_p: Array::new(), flattens_p: Array::new() }
}

/// ```prism
/// FreshName: fn Wx, Text -> ((Text, Wx))
/// ```
pub fn fresh_name_f(wx_p0: &Wx, base_p1: &Text) -> (Text, Wx) {
    let pick_p2 = if !crate::check::types::has_text_f(&wx_p0.taken_p, base_p1) {
        base_p1.clone()
    } else {
        Text::from(format!("{}_{}", base_p1, &first_free_f(&wx_p0.taken_p, base_p1, &Nat::from(2u32))))
    };
    let wx2_p3 = {
        let mut this: Wx = wx_p0.clone();
        this.taken_p = crate::prelude::push(&this.taken_p, &pick_p2);
        this
    };
    (pick_p2.clone(), wx2_p3.clone())
}

/// ```prism
/// FirstFree: fn [Text], Text, Nat -> Nat
/// ```
pub fn first_free_f(taken_p0: &Array<Text>, base_p1: &Text, from_p2: &Nat) -> Nat {
    crate::prelude::fold(&crate::check::errors::range0_f(&crate::prelude::len(taken_p0)), from_p2, &(|n_p3: &Nat, _: &Nat| if crate::check::types::has_text_f(taken_p0, &Text::from(format!("{}_{}", base_p1, n_p3))) {
        n_p3 + &Nat::from(1u32)
    } else {
        n_p3.clone()
    }))
}

/// ```prism
/// AddGn: fn Wx, Text, OutTy, GnKind, Nat -> ((Nat, Wx))
/// ```
pub fn add_gn_f(wx_p0: &Wx, name_p1: &Text, ty_p2: &crate::lower::model::OutTy, kind_p3: &GnKind, height_p4: &Nat) -> (Nat, Wx) {
    let id_p5 = crate::prelude::len(&wx_p0.gns_p);
    let wx2_p6 = {
        let mut this: Wx = wx_p0.clone();
        this.gns_p = crate::prelude::push(&this.gns_p, &Gn { id_p: id_p5.clone(), name_p: name_p1.clone(), ty_p: ty_p2.clone(), kind_p: kind_p3.clone(), height_p: height_p4.clone(), inputs_p: Array::new(), reads_p: Array::new(), floor_p: Nat::from(0u32), outs_p: Array::new() });
        this
    };
    (id_p5.clone(), wx2_p6.clone())
}

/// ```prism
/// Connect: fn Wx, EvRef, Sk -> Wx
/// ```
pub fn connect_f(wx_p0: &Wx, r_p1: &EvRef, sink_p2: &Sk) -> Wx {
    if &r_p1.owner_p != &wx_p0.node_p {
        crossed_f(wx_p0, &Text::from(format!("an event of node `{}` (its graph node {})", &r_p1.owner_p, &r_p1.node_p)))
    } else {
        {
            let mut this: Wx = wx_p0.clone();
            this.gns_p = crate::prelude::each(&this.gns_p, &(|n_p3: &Gn| if &n_p3.id_p == &r_p1.node_p {
                add_out_f(n_p3, &Out { pipe_f: r_p1.pipe_f.clone(), sink_p: sink_p2.clone() })
            } else {
                n_p3.clone()
            }));
            this
        }
    }
}

/// ```prism
/// Crossed: fn Wx, Text -> Wx
/// ```
pub fn crossed_f(wx_p0: &Wx, what_p1: &Text) -> Wx {
    let mut this: Wx = wx_p0.clone();
    this.build_p = crate::prelude::push(&this.build_p, &crate::lower::model::Do::DoExpr(crate::lower::expr::refusal_f(&Text::from(format!("{} read in node `{}` without a port (a lowering bug)", what_p1, &wx_p0.node_p)))));
    this
}

/// ```prism
/// AddOut: fn Gn, Out -> Gn
/// ```
pub fn add_out_f(n_p0: &Gn, o_p1: &Out) -> Gn {
    let mut this: Gn = n_p0.clone();
    this.outs_p = crate::prelude::push(&this.outs_p, o_p1);
    this
}

/// ```prism
/// AddField: fn Wx, Text, OutTy, Text, Ex -> Wx
/// ```
pub fn add_field_f(wx_p0: &Wx, name_p1: &Text, t_p2: &crate::lower::model::OutTy, doc_p3: &Text, init_p4: &crate::lower::model::Ex) -> Wx {
    let mut this: Wx = wx_p0.clone();
    this.fields_p = crate::prelude::push(&this.fields_p, &(name_p1.clone(), t_p2.clone(), doc_p3.clone()));
    this.inits_p = crate::prelude::push(&this.inits_p, &(name_p1.clone(), init_p4.clone()));
    this
}

/// ```prism
/// AddFieldLast: fn Wx, Text, OutTy, Text, Ex -> Wx
/// ```
pub fn add_field_last_f(wx_p0: &Wx, name_p1: &Text, t_p2: &crate::lower::model::OutTy, doc_p3: &Text, init_p4: &crate::lower::model::Ex) -> Wx {
    let mut this: Wx = wx_p0.clone();
    this.fields_p = crate::prelude::push(&this.fields_p, &(name_p1.clone(), t_p2.clone(), doc_p3.clone()));
    this.moves_p = crate::prelude::push(&this.moves_p, &(name_p1.clone(), init_p4.clone()));
    this
}

/// ```prism
/// GnOf: fn Wx, Nat -> Gn
/// ```
pub fn gn_of_f(wx_p0: &Wx, n_p1: &Nat) -> Gn {
    crate::prelude::or(&crate::prelude::index(&wx_p0.gns_p, n_p1), &Gn { id_p: n_p1.clone(), name_p: Text::lit("never"), ty_p: crate::lower::model::OutTy::OutUnit, kind_p: GnKind::GnNever, height_p: Nat::from(0u32), inputs_p: Array::new(), reads_p: Array::new(), floor_p: Nat::from(0u32), outs_p: Array::new() })
}

/// ```prism
/// BindPlain: fn Env, Env, Text, Text, OutTy -> ((Env, Env))
/// ```
pub fn bind_plain_f(benv_p0: &crate::lower::types::Env, menv_p1: &crate::lower::types::Env, nkey_p2: &Text, rs_p3: &Text, t_p4: &crate::lower::model::OutTy) -> (crate::lower::types::Env, crate::lower::types::Env) {
    (crate::lower::types::bind_f(benv_p0, nkey_p2, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(rs_p3.clone()), crate::lower::types::Holding::Owned, t_p4.clone())), crate::lower::types::bind_f(menv_p1, nkey_p2, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), rs_p3.clone()), crate::lower::types::Holding::Owned, t_p4.clone())))
}
