//! The module `Lower.Node`, from `target/bootstrap/src/prismc/lower/node/mod.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file. The runtime
//! side is reached from the crate, `crate::prelude` (and through it `::prism_rtl`), the
//! standard library from `::std`, and nothing is imported by name: a program's own type
//! (`Row`, `Option`) hides none of theirs. The traits are in scope unnamed, for their methods.

use crate::prelude::traits::*;
pub mod def;
pub mod dynamics;
pub mod elements;
pub mod finish;
pub mod keyed;
pub mod static_;
pub mod switch_;

/// `BundlePlace`:
///
/// ```prism
/// type BundlePlace = record:
/// ```
#[derive(::std::clone::Clone)]
pub struct BundlePlace {
    pub pos_p: crate::lower::model::Pos,
    pub stem_p: crate::prelude::Text,
    pub state_ty_p: crate::lower::model::OutTy,
    pub state_parts_p: crate::prelude::Nat,
    pub holds_p: crate::prelude::Array<(crate::prelude::Nat, crate::prelude::Text, crate::lower::model::OutTy)>,
    pub events_p: crate::prelude::Array<(crate::prelude::Nat, crate::lower::model::OutTy)>,
    pub state_accessor_p: crate::prelude::Text,
    pub event_accessor_p: crate::prelude::Text,
    pub first_variant_p: crate::lower::model::Ref,
}

impl crate::prelude::ToPod for BundlePlace {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("BundlePlace", vec![("pos", self.pos_p.to_pod()), ("stem", self.stem_p.to_pod()), ("stateTy", self.state_ty_p.to_pod()), ("stateParts", self.state_parts_p.to_pod()), ("holds", self.holds_p.to_pod()), ("events", self.events_p.to_pod()), ("stateAccessor", self.state_accessor_p.to_pod()), ("eventAccessor", self.event_accessor_p.to_pod()), ("firstVariant", self.first_variant_p.to_pod())])
    }
}

impl crate::prelude::FromPod for BundlePlace {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(BundlePlace { pos_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "pos")?)?, stem_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "stem")?)?, state_ty_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "stateTy")?)?, state_parts_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "stateParts")?)?, holds_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "holds")?)?, events_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "events")?)?, state_accessor_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "stateAccessor")?)?, event_accessor_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "eventAccessor")?)?, first_variant_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "firstVariant")?)? })
    }
}

/// `EvRef`:
///
/// ```prism
/// type EvRef = record:
/// ```
#[derive(::std::clone::Clone)]
pub struct EvRef {
    pub node_p: crate::prelude::Nat,
    pub owner_p: crate::prelude::Text,
    pub pipe_f: ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::model::Ex, ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::Ex) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::lower::model::Do>>>>)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::lower::model::Do>>>>,
}

/// `FlatDef`:
///
/// ```prism
/// type FlatDef = record:
/// ```
#[derive(::std::clone::Clone)]
pub struct FlatDef {
    pub name_p: crate::prelude::Text,
    pub outer_p: crate::prelude::Text,
    pub generation_p: crate::prelude::Text,
    pub held_p: bool,
    pub ty_p: crate::lower::model::OutTy,
}

impl crate::prelude::ToPod for FlatDef {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("FlatDef", vec![("name", self.name_p.to_pod()), ("outer", self.outer_p.to_pod()), ("generation", self.generation_p.to_pod()), ("held", self.held_p.to_pod()), ("ty", self.ty_p.to_pod())])
    }
}

impl crate::prelude::FromPod for FlatDef {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(FlatDef { name_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "name")?)?, outer_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "outer")?)?, generation_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "generation")?)?, held_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "held")?)?, ty_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "ty")?)? })
    }
}

/// `Gn`:
///
/// ```prism
/// type Gn = record:
/// ```
#[derive(::std::clone::Clone)]
pub struct Gn {
    pub id_p: crate::prelude::Nat,
    pub name_p: crate::prelude::Text,
    pub ty_p: crate::lower::model::OutTy,
    pub kind_p: GnKind,
    pub height_p: crate::prelude::Nat,
    pub inputs_p: crate::prelude::Array<crate::prelude::Text>,
    pub reads_p: crate::prelude::Array<Read>,
    pub floor_p: crate::prelude::Nat,
    pub outs_p: crate::prelude::Array<Out>,
}

/// `GnKind`:
///
/// ```prism
/// type GnKind = choice:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub enum GnKind {
    GnNamed,
    GnAnswer,
    GnStarted,
    GnDeferred,
    GnPort,
    GnMerge,
    GnUnion,
    GnBoth,
    GnExcept,
    GnMergeAll,
    GnGather,
    GnMergeList,
    GnUpdated,
    GnNever,
}

impl crate::prelude::Show for GnKind {
    fn show(&self, p: &mut crate::prelude::Printer) {
        match self {
            GnKind::GnNamed => p.choice("GnNamed", &[]),
            GnKind::GnAnswer => p.choice("GnAnswer", &[]),
            GnKind::GnStarted => p.choice("GnStarted", &[]),
            GnKind::GnDeferred => p.choice("GnDeferred", &[]),
            GnKind::GnPort => p.choice("GnPort", &[]),
            GnKind::GnMerge => p.choice("GnMerge", &[]),
            GnKind::GnUnion => p.choice("GnUnion", &[]),
            GnKind::GnBoth => p.choice("GnBoth", &[]),
            GnKind::GnExcept => p.choice("GnExcept", &[]),
            GnKind::GnMergeAll => p.choice("GnMergeAll", &[]),
            GnKind::GnGather => p.choice("GnGather", &[]),
            GnKind::GnMergeList => p.choice("GnMergeList", &[]),
            GnKind::GnUpdated => p.choice("GnUpdated", &[]),
            GnKind::GnNever => p.choice("GnNever", &[]),
        }
    }
}

impl crate::prelude::ToPod for GnKind {
    fn to_pod(&self) -> crate::prelude::Pod {
        match self {
            GnKind::GnNamed => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("GnNamed", 0), vec![]),
            GnKind::GnAnswer => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("GnAnswer", 1), vec![]),
            GnKind::GnStarted => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("GnStarted", 2), vec![]),
            GnKind::GnDeferred => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("GnDeferred", 3), vec![]),
            GnKind::GnPort => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("GnPort", 4), vec![]),
            GnKind::GnMerge => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("GnMerge", 5), vec![]),
            GnKind::GnUnion => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("GnUnion", 6), vec![]),
            GnKind::GnBoth => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("GnBoth", 7), vec![]),
            GnKind::GnExcept => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("GnExcept", 8), vec![]),
            GnKind::GnMergeAll => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("GnMergeAll", 9), vec![]),
            GnKind::GnGather => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("GnGather", 10), vec![]),
            GnKind::GnMergeList => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("GnMergeList", 11), vec![]),
            GnKind::GnUpdated => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("GnUpdated", 12), vec![]),
            GnKind::GnNever => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("GnNever", 13), vec![]),
        }
    }
}

impl crate::prelude::FromPod for GnKind {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        match p.structure() {
            crate::prelude::Pod::Choice(c, a) if &**c == "GnNamed" && a.len() == 0 => ::std::result::Result::Ok(GnKind::GnNamed),
            crate::prelude::Pod::Choice(c, a) if &**c == "GnAnswer" && a.len() == 0 => ::std::result::Result::Ok(GnKind::GnAnswer),
            crate::prelude::Pod::Choice(c, a) if &**c == "GnStarted" && a.len() == 0 => ::std::result::Result::Ok(GnKind::GnStarted),
            crate::prelude::Pod::Choice(c, a) if &**c == "GnDeferred" && a.len() == 0 => ::std::result::Result::Ok(GnKind::GnDeferred),
            crate::prelude::Pod::Choice(c, a) if &**c == "GnPort" && a.len() == 0 => ::std::result::Result::Ok(GnKind::GnPort),
            crate::prelude::Pod::Choice(c, a) if &**c == "GnMerge" && a.len() == 0 => ::std::result::Result::Ok(GnKind::GnMerge),
            crate::prelude::Pod::Choice(c, a) if &**c == "GnUnion" && a.len() == 0 => ::std::result::Result::Ok(GnKind::GnUnion),
            crate::prelude::Pod::Choice(c, a) if &**c == "GnBoth" && a.len() == 0 => ::std::result::Result::Ok(GnKind::GnBoth),
            crate::prelude::Pod::Choice(c, a) if &**c == "GnExcept" && a.len() == 0 => ::std::result::Result::Ok(GnKind::GnExcept),
            crate::prelude::Pod::Choice(c, a) if &**c == "GnMergeAll" && a.len() == 0 => ::std::result::Result::Ok(GnKind::GnMergeAll),
            crate::prelude::Pod::Choice(c, a) if &**c == "GnGather" && a.len() == 0 => ::std::result::Result::Ok(GnKind::GnGather),
            crate::prelude::Pod::Choice(c, a) if &**c == "GnMergeList" && a.len() == 0 => ::std::result::Result::Ok(GnKind::GnMergeList),
            crate::prelude::Pod::Choice(c, a) if &**c == "GnUpdated" && a.len() == 0 => ::std::result::Result::Ok(GnKind::GnUpdated),
            crate::prelude::Pod::Choice(c, a) if &**c == "GnNever" && a.len() == 0 => ::std::result::Result::Ok(GnKind::GnNever),
            other => ::prism_rtl::pod::mismatch("a GnKind", other),
        }
    }
}

/// `HostDef`:
///
/// ```prism
/// type HostDef = record:
/// ```
#[derive(::std::clone::Clone)]
pub struct HostDef {
    pub pos_p: crate::lower::model::Pos,
    pub name_p: crate::prelude::Text,
    pub scope_p: crate::prelude::Nat,
}

impl crate::prelude::ToPod for HostDef {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("HostDef", vec![("pos", self.pos_p.to_pod()), ("name", self.name_p.to_pod()), ("scope", self.scope_p.to_pod())])
    }
}

impl crate::prelude::FromPod for HostDef {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(HostDef { pos_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "pos")?)?, name_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "name")?)?, scope_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "scope")?)? })
    }
}

/// `Out`:
///
/// ```prism
/// type Out = record:
/// ```
#[derive(::std::clone::Clone)]
pub struct Out {
    pub pipe_f: ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::model::Ex, ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::Ex) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::lower::model::Do>>>>)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::lower::model::Do>>>>,
    pub sink_p: Sk,
}

/// `PendingRow`:
///
/// ```prism
/// type PendingRow = record:
/// ```
#[derive(::std::clone::Clone)]
pub struct PendingRow {
    pub wx_p: Wx,
    pub qk_p: crate::prelude::Text,
    pub params_p: crate::prelude::Array<(crate::prelude::Text, crate::lower::model::OutTy)>,
    pub gathers_p: crate::prelude::Array<crate::prelude::Nat>,
}

/// `Place`:
///
/// ```prism
/// type Place = record:
/// ```
#[derive(::std::clone::Clone)]
pub struct Place {
    pub pos_p: crate::lower::model::Pos,
    pub level_p: crate::lower::model::Ex,
    pub getter_p: crate::prelude::Text,
    pub reads_p: crate::prelude::Array<Read>,
    pub entry_p: crate::prelude::Text,
    pub watch_p: crate::prelude::Text,
}

impl crate::prelude::ToPod for Place {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("Place", vec![("pos", self.pos_p.to_pod()), ("level", self.level_p.to_pod()), ("getter", self.getter_p.to_pod()), ("reads", self.reads_p.to_pod()), ("entry", self.entry_p.to_pod()), ("watch", self.watch_p.to_pod())])
    }
}

impl crate::prelude::FromPod for Place {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(Place { pos_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "pos")?)?, level_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "level")?)?, getter_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "getter")?)?, reads_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "reads")?)?, entry_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "entry")?)?, watch_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "watch")?)? })
    }
}

/// `Read`:
///
/// ```prism
/// type Read = choice:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub enum Read {
    OwnRead(crate::prelude::Text),
    ParentRead(crate::prelude::Text),
}

impl crate::prelude::Show for Read {
    fn show(&self, p: &mut crate::prelude::Printer) {
        match self {
            Read::OwnRead(a0) => p.choice("OwnRead", &[a0]),
            Read::ParentRead(a0) => p.choice("ParentRead", &[a0]),
        }
    }
}

impl crate::prelude::ToPod for Read {
    fn to_pod(&self) -> crate::prelude::Pod {
        match self {
            Read::OwnRead(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("OwnRead", 0), vec![a0.to_pod()]),
            Read::ParentRead(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("ParentRead", 1), vec![a0.to_pod()]),
        }
    }
}

impl crate::prelude::FromPod for Read {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        match p.structure() {
            crate::prelude::Pod::Choice(c, a) if &**c == "OwnRead" && a.len() == 1 => ::std::result::Result::Ok(Read::OwnRead(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "ParentRead" && a.len() == 1 => ::std::result::Result::Ok(Read::ParentRead(crate::prelude::FromPod::from_pod(&a[0])?)),
            other => ::prism_rtl::pod::mismatch("a Read", other),
        }
    }
}

/// `RowMarks`:
///
/// ```prism
/// type RowMarks = record:
/// ```
#[derive(::std::clone::Clone)]
pub struct RowMarks {
    pub builder_p: crate::prelude::Text,
    pub reads_p: crate::prelude::Array<Read>,
    pub wrote_p: crate::prelude::Array<crate::prelude::Text>,
    pub builds_p: crate::prelude::Array<crate::prelude::Text>,
    pub kind_p: crate::lower::model::RowKind,
}

impl crate::prelude::ToPod for RowMarks {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("RowMarks", vec![("builder", self.builder_p.to_pod()), ("reads", self.reads_p.to_pod()), ("wrote", self.wrote_p.to_pod()), ("builds", self.builds_p.to_pod()), ("kind", self.kind_p.to_pod())])
    }
}

impl crate::prelude::FromPod for RowMarks {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(RowMarks { builder_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "builder")?)?, reads_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "reads")?)?, wrote_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "wrote")?)?, builds_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "builds")?)?, kind_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "kind")?)? })
    }
}

/// `Sk`:
///
/// ```prism
/// type Sk = choice:
/// ```
#[derive(::std::clone::Clone)]
pub enum Sk {
    SkNode(crate::prelude::Nat),
    SkIn(crate::prelude::Nat, crate::prelude::Nat),
    SkHold(crate::prelude::Text),
    SkRequest(crate::lower::model::Pos, crate::prelude::Text),
    SkResult,
    SkArm(crate::prelude::Text),
    SkLater(crate::prelude::Text),
    SkCycle(crate::prelude::Text, crate::prelude::Text, crate::prelude::Nat),
    SkUp(crate::prelude::Text),
    SkPort(crate::prelude::Text),
    SkMachine(crate::prelude::Text, crate::lower::model::Ex, crate::prelude::Nat),
    SkDistinct(crate::prelude::Text),
    SkPerKey(crate::prelude::Text),
}

impl crate::prelude::ToPod for Sk {
    fn to_pod(&self) -> crate::prelude::Pod {
        match self {
            Sk::SkNode(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("SkNode", 0), vec![a0.to_pod()]),
            Sk::SkIn(a0, a1) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("SkIn", 1), vec![a0.to_pod(), a1.to_pod()]),
            Sk::SkHold(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("SkHold", 2), vec![a0.to_pod()]),
            Sk::SkRequest(a0, a1) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("SkRequest", 3), vec![a0.to_pod(), a1.to_pod()]),
            Sk::SkResult => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("SkResult", 4), vec![]),
            Sk::SkArm(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("SkArm", 5), vec![a0.to_pod()]),
            Sk::SkLater(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("SkLater", 6), vec![a0.to_pod()]),
            Sk::SkCycle(a0, a1, a2) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("SkCycle", 7), vec![a0.to_pod(), a1.to_pod(), a2.to_pod()]),
            Sk::SkUp(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("SkUp", 8), vec![a0.to_pod()]),
            Sk::SkPort(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("SkPort", 9), vec![a0.to_pod()]),
            Sk::SkMachine(a0, a1, a2) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("SkMachine", 10), vec![a0.to_pod(), a1.to_pod(), a2.to_pod()]),
            Sk::SkDistinct(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("SkDistinct", 11), vec![a0.to_pod()]),
            Sk::SkPerKey(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("SkPerKey", 12), vec![a0.to_pod()]),
        }
    }
}

impl crate::prelude::FromPod for Sk {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        match p.structure() {
            crate::prelude::Pod::Choice(c, a) if &**c == "SkNode" && a.len() == 1 => ::std::result::Result::Ok(Sk::SkNode(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "SkIn" && a.len() == 2 => ::std::result::Result::Ok(Sk::SkIn(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "SkHold" && a.len() == 1 => ::std::result::Result::Ok(Sk::SkHold(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "SkRequest" && a.len() == 2 => ::std::result::Result::Ok(Sk::SkRequest(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "SkResult" && a.len() == 0 => ::std::result::Result::Ok(Sk::SkResult),
            crate::prelude::Pod::Choice(c, a) if &**c == "SkArm" && a.len() == 1 => ::std::result::Result::Ok(Sk::SkArm(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "SkLater" && a.len() == 1 => ::std::result::Result::Ok(Sk::SkLater(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "SkCycle" && a.len() == 3 => ::std::result::Result::Ok(Sk::SkCycle(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?, crate::prelude::FromPod::from_pod(&a[2])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "SkUp" && a.len() == 1 => ::std::result::Result::Ok(Sk::SkUp(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "SkPort" && a.len() == 1 => ::std::result::Result::Ok(Sk::SkPort(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "SkMachine" && a.len() == 3 => ::std::result::Result::Ok(Sk::SkMachine(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?, crate::prelude::FromPod::from_pod(&a[2])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "SkDistinct" && a.len() == 1 => ::std::result::Result::Ok(Sk::SkDistinct(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "SkPerKey" && a.len() == 1 => ::std::result::Result::Ok(Sk::SkPerKey(crate::prelude::FromPod::from_pod(&a[0])?)),
            other => ::prism_rtl::pod::mismatch("a Sk", other),
        }
    }
}

/// `SnapDef`:
///
/// ```prism
/// type SnapDef = record:
/// ```
#[derive(::std::clone::Clone)]
pub struct SnapDef {
    pub name_p: crate::prelude::Text,
    pub live_p: crate::prelude::Text,
    pub ty_p: crate::lower::model::OutTy,
    pub eq_p: bool,
    pub builder_p: crate::prelude::Text,
    pub before_p: bool,
    pub what_p: crate::prelude::Text,
}

impl crate::prelude::ToPod for SnapDef {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("SnapDef", vec![("name", self.name_p.to_pod()), ("live", self.live_p.to_pod()), ("ty", self.ty_p.to_pod()), ("eq", self.eq_p.to_pod()), ("builder", self.builder_p.to_pod()), ("before", self.before_p.to_pod()), ("what", self.what_p.to_pod())])
    }
}

impl crate::prelude::FromPod for SnapDef {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(SnapDef { name_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "name")?)?, live_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "live")?)?, ty_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "ty")?)?, eq_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "eq")?)?, builder_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "builder")?)?, before_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "before")?)?, what_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "what")?)? })
    }
}

/// `Wres`:
///
/// ```prism
/// type Wres = choice:
/// ```
#[derive(::std::clone::Clone)]
pub enum Wres {
    WrEv(EvRef),
    WrDyn(crate::lower::model::Ex, crate::prelude::Array<Read>, crate::lower::model::OutTy),
    WrPlain(crate::lower::model::Ex, crate::lower::model::OutTy),
    WrLate(crate::lower::model::Ex, crate::lower::model::OutTy),
    WrUnit,
    WrHosted(::std::rc::Rc<Wres>, crate::lower::types::Bn),
    WrParts(crate::prelude::Array<Wres>),
}

/// `Wx`:
///
/// ```prism
/// type Wx = record:
/// ```
#[derive(::std::clone::Clone)]
pub struct Wx {
    pub lx_p: crate::lower::Lx,
    pub node_p: crate::prelude::Text,
    pub pos_p: crate::lower::model::Pos,
    pub gns_p: crate::prelude::Array<Gn>,
    pub fields_p: crate::prelude::Array<(crate::prelude::Text, crate::lower::model::OutTy, crate::prelude::Text)>,
    pub inits_p: crate::prelude::Array<(crate::prelude::Text, crate::lower::model::Ex)>,
    pub moves_p: crate::prelude::Array<(crate::prelude::Text, crate::lower::model::Ex)>,
    pub lets_p: crate::prelude::Array<crate::lower::model::Do>,
    pub build_p: crate::prelude::Array<crate::lower::model::Do>,
    pub places_p: crate::prelude::Array<Place>,
    pub answers_p: crate::prelude::Array<(crate::lower::model::Pos, crate::prelude::Nat, crate::lower::model::OutTy, crate::prelude::Text)>,
    pub started_p: crate::prelude::Array<crate::prelude::Nat>,
    pub defers_p: crate::prelude::Array<(crate::prelude::Text, crate::prelude::Nat)>,
    pub getters_p: crate::prelude::Array<crate::lower::model::MethDef>,
    pub dyn_reads_p: crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<Read>>,
    pub taken_p: crate::prelude::Array<crate::prelude::Text>,
    pub fallible_p: bool,
    pub based_o: ::std::option::Option<crate::prelude::Nat>,
    pub inlining_p: crate::prelude::Array<crate::prelude::Text>,
    pub result_p: Wres,
    pub rows_p: crate::prelude::Array<crate::lower::model::NodeDef>,
    pub builders_p: crate::prelude::Array<crate::lower::model::ForDef>,
    pub let_caches_p: crate::prelude::Array<crate::prelude::Text>,
    pub build_holds_p: crate::prelude::Array<Read>,
    pub up_sink_p: crate::prelude::Text,
    pub gens_p: crate::prelude::Array<crate::lower::model::GenDef>,
    pub gen_holds_p: crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<Read>)>,
    pub ports_p: crate::prelude::Array<crate::prelude::Text>,
    pub subs_p: crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy)>,
    pub parent_env_p: crate::lower::types::Env,
    pub hosts_p: crate::prelude::Array<HostDef>,
    pub dyn_places_p: crate::prelude::Array<(crate::lower::model::Pos, crate::prelude::Text, crate::lower::model::OutTy, crate::prelude::Text)>,
    pub bundles_p: crate::prelude::Array<BundlePlace>,
    pub scopes_p: crate::prelude::Array<crate::prelude::Text>,
    pub hosted_by_o: ::std::option::Option<crate::prelude::Text>,
    pub valued_as_o: ::std::option::Option<bool>,
    pub root_dyns_p: crate::prelude::Array<(crate::lower::model::Ex, crate::prelude::Array<Read>, crate::lower::model::OutTy)>,
    pub gen_of_p: crate::prelude::Text,
    pub row_marks_p: crate::prelude::Array<RowMarks>,
    pub pending_p: crate::prelude::Array<PendingRow>,
    pub floors_p: crate::prelude::Map<crate::prelude::Text, crate::prelude::Nat>,
    pub snaps_p: crate::prelude::Array<SnapDef>,
    pub result_moved_p: crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<Read>)>,
    pub dyn_answers_p: crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<Read>)>,
    pub inited_p: crate::prelude::Array<crate::prelude::Text>,
    pub flattens_p: crate::prelude::Array<FlatDef>,
    pub clause_results_p: crate::prelude::Array<crate::prelude::Text>,
    pub switches_p: crate::prelude::Array<crate::prelude::Text>,
    pub late_inits_p: crate::prelude::Array<crate::lower::model::Do>,
    pub late_asks_p: crate::prelude::Array<crate::lower::model::Do>,
    pub whole_result_at_p: crate::prelude::Text,
    pub early_choices_p: crate::prelude::Array<crate::prelude::Text>,
    pub deferred_gens_p: crate::prelude::Array<crate::prelude::Text>,
    pub late_hosts_p: crate::prelude::Array<crate::prelude::Nat>,
    pub late_firsts_p: crate::prelude::Array<(crate::prelude::Nat, crate::prelude::Array<crate::lower::model::Do>)>,
    pub late_starts_p: crate::prelude::Array<(crate::prelude::Nat, crate::prelude::Array<crate::lower::model::Do>)>,
    pub late_places_p: crate::prelude::Array<crate::prelude::Text>,
    pub late_numbered_p: crate::prelude::Array<crate::prelude::Text>,
    pub base_late_p: bool,
    pub late_gens_p: bool,
    pub late_row_gens_p: crate::prelude::Array<crate::prelude::Text>,
    pub gen_phase_p: crate::prelude::Nat,
    pub numbered_by_p: crate::prelude::Array<crate::lower::model::Do>,
    pub unplaced_hosts_p: crate::prelude::Array<crate::prelude::Text>,
}

/// ```prism
/// IdPipe: unbounded fn Ex, (unbounded fn Ex -> [Do]) -> [Do]
/// ```
pub fn id_pipe_f(x_p0: &crate::lower::model::Ex, k_f1: &::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::Ex) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::lower::model::Do>>>>) -> crate::prelude::Array<crate::lower::model::Do> {
    crate::prelude::run_to_end(k_f1(x_p0.clone()))
}

/// The step machine of `IdPipe`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// IdPipe: unbounded fn Ex, (unbounded fn Ex -> [Do]) -> [Do]
/// ```
pub struct IdPipe {
    pub x_p0: crate::lower::model::Ex,
    pub k_f1: ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::Ex) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::lower::model::Do>>>>,
}

impl ::prism_rtl::Job<crate::prelude::Array<crate::lower::model::Do>> for IdPipe {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<crate::lower::model::Do>> {
        let x_p0 = &self.x_p0;
        let k_f1 = &self.k_f1;
        k_f1(x_p0.clone()).cycle()
    }
}

/// `Start IdPipe, x`: what the function value is when passed to `@Run`.
pub fn start_id_pipe_f(x_p0: crate::lower::model::Ex, k_f1: ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::Ex) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::lower::model::Do>>>>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::lower::model::Do>>> {
    ::std::rc::Rc::new(IdPipe { x_p0, k_f1 })
}

/// ```prism
/// EvRefOf: fn Wx, Nat -> EvRef
/// ```
pub fn ev_ref_of_f(wx_p0: &Wx, n_p1: &crate::prelude::Nat) -> EvRef {
    EvRef { node_p: n_p1.clone(), owner_p: wx_p0.node_p.clone(), pipe_f: ::std::rc::Rc::new(|(a0, a1): (crate::lower::model::Ex, ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::Ex) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::lower::model::Do>>>>)| crate::prelude::entered(start_id_pipe_f(a0, a1))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::model::Ex, ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::Ex) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::lower::model::Do>>>>)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::lower::model::Do>>>> }
}

/// ```prism
/// KindWord: fn GnKind -> Text
/// ```
pub fn kind_word_f(k_p0: &GnKind) -> crate::prelude::Text {
    match k_p0 {
        GnKind::GnNamed => crate::prelude::Text::lit("named"),
        GnKind::GnAnswer => crate::prelude::Text::lit("answer"),
        GnKind::GnStarted => crate::prelude::Text::lit("started"),
        GnKind::GnDeferred => crate::prelude::Text::lit("deferred"),
        GnKind::GnPort => crate::prelude::Text::lit("port"),
        GnKind::GnMerge => crate::prelude::Text::lit("merge"),
        GnKind::GnUnion => crate::prelude::Text::lit("union"),
        GnKind::GnBoth => crate::prelude::Text::lit("both"),
        GnKind::GnExcept => crate::prelude::Text::lit("except"),
        GnKind::GnMergeAll => crate::prelude::Text::lit("mergeall"),
        GnKind::GnGather => crate::prelude::Text::lit("gather"),
        GnKind::GnMergeList => crate::prelude::Text::lit("mergelist"),
        GnKind::GnUpdated => crate::prelude::Text::lit("updated"),
        GnKind::GnNever => crate::prelude::Text::lit("never"),
    }
}

/// ```prism
/// HasRead: fn [Read], Read -> Bool
/// ```
pub fn has_read_f(rs_p0: &crate::prelude::Array<Read>, r_p1: &Read) -> bool {
    crate::prelude::fold(rs_p0, &false, &(|seen_p2: &bool, x_p3: &Read| *seen_p2 || (x_p3 == r_p1)))
}

/// ```prism
/// AddRead: fn [Read], Read -> [Read]
/// ```
pub fn add_read_f(rs_p0: &crate::prelude::Array<Read>, r_p1: &Read) -> crate::prelude::Array<Read> {
    if has_read_f(rs_p0, r_p1) { rs_p0.clone() } else { crate::prelude::push(rs_p0, r_p1) }
}

/// ```prism
/// UnionReads: fn [Read], [Read] -> [Read]
/// ```
pub fn union_reads_f(xs_p0: &crate::prelude::Array<Read>, ys_p1: &crate::prelude::Array<Read>) -> crate::prelude::Array<Read> {
    crate::prelude::fold(ys_p1, xs_p0, &(|acc_p2: &crate::prelude::Array<Read>, y_p3: &Read| add_read_f(acc_p2, y_p3)))
}

/// ```prism
/// let nodeHooks
/// ```
pub fn node_hooks_p() -> crate::prelude::Array<crate::prelude::Text> {
    crate::prelude::Array::from(vec![crate::prelude::Text::lit("path"), crate::prelude::Text::lit("build"), crate::prelude::Text::lit("wake"), crate::prelude::Text::lit("started"), crate::prelude::Text::lit("deferred"), crate::prelude::Text::lit("answer"), crate::prelude::Text::lit("push"), crate::prelude::Text::lit("swap"), crate::prelude::Text::lit("leave"), crate::prelude::Text::lit("patch"), crate::prelude::Text::lit("clean_up"), crate::prelude::Text::lit("edges"), crate::prelude::Text::lit("release"), crate::prelude::Text::lit("leave_row"), crate::prelude::Text::lit("remove_places")])
}

/// ```prism
/// UnderItsPath: fn Wx, ?Text -> Wx
/// ```
pub fn under_its_path_f(wx_p0: &Wx, hosted_by_o1: &::std::option::Option<crate::prelude::Text>) -> Wx {
    match hosted_by_o1 {
        ::std::option::Option::Some(_) => {
            let mut this: Wx = wx_p0.clone();
            this.lets_p = crate::prelude::append(&crate::prelude::Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("enclosing")), crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("prism_rtl::host_under")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XVar(crate::prelude::Text::lit("enclosing")), crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("path"))))])))]), &this.lets_p);
            this
        },
        ::std::option::Option::None => wx_p0.clone(),
    }
}

/// ```prism
/// NewWx: fn Lx, Text, [((Text, OutTy, Text))], [((Text, Ex))], [((Text, Ex))], [MethDef], (Text ==> [Read]), [Text], [Text], ?Text -> Wx
/// ```
pub fn new_wx_f(lx_p0: &crate::lower::Lx, name_p1: &crate::prelude::Text, fields_p2: &crate::prelude::Array<(crate::prelude::Text, crate::lower::model::OutTy, crate::prelude::Text)>, inits_p3: &crate::prelude::Array<(crate::prelude::Text, crate::lower::model::Ex)>, moves_p4: &crate::prelude::Array<(crate::prelude::Text, crate::lower::model::Ex)>, getters_p5: &crate::prelude::Array<crate::lower::model::MethDef>, dyn_reads_p6: &crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<Read>>, taken_p7: &crate::prelude::Array<crate::prelude::Text>, inlining_p8: &crate::prelude::Array<crate::prelude::Text>, hosted_by_o9: &::std::option::Option<crate::prelude::Text>) -> Wx {
    let hosted_fields_pa = match hosted_by_o9 {
        ::std::option::Option::Some(_) => crate::prelude::Array::from(vec![(crate::prelude::Text::lit("enclosing"), crate::lower::types::host_of_ty_p(), crate::prelude::Text::lit("the host whose document this row\'s places are entries of (pick HO)"))]),
        ::std::option::Option::None => crate::prelude::Array::new(),
    };
    let hosted_inits_pb = match hosted_by_o9 {
        ::std::option::Option::Some(_) => crate::prelude::Array::from(vec![(crate::prelude::Text::lit("enclosing"), crate::lower::model::Ex::XVar(crate::prelude::Text::lit("enclosing")))]),
        ::std::option::Option::None => crate::prelude::Array::new(),
    };
    Wx { lx_p: lx_p0.clone(), node_p: name_p1.clone(), pos_p: crate::lower::model::pos0_p(), gns_p: crate::prelude::Array::new(), fields_p: crate::prelude::append(fields_p2, &hosted_fields_pa), inits_p: inits_p3.clone(), moves_p: crate::prelude::append(moves_p4, &hosted_inits_pb), lets_p: crate::prelude::Array::new(), build_p: crate::prelude::Array::new(), places_p: crate::prelude::Array::new(), answers_p: crate::prelude::Array::new(), started_p: crate::prelude::Array::new(), defers_p: crate::prelude::Array::new(), getters_p: getters_p5.clone(), dyn_reads_p: dyn_reads_p6.clone(), taken_p: crate::prelude::push(taken_p7, &crate::prelude::Text::lit("enclosing")), fallible_p: false, based_o: ::std::option::Option::None, inlining_p: inlining_p8.clone(), result_p: Wres::WrUnit, rows_p: crate::prelude::Array::new(), builders_p: crate::prelude::Array::new(), let_caches_p: crate::prelude::Array::new(), build_holds_p: crate::prelude::Array::new(), up_sink_p: crate::prelude::Text::lit(""), gens_p: crate::prelude::Array::new(), gen_holds_p: crate::prelude::Array::new(), ports_p: crate::prelude::Array::new(), subs_p: crate::prelude::Array::new(), parent_env_p: crate::lower::types::empty_env_p(), hosts_p: crate::prelude::Array::new(), dyn_places_p: crate::prelude::Array::new(), bundles_p: crate::prelude::Array::new(), scopes_p: crate::prelude::Array::new(), hosted_by_o: hosted_by_o9.clone(), valued_as_o: ::std::option::Option::None, root_dyns_p: crate::prelude::Array::new(), gen_of_p: crate::prelude::Text::lit(""), row_marks_p: crate::prelude::Array::new(), pending_p: crate::prelude::Array::new(), floors_p: crate::prelude::Map::new(), snaps_p: crate::prelude::Array::new(), result_moved_p: crate::prelude::Array::new(), dyn_answers_p: crate::prelude::Array::new(), inited_p: crate::prelude::Array::new(), flattens_p: crate::prelude::Array::new(), clause_results_p: crate::prelude::Array::new(), switches_p: crate::prelude::Array::new(), late_inits_p: crate::prelude::Array::new(), late_asks_p: crate::prelude::Array::new(), whole_result_at_p: crate::prelude::Text::lit(""), early_choices_p: crate::prelude::Array::new(), deferred_gens_p: crate::prelude::Array::new(), late_hosts_p: crate::prelude::Array::new(), late_firsts_p: crate::prelude::Array::new(), late_starts_p: crate::prelude::Array::new(), late_places_p: crate::prelude::Array::new(), late_numbered_p: crate::prelude::Array::new(), base_late_p: false, late_gens_p: false, late_row_gens_p: crate::prelude::Array::new(), gen_phase_p: crate::prelude::Nat::from(0u32), numbered_by_p: crate::prelude::Array::new(), unplaced_hosts_p: crate::prelude::Array::new() }
}

/// ```prism
/// FreshName: fn Wx, Text -> ((Text, Wx))
/// ```
pub fn fresh_name_f(wx_p0: &Wx, base_p1: &crate::prelude::Text) -> (crate::prelude::Text, Wx) {
    let pick_p2 = if !crate::check::types::has_text_f(&wx_p0.taken_p, base_p1) {
        base_p1.clone()
    } else {
        crate::prelude::Text::from(format!("{}_{}", base_p1, &first_free_f(&wx_p0.taken_p, base_p1, &crate::prelude::Nat::from(2u32))))
    };
    let wx2_p3 = {
        let mut this: Wx = wx_p0.clone();
        this.taken_p = crate::prelude::push(&this.taken_p, &pick_p2);
        this
    };
    (pick_p2.clone(), wx2_p3.clone())
}

/// ```prism
/// FirstFree: fn [Text], Text, Nat -> Nat
/// ```
pub fn first_free_f(taken_p0: &crate::prelude::Array<crate::prelude::Text>, base_p1: &crate::prelude::Text, from_p2: &crate::prelude::Nat) -> crate::prelude::Nat {
    crate::prelude::fold(&crate::check::errors::range0_f(&crate::prelude::len(taken_p0)), from_p2, &(|n_p3: &crate::prelude::Nat, _: &crate::prelude::Nat| if crate::check::types::has_text_f(taken_p0, &crate::prelude::Text::from(format!("{}_{}", base_p1, n_p3))) {
        n_p3 + &crate::prelude::Nat::from(1u32)
    } else {
        n_p3.clone()
    }))
}

/// ```prism
/// AddGn: fn Wx, Text, OutTy, GnKind, Nat -> ((Nat, Wx))
/// ```
pub fn add_gn_f(wx_p0: &Wx, name_p1: &crate::prelude::Text, ty_p2: &crate::lower::model::OutTy, kind_p3: &GnKind, height_p4: &crate::prelude::Nat) -> (crate::prelude::Nat, Wx) {
    let id_p5 = crate::prelude::len(&wx_p0.gns_p);
    let wx2_p6 = {
        let mut this: Wx = wx_p0.clone();
        this.gns_p = crate::prelude::push(&this.gns_p, &Gn { id_p: id_p5.clone(), name_p: name_p1.clone(), ty_p: ty_p2.clone(), kind_p: kind_p3.clone(), height_p: height_p4.clone(), inputs_p: crate::prelude::Array::new(), reads_p: crate::prelude::Array::new(), floor_p: crate::prelude::Nat::from(0u32), outs_p: crate::prelude::Array::new() });
        this
    };
    (id_p5.clone(), wx2_p6.clone())
}

/// ```prism
/// Connect: fn Wx, EvRef, Sk -> Wx
/// ```
pub fn connect_f(wx_p0: &Wx, r_p1: &EvRef, sink_p2: &Sk) -> Wx {
    if &r_p1.owner_p != &wx_p0.node_p {
        crossed_f(wx_p0, &crate::prelude::Text::from(format!("an event of node `{}` (its graph node {})", &r_p1.owner_p, &r_p1.node_p)))
    } else {
        {
            let mut this: Wx = wx_p0.clone();
            this.gns_p = crate::prelude::each(&this.gns_p, &(|n_p3: &Gn| if &n_p3.id_p == &r_p1.node_p {
                add_out_f(n_p3, &Out { pipe_f: r_p1.pipe_f.clone(), sink_p: sink_p2.clone() })
            } else {
                n_p3.clone()
            }));
            this
        }
    }
}

/// ```prism
/// Crossed: fn Wx, Text -> Wx
/// ```
pub fn crossed_f(wx_p0: &Wx, what_p1: &crate::prelude::Text) -> Wx {
    let mut this: Wx = wx_p0.clone();
    this.build_p = crate::prelude::push(&this.build_p, &crate::lower::expr::internal_bug_do_f(&crate::prelude::Text::from(format!("{} read in node `{}` without a port", what_p1, &wx_p0.node_p))));
    this
}

/// ```prism
/// AddOut: fn Gn, Out -> Gn
/// ```
pub fn add_out_f(n_p0: &Gn, o_p1: &Out) -> Gn {
    let mut this: Gn = n_p0.clone();
    this.outs_p = crate::prelude::push(&this.outs_p, o_p1);
    this
}

/// ```prism
/// AddField: fn Wx, Text, OutTy, Text, Ex -> Wx
/// ```
pub fn add_field_f(wx_p0: &Wx, name_p1: &crate::prelude::Text, t_p2: &crate::lower::model::OutTy, doc_p3: &crate::prelude::Text, init_p4: &crate::lower::model::Ex) -> Wx {
    let mut this: Wx = wx_p0.clone();
    this.fields_p = crate::prelude::push(&this.fields_p, &(name_p1.clone(), t_p2.clone(), doc_p3.clone()));
    this.inits_p = crate::prelude::push(&this.inits_p, &(name_p1.clone(), init_p4.clone()));
    this
}

/// ```prism
/// AddFieldLast: fn Wx, Text, OutTy, Text, Ex -> Wx
/// ```
pub fn add_field_last_f(wx_p0: &Wx, name_p1: &crate::prelude::Text, t_p2: &crate::lower::model::OutTy, doc_p3: &crate::prelude::Text, init_p4: &crate::lower::model::Ex) -> Wx {
    let mut this: Wx = wx_p0.clone();
    this.fields_p = crate::prelude::push(&this.fields_p, &(name_p1.clone(), t_p2.clone(), doc_p3.clone()));
    this.moves_p = crate::prelude::push(&this.moves_p, &(name_p1.clone(), init_p4.clone()));
    this
}

/// ```prism
/// GnOf: fn Wx, Nat -> Gn
/// ```
pub fn gn_of_f(wx_p0: &Wx, n_p1: &crate::prelude::Nat) -> Gn {
    crate::prelude::or(&crate::prelude::index(&wx_p0.gns_p, n_p1), &Gn { id_p: n_p1.clone(), name_p: crate::prelude::Text::lit("never"), ty_p: crate::lower::model::OutTy::OutUnit, kind_p: GnKind::GnNever, height_p: crate::prelude::Nat::from(0u32), inputs_p: crate::prelude::Array::new(), reads_p: crate::prelude::Array::new(), floor_p: crate::prelude::Nat::from(0u32), outs_p: crate::prelude::Array::new() })
}

/// ```prism
/// BindPlain: fn Env, Env, Text, Text, OutTy -> ((Env, Env))
/// ```
pub fn bind_plain_f(benv_p0: &crate::lower::types::Env, menv_p1: &crate::lower::types::Env, nkey_p2: &crate::prelude::Text, rs_p3: &crate::prelude::Text, t_p4: &crate::lower::model::OutTy) -> (crate::lower::types::Env, crate::lower::types::Env) {
    (crate::lower::types::bind_f(benv_p0, nkey_p2, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(rs_p3.clone()), crate::lower::types::Holding::Owned, t_p4.clone())), crate::lower::types::bind_f(menv_p1, nkey_p2, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), rs_p3.clone()), crate::lower::types::Holding::Owned, t_p4.clone())))
}
