//! The module `Lower.Node`, from `target/bootstrap/src/prismc/lower/node/mod.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// `ClauseRow`:
///
/// ```prism
/// type ClauseRow = record:
/// ```
#[derive(Clone)]
pub struct ClauseRow {
    pub case: GenCase,
    pub parent: Wx,
    pub width: Nat,
}

/// `EvRef`:
///
/// ```prism
/// type EvRef = record:
/// ```
#[derive(Clone)]
pub struct EvRef {
    pub node_: Nat,
    pub owner: Text,
    pub pipe: Rc<dyn Fn((crate::lower::model::Ex, Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>)) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>,
}

/// `FlatDef`:
///
/// ```prism
/// type FlatDef = record:
/// ```
#[derive(Clone)]
pub struct FlatDef {
    pub name: Text,
    pub outer: Text,
    pub generation: Text,
    pub ty: crate::lower::model::OutTy,
}

impl ToPod for FlatDef {
    fn to_pod(&self) -> Pod {
        Pod::record("FlatDef", vec![("name", self.name.to_pod()), ("outer", self.outer.to_pod()), ("generation", self.generation.to_pod()), ("ty", self.ty.to_pod())])
    }
}

impl FromPod for FlatDef {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(FlatDef { name: FromPod::from_pod(field(p, "name")?)?, outer: FromPod::from_pod(field(p, "outer")?)?, generation: FromPod::from_pod(field(p, "generation")?)?, ty: FromPod::from_pod(field(p, "ty")?)? })
    }
}

/// `GenCase`:
///
/// ```prism
/// type GenCase = record:
/// ```
#[derive(Clone)]
pub struct GenCase {
    pub node_: crate::lower::model::NodeDef,
    pub params: Array<(Text, crate::lower::model::OutTy)>,
    pub pat: crate::lower::model::Pa,
    pub conds: Array<crate::lower::model::Cc>,
    pub passed: Array<crate::lower::model::Ex>,
}

impl ToPod for GenCase {
    fn to_pod(&self) -> Pod {
        Pod::record("GenCase", vec![("node", self.node_.to_pod()), ("params", self.params.to_pod()), ("pat", self.pat.to_pod()), ("conds", self.conds.to_pod()), ("passed", self.passed.to_pod())])
    }
}

impl FromPod for GenCase {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(GenCase { node_: FromPod::from_pod(field(p, "node")?)?, params: FromPod::from_pod(field(p, "params")?)?, pat: FromPod::from_pod(field(p, "pat")?)?, conds: FromPod::from_pod(field(p, "conds")?)?, passed: FromPod::from_pod(field(p, "passed")?)? })
    }
}

/// `GenRow`:
///
/// ```prism
/// type GenRow = record:
/// ```
#[derive(Clone)]
pub struct GenRow {
    pub node_: crate::lower::model::NodeDef,
    pub parent: Wx,
    pub dyn_result: Option<crate::lower::model::OutTy>,
}

/// `Gn`:
///
/// ```prism
/// type Gn = record:
/// ```
#[derive(Clone)]
pub struct Gn {
    pub id: Nat,
    pub name: Text,
    pub ty: crate::lower::model::OutTy,
    pub kind: GnKind,
    pub height: Nat,
    pub inputs: Array<Text>,
    pub reads: Array<Read>,
    pub floor: Nat,
    pub outs: Array<Out>,
}

/// `GnKind`:
///
/// ```prism
/// type GnKind = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum GnKind {
    GnNamed,
    GnAnswer,
    GnStarted,
    GnDeferred,
    GnPort,
    GnMerge,
    GnUnion,
    GnBoth,
    GnExcept,
    GnMergeAll,
    GnGather,
    GnUpdated,
    GnNever,
}

impl Show for GnKind {
    fn show(&self, p: &mut Printer) {
        match self {
            GnKind::GnNamed => p.choice("GnNamed", &[]),
            GnKind::GnAnswer => p.choice("GnAnswer", &[]),
            GnKind::GnStarted => p.choice("GnStarted", &[]),
            GnKind::GnDeferred => p.choice("GnDeferred", &[]),
            GnKind::GnPort => p.choice("GnPort", &[]),
            GnKind::GnMerge => p.choice("GnMerge", &[]),
            GnKind::GnUnion => p.choice("GnUnion", &[]),
            GnKind::GnBoth => p.choice("GnBoth", &[]),
            GnKind::GnExcept => p.choice("GnExcept", &[]),
            GnKind::GnMergeAll => p.choice("GnMergeAll", &[]),
            GnKind::GnGather => p.choice("GnGather", &[]),
            GnKind::GnUpdated => p.choice("GnUpdated", &[]),
            GnKind::GnNever => p.choice("GnNever", &[]),
        }
    }
}

impl ToPod for GnKind {
    fn to_pod(&self) -> Pod {
        match self {
            GnKind::GnNamed => Pod::Choice("GnNamed".into(), vec![]),
            GnKind::GnAnswer => Pod::Choice("GnAnswer".into(), vec![]),
            GnKind::GnStarted => Pod::Choice("GnStarted".into(), vec![]),
            GnKind::GnDeferred => Pod::Choice("GnDeferred".into(), vec![]),
            GnKind::GnPort => Pod::Choice("GnPort".into(), vec![]),
            GnKind::GnMerge => Pod::Choice("GnMerge".into(), vec![]),
            GnKind::GnUnion => Pod::Choice("GnUnion".into(), vec![]),
            GnKind::GnBoth => Pod::Choice("GnBoth".into(), vec![]),
            GnKind::GnExcept => Pod::Choice("GnExcept".into(), vec![]),
            GnKind::GnMergeAll => Pod::Choice("GnMergeAll".into(), vec![]),
            GnKind::GnGather => Pod::Choice("GnGather".into(), vec![]),
            GnKind::GnUpdated => Pod::Choice("GnUpdated".into(), vec![]),
            GnKind::GnNever => Pod::Choice("GnNever".into(), vec![]),
        }
    }
}

impl FromPod for GnKind {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "GnNamed" && a.len() == 0 => Ok(GnKind::GnNamed),
            Pod::Choice(c, a) if &**c == "GnAnswer" && a.len() == 0 => Ok(GnKind::GnAnswer),
            Pod::Choice(c, a) if &**c == "GnStarted" && a.len() == 0 => Ok(GnKind::GnStarted),
            Pod::Choice(c, a) if &**c == "GnDeferred" && a.len() == 0 => Ok(GnKind::GnDeferred),
            Pod::Choice(c, a) if &**c == "GnPort" && a.len() == 0 => Ok(GnKind::GnPort),
            Pod::Choice(c, a) if &**c == "GnMerge" && a.len() == 0 => Ok(GnKind::GnMerge),
            Pod::Choice(c, a) if &**c == "GnUnion" && a.len() == 0 => Ok(GnKind::GnUnion),
            Pod::Choice(c, a) if &**c == "GnBoth" && a.len() == 0 => Ok(GnKind::GnBoth),
            Pod::Choice(c, a) if &**c == "GnExcept" && a.len() == 0 => Ok(GnKind::GnExcept),
            Pod::Choice(c, a) if &**c == "GnMergeAll" && a.len() == 0 => Ok(GnKind::GnMergeAll),
            Pod::Choice(c, a) if &**c == "GnGather" && a.len() == 0 => Ok(GnKind::GnGather),
            Pod::Choice(c, a) if &**c == "GnUpdated" && a.len() == 0 => Ok(GnKind::GnUpdated),
            Pod::Choice(c, a) if &**c == "GnNever" && a.len() == 0 => Ok(GnKind::GnNever),
            other => mismatch("a GnKind", other),
        }
    }
}

/// `HostDef`:
///
/// ```prism
/// type HostDef = record:
/// ```
#[derive(Clone)]
pub struct HostDef {
    pub pos: crate::lower::model::Pos_,
    pub name: Text,
    pub scope: Nat,
}

impl ToPod for HostDef {
    fn to_pod(&self) -> Pod {
        Pod::record("HostDef", vec![("pos", self.pos.to_pod()), ("name", self.name.to_pod()), ("scope", self.scope.to_pod())])
    }
}

impl FromPod for HostDef {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(HostDef { pos: FromPod::from_pod(field(p, "pos")?)?, name: FromPod::from_pod(field(p, "name")?)?, scope: FromPod::from_pod(field(p, "scope")?)? })
    }
}

/// `HostForm`:
///
/// ```prism
/// type HostForm = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum HostForm {
    HostEach,
    HostSome,
}

impl Show for HostForm {
    fn show(&self, p: &mut Printer) {
        match self {
            HostForm::HostEach => p.choice("HostEach", &[]),
            HostForm::HostSome => p.choice("HostSome", &[]),
        }
    }
}

impl ToPod for HostForm {
    fn to_pod(&self) -> Pod {
        match self {
            HostForm::HostEach => Pod::Choice("HostEach".into(), vec![]),
            HostForm::HostSome => Pod::Choice("HostSome".into(), vec![]),
        }
    }
}

impl FromPod for HostForm {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "HostEach" && a.len() == 0 => Ok(HostForm::HostEach),
            Pod::Choice(c, a) if &**c == "HostSome" && a.len() == 0 => Ok(HostForm::HostSome),
            other => mismatch("a HostForm", other),
        }
    }
}

/// `HowBound`:
///
/// ```prism
/// type HowBound = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum HowBound {
    AsHold,
    AsBind,
    AsLet,
}

impl Show for HowBound {
    fn show(&self, p: &mut Printer) {
        match self {
            HowBound::AsHold => p.choice("AsHold", &[]),
            HowBound::AsBind => p.choice("AsBind", &[]),
            HowBound::AsLet => p.choice("AsLet", &[]),
        }
    }
}

impl ToPod for HowBound {
    fn to_pod(&self) -> Pod {
        match self {
            HowBound::AsHold => Pod::Choice("AsHold".into(), vec![]),
            HowBound::AsBind => Pod::Choice("AsBind".into(), vec![]),
            HowBound::AsLet => Pod::Choice("AsLet".into(), vec![]),
        }
    }
}

impl FromPod for HowBound {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "AsHold" && a.len() == 0 => Ok(HowBound::AsHold),
            Pod::Choice(c, a) if &**c == "AsBind" && a.len() == 0 => Ok(HowBound::AsBind),
            Pod::Choice(c, a) if &**c == "AsLet" && a.len() == 0 => Ok(HowBound::AsLet),
            other => mismatch("a HowBound", other),
        }
    }
}

/// `Out`:
///
/// ```prism
/// type Out = record:
/// ```
#[derive(Clone)]
pub struct Out {
    pub pipe: Rc<dyn Fn((crate::lower::model::Ex, Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>)) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>,
    pub sink: Sk,
}

/// `PendingRow`:
///
/// ```prism
/// type PendingRow = record:
/// ```
#[derive(Clone)]
pub struct PendingRow {
    pub wx: Wx,
    pub qk: Text,
    pub params: Array<(Text, crate::lower::model::OutTy)>,
    pub gather: Option<Nat>,
}

/// `Place`:
///
/// ```prism
/// type Place = record:
/// ```
#[derive(Clone)]
pub struct Place {
    pub pos: crate::lower::model::Pos_,
    pub level: crate::lower::model::Ex,
    pub getter: Text,
    pub reads: Array<Read>,
}

impl ToPod for Place {
    fn to_pod(&self) -> Pod {
        Pod::record("Place", vec![("pos", self.pos.to_pod()), ("level", self.level.to_pod()), ("getter", self.getter.to_pod()), ("reads", self.reads.to_pod())])
    }
}

impl FromPod for Place {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Place { pos: FromPod::from_pod(field(p, "pos")?)?, level: FromPod::from_pod(field(p, "level")?)?, getter: FromPod::from_pod(field(p, "getter")?)?, reads: FromPod::from_pod(field(p, "reads")?)? })
    }
}

/// `Read`:
///
/// ```prism
/// type Read = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum Read {
    OwnRead(Text),
    ParentRead(Text),
}

impl Show for Read {
    fn show(&self, p: &mut Printer) {
        match self {
            Read::OwnRead(a0) => p.choice("OwnRead", &[a0]),
            Read::ParentRead(a0) => p.choice("ParentRead", &[a0]),
        }
    }
}

impl ToPod for Read {
    fn to_pod(&self) -> Pod {
        match self {
            Read::OwnRead(a0) => Pod::Choice("OwnRead".into(), vec![a0.to_pod()]),
            Read::ParentRead(a0) => Pod::Choice("ParentRead".into(), vec![a0.to_pod()]),
        }
    }
}

impl FromPod for Read {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "OwnRead" && a.len() == 1 => Ok(Read::OwnRead(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "ParentRead" && a.len() == 1 => Ok(Read::ParentRead(FromPod::from_pod(&a[0])?)),
            other => mismatch("a Read", other),
        }
    }
}

/// `RowLocal`:
///
/// ```prism
/// type RowLocal = record:
/// ```
#[derive(Clone)]
pub struct RowLocal {
    pub name: Text,
    pub field: Text,
    pub ty: crate::lower::model::OutTy,
    pub passed: crate::lower::model::Ex,
}

impl ToPod for RowLocal {
    fn to_pod(&self) -> Pod {
        Pod::record("RowLocal", vec![("name", self.name.to_pod()), ("field", self.field.to_pod()), ("ty", self.ty.to_pod()), ("passed", self.passed.to_pod())])
    }
}

impl FromPod for RowLocal {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(RowLocal { name: FromPod::from_pod(field(p, "name")?)?, field: FromPod::from_pod(field(p, "field")?)?, ty: FromPod::from_pod(field(p, "ty")?)?, passed: FromPod::from_pod(field(p, "passed")?)? })
    }
}

/// `RowMarks`:
///
/// ```prism
/// type RowMarks = record:
/// ```
#[derive(Clone)]
pub struct RowMarks {
    pub builder: Text,
    pub reads: Array<Read>,
    pub wrote: Array<Text>,
    pub kind: crate::lower::model::RowKind,
}

impl ToPod for RowMarks {
    fn to_pod(&self) -> Pod {
        Pod::record("RowMarks", vec![("builder", self.builder.to_pod()), ("reads", self.reads.to_pod()), ("wrote", self.wrote.to_pod()), ("kind", self.kind.to_pod())])
    }
}

impl FromPod for RowMarks {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(RowMarks { builder: FromPod::from_pod(field(p, "builder")?)?, reads: FromPod::from_pod(field(p, "reads")?)?, wrote: FromPod::from_pod(field(p, "wrote")?)?, kind: FromPod::from_pod(field(p, "kind")?)? })
    }
}

/// `Sinks`:
///
/// ```prism
/// type Sinks = record:
/// ```
#[derive(Clone)]
pub struct Sinks {
    pub wx: Wx,
    pub dirty: Array<Read>,
    pub builds: Array<Read>,
    pub heights: Array<Nat>,
    pub many: bool,
}

/// `Sk`:
///
/// ```prism
/// type Sk = choice:
/// ```
#[derive(Clone)]
pub enum Sk {
    SkNode(Nat),
    SkIn(Nat, Nat),
    SkHold(Text),
    SkRequest(crate::lower::model::Pos_, Text),
    SkResult,
    SkArm(Text),
    SkCycle(Text, Text, Nat),
    SkUp(Text),
    SkPort(Text),
    SkMachine(Text, Text, Nat),
}

impl ToPod for Sk {
    fn to_pod(&self) -> Pod {
        match self {
            Sk::SkNode(a0) => Pod::Choice("SkNode".into(), vec![a0.to_pod()]),
            Sk::SkIn(a0, a1) => Pod::Choice("SkIn".into(), vec![a0.to_pod(), a1.to_pod()]),
            Sk::SkHold(a0) => Pod::Choice("SkHold".into(), vec![a0.to_pod()]),
            Sk::SkRequest(a0, a1) => Pod::Choice("SkRequest".into(), vec![a0.to_pod(), a1.to_pod()]),
            Sk::SkResult => Pod::Choice("SkResult".into(), vec![]),
            Sk::SkArm(a0) => Pod::Choice("SkArm".into(), vec![a0.to_pod()]),
            Sk::SkCycle(a0, a1, a2) => Pod::Choice("SkCycle".into(), vec![a0.to_pod(), a1.to_pod(), a2.to_pod()]),
            Sk::SkUp(a0) => Pod::Choice("SkUp".into(), vec![a0.to_pod()]),
            Sk::SkPort(a0) => Pod::Choice("SkPort".into(), vec![a0.to_pod()]),
            Sk::SkMachine(a0, a1, a2) => Pod::Choice("SkMachine".into(), vec![a0.to_pod(), a1.to_pod(), a2.to_pod()]),
        }
    }
}

impl FromPod for Sk {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "SkNode" && a.len() == 1 => Ok(Sk::SkNode(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "SkIn" && a.len() == 2 => Ok(Sk::SkIn(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "SkHold" && a.len() == 1 => Ok(Sk::SkHold(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "SkRequest" && a.len() == 2 => Ok(Sk::SkRequest(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "SkResult" && a.len() == 0 => Ok(Sk::SkResult),
            Pod::Choice(c, a) if &**c == "SkArm" && a.len() == 1 => Ok(Sk::SkArm(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "SkCycle" && a.len() == 3 => Ok(Sk::SkCycle(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?, FromPod::from_pod(&a[2])?)),
            Pod::Choice(c, a) if &**c == "SkUp" && a.len() == 1 => Ok(Sk::SkUp(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "SkPort" && a.len() == 1 => Ok(Sk::SkPort(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "SkMachine" && a.len() == 3 => Ok(Sk::SkMachine(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?, FromPod::from_pod(&a[2])?)),
            other => mismatch("a Sk", other),
        }
    }
}

/// `SnapDef`:
///
/// ```prism
/// type SnapDef = record:
/// ```
#[derive(Clone)]
pub struct SnapDef {
    pub name: Text,
    pub live: Text,
    pub ty: crate::lower::model::OutTy,
    pub eq: bool,
    pub builder: Text,
    pub before: bool,
    pub what: Text,
}

impl ToPod for SnapDef {
    fn to_pod(&self) -> Pod {
        Pod::record("SnapDef", vec![("name", self.name.to_pod()), ("live", self.live.to_pod()), ("ty", self.ty.to_pod()), ("eq", self.eq.to_pod()), ("builder", self.builder.to_pod()), ("before", self.before.to_pod()), ("what", self.what.to_pod())])
    }
}

impl FromPod for SnapDef {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(SnapDef { name: FromPod::from_pod(field(p, "name")?)?, live: FromPod::from_pod(field(p, "live")?)?, ty: FromPod::from_pod(field(p, "ty")?)?, eq: FromPod::from_pod(field(p, "eq")?)?, builder: FromPod::from_pod(field(p, "builder")?)?, before: FromPod::from_pod(field(p, "before")?)?, what: FromPod::from_pod(field(p, "what")?)? })
    }
}

/// `Wres`:
///
/// ```prism
/// type Wres = choice:
/// ```
#[derive(Clone)]
pub enum Wres {
    WrEv(EvRef),
    WrDyn(crate::lower::model::Ex, Array<Read>, crate::lower::model::OutTy),
    WrPlain(crate::lower::model::Ex, crate::lower::model::OutTy),
    WrUnit,
    WrHosted(Rc<Wres>, crate::lower::Bn),
}

/// `Wx`:
///
/// ```prism
/// type Wx = record:
/// ```
#[derive(Clone)]
pub struct Wx {
    pub lx: crate::lower::Lx,
    pub node_: Text,
    pub pos: crate::lower::model::Pos_,
    pub gns: Array<Gn>,
    pub fields: Array<(Text, crate::lower::model::OutTy, Text)>,
    pub inits: Array<(Text, crate::lower::model::Ex)>,
    pub moves: Array<(Text, crate::lower::model::Ex)>,
    pub lets: Array<crate::lower::model::Do>,
    pub build: Array<crate::lower::model::Do>,
    pub places: Array<Place>,
    pub answers: Array<(crate::lower::model::Pos_, Nat, crate::lower::model::OutTy, Text)>,
    pub started: Array<Nat>,
    pub defers: Array<(Text, Nat)>,
    pub getters: Array<crate::lower::model::MethDef>,
    pub dyn_reads: Map<Text, Array<Read>>,
    pub taken: Array<Text>,
    pub fallible: bool,
    pub depth: Nat,
    pub result: Wres,
    pub rows: Array<crate::lower::model::NodeDef>,
    pub builders: Array<crate::lower::model::ForDef>,
    pub build_holds: Array<Read>,
    pub up_sink: Text,
    pub gens: Array<crate::lower::model::GenDef>,
    pub gen_holds: Array<(Text, Array<Read>)>,
    pub ports: Array<Text>,
    pub subs: Array<(Text, Text, crate::lower::model::OutTy)>,
    pub parent_env: crate::lower::Env,
    pub hosts: Array<HostDef>,
    pub dyn_places: Array<(crate::lower::model::Pos_, Text, crate::lower::model::OutTy, Text)>,
    pub scopes: Array<Text>,
    pub hosted_by: Option<Text>,
    pub root_dyn: Option<(crate::lower::model::Ex, Array<Read>, crate::lower::model::OutTy)>,
    pub row_marks: Array<RowMarks>,
    pub pending: Array<PendingRow>,
    pub floors: Map<Text, Nat>,
    pub snaps: Array<SnapDef>,
    pub result_moved: Option<(Text, Array<Read>)>,
    pub dyn_answers: Array<(Text, Array<Read>)>,
    pub inited: Array<Text>,
    pub flattens: Array<FlatDef>,
}

/// ```prism
/// IdPipe: unbounded fn Ex, (unbounded fn Ex -> [Do]) -> [Do]
/// ```
pub fn id_pipe(x: &crate::lower::model::Ex, k_fn: &Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>) -> Array<crate::lower::model::Do> {
    run_to_end(k_fn(x.clone()))
}

/// The step machine of `IdPipe`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// IdPipe: unbounded fn Ex, (unbounded fn Ex -> [Do]) -> [Do]
/// ```
pub struct IdPipe {
    pub x: crate::lower::model::Ex,
    pub k_fn: Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>,
}

impl prism_rtl::Job<Array<crate::lower::model::Do>> for IdPipe {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::lower::model::Do>> {
        let x = &self.x;
        let k_fn = &self.k_fn;
        k_fn(x.clone()).cycle()
    }
}

/// `Start IdPipe, x`: what the function value is when passed to `@Run`.
pub fn start_id_pipe(x: crate::lower::model::Ex, k_fn: Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>> {
    Rc::new(IdPipe { x, k_fn })
}

/// ```prism
/// EvRefOf: fn Wx, Nat -> EvRef
/// ```
pub fn ev_ref_of(wx: &Wx, n: &Nat) -> EvRef {
    EvRef { node_: n.clone(), owner: wx.node_.clone(), pipe: Rc::new(|(a0, a1): (crate::lower::model::Ex, Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>)| entered(start_id_pipe(a0, a1))) as Rc<dyn Fn((crate::lower::model::Ex, Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>)) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>> }
}

/// ```prism
/// KindWord: fn GnKind -> Text
/// ```
pub fn kind_word(k: &GnKind) -> Text {
    match k {
        GnKind::GnNamed => Text::lit("named"),
        GnKind::GnAnswer => Text::lit("answer"),
        GnKind::GnStarted => Text::lit("started"),
        GnKind::GnDeferred => Text::lit("deferred"),
        GnKind::GnPort => Text::lit("port"),
        GnKind::GnMerge => Text::lit("merge"),
        GnKind::GnUnion => Text::lit("union"),
        GnKind::GnBoth => Text::lit("both"),
        GnKind::GnExcept => Text::lit("except"),
        GnKind::GnMergeAll => Text::lit("mergeall"),
        GnKind::GnGather => Text::lit("gather"),
        GnKind::GnUpdated => Text::lit("updated"),
        GnKind::GnNever => Text::lit("never"),
    }
}

/// ```prism
/// HasRead: fn [Read], Read -> Bool
/// ```
pub fn has_read(rs: &Array<Read>, r: &Read) -> bool {
    fold(rs, &false, &(|seen: &bool, x: &Read| *seen || (x == r)))
}

/// ```prism
/// AddRead: fn [Read], Read -> [Read]
/// ```
pub fn add_read(rs: &Array<Read>, r: &Read) -> Array<Read> {
    if has_read(rs, r) { rs.clone() } else { push(rs, r) }
}

/// ```prism
/// UnionReads: fn [Read], [Read] -> [Read]
/// ```
pub fn union_reads(xs: &Array<Read>, ys: &Array<Read>) -> Array<Read> {
    fold(ys, xs, &(|acc: &Array<Read>, y: &Read| add_read(acc, y)))
}

/// ```prism
/// let nodeHooks
/// ```
pub fn node_hooks() -> Array<Text> {
    Array::from(vec![Text::lit("path"), Text::lit("build"), Text::lit("wake"), Text::lit("started"), Text::lit("deferred"), Text::lit("answer"), Text::lit("push"), Text::lit("swap"), Text::lit("leave"), Text::lit("patch"), Text::lit("clean_up"), Text::lit("edges"), Text::lit("release"), Text::lit("leave_row"), Text::lit("remove_places")])
}

/// ```prism
/// NewWx: fn Lx, Text, [((Text, OutTy, Text))], [((Text, Ex))], [((Text, Ex))], [MethDef], (Text ==> [Read]), [Text], Nat, ?Text -> Wx
/// ```
pub fn new_wx(lx: &crate::lower::Lx, name: &Text, fields: &Array<(Text, crate::lower::model::OutTy, Text)>, inits: &Array<(Text, crate::lower::model::Ex)>, moves_: &Array<(Text, crate::lower::model::Ex)>, getters: &Array<crate::lower::model::MethDef>, dyn_reads: &Map<Text, Array<Read>>, taken: &Array<Text>, depth: &Nat, hosted_by_opt: &Option<Text>) -> Wx {
    let hosted_fields = match hosted_by_opt {
        Some(_) => Array::from(vec![(Text::lit("enclosing"), crate::lower::host_of_ty(), Text::lit("the host whose document this row's places are entries of (pick HO)"))]),
        None => Array::new(),
    };
    let hosted_inits = match hosted_by_opt {
        Some(_) => Array::from(vec![(Text::lit("enclosing"), crate::lower::model::Ex::XVar(Text::lit("enclosing")))]),
        None => Array::new(),
    };
    Wx { lx: lx.clone(), node_: name.clone(), pos: crate::lower::model::pos0(), gns: Array::new(), fields: append(fields, &hosted_fields), inits: inits.clone(), moves: append(moves_, &hosted_inits), lets: Array::new(), build: Array::new(), places: Array::new(), answers: Array::new(), started: Array::new(), defers: Array::new(), getters: getters.clone(), dyn_reads: dyn_reads.clone(), taken: push(taken, &Text::lit("enclosing")), fallible: false, depth: depth.clone(), result: Wres::WrUnit, rows: Array::new(), builders: Array::new(), build_holds: Array::new(), up_sink: Text::lit(""), gens: Array::new(), gen_holds: Array::new(), ports: Array::new(), subs: Array::new(), parent_env: crate::lower::empty_env(), hosts: Array::new(), dyn_places: Array::new(), scopes: Array::new(), hosted_by: hosted_by_opt.clone(), root_dyn: None, row_marks: Array::new(), pending: Array::new(), floors: Map::new(), snaps: Array::new(), result_moved: None, dyn_answers: Array::new(), inited: Array::new(), flattens: Array::new() }
}

/// ```prism
/// FreshName: fn Wx, Text -> ((Text, Wx))
/// ```
pub fn fresh_name(wx: &Wx, base: &Text) -> (Text, Wx) {
    let pick = if !crate::check::types::has_text(&wx.taken, base) {
        base.clone()
    } else {
        Text::from(format!("{}_{}", base, &first_free(&wx.taken, base, &Nat::from(2u32))))
    };
    let wx2 = {
        let mut this: Wx = wx.clone();
        this.taken = push(&this.taken, &pick);
        this
    };
    (pick.clone(), wx2.clone())
}

/// ```prism
/// FirstFree: fn [Text], Text, Nat -> Nat
/// ```
pub fn first_free(taken: &Array<Text>, base: &Text, from: &Nat) -> Nat {
    fold(&crate::check::errors::range0(&len(taken)), from, &(|n: &Nat, _: &Nat| if crate::check::types::has_text(taken, &Text::from(format!("{}_{}", base, n))) {
        n + &Nat::from(1u32)
    } else {
        n.clone()
    }))
}

/// ```prism
/// AddGn: fn Wx, Text, OutTy, GnKind, Nat -> ((Nat, Wx))
/// ```
pub fn add_gn(wx: &Wx, name: &Text, ty: &crate::lower::model::OutTy, kind: &GnKind, height: &Nat) -> (Nat, Wx) {
    let id = len(&wx.gns);
    let wx2 = {
        let mut this: Wx = wx.clone();
        this.gns = push(&this.gns, &Gn { id: id.clone(), name: name.clone(), ty: ty.clone(), kind: kind.clone(), height: height.clone(), inputs: Array::new(), reads: Array::new(), floor: Nat::from(0u32), outs: Array::new() });
        this
    };
    (id.clone(), wx2.clone())
}

/// ```prism
/// Connect: fn Wx, EvRef, Sk -> Wx
/// ```
pub fn connect(wx: &Wx, r: &EvRef, sink: &Sk) -> Wx {
    if &r.owner != &wx.node_ {
        crossed(wx, &Text::from(format!("an event of node `{}` (its graph node {})", &r.owner, &r.node_)))
    } else {
        {
            let mut this: Wx = wx.clone();
            this.gns = each(&this.gns, &(|n: &Gn| if &n.id == &r.node_ {
                add_out(n, &Out { pipe: r.pipe.clone(), sink: sink.clone() })
            } else {
                n.clone()
            }));
            this
        }
    }
}

/// ```prism
/// Crossed: fn Wx, Text -> Wx
/// ```
pub fn crossed(wx: &Wx, what: &Text) -> Wx {
    let mut this: Wx = wx.clone();
    this.build = push(&this.build, &crate::lower::model::Do::DoExpr(crate::lower::refusal(&Text::from(format!("{} read in node `{}` without a port (a lowering bug)", what, &wx.node_)))));
    this
}

/// ```prism
/// AddOut: fn Gn, Out -> Gn
/// ```
pub fn add_out(n: &Gn, o: &Out) -> Gn {
    let mut this: Gn = n.clone();
    this.outs = push(&this.outs, o);
    this
}

/// ```prism
/// AddField: fn Wx, Text, OutTy, Text, Ex -> Wx
/// ```
pub fn add_field(wx: &Wx, name: &Text, t: &crate::lower::model::OutTy, doc: &Text, init: &crate::lower::model::Ex) -> Wx {
    let mut this: Wx = wx.clone();
    this.fields = push(&this.fields, &(name.clone(), t.clone(), doc.clone()));
    this.inits = push(&this.inits, &(name.clone(), init.clone()));
    this
}

/// ```prism
/// AddFieldLast: fn Wx, Text, OutTy, Text, Ex -> Wx
/// ```
pub fn add_field_last(wx: &Wx, name: &Text, t: &crate::lower::model::OutTy, doc: &Text, init: &crate::lower::model::Ex) -> Wx {
    let mut this: Wx = wx.clone();
    this.fields = push(&this.fields, &(name.clone(), t.clone(), doc.clone()));
    this.moves = push(&this.moves, &(name.clone(), init.clone()));
    this
}

/// ```prism
/// GnOf: fn Wx, Nat -> Gn
/// ```
pub fn gn_of(wx: &Wx, n: &Nat) -> Gn {
    or(&index(&wx.gns, n), &Gn { id: n.clone(), name: Text::lit("never"), ty: crate::lower::model::OutTy::OutUnit, kind: GnKind::GnNever, height: Nat::from(0u32), inputs: Array::new(), reads: Array::new(), floor: Nat::from(0u32), outs: Array::new() })
}

/// ```prism
/// BindPlain: fn Env, Env, Text, Text, OutTy -> ((Env, Env))
/// ```
pub fn bind_plain(benv: &crate::lower::Env, menv: &crate::lower::Env, nkey: &Text, rs: &Text, t: &crate::lower::model::OutTy) -> (crate::lower::Env, crate::lower::Env) {
    (crate::lower::bind(benv, nkey, &crate::lower::Bn::BnLocal(crate::lower::model::Ex::XVar(rs.clone()), crate::lower::Holding::Owned, t.clone())), crate::lower::bind(menv, nkey, &crate::lower::Bn::BnLocal(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), rs.clone()), crate::lower::Holding::Owned, t.clone())))
}

/// ```prism
/// NodeDefOf: unbounded fn Lx, Text, [Pattern], Block, Scheme, Bool -> NodeDef
/// ```
pub fn node_def_of(lx: &crate::lower::Lx, qk: &Text, params: &Array<crate::syntax::Pattern_>, body: &crate::syntax::Block, sc: &crate::check::types::Scheme, is_root: &bool) -> crate::lower::model::NodeDef {
    let name = crate::lower::camel(&crate::check::types::bare_name(qk));
    let ptys = match &sc.ty {
        crate::check::types::Ty::TyFn(_, ps, _) => ps.clone(),
        _ => Array::new(),
    };
    let wx0 = new_wx(lx, &name, &Array::new(), &Array::new(), &Array::new(), &Array::new(), &Map::new(), &node_hooks(), &Nat::from(0u32), &None);
    let (ps, wx1, benv, menv) = run_to_end(fold_job(crate::check::errors::range0(&len(params)), (Array::new(), wx0.clone(), crate::lower::empty_env(), crate::lower::empty_env()), {
        let params = params.clone();
        let lx = lx.clone();
        let ptys = ptys.clone();
        Rc::new(move |(p0, p1): ((Array<(Text, crate::lower::model::OutTy)>, Wx, crate::lower::Env, crate::lower::Env), Nat)| {
            let params = params.clone();
            let lx = lx.clone();
            let ptys = ptys.clone();
            entered(once_job(move || {
                let (acc, w, be, me) = p0;
                let i = p1;
                {
                    let p_ = or(&index(&params, &i), &crate::lower::dummy_pat());
                    let nkey = crate::lower::plain_binder(&lx, &p_);
                    let base = if &nkey == &Text::lit("") {
                        Text::from(format!("arg{}", &i))
                    } else {
                        crate::lower::snake(&nkey)
                    };
                    let (rs, w2) = fresh_name(&w, &base);
                    call_then(crate::lower::start_out_ty_of(lx.clone(), crate::lower::peel(&or(&index(&ptys, &i), &crate::check::types::Ty::TyErr))), move |out_ty_of_16357: crate::lower::model::OutTy| {
                        let t = out_ty_of_16357;
                        let w3 = {
                            let mut this: Wx = w2.clone();
                            this.fields = push(&this.fields, &(rs.clone(), t.clone(), Text::lit("a parameter")));
                            this.inits = push(&this.inits, &(rs.clone(), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(rs.clone())))));
                            this
                        };
                        let (be2, me2) = bind_plain(&be, &me, &nkey, &rs, &t);
                        prism_rtl::Turn::Finished((push(&acc, &(rs.clone(), t.clone())), w3.clone(), be2.clone(), me2.clone()))
                    })
                }
            }))
        }) as Rc<dyn Fn(((Array<(Text, crate::lower::model::OutTy)>, Wx, crate::lower::Env, crate::lower::Env), Nat)) -> Rc<dyn prism_rtl::Job<(Array<(Text, crate::lower::model::OutTy)>, Wx, crate::lower::Env, crate::lower::Env)>>>
    }));
    let wx2 = block_into(&wx1, &benv, &menv, body);
    let wx3 = if *is_root { root_result(&wx2) } else { wx2.clone() };
    finish_node(&wx3, qk, &ps, &false)
}

/// The step machine of `NodeDefOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// NodeDefOf: unbounded fn Lx, Text, [Pattern], Block, Scheme, Bool -> NodeDef
/// ```
pub struct NodeDefOf {
    pub lx: crate::lower::Lx,
    pub qk: Text,
    pub params: Array<crate::syntax::Pattern_>,
    pub body: crate::syntax::Block,
    pub sc: crate::check::types::Scheme,
    pub is_root: bool,
}

impl prism_rtl::Job<crate::lower::model::NodeDef> for NodeDefOf {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::NodeDef> {
        let lx = &self.lx;
        let qk = &self.qk;
        let params = &self.params;
        let body = &self.body;
        let sc = &self.sc;
        let is_root = &self.is_root;
        let name = crate::lower::camel(&crate::check::types::bare_name(qk));
        let ptys = match &sc.ty {
            crate::check::types::Ty::TyFn(_, ps, _) => ps.clone(),
            _ => Array::new(),
        };
        let wx0 = new_wx(lx, &name, &Array::new(), &Array::new(), &Array::new(), &Array::new(), &Map::new(), &node_hooks(), &Nat::from(0u32), &None);
        let body = body.clone();
        let is_root = *is_root;
        let lx = lx.clone();
        let params = params.clone();
        let qk = qk.clone();
        call_value(fold_job(crate::check::errors::range0(&len(&params)), (Array::new(), wx0.clone(), crate::lower::empty_env(), crate::lower::empty_env()), {
            let params = params.clone();
            let lx = lx.clone();
            let ptys = ptys.clone();
            Rc::new(move |(p0, p1): ((Array<(Text, crate::lower::model::OutTy)>, Wx, crate::lower::Env, crate::lower::Env), Nat)| {
                let params = params.clone();
                let lx = lx.clone();
                let ptys = ptys.clone();
                entered(once_job(move || {
                    let (acc, w, be, me) = p0;
                    let i = p1;
                    {
                        let p_ = or(&index(&params, &i), &crate::lower::dummy_pat());
                        let nkey = crate::lower::plain_binder(&lx, &p_);
                        let base = if &nkey == &Text::lit("") {
                            Text::from(format!("arg{}", &i))
                        } else {
                            crate::lower::snake(&nkey)
                        };
                        let (rs, w2) = fresh_name(&w, &base);
                        call_then(crate::lower::start_out_ty_of(lx.clone(), crate::lower::peel(&or(&index(&ptys, &i), &crate::check::types::Ty::TyErr))), move |out_ty_of_16357: crate::lower::model::OutTy| {
                            let t = out_ty_of_16357;
                            let w3 = {
                                let mut this: Wx = w2.clone();
                                this.fields = push(&this.fields, &(rs.clone(), t.clone(), Text::lit("a parameter")));
                                this.inits = push(&this.inits, &(rs.clone(), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(rs.clone())))));
                                this
                            };
                            let (be2, me2) = bind_plain(&be, &me, &nkey, &rs, &t);
                            prism_rtl::Turn::Finished((push(&acc, &(rs.clone(), t.clone())), w3.clone(), be2.clone(), me2.clone()))
                        })
                    }
                }))
            }) as Rc<dyn Fn(((Array<(Text, crate::lower::model::OutTy)>, Wx, crate::lower::Env, crate::lower::Env), Nat)) -> Rc<dyn prism_rtl::Job<(Array<(Text, crate::lower::model::OutTy)>, Wx, crate::lower::Env, crate::lower::Env)>>>
        }), move |fold_16074: (Array<(Text, crate::lower::model::OutTy)>, Wx, crate::lower::Env, crate::lower::Env)| {
            let (ps, wx1, benv, menv) = fold_16074;
            call_then(start_block_into(wx1.clone(), benv.clone(), menv.clone(), body.clone()), move |block_into_16675: Wx| {
                let wx2 = block_into_16675;
                let wx3 = if is_root { root_result(&wx2) } else { wx2.clone() };
                prism_rtl::Turn::More(Rc::new(FinishNode { wx0: wx3.clone(), qk: qk.clone(), params: ps.clone(), is_row: false }))
            })
        })
    }
}

/// `Start NodeDefOf, x`: what the function value is when passed to `@Run`.
pub fn start_node_def_of(lx: crate::lower::Lx, qk: Text, params: Array<crate::syntax::Pattern_>, body: crate::syntax::Block, sc: crate::check::types::Scheme, is_root: bool) -> Rc<dyn prism_rtl::Job<crate::lower::model::NodeDef>> {
    Rc::new(NodeDefOf { lx, qk, params, body, sc, is_root })
}

/// ```prism
/// RootResult: fn Wx -> Wx
/// ```
pub fn root_result(wx: &Wx) -> Wx {
    match &wx.result {
        Wres::WrEv(r) => connect(wx, r, &Sk::SkResult),
        Wres::WrDyn(x, rds, t) => {
            let mut this: Wx = wx.clone();
            this.root_dyn = Some((x.clone(), rds.clone(), t.clone()));
            this.getters = push(&this.getters, &crate::lower::model::MethDef { name: Text::lit("result_value"), recv: crate::lower::model::Recv::RecvRef, params: Array::new(), cx_: crate::lower::model::CxArg::CxRef, ret: crate::lower::model::OutTy::OutPod, body: Array::new(), tail: crate::lower::model::Ex::XMethod(Rc::new(x.clone()), Text::lit("to_pod"), Array::new()), doc: Text::lit("The root's dynamic result, pulled after the tick.") });
            this.fields = push(&this.fields, &(Text::lit("result_last"), crate::lower::model::OutTy::OutCell(Rc::new(crate::lower::model::OutTy::OutOpt(Rc::new(crate::lower::model::OutTy::OutPod)))), Text::lit("the result the World last heard")));
            this.moves = push(&this.moves, &(Text::lit("result_last"), crate::lower::model::Ex::XCall(Text::lit("RefCell::new"), Array::from(vec![crate::lower::model::Ex::XNone]))));
            this.build = push(&this.build, &crate::lower::model::Do::DoScope(result_told(&crate::lower::model::Ex::XVar(Text::lit("node")))));
            this
        },
        Wres::WrPlain(x, _) => {
            let mut this: Wx = wx.clone();
            this.build = push(&this.build, &crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCx), Text::lit("result"), Array::from(vec![crate::lower::model::Ex::XCtor(Text::lit("Outcome::Value"), Array::from(vec![crate::lower::model::Ex::XMethod(Rc::new(x.clone()), Text::lit("to_pod"), Array::new())]))]))));
            this
        },
        _ => wx.clone(),
    }
}

/// ```prism
/// BlockInto: unbounded fn Wx, Env, Env, Block -> Wx
/// ```
pub fn block_into(wx: &Wx, benv: &crate::lower::Env, menv: &crate::lower::Env, b: &crate::syntax::Block) -> Wx {
    let (wx1, be1, me1) = run_to_end(fold_job(b.stmts.clone(), (wx.clone(), benv.clone(), menv.clone()), Rc::new(move |(p0, p1): ((Wx, crate::lower::Env, crate::lower::Env), crate::syntax::Stmt)| entered(once_job(move || {
        let (w, be, me) = p0;
        let s = p1;
        prism_rtl::Turn::More(Rc::new(PreBind { wx: w.clone(), benv: be.clone(), menv: me.clone(), s: s.clone() }))
    }))) as Rc<dyn Fn(((Wx, crate::lower::Env, crate::lower::Env), crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<(Wx, crate::lower::Env, crate::lower::Env)>>>));
    let n = len(&b.stmts);
    let (wx2, _, _) = run_to_end(fold_job(crate::check::errors::range0(&n), (wx1.clone(), be1.clone(), me1.clone()), {
        let b = b.clone();
        let n = n.clone();
        Rc::new(move |(p0, p1): ((Wx, crate::lower::Env, crate::lower::Env), Nat)| {
            let b = b.clone();
            let n = n.clone();
            entered(once_job(move || {
                let (w, be, me) = p0;
                let i = p1;
                prism_rtl::Turn::More(Rc::new(WidgetStmt { wx: w.clone(), benv: be.clone(), menv: me.clone(), s: or(&index(&b.stmts, &i), &crate::lower::dummy_stmt_l()), last: &(&i + &Nat::from(1u32)) == &n }))
            }))
        }) as Rc<dyn Fn(((Wx, crate::lower::Env, crate::lower::Env), Nat)) -> Rc<dyn prism_rtl::Job<(Wx, crate::lower::Env, crate::lower::Env)>>>
    }));
    wx2.clone()
}

/// The step machine of `BlockInto`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BlockInto: unbounded fn Wx, Env, Env, Block -> Wx
/// ```
pub struct BlockInto {
    pub wx: Wx,
    pub benv: crate::lower::Env,
    pub menv: crate::lower::Env,
    pub b: crate::syntax::Block,
}

impl prism_rtl::Job<Wx> for BlockInto {
    fn cycle(&self) -> prism_rtl::Turn<Wx> {
        let wx = &self.wx;
        let benv = &self.benv;
        let menv = &self.menv;
        let b = &self.b;
        let b = b.clone();
        let benv = benv.clone();
        let menv = menv.clone();
        let wx = wx.clone();
        call_value(fold_job(b.stmts.clone(), (wx.clone(), benv.clone(), menv.clone()), Rc::new(move |(p0, p1): ((Wx, crate::lower::Env, crate::lower::Env), crate::syntax::Stmt)| entered(once_job(move || {
            let (w, be, me) = p0;
            let s = p1;
            prism_rtl::Turn::More(Rc::new(PreBind { wx: w.clone(), benv: be.clone(), menv: me.clone(), s: s.clone() }))
        }))) as Rc<dyn Fn(((Wx, crate::lower::Env, crate::lower::Env), crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<(Wx, crate::lower::Env, crate::lower::Env)>>>), move |fold_17998: (Wx, crate::lower::Env, crate::lower::Env)| {
            let (wx1, be1, me1) = fold_17998;
            let n = len(&b.stmts);
            call_value(fold_job(crate::check::errors::range0(&n), (wx1.clone(), be1.clone(), me1.clone()), {
                let b = b.clone();
                let n = n.clone();
                Rc::new(move |(p0, p1): ((Wx, crate::lower::Env, crate::lower::Env), Nat)| {
                    let b = b.clone();
                    let n = n.clone();
                    entered(once_job(move || {
                        let (w, be, me) = p0;
                        let i = p1;
                        prism_rtl::Turn::More(Rc::new(WidgetStmt { wx: w.clone(), benv: be.clone(), menv: me.clone(), s: or(&index(&b.stmts, &i), &crate::lower::dummy_stmt_l()), last: &(&i + &Nat::from(1u32)) == &n }))
                    }))
                }) as Rc<dyn Fn(((Wx, crate::lower::Env, crate::lower::Env), Nat)) -> Rc<dyn prism_rtl::Job<(Wx, crate::lower::Env, crate::lower::Env)>>>
            }), move |fold_18131: (Wx, crate::lower::Env, crate::lower::Env)| {
                let (wx2, _, _) = fold_18131;
                prism_rtl::Turn::Finished(wx2.clone())
            })
        })
    }
}

/// `Start BlockInto, x`: what the function value is when passed to `@Run`.
pub fn start_block_into(wx: Wx, benv: crate::lower::Env, menv: crate::lower::Env, b: crate::syntax::Block) -> Rc<dyn prism_rtl::Job<Wx>> {
    Rc::new(BlockInto { wx, benv, menv, b })
}

/// ```prism
/// PreBind: unbounded fn Wx, Env, Env, Stmt -> ((Wx, Env, Env))
/// ```
pub fn pre_bind(wx: &Wx, benv: &crate::lower::Env, menv: &crate::lower::Env, s: &crate::syntax::Stmt) -> (Wx, crate::lower::Env, crate::lower::Env) {
    match &s.kind {
        crate::syntax::StmtKind::SBind(p_, init, step_opt) => match &*p_.kind {
            crate::syntax::PatternKind::PName(n) => pre_bind_name(wx, benv, menv, n, &how_bound(step_opt)),
            crate::syntax::PatternKind::PTuple(ps) => run_to_end(fold_job(ps.clone(), (wx.clone(), benv.clone(), menv.clone()), Rc::new(move |(p0, p1): ((Wx, crate::lower::Env, crate::lower::Env), crate::syntax::Pattern_)| entered(once_job(move || {
                let (w, be, me) = p0;
                let q = p1;
                match &*q.kind {
                    crate::syntax::PatternKind::PName(n) => prism_rtl::Turn::More(Rc::new(PreBindName { wx: w.clone(), benv: be.clone(), menv: me.clone(), n: n.clone(), how: HowBound::AsBind })),
                    _ => prism_rtl::Turn::Finished((w.clone(), be.clone(), me.clone())),
                }
            }))) as Rc<dyn Fn(((Wx, crate::lower::Env, crate::lower::Env), crate::syntax::Pattern_)) -> Rc<dyn prism_rtl::Job<(Wx, crate::lower::Env, crate::lower::Env)>>>)),
            _ => (wx.clone(), benv.clone(), menv.clone()),
        },
        crate::syntax::StmtKind::SLet(p_, _, _) => match &*p_.kind {
            crate::syntax::PatternKind::PName(n) => pre_bind_name(wx, benv, menv, n, &HowBound::AsLet),
            _ => (wx.clone(), benv.clone(), menv.clone()),
        },
        crate::syntax::StmtKind::SFn(c) => {
            let fname = crate::check::env::def_name_text(&c.name);
            (wx.clone(), crate::lower::bind(benv, &fname, &crate::lower::Bn::BnLocalFn(c.clone())), crate::lower::bind(menv, &fname, &crate::lower::Bn::BnLocalFn(c.clone())))
        },
        _ => (wx.clone(), benv.clone(), menv.clone()),
    }
}

/// The step machine of `PreBind`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PreBind: unbounded fn Wx, Env, Env, Stmt -> ((Wx, Env, Env))
/// ```
pub struct PreBind {
    pub wx: Wx,
    pub benv: crate::lower::Env,
    pub menv: crate::lower::Env,
    pub s: crate::syntax::Stmt,
}

impl prism_rtl::Job<(Wx, crate::lower::Env, crate::lower::Env)> for PreBind {
    fn cycle(&self) -> prism_rtl::Turn<(Wx, crate::lower::Env, crate::lower::Env)> {
        let wx = &self.wx;
        let benv = &self.benv;
        let menv = &self.menv;
        let s = &self.s;
        match &s.kind {
            crate::syntax::StmtKind::SBind(p_, init, step_opt) => match &*p_.kind {
                crate::syntax::PatternKind::PName(n) => prism_rtl::Turn::More(Rc::new(PreBindName { wx: wx.clone(), benv: benv.clone(), menv: menv.clone(), n: n.clone(), how: how_bound(step_opt) })),
                crate::syntax::PatternKind::PTuple(ps) => fold_job(ps.clone(), (wx.clone(), benv.clone(), menv.clone()), Rc::new(move |(p0, p1): ((Wx, crate::lower::Env, crate::lower::Env), crate::syntax::Pattern_)| entered(once_job(move || {
                    let (w, be, me) = p0;
                    let q = p1;
                    match &*q.kind {
                        crate::syntax::PatternKind::PName(n) => prism_rtl::Turn::More(Rc::new(PreBindName { wx: w.clone(), benv: be.clone(), menv: me.clone(), n: n.clone(), how: HowBound::AsBind })),
                        _ => prism_rtl::Turn::Finished((w.clone(), be.clone(), me.clone())),
                    }
                }))) as Rc<dyn Fn(((Wx, crate::lower::Env, crate::lower::Env), crate::syntax::Pattern_)) -> Rc<dyn prism_rtl::Job<(Wx, crate::lower::Env, crate::lower::Env)>>>).cycle(),
                _ => prism_rtl::Turn::Finished((wx.clone(), benv.clone(), menv.clone())),
            },
            crate::syntax::StmtKind::SLet(p_, _, _) => match &*p_.kind {
                crate::syntax::PatternKind::PName(n) => prism_rtl::Turn::More(Rc::new(PreBindName { wx: wx.clone(), benv: benv.clone(), menv: menv.clone(), n: n.clone(), how: HowBound::AsLet })),
                _ => prism_rtl::Turn::Finished((wx.clone(), benv.clone(), menv.clone())),
            },
            crate::syntax::StmtKind::SFn(c) => {
                let fname = crate::check::env::def_name_text(&c.name);
                prism_rtl::Turn::Finished((wx.clone(), crate::lower::bind(benv, &fname, &crate::lower::Bn::BnLocalFn(c.clone())), crate::lower::bind(menv, &fname, &crate::lower::Bn::BnLocalFn(c.clone()))))
            },
            _ => prism_rtl::Turn::Finished((wx.clone(), benv.clone(), menv.clone())),
        }
    }
}

/// `Start PreBind, x`: what the function value is when passed to `@Run`.
pub fn start_pre_bind(wx: Wx, benv: crate::lower::Env, menv: crate::lower::Env, s: crate::syntax::Stmt) -> Rc<dyn prism_rtl::Job<(Wx, crate::lower::Env, crate::lower::Env)>> {
    Rc::new(PreBind { wx, benv, menv, s })
}

/// ```prism
/// HowBound: fn ?Expr -> HowBound
/// ```
pub fn how_bound(opt0: &Option<crate::syntax::Expr>) -> HowBound {
    match opt0 {
        Some(_) => HowBound::AsHold,
        None => HowBound::AsBind,
    }
}

/// ```prism
/// PreBindName: unbounded fn Wx, Env, Env, SName, HowBound -> ((Wx, Env, Env))
/// ```
pub fn pre_bind_name(wx: &Wx, benv: &crate::lower::Env, menv: &crate::lower::Env, n: &crate::syntax::SName, how: &HowBound) -> (Wx, crate::lower::Env, crate::lower::Env) {
    let lx = crate::lower::widget_let_lx(&wx.lx, &n.span);
    let nkey = crate::check::env::sname_key(n);
    let full = crate::lower::binder_ty(&lx, &n.span);
    let layer = crate::lower::layer_of(&full);
    let t = crate::lower::out_ty_of(&lx, &crate::lower::peel(&full));
    let (rs, wx1) = fresh_name(wx, &crate::lower::snake(&nkey));
    if (&layer == &crate::lower::Layer::LyEv) || is_switched(&full) {
        {
            let et = crate::lower::out_ty_of(&lx, &crate::lower::peel(&crate::lower::peel(&full)));
            let (id, wx2) = add_gn(&wx1, &rs, &et, &GnKind::GnNamed, &Nat::from(0u32));
            let b = crate::lower::Bn::BnEv(ev_ref_of(&wx2, &id), t.clone());
            let pf = Text::from(format!("{}_v_port", &rs));
            let pt = crate::lower::model::OutTy::OutRc(Rc::new(crate::lower::model::OutTy::OutPort(Rc::new(et.clone()))));
            let wx3 = {
                let mut this: Wx = connect(&wx2, &ev_ref_of(&wx2, &id), &Sk::SkPort(Text::from(format!("{}_v", &rs))));
                this.lets = push(&this.lets, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaBind(pf.clone())), pt.clone()), crate::lower::model::Ex::XCall(Text::lit("Rc::new"), Array::from(vec![crate::lower::model::Ex::XCall(Text::lit("Port::new"), Array::new())]))));
                this.fields = push(&this.fields, &(pf.clone(), pt.clone(), Text::from(format!("`{}` as a value: the port it fires", &nkey))));
                this.moves = push(&this.moves, &(pf.clone(), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(pf.clone())))));
                this
            };
            let be = crate::lower::bind(&crate::lower::bind(benv, &nkey, &b), &Text::from(format!("{}#port", &nkey)), &crate::lower::Bn::BnLocal(crate::lower::model::Ex::XVar(pf.clone()), crate::lower::Holding::Owned, pt.clone()));
            let me = crate::lower::bind(&crate::lower::bind(menv, &nkey, &b), &Text::from(format!("{}#port", &nkey)), &crate::lower::Bn::BnLocal(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), pf.clone()), crate::lower::Holding::Owned, pt.clone()));
            (wx3.clone(), be.clone(), me.clone())
        }
    } else {
        match (layer.clone(), how.clone()) {
            (crate::lower::Layer::LyDyn, HowBound::AsLet) => {
                let b = crate::lower::Bn::BnDyn(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XSelf), rs.clone(), Array::from(vec![crate::lower::model::Ex::XCx])), Array::from(vec![Read::OwnRead(rs.clone())]), t.clone());
                (wx1.clone(), crate::lower::bind(benv, &nkey, &b), crate::lower::bind(menv, &nkey, &b))
            },
            (crate::lower::Layer::LyDyn, _) => {
                let b = crate::lower::Bn::BnHold(rs.clone(), t.clone());
                (wx1.clone(), crate::lower::bind(benv, &nkey, &b), crate::lower::bind(menv, &nkey, &b))
            },
            _ => match many_instances(&wx.lx, &n.span) {
                Some(insts) => run_to_end(fold_job(crate::check::errors::range0(&len(&insts)), (wx1.clone(), benv.clone(), menv.clone()), {
                    let insts = insts.clone();
                    let wx = wx.clone();
                    let n = n.clone();
                    let rs = rs.clone();
                    let nkey = nkey.clone();
                    Rc::new(move |(p0, p1): ((Wx, crate::lower::Env, crate::lower::Env), Nat)| {
                        let insts = insts.clone();
                        let wx = wx.clone();
                        let n = n.clone();
                        let rs = rs.clone();
                        let nkey = nkey.clone();
                        entered(once_job(move || {
                            let (w, be, me) = p0;
                            let k = p1;
                            {
                                let inst = or(&index(&insts, &k), &(Array::new(), Array::new()));
                                let lxk = crate::lower::at_instance(&wx.lx, &inst);
                                call_then(crate::lower::start_out_ty_of(lxk.clone(), crate::lower::peel(&crate::lower::binder_ty(&lxk, &n.span))), move |out_ty_of_21493: crate::lower::model::OutTy| {
                                    let tk = out_ty_of_21493;
                                    let (rk, w2) = if &k == &Nat::from(0u32) {
                                        (rs.clone(), w.clone())
                                    } else {
                                        fresh_name(&w, &Text::from(format!("{}_{}", &rs, &k)))
                                    };
                                    let bkey = if &k == &Nat::from(0u32) {
                                        nkey.clone()
                                    } else {
                                        Text::from(format!("{}#inst{}", &nkey, &k))
                                    };
                                    let (be2, me2) = bind_plain(&be, &me, &bkey, &rk, &tk);
                                    let ukey = Text::from(format!("{}#{}", &nkey, &show_text(&inst)));
                                    prism_rtl::Turn::Finished((w2.clone(), with_use(&be2, &ukey, &bkey), with_use(&me2, &ukey, &bkey)))
                                })
                            }
                        }))
                    }) as Rc<dyn Fn(((Wx, crate::lower::Env, crate::lower::Env), Nat)) -> Rc<dyn prism_rtl::Job<(Wx, crate::lower::Env, crate::lower::Env)>>>
                })),
                None => {
                    let (be, me) = bind_plain(benv, menv, &nkey, &rs, &t);
                    (wx1.clone(), be.clone(), me.clone())
                },
            },
        }
    }
}

/// The step machine of `PreBindName`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PreBindName: unbounded fn Wx, Env, Env, SName, HowBound -> ((Wx, Env, Env))
/// ```
pub struct PreBindName {
    pub wx: Wx,
    pub benv: crate::lower::Env,
    pub menv: crate::lower::Env,
    pub n: crate::syntax::SName,
    pub how: HowBound,
}

impl prism_rtl::Job<(Wx, crate::lower::Env, crate::lower::Env)> for PreBindName {
    fn cycle(&self) -> prism_rtl::Turn<(Wx, crate::lower::Env, crate::lower::Env)> {
        let wx = &self.wx;
        let benv = &self.benv;
        let menv = &self.menv;
        let n = &self.n;
        let how = &self.how;
        let benv = benv.clone();
        let how = how.clone();
        let menv = menv.clone();
        let n = n.clone();
        let wx = wx.clone();
        call_then(crate::lower::start_widget_let_lx(wx.lx.clone(), n.span.clone()), move |widget_let_lx_19478: crate::lower::Lx| {
            let lx = widget_let_lx_19478;
            let nkey = crate::check::env::sname_key(&n);
            let full = crate::lower::binder_ty(&lx, &n.span);
            let layer = crate::lower::layer_of(&full);
            call_then(crate::lower::start_out_ty_of(lx.clone(), crate::lower::peel(&full)), move |out_ty_of_19606: crate::lower::model::OutTy| {
                let t = out_ty_of_19606;
                let (rs, wx1) = fresh_name(&wx, &crate::lower::snake(&nkey));
                if (&layer == &crate::lower::Layer::LyEv) || is_switched(&full) {
                    call_then(crate::lower::start_out_ty_of(lx.clone(), crate::lower::peel(&crate::lower::peel(&full))), move |out_ty_of_19737: crate::lower::model::OutTy| {
                        let et = out_ty_of_19737;
                        let (id, wx2) = add_gn(&wx1, &rs, &et, &GnKind::GnNamed, &Nat::from(0u32));
                        let b = crate::lower::Bn::BnEv(ev_ref_of(&wx2, &id), t.clone());
                        let pf = Text::from(format!("{}_v_port", &rs));
                        let pt = crate::lower::model::OutTy::OutRc(Rc::new(crate::lower::model::OutTy::OutPort(Rc::new(et.clone()))));
                        let wx3 = {
                            let mut this: Wx = connect(&wx2, &ev_ref_of(&wx2, &id), &Sk::SkPort(Text::from(format!("{}_v", &rs))));
                            this.lets = push(&this.lets, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaBind(pf.clone())), pt.clone()), crate::lower::model::Ex::XCall(Text::lit("Rc::new"), Array::from(vec![crate::lower::model::Ex::XCall(Text::lit("Port::new"), Array::new())]))));
                            this.fields = push(&this.fields, &(pf.clone(), pt.clone(), Text::from(format!("`{}` as a value: the port it fires", &nkey))));
                            this.moves = push(&this.moves, &(pf.clone(), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(pf.clone())))));
                            this
                        };
                        let be = crate::lower::bind(&crate::lower::bind(&benv, &nkey, &b), &Text::from(format!("{}#port", &nkey)), &crate::lower::Bn::BnLocal(crate::lower::model::Ex::XVar(pf.clone()), crate::lower::Holding::Owned, pt.clone()));
                        let me = crate::lower::bind(&crate::lower::bind(&menv, &nkey, &b), &Text::from(format!("{}#port", &nkey)), &crate::lower::Bn::BnLocal(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), pf.clone()), crate::lower::Holding::Owned, pt.clone()));
                        prism_rtl::Turn::Finished((wx3.clone(), be.clone(), me.clone()))
                    })
                } else {
                    match (layer.clone(), how.clone()) {
                        (crate::lower::Layer::LyDyn, HowBound::AsLet) => {
                            let b = crate::lower::Bn::BnDyn(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XSelf), rs.clone(), Array::from(vec![crate::lower::model::Ex::XCx])), Array::from(vec![Read::OwnRead(rs.clone())]), t.clone());
                            prism_rtl::Turn::Finished((wx1.clone(), crate::lower::bind(&benv, &nkey, &b), crate::lower::bind(&menv, &nkey, &b)))
                        },
                        (crate::lower::Layer::LyDyn, _) => {
                            let b = crate::lower::Bn::BnHold(rs.clone(), t.clone());
                            prism_rtl::Turn::Finished((wx1.clone(), crate::lower::bind(&benv, &nkey, &b), crate::lower::bind(&menv, &nkey, &b)))
                        },
                        _ => call_then(start_many_instances(wx.lx.clone(), n.span.clone()), move |many_instances_21025: Option<Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)>>| match many_instances_21025 {
                            Some(insts) => fold_job(crate::check::errors::range0(&len(&insts)), (wx1.clone(), benv.clone(), menv.clone()), {
                                let insts = insts.clone();
                                let wx = wx.clone();
                                let n = n.clone();
                                let rs = rs.clone();
                                let nkey = nkey.clone();
                                Rc::new(move |(p0, p1): ((Wx, crate::lower::Env, crate::lower::Env), Nat)| {
                                    let insts = insts.clone();
                                    let wx = wx.clone();
                                    let n = n.clone();
                                    let rs = rs.clone();
                                    let nkey = nkey.clone();
                                    entered(once_job(move || {
                                        let (w, be, me) = p0;
                                        let k = p1;
                                        {
                                            let inst = or(&index(&insts, &k), &(Array::new(), Array::new()));
                                            let lxk = crate::lower::at_instance(&wx.lx, &inst);
                                            call_then(crate::lower::start_out_ty_of(lxk.clone(), crate::lower::peel(&crate::lower::binder_ty(&lxk, &n.span))), move |out_ty_of_21493: crate::lower::model::OutTy| {
                                                let tk = out_ty_of_21493;
                                                let (rk, w2) = if &k == &Nat::from(0u32) {
                                                    (rs.clone(), w.clone())
                                                } else {
                                                    fresh_name(&w, &Text::from(format!("{}_{}", &rs, &k)))
                                                };
                                                let bkey = if &k == &Nat::from(0u32) {
                                                    nkey.clone()
                                                } else {
                                                    Text::from(format!("{}#inst{}", &nkey, &k))
                                                };
                                                let (be2, me2) = bind_plain(&be, &me, &bkey, &rk, &tk);
                                                let ukey = Text::from(format!("{}#{}", &nkey, &show_text(&inst)));
                                                prism_rtl::Turn::Finished((w2.clone(), with_use(&be2, &ukey, &bkey), with_use(&me2, &ukey, &bkey)))
                                            })
                                        }
                                    }))
                                }) as Rc<dyn Fn(((Wx, crate::lower::Env, crate::lower::Env), Nat)) -> Rc<dyn prism_rtl::Job<(Wx, crate::lower::Env, crate::lower::Env)>>>
                            }).cycle(),
                            None => {
                                let (be, me) = bind_plain(&benv, &menv, &nkey, &rs, &t);
                                prism_rtl::Turn::Finished((wx1.clone(), be.clone(), me.clone()))
                            },
                        }),
                    }
                }
            })
        })
    }
}

/// `Start PreBindName, x`: what the function value is when passed to `@Run`.
pub fn start_pre_bind_name(wx: Wx, benv: crate::lower::Env, menv: crate::lower::Env, n: crate::syntax::SName, how: HowBound) -> Rc<dyn prism_rtl::Job<(Wx, crate::lower::Env, crate::lower::Env)>> {
    Rc::new(PreBindName { wx, benv, menv, n, how })
}

/// ```prism
/// WithUse: fn Env, Text, Text -> Env
/// ```
pub fn with_use(env: &crate::lower::Env, ukey: &Text, bkey: &Text) -> crate::lower::Env {
    let mut this: crate::lower::Env = env.clone();
    this.uses = insert(&this.uses, ukey, bkey);
    this
}

/// ```prism
/// ?ManyInstances: unbounded fn Lx, Range -> ?[(([((Text, Ty))], [((Text, Col))]))]
/// ```
pub fn many_instances(lx: &crate::lower::Lx, span: &crate::syntax::Range) -> Option<Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)>> {
    match get(&lx.gens, &crate::lower::place_key(lx, span)) {
        Some(gn) => {
            let insts = crate::lower::instantiations(lx, &gn);
            if &len(&insts) > &Nat::from(1u32) { Some(insts.clone()) } else { None }
        },
        None => None,
    }
}

/// The step machine of `ManyInstances`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?ManyInstances: unbounded fn Lx, Range -> ?[(([((Text, Ty))], [((Text, Col))]))]
/// ```
pub struct ManyInstances {
    pub lx: crate::lower::Lx,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<Option<Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)>>> for ManyInstances {
    fn cycle(&self) -> prism_rtl::Turn<Option<Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)>>> {
        let lx = &self.lx;
        let span = &self.span;
        match get(&lx.gens, &crate::lower::place_key(lx, span)) {
            Some(gn) => {
                let lx = lx.clone();
                call_then(crate::lower::start_instantiations(lx.clone(), gn.clone()), move |instantiations_22370: Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)>| {
                    let insts = instantiations_22370;
                    if &len(&insts) > &Nat::from(1u32) {
                        prism_rtl::Turn::Finished(Some(insts.clone()))
                    } else {
                        prism_rtl::Turn::Finished(None)
                    }
                })
            },
            None => prism_rtl::Turn::Finished(None),
        }
    }
}

/// `Start ManyInstances, x`: what the function value is when passed to `@Run`.
pub fn start_many_instances(lx: crate::lower::Lx, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<Option<Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)>>>> {
    Rc::new(ManyInstances { lx, span })
}

/// ```prism
/// IsSwitched: fn Ty -> Bool
/// ```
pub fn is_switched(t: &crate::check::types::Ty) -> bool {
    'm22687: {
        if let crate::check::types::Ty::TySig(m22687_0_0, m22687_0_1) = t && (m22687_0_0 == &Text::lit("$")) && let crate::check::types::Ty::TySig(m22687_0_1_r_0, _) = &**m22687_0_1 && (m22687_0_1_r_0 == &Text::lit("!")) {
            break 'm22687 true;
        }
        false
    }
}

/// ```prism
/// ?BindingOf: fn Env, Pattern -> ?Bn
/// ```
pub fn binding_of(env: &crate::lower::Env, p_: &crate::syntax::Pattern_) -> Option<crate::lower::Bn> {
    match &*p_.kind {
        crate::syntax::PatternKind::PName(n) => get(&env.names, &crate::check::env::sname_key(n)),
        crate::syntax::PatternKind::PTuple(ps) => Some(crate::lower::Bn::BnParts(each(ps, &(|q: &crate::syntax::Pattern_| binding_of_name(env, q))))),
        _ => None,
    }
}

/// ```prism
/// ?BindingOfName: fn Env, Pattern -> ?Bn
/// ```
pub fn binding_of_name(env: &crate::lower::Env, p_: &crate::syntax::Pattern_) -> Option<crate::lower::Bn> {
    match &*p_.kind {
        crate::syntax::PatternKind::PName(n) => get(&env.names, &crate::check::env::sname_key(n)),
        _ => None,
    }
}

/// ```prism
/// WidgetStmt: unbounded fn Wx, Env, Env, Stmt, Bool -> ((Wx, Env, Env))
/// ```
pub fn widget_stmt(wx: &Wx, benv: &crate::lower::Env, menv: &crate::lower::Env, s: &crate::syntax::Stmt, last: &bool) -> (Wx, crate::lower::Env, crate::lower::Env) {
    let lx = wx.lx.clone();
    match &s.kind {
        crate::syntax::StmtKind::SBind(p_, e, None) => {
            let (wx2, res) = build_line(wx, benv, menv, e, &binding_of(menv, p_));
            let wx3 = bind_res(&wx2, menv, p_, &res);
            match (res.clone(), (*p_.kind).clone()) {
                (Wres::WrDyn(ex, rds, t), crate::syntax::PatternKind::PName(n)) => {
                    let b = crate::lower::Bn::BnDyn(ex.clone(), rds.clone(), t.clone());
                    (wx3.clone(), crate::lower::bind(benv, &crate::check::env::sname_key(&n), &b), crate::lower::bind(menv, &crate::check::env::sname_key(&n), &b))
                },
                (Wres::WrHosted(inner, doc), crate::syntax::PatternKind::PTuple(ps)) => bind_hosted(&wx3, benv, menv, &*inner, &doc, &ps),
                _ => (wx3.clone(), benv.clone(), menv.clone()),
            }
        },
        crate::syntax::StmtKind::SBind(p_, init, Some(step_)) => {
            let (wx2, be2) = hold_line(wx, benv, menv, p_, init, step_);
            (wx2.clone(), be2.clone(), menv.clone())
        },
        crate::syntax::StmtKind::SIgnore(e) => {
            let (wx2, _) = build_line(wx, benv, menv, e, &None);
            (wx2.clone(), benv.clone(), menv.clone())
        },
        crate::syntax::StmtKind::SLet(p_, _, e) => {
            let (wx2, be2) = let_line(wx, benv, menv, p_, e);
            (wx2.clone(), be2.clone(), menv.clone())
        },
        crate::syntax::StmtKind::SExpr(e) => match &*e.kind {
            crate::syntax::ExprKind::EFreeSigil(m24204_0_0, x) if (m24204_0_0 == &Text::lit("@")) => {
                let (res, wx2) = result_of(wx, benv, menv, &**x);
                let wx3 = {
                    let mut this: Wx = wx2.clone();
                    this.result = res.clone();
                    this
                };
                (wx3.clone(), benv.clone(), menv.clone())
            },
            _ => {
                let (wx2, res) = build_line(wx, benv, menv, e, &None);
                let wx3 = if *last { set_result(&wx2, &res) } else { wx2.clone() };
                (wx3.clone(), benv.clone(), menv.clone())
            },
            _ => unreachable!("no arm matched"),
        },
        crate::syntax::StmtKind::SEmit(_) => (wx.clone(), benv.clone(), menv.clone()),
        crate::syntax::StmtKind::SSignature(_) => (wx.clone(), benv.clone(), menv.clone()),
        crate::syntax::StmtKind::SFn(c) => (wx.clone(), benv.clone(), menv.clone()),
        _ => {
            let wx2 = {
                let mut this: Wx = wx.clone();
                this.build = push(&this.build, &crate::lower::refusal_do(&Text::lit("a statement this back end does not lower yet")));
                this
            };
            (wx2.clone(), benv.clone(), menv.clone())
        },
    }
}

/// The step machine of `WidgetStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// WidgetStmt: unbounded fn Wx, Env, Env, Stmt, Bool -> ((Wx, Env, Env))
/// ```
pub struct WidgetStmt {
    pub wx: Wx,
    pub benv: crate::lower::Env,
    pub menv: crate::lower::Env,
    pub s: crate::syntax::Stmt,
    pub last: bool,
}

impl prism_rtl::Job<(Wx, crate::lower::Env, crate::lower::Env)> for WidgetStmt {
    fn cycle(&self) -> prism_rtl::Turn<(Wx, crate::lower::Env, crate::lower::Env)> {
        let wx = &self.wx;
        let benv = &self.benv;
        let menv = &self.menv;
        let s = &self.s;
        let last = &self.last;
        let lx = wx.lx.clone();
        match &s.kind {
            crate::syntax::StmtKind::SBind(p_, e, None) => {
                let benv = benv.clone();
                let e = e.clone();
                let menv = menv.clone();
                let p_ = p_.clone();
                let wx = wx.clone();
                call_then(start_build_line(wx.clone(), benv.clone(), menv.clone(), e.clone(), binding_of(&menv, &p_)), move |build_line_23358: (Wx, Wres)| {
                    let (wx2, res) = build_line_23358;
                    let wx3 = bind_res(&wx2, &menv, &p_, &res);
                    match (res.clone(), (*p_.kind).clone()) {
                        (Wres::WrDyn(ex, rds, t), crate::syntax::PatternKind::PName(n)) => {
                            let b = crate::lower::Bn::BnDyn(ex.clone(), rds.clone(), t.clone());
                            prism_rtl::Turn::Finished((wx3.clone(), crate::lower::bind(&benv, &crate::check::env::sname_key(&n), &b), crate::lower::bind(&menv, &crate::check::env::sname_key(&n), &b)))
                        },
                        (Wres::WrHosted(inner, doc), crate::syntax::PatternKind::PTuple(ps)) => prism_rtl::Turn::Finished(bind_hosted(&wx3, &benv, &menv, &*inner, &doc, &ps)),
                        _ => prism_rtl::Turn::Finished((wx3.clone(), benv.clone(), menv.clone())),
                    }
                })
            },
            crate::syntax::StmtKind::SBind(p_, init, Some(step_)) => {
                let benv = benv.clone();
                let init = init.clone();
                let menv = menv.clone();
                let p_ = p_.clone();
                let step_ = step_.clone();
                let wx = wx.clone();
                call_then(start_hold_line(wx.clone(), benv.clone(), menv.clone(), p_.clone(), init.clone(), step_.clone()), move |hold_line_23881: (Wx, crate::lower::Env)| {
                    let (wx2, be2) = hold_line_23881;
                    prism_rtl::Turn::Finished((wx2.clone(), be2.clone(), menv.clone()))
                })
            },
            crate::syntax::StmtKind::SIgnore(e) => {
                let benv = benv.clone();
                let e = e.clone();
                let menv = menv.clone();
                let wx = wx.clone();
                call_then(start_build_line(wx.clone(), benv.clone(), menv.clone(), e.clone(), None), move |build_line_24004: (Wx, Wres)| {
                    let (wx2, _) = build_line_24004;
                    prism_rtl::Turn::Finished((wx2.clone(), benv.clone(), menv.clone()))
                })
            },
            crate::syntax::StmtKind::SLet(p_, _, e) => {
                let benv = benv.clone();
                let e = e.clone();
                let menv = menv.clone();
                let p_ = p_.clone();
                let wx = wx.clone();
                call_then(start_let_line(wx.clone(), benv.clone(), menv.clone(), p_.clone(), e.clone()), move |let_line_24127: (Wx, crate::lower::Env)| {
                    let (wx2, be2) = let_line_24127;
                    prism_rtl::Turn::Finished((wx2.clone(), be2.clone(), menv.clone()))
                })
            },
            crate::syntax::StmtKind::SExpr(e) => match &*e.kind {
                crate::syntax::ExprKind::EFreeSigil(m24204_0_0, x) if (m24204_0_0 == &Text::lit("@")) => {
                    let benv = benv.clone();
                    let menv = menv.clone();
                    let wx = wx.clone();
                    let x = (**x).clone();
                    call_then(start_result_of(wx.clone(), benv.clone(), menv.clone(), x.clone()), move |result_of_24284: (Wres, Wx)| {
                        let (res, wx2) = result_of_24284;
                        let wx3 = {
                            let mut this: Wx = wx2.clone();
                            this.result = res.clone();
                            this
                        };
                        prism_rtl::Turn::Finished((wx3.clone(), benv.clone(), menv.clone()))
                    })
                },
                _ => {
                    let benv = benv.clone();
                    let e = e.clone();
                    let last = *last;
                    let menv = menv.clone();
                    let wx = wx.clone();
                    call_then(start_build_line(wx.clone(), benv.clone(), menv.clone(), e.clone(), None), move |build_line_24480: (Wx, Wres)| {
                        let (wx2, res) = build_line_24480;
                        let wx3 = if last { set_result(&wx2, &res) } else { wx2.clone() };
                        prism_rtl::Turn::Finished((wx3.clone(), benv.clone(), menv.clone()))
                    })
                },
                _ => unreachable!("no arm matched"),
            },
            crate::syntax::StmtKind::SEmit(_) => prism_rtl::Turn::Finished((wx.clone(), benv.clone(), menv.clone())),
            crate::syntax::StmtKind::SSignature(_) => prism_rtl::Turn::Finished((wx.clone(), benv.clone(), menv.clone())),
            crate::syntax::StmtKind::SFn(c) => prism_rtl::Turn::Finished((wx.clone(), benv.clone(), menv.clone())),
            _ => {
                let wx2 = {
                    let mut this: Wx = wx.clone();
                    this.build = push(&this.build, &crate::lower::refusal_do(&Text::lit("a statement this back end does not lower yet")));
                    this
                };
                prism_rtl::Turn::Finished((wx2.clone(), benv.clone(), menv.clone()))
            },
        }
    }
}

/// `Start WidgetStmt, x`: what the function value is when passed to `@Run`.
pub fn start_widget_stmt(wx: Wx, benv: crate::lower::Env, menv: crate::lower::Env, s: crate::syntax::Stmt, last: bool) -> Rc<dyn prism_rtl::Job<(Wx, crate::lower::Env, crate::lower::Env)>> {
    Rc::new(WidgetStmt { wx, benv, menv, s, last })
}

/// ```prism
/// BindHosted: fn Wx, Env, Env, Wres, Bn, [Pattern] -> ((Wx, Env, Env))
/// ```
pub fn bind_hosted(wx: &Wx, benv: &crate::lower::Env, menv: &crate::lower::Env, res: &Wres, doc: &crate::lower::Bn, ps: &Array<crate::syntax::Pattern_>) -> (Wx, crate::lower::Env, crate::lower::Env) {
    let r_opt = match res {
        Wres::WrEv(r) => Some(crate::lower::Bn::BnEv(r.clone(), crate::lower::model::OutTy::OutUnit)),
        Wres::WrDyn(ex, rds, t) => Some(crate::lower::Bn::BnDyn(ex.clone(), rds.clone(), t.clone())),
        _ => None,
    };
    let (be1, me1) = bind_part(benv, menv, &index(ps, &Nat::from(0u32)), &r_opt);
    bind_part2(wx, &be1, &me1, &index(ps, &Nat::from(1u32)), &Some(doc.clone()))
}

/// ```prism
/// BindPart: fn Env, Env, ?Pattern, ?Bn -> ((Env, Env))
/// ```
pub fn bind_part(benv: &crate::lower::Env, menv: &crate::lower::Env, p__opt: &Option<crate::syntax::Pattern_>, b_opt: &Option<crate::lower::Bn>) -> (crate::lower::Env, crate::lower::Env) {
    match (p__opt.clone(), b_opt.clone()) {
        (Some(p_), Some(b)) => match &*p_.kind {
            crate::syntax::PatternKind::PName(n) => (crate::lower::bind(benv, &crate::check::env::sname_key(n), &b), crate::lower::bind(menv, &crate::check::env::sname_key(n), &b)),
            _ => (benv.clone(), menv.clone()),
        },
        _ => (benv.clone(), menv.clone()),
    }
}

/// ```prism
/// BindPart2: fn Wx, Env, Env, ?Pattern, ?Bn -> ((Wx, Env, Env))
/// ```
pub fn bind_part2(wx: &Wx, benv: &crate::lower::Env, menv: &crate::lower::Env, p__opt: &Option<crate::syntax::Pattern_>, b_opt: &Option<crate::lower::Bn>) -> (Wx, crate::lower::Env, crate::lower::Env) {
    let (be, me) = bind_part(benv, menv, p__opt, b_opt);
    (wx.clone(), be.clone(), me.clone())
}

/// ```prism
/// SetResult: fn Wx, Wres -> Wx
/// ```
pub fn set_result(wx: &Wx, res: &Wres) -> Wx {
    let mut this: Wx = wx.clone();
    this.result = res.clone();
    this
}

/// ```prism
/// ResultOf: unbounded fn Wx, Env, Env, Expr -> ((Wres, Wx))
/// ```
pub fn result_of(wx: &Wx, benv: &crate::lower::Env, menv: &crate::lower::Env, x: &crate::syntax::Expr) -> (Wres, Wx) {
    let lx = wx.lx.clone();
    let full = crate::lower::type_at(&lx, &x.span);
    let t = crate::lower::out_ty_of(&lx, &crate::lower::peel(&full));
    let bound_opt = match &*x.kind {
        crate::syntax::ExprKind::EName(n) => if &len(&n.path_) == &Nat::from(1u32) {
            get(&menv.names, &crate::check::env::sname_key(n))
        } else {
            None
        },
        _ => None,
    };
    match &bound_opt {
        Some(crate::lower::Bn::BnEv(r, _)) => (Wres::WrEv(r.clone()), wx.clone()),
        Some(crate::lower::Bn::BnDyn(ex, rds, bt)) => (Wres::WrDyn(ex.clone(), rds.clone(), bt.clone()), wx.clone()),
        _ => result_of_typed(wx, benv, menv, x, &full, &t),
    }
}

/// The step machine of `ResultOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ResultOf: unbounded fn Wx, Env, Env, Expr -> ((Wres, Wx))
/// ```
pub struct ResultOf {
    pub wx: Wx,
    pub benv: crate::lower::Env,
    pub menv: crate::lower::Env,
    pub x: crate::syntax::Expr,
}

impl prism_rtl::Job<(Wres, Wx)> for ResultOf {
    fn cycle(&self) -> prism_rtl::Turn<(Wres, Wx)> {
        let wx = &self.wx;
        let benv = &self.benv;
        let menv = &self.menv;
        let x = &self.x;
        let lx = wx.lx.clone();
        let full = crate::lower::type_at(&lx, &x.span);
        let benv = benv.clone();
        let menv = menv.clone();
        let wx = wx.clone();
        let x = x.clone();
        call_then(crate::lower::start_out_ty_of(lx.clone(), crate::lower::peel(&full)), move |out_ty_of_26392: crate::lower::model::OutTy| {
            let t = out_ty_of_26392;
            let bound_opt = match &*x.kind {
                crate::syntax::ExprKind::EName(n) => if &len(&n.path_) == &Nat::from(1u32) {
                    get(&menv.names, &crate::check::env::sname_key(n))
                } else {
                    None
                },
                _ => None,
            };
            match &bound_opt {
                Some(crate::lower::Bn::BnEv(r, _)) => prism_rtl::Turn::Finished((Wres::WrEv(r.clone()), wx.clone())),
                Some(crate::lower::Bn::BnDyn(ex, rds, bt)) => prism_rtl::Turn::Finished((Wres::WrDyn(ex.clone(), rds.clone(), bt.clone()), wx.clone())),
                _ => prism_rtl::Turn::More(Rc::new(ResultOfTyped { wx: wx.clone(), benv: benv.clone(), menv: menv.clone(), x: x.clone(), full: full.clone(), t: t.clone() })),
            }
        })
    }
}

/// `Start ResultOf, x`: what the function value is when passed to `@Run`.
pub fn start_result_of(wx: Wx, benv: crate::lower::Env, menv: crate::lower::Env, x: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<(Wres, Wx)>> {
    Rc::new(ResultOf { wx, benv, menv, x })
}

/// ```prism
/// ResultOfTyped: unbounded fn Wx, Env, Env, Expr, Ty, OutTy -> ((Wres, Wx))
/// ```
pub fn result_of_typed(wx: &Wx, benv: &crate::lower::Env, menv: &crate::lower::Env, x: &crate::syntax::Expr, full: &crate::check::types::Ty, t: &crate::lower::model::OutTy) -> (Wres, Wx) {
    let lx = wx.lx.clone();
    match crate::lower::layer_of(full) {
        crate::lower::Layer::LyEv => {
            let (r, wx2) = event_ref(wx, menv, x);
            (Wres::WrEv(r.clone()), wx2.clone())
        },
        crate::lower::Layer::LyDyn => {
            let (ex, reads) = dynamic_expr(wx, menv, x);
            (Wres::WrDyn(ex.clone(), reads.clone(), t.clone()), wx.clone())
        },
        _ => if t == &crate::lower::model::OutTy::OutUnit {
            (Wres::WrUnit, wx.clone())
        } else {
            (Wres::WrPlain(crate::lower::own(&crate::lower::value_of(&lx, benv, x)), t.clone()), wx.clone())
        },
    }
}

/// The step machine of `ResultOfTyped`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ResultOfTyped: unbounded fn Wx, Env, Env, Expr, Ty, OutTy -> ((Wres, Wx))
/// ```
pub struct ResultOfTyped {
    pub wx: Wx,
    pub benv: crate::lower::Env,
    pub menv: crate::lower::Env,
    pub x: crate::syntax::Expr,
    pub full: crate::check::types::Ty,
    pub t: crate::lower::model::OutTy,
}

impl prism_rtl::Job<(Wres, Wx)> for ResultOfTyped {
    fn cycle(&self) -> prism_rtl::Turn<(Wres, Wx)> {
        let wx = &self.wx;
        let benv = &self.benv;
        let menv = &self.menv;
        let x = &self.x;
        let full = &self.full;
        let t = &self.t;
        let lx = wx.lx.clone();
        match crate::lower::layer_of(full) {
            crate::lower::Layer::LyEv => {
                let menv = menv.clone();
                let wx = wx.clone();
                let x = x.clone();
                call_then(start_event_ref(wx.clone(), menv.clone(), x.clone()), move |event_ref_26928: (EvRef, Wx)| {
                    let (r, wx2) = event_ref_26928;
                    prism_rtl::Turn::Finished((Wres::WrEv(r.clone()), wx2.clone()))
                })
            },
            crate::lower::Layer::LyDyn => {
                let menv = menv.clone();
                let t = t.clone();
                let wx = wx.clone();
                let x = x.clone();
                call_then(start_dynamic_expr(wx.clone(), menv.clone(), x.clone()), move |dynamic_expr_27024: (crate::lower::model::Ex, Array<Read>)| {
                    let (ex, reads) = dynamic_expr_27024;
                    prism_rtl::Turn::Finished((Wres::WrDyn(ex.clone(), reads.clone(), t.clone()), wx.clone()))
                })
            },
            _ => if t == &crate::lower::model::OutTy::OutUnit {
                prism_rtl::Turn::Finished((Wres::WrUnit, wx.clone()))
            } else {
                {
                    let benv = benv.clone();
                    let t = t.clone();
                    let wx = wx.clone();
                    let x = x.clone();
                    call_then(crate::lower::start_value_of(lx.clone(), benv.clone(), x.clone()), move |value_of_27187: crate::lower::Vl| prism_rtl::Turn::Finished((Wres::WrPlain(crate::lower::own(&value_of_27187), t.clone()), wx.clone())))
                }
            },
        }
    }
}

/// `Start ResultOfTyped, x`: what the function value is when passed to `@Run`.
pub fn start_result_of_typed(wx: Wx, benv: crate::lower::Env, menv: crate::lower::Env, x: crate::syntax::Expr, full: crate::check::types::Ty, t: crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<(Wres, Wx)>> {
    Rc::new(ResultOfTyped { wx, benv, menv, x, full, t })
}

/// ```prism
/// HoldLine: unbounded fn Wx, Env, Env, Pattern, Expr, Expr -> ((Wx, Env))
/// ```
pub fn hold_line(wx: &Wx, benv: &crate::lower::Env, menv: &crate::lower::Env, p_: &crate::syntax::Pattern_, init: &crate::syntax::Expr, step_: &crate::syntax::Expr) -> (Wx, crate::lower::Env) {
    let lx = wx.lx.clone();
    match binding_of(menv, p_) {
        Some(crate::lower::Bn::BnHold(f, t)) => {
            let iv = crate::lower::own(&crate::lower::value_of(&lx, benv, init));
            let wx1 = add_field(wx, &f, &crate::lower::model::OutTy::OutHold(Rc::new(t.clone())), &Text::from(format!("`{}`", &pat_text(p_))), &crate::lower::model::Ex::XCall(Text::lit("Hold::new"), Array::from(vec![crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(Text::from(format!("{}_init", &f))))), crate::lower::model::Ex::XCx])));
            let (r, wx2) = event_ref(&wx1, menv, step_);
            let wx3 = {
                let mut this: Wx = connect(&wx2, &r, &Sk::SkHold(f.clone()));
                this.lets = push(&this.lets, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaBind(Text::from(format!("{}_init", &f)))), t.clone()), iv.clone()));
                this.inited = push(&this.inited, &f);
                this
            };
            (wx3.clone(), crate::lower::bind(benv, &Text::from(format!("{}#init", &pat_text(p_))), &crate::lower::Bn::BnLocal(crate::lower::model::Ex::XVar(Text::from(format!("{}_init", &f))), crate::lower::Holding::Owned, t.clone())))
        },
        _ => (wx.clone(), benv.clone()),
    }
}

/// The step machine of `HoldLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// HoldLine: unbounded fn Wx, Env, Env, Pattern, Expr, Expr -> ((Wx, Env))
/// ```
pub struct HoldLine {
    pub wx: Wx,
    pub benv: crate::lower::Env,
    pub menv: crate::lower::Env,
    pub p_: crate::syntax::Pattern_,
    pub init: crate::syntax::Expr,
    pub step_: crate::syntax::Expr,
}

impl prism_rtl::Job<(Wx, crate::lower::Env)> for HoldLine {
    fn cycle(&self) -> prism_rtl::Turn<(Wx, crate::lower::Env)> {
        let wx = &self.wx;
        let benv = &self.benv;
        let menv = &self.menv;
        let p_ = &self.p_;
        let init = &self.init;
        let step_ = &self.step_;
        let lx = wx.lx.clone();
        match binding_of(menv, p_) {
            Some(crate::lower::Bn::BnHold(f, t)) => {
                let benv = benv.clone();
                let init = init.clone();
                let menv = menv.clone();
                let p_ = p_.clone();
                let step_ = step_.clone();
                let wx = wx.clone();
                call_then(crate::lower::start_value_of(lx.clone(), benv.clone(), init.clone()), move |value_of_27742: crate::lower::Vl| {
                    let iv = crate::lower::own(&value_of_27742);
                    let wx1 = add_field(&wx, &f, &crate::lower::model::OutTy::OutHold(Rc::new(t.clone())), &Text::from(format!("`{}`", &pat_text(&p_))), &crate::lower::model::Ex::XCall(Text::lit("Hold::new"), Array::from(vec![crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(Text::from(format!("{}_init", &f))))), crate::lower::model::Ex::XCx])));
                    call_then(start_event_ref(wx1.clone(), menv.clone(), step_.clone()), move |event_ref_27920: (EvRef, Wx)| {
                        let (r, wx2) = event_ref_27920;
                        let wx3 = {
                            let mut this: Wx = connect(&wx2, &r, &Sk::SkHold(f.clone()));
                            this.lets = push(&this.lets, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaBind(Text::from(format!("{}_init", &f)))), t.clone()), iv.clone()));
                            this.inited = push(&this.inited, &f);
                            this
                        };
                        prism_rtl::Turn::Finished((wx3.clone(), crate::lower::bind(&benv, &Text::from(format!("{}#init", &pat_text(&p_))), &crate::lower::Bn::BnLocal(crate::lower::model::Ex::XVar(Text::from(format!("{}_init", &f))), crate::lower::Holding::Owned, t.clone()))))
                    })
                })
            },
            _ => prism_rtl::Turn::Finished((wx.clone(), benv.clone())),
        }
    }
}

/// `Start HoldLine, x`: what the function value is when passed to `@Run`.
pub fn start_hold_line(wx: Wx, benv: crate::lower::Env, menv: crate::lower::Env, p_: crate::syntax::Pattern_, init: crate::syntax::Expr, step_: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<(Wx, crate::lower::Env)>> {
    Rc::new(HoldLine { wx, benv, menv, p_, init, step_ })
}

/// ```prism
/// InitEnv: fn Env -> Env
/// ```
pub fn init_env(env: &crate::lower::Env) -> crate::lower::Env {
    fold(&keys(&env.names), env, &(|en: &crate::lower::Env, k: &Text| match (crate::syntax::lexer::before_suffix(k, &Text::lit("#init")), get(&env.names, k)) {
        (Some(name), Some(b)) => crate::lower::bind(en, &name, &b),
        _ => en.clone(),
    }))
}

/// ```prism
/// AllInited: fn Wx, [Read] -> Bool
/// ```
pub fn all_inited(wx: &Wx, reads: &Array<Read>) -> bool {
    fold(&reads_closed(&wx.dyn_reads, reads), &true, &(|ok: &bool, r: &Read| *ok && match r {
        Read::OwnRead(f) => crate::check::types::has_text(&wx.inited, f),
        Read::ParentRead(_) => false,
    }))
}

/// ```prism
/// PatText: fn Pattern -> Text
/// ```
pub fn pat_text(p_: &crate::syntax::Pattern_) -> Text {
    match &*p_.kind {
        crate::syntax::PatternKind::PName(n) => crate::check::env::sname_key(n),
        _ => Text::lit("_"),
    }
}

/// ```prism
/// LetLine: unbounded fn Wx, Env, Env, Pattern, Expr -> ((Wx, Env))
/// ```
pub fn let_line(wx: &Wx, benv: &crate::lower::Env, menv: &crate::lower::Env, p_: &crate::syntax::Pattern_, e: &crate::syntax::Expr) -> (Wx, crate::lower::Env) {
    let lx = wx.lx.clone();
    match binding_of(menv, p_) {
        Some(crate::lower::Bn::BnEv(er, t)) => {
            let (r, wx2) = event_ref(wx, menv, e);
            let fed = crate::lower::out_ty_of(&lx, &crate::lower::peel(&crate::lower::peel(&crate::lower::type_at(&lx, &e.span))));
            let r2 = 'm29712: {
                if let crate::lower::model::OutTy::OutEvent(m29712_0_0) = &t && let crate::lower::model::OutTy::OutRes(_) = &**m29712_0_0 {
                    break 'm29712 if &fed == &crate::lower::model::OutTy::OutError { err_pipe(&r) } else { r.clone() };
                }
                if let crate::lower::model::OutTy::OutRes(_) = &t {
                    break 'm29712 if &fed == &crate::lower::model::OutTy::OutError { err_pipe(&r) } else { r.clone() };
                }
                r.clone()
            };
            (connect(&wx2, &r2, &Sk::SkNode(er.node_.clone())), benv.clone())
        },
        Some(crate::lower::Bn::BnDyn(_, _, t)) => {
            let rs = crate::lower::snake(&pat_text(p_));
            let (ex, reads) = dynamic_expr(wx, menv, e);
            let getter = crate::lower::model::MethDef { name: rs.clone(), recv: crate::lower::model::Recv::RecvRef, params: Array::new(), cx_: crate::lower::model::CxArg::CxRef, ret: t.clone(), body: Array::new(), tail: ex.clone(), doc: Text::from(format!("`{}`", &pat_text(p_))) };
            let wx2 = {
                let mut this: Wx = wx.clone();
                this.getters = push(&this.getters, &getter);
                this.dyn_reads = insert(&this.dyn_reads, &rs, &reads);
                this
            };
            if all_inited(&wx2, &reads) {
                {
                    let wx3 = {
                        let mut this: Wx = wx2.clone();
                        this.lets = push(&this.lets, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaBind(Text::from(format!("{}_init", &rs)))), t.clone()), crate::lower::own(&crate::lower::value_of(&lx, &init_env(benv), e))));
                        this.inited = push(&this.inited, &rs);
                        this
                    };
                    (wx3.clone(), crate::lower::bind(benv, &Text::from(format!("{}#init", &pat_text(p_))), &crate::lower::Bn::BnLocal(crate::lower::model::Ex::XVar(Text::from(format!("{}_init", &rs))), crate::lower::Holding::Owned, t.clone())))
                }
            } else {
                (wx2.clone(), benv.clone())
            }
        },
        Some(crate::lower::Bn::BnLocal(rs, _, t)) => {
            let insts_opt = match &*p_.kind {
                crate::syntax::PatternKind::PName(n) => many_instances(&lx, &n.span),
                _ => None,
            };
            match &insts_opt {
                Some(insts) => match &*p_.kind {
                    crate::syntax::PatternKind::PName(n) => {
                        let nkey = crate::check::env::sname_key(n);
                        let wxn = run_to_end(fold_job(crate::check::errors::range0(&len(insts)), wx.clone(), {
                            let lx = lx.clone();
                            let insts = insts.clone();
                            let nkey = nkey.clone();
                            let menv = menv.clone();
                            let benv = benv.clone();
                            let e = e.clone();
                            Rc::new(move |(p0, p1): (Wx, Nat)| {
                                let lx = lx.clone();
                                let insts = insts.clone();
                                let nkey = nkey.clone();
                                let menv = menv.clone();
                                let benv = benv.clone();
                                let e = e.clone();
                                entered(once_job(move || {
                                    let w = p0;
                                    let k = p1;
                                    {
                                        let lxk = crate::lower::at_instance(&lx, &or(&index(&insts, &k), &(Array::new(), Array::new())));
                                        let bkey = if &k == &Nat::from(0u32) {
                                            nkey.clone()
                                        } else {
                                            Text::from(format!("{}#inst{}", &nkey, &k))
                                        };
                                        match get(&menv.names, &bkey) {
                                            Some(crate::lower::Bn::BnLocal(rk, _, tk)) => call_then(crate::lower::start_value_of(lxk.clone(), benv.clone(), e.clone()), move |value_of_31515: crate::lower::Vl| prism_rtl::Turn::Finished(widget_let_field(&w, &crate::lower::place_stem(&rk), &tk, &crate::lower::own(&value_of_31515), &Text::from(format!("`{}` at its instantiation {}", &nkey, &k))))),
                                            _ => prism_rtl::Turn::Finished({
                                                let mut this: Wx = w.clone();
                                                this.build = push(&this.build, &crate::lower::refusal_do(&Text::from(format!("`{}` at its instantiation {}, which has no binding", &nkey, &k))));
                                                this
                                            }),
                                        }
                                    }
                                }))
                            }) as Rc<dyn Fn((Wx, Nat)) -> Rc<dyn prism_rtl::Job<Wx>>>
                        }));
                        (wxn.clone(), benv.clone())
                    },
                    _ => (wx.clone(), benv.clone()),
                },
                None => {
                    let lxw = match &*p_.kind {
                        crate::syntax::PatternKind::PName(n) => crate::lower::widget_let_lx(&lx, &n.span),
                        _ => lx.clone(),
                    };
                    let v_ = crate::lower::own(&crate::lower::value_of(&lxw, benv, e));
                    (widget_let_field(wx, &crate::lower::place_stem(&rs), &t, &v_, &Text::from(format!("`{}`", &pat_text(p_)))), benv.clone())
                },
            }
        },
        _ => (wx.clone(), benv.clone()),
    }
}

/// The step machine of `LetLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LetLine: unbounded fn Wx, Env, Env, Pattern, Expr -> ((Wx, Env))
/// ```
pub struct LetLine {
    pub wx: Wx,
    pub benv: crate::lower::Env,
    pub menv: crate::lower::Env,
    pub p_: crate::syntax::Pattern_,
    pub e: crate::syntax::Expr,
}

impl prism_rtl::Job<(Wx, crate::lower::Env)> for LetLine {
    fn cycle(&self) -> prism_rtl::Turn<(Wx, crate::lower::Env)> {
        let wx = &self.wx;
        let benv = &self.benv;
        let menv = &self.menv;
        let p_ = &self.p_;
        let e = &self.e;
        let lx = wx.lx.clone();
        match binding_of(menv, p_) {
            Some(crate::lower::Bn::BnEv(er, t)) => {
                let benv = benv.clone();
                let e = e.clone();
                let menv = menv.clone();
                let wx = wx.clone();
                call_then(start_event_ref(wx.clone(), menv.clone(), e.clone()), move |event_ref_29602: (EvRef, Wx)| {
                    let (r, wx2) = event_ref_29602;
                    call_then(crate::lower::start_out_ty_of(lx.clone(), crate::lower::peel(&crate::lower::peel(&crate::lower::type_at(&lx, &e.span)))), move |out_ty_of_29645: crate::lower::model::OutTy| {
                        let fed = out_ty_of_29645;
                        let r2 = 'm29712: {
                            if let crate::lower::model::OutTy::OutEvent(m29712_0_0) = &t && let crate::lower::model::OutTy::OutRes(_) = &**m29712_0_0 {
                                break 'm29712 if &fed == &crate::lower::model::OutTy::OutError { err_pipe(&r) } else { r.clone() };
                            }
                            if let crate::lower::model::OutTy::OutRes(_) = &t {
                                break 'm29712 if &fed == &crate::lower::model::OutTy::OutError { err_pipe(&r) } else { r.clone() };
                            }
                            r.clone()
                        };
                        prism_rtl::Turn::Finished((connect(&wx2, &r2, &Sk::SkNode(er.node_.clone())), benv.clone()))
                    })
                })
            },
            Some(crate::lower::Bn::BnDyn(_, _, t)) => {
                let rs = crate::lower::snake(&pat_text(p_));
                let benv = benv.clone();
                let e = e.clone();
                let menv = menv.clone();
                let p_ = p_.clone();
                let wx = wx.clone();
                call_then(start_dynamic_expr(wx.clone(), menv.clone(), e.clone()), move |dynamic_expr_30065: (crate::lower::model::Ex, Array<Read>)| {
                    let (ex, reads) = dynamic_expr_30065;
                    let getter = crate::lower::model::MethDef { name: rs.clone(), recv: crate::lower::model::Recv::RecvRef, params: Array::new(), cx_: crate::lower::model::CxArg::CxRef, ret: t.clone(), body: Array::new(), tail: ex.clone(), doc: Text::from(format!("`{}`", &pat_text(&p_))) };
                    let wx2 = {
                        let mut this: Wx = wx.clone();
                        this.getters = push(&this.getters, &getter);
                        this.dyn_reads = insert(&this.dyn_reads, &rs, &reads);
                        this
                    };
                    if all_inited(&wx2, &reads) {
                        {
                            let wx3 = {
                                let mut this: Wx = wx2.clone();
                                this.lets = push(&this.lets, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaBind(Text::from(format!("{}_init", &rs)))), t.clone()), crate::lower::own(&crate::lower::value_of(&lx, &init_env(&benv), &e))));
                                this.inited = push(&this.inited, &rs);
                                this
                            };
                            prism_rtl::Turn::Finished((wx3.clone(), crate::lower::bind(&benv, &Text::from(format!("{}#init", &pat_text(&p_))), &crate::lower::Bn::BnLocal(crate::lower::model::Ex::XVar(Text::from(format!("{}_init", &rs))), crate::lower::Holding::Owned, t.clone()))))
                        }
                    } else {
                        prism_rtl::Turn::Finished((wx2.clone(), benv.clone()))
                    }
                })
            },
            Some(crate::lower::Bn::BnLocal(rs, _, t)) => {
                let insts_opt = match &*p_.kind {
                    crate::syntax::PatternKind::PName(n) => many_instances(&lx, &n.span),
                    _ => None,
                };
                match &insts_opt {
                    Some(insts) => match &*p_.kind {
                        crate::syntax::PatternKind::PName(n) => {
                            let nkey = crate::check::env::sname_key(n);
                            let benv = benv.clone();
                            let e = e.clone();
                            let insts = insts.clone();
                            let menv = menv.clone();
                            let wx = wx.clone();
                            call_value(fold_job(crate::check::errors::range0(&len(&insts)), wx.clone(), {
                                let lx = lx.clone();
                                let insts = insts.clone();
                                let nkey = nkey.clone();
                                let menv = menv.clone();
                                let benv = benv.clone();
                                let e = e.clone();
                                Rc::new(move |(p0, p1): (Wx, Nat)| {
                                    let lx = lx.clone();
                                    let insts = insts.clone();
                                    let nkey = nkey.clone();
                                    let menv = menv.clone();
                                    let benv = benv.clone();
                                    let e = e.clone();
                                    entered(once_job(move || {
                                        let w = p0;
                                        let k = p1;
                                        {
                                            let lxk = crate::lower::at_instance(&lx, &or(&index(&insts, &k), &(Array::new(), Array::new())));
                                            let bkey = if &k == &Nat::from(0u32) {
                                                nkey.clone()
                                            } else {
                                                Text::from(format!("{}#inst{}", &nkey, &k))
                                            };
                                            match get(&menv.names, &bkey) {
                                                Some(crate::lower::Bn::BnLocal(rk, _, tk)) => call_then(crate::lower::start_value_of(lxk.clone(), benv.clone(), e.clone()), move |value_of_31515: crate::lower::Vl| prism_rtl::Turn::Finished(widget_let_field(&w, &crate::lower::place_stem(&rk), &tk, &crate::lower::own(&value_of_31515), &Text::from(format!("`{}` at its instantiation {}", &nkey, &k))))),
                                                _ => prism_rtl::Turn::Finished({
                                                    let mut this: Wx = w.clone();
                                                    this.build = push(&this.build, &crate::lower::refusal_do(&Text::from(format!("`{}` at its instantiation {}, which has no binding", &nkey, &k))));
                                                    this
                                                }),
                                            }
                                        }
                                    }))
                                }) as Rc<dyn Fn((Wx, Nat)) -> Rc<dyn prism_rtl::Job<Wx>>>
                            }), move |fold_31159: Wx| {
                                let wxn = fold_31159;
                                prism_rtl::Turn::Finished((wxn.clone(), benv.clone()))
                            })
                        },
                        _ => prism_rtl::Turn::Finished((wx.clone(), benv.clone())),
                    },
                    None => {
                        let lxw = match &*p_.kind {
                            crate::syntax::PatternKind::PName(n) => crate::lower::widget_let_lx(&lx, &n.span),
                            _ => lx.clone(),
                        };
                        let benv = benv.clone();
                        let e = e.clone();
                        let p_ = p_.clone();
                        let wx = wx.clone();
                        call_then(crate::lower::start_value_of(lxw.clone(), benv.clone(), e.clone()), move |value_of_32035: crate::lower::Vl| {
                            let v_ = crate::lower::own(&value_of_32035);
                            prism_rtl::Turn::Finished((widget_let_field(&wx, &crate::lower::place_stem(&rs), &t, &v_, &Text::from(format!("`{}`", &pat_text(&p_)))), benv.clone()))
                        })
                    },
                }
            },
            _ => prism_rtl::Turn::Finished((wx.clone(), benv.clone())),
        }
    }
}

/// `Start LetLine, x`: what the function value is when passed to `@Run`.
pub fn start_let_line(wx: Wx, benv: crate::lower::Env, menv: crate::lower::Env, p_: crate::syntax::Pattern_, e: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<(Wx, crate::lower::Env)>> {
    Rc::new(LetLine { wx, benv, menv, p_, e })
}

/// ```prism
/// WidgetLetField: fn Wx, Text, OutTy, Ex, Text -> Wx
/// ```
pub fn widget_let_field(wx: &Wx, f: &Text, t: &crate::lower::model::OutTy, v_: &crate::lower::model::Ex, doc: &Text) -> Wx {
    let mut this: Wx = wx.clone();
    this.lets = push(&this.lets, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(f.clone()), v_.clone()));
    this.fields = push(&this.fields, &(f.clone(), t.clone(), doc.clone()));
    this.inits = push(&this.inits, &(f.clone(), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(f.clone())))));
    this
}

/// ```prism
/// ErrPipe: fn EvRef -> EvRef
/// ```
pub fn err_pipe(r: &EvRef) -> EvRef {
    EvRef { node_: r.node_.clone(), owner: r.owner.clone(), pipe: {
        let r = r.clone();
        Rc::new(move |(p0, p1): (crate::lower::model::Ex, Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>)| {
            let r = r.clone();
            entered(once_job(move || {
                let x = p0;
                let k_fn = p1;
                (&r.pipe)((x.clone(), {
                    let k_fn = k_fn.clone();
                    Rc::new(move |p0: crate::lower::model::Ex| {
                        let k_fn = k_fn.clone();
                        entered(once_job(move || {
                            let y = p0;
                            (&k_fn)(crate::lower::model::Ex::XCtor(Text::lit("Err"), Array::from(vec![y.clone()]))).cycle()
                        }))
                    }) as Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>
                })).cycle()
            }))
        }) as Rc<dyn Fn((crate::lower::model::Ex, Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>)) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>
    } }
}

/// ```prism
/// OwnAs: fn OutTy, Vl -> Ex
/// ```
pub fn own_as(t: &crate::lower::model::OutTy, v_: &crate::lower::Vl) -> crate::lower::model::Ex {
    match t {
        crate::lower::model::OutTy::OutRes(_) => if &crate::lower::value_ty(v_) == &crate::lower::model::OutTy::OutError {
            crate::lower::model::Ex::XCtor(Text::lit("Err"), Array::from(vec![crate::lower::own(v_)]))
        } else {
            crate::lower::own(v_)
        },
        _ => crate::lower::own(v_),
    }
}

/// ```prism
/// BindRes: fn Wx, Env, Pattern, Wres -> Wx
/// ```
pub fn bind_res(wx2: &Wx, menv: &crate::lower::Env, p_: &crate::syntax::Pattern_, res: &Wres) -> Wx {
    match binding_of(menv, p_) {
        Some(crate::lower::Bn::BnEv(er, _)) => match res {
            Wres::WrEv(r) => if &er.owner != &wx2.node_ {
                crossed(wx2, &Text::from(format!("the bound event of node `{}` (its graph node {})", &er.owner, &er.node_)))
            } else {
                if &r.node_ == &er.node_ {
                    wx2.clone()
                } else {
                    connect(wx2, r, &Sk::SkNode(er.node_.clone()))
                }
            },
            _ => wx2.clone(),
        },
        _ => wx2.clone(),
    }
}

/// ```prism
/// BuildLine: unbounded fn Wx, Env, Env, Expr, ?Bn -> ((Wx, Wres))
/// ```
pub fn build_line(wx: &Wx, benv: &crate::lower::Env, menv: &crate::lower::Env, e: &crate::syntax::Expr, bound_opt: &Option<crate::lower::Bn>) -> (Wx, Wres) {
    let lx = wx.lx.clone();
    let full = crate::lower::type_at(&lx, &e.span);
    'm33812: {
        let scrutinee = &*e.kind;
        if let crate::syntax::ExprKind::EGroup(x) = scrutinee {
            break 'm33812 build_line(wx, benv, menv, &**x, bound_opt);
        }
        if let crate::syntax::ExprKind::EWidgetBlock(b) = scrutinee {
            break 'm33812 inline_block(wx, benv, menv, b, &lx);
        }
        if let crate::syntax::ExprKind::EFor(binders_opt, source, body) = scrutinee {
            break 'm33812 for_line(wx, benv, menv, binders_opt, &**source, body, e, bound_opt);
        }
        if let crate::syntax::ExprKind::ERebuild(scrut, body) = scrutinee {
            break 'm33812 rebuild_line(wx, benv, menv, &**scrut, body, e, bound_opt);
        }
        if let crate::syntax::ExprKind::EIf(m33812_4_0, then_b, Some(else_b)) = scrutinee && let crate::syntax::Cond::CondExpr(c) = &**m33812_4_0 {
            break 'm33812 crate::lower::if_gen_line(wx, menv, &**c, then_b, else_b, e);
        }
        match crate::lower::peel(&full) {
            crate::check::types::Ty::TyElem(_, _) => element_line(wx, benv, menv, e, bound_opt),
            crate::check::types::Ty::TyAt(_, _) => widget_line(wx, benv, menv, e, bound_opt),
            _ => {
                let wx2 = {
                    let mut this: Wx = wx.clone();
                    this.build = push(&this.build, &crate::lower::refusal_do(&Text::lit("a building line this back end does not lower yet")));
                    this
                };
                (wx2.clone(), Wres::WrUnit)
            },
        }
    }
}

/// The step machine of `BuildLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BuildLine: unbounded fn Wx, Env, Env, Expr, ?Bn -> ((Wx, Wres))
/// ```
pub struct BuildLine {
    pub wx: Wx,
    pub benv: crate::lower::Env,
    pub menv: crate::lower::Env,
    pub e: crate::syntax::Expr,
    pub bound_opt: Option<crate::lower::Bn>,
}

impl prism_rtl::Job<(Wx, Wres)> for BuildLine {
    fn cycle(&self) -> prism_rtl::Turn<(Wx, Wres)> {
        let wx = &self.wx;
        let benv = &self.benv;
        let menv = &self.menv;
        let e = &self.e;
        let bound_opt = &self.bound_opt;
        let lx = wx.lx.clone();
        let full = crate::lower::type_at(&lx, &e.span);
        'm33812: {
            let scrutinee = &*e.kind;
            if let crate::syntax::ExprKind::EGroup(x) = scrutinee {
                break 'm33812 prism_rtl::Turn::More(Rc::new(BuildLine { wx: wx.clone(), benv: benv.clone(), menv: menv.clone(), e: (**x).clone(), bound_opt: bound_opt.clone() }));
            }
            if let crate::syntax::ExprKind::EWidgetBlock(b) = scrutinee {
                break 'm33812 prism_rtl::Turn::More(Rc::new(InlineBlock { wx: wx.clone(), benv: benv.clone(), menv: menv.clone(), b: b.clone(), lx: lx.clone() }));
            }
            if let crate::syntax::ExprKind::EFor(binders_opt, source, body) = scrutinee {
                break 'm33812 prism_rtl::Turn::More(Rc::new(ForLine { wx: wx.clone(), benv: benv.clone(), menv: menv.clone(), binders_opt: binders_opt.clone(), source: (**source).clone(), body: body.clone(), e: e.clone(), bound_opt: bound_opt.clone() }));
            }
            if let crate::syntax::ExprKind::ERebuild(scrut, body) = scrutinee {
                break 'm33812 prism_rtl::Turn::More(Rc::new(RebuildLine { wx: wx.clone(), benv: benv.clone(), menv: menv.clone(), scrut: (**scrut).clone(), body: body.clone(), e: e.clone(), bound_opt: bound_opt.clone() }));
            }
            if let crate::syntax::ExprKind::EIf(m33812_4_0, then_b, Some(else_b)) = scrutinee && let crate::syntax::Cond::CondExpr(c) = &**m33812_4_0 {
                break 'm33812 prism_rtl::Turn::More(Rc::new(crate::lower::IfGenLine { wx: wx.clone(), menv: menv.clone(), c: (**c).clone(), then_b: then_b.clone(), else_b: else_b.clone(), e: e.clone() }));
            }
            match crate::lower::peel(&full) {
                crate::check::types::Ty::TyElem(_, _) => prism_rtl::Turn::More(Rc::new(ElementLine { wx: wx.clone(), benv: benv.clone(), menv: menv.clone(), e: e.clone(), bound_opt: bound_opt.clone() })),
                crate::check::types::Ty::TyAt(_, _) => prism_rtl::Turn::More(Rc::new(WidgetLine { wx: wx.clone(), benv: benv.clone(), menv: menv.clone(), e: e.clone(), bound_opt: bound_opt.clone() })),
                _ => {
                    let wx2 = {
                        let mut this: Wx = wx.clone();
                        this.build = push(&this.build, &crate::lower::refusal_do(&Text::lit("a building line this back end does not lower yet")));
                        this
                    };
                    prism_rtl::Turn::Finished((wx2.clone(), Wres::WrUnit))
                },
            }
        }
    }
}

/// `Start BuildLine, x`: what the function value is when passed to `@Run`.
pub fn start_build_line(wx: Wx, benv: crate::lower::Env, menv: crate::lower::Env, e: crate::syntax::Expr, bound_opt: Option<crate::lower::Bn>) -> Rc<dyn prism_rtl::Job<(Wx, Wres)>> {
    Rc::new(BuildLine { wx, benv, menv, e, bound_opt })
}

/// ```prism
/// ElementLine: unbounded fn Wx, Env, Env, Expr, ?Bn -> ((Wx, Wres))
/// ```
pub fn element_line(wx: &Wx, benv: &crate::lower::Env, menv: &crate::lower::Env, e: &crate::syntax::Expr, bound_opt: &Option<crate::lower::Bn>) -> (Wx, Wres) {
    let lx = wx.lx.clone();
    let (tag_name, args) = match &*e.kind {
        crate::syntax::ExprKind::ECall(c, xs, _, _) => (tag_name_of(&lx, &**c), xs.clone()),
        crate::syntax::ExprKind::EName(n) => (tag_name_of(&lx, e), Array::new()),
        _ => (Text::lit(""), Array::new()),
    };
    let full = crate::lower::type_at(&lx, &e.span);
    match get(&lx.g.tags, &tag_name) {
        None => {
            let wx2 = {
                let mut this: Wx = wx.clone();
                this.build = push(&this.build, &crate::lower::refusal_do(&Text::lit("an element of an unknown tag")));
                this
            };
            (wx2.clone(), Wres::WrUnit)
        },
        Some(tg) => {
            let pos = wx.pos.clone();
            let wx1 = {
                let mut this: Wx = wx.clone();
                this.pos = crate::lower::model::next_pos(&this.pos);
                this
            };
            let struct_path = crate::lower::path_in(&lx, &tg.home, &crate::lower::tag_struct(&tg.name));
            let (live_fields, const_fields, reads, wx2) = run_to_end(fold_job(tg.fields.clone(), (Array::new(), Array::new(), Array::new(), wx1.clone()), {
                let args = args.clone();
                let menv = menv.clone();
                let pos = pos.clone();
                let tg = tg.clone();
                let lx = lx.clone();
                let benv = benv.clone();
                Rc::new(move |(p0, p1): ((Array<(Text, crate::lower::model::Ex)>, Array<(Text, crate::lower::model::Ex)>, Array<Read>, Wx), (Text, crate::check::types::Ty))| {
                    let args = args.clone();
                    let menv = menv.clone();
                    let pos = pos.clone();
                    let tg = tg.clone();
                    let lx = lx.clone();
                    let benv = benv.clone();
                    entered(once_job(move || {
                        let (lf, cf, rd, w) = p0;
                        let (fname, fty) = p1;
                        match tag_arg(&args, &fname) {
                            None => prism_rtl::Turn::Finished((lf.clone(), cf.clone(), rd.clone(), w.clone())),
                            Some(arg) => match crate::lower::layer_of(&fty) {
                                crate::lower::Layer::LyEv => call_then(start_event_ref(w.clone(), menv.clone(), arg.clone()), move |event_ref_36127: (EvRef, Wx)| {
                                    let (r, w2) = event_ref_36127;
                                    prism_rtl::Turn::Finished((lf.clone(), cf.clone(), rd.clone(), connect(&w2, &r, &Sk::SkRequest(pos.clone(), request_field(&tg, &fname)))))
                                }),
                                _ => call_then(start_dynamic_expr(w.clone(), menv.clone(), arg.clone()), move |dynamic_expr_36345: (crate::lower::model::Ex, Array<Read>)| {
                                    let (ex, rds) = dynamic_expr_36345;
                                    call_then(crate::lower::start_value_of(lx.clone(), benv.clone(), arg.clone()), move |value_of_36416: crate::lower::Vl| {
                                        let cv = crate::lower::own(&value_of_36416);
                                        prism_rtl::Turn::Finished((push(&lf, &(crate::lower::snake(&fname), ex.clone())), push(&cf, &(crate::lower::snake(&fname), cv.clone())), union_reads(&rd, &rds), w.clone()))
                                    })
                                }),
                            },
                        }
                    }))
                }) as Rc<dyn Fn(((Array<(Text, crate::lower::model::Ex)>, Array<(Text, crate::lower::model::Ex)>, Array<Read>, Wx), (Text, crate::check::types::Ty))) -> Rc<dyn prism_rtl::Job<(Array<(Text, crate::lower::model::Ex)>, Array<(Text, crate::lower::model::Ex)>, Array<Read>, Wx)>>>
            }));
            let live = &len(&reads) > &Nat::from(0u32);
            let (getter, wx3) = if live {
                fresh_name(&wx2, &crate::lower::snake(&crate::check::types::bare_name(&tg.name)))
            } else {
                (Text::lit(""), wx2.clone())
            };
            let variant = crate::lower::variant_of(&lx, &tg);
            let level = crate::lower::model::Ex::XCtor(variant.clone(), Array::from(vec![crate::lower::model::Ex::XRecord(struct_path.clone(), if live { live_fields.clone() } else { const_fields.clone() })]));
            let at_build = crate::lower::model::Ex::XCtor(variant.clone(), Array::from(vec![crate::lower::model::Ex::XRecord(struct_path.clone(), const_fields.clone())]));
            let added = if live {
                crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("node"))), getter.clone(), Array::from(vec![crate::lower::model::Ex::XCx]))
            } else {
                level.clone()
            };
            let wx4 = {
                let mut this: Wx = wx3.clone();
                this.places = push(&this.places, &Place { pos: pos.clone(), level: level.clone(), getter: getter.clone(), reads: reads.clone() });
                this.build = if emits(&wx3, &pos) {
                    push(&this.build, &crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCx), Text::lit("added"), Array::from(vec![place_at(&wx3, &Text::lit("node"), &pos), crate::lower::model::Ex::XMethod(Rc::new(added.clone()), Text::lit("to_pod"), Array::new())]))))
                } else {
                    this.build.clone()
                };
                this
            };
            element_output(&wx4, menv, &tg, &element_out(&lx, &tg, &full), &pos, bound_opt, &at_build)
        },
    }
}

/// The step machine of `ElementLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ElementLine: unbounded fn Wx, Env, Env, Expr, ?Bn -> ((Wx, Wres))
/// ```
pub struct ElementLine {
    pub wx: Wx,
    pub benv: crate::lower::Env,
    pub menv: crate::lower::Env,
    pub e: crate::syntax::Expr,
    pub bound_opt: Option<crate::lower::Bn>,
}

impl prism_rtl::Job<(Wx, Wres)> for ElementLine {
    fn cycle(&self) -> prism_rtl::Turn<(Wx, Wres)> {
        let wx = &self.wx;
        let benv = &self.benv;
        let menv = &self.menv;
        let e = &self.e;
        let bound_opt = &self.bound_opt;
        let lx = wx.lx.clone();
        let (tag_name, args) = match &*e.kind {
            crate::syntax::ExprKind::ECall(c, xs, _, _) => (tag_name_of(&lx, &**c), xs.clone()),
            crate::syntax::ExprKind::EName(n) => (tag_name_of(&lx, e), Array::new()),
            _ => (Text::lit(""), Array::new()),
        };
        let full = crate::lower::type_at(&lx, &e.span);
        match get(&lx.g.tags, &tag_name) {
            None => {
                let wx2 = {
                    let mut this: Wx = wx.clone();
                    this.build = push(&this.build, &crate::lower::refusal_do(&Text::lit("an element of an unknown tag")));
                    this
                };
                prism_rtl::Turn::Finished((wx2.clone(), Wres::WrUnit))
            },
            Some(tg) => {
                let pos = wx.pos.clone();
                let wx1 = {
                    let mut this: Wx = wx.clone();
                    this.pos = crate::lower::model::next_pos(&this.pos);
                    this
                };
                let struct_path = crate::lower::path_in(&lx, &tg.home, &crate::lower::tag_struct(&tg.name));
                let bound_opt = bound_opt.clone();
                let benv = benv.clone();
                let menv = menv.clone();
                call_value(fold_job(tg.fields.clone(), (Array::new(), Array::new(), Array::new(), wx1.clone()), {
                    let args = args.clone();
                    let menv = menv.clone();
                    let pos = pos.clone();
                    let tg = tg.clone();
                    let lx = lx.clone();
                    let benv = benv.clone();
                    Rc::new(move |(p0, p1): ((Array<(Text, crate::lower::model::Ex)>, Array<(Text, crate::lower::model::Ex)>, Array<Read>, Wx), (Text, crate::check::types::Ty))| {
                        let args = args.clone();
                        let menv = menv.clone();
                        let pos = pos.clone();
                        let tg = tg.clone();
                        let lx = lx.clone();
                        let benv = benv.clone();
                        entered(once_job(move || {
                            let (lf, cf, rd, w) = p0;
                            let (fname, fty) = p1;
                            match tag_arg(&args, &fname) {
                                None => prism_rtl::Turn::Finished((lf.clone(), cf.clone(), rd.clone(), w.clone())),
                                Some(arg) => match crate::lower::layer_of(&fty) {
                                    crate::lower::Layer::LyEv => call_then(start_event_ref(w.clone(), menv.clone(), arg.clone()), move |event_ref_36127: (EvRef, Wx)| {
                                        let (r, w2) = event_ref_36127;
                                        prism_rtl::Turn::Finished((lf.clone(), cf.clone(), rd.clone(), connect(&w2, &r, &Sk::SkRequest(pos.clone(), request_field(&tg, &fname)))))
                                    }),
                                    _ => call_then(start_dynamic_expr(w.clone(), menv.clone(), arg.clone()), move |dynamic_expr_36345: (crate::lower::model::Ex, Array<Read>)| {
                                        let (ex, rds) = dynamic_expr_36345;
                                        call_then(crate::lower::start_value_of(lx.clone(), benv.clone(), arg.clone()), move |value_of_36416: crate::lower::Vl| {
                                            let cv = crate::lower::own(&value_of_36416);
                                            prism_rtl::Turn::Finished((push(&lf, &(crate::lower::snake(&fname), ex.clone())), push(&cf, &(crate::lower::snake(&fname), cv.clone())), union_reads(&rd, &rds), w.clone()))
                                        })
                                    }),
                                },
                            }
                        }))
                    }) as Rc<dyn Fn(((Array<(Text, crate::lower::model::Ex)>, Array<(Text, crate::lower::model::Ex)>, Array<Read>, Wx), (Text, crate::check::types::Ty))) -> Rc<dyn prism_rtl::Job<(Array<(Text, crate::lower::model::Ex)>, Array<(Text, crate::lower::model::Ex)>, Array<Read>, Wx)>>>
                }), move |fold_35809: (Array<(Text, crate::lower::model::Ex)>, Array<(Text, crate::lower::model::Ex)>, Array<Read>, Wx)| {
                    let (live_fields, const_fields, reads, wx2) = fold_35809;
                    let live = &len(&reads) > &Nat::from(0u32);
                    let (getter, wx3) = if live {
                        fresh_name(&wx2, &crate::lower::snake(&crate::check::types::bare_name(&tg.name)))
                    } else {
                        (Text::lit(""), wx2.clone())
                    };
                    let variant = crate::lower::variant_of(&lx, &tg);
                    let level = crate::lower::model::Ex::XCtor(variant.clone(), Array::from(vec![crate::lower::model::Ex::XRecord(struct_path.clone(), if live { live_fields.clone() } else { const_fields.clone() })]));
                    let at_build = crate::lower::model::Ex::XCtor(variant.clone(), Array::from(vec![crate::lower::model::Ex::XRecord(struct_path.clone(), const_fields.clone())]));
                    let added = if live {
                        crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("node"))), getter.clone(), Array::from(vec![crate::lower::model::Ex::XCx]))
                    } else {
                        level.clone()
                    };
                    let wx4 = {
                        let mut this: Wx = wx3.clone();
                        this.places = push(&this.places, &Place { pos: pos.clone(), level: level.clone(), getter: getter.clone(), reads: reads.clone() });
                        this.build = if emits(&wx3, &pos) {
                            push(&this.build, &crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCx), Text::lit("added"), Array::from(vec![place_at(&wx3, &Text::lit("node"), &pos), crate::lower::model::Ex::XMethod(Rc::new(added.clone()), Text::lit("to_pod"), Array::new())]))))
                        } else {
                            this.build.clone()
                        };
                        this
                    };
                    prism_rtl::Turn::Finished(element_output(&wx4, &menv, &tg, &element_out(&lx, &tg, &full), &pos, &bound_opt, &at_build))
                })
            },
        }
    }
}

/// `Start ElementLine, x`: what the function value is when passed to `@Run`.
pub fn start_element_line(wx: Wx, benv: crate::lower::Env, menv: crate::lower::Env, e: crate::syntax::Expr, bound_opt: Option<crate::lower::Bn>) -> Rc<dyn prism_rtl::Job<(Wx, Wres)>> {
    Rc::new(ElementLine { wx, benv, menv, e, bound_opt })
}

/// ```prism
/// ElementOut: unbounded fn Lx, TagInfo, Ty -> OutTy
/// ```
pub fn element_out(lx: &crate::lower::Lx, tg: &crate::check::env::TagInfo, full: &crate::check::types::Ty) -> crate::lower::model::OutTy {
    let t = match crate::lower::peel(full) {
        crate::check::types::Ty::TyElem(_, o) => crate::lower::out_ty_of(lx, &crate::lower::peel(&*o)),
        _ => crate::lower::out_ty_of(lx, &crate::lower::peel(&tg.out)),
    };
    match &t {
        crate::lower::model::OutTy::OutGen(_) => crate::lower::model::OutTy::OutPod,
        _ => t.clone(),
    }
}

/// ```prism
/// TagNameOf: fn Lx, Expr -> Text
/// ```
pub fn tag_name_of(lx: &crate::lower::Lx, c: &crate::syntax::Expr) -> Text {
    match &*c.kind {
        crate::syntax::ExprKind::EName(n) => {
            let (qk_opt, _) = crate::check::env::resolve_value(&lx.g, &lx.home, n);
            or(&qk_opt, &crate::check::env::dotted(&n.path_))
        },
        crate::syntax::ExprKind::EGroup(x) => tag_name_of(lx, &**x),
        _ => Text::lit(""),
    }
}

/// ```prism
/// ?TagArg: fn [Arg], Text -> ?Expr
/// ```
pub fn tag_arg(args: &Array<crate::syntax::Arg>, fname: &Text) -> Option<crate::syntax::Expr> {
    fold(args, &None, &(|found_opt: &Option<crate::syntax::Expr>, a: &crate::syntax::Arg| match &a.name {
        Some(n) => if &n.name == fname { Some(a.value.clone()) } else { found_opt.clone() },
        None => found_opt.clone(),
    }))
}

/// ```prism
/// RequestField: fn TagInfo, Text -> Text
/// ```
pub fn request_field(tg: &crate::check::env::TagInfo, fname: &Text) -> Text {
    let evs = filter(&tg.fields, &(|(_, t): &(Text, crate::check::types::Ty)| &crate::lower::layer_of(t) == &crate::lower::Layer::LyEv));
    if &len(&evs) > &Nat::from(1u32) { fname.clone() } else { Text::lit("") }
}

/// ```prism
/// ElementOutput: unbounded fn Wx, Env, TagInfo, OutTy, Pos, ?Bn, Ex -> ((Wx, Wres))
/// ```
pub fn element_output(wx: &Wx, menv: &crate::lower::Env, tg: &crate::check::env::TagInfo, out: &crate::lower::model::OutTy, pos: &crate::lower::model::Pos_, bound_opt: &Option<crate::lower::Bn>, level: &crate::lower::model::Ex) -> (Wx, Wres) {
    let lx = wx.lx.clone();
    match bound_opt {
        Some(crate::lower::Bn::BnParts(parts)) => bundle_output(wx, tg, out, pos, parts, level),
        _ => element_output_of(wx, menv, tg, out, pos, bound_opt, level),
    }
}

/// ```prism
/// BundleOutput: unbounded fn Wx, TagInfo, OutTy, Pos, [?Bn], Ex -> ((Wx, Wres))
/// ```
pub fn bundle_output(wx: &Wx, tg: &crate::check::env::TagInfo, out: &crate::lower::model::OutTy, pos: &crate::lower::model::Pos_, parts: &Array<Option<crate::lower::Bn>>, level: &crate::lower::model::Ex) -> (Wx, Wres) {
    if !emits(wx, pos) {
        {
            let wx2 = {
                let mut this: Wx = wx.clone();
                this.build = push(&this.build, &crate::lower::refusal_do(&Text::from(format!("a bundle ({}) in a hosted scope", &tg.name))));
                this
            };
            (wx2.clone(), Wres::WrUnit)
        }
    } else {
        bundle_output_of(wx, tg, out, pos, parts, level)
    }
}

/// ```prism
/// BundleOutputOf: unbounded fn Wx, TagInfo, OutTy, Pos, [?Bn], Ex -> ((Wx, Wres))
/// ```
pub fn bundle_output_of(wx: &Wx, tg: &crate::check::env::TagInfo, out: &crate::lower::model::OutTy, pos: &crate::lower::model::Pos_, parts: &Array<Option<crate::lower::Bn>>, level: &crate::lower::model::Ex) -> (Wx, Wres) {
    let layers = match &tg.out {
        crate::check::types::Ty::TyTuple(cs) => each(cs, &(|c: &crate::check::types::Ty| crate::lower::layer_of(c))),
        _ => Array::new(),
    };
    let tys = match out {
        crate::lower::model::OutTy::OutTuple(ts) => ts.clone(),
        _ => Array::new(),
    };
    let idx = crate::check::errors::range0(&len(&layers));
    let plain_ix = filter(&idx, &(|i: &Nat| &or(&index(&layers, i), &crate::lower::Layer::LyPlain) == &crate::lower::Layer::LyPlain));
    let ev_ix = filter(&idx, &(|i: &Nat| &or(&index(&layers, i), &crate::lower::Layer::LyPlain) == &crate::lower::Layer::LyEv));
    let dyn_ix = filter(&idx, &(|i: &Nat| &or(&index(&layers, i), &crate::lower::Layer::LyPlain) == &crate::lower::Layer::LyDyn));
    let wx1 = bundle_first(wx, tg, pos, &plain_ix, &tys, parts, level);
    let wx2 = fold(&ev_ix, &wx1, &(|w: &Wx, i: &Nat| bundle_answer(w, pos, &or(&index(&tys, i), &crate::lower::model::OutTy::OutUnit), &or(&index(parts, i), &None))));
    if (&len(&ev_ix) > &Nat::from(1u32)) || (&len(&dyn_ix) > &Nat::from(0u32)) {
        {
            let wx3 = {
                let mut this: Wx = wx2.clone();
                this.build = push(&this.build, &crate::lower::refusal_do(&Text::from(format!("a bundle with a `$` part or two event parts ({})", &tg.name))));
                this
            };
            (wx3.clone(), Wres::WrUnit)
        }
    } else {
        (wx2.clone(), Wres::WrUnit)
    }
}

/// ```prism
/// BundleFirst: unbounded fn Wx, TagInfo, Pos, [Nat], [OutTy], [?Bn], Ex -> Wx
/// ```
pub fn bundle_first(wx: &Wx, tg: &crate::check::env::TagInfo, pos: &crate::lower::model::Pos_, plain_ix: &Array<Nat>, tys: &Array<crate::lower::model::OutTy>, parts: &Array<Option<crate::lower::Bn>>, level: &crate::lower::model::Ex) -> Wx {
    match plain_ix {
        m41142_0 if (m41142_0.len() == 0) => wx.clone(),
        _ => {
            let one = &len(plain_ix) == &Nat::from(1u32);
            let plain_ty = if one {
                or(&index(tys, &or(&index(plain_ix, &Nat::from(0u32)), &Nat::from(0u32))), &crate::lower::model::OutTy::OutUnit)
            } else {
                crate::lower::model::OutTy::OutTuple(each(plain_ix, &(|i: &Nat| or(&index(tys, i), &crate::lower::model::OutTy::OutUnit))))
            };
            let wx1 = {
                let mut this: Wx = wx.clone();
                this.lets = append(&this.lets, &Array::from(vec![first_value_let(wx, pos, tg, level), crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(Text::from(format!("bundle_{}", &crate::lower::model::place_text(pos)))), crate::lower::model::Ex::XDecode(plain_ty.clone(), Rc::new(crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XVar(Text::from(format!("first_{}", &crate::lower::model::place_text(pos)))))))))]));
                this.fallible = true;
                this
            };
            fold(&crate::check::errors::range0(&len(plain_ix)), &wx1, &(|w: &Wx, k: &Nat| {
                let i = or(&index(plain_ix, k), &Nat::from(0u32));
                match index(parts, &i) {
                    Some(Some(crate::lower::Bn::BnLocal(rs, _, _))) => {
                        let f = crate::lower::place_stem(&rs);
                        let part = if one {
                            crate::lower::model::Ex::XVar(Text::from(format!("bundle_{}", &crate::lower::model::place_text(pos))))
                        } else {
                            crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XPart(Rc::new(crate::lower::model::Ex::XVar(Text::from(format!("bundle_{}", &crate::lower::model::place_text(pos))))), k.clone())))
                        };
                        {
                            let mut this: Wx = w.clone();
                            this.lets = push(&this.lets, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(f.clone()), part.clone()));
                            this.fields = push(&this.fields, &(f.clone(), or(&index(tys, &i), &crate::lower::model::OutTy::OutUnit), Text::from(format!("place {}'s answer, part {} of its first value", &crate::lower::model::place_text(pos), &i))));
                            this.inits = push(&this.inits, &(f.clone(), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(f.clone())))));
                            this
                        }
                    },
                    _ => w.clone(),
                }
            }))
        },
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// BundleAnswer: fn Wx, Pos, OutTy, ?Bn -> Wx
/// ```
pub fn bundle_answer(wx: &Wx, pos: &crate::lower::model::Pos_, et: &crate::lower::model::OutTy, b_opt: &Option<crate::lower::Bn>) -> Wx {
    let t = match et {
        crate::lower::model::OutTy::OutEvent(inner) => (**inner).clone(),
        _ => et.clone(),
    };
    let (id, wx2) = match b_opt {
        Some(crate::lower::Bn::BnEv(er, _)) => (er.node_.clone(), wx.clone()),
        _ => {
            let (nm, w) = fresh_name(wx, &Text::from(format!("place_{}", &crate::lower::model::place_text(pos))));
            add_gn(&w, &nm, &t, &GnKind::GnAnswer, &Nat::from(0u32))
        },
    };
    let mut this: Wx = wx2.clone();
    this.answers = push(&this.answers, &(pos.clone(), id.clone(), t.clone(), Text::lit("")));
    this
}

/// ```prism
/// FirstValueLet: fn Wx, Pos, TagInfo, Ex -> Do
/// ```
pub fn first_value_let(wx: &Wx, pos: &crate::lower::model::Pos_, tg: &crate::check::env::TagInfo, level: &crate::lower::model::Ex) -> crate::lower::model::Do {
    let missing = crate::lower::model::Ex::XCall(Text::lit("Fault::answer"), Array::from(vec![crate::lower::model::Ex::XStr(Text::from(format!("no first value for {}", &tg.name)))]));
    if emits(wx, pos) {
        {
            let asked = crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCx), Text::lit("first_value"), Array::from(vec![crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(level.clone()), Text::lit("to_pod"), Array::new())))]));
            crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(Text::from(format!("first_{}", &crate::lower::model::place_text(pos)))), crate::lower::try_of(&crate::lower::model::Ex::XMethod(Rc::new(asked.clone()), Text::lit("ok_or"), Array::from(vec![missing.clone()]))))
        }
    } else {
        {
            let host = host_local(wx, pos);
            let asked = crate::lower::try_of(&crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(host.clone())), Text::lit("first_value"), Array::from(vec![crate::lower::model::Ex::XRef(Rc::new(place_at(wx, &Text::lit(""), pos))), crate::lower::model::Ex::XRef(Rc::new(level.clone())), crate::lower::model::Ex::XCx])));
            crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(Text::from(format!("first_{}", &crate::lower::model::place_text(pos)))), crate::lower::try_of(&crate::lower::model::Ex::XMethod(Rc::new(crate::lower::try_of(&crate::lower::model::Ex::XMethod(Rc::new(asked.clone()), Text::lit("ok_or"), Array::from(vec![missing.clone()])))), answer_accessor(tg), Array::new())))
        }
    }
}

/// ```prism
/// HostLocal: fn Wx, Pos -> Text
/// ```
pub fn host_local(wx: &Wx, pos: &crate::lower::model::Pos_) -> Text {
    if &pos.scope == &Nat::from(0u32) {
        Text::lit("enclosing")
    } else {
        or(&index(&wx.scopes, &crate::syntax::lexer::dec(&pos.scope)), &Text::lit(""))
    }
}

/// ```prism
/// AnswerVariant: fn TagInfo -> Text
/// ```
pub fn answer_variant(tg: &crate::check::env::TagInfo) -> Text {
    Text::from(format!("crate::Answer::{}", &crate::lower::tag_struct(&tg.name)))
}

/// ```prism
/// AnswerAccessor: fn TagInfo -> Text
/// ```
pub fn answer_accessor(tg: &crate::check::env::TagInfo) -> Text {
    crate::lower::snake(&crate::lower::tag_struct(&tg.name))
}

/// ```prism
/// ElementOutputOf: unbounded fn Wx, Env, TagInfo, OutTy, Pos, ?Bn, Ex -> ((Wx, Wres))
/// ```
pub fn element_output_of(wx: &Wx, menv: &crate::lower::Env, tg: &crate::check::env::TagInfo, out: &crate::lower::model::OutTy, pos: &crate::lower::model::Pos_, bound_opt: &Option<crate::lower::Bn>, level: &crate::lower::model::Ex) -> (Wx, Wres) {
    let lx = wx.lx.clone();
    match crate::lower::layer_of(&tg.out) {
        crate::lower::Layer::LyEv => {
            let (id, wx2) = match bound_opt {
                Some(crate::lower::Bn::BnEv(er, _)) => (er.node_.clone(), wx.clone()),
                _ => {
                    let (nm, w) = fresh_name(wx, &Text::from(format!("place_{}", &crate::lower::model::place_text(pos))));
                    add_gn(&w, &nm, out, &GnKind::GnAnswer, &Nat::from(0u32))
                },
            };
            let wx3 = {
                let mut this: Wx = wx2.clone();
                this.answers = push(&this.answers, &(pos.clone(), id.clone(), out.clone(), answer_accessor(tg)));
                this
            };
            (wx3.clone(), Wres::WrEv(ev_ref_of(&wx3, &id)))
        },
        crate::lower::Layer::LyDyn => {
            let (f, wx1) = match bound_opt {
                Some(crate::lower::Bn::BnHold(hf, _)) => (hf.clone(), wx.clone()),
                _ => fresh_name(wx, &Text::from(format!("place_{}", &crate::lower::model::place_text(pos)))),
            };
            let emits_ = emits(wx, pos);
            let first_ = if emits_ {
                crate::lower::model::Ex::XDecode(out.clone(), Rc::new(crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XVar(Text::from(format!("first_{}", &crate::lower::model::place_text(pos))))))))
            } else {
                crate::lower::model::Ex::XVar(Text::from(format!("first_{}", &crate::lower::model::place_text(pos))))
            };
            let wx2 = {
                let mut this: Wx = wx1.clone();
                this.lets = push(&this.lets, &first_value_let(wx, pos, tg, level));
                this.fields = push(&this.fields, &(f.clone(), crate::lower::model::OutTy::OutHold(Rc::new(out.clone())), Text::from(format!("pushed to place {}", &crate::lower::model::place_text(pos)))));
                this.inits = push(&this.inits, &(f.clone(), crate::lower::model::Ex::XCall(Text::lit("Hold::new"), Array::from(vec![first_.clone(), crate::lower::model::Ex::XCx]))));
                this.dyn_places = push(&this.dyn_places, &(pos.clone(), f.clone(), out.clone(), answer_accessor(tg)));
                this.fallible = true;
                this
            };
            let wx3 = if emits_ {
                {
                    let mut this: Wx = wx2.clone();
                    this.lets = push(&this.lets, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(Text::from(format!("{}_element", &f))), crate::lower::model::Ex::XMethod(Rc::new(level.clone()), Text::lit("to_pod"), Array::new())));
                    this.fields = push(&this.fields, &(Text::from(format!("{}_element", &f)), crate::lower::model::OutTy::OutPod, Text::from(format!("place {}'s element, which pushes are keyed by", &crate::lower::model::place_text(pos)))));
                    this.moves = push(&this.moves, &(Text::from(format!("{}_element", &f)), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(Text::from(format!("{}_element", &f)))))));
                    this.build = push(&this.build, &crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCx), Text::lit("listen"), Array::from(vec![crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XVar(Text::lit("node"))), Text::from(format!("{}_element", &f))))), crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XCast(Rc::new(crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(Text::lit("node"))))), crate::lower::model::OutTy::OutObj(Rc::new(crate::lower::model::OutTy::OutNamed(Text::lit("Node"), Array::new()))))))]))));
                    this
                }
            } else {
                wx2.clone()
            };
            (wx3.clone(), Wres::WrDyn(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", &f)))), Text::lit("get"), Array::from(vec![crate::lower::model::Ex::XCx])), Array::from(vec![Read::OwnRead(f.clone())]), out.clone()))
        },
        _ => match bound_opt {
            Some(crate::lower::Bn::BnLocal(rs, _, _)) => {
                let f = crate::lower::place_stem(rs);
                let first_ = if emits(wx, pos) {
                    crate::lower::model::Ex::XDecode(out.clone(), Rc::new(crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XVar(Text::from(format!("first_{}", &crate::lower::model::place_text(pos))))))))
                } else {
                    crate::lower::model::Ex::XVar(Text::from(format!("first_{}", &crate::lower::model::place_text(pos))))
                };
                let wx2 = {
                    let mut this: Wx = wx.clone();
                    this.lets = append(&this.lets, &Array::from(vec![first_value_let(wx, pos, tg, level), crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(f.clone()), first_.clone())]));
                    this.fields = push(&this.fields, &(f.clone(), out.clone(), Text::from(format!("place {}'s answer, its first value", &crate::lower::model::place_text(pos)))));
                    this.inits = push(&this.inits, &(f.clone(), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(f.clone())))));
                    this.fallible = true;
                    this
                };
                (wx2.clone(), Wres::WrUnit)
            },
            _ => (wx.clone(), Wres::WrUnit),
        },
    }
}

/// ```prism
/// WidgetLine: unbounded fn Wx, Env, Env, Expr, ?Bn -> ((Wx, Wres))
/// ```
pub fn widget_line(wx: &Wx, benv: &crate::lower::Env, menv: &crate::lower::Env, e: &crate::syntax::Expr, bound_opt: &Option<crate::lower::Bn>) -> (Wx, Wres) {
    let lx = wx.lx.clone();
    let (callee, args) = match &*e.kind {
        crate::syntax::ExprKind::ECall(c, xs, _, _) => ((**c).clone(), xs.clone()),
        _ => (e.clone(), Array::new()),
    };
    let qk = match &*callee.kind {
        crate::syntax::ExprKind::EName(n) => {
            let (q_opt, _) = crate::check::env::resolve_value(&lx.g, &lx.home, n);
            or(&q_opt, &Text::lit(""))
        },
        _ => Text::lit(""),
    };
    let target_opt = match bound_opt {
        Some(crate::lower::Bn::BnEv(er, _)) => Some(er.node_.clone()),
        _ => None,
    };
    let param_opt = match &*callee.kind {
        crate::syntax::ExprKind::EName(n) => if &len(&n.path_) == &Nat::from(1u32) {
            get(&menv.names, &crate::check::env::sname_key(n))
        } else {
            None
        },
        _ => None,
    };
    match &param_opt {
        Some(crate::lower::Bn::BnWidget(x, cbenv, cmenv, clx)) => apply_widget_param(wx, x, cbenv, cmenv, clx, &len(&args)),
        _ => widget_call(wx, benv, menv, e, bound_opt, &qk, &args, &target_opt),
    }
}

/// The step machine of `WidgetLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// WidgetLine: unbounded fn Wx, Env, Env, Expr, ?Bn -> ((Wx, Wres))
/// ```
pub struct WidgetLine {
    pub wx: Wx,
    pub benv: crate::lower::Env,
    pub menv: crate::lower::Env,
    pub e: crate::syntax::Expr,
    pub bound_opt: Option<crate::lower::Bn>,
}

impl prism_rtl::Job<(Wx, Wres)> for WidgetLine {
    fn cycle(&self) -> prism_rtl::Turn<(Wx, Wres)> {
        let wx = &self.wx;
        let benv = &self.benv;
        let menv = &self.menv;
        let e = &self.e;
        let bound_opt = &self.bound_opt;
        let lx = wx.lx.clone();
        let (callee, args) = match &*e.kind {
            crate::syntax::ExprKind::ECall(c, xs, _, _) => ((**c).clone(), xs.clone()),
            _ => (e.clone(), Array::new()),
        };
        let qk = match &*callee.kind {
            crate::syntax::ExprKind::EName(n) => {
                let (q_opt, _) = crate::check::env::resolve_value(&lx.g, &lx.home, n);
                or(&q_opt, &Text::lit(""))
            },
            _ => Text::lit(""),
        };
        let target_opt = match bound_opt {
            Some(crate::lower::Bn::BnEv(er, _)) => Some(er.node_.clone()),
            _ => None,
        };
        let param_opt = match &*callee.kind {
            crate::syntax::ExprKind::EName(n) => if &len(&n.path_) == &Nat::from(1u32) {
                get(&menv.names, &crate::check::env::sname_key(n))
            } else {
                None
            },
            _ => None,
        };
        match &param_opt {
            Some(crate::lower::Bn::BnWidget(x, cbenv, cmenv, clx)) => prism_rtl::Turn::Finished(apply_widget_param(wx, x, cbenv, cmenv, clx, &len(&args))),
            _ => prism_rtl::Turn::Finished(widget_call(wx, benv, menv, e, bound_opt, &qk, &args, &target_opt)),
        }
    }
}

/// `Start WidgetLine, x`: what the function value is when passed to `@Run`.
pub fn start_widget_line(wx: Wx, benv: crate::lower::Env, menv: crate::lower::Env, e: crate::syntax::Expr, bound_opt: Option<crate::lower::Bn>) -> Rc<dyn prism_rtl::Job<(Wx, Wres)>> {
    Rc::new(WidgetLine { wx, benv, menv, e, bound_opt })
}

/// ```prism
/// ApplyWidgetParam: unbounded fn Wx, Expr, Env, Env, Lx, Nat -> ((Wx, Wres))
/// ```
pub fn apply_widget_param(wx: &Wx, x: &crate::syntax::Expr, cbenv: &crate::lower::Env, cmenv: &crate::lower::Env, clx: &crate::lower::Lx, nargs: &Nat) -> (Wx, Wres) {
    if nargs > &Nat::from(0u32) {
        {
            let wx2 = {
                let mut this: Wx = wx.clone();
                this.build = push(&this.build, &crate::lower::refusal_do(&Text::lit("a widget parameter applied to arguments")));
                this
            };
            (wx2.clone(), Wres::WrUnit)
        }
    } else {
        if &wx.depth > &Nat::from(32u32) {
            (wx.clone(), Wres::WrUnit)
        } else {
            {
                let lx = wx.lx.clone();
                let inner = {
                    let mut this: Wx = wx.clone();
                    this.lx = clx.clone();
                    this.depth = &this.depth + &Nat::from(1u32);
                    this
                };
                let (done, res) = build_line(&inner, cbenv, cmenv, x, &None);
                let back_ = {
                    let mut this: Wx = done.clone();
                    this.lx = lx.clone();
                    this.depth = wx.depth.clone();
                    this
                };
                (back_.clone(), res.clone())
            }
        }
    }
}

/// ```prism
/// InlineBlock: unbounded fn Wx, Env, Env, Block, Lx -> ((Wx, Wres))
/// ```
pub fn inline_block(wx: &Wx, benv: &crate::lower::Env, menv: &crate::lower::Env, b: &crate::syntax::Block, lx: &crate::lower::Lx) -> (Wx, Wres) {
    let inner = {
        let mut this: Wx = wx.clone();
        this.result = Wres::WrUnit;
        this
    };
    let done = block_into(&inner, benv, menv, b);
    let back_ = {
        let mut this: Wx = done.clone();
        this.result = wx.result.clone();
        this
    };
    (back_.clone(), done.result.clone())
}

/// The step machine of `InlineBlock`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InlineBlock: unbounded fn Wx, Env, Env, Block, Lx -> ((Wx, Wres))
/// ```
pub struct InlineBlock {
    pub wx: Wx,
    pub benv: crate::lower::Env,
    pub menv: crate::lower::Env,
    pub b: crate::syntax::Block,
    pub lx: crate::lower::Lx,
}

impl prism_rtl::Job<(Wx, Wres)> for InlineBlock {
    fn cycle(&self) -> prism_rtl::Turn<(Wx, Wres)> {
        let wx = &self.wx;
        let benv = &self.benv;
        let menv = &self.menv;
        let b = &self.b;
        let lx = &self.lx;
        let inner = {
            let mut this: Wx = wx.clone();
            this.result = Wres::WrUnit;
            this
        };
        let b = b.clone();
        let benv = benv.clone();
        let menv = menv.clone();
        let wx = wx.clone();
        call_then(start_block_into(inner.clone(), benv.clone(), menv.clone(), b.clone()), move |block_into_50040: Wx| {
            let done = block_into_50040;
            let back_ = {
                let mut this: Wx = done.clone();
                this.result = wx.result.clone();
                this
            };
            prism_rtl::Turn::Finished((back_.clone(), done.result.clone()))
        })
    }
}

/// `Start InlineBlock, x`: what the function value is when passed to `@Run`.
pub fn start_inline_block(wx: Wx, benv: crate::lower::Env, menv: crate::lower::Env, b: crate::syntax::Block, lx: crate::lower::Lx) -> Rc<dyn prism_rtl::Job<(Wx, Wres)>> {
    Rc::new(InlineBlock { wx, benv, menv, b, lx })
}

/// ```prism
/// WidgetCall: unbounded fn Wx, Env, Env, Expr, ?Bn, Text, [Arg], ?Nat -> ((Wx, Wres))
/// ```
pub fn widget_call(wx: &Wx, benv: &crate::lower::Env, menv: &crate::lower::Env, e: &crate::syntax::Expr, bound_opt: &Option<crate::lower::Bn>, qk: &Text, args: &Array<crate::syntax::Arg>, target_opt: &Option<Nat>) -> (Wx, Wres) {
    let lx = wx.lx.clone();
    match qk {
        m50324_0 if (m50324_0 == &Text::lit("Prelude.@started")) => started_line(wx, bound_opt),
        m50324_1 if (m50324_1 == &Text::lit("Prelude.@Switch")) => switch_line(wx, menv, args),
        m50324_2 if (m50324_2 == &Text::lit("Prelude.@Flatten")) => flatten_line(wx, menv, args, bound_opt),
        m50324_3 if (m50324_3 == &Text::lit("Prelude.@Defer")) => defer_line(wx, menv, args, e, target_opt),
        m50324_4 if (m50324_4 == &Text::lit("Prelude.@Run")) => run_line(wx, benv, args, e, target_opt),
        m50324_5 if (m50324_5 == &Text::lit("Prelude.@Machine")) => machine_line(wx, benv, menv, args, e, target_opt),
        m50324_6 if (m50324_6 == &Text::lit("Prelude.@HostDocument")) => host_line(wx, benv, menv, &HostForm::HostEach, args, bound_opt),
        m50324_7 if (m50324_7 == &Text::lit("Prelude.@HostSome")) => host_line(wx, benv, menv, &HostForm::HostSome, args, bound_opt),
        _ => match get(&lx.g.vals, qk) {
            Some(v_) => inline_widget(wx, benv, menv, qk, &v_, args, e),
            None => {
                let wx2 = {
                    let mut this: Wx = wx.clone();
                    this.build = push(&this.build, &crate::lower::refusal_do(&Text::lit("a widget this back end does not lower yet")));
                    this
                };
                (wx2.clone(), Wres::WrUnit)
            },
        },
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// HostLine: unbounded fn Wx, Env, Env, HostForm, [Arg], ?Bn -> ((Wx, Wres))
/// ```
pub fn host_line(wx: &Wx, benv: &crate::lower::Env, menv: &crate::lower::Env, form: &HostForm, args: &Array<crate::syntax::Arg>, bound_opt: &Option<crate::lower::Bn>) -> (Wx, Wres) {
    let lx = wx.lx.clone();
    let pos = wx.pos.clone();
    let k = &len(&wx.scopes) + &Nat::from(1u32);
    let hf = Text::from(format!("host_{}", &k));
    let rows_name = Text::from(format!("{}_rows", &hf));
    let doc_getter = Text::from(format!("{}_doc", &hf));
    let wx1 = {
        let mut this: Wx = wx.clone();
        this.taken = append(&this.taken, &Array::from(vec![hf.clone(), rows_name.clone(), doc_getter.clone(), Text::from(format!("{}_now", &doc_getter)), Text::from(format!("{}_snap", &doc_getter)), Text::from(format!("{}_direct", &doc_getter)), Text::from(format!("{}_publish", &doc_getter)), Text::from(format!("{}_answer", &hf)), Text::from(format!("{}_moved", &hf))]));
        this
    };
    let named = match index(args, &Nat::from(1u32)) {
        Some(sup) => is_widget_name(&sup.value),
        None => false,
    };
    match (index(args, &Nat::from(0u32)), index(args, &Nat::from(1u32))) {
        (Some(_), Some(_)) if named => {
            let wx2 = {
                let mut this: Wx = wx1.clone();
                this.pos = crate::lower::model::next_pos(&this.pos);
                this.build = push(&this.build, &crate::lower::refusal_do(&Text::lit("a named widget function as a host's supplier (gap NS): a lambda supplier is lowered, a widget function is not a value")));
                this
            };
            (wx2.clone(), Wres::WrHosted(Rc::new(Wres::WrUnit), crate::lower::Bn::BnLocal(crate::lower::model::Ex::XUnit, crate::lower::Holding::Owned, crate::lower::model::OutTy::OutUnit)))
        },
        (Some(child), Some(sup)) => {
            let (wxd, dyn_env, dyn_lets) = dynamic_answers(&wx1, benv, menv, &hf, &sup.value);
            let offered = crate::lower::own(&crate::lower::value_of(&lx, &dyn_env, &sup.value));
            let supplier0 = match form {
                HostForm::HostEach => offered.clone(),
                HostForm::HostSome => crate::lower::model::Ex::XCall(Text::lit("prism_rtl::forward_on_none"), Array::from(vec![offered.clone()])),
            };
            let supplier = if &len(&dyn_lets) == &Nat::from(0u32) {
                supplier0.clone()
            } else {
                crate::lower::model::Ex::XBlock(dyn_lets.clone(), Rc::new(supplier0.clone()))
            };
            let enclosing = if emits(wx, &pos) {
                crate::lower::model::Ex::XNone
            } else {
                crate::lower::model::Ex::XCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Ex::XCast(Rc::new(crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(host_local(wx, &pos))))), crate::lower::host_of_ty())]))
            };
            let made = crate::lower::model::Ex::XCall(Text::lit("prism_rtl::Host::new"), Array::from(vec![place_at(wx, &Text::lit(""), &pos), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(rows_name.clone()))), supplier.clone(), enclosing.clone(), crate::lower::model::Ex::XPath(Text::from(format!("{}::{}_direct", &wx.node_, &doc_getter))), crate::lower::model::Ex::XPath(Text::from(format!("{}::{}_answer", &wx.node_, &hf)))]));
            let host_ty = crate::lower::model::OutTy::OutRc(Rc::new(crate::lower::model::OutTy::OutNamed(Text::lit("prism_rtl::Host"), Array::from(vec![crate::lower::elem_ty(), crate::lower::answer_ty_value(), crate::lower::model::OutTy::OutNamed(wx.node_.clone(), Array::new())]))));
            let rows_ty = crate::lower::model::OutTy::OutNamed(Text::lit("prism_rtl::Rows"), Array::from(vec![crate::lower::elem_ty(), crate::lower::answer_ty_value()]));
            let doc_ty = crate::lower::model::OutTy::OutMap(Rc::new(crate::lower::model::OutTy::OutPath), Rc::new(crate::lower::elem_ty()));
            let what = Text::from(format!("the document of the child hosted at place {}", &crate::lower::model::place_text(&pos)));
            let wx2 = {
                let mut this: Wx = wxd.clone();
                this.pos = crate::lower::model::next_pos(&this.pos);
                this.lets = append(&this.lets, &Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaBind(rows_name.clone())), rows_ty.clone()), crate::lower::model::Ex::XCall(Text::lit("Rc::new"), Array::from(vec![crate::lower::model::Ex::XCall(Text::lit("RefCell::new"), Array::from(vec![crate::lower::model::Ex::XCall(Text::lit("Map::new"), Array::new())]))]))), crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(hf.clone()), made.clone())]));
                this.fields = append(&this.fields, &Array::from(vec![(hf.clone(), host_ty.clone(), Text::from(format!("the host at place {}: its supplier, its rows, and the way back into its child (pick HO)", &crate::lower::model::place_text(&pos)))), (rows_name.clone(), rows_ty.clone(), Text::from(format!("the rows of the host at place {}: `for p, e <- $doc`, one supplier blueprint per child place", &crate::lower::model::place_text(&pos)))), (Text::from(format!("{}_snap", &doc_getter)), crate::lower::model::OutTy::OutSnapshot(Rc::new(doc_ty.clone())), Text::from(format!("`$doc` of the host at place {}, a structural dynamic: its snapshots, the structure and the lagged dynamic (pick ST)", &crate::lower::model::place_text(&pos))))]));
                this.moves = append(&this.moves, &Array::from(vec![(hf.clone(), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(hf.clone())))), (rows_name.clone(), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(rows_name.clone()))))]));
                this.inits = push(&this.inits, &(Text::from(format!("{}_snap", &doc_getter)), crate::lower::model::Ex::XCall(Text::lit("Snapshot::new"), Array::from(vec![crate::lower::model::Ex::XStr(what.clone())]))));
                this.hosts = push(&this.hosts, &HostDef { pos: pos.clone(), name: hf.clone(), scope: k.clone() });
                this.snaps = push(&this.snaps, &SnapDef { name: doc_getter.clone(), live: Text::from(format!("{}_now", &doc_getter)), ty: doc_ty.clone(), eq: true, builder: rows_name.clone(), before: true, what: what.clone() });
                this.getters = append(&this.getters, &Array::from(vec![snap_getter(&doc_getter, &doc_ty, &Text::from(format!("The document of the child hosted at place {}, `$doc`, a structural dynamic (pick ST): one tick behind the child's structure, the snapshot of the tick before the tick the read point is after.", &crate::lower::model::place_text(&pos)))), crate::lower::model::MethDef { name: Text::from(format!("{}_direct", &doc_getter)), recv: crate::lower::model::Recv::RecvRef, params: Array::new(), cx_: crate::lower::model::CxArg::CxRef, ret: doc_ty.clone(), body: Array::new(), tail: crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_snap", &doc_getter)))), Text::lit("current"), Array::from(vec![crate::lower::model::Ex::XCx])), doc: Text::from(format!("The structure of the child hosted at place {}, not the lagged `$doc`: the snapshot taken in this tick's construction step, the document as the tick opened during propagation. The host's own `for` and its rows' entries read it, so a newborn child place gets its row in the tick it is born (pick ST).", &crate::lower::model::place_text(&pos))) }]));
                this.scopes = push(&this.scopes, &hf);
                this.builders = push(&this.builders, &crate::lower::model::ForDef { name: rows_name.clone(), pos: pos.clone(), at: place_at(wx, &Text::lit("self"), &pos), key_ty: crate::lower::model::OutTy::OutPath, value_ty: crate::lower::elem_ty(), row_node: Text::lit("prism_rtl::HostRow::<crate::Elem, crate::Answer>"), keyed: true, source: Text::from(format!("{}_direct", &doc_getter)), parent: crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), hf.clone()))), passed: Array::new() });
                this.build_holds = add_read(&this.build_holds, &Read::OwnRead(Text::from(format!("{}_now", &doc_getter))));
                this.row_marks = push(&this.row_marks, &RowMarks { builder: rows_name.clone(), reads: Array::from(vec![Read::OwnRead(Text::from(format!("{}_now", &doc_getter)))]), wrote: Array::new(), kind: crate::lower::model::RowKind::ForRow });
                this.fallible = true;
                this
            };
            let inner = {
                let mut this: Wx = wx2.clone();
                this.pos = crate::lower::model::scope_pos(&k);
                this.result = Wres::WrUnit;
                this
            };
            let (done, res) = build_line(&inner, benv, menv, &child.value, &None);
            let child_places = drop(&done.places, &len(&wx2.places));
            let child_builds = filter(&done.build_holds, &(|h: &Read| !has_read(&wx2.build_holds, h)));
            let child_gens = fold(&drop(&done.gen_holds, &len(&wx2.gen_holds)), &Array::new(), &(|acc: &Array<Read>, (_, hs): &(Text, Array<Read>)| union_reads(acc, hs)));
            let child_rows = fold(&drop(&done.row_marks, &len(&wx2.row_marks)), &Array::new(), &(|acc: &Array<Read>, rm: &RowMarks| union_reads(acc, &rm.reads)));
            let doc_reads = fold(&child_places, &union_reads(&union_reads(&child_builds, &child_gens), &child_rows), &(|acc: &Array<Read>, pl: &Place| union_reads(acc, &pl.reads)));
            let in_scope_fn = {
                let k = k.clone();
                Rc::new(move |p_: &crate::lower::model::Pos_| &p_.scope == &k)
            };
            let getter = host_doc_getter(&Text::from(format!("{}_now", &doc_getter)), &pos, &filter(&child_places, &(|pl: &Place| (&in_scope_fn)(&pl.pos))), &filter(&drop(&done.builders, &len(&wx2.builders)), &(|b: &crate::lower::model::ForDef| (&in_scope_fn)(&b.pos))), &filter(&drop(&done.gens, &len(&wx2.gens)), &(|gd: &crate::lower::model::GenDef| (&in_scope_fn)(&gd.pos))));
            let back_ = {
                let mut this: Wx = done.clone();
                this.pos = wx2.pos.clone();
                this.result = wx.result.clone();
                this.getters = push(&this.getters, &getter);
                this.dyn_reads = insert(&this.dyn_reads, &Text::from(format!("{}_now", &doc_getter)), &doc_reads);
                this
            };
            let doc_bn = crate::lower::Bn::BnDyn(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XSelf), doc_getter.clone(), Array::from(vec![crate::lower::model::Ex::XCx])), Array::from(vec![Read::OwnRead(doc_getter.clone())]), doc_ty.clone());
            (back_.clone(), Wres::WrHosted(Rc::new(res.clone()), doc_bn.clone()))
        },
        _ => {
            let wx2 = {
                let mut this: Wx = wx1.clone();
                this.pos = crate::lower::model::next_pos(&this.pos);
                this.build = push(&this.build, &crate::lower::refusal_do(&Text::lit("a host without its child or its supplier")));
                this
            };
            (wx2.clone(), Wres::WrHosted(Rc::new(Wres::WrUnit), crate::lower::Bn::BnLocal(crate::lower::model::Ex::XUnit, crate::lower::Holding::Owned, crate::lower::model::OutTy::OutUnit)))
        },
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// IsWidgetName: fn Expr -> Bool
/// ```
pub fn is_widget_name(e: &crate::syntax::Expr) -> bool {
    match &*e.kind {
        crate::syntax::ExprKind::EName(n) => crate::syntax::lexer::has_prefix(&crate::check::env::sname_key(n), &Text::lit("@")),
        crate::syntax::ExprKind::EGroup(x) => is_widget_name(&**x),
        _ => false,
    }
}

/// ```prism
/// DynamicAnswers: unbounded fn Wx, Env, Env, Text, Expr -> ((Wx, Env, [Do]))
/// ```
pub fn dynamic_answers(wx: &Wx, benv: &crate::lower::Env, menv: &crate::lower::Env, hf: &Text, sup: &crate::syntax::Expr) -> (Wx, crate::lower::Env, Array<crate::lower::model::Do>) {
    let lx = wx.lx.clone();
    let dyns = fold(&crate::check::typed::exprs_in(sup), &Array::new(), &(|acc: &Array<(crate::syntax::Expr, crate::syntax::Expr)>, x: &crate::syntax::Expr| match &*x.kind {
        crate::syntax::ExprKind::EFreeSigil(m60487_0_0, y) if (m60487_0_0 == &Text::lit("@")) => match dynamic_answer(&lx, &**y) {
            Some(d) => push(acc, &((**y).clone(), d.clone())),
            None => acc.clone(),
        },
        _ => acc.clone(),
        _ => unreachable!("no arm matched"),
    }));
    if &len(&dyns) == &Nat::from(0u32) {
        (wx.clone(), benv.clone(), Array::new())
    } else {
        {
            let owner = Text::from(format!("{}_owner", hf));
            let wx1 = {
                let mut this: Wx = wx.clone();
                this.taken = push(&this.taken, &owner);
                this.lets = push(&this.lets, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(owner.clone()), crate::lower::model::Ex::XCall(Text::from(format!("prism_rtl::Link::<{}>::new", &wx.node_)), Array::new())));
                this.build = push(&this.build, &crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(owner.clone())), Text::lit("link"), Array::from(vec![crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XVar(Text::lit("node"))))]))));
                this
            };
            let env0 = crate::lower::bind(benv, &Text::lit("#owner"), &crate::lower::Bn::BnLocal(crate::lower::model::Ex::XVar(owner.clone()), crate::lower::Holding::Owned, crate::lower::model::OutTy::OutUnit));
            let lets0 = Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(owner.clone()), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(owner.clone()))))]);
            run_to_end(fold_job(crate::check::errors::range0(&len(&dyns)), (wx1.clone(), env0.clone(), lets0.clone()), {
                let dyns = dyns.clone();
                let hf = hf.clone();
                let menv = menv.clone();
                let lx = lx.clone();
                Rc::new(move |(p0, p1): ((Wx, crate::lower::Env, Array<crate::lower::model::Do>), Nat)| {
                    let dyns = dyns.clone();
                    let hf = hf.clone();
                    let menv = menv.clone();
                    let lx = lx.clone();
                    entered(once_job(move || {
                        let (w, en, ls) = p0;
                        let j = p1;
                        match index(&dyns, &j) {
                            Some((y, d)) => {
                                let name = Text::from(format!("{}_dyn_{}", &hf, &(&j + &Nat::from(1u32))));
                                let port = Text::from(format!("{}_port", &name));
                                call_then(start_dynamic_expr(w.clone(), menv.clone(), d.clone()), move |dynamic_expr_61399: (crate::lower::model::Ex, Array<Read>)| {
                                    let (ex, reads) = dynamic_expr_61399;
                                    call_then(crate::lower::start_out_ty_of(lx.clone(), crate::lower::peel(&crate::lower::type_at(&lx, &d.span))), move |out_ty_of_61446: crate::lower::model::OutTy| {
                                        let t = out_ty_of_61446;
                                        if !all_inited(&w, &reads) {
                                            prism_rtl::Turn::Finished((w.clone(), en.clone(), ls.clone()))
                                        } else {
                                            {
                                                let w2 = {
                                                    let mut this: Wx = w.clone();
                                                    this.taken = append(&this.taken, &Array::from(vec![name.clone(), port.clone()]));
                                                    this.getters = push(&this.getters, &crate::lower::model::MethDef { name: name.clone(), recv: crate::lower::model::Recv::RecvRef, params: Array::new(), cx_: crate::lower::model::CxArg::CxRef, ret: t.clone(), body: Array::new(), tail: ex.clone(), doc: Text::from(format!("The host at `{}`'s dynamic answer `{}`, read at the read point (round 3 DY).", &hf, &crate::lower::src_text(&lx, &lx.file, &y.span))) });
                                                    this.lets = push(&this.lets, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaBind(port.clone())), crate::lower::model::OutTy::OutRc(Rc::new(crate::lower::model::OutTy::OutPort(Rc::new(crate::lower::model::OutTy::OutUnit))))), crate::lower::model::Ex::XCall(Text::lit("Rc::new"), Array::from(vec![crate::lower::model::Ex::XCall(Text::lit("Port::new"), Array::new())]))));
                                                    this.fields = push(&this.fields, &(port.clone(), crate::lower::model::OutTy::OutRc(Rc::new(crate::lower::model::OutTy::OutPort(Rc::new(crate::lower::model::OutTy::OutUnit)))), Text::from(format!("the dynamic answer `{}` moved: its blueprints push the child's place next tick", &name))));
                                                    this.moves = push(&this.moves, &(port.clone(), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(port.clone())))));
                                                    this.dyn_answers = push(&this.dyn_answers, &(name.clone(), reads.clone()));
                                                    this
                                                };
                                                prism_rtl::Turn::Finished((w2.clone(), crate::lower::bind(&en, &Text::from(format!("#dyn{}", &dyn_key(&y))), &crate::lower::Bn::BnLocal(crate::lower::model::Ex::XVar(name.clone()), crate::lower::Holding::Owned, t.clone())), push(&ls, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(port.clone()), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(port.clone())))))))
                                            }
                                        }
                                    })
                                })
                            },
                            None => prism_rtl::Turn::Finished((w.clone(), en.clone(), ls.clone())),
                        }
                    }))
                }) as Rc<dyn Fn(((Wx, crate::lower::Env, Array<crate::lower::model::Do>), Nat)) -> Rc<dyn prism_rtl::Job<(Wx, crate::lower::Env, Array<crate::lower::model::Do>)>>>
            }))
        }
    }
}

/// ```prism
/// ?DynamicAnswer: fn Lx, Expr -> ?Expr
/// ```
pub fn dynamic_answer(lx: &crate::lower::Lx, x: &crate::syntax::Expr) -> Option<crate::syntax::Expr> {
    if &crate::lower::layer_of(&crate::lower::type_at(lx, &x.span)) != &crate::lower::Layer::LyDyn {
        None
    } else {
        match &*x.kind {
            crate::syntax::ExprKind::EFreeSigil(m62876_0_0, inner) if (m62876_0_0 == &Text::lit("$")) => if &crate::lower::layer_of(&crate::lower::type_at(lx, &inner.span)) == &crate::lower::Layer::LyDyn {
                Some((**inner).clone())
            } else {
                None
            },
            _ => Some(x.clone()),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// ```prism
/// DynKey: fn Expr -> Text
/// ```
pub fn dyn_key(x: &crate::syntax::Expr) -> Text {
    Text::from(format!("{}:{}", &x.span.start, &x.span.end))
}

/// ```prism
/// HostDocGetter: fn Text, Pos, [Place], [ForDef], [GenDef] -> MethDef
/// ```
pub fn host_doc_getter(name: &Text, pos: &crate::lower::model::Pos_, places: &Array<Place>, builders: &Array<crate::lower::model::ForDef>, gens: &Array<crate::lower::model::GenDef>) -> crate::lower::model::MethDef {
    let start = crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaMut(Text::lit("doc"))), crate::lower::model::OutTy::OutMap(Rc::new(crate::lower::model::OutTy::OutPath), Rc::new(crate::lower::elem_ty()))), crate::lower::model::Ex::XCall(Text::lit("Map::new"), Array::new()));
    let body = document_body(&{
        let f = Rc::new(map_insert);
        Rc::new(move |(a0, a1): (crate::lower::model::Ex, crate::lower::model::Ex)| {
            let f = f.clone();
            once_job(move || prism_rtl::Turn::Finished(f(&a0, &a1)))
        }) as Rc<dyn Fn((crate::lower::model::Ex, crate::lower::model::Ex)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Do>>>
    }, places, builders, gens);
    crate::lower::model::MethDef { name: name.clone(), recv: crate::lower::model::Recv::RecvRef, params: Array::new(), cx_: crate::lower::model::CxArg::CxRef, ret: crate::lower::model::OutTy::OutMap(Rc::new(crate::lower::model::OutTy::OutPath), Rc::new(crate::lower::elem_ty())), body: append(&Array::from(vec![start.clone()]), &body), tail: crate::lower::model::Ex::XVar(Text::lit("doc")), doc: Text::from(format!("The document of the child hosted at place {} computed live: each of its places by its path relative to the child, its level at the read point (pick HO). Read only by the snapshot `$doc` answers from (pick ST).", &crate::lower::model::place_text(pos))) }
}

/// ```prism
/// SnapGetter: fn Text, OutTy, Text -> MethDef
/// ```
pub fn snap_getter(name: &Text, t: &crate::lower::model::OutTy, doc: &Text) -> crate::lower::model::MethDef {
    crate::lower::model::MethDef { name: name.clone(), recv: crate::lower::model::Recv::RecvRef, params: Array::new(), cx_: crate::lower::model::CxArg::CxRef, ret: t.clone(), body: Array::new(), tail: crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_snap", name)))), Text::lit("get"), Array::from(vec![crate::lower::model::Ex::XCx])), doc: doc.clone() }
}

/// ```prism
/// StartedLine: fn Wx, ?Bn -> ((Wx, Wres))
/// ```
pub fn started_line(wx: &Wx, bound_opt: &Option<crate::lower::Bn>) -> (Wx, Wres) {
    let wx1 = {
        let mut this: Wx = wx.clone();
        this.pos = crate::lower::model::next_pos(&this.pos);
        this
    };
    let (id, wx2) = match bound_opt {
        Some(crate::lower::Bn::BnEv(er, _)) => (er.node_.clone(), wx1.clone()),
        _ => {
            let (nm, w) = fresh_name(&wx1, &Text::lit("started"));
            add_gn(&w, &nm, &crate::lower::model::OutTy::OutUnit, &GnKind::GnStarted, &Nat::from(0u32))
        },
    };
    let wx3 = {
        let mut this: Wx = wx2.clone();
        this.started = push(&this.started, &id);
        this
    };
    (wx3.clone(), Wres::WrEv(ev_ref_of(&wx3, &id)))
}

/// ```prism
/// DeferLine: unbounded fn Wx, Env, [Arg], Expr, ?Nat -> ((Wx, Wres))
/// ```
pub fn defer_line(wx: &Wx, menv: &crate::lower::Env, args: &Array<crate::syntax::Arg>, e: &crate::syntax::Expr, target_opt: &Option<Nat>) -> (Wx, Wres) {
    let lx = wx.lx.clone();
    let t = crate::lower::out_ty_of(&lx, &crate::lower::out_of(&crate::lower::type_at(&lx, &e.span)));
    let (field, wx1) = fresh_name(wx, &Text::lit("deferred"));
    let (id, wx2) = match target_opt {
        Some(n) => (n.clone(), wx1.clone()),
        None => add_gn(&wx1, &Text::from(format!("{}_fired", &field)), &t, &GnKind::GnDeferred, &Nat::from(0u32)),
    };
    let wx3 = add_field_last(&wx2, &field, &crate::lower::model::OutTy::OutDefer(Rc::new(t.clone())), &Text::lit("`@Defer`"), &crate::lower::model::Ex::XCall(Text::lit("Defer::new"), Array::new()));
    let wx4 = {
        let mut this: Wx = wx3.clone();
        this.defers = push(&this.defers, &(field.clone(), id.clone()));
        this
    };
    match index(args, &Nat::from(0u32)) {
        Some(a) => {
            let (r, wx5) = event_ref(&wx4, menv, &a.value);
            (connect(&wx5, &r, &Sk::SkArm(field.clone())), Wres::WrEv(ev_ref_of(&wx5, &id)))
        },
        None => (wx4.clone(), Wres::WrEv(ev_ref_of(&wx4, &id))),
    }
}

/// ```prism
/// RunLine: unbounded fn Wx, Env, [Arg], Expr, ?Nat -> ((Wx, Wres))
/// ```
pub fn run_line(wx: &Wx, benv: &crate::lower::Env, args: &Array<crate::syntax::Arg>, e: &crate::syntax::Expr, target_opt: &Option<Nat>) -> (Wx, Wres) {
    let lx = wx.lx.clone();
    let t = crate::lower::out_ty_of(&lx, &crate::lower::out_of(&crate::lower::type_at(&lx, &e.span)));
    let (p_, wx1) = fresh_name(wx, &Text::lit("run"));
    let wx2 = {
        let mut this: Wx = wx1.clone();
        this.pos = crate::lower::model::next_pos(&this.pos);
        this.taken = append(&this.taken, &Array::from(vec![Text::from(format!("{}_job", &p_)), Text::from(format!("{}_again", &p_)), Text::from(format!("{}_started", &p_)), Text::from(format!("{}_turn", &p_))]));
        this
    };
    let start = match index(args, &Nat::from(0u32)) {
        Some(a) => match &*a.value.kind {
            crate::syntax::ExprKind::EName(n) => {
                let (q_opt, _) = crate::check::env::resolve_value(&lx.g, &lx.home, n);
                crate::lower::model::Ex::XPath(crate::lower::start_path(&lx, &or(&q_opt, &Text::lit(""))))
            },
            _ => crate::lower::refusal(&Text::lit("an `@Run` of a function value that is not a name")),
        },
        None => crate::lower::refusal(&Text::lit("an `@Run` without its function")),
    };
    let x = match index(args, &Nat::from(1u32)) {
        Some(a) => crate::lower::own(&crate::lower::value_of(&lx, benv, &a.value)),
        None => crate::lower::model::Ex::XUnit,
    };
    let wx3 = add_field(&wx2, &Text::from(format!("{}_job", &p_)), &crate::lower::model::OutTy::OutHold(Rc::new(crate::lower::model::OutTy::OutJob(Rc::new(t.clone())))), &Text::lit("`@Run`'s job (`@Machine`'s state)"), &crate::lower::model::Ex::XCall(Text::lit("Hold::new"), Array::from(vec![crate::lower::model::Ex::XApply(Rc::new(start.clone()), Array::from(vec![x.clone()])), crate::lower::model::Ex::XCx])));
    let wx4 = add_field_last(&wx3, &Text::from(format!("{}_again", &p_)), &crate::lower::model::OutTy::OutDefer(Rc::new(crate::lower::model::OutTy::OutUnit)), &Text::lit("`@Run`'s `!again`"), &crate::lower::model::Ex::XCall(Text::lit("Defer::new"), Array::new()));
    let (s, wx5) = add_gn(&wx4, &Text::from(format!("{}_started", &p_)), &crate::lower::model::OutTy::OutUnit, &GnKind::GnStarted, &Nat::from(0u32));
    let (a, wx6) = add_gn(&wx5, &Text::from(format!("{}_again", &p_)), &crate::lower::model::OutTy::OutUnit, &GnKind::GnDeferred, &Nat::from(0u32));
    let (m, wx7) = merge(&wx6, &Text::from(format!("{}_turn", &p_)), &crate::lower::model::OutTy::OutUnit, &ev_ref_of(&wx6, &s), &ev_ref_of(&wx6, &a));
    let (res, wx8) = match target_opt {
        Some(n) => (n.clone(), wx7.clone()),
        None => add_gn(&wx7, &Text::from(format!("{}_done", &p_)), &t, &GnKind::GnNamed, &Nat::from(0u32)),
    };
    let wx9 = {
        let mut this: Wx = connect(&wx8, &ev_ref_of(&wx8, &m), &Sk::SkCycle(Text::from(format!("{}_job", &p_)), Text::from(format!("{}_again", &p_)), res.clone()));
        this.started = push(&this.started, &s);
        this.defers = push(&this.defers, &(Text::from(format!("{}_again", &p_)), a.clone()));
        this
    };
    (wx9.clone(), Wres::WrEv(ev_ref_of(&wx9, &res)))
}

/// ```prism
/// MachineLine: unbounded fn Wx, Env, Env, [Arg], Expr, ?Nat -> ((Wx, Wres))
/// ```
pub fn machine_line(wx: &Wx, benv: &crate::lower::Env, menv: &crate::lower::Env, args: &Array<crate::syntax::Arg>, e: &crate::syntax::Expr, target_opt: &Option<Nat>) -> (Wx, Wres) {
    let lx = wx.lx.clone();
    let t = crate::lower::out_ty_of(&lx, &crate::lower::out_of(&crate::lower::type_at(&lx, &e.span)));
    let (f, wx1) = fresh_name(wx, &Text::lit("machine"));
    let step_ = match index(args, &Nat::from(0u32)) {
        Some(a) => match &*a.value.kind {
            crate::syntax::ExprKind::EName(n) => {
                let (q_opt, _) = crate::check::env::resolve_value(&lx.g, &lx.home, n);
                match &q_opt {
                    Some(q) => crate::lower::value_path(&lx, q),
                    None => Text::lit(""),
                }
            },
            _ => Text::lit(""),
        },
        None => Text::lit(""),
    };
    match (step_.clone(), index(args, &Nat::from(1u32)), index(args, &Nat::from(2u32))) {
        (sp, Some(init), Some(ev)) if (&sp != &Text::lit("")) => {
            let st = crate::lower::out_ty_of(&lx, &crate::lower::peel(&crate::lower::type_at(&lx, &init.value.span)));
            let x = crate::lower::own(&crate::lower::value_of(&lx, benv, &init.value));
            let wx2 = add_field(&wx1, &Text::from(format!("{}_state", &f)), &crate::lower::model::OutTy::OutHold(Rc::new(st.clone())), &Text::lit("`@Machine`'s state"), &crate::lower::model::Ex::XCall(Text::lit("Hold::new"), Array::from(vec![x.clone(), crate::lower::model::Ex::XCx])));
            let (out, wx3) = match target_opt {
                Some(n) => (n.clone(), wx2.clone()),
                None => add_gn(&wx2, &Text::from(format!("{}_fired", &f)), &t, &GnKind::GnNamed, &Nat::from(0u32)),
            };
            let (r, wx4) = event_ref(&wx3, menv, &ev.value);
            (connect(&wx4, &r, &Sk::SkMachine(Text::from(format!("{}_state", &f)), sp.clone(), out.clone())), Wres::WrEv(ev_ref_of(&wx4, &out)))
        },
        _ => {
            let wx2 = {
                let mut this: Wx = wx1.clone();
                this.build = push(&this.build, &crate::lower::refusal_do(&Text::lit("an `@Machine` whose step is not a named function")));
                this
            };
            (wx2.clone(), Wres::WrUnit)
        },
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// InlineWidget: unbounded fn Wx, Env, Env, Text, ValInfo, [Arg], Expr -> ((Wx, Wres))
/// ```
pub fn inline_widget(wx: &Wx, benv: &crate::lower::Env, menv: &crate::lower::Env, qk: &Text, v_: &crate::check::env::ValInfo, args: &Array<crate::syntax::Arg>, e: &crate::syntax::Expr) -> (Wx, Wres) {
    let lx = wx.lx.clone();
    let clauses = crate::lower::clauses_of(&lx.g, qk);
    let w_opt = widget_decl_of(&lx.g, qk);
    let (params, body_opt) = match &w_opt {
        Some(wd) => (Array::new(), Some(wd.body.clone())),
        None => 'm69812: {
            if let m69812_0 = &clauses && (m69812_0.len() == 1) && let Some(c) = index(m69812_0, &Nat::from(0u32)) {
                break 'm69812 match &c.body {
                    crate::syntax::FnBody::BodyBlock(b) => (c.params.clone(), Some(b.clone())),
                    crate::syntax::FnBody::BodyExpr(x) => (c.params.clone(), Some(crate::syntax::Block { stmts: Array::from(vec![crate::syntax::Stmt { kind: crate::syntax::StmtKind::SExpr(x.clone()), span: x.span.clone() }]), inline: true, span: x.span.clone() })),
                };
            }
            (Array::new(), None)
        },
    };
    match &body_opt {
        None => if &len(&clauses) == &Nat::from(0u32) {
            {
                let wx2 = {
                    let mut this: Wx = wx.clone();
                    this.build = push(&this.build, &crate::lower::refusal_do(&Text::from(format!("the builtin widget {}", &crate::check::types::bare_name(qk)))));
                    this
                };
                (wx2.clone(), Wres::WrUnit)
            }
        } else {
            match index(args, &Nat::from(0u32)) {
                Some(a) => {
                    let call = crate::syntax::Block { stmts: Array::from(vec![crate::syntax::Stmt { kind: crate::syntax::StmtKind::SExpr(e.clone()), span: e.span.clone() }]), inline: true, span: e.span.clone() };
                    clause_widget_line(wx, menv, &a.value, &call, qk, v_, e)
                },
                None => {
                    let wx2 = {
                        let mut this: Wx = wx.clone();
                        this.build = push(&this.build, &crate::lower::refusal_do(&Text::lit("a widget of several clauses that takes no arguments")));
                        this
                    };
                    (wx2.clone(), Wres::WrUnit)
                },
            }
        },
        Some(body) => if &wx.depth > &Nat::from(16u32) {
            (wx.clone(), Wres::WrUnit)
        } else {
            {
                let lxc = crate::lower::in_module_at(&lx, &v_.file, &v_.home, &lx.site);
                let ptys = match &v_.scheme.ty {
                    crate::check::types::Ty::TyFn(_, ps, _) => ps.clone(),
                    _ => Array::new(),
                };
                let (wx1, be1, me1) = run_to_end(fold_job(crate::check::errors::range0(&len(&params)), (wx.clone(), crate::lower::empty_env(), crate::lower::empty_env()), {
                    let params = params.clone();
                    let lxc = lxc.clone();
                    let ptys = ptys.clone();
                    let args = args.clone();
                    let benv = benv.clone();
                    let menv = menv.clone();
                    Rc::new(move |(p0, p1): ((Wx, crate::lower::Env, crate::lower::Env), Nat)| {
                        let params = params.clone();
                        let lxc = lxc.clone();
                        let ptys = ptys.clone();
                        let args = args.clone();
                        let benv = benv.clone();
                        let menv = menv.clone();
                        entered(once_job(move || {
                            let (w, be, me) = p0;
                            let i = p1;
                            {
                                let p_ = or(&index(&params, &i), &crate::lower::dummy_pat());
                                let nkey = crate::lower::plain_binder(&lxc, &p_);
                                let pty = or(&index(&ptys, &i), &crate::check::types::Ty::TyErr);
                                match index(&args, &i) {
                                    None => prism_rtl::Turn::Finished((w.clone(), be.clone(), me.clone())),
                                    Some(a) => prism_rtl::Turn::Finished(bind_param(&w, &benv, &menv, &be, &me, &nkey, &pty, &a.value)),
                                }
                            }
                        }))
                    }) as Rc<dyn Fn(((Wx, crate::lower::Env, crate::lower::Env), Nat)) -> Rc<dyn prism_rtl::Job<(Wx, crate::lower::Env, crate::lower::Env)>>>
                }));
                let inner = {
                    let mut this: Wx = wx1.clone();
                    this.lx = lxc.clone();
                    this.depth = &this.depth + &Nat::from(1u32);
                    this.result = Wres::WrUnit;
                    this
                };
                let done = block_into(&inner, &be1, &me1, body);
                let back_ = {
                    let mut this: Wx = done.clone();
                    this.lx = lx.clone();
                    this.depth = wx.depth.clone();
                    this.result = wx.result.clone();
                    this
                };
                (back_.clone(), done.result.clone())
            }
        },
    }
}

/// ```prism
/// ?WidgetDeclOf: fn G, Text -> ?WidgetDecl
/// ```
pub fn widget_decl_of(g: &crate::check::env::G, qk: &Text) -> Option<crate::syntax::WidgetDecl> {
    fold(&g.defs, &None, &(|found_opt: &Option<crate::syntax::WidgetDecl>, d: &crate::check::env::Def| if &d.qk == qk { def_widget(d, found_opt) } else { found_opt.clone() }))
}

/// ```prism
/// ?DefWidget: fn Def, ?WidgetDecl -> ?WidgetDecl
/// ```
pub fn def_widget(d: &crate::check::env::Def, other_opt: &Option<crate::syntax::WidgetDecl>) -> Option<crate::syntax::WidgetDecl> {
    match &d.body {
        crate::check::env::DefBody::DbWidget(w) => Some(w.clone()),
        _ => other_opt.clone(),
    }
}

/// ```prism
/// BindParam: unbounded fn Wx, Env, Env, Env, Env, Text, Ty, Expr -> ((Wx, Env, Env))
/// ```
pub fn bind_param(wx: &Wx, cbenv: &crate::lower::Env, cmenv: &crate::lower::Env, be: &crate::lower::Env, me: &crate::lower::Env, nkey: &Text, pty: &crate::check::types::Ty, arg: &crate::syntax::Expr) -> (Wx, crate::lower::Env, crate::lower::Env) {
    let lx = wx.lx.clone();
    let t = crate::lower::out_ty_of(&lx, &crate::lower::peel(pty));
    match crate::lower::layer_of(pty) {
        crate::lower::Layer::LyBlueprint => {
            let b = crate::lower::Bn::BnWidget(arg.clone(), cbenv.clone(), cmenv.clone(), lx.clone());
            (wx.clone(), crate::lower::bind(be, nkey, &b), crate::lower::bind(me, nkey, &b))
        },
        crate::lower::Layer::LyEv => {
            let (r, wx2) = event_ref(wx, cmenv, arg);
            let b = crate::lower::Bn::BnEv(r.clone(), t.clone());
            (wx2.clone(), crate::lower::bind(be, nkey, &b), crate::lower::bind(me, nkey, &b))
        },
        crate::lower::Layer::LyDyn => {
            let (ex, reads) = dynamic_expr(wx, cmenv, arg);
            let b = crate::lower::Bn::BnDyn(ex.clone(), reads.clone(), t.clone());
            (wx.clone(), crate::lower::bind(be, nkey, &b), crate::lower::bind(me, nkey, &b))
        },
        _ => {
            let (rs, wx2) = fresh_name(wx, &crate::lower::snake(nkey));
            let v_ = crate::lower::own(&crate::lower::value_of(&lx, cbenv, arg));
            let wx3 = {
                let mut this: Wx = wx2.clone();
                this.lets = push(&this.lets, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(rs.clone()), v_.clone()));
                this.fields = push(&this.fields, &(rs.clone(), t.clone(), Text::from(format!("`{}`", nkey))));
                this.inits = push(&this.inits, &(rs.clone(), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(rs.clone())))));
                this
            };
            let (be2, me2) = bind_plain(be, me, nkey, &rs, &t);
            (wx3.clone(), be2.clone(), me2.clone())
        },
    }
}

/// ```prism
/// DynamicExpr: unbounded fn Wx, Env, Expr -> ((Ex, [Read]))
/// ```
pub fn dynamic_expr(wx: &Wx, menv: &crate::lower::Env, e: &crate::syntax::Expr) -> (crate::lower::model::Ex, Array<Read>) {
    let v_ = crate::lower::value_of(&wx.lx, menv, e);
    let reads = fold(&crate::check::typed::exprs_in(e), &Array::new(), &(|acc: &Array<Read>, x: &crate::syntax::Expr| match &*x.kind {
        crate::syntax::ExprKind::EName(n) => match get(&menv.names, &crate::check::env::sname_key(n)) {
            Some(crate::lower::Bn::BnHold(f, _)) => add_read(acc, &Read::OwnRead(f.clone())),
            Some(crate::lower::Bn::BnDyn(_, rs, _)) => union_reads(acc, &rs),
            _ => acc.clone(),
        },
        _ => acc.clone(),
    }));
    (crate::lower::own(&v_), reads.clone())
}

/// The step machine of `DynamicExpr`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// DynamicExpr: unbounded fn Wx, Env, Expr -> ((Ex, [Read]))
/// ```
pub struct DynamicExpr {
    pub wx: Wx,
    pub menv: crate::lower::Env,
    pub e: crate::syntax::Expr,
}

impl prism_rtl::Job<(crate::lower::model::Ex, Array<Read>)> for DynamicExpr {
    fn cycle(&self) -> prism_rtl::Turn<(crate::lower::model::Ex, Array<Read>)> {
        let wx = &self.wx;
        let menv = &self.menv;
        let e = &self.e;
        let e = e.clone();
        let menv = menv.clone();
        let wx = wx.clone();
        call_then(crate::lower::start_value_of(wx.lx.clone(), menv.clone(), e.clone()), move |value_of_74755: crate::lower::Vl| {
            let v_ = value_of_74755;
            call_then(crate::check::typed::start_exprs_in(e.clone()), move |exprs_in_74800: Array<crate::syntax::Expr>| {
                let reads = fold(&exprs_in_74800, &Array::new(), &(|acc: &Array<Read>, x: &crate::syntax::Expr| match &*x.kind {
                    crate::syntax::ExprKind::EName(n) => match get(&menv.names, &crate::check::env::sname_key(n)) {
                        Some(crate::lower::Bn::BnHold(f, _)) => add_read(acc, &Read::OwnRead(f.clone())),
                        Some(crate::lower::Bn::BnDyn(_, rs, _)) => union_reads(acc, &rs),
                        _ => acc.clone(),
                    },
                    _ => acc.clone(),
                }));
                prism_rtl::Turn::Finished((crate::lower::own(&v_), reads.clone()))
            })
        })
    }
}

/// `Start DynamicExpr, x`: what the function value is when passed to `@Run`.
pub fn start_dynamic_expr(wx: Wx, menv: crate::lower::Env, e: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<(crate::lower::model::Ex, Array<Read>)>> {
    Rc::new(DynamicExpr { wx, menv, e })
}

/// ```prism
/// NeverEvent: fn Wx, OutTy -> ((EvRef, Wx))
/// ```
pub fn never_event(wx: &Wx, t: &crate::lower::model::OutTy) -> (EvRef, Wx) {
    let (id, wx2) = add_gn(wx, &Text::lit("never"), t, &GnKind::GnNever, &Nat::from(0u32));
    (ev_ref_of(&wx2, &id), wx2.clone())
}

/// ```prism
/// EventRef: unbounded fn Wx, Env, Expr -> ((EvRef, Wx))
/// ```
pub fn event_ref(wx: &Wx, menv: &crate::lower::Env, e: &crate::syntax::Expr) -> (EvRef, Wx) {
    let lx = wx.lx.clone();
    let t = crate::lower::out_ty_of(&lx, &crate::lower::peel(&crate::lower::type_at(&lx, &e.span)));
    'm75664: {
        let scrutinee = &*e.kind;
        if let crate::syntax::ExprKind::EGroup(x) = scrutinee {
            break 'm75664 event_ref(wx, menv, &**x);
        }
        if let crate::syntax::ExprKind::EName(n) = scrutinee {
            break 'm75664 match get(&menv.names, &crate::check::env::sname_key(n)) {
                Some(crate::lower::Bn::BnEv(r, _)) => if &r.owner == &wx.node_ {
                    (r.clone(), wx.clone())
                } else {
                    never_event(&crossed(wx, &Text::from(format!("the event `{}`, of node `{}`,", &crate::check::env::sname_key(n), &r.owner))), &t)
                },
                _ => never_event(wx, &t),
            };
        }
        if let crate::syntax::ExprKind::EBinary(m75664_2_0, l, r) = scrutinee && (m75664_2_0 == &Text::lit("<|")) {
            break 'm75664 {
                let (lr, w1) = event_ref(wx, menv, &**l);
                let (rr, w2) = event_ref(&w1, menv, &**r);
                let (nm, w3) = fresh_name(&w2, &Text::lit("anon"));
                let (id, w4) = merge(&w3, &nm, &t, &lr, &rr);
                (ev_ref_of(&w4, &id), w4.clone())
            };
        }
        if let crate::syntax::ExprKind::EBinary(m75664_3_0, l, r) = scrutinee && (m75664_3_0 == &Text::lit("on")) {
            break 'm75664 {
                let (rr, w1) = event_ref(wx, menv, &**r);
                let value = crate::lower::own(&crate::lower::value_of(&lx, menv, &**l));
                (EvRef { node_: rr.node_.clone(), owner: rr.owner.clone(), pipe: {
                    let rr = rr.clone();
                    let value = value.clone();
                    Rc::new(move |(p0, p1): (crate::lower::model::Ex, Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>)| {
                        let rr = rr.clone();
                        let value = value.clone();
                        entered(once_job(move || {
                            let x = p0;
                            let k_fn = p1;
                            (&rr.pipe)((x.clone(), {
                                let k_fn = k_fn.clone();
                                let value = value.clone();
                                Rc::new(move |p0: crate::lower::model::Ex| {
                                    let k_fn = k_fn.clone();
                                    let value = value.clone();
                                    entered(once_job(move || {
                                        let _ = p0;
                                        (&k_fn)(value.clone()).cycle()
                                    }))
                                }) as Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>
                            })).cycle()
                        }))
                    }) as Rc<dyn Fn((crate::lower::model::Ex, Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>)) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>
                } }, w1.clone())
            };
        }
        if let crate::syntax::ExprKind::ECall(c, args, _, _) = scrutinee {
            break 'm75664 match callee_key(&lx, &**c) {
                m76520_0 if (&m76520_0 == &Text::lit("Prelude.!Filter")) => filter_event(wx, menv, args, &false),
                m76520_1 if (&m76520_1 == &Text::lit("Prelude.!Present")) => filter_event(wx, menv, args, &true),
                m76520_2 if (&m76520_2 == &Text::lit("Prelude.!Gate")) => gate_event(wx, menv, args),
                m76520_3 if (&m76520_3 == &Text::lit("Prelude.!Union")) => pair_event(wx, menv, args, &GnKind::GnUnion, &t),
                m76520_4 if (&m76520_4 == &Text::lit("Prelude.!Both")) => pair_event(wx, menv, args, &GnKind::GnBoth, &t),
                m76520_5 if (&m76520_5 == &Text::lit("Prelude.!Except")) => pair_event(wx, menv, args, &GnKind::GnExcept, &t),
                m76520_6 if (&m76520_6 == &Text::lit("Prelude.!MergeAll")) => merge_all_event(wx, menv, args, &t),
                m76520_7 if (&m76520_7 == &Text::lit("Prelude.!Updated")) => updated_event(wx, menv, args, &t),
                _ => event_map(wx, menv, e),
                _ => unreachable!("no arm matched"),
            };
        }
        if let crate::syntax::ExprKind::EIf(m75664_5_0, then_b, Some(else_b)) = scrutinee && let crate::syntax::Cond::CondExpr(c) = &**m75664_5_0 {
            break 'm75664 match (block_expr(then_b), block_expr(else_b)) {
                (Some(a), Some(b)) => event_if(wx, menv, &**c, &a, &b, &t),
                _ => event_map(wx, menv, e),
            };
        }
        event_map(wx, menv, e)
    }
}

/// The step machine of `EventRef`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// EventRef: unbounded fn Wx, Env, Expr -> ((EvRef, Wx))
/// ```
pub struct EventRef {
    pub wx: Wx,
    pub menv: crate::lower::Env,
    pub e: crate::syntax::Expr,
}

impl prism_rtl::Job<(EvRef, Wx)> for EventRef {
    fn cycle(&self) -> prism_rtl::Turn<(EvRef, Wx)> {
        let wx = &self.wx;
        let menv = &self.menv;
        let e = &self.e;
        let lx = wx.lx.clone();
        let e = e.clone();
        let menv = menv.clone();
        let wx = wx.clone();
        call_then(crate::lower::start_out_ty_of(lx.clone(), crate::lower::peel(&crate::lower::type_at(&lx, &e.span))), move |out_ty_of_75621: crate::lower::model::OutTy| {
            let t = out_ty_of_75621;
            'm75664: {
                let scrutinee = &*e.kind;
                if let crate::syntax::ExprKind::EGroup(x) = scrutinee {
                    break 'm75664 prism_rtl::Turn::More(Rc::new(EventRef { wx: wx.clone(), menv: menv.clone(), e: (**x).clone() }));
                }
                if let crate::syntax::ExprKind::EName(n) = scrutinee {
                    break 'm75664 match get(&menv.names, &crate::check::env::sname_key(n)) {
                        Some(crate::lower::Bn::BnEv(r, _)) => if &r.owner == &wx.node_ {
                            prism_rtl::Turn::Finished((r.clone(), wx.clone()))
                        } else {
                            prism_rtl::Turn::Finished(never_event(&crossed(&wx, &Text::from(format!("the event `{}`, of node `{}`,", &crate::check::env::sname_key(n), &r.owner))), &t))
                        },
                        _ => prism_rtl::Turn::Finished(never_event(&wx, &t)),
                    };
                }
                if let crate::syntax::ExprKind::EBinary(m75664_2_0, l, r) = scrutinee && (m75664_2_0 == &Text::lit("<|")) {
                    break 'm75664 {
                        let l = (**l).clone();
                        let r = (**r).clone();
                        call_then(start_event_ref(wx.clone(), menv.clone(), l.clone()), move |event_ref_76041: (EvRef, Wx)| {
                            let (lr, w1) = event_ref_76041;
                            call_then(start_event_ref(w1.clone(), menv.clone(), r.clone()), move |event_ref_76091: (EvRef, Wx)| {
                                let (rr, w2) = event_ref_76091;
                                let (nm, w3) = fresh_name(&w2, &Text::lit("anon"));
                                let (id, w4) = merge(&w3, &nm, &t, &lr, &rr);
                                prism_rtl::Turn::Finished((ev_ref_of(&w4, &id), w4.clone()))
                            })
                        })
                    };
                }
                if let crate::syntax::ExprKind::EBinary(m75664_3_0, l, r) = scrutinee && (m75664_3_0 == &Text::lit("on")) {
                    break 'm75664 {
                        let l = (**l).clone();
                        let r = (**r).clone();
                        call_then(start_event_ref(wx.clone(), menv.clone(), r.clone()), move |event_ref_76309: (EvRef, Wx)| {
                            let (rr, w1) = event_ref_76309;
                            call_then(crate::lower::start_value_of(lx.clone(), menv.clone(), l.clone()), move |value_of_76359: crate::lower::Vl| {
                                let value = crate::lower::own(&value_of_76359);
                                prism_rtl::Turn::Finished((EvRef { node_: rr.node_.clone(), owner: rr.owner.clone(), pipe: {
                                    let rr = rr.clone();
                                    let value = value.clone();
                                    Rc::new(move |(p0, p1): (crate::lower::model::Ex, Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>)| {
                                        let rr = rr.clone();
                                        let value = value.clone();
                                        entered(once_job(move || {
                                            let x = p0;
                                            let k_fn = p1;
                                            (&rr.pipe)((x.clone(), {
                                                let k_fn = k_fn.clone();
                                                let value = value.clone();
                                                Rc::new(move |p0: crate::lower::model::Ex| {
                                                    let k_fn = k_fn.clone();
                                                    let value = value.clone();
                                                    entered(once_job(move || {
                                                        let _ = p0;
                                                        (&k_fn)(value.clone()).cycle()
                                                    }))
                                                }) as Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>
                                            })).cycle()
                                        }))
                                    }) as Rc<dyn Fn((crate::lower::model::Ex, Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>)) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>
                                } }, w1.clone()))
                            })
                        })
                    };
                }
                if let crate::syntax::ExprKind::ECall(c, args, _, _) = scrutinee {
                    break 'm75664 match callee_key(&lx, &**c) {
                        m76520_0 if (&m76520_0 == &Text::lit("Prelude.!Filter")) => prism_rtl::Turn::Finished(filter_event(&wx, &menv, args, &false)),
                        m76520_1 if (&m76520_1 == &Text::lit("Prelude.!Present")) => prism_rtl::Turn::Finished(filter_event(&wx, &menv, args, &true)),
                        m76520_2 if (&m76520_2 == &Text::lit("Prelude.!Gate")) => prism_rtl::Turn::Finished(gate_event(&wx, &menv, args)),
                        m76520_3 if (&m76520_3 == &Text::lit("Prelude.!Union")) => prism_rtl::Turn::Finished(pair_event(&wx, &menv, args, &GnKind::GnUnion, &t)),
                        m76520_4 if (&m76520_4 == &Text::lit("Prelude.!Both")) => prism_rtl::Turn::Finished(pair_event(&wx, &menv, args, &GnKind::GnBoth, &t)),
                        m76520_5 if (&m76520_5 == &Text::lit("Prelude.!Except")) => prism_rtl::Turn::Finished(pair_event(&wx, &menv, args, &GnKind::GnExcept, &t)),
                        m76520_6 if (&m76520_6 == &Text::lit("Prelude.!MergeAll")) => prism_rtl::Turn::Finished(merge_all_event(&wx, &menv, args, &t)),
                        m76520_7 if (&m76520_7 == &Text::lit("Prelude.!Updated")) => prism_rtl::Turn::Finished(updated_event(&wx, &menv, args, &t)),
                        _ => prism_rtl::Turn::Finished(event_map(&wx, &menv, &e)),
                        _ => unreachable!("no arm matched"),
                    };
                }
                if let crate::syntax::ExprKind::EIf(m75664_5_0, then_b, Some(else_b)) = scrutinee && let crate::syntax::Cond::CondExpr(c) = &**m75664_5_0 {
                    break 'm75664 match (block_expr(then_b), block_expr(else_b)) {
                        (Some(a), Some(b)) => prism_rtl::Turn::Finished(event_if(&wx, &menv, &**c, &a, &b, &t)),
                        _ => prism_rtl::Turn::Finished(event_map(&wx, &menv, &e)),
                    };
                }
                prism_rtl::Turn::Finished(event_map(&wx, &menv, &e))
            }
        })
    }
}

/// `Start EventRef, x`: what the function value is when passed to `@Run`.
pub fn start_event_ref(wx: Wx, menv: crate::lower::Env, e: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<(EvRef, Wx)>> {
    Rc::new(EventRef { wx, menv, e })
}

/// ```prism
/// EventIf: unbounded fn Wx, Env, Expr, Expr, Expr, OutTy -> ((EvRef, Wx))
/// ```
pub fn event_if(wx: &Wx, menv: &crate::lower::Env, c: &crate::syntax::Expr, a: &crate::syntax::Expr, b: &crate::syntax::Expr, t: &crate::lower::model::OutTy) -> (EvRef, Wx) {
    let cond = crate::lower::as_bool(&crate::lower::value_of(&wx.lx, menv, c));
    let (ra, w1) = event_ref(wx, menv, a);
    let (rb, w2) = event_ref(&w1, menv, b);
    let ga = EvRef { node_: ra.node_.clone(), owner: ra.owner.clone(), pipe: {
        let ra = ra.clone();
        let cond = cond.clone();
        Rc::new(move |(p0, p1): (crate::lower::model::Ex, Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>)| {
            let ra = ra.clone();
            let cond = cond.clone();
            entered(once_job(move || {
                let x = p0;
                let k_fn = p1;
                (&ra.pipe)((x.clone(), {
                    let cond = cond.clone();
                    let k_fn = k_fn.clone();
                    Rc::new(move |p0: crate::lower::model::Ex| {
                        let cond = cond.clone();
                        let k_fn = k_fn.clone();
                        entered(once_job(move || {
                            let y = p0;
                            call_value((&k_fn)(y.clone()), move |k_77798: Array<crate::lower::model::Do>| prism_rtl::Turn::Finished(Array::from(vec![crate::lower::model::Do::DoIf(cond.clone(), k_77798, Array::new())])))
                        }))
                    }) as Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>
                })).cycle()
            }))
        }) as Rc<dyn Fn((crate::lower::model::Ex, Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>)) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>
    } };
    let gb = EvRef { node_: rb.node_.clone(), owner: rb.owner.clone(), pipe: {
        let rb = rb.clone();
        let cond = cond.clone();
        Rc::new(move |(p0, p1): (crate::lower::model::Ex, Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>)| {
            let rb = rb.clone();
            let cond = cond.clone();
            entered(once_job(move || {
                let x = p0;
                let k_fn = p1;
                (&rb.pipe)((x.clone(), {
                    let cond = cond.clone();
                    let k_fn = k_fn.clone();
                    Rc::new(move |p0: crate::lower::model::Ex| {
                        let cond = cond.clone();
                        let k_fn = k_fn.clone();
                        entered(once_job(move || {
                            let y = p0;
                            call_value((&k_fn)(y.clone()), move |k_77936: Array<crate::lower::model::Do>| prism_rtl::Turn::Finished(Array::from(vec![crate::lower::model::Do::DoIf(crate::lower::model::Ex::XBin(Text::lit("=="), Rc::new(cond.clone()), Rc::new(crate::lower::model::Ex::XBool(false))), k_77936, Array::new())])))
                        }))
                    }) as Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>
                })).cycle()
            }))
        }) as Rc<dyn Fn((crate::lower::model::Ex, Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>)) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>
    } };
    let (nm, w3) = fresh_name(&w2, &Text::lit("chosen"));
    let (id, w4) = merge(&w3, &nm, t, &ga, &gb);
    (ev_ref_of(&w4, &id), w4.clone())
}

/// ```prism
/// ?BlockExpr: fn Block -> ?Expr
/// ```
pub fn block_expr(b: &crate::syntax::Block) -> Option<crate::syntax::Expr> {
    'm78170: {
        let scrutinee = &b.stmts;
        if let m78170_0 = scrutinee && (m78170_0.len() == 1) && let Some(st) = index(m78170_0, &Nat::from(0u32)) {
            break 'm78170 match &st.kind {
                crate::syntax::StmtKind::SExpr(x) => Some(x.clone()),
                _ => None,
            };
        }
        None
    }
}

/// ```prism
/// CalleeKey: fn Lx, Expr -> Text
/// ```
pub fn callee_key(lx: &crate::lower::Lx, c: &crate::syntax::Expr) -> Text {
    match &*c.kind {
        crate::syntax::ExprKind::EName(n) => {
            let (q_opt, _) = crate::check::env::resolve_value(&lx.g, &lx.home, n);
            or(&q_opt, &Text::lit(""))
        },
        _ => Text::lit(""),
    }
}

/// ```prism
/// PairEvent: unbounded fn Wx, Env, [Arg], GnKind, OutTy -> ((EvRef, Wx))
/// ```
pub fn pair_event(wx: &Wx, menv: &crate::lower::Env, args: &Array<crate::syntax::Arg>, kind: &GnKind, t: &crate::lower::model::OutTy) -> (EvRef, Wx) {
    match (index(args, &Nat::from(0u32)), index(args, &Nat::from(1u32))) {
        (Some(a), Some(b)) => {
            let (ra, w1) = event_ref(wx, menv, &a.value);
            let (rb, w2) = event_ref(&w1, menv, &b.value);
            let lt = crate::lower::out_ty_of(&wx.lx, &crate::lower::peel(&crate::lower::type_at(&wx.lx, &a.value.span)));
            let rt = crate::lower::out_ty_of(&wx.lx, &crate::lower::peel(&crate::lower::type_at(&wx.lx, &b.value.span)));
            let (nm, w3) = fresh_name(&w2, &kind_word(kind));
            let (id, w4) = combinator(&w3, &nm, t, kind, &ra, &rb, &lt, &rt);
            (ev_ref_of(&w4, &id), w4.clone())
        },
        _ => never_event(wx, t),
    }
}

/// ```prism
/// MergeAllEvent: unbounded fn Wx, Env, [Arg], OutTy -> ((EvRef, Wx))
/// ```
pub fn merge_all_event(wx: &Wx, menv: &crate::lower::Env, args: &Array<crate::syntax::Arg>, t: &crate::lower::model::OutTy) -> (EvRef, Wx) {
    match index(args, &Nat::from(0u32)) {
        Some(a) => match &*a.value.kind {
            crate::syntax::ExprKind::EArray(es) => {
                let et = match t {
                    crate::lower::model::OutTy::OutArray(x) => (**x).clone(),
                    _ => crate::lower::model::OutTy::OutUnit,
                };
                let (nm, w1) = fresh_name(wx, &Text::lit("merged"));
                let (id, w2) = add_gn(&w1, &nm, t, &GnKind::GnMergeAll, &Nat::from(1u32));
                let ins = each(&crate::check::errors::range0(&len(es)), &(|i: &Nat| Text::from(format!("{}_{}", &nm, i))));
                let w3 = fold(&ins, &w2, &(|w: &Wx, f: &Text| add_field_last(w, f, &crate::lower::model::OutTy::OutStamped(Rc::new(et.clone())), &Text::lit("an input of `!MergeAll`"), &crate::lower::model::Ex::XCall(Text::lit("Stamped::new"), Array::new()))));
                let w4 = {
                    let mut this: Wx = w3.clone();
                    this.gns = each(&this.gns, &(|n: &Gn| if &n.id == &id { with_inputs(n, &ins) } else { n.clone() }));
                    this
                };
                let w5 = run_to_end(fold_job(crate::check::errors::range0(&len(es)), w4.clone(), {
                    let menv = menv.clone();
                    let es = es.clone();
                    let a = a.clone();
                    let id = id.clone();
                    Rc::new(move |(p0, p1): (Wx, Nat)| {
                        let menv = menv.clone();
                        let es = es.clone();
                        let a = a.clone();
                        let id = id.clone();
                        entered(once_job(move || {
                            let w = p0;
                            let i = p1;
                            call_then(start_event_ref(w.clone(), menv.clone(), or(&index(&es, &i), &a.value)), move |event_ref_80104: (EvRef, Wx)| {
                                let (r, w6) = event_ref_80104;
                                prism_rtl::Turn::Finished(connect(&w6, &r, &Sk::SkIn(id.clone(), i.clone())))
                            })
                        }))
                    }) as Rc<dyn Fn((Wx, Nat)) -> Rc<dyn prism_rtl::Job<Wx>>>
                }));
                (ev_ref_of(&w5, &id), w5.clone())
            },
            _ => {
                let (r, w1) = never_event(wx, t);
                let w2 = {
                    let mut this: Wx = w1.clone();
                    this.build = push(&this.build, &crate::lower::refusal_do(&Text::lit("`!MergeAll` of a list that is not a literal")));
                    this
                };
                (r.clone(), w2.clone())
            },
        },
        None => never_event(wx, t),
    }
}

/// ```prism
/// UpdatedEvent: unbounded fn Wx, Env, [Arg], OutTy -> ((EvRef, Wx))
/// ```
pub fn updated_event(wx: &Wx, menv: &crate::lower::Env, args: &Array<crate::syntax::Arg>, t: &crate::lower::model::OutTy) -> (EvRef, Wx) {
    match index(args, &Nat::from(0u32)) {
        Some(a) => {
            let (ex, reads) = dynamic_expr(wx, menv, &a.value);
            let (nm, w1) = fresh_name(wx, &Text::lit("updated"));
            let (id, w2) = add_gn(&w1, &nm, t, &GnKind::GnUpdated, &Nat::from(1u32));
            let w3 = add_field_last(&w2, &Text::from(format!("{}_moved", &nm)), &crate::lower::model::OutTy::OutNamed(Text::lit("Cell"), Array::from(vec![crate::lower::model::OutTy::OutBool])), &Text::from(format!("a hold `!{}`'s dynamic reads was written this tick", &nm)), &crate::lower::model::Ex::XCall(Text::lit("Cell::new"), Array::from(vec![crate::lower::model::Ex::XBool(false)])));
            let w4 = {
                let mut this: Wx = w3.clone();
                this.gns = each(&this.gns, &(|n: &Gn| if &n.id == &id { with_reads(n, &reads) } else { n.clone() }));
                this.getters = push(&this.getters, &crate::lower::model::MethDef { name: Text::from(format!("{}_value", &nm)), recv: crate::lower::model::Recv::RecvRef, params: Array::new(), cx_: crate::lower::model::CxArg::CxRef, ret: t.clone(), body: Array::new(), tail: ex.clone(), doc: Text::from(format!("The dynamic `!{}` is the event half of, which the wake reads after the tick.", &nm)) });
                this
            };
            (ev_ref_of(&w4, &id), w4.clone())
        },
        None => never_event(wx, t),
    }
}

/// ```prism
/// FilterEvent: unbounded fn Wx, Env, [Arg], Bool -> ((EvRef, Wx))
/// ```
pub fn filter_event(wx: &Wx, menv: &crate::lower::Env, args: &Array<crate::syntax::Arg>, is_unit: &bool) -> (EvRef, Wx) {
    match index(args, &Nat::from(0u32)) {
        None => never_event(wx, &crate::lower::model::OutTy::OutUnit),
        Some(a) => {
            let (r, w1) = event_ref(wx, menv, &a.value);
            let bound = if *is_unit {
                crate::lower::model::Pa::PaWild
            } else {
                crate::lower::model::Pa::PaBind(Text::lit("w"))
            };
            let pipe = {
                let r = r.clone();
                let bound = bound.clone();
                let is_unit = *is_unit;
                Rc::new(move |(p0, p1): (crate::lower::model::Ex, Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>)| {
                    let r = r.clone();
                    let bound = bound.clone();
                    let is_unit = is_unit;
                    entered(once_job(move || {
                        let x = p0;
                        let k_fn = p1;
                        (&r.pipe)((x.clone(), {
                            let bound = bound.clone();
                            let k_fn = k_fn.clone();
                            let is_unit = is_unit;
                            Rc::new(move |p0: crate::lower::model::Ex| {
                                let bound = bound.clone();
                                let k_fn = k_fn.clone();
                                let is_unit = is_unit;
                                entered(once_job(move || {
                                    let y = p0;
                                    call_value((&k_fn)(if is_unit {
                                        crate::lower::model::Ex::XUnit
                                    } else {
                                        crate::lower::model::Ex::XVar(Text::lit("w"))
                                    }), move |k_82466: Array<crate::lower::model::Do>| prism_rtl::Turn::Finished(Array::from(vec![crate::lower::model::Do::DoIfLet(crate::lower::model::Pa::PaCtor(Text::lit("Some"), Array::from(vec![bound.clone()])), y.clone(), k_82466, Array::new())])))
                                }))
                            }) as Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>
                        })).cycle()
                    }))
                }) as Rc<dyn Fn((crate::lower::model::Ex, Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>)) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>
            };
            (EvRef { node_: r.node_.clone(), owner: r.owner.clone(), pipe: pipe.clone() }, w1.clone())
        },
    }
}

/// ```prism
/// GateEvent: unbounded fn Wx, Env, [Arg] -> ((EvRef, Wx))
/// ```
pub fn gate_event(wx: &Wx, menv: &crate::lower::Env, args: &Array<crate::syntax::Arg>) -> (EvRef, Wx) {
    match index(args, &Nat::from(1u32)) {
        None => never_event(wx, &crate::lower::model::OutTy::OutUnit),
        Some(a) => {
            let (r, w1) = event_ref(wx, menv, &a.value);
            let cond = match index(args, &Nat::from(0u32)) {
                Some(b) => crate::lower::as_bool(&crate::lower::value_of(&wx.lx, menv, &b.value)),
                None => crate::lower::model::Ex::XBool(false),
            };
            let pipe = {
                let r = r.clone();
                let cond = cond.clone();
                Rc::new(move |(p0, p1): (crate::lower::model::Ex, Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>)| {
                    let r = r.clone();
                    let cond = cond.clone();
                    entered(once_job(move || {
                        let x = p0;
                        let k_fn = p1;
                        (&r.pipe)((x.clone(), {
                            let cond = cond.clone();
                            let k_fn = k_fn.clone();
                            Rc::new(move |p0: crate::lower::model::Ex| {
                                let cond = cond.clone();
                                let k_fn = k_fn.clone();
                                entered(once_job(move || {
                                    let y = p0;
                                    call_value((&k_fn)(y.clone()), move |k_82999: Array<crate::lower::model::Do>| prism_rtl::Turn::Finished(Array::from(vec![crate::lower::model::Do::DoIf(cond.clone(), k_82999, Array::new())])))
                                }))
                            }) as Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>
                        })).cycle()
                    }))
                }) as Rc<dyn Fn((crate::lower::model::Ex, Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>)) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>
            };
            (EvRef { node_: r.node_.clone(), owner: r.owner.clone(), pipe: pipe.clone() }, w1.clone())
        },
    }
}

/// ```prism
/// EventMap: unbounded fn Wx, Env, Expr -> ((EvRef, Wx))
/// ```
pub fn event_map(wx: &Wx, menv: &crate::lower::Env, e: &crate::syntax::Expr) -> (EvRef, Wx) {
    let lx = wx.lx.clone();
    let t = crate::lower::out_ty_of(&lx, &crate::lower::peel(&crate::lower::type_at(&lx, &e.span)));
    let evs = filter(&operands(e), &(|x: &crate::syntax::Expr| &crate::lower::layer_of(&crate::lower::type_at(&lx, &x.span)) == &crate::lower::Layer::LyEv));
    'm83481: {
        if let m83481_0 = &evs && (m83481_0.len() == 1) && let Some(one) = index(m83481_0, &Nat::from(0u32)) {
            break 'm83481 {
                let (r, w1) = event_ref(wx, menv, &one);
                let et = crate::lower::out_ty_of(&lx, &crate::lower::peel(&crate::lower::type_at(&lx, &one.span)));
                let k = crate::lower::place_key(&lx, &one.span);
                let pipe = {
                    let r = r.clone();
                    let lx = lx.clone();
                    let menv = menv.clone();
                    let k = k.clone();
                    let et = et.clone();
                    let e = e.clone();
                    Rc::new(move |(p0, p1): (crate::lower::model::Ex, Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>)| {
                        let r = r.clone();
                        let lx = lx.clone();
                        let menv = menv.clone();
                        let k = k.clone();
                        let et = et.clone();
                        let e = e.clone();
                        entered(once_job(move || {
                            let x = p0;
                            let k_fn = p1;
                            (&r.pipe)((x.clone(), {
                                let k_fn = k_fn.clone();
                                let lx = lx.clone();
                                let menv = menv.clone();
                                let k = k.clone();
                                let et = et.clone();
                                let e = e.clone();
                                Rc::new(move |p0: crate::lower::model::Ex| {
                                    let k_fn = k_fn.clone();
                                    let lx = lx.clone();
                                    let menv = menv.clone();
                                    let k = k.clone();
                                    let et = et.clone();
                                    let e = e.clone();
                                    entered(once_job(move || {
                                        let y = p0;
                                        call_then(crate::lower::start_value_of(lx.clone(), crate::lower::bind_span(&menv, &k, &firing_value(&y, &et)), e.clone()), move |value_of_83718: crate::lower::Vl| (&k_fn)(crate::lower::own(&value_of_83718)).cycle())
                                    }))
                                }) as Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>
                            })).cycle()
                        }))
                    }) as Rc<dyn Fn((crate::lower::model::Ex, Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>)) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>
                };
                (EvRef { node_: r.node_.clone(), owner: r.owner.clone(), pipe: pipe.clone() }, w1.clone())
            };
        }
        never_event(wx, &t)
    }
}

/// ```prism
/// FiringValue: fn Ex, OutTy -> Vl
/// ```
pub fn firing_value(ex0: &crate::lower::model::Ex, t: &crate::lower::model::OutTy) -> crate::lower::Vl {
    match ex0 {
        crate::lower::model::Ex::XVar(n) => crate::lower::Vl::VlPlace(crate::lower::model::Ex::XVar(n.clone()), crate::lower::Holding::Owned, t.clone()),
        crate::lower::model::Ex::XUnit => crate::lower::Vl::VlPlace(crate::lower::model::Ex::XUnit, crate::lower::Holding::Owned, t.clone()),
        x => crate::lower::Vl::VlOwned(x.clone(), t.clone()),
    }
}

/// ```prism
/// Operands: fn Expr -> [Expr]
/// ```
pub fn operands(e: &crate::syntax::Expr) -> Array<crate::syntax::Expr> {
    match &*e.kind {
        crate::syntax::ExprKind::ECall(c, args, _, _) => append(&Array::from(vec![(**c).clone()]), &each(args, &(|a: &crate::syntax::Arg| a.value.clone()))),
        crate::syntax::ExprKind::EMethod(r, _, args) => append(&Array::from(vec![(**r).clone()]), &each(args, &(|a: &crate::syntax::Arg| a.value.clone()))),
        crate::syntax::ExprKind::EBinary(_, l, r) => Array::from(vec![(**l).clone(), (**r).clone()]),
        crate::syntax::ExprKind::EUnary(_, x) => Array::from(vec![(**x).clone()]),
        crate::syntax::ExprKind::EFreeSigil(_, x) => Array::from(vec![(**x).clone()]),
        crate::syntax::ExprKind::EGroup(x) => Array::from(vec![(**x).clone()]),
        crate::syntax::ExprKind::EField(r, _, _) => Array::from(vec![(**r).clone()]),
        crate::syntax::ExprKind::EIndex(r, i) => Array::from(vec![(**r).clone(), (**i).clone()]),
        crate::syntax::ExprKind::ETuple(es) => es.clone(),
        crate::syntax::ExprKind::EArray(es) => es.clone(),
        crate::syntax::ExprKind::EMap(kvs) => fold(kvs, &Array::new(), &(|acc: &Array<crate::syntax::Expr>, (k, v_): &(crate::syntax::Expr, crate::syntax::Expr)| append(acc, &Array::from(vec![k.clone(), v_.clone()])))),
        crate::syntax::ExprKind::ELit(l) => match &l.kind {
            crate::syntax::LitKind::LText(segs) => fold(segs, &Array::new(), &(|acc: &Array<crate::syntax::Expr>, sg: &crate::syntax::TextSeg| match sg {
                crate::syntax::TextSeg::SegPlaceholder(x) => push(acc, x),
                _ => acc.clone(),
            })),
            _ => Array::new(),
        },
        _ => Array::new(),
    }
}

/// ```prism
/// Merge: fn Wx, Text, OutTy, EvRef, EvRef -> ((Nat, Wx))
/// ```
pub fn merge(wx: &Wx, name: &Text, t: &crate::lower::model::OutTy, l: &EvRef, r: &EvRef) -> (Nat, Wx) {
    combinator(wx, name, t, &GnKind::GnMerge, l, r, t, t)
}

/// ```prism
/// Combinator: fn Wx, Text, OutTy, GnKind, EvRef, EvRef, OutTy, OutTy -> ((Nat, Wx))
/// ```
pub fn combinator(wx: &Wx, name: &Text, t: &crate::lower::model::OutTy, kind: &GnKind, l: &EvRef, r: &EvRef, lt: &crate::lower::model::OutTy, rt: &crate::lower::model::OutTy) -> (Nat, Wx) {
    let (id, wx1) = add_gn(wx, name, t, kind, &Nat::from(1u32));
    let wx2 = add_field_last(&wx1, &Text::from(format!("{}_left", name)), &crate::lower::model::OutTy::OutStamped(Rc::new(lt.clone())), &Text::from(format!("`{}`'s left input", name)), &crate::lower::model::Ex::XCall(Text::lit("Stamped::new"), Array::new()));
    let wx3 = add_field_last(&wx2, &Text::from(format!("{}_right", name)), &crate::lower::model::OutTy::OutStamped(Rc::new(rt.clone())), &Text::lit("its right input"), &crate::lower::model::Ex::XCall(Text::lit("Stamped::new"), Array::new()));
    let wx4 = {
        let mut this: Wx = wx3.clone();
        this.gns = each(&this.gns, &(|n: &Gn| if &n.id == &id {
            with_inputs(n, &Array::from(vec![Text::from(format!("{}_left", name)), Text::from(format!("{}_right", name))]))
        } else {
            n.clone()
        }));
        this
    };
    (id.clone(), connect(&connect(&wx4, l, &Sk::SkIn(id.clone(), Nat::from(0u32))), r, &Sk::SkIn(id.clone(), Nat::from(1u32))))
}

/// ```prism
/// WithInputs: fn Gn, [Text] -> Gn
/// ```
pub fn with_inputs(n: &Gn, ins: &Array<Text>) -> Gn {
    let mut this: Gn = n.clone();
    this.inputs = ins.clone();
    this
}

/// ```prism
/// WithReads: fn Gn, [Read] -> Gn
/// ```
pub fn with_reads(n: &Gn, reads: &Array<Read>) -> Gn {
    let mut this: Gn = n.clone();
    this.reads = reads.clone();
    this
}

/// ```prism
/// Heights: fn [Gn] -> [Gn]
/// ```
pub fn heights(gns: &Array<Gn>) -> Array<Gn> {
    fold(gns, gns, &(|cur: &Array<Gn>, _: &Gn| each(cur, &(|n: &Gn| height_step(cur, n)))))
}

/// ```prism
/// HeightStep: fn [Gn], Gn -> Gn
/// ```
pub fn height_step(gns: &Array<Gn>, n: &Gn) -> Gn {
    let feeders = filter(gns, &(|m: &Gn| fold(&m.outs, &false, &(|f: &bool, o: &Out| *f || feeds(&o.sink, n)))));
    let top = fold(&feeders, &Nat::from(0u32), &(|hi: &Nat, m: &Gn| max(hi, &m.height)));
    let h = match &n.kind {
        GnKind::GnNamed => top.clone(),
        kind => if is_comb(kind) {
            max(&(&top + &Nat::from(1u32)), &n.floor)
        } else {
            n.height.clone()
        },
    };
    let mut this: Gn = n.clone();
    this.height = h.clone();
    this
}

/// ```prism
/// IsComb: fn GnKind -> Bool
/// ```
pub fn is_comb(k: &GnKind) -> bool {
    match k {
        GnKind::GnMerge => true,
        GnKind::GnUnion => true,
        GnKind::GnBoth => true,
        GnKind::GnExcept => true,
        GnKind::GnMergeAll => true,
        GnKind::GnUpdated => true,
        _ => false,
    }
}

/// ```prism
/// Feeds: fn Sk, Gn -> Bool
/// ```
pub fn feeds(sk0: &Sk, n: &Gn) -> bool {
    match sk0 {
        Sk::SkNode(m) => m == &n.id,
        Sk::SkIn(m, _) => m == &n.id,
        Sk::SkCycle(_, _, m) => m == &n.id,
        Sk::SkMachine(f, _, m) => (m == &n.id) || writes(f, n),
        Sk::SkHold(f) => writes(f, n),
        other => false,
    }
}

/// ```prism
/// Writes: fn Text, Gn -> Bool
/// ```
pub fn writes(f: &Text, n: &Gn) -> bool {
    moves(&Read::OwnRead(f.clone()), n)
}

/// ```prism
/// Moves: fn Read, Gn -> Bool
/// ```
pub fn moves(r: &Read, n: &Gn) -> bool {
    (&n.kind == &GnKind::GnUpdated) && has_read(&n.reads, r)
}

/// ```prism
/// ReadsClosed: fn (Text ==> [Read]), [Read] -> [Read]
/// ```
pub fn reads_closed(dyn_: &Map<Text, Array<Read>>, reads: &Array<Read>) -> Array<Read> {
    fold(&crate::check::errors::range0(&Nat::from(4u32)), reads, &(|acc: &Array<Read>, _: &Nat| fold(acc, acc, &(|a: &Array<Read>, r: &Read| union_reads(a, &getter_reads(dyn_, r))))))
}

/// ```prism
/// GetterReads: fn (Text ==> [Read]), Read -> [Read]
/// ```
pub fn getter_reads(dyn_: &Map<Text, Array<Read>>, read1: &Read) -> Array<Read> {
    match read1 {
        Read::OwnRead(n) => or(&get(dyn_, n), &Array::new()),
        Read::ParentRead(_) => Array::new(),
    }
}

/// ```prism
/// ReachesSnap: fn [Text], [Read] -> Bool
/// ```
pub fn reaches_snap(roots: &Array<Text>, reads: &Array<Read>) -> bool {
    fold(reads, &false, &(|f: &bool, r: &Read| *f || match r {
        Read::OwnRead(n) => crate::check::types::has_text(roots, n),
        Read::ParentRead(_) => false,
    }))
}

/// ```prism
/// SnapNames: fn Wx -> [Text]
/// ```
pub fn snap_names(wx: &Wx) -> Array<Text> {
    each(&wx.snaps, &(|sn: &SnapDef| sn.name.clone()))
}

/// ```prism
/// WakeConst: fn [Nat], Nat -> Text
/// ```
pub fn wake_const(heights_: &Array<Nat>, h: &Nat) -> Text {
    if &len(heights_) <= &Nat::from(1u32) {
        Text::lit("WAKE")
    } else {
        Text::from(format!("WAKE_{}", h))
    }
}

/// ```prism
/// SelfCall: fn Text, [Ex] -> Do
/// ```
pub fn self_call(m: &Text, args: &Array<crate::lower::model::Ex>) -> crate::lower::model::Do {
    crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XSelf), m.clone(), push(args, &crate::lower::model::Ex::XCx)))
}

/// ```prism
/// SinkCode: fn Sinks, Sk, Ex -> [Do]
/// ```
pub fn sink_code(sk: &Sinks, target: &Sk, y: &crate::lower::model::Ex) -> Array<crate::lower::model::Do> {
    match target {
        Sk::SkNode(m) => Array::from(vec![self_call(&gn_of(&sk.wx, m).name, &Array::from(vec![y.clone()]))]),
        Sk::SkIn(m, i) => {
            let g = gn_of(&sk.wx, m);
            append(&Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", &or(&index(&g.inputs, i), &Text::lit("")))))), Text::lit("set"), Array::from(vec![y.clone(), crate::lower::model::Ex::XCx])))]), &ask_wake(sk, &g.height))
        },
        Sk::SkHold(f) => append(&Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", f)))), Text::lit("set"), Array::from(vec![y.clone(), crate::lower::model::Ex::XCx])))]), &hold_written(sk, f)),
        Sk::SkRequest(pos, field) => {
            let field_ex = if field == &Text::lit("") {
                crate::lower::model::Ex::XNone
            } else {
                crate::lower::model::Ex::XCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Ex::XStr(field.clone())]))
            };
            if emits(&sk.wx, pos) {
                Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCx), Text::lit("request"), Array::from(vec![place_at(&sk.wx, &Text::lit("self"), pos), field_ex.clone(), crate::lower::model::Ex::XMethod(Rc::new(y.clone()), Text::lit("to_pod"), Array::new())])))])
            } else {
                Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(Text::lit("requested")), crate::lower::model::Ex::XMethod(Rc::new(host_field_ex(&sk.wx, pos)), Text::lit("request"), Array::from(vec![crate::lower::model::Ex::XRef(Rc::new(place_at(&sk.wx, &Text::lit("self"), pos))), field_ex.clone(), crate::lower::model::Ex::XMethod(Rc::new(y.clone()), Text::lit("to_pod"), Array::new()), crate::lower::model::Ex::XCx]))), crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCx), Text::lit("keep"), Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("requested"))])))])
            }
        },
        Sk::SkResult => Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCx), Text::lit("result"), Array::from(vec![crate::lower::model::Ex::XCtor(Text::lit("Outcome::Fired"), Array::from(vec![crate::lower::model::Ex::XMethod(Rc::new(y.clone()), Text::lit("to_pod"), Array::new())]))])))]),
        Sk::SkArm(f) => Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", f)))), Text::lit("arm"), Array::from(vec![y.clone(), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XSelf)), crate::lower::model::Ex::XCx])))]),
        Sk::SkMachine(f, step_, out) => {
            let stepped = crate::lower::model::Ex::XCall(step_.clone(), Array::from(vec![crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), f.clone())), Text::lit("get"), Array::from(vec![crate::lower::model::Ex::XCx])))), crate::lower::model::Ex::XRef(Rc::new(y.clone()))]));
            append(&Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTuple(Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("machine_s")), crate::lower::model::Pa::PaBind(Text::lit("machine_b"))])), stepped.clone()), crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", f)))), Text::lit("set"), Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("machine_s")), crate::lower::model::Ex::XCx]))), crate::lower::model::Do::DoIfLet(crate::lower::model::Pa::PaCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("machine_b"))])), crate::lower::model::Ex::XVar(Text::lit("machine_b")), Array::from(vec![self_call(&gn_of(&sk.wx, out).name, &Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("machine_b"))]))]), Array::new())]), &moved_marks(sk, f))
        },
        Sk::SkPort(f) => Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_port", f)))), Text::lit("fire"), Array::from(vec![y.clone(), crate::lower::model::Ex::XCx]))), Text::lit("ok"), Array::new()))]),
        Sk::SkUp(m) => {
            let keyed = &len(&filter(&sk.wx.fields, &(|(f, _, _): &(Text, crate::lower::model::OutTy, Text)| f == &Text::lit("key")))) > &Nat::from(0u32);
            let args = if keyed {
                Array::from(vec![crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::lit("key")))), y.clone(), crate::lower::model::Ex::XCx])
            } else {
                Array::from(vec![y.clone(), crate::lower::model::Ex::XCx])
            };
            Array::from(vec![crate::lower::model::Do::DoIfLet(crate::lower::model::Pa::PaCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("parent"))])), crate::lower::model::Ex::XUpgrade(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::lit("parent")))), Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("parent"))), m.clone(), args.clone()))]), Array::new())])
        },
        Sk::SkCycle(job, again, res) => {
            let more = Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", job)))), Text::lit("set"), Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("next")), crate::lower::model::Ex::XCx]))), crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", again)))), Text::lit("arm"), Array::from(vec![crate::lower::model::Ex::XUnit, crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XSelf)), crate::lower::model::Ex::XCx])))]);
            let fin = Array::from(vec![self_call(&gn_of(&sk.wx, res).name, &Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("b"))]))]);
            Array::from(vec![crate::lower::model::Do::DoMatch(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", job)))), Text::lit("get"), Array::from(vec![crate::lower::model::Ex::XCx]))), Text::lit("cycle"), Array::new()), Array::from(vec![(crate::lower::model::Pa::PaCtor(Text::lit("prism_rtl::Turn::More"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("next"))])), more.clone()), (crate::lower::model::Pa::PaCtor(Text::lit("prism_rtl::Turn::Finished"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("b"))])), fin.clone())]))])
        },
    }
}

/// ```prism
/// HoldWritten: fn Sinks, Text -> [Do]
/// ```
pub fn hold_written(sk: &Sinks, f: &Text) -> Array<crate::lower::model::Do> {
    let r = Read::OwnRead(f.clone());
    let read_by_place = has_read(&sk.dirty, &r);
    let (dirty, told) = match &sk.wx.hosted_by {
        Some(_) => (Array::new(), if read_by_place {
            Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XSelf), Text::lit("document_moved"), Array::from(vec![crate::lower::model::Ex::XCx])))])
        } else {
            Array::new()
        }),
        None => (if read_by_place {
            Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCx), Text::lit("dirty"), Array::from(vec![crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XSelf))])))])
        } else {
            Array::new()
        }, Array::new()),
    };
    let stales = fold(&sk.wx.gen_holds, &Array::new(), &(|acc: &Array<crate::lower::model::Do>, (gname, hs): &(Text, Array<Read>)| if has_read(&reads_closed(&sk.wx.dyn_reads, hs), &r) {
        push(acc, &crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_stale", gname)))), Text::lit("set"), Array::from(vec![crate::lower::model::Ex::XBool(true)]))))
    } else {
        acc.clone()
    }));
    let row_marks = fold(&sk.wx.row_marks, &Array::new(), &(|acc: &Array<crate::lower::model::Do>, rm: &RowMarks| append(acc, &row_written(&sk.wx, rm, &r))));
    let builds = has_read(&sk.builds, &r) || (&len(&stales) > &Nat::from(0u32));
    let rebuild_it = if builds && !lists_build(sk, &r) {
        append(&stales, &Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCx), Text::lit("build_later"), Array::from(vec![crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XSelf))])))]))
    } else {
        stales.clone()
    };
    let gathered = match &sk.wx.result_moved {
        Some((m, rds)) => if has_read(rds, &r) {
            Array::from(vec![crate::lower::model::Do::DoIfLet(crate::lower::model::Pa::PaCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("parent"))])), crate::lower::model::Ex::XUpgrade(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::lit("parent")))), Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("parent"))), m.clone(), Array::from(vec![crate::lower::model::Ex::XCx])))]), Array::new())])
        } else {
            Array::new()
        },
        None => Array::new(),
    };
    append(&append(&append(&append(&append(&dirty, &told), &rebuild_it), &row_marks), &gathered), &moved_marks(sk, f))
}

/// ```prism
/// HostFieldEx: fn Wx, Pos -> Ex
/// ```
pub fn host_field_ex(wx: &Wx, pos: &crate::lower::model::Pos_) -> crate::lower::model::Ex {
    crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), host_local(wx, pos))
}

/// ```prism
/// MovedMarks: fn Sinks, Text -> [Do]
/// ```
pub fn moved_marks(sk: &Sinks, f: &Text) -> Array<crate::lower::model::Do> {
    moved_by(sk, &Read::OwnRead(f.clone()))
}

/// ```prism
/// MovedBy: fn Sinks, Read -> [Do]
/// ```
pub fn moved_by(sk: &Sinks, r: &Read) -> Array<crate::lower::model::Do> {
    let moved = filter(&sk.wx.gns, &(|g: &Gn| moves(r, g)));
    let flags = each(&moved, &(|g: &Gn| crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_moved", &g.name)))), Text::lit("set"), Array::from(vec![crate::lower::model::Ex::XBool(true)])))));
    let heights_ = sort_nats(&fold(&moved, &Array::new(), &(|acc: &Array<Nat>, g: &Gn| crate::check::types::add_nat(acc, &g.height))));
    let marks = each(&snaps_behind(&sk.wx, r), &(|sn: &SnapDef| crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_snap", &sn.name)))), Text::lit("mark"), Array::from(vec![crate::lower::model::Ex::XCx])))));
    let listed = if lists_build(sk, r) {
        Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCx), Text::lit("build_later"), Array::from(vec![crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XSelf))])))])
    } else {
        Array::new()
    };
    let answers = each(&filter(&sk.wx.dyn_answers, &(|(_, rds): &(Text, Array<Read>)| has_read(&reads_closed(&sk.wx.dyn_reads, rds), r))), &(|(name, _): &(Text, Array<Read>)| crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_port", name)))), Text::lit("fire"), Array::from(vec![crate::lower::model::Ex::XUnit, crate::lower::model::Ex::XCx]))), Text::lit("ok"), Array::new()))));
    let adoptions = each(&filter(&sk.wx.flattens, &(|fl: &FlatDef| r == &Read::OwnRead(fl.outer.clone()))), &(|fl: &FlatDef| crate::lower::model::Do::DoScope(adoption(fl))));
    append(&append(&append(&append(&append(&fold(&heights_, &flags, &(|acc: &Array<crate::lower::model::Do>, h: &Nat| append(acc, &ask_wake(sk, h)))), &marks), &listed), &answers), &adoptions), &source_marks(&sk.wx, r))
}

/// ```prism
/// SourceMarks: fn Wx, Read -> [Do]
/// ```
pub fn source_marks(wx: &Wx, r: &Read) -> Array<crate::lower::model::Do> {
    fold(&wx.builders, &Array::new(), &(|acc: &Array<crate::lower::model::Do>, b: &crate::lower::model::ForDef| if has_read(&reads_closed(&wx.dyn_reads, &or(&get(&wx.dyn_reads, &b.source), &Array::new())), r) {
        push(acc, &crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_cache", &b.source)))), Text::lit("mark"), Array::from(vec![crate::lower::model::Ex::XCx]))))
    } else {
        acc.clone()
    }))
}

/// ```prism
/// SnapsBehind: fn Wx, Read -> [SnapDef]
/// ```
pub fn snaps_behind(wx: &Wx, r: &Read) -> Array<SnapDef> {
    filter(&wx.snaps, &(|sn: &SnapDef| (r == &Read::OwnRead(sn.live.clone())) || has_read(&reads_closed(&wx.dyn_reads, &Array::from(vec![Read::OwnRead(sn.live.clone())])), r)))
}

/// ```prism
/// ListsBuild: fn Sinks, Read -> Bool
/// ```
pub fn lists_build(sk: &Sinks, r: &Read) -> bool {
    &len(&snaps_behind(&sk.wx, r)) > &Nat::from(0u32)
}

/// ```prism
/// FiringCode: unbounded fn Sinks, Gn, Ex -> [Do]
/// ```
pub fn firing_code(sk: &Sinks, g: &Gn, x: &crate::lower::model::Ex) -> Array<crate::lower::model::Do> {
    let many = (&len(&g.outs) > &Nat::from(1u32)) && !crate::lower::is_copy(&g.ty);
    let xv = if many { crate::lower::model::Ex::XClone(Rc::new(x.clone())) } else { x.clone() };
    run_to_end(fold_job(g.outs.clone(), Array::new(), {
        let xv = xv.clone();
        let sk = sk.clone();
        Rc::new(move |(p0, p1): (Array<crate::lower::model::Do>, Out)| {
            let xv = xv.clone();
            let sk = sk.clone();
            entered(once_job(move || {
                let acc = p0;
                let o = p1;
                call_value((&o.pipe)((xv.clone(), {
                    let sk = sk.clone();
                    let o = o.clone();
                    Rc::new(move |p0: crate::lower::model::Ex| {
                        let sk = sk.clone();
                        let o = o.clone();
                        once_job(move || {
                            let y = p0;
                            prism_rtl::Turn::Finished(sink_code(&sk, &o.sink, &y))
                        })
                    }) as Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>
                })), move |call_97202: Array<crate::lower::model::Do>| prism_rtl::Turn::Finished(append(&acc, &call_97202)))
            }))
        }) as Rc<dyn Fn((Array<crate::lower::model::Do>, Out)) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>
    }))
}

/// The step machine of `FiringCode`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FiringCode: unbounded fn Sinks, Gn, Ex -> [Do]
/// ```
pub struct FiringCode {
    pub sk: Sinks,
    pub g: Gn,
    pub x: crate::lower::model::Ex,
}

impl prism_rtl::Job<Array<crate::lower::model::Do>> for FiringCode {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::lower::model::Do>> {
        let sk = &self.sk;
        let g = &self.g;
        let x = &self.x;
        let many = (&len(&g.outs) > &Nat::from(1u32)) && !crate::lower::is_copy(&g.ty);
        let xv = if many { crate::lower::model::Ex::XClone(Rc::new(x.clone())) } else { x.clone() };
        fold_job(g.outs.clone(), Array::new(), {
            let xv = xv.clone();
            let sk = sk.clone();
            Rc::new(move |(p0, p1): (Array<crate::lower::model::Do>, Out)| {
                let xv = xv.clone();
                let sk = sk.clone();
                entered(once_job(move || {
                    let acc = p0;
                    let o = p1;
                    call_value((&o.pipe)((xv.clone(), {
                        let sk = sk.clone();
                        let o = o.clone();
                        Rc::new(move |p0: crate::lower::model::Ex| {
                            let sk = sk.clone();
                            let o = o.clone();
                            once_job(move || {
                                let y = p0;
                                prism_rtl::Turn::Finished(sink_code(&sk, &o.sink, &y))
                            })
                        }) as Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>
                    })), move |call_97202: Array<crate::lower::model::Do>| prism_rtl::Turn::Finished(append(&acc, &call_97202)))
                }))
            }) as Rc<dyn Fn((Array<crate::lower::model::Do>, Out)) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>
        }).cycle()
    }
}

/// `Start FiringCode, x`: what the function value is when passed to `@Run`.
pub fn start_firing_code(sk: Sinks, g: Gn, x: crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>> {
    Rc::new(FiringCode { sk, g, x })
}

/// ```prism
/// FinishNode: unbounded fn Wx, Text, [((Text, OutTy))], Bool -> NodeDef
/// ```
pub fn finish_node(wx0: &Wx, qk: &Text, params: &Array<(Text, crate::lower::model::OutTy)>, is_row: &bool) -> crate::lower::model::NodeDef {
    let closed_gns = each(&wx0.gns, &(|g: &Gn| if &g.kind == &GnKind::GnUpdated {
        with_reads(g, &reads_closed(&wx0.dyn_reads, &g.reads))
    } else {
        g.clone()
    }));
    let (row_defs, gns2) = finish_pending(wx0, &heights(&closed_gns));
    let is_gen = *is_row && (&len(&filter(&wx0.fields, &(|(f, _, _): &(Text, crate::lower::model::OutTy, Text)| f == &Text::lit("key")))) == &Nat::from(0u32));
    let wx = {
        let mut this: Wx = wx0.clone();
        this.gns = heights(&gns2);
        this.build = append(&this.build, &updated_gaps(wx0, &closed_gns, &is_gen));
        this.rows = fold(&row_defs, &this.rows, &(|acc: &Array<crate::lower::model::NodeDef>, rd: &crate::lower::model::NodeDef| append(&push(acc, rd), &rd.children)));
        this
    };
    let combs = filter(&wx.gns, &(|g: &Gn| is_comb(&g.kind) || (&g.kind == &GnKind::GnGather)));
    let heights_ = sort_nats(&fold(&combs, &Array::new(), &(|acc: &Array<Nat>, g: &Gn| crate::check::types::add_nat(acc, &g.height))));
    let many = &len(&heights_) > &Nat::from(1u32);
    let consts = each(&heights_, &(|h: &Nat| (wake_const(&heights_, h), h.clone(), Text::lit("merges' height above the node's inputs"))));
    let live = filter(&wx.places, &(|p_: &Place| &p_.getter != &Text::lit("")));
    let root_reads = match &wx.root_dyn {
        Some((_, rds, _)) => reads_closed(&wx.dyn_reads, rds),
        None => Array::new(),
    };
    let dirty_holds = fold(&live, &root_reads, &(|acc: &Array<Read>, p_: &Place| union_reads(acc, &reads_closed(&wx.dyn_reads, &p_.reads))));
    let build_holds = reads_closed(&wx.dyn_reads, &wx.build_holds);
    let sinks = Sinks { wx: wx.clone(), dirty: dirty_holds.clone(), builds: build_holds.clone(), heights: heights_.clone(), many };
    let ev_methods = run_to_end(each_job(filter(&wx.gns, &(|g: &Gn| &g.kind != &GnKind::GnNever)), {
        let sinks = sinks.clone();
        Rc::new(move |p0: Gn| {
            let sinks = sinks.clone();
            entered(once_job(move || {
                let g = p0;
                call_then(start_firing_code(sinks.clone(), g.clone(), crate::lower::model::Ex::XVar(Text::lit("v"))), move |firing_code_98994: Array<crate::lower::model::Do>| prism_rtl::Turn::Finished(crate::lower::model::MethDef { name: g.name.clone(), recv: crate::lower::model::Recv::RecvRc, params: Array::from(vec![(Text::lit("v"), g.ty.clone())]), cx_: crate::lower::model::CxArg::CxMut, ret: crate::lower::model::OutTy::OutUnit, body: firing_code_98994, tail: crate::lower::model::Ex::XUnit, doc: gn_doc(&g) }))
            }))
        }) as Rc<dyn Fn(Gn) -> Rc<dyn prism_rtl::Job<crate::lower::model::MethDef>>>
    }));
    let gather_ins = each(&filter(&wx.gns, &(|g: &Gn| &g.kind == &GnKind::GnGather)), &(|g: &Gn| gather_in(&sinks, g)));
    let place_getters = each(&live, &(|p_: &Place| crate::lower::model::MethDef { name: p_.getter.clone(), recv: crate::lower::model::Recv::RecvRef, params: Array::new(), cx_: crate::lower::model::CxArg::CxRef, ret: crate::lower::elem_ty(), body: Array::new(), tail: p_.level.clone(), doc: Text::from(format!("Place {}'s level, read at the read point.", &crate::lower::model::place_text(&p_.pos))) }));
    let wake_body = if many {
        Array::from(vec![wake_by_height(&combs, &heights_)])
    } else {
        each(&combs, &(|g: &Gn| decide(g)))
    };
    let started_body = each(&wx.started, &(|st: &Nat| self_call(&gn_of(&wx, st).name, &Array::from(vec![crate::lower::model::Ex::XUnit]))));
    let deferred_body = each(&wx.defers, &(|(f, id): &(Text, Nat)| crate::lower::model::Do::DoIfLet(crate::lower::model::Pa::PaCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("v"))])), crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", f)))), Text::lit("fired"), Array::from(vec![crate::lower::model::Ex::XCx])), Array::from(vec![self_call(&gn_of(&wx, id).name, &Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("v"))]))]), Array::new())));
    let patch_body0 = fold(&filter(&live, &(|p_: &Place| emits(&wx, &p_.pos))), &Array::new(), &(|acc: &Array<crate::lower::model::Do>, p_: &Place| append(acc, &patch_place(&wx, p_))));
    let patch_body = append(&patch_body0, &root_dyn_patch(&wx));
    let build_body = build_steps(&sinks, &false);
    let push_body = each(&filter(&wx.dyn_places, &(|(pos, _, _, _): &(crate::lower::model::Pos_, Text, crate::lower::model::OutTy, Text)| emits(&wx, pos))), &(|(pos, f, t, _): &(crate::lower::model::Pos_, Text, crate::lower::model::OutTy, Text)| crate::lower::model::Do::DoIf(crate::lower::model::Ex::XBin(Text::lit("=="), Rc::new(crate::lower::model::Ex::XVar(Text::lit("element"))), Rc::new(crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_element", f))))))), dyn_place_write(&sinks, f, &crate::lower::model::Ex::XDecode(t.clone(), Rc::new(crate::lower::model::Ex::XVar(Text::lit("v"))))), Array::new())));
    let hooks = filter(&Array::from(vec![(Text::lit("wake"), wake_body.clone()), (Text::lit("started"), started_body.clone()), (Text::lit("deferred"), deferred_body.clone()), (Text::lit("build"), build_body.clone()), (Text::lit("push"), push_body.clone()), (Text::lit("patch"), patch_body.clone())]), &(|(_, b): &(Text, Array<crate::lower::model::Do>)| &len(b) > &Nat::from(0u32)));
    let started_reg = if &len(&wx.started) > &Nat::from(0u32) {
        Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCx), Text::lit("on_started"), Array::from(vec![crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(Text::lit("node"))))])))])
    } else {
        Array::new()
    };
    let links = each(&wx.hosts, &(|h: &HostDef| crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XVar(Text::lit("node"))), Text::from(format!("{}", &h.name)))), Text::lit("link"), Array::from(vec![crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XVar(Text::lit("node"))))])))));
    let rows_built = append(&links, &build_steps(&sinks, &true));
    let subscribed = each(&wx.subs, &(|(ev, m, t): &(Text, Text, crate::lower::model::OutTy)| crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XCall(Text::lit("subscribe_row"), Array::from(vec![crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XVar(Text::lit("node")))), crate::lower::model::Ex::XUpgrade(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XVar(Text::lit("node"))), Text::lit("parent")))), crate::lower::model::Ex::XClosure(false, Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("p"))]), Rc::new(crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XVar(Text::lit("p"))), Text::from(format!("{}_port", ev))))))), crate::lower::model::Ex::XClosure(false, Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("n")), crate::lower::model::Pa::PaBind(Text::lit("v")), crate::lower::model::Pa::PaBind(Text::lit("cx"))]), Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("n"))), m.clone(), Array::from(vec![crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(Text::lit("v")))), crate::lower::model::Ex::XCx])))), crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XVar(Text::lit("node"))), Text::from(format!("{}_sub", m)))))])))));
    let answers = append(&each(&filter(&wx.answers, &(|(pos, _, _, _): &(crate::lower::model::Pos_, Nat, crate::lower::model::OutTy, Text)| emits(&wx, pos))), &(|(pos, id, t, _): &(crate::lower::model::Pos_, Nat, crate::lower::model::OutTy, Text)| answer_arm(&wx, pos, id, t))), &each(&filter(&wx.dyn_places, &(|(pos, _, _, _): &(crate::lower::model::Pos_, Text, crate::lower::model::OutTy, Text)| emits(&wx, pos))), &(|(pos, f, t, _): &(crate::lower::model::Pos_, Text, crate::lower::model::OutTy, Text)| dyn_answer_arm(&sinks, pos, f, t))));
    let forwards = append(&each(&filter(&wx.builders, &(|b: &crate::lower::model::ForDef| emits(&wx, &b.pos))), &(|b: &crate::lower::model::ForDef| (pos_pat(&b.pos, &key_tail()), forward_answer(b)))), &fold(&filter(&wx.gens, &(|gd: &crate::lower::model::GenDef| emits(&wx, &gd.pos))), &Array::new(), &(|acc: &Array<(crate::lower::model::Pa, crate::lower::model::Ex)>, gd: &crate::lower::model::GenDef| append(acc, &gen_forwards(gd)))));
    let host_methods = fold(&wx.hosts, &Array::new(), &(|acc: &Array<crate::lower::model::MethDef>, h: &HostDef| append(acc, &Array::from(vec![typed_dispatch(&sinks, &Text::from(format!("{}_answer", &h.name)), &h.scope), host_moved(&sinks, h)]))));
    let gathered = filter(&wx.snaps, &(|sn: &SnapDef| !(sn.before || is_generation(&wx, &sn.builder))));
    let gathered_moved_ = append(&append(&each(&gathered, &(|sn: &SnapDef| gathered_moved(sn))), &each(&wx.snaps, &(|sn: &SnapDef| snap_publish(&sinks, sn)))), &flatten_methods(&sinks));
    let hosted_methods = match &wx.hosted_by {
        Some(_) => Array::from(vec![typed_dispatch(&sinks, &Text::lit("deliver"), &Nat::from(0u32)), document_getter(&wx)]),
        None => Array::new(),
    };
    let moved_method = match &wx.hosted_by {
        Some(m) => Array::from(vec![document_moved(m)]),
        None => Array::new(),
    };
    let row_methods_ = if *is_row { row_methods(&wx) } else { Array::new() };
    let heard = each(&row_hears(&wx), &(|m: &Text| crate::lower::model::MethDef { name: Text::from(format!("parent_wrote_{}", m)), recv: crate::lower::model::Recv::RecvRc, params: Array::new(), cx_: crate::lower::model::CxArg::CxMut, ret: crate::lower::model::OutTy::OutUnit, body: append(&moved_by(&sinks, &Read::ParentRead(m.clone())), &fold(&wx.row_marks, &Array::new(), &(|acc: &Array<crate::lower::model::Do>, rm: &RowMarks| append(acc, &row_written(&wx, rm, &Read::ParentRead(m.clone())))))), tail: crate::lower::model::Ex::XUnit, doc: Text::from(format!("The block wrote behind its `{}`, which this row reads through the parent: the `!Updated` nodes over it are told and the wake asked at their heights; the rows of this row's own `for`s that read it are marked.", m)) }));
    let top = fold(&wx.gns, &Nat::from(0u32), &(|hi: &Nat, g: &Gn| max(hi, &g.height)));
    let wakes_field = if many {
        Array::from(vec![(Text::lit("wakes"), crate::lower::model::OutTy::OutWakes, Text::lit("the heights asked for this tick, lowest first"))])
    } else {
        Array::new()
    };
    let wakes_init = if many {
        Array::from(vec![(Text::lit("wakes"), crate::lower::model::Ex::XCall(Text::lit("Wakes::default"), Array::new()))])
    } else {
        Array::new()
    };
    let gen_fields = fold(&wx.gens, &Array::new(), &(|acc: &Array<(Text, crate::lower::model::OutTy, Text)>, gd: &crate::lower::model::GenDef| append(acc, &Array::from(vec![(gd.name.clone(), crate::lower::model::OutTy::OutCell(Rc::new(crate::lower::model::OutTy::OutOpt(Rc::new(crate::lower::model::OutTy::OutObj(Rc::new(crate::lower::model::OutTy::OutNamed(Text::lit("Row"), Array::new()))))))), Text::from(format!("the current generation of the `rebuild` at place {}", &crate::lower::model::place_text(&gd.pos)))), (Text::from(format!("{}_count", &gd.name)), crate::lower::model::OutTy::OutNamed(Text::lit("Cell"), Array::from(vec![crate::lower::model::OutTy::OutCount])), Text::lit("how many generations it has built")), (Text::from(format!("{}_stale", &gd.name)), crate::lower::model::OutTy::OutNamed(Text::lit("Cell"), Array::from(vec![crate::lower::model::OutTy::OutBool])), Text::lit("its source changed since it was built"))]))));
    let gen_inits = fold(&wx.gens, &Array::new(), &(|acc: &Array<(Text, crate::lower::model::Ex)>, gd: &crate::lower::model::GenDef| append(acc, &Array::from(vec![(gd.name.clone(), crate::lower::model::Ex::XCall(Text::lit("RefCell::new"), Array::from(vec![crate::lower::model::Ex::XNone]))), (Text::from(format!("{}_count", &gd.name)), crate::lower::model::Ex::XCall(Text::lit("Cell::new"), Array::from(vec![crate::lower::model::Ex::XIndex(Nat::from(0u32))]))), (Text::from(format!("{}_stale", &gd.name)), crate::lower::model::Ex::XCall(Text::lit("Cell::new"), Array::from(vec![crate::lower::model::Ex::XBool(false)])))]))));
    let port_fields = each(&wx.ports, &(|pn: &Text| (Text::from(format!("{}_port", pn)), crate::lower::model::OutTy::OutPort(Rc::new(gn_ty_named(&wx, pn))), Text::from(format!("`!{}`, which rows subscribe to", pn)))));
    let port_inits = each(&wx.ports, &(|pn: &Text| (Text::from(format!("{}_port", pn)), crate::lower::model::Ex::XCall(Text::lit("Port::new"), Array::new()))));
    let sub_fields = each(&wx.subs, &(|(ev, m, t): &(Text, Text, crate::lower::model::OutTy)| (Text::from(format!("{}_sub", m)), crate::lower::model::OutTy::OutNamed(Text::lit("Cell"), Array::from(vec![crate::lower::model::OutTy::OutOpt(Rc::new(crate::lower::model::OutTy::OutNamed(Text::lit("Handle"), Array::new())))])), Text::from(format!("the subscription to the parent's `!{}`", ev)))));
    let sub_inits = each(&wx.subs, &(|(ev, m, t): &(Text, Text, crate::lower::model::OutTy)| (Text::from(format!("{}_sub", m)), crate::lower::model::Ex::XCall(Text::lit("Cell::new"), Array::from(vec![crate::lower::model::Ex::XNone])))));
    let fallible = ((wx.fallible || *is_row) || (&len(&wx.builders) > &Nat::from(0u32))) || (&len(&wx.gens) > &Nat::from(0u32));
    crate::lower::model::NodeDef { name: wx.node_.clone(), prism: crate::check::types::bare_name(qk), doc: crate::lower::definition_text(&wx.lx, qk), params: params.clone(), fields: append(&append(&append(&append(&wx.fields, &wakes_field), &gen_fields), &port_fields), &sub_fields), consts: consts.clone(), lets: wx.lets.clone(), inits: append(&wx.inits, &append(&append(&append(&append(&wx.moves, &wakes_init), &gen_inits), &port_inits), &sub_inits)), build: append(&append(&append(&rows_built, &wx.build), &subscribed), &started_reg), fallible, methods: append(&append(&append(&append(&append(&append(&append(&append(&ev_methods, &gather_ins), &place_getters), &wx.getters), &row_methods_), &heard), &host_methods), &gathered_moved_), &moved_method), answers: append(&answers, &forwards), hooks: hooks.clone(), builders: wx.builders.clone(), wakes: many, children: wx.rows.clone(), gens: wx.gens.clone(), subs: wx.subs.clone(), top: top.clone(), row_kind: if *is_row {
        if is_gen {
            crate::lower::model::RowKind::GenerationRow
        } else {
            crate::lower::model::RowKind::ForRow
        }
    } else {
        crate::lower::model::RowKind::NotARow
    }, hosted: hosted_methods.clone() }
}

/// The step machine of `FinishNode`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FinishNode: unbounded fn Wx, Text, [((Text, OutTy))], Bool -> NodeDef
/// ```
pub struct FinishNode {
    pub wx0: Wx,
    pub qk: Text,
    pub params: Array<(Text, crate::lower::model::OutTy)>,
    pub is_row: bool,
}

impl prism_rtl::Job<crate::lower::model::NodeDef> for FinishNode {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::NodeDef> {
        let wx0 = &self.wx0;
        let qk = &self.qk;
        let params = &self.params;
        let is_row = &self.is_row;
        let closed_gns = each(&wx0.gns, &(|g: &Gn| if &g.kind == &GnKind::GnUpdated {
            with_reads(g, &reads_closed(&wx0.dyn_reads, &g.reads))
        } else {
            g.clone()
        }));
        let is_row = *is_row;
        let params = params.clone();
        let qk = qk.clone();
        let wx0 = wx0.clone();
        call_then(start_finish_pending(wx0.clone(), heights(&closed_gns)), move |finish_pending_97759: (Array<crate::lower::model::NodeDef>, Array<Gn>)| {
            let (row_defs, gns2) = finish_pending_97759;
            let is_gen = is_row && (&len(&filter(&wx0.fields, &(|(f, _, _): &(Text, crate::lower::model::OutTy, Text)| f == &Text::lit("key")))) == &Nat::from(0u32));
            let wx = {
                let mut this: Wx = wx0.clone();
                this.gns = heights(&gns2);
                this.build = append(&this.build, &updated_gaps(&wx0, &closed_gns, &is_gen));
                this.rows = fold(&row_defs, &this.rows, &(|acc: &Array<crate::lower::model::NodeDef>, rd: &crate::lower::model::NodeDef| append(&push(acc, rd), &rd.children)));
                this
            };
            let combs = filter(&wx.gns, &(|g: &Gn| is_comb(&g.kind) || (&g.kind == &GnKind::GnGather)));
            let heights_ = sort_nats(&fold(&combs, &Array::new(), &(|acc: &Array<Nat>, g: &Gn| crate::check::types::add_nat(acc, &g.height))));
            let many = &len(&heights_) > &Nat::from(1u32);
            let consts = each(&heights_, &(|h: &Nat| (wake_const(&heights_, h), h.clone(), Text::lit("merges' height above the node's inputs"))));
            let live = filter(&wx.places, &(|p_: &Place| &p_.getter != &Text::lit("")));
            let root_reads = match &wx.root_dyn {
                Some((_, rds, _)) => reads_closed(&wx.dyn_reads, rds),
                None => Array::new(),
            };
            let dirty_holds = fold(&live, &root_reads, &(|acc: &Array<Read>, p_: &Place| union_reads(acc, &reads_closed(&wx.dyn_reads, &p_.reads))));
            let build_holds = reads_closed(&wx.dyn_reads, &wx.build_holds);
            let sinks = Sinks { wx: wx.clone(), dirty: dirty_holds.clone(), builds: build_holds.clone(), heights: heights_.clone(), many };
            call_value(each_job(filter(&wx.gns, &(|g: &Gn| &g.kind != &GnKind::GnNever)), {
                let sinks = sinks.clone();
                Rc::new(move |p0: Gn| {
                    let sinks = sinks.clone();
                    entered(once_job(move || {
                        let g = p0;
                        call_then(start_firing_code(sinks.clone(), g.clone(), crate::lower::model::Ex::XVar(Text::lit("v"))), move |firing_code_98994: Array<crate::lower::model::Do>| prism_rtl::Turn::Finished(crate::lower::model::MethDef { name: g.name.clone(), recv: crate::lower::model::Recv::RecvRc, params: Array::from(vec![(Text::lit("v"), g.ty.clone())]), cx_: crate::lower::model::CxArg::CxMut, ret: crate::lower::model::OutTy::OutUnit, body: firing_code_98994, tail: crate::lower::model::Ex::XUnit, doc: gn_doc(&g) }))
                    }))
                }) as Rc<dyn Fn(Gn) -> Rc<dyn prism_rtl::Job<crate::lower::model::MethDef>>>
            }), move |each_98854: Array<crate::lower::model::MethDef>| {
                let ev_methods = each_98854;
                let gather_ins = each(&filter(&wx.gns, &(|g: &Gn| &g.kind == &GnKind::GnGather)), &(|g: &Gn| gather_in(&sinks, g)));
                let place_getters = each(&live, &(|p_: &Place| crate::lower::model::MethDef { name: p_.getter.clone(), recv: crate::lower::model::Recv::RecvRef, params: Array::new(), cx_: crate::lower::model::CxArg::CxRef, ret: crate::lower::elem_ty(), body: Array::new(), tail: p_.level.clone(), doc: Text::from(format!("Place {}'s level, read at the read point.", &crate::lower::model::place_text(&p_.pos))) }));
                let wake_body = if many {
                    Array::from(vec![wake_by_height(&combs, &heights_)])
                } else {
                    each(&combs, &(|g: &Gn| decide(g)))
                };
                let started_body = each(&wx.started, &(|st: &Nat| self_call(&gn_of(&wx, st).name, &Array::from(vec![crate::lower::model::Ex::XUnit]))));
                let deferred_body = each(&wx.defers, &(|(f, id): &(Text, Nat)| crate::lower::model::Do::DoIfLet(crate::lower::model::Pa::PaCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("v"))])), crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", f)))), Text::lit("fired"), Array::from(vec![crate::lower::model::Ex::XCx])), Array::from(vec![self_call(&gn_of(&wx, id).name, &Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("v"))]))]), Array::new())));
                let patch_body0 = fold(&filter(&live, &(|p_: &Place| emits(&wx, &p_.pos))), &Array::new(), &(|acc: &Array<crate::lower::model::Do>, p_: &Place| append(acc, &patch_place(&wx, p_))));
                let patch_body = append(&patch_body0, &root_dyn_patch(&wx));
                let build_body = build_steps(&sinks, &false);
                let push_body = each(&filter(&wx.dyn_places, &(|(pos, _, _, _): &(crate::lower::model::Pos_, Text, crate::lower::model::OutTy, Text)| emits(&wx, pos))), &(|(pos, f, t, _): &(crate::lower::model::Pos_, Text, crate::lower::model::OutTy, Text)| crate::lower::model::Do::DoIf(crate::lower::model::Ex::XBin(Text::lit("=="), Rc::new(crate::lower::model::Ex::XVar(Text::lit("element"))), Rc::new(crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_element", f))))))), dyn_place_write(&sinks, f, &crate::lower::model::Ex::XDecode(t.clone(), Rc::new(crate::lower::model::Ex::XVar(Text::lit("v"))))), Array::new())));
                let hooks = filter(&Array::from(vec![(Text::lit("wake"), wake_body.clone()), (Text::lit("started"), started_body.clone()), (Text::lit("deferred"), deferred_body.clone()), (Text::lit("build"), build_body.clone()), (Text::lit("push"), push_body.clone()), (Text::lit("patch"), patch_body.clone())]), &(|(_, b): &(Text, Array<crate::lower::model::Do>)| &len(b) > &Nat::from(0u32)));
                let started_reg = if &len(&wx.started) > &Nat::from(0u32) {
                    Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCx), Text::lit("on_started"), Array::from(vec![crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(Text::lit("node"))))])))])
                } else {
                    Array::new()
                };
                let links = each(&wx.hosts, &(|h: &HostDef| crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XVar(Text::lit("node"))), Text::from(format!("{}", &h.name)))), Text::lit("link"), Array::from(vec![crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XVar(Text::lit("node"))))])))));
                let rows_built = append(&links, &build_steps(&sinks, &true));
                let subscribed = each(&wx.subs, &(|(ev, m, t): &(Text, Text, crate::lower::model::OutTy)| crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XCall(Text::lit("subscribe_row"), Array::from(vec![crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XVar(Text::lit("node")))), crate::lower::model::Ex::XUpgrade(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XVar(Text::lit("node"))), Text::lit("parent")))), crate::lower::model::Ex::XClosure(false, Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("p"))]), Rc::new(crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XVar(Text::lit("p"))), Text::from(format!("{}_port", ev))))))), crate::lower::model::Ex::XClosure(false, Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("n")), crate::lower::model::Pa::PaBind(Text::lit("v")), crate::lower::model::Pa::PaBind(Text::lit("cx"))]), Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("n"))), m.clone(), Array::from(vec![crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(Text::lit("v")))), crate::lower::model::Ex::XCx])))), crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XVar(Text::lit("node"))), Text::from(format!("{}_sub", m)))))])))));
                let answers = append(&each(&filter(&wx.answers, &(|(pos, _, _, _): &(crate::lower::model::Pos_, Nat, crate::lower::model::OutTy, Text)| emits(&wx, pos))), &(|(pos, id, t, _): &(crate::lower::model::Pos_, Nat, crate::lower::model::OutTy, Text)| answer_arm(&wx, pos, id, t))), &each(&filter(&wx.dyn_places, &(|(pos, _, _, _): &(crate::lower::model::Pos_, Text, crate::lower::model::OutTy, Text)| emits(&wx, pos))), &(|(pos, f, t, _): &(crate::lower::model::Pos_, Text, crate::lower::model::OutTy, Text)| dyn_answer_arm(&sinks, pos, f, t))));
                let forwards = append(&each(&filter(&wx.builders, &(|b: &crate::lower::model::ForDef| emits(&wx, &b.pos))), &(|b: &crate::lower::model::ForDef| (pos_pat(&b.pos, &key_tail()), forward_answer(b)))), &fold(&filter(&wx.gens, &(|gd: &crate::lower::model::GenDef| emits(&wx, &gd.pos))), &Array::new(), &(|acc: &Array<(crate::lower::model::Pa, crate::lower::model::Ex)>, gd: &crate::lower::model::GenDef| append(acc, &gen_forwards(gd)))));
                let host_methods = fold(&wx.hosts, &Array::new(), &(|acc: &Array<crate::lower::model::MethDef>, h: &HostDef| append(acc, &Array::from(vec![typed_dispatch(&sinks, &Text::from(format!("{}_answer", &h.name)), &h.scope), host_moved(&sinks, h)]))));
                let gathered = filter(&wx.snaps, &(|sn: &SnapDef| !(sn.before || is_generation(&wx, &sn.builder))));
                let gathered_moved_ = append(&append(&each(&gathered, &(|sn: &SnapDef| gathered_moved(sn))), &each(&wx.snaps, &(|sn: &SnapDef| snap_publish(&sinks, sn)))), &flatten_methods(&sinks));
                let hosted_methods = match &wx.hosted_by {
                    Some(_) => Array::from(vec![typed_dispatch(&sinks, &Text::lit("deliver"), &Nat::from(0u32)), document_getter(&wx)]),
                    None => Array::new(),
                };
                let moved_method = match &wx.hosted_by {
                    Some(m) => Array::from(vec![document_moved(m)]),
                    None => Array::new(),
                };
                let row_methods_ = if is_row { row_methods(&wx) } else { Array::new() };
                let heard = each(&row_hears(&wx), &(|m: &Text| crate::lower::model::MethDef { name: Text::from(format!("parent_wrote_{}", m)), recv: crate::lower::model::Recv::RecvRc, params: Array::new(), cx_: crate::lower::model::CxArg::CxMut, ret: crate::lower::model::OutTy::OutUnit, body: append(&moved_by(&sinks, &Read::ParentRead(m.clone())), &fold(&wx.row_marks, &Array::new(), &(|acc: &Array<crate::lower::model::Do>, rm: &RowMarks| append(acc, &row_written(&wx, rm, &Read::ParentRead(m.clone())))))), tail: crate::lower::model::Ex::XUnit, doc: Text::from(format!("The block wrote behind its `{}`, which this row reads through the parent: the `!Updated` nodes over it are told and the wake asked at their heights; the rows of this row's own `for`s that read it are marked.", m)) }));
                let top = fold(&wx.gns, &Nat::from(0u32), &(|hi: &Nat, g: &Gn| max(hi, &g.height)));
                let wakes_field = if many {
                    Array::from(vec![(Text::lit("wakes"), crate::lower::model::OutTy::OutWakes, Text::lit("the heights asked for this tick, lowest first"))])
                } else {
                    Array::new()
                };
                let wakes_init = if many {
                    Array::from(vec![(Text::lit("wakes"), crate::lower::model::Ex::XCall(Text::lit("Wakes::default"), Array::new()))])
                } else {
                    Array::new()
                };
                let gen_fields = fold(&wx.gens, &Array::new(), &(|acc: &Array<(Text, crate::lower::model::OutTy, Text)>, gd: &crate::lower::model::GenDef| append(acc, &Array::from(vec![(gd.name.clone(), crate::lower::model::OutTy::OutCell(Rc::new(crate::lower::model::OutTy::OutOpt(Rc::new(crate::lower::model::OutTy::OutObj(Rc::new(crate::lower::model::OutTy::OutNamed(Text::lit("Row"), Array::new()))))))), Text::from(format!("the current generation of the `rebuild` at place {}", &crate::lower::model::place_text(&gd.pos)))), (Text::from(format!("{}_count", &gd.name)), crate::lower::model::OutTy::OutNamed(Text::lit("Cell"), Array::from(vec![crate::lower::model::OutTy::OutCount])), Text::lit("how many generations it has built")), (Text::from(format!("{}_stale", &gd.name)), crate::lower::model::OutTy::OutNamed(Text::lit("Cell"), Array::from(vec![crate::lower::model::OutTy::OutBool])), Text::lit("its source changed since it was built"))]))));
                let gen_inits = fold(&wx.gens, &Array::new(), &(|acc: &Array<(Text, crate::lower::model::Ex)>, gd: &crate::lower::model::GenDef| append(acc, &Array::from(vec![(gd.name.clone(), crate::lower::model::Ex::XCall(Text::lit("RefCell::new"), Array::from(vec![crate::lower::model::Ex::XNone]))), (Text::from(format!("{}_count", &gd.name)), crate::lower::model::Ex::XCall(Text::lit("Cell::new"), Array::from(vec![crate::lower::model::Ex::XIndex(Nat::from(0u32))]))), (Text::from(format!("{}_stale", &gd.name)), crate::lower::model::Ex::XCall(Text::lit("Cell::new"), Array::from(vec![crate::lower::model::Ex::XBool(false)])))]))));
                let port_fields = each(&wx.ports, &(|pn: &Text| (Text::from(format!("{}_port", pn)), crate::lower::model::OutTy::OutPort(Rc::new(gn_ty_named(&wx, pn))), Text::from(format!("`!{}`, which rows subscribe to", pn)))));
                let port_inits = each(&wx.ports, &(|pn: &Text| (Text::from(format!("{}_port", pn)), crate::lower::model::Ex::XCall(Text::lit("Port::new"), Array::new()))));
                let sub_fields = each(&wx.subs, &(|(ev, m, t): &(Text, Text, crate::lower::model::OutTy)| (Text::from(format!("{}_sub", m)), crate::lower::model::OutTy::OutNamed(Text::lit("Cell"), Array::from(vec![crate::lower::model::OutTy::OutOpt(Rc::new(crate::lower::model::OutTy::OutNamed(Text::lit("Handle"), Array::new())))])), Text::from(format!("the subscription to the parent's `!{}`", ev)))));
                let sub_inits = each(&wx.subs, &(|(ev, m, t): &(Text, Text, crate::lower::model::OutTy)| (Text::from(format!("{}_sub", m)), crate::lower::model::Ex::XCall(Text::lit("Cell::new"), Array::from(vec![crate::lower::model::Ex::XNone])))));
                let fallible = ((wx.fallible || is_row) || (&len(&wx.builders) > &Nat::from(0u32))) || (&len(&wx.gens) > &Nat::from(0u32));
                prism_rtl::Turn::Finished(crate::lower::model::NodeDef { name: wx.node_.clone(), prism: crate::check::types::bare_name(&qk), doc: crate::lower::definition_text(&wx.lx, &qk), params: params.clone(), fields: append(&append(&append(&append(&wx.fields, &wakes_field), &gen_fields), &port_fields), &sub_fields), consts: consts.clone(), lets: wx.lets.clone(), inits: append(&wx.inits, &append(&append(&append(&append(&wx.moves, &wakes_init), &gen_inits), &port_inits), &sub_inits)), build: append(&append(&append(&rows_built, &wx.build), &subscribed), &started_reg), fallible, methods: append(&append(&append(&append(&append(&append(&append(&append(&ev_methods, &gather_ins), &place_getters), &wx.getters), &row_methods_), &heard), &host_methods), &gathered_moved_), &moved_method), answers: append(&answers, &forwards), hooks: hooks.clone(), builders: wx.builders.clone(), wakes: many, children: wx.rows.clone(), gens: wx.gens.clone(), subs: wx.subs.clone(), top: top.clone(), row_kind: if is_row {
                    if is_gen {
                        crate::lower::model::RowKind::GenerationRow
                    } else {
                        crate::lower::model::RowKind::ForRow
                    }
                } else {
                    crate::lower::model::RowKind::NotARow
                }, hosted: hosted_methods.clone() })
            })
        })
    }
}

/// `Start FinishNode, x`: what the function value is when passed to `@Run`.
pub fn start_finish_node(wx0: Wx, qk: Text, params: Array<(Text, crate::lower::model::OutTy)>, is_row: bool) -> Rc<dyn prism_rtl::Job<crate::lower::model::NodeDef>> {
    Rc::new(FinishNode { wx0, qk, params, is_row })
}

/// ```prism
/// IsGeneration: fn Wx, Text -> Bool
/// ```
pub fn is_generation(wx: &Wx, name: &Text) -> bool {
    &len(&filter(&wx.gens, &(|gd: &crate::lower::model::GenDef| &gd.name == name))) > &Nat::from(0u32)
}

/// ```prism
/// FlattenMethods: fn Sinks -> [MethDef]
/// ```
pub fn flatten_methods(sk: &Sinks) -> Array<crate::lower::model::MethDef> {
    let wx = sk.wx.clone();
    let adopts = each(&wx.flattens, &(|fl: &FlatDef| {
        let set = crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_inner", &fl.name)))), Text::lit("set"), Array::from(vec![crate::lower::model::Ex::XCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XSelf), fl.outer.clone(), Array::from(vec![crate::lower::model::Ex::XCx]))])), crate::lower::model::Ex::XCx])));
        crate::lower::model::MethDef { name: Text::from(format!("{}_adopt", &fl.name)), recv: crate::lower::model::Recv::RecvRc, params: Array::new(), cx_: crate::lower::model::CxArg::CxMut, ret: crate::lower::model::OutTy::OutUnit, body: append(&Array::from(vec![set.clone()]), &hold_written(sk, &Text::from(format!("{}_inner", &fl.name)))), tail: crate::lower::model::Ex::XUnit, doc: Text::lit("`@Flatten` adopts the inner its `rebuild`'s dynamic held after the tick before, among this tick's first firings: from here on it reads that inner (Semantics ch. 7).") }
    }));
    let dyn_gens = filter(&wx.gens, &(|gd: &crate::lower::model::GenDef| &len(&filter(&wx.snaps, &(|sn: &SnapDef| &sn.builder == &gd.name))) > &Nat::from(0u32)));
    let moved = each(&dyn_gens, &(|gd: &crate::lower::model::GenDef| {
        let marks = fold(&filter(&wx.flattens, &(|fl: &FlatDef| &fl.generation == &gd.name)), &Array::new(), &(|acc: &Array<crate::lower::model::Do>, fl: &FlatDef| append(acc, &hold_written(sk, &Text::from(format!("{}_inner", &fl.name))))));
        crate::lower::model::MethDef { name: Text::from(format!("{}_result_moved", &gd.name)), recv: crate::lower::model::Recv::RecvRc, params: Array::new(), cx_: crate::lower::model::CxArg::CxMut, ret: crate::lower::model::OutTy::OutUnit, body: marks.clone(), tail: crate::lower::model::Ex::XUnit, doc: Text::lit("The current generation's result moved: what reads a `@Flatten` over it reads it again.") }
    }));
    append(&adopts, &moved)
}

/// ```prism
/// HostMoved: fn Sinks, HostDef -> MethDef
/// ```
pub fn host_moved(sk: &Sinks, h: &HostDef) -> crate::lower::model::MethDef {
    crate::lower::model::MethDef { name: Text::from(format!("{}_moved", &h.name)), recv: crate::lower::model::Recv::RecvRc, params: Array::new(), cx_: crate::lower::model::CxArg::CxMut, ret: crate::lower::model::OutTy::OutUnit, body: hold_written(sk, &Text::from(format!("{}_doc_now", &h.name))), tail: crate::lower::model::Ex::XUnit, doc: Text::from(format!("A node of the child hosted at place {} wrote behind its document: the structure is marked as for a write of a hold it reads (pick HO), the snapshot listed to be taken; the program's `$doc` moves when it is published, the tick after (pick ST).", &crate::lower::model::place_text(&h.pos))) }
}

/// ```prism
/// BuildSteps: fn Sinks, Bool -> [Do]
/// ```
pub fn build_steps(sk: &Sinks, at_build: &bool) -> Array<crate::lower::model::Do> {
    let wx = sk.wx.clone();
    let recv = if *at_build {
        crate::lower::model::Ex::XVar(Text::lit("node"))
    } else {
        crate::lower::model::Ex::XSelf
    };
    let take_fn = {
        let at_build = *at_build;
        let sk = sk.clone();
        Rc::new(move |sn: &SnapDef| if at_build { snap_take_at_build(sn) } else { snap_take(&sk, sn) })
    };
    let builder_fn = {
        let wx = wx.clone();
        let take_fn = take_fn.clone();
        let recv = recv.clone();
        Rc::new(move |b: &crate::lower::model::ForDef| {
            let before_ = each(&filter(&wx.snaps, &(|sn: &SnapDef| sn.before && (&sn.builder == &b.name))), &*take_fn);
            let after_ = each(&filter(&wx.snaps, &(|sn: &SnapDef| !sn.before && (&sn.builder == &b.name))), &*take_fn);
            append(&push(&before_, &crate::lower::model::Do::DoExpr(crate::lower::try_of(&crate::lower::model::Ex::XMethod(Rc::new(recv.clone()), Text::from(format!("{}_build", &b.name)), Array::from(vec![crate::lower::model::Ex::XCx]))))), &after_)
        })
    };
    let gen__fn = {
        let at_build = *at_build;
        let recv = recv.clone();
        let wx = wx.clone();
        let take_fn = take_fn.clone();
        Rc::new(move |gd: &crate::lower::model::GenDef| {
            let built = if at_build {
                crate::lower::model::Do::DoExpr(crate::lower::try_of(&crate::lower::model::Ex::XMethod(Rc::new(recv.clone()), Text::from(format!("{}_build", &gd.name)), Array::from(vec![crate::lower::model::Ex::XCx]))))
            } else {
                crate::lower::model::Do::DoIf(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_stale", &gd.name)))), Text::lit("replace"), Array::from(vec![crate::lower::model::Ex::XBool(false)])), Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::try_of(&crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_build", &gd.name)), Array::from(vec![crate::lower::model::Ex::XCx]))))]), Array::new())
            };
            append(&Array::from(vec![built.clone()]), &each(&filter(&wx.snaps, &(|sn: &SnapDef| !sn.before && (&sn.builder == &gd.name))), &*take_fn))
        })
    };
    fold(&crate::check::errors::range0(&(&len(&wx.scopes) + &Nat::from(1u32))), &Array::new(), &(|acc: &Array<crate::lower::model::Do>, i: &Nat| {
        let k = or(&(&len(&wx.scopes)).checked_sub(i), &Nat::from(0u32));
        let builders = fold(&filter(&wx.builders, &(|b: &crate::lower::model::ForDef| &b.pos.scope == &k)), &Array::new(), &(|a: &Array<crate::lower::model::Do>, b: &crate::lower::model::ForDef| append(a, &(&builder_fn)(b))));
        append(&append(acc, &builders), &fold(&filter(&wx.gens, &(|gd: &crate::lower::model::GenDef| &gd.pos.scope == &k)), &Array::new(), &(|a: &Array<crate::lower::model::Do>, gd: &crate::lower::model::GenDef| append(a, &(&gen__fn)(gd)))))
    }))
}

/// ```prism
/// SnapTakeAtBuild: fn SnapDef -> Do
/// ```
pub fn snap_take_at_build(sn: &SnapDef) -> crate::lower::model::Do {
    crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XVar(Text::lit("node"))), Text::from(format!("{}_snap", &sn.name)))), Text::lit("take"), Array::from(vec![crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("node"))), Text::from(format!("{}_now", &sn.name)), Array::from(vec![crate::lower::model::Ex::XCx])), crate::lower::model::Ex::XCx])))
}

/// ```prism
/// SnapTake: fn Sinks, SnapDef -> Do
/// ```
pub fn snap_take(sk: &Sinks, sn: &SnapDef) -> crate::lower::model::Do {
    let now = crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_now", &sn.name)), Array::from(vec![crate::lower::model::Ex::XCx]));
    let take_ = crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_snap", &sn.name)))), if sn.eq { Text::lit("take_compared") } else { Text::lit("take") }, Array::from(vec![now.clone(), crate::lower::model::Ex::XCx])));
    let queue = crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCx), Text::lit("answer_later"), Array::from(vec![crate::lower::model::Ex::XLater(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("node"))), Text::from(format!("{}_publish", &sn.name)), Array::from(vec![crate::lower::model::Ex::XCx]))))])));
    let queued = crate::lower::model::Do::DoIf(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_snap", &sn.name)))), Text::lit("queue"), Array::from(vec![crate::lower::model::Ex::XCx])), Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(Text::lit("node")), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XSelf))), queue.clone()]), Array::new());
    crate::lower::model::Do::DoIf(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_snap", &sn.name)))), Text::lit("marked"), Array::from(vec![crate::lower::model::Ex::XCx])), Array::from(vec![take_.clone(), queued.clone()]), Array::new())
}

/// ```prism
/// SnapPublish: fn Sinks, SnapDef -> MethDef
/// ```
pub fn snap_publish(sk: &Sinks, sn: &SnapDef) -> crate::lower::model::MethDef {
    crate::lower::model::MethDef { name: Text::from(format!("{}_publish", &sn.name)), recv: crate::lower::model::Recv::RecvRc, params: Array::new(), cx_: crate::lower::model::CxArg::CxMut, ret: crate::lower::model::OutTy::OutUnit, body: Array::from(vec![crate::lower::model::Do::DoIf(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_snap", &sn.name)))), Text::lit("published"), Array::from(vec![crate::lower::model::Ex::XCx])), hold_written(sk, &sn.name), Array::new())]), tail: crate::lower::model::Ex::XUnit, doc: Text::from(format!("{}, published: its snapshot of the tick before moved it, written as a hold is (pick ST).", &sn.what)) }
}

/// ```prism
/// GatheredMoved: fn SnapDef -> MethDef
/// ```
pub fn gathered_moved(sn: &SnapDef) -> crate::lower::model::MethDef {
    crate::lower::model::MethDef { name: Text::from(format!("{}_moved", &sn.name)), recv: crate::lower::model::Recv::RecvRc, params: Array::new(), cx_: crate::lower::model::CxArg::CxMut, ret: crate::lower::model::OutTy::OutUnit, body: Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_snap", &sn.name)))), Text::lit("mark"), Array::from(vec![crate::lower::model::Ex::XCx]))), crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCx), Text::lit("build_later"), Array::from(vec![crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XSelf))])))]), tail: crate::lower::model::Ex::XUnit, doc: Text::lit("A row's result moved: the `for`'s gathered dynamic is marked, and its snapshot taken after the builder (pick ST).") }
}

/// ```prism
/// DocumentGetter: fn Wx -> MethDef
/// ```
pub fn document_getter(wx: &Wx) -> crate::lower::model::MethDef {
    let is_own_fn = Rc::new(move |p_: &crate::lower::model::Pos_| &p_.scope == &Nat::from(0u32));
    let body = document_body(&{
        let f = Rc::new(vec_push);
        Rc::new(move |(a0, a1): (crate::lower::model::Ex, crate::lower::model::Ex)| {
            let f = f.clone();
            once_job(move || prism_rtl::Turn::Finished(f(&a0, &a1)))
        }) as Rc<dyn Fn((crate::lower::model::Ex, crate::lower::model::Ex)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Do>>>
    }, &filter(&wx.places, &(|pl: &Place| (&is_own_fn)(&pl.pos))), &filter(&wx.builders, &(|b: &crate::lower::model::ForDef| (&is_own_fn)(&b.pos))), &filter(&wx.gens, &(|gd: &crate::lower::model::GenDef| (&is_own_fn)(&gd.pos))));
    crate::lower::model::MethDef { name: Text::lit("document"), recv: crate::lower::model::Recv::RecvRef, params: Array::new(), cx_: crate::lower::model::CxArg::CxRef, ret: crate::lower::model::OutTy::OutNamed(Text::lit("Vec"), Array::from(vec![crate::lower::model::OutTy::OutTuple(Array::from(vec![crate::lower::model::OutTy::OutPath, crate::lower::elem_ty()]))])), body: append(&Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaMut(Text::lit("doc"))), crate::lower::model::OutTy::OutNamed(Text::lit("Vec"), Array::from(vec![crate::lower::model::OutTy::OutTuple(Array::from(vec![crate::lower::model::OutTy::OutPath, crate::lower::elem_ty()]))]))), crate::lower::model::Ex::XCall(Text::lit("Vec::new"), Array::new()))]), &body), tail: crate::lower::model::Ex::XVar(Text::lit("doc")), doc: Text::lit("The row's own places, entries of its host's document, by their paths relative to the row (pick HO).") }
}

/// ```prism
/// DocumentMoved: fn Text -> MethDef
/// ```
pub fn document_moved(m: &Text) -> crate::lower::model::MethDef {
    crate::lower::model::MethDef { name: Text::lit("document_moved"), recv: crate::lower::model::Recv::RecvRc, params: Array::new(), cx_: crate::lower::model::CxArg::CxMut, ret: crate::lower::model::OutTy::OutUnit, body: Array::from(vec![crate::lower::model::Do::DoIfLet(crate::lower::model::Pa::PaCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("parent"))])), crate::lower::model::Ex::XUpgrade(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::lit("parent")))), Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("parent"))), m.clone(), Array::from(vec![crate::lower::model::Ex::XCx])))]), Array::new())]), tail: crate::lower::model::Ex::XUnit, doc: Text::lit("A place of this row may have moved: its host's document moved, and the host's readers and rows are marked (pick HO).") }
}

/// ```prism
/// DocumentBody: fn (fn Ex, Ex -> Do), [Place], [ForDef], [GenDef] -> [Do]
/// ```
pub fn document_body(add_fn: &Rc<dyn Fn((crate::lower::model::Ex, crate::lower::model::Ex)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Do>>>, places: &Array<Place>, builders: &Array<crate::lower::model::ForDef>, gens: &Array<crate::lower::model::GenDef>) -> Array<crate::lower::model::Do> {
    let statics = run_to_end(each_job(places.clone(), {
        let add_fn = add_fn.clone();
        Rc::new(move |p0: Place| {
            let add_fn = add_fn.clone();
            entered(once_job(move || {
                let pl = p0;
                {
                    let level = if &pl.getter == &Text::lit("") {
                        pl.level.clone()
                    } else {
                        crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XSelf), pl.getter.clone(), Array::from(vec![crate::lower::model::Ex::XCx]))
                    };
                    (&add_fn)((crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCall(Text::lit("Path::root"), Array::new())), Text::lit("at"), Array::from(vec![crate::lower::model::Ex::XIndex(pl.pos.at.clone())])), level.clone())).cycle()
                }
            }))
        }) as Rc<dyn Fn(Place) -> Rc<dyn prism_rtl::Job<crate::lower::model::Do>>>
    }));
    let rows = run_to_end(each_job(builders.clone(), {
        let add_fn = add_fn.clone();
        Rc::new(move |p0: crate::lower::model::ForDef| {
            let add_fn = add_fn.clone();
            entered(once_job(move || {
                let b = p0;
                call_value((&add_fn)((crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCall(Text::lit("Path::root"), Array::new())), Text::lit("at"), Array::from(vec![crate::lower::model::Ex::XIndex(b.pos.at.clone())]))), Text::lit("child"), Array::from(vec![crate::lower::model::Ex::XCtor(Text::lit("Segment::Key"), Array::from(vec![crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("k"))), Text::lit("to_pod"), Array::new())]))]))), Text::lit("join"), Array::from(vec![crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XVar(Text::lit("p"))))])), crate::lower::model::Ex::XVar(Text::lit("e")))), move |add_114367: crate::lower::model::Do| prism_rtl::Turn::Finished(crate::lower::model::Do::DoFor(crate::lower::model::Pa::PaTuple(Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("k")), crate::lower::model::Pa::PaBind(Text::lit("row"))])), crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), b.name.clone())), Text::lit("borrow"), Array::new())), Text::lit("iter"), Array::new()), Array::from(vec![crate::lower::model::Do::DoFor(crate::lower::model::Pa::PaTuple(Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("p")), crate::lower::model::Pa::PaBind(Text::lit("e"))])), crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("row"))), Text::lit("document"), Array::from(vec![crate::lower::model::Ex::XCx])), Array::from(vec![add_114367]))]))))
            }))
        }) as Rc<dyn Fn(crate::lower::model::ForDef) -> Rc<dyn prism_rtl::Job<crate::lower::model::Do>>>
    }));
    let generations = run_to_end(each_job(gens.clone(), {
        let add_fn = add_fn.clone();
        Rc::new(move |p0: crate::lower::model::GenDef| {
            let add_fn = add_fn.clone();
            entered(once_job(move || {
                let gd = p0;
                call_value((&add_fn)((crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCall(Text::lit("Path::root"), Array::new())), Text::lit("at"), Array::from(vec![crate::lower::model::Ex::XIndex(gd.pos.at.clone())]))), Text::lit("child"), Array::from(vec![crate::lower::model::Ex::XCtor(Text::lit("Segment::Gen"), Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("g"))]))]))), Text::lit("join"), Array::from(vec![crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XVar(Text::lit("p"))))])), crate::lower::model::Ex::XVar(Text::lit("e")))), move |add_114939: crate::lower::model::Do| prism_rtl::Turn::Finished(crate::lower::model::Do::DoIfLet(crate::lower::model::Pa::PaCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("row"))])), crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), gd.name.clone())), Text::lit("borrow"), Array::new())), Text::lit("as_ref"), Array::new()), Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(Text::lit("g")), crate::lower::model::Ex::XBin(Text::lit("-"), Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_count", &gd.name)))), Text::lit("get"), Array::new())), Rc::new(crate::lower::model::Ex::XIndex(Nat::from(1u32))))), crate::lower::model::Do::DoFor(crate::lower::model::Pa::PaTuple(Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("p")), crate::lower::model::Pa::PaBind(Text::lit("e"))])), crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("row"))), Text::lit("document"), Array::from(vec![crate::lower::model::Ex::XCx])), Array::from(vec![add_114939]))]), Array::new())))
            }))
        }) as Rc<dyn Fn(crate::lower::model::GenDef) -> Rc<dyn prism_rtl::Job<crate::lower::model::Do>>>
    }));
    append(&append(&statics, &rows), &generations)
}

/// ```prism
/// MapInsert: fn Ex, Ex -> Do
/// ```
pub fn map_insert(path_: &crate::lower::model::Ex, e: &crate::lower::model::Ex) -> crate::lower::model::Do {
    crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("doc"))), Text::lit("insert"), Array::from(vec![path_.clone(), e.clone()])))
}

/// ```prism
/// VecPush: fn Ex, Ex -> Do
/// ```
pub fn vec_push(path_: &crate::lower::model::Ex, e: &crate::lower::model::Ex) -> crate::lower::model::Do {
    crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("doc"))), Text::lit("push"), Array::from(vec![crate::lower::model::Ex::XTuple(Array::from(vec![path_.clone(), e.clone()]))])))
}

/// ```prism
/// DynAnswerArm: fn Sinks, Pos, Text, OutTy -> ((Pa, Ex))
/// ```
pub fn dyn_answer_arm(sk: &Sinks, pos: &crate::lower::model::Pos_, f: &Text, t: &crate::lower::model::OutTy) -> (crate::lower::model::Pa, crate::lower::model::Ex) {
    (pos_pat(pos, &Array::new()), crate::lower::model::Ex::XBlock(dyn_place_write(sk, f, &crate::lower::model::Ex::XDecode(t.clone(), Rc::new(crate::lower::model::Ex::XVar(Text::lit("v"))))), Rc::new(crate::lower::model::Ex::XUnit)))
}

/// ```prism
/// DynPlaceWrite: fn Sinks, Text, Ex -> [Do]
/// ```
pub fn dyn_place_write(sk: &Sinks, f: &Text, value: &crate::lower::model::Ex) -> Array<crate::lower::model::Do> {
    append(&Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", f)))), Text::lit("set"), Array::from(vec![value.clone(), crate::lower::model::Ex::XCx])))]), &hold_written(sk, f))
}

/// ```prism
/// UpdatedGaps: fn Wx, [Gn], Bool -> [Do]
/// ```
pub fn updated_gaps(wx: &Wx, gns: &Array<Gn>, is_gen: &bool) -> Array<crate::lower::model::Do> {
    let holds = fold(&wx.fields, &Array::new(), &(|acc: &Array<Text>, (f, t, _): &(Text, crate::lower::model::OutTy, Text)| if is_hold(t) { push(acc, f) } else { acc.clone() }));
    let derived = keys(&wx.dyn_reads);
    let roots = snap_names(wx);
    let own = fold(&filter(gns, &(|g: &Gn| &g.kind == &GnKind::GnUpdated)), &Array::new(), &(|acc: &Array<crate::lower::model::Do>, g: &Gn| fold(&g.reads, acc, &(|a: &Array<crate::lower::model::Do>, r: &Read| match r {
        Read::ParentRead(f) => if *is_gen {
            push(a, &crate::lower::refusal_do(&Text::from(format!("`!Updated` of a dynamic in a generation that reads its block's `{}`, which the block does not tell a generation of (gap DY)", f))))
        } else {
            a.clone()
        },
        Read::OwnRead(f) => if (crate::check::types::has_text(&holds, f) || crate::check::types::has_text(&derived, f)) || crate::check::types::has_text(&roots, f) {
            a.clone()
        } else {
            push(a, &crate::lower::refusal_do(&Text::from(format!("`!Updated` of a dynamic that reads `{}`, which no sink of this node writes (no height for its event)", f))))
        },
    }))));
    fold(&wx.pending, &own, &(|acc: &Array<crate::lower::model::Do>, p_: &PendingRow| fold(&row_hears(&p_.wx), acc, &(|a: &Array<crate::lower::model::Do>, m: &Text| {
        let behind = reads_closed(&wx.dyn_reads, &Array::from(vec![Read::OwnRead(m.clone())]));
        let written = fold(&behind, &false, &(|w: &bool, r: &Read| *w || match r {
            Read::OwnRead(h) => crate::check::types::has_text(&holds, h),
            Read::ParentRead(_) => true,
        }));
        if crate::check::types::has_text(&roots, m) || reaches_snap(&roots, &behind) {
            push(a, &crate::lower::refusal_do(&Text::from(format!("`!Updated` of a dynamic in a row that reads its block's `{}`, a structural dynamic the block publishes at the start of a tick, not lowered for a row's `!Updated` (gap SU)", m))))
        } else {
            if written || crate::check::types::has_text(&derived, m) {
                a.clone()
            } else {
                push(a, &crate::lower::refusal_do(&Text::from(format!("`!Updated` of a dynamic in a row that reads its block's `{}`, which no sink of the block writes (no height for its event)", m))))
            }
        }
    }))))
}

/// ```prism
/// FinishPending: unbounded fn Wx, [Gn] -> (([NodeDef], [Gn]))
/// ```
pub fn finish_pending(wx: &Wx, gns: &Array<Gn>) -> (Array<crate::lower::model::NodeDef>, Array<Gn>) {
    run_to_end(fold_job(wx.pending.clone(), (Array::new(), gns.clone()), {
        let wx = wx.clone();
        Rc::new(move |(p0, p1): ((Array<crate::lower::model::NodeDef>, Array<Gn>), PendingRow)| {
            let wx = wx.clone();
            entered(once_job(move || {
                let (defs, cur) = p0;
                let p_ = p1;
                {
                    let floors = fold(&row_hears(&p_.wx), &Map::new(), &(|acc: &Map<Text, Nat>, m: &Text| insert(acc, m, &parent_floor(&wx, &cur, &Array::from(vec![Read::ParentRead(m.clone())])))));
                    let floored = {
                        let mut this: Wx = p_.wx.clone();
                        this.floors = floors.clone();
                        this.gns = each(&this.gns, &(|g: &Gn| if &g.kind == &GnKind::GnUpdated {
                            with_floor(g, &parent_floor(&wx, &cur, &reads_closed(&p_.wx.dyn_reads, &g.reads)))
                        } else {
                            g.clone()
                        }));
                        this
                    };
                    call_then(start_finish_node(floored.clone(), p_.qk.clone(), p_.params.clone(), true), move |finish_node_119205: crate::lower::model::NodeDef| {
                        let def = finish_node_119205;
                        let next = match &p_.gather {
                            Some(gid) => each(&cur, &(|g: &Gn| if &g.id == gid { with_height(g, &(&def.top + &Nat::from(1u32))) } else { g.clone() })),
                            None => cur.clone(),
                        };
                        prism_rtl::Turn::Finished((push(&defs, &def), next.clone()))
                    })
                }
            }))
        }) as Rc<dyn Fn(((Array<crate::lower::model::NodeDef>, Array<Gn>), PendingRow)) -> Rc<dyn prism_rtl::Job<(Array<crate::lower::model::NodeDef>, Array<Gn>)>>>
    }))
}

/// The step machine of `FinishPending`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FinishPending: unbounded fn Wx, [Gn] -> (([NodeDef], [Gn]))
/// ```
pub struct FinishPending {
    pub wx: Wx,
    pub gns: Array<Gn>,
}

impl prism_rtl::Job<(Array<crate::lower::model::NodeDef>, Array<Gn>)> for FinishPending {
    fn cycle(&self) -> prism_rtl::Turn<(Array<crate::lower::model::NodeDef>, Array<Gn>)> {
        let wx = &self.wx;
        let gns = &self.gns;
        fold_job(wx.pending.clone(), (Array::new(), gns.clone()), {
            let wx = wx.clone();
            Rc::new(move |(p0, p1): ((Array<crate::lower::model::NodeDef>, Array<Gn>), PendingRow)| {
                let wx = wx.clone();
                entered(once_job(move || {
                    let (defs, cur) = p0;
                    let p_ = p1;
                    {
                        let floors = fold(&row_hears(&p_.wx), &Map::new(), &(|acc: &Map<Text, Nat>, m: &Text| insert(acc, m, &parent_floor(&wx, &cur, &Array::from(vec![Read::ParentRead(m.clone())])))));
                        let floored = {
                            let mut this: Wx = p_.wx.clone();
                            this.floors = floors.clone();
                            this.gns = each(&this.gns, &(|g: &Gn| if &g.kind == &GnKind::GnUpdated {
                                with_floor(g, &parent_floor(&wx, &cur, &reads_closed(&p_.wx.dyn_reads, &g.reads)))
                            } else {
                                g.clone()
                            }));
                            this
                        };
                        call_then(start_finish_node(floored.clone(), p_.qk.clone(), p_.params.clone(), true), move |finish_node_119205: crate::lower::model::NodeDef| {
                            let def = finish_node_119205;
                            let next = match &p_.gather {
                                Some(gid) => each(&cur, &(|g: &Gn| if &g.id == gid { with_height(g, &(&def.top + &Nat::from(1u32))) } else { g.clone() })),
                                None => cur.clone(),
                            };
                            prism_rtl::Turn::Finished((push(&defs, &def), next.clone()))
                        })
                    }
                }))
            }) as Rc<dyn Fn(((Array<crate::lower::model::NodeDef>, Array<Gn>), PendingRow)) -> Rc<dyn prism_rtl::Job<(Array<crate::lower::model::NodeDef>, Array<Gn>)>>>
        }).cycle()
    }
}

/// `Start FinishPending, x`: what the function value is when passed to `@Run`.
pub fn start_finish_pending(wx: Wx, gns: Array<Gn>) -> Rc<dyn prism_rtl::Job<(Array<crate::lower::model::NodeDef>, Array<Gn>)>> {
    Rc::new(FinishPending { wx, gns })
}

/// ```prism
/// ParentFloor: fn Wx, [Gn], [Read] -> Nat
/// ```
pub fn parent_floor(wx: &Wx, gns: &Array<Gn>, reads: &Array<Read>) -> Nat {
    fold(reads, &Nat::from(0u32), &(|hi: &Nat, r: &Read| match r {
        Read::ParentRead(m) => fold(&reads_closed(&wx.dyn_reads, &Array::from(vec![Read::OwnRead(m.clone())])), hi, &(|h2: &Nat, hr: &Read| match hr {
            Read::OwnRead(f) => fold(gns, h2, &(|h3: &Nat, g: &Gn| if writes_hold(g, f) { max(h3, &(&g.height + &Nat::from(1u32))) } else { h3.clone() })),
            Read::ParentRead(up) => max(h2, &or(&get(&wx.floors, up), &Nat::from(0u32))),
        })),
        Read::OwnRead(_) => hi.clone(),
    }))
}

/// ```prism
/// WritesHold: fn Gn, Text -> Bool
/// ```
pub fn writes_hold(g: &Gn, f: &Text) -> bool {
    fold(&g.outs, &false, &(|acc: &bool, o: &Out| *acc || sink_writes_hold(&o.sink, f)))
}

/// ```prism
/// SinkWritesHold: fn Sk, Text -> Bool
/// ```
pub fn sink_writes_hold(sk0: &Sk, f: &Text) -> bool {
    match sk0 {
        Sk::SkHold(h) => h == f,
        Sk::SkMachine(h, _, _) => h == f,
        other => false,
    }
}

/// ```prism
/// WithFloor: fn Gn, Nat -> Gn
/// ```
pub fn with_floor(g: &Gn, h: &Nat) -> Gn {
    let mut this: Gn = g.clone();
    this.floor = h.clone();
    this
}

/// ```prism
/// WithHeight: fn Gn, Nat -> Gn
/// ```
pub fn with_height(g: &Gn, h: &Nat) -> Gn {
    let mut this: Gn = g.clone();
    this.height = h.clone();
    this
}

/// ```prism
/// RowHears: fn Wx -> [Text]
/// ```
pub fn row_hears(wx: &Wx) -> Array<Text> {
    let from_updated = fold(&filter(&wx.gns, &(|g: &Gn| &g.kind == &GnKind::GnUpdated)), &Array::new(), &(|acc: &Array<Read>, g: &Gn| union_reads(acc, &reads_closed(&wx.dyn_reads, &g.reads))));
    let from_rows = fold(&wx.row_marks, &Array::new(), &(|acc: &Array<Read>, rm: &RowMarks| union_reads(acc, &reads_closed(&wx.dyn_reads, &append(&rm.reads, &each(&rm.wrote, &(|m: &Text| Read::OwnRead(m.clone()))))))));
    fold(&union_reads(&from_updated, &from_rows), &Array::new(), &(|acc: &Array<Text>, r: &Read| match r {
        Read::ParentRead(m) => crate::check::types::add_text(acc, m),
        Read::OwnRead(_) => acc.clone(),
    }))
}

/// ```prism
/// RowWritten: fn Wx, RowMarks, Read -> [Do]
/// ```
pub fn row_written(wx: &Wx, rm: &RowMarks, r: &Read) -> Array<crate::lower::model::Do> {
    let dirty = if has_read(&reads_closed(&wx.dyn_reads, &rm.reads), r) {
        Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCx), Text::lit("dirty"), Array::from(vec![crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(Text::lit("row"))))])))])
    } else {
        Array::new()
    };
    let told = fold(&rm.wrote, &Array::new(), &(|acc: &Array<crate::lower::model::Do>, m: &Text| if has_read(&reads_closed(&wx.dyn_reads, &Array::from(vec![Read::OwnRead(m.clone())])), r) {
        push(acc, &crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("row"))), Text::from(format!("parent_wrote_{}", m)), Array::from(vec![crate::lower::model::Ex::XCx]))))
    } else {
        acc.clone()
    }));
    let body = append(&dirty, &told);
    if &len(&body) == &Nat::from(0u32) {
        Array::new()
    } else {
        match &rm.kind {
            crate::lower::model::RowKind::GenerationRow => Array::from(vec![crate::lower::model::Do::DoIfLet(crate::lower::model::Pa::PaCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("row"))])), crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), rm.builder.clone())), Text::lit("borrow"), Array::new())), Text::lit("as_ref"), Array::new()), body.clone(), Array::new())]),
            _ => Array::from(vec![crate::lower::model::Do::DoFor(crate::lower::model::Pa::PaBind(Text::lit("row")), crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), rm.builder.clone())), Text::lit("borrow"), Array::new())), Text::lit("values"), Array::new()), body.clone())]),
        }
    }
}

/// ```prism
/// PatchPlace: fn Wx, Place -> [Do]
/// ```
pub fn patch_place(wx: &Wx, p_: &Place) -> Array<crate::lower::model::Do> {
    let pull = crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(p_.getter.clone()), crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XSelf), p_.getter.clone(), Array::from(vec![crate::lower::model::Ex::XCx])));
    let at_ = place_at(wx, &Text::lit("self"), &p_.pos);
    Array::from(vec![pull.clone(), crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCx), Text::lit("changed"), Array::from(vec![at_.clone(), crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(p_.getter.clone())), Text::lit("to_pod"), Array::new())])))])
}

/// ```prism
/// Emits: fn Wx, Pos -> Bool
/// ```
pub fn emits(wx: &Wx, pos: &crate::lower::model::Pos_) -> bool {
    (&pos.scope == &Nat::from(0u32)) && (&wx.hosted_by == &None)
}

/// ```prism
/// ResultTold: fn Ex -> [Do]
/// ```
pub fn result_told(node_: &crate::lower::model::Ex) -> Array<crate::lower::model::Do> {
    let r = crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(Text::lit("r")), crate::lower::model::Ex::XMethod(Rc::new(node_.clone()), Text::lit("result_value"), Array::from(vec![crate::lower::model::Ex::XCx])));
    Array::from(vec![r.clone(), result_kept(node_), result_tell()])
}

/// ```prism
/// ResultMoved: fn Ex -> [Do]
/// ```
pub fn result_moved(node_: &crate::lower::model::Ex) -> Array<crate::lower::model::Do> {
    let r = crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(Text::lit("r")), crate::lower::model::Ex::XMethod(Rc::new(node_.clone()), Text::lit("result_value"), Array::from(vec![crate::lower::model::Ex::XCx])));
    let last = crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(node_.clone()), Text::lit("result_last"))), Text::lit("borrow"), Array::new())), Text::lit("as_ref"), Array::new());
    let differs = crate::lower::model::Ex::XBin(Text::lit("!="), Rc::new(last.clone()), Rc::new(crate::lower::model::Ex::XCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XVar(Text::lit("r"))))]))));
    Array::from(vec![r.clone(), crate::lower::model::Do::DoIf(differs.clone(), Array::from(vec![result_kept(node_), result_tell()]), Array::new())])
}

/// ```prism
/// ResultKept: fn Ex -> Do
/// ```
pub fn result_kept(node_: &crate::lower::model::Ex) -> crate::lower::model::Do {
    crate::lower::model::Do::DoAssign(crate::lower::model::Ex::XDeref(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(node_.clone()), Text::lit("result_last"))), Text::lit("borrow_mut"), Array::new()))), crate::lower::model::Ex::XCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(Text::lit("r"))))])))
}

/// ```prism
/// let resultTell
/// ```
pub fn result_tell() -> crate::lower::model::Do {
    crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCx), Text::lit("result"), Array::from(vec![crate::lower::model::Ex::XCtor(Text::lit("Outcome::Value"), Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("r"))]))])))
}

/// ```prism
/// Adoption: fn FlatDef -> [Do]
/// ```
pub fn adoption(fl: &FlatDef) -> Array<crate::lower::model::Do> {
    let adopt = crate::lower::model::Ex::XLater(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("node"))), Text::from(format!("{}_adopt", &fl.name)), Array::from(vec![crate::lower::model::Ex::XCx]))));
    Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(Text::lit("node")), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XSelf))), crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCx), Text::lit("answer_later"), Array::from(vec![adopt.clone()])))])
}

/// ```prism
/// PlaceAt: fn Wx, Text, Pos -> Ex
/// ```
pub fn place_at(wx: &Wx, recv: &Text, pos: &crate::lower::model::Pos_) -> crate::lower::model::Ex {
    let at_ = Array::from(vec![crate::lower::model::Ex::XIndex(pos.at.clone())]);
    if emits(wx, pos) {
        crate::lower::model::Ex::XMethod(Rc::new(if recv == &Text::lit("") {
            crate::lower::model::Ex::XVar(Text::lit("path"))
        } else {
            if recv == &Text::lit("self") {
                crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::lit("path"))
            } else {
                crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XVar(recv.clone())), Text::lit("path"))
            }
        }), Text::lit("at"), at_.clone())
    } else {
        crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCall(Text::lit("Path::root"), Array::new())), Text::lit("at"), at_.clone())
    }
}

/// ```prism
/// PosPat: fn Pos, [Pa] -> Pa
/// ```
pub fn pos_pat(pos: &crate::lower::model::Pos_, tail: &Array<crate::lower::model::Pa>) -> crate::lower::model::Pa {
    crate::lower::model::Pa::PaSlice(append(&Array::from(vec![crate::lower::model::Pa::PaCtor(Text::lit("Segment::Pos"), Array::from(vec![crate::lower::model::Pa::PaIndex(pos.at.clone())]))]), tail))
}

/// ```prism
/// let keyTail
/// ```
pub fn key_tail() -> Array<crate::lower::model::Pa> {
    Array::from(vec![crate::lower::model::Pa::PaCtor(Text::lit("Segment::Key"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("k"))])), crate::lower::model::Pa::PaRest(Text::lit("rest"))])
}

/// ```prism
/// let genTail
/// ```
pub fn gen_tail() -> Array<crate::lower::model::Pa> {
    Array::from(vec![crate::lower::model::Pa::PaCtor(Text::lit("Segment::Gen"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("g"))])), crate::lower::model::Pa::PaRest(Text::lit("rest"))])
}

/// ```prism
/// ?HostedRows: fn Wx -> ?Text
/// ```
pub fn hosted_rows(wx: &Wx) -> Option<Text> {
    if &wx.pos.scope > &Nat::from(0u32) {
        Some(Text::from(format!("{}_moved", &or(&index(&wx.scopes, &crate::syntax::lexer::dec(&wx.pos.scope)), &Text::lit("")))))
    } else {
        match &wx.hosted_by {
            Some(_) => Some(Text::lit("document_moved")),
            None => None,
        }
    }
}

/// ```prism
/// RootDynPatch: fn Wx -> [Do]
/// ```
pub fn root_dyn_patch(wx: &Wx) -> Array<crate::lower::model::Do> {
    match &wx.root_dyn {
        Some(_) => Array::from(vec![crate::lower::model::Do::DoLine(result_moved(&crate::lower::model::Ex::XSelf))]),
        None => Array::new(),
    }
}

/// ```prism
/// AnswerArm: fn Wx, Pos, Nat, OutTy -> ((Pa, Ex))
/// ```
pub fn answer_arm(wx: &Wx, pos: &crate::lower::model::Pos_, id: &Nat, t: &crate::lower::model::OutTy) -> (crate::lower::model::Pa, crate::lower::model::Ex) {
    let call = crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XSelf), gn_of(wx, id).name.clone(), Array::from(vec![crate::lower::model::Ex::XDecode(t.clone(), Rc::new(crate::lower::model::Ex::XVar(Text::lit("v")))), crate::lower::model::Ex::XCx]));
    (pos_pat(pos, &Array::new()), call.clone())
}

/// ```prism
/// TypedAnswerArm: fn Wx, Pos, Nat, Text -> ((Pa, [Do]))
/// ```
pub fn typed_answer_arm(wx: &Wx, pos: &crate::lower::model::Pos_, id: &Nat, acc: &Text) -> (crate::lower::model::Pa, Array<crate::lower::model::Do>) {
    (pos_pat(pos, &Array::new()), Array::from(vec![self_call(&gn_of(wx, id).name, &Array::from(vec![crate::lower::try_of(&crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("v"))), acc.clone(), Array::new()))]))]))
}

/// ```prism
/// TypedDynArm: fn Sinks, Pos, Text, Text -> ((Pa, [Do]))
/// ```
pub fn typed_dyn_arm(sk: &Sinks, pos: &crate::lower::model::Pos_, f: &Text, acc: &Text) -> (crate::lower::model::Pa, Array<crate::lower::model::Do>) {
    (pos_pat(pos, &Array::new()), dyn_place_write(sk, f, &crate::lower::try_of(&crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("v"))), acc.clone(), Array::new()))))
}

/// ```prism
/// TypedForwardArm: fn ForDef, Ex -> ((Pa, [Do]))
/// ```
pub fn typed_forward_arm(b: &crate::lower::model::ForDef, segs: &crate::lower::model::Ex) -> (crate::lower::model::Pa, Array<crate::lower::model::Do>) {
    let row_of = crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", &b.name)))), Text::lit("borrow"), Array::new())), Text::lit("get"), Array::from(vec![crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XDecode(b.key_ty.clone(), Rc::new(crate::lower::model::Ex::XVar(Text::lit("k"))))))]))), Text::lit("cloned"), Array::new());
    (pos_pat(&b.pos, &key_tail()), Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(Text::lit("row")), row_of.clone()), crate::lower::model::Do::DoMatch(crate::lower::model::Ex::XVar(Text::lit("row")), Array::from(vec![(crate::lower::model::Pa::PaCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("row"))])), Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::try_of(&crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("row"))), Text::lit("deliver"), Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("rest")), crate::lower::model::Ex::XVar(Text::lit("v")), crate::lower::model::Ex::XCx]))))])), (crate::lower::model::Pa::PaUnit(Text::lit("None")), Array::from(vec![crate::lower::model::Do::DoReturn(crate::lower::model::Ex::XCtor(Text::lit("Err"), Array::from(vec![crate::lower::model::Ex::XCall(Text::lit("Fault::answer"), Array::from(vec![crate::lower::model::Ex::XFormatStr(Array::from(vec![crate::lower::model::Ex::XText(Text::lit("no row ")), crate::lower::model::Ex::XVar(Text::lit("k")), crate::lower::model::Ex::XText(Text::lit(" under the hosted place ")), crate::lower::model::Ex::XCtor(Text::lit("Path"), Array::from(vec![crate::lower::model::Ex::XMethod(Rc::new(segs.clone()), Text::lit("to_vec"), Array::new())]))]))]))])))]))]))]))
}

/// ```prism
/// TypedGenArm: fn GenDef -> ((Pa, [Do]))
/// ```
pub fn typed_gen_arm(gd: &crate::lower::model::GenDef) -> (crate::lower::model::Pa, Array<crate::lower::model::Do>) {
    let current = crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", &gd.name)))), Text::lit("borrow"), Array::new())));
    let is_current = crate::lower::model::Ex::XBin(Text::lit("=="), Rc::new(crate::lower::model::Ex::XBin(Text::lit("+"), Rc::new(crate::lower::model::Ex::XDeref(Rc::new(crate::lower::model::Ex::XVar(Text::lit("g"))))), Rc::new(crate::lower::model::Ex::XIndex(Nat::from(1u32))))), Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_count", &gd.name)))), Text::lit("get"), Array::new())));
    (pos_pat(&gd.pos, &gen_tail()), Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(Text::lit("row")), current.clone()), crate::lower::model::Do::DoIfLet(crate::lower::model::Pa::PaCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("row"))])), crate::lower::model::Ex::XVar(Text::lit("row")), Array::from(vec![crate::lower::model::Do::DoIf(is_current.clone(), Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::try_of(&crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("row"))), Text::lit("deliver"), Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("rest")), crate::lower::model::Ex::XVar(Text::lit("v")), crate::lower::model::Ex::XCx]))))]), Array::new())]), Array::new())]))
}

/// ```prism
/// TypedDispatch: fn Sinks, Text, Nat -> MethDef
/// ```
pub fn typed_dispatch(sk: &Sinks, name: &Text, scope: &Nat) -> crate::lower::model::MethDef {
    let wx = sk.wx.clone();
    let in_scope_fn = {
        let scope = scope.clone();
        Rc::new(move |p_: &crate::lower::model::Pos_| &p_.scope == &scope)
    };
    let (recv, param, segs, doc) = if scope > &Nat::from(0u32) {
        (crate::lower::model::Recv::RecvRc, (Text::lit("place"), crate::lower::model::OutTy::OutRef(Rc::new(crate::lower::model::OutTy::OutPath))), crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("place"))), Text::lit("segments"), Array::new()), Text::from(format!("The host at place {} answers its child's place `place` (pick HO): into the child's input method, a hold the place's element answers, or the row of a `for` or `rebuild` under it.", &crate::lower::model::place_text(&or(&index(&wx.hosts, &crate::syntax::lexer::dec(scope)), &dummy_host()).pos))))
    } else {
        (crate::lower::model::Recv::RecvOwned, (Text::lit("at"), crate::lower::model::OutTy::OutRef(Rc::new(crate::lower::model::OutTy::OutSlice(Rc::new(crate::lower::model::OutTy::OutNamed(Text::lit("Segment"), Array::new())))))), crate::lower::model::Ex::XVar(Text::lit("at")), Text::lit("A host's answer to a place of this row's own, `at` under the row (pick HO): into the input method, a hold, or a row under it."))
    };
    let answers = each(&filter(&wx.answers, &(|(pos, _, _, _): &(crate::lower::model::Pos_, Nat, crate::lower::model::OutTy, Text)| (&in_scope_fn)(pos))), &(|(pos, id, _, acc): &(crate::lower::model::Pos_, Nat, crate::lower::model::OutTy, Text)| typed_answer_arm(&wx, pos, id, acc)));
    let dyns = each(&filter(&wx.dyn_places, &(|(pos, _, _, _): &(crate::lower::model::Pos_, Text, crate::lower::model::OutTy, Text)| (&in_scope_fn)(pos))), &(|(pos, f, _, acc): &(crate::lower::model::Pos_, Text, crate::lower::model::OutTy, Text)| typed_dyn_arm(sk, pos, f, acc)));
    let rows = each(&filter(&wx.builders, &(|b: &crate::lower::model::ForDef| (&in_scope_fn)(&b.pos))), &(|b: &crate::lower::model::ForDef| typed_forward_arm(b, &segs)));
    let gens = each(&filter(&wx.gens, &(|gd: &crate::lower::model::GenDef| (&in_scope_fn)(&gd.pos))), &(|gd: &crate::lower::model::GenDef| typed_gen_arm(gd)));
    let none = (crate::lower::model::Pa::PaWild, Array::from(vec![crate::lower::model::Do::DoReturn(crate::lower::model::Ex::XCtor(Text::lit("Err"), Array::from(vec![crate::lower::model::Ex::XCall(Text::lit("Fault::answer"), Array::from(vec![crate::lower::model::Ex::XFormatStr(Array::from(vec![crate::lower::model::Ex::XText(Text::lit("no hosted place at ")), crate::lower::model::Ex::XCtor(Text::lit("Path"), Array::from(vec![crate::lower::model::Ex::XMethod(Rc::new(segs.clone()), Text::lit("to_vec"), Array::new())])), crate::lower::model::Ex::XText(Text::lit(" to answer"))]))]))])))]));
    let arms = push(&append(&append(&append(&answers, &dyns), &rows), &gens), &none);
    crate::lower::model::MethDef { name: name.clone(), recv: recv.clone(), params: Array::from(vec![param.clone(), (Text::lit("v"), crate::lower::model::OutTy::OutRef(Rc::new(crate::lower::answer_ty_value())))]), cx_: crate::lower::model::CxArg::CxMut, ret: crate::lower::model::OutTy::OutNamed(Text::lit("Done"), Array::new()), body: Array::from(vec![crate::lower::model::Do::DoMatch(segs.clone(), arms.clone())]), tail: crate::lower::model::Ex::XCtor(Text::lit("Ok"), Array::from(vec![crate::lower::model::Ex::XUnit])), doc: doc.clone() }
}

/// ```prism
/// let dummyHost
/// ```
pub fn dummy_host() -> HostDef {
    HostDef { pos: crate::lower::model::pos0(), name: Text::lit(""), scope: Nat::from(0u32) }
}

/// ```prism
/// SortNats: fn [Nat] -> [Nat]
/// ```
pub fn sort_nats(xs: &Array<Nat>) -> Array<Nat> {
    fold(xs, &Array::new(), &(|acc: &Array<Nat>, x: &Nat| append(&push(&filter(acc, &(|y: &Nat| y < x)), x), &filter(acc, &(|y: &Nat| !(y < x))))))
}

/// ```prism
/// AskWake: fn Sinks, Nat -> [Do]
/// ```
pub fn ask_wake(sk: &Sinks, h: &Nat) -> Array<crate::lower::model::Do> {
    let c = crate::lower::model::Ex::XConst(wake_const(&sk.heights, h));
    let ask = crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::lit("wakes"))), Text::lit("ask"), Array::from(vec![c.clone()])));
    let wake = crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCx), Text::lit("wake"), Array::from(vec![c.clone(), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XSelf))])));
    if sk.many {
        Array::from(vec![ask.clone(), wake.clone()])
    } else {
        Array::from(vec![wake.clone()])
    }
}

/// ```prism
/// GatherIn: fn Sinks, Gn -> MethDef
/// ```
pub fn gather_in(sk: &Sinks, g: &Gn) -> crate::lower::model::MethDef {
    let field = or(&index(&g.inputs, &Nat::from(0u32)), &Text::lit(""));
    let kt = match &g.ty {
        crate::lower::model::OutTy::OutMap(k, _) => (**k).clone(),
        _ => crate::lower::model::OutTy::OutUnit,
    };
    let vt = match &g.ty {
        crate::lower::model::OutTy::OutMap(_, v_) => (**v_).clone(),
        _ => crate::lower::model::OutTy::OutUnit,
    };
    let current = crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", &field)))), Text::lit("get"), Array::from(vec![crate::lower::model::Ex::XCx]))), Text::lit("unwrap_or_default"), Array::new());
    let collect = Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaMut(Text::lit("all")), current.clone()), crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("all"))), Text::lit("insert"), Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("k")), crate::lower::model::Ex::XVar(Text::lit("v"))]))), crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", &field)))), Text::lit("set"), Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("all")), crate::lower::model::Ex::XCx])))]);
    let body = append(&collect, &ask_wake(sk, &g.height));
    crate::lower::model::MethDef { name: Text::from(format!("{}_in", &g.name)), recv: crate::lower::model::Recv::RecvRc, params: Array::from(vec![(Text::lit("k"), kt.clone()), (Text::lit("v"), vt.clone())]), cx_: crate::lower::model::CxArg::CxMut, ret: crate::lower::model::OutTy::OutUnit, body: body.clone(), tail: crate::lower::model::Ex::XUnit, doc: Text::lit("A row's firing, gathered by its key.") }
}

/// ```prism
/// Decide: fn Gn -> Do
/// ```
pub fn decide(g: &Gn) -> crate::lower::model::Do {
    match &g.kind {
        GnKind::GnGather => crate::lower::model::Do::DoIfLet(crate::lower::model::Pa::PaCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("v"))])), crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", &or(&index(&g.inputs, &Nat::from(0u32)), &Text::lit("")))))), Text::lit("take"), Array::from(vec![crate::lower::model::Ex::XCx])), Array::from(vec![self_call(&g.name, &Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("v"))]))]), Array::new()),
        GnKind::GnMerge => merge_decide(g),
        GnKind::GnUpdated => updated_decide(g),
        GnKind::GnMergeAll => {
            let pushes = each(&g.inputs, &(|f: &Text| crate::lower::model::Do::DoIfLet(crate::lower::model::Pa::PaCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("x"))])), crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", f)))), Text::lit("take"), Array::from(vec![crate::lower::model::Ex::XCx])), Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("all"))), Text::lit("push_back"), Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("x"))])))]), Array::new())));
            let start = crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaMut(Text::lit("all"))), g.ty.clone()), crate::lower::model::Ex::XCall(Text::lit("Array::new"), Array::new()));
            let fire = crate::lower::model::Do::DoIf(crate::lower::model::Ex::XUnary(Text::lit("!"), Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("all"))), Text::lit("is_empty"), Array::new()))), Array::from(vec![self_call(&g.name, &Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("all"))]))]), Array::new());
            crate::lower::model::Do::DoBlock(push(&append(&Array::from(vec![start.clone()]), &pushes), &fire))
        },
        kind => pair_decide(g, kind),
    }
}

/// ```prism
/// UpdatedDecide: fn Gn -> Do
/// ```
pub fn updated_decide(g: &Gn) -> crate::lower::model::Do {
    crate::lower::model::Do::DoIf(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_moved", &g.name)))), Text::lit("replace"), Array::from(vec![crate::lower::model::Ex::XBool(false)])), Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(Text::lit("after")), crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCx), Text::lit("after"), Array::from(vec![crate::lower::model::Ex::XClosure(false, Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("cx"))]), Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_value", &g.name)), Array::from(vec![crate::lower::model::Ex::XCx]))))]))), self_call(&g.name, &Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("after"))]))]), Array::new())
}

/// ```prism
/// PairDecide: fn Gn, GnKind -> Do
/// ```
pub fn pair_decide(g: &Gn, kind: &GnKind) -> crate::lower::model::Do {
    let get_l = crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", &or(&index(&g.inputs, &Nat::from(0u32)), &Text::lit("")))))), Text::lit("take"), Array::from(vec![crate::lower::model::Ex::XCx]));
    let get_r = crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", &or(&index(&g.inputs, &Nat::from(1u32)), &Text::lit("")))))), Text::lit("take"), Array::from(vec![crate::lower::model::Ex::XCx]));
    let both_ = crate::lower::model::Ex::XTuple(Array::from(vec![get_l.clone(), get_r.clone()]));
    let fire_fn = {
        let g = g.clone();
        Rc::new(move |x: &crate::lower::model::Ex| Array::from(vec![self_call(&g.name, &Array::from(vec![x.clone()]))]))
    };
    let sa = crate::lower::model::Pa::PaCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("a"))]));
    let sb = crate::lower::model::Pa::PaCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("b"))]));
    let some2 = crate::lower::model::Pa::PaTuple(Array::from(vec![sa.clone(), sb.clone()]));
    let left = crate::lower::model::Pa::PaTuple(Array::from(vec![sa.clone(), crate::lower::model::Pa::PaUnit(Text::lit("None"))]));
    let right = crate::lower::model::Pa::PaTuple(Array::from(vec![crate::lower::model::Pa::PaUnit(Text::lit("None")), sb.clone()]));
    let cases = match kind {
        GnKind::GnUnion => Array::from(vec![(some2.clone(), (&fire_fn)(&crate::lower::model::Ex::XCall(Text::lit("union"), Array::from(vec![crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XVar(Text::lit("a")))), crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XVar(Text::lit("b"))))])))), (left.clone(), (&fire_fn)(&crate::lower::model::Ex::XVar(Text::lit("a")))), (right.clone(), (&fire_fn)(&crate::lower::model::Ex::XVar(Text::lit("b")))), (crate::lower::model::Pa::PaWild, Array::new())]),
        GnKind::GnBoth => Array::from(vec![(some2.clone(), (&fire_fn)(&crate::lower::model::Ex::XTuple(Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("a")), crate::lower::model::Ex::XVar(Text::lit("b"))])))), (crate::lower::model::Pa::PaWild, Array::new())]),
        _ => Array::from(vec![(left.clone(), (&fire_fn)(&crate::lower::model::Ex::XVar(Text::lit("a")))), (crate::lower::model::Pa::PaWild, Array::new())]),
    };
    crate::lower::model::Do::DoMatch(both_.clone(), cases.clone())
}

/// ```prism
/// WakeByHeight: fn [Gn], [Nat] -> Do
/// ```
pub fn wake_by_height(combs: &Array<Gn>, heights_: &Array<Nat>) -> crate::lower::model::Do {
    crate::lower::model::Do::DoMatch(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::lit("wakes"))), Text::lit("next"), Array::new()), push(&each(heights_, &(|h: &Nat| (crate::lower::model::Pa::PaConst(wake_const(heights_, h)), each(&filter(combs, &(|g: &Gn| &g.height == h)), &(|g: &Gn| decide(g)))))), &(crate::lower::model::Pa::PaWild, Array::new())))
}

/// ```prism
/// ForwardAnswer: fn ForDef -> Ex
/// ```
pub fn forward_answer(b: &crate::lower::model::ForDef) -> crate::lower::model::Ex {
    let row_of = crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", &b.name)))), Text::lit("borrow"), Array::new())), Text::lit("get"), Array::from(vec![crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XDecode(b.key_ty.clone(), Rc::new(crate::lower::model::Ex::XVar(Text::lit("k"))))))]))), Text::lit("cloned"), Array::new());
    crate::lower::model::Ex::XBlock(Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(Text::lit("row")), row_of.clone()), crate::lower::model::Do::DoIfLet(crate::lower::model::Pa::PaCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("row"))])), crate::lower::model::Ex::XVar(Text::lit("row")), Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::try_of(&crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("row"))), Text::lit("answer"), Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("rest")), crate::lower::model::Ex::XVar(Text::lit("v")), crate::lower::model::Ex::XCx]))))]), Array::new())]), Rc::new(crate::lower::model::Ex::XUnit))
}

/// ```prism
/// IsHold: fn OutTy -> Bool
/// ```
pub fn is_hold(out_ty0: &crate::lower::model::OutTy) -> bool {
    match out_ty0 {
        crate::lower::model::OutTy::OutHold(_) => true,
        other => false,
    }
}

/// ```prism
/// RowMethods: fn Wx -> [MethDef]
/// ```
pub fn row_methods(wx: &Wx) -> Array<crate::lower::model::MethDef> {
    let removes = each(&filter(&wx.places, &(|p_: &Place| emits(wx, &p_.pos))), &(|p_: &Place| crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCx), Text::lit("removed"), Array::from(vec![place_at(wx, &Text::lit("self"), &p_.pos)])))));
    let nested = append(&each(&wx.builders, &(|b: &crate::lower::model::ForDef| crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), b.name.clone())), Text::lit("borrow"), Array::new())), Text::lit("values"), Array::new())), Text::lit("for_each"), Array::from(vec![crate::lower::model::Ex::XClosure(false, Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("row"))]), Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("row"))), Text::lit("leave_row"), Array::from(vec![crate::lower::model::Ex::XCx]))))]))))), &each(&wx.gens, &(|gd: &crate::lower::model::GenDef| crate::lower::model::Do::DoIfLet(crate::lower::model::Pa::PaCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("row"))])), crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), gd.name.clone())), Text::lit("borrow"), Array::new())), Text::lit("as_ref"), Array::new()), Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("row"))), Text::lit("leave_row"), Array::from(vec![crate::lower::model::Ex::XCx])))]), Array::new()))));
    Array::from(vec![crate::lower::model::MethDef { name: Text::lit("remove_places"), recv: crate::lower::model::Recv::RecvRef, params: Array::new(), cx_: crate::lower::model::CxArg::CxMut, ret: crate::lower::model::OutTy::OutUnit, body: append(&removes, &nested), tail: crate::lower::model::Ex::XUnit, doc: Text::lit("The row left: its places are torn down.") }])
}

/// ```prism
/// GnDoc: fn Gn -> Text
/// ```
pub fn gn_doc(g: &Gn) -> Text {
    match &g.kind {
        GnKind::GnAnswer => Text::from(format!("`{}`: an answer at its place.", &g.name)),
        GnKind::GnStarted => Text::lit("`@started`, the tick after the build."),
        GnKind::GnDeferred => Text::lit("An `@Defer` firing, the tick after it was armed."),
        GnKind::GnMerge => Text::from(format!("The merge `{}`, decided in the wake.", &g.name)),
        GnKind::GnUpdated => Text::lit("`!Updated`: the dynamic's value after the tick, fired in the wake when a hold it reads was written (or a structural dynamic it reads was published, pick ST)."),
        _ => Text::from(format!("`!{}`.", &g.name)),
    }
}

/// ```prism
/// MergeDecide: fn Gn -> Do
/// ```
pub fn merge_decide(g: &Gn) -> crate::lower::model::Do {
    let call = Array::from(vec![self_call(&g.name, &Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("v"))]))]);
    let take_l = crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(Text::lit("left")), crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", &or(&index(&g.inputs, &Nat::from(0u32)), &Text::lit("")))))), Text::lit("take"), Array::from(vec![crate::lower::model::Ex::XCx])));
    let take_r = crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(Text::lit("right")), crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", &or(&index(&g.inputs, &Nat::from(1u32)), &Text::lit("")))))), Text::lit("take"), Array::from(vec![crate::lower::model::Ex::XCx])));
    let right = crate::lower::model::Do::DoIfLet(crate::lower::model::Pa::PaCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("v"))])), crate::lower::model::Ex::XVar(Text::lit("right")), call.clone(), Array::new());
    crate::lower::model::Do::DoBlock(Array::from(vec![take_l.clone(), take_r.clone(), crate::lower::model::Do::DoIfLet(crate::lower::model::Pa::PaCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("v"))])), crate::lower::model::Ex::XVar(Text::lit("left")), call.clone(), Array::from(vec![right.clone()]))]))
}

/// ```prism
/// ForLine: unbounded fn Wx, Env, Env, ?ForBinders, Expr, Block, Expr, ?Bn -> ((Wx, Wres))
/// ```
pub fn for_line(wx: &Wx, benv: &crate::lower::Env, menv: &crate::lower::Env, binders_opt: &Option<crate::syntax::ForBinders>, source: &crate::syntax::Expr, body: &crate::syntax::Block, e: &crate::syntax::Expr, bound_opt: &Option<crate::lower::Bn>) -> (Wx, Wres) {
    let lx = wx.lx.clone();
    let pos = wx.pos.clone();
    let wx1 = {
        let mut this: Wx = wx.clone();
        this.pos = crate::lower::model::next_pos(&this.pos);
        this
    };
    let (src_ex, reads) = dynamic_expr(&wx1, menv, source);
    let src_ty = crate::lower::peel(&crate::lower::type_at(&lx, &source.span));
    let (kt, vt, keyed) = match &src_ty {
        crate::check::types::Ty::TyMap(k, v_) => (crate::lower::out_ty_of(&lx, &**k), crate::lower::out_ty_of(&lx, &**v_), true),
        crate::check::types::Ty::TyArray(v_) => (crate::lower::model::OutTy::OutNat, crate::lower::out_ty_of(&lx, &**v_), false),
        _ => (crate::lower::model::OutTy::OutUnit, crate::lower::model::OutTy::OutUnit, true),
    };
    let src = if keyed {
        src_ex.clone()
    } else {
        crate::lower::model::Ex::XCall(Text::lit("indexed"), Array::from(vec![crate::lower::model::Ex::XRef(Rc::new(src_ex.clone()))]))
    };
    let base = match bound_opt {
        Some(crate::lower::Bn::BnEv(er, _)) => gn_of(&wx1, &er.node_).name.clone(),
        _ => Text::lit("rows"),
    };
    let (name, wx2a) = fresh_name(&wx1, &base);
    let src_getter = Text::from(format!("{}_source", &name));
    let src_cached = crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_cache", &src_getter)))), Text::lit("get"), Array::from(vec![crate::lower::model::Ex::XCx, crate::lower::model::Ex::XClosure(false, Array::new(), Rc::new(src.clone()))]));
    let src_def = crate::lower::model::MethDef { name: src_getter.clone(), recv: crate::lower::model::Recv::RecvRef, params: Array::new(), cx_: crate::lower::model::CxArg::CxRef, ret: crate::lower::model::OutTy::OutMap(Rc::new(kt.clone()), Rc::new(vt.clone())), body: Array::new(), tail: src_cached.clone(), doc: Text::from(format!("The source of the `for` at place {} by key, at the read point: what its builder and its rows' entries read, computed once per write behind it.", &crate::lower::model::place_text(&pos))) };
    let row_name = Text::from(format!("{}{}Row", &wx.node_, &row_suffix(wx)));
    let locals = row_locals(benv, menv, body);
    let row_fields = append(&Array::from(vec![(Text::lit("key"), kt.clone(), Text::lit("the row's key")), (Text::lit("left_entry"), crate::lower::model::OutTy::OutCell(Rc::new(crate::lower::model::OutTy::OutOpt(Rc::new(vt.clone())))), Text::lit("the entry as the tick its key left opened, kept from the row's leaving on (R8)")), (Text::lit("parent"), crate::lower::model::OutTy::OutWeak(wx.node_.clone()), Text::lit("the node of the `for`"))]), &each(&locals, &(|l: &RowLocal| (l.field.clone(), l.ty.clone(), Text::from(format!("`{}`, the block's", &l.name))))));
    let row_moves = append(&Array::from(vec![(Text::lit("key"), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(Text::lit("key"))))), (Text::lit("left_entry"), crate::lower::model::Ex::XCall(Text::lit("RefCell::new"), Array::from(vec![crate::lower::model::Ex::XNone]))), (Text::lit("parent"), crate::lower::model::Ex::XVar(Text::lit("parent")))]), &each(&locals, &(|l: &RowLocal| (l.field.clone(), crate::lower::model::Ex::XVar(l.field.clone())))));
    let row_taken = append(&append(&node_hooks(), &Array::from(vec![Text::lit("key"), Text::lit("value"), Text::lit("parent"), Text::lit("entry"), Text::lit("left_entry")])), &each(&locals, &(|l: &RowLocal| l.field.clone())));
    let row_wx0 = new_wx(&lx, &row_name, &row_fields, &Array::new(), &row_moves, &Array::from(vec![entry_getter(&src_getter, &vt)]), &map_of(vec![(Text::lit("entry"), Array::from(vec![Read::ParentRead(src_getter.clone())]))]), &row_taken, &wx.depth, &hosted_rows(wx));
    let (wx2p, row_wx0p, ports) = row_env(&wx2a, &row_wx0, menv, body);
    let wx2 = {
        let mut this: Wx = add_field(&wx2p, &Text::from(format!("{}_cache", &src_getter)), &crate::lower::model::OutTy::OutNamed(Text::lit("Cache"), Array::from(vec![crate::lower::model::OutTy::OutMap(Rc::new(kt.clone()), Rc::new(vt.clone()))])), &Text::from(format!("the source of the `for` at place {}, cached (gap SR)", &crate::lower::model::place_text(&pos))), &crate::lower::model::Ex::XCall(Text::lit("Cache::new"), Array::new()));
        this.taken = append(&this.taken, &Array::from(vec![src_getter.clone(), Text::from(format!("{}_cache", &src_getter))]));
        this.getters = push(&this.getters, &src_def);
        this.dyn_reads = insert(&this.dyn_reads, &src_getter, &reads);
        this
    };
    let key_b = crate::lower::Bn::BnLocal(crate::lower::model::Ex::XVar(Text::lit("key")), crate::lower::Holding::Owned, kt.clone());
    let key_m = crate::lower::Bn::BnLocal(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::lit("key")), crate::lower::Holding::Owned, kt.clone());
    let benv_l = events_of(&ports, &fold(&locals, &row_reads(benv, &parent_arg()), &(|en: &crate::lower::Env, l: &RowLocal| crate::lower::bind(en, &l.name, &crate::lower::Bn::BnLocal(crate::lower::model::Ex::XVar(l.field.clone()), crate::lower::Holding::Owned, l.ty.clone())))));
    let menv_l = events_of(&ports, &fold(&locals, &row_reads(menv, &parent_ref()), &(|en: &crate::lower::Env, l: &RowLocal| crate::lower::bind(en, &l.name, &crate::lower::Bn::BnLocal(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), l.field.clone()), crate::lower::Holding::Owned, l.ty.clone())))));
    let passed = append(&hosted_passed(wx), &each(&locals, &(|l: &RowLocal| l.passed.clone())));
    let row_params = append(&append(&Array::from(vec![(Text::lit("key"), kt.clone()), (Text::lit("value"), vt.clone()), (Text::lit("parent"), crate::lower::model::OutTy::OutWeak(wx.node_.clone()))]), &hosted_params(wx)), &each(&locals, &(|l: &RowLocal| (l.field.clone(), l.ty.clone()))));
    let entry_m = crate::lower::Bn::BnDyn(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XSelf), Text::lit("entry"), Array::from(vec![crate::lower::model::Ex::XCx])), Array::from(vec![Read::ParentRead(src_getter.clone())]), vt.clone());
    let (rbe, rme) = for_envs(&benv_l, &menv_l, binders_opt, &key_b, &key_m, &crate::lower::Bn::BnLocal(crate::lower::model::Ex::XVar(Text::lit("value")), crate::lower::Holding::Owned, vt.clone()), &entry_m, &vt);
    let row_wx = block_into(&row_wx0p, &rbe, &rme, body);
    let wx3 = {
        let mut this: Wx = wx2.clone();
        this.row_marks = push(&this.row_marks, &RowMarks { builder: name.clone(), reads: row_place_reads(&row_wx), wrote: row_hears(&row_wx), kind: crate::lower::model::RowKind::ForRow });
        this
    };
    let full = crate::lower::type_at(&lx, &e.span);
    let out_ty = crate::lower::out_ty_of(&lx, &crate::lower::peel(&full));
    match &row_wx.result {
        Wres::WrEv(r) => {
            let (gid, wx4) = add_gn(&wx3, &Text::from(format!("{}_all", &name)), &out_ty, &GnKind::GnGather, &Nat::from(1u32));
            let wx5 = add_field_last(&wx4, &Text::from(format!("{}_gathered", &name)), &crate::lower::model::OutTy::OutStamped(Rc::new(out_ty.clone())), &Text::lit("the rows' firings this tick, by key"), &crate::lower::model::Ex::XCall(Text::lit("Stamped::new"), Array::new()));
            let wx6 = {
                let mut this: Wx = wx5.clone();
                this.gns = each(&this.gns, &(|n: &Gn| if &n.id == &gid {
                    with_inputs(n, &Array::from(vec![Text::from(format!("{}_gathered", &name))]))
                } else {
                    n.clone()
                }));
                this
            };
            let row_done = connect(&row_wx, r, &Sk::SkUp(Text::from(format!("{}_all_in", &name))));
            let wx7 = add_builder(&wx6, &name, &pos, &kt, &vt, &row_name, &keyed, &reads, &PendingRow { wx: row_done.clone(), qk: row_name.clone(), params: row_params.clone(), gather: Some(gid.clone()) }, &passed);
            (wx7.clone(), Wres::WrEv(ev_ref_of(&wx7, &gid)))
        },
        Wres::WrDyn(ex, result_reads, rt) => {
            let gathered = Text::from(format!("{}_all", &name));
            let gathered_ty = crate::lower::model::OutTy::OutMap(Rc::new(kt.clone()), Rc::new(rt.clone()));
            let own_behind = filter(&reads_closed(&row_wx.dyn_reads, result_reads), &(|r: &Read| match r {
                Read::OwnRead(_) => true,
                Read::ParentRead(_) => false,
            }));
            let row_done = {
                let mut this: Wx = row_wx.clone();
                this.getters = push(&this.getters, &crate::lower::model::MethDef { name: Text::lit("result"), recv: crate::lower::model::Recv::RecvRef, params: Array::new(), cx_: crate::lower::model::CxArg::CxRef, ret: rt.clone(), body: Array::new(), tail: ex.clone(), doc: Text::lit("The row's result, which the block gathers by key.") });
                this.result_moved = if &len(&own_behind) > &Nat::from(0u32) {
                    Some((Text::from(format!("{}_moved", &gathered)), own_behind.clone()))
                } else {
                    None
                };
                this
            };
            let wx4 = add_builder(&wx3, &name, &pos, &kt, &vt, &row_name, &keyed, &reads, &PendingRow { wx: row_done.clone(), qk: row_name.clone(), params: row_params.clone(), gather: None }, &passed);
            let all = crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), name.clone())), Text::lit("borrow"), Array::new())), Text::lit("iter"), Array::new())), Text::lit("map"), Array::from(vec![crate::lower::model::Ex::XClosure(false, Array::from(vec![crate::lower::model::Pa::PaTuple(Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("k")), crate::lower::model::Pa::PaBind(Text::lit("row"))]))]), Rc::new(crate::lower::model::Ex::XTuple(Array::from(vec![crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(Text::lit("k")))), crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("row"))), Text::lit("result"), Array::from(vec![crate::lower::model::Ex::XCx]))]))))]))), Text::lit("collect"), Array::new());
            let what = Text::from(format!("the dynamic gathered by the `for` at place {}", &crate::lower::model::place_text(&pos)));
            let wx5 = {
                let mut this: Wx = wx4.clone();
                this.taken = append(&this.taken, &Array::from(vec![gathered.clone(), Text::from(format!("{}_now", &gathered)), Text::from(format!("{}_snap", &gathered)), Text::from(format!("{}_moved", &gathered)), Text::from(format!("{}_publish", &gathered))]));
                this.getters = append(&this.getters, &Array::from(vec![crate::lower::model::MethDef { name: Text::from(format!("{}_now", &gathered)), recv: crate::lower::model::Recv::RecvRef, params: Array::new(), cx_: crate::lower::model::CxArg::CxRef, ret: gathered_ty.clone(), body: Array::new(), tail: all.clone(), doc: Text::lit("The rows' results by key, computed live: what the snapshot of the `for`'s dynamic is taken from (pick ST).") }, snap_getter(&gathered, &gathered_ty, &Text::lit("The `for`'s dynamic, the rows' results by key, a structural dynamic (pick ST): one tick behind the rows, the snapshot of the tick before the tick the read point is after."))]));
                this.fields = push(&this.fields, &(Text::from(format!("{}_snap", &gathered)), crate::lower::model::OutTy::OutSnapshot(Rc::new(gathered_ty.clone())), Text::from(format!("the `for` at place {}'s gathered dynamic, structural: its snapshots, the rows' results and the lagged dynamic (pick ST)", &crate::lower::model::place_text(&pos)))));
                this.inits = push(&this.inits, &(Text::from(format!("{}_snap", &gathered)), crate::lower::model::Ex::XCall(Text::lit("Snapshot::new"), Array::from(vec![crate::lower::model::Ex::XStr(what.clone())]))));
                this.snaps = push(&this.snaps, &SnapDef { name: gathered.clone(), live: Text::from(format!("{}_now", &gathered)), ty: gathered_ty.clone(), eq: crate::lower::ty_has_eq(&lx, &crate::lower::peel(&full), &Array::new()), builder: name.clone(), before: false, what: what.clone() });
                this.dyn_reads = insert(&this.dyn_reads, &Text::from(format!("{}_now", &gathered)), &union_reads(&reads, &block_reads(&reads_closed(&row_wx.dyn_reads, result_reads))));
                this
            };
            (wx5.clone(), Wres::WrDyn(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XSelf), gathered.clone(), Array::from(vec![crate::lower::model::Ex::XCx])), Array::from(vec![Read::OwnRead(gathered.clone())]), gathered_ty.clone()))
        },
        _ => {
            let wx4 = add_builder(&wx3, &name, &pos, &kt, &vt, &row_name, &keyed, &reads, &PendingRow { wx: row_wx.clone(), qk: row_name.clone(), params: row_params.clone(), gather: None }, &passed);
            (wx4.clone(), Wres::WrUnit)
        },
    }
}

/// The step machine of `ForLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ForLine: unbounded fn Wx, Env, Env, ?ForBinders, Expr, Block, Expr, ?Bn -> ((Wx, Wres))
/// ```
pub struct ForLine {
    pub wx: Wx,
    pub benv: crate::lower::Env,
    pub menv: crate::lower::Env,
    pub binders_opt: Option<crate::syntax::ForBinders>,
    pub source: crate::syntax::Expr,
    pub body: crate::syntax::Block,
    pub e: crate::syntax::Expr,
    pub bound_opt: Option<crate::lower::Bn>,
}

impl prism_rtl::Job<(Wx, Wres)> for ForLine {
    fn cycle(&self) -> prism_rtl::Turn<(Wx, Wres)> {
        let wx = &self.wx;
        let benv = &self.benv;
        let menv = &self.menv;
        let binders_opt = &self.binders_opt;
        let source = &self.source;
        let body = &self.body;
        let e = &self.e;
        let bound_opt = &self.bound_opt;
        let lx = wx.lx.clone();
        let pos = wx.pos.clone();
        let wx1 = {
            let mut this: Wx = wx.clone();
            this.pos = crate::lower::model::next_pos(&this.pos);
            this
        };
        let binders_opt = binders_opt.clone();
        let bound_opt = bound_opt.clone();
        let benv = benv.clone();
        let body = body.clone();
        let e = e.clone();
        let menv = menv.clone();
        let source = source.clone();
        let wx = wx.clone();
        call_then(start_dynamic_expr(wx1.clone(), menv.clone(), source.clone()), move |dynamic_expr_138334: (crate::lower::model::Ex, Array<Read>)| {
            let (src_ex, reads) = dynamic_expr_138334;
            let src_ty = crate::lower::peel(&crate::lower::type_at(&lx, &source.span));
            let (kt, vt, keyed) = match &src_ty {
                crate::check::types::Ty::TyMap(k, v_) => (crate::lower::out_ty_of(&lx, &**k), crate::lower::out_ty_of(&lx, &**v_), true),
                crate::check::types::Ty::TyArray(v_) => (crate::lower::model::OutTy::OutNat, crate::lower::out_ty_of(&lx, &**v_), false),
                _ => (crate::lower::model::OutTy::OutUnit, crate::lower::model::OutTy::OutUnit, true),
            };
            let src = if keyed {
                src_ex.clone()
            } else {
                crate::lower::model::Ex::XCall(Text::lit("indexed"), Array::from(vec![crate::lower::model::Ex::XRef(Rc::new(src_ex.clone()))]))
            };
            let base = match &bound_opt {
                Some(crate::lower::Bn::BnEv(er, _)) => gn_of(&wx1, &er.node_).name.clone(),
                _ => Text::lit("rows"),
            };
            let (name, wx2a) = fresh_name(&wx1, &base);
            let src_getter = Text::from(format!("{}_source", &name));
            let src_cached = crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_cache", &src_getter)))), Text::lit("get"), Array::from(vec![crate::lower::model::Ex::XCx, crate::lower::model::Ex::XClosure(false, Array::new(), Rc::new(src.clone()))]));
            let src_def = crate::lower::model::MethDef { name: src_getter.clone(), recv: crate::lower::model::Recv::RecvRef, params: Array::new(), cx_: crate::lower::model::CxArg::CxRef, ret: crate::lower::model::OutTy::OutMap(Rc::new(kt.clone()), Rc::new(vt.clone())), body: Array::new(), tail: src_cached.clone(), doc: Text::from(format!("The source of the `for` at place {} by key, at the read point: what its builder and its rows' entries read, computed once per write behind it.", &crate::lower::model::place_text(&pos))) };
            let row_name = Text::from(format!("{}{}Row", &wx.node_, &row_suffix(&wx)));
            let locals = row_locals(&benv, &menv, &body);
            let row_fields = append(&Array::from(vec![(Text::lit("key"), kt.clone(), Text::lit("the row's key")), (Text::lit("left_entry"), crate::lower::model::OutTy::OutCell(Rc::new(crate::lower::model::OutTy::OutOpt(Rc::new(vt.clone())))), Text::lit("the entry as the tick its key left opened, kept from the row's leaving on (R8)")), (Text::lit("parent"), crate::lower::model::OutTy::OutWeak(wx.node_.clone()), Text::lit("the node of the `for`"))]), &each(&locals, &(|l: &RowLocal| (l.field.clone(), l.ty.clone(), Text::from(format!("`{}`, the block's", &l.name))))));
            let row_moves = append(&Array::from(vec![(Text::lit("key"), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(Text::lit("key"))))), (Text::lit("left_entry"), crate::lower::model::Ex::XCall(Text::lit("RefCell::new"), Array::from(vec![crate::lower::model::Ex::XNone]))), (Text::lit("parent"), crate::lower::model::Ex::XVar(Text::lit("parent")))]), &each(&locals, &(|l: &RowLocal| (l.field.clone(), crate::lower::model::Ex::XVar(l.field.clone())))));
            let row_taken = append(&append(&node_hooks(), &Array::from(vec![Text::lit("key"), Text::lit("value"), Text::lit("parent"), Text::lit("entry"), Text::lit("left_entry")])), &each(&locals, &(|l: &RowLocal| l.field.clone())));
            let row_wx0 = new_wx(&lx, &row_name, &row_fields, &Array::new(), &row_moves, &Array::from(vec![entry_getter(&src_getter, &vt)]), &map_of(vec![(Text::lit("entry"), Array::from(vec![Read::ParentRead(src_getter.clone())]))]), &row_taken, &wx.depth, &hosted_rows(&wx));
            let (wx2p, row_wx0p, ports) = row_env(&wx2a, &row_wx0, &menv, &body);
            let wx2 = {
                let mut this: Wx = add_field(&wx2p, &Text::from(format!("{}_cache", &src_getter)), &crate::lower::model::OutTy::OutNamed(Text::lit("Cache"), Array::from(vec![crate::lower::model::OutTy::OutMap(Rc::new(kt.clone()), Rc::new(vt.clone()))])), &Text::from(format!("the source of the `for` at place {}, cached (gap SR)", &crate::lower::model::place_text(&pos))), &crate::lower::model::Ex::XCall(Text::lit("Cache::new"), Array::new()));
                this.taken = append(&this.taken, &Array::from(vec![src_getter.clone(), Text::from(format!("{}_cache", &src_getter))]));
                this.getters = push(&this.getters, &src_def);
                this.dyn_reads = insert(&this.dyn_reads, &src_getter, &reads);
                this
            };
            let key_b = crate::lower::Bn::BnLocal(crate::lower::model::Ex::XVar(Text::lit("key")), crate::lower::Holding::Owned, kt.clone());
            let key_m = crate::lower::Bn::BnLocal(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::lit("key")), crate::lower::Holding::Owned, kt.clone());
            let benv_l = events_of(&ports, &fold(&locals, &row_reads(&benv, &parent_arg()), &(|en: &crate::lower::Env, l: &RowLocal| crate::lower::bind(en, &l.name, &crate::lower::Bn::BnLocal(crate::lower::model::Ex::XVar(l.field.clone()), crate::lower::Holding::Owned, l.ty.clone())))));
            let menv_l = events_of(&ports, &fold(&locals, &row_reads(&menv, &parent_ref()), &(|en: &crate::lower::Env, l: &RowLocal| crate::lower::bind(en, &l.name, &crate::lower::Bn::BnLocal(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), l.field.clone()), crate::lower::Holding::Owned, l.ty.clone())))));
            let passed = append(&hosted_passed(&wx), &each(&locals, &(|l: &RowLocal| l.passed.clone())));
            let row_params = append(&append(&Array::from(vec![(Text::lit("key"), kt.clone()), (Text::lit("value"), vt.clone()), (Text::lit("parent"), crate::lower::model::OutTy::OutWeak(wx.node_.clone()))]), &hosted_params(&wx)), &each(&locals, &(|l: &RowLocal| (l.field.clone(), l.ty.clone()))));
            let entry_m = crate::lower::Bn::BnDyn(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XSelf), Text::lit("entry"), Array::from(vec![crate::lower::model::Ex::XCx])), Array::from(vec![Read::ParentRead(src_getter.clone())]), vt.clone());
            let (rbe, rme) = for_envs(&benv_l, &menv_l, &binders_opt, &key_b, &key_m, &crate::lower::Bn::BnLocal(crate::lower::model::Ex::XVar(Text::lit("value")), crate::lower::Holding::Owned, vt.clone()), &entry_m, &vt);
            call_then(start_block_into(row_wx0p.clone(), rbe.clone(), rme.clone(), body.clone()), move |block_into_142143: Wx| {
                let row_wx = block_into_142143;
                let wx3 = {
                    let mut this: Wx = wx2.clone();
                    this.row_marks = push(&this.row_marks, &RowMarks { builder: name.clone(), reads: row_place_reads(&row_wx), wrote: row_hears(&row_wx), kind: crate::lower::model::RowKind::ForRow });
                    this
                };
                let full = crate::lower::type_at(&lx, &e.span);
                call_then(crate::lower::start_out_ty_of(lx.clone(), crate::lower::peel(&full)), move |out_ty_of_142382: crate::lower::model::OutTy| {
                    let out_ty = out_ty_of_142382;
                    match &row_wx.result {
                        Wres::WrEv(r) => {
                            let (gid, wx4) = add_gn(&wx3, &Text::from(format!("{}_all", &name)), &out_ty, &GnKind::GnGather, &Nat::from(1u32));
                            let wx5 = add_field_last(&wx4, &Text::from(format!("{}_gathered", &name)), &crate::lower::model::OutTy::OutStamped(Rc::new(out_ty.clone())), &Text::lit("the rows' firings this tick, by key"), &crate::lower::model::Ex::XCall(Text::lit("Stamped::new"), Array::new()));
                            let wx6 = {
                                let mut this: Wx = wx5.clone();
                                this.gns = each(&this.gns, &(|n: &Gn| if &n.id == &gid {
                                    with_inputs(n, &Array::from(vec![Text::from(format!("{}_gathered", &name))]))
                                } else {
                                    n.clone()
                                }));
                                this
                            };
                            let row_done = connect(&row_wx, r, &Sk::SkUp(Text::from(format!("{}_all_in", &name))));
                            let wx7 = add_builder(&wx6, &name, &pos, &kt, &vt, &row_name, &keyed, &reads, &PendingRow { wx: row_done.clone(), qk: row_name.clone(), params: row_params.clone(), gather: Some(gid.clone()) }, &passed);
                            prism_rtl::Turn::Finished((wx7.clone(), Wres::WrEv(ev_ref_of(&wx7, &gid))))
                        },
                        Wres::WrDyn(ex, result_reads, rt) => {
                            let gathered = Text::from(format!("{}_all", &name));
                            let gathered_ty = crate::lower::model::OutTy::OutMap(Rc::new(kt.clone()), Rc::new(rt.clone()));
                            let own_behind = filter(&reads_closed(&row_wx.dyn_reads, result_reads), &(|r: &Read| match r {
                                Read::OwnRead(_) => true,
                                Read::ParentRead(_) => false,
                            }));
                            let row_done = {
                                let mut this: Wx = row_wx.clone();
                                this.getters = push(&this.getters, &crate::lower::model::MethDef { name: Text::lit("result"), recv: crate::lower::model::Recv::RecvRef, params: Array::new(), cx_: crate::lower::model::CxArg::CxRef, ret: rt.clone(), body: Array::new(), tail: ex.clone(), doc: Text::lit("The row's result, which the block gathers by key.") });
                                this.result_moved = if &len(&own_behind) > &Nat::from(0u32) {
                                    Some((Text::from(format!("{}_moved", &gathered)), own_behind.clone()))
                                } else {
                                    None
                                };
                                this
                            };
                            let wx4 = add_builder(&wx3, &name, &pos, &kt, &vt, &row_name, &keyed, &reads, &PendingRow { wx: row_done.clone(), qk: row_name.clone(), params: row_params.clone(), gather: None }, &passed);
                            let all = crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), name.clone())), Text::lit("borrow"), Array::new())), Text::lit("iter"), Array::new())), Text::lit("map"), Array::from(vec![crate::lower::model::Ex::XClosure(false, Array::from(vec![crate::lower::model::Pa::PaTuple(Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("k")), crate::lower::model::Pa::PaBind(Text::lit("row"))]))]), Rc::new(crate::lower::model::Ex::XTuple(Array::from(vec![crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(Text::lit("k")))), crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("row"))), Text::lit("result"), Array::from(vec![crate::lower::model::Ex::XCx]))]))))]))), Text::lit("collect"), Array::new());
                            let what = Text::from(format!("the dynamic gathered by the `for` at place {}", &crate::lower::model::place_text(&pos)));
                            let wx5 = {
                                let mut this: Wx = wx4.clone();
                                this.taken = append(&this.taken, &Array::from(vec![gathered.clone(), Text::from(format!("{}_now", &gathered)), Text::from(format!("{}_snap", &gathered)), Text::from(format!("{}_moved", &gathered)), Text::from(format!("{}_publish", &gathered))]));
                                this.getters = append(&this.getters, &Array::from(vec![crate::lower::model::MethDef { name: Text::from(format!("{}_now", &gathered)), recv: crate::lower::model::Recv::RecvRef, params: Array::new(), cx_: crate::lower::model::CxArg::CxRef, ret: gathered_ty.clone(), body: Array::new(), tail: all.clone(), doc: Text::lit("The rows' results by key, computed live: what the snapshot of the `for`'s dynamic is taken from (pick ST).") }, snap_getter(&gathered, &gathered_ty, &Text::lit("The `for`'s dynamic, the rows' results by key, a structural dynamic (pick ST): one tick behind the rows, the snapshot of the tick before the tick the read point is after."))]));
                                this.fields = push(&this.fields, &(Text::from(format!("{}_snap", &gathered)), crate::lower::model::OutTy::OutSnapshot(Rc::new(gathered_ty.clone())), Text::from(format!("the `for` at place {}'s gathered dynamic, structural: its snapshots, the rows' results and the lagged dynamic (pick ST)", &crate::lower::model::place_text(&pos)))));
                                this.inits = push(&this.inits, &(Text::from(format!("{}_snap", &gathered)), crate::lower::model::Ex::XCall(Text::lit("Snapshot::new"), Array::from(vec![crate::lower::model::Ex::XStr(what.clone())]))));
                                this.snaps = push(&this.snaps, &SnapDef { name: gathered.clone(), live: Text::from(format!("{}_now", &gathered)), ty: gathered_ty.clone(), eq: crate::lower::ty_has_eq(&lx, &crate::lower::peel(&full), &Array::new()), builder: name.clone(), before: false, what: what.clone() });
                                this.dyn_reads = insert(&this.dyn_reads, &Text::from(format!("{}_now", &gathered)), &union_reads(&reads, &block_reads(&reads_closed(&row_wx.dyn_reads, result_reads))));
                                this
                            };
                            prism_rtl::Turn::Finished((wx5.clone(), Wres::WrDyn(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XSelf), gathered.clone(), Array::from(vec![crate::lower::model::Ex::XCx])), Array::from(vec![Read::OwnRead(gathered.clone())]), gathered_ty.clone())))
                        },
                        _ => {
                            let wx4 = add_builder(&wx3, &name, &pos, &kt, &vt, &row_name, &keyed, &reads, &PendingRow { wx: row_wx.clone(), qk: row_name.clone(), params: row_params.clone(), gather: None }, &passed);
                            prism_rtl::Turn::Finished((wx4.clone(), Wres::WrUnit))
                        },
                    }
                })
            })
        })
    }
}

/// `Start ForLine, x`: what the function value is when passed to `@Run`.
pub fn start_for_line(wx: Wx, benv: crate::lower::Env, menv: crate::lower::Env, binders_opt: Option<crate::syntax::ForBinders>, source: crate::syntax::Expr, body: crate::syntax::Block, e: crate::syntax::Expr, bound_opt: Option<crate::lower::Bn>) -> Rc<dyn prism_rtl::Job<(Wx, Wres)>> {
    Rc::new(ForLine { wx, benv, menv, binders_opt, source, body, e, bound_opt })
}

/// ```prism
/// EntryGetter: fn Text, OutTy -> MethDef
/// ```
pub fn entry_getter(src_getter: &Text, vt: &crate::lower::model::OutTy) -> crate::lower::model::MethDef {
    let found = crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("parent"))), src_getter.clone(), Array::from(vec![crate::lower::model::Ex::XCx]))), Text::lit("get"), Array::from(vec![crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::lit("key"))))]))), Text::lit("cloned"), Array::new());
    let opened = crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCx), Text::lit("before"), Array::from(vec![crate::lower::model::Ex::XClosure(false, Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("cx"))]), Rc::new(found.clone()))]))), Text::lit("expect"), Array::from(vec![crate::lower::model::Ex::XStr(Text::lit("a row's key is in its source as its tick opened"))]));
    let body = Array::from(vec![crate::lower::model::Do::DoIfLet(crate::lower::model::Pa::PaCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("v"))])), crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::lit("left_entry"))), Text::lit("borrow"), Array::new())), Text::lit("as_ref"), Array::new()), Array::from(vec![crate::lower::model::Do::DoReturn(crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(Text::lit("v")))))]), Array::new()), crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(Text::lit("parent")), parent_ref())]);
    let tail = crate::lower::model::Ex::XMatch(Rc::new(found.clone()), Array::from(vec![crate::lower::model::XArm { pat: crate::lower::model::Pa::PaCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("v"))])), conds: Array::new(), body: crate::lower::model::Ex::XVar(Text::lit("v")) }, crate::lower::model::XArm { pat: crate::lower::model::Pa::PaUnit(Text::lit("None")), conds: Array::new(), body: opened.clone() }]), false, vt.clone());
    crate::lower::model::MethDef { name: Text::lit("entry"), recv: crate::lower::model::Recv::RecvRef, params: Array::new(), cx_: crate::lower::model::CxArg::CxRef, ret: vt.clone(), body: body.clone(), tail: tail.clone(), doc: Text::lit("The row's entry, `$_`: the block's source at this key, at the read point; from the row's leaving on, the value as the leaving tick opened.") }
}

/// ```prism
/// AddBuilder: fn Wx, Text, Pos, OutTy, OutTy, Text, Bool, [Read], PendingRow, [Ex] -> Wx
/// ```
pub fn add_builder(wx: &Wx, name: &Text, pos: &crate::lower::model::Pos_, kt: &crate::lower::model::OutTy, vt: &crate::lower::model::OutTy, row_name: &Text, keyed: &bool, reads: &Array<Read>, waiting: &PendingRow, passed: &Array<crate::lower::model::Ex>) -> Wx {
    let wx0 = add_field_last(wx, name, &crate::lower::model::OutTy::OutCell(Rc::new(crate::lower::model::OutTy::OutMap(Rc::new(kt.clone()), Rc::new(crate::lower::model::OutTy::OutRc(Rc::new(crate::lower::model::OutTy::OutNamed(row_name.clone(), Array::new()))))))), &Text::from(format!("the rows of the `for` at place {}", &crate::lower::model::place_text(pos))), &crate::lower::model::Ex::XCall(Text::lit("RefCell::new"), Array::from(vec![crate::lower::model::Ex::XCall(Text::lit("Map::new"), Array::new())])));
    let mut this: Wx = wx0.clone();
    this.builders = push(&this.builders, &crate::lower::model::ForDef { name: name.clone(), pos: pos.clone(), at: place_at(wx, &Text::lit("self"), pos), key_ty: kt.clone(), value_ty: vt.clone(), row_node: row_name.clone(), keyed: *keyed, source: Text::from(format!("{}_source", name)), parent: crate::lower::model::Ex::XWeak(Rc::new(crate::lower::model::Ex::XSelf)), passed: passed.clone() });
    this.build_holds = union_reads(&this.build_holds, reads);
    this.pending = push(&this.pending, waiting);
    this
}

/// ```prism
/// RowPlaceReads: fn Wx -> [Read]
/// ```
pub fn row_place_reads(row_wx: &Wx) -> Array<Read> {
    fold(&row_wx.places, &Array::new(), &(|acc: &Array<Read>, pl: &Place| union_reads(acc, &block_reads(&reads_closed(&row_wx.dyn_reads, &pl.reads)))))
}

/// ```prism
/// HostedParams: fn Wx -> [((Text, OutTy))]
/// ```
pub fn hosted_params(wx: &Wx) -> Array<(Text, crate::lower::model::OutTy)> {
    match hosted_rows(wx) {
        Some(_) => Array::from(vec![(Text::lit("enclosing"), crate::lower::host_of_ty())]),
        None => Array::new(),
    }
}

/// ```prism
/// HostedPassed: fn Wx -> [Ex]
/// ```
pub fn hosted_passed(wx: &Wx) -> Array<crate::lower::model::Ex> {
    match hosted_rows(wx) {
        Some(_) => Array::from(vec![crate::lower::model::Ex::XClone(Rc::new(host_field_ex(wx, &wx.pos)))]),
        None => Array::new(),
    }
}

/// ```prism
/// RowReads: fn Env, Ex -> Env
/// ```
pub fn row_reads(env: &crate::lower::Env, pref: &crate::lower::model::Ex) -> crate::lower::Env {
    fold(&keys(&env.names), env, &(|en: &crate::lower::Env, k: &Text| 'm149659: {
        let scrutinee = &get(&env.names, k);
        if let Some(crate::lower::Bn::BnHold(f, t)) = scrutinee {
            break 'm149659 crate::lower::bind(en, k, &crate::lower::Bn::BnDyn(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(pref.clone()), f.clone())), Text::lit("get"), Array::from(vec![crate::lower::model::Ex::XCx])), Array::from(vec![Read::ParentRead(f.clone())]), t.clone()));
        }
        if let Some(crate::lower::Bn::BnDyn(crate::lower::model::Ex::XMethod(m149659_1_0_0, m, xs), _, t)) = scrutinee && let crate::lower::model::Ex::XSelf = &**m149659_1_0_0 {
            break 'm149659 crate::lower::bind(en, k, &crate::lower::Bn::BnDyn(crate::lower::model::Ex::XMethod(Rc::new(pref.clone()), m.clone(), xs.clone()), Array::from(vec![Read::ParentRead(m.clone())]), t.clone()));
        }
        en.clone()
    }))
}

/// ```prism
/// EventsOf: fn Env, Env -> Env
/// ```
pub fn events_of(ports: &crate::lower::Env, env: &crate::lower::Env) -> crate::lower::Env {
    fold(&keys(&ports.names), env, &(|en: &crate::lower::Env, k: &Text| match get(&ports.names, k) {
        Some(crate::lower::Bn::BnEv(er, t)) => crate::lower::bind(en, k, &crate::lower::Bn::BnEv(er.clone(), t.clone())),
        _ => en.clone(),
    }))
}

/// ```prism
/// BlockReads: fn [Read] -> [Read]
/// ```
pub fn block_reads(reads: &Array<Read>) -> Array<Read> {
    fold(reads, &Array::new(), &(|acc: &Array<Read>, r: &Read| match r {
        Read::ParentRead(f) => add_read(acc, &Read::OwnRead(f.clone())),
        Read::OwnRead(_) => acc.clone(),
    }))
}

/// ```prism
/// RowLocals: unbounded fn Env, Env, Block -> [RowLocal]
/// ```
pub fn row_locals(benv: &crate::lower::Env, menv: &crate::lower::Env, body: &crate::syntax::Block) -> Array<RowLocal> {
    fold(&crate::lower::read_names(&crate::check::typed::block_exprs(body)), &Array::new(), &(|acc: &Array<RowLocal>, n: &Text| match get(&menv.names, n) {
        Some(crate::lower::Bn::BnLocal(rs, mode, t)) => {
            let field = crate::lower::snake(n);
            if (((&field == &Text::lit("key")) || (&field == &Text::lit("value"))) || (&field == &Text::lit("parent"))) || (&field == &Text::lit("path")) {
                acc.clone()
            } else {
                push(acc, &RowLocal { name: n.clone(), field: field.clone(), ty: t.clone(), passed: crate::lower::own(&crate::lower::Vl::VlPlace(rs.clone(), mode.clone(), t.clone())) })
            }
        },
        _ => acc.clone(),
    }))
}

/// ```prism
/// ForEnvs: unbounded fn Env, Env, ?ForBinders, Bn, Bn, Bn, Bn, OutTy -> ((Env, Env))
/// ```
pub fn for_envs(benv: &crate::lower::Env, menv: &crate::lower::Env, binders_opt: &Option<crate::syntax::ForBinders>, key_b: &crate::lower::Bn, key_m: &crate::lower::Bn, val_b: &crate::lower::Bn, val_m: &crate::lower::Bn, vt: &crate::lower::model::OutTy) -> (crate::lower::Env, crate::lower::Env) {
    let be0 = crate::lower::bind(&crate::lower::bind(benv, &Text::lit("key"), key_b), &Text::lit("$_"), val_b);
    let me0 = crate::lower::bind(&crate::lower::bind(menv, &Text::lit("key"), key_m), &Text::lit("$_"), val_m);
    match binders_opt {
        None => (be0.clone(), me0.clone()),
        Some(fb) => match &fb.second {
            Some(second) => {
                let be1 = bind_pat(&be0, &fb.first, key_b, &crate::lower::model::Ex::XVar(Text::lit("key")), &kt0());
                let me1 = bind_pat(&me0, &fb.first, key_m, &crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::lit("key")), &kt0());
                (bind_pat(&be1, second, val_b, &crate::lower::model::Ex::XVar(Text::lit("value")), vt), bind_pat(&me1, second, val_m, &crate::lower::model::Ex::XUnit, vt))
            },
            None => (bind_pat(&be0, &fb.first, val_b, &crate::lower::model::Ex::XVar(Text::lit("value")), vt), bind_pat(&me0, &fb.first, val_m, &crate::lower::model::Ex::XUnit, vt)),
        },
    }
}

/// ```prism
/// let kt0
/// ```
pub fn kt0() -> crate::lower::model::OutTy {
    crate::lower::model::OutTy::OutUnit
}

/// ```prism
/// BindPat: fn Env, Pattern, Bn, Ex, OutTy -> Env
/// ```
pub fn bind_pat(env: &crate::lower::Env, p_: &crate::syntax::Pattern_, b: &crate::lower::Bn, whole: &crate::lower::model::Ex, t: &crate::lower::model::OutTy) -> crate::lower::Env {
    match &*p_.kind {
        crate::syntax::PatternKind::PName(n) => crate::lower::bind(env, &crate::check::env::sname_key(n), b),
        crate::syntax::PatternKind::PGroup(q) => bind_pat(env, &**q, b, whole, t),
        crate::syntax::PatternKind::PTuple(ps) => {
            let ts = match t {
                crate::lower::model::OutTy::OutTuple(xs) => xs.clone(),
                _ => Array::new(),
            };
            fold(&crate::check::errors::range0(&len(ps)), env, &(|en: &crate::lower::Env, i: &Nat| match index(ps, i) {
                Some(q) => match &*q.kind {
                    crate::syntax::PatternKind::PName(n) => crate::lower::bind(en, &crate::check::env::sname_key(n), &part_bn(b, whole, i, &or(&index(&ts, i), &crate::lower::model::OutTy::OutUnit))),
                    _ => en.clone(),
                },
                None => en.clone(),
            }))
        },
        _ => env.clone(),
    }
}

/// ```prism
/// PartBn: fn Bn, Ex, Nat, OutTy -> Bn
/// ```
pub fn part_bn(bn0: &crate::lower::Bn, whole: &crate::lower::model::Ex, i: &Nat, t: &crate::lower::model::OutTy) -> crate::lower::Bn {
    match bn0 {
        crate::lower::Bn::BnDyn(x, rds, _) => crate::lower::Bn::BnDyn(crate::lower::model::Ex::XPart(Rc::new(x.clone()), i.clone()), rds.clone(), t.clone()),
        other => crate::lower::Bn::BnLocal(crate::lower::model::Ex::XPart(Rc::new(whole.clone()), i.clone()), crate::lower::Holding::Owned, t.clone()),
    }
}

/// ```prism
/// RowSuffix: fn Wx -> Text
/// ```
pub fn row_suffix(wx: &Wx) -> Text {
    let n = &len(&wx.rows) + &len(&wx.pending);
    if &n == &Nat::from(0u32) { Text::lit("") } else { Text::from(format!("{}", &n)) }
}

/// ```prism
/// GnTyNamed: fn Wx, Text -> OutTy
/// ```
pub fn gn_ty_named(wx: &Wx, n: &Text) -> crate::lower::model::OutTy {
    fold(&wx.gns, &crate::lower::model::OutTy::OutUnit, &(|acc: &crate::lower::model::OutTy, g: &Gn| if &g.name == n { g.ty.clone() } else { acc.clone() }))
}

/// ```prism
/// RowEnv: unbounded fn Wx, Wx, Env, Block -> ((Wx, Wx, Env))
/// ```
pub fn row_env(parent: &Wx, row_wx: &Wx, menv: &crate::lower::Env, body: &crate::syntax::Block) -> (Wx, Wx, crate::lower::Env) {
    let names = crate::lower::read_names(&crate::check::typed::block_exprs(body));
    fold(&names, &(parent.clone(), row_wx.clone(), crate::lower::empty_env()), &(|(p_, r, env): &(Wx, Wx, crate::lower::Env), n: &Text| match get(&menv.names, n) {
        Some(crate::lower::Bn::BnLocal(rs, mode, t)) => (p_.clone(), r.clone(), crate::lower::bind(env, n, &crate::lower::Bn::BnLocal(over_parent(&rs), crate::lower::Holding::Owned, t.clone()))),
        Some(crate::lower::Bn::BnEv(er, t)) => {
            let pname = gn_of(p_, &er.node_).name.clone();
            let (rs, r1) = fresh_name(r, &crate::lower::snake(n));
            let (id, r2) = add_gn(&r1, &rs, &t, &GnKind::GnPort, &Nat::from(0u32));
            let r3 = {
                let mut this: Wx = r2.clone();
                this.subs = push(&this.subs, &(pname.clone(), rs.clone(), t.clone()));
                this
            };
            let p2 = if crate::check::types::has_text(&p_.ports, &pname) {
                p_.clone()
            } else {
                connect(&with_port(p_, &pname), &ev_ref_of(p_, &er.node_), &Sk::SkPort(pname.clone()))
            };
            (p2.clone(), r3.clone(), crate::lower::bind(env, n, &crate::lower::Bn::BnEv(ev_ref_of(&r3, &id), t.clone())))
        },
        Some(crate::lower::Bn::BnDyn(crate::lower::model::Ex::XMethod(recv, m, xs), _, t)) => if &*recv == &crate::lower::model::Ex::XSelf {
            (p_.clone(), r.clone(), crate::lower::bind(env, n, &crate::lower::Bn::BnDyn(crate::lower::model::Ex::XMethod(Rc::new(parent_ref()), m.clone(), xs.clone()), Array::from(vec![Read::ParentRead(m.clone())]), t.clone())))
        } else {
            (p_.clone(), r.clone(), env.clone())
        },
        Some(crate::lower::Bn::BnHold(f, t)) => (p_.clone(), r.clone(), crate::lower::bind(env, n, &crate::lower::Bn::BnDyn(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(parent_ref()), f.clone())), Text::lit("get"), Array::from(vec![crate::lower::model::Ex::XCx])), Array::from(vec![Read::ParentRead(f.clone())]), t.clone()))),
        _ => (p_.clone(), r.clone(), env.clone()),
    }))
}

/// ```prism
/// OverParent: fn Ex -> Ex
/// ```
pub fn over_parent(x: &crate::lower::model::Ex) -> crate::lower::model::Ex {
    match x {
        crate::lower::model::Ex::XSelf => parent_ref(),
        crate::lower::model::Ex::XField(y, f) => crate::lower::model::Ex::XField(Rc::new(over_parent(&**y)), f.clone()),
        crate::lower::model::Ex::XPart(y, k) => crate::lower::model::Ex::XPart(Rc::new(over_parent(&**y)), k.clone()),
        crate::lower::model::Ex::XMethod(y, m, xs) => crate::lower::model::Ex::XMethod(Rc::new(over_parent(&**y)), m.clone(), xs.clone()),
        crate::lower::model::Ex::XUpgrade(y) => crate::lower::model::Ex::XUpgrade(Rc::new(over_parent(&**y))),
        _ => crate::lower::model::Ex::XField(Rc::new(parent_ref()), crate::lower::place_stem(x)),
    }
}

/// ```prism
/// let parentRef
/// ```
pub fn parent_ref() -> crate::lower::model::Ex {
    crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XUpgrade(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::lit("parent"))))), Text::lit("expect"), Array::from(vec![crate::lower::model::Ex::XStr(Text::lit("the block outlives its rows"))]))
}

/// ```prism
/// let parentArg
/// ```
pub fn parent_arg() -> crate::lower::model::Ex {
    crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XUpgrade(Rc::new(crate::lower::model::Ex::XVar(Text::lit("parent"))))), Text::lit("expect"), Array::from(vec![crate::lower::model::Ex::XStr(Text::lit("the block outlives its rows"))]))
}

/// ```prism
/// WithPort: fn Wx, Text -> Wx
/// ```
pub fn with_port(wx: &Wx, pname: &Text) -> Wx {
    let mut this: Wx = wx.clone();
    this.ports = push(&this.ports, pname);
    this
}

/// ```prism
/// RebuildLine: unbounded fn Wx, Env, Env, Expr, Block, Expr, ?Bn -> ((Wx, Wres))
/// ```
pub fn rebuild_line(wx: &Wx, benv: &crate::lower::Env, menv: &crate::lower::Env, scrut: &crate::syntax::Expr, body: &crate::syntax::Block, e: &crate::syntax::Expr, bound_opt: &Option<crate::lower::Bn>) -> (Wx, Wres) {
    let lx = wx.lx.clone();
    let pos = wx.pos.clone();
    let wx1 = {
        let mut this: Wx = wx.clone();
        this.pos = crate::lower::model::next_pos(&this.pos);
        this
    };
    let (src_ex, reads) = dynamic_expr(&wx1, menv, scrut);
    let vt = crate::lower::out_ty_of(&lx, &crate::lower::peel(&crate::lower::type_at(&lx, &scrut.span)));
    let (name, wx2) = fresh_name(&wx1, &Text::lit("generation"));
    if gives_dynamic(&crate::lower::type_at(&lx, &e.span)) {
        rebuild_dynamic(&wx2, menv, body, &src_ex, &reads, &vt, &name, &pos)
    } else {
        {
            let (up_id, wx3) = match bound_opt {
                Some(crate::lower::Bn::BnEv(er, _)) => (er.node_.clone(), wx2.clone()),
                _ => add_gn(&wx2, &Text::from(format!("{}_fired", &name)), &crate::lower::out_ty_of(&lx, &crate::lower::peel(&crate::lower::type_at(&lx, &e.span))), &GnKind::GnNamed, &Nat::from(0u32)),
            };
            let (cases, wx4) = gen_cases(&wx3, menv, body, &vt, &name);
            let row_defs = each(&cases, &(|c: &GenCase| c.node_.clone()));
            let select = gen_select(&wx4, menv, body, &cases, &pos);
            let wx5 = {
                let mut this: Wx = wx4.clone();
                this.gens = push(&this.gens, &crate::lower::model::GenDef { name: name.clone(), pos: pos.clone(), at: place_at(wx, &Text::lit("self"), &pos), source: src_ex.clone(), value_ty: vt.clone(), select: select.clone(), transparent: false, width: Nat::from(0u32) });
                this.gen_holds = push(&this.gen_holds, &(name.clone(), reads.clone()));
                this.rows = fold(&row_defs, &this.rows, &(|acc: &Array<crate::lower::model::NodeDef>, rd: &crate::lower::model::NodeDef| append(&push(acc, rd), &rd.children)));
                this.getters = push(&this.getters, &gen_up(&name, &gn_of(&wx4, &up_id).name, &gn_of(&wx4, &up_id).ty));
                this
            };
            (wx5.clone(), Wres::WrEv(ev_ref_of(&wx5, &up_id)))
        }
    }
}

/// The step machine of `RebuildLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RebuildLine: unbounded fn Wx, Env, Env, Expr, Block, Expr, ?Bn -> ((Wx, Wres))
/// ```
pub struct RebuildLine {
    pub wx: Wx,
    pub benv: crate::lower::Env,
    pub menv: crate::lower::Env,
    pub scrut: crate::syntax::Expr,
    pub body: crate::syntax::Block,
    pub e: crate::syntax::Expr,
    pub bound_opt: Option<crate::lower::Bn>,
}

impl prism_rtl::Job<(Wx, Wres)> for RebuildLine {
    fn cycle(&self) -> prism_rtl::Turn<(Wx, Wres)> {
        let wx = &self.wx;
        let benv = &self.benv;
        let menv = &self.menv;
        let scrut = &self.scrut;
        let body = &self.body;
        let e = &self.e;
        let bound_opt = &self.bound_opt;
        let lx = wx.lx.clone();
        let pos = wx.pos.clone();
        let wx1 = {
            let mut this: Wx = wx.clone();
            this.pos = crate::lower::model::next_pos(&this.pos);
            this
        };
        let bound_opt = bound_opt.clone();
        let body = body.clone();
        let e = e.clone();
        let menv = menv.clone();
        let scrut = scrut.clone();
        let wx = wx.clone();
        call_then(start_dynamic_expr(wx1.clone(), menv.clone(), scrut.clone()), move |dynamic_expr_156454: (crate::lower::model::Ex, Array<Read>)| {
            let (src_ex, reads) = dynamic_expr_156454;
            call_then(crate::lower::start_out_ty_of(lx.clone(), crate::lower::peel(&crate::lower::type_at(&lx, &scrut.span))), move |out_ty_of_156496: crate::lower::model::OutTy| {
                let vt = out_ty_of_156496;
                let (name, wx2) = fresh_name(&wx1, &Text::lit("generation"));
                if gives_dynamic(&crate::lower::type_at(&lx, &e.span)) {
                    prism_rtl::Turn::Finished(rebuild_dynamic(&wx2, &menv, &body, &src_ex, &reads, &vt, &name, &pos))
                } else {
                    {
                        let (up_id, wx3) = match &bound_opt {
                            Some(crate::lower::Bn::BnEv(er, _)) => (er.node_.clone(), wx2.clone()),
                            _ => add_gn(&wx2, &Text::from(format!("{}_fired", &name)), &crate::lower::out_ty_of(&lx, &crate::lower::peel(&crate::lower::type_at(&lx, &e.span))), &GnKind::GnNamed, &Nat::from(0u32)),
                        };
                        let (cases, wx4) = gen_cases(&wx3, &menv, &body, &vt, &name);
                        let row_defs = each(&cases, &(|c: &GenCase| c.node_.clone()));
                        let select = gen_select(&wx4, &menv, &body, &cases, &pos);
                        let wx5 = {
                            let mut this: Wx = wx4.clone();
                            this.gens = push(&this.gens, &crate::lower::model::GenDef { name: name.clone(), pos: pos.clone(), at: place_at(&wx, &Text::lit("self"), &pos), source: src_ex.clone(), value_ty: vt.clone(), select: select.clone(), transparent: false, width: Nat::from(0u32) });
                            this.gen_holds = push(&this.gen_holds, &(name.clone(), reads.clone()));
                            this.rows = fold(&row_defs, &this.rows, &(|acc: &Array<crate::lower::model::NodeDef>, rd: &crate::lower::model::NodeDef| append(&push(acc, rd), &rd.children)));
                            this.getters = push(&this.getters, &gen_up(&name, &gn_of(&wx4, &up_id).name, &gn_of(&wx4, &up_id).ty));
                            this
                        };
                        prism_rtl::Turn::Finished((wx5.clone(), Wres::WrEv(ev_ref_of(&wx5, &up_id))))
                    }
                }
            })
        })
    }
}

/// `Start RebuildLine, x`: what the function value is when passed to `@Run`.
pub fn start_rebuild_line(wx: Wx, benv: crate::lower::Env, menv: crate::lower::Env, scrut: crate::syntax::Expr, body: crate::syntax::Block, e: crate::syntax::Expr, bound_opt: Option<crate::lower::Bn>) -> Rc<dyn prism_rtl::Job<(Wx, Wres)>> {
    Rc::new(RebuildLine { wx, benv, menv, scrut, body, e, bound_opt })
}

/// ```prism
/// GivesDynamic: fn Ty -> Bool
/// ```
pub fn gives_dynamic(t: &crate::check::types::Ty) -> bool {
    'm157715: {
        if let crate::check::types::Ty::TySig(m157715_0_0, m157715_0_1) = t && (m157715_0_0 == &Text::lit("$")) && let crate::check::types::Ty::TySig(m157715_0_1_r_0, _) = &**m157715_0_1 && (m157715_0_1_r_0 == &Text::lit("$")) {
            break 'm157715 true;
        }
        if let crate::check::types::Ty::TyAt(i, _) = t {
            break 'm157715 gives_dynamic(&**i);
        }
        false
    }
}

/// ```prism
/// RebuildDynamic: unbounded fn Wx, Env, Block, Ex, [Read], OutTy, Text, Pos -> ((Wx, Wres))
/// ```
pub fn rebuild_dynamic(wx: &Wx, menv: &crate::lower::Env, body: &crate::syntax::Block, src_ex: &crate::lower::model::Ex, reads: &Array<Read>, vt: &crate::lower::model::OutTy, name: &Text, pos: &crate::lower::model::Pos_) -> (Wx, Wres) {
    let row_name = Text::from(format!("{}Gen{}", &wx.node_, &row_suffix(wx)));
    let whole = gen_row_of(wx, menv, body, vt, &row_name, name);
    match &whole.dyn_result {
        None => {
            let wx2 = {
                let mut this: Wx = whole.parent.clone();
                this.build = push(&this.build, &crate::lower::refusal_do(&Text::lit("a `rebuild` whose generation gives a dynamic it does not lower")));
                this
            };
            (wx2.clone(), Wres::WrUnit)
        },
        Some(rt) => {
            let dyn_ty = crate::lower::model::OutTy::OutDyn(Rc::new(rt.clone()));
            let result = Text::from(format!("{}_result", name));
            let live = Text::from(format!("{}_live", &result));
            let what = Text::from(format!("the dynamic of the `rebuild` at place {}", &crate::lower::model::place_text(pos)));
            let tail = append(&append(&Array::from(vec![crate::lower::model::Ex::XWeak(Rc::new(crate::lower::model::Ex::XSelf))]), &hosted_passed(wx)), &Array::from(vec![crate::lower::model::Ex::XCx]));
            let built = crate::lower::try_of(&crate::lower::model::Ex::XCall(Text::from(format!("{}::build", &whole.node_.name)), append(&Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("path")), crate::lower::model::Ex::XVar(Text::lit("value"))]), &tail)));
            let kept = crate::lower::model::Do::DoAssign(crate::lower::model::Ex::XDeref(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), live.clone())), Text::lit("borrow_mut"), Array::new()))), crate::lower::model::Ex::XCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("row"))), Text::lit("result_dynamic"), Array::new())])));
            let marked = crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_snap", &result)))), Text::lit("mark"), Array::from(vec![crate::lower::model::Ex::XCx])));
            let select = crate::lower::model::Ex::XBlock(Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(Text::lit("row")), built.clone()), kept.clone(), marked.clone()]), Rc::new(crate::lower::model::Ex::XVar(Text::lit("row"))));
            let current = crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", &live)))), Text::lit("borrow"), Array::new())))), Text::lit("expect"), Array::from(vec![crate::lower::model::Ex::XStr(Text::lit("a `rebuild` has a generation from its build on"))]));
            let wx2 = {
                let mut this: Wx = whole.parent.clone();
                this.gens = push(&this.gens, &crate::lower::model::GenDef { name: name.clone(), pos: pos.clone(), at: place_at(wx, &Text::lit("self"), pos), source: src_ex.clone(), value_ty: vt.clone(), select: select.clone(), transparent: false, width: Nat::from(0u32) });
                this.gen_holds = push(&this.gen_holds, &(name.clone(), reads.clone()));
                this.rows = append(&push(&this.rows, &whole.node_), &whole.node_.children);
                this.taken = append(&this.taken, &Array::from(vec![result.clone(), live.clone(), Text::from(format!("{}_now", &result)), Text::from(format!("{}_snap", &result)), Text::from(format!("{}_publish", &result)), Text::from(format!("{}_moved", &result))]));
                this.fields = append(&this.fields, &Array::from(vec![(live.clone(), crate::lower::model::OutTy::OutCell(Rc::new(crate::lower::model::OutTy::OutOpt(Rc::new(dyn_ty.clone())))), Text::lit("the current generation's result, which the snapshot of the `rebuild`'s dynamic is taken from")), (Text::from(format!("{}_snap", &result)), crate::lower::model::OutTy::OutSnapshot(Rc::new(dyn_ty.clone())), Text::from(format!("the `rebuild` at place {}'s dynamic, structural: its snapshots, the generations' results and the lagged dynamic (pick ST)", &crate::lower::model::place_text(pos))))]));
                this.moves = push(&this.moves, &(live.clone(), crate::lower::model::Ex::XCall(Text::lit("RefCell::new"), Array::from(vec![crate::lower::model::Ex::XNone]))));
                this.inits = push(&this.inits, &(Text::from(format!("{}_snap", &result)), crate::lower::model::Ex::XCall(Text::lit("Snapshot::new"), Array::from(vec![crate::lower::model::Ex::XStr(what.clone())]))));
                this.getters = append(&this.getters, &Array::from(vec![crate::lower::model::MethDef { name: Text::from(format!("{}_now", &result)), recv: crate::lower::model::Recv::RecvRef, params: Array::new(), cx_: crate::lower::model::CxArg::CxRef, ret: dyn_ty.clone(), body: Array::new(), tail: current.clone(), doc: Text::lit("The current generation's result: what the snapshot of the `rebuild`'s dynamic is taken from (pick ST).") }, snap_getter(&result, &dyn_ty, &Text::lit("The `rebuild`'s dynamic, its generation's result, a structural dynamic (pick ST): one tick behind the generations, the snapshot of the tick before the tick the read point is after."))]));
                this.snaps = push(&this.snaps, &SnapDef { name: result.clone(), live: Text::from(format!("{}_now", &result)), ty: dyn_ty.clone(), eq: false, builder: name.clone(), before: false, what: what.clone() });
                this
            };
            (wx2.clone(), Wres::WrDyn(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XSelf), result.clone(), Array::from(vec![crate::lower::model::Ex::XCx])), Array::from(vec![Read::OwnRead(result.clone())]), dyn_ty.clone()))
        },
    }
}

/// ```prism
/// ClauseWidgetLine: unbounded fn Wx, Env, Expr, Block, Text, ValInfo, Expr -> ((Wx, Wres))
/// ```
pub fn clause_widget_line(wx: &Wx, menv: &crate::lower::Env, scrut: &crate::syntax::Expr, call: &crate::syntax::Block, qk: &Text, v_: &crate::check::env::ValInfo, e: &crate::syntax::Expr) -> (Wx, Wres) {
    let lx = wx.lx.clone();
    let pos = wx.pos.clone();
    let (src_ex, reads) = dynamic_expr(wx, menv, scrut);
    let vt = crate::lower::out_ty_of(&lx, &crate::lower::peel(&crate::lower::type_at(&lx, &scrut.span)));
    let (name, wx1) = fresh_name(wx, &Text::lit("generation"));
    let (up_id, wx2) = add_gn(&wx1, &Text::from(format!("{}_fired", &name)), &crate::lower::out_ty_of(&lx, &crate::lower::out_of(&crate::lower::type_at(&lx, &e.span))), &GnKind::GnNamed, &Nat::from(0u32));
    let clauses = crate::lower::clauses_of(&lx.g, qk);
    let row_name = Text::from(format!("{}Gen{}", &wx.node_, &row_suffix(wx)));
    let (rows, wx3) = run_to_end(fold_job(crate::check::errors::range0(&len(&clauses)), (Array::new(), wx2.clone()), {
        let clauses = clauses.clone();
        let menv = menv.clone();
        let v_ = v_.clone();
        let row_name = row_name.clone();
        let name = name.clone();
        Rc::new(move |(p0, p1): ((Array<ClauseRow>, Wx), Nat)| {
            let clauses = clauses.clone();
            let menv = menv.clone();
            let v_ = v_.clone();
            let row_name = row_name.clone();
            let name = name.clone();
            entered(once_job(move || {
                let (acc, w) = p0;
                let i = p1;
                {
                    let c = or(&index(&clauses, &i), &crate::lower::dummy_clause());
                    let cr = clause_row_of(&w, &menv, &c, &v_, &Text::from(format!("{}{}", &row_name, &i)), &name, &true);
                    prism_rtl::Turn::Finished((push(&acc, &cr), cr.parent.clone()))
                }
            }))
        }) as Rc<dyn Fn(((Array<ClauseRow>, Wx), Nat)) -> Rc<dyn prism_rtl::Job<(Array<ClauseRow>, Wx)>>>
    }));
    let width = fold(&rows, &Nat::from(0u32), &(|acc: &Nat, cr: &ClauseRow| max(acc, &cr.width)));
    let cases = each(&rows, &(|cr: &ClauseRow| cr.case.clone()));
    if is_hosted_scope(wx) {
        {
            let wx4 = {
                let mut this: Wx = wx3.clone();
                this.build = push(&this.build, &crate::lower::refusal_do(&Text::lit("a widget of several clauses in a static position of a hosted scope")));
                this
            };
            (wx4.clone(), Wres::WrUnit)
        }
    } else {
        {
            let select = gen_select(&wx3, menv, call, &cases, &pos);
            let wx4 = {
                let mut this: Wx = wx3.clone();
                this.pos = crate::lower::model::Pos_ { scope: pos.scope.clone(), at: &pos.at + &width };
                this.gens = push(&this.gens, &crate::lower::model::GenDef { name: name.clone(), pos: pos.clone(), at: place_at(wx, &Text::lit("self"), &pos), source: src_ex.clone(), value_ty: vt.clone(), select: select.clone(), transparent: true, width: width.clone() });
                this.gen_holds = push(&this.gen_holds, &(name.clone(), reads.clone()));
                this.rows = fold(&cases, &this.rows, &(|acc: &Array<crate::lower::model::NodeDef>, gc: &GenCase| append(&push(acc, &gc.node_), &gc.node_.children)));
                this.getters = push(&this.getters, &gen_up(&name, &gn_of(&wx3, &up_id).name, &gn_of(&wx3, &up_id).ty));
                this
            };
            (wx4.clone(), Wres::WrEv(ev_ref_of(&wx4, &up_id)))
        }
    }
}

/// ```prism
/// IsHostedScope: fn Wx -> Bool
/// ```
pub fn is_hosted_scope(wx: &Wx) -> bool {
    (&wx.pos.scope > &Nat::from(0u32)) || is_some(&wx.hosted_by)
}

/// ```prism
/// IsSome: fn ?a -> Bool
/// ```
pub fn is_some<A: Clone + 'static>(opt0: &Option<A>) -> bool {
    match opt0 {
        Some(_) => true,
        None => false,
    }
}

/// ```prism
/// GenCases: unbounded fn Wx, Env, Block, OutTy, Text -> (([GenCase], Wx))
/// ```
pub fn gen_cases(wx: &Wx, menv: &crate::lower::Env, body: &crate::syntax::Block, vt: &crate::lower::model::OutTy, name: &Text) -> (Array<GenCase>, Wx) {
    let lx = wx.lx.clone();
    let row_name = Text::from(format!("{}Gen{}", &wx.node_, &row_suffix(wx)));
    match clause_call(&lx, body) {
        Some((qk, args)) => {
            let clauses = crate::lower::clauses_of(&lx.g, &qk);
            let v_ = crate::lower::val_of(&lx, &qk);
            run_to_end(fold_job(crate::check::errors::range0(&len(&clauses)), (Array::new(), wx.clone()), {
                let clauses = clauses.clone();
                let menv = menv.clone();
                let v_ = v_.clone();
                let row_name = row_name.clone();
                let name = name.clone();
                Rc::new(move |(p0, p1): ((Array<GenCase>, Wx), Nat)| {
                    let clauses = clauses.clone();
                    let menv = menv.clone();
                    let v_ = v_.clone();
                    let row_name = row_name.clone();
                    let name = name.clone();
                    entered(once_job(move || {
                        let (acc, w) = p0;
                        let i = p1;
                        {
                            let c = or(&index(&clauses, &i), &crate::lower::dummy_clause());
                            let cr = clause_row_of(&w, &menv, &c, &v_, &Text::from(format!("{}{}", &row_name, &i)), &name, &false);
                            prism_rtl::Turn::Finished((push(&acc, &cr.case), cr.parent.clone()))
                        }
                    }))
                }) as Rc<dyn Fn(((Array<GenCase>, Wx), Nat)) -> Rc<dyn prism_rtl::Job<(Array<GenCase>, Wx)>>>
            }))
        },
        None => {
            let whole = gen_row_of(wx, menv, body, vt, &row_name, name);
            (Array::from(vec![GenCase { node_: whole.node_.clone(), params: Array::from(vec![(Text::lit("value"), vt.clone())]), pat: crate::lower::model::Pa::PaWild, conds: Array::new(), passed: Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("value"))]) }]), whole.parent.clone())
        },
    }
}

/// ```prism
/// ?ClauseCall: fn Lx, Block -> ?((Text, [Arg]))
/// ```
pub fn clause_call(lx: &crate::lower::Lx, body: &crate::syntax::Block) -> Option<(Text, Array<crate::syntax::Arg>)> {
    'm165664: {
        let scrutinee = &body.stmts;
        if let m165664_0 = scrutinee && (m165664_0.len() == 1) && let Some(st) = index(m165664_0, &Nat::from(0u32)) {
            break 'm165664 match &st.kind {
                crate::syntax::StmtKind::SExpr(x) => clause_call_x(lx, x),
                crate::syntax::StmtKind::SIgnore(x) => clause_call_x(lx, x),
                _ => None,
            };
        }
        None
    }
}

/// ```prism
/// ?ClauseCallX: fn Lx, Expr -> ?((Text, [Arg]))
/// ```
pub fn clause_call_x(lx: &crate::lower::Lx, x: &crate::syntax::Expr) -> Option<(Text, Array<crate::syntax::Arg>)> {
    match &*x.kind {
        crate::syntax::ExprKind::ECall(c, args, _, _) => {
            let qk = crate::lower::blueprint_qk(lx, &**c);
            if &len(&crate::lower::clauses_of(&lx.g, &qk)) > &Nat::from(1u32) {
                Some((qk.clone(), args.clone()))
            } else {
                None
            }
        },
        _ => None,
    }
}

/// ```prism
/// ClauseRowOf: unbounded fn Wx, Env, FnClause, ValInfo, Text, Text, Bool -> ClauseRow
/// ```
pub fn clause_row_of(wx: &Wx, menv: &crate::lower::Env, c: &crate::syntax::FnClause, v_: &crate::check::env::ValInfo, row_name: &Text, gen_name: &Text, transparent: &bool) -> ClauseRow {
    let up_name = Text::from(format!("{}_up", gen_name));
    let lx = wx.lx.clone();
    let lxc = crate::lower::in_module_at(&lx, &v_.file, &v_.home, &lx.site);
    let ptys = match &v_.scheme.ty {
        crate::check::types::Ty::TyFn(_, ps, _) => ps.clone(),
        _ => Array::new(),
    };
    let pos = run_to_end(each_job(crate::check::errors::range0(&len(&c.params)), {
        let lxc = lxc.clone();
        let c = c.clone();
        let ptys = ptys.clone();
        Rc::new(move |p0: Nat| {
            let lxc = lxc.clone();
            let c = c.clone();
            let ptys = ptys.clone();
            entered(once_job(move || {
                let i = p0;
                prism_rtl::Turn::More(Rc::new(crate::lower::RustPat { lx: lxc.clone(), p_: or(&index(&c.params, &i), &crate::lower::dummy_pat()), ty: or(&index(&ptys, &i), &crate::check::types::Ty::TyErr), mode: crate::lower::Holding::ByRef, fresh: Text::from(format!("c{}", &i)) }))
            }))
        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<crate::lower::PatOut>>>
    }));
    let pa = crate::lower::model::Pa::PaTuple(each(&pos, &(|o: &crate::lower::PatOut| o.pa.clone())));
    let binds = fold(&pos, &Map::new(), &(|m: &Map<Text, crate::lower::Bn>, o: &crate::lower::PatOut| fold(&o.binds, m, &(|m2: &Map<Text, crate::lower::Bn>, (n, b): &(Text, crate::lower::Bn)| insert(m2, n, b)))));
    let binders = filter(&run_to_end(fold_job(c.params.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<(Text, crate::syntax::Range)>, crate::syntax::Pattern_)| entered(once_job(move || {
        let acc = p0;
        let p_ = p1;
        call_then(crate::check::env::start_pattern_binders(p_.clone()), move |pattern_binders_167177: Array<(Text, crate::syntax::Range)>| prism_rtl::Turn::Finished(append(&acc, &pattern_binders_167177)))
    }))) as Rc<dyn Fn((Array<(Text, crate::syntax::Range)>, crate::syntax::Pattern_)) -> Rc<dyn prism_rtl::Job<Array<(Text, crate::syntax::Range)>>>>)), &(|(bn, _): &(Text, crate::syntax::Range)| crate::check::env::has_key(&binds, bn)));
    let fields = run_to_end(each_job(binders.clone(), {
        let lxc = lxc.clone();
        Rc::new(move |p0: (Text, crate::syntax::Range)| {
            let lxc = lxc.clone();
            entered(once_job(move || {
                let (bn, r) = p0;
                call_then(crate::lower::start_out_ty_of(lxc.clone(), crate::lower::peel(&crate::lower::binder_ty(&lxc, &r))), move |out_ty_of_167291: crate::lower::model::OutTy| prism_rtl::Turn::Finished((crate::lower::snake(&bn), out_ty_of_167291, bn.clone())))
            }))
        }) as Rc<dyn Fn((Text, crate::syntax::Range)) -> Rc<dyn prism_rtl::Job<(Text, crate::lower::model::OutTy, Text)>>>
    }));
    let row_fields = push(&each(&fields, &(|(f, t, bn): &(Text, crate::lower::model::OutTy, Text)| (f.clone(), t.clone(), Text::from(format!("`{}`", bn))))), &(Text::lit("parent"), crate::lower::model::OutTy::OutWeak(wx.node_.clone()), Text::lit("the node of the `rebuild`")));
    let row_inits = each(&fields, &(|(f, _, _): &(Text, crate::lower::model::OutTy, Text)| (f.clone(), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(f.clone()))))));
    let row_taken = append(&node_hooks(), &push(&each(&fields, &(|(f, _, _): &(Text, crate::lower::model::OutTy, Text)| f.clone())), &Text::lit("parent")));
    let r00 = new_wx(&lxc, row_name, &row_fields, &row_inits, &Array::from(vec![(Text::lit("parent"), crate::lower::model::Ex::XVar(Text::lit("parent")))]), &Array::new(), &Map::new(), &row_taken, &wx.depth, &hosted_rows(wx));
    let r0 = if *transparent {
        {
            let mut this: Wx = r00.clone();
            this.pos = wx.pos.clone();
            this
        }
    } else {
        r00.clone()
    };
    let body = match &c.body {
        crate::syntax::FnBody::BodyBlock(b) => b.clone(),
        crate::syntax::FnBody::BodyExpr(x) => crate::syntax::Block { stmts: Array::from(vec![crate::syntax::Stmt { kind: crate::syntax::StmtKind::SExpr(x.clone()), span: x.span.clone() }]), inline: true, span: x.span.clone() },
    };
    let (p1, r1, ports) = row_env(wx, &r0, menv, &body);
    let (be, me) = fold(&fields, &(crate::lower::empty_env(), crate::lower::empty_env()), &(|(b, m): &(crate::lower::Env, crate::lower::Env), (f, t, bn): &(Text, crate::lower::model::OutTy, Text)| bind_plain(b, m, bn, f, t)));
    let r2 = block_into(&r1, &be, &me, &body);
    let r3 = match &r2.result {
        Wres::WrEv(r) => connect(&r2, r, &Sk::SkUp(up_name.clone())),
        _ => r2.clone(),
    };
    let node_ = finish_node(&r3, row_name, &append(&push(&each(&fields, &(|(f, t, _): &(Text, crate::lower::model::OutTy, Text)| (f.clone(), t.clone()))), &(Text::lit("parent"), crate::lower::model::OutTy::OutWeak(wx.node_.clone()))), &hosted_params(wx)), &true);
    let p2 = gen_marked(&p1, gen_name, &r3);
    let passed = each(&fields, &(|(f, t, bn): &(Text, crate::lower::model::OutTy, Text)| match get(&binds, bn) {
        Some(crate::lower::Bn::BnLocal(rs, mode, bt)) => crate::lower::own(&crate::lower::Vl::VlPlace(rs.clone(), mode.clone(), bt.clone())),
        _ => crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(f.clone()))),
    }));
    ClauseRow { case: GenCase { node_: node_.clone(), params: each(&fields, &(|(f, t, _): &(Text, crate::lower::model::OutTy, Text)| (f.clone(), t.clone()))), pat: pa.clone(), conds: fold(&pos, &Array::new(), &(|acc: &Array<crate::lower::model::Cc>, o: &crate::lower::PatOut| append(acc, &o.conds))), passed: passed.clone() }, parent: p2.clone(), width: or(&(&r2.pos.at).checked_sub(&r0.pos.at), &Nat::from(0u32)) }
}

/// ```prism
/// GenRowOf: unbounded fn Wx, Env, Block, OutTy, Text, Text -> GenRow
/// ```
pub fn gen_row_of(wx: &Wx, menv: &crate::lower::Env, body: &crate::syntax::Block, vt: &crate::lower::model::OutTy, row_name: &Text, gen_name: &Text) -> GenRow {
    let lx = wx.lx.clone();
    let up_name = Text::from(format!("{}_up", gen_name));
    let r0 = new_wx(&lx, row_name, &Array::from(vec![(Text::lit("value"), vt.clone(), Text::lit("the generation's value, `_`")), (Text::lit("parent"), crate::lower::model::OutTy::OutWeak(wx.node_.clone()), Text::lit("the node of the `rebuild`"))]), &Array::from(vec![(Text::lit("value"), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(Text::lit("value")))))]), &Array::from(vec![(Text::lit("parent"), crate::lower::model::Ex::XVar(Text::lit("parent")))]), &Array::new(), &Map::new(), &append(&node_hooks(), &Array::from(vec![Text::lit("value"), Text::lit("parent"), Text::lit("result"), Text::lit("result_dynamic")])), &wx.depth, &hosted_rows(wx));
    let (p1, r1, ports) = row_env(wx, &r0, menv, body);
    let be = crate::lower::bind(&build_spelling(&ports), &Text::lit("_"), &crate::lower::Bn::BnLocal(crate::lower::model::Ex::XVar(Text::lit("value")), crate::lower::Holding::Owned, vt.clone()));
    let me = crate::lower::bind(&ports, &Text::lit("_"), &crate::lower::Bn::BnLocal(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::lit("value")), crate::lower::Holding::Owned, vt.clone()));
    let r2 = block_into(&r1, &be, &me, body);
    let (r3, dyn_result_opt) = match &r2.result {
        Wres::WrEv(r) => (connect(&r2, r, &Sk::SkUp(up_name.clone())), None),
        Wres::WrDyn(ex, result_reads, rt) => (gen_result(&r2, gen_name, ex, result_reads, rt), Some(rt.clone())),
        _ => (r2.clone(), None),
    };
    GenRow { node_: finish_node(&r3, row_name, &append(&Array::from(vec![(Text::lit("value"), vt.clone()), (Text::lit("parent"), crate::lower::model::OutTy::OutWeak(wx.node_.clone()))]), &hosted_params(wx)), &true), parent: gen_marked(&p1, gen_name, &r3), dyn_result: dyn_result_opt.clone() }
}

/// ```prism
/// GenResult: fn Wx, Text, Ex, [Read], OutTy -> Wx
/// ```
pub fn gen_result(r: &Wx, gen_name: &Text, ex: &crate::lower::model::Ex, result_reads: &Array<Read>, rt: &crate::lower::model::OutTy) -> Wx {
    let own_behind = filter(&reads_closed(&r.dyn_reads, result_reads), &(|rd: &Read| match rd {
        Read::OwnRead(_) => true,
        Read::ParentRead(_) => false,
    }));
    let made = crate::lower::model::Ex::XCall(Text::lit("Dynamic::of"), Array::from(vec![crate::lower::model::Ex::XClosure(true, Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("cx"))]), Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("me"))), Text::lit("result"), Array::from(vec![crate::lower::model::Ex::XCx])))), crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XCall(Text::lit("Rc::new"), Array::from(vec![crate::lower::model::Ex::XCall(Text::lit("Port::new"), Array::new())]))))]));
    let doc = Text::from(format!("The generation's result as a dynamic, which the block keeps while the generation is current; the block hears it move through `{}_result_moved`, not through the dynamic's port.", gen_name));
    let mut this: Wx = r.clone();
    this.getters = append(&this.getters, &Array::from(vec![crate::lower::model::MethDef { name: Text::lit("result"), recv: crate::lower::model::Recv::RecvRef, params: Array::new(), cx_: crate::lower::model::CxArg::CxRef, ret: rt.clone(), body: Array::new(), tail: ex.clone(), doc: Text::lit("The generation's result, which the `rebuild` hands back.") }, crate::lower::model::MethDef { name: Text::lit("result_dynamic"), recv: crate::lower::model::Recv::RecvRc, params: Array::new(), cx_: crate::lower::model::CxArg::CxNone, ret: crate::lower::model::OutTy::OutDyn(Rc::new(rt.clone())), body: Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(Text::lit("me")), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XSelf)))]), tail: made.clone(), doc: doc.clone() }]));
    this.result_moved = if &len(&own_behind) > &Nat::from(0u32) {
        Some((Text::from(format!("{}_result_moved", gen_name)), own_behind.clone()))
    } else {
        None
    };
    this
}

/// ```prism
/// GenMarked: fn Wx, Text, Wx -> Wx
/// ```
pub fn gen_marked(parent: &Wx, gen_name: &Text, row_wx: &Wx) -> Wx {
    let reads = row_place_reads(row_wx);
    if &len(&reads) == &Nat::from(0u32) {
        parent.clone()
    } else {
        {
            let mut this: Wx = parent.clone();
            this.row_marks = push(&this.row_marks, &RowMarks { builder: gen_name.clone(), reads: reads.clone(), wrote: Array::new(), kind: crate::lower::model::RowKind::GenerationRow });
            this
        }
    }
}

/// ```prism
/// BuildSpelling: fn Env -> Env
/// ```
pub fn build_spelling(env: &crate::lower::Env) -> crate::lower::Env {
    fold(&keys(&env.names), env, &(|en: &crate::lower::Env, k: &Text| match get(&env.names, k) {
        Some(crate::lower::Bn::BnLocal(rs, mode, t)) => match crate::lower::through_parent(&rs) {
            Some(x) => crate::lower::bind(en, k, &crate::lower::Bn::BnLocal(x.clone(), mode.clone(), t.clone())),
            None => en.clone(),
        },
        Some(crate::lower::Bn::BnDyn(crate::lower::model::Ex::XMethod(rs, m, xs), ds, t)) => match crate::lower::through_parent(&*rs) {
            Some(x) => crate::lower::bind(en, k, &crate::lower::Bn::BnDyn(crate::lower::model::Ex::XMethod(Rc::new(x.clone()), m.clone(), xs.clone()), ds.clone(), t.clone())),
            None => en.clone(),
        },
        _ => en.clone(),
    }))
}

/// ```prism
/// GenSelect: unbounded fn Wx, Env, Block, [GenCase], Pos -> Ex
/// ```
pub fn gen_select(wx: &Wx, menv: &crate::lower::Env, body: &crate::syntax::Block, cases: &Array<GenCase>, pos: &crate::lower::model::Pos_) -> crate::lower::model::Ex {
    let tail = append(&append(&Array::from(vec![crate::lower::model::Ex::XWeak(Rc::new(crate::lower::model::Ex::XSelf))]), &hosted_passed(wx)), &Array::from(vec![crate::lower::model::Ex::XCx]));
    match clause_call(&wx.lx, body) {
        None => match index(cases, &Nat::from(0u32)) {
            Some(c) => crate::lower::try_of(&crate::lower::model::Ex::XCall(Text::from(format!("{}::build", &c.node_.name)), append(&Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("path")), crate::lower::model::Ex::XVar(Text::lit("value"))]), &tail))),
            None => crate::lower::refusal(&Text::lit("a `rebuild` with no generation")),
        },
        Some((qk, args)) => {
            let env = crate::lower::bind(menv, &Text::lit("_"), &crate::lower::Bn::BnLocal(crate::lower::model::Ex::XVar(Text::lit("value")), crate::lower::Holding::Owned, crate::lower::model::OutTy::OutUnit));
            let scrut = crate::lower::model::Ex::XTuple(run_to_end(each_job(args.clone(), {
                let wx = wx.clone();
                let env = env.clone();
                Rc::new(move |p0: crate::syntax::Arg| {
                    let wx = wx.clone();
                    let env = env.clone();
                    entered(once_job(move || {
                        let a = p0;
                        prism_rtl::Turn::More(Rc::new(crate::lower::Argument { lx: wx.lx.clone(), env: env.clone(), e: a.value.clone() }))
                    }))
                }) as Rc<dyn Fn(crate::syntax::Arg) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
            })));
            let arms = each(cases, &(|c: &GenCase| {
                let made = crate::lower::try_of(&crate::lower::model::Ex::XCall(Text::from(format!("{}::build", &c.node_.name)), append(&append(&Array::from(vec![crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(Text::lit("path"))))]), &c.passed), &tail)));
                crate::lower::model::XArm { pat: c.pat.clone(), conds: c.conds.clone(), body: crate::lower::model::Ex::XCast(Rc::new(made.clone()), crate::lower::model::OutTy::OutObj(Rc::new(crate::lower::model::OutTy::OutNamed(Text::lit("Row"), Array::new())))) }
            }));
            crate::lower::own(&crate::lower::arms_value(&scrut, &arms, &Text::lit("'select"), &crate::lower::model::OutTy::OutObj(Rc::new(crate::lower::model::OutTy::OutNamed(Text::lit("Row"), Array::new())))))
        },
    }
}

/// ```prism
/// GenUp: fn Text, Text, OutTy -> MethDef
/// ```
pub fn gen_up(name: &Text, up_name: &Text, t: &crate::lower::model::OutTy) -> crate::lower::model::MethDef {
    crate::lower::model::MethDef { name: Text::from(format!("{}_up", name)), recv: crate::lower::model::Recv::RecvRc, params: Array::from(vec![(Text::lit("v"), t.clone())]), cx_: crate::lower::model::CxArg::CxMut, ret: crate::lower::model::OutTy::OutUnit, body: Array::from(vec![self_call(up_name, &Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("v"))]))]), tail: crate::lower::model::Ex::XUnit, doc: Text::lit("The current generation's result fires the `rebuild`'s.") }
}

/// ```prism
/// GenForwards: fn GenDef -> [((Pa, Ex))]
/// ```
pub fn gen_forwards(gd: &crate::lower::model::GenDef) -> Array<(crate::lower::model::Pa, crate::lower::model::Ex)> {
    if gd.transparent {
        each(&crate::check::errors::range0(&gd.width), &(|i: &Nat| {
            let current = crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", &gd.name)))), Text::lit("borrow"), Array::new())));
            let body = crate::lower::model::Ex::XBlock(Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(Text::lit("row")), current.clone()), crate::lower::model::Do::DoIfLet(crate::lower::model::Pa::PaCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("row"))])), crate::lower::model::Ex::XVar(Text::lit("row")), Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::try_of(&crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("row"))), Text::lit("answer"), Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("at")), crate::lower::model::Ex::XVar(Text::lit("v")), crate::lower::model::Ex::XCx]))))]), Array::new())]), Rc::new(crate::lower::model::Ex::XUnit));
            (pos_pat(&crate::lower::model::Pos_ { scope: gd.pos.scope.clone(), at: &gd.pos.at + i }, &Array::from(vec![crate::lower::model::Pa::PaRest(Text::lit(""))])), body.clone())
        }))
    } else {
        Array::from(vec![(pos_pat(&gd.pos, &gen_tail()), forward_gen(gd))])
    }
}

/// ```prism
/// ForwardGen: fn GenDef -> Ex
/// ```
pub fn forward_gen(gd: &crate::lower::model::GenDef) -> crate::lower::model::Ex {
    let current = crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", &gd.name)))), Text::lit("borrow"), Array::new())));
    let is_current = crate::lower::model::Ex::XBin(Text::lit("=="), Rc::new(crate::lower::model::Ex::XBin(Text::lit("+"), Rc::new(crate::lower::model::Ex::XDeref(Rc::new(crate::lower::model::Ex::XVar(Text::lit("g"))))), Rc::new(crate::lower::model::Ex::XIndex(Nat::from(1u32))))), Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_count", &gd.name)))), Text::lit("get"), Array::new())));
    crate::lower::model::Ex::XBlock(Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(Text::lit("row")), current.clone()), crate::lower::model::Do::DoIfLet(crate::lower::model::Pa::PaCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("row"))])), crate::lower::model::Ex::XVar(Text::lit("row")), Array::from(vec![crate::lower::model::Do::DoIf(is_current.clone(), Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::try_of(&crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("row"))), Text::lit("answer"), Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("rest")), crate::lower::model::Ex::XVar(Text::lit("v")), crate::lower::model::Ex::XCx]))))]), Array::new())]), Array::new())]), Rc::new(crate::lower::model::Ex::XUnit))
}

/// ```prism
/// FlattenLine: unbounded fn Wx, Env, [Arg], ?Bn -> ((Wx, Wres))
/// ```
pub fn flatten_line(wx: &Wx, menv: &crate::lower::Env, args: &Array<crate::syntax::Arg>, bound_opt: &Option<crate::lower::Bn>) -> (Wx, Wres) {
    let outer_opt = match index(args, &Nat::from(0u32)) {
        Some(a) => match &*a.value.kind {
            crate::syntax::ExprKind::EName(n) => 'm175976: {
                let scrutinee = &get(&menv.names, &crate::check::env::sname_key(n));
                if let Some(crate::lower::Bn::BnDyn(crate::lower::model::Ex::XMethod(m175976_0_0_0, m, _), _, crate::lower::model::OutTy::OutDyn(t))) = scrutinee && let crate::lower::model::Ex::XSelf = &**m175976_0_0_0 {
                    break 'm175976 fold(&wx.gens, &None, &(|acc_opt: &Option<(Text, Text, crate::lower::model::OutTy)>, gd: &crate::lower::model::GenDef| if &Text::from(format!("{}_result", &gd.name)) == m {
                        Some((m.clone(), gd.name.clone(), (**t).clone()))
                    } else {
                        acc_opt.clone()
                    }));
                }
                None
            },
            _ => None,
        },
        None => None,
    };
    match &outer_opt {
        None => {
            let wx2 = {
                let mut this: Wx = wx.clone();
                this.build = push(&this.build, &crate::lower::refusal_do(&Text::lit("`@Flatten` of a dynamic that is not a `rebuild`'s")));
                this
            };
            (wx2.clone(), Wres::WrUnit)
        },
        Some((m, gen_, t)) => {
            let (name, wx1) = match bound_opt {
                Some(crate::lower::Bn::BnHold(f, _)) => (f.clone(), wx.clone()),
                _ => fresh_name(wx, &Text::lit("flatten")),
            };
            let inner = Text::from(format!("{}_inner", &name));
            let first_ = crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XVar(Text::lit("node"))), Text::from(format!("{}", &inner)))), Text::lit("set"), Array::from(vec![crate::lower::model::Ex::XCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("node"))), m.clone(), Array::from(vec![crate::lower::model::Ex::XCx]))])), crate::lower::model::Ex::XCx])));
            let sample = crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", &inner)))), Text::lit("get"), Array::from(vec![crate::lower::model::Ex::XCx]))), Text::lit("expect"), Array::from(vec![crate::lower::model::Ex::XStr(Text::lit("`@Flatten` adopts its first inner at the build"))]))), Text::lit("sample"), Array::from(vec![crate::lower::model::Ex::XCx]));
            let wx2 = {
                let mut this: Wx = wx1.clone();
                this.taken = append(&this.taken, &Array::from(vec![inner.clone(), Text::from(format!("{}_adopt", &name))]));
                this.fields = push(&this.fields, &(inner.clone(), crate::lower::model::OutTy::OutHold(Rc::new(crate::lower::model::OutTy::OutOpt(Rc::new(crate::lower::model::OutTy::OutDyn(Rc::new(t.clone())))))), Text::lit("`@Flatten`'s current inner: the dynamic of the generation it adopted")));
                this.moves = push(&this.moves, &(inner.clone(), crate::lower::model::Ex::XCall(Text::lit("Hold::new"), Array::from(vec![crate::lower::model::Ex::XNone, crate::lower::model::Ex::XCx]))));
                this.build = push(&this.build, &first_);
                this.getters = push(&this.getters, &crate::lower::model::MethDef { name: name.clone(), recv: crate::lower::model::Recv::RecvRef, params: Array::new(), cx_: crate::lower::model::CxArg::CxRef, ret: t.clone(), body: Array::new(), tail: sample.clone(), doc: Text::lit("`@Flatten`'s dynamic: its current inner at the read point.") });
                this.dyn_reads = insert(&this.dyn_reads, &name, &Array::from(vec![Read::OwnRead(inner.clone())]));
                this.flattens = push(&this.flattens, &FlatDef { name: name.clone(), outer: m.clone(), generation: gen_.clone(), ty: t.clone() });
                this
            };
            (wx2.clone(), Wres::WrDyn(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XSelf), name.clone(), Array::from(vec![crate::lower::model::Ex::XCx])), Array::from(vec![Read::OwnRead(inner.clone())]), t.clone()))
        },
    }
}

/// ```prism
/// SwitchLine: unbounded fn Wx, Env, [Arg] -> ((Wx, Wres))
/// ```
pub fn switch_line(wx: &Wx, menv: &crate::lower::Env, args: &Array<crate::syntax::Arg>) -> (Wx, Wres) {
    match index(args, &Nat::from(0u32)) {
        Some(a) => {
            let (r, wx2) = event_ref(wx, menv, &a.value);
            (wx2.clone(), Wres::WrEv(r.clone()))
        },
        None => (wx.clone(), Wres::WrUnit),
    }
}
