//! The module `Lower.Node.Elements`, from `target/bootstrap/src/prismc/lower/node/elements.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// ```prism
/// ElementLine: unbounded fn Wx, Env, Env, Expr, ?Bn -> ((Wx, Wres))
/// ```
pub fn element_line(wx: &crate::lower::node_::Wx, benv: &crate::lower::types::Env, menv: &crate::lower::types::Env, e: &crate::syntax::Expr, bound_opt: &Option<crate::lower::types::Bn>) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    let lx = wx.lx.clone();
    let (tag_name, args) = match &*e.kind {
        crate::syntax::ExprKind::ECall(c, xs, _, _) => (tag_name_of(&lx, &**c), xs.clone()),
        crate::syntax::ExprKind::EName(n) => (tag_name_of(&lx, e), Array::new()),
        _ => (Text::lit(""), Array::new()),
    };
    let full = crate::lower::type_at(&lx, &e.span);
    match get(&lx.g.tags, &tag_name) {
        None => {
            let wx2 = {
                let mut this: crate::lower::node_::Wx = wx.clone();
                this.build = push(&this.build, &crate::lower::expr::refusal_do(&Text::lit("an element of an unknown tag")));
                this
            };
            (wx2.clone(), crate::lower::node_::Wres::WrUnit)
        },
        Some(tg) => {
            let pos = wx.pos.clone();
            let wx1 = {
                let mut this: crate::lower::node_::Wx = wx.clone();
                this.pos = crate::lower::model::next_pos(&this.pos);
                this
            };
            let struct_path = crate::lower::path_in(&lx, &tg.home, &crate::lower::tag_struct(&tg.name));
            let (live_fields, const_fields, method_consts, reads, wx2) = run_to_end(fold_job(tg.fields.clone(), (Array::new(), Array::new(), Array::new(), Array::new(), wx1.clone()), {
                let args = args.clone();
                let menv = menv.clone();
                let pos = pos.clone();
                let tg = tg.clone();
                let lx = lx.clone();
                let benv = benv.clone();
                Rc::new(move |(p0, p1): ((Array<(Text, crate::lower::model::Ex)>, Array<(Text, crate::lower::model::Ex)>, Array<(Text, crate::lower::model::Ex)>, Array<crate::lower::node_::Read>, crate::lower::node_::Wx), (Text, crate::check::types::Ty))| {
                    let args = args.clone();
                    let menv = menv.clone();
                    let pos = pos.clone();
                    let tg = tg.clone();
                    let lx = lx.clone();
                    let benv = benv.clone();
                    entered(once_job(move || {
                        let (lf, cf, mf, rd, w) = p0;
                        let (fname, fty) = p1;
                        match tag_arg(&args, &fname) {
                            None => prism_rtl::Turn::Finished((lf.clone(), cf.clone(), mf.clone(), rd.clone(), w.clone())),
                            Some(arg) => match crate::lower::types::layer_of(&fty) {
                                crate::lower::types::Layer::LyEv => call_then(crate::lower::node_::dynamics::start_event_ref(w.clone(), menv.clone(), arg.clone()), move |event_ref_2608: (crate::lower::node_::EvRef, crate::lower::node_::Wx)| {
                                    let (r, w2) = event_ref_2608;
                                    prism_rtl::Turn::Finished((lf.clone(), cf.clone(), mf.clone(), rd.clone(), crate::lower::node_::connect(&w2, &r, &crate::lower::node_::Sk::SkRequest(pos.clone(), request_field(&tg, &fname)))))
                                }),
                                _ => call_then(crate::lower::node_::dynamics::start_dynamic_expr(w.clone(), menv.clone(), arg.clone()), move |dynamic_expr_2830: (crate::lower::model::Ex, Array<crate::lower::node_::Read>)| {
                                    let (ex, rds) = dynamic_expr_2830;
                                    call_then(crate::lower::expr::start_value_of(lx.clone(), benv.clone(), arg.clone()), move |value_of_2901: crate::lower::types::Vl| {
                                        let cv = crate::lower::types::own(&value_of_2901);
                                        call_then(crate::lower::expr::start_value_of(lx.clone(), menv.clone(), arg.clone()), move |value_of_2970: crate::lower::types::Vl| {
                                            let mv = crate::lower::types::own(&value_of_2970);
                                            prism_rtl::Turn::Finished((push(&lf, &(crate::lower::snake(&fname), ex.clone())), push(&cf, &(crate::lower::snake(&fname), cv.clone())), push(&mf, &(crate::lower::snake(&fname), mv.clone())), crate::lower::node_::union_reads(&rd, &rds), w.clone()))
                                        })
                                    })
                                }),
                            },
                        }
                    }))
                }) as Rc<dyn Fn(((Array<(Text, crate::lower::model::Ex)>, Array<(Text, crate::lower::model::Ex)>, Array<(Text, crate::lower::model::Ex)>, Array<crate::lower::node_::Read>, crate::lower::node_::Wx), (Text, crate::check::types::Ty))) -> Rc<dyn prism_rtl::Job<(Array<(Text, crate::lower::model::Ex)>, Array<(Text, crate::lower::model::Ex)>, Array<(Text, crate::lower::model::Ex)>, Array<crate::lower::node_::Read>, crate::lower::node_::Wx)>>>
            }));
            let live = &len(&reads) > &Nat::from(0u32);
            let (getter, wx3) = if live {
                crate::lower::node_::fresh_name(&wx2, &crate::lower::snake(&crate::check::types::bare_name(&tg.name)))
            } else {
                (Text::lit(""), wx2.clone())
            };
            let variant = crate::lower::program::variant_of(&lx, &tg);
            let level = crate::lower::model::Ex::XCtor(variant.clone(), Array::from(vec![crate::lower::model::Ex::XRecord(struct_path.clone(), if live { live_fields.clone() } else { method_consts.clone() })]));
            let at_build = crate::lower::model::Ex::XCtor(variant.clone(), Array::from(vec![crate::lower::model::Ex::XRecord(struct_path.clone(), const_fields.clone())]));
            let added = if live {
                crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("node"))), getter.clone(), Array::from(vec![crate::lower::model::Ex::XCx]))
            } else {
                at_build.clone()
            };
            let wx4 = {
                let mut this: crate::lower::node_::Wx = wx3.clone();
                this.places = push(&this.places, &crate::lower::node_::Place { pos: pos.clone(), level: level.clone(), getter: getter.clone(), reads: reads.clone() });
                this.build = if crate::lower::node_::finish::emits(&wx3, &pos) {
                    push(&this.build, &crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCx), Text::lit("added"), Array::from(vec![crate::lower::node_::finish::place_at(&wx3, &Text::lit("node"), &pos), crate::lower::model::Ex::XMethod(Rc::new(added.clone()), Text::lit("to_pod"), Array::new())]))))
                } else {
                    this.build.clone()
                };
                this
            };
            element_output(&wx4, menv, &tg, &element_out(&lx, &tg, &full), &pos, bound_opt, &at_build)
        },
    }
}

/// The step machine of `ElementLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ElementLine: unbounded fn Wx, Env, Env, Expr, ?Bn -> ((Wx, Wres))
/// ```
pub struct ElementLine {
    pub wx: crate::lower::node_::Wx,
    pub benv: crate::lower::types::Env,
    pub menv: crate::lower::types::Env,
    pub e: crate::syntax::Expr,
    pub bound_opt: Option<crate::lower::types::Bn>,
}

impl prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::node_::Wres)> for ElementLine {
    fn cycle(&self) -> prism_rtl::Turn<(crate::lower::node_::Wx, crate::lower::node_::Wres)> {
        let wx = &self.wx;
        let benv = &self.benv;
        let menv = &self.menv;
        let e = &self.e;
        let bound_opt = &self.bound_opt;
        let lx = wx.lx.clone();
        let (tag_name, args) = match &*e.kind {
            crate::syntax::ExprKind::ECall(c, xs, _, _) => (tag_name_of(&lx, &**c), xs.clone()),
            crate::syntax::ExprKind::EName(n) => (tag_name_of(&lx, e), Array::new()),
            _ => (Text::lit(""), Array::new()),
        };
        let full = crate::lower::type_at(&lx, &e.span);
        match get(&lx.g.tags, &tag_name) {
            None => {
                let wx2 = {
                    let mut this: crate::lower::node_::Wx = wx.clone();
                    this.build = push(&this.build, &crate::lower::expr::refusal_do(&Text::lit("an element of an unknown tag")));
                    this
                };
                prism_rtl::Turn::Finished((wx2.clone(), crate::lower::node_::Wres::WrUnit))
            },
            Some(tg) => {
                let pos = wx.pos.clone();
                let wx1 = {
                    let mut this: crate::lower::node_::Wx = wx.clone();
                    this.pos = crate::lower::model::next_pos(&this.pos);
                    this
                };
                let struct_path = crate::lower::path_in(&lx, &tg.home, &crate::lower::tag_struct(&tg.name));
                let bound_opt = bound_opt.clone();
                let benv = benv.clone();
                let menv = menv.clone();
                call_value(fold_job(tg.fields.clone(), (Array::new(), Array::new(), Array::new(), Array::new(), wx1.clone()), {
                    let args = args.clone();
                    let menv = menv.clone();
                    let pos = pos.clone();
                    let tg = tg.clone();
                    let lx = lx.clone();
                    let benv = benv.clone();
                    Rc::new(move |(p0, p1): ((Array<(Text, crate::lower::model::Ex)>, Array<(Text, crate::lower::model::Ex)>, Array<(Text, crate::lower::model::Ex)>, Array<crate::lower::node_::Read>, crate::lower::node_::Wx), (Text, crate::check::types::Ty))| {
                        let args = args.clone();
                        let menv = menv.clone();
                        let pos = pos.clone();
                        let tg = tg.clone();
                        let lx = lx.clone();
                        let benv = benv.clone();
                        entered(once_job(move || {
                            let (lf, cf, mf, rd, w) = p0;
                            let (fname, fty) = p1;
                            match tag_arg(&args, &fname) {
                                None => prism_rtl::Turn::Finished((lf.clone(), cf.clone(), mf.clone(), rd.clone(), w.clone())),
                                Some(arg) => match crate::lower::types::layer_of(&fty) {
                                    crate::lower::types::Layer::LyEv => call_then(crate::lower::node_::dynamics::start_event_ref(w.clone(), menv.clone(), arg.clone()), move |event_ref_2608: (crate::lower::node_::EvRef, crate::lower::node_::Wx)| {
                                        let (r, w2) = event_ref_2608;
                                        prism_rtl::Turn::Finished((lf.clone(), cf.clone(), mf.clone(), rd.clone(), crate::lower::node_::connect(&w2, &r, &crate::lower::node_::Sk::SkRequest(pos.clone(), request_field(&tg, &fname)))))
                                    }),
                                    _ => call_then(crate::lower::node_::dynamics::start_dynamic_expr(w.clone(), menv.clone(), arg.clone()), move |dynamic_expr_2830: (crate::lower::model::Ex, Array<crate::lower::node_::Read>)| {
                                        let (ex, rds) = dynamic_expr_2830;
                                        call_then(crate::lower::expr::start_value_of(lx.clone(), benv.clone(), arg.clone()), move |value_of_2901: crate::lower::types::Vl| {
                                            let cv = crate::lower::types::own(&value_of_2901);
                                            call_then(crate::lower::expr::start_value_of(lx.clone(), menv.clone(), arg.clone()), move |value_of_2970: crate::lower::types::Vl| {
                                                let mv = crate::lower::types::own(&value_of_2970);
                                                prism_rtl::Turn::Finished((push(&lf, &(crate::lower::snake(&fname), ex.clone())), push(&cf, &(crate::lower::snake(&fname), cv.clone())), push(&mf, &(crate::lower::snake(&fname), mv.clone())), crate::lower::node_::union_reads(&rd, &rds), w.clone()))
                                            })
                                        })
                                    }),
                                },
                            }
                        }))
                    }) as Rc<dyn Fn(((Array<(Text, crate::lower::model::Ex)>, Array<(Text, crate::lower::model::Ex)>, Array<(Text, crate::lower::model::Ex)>, Array<crate::lower::node_::Read>, crate::lower::node_::Wx), (Text, crate::check::types::Ty))) -> Rc<dyn prism_rtl::Job<(Array<(Text, crate::lower::model::Ex)>, Array<(Text, crate::lower::model::Ex)>, Array<(Text, crate::lower::model::Ex)>, Array<crate::lower::node_::Read>, crate::lower::node_::Wx)>>>
                }), move |fold_2276: (Array<(Text, crate::lower::model::Ex)>, Array<(Text, crate::lower::model::Ex)>, Array<(Text, crate::lower::model::Ex)>, Array<crate::lower::node_::Read>, crate::lower::node_::Wx)| {
                    let (live_fields, const_fields, method_consts, reads, wx2) = fold_2276;
                    let live = &len(&reads) > &Nat::from(0u32);
                    let (getter, wx3) = if live {
                        crate::lower::node_::fresh_name(&wx2, &crate::lower::snake(&crate::check::types::bare_name(&tg.name)))
                    } else {
                        (Text::lit(""), wx2.clone())
                    };
                    let variant = crate::lower::program::variant_of(&lx, &tg);
                    let level = crate::lower::model::Ex::XCtor(variant.clone(), Array::from(vec![crate::lower::model::Ex::XRecord(struct_path.clone(), if live { live_fields.clone() } else { method_consts.clone() })]));
                    let at_build = crate::lower::model::Ex::XCtor(variant.clone(), Array::from(vec![crate::lower::model::Ex::XRecord(struct_path.clone(), const_fields.clone())]));
                    let added = if live {
                        crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("node"))), getter.clone(), Array::from(vec![crate::lower::model::Ex::XCx]))
                    } else {
                        at_build.clone()
                    };
                    let wx4 = {
                        let mut this: crate::lower::node_::Wx = wx3.clone();
                        this.places = push(&this.places, &crate::lower::node_::Place { pos: pos.clone(), level: level.clone(), getter: getter.clone(), reads: reads.clone() });
                        this.build = if crate::lower::node_::finish::emits(&wx3, &pos) {
                            push(&this.build, &crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCx), Text::lit("added"), Array::from(vec![crate::lower::node_::finish::place_at(&wx3, &Text::lit("node"), &pos), crate::lower::model::Ex::XMethod(Rc::new(added.clone()), Text::lit("to_pod"), Array::new())]))))
                        } else {
                            this.build.clone()
                        };
                        this
                    };
                    prism_rtl::Turn::Finished(element_output(&wx4, &menv, &tg, &element_out(&lx, &tg, &full), &pos, &bound_opt, &at_build))
                })
            },
        }
    }
}

/// `Start ElementLine, x`: what the function value is when passed to `@Run`.
pub fn start_element_line(wx: crate::lower::node_::Wx, benv: crate::lower::types::Env, menv: crate::lower::types::Env, e: crate::syntax::Expr, bound_opt: Option<crate::lower::types::Bn>) -> Rc<dyn prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::node_::Wres)>> {
    Rc::new(ElementLine { wx, benv, menv, e, bound_opt })
}

/// ```prism
/// ElementOut: unbounded fn Lx, TagInfo, Ty -> OutTy
/// ```
pub fn element_out(lx: &crate::lower::Lx, tg: &crate::check::env::TagInfo, full: &crate::check::types::Ty) -> crate::lower::model::OutTy {
    let t = match crate::lower::types::peel(full) {
        crate::check::types::Ty::TyElem(_, o) => crate::lower::types::out_ty_of(lx, &crate::lower::types::peel(&*o)),
        _ => crate::lower::types::out_ty_of(lx, &crate::lower::types::peel(&tg.out)),
    };
    match &t {
        crate::lower::model::OutTy::OutGen(_) => crate::lower::model::OutTy::OutPod,
        _ => t.clone(),
    }
}

/// ```prism
/// TagNameOf: fn Lx, Expr -> Text
/// ```
pub fn tag_name_of(lx: &crate::lower::Lx, c: &crate::syntax::Expr) -> Text {
    match &*c.kind {
        crate::syntax::ExprKind::EName(n) => {
            let (qk_opt, _) = crate::check::env::names::resolve_value(&lx.g, &lx.home, n);
            or(&qk_opt, &crate::check::env::dotted(&n.path_))
        },
        crate::syntax::ExprKind::EGroup(x) => tag_name_of(lx, &**x),
        _ => Text::lit(""),
    }
}

/// ```prism
/// ?TagArg: fn [Arg], Text -> ?Expr
/// ```
pub fn tag_arg(args: &Array<crate::syntax::Arg>, fname: &Text) -> Option<crate::syntax::Expr> {
    fold(args, &None, &(|found_opt: &Option<crate::syntax::Expr>, a: &crate::syntax::Arg| match &a.name {
        Some(n) => if &n.name == fname { Some(a.value.clone()) } else { found_opt.clone() },
        None => found_opt.clone(),
    }))
}

/// ```prism
/// RequestField: fn TagInfo, Text -> Text
/// ```
pub fn request_field(tg: &crate::check::env::TagInfo, fname: &Text) -> Text {
    let evs = filter(&tg.fields, &(|(_, t): &(Text, crate::check::types::Ty)| &crate::lower::types::layer_of(t) == &crate::lower::types::Layer::LyEv));
    if &len(&evs) > &Nat::from(1u32) { fname.clone() } else { Text::lit("") }
}

/// ```prism
/// ElementOutput: unbounded fn Wx, Env, TagInfo, OutTy, Pos, ?Bn, Ex -> ((Wx, Wres))
/// ```
pub fn element_output(wx: &crate::lower::node_::Wx, menv: &crate::lower::types::Env, tg: &crate::check::env::TagInfo, out: &crate::lower::model::OutTy, pos: &crate::lower::model::Pos_, bound_opt: &Option<crate::lower::types::Bn>, level: &crate::lower::model::Ex) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    let lx = wx.lx.clone();
    match bound_opt {
        Some(crate::lower::types::Bn::BnParts(parts)) => bundle_output(wx, tg, out, pos, parts, level),
        _ => element_output_of(wx, menv, tg, out, pos, bound_opt, level),
    }
}

/// ```prism
/// BundleOutput: unbounded fn Wx, TagInfo, OutTy, Pos, [?Bn], Ex -> ((Wx, Wres))
/// ```
pub fn bundle_output(wx: &crate::lower::node_::Wx, tg: &crate::check::env::TagInfo, out: &crate::lower::model::OutTy, pos: &crate::lower::model::Pos_, parts: &Array<Option<crate::lower::types::Bn>>, level: &crate::lower::model::Ex) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    if !crate::lower::node_::finish::emits(wx, pos) {
        {
            let wx2 = {
                let mut this: crate::lower::node_::Wx = wx.clone();
                this.build = push(&this.build, &crate::lower::expr::refusal_do(&Text::from(format!("a bundle ({}) in a hosted scope", &tg.name))));
                this
            };
            (wx2.clone(), crate::lower::node_::Wres::WrUnit)
        }
    } else {
        bundle_output_of(wx, tg, out, pos, parts, level)
    }
}

/// ```prism
/// BundleOutputOf: unbounded fn Wx, TagInfo, OutTy, Pos, [?Bn], Ex -> ((Wx, Wres))
/// ```
pub fn bundle_output_of(wx: &crate::lower::node_::Wx, tg: &crate::check::env::TagInfo, out: &crate::lower::model::OutTy, pos: &crate::lower::model::Pos_, parts: &Array<Option<crate::lower::types::Bn>>, level: &crate::lower::model::Ex) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    let layers = match &tg.out {
        crate::check::types::Ty::TyTuple(cs) => each(cs, &(|c: &crate::check::types::Ty| crate::lower::types::layer_of(c))),
        _ => Array::new(),
    };
    let tys = match out {
        crate::lower::model::OutTy::OutTuple(ts) => ts.clone(),
        _ => Array::new(),
    };
    let idx = crate::check::errors::range0(&len(&layers));
    let plain_ix = filter(&idx, &(|i: &Nat| &or(&index(&layers, i), &crate::lower::types::Layer::LyPlain) == &crate::lower::types::Layer::LyPlain));
    let ev_ix = filter(&idx, &(|i: &Nat| &or(&index(&layers, i), &crate::lower::types::Layer::LyPlain) == &crate::lower::types::Layer::LyEv));
    let dyn_ix = filter(&idx, &(|i: &Nat| &or(&index(&layers, i), &crate::lower::types::Layer::LyPlain) == &crate::lower::types::Layer::LyDyn));
    let wx1 = bundle_first(wx, tg, pos, &plain_ix, &tys, parts, level);
    let wx2 = fold(&ev_ix, &wx1, &(|w: &crate::lower::node_::Wx, i: &Nat| bundle_answer(w, pos, &or(&index(&tys, i), &crate::lower::model::OutTy::OutUnit), &or(&index(parts, i), &None))));
    if (&len(&ev_ix) > &Nat::from(1u32)) || (&len(&dyn_ix) > &Nat::from(0u32)) {
        {
            let wx3 = {
                let mut this: crate::lower::node_::Wx = wx2.clone();
                this.build = push(&this.build, &crate::lower::expr::refusal_do(&Text::from(format!("a bundle with a `$` part or two event parts ({})", &tg.name))));
                this
            };
            (wx3.clone(), crate::lower::node_::Wres::WrUnit)
        }
    } else {
        (wx2.clone(), crate::lower::node_::Wres::WrUnit)
    }
}

/// ```prism
/// BundleFirst: unbounded fn Wx, TagInfo, Pos, [Nat], [OutTy], [?Bn], Ex -> Wx
/// ```
pub fn bundle_first(wx: &crate::lower::node_::Wx, tg: &crate::check::env::TagInfo, pos: &crate::lower::model::Pos_, plain_ix: &Array<Nat>, tys: &Array<crate::lower::model::OutTy>, parts: &Array<Option<crate::lower::types::Bn>>, level: &crate::lower::model::Ex) -> crate::lower::node_::Wx {
    match plain_ix {
        m7769_0 if (m7769_0.len() == 0) => wx.clone(),
        _ => {
            let one = &len(plain_ix) == &Nat::from(1u32);
            let plain_ty = if one {
                or(&index(tys, &or(&index(plain_ix, &Nat::from(0u32)), &Nat::from(0u32))), &crate::lower::model::OutTy::OutUnit)
            } else {
                crate::lower::model::OutTy::OutTuple(each(plain_ix, &(|i: &Nat| or(&index(tys, i), &crate::lower::model::OutTy::OutUnit))))
            };
            let wx1 = {
                let mut this: crate::lower::node_::Wx = wx.clone();
                this.lets = append(&this.lets, &Array::from(vec![first_value_let(wx, pos, tg, level), crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(Text::from(format!("bundle_{}", &crate::lower::model::place_text(pos)))), crate::lower::model::Ex::XDecode(plain_ty.clone(), Rc::new(crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XVar(Text::from(format!("first_{}", &crate::lower::model::place_text(pos)))))))))]));
                this.fallible = true;
                this
            };
            fold(&crate::check::errors::range0(&len(plain_ix)), &wx1, &(|w: &crate::lower::node_::Wx, k: &Nat| {
                let i = or(&index(plain_ix, k), &Nat::from(0u32));
                match index(parts, &i) {
                    Some(Some(crate::lower::types::Bn::BnLocal(rs, _, _))) => {
                        let f = crate::lower::types::place_stem(&rs);
                        let part = if one {
                            crate::lower::model::Ex::XVar(Text::from(format!("bundle_{}", &crate::lower::model::place_text(pos))))
                        } else {
                            crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XPart(Rc::new(crate::lower::model::Ex::XVar(Text::from(format!("bundle_{}", &crate::lower::model::place_text(pos))))), k.clone())))
                        };
                        {
                            let mut this: crate::lower::node_::Wx = w.clone();
                            this.lets = push(&this.lets, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(f.clone()), part.clone()));
                            this.fields = push(&this.fields, &(f.clone(), or(&index(tys, &i), &crate::lower::model::OutTy::OutUnit), Text::from(format!("place {}\'s answer, part {} of its first value", &crate::lower::model::place_text(pos), &i))));
                            this.inits = push(&this.inits, &(f.clone(), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(f.clone())))));
                            this
                        }
                    },
                    _ => w.clone(),
                }
            }))
        },
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// BundleAnswer: fn Wx, Pos, OutTy, ?Bn -> Wx
/// ```
pub fn bundle_answer(wx: &crate::lower::node_::Wx, pos: &crate::lower::model::Pos_, et: &crate::lower::model::OutTy, b_opt: &Option<crate::lower::types::Bn>) -> crate::lower::node_::Wx {
    let t = match et {
        crate::lower::model::OutTy::OutEvent(inner) => (**inner).clone(),
        _ => et.clone(),
    };
    let (id, wx2) = match b_opt {
        Some(crate::lower::types::Bn::BnEv(er, _)) => (er.node_.clone(), wx.clone()),
        _ => {
            let (nm, w) = crate::lower::node_::fresh_name(wx, &Text::from(format!("place_{}", &crate::lower::model::place_text(pos))));
            crate::lower::node_::add_gn(&w, &nm, &t, &crate::lower::node_::GnKind::GnAnswer, &Nat::from(0u32))
        },
    };
    let mut this: crate::lower::node_::Wx = wx2.clone();
    this.answers = push(&this.answers, &(pos.clone(), id.clone(), t.clone(), Text::lit("")));
    this
}

/// ```prism
/// FirstValueLet: fn Wx, Pos, TagInfo, Ex -> Do
/// ```
pub fn first_value_let(wx: &crate::lower::node_::Wx, pos: &crate::lower::model::Pos_, tg: &crate::check::env::TagInfo, level: &crate::lower::model::Ex) -> crate::lower::model::Do {
    let missing = crate::lower::model::Ex::XCall(Text::lit("Fault::answer"), Array::from(vec![crate::lower::model::Ex::XStr(Text::from(format!("no first value for {}", &tg.name)))]));
    if crate::lower::node_::finish::emits(wx, pos) {
        {
            let asked = crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCx), Text::lit("first_value"), Array::from(vec![crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(level.clone()), Text::lit("to_pod"), Array::new())))]));
            crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(Text::from(format!("first_{}", &crate::lower::model::place_text(pos)))), crate::lower::expr::try_of(&crate::lower::model::Ex::XMethod(Rc::new(asked.clone()), Text::lit("ok_or"), Array::from(vec![missing.clone()]))))
        }
    } else {
        {
            let host = host_local(wx, pos);
            let asked = crate::lower::expr::try_of(&crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(host.clone())), Text::lit("first_value"), Array::from(vec![crate::lower::model::Ex::XRef(Rc::new(crate::lower::node_::finish::place_at(wx, &Text::lit(""), pos))), crate::lower::model::Ex::XRef(Rc::new(level.clone())), crate::lower::model::Ex::XCx])));
            crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(Text::from(format!("first_{}", &crate::lower::model::place_text(pos)))), crate::lower::expr::try_of(&crate::lower::model::Ex::XMethod(Rc::new(crate::lower::expr::try_of(&crate::lower::model::Ex::XMethod(Rc::new(asked.clone()), Text::lit("ok_or"), Array::from(vec![missing.clone()])))), answer_accessor(tg), Array::new())))
        }
    }
}

/// ```prism
/// HostLocal: fn Wx, Pos -> Text
/// ```
pub fn host_local(wx: &crate::lower::node_::Wx, pos: &crate::lower::model::Pos_) -> Text {
    if &pos.scope == &Nat::from(0u32) {
        Text::lit("enclosing")
    } else {
        or(&index(&wx.scopes, &crate::syntax::lexer::chars::dec(&pos.scope)), &Text::lit(""))
    }
}

/// ```prism
/// AnswerVariant: fn TagInfo -> Text
/// ```
pub fn answer_variant(tg: &crate::check::env::TagInfo) -> Text {
    Text::from(format!("crate::Answer::{}", &crate::lower::tag_struct(&tg.name)))
}

/// ```prism
/// AnswerAccessor: fn TagInfo -> Text
/// ```
pub fn answer_accessor(tg: &crate::check::env::TagInfo) -> Text {
    crate::lower::snake(&crate::lower::tag_struct(&tg.name))
}

/// ```prism
/// ElementOutputOf: unbounded fn Wx, Env, TagInfo, OutTy, Pos, ?Bn, Ex -> ((Wx, Wres))
/// ```
pub fn element_output_of(wx: &crate::lower::node_::Wx, menv: &crate::lower::types::Env, tg: &crate::check::env::TagInfo, out: &crate::lower::model::OutTy, pos: &crate::lower::model::Pos_, bound_opt: &Option<crate::lower::types::Bn>, level: &crate::lower::model::Ex) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    let lx = wx.lx.clone();
    match crate::lower::types::layer_of(&tg.out) {
        crate::lower::types::Layer::LyEv => {
            let (id, wx2) = match bound_opt {
                Some(crate::lower::types::Bn::BnEv(er, _)) => (er.node_.clone(), wx.clone()),
                _ => {
                    let (nm, w) = crate::lower::node_::fresh_name(wx, &Text::from(format!("place_{}", &crate::lower::model::place_text(pos))));
                    crate::lower::node_::add_gn(&w, &nm, out, &crate::lower::node_::GnKind::GnAnswer, &Nat::from(0u32))
                },
            };
            let wx3 = {
                let mut this: crate::lower::node_::Wx = wx2.clone();
                this.answers = push(&this.answers, &(pos.clone(), id.clone(), out.clone(), answer_accessor(tg)));
                this
            };
            (wx3.clone(), crate::lower::node_::Wres::WrEv(crate::lower::node_::ev_ref_of(&wx3, &id)))
        },
        crate::lower::types::Layer::LyDyn => {
            let (f, wx1) = match bound_opt {
                Some(crate::lower::types::Bn::BnHold(hf, _)) => (hf.clone(), wx.clone()),
                _ => crate::lower::node_::fresh_name(wx, &Text::from(format!("place_{}", &crate::lower::model::place_text(pos)))),
            };
            let emits = crate::lower::node_::finish::emits(wx, pos);
            let first_ = if emits {
                crate::lower::model::Ex::XDecode(out.clone(), Rc::new(crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XVar(Text::from(format!("first_{}", &crate::lower::model::place_text(pos))))))))
            } else {
                crate::lower::model::Ex::XVar(Text::from(format!("first_{}", &crate::lower::model::place_text(pos))))
            };
            let wx2 = {
                let mut this: crate::lower::node_::Wx = wx1.clone();
                this.lets = push(&this.lets, &first_value_let(wx, pos, tg, level));
                this.fields = push(&this.fields, &(f.clone(), crate::lower::model::OutTy::OutHold(Rc::new(out.clone())), Text::from(format!("pushed to place {}", &crate::lower::model::place_text(pos)))));
                this.inits = push(&this.inits, &(f.clone(), crate::lower::model::Ex::XCall(Text::lit("Hold::new"), Array::from(vec![first_.clone(), crate::lower::model::Ex::XCx]))));
                this.dyn_places = push(&this.dyn_places, &(pos.clone(), f.clone(), out.clone(), answer_accessor(tg)));
                this.fallible = true;
                this
            };
            let wx3 = if emits {
                {
                    let mut this: crate::lower::node_::Wx = wx2.clone();
                    this.lets = push(&this.lets, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(Text::from(format!("{}_element", &f))), crate::lower::model::Ex::XMethod(Rc::new(level.clone()), Text::lit("to_pod"), Array::new())));
                    this.fields = push(&this.fields, &(Text::from(format!("{}_element", &f)), crate::lower::model::OutTy::OutPod, Text::from(format!("place {}\'s element, which pushes are keyed by", &crate::lower::model::place_text(pos)))));
                    this.moves = push(&this.moves, &(Text::from(format!("{}_element", &f)), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(Text::from(format!("{}_element", &f)))))));
                    this.build = push(&this.build, &crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCx), Text::lit("listen"), Array::from(vec![crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XVar(Text::lit("node"))), Text::from(format!("{}_element", &f))))), crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XCast(Rc::new(crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(Text::lit("node"))))), crate::lower::model::OutTy::OutObj(Rc::new(crate::lower::model::OutTy::OutNamed(Text::lit("Node"), Array::new()))))))]))));
                    this
                }
            } else {
                wx2.clone()
            };
            (wx3.clone(), crate::lower::node_::Wres::WrDyn(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", &f)))), Text::lit("get"), Array::from(vec![crate::lower::model::Ex::XCx])), Array::from(vec![crate::lower::node_::Read::OwnRead(f.clone())]), out.clone()))
        },
        _ => match bound_opt {
            Some(crate::lower::types::Bn::BnLocal(rs, _, _)) => {
                let f = crate::lower::types::place_stem(rs);
                let first_ = if crate::lower::node_::finish::emits(wx, pos) {
                    crate::lower::model::Ex::XDecode(out.clone(), Rc::new(crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XVar(Text::from(format!("first_{}", &crate::lower::model::place_text(pos))))))))
                } else {
                    crate::lower::model::Ex::XVar(Text::from(format!("first_{}", &crate::lower::model::place_text(pos))))
                };
                let wx2 = {
                    let mut this: crate::lower::node_::Wx = wx.clone();
                    this.lets = append(&this.lets, &Array::from(vec![first_value_let(wx, pos, tg, level), crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(f.clone()), first_.clone())]));
                    this.fields = push(&this.fields, &(f.clone(), out.clone(), Text::from(format!("place {}\'s answer, its first value", &crate::lower::model::place_text(pos)))));
                    this.inits = push(&this.inits, &(f.clone(), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(f.clone())))));
                    this.fallible = true;
                    this
                };
                (wx2.clone(), crate::lower::node_::Wres::WrUnit)
            },
            _ => (wx.clone(), crate::lower::node_::Wres::WrUnit),
        },
    }
}
