//! The module `Lower.Node.Elements`, from `target/bootstrap/src/prismc/lower/node/elements.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file. The runtime
//! side is reached from the crate, `crate::prelude` (and through it `::prism_rtl`), the
//! standard library from `::std`, and nothing is imported by name: a program's own type
//! (`Row`, `Option`) hides none of theirs. The traits are in scope unnamed, for their methods.

use crate::prelude::traits::*;

/// ```prism
/// ElementLine: unbounded fn Wx, Env, Env, Expr, ?Bn -> ((Wx, Wres))
/// ```
pub fn element_line_f(wx_p0: &crate::lower::node_::Wx, benv_p1: &crate::lower::types::Env, menv_p2: &crate::lower::types::Env, e_p3: &crate::syntax::Expr, bound_o4: &::std::option::Option<crate::lower::types::Bn>) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    let lx_p5 = wx_p0.lx_p.clone();
    let (tag_name_pa, args_pb) = match &*e_p3.kind_p {
        crate::syntax::ExprKind::ECall(c_p7, xs_p8, _, _) => (tag_name_of_f(&lx_p5, &**c_p7), xs_p8.clone()),
        crate::syntax::ExprKind::EName(n_p9) => (tag_name_of_f(&lx_p5, e_p3), crate::prelude::Array::new()),
        _ => (crate::prelude::Text::lit(""), crate::prelude::Array::new()),
    };
    let full_p6 = crate::lower::type_at_f(&lx_p5, &e_p3.span_p);
    match crate::prelude::get(&lx_p5.g_p.tags_p, &tag_name_pa) {
        ::std::option::Option::None => {
            let wx2_pc = {
                let mut this: crate::lower::node_::Wx = wx_p0.clone();
                this.build_p = crate::prelude::push(&this.build_p, &crate::lower::expr::refusal_do_f(&crate::prelude::Text::lit("an element of an unknown tag")));
                this
            };
            (wx2_pc.clone(), crate::lower::node_::Wres::WrUnit)
        },
        ::std::option::Option::Some(tg_pd) => element_placed_f(wx_p0, benv_p1, menv_p2, &tg_pd, &args_pb, &crate::prelude::Array::new(), &element_out_f(&lx_p5, &tg_pd, &full_p6), bound_o4),
    }
}

/// ```prism
/// RequestFieldInto: unbounded fn Wx, TagInfo, Pos, Text, Ty, EvRef, OutTy, [((Text, Ex))], [((Text, Ex))], [((Text, Ex))], [Read] -> (([((Text, Ex))], [((Text, Ex))], [((Text, Ex))], [Read], Wx))
/// ```
pub fn request_field_into_f(w2_p0: &crate::lower::node_::Wx, tg_p1: &crate::check::env::TagInfo, pos_p2: &crate::lower::model::Pos, fname_p3: &crate::prelude::Text, fty_p4: &crate::check::types::Ty, r_p5: &crate::lower::node_::EvRef, et_p6: &crate::lower::model::OutTy, lf_p7: &crate::prelude::Array<(crate::prelude::Text, crate::lower::model::Ex)>, cf_p8: &crate::prelude::Array<(crate::prelude::Text, crate::lower::model::Ex)>, mf_p9: &crate::prelude::Array<(crate::prelude::Text, crate::lower::model::Ex)>, rd_pa: &crate::prelude::Array<crate::lower::node_::Read>) -> (crate::prelude::Array<(crate::prelude::Text, crate::lower::model::Ex)>, crate::prelude::Array<(crate::prelude::Text, crate::lower::model::Ex)>, crate::prelude::Array<(crate::prelude::Text, crate::lower::model::Ex)>, crate::prelude::Array<crate::lower::node_::Read>, crate::lower::node_::Wx) {
    let lx_pb = w2_p0.lx_p.clone();
    let w3_pc = crate::lower::node_::connect_f(w2_p0, r_p5, &crate::lower::node_::Sk::SkRequest(pos_p2.clone(), request_field_f(tg_p1, fname_p3)));
    if &crate::prelude::len(&crate::lower::program::level_events_f(tg_p1)) == &crate::prelude::Nat::from(0u32) {
        (lf_p7.clone(), cf_p8.clone(), mf_p9.clone(), rd_pa.clone(), w3_pc.clone())
    } else {
        {
            let (stem_pl, w4_pm) = crate::lower::node_::fresh_name_f(&w3_pc, &crate::prelude::Text::from(format!("request_{}_{}", &crate::lower::model::place_text_f(pos_p2), &crate::lower::snake_f(&crate::lower::field_spell_f(&tg_p1.home_p, fname_p3, fty_p4)))));
            let pf_pd = crate::prelude::Text::from(format!("{}_port", &stem_pl));
            let ef_pe = crate::prelude::Text::from(format!("{}_event", &stem_pl));
            let pt_pf = crate::lower::model::OutTy::OutRc(::std::rc::Rc::new(crate::lower::model::OutTy::OutPort(::std::rc::Rc::new(et_p6.clone()))));
            let ev_ty_pg = crate::lower::model::OutTy::OutEvent(::std::rc::Rc::new(crate::lower::types::tag_field_out_f(&lx_pb, fty_p4)));
            let made_ph = crate::lower::types::recoded_whole_f(&lx_pb, fty_p4, &crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("prism_rtl::Event::of")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XVar(pf_pd.clone())))])));
            let w5_pi = {
                let mut this: crate::lower::node_::Wx = crate::lower::node_::connect_f(&w4_pm, r_p5, &crate::lower::node_::Sk::SkPort(stem_pl.clone()));
                this.taken_p = crate::prelude::append(&this.taken_p, &crate::prelude::Array::from(vec![pf_pd.clone(), ef_pe.clone()]));
                this.lets_p = crate::prelude::append(&this.lets_p, &crate::prelude::Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaBind(pf_pd.clone())), pt_pf.clone()), crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Rc::new")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Port::new")), crate::prelude::Array::new())]))), crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaBind(ef_pe.clone())), ev_ty_pg.clone()), made_ph.clone())]));
                this.fields_p = crate::prelude::append(&this.fields_p, &crate::prelude::Array::from(vec![(pf_pd.clone(), pt_pf.clone(), crate::prelude::Text::from(format!("place {}\'s `{}`: the port it fires", &crate::lower::model::place_text_f(pos_p2), fname_p3))), (ef_pe.clone(), ev_ty_pg.clone(), crate::prelude::Text::from(format!("place {}\'s `{}` as its level holds it", &crate::lower::model::place_text_f(pos_p2), fname_p3)))]));
                this.moves_p = crate::prelude::append(&this.moves_p, &crate::prelude::Array::from(vec![(pf_pd.clone(), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(pf_pd.clone())))), (ef_pe.clone(), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(ef_pe.clone()))))]));
                this
            };
            let spelled_pj = crate::lower::field_spell_f(&tg_p1.home_p, fname_p3, fty_p4);
            let held_pk = crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), ef_pe.clone())));
            (crate::prelude::push(lf_p7, &(spelled_pj.clone(), held_pk.clone())), crate::prelude::push(cf_p8, &(spelled_pj.clone(), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(ef_pe.clone()))))), crate::prelude::push(mf_p9, &(spelled_pj.clone(), held_pk.clone())), rd_pa.clone(), w5_pi.clone())
        }
    }
}

/// ```prism
/// ?FedEvent: fn [((Text, EvRef, OutTy))], Text -> ?((EvRef, OutTy))
/// ```
pub fn fed_event_o(fed_p0: &crate::prelude::Array<(crate::prelude::Text, crate::lower::node_::EvRef, crate::lower::model::OutTy)>, fname_p1: &crate::prelude::Text) -> ::std::option::Option<(crate::lower::node_::EvRef, crate::lower::model::OutTy)> {
    crate::prelude::fold(fed_p0, &::std::option::Option::None, &(|found_o2: &::std::option::Option<(crate::lower::node_::EvRef, crate::lower::model::OutTy)>, (n_p3, r_p4, et_p5): &(crate::prelude::Text, crate::lower::node_::EvRef, crate::lower::model::OutTy)| if n_p3 == fname_p1 {
        ::std::option::Option::Some((r_p4.clone(), et_p5.clone()))
    } else {
        found_o2.clone()
    }))
}

/// ```prism
/// ElementPlaced: unbounded fn Wx, Env, Env, TagInfo, [Arg], [((Text, EvRef, OutTy))], OutTy, ?Bn -> ((Wx, Wres))
/// ```
pub fn element_placed_f(wx_p0: &crate::lower::node_::Wx, benv_p1: &crate::lower::types::Env, menv_p2: &crate::lower::types::Env, tg_p3: &crate::check::env::TagInfo, args_p4: &crate::prelude::Array<crate::syntax::Arg>, fed_p5: &crate::prelude::Array<(crate::prelude::Text, crate::lower::node_::EvRef, crate::lower::model::OutTy)>, out_p6: &crate::lower::model::OutTy, bound_o7: &::std::option::Option<crate::lower::types::Bn>) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    let lx_p8 = wx_p0.lx_p.clone();
    let pos_p9 = wx_p0.pos_p.clone();
    let wx1_pa = {
        let mut this: crate::lower::node_::Wx = wx_p0.clone();
        this.pos_p = crate::lower::model::next_pos_f(&this.pos_p);
        this
    };
    let struct_path_pb = crate::lower::ref_in_f(&lx_p8, &tg_p3.home_p, &crate::lower::tag_struct_of_f(tg_p3));
    let (live_fields_p1e, const_fields_p1f, method_consts_p1g, reads_p1h, wx2_p1i) = crate::prelude::run_to_end(crate::prelude::fold_job(tg_p3.fields_p.clone(), (crate::prelude::Array::new(), crate::prelude::Array::new(), crate::prelude::Array::new(), crate::prelude::Array::new(), wx1_pa.clone()), {
        let args_p4x = args_p4.clone();
        let fed_p5x = fed_p5.clone();
        let tg_p3x = tg_p3.clone();
        let pos_p9x = pos_p9.clone();
        let menv_p2x = menv_p2.clone();
        let lx_p8x = lx_p8.clone();
        let benv_p1x = benv_p1.clone();
        ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Array<(crate::prelude::Text, crate::lower::model::Ex)>, crate::prelude::Array<(crate::prelude::Text, crate::lower::model::Ex)>, crate::prelude::Array<(crate::prelude::Text, crate::lower::model::Ex)>, crate::prelude::Array<crate::lower::node_::Read>, crate::lower::node_::Wx), (crate::prelude::Text, crate::check::types::Ty))| {
            let args_p4xy = args_p4x.clone();
            let fed_p5xy = fed_p5x.clone();
            let tg_p3xy = tg_p3x.clone();
            let pos_p9xy = pos_p9x.clone();
            let menv_p2xy = menv_p2x.clone();
            let lx_p8xy = lx_p8x.clone();
            let benv_p1xy = benv_p1x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (lf_pt, cf_pu, mf_pv, rd_p10, w_p11) = p0;
                let (fname_p12, fty_p13) = p1;
                match tag_arg_o(&args_p4xy, &fname_p12) {
                    ::std::option::Option::None => match fed_event_o(&fed_p5xy, &fname_p12) {
                        ::std::option::Option::Some((r_p14, et_p15)) => ::prism_rtl::Turn::Finished(request_field_into_f(&w_p11, &tg_p3xy, &pos_p9xy, &fname_p12, &fty_p13, &r_p14, &et_p15, &lf_pt, &cf_pu, &mf_pv, &rd_p10)),
                        ::std::option::Option::None => ::prism_rtl::Turn::Finished((lf_pt.clone(), cf_pu.clone(), mf_pv.clone(), rd_p10.clone(), w_p11.clone())),
                    },
                    ::std::option::Option::Some(arg_p16) => match crate::lower::types::layer_of_f(&fty_p13) {
                        crate::lower::types::Layer::LyEv => {
                            let (r_p17, w2_p18) = crate::lower::node_::dynamics::event_ref_f(&w_p11, &menv_p2xy, &arg_p16);
                            crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p8xy.clone(), crate::lower::types::peel_f(&crate::lower::type_at_f(&lx_p8xy, &arg_p16.span_p))), move |out_ty_of_f_5639: crate::lower::model::OutTy| ::prism_rtl::Turn::Finished(request_field_into_f(&w2_p18, &tg_p3xy, &pos_p9xy, &fname_p12, &fty_p13, &r_p17, &out_ty_of_f_5639, &lf_pt, &cf_pu, &mf_pv, &rd_p10)))
                        },
                        _ => crate::prelude::call_then(crate::lower::node_::dynamics::start_dynamic_expr_f(w_p11.clone(), menv_p2xy.clone(), arg_p16.clone()), move |dynamic_expr_f_5771: (crate::lower::model::Ex, crate::prelude::Array<crate::lower::node_::Read>)| {
                            let (ex0_p1c, rds_p1d) = dynamic_expr_f_5771;
                            crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p8xy.clone(), crate::lower::node_::def::init_env_f(&benv_p1xy), arg_p16.clone()), move |value_of_f_6037: crate::lower::types::Vl| crate::prelude::call_then(crate::lower::types::start_recoded_field_f(lx_p8xy.clone(), fty_p13.clone(), crate::lower::types::own_f(&value_of_f_6037)), move |recoded_field_f_6009: crate::lower::model::Ex| {
                                let cv_p19 = recoded_field_f_6009;
                                crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p8xy.clone(), menv_p2xy.clone(), arg_p16.clone()), move |value_of_f_6132: crate::lower::types::Vl| crate::prelude::call_then(crate::lower::types::start_recoded_field_f(lx_p8xy.clone(), fty_p13.clone(), crate::lower::types::own_f(&value_of_f_6132)), move |recoded_field_f_6104: crate::lower::model::Ex| {
                                    let mv_p1a = recoded_field_f_6104;
                                    crate::prelude::call_then(crate::lower::types::start_recoded_field_f(lx_p8xy.clone(), fty_p13.clone(), ex0_p1c.clone()), move |recoded_field_f_6271: crate::lower::model::Ex| {
                                        let ex_p1b = recoded_field_f_6271;
                                        crate::prelude::call_then(crate::lower::start_field_spell_f(tg_p3xy.home_p.clone(), fname_p12.clone(), fty_p13.clone()), move |field_spell_f_6336: crate::prelude::Text| crate::prelude::call_then(crate::lower::start_field_spell_f(tg_p3xy.home_p.clone(), fname_p12.clone(), fty_p13.clone()), move |field_spell_f_6389: crate::prelude::Text| crate::prelude::call_then(crate::lower::start_field_spell_f(tg_p3xy.home_p.clone(), fname_p12.clone(), fty_p13.clone()), move |field_spell_f_6442: crate::prelude::Text| ::prism_rtl::Turn::Finished((crate::prelude::push(&lf_pt, &(field_spell_f_6336, ex_p1b.clone())), crate::prelude::push(&cf_pu, &(field_spell_f_6389, cv_p19.clone())), crate::prelude::push(&mf_pv, &(field_spell_f_6442, mv_p1a.clone())), crate::lower::node_::union_reads_f(&rd_p10, &rds_p1d), w_p11.clone())))))
                                    })
                                }))
                            }))
                        }),
                    },
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Array<(crate::prelude::Text, crate::lower::model::Ex)>, crate::prelude::Array<(crate::prelude::Text, crate::lower::model::Ex)>, crate::prelude::Array<(crate::prelude::Text, crate::lower::model::Ex)>, crate::prelude::Array<crate::lower::node_::Read>, crate::lower::node_::Wx), (crate::prelude::Text, crate::check::types::Ty))) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<(crate::prelude::Text, crate::lower::model::Ex)>, crate::prelude::Array<(crate::prelude::Text, crate::lower::model::Ex)>, crate::prelude::Array<(crate::prelude::Text, crate::lower::model::Ex)>, crate::prelude::Array<crate::lower::node_::Read>, crate::lower::node_::Wx)>>>
    }));
    let late_pc = crate::prelude::run_to_end(crate::prelude::fold_job(args_p4.clone(), false, {
        let menv_p2x = menv_p2.clone();
        ::std::rc::Rc::new(move |(p0, p1): (bool, crate::syntax::Arg)| {
            let menv_p2xy = menv_p2x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let f_p1j = p0;
                let a_p1k = p1;
                if f_p1j {
                    ::prism_rtl::Turn::Finished(true)
                } else {
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::lower::node_::def::ReadsLate { env_p0: menv_p2xy.clone(), e_p1: a_p1k.value_p.clone() }))
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::syntax::Arg)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
    }));
    let live_pd = (&crate::prelude::len(&reads_p1h) > &crate::prelude::Nat::from(0u32)) || late_pc;
    let (getter_p1l, wx3_p1m) = if live_pd {
        crate::lower::node_::fresh_name_f(&wx2_p1i, &crate::lower::snake_f(&crate::check::types::bare_name_f(&tg_p3.name_p)))
    } else {
        (crate::prelude::Text::lit(""), wx2_p1i.clone())
    };
    let variant_pe = crate::lower::program::variant_of_f(&lx_p8, tg_p3);
    let level_pf = crate::lower::model::Ex::XCtor(variant_pe.clone(), crate::prelude::Array::from(vec![crate::lower::model::Ex::XRecord(struct_path_pb.clone(), if live_pd { live_fields_p1e.clone() } else { method_consts_p1g.clone() })]));
    let at_build_pg = crate::lower::model::Ex::XCtor(variant_pe.clone(), crate::prelude::Array::from(vec![crate::lower::model::Ex::XRecord(struct_path_pb.clone(), const_fields_p1f.clone())]));
    let added_ph = if live_pd {
        crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("node"))), getter_p1l.clone(), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx]))
    } else {
        at_build_pg.clone()
    };
    let emits_pi = crate::lower::node_::finish::emits_f(&wx3_p1m, &pos_p9);
    let (entry_p1n, wx3e_p1o) = if emits_pi {
        (crate::prelude::Text::lit(""), wx3_p1m.clone())
    } else {
        crate::lower::node_::fresh_name_f(&wx3_p1m, &crate::prelude::Text::from(format!("entry_{}", &crate::lower::model::place_text_f(&pos_p9))))
    };
    let deep_pj = emits_pi && crate::lower::program::tag_holds_dyn_f(&lx_p8, tg_p3);
    let (watch_p1p, wx3w_p1q) = if deep_pj {
        crate::lower::node_::fresh_name_f(&wx3e_p1o, &crate::prelude::Text::from(format!("watch_{}", &crate::lower::model::place_text_f(&pos_p9))))
    } else {
        (crate::prelude::Text::lit(""), wx3e_p1o.clone())
    };
    let what_pk = crate::prelude::Text::from(format!("place {} ({}) of `{}`", &crate::lower::model::place_text_f(&pos_p9), &tg_p3.name_p, &wx_p0.node_p));
    let const_take_pl = if live_pd {
        crate::prelude::Array::new()
    } else {
        crate::prelude::Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XVar(entry_p1n.clone())), crate::prelude::Text::lit("take"), crate::prelude::Array::from(vec![at_build_pg.clone(), crate::lower::model::Ex::XCx])))])
    };
    let wx3h_pm = if emits_pi {
        wx3w_p1q.clone()
    } else {
        {
            let mut this: crate::lower::node_::Wx = wx3w_p1q.clone();
            this.lets_p = crate::prelude::append(&crate::prelude::push(&this.lets_p, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaBind(entry_p1n.clone())), crate::lower::types::entry_ty_p()), crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("prism_rtl::Entry::new")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XStr(what_pk.clone())])))), &const_take_pl);
            this.fields_p = crate::prelude::push(&this.fields_p, &(entry_p1n.clone(), crate::lower::types::entry_ty_p(), crate::prelude::Text::from(format!("{}, an entry of its host\'s document", &what_pk))));
            this.moves_p = crate::prelude::push(&this.moves_p, &(entry_p1n.clone(), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(entry_p1n.clone())))));
            this
        }
    };
    let wx3d_pn = if deep_pj {
        crate::lower::node_::add_field_last_f(&wx3h_pm, &watch_p1p, &crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("prism_rtl::Watch")), crate::prelude::Array::new()), &crate::prelude::Text::from(format!("the dynamics place {}\'s level holds, watched so a move sends it again (doubt WD)", &crate::lower::model::place_text_f(&pos_p9))), &crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("prism_rtl::Watch::new")), crate::prelude::Array::new()))
    } else {
        wx3h_pm.clone()
    };
    let sent_po = if deep_pj {
        crate::prelude::Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("sent")), added_ph.clone()), crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XCx), crate::prelude::Text::lit("added"), crate::prelude::Array::from(vec![crate::lower::node_::finish::place_at_f(&wx3_p1m, &crate::prelude::Text::lit("node"), &pos_p9), crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("sent"))), crate::prelude::Text::lit("level_pod"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx]))]))), crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("node"))), watch_p1p.clone())), crate::prelude::Text::lit("renew"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("sent")))), crate::lower::model::Ex::XCast(::std::rc::Rc::new(crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("node"))))), crate::lower::model::OutTy::OutObj(::std::rc::Rc::new(crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Node")), crate::prelude::Array::new())))), crate::lower::model::Ex::XCx])))])
    } else {
        crate::prelude::Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XCx), crate::prelude::Text::lit("added"), crate::prelude::Array::from(vec![crate::lower::node_::finish::place_at_f(&wx3_p1m, &crate::prelude::Text::lit("node"), &pos_p9), crate::lower::model::Ex::XMethod(::std::rc::Rc::new(added_ph.clone()), crate::prelude::Text::lit("level_pod"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx]))])))])
    };
    let wx4_pp = {
        let mut this: crate::lower::node_::Wx = wx3d_pn.clone();
        this.places_p = crate::prelude::push(&this.places_p, &crate::lower::node_::Place { pos_p: pos_p9.clone(), level_p: level_pf.clone(), getter_p: getter_p1l.clone(), reads_p: reads_p1h.clone(), entry_p: entry_p1n.clone(), watch_p: watch_p1p.clone() });
        this.build_p = if emits_pi {
            if deep_pj {
                crate::prelude::push(&this.build_p, &crate::lower::model::Do::DoScope(sent_po.clone()))
            } else {
                crate::prelude::append(&this.build_p, &sent_po)
            }
        } else {
            this.build_p.clone()
        };
        this
    };
    let parts_bound_pq = match bound_o7 {
        ::std::option::Option::Some(crate::lower::types::Bn::BnParts(_)) => true,
        _ => false,
    };
    let asks_late_pr = crate::check::types::has_nat_f(&wx4_pp.late_hosts_p, &pos_p9.scope_p) && match &tg_p3.out_p {
        crate::check::types::Ty::TyTuple(cs_p1r) => parts_bound_pq && crate::prelude::fold(cs_p1r, &false, &(|found_p1s: &bool, c_p1t: &crate::check::types::Ty| *found_p1s || (&crate::lower::types::layer_of_f(c_p1t) != &crate::lower::types::Layer::LyEv))),
        other_p1u => !parts_bound_pq && ((&crate::lower::types::layer_of_f(other_p1u) == &crate::lower::types::Layer::LyDyn) || crate::lower::node_::switch_::is_some_f(&crate::lower::node_::def::late_plain_hold_o(bound_o7))),
    };
    let asks_at_row_ps = ((late_pc && !parts_bound_pq) && crate::lower::node_::finish::emits_f(&wx4_pp, &pos_p9)) && crate::lower::node_::switch_::is_some_f(&crate::lower::node_::def::late_plain_hold_o(bound_o7));
    element_output_f(&wx4_pp, menv_p2, tg_p3, out_p6, &pos_p9, bound_o7, &(if asks_at_row_ps {
        crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), getter_p1l.clone(), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx]))
    } else {
        if late_pc && asks_late_pr { added_ph.clone() } else { at_build_pg.clone() }
    }))
}

/// ```prism
/// ElementOut: unbounded fn Lx, TagInfo, Ty -> OutTy
/// ```
pub fn element_out_f(lx_p0: &crate::lower::Lx, tg_p1: &crate::check::env::TagInfo, full_p2: &crate::check::types::Ty) -> crate::lower::model::OutTy {
    let t_p3 = match crate::lower::types::peel_f(full_p2) {
        crate::check::types::Ty::TyElem(_, o_p4) => crate::lower::types::out_ty_of_f(lx_p0, &crate::lower::types::peel_f(&*o_p4)),
        _ => crate::lower::types::out_ty_of_f(lx_p0, &crate::lower::types::peel_f(&tg_p1.out_p)),
    };
    crate::lower::types::erased_out_f(&t_p3)
}

/// ```prism
/// TagNameOf: fn Lx, Expr -> Text
/// ```
pub fn tag_name_of_f(lx_p0: &crate::lower::Lx, c_p1: &crate::syntax::Expr) -> crate::prelude::Text {
    match &*c_p1.kind_p {
        crate::syntax::ExprKind::EName(n_p2) => {
            let (qk_o3, _) = crate::check::env::names::resolve_value_f(&lx_p0.g_p, &lx_p0.home_p, n_p2);
            crate::prelude::or(&qk_o3, &crate::check::env::dotted_f(&n_p2.path_p))
        },
        crate::syntax::ExprKind::EGroup(x_p4) => tag_name_of_f(lx_p0, &**x_p4),
        _ => crate::prelude::Text::lit(""),
    }
}

/// ```prism
/// ?TagArg: fn [Arg], Text -> ?Expr
/// ```
pub fn tag_arg_o(args_p0: &crate::prelude::Array<crate::syntax::Arg>, fname_p1: &crate::prelude::Text) -> ::std::option::Option<crate::syntax::Expr> {
    crate::prelude::fold(args_p0, &::std::option::Option::None, &(|found_o2: &::std::option::Option<crate::syntax::Expr>, a_p3: &crate::syntax::Arg| match &a_p3.name_o {
        ::std::option::Option::Some(n_p4) => if &n_p4.name_p == fname_p1 {
            ::std::option::Option::Some(a_p3.value_p.clone())
        } else {
            found_o2.clone()
        },
        ::std::option::Option::None => found_o2.clone(),
    }))
}

/// ```prism
/// RequestField: fn TagInfo, Text -> Text
/// ```
pub fn request_field_f(tg_p0: &crate::check::env::TagInfo, fname_p1: &crate::prelude::Text) -> crate::prelude::Text {
    let evs_p2 = crate::prelude::filter(&tg_p0.fields_p, &(|(_, t_p3): &(crate::prelude::Text, crate::check::types::Ty)| &crate::lower::types::layer_of_f(t_p3) == &crate::lower::types::Layer::LyEv));
    if &crate::prelude::len(&evs_p2) > &crate::prelude::Nat::from(1u32) {
        fname_p1.clone()
    } else {
        crate::prelude::Text::lit("")
    }
}

/// ```prism
/// ElementOutput: unbounded fn Wx, Env, TagInfo, OutTy, Pos, ?Bn, Ex -> ((Wx, Wres))
/// ```
pub fn element_output_f(wx_p0: &crate::lower::node_::Wx, menv_p1: &crate::lower::types::Env, tg_p2: &crate::check::env::TagInfo, out_p3: &crate::lower::model::OutTy, pos_p4: &crate::lower::model::Pos, bound_o5: &::std::option::Option<crate::lower::types::Bn>, level_p6: &crate::lower::model::Ex) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    let lx_p7 = wx_p0.lx_p.clone();
    match bound_o5 {
        ::std::option::Option::Some(crate::lower::types::Bn::BnParts(parts_p8)) => bundle_output_f(wx_p0, tg_p2, out_p3, pos_p4, parts_p8, level_p6),
        _ => element_output_of_f(wx_p0, menv_p1, tg_p2, out_p3, pos_p4, bound_o5, level_p6),
    }
}

/// ```prism
/// BundleOutput: unbounded fn Wx, TagInfo, OutTy, Pos, [?Bn], Ex -> ((Wx, Wres))
/// ```
pub fn bundle_output_f(wx_p0: &crate::lower::node_::Wx, tg_p1: &crate::check::env::TagInfo, out_p2: &crate::lower::model::OutTy, pos_p3: &crate::lower::model::Pos, parts_p4: &crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>, level_p5: &crate::lower::model::Ex) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    bundle_output_of_f(wx_p0, tg_p1, out_p2, pos_p3, parts_p4, level_p5)
}

/// ```prism
/// BundleOutputOf: unbounded fn Wx, TagInfo, OutTy, Pos, [?Bn], Ex -> ((Wx, Wres))
/// ```
pub fn bundle_output_of_f(wx_p0: &crate::lower::node_::Wx, tg_p1: &crate::check::env::TagInfo, out_p2: &crate::lower::model::OutTy, pos_p3: &crate::lower::model::Pos, parts_p4: &crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>, level_p5: &crate::lower::model::Ex) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    let layers_p6 = match &tg_p1.out_p {
        crate::check::types::Ty::TyTuple(cs_pp) => crate::prelude::each(cs_pp, &(|c_pq: &crate::check::types::Ty| crate::lower::types::layer_of_f(c_pq))),
        _ => crate::prelude::Array::new(),
    };
    let tys_p7 = match out_p2 {
        crate::lower::model::OutTy::OutTuple(ts_pr) => ts_pr.clone(),
        _ => crate::prelude::Array::new(),
    };
    let idx_p8 = crate::check::errors::range0_f(&crate::prelude::len(&layers_p6));
    let state_ix_p9 = crate::prelude::filter(&idx_p8, &(|i_ps: &crate::prelude::Nat| &crate::prelude::or(&crate::prelude::index(&layers_p6, i_ps), &crate::lower::types::Layer::LyPlain) != &crate::lower::types::Layer::LyEv));
    let ev_ix_pa = crate::prelude::filter(&idx_p8, &(|i_pt: &crate::prelude::Nat| &crate::prelude::or(&crate::prelude::index(&layers_p6, i_pt), &crate::lower::types::Layer::LyPlain) == &crate::lower::types::Layer::LyEv));
    let value_ty_fb = {
        let tys_p7x = tys_p7.clone();
        ::std::rc::Rc::new(move |i_pu: &crate::prelude::Nat| match crate::prelude::or(&crate::prelude::index(&tys_p7x, i_pu), &crate::lower::model::OutTy::OutUnit) {
            crate::lower::model::OutTy::OutDyn(inner_pv) => (*inner_pv).clone(),
            crate::lower::model::OutTy::OutEvent(inner_p10) => (*inner_p10).clone(),
            other_p11 => other_p11,
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(&crate::prelude::Nat) -> crate::lower::model::OutTy>
    };
    let (wx1_p17, events_p18) = crate::prelude::fold(&ev_ix_pa, &(wx_p0.clone(), crate::prelude::Array::new()), &(|(w_p12, acc_p13): &(crate::lower::node_::Wx, crate::prelude::Array<(crate::prelude::Nat, crate::lower::model::OutTy)>), i_p14: &crate::prelude::Nat| {
        let (id_p15, w2_p16) = bundle_event_f(w_p12, pos_p3, &(&value_ty_fb)(i_p14), &crate::prelude::or(&crate::prelude::index(parts_p4, i_p14), &::std::option::Option::None));
        (w2_p16.clone(), crate::prelude::push(acc_p13, &(id_p15.clone(), (&value_ty_fb)(i_p14))))
    }));
    let one_pc = &crate::prelude::len(&state_ix_p9) == &crate::prelude::Nat::from(1u32);
    let state_ty_pd = if one_pc {
        (&value_ty_fb)(&crate::prelude::or(&crate::prelude::index(&state_ix_p9, &crate::prelude::Nat::from(0u32)), &crate::prelude::Nat::from(0u32)))
    } else {
        crate::lower::model::OutTy::OutTuple(crate::prelude::each(&state_ix_p9, &*value_ty_fb))
    };
    let whole_pe = crate::prelude::Text::from(format!("bundle_{}", &crate::lower::model::place_text_f(pos_p3)));
    let late_pf = (&crate::prelude::len(&state_ix_p9) > &crate::prelude::Nat::from(0u32)) && crate::check::types::has_nat_f(&wx_p0.late_hosts_p, &pos_p3.scope_p);
    let whole_lets_pg = crate::prelude::Array::from(vec![first_value_let_f(&wx1_p17, pos_p3, tg_p1, level_p5, &state_ty_pd), crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(whole_pe.clone()), if crate::lower::node_::finish::emits_f(&wx1_p17, pos_p3) {
        crate::lower::model::Ex::XDecode(state_ty_pd.clone(), ::std::rc::Rc::new(crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::from(format!("first_{}", &crate::lower::model::place_text_f(pos_p3))))))))
    } else {
        crate::lower::model::Ex::XVar(crate::prelude::Text::from(format!("first_{}", &crate::lower::model::place_text_f(pos_p3))))
    })]);
    let asks_late_ph = {
        let mut this: crate::lower::node_::Wx = wx1_p17.clone();
        this.late_firsts_p = crate::prelude::push(&this.late_firsts_p, &(pos_p3.scope_p.clone(), whole_lets_pg.clone()));
        this.fallible_p = true;
        this
    };
    let wx2_pi = if &crate::prelude::len(&state_ix_p9) == &crate::prelude::Nat::from(0u32) {
        wx1_p17.clone()
    } else {
        if late_pf {
            asks_late_ph.clone()
        } else {
            {
                let mut this: crate::lower::node_::Wx = wx1_p17.clone();
                this.lets_p = crate::prelude::append(&this.lets_p, &whole_lets_pg);
                this.fallible_p = true;
                this
            }
        }
    };
    let (wx3_p1o, holds_p1p) = crate::prelude::fold(&crate::check::errors::range0_f(&crate::prelude::len(&state_ix_p9)), &(wx2_pi.clone(), crate::prelude::Array::new()), &(|(w_p19, acc_p1a): &(crate::lower::node_::Wx, crate::prelude::Array<(crate::prelude::Nat, crate::prelude::Text, crate::lower::model::OutTy)>), k_p1b: &crate::prelude::Nat| {
        let i_p1c = crate::prelude::or(&crate::prelude::index(&state_ix_p9, k_p1b), &crate::prelude::Nat::from(0u32));
        let part_p1d = if one_pc {
            crate::lower::model::Ex::XVar(whole_pe.clone())
        } else {
            crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XPart(::std::rc::Rc::new(crate::lower::model::Ex::XVar(whole_pe.clone())), k_p1b.clone())))
        };
        if late_pf && (&crate::prelude::or(&crate::prelude::index(&layers_p6, &i_p1c), &crate::lower::types::Layer::LyPlain) == &crate::lower::types::Layer::LyDyn) {
            {
                let (f_p1f, w1_p1g) = match crate::lower::node_::def::late_place_hold_o(&crate::prelude::or(&crate::prelude::index(parts_p4, &i_p1c), &::std::option::Option::None)) {
                    ::std::option::Option::Some(hf_p1e) => (hf_p1e, w_p19.clone()),
                    ::std::option::Option::None => crate::lower::node_::fresh_name_f(w_p19, &crate::prelude::Text::from(format!("place_{}", &crate::lower::model::place_text_f(pos_p3)))),
                };
                (late_first_place_f(&w1_p1g, pos_p3, &f_p1f, &(&value_ty_fb)(&i_p1c), &crate::prelude::Array::from(vec![late_first_set_f(&f_p1f, &part_p1d)])), crate::prelude::push(acc_p1a, &(k_p1b.clone(), f_p1f.clone(), (&value_ty_fb)(&i_p1c))))
            }
        } else {
            if late_pf {
                (late_plain_part_f(w_p19, pos_p3, &crate::prelude::or(&crate::prelude::index(parts_p4, &i_p1c), &::std::option::Option::None), &i_p1c, &(&value_ty_fb)(&i_p1c), &part_p1d), acc_p1a.clone())
            } else {
                if &crate::prelude::or(&crate::prelude::index(&layers_p6, &i_p1c), &crate::lower::types::Layer::LyPlain) == &crate::lower::types::Layer::LyDyn {
                    {
                        let (f_p1j, w1_p1k) = match crate::prelude::index(parts_p4, &i_p1c) {
                            ::std::option::Option::Some(::std::option::Option::Some(crate::lower::types::Bn::BnHold(hf_p1i, _))) => (hf_p1i, w_p19.clone()),
                            _ => crate::lower::node_::fresh_name_f(w_p19, &crate::prelude::Text::from(format!("place_{}", &crate::lower::model::place_text_f(pos_p3)))),
                        };
                        let w2_p1h = {
                            let mut this: crate::lower::node_::Wx = w1_p1k.clone();
                            this.lets_p = crate::prelude::push(&this.lets_p, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaBind(crate::prelude::Text::from(format!("{}_init", &f_p1j)))), (&value_ty_fb)(&i_p1c)), part_p1d.clone()));
                            this.fields_p = crate::prelude::push(&this.fields_p, &(f_p1j.clone(), crate::lower::model::OutTy::OutHold(::std::rc::Rc::new((&value_ty_fb)(&i_p1c))), crate::prelude::Text::from(format!("pushed to place {}, part {} of its answer", &crate::lower::model::place_text_f(pos_p3), &i_p1c))));
                            this.inits_p = crate::prelude::push(&this.inits_p, &(f_p1j.clone(), crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Hold::new")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::from(format!("{}_init", &f_p1j))))), crate::lower::model::Ex::XCx]))));
                            this
                        };
                        (w2_p1h.clone(), crate::prelude::push(acc_p1a, &(k_p1b.clone(), f_p1j.clone(), (&value_ty_fb)(&i_p1c))))
                    }
                } else {
                    match crate::prelude::index(parts_p4, &i_p1c) {
                        ::std::option::Option::Some(::std::option::Option::Some(crate::lower::types::Bn::BnLocal(rs_p1l, _, _))) => {
                            let f_p1m = crate::lower::types::place_stem_f(&rs_p1l);
                            let w2_p1n = {
                                let mut this: crate::lower::node_::Wx = w_p19.clone();
                                this.lets_p = crate::prelude::push(&this.lets_p, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(f_p1m.clone()), part_p1d.clone()));
                                this.fields_p = crate::prelude::push(&this.fields_p, &(f_p1m.clone(), (&value_ty_fb)(&i_p1c), crate::prelude::Text::from(format!("place {}\'s answer, part {}, read from its first value", &crate::lower::model::place_text_f(pos_p3), &i_p1c))));
                                this.inits_p = crate::prelude::push(&this.inits_p, &(f_p1m.clone(), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(f_p1m.clone())))));
                                this
                            };
                            (w2_p1n.clone(), acc_p1a.clone())
                        },
                        _ => (w_p19.clone(), acc_p1a.clone()),
                    }
                }
            }
        }
    }));
    let stem_pj = match crate::prelude::index(&holds_p1p, &crate::prelude::Nat::from(0u32)) {
        ::std::option::Option::Some((_, f_p1q, _)) => f_p1q,
        ::std::option::Option::None => crate::prelude::Text::lit(""),
    };
    let wx4_pk = if (&stem_pj == &crate::prelude::Text::lit("")) || !crate::lower::node_::finish::emits_f(&wx3_p1o, pos_p3) {
        wx3_p1o.clone()
    } else {
        {
            let mut this: crate::lower::node_::Wx = wx3_p1o.clone();
            this.lets_p = crate::prelude::push(&this.lets_p, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::prelude::Text::from(format!("{}_element", &stem_pj))), crate::lower::model::Ex::XMethod(::std::rc::Rc::new(level_p5.clone()), crate::prelude::Text::lit("to_pod"), crate::prelude::Array::new())));
            this.fields_p = crate::prelude::push(&this.fields_p, &(crate::prelude::Text::from(format!("{}_element", &stem_pj)), crate::lower::model::OutTy::OutPod, crate::prelude::Text::from(format!("place {}\'s element, which pushes are keyed by", &crate::lower::model::place_text_f(pos_p3)))));
            this.moves_p = crate::prelude::push(&this.moves_p, &(crate::prelude::Text::from(format!("{}_element", &stem_pj)), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::from(format!("{}_element", &stem_pj)))))));
            this.build_p = crate::prelude::push(&this.build_p, &crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XCx), crate::prelude::Text::lit("listen"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("node"))), crate::prelude::Text::from(format!("{}_element", &stem_pj))))), crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XCast(::std::rc::Rc::new(crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("node"))))), crate::lower::model::OutTy::OutObj(::std::rc::Rc::new(crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Node")), crate::prelude::Array::new()))))))]))));
            this
        }
    };
    let wx5_pl = {
        let mut this: crate::lower::node_::Wx = wx4_pk.clone();
        this.bundles_p = crate::prelude::push(&this.bundles_p, &crate::lower::node_::BundlePlace { pos_p: pos_p3.clone(), stem_p: stem_pj.clone(), state_ty_p: state_ty_pd.clone(), state_parts_p: crate::prelude::len(&state_ix_p9), holds_p: holds_p1p.clone(), events_p: events_p18.clone(), state_accessor_p: if &crate::prelude::len(&ev_ix_pa) == &crate::prelude::Nat::from(0u32) {
            answer_accessor_f(tg_p1)
        } else {
            crate::prelude::Text::from(format!("{}_first", &answer_accessor_f(tg_p1)))
        }, event_accessor_p: answer_accessor_f(tg_p1), first_variant_p: answer_first_variant_f(tg_p1) });
        this
    };
    let loose_pm = crate::prelude::filter(&crate::check::errors::range0_f(&crate::prelude::len(&state_ix_p9)), &(|k_p1r: &crate::prelude::Nat| (!late_pf && (&crate::prelude::or(&crate::prelude::index(&layers_p6, &crate::prelude::or(&crate::prelude::index(&state_ix_p9, k_p1r), &crate::prelude::Nat::from(0u32))), &crate::lower::types::Layer::LyPlain) != &crate::lower::types::Layer::LyDyn)) && is_unbound_part_f(&crate::prelude::index(parts_p4, &crate::prelude::or(&crate::prelude::index(&state_ix_p9, k_p1r), &crate::prelude::Nat::from(0u32))))));
    let part_at_fn = {
        let loose_pmx = loose_pm.clone();
        let state_ix_p9x = state_ix_p9.clone();
        let one_pcx = one_pc;
        let whole_pex = whole_pe.clone();
        let value_ty_fbx = value_ty_fb.clone();
        ::std::rc::Rc::new(move |i_p1s: &crate::prelude::Nat| crate::prelude::fold(&loose_pmx, &crate::lower::node_::Wres::WrUnit, &(|found_p1t: &crate::lower::node_::Wres, k_p1u: &crate::prelude::Nat| if &crate::prelude::or(&crate::prelude::index(&state_ix_p9x, k_p1u), &crate::prelude::Nat::from(0u32)) == i_p1s {
            crate::lower::node_::Wres::WrPlain(if one_pcx {
                crate::lower::model::Ex::XVar(whole_pex.clone())
            } else {
                crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XPart(::std::rc::Rc::new(crate::lower::model::Ex::XVar(whole_pex.clone())), k_p1u.clone())))
            }, (&value_ty_fbx)(i_p1s))
        } else {
            found_p1t.clone()
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn(&crate::prelude::Nat) -> crate::lower::node_::Wres>
    };
    let result_po = if &crate::prelude::len(&loose_pm) == &crate::prelude::Nat::from(0u32) {
        crate::lower::node_::Wres::WrUnit
    } else {
        crate::lower::node_::Wres::WrParts(crate::prelude::each(&idx_p8, &*part_at_fn))
    };
    (wx5_pl.clone(), result_po.clone())
}

/// ```prism
/// IsUnboundPart: fn ??Bn -> Bool
/// ```
pub fn is_unbound_part_f(opt0: &::std::option::Option<::std::option::Option<crate::lower::types::Bn>>) -> bool {
    match opt0 {
        ::std::option::Option::Some(::std::option::Option::Some(_)) => false,
        other_o0 => true,
    }
}

/// ```prism
/// LatePlainPart: fn Wx, Pos, ?Bn, Nat, OutTy, Ex -> Wx
/// ```
pub fn late_plain_part_f(wx_p0: &crate::lower::node_::Wx, pos_p1: &crate::lower::model::Pos, bound_o2: &::std::option::Option<crate::lower::types::Bn>, i_p3: &crate::prelude::Nat, t_p4: &crate::lower::model::OutTy, part_p5: &crate::lower::model::Ex) -> crate::lower::node_::Wx {
    match crate::lower::node_::def::late_plain_hold_o(bound_o2) {
        ::std::option::Option::Some(f_p6) => {
            let mut this: crate::lower::node_::Wx = wx_p0.clone();
            this.fields_p = crate::prelude::push(&this.fields_p, &(f_p6.clone(), crate::lower::model::OutTy::OutHold(::std::rc::Rc::new(crate::lower::model::OutTy::OutOpt(::std::rc::Rc::new(t_p4.clone())))), crate::prelude::Text::from(format!("place {}\'s answer, part {}, read from its first value: empty until that is asked, once the node stands", &crate::lower::model::place_text_f(pos_p1), i_p3))));
            this.moves_p = crate::prelude::push(&this.moves_p, &(f_p6.clone(), crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Hold::new")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XNone, crate::lower::model::Ex::XCx]))));
            this.late_firsts_p = crate::prelude::push(&this.late_firsts_p, &(pos_p1.scope_p.clone(), crate::prelude::Array::from(vec![late_first_set_f(&f_p6, part_p5)])));
            this
        },
        ::std::option::Option::None => wx_p0.clone(),
    }
}

/// ```prism
/// BundleEvent: fn Wx, Pos, OutTy, ?Bn -> ((Nat, Wx))
/// ```
pub fn bundle_event_f(wx_p0: &crate::lower::node_::Wx, pos_p1: &crate::lower::model::Pos, t_p2: &crate::lower::model::OutTy, b_o3: &::std::option::Option<crate::lower::types::Bn>) -> (crate::prelude::Nat, crate::lower::node_::Wx) {
    match b_o3 {
        ::std::option::Option::Some(crate::lower::types::Bn::BnEv(er_p4, _)) => (er_p4.node_p.clone(), wx_p0.clone()),
        _ => {
            let (nm_p5, w_p6) = crate::lower::node_::fresh_name_f(wx_p0, &crate::prelude::Text::from(format!("place_{}", &crate::lower::model::place_text_f(pos_p1))));
            crate::lower::node_::add_gn_f(&w_p6, &nm_p5, t_p2, &crate::lower::node_::GnKind::GnAnswer, &crate::prelude::Nat::from(0u32))
        },
    }
}

/// ```prism
/// FirstValueLet: unbounded fn Wx, Pos, TagInfo, Ex, OutTy -> Do
/// ```
pub fn first_value_let_f(wx_p0: &crate::lower::node_::Wx, pos_p1: &crate::lower::model::Pos, tg_p2: &crate::check::env::TagInfo, level_p3: &crate::lower::model::Ex, placed_p4: &crate::lower::model::OutTy) -> crate::lower::model::Do {
    let missing_p5 = crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Fault::answer")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XStr(crate::prelude::Text::from(format!("no first value for {}", &tg_p2.name_p)))]));
    if crate::lower::node_::finish::emits_f(wx_p0, pos_p1) {
        {
            let asked_p6 = crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XCx), crate::prelude::Text::lit("first_value"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(level_p3.clone()), crate::prelude::Text::lit("to_pod"), crate::prelude::Array::new())))]));
            crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::prelude::Text::from(format!("first_{}", &crate::lower::model::place_text_f(pos_p1)))), crate::lower::expr::try_of_f(&crate::lower::model::Ex::XMethod(::std::rc::Rc::new(asked_p6.clone()), crate::prelude::Text::lit("ok_or"), crate::prelude::Array::from(vec![missing_p5.clone()]))))
        }
    } else {
        {
            let host_p7 = host_local_f(wx_p0, pos_p1);
            let entry_p8 = crate::prelude::or(&crate::prelude::fold(&wx_p0.places_p, &::std::option::Option::None, &(|e_oc: &::std::option::Option<crate::prelude::Text>, pl_pd: &crate::lower::node_::Place| if &pl_pd.pos_p == pos_p1 {
                ::std::option::Option::Some(pl_pd.entry_p.clone())
            } else {
                e_oc.clone()
            })), &crate::prelude::Text::lit(""));
            let asked_p9 = crate::lower::expr::try_of_f(&crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XVar(host_p7.clone())), crate::prelude::Text::lit("first_value"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::node_::finish::place_at_f(wx_p0, &crate::prelude::Text::lit(""), pos_p1))), crate::lower::model::Ex::XRef(::std::rc::Rc::new(level_p3.clone())), crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XVar(entry_p8.clone()))), crate::lower::model::Ex::XCx])));
            let accessor_pa = if is_bundle_tag_f(tg_p2) {
                crate::prelude::Text::from(format!("{}_first", &answer_accessor_f(tg_p2)))
            } else {
                answer_accessor_f(tg_p2)
            };
            let carried_pb = if is_bundle_tag_f(tg_p2) {
                crate::prelude::or(&crate::lower::program::bundle_first_ty_o(&wx_p0.lx_p, tg_p2), &crate::lower::model::OutTy::OutUnit)
            } else {
                crate::lower::program::answer_ty_f(&wx_p0.lx_p, tg_p2)
            };
            crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::prelude::Text::from(format!("first_{}", &crate::lower::model::place_text_f(pos_p1)))), crate::lower::program::recoded_answer_f(&crate::lower::program::answer_open_f(&wx_p0.lx_p, tg_p2), &carried_pb, placed_p4, &crate::lower::expr::try_of_f(&crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::expr::try_of_f(&crate::lower::model::Ex::XMethod(::std::rc::Rc::new(asked_p9.clone()), crate::prelude::Text::lit("ok_or"), crate::prelude::Array::from(vec![missing_p5.clone()])))), accessor_pa.clone(), crate::prelude::Array::new()))))
        }
    }
}

/// ```prism
/// HostLocal: fn Wx, Pos -> Text
/// ```
pub fn host_local_f(wx_p0: &crate::lower::node_::Wx, pos_p1: &crate::lower::model::Pos) -> crate::prelude::Text {
    if &pos_p1.scope_p == &crate::prelude::Nat::from(0u32) {
        crate::prelude::Text::lit("enclosing")
    } else {
        crate::prelude::or(&crate::prelude::index(&wx_p0.scopes_p, &crate::syntax::lexer::chars::dec_f(&pos_p1.scope_p)), &crate::prelude::Text::lit(""))
    }
}

/// ```prism
/// AnswerVariant: fn TagInfo -> Ref
/// ```
pub fn answer_variant_f(tg_p0: &crate::check::env::TagInfo) -> crate::lower::model::Ref {
    crate::lower::model::ref_child_f(&crate::lower::model::answer_ref_p(), &crate::lower::tag_struct_f(&tg_p0.name_p))
}

/// ```prism
/// IsBundleTag: fn TagInfo -> Bool
/// ```
pub fn is_bundle_tag_f(tg_p0: &crate::check::env::TagInfo) -> bool {
    match crate::lower::types::peel_f(&tg_p0.out_p) {
        crate::check::types::Ty::TyTuple(cs_p1) => crate::prelude::fold(&cs_p1, &false, &(|f_p2: &bool, c_p3: &crate::check::types::Ty| *f_p2 || (&crate::lower::types::layer_of_f(c_p3) == &crate::lower::types::Layer::LyEv))) && crate::prelude::fold(&cs_p1, &false, &(|f_p4: &bool, c_p5: &crate::check::types::Ty| *f_p4 || (&crate::lower::types::layer_of_f(c_p5) != &crate::lower::types::Layer::LyEv))),
        _ => false,
    }
}

/// ```prism
/// AnswerFirstVariant: fn TagInfo -> Ref
/// ```
pub fn answer_first_variant_f(tg_p0: &crate::check::env::TagInfo) -> crate::lower::model::Ref {
    crate::lower::model::ref_child_f(&crate::lower::model::answer_ref_p(), &crate::prelude::Text::from(format!("{}First", &crate::lower::tag_struct_f(&tg_p0.name_p))))
}

/// ```prism
/// AnswerAccessor: fn TagInfo -> Text
/// ```
pub fn answer_accessor_f(tg_p0: &crate::check::env::TagInfo) -> crate::prelude::Text {
    crate::lower::snake_f(&crate::lower::tag_struct_f(&tg_p0.name_p))
}

/// ```prism
/// DynamicPlace: unbounded fn Wx, TagInfo, OutTy, Pos, Text, Ex, Text -> Wx
/// ```
pub fn dynamic_place_f(wx1_p0: &crate::lower::node_::Wx, tg_p1: &crate::check::env::TagInfo, out_p2: &crate::lower::model::OutTy, pos_p3: &crate::lower::model::Pos, f_p4: &crate::prelude::Text, level_p5: &crate::lower::model::Ex, accessor_p6: &crate::prelude::Text) -> crate::lower::node_::Wx {
    let emits_p7 = crate::lower::node_::finish::emits_f(wx1_p0, pos_p3);
    let first_p8 = if emits_p7 {
        crate::lower::model::Ex::XDecode(out_p2.clone(), ::std::rc::Rc::new(crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::from(format!("first_{}", &crate::lower::model::place_text_f(pos_p3))))))))
    } else {
        crate::lower::model::Ex::XVar(crate::prelude::Text::from(format!("first_{}", &crate::lower::model::place_text_f(pos_p3))))
    };
    let wx2_p9 = {
        let mut this: crate::lower::node_::Wx = wx1_p0.clone();
        this.lets_p = crate::prelude::append(&this.lets_p, &crate::prelude::Array::from(vec![first_value_let_f(wx1_p0, pos_p3, tg_p1, level_p5, out_p2), crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaBind(crate::prelude::Text::from(format!("{}_init", f_p4)))), out_p2.clone()), first_p8.clone())]));
        this.fields_p = crate::prelude::push(&this.fields_p, &(f_p4.clone(), crate::lower::model::OutTy::OutHold(::std::rc::Rc::new(out_p2.clone())), crate::prelude::Text::from(format!("pushed to place {}", &crate::lower::model::place_text_f(pos_p3)))));
        this.inits_p = crate::prelude::push(&this.inits_p, &(f_p4.clone(), crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Hold::new")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::from(format!("{}_init", f_p4))))), crate::lower::model::Ex::XCx]))));
        this.dyn_places_p = crate::prelude::push(&this.dyn_places_p, &(pos_p3.clone(), f_p4.clone(), out_p2.clone(), accessor_p6.clone()));
        this.fallible_p = true;
        this
    };
    if emits_p7 {
        {
            let mut this: crate::lower::node_::Wx = wx2_p9.clone();
            this.lets_p = crate::prelude::push(&this.lets_p, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::prelude::Text::from(format!("{}_element", f_p4))), crate::lower::model::Ex::XMethod(::std::rc::Rc::new(level_p5.clone()), crate::prelude::Text::lit("to_pod"), crate::prelude::Array::new())));
            this.fields_p = crate::prelude::push(&this.fields_p, &(crate::prelude::Text::from(format!("{}_element", f_p4)), crate::lower::model::OutTy::OutPod, crate::prelude::Text::from(format!("place {}\'s element, which pushes are keyed by", &crate::lower::model::place_text_f(pos_p3)))));
            this.moves_p = crate::prelude::push(&this.moves_p, &(crate::prelude::Text::from(format!("{}_element", f_p4)), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::from(format!("{}_element", f_p4)))))));
            this.build_p = crate::prelude::push(&this.build_p, &crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XCx), crate::prelude::Text::lit("listen"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("node"))), crate::prelude::Text::from(format!("{}_element", f_p4))))), crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XCast(::std::rc::Rc::new(crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("node"))))), crate::lower::model::OutTy::OutObj(::std::rc::Rc::new(crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Node")), crate::prelude::Array::new()))))))]))));
            this
        }
    } else {
        wx2_p9.clone()
    }
}

/// ```prism
/// LateFirstPlace: fn Wx, Pos, Text, OutTy, [Do] -> Wx
/// ```
pub fn late_first_place_f(wx_p0: &crate::lower::node_::Wx, pos_p1: &crate::lower::model::Pos, f_p2: &crate::prelude::Text, t_p3: &crate::lower::model::OutTy, asked_p4: &crate::prelude::Array<crate::lower::model::Do>) -> crate::lower::node_::Wx {
    let mut this: crate::lower::node_::Wx = late_first_hold_f(wx_p0, pos_p1, f_p2, t_p3);
    this.late_firsts_p = crate::prelude::push(&this.late_firsts_p, &(pos_p1.scope_p.clone(), asked_p4.clone()));
    this
}

/// ```prism
/// LateFirstHold: fn Wx, Pos, Text, OutTy -> Wx
/// ```
pub fn late_first_hold_f(wx_p0: &crate::lower::node_::Wx, pos_p1: &crate::lower::model::Pos, f_p2: &crate::prelude::Text, t_p3: &crate::lower::model::OutTy) -> crate::lower::node_::Wx {
    let mut this: crate::lower::node_::Wx = wx_p0.clone();
    this.fields_p = crate::prelude::push(&this.fields_p, &(f_p2.clone(), crate::lower::model::OutTy::OutHold(::std::rc::Rc::new(crate::lower::model::OutTy::OutOpt(::std::rc::Rc::new(t_p3.clone())))), crate::prelude::Text::from(format!("pushed to place {}, empty until its first value is asked, once the node stands", &crate::lower::model::place_text_f(pos_p1)))));
    this.moves_p = crate::prelude::push(&this.moves_p, &(f_p2.clone(), crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Hold::new")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XNone, crate::lower::model::Ex::XCx]))));
    this.late_places_p = crate::prelude::push(&this.late_places_p, f_p2);
    this.fallible_p = true;
    this
}

/// ```prism
/// LateFirstSet: fn Text, Ex -> Do
/// ```
pub fn late_first_set_f(f_p0: &crate::prelude::Text, first_p1: &crate::lower::model::Ex) -> crate::lower::model::Do {
    crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("node"))), f_p0.clone())), crate::prelude::Text::lit("set"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Some")), crate::prelude::Array::from(vec![first_p1.clone()])), crate::lower::model::Ex::XCx])))
}

/// ```prism
/// ElementOutputOf: unbounded fn Wx, Env, TagInfo, OutTy, Pos, ?Bn, Ex -> ((Wx, Wres))
/// ```
pub fn element_output_of_f(wx_p0: &crate::lower::node_::Wx, menv_p1: &crate::lower::types::Env, tg_p2: &crate::check::env::TagInfo, out_p3: &crate::lower::model::OutTy, pos_p4: &crate::lower::model::Pos, bound_o5: &::std::option::Option<crate::lower::types::Bn>, level_p6: &crate::lower::model::Ex) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    let lx_p7 = wx_p0.lx_p.clone();
    match crate::lower::types::layer_of_f(&tg_p2.out_p) {
        crate::lower::types::Layer::LyEv => {
            let (id_pc, wx2_pd) = match bound_o5 {
                ::std::option::Option::Some(crate::lower::types::Bn::BnEv(er_p9, _)) => (er_p9.node_p.clone(), wx_p0.clone()),
                _ => {
                    let (nm_pa, w_pb) = crate::lower::node_::fresh_name_f(wx_p0, &crate::prelude::Text::from(format!("place_{}", &crate::lower::model::place_text_f(pos_p4))));
                    crate::lower::node_::add_gn_f(&w_pb, &nm_pa, out_p3, &crate::lower::node_::GnKind::GnAnswer, &crate::prelude::Nat::from(0u32))
                },
            };
            let wx3_p8 = {
                let mut this: crate::lower::node_::Wx = wx2_pd.clone();
                this.answers_p = crate::prelude::push(&this.answers_p, &(pos_p4.clone(), id_pc.clone(), out_p3.clone(), answer_accessor_f(tg_p2)));
                this
            };
            (wx3_p8.clone(), crate::lower::node_::Wres::WrEv(crate::lower::node_::ev_ref_of_f(&wx3_p8, &id_pc)))
        },
        crate::lower::types::Layer::LyDyn if crate::check::types::has_nat_f(&wx_p0.late_hosts_p, &pos_p4.scope_p) => {
            let (f_ph, wx1_pi) = match crate::lower::node_::def::late_place_hold_o(bound_o5) {
                ::std::option::Option::Some(hf_pg) => (hf_pg, wx_p0.clone()),
                ::std::option::Option::None => crate::lower::node_::fresh_name_f(wx_p0, &crate::prelude::Text::from(format!("place_{}", &crate::lower::model::place_text_f(pos_p4)))),
            };
            let asked_pe = crate::prelude::Array::from(vec![first_value_let_f(&wx1_pi, pos_p4, tg_p2, level_p6, out_p3), late_first_set_f(&f_ph, &crate::lower::model::Ex::XVar(crate::prelude::Text::from(format!("first_{}", &crate::lower::model::place_text_f(pos_p4)))))]);
            let wx3_pf = {
                let mut this: crate::lower::node_::Wx = late_first_place_f(&wx1_pi, pos_p4, &f_ph, out_p3, &asked_pe);
                this.dyn_places_p = crate::prelude::push(&this.dyn_places_p, &(pos_p4.clone(), f_ph.clone(), out_p3.clone(), answer_accessor_f(tg_p2)));
                this
            };
            (wx3_pf.clone(), crate::lower::node_::def::bn_res_f(&crate::lower::node_::def::late_place_bn_f(&f_ph, out_p3)))
        },
        crate::lower::types::Layer::LyDyn => {
            let (f_pl, wx1_pm) = match bound_o5 {
                ::std::option::Option::Some(crate::lower::types::Bn::BnHold(hf_pk, _)) => (hf_pk.clone(), wx_p0.clone()),
                _ => crate::lower::node_::fresh_name_f(wx_p0, &crate::prelude::Text::from(format!("place_{}", &crate::lower::model::place_text_f(pos_p4)))),
            };
            let wx3_pj = dynamic_place_f(&wx1_pm, tg_p2, out_p3, pos_p4, &f_pl, level_p6, &answer_accessor_f(tg_p2));
            (wx3_pj.clone(), crate::lower::node_::Wres::WrDyn(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::from(format!("{}", &f_pl)))), crate::prelude::Text::lit("get"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx])), crate::prelude::Array::from(vec![crate::lower::node_::Read::OwnRead(f_pl.clone())]), out_p3.clone()))
        },
        _ => match crate::lower::node_::def::late_plain_hold_o(bound_o5) {
            ::std::option::Option::Some(f_pn) if !crate::lower::node_::finish::emits_f(wx_p0, pos_p4) => {
                let wx2_po = {
                    let mut this: crate::lower::node_::Wx = wx_p0.clone();
                    this.fields_p = crate::prelude::push(&this.fields_p, &(f_pn.clone(), crate::lower::model::OutTy::OutHold(::std::rc::Rc::new(crate::lower::model::OutTy::OutOpt(::std::rc::Rc::new(out_p3.clone())))), crate::prelude::Text::from(format!("place {}\'s answer, its first value: empty until that is asked, once its host is placed", &crate::lower::model::place_text_f(pos_p4)))));
                    this.moves_p = crate::prelude::push(&this.moves_p, &(f_pn.clone(), crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Hold::new")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XNone, crate::lower::model::Ex::XCx]))));
                    this.late_firsts_p = crate::prelude::push(&this.late_firsts_p, &(pos_p4.scope_p.clone(), crate::prelude::Array::from(vec![first_value_let_f(wx_p0, pos_p4, tg_p2, level_p6, out_p3), late_first_set_f(&f_pn, &crate::lower::model::Ex::XVar(crate::prelude::Text::from(format!("first_{}", &crate::lower::model::place_text_f(pos_p4)))))])));
                    this.fallible_p = true;
                    this
                };
                (wx2_po.clone(), crate::lower::node_::Wres::WrUnit)
            },
            ::std::option::Option::Some(f_pp) => {
                let asked_pq = crate::prelude::Array::from(vec![first_value_let_f(wx_p0, pos_p4, tg_p2, level_p6, out_p3), crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), f_pp.clone())), crate::prelude::Text::lit("set"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Some")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XDecode(out_p3.clone(), ::std::rc::Rc::new(crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::from(format!("first_{}", &crate::lower::model::place_text_f(pos_p4))))))))])), crate::lower::model::Ex::XCx])))]);
                let wx2_pr = {
                    let mut this: crate::lower::node_::Wx = wx_p0.clone();
                    this.fields_p = crate::prelude::push(&this.fields_p, &(f_pp.clone(), crate::lower::model::OutTy::OutHold(::std::rc::Rc::new(crate::lower::model::OutTy::OutOpt(::std::rc::Rc::new(out_p3.clone())))), crate::prelude::Text::from(format!("place {}\'s answer, its first value: empty until that is asked, where the late result its element reads is built", &crate::lower::model::place_text_f(pos_p4)))));
                    this.moves_p = crate::prelude::push(&this.moves_p, &(f_pp.clone(), crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Hold::new")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XNone, crate::lower::model::Ex::XCx]))));
                    this.late_asks_p = crate::prelude::append(&this.late_asks_p, &asked_pq);
                    this
                };
                (wx2_pr.clone(), crate::lower::node_::Wres::WrUnit)
            },
            ::std::option::Option::None => match bound_o5 {
                ::std::option::Option::Some(crate::lower::types::Bn::BnLocal(rs_ps, _, _)) => {
                    let f_pt = crate::lower::types::place_stem_f(rs_ps);
                    let first_pu = if crate::lower::node_::finish::emits_f(wx_p0, pos_p4) {
                        crate::lower::model::Ex::XDecode(out_p3.clone(), ::std::rc::Rc::new(crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::from(format!("first_{}", &crate::lower::model::place_text_f(pos_p4))))))))
                    } else {
                        crate::lower::model::Ex::XVar(crate::prelude::Text::from(format!("first_{}", &crate::lower::model::place_text_f(pos_p4))))
                    };
                    let asks_pv = if (&pos_p4.scope_p != &crate::prelude::Nat::from(0u32)) && crate::check::types::has_text_f(&wx_p0.unplaced_hosts_p, &host_local_f(wx_p0, pos_p4)) {
                        crate::prelude::Array::from(vec![crate::lower::expr::refusal_do_f(&crate::prelude::Text::from(format!("a hosted place with a plain answer (place {}) under a host whose own place takes its number after its block\'s node (a host in an arm or a clause numbered late, or below a building `match`, `if` or widget of several clauses built after the node)", &crate::lower::model::place_text_f(pos_p4))))])
                    } else {
                        crate::prelude::Array::new()
                    };
                    let wx2_p10 = {
                        let mut this: crate::lower::node_::Wx = wx_p0.clone();
                        this.lets_p = crate::prelude::append(&crate::prelude::append(&this.lets_p, &asks_pv), &crate::prelude::Array::from(vec![first_value_let_f(wx_p0, pos_p4, tg_p2, level_p6, out_p3), crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(f_pt.clone()), first_pu.clone())]));
                        this.fields_p = crate::prelude::push(&this.fields_p, &(f_pt.clone(), out_p3.clone(), crate::prelude::Text::from(format!("place {}\'s answer, its first value", &crate::lower::model::place_text_f(pos_p4)))));
                        this.inits_p = crate::prelude::push(&this.inits_p, &(f_pt.clone(), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(f_pt.clone())))));
                        this.fallible_p = true;
                        this
                    };
                    (wx2_p10.clone(), crate::lower::node_::Wres::WrUnit)
                },
                _ => (wx_p0.clone(), crate::lower::node_::Wres::WrUnit),
            },
            _ => unreachable!("no arm matched"),
        },
        _ => unreachable!("no arm matched"),
    }
}
