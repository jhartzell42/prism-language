//! The module `Lower.Node.Elements`, from `target/bootstrap/src/prismc/lower/node/elements.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// ```prism
/// ElementLine: unbounded fn Wx, Env, Env, Expr, ?Bn -> ((Wx, Wres))
/// ```
pub fn element_line_f(wx_p0: &crate::lower::node_::Wx, benv_p1: &crate::lower::types::Env, menv_p2: &crate::lower::types::Env, e_p3: &crate::syntax::Expr, bound_o4: &Option<crate::lower::types::Bn>) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    let lx_p5 = wx_p0.lx_p.clone();
    let (tag_name_pa, args_pb) = match &*e_p3.kind_p {
        crate::syntax::ExprKind::ECall(c_p7, xs_p8, _, _) => (tag_name_of_f(&lx_p5, &**c_p7), xs_p8.clone()),
        crate::syntax::ExprKind::EName(n_p9) => (tag_name_of_f(&lx_p5, e_p3), Array::new()),
        _ => (Text::lit(""), Array::new()),
    };
    let full_p6 = crate::lower::type_at_f(&lx_p5, &e_p3.span_p);
    match crate::prelude::get(&lx_p5.g_p.tags_p, &tag_name_pa) {
        None => {
            let wx2_pc = {
                let mut this: crate::lower::node_::Wx = wx_p0.clone();
                this.build_p = crate::prelude::push(&this.build_p, &crate::lower::expr::refusal_do_f(&Text::lit("an element of an unknown tag")));
                this
            };
            (wx2_pc.clone(), crate::lower::node_::Wres::WrUnit)
        },
        Some(tg_pd) => {
            let pos_pe = wx_p0.pos_p.clone();
            let wx1_pf = {
                let mut this: crate::lower::node_::Wx = wx_p0.clone();
                this.pos_p = crate::lower::model::next_pos_f(&this.pos_p);
                this
            };
            let struct_path_pg = crate::lower::path_in_f(&lx_p5, &tg_pd.home_p, &crate::lower::tag_struct_f(&tg_pd.name_p));
            let (live_fields_p1c, const_fields_p1d, method_consts_p1e, reads_p1f, wx2_p1g) = crate::prelude::run_to_end(crate::prelude::fold_job(tg_pd.fields_p.clone(), (Array::new(), Array::new(), Array::new(), Array::new(), wx1_pf.clone()), {
                let args_pbx = args_pb.clone();
                let menv_p2x = menv_p2.clone();
                let pos_pex = pos_pe.clone();
                let tg_pdx = tg_pd.clone();
                let lx_p5x = lx_p5.clone();
                let benv_p1x = benv_p1.clone();
                Rc::new(move |(p0, p1): ((Array<(Text, crate::lower::model::Ex)>, Array<(Text, crate::lower::model::Ex)>, Array<(Text, crate::lower::model::Ex)>, Array<crate::lower::node_::Read>, crate::lower::node_::Wx), (Text, crate::check::types::Ty))| {
                    let args_pbxy = args_pbx.clone();
                    let menv_p2xy = menv_p2x.clone();
                    let pos_pexy = pos_pex.clone();
                    let tg_pdxy = tg_pdx.clone();
                    let lx_p5xy = lx_p5x.clone();
                    let benv_p1xy = benv_p1x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let (lf_pu, cf_pv, mf_p10, rd_p11, w_p12) = p0;
                        let (fname_p13, fty_p14) = p1;
                        match tag_arg_o(&args_pbxy, &fname_p13) {
                            None => prism_rtl::Turn::Finished((lf_pu.clone(), cf_pv.clone(), mf_p10.clone(), rd_p11.clone(), w_p12.clone())),
                            Some(arg_p15) => match crate::lower::types::layer_of_f(&fty_p14) {
                                crate::lower::types::Layer::LyEv => crate::prelude::call_then(crate::lower::node_::dynamics::start_event_ref_f(w_p12.clone(), menv_p2xy.clone(), arg_p15.clone()), move |event_ref_f_2608: (crate::lower::node_::EvRef, crate::lower::node_::Wx)| {
                                    let (r_p16, w2_p17) = event_ref_f_2608;
                                    prism_rtl::Turn::Finished((lf_pu.clone(), cf_pv.clone(), mf_p10.clone(), rd_p11.clone(), crate::lower::node_::connect_f(&w2_p17, &r_p16, &crate::lower::node_::Sk::SkRequest(pos_pexy.clone(), request_field_f(&tg_pdxy, &fname_p13)))))
                                }),
                                _ => crate::prelude::call_then(crate::lower::node_::dynamics::start_dynamic_expr_f(w_p12.clone(), menv_p2xy.clone(), arg_p15.clone()), move |dynamic_expr_f_2830: (crate::lower::model::Ex, Array<crate::lower::node_::Read>)| {
                                    let (ex_p1a, rds_p1b) = dynamic_expr_f_2830;
                                    crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p5xy.clone(), crate::lower::node_::def::init_env_f(&benv_p1xy), arg_p15.clone()), move |value_of_f_3097: crate::lower::types::Vl| {
                                        let cv_p18 = crate::lower::types::own_f(&value_of_f_3097);
                                        crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p5xy.clone(), menv_p2xy.clone(), arg_p15.clone()), move |value_of_f_3176: crate::lower::types::Vl| {
                                            let mv_p19 = crate::lower::types::own_f(&value_of_f_3176);
                                            crate::prelude::call_then(crate::lower::start_field_spell_f(tg_pdxy.home_p.clone(), fname_p13.clone(), fty_p14.clone()), move |field_spell_f_3246: Text| crate::prelude::call_then(crate::lower::start_field_spell_f(tg_pdxy.home_p.clone(), fname_p13.clone(), fty_p14.clone()), move |field_spell_f_3299: Text| crate::prelude::call_then(crate::lower::start_field_spell_f(tg_pdxy.home_p.clone(), fname_p13.clone(), fty_p14.clone()), move |field_spell_f_3352: Text| prism_rtl::Turn::Finished((crate::prelude::push(&lf_pu, &(field_spell_f_3246, ex_p1a.clone())), crate::prelude::push(&cf_pv, &(field_spell_f_3299, cv_p18.clone())), crate::prelude::push(&mf_p10, &(field_spell_f_3352, mv_p19.clone())), crate::lower::node_::union_reads_f(&rd_p11, &rds_p1b), w_p12.clone())))))
                                        })
                                    })
                                }),
                            },
                        }
                    }))
                }) as Rc<dyn Fn(((Array<(Text, crate::lower::model::Ex)>, Array<(Text, crate::lower::model::Ex)>, Array<(Text, crate::lower::model::Ex)>, Array<crate::lower::node_::Read>, crate::lower::node_::Wx), (Text, crate::check::types::Ty))) -> Rc<dyn prism_rtl::Job<(Array<(Text, crate::lower::model::Ex)>, Array<(Text, crate::lower::model::Ex)>, Array<(Text, crate::lower::model::Ex)>, Array<crate::lower::node_::Read>, crate::lower::node_::Wx)>>>
            }));
            let live_ph = &crate::prelude::len(&reads_p1f) > &Nat::from(0u32);
            let (getter_p1h, wx3_p1i) = if live_ph {
                crate::lower::node_::fresh_name_f(&wx2_p1g, &crate::lower::snake_f(&crate::check::types::bare_name_f(&tg_pd.name_p)))
            } else {
                (Text::lit(""), wx2_p1g.clone())
            };
            let variant_pi = crate::lower::program::variant_of_f(&lx_p5, &tg_pd);
            let level_pj = crate::lower::model::Ex::XCtor(variant_pi.clone(), Array::from(vec![crate::lower::model::Ex::XRecord(struct_path_pg.clone(), if live_ph { live_fields_p1c.clone() } else { method_consts_p1e.clone() })]));
            let at_build_pk = crate::lower::model::Ex::XCtor(variant_pi.clone(), Array::from(vec![crate::lower::model::Ex::XRecord(struct_path_pg.clone(), const_fields_p1d.clone())]));
            let added_pl = if live_ph {
                crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("node"))), getter_p1h.clone(), Array::from(vec![crate::lower::model::Ex::XCx]))
            } else {
                at_build_pk.clone()
            };
            let emits_pm = crate::lower::node_::finish::emits_f(&wx3_p1i, &pos_pe);
            let (entry_p1j, wx3e_p1k) = if emits_pm {
                (Text::lit(""), wx3_p1i.clone())
            } else {
                crate::lower::node_::fresh_name_f(&wx3_p1i, &Text::from(format!("entry_{}", &crate::lower::model::place_text_f(&pos_pe))))
            };
            let deep_pn = emits_pm && crate::lower::program::tag_holds_dyn_f(&lx_p5, &tg_pd);
            let (watch_p1l, wx3w_p1m) = if deep_pn {
                crate::lower::node_::fresh_name_f(&wx3e_p1k, &Text::from(format!("watch_{}", &crate::lower::model::place_text_f(&pos_pe))))
            } else {
                (Text::lit(""), wx3e_p1k.clone())
            };
            let what_po = Text::from(format!("place {} ({}) of `{}`", &crate::lower::model::place_text_f(&pos_pe), &tg_pd.name_p, &wx_p0.node_p));
            let const_take_pp = if live_ph {
                Array::new()
            } else {
                Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(entry_p1j.clone())), Text::lit("take"), Array::from(vec![at_build_pk.clone(), crate::lower::model::Ex::XCx])))])
            };
            let wx3h_pq = if emits_pm {
                wx3w_p1m.clone()
            } else {
                {
                    let mut this: crate::lower::node_::Wx = wx3w_p1m.clone();
                    this.lets_p = crate::prelude::append(&crate::prelude::push(&this.lets_p, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaBind(entry_p1j.clone())), crate::lower::types::entry_ty_p()), crate::lower::model::Ex::XCall(Text::lit("prism_rtl::Entry::new"), Array::from(vec![crate::lower::model::Ex::XStr(what_po.clone())])))), &const_take_pp);
                    this.fields_p = crate::prelude::push(&this.fields_p, &(entry_p1j.clone(), crate::lower::types::entry_ty_p(), Text::from(format!("{}, an entry of its host\'s document", &what_po))));
                    this.moves_p = crate::prelude::push(&this.moves_p, &(entry_p1j.clone(), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(entry_p1j.clone())))));
                    this
                }
            };
            let wx3d_pr = if deep_pn {
                crate::lower::node_::add_field_last_f(&wx3h_pq, &watch_p1l, &crate::lower::model::OutTy::OutNamed(Text::lit("prism_rtl::Watch"), Array::new()), &Text::from(format!("the dynamics place {}\'s level holds, watched so a move sends it again (doubt WD)", &crate::lower::model::place_text_f(&pos_pe))), &crate::lower::model::Ex::XCall(Text::lit("prism_rtl::Watch::new"), Array::new()))
            } else {
                wx3h_pq.clone()
            };
            let sent_ps = if deep_pn {
                Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(Text::lit("sent")), added_pl.clone()), crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCx), Text::lit("added"), Array::from(vec![crate::lower::node_::finish::place_at_f(&wx3_p1i, &Text::lit("node"), &pos_pe), crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("sent"))), Text::lit("level_pod"), Array::from(vec![crate::lower::model::Ex::XCx]))]))), crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XVar(Text::lit("node"))), watch_p1l.clone())), Text::lit("renew"), Array::from(vec![crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XVar(Text::lit("sent")))), crate::lower::model::Ex::XCast(Rc::new(crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(Text::lit("node"))))), crate::lower::model::OutTy::OutObj(Rc::new(crate::lower::model::OutTy::OutNamed(Text::lit("Node"), Array::new())))), crate::lower::model::Ex::XCx])))])
            } else {
                Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCx), Text::lit("added"), Array::from(vec![crate::lower::node_::finish::place_at_f(&wx3_p1i, &Text::lit("node"), &pos_pe), crate::lower::model::Ex::XMethod(Rc::new(added_pl.clone()), Text::lit("level_pod"), Array::from(vec![crate::lower::model::Ex::XCx]))])))])
            };
            let wx4_pt = {
                let mut this: crate::lower::node_::Wx = wx3d_pr.clone();
                this.places_p = crate::prelude::push(&this.places_p, &crate::lower::node_::Place { pos_p: pos_pe.clone(), level_p: level_pj.clone(), getter_p: getter_p1h.clone(), reads_p: reads_p1f.clone(), entry_p: entry_p1j.clone(), watch_p: watch_p1l.clone() });
                this.build_p = if emits_pm {
                    if deep_pn {
                        crate::prelude::push(&this.build_p, &crate::lower::model::Do::DoScope(sent_ps.clone()))
                    } else {
                        crate::prelude::append(&this.build_p, &sent_ps)
                    }
                } else {
                    this.build_p.clone()
                };
                this
            };
            element_output_f(&wx4_pt, menv_p2, &tg_pd, &element_out_f(&lx_p5, &tg_pd, &full_p6), &pos_pe, bound_o4, &at_build_pk)
        },
    }
}

/// The step machine of `ElementLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ElementLine: unbounded fn Wx, Env, Env, Expr, ?Bn -> ((Wx, Wres))
/// ```
pub struct ElementLine {
    pub wx_p0: crate::lower::node_::Wx,
    pub benv_p1: crate::lower::types::Env,
    pub menv_p2: crate::lower::types::Env,
    pub e_p3: crate::syntax::Expr,
    pub bound_o4: Option<crate::lower::types::Bn>,
}

impl prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::node_::Wres)> for ElementLine {
    fn cycle(&self) -> prism_rtl::Turn<(crate::lower::node_::Wx, crate::lower::node_::Wres)> {
        let wx_p0 = &self.wx_p0;
        let benv_p1 = &self.benv_p1;
        let menv_p2 = &self.menv_p2;
        let e_p3 = &self.e_p3;
        let bound_o4 = &self.bound_o4;
        let lx_p5 = wx_p0.lx_p.clone();
        let (tag_name_pa, args_pb) = match &*e_p3.kind_p {
            crate::syntax::ExprKind::ECall(c_p7, xs_p8, _, _) => (tag_name_of_f(&lx_p5, &**c_p7), xs_p8.clone()),
            crate::syntax::ExprKind::EName(n_p9) => (tag_name_of_f(&lx_p5, e_p3), Array::new()),
            _ => (Text::lit(""), Array::new()),
        };
        let full_p6 = crate::lower::type_at_f(&lx_p5, &e_p3.span_p);
        match crate::prelude::get(&lx_p5.g_p.tags_p, &tag_name_pa) {
            None => {
                let wx2_pc = {
                    let mut this: crate::lower::node_::Wx = wx_p0.clone();
                    this.build_p = crate::prelude::push(&this.build_p, &crate::lower::expr::refusal_do_f(&Text::lit("an element of an unknown tag")));
                    this
                };
                prism_rtl::Turn::Finished((wx2_pc.clone(), crate::lower::node_::Wres::WrUnit))
            },
            Some(tg_pd) => {
                let pos_pe = wx_p0.pos_p.clone();
                let wx1_pf = {
                    let mut this: crate::lower::node_::Wx = wx_p0.clone();
                    this.pos_p = crate::lower::model::next_pos_f(&this.pos_p);
                    this
                };
                let struct_path_pg = crate::lower::path_in_f(&lx_p5, &tg_pd.home_p, &crate::lower::tag_struct_f(&tg_pd.name_p));
                let bound_o4x = bound_o4.clone();
                let benv_p1x = benv_p1.clone();
                let menv_p2x = menv_p2.clone();
                let wx_p0x = wx_p0.clone();
                crate::prelude::call_value(crate::prelude::fold_job(tg_pd.fields_p.clone(), (Array::new(), Array::new(), Array::new(), Array::new(), wx1_pf.clone()), {
                    let args_pbx = args_pb.clone();
                    let menv_p2xx = menv_p2x.clone();
                    let pos_pex = pos_pe.clone();
                    let tg_pdx = tg_pd.clone();
                    let lx_p5x = lx_p5.clone();
                    let benv_p1xx = benv_p1x.clone();
                    Rc::new(move |(p0, p1): ((Array<(Text, crate::lower::model::Ex)>, Array<(Text, crate::lower::model::Ex)>, Array<(Text, crate::lower::model::Ex)>, Array<crate::lower::node_::Read>, crate::lower::node_::Wx), (Text, crate::check::types::Ty))| {
                        let args_pbxy = args_pbx.clone();
                        let menv_p2xxy = menv_p2xx.clone();
                        let pos_pexy = pos_pex.clone();
                        let tg_pdxy = tg_pdx.clone();
                        let lx_p5xy = lx_p5x.clone();
                        let benv_p1xxy = benv_p1xx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let (lf_pu, cf_pv, mf_p10, rd_p11, w_p12) = p0;
                            let (fname_p13, fty_p14) = p1;
                            match tag_arg_o(&args_pbxy, &fname_p13) {
                                None => prism_rtl::Turn::Finished((lf_pu.clone(), cf_pv.clone(), mf_p10.clone(), rd_p11.clone(), w_p12.clone())),
                                Some(arg_p15) => match crate::lower::types::layer_of_f(&fty_p14) {
                                    crate::lower::types::Layer::LyEv => crate::prelude::call_then(crate::lower::node_::dynamics::start_event_ref_f(w_p12.clone(), menv_p2xxy.clone(), arg_p15.clone()), move |event_ref_f_2608: (crate::lower::node_::EvRef, crate::lower::node_::Wx)| {
                                        let (r_p16, w2_p17) = event_ref_f_2608;
                                        prism_rtl::Turn::Finished((lf_pu.clone(), cf_pv.clone(), mf_p10.clone(), rd_p11.clone(), crate::lower::node_::connect_f(&w2_p17, &r_p16, &crate::lower::node_::Sk::SkRequest(pos_pexy.clone(), request_field_f(&tg_pdxy, &fname_p13)))))
                                    }),
                                    _ => crate::prelude::call_then(crate::lower::node_::dynamics::start_dynamic_expr_f(w_p12.clone(), menv_p2xxy.clone(), arg_p15.clone()), move |dynamic_expr_f_2830: (crate::lower::model::Ex, Array<crate::lower::node_::Read>)| {
                                        let (ex_p1a, rds_p1b) = dynamic_expr_f_2830;
                                        crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p5xy.clone(), crate::lower::node_::def::init_env_f(&benv_p1xxy), arg_p15.clone()), move |value_of_f_3097: crate::lower::types::Vl| {
                                            let cv_p18 = crate::lower::types::own_f(&value_of_f_3097);
                                            crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p5xy.clone(), menv_p2xxy.clone(), arg_p15.clone()), move |value_of_f_3176: crate::lower::types::Vl| {
                                                let mv_p19 = crate::lower::types::own_f(&value_of_f_3176);
                                                crate::prelude::call_then(crate::lower::start_field_spell_f(tg_pdxy.home_p.clone(), fname_p13.clone(), fty_p14.clone()), move |field_spell_f_3246: Text| crate::prelude::call_then(crate::lower::start_field_spell_f(tg_pdxy.home_p.clone(), fname_p13.clone(), fty_p14.clone()), move |field_spell_f_3299: Text| crate::prelude::call_then(crate::lower::start_field_spell_f(tg_pdxy.home_p.clone(), fname_p13.clone(), fty_p14.clone()), move |field_spell_f_3352: Text| prism_rtl::Turn::Finished((crate::prelude::push(&lf_pu, &(field_spell_f_3246, ex_p1a.clone())), crate::prelude::push(&cf_pv, &(field_spell_f_3299, cv_p18.clone())), crate::prelude::push(&mf_p10, &(field_spell_f_3352, mv_p19.clone())), crate::lower::node_::union_reads_f(&rd_p11, &rds_p1b), w_p12.clone())))))
                                            })
                                        })
                                    }),
                                },
                            }
                        }))
                    }) as Rc<dyn Fn(((Array<(Text, crate::lower::model::Ex)>, Array<(Text, crate::lower::model::Ex)>, Array<(Text, crate::lower::model::Ex)>, Array<crate::lower::node_::Read>, crate::lower::node_::Wx), (Text, crate::check::types::Ty))) -> Rc<dyn prism_rtl::Job<(Array<(Text, crate::lower::model::Ex)>, Array<(Text, crate::lower::model::Ex)>, Array<(Text, crate::lower::model::Ex)>, Array<crate::lower::node_::Read>, crate::lower::node_::Wx)>>>
                }), move |fold_2276: (Array<(Text, crate::lower::model::Ex)>, Array<(Text, crate::lower::model::Ex)>, Array<(Text, crate::lower::model::Ex)>, Array<crate::lower::node_::Read>, crate::lower::node_::Wx)| {
                    let (live_fields_p1c, const_fields_p1d, method_consts_p1e, reads_p1f, wx2_p1g) = fold_2276;
                    let live_ph = &crate::prelude::len(&reads_p1f) > &Nat::from(0u32);
                    let (getter_p1h, wx3_p1i) = if live_ph {
                        crate::lower::node_::fresh_name_f(&wx2_p1g, &crate::lower::snake_f(&crate::check::types::bare_name_f(&tg_pd.name_p)))
                    } else {
                        (Text::lit(""), wx2_p1g.clone())
                    };
                    let variant_pi = crate::lower::program::variant_of_f(&lx_p5, &tg_pd);
                    let level_pj = crate::lower::model::Ex::XCtor(variant_pi.clone(), Array::from(vec![crate::lower::model::Ex::XRecord(struct_path_pg.clone(), if live_ph { live_fields_p1c.clone() } else { method_consts_p1e.clone() })]));
                    let at_build_pk = crate::lower::model::Ex::XCtor(variant_pi.clone(), Array::from(vec![crate::lower::model::Ex::XRecord(struct_path_pg.clone(), const_fields_p1d.clone())]));
                    let added_pl = if live_ph {
                        crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("node"))), getter_p1h.clone(), Array::from(vec![crate::lower::model::Ex::XCx]))
                    } else {
                        at_build_pk.clone()
                    };
                    let emits_pm = crate::lower::node_::finish::emits_f(&wx3_p1i, &pos_pe);
                    let (entry_p1j, wx3e_p1k) = if emits_pm {
                        (Text::lit(""), wx3_p1i.clone())
                    } else {
                        crate::lower::node_::fresh_name_f(&wx3_p1i, &Text::from(format!("entry_{}", &crate::lower::model::place_text_f(&pos_pe))))
                    };
                    let deep_pn = emits_pm && crate::lower::program::tag_holds_dyn_f(&lx_p5, &tg_pd);
                    let (watch_p1l, wx3w_p1m) = if deep_pn {
                        crate::lower::node_::fresh_name_f(&wx3e_p1k, &Text::from(format!("watch_{}", &crate::lower::model::place_text_f(&pos_pe))))
                    } else {
                        (Text::lit(""), wx3e_p1k.clone())
                    };
                    let what_po = Text::from(format!("place {} ({}) of `{}`", &crate::lower::model::place_text_f(&pos_pe), &tg_pd.name_p, &wx_p0x.node_p));
                    let const_take_pp = if live_ph {
                        Array::new()
                    } else {
                        Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(entry_p1j.clone())), Text::lit("take"), Array::from(vec![at_build_pk.clone(), crate::lower::model::Ex::XCx])))])
                    };
                    let wx3h_pq = if emits_pm {
                        wx3w_p1m.clone()
                    } else {
                        {
                            let mut this: crate::lower::node_::Wx = wx3w_p1m.clone();
                            this.lets_p = crate::prelude::append(&crate::prelude::push(&this.lets_p, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaBind(entry_p1j.clone())), crate::lower::types::entry_ty_p()), crate::lower::model::Ex::XCall(Text::lit("prism_rtl::Entry::new"), Array::from(vec![crate::lower::model::Ex::XStr(what_po.clone())])))), &const_take_pp);
                            this.fields_p = crate::prelude::push(&this.fields_p, &(entry_p1j.clone(), crate::lower::types::entry_ty_p(), Text::from(format!("{}, an entry of its host\'s document", &what_po))));
                            this.moves_p = crate::prelude::push(&this.moves_p, &(entry_p1j.clone(), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(entry_p1j.clone())))));
                            this
                        }
                    };
                    let wx3d_pr = if deep_pn {
                        crate::lower::node_::add_field_last_f(&wx3h_pq, &watch_p1l, &crate::lower::model::OutTy::OutNamed(Text::lit("prism_rtl::Watch"), Array::new()), &Text::from(format!("the dynamics place {}\'s level holds, watched so a move sends it again (doubt WD)", &crate::lower::model::place_text_f(&pos_pe))), &crate::lower::model::Ex::XCall(Text::lit("prism_rtl::Watch::new"), Array::new()))
                    } else {
                        wx3h_pq.clone()
                    };
                    let sent_ps = if deep_pn {
                        Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(Text::lit("sent")), added_pl.clone()), crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCx), Text::lit("added"), Array::from(vec![crate::lower::node_::finish::place_at_f(&wx3_p1i, &Text::lit("node"), &pos_pe), crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("sent"))), Text::lit("level_pod"), Array::from(vec![crate::lower::model::Ex::XCx]))]))), crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XVar(Text::lit("node"))), watch_p1l.clone())), Text::lit("renew"), Array::from(vec![crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XVar(Text::lit("sent")))), crate::lower::model::Ex::XCast(Rc::new(crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(Text::lit("node"))))), crate::lower::model::OutTy::OutObj(Rc::new(crate::lower::model::OutTy::OutNamed(Text::lit("Node"), Array::new())))), crate::lower::model::Ex::XCx])))])
                    } else {
                        Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCx), Text::lit("added"), Array::from(vec![crate::lower::node_::finish::place_at_f(&wx3_p1i, &Text::lit("node"), &pos_pe), crate::lower::model::Ex::XMethod(Rc::new(added_pl.clone()), Text::lit("level_pod"), Array::from(vec![crate::lower::model::Ex::XCx]))])))])
                    };
                    let wx4_pt = {
                        let mut this: crate::lower::node_::Wx = wx3d_pr.clone();
                        this.places_p = crate::prelude::push(&this.places_p, &crate::lower::node_::Place { pos_p: pos_pe.clone(), level_p: level_pj.clone(), getter_p: getter_p1h.clone(), reads_p: reads_p1f.clone(), entry_p: entry_p1j.clone(), watch_p: watch_p1l.clone() });
                        this.build_p = if emits_pm {
                            if deep_pn {
                                crate::prelude::push(&this.build_p, &crate::lower::model::Do::DoScope(sent_ps.clone()))
                            } else {
                                crate::prelude::append(&this.build_p, &sent_ps)
                            }
                        } else {
                            this.build_p.clone()
                        };
                        this
                    };
                    prism_rtl::Turn::Finished(element_output_f(&wx4_pt, &menv_p2x, &tg_pd, &element_out_f(&lx_p5, &tg_pd, &full_p6), &pos_pe, &bound_o4x, &at_build_pk))
                })
            },
        }
    }
}

/// `Start ElementLine, x`: what the function value is when passed to `@Run`.
pub fn start_element_line_f(wx_p0: crate::lower::node_::Wx, benv_p1: crate::lower::types::Env, menv_p2: crate::lower::types::Env, e_p3: crate::syntax::Expr, bound_o4: Option<crate::lower::types::Bn>) -> Rc<dyn prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::node_::Wres)>> {
    Rc::new(ElementLine { wx_p0, benv_p1, menv_p2, e_p3, bound_o4 })
}

/// ```prism
/// ElementOut: unbounded fn Lx, TagInfo, Ty -> OutTy
/// ```
pub fn element_out_f(lx_p0: &crate::lower::Lx, tg_p1: &crate::check::env::TagInfo, full_p2: &crate::check::types::Ty) -> crate::lower::model::OutTy {
    let t_p3 = match crate::lower::types::peel_f(full_p2) {
        crate::check::types::Ty::TyElem(_, o_p4) => crate::lower::types::out_ty_of_f(lx_p0, &crate::lower::types::peel_f(&*o_p4)),
        _ => crate::lower::types::out_ty_of_f(lx_p0, &crate::lower::types::peel_f(&tg_p1.out_p)),
    };
    match &t_p3 {
        crate::lower::model::OutTy::OutGen(_) => crate::lower::model::OutTy::OutPod,
        _ => t_p3.clone(),
    }
}

/// ```prism
/// TagNameOf: fn Lx, Expr -> Text
/// ```
pub fn tag_name_of_f(lx_p0: &crate::lower::Lx, c_p1: &crate::syntax::Expr) -> Text {
    match &*c_p1.kind_p {
        crate::syntax::ExprKind::EName(n_p2) => {
            let (qk_o3, _) = crate::check::env::names::resolve_value_f(&lx_p0.g_p, &lx_p0.home_p, n_p2);
            crate::prelude::or(&qk_o3, &crate::check::env::dotted_f(&n_p2.path_p))
        },
        crate::syntax::ExprKind::EGroup(x_p4) => tag_name_of_f(lx_p0, &**x_p4),
        _ => Text::lit(""),
    }
}

/// ```prism
/// ?TagArg: fn [Arg], Text -> ?Expr
/// ```
pub fn tag_arg_o(args_p0: &Array<crate::syntax::Arg>, fname_p1: &Text) -> Option<crate::syntax::Expr> {
    crate::prelude::fold(args_p0, &None, &(|found_o2: &Option<crate::syntax::Expr>, a_p3: &crate::syntax::Arg| match &a_p3.name_o {
        Some(n_p4) => if &n_p4.name_p == fname_p1 { Some(a_p3.value_p.clone()) } else { found_o2.clone() },
        None => found_o2.clone(),
    }))
}

/// ```prism
/// RequestField: fn TagInfo, Text -> Text
/// ```
pub fn request_field_f(tg_p0: &crate::check::env::TagInfo, fname_p1: &Text) -> Text {
    let evs_p2 = crate::prelude::filter(&tg_p0.fields_p, &(|(_, t_p3): &(Text, crate::check::types::Ty)| &crate::lower::types::layer_of_f(t_p3) == &crate::lower::types::Layer::LyEv));
    if &crate::prelude::len(&evs_p2) > &Nat::from(1u32) {
        fname_p1.clone()
    } else {
        Text::lit("")
    }
}

/// ```prism
/// ElementOutput: unbounded fn Wx, Env, TagInfo, OutTy, Pos, ?Bn, Ex -> ((Wx, Wres))
/// ```
pub fn element_output_f(wx_p0: &crate::lower::node_::Wx, menv_p1: &crate::lower::types::Env, tg_p2: &crate::check::env::TagInfo, out_p3: &crate::lower::model::OutTy, pos_p4: &crate::lower::model::Pos_, bound_o5: &Option<crate::lower::types::Bn>, level_p6: &crate::lower::model::Ex) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    let lx_p7 = wx_p0.lx_p.clone();
    match bound_o5 {
        Some(crate::lower::types::Bn::BnParts(parts_p8)) => bundle_output_f(wx_p0, tg_p2, out_p3, pos_p4, parts_p8, level_p6),
        _ => element_output_of_f(wx_p0, menv_p1, tg_p2, out_p3, pos_p4, bound_o5, level_p6),
    }
}

/// ```prism
/// BundleOutput: unbounded fn Wx, TagInfo, OutTy, Pos, [?Bn], Ex -> ((Wx, Wres))
/// ```
pub fn bundle_output_f(wx_p0: &crate::lower::node_::Wx, tg_p1: &crate::check::env::TagInfo, out_p2: &crate::lower::model::OutTy, pos_p3: &crate::lower::model::Pos_, parts_p4: &Array<Option<crate::lower::types::Bn>>, level_p5: &crate::lower::model::Ex) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    if !crate::lower::node_::finish::emits_f(wx_p0, pos_p3) {
        {
            let wx2_p6 = {
                let mut this: crate::lower::node_::Wx = wx_p0.clone();
                this.build_p = crate::prelude::push(&this.build_p, &crate::lower::expr::refusal_do_f(&Text::from(format!("a bundle ({}) in a hosted scope", &tg_p1.name_p))));
                this
            };
            (wx2_p6.clone(), crate::lower::node_::Wres::WrUnit)
        }
    } else {
        bundle_output_of_f(wx_p0, tg_p1, out_p2, pos_p3, parts_p4, level_p5)
    }
}

/// ```prism
/// BundleOutputOf: unbounded fn Wx, TagInfo, OutTy, Pos, [?Bn], Ex -> ((Wx, Wres))
/// ```
pub fn bundle_output_of_f(wx_p0: &crate::lower::node_::Wx, tg_p1: &crate::check::env::TagInfo, out_p2: &crate::lower::model::OutTy, pos_p3: &crate::lower::model::Pos_, parts_p4: &Array<Option<crate::lower::types::Bn>>, level_p5: &crate::lower::model::Ex) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    let layers_p6 = match &tg_p1.out_p {
        crate::check::types::Ty::TyTuple(cs_pe) => crate::prelude::each(cs_pe, &(|c_pf: &crate::check::types::Ty| crate::lower::types::layer_of_f(c_pf))),
        _ => Array::new(),
    };
    let tys_p7 = match out_p2 {
        crate::lower::model::OutTy::OutTuple(ts_pg) => ts_pg.clone(),
        _ => Array::new(),
    };
    let idx_p8 = crate::check::errors::range0_f(&crate::prelude::len(&layers_p6));
    let plain_ix_p9 = crate::prelude::filter(&idx_p8, &(|i_ph: &Nat| &crate::prelude::or(&crate::prelude::index(&layers_p6, i_ph), &crate::lower::types::Layer::LyPlain) == &crate::lower::types::Layer::LyPlain));
    let ev_ix_pa = crate::prelude::filter(&idx_p8, &(|i_pi: &Nat| &crate::prelude::or(&crate::prelude::index(&layers_p6, i_pi), &crate::lower::types::Layer::LyPlain) == &crate::lower::types::Layer::LyEv));
    let dyn_ix_pb = crate::prelude::filter(&idx_p8, &(|i_pj: &Nat| &crate::prelude::or(&crate::prelude::index(&layers_p6, i_pj), &crate::lower::types::Layer::LyPlain) == &crate::lower::types::Layer::LyDyn));
    let wx1_pc = bundle_first_f(wx_p0, tg_p1, pos_p3, &plain_ix_p9, &tys_p7, parts_p4, level_p5);
    let wx2_pd = crate::prelude::fold(&ev_ix_pa, &wx1_pc, &(|w_pk: &crate::lower::node_::Wx, i_pl: &Nat| bundle_answer_f(w_pk, pos_p3, &crate::prelude::or(&crate::prelude::index(&tys_p7, i_pl), &crate::lower::model::OutTy::OutUnit), &crate::prelude::or(&crate::prelude::index(parts_p4, i_pl), &None))));
    if (&crate::prelude::len(&ev_ix_pa) > &Nat::from(1u32)) || (&crate::prelude::len(&dyn_ix_pb) > &Nat::from(0u32)) {
        {
            let wx3_pm = {
                let mut this: crate::lower::node_::Wx = wx2_pd.clone();
                this.build_p = crate::prelude::push(&this.build_p, &crate::lower::expr::refusal_do_f(&Text::from(format!("a bundle with a `$` part or two event parts ({})", &tg_p1.name_p))));
                this
            };
            (wx3_pm.clone(), crate::lower::node_::Wres::WrUnit)
        }
    } else {
        (wx2_pd.clone(), crate::lower::node_::Wres::WrUnit)
    }
}

/// ```prism
/// BundleFirst: unbounded fn Wx, TagInfo, Pos, [Nat], [OutTy], [?Bn], Ex -> Wx
/// ```
pub fn bundle_first_f(wx_p0: &crate::lower::node_::Wx, tg_p1: &crate::check::env::TagInfo, pos_p2: &crate::lower::model::Pos_, plain_ix_p3: &Array<Nat>, tys_p4: &Array<crate::lower::model::OutTy>, parts_p5: &Array<Option<crate::lower::types::Bn>>, level_p6: &crate::lower::model::Ex) -> crate::lower::node_::Wx {
    match plain_ix_p3 {
        m10087_0 if (m10087_0.len() == 0) => wx_p0.clone(),
        _ => {
            let one_p7 = &crate::prelude::len(plain_ix_p3) == &Nat::from(1u32);
            let plain_ty_p8 = if one_p7 {
                crate::prelude::or(&crate::prelude::index(tys_p4, &crate::prelude::or(&crate::prelude::index(plain_ix_p3, &Nat::from(0u32)), &Nat::from(0u32))), &crate::lower::model::OutTy::OutUnit)
            } else {
                crate::lower::model::OutTy::OutTuple(crate::prelude::each(plain_ix_p3, &(|i_pa: &Nat| crate::prelude::or(&crate::prelude::index(tys_p4, i_pa), &crate::lower::model::OutTy::OutUnit))))
            };
            let wx1_p9 = {
                let mut this: crate::lower::node_::Wx = wx_p0.clone();
                this.lets_p = crate::prelude::append(&this.lets_p, &Array::from(vec![first_value_let_f(wx_p0, pos_p2, tg_p1, level_p6), crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(Text::from(format!("bundle_{}", &crate::lower::model::place_text_f(pos_p2)))), crate::lower::model::Ex::XDecode(plain_ty_p8.clone(), Rc::new(crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XVar(Text::from(format!("first_{}", &crate::lower::model::place_text_f(pos_p2)))))))))]));
                this.fallible_p = true;
                this
            };
            crate::prelude::fold(&crate::check::errors::range0_f(&crate::prelude::len(plain_ix_p3)), &wx1_p9, &(|w_pb: &crate::lower::node_::Wx, k_pc: &Nat| {
                let i_pd = crate::prelude::or(&crate::prelude::index(plain_ix_p3, k_pc), &Nat::from(0u32));
                match crate::prelude::index(parts_p5, &i_pd) {
                    Some(Some(crate::lower::types::Bn::BnLocal(rs_pe, _, _))) => {
                        let f_pf = crate::lower::types::place_stem_f(&rs_pe);
                        let part_pg = if one_p7 {
                            crate::lower::model::Ex::XVar(Text::from(format!("bundle_{}", &crate::lower::model::place_text_f(pos_p2))))
                        } else {
                            crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XPart(Rc::new(crate::lower::model::Ex::XVar(Text::from(format!("bundle_{}", &crate::lower::model::place_text_f(pos_p2))))), k_pc.clone())))
                        };
                        {
                            let mut this: crate::lower::node_::Wx = w_pb.clone();
                            this.lets_p = crate::prelude::push(&this.lets_p, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(f_pf.clone()), part_pg.clone()));
                            this.fields_p = crate::prelude::push(&this.fields_p, &(f_pf.clone(), crate::prelude::or(&crate::prelude::index(tys_p4, &i_pd), &crate::lower::model::OutTy::OutUnit), Text::from(format!("place {}\'s answer, part {} of its first value", &crate::lower::model::place_text_f(pos_p2), &i_pd))));
                            this.inits_p = crate::prelude::push(&this.inits_p, &(f_pf.clone(), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(f_pf.clone())))));
                            this
                        }
                    },
                    _ => w_pb.clone(),
                }
            }))
        },
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// BundleAnswer: fn Wx, Pos, OutTy, ?Bn -> Wx
/// ```
pub fn bundle_answer_f(wx_p0: &crate::lower::node_::Wx, pos_p1: &crate::lower::model::Pos_, et_p2: &crate::lower::model::OutTy, b_o3: &Option<crate::lower::types::Bn>) -> crate::lower::node_::Wx {
    let t_p4 = match et_p2 {
        crate::lower::model::OutTy::OutEvent(inner_p5) => (**inner_p5).clone(),
        _ => et_p2.clone(),
    };
    let (id_p9, wx2_pa) = match b_o3 {
        Some(crate::lower::types::Bn::BnEv(er_p6, _)) => (er_p6.node_p.clone(), wx_p0.clone()),
        _ => {
            let (nm_p7, w_p8) = crate::lower::node_::fresh_name_f(wx_p0, &Text::from(format!("place_{}", &crate::lower::model::place_text_f(pos_p1))));
            crate::lower::node_::add_gn_f(&w_p8, &nm_p7, &t_p4, &crate::lower::node_::GnKind::GnAnswer, &Nat::from(0u32))
        },
    };
    let mut this: crate::lower::node_::Wx = wx2_pa.clone();
    this.answers_p = crate::prelude::push(&this.answers_p, &(pos_p1.clone(), id_p9.clone(), t_p4.clone(), Text::lit("")));
    this
}

/// ```prism
/// FirstValueLet: fn Wx, Pos, TagInfo, Ex -> Do
/// ```
pub fn first_value_let_f(wx_p0: &crate::lower::node_::Wx, pos_p1: &crate::lower::model::Pos_, tg_p2: &crate::check::env::TagInfo, level_p3: &crate::lower::model::Ex) -> crate::lower::model::Do {
    let missing_p4 = crate::lower::model::Ex::XCall(Text::lit("Fault::answer"), Array::from(vec![crate::lower::model::Ex::XStr(Text::from(format!("no first value for {}", &tg_p2.name_p)))]));
    if crate::lower::node_::finish::emits_f(wx_p0, pos_p1) {
        {
            let asked_p5 = crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCx), Text::lit("first_value"), Array::from(vec![crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(level_p3.clone()), Text::lit("to_pod"), Array::new())))]));
            crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(Text::from(format!("first_{}", &crate::lower::model::place_text_f(pos_p1)))), crate::lower::expr::try_of_f(&crate::lower::model::Ex::XMethod(Rc::new(asked_p5.clone()), Text::lit("ok_or"), Array::from(vec![missing_p4.clone()]))))
        }
    } else {
        {
            let host_p6 = host_local_f(wx_p0, pos_p1);
            let entry_p7 = crate::prelude::or(&crate::prelude::fold(&wx_p0.places_p, &None, &(|e_o9: &Option<Text>, pl_pa: &crate::lower::node_::Place| if &pl_pa.pos_p == pos_p1 { Some(pl_pa.entry_p.clone()) } else { e_o9.clone() })), &Text::lit(""));
            let asked_p8 = crate::lower::expr::try_of_f(&crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(host_p6.clone())), Text::lit("first_value"), Array::from(vec![crate::lower::model::Ex::XRef(Rc::new(crate::lower::node_::finish::place_at_f(wx_p0, &Text::lit(""), pos_p1))), crate::lower::model::Ex::XRef(Rc::new(level_p3.clone())), crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XVar(entry_p7.clone()))), crate::lower::model::Ex::XCx])));
            crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(Text::from(format!("first_{}", &crate::lower::model::place_text_f(pos_p1)))), crate::lower::expr::try_of_f(&crate::lower::model::Ex::XMethod(Rc::new(crate::lower::expr::try_of_f(&crate::lower::model::Ex::XMethod(Rc::new(asked_p8.clone()), Text::lit("ok_or"), Array::from(vec![missing_p4.clone()])))), answer_accessor_f(tg_p2), Array::new())))
        }
    }
}

/// ```prism
/// HostLocal: fn Wx, Pos -> Text
/// ```
pub fn host_local_f(wx_p0: &crate::lower::node_::Wx, pos_p1: &crate::lower::model::Pos_) -> Text {
    if &pos_p1.scope_p == &Nat::from(0u32) {
        Text::lit("enclosing")
    } else {
        crate::prelude::or(&crate::prelude::index(&wx_p0.scopes_p, &crate::syntax::lexer::chars::dec_f(&pos_p1.scope_p)), &Text::lit(""))
    }
}

/// ```prism
/// AnswerVariant: fn TagInfo -> Text
/// ```
pub fn answer_variant_f(tg_p0: &crate::check::env::TagInfo) -> Text {
    Text::from(format!("crate::Answer::{}", &crate::lower::tag_struct_f(&tg_p0.name_p)))
}

/// ```prism
/// AnswerAccessor: fn TagInfo -> Text
/// ```
pub fn answer_accessor_f(tg_p0: &crate::check::env::TagInfo) -> Text {
    crate::lower::snake_f(&crate::lower::tag_struct_f(&tg_p0.name_p))
}

/// ```prism
/// ElementOutputOf: unbounded fn Wx, Env, TagInfo, OutTy, Pos, ?Bn, Ex -> ((Wx, Wres))
/// ```
pub fn element_output_of_f(wx_p0: &crate::lower::node_::Wx, menv_p1: &crate::lower::types::Env, tg_p2: &crate::check::env::TagInfo, out_p3: &crate::lower::model::OutTy, pos_p4: &crate::lower::model::Pos_, bound_o5: &Option<crate::lower::types::Bn>, level_p6: &crate::lower::model::Ex) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    let lx_p7 = wx_p0.lx_p.clone();
    match crate::lower::types::layer_of_f(&tg_p2.out_p) {
        crate::lower::types::Layer::LyEv => {
            let (id_pc, wx2_pd) = match bound_o5 {
                Some(crate::lower::types::Bn::BnEv(er_p9, _)) => (er_p9.node_p.clone(), wx_p0.clone()),
                _ => {
                    let (nm_pa, w_pb) = crate::lower::node_::fresh_name_f(wx_p0, &Text::from(format!("place_{}", &crate::lower::model::place_text_f(pos_p4))));
                    crate::lower::node_::add_gn_f(&w_pb, &nm_pa, out_p3, &crate::lower::node_::GnKind::GnAnswer, &Nat::from(0u32))
                },
            };
            let wx3_p8 = {
                let mut this: crate::lower::node_::Wx = wx2_pd.clone();
                this.answers_p = crate::prelude::push(&this.answers_p, &(pos_p4.clone(), id_pc.clone(), out_p3.clone(), answer_accessor_f(tg_p2)));
                this
            };
            (wx3_p8.clone(), crate::lower::node_::Wres::WrEv(crate::lower::node_::ev_ref_of_f(&wx3_p8, &id_pc)))
        },
        crate::lower::types::Layer::LyDyn => {
            let (f_pj, wx1_pk) = match bound_o5 {
                Some(crate::lower::types::Bn::BnHold(hf_pi, _)) => (hf_pi.clone(), wx_p0.clone()),
                _ => crate::lower::node_::fresh_name_f(wx_p0, &Text::from(format!("place_{}", &crate::lower::model::place_text_f(pos_p4)))),
            };
            let emits_pe = crate::lower::node_::finish::emits_f(wx_p0, pos_p4);
            let first_pf = if emits_pe {
                crate::lower::model::Ex::XDecode(out_p3.clone(), Rc::new(crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XVar(Text::from(format!("first_{}", &crate::lower::model::place_text_f(pos_p4))))))))
            } else {
                crate::lower::model::Ex::XVar(Text::from(format!("first_{}", &crate::lower::model::place_text_f(pos_p4))))
            };
            let wx2_pg = {
                let mut this: crate::lower::node_::Wx = wx1_pk.clone();
                this.lets_p = crate::prelude::push(&this.lets_p, &first_value_let_f(wx_p0, pos_p4, tg_p2, level_p6));
                this.fields_p = crate::prelude::push(&this.fields_p, &(f_pj.clone(), crate::lower::model::OutTy::OutHold(Rc::new(out_p3.clone())), Text::from(format!("pushed to place {}", &crate::lower::model::place_text_f(pos_p4)))));
                this.inits_p = crate::prelude::push(&this.inits_p, &(f_pj.clone(), crate::lower::model::Ex::XCall(Text::lit("Hold::new"), Array::from(vec![first_pf.clone(), crate::lower::model::Ex::XCx]))));
                this.dyn_places_p = crate::prelude::push(&this.dyn_places_p, &(pos_p4.clone(), f_pj.clone(), out_p3.clone(), answer_accessor_f(tg_p2)));
                this.fallible_p = true;
                this
            };
            let wx3_ph = if emits_pe {
                {
                    let mut this: crate::lower::node_::Wx = wx2_pg.clone();
                    this.lets_p = crate::prelude::push(&this.lets_p, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(Text::from(format!("{}_element", &f_pj))), crate::lower::model::Ex::XMethod(Rc::new(level_p6.clone()), Text::lit("to_pod"), Array::new())));
                    this.fields_p = crate::prelude::push(&this.fields_p, &(Text::from(format!("{}_element", &f_pj)), crate::lower::model::OutTy::OutPod, Text::from(format!("place {}\'s element, which pushes are keyed by", &crate::lower::model::place_text_f(pos_p4)))));
                    this.moves_p = crate::prelude::push(&this.moves_p, &(Text::from(format!("{}_element", &f_pj)), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(Text::from(format!("{}_element", &f_pj)))))));
                    this.build_p = crate::prelude::push(&this.build_p, &crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCx), Text::lit("listen"), Array::from(vec![crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XVar(Text::lit("node"))), Text::from(format!("{}_element", &f_pj))))), crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XCast(Rc::new(crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(Text::lit("node"))))), crate::lower::model::OutTy::OutObj(Rc::new(crate::lower::model::OutTy::OutNamed(Text::lit("Node"), Array::new()))))))]))));
                    this
                }
            } else {
                wx2_pg.clone()
            };
            (wx3_ph.clone(), crate::lower::node_::Wres::WrDyn(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", &f_pj)))), Text::lit("get"), Array::from(vec![crate::lower::model::Ex::XCx])), Array::from(vec![crate::lower::node_::Read::OwnRead(f_pj.clone())]), out_p3.clone()))
        },
        _ => match bound_o5 {
            Some(crate::lower::types::Bn::BnLocal(rs_pl, _, _)) => {
                let f_pm = crate::lower::types::place_stem_f(rs_pl);
                let first_pn = if crate::lower::node_::finish::emits_f(wx_p0, pos_p4) {
                    crate::lower::model::Ex::XDecode(out_p3.clone(), Rc::new(crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XVar(Text::from(format!("first_{}", &crate::lower::model::place_text_f(pos_p4))))))))
                } else {
                    crate::lower::model::Ex::XVar(Text::from(format!("first_{}", &crate::lower::model::place_text_f(pos_p4))))
                };
                let wx2_po = {
                    let mut this: crate::lower::node_::Wx = wx_p0.clone();
                    this.lets_p = crate::prelude::append(&this.lets_p, &Array::from(vec![first_value_let_f(wx_p0, pos_p4, tg_p2, level_p6), crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(f_pm.clone()), first_pn.clone())]));
                    this.fields_p = crate::prelude::push(&this.fields_p, &(f_pm.clone(), out_p3.clone(), Text::from(format!("place {}\'s answer, its first value", &crate::lower::model::place_text_f(pos_p4)))));
                    this.inits_p = crate::prelude::push(&this.inits_p, &(f_pm.clone(), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(f_pm.clone())))));
                    this.fallible_p = true;
                    this
                };
                (wx2_po.clone(), crate::lower::node_::Wres::WrUnit)
            },
            _ => (wx_p0.clone(), crate::lower::node_::Wres::WrUnit),
        },
    }
}
