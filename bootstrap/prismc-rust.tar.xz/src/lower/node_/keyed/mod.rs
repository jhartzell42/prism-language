//! The module `Lower.Node.Keyed`, from `target/bootstrap/src/prismc/lower/node/keyed.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// `RowLocal`:
///
/// ```prism
/// type RowLocal = record:
/// ```
#[derive(Clone)]
pub struct RowLocal {
    pub name_p: Text,
    pub field_p: Text,
    pub ty_p: crate::lower::model::OutTy,
    pub passed_p: crate::lower::model::Ex,
}

impl ToPod for RowLocal {
    fn to_pod(&self) -> Pod {
        Pod::record("RowLocal", vec![("name", self.name_p.to_pod()), ("field", self.field_p.to_pod()), ("ty", self.ty_p.to_pod()), ("passed", self.passed_p.to_pod())])
    }
}

impl FromPod for RowLocal {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(RowLocal { name_p: FromPod::from_pod(field(p, "name")?)?, field_p: FromPod::from_pod(field(p, "field")?)?, ty_p: FromPod::from_pod(field(p, "ty")?)?, passed_p: FromPod::from_pod(field(p, "passed")?)? })
    }
}

/// ```prism
/// ForLine: unbounded fn Wx, Env, Env, ?ForBinders, Expr, Block, Expr, ?Bn -> ((Wx, Wres))
/// ```
pub fn for_line_f(wx_p0: &crate::lower::node_::Wx, benv_p1: &crate::lower::types::Env, menv_p2: &crate::lower::types::Env, binders_o3: &Option<crate::syntax::ForBinders>, source_p4: &crate::syntax::Expr, body_p5: &crate::syntax::Block, e_p6: &crate::syntax::Expr, bound_o7: &Option<crate::lower::types::Bn>) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    let lx_p8 = wx_p0.lx_p.clone();
    let pos_p9 = wx_p0.pos_p.clone();
    let wx1_pa = {
        let mut this: crate::lower::node_::Wx = wx_p0.clone();
        this.pos_p = crate::lower::model::next_pos_f(&this.pos_p);
        this
    };
    let (src_ex_p12, reads_p13) = crate::lower::node_::dynamics::dynamic_expr_f(&wx1_pa, menv_p2, source_p4);
    let src_ty_pb = crate::lower::types::peel_f(&crate::lower::type_at_f(&lx_p8, &source_p4.span_p));
    let (kt_p17, vt_p18, keyed_p19) = match &src_ty_pb {
        crate::check::types::Ty::TyMap(k_p14, v_p15) => (crate::lower::types::out_ty_of_f(&lx_p8, &**k_p14), crate::lower::types::out_ty_of_f(&lx_p8, &**v_p15), true),
        crate::check::types::Ty::TyArray(v_p16) => (crate::lower::model::OutTy::OutNat, crate::lower::types::out_ty_of_f(&lx_p8, &**v_p16), false),
        _ => (crate::lower::model::OutTy::OutUnit, crate::lower::model::OutTy::OutUnit, true),
    };
    let src_pc = if keyed_p19 {
        src_ex_p12.clone()
    } else {
        crate::lower::model::Ex::XCall(crate::lower::helper_f(&Text::lit("indexed")), Array::from(vec![crate::lower::model::Ex::XRef(Rc::new(src_ex_p12.clone()))]))
    };
    let base_pd = match bound_o7 {
        Some(crate::lower::types::Bn::BnEv(er_p1a, _)) => crate::lower::node_::gn_of_f(&wx1_pa, &er_p1a.node_p).name_p.clone(),
        _ => Text::lit("rows"),
    };
    let (name_p1b, wx2a_p1c) = crate::lower::node_::fresh_name_f(&wx1_pa, &base_pd);
    let src_getter_pe = Text::from(format!("{}_source", &name_p1b));
    let src_cached_pf = crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_cache", &src_getter_pe)))), Text::lit("get"), Array::from(vec![crate::lower::model::Ex::XCx, crate::lower::model::Ex::XClosure(false, Array::new(), Rc::new(src_pc.clone()))]));
    let src_def_pg = crate::lower::model::MethDef { name_p: src_getter_pe.clone(), recv_p: crate::lower::model::Recv::RecvRef, params_p: Array::new(), cx_p: crate::lower::model::CxArg::CxRef, ret_p: crate::lower::model::OutTy::OutMap(Rc::new(kt_p17.clone()), Rc::new(vt_p18.clone())), body_p: Array::new(), tail_p: src_cached_pf.clone(), doc_p: Text::from(format!("The source of the `for` at place {} by key, at the read point: what its builder and its rows\' entries read, computed once per write behind it.", &crate::lower::model::place_text_f(&pos_p9))) };
    let row_name_ph = Text::from(format!("{}{}Row", &wx_p0.node_p, &row_suffix_f(wx_p0)));
    let locals_pi = row_locals_f(benv_p1, menv_p2, body_p5);
    let row_fields_pj = crate::prelude::append(&Array::from(vec![(Text::lit("key"), kt_p17.clone(), Text::lit("the row\'s key")), (Text::lit("left_entry"), crate::lower::model::OutTy::OutCell(Rc::new(crate::lower::model::OutTy::OutOpt(Rc::new(vt_p18.clone())))), Text::lit("the entry as the tick its key left opened, kept from the row\'s leaving on (R8)")), (Text::lit("parent"), crate::lower::model::OutTy::OutWeak(wx_p0.node_p.clone()), Text::lit("the node of the `for`"))]), &crate::prelude::each(&locals_pi, &(|l_p1d: &RowLocal| (l_p1d.field_p.clone(), l_p1d.ty_p.clone(), Text::from(format!("`{}`, the block\'s", &l_p1d.name_p))))));
    let row_moves_pk = crate::prelude::append(&Array::from(vec![(Text::lit("key"), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(Text::lit("key"))))), (Text::lit("left_entry"), crate::lower::model::Ex::XCall(Text::lit("RefCell::new"), Array::from(vec![crate::lower::model::Ex::XNone]))), (Text::lit("parent"), crate::lower::model::Ex::XVar(Text::lit("parent")))]), &crate::prelude::each(&locals_pi, &(|l_p1e: &RowLocal| (l_p1e.field_p.clone(), crate::lower::model::Ex::XVar(l_p1e.field_p.clone())))));
    let row_taken_pl = crate::prelude::append(&crate::prelude::append(&crate::lower::node_::node_hooks_p(), &Array::from(vec![Text::lit("key"), Text::lit("value"), Text::lit("parent"), Text::lit("entry"), Text::lit("left_entry")])), &crate::prelude::each(&locals_pi, &(|l_p1f: &RowLocal| l_p1f.field_p.clone())));
    let row_wx0_pm = crate::lower::node_::new_wx_f(&lx_p8, &row_name_ph, &row_fields_pj, &Array::new(), &row_moves_pk, &Array::from(vec![entry_getter_f(&src_getter_pe, &vt_p18)]), &crate::prelude::map_of(vec![(Text::lit("entry"), Array::from(vec![crate::lower::node_::Read::ParentRead(src_getter_pe.clone())]))]), &row_taken_pl, &wx_p0.inlining_p, &crate::lower::node_::finish::hosted_rows_o(wx_p0));
    let (wx2p_p1g, row_wx0p_p1h, ports_p1i) = crate::lower::node_::switch_::row_env_f(&wx2a_p1c, &row_wx0_pm, menv_p2, body_p5);
    let wx2_pn = {
        let mut this: crate::lower::node_::Wx = crate::lower::node_::add_field_f(&wx2p_p1g, &Text::from(format!("{}_cache", &src_getter_pe)), &crate::lower::model::OutTy::OutNamed(Text::lit("Cache"), Array::from(vec![crate::lower::model::OutTy::OutMap(Rc::new(kt_p17.clone()), Rc::new(vt_p18.clone()))])), &Text::from(format!("the source of the `for` at place {}, cached (gap SR)", &crate::lower::model::place_text_f(&pos_p9))), &crate::lower::model::Ex::XCall(Text::lit("Cache::new"), Array::new()));
        this.taken_p = crate::prelude::append(&this.taken_p, &Array::from(vec![src_getter_pe.clone(), Text::from(format!("{}_cache", &src_getter_pe))]));
        this.getters_p = crate::prelude::push(&this.getters_p, &src_def_pg);
        this.dyn_reads_p = crate::prelude::insert(&this.dyn_reads_p, &src_getter_pe, &reads_p13);
        this
    };
    let key_b_po = crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(Text::lit("key")), crate::lower::types::Holding::Owned, kt_p17.clone());
    let key_m_pp = crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::lit("key")), crate::lower::types::Holding::Owned, kt_p17.clone());
    let benv_l_pq = events_of_f(&ports_p1i, &crate::prelude::fold(&locals_pi, &row_reads_f(benv_p1, &crate::lower::node_::switch_::parent_arg_p()), &(|en_p1j: &crate::lower::types::Env, l_p1k: &RowLocal| crate::lower::types::bind_f(en_p1j, &l_p1k.name_p, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(l_p1k.field_p.clone()), crate::lower::types::Holding::Owned, l_p1k.ty_p.clone())))));
    let menv_l_pr = events_of_f(&ports_p1i, &crate::prelude::fold(&locals_pi, &row_reads_f(menv_p2, &crate::lower::node_::switch_::parent_ref_p()), &(|en_p1l: &crate::lower::types::Env, l_p1m: &RowLocal| crate::lower::types::bind_f(en_p1l, &l_p1m.name_p, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), l_p1m.field_p.clone()), crate::lower::types::Holding::Owned, l_p1m.ty_p.clone())))));
    let passed_ps = crate::prelude::append(&hosted_passed_f(wx_p0), &crate::prelude::each(&locals_pi, &(|l_p1n: &RowLocal| l_p1n.passed_p.clone())));
    let row_params_pt = crate::prelude::append(&crate::prelude::append(&Array::from(vec![(Text::lit("key"), kt_p17.clone()), (Text::lit("value"), vt_p18.clone()), (Text::lit("parent"), crate::lower::model::OutTy::OutWeak(wx_p0.node_p.clone()))]), &hosted_params_f(wx_p0)), &crate::prelude::each(&locals_pi, &(|l_p1o: &RowLocal| (l_p1o.field_p.clone(), l_p1o.ty_p.clone()))));
    let (row_wx0f_p20, val_b_p21, val_m_p22, inner_p23) = match &vt_p18 {
        crate::lower::model::OutTy::OutDyn(t_p1p) => {
            let (fname_p1r, row_wx_n_p1s) = crate::lower::node_::fresh_name_f(&row_wx0p_p1h, &crate::lower::snake_f(&for_value_name_f(binders_o3)));
            let (row_wx_f_p1t, fres_p1u) = crate::lower::node_::switch_::entry_flatten_f(&row_wx_n_p1s, &**t_p1p, &Some(crate::lower::types::Bn::BnHold(fname_p1r.clone(), (**t_p1p).clone())));
            let fb_p1q = crate::lower::node_::def::bundle_bn_f(&fres_p1u);
            (row_wx_f_p1t.clone(), fb_p1q.clone(), fb_p1q.clone(), (**t_p1p).clone())
        },
        _ => {
            let entry_m_p1v = crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XSelf), Text::lit("entry"), Array::from(vec![crate::lower::model::Ex::XCx])), Array::from(vec![crate::lower::node_::Read::ParentRead(src_getter_pe.clone())]), vt_p18.clone());
            (row_wx0p_p1h.clone(), crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(Text::lit("value")), crate::lower::types::Holding::Owned, vt_p18.clone()), entry_m_p1v.clone(), vt_p18.clone())
        },
    };
    let (rbe_p24, rme_p25) = for_envs_f(&benv_l_pq, &menv_l_pr, binders_o3, &key_b_po, &key_m_pp, &val_b_p21, &val_m_p22, &inner_p23);
    let row_wx_pu = crate::lower::node_::def::block_into_f(&row_wx0f_p20, &rbe_p24, &rme_p25, body_p5);
    let wx3_pv = {
        let mut this: crate::lower::node_::Wx = wx2_pn.clone();
        this.row_marks_p = crate::prelude::push(&this.row_marks_p, &crate::lower::node_::RowMarks { builder_p: name_p1b.clone(), reads_p: row_place_reads_f(&row_wx_pu), wrote_p: crate::lower::node_::finish::row_hears_f(&row_wx_pu), kind_p: crate::lower::model::RowKind::ForRow });
        this
    };
    let full_p10 = crate::lower::type_at_f(&lx_p8, &e_p6.span_p);
    let out_ty_p11 = crate::lower::types::out_ty_of_f(&lx_p8, &crate::lower::types::peel_f(&full_p10));
    match &row_wx_pu.result_p {
        crate::lower::node_::Wres::WrEv(r_p26) => {
            let (gid_p2b, wx4_p2c) = crate::lower::node_::add_gn_f(&wx3_pv, &Text::from(format!("{}_all", &name_p1b)), &out_ty_p11, &crate::lower::node_::GnKind::GnGather, &Nat::from(1u32));
            let wx5_p27 = crate::lower::node_::add_field_last_f(&wx4_p2c, &Text::from(format!("{}_gathered", &name_p1b)), &crate::lower::model::OutTy::OutStamped(Rc::new(out_ty_p11.clone())), &Text::lit("the rows\' firings this tick, by key"), &crate::lower::model::Ex::XCall(Text::lit("Stamped::new"), Array::new()));
            let wx6_p28 = {
                let mut this: crate::lower::node_::Wx = wx5_p27.clone();
                this.gns_p = crate::prelude::each(&this.gns_p, &(|n_p2d: &crate::lower::node_::Gn| if &n_p2d.id_p == &gid_p2b {
                    crate::lower::node_::dynamics::with_inputs_f(n_p2d, &Array::from(vec![Text::from(format!("{}_gathered", &name_p1b))]))
                } else {
                    n_p2d.clone()
                }));
                this
            };
            let row_done_p29 = crate::lower::node_::connect_f(&row_wx_pu, r_p26, &crate::lower::node_::Sk::SkUp(Text::from(format!("{}_all_in", &name_p1b))));
            let wx7_p2a = add_builder_f(&wx6_p28, &name_p1b, &pos_p9, &kt_p17, &vt_p18, &row_name_ph, &keyed_p19, &reads_p13, &crate::lower::node_::PendingRow { wx_p: row_done_p29.clone(), qk_p: row_name_ph.clone(), params_p: row_params_pt.clone(), gather_o: Some(gid_p2b.clone()) }, &passed_ps);
            (wx7_p2a.clone(), crate::lower::node_::Wres::WrEv(crate::lower::node_::ev_ref_of_f(&wx7_p2a, &gid_p2b)))
        },
        crate::lower::node_::Wres::WrDyn(ex_p2e, result_reads_p2f, rt_p2g) => {
            let gathered_p2h = Text::from(format!("{}_all", &name_p1b));
            let gathered_ty_p2i = crate::lower::model::OutTy::OutMap(Rc::new(kt_p17.clone()), Rc::new(rt_p2g.clone()));
            let own_behind_p2j = crate::prelude::filter(&crate::lower::node_::finish::reads_closed_f(&row_wx_pu.dyn_reads_p, result_reads_p2f), &(|r_p2p: &crate::lower::node_::Read| match r_p2p {
                crate::lower::node_::Read::OwnRead(_) => true,
                crate::lower::node_::Read::ParentRead(_) => false,
            }));
            let row_done_p2k = {
                let mut this: crate::lower::node_::Wx = row_wx_pu.clone();
                this.getters_p = crate::prelude::push(&this.getters_p, &crate::lower::model::MethDef { name_p: Text::lit("result"), recv_p: crate::lower::model::Recv::RecvRef, params_p: Array::new(), cx_p: crate::lower::model::CxArg::CxRef, ret_p: rt_p2g.clone(), body_p: Array::new(), tail_p: ex_p2e.clone(), doc_p: Text::lit("The row\'s result, which the block gathers by key.") });
                this.result_moved_o = if &crate::prelude::len(&own_behind_p2j) > &Nat::from(0u32) {
                    Some((Text::from(format!("{}_moved", &gathered_p2h)), own_behind_p2j.clone()))
                } else {
                    None
                };
                this
            };
            let wx4_p2l = add_builder_f(&wx3_pv, &name_p1b, &pos_p9, &kt_p17, &vt_p18, &row_name_ph, &keyed_p19, &reads_p13, &crate::lower::node_::PendingRow { wx_p: row_done_p2k.clone(), qk_p: row_name_ph.clone(), params_p: row_params_pt.clone(), gather_o: None }, &passed_ps);
            let all_p2m = crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), name_p1b.clone())), Text::lit("borrow"), Array::new())), Text::lit("iter"), Array::new())), Text::lit("map"), Array::from(vec![crate::lower::model::Ex::XClosure(false, Array::from(vec![crate::lower::model::Pa::PaTuple(Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("k")), crate::lower::model::Pa::PaBind(Text::lit("row"))]))]), Rc::new(crate::lower::model::Ex::XTuple(Array::from(vec![crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(Text::lit("k")))), crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("row"))), Text::lit("result"), Array::from(vec![crate::lower::model::Ex::XCx]))]))))]))), Text::lit("collect"), Array::new());
            let what_p2n = Text::from(format!("the dynamic gathered by the `for` at place {}", &crate::lower::model::place_text_f(&pos_p9)));
            let wx5_p2o = {
                let mut this: crate::lower::node_::Wx = wx4_p2l.clone();
                this.taken_p = crate::prelude::append(&this.taken_p, &Array::from(vec![gathered_p2h.clone(), Text::from(format!("{}_now", &gathered_p2h)), Text::from(format!("{}_snap", &gathered_p2h)), Text::from(format!("{}_moved", &gathered_p2h)), Text::from(format!("{}_publish", &gathered_p2h))]));
                this.getters_p = crate::prelude::append(&this.getters_p, &Array::from(vec![crate::lower::model::MethDef { name_p: Text::from(format!("{}_now", &gathered_p2h)), recv_p: crate::lower::model::Recv::RecvRef, params_p: Array::new(), cx_p: crate::lower::model::CxArg::CxRef, ret_p: gathered_ty_p2i.clone(), body_p: Array::new(), tail_p: all_p2m.clone(), doc_p: Text::lit("The rows\' results by key, computed live: what the snapshot of the `for`\'s dynamic is taken from (pick ST).") }, crate::lower::node_::static_::snap_getter_f(&gathered_p2h, &gathered_ty_p2i, &Text::lit("The `for`\'s dynamic, the rows\' results by key, a structural dynamic (pick ST): one tick behind the rows, the snapshot of the tick before the tick the read point is after."))]));
                this.fields_p = crate::prelude::push(&this.fields_p, &(Text::from(format!("{}_snap", &gathered_p2h)), crate::lower::model::OutTy::OutSnapshot(Rc::new(gathered_ty_p2i.clone())), Text::from(format!("the `for` at place {}\'s gathered dynamic, structural: its snapshots, the rows\' results and the lagged dynamic (pick ST)", &crate::lower::model::place_text_f(&pos_p9)))));
                this.inits_p = crate::prelude::push(&this.inits_p, &(Text::from(format!("{}_snap", &gathered_p2h)), crate::lower::model::Ex::XCall(Text::lit("Snapshot::new"), Array::from(vec![crate::lower::model::Ex::XStr(what_p2n.clone())]))));
                this.snaps_p = crate::prelude::push(&this.snaps_p, &crate::lower::node_::SnapDef { name_p: gathered_p2h.clone(), live_p: Text::from(format!("{}_now", &gathered_p2h)), ty_p: gathered_ty_p2i.clone(), eq_p: crate::lower::program::ty_has_eq_f(&lx_p8, &crate::lower::types::peel_f(&full_p10), &Array::new()), builder_p: name_p1b.clone(), before_p: false, what_p: what_p2n.clone() });
                this.dyn_reads_p = crate::prelude::insert(&this.dyn_reads_p, &Text::from(format!("{}_now", &gathered_p2h)), &crate::lower::node_::union_reads_f(&reads_p13, &block_reads_f(&crate::lower::node_::finish::reads_closed_f(&row_wx_pu.dyn_reads_p, result_reads_p2f))));
                this
            };
            (wx5_p2o.clone(), crate::lower::node_::Wres::WrDyn(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XSelf), gathered_p2h.clone(), Array::from(vec![crate::lower::model::Ex::XCx])), Array::from(vec![crate::lower::node_::Read::OwnRead(gathered_p2h.clone())]), gathered_ty_p2i.clone()))
        },
        crate::lower::node_::Wres::WrParts(_) => {
            let wx4_p2q = {
                let mut this: crate::lower::node_::Wx = wx3_pv.clone();
                this.build_p = crate::prelude::push(&this.build_p, &crate::lower::expr::refusal_do_f(&Text::lit("a `for` whose rows end on a bundle (Semantics ch. 4: gathered part by part)")));
                this
            };
            (wx4_p2q.clone(), crate::lower::node_::Wres::WrUnit)
        },
        _ => {
            let wx4_p2r = add_builder_f(&wx3_pv, &name_p1b, &pos_p9, &kt_p17, &vt_p18, &row_name_ph, &keyed_p19, &reads_p13, &crate::lower::node_::PendingRow { wx_p: row_wx_pu.clone(), qk_p: row_name_ph.clone(), params_p: row_params_pt.clone(), gather_o: None }, &passed_ps);
            (wx4_p2r.clone(), crate::lower::node_::Wres::WrUnit)
        },
    }
}

/// The step machine of `ForLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ForLine: unbounded fn Wx, Env, Env, ?ForBinders, Expr, Block, Expr, ?Bn -> ((Wx, Wres))
/// ```
pub struct ForLine {
    pub wx_p0: crate::lower::node_::Wx,
    pub benv_p1: crate::lower::types::Env,
    pub menv_p2: crate::lower::types::Env,
    pub binders_o3: Option<crate::syntax::ForBinders>,
    pub source_p4: crate::syntax::Expr,
    pub body_p5: crate::syntax::Block,
    pub e_p6: crate::syntax::Expr,
    pub bound_o7: Option<crate::lower::types::Bn>,
}

impl prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::node_::Wres)> for ForLine {
    fn cycle(&self) -> prism_rtl::Turn<(crate::lower::node_::Wx, crate::lower::node_::Wres)> {
        let wx_p0 = &self.wx_p0;
        let benv_p1 = &self.benv_p1;
        let menv_p2 = &self.menv_p2;
        let binders_o3 = &self.binders_o3;
        let source_p4 = &self.source_p4;
        let body_p5 = &self.body_p5;
        let e_p6 = &self.e_p6;
        let bound_o7 = &self.bound_o7;
        let lx_p8 = wx_p0.lx_p.clone();
        let pos_p9 = wx_p0.pos_p.clone();
        let wx1_pa = {
            let mut this: crate::lower::node_::Wx = wx_p0.clone();
            this.pos_p = crate::lower::model::next_pos_f(&this.pos_p);
            this
        };
        let binders_o3x = binders_o3.clone();
        let bound_o7x = bound_o7.clone();
        let benv_p1x = benv_p1.clone();
        let body_p5x = body_p5.clone();
        let e_p6x = e_p6.clone();
        let menv_p2x = menv_p2.clone();
        let source_p4x = source_p4.clone();
        let wx_p0x = wx_p0.clone();
        crate::prelude::call_then(crate::lower::node_::dynamics::start_dynamic_expr_f(wx1_pa.clone(), menv_p2x.clone(), source_p4x.clone()), move |dynamic_expr_f_1801: (crate::lower::model::Ex, Array<crate::lower::node_::Read>)| {
            let (src_ex_p12, reads_p13) = dynamic_expr_f_1801;
            let src_ty_pb = crate::lower::types::peel_f(&crate::lower::type_at_f(&lx_p8, &source_p4x.span_p));
            let (kt_p17, vt_p18, keyed_p19) = match &src_ty_pb {
                crate::check::types::Ty::TyMap(k_p14, v_p15) => (crate::lower::types::out_ty_of_f(&lx_p8, &**k_p14), crate::lower::types::out_ty_of_f(&lx_p8, &**v_p15), true),
                crate::check::types::Ty::TyArray(v_p16) => (crate::lower::model::OutTy::OutNat, crate::lower::types::out_ty_of_f(&lx_p8, &**v_p16), false),
                _ => (crate::lower::model::OutTy::OutUnit, crate::lower::model::OutTy::OutUnit, true),
            };
            let src_pc = if keyed_p19 {
                src_ex_p12.clone()
            } else {
                crate::lower::model::Ex::XCall(crate::lower::helper_f(&Text::lit("indexed")), Array::from(vec![crate::lower::model::Ex::XRef(Rc::new(src_ex_p12.clone()))]))
            };
            let base_pd = match &bound_o7x {
                Some(crate::lower::types::Bn::BnEv(er_p1a, _)) => crate::lower::node_::gn_of_f(&wx1_pa, &er_p1a.node_p).name_p.clone(),
                _ => Text::lit("rows"),
            };
            let (name_p1b, wx2a_p1c) = crate::lower::node_::fresh_name_f(&wx1_pa, &base_pd);
            let src_getter_pe = Text::from(format!("{}_source", &name_p1b));
            let src_cached_pf = crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_cache", &src_getter_pe)))), Text::lit("get"), Array::from(vec![crate::lower::model::Ex::XCx, crate::lower::model::Ex::XClosure(false, Array::new(), Rc::new(src_pc.clone()))]));
            let src_def_pg = crate::lower::model::MethDef { name_p: src_getter_pe.clone(), recv_p: crate::lower::model::Recv::RecvRef, params_p: Array::new(), cx_p: crate::lower::model::CxArg::CxRef, ret_p: crate::lower::model::OutTy::OutMap(Rc::new(kt_p17.clone()), Rc::new(vt_p18.clone())), body_p: Array::new(), tail_p: src_cached_pf.clone(), doc_p: Text::from(format!("The source of the `for` at place {} by key, at the read point: what its builder and its rows\' entries read, computed once per write behind it.", &crate::lower::model::place_text_f(&pos_p9))) };
            let row_name_ph = Text::from(format!("{}{}Row", &wx_p0x.node_p, &row_suffix_f(&wx_p0x)));
            let locals_pi = row_locals_f(&benv_p1x, &menv_p2x, &body_p5x);
            let row_fields_pj = crate::prelude::append(&Array::from(vec![(Text::lit("key"), kt_p17.clone(), Text::lit("the row\'s key")), (Text::lit("left_entry"), crate::lower::model::OutTy::OutCell(Rc::new(crate::lower::model::OutTy::OutOpt(Rc::new(vt_p18.clone())))), Text::lit("the entry as the tick its key left opened, kept from the row\'s leaving on (R8)")), (Text::lit("parent"), crate::lower::model::OutTy::OutWeak(wx_p0x.node_p.clone()), Text::lit("the node of the `for`"))]), &crate::prelude::each(&locals_pi, &(|l_p1d: &RowLocal| (l_p1d.field_p.clone(), l_p1d.ty_p.clone(), Text::from(format!("`{}`, the block\'s", &l_p1d.name_p))))));
            let row_moves_pk = crate::prelude::append(&Array::from(vec![(Text::lit("key"), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(Text::lit("key"))))), (Text::lit("left_entry"), crate::lower::model::Ex::XCall(Text::lit("RefCell::new"), Array::from(vec![crate::lower::model::Ex::XNone]))), (Text::lit("parent"), crate::lower::model::Ex::XVar(Text::lit("parent")))]), &crate::prelude::each(&locals_pi, &(|l_p1e: &RowLocal| (l_p1e.field_p.clone(), crate::lower::model::Ex::XVar(l_p1e.field_p.clone())))));
            let row_taken_pl = crate::prelude::append(&crate::prelude::append(&crate::lower::node_::node_hooks_p(), &Array::from(vec![Text::lit("key"), Text::lit("value"), Text::lit("parent"), Text::lit("entry"), Text::lit("left_entry")])), &crate::prelude::each(&locals_pi, &(|l_p1f: &RowLocal| l_p1f.field_p.clone())));
            let row_wx0_pm = crate::lower::node_::new_wx_f(&lx_p8, &row_name_ph, &row_fields_pj, &Array::new(), &row_moves_pk, &Array::from(vec![entry_getter_f(&src_getter_pe, &vt_p18)]), &crate::prelude::map_of(vec![(Text::lit("entry"), Array::from(vec![crate::lower::node_::Read::ParentRead(src_getter_pe.clone())]))]), &row_taken_pl, &wx_p0x.inlining_p, &crate::lower::node_::finish::hosted_rows_o(&wx_p0x));
            let (wx2p_p1g, row_wx0p_p1h, ports_p1i) = crate::lower::node_::switch_::row_env_f(&wx2a_p1c, &row_wx0_pm, &menv_p2x, &body_p5x);
            let wx2_pn = {
                let mut this: crate::lower::node_::Wx = crate::lower::node_::add_field_f(&wx2p_p1g, &Text::from(format!("{}_cache", &src_getter_pe)), &crate::lower::model::OutTy::OutNamed(Text::lit("Cache"), Array::from(vec![crate::lower::model::OutTy::OutMap(Rc::new(kt_p17.clone()), Rc::new(vt_p18.clone()))])), &Text::from(format!("the source of the `for` at place {}, cached (gap SR)", &crate::lower::model::place_text_f(&pos_p9))), &crate::lower::model::Ex::XCall(Text::lit("Cache::new"), Array::new()));
                this.taken_p = crate::prelude::append(&this.taken_p, &Array::from(vec![src_getter_pe.clone(), Text::from(format!("{}_cache", &src_getter_pe))]));
                this.getters_p = crate::prelude::push(&this.getters_p, &src_def_pg);
                this.dyn_reads_p = crate::prelude::insert(&this.dyn_reads_p, &src_getter_pe, &reads_p13);
                this
            };
            let key_b_po = crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(Text::lit("key")), crate::lower::types::Holding::Owned, kt_p17.clone());
            let key_m_pp = crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::lit("key")), crate::lower::types::Holding::Owned, kt_p17.clone());
            let benv_l_pq = events_of_f(&ports_p1i, &crate::prelude::fold(&locals_pi, &row_reads_f(&benv_p1x, &crate::lower::node_::switch_::parent_arg_p()), &(|en_p1j: &crate::lower::types::Env, l_p1k: &RowLocal| crate::lower::types::bind_f(en_p1j, &l_p1k.name_p, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(l_p1k.field_p.clone()), crate::lower::types::Holding::Owned, l_p1k.ty_p.clone())))));
            let menv_l_pr = events_of_f(&ports_p1i, &crate::prelude::fold(&locals_pi, &row_reads_f(&menv_p2x, &crate::lower::node_::switch_::parent_ref_p()), &(|en_p1l: &crate::lower::types::Env, l_p1m: &RowLocal| crate::lower::types::bind_f(en_p1l, &l_p1m.name_p, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), l_p1m.field_p.clone()), crate::lower::types::Holding::Owned, l_p1m.ty_p.clone())))));
            let passed_ps = crate::prelude::append(&hosted_passed_f(&wx_p0x), &crate::prelude::each(&locals_pi, &(|l_p1n: &RowLocal| l_p1n.passed_p.clone())));
            let row_params_pt = crate::prelude::append(&crate::prelude::append(&Array::from(vec![(Text::lit("key"), kt_p17.clone()), (Text::lit("value"), vt_p18.clone()), (Text::lit("parent"), crate::lower::model::OutTy::OutWeak(wx_p0x.node_p.clone()))]), &hosted_params_f(&wx_p0x)), &crate::prelude::each(&locals_pi, &(|l_p1o: &RowLocal| (l_p1o.field_p.clone(), l_p1o.ty_p.clone()))));
            let (row_wx0f_p20, val_b_p21, val_m_p22, inner_p23) = match &vt_p18 {
                crate::lower::model::OutTy::OutDyn(t_p1p) => {
                    let (fname_p1r, row_wx_n_p1s) = crate::lower::node_::fresh_name_f(&row_wx0p_p1h, &crate::lower::snake_f(&for_value_name_f(&binders_o3x)));
                    let (row_wx_f_p1t, fres_p1u) = crate::lower::node_::switch_::entry_flatten_f(&row_wx_n_p1s, &**t_p1p, &Some(crate::lower::types::Bn::BnHold(fname_p1r.clone(), (**t_p1p).clone())));
                    let fb_p1q = crate::lower::node_::def::bundle_bn_f(&fres_p1u);
                    (row_wx_f_p1t.clone(), fb_p1q.clone(), fb_p1q.clone(), (**t_p1p).clone())
                },
                _ => {
                    let entry_m_p1v = crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XSelf), Text::lit("entry"), Array::from(vec![crate::lower::model::Ex::XCx])), Array::from(vec![crate::lower::node_::Read::ParentRead(src_getter_pe.clone())]), vt_p18.clone());
                    (row_wx0p_p1h.clone(), crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(Text::lit("value")), crate::lower::types::Holding::Owned, vt_p18.clone()), entry_m_p1v.clone(), vt_p18.clone())
                },
            };
            let (rbe_p24, rme_p25) = for_envs_f(&benv_l_pq, &menv_l_pr, &binders_o3x, &key_b_po, &key_m_pp, &val_b_p21, &val_m_p22, &inner_p23);
            crate::prelude::call_then(crate::lower::node_::def::start_block_into_f(row_wx0f_p20.clone(), rbe_p24.clone(), rme_p25.clone(), body_p5x.clone()), move |block_into_f_6202: crate::lower::node_::Wx| {
                let row_wx_pu = block_into_f_6202;
                let wx3_pv = {
                    let mut this: crate::lower::node_::Wx = wx2_pn.clone();
                    this.row_marks_p = crate::prelude::push(&this.row_marks_p, &crate::lower::node_::RowMarks { builder_p: name_p1b.clone(), reads_p: row_place_reads_f(&row_wx_pu), wrote_p: crate::lower::node_::finish::row_hears_f(&row_wx_pu), kind_p: crate::lower::model::RowKind::ForRow });
                    this
                };
                let full_p10 = crate::lower::type_at_f(&lx_p8, &e_p6x.span_p);
                crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p8.clone(), crate::lower::types::peel_f(&full_p10)), move |out_ty_of_f_6441: crate::lower::model::OutTy| {
                    let out_ty_p11 = out_ty_of_f_6441;
                    match &row_wx_pu.result_p {
                        crate::lower::node_::Wres::WrEv(r_p26) => {
                            let (gid_p2b, wx4_p2c) = crate::lower::node_::add_gn_f(&wx3_pv, &Text::from(format!("{}_all", &name_p1b)), &out_ty_p11, &crate::lower::node_::GnKind::GnGather, &Nat::from(1u32));
                            let wx5_p27 = crate::lower::node_::add_field_last_f(&wx4_p2c, &Text::from(format!("{}_gathered", &name_p1b)), &crate::lower::model::OutTy::OutStamped(Rc::new(out_ty_p11.clone())), &Text::lit("the rows\' firings this tick, by key"), &crate::lower::model::Ex::XCall(Text::lit("Stamped::new"), Array::new()));
                            let wx6_p28 = {
                                let mut this: crate::lower::node_::Wx = wx5_p27.clone();
                                this.gns_p = crate::prelude::each(&this.gns_p, &(|n_p2d: &crate::lower::node_::Gn| if &n_p2d.id_p == &gid_p2b {
                                    crate::lower::node_::dynamics::with_inputs_f(n_p2d, &Array::from(vec![Text::from(format!("{}_gathered", &name_p1b))]))
                                } else {
                                    n_p2d.clone()
                                }));
                                this
                            };
                            let row_done_p29 = crate::lower::node_::connect_f(&row_wx_pu, r_p26, &crate::lower::node_::Sk::SkUp(Text::from(format!("{}_all_in", &name_p1b))));
                            let wx7_p2a = add_builder_f(&wx6_p28, &name_p1b, &pos_p9, &kt_p17, &vt_p18, &row_name_ph, &keyed_p19, &reads_p13, &crate::lower::node_::PendingRow { wx_p: row_done_p29.clone(), qk_p: row_name_ph.clone(), params_p: row_params_pt.clone(), gather_o: Some(gid_p2b.clone()) }, &passed_ps);
                            prism_rtl::Turn::Finished((wx7_p2a.clone(), crate::lower::node_::Wres::WrEv(crate::lower::node_::ev_ref_of_f(&wx7_p2a, &gid_p2b))))
                        },
                        crate::lower::node_::Wres::WrDyn(ex_p2e, result_reads_p2f, rt_p2g) => {
                            let gathered_p2h = Text::from(format!("{}_all", &name_p1b));
                            let gathered_ty_p2i = crate::lower::model::OutTy::OutMap(Rc::new(kt_p17.clone()), Rc::new(rt_p2g.clone()));
                            let own_behind_p2j = crate::prelude::filter(&crate::lower::node_::finish::reads_closed_f(&row_wx_pu.dyn_reads_p, result_reads_p2f), &(|r_p2p: &crate::lower::node_::Read| match r_p2p {
                                crate::lower::node_::Read::OwnRead(_) => true,
                                crate::lower::node_::Read::ParentRead(_) => false,
                            }));
                            let row_done_p2k = {
                                let mut this: crate::lower::node_::Wx = row_wx_pu.clone();
                                this.getters_p = crate::prelude::push(&this.getters_p, &crate::lower::model::MethDef { name_p: Text::lit("result"), recv_p: crate::lower::model::Recv::RecvRef, params_p: Array::new(), cx_p: crate::lower::model::CxArg::CxRef, ret_p: rt_p2g.clone(), body_p: Array::new(), tail_p: ex_p2e.clone(), doc_p: Text::lit("The row\'s result, which the block gathers by key.") });
                                this.result_moved_o = if &crate::prelude::len(&own_behind_p2j) > &Nat::from(0u32) {
                                    Some((Text::from(format!("{}_moved", &gathered_p2h)), own_behind_p2j.clone()))
                                } else {
                                    None
                                };
                                this
                            };
                            let wx4_p2l = add_builder_f(&wx3_pv, &name_p1b, &pos_p9, &kt_p17, &vt_p18, &row_name_ph, &keyed_p19, &reads_p13, &crate::lower::node_::PendingRow { wx_p: row_done_p2k.clone(), qk_p: row_name_ph.clone(), params_p: row_params_pt.clone(), gather_o: None }, &passed_ps);
                            let all_p2m = crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), name_p1b.clone())), Text::lit("borrow"), Array::new())), Text::lit("iter"), Array::new())), Text::lit("map"), Array::from(vec![crate::lower::model::Ex::XClosure(false, Array::from(vec![crate::lower::model::Pa::PaTuple(Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("k")), crate::lower::model::Pa::PaBind(Text::lit("row"))]))]), Rc::new(crate::lower::model::Ex::XTuple(Array::from(vec![crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(Text::lit("k")))), crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("row"))), Text::lit("result"), Array::from(vec![crate::lower::model::Ex::XCx]))]))))]))), Text::lit("collect"), Array::new());
                            let what_p2n = Text::from(format!("the dynamic gathered by the `for` at place {}", &crate::lower::model::place_text_f(&pos_p9)));
                            let wx5_p2o = {
                                let mut this: crate::lower::node_::Wx = wx4_p2l.clone();
                                this.taken_p = crate::prelude::append(&this.taken_p, &Array::from(vec![gathered_p2h.clone(), Text::from(format!("{}_now", &gathered_p2h)), Text::from(format!("{}_snap", &gathered_p2h)), Text::from(format!("{}_moved", &gathered_p2h)), Text::from(format!("{}_publish", &gathered_p2h))]));
                                this.getters_p = crate::prelude::append(&this.getters_p, &Array::from(vec![crate::lower::model::MethDef { name_p: Text::from(format!("{}_now", &gathered_p2h)), recv_p: crate::lower::model::Recv::RecvRef, params_p: Array::new(), cx_p: crate::lower::model::CxArg::CxRef, ret_p: gathered_ty_p2i.clone(), body_p: Array::new(), tail_p: all_p2m.clone(), doc_p: Text::lit("The rows\' results by key, computed live: what the snapshot of the `for`\'s dynamic is taken from (pick ST).") }, crate::lower::node_::static_::snap_getter_f(&gathered_p2h, &gathered_ty_p2i, &Text::lit("The `for`\'s dynamic, the rows\' results by key, a structural dynamic (pick ST): one tick behind the rows, the snapshot of the tick before the tick the read point is after."))]));
                                this.fields_p = crate::prelude::push(&this.fields_p, &(Text::from(format!("{}_snap", &gathered_p2h)), crate::lower::model::OutTy::OutSnapshot(Rc::new(gathered_ty_p2i.clone())), Text::from(format!("the `for` at place {}\'s gathered dynamic, structural: its snapshots, the rows\' results and the lagged dynamic (pick ST)", &crate::lower::model::place_text_f(&pos_p9)))));
                                this.inits_p = crate::prelude::push(&this.inits_p, &(Text::from(format!("{}_snap", &gathered_p2h)), crate::lower::model::Ex::XCall(Text::lit("Snapshot::new"), Array::from(vec![crate::lower::model::Ex::XStr(what_p2n.clone())]))));
                                this.snaps_p = crate::prelude::push(&this.snaps_p, &crate::lower::node_::SnapDef { name_p: gathered_p2h.clone(), live_p: Text::from(format!("{}_now", &gathered_p2h)), ty_p: gathered_ty_p2i.clone(), eq_p: crate::lower::program::ty_has_eq_f(&lx_p8, &crate::lower::types::peel_f(&full_p10), &Array::new()), builder_p: name_p1b.clone(), before_p: false, what_p: what_p2n.clone() });
                                this.dyn_reads_p = crate::prelude::insert(&this.dyn_reads_p, &Text::from(format!("{}_now", &gathered_p2h)), &crate::lower::node_::union_reads_f(&reads_p13, &block_reads_f(&crate::lower::node_::finish::reads_closed_f(&row_wx_pu.dyn_reads_p, result_reads_p2f))));
                                this
                            };
                            prism_rtl::Turn::Finished((wx5_p2o.clone(), crate::lower::node_::Wres::WrDyn(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XSelf), gathered_p2h.clone(), Array::from(vec![crate::lower::model::Ex::XCx])), Array::from(vec![crate::lower::node_::Read::OwnRead(gathered_p2h.clone())]), gathered_ty_p2i.clone())))
                        },
                        crate::lower::node_::Wres::WrParts(_) => {
                            let wx4_p2q = {
                                let mut this: crate::lower::node_::Wx = wx3_pv.clone();
                                this.build_p = crate::prelude::push(&this.build_p, &crate::lower::expr::refusal_do_f(&Text::lit("a `for` whose rows end on a bundle (Semantics ch. 4: gathered part by part)")));
                                this
                            };
                            prism_rtl::Turn::Finished((wx4_p2q.clone(), crate::lower::node_::Wres::WrUnit))
                        },
                        _ => {
                            let wx4_p2r = add_builder_f(&wx3_pv, &name_p1b, &pos_p9, &kt_p17, &vt_p18, &row_name_ph, &keyed_p19, &reads_p13, &crate::lower::node_::PendingRow { wx_p: row_wx_pu.clone(), qk_p: row_name_ph.clone(), params_p: row_params_pt.clone(), gather_o: None }, &passed_ps);
                            prism_rtl::Turn::Finished((wx4_p2r.clone(), crate::lower::node_::Wres::WrUnit))
                        },
                    }
                })
            })
        })
    }
}

/// `Start ForLine, x`: what the function value is when passed to `@Run`.
pub fn start_for_line_f(wx_p0: crate::lower::node_::Wx, benv_p1: crate::lower::types::Env, menv_p2: crate::lower::types::Env, binders_o3: Option<crate::syntax::ForBinders>, source_p4: crate::syntax::Expr, body_p5: crate::syntax::Block, e_p6: crate::syntax::Expr, bound_o7: Option<crate::lower::types::Bn>) -> Rc<dyn prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::node_::Wres)>> {
    Rc::new(ForLine { wx_p0, benv_p1, menv_p2, binders_o3, source_p4, body_p5, e_p6, bound_o7 })
}

/// ```prism
/// EntryGetter: fn Text, OutTy -> MethDef
/// ```
pub fn entry_getter_f(src_getter_p0: &Text, vt_p1: &crate::lower::model::OutTy) -> crate::lower::model::MethDef {
    let found_p2 = crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("parent"))), src_getter_p0.clone(), Array::from(vec![crate::lower::model::Ex::XCx]))), Text::lit("get"), Array::from(vec![crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::lit("key"))))]))), Text::lit("cloned"), Array::new());
    let opened_p3 = crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCx), Text::lit("before"), Array::from(vec![crate::lower::model::Ex::XClosure(false, Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("cx"))]), Rc::new(found_p2.clone()))]))), Text::lit("expect"), Array::from(vec![crate::lower::model::Ex::XStr(Text::lit("a row\'s key is in its source as its tick opened"))]));
    let body_p4 = Array::from(vec![crate::lower::model::Do::DoIfLet(crate::lower::model::Pa::PaCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("v"))])), crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::lit("left_entry"))), Text::lit("borrow"), Array::new())), Text::lit("as_ref"), Array::new()), Array::from(vec![crate::lower::model::Do::DoReturn(crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(Text::lit("v")))))]), Array::new()), crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(Text::lit("parent")), crate::lower::node_::switch_::parent_ref_p())]);
    let tail_p5 = crate::lower::model::Ex::XMatch(Rc::new(found_p2.clone()), Array::from(vec![crate::lower::model::XArm { pat_p: crate::lower::model::Pa::PaCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("v"))])), conds_p: Array::new(), body_p: crate::lower::model::Ex::XVar(Text::lit("v")) }, crate::lower::model::XArm { pat_p: crate::lower::model::Pa::PaUnit(Text::lit("None")), conds_p: Array::new(), body_p: opened_p3.clone() }]), false, vt_p1.clone());
    crate::lower::model::MethDef { name_p: Text::lit("entry"), recv_p: crate::lower::model::Recv::RecvRef, params_p: Array::new(), cx_p: crate::lower::model::CxArg::CxRef, ret_p: vt_p1.clone(), body_p: body_p4.clone(), tail_p: tail_p5.clone(), doc_p: Text::lit("The row\'s entry, `$_`: the block\'s source at this key, at the read point; from the row\'s leaving on, the value as the leaving tick opened.") }
}

/// ```prism
/// AddBuilder: fn Wx, Text, Pos, OutTy, OutTy, Text, Bool, [Read], PendingRow, [Ex] -> Wx
/// ```
pub fn add_builder_f(wx_p0: &crate::lower::node_::Wx, name_p1: &Text, pos_p2: &crate::lower::model::Pos_, kt_p3: &crate::lower::model::OutTy, vt_p4: &crate::lower::model::OutTy, row_name_p5: &Text, keyed_p6: &bool, reads_p7: &Array<crate::lower::node_::Read>, waiting_p8: &crate::lower::node_::PendingRow, passed_p9: &Array<crate::lower::model::Ex>) -> crate::lower::node_::Wx {
    let wx0_pa = crate::lower::node_::add_field_last_f(wx_p0, name_p1, &crate::lower::model::OutTy::OutCell(Rc::new(crate::lower::model::OutTy::OutMap(Rc::new(kt_p3.clone()), Rc::new(crate::lower::model::OutTy::OutRc(Rc::new(crate::lower::model::OutTy::OutNamed(row_name_p5.clone(), Array::new()))))))), &Text::from(format!("the rows of the `for` at place {}", &crate::lower::model::place_text_f(pos_p2))), &crate::lower::model::Ex::XCall(Text::lit("RefCell::new"), Array::from(vec![crate::lower::model::Ex::XCall(Text::lit("Map::new"), Array::new())])));
    let wx1_pb = crate::lower::node_::add_field_last_f(&wx0_pa, &Text::from(format!("{}_from", name_p1)), &crate::lower::model::OutTy::OutCell(Rc::new(crate::lower::model::OutTy::OutMap(Rc::new(kt_p3.clone()), Rc::new(vt_p4.clone())))), &Text::from(format!("the source the rows of the `for` at place {} were last built from", &crate::lower::model::place_text_f(pos_p2))), &crate::lower::model::Ex::XCall(Text::lit("RefCell::new"), Array::from(vec![crate::lower::model::Ex::XCall(Text::lit("Map::new"), Array::new())])));
    let replaced_pc = crate::prelude::each(&crate::prelude::filter(&waiting_p8.wx_p.flattens_p, &(|fl_pd: &crate::lower::node_::FlatDef| &fl_pd.generation_p == &Text::lit(""))), &(|fl_pe: &crate::lower::node_::FlatDef| Text::from(format!("{}_replaced", &fl_pe.name_p))));
    let mut this: crate::lower::node_::Wx = wx1_pb.clone();
    this.builders_p = crate::prelude::push(&this.builders_p, &crate::lower::model::ForDef { name_p: name_p1.clone(), pos_p: pos_p2.clone(), at_p: crate::lower::node_::finish::place_at_f(wx_p0, &Text::lit("self"), pos_p2), key_ty_p: kt_p3.clone(), value_ty_p: vt_p4.clone(), row_node_p: row_name_p5.clone(), keyed_p: *keyed_p6, source_p: Text::from(format!("{}_source", name_p1)), parent_p: crate::lower::model::Ex::XWeak(Rc::new(crate::lower::model::Ex::XSelf)), passed_p: passed_p9.clone(), moved_p: crate::prelude::or(&crate::lower::node_::finish::hosted_rows_o(wx_p0), &Text::lit("")), replaced_p: replaced_pc.clone() });
    this.build_holds_p = crate::lower::node_::union_reads_f(&this.build_holds_p, reads_p7);
    this.pending_p = crate::prelude::push(&this.pending_p, waiting_p8);
    this
}

/// ```prism
/// ForValueName: fn ?ForBinders -> Text
/// ```
pub fn for_value_name_f(binders_o0: &Option<crate::syntax::ForBinders>) -> Text {
    match binders_o0 {
        Some(fb_p1) => match &fb_p1.second_o {
            Some(p_p2) => pattern_name_or_f(p_p2, &Text::lit("flatten")),
            None => pattern_name_or_f(&fb_p1.first_p, &Text::lit("flatten")),
        },
        None => Text::lit("flatten"),
    }
}

/// ```prism
/// PatternNameOr: fn Pattern, Text -> Text
/// ```
pub fn pattern_name_or_f(p_p0: &crate::syntax::Pattern_, other_p1: &Text) -> Text {
    match &*p_p0.kind_p {
        crate::syntax::PatternKind::PName(n_p2) => crate::check::env::sname_key_f(n_p2),
        crate::syntax::PatternKind::PGroup(q_p3) => pattern_name_or_f(&**q_p3, other_p1),
        _ => other_p1.clone(),
    }
}

/// ```prism
/// RowPlaceReads: fn Wx -> [Read]
/// ```
pub fn row_place_reads_f(row_wx_p0: &crate::lower::node_::Wx) -> Array<crate::lower::node_::Read> {
    crate::prelude::fold(&row_wx_p0.places_p, &Array::new(), &(|acc_p1: &Array<crate::lower::node_::Read>, pl_p2: &crate::lower::node_::Place| crate::lower::node_::union_reads_f(acc_p1, &block_reads_f(&crate::lower::node_::finish::reads_closed_f(&row_wx_p0.dyn_reads_p, &pl_p2.reads_p)))))
}

/// ```prism
/// HostedParams: fn Wx -> [((Text, OutTy))]
/// ```
pub fn hosted_params_f(wx_p0: &crate::lower::node_::Wx) -> Array<(Text, crate::lower::model::OutTy)> {
    match crate::lower::node_::finish::hosted_rows_o(wx_p0) {
        Some(_) => Array::from(vec![(Text::lit("enclosing"), crate::lower::types::host_of_ty_p())]),
        None => Array::new(),
    }
}

/// ```prism
/// HostedPassed: fn Wx -> [Ex]
/// ```
pub fn hosted_passed_f(wx_p0: &crate::lower::node_::Wx) -> Array<crate::lower::model::Ex> {
    match crate::lower::node_::finish::hosted_rows_o(wx_p0) {
        Some(_) => Array::from(vec![crate::lower::model::Ex::XClone(Rc::new(crate::lower::node_::finish::host_field_ex_f(wx_p0, &wx_p0.pos_p)))]),
        None => Array::new(),
    }
}

/// ```prism
/// RowReads: fn Env, Ex -> Env
/// ```
pub fn row_reads_f(env_p0: &crate::lower::types::Env, pref_p1: &crate::lower::model::Ex) -> crate::lower::types::Env {
    crate::prelude::fold(&crate::prelude::keys(&env_p0.names_p), env_p0, &(|en_p2: &crate::lower::types::Env, k_p3: &Text| 'm15233: {
        let scrutinee = &crate::prelude::get(&env_p0.names_p, k_p3);
        if let Some(crate::lower::types::Bn::BnHold(f_p4, t_p5)) = scrutinee {
            break 'm15233 crate::lower::types::bind_f(en_p2, k_p3, &crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(pref_p1.clone()), f_p4.clone())), Text::lit("get"), Array::from(vec![crate::lower::model::Ex::XCx])), Array::from(vec![crate::lower::node_::Read::ParentRead(f_p4.clone())]), t_p5.clone()));
        }
        if let Some(crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(m15233_1_0_0, m_p6, xs_p7), _, t_p8)) = scrutinee && let crate::lower::model::Ex::XSelf = &**m15233_1_0_0 {
            break 'm15233 crate::lower::types::bind_f(en_p2, k_p3, &crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(Rc::new(pref_p1.clone()), m_p6.clone(), xs_p7.clone()), Array::from(vec![crate::lower::node_::Read::ParentRead(m_p6.clone())]), t_p8.clone()));
        }
        if let Some(crate::lower::types::Bn::BnDyn(_, _, _)) = scrutinee {
            break 'm15233 match crate::prelude::get(&env_p0.names_p, &Text::from(format!("{}#row", k_p3))) {
                Some(crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(_, m_p9, xs_pa), _, t_pb)) => crate::lower::types::bind_f(en_p2, k_p3, &crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(Rc::new(pref_p1.clone()), m_p9.clone(), xs_pa), Array::from(vec![crate::lower::node_::Read::ParentRead(m_p9.clone())]), t_pb)),
                _ => en_p2.clone(),
            };
        }
        en_p2.clone()
    }))
}

/// ```prism
/// EventsOf: fn Env, Env -> Env
/// ```
pub fn events_of_f(ports_p0: &crate::lower::types::Env, env_p1: &crate::lower::types::Env) -> crate::lower::types::Env {
    crate::prelude::fold(&crate::prelude::keys(&ports_p0.names_p), env_p1, &(|en_p2: &crate::lower::types::Env, k_p3: &Text| match crate::prelude::get(&ports_p0.names_p, k_p3) {
        Some(crate::lower::types::Bn::BnEv(er_p4, t_p5)) => crate::lower::types::bind_f(en_p2, k_p3, &crate::lower::types::Bn::BnEv(er_p4, t_p5)),
        _ => en_p2.clone(),
    }))
}

/// ```prism
/// BlockReads: fn [Read] -> [Read]
/// ```
pub fn block_reads_f(reads_p0: &Array<crate::lower::node_::Read>) -> Array<crate::lower::node_::Read> {
    crate::prelude::fold(reads_p0, &Array::new(), &(|acc_p1: &Array<crate::lower::node_::Read>, r_p2: &crate::lower::node_::Read| match r_p2 {
        crate::lower::node_::Read::ParentRead(f_p3) => crate::lower::node_::add_read_f(acc_p1, &crate::lower::node_::Read::OwnRead(f_p3.clone())),
        crate::lower::node_::Read::OwnRead(_) => acc_p1.clone(),
    }))
}

/// ```prism
/// RowLocals: unbounded fn Env, Env, Block -> [RowLocal]
/// ```
pub fn row_locals_f(benv_p0: &crate::lower::types::Env, menv_p1: &crate::lower::types::Env, body_p2: &crate::syntax::Block) -> Array<RowLocal> {
    crate::prelude::fold(&crate::lower::expr::read_names_f(&crate::check::typed::print::block_exprs_f(body_p2)), &Array::new(), &(|acc_p3: &Array<RowLocal>, n_p4: &Text| match crate::prelude::get(&menv_p1.names_p, n_p4) {
        Some(crate::lower::types::Bn::BnLocal(rs_p5, mode_p6, t_p7)) => {
            let field_p8 = crate::lower::snake_f(n_p4);
            if (((&field_p8 == &Text::lit("key")) || (&field_p8 == &Text::lit("value"))) || (&field_p8 == &Text::lit("parent"))) || (&field_p8 == &Text::lit("path")) {
                acc_p3.clone()
            } else {
                crate::prelude::push(acc_p3, &RowLocal { name_p: n_p4.clone(), field_p: field_p8.clone(), ty_p: t_p7.clone(), passed_p: crate::lower::types::own_f(&crate::lower::types::Vl::VlPlace(rs_p5, mode_p6, t_p7.clone())) })
            }
        },
        _ => acc_p3.clone(),
    }))
}

/// ```prism
/// ForEnvs: unbounded fn Env, Env, ?ForBinders, Bn, Bn, Bn, Bn, OutTy -> ((Env, Env))
/// ```
pub fn for_envs_f(benv_p0: &crate::lower::types::Env, menv_p1: &crate::lower::types::Env, binders_o2: &Option<crate::syntax::ForBinders>, key_b_p3: &crate::lower::types::Bn, key_m_p4: &crate::lower::types::Bn, val_b_p5: &crate::lower::types::Bn, val_m_p6: &crate::lower::types::Bn, vt_p7: &crate::lower::model::OutTy) -> (crate::lower::types::Env, crate::lower::types::Env) {
    let be0_p8 = crate::lower::types::bind_f(&crate::lower::types::bind_f(benv_p0, &Text::lit("key"), key_b_p3), &Text::lit("$_"), val_b_p5);
    let me0_p9 = crate::lower::types::bind_f(&crate::lower::types::bind_f(menv_p1, &Text::lit("key"), key_m_p4), &Text::lit("$_"), val_m_p6);
    match binders_o2 {
        None => (be0_p8.clone(), me0_p9.clone()),
        Some(fb_pa) => match &fb_pa.second_o {
            Some(second_pb) => {
                let be1_pc = bind_pat_f(&be0_p8, &fb_pa.first_p, key_b_p3, &crate::lower::model::Ex::XVar(Text::lit("key")), &kt0_p());
                let me1_pd = bind_pat_f(&me0_p9, &fb_pa.first_p, key_m_p4, &crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::lit("key")), &kt0_p());
                (bind_pat_f(&be1_pc, second_pb, val_b_p5, &crate::lower::model::Ex::XVar(Text::lit("value")), vt_p7), bind_pat_f(&me1_pd, second_pb, val_m_p6, &crate::lower::model::Ex::XUnit, vt_p7))
            },
            None => (bind_pat_f(&be0_p8, &fb_pa.first_p, val_b_p5, &crate::lower::model::Ex::XVar(Text::lit("value")), vt_p7), bind_pat_f(&me0_p9, &fb_pa.first_p, val_m_p6, &crate::lower::model::Ex::XUnit, vt_p7)),
        },
    }
}

/// ```prism
/// let kt0
/// ```
pub fn kt0_p() -> crate::lower::model::OutTy {
    crate::lower::model::OutTy::OutUnit
}

/// ```prism
/// BindPat: fn Env, Pattern, Bn, Ex, OutTy -> Env
/// ```
pub fn bind_pat_f(env_p0: &crate::lower::types::Env, p_p1: &crate::syntax::Pattern_, b_p2: &crate::lower::types::Bn, whole_p3: &crate::lower::model::Ex, t_p4: &crate::lower::model::OutTy) -> crate::lower::types::Env {
    match &*p_p1.kind_p {
        crate::syntax::PatternKind::PName(n_p5) => crate::lower::types::bind_f(env_p0, &crate::check::env::sname_key_f(n_p5), b_p2),
        crate::syntax::PatternKind::PGroup(q_p6) => bind_pat_f(env_p0, &**q_p6, b_p2, whole_p3, t_p4),
        crate::syntax::PatternKind::PTuple(ps_p7) => {
            let ts_p8 = match t_p4 {
                crate::lower::model::OutTy::OutTuple(xs_p9) => xs_p9.clone(),
                _ => Array::new(),
            };
            crate::prelude::fold(&crate::check::errors::range0_f(&crate::prelude::len(ps_p7)), env_p0, &(|en_pa: &crate::lower::types::Env, i_pb: &Nat| match crate::prelude::index(ps_p7, i_pb) {
                Some(q_pc) => match &*q_pc.kind_p {
                    crate::syntax::PatternKind::PName(n_pd) => crate::lower::types::bind_f(en_pa, &crate::check::env::sname_key_f(n_pd), &part_bn_f(b_p2, whole_p3, i_pb, &crate::prelude::or(&crate::prelude::index(&ts_p8, i_pb), &crate::lower::model::OutTy::OutUnit))),
                    _ => en_pa.clone(),
                },
                None => en_pa.clone(),
            }))
        },
        _ => env_p0.clone(),
    }
}

/// ```prism
/// PartBn: fn Bn, Ex, Nat, OutTy -> Bn
/// ```
pub fn part_bn_f(bn0: &crate::lower::types::Bn, whole_p2: &crate::lower::model::Ex, i_p3: &Nat, t_p4: &crate::lower::model::OutTy) -> crate::lower::types::Bn {
    match bn0 {
        crate::lower::types::Bn::BnDyn(x_p0, rds_p1, _) => crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XPart(Rc::new(x_p0.clone()), i_p3.clone()), rds_p1.clone(), t_p4.clone()),
        other_p5 => crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XPart(Rc::new(whole_p2.clone()), i_p3.clone()), crate::lower::types::Holding::Owned, t_p4.clone()),
    }
}

/// ```prism
/// RowSuffix: fn Wx -> Text
/// ```
pub fn row_suffix_f(wx_p0: &crate::lower::node_::Wx) -> Text {
    let n_p1 = &crate::prelude::len(&wx_p0.rows_p) + &crate::prelude::len(&wx_p0.pending_p);
    if &n_p1 == &Nat::from(0u32) {
        Text::lit("")
    } else {
        Text::from(format!("{}", &n_p1))
    }
}

/// ```prism
/// GnTyNamed: fn Wx, Text -> OutTy
/// ```
pub fn gn_ty_named_f(wx_p0: &crate::lower::node_::Wx, n_p1: &Text) -> crate::lower::model::OutTy {
    crate::prelude::fold(&wx_p0.gns_p, &crate::lower::model::OutTy::OutUnit, &(|acc_p2: &crate::lower::model::OutTy, g_p3: &crate::lower::node_::Gn| if &g_p3.name_p == n_p1 { g_p3.ty_p.clone() } else { acc_p2.clone() }))
}
