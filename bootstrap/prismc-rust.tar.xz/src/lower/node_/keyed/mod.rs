//! The module `Lower.Node.Keyed`, from `target/bootstrap/src/prismc/lower/node/keyed.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// `RowLocal`:
///
/// ```prism
/// type RowLocal = record:
/// ```
#[derive(Clone)]
pub struct RowLocal {
    pub name: Text,
    pub field: Text,
    pub ty: crate::lower::model::OutTy,
    pub passed: crate::lower::model::Ex,
}

impl ToPod for RowLocal {
    fn to_pod(&self) -> Pod {
        Pod::record("RowLocal", vec![("name", self.name.to_pod()), ("field", self.field.to_pod()), ("ty", self.ty.to_pod()), ("passed", self.passed.to_pod())])
    }
}

impl FromPod for RowLocal {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(RowLocal { name: FromPod::from_pod(field(p, "name")?)?, field: FromPod::from_pod(field(p, "field")?)?, ty: FromPod::from_pod(field(p, "ty")?)?, passed: FromPod::from_pod(field(p, "passed")?)? })
    }
}

/// ```prism
/// ForLine: unbounded fn Wx, Env, Env, ?ForBinders, Expr, Block, Expr, ?Bn -> ((Wx, Wres))
/// ```
pub fn for_line(wx: &crate::lower::node_::Wx, benv: &crate::lower::types::Env, menv: &crate::lower::types::Env, binders_opt: &Option<crate::syntax::ForBinders>, source: &crate::syntax::Expr, body: &crate::syntax::Block, e: &crate::syntax::Expr, bound_opt: &Option<crate::lower::types::Bn>) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    let lx = wx.lx.clone();
    let pos = wx.pos.clone();
    let wx1 = {
        let mut this: crate::lower::node_::Wx = wx.clone();
        this.pos = crate::lower::model::next_pos(&this.pos);
        this
    };
    let (src_ex, reads) = crate::lower::node_::dynamics::dynamic_expr(&wx1, menv, source);
    let src_ty = crate::lower::types::peel(&crate::lower::type_at(&lx, &source.span));
    let (kt, vt, keyed) = match &src_ty {
        crate::check::types::Ty::TyMap(k, v_) => (crate::lower::types::out_ty_of(&lx, &**k), crate::lower::types::out_ty_of(&lx, &**v_), true),
        crate::check::types::Ty::TyArray(v_) => (crate::lower::model::OutTy::OutNat, crate::lower::types::out_ty_of(&lx, &**v_), false),
        _ => (crate::lower::model::OutTy::OutUnit, crate::lower::model::OutTy::OutUnit, true),
    };
    let src = if keyed {
        src_ex.clone()
    } else {
        crate::lower::model::Ex::XCall(Text::lit("indexed"), Array::from(vec![crate::lower::model::Ex::XRef(Rc::new(src_ex.clone()))]))
    };
    let base = match bound_opt {
        Some(crate::lower::types::Bn::BnEv(er, _)) => crate::lower::node_::gn_of(&wx1, &er.node_).name.clone(),
        _ => Text::lit("rows"),
    };
    let (name, wx2a) = crate::lower::node_::fresh_name(&wx1, &base);
    let src_getter = Text::from(format!("{}_source", &name));
    let src_cached = crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_cache", &src_getter)))), Text::lit("get"), Array::from(vec![crate::lower::model::Ex::XCx, crate::lower::model::Ex::XClosure(false, Array::new(), Rc::new(src.clone()))]));
    let src_def = crate::lower::model::MethDef { name: src_getter.clone(), recv: crate::lower::model::Recv::RecvRef, params: Array::new(), cx_: crate::lower::model::CxArg::CxRef, ret: crate::lower::model::OutTy::OutMap(Rc::new(kt.clone()), Rc::new(vt.clone())), body: Array::new(), tail: src_cached.clone(), doc: Text::from(format!("The source of the `for` at place {} by key, at the read point: what its builder and its rows\' entries read, computed once per write behind it.", &crate::lower::model::place_text(&pos))) };
    let row_name = Text::from(format!("{}{}Row", &wx.node_, &row_suffix(wx)));
    let locals = row_locals(benv, menv, body);
    let row_fields = append(&Array::from(vec![(Text::lit("key"), kt.clone(), Text::lit("the row\'s key")), (Text::lit("left_entry"), crate::lower::model::OutTy::OutCell(Rc::new(crate::lower::model::OutTy::OutOpt(Rc::new(vt.clone())))), Text::lit("the entry as the tick its key left opened, kept from the row\'s leaving on (R8)")), (Text::lit("parent"), crate::lower::model::OutTy::OutWeak(wx.node_.clone()), Text::lit("the node of the `for`"))]), &each(&locals, &(|l: &RowLocal| (l.field.clone(), l.ty.clone(), Text::from(format!("`{}`, the block\'s", &l.name))))));
    let row_moves = append(&Array::from(vec![(Text::lit("key"), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(Text::lit("key"))))), (Text::lit("left_entry"), crate::lower::model::Ex::XCall(Text::lit("RefCell::new"), Array::from(vec![crate::lower::model::Ex::XNone]))), (Text::lit("parent"), crate::lower::model::Ex::XVar(Text::lit("parent")))]), &each(&locals, &(|l: &RowLocal| (l.field.clone(), crate::lower::model::Ex::XVar(l.field.clone())))));
    let row_taken = append(&append(&crate::lower::node_::node_hooks(), &Array::from(vec![Text::lit("key"), Text::lit("value"), Text::lit("parent"), Text::lit("entry"), Text::lit("left_entry")])), &each(&locals, &(|l: &RowLocal| l.field.clone())));
    let row_wx0 = crate::lower::node_::new_wx(&lx, &row_name, &row_fields, &Array::new(), &row_moves, &Array::from(vec![entry_getter(&src_getter, &vt)]), &map_of(vec![(Text::lit("entry"), Array::from(vec![crate::lower::node_::Read::ParentRead(src_getter.clone())]))]), &row_taken, &wx.depth, &crate::lower::node_::finish::hosted_rows(wx));
    let (wx2p, row_wx0p, ports) = crate::lower::node_::switch_::row_env(&wx2a, &row_wx0, menv, body);
    let wx2 = {
        let mut this: crate::lower::node_::Wx = crate::lower::node_::add_field(&wx2p, &Text::from(format!("{}_cache", &src_getter)), &crate::lower::model::OutTy::OutNamed(Text::lit("Cache"), Array::from(vec![crate::lower::model::OutTy::OutMap(Rc::new(kt.clone()), Rc::new(vt.clone()))])), &Text::from(format!("the source of the `for` at place {}, cached (gap SR)", &crate::lower::model::place_text(&pos))), &crate::lower::model::Ex::XCall(Text::lit("Cache::new"), Array::new()));
        this.taken = append(&this.taken, &Array::from(vec![src_getter.clone(), Text::from(format!("{}_cache", &src_getter))]));
        this.getters = push(&this.getters, &src_def);
        this.dyn_reads = insert(&this.dyn_reads, &src_getter, &reads);
        this
    };
    let key_b = crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(Text::lit("key")), crate::lower::types::Holding::Owned, kt.clone());
    let key_m = crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::lit("key")), crate::lower::types::Holding::Owned, kt.clone());
    let benv_l = events_of(&ports, &fold(&locals, &row_reads(benv, &crate::lower::node_::switch_::parent_arg()), &(|en: &crate::lower::types::Env, l: &RowLocal| crate::lower::types::bind(en, &l.name, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(l.field.clone()), crate::lower::types::Holding::Owned, l.ty.clone())))));
    let menv_l = events_of(&ports, &fold(&locals, &row_reads(menv, &crate::lower::node_::switch_::parent_ref()), &(|en: &crate::lower::types::Env, l: &RowLocal| crate::lower::types::bind(en, &l.name, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), l.field.clone()), crate::lower::types::Holding::Owned, l.ty.clone())))));
    let passed = append(&hosted_passed(wx), &each(&locals, &(|l: &RowLocal| l.passed.clone())));
    let row_params = append(&append(&Array::from(vec![(Text::lit("key"), kt.clone()), (Text::lit("value"), vt.clone()), (Text::lit("parent"), crate::lower::model::OutTy::OutWeak(wx.node_.clone()))]), &hosted_params(wx)), &each(&locals, &(|l: &RowLocal| (l.field.clone(), l.ty.clone()))));
    let entry_m = crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XSelf), Text::lit("entry"), Array::from(vec![crate::lower::model::Ex::XCx])), Array::from(vec![crate::lower::node_::Read::ParentRead(src_getter.clone())]), vt.clone());
    let (rbe, rme) = for_envs(&benv_l, &menv_l, binders_opt, &key_b, &key_m, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(Text::lit("value")), crate::lower::types::Holding::Owned, vt.clone()), &entry_m, &vt);
    let row_wx = crate::lower::node_::def::block_into(&row_wx0p, &rbe, &rme, body);
    let wx3 = {
        let mut this: crate::lower::node_::Wx = wx2.clone();
        this.row_marks = push(&this.row_marks, &crate::lower::node_::RowMarks { builder: name.clone(), reads: row_place_reads(&row_wx), wrote: crate::lower::node_::finish::row_hears(&row_wx), kind: crate::lower::model::RowKind::ForRow });
        this
    };
    let full = crate::lower::type_at(&lx, &e.span);
    let out_ty = crate::lower::types::out_ty_of(&lx, &crate::lower::types::peel(&full));
    match &row_wx.result {
        crate::lower::node_::Wres::WrEv(r) => {
            let (gid, wx4) = crate::lower::node_::add_gn(&wx3, &Text::from(format!("{}_all", &name)), &out_ty, &crate::lower::node_::GnKind::GnGather, &Nat::from(1u32));
            let wx5 = crate::lower::node_::add_field_last(&wx4, &Text::from(format!("{}_gathered", &name)), &crate::lower::model::OutTy::OutStamped(Rc::new(out_ty.clone())), &Text::lit("the rows\' firings this tick, by key"), &crate::lower::model::Ex::XCall(Text::lit("Stamped::new"), Array::new()));
            let wx6 = {
                let mut this: crate::lower::node_::Wx = wx5.clone();
                this.gns = each(&this.gns, &(|n: &crate::lower::node_::Gn| if &n.id == &gid {
                    crate::lower::node_::dynamics::with_inputs(n, &Array::from(vec![Text::from(format!("{}_gathered", &name))]))
                } else {
                    n.clone()
                }));
                this
            };
            let row_done = crate::lower::node_::connect(&row_wx, r, &crate::lower::node_::Sk::SkUp(Text::from(format!("{}_all_in", &name))));
            let wx7 = add_builder(&wx6, &name, &pos, &kt, &vt, &row_name, &keyed, &reads, &crate::lower::node_::PendingRow { wx: row_done.clone(), qk: row_name.clone(), params: row_params.clone(), gather: Some(gid.clone()) }, &passed);
            (wx7.clone(), crate::lower::node_::Wres::WrEv(crate::lower::node_::ev_ref_of(&wx7, &gid)))
        },
        crate::lower::node_::Wres::WrDyn(ex, result_reads, rt) => {
            let gathered = Text::from(format!("{}_all", &name));
            let gathered_ty = crate::lower::model::OutTy::OutMap(Rc::new(kt.clone()), Rc::new(rt.clone()));
            let own_behind = filter(&crate::lower::node_::finish::reads_closed(&row_wx.dyn_reads, result_reads), &(|r: &crate::lower::node_::Read| match r {
                crate::lower::node_::Read::OwnRead(_) => true,
                crate::lower::node_::Read::ParentRead(_) => false,
            }));
            let row_done = {
                let mut this: crate::lower::node_::Wx = row_wx.clone();
                this.getters = push(&this.getters, &crate::lower::model::MethDef { name: Text::lit("result"), recv: crate::lower::model::Recv::RecvRef, params: Array::new(), cx_: crate::lower::model::CxArg::CxRef, ret: rt.clone(), body: Array::new(), tail: ex.clone(), doc: Text::lit("The row\'s result, which the block gathers by key.") });
                this.result_moved = if &len(&own_behind) > &Nat::from(0u32) {
                    Some((Text::from(format!("{}_moved", &gathered)), own_behind.clone()))
                } else {
                    None
                };
                this
            };
            let wx4 = add_builder(&wx3, &name, &pos, &kt, &vt, &row_name, &keyed, &reads, &crate::lower::node_::PendingRow { wx: row_done.clone(), qk: row_name.clone(), params: row_params.clone(), gather: None }, &passed);
            let all = crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), name.clone())), Text::lit("borrow"), Array::new())), Text::lit("iter"), Array::new())), Text::lit("map"), Array::from(vec![crate::lower::model::Ex::XClosure(false, Array::from(vec![crate::lower::model::Pa::PaTuple(Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("k")), crate::lower::model::Pa::PaBind(Text::lit("row"))]))]), Rc::new(crate::lower::model::Ex::XTuple(Array::from(vec![crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(Text::lit("k")))), crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("row"))), Text::lit("result"), Array::from(vec![crate::lower::model::Ex::XCx]))]))))]))), Text::lit("collect"), Array::new());
            let what = Text::from(format!("the dynamic gathered by the `for` at place {}", &crate::lower::model::place_text(&pos)));
            let wx5 = {
                let mut this: crate::lower::node_::Wx = wx4.clone();
                this.taken = append(&this.taken, &Array::from(vec![gathered.clone(), Text::from(format!("{}_now", &gathered)), Text::from(format!("{}_snap", &gathered)), Text::from(format!("{}_moved", &gathered)), Text::from(format!("{}_publish", &gathered))]));
                this.getters = append(&this.getters, &Array::from(vec![crate::lower::model::MethDef { name: Text::from(format!("{}_now", &gathered)), recv: crate::lower::model::Recv::RecvRef, params: Array::new(), cx_: crate::lower::model::CxArg::CxRef, ret: gathered_ty.clone(), body: Array::new(), tail: all.clone(), doc: Text::lit("The rows\' results by key, computed live: what the snapshot of the `for`\'s dynamic is taken from (pick ST).") }, crate::lower::node_::static_::snap_getter(&gathered, &gathered_ty, &Text::lit("The `for`\'s dynamic, the rows\' results by key, a structural dynamic (pick ST): one tick behind the rows, the snapshot of the tick before the tick the read point is after."))]));
                this.fields = push(&this.fields, &(Text::from(format!("{}_snap", &gathered)), crate::lower::model::OutTy::OutSnapshot(Rc::new(gathered_ty.clone())), Text::from(format!("the `for` at place {}\'s gathered dynamic, structural: its snapshots, the rows\' results and the lagged dynamic (pick ST)", &crate::lower::model::place_text(&pos)))));
                this.inits = push(&this.inits, &(Text::from(format!("{}_snap", &gathered)), crate::lower::model::Ex::XCall(Text::lit("Snapshot::new"), Array::from(vec![crate::lower::model::Ex::XStr(what.clone())]))));
                this.snaps = push(&this.snaps, &crate::lower::node_::SnapDef { name: gathered.clone(), live: Text::from(format!("{}_now", &gathered)), ty: gathered_ty.clone(), eq: crate::lower::program::ty_has_eq(&lx, &crate::lower::types::peel(&full), &Array::new()), builder: name.clone(), before: false, what: what.clone() });
                this.dyn_reads = insert(&this.dyn_reads, &Text::from(format!("{}_now", &gathered)), &crate::lower::node_::union_reads(&reads, &block_reads(&crate::lower::node_::finish::reads_closed(&row_wx.dyn_reads, result_reads))));
                this
            };
            (wx5.clone(), crate::lower::node_::Wres::WrDyn(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XSelf), gathered.clone(), Array::from(vec![crate::lower::model::Ex::XCx])), Array::from(vec![crate::lower::node_::Read::OwnRead(gathered.clone())]), gathered_ty.clone()))
        },
        _ => {
            let wx4 = add_builder(&wx3, &name, &pos, &kt, &vt, &row_name, &keyed, &reads, &crate::lower::node_::PendingRow { wx: row_wx.clone(), qk: row_name.clone(), params: row_params.clone(), gather: None }, &passed);
            (wx4.clone(), crate::lower::node_::Wres::WrUnit)
        },
    }
}

/// The step machine of `ForLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ForLine: unbounded fn Wx, Env, Env, ?ForBinders, Expr, Block, Expr, ?Bn -> ((Wx, Wres))
/// ```
pub struct ForLine {
    pub wx: crate::lower::node_::Wx,
    pub benv: crate::lower::types::Env,
    pub menv: crate::lower::types::Env,
    pub binders_opt: Option<crate::syntax::ForBinders>,
    pub source: crate::syntax::Expr,
    pub body: crate::syntax::Block,
    pub e: crate::syntax::Expr,
    pub bound_opt: Option<crate::lower::types::Bn>,
}

impl prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::node_::Wres)> for ForLine {
    fn cycle(&self) -> prism_rtl::Turn<(crate::lower::node_::Wx, crate::lower::node_::Wres)> {
        let wx = &self.wx;
        let benv = &self.benv;
        let menv = &self.menv;
        let binders_opt = &self.binders_opt;
        let source = &self.source;
        let body = &self.body;
        let e = &self.e;
        let bound_opt = &self.bound_opt;
        let lx = wx.lx.clone();
        let pos = wx.pos.clone();
        let wx1 = {
            let mut this: crate::lower::node_::Wx = wx.clone();
            this.pos = crate::lower::model::next_pos(&this.pos);
            this
        };
        let binders_opt = binders_opt.clone();
        let bound_opt = bound_opt.clone();
        let benv = benv.clone();
        let body = body.clone();
        let e = e.clone();
        let menv = menv.clone();
        let source = source.clone();
        let wx = wx.clone();
        call_then(crate::lower::node_::dynamics::start_dynamic_expr(wx1.clone(), menv.clone(), source.clone()), move |dynamic_expr_1801: (crate::lower::model::Ex, Array<crate::lower::node_::Read>)| {
            let (src_ex, reads) = dynamic_expr_1801;
            let src_ty = crate::lower::types::peel(&crate::lower::type_at(&lx, &source.span));
            let (kt, vt, keyed) = match &src_ty {
                crate::check::types::Ty::TyMap(k, v_) => (crate::lower::types::out_ty_of(&lx, &**k), crate::lower::types::out_ty_of(&lx, &**v_), true),
                crate::check::types::Ty::TyArray(v_) => (crate::lower::model::OutTy::OutNat, crate::lower::types::out_ty_of(&lx, &**v_), false),
                _ => (crate::lower::model::OutTy::OutUnit, crate::lower::model::OutTy::OutUnit, true),
            };
            let src = if keyed {
                src_ex.clone()
            } else {
                crate::lower::model::Ex::XCall(Text::lit("indexed"), Array::from(vec![crate::lower::model::Ex::XRef(Rc::new(src_ex.clone()))]))
            };
            let base = match &bound_opt {
                Some(crate::lower::types::Bn::BnEv(er, _)) => crate::lower::node_::gn_of(&wx1, &er.node_).name.clone(),
                _ => Text::lit("rows"),
            };
            let (name, wx2a) = crate::lower::node_::fresh_name(&wx1, &base);
            let src_getter = Text::from(format!("{}_source", &name));
            let src_cached = crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_cache", &src_getter)))), Text::lit("get"), Array::from(vec![crate::lower::model::Ex::XCx, crate::lower::model::Ex::XClosure(false, Array::new(), Rc::new(src.clone()))]));
            let src_def = crate::lower::model::MethDef { name: src_getter.clone(), recv: crate::lower::model::Recv::RecvRef, params: Array::new(), cx_: crate::lower::model::CxArg::CxRef, ret: crate::lower::model::OutTy::OutMap(Rc::new(kt.clone()), Rc::new(vt.clone())), body: Array::new(), tail: src_cached.clone(), doc: Text::from(format!("The source of the `for` at place {} by key, at the read point: what its builder and its rows\' entries read, computed once per write behind it.", &crate::lower::model::place_text(&pos))) };
            let row_name = Text::from(format!("{}{}Row", &wx.node_, &row_suffix(&wx)));
            let locals = row_locals(&benv, &menv, &body);
            let row_fields = append(&Array::from(vec![(Text::lit("key"), kt.clone(), Text::lit("the row\'s key")), (Text::lit("left_entry"), crate::lower::model::OutTy::OutCell(Rc::new(crate::lower::model::OutTy::OutOpt(Rc::new(vt.clone())))), Text::lit("the entry as the tick its key left opened, kept from the row\'s leaving on (R8)")), (Text::lit("parent"), crate::lower::model::OutTy::OutWeak(wx.node_.clone()), Text::lit("the node of the `for`"))]), &each(&locals, &(|l: &RowLocal| (l.field.clone(), l.ty.clone(), Text::from(format!("`{}`, the block\'s", &l.name))))));
            let row_moves = append(&Array::from(vec![(Text::lit("key"), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(Text::lit("key"))))), (Text::lit("left_entry"), crate::lower::model::Ex::XCall(Text::lit("RefCell::new"), Array::from(vec![crate::lower::model::Ex::XNone]))), (Text::lit("parent"), crate::lower::model::Ex::XVar(Text::lit("parent")))]), &each(&locals, &(|l: &RowLocal| (l.field.clone(), crate::lower::model::Ex::XVar(l.field.clone())))));
            let row_taken = append(&append(&crate::lower::node_::node_hooks(), &Array::from(vec![Text::lit("key"), Text::lit("value"), Text::lit("parent"), Text::lit("entry"), Text::lit("left_entry")])), &each(&locals, &(|l: &RowLocal| l.field.clone())));
            let row_wx0 = crate::lower::node_::new_wx(&lx, &row_name, &row_fields, &Array::new(), &row_moves, &Array::from(vec![entry_getter(&src_getter, &vt)]), &map_of(vec![(Text::lit("entry"), Array::from(vec![crate::lower::node_::Read::ParentRead(src_getter.clone())]))]), &row_taken, &wx.depth, &crate::lower::node_::finish::hosted_rows(&wx));
            let (wx2p, row_wx0p, ports) = crate::lower::node_::switch_::row_env(&wx2a, &row_wx0, &menv, &body);
            let wx2 = {
                let mut this: crate::lower::node_::Wx = crate::lower::node_::add_field(&wx2p, &Text::from(format!("{}_cache", &src_getter)), &crate::lower::model::OutTy::OutNamed(Text::lit("Cache"), Array::from(vec![crate::lower::model::OutTy::OutMap(Rc::new(kt.clone()), Rc::new(vt.clone()))])), &Text::from(format!("the source of the `for` at place {}, cached (gap SR)", &crate::lower::model::place_text(&pos))), &crate::lower::model::Ex::XCall(Text::lit("Cache::new"), Array::new()));
                this.taken = append(&this.taken, &Array::from(vec![src_getter.clone(), Text::from(format!("{}_cache", &src_getter))]));
                this.getters = push(&this.getters, &src_def);
                this.dyn_reads = insert(&this.dyn_reads, &src_getter, &reads);
                this
            };
            let key_b = crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(Text::lit("key")), crate::lower::types::Holding::Owned, kt.clone());
            let key_m = crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::lit("key")), crate::lower::types::Holding::Owned, kt.clone());
            let benv_l = events_of(&ports, &fold(&locals, &row_reads(&benv, &crate::lower::node_::switch_::parent_arg()), &(|en: &crate::lower::types::Env, l: &RowLocal| crate::lower::types::bind(en, &l.name, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(l.field.clone()), crate::lower::types::Holding::Owned, l.ty.clone())))));
            let menv_l = events_of(&ports, &fold(&locals, &row_reads(&menv, &crate::lower::node_::switch_::parent_ref()), &(|en: &crate::lower::types::Env, l: &RowLocal| crate::lower::types::bind(en, &l.name, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), l.field.clone()), crate::lower::types::Holding::Owned, l.ty.clone())))));
            let passed = append(&hosted_passed(&wx), &each(&locals, &(|l: &RowLocal| l.passed.clone())));
            let row_params = append(&append(&Array::from(vec![(Text::lit("key"), kt.clone()), (Text::lit("value"), vt.clone()), (Text::lit("parent"), crate::lower::model::OutTy::OutWeak(wx.node_.clone()))]), &hosted_params(&wx)), &each(&locals, &(|l: &RowLocal| (l.field.clone(), l.ty.clone()))));
            let entry_m = crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XSelf), Text::lit("entry"), Array::from(vec![crate::lower::model::Ex::XCx])), Array::from(vec![crate::lower::node_::Read::ParentRead(src_getter.clone())]), vt.clone());
            let (rbe, rme) = for_envs(&benv_l, &menv_l, &binders_opt, &key_b, &key_m, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(Text::lit("value")), crate::lower::types::Holding::Owned, vt.clone()), &entry_m, &vt);
            call_then(crate::lower::node_::def::start_block_into(row_wx0p.clone(), rbe.clone(), rme.clone(), body.clone()), move |block_into_5610: crate::lower::node_::Wx| {
                let row_wx = block_into_5610;
                let wx3 = {
                    let mut this: crate::lower::node_::Wx = wx2.clone();
                    this.row_marks = push(&this.row_marks, &crate::lower::node_::RowMarks { builder: name.clone(), reads: row_place_reads(&row_wx), wrote: crate::lower::node_::finish::row_hears(&row_wx), kind: crate::lower::model::RowKind::ForRow });
                    this
                };
                let full = crate::lower::type_at(&lx, &e.span);
                call_then(crate::lower::types::start_out_ty_of(lx.clone(), crate::lower::types::peel(&full)), move |out_ty_of_5849: crate::lower::model::OutTy| {
                    let out_ty = out_ty_of_5849;
                    match &row_wx.result {
                        crate::lower::node_::Wres::WrEv(r) => {
                            let (gid, wx4) = crate::lower::node_::add_gn(&wx3, &Text::from(format!("{}_all", &name)), &out_ty, &crate::lower::node_::GnKind::GnGather, &Nat::from(1u32));
                            let wx5 = crate::lower::node_::add_field_last(&wx4, &Text::from(format!("{}_gathered", &name)), &crate::lower::model::OutTy::OutStamped(Rc::new(out_ty.clone())), &Text::lit("the rows\' firings this tick, by key"), &crate::lower::model::Ex::XCall(Text::lit("Stamped::new"), Array::new()));
                            let wx6 = {
                                let mut this: crate::lower::node_::Wx = wx5.clone();
                                this.gns = each(&this.gns, &(|n: &crate::lower::node_::Gn| if &n.id == &gid {
                                    crate::lower::node_::dynamics::with_inputs(n, &Array::from(vec![Text::from(format!("{}_gathered", &name))]))
                                } else {
                                    n.clone()
                                }));
                                this
                            };
                            let row_done = crate::lower::node_::connect(&row_wx, r, &crate::lower::node_::Sk::SkUp(Text::from(format!("{}_all_in", &name))));
                            let wx7 = add_builder(&wx6, &name, &pos, &kt, &vt, &row_name, &keyed, &reads, &crate::lower::node_::PendingRow { wx: row_done.clone(), qk: row_name.clone(), params: row_params.clone(), gather: Some(gid.clone()) }, &passed);
                            prism_rtl::Turn::Finished((wx7.clone(), crate::lower::node_::Wres::WrEv(crate::lower::node_::ev_ref_of(&wx7, &gid))))
                        },
                        crate::lower::node_::Wres::WrDyn(ex, result_reads, rt) => {
                            let gathered = Text::from(format!("{}_all", &name));
                            let gathered_ty = crate::lower::model::OutTy::OutMap(Rc::new(kt.clone()), Rc::new(rt.clone()));
                            let own_behind = filter(&crate::lower::node_::finish::reads_closed(&row_wx.dyn_reads, result_reads), &(|r: &crate::lower::node_::Read| match r {
                                crate::lower::node_::Read::OwnRead(_) => true,
                                crate::lower::node_::Read::ParentRead(_) => false,
                            }));
                            let row_done = {
                                let mut this: crate::lower::node_::Wx = row_wx.clone();
                                this.getters = push(&this.getters, &crate::lower::model::MethDef { name: Text::lit("result"), recv: crate::lower::model::Recv::RecvRef, params: Array::new(), cx_: crate::lower::model::CxArg::CxRef, ret: rt.clone(), body: Array::new(), tail: ex.clone(), doc: Text::lit("The row\'s result, which the block gathers by key.") });
                                this.result_moved = if &len(&own_behind) > &Nat::from(0u32) {
                                    Some((Text::from(format!("{}_moved", &gathered)), own_behind.clone()))
                                } else {
                                    None
                                };
                                this
                            };
                            let wx4 = add_builder(&wx3, &name, &pos, &kt, &vt, &row_name, &keyed, &reads, &crate::lower::node_::PendingRow { wx: row_done.clone(), qk: row_name.clone(), params: row_params.clone(), gather: None }, &passed);
                            let all = crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), name.clone())), Text::lit("borrow"), Array::new())), Text::lit("iter"), Array::new())), Text::lit("map"), Array::from(vec![crate::lower::model::Ex::XClosure(false, Array::from(vec![crate::lower::model::Pa::PaTuple(Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("k")), crate::lower::model::Pa::PaBind(Text::lit("row"))]))]), Rc::new(crate::lower::model::Ex::XTuple(Array::from(vec![crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(Text::lit("k")))), crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("row"))), Text::lit("result"), Array::from(vec![crate::lower::model::Ex::XCx]))]))))]))), Text::lit("collect"), Array::new());
                            let what = Text::from(format!("the dynamic gathered by the `for` at place {}", &crate::lower::model::place_text(&pos)));
                            let wx5 = {
                                let mut this: crate::lower::node_::Wx = wx4.clone();
                                this.taken = append(&this.taken, &Array::from(vec![gathered.clone(), Text::from(format!("{}_now", &gathered)), Text::from(format!("{}_snap", &gathered)), Text::from(format!("{}_moved", &gathered)), Text::from(format!("{}_publish", &gathered))]));
                                this.getters = append(&this.getters, &Array::from(vec![crate::lower::model::MethDef { name: Text::from(format!("{}_now", &gathered)), recv: crate::lower::model::Recv::RecvRef, params: Array::new(), cx_: crate::lower::model::CxArg::CxRef, ret: gathered_ty.clone(), body: Array::new(), tail: all.clone(), doc: Text::lit("The rows\' results by key, computed live: what the snapshot of the `for`\'s dynamic is taken from (pick ST).") }, crate::lower::node_::static_::snap_getter(&gathered, &gathered_ty, &Text::lit("The `for`\'s dynamic, the rows\' results by key, a structural dynamic (pick ST): one tick behind the rows, the snapshot of the tick before the tick the read point is after."))]));
                                this.fields = push(&this.fields, &(Text::from(format!("{}_snap", &gathered)), crate::lower::model::OutTy::OutSnapshot(Rc::new(gathered_ty.clone())), Text::from(format!("the `for` at place {}\'s gathered dynamic, structural: its snapshots, the rows\' results and the lagged dynamic (pick ST)", &crate::lower::model::place_text(&pos)))));
                                this.inits = push(&this.inits, &(Text::from(format!("{}_snap", &gathered)), crate::lower::model::Ex::XCall(Text::lit("Snapshot::new"), Array::from(vec![crate::lower::model::Ex::XStr(what.clone())]))));
                                this.snaps = push(&this.snaps, &crate::lower::node_::SnapDef { name: gathered.clone(), live: Text::from(format!("{}_now", &gathered)), ty: gathered_ty.clone(), eq: crate::lower::program::ty_has_eq(&lx, &crate::lower::types::peel(&full), &Array::new()), builder: name.clone(), before: false, what: what.clone() });
                                this.dyn_reads = insert(&this.dyn_reads, &Text::from(format!("{}_now", &gathered)), &crate::lower::node_::union_reads(&reads, &block_reads(&crate::lower::node_::finish::reads_closed(&row_wx.dyn_reads, result_reads))));
                                this
                            };
                            prism_rtl::Turn::Finished((wx5.clone(), crate::lower::node_::Wres::WrDyn(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XSelf), gathered.clone(), Array::from(vec![crate::lower::model::Ex::XCx])), Array::from(vec![crate::lower::node_::Read::OwnRead(gathered.clone())]), gathered_ty.clone())))
                        },
                        _ => {
                            let wx4 = add_builder(&wx3, &name, &pos, &kt, &vt, &row_name, &keyed, &reads, &crate::lower::node_::PendingRow { wx: row_wx.clone(), qk: row_name.clone(), params: row_params.clone(), gather: None }, &passed);
                            prism_rtl::Turn::Finished((wx4.clone(), crate::lower::node_::Wres::WrUnit))
                        },
                    }
                })
            })
        })
    }
}

/// `Start ForLine, x`: what the function value is when passed to `@Run`.
pub fn start_for_line(wx: crate::lower::node_::Wx, benv: crate::lower::types::Env, menv: crate::lower::types::Env, binders_opt: Option<crate::syntax::ForBinders>, source: crate::syntax::Expr, body: crate::syntax::Block, e: crate::syntax::Expr, bound_opt: Option<crate::lower::types::Bn>) -> Rc<dyn prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::node_::Wres)>> {
    Rc::new(ForLine { wx, benv, menv, binders_opt, source, body, e, bound_opt })
}

/// ```prism
/// EntryGetter: fn Text, OutTy -> MethDef
/// ```
pub fn entry_getter(src_getter: &Text, vt: &crate::lower::model::OutTy) -> crate::lower::model::MethDef {
    let found = crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("parent"))), src_getter.clone(), Array::from(vec![crate::lower::model::Ex::XCx]))), Text::lit("get"), Array::from(vec![crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::lit("key"))))]))), Text::lit("cloned"), Array::new());
    let opened = crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCx), Text::lit("before"), Array::from(vec![crate::lower::model::Ex::XClosure(false, Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("cx"))]), Rc::new(found.clone()))]))), Text::lit("expect"), Array::from(vec![crate::lower::model::Ex::XStr(Text::lit("a row\'s key is in its source as its tick opened"))]));
    let body = Array::from(vec![crate::lower::model::Do::DoIfLet(crate::lower::model::Pa::PaCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("v"))])), crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::lit("left_entry"))), Text::lit("borrow"), Array::new())), Text::lit("as_ref"), Array::new()), Array::from(vec![crate::lower::model::Do::DoReturn(crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(Text::lit("v")))))]), Array::new()), crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(Text::lit("parent")), crate::lower::node_::switch_::parent_ref())]);
    let tail = crate::lower::model::Ex::XMatch(Rc::new(found.clone()), Array::from(vec![crate::lower::model::XArm { pat: crate::lower::model::Pa::PaCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("v"))])), conds: Array::new(), body: crate::lower::model::Ex::XVar(Text::lit("v")) }, crate::lower::model::XArm { pat: crate::lower::model::Pa::PaUnit(Text::lit("None")), conds: Array::new(), body: opened.clone() }]), false, vt.clone());
    crate::lower::model::MethDef { name: Text::lit("entry"), recv: crate::lower::model::Recv::RecvRef, params: Array::new(), cx_: crate::lower::model::CxArg::CxRef, ret: vt.clone(), body: body.clone(), tail: tail.clone(), doc: Text::lit("The row\'s entry, `$_`: the block\'s source at this key, at the read point; from the row\'s leaving on, the value as the leaving tick opened.") }
}

/// ```prism
/// AddBuilder: fn Wx, Text, Pos, OutTy, OutTy, Text, Bool, [Read], PendingRow, [Ex] -> Wx
/// ```
pub fn add_builder(wx: &crate::lower::node_::Wx, name: &Text, pos: &crate::lower::model::Pos_, kt: &crate::lower::model::OutTy, vt: &crate::lower::model::OutTy, row_name: &Text, keyed: &bool, reads: &Array<crate::lower::node_::Read>, waiting: &crate::lower::node_::PendingRow, passed: &Array<crate::lower::model::Ex>) -> crate::lower::node_::Wx {
    let wx0 = crate::lower::node_::add_field_last(wx, name, &crate::lower::model::OutTy::OutCell(Rc::new(crate::lower::model::OutTy::OutMap(Rc::new(kt.clone()), Rc::new(crate::lower::model::OutTy::OutRc(Rc::new(crate::lower::model::OutTy::OutNamed(row_name.clone(), Array::new()))))))), &Text::from(format!("the rows of the `for` at place {}", &crate::lower::model::place_text(pos))), &crate::lower::model::Ex::XCall(Text::lit("RefCell::new"), Array::from(vec![crate::lower::model::Ex::XCall(Text::lit("Map::new"), Array::new())])));
    let wx1 = crate::lower::node_::add_field_last(&wx0, &Text::from(format!("{}_from", name)), &crate::lower::model::OutTy::OutCell(Rc::new(crate::lower::model::OutTy::OutMap(Rc::new(kt.clone()), Rc::new(vt.clone())))), &Text::from(format!("the source the rows of the `for` at place {} were last built from", &crate::lower::model::place_text(pos))), &crate::lower::model::Ex::XCall(Text::lit("RefCell::new"), Array::from(vec![crate::lower::model::Ex::XCall(Text::lit("Map::new"), Array::new())])));
    let mut this: crate::lower::node_::Wx = wx1.clone();
    this.builders = push(&this.builders, &crate::lower::model::ForDef { name: name.clone(), pos: pos.clone(), at: crate::lower::node_::finish::place_at(wx, &Text::lit("self"), pos), key_ty: kt.clone(), value_ty: vt.clone(), row_node: row_name.clone(), keyed: *keyed, source: Text::from(format!("{}_source", name)), parent: crate::lower::model::Ex::XWeak(Rc::new(crate::lower::model::Ex::XSelf)), passed: passed.clone(), moved: or(&crate::lower::node_::finish::hosted_rows(wx), &Text::lit("")) });
    this.build_holds = crate::lower::node_::union_reads(&this.build_holds, reads);
    this.pending = push(&this.pending, waiting);
    this
}

/// ```prism
/// RowPlaceReads: fn Wx -> [Read]
/// ```
pub fn row_place_reads(row_wx: &crate::lower::node_::Wx) -> Array<crate::lower::node_::Read> {
    let flats = fold(&filter(&row_wx.flattens, &(|fl: &crate::lower::node_::FlatDef| &fl.generation == &Text::lit(""))), &Array::new(), &(|acc: &Array<crate::lower::node_::Read>, fl: &crate::lower::node_::FlatDef| crate::lower::node_::union_reads(acc, &block_reads(&crate::lower::node_::finish::reads_closed(&row_wx.dyn_reads, &Array::from(vec![crate::lower::node_::Read::OwnRead(fl.outer.clone())]))))));
    fold(&row_wx.places, &flats, &(|acc: &Array<crate::lower::node_::Read>, pl: &crate::lower::node_::Place| crate::lower::node_::union_reads(acc, &block_reads(&crate::lower::node_::finish::reads_closed(&row_wx.dyn_reads, &pl.reads)))))
}

/// ```prism
/// HostedParams: fn Wx -> [((Text, OutTy))]
/// ```
pub fn hosted_params(wx: &crate::lower::node_::Wx) -> Array<(Text, crate::lower::model::OutTy)> {
    match crate::lower::node_::finish::hosted_rows(wx) {
        Some(_) => Array::from(vec![(Text::lit("enclosing"), crate::lower::types::host_of_ty())]),
        None => Array::new(),
    }
}

/// ```prism
/// HostedPassed: fn Wx -> [Ex]
/// ```
pub fn hosted_passed(wx: &crate::lower::node_::Wx) -> Array<crate::lower::model::Ex> {
    match crate::lower::node_::finish::hosted_rows(wx) {
        Some(_) => Array::from(vec![crate::lower::model::Ex::XClone(Rc::new(crate::lower::node_::finish::host_field_ex(wx, &wx.pos)))]),
        None => Array::new(),
    }
}

/// ```prism
/// RowReads: fn Env, Ex -> Env
/// ```
pub fn row_reads(env: &crate::lower::types::Env, pref: &crate::lower::model::Ex) -> crate::lower::types::Env {
    fold(&keys(&env.names), env, &(|en: &crate::lower::types::Env, k: &Text| 'm13621: {
        let scrutinee = &get(&env.names, k);
        if let Some(crate::lower::types::Bn::BnHold(f, t)) = scrutinee {
            break 'm13621 crate::lower::types::bind(en, k, &crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(pref.clone()), f.clone())), Text::lit("get"), Array::from(vec![crate::lower::model::Ex::XCx])), Array::from(vec![crate::lower::node_::Read::ParentRead(f.clone())]), t.clone()));
        }
        if let Some(crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(m13621_1_0_0, m, xs), _, t)) = scrutinee && let crate::lower::model::Ex::XSelf = &**m13621_1_0_0 {
            break 'm13621 crate::lower::types::bind(en, k, &crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(Rc::new(pref.clone()), m.clone(), xs.clone()), Array::from(vec![crate::lower::node_::Read::ParentRead(m.clone())]), t.clone()));
        }
        en.clone()
    }))
}

/// ```prism
/// EventsOf: fn Env, Env -> Env
/// ```
pub fn events_of(ports: &crate::lower::types::Env, env: &crate::lower::types::Env) -> crate::lower::types::Env {
    fold(&keys(&ports.names), env, &(|en: &crate::lower::types::Env, k: &Text| match get(&ports.names, k) {
        Some(crate::lower::types::Bn::BnEv(er, t)) => crate::lower::types::bind(en, k, &crate::lower::types::Bn::BnEv(er, t)),
        _ => en.clone(),
    }))
}

/// ```prism
/// BlockReads: fn [Read] -> [Read]
/// ```
pub fn block_reads(reads: &Array<crate::lower::node_::Read>) -> Array<crate::lower::node_::Read> {
    fold(reads, &Array::new(), &(|acc: &Array<crate::lower::node_::Read>, r: &crate::lower::node_::Read| match r {
        crate::lower::node_::Read::ParentRead(f) => crate::lower::node_::add_read(acc, &crate::lower::node_::Read::OwnRead(f.clone())),
        crate::lower::node_::Read::OwnRead(_) => acc.clone(),
    }))
}

/// ```prism
/// RowLocals: unbounded fn Env, Env, Block -> [RowLocal]
/// ```
pub fn row_locals(benv: &crate::lower::types::Env, menv: &crate::lower::types::Env, body: &crate::syntax::Block) -> Array<RowLocal> {
    fold(&crate::lower::expr::read_names(&crate::check::typed::print::block_exprs(body)), &Array::new(), &(|acc: &Array<RowLocal>, n: &Text| match get(&menv.names, n) {
        Some(crate::lower::types::Bn::BnLocal(rs, mode, t)) => {
            let field_ = crate::lower::snake(n);
            if (((&field_ == &Text::lit("key")) || (&field_ == &Text::lit("value"))) || (&field_ == &Text::lit("parent"))) || (&field_ == &Text::lit("path")) {
                acc.clone()
            } else {
                push(acc, &RowLocal { name: n.clone(), field: field_.clone(), ty: t.clone(), passed: crate::lower::types::own(&crate::lower::types::Vl::VlPlace(rs, mode, t.clone())) })
            }
        },
        _ => acc.clone(),
    }))
}

/// ```prism
/// ForEnvs: unbounded fn Env, Env, ?ForBinders, Bn, Bn, Bn, Bn, OutTy -> ((Env, Env))
/// ```
pub fn for_envs(benv: &crate::lower::types::Env, menv: &crate::lower::types::Env, binders_opt: &Option<crate::syntax::ForBinders>, key_b: &crate::lower::types::Bn, key_m: &crate::lower::types::Bn, val_b: &crate::lower::types::Bn, val_m: &crate::lower::types::Bn, vt: &crate::lower::model::OutTy) -> (crate::lower::types::Env, crate::lower::types::Env) {
    let be0 = crate::lower::types::bind(&crate::lower::types::bind(benv, &Text::lit("key"), key_b), &Text::lit("$_"), val_b);
    let me0 = crate::lower::types::bind(&crate::lower::types::bind(menv, &Text::lit("key"), key_m), &Text::lit("$_"), val_m);
    match binders_opt {
        None => (be0.clone(), me0.clone()),
        Some(fb) => match &fb.second {
            Some(second) => {
                let be1 = bind_pat(&be0, &fb.first, key_b, &crate::lower::model::Ex::XVar(Text::lit("key")), &kt0());
                let me1 = bind_pat(&me0, &fb.first, key_m, &crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::lit("key")), &kt0());
                (bind_pat(&be1, second, val_b, &crate::lower::model::Ex::XVar(Text::lit("value")), vt), bind_pat(&me1, second, val_m, &crate::lower::model::Ex::XUnit, vt))
            },
            None => (bind_pat(&be0, &fb.first, val_b, &crate::lower::model::Ex::XVar(Text::lit("value")), vt), bind_pat(&me0, &fb.first, val_m, &crate::lower::model::Ex::XUnit, vt)),
        },
    }
}

/// ```prism
/// let kt0
/// ```
pub fn kt0() -> crate::lower::model::OutTy {
    crate::lower::model::OutTy::OutUnit
}

/// ```prism
/// BindPat: fn Env, Pattern, Bn, Ex, OutTy -> Env
/// ```
pub fn bind_pat(env: &crate::lower::types::Env, p_: &crate::syntax::Pattern_, b: &crate::lower::types::Bn, whole: &crate::lower::model::Ex, t: &crate::lower::model::OutTy) -> crate::lower::types::Env {
    match &*p_.kind {
        crate::syntax::PatternKind::PName(n) => crate::lower::types::bind(env, &crate::check::env::sname_key(n), b),
        crate::syntax::PatternKind::PGroup(q) => bind_pat(env, &**q, b, whole, t),
        crate::syntax::PatternKind::PTuple(ps) => {
            let ts = match t {
                crate::lower::model::OutTy::OutTuple(xs) => xs.clone(),
                _ => Array::new(),
            };
            fold(&crate::check::errors::range0(&len(ps)), env, &(|en: &crate::lower::types::Env, i: &Nat| match index(ps, i) {
                Some(q) => match &*q.kind {
                    crate::syntax::PatternKind::PName(n) => crate::lower::types::bind(en, &crate::check::env::sname_key(n), &part_bn(b, whole, i, &or(&index(&ts, i), &crate::lower::model::OutTy::OutUnit))),
                    _ => en.clone(),
                },
                None => en.clone(),
            }))
        },
        _ => env.clone(),
    }
}

/// ```prism
/// PartBn: fn Bn, Ex, Nat, OutTy -> Bn
/// ```
pub fn part_bn(bn0: &crate::lower::types::Bn, whole: &crate::lower::model::Ex, i: &Nat, t: &crate::lower::model::OutTy) -> crate::lower::types::Bn {
    match bn0 {
        crate::lower::types::Bn::BnDyn(x, rds, _) => crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XPart(Rc::new(x.clone()), i.clone()), rds.clone(), t.clone()),
        other => crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XPart(Rc::new(whole.clone()), i.clone()), crate::lower::types::Holding::Owned, t.clone()),
    }
}

/// ```prism
/// RowSuffix: fn Wx -> Text
/// ```
pub fn row_suffix(wx: &crate::lower::node_::Wx) -> Text {
    let n = &len(&wx.rows) + &len(&wx.pending);
    if &n == &Nat::from(0u32) { Text::lit("") } else { Text::from(format!("{}", &n)) }
}

/// ```prism
/// GnTyNamed: fn Wx, Text -> OutTy
/// ```
pub fn gn_ty_named(wx: &crate::lower::node_::Wx, n: &Text) -> crate::lower::model::OutTy {
    fold(&wx.gns, &crate::lower::model::OutTy::OutUnit, &(|acc: &crate::lower::model::OutTy, g: &crate::lower::node_::Gn| if &g.name == n { g.ty.clone() } else { acc.clone() }))
}
