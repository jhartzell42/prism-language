//! The module `Lower.Node.Keyed`, from `target/bootstrap/src/prismc/lower/node/keyed.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file. The runtime
//! side is reached from the crate, `crate::prelude` (and through it `::prism_rtl`), the
//! standard library from `::std`, and nothing is imported by name: a program's own type
//! (`Row`, `Option`) hides none of theirs. The traits are in scope unnamed, for their methods.

use crate::prelude::traits::*;

/// `ForGathered`:
///
/// ```prism
/// type ForGathered = record:
/// ```
#[derive(::std::clone::Clone)]
pub struct ForGathered {
    pub block_p: crate::lower::node_::Wx,
    pub row_wx_p: crate::lower::node_::Wx,
    pub gathers_p: crate::prelude::Array<crate::prelude::Nat>,
}

/// `ForGatheredParts`:
///
/// ```prism
/// type ForGatheredParts = record:
/// ```
#[derive(::std::clone::Clone)]
pub struct ForGatheredParts {
    pub state_p: ForGathered,
    pub parts_p: crate::prelude::Array<crate::lower::node_::Wres>,
}

/// `RowLocal`:
///
/// ```prism
/// type RowLocal = record:
/// ```
#[derive(::std::clone::Clone)]
pub struct RowLocal {
    pub name_p: crate::prelude::Text,
    pub field_p: crate::prelude::Text,
    pub ty_p: crate::lower::model::OutTy,
    pub passed_p: crate::lower::model::Ex,
}

impl crate::prelude::ToPod for RowLocal {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("RowLocal", vec![("name", self.name_p.to_pod()), ("field", self.field_p.to_pod()), ("ty", self.ty_p.to_pod()), ("passed", self.passed_p.to_pod())])
    }
}

impl crate::prelude::FromPod for RowLocal {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(RowLocal { name_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "name")?)?, field_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "field")?)?, ty_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "ty")?)?, passed_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "passed")?)? })
    }
}

/// ```prism
/// ForLine: unbounded fn Wx, Env, Env, ?ForBinders, Expr, Block, Expr, ?Bn -> ((Wx, Wres))
/// ```
pub fn for_line_f(wx_p0: &crate::lower::node_::Wx, benv0_p1: &crate::lower::types::Env, menv0_p2: &crate::lower::types::Env, binders_o3: &::std::option::Option<crate::syntax::ForBinders>, source_p4: &crate::syntax::Expr, body_p5: &crate::syntax::Block, e_p6: &crate::syntax::Expr, bound_o7: &::std::option::Option<crate::lower::types::Bn>) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    let lx_p8 = wx_p0.lx_p.clone();
    let pos_p9 = wx_p0.pos_p.clone();
    let wx1_pa = {
        let mut this: crate::lower::node_::Wx = wx_p0.clone();
        this.pos_p = crate::lower::model::next_pos_f(&this.pos_p);
        this
    };
    let (src_ex0_p14, reads_p15) = crate::lower::node_::dynamics::dynamic_expr_f(&wx1_pa, menv0_p2, source_p4);
    let src_ex_pb = crate::lower::types::plain_owned_f(&crate::lower::types::peel_f(&crate::lower::type_at_f(&lx_p8, &source_p4.span_p)), &src_ex0_p14);
    let src_ty_pc = crate::lower::types::collection_f(&crate::lower::types::peel_f(&crate::lower::type_at_f(&lx_p8, &source_p4.span_p)));
    let (kt_p19, vt_p1a, keyed_p1b) = match &src_ty_pc {
        crate::check::types::Ty::TyMap(k_p16, v_p17) => (crate::lower::types::out_ty_of_f(&lx_p8, &**k_p16), crate::lower::types::out_ty_of_f(&lx_p8, &**v_p17), true),
        crate::check::types::Ty::TyArray(v_p18) => (crate::lower::model::OutTy::OutNat, crate::lower::types::out_ty_of_f(&lx_p8, &**v_p18), false),
        _ => (crate::lower::model::OutTy::OutUnit, crate::lower::model::OutTy::OutUnit, true),
    };
    let src_pd = if keyed_p1b {
        src_ex_pb.clone()
    } else {
        crate::lower::model::Ex::XCall(crate::lower::helper_ref_f(&crate::prelude::Text::lit("indexed")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XRef(::std::rc::Rc::new(src_ex_pb.clone()))]))
    };
    let base_pe = match bound_o7 {
        ::std::option::Option::Some(crate::lower::types::Bn::BnEv(er_p1c, _)) => crate::lower::node_::gn_of_f(&wx1_pa, &er_p1c.node_p).name_p.clone(),
        _ => crate::prelude::Text::lit("rows"),
    };
    let (name_p1d, wx2a_p1e) = crate::lower::node_::fresh_name_f(&wx1_pa, &base_pe);
    let src_getter_pf = crate::prelude::Text::from(format!("{}_source", &name_p1d));
    let src_cached_pg = crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::from(format!("{}_cache", &src_getter_pf)))), crate::prelude::Text::lit("get"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx, crate::lower::model::Ex::XClosure(false, crate::prelude::Array::new(), ::std::rc::Rc::new(src_pd.clone()))]));
    let src_def_ph = crate::lower::model::MethDef { name_p: src_getter_pf.clone(), recv_p: crate::lower::model::Recv::RecvRef, params_p: crate::prelude::Array::new(), cx_p: crate::lower::model::CxArg::CxRef, ret_p: crate::lower::model::OutTy::OutMap(::std::rc::Rc::new(kt_p19.clone()), ::std::rc::Rc::new(vt_p1a.clone())), body_p: crate::prelude::Array::new(), tail_p: src_cached_pg.clone(), doc_p: crate::prelude::Text::from(format!("The source of the `for` at place {} by key, at the read point: what its builder and its rows\' entries read, computed once per write behind it.", &crate::lower::model::place_text_f(&pos_p9))) };
    let row_name_pi = crate::prelude::Text::from(format!("{}{}Row", &wx_p0.node_p, &row_suffix_f(wx_p0)));
    let locals_pj = row_locals_f(benv0_p1, menv0_p2, body_p5);
    let row_fields_pk = crate::prelude::append(&crate::prelude::Array::from(vec![(crate::prelude::Text::lit("key"), kt_p19.clone(), crate::prelude::Text::lit("the row\'s key")), (crate::prelude::Text::lit("left_entry"), crate::lower::model::OutTy::OutCell(::std::rc::Rc::new(crate::lower::model::OutTy::OutOpt(::std::rc::Rc::new(vt_p1a.clone())))), crate::prelude::Text::lit("the entry as the tick its key left opened, kept from the row\'s leaving on (R8)")), (crate::prelude::Text::lit("parent"), crate::lower::model::OutTy::OutWeak(wx_p0.node_p.clone()), crate::prelude::Text::lit("the node of the `for`"))]), &crate::prelude::each(&locals_pj, &(|l_p1f: &RowLocal| (l_p1f.field_p.clone(), l_p1f.ty_p.clone(), crate::prelude::Text::from(format!("`{}`, the block\'s", &l_p1f.name_p))))));
    let row_moves_pl = crate::prelude::append(&crate::prelude::Array::from(vec![(crate::prelude::Text::lit("key"), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("key"))))), (crate::prelude::Text::lit("left_entry"), crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::RefCell::new")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XNone]))), (crate::prelude::Text::lit("parent"), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("parent")))))]), &crate::prelude::each(&locals_pj, &(|l_p1g: &RowLocal| (l_p1g.field_p.clone(), crate::lower::model::Ex::XVar(l_p1g.field_p.clone())))));
    let row_taken_pm = crate::prelude::append(&crate::prelude::append(&crate::lower::node_::node_hooks_p(), &crate::prelude::Array::from(vec![crate::prelude::Text::lit("key"), crate::prelude::Text::lit("value"), crate::prelude::Text::lit("parent"), crate::prelude::Text::lit("entry"), crate::prelude::Text::lit("left_entry")])), &crate::prelude::each(&locals_pj, &(|l_p1h: &RowLocal| l_p1h.field_p.clone())));
    let row_wx0_pn = crate::lower::node_::under_its_path_f(&crate::lower::node_::new_wx_f(&lx_p8, &row_name_pi, &row_fields_pk, &crate::prelude::Array::new(), &row_moves_pl, &crate::prelude::Array::from(vec![entry_getter_f(&src_getter_pf, &vt_p1a)]), &crate::prelude::map_of(vec![(crate::prelude::Text::lit("entry"), crate::prelude::Array::from(vec![crate::lower::node_::Read::ParentRead(src_getter_pf.clone())]))]), &row_taken_pm, &wx_p0.inlining_p, &crate::lower::node_::finish::hosted_rows_o(wx_p0)), &crate::lower::node_::finish::hosted_rows_o(wx_p0));
    let (wx2g_p1i, benv_p1j, menv_p1k) = row_read_getters_f(&wx2a_p1e, benv0_p1, menv0_p2, body_p5);
    let (wx2p_p1l, row_wx0p_p1m, ports_p1n) = crate::lower::node_::switch_::row_env_f(&wx2g_p1i, &row_wx0_pn, &menv_p1k, body_p5);
    let wx2_po = {
        let mut this: crate::lower::node_::Wx = crate::lower::node_::add_field_f(&wx2p_p1l, &crate::prelude::Text::from(format!("{}_cache", &src_getter_pf)), &crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Cache")), crate::prelude::Array::from(vec![crate::lower::model::OutTy::OutMap(::std::rc::Rc::new(kt_p19.clone()), ::std::rc::Rc::new(vt_p1a.clone()))])), &crate::prelude::Text::from(format!("the source of the `for` at place {}, cached (gap SR)", &crate::lower::model::place_text_f(&pos_p9))), &crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Cache::new")), crate::prelude::Array::new()));
        this.taken_p = crate::prelude::append(&this.taken_p, &crate::prelude::Array::from(vec![src_getter_pf.clone(), crate::prelude::Text::from(format!("{}_cache", &src_getter_pf))]));
        this.getters_p = crate::prelude::push(&this.getters_p, &src_def_ph);
        this.dyn_reads_p = crate::prelude::insert(&this.dyn_reads_p, &src_getter_pf, &reads_p15);
        this
    };
    let key_b_pp = crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("key")), crate::lower::types::Holding::Owned, kt_p19.clone());
    let key_m_pq = crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::lit("key")), crate::lower::types::Holding::Owned, kt_p19.clone());
    let benv_l_pr = crate::lower::node_::switch_::whole_of_block_f(&menv_p1k, &bundles_of_f(&ports_p1n, &events_of_f(&ports_p1n, &crate::prelude::fold(&locals_pj, &without_build_values_f(&row_reads_f(&benv_p1j, &crate::lower::node_::switch_::parent_arg_p())), &(|en_p1o: &crate::lower::types::Env, l_p1p: &RowLocal| crate::lower::types::bind_f(en_p1o, &l_p1p.name_p, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(l_p1p.field_p.clone()), crate::lower::types::Holding::Owned, l_p1p.ty_p.clone()))))), &true), &true);
    let menv_l_ps = crate::lower::node_::switch_::whole_of_block_f(&menv_p1k, &bundles_of_f(&ports_p1n, &events_of_f(&ports_p1n, &crate::prelude::fold(&locals_pj, &row_reads_f(&menv_p1k, &crate::lower::node_::switch_::parent_ref_p()), &(|en_p1q: &crate::lower::types::Env, l_p1r: &RowLocal| crate::lower::types::bind_f(en_p1q, &l_p1r.name_p, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), l_p1r.field_p.clone()), crate::lower::types::Holding::Owned, l_p1r.ty_p.clone()))))), &false), &false);
    let passed_pt = crate::prelude::append(&hosted_passed_f(wx_p0), &crate::prelude::each(&locals_pj, &(|l_p1s: &RowLocal| l_p1s.passed_p.clone())));
    let row_params_pu = crate::prelude::append(&crate::prelude::append(&crate::prelude::Array::from(vec![(crate::prelude::Text::lit("key"), kt_p19.clone()), (crate::prelude::Text::lit("value"), vt_p1a.clone()), (crate::prelude::Text::lit("parent"), crate::lower::model::OutTy::OutWeak(wx_p0.node_p.clone()))]), &hosted_params_f(wx_p0)), &crate::prelude::each(&locals_pj, &(|l_p1t: &RowLocal| (l_p1t.field_p.clone(), l_p1t.ty_p.clone()))));
    let (row_wx0f_p25, val_b_p26, val_m_p27, inner_p28) = match &vt_p1a {
        crate::lower::model::OutTy::OutDyn(t_p1u) => {
            let (fname_p20, row_wx_n_p21) = crate::lower::node_::fresh_name_f(&row_wx0p_p1m, &crate::lower::snake_f(&for_value_name_f(binders_o3)));
            let (row_wx_f_p22, fres_p23) = crate::lower::node_::switch_::entry_flatten_f(&row_wx_n_p21, &**t_p1u, &::std::option::Option::Some(crate::lower::types::Bn::BnHold(fname_p20.clone(), (**t_p1u).clone())));
            let fb_p1v = crate::lower::node_::def::bundle_bn_f(&fres_p23);
            (row_wx_f_p22.clone(), fb_p1v.clone(), fb_p1v.clone(), (**t_p1u).clone())
        },
        _ => {
            let entry_m_p24 = crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::lit("entry"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx])), crate::prelude::Array::from(vec![crate::lower::node_::Read::ParentRead(src_getter_pf.clone())]), vt_p1a.clone());
            (row_wx0p_p1m.clone(), crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("value")), crate::lower::types::Holding::Owned, vt_p1a.clone()), entry_m_p24.clone(), vt_p1a.clone())
        },
    };
    let (rbe_p29, rme_p2a) = for_envs_f(&benv_l_pr, &menv_l_ps, binders_o3, &key_b_pp, &key_m_pq, &val_b_p26, &val_m_p27, &inner_p28);
    let row_wx_pv = crate::lower::node_::def::block_into_f(&row_wx0f_p25, &rbe_p29, &rme_p2a, body_p5);
    let wx3_p10 = {
        let mut this: crate::lower::node_::Wx = wx2_po.clone();
        this.row_marks_p = crate::prelude::push(&this.row_marks_p, &crate::lower::node_::RowMarks { builder_p: name_p1d.clone(), reads_p: row_place_reads_f(&row_wx_pv), wrote_p: crate::lower::node_::finish::row_hears_f(&row_wx_pv), builds_p: crate::prelude::Array::new(), kind_p: crate::lower::model::RowKind::ForRow });
        this
    };
    let full_p11 = crate::lower::type_at_f(&lx_p8, &e_p6.span_p);
    let out_ty_p12 = crate::lower::types::out_ty_of_f(&lx_p8, &crate::lower::types::peel_f(&full_p11));
    let row_wx_r_p13 = match &row_wx_pv.result_p {
        crate::lower::node_::Wres::WrPlain(ex_p2b, rt_p2c) => {
            let (f_p2d, rw1_p2e) = crate::lower::node_::fresh_name_f(&row_wx_pv, &crate::prelude::Text::lit("result"));
            {
                let mut this: crate::lower::node_::Wx = rw1_p2e.clone();
                this.lets_p = crate::prelude::push(&this.lets_p, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaBind(f_p2d.clone())), rt_p2c.clone()), ex_p2b.clone()));
                this.fields_p = crate::prelude::push(&this.fields_p, &(f_p2d.clone(), rt_p2c.clone(), crate::prelude::Text::lit("the row\'s plain result")));
                this.inits_p = crate::prelude::push(&this.inits_p, &(f_p2d.clone(), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(f_p2d.clone())))));
                this.result_p = crate::lower::node_::Wres::WrDyn(crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), f_p2d.clone()))), crate::prelude::Array::new(), rt_p2c.clone());
                this
            }
        },
        crate::lower::node_::Wres::WrLate(ex_p2f, rt_p2g) => {
            let mut this: crate::lower::node_::Wx = row_wx_pv.clone();
            this.result_p = crate::lower::node_::Wres::WrDyn(ex_p2f.clone(), crate::prelude::Array::new(), rt_p2g.clone());
            this
        },
        _ => row_wx_pv.clone(),
    };
    match &row_wx_r_p13.result_p {
        crate::lower::node_::Wres::WrEv(r_p2h) => {
            let (gid_p2m, wx4_p2n) = crate::lower::node_::add_gn_f(&wx3_p10, &crate::prelude::Text::from(format!("{}_all", &name_p1d)), &out_ty_p12, &crate::lower::node_::GnKind::GnGather, &crate::prelude::Nat::from(1u32));
            let wx5_p2i = crate::lower::node_::add_field_last_f(&wx4_p2n, &crate::prelude::Text::from(format!("{}_gathered", &name_p1d)), &crate::lower::model::OutTy::OutStamped(::std::rc::Rc::new(out_ty_p12.clone())), &crate::prelude::Text::lit("the rows\' firings this tick, by key"), &crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Stamped::new")), crate::prelude::Array::new()));
            let wx6_p2j = {
                let mut this: crate::lower::node_::Wx = wx5_p2i.clone();
                this.gns_p = crate::prelude::each(&this.gns_p, &(|n_p2o: &crate::lower::node_::Gn| if &n_p2o.id_p == &gid_p2m {
                    crate::lower::node_::dynamics::with_inputs_f(n_p2o, &crate::prelude::Array::from(vec![crate::prelude::Text::from(format!("{}_gathered", &name_p1d))]))
                } else {
                    n_p2o.clone()
                }));
                this
            };
            let row_done_p2k = crate::lower::node_::connect_f(&row_wx_r_p13, r_p2h, &crate::lower::node_::Sk::SkUp(crate::prelude::Text::from(format!("{}_all_in", &name_p1d))));
            let wx7_p2l = add_builder_f(&wx6_p2j, &name_p1d, &pos_p9, &kt_p19, &vt_p1a, &row_name_pi, &keyed_p1b, &reads_p15, &crate::lower::node_::PendingRow { wx_p: row_done_p2k.clone(), qk_p: row_name_pi.clone(), params_p: row_params_pu.clone(), gathers_p: crate::prelude::Array::from(vec![gid_p2m.clone()]) }, &passed_pt);
            (wx7_p2l.clone(), crate::lower::node_::Wres::WrEv(crate::lower::node_::ev_ref_of_f(&wx7_p2l, &gid_p2m)))
        },
        crate::lower::node_::Wres::WrDyn(ex_p2p, result_reads_p2q, rt_p2r) => {
            let gathered_p2s = crate::prelude::Text::from(format!("{}_all", &name_p1d));
            let gathered_ty_p2t = crate::lower::model::OutTy::OutMap(::std::rc::Rc::new(kt_p19.clone()), ::std::rc::Rc::new(rt_p2r.clone()));
            let own_behind_p2u = crate::prelude::filter(&crate::lower::node_::finish::reads_closed_f(&row_wx_r_p13.dyn_reads_p, result_reads_p2q), &(|r_p34: &crate::lower::node_::Read| match r_p34 {
                crate::lower::node_::Read::OwnRead(_) => true,
                crate::lower::node_::Read::ParentRead(_) => false,
            }));
            let row_done_p2v = {
                let mut this: crate::lower::node_::Wx = row_wx_r_p13.clone();
                this.getters_p = crate::prelude::push(&this.getters_p, &crate::lower::model::MethDef { name_p: crate::prelude::Text::lit("result"), recv_p: crate::lower::model::Recv::RecvRef, params_p: crate::prelude::Array::new(), cx_p: crate::lower::model::CxArg::CxRef, ret_p: rt_p2r.clone(), body_p: crate::prelude::Array::new(), tail_p: ex_p2p.clone(), doc_p: crate::prelude::Text::lit("The row\'s result, which the block gathers by key.") });
                this.result_moved_p = if &crate::prelude::len(&own_behind_p2u) > &crate::prelude::Nat::from(0u32) {
                    crate::prelude::push(&this.result_moved_p, &(crate::prelude::Text::from(format!("{}_moved", &gathered_p2s)), own_behind_p2u.clone()))
                } else {
                    this.result_moved_p.clone()
                };
                this
            };
            let wx4_p30 = add_builder_f(&wx3_p10, &name_p1d, &pos_p9, &kt_p19, &vt_p1a, &row_name_pi, &keyed_p1b, &reads_p15, &crate::lower::node_::PendingRow { wx_p: row_done_p2v.clone(), qk_p: row_name_pi.clone(), params_p: row_params_pu.clone(), gathers_p: crate::prelude::Array::new() }, &passed_pt);
            let all_p31 = crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), name_p1d.clone())), crate::prelude::Text::lit("borrow"), crate::prelude::Array::new())), crate::prelude::Text::lit("iter"), crate::prelude::Array::new())), crate::prelude::Text::lit("map"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XClosure(false, crate::prelude::Array::from(vec![crate::lower::model::Pa::PaTuple(crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("k")), crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("row"))]))]), ::std::rc::Rc::new(crate::lower::model::Ex::XTuple(crate::prelude::Array::from(vec![crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("k")))), crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("row"))), crate::prelude::Text::lit("result"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx]))]))))]))), crate::prelude::Text::lit("collect"), crate::prelude::Array::new());
            let what_p32 = crate::prelude::Text::from(format!("the dynamic gathered by the `for` at place {}", &crate::lower::model::place_text_f(&pos_p9)));
            let wx5_p33 = {
                let mut this: crate::lower::node_::Wx = wx4_p30.clone();
                this.taken_p = crate::prelude::append(&this.taken_p, &crate::prelude::Array::from(vec![gathered_p2s.clone(), crate::prelude::Text::from(format!("{}_now", &gathered_p2s)), crate::prelude::Text::from(format!("{}_snap", &gathered_p2s)), crate::prelude::Text::from(format!("{}_moved", &gathered_p2s)), crate::prelude::Text::from(format!("{}_publish", &gathered_p2s))]));
                this.getters_p = crate::prelude::append(&this.getters_p, &crate::prelude::Array::from(vec![crate::lower::model::MethDef { name_p: crate::prelude::Text::from(format!("{}_now", &gathered_p2s)), recv_p: crate::lower::model::Recv::RecvRef, params_p: crate::prelude::Array::new(), cx_p: crate::lower::model::CxArg::CxRef, ret_p: gathered_ty_p2t.clone(), body_p: crate::prelude::Array::new(), tail_p: all_p31.clone(), doc_p: crate::prelude::Text::lit("The rows\' results by key, computed live: what the snapshot of the `for`\'s dynamic is taken from (pick ST).") }, crate::lower::node_::static_::snap_getter_f(&gathered_p2s, &gathered_ty_p2t, &crate::prelude::Text::lit("The `for`\'s dynamic, the rows\' results by key, a structural dynamic (pick ST): one tick behind the rows, the snapshot of the tick before the tick the read point is after."))]));
                this.fields_p = crate::prelude::push(&this.fields_p, &(crate::prelude::Text::from(format!("{}_snap", &gathered_p2s)), crate::lower::model::OutTy::OutSnapshot(::std::rc::Rc::new(gathered_ty_p2t.clone())), crate::prelude::Text::from(format!("the `for` at place {}\'s gathered dynamic, structural: its snapshots, the rows\' results and the lagged dynamic (pick ST)", &crate::lower::model::place_text_f(&pos_p9)))));
                this.inits_p = crate::prelude::push(&this.inits_p, &(crate::prelude::Text::from(format!("{}_snap", &gathered_p2s)), crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Snapshot::new")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XStr(what_p32.clone())]))));
                this.snaps_p = crate::prelude::push(&this.snaps_p, &crate::lower::node_::SnapDef { name_p: gathered_p2s.clone(), live_p: crate::prelude::Text::from(format!("{}_now", &gathered_p2s)), ty_p: gathered_ty_p2t.clone(), eq_p: crate::lower::program::ty_has_eq_f(&lx_p8, &crate::lower::types::peel_f(&full_p11), &crate::prelude::Array::new()), builder_p: name_p1d.clone(), before_p: false, what_p: what_p32.clone() });
                this.dyn_reads_p = crate::prelude::insert(&this.dyn_reads_p, &crate::prelude::Text::from(format!("{}_now", &gathered_p2s)), &crate::lower::node_::union_reads_f(&reads_p15, &block_reads_f(&crate::lower::node_::finish::reads_closed_f(&row_wx_r_p13.dyn_reads_p, result_reads_p2q))));
                this
            };
            (wx5_p33.clone(), crate::lower::node_::Wres::WrDyn(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), gathered_p2s.clone(), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx])), crate::prelude::Array::from(vec![crate::lower::node_::Read::OwnRead(gathered_p2s.clone())]), gathered_ty_p2t.clone()))
        },
        crate::lower::node_::Wres::WrParts(parts_p35) => {
            let gathered_p36 = for_parts_f(&ForGathered { block_p: wx3_p10.clone(), row_wx_p: row_wx_r_p13.clone(), gathers_p: crate::prelude::Array::new() }, &name_p1d, &pos_p9, &kt_p19, &bundle_part_tys_f(&full_p11), parts_p35, &crate::prelude::Text::lit(""), &reads_p15);
            let wx4_p37 = add_builder_f(&gathered_p36.state_p.block_p, &name_p1d, &pos_p9, &kt_p19, &vt_p1a, &row_name_pi, &keyed_p1b, &reads_p15, &crate::lower::node_::PendingRow { wx_p: gathered_p36.state_p.row_wx_p.clone(), qk_p: row_name_pi.clone(), params_p: row_params_pu.clone(), gathers_p: gathered_p36.state_p.gathers_p.clone() }, &passed_pt);
            (wx4_p37.clone(), crate::lower::node_::Wres::WrParts(gathered_p36.parts_p.clone()))
        },
        _ => {
            let wx4_p38 = add_builder_f(&wx3_p10, &name_p1d, &pos_p9, &kt_p19, &vt_p1a, &row_name_pi, &keyed_p1b, &reads_p15, &crate::lower::node_::PendingRow { wx_p: row_wx_r_p13.clone(), qk_p: row_name_pi.clone(), params_p: row_params_pu.clone(), gathers_p: crate::prelude::Array::new() }, &passed_pt);
            (wx4_p38.clone(), crate::lower::node_::Wres::WrUnit)
        },
    }
}

/// ```prism
/// BundlePartTys: fn Ty -> [Ty]
/// ```
pub fn bundle_part_tys_f(t_p0: &crate::check::types::Ty) -> crate::prelude::Array<crate::check::types::Ty> {
    match t_p0 {
        crate::check::types::Ty::TyTuple(ts_p1) => ts_p1.clone(),
        crate::check::types::Ty::TyAt(i_p2, _) => bundle_part_tys_f(&**i_p2),
        crate::check::types::Ty::TySig(m12531_2_0, i_p3) if (m12531_2_0 == &crate::prelude::Text::lit("&")) => bundle_part_tys_f(&**i_p3),
        _ => crate::prelude::Array::new(),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// ForParts: unbounded fn ForGathered, Text, Pos, OutTy, [Ty], [Wres], Text, [Read] -> ForGatheredParts
/// ```
pub fn for_parts_f(start_p0: &ForGathered, name_p1: &crate::prelude::Text, pos_p2: &crate::lower::model::Pos, kt_p3: &crate::lower::model::OutTy, tys_p4: &crate::prelude::Array<crate::check::types::Ty>, parts_p5: &crate::prelude::Array<crate::lower::node_::Wres>, prefix_p6: &crate::prelude::Text, reads_p7: &crate::prelude::Array<crate::lower::node_::Read>) -> ForGatheredParts {
    crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(parts_p5)), ForGatheredParts { state_p: start_p0.clone(), parts_p: crate::prelude::Array::new() }, {
        let prefix_p6x = prefix_p6.clone();
        let name_p1x = name_p1.clone();
        let pos_p2x = pos_p2.clone();
        let kt_p3x = kt_p3.clone();
        let tys_p4x = tys_p4.clone();
        let parts_p5x = parts_p5.clone();
        let reads_p7x = reads_p7.clone();
        ::std::rc::Rc::new(move |(p0, p1): (ForGatheredParts, crate::prelude::Nat)| {
            let prefix_p6xy = prefix_p6x.clone();
            let name_p1xy = name_p1x.clone();
            let pos_p2xy = pos_p2x.clone();
            let kt_p3xy = kt_p3x.clone();
            let tys_p4xy = tys_p4x.clone();
            let parts_p5xy = parts_p5x.clone();
            let reads_p7xy = reads_p7x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_p8 = p0;
                let i_p9 = p1;
                {
                    let suffix_pa = if &prefix_p6xy == &crate::prelude::Text::lit("") {
                        crate::prelude::Text::from(format!("p{}", &i_p9))
                    } else {
                        crate::prelude::Text::from(format!("{}_{}", &prefix_p6xy, &i_p9))
                    };
                    let (state_pb, res_pc) = for_part_f(&acc_p8.state_p, &name_p1xy, &pos_p2xy, &kt_p3xy, &crate::prelude::or(&crate::prelude::index(&tys_p4xy, &i_p9), &crate::check::types::Ty::TyErr), &crate::prelude::or(&crate::prelude::index(&parts_p5xy, &i_p9), &crate::lower::node_::Wres::WrUnit), &suffix_pa, &reads_p7xy);
                    ::prism_rtl::Turn::Finished(ForGatheredParts { state_p: state_pb.clone(), parts_p: crate::prelude::push(&acc_p8.parts_p, &res_pc) })
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((ForGatheredParts, crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<ForGatheredParts>>>
    }))
}

/// ```prism
/// ForPart: unbounded fn ForGathered, Text, Pos, OutTy, Ty, Wres, Text, [Read] -> ((ForGathered, Wres))
/// ```
pub fn for_part_f(st_p0: &ForGathered, name_p1: &crate::prelude::Text, pos_p2: &crate::lower::model::Pos, kt_p3: &crate::lower::model::OutTy, full_p4: &crate::check::types::Ty, part_p5: &crate::lower::node_::Wres, suffix_p6: &crate::prelude::Text, reads_p7: &crate::prelude::Array<crate::lower::node_::Read>) -> (ForGathered, crate::lower::node_::Wres) {
    let lx_p8 = st_p0.block_p.lx_p.clone();
    let part2_p9 = match part_p5 {
        crate::lower::node_::Wres::WrHosted(inner_pa, _) => (**inner_pa).clone(),
        _ => part_p5.clone(),
    };
    match &part2_p9 {
        crate::lower::node_::Wres::WrEv(r_pb) => {
            let out_ty_pc = crate::lower::types::out_ty_of_f(&lx_p8, &crate::lower::types::peel_f(full_p4));
            let (gid_pg, b1_ph) = crate::lower::node_::add_gn_f(&st_p0.block_p, &crate::prelude::Text::from(format!("{}_{}_all", name_p1, suffix_p6)), &out_ty_pc, &crate::lower::node_::GnKind::GnGather, &crate::prelude::Nat::from(1u32));
            let b2_pd = crate::lower::node_::add_field_last_f(&b1_ph, &crate::prelude::Text::from(format!("{}_{}_gathered", name_p1, suffix_p6)), &crate::lower::model::OutTy::OutStamped(::std::rc::Rc::new(out_ty_pc.clone())), &crate::prelude::Text::from(format!("the rows\' firings of part {} this tick, by key", suffix_p6)), &crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Stamped::new")), crate::prelude::Array::new()));
            let b3_pe = {
                let mut this: crate::lower::node_::Wx = b2_pd.clone();
                this.gns_p = crate::prelude::each(&this.gns_p, &(|n_pi: &crate::lower::node_::Gn| if &n_pi.id_p == &gid_pg {
                    crate::lower::node_::dynamics::with_inputs_f(n_pi, &crate::prelude::Array::from(vec![crate::prelude::Text::from(format!("{}_{}_gathered", name_p1, suffix_p6))]))
                } else {
                    n_pi.clone()
                }));
                this
            };
            let row_done_pf = crate::lower::node_::connect_f(&st_p0.row_wx_p, r_pb, &crate::lower::node_::Sk::SkUp(crate::prelude::Text::from(format!("{}_{}_all_in", name_p1, suffix_p6))));
            (ForGathered { block_p: b3_pe.clone(), row_wx_p: row_done_pf.clone(), gathers_p: crate::prelude::push(&st_p0.gathers_p, &gid_pg) }, crate::lower::node_::Wres::WrEv(crate::lower::node_::ev_ref_of_f(&b3_pe, &gid_pg)))
        },
        crate::lower::node_::Wres::WrDyn(ex_pj, result_reads_pk, rt_pl) => for_dyn_part_f(st_p0, name_p1, pos_p2, kt_p3, full_p4, ex_pj, result_reads_pk, rt_pl, suffix_p6, reads_p7),
        crate::lower::node_::Wres::WrPlain(ex_pm, rt_pn) => {
            let (f_pp, rw1_pq) = crate::lower::node_::fresh_name_f(&st_p0.row_wx_p, &crate::prelude::Text::lit("result"));
            let rw2_po = {
                let mut this: crate::lower::node_::Wx = rw1_pq.clone();
                this.lets_p = crate::prelude::push(&this.lets_p, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaBind(f_pp.clone())), rt_pn.clone()), ex_pm.clone()));
                this.fields_p = crate::prelude::push(&this.fields_p, &(f_pp.clone(), rt_pn.clone(), crate::prelude::Text::from(format!("the row\'s plain result, part {}", suffix_p6))));
                this.inits_p = crate::prelude::push(&this.inits_p, &(f_pp.clone(), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(f_pp.clone())))));
                this
            };
            for_dyn_part_f(&ForGathered { block_p: st_p0.block_p.clone(), row_wx_p: rw2_po.clone(), gathers_p: st_p0.gathers_p.clone() }, name_p1, pos_p2, kt_p3, full_p4, &crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), f_pp.clone()))), &crate::prelude::Array::new(), rt_pn, suffix_p6, reads_p7)
        },
        crate::lower::node_::Wres::WrLate(ex_pr, rt_ps) => for_dyn_part_f(st_p0, name_p1, pos_p2, kt_p3, full_p4, ex_pr, &crate::prelude::Array::new(), rt_ps, suffix_p6, reads_p7),
        crate::lower::node_::Wres::WrParts(inner_pt) => {
            let gathered_pu = for_parts_f(st_p0, name_p1, pos_p2, kt_p3, &bundle_part_tys_f(full_p4), inner_pt, suffix_p6, reads_p7);
            (gathered_pu.state_p.clone(), crate::lower::node_::Wres::WrParts(gathered_pu.parts_p.clone()))
        },
        _ => (st_p0.clone(), crate::lower::node_::Wres::WrUnit),
    }
}

/// ```prism
/// ForDynPart: unbounded fn ForGathered, Text, Pos, OutTy, Ty, Ex, [Read], OutTy, Text, [Read] -> ((ForGathered, Wres))
/// ```
pub fn for_dyn_part_f(st_p0: &ForGathered, name_p1: &crate::prelude::Text, pos_p2: &crate::lower::model::Pos, kt_p3: &crate::lower::model::OutTy, full_p4: &crate::check::types::Ty, ex_p5: &crate::lower::model::Ex, result_reads_p6: &crate::prelude::Array<crate::lower::node_::Read>, rt_p7: &crate::lower::model::OutTy, suffix_p8: &crate::prelude::Text, reads_p9: &crate::prelude::Array<crate::lower::node_::Read>) -> (ForGathered, crate::lower::node_::Wres) {
    let lx_pa = st_p0.block_p.lx_p.clone();
    let gathered_pb = crate::prelude::Text::from(format!("{}_{}_all", name_p1, suffix_p8));
    let row_result_pc = crate::prelude::Text::from(format!("result_{}", suffix_p8));
    let gathered_ty_pd = crate::lower::model::OutTy::OutMap(::std::rc::Rc::new(kt_p3.clone()), ::std::rc::Rc::new(rt_p7.clone()));
    let own_behind_pe = crate::prelude::filter(&crate::lower::node_::finish::reads_closed_f(&st_p0.row_wx_p.dyn_reads_p, result_reads_p6), &(|r_pj: &crate::lower::node_::Read| match r_pj {
        crate::lower::node_::Read::OwnRead(_) => true,
        crate::lower::node_::Read::ParentRead(_) => false,
    }));
    let row_done_pf = {
        let mut this: crate::lower::node_::Wx = st_p0.row_wx_p.clone();
        this.taken_p = crate::prelude::push(&this.taken_p, &row_result_pc);
        this.getters_p = crate::prelude::push(&this.getters_p, &crate::lower::model::MethDef { name_p: row_result_pc.clone(), recv_p: crate::lower::model::Recv::RecvRef, params_p: crate::prelude::Array::new(), cx_p: crate::lower::model::CxArg::CxRef, ret_p: rt_p7.clone(), body_p: crate::prelude::Array::new(), tail_p: ex_p5.clone(), doc_p: crate::prelude::Text::from(format!("Part {} of the row\'s result, which the block gathers by key.", suffix_p8)) });
        this.result_moved_p = if &crate::prelude::len(&own_behind_pe) > &crate::prelude::Nat::from(0u32) {
            crate::prelude::push(&this.result_moved_p, &(crate::prelude::Text::from(format!("{}_moved", &gathered_pb)), own_behind_pe.clone()))
        } else {
            this.result_moved_p.clone()
        };
        this
    };
    let all_pg = crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), name_p1.clone())), crate::prelude::Text::lit("borrow"), crate::prelude::Array::new())), crate::prelude::Text::lit("iter"), crate::prelude::Array::new())), crate::prelude::Text::lit("map"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XClosure(false, crate::prelude::Array::from(vec![crate::lower::model::Pa::PaTuple(crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("k")), crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("row"))]))]), ::std::rc::Rc::new(crate::lower::model::Ex::XTuple(crate::prelude::Array::from(vec![crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("k")))), crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("row"))), row_result_pc.clone(), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx]))]))))]))), crate::prelude::Text::lit("collect"), crate::prelude::Array::new());
    let what_ph = crate::prelude::Text::from(format!("part {} of the bundle gathered by the `for` at place {}", suffix_p8, &crate::lower::model::place_text_f(pos_p2)));
    let block_pi = {
        let mut this: crate::lower::node_::Wx = st_p0.block_p.clone();
        this.taken_p = crate::prelude::append(&this.taken_p, &crate::prelude::Array::from(vec![gathered_pb.clone(), crate::prelude::Text::from(format!("{}_now", &gathered_pb)), crate::prelude::Text::from(format!("{}_snap", &gathered_pb)), crate::prelude::Text::from(format!("{}_moved", &gathered_pb)), crate::prelude::Text::from(format!("{}_publish", &gathered_pb))]));
        this.getters_p = crate::prelude::append(&this.getters_p, &crate::prelude::Array::from(vec![crate::lower::model::MethDef { name_p: crate::prelude::Text::from(format!("{}_now", &gathered_pb)), recv_p: crate::lower::model::Recv::RecvRef, params_p: crate::prelude::Array::new(), cx_p: crate::lower::model::CxArg::CxRef, ret_p: gathered_ty_pd.clone(), body_p: crate::prelude::Array::new(), tail_p: all_pg.clone(), doc_p: crate::prelude::Text::from(format!("Part {} of the rows\' results by key, computed live: what the snapshot of the gathered dynamic is taken from (pick ST).", suffix_p8)) }, crate::lower::node_::static_::snap_getter_f(&gathered_pb, &gathered_ty_pd, &crate::prelude::Text::from(format!("Part {} of the `for`\'s bundle, the rows\' values by key, a structural dynamic (pick ST): one tick behind the rows.", suffix_p8)))]));
        this.fields_p = crate::prelude::push(&this.fields_p, &(crate::prelude::Text::from(format!("{}_snap", &gathered_pb)), crate::lower::model::OutTy::OutSnapshot(::std::rc::Rc::new(gathered_ty_pd.clone())), crate::prelude::Text::from(format!("part {} of the bundle of the `for` at place {}, structural: its snapshots and the lagged dynamic (pick ST)", suffix_p8, &crate::lower::model::place_text_f(pos_p2)))));
        this.inits_p = crate::prelude::push(&this.inits_p, &(crate::prelude::Text::from(format!("{}_snap", &gathered_pb)), crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Snapshot::new")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XStr(what_ph.clone())]))));
        this.snaps_p = crate::prelude::push(&this.snaps_p, &crate::lower::node_::SnapDef { name_p: gathered_pb.clone(), live_p: crate::prelude::Text::from(format!("{}_now", &gathered_pb)), ty_p: gathered_ty_pd.clone(), eq_p: crate::lower::program::ty_has_eq_f(&lx_pa, &crate::lower::types::peel_f(full_p4), &crate::prelude::Array::new()), builder_p: name_p1.clone(), before_p: false, what_p: what_ph.clone() });
        this.dyn_reads_p = crate::prelude::insert(&this.dyn_reads_p, &crate::prelude::Text::from(format!("{}_now", &gathered_pb)), &crate::lower::node_::union_reads_f(reads_p9, &block_reads_f(&crate::lower::node_::finish::reads_closed_f(&st_p0.row_wx_p.dyn_reads_p, result_reads_p6))));
        this
    };
    (ForGathered { block_p: block_pi.clone(), row_wx_p: row_done_pf.clone(), gathers_p: st_p0.gathers_p.clone() }, crate::lower::node_::Wres::WrDyn(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), gathered_pb.clone(), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx])), crate::prelude::Array::from(vec![crate::lower::node_::Read::OwnRead(gathered_pb.clone())]), gathered_ty_pd.clone()))
}

/// ```prism
/// EntryGetter: fn Text, OutTy -> MethDef
/// ```
pub fn entry_getter_f(src_getter_p0: &crate::prelude::Text, vt_p1: &crate::lower::model::OutTy) -> crate::lower::model::MethDef {
    let found_p2 = crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("parent"))), src_getter_p0.clone(), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx]))), crate::prelude::Text::lit("get"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::lit("key"))))]))), crate::prelude::Text::lit("cloned"), crate::prelude::Array::new());
    let opened_p3 = crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XCx), crate::prelude::Text::lit("before"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XClosure(false, crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("cx"))]), ::std::rc::Rc::new(found_p2.clone()))]))), crate::prelude::Text::lit("expect"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XStr(crate::prelude::Text::lit("a row\'s key is in its source as its tick opened"))]));
    let body_p4 = crate::prelude::Array::from(vec![crate::lower::model::Do::DoIfLet(crate::lower::model::Pa::PaCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Some")), crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("v"))])), crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::lit("left_entry"))), crate::prelude::Text::lit("borrow"), crate::prelude::Array::new())), crate::prelude::Text::lit("as_ref"), crate::prelude::Array::new()), crate::prelude::Array::from(vec![crate::lower::model::Do::DoReturn(crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("v")))))]), crate::prelude::Array::new()), crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("parent")), crate::lower::node_::switch_::parent_ref_p())]);
    let tail_p5 = crate::lower::model::Ex::XMatch(::std::rc::Rc::new(found_p2.clone()), crate::prelude::Array::from(vec![crate::lower::model::XArm { pat_p: crate::lower::model::Pa::PaCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Some")), crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("v"))])), conds_p: crate::prelude::Array::new(), body_p: crate::lower::model::Ex::XVar(crate::prelude::Text::lit("v")) }, crate::lower::model::XArm { pat_p: crate::lower::model::Pa::PaUnit(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::None"))), conds_p: crate::prelude::Array::new(), body_p: opened_p3.clone() }]), false, vt_p1.clone());
    crate::lower::model::MethDef { name_p: crate::prelude::Text::lit("entry"), recv_p: crate::lower::model::Recv::RecvRef, params_p: crate::prelude::Array::new(), cx_p: crate::lower::model::CxArg::CxRef, ret_p: vt_p1.clone(), body_p: body_p4.clone(), tail_p: tail_p5.clone(), doc_p: crate::prelude::Text::lit("The row\'s entry, `$_`: the block\'s source at this key, at the read point; from the row\'s leaving on, the value as the leaving tick opened.") }
}

/// ```prism
/// AddBuilder: fn Wx, Text, Pos, OutTy, OutTy, Text, Bool, [Read], PendingRow, [Ex] -> Wx
/// ```
pub fn add_builder_f(wx_p0: &crate::lower::node_::Wx, name_p1: &crate::prelude::Text, pos_p2: &crate::lower::model::Pos, kt_p3: &crate::lower::model::OutTy, vt_p4: &crate::lower::model::OutTy, row_name_p5: &crate::prelude::Text, keyed_p6: &bool, reads_p7: &crate::prelude::Array<crate::lower::node_::Read>, waiting_p8: &crate::lower::node_::PendingRow, passed_p9: &crate::prelude::Array<crate::lower::model::Ex>) -> crate::lower::node_::Wx {
    let wx0_pa = crate::lower::node_::add_field_last_f(wx_p0, name_p1, &crate::lower::model::OutTy::OutCell(::std::rc::Rc::new(crate::lower::model::OutTy::OutMap(::std::rc::Rc::new(kt_p3.clone()), ::std::rc::Rc::new(crate::lower::model::OutTy::OutRc(::std::rc::Rc::new(crate::lower::model::OutTy::OutNamed(crate::lower::site_ref_f(&wx_p0.lx_p, row_name_p5), crate::prelude::Array::new()))))))), &crate::prelude::Text::from(format!("the rows of the `for` at place {}", &crate::lower::model::place_text_f(pos_p2))), &crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::RefCell::new")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Map::new")), crate::prelude::Array::new())])));
    let wx1_pb = crate::lower::node_::add_field_last_f(&wx0_pa, &crate::prelude::Text::from(format!("{}_from", name_p1)), &crate::lower::model::OutTy::OutCell(::std::rc::Rc::new(crate::lower::model::OutTy::OutMap(::std::rc::Rc::new(kt_p3.clone()), ::std::rc::Rc::new(vt_p4.clone())))), &crate::prelude::Text::from(format!("the source the rows of the `for` at place {} were last built from", &crate::lower::model::place_text_f(pos_p2))), &crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::RefCell::new")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Map::new")), crate::prelude::Array::new())])));
    let replaced_pc = crate::prelude::each(&crate::prelude::filter(&waiting_p8.wx_p.flattens_p, &(|fl_pd: &crate::lower::node_::FlatDef| (&fl_pd.generation_p == &crate::prelude::Text::lit("")) && !fl_pd.held_p)), &(|fl_pe: &crate::lower::node_::FlatDef| crate::prelude::Text::from(format!("{}_replaced", &fl_pe.name_p))));
    let mut this: crate::lower::node_::Wx = wx1_pb.clone();
    this.builders_p = crate::prelude::push(&this.builders_p, &crate::lower::model::ForDef { name_p: name_p1.clone(), pos_p: pos_p2.clone(), at_p: crate::lower::node_::finish::place_at_f(wx_p0, &crate::prelude::Text::lit("self"), pos_p2), key_ty_p: kt_p3.clone(), value_ty_p: vt_p4.clone(), row_node_p: row_name_p5.clone(), keyed_p: *keyed_p6, source_p: crate::prelude::Text::from(format!("{}_source", name_p1)), parent_p: crate::lower::model::Ex::XWeak(::std::rc::Rc::new(crate::lower::model::Ex::XSelf)), passed_p: passed_p9.clone(), moved_p: crate::prelude::or(&crate::lower::node_::finish::hosted_rows_o(wx_p0), &crate::prelude::Text::lit("")), replaced_p: replaced_pc.clone() });
    this.build_holds_p = crate::lower::node_::union_reads_f(&this.build_holds_p, reads_p7);
    this.pending_p = crate::prelude::push(&this.pending_p, waiting_p8);
    this
}

/// ```prism
/// ForValueName: fn ?ForBinders -> Text
/// ```
pub fn for_value_name_f(binders_o0: &::std::option::Option<crate::syntax::ForBinders>) -> crate::prelude::Text {
    match binders_o0 {
        ::std::option::Option::Some(fb_p1) => match &fb_p1.second_o {
            ::std::option::Option::Some(p_p2) => pattern_name_or_f(p_p2, &crate::prelude::Text::lit("flatten")),
            ::std::option::Option::None => pattern_name_or_f(&fb_p1.first_p, &crate::prelude::Text::lit("flatten")),
        },
        ::std::option::Option::None => crate::prelude::Text::lit("flatten"),
    }
}

/// ```prism
/// PatternNameOr: fn Pattern, Text -> Text
/// ```
pub fn pattern_name_or_f(p_p0: &crate::syntax::Pattern, other_p1: &crate::prelude::Text) -> crate::prelude::Text {
    match &*p_p0.kind_p {
        crate::syntax::PatternKind::PName(n_p2) => crate::check::env::sname_key_f(n_p2),
        crate::syntax::PatternKind::PGroup(q_p3) => pattern_name_or_f(&**q_p3, other_p1),
        _ => other_p1.clone(),
    }
}

/// ```prism
/// RowPlaceReads: fn Wx -> [Read]
/// ```
pub fn row_place_reads_f(row_wx_p0: &crate::lower::node_::Wx) -> crate::prelude::Array<crate::lower::node_::Read> {
    crate::prelude::fold(&row_wx_p0.places_p, &crate::prelude::Array::new(), &(|acc_p1: &crate::prelude::Array<crate::lower::node_::Read>, pl_p2: &crate::lower::node_::Place| crate::lower::node_::union_reads_f(acc_p1, &block_reads_f(&crate::lower::node_::finish::reads_closed_f(&row_wx_p0.dyn_reads_p, &pl_p2.reads_p)))))
}

/// ```prism
/// HostedParams: fn Wx -> [((Text, OutTy))]
/// ```
pub fn hosted_params_f(wx_p0: &crate::lower::node_::Wx) -> crate::prelude::Array<(crate::prelude::Text, crate::lower::model::OutTy)> {
    match crate::lower::node_::finish::hosted_rows_o(wx_p0) {
        ::std::option::Option::Some(_) => crate::prelude::Array::from(vec![(crate::prelude::Text::lit("enclosing"), crate::lower::types::host_of_ty_p())]),
        ::std::option::Option::None => crate::prelude::Array::new(),
    }
}

/// ```prism
/// HostedPassed: fn Wx -> [Ex]
/// ```
pub fn hosted_passed_f(wx_p0: &crate::lower::node_::Wx) -> crate::prelude::Array<crate::lower::model::Ex> {
    match crate::lower::node_::finish::hosted_rows_o(wx_p0) {
        ::std::option::Option::Some(_) => crate::prelude::Array::from(vec![crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::node_::finish::host_field_ex_f(wx_p0, &wx_p0.pos_p)))]),
        ::std::option::Option::None => crate::prelude::Array::new(),
    }
}

/// ```prism
/// RowReads: fn Env, Ex -> Env
/// ```
pub fn row_reads_f(env_p0: &crate::lower::types::Env, pref_p1: &crate::lower::model::Ex) -> crate::lower::types::Env {
    crate::prelude::fold(&crate::prelude::keys(&env_p0.names_p), env_p0, &(|en_p2: &crate::lower::types::Env, k_p3: &crate::prelude::Text| 'm23675: {
        let scrutinee = &crate::prelude::get(&env_p0.names_p, k_p3);
        if let ::std::option::Option::Some(crate::lower::types::Bn::BnHold(f_p4, t_p5)) = scrutinee {
            break 'm23675 crate::lower::types::bind_f(en_p2, k_p3, &crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(pref_p1.clone()), f_p4.clone())), crate::prelude::Text::lit("get"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx])), crate::prelude::Array::from(vec![crate::lower::node_::Read::ParentRead(f_p4.clone())]), t_p5.clone()));
        }
        if let ::std::option::Option::Some(crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(m23675_1_0_0, m_p6, xs_p7), _, t_p8)) = scrutinee && let crate::lower::model::Ex::XSelf = &**m23675_1_0_0 {
            break 'm23675 crate::lower::types::bind_f(en_p2, k_p3, &crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(pref_p1.clone()), m_p6.clone(), xs_p7.clone()), crate::prelude::Array::from(vec![crate::lower::node_::Read::ParentRead(m_p6.clone())]), t_p8.clone()));
        }
        if let ::std::option::Option::Some(crate::lower::types::Bn::BnDyn(ex_p9, rds_pa, bt_pb)) = scrutinee {
            break 'm23675 match crate::prelude::get(&env_p0.names_p, &crate::prelude::Text::from(format!("{}#row", k_p3))) {
                ::std::option::Option::Some(crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(_, m_pc, xs_pd), _, t_pe)) => crate::lower::types::bind_f(en_p2, k_p3, &crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(pref_p1.clone()), m_pc.clone(), xs_pd), crate::prelude::Array::from(vec![crate::lower::node_::Read::ParentRead(m_pc.clone())]), t_pe)),
                _ => if crate::lower::node_::switch_::on_self_rooted_f(ex_p9) && crate::prelude::fold(rds_pa, &true, &(|f_pf: &bool, rd_pg: &crate::lower::node_::Read| *f_pf && crate::lower::node_::finish::is_own_read_f(rd_pg))) {
                    crate::lower::types::bind_f(en_p2, k_p3, &crate::lower::types::Bn::BnDyn(over_block_f(ex_p9, pref_p1), crate::prelude::each(rds_pa, &(|rd_ph: &crate::lower::node_::Read| crate::lower::node_::switch_::as_parent_read_f(rd_ph))), bt_pb.clone()))
                } else {
                    en_p2.clone()
                },
            };
        }
        en_p2.clone()
    }))
}

/// ```prism
/// WithoutBuildValues: fn Env -> Env
/// ```
pub fn without_build_values_f(env_p0: &crate::lower::types::Env) -> crate::lower::types::Env {
    crate::lower::node_::def::without_names_f(env_p0, &crate::prelude::filter(&crate::prelude::keys(&env_p0.names_p), &(|k_p1: &crate::prelude::Text| &crate::syntax::lexer::chars::before_suffix_o(k_p1, &crate::prelude::Text::lit("#init")) != &::std::option::Option::None)))
}

/// ```prism
/// OverBlock: fn Ex, Ex -> Ex
/// ```
pub fn over_block_f(x_p0: &crate::lower::model::Ex, pref_p1: &crate::lower::model::Ex) -> crate::lower::model::Ex {
    match x_p0 {
        crate::lower::model::Ex::XSelf => pref_p1.clone(),
        crate::lower::model::Ex::XField(y_p2, f_p3) => crate::lower::model::Ex::XField(::std::rc::Rc::new(over_block_f(&**y_p2, pref_p1)), f_p3.clone()),
        crate::lower::model::Ex::XFieldOf(y_p4, o_p5, f_p6) => crate::lower::model::Ex::XFieldOf(::std::rc::Rc::new(over_block_f(&**y_p4, pref_p1)), o_p5.clone(), f_p6.clone()),
        crate::lower::model::Ex::XPart(y_p7, i_p8) => crate::lower::model::Ex::XPart(::std::rc::Rc::new(over_block_f(&**y_p7, pref_p1)), i_p8.clone()),
        crate::lower::model::Ex::XMethod(y_p9, m_pa, xs_pb) => crate::lower::model::Ex::XMethod(::std::rc::Rc::new(over_block_f(&**y_p9, pref_p1)), m_pa.clone(), xs_pb.clone()),
        _ => x_p0.clone(),
    }
}

/// ```prism
/// EventsOf: fn Env, Env -> Env
/// ```
pub fn events_of_f(ports_p0: &crate::lower::types::Env, env_p1: &crate::lower::types::Env) -> crate::lower::types::Env {
    crate::prelude::fold(&crate::prelude::keys(&ports_p0.names_p), env_p1, &(|en_p2: &crate::lower::types::Env, k_p3: &crate::prelude::Text| match crate::prelude::get(&ports_p0.names_p, k_p3) {
        ::std::option::Option::Some(crate::lower::types::Bn::BnEv(er_p4, t_p5)) => crate::lower::types::bind_f(en_p2, k_p3, &crate::lower::types::Bn::BnEv(er_p4, t_p5)),
        ::std::option::Option::Some(crate::lower::types::Bn::BnWidget(x_p6, cbenv_p7, cmenv_p8, clx_p9)) => crate::lower::types::bind_f(en_p2, k_p3, &crate::lower::types::Bn::BnWidget(x_p6, cbenv_p7, cmenv_p8, clx_p9)),
        _ => en_p2.clone(),
    }))
}

/// ```prism
/// BundlesOf: unbounded fn Env, Env, Bool -> Env
/// ```
pub fn bundles_of_f(ports_p0: &crate::lower::types::Env, env_p1: &crate::lower::types::Env, build_p2: &bool) -> crate::lower::types::Env {
    crate::prelude::run_to_end(crate::prelude::fold_job(crate::prelude::keys(&ports_p0.names_p), env_p1.clone(), {
        let ports_p0x = ports_p0.clone();
        let build_p2x = *build_p2;
        ::std::rc::Rc::new(move |(p0, p1): (crate::lower::types::Env, crate::prelude::Text)| {
            let ports_p0xy = ports_p0x.clone();
            let build_p2xy = build_p2x;
            crate::prelude::entered(crate::prelude::once_job(move || {
                let en_p3 = p0;
                let k_p4 = p1;
                match crate::prelude::get(&ports_p0xy.names_p, &k_p4) {
                    ::std::option::Option::Some(crate::lower::types::Bn::BnParts(bs_p5)) => ::prism_rtl::Turn::Finished(crate::lower::types::bind_f(&en_p3, &k_p4, &crate::lower::types::Bn::BnParts(if build_p2xy {
                        crate::lower::node_::switch_::parts_at_build_f(&bs_p5)
                    } else {
                        bs_p5.clone()
                    }))),
                    _ => ::prism_rtl::Turn::Finished(en_p3.clone()),
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::types::Env, crate::prelude::Text)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::types::Env>>>
    }))
}

/// ```prism
/// RowReadGetters: unbounded fn Wx, Env, Env, Block -> ((Wx, Env, Env))
/// ```
pub fn row_read_getters_f(wx_p0: &crate::lower::node_::Wx, benv_p1: &crate::lower::types::Env, menv_p2: &crate::lower::types::Env, body_p3: &crate::syntax::Block) -> (crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env) {
    crate::prelude::fold(&crate::lower::node_::switch_::row_names_closed_f(menv_p2, &crate::lower::expr::read_names_f(&crate::check::typed::print::block_exprs_f(body_p3))), &(wx_p0.clone(), benv_p1.clone(), menv_p2.clone()), &(|(w_p4, be_p5, me_p6): &(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), n_p7: &crate::prelude::Text| match (crate::prelude::get(&me_p6.names_p, n_p7), crate::check::env::has_key_f(&me_p6.names_p, &crate::prelude::Text::from(format!("{}#row", n_p7)))) {
        (::std::option::Option::Some(crate::lower::types::Bn::BnDyn(ex_p8, rds_p9, t_pa)), false) => {
            let own_pb = 'm27248: {
                if let crate::lower::model::Ex::XMethod(m27248_0_0, _, _) = &ex_p8 && let crate::lower::model::Ex::XSelf = &**m27248_0_0 {
                    break 'm27248 true;
                }
                crate::lower::node_::switch_::on_self_rooted_f(&ex_p8) && crate::prelude::fold(&rds_p9, &true, &(|f_pc: &bool, rd_pd: &crate::lower::node_::Read| *f_pc && crate::lower::node_::finish::is_own_read_f(rd_pd)))
            };
            if own_pb {
                (w_p4.clone(), be_p5.clone(), me_p6.clone())
            } else {
                {
                    let (getter_pg, w1_ph) = crate::lower::node_::fresh_name_f(w_p4, &crate::prelude::Text::from(format!("through_{}", &crate::lower::snake_f(n_p7))));
                    let w2_pe = {
                        let mut this: crate::lower::node_::Wx = w1_ph.clone();
                        this.getters_p = crate::prelude::push(&this.getters_p, &crate::lower::model::MethDef { name_p: getter_pg.clone(), recv_p: crate::lower::model::Recv::RecvRef, params_p: crate::prelude::Array::new(), cx_p: crate::lower::model::CxArg::CxRef, ret_p: t_pa.clone(), body_p: crate::prelude::Array::new(), tail_p: ex_p8.clone(), doc_p: crate::prelude::Text::from(format!("`{}` of a block around this one, as this block\'s rows read it through it.", n_p7)) });
                        this.dyn_reads_p = crate::prelude::insert(&this.dyn_reads_p, &getter_pg, &rds_p9);
                        this
                    };
                    let b_pf = crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), getter_pg.clone(), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx])), crate::prelude::Array::from(vec![crate::lower::node_::Read::OwnRead(getter_pg.clone())]), t_pa.clone());
                    (w2_pe.clone(), crate::lower::types::bind_f(be_p5, n_p7, &b_pf), crate::lower::types::bind_f(me_p6, n_p7, &b_pf))
                }
            }
        },
        _ => (w_p4.clone(), be_p5.clone(), me_p6.clone()),
    }))
}

/// ```prism
/// BlockReads: fn [Read] -> [Read]
/// ```
pub fn block_reads_f(reads_p0: &crate::prelude::Array<crate::lower::node_::Read>) -> crate::prelude::Array<crate::lower::node_::Read> {
    crate::prelude::fold(reads_p0, &crate::prelude::Array::new(), &(|acc_p1: &crate::prelude::Array<crate::lower::node_::Read>, r_p2: &crate::lower::node_::Read| match r_p2 {
        crate::lower::node_::Read::ParentRead(f_p3) => crate::lower::node_::add_read_f(acc_p1, &crate::lower::node_::Read::OwnRead(f_p3.clone())),
        crate::lower::node_::Read::OwnRead(_) => acc_p1.clone(),
    }))
}

/// ```prism
/// RowLocals: unbounded fn Env, Env, Block -> [RowLocal]
/// ```
pub fn row_locals_f(benv_p0: &crate::lower::types::Env, menv_p1: &crate::lower::types::Env, body_p2: &crate::syntax::Block) -> crate::prelude::Array<RowLocal> {
    crate::prelude::fold(&crate::lower::node_::switch_::row_names_closed_f(menv_p1, &crate::lower::expr::read_names_f(&crate::check::typed::print::block_exprs_f(body_p2))), &crate::prelude::Array::new(), &(|acc_p3: &crate::prelude::Array<RowLocal>, n_p4: &crate::prelude::Text| match crate::prelude::get(&menv_p1.names_p, n_p4) {
        ::std::option::Option::Some(crate::lower::types::Bn::BnLocal(rs_p5, mode_p6, t_p7)) => {
            let field_p8 = crate::lower::snake_f(n_p4);
            if (((&field_p8 == &crate::prelude::Text::lit("key")) || (&field_p8 == &crate::prelude::Text::lit("value"))) || (&field_p8 == &crate::prelude::Text::lit("parent"))) || (&field_p8 == &crate::prelude::Text::lit("path")) {
                acc_p3.clone()
            } else {
                crate::prelude::push(acc_p3, &RowLocal { name_p: n_p4.clone(), field_p: field_p8.clone(), ty_p: t_p7.clone(), passed_p: crate::lower::types::own_f(&crate::lower::types::Vl::VlPlace(rs_p5, mode_p6, t_p7.clone())) })
            }
        },
        _ => acc_p3.clone(),
    }))
}

/// ```prism
/// ForEnvs: unbounded fn Env, Env, ?ForBinders, Bn, Bn, Bn, Bn, OutTy -> ((Env, Env))
/// ```
pub fn for_envs_f(benv_p0: &crate::lower::types::Env, menv_p1: &crate::lower::types::Env, binders_o2: &::std::option::Option<crate::syntax::ForBinders>, key_b_p3: &crate::lower::types::Bn, key_m_p4: &crate::lower::types::Bn, val_b_p5: &crate::lower::types::Bn, val_m_p6: &crate::lower::types::Bn, vt_p7: &crate::lower::model::OutTy) -> (crate::lower::types::Env, crate::lower::types::Env) {
    let be0_p8 = crate::lower::types::bind_f(&crate::lower::types::bind_f(benv_p0, &crate::prelude::Text::lit("key"), key_b_p3), &crate::prelude::Text::lit("$_"), val_b_p5);
    let me0_p9 = crate::lower::types::bind_f(&crate::lower::types::bind_f(menv_p1, &crate::prelude::Text::lit("key"), key_m_p4), &crate::prelude::Text::lit("$_"), val_m_p6);
    match binders_o2 {
        ::std::option::Option::None => (be0_p8.clone(), me0_p9.clone()),
        ::std::option::Option::Some(fb_pa) => match &fb_pa.second_o {
            ::std::option::Option::Some(second_pb) => {
                let be1_pc = bind_pat_f(&be0_p8, &fb_pa.first_p, key_b_p3, &crate::lower::model::Ex::XVar(crate::prelude::Text::lit("key")), &local_ty_f(key_b_p3));
                let me1_pd = bind_pat_f(&me0_p9, &fb_pa.first_p, key_m_p4, &crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::lit("key")), &local_ty_f(key_m_p4));
                (bind_pat_f(&be1_pc, second_pb, val_b_p5, &crate::lower::model::Ex::XVar(crate::prelude::Text::lit("value")), vt_p7), bind_pat_f(&me1_pd, second_pb, val_m_p6, &crate::lower::model::Ex::XUnit, vt_p7))
            },
            ::std::option::Option::None => (bind_pat_f(&be0_p8, &fb_pa.first_p, val_b_p5, &crate::lower::model::Ex::XVar(crate::prelude::Text::lit("value")), vt_p7), bind_pat_f(&me0_p9, &fb_pa.first_p, val_m_p6, &crate::lower::model::Ex::XUnit, vt_p7)),
        },
    }
}

/// ```prism
/// LocalTy: fn Bn -> OutTy
/// ```
pub fn local_ty_f(bn0: &crate::lower::types::Bn) -> crate::lower::model::OutTy {
    match bn0 {
        crate::lower::types::Bn::BnLocal(_, _, t_p0) => t_p0.clone(),
        other_p1 => crate::lower::model::OutTy::OutUnit,
    }
}

/// ```prism
/// BindPat: fn Env, Pattern, Bn, Ex, OutTy -> Env
/// ```
pub fn bind_pat_f(env_p0: &crate::lower::types::Env, p_p1: &crate::syntax::Pattern, b_p2: &crate::lower::types::Bn, whole_p3: &crate::lower::model::Ex, t_p4: &crate::lower::model::OutTy) -> crate::lower::types::Env {
    match &*p_p1.kind_p {
        crate::syntax::PatternKind::PName(n_p5) => crate::lower::types::bind_f(env_p0, &crate::check::env::sname_key_f(n_p5), b_p2),
        crate::syntax::PatternKind::PGroup(q_p6) => bind_pat_f(env_p0, &**q_p6, b_p2, whole_p3, t_p4),
        crate::syntax::PatternKind::PTuple(ps_p7) => {
            let ts_p8 = match t_p4 {
                crate::lower::model::OutTy::OutTuple(xs_p9) => xs_p9.clone(),
                _ => crate::prelude::Array::new(),
            };
            crate::prelude::fold(&crate::check::errors::range0_f(&crate::prelude::len(ps_p7)), env_p0, &(|en_pa: &crate::lower::types::Env, i_pb: &crate::prelude::Nat| match crate::prelude::index(ps_p7, i_pb) {
                ::std::option::Option::Some(q_pc) => match &*q_pc.kind_p {
                    crate::syntax::PatternKind::PName(n_pd) => crate::lower::types::bind_f(en_pa, &crate::check::env::sname_key_f(n_pd), &part_bn_f(b_p2, whole_p3, i_pb, &crate::prelude::or(&crate::prelude::index(&ts_p8, i_pb), &crate::lower::model::OutTy::OutUnit))),
                    _ => en_pa.clone(),
                },
                ::std::option::Option::None => en_pa.clone(),
            }))
        },
        _ => env_p0.clone(),
    }
}

/// ```prism
/// PartBn: fn Bn, Ex, Nat, OutTy -> Bn
/// ```
pub fn part_bn_f(bn0: &crate::lower::types::Bn, whole_p2: &crate::lower::model::Ex, i_p3: &crate::prelude::Nat, t_p4: &crate::lower::model::OutTy) -> crate::lower::types::Bn {
    match bn0 {
        crate::lower::types::Bn::BnDyn(x_p0, rds_p1, _) => crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XPart(::std::rc::Rc::new(x_p0.clone()), i_p3.clone()), rds_p1.clone(), t_p4.clone()),
        other_p5 => crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XPart(::std::rc::Rc::new(whole_p2.clone()), i_p3.clone()), crate::lower::types::Holding::Owned, t_p4.clone()),
    }
}

/// ```prism
/// RowSuffix: fn Wx -> Text
/// ```
pub fn row_suffix_f(wx_p0: &crate::lower::node_::Wx) -> crate::prelude::Text {
    let n_p1 = &crate::prelude::len(&wx_p0.rows_p) + &crate::prelude::len(&wx_p0.pending_p);
    if &n_p1 == &crate::prelude::Nat::from(0u32) {
        crate::prelude::Text::lit("")
    } else {
        crate::prelude::Text::from(format!("{}", &n_p1))
    }
}

/// ```prism
/// GnTyNamed: fn Wx, Text -> OutTy
/// ```
pub fn gn_ty_named_f(wx_p0: &crate::lower::node_::Wx, n_p1: &crate::prelude::Text) -> crate::lower::model::OutTy {
    crate::prelude::fold(&wx_p0.gns_p, &crate::lower::model::OutTy::OutUnit, &(|acc_p2: &crate::lower::model::OutTy, g_p3: &crate::lower::node_::Gn| if &g_p3.name_p == n_p1 { g_p3.ty_p.clone() } else { acc_p2.clone() }))
}
