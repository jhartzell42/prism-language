//! The module `Lower.Node.Def`, from `target/bootstrap/src/prismc/lower/node/def.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file. The runtime
//! side is reached from the crate, `crate::prelude` (and through it `::prism_rtl`), the
//! standard library from `::std`, and nothing is imported by name: a program's own type
//! (`Row`, `Option`) hides none of theirs. The traits are in scope unnamed, for their methods.

use crate::prelude::traits::*;

/// `HowBound`:
///
/// ```prism
/// type HowBound = choice:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub enum HowBound {
    AsHold,
    AsBind,
    AsLet,
    AsResult,
    AsLateHold,
    AsLatePlace,
}

impl crate::prelude::Show for HowBound {
    fn show(&self, p: &mut crate::prelude::Printer) {
        match self {
            HowBound::AsHold => p.choice("AsHold", &[]),
            HowBound::AsBind => p.choice("AsBind", &[]),
            HowBound::AsLet => p.choice("AsLet", &[]),
            HowBound::AsResult => p.choice("AsResult", &[]),
            HowBound::AsLateHold => p.choice("AsLateHold", &[]),
            HowBound::AsLatePlace => p.choice("AsLatePlace", &[]),
        }
    }
}

impl crate::prelude::ToPod for HowBound {
    fn to_pod(&self) -> crate::prelude::Pod {
        match self {
            HowBound::AsHold => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("AsHold", 0), vec![]),
            HowBound::AsBind => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("AsBind", 1), vec![]),
            HowBound::AsLet => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("AsLet", 2), vec![]),
            HowBound::AsResult => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("AsResult", 3), vec![]),
            HowBound::AsLateHold => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("AsLateHold", 4), vec![]),
            HowBound::AsLatePlace => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("AsLatePlace", 5), vec![]),
        }
    }
}

impl crate::prelude::FromPod for HowBound {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        match p.structure() {
            crate::prelude::Pod::Choice(c, a) if &**c == "AsHold" && a.len() == 0 => ::std::result::Result::Ok(HowBound::AsHold),
            crate::prelude::Pod::Choice(c, a) if &**c == "AsBind" && a.len() == 0 => ::std::result::Result::Ok(HowBound::AsBind),
            crate::prelude::Pod::Choice(c, a) if &**c == "AsLet" && a.len() == 0 => ::std::result::Result::Ok(HowBound::AsLet),
            crate::prelude::Pod::Choice(c, a) if &**c == "AsResult" && a.len() == 0 => ::std::result::Result::Ok(HowBound::AsResult),
            crate::prelude::Pod::Choice(c, a) if &**c == "AsLateHold" && a.len() == 0 => ::std::result::Result::Ok(HowBound::AsLateHold),
            crate::prelude::Pod::Choice(c, a) if &**c == "AsLatePlace" && a.len() == 0 => ::std::result::Result::Ok(HowBound::AsLatePlace),
            other => ::prism_rtl::pod::mismatch("a HowBound", other),
        }
    }
}

/// `LateName`:
///
/// ```prism
/// type LateName = record:
/// ```
#[derive(::std::clone::Clone)]
pub struct LateName {
    pub getter_p: crate::prelude::Text,
    pub part_o: ::std::option::Option<crate::prelude::Nat>,
    pub ty_p: crate::lower::model::OutTy,
    pub name_p: crate::prelude::Text,
    pub within_o: ::std::option::Option<(crate::syntax::Pattern, crate::check::types::Ty)>,
}

impl crate::prelude::ToPod for LateName {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("LateName", vec![("getter", self.getter_p.to_pod()), ("part", self.part_o.to_pod()), ("ty", self.ty_p.to_pod()), ("name", self.name_p.to_pod()), ("within", self.within_o.to_pod())])
    }
}

impl crate::prelude::FromPod for LateName {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(LateName { getter_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "getter")?)?, part_o: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "part")?)?, ty_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "ty")?)?, name_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "name")?)?, within_o: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "within")?)? })
    }
}

/// ```prism
/// NodeDefOf: unbounded fn Lx, Text, [Pattern], Block, Scheme, Bool -> NodeDef
/// ```
pub fn node_def_of_f(lx_p0: &crate::lower::Lx, qk_p1: &crate::prelude::Text, params_p2: &crate::prelude::Array<crate::syntax::Pattern>, body_p3: &crate::syntax::Block, sc_p4: &crate::check::types::Scheme, is_root_p5: &bool) -> crate::lower::model::NodeDef {
    let name_p6 = crate::lower::node_name_f(qk_p1);
    let ptys_p7 = match &sc_p4.ty_p {
        crate::check::types::Ty::TyFn(_, ps_pb, _) => ps_pb.clone(),
        _ => crate::prelude::Array::new(),
    };
    let wx0_p8 = crate::lower::node_::new_wx_f(lx_p0, &name_p6, &crate::prelude::Array::new(), &crate::prelude::Array::new(), &crate::prelude::Array::new(), &crate::prelude::Array::new(), &crate::prelude::Map::new(), &crate::lower::node_::node_hooks_p(), &crate::prelude::Array::new(), &::std::option::Option::None);
    let (ps_pq, wx1_pr, benv_ps, menv_pt) = crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(params_p2)), (crate::prelude::Array::new(), wx0_p8.clone(), crate::lower::types::empty_env_p(), crate::lower::types::empty_env_p()), {
        let params_p2x = params_p2.clone();
        let lx_p0x = lx_p0.clone();
        let ptys_p7x = ptys_p7.clone();
        ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Array<(crate::prelude::Text, crate::lower::model::OutTy)>, crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::prelude::Nat)| {
            let params_p2xy = params_p2x.clone();
            let lx_p0xy = lx_p0x.clone();
            let ptys_p7xy = ptys_p7x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (acc_pc, w_pd, be_pe, me_pf) = p0;
                let i_pg = p1;
                {
                    let p_ph = crate::prelude::or(&crate::prelude::index(&params_p2xy, &i_pg), &crate::lower::patterns::dummy_pat_p());
                    let nkey_pi = crate::lower::functions::plain_binder_f(&lx_p0xy, &p_ph);
                    let acc_pcz = acc_pc.clone();
                    let be_pez = be_pe.clone();
                    let i_pgz = i_pg.clone();
                    let lx_p0xyz = lx_p0xy.clone();
                    let me_pfz = me_pf.clone();
                    let nkey_piz = nkey_pi.clone();
                    let ptys_p7xyz = ptys_p7xy.clone();
                    let w_pdz = w_pd.clone();
                    let k_let1856 = move |v1856: crate::prelude::Text| {
                        let base_pj = v1856;
                        let (rs_pm, w2_pn) = crate::lower::node_::fresh_name_f(&w_pdz, &base_pj);
                        crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0xyz.clone(), crate::lower::types::peel_f(&crate::prelude::or(&crate::prelude::index(&ptys_p7xyz, &i_pgz), &crate::check::types::Ty::TyErr))), move |out_ty_of_f_1985: crate::lower::model::OutTy| {
                            let t_pk = out_ty_of_f_1985;
                            let w3_pl = {
                                let mut this: crate::lower::node_::Wx = w2_pn.clone();
                                this.fields_p = crate::prelude::push(&this.fields_p, &(rs_pm.clone(), t_pk.clone(), crate::prelude::Text::lit("a parameter")));
                                this.inits_p = crate::prelude::push(&this.inits_p, &(rs_pm.clone(), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(rs_pm.clone())))));
                                this
                            };
                            let (be2_po, me2_pp) = crate::lower::node_::bind_plain_f(&be_pez, &me_pfz, &nkey_piz, &rs_pm, &t_pk);
                            ::prism_rtl::Turn::Finished((crate::prelude::push(&acc_pcz, &(rs_pm.clone(), t_pk.clone())), w3_pl.clone(), be2_po.clone(), me2_pp.clone()))
                        })
                    };
                    if &nkey_pi == &crate::prelude::Text::lit("") {
                        k_let1856(crate::prelude::Text::from(format!("arg{}", &i_pg)))
                    } else {
                        crate::prelude::call_then(crate::lower::start_local_name_at_f(lx_p0xy.clone(), nkey_pi.clone(), p_ph.span_p.clone()), move |local_name_at_f_1897: crate::prelude::Text| k_let1856(local_name_at_f_1897))
                    }
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Array<(crate::prelude::Text, crate::lower::model::OutTy)>, crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<(crate::prelude::Text, crate::lower::model::OutTy)>, crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>>>
    }));
    let wx2_p9 = block_into_f(&wx1_pr, &benv_ps, &menv_pt, body_p3);
    let wx3_pa = if *is_root_p5 { root_result_f(&wx2_p9) } else { wx2_p9.clone() };
    crate::lower::node_::finish::finish_node_f(&wx3_pa, qk_p1, &ps_pq, &false)
}

/// The step machine of `NodeDefOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// NodeDefOf: unbounded fn Lx, Text, [Pattern], Block, Scheme, Bool -> NodeDef
/// ```
pub struct NodeDefOf {
    pub lx_p0: crate::lower::Lx,
    pub qk_p1: crate::prelude::Text,
    pub params_p2: crate::prelude::Array<crate::syntax::Pattern>,
    pub body_p3: crate::syntax::Block,
    pub sc_p4: crate::check::types::Scheme,
    pub is_root_p5: bool,
}

impl ::prism_rtl::Job<crate::lower::model::NodeDef> for NodeDefOf {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::lower::model::NodeDef> {
        let lx_p0 = &self.lx_p0;
        let qk_p1 = &self.qk_p1;
        let params_p2 = &self.params_p2;
        let body_p3 = &self.body_p3;
        let sc_p4 = &self.sc_p4;
        let is_root_p5 = &self.is_root_p5;
        let name_p6 = crate::lower::node_name_f(qk_p1);
        let ptys_p7 = match &sc_p4.ty_p {
            crate::check::types::Ty::TyFn(_, ps_pb, _) => ps_pb.clone(),
            _ => crate::prelude::Array::new(),
        };
        let wx0_p8 = crate::lower::node_::new_wx_f(lx_p0, &name_p6, &crate::prelude::Array::new(), &crate::prelude::Array::new(), &crate::prelude::Array::new(), &crate::prelude::Array::new(), &crate::prelude::Map::new(), &crate::lower::node_::node_hooks_p(), &crate::prelude::Array::new(), &::std::option::Option::None);
        let body_p3x = body_p3.clone();
        let is_root_p5x = *is_root_p5;
        let lx_p0x = lx_p0.clone();
        let params_p2x = params_p2.clone();
        let qk_p1x = qk_p1.clone();
        crate::prelude::call_value(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(&params_p2x)), (crate::prelude::Array::new(), wx0_p8.clone(), crate::lower::types::empty_env_p(), crate::lower::types::empty_env_p()), {
            let params_p2xx = params_p2x.clone();
            let lx_p0xx = lx_p0x.clone();
            let ptys_p7x = ptys_p7.clone();
            ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Array<(crate::prelude::Text, crate::lower::model::OutTy)>, crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::prelude::Nat)| {
                let params_p2xxy = params_p2xx.clone();
                let lx_p0xxy = lx_p0xx.clone();
                let ptys_p7xy = ptys_p7x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let (acc_pc, w_pd, be_pe, me_pf) = p0;
                    let i_pg = p1;
                    {
                        let p_ph = crate::prelude::or(&crate::prelude::index(&params_p2xxy, &i_pg), &crate::lower::patterns::dummy_pat_p());
                        let nkey_pi = crate::lower::functions::plain_binder_f(&lx_p0xxy, &p_ph);
                        let acc_pcz = acc_pc.clone();
                        let be_pez = be_pe.clone();
                        let i_pgz = i_pg.clone();
                        let lx_p0xxyz = lx_p0xxy.clone();
                        let me_pfz = me_pf.clone();
                        let nkey_piz = nkey_pi.clone();
                        let ptys_p7xyz = ptys_p7xy.clone();
                        let w_pdz = w_pd.clone();
                        let k_let1856 = move |v1856: crate::prelude::Text| {
                            let base_pj = v1856;
                            let (rs_pm, w2_pn) = crate::lower::node_::fresh_name_f(&w_pdz, &base_pj);
                            crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0xxyz.clone(), crate::lower::types::peel_f(&crate::prelude::or(&crate::prelude::index(&ptys_p7xyz, &i_pgz), &crate::check::types::Ty::TyErr))), move |out_ty_of_f_1985: crate::lower::model::OutTy| {
                                let t_pk = out_ty_of_f_1985;
                                let w3_pl = {
                                    let mut this: crate::lower::node_::Wx = w2_pn.clone();
                                    this.fields_p = crate::prelude::push(&this.fields_p, &(rs_pm.clone(), t_pk.clone(), crate::prelude::Text::lit("a parameter")));
                                    this.inits_p = crate::prelude::push(&this.inits_p, &(rs_pm.clone(), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(rs_pm.clone())))));
                                    this
                                };
                                let (be2_po, me2_pp) = crate::lower::node_::bind_plain_f(&be_pez, &me_pfz, &nkey_piz, &rs_pm, &t_pk);
                                ::prism_rtl::Turn::Finished((crate::prelude::push(&acc_pcz, &(rs_pm.clone(), t_pk.clone())), w3_pl.clone(), be2_po.clone(), me2_pp.clone()))
                            })
                        };
                        if &nkey_pi == &crate::prelude::Text::lit("") {
                            k_let1856(crate::prelude::Text::from(format!("arg{}", &i_pg)))
                        } else {
                            crate::prelude::call_then(crate::lower::start_local_name_at_f(lx_p0xxy.clone(), nkey_pi.clone(), p_ph.span_p.clone()), move |local_name_at_f_1897: crate::prelude::Text| k_let1856(local_name_at_f_1897))
                        }
                    }
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Array<(crate::prelude::Text, crate::lower::model::OutTy)>, crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<(crate::prelude::Text, crate::lower::model::OutTy)>, crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>>>
        }), move |fold_1684: (crate::prelude::Array<(crate::prelude::Text, crate::lower::model::OutTy)>, crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)| {
            let (ps_pq, wx1_pr, benv_ps, menv_pt) = fold_1684;
            crate::prelude::call_then(start_block_into_f(wx1_pr.clone(), benv_ps.clone(), menv_pt.clone(), body_p3x.clone()), move |block_into_f_2303: crate::lower::node_::Wx| {
                let wx2_p9 = block_into_f_2303;
                let ps_pqz = ps_pq.clone();
                let qk_p1xz = qk_p1x.clone();
                let k_let2339 = move |v2339: crate::lower::node_::Wx| {
                    let wx3_pa = v2339;
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::lower::node_::finish::FinishNode { wx0_p0: wx3_pa.clone(), qk_p1: qk_p1xz.clone(), params_p2: ps_pqz.clone(), is_row_p3: false }))
                };
                if is_root_p5x {
                    crate::prelude::call_then(start_root_result_f(wx2_p9.clone()), move |root_result_f_2360: crate::lower::node_::Wx| k_let2339(root_result_f_2360))
                } else {
                    k_let2339(wx2_p9.clone())
                }
            })
        })
    }
}

/// `Start NodeDefOf, x`: what the function value is when passed to `@Run`.
pub fn start_node_def_of_f(lx_p0: crate::lower::Lx, qk_p1: crate::prelude::Text, params_p2: crate::prelude::Array<crate::syntax::Pattern>, body_p3: crate::syntax::Block, sc_p4: crate::check::types::Scheme, is_root_p5: bool) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::NodeDef>> {
    ::std::rc::Rc::new(NodeDefOf { lx_p0, qk_p1, params_p2, body_p3, sc_p4, is_root_p5 })
}

/// ```prism
/// OverNode: fn Ex -> Ex
/// ```
pub fn over_node_f(x_p0: &crate::lower::model::Ex) -> crate::lower::model::Ex {
    match x_p0 {
        crate::lower::model::Ex::XSelf => crate::lower::model::Ex::XVar(crate::prelude::Text::lit("node")),
        crate::lower::model::Ex::XField(y_p1, f_p2) => crate::lower::model::Ex::XField(::std::rc::Rc::new(over_node_f(&**y_p1)), f_p2.clone()),
        crate::lower::model::Ex::XMethod(y_p3, m_p4, xs_p5) => crate::lower::model::Ex::XMethod(::std::rc::Rc::new(over_node_f(&**y_p3)), m_p4.clone(), xs_p5.clone()),
        crate::lower::model::Ex::XClone(y_p6) => crate::lower::model::Ex::XClone(::std::rc::Rc::new(over_node_f(&**y_p6))),
        _ => x_p0.clone(),
    }
}

/// ```prism
/// RootResult: unbounded fn Wx -> Wx
/// ```
pub fn root_result_f(wx_p0: &crate::lower::node_::Wx) -> crate::lower::node_::Wx {
    root_result_of_f(wx_p0, &wx_p0.result_p)
}

/// The step machine of `RootResult`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RootResult: unbounded fn Wx -> Wx
/// ```
pub struct RootResult {
    pub wx_p0: crate::lower::node_::Wx,
}

impl ::prism_rtl::Job<crate::lower::node_::Wx> for RootResult {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::lower::node_::Wx> {
        let wx_p0 = &self.wx_p0;
        ::prism_rtl::Turn::More(::std::rc::Rc::new(RootResultOf { wx_p0: wx_p0.clone(), res_p1: wx_p0.result_p.clone() }))
    }
}

/// `Start RootResult, x`: what the function value is when passed to `@Run`.
pub fn start_root_result_f(wx_p0: crate::lower::node_::Wx) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::node_::Wx>> {
    ::std::rc::Rc::new(RootResult { wx_p0 })
}

/// ```prism
/// RootResultOf: unbounded fn Wx, Wres -> Wx
/// ```
pub fn root_result_of_f(wx_p0: &crate::lower::node_::Wx, res_p1: &crate::lower::node_::Wres) -> crate::lower::node_::Wx {
    match res_p1 {
        crate::lower::node_::Wres::WrEv(r_p2) => crate::lower::node_::connect_f(wx_p0, r_p2, &crate::lower::node_::Sk::SkResult),
        crate::lower::node_::Wres::WrDyn(x_p3, rds_p4, t_p5) => {
            let k_p6 = crate::prelude::len(&wx_p0.root_dyns_p);
            {
                let mut this: crate::lower::node_::Wx = wx_p0.clone();
                this.root_dyns_p = crate::prelude::push(&this.root_dyns_p, &(x_p3.clone(), rds_p4.clone(), t_p5.clone()));
                this.taken_p = crate::prelude::append(&this.taken_p, &crate::prelude::Array::from(vec![crate::lower::node_::finish::root_result_stem_f(&crate::prelude::Text::lit("result_value"), &k_p6), crate::lower::node_::finish::root_result_stem_f(&crate::prelude::Text::lit("result_last"), &k_p6)]));
                this.getters_p = crate::prelude::push(&this.getters_p, &crate::lower::model::MethDef { name_p: crate::lower::node_::finish::root_result_stem_f(&crate::prelude::Text::lit("result_value"), &k_p6), recv_p: crate::lower::model::Recv::RecvRef, params_p: crate::prelude::Array::new(), cx_p: crate::lower::model::CxArg::CxRef, ret_p: crate::lower::model::OutTy::OutPod, body_p: crate::prelude::Array::new(), tail_p: crate::lower::model::Ex::XMethod(::std::rc::Rc::new(x_p3.clone()), crate::prelude::Text::lit("to_pod"), crate::prelude::Array::new()), doc_p: crate::prelude::Text::lit("The root\'s dynamic result, pulled after the tick.") });
                this.fields_p = crate::prelude::push(&this.fields_p, &(crate::lower::node_::finish::root_result_stem_f(&crate::prelude::Text::lit("result_last"), &k_p6), crate::lower::model::OutTy::OutCell(::std::rc::Rc::new(crate::lower::model::OutTy::OutOpt(::std::rc::Rc::new(crate::lower::model::OutTy::OutPod)))), crate::prelude::Text::lit("the result the World last heard")));
                this.moves_p = crate::prelude::push(&this.moves_p, &(crate::lower::node_::finish::root_result_stem_f(&crate::prelude::Text::lit("result_last"), &k_p6), crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::RefCell::new")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XNone]))));
                this.build_p = crate::prelude::push(&this.build_p, &crate::lower::model::Do::DoScope(crate::lower::node_::finish::result_told_f(&crate::lower::model::Ex::XVar(crate::prelude::Text::lit("node")), &k_p6)));
                this
            }
        },
        crate::lower::node_::Wres::WrPlain(x_p7, _) => {
            let mut this: crate::lower::node_::Wx = wx_p0.clone();
            this.build_p = crate::prelude::push(&this.build_p, &crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XCx), crate::prelude::Text::lit("result"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Outcome::Value")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XMethod(::std::rc::Rc::new(x_p7.clone()), crate::prelude::Text::lit("to_pod"), crate::prelude::Array::new())]))]))));
            this
        },
        crate::lower::node_::Wres::WrLate(x_p8, _) => {
            let mut this: crate::lower::node_::Wx = wx_p0.clone();
            this.build_p = crate::prelude::push(&this.build_p, &crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XCx), crate::prelude::Text::lit("result"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Outcome::Value")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XMethod(::std::rc::Rc::new(over_node_f(x_p8)), crate::prelude::Text::lit("to_pod"), crate::prelude::Array::new())]))]))));
            this
        },
        crate::lower::node_::Wres::WrParts(parts_p9) => crate::prelude::run_to_end(crate::prelude::fold_job(parts_p9.clone(), wx_p0.clone(), ::std::rc::Rc::new(move |(p0, p1): (crate::lower::node_::Wx, crate::lower::node_::Wres)| crate::prelude::entered(crate::prelude::once_job(move || {
            let w_pa = p0;
            let part_pb = p1;
            ::prism_rtl::Turn::More(::std::rc::Rc::new(RootResultOf { wx_p0: w_pa.clone(), res_p1: part_pb.clone() }))
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::node_::Wx, crate::lower::node_::Wres)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::node_::Wx>>>)),
        _ => wx_p0.clone(),
    }
}

/// The step machine of `RootResultOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RootResultOf: unbounded fn Wx, Wres -> Wx
/// ```
pub struct RootResultOf {
    pub wx_p0: crate::lower::node_::Wx,
    pub res_p1: crate::lower::node_::Wres,
}

impl ::prism_rtl::Job<crate::lower::node_::Wx> for RootResultOf {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::lower::node_::Wx> {
        let wx_p0 = &self.wx_p0;
        let res_p1 = &self.res_p1;
        match res_p1 {
            crate::lower::node_::Wres::WrEv(r_p2) => ::prism_rtl::Turn::Finished(crate::lower::node_::connect_f(wx_p0, r_p2, &crate::lower::node_::Sk::SkResult)),
            crate::lower::node_::Wres::WrDyn(x_p3, rds_p4, t_p5) => {
                let k_p6 = crate::prelude::len(&wx_p0.root_dyns_p);
                ::prism_rtl::Turn::Finished({
                    let mut this: crate::lower::node_::Wx = wx_p0.clone();
                    this.root_dyns_p = crate::prelude::push(&this.root_dyns_p, &(x_p3.clone(), rds_p4.clone(), t_p5.clone()));
                    this.taken_p = crate::prelude::append(&this.taken_p, &crate::prelude::Array::from(vec![crate::lower::node_::finish::root_result_stem_f(&crate::prelude::Text::lit("result_value"), &k_p6), crate::lower::node_::finish::root_result_stem_f(&crate::prelude::Text::lit("result_last"), &k_p6)]));
                    this.getters_p = crate::prelude::push(&this.getters_p, &crate::lower::model::MethDef { name_p: crate::lower::node_::finish::root_result_stem_f(&crate::prelude::Text::lit("result_value"), &k_p6), recv_p: crate::lower::model::Recv::RecvRef, params_p: crate::prelude::Array::new(), cx_p: crate::lower::model::CxArg::CxRef, ret_p: crate::lower::model::OutTy::OutPod, body_p: crate::prelude::Array::new(), tail_p: crate::lower::model::Ex::XMethod(::std::rc::Rc::new(x_p3.clone()), crate::prelude::Text::lit("to_pod"), crate::prelude::Array::new()), doc_p: crate::prelude::Text::lit("The root\'s dynamic result, pulled after the tick.") });
                    this.fields_p = crate::prelude::push(&this.fields_p, &(crate::lower::node_::finish::root_result_stem_f(&crate::prelude::Text::lit("result_last"), &k_p6), crate::lower::model::OutTy::OutCell(::std::rc::Rc::new(crate::lower::model::OutTy::OutOpt(::std::rc::Rc::new(crate::lower::model::OutTy::OutPod)))), crate::prelude::Text::lit("the result the World last heard")));
                    this.moves_p = crate::prelude::push(&this.moves_p, &(crate::lower::node_::finish::root_result_stem_f(&crate::prelude::Text::lit("result_last"), &k_p6), crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::RefCell::new")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XNone]))));
                    this.build_p = crate::prelude::push(&this.build_p, &crate::lower::model::Do::DoScope(crate::lower::node_::finish::result_told_f(&crate::lower::model::Ex::XVar(crate::prelude::Text::lit("node")), &k_p6)));
                    this
                })
            },
            crate::lower::node_::Wres::WrPlain(x_p7, _) => ::prism_rtl::Turn::Finished({
                let mut this: crate::lower::node_::Wx = wx_p0.clone();
                this.build_p = crate::prelude::push(&this.build_p, &crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XCx), crate::prelude::Text::lit("result"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Outcome::Value")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XMethod(::std::rc::Rc::new(x_p7.clone()), crate::prelude::Text::lit("to_pod"), crate::prelude::Array::new())]))]))));
                this
            }),
            crate::lower::node_::Wres::WrLate(x_p8, _) => ::prism_rtl::Turn::Finished({
                let mut this: crate::lower::node_::Wx = wx_p0.clone();
                this.build_p = crate::prelude::push(&this.build_p, &crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XCx), crate::prelude::Text::lit("result"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Outcome::Value")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XMethod(::std::rc::Rc::new(over_node_f(x_p8)), crate::prelude::Text::lit("to_pod"), crate::prelude::Array::new())]))]))));
                this
            }),
            crate::lower::node_::Wres::WrParts(parts_p9) => crate::prelude::fold_job(parts_p9.clone(), wx_p0.clone(), ::std::rc::Rc::new(move |(p0, p1): (crate::lower::node_::Wx, crate::lower::node_::Wres)| crate::prelude::entered(crate::prelude::once_job(move || {
                let w_pa = p0;
                let part_pb = p1;
                ::prism_rtl::Turn::More(::std::rc::Rc::new(RootResultOf { wx_p0: w_pa.clone(), res_p1: part_pb.clone() }))
            }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::node_::Wx, crate::lower::node_::Wres)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::node_::Wx>>>).cycle(),
            _ => ::prism_rtl::Turn::Finished(wx_p0.clone()),
        }
    }
}

/// `Start RootResultOf, x`: what the function value is when passed to `@Run`.
pub fn start_root_result_of_f(wx_p0: crate::lower::node_::Wx, res_p1: crate::lower::node_::Wres) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::node_::Wx>> {
    ::std::rc::Rc::new(RootResultOf { wx_p0, res_p1 })
}

/// ```prism
/// BlockInto: unbounded fn Wx, Env, Env, Block -> Wx
/// ```
pub fn block_into_f(wx_p0: &crate::lower::node_::Wx, benv0_p1: &crate::lower::types::Env, menv0_p2: &crate::lower::types::Env, b_p3: &crate::syntax::Block) -> crate::lower::node_::Wx {
    let (benv_p6, menv_p7) = with_element_lets_f(&wx_p0.lx_p, benv0_p1, menv0_p2, b_p3);
    let env_p4 = with_local_widgets_f(&menv_p7, b_p3);
    let wxe_p5 = {
        let mut this: crate::lower::node_::Wx = wx_p0.clone();
        this.early_choices_p = crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(&b_p3.stmts_p)), this.early_choices_p.clone(), {
            let wx_p0x = wx_p0.clone();
            let env_p4x = env_p4.clone();
            let b_p3x = b_p3.clone();
            ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::prelude::Nat)| {
                let wx_p0xy = wx_p0x.clone();
                let env_p4xy = env_p4x.clone();
                let b_p3xy = b_p3x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let acc_p8 = p0;
                    let i_p9 = p1;
                    crate::prelude::call_then(start_is_early_choice_at_f(wx_p0xy.lx_p.clone(), env_p4xy.clone(), b_p3xy.clone(), i_p9.clone()), move |is_early_choice_at_f_5567: bool| if is_early_choice_at_f_5567 {
                        ::prism_rtl::Turn::Finished(crate::check::types::add_text_f(&acc_p8, &early_choice_key_f(&crate::prelude::or(&crate::prelude::index(&b_p3xy.stmts_p, &i_p9), &crate::lower::expr::dummy_stmt_l_p()))))
                    } else {
                        crate::prelude::call_then(start_is_pure_choice_at_f(wx_p0xy.lx_p.clone(), env_p4xy.clone(), b_p3xy.clone(), i_p9.clone(), crate::prelude::Nat::from(16u32)), move |is_pure_choice_at_f_5668: bool| if is_pure_choice_at_f_5668 {
                            ::prism_rtl::Turn::Finished(crate::check::types::add_text_f(&acc_p8, &pure_choice_stmt_key_f(&crate::prelude::or(&crate::prelude::index(&b_p3xy.stmts_p, &i_p9), &crate::lower::expr::dummy_stmt_l_p()))))
                        } else {
                            ::prism_rtl::Turn::Finished(acc_p8.clone())
                        })
                    })
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>
        }));
        this
    };
    match earlier_line_o(&late_line_at_o(&wx_p0.lx_p, &menv_p7, b_p3, &crate::prelude::Nat::from(16u32)), &late_place_taker_at_o(wx_p0, b_p3)) {
        ::std::option::Option::Some(k_pa) => split_block_into_f(&wxe_p5, &benv_p6, &menv_p7, b_p3, &k_pa),
        ::std::option::Option::None => {
            let (wx2_pb, _, _) = lines_into_f(&wxe_p5, &benv_p6, &menv_p7, b_p3, &false);
            wx2_pb.clone()
        },
    }
}

/// The step machine of `BlockInto`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BlockInto: unbounded fn Wx, Env, Env, Block -> Wx
/// ```
pub struct BlockInto {
    pub wx_p0: crate::lower::node_::Wx,
    pub benv0_p1: crate::lower::types::Env,
    pub menv0_p2: crate::lower::types::Env,
    pub b_p3: crate::syntax::Block,
}

impl ::prism_rtl::Job<crate::lower::node_::Wx> for BlockInto {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::lower::node_::Wx> {
        let wx_p0 = &self.wx_p0;
        let benv0_p1 = &self.benv0_p1;
        let menv0_p2 = &self.menv0_p2;
        let b_p3 = &self.b_p3;
        let b_p3x = b_p3.clone();
        let benv0_p1x = benv0_p1.clone();
        let menv0_p2x = menv0_p2.clone();
        let wx_p0x = wx_p0.clone();
        crate::prelude::call_then(start_with_element_lets_f(wx_p0x.lx_p.clone(), benv0_p1x.clone(), menv0_p2x.clone(), b_p3x.clone()), move |with_element_lets_f_5378: (crate::lower::types::Env, crate::lower::types::Env)| {
            let (benv_p6, menv_p7) = with_element_lets_f_5378;
            let env_p4 = with_local_widgets_f(&menv_p7, &b_p3x);
            let wxe_p5 = {
                let mut this: crate::lower::node_::Wx = wx_p0x.clone();
                this.early_choices_p = crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(&b_p3x.stmts_p)), this.early_choices_p.clone(), {
                    let wx_p0xx = wx_p0x.clone();
                    let env_p4x = env_p4.clone();
                    let b_p3xx = b_p3x.clone();
                    ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::prelude::Nat)| {
                        let wx_p0xxy = wx_p0xx.clone();
                        let env_p4xy = env_p4x.clone();
                        let b_p3xxy = b_p3xx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let acc_p8 = p0;
                            let i_p9 = p1;
                            crate::prelude::call_then(start_is_early_choice_at_f(wx_p0xxy.lx_p.clone(), env_p4xy.clone(), b_p3xxy.clone(), i_p9.clone()), move |is_early_choice_at_f_5567: bool| if is_early_choice_at_f_5567 {
                                ::prism_rtl::Turn::Finished(crate::check::types::add_text_f(&acc_p8, &early_choice_key_f(&crate::prelude::or(&crate::prelude::index(&b_p3xxy.stmts_p, &i_p9), &crate::lower::expr::dummy_stmt_l_p()))))
                            } else {
                                crate::prelude::call_then(start_is_pure_choice_at_f(wx_p0xxy.lx_p.clone(), env_p4xy.clone(), b_p3xxy.clone(), i_p9.clone(), crate::prelude::Nat::from(16u32)), move |is_pure_choice_at_f_5668: bool| if is_pure_choice_at_f_5668 {
                                    ::prism_rtl::Turn::Finished(crate::check::types::add_text_f(&acc_p8, &pure_choice_stmt_key_f(&crate::prelude::or(&crate::prelude::index(&b_p3xxy.stmts_p, &i_p9), &crate::lower::expr::dummy_stmt_l_p()))))
                                } else {
                                    ::prism_rtl::Turn::Finished(acc_p8.clone())
                                })
                            })
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>
                }));
                this
            };
            crate::prelude::call_then(start_late_line_at_o(wx_p0x.lx_p.clone(), menv_p7.clone(), b_p3x.clone(), crate::prelude::Nat::from(16u32)), move |late_line_at_o_5800: ::std::option::Option<crate::prelude::Nat>| crate::prelude::call_then(start_late_place_taker_at_o(wx_p0x.clone(), b_p3x.clone()), move |late_place_taker_at_o_5834: ::std::option::Option<crate::prelude::Nat>| match earlier_line_o(&late_line_at_o_5800, &late_place_taker_at_o_5834) {
                ::std::option::Option::Some(k_pa) => ::prism_rtl::Turn::More(::std::rc::Rc::new(SplitBlockInto { wx00_p0: wxe_p5.clone(), benv00_p1: benv_p6.clone(), menv00_p2: menv_p7.clone(), b_p3: b_p3x.clone(), k_p4: k_pa.clone() })),
                ::std::option::Option::None => crate::prelude::call_then(start_lines_into_f(wxe_p5.clone(), benv_p6.clone(), menv_p7.clone(), b_p3x.clone(), false), move |lines_into_f_5965: (crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)| {
                    let (wx2_pb, _, _) = lines_into_f_5965;
                    ::prism_rtl::Turn::Finished(wx2_pb.clone())
                }),
            }))
        })
    }
}

/// `Start BlockInto, x`: what the function value is when passed to `@Run`.
pub fn start_block_into_f(wx_p0: crate::lower::node_::Wx, benv0_p1: crate::lower::types::Env, menv0_p2: crate::lower::types::Env, b_p3: crate::syntax::Block) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::node_::Wx>> {
    ::std::rc::Rc::new(BlockInto { wx_p0, benv0_p1, menv0_p2, b_p3 })
}

/// ```prism
/// ?EarlierLine: fn ?Nat, ?Nat -> ?Nat
/// ```
pub fn earlier_line_o(opt0: &::std::option::Option<crate::prelude::Nat>, opt1: &::std::option::Option<crate::prelude::Nat>) -> ::std::option::Option<crate::prelude::Nat> {
    match (opt0, opt1) {
        (::std::option::Option::Some(a_p0), ::std::option::Option::Some(b_p1)) => ::std::option::Option::Some(crate::prelude::min(a_p0, b_p1)),
        (::std::option::Option::Some(a_p2), ::std::option::Option::None) => ::std::option::Option::Some(a_p2.clone()),
        (::std::option::Option::None, b_o3) => b_o3.clone(),
    }
}

/// ```prism
/// ?LatePlaceTakerAt: unbounded fn Wx, Block -> ?Nat
/// ```
pub fn late_place_taker_at_o(wx_p0: &crate::lower::node_::Wx, b_p1: &crate::syntax::Block) -> ::std::option::Option<crate::prelude::Nat> {
    if !crate::check::types::has_nat_f(&wx_p0.late_hosts_p, &wx_p0.pos_p.scope_p) {
        ::std::option::Option::None
    } else {
        {
            let lx_p2 = wx_p0.lx_p.clone();
            crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(&b_p1.stmts_p)), ::std::option::Option::None, {
                let b_p1x = b_p1.clone();
                let lx_p2x = lx_p2.clone();
                ::std::rc::Rc::new(move |(p0, p1): (::std::option::Option<crate::prelude::Nat>, crate::prelude::Nat)| {
                    let b_p1xy = b_p1x.clone();
                    let lx_p2xy = lx_p2x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let found_o3 = p0;
                        let i_p4 = p1;
                        match &found_o3 {
                            ::std::option::Option::Some(k_p5) => ::prism_rtl::Turn::Finished(::std::option::Option::Some(k_p5.clone())),
                            ::std::option::Option::None => {
                                let above_p6 = crate::prelude::take(&b_p1xy.stmts_p, &i_p4);
                                crate::prelude::call_value(crate::prelude::fold_job(above_p6.clone(), crate::prelude::Array::new(), {
                                    let lx_p2xyx = lx_p2xy.clone();
                                    ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::syntax::Stmt)| {
                                        let lx_p2xyxy = lx_p2xyx.clone();
                                        crate::prelude::entered(crate::prelude::once_job(move || {
                                            let acc_p9 = p0;
                                            let st_pa = p1;
                                            match &st_pa.kind_p {
                                                crate::syntax::StmtKind::SBind(whole_pb, init_pc, ::std::option::Option::None) => if !is_bundle_place_f(&lx_p2xyxy, init_pc) {
                                                    ::prism_rtl::Turn::Finished(acc_p9.clone())
                                                } else {
                                                    crate::prelude::fold_job(tuple_parts_f(whole_pb), acc_p9.clone(), {
                                                        let lx_p2xyxyx = lx_p2xyxy.clone();
                                                        ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::syntax::Pattern)| {
                                                            let lx_p2xyxyxy = lx_p2xyxyx.clone();
                                                            crate::prelude::entered(crate::prelude::once_job(move || {
                                                                let acc2_pd = p0;
                                                                let q_pe = p1;
                                                                match &*q_pe.kind_p {
                                                                    crate::syntax::PatternKind::PName(n_pf) => {
                                                                        let n_pfx = n_pf.clone();
                                                                        crate::prelude::call_then(crate::lower::expr::start_widget_let_lx_f(lx_p2xyxyxy.clone(), n_pfx.span_p.clone()), move |widget_let_lx_f_7437: crate::lower::Lx| {
                                                                            let full_pg = crate::lower::binder_ty_f(&widget_let_lx_f_7437, &n_pfx.span_p);
                                                                            if ((is_time_name_f(&crate::check::env::sname_key_f(&n_pfx)) || (&crate::lower::types::layer_of_f(&full_pg) != &crate::lower::types::Layer::LyPlain)) || crate::lower::types::time_within_f(&full_pg)) || crate::lower::types::is_bundle_f(&full_pg) {
                                                                                ::prism_rtl::Turn::Finished(acc2_pd.clone())
                                                                            } else {
                                                                                ::prism_rtl::Turn::Finished(crate::check::types::add_text_f(&acc2_pd, &crate::check::env::sname_key_f(&n_pfx)))
                                                                            }
                                                                        })
                                                                    },
                                                                    _ => ::prism_rtl::Turn::Finished(acc2_pd.clone()),
                                                                }
                                                            }))
                                                        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::syntax::Pattern)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>
                                                    }).cycle()
                                                },
                                                _ => ::prism_rtl::Turn::Finished(acc_p9.clone()),
                                            }
                                        }))
                                    }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::syntax::Stmt)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>
                                }), move |fold_7181: crate::prelude::Array<crate::prelude::Text>| {
                                    let parts_p7 = fold_7181;
                                    crate::prelude::call_value(crate::prelude::fold_job(above_p6.clone(), parts_p7.clone(), {
                                        let above_p6x = above_p6.clone();
                                        ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::syntax::Stmt)| {
                                            let above_p6xy = above_p6x.clone();
                                            crate::prelude::entered(crate::prelude::once_job(move || {
                                                let acc_ph = p0;
                                                let _ = p1;
                                                crate::prelude::fold_job(above_p6xy.clone(), acc_ph.clone(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::syntax::Stmt)| crate::prelude::entered(crate::prelude::once_job(move || {
                                                    let acc2_pi = p0;
                                                    let st_pj = p1;
                                                    match &st_pj.kind_p {
                                                        crate::syntax::StmtKind::SLet(q_pk, _, x_pl) => {
                                                            let q_pkx = q_pk.clone();
                                                            let x_plx = x_pl.clone();
                                                            crate::prelude::call_then(crate::check::typed::print::start_exprs_in_f(x_plx.clone()), move |exprs_in_f_7859: crate::prelude::Array<crate::syntax::Expr>| crate::prelude::call_then(crate::lower::expr::start_free_reads_f(exprs_in_f_7859, crate::prelude::Array::new()), move |free_reads_f_7848: crate::prelude::Array<crate::prelude::Text>| if &crate::prelude::len(&crate::prelude::filter(&free_reads_f_7848, &(|n_pm: &crate::prelude::Text| crate::check::types::has_text_f(&acc2_pi, n_pm)))) > &crate::prelude::Nat::from(0u32) {
                                                                crate::prelude::call_then(crate::check::env::names::start_pattern_names_f(q_pkx.clone()), move |pattern_names_f_7924: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc2_pi, &pattern_names_f_7924)))
                                                            } else {
                                                                ::prism_rtl::Turn::Finished(acc2_pi.clone())
                                                            }))
                                                        },
                                                        _ => ::prism_rtl::Turn::Finished(acc2_pi.clone()),
                                                    }
                                                }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::syntax::Stmt)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>).cycle()
                                            }))
                                        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::syntax::Stmt)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>
                                    }), move |fold_7718: crate::prelude::Array<crate::prelude::Text>| {
                                        let late_p8 = fold_7718;
                                        match &crate::prelude::or(&crate::prelude::index(&b_p1xy.stmts_p, &i_p4), &crate::lower::expr::dummy_stmt_l_p()).kind_p {
                                            crate::syntax::StmtKind::SBind(q_pn, e_po, ::std::option::Option::None) => {
                                                let e_pox = e_po.clone();
                                                let q_pnx = q_pn.clone();
                                                crate::prelude::call_then(crate::check::env::names::start_pattern_names_f(q_pnx.clone()), move |pattern_names_f_8114: crate::prelude::Array<crate::prelude::Text>| {
                                                    let binds_pp = &crate::prelude::len(&crate::prelude::filter(&pattern_names_f_8114, &(|n_ps: &crate::prelude::Text| !is_time_name_f(n_ps)))) > &crate::prelude::Nat::from(0u32);
                                                    let placed_pq = match crate::lower::types::peel_f(&crate::lower::type_at_f(&lx_p2xy, &e_pox.span_p)) {
                                                        crate::check::types::Ty::TyElem(_, _) => true,
                                                        _ => false,
                                                    };
                                                    crate::prelude::call_then(crate::check::typed::print::start_exprs_in_f(e_pox.clone()), move |exprs_in_f_8376: crate::prelude::Array<crate::syntax::Expr>| crate::prelude::call_then(crate::lower::expr::start_free_reads_f(exprs_in_f_8376, crate::prelude::Array::new()), move |free_reads_f_8365: crate::prelude::Array<crate::prelude::Text>| {
                                                        let takes_pr = &crate::prelude::len(&crate::prelude::filter(&free_reads_f_8365, &(|n_pt: &crate::prelude::Text| crate::check::types::has_text_f(&late_p8, n_pt)))) > &crate::prelude::Nat::from(0u32);
                                                        if ((binds_pp && takes_pr) && !placed_pq) && is_plain_result_f(&lx_p2xy, &e_pox) {
                                                            ::prism_rtl::Turn::Finished(::std::option::Option::Some(i_p4.clone()))
                                                        } else {
                                                            ::prism_rtl::Turn::Finished(::std::option::Option::None)
                                                        }
                                                    }))
                                                })
                                            },
                                            _ => ::prism_rtl::Turn::Finished(::std::option::Option::None),
                                        }
                                    })
                                })
                            },
                        }
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn((::std::option::Option<crate::prelude::Nat>, crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<::std::option::Option<crate::prelude::Nat>>>>
            }))
        }
    }
}

/// The step machine of `LatePlaceTakerAt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?LatePlaceTakerAt: unbounded fn Wx, Block -> ?Nat
/// ```
pub struct LatePlaceTakerAt {
    pub wx_p0: crate::lower::node_::Wx,
    pub b_p1: crate::syntax::Block,
}

impl ::prism_rtl::Job<::std::option::Option<crate::prelude::Nat>> for LatePlaceTakerAt {
    fn cycle(&self) -> ::prism_rtl::Turn<::std::option::Option<crate::prelude::Nat>> {
        let wx_p0 = &self.wx_p0;
        let b_p1 = &self.b_p1;
        if !crate::check::types::has_nat_f(&wx_p0.late_hosts_p, &wx_p0.pos_p.scope_p) {
            ::prism_rtl::Turn::Finished(::std::option::Option::None)
        } else {
            {
                let lx_p2 = wx_p0.lx_p.clone();
                crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(&b_p1.stmts_p)), ::std::option::Option::None, {
                    let b_p1x = b_p1.clone();
                    let lx_p2x = lx_p2.clone();
                    ::std::rc::Rc::new(move |(p0, p1): (::std::option::Option<crate::prelude::Nat>, crate::prelude::Nat)| {
                        let b_p1xy = b_p1x.clone();
                        let lx_p2xy = lx_p2x.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let found_o3 = p0;
                            let i_p4 = p1;
                            match &found_o3 {
                                ::std::option::Option::Some(k_p5) => ::prism_rtl::Turn::Finished(::std::option::Option::Some(k_p5.clone())),
                                ::std::option::Option::None => {
                                    let above_p6 = crate::prelude::take(&b_p1xy.stmts_p, &i_p4);
                                    crate::prelude::call_value(crate::prelude::fold_job(above_p6.clone(), crate::prelude::Array::new(), {
                                        let lx_p2xyx = lx_p2xy.clone();
                                        ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::syntax::Stmt)| {
                                            let lx_p2xyxy = lx_p2xyx.clone();
                                            crate::prelude::entered(crate::prelude::once_job(move || {
                                                let acc_p9 = p0;
                                                let st_pa = p1;
                                                match &st_pa.kind_p {
                                                    crate::syntax::StmtKind::SBind(whole_pb, init_pc, ::std::option::Option::None) => if !is_bundle_place_f(&lx_p2xyxy, init_pc) {
                                                        ::prism_rtl::Turn::Finished(acc_p9.clone())
                                                    } else {
                                                        crate::prelude::fold_job(tuple_parts_f(whole_pb), acc_p9.clone(), {
                                                            let lx_p2xyxyx = lx_p2xyxy.clone();
                                                            ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::syntax::Pattern)| {
                                                                let lx_p2xyxyxy = lx_p2xyxyx.clone();
                                                                crate::prelude::entered(crate::prelude::once_job(move || {
                                                                    let acc2_pd = p0;
                                                                    let q_pe = p1;
                                                                    match &*q_pe.kind_p {
                                                                        crate::syntax::PatternKind::PName(n_pf) => {
                                                                            let n_pfx = n_pf.clone();
                                                                            crate::prelude::call_then(crate::lower::expr::start_widget_let_lx_f(lx_p2xyxyxy.clone(), n_pfx.span_p.clone()), move |widget_let_lx_f_7437: crate::lower::Lx| {
                                                                                let full_pg = crate::lower::binder_ty_f(&widget_let_lx_f_7437, &n_pfx.span_p);
                                                                                if ((is_time_name_f(&crate::check::env::sname_key_f(&n_pfx)) || (&crate::lower::types::layer_of_f(&full_pg) != &crate::lower::types::Layer::LyPlain)) || crate::lower::types::time_within_f(&full_pg)) || crate::lower::types::is_bundle_f(&full_pg) {
                                                                                    ::prism_rtl::Turn::Finished(acc2_pd.clone())
                                                                                } else {
                                                                                    ::prism_rtl::Turn::Finished(crate::check::types::add_text_f(&acc2_pd, &crate::check::env::sname_key_f(&n_pfx)))
                                                                                }
                                                                            })
                                                                        },
                                                                        _ => ::prism_rtl::Turn::Finished(acc2_pd.clone()),
                                                                    }
                                                                }))
                                                            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::syntax::Pattern)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>
                                                        }).cycle()
                                                    },
                                                    _ => ::prism_rtl::Turn::Finished(acc_p9.clone()),
                                                }
                                            }))
                                        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::syntax::Stmt)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>
                                    }), move |fold_7181: crate::prelude::Array<crate::prelude::Text>| {
                                        let parts_p7 = fold_7181;
                                        crate::prelude::call_value(crate::prelude::fold_job(above_p6.clone(), parts_p7.clone(), {
                                            let above_p6x = above_p6.clone();
                                            ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::syntax::Stmt)| {
                                                let above_p6xy = above_p6x.clone();
                                                crate::prelude::entered(crate::prelude::once_job(move || {
                                                    let acc_ph = p0;
                                                    let _ = p1;
                                                    crate::prelude::fold_job(above_p6xy.clone(), acc_ph.clone(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::syntax::Stmt)| crate::prelude::entered(crate::prelude::once_job(move || {
                                                        let acc2_pi = p0;
                                                        let st_pj = p1;
                                                        match &st_pj.kind_p {
                                                            crate::syntax::StmtKind::SLet(q_pk, _, x_pl) => {
                                                                let q_pkx = q_pk.clone();
                                                                let x_plx = x_pl.clone();
                                                                crate::prelude::call_then(crate::check::typed::print::start_exprs_in_f(x_plx.clone()), move |exprs_in_f_7859: crate::prelude::Array<crate::syntax::Expr>| crate::prelude::call_then(crate::lower::expr::start_free_reads_f(exprs_in_f_7859, crate::prelude::Array::new()), move |free_reads_f_7848: crate::prelude::Array<crate::prelude::Text>| if &crate::prelude::len(&crate::prelude::filter(&free_reads_f_7848, &(|n_pm: &crate::prelude::Text| crate::check::types::has_text_f(&acc2_pi, n_pm)))) > &crate::prelude::Nat::from(0u32) {
                                                                    crate::prelude::call_then(crate::check::env::names::start_pattern_names_f(q_pkx.clone()), move |pattern_names_f_7924: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc2_pi, &pattern_names_f_7924)))
                                                                } else {
                                                                    ::prism_rtl::Turn::Finished(acc2_pi.clone())
                                                                }))
                                                            },
                                                            _ => ::prism_rtl::Turn::Finished(acc2_pi.clone()),
                                                        }
                                                    }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::syntax::Stmt)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>).cycle()
                                                }))
                                            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::syntax::Stmt)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>
                                        }), move |fold_7718: crate::prelude::Array<crate::prelude::Text>| {
                                            let late_p8 = fold_7718;
                                            match &crate::prelude::or(&crate::prelude::index(&b_p1xy.stmts_p, &i_p4), &crate::lower::expr::dummy_stmt_l_p()).kind_p {
                                                crate::syntax::StmtKind::SBind(q_pn, e_po, ::std::option::Option::None) => {
                                                    let e_pox = e_po.clone();
                                                    let q_pnx = q_pn.clone();
                                                    crate::prelude::call_then(crate::check::env::names::start_pattern_names_f(q_pnx.clone()), move |pattern_names_f_8114: crate::prelude::Array<crate::prelude::Text>| {
                                                        let binds_pp = &crate::prelude::len(&crate::prelude::filter(&pattern_names_f_8114, &(|n_ps: &crate::prelude::Text| !is_time_name_f(n_ps)))) > &crate::prelude::Nat::from(0u32);
                                                        let placed_pq = match crate::lower::types::peel_f(&crate::lower::type_at_f(&lx_p2xy, &e_pox.span_p)) {
                                                            crate::check::types::Ty::TyElem(_, _) => true,
                                                            _ => false,
                                                        };
                                                        crate::prelude::call_then(crate::check::typed::print::start_exprs_in_f(e_pox.clone()), move |exprs_in_f_8376: crate::prelude::Array<crate::syntax::Expr>| crate::prelude::call_then(crate::lower::expr::start_free_reads_f(exprs_in_f_8376, crate::prelude::Array::new()), move |free_reads_f_8365: crate::prelude::Array<crate::prelude::Text>| {
                                                            let takes_pr = &crate::prelude::len(&crate::prelude::filter(&free_reads_f_8365, &(|n_pt: &crate::prelude::Text| crate::check::types::has_text_f(&late_p8, n_pt)))) > &crate::prelude::Nat::from(0u32);
                                                            if ((binds_pp && takes_pr) && !placed_pq) && is_plain_result_f(&lx_p2xy, &e_pox) {
                                                                ::prism_rtl::Turn::Finished(::std::option::Option::Some(i_p4.clone()))
                                                            } else {
                                                                ::prism_rtl::Turn::Finished(::std::option::Option::None)
                                                            }
                                                        }))
                                                    })
                                                },
                                                _ => ::prism_rtl::Turn::Finished(::std::option::Option::None),
                                            }
                                        })
                                    })
                                },
                            }
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn((::std::option::Option<crate::prelude::Nat>, crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<::std::option::Option<crate::prelude::Nat>>>>
                }).cycle()
            }
        }
    }
}

/// `Start LatePlaceTakerAt, x`: what the function value is when passed to `@Run`.
pub fn start_late_place_taker_at_o(wx_p0: crate::lower::node_::Wx, b_p1: crate::syntax::Block) -> ::std::rc::Rc<dyn ::prism_rtl::Job<::std::option::Option<crate::prelude::Nat>>> {
    ::std::rc::Rc::new(LatePlaceTakerAt { wx_p0, b_p1 })
}

/// ```prism
/// TupleParts: fn Pattern -> [Pattern]
/// ```
pub fn tuple_parts_f(p_p0: &crate::syntax::Pattern) -> crate::prelude::Array<crate::syntax::Pattern> {
    match &*p_p0.kind_p {
        crate::syntax::PatternKind::PTuple(ps_p1) => ps_p1.clone(),
        _ => crate::prelude::Array::new(),
    }
}

/// ```prism
/// IsEarlyChoiceAt: unbounded fn Lx, Env, Block, Nat -> Bool
/// ```
pub fn is_early_choice_at_f(lx_p0: &crate::lower::Lx, menv_p1: &crate::lower::types::Env, b_p2: &crate::syntax::Block, i_p3: &crate::prelude::Nat) -> bool {
    match &crate::prelude::or(&crate::prelude::index(&b_p2.stmts_p, i_p3), &crate::lower::expr::dummy_stmt_l_p()).kind_p {
        crate::syntax::StmtKind::SBind(p_p4, e_p5, ::std::option::Option::None) => match &*crate::lower::node_::static_::ungrouped_f(e_p5).kind_p {
            crate::syntax::ExprKind::EMatch(_, arms_p6) => {
                let names_p7 = crate::prelude::filter(&crate::check::env::names::pattern_names_f(p_p4), &(|n_pd: &crate::prelude::Text| !is_time_name_f(n_pd)));
                let plain_p8 = is_plain_result_f(lx_p0, e_p5) && !crate::lower::types::is_bundle_f(&line_out_full_f(lx_p0, e_p5));
                let unguarded_p9 = crate::prelude::fold(arms_p6, &true, &(|ok_pe: &bool, a_pf: &crate::syntax::Arm| *ok_pe && (&a_pf.guard_o == &::std::option::Option::None)));
                let block_defs_pa = crate::prelude::run_to_end(crate::prelude::fold_job(b_p2.stmts_p.clone(), crate::prelude::Array::new(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::syntax::Stmt)| crate::prelude::entered(crate::prelude::once_job(move || {
                    let acc_pg = p0;
                    let st_ph = p1;
                    crate::prelude::call_then(crate::check::blocks::start_group_defs_f(st_ph.clone()), move |group_defs_f_9885: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_pg, &group_defs_f_9885)))
                }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::syntax::Stmt)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>));
                let closed_pb = crate::prelude::run_to_end(crate::prelude::fold_job(arms_p6.clone(), true, {
                    let menv_p1x = menv_p1.clone();
                    let block_defs_pax = block_defs_pa.clone();
                    ::std::rc::Rc::new(move |(p0, p1): (bool, crate::syntax::Arm)| {
                        let menv_p1xy = menv_p1x.clone();
                        let block_defs_paxy = block_defs_pax.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let ok_pi = p0;
                            let a_pj = p1;
                            {
                                let a_pjz = a_pj.clone();
                                let block_defs_paxyz = block_defs_paxy.clone();
                                let menv_p1xyz = menv_p1xy.clone();
                                let ok_piz = ok_pi;
                                let k_let9979 = move |v9979: crate::prelude::Array<crate::prelude::Text>| {
                                    let own_pk = v9979;
                                    if ok_piz {
                                        crate::prelude::call_then(crate::check::typed::print::start_block_exprs_f(a_pjz.body_p.clone()), move |block_exprs_f_10117: crate::prelude::Array<crate::syntax::Expr>| crate::prelude::call_then(crate::lower::expr::start_free_reads_f(block_exprs_f_10117, crate::prelude::Array::from(vec![(own_pk.clone(), a_pjz.span_p.clone())])), move |free_reads_f_10106: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::prelude::fold(&free_reads_f_10106, &true, &(|ok2_pm: &bool, n_pn: &crate::prelude::Text| (*ok2_pm && !crate::check::env::has_key_f(&menv_p1xyz.names_p, n_pn)) && !crate::check::types::has_text_f(&block_defs_paxyz, n_pn))))))
                                    } else {
                                        ::prism_rtl::Turn::Finished(false)
                                    }
                                };
                                match a_pj.pattern_o.clone() {
                                    ::std::option::Option::Some(q_pl) => crate::prelude::call_then(crate::check::env::names::start_pattern_names_f(q_pl.clone()), move |pattern_names_f_10032: crate::prelude::Array<crate::prelude::Text>| k_let9979(pattern_names_f_10032)),
                                    ::std::option::Option::None => k_let9979(crate::prelude::Array::new()),
                                }
                            }
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::syntax::Arm)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
                }));
                let taken_pc = crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(i_p3), false, {
                    let lx_p0x = lx_p0.clone();
                    let b_p2x = b_p2.clone();
                    let names_p7x = names_p7.clone();
                    ::std::rc::Rc::new(move |(p0, p1): (bool, crate::prelude::Nat)| {
                        let lx_p0xy = lx_p0x.clone();
                        let b_p2xy = b_p2x.clone();
                        let names_p7xy = names_p7x.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let f_po = p0;
                            let j_pp = p1;
                            if f_po {
                                ::prism_rtl::Turn::Finished(true)
                            } else {
                                ::prism_rtl::Turn::More(::std::rc::Rc::new(TakesAtBuild { lx_p0: lx_p0xy.clone(), st_p1: crate::prelude::or(&crate::prelude::index(&b_p2xy.stmts_p, &j_pp), &crate::lower::expr::dummy_stmt_l_p()), names_p2: names_p7xy.clone() }))
                            }
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
                }));
                (((plain_p8 && unguarded_p9) && closed_pb) && taken_pc) && !is_pure_choice_taken_by_f(lx_p0, menv_p1, b_p2, i_p3, &crate::prelude::Nat::from(16u32), &true)
            },
            _ => false,
        },
        _ => false,
    }
}

/// The step machine of `IsEarlyChoiceAt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// IsEarlyChoiceAt: unbounded fn Lx, Env, Block, Nat -> Bool
/// ```
pub struct IsEarlyChoiceAt {
    pub lx_p0: crate::lower::Lx,
    pub menv_p1: crate::lower::types::Env,
    pub b_p2: crate::syntax::Block,
    pub i_p3: crate::prelude::Nat,
}

impl ::prism_rtl::Job<bool> for IsEarlyChoiceAt {
    fn cycle(&self) -> ::prism_rtl::Turn<bool> {
        let lx_p0 = &self.lx_p0;
        let menv_p1 = &self.menv_p1;
        let b_p2 = &self.b_p2;
        let i_p3 = &self.i_p3;
        match &crate::prelude::or(&crate::prelude::index(&b_p2.stmts_p, i_p3), &crate::lower::expr::dummy_stmt_l_p()).kind_p {
            crate::syntax::StmtKind::SBind(p_p4, e_p5, ::std::option::Option::None) => match &*crate::lower::node_::static_::ungrouped_f(e_p5).kind_p {
                crate::syntax::ExprKind::EMatch(_, arms_p6) => {
                    let arms_p6x = arms_p6.clone();
                    let b_p2x = b_p2.clone();
                    let e_p5x = e_p5.clone();
                    let i_p3x = i_p3.clone();
                    let lx_p0x = lx_p0.clone();
                    let menv_p1x = menv_p1.clone();
                    let p_p4x = p_p4.clone();
                    crate::prelude::call_then(crate::check::env::names::start_pattern_names_f(p_p4x.clone()), move |pattern_names_f_9606: crate::prelude::Array<crate::prelude::Text>| {
                        let names_p7 = crate::prelude::filter(&pattern_names_f_9606, &(|n_pd: &crate::prelude::Text| !is_time_name_f(n_pd)));
                        crate::prelude::call_then(start_is_plain_result_f(lx_p0x.clone(), e_p5x.clone()), move |is_plain_result_f_9672: bool| {
                            let plain_p8 = is_plain_result_f_9672 && !crate::lower::types::is_bundle_f(&line_out_full_f(&lx_p0x, &e_p5x));
                            let unguarded_p9 = crate::prelude::fold(&arms_p6x, &true, &(|ok_pe: &bool, a_pf: &crate::syntax::Arm| *ok_pe && (&a_pf.guard_o == &::std::option::Option::None)));
                            crate::prelude::call_value(crate::prelude::fold_job(b_p2x.stmts_p.clone(), crate::prelude::Array::new(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::syntax::Stmt)| crate::prelude::entered(crate::prelude::once_job(move || {
                                let acc_pg = p0;
                                let st_ph = p1;
                                crate::prelude::call_then(crate::check::blocks::start_group_defs_f(st_ph.clone()), move |group_defs_f_9885: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_pg, &group_defs_f_9885)))
                            }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::syntax::Stmt)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>), move |fold_9837: crate::prelude::Array<crate::prelude::Text>| {
                                let block_defs_pa = fold_9837;
                                crate::prelude::call_value(crate::prelude::fold_job(arms_p6x.clone(), true, {
                                    let menv_p1xx = menv_p1x.clone();
                                    let block_defs_pax = block_defs_pa.clone();
                                    ::std::rc::Rc::new(move |(p0, p1): (bool, crate::syntax::Arm)| {
                                        let menv_p1xxy = menv_p1xx.clone();
                                        let block_defs_paxy = block_defs_pax.clone();
                                        crate::prelude::entered(crate::prelude::once_job(move || {
                                            let ok_pi = p0;
                                            let a_pj = p1;
                                            {
                                                let a_pjz = a_pj.clone();
                                                let block_defs_paxyz = block_defs_paxy.clone();
                                                let menv_p1xxyz = menv_p1xxy.clone();
                                                let ok_piz = ok_pi;
                                                let k_let9979 = move |v9979: crate::prelude::Array<crate::prelude::Text>| {
                                                    let own_pk = v9979;
                                                    if ok_piz {
                                                        crate::prelude::call_then(crate::check::typed::print::start_block_exprs_f(a_pjz.body_p.clone()), move |block_exprs_f_10117: crate::prelude::Array<crate::syntax::Expr>| crate::prelude::call_then(crate::lower::expr::start_free_reads_f(block_exprs_f_10117, crate::prelude::Array::from(vec![(own_pk.clone(), a_pjz.span_p.clone())])), move |free_reads_f_10106: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::prelude::fold(&free_reads_f_10106, &true, &(|ok2_pm: &bool, n_pn: &crate::prelude::Text| (*ok2_pm && !crate::check::env::has_key_f(&menv_p1xxyz.names_p, n_pn)) && !crate::check::types::has_text_f(&block_defs_paxyz, n_pn))))))
                                                    } else {
                                                        ::prism_rtl::Turn::Finished(false)
                                                    }
                                                };
                                                match a_pj.pattern_o.clone() {
                                                    ::std::option::Option::Some(q_pl) => crate::prelude::call_then(crate::check::env::names::start_pattern_names_f(q_pl.clone()), move |pattern_names_f_10032: crate::prelude::Array<crate::prelude::Text>| k_let9979(pattern_names_f_10032)),
                                                    ::std::option::Option::None => k_let9979(crate::prelude::Array::new()),
                                                }
                                            }
                                        }))
                                    }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::syntax::Arm)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
                                }), move |fold_9937: bool| {
                                    let closed_pb = fold_9937;
                                    crate::prelude::call_value(crate::prelude::fold_job(crate::check::errors::range0_f(&i_p3x), false, {
                                        let lx_p0xx = lx_p0x.clone();
                                        let b_p2xx = b_p2x.clone();
                                        let names_p7x = names_p7.clone();
                                        ::std::rc::Rc::new(move |(p0, p1): (bool, crate::prelude::Nat)| {
                                            let lx_p0xxy = lx_p0xx.clone();
                                            let b_p2xxy = b_p2xx.clone();
                                            let names_p7xy = names_p7x.clone();
                                            crate::prelude::entered(crate::prelude::once_job(move || {
                                                let f_po = p0;
                                                let j_pp = p1;
                                                if f_po {
                                                    ::prism_rtl::Turn::Finished(true)
                                                } else {
                                                    ::prism_rtl::Turn::More(::std::rc::Rc::new(TakesAtBuild { lx_p0: lx_p0xxy.clone(), st_p1: crate::prelude::or(&crate::prelude::index(&b_p2xxy.stmts_p, &j_pp), &crate::lower::expr::dummy_stmt_l_p()), names_p2: names_p7xy.clone() }))
                                                }
                                            }))
                                        }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
                                    }), move |fold_10267: bool| {
                                        let taken_pc = fold_10267;
                                        if ((plain_p8 && unguarded_p9) && closed_pb) && taken_pc {
                                            crate::prelude::call_then(start_is_pure_choice_taken_by_f(lx_p0x.clone(), menv_p1x.clone(), b_p2x.clone(), i_p3x.clone(), crate::prelude::Nat::from(16u32), true), move |is_pure_choice_taken_by_f_10418: bool| ::prism_rtl::Turn::Finished(!is_pure_choice_taken_by_f_10418))
                                        } else {
                                            ::prism_rtl::Turn::Finished(false)
                                        }
                                    })
                                })
                            })
                        })
                    })
                },
                _ => ::prism_rtl::Turn::Finished(false),
            },
            _ => ::prism_rtl::Turn::Finished(false),
        }
    }
}

/// `Start IsEarlyChoiceAt, x`: what the function value is when passed to `@Run`.
pub fn start_is_early_choice_at_f(lx_p0: crate::lower::Lx, menv_p1: crate::lower::types::Env, b_p2: crate::syntax::Block, i_p3: crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>> {
    ::std::rc::Rc::new(IsEarlyChoiceAt { lx_p0, menv_p1, b_p2, i_p3 })
}

/// ```prism
/// IsPureChoiceAt: unbounded fn Lx, Env, Block, Nat, Nat -> Bool
/// ```
pub fn is_pure_choice_at_f(lx_p0: &crate::lower::Lx, menv_p1: &crate::lower::types::Env, b_p2: &crate::syntax::Block, i_p3: &crate::prelude::Nat, depth_p4: &crate::prelude::Nat) -> bool {
    is_pure_choice_taken_by_f(lx_p0, menv_p1, b_p2, i_p3, depth_p4, &false)
}

/// The step machine of `IsPureChoiceAt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// IsPureChoiceAt: unbounded fn Lx, Env, Block, Nat, Nat -> Bool
/// ```
pub struct IsPureChoiceAt {
    pub lx_p0: crate::lower::Lx,
    pub menv_p1: crate::lower::types::Env,
    pub b_p2: crate::syntax::Block,
    pub i_p3: crate::prelude::Nat,
    pub depth_p4: crate::prelude::Nat,
}

impl ::prism_rtl::Job<bool> for IsPureChoiceAt {
    fn cycle(&self) -> ::prism_rtl::Turn<bool> {
        let lx_p0 = &self.lx_p0;
        let menv_p1 = &self.menv_p1;
        let b_p2 = &self.b_p2;
        let i_p3 = &self.i_p3;
        let depth_p4 = &self.depth_p4;
        ::prism_rtl::Turn::More(::std::rc::Rc::new(IsPureChoiceTakenBy { lx_p0: lx_p0.clone(), menv_p1: menv_p1.clone(), b_p2: b_p2.clone(), i_p3: i_p3.clone(), depth_p4: depth_p4.clone(), choices_only_p5: false }))
    }
}

/// `Start IsPureChoiceAt, x`: what the function value is when passed to `@Run`.
pub fn start_is_pure_choice_at_f(lx_p0: crate::lower::Lx, menv_p1: crate::lower::types::Env, b_p2: crate::syntax::Block, i_p3: crate::prelude::Nat, depth_p4: crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>> {
    ::std::rc::Rc::new(IsPureChoiceAt { lx_p0, menv_p1, b_p2, i_p3, depth_p4 })
}

/// ```prism
/// IsPureChoiceTakenBy: unbounded fn Lx, Env, Block, Nat, Nat, Bool -> Bool
/// ```
pub fn is_pure_choice_taken_by_f(lx_p0: &crate::lower::Lx, menv_p1: &crate::lower::types::Env, b_p2: &crate::syntax::Block, i_p3: &crate::prelude::Nat, depth_p4: &crate::prelude::Nat, choices_only_p5: &bool) -> bool {
    match &crate::prelude::or(&crate::prelude::index(&b_p2.stmts_p, i_p3), &crate::lower::expr::dummy_stmt_l_p()).kind_p {
        crate::syntax::StmtKind::SBind(p_p6, e_p7, ::std::option::Option::None) => {
            let names_p8 = crate::prelude::filter(&crate::check::env::names::pattern_names_f(p_p6), &(|n_pb: &crate::prelude::Text| !is_time_name_f(n_pb)));
            let plain_p9 = is_plain_result_f(lx_p0, e_p7) && !crate::lower::types::is_bundle_f(&line_out_full_f(lx_p0, e_p7));
            let taken_pa = crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(i_p3), false, {
                let choices_only_p5x = *choices_only_p5;
                let b_p2x = b_p2.clone();
                let lx_p0x = lx_p0.clone();
                let names_p8x = names_p8.clone();
                ::std::rc::Rc::new(move |(p0, p1): (bool, crate::prelude::Nat)| {
                    let choices_only_p5xy = choices_only_p5x;
                    let b_p2xy = b_p2x.clone();
                    let lx_p0xy = lx_p0x.clone();
                    let names_p8xy = names_p8x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let f_pc = p0;
                        let j_pd = p1;
                        if f_pc {
                            ::prism_rtl::Turn::Finished(true)
                        } else {
                            if !choices_only_p5xy || is_choice_line_f(&crate::prelude::or(&crate::prelude::index(&b_p2xy.stmts_p, &j_pd), &crate::lower::expr::dummy_stmt_l_p())) {
                                ::prism_rtl::Turn::More(::std::rc::Rc::new(TakesAtBuild { lx_p0: lx_p0xy.clone(), st_p1: crate::prelude::or(&crate::prelude::index(&b_p2xy.stmts_p, &j_pd), &crate::lower::expr::dummy_stmt_l_p()), names_p2: names_p8xy.clone() }))
                            } else {
                                ::prism_rtl::Turn::Finished(false)
                            }
                        }
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
            }));
            if !(plain_p9 && taken_pa) {
                false
            } else {
                match pure_choice_o(e_p7) {
                    ::std::option::Option::Some((heads_pe, bodies_pf)) => {
                        let late_defs_pg = crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(&b_p2.stmts_p)), crate::prelude::Array::new(), {
                            let i_p3x = i_p3.clone();
                            let b_p2x = b_p2.clone();
                            let lx_p0x = lx_p0.clone();
                            let menv_p1x = menv_p1.clone();
                            let depth_p4x = depth_p4.clone();
                            ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::prelude::Nat)| {
                                let i_p3xy = i_p3x.clone();
                                let b_p2xy = b_p2x.clone();
                                let lx_p0xy = lx_p0x.clone();
                                let menv_p1xy = menv_p1x.clone();
                                let depth_p4xy = depth_p4x.clone();
                                crate::prelude::entered(crate::prelude::once_job(move || {
                                    let acc_pi = p0;
                                    let j_pj = p1;
                                    if &j_pj == &i_p3xy {
                                        ::prism_rtl::Turn::Finished(acc_pi.clone())
                                    } else {
                                        match &crate::prelude::or(&crate::prelude::index(&b_p2xy.stmts_p, &j_pj), &crate::lower::expr::dummy_stmt_l_p()).kind_p {
                                            crate::syntax::StmtKind::SBind(q_pk, x_pl, ::std::option::Option::None) => {
                                                let q_pkx = q_pk.clone();
                                                let x_plx = x_pl.clone();
                                                crate::prelude::call_then(start_is_late_expr_f(lx_p0xy.clone(), menv_p1xy.clone(), x_plx.clone(), depth_p4xy.clone()), move |is_late_expr_f_13128: bool| if is_late_expr_f_13128 {
                                                    crate::prelude::call_then(crate::check::env::names::start_pattern_names_f(q_pkx.clone()), move |pattern_names_f_13184: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_pi, &crate::prelude::filter(&pattern_names_f_13184, &(|n_pm: &crate::prelude::Text| !is_time_name_f(n_pm))))))
                                                } else {
                                                    ::prism_rtl::Turn::Finished(acc_pi.clone())
                                                })
                                            },
                                            _ => ::prism_rtl::Turn::Finished(acc_pi.clone()),
                                        }
                                    }
                                }))
                            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>
                        }));
                        let read_ph = crate::lower::expr::free_reads_f(&crate::prelude::run_to_end(crate::prelude::fold_job(bodies_pf.clone(), heads_pe.clone(), {
                            let lx_p0x = lx_p0.clone();
                            ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::syntax::Expr>, crate::syntax::Block)| {
                                let lx_p0xy = lx_p0x.clone();
                                crate::prelude::entered(crate::prelude::once_job(move || {
                                    let acc_pn = p0;
                                    let body_po = p1;
                                    crate::prelude::call_then(start_pure_arm_f(lx_p0xy.clone(), body_po.clone()), move |pure_arm_f_13367: crate::syntax::Block| crate::prelude::call_then(crate::check::typed::print::start_block_exprs_f(pure_arm_f_13367), move |block_exprs_f_13355: crate::prelude::Array<crate::syntax::Expr>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_pn, &block_exprs_f_13355))))
                                }))
                            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::syntax::Expr>, crate::syntax::Block)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::syntax::Expr>>>>
                        })), &crate::prelude::Array::new());
                        crate::prelude::run_to_end(crate::prelude::fold_job(bodies_pf.clone(), true, {
                            let lx_p0x = lx_p0.clone();
                            ::std::rc::Rc::new(move |(p0, p1): (bool, crate::syntax::Block)| {
                                let lx_p0xy = lx_p0x.clone();
                                crate::prelude::entered(crate::prelude::once_job(move || {
                                    let ok_pp = p0;
                                    let body_pq = p1;
                                    if ok_pp {
                                        ::prism_rtl::Turn::More(::std::rc::Rc::new(IsPureArm { lx_p0: lx_p0xy.clone(), body_p1: body_pq.clone() }))
                                    } else {
                                        ::prism_rtl::Turn::Finished(false)
                                    }
                                }))
                            }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::syntax::Block)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
                        })) && crate::prelude::fold(&read_ph, &true, &(|ok_pr: &bool, n_ps: &crate::prelude::Text| *ok_pr && !crate::check::types::has_text_f(&late_defs_pg, n_ps)))
                    },
                    ::std::option::Option::None => false,
                }
            }
        },
        _ => false,
    }
}

/// The step machine of `IsPureChoiceTakenBy`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// IsPureChoiceTakenBy: unbounded fn Lx, Env, Block, Nat, Nat, Bool -> Bool
/// ```
pub struct IsPureChoiceTakenBy {
    pub lx_p0: crate::lower::Lx,
    pub menv_p1: crate::lower::types::Env,
    pub b_p2: crate::syntax::Block,
    pub i_p3: crate::prelude::Nat,
    pub depth_p4: crate::prelude::Nat,
    pub choices_only_p5: bool,
}

impl ::prism_rtl::Job<bool> for IsPureChoiceTakenBy {
    fn cycle(&self) -> ::prism_rtl::Turn<bool> {
        let lx_p0 = &self.lx_p0;
        let menv_p1 = &self.menv_p1;
        let b_p2 = &self.b_p2;
        let i_p3 = &self.i_p3;
        let depth_p4 = &self.depth_p4;
        let choices_only_p5 = &self.choices_only_p5;
        match &crate::prelude::or(&crate::prelude::index(&b_p2.stmts_p, i_p3), &crate::lower::expr::dummy_stmt_l_p()).kind_p {
            crate::syntax::StmtKind::SBind(p_p6, e_p7, ::std::option::Option::None) => {
                let b_p2x = b_p2.clone();
                let choices_only_p5x = *choices_only_p5;
                let depth_p4x = depth_p4.clone();
                let e_p7x = e_p7.clone();
                let i_p3x = i_p3.clone();
                let lx_p0x = lx_p0.clone();
                let menv_p1x = menv_p1.clone();
                let p_p6x = p_p6.clone();
                crate::prelude::call_then(crate::check::env::names::start_pattern_names_f(p_p6x.clone()), move |pattern_names_f_12542: crate::prelude::Array<crate::prelude::Text>| {
                    let names_p8 = crate::prelude::filter(&pattern_names_f_12542, &(|n_pb: &crate::prelude::Text| !is_time_name_f(n_pb)));
                    crate::prelude::call_then(start_is_plain_result_f(lx_p0x.clone(), e_p7x.clone()), move |is_plain_result_f_12604: bool| {
                        let plain_p9 = is_plain_result_f_12604 && !crate::lower::types::is_bundle_f(&line_out_full_f(&lx_p0x, &e_p7x));
                        crate::prelude::call_value(crate::prelude::fold_job(crate::check::errors::range0_f(&i_p3x), false, {
                            let choices_only_p5xx = choices_only_p5x;
                            let b_p2xx = b_p2x.clone();
                            let lx_p0xx = lx_p0x.clone();
                            let names_p8x = names_p8.clone();
                            ::std::rc::Rc::new(move |(p0, p1): (bool, crate::prelude::Nat)| {
                                let choices_only_p5xxy = choices_only_p5xx;
                                let b_p2xxy = b_p2xx.clone();
                                let lx_p0xxy = lx_p0xx.clone();
                                let names_p8xy = names_p8x.clone();
                                crate::prelude::entered(crate::prelude::once_job(move || {
                                    let f_pc = p0;
                                    let j_pd = p1;
                                    if f_pc {
                                        ::prism_rtl::Turn::Finished(true)
                                    } else {
                                        if !choices_only_p5xxy || is_choice_line_f(&crate::prelude::or(&crate::prelude::index(&b_p2xxy.stmts_p, &j_pd), &crate::lower::expr::dummy_stmt_l_p())) {
                                            ::prism_rtl::Turn::More(::std::rc::Rc::new(TakesAtBuild { lx_p0: lx_p0xxy.clone(), st_p1: crate::prelude::or(&crate::prelude::index(&b_p2xxy.stmts_p, &j_pd), &crate::lower::expr::dummy_stmt_l_p()), names_p2: names_p8xy.clone() }))
                                        } else {
                                            ::prism_rtl::Turn::Finished(false)
                                        }
                                    }
                                }))
                            }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
                        }), move |fold_12684: bool| {
                            let taken_pa = fold_12684;
                            if !(plain_p9 && taken_pa) {
                                ::prism_rtl::Turn::Finished(false)
                            } else {
                                crate::prelude::call_then(start_pure_choice_o(e_p7x.clone()), move |pure_choice_o_12903: ::std::option::Option<(crate::prelude::Array<crate::syntax::Expr>, crate::prelude::Array<crate::syntax::Block>)>| match pure_choice_o_12903 {
                                    ::std::option::Option::Some((heads_pe, bodies_pf)) => crate::prelude::call_value(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(&b_p2x.stmts_p)), crate::prelude::Array::new(), {
                                        let i_p3xx = i_p3x.clone();
                                        let b_p2xx = b_p2x.clone();
                                        let lx_p0xx = lx_p0x.clone();
                                        let menv_p1xx = menv_p1x.clone();
                                        let depth_p4xx = depth_p4x.clone();
                                        ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::prelude::Nat)| {
                                            let i_p3xxy = i_p3xx.clone();
                                            let b_p2xxy = b_p2xx.clone();
                                            let lx_p0xxy = lx_p0xx.clone();
                                            let menv_p1xxy = menv_p1xx.clone();
                                            let depth_p4xxy = depth_p4xx.clone();
                                            crate::prelude::entered(crate::prelude::once_job(move || {
                                                let acc_pi = p0;
                                                let j_pj = p1;
                                                if &j_pj == &i_p3xxy {
                                                    ::prism_rtl::Turn::Finished(acc_pi.clone())
                                                } else {
                                                    match &crate::prelude::or(&crate::prelude::index(&b_p2xxy.stmts_p, &j_pj), &crate::lower::expr::dummy_stmt_l_p()).kind_p {
                                                        crate::syntax::StmtKind::SBind(q_pk, x_pl, ::std::option::Option::None) => {
                                                            let q_pkx = q_pk.clone();
                                                            let x_plx = x_pl.clone();
                                                            crate::prelude::call_then(start_is_late_expr_f(lx_p0xxy.clone(), menv_p1xxy.clone(), x_plx.clone(), depth_p4xxy.clone()), move |is_late_expr_f_13128: bool| if is_late_expr_f_13128 {
                                                                crate::prelude::call_then(crate::check::env::names::start_pattern_names_f(q_pkx.clone()), move |pattern_names_f_13184: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_pi, &crate::prelude::filter(&pattern_names_f_13184, &(|n_pm: &crate::prelude::Text| !is_time_name_f(n_pm))))))
                                                            } else {
                                                                ::prism_rtl::Turn::Finished(acc_pi.clone())
                                                            })
                                                        },
                                                        _ => ::prism_rtl::Turn::Finished(acc_pi.clone()),
                                                    }
                                                }
                                            }))
                                        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>
                                    }), move |fold_12982: crate::prelude::Array<crate::prelude::Text>| {
                                        let late_defs_pg = fold_12982;
                                        crate::prelude::call_value(crate::prelude::fold_job(bodies_pf.clone(), heads_pe.clone(), {
                                            let lx_p0xx = lx_p0x.clone();
                                            ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::syntax::Expr>, crate::syntax::Block)| {
                                                let lx_p0xxy = lx_p0xx.clone();
                                                crate::prelude::entered(crate::prelude::once_job(move || {
                                                    let acc_pn = p0;
                                                    let body_po = p1;
                                                    crate::prelude::call_then(start_pure_arm_f(lx_p0xxy.clone(), body_po.clone()), move |pure_arm_f_13367: crate::syntax::Block| crate::prelude::call_then(crate::check::typed::print::start_block_exprs_f(pure_arm_f_13367), move |block_exprs_f_13355: crate::prelude::Array<crate::syntax::Expr>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_pn, &block_exprs_f_13355))))
                                                }))
                                            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::syntax::Expr>, crate::syntax::Block)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::syntax::Expr>>>>
                                        }), move |fold_13309: crate::prelude::Array<crate::syntax::Expr>| crate::prelude::call_then(crate::lower::expr::start_free_reads_f(fold_13309, crate::prelude::Array::new()), move |free_reads_f_13298: crate::prelude::Array<crate::prelude::Text>| {
                                            let read_ph = free_reads_f_13298;
                                            crate::prelude::call_value(crate::prelude::fold_job(bodies_pf.clone(), true, {
                                                let lx_p0xx = lx_p0x.clone();
                                                ::std::rc::Rc::new(move |(p0, p1): (bool, crate::syntax::Block)| {
                                                    let lx_p0xxy = lx_p0xx.clone();
                                                    crate::prelude::entered(crate::prelude::once_job(move || {
                                                        let ok_pp = p0;
                                                        let body_pq = p1;
                                                        if ok_pp {
                                                            ::prism_rtl::Turn::More(::std::rc::Rc::new(IsPureArm { lx_p0: lx_p0xxy.clone(), body_p1: body_pq.clone() }))
                                                        } else {
                                                            ::prism_rtl::Turn::Finished(false)
                                                        }
                                                    }))
                                                }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::syntax::Block)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
                                            }), move |fold_13410: bool| ::prism_rtl::Turn::Finished(fold_13410 && crate::prelude::fold(&read_ph, &true, &(|ok_pr: &bool, n_ps: &crate::prelude::Text| *ok_pr && !crate::check::types::has_text_f(&late_defs_pg, n_ps)))))
                                        }))
                                    }),
                                    ::std::option::Option::None => ::prism_rtl::Turn::Finished(false),
                                })
                            }
                        })
                    })
                })
            },
            _ => ::prism_rtl::Turn::Finished(false),
        }
    }
}

/// `Start IsPureChoiceTakenBy, x`: what the function value is when passed to `@Run`.
pub fn start_is_pure_choice_taken_by_f(lx_p0: crate::lower::Lx, menv_p1: crate::lower::types::Env, b_p2: crate::syntax::Block, i_p3: crate::prelude::Nat, depth_p4: crate::prelude::Nat, choices_only_p5: bool) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>> {
    ::std::rc::Rc::new(IsPureChoiceTakenBy { lx_p0, menv_p1, b_p2, i_p3, depth_p4, choices_only_p5 })
}

/// ```prism
/// IsChoiceLine: fn Stmt -> Bool
/// ```
pub fn is_choice_line_f(st_p0: &crate::syntax::Stmt) -> bool {
    let line_o1 = match &st_p0.kind_p {
        crate::syntax::StmtKind::SBind(_, e_p2, ::std::option::Option::None) => ::std::option::Option::Some(e_p2.clone()),
        crate::syntax::StmtKind::SIgnore(e_p3) => ::std::option::Option::Some(e_p3.clone()),
        crate::syntax::StmtKind::SExpr(e_p4) => ::std::option::Option::Some(e_p4.clone()),
        _ => ::std::option::Option::None,
    };
    match &line_o1 {
        ::std::option::Option::Some(e_p5) => match &*crate::lower::node_::static_::ungrouped_f(e_p5).kind_p {
            crate::syntax::ExprKind::EIf(_, _, _) => true,
            crate::syntax::ExprKind::EMatch(_, _) => true,
            _ => false,
        },
        ::std::option::Option::None => false,
    }
}

/// ```prism
/// ?PureChoice: unbounded fn Expr -> ?(([Expr], [Block]))
/// ```
pub fn pure_choice_o(e_p0: &crate::syntax::Expr) -> ::std::option::Option<(crate::prelude::Array<crate::syntax::Expr>, crate::prelude::Array<crate::syntax::Block>)> {
    match &*crate::lower::node_::static_::ungrouped_f(e_p0).kind_p {
        crate::syntax::ExprKind::EMatch(s_p1, arms_p2) => ::std::option::Option::Some((crate::prelude::run_to_end(crate::prelude::fold_job(arms_p2.clone(), crate::check::typed::print::exprs_in_f(&**s_p1), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::syntax::Expr>, crate::syntax::Arm)| crate::prelude::entered(crate::prelude::once_job(move || {
            let acc_p3 = p0;
            let a_p4 = p1;
            ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_p3, &guard_exprs_f(&a_p4.guard_o)))
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::syntax::Expr>, crate::syntax::Arm)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::syntax::Expr>>>>)), crate::prelude::each(arms_p2, &(|a_p5: &crate::syntax::Arm| a_p5.body_p.clone())))),
        crate::syntax::ExprKind::EIf(c_p6, then_b_p7, ::std::option::Option::Some(else_b_p8)) => ::std::option::Option::Some((crate::check::typed::print::cond_exprs_f(&**c_p6), crate::prelude::Array::from(vec![then_b_p7.clone(), else_b_p8.clone()]))),
        _ => ::std::option::Option::None,
    }
}

/// The step machine of `PureChoice`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?PureChoice: unbounded fn Expr -> ?(([Expr], [Block]))
/// ```
pub struct PureChoice {
    pub e_p0: crate::syntax::Expr,
}

impl ::prism_rtl::Job<::std::option::Option<(crate::prelude::Array<crate::syntax::Expr>, crate::prelude::Array<crate::syntax::Block>)>> for PureChoice {
    fn cycle(&self) -> ::prism_rtl::Turn<::std::option::Option<(crate::prelude::Array<crate::syntax::Expr>, crate::prelude::Array<crate::syntax::Block>)>> {
        let e_p0 = &self.e_p0;
        match &*crate::lower::node_::static_::ungrouped_f(e_p0).kind_p {
            crate::syntax::ExprKind::EMatch(s_p1, arms_p2) => ::prism_rtl::Turn::Finished(::std::option::Option::Some((crate::prelude::run_to_end(crate::prelude::fold_job(arms_p2.clone(), crate::check::typed::print::exprs_in_f(&**s_p1), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::syntax::Expr>, crate::syntax::Arm)| crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_p3 = p0;
                let a_p4 = p1;
                ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_p3, &guard_exprs_f(&a_p4.guard_o)))
            }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::syntax::Expr>, crate::syntax::Arm)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::syntax::Expr>>>>)), crate::prelude::each(arms_p2, &(|a_p5: &crate::syntax::Arm| a_p5.body_p.clone()))))),
            crate::syntax::ExprKind::EIf(c_p6, then_b_p7, ::std::option::Option::Some(else_b_p8)) => ::prism_rtl::Turn::Finished(::std::option::Option::Some((crate::check::typed::print::cond_exprs_f(&**c_p6), crate::prelude::Array::from(vec![then_b_p7.clone(), else_b_p8.clone()])))),
            _ => ::prism_rtl::Turn::Finished(::std::option::Option::None),
        }
    }
}

/// `Start PureChoice, x`: what the function value is when passed to `@Run`.
pub fn start_pure_choice_o(e_p0: crate::syntax::Expr) -> ::std::rc::Rc<dyn ::prism_rtl::Job<::std::option::Option<(crate::prelude::Array<crate::syntax::Expr>, crate::prelude::Array<crate::syntax::Block>)>>> {
    ::std::rc::Rc::new(PureChoice { e_p0 })
}

/// ```prism
/// GuardExprs: unbounded fn ?Expr -> [Expr]
/// ```
pub fn guard_exprs_f(opt0: &::std::option::Option<crate::syntax::Expr>) -> crate::prelude::Array<crate::syntax::Expr> {
    match opt0 {
        ::std::option::Option::Some(g_p0) => crate::check::typed::print::exprs_in_f(g_p0),
        ::std::option::Option::None => crate::prelude::Array::new(),
    }
}

/// ```prism
/// IsPlainLet: unbounded fn Lx, Stmt -> Bool
/// ```
pub fn is_plain_let_f(lx_p0: &crate::lower::Lx, st_p1: &crate::syntax::Stmt) -> bool {
    match &st_p1.kind_p {
        crate::syntax::StmtKind::SLet(p_p2, _, e_p3) => crate::prelude::fold(&crate::check::env::names::pattern_names_f(p_p2), &true, &(|ok_p4: &bool, n_p5: &crate::prelude::Text| *ok_p4 && !is_time_name_f(n_p5))) && !crate::lower::types::time_within_f(&crate::lower::type_at_f(lx_p0, &e_p3.span_p)),
        _ => false,
    }
}

/// ```prism
/// PureArm: unbounded fn Lx, Block -> Block
/// ```
pub fn pure_arm_f(lx_p0: &crate::lower::Lx, body_p1: &crate::syntax::Block) -> crate::syntax::Block {
    let lets_p2 = crate::prelude::run_to_end(crate::prelude::filter_job(crate::prelude::take(&body_p1.stmts_p, &crate::syntax::lexer::chars::dec_f(&crate::prelude::len(&body_p1.stmts_p))), {
        let lx_p0x = lx_p0.clone();
        ::std::rc::Rc::new(move |p0: crate::syntax::Stmt| {
            let lx_p0xy = lx_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let st_p3 = p0;
                ::prism_rtl::Turn::Finished(is_plain_let_f(&lx_p0xy, &st_p3))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::syntax::Stmt) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
    }));
    match &crate::prelude::or(&crate::prelude::index(&body_p1.stmts_p, &crate::syntax::lexer::chars::dec_f(&crate::prelude::len(&body_p1.stmts_p))), &crate::lower::expr::dummy_stmt_l_p()).kind_p {
        crate::syntax::StmtKind::SExpr(y_p4) => match &*y_p4.kind_p {
            crate::syntax::ExprKind::EFreeSigil(m15186_0_0, v_p5) if (m15186_0_0 == &crate::prelude::Text::lit("@")) => crate::syntax::Block { stmts_p: crate::prelude::push(&lets_p2, &crate::syntax::Stmt { kind_p: crate::syntax::StmtKind::SExpr((**v_p5).clone()), span_p: v_p5.span_p.clone() }), inline_p: body_p1.inline_p, span_p: body_p1.span_p.clone() },
            _ => crate::syntax::Block { stmts_p: lets_p2.clone(), inline_p: body_p1.inline_p, span_p: body_p1.span_p.clone() },
            _ => unreachable!("no arm matched"),
        },
        _ => crate::syntax::Block { stmts_p: lets_p2.clone(), inline_p: body_p1.inline_p, span_p: body_p1.span_p.clone() },
    }
}

/// The step machine of `PureArm`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PureArm: unbounded fn Lx, Block -> Block
/// ```
pub struct PureArm {
    pub lx_p0: crate::lower::Lx,
    pub body_p1: crate::syntax::Block,
}

impl ::prism_rtl::Job<crate::syntax::Block> for PureArm {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::syntax::Block> {
        let lx_p0 = &self.lx_p0;
        let body_p1 = &self.body_p1;
        let body_p1x = body_p1.clone();
        let lx_p0x = lx_p0.clone();
        crate::prelude::call_value(crate::prelude::filter_job(crate::prelude::take(&body_p1x.stmts_p, &crate::syntax::lexer::chars::dec_f(&crate::prelude::len(&body_p1x.stmts_p))), {
            let lx_p0xx = lx_p0x.clone();
            ::std::rc::Rc::new(move |p0: crate::syntax::Stmt| {
                let lx_p0xxy = lx_p0xx.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let st_p3 = p0;
                    ::prism_rtl::Turn::Finished(is_plain_let_f(&lx_p0xxy, &st_p3))
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::syntax::Stmt) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
        }), move |filter_15029: crate::prelude::Array<crate::syntax::Stmt>| {
            let lets_p2 = filter_15029;
            match &crate::prelude::or(&crate::prelude::index(&body_p1x.stmts_p, &crate::syntax::lexer::chars::dec_f(&crate::prelude::len(&body_p1x.stmts_p))), &crate::lower::expr::dummy_stmt_l_p()).kind_p {
                crate::syntax::StmtKind::SExpr(y_p4) => match &*y_p4.kind_p {
                    crate::syntax::ExprKind::EFreeSigil(m15186_0_0, v_p5) if (m15186_0_0 == &crate::prelude::Text::lit("@")) => ::prism_rtl::Turn::Finished(crate::syntax::Block { stmts_p: crate::prelude::push(&lets_p2, &crate::syntax::Stmt { kind_p: crate::syntax::StmtKind::SExpr((**v_p5).clone()), span_p: v_p5.span_p.clone() }), inline_p: body_p1x.inline_p, span_p: body_p1x.span_p.clone() }),
                    _ => ::prism_rtl::Turn::Finished(crate::syntax::Block { stmts_p: lets_p2.clone(), inline_p: body_p1x.inline_p, span_p: body_p1x.span_p.clone() }),
                    _ => unreachable!("no arm matched"),
                },
                _ => ::prism_rtl::Turn::Finished(crate::syntax::Block { stmts_p: lets_p2.clone(), inline_p: body_p1x.inline_p, span_p: body_p1x.span_p.clone() }),
            }
        })
    }
}

/// `Start PureArm, x`: what the function value is when passed to `@Run`.
pub fn start_pure_arm_f(lx_p0: crate::lower::Lx, body_p1: crate::syntax::Block) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::syntax::Block>> {
    ::std::rc::Rc::new(PureArm { lx_p0, body_p1 })
}

/// ```prism
/// IsPureArm: unbounded fn Lx, Block -> Bool
/// ```
pub fn is_pure_arm_f(lx_p0: &crate::lower::Lx, body_p1: &crate::syntax::Block) -> bool {
    let ends_p2 = match &crate::prelude::or(&crate::prelude::index(&body_p1.stmts_p, &crate::syntax::lexer::chars::dec_f(&crate::prelude::len(&body_p1.stmts_p))), &crate::lower::expr::dummy_stmt_l_p()).kind_p {
        crate::syntax::StmtKind::SExpr(y_p4) => match &*y_p4.kind_p {
            crate::syntax::ExprKind::EFreeSigil(m15749_0_0, _) if (m15749_0_0 == &crate::prelude::Text::lit("@")) => true,
            _ => false,
            _ => unreachable!("no arm matched"),
        },
        _ => false,
    };
    let defs_p3 = crate::prelude::run_to_end(crate::prelude::fold_job(body_p1.stmts_p.clone(), crate::prelude::Array::new(), {
        let lx_p0x = lx_p0.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::syntax::Stmt)| {
            let lx_p0xy = lx_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_p5 = p0;
                let st_p6 = p1;
                if is_plain_let_f(&lx_p0xy, &st_p6) {
                    ::prism_rtl::Turn::Finished(acc_p5.clone())
                } else {
                    crate::prelude::call_then(crate::check::blocks::start_group_defs_f(st_p6.clone()), move |group_defs_f_15956: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_p5, &group_defs_f_15956)))
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::syntax::Stmt)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>
    }));
    ends_p2 && crate::prelude::fold(&crate::lower::expr::free_reads_f(&crate::check::typed::print::block_exprs_f(&pure_arm_f(lx_p0, body_p1)), &crate::prelude::Array::new()), &true, &(|ok_p7: &bool, n_p8: &crate::prelude::Text| *ok_p7 && !crate::check::types::has_text_f(&defs_p3, n_p8)))
}

/// The step machine of `IsPureArm`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// IsPureArm: unbounded fn Lx, Block -> Bool
/// ```
pub struct IsPureArm {
    pub lx_p0: crate::lower::Lx,
    pub body_p1: crate::syntax::Block,
}

impl ::prism_rtl::Job<bool> for IsPureArm {
    fn cycle(&self) -> ::prism_rtl::Turn<bool> {
        let lx_p0 = &self.lx_p0;
        let body_p1 = &self.body_p1;
        let ends_p2 = match &crate::prelude::or(&crate::prelude::index(&body_p1.stmts_p, &crate::syntax::lexer::chars::dec_f(&crate::prelude::len(&body_p1.stmts_p))), &crate::lower::expr::dummy_stmt_l_p()).kind_p {
            crate::syntax::StmtKind::SExpr(y_p4) => match &*y_p4.kind_p {
                crate::syntax::ExprKind::EFreeSigil(m15749_0_0, _) if (m15749_0_0 == &crate::prelude::Text::lit("@")) => true,
                _ => false,
                _ => unreachable!("no arm matched"),
            },
            _ => false,
        };
        let body_p1x = body_p1.clone();
        let lx_p0x = lx_p0.clone();
        crate::prelude::call_value(crate::prelude::fold_job(body_p1x.stmts_p.clone(), crate::prelude::Array::new(), {
            let lx_p0xx = lx_p0x.clone();
            ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::syntax::Stmt)| {
                let lx_p0xxy = lx_p0xx.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let acc_p5 = p0;
                    let st_p6 = p1;
                    if is_plain_let_f(&lx_p0xxy, &st_p6) {
                        ::prism_rtl::Turn::Finished(acc_p5.clone())
                    } else {
                        crate::prelude::call_then(crate::check::blocks::start_group_defs_f(st_p6.clone()), move |group_defs_f_15956: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_p5, &group_defs_f_15956)))
                    }
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::syntax::Stmt)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>
        }), move |fold_15873: crate::prelude::Array<crate::prelude::Text>| {
            let defs_p3 = fold_15873;
            if ends_p2 {
                crate::prelude::call_then(start_pure_arm_f(lx_p0x.clone(), body_p1x.clone()), move |pure_arm_f_16025: crate::syntax::Block| crate::prelude::call_then(crate::check::typed::print::start_block_exprs_f(pure_arm_f_16025), move |block_exprs_f_16013: crate::prelude::Array<crate::syntax::Expr>| crate::prelude::call_then(crate::lower::expr::start_free_reads_f(block_exprs_f_16013, crate::prelude::Array::new()), move |free_reads_f_16002: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::prelude::fold(&free_reads_f_16002, &true, &(|ok_p7: &bool, n_p8: &crate::prelude::Text| *ok_p7 && !crate::check::types::has_text_f(&defs_p3, n_p8)))))))
            } else {
                ::prism_rtl::Turn::Finished(false)
            }
        })
    }
}

/// `Start IsPureArm, x`: what the function value is when passed to `@Run`.
pub fn start_is_pure_arm_f(lx_p0: crate::lower::Lx, body_p1: crate::syntax::Block) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>> {
    ::std::rc::Rc::new(IsPureArm { lx_p0, body_p1 })
}

/// ```prism
/// PureChoiceValue: unbounded fn Lx, Env, Expr -> Vl
/// ```
pub fn pure_choice_value_f(lx_p0: &crate::lower::Lx, benv_p1: &crate::lower::types::Env, e_p2: &crate::syntax::Expr) -> crate::lower::types::Vl {
    let t_p3 = crate::lower::types::out_ty_of_f(lx_p0, &crate::lower::types::out_of_f(&crate::lower::type_at_f(lx_p0, &e_p2.span_p)));
    match &*crate::lower::node_::static_::ungrouped_f(e_p2).kind_p {
        crate::syntax::ExprKind::EMatch(s_p4, arms_p5) => crate::lower::expr::match_value_f(lx_p0, benv_p1, &**s_p4, &crate::prelude::run_to_end(crate::prelude::each_job(arms_p5.clone(), {
            let lx_p0x = lx_p0.clone();
            ::std::rc::Rc::new(move |p0: crate::syntax::Arm| {
                let lx_p0xy = lx_p0x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let a_p6 = p0;
                    ::prism_rtl::Turn::Finished(pure_arm_of_f(&lx_p0xy, &a_p6))
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::syntax::Arm) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::syntax::Arm>>>
        })), &t_p3, &e_p2.span_p),
        crate::syntax::ExprKind::EIf(c_p7, then_b_p8, ::std::option::Option::Some(else_b_p9)) => crate::lower::expr::if_value_f(lx_p0, benv_p1, &**c_p7, &pure_arm_f(lx_p0, then_b_p8), &::std::option::Option::Some(pure_arm_f(lx_p0, else_b_p9)), &t_p3),
        _ => crate::lower::types::Vl::VlOwned(crate::lower::expr::internal_bug_f(&crate::prelude::Text::lit("a pure building choice that is no `match` and no `if` with an `else`")), t_p3.clone()),
    }
}

/// The step machine of `PureChoiceValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PureChoiceValue: unbounded fn Lx, Env, Expr -> Vl
/// ```
pub struct PureChoiceValue {
    pub lx_p0: crate::lower::Lx,
    pub benv_p1: crate::lower::types::Env,
    pub e_p2: crate::syntax::Expr,
}

impl ::prism_rtl::Job<crate::lower::types::Vl> for PureChoiceValue {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::lower::types::Vl> {
        let lx_p0 = &self.lx_p0;
        let benv_p1 = &self.benv_p1;
        let e_p2 = &self.e_p2;
        let benv_p1x = benv_p1.clone();
        let e_p2x = e_p2.clone();
        let lx_p0x = lx_p0.clone();
        crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0x.clone(), crate::lower::types::out_of_f(&crate::lower::type_at_f(&lx_p0x, &e_p2x.span_p))), move |out_ty_of_f_16355: crate::lower::model::OutTy| {
            let t_p3 = out_ty_of_f_16355;
            match &*crate::lower::node_::static_::ungrouped_f(&e_p2x).kind_p {
                crate::syntax::ExprKind::EMatch(s_p4, arms_p5) => {
                    let arms_p5x = arms_p5.clone();
                    let s_p4x = (**s_p4).clone();
                    crate::prelude::call_value(crate::prelude::each_job(arms_p5x.clone(), {
                        let lx_p0xx = lx_p0x.clone();
                        ::std::rc::Rc::new(move |p0: crate::syntax::Arm| {
                            let lx_p0xxy = lx_p0xx.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let a_p6 = p0;
                                ::prism_rtl::Turn::Finished(pure_arm_of_f(&lx_p0xxy, &a_p6))
                            }))
                        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::syntax::Arm) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::syntax::Arm>>>
                    }), move |each_16474: crate::prelude::Array<crate::syntax::Arm>| ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::lower::expr::MatchValue { lx_p0: lx_p0x.clone(), env_p1: benv_p1x.clone(), s_p2: s_p4x.clone(), arms_p3: each_16474, t_p4: t_p3.clone(), span_p5: e_p2x.span_p.clone() })))
                },
                crate::syntax::ExprKind::EIf(c_p7, then_b_p8, ::std::option::Option::Some(else_b_p9)) => {
                    let c_p7x = (**c_p7).clone();
                    let else_b_p9x = else_b_p9.clone();
                    let then_b_p8x = then_b_p8.clone();
                    crate::prelude::call_then(start_pure_arm_f(lx_p0x.clone(), then_b_p8x.clone()), move |pure_arm_f_16573: crate::syntax::Block| ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::lower::expr::IfValue { lx_p0: lx_p0x.clone(), env_p1: benv_p1x.clone(), c_p2: c_p7x.clone(), then_b_p3: pure_arm_f_16573, else_b_o4: ::std::option::Option::Some(pure_arm_f(&lx_p0x, &else_b_p9x)), t_p5: t_p3.clone() })))
                },
                _ => ::prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::expr::internal_bug_f(&crate::prelude::Text::lit("a pure building choice that is no `match` and no `if` with an `else`")), t_p3.clone())),
            }
        })
    }
}

/// `Start PureChoiceValue, x`: what the function value is when passed to `@Run`.
pub fn start_pure_choice_value_f(lx_p0: crate::lower::Lx, benv_p1: crate::lower::types::Env, e_p2: crate::syntax::Expr) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::types::Vl>> {
    ::std::rc::Rc::new(PureChoiceValue { lx_p0, benv_p1, e_p2 })
}

/// ```prism
/// PureArmOf: unbounded fn Lx, Arm -> Arm
/// ```
pub fn pure_arm_of_f(lx_p0: &crate::lower::Lx, a_p1: &crate::syntax::Arm) -> crate::syntax::Arm {
    crate::syntax::Arm { pattern_o: a_p1.pattern_o.clone(), guard_o: a_p1.guard_o.clone(), body_p: pure_arm_f(lx_p0, &a_p1.body_p), span_p: a_p1.span_p.clone() }
}

/// ```prism
/// PureChoiceKey: fn Expr -> Text
/// ```
pub fn pure_choice_key_f(e_p0: &crate::syntax::Expr) -> crate::prelude::Text {
    crate::prelude::Text::from(format!("pure:{}", &init_key_f(&crate::lower::node_::static_::ungrouped_f(e_p0))))
}

/// ```prism
/// PureChoiceStmtKey: fn Stmt -> Text
/// ```
pub fn pure_choice_stmt_key_f(s_p0: &crate::syntax::Stmt) -> crate::prelude::Text {
    match &s_p0.kind_p {
        crate::syntax::StmtKind::SBind(_, e_p1, ::std::option::Option::None) => pure_choice_key_f(e_p1),
        _ => crate::prelude::Text::lit(""),
    }
}

/// ```prism
/// EarlyChoiceKey: fn Stmt -> Text
/// ```
pub fn early_choice_key_f(s_p0: &crate::syntax::Stmt) -> crate::prelude::Text {
    match &s_p0.kind_p {
        crate::syntax::StmtKind::SBind(_, e_p1, ::std::option::Option::None) => init_key_f(&crate::lower::node_::static_::ungrouped_f(e_p1)),
        _ => crate::prelude::Text::lit(""),
    }
}

/// ```prism
/// TakesAtBuild: unbounded fn Lx, Stmt, [Text] -> Bool
/// ```
pub fn takes_at_build_f(lx_p0: &crate::lower::Lx, st_p1: &crate::syntax::Stmt, names_p2: &crate::prelude::Array<crate::prelude::Text>) -> bool {
    let line_o3 = match &st_p1.kind_p {
        crate::syntax::StmtKind::SBind(_, e_p4, ::std::option::Option::None) => ::std::option::Option::Some(e_p4.clone()),
        crate::syntax::StmtKind::SIgnore(e_p5) => ::std::option::Option::Some(e_p5.clone()),
        crate::syntax::StmtKind::SExpr(e_p6) => ::std::option::Option::Some(e_p6.clone()),
        _ => ::std::option::Option::None,
    };
    match &line_o3 {
        ::std::option::Option::Some(e_p7) => {
            let tag_name_p8 = match &*crate::lower::node_::static_::ungrouped_f(e_p7).kind_p {
                crate::syntax::ExprKind::ECall(c_pa, _, _, _) => crate::lower::node_::elements::tag_name_of_f(lx_p0, &**c_pa),
                crate::syntax::ExprKind::EName(_) => crate::lower::node_::elements::tag_name_of_f(lx_p0, &crate::lower::node_::static_::ungrouped_f(e_p7)),
                _ => crate::prelude::Text::lit(""),
            };
            let placed_p9 = match crate::prelude::get(&lx_p0.g_p.tags_p, &tag_name_p8) {
                ::std::option::Option::Some(tg_pb) => &tg_pb.kind_p == &crate::prelude::Text::lit("Element"),
                ::std::option::Option::None => false,
            };
            !placed_p9 && crate::prelude::fold(&reads_of_line_f(st_p1), &false, &(|f_pc: &bool, n_pd: &crate::prelude::Text| *f_pc || crate::check::types::has_text_f(names_p2, n_pd)))
        },
        ::std::option::Option::None => false,
    }
}

/// The step machine of `TakesAtBuild`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TakesAtBuild: unbounded fn Lx, Stmt, [Text] -> Bool
/// ```
pub struct TakesAtBuild {
    pub lx_p0: crate::lower::Lx,
    pub st_p1: crate::syntax::Stmt,
    pub names_p2: crate::prelude::Array<crate::prelude::Text>,
}

impl ::prism_rtl::Job<bool> for TakesAtBuild {
    fn cycle(&self) -> ::prism_rtl::Turn<bool> {
        let lx_p0 = &self.lx_p0;
        let st_p1 = &self.st_p1;
        let names_p2 = &self.names_p2;
        let line_o3 = match &st_p1.kind_p {
            crate::syntax::StmtKind::SBind(_, e_p4, ::std::option::Option::None) => ::std::option::Option::Some(e_p4.clone()),
            crate::syntax::StmtKind::SIgnore(e_p5) => ::std::option::Option::Some(e_p5.clone()),
            crate::syntax::StmtKind::SExpr(e_p6) => ::std::option::Option::Some(e_p6.clone()),
            _ => ::std::option::Option::None,
        };
        match &line_o3 {
            ::std::option::Option::Some(e_p7) => {
                let tag_name_p8 = match &*crate::lower::node_::static_::ungrouped_f(e_p7).kind_p {
                    crate::syntax::ExprKind::ECall(c_pa, _, _, _) => crate::lower::node_::elements::tag_name_of_f(lx_p0, &**c_pa),
                    crate::syntax::ExprKind::EName(_) => crate::lower::node_::elements::tag_name_of_f(lx_p0, &crate::lower::node_::static_::ungrouped_f(e_p7)),
                    _ => crate::prelude::Text::lit(""),
                };
                let placed_p9 = match crate::prelude::get(&lx_p0.g_p.tags_p, &tag_name_p8) {
                    ::std::option::Option::Some(tg_pb) => &tg_pb.kind_p == &crate::prelude::Text::lit("Element"),
                    ::std::option::Option::None => false,
                };
                if !placed_p9 {
                    {
                        let names_p2x = names_p2.clone();
                        let st_p1x = st_p1.clone();
                        crate::prelude::call_then(start_reads_of_line_f(st_p1x.clone()), move |reads_of_line_f_18167: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::prelude::fold(&reads_of_line_f_18167, &false, &(|f_pc: &bool, n_pd: &crate::prelude::Text| *f_pc || crate::check::types::has_text_f(&names_p2x, n_pd)))))
                    }
                } else {
                    ::prism_rtl::Turn::Finished(false)
                }
            },
            ::std::option::Option::None => ::prism_rtl::Turn::Finished(false),
        }
    }
}

/// `Start TakesAtBuild, x`: what the function value is when passed to `@Run`.
pub fn start_takes_at_build_f(lx_p0: crate::lower::Lx, st_p1: crate::syntax::Stmt, names_p2: crate::prelude::Array<crate::prelude::Text>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>> {
    ::std::rc::Rc::new(TakesAtBuild { lx_p0, st_p1, names_p2 })
}

/// ```prism
/// WithElementLets: unbounded fn Lx, Env, Env, Block -> ((Env, Env))
/// ```
pub fn with_element_lets_f(lx_p0: &crate::lower::Lx, benv_p1: &crate::lower::types::Env, menv_p2: &crate::lower::types::Env, b_p3: &crate::syntax::Block) -> (crate::lower::types::Env, crate::lower::types::Env) {
    crate::prelude::run_to_end(crate::prelude::fold_job(b_p3.stmts_p.clone(), (benv_p1.clone(), menv_p2.clone()), {
        let lx_p0x = lx_p0.clone();
        let b_p3x = b_p3.clone();
        ::std::rc::Rc::new(move |(p0, p1): ((crate::lower::types::Env, crate::lower::types::Env), crate::syntax::Stmt)| {
            let lx_p0xy = lx_p0x.clone();
            let b_p3xy = b_p3x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (be_p4, me_p5) = p0;
                let s_p6 = p1;
                match &s_p6.kind_p {
                    crate::syntax::StmtKind::SLet(p_p7, _, e_p8) => match &*p_p7.kind_p {
                        crate::syntax::PatternKind::PName(n_p9) => if &crate::lower::types::layer_of_f(&crate::lower::binder_ty_f(&lx_p0xy, &n_p9.span_p)) == &crate::lower::types::Layer::LyBlueprint {
                            {
                                let held_pa = crate::lower::types::Bn::BnWidget(crate::lower::node_::static_::ungrouped_f(e_p8), crate::lower::types::empty_env_p(), crate::lower::types::empty_env_p(), lx_p0xy.clone());
                                let nkey_pb = crate::check::env::sname_key_f(n_p9);
                                ::prism_rtl::Turn::Finished((crate::lower::types::bind_f(&crate::lower::types::bind_f(&be_p4, &crate::prelude::Text::from(format!("{}#blueprint", &nkey_pb)), &held_pa), &crate::prelude::Text::from(format!("{}#placed", &nkey_pb)), &held_pa), crate::lower::types::bind_f(&crate::lower::types::bind_f(&me_p5, &crate::prelude::Text::from(format!("{}#blueprint", &nkey_pb)), &held_pa), &crate::prelude::Text::from(format!("{}#placed", &nkey_pb)), &held_pa)))
                            }
                        } else {
                            {
                                let e_p8x = e_p8.clone();
                                let n_p9x = n_p9.clone();
                                crate::prelude::call_then(crate::lower::node_::static_::start_is_tag_application_f(lx_p0xy.clone(), e_p8x.clone()), move |is_tag_application_f_19769: bool| if !is_tag_application_f_19769 {
                                    ::prism_rtl::Turn::Finished((be_p4.clone(), me_p5.clone()))
                                } else {
                                    {
                                        let nkey_pc = crate::check::env::sname_key_f(&n_p9x);
                                        let held_pd = crate::lower::types::Bn::BnWidget(crate::lower::node_::static_::ungrouped_f(&e_p8x), crate::lower::types::empty_env_p(), crate::lower::types::empty_env_p(), lx_p0xy.clone());
                                        crate::prelude::call_value(crate::prelude::filter_job(b_p3xy.stmts_p.clone(), {
                                            let nkey_pcx = nkey_pc.clone();
                                            let lx_p0xyx = lx_p0xy.clone();
                                            ::std::rc::Rc::new(move |p0: crate::syntax::Stmt| {
                                                let nkey_pcxy = nkey_pcx.clone();
                                                let lx_p0xyxy = lx_p0xyx.clone();
                                                crate::prelude::entered(crate::prelude::once_job(move || {
                                                    let st_ph = p0;
                                                    crate::prelude::call_then(start_reads_of_line_f(st_ph.clone()), move |reads_of_line_f_19996: crate::prelude::Array<crate::prelude::Text>| if crate::check::types::has_text_f(&reads_of_line_f_19996, &nkey_pcxy) {
                                                        crate::prelude::call_then(start_placed_name_o(lx_p0xyxy.clone(), st_ph.clone()), move |placed_name_o_20024: ::std::option::Option<crate::prelude::Text>| ::prism_rtl::Turn::Finished(&placed_name_o_20024 != &::std::option::Option::Some(nkey_pcxy.clone())))
                                                    } else {
                                                        ::prism_rtl::Turn::Finished(false)
                                                    })
                                                }))
                                            }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::syntax::Stmt) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
                                        }), move |filter_19964: crate::prelude::Array<crate::syntax::Stmt>| {
                                            let others_pe = filter_19964;
                                            let be1_pf = crate::lower::types::bind_f(&be_p4, &crate::prelude::Text::from(format!("{}#element", &nkey_pc)), &held_pd);
                                            let me1_pg = crate::lower::types::bind_f(&me_p5, &crate::prelude::Text::from(format!("{}#element", &nkey_pc)), &held_pd);
                                            if &crate::prelude::len(&others_pe) == &crate::prelude::Nat::from(0u32) {
                                                ::prism_rtl::Turn::Finished((crate::lower::types::bind_f(&be1_pf, &crate::prelude::Text::from(format!("{}#placed", &nkey_pc)), &held_pd), crate::lower::types::bind_f(&me1_pg, &crate::prelude::Text::from(format!("{}#placed", &nkey_pc)), &held_pd)))
                                            } else {
                                                ::prism_rtl::Turn::Finished((be1_pf.clone(), me1_pg.clone()))
                                            }
                                        })
                                    }
                                })
                            }
                        },
                        _ => ::prism_rtl::Turn::Finished((be_p4.clone(), me_p5.clone())),
                    },
                    _ => ::prism_rtl::Turn::Finished((be_p4.clone(), me_p5.clone())),
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::lower::types::Env, crate::lower::types::Env), crate::syntax::Stmt)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::types::Env, crate::lower::types::Env)>>>
    }))
}

/// The step machine of `WithElementLets`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// WithElementLets: unbounded fn Lx, Env, Env, Block -> ((Env, Env))
/// ```
pub struct WithElementLets {
    pub lx_p0: crate::lower::Lx,
    pub benv_p1: crate::lower::types::Env,
    pub menv_p2: crate::lower::types::Env,
    pub b_p3: crate::syntax::Block,
}

impl ::prism_rtl::Job<(crate::lower::types::Env, crate::lower::types::Env)> for WithElementLets {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::lower::types::Env, crate::lower::types::Env)> {
        let lx_p0 = &self.lx_p0;
        let benv_p1 = &self.benv_p1;
        let menv_p2 = &self.menv_p2;
        let b_p3 = &self.b_p3;
        crate::prelude::fold_job(b_p3.stmts_p.clone(), (benv_p1.clone(), menv_p2.clone()), {
            let lx_p0x = lx_p0.clone();
            let b_p3x = b_p3.clone();
            ::std::rc::Rc::new(move |(p0, p1): ((crate::lower::types::Env, crate::lower::types::Env), crate::syntax::Stmt)| {
                let lx_p0xy = lx_p0x.clone();
                let b_p3xy = b_p3x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let (be_p4, me_p5) = p0;
                    let s_p6 = p1;
                    match &s_p6.kind_p {
                        crate::syntax::StmtKind::SLet(p_p7, _, e_p8) => match &*p_p7.kind_p {
                            crate::syntax::PatternKind::PName(n_p9) => if &crate::lower::types::layer_of_f(&crate::lower::binder_ty_f(&lx_p0xy, &n_p9.span_p)) == &crate::lower::types::Layer::LyBlueprint {
                                {
                                    let held_pa = crate::lower::types::Bn::BnWidget(crate::lower::node_::static_::ungrouped_f(e_p8), crate::lower::types::empty_env_p(), crate::lower::types::empty_env_p(), lx_p0xy.clone());
                                    let nkey_pb = crate::check::env::sname_key_f(n_p9);
                                    ::prism_rtl::Turn::Finished((crate::lower::types::bind_f(&crate::lower::types::bind_f(&be_p4, &crate::prelude::Text::from(format!("{}#blueprint", &nkey_pb)), &held_pa), &crate::prelude::Text::from(format!("{}#placed", &nkey_pb)), &held_pa), crate::lower::types::bind_f(&crate::lower::types::bind_f(&me_p5, &crate::prelude::Text::from(format!("{}#blueprint", &nkey_pb)), &held_pa), &crate::prelude::Text::from(format!("{}#placed", &nkey_pb)), &held_pa)))
                                }
                            } else {
                                {
                                    let e_p8x = e_p8.clone();
                                    let n_p9x = n_p9.clone();
                                    crate::prelude::call_then(crate::lower::node_::static_::start_is_tag_application_f(lx_p0xy.clone(), e_p8x.clone()), move |is_tag_application_f_19769: bool| if !is_tag_application_f_19769 {
                                        ::prism_rtl::Turn::Finished((be_p4.clone(), me_p5.clone()))
                                    } else {
                                        {
                                            let nkey_pc = crate::check::env::sname_key_f(&n_p9x);
                                            let held_pd = crate::lower::types::Bn::BnWidget(crate::lower::node_::static_::ungrouped_f(&e_p8x), crate::lower::types::empty_env_p(), crate::lower::types::empty_env_p(), lx_p0xy.clone());
                                            crate::prelude::call_value(crate::prelude::filter_job(b_p3xy.stmts_p.clone(), {
                                                let nkey_pcx = nkey_pc.clone();
                                                let lx_p0xyx = lx_p0xy.clone();
                                                ::std::rc::Rc::new(move |p0: crate::syntax::Stmt| {
                                                    let nkey_pcxy = nkey_pcx.clone();
                                                    let lx_p0xyxy = lx_p0xyx.clone();
                                                    crate::prelude::entered(crate::prelude::once_job(move || {
                                                        let st_ph = p0;
                                                        crate::prelude::call_then(start_reads_of_line_f(st_ph.clone()), move |reads_of_line_f_19996: crate::prelude::Array<crate::prelude::Text>| if crate::check::types::has_text_f(&reads_of_line_f_19996, &nkey_pcxy) {
                                                            crate::prelude::call_then(start_placed_name_o(lx_p0xyxy.clone(), st_ph.clone()), move |placed_name_o_20024: ::std::option::Option<crate::prelude::Text>| ::prism_rtl::Turn::Finished(&placed_name_o_20024 != &::std::option::Option::Some(nkey_pcxy.clone())))
                                                        } else {
                                                            ::prism_rtl::Turn::Finished(false)
                                                        })
                                                    }))
                                                }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::syntax::Stmt) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
                                            }), move |filter_19964: crate::prelude::Array<crate::syntax::Stmt>| {
                                                let others_pe = filter_19964;
                                                let be1_pf = crate::lower::types::bind_f(&be_p4, &crate::prelude::Text::from(format!("{}#element", &nkey_pc)), &held_pd);
                                                let me1_pg = crate::lower::types::bind_f(&me_p5, &crate::prelude::Text::from(format!("{}#element", &nkey_pc)), &held_pd);
                                                if &crate::prelude::len(&others_pe) == &crate::prelude::Nat::from(0u32) {
                                                    ::prism_rtl::Turn::Finished((crate::lower::types::bind_f(&be1_pf, &crate::prelude::Text::from(format!("{}#placed", &nkey_pc)), &held_pd), crate::lower::types::bind_f(&me1_pg, &crate::prelude::Text::from(format!("{}#placed", &nkey_pc)), &held_pd)))
                                                } else {
                                                    ::prism_rtl::Turn::Finished((be1_pf.clone(), me1_pg.clone()))
                                                }
                                            })
                                        }
                                    })
                                }
                            },
                            _ => ::prism_rtl::Turn::Finished((be_p4.clone(), me_p5.clone())),
                        },
                        _ => ::prism_rtl::Turn::Finished((be_p4.clone(), me_p5.clone())),
                    }
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::lower::types::Env, crate::lower::types::Env), crate::syntax::Stmt)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::types::Env, crate::lower::types::Env)>>>
        }).cycle()
    }
}

/// `Start WithElementLets, x`: what the function value is when passed to `@Run`.
pub fn start_with_element_lets_f(lx_p0: crate::lower::Lx, benv_p1: crate::lower::types::Env, menv_p2: crate::lower::types::Env, b_p3: crate::syntax::Block) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::types::Env, crate::lower::types::Env)>> {
    ::std::rc::Rc::new(WithElementLets { lx_p0, benv_p1, menv_p2, b_p3 })
}

/// ```prism
/// ?PlacedName: unbounded fn Lx, Stmt -> ?Text
/// ```
pub fn placed_name_o(lx_p0: &crate::lower::Lx, s_p1: &crate::syntax::Stmt) -> ::std::option::Option<crate::prelude::Text> {
    let line_o5 = match &s_p1.kind_p {
        crate::syntax::StmtKind::SBind(_, e_p2, ::std::option::Option::None) => ::std::option::Option::Some(e_p2.clone()),
        crate::syntax::StmtKind::SIgnore(e_p3) => ::std::option::Option::Some(e_p3.clone()),
        crate::syntax::StmtKind::SExpr(e_p4) => ::std::option::Option::Some(e_p4.clone()),
        _ => ::std::option::Option::None,
    };
    match &line_o5 {
        ::std::option::Option::Some(e_p6) => match &*crate::lower::node_::static_::ungrouped_f(e_p6).kind_p {
            crate::syntax::ExprKind::ECall(c_p7, args_p8, _, _) => if &crate::lower::node_::dynamics::callee_key_f(lx_p0, &**c_p7) != &crate::prelude::Text::lit("Prelude.@Element") {
                ::std::option::Option::None
            } else {
                match crate::prelude::index(args_p8, &crate::prelude::Nat::from(0u32)) {
                    ::std::option::Option::Some(a_p9) => match &*crate::lower::node_::static_::ungrouped_f(&a_p9.value_p).kind_p {
                        crate::syntax::ExprKind::EName(n_pa) => if &crate::prelude::len(&n_pa.path_p) == &crate::prelude::Nat::from(1u32) {
                            ::std::option::Option::Some(crate::check::env::sname_key_f(n_pa))
                        } else {
                            ::std::option::Option::None
                        },
                        _ => ::std::option::Option::None,
                    },
                    ::std::option::Option::None => ::std::option::Option::None,
                }
            },
            _ => ::std::option::Option::None,
        },
        ::std::option::Option::None => ::std::option::Option::None,
    }
}

/// The step machine of `PlacedName`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?PlacedName: unbounded fn Lx, Stmt -> ?Text
/// ```
pub struct PlacedName {
    pub lx_p0: crate::lower::Lx,
    pub s_p1: crate::syntax::Stmt,
}

impl ::prism_rtl::Job<::std::option::Option<crate::prelude::Text>> for PlacedName {
    fn cycle(&self) -> ::prism_rtl::Turn<::std::option::Option<crate::prelude::Text>> {
        let lx_p0 = &self.lx_p0;
        let s_p1 = &self.s_p1;
        let line_o5 = match &s_p1.kind_p {
            crate::syntax::StmtKind::SBind(_, e_p2, ::std::option::Option::None) => ::std::option::Option::Some(e_p2.clone()),
            crate::syntax::StmtKind::SIgnore(e_p3) => ::std::option::Option::Some(e_p3.clone()),
            crate::syntax::StmtKind::SExpr(e_p4) => ::std::option::Option::Some(e_p4.clone()),
            _ => ::std::option::Option::None,
        };
        match &line_o5 {
            ::std::option::Option::Some(e_p6) => match &*crate::lower::node_::static_::ungrouped_f(e_p6).kind_p {
                crate::syntax::ExprKind::ECall(c_p7, args_p8, _, _) => if &crate::lower::node_::dynamics::callee_key_f(lx_p0, &**c_p7) != &crate::prelude::Text::lit("Prelude.@Element") {
                    ::prism_rtl::Turn::Finished(::std::option::Option::None)
                } else {
                    match crate::prelude::index(args_p8, &crate::prelude::Nat::from(0u32)) {
                        ::std::option::Option::Some(a_p9) => match &*crate::lower::node_::static_::ungrouped_f(&a_p9.value_p).kind_p {
                            crate::syntax::ExprKind::EName(n_pa) => if &crate::prelude::len(&n_pa.path_p) == &crate::prelude::Nat::from(1u32) {
                                ::prism_rtl::Turn::Finished(::std::option::Option::Some(crate::check::env::sname_key_f(n_pa)))
                            } else {
                                ::prism_rtl::Turn::Finished(::std::option::Option::None)
                            },
                            _ => ::prism_rtl::Turn::Finished(::std::option::Option::None),
                        },
                        ::std::option::Option::None => ::prism_rtl::Turn::Finished(::std::option::Option::None),
                    }
                },
                _ => ::prism_rtl::Turn::Finished(::std::option::Option::None),
            },
            ::std::option::Option::None => ::prism_rtl::Turn::Finished(::std::option::Option::None),
        }
    }
}

/// `Start PlacedName, x`: what the function value is when passed to `@Run`.
pub fn start_placed_name_o(lx_p0: crate::lower::Lx, s_p1: crate::syntax::Stmt) -> ::std::rc::Rc<dyn ::prism_rtl::Job<::std::option::Option<crate::prelude::Text>>> {
    ::std::rc::Rc::new(PlacedName { lx_p0, s_p1 })
}

/// ```prism
/// IsPlacedLet: fn Env, Pattern -> Bool
/// ```
pub fn is_placed_let_f(menv_p0: &crate::lower::types::Env, p_p1: &crate::syntax::Pattern) -> bool {
    match &*p_p1.kind_p {
        crate::syntax::PatternKind::PName(n_p2) => crate::check::env::has_key_f(&menv_p0.names_p, &crate::prelude::Text::from(format!("{}#placed", &crate::check::env::sname_key_f(n_p2)))),
        _ => false,
    }
}

/// ```prism
/// ?BundleLetName: unbounded fn Lx, Stmt -> ?Text
/// ```
pub fn bundle_let_name_o(lx_p0: &crate::lower::Lx, s_p1: &crate::syntax::Stmt) -> ::std::option::Option<crate::prelude::Text> {
    match &s_p1.kind_p {
        crate::syntax::StmtKind::SLet(p_p2, _, _) => match one_name_o(p_p2) {
            ::std::option::Option::Some(n_p3) => if crate::lower::types::is_bundle_f(&crate::lower::binder_ty_f(&crate::lower::expr::widget_let_lx_f(lx_p0, &n_p3.span_p), &n_p3.span_p)) {
                ::std::option::Option::Some(crate::check::env::sname_key_f(&n_p3))
            } else {
                ::std::option::Option::None
            },
            ::std::option::Option::None => ::std::option::Option::None,
        },
        _ => ::std::option::Option::None,
    }
}

/// The step machine of `BundleLetName`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?BundleLetName: unbounded fn Lx, Stmt -> ?Text
/// ```
pub struct BundleLetName {
    pub lx_p0: crate::lower::Lx,
    pub s_p1: crate::syntax::Stmt,
}

impl ::prism_rtl::Job<::std::option::Option<crate::prelude::Text>> for BundleLetName {
    fn cycle(&self) -> ::prism_rtl::Turn<::std::option::Option<crate::prelude::Text>> {
        let lx_p0 = &self.lx_p0;
        let s_p1 = &self.s_p1;
        match &s_p1.kind_p {
            crate::syntax::StmtKind::SLet(p_p2, _, _) => match one_name_o(p_p2) {
                ::std::option::Option::Some(n_p3) => {
                    let lx_p0x = lx_p0.clone();
                    crate::prelude::call_then(crate::lower::expr::start_widget_let_lx_f(lx_p0x.clone(), n_p3.span_p.clone()), move |widget_let_lx_f_21595: crate::lower::Lx| if crate::lower::types::is_bundle_f(&crate::lower::binder_ty_f(&widget_let_lx_f_21595, &n_p3.span_p)) {
                        ::prism_rtl::Turn::Finished(::std::option::Option::Some(crate::check::env::sname_key_f(&n_p3)))
                    } else {
                        ::prism_rtl::Turn::Finished(::std::option::Option::None)
                    })
                },
                ::std::option::Option::None => ::prism_rtl::Turn::Finished(::std::option::Option::None),
            },
            _ => ::prism_rtl::Turn::Finished(::std::option::Option::None),
        }
    }
}

/// `Start BundleLetName, x`: what the function value is when passed to `@Run`.
pub fn start_bundle_let_name_o(lx_p0: crate::lower::Lx, s_p1: crate::syntax::Stmt) -> ::std::rc::Rc<dyn ::prism_rtl::Job<::std::option::Option<crate::prelude::Text>>> {
    ::std::rc::Rc::new(BundleLetName { lx_p0, s_p1 })
}

/// ```prism
/// BundleLetsEarly: unbounded fn Lx, [Stmt], Nat -> [Stmt]
/// ```
pub fn bundle_lets_early_f(lx_p0: &crate::lower::Lx, stmts_p1: &crate::prelude::Array<crate::syntax::Stmt>, fuel_p2: &crate::prelude::Nat) -> crate::prelude::Array<crate::syntax::Stmt> {
    let move_o3 = crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(stmts_p1)), ::std::option::Option::None, {
        let lx_p0x = lx_p0.clone();
        let stmts_p1x = stmts_p1.clone();
        ::std::rc::Rc::new(move |(p0, p1): (::std::option::Option<(crate::prelude::Nat, crate::prelude::Nat)>, crate::prelude::Nat)| {
            let lx_p0xy = lx_p0x.clone();
            let stmts_p1xy = stmts_p1x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let found_o4 = p0;
                let i_p5 = p1;
                if crate::lower::node_::switch_::is_some_f(&found_o4) {
                    ::prism_rtl::Turn::Finished(found_o4.clone())
                } else {
                    crate::prelude::call_then(start_bundle_let_name_o(lx_p0xy.clone(), crate::prelude::or(&crate::prelude::index(&stmts_p1xy, &i_p5), &crate::lower::expr::dummy_stmt_l_p())), move |bundle_let_name_o_22461: ::std::option::Option<crate::prelude::Text>| match bundle_let_name_o_22461 {
                        ::std::option::Option::Some(nkey_p6) => crate::prelude::fold_job(crate::check::errors::range0_f(&i_p5), ::std::option::Option::None, {
                            let stmts_p1xyx = stmts_p1xy.clone();
                            let nkey_p6x = nkey_p6.clone();
                            let i_p5x = i_p5.clone();
                            ::std::rc::Rc::new(move |(p0, p1): (::std::option::Option<(crate::prelude::Nat, crate::prelude::Nat)>, crate::prelude::Nat)| {
                                let stmts_p1xyxy = stmts_p1xyx.clone();
                                let nkey_p6xy = nkey_p6x.clone();
                                let i_p5xy = i_p5x.clone();
                                crate::prelude::entered(crate::prelude::once_job(move || {
                                    let first_o7 = p0;
                                    let j_p8 = p1;
                                    if crate::lower::node_::switch_::is_some_f(&first_o7) {
                                        ::prism_rtl::Turn::Finished(first_o7.clone())
                                    } else {
                                        crate::prelude::call_then(start_reads_of_line_f(crate::prelude::or(&crate::prelude::index(&stmts_p1xyxy, &j_p8), &crate::lower::expr::dummy_stmt_l_p())), move |reads_of_line_f_22601: crate::prelude::Array<crate::prelude::Text>| if crate::check::types::has_text_f(&reads_of_line_f_22601, &nkey_p6xy) {
                                            ::prism_rtl::Turn::Finished(::std::option::Option::Some((i_p5xy.clone(), j_p8.clone())))
                                        } else {
                                            ::prism_rtl::Turn::Finished(::std::option::Option::None)
                                        })
                                    }
                                }))
                            }) as ::std::rc::Rc<dyn ::std::ops::Fn((::std::option::Option<(crate::prelude::Nat, crate::prelude::Nat)>, crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<::std::option::Option<(crate::prelude::Nat, crate::prelude::Nat)>>>>
                        }).cycle(),
                        ::std::option::Option::None => ::prism_rtl::Turn::Finished(::std::option::Option::None),
                    })
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((::std::option::Option<(crate::prelude::Nat, crate::prelude::Nat)>, crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<::std::option::Option<(crate::prelude::Nat, crate::prelude::Nat)>>>>
    }));
    match &move_o3 {
        ::std::option::Option::Some((i_p9, j_pa)) if (fuel_p2 > &crate::prelude::Nat::from(0u32)) => {
            let moved_pb = crate::prelude::or(&crate::prelude::index(stmts_p1, i_p9), &crate::lower::expr::dummy_stmt_l_p());
            bundle_lets_early_f(lx_p0, &crate::prelude::append(&crate::prelude::push(&crate::prelude::take(stmts_p1, j_pa), &moved_pb), &crate::prelude::filter(&crate::prelude::drop(stmts_p1, j_pa), &(|st_pc: &crate::syntax::Stmt| !has_stmt_f(&crate::prelude::Array::from(vec![moved_pb.clone()]), st_pc)))), &crate::syntax::lexer::chars::dec_f(fuel_p2))
        },
        _ => stmts_p1.clone(),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `BundleLetsEarly`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BundleLetsEarly: unbounded fn Lx, [Stmt], Nat -> [Stmt]
/// ```
pub struct BundleLetsEarly {
    pub lx_p0: crate::lower::Lx,
    pub stmts_p1: crate::prelude::Array<crate::syntax::Stmt>,
    pub fuel_p2: crate::prelude::Nat,
}

impl ::prism_rtl::Job<crate::prelude::Array<crate::syntax::Stmt>> for BundleLetsEarly {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<crate::syntax::Stmt>> {
        let lx_p0 = &self.lx_p0;
        let stmts_p1 = &self.stmts_p1;
        let fuel_p2 = &self.fuel_p2;
        let fuel_p2x = fuel_p2.clone();
        let lx_p0x = lx_p0.clone();
        let stmts_p1x = stmts_p1.clone();
        crate::prelude::call_value(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(&stmts_p1x)), ::std::option::Option::None, {
            let lx_p0xx = lx_p0x.clone();
            let stmts_p1xx = stmts_p1x.clone();
            ::std::rc::Rc::new(move |(p0, p1): (::std::option::Option<(crate::prelude::Nat, crate::prelude::Nat)>, crate::prelude::Nat)| {
                let lx_p0xxy = lx_p0xx.clone();
                let stmts_p1xxy = stmts_p1xx.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let found_o4 = p0;
                    let i_p5 = p1;
                    if crate::lower::node_::switch_::is_some_f(&found_o4) {
                        ::prism_rtl::Turn::Finished(found_o4.clone())
                    } else {
                        crate::prelude::call_then(start_bundle_let_name_o(lx_p0xxy.clone(), crate::prelude::or(&crate::prelude::index(&stmts_p1xxy, &i_p5), &crate::lower::expr::dummy_stmt_l_p())), move |bundle_let_name_o_22461: ::std::option::Option<crate::prelude::Text>| match bundle_let_name_o_22461 {
                            ::std::option::Option::Some(nkey_p6) => crate::prelude::fold_job(crate::check::errors::range0_f(&i_p5), ::std::option::Option::None, {
                                let stmts_p1xxyx = stmts_p1xxy.clone();
                                let nkey_p6x = nkey_p6.clone();
                                let i_p5x = i_p5.clone();
                                ::std::rc::Rc::new(move |(p0, p1): (::std::option::Option<(crate::prelude::Nat, crate::prelude::Nat)>, crate::prelude::Nat)| {
                                    let stmts_p1xxyxy = stmts_p1xxyx.clone();
                                    let nkey_p6xy = nkey_p6x.clone();
                                    let i_p5xy = i_p5x.clone();
                                    crate::prelude::entered(crate::prelude::once_job(move || {
                                        let first_o7 = p0;
                                        let j_p8 = p1;
                                        if crate::lower::node_::switch_::is_some_f(&first_o7) {
                                            ::prism_rtl::Turn::Finished(first_o7.clone())
                                        } else {
                                            crate::prelude::call_then(start_reads_of_line_f(crate::prelude::or(&crate::prelude::index(&stmts_p1xxyxy, &j_p8), &crate::lower::expr::dummy_stmt_l_p())), move |reads_of_line_f_22601: crate::prelude::Array<crate::prelude::Text>| if crate::check::types::has_text_f(&reads_of_line_f_22601, &nkey_p6xy) {
                                                ::prism_rtl::Turn::Finished(::std::option::Option::Some((i_p5xy.clone(), j_p8.clone())))
                                            } else {
                                                ::prism_rtl::Turn::Finished(::std::option::Option::None)
                                            })
                                        }
                                    }))
                                }) as ::std::rc::Rc<dyn ::std::ops::Fn((::std::option::Option<(crate::prelude::Nat, crate::prelude::Nat)>, crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<::std::option::Option<(crate::prelude::Nat, crate::prelude::Nat)>>>>
                            }).cycle(),
                            ::std::option::Option::None => ::prism_rtl::Turn::Finished(::std::option::Option::None),
                        })
                    }
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((::std::option::Option<(crate::prelude::Nat, crate::prelude::Nat)>, crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<::std::option::Option<(crate::prelude::Nat, crate::prelude::Nat)>>>>
        }), move |fold_22379: ::std::option::Option<(crate::prelude::Nat, crate::prelude::Nat)>| {
            let move_o3 = fold_22379;
            match &move_o3 {
                ::std::option::Option::Some((i_p9, j_pa)) if (&fuel_p2x > &crate::prelude::Nat::from(0u32)) => {
                    let moved_pb = crate::prelude::or(&crate::prelude::index(&stmts_p1x, i_p9), &crate::lower::expr::dummy_stmt_l_p());
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(BundleLetsEarly { lx_p0: lx_p0x.clone(), stmts_p1: crate::prelude::append(&crate::prelude::push(&crate::prelude::take(&stmts_p1x, j_pa), &moved_pb), &crate::prelude::filter(&crate::prelude::drop(&stmts_p1x, j_pa), &(|st_pc: &crate::syntax::Stmt| !has_stmt_f(&crate::prelude::Array::from(vec![moved_pb.clone()]), st_pc)))), fuel_p2: crate::syntax::lexer::chars::dec_f(&fuel_p2x) }))
                },
                _ => ::prism_rtl::Turn::Finished(stmts_p1x.clone()),
                _ => unreachable!("no arm matched"),
            }
        })
    }
}

/// `Start BundleLetsEarly, x`: what the function value is when passed to `@Run`.
pub fn start_bundle_lets_early_f(lx_p0: crate::lower::Lx, stmts_p1: crate::prelude::Array<crate::syntax::Stmt>, fuel_p2: crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::syntax::Stmt>>> {
    ::std::rc::Rc::new(BundleLetsEarly { lx_p0, stmts_p1, fuel_p2 })
}

/// ```prism
/// IsLastLine: fn ?Stmt, Stmt -> Bool
/// ```
pub fn is_last_line_f(opt0: &::std::option::Option<crate::syntax::Stmt>, st_p1: &crate::syntax::Stmt) -> bool {
    match opt0 {
        ::std::option::Option::Some(last_p0) => has_stmt_f(&crate::prelude::Array::from(vec![last_p0.clone()]), st_p1),
        ::std::option::Option::None => false,
    }
}

/// ```prism
/// LinesInto: unbounded fn Wx, Env, Env, Block, Bool -> ((Wx, Env, Env))
/// ```
pub fn lines_into_f(wx_p0: &crate::lower::node_::Wx, benv0_p1: &crate::lower::types::Env, menv0_p2: &crate::lower::types::Env, b_p3: &crate::syntax::Block, open_p4: &bool) -> (crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env) {
    let stmts_p5 = bundle_lets_early_f(&wx_p0.lx_p, &b_p3.stmts_p, &crate::prelude::len(&b_p3.stmts_p));
    let last_o6 = crate::prelude::index(&b_p3.stmts_p, &crate::syntax::lexer::chars::dec_f(&crate::prelude::len(&b_p3.stmts_p)));
    let fns_p7 = crate::prelude::fold(&crate::prelude::filter(&stmts_p5, &is_fn_line_f), &crate::lower::types::empty_env_p(), &(|en_pc: &crate::lower::types::Env, s_pd: &crate::syntax::Stmt| match &s_pd.kind_p {
        crate::syntax::StmtKind::SFn(c_pe) => crate::lower::types::bind_f(en_pc, &crate::check::env::def_name_text_f(&c_pe.name_p), &crate::lower::expr::with_clause_f(en_pc, &crate::check::env::def_name_text_f(&c_pe.name_p), c_pe)),
        _ => en_pc.clone(),
    }));
    let (wxq_pj, benvq_pk, menvq_pl) = crate::prelude::run_to_end(crate::prelude::fold_job(stmts_p5.clone(), (wx_p0.clone(), benv0_p1.clone(), menv0_p2.clone()), ::std::rc::Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::syntax::Stmt)| crate::prelude::entered(crate::prelude::once_job(move || {
        let (w_pf, be_pg, me_ph) = p0;
        let s_pi = p1;
        ::prism_rtl::Turn::More(::std::rc::Rc::new(LatePlaceParts { wx_p0: w_pf.clone(), benv_p1: be_pg.clone(), menv_p2: me_ph.clone(), s_p3: s_pi.clone() }))
    }))) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::syntax::Stmt)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>>>));
    let (wxp_pq, benvp_pr, menvp_ps) = crate::prelude::run_to_end(crate::prelude::fold_job(stmts_p5.clone(), (wxq_pj.clone(), benvq_pk.clone(), menvq_pl.clone()), ::std::rc::Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::syntax::Stmt)| crate::prelude::entered(crate::prelude::once_job(move || {
        let (w_pm, be_pn, me_po) = p0;
        let s_pp = p1;
        ::prism_rtl::Turn::More(::std::rc::Rc::new(LateHostedAnswer { wx_p0: w_pm.clone(), benv_p1: be_pn.clone(), menv_p2: me_po.clone(), s_p3: s_pp.clone() }))
    }))) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::syntax::Stmt)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>>>));
    let (wx0_pt, benv_pu, menv_pv) = mark_late_lets_f(&wxp_pq, &benvp_pr, &menvp_ps, &fns_p7, &stmts_p5, &crate::prelude::len(&stmts_p5));
    let (wx1p_p14, be1_p15, me1_p16) = crate::prelude::run_to_end(crate::prelude::fold_job(stmts_p5.clone(), (wx0_pt.clone(), benv_pu.clone(), menv_pv.clone()), ::std::rc::Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::syntax::Stmt)| crate::prelude::entered(crate::prelude::once_job(move || {
        let (w_p10, be_p11, me_p12) = p0;
        let s_p13 = p1;
        ::prism_rtl::Turn::More(::std::rc::Rc::new(PreBind { wx_p0: w_p10.clone(), benv_p1: be_p11.clone(), menv_p2: me_p12.clone(), s_p3: s_p13.clone() }))
    }))) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::syntax::Stmt)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>>>));
    let wx1_p8 = late_let_getters_f(&wx1p_p14, &me1_p16, &stmts_p5);
    let order_p9 = build_order_f(&stmts_p5);
    let (wx2_p1d, be2_p1e) = crate::prelude::run_to_end(crate::prelude::fold_job(order_p9.clone(), (wx1_p8.clone(), be1_p15.clone()), {
        let me1_p16x = me1_p16.clone();
        let stmts_p5x = stmts_p5.clone();
        ::std::rc::Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::types::Env), crate::prelude::Array<crate::prelude::Nat>)| {
            let me1_p16xy = me1_p16x.clone();
            let stmts_p5xy = stmts_p5x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (w_p17, be_p18) = p0;
                let comp_p19 = p1;
                crate::prelude::fold_job(comp_p19.clone(), (w_p17.clone(), be_p18.clone()), {
                    let me1_p16xyx = me1_p16xy.clone();
                    let stmts_p5xyx = stmts_p5xy.clone();
                    ::std::rc::Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::types::Env), crate::prelude::Nat)| {
                        let me1_p16xyxy = me1_p16xyx.clone();
                        let stmts_p5xyxy = stmts_p5xyx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let (w2_p1a, be3_p1b) = p0;
                            let i_p1c = p1;
                            ::prism_rtl::Turn::More(::std::rc::Rc::new(PreInit { wx_p0: w2_p1a.clone(), benv_p1: be3_p1b.clone(), menv_p2: me1_p16xyxy.clone(), s_p3: crate::prelude::or(&crate::prelude::index(&stmts_p5xyxy, &i_p1c), &crate::lower::expr::dummy_stmt_l_p()) }))
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::lower::node_::Wx, crate::lower::types::Env), crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env)>>>
                }).cycle()
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::lower::node_::Wx, crate::lower::types::Env), crate::prelude::Array<crate::prelude::Nat>)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env)>>>
    }));
    let n_pa = crate::prelude::len(&stmts_p5);
    let start_pb = crate::prelude::len(&wx2_p1d.lets_p);
    let (wx3_p1n, be4_p1o, me4_p1p, ends_p1q) = crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(&n_pa), (wx2_p1d.clone(), be2_p1e.clone(), me1_p16.clone(), crate::prelude::Array::new()), {
        let stmts_p5x = stmts_p5.clone();
        let open_p4x = *open_p4;
        let last_o6x = last_o6.clone();
        ::std::rc::Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env, crate::prelude::Array<crate::prelude::Nat>), crate::prelude::Nat)| {
            let stmts_p5xy = stmts_p5x.clone();
            let open_p4xy = open_p4x;
            let last_o6xy = last_o6x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (w_p1f, be_p1g, me_p1h, acc_p1i) = p0;
                let i_p1j = p1;
                crate::prelude::call_then(start_widget_stmt_f(w_p1f.clone(), be_p1g.clone(), me_p1h.clone(), crate::prelude::or(&crate::prelude::index(&stmts_p5xy, &i_p1j), &crate::lower::expr::dummy_stmt_l_p()), !open_p4xy && is_last_line_f(&last_o6xy, &crate::prelude::or(&crate::prelude::index(&stmts_p5xy, &i_p1j), &crate::lower::expr::dummy_stmt_l_p()))), move |widget_stmt_f_25084: (crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)| {
                    let (w2_p1k, be3_p1l, me3_p1m) = widget_stmt_f_25084;
                    ::prism_rtl::Turn::Finished((w2_p1k.clone(), be3_p1l.clone(), me3_p1m.clone(), crate::prelude::push(&acc_p1i, &crate::prelude::len(&w2_p1k.lets_p))))
                })
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env, crate::prelude::Array<crate::prelude::Nat>), crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env, crate::prelude::Array<crate::prelude::Nat>)>>>
    }));
    (build_in_order_f(&wx3_p1n, &stmts_p5, &order_p9, &start_pb, &ends_p1q), be4_p1o.clone(), me4_p1p.clone())
}

/// The step machine of `LinesInto`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LinesInto: unbounded fn Wx, Env, Env, Block, Bool -> ((Wx, Env, Env))
/// ```
pub struct LinesInto {
    pub wx_p0: crate::lower::node_::Wx,
    pub benv0_p1: crate::lower::types::Env,
    pub menv0_p2: crate::lower::types::Env,
    pub b_p3: crate::syntax::Block,
    pub open_p4: bool,
}

impl ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)> for LinesInto {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)> {
        let wx_p0 = &self.wx_p0;
        let benv0_p1 = &self.benv0_p1;
        let menv0_p2 = &self.menv0_p2;
        let b_p3 = &self.b_p3;
        let open_p4 = &self.open_p4;
        let b_p3x = b_p3.clone();
        let benv0_p1x = benv0_p1.clone();
        let menv0_p2x = menv0_p2.clone();
        let open_p4x = *open_p4;
        let wx_p0x = wx_p0.clone();
        crate::prelude::call_then(start_bundle_lets_early_f(wx_p0x.lx_p.clone(), b_p3x.stmts_p.clone(), crate::prelude::len(&b_p3x.stmts_p)), move |bundle_lets_early_f_23538: crate::prelude::Array<crate::syntax::Stmt>| {
            let stmts_p5 = bundle_lets_early_f_23538;
            let last_o6 = crate::prelude::index(&b_p3x.stmts_p, &crate::syntax::lexer::chars::dec_f(&crate::prelude::len(&b_p3x.stmts_p)));
            let fns_p7 = crate::prelude::fold(&crate::prelude::filter(&stmts_p5, &is_fn_line_f), &crate::lower::types::empty_env_p(), &(|en_pc: &crate::lower::types::Env, s_pd: &crate::syntax::Stmt| match &s_pd.kind_p {
                crate::syntax::StmtKind::SFn(c_pe) => crate::lower::types::bind_f(en_pc, &crate::check::env::def_name_text_f(&c_pe.name_p), &crate::lower::expr::with_clause_f(en_pc, &crate::check::env::def_name_text_f(&c_pe.name_p), c_pe)),
                _ => en_pc.clone(),
            }));
            crate::prelude::call_value(crate::prelude::fold_job(stmts_p5.clone(), (wx_p0x.clone(), benv0_p1x.clone(), menv0_p2x.clone()), ::std::rc::Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::syntax::Stmt)| crate::prelude::entered(crate::prelude::once_job(move || {
                let (w_pf, be_pg, me_ph) = p0;
                let s_pi = p1;
                ::prism_rtl::Turn::More(::std::rc::Rc::new(LatePlaceParts { wx_p0: w_pf.clone(), benv_p1: be_pg.clone(), menv_p2: me_ph.clone(), s_p3: s_pi.clone() }))
            }))) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::syntax::Stmt)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>>>), move |fold_24163: (crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)| {
                let (wxq_pj, benvq_pk, menvq_pl) = fold_24163;
                crate::prelude::call_value(crate::prelude::fold_job(stmts_p5.clone(), (wxq_pj.clone(), benvq_pk.clone(), menvq_pl.clone()), ::std::rc::Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::syntax::Stmt)| crate::prelude::entered(crate::prelude::once_job(move || {
                    let (w_pm, be_pn, me_po) = p0;
                    let s_pp = p1;
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(LateHostedAnswer { wx_p0: w_pm.clone(), benv_p1: be_pn.clone(), menv_p2: me_po.clone(), s_p3: s_pp.clone() }))
                }))) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::syntax::Stmt)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>>>), move |fold_24392: (crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)| {
                    let (wxp_pq, benvp_pr, menvp_ps) = fold_24392;
                    crate::prelude::call_then(start_mark_late_lets_f(wxp_pq.clone(), benvp_pr.clone(), menvp_ps.clone(), fns_p7.clone(), stmts_p5.clone(), crate::prelude::len(&stmts_p5)), move |mark_late_lets_f_24507: (crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)| {
                        let (wx0_pt, benv_pu, menv_pv) = mark_late_lets_f_24507;
                        crate::prelude::call_value(crate::prelude::fold_job(stmts_p5.clone(), (wx0_pt.clone(), benv_pu.clone(), menv_pv.clone()), ::std::rc::Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::syntax::Stmt)| crate::prelude::entered(crate::prelude::once_job(move || {
                            let (w_p10, be_p11, me_p12) = p0;
                            let s_p13 = p1;
                            ::prism_rtl::Turn::More(::std::rc::Rc::new(PreBind { wx_p0: w_p10.clone(), benv_p1: be_p11.clone(), menv_p2: me_p12.clone(), s_p3: s_p13.clone() }))
                        }))) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::syntax::Stmt)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>>>), move |fold_24592: (crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)| {
                            let (wx1p_p14, be1_p15, me1_p16) = fold_24592;
                            crate::prelude::call_then(start_late_let_getters_f(wx1p_p14.clone(), me1_p16.clone(), stmts_p5.clone()), move |late_let_getters_f_24680: crate::lower::node_::Wx| {
                                let wx1_p8 = late_let_getters_f_24680;
                                crate::prelude::call_then(start_build_order_f(stmts_p5.clone()), move |build_order_f_24728: crate::prelude::Array<crate::prelude::Array<crate::prelude::Nat>>| {
                                    let order_p9 = build_order_f_24728;
                                    crate::prelude::call_value(crate::prelude::fold_job(order_p9.clone(), (wx1_p8.clone(), be1_p15.clone()), {
                                        let me1_p16x = me1_p16.clone();
                                        let stmts_p5x = stmts_p5.clone();
                                        ::std::rc::Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::types::Env), crate::prelude::Array<crate::prelude::Nat>)| {
                                            let me1_p16xy = me1_p16x.clone();
                                            let stmts_p5xy = stmts_p5x.clone();
                                            crate::prelude::entered(crate::prelude::once_job(move || {
                                                let (w_p17, be_p18) = p0;
                                                let comp_p19 = p1;
                                                crate::prelude::fold_job(comp_p19.clone(), (w_p17.clone(), be_p18.clone()), {
                                                    let me1_p16xyx = me1_p16xy.clone();
                                                    let stmts_p5xyx = stmts_p5xy.clone();
                                                    ::std::rc::Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::types::Env), crate::prelude::Nat)| {
                                                        let me1_p16xyxy = me1_p16xyx.clone();
                                                        let stmts_p5xyxy = stmts_p5xyx.clone();
                                                        crate::prelude::entered(crate::prelude::once_job(move || {
                                                            let (w2_p1a, be3_p1b) = p0;
                                                            let i_p1c = p1;
                                                            ::prism_rtl::Turn::More(::std::rc::Rc::new(PreInit { wx_p0: w2_p1a.clone(), benv_p1: be3_p1b.clone(), menv_p2: me1_p16xyxy.clone(), s_p3: crate::prelude::or(&crate::prelude::index(&stmts_p5xyxy, &i_p1c), &crate::lower::expr::dummy_stmt_l_p()) }))
                                                        }))
                                                    }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::lower::node_::Wx, crate::lower::types::Env), crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env)>>>
                                                }).cycle()
                                            }))
                                        }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::lower::node_::Wx, crate::lower::types::Env), crate::prelude::Array<crate::prelude::Nat>)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env)>>>
                                    }), move |fold_24768: (crate::lower::node_::Wx, crate::lower::types::Env)| {
                                        let (wx2_p1d, be2_p1e) = fold_24768;
                                        let n_pa = crate::prelude::len(&stmts_p5);
                                        let start_pb = crate::prelude::len(&wx2_p1d.lets_p);
                                        crate::prelude::call_value(crate::prelude::fold_job(crate::check::errors::range0_f(&n_pa), (wx2_p1d.clone(), be2_p1e.clone(), me1_p16.clone(), crate::prelude::Array::new()), {
                                            let stmts_p5x = stmts_p5.clone();
                                            let open_p4xx = open_p4x;
                                            let last_o6x = last_o6.clone();
                                            ::std::rc::Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env, crate::prelude::Array<crate::prelude::Nat>), crate::prelude::Nat)| {
                                                let stmts_p5xy = stmts_p5x.clone();
                                                let open_p4xxy = open_p4xx;
                                                let last_o6xy = last_o6x.clone();
                                                crate::prelude::entered(crate::prelude::once_job(move || {
                                                    let (w_p1f, be_p1g, me_p1h, acc_p1i) = p0;
                                                    let i_p1j = p1;
                                                    crate::prelude::call_then(start_widget_stmt_f(w_p1f.clone(), be_p1g.clone(), me_p1h.clone(), crate::prelude::or(&crate::prelude::index(&stmts_p5xy, &i_p1j), &crate::lower::expr::dummy_stmt_l_p()), !open_p4xxy && is_last_line_f(&last_o6xy, &crate::prelude::or(&crate::prelude::index(&stmts_p5xy, &i_p1j), &crate::lower::expr::dummy_stmt_l_p()))), move |widget_stmt_f_25084: (crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)| {
                                                        let (w2_p1k, be3_p1l, me3_p1m) = widget_stmt_f_25084;
                                                        ::prism_rtl::Turn::Finished((w2_p1k.clone(), be3_p1l.clone(), me3_p1m.clone(), crate::prelude::push(&acc_p1i, &crate::prelude::len(&w2_p1k.lets_p))))
                                                    })
                                                }))
                                            }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env, crate::prelude::Array<crate::prelude::Nat>), crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env, crate::prelude::Array<crate::prelude::Nat>)>>>
                                        }), move |fold_24986: (crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env, crate::prelude::Array<crate::prelude::Nat>)| {
                                            let (wx3_p1n, be4_p1o, me4_p1p, ends_p1q) = fold_24986;
                                            crate::prelude::call_then(start_build_in_order_f(wx3_p1n.clone(), stmts_p5.clone(), order_p9.clone(), start_pb.clone(), ends_p1q.clone()), move |build_in_order_f_25253: crate::lower::node_::Wx| ::prism_rtl::Turn::Finished((build_in_order_f_25253, be4_p1o.clone(), me4_p1p.clone())))
                                        })
                                    })
                                })
                            })
                        })
                    })
                })
            })
        })
    }
}

/// `Start LinesInto, x`: what the function value is when passed to `@Run`.
pub fn start_lines_into_f(wx_p0: crate::lower::node_::Wx, benv0_p1: crate::lower::types::Env, menv0_p2: crate::lower::types::Env, b_p3: crate::syntax::Block, open_p4: bool) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>> {
    ::std::rc::Rc::new(LinesInto { wx_p0, benv0_p1, menv0_p2, b_p3, open_p4 })
}

/// ```prism
/// ?LateLineAt: unbounded fn Lx, Env, Block, Nat -> ?Nat
/// ```
pub fn late_line_at_o(lx_p0: &crate::lower::Lx, menv_p1: &crate::lower::types::Env, b_p2: &crate::syntax::Block, depth_p3: &crate::prelude::Nat) -> ::std::option::Option<crate::prelude::Nat> {
    let env_p4 = with_local_widgets_f(menv_p1, b_p2);
    crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(&b_p2.stmts_p)), ::std::option::Option::None, {
        let b_p2x = b_p2.clone();
        let lx_p0x = lx_p0.clone();
        let env_p4x = env_p4.clone();
        let depth_p3x = depth_p3.clone();
        ::std::rc::Rc::new(move |(p0, p1): (::std::option::Option<crate::prelude::Nat>, crate::prelude::Nat)| {
            let b_p2xy = b_p2x.clone();
            let lx_p0xy = lx_p0x.clone();
            let env_p4xy = env_p4x.clone();
            let depth_p3xy = depth_p3x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let found_o5 = p0;
                let i_p6 = p1;
                match &found_o5 {
                    ::std::option::Option::Some(k_p7) => ::prism_rtl::Turn::Finished(::std::option::Option::Some(k_p7.clone())),
                    ::std::option::Option::None => match &crate::prelude::or(&crate::prelude::index(&b_p2xy.stmts_p, &i_p6), &crate::lower::expr::dummy_stmt_l_p()).kind_p {
                        crate::syntax::StmtKind::SBind(_, e_p8, ::std::option::Option::None) => {
                            let e_p8x = e_p8.clone();
                            crate::prelude::call_then(start_is_late_expr_f(lx_p0xy.clone(), env_p4xy.clone(), e_p8x.clone(), depth_p3xy.clone()), move |is_late_expr_f_26099: bool| if is_late_expr_f_26099 && !(is_early_choice_at_f(&lx_p0xy, &env_p4xy, &b_p2xy, &i_p6) || is_pure_choice_at_f(&lx_p0xy, &env_p4xy, &b_p2xy, &i_p6, &depth_p3xy)) {
                                ::prism_rtl::Turn::Finished(::std::option::Option::Some(i_p6.clone()))
                            } else {
                                ::prism_rtl::Turn::Finished(::std::option::Option::None)
                            })
                        },
                        _ => ::prism_rtl::Turn::Finished(::std::option::Option::None),
                    },
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((::std::option::Option<crate::prelude::Nat>, crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<::std::option::Option<crate::prelude::Nat>>>>
    }))
}

/// The step machine of `LateLineAt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?LateLineAt: unbounded fn Lx, Env, Block, Nat -> ?Nat
/// ```
pub struct LateLineAt {
    pub lx_p0: crate::lower::Lx,
    pub menv_p1: crate::lower::types::Env,
    pub b_p2: crate::syntax::Block,
    pub depth_p3: crate::prelude::Nat,
}

impl ::prism_rtl::Job<::std::option::Option<crate::prelude::Nat>> for LateLineAt {
    fn cycle(&self) -> ::prism_rtl::Turn<::std::option::Option<crate::prelude::Nat>> {
        let lx_p0 = &self.lx_p0;
        let menv_p1 = &self.menv_p1;
        let b_p2 = &self.b_p2;
        let depth_p3 = &self.depth_p3;
        let env_p4 = with_local_widgets_f(menv_p1, b_p2);
        crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(&b_p2.stmts_p)), ::std::option::Option::None, {
            let b_p2x = b_p2.clone();
            let lx_p0x = lx_p0.clone();
            let env_p4x = env_p4.clone();
            let depth_p3x = depth_p3.clone();
            ::std::rc::Rc::new(move |(p0, p1): (::std::option::Option<crate::prelude::Nat>, crate::prelude::Nat)| {
                let b_p2xy = b_p2x.clone();
                let lx_p0xy = lx_p0x.clone();
                let env_p4xy = env_p4x.clone();
                let depth_p3xy = depth_p3x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let found_o5 = p0;
                    let i_p6 = p1;
                    match &found_o5 {
                        ::std::option::Option::Some(k_p7) => ::prism_rtl::Turn::Finished(::std::option::Option::Some(k_p7.clone())),
                        ::std::option::Option::None => match &crate::prelude::or(&crate::prelude::index(&b_p2xy.stmts_p, &i_p6), &crate::lower::expr::dummy_stmt_l_p()).kind_p {
                            crate::syntax::StmtKind::SBind(_, e_p8, ::std::option::Option::None) => {
                                let e_p8x = e_p8.clone();
                                crate::prelude::call_then(start_is_late_expr_f(lx_p0xy.clone(), env_p4xy.clone(), e_p8x.clone(), depth_p3xy.clone()), move |is_late_expr_f_26099: bool| if is_late_expr_f_26099 && !(is_early_choice_at_f(&lx_p0xy, &env_p4xy, &b_p2xy, &i_p6) || is_pure_choice_at_f(&lx_p0xy, &env_p4xy, &b_p2xy, &i_p6, &depth_p3xy)) {
                                    ::prism_rtl::Turn::Finished(::std::option::Option::Some(i_p6.clone()))
                                } else {
                                    ::prism_rtl::Turn::Finished(::std::option::Option::None)
                                })
                            },
                            _ => ::prism_rtl::Turn::Finished(::std::option::Option::None),
                        },
                    }
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((::std::option::Option<crate::prelude::Nat>, crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<::std::option::Option<crate::prelude::Nat>>>>
        }).cycle()
    }
}

/// `Start LateLineAt, x`: what the function value is when passed to `@Run`.
pub fn start_late_line_at_o(lx_p0: crate::lower::Lx, menv_p1: crate::lower::types::Env, b_p2: crate::syntax::Block, depth_p3: crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<::std::option::Option<crate::prelude::Nat>>> {
    ::std::rc::Rc::new(LateLineAt { lx_p0, menv_p1, b_p2, depth_p3 })
}

/// ```prism
/// WithLocalWidgets: fn Env, Block -> Env
/// ```
pub fn with_local_widgets_f(env_p0: &crate::lower::types::Env, b_p1: &crate::syntax::Block) -> crate::lower::types::Env {
    crate::prelude::fold(&b_p1.stmts_p, env_p0, &(|en_p2: &crate::lower::types::Env, s_p3: &crate::syntax::Stmt| match &s_p3.kind_p {
        crate::syntax::StmtKind::SWidget(w_p4) => crate::lower::types::bind_f(en_p2, &crate::check::env::sname_key_f(&w_p4.name_p), &crate::lower::types::Bn::BnLocalWidget(w_p4.body_p.clone())),
        _ => en_p2.clone(),
    }))
}

/// ```prism
/// IsLateExpr: unbounded fn Lx, Env, Expr, Nat -> Bool
/// ```
pub fn is_late_expr_f(lx_p0: &crate::lower::Lx, menv_p1: &crate::lower::types::Env, e_p2: &crate::syntax::Expr, depth_p3: &crate::prelude::Nat) -> bool {
    match &*e_p2.kind_p {
        crate::syntax::ExprKind::EGroup(x_p4) => is_late_expr_f(lx_p0, menv_p1, &**x_p4, depth_p3),
        crate::syntax::ExprKind::EIf(_, _, ::std::option::Option::Some(_)) => is_plain_result_f(lx_p0, e_p2),
        crate::syntax::ExprKind::EMatch(_, _) => is_plain_result_f(lx_p0, e_p2),
        crate::syntax::ExprKind::EWidgetBlock(b_p5) => is_late_block_f(lx_p0, menv_p1, b_p5, depth_p3),
        _ => {
            let (callee_p8, args_p9) = match &*e_p2.kind_p {
                crate::syntax::ExprKind::ECall(c_p6, xs_p7, _, _) => ((**c_p6).clone(), xs_p7.clone()),
                _ => (e_p2.clone(), crate::prelude::Array::new()),
            };
            match &*callee_p8.kind_p {
                crate::syntax::ExprKind::EName(n_pa) => {
                    let local_ob = if &crate::prelude::len(&n_pa.path_p) != &crate::prelude::Nat::from(1u32) {
                        ::std::option::Option::None
                    } else {
                        match crate::prelude::get(&menv_p1.names_p, &crate::prelude::Text::from(format!("{}#blueprint", &crate::check::env::sname_key_f(n_pa)))) {
                            ::std::option::Option::Some(crate::lower::types::Bn::BnWidget(x_pc, _, _, _)) => ::std::option::Option::Some(crate::lower::types::Bn::BnWidget(x_pc, crate::lower::types::empty_env_p(), menv_p1.clone(), lx_p0.clone())),
                            _ => crate::prelude::get(&menv_p1.names_p, &crate::check::env::sname_key_f(n_pa)),
                        }
                    };
                    match &local_ob {
                        ::std::option::Option::Some(crate::lower::types::Bn::BnWidget(x_pd, _, cmenv_pe, clx_pf)) => (depth_p3 > &crate::prelude::Nat::from(0u32)) && is_late_expr_f(clx_pf, cmenv_pe, x_pd, &crate::syntax::lexer::chars::dec_f(depth_p3)),
                        ::std::option::Option::Some(crate::lower::types::Bn::BnLocalWidget(wb_pg)) => (depth_p3 > &crate::prelude::Nat::from(0u32)) && is_late_block_f(lx_p0, menv_p1, wb_pg, &crate::syntax::lexer::chars::dec_f(depth_p3)),
                        ::std::option::Option::Some(crate::lower::types::Bn::BnLocal(_, _, _)) => ((&crate::prelude::len(&args_p9) == &crate::prelude::Nat::from(0u32)) && (&crate::lower::types::layer_of_f(&crate::lower::type_at_f(lx_p0, &e_p2.span_p)) == &crate::lower::types::Layer::LyBlueprint)) && is_plain_result_f(lx_p0, e_p2),
                        _ => {
                            let (q_oh, _) = crate::check::env::names::resolve_value_f(&lx_p0.g_p, &lx_p0.home_p, n_pa);
                            match &q_oh {
                                ::std::option::Option::Some(m28487_0) if (m28487_0 == &crate::prelude::Text::lit("Prelude.@Element")) => match crate::prelude::index(&args_p9, &crate::prelude::Nat::from(0u32)) {
                                    ::std::option::Option::Some(a_pi) => (!crate::lower::node_::static_::is_tag_application_f(lx_p0, &a_pi.value_p) && !crate::lower::node_::switch_::is_some_f(&crate::lower::node_::static_::element_let_o(menv_p1, &a_pi.value_p))) && is_plain_result_f(lx_p0, e_p2),
                                    ::std::option::Option::None => false,
                                },
                                ::std::option::Option::Some(q_pj) => match crate::prelude::get(&lx_p0.g_p.vals_p, q_pj) {
                                    ::std::option::Option::Some(v_pk) if is_recursing_call_f(lx_p0, q_pj, &v_pk, e_p2) => true,
                                    ::std::option::Option::Some(v_pl) => match one_body_o(lx_p0, q_pj) {
                                        ::std::option::Option::Some(body_pm) => ((depth_p3 > &crate::prelude::Nat::from(0u32)) && is_plain_result_f(lx_p0, e_p2)) && is_late_block_f(&crate::lower::program::in_module_at_f(lx_p0, &v_pl.file_p, &v_pl.home_p, &lx_p0.site_p), &callee_widget_env_f(lx_p0, menv_p1, q_pj, &v_pl, &args_p9), &body_pm, &crate::syntax::lexer::chars::dec_f(depth_p3)),
                                        ::std::option::Option::None => ((&crate::prelude::len(&crate::lower::jobs::clauses_of_f(&lx_p0.g_p, q_pj)) > &crate::prelude::Nat::from(1u32)) && crate::lower::types::is_bundle_f(&line_out_full_f(lx_p0, e_p2))) && is_plain_result_f(lx_p0, e_p2),
                                    },
                                    ::std::option::Option::None => false,
                                    _ => unreachable!("no arm matched"),
                                },
                                ::std::option::Option::None => false,
                                _ => unreachable!("no arm matched"),
                            }
                        },
                    }
                },
                _ => false,
            }
        },
    }
}

/// The step machine of `IsLateExpr`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// IsLateExpr: unbounded fn Lx, Env, Expr, Nat -> Bool
/// ```
pub struct IsLateExpr {
    pub lx_p0: crate::lower::Lx,
    pub menv_p1: crate::lower::types::Env,
    pub e_p2: crate::syntax::Expr,
    pub depth_p3: crate::prelude::Nat,
}

impl ::prism_rtl::Job<bool> for IsLateExpr {
    fn cycle(&self) -> ::prism_rtl::Turn<bool> {
        let lx_p0 = &self.lx_p0;
        let menv_p1 = &self.menv_p1;
        let e_p2 = &self.e_p2;
        let depth_p3 = &self.depth_p3;
        match &*e_p2.kind_p {
            crate::syntax::ExprKind::EGroup(x_p4) => ::prism_rtl::Turn::More(::std::rc::Rc::new(IsLateExpr { lx_p0: lx_p0.clone(), menv_p1: menv_p1.clone(), e_p2: (**x_p4).clone(), depth_p3: depth_p3.clone() })),
            crate::syntax::ExprKind::EIf(_, _, ::std::option::Option::Some(_)) => ::prism_rtl::Turn::More(::std::rc::Rc::new(IsPlainResult { lx_p0: lx_p0.clone(), e_p1: e_p2.clone() })),
            crate::syntax::ExprKind::EMatch(_, _) => ::prism_rtl::Turn::More(::std::rc::Rc::new(IsPlainResult { lx_p0: lx_p0.clone(), e_p1: e_p2.clone() })),
            crate::syntax::ExprKind::EWidgetBlock(b_p5) => ::prism_rtl::Turn::More(::std::rc::Rc::new(IsLateBlock { lx_p0: lx_p0.clone(), menv_p1: menv_p1.clone(), b_p2: b_p5.clone(), depth_p3: depth_p3.clone() })),
            _ => {
                let (callee_p8, args_p9) = match &*e_p2.kind_p {
                    crate::syntax::ExprKind::ECall(c_p6, xs_p7, _, _) => ((**c_p6).clone(), xs_p7.clone()),
                    _ => (e_p2.clone(), crate::prelude::Array::new()),
                };
                match &*callee_p8.kind_p {
                    crate::syntax::ExprKind::EName(n_pa) => {
                        let local_ob = if &crate::prelude::len(&n_pa.path_p) != &crate::prelude::Nat::from(1u32) {
                            ::std::option::Option::None
                        } else {
                            match crate::prelude::get(&menv_p1.names_p, &crate::prelude::Text::from(format!("{}#blueprint", &crate::check::env::sname_key_f(n_pa)))) {
                                ::std::option::Option::Some(crate::lower::types::Bn::BnWidget(x_pc, _, _, _)) => ::std::option::Option::Some(crate::lower::types::Bn::BnWidget(x_pc, crate::lower::types::empty_env_p(), menv_p1.clone(), lx_p0.clone())),
                                _ => crate::prelude::get(&menv_p1.names_p, &crate::check::env::sname_key_f(n_pa)),
                            }
                        };
                        match &local_ob {
                            ::std::option::Option::Some(crate::lower::types::Bn::BnWidget(x_pd, _, cmenv_pe, clx_pf)) => if depth_p3 > &crate::prelude::Nat::from(0u32) {
                                ::prism_rtl::Turn::More(::std::rc::Rc::new(IsLateExpr { lx_p0: clx_pf.clone(), menv_p1: cmenv_pe.clone(), e_p2: x_pd.clone(), depth_p3: crate::syntax::lexer::chars::dec_f(depth_p3) }))
                            } else {
                                ::prism_rtl::Turn::Finished(false)
                            },
                            ::std::option::Option::Some(crate::lower::types::Bn::BnLocalWidget(wb_pg)) => if depth_p3 > &crate::prelude::Nat::from(0u32) {
                                ::prism_rtl::Turn::More(::std::rc::Rc::new(IsLateBlock { lx_p0: lx_p0.clone(), menv_p1: menv_p1.clone(), b_p2: wb_pg.clone(), depth_p3: crate::syntax::lexer::chars::dec_f(depth_p3) }))
                            } else {
                                ::prism_rtl::Turn::Finished(false)
                            },
                            ::std::option::Option::Some(crate::lower::types::Bn::BnLocal(_, _, _)) => if (&crate::prelude::len(&args_p9) == &crate::prelude::Nat::from(0u32)) && (&crate::lower::types::layer_of_f(&crate::lower::type_at_f(lx_p0, &e_p2.span_p)) == &crate::lower::types::Layer::LyBlueprint) {
                                ::prism_rtl::Turn::More(::std::rc::Rc::new(IsPlainResult { lx_p0: lx_p0.clone(), e_p1: e_p2.clone() }))
                            } else {
                                ::prism_rtl::Turn::Finished(false)
                            },
                            _ => {
                                let (q_oh, _) = crate::check::env::names::resolve_value_f(&lx_p0.g_p, &lx_p0.home_p, n_pa);
                                match &q_oh {
                                    ::std::option::Option::Some(m28487_0) if (m28487_0 == &crate::prelude::Text::lit("Prelude.@Element")) => match crate::prelude::index(&args_p9, &crate::prelude::Nat::from(0u32)) {
                                        ::std::option::Option::Some(a_pi) => {
                                            let e_p2x = e_p2.clone();
                                            let lx_p0x = lx_p0.clone();
                                            let menv_p1x = menv_p1.clone();
                                            crate::prelude::call_then(crate::lower::node_::static_::start_is_tag_application_f(lx_p0x.clone(), a_pi.value_p.clone()), move |is_tag_application_f_28927: bool| if !is_tag_application_f_28927 && !crate::lower::node_::switch_::is_some_f(&crate::lower::node_::static_::element_let_o(&menv_p1x, &a_pi.value_p)) {
                                                ::prism_rtl::Turn::More(::std::rc::Rc::new(IsPlainResult { lx_p0: lx_p0x.clone(), e_p1: e_p2x.clone() }))
                                            } else {
                                                ::prism_rtl::Turn::Finished(false)
                                            })
                                        },
                                        ::std::option::Option::None => ::prism_rtl::Turn::Finished(false),
                                    },
                                    ::std::option::Option::Some(q_pj) => match crate::prelude::get(&lx_p0.g_p.vals_p, q_pj) {
                                        ::std::option::Option::Some(v_pk) if is_recursing_call_f(lx_p0, q_pj, &v_pk, e_p2) => ::prism_rtl::Turn::Finished(true),
                                        ::std::option::Option::Some(v_pl) => {
                                            let depth_p3x = depth_p3.clone();
                                            let e_p2x = e_p2.clone();
                                            let lx_p0x = lx_p0.clone();
                                            let menv_p1x = menv_p1.clone();
                                            let q_pjx = q_pj.clone();
                                            crate::prelude::call_then(start_one_body_o(lx_p0x.clone(), q_pjx.clone()), move |one_body_o_29241: ::std::option::Option<crate::syntax::Block>| match one_body_o_29241 {
                                                ::std::option::Option::Some(body_pm) => if (&depth_p3x > &crate::prelude::Nat::from(0u32)) && is_plain_result_f(&lx_p0x, &e_p2x) {
                                                    crate::prelude::call_then(start_callee_widget_env_f(lx_p0x.clone(), menv_p1x.clone(), q_pjx.clone(), v_pl.clone(), args_p9.clone()), move |callee_widget_env_f_29396: crate::lower::types::Env| ::prism_rtl::Turn::More(::std::rc::Rc::new(IsLateBlock { lx_p0: crate::lower::program::in_module_at_f(&lx_p0x, &v_pl.file_p, &v_pl.home_p, &lx_p0x.site_p), menv_p1: callee_widget_env_f_29396, b_p2: body_pm.clone(), depth_p3: crate::syntax::lexer::chars::dec_f(&depth_p3x) })))
                                                } else {
                                                    ::prism_rtl::Turn::Finished(false)
                                                },
                                                ::std::option::Option::None => if (&crate::prelude::len(&crate::lower::jobs::clauses_of_f(&lx_p0x.g_p, &q_pjx)) > &crate::prelude::Nat::from(1u32)) && crate::lower::types::is_bundle_f(&line_out_full_f(&lx_p0x, &e_p2x)) {
                                                    ::prism_rtl::Turn::More(::std::rc::Rc::new(IsPlainResult { lx_p0: lx_p0x.clone(), e_p1: e_p2x.clone() }))
                                                } else {
                                                    ::prism_rtl::Turn::Finished(false)
                                                },
                                            })
                                        },
                                        ::std::option::Option::None => ::prism_rtl::Turn::Finished(false),
                                        _ => unreachable!("no arm matched"),
                                    },
                                    ::std::option::Option::None => ::prism_rtl::Turn::Finished(false),
                                    _ => unreachable!("no arm matched"),
                                }
                            },
                        }
                    },
                    _ => ::prism_rtl::Turn::Finished(false),
                }
            },
        }
    }
}

/// `Start IsLateExpr, x`: what the function value is when passed to `@Run`.
pub fn start_is_late_expr_f(lx_p0: crate::lower::Lx, menv_p1: crate::lower::types::Env, e_p2: crate::syntax::Expr, depth_p3: crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>> {
    ::std::rc::Rc::new(IsLateExpr { lx_p0, menv_p1, e_p2, depth_p3 })
}

/// ```prism
/// IsRecursingCall: unbounded fn Lx, Text, ValInfo, Expr -> Bool
/// ```
pub fn is_recursing_call_f(lx_p0: &crate::lower::Lx, q_p1: &crate::prelude::Text, v_p2: &crate::check::env::ValInfo, e_p3: &crate::syntax::Expr) -> bool {
    let ptys_p4 = match &v_p2.scheme_p.ty_p {
        crate::check::types::Ty::TyFn(_, ps_p5, _) => ps_p5.clone(),
        _ => crate::prelude::Array::new(),
    };
    (((crate::check::types::has_text_f(&lx_p0.recursing_p, q_p1) && is_plain_result_f(lx_p0, e_p3)) && !crate::lower::types::is_bundle_f(&line_out_full_f(lx_p0, e_p3))) && (&crate::prelude::len(&crate::lower::node_::static_::rigids_in_f(&v_p2.scheme_p.ty_p)) == &crate::prelude::Nat::from(0u32))) && crate::prelude::fold(&ptys_p4, &true, &(|ok_p6: &bool, pt_p7: &crate::check::types::Ty| (*ok_p6 && (&crate::lower::types::layer_of_f(pt_p7) == &crate::lower::types::Layer::LyPlain)) && !crate::lower::node_::static_::is_widget_fn_ty_f(pt_p7)))
}

/// The step machine of `IsRecursingCall`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// IsRecursingCall: unbounded fn Lx, Text, ValInfo, Expr -> Bool
/// ```
pub struct IsRecursingCall {
    pub lx_p0: crate::lower::Lx,
    pub q_p1: crate::prelude::Text,
    pub v_p2: crate::check::env::ValInfo,
    pub e_p3: crate::syntax::Expr,
}

impl ::prism_rtl::Job<bool> for IsRecursingCall {
    fn cycle(&self) -> ::prism_rtl::Turn<bool> {
        let lx_p0 = &self.lx_p0;
        let q_p1 = &self.q_p1;
        let v_p2 = &self.v_p2;
        let e_p3 = &self.e_p3;
        let ptys_p4 = match &v_p2.scheme_p.ty_p {
            crate::check::types::Ty::TyFn(_, ps_p5, _) => ps_p5.clone(),
            _ => crate::prelude::Array::new(),
        };
        ::prism_rtl::Turn::Finished((((crate::check::types::has_text_f(&lx_p0.recursing_p, q_p1) && is_plain_result_f(lx_p0, e_p3)) && !crate::lower::types::is_bundle_f(&line_out_full_f(lx_p0, e_p3))) && (&crate::prelude::len(&crate::lower::node_::static_::rigids_in_f(&v_p2.scheme_p.ty_p)) == &crate::prelude::Nat::from(0u32))) && crate::prelude::fold(&ptys_p4, &true, &(|ok_p6: &bool, pt_p7: &crate::check::types::Ty| (*ok_p6 && (&crate::lower::types::layer_of_f(pt_p7) == &crate::lower::types::Layer::LyPlain)) && !crate::lower::node_::static_::is_widget_fn_ty_f(pt_p7))))
    }
}

/// `Start IsRecursingCall, x`: what the function value is when passed to `@Run`.
pub fn start_is_recursing_call_f(lx_p0: crate::lower::Lx, q_p1: crate::prelude::Text, v_p2: crate::check::env::ValInfo, e_p3: crate::syntax::Expr) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>> {
    ::std::rc::Rc::new(IsRecursingCall { lx_p0, q_p1, v_p2, e_p3 })
}

/// ```prism
/// CalleeWidgetEnv: unbounded fn Lx, Env, Text, ValInfo, [Arg] -> Env
/// ```
pub fn callee_widget_env_f(lx_p0: &crate::lower::Lx, menv_p1: &crate::lower::types::Env, qk_p2: &crate::prelude::Text, v_p3: &crate::check::env::ValInfo, args_p4: &crate::prelude::Array<crate::syntax::Arg>) -> crate::lower::types::Env {
    let lxc_p5 = crate::lower::program::in_module_at_f(lx_p0, &v_p3.file_p, &v_p3.home_p, &lx_p0.site_p);
    let ptys_p6 = match &v_p3.scheme_p.ty_p {
        crate::check::types::Ty::TyFn(_, ps_p7, _) => ps_p7.clone(),
        _ => crate::prelude::Array::new(),
    };
    'm31165: {
        let scrutinee = &crate::lower::jobs::clauses_of_f(&lx_p0.g_p, qk_p2);
        if let m31165_0 = scrutinee && (m31165_0.len() == 1) && let ::std::option::Option::Some(c_p8) = crate::prelude::index(m31165_0, &crate::prelude::Nat::from(0u32)) {
            break 'm31165 crate::prelude::fold(&crate::check::errors::range0_f(&crate::prelude::len(&c_p8.params_p)), &crate::lower::types::empty_env_p(), &(|en_p9: &crate::lower::types::Env, i_pa: &crate::prelude::Nat| match (crate::prelude::index(&c_p8.params_p, i_pa), crate::prelude::index(&ptys_p6, i_pa), crate::prelude::index(args_p4, i_pa)) {
                (::std::option::Option::Some(p_pb), ::std::option::Option::Some(pt_pc), ::std::option::Option::Some(a_pd)) if (&crate::lower::types::layer_of_f(&pt_pc) == &crate::lower::types::Layer::LyBlueprint) => crate::lower::types::bind_f(en_p9, &crate::lower::functions::plain_binder_f(&lxc_p5, &p_pb), &crate::lower::types::Bn::BnWidget(a_pd.value_p.clone(), crate::lower::types::empty_env_p(), menv_p1.clone(), lx_p0.clone())),
                _ => en_p9.clone(),
                _ => unreachable!("no arm matched"),
            }));
        }
        crate::lower::types::empty_env_p()
    }
}

/// The step machine of `CalleeWidgetEnv`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CalleeWidgetEnv: unbounded fn Lx, Env, Text, ValInfo, [Arg] -> Env
/// ```
pub struct CalleeWidgetEnv {
    pub lx_p0: crate::lower::Lx,
    pub menv_p1: crate::lower::types::Env,
    pub qk_p2: crate::prelude::Text,
    pub v_p3: crate::check::env::ValInfo,
    pub args_p4: crate::prelude::Array<crate::syntax::Arg>,
}

impl ::prism_rtl::Job<crate::lower::types::Env> for CalleeWidgetEnv {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::lower::types::Env> {
        let lx_p0 = &self.lx_p0;
        let menv_p1 = &self.menv_p1;
        let qk_p2 = &self.qk_p2;
        let v_p3 = &self.v_p3;
        let args_p4 = &self.args_p4;
        let lxc_p5 = crate::lower::program::in_module_at_f(lx_p0, &v_p3.file_p, &v_p3.home_p, &lx_p0.site_p);
        let ptys_p6 = match &v_p3.scheme_p.ty_p {
            crate::check::types::Ty::TyFn(_, ps_p7, _) => ps_p7.clone(),
            _ => crate::prelude::Array::new(),
        };
        'm31165: {
            let scrutinee = &crate::lower::jobs::clauses_of_f(&lx_p0.g_p, qk_p2);
            if let m31165_0 = scrutinee && (m31165_0.len() == 1) && let ::std::option::Option::Some(c_p8) = crate::prelude::index(m31165_0, &crate::prelude::Nat::from(0u32)) {
                break 'm31165 ::prism_rtl::Turn::Finished(crate::prelude::fold(&crate::check::errors::range0_f(&crate::prelude::len(&c_p8.params_p)), &crate::lower::types::empty_env_p(), &(|en_p9: &crate::lower::types::Env, i_pa: &crate::prelude::Nat| match (crate::prelude::index(&c_p8.params_p, i_pa), crate::prelude::index(&ptys_p6, i_pa), crate::prelude::index(args_p4, i_pa)) {
                    (::std::option::Option::Some(p_pb), ::std::option::Option::Some(pt_pc), ::std::option::Option::Some(a_pd)) if (&crate::lower::types::layer_of_f(&pt_pc) == &crate::lower::types::Layer::LyBlueprint) => crate::lower::types::bind_f(en_p9, &crate::lower::functions::plain_binder_f(&lxc_p5, &p_pb), &crate::lower::types::Bn::BnWidget(a_pd.value_p.clone(), crate::lower::types::empty_env_p(), menv_p1.clone(), lx_p0.clone())),
                    _ => en_p9.clone(),
                    _ => unreachable!("no arm matched"),
                })));
            }
            ::prism_rtl::Turn::Finished(crate::lower::types::empty_env_p())
        }
    }
}

/// `Start CalleeWidgetEnv, x`: what the function value is when passed to `@Run`.
pub fn start_callee_widget_env_f(lx_p0: crate::lower::Lx, menv_p1: crate::lower::types::Env, qk_p2: crate::prelude::Text, v_p3: crate::check::env::ValInfo, args_p4: crate::prelude::Array<crate::syntax::Arg>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::types::Env>> {
    ::std::rc::Rc::new(CalleeWidgetEnv { lx_p0, menv_p1, qk_p2, v_p3, args_p4 })
}

/// ```prism
/// ?OneBody: unbounded fn Lx, Text -> ?Block
/// ```
pub fn one_body_o(lx_p0: &crate::lower::Lx, qk_p1: &crate::prelude::Text) -> ::std::option::Option<crate::syntax::Block> {
    match crate::lower::node_::static_::widget_decl_of_o(&lx_p0.g_p, qk_p1) {
        ::std::option::Option::Some(wd_p2) => ::std::option::Option::Some(wd_p2.body_p.clone()),
        ::std::option::Option::None => 'm31662: {
            let scrutinee = &crate::lower::jobs::clauses_of_f(&lx_p0.g_p, qk_p1);
            if let m31662_0 = scrutinee && (m31662_0.len() == 1) && let ::std::option::Option::Some(c_p3) = crate::prelude::index(m31662_0, &crate::prelude::Nat::from(0u32)) {
                break 'm31662 match &c_p3.body_p {
                    crate::syntax::decls::FnBody::BodyBlock(b_p4) => ::std::option::Option::Some(b_p4.clone()),
                    crate::syntax::decls::FnBody::BodyExpr(x_p5) => ::std::option::Option::Some(crate::syntax::Block { stmts_p: crate::prelude::Array::from(vec![crate::syntax::Stmt { kind_p: crate::syntax::StmtKind::SExpr(x_p5.clone()), span_p: x_p5.span_p.clone() }]), inline_p: true, span_p: x_p5.span_p.clone() }),
                };
            }
            ::std::option::Option::None
        },
    }
}

/// The step machine of `OneBody`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?OneBody: unbounded fn Lx, Text -> ?Block
/// ```
pub struct OneBody {
    pub lx_p0: crate::lower::Lx,
    pub qk_p1: crate::prelude::Text,
}

impl ::prism_rtl::Job<::std::option::Option<crate::syntax::Block>> for OneBody {
    fn cycle(&self) -> ::prism_rtl::Turn<::std::option::Option<crate::syntax::Block>> {
        let lx_p0 = &self.lx_p0;
        let qk_p1 = &self.qk_p1;
        match crate::lower::node_::static_::widget_decl_of_o(&lx_p0.g_p, qk_p1) {
            ::std::option::Option::Some(wd_p2) => ::prism_rtl::Turn::Finished(::std::option::Option::Some(wd_p2.body_p.clone())),
            ::std::option::Option::None => 'm31662: {
                let scrutinee = &crate::lower::jobs::clauses_of_f(&lx_p0.g_p, qk_p1);
                if let m31662_0 = scrutinee && (m31662_0.len() == 1) && let ::std::option::Option::Some(c_p3) = crate::prelude::index(m31662_0, &crate::prelude::Nat::from(0u32)) {
                    break 'm31662 match &c_p3.body_p {
                        crate::syntax::decls::FnBody::BodyBlock(b_p4) => ::prism_rtl::Turn::Finished(::std::option::Option::Some(b_p4.clone())),
                        crate::syntax::decls::FnBody::BodyExpr(x_p5) => ::prism_rtl::Turn::Finished(::std::option::Option::Some(crate::syntax::Block { stmts_p: crate::prelude::Array::from(vec![crate::syntax::Stmt { kind_p: crate::syntax::StmtKind::SExpr(x_p5.clone()), span_p: x_p5.span_p.clone() }]), inline_p: true, span_p: x_p5.span_p.clone() })),
                    };
                }
                ::prism_rtl::Turn::Finished(::std::option::Option::None)
            },
        }
    }
}

/// `Start OneBody, x`: what the function value is when passed to `@Run`.
pub fn start_one_body_o(lx_p0: crate::lower::Lx, qk_p1: crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<::std::option::Option<crate::syntax::Block>>> {
    ::std::rc::Rc::new(OneBody { lx_p0, qk_p1 })
}

/// ```prism
/// IsLateBlock: unbounded fn Lx, Env, Block, Nat -> Bool
/// ```
pub fn is_late_block_f(lx_p0: &crate::lower::Lx, menv_p1: &crate::lower::types::Env, b_p2: &crate::syntax::Block, depth_p3: &crate::prelude::Nat) -> bool {
    match &crate::prelude::or(&crate::prelude::index(&b_p2.stmts_p, &crate::syntax::lexer::chars::dec_f(&crate::prelude::len(&b_p2.stmts_p))), &crate::lower::expr::dummy_stmt_l_p()).kind_p {
        crate::syntax::StmtKind::SExpr(x_p4) => is_plain_result_f(lx_p0, x_p4) && (crate::lower::node_::switch_::is_some_f(&late_line_at_o(lx_p0, menv_p1, b_p2, depth_p3)) || is_late_expr_f(lx_p0, &with_local_widgets_f(menv_p1, b_p2), x_p4, depth_p3)),
        _ => false,
    }
}

/// The step machine of `IsLateBlock`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// IsLateBlock: unbounded fn Lx, Env, Block, Nat -> Bool
/// ```
pub struct IsLateBlock {
    pub lx_p0: crate::lower::Lx,
    pub menv_p1: crate::lower::types::Env,
    pub b_p2: crate::syntax::Block,
    pub depth_p3: crate::prelude::Nat,
}

impl ::prism_rtl::Job<bool> for IsLateBlock {
    fn cycle(&self) -> ::prism_rtl::Turn<bool> {
        let lx_p0 = &self.lx_p0;
        let menv_p1 = &self.menv_p1;
        let b_p2 = &self.b_p2;
        let depth_p3 = &self.depth_p3;
        match &crate::prelude::or(&crate::prelude::index(&b_p2.stmts_p, &crate::syntax::lexer::chars::dec_f(&crate::prelude::len(&b_p2.stmts_p))), &crate::lower::expr::dummy_stmt_l_p()).kind_p {
            crate::syntax::StmtKind::SExpr(x_p4) => {
                let b_p2x = b_p2.clone();
                let depth_p3x = depth_p3.clone();
                let lx_p0x = lx_p0.clone();
                let menv_p1x = menv_p1.clone();
                let x_p4x = x_p4.clone();
                crate::prelude::call_then(start_is_plain_result_f(lx_p0x.clone(), x_p4x.clone()), move |is_plain_result_f_32156: bool| if is_plain_result_f_32156 {
                    crate::prelude::call_then(start_late_line_at_o(lx_p0x.clone(), menv_p1x.clone(), b_p2x.clone(), depth_p3x.clone()), move |late_line_at_o_32191: ::std::option::Option<crate::prelude::Nat>| if crate::lower::node_::switch_::is_some_f(&late_line_at_o_32191) {
                        ::prism_rtl::Turn::Finished(true)
                    } else {
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(IsLateExpr { lx_p0: lx_p0x.clone(), menv_p1: with_local_widgets_f(&menv_p1x, &b_p2x), e_p2: x_p4x.clone(), depth_p3: depth_p3x.clone() }))
                    })
                } else {
                    ::prism_rtl::Turn::Finished(false)
                })
            },
            _ => ::prism_rtl::Turn::Finished(false),
        }
    }
}

/// `Start IsLateBlock, x`: what the function value is when passed to `@Run`.
pub fn start_is_late_block_f(lx_p0: crate::lower::Lx, menv_p1: crate::lower::types::Env, b_p2: crate::syntax::Block, depth_p3: crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>> {
    ::std::rc::Rc::new(IsLateBlock { lx_p0, menv_p1, b_p2, depth_p3 })
}

/// ```prism
/// IsPlainResult: unbounded fn Lx, Expr -> Bool
/// ```
pub fn is_plain_result_f(lx_p0: &crate::lower::Lx, e_p1: &crate::syntax::Expr) -> bool {
    plain_in_f(lx_p0, &line_out_full_f(lx_p0, e_p1))
}

/// The step machine of `IsPlainResult`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// IsPlainResult: unbounded fn Lx, Expr -> Bool
/// ```
pub struct IsPlainResult {
    pub lx_p0: crate::lower::Lx,
    pub e_p1: crate::syntax::Expr,
}

impl ::prism_rtl::Job<bool> for IsPlainResult {
    fn cycle(&self) -> ::prism_rtl::Turn<bool> {
        let lx_p0 = &self.lx_p0;
        let e_p1 = &self.e_p1;
        ::prism_rtl::Turn::More(::std::rc::Rc::new(PlainIn { lx_p0: lx_p0.clone(), t_p1: line_out_full_f(lx_p0, e_p1) }))
    }
}

/// `Start IsPlainResult, x`: what the function value is when passed to `@Run`.
pub fn start_is_plain_result_f(lx_p0: crate::lower::Lx, e_p1: crate::syntax::Expr) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>> {
    ::std::rc::Rc::new(IsPlainResult { lx_p0, e_p1 })
}

/// ```prism
/// PlainIn: unbounded fn Lx, Ty -> Bool
/// ```
pub fn plain_in_f(lx_p0: &crate::lower::Lx, t_p1: &crate::check::types::Ty) -> bool {
    match t_p1 {
        crate::check::types::Ty::TyTuple(ts_p2) if crate::lower::types::is_bundle_f(t_p1) => crate::prelude::run_to_end(crate::prelude::fold_job(ts_p2.clone(), false, {
            let lx_p0x = lx_p0.clone();
            ::std::rc::Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| {
                let lx_p0xy = lx_p0x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let found_p3 = p0;
                    let x_p4 = p1;
                    if found_p3 {
                        ::prism_rtl::Turn::Finished(true)
                    } else {
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(PlainIn { lx_p0: lx_p0xy.clone(), t_p1: x_p4.clone() }))
                    }
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::check::types::Ty)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
        })),
        _ => (&crate::lower::types::layer_of_f(t_p1) == &crate::lower::types::Layer::LyPlain) && (&crate::lower::types::out_ty_of_f(lx_p0, &crate::lower::types::peel_f(t_p1)) != &crate::lower::model::OutTy::OutUnit),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `PlainIn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PlainIn: unbounded fn Lx, Ty -> Bool
/// ```
pub struct PlainIn {
    pub lx_p0: crate::lower::Lx,
    pub t_p1: crate::check::types::Ty,
}

impl ::prism_rtl::Job<bool> for PlainIn {
    fn cycle(&self) -> ::prism_rtl::Turn<bool> {
        let lx_p0 = &self.lx_p0;
        let t_p1 = &self.t_p1;
        match t_p1 {
            crate::check::types::Ty::TyTuple(ts_p2) if crate::lower::types::is_bundle_f(t_p1) => crate::prelude::fold_job(ts_p2.clone(), false, {
                let lx_p0x = lx_p0.clone();
                ::std::rc::Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| {
                    let lx_p0xy = lx_p0x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let found_p3 = p0;
                        let x_p4 = p1;
                        if found_p3 {
                            ::prism_rtl::Turn::Finished(true)
                        } else {
                            ::prism_rtl::Turn::More(::std::rc::Rc::new(PlainIn { lx_p0: lx_p0xy.clone(), t_p1: x_p4.clone() }))
                        }
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::check::types::Ty)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
            }).cycle(),
            _ => if &crate::lower::types::layer_of_f(t_p1) == &crate::lower::types::Layer::LyPlain {
                {
                    let lx_p0x = lx_p0.clone();
                    let t_p1x = t_p1.clone();
                    crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0x.clone(), crate::lower::types::peel_f(&t_p1x)), move |out_ty_of_f_32789: crate::lower::model::OutTy| ::prism_rtl::Turn::Finished(&out_ty_of_f_32789 != &crate::lower::model::OutTy::OutUnit))
                }
            } else {
                ::prism_rtl::Turn::Finished(false)
            },
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start PlainIn, x`: what the function value is when passed to `@Run`.
pub fn start_plain_in_f(lx_p0: crate::lower::Lx, t_p1: crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>> {
    ::std::rc::Rc::new(PlainIn { lx_p0, t_p1 })
}

/// ```prism
/// LineOutFull: fn Lx, Expr -> Ty
/// ```
pub fn line_out_full_f(lx_p0: &crate::lower::Lx, e_p1: &crate::syntax::Expr) -> crate::check::types::Ty {
    let full_p2 = crate::lower::type_at_f(lx_p0, &e_p1.span_p);
    match crate::lower::types::peel_f(&full_p2) {
        crate::check::types::Ty::TyElem(_, o_p3) => (*o_p3).clone(),
        _ => match &full_p2 {
            crate::check::types::Ty::TyAt(i_p4, _) => (**i_p4).clone(),
            _ => full_p2.clone(),
        },
    }
}

/// ```prism
/// LineResult: unbounded fn Lx, Expr -> ((OutTy, Layer))
/// ```
pub fn line_result_f(lx_p0: &crate::lower::Lx, e_p1: &crate::syntax::Expr) -> (crate::lower::model::OutTy, crate::lower::types::Layer) {
    let full_p2 = crate::lower::type_at_f(lx_p0, &e_p1.span_p);
    match crate::lower::types::peel_f(&full_p2) {
        crate::check::types::Ty::TyElem(_, o_p3) => (crate::lower::types::out_ty_of_f(lx_p0, &crate::lower::types::peel_f(&*o_p3)), crate::lower::types::layer_of_f(&*o_p3)),
        _ => (crate::lower::types::out_ty_of_f(lx_p0, &crate::lower::types::out_of_f(&full_p2)), crate::lower::node_::switch_::result_layer_f(&full_p2)),
    }
}

/// The step machine of `LineResult`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LineResult: unbounded fn Lx, Expr -> ((OutTy, Layer))
/// ```
pub struct LineResult {
    pub lx_p0: crate::lower::Lx,
    pub e_p1: crate::syntax::Expr,
}

impl ::prism_rtl::Job<(crate::lower::model::OutTy, crate::lower::types::Layer)> for LineResult {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::lower::model::OutTy, crate::lower::types::Layer)> {
        let lx_p0 = &self.lx_p0;
        let e_p1 = &self.e_p1;
        let full_p2 = crate::lower::type_at_f(lx_p0, &e_p1.span_p);
        match crate::lower::types::peel_f(&full_p2) {
            crate::check::types::Ty::TyElem(_, o_p3) => {
                let lx_p0x = lx_p0.clone();
                crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0x.clone(), crate::lower::types::peel_f(&*o_p3)), move |out_ty_of_f_33471: crate::lower::model::OutTy| ::prism_rtl::Turn::Finished((out_ty_of_f_33471, crate::lower::types::layer_of_f(&*o_p3))))
            },
            _ => {
                let lx_p0x = lx_p0.clone();
                crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0x.clone(), crate::lower::types::out_of_f(&full_p2)), move |out_ty_of_f_33530: crate::lower::model::OutTy| ::prism_rtl::Turn::Finished((out_ty_of_f_33530, crate::lower::node_::switch_::result_layer_f(&full_p2))))
            },
        }
    }
}

/// `Start LineResult, x`: what the function value is when passed to `@Run`.
pub fn start_line_result_f(lx_p0: crate::lower::Lx, e_p1: crate::syntax::Expr) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::model::OutTy, crate::lower::types::Layer)>> {
    ::std::rc::Rc::new(LineResult { lx_p0, e_p1 })
}

/// ```prism
/// SplitBlockInto: unbounded fn Wx, Env, Env, Block, Nat -> Wx
/// ```
pub fn split_block_into_f(wx00_p0: &crate::lower::node_::Wx, benv00_p1: &crate::lower::types::Env, menv00_p2: &crate::lower::types::Env, b_p3: &crate::syntax::Block, k_p4: &crate::prelude::Nat) -> crate::lower::node_::Wx {
    let lx_p5 = wx00_p0.lx_p.clone();
    let outer_late_p6 = wx00_p0.late_inits_p.clone();
    let outer_asks_p7 = wx00_p0.late_asks_p.clone();
    let wxa_p8 = {
        let mut this: crate::lower::node_::Wx = wx00_p0.clone();
        this.late_inits_p = crate::prelude::Array::new();
        this.late_asks_p = crate::prelude::Array::new();
        this
    };
    let s_p9 = crate::prelude::or(&crate::prelude::index(&b_p3.stmts_p, k_p4), &crate::lower::expr::dummy_stmt_l_p());
    let bundled_pa = match &s_p9.kind_p {
        crate::syntax::StmtKind::SBind(_, e_pl, ::std::option::Option::None) => crate::lower::types::is_bundle_f(&line_out_full_f(&lx_p5, e_pl)),
        _ => false,
    };
    let (wx_pm, benv_pn, menv_po) = if bundled_pa {
        pre_bind_f(&wxa_p8, benv00_p1, menv00_p2, &s_p9)
    } else {
        (wxa_p8.clone(), benv00_p1.clone(), menv00_p2.clone())
    };
    let late_names_pb = match &s_p9.kind_p {
        crate::syntax::StmtKind::SBind(p_pp, _, ::std::option::Option::None) => crate::prelude::filter(&crate::check::env::names::pattern_names_f(p_pp), &(|n_pq: &crate::prelude::Text| !is_time_name_f(n_pq))),
        _ => crate::prelude::Array::new(),
    };
    let below_pc = crate::prelude::drop(&b_p3.stmts_p, &(k_p4 + &crate::prelude::Nat::from(1u32)));
    let above_reads_pd = crate::prelude::run_to_end(crate::prelude::fold_job(crate::prelude::take(&b_p3.stmts_p, k_p4), crate::prelude::Array::new(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::syntax::Stmt)| crate::prelude::entered(crate::prelude::once_job(move || {
        let acc_pr = p0;
        let st_ps = p1;
        crate::prelude::call_then(start_reads_of_line_f(st_ps.clone()), move |reads_of_line_f_36332: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_pr, &reads_of_line_f_36332)))
    }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::syntax::Stmt)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>));
    let hoisted_pe = hoisted_lines_f(&below_pc, &late_names_pb, &above_reads_pd);
    let staying0_pf = crate::prelude::filter(&below_pc, &(|st_pt: &crate::syntax::Stmt| !has_stmt_f(&hoisted_pe, st_pt)));
    let last_hoisted_pg = match crate::prelude::index(&b_p3.stmts_p, &crate::syntax::lexer::chars::dec_f(&crate::prelude::len(&b_p3.stmts_p))) {
        ::std::option::Option::Some(st_pu) => (&(k_p4 + &crate::prelude::Nat::from(1u32)) < &crate::prelude::len(&b_p3.stmts_p)) && has_stmt_f(&hoisted_pe, &st_pu),
        ::std::option::Option::None => false,
    };
    let staying_ph = if last_hoisted_pg { unresulted_f(&staying0_pf) } else { staying0_pf.clone() };
    let head_pi = crate::syntax::Block { stmts_p: crate::prelude::append(&crate::prelude::take(&b_p3.stmts_p, k_p4), &hoisted_pe), inline_p: b_p3.inline_p, span_p: b_p3.span_p.clone() };
    let rest_pj = crate::syntax::Block { stmts_p: staying_ph.clone(), inline_p: b_p3.inline_p, span_p: b_p3.span_p.clone() };
    let (wxu_pv, beu_p10, meu_p11, ups_p12) = pre_bind_ups_f(&wx_pm, &benv_pn, &menv_po, &staying_ph);
    let whole_ok = if !bundled_pa {
        ::std::option::Option::None
    } else {
        match &s_p9.kind_p {
            crate::syntax::StmtKind::SBind(p_p13, _, ::std::option::Option::None) => one_name_o(p_p13),
            _ => ::std::option::Option::None,
        }
    };
    let (wxl_p19, bel_p1a, mel_p1b, lates_p1c) = match (whole_ok.clone(), s_p9.kind_p.clone()) {
        (::std::option::Option::Some(n_p14), crate::syntax::StmtKind::SBind(_, e_p15, ::std::option::Option::None)) => {
            let (w_p16, be_p17, me_p18) = pre_bind_whole_f(&wxu_pv, &beu_p10, &meu_p11, &n_p14, &crate::lower::node_::keyed::bundle_part_tys_f(&line_out_full_f(&lx_p5, &e_p15)));
            (w_p16.clone(), be_p17.clone(), me_p18.clone(), crate::prelude::Array::new())
        },
        _ => bind_late_f(&wxu_pv, &beu_p10, &meu_p11, &s_p9),
    };
    let (wx0_p1d, be0_p1e, me0_p1f) = lines_into_f(&wxl_p19, &bel_p1a, &mel_p1b, &head_pi, &true);
    let (wx1w_p1k, be1w_p1l, me1w_p1m) = crate::prelude::run_to_end(crate::prelude::fold_job(line_exprs_f(&s_p9), (wx0_p1d.clone(), be0_p1e.clone(), me0_p1f.clone()), ::std::rc::Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::syntax::Expr)| crate::prelude::entered(crate::prelude::once_job(move || {
        let (w_p1g, be_p1h, me_p1i) = p0;
        let e_p1j = p1;
        ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::lower::node_::static_::WholeArgs { wx_p0: w_p1g.clone(), benv_p1: be_p1h.clone(), menv_p2: me_p1i.clone(), e_p3: e_p1j.clone(), whole_p4: false }))
    }))) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::syntax::Expr)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>>>));
    let (wx1_p1r, be1_p1s, me1_p1t) = crate::prelude::run_to_end(crate::prelude::fold_job(line_exprs_f(&s_p9), (wx1w_p1k.clone(), be1w_p1l.clone(), me1w_p1m.clone()), {
        let s_p9x = s_p9.clone();
        ::std::rc::Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::syntax::Expr)| {
            let s_p9xy = s_p9x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (w_p1n, be_p1o, me_p1p) = p0;
                let e_p1q = p1;
                ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::lower::node_::static_::BlueprintValuesAt { wx_p0: w_p1n.clone(), benv_p1: be_p1o.clone(), menv_p2: me_p1p.clone(), e_p3: e_p1q.clone(), named_p4: is_let_of_blueprint_f(&s_p9xy) }))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::syntax::Expr)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>>>
    }));
    match &s_p9.kind_p {
        crate::syntax::StmtKind::SBind(p_p1u, e_p1v, ::std::option::Option::None) => {
            let (wx2a_p22, late_p23) = build_line_f(&wx1_p1r, &be1_p1s, &me1_p1t, e_p1v, &::std::option::Option::None);
            let (wx2_p24, part_reads_p25) = late_parts_f(&wx2a_p22, &late_p23);
            let (wx2k_p2d, kept_p2e) = match &late_p23 {
                crate::lower::node_::Wres::WrLate(read_p26, _) => (wx2_p24.clone(), read_p26.clone()),
                crate::lower::node_::Wres::WrParts(_) => (wx2_p24.clone(), crate::lower::model::Ex::XTuple(crate::prelude::each(&part_reads_p25, &(|(_, read_p27): &(crate::prelude::Nat, crate::lower::model::Ex)| read_p27.clone())))),
                crate::lower::node_::Wres::WrPlain(ex_p28, t_p29) => {
                    let (f_p2b, w1_p2c) = crate::lower::node_::fresh_name_f(&wx2_p24, &crate::prelude::Text::lit("split_result"));
                    let w2_p2a = {
                        let mut this: crate::lower::node_::Wx = w1_p2c.clone();
                        this.lets_p = crate::prelude::push(&this.lets_p, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaBind(f_p2b.clone())), t_p29.clone()), ex_p28.clone()));
                        this.fields_p = crate::prelude::push(&this.fields_p, &(f_p2b.clone(), t_p29.clone(), crate::prelude::Text::lit("the plain result of the line a block is split at")));
                        this.inits_p = crate::prelude::push(&this.inits_p, &(f_p2b.clone(), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(f_p2b.clone())))));
                        this
                    };
                    (w2_p2a.clone(), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), f_p2b.clone()))))
                },
                _ => (wx2_p24.clone(), crate::lower::expr::refusal_f(&crate::prelude::Text::lit("a block split at a line whose result is not late"))),
            };
            let wx2g_p20 = late_getters_f(&wx2k_p2d, &lates_p1c, &kept_p2e, &part_reads_p25);
            let (wx2b_p2k, _, me2_p2l) = match (late_p23.clone(), (*p_p1u.kind_p).clone(), whole_ok.clone()) {
                (crate::lower::node_::Wres::WrParts(parts_p2f), _, ::std::option::Option::Some(n_p2g)) => bind_whole_f(&wx2g_p20, &be1_p1s, &me1_p1t, &n_p2g, &parts_p2f, &part_reads_p25),
                (crate::lower::node_::Wres::WrParts(parts_p2h), crate::syntax::PatternKind::PTuple(ps_p2i), ::std::option::Option::None) => bind_parts_f(&wx2g_p20, &be1_p1s, &me1_p1t, &crate::prelude::each(&parts_p2h, &(|q_p2j: &crate::lower::node_::Wres| if is_time_part_f(q_p2j) { q_p2j.clone() } else { crate::lower::node_::Wres::WrUnit })), &ps_p2i, &crate::prelude::Array::new()),
                _ => (wx2g_p20.clone(), be1_p1s.clone(), me1_p1t.clone()),
            };
            let wx2s_p21 = {
                let mut this: crate::lower::node_::Wx = with_late_inits_f(&wx2b_p2k, &crate::prelude::append(&wx2b_p2k.late_asks_p, &wx2b_p2k.late_inits_p));
                this.late_inits_p = outer_late_p6.clone();
                this.late_asks_p = outer_asks_p7.clone();
                this
            };
            if &crate::prelude::len(&staying_ph) == &crate::prelude::Nat::from(0u32) {
                set_result_f(&wx2s_p21, &crate::lower::node_::Wres::WrUnit)
            } else {
                {
                    let (out_ty_p2q, layer_p2r, out_full_p2s) = match &crate::prelude::or(&crate::prelude::index(&rest_pj.stmts_p, &crate::syntax::lexer::chars::dec_f(&crate::prelude::len(&rest_pj.stmts_p))), &crate::lower::expr::dummy_stmt_l_p()).kind_p {
                        crate::syntax::StmtKind::SExpr(x_p2n) => {
                            let (t_p2o, ly_p2p) = line_result_f(&lx_p5, x_p2n);
                            (t_p2o.clone(), ly_p2p.clone(), line_out_full_f(&lx_p5, x_p2n))
                        },
                        _ => (crate::lower::model::OutTy::OutUnit, crate::lower::types::Layer::LyPlain, crate::check::types::Ty::TyCon(crate::prelude::Text::lit("unit"), crate::prelude::Array::new())),
                    };
                    let row_env_p2m = without_names_f(&me2_p2l, &crate::prelude::each(&ups_p12, &(|(nkey_p2t, _, _): &(crate::prelude::Text, crate::prelude::Text, crate::prelude::Text)| nkey_p2t.clone())));
                    let (scrut_p2u, pats_p2v, sty_p30) = if !bundled_pa {
                        (kept_p2e.clone(), crate::prelude::Array::from(vec![::std::option::Option::Some(p_p1u.clone())]), crate::lower::types::out_of_f(&crate::lower::type_at_f(&lx_p5, &e_p1v.span_p)))
                    } else {
                        lower_binder_f(&lx_p5, p_p1u, e_p1v, &part_reads_p25)
                    };
                    let (wx3_p33, res_p34) = crate::lower::node_::switch_::building_choice_line_f(&wx2s_p21, &row_env_p2m, &scrut_p2u, &pats_p2v, &sty_p30, &crate::prelude::Array::from(vec![::std::option::Option::None]), &crate::prelude::Array::from(vec![rest_pj.clone()]), &out_ty_p2q, &layer_p2r, &out_full_p2s, &crate::prelude::each(&ups_p12, &(|(_, mine_p31, blocks_p32): &(crate::prelude::Text, crate::prelude::Text, crate::prelude::Text)| (mine_p31.clone(), blocks_p32.clone()))));
                    set_result_f(&wx3_p33, &res_p34)
                }
            }
        },
        _ => {
            let mut this: crate::lower::node_::Wx = wx1_p1r.clone();
            this.build_p = crate::prelude::push(&this.build_p, &crate::lower::expr::internal_bug_do_f(&crate::prelude::Text::lit("a block split at a line that binds nothing")));
            this
        },
    }
}

/// The step machine of `SplitBlockInto`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SplitBlockInto: unbounded fn Wx, Env, Env, Block, Nat -> Wx
/// ```
pub struct SplitBlockInto {
    pub wx00_p0: crate::lower::node_::Wx,
    pub benv00_p1: crate::lower::types::Env,
    pub menv00_p2: crate::lower::types::Env,
    pub b_p3: crate::syntax::Block,
    pub k_p4: crate::prelude::Nat,
}

impl ::prism_rtl::Job<crate::lower::node_::Wx> for SplitBlockInto {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::lower::node_::Wx> {
        let wx00_p0 = &self.wx00_p0;
        let benv00_p1 = &self.benv00_p1;
        let menv00_p2 = &self.menv00_p2;
        let b_p3 = &self.b_p3;
        let k_p4 = &self.k_p4;
        let lx_p5 = wx00_p0.lx_p.clone();
        let outer_late_p6 = wx00_p0.late_inits_p.clone();
        let outer_asks_p7 = wx00_p0.late_asks_p.clone();
        let wxa_p8 = {
            let mut this: crate::lower::node_::Wx = wx00_p0.clone();
            this.late_inits_p = crate::prelude::Array::new();
            this.late_asks_p = crate::prelude::Array::new();
            this
        };
        let s_p9 = crate::prelude::or(&crate::prelude::index(&b_p3.stmts_p, k_p4), &crate::lower::expr::dummy_stmt_l_p());
        let bundled_pa = match &s_p9.kind_p {
            crate::syntax::StmtKind::SBind(_, e_pl, ::std::option::Option::None) => crate::lower::types::is_bundle_f(&line_out_full_f(&lx_p5, e_pl)),
            _ => false,
        };
        let b_p3z = b_p3.clone();
        let bundled_paz = bundled_pa;
        let k_p4z = k_p4.clone();
        let lx_p5z = lx_p5.clone();
        let outer_asks_p7z = outer_asks_p7.clone();
        let outer_late_p6z = outer_late_p6.clone();
        let s_p9z = s_p9.clone();
        let k_let35856 = move |v35856: (crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)| {
            let (wx_pm, benv_pn, menv_po) = v35856;
            let b_p3zz = b_p3z.clone();
            let benv_pnz = benv_pn.clone();
            let bundled_pazz = bundled_paz;
            let k_p4zz = k_p4z.clone();
            let lx_p5zz = lx_p5z.clone();
            let menv_poz = menv_po.clone();
            let outer_asks_p7zz = outer_asks_p7z.clone();
            let outer_late_p6zz = outer_late_p6z.clone();
            let s_p9zz = s_p9z.clone();
            let wx_pmz = wx_pm.clone();
            let k_let35958 = move |v35958: crate::prelude::Array<crate::prelude::Text>| {
                let late_names_pb = v35958;
                let below_pc = crate::prelude::drop(&b_p3zz.stmts_p, &(&k_p4zz + &crate::prelude::Nat::from(1u32)));
                crate::prelude::call_value(crate::prelude::fold_job(crate::prelude::take(&b_p3zz.stmts_p, &k_p4zz), crate::prelude::Array::new(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::syntax::Stmt)| crate::prelude::entered(crate::prelude::once_job(move || {
                    let acc_pr = p0;
                    let st_ps = p1;
                    crate::prelude::call_then(start_reads_of_line_f(st_ps.clone()), move |reads_of_line_f_36332: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_pr, &reads_of_line_f_36332)))
                }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::syntax::Stmt)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>), move |fold_36274: crate::prelude::Array<crate::prelude::Text>| {
                    let above_reads_pd = fold_36274;
                    crate::prelude::call_then(start_hoisted_lines_f(below_pc.clone(), late_names_pb.clone(), above_reads_pd.clone()), move |hoisted_lines_f_36366: crate::prelude::Array<crate::syntax::Stmt>| {
                        let hoisted_pe = hoisted_lines_f_36366;
                        let staying0_pf = crate::prelude::filter(&below_pc, &(|st_pt: &crate::syntax::Stmt| !has_stmt_f(&hoisted_pe, st_pt)));
                        let last_hoisted_pg = match crate::prelude::index(&b_p3zz.stmts_p, &crate::syntax::lexer::chars::dec_f(&crate::prelude::len(&b_p3zz.stmts_p))) {
                            ::std::option::Option::Some(st_pu) => (&(&k_p4zz + &crate::prelude::Nat::from(1u32)) < &crate::prelude::len(&b_p3zz.stmts_p)) && has_stmt_f(&hoisted_pe, &st_pu),
                            ::std::option::Option::None => false,
                        };
                        let staying_ph = if last_hoisted_pg { unresulted_f(&staying0_pf) } else { staying0_pf.clone() };
                        let head_pi = crate::syntax::Block { stmts_p: crate::prelude::append(&crate::prelude::take(&b_p3zz.stmts_p, &k_p4zz), &hoisted_pe), inline_p: b_p3zz.inline_p, span_p: b_p3zz.span_p.clone() };
                        let rest_pj = crate::syntax::Block { stmts_p: staying_ph.clone(), inline_p: b_p3zz.inline_p, span_p: b_p3zz.span_p.clone() };
                        crate::prelude::call_then(start_pre_bind_ups_f(wx_pmz.clone(), benv_pnz.clone(), menv_poz.clone(), staying_ph.clone()), move |pre_bind_ups_f_36993: (crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env, crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text, crate::prelude::Text)>)| {
                            let (wxu_pv, beu_p10, meu_p11, ups_p12) = pre_bind_ups_f_36993;
                            let whole_ok = if !bundled_pazz {
                                ::std::option::Option::None
                            } else {
                                match &s_p9zz.kind_p {
                                    crate::syntax::StmtKind::SBind(p_p13, _, ::std::option::Option::None) => one_name_o(p_p13),
                                    _ => ::std::option::Option::None,
                                }
                            };
                            let whole_okz = whole_ok.clone();
                            let bundled_pazzz = bundled_pazz;
                            let head_piz = head_pi.clone();
                            let lx_p5zzz = lx_p5zz.clone();
                            let outer_asks_p7zzz = outer_asks_p7zz.clone();
                            let outer_late_p6zzz = outer_late_p6zz.clone();
                            let rest_pjz = rest_pj.clone();
                            let s_p9zzz = s_p9zz.clone();
                            let staying_phz = staying_ph.clone();
                            let ups_p12z = ups_p12.clone();
                            let k_let37290 = move |v37290: (crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env, crate::prelude::Array<LateName>)| {
                                let (wxl_p19, bel_p1a, mel_p1b, lates_p1c) = v37290;
                                crate::prelude::call_then(start_lines_into_f(wxl_p19.clone(), bel_p1a.clone(), mel_p1b.clone(), head_piz.clone(), true), move |lines_into_f_37594: (crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)| {
                                    let (wx0_p1d, be0_p1e, me0_p1f) = lines_into_f_37594;
                                    crate::prelude::call_value(crate::prelude::fold_job(line_exprs_f(&s_p9zzz), (wx0_p1d.clone(), be0_p1e.clone(), me0_p1f.clone()), ::std::rc::Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::syntax::Expr)| crate::prelude::entered(crate::prelude::once_job(move || {
                                        let (w_p1g, be_p1h, me_p1i) = p0;
                                        let e_p1j = p1;
                                        ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::lower::node_::static_::WholeArgs { wx_p0: w_p1g.clone(), benv_p1: be_p1h.clone(), menv_p2: me_p1i.clone(), e_p3: e_p1j.clone(), whole_p4: false }))
                                    }))) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::syntax::Expr)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>>>), move |fold_37661: (crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)| {
                                        let (wx1w_p1k, be1w_p1l, me1w_p1m) = fold_37661;
                                        crate::prelude::call_value(crate::prelude::fold_job(line_exprs_f(&s_p9zzz), (wx1w_p1k.clone(), be1w_p1l.clone(), me1w_p1m.clone()), {
                                            let s_p9zzzx = s_p9zzz.clone();
                                            ::std::rc::Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::syntax::Expr)| {
                                                let s_p9zzzxy = s_p9zzzx.clone();
                                                crate::prelude::entered(crate::prelude::once_job(move || {
                                                    let (w_p1n, be_p1o, me_p1p) = p0;
                                                    let e_p1q = p1;
                                                    ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::lower::node_::static_::BlueprintValuesAt { wx_p0: w_p1n.clone(), benv_p1: be_p1o.clone(), menv_p2: me_p1p.clone(), e_p3: e_p1q.clone(), named_p4: is_let_of_blueprint_f(&s_p9zzzxy) }))
                                                }))
                                            }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::syntax::Expr)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>>>
                                        }), move |fold_37778: (crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)| {
                                            let (wx1_p1r, be1_p1s, me1_p1t) = fold_37778;
                                            match &s_p9zzz.kind_p {
                                                crate::syntax::StmtKind::SBind(p_p1u, e_p1v, ::std::option::Option::None) => {
                                                    let e_p1vx = e_p1v.clone();
                                                    let p_p1ux = p_p1u.clone();
                                                    crate::prelude::call_then(start_build_line_f(wx1_p1r.clone(), be1_p1s.clone(), me1_p1t.clone(), e_p1vx.clone(), ::std::option::Option::None), move |build_line_f_37969: (crate::lower::node_::Wx, crate::lower::node_::Wres)| {
                                                        let (wx2a_p22, late_p23) = build_line_f_37969;
                                                        let (wx2_p24, part_reads_p25) = late_parts_f(&wx2a_p22, &late_p23);
                                                        let (wx2k_p2d, kept_p2e) = match &late_p23 {
                                                            crate::lower::node_::Wres::WrLate(read_p26, _) => (wx2_p24.clone(), read_p26.clone()),
                                                            crate::lower::node_::Wres::WrParts(_) => (wx2_p24.clone(), crate::lower::model::Ex::XTuple(crate::prelude::each(&part_reads_p25, &(|(_, read_p27): &(crate::prelude::Nat, crate::lower::model::Ex)| read_p27.clone())))),
                                                            crate::lower::node_::Wres::WrPlain(ex_p28, t_p29) => {
                                                                let (f_p2b, w1_p2c) = crate::lower::node_::fresh_name_f(&wx2_p24, &crate::prelude::Text::lit("split_result"));
                                                                let w2_p2a = {
                                                                    let mut this: crate::lower::node_::Wx = w1_p2c.clone();
                                                                    this.lets_p = crate::prelude::push(&this.lets_p, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaBind(f_p2b.clone())), t_p29.clone()), ex_p28.clone()));
                                                                    this.fields_p = crate::prelude::push(&this.fields_p, &(f_p2b.clone(), t_p29.clone(), crate::prelude::Text::lit("the plain result of the line a block is split at")));
                                                                    this.inits_p = crate::prelude::push(&this.inits_p, &(f_p2b.clone(), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(f_p2b.clone())))));
                                                                    this
                                                                };
                                                                (w2_p2a.clone(), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), f_p2b.clone()))))
                                                            },
                                                            _ => (wx2_p24.clone(), crate::lower::expr::refusal_f(&crate::prelude::Text::lit("a block split at a line whose result is not late"))),
                                                        };
                                                        crate::prelude::call_then(start_late_getters_f(wx2k_p2d.clone(), lates_p1c.clone(), kept_p2e.clone(), part_reads_p25.clone()), move |late_getters_f_39177: crate::lower::node_::Wx| {
                                                            let wx2g_p20 = late_getters_f_39177;
                                                            let bundled_pazzzz = bundled_pazzz;
                                                            let e_p1vxz = e_p1vx.clone();
                                                            let kept_p2ez = kept_p2e.clone();
                                                            let lx_p5zzzz = lx_p5zzz.clone();
                                                            let outer_asks_p7zzzz = outer_asks_p7zzz.clone();
                                                            let outer_late_p6zzzz = outer_late_p6zzz.clone();
                                                            let p_p1uxz = p_p1ux.clone();
                                                            let part_reads_p25z = part_reads_p25.clone();
                                                            let rest_pjzz = rest_pjz.clone();
                                                            let staying_phzz = staying_phz.clone();
                                                            let ups_p12zz = ups_p12z.clone();
                                                            let k_let39317 = move |v39317: (crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)| {
                                                                let (wx2b_p2k, _, me2_p2l) = v39317;
                                                                let wx2s_p21 = {
                                                                    let mut this: crate::lower::node_::Wx = with_late_inits_f(&wx2b_p2k, &crate::prelude::append(&wx2b_p2k.late_asks_p, &wx2b_p2k.late_inits_p));
                                                                    this.late_inits_p = outer_late_p6zzzz.clone();
                                                                    this.late_asks_p = outer_asks_p7zzzz.clone();
                                                                    this
                                                                };
                                                                if &crate::prelude::len(&staying_phzz) == &crate::prelude::Nat::from(0u32) {
                                                                    ::prism_rtl::Turn::Finished(set_result_f(&wx2s_p21, &crate::lower::node_::Wres::WrUnit))
                                                                } else {
                                                                    {
                                                                        let bundled_pazzzzz = bundled_pazzzz;
                                                                        let e_p1vxzz = e_p1vxz.clone();
                                                                        let kept_p2ezz = kept_p2ez.clone();
                                                                        let lx_p5zzzzz = lx_p5zzzz.clone();
                                                                        let me2_p2lz = me2_p2l.clone();
                                                                        let p_p1uxzz = p_p1uxz.clone();
                                                                        let part_reads_p25zz = part_reads_p25z.clone();
                                                                        let rest_pjzzz = rest_pjzz.clone();
                                                                        let ups_p12zzz = ups_p12zz.clone();
                                                                        let wx2s_p21z = wx2s_p21.clone();
                                                                        let k_let39995 = move |v39995: (crate::lower::model::OutTy, crate::lower::types::Layer, crate::check::types::Ty)| {
                                                                            let (out_ty_p2q, layer_p2r, out_full_p2s) = v39995;
                                                                            let row_env_p2m = without_names_f(&me2_p2lz, &crate::prelude::each(&ups_p12zzz, &(|(nkey_p2t, _, _): &(crate::prelude::Text, crate::prelude::Text, crate::prelude::Text)| nkey_p2t.clone())));
                                                                            let (scrut_p2u, pats_p2v, sty_p30) = if !bundled_pazzzzz {
                                                                                (kept_p2ezz.clone(), crate::prelude::Array::from(vec![::std::option::Option::Some(p_p1uxzz.clone())]), crate::lower::types::out_of_f(&crate::lower::type_at_f(&lx_p5zzzzz, &e_p1vxzz.span_p)))
                                                                            } else {
                                                                                lower_binder_f(&lx_p5zzzzz, &p_p1uxzz, &e_p1vxzz, &part_reads_p25zz)
                                                                            };
                                                                            crate::prelude::call_then(crate::lower::node_::switch_::start_building_choice_line_f(wx2s_p21z.clone(), row_env_p2m.clone(), scrut_p2u.clone(), pats_p2v.clone(), sty_p30.clone(), crate::prelude::Array::from(vec![::std::option::Option::None]), crate::prelude::Array::from(vec![rest_pjzzz.clone()]), out_ty_p2q.clone(), layer_p2r.clone(), out_full_p2s.clone(), crate::prelude::each(&ups_p12zzz, &(|(_, mine_p31, blocks_p32): &(crate::prelude::Text, crate::prelude::Text, crate::prelude::Text)| (mine_p31.clone(), blocks_p32.clone())))), move |building_choice_line_f_40824: (crate::lower::node_::Wx, crate::lower::node_::Wres)| {
                                                                                let (wx3_p33, res_p34) = building_choice_line_f_40824;
                                                                                ::prism_rtl::Turn::Finished(set_result_f(&wx3_p33, &res_p34))
                                                                            })
                                                                        };
                                                                        match crate::prelude::or(&crate::prelude::index(&rest_pjzz.stmts_p, &crate::syntax::lexer::chars::dec_f(&crate::prelude::len(&rest_pjzz.stmts_p))), &crate::lower::expr::dummy_stmt_l_p()).kind_p.clone() {
                                                                            crate::syntax::StmtKind::SExpr(x_p2n) => crate::prelude::call_then(start_line_result_f(lx_p5zzzz.clone(), x_p2n.clone()), move |line_result_f_40158: (crate::lower::model::OutTy, crate::lower::types::Layer)| {
                                                                                let (t_p2o, ly_p2p) = line_result_f_40158;
                                                                                k_let39995((t_p2o.clone(), ly_p2p.clone(), line_out_full_f(&lx_p5zzzz, &x_p2n)))
                                                                            }),
                                                                            _ => k_let39995((crate::lower::model::OutTy::OutUnit, crate::lower::types::Layer::LyPlain, crate::check::types::Ty::TyCon(crate::prelude::Text::lit("unit"), crate::prelude::Array::new()))),
                                                                        }
                                                                    }
                                                                }
                                                            };
                                                            match (late_p23.clone(), (*p_p1ux.kind_p).clone(), whole_okz.clone()) {
                                                                (crate::lower::node_::Wres::WrParts(parts_p2f), _, ::std::option::Option::Some(n_p2g)) => crate::prelude::call_then(start_bind_whole_f(wx2g_p20.clone(), be1_p1s.clone(), me1_p1t.clone(), n_p2g.clone(), parts_p2f.clone(), part_reads_p25.clone()), move |bind_whole_f_39427: (crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)| k_let39317(bind_whole_f_39427)),
                                                                (crate::lower::node_::Wres::WrParts(parts_p2h), crate::syntax::PatternKind::PTuple(ps_p2i), ::std::option::Option::None) => crate::prelude::call_then(start_bind_parts_f(wx2g_p20.clone(), be1_p1s.clone(), me1_p1t.clone(), crate::prelude::each(&parts_p2h, &(|q_p2j: &crate::lower::node_::Wres| if is_time_part_f(q_p2j) { q_p2j.clone() } else { crate::lower::node_::Wres::WrUnit })), ps_p2i.clone(), crate::prelude::Array::new()), move |bind_parts_f_39526: (crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)| k_let39317(bind_parts_f_39526)),
                                                                _ => k_let39317((wx2g_p20.clone(), be1_p1s.clone(), me1_p1t.clone())),
                                                            }
                                                        })
                                                    })
                                                },
                                                _ => ::prism_rtl::Turn::Finished({
                                                    let mut this: crate::lower::node_::Wx = wx1_p1r.clone();
                                                    this.build_p = crate::prelude::push(&this.build_p, &crate::lower::expr::internal_bug_do_f(&crate::prelude::Text::lit("a block split at a line that binds nothing")));
                                                    this
                                                }),
                                            }
                                        })
                                    })
                                })
                            };
                            match (whole_ok.clone(), s_p9zz.kind_p.clone()) {
                                (::std::option::Option::Some(n_p14), crate::syntax::StmtKind::SBind(_, e_p15, ::std::option::Option::None)) => crate::prelude::call_then(start_pre_bind_whole_f(wxu_pv.clone(), beu_p10.clone(), meu_p11.clone(), n_p14.clone(), crate::lower::node_::keyed::bundle_part_tys_f(&line_out_full_f(&lx_p5zz, &e_p15))), move |pre_bind_whole_f_37422: (crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)| {
                                    let (w_p16, be_p17, me_p18) = pre_bind_whole_f_37422;
                                    k_let37290((w_p16.clone(), be_p17.clone(), me_p18.clone(), crate::prelude::Array::new()))
                                }),
                                _ => crate::prelude::call_then(start_bind_late_f(wxu_pv.clone(), beu_p10.clone(), meu_p11.clone(), s_p9zz.clone()), move |bind_late_f_37540: (crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env, crate::prelude::Array<LateName>)| k_let37290(bind_late_f_37540)),
                            }
                        })
                    })
                })
            };
            match s_p9z.kind_p.clone() {
                crate::syntax::StmtKind::SBind(p_pp, _, ::std::option::Option::None) => crate::prelude::call_then(crate::check::env::names::start_pattern_names_f(p_pp.clone()), move |pattern_names_f_36026: crate::prelude::Array<crate::prelude::Text>| k_let35958(crate::prelude::filter(&pattern_names_f_36026, &(|n_pq: &crate::prelude::Text| !is_time_name_f(n_pq))))),
                _ => k_let35958(crate::prelude::Array::new()),
            }
        };
        if bundled_pa {
            {
                let benv00_p1x = benv00_p1.clone();
                let menv00_p2x = menv00_p2.clone();
                crate::prelude::call_then(start_pre_bind_f(wxa_p8.clone(), benv00_p1x.clone(), menv00_p2x.clone(), s_p9.clone()), move |pre_bind_f_35893: (crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)| k_let35856(pre_bind_f_35893))
            }
        } else {
            k_let35856((wxa_p8.clone(), benv00_p1.clone(), menv00_p2.clone()))
        }
    }
}

/// `Start SplitBlockInto, x`: what the function value is when passed to `@Run`.
pub fn start_split_block_into_f(wx00_p0: crate::lower::node_::Wx, benv00_p1: crate::lower::types::Env, menv00_p2: crate::lower::types::Env, b_p3: crate::syntax::Block, k_p4: crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::node_::Wx>> {
    ::std::rc::Rc::new(SplitBlockInto { wx00_p0, benv00_p1, menv00_p2, b_p3, k_p4 })
}

/// ```prism
/// ?OneName: fn Pattern -> ?SName
/// ```
pub fn one_name_o(p_p0: &crate::syntax::Pattern) -> ::std::option::Option<crate::syntax::SName> {
    match &*p_p0.kind_p {
        crate::syntax::PatternKind::PName(n_p1) => ::std::option::Option::Some(n_p1.clone()),
        crate::syntax::PatternKind::PGroup(q_p2) => one_name_o(&**q_p2),
        _ => ::std::option::Option::None,
    }
}

/// ```prism
/// PreBindWhole: unbounded fn Wx, Env, Env, SName, [Ty] -> ((Wx, Env, Env))
/// ```
pub fn pre_bind_whole_f(wx_p0: &crate::lower::node_::Wx, benv_p1: &crate::lower::types::Env, menv_p2: &crate::lower::types::Env, n_p3: &crate::syntax::SName, tys_p4: &crate::prelude::Array<crate::check::types::Ty>) -> (crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env) {
    let nkey_p5 = crate::check::env::sname_key_f(n_p3);
    let (wx2_p7, builds_p8, methods_p9) = pre_bind_whole_parts_f(wx_p0, &nkey_p5, &crate::lower::local_name_at_f(&wx_p0.lx_p, &nkey_p5, &n_p3.span_p), tys_p4);
    let marker_p6 = crate::lower::types::Bn::BnLocal(crate::lower::expr::refusal_f(&crate::prelude::Text::from(format!("the bundle `{}`, whose plain part is late, read as one value at its block\'s build", &nkey_p5))), crate::lower::types::Holding::Owned, crate::lower::model::OutTy::OutUnit);
    let (wx3_pa, me3_pb) = late_bundle_value_f(&wx2_p7, &crate::lower::types::bind_f(&crate::lower::types::bind_f(menv_p2, &nkey_p5, &crate::lower::types::Bn::BnParts(methods_p9.clone())), &crate::prelude::Text::from(format!("{}#late", &nkey_p5)), &marker_p6), &nkey_p5, &crate::lower::local_name_at_f(&wx_p0.lx_p, &nkey_p5, &n_p3.span_p), &methods_p9, &crate::lower::types::out_ty_of_f(&wx_p0.lx_p, &crate::check::types::Ty::TyTuple(tys_p4.clone())));
    (wx3_pa.clone(), crate::lower::types::bind_f(&crate::lower::types::bind_f(&crate::lower::types::bind_f(benv_p1, &nkey_p5, &crate::lower::types::Bn::BnParts(builds_p8.clone())), &crate::prelude::Text::from(format!("{}#late", &nkey_p5)), &marker_p6), &crate::prelude::Text::from(format!("{}#value", &nkey_p5)), &marker_p6), me3_pb.clone())
}

/// The step machine of `PreBindWhole`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PreBindWhole: unbounded fn Wx, Env, Env, SName, [Ty] -> ((Wx, Env, Env))
/// ```
pub struct PreBindWhole {
    pub wx_p0: crate::lower::node_::Wx,
    pub benv_p1: crate::lower::types::Env,
    pub menv_p2: crate::lower::types::Env,
    pub n_p3: crate::syntax::SName,
    pub tys_p4: crate::prelude::Array<crate::check::types::Ty>,
}

impl ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)> for PreBindWhole {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)> {
        let wx_p0 = &self.wx_p0;
        let benv_p1 = &self.benv_p1;
        let menv_p2 = &self.menv_p2;
        let n_p3 = &self.n_p3;
        let tys_p4 = &self.tys_p4;
        let nkey_p5 = crate::check::env::sname_key_f(n_p3);
        let benv_p1x = benv_p1.clone();
        let menv_p2x = menv_p2.clone();
        let n_p3x = n_p3.clone();
        let tys_p4x = tys_p4.clone();
        let wx_p0x = wx_p0.clone();
        crate::prelude::call_then(crate::lower::start_local_name_at_f(wx_p0x.lx_p.clone(), nkey_p5.clone(), n_p3x.span_p.clone()), move |local_name_at_f_42458: crate::prelude::Text| crate::prelude::call_then(start_pre_bind_whole_parts_f(wx_p0x.clone(), nkey_p5.clone(), local_name_at_f_42458, tys_p4x.clone()), move |pre_bind_whole_parts_f_42429: (crate::lower::node_::Wx, crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>, crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>)| {
            let (wx2_p7, builds_p8, methods_p9) = pre_bind_whole_parts_f_42429;
            let marker_p6 = crate::lower::types::Bn::BnLocal(crate::lower::expr::refusal_f(&crate::prelude::Text::from(format!("the bundle `{}`, whose plain part is late, read as one value at its block\'s build", &nkey_p5))), crate::lower::types::Holding::Owned, crate::lower::model::OutTy::OutUnit);
            crate::prelude::call_then(crate::lower::start_local_name_at_f(wx_p0x.lx_p.clone(), nkey_p5.clone(), n_p3x.span_p.clone()), move |local_name_at_f_42754: crate::prelude::Text| crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(wx_p0x.lx_p.clone(), crate::check::types::Ty::TyTuple(tys_p4x.clone())), move |out_ty_of_f_42798: crate::lower::model::OutTy| crate::prelude::call_then(start_late_bundle_value_f(wx2_p7.clone(), crate::lower::types::bind_f(&crate::lower::types::bind_f(&menv_p2x, &nkey_p5, &crate::lower::types::Bn::BnParts(methods_p9.clone())), &crate::prelude::Text::from(format!("{}#late", &nkey_p5)), &marker_p6), nkey_p5.clone(), local_name_at_f_42754, methods_p9.clone(), out_ty_of_f_42798), move |late_bundle_value_f_42658: (crate::lower::node_::Wx, crate::lower::types::Env)| {
                let (wx3_pa, me3_pb) = late_bundle_value_f_42658;
                ::prism_rtl::Turn::Finished((wx3_pa.clone(), crate::lower::types::bind_f(&crate::lower::types::bind_f(&crate::lower::types::bind_f(&benv_p1x, &nkey_p5, &crate::lower::types::Bn::BnParts(builds_p8.clone())), &crate::prelude::Text::from(format!("{}#late", &nkey_p5)), &marker_p6), &crate::prelude::Text::from(format!("{}#value", &nkey_p5)), &marker_p6), me3_pb.clone()))
            })))
        }))
    }
}

/// `Start PreBindWhole, x`: what the function value is when passed to `@Run`.
pub fn start_pre_bind_whole_f(wx_p0: crate::lower::node_::Wx, benv_p1: crate::lower::types::Env, menv_p2: crate::lower::types::Env, n_p3: crate::syntax::SName, tys_p4: crate::prelude::Array<crate::check::types::Ty>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>> {
    ::std::rc::Rc::new(PreBindWhole { wx_p0, benv_p1, menv_p2, n_p3, tys_p4 })
}

/// ```prism
/// LateBundleValue: unbounded fn Wx, Env, Text, Text, [?Bn], OutTy -> ((Wx, Env))
/// ```
pub fn late_bundle_value_f(wx_p0: &crate::lower::node_::Wx, menv_p1: &crate::lower::types::Env, nkey_p2: &crate::prelude::Text, stem_p3: &crate::prelude::Text, methods_p4: &crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>, t_p5: &crate::lower::model::OutTy) -> (crate::lower::node_::Wx, crate::lower::types::Env) {
    let simple_p6 = (&crate::prelude::len(methods_p4) > &crate::prelude::Nat::from(0u32)) && crate::prelude::fold(methods_p4, &true, &(|ok_p7: &bool, part_o8: &::std::option::Option<crate::lower::types::Bn>| *ok_p7 && match part_o8 {
        ::std::option::Option::Some(crate::lower::types::Bn::BnEv(_, _)) => true,
        ::std::option::Option::Some(crate::lower::types::Bn::BnDyn(_, _, _)) => true,
        ::std::option::Option::Some(crate::lower::types::Bn::BnHold(_, _)) => true,
        ::std::option::Option::Some(crate::lower::types::Bn::BnLocal(_, _, _)) => true,
        _ => false,
    }));
    if !simple_p6 {
        (wx_p0.clone(), menv_p1.clone())
    } else {
        {
            let (values_p10, wx1_p11) = crate::prelude::fold(&crate::check::errors::range0_f(&crate::prelude::len(methods_p4)), &(crate::prelude::Array::new(), wx_p0.clone()), &(|(acc_pa, w_pb): &(crate::prelude::Array<crate::lower::model::Ex>, crate::lower::node_::Wx), i_pc: &crate::prelude::Nat| match part_of_o(methods_p4, i_pc) {
                ::std::option::Option::Some(crate::lower::types::Bn::BnEv(r_pd, _)) => {
                    let et_pe = crate::lower::node_::gn_of_f(w_pb, &r_pd.node_p).ty_p.clone();
                    let (rs_pi, w1_pj) = crate::lower::node_::fresh_name_f(w_pb, &crate::prelude::Text::from(format!("{}_value{}", stem_p3, i_pc)));
                    let pf_pf = crate::prelude::Text::from(format!("{}_v_port", &rs_pi));
                    let pt_pg = crate::lower::model::OutTy::OutRc(::std::rc::Rc::new(crate::lower::model::OutTy::OutPort(::std::rc::Rc::new(et_pe.clone()))));
                    let w2_ph = {
                        let mut this: crate::lower::node_::Wx = crate::lower::node_::connect_f(&w1_pj, &r_pd, &crate::lower::node_::Sk::SkPort(crate::prelude::Text::from(format!("{}_v", &rs_pi))));
                        this.taken_p = crate::prelude::push(&this.taken_p, &pf_pf);
                        this.lets_p = crate::prelude::push(&this.lets_p, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaBind(pf_pf.clone())), pt_pg.clone()), crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Rc::new")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Port::new")), crate::prelude::Array::new())]))));
                        this.fields_p = crate::prelude::push(&this.fields_p, &(pf_pf.clone(), pt_pg.clone(), crate::prelude::Text::from(format!("part {} of the late bundle `{}` as a value: the port it fires", i_pc, nkey_p2))));
                        this.moves_p = crate::prelude::push(&this.moves_p, &(pf_pf.clone(), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(pf_pf.clone())))));
                        this
                    };
                    (crate::prelude::push(acc_pa, &crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("prism_rtl::Event::of")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), pf_pf.clone())))]))), w2_ph.clone())
                },
                ::std::option::Option::Some(crate::lower::types::Bn::BnDyn(ex_pk, reads_pl, dt_pm)) => {
                    let (made_pn, w1_po) = live_dynamic_f(w_pb, &crate::prelude::Text::from(format!("{}_value{}", stem_p3, i_pc)), &ex_pk, &reads_pl, &dt_pm, &crate::prelude::Text::from(format!("part {} of the late bundle `{}`", i_pc, nkey_p2)));
                    (crate::prelude::push(acc_pa, &in_node_f(&made_pn)), w1_po.clone())
                },
                ::std::option::Option::Some(crate::lower::types::Bn::BnHold(f_pp, dt_pq)) => {
                    let (made_pr, w1_ps) = live_dynamic_f(w_pb, &crate::prelude::Text::from(format!("{}_value{}", stem_p3, i_pc)), &crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), f_pp.clone())), crate::prelude::Text::lit("get"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx])), &crate::prelude::Array::from(vec![crate::lower::node_::Read::OwnRead(f_pp.clone())]), &dt_pq, &crate::prelude::Text::from(format!("part {} of the late bundle `{}`", i_pc, nkey_p2)));
                    (crate::prelude::push(acc_pa, &in_node_f(&made_pr)), w1_ps.clone())
                },
                ::std::option::Option::Some(crate::lower::types::Bn::BnLocal(ex_pt, mode_pu, pt_pv)) => (crate::prelude::push(acc_pa, &crate::lower::types::own_f(&crate::lower::types::Vl::VlPlace(ex_pt, mode_pu, pt_pv))), w_pb.clone()),
                _ => (acc_pa.clone(), w_pb.clone()),
            }));
            let (getter_p12, wx2_p13) = crate::lower::node_::fresh_name_f(&wx1_p11, &crate::prelude::Text::from(format!("late_{}_bundle", stem_p3)));
            let wx3_p9 = {
                let mut this: crate::lower::node_::Wx = wx2_p13.clone();
                this.getters_p = crate::prelude::push(&this.getters_p, &crate::lower::model::MethDef { name_p: getter_p12.clone(), recv_p: crate::lower::model::Recv::RecvRef, params_p: crate::prelude::Array::new(), cx_p: crate::lower::model::CxArg::CxNone, ret_p: t_p5.clone(), body_p: crate::prelude::Array::new(), tail_p: crate::lower::model::Ex::XTuple(values_p10.clone()), doc_p: crate::prelude::Text::from(format!("The late bundle `{}` as one value, read once the row that gives its late part is built.", nkey_p2)) });
                this
            };
            (wx3_p9.clone(), crate::lower::types::bind_f(menv_p1, &crate::prelude::Text::from(format!("{}#value", nkey_p2)), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), getter_p12.clone(), crate::prelude::Array::new()), crate::lower::types::Holding::Owned, t_p5.clone())))
        }
    }
}

/// The step machine of `LateBundleValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LateBundleValue: unbounded fn Wx, Env, Text, Text, [?Bn], OutTy -> ((Wx, Env))
/// ```
pub struct LateBundleValue {
    pub wx_p0: crate::lower::node_::Wx,
    pub menv_p1: crate::lower::types::Env,
    pub nkey_p2: crate::prelude::Text,
    pub stem_p3: crate::prelude::Text,
    pub methods_p4: crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>,
    pub t_p5: crate::lower::model::OutTy,
}

impl ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env)> for LateBundleValue {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::lower::node_::Wx, crate::lower::types::Env)> {
        let wx_p0 = &self.wx_p0;
        let menv_p1 = &self.menv_p1;
        let nkey_p2 = &self.nkey_p2;
        let stem_p3 = &self.stem_p3;
        let methods_p4 = &self.methods_p4;
        let t_p5 = &self.t_p5;
        let simple_p6 = (&crate::prelude::len(methods_p4) > &crate::prelude::Nat::from(0u32)) && crate::prelude::fold(methods_p4, &true, &(|ok_p7: &bool, part_o8: &::std::option::Option<crate::lower::types::Bn>| *ok_p7 && match part_o8 {
            ::std::option::Option::Some(crate::lower::types::Bn::BnEv(_, _)) => true,
            ::std::option::Option::Some(crate::lower::types::Bn::BnDyn(_, _, _)) => true,
            ::std::option::Option::Some(crate::lower::types::Bn::BnHold(_, _)) => true,
            ::std::option::Option::Some(crate::lower::types::Bn::BnLocal(_, _, _)) => true,
            _ => false,
        }));
        if !simple_p6 {
            ::prism_rtl::Turn::Finished((wx_p0.clone(), menv_p1.clone()))
        } else {
            {
                let (values_p10, wx1_p11) = crate::prelude::fold(&crate::check::errors::range0_f(&crate::prelude::len(methods_p4)), &(crate::prelude::Array::new(), wx_p0.clone()), &(|(acc_pa, w_pb): &(crate::prelude::Array<crate::lower::model::Ex>, crate::lower::node_::Wx), i_pc: &crate::prelude::Nat| match part_of_o(methods_p4, i_pc) {
                    ::std::option::Option::Some(crate::lower::types::Bn::BnEv(r_pd, _)) => {
                        let et_pe = crate::lower::node_::gn_of_f(w_pb, &r_pd.node_p).ty_p.clone();
                        let (rs_pi, w1_pj) = crate::lower::node_::fresh_name_f(w_pb, &crate::prelude::Text::from(format!("{}_value{}", stem_p3, i_pc)));
                        let pf_pf = crate::prelude::Text::from(format!("{}_v_port", &rs_pi));
                        let pt_pg = crate::lower::model::OutTy::OutRc(::std::rc::Rc::new(crate::lower::model::OutTy::OutPort(::std::rc::Rc::new(et_pe.clone()))));
                        let w2_ph = {
                            let mut this: crate::lower::node_::Wx = crate::lower::node_::connect_f(&w1_pj, &r_pd, &crate::lower::node_::Sk::SkPort(crate::prelude::Text::from(format!("{}_v", &rs_pi))));
                            this.taken_p = crate::prelude::push(&this.taken_p, &pf_pf);
                            this.lets_p = crate::prelude::push(&this.lets_p, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaBind(pf_pf.clone())), pt_pg.clone()), crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Rc::new")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Port::new")), crate::prelude::Array::new())]))));
                            this.fields_p = crate::prelude::push(&this.fields_p, &(pf_pf.clone(), pt_pg.clone(), crate::prelude::Text::from(format!("part {} of the late bundle `{}` as a value: the port it fires", i_pc, nkey_p2))));
                            this.moves_p = crate::prelude::push(&this.moves_p, &(pf_pf.clone(), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(pf_pf.clone())))));
                            this
                        };
                        (crate::prelude::push(acc_pa, &crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("prism_rtl::Event::of")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), pf_pf.clone())))]))), w2_ph.clone())
                    },
                    ::std::option::Option::Some(crate::lower::types::Bn::BnDyn(ex_pk, reads_pl, dt_pm)) => {
                        let (made_pn, w1_po) = live_dynamic_f(w_pb, &crate::prelude::Text::from(format!("{}_value{}", stem_p3, i_pc)), &ex_pk, &reads_pl, &dt_pm, &crate::prelude::Text::from(format!("part {} of the late bundle `{}`", i_pc, nkey_p2)));
                        (crate::prelude::push(acc_pa, &in_node_f(&made_pn)), w1_po.clone())
                    },
                    ::std::option::Option::Some(crate::lower::types::Bn::BnHold(f_pp, dt_pq)) => {
                        let (made_pr, w1_ps) = live_dynamic_f(w_pb, &crate::prelude::Text::from(format!("{}_value{}", stem_p3, i_pc)), &crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), f_pp.clone())), crate::prelude::Text::lit("get"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx])), &crate::prelude::Array::from(vec![crate::lower::node_::Read::OwnRead(f_pp.clone())]), &dt_pq, &crate::prelude::Text::from(format!("part {} of the late bundle `{}`", i_pc, nkey_p2)));
                        (crate::prelude::push(acc_pa, &in_node_f(&made_pr)), w1_ps.clone())
                    },
                    ::std::option::Option::Some(crate::lower::types::Bn::BnLocal(ex_pt, mode_pu, pt_pv)) => (crate::prelude::push(acc_pa, &crate::lower::types::own_f(&crate::lower::types::Vl::VlPlace(ex_pt, mode_pu, pt_pv))), w_pb.clone()),
                    _ => (acc_pa.clone(), w_pb.clone()),
                }));
                let (getter_p12, wx2_p13) = crate::lower::node_::fresh_name_f(&wx1_p11, &crate::prelude::Text::from(format!("late_{}_bundle", stem_p3)));
                let wx3_p9 = {
                    let mut this: crate::lower::node_::Wx = wx2_p13.clone();
                    this.getters_p = crate::prelude::push(&this.getters_p, &crate::lower::model::MethDef { name_p: getter_p12.clone(), recv_p: crate::lower::model::Recv::RecvRef, params_p: crate::prelude::Array::new(), cx_p: crate::lower::model::CxArg::CxNone, ret_p: t_p5.clone(), body_p: crate::prelude::Array::new(), tail_p: crate::lower::model::Ex::XTuple(values_p10.clone()), doc_p: crate::prelude::Text::from(format!("The late bundle `{}` as one value, read once the row that gives its late part is built.", nkey_p2)) });
                    this
                };
                ::prism_rtl::Turn::Finished((wx3_p9.clone(), crate::lower::types::bind_f(menv_p1, &crate::prelude::Text::from(format!("{}#value", nkey_p2)), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), getter_p12.clone(), crate::prelude::Array::new()), crate::lower::types::Holding::Owned, t_p5.clone()))))
            }
        }
    }
}

/// `Start LateBundleValue, x`: what the function value is when passed to `@Run`.
pub fn start_late_bundle_value_f(wx_p0: crate::lower::node_::Wx, menv_p1: crate::lower::types::Env, nkey_p2: crate::prelude::Text, stem_p3: crate::prelude::Text, methods_p4: crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>, t_p5: crate::lower::model::OutTy) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env)>> {
    ::std::rc::Rc::new(LateBundleValue { wx_p0, menv_p1, nkey_p2, stem_p3, methods_p4, t_p5 })
}

/// ```prism
/// InNode: fn Ex -> Ex
/// ```
pub fn in_node_f(ex_p0: &crate::lower::model::Ex) -> crate::lower::model::Ex {
    'm46259: {
        if let crate::lower::model::Ex::XClone(m46259_0_0) = ex_p0 && let crate::lower::model::Ex::XVar(name_p1) = &**m46259_0_0 {
            break 'm46259 crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), name_p1.clone())));
        }
        if let other_p2 = ex_p0 {
            break 'm46259 other_p2.clone();
        }
        unreachable!("no clause matched")
    }
}

/// ```prism
/// PreBindWholeParts: unbounded fn Wx, Text, Text, [Ty] -> ((Wx, [?Bn], [?Bn]))
/// ```
pub fn pre_bind_whole_parts_f(wx_p0: &crate::lower::node_::Wx, nkey_p1: &crate::prelude::Text, stem_p2: &crate::prelude::Text, tys_p3: &crate::prelude::Array<crate::check::types::Ty>) -> (crate::lower::node_::Wx, crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>, crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>) {
    crate::prelude::run_to_end(crate::prelude::fold_job(tys_p3.clone(), (wx_p0.clone(), crate::prelude::Array::new(), crate::prelude::Array::new()), {
        let nkey_p1x = nkey_p1.clone();
        let stem_p2x = stem_p2.clone();
        ::std::rc::Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>, crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>), crate::check::types::Ty)| {
            let nkey_p1xy = nkey_p1x.clone();
            let stem_p2xy = stem_p2x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (w_p4, builds_p5, methods_p6) = p0;
                let ty_p7 = p1;
                {
                    let lx_p8 = w_p4.lx_p.clone();
                    let i_p9 = crate::prelude::len(&builds_p5);
                    crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p8.clone(), crate::lower::types::peel_f(&ty_p7)), move |out_ty_of_f_46572: crate::lower::model::OutTy| {
                        let t_pa = out_ty_of_f_46572;
                        if crate::lower::types::is_bundle_f(&ty_p7) {
                            crate::prelude::call_then(start_pre_bind_whole_parts_f(w_p4.clone(), nkey_p1xy.clone(), crate::prelude::Text::from(format!("{}_{}", &stem_p2xy, &i_p9)), crate::lower::node_::keyed::bundle_part_tys_f(&ty_p7)), move |pre_bind_whole_parts_f_46643: (crate::lower::node_::Wx, crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>, crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>)| {
                                let (w2_pb, bs_pc, ms_pd) = pre_bind_whole_parts_f_46643;
                                ::prism_rtl::Turn::Finished((w2_pb.clone(), crate::prelude::append(&builds_p5, &crate::prelude::Array::from(vec![::std::option::Option::Some(crate::lower::types::Bn::BnParts(bs_pc.clone()))])), crate::prelude::append(&methods_p6, &crate::prelude::Array::from(vec![::std::option::Option::Some(crate::lower::types::Bn::BnParts(ms_pd.clone()))]))))
                            })
                        } else {
                            match crate::lower::types::layer_of_f(&ty_p7) {
                                crate::lower::types::Layer::LyEv => {
                                    let (rs_pf, w1_pg) = crate::lower::node_::fresh_name_f(&w_p4, &crate::prelude::Text::from(format!("{}_part{}", &stem_p2xy, &i_p9)));
                                    crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p8.clone(), crate::lower::types::peel_f(&crate::lower::types::peel_f(&ty_p7))), move |out_ty_of_f_46942: crate::lower::model::OutTy| {
                                        let (id_ph, w2_pi) = crate::lower::node_::add_gn_f(&w1_pg, &rs_pf, &out_ty_of_f_46942, &crate::lower::node_::GnKind::GnNamed, &crate::prelude::Nat::from(0u32));
                                        let b_pe = crate::lower::types::Bn::BnEv(crate::lower::node_::ev_ref_of_f(&w2_pi, &id_ph), t_pa.clone());
                                        ::prism_rtl::Turn::Finished((w2_pi.clone(), crate::prelude::append(&builds_p5, &crate::prelude::Array::from(vec![::std::option::Option::Some(b_pe.clone())])), crate::prelude::append(&methods_p6, &crate::prelude::Array::from(vec![::std::option::Option::Some(b_pe.clone())]))))
                                    })
                                },
                                crate::lower::types::Layer::LyDyn => {
                                    let (rs_pk, w1_pl) = crate::lower::node_::fresh_name_f(&w_p4, &crate::prelude::Text::from(format!("{}_part{}", &stem_p2xy, &i_p9)));
                                    let b_pj = crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), rs_pk.clone(), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx])), crate::prelude::Array::from(vec![crate::lower::node_::Read::OwnRead(rs_pk.clone())]), t_pa.clone());
                                    ::prism_rtl::Turn::Finished((w1_pl.clone(), crate::prelude::append(&builds_p5, &crate::prelude::Array::from(vec![::std::option::Option::Some(b_pj.clone())])), crate::prelude::append(&methods_p6, &crate::prelude::Array::from(vec![::std::option::Option::Some(b_pj.clone())]))))
                                },
                                _ => {
                                    let (getter_pn, w1_po) = crate::lower::node_::fresh_name_f(&w_p4, &crate::prelude::Text::from(format!("late_{}_p{}", &stem_p2xy, &i_p9)));
                                    let unbuilt_pm = crate::lower::types::Bn::BnLocal(crate::lower::expr::refusal_f(&crate::prelude::Text::from(format!("a late plain part of the bundle `{}` read at its block\'s build by a line of the block\'s node", &nkey_p1xy))), crate::lower::types::Holding::Owned, t_pa.clone());
                                    ::prism_rtl::Turn::Finished((w1_po.clone(), crate::prelude::append(&builds_p5, &crate::prelude::Array::from(vec![::std::option::Option::Some(unbuilt_pm.clone())])), crate::prelude::append(&methods_p6, &crate::prelude::Array::from(vec![::std::option::Option::Some(crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), getter_pn.clone(), crate::prelude::Array::new()), crate::lower::types::Holding::Owned, t_pa.clone()))]))))
                                },
                            }
                        }
                    })
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::lower::node_::Wx, crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>, crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>), crate::check::types::Ty)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>, crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>)>>>
    }))
}

/// The step machine of `PreBindWholeParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PreBindWholeParts: unbounded fn Wx, Text, Text, [Ty] -> ((Wx, [?Bn], [?Bn]))
/// ```
pub struct PreBindWholeParts {
    pub wx_p0: crate::lower::node_::Wx,
    pub nkey_p1: crate::prelude::Text,
    pub stem_p2: crate::prelude::Text,
    pub tys_p3: crate::prelude::Array<crate::check::types::Ty>,
}

impl ::prism_rtl::Job<(crate::lower::node_::Wx, crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>, crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>)> for PreBindWholeParts {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::lower::node_::Wx, crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>, crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>)> {
        let wx_p0 = &self.wx_p0;
        let nkey_p1 = &self.nkey_p1;
        let stem_p2 = &self.stem_p2;
        let tys_p3 = &self.tys_p3;
        crate::prelude::fold_job(tys_p3.clone(), (wx_p0.clone(), crate::prelude::Array::new(), crate::prelude::Array::new()), {
            let nkey_p1x = nkey_p1.clone();
            let stem_p2x = stem_p2.clone();
            ::std::rc::Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>, crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>), crate::check::types::Ty)| {
                let nkey_p1xy = nkey_p1x.clone();
                let stem_p2xy = stem_p2x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let (w_p4, builds_p5, methods_p6) = p0;
                    let ty_p7 = p1;
                    {
                        let lx_p8 = w_p4.lx_p.clone();
                        let i_p9 = crate::prelude::len(&builds_p5);
                        crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p8.clone(), crate::lower::types::peel_f(&ty_p7)), move |out_ty_of_f_46572: crate::lower::model::OutTy| {
                            let t_pa = out_ty_of_f_46572;
                            if crate::lower::types::is_bundle_f(&ty_p7) {
                                crate::prelude::call_then(start_pre_bind_whole_parts_f(w_p4.clone(), nkey_p1xy.clone(), crate::prelude::Text::from(format!("{}_{}", &stem_p2xy, &i_p9)), crate::lower::node_::keyed::bundle_part_tys_f(&ty_p7)), move |pre_bind_whole_parts_f_46643: (crate::lower::node_::Wx, crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>, crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>)| {
                                    let (w2_pb, bs_pc, ms_pd) = pre_bind_whole_parts_f_46643;
                                    ::prism_rtl::Turn::Finished((w2_pb.clone(), crate::prelude::append(&builds_p5, &crate::prelude::Array::from(vec![::std::option::Option::Some(crate::lower::types::Bn::BnParts(bs_pc.clone()))])), crate::prelude::append(&methods_p6, &crate::prelude::Array::from(vec![::std::option::Option::Some(crate::lower::types::Bn::BnParts(ms_pd.clone()))]))))
                                })
                            } else {
                                match crate::lower::types::layer_of_f(&ty_p7) {
                                    crate::lower::types::Layer::LyEv => {
                                        let (rs_pf, w1_pg) = crate::lower::node_::fresh_name_f(&w_p4, &crate::prelude::Text::from(format!("{}_part{}", &stem_p2xy, &i_p9)));
                                        crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p8.clone(), crate::lower::types::peel_f(&crate::lower::types::peel_f(&ty_p7))), move |out_ty_of_f_46942: crate::lower::model::OutTy| {
                                            let (id_ph, w2_pi) = crate::lower::node_::add_gn_f(&w1_pg, &rs_pf, &out_ty_of_f_46942, &crate::lower::node_::GnKind::GnNamed, &crate::prelude::Nat::from(0u32));
                                            let b_pe = crate::lower::types::Bn::BnEv(crate::lower::node_::ev_ref_of_f(&w2_pi, &id_ph), t_pa.clone());
                                            ::prism_rtl::Turn::Finished((w2_pi.clone(), crate::prelude::append(&builds_p5, &crate::prelude::Array::from(vec![::std::option::Option::Some(b_pe.clone())])), crate::prelude::append(&methods_p6, &crate::prelude::Array::from(vec![::std::option::Option::Some(b_pe.clone())]))))
                                        })
                                    },
                                    crate::lower::types::Layer::LyDyn => {
                                        let (rs_pk, w1_pl) = crate::lower::node_::fresh_name_f(&w_p4, &crate::prelude::Text::from(format!("{}_part{}", &stem_p2xy, &i_p9)));
                                        let b_pj = crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), rs_pk.clone(), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx])), crate::prelude::Array::from(vec![crate::lower::node_::Read::OwnRead(rs_pk.clone())]), t_pa.clone());
                                        ::prism_rtl::Turn::Finished((w1_pl.clone(), crate::prelude::append(&builds_p5, &crate::prelude::Array::from(vec![::std::option::Option::Some(b_pj.clone())])), crate::prelude::append(&methods_p6, &crate::prelude::Array::from(vec![::std::option::Option::Some(b_pj.clone())]))))
                                    },
                                    _ => {
                                        let (getter_pn, w1_po) = crate::lower::node_::fresh_name_f(&w_p4, &crate::prelude::Text::from(format!("late_{}_p{}", &stem_p2xy, &i_p9)));
                                        let unbuilt_pm = crate::lower::types::Bn::BnLocal(crate::lower::expr::refusal_f(&crate::prelude::Text::from(format!("a late plain part of the bundle `{}` read at its block\'s build by a line of the block\'s node", &nkey_p1xy))), crate::lower::types::Holding::Owned, t_pa.clone());
                                        ::prism_rtl::Turn::Finished((w1_po.clone(), crate::prelude::append(&builds_p5, &crate::prelude::Array::from(vec![::std::option::Option::Some(unbuilt_pm.clone())])), crate::prelude::append(&methods_p6, &crate::prelude::Array::from(vec![::std::option::Option::Some(crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), getter_pn.clone(), crate::prelude::Array::new()), crate::lower::types::Holding::Owned, t_pa.clone()))]))))
                                    },
                                }
                            }
                        })
                    }
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::lower::node_::Wx, crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>, crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>), crate::check::types::Ty)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>, crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>)>>>
        }).cycle()
    }
}

/// `Start PreBindWholeParts, x`: what the function value is when passed to `@Run`.
pub fn start_pre_bind_whole_parts_f(wx_p0: crate::lower::node_::Wx, nkey_p1: crate::prelude::Text, stem_p2: crate::prelude::Text, tys_p3: crate::prelude::Array<crate::check::types::Ty>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>, crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>)>> {
    ::std::rc::Rc::new(PreBindWholeParts { wx_p0, nkey_p1, stem_p2, tys_p3 })
}

/// ```prism
/// BindWhole: unbounded fn Wx, Env, Env, SName, [Wres], [((Nat, Ex))] -> ((Wx, Env, Env))
/// ```
pub fn bind_whole_f(wx_p0: &crate::lower::node_::Wx, benv_p1: &crate::lower::types::Env, menv_p2: &crate::lower::types::Env, n_p3: &crate::syntax::SName, parts_p4: &crate::prelude::Array<crate::lower::node_::Wres>, part_reads_p5: &crate::prelude::Array<(crate::prelude::Nat, crate::lower::model::Ex)>) -> (crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env) {
    match crate::prelude::get(&menv_p2.names_p, &crate::check::env::sname_key_f(n_p3)) {
        ::std::option::Option::Some(crate::lower::types::Bn::BnParts(pre_p6)) => (bind_whole_parts_f(wx_p0, &crate::check::env::sname_key_f(n_p3), &pre_p6, parts_p4, &::std::option::Option::Some(part_reads_p5.clone())), benv_p1.clone(), menv_p2.clone()),
        _ => ({
            let mut this: crate::lower::node_::Wx = wx_p0.clone();
            this.build_p = crate::prelude::push(&this.build_p, &crate::lower::expr::internal_bug_do_f(&crate::prelude::Text::from(format!("the bundle `{}` bound whole where its block is split, whose name was not bound before its lines", &crate::check::env::sname_key_f(n_p3)))));
            this
        }, benv_p1.clone(), menv_p2.clone()),
    }
}

/// The step machine of `BindWhole`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BindWhole: unbounded fn Wx, Env, Env, SName, [Wres], [((Nat, Ex))] -> ((Wx, Env, Env))
/// ```
pub struct BindWhole {
    pub wx_p0: crate::lower::node_::Wx,
    pub benv_p1: crate::lower::types::Env,
    pub menv_p2: crate::lower::types::Env,
    pub n_p3: crate::syntax::SName,
    pub parts_p4: crate::prelude::Array<crate::lower::node_::Wres>,
    pub part_reads_p5: crate::prelude::Array<(crate::prelude::Nat, crate::lower::model::Ex)>,
}

impl ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)> for BindWhole {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)> {
        let wx_p0 = &self.wx_p0;
        let benv_p1 = &self.benv_p1;
        let menv_p2 = &self.menv_p2;
        let n_p3 = &self.n_p3;
        let parts_p4 = &self.parts_p4;
        let part_reads_p5 = &self.part_reads_p5;
        match crate::prelude::get(&menv_p2.names_p, &crate::check::env::sname_key_f(n_p3)) {
            ::std::option::Option::Some(crate::lower::types::Bn::BnParts(pre_p6)) => {
                let benv_p1x = benv_p1.clone();
                let menv_p2x = menv_p2.clone();
                let n_p3x = n_p3.clone();
                let part_reads_p5x = part_reads_p5.clone();
                let parts_p4x = parts_p4.clone();
                let wx_p0x = wx_p0.clone();
                crate::prelude::call_then(start_bind_whole_parts_f(wx_p0x.clone(), crate::check::env::sname_key_f(&n_p3x), pre_p6.clone(), parts_p4x.clone(), ::std::option::Option::Some(part_reads_p5x.clone())), move |bind_whole_parts_f_48286: crate::lower::node_::Wx| ::prism_rtl::Turn::Finished((bind_whole_parts_f_48286, benv_p1x.clone(), menv_p2x.clone())))
            },
            _ => ::prism_rtl::Turn::Finished(({
                let mut this: crate::lower::node_::Wx = wx_p0.clone();
                this.build_p = crate::prelude::push(&this.build_p, &crate::lower::expr::internal_bug_do_f(&crate::prelude::Text::from(format!("the bundle `{}` bound whole where its block is split, whose name was not bound before its lines", &crate::check::env::sname_key_f(n_p3)))));
                this
            }, benv_p1.clone(), menv_p2.clone())),
        }
    }
}

/// `Start BindWhole, x`: what the function value is when passed to `@Run`.
pub fn start_bind_whole_f(wx_p0: crate::lower::node_::Wx, benv_p1: crate::lower::types::Env, menv_p2: crate::lower::types::Env, n_p3: crate::syntax::SName, parts_p4: crate::prelude::Array<crate::lower::node_::Wres>, part_reads_p5: crate::prelude::Array<(crate::prelude::Nat, crate::lower::model::Ex)>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>> {
    ::std::rc::Rc::new(BindWhole { wx_p0, benv_p1, menv_p2, n_p3, parts_p4, part_reads_p5 })
}

/// ```prism
/// BindWholeParts: unbounded fn Wx, Text, [?Bn], [Wres], ?[((Nat, Ex))] -> Wx
/// ```
pub fn bind_whole_parts_f(wx_p0: &crate::lower::node_::Wx, nkey_p1: &crate::prelude::Text, pre_p2: &crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>, parts_p3: &crate::prelude::Array<crate::lower::node_::Wres>, reads_o4: &::std::option::Option<crate::prelude::Array<(crate::prelude::Nat, crate::lower::model::Ex)>>) -> crate::lower::node_::Wx {
    crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(parts_p3)), wx_p0.clone(), {
        let pre_p2x = pre_p2.clone();
        let parts_p3x = parts_p3.clone();
        let nkey_p1x = nkey_p1.clone();
        let reads_o4x = reads_o4.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::lower::node_::Wx, crate::prelude::Nat)| {
            let pre_p2xy = pre_p2x.clone();
            let parts_p3xy = parts_p3x.clone();
            let nkey_p1xy = nkey_p1x.clone();
            let reads_o4xy = reads_o4x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let w_p5 = p0;
                let i_p6 = p1;
                'm48727: {
                    let scrutinee = &(part_of_o(&pre_p2xy, &i_p6), crate::prelude::or(&crate::prelude::index(&parts_p3xy, &i_p6), &crate::lower::node_::Wres::WrUnit));
                    if let (::std::option::Option::Some(crate::lower::types::Bn::BnEv(er_p7, _)), crate::lower::node_::Wres::WrEv(r_p8)) = scrutinee {
                        break 'm48727 if &er_p7.owner_p != &w_p5.node_p {
                            ::prism_rtl::Turn::Finished(crate::lower::node_::crossed_f(&w_p5, &crate::prelude::Text::from(format!("the bound event of node `{}` (its graph node {})", &er_p7.owner_p, &er_p7.node_p))))
                        } else {
                            if &r_p8.node_p == &er_p7.node_p {
                                ::prism_rtl::Turn::Finished(w_p5.clone())
                            } else {
                                ::prism_rtl::Turn::Finished(crate::lower::node_::connect_f(&w_p5, r_p8, &crate::lower::node_::Sk::SkNode(er_p7.node_p.clone())))
                            }
                        };
                    }
                    if let (::std::option::Option::Some(crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(m48727_1_0_0_0, rs_p9, _), _, _)), crate::lower::node_::Wres::WrDyn(ex_pa, rds_pb, t_pc)) = scrutinee && let crate::lower::model::Ex::XSelf = &**m48727_1_0_0_0 {
                        break 'm48727 ::prism_rtl::Turn::Finished({
                            let mut this: crate::lower::node_::Wx = w_p5.clone();
                            this.getters_p = crate::prelude::push(&this.getters_p, &crate::lower::model::MethDef { name_p: rs_p9.clone(), recv_p: crate::lower::model::Recv::RecvRef, params_p: crate::prelude::Array::new(), cx_p: crate::lower::model::CxArg::CxRef, ret_p: t_pc.clone(), body_p: crate::prelude::Array::new(), tail_p: ex_pa.clone(), doc_p: crate::prelude::Text::from(format!("A dynamic part of the bundle `{}`.", &nkey_p1xy)) });
                            this.dyn_reads_p = crate::prelude::insert(&this.dyn_reads_p, rs_p9, rds_pb);
                            this
                        });
                    }
                    if let (::std::option::Option::Some(crate::lower::types::Bn::BnParts(inner_pd)), crate::lower::node_::Wres::WrParts(ps_pe)) = scrutinee {
                        break 'm48727 ::prism_rtl::Turn::More(::std::rc::Rc::new(BindWholeParts { wx_p0: w_p5.clone(), nkey_p1: nkey_p1xy.clone(), pre_p2: inner_pd.clone(), parts_p3: ps_pe.clone(), reads_o4: ::std::option::Option::None }));
                    }
                    if let (::std::option::Option::Some(crate::lower::types::Bn::BnParts(inner_pf)), crate::lower::node_::Wres::WrHosted(m48727_3_1_0, _)) = scrutinee && let crate::lower::node_::Wres::WrParts(ps_pg) = &**m48727_3_1_0 {
                        break 'm48727 ::prism_rtl::Turn::More(::std::rc::Rc::new(BindWholeParts { wx_p0: w_p5.clone(), nkey_p1: nkey_p1xy.clone(), pre_p2: inner_pf.clone(), parts_p3: ps_pg.clone(), reads_o4: ::std::option::Option::None }));
                    }
                    if let (::std::option::Option::Some(crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XMethod(m48727_4_0_0_0, getter_ph, _), _, t_pi)), part_pj) = scrutinee && let crate::lower::model::Ex::XSelf = &**m48727_4_0_0_0 {
                        break 'm48727 {
                            let top_ok = match &reads_o4xy {
                                ::std::option::Option::Some(part_reads_pl) => part_read_o(part_reads_pl, &i_p6),
                                ::std::option::Option::None => ::std::option::Option::None,
                            };
                            let (read_os, w1_pt) = match (top_ok.clone(), part_pj.clone()) {
                                (::std::option::Option::Some(read_pm), _) => (::std::option::Option::Some(read_pm), w_p5.clone()),
                                (::std::option::Option::None, crate::lower::node_::Wres::WrLate(read_pn, _)) => (::std::option::Option::Some(read_pn), w_p5.clone()),
                                (::std::option::Option::None, crate::lower::node_::Wres::WrPlain(ex_po, pt_pp)) => {
                                    let (kept_pq, w2_pr) = kept_part_f(&crate::prelude::Array::new(), &w_p5, &ex_po, &pt_pp, &crate::prelude::Text::from(format!("a plain part of the bundle `{}`", &nkey_p1xy)));
                                    (crate::prelude::index(&kept_pq, &crate::prelude::Nat::from(0u32)), w2_pr.clone())
                                },
                                _ => (::std::option::Option::None, w_p5.clone()),
                            };
                            match &read_os {
                                ::std::option::Option::Some(read_pu) => ::prism_rtl::Turn::Finished({
                                    let mut this: crate::lower::node_::Wx = w1_pt.clone();
                                    this.getters_p = crate::prelude::push(&this.getters_p, &crate::lower::model::MethDef { name_p: getter_ph.clone(), recv_p: crate::lower::model::Recv::RecvRef, params_p: crate::prelude::Array::new(), cx_p: crate::lower::model::CxArg::CxNone, ret_p: t_pi.clone(), body_p: crate::prelude::Array::new(), tail_p: read_pu.clone(), doc_p: crate::prelude::Text::from(format!("A late plain part of the bundle `{}`, read once the row that gives it is built.", &nkey_p1xy)) });
                                    this
                                }),
                                ::std::option::Option::None => ::prism_rtl::Turn::Finished({
                                    let mut this: crate::lower::node_::Wx = w1_pt.clone();
                                    this.build_p = crate::prelude::push(&this.build_p, &crate::lower::expr::internal_bug_do_f(&crate::prelude::Text::from(format!("part {} of the bundle `{}`, bound as a plain value, which its line gives as none", &i_p6, &nkey_p1xy))));
                                    this
                                }),
                            }
                        };
                    }
                    ::prism_rtl::Turn::Finished({
                        let mut this: crate::lower::node_::Wx = w_p5.clone();
                        this.build_p = crate::prelude::push(&this.build_p, &crate::lower::expr::internal_bug_do_f(&crate::prelude::Text::from(format!("part {} of the bundle `{}`, which its line gives as another kind than its type", &i_p6, &nkey_p1xy))));
                        this
                    })
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::node_::Wx, crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::node_::Wx>>>
    }))
}

/// The step machine of `BindWholeParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BindWholeParts: unbounded fn Wx, Text, [?Bn], [Wres], ?[((Nat, Ex))] -> Wx
/// ```
pub struct BindWholeParts {
    pub wx_p0: crate::lower::node_::Wx,
    pub nkey_p1: crate::prelude::Text,
    pub pre_p2: crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>,
    pub parts_p3: crate::prelude::Array<crate::lower::node_::Wres>,
    pub reads_o4: ::std::option::Option<crate::prelude::Array<(crate::prelude::Nat, crate::lower::model::Ex)>>,
}

impl ::prism_rtl::Job<crate::lower::node_::Wx> for BindWholeParts {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::lower::node_::Wx> {
        let wx_p0 = &self.wx_p0;
        let nkey_p1 = &self.nkey_p1;
        let pre_p2 = &self.pre_p2;
        let parts_p3 = &self.parts_p3;
        let reads_o4 = &self.reads_o4;
        crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(parts_p3)), wx_p0.clone(), {
            let pre_p2x = pre_p2.clone();
            let parts_p3x = parts_p3.clone();
            let nkey_p1x = nkey_p1.clone();
            let reads_o4x = reads_o4.clone();
            ::std::rc::Rc::new(move |(p0, p1): (crate::lower::node_::Wx, crate::prelude::Nat)| {
                let pre_p2xy = pre_p2x.clone();
                let parts_p3xy = parts_p3x.clone();
                let nkey_p1xy = nkey_p1x.clone();
                let reads_o4xy = reads_o4x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let w_p5 = p0;
                    let i_p6 = p1;
                    'm48727: {
                        let scrutinee = &(part_of_o(&pre_p2xy, &i_p6), crate::prelude::or(&crate::prelude::index(&parts_p3xy, &i_p6), &crate::lower::node_::Wres::WrUnit));
                        if let (::std::option::Option::Some(crate::lower::types::Bn::BnEv(er_p7, _)), crate::lower::node_::Wres::WrEv(r_p8)) = scrutinee {
                            break 'm48727 if &er_p7.owner_p != &w_p5.node_p {
                                ::prism_rtl::Turn::Finished(crate::lower::node_::crossed_f(&w_p5, &crate::prelude::Text::from(format!("the bound event of node `{}` (its graph node {})", &er_p7.owner_p, &er_p7.node_p))))
                            } else {
                                if &r_p8.node_p == &er_p7.node_p {
                                    ::prism_rtl::Turn::Finished(w_p5.clone())
                                } else {
                                    ::prism_rtl::Turn::Finished(crate::lower::node_::connect_f(&w_p5, r_p8, &crate::lower::node_::Sk::SkNode(er_p7.node_p.clone())))
                                }
                            };
                        }
                        if let (::std::option::Option::Some(crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(m48727_1_0_0_0, rs_p9, _), _, _)), crate::lower::node_::Wres::WrDyn(ex_pa, rds_pb, t_pc)) = scrutinee && let crate::lower::model::Ex::XSelf = &**m48727_1_0_0_0 {
                            break 'm48727 ::prism_rtl::Turn::Finished({
                                let mut this: crate::lower::node_::Wx = w_p5.clone();
                                this.getters_p = crate::prelude::push(&this.getters_p, &crate::lower::model::MethDef { name_p: rs_p9.clone(), recv_p: crate::lower::model::Recv::RecvRef, params_p: crate::prelude::Array::new(), cx_p: crate::lower::model::CxArg::CxRef, ret_p: t_pc.clone(), body_p: crate::prelude::Array::new(), tail_p: ex_pa.clone(), doc_p: crate::prelude::Text::from(format!("A dynamic part of the bundle `{}`.", &nkey_p1xy)) });
                                this.dyn_reads_p = crate::prelude::insert(&this.dyn_reads_p, rs_p9, rds_pb);
                                this
                            });
                        }
                        if let (::std::option::Option::Some(crate::lower::types::Bn::BnParts(inner_pd)), crate::lower::node_::Wres::WrParts(ps_pe)) = scrutinee {
                            break 'm48727 ::prism_rtl::Turn::More(::std::rc::Rc::new(BindWholeParts { wx_p0: w_p5.clone(), nkey_p1: nkey_p1xy.clone(), pre_p2: inner_pd.clone(), parts_p3: ps_pe.clone(), reads_o4: ::std::option::Option::None }));
                        }
                        if let (::std::option::Option::Some(crate::lower::types::Bn::BnParts(inner_pf)), crate::lower::node_::Wres::WrHosted(m48727_3_1_0, _)) = scrutinee && let crate::lower::node_::Wres::WrParts(ps_pg) = &**m48727_3_1_0 {
                            break 'm48727 ::prism_rtl::Turn::More(::std::rc::Rc::new(BindWholeParts { wx_p0: w_p5.clone(), nkey_p1: nkey_p1xy.clone(), pre_p2: inner_pf.clone(), parts_p3: ps_pg.clone(), reads_o4: ::std::option::Option::None }));
                        }
                        if let (::std::option::Option::Some(crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XMethod(m48727_4_0_0_0, getter_ph, _), _, t_pi)), part_pj) = scrutinee && let crate::lower::model::Ex::XSelf = &**m48727_4_0_0_0 {
                            break 'm48727 {
                                let top_ok = match &reads_o4xy {
                                    ::std::option::Option::Some(part_reads_pl) => part_read_o(part_reads_pl, &i_p6),
                                    ::std::option::Option::None => ::std::option::Option::None,
                                };
                                let (read_os, w1_pt) = match (top_ok.clone(), part_pj.clone()) {
                                    (::std::option::Option::Some(read_pm), _) => (::std::option::Option::Some(read_pm), w_p5.clone()),
                                    (::std::option::Option::None, crate::lower::node_::Wres::WrLate(read_pn, _)) => (::std::option::Option::Some(read_pn), w_p5.clone()),
                                    (::std::option::Option::None, crate::lower::node_::Wres::WrPlain(ex_po, pt_pp)) => {
                                        let (kept_pq, w2_pr) = kept_part_f(&crate::prelude::Array::new(), &w_p5, &ex_po, &pt_pp, &crate::prelude::Text::from(format!("a plain part of the bundle `{}`", &nkey_p1xy)));
                                        (crate::prelude::index(&kept_pq, &crate::prelude::Nat::from(0u32)), w2_pr.clone())
                                    },
                                    _ => (::std::option::Option::None, w_p5.clone()),
                                };
                                match &read_os {
                                    ::std::option::Option::Some(read_pu) => ::prism_rtl::Turn::Finished({
                                        let mut this: crate::lower::node_::Wx = w1_pt.clone();
                                        this.getters_p = crate::prelude::push(&this.getters_p, &crate::lower::model::MethDef { name_p: getter_ph.clone(), recv_p: crate::lower::model::Recv::RecvRef, params_p: crate::prelude::Array::new(), cx_p: crate::lower::model::CxArg::CxNone, ret_p: t_pi.clone(), body_p: crate::prelude::Array::new(), tail_p: read_pu.clone(), doc_p: crate::prelude::Text::from(format!("A late plain part of the bundle `{}`, read once the row that gives it is built.", &nkey_p1xy)) });
                                        this
                                    }),
                                    ::std::option::Option::None => ::prism_rtl::Turn::Finished({
                                        let mut this: crate::lower::node_::Wx = w1_pt.clone();
                                        this.build_p = crate::prelude::push(&this.build_p, &crate::lower::expr::internal_bug_do_f(&crate::prelude::Text::from(format!("part {} of the bundle `{}`, bound as a plain value, which its line gives as none", &i_p6, &nkey_p1xy))));
                                        this
                                    }),
                                }
                            };
                        }
                        ::prism_rtl::Turn::Finished({
                            let mut this: crate::lower::node_::Wx = w_p5.clone();
                            this.build_p = crate::prelude::push(&this.build_p, &crate::lower::expr::internal_bug_do_f(&crate::prelude::Text::from(format!("part {} of the bundle `{}`, which its line gives as another kind than its type", &i_p6, &nkey_p1xy))));
                            this
                        })
                    }
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::node_::Wx, crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::node_::Wx>>>
        }).cycle()
    }
}

/// `Start BindWholeParts, x`: what the function value is when passed to `@Run`.
pub fn start_bind_whole_parts_f(wx_p0: crate::lower::node_::Wx, nkey_p1: crate::prelude::Text, pre_p2: crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>, parts_p3: crate::prelude::Array<crate::lower::node_::Wres>, reads_o4: ::std::option::Option<crate::prelude::Array<(crate::prelude::Nat, crate::lower::model::Ex)>>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::node_::Wx>> {
    ::std::rc::Rc::new(BindWholeParts { wx_p0, nkey_p1, pre_p2, parts_p3, reads_o4 })
}

/// ```prism
/// IsTimeName: fn Text -> Bool
/// ```
pub fn is_time_name_f(n_p0: &crate::prelude::Text) -> bool {
    crate::syntax::lexer::chars::has_prefix_f(n_p0, &crate::prelude::Text::lit("$")) || crate::syntax::lexer::chars::has_prefix_f(n_p0, &crate::prelude::Text::lit("!"))
}

/// ```prism
/// IsTimePart: fn Wres -> Bool
/// ```
pub fn is_time_part_f(part_p0: &crate::lower::node_::Wres) -> bool {
    match part_p0 {
        crate::lower::node_::Wres::WrEv(_) => true,
        crate::lower::node_::Wres::WrDyn(_, _, _) => true,
        crate::lower::node_::Wres::WrParts(_) => true,
        crate::lower::node_::Wres::WrHosted(_, _) => true,
        _ => false,
    }
}

/// ```prism
/// LateParts: fn Wx, Wres -> ((Wx, [((Nat, Ex))]))
/// ```
pub fn late_parts_f(wx_p0: &crate::lower::node_::Wx, late_p1: &crate::lower::node_::Wres) -> (crate::lower::node_::Wx, crate::prelude::Array<(crate::prelude::Nat, crate::lower::model::Ex)>) {
    match late_p1 {
        crate::lower::node_::Wres::WrParts(parts_p2) => crate::prelude::fold(&crate::check::errors::range0_f(&crate::prelude::len(parts_p2)), &(wx_p0.clone(), crate::prelude::Array::new()), &(|(w_p3, acc_p4): &(crate::lower::node_::Wx, crate::prelude::Array<(crate::prelude::Nat, crate::lower::model::Ex)>), i_p5: &crate::prelude::Nat| match crate::prelude::index(parts_p2, i_p5) {
            ::std::option::Option::Some(crate::lower::node_::Wres::WrLate(read_p6, _)) => (w_p3.clone(), crate::prelude::push(acc_p4, &(i_p5.clone(), read_p6))),
            ::std::option::Option::Some(crate::lower::node_::Wres::WrPlain(ex_p7, t_p8)) => {
                let (f_pa, w1_pb) = crate::lower::node_::fresh_name_f(w_p3, &crate::prelude::Text::lit("bundle_part"));
                let w2_p9 = {
                    let mut this: crate::lower::node_::Wx = w1_pb.clone();
                    this.lets_p = crate::prelude::push(&this.lets_p, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaBind(f_pa.clone())), t_p8.clone()), ex_p7));
                    this.fields_p = crate::prelude::push(&this.fields_p, &(f_pa.clone(), t_p8.clone(), crate::prelude::Text::lit("a plain part of a bundle bound where its block is split")));
                    this.inits_p = crate::prelude::push(&this.inits_p, &(f_pa.clone(), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(f_pa.clone())))));
                    this
                };
                (w2_p9.clone(), crate::prelude::push(acc_p4, &(i_p5.clone(), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), f_pa.clone()))))))
            },
            _ => (w_p3.clone(), acc_p4.clone()),
        })),
        _ => (wx_p0.clone(), crate::prelude::Array::new()),
    }
}

/// ```prism
/// ?PartRead: fn [((Nat, Ex))], Nat -> ?Ex
/// ```
pub fn part_read_o(reads_p0: &crate::prelude::Array<(crate::prelude::Nat, crate::lower::model::Ex)>, i_p1: &crate::prelude::Nat) -> ::std::option::Option<crate::lower::model::Ex> {
    crate::prelude::fold(reads_p0, &::std::option::Option::None, &(|found_o2: &::std::option::Option<crate::lower::model::Ex>, (j_p3, read_p4): &(crate::prelude::Nat, crate::lower::model::Ex)| if j_p3 == i_p1 {
        ::std::option::Option::Some(read_p4.clone())
    } else {
        found_o2.clone()
    }))
}

/// ```prism
/// LowerBinder: fn Lx, Pattern, Expr, [((Nat, Ex))] -> ((Ex, [?Pattern], Ty))
/// ```
pub fn lower_binder_f(lx_p0: &crate::lower::Lx, p_p1: &crate::syntax::Pattern, e_p2: &crate::syntax::Expr, part_reads_p3: &crate::prelude::Array<(crate::prelude::Nat, crate::lower::model::Ex)>) -> (crate::lower::model::Ex, crate::prelude::Array<::std::option::Option<crate::syntax::Pattern>>, crate::check::types::Ty) {
    let tys_p4 = crate::lower::node_::keyed::bundle_part_tys_f(&line_out_full_f(lx_p0, e_p2));
    let ps_p5 = match &*p_p1.kind_p {
        crate::syntax::PatternKind::PTuple(qs_p7) => qs_p7.clone(),
        _ => crate::prelude::Array::new(),
    };
    let bound_p6 = crate::prelude::filter(part_reads_p3, &(|(i_p8, _): &(crate::prelude::Nat, crate::lower::model::Ex)| i_p8 < &crate::prelude::len(&ps_p5)));
    'm52909: {
        if let m52909_0 = &bound_p6 && (m52909_0.len() == 0) {
            break 'm52909 (crate::lower::model::Ex::XUnit, crate::prelude::Array::from(vec![::std::option::Option::None]), crate::check::types::Ty::TyCon(crate::prelude::Text::lit("unit"), crate::prelude::Array::new()));
        }
        if let m52909_1 = &bound_p6 && (m52909_1.len() == 1) && let ::std::option::Option::Some((i_p9, read_pa)) = crate::prelude::index(m52909_1, &crate::prelude::Nat::from(0u32)) {
            break 'm52909 (read_pa.clone(), crate::prelude::Array::from(vec![crate::prelude::index(&ps_p5, &i_p9)]), crate::prelude::or(&crate::prelude::index(&tys_p4, &i_p9), &crate::check::types::Ty::TyErr));
        }
        (crate::lower::model::Ex::XTuple(crate::prelude::each(&bound_p6, &(|(_, read_pb): &(crate::prelude::Nat, crate::lower::model::Ex)| read_pb.clone()))), crate::prelude::Array::from(vec![::std::option::Option::Some(crate::syntax::Pattern { kind_p: ::std::rc::Rc::new(crate::syntax::PatternKind::PTuple(crate::prelude::each(&bound_p6, &(|(i_pc, _): &(crate::prelude::Nat, crate::lower::model::Ex)| crate::prelude::or(&crate::prelude::index(&ps_p5, i_pc), &crate::lower::patterns::dummy_pat_p()))))), span_p: p_p1.span_p.clone() })]), crate::check::types::Ty::TyTuple(crate::prelude::each(&bound_p6, &(|(i_pd, _): &(crate::prelude::Nat, crate::lower::model::Ex)| crate::prelude::or(&crate::prelude::index(&tys_p4, i_pd), &crate::check::types::Ty::TyErr)))))
    }
}

/// ```prism
/// HasStmt: fn [Stmt], Stmt -> Bool
/// ```
pub fn has_stmt_f(sts_p0: &crate::prelude::Array<crate::syntax::Stmt>, st_p1: &crate::syntax::Stmt) -> bool {
    crate::prelude::fold(sts_p0, &false, &(|f_p2: &bool, x_p3: &crate::syntax::Stmt| *f_p2 || ((&x_p3.span_p.start_p == &st_p1.span_p.start_p) && (&x_p3.span_p.end_p == &st_p1.span_p.end_p))))
}

/// ```prism
/// Unresulted: fn [Stmt] -> [Stmt]
/// ```
pub fn unresulted_f(sts_p0: &crate::prelude::Array<crate::syntax::Stmt>) -> crate::prelude::Array<crate::syntax::Stmt> {
    match crate::prelude::index(sts_p0, &crate::syntax::lexer::chars::dec_f(&crate::prelude::len(sts_p0))) {
        ::std::option::Option::Some(last_p1) => match &last_p1.kind_p {
            crate::syntax::StmtKind::SExpr(e_p2) => match &*e_p2.kind_p {
                crate::syntax::ExprKind::EFreeSigil(m53639_0_0, _) if (m53639_0_0 == &crate::prelude::Text::lit("@")) => sts_p0.clone(),
                _ => crate::prelude::push(&crate::prelude::take(sts_p0, &crate::syntax::lexer::chars::dec_f(&crate::prelude::len(sts_p0))), &crate::syntax::Stmt { kind_p: crate::syntax::StmtKind::SIgnore(e_p2.clone()), span_p: last_p1.span_p.clone() }),
                _ => unreachable!("no arm matched"),
            },
            _ => sts_p0.clone(),
        },
        ::std::option::Option::None => sts_p0.clone(),
    }
}

/// ```prism
/// HoistedLines: unbounded fn [Stmt], [Text], [Text] -> [Stmt]
/// ```
pub fn hoisted_lines_f(below_p0: &crate::prelude::Array<crate::syntax::Stmt>, late_names_p1: &crate::prelude::Array<crate::prelude::Text>, above_reads_p2: &crate::prelude::Array<crate::prelude::Text>) -> crate::prelude::Array<crate::syntax::Stmt> {
    let candidates_p3 = crate::prelude::filter(below_p0, &(|st_p5: &crate::syntax::Stmt| match &st_p5.kind_p {
        crate::syntax::StmtKind::SBind(_, _, ::std::option::Option::Some(_)) => true,
        crate::syntax::StmtKind::SLet(_, _, _) => true,
        crate::syntax::StmtKind::SFn(_) => true,
        crate::syntax::StmtKind::SWidget(_) => true,
        crate::syntax::StmtKind::SSignature(_) => true,
        crate::syntax::StmtKind::SEmit(_) => true,
        _ => false,
    }));
    let fixed_p4 = crate::prelude::filter(below_p0, &(|st_p6: &crate::syntax::Stmt| !has_stmt_f(&candidates_p3, st_p6)));
    hoisted_among_f(&candidates_p3, &crate::prelude::run_to_end(crate::prelude::fold_job(fixed_p4.clone(), crate::prelude::Array::new(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::syntax::Stmt)| crate::prelude::entered(crate::prelude::once_job(move || {
        let acc_p7 = p0;
        let st_p8 = p1;
        crate::prelude::call_then(start_non_event_defs_f(st_p8.clone()), move |non_event_defs_f_54777: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_p7, &non_event_defs_f_54777)))
    }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::syntax::Stmt)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>)), late_names_p1, above_reads_p2)
}

/// The step machine of `HoistedLines`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// HoistedLines: unbounded fn [Stmt], [Text], [Text] -> [Stmt]
/// ```
pub struct HoistedLines {
    pub below_p0: crate::prelude::Array<crate::syntax::Stmt>,
    pub late_names_p1: crate::prelude::Array<crate::prelude::Text>,
    pub above_reads_p2: crate::prelude::Array<crate::prelude::Text>,
}

impl ::prism_rtl::Job<crate::prelude::Array<crate::syntax::Stmt>> for HoistedLines {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<crate::syntax::Stmt>> {
        let below_p0 = &self.below_p0;
        let late_names_p1 = &self.late_names_p1;
        let above_reads_p2 = &self.above_reads_p2;
        let candidates_p3 = crate::prelude::filter(below_p0, &(|st_p5: &crate::syntax::Stmt| match &st_p5.kind_p {
            crate::syntax::StmtKind::SBind(_, _, ::std::option::Option::Some(_)) => true,
            crate::syntax::StmtKind::SLet(_, _, _) => true,
            crate::syntax::StmtKind::SFn(_) => true,
            crate::syntax::StmtKind::SWidget(_) => true,
            crate::syntax::StmtKind::SSignature(_) => true,
            crate::syntax::StmtKind::SEmit(_) => true,
            _ => false,
        }));
        let fixed_p4 = crate::prelude::filter(below_p0, &(|st_p6: &crate::syntax::Stmt| !has_stmt_f(&candidates_p3, st_p6)));
        let above_reads_p2x = above_reads_p2.clone();
        let late_names_p1x = late_names_p1.clone();
        crate::prelude::call_value(crate::prelude::fold_job(fixed_p4.clone(), crate::prelude::Array::new(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::syntax::Stmt)| crate::prelude::entered(crate::prelude::once_job(move || {
            let acc_p7 = p0;
            let st_p8 = p1;
            crate::prelude::call_then(start_non_event_defs_f(st_p8.clone()), move |non_event_defs_f_54777: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_p7, &non_event_defs_f_54777)))
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::syntax::Stmt)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>), move |fold_54731: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::More(::std::rc::Rc::new(HoistedAmong { candidates_p0: candidates_p3.clone(), blocking_p1: fold_54731, late_names_p2: late_names_p1x.clone(), above_reads_p3: above_reads_p2x.clone() })))
    }
}

/// `Start HoistedLines, x`: what the function value is when passed to `@Run`.
pub fn start_hoisted_lines_f(below_p0: crate::prelude::Array<crate::syntax::Stmt>, late_names_p1: crate::prelude::Array<crate::prelude::Text>, above_reads_p2: crate::prelude::Array<crate::prelude::Text>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::syntax::Stmt>>> {
    ::std::rc::Rc::new(HoistedLines { below_p0, late_names_p1, above_reads_p2 })
}

/// ```prism
/// IsOneNameReadAbove: fn Pattern, [Text] -> Bool
/// ```
pub fn is_one_name_read_above_f(p_p0: &crate::syntax::Pattern, above_reads_p1: &crate::prelude::Array<crate::prelude::Text>) -> bool {
    match &*p_p0.kind_p {
        crate::syntax::PatternKind::PName(n_p2) => crate::check::types::has_text_f(above_reads_p1, &crate::check::env::sname_key_f(n_p2)),
        _ => false,
    }
}

/// ```prism
/// HoistedAmong: unbounded fn [Stmt], [Text], [Text], [Text] -> [Stmt]
/// ```
pub fn hoisted_among_f(candidates_p0: &crate::prelude::Array<crate::syntax::Stmt>, blocking_p1: &crate::prelude::Array<crate::prelude::Text>, late_names_p2: &crate::prelude::Array<crate::prelude::Text>, above_reads_p3: &crate::prelude::Array<crate::prelude::Text>) -> crate::prelude::Array<crate::syntax::Stmt> {
    let stays_f4 = {
        let above_reads_p3x = above_reads_p3.clone();
        let blocking_p1x = blocking_p1.clone();
        let late_names_p2x = late_names_p2.clone();
        ::std::rc::Rc::new(move |p0: crate::syntax::Stmt| {
            let above_reads_p3xy = above_reads_p3x.clone();
            let blocking_p1xy = blocking_p1x.clone();
            let late_names_p2xy = late_names_p2x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let st_p6 = p0;
                crate::prelude::call_then(start_reads_of_line_f(st_p6.clone()), move |reads_of_line_f_55285: crate::prelude::Array<crate::prelude::Text>| {
                    let reads_p7 = reads_of_line_f_55285;
                    let blocking_p1xyz = blocking_p1xy.clone();
                    let late_names_p2xyz = late_names_p2xy.clone();
                    let reads_p7z = reads_p7.clone();
                    let k_let55308 = move |v55308: bool| {
                        let plain_let_p8 = v55308;
                        ::prism_rtl::Turn::Finished(crate::prelude::fold(&reads_p7z, &false, &(|f_pc: &bool, n_pd: &crate::prelude::Text| *f_pc || crate::check::types::has_text_f(&blocking_p1xyz, n_pd))) || (plain_let_p8 && crate::prelude::fold(&reads_p7z, &false, &(|f_pe: &bool, n_pf: &crate::prelude::Text| *f_pe || crate::check::types::has_text_f(&late_names_p2xyz, n_pf)))))
                    };
                    match st_p6.kind_p.clone() {
                        crate::syntax::StmtKind::SLet(p_p9, _, _) => crate::prelude::call_then(crate::check::env::names::start_pattern_names_f(p_p9.clone()), move |pattern_names_f_55381: crate::prelude::Array<crate::prelude::Text>| k_let55308(crate::prelude::fold(&pattern_names_f_55381, &false, &(|f_pa: &bool, n_pb: &crate::prelude::Text| *f_pa || !(crate::syntax::lexer::chars::has_prefix_f(n_pb, &crate::prelude::Text::lit("$")) || crate::syntax::lexer::chars::has_prefix_f(n_pb, &crate::prelude::Text::lit("!"))))) && !is_one_name_read_above_f(&p_p9, &above_reads_p3xy))),
                        _ => k_let55308(false),
                    }
                })
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::syntax::Stmt) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
    };
    let out_p5 = crate::prelude::run_to_end(crate::prelude::filter_job(candidates_p0.clone(), stays_f4.clone()));
    if &crate::prelude::len(&out_p5) == &crate::prelude::Nat::from(0u32) {
        candidates_p0.clone()
    } else {
        hoisted_among_f(&crate::prelude::filter(candidates_p0, &(|st_pg: &crate::syntax::Stmt| !has_stmt_f(&out_p5, st_pg))), &crate::prelude::run_to_end(crate::prelude::fold_job(out_p5.clone(), blocking_p1.clone(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::syntax::Stmt)| crate::prelude::entered(crate::prelude::once_job(move || {
            let acc_ph = p0;
            let st_pi = p1;
            crate::prelude::call_then(start_non_event_defs_f(st_pi.clone()), move |non_event_defs_f_55864: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_ph, &non_event_defs_f_55864)))
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::syntax::Stmt)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>)), late_names_p2, above_reads_p3)
    }
}

/// The step machine of `HoistedAmong`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// HoistedAmong: unbounded fn [Stmt], [Text], [Text], [Text] -> [Stmt]
/// ```
pub struct HoistedAmong {
    pub candidates_p0: crate::prelude::Array<crate::syntax::Stmt>,
    pub blocking_p1: crate::prelude::Array<crate::prelude::Text>,
    pub late_names_p2: crate::prelude::Array<crate::prelude::Text>,
    pub above_reads_p3: crate::prelude::Array<crate::prelude::Text>,
}

impl ::prism_rtl::Job<crate::prelude::Array<crate::syntax::Stmt>> for HoistedAmong {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<crate::syntax::Stmt>> {
        let candidates_p0 = &self.candidates_p0;
        let blocking_p1 = &self.blocking_p1;
        let late_names_p2 = &self.late_names_p2;
        let above_reads_p3 = &self.above_reads_p3;
        let stays_f4 = {
            let above_reads_p3x = above_reads_p3.clone();
            let blocking_p1x = blocking_p1.clone();
            let late_names_p2x = late_names_p2.clone();
            ::std::rc::Rc::new(move |p0: crate::syntax::Stmt| {
                let above_reads_p3xy = above_reads_p3x.clone();
                let blocking_p1xy = blocking_p1x.clone();
                let late_names_p2xy = late_names_p2x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let st_p6 = p0;
                    crate::prelude::call_then(start_reads_of_line_f(st_p6.clone()), move |reads_of_line_f_55285: crate::prelude::Array<crate::prelude::Text>| {
                        let reads_p7 = reads_of_line_f_55285;
                        let blocking_p1xyz = blocking_p1xy.clone();
                        let late_names_p2xyz = late_names_p2xy.clone();
                        let reads_p7z = reads_p7.clone();
                        let k_let55308 = move |v55308: bool| {
                            let plain_let_p8 = v55308;
                            ::prism_rtl::Turn::Finished(crate::prelude::fold(&reads_p7z, &false, &(|f_pc: &bool, n_pd: &crate::prelude::Text| *f_pc || crate::check::types::has_text_f(&blocking_p1xyz, n_pd))) || (plain_let_p8 && crate::prelude::fold(&reads_p7z, &false, &(|f_pe: &bool, n_pf: &crate::prelude::Text| *f_pe || crate::check::types::has_text_f(&late_names_p2xyz, n_pf)))))
                        };
                        match st_p6.kind_p.clone() {
                            crate::syntax::StmtKind::SLet(p_p9, _, _) => crate::prelude::call_then(crate::check::env::names::start_pattern_names_f(p_p9.clone()), move |pattern_names_f_55381: crate::prelude::Array<crate::prelude::Text>| k_let55308(crate::prelude::fold(&pattern_names_f_55381, &false, &(|f_pa: &bool, n_pb: &crate::prelude::Text| *f_pa || !(crate::syntax::lexer::chars::has_prefix_f(n_pb, &crate::prelude::Text::lit("$")) || crate::syntax::lexer::chars::has_prefix_f(n_pb, &crate::prelude::Text::lit("!"))))) && !is_one_name_read_above_f(&p_p9, &above_reads_p3xy))),
                            _ => k_let55308(false),
                        }
                    })
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::syntax::Stmt) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
        };
        let above_reads_p3x = above_reads_p3.clone();
        let blocking_p1x = blocking_p1.clone();
        let candidates_p0x = candidates_p0.clone();
        let late_names_p2x = late_names_p2.clone();
        crate::prelude::call_value(crate::prelude::filter_job(candidates_p0x.clone(), stays_f4.clone()), move |filter_55683: crate::prelude::Array<crate::syntax::Stmt>| {
            let out_p5 = filter_55683;
            if &crate::prelude::len(&out_p5) == &crate::prelude::Nat::from(0u32) {
                ::prism_rtl::Turn::Finished(candidates_p0x.clone())
            } else {
                crate::prelude::call_value(crate::prelude::fold_job(out_p5.clone(), blocking_p1x.clone(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::syntax::Stmt)| crate::prelude::entered(crate::prelude::once_job(move || {
                    let acc_ph = p0;
                    let st_pi = p1;
                    crate::prelude::call_then(start_non_event_defs_f(st_pi.clone()), move |non_event_defs_f_55864: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_ph, &non_event_defs_f_55864)))
                }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::syntax::Stmt)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>), move |fold_55816: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::More(::std::rc::Rc::new(HoistedAmong { candidates_p0: crate::prelude::filter(&candidates_p0x, &(|st_pg: &crate::syntax::Stmt| !has_stmt_f(&out_p5, st_pg))), blocking_p1: fold_55816, late_names_p2: late_names_p2x.clone(), above_reads_p3: above_reads_p3x.clone() })))
            }
        })
    }
}

/// `Start HoistedAmong, x`: what the function value is when passed to `@Run`.
pub fn start_hoisted_among_f(candidates_p0: crate::prelude::Array<crate::syntax::Stmt>, blocking_p1: crate::prelude::Array<crate::prelude::Text>, late_names_p2: crate::prelude::Array<crate::prelude::Text>, above_reads_p3: crate::prelude::Array<crate::prelude::Text>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::syntax::Stmt>>> {
    ::std::rc::Rc::new(HoistedAmong { candidates_p0, blocking_p1, late_names_p2, above_reads_p3 })
}

/// ```prism
/// ReadsOfLine: unbounded fn Stmt -> [Text]
/// ```
pub fn reads_of_line_f(s_p0: &crate::syntax::Stmt) -> crate::prelude::Array<crate::prelude::Text> {
    match &s_p0.kind_p {
        crate::syntax::StmtKind::SFn(f_p1) => crate::lower::expr::free_reads_f(&crate::check::typed::print::stmt_exprs_f(s_p0), &crate::prelude::Array::from(vec![(crate::prelude::run_to_end(crate::prelude::fold_job(f_p1.params_p.clone(), crate::prelude::Array::new(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::syntax::Pattern)| crate::prelude::entered(crate::prelude::once_job(move || {
            let acc_p2 = p0;
            let q_p3 = p1;
            crate::prelude::call_then(crate::check::env::names::start_pattern_names_f(q_p3.clone()), move |pattern_names_f_56152: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_p2, &pattern_names_f_56152)))
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::syntax::Pattern)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>)), f_p1.span_p.clone())])),
        _ => crate::lower::expr::free_reads_f(&crate::check::typed::print::stmt_exprs_f(s_p0), &crate::prelude::Array::new()),
    }
}

/// The step machine of `ReadsOfLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ReadsOfLine: unbounded fn Stmt -> [Text]
/// ```
pub struct ReadsOfLine {
    pub s_p0: crate::syntax::Stmt,
}

impl ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>> for ReadsOfLine {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<crate::prelude::Text>> {
        let s_p0 = &self.s_p0;
        match &s_p0.kind_p {
            crate::syntax::StmtKind::SFn(f_p1) => {
                let f_p1x = f_p1.clone();
                let s_p0x = s_p0.clone();
                crate::prelude::call_then(crate::check::typed::print::start_stmt_exprs_f(s_p0x.clone()), move |stmt_exprs_f_56089: crate::prelude::Array<crate::syntax::Expr>| crate::prelude::call_value(crate::prelude::fold_job(f_p1x.params_p.clone(), crate::prelude::Array::new(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::syntax::Pattern)| crate::prelude::entered(crate::prelude::once_job(move || {
                    let acc_p2 = p0;
                    let q_p3 = p1;
                    crate::prelude::call_then(crate::check::env::names::start_pattern_names_f(q_p3.clone()), move |pattern_names_f_56152: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_p2, &pattern_names_f_56152)))
                }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::syntax::Pattern)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>), move |fold_56108: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::lower::expr::FreeReads { es_p0: stmt_exprs_f_56089, outer_p1: crate::prelude::Array::from(vec![(fold_56108, f_p1x.span_p.clone())]) }))))
            },
            _ => {
                let s_p0x = s_p0.clone();
                crate::prelude::call_then(crate::check::typed::print::start_stmt_exprs_f(s_p0x.clone()), move |stmt_exprs_f_56207: crate::prelude::Array<crate::syntax::Expr>| ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::lower::expr::FreeReads { es_p0: stmt_exprs_f_56207, outer_p1: crate::prelude::Array::new() })))
            },
        }
    }
}

/// `Start ReadsOfLine, x`: what the function value is when passed to `@Run`.
pub fn start_reads_of_line_f(s_p0: crate::syntax::Stmt) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>> {
    ::std::rc::Rc::new(ReadsOfLine { s_p0 })
}

/// ```prism
/// NonEventDefs: unbounded fn Stmt -> [Text]
/// ```
pub fn non_event_defs_f(s_p0: &crate::syntax::Stmt) -> crate::prelude::Array<crate::prelude::Text> {
    crate::prelude::filter(&crate::check::blocks::group_defs_f(s_p0), &(|d_p1: &crate::prelude::Text| !crate::syntax::lexer::chars::has_prefix_f(d_p1, &crate::prelude::Text::lit("!"))))
}

/// The step machine of `NonEventDefs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// NonEventDefs: unbounded fn Stmt -> [Text]
/// ```
pub struct NonEventDefs {
    pub s_p0: crate::syntax::Stmt,
}

impl ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>> for NonEventDefs {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<crate::prelude::Text>> {
        let s_p0 = &self.s_p0;
        let s_p0x = s_p0.clone();
        crate::prelude::call_then(crate::check::blocks::start_group_defs_f(s_p0x.clone()), move |group_defs_f_56297: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::prelude::filter(&group_defs_f_56297, &(|d_p1: &crate::prelude::Text| !crate::syntax::lexer::chars::has_prefix_f(d_p1, &crate::prelude::Text::lit("!"))))))
    }
}

/// `Start NonEventDefs, x`: what the function value is when passed to `@Run`.
pub fn start_non_event_defs_f(s_p0: crate::syntax::Stmt) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>> {
    ::std::rc::Rc::new(NonEventDefs { s_p0 })
}

/// ```prism
/// PreBindUps: unbounded fn Wx, Env, Env, [Stmt] -> ((Wx, Env, Env, [((Text, Text, Text))]))
/// ```
pub fn pre_bind_ups_f(wx_p0: &crate::lower::node_::Wx, benv_p1: &crate::lower::types::Env, menv_p2: &crate::lower::types::Env, staying_p3: &crate::prelude::Array<crate::syntax::Stmt>) -> (crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env, crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text, crate::prelude::Text)>) {
    let binders_p4 = crate::prelude::run_to_end(crate::prelude::fold_job(staying_p3.clone(), crate::prelude::Array::new(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<(crate::syntax::SName, HowBound)>, crate::syntax::Stmt)| crate::prelude::entered(crate::prelude::once_job(move || {
        let acc_p5 = p0;
        let st_p6 = p1;
        match &st_p6.kind_p {
            crate::syntax::StmtKind::SBind(p_p7, _, ::std::option::Option::None) => {
                let p_p7x = p_p7.clone();
                crate::prelude::call_then(start_binder_names_f(p_p7x.clone()), move |binder_names_f_56946: crate::prelude::Array<crate::syntax::SName>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_p5, &crate::prelude::each(&crate::prelude::filter(&binder_names_f_56946, &(|n_p8: &crate::syntax::SName| crate::syntax::lexer::chars::has_prefix_f(&crate::check::env::sname_key_f(n_p8), &crate::prelude::Text::lit("!")))), &(|n_p9: &crate::syntax::SName| (n_p9.clone(), HowBound::AsBind))))))
            },
            crate::syntax::StmtKind::SLet(p_pa, _, _) => {
                let p_pax = p_pa.clone();
                crate::prelude::call_then(start_binder_names_f(p_pax.clone()), move |binder_names_f_57076: crate::prelude::Array<crate::syntax::SName>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_p5, &crate::prelude::each(&crate::prelude::filter(&binder_names_f_57076, &(|n_pb: &crate::syntax::SName| crate::syntax::lexer::chars::has_prefix_f(&crate::check::env::sname_key_f(n_pb), &crate::prelude::Text::lit("!")))), &(|n_pc: &crate::syntax::SName| (n_pc.clone(), HowBound::AsLet))))))
            },
            _ => ::prism_rtl::Turn::Finished(acc_p5.clone()),
        }
    }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<(crate::syntax::SName, HowBound)>, crate::syntax::Stmt)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<(crate::syntax::SName, HowBound)>>>>));
    crate::prelude::run_to_end(crate::prelude::fold_job(binders_p4.clone(), (wx_p0.clone(), benv_p1.clone(), menv_p2.clone(), crate::prelude::Array::new()), ::std::rc::Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env, crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text, crate::prelude::Text)>), (crate::syntax::SName, HowBound))| crate::prelude::entered(crate::prelude::once_job(move || {
        let (w_pd, be_pe, me_pf, acc_pg) = p0;
        let (n_ph, how_pi) = p1;
        crate::prelude::call_then(start_pre_bind_name_f(w_pd.clone(), be_pe.clone(), me_pf.clone(), n_ph.clone(), how_pi.clone()), move |pre_bind_name_f_57278: (crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)| {
            let (w2_pj, be2_pk, me2_pl) = pre_bind_name_f_57278;
            match crate::prelude::get(&me2_pl.names_p, &crate::check::env::sname_key_f(&n_ph)) {
                ::std::option::Option::Some(crate::lower::types::Bn::BnEv(er_pm, _)) => crate::prelude::call_then(crate::lower::expr::start_widget_let_lx_f(w_pd.lx_p.clone(), n_ph.span_p.clone()), move |widget_let_lx_f_57435: crate::lower::Lx| crate::prelude::call_then(crate::lower::start_local_name_at_f(widget_let_lx_f_57435, crate::check::env::sname_key_f(&n_ph), n_ph.span_p.clone()), move |local_name_at_f_57422: crate::prelude::Text| ::prism_rtl::Turn::Finished((w2_pj.clone(), be2_pk.clone(), me2_pl.clone(), crate::prelude::push(&acc_pg, &(crate::check::env::sname_key_f(&n_ph), local_name_at_f_57422, crate::lower::node_::gn_of_f(&w2_pj, &er_pm.node_p).name_p.clone())))))),
                _ => ::prism_rtl::Turn::Finished((w2_pj.clone(), be2_pk.clone(), me2_pl.clone(), acc_pg.clone())),
            }
        })
    }))) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env, crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text, crate::prelude::Text)>), (crate::syntax::SName, HowBound))) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env, crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text, crate::prelude::Text)>)>>>))
}

/// The step machine of `PreBindUps`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PreBindUps: unbounded fn Wx, Env, Env, [Stmt] -> ((Wx, Env, Env, [((Text, Text, Text))]))
/// ```
pub struct PreBindUps {
    pub wx_p0: crate::lower::node_::Wx,
    pub benv_p1: crate::lower::types::Env,
    pub menv_p2: crate::lower::types::Env,
    pub staying_p3: crate::prelude::Array<crate::syntax::Stmt>,
}

impl ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env, crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text, crate::prelude::Text)>)> for PreBindUps {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env, crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text, crate::prelude::Text)>)> {
        let wx_p0 = &self.wx_p0;
        let benv_p1 = &self.benv_p1;
        let menv_p2 = &self.menv_p2;
        let staying_p3 = &self.staying_p3;
        let benv_p1x = benv_p1.clone();
        let menv_p2x = menv_p2.clone();
        let staying_p3x = staying_p3.clone();
        let wx_p0x = wx_p0.clone();
        crate::prelude::call_value(crate::prelude::fold_job(staying_p3x.clone(), crate::prelude::Array::new(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<(crate::syntax::SName, HowBound)>, crate::syntax::Stmt)| crate::prelude::entered(crate::prelude::once_job(move || {
            let acc_p5 = p0;
            let st_p6 = p1;
            match &st_p6.kind_p {
                crate::syntax::StmtKind::SBind(p_p7, _, ::std::option::Option::None) => {
                    let p_p7x = p_p7.clone();
                    crate::prelude::call_then(start_binder_names_f(p_p7x.clone()), move |binder_names_f_56946: crate::prelude::Array<crate::syntax::SName>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_p5, &crate::prelude::each(&crate::prelude::filter(&binder_names_f_56946, &(|n_p8: &crate::syntax::SName| crate::syntax::lexer::chars::has_prefix_f(&crate::check::env::sname_key_f(n_p8), &crate::prelude::Text::lit("!")))), &(|n_p9: &crate::syntax::SName| (n_p9.clone(), HowBound::AsBind))))))
                },
                crate::syntax::StmtKind::SLet(p_pa, _, _) => {
                    let p_pax = p_pa.clone();
                    crate::prelude::call_then(start_binder_names_f(p_pax.clone()), move |binder_names_f_57076: crate::prelude::Array<crate::syntax::SName>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_p5, &crate::prelude::each(&crate::prelude::filter(&binder_names_f_57076, &(|n_pb: &crate::syntax::SName| crate::syntax::lexer::chars::has_prefix_f(&crate::check::env::sname_key_f(n_pb), &crate::prelude::Text::lit("!")))), &(|n_pc: &crate::syntax::SName| (n_pc.clone(), HowBound::AsLet))))))
                },
                _ => ::prism_rtl::Turn::Finished(acc_p5.clone()),
            }
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<(crate::syntax::SName, HowBound)>, crate::syntax::Stmt)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<(crate::syntax::SName, HowBound)>>>>), move |fold_56843: crate::prelude::Array<(crate::syntax::SName, HowBound)>| {
            let binders_p4 = fold_56843;
            crate::prelude::fold_job(binders_p4.clone(), (wx_p0x.clone(), benv_p1x.clone(), menv_p2x.clone(), crate::prelude::Array::new()), ::std::rc::Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env, crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text, crate::prelude::Text)>), (crate::syntax::SName, HowBound))| crate::prelude::entered(crate::prelude::once_job(move || {
                let (w_pd, be_pe, me_pf, acc_pg) = p0;
                let (n_ph, how_pi) = p1;
                crate::prelude::call_then(start_pre_bind_name_f(w_pd.clone(), be_pe.clone(), me_pf.clone(), n_ph.clone(), how_pi.clone()), move |pre_bind_name_f_57278: (crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)| {
                    let (w2_pj, be2_pk, me2_pl) = pre_bind_name_f_57278;
                    match crate::prelude::get(&me2_pl.names_p, &crate::check::env::sname_key_f(&n_ph)) {
                        ::std::option::Option::Some(crate::lower::types::Bn::BnEv(er_pm, _)) => crate::prelude::call_then(crate::lower::expr::start_widget_let_lx_f(w_pd.lx_p.clone(), n_ph.span_p.clone()), move |widget_let_lx_f_57435: crate::lower::Lx| crate::prelude::call_then(crate::lower::start_local_name_at_f(widget_let_lx_f_57435, crate::check::env::sname_key_f(&n_ph), n_ph.span_p.clone()), move |local_name_at_f_57422: crate::prelude::Text| ::prism_rtl::Turn::Finished((w2_pj.clone(), be2_pk.clone(), me2_pl.clone(), crate::prelude::push(&acc_pg, &(crate::check::env::sname_key_f(&n_ph), local_name_at_f_57422, crate::lower::node_::gn_of_f(&w2_pj, &er_pm.node_p).name_p.clone())))))),
                        _ => ::prism_rtl::Turn::Finished((w2_pj.clone(), be2_pk.clone(), me2_pl.clone(), acc_pg.clone())),
                    }
                })
            }))) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env, crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text, crate::prelude::Text)>), (crate::syntax::SName, HowBound))) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env, crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text, crate::prelude::Text)>)>>>).cycle()
        })
    }
}

/// `Start PreBindUps, x`: what the function value is when passed to `@Run`.
pub fn start_pre_bind_ups_f(wx_p0: crate::lower::node_::Wx, benv_p1: crate::lower::types::Env, menv_p2: crate::lower::types::Env, staying_p3: crate::prelude::Array<crate::syntax::Stmt>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env, crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text, crate::prelude::Text)>)>> {
    ::std::rc::Rc::new(PreBindUps { wx_p0, benv_p1, menv_p2, staying_p3 })
}

/// ```prism
/// WithoutNames: fn Env, [Text] -> Env
/// ```
pub fn without_names_f(env_p0: &crate::lower::types::Env, gone_p1: &crate::prelude::Array<crate::prelude::Text>) -> crate::lower::types::Env {
    let bare_p2 = {
        let mut this: crate::lower::types::Env = env_p0.clone();
        this.names_p = crate::prelude::Map::new();
        this
    };
    crate::prelude::fold(&crate::prelude::keys(&env_p0.names_p), &bare_p2, &(|en_p3: &crate::lower::types::Env, nm_p4: &crate::prelude::Text| match crate::prelude::get(&env_p0.names_p, nm_p4) {
        ::std::option::Option::Some(bn_p5) => if crate::check::types::has_text_f(gone_p1, nm_p4) {
            en_p3.clone()
        } else {
            crate::lower::types::bind_f(en_p3, nm_p4, &bn_p5)
        },
        ::std::option::Option::None => en_p3.clone(),
    }))
}

/// ```prism
/// BindLate: unbounded fn Wx, Env, Env, Stmt -> ((Wx, Env, Env, [LateName]))
/// ```
pub fn bind_late_f(wx_p0: &crate::lower::node_::Wx, benv_p1: &crate::lower::types::Env, menv_p2: &crate::lower::types::Env, s_p3: &crate::syntax::Stmt) -> (crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env, crate::prelude::Array<LateName>) {
    match &s_p3.kind_p {
        crate::syntax::StmtKind::SBind(p_p4, e_p5, ::std::option::Option::None) => {
            let part_tys_p6 = crate::lower::node_::keyed::bundle_part_tys_f(&line_out_full_f(&wx_p0.lx_p, e_p5));
            let parts_p7 = match &*p_p4.kind_p {
                crate::syntax::PatternKind::PName(n_p8) => crate::prelude::Array::from(vec![(n_p8.clone(), ::std::option::Option::None, ::std::option::Option::None)]),
                crate::syntax::PatternKind::PGroup(q_p9) => match &*q_p9.kind_p {
                    crate::syntax::PatternKind::PName(n_pa) => crate::prelude::Array::from(vec![(n_pa.clone(), ::std::option::Option::None, ::std::option::Option::None)]),
                    _ => crate::prelude::Array::new(),
                },
                crate::syntax::PatternKind::PTuple(ps_pb) => crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(ps_pb)), crate::prelude::Array::new(), {
                    let ps_pbx = ps_pb.clone();
                    let part_tys_p6x = part_tys_p6.clone();
                    ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<(crate::syntax::SName, ::std::option::Option<crate::prelude::Nat>, ::std::option::Option<(crate::syntax::Pattern, crate::check::types::Ty)>)>, crate::prelude::Nat)| {
                        let ps_pbxy = ps_pbx.clone();
                        let part_tys_p6xy = part_tys_p6x.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let acc_pc = p0;
                            let i_pd = p1;
                            match &*crate::prelude::or(&crate::prelude::index(&ps_pbxy, &i_pd), &crate::lower::patterns::dummy_pat_p()).kind_p {
                                crate::syntax::PatternKind::PName(n_pe) => if is_time_name_f(&crate::check::env::sname_key_f(n_pe)) {
                                    ::prism_rtl::Turn::Finished(acc_pc.clone())
                                } else {
                                    ::prism_rtl::Turn::Finished(crate::prelude::push(&acc_pc, &(n_pe.clone(), ::std::option::Option::Some(i_pd.clone()), ::std::option::Option::None)))
                                },
                                _ => {
                                    let part_ty_pf = crate::prelude::or(&crate::prelude::index(&part_tys_p6xy, &i_pd), &crate::check::types::Ty::TyErr);
                                    if crate::lower::types::is_bundle_f(&part_ty_pf) {
                                        ::prism_rtl::Turn::Finished(acc_pc.clone())
                                    } else {
                                        crate::prelude::call_then(start_binder_names_f(crate::prelude::or(&crate::prelude::index(&ps_pbxy, &i_pd), &crate::lower::patterns::dummy_pat_p())), move |binder_names_f_59258: crate::prelude::Array<crate::syntax::SName>| ::prism_rtl::Turn::Finished(crate::prelude::fold(&binder_names_f_59258, &acc_pc, &(|a_pg: &crate::prelude::Array<(crate::syntax::SName, ::std::option::Option<crate::prelude::Nat>, ::std::option::Option<(crate::syntax::Pattern, crate::check::types::Ty)>)>, n_ph: &crate::syntax::SName| if is_time_name_f(&crate::check::env::sname_key_f(n_ph)) {
                                            a_pg.clone()
                                        } else {
                                            crate::prelude::push(a_pg, &(n_ph.clone(), ::std::option::Option::Some(i_pd.clone()), ::std::option::Option::Some((crate::prelude::or(&crate::prelude::index(&ps_pbxy, &i_pd), &crate::lower::patterns::dummy_pat_p()), part_ty_pf.clone()))))
                                        }))))
                                    }
                                },
                            }
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<(crate::syntax::SName, ::std::option::Option<crate::prelude::Nat>, ::std::option::Option<(crate::syntax::Pattern, crate::check::types::Ty)>)>, crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<(crate::syntax::SName, ::std::option::Option<crate::prelude::Nat>, ::std::option::Option<(crate::syntax::Pattern, crate::check::types::Ty)>)>>>>
                })),
                _ => crate::prelude::Array::new(),
            };
            crate::prelude::run_to_end(crate::prelude::fold_job(parts_p7.clone(), (wx_p0.clone(), benv_p1.clone(), menv_p2.clone(), crate::prelude::Array::new()), ::std::rc::Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env, crate::prelude::Array<LateName>), (crate::syntax::SName, ::std::option::Option<crate::prelude::Nat>, ::std::option::Option<(crate::syntax::Pattern, crate::check::types::Ty)>))| crate::prelude::entered(crate::prelude::once_job(move || {
                let (w_pi, be_pj, me_pk, acc_pl) = p0;
                let (n_pm, part_on, within_oo) = p1;
                {
                    let nkey_pp = crate::check::env::sname_key_f(&n_pm);
                    crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(w_pi.lx_p.clone(), crate::lower::types::peel_f(&crate::lower::binder_ty_f(&w_pi.lx_p, &n_pm.span_p))), move |out_ty_of_f_59570: crate::lower::model::OutTy| {
                        let t_pq = out_ty_of_f_59570;
                        crate::prelude::call_then(crate::lower::start_local_name_at_f(w_pi.lx_p.clone(), nkey_pp.clone(), n_pm.span_p.clone()), move |local_name_at_f_59668: crate::prelude::Text| {
                            let (getter_pu, w2_pv) = crate::lower::node_::fresh_name_f(&w_pi, &crate::prelude::Text::from(format!("late_{}", &local_name_at_f_59668)));
                            let unbuilt_pr = crate::lower::types::Bn::BnLocal(crate::lower::expr::refusal_f(&crate::prelude::Text::from(format!("the late result `{}` read at its block\'s build by a line of the block\'s node (a place\'s constant field or a plain `let` above the line that binds it)", &nkey_pp))), crate::lower::types::Holding::Owned, t_pq.clone());
                            let be2_ps = crate::lower::types::bind_f(&crate::lower::types::bind_f(&be_pj, &nkey_pp, &unbuilt_pr), &crate::prelude::Text::from(format!("{}#late", &nkey_pp)), &unbuilt_pr);
                            let me2_pt = crate::lower::types::bind_f(&crate::lower::types::bind_f(&me_pk, &nkey_pp, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), getter_pu.clone(), crate::prelude::Array::new()), crate::lower::types::Holding::Owned, t_pq.clone())), &crate::prelude::Text::from(format!("{}#late", &nkey_pp)), &unbuilt_pr);
                            ::prism_rtl::Turn::Finished((w2_pv.clone(), be2_ps.clone(), me2_pt.clone(), crate::prelude::push(&acc_pl, &LateName { getter_p: getter_pu.clone(), part_o: part_on.clone(), ty_p: t_pq.clone(), name_p: nkey_pp.clone(), within_o: within_oo.clone() })))
                        })
                    })
                }
            }))) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env, crate::prelude::Array<LateName>), (crate::syntax::SName, ::std::option::Option<crate::prelude::Nat>, ::std::option::Option<(crate::syntax::Pattern, crate::check::types::Ty)>))) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env, crate::prelude::Array<LateName>)>>>))
        },
        _ => (wx_p0.clone(), benv_p1.clone(), menv_p2.clone(), crate::prelude::Array::new()),
    }
}

/// The step machine of `BindLate`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BindLate: unbounded fn Wx, Env, Env, Stmt -> ((Wx, Env, Env, [LateName]))
/// ```
pub struct BindLate {
    pub wx_p0: crate::lower::node_::Wx,
    pub benv_p1: crate::lower::types::Env,
    pub menv_p2: crate::lower::types::Env,
    pub s_p3: crate::syntax::Stmt,
}

impl ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env, crate::prelude::Array<LateName>)> for BindLate {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env, crate::prelude::Array<LateName>)> {
        let wx_p0 = &self.wx_p0;
        let benv_p1 = &self.benv_p1;
        let menv_p2 = &self.menv_p2;
        let s_p3 = &self.s_p3;
        match &s_p3.kind_p {
            crate::syntax::StmtKind::SBind(p_p4, e_p5, ::std::option::Option::None) => {
                let part_tys_p6 = crate::lower::node_::keyed::bundle_part_tys_f(&line_out_full_f(&wx_p0.lx_p, e_p5));
                let benv_p1z = benv_p1.clone();
                let menv_p2z = menv_p2.clone();
                let wx_p0z = wx_p0.clone();
                let k_let58428 = move |v58428: crate::prelude::Array<(crate::syntax::SName, ::std::option::Option<crate::prelude::Nat>, ::std::option::Option<(crate::syntax::Pattern, crate::check::types::Ty)>)>| {
                    let parts_p7 = v58428;
                    crate::prelude::fold_job(parts_p7.clone(), (wx_p0z.clone(), benv_p1z.clone(), menv_p2z.clone(), crate::prelude::Array::new()), ::std::rc::Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env, crate::prelude::Array<LateName>), (crate::syntax::SName, ::std::option::Option<crate::prelude::Nat>, ::std::option::Option<(crate::syntax::Pattern, crate::check::types::Ty)>))| crate::prelude::entered(crate::prelude::once_job(move || {
                        let (w_pi, be_pj, me_pk, acc_pl) = p0;
                        let (n_pm, part_on, within_oo) = p1;
                        {
                            let nkey_pp = crate::check::env::sname_key_f(&n_pm);
                            crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(w_pi.lx_p.clone(), crate::lower::types::peel_f(&crate::lower::binder_ty_f(&w_pi.lx_p, &n_pm.span_p))), move |out_ty_of_f_59570: crate::lower::model::OutTy| {
                                let t_pq = out_ty_of_f_59570;
                                crate::prelude::call_then(crate::lower::start_local_name_at_f(w_pi.lx_p.clone(), nkey_pp.clone(), n_pm.span_p.clone()), move |local_name_at_f_59668: crate::prelude::Text| {
                                    let (getter_pu, w2_pv) = crate::lower::node_::fresh_name_f(&w_pi, &crate::prelude::Text::from(format!("late_{}", &local_name_at_f_59668)));
                                    let unbuilt_pr = crate::lower::types::Bn::BnLocal(crate::lower::expr::refusal_f(&crate::prelude::Text::from(format!("the late result `{}` read at its block\'s build by a line of the block\'s node (a place\'s constant field or a plain `let` above the line that binds it)", &nkey_pp))), crate::lower::types::Holding::Owned, t_pq.clone());
                                    let be2_ps = crate::lower::types::bind_f(&crate::lower::types::bind_f(&be_pj, &nkey_pp, &unbuilt_pr), &crate::prelude::Text::from(format!("{}#late", &nkey_pp)), &unbuilt_pr);
                                    let me2_pt = crate::lower::types::bind_f(&crate::lower::types::bind_f(&me_pk, &nkey_pp, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), getter_pu.clone(), crate::prelude::Array::new()), crate::lower::types::Holding::Owned, t_pq.clone())), &crate::prelude::Text::from(format!("{}#late", &nkey_pp)), &unbuilt_pr);
                                    ::prism_rtl::Turn::Finished((w2_pv.clone(), be2_ps.clone(), me2_pt.clone(), crate::prelude::push(&acc_pl, &LateName { getter_p: getter_pu.clone(), part_o: part_on.clone(), ty_p: t_pq.clone(), name_p: nkey_pp.clone(), within_o: within_oo.clone() })))
                                })
                            })
                        }
                    }))) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env, crate::prelude::Array<LateName>), (crate::syntax::SName, ::std::option::Option<crate::prelude::Nat>, ::std::option::Option<(crate::syntax::Pattern, crate::check::types::Ty)>))) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env, crate::prelude::Array<LateName>)>>>).cycle()
                };
                match (*p_p4.kind_p).clone() {
                    crate::syntax::PatternKind::PName(n_p8) => k_let58428(crate::prelude::Array::from(vec![(n_p8.clone(), ::std::option::Option::None, ::std::option::Option::None)])),
                    crate::syntax::PatternKind::PGroup(q_p9) => k_let58428(match &*q_p9.kind_p {
                        crate::syntax::PatternKind::PName(n_pa) => crate::prelude::Array::from(vec![(n_pa.clone(), ::std::option::Option::None, ::std::option::Option::None)]),
                        _ => crate::prelude::Array::new(),
                    }),
                    crate::syntax::PatternKind::PTuple(ps_pb) => crate::prelude::call_value(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(&ps_pb)), crate::prelude::Array::new(), {
                        let ps_pbx = ps_pb.clone();
                        let part_tys_p6x = part_tys_p6.clone();
                        ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<(crate::syntax::SName, ::std::option::Option<crate::prelude::Nat>, ::std::option::Option<(crate::syntax::Pattern, crate::check::types::Ty)>)>, crate::prelude::Nat)| {
                            let ps_pbxy = ps_pbx.clone();
                            let part_tys_p6xy = part_tys_p6x.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let acc_pc = p0;
                                let i_pd = p1;
                                match &*crate::prelude::or(&crate::prelude::index(&ps_pbxy, &i_pd), &crate::lower::patterns::dummy_pat_p()).kind_p {
                                    crate::syntax::PatternKind::PName(n_pe) => if is_time_name_f(&crate::check::env::sname_key_f(n_pe)) {
                                        ::prism_rtl::Turn::Finished(acc_pc.clone())
                                    } else {
                                        ::prism_rtl::Turn::Finished(crate::prelude::push(&acc_pc, &(n_pe.clone(), ::std::option::Option::Some(i_pd.clone()), ::std::option::Option::None)))
                                    },
                                    _ => {
                                        let part_ty_pf = crate::prelude::or(&crate::prelude::index(&part_tys_p6xy, &i_pd), &crate::check::types::Ty::TyErr);
                                        if crate::lower::types::is_bundle_f(&part_ty_pf) {
                                            ::prism_rtl::Turn::Finished(acc_pc.clone())
                                        } else {
                                            crate::prelude::call_then(start_binder_names_f(crate::prelude::or(&crate::prelude::index(&ps_pbxy, &i_pd), &crate::lower::patterns::dummy_pat_p())), move |binder_names_f_59258: crate::prelude::Array<crate::syntax::SName>| ::prism_rtl::Turn::Finished(crate::prelude::fold(&binder_names_f_59258, &acc_pc, &(|a_pg: &crate::prelude::Array<(crate::syntax::SName, ::std::option::Option<crate::prelude::Nat>, ::std::option::Option<(crate::syntax::Pattern, crate::check::types::Ty)>)>, n_ph: &crate::syntax::SName| if is_time_name_f(&crate::check::env::sname_key_f(n_ph)) {
                                                a_pg.clone()
                                            } else {
                                                crate::prelude::push(a_pg, &(n_ph.clone(), ::std::option::Option::Some(i_pd.clone()), ::std::option::Option::Some((crate::prelude::or(&crate::prelude::index(&ps_pbxy, &i_pd), &crate::lower::patterns::dummy_pat_p()), part_ty_pf.clone()))))
                                            }))))
                                        }
                                    },
                                }
                            }))
                        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<(crate::syntax::SName, ::std::option::Option<crate::prelude::Nat>, ::std::option::Option<(crate::syntax::Pattern, crate::check::types::Ty)>)>, crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<(crate::syntax::SName, ::std::option::Option<crate::prelude::Nat>, ::std::option::Option<(crate::syntax::Pattern, crate::check::types::Ty)>)>>>>
                    }), move |fold_58939: crate::prelude::Array<(crate::syntax::SName, ::std::option::Option<crate::prelude::Nat>, ::std::option::Option<(crate::syntax::Pattern, crate::check::types::Ty)>)>| k_let58428(fold_58939)),
                    _ => k_let58428(crate::prelude::Array::new()),
                }
            },
            _ => ::prism_rtl::Turn::Finished((wx_p0.clone(), benv_p1.clone(), menv_p2.clone(), crate::prelude::Array::new())),
        }
    }
}

/// `Start BindLate, x`: what the function value is when passed to `@Run`.
pub fn start_bind_late_f(wx_p0: crate::lower::node_::Wx, benv_p1: crate::lower::types::Env, menv_p2: crate::lower::types::Env, s_p3: crate::syntax::Stmt) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env, crate::prelude::Array<LateName>)>> {
    ::std::rc::Rc::new(BindLate { wx_p0, benv_p1, menv_p2, s_p3 })
}

/// ```prism
/// LateGetters: unbounded fn Wx, [LateName], Ex, [((Nat, Ex))] -> Wx
/// ```
pub fn late_getters_f(wx_p0: &crate::lower::node_::Wx, lates_p1: &crate::prelude::Array<LateName>, kept_p2: &crate::lower::model::Ex, part_reads_p3: &crate::prelude::Array<(crate::prelude::Nat, crate::lower::model::Ex)>) -> crate::lower::node_::Wx {
    crate::prelude::run_to_end(crate::prelude::fold_job(lates_p1.clone(), wx_p0.clone(), {
        let part_reads_p3x = part_reads_p3.clone();
        let kept_p2x = kept_p2.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::lower::node_::Wx, LateName)| {
            let part_reads_p3xy = part_reads_p3x.clone();
            let kept_p2xy = kept_p2x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let w_p4 = p0;
                let late_p5 = p1;
                {
                    let read_p6 = match &late_p5.part_o {
                        ::std::option::Option::Some(i_p8) => match part_read_o(&part_reads_p3xy, i_p8) {
                            ::std::option::Option::Some(read_p9) => read_p9,
                            ::std::option::Option::None => crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XPart(::std::rc::Rc::new(kept_p2xy.clone()), i_p8.clone()))),
                        },
                        ::std::option::Option::None => kept_p2xy.clone(),
                    };
                    let late_p5z = late_p5.clone();
                    let w_p4z = w_p4.clone();
                    let k_let61077 = move |v61077: crate::lower::model::Ex| {
                        let tail_p7 = v61077;
                        ::prism_rtl::Turn::Finished({
                            let mut this: crate::lower::node_::Wx = w_p4z.clone();
                            this.getters_p = crate::prelude::push(&this.getters_p, &crate::lower::model::MethDef { name_p: late_p5z.getter_p.clone(), recv_p: crate::lower::model::Recv::RecvRef, params_p: crate::prelude::Array::new(), cx_p: crate::lower::model::CxArg::CxNone, ret_p: late_p5z.ty_p.clone(), body_p: crate::prelude::Array::new(), tail_p: tail_p7.clone(), doc_p: crate::prelude::Text::lit("A late result, read once the row that gives it is built.") });
                            this
                        })
                    };
                    match late_p5.within_o.clone() {
                        ::std::option::Option::Some((q_pa, part_ty_pb)) => crate::prelude::call_then(crate::lower::patterns::start_rust_pat_f(w_p4.lx_p.clone(), q_pa.clone(), part_ty_pb.clone(), crate::lower::types::Holding::ByRef, crate::prelude::Text::lit("late_part")), move |rust_pat_f_61153: crate::lower::patterns::PatOut| {
                            let o_pc = rust_pat_f_61153;
                            let bound_od = crate::prelude::fold(&o_pc.binds_p, &::std::option::Option::None, &(|found_oe: &::std::option::Option<crate::lower::types::Bn>, (k_pf, b_pg): &(crate::prelude::Text, crate::lower::types::Bn)| if k_pf == &late_p5.name_p {
                                ::std::option::Option::Some(b_pg.clone())
                            } else {
                                found_oe.clone()
                            }));
                            match bound_od.clone() {
                                ::std::option::Option::Some(crate::lower::types::Bn::BnLocal(rs_ph, mode_pi, vt_pj)) => {
                                    let arm_pk = crate::lower::model::XArm { pat_p: o_pc.pa_p.clone(), conds_p: o_pc.conds_p.clone(), body_p: crate::lower::types::own_f(&crate::lower::types::Vl::VlPlace(rs_ph.clone(), mode_pi.clone(), vt_pj.clone())) };
                                    let other_pl = crate::lower::model::XArm { pat_p: crate::lower::model::Pa::PaWild, conds_p: crate::prelude::Array::new(), body_p: crate::lower::model::Ex::XUnreachable };
                                    crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(w_p4.lx_p.clone(), crate::lower::types::peel_f(&part_ty_pb)), move |out_ty_of_f_61610: crate::lower::model::OutTy| k_let61077(crate::lower::model::Ex::XBlock(crate::prelude::Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("late_part"))), out_ty_of_f_61610), read_p6.clone())]), ::std::rc::Rc::new(crate::lower::types::own_f(&crate::lower::expr::arms_value_f(&crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("late_part")))), &crate::prelude::Array::from(vec![arm_pk.clone(), other_pl.clone()]), &crate::prelude::Text::lit("\'bound"), &late_p5.ty_p))))))
                                },
                                _ => k_let61077(crate::lower::expr::internal_bug_f(&crate::prelude::Text::from(format!("the late name `{}`, which the pattern of its part does not bind", &late_p5.name_p)))),
                            }
                        }),
                        ::std::option::Option::None => k_let61077(read_p6.clone()),
                    }
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::node_::Wx, LateName)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::node_::Wx>>>
    }))
}

/// The step machine of `LateGetters`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LateGetters: unbounded fn Wx, [LateName], Ex, [((Nat, Ex))] -> Wx
/// ```
pub struct LateGetters {
    pub wx_p0: crate::lower::node_::Wx,
    pub lates_p1: crate::prelude::Array<LateName>,
    pub kept_p2: crate::lower::model::Ex,
    pub part_reads_p3: crate::prelude::Array<(crate::prelude::Nat, crate::lower::model::Ex)>,
}

impl ::prism_rtl::Job<crate::lower::node_::Wx> for LateGetters {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::lower::node_::Wx> {
        let wx_p0 = &self.wx_p0;
        let lates_p1 = &self.lates_p1;
        let kept_p2 = &self.kept_p2;
        let part_reads_p3 = &self.part_reads_p3;
        crate::prelude::fold_job(lates_p1.clone(), wx_p0.clone(), {
            let part_reads_p3x = part_reads_p3.clone();
            let kept_p2x = kept_p2.clone();
            ::std::rc::Rc::new(move |(p0, p1): (crate::lower::node_::Wx, LateName)| {
                let part_reads_p3xy = part_reads_p3x.clone();
                let kept_p2xy = kept_p2x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let w_p4 = p0;
                    let late_p5 = p1;
                    {
                        let read_p6 = match &late_p5.part_o {
                            ::std::option::Option::Some(i_p8) => match part_read_o(&part_reads_p3xy, i_p8) {
                                ::std::option::Option::Some(read_p9) => read_p9,
                                ::std::option::Option::None => crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XPart(::std::rc::Rc::new(kept_p2xy.clone()), i_p8.clone()))),
                            },
                            ::std::option::Option::None => kept_p2xy.clone(),
                        };
                        let late_p5z = late_p5.clone();
                        let w_p4z = w_p4.clone();
                        let k_let61077 = move |v61077: crate::lower::model::Ex| {
                            let tail_p7 = v61077;
                            ::prism_rtl::Turn::Finished({
                                let mut this: crate::lower::node_::Wx = w_p4z.clone();
                                this.getters_p = crate::prelude::push(&this.getters_p, &crate::lower::model::MethDef { name_p: late_p5z.getter_p.clone(), recv_p: crate::lower::model::Recv::RecvRef, params_p: crate::prelude::Array::new(), cx_p: crate::lower::model::CxArg::CxNone, ret_p: late_p5z.ty_p.clone(), body_p: crate::prelude::Array::new(), tail_p: tail_p7.clone(), doc_p: crate::prelude::Text::lit("A late result, read once the row that gives it is built.") });
                                this
                            })
                        };
                        match late_p5.within_o.clone() {
                            ::std::option::Option::Some((q_pa, part_ty_pb)) => crate::prelude::call_then(crate::lower::patterns::start_rust_pat_f(w_p4.lx_p.clone(), q_pa.clone(), part_ty_pb.clone(), crate::lower::types::Holding::ByRef, crate::prelude::Text::lit("late_part")), move |rust_pat_f_61153: crate::lower::patterns::PatOut| {
                                let o_pc = rust_pat_f_61153;
                                let bound_od = crate::prelude::fold(&o_pc.binds_p, &::std::option::Option::None, &(|found_oe: &::std::option::Option<crate::lower::types::Bn>, (k_pf, b_pg): &(crate::prelude::Text, crate::lower::types::Bn)| if k_pf == &late_p5.name_p {
                                    ::std::option::Option::Some(b_pg.clone())
                                } else {
                                    found_oe.clone()
                                }));
                                match bound_od.clone() {
                                    ::std::option::Option::Some(crate::lower::types::Bn::BnLocal(rs_ph, mode_pi, vt_pj)) => {
                                        let arm_pk = crate::lower::model::XArm { pat_p: o_pc.pa_p.clone(), conds_p: o_pc.conds_p.clone(), body_p: crate::lower::types::own_f(&crate::lower::types::Vl::VlPlace(rs_ph.clone(), mode_pi.clone(), vt_pj.clone())) };
                                        let other_pl = crate::lower::model::XArm { pat_p: crate::lower::model::Pa::PaWild, conds_p: crate::prelude::Array::new(), body_p: crate::lower::model::Ex::XUnreachable };
                                        crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(w_p4.lx_p.clone(), crate::lower::types::peel_f(&part_ty_pb)), move |out_ty_of_f_61610: crate::lower::model::OutTy| k_let61077(crate::lower::model::Ex::XBlock(crate::prelude::Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("late_part"))), out_ty_of_f_61610), read_p6.clone())]), ::std::rc::Rc::new(crate::lower::types::own_f(&crate::lower::expr::arms_value_f(&crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("late_part")))), &crate::prelude::Array::from(vec![arm_pk.clone(), other_pl.clone()]), &crate::prelude::Text::lit("\'bound"), &late_p5.ty_p))))))
                                    },
                                    _ => k_let61077(crate::lower::expr::internal_bug_f(&crate::prelude::Text::from(format!("the late name `{}`, which the pattern of its part does not bind", &late_p5.name_p)))),
                                }
                            }),
                            ::std::option::Option::None => k_let61077(read_p6.clone()),
                        }
                    }
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::node_::Wx, LateName)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::node_::Wx>>>
        }).cycle()
    }
}

/// `Start LateGetters, x`: what the function value is when passed to `@Run`.
pub fn start_late_getters_f(wx_p0: crate::lower::node_::Wx, lates_p1: crate::prelude::Array<LateName>, kept_p2: crate::lower::model::Ex, part_reads_p3: crate::prelude::Array<(crate::prelude::Nat, crate::lower::model::Ex)>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::node_::Wx>> {
    ::std::rc::Rc::new(LateGetters { wx_p0, lates_p1, kept_p2, part_reads_p3 })
}

/// ```prism
/// WithLateInits: fn Wx, [Do] -> Wx
/// ```
pub fn with_late_inits_f(wx_p0: &crate::lower::node_::Wx, sets_p1: &crate::prelude::Array<crate::lower::model::Do>) -> crate::lower::node_::Wx {
    if &crate::prelude::len(sets_p1) == &crate::prelude::Nat::from(0u32) {
        wx_p0.clone()
    } else {
        match crate::prelude::index(&wx_p0.gens_p, &crate::syntax::lexer::chars::dec_f(&crate::prelude::len(&wx_p0.gens_p))) {
            ::std::option::Option::Some(gd_p2) => {
                let gd2_p3 = {
                    let mut this: crate::lower::model::GenDef = gd_p2.clone();
                    this.select_p = crate::lower::model::Ex::XBlock(crate::prelude::append(&crate::prelude::Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("row")), gd_p2.select_p.clone())]), sets_p1), ::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("row"))));
                    this
                };
                {
                    let mut this: crate::lower::node_::Wx = wx_p0.clone();
                    this.gens_p = crate::prelude::push(&crate::prelude::take(&this.gens_p, &crate::syntax::lexer::chars::dec_f(&crate::prelude::len(&this.gens_p))), &gd2_p3);
                    this
                }
            },
            ::std::option::Option::None => {
                let mut this: crate::lower::node_::Wx = wx_p0.clone();
                this.build_p = crate::prelude::push(&this.build_p, &crate::lower::expr::internal_bug_do_f(&crate::prelude::Text::lit("a late result with no generation that gives it")));
                this
            },
        }
    }
}

/// ```prism
/// ReadsLate: unbounded fn Env, Expr -> Bool
/// ```
pub fn reads_late_f(env_p0: &crate::lower::types::Env, e_p1: &crate::syntax::Expr) -> bool {
    reads_late_via_f(env_p0, env_p0, e_p1)
}

/// The step machine of `ReadsLate`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ReadsLate: unbounded fn Env, Expr -> Bool
/// ```
pub struct ReadsLate {
    pub env_p0: crate::lower::types::Env,
    pub e_p1: crate::syntax::Expr,
}

impl ::prism_rtl::Job<bool> for ReadsLate {
    fn cycle(&self) -> ::prism_rtl::Turn<bool> {
        let env_p0 = &self.env_p0;
        let e_p1 = &self.e_p1;
        ::prism_rtl::Turn::Finished(reads_late_via_f(env_p0, env_p0, e_p1))
    }
}

/// `Start ReadsLate, x`: what the function value is when passed to `@Run`.
pub fn start_reads_late_f(env_p0: crate::lower::types::Env, e_p1: crate::syntax::Expr) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>> {
    ::std::rc::Rc::new(ReadsLate { env_p0, e_p1 })
}

/// ```prism
/// ReadsLateVia: unbounded fn Env, Env, Expr -> Bool
/// ```
pub fn reads_late_via_f(fns_p0: &crate::lower::types::Env, env_p1: &crate::lower::types::Env, e_p2: &crate::syntax::Expr) -> bool {
    crate::prelude::fold(&crate::lower::node_::switch_::row_names_closed_f(fns_p0, &crate::lower::expr::free_reads_f(&crate::check::typed::print::exprs_in_f(e_p2), &crate::prelude::Array::new())), &false, &(|f_p3: &bool, n_p4: &crate::prelude::Text| *f_p3 || crate::check::env::has_key_f(&env_p1.names_p, &crate::prelude::Text::from(format!("{}#late", n_p4)))))
}

/// ```prism
/// IsFnLine: fn Stmt -> Bool
/// ```
pub fn is_fn_line_f(s_p0: &crate::syntax::Stmt) -> bool {
    match &s_p0.kind_p {
        crate::syntax::StmtKind::SFn(_) => true,
        _ => false,
    }
}

/// ```prism
/// MarkLateLets: unbounded fn Wx, Env, Env, Env, [Stmt], Nat -> ((Wx, Env, Env))
/// ```
pub fn mark_late_lets_f(wx_p0: &crate::lower::node_::Wx, benv_p1: &crate::lower::types::Env, menv_p2: &crate::lower::types::Env, fns_p3: &crate::lower::types::Env, stmts_p4: &crate::prelude::Array<crate::syntax::Stmt>, fuel_p5: &crate::prelude::Nat) -> (crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env) {
    let (wx2_pn, be2_po, me2_pp, grew_pq) = crate::prelude::run_to_end(crate::prelude::fold_job(stmts_p4.clone(), (wx_p0.clone(), benv_p1.clone(), menv_p2.clone(), false), {
        let fns_p3x = fns_p3.clone();
        ::std::rc::Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env, bool), crate::syntax::Stmt)| {
            let fns_p3xy = fns_p3x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (w_p6, be_p7, me_p8, ch_p9) = p0;
                let s_pa = p1;
                crate::prelude::call_then(start_is_late_bundle_stmt_f(w_p6.lx_p.clone(), fns_p3xy.clone(), me_p8.clone(), s_pa.clone()), move |is_late_bundle_stmt_f_64636: bool| if is_late_bundle_stmt_f_64636 {
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(MarkLateBundle { wx_p0: w_p6.clone(), be_p1: be_p7.clone(), me_p2: me_p8.clone(), s_p3: s_pa.clone() }))
                } else {
                    crate::prelude::call_then(start_late_let_names_f(w_p6.lx_p.clone(), fns_p3xy.clone(), me_p8.clone(), s_pa.clone()), move |late_let_names_f_64721: crate::prelude::Array<crate::syntax::SName>| crate::prelude::call_then(start_late_part_names_f(me_p8.clone(), s_pa.clone()), move |late_part_names_f_64754: crate::prelude::Array<crate::syntax::SName>| crate::prelude::fold_job(crate::prelude::append(&late_let_names_f_64721, &late_part_names_f_64754), (w_p6.clone(), be_p7.clone(), me_p8.clone(), ch_p9), {
                        let s_pax = s_pa.clone();
                        let fns_p3xyx = fns_p3xy.clone();
                        let me_p8x = me_p8.clone();
                        ::std::rc::Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env, bool), crate::syntax::SName)| {
                            let s_paxy = s_pax.clone();
                            let fns_p3xyxy = fns_p3xyx.clone();
                            let me_p8xy = me_p8x.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let (w1_pb, be1_pc, me1_pd, _) = p0;
                                let n_pe = p1;
                                {
                                    let nkey_pf = crate::check::env::sname_key_f(&n_pe);
                                    crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(w1_pb.lx_p.clone(), crate::lower::types::peel_f(&crate::lower::binder_ty_f(&w1_pb.lx_p, &n_pe.span_p))), move |out_ty_of_f_64873: crate::lower::model::OutTy| {
                                        let t_pg = out_ty_of_f_64873;
                                        crate::prelude::call_then(crate::lower::start_local_name_at_f(w1_pb.lx_p.clone(), nkey_pf.clone(), n_pe.span_p.clone()), move |local_name_at_f_64970: crate::prelude::Text| {
                                            let (getter_pk, w2_pl) = crate::lower::node_::fresh_name_f(&w1_pb, &crate::prelude::Text::from(format!("late_{}", &local_name_at_f_64970)));
                                            let unbuilt_ph = crate::lower::types::Bn::BnLocal(crate::lower::expr::refusal_f(&crate::prelude::Text::from(format!("the late `let` `{}` read at its block\'s build by a line of the block\'s node that takes a value there (a widget\'s plain argument, a builder\'s plain local)", &nkey_pf))), crate::lower::types::Holding::Owned, t_pg.clone());
                                            let me3_pi = crate::lower::types::bind_f(&crate::lower::types::bind_f(&me1_pd, &nkey_pf, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), getter_pk.clone(), crate::prelude::Array::new()), crate::lower::types::Holding::Owned, t_pg.clone())), &crate::prelude::Text::from(format!("{}#late", &nkey_pf)), &unbuilt_ph);
                                            let be1_pcz = be1_pc.clone();
                                            let me3_piz = me3_pi.clone();
                                            let nkey_pfz = nkey_pf.clone();
                                            let unbuilt_phz = unbuilt_ph.clone();
                                            let w2_plz = w2_pl.clone();
                                            let k_let65498 = move |v65498: bool| {
                                                let of_places_pj = v65498;
                                                ::prism_rtl::Turn::Finished((w2_plz.clone(), crate::lower::types::bind_f(&crate::lower::types::bind_f(&be1_pcz, &nkey_pfz, &unbuilt_phz), &crate::prelude::Text::from(format!("{}#late", &nkey_pfz)), &unbuilt_phz), if of_places_pj {
                                                    crate::lower::types::bind_f(&me3_piz, &crate::prelude::Text::from(format!("{}#lateplace", &nkey_pfz)), &unbuilt_phz)
                                                } else {
                                                    me3_piz.clone()
                                                }, true))
                                            };
                                            match s_paxy.kind_p.clone() {
                                                crate::syntax::StmtKind::SLet(_, _, e_pm) => crate::prelude::call_then(start_reads_late_of_places_f(fns_p3xyxy.clone(), me_p8xy.clone(), e_pm.clone()), move |reads_late_of_places_f_65563: bool| k_let65498(reads_late_of_places_f_65563)),
                                                _ => k_let65498(false),
                                            }
                                        })
                                    })
                                }
                            }))
                        }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env, bool), crate::syntax::SName)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env, bool)>>>
                    }).cycle()))
                })
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env, bool), crate::syntax::Stmt)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env, bool)>>>
    }));
    let (wx3p_p10, be3p_p11, me3p_p12, grew3p_p13) = crate::prelude::run_to_end(crate::prelude::fold_job(stmts_p4.clone(), (wx2_pn.clone(), be2_po.clone(), me2_pp.clone(), grew_pq), {
        let fns_p3x = fns_p3.clone();
        ::std::rc::Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env, bool), crate::syntax::Stmt)| {
            let fns_p3xy = fns_p3x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (w_pr, be_ps, me_pt, ch_pu) = p0;
                let s_pv = p1;
                ::prism_rtl::Turn::More(::std::rc::Rc::new(LateFieldPlaces { wx_p0: w_pr.clone(), benv_p1: be_ps.clone(), menv_p2: me_pt.clone(), fns_p3: fns_p3xy.clone(), s_p4: s_pv.clone(), grew_p5: ch_pu }))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env, bool), crate::syntax::Stmt)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env, bool)>>>
    }));
    let (wx3_p19, be3_p1a, me3_p1b, grew3_p1c) = crate::prelude::run_to_end(crate::prelude::fold_job(stmts_p4.clone(), (wx3p_p10.clone(), be3p_p11.clone(), me3p_p12.clone(), grew3p_p13), {
        let fns_p3x = fns_p3.clone();
        ::std::rc::Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env, bool), crate::syntax::Stmt)| {
            let fns_p3xy = fns_p3x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (w_p14, be_p15, me_p16, ch_p17) = p0;
                let s_p18 = p1;
                ::prism_rtl::Turn::More(::std::rc::Rc::new(LateTakerResults { wx_p0: w_p14.clone(), benv_p1: be_p15.clone(), menv_p2: me_p16.clone(), fns_p3: fns_p3xy.clone(), s_p4: s_p18.clone(), grew_p5: ch_p17 }))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env, bool), crate::syntax::Stmt)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env, bool)>>>
    }));
    if grew3_p1c && (fuel_p5 > &crate::prelude::Nat::from(0u32)) {
        mark_late_lets_f(&wx3_p19, &be3_p1a, &me3_p1b, fns_p3, stmts_p4, &crate::syntax::lexer::chars::dec_f(fuel_p5))
    } else {
        (wx3_p19.clone(), be3_p1a.clone(), me3_p1b.clone())
    }
}

/// The step machine of `MarkLateLets`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// MarkLateLets: unbounded fn Wx, Env, Env, Env, [Stmt], Nat -> ((Wx, Env, Env))
/// ```
pub struct MarkLateLets {
    pub wx_p0: crate::lower::node_::Wx,
    pub benv_p1: crate::lower::types::Env,
    pub menv_p2: crate::lower::types::Env,
    pub fns_p3: crate::lower::types::Env,
    pub stmts_p4: crate::prelude::Array<crate::syntax::Stmt>,
    pub fuel_p5: crate::prelude::Nat,
}

impl ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)> for MarkLateLets {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)> {
        let wx_p0 = &self.wx_p0;
        let benv_p1 = &self.benv_p1;
        let menv_p2 = &self.menv_p2;
        let fns_p3 = &self.fns_p3;
        let stmts_p4 = &self.stmts_p4;
        let fuel_p5 = &self.fuel_p5;
        let benv_p1x = benv_p1.clone();
        let fns_p3x = fns_p3.clone();
        let fuel_p5x = fuel_p5.clone();
        let menv_p2x = menv_p2.clone();
        let stmts_p4x = stmts_p4.clone();
        let wx_p0x = wx_p0.clone();
        crate::prelude::call_value(crate::prelude::fold_job(stmts_p4x.clone(), (wx_p0x.clone(), benv_p1x.clone(), menv_p2x.clone(), false), {
            let fns_p3xx = fns_p3x.clone();
            ::std::rc::Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env, bool), crate::syntax::Stmt)| {
                let fns_p3xxy = fns_p3xx.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let (w_p6, be_p7, me_p8, ch_p9) = p0;
                    let s_pa = p1;
                    crate::prelude::call_then(start_is_late_bundle_stmt_f(w_p6.lx_p.clone(), fns_p3xxy.clone(), me_p8.clone(), s_pa.clone()), move |is_late_bundle_stmt_f_64636: bool| if is_late_bundle_stmt_f_64636 {
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(MarkLateBundle { wx_p0: w_p6.clone(), be_p1: be_p7.clone(), me_p2: me_p8.clone(), s_p3: s_pa.clone() }))
                    } else {
                        crate::prelude::call_then(start_late_let_names_f(w_p6.lx_p.clone(), fns_p3xxy.clone(), me_p8.clone(), s_pa.clone()), move |late_let_names_f_64721: crate::prelude::Array<crate::syntax::SName>| crate::prelude::call_then(start_late_part_names_f(me_p8.clone(), s_pa.clone()), move |late_part_names_f_64754: crate::prelude::Array<crate::syntax::SName>| crate::prelude::fold_job(crate::prelude::append(&late_let_names_f_64721, &late_part_names_f_64754), (w_p6.clone(), be_p7.clone(), me_p8.clone(), ch_p9), {
                            let s_pax = s_pa.clone();
                            let fns_p3xxyx = fns_p3xxy.clone();
                            let me_p8x = me_p8.clone();
                            ::std::rc::Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env, bool), crate::syntax::SName)| {
                                let s_paxy = s_pax.clone();
                                let fns_p3xxyxy = fns_p3xxyx.clone();
                                let me_p8xy = me_p8x.clone();
                                crate::prelude::entered(crate::prelude::once_job(move || {
                                    let (w1_pb, be1_pc, me1_pd, _) = p0;
                                    let n_pe = p1;
                                    {
                                        let nkey_pf = crate::check::env::sname_key_f(&n_pe);
                                        crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(w1_pb.lx_p.clone(), crate::lower::types::peel_f(&crate::lower::binder_ty_f(&w1_pb.lx_p, &n_pe.span_p))), move |out_ty_of_f_64873: crate::lower::model::OutTy| {
                                            let t_pg = out_ty_of_f_64873;
                                            crate::prelude::call_then(crate::lower::start_local_name_at_f(w1_pb.lx_p.clone(), nkey_pf.clone(), n_pe.span_p.clone()), move |local_name_at_f_64970: crate::prelude::Text| {
                                                let (getter_pk, w2_pl) = crate::lower::node_::fresh_name_f(&w1_pb, &crate::prelude::Text::from(format!("late_{}", &local_name_at_f_64970)));
                                                let unbuilt_ph = crate::lower::types::Bn::BnLocal(crate::lower::expr::refusal_f(&crate::prelude::Text::from(format!("the late `let` `{}` read at its block\'s build by a line of the block\'s node that takes a value there (a widget\'s plain argument, a builder\'s plain local)", &nkey_pf))), crate::lower::types::Holding::Owned, t_pg.clone());
                                                let me3_pi = crate::lower::types::bind_f(&crate::lower::types::bind_f(&me1_pd, &nkey_pf, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), getter_pk.clone(), crate::prelude::Array::new()), crate::lower::types::Holding::Owned, t_pg.clone())), &crate::prelude::Text::from(format!("{}#late", &nkey_pf)), &unbuilt_ph);
                                                let be1_pcz = be1_pc.clone();
                                                let me3_piz = me3_pi.clone();
                                                let nkey_pfz = nkey_pf.clone();
                                                let unbuilt_phz = unbuilt_ph.clone();
                                                let w2_plz = w2_pl.clone();
                                                let k_let65498 = move |v65498: bool| {
                                                    let of_places_pj = v65498;
                                                    ::prism_rtl::Turn::Finished((w2_plz.clone(), crate::lower::types::bind_f(&crate::lower::types::bind_f(&be1_pcz, &nkey_pfz, &unbuilt_phz), &crate::prelude::Text::from(format!("{}#late", &nkey_pfz)), &unbuilt_phz), if of_places_pj {
                                                        crate::lower::types::bind_f(&me3_piz, &crate::prelude::Text::from(format!("{}#lateplace", &nkey_pfz)), &unbuilt_phz)
                                                    } else {
                                                        me3_piz.clone()
                                                    }, true))
                                                };
                                                match s_paxy.kind_p.clone() {
                                                    crate::syntax::StmtKind::SLet(_, _, e_pm) => crate::prelude::call_then(start_reads_late_of_places_f(fns_p3xxyxy.clone(), me_p8xy.clone(), e_pm.clone()), move |reads_late_of_places_f_65563: bool| k_let65498(reads_late_of_places_f_65563)),
                                                    _ => k_let65498(false),
                                                }
                                            })
                                        })
                                    }
                                }))
                            }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env, bool), crate::syntax::SName)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env, bool)>>>
                        }).cycle()))
                    })
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env, bool), crate::syntax::Stmt)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env, bool)>>>
        }), move |fold_64570: (crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env, bool)| {
            let (wx2_pn, be2_po, me2_pp, grew_pq) = fold_64570;
            crate::prelude::call_value(crate::prelude::fold_job(stmts_p4x.clone(), (wx2_pn.clone(), be2_po.clone(), me2_pp.clone(), grew_pq), {
                let fns_p3xx = fns_p3x.clone();
                ::std::rc::Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env, bool), crate::syntax::Stmt)| {
                    let fns_p3xxy = fns_p3xx.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let (w_pr, be_ps, me_pt, ch_pu) = p0;
                        let s_pv = p1;
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(LateFieldPlaces { wx_p0: w_pr.clone(), benv_p1: be_ps.clone(), menv_p2: me_pt.clone(), fns_p3: fns_p3xxy.clone(), s_p4: s_pv.clone(), grew_p5: ch_pu }))
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env, bool), crate::syntax::Stmt)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env, bool)>>>
            }), move |fold_65942: (crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env, bool)| {
                let (wx3p_p10, be3p_p11, me3p_p12, grew3p_p13) = fold_65942;
                crate::prelude::call_value(crate::prelude::fold_job(stmts_p4x.clone(), (wx3p_p10.clone(), be3p_p11.clone(), me3p_p12.clone(), grew3p_p13), {
                    let fns_p3xx = fns_p3x.clone();
                    ::std::rc::Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env, bool), crate::syntax::Stmt)| {
                        let fns_p3xxy = fns_p3xx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let (w_p14, be_p15, me_p16, ch_p17) = p0;
                            let s_p18 = p1;
                            ::prism_rtl::Turn::More(::std::rc::Rc::new(LateTakerResults { wx_p0: w_p14.clone(), benv_p1: be_p15.clone(), menv_p2: me_p16.clone(), fns_p3: fns_p3xxy.clone(), s_p4: s_p18.clone(), grew_p5: ch_p17 }))
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env, bool), crate::syntax::Stmt)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env, bool)>>>
                }), move |fold_66217: (crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env, bool)| {
                    let (wx3_p19, be3_p1a, me3_p1b, grew3_p1c) = fold_66217;
                    if grew3_p1c && (&fuel_p5x > &crate::prelude::Nat::from(0u32)) {
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(MarkLateLets { wx_p0: wx3_p19.clone(), benv_p1: be3_p1a.clone(), menv_p2: me3_p1b.clone(), fns_p3: fns_p3x.clone(), stmts_p4: stmts_p4x.clone(), fuel_p5: crate::syntax::lexer::chars::dec_f(&fuel_p5x) }))
                    } else {
                        ::prism_rtl::Turn::Finished((wx3_p19.clone(), be3_p1a.clone(), me3_p1b.clone()))
                    }
                })
            })
        })
    }
}

/// `Start MarkLateLets, x`: what the function value is when passed to `@Run`.
pub fn start_mark_late_lets_f(wx_p0: crate::lower::node_::Wx, benv_p1: crate::lower::types::Env, menv_p2: crate::lower::types::Env, fns_p3: crate::lower::types::Env, stmts_p4: crate::prelude::Array<crate::syntax::Stmt>, fuel_p5: crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>> {
    ::std::rc::Rc::new(MarkLateLets { wx_p0, benv_p1, menv_p2, fns_p3, stmts_p4, fuel_p5 })
}

/// ```prism
/// LateTakerResults: unbounded fn Wx, Env, Env, Env, Stmt, Bool -> ((Wx, Env, Env, Bool))
/// ```
pub fn late_taker_results_f(wx_p0: &crate::lower::node_::Wx, benv_p1: &crate::lower::types::Env, menv_p2: &crate::lower::types::Env, fns_p3: &crate::lower::types::Env, s_p4: &crate::syntax::Stmt, grew_p5: &bool) -> (crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env, bool) {
    match &s_p4.kind_p {
        crate::syntax::StmtKind::SBind(p_p6, e_p7, ::std::option::Option::None) => match &*p_p6.kind_p {
            crate::syntax::PatternKind::PName(n_p8) => {
                let nkey_p9 = crate::check::env::sname_key_f(n_p8);
                let lx_pa = crate::lower::expr::widget_let_lx_f(&wx_p0.lx_p, &n_p8.span_p);
                let full_pb = crate::lower::binder_ty_f(&lx_pa, &n_p8.span_p);
                let placed_pc = match crate::lower::types::peel_f(&crate::lower::type_at_f(&wx_p0.lx_p, &crate::lower::node_::static_::ungrouped_f(e_p7).span_p)) {
                    crate::check::types::Ty::TyElem(_, _) => true,
                    _ => false,
                };
                if (((((((placed_pc || is_time_name_f(&nkey_p9)) || crate::check::env::has_key_f(&menv_p2.names_p, &crate::prelude::Text::from(format!("{}#late", &nkey_p9)))) || (&crate::lower::types::layer_of_f(&full_pb) != &crate::lower::types::Layer::LyPlain)) || crate::lower::types::time_within_f(&full_pb)) || crate::lower::types::is_bundle_f(&full_pb)) || crate::lower::types::is_bundle_f(&line_out_full_f(&wx_p0.lx_p, e_p7))) || !is_plain_result_f(&wx_p0.lx_p, e_p7)) || !reads_late_via_f(fns_p3, menv_p2, e_p7) {
                    (wx_p0.clone(), benv_p1.clone(), menv_p2.clone(), *grew_p5)
                } else {
                    {
                        let t_pd = crate::lower::types::out_ty_of_f(&lx_pa, &crate::lower::types::peel_f(&full_pb));
                        let (getter_pg, w2_ph) = crate::lower::node_::fresh_name_f(wx_p0, &crate::prelude::Text::from(format!("late_{}", &crate::lower::local_name_at_f(&lx_pa, &nkey_p9, &n_p8.span_p))));
                        let unbuilt_pe = crate::lower::types::Bn::BnLocal(crate::lower::expr::refusal_f(&crate::prelude::Text::from(format!("the late result `{}` of a line that takes a late name, read at its block\'s build by a line of the block\'s node that takes a value there", &nkey_p9))), crate::lower::types::Holding::Owned, t_pd.clone());
                        let me2_pf = crate::lower::types::bind_f(&crate::lower::types::bind_f(&crate::lower::types::bind_f(menv_p2, &nkey_p9, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), getter_pg.clone(), crate::prelude::Array::new()), crate::lower::types::Holding::Owned, t_pd.clone())), &crate::prelude::Text::from(format!("{}#late", &nkey_p9)), &unbuilt_pe), &crate::prelude::Text::from(format!("{}#taker", &nkey_p9)), &unbuilt_pe);
                        (w2_ph.clone(), crate::lower::types::bind_f(&crate::lower::types::bind_f(benv_p1, &nkey_p9, &unbuilt_pe), &crate::prelude::Text::from(format!("{}#late", &nkey_p9)), &unbuilt_pe), me2_pf.clone(), true)
                    }
                }
            },
            _ => (wx_p0.clone(), benv_p1.clone(), menv_p2.clone(), *grew_p5),
        },
        _ => (wx_p0.clone(), benv_p1.clone(), menv_p2.clone(), *grew_p5),
    }
}

/// The step machine of `LateTakerResults`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LateTakerResults: unbounded fn Wx, Env, Env, Env, Stmt, Bool -> ((Wx, Env, Env, Bool))
/// ```
pub struct LateTakerResults {
    pub wx_p0: crate::lower::node_::Wx,
    pub benv_p1: crate::lower::types::Env,
    pub menv_p2: crate::lower::types::Env,
    pub fns_p3: crate::lower::types::Env,
    pub s_p4: crate::syntax::Stmt,
    pub grew_p5: bool,
}

impl ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env, bool)> for LateTakerResults {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env, bool)> {
        let wx_p0 = &self.wx_p0;
        let benv_p1 = &self.benv_p1;
        let menv_p2 = &self.menv_p2;
        let fns_p3 = &self.fns_p3;
        let s_p4 = &self.s_p4;
        let grew_p5 = &self.grew_p5;
        match &s_p4.kind_p {
            crate::syntax::StmtKind::SBind(p_p6, e_p7, ::std::option::Option::None) => match &*p_p6.kind_p {
                crate::syntax::PatternKind::PName(n_p8) => {
                    let nkey_p9 = crate::check::env::sname_key_f(n_p8);
                    let benv_p1x = benv_p1.clone();
                    let e_p7x = e_p7.clone();
                    let fns_p3x = fns_p3.clone();
                    let grew_p5x = *grew_p5;
                    let menv_p2x = menv_p2.clone();
                    let n_p8x = n_p8.clone();
                    let wx_p0x = wx_p0.clone();
                    crate::prelude::call_then(crate::lower::expr::start_widget_let_lx_f(wx_p0x.lx_p.clone(), n_p8x.span_p.clone()), move |widget_let_lx_f_67609: crate::lower::Lx| {
                        let lx_pa = widget_let_lx_f_67609;
                        let full_pb = crate::lower::binder_ty_f(&lx_pa, &n_p8x.span_p);
                        let placed_pc = match crate::lower::types::peel_f(&crate::lower::type_at_f(&wx_p0x.lx_p, &crate::lower::node_::static_::ungrouped_f(&e_p7x).span_p)) {
                            crate::check::types::Ty::TyElem(_, _) => true,
                            _ => false,
                        };
                        if (((((((placed_pc || is_time_name_f(&nkey_p9)) || crate::check::env::has_key_f(&menv_p2x.names_p, &crate::prelude::Text::from(format!("{}#late", &nkey_p9)))) || (&crate::lower::types::layer_of_f(&full_pb) != &crate::lower::types::Layer::LyPlain)) || crate::lower::types::time_within_f(&full_pb)) || crate::lower::types::is_bundle_f(&full_pb)) || crate::lower::types::is_bundle_f(&line_out_full_f(&wx_p0x.lx_p, &e_p7x))) || !is_plain_result_f(&wx_p0x.lx_p, &e_p7x)) || !reads_late_via_f(&fns_p3x, &menv_p2x, &e_p7x) {
                            ::prism_rtl::Turn::Finished((wx_p0x.clone(), benv_p1x.clone(), menv_p2x.clone(), grew_p5x))
                        } else {
                            crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_pa.clone(), crate::lower::types::peel_f(&full_pb)), move |out_ty_of_f_68151: crate::lower::model::OutTy| {
                                let t_pd = out_ty_of_f_68151;
                                crate::prelude::call_then(crate::lower::start_local_name_at_f(lx_pa.clone(), nkey_p9.clone(), n_p8x.span_p.clone()), move |local_name_at_f_68233: crate::prelude::Text| {
                                    let (getter_pg, w2_ph) = crate::lower::node_::fresh_name_f(&wx_p0x, &crate::prelude::Text::from(format!("late_{}", &local_name_at_f_68233)));
                                    let unbuilt_pe = crate::lower::types::Bn::BnLocal(crate::lower::expr::refusal_f(&crate::prelude::Text::from(format!("the late result `{}` of a line that takes a late name, read at its block\'s build by a line of the block\'s node that takes a value there", &nkey_p9))), crate::lower::types::Holding::Owned, t_pd.clone());
                                    let me2_pf = crate::lower::types::bind_f(&crate::lower::types::bind_f(&crate::lower::types::bind_f(&menv_p2x, &nkey_p9, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), getter_pg.clone(), crate::prelude::Array::new()), crate::lower::types::Holding::Owned, t_pd.clone())), &crate::prelude::Text::from(format!("{}#late", &nkey_p9)), &unbuilt_pe), &crate::prelude::Text::from(format!("{}#taker", &nkey_p9)), &unbuilt_pe);
                                    ::prism_rtl::Turn::Finished((w2_ph.clone(), crate::lower::types::bind_f(&crate::lower::types::bind_f(&benv_p1x, &nkey_p9, &unbuilt_pe), &crate::prelude::Text::from(format!("{}#late", &nkey_p9)), &unbuilt_pe), me2_pf.clone(), true))
                                })
                            })
                        }
                    })
                },
                _ => ::prism_rtl::Turn::Finished((wx_p0.clone(), benv_p1.clone(), menv_p2.clone(), *grew_p5)),
            },
            _ => ::prism_rtl::Turn::Finished((wx_p0.clone(), benv_p1.clone(), menv_p2.clone(), *grew_p5)),
        }
    }
}

/// `Start LateTakerResults, x`: what the function value is when passed to `@Run`.
pub fn start_late_taker_results_f(wx_p0: crate::lower::node_::Wx, benv_p1: crate::lower::types::Env, menv_p2: crate::lower::types::Env, fns_p3: crate::lower::types::Env, s_p4: crate::syntax::Stmt, grew_p5: bool) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env, bool)>> {
    ::std::rc::Rc::new(LateTakerResults { wx_p0, benv_p1, menv_p2, fns_p3, s_p4, grew_p5 })
}

/// ```prism
/// ?TakerGetter: fn Env, Pattern -> ?Text
/// ```
pub fn taker_getter_o(menv_p0: &crate::lower::types::Env, p_p1: &crate::syntax::Pattern) -> ::std::option::Option<crate::prelude::Text> {
    match &*p_p1.kind_p {
        crate::syntax::PatternKind::PName(n_p2) => if !crate::check::env::has_key_f(&menv_p0.names_p, &crate::prelude::Text::from(format!("{}#taker", &crate::check::env::sname_key_f(n_p2)))) {
            ::std::option::Option::None
        } else {
            'm69059: {
                let scrutinee = &crate::prelude::get(&menv_p0.names_p, &crate::check::env::sname_key_f(n_p2));
                if let ::std::option::Option::Some(crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XMethod(m69059_0_0_0, getter_p3, _), _, _)) = scrutinee && let crate::lower::model::Ex::XSelf = &**m69059_0_0_0 {
                    break 'm69059 ::std::option::Option::Some(getter_p3.clone());
                }
                ::std::option::Option::None
            }
        },
        _ => ::std::option::Option::None,
    }
}

/// ```prism
/// LateFieldPlaces: unbounded fn Wx, Env, Env, Env, Stmt, Bool -> ((Wx, Env, Env, Bool))
/// ```
pub fn late_field_places_f(wx_p0: &crate::lower::node_::Wx, benv_p1: &crate::lower::types::Env, menv_p2: &crate::lower::types::Env, fns_p3: &crate::lower::types::Env, s_p4: &crate::syntax::Stmt, grew_p5: &bool) -> (crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env, bool) {
    match &s_p4.kind_p {
        crate::syntax::StmtKind::SBind(p_p6, init_p7, ::std::option::Option::None) => match &*p_p6.kind_p {
            crate::syntax::PatternKind::PName(n_p8) => {
                let nkey_p9 = crate::check::env::sname_key_f(n_p8);
                let lx_pa = crate::lower::expr::widget_let_lx_f(&wx_p0.lx_p, &n_p8.span_p);
                let full_pb = crate::lower::binder_ty_f(&lx_pa, &n_p8.span_p);
                let placed_pc = match crate::lower::types::peel_f(&crate::lower::type_at_f(&wx_p0.lx_p, &init_p7.span_p)) {
                    crate::check::types::Ty::TyElem(_, _) => true,
                    _ => false,
                };
                if (((((((!placed_pc || !crate::lower::node_::finish::emits_f(wx_p0, &wx_p0.pos_p)) || is_time_name_f(&nkey_p9)) || crate::check::env::has_key_f(&menv_p2.names_p, &crate::prelude::Text::from(format!("{}#late", &nkey_p9)))) || (&crate::lower::types::layer_of_f(&full_pb) != &crate::lower::types::Layer::LyPlain)) || crate::lower::types::time_within_f(&full_pb)) || crate::lower::types::is_bundle_f(&full_pb)) || !reads_late_via_f(fns_p3, menv_p2, init_p7)) || reads_late_of_places_f(fns_p3, menv_p2, init_p7) {
                    (wx_p0.clone(), benv_p1.clone(), menv_p2.clone(), *grew_p5)
                } else {
                    {
                        let t_pd = crate::lower::types::out_ty_of_f(&lx_pa, &crate::lower::types::peel_f(&full_pb));
                        let (rs_pf, w2_pg) = crate::lower::node_::fresh_name_f(wx_p0, &crate::lower::local_name_at_f(&lx_pa, &nkey_p9, &n_p8.span_p));
                        let unbuilt_pe = crate::lower::types::Bn::BnLocal(crate::lower::expr::refusal_f(&crate::prelude::Text::from(format!("the answer `{}` of a place whose constant field reads a late result, read at its block\'s build by a line of the block\'s node that takes a value there", &nkey_p9))), crate::lower::types::Holding::Owned, t_pd.clone());
                        (w2_pg.clone(), crate::lower::types::bind_f(&crate::lower::types::bind_f(benv_p1, &nkey_p9, &unbuilt_pe), &crate::prelude::Text::from(format!("{}#late", &nkey_p9)), &unbuilt_pe), crate::lower::types::bind_f(&crate::lower::types::bind_f(menv_p2, &nkey_p9, &late_plain_bn_f(&rs_pf, &t_pd)), &crate::prelude::Text::from(format!("{}#late", &nkey_p9)), &unbuilt_pe), true)
                    }
                }
            },
            _ => (wx_p0.clone(), benv_p1.clone(), menv_p2.clone(), *grew_p5),
        },
        _ => (wx_p0.clone(), benv_p1.clone(), menv_p2.clone(), *grew_p5),
    }
}

/// The step machine of `LateFieldPlaces`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LateFieldPlaces: unbounded fn Wx, Env, Env, Env, Stmt, Bool -> ((Wx, Env, Env, Bool))
/// ```
pub struct LateFieldPlaces {
    pub wx_p0: crate::lower::node_::Wx,
    pub benv_p1: crate::lower::types::Env,
    pub menv_p2: crate::lower::types::Env,
    pub fns_p3: crate::lower::types::Env,
    pub s_p4: crate::syntax::Stmt,
    pub grew_p5: bool,
}

impl ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env, bool)> for LateFieldPlaces {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env, bool)> {
        let wx_p0 = &self.wx_p0;
        let benv_p1 = &self.benv_p1;
        let menv_p2 = &self.menv_p2;
        let fns_p3 = &self.fns_p3;
        let s_p4 = &self.s_p4;
        let grew_p5 = &self.grew_p5;
        match &s_p4.kind_p {
            crate::syntax::StmtKind::SBind(p_p6, init_p7, ::std::option::Option::None) => match &*p_p6.kind_p {
                crate::syntax::PatternKind::PName(n_p8) => {
                    let nkey_p9 = crate::check::env::sname_key_f(n_p8);
                    let benv_p1x = benv_p1.clone();
                    let fns_p3x = fns_p3.clone();
                    let grew_p5x = *grew_p5;
                    let init_p7x = init_p7.clone();
                    let menv_p2x = menv_p2.clone();
                    let n_p8x = n_p8.clone();
                    let wx_p0x = wx_p0.clone();
                    crate::prelude::call_then(crate::lower::expr::start_widget_let_lx_f(wx_p0x.lx_p.clone(), n_p8x.span_p.clone()), move |widget_let_lx_f_70274: crate::lower::Lx| {
                        let lx_pa = widget_let_lx_f_70274;
                        let full_pb = crate::lower::binder_ty_f(&lx_pa, &n_p8x.span_p);
                        let placed_pc = match crate::lower::types::peel_f(&crate::lower::type_at_f(&wx_p0x.lx_p, &init_p7x.span_p)) {
                            crate::check::types::Ty::TyElem(_, _) => true,
                            _ => false,
                        };
                        if (((((((!placed_pc || !crate::lower::node_::finish::emits_f(&wx_p0x, &wx_p0x.pos_p)) || is_time_name_f(&nkey_p9)) || crate::check::env::has_key_f(&menv_p2x.names_p, &crate::prelude::Text::from(format!("{}#late", &nkey_p9)))) || (&crate::lower::types::layer_of_f(&full_pb) != &crate::lower::types::Layer::LyPlain)) || crate::lower::types::time_within_f(&full_pb)) || crate::lower::types::is_bundle_f(&full_pb)) || !reads_late_via_f(&fns_p3x, &menv_p2x, &init_p7x)) || reads_late_of_places_f(&fns_p3x, &menv_p2x, &init_p7x) {
                            ::prism_rtl::Turn::Finished((wx_p0x.clone(), benv_p1x.clone(), menv_p2x.clone(), grew_p5x))
                        } else {
                            crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_pa.clone(), crate::lower::types::peel_f(&full_pb)), move |out_ty_of_f_70814: crate::lower::model::OutTy| {
                                let t_pd = out_ty_of_f_70814;
                                crate::prelude::call_then(crate::lower::start_local_name_at_f(lx_pa.clone(), nkey_p9.clone(), n_p8x.span_p.clone()), move |local_name_at_f_70886: crate::prelude::Text| {
                                    let (rs_pf, w2_pg) = crate::lower::node_::fresh_name_f(&wx_p0x, &local_name_at_f_70886);
                                    let unbuilt_pe = crate::lower::types::Bn::BnLocal(crate::lower::expr::refusal_f(&crate::prelude::Text::from(format!("the answer `{}` of a place whose constant field reads a late result, read at its block\'s build by a line of the block\'s node that takes a value there", &nkey_p9))), crate::lower::types::Holding::Owned, t_pd.clone());
                                    ::prism_rtl::Turn::Finished((w2_pg.clone(), crate::lower::types::bind_f(&crate::lower::types::bind_f(&benv_p1x, &nkey_p9, &unbuilt_pe), &crate::prelude::Text::from(format!("{}#late", &nkey_p9)), &unbuilt_pe), crate::lower::types::bind_f(&crate::lower::types::bind_f(&menv_p2x, &nkey_p9, &late_plain_bn_f(&rs_pf, &t_pd)), &crate::prelude::Text::from(format!("{}#late", &nkey_p9)), &unbuilt_pe), true))
                                })
                            })
                        }
                    })
                },
                _ => ::prism_rtl::Turn::Finished((wx_p0.clone(), benv_p1.clone(), menv_p2.clone(), *grew_p5)),
            },
            _ => ::prism_rtl::Turn::Finished((wx_p0.clone(), benv_p1.clone(), menv_p2.clone(), *grew_p5)),
        }
    }
}

/// `Start LateFieldPlaces, x`: what the function value is when passed to `@Run`.
pub fn start_late_field_places_f(wx_p0: crate::lower::node_::Wx, benv_p1: crate::lower::types::Env, menv_p2: crate::lower::types::Env, fns_p3: crate::lower::types::Env, s_p4: crate::syntax::Stmt, grew_p5: bool) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env, bool)>> {
    ::std::rc::Rc::new(LateFieldPlaces { wx_p0, benv_p1, menv_p2, fns_p3, s_p4, grew_p5 })
}

/// ```prism
/// LatePlaceParts: unbounded fn Wx, Env, Env, Stmt -> ((Wx, Env, Env))
/// ```
pub fn late_place_parts_f(wx_p0: &crate::lower::node_::Wx, benv_p1: &crate::lower::types::Env, menv_p2: &crate::lower::types::Env, s_p3: &crate::syntax::Stmt) -> (crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env) {
    match &s_p3.kind_p {
        crate::syntax::StmtKind::SBind(p_p4, init_p5, ::std::option::Option::None) => if !(crate::check::types::has_nat_f(&wx_p0.late_hosts_p, &wx_p0.pos_p.scope_p) && is_bundle_place_f(&wx_p0.lx_p, init_p5)) {
            (wx_p0.clone(), benv_p1.clone(), menv_p2.clone())
        } else {
            match &*p_p4.kind_p {
                crate::syntax::PatternKind::PTuple(ps_p6) => crate::prelude::run_to_end(crate::prelude::fold_job(ps_p6.clone(), (wx_p0.clone(), benv_p1.clone(), menv_p2.clone()), {
                    let init_p5x = init_p5.clone();
                    let ps_p6x = ps_p6.clone();
                    ::std::rc::Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::syntax::Pattern)| {
                        let init_p5xy = init_p5x.clone();
                        let ps_p6xy = ps_p6x.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let (w_p7, be_p8, me_p9) = p0;
                            let q_pa = p1;
                            match &*q_pa.kind_p {
                                crate::syntax::PatternKind::PName(n_pb) => {
                                    let nkey_pc = crate::check::env::sname_key_f(n_pb);
                                    let n_pbx = n_pb.clone();
                                    crate::prelude::call_then(crate::lower::expr::start_widget_let_lx_f(w_p7.lx_p.clone(), n_pbx.span_p.clone()), move |widget_let_lx_f_72686: crate::lower::Lx| {
                                        let lx_pd = widget_let_lx_f_72686;
                                        let full_pe = crate::lower::binder_ty_f(&lx_pd, &n_pbx.span_p);
                                        if ((is_time_name_f(&nkey_pc) || (&crate::lower::types::layer_of_f(&full_pe) != &crate::lower::types::Layer::LyPlain)) || crate::lower::types::time_within_f(&full_pe)) || crate::lower::types::is_bundle_f(&full_pe) {
                                            ::prism_rtl::Turn::Finished((w_p7.clone(), be_p8.clone(), me_p9.clone()))
                                        } else {
                                            crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_pd.clone(), crate::lower::types::peel_f(&full_pe)), move |out_ty_of_f_72927: crate::lower::model::OutTy| {
                                                let t_pf = out_ty_of_f_72927;
                                                crate::prelude::call_then(crate::lower::start_local_name_at_f(lx_pd.clone(), nkey_pc.clone(), n_pbx.span_p.clone()), move |local_name_at_f_73002: crate::prelude::Text| {
                                                    let (rs_ph, w2_pi) = crate::lower::node_::fresh_name_f(&w_p7, &local_name_at_f_73002);
                                                    let unbuilt_pg = crate::lower::types::Bn::BnLocal(crate::lower::expr::refusal_f(&crate::prelude::Text::from(format!("the plain part `{}` of a late place\'s answer read at its block\'s build by a line of the block\'s node that takes a value there (a place\'s constant field)", &nkey_pc))), crate::lower::types::Holding::Owned, t_pf.clone());
                                                    ::prism_rtl::Turn::Finished((w2_pi.clone(), crate::lower::types::bind_f(&crate::lower::types::bind_f(&be_p8, &nkey_pc, &unbuilt_pg), &crate::prelude::Text::from(format!("{}#late", &nkey_pc)), &unbuilt_pg), crate::lower::types::bind_f(&crate::lower::types::bind_f(&crate::lower::types::bind_f(&me_p9, &nkey_pc, &late_plain_bn_f(&rs_ph, &t_pf)), &crate::prelude::Text::from(format!("{}#late", &nkey_pc)), &unbuilt_pg), &crate::prelude::Text::from(format!("{}#lateplace", &nkey_pc)), &unbuilt_pg)))
                                                })
                                            })
                                        }
                                    })
                                },
                                _ => {
                                    let part_tys_pj = crate::lower::node_::keyed::bundle_part_tys_f(&line_out_full_f(&w_p7.lx_p, &init_p5xy));
                                    let at_pk = crate::prelude::len(&crate::prelude::filter(&ps_p6xy, &(|other_pn: &crate::syntax::Pattern| &other_pn.span_p.start_p < &q_pa.span_p.start_p)));
                                    let part_ty_pl = crate::prelude::or(&crate::prelude::index(&part_tys_pj, &at_pk), &crate::check::types::Ty::TyErr);
                                    crate::prelude::call_then(start_binder_names_f(q_pa.clone()), move |binder_names_f_74055: crate::prelude::Array<crate::syntax::SName>| {
                                        let names_pm = crate::prelude::filter(&binder_names_f_74055, &(|n_po: &crate::syntax::SName| !is_time_name_f(&crate::check::env::sname_key_f(n_po))));
                                        if (((&crate::prelude::len(&names_pm) == &crate::prelude::Nat::from(0u32)) || (&crate::lower::types::layer_of_f(&part_ty_pl) != &crate::lower::types::Layer::LyPlain)) || crate::lower::types::time_within_f(&part_ty_pl)) || crate::lower::types::is_bundle_f(&part_ty_pl) {
                                            ::prism_rtl::Turn::Finished((w_p7.clone(), be_p8.clone(), me_p9.clone()))
                                        } else {
                                            crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(w_p7.lx_p.clone(), crate::lower::types::peel_f(&part_ty_pl)), move |out_ty_of_f_74281: crate::lower::model::OutTy| {
                                                let pt_pp = out_ty_of_f_74281;
                                                let (hold_ps, w1_pt) = crate::lower::node_::fresh_name_f(&w_p7, &crate::prelude::Text::from(format!("part_{}", &q_pa.span_p.start_p)));
                                                let held_pq = late_plain_bn_f(&hold_ps, &pt_pp);
                                                let read_pr = match &held_pq {
                                                    crate::lower::types::Bn::BnLocal(ex_pu, _, _) => ex_pu.clone(),
                                                    _ => crate::lower::expr::internal_bug_f(&crate::prelude::Text::lit("a late place\'s plain part with no hold")),
                                                };
                                                crate::prelude::fold_job(names_pm.clone(), (w1_pt.clone(), be_p8.clone(), crate::lower::types::bind_f(&me_p9, &part_hold_key_f(&q_pa), &held_pq)), {
                                                    let q_pax = q_pa.clone();
                                                    let part_ty_plx = part_ty_pl.clone();
                                                    let read_prx = read_pr.clone();
                                                    ::std::rc::Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::syntax::SName)| {
                                                        let q_paxy = q_pax.clone();
                                                        let part_ty_plxy = part_ty_plx.clone();
                                                        let read_prxy = read_prx.clone();
                                                        crate::prelude::entered(crate::prelude::once_job(move || {
                                                            let (w2_pv, be2_p10, me2_p11) = p0;
                                                            let n_p12 = p1;
                                                            {
                                                                let nkey_p13 = crate::check::env::sname_key_f(&n_p12);
                                                                crate::prelude::call_then(crate::lower::expr::start_widget_let_lx_f(w2_pv.lx_p.clone(), n_p12.span_p.clone()), move |widget_let_lx_f_74801: crate::lower::Lx| {
                                                                    let lx_p14 = widget_let_lx_f_74801;
                                                                    crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p14.clone(), crate::lower::types::peel_f(&crate::lower::binder_ty_f(&lx_p14, &n_p12.span_p))), move |out_ty_of_f_74859: crate::lower::model::OutTy| {
                                                                        let t_p15 = out_ty_of_f_74859;
                                                                        crate::prelude::call_then(crate::lower::start_local_name_at_f(lx_p14.clone(), nkey_p13.clone(), n_p12.span_p.clone()), move |local_name_at_f_74966: crate::prelude::Text| {
                                                                            let (getter_p18, w3_p19) = crate::lower::node_::fresh_name_f(&w2_pv, &crate::prelude::Text::from(format!("late_{}", &local_name_at_f_74966)));
                                                                            let unbuilt_p16 = crate::lower::types::Bn::BnLocal(crate::lower::expr::refusal_f(&crate::prelude::Text::from(format!("the name `{}` inside the plain part of a late place\'s answer read at its block\'s build by a line of the block\'s node that takes a value there (a place\'s constant field)", &nkey_p13))), crate::lower::types::Holding::Owned, t_p15.clone());
                                                                            crate::prelude::call_then(start_late_getters_f(w3_p19.clone(), crate::prelude::Array::from(vec![LateName { getter_p: getter_p18.clone(), part_o: ::std::option::Option::None, ty_p: t_p15.clone(), name_p: nkey_p13.clone(), within_o: ::std::option::Option::Some((q_paxy.clone(), part_ty_plxy.clone())) }]), read_prxy.clone(), crate::prelude::Array::new()), move |late_getters_f_75271: crate::lower::node_::Wx| {
                                                                                let w4_p17 = late_getters_f_75271;
                                                                                ::prism_rtl::Turn::Finished((w4_p17.clone(), crate::lower::types::bind_f(&crate::lower::types::bind_f(&be2_p10, &nkey_p13, &unbuilt_p16), &crate::prelude::Text::from(format!("{}#late", &nkey_p13)), &unbuilt_p16), crate::lower::types::bind_f(&crate::lower::types::bind_f(&crate::lower::types::bind_f(&me2_p11, &nkey_p13, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), getter_p18.clone(), crate::prelude::Array::new()), crate::lower::types::Holding::Owned, t_p15.clone())), &crate::prelude::Text::from(format!("{}#late", &nkey_p13)), &unbuilt_p16), &crate::prelude::Text::from(format!("{}#lateplace", &nkey_p13)), &unbuilt_p16)))
                                                                            })
                                                                        })
                                                                    })
                                                                })
                                                            }
                                                        }))
                                                    }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::syntax::SName)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>>>
                                                }).cycle()
                                            })
                                        }
                                    })
                                },
                            }
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::syntax::Pattern)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>>>
                })),
                _ => (wx_p0.clone(), benv_p1.clone(), menv_p2.clone()),
            }
        },
        _ => (wx_p0.clone(), benv_p1.clone(), menv_p2.clone()),
    }
}

/// The step machine of `LatePlaceParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LatePlaceParts: unbounded fn Wx, Env, Env, Stmt -> ((Wx, Env, Env))
/// ```
pub struct LatePlaceParts {
    pub wx_p0: crate::lower::node_::Wx,
    pub benv_p1: crate::lower::types::Env,
    pub menv_p2: crate::lower::types::Env,
    pub s_p3: crate::syntax::Stmt,
}

impl ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)> for LatePlaceParts {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)> {
        let wx_p0 = &self.wx_p0;
        let benv_p1 = &self.benv_p1;
        let menv_p2 = &self.menv_p2;
        let s_p3 = &self.s_p3;
        match &s_p3.kind_p {
            crate::syntax::StmtKind::SBind(p_p4, init_p5, ::std::option::Option::None) => if !(crate::check::types::has_nat_f(&wx_p0.late_hosts_p, &wx_p0.pos_p.scope_p) && is_bundle_place_f(&wx_p0.lx_p, init_p5)) {
                ::prism_rtl::Turn::Finished((wx_p0.clone(), benv_p1.clone(), menv_p2.clone()))
            } else {
                match &*p_p4.kind_p {
                    crate::syntax::PatternKind::PTuple(ps_p6) => crate::prelude::fold_job(ps_p6.clone(), (wx_p0.clone(), benv_p1.clone(), menv_p2.clone()), {
                        let init_p5x = init_p5.clone();
                        let ps_p6x = ps_p6.clone();
                        ::std::rc::Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::syntax::Pattern)| {
                            let init_p5xy = init_p5x.clone();
                            let ps_p6xy = ps_p6x.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let (w_p7, be_p8, me_p9) = p0;
                                let q_pa = p1;
                                match &*q_pa.kind_p {
                                    crate::syntax::PatternKind::PName(n_pb) => {
                                        let nkey_pc = crate::check::env::sname_key_f(n_pb);
                                        let n_pbx = n_pb.clone();
                                        crate::prelude::call_then(crate::lower::expr::start_widget_let_lx_f(w_p7.lx_p.clone(), n_pbx.span_p.clone()), move |widget_let_lx_f_72686: crate::lower::Lx| {
                                            let lx_pd = widget_let_lx_f_72686;
                                            let full_pe = crate::lower::binder_ty_f(&lx_pd, &n_pbx.span_p);
                                            if ((is_time_name_f(&nkey_pc) || (&crate::lower::types::layer_of_f(&full_pe) != &crate::lower::types::Layer::LyPlain)) || crate::lower::types::time_within_f(&full_pe)) || crate::lower::types::is_bundle_f(&full_pe) {
                                                ::prism_rtl::Turn::Finished((w_p7.clone(), be_p8.clone(), me_p9.clone()))
                                            } else {
                                                crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_pd.clone(), crate::lower::types::peel_f(&full_pe)), move |out_ty_of_f_72927: crate::lower::model::OutTy| {
                                                    let t_pf = out_ty_of_f_72927;
                                                    crate::prelude::call_then(crate::lower::start_local_name_at_f(lx_pd.clone(), nkey_pc.clone(), n_pbx.span_p.clone()), move |local_name_at_f_73002: crate::prelude::Text| {
                                                        let (rs_ph, w2_pi) = crate::lower::node_::fresh_name_f(&w_p7, &local_name_at_f_73002);
                                                        let unbuilt_pg = crate::lower::types::Bn::BnLocal(crate::lower::expr::refusal_f(&crate::prelude::Text::from(format!("the plain part `{}` of a late place\'s answer read at its block\'s build by a line of the block\'s node that takes a value there (a place\'s constant field)", &nkey_pc))), crate::lower::types::Holding::Owned, t_pf.clone());
                                                        ::prism_rtl::Turn::Finished((w2_pi.clone(), crate::lower::types::bind_f(&crate::lower::types::bind_f(&be_p8, &nkey_pc, &unbuilt_pg), &crate::prelude::Text::from(format!("{}#late", &nkey_pc)), &unbuilt_pg), crate::lower::types::bind_f(&crate::lower::types::bind_f(&crate::lower::types::bind_f(&me_p9, &nkey_pc, &late_plain_bn_f(&rs_ph, &t_pf)), &crate::prelude::Text::from(format!("{}#late", &nkey_pc)), &unbuilt_pg), &crate::prelude::Text::from(format!("{}#lateplace", &nkey_pc)), &unbuilt_pg)))
                                                    })
                                                })
                                            }
                                        })
                                    },
                                    _ => {
                                        let part_tys_pj = crate::lower::node_::keyed::bundle_part_tys_f(&line_out_full_f(&w_p7.lx_p, &init_p5xy));
                                        let at_pk = crate::prelude::len(&crate::prelude::filter(&ps_p6xy, &(|other_pn: &crate::syntax::Pattern| &other_pn.span_p.start_p < &q_pa.span_p.start_p)));
                                        let part_ty_pl = crate::prelude::or(&crate::prelude::index(&part_tys_pj, &at_pk), &crate::check::types::Ty::TyErr);
                                        crate::prelude::call_then(start_binder_names_f(q_pa.clone()), move |binder_names_f_74055: crate::prelude::Array<crate::syntax::SName>| {
                                            let names_pm = crate::prelude::filter(&binder_names_f_74055, &(|n_po: &crate::syntax::SName| !is_time_name_f(&crate::check::env::sname_key_f(n_po))));
                                            if (((&crate::prelude::len(&names_pm) == &crate::prelude::Nat::from(0u32)) || (&crate::lower::types::layer_of_f(&part_ty_pl) != &crate::lower::types::Layer::LyPlain)) || crate::lower::types::time_within_f(&part_ty_pl)) || crate::lower::types::is_bundle_f(&part_ty_pl) {
                                                ::prism_rtl::Turn::Finished((w_p7.clone(), be_p8.clone(), me_p9.clone()))
                                            } else {
                                                crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(w_p7.lx_p.clone(), crate::lower::types::peel_f(&part_ty_pl)), move |out_ty_of_f_74281: crate::lower::model::OutTy| {
                                                    let pt_pp = out_ty_of_f_74281;
                                                    let (hold_ps, w1_pt) = crate::lower::node_::fresh_name_f(&w_p7, &crate::prelude::Text::from(format!("part_{}", &q_pa.span_p.start_p)));
                                                    let held_pq = late_plain_bn_f(&hold_ps, &pt_pp);
                                                    let read_pr = match &held_pq {
                                                        crate::lower::types::Bn::BnLocal(ex_pu, _, _) => ex_pu.clone(),
                                                        _ => crate::lower::expr::internal_bug_f(&crate::prelude::Text::lit("a late place\'s plain part with no hold")),
                                                    };
                                                    crate::prelude::fold_job(names_pm.clone(), (w1_pt.clone(), be_p8.clone(), crate::lower::types::bind_f(&me_p9, &part_hold_key_f(&q_pa), &held_pq)), {
                                                        let q_pax = q_pa.clone();
                                                        let part_ty_plx = part_ty_pl.clone();
                                                        let read_prx = read_pr.clone();
                                                        ::std::rc::Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::syntax::SName)| {
                                                            let q_paxy = q_pax.clone();
                                                            let part_ty_plxy = part_ty_plx.clone();
                                                            let read_prxy = read_prx.clone();
                                                            crate::prelude::entered(crate::prelude::once_job(move || {
                                                                let (w2_pv, be2_p10, me2_p11) = p0;
                                                                let n_p12 = p1;
                                                                {
                                                                    let nkey_p13 = crate::check::env::sname_key_f(&n_p12);
                                                                    crate::prelude::call_then(crate::lower::expr::start_widget_let_lx_f(w2_pv.lx_p.clone(), n_p12.span_p.clone()), move |widget_let_lx_f_74801: crate::lower::Lx| {
                                                                        let lx_p14 = widget_let_lx_f_74801;
                                                                        crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p14.clone(), crate::lower::types::peel_f(&crate::lower::binder_ty_f(&lx_p14, &n_p12.span_p))), move |out_ty_of_f_74859: crate::lower::model::OutTy| {
                                                                            let t_p15 = out_ty_of_f_74859;
                                                                            crate::prelude::call_then(crate::lower::start_local_name_at_f(lx_p14.clone(), nkey_p13.clone(), n_p12.span_p.clone()), move |local_name_at_f_74966: crate::prelude::Text| {
                                                                                let (getter_p18, w3_p19) = crate::lower::node_::fresh_name_f(&w2_pv, &crate::prelude::Text::from(format!("late_{}", &local_name_at_f_74966)));
                                                                                let unbuilt_p16 = crate::lower::types::Bn::BnLocal(crate::lower::expr::refusal_f(&crate::prelude::Text::from(format!("the name `{}` inside the plain part of a late place\'s answer read at its block\'s build by a line of the block\'s node that takes a value there (a place\'s constant field)", &nkey_p13))), crate::lower::types::Holding::Owned, t_p15.clone());
                                                                                crate::prelude::call_then(start_late_getters_f(w3_p19.clone(), crate::prelude::Array::from(vec![LateName { getter_p: getter_p18.clone(), part_o: ::std::option::Option::None, ty_p: t_p15.clone(), name_p: nkey_p13.clone(), within_o: ::std::option::Option::Some((q_paxy.clone(), part_ty_plxy.clone())) }]), read_prxy.clone(), crate::prelude::Array::new()), move |late_getters_f_75271: crate::lower::node_::Wx| {
                                                                                    let w4_p17 = late_getters_f_75271;
                                                                                    ::prism_rtl::Turn::Finished((w4_p17.clone(), crate::lower::types::bind_f(&crate::lower::types::bind_f(&be2_p10, &nkey_p13, &unbuilt_p16), &crate::prelude::Text::from(format!("{}#late", &nkey_p13)), &unbuilt_p16), crate::lower::types::bind_f(&crate::lower::types::bind_f(&crate::lower::types::bind_f(&me2_p11, &nkey_p13, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), getter_p18.clone(), crate::prelude::Array::new()), crate::lower::types::Holding::Owned, t_p15.clone())), &crate::prelude::Text::from(format!("{}#late", &nkey_p13)), &unbuilt_p16), &crate::prelude::Text::from(format!("{}#lateplace", &nkey_p13)), &unbuilt_p16)))
                                                                                })
                                                                            })
                                                                        })
                                                                    })
                                                                }
                                                            }))
                                                        }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::syntax::SName)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>>>
                                                    }).cycle()
                                                })
                                            }
                                        })
                                    },
                                }
                            }))
                        }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::syntax::Pattern)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>>>
                    }).cycle(),
                    _ => ::prism_rtl::Turn::Finished((wx_p0.clone(), benv_p1.clone(), menv_p2.clone())),
                }
            },
            _ => ::prism_rtl::Turn::Finished((wx_p0.clone(), benv_p1.clone(), menv_p2.clone())),
        }
    }
}

/// `Start LatePlaceParts, x`: what the function value is when passed to `@Run`.
pub fn start_late_place_parts_f(wx_p0: crate::lower::node_::Wx, benv_p1: crate::lower::types::Env, menv_p2: crate::lower::types::Env, s_p3: crate::syntax::Stmt) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>> {
    ::std::rc::Rc::new(LatePlaceParts { wx_p0, benv_p1, menv_p2, s_p3 })
}

/// ```prism
/// PartHoldKey: fn Pattern -> Text
/// ```
pub fn part_hold_key_f(q_p0: &crate::syntax::Pattern) -> crate::prelude::Text {
    crate::prelude::Text::from(format!("#parthold{}:{}", &q_p0.span_p.start_p, &q_p0.span_p.end_p))
}

/// ```prism
/// LateHostedAnswer: unbounded fn Wx, Env, Env, Stmt -> ((Wx, Env, Env))
/// ```
pub fn late_hosted_answer_f(wx_p0: &crate::lower::node_::Wx, benv_p1: &crate::lower::types::Env, menv_p2: &crate::lower::types::Env, s_p3: &crate::syntax::Stmt) -> (crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env) {
    match &s_p3.kind_p {
        crate::syntax::StmtKind::SBind(p_p4, init_p5, ::std::option::Option::None) => match &*p_p4.kind_p {
            crate::syntax::PatternKind::PName(n_p6) => {
                let nkey_p7 = crate::check::env::sname_key_f(n_p6);
                let lx_p8 = crate::lower::expr::widget_let_lx_f(&wx_p0.lx_p, &n_p6.span_p);
                let full_p9 = crate::lower::binder_ty_f(&lx_p8, &n_p6.span_p);
                let placed_pa = match crate::lower::types::peel_f(&crate::lower::type_at_f(&wx_p0.lx_p, &init_p5.span_p)) {
                    crate::check::types::Ty::TyElem(_, _) => true,
                    _ => false,
                };
                if ((((((!placed_pa || (&wx_p0.pos_p.scope_p == &crate::prelude::Nat::from(0u32))) || !crate::check::types::has_text_f(&wx_p0.unplaced_hosts_p, &crate::prelude::or(&crate::prelude::index(&wx_p0.scopes_p, &crate::syntax::lexer::chars::dec_f(&wx_p0.pos_p.scope_p)), &crate::prelude::Text::lit("")))) || is_time_name_f(&nkey_p7)) || crate::check::env::has_key_f(&menv_p2.names_p, &crate::prelude::Text::from(format!("{}#late", &nkey_p7)))) || (&crate::lower::types::layer_of_f(&full_p9) != &crate::lower::types::Layer::LyPlain)) || crate::lower::types::time_within_f(&full_p9)) || crate::lower::types::is_bundle_f(&full_p9) {
                    (wx_p0.clone(), benv_p1.clone(), menv_p2.clone())
                } else {
                    {
                        let t_pb = crate::lower::types::out_ty_of_f(&lx_p8, &crate::lower::types::peel_f(&full_p9));
                        let (rs_pd, w2_pe) = crate::lower::node_::fresh_name_f(wx_p0, &crate::lower::local_name_at_f(&lx_p8, &nkey_p7, &n_p6.span_p));
                        let unbuilt_pc = crate::lower::types::Bn::BnLocal(crate::lower::expr::refusal_f(&crate::prelude::Text::from(format!("the plain answer `{}` of a place under a host placed after its node, read at its block\'s build by a line of the block\'s node that takes a value there (a place\'s constant field)", &nkey_p7))), crate::lower::types::Holding::Owned, t_pb.clone());
                        (w2_pe.clone(), crate::lower::types::bind_f(&crate::lower::types::bind_f(benv_p1, &nkey_p7, &unbuilt_pc), &crate::prelude::Text::from(format!("{}#late", &nkey_p7)), &unbuilt_pc), crate::lower::types::bind_f(&crate::lower::types::bind_f(&crate::lower::types::bind_f(menv_p2, &nkey_p7, &late_plain_bn_f(&rs_pd, &t_pb)), &crate::prelude::Text::from(format!("{}#late", &nkey_p7)), &unbuilt_pc), &crate::prelude::Text::from(format!("{}#lateplace", &nkey_p7)), &unbuilt_pc))
                    }
                }
            },
            _ => (wx_p0.clone(), benv_p1.clone(), menv_p2.clone()),
        },
        _ => (wx_p0.clone(), benv_p1.clone(), menv_p2.clone()),
    }
}

/// The step machine of `LateHostedAnswer`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LateHostedAnswer: unbounded fn Wx, Env, Env, Stmt -> ((Wx, Env, Env))
/// ```
pub struct LateHostedAnswer {
    pub wx_p0: crate::lower::node_::Wx,
    pub benv_p1: crate::lower::types::Env,
    pub menv_p2: crate::lower::types::Env,
    pub s_p3: crate::syntax::Stmt,
}

impl ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)> for LateHostedAnswer {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)> {
        let wx_p0 = &self.wx_p0;
        let benv_p1 = &self.benv_p1;
        let menv_p2 = &self.menv_p2;
        let s_p3 = &self.s_p3;
        match &s_p3.kind_p {
            crate::syntax::StmtKind::SBind(p_p4, init_p5, ::std::option::Option::None) => match &*p_p4.kind_p {
                crate::syntax::PatternKind::PName(n_p6) => {
                    let nkey_p7 = crate::check::env::sname_key_f(n_p6);
                    let benv_p1x = benv_p1.clone();
                    let init_p5x = init_p5.clone();
                    let menv_p2x = menv_p2.clone();
                    let n_p6x = n_p6.clone();
                    let wx_p0x = wx_p0.clone();
                    crate::prelude::call_then(crate::lower::expr::start_widget_let_lx_f(wx_p0x.lx_p.clone(), n_p6x.span_p.clone()), move |widget_let_lx_f_76627: crate::lower::Lx| {
                        let lx_p8 = widget_let_lx_f_76627;
                        let full_p9 = crate::lower::binder_ty_f(&lx_p8, &n_p6x.span_p);
                        let placed_pa = match crate::lower::types::peel_f(&crate::lower::type_at_f(&wx_p0x.lx_p, &init_p5x.span_p)) {
                            crate::check::types::Ty::TyElem(_, _) => true,
                            _ => false,
                        };
                        if ((((((!placed_pa || (&wx_p0x.pos_p.scope_p == &crate::prelude::Nat::from(0u32))) || !crate::check::types::has_text_f(&wx_p0x.unplaced_hosts_p, &crate::prelude::or(&crate::prelude::index(&wx_p0x.scopes_p, &crate::syntax::lexer::chars::dec_f(&wx_p0x.pos_p.scope_p)), &crate::prelude::Text::lit("")))) || is_time_name_f(&nkey_p7)) || crate::check::env::has_key_f(&menv_p2x.names_p, &crate::prelude::Text::from(format!("{}#late", &nkey_p7)))) || (&crate::lower::types::layer_of_f(&full_p9) != &crate::lower::types::Layer::LyPlain)) || crate::lower::types::time_within_f(&full_p9)) || crate::lower::types::is_bundle_f(&full_p9) {
                            ::prism_rtl::Turn::Finished((wx_p0x.clone(), benv_p1x.clone(), menv_p2x.clone()))
                        } else {
                            crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p8.clone(), crate::lower::types::peel_f(&full_p9)), move |out_ty_of_f_77147: crate::lower::model::OutTy| {
                                let t_pb = out_ty_of_f_77147;
                                crate::prelude::call_then(crate::lower::start_local_name_at_f(lx_p8.clone(), nkey_p7.clone(), n_p6x.span_p.clone()), move |local_name_at_f_77219: crate::prelude::Text| {
                                    let (rs_pd, w2_pe) = crate::lower::node_::fresh_name_f(&wx_p0x, &local_name_at_f_77219);
                                    let unbuilt_pc = crate::lower::types::Bn::BnLocal(crate::lower::expr::refusal_f(&crate::prelude::Text::from(format!("the plain answer `{}` of a place under a host placed after its node, read at its block\'s build by a line of the block\'s node that takes a value there (a place\'s constant field)", &nkey_p7))), crate::lower::types::Holding::Owned, t_pb.clone());
                                    ::prism_rtl::Turn::Finished((w2_pe.clone(), crate::lower::types::bind_f(&crate::lower::types::bind_f(&benv_p1x, &nkey_p7, &unbuilt_pc), &crate::prelude::Text::from(format!("{}#late", &nkey_p7)), &unbuilt_pc), crate::lower::types::bind_f(&crate::lower::types::bind_f(&crate::lower::types::bind_f(&menv_p2x, &nkey_p7, &late_plain_bn_f(&rs_pd, &t_pb)), &crate::prelude::Text::from(format!("{}#late", &nkey_p7)), &unbuilt_pc), &crate::prelude::Text::from(format!("{}#lateplace", &nkey_p7)), &unbuilt_pc)))
                                })
                            })
                        }
                    })
                },
                _ => ::prism_rtl::Turn::Finished((wx_p0.clone(), benv_p1.clone(), menv_p2.clone())),
            },
            _ => ::prism_rtl::Turn::Finished((wx_p0.clone(), benv_p1.clone(), menv_p2.clone())),
        }
    }
}

/// `Start LateHostedAnswer, x`: what the function value is when passed to `@Run`.
pub fn start_late_hosted_answer_f(wx_p0: crate::lower::node_::Wx, benv_p1: crate::lower::types::Env, menv_p2: crate::lower::types::Env, s_p3: crate::syntax::Stmt) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>> {
    ::std::rc::Rc::new(LateHostedAnswer { wx_p0, benv_p1, menv_p2, s_p3 })
}

/// ```prism
/// LatePlainBn: fn Text, OutTy -> Bn
/// ```
pub fn late_plain_bn_f(f_p0: &crate::prelude::Text, t_p1: &crate::lower::model::OutTy) -> crate::lower::types::Bn {
    crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), f_p0.clone())), crate::prelude::Text::lit("newest"), crate::prelude::Array::new())), crate::prelude::Text::lit("expect"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XStr(crate::prelude::Text::lit("a hosted place\'s first value is asked once its node stands"))])), crate::lower::types::Holding::Owned, t_p1.clone())
}

/// ```prism
/// ?LatePlainHold: fn ?Bn -> ?Text
/// ```
pub fn late_plain_hold_o(opt0: &::std::option::Option<crate::lower::types::Bn>) -> ::std::option::Option<crate::prelude::Text> {
    'c: {
        if let ::std::option::Option::Some(crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XMethod(c0_0_0_0, c0_0_0_1, _), _, _)) = opt0 && let crate::lower::model::Ex::XMethod(c0_0_0_0_r_0, c0_0_0_0_r_1, _) = &**c0_0_0_0 && let crate::lower::model::Ex::XField(c0_0_0_0_r_0_r_0, f_p0) = &**c0_0_0_0_r_0 && let crate::lower::model::Ex::XSelf = &**c0_0_0_0_r_0_r_0 && (c0_0_0_0_r_1 == &crate::prelude::Text::lit("newest")) && (c0_0_0_1 == &crate::prelude::Text::lit("expect")) {
            break 'c ::std::option::Option::Some(f_p0.clone());
        }
        if let other_o1 = opt0 {
            break 'c ::std::option::Option::None;
        }
        unreachable!("no clause matched")
    }
}

/// ```prism
/// ReadsLateOfPlaces: unbounded fn Env, Env, Expr -> Bool
/// ```
pub fn reads_late_of_places_f(fns_p0: &crate::lower::types::Env, env_p1: &crate::lower::types::Env, e_p2: &crate::syntax::Expr) -> bool {
    let lates_p3 = crate::prelude::filter(&crate::lower::node_::switch_::row_names_closed_f(fns_p0, &crate::lower::expr::free_reads_f(&crate::check::typed::print::exprs_in_f(e_p2), &crate::prelude::Array::new())), &(|n_p4: &crate::prelude::Text| crate::check::env::has_key_f(&env_p1.names_p, &crate::prelude::Text::from(format!("{}#late", n_p4)))));
    (&crate::prelude::len(&lates_p3) > &crate::prelude::Nat::from(0u32)) && crate::prelude::fold(&lates_p3, &true, &(|ok_p5: &bool, n_p6: &crate::prelude::Text| *ok_p5 && crate::check::env::has_key_f(&env_p1.names_p, &crate::prelude::Text::from(format!("{}#lateplace", n_p6)))))
}

/// The step machine of `ReadsLateOfPlaces`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ReadsLateOfPlaces: unbounded fn Env, Env, Expr -> Bool
/// ```
pub struct ReadsLateOfPlaces {
    pub fns_p0: crate::lower::types::Env,
    pub env_p1: crate::lower::types::Env,
    pub e_p2: crate::syntax::Expr,
}

impl ::prism_rtl::Job<bool> for ReadsLateOfPlaces {
    fn cycle(&self) -> ::prism_rtl::Turn<bool> {
        let fns_p0 = &self.fns_p0;
        let env_p1 = &self.env_p1;
        let e_p2 = &self.e_p2;
        let e_p2x = e_p2.clone();
        let env_p1x = env_p1.clone();
        let fns_p0x = fns_p0.clone();
        crate::prelude::call_then(crate::check::typed::print::start_exprs_in_f(e_p2x.clone()), move |exprs_in_f_78698: crate::prelude::Array<crate::syntax::Expr>| crate::prelude::call_then(crate::lower::expr::start_free_reads_f(exprs_in_f_78698, crate::prelude::Array::new()), move |free_reads_f_78687: crate::prelude::Array<crate::prelude::Text>| crate::prelude::call_then(crate::lower::node_::switch_::start_row_names_closed_f(fns_p0x.clone(), free_reads_f_78687), move |row_names_closed_f_78666: crate::prelude::Array<crate::prelude::Text>| {
            let lates_p3 = crate::prelude::filter(&row_names_closed_f_78666, &(|n_p4: &crate::prelude::Text| crate::check::env::has_key_f(&env_p1x.names_p, &crate::prelude::Text::from(format!("{}#late", n_p4)))));
            ::prism_rtl::Turn::Finished((&crate::prelude::len(&lates_p3) > &crate::prelude::Nat::from(0u32)) && crate::prelude::fold(&lates_p3, &true, &(|ok_p5: &bool, n_p6: &crate::prelude::Text| *ok_p5 && crate::check::env::has_key_f(&env_p1x.names_p, &crate::prelude::Text::from(format!("{}#lateplace", n_p6))))))
        })))
    }
}

/// `Start ReadsLateOfPlaces, x`: what the function value is when passed to `@Run`.
pub fn start_reads_late_of_places_f(fns_p0: crate::lower::types::Env, env_p1: crate::lower::types::Env, e_p2: crate::syntax::Expr) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>> {
    ::std::rc::Rc::new(ReadsLateOfPlaces { fns_p0, env_p1, e_p2 })
}

/// ```prism
/// IsLateBundleStmt: unbounded fn Lx, Env, Env, Stmt -> Bool
/// ```
pub fn is_late_bundle_stmt_f(lx_p0: &crate::lower::Lx, fns_p1: &crate::lower::types::Env, me_p2: &crate::lower::types::Env, s_p3: &crate::syntax::Stmt) -> bool {
    match &s_p3.kind_p {
        crate::syntax::StmtKind::SLet(p_p4, _, e_p5) => match bundle_written_o(lx_p0, p_p4, e_p5) {
            ::std::option::Option::Some((n_p6, tuple_p7)) => !crate::check::env::has_key_f(&me_p2.names_p, &crate::prelude::Text::from(format!("{}#late", &crate::check::env::sname_key_f(&n_p6)))) && has_late_plain_part_f(lx_p0, fns_p1, me_p2, &tuple_p7),
            ::std::option::Option::None => match late_bundle_alias_o(me_p2, p_p4, e_p5) {
                ::std::option::Option::Some(n_p8) => !crate::check::env::has_key_f(&me_p2.names_p, &crate::prelude::Text::from(format!("{}#late", &crate::check::env::sname_key_f(&n_p8)))),
                ::std::option::Option::None => false,
            },
        },
        _ => false,
    }
}

/// The step machine of `IsLateBundleStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// IsLateBundleStmt: unbounded fn Lx, Env, Env, Stmt -> Bool
/// ```
pub struct IsLateBundleStmt {
    pub lx_p0: crate::lower::Lx,
    pub fns_p1: crate::lower::types::Env,
    pub me_p2: crate::lower::types::Env,
    pub s_p3: crate::syntax::Stmt,
}

impl ::prism_rtl::Job<bool> for IsLateBundleStmt {
    fn cycle(&self) -> ::prism_rtl::Turn<bool> {
        let lx_p0 = &self.lx_p0;
        let fns_p1 = &self.fns_p1;
        let me_p2 = &self.me_p2;
        let s_p3 = &self.s_p3;
        match &s_p3.kind_p {
            crate::syntax::StmtKind::SLet(p_p4, _, e_p5) => {
                let e_p5x = e_p5.clone();
                let fns_p1x = fns_p1.clone();
                let lx_p0x = lx_p0.clone();
                let me_p2x = me_p2.clone();
                let p_p4x = p_p4.clone();
                crate::prelude::call_then(start_bundle_written_o(lx_p0x.clone(), p_p4x.clone(), e_p5x.clone()), move |bundle_written_o_79164: ::std::option::Option<(crate::syntax::SName, crate::syntax::Expr)>| match bundle_written_o_79164 {
                    ::std::option::Option::Some((n_p6, tuple_p7)) => ::prism_rtl::Turn::Finished(!crate::check::env::has_key_f(&me_p2x.names_p, &crate::prelude::Text::from(format!("{}#late", &crate::check::env::sname_key_f(&n_p6)))) && has_late_plain_part_f(&lx_p0x, &fns_p1x, &me_p2x, &tuple_p7)),
                    ::std::option::Option::None => match late_bundle_alias_o(&me_p2x, &p_p4x, &e_p5x) {
                        ::std::option::Option::Some(n_p8) => ::prism_rtl::Turn::Finished(!crate::check::env::has_key_f(&me_p2x.names_p, &crate::prelude::Text::from(format!("{}#late", &crate::check::env::sname_key_f(&n_p8))))),
                        ::std::option::Option::None => ::prism_rtl::Turn::Finished(false),
                    },
                })
            },
            _ => ::prism_rtl::Turn::Finished(false),
        }
    }
}

/// `Start IsLateBundleStmt, x`: what the function value is when passed to `@Run`.
pub fn start_is_late_bundle_stmt_f(lx_p0: crate::lower::Lx, fns_p1: crate::lower::types::Env, me_p2: crate::lower::types::Env, s_p3: crate::syntax::Stmt) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>> {
    ::std::rc::Rc::new(IsLateBundleStmt { lx_p0, fns_p1, me_p2, s_p3 })
}

/// ```prism
/// ?LateBundleAlias: unbounded fn Env, Pattern, Expr -> ?SName
/// ```
pub fn late_bundle_alias_o(me_p0: &crate::lower::types::Env, p_p1: &crate::syntax::Pattern, e_p2: &crate::syntax::Expr) -> ::std::option::Option<crate::syntax::SName> {
    match ((*p_p1.kind_p).clone(), (*e_p2.kind_p).clone()) {
        (crate::syntax::PatternKind::PGroup(q_p3), _) => late_bundle_alias_o(me_p0, &*q_p3, e_p2),
        (_, crate::syntax::ExprKind::EGroup(x_p4)) => late_bundle_alias_o(me_p0, p_p1, &*x_p4),
        (crate::syntax::PatternKind::PName(n_p5), crate::syntax::ExprKind::EName(m_p6)) => if ((&crate::prelude::len(&m_p6.path_p) == &crate::prelude::Nat::from(1u32)) && crate::check::env::has_key_f(&me_p0.names_p, &crate::prelude::Text::from(format!("{}#late", &crate::check::env::sname_key_f(&m_p6))))) && is_late_bundle_name_f(me_p0, &crate::check::env::sname_key_f(&m_p6)) {
            ::std::option::Option::Some(n_p5)
        } else {
            ::std::option::Option::None
        },
        _ => ::std::option::Option::None,
    }
}

/// ```prism
/// IsLateBundleName: fn Env, Text -> Bool
/// ```
pub fn is_late_bundle_name_f(me_p0: &crate::lower::types::Env, nkey_p1: &crate::prelude::Text) -> bool {
    match crate::prelude::get(&me_p0.names_p, nkey_p1) {
        ::std::option::Option::Some(crate::lower::types::Bn::BnParts(_)) => true,
        ::std::option::Option::None => true,
        _ => false,
    }
}

/// ```prism
/// HasLatePlainPart: unbounded fn Lx, Env, Env, Expr -> Bool
/// ```
pub fn has_late_plain_part_f(lx_p0: &crate::lower::Lx, fns_p1: &crate::lower::types::Env, me_p2: &crate::lower::types::Env, tuple_p3: &crate::syntax::Expr) -> bool {
    match &*crate::lower::node_::static_::ungrouped_f(tuple_p3).kind_p {
        crate::syntax::ExprKind::ETuple(xs_p4) => crate::prelude::run_to_end(crate::prelude::fold_job(xs_p4.clone(), false, {
            let lx_p0x = lx_p0.clone();
            let fns_p1x = fns_p1.clone();
            let me_p2x = me_p2.clone();
            ::std::rc::Rc::new(move |(p0, p1): (bool, crate::syntax::Expr)| {
                let lx_p0xy = lx_p0x.clone();
                let fns_p1xy = fns_p1x.clone();
                let me_p2xy = me_p2x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let found_p5 = p0;
                    let y_p6 = p1;
                    ::prism_rtl::Turn::Finished(found_p5 || (if crate::lower::types::is_bundle_f(&crate::lower::type_at_f(&lx_p0xy, &y_p6.span_p)) {
                        has_late_plain_part_f(&lx_p0xy, &fns_p1xy, &me_p2xy, &y_p6)
                    } else {
                        is_plain_part_ty_f(&crate::lower::type_at_f(&lx_p0xy, &y_p6.span_p)) && reads_late_via_f(&fns_p1xy, &me_p2xy, &y_p6)
                    }))
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::syntax::Expr)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
        })),
        _ => false,
    }
}

/// ```prism
/// IsPlainPartTy: fn Ty -> Bool
/// ```
pub fn is_plain_part_ty_f(t_p0: &crate::check::types::Ty) -> bool {
    !(((&crate::lower::types::layer_of_f(t_p0) == &crate::lower::types::Layer::LyEv) || (&crate::lower::types::layer_of_f(t_p0) == &crate::lower::types::Layer::LyDyn)) || crate::lower::types::is_bundle_f(t_p0))
}

/// ```prism
/// MarkLateBundle: unbounded fn Wx, Env, Env, Stmt -> ((Wx, Env, Env, Bool))
/// ```
pub fn mark_late_bundle_f(wx_p0: &crate::lower::node_::Wx, be_p1: &crate::lower::types::Env, me_p2: &crate::lower::types::Env, s_p3: &crate::syntax::Stmt) -> (crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env, bool) {
    match &s_p3.kind_p {
        crate::syntax::StmtKind::SLet(p_p4, _, e_p5) => match bundle_written_o(&wx_p0.lx_p, p_p4, e_p5) {
            ::std::option::Option::Some((n_p6, _)) => {
                let nkey_p7 = crate::check::env::sname_key_f(&n_p6);
                let marker_p8 = crate::lower::types::Bn::BnLocal(crate::lower::expr::refusal_f(&crate::prelude::Text::from(format!("the bundle `{}`, whose plain part reads a late result, read as one value at its block\'s build", &nkey_p7))), crate::lower::types::Holding::Owned, crate::lower::model::OutTy::OutUnit);
                (wx_p0.clone(), crate::lower::types::bind_f(&crate::lower::types::bind_f(be_p1, &crate::prelude::Text::from(format!("{}#late", &nkey_p7)), &marker_p8), &crate::prelude::Text::from(format!("{}#latebundle", &nkey_p7)), &marker_p8), crate::lower::types::bind_f(&crate::lower::types::bind_f(me_p2, &crate::prelude::Text::from(format!("{}#late", &nkey_p7)), &marker_p8), &crate::prelude::Text::from(format!("{}#latebundle", &nkey_p7)), &marker_p8), true)
            },
            ::std::option::Option::None => match late_bundle_alias_o(me_p2, p_p4, e_p5) {
                ::std::option::Option::Some(n_p9) => {
                    let marker_pa = crate::lower::types::Bn::BnLocal(crate::lower::expr::refusal_f(&crate::prelude::Text::from(format!("the bundle `{}`, another name of a late bundle, read as one value at its block\'s build", &crate::check::env::sname_key_f(&n_p9)))), crate::lower::types::Holding::Owned, crate::lower::model::OutTy::OutUnit);
                    (wx_p0.clone(), crate::lower::types::bind_f(be_p1, &crate::prelude::Text::from(format!("{}#late", &crate::check::env::sname_key_f(&n_p9))), &marker_pa), crate::lower::types::bind_f(me_p2, &crate::prelude::Text::from(format!("{}#late", &crate::check::env::sname_key_f(&n_p9))), &marker_pa), true)
                },
                ::std::option::Option::None => (wx_p0.clone(), be_p1.clone(), me_p2.clone(), false),
            },
        },
        _ => (wx_p0.clone(), be_p1.clone(), me_p2.clone(), false),
    }
}

/// The step machine of `MarkLateBundle`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// MarkLateBundle: unbounded fn Wx, Env, Env, Stmt -> ((Wx, Env, Env, Bool))
/// ```
pub struct MarkLateBundle {
    pub wx_p0: crate::lower::node_::Wx,
    pub be_p1: crate::lower::types::Env,
    pub me_p2: crate::lower::types::Env,
    pub s_p3: crate::syntax::Stmt,
}

impl ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env, bool)> for MarkLateBundle {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env, bool)> {
        let wx_p0 = &self.wx_p0;
        let be_p1 = &self.be_p1;
        let me_p2 = &self.me_p2;
        let s_p3 = &self.s_p3;
        match &s_p3.kind_p {
            crate::syntax::StmtKind::SLet(p_p4, _, e_p5) => {
                let be_p1x = be_p1.clone();
                let e_p5x = e_p5.clone();
                let me_p2x = me_p2.clone();
                let p_p4x = p_p4.clone();
                let wx_p0x = wx_p0.clone();
                crate::prelude::call_then(start_bundle_written_o(wx_p0x.lx_p.clone(), p_p4x.clone(), e_p5x.clone()), move |bundle_written_o_81265: ::std::option::Option<(crate::syntax::SName, crate::syntax::Expr)>| match bundle_written_o_81265 {
                    ::std::option::Option::Some((n_p6, _)) => {
                        let nkey_p7 = crate::check::env::sname_key_f(&n_p6);
                        let marker_p8 = crate::lower::types::Bn::BnLocal(crate::lower::expr::refusal_f(&crate::prelude::Text::from(format!("the bundle `{}`, whose plain part reads a late result, read as one value at its block\'s build", &nkey_p7))), crate::lower::types::Holding::Owned, crate::lower::model::OutTy::OutUnit);
                        ::prism_rtl::Turn::Finished((wx_p0x.clone(), crate::lower::types::bind_f(&crate::lower::types::bind_f(&be_p1x, &crate::prelude::Text::from(format!("{}#late", &nkey_p7)), &marker_p8), &crate::prelude::Text::from(format!("{}#latebundle", &nkey_p7)), &marker_p8), crate::lower::types::bind_f(&crate::lower::types::bind_f(&me_p2x, &crate::prelude::Text::from(format!("{}#late", &nkey_p7)), &marker_p8), &crate::prelude::Text::from(format!("{}#latebundle", &nkey_p7)), &marker_p8), true))
                    },
                    ::std::option::Option::None => match late_bundle_alias_o(&me_p2x, &p_p4x, &e_p5x) {
                        ::std::option::Option::Some(n_p9) => {
                            let marker_pa = crate::lower::types::Bn::BnLocal(crate::lower::expr::refusal_f(&crate::prelude::Text::from(format!("the bundle `{}`, another name of a late bundle, read as one value at its block\'s build", &crate::check::env::sname_key_f(&n_p9)))), crate::lower::types::Holding::Owned, crate::lower::model::OutTy::OutUnit);
                            ::prism_rtl::Turn::Finished((wx_p0x.clone(), crate::lower::types::bind_f(&be_p1x, &crate::prelude::Text::from(format!("{}#late", &crate::check::env::sname_key_f(&n_p9))), &marker_pa), crate::lower::types::bind_f(&me_p2x, &crate::prelude::Text::from(format!("{}#late", &crate::check::env::sname_key_f(&n_p9))), &marker_pa), true))
                        },
                        ::std::option::Option::None => ::prism_rtl::Turn::Finished((wx_p0x.clone(), be_p1x.clone(), me_p2x.clone(), false)),
                    },
                })
            },
            _ => ::prism_rtl::Turn::Finished((wx_p0.clone(), be_p1.clone(), me_p2.clone(), false)),
        }
    }
}

/// `Start MarkLateBundle, x`: what the function value is when passed to `@Run`.
pub fn start_mark_late_bundle_f(wx_p0: crate::lower::node_::Wx, be_p1: crate::lower::types::Env, me_p2: crate::lower::types::Env, s_p3: crate::syntax::Stmt) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env, bool)>> {
    ::std::rc::Rc::new(MarkLateBundle { wx_p0, be_p1, me_p2, s_p3 })
}

/// ```prism
/// LateBundleLet: unbounded fn Wx, Env, Env, SName, Expr -> ((Wx, Env, Env))
/// ```
pub fn late_bundle_let_f(wx_p0: &crate::lower::node_::Wx, benv_p1: &crate::lower::types::Env, menv_p2: &crate::lower::types::Env, n_p3: &crate::syntax::SName, tuple_p4: &crate::syntax::Expr) -> (crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env) {
    let nkey_p5 = crate::check::env::sname_key_f(n_p3);
    let (wx2_p6, builds_p7, methods_p8) = late_bundle_parts_f(wx_p0, benv_p1, menv_p2, &nkey_p5, &crate::lower::local_name_at_f(&wx_p0.lx_p, &nkey_p5, &n_p3.span_p), tuple_p4);
    let (wx3_p9, me3_pa) = late_bundle_value_f(&wx2_p6, &crate::lower::types::bind_f(menv_p2, &nkey_p5, &crate::lower::types::Bn::BnParts(methods_p8.clone())), &nkey_p5, &crate::lower::local_name_at_f(&wx_p0.lx_p, &nkey_p5, &n_p3.span_p), &methods_p8, &crate::lower::types::out_ty_of_f(&wx_p0.lx_p, &crate::lower::type_at_f(&wx_p0.lx_p, &tuple_p4.span_p)));
    (wx3_p9.clone(), crate::lower::types::bind_f(benv_p1, &nkey_p5, &crate::lower::types::Bn::BnParts(builds_p7.clone())), me3_pa.clone())
}

/// The step machine of `LateBundleLet`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LateBundleLet: unbounded fn Wx, Env, Env, SName, Expr -> ((Wx, Env, Env))
/// ```
pub struct LateBundleLet {
    pub wx_p0: crate::lower::node_::Wx,
    pub benv_p1: crate::lower::types::Env,
    pub menv_p2: crate::lower::types::Env,
    pub n_p3: crate::syntax::SName,
    pub tuple_p4: crate::syntax::Expr,
}

impl ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)> for LateBundleLet {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)> {
        let wx_p0 = &self.wx_p0;
        let benv_p1 = &self.benv_p1;
        let menv_p2 = &self.menv_p2;
        let n_p3 = &self.n_p3;
        let tuple_p4 = &self.tuple_p4;
        let nkey_p5 = crate::check::env::sname_key_f(n_p3);
        let benv_p1x = benv_p1.clone();
        let menv_p2x = menv_p2.clone();
        let n_p3x = n_p3.clone();
        let tuple_p4x = tuple_p4.clone();
        let wx_p0x = wx_p0.clone();
        crate::prelude::call_then(crate::lower::start_local_name_at_f(wx_p0x.lx_p.clone(), nkey_p5.clone(), n_p3x.span_p.clone()), move |local_name_at_f_82823: crate::prelude::Text| {
            let (wx2_p6, builds_p7, methods_p8) = late_bundle_parts_f(&wx_p0x, &benv_p1x, &menv_p2x, &nkey_p5, &local_name_at_f_82823, &tuple_p4x);
            crate::prelude::call_then(crate::lower::start_local_name_at_f(wx_p0x.lx_p.clone(), nkey_p5.clone(), n_p3x.span_p.clone()), move |local_name_at_f_83043: crate::prelude::Text| crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(wx_p0x.lx_p.clone(), crate::lower::type_at_f(&wx_p0x.lx_p, &tuple_p4x.span_p)), move |out_ty_of_f_83087: crate::lower::model::OutTy| crate::prelude::call_then(start_late_bundle_value_f(wx2_p6.clone(), crate::lower::types::bind_f(&menv_p2x, &nkey_p5, &crate::lower::types::Bn::BnParts(methods_p8.clone())), nkey_p5.clone(), local_name_at_f_83043, methods_p8.clone(), out_ty_of_f_83087), move |late_bundle_value_f_82977: (crate::lower::node_::Wx, crate::lower::types::Env)| {
                let (wx3_p9, me3_pa) = late_bundle_value_f_82977;
                ::prism_rtl::Turn::Finished((wx3_p9.clone(), crate::lower::types::bind_f(&benv_p1x, &nkey_p5, &crate::lower::types::Bn::BnParts(builds_p7.clone())), me3_pa.clone()))
            })))
        })
    }
}

/// `Start LateBundleLet, x`: what the function value is when passed to `@Run`.
pub fn start_late_bundle_let_f(wx_p0: crate::lower::node_::Wx, benv_p1: crate::lower::types::Env, menv_p2: crate::lower::types::Env, n_p3: crate::syntax::SName, tuple_p4: crate::syntax::Expr) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>> {
    ::std::rc::Rc::new(LateBundleLet { wx_p0, benv_p1, menv_p2, n_p3, tuple_p4 })
}

/// ```prism
/// LateBundleParts: unbounded fn Wx, Env, Env, Text, Text, Expr -> ((Wx, [?Bn], [?Bn]))
/// ```
pub fn late_bundle_parts_f(wx_p0: &crate::lower::node_::Wx, benv_p1: &crate::lower::types::Env, menv_p2: &crate::lower::types::Env, nkey_p3: &crate::prelude::Text, stem_p4: &crate::prelude::Text, tuple_p5: &crate::syntax::Expr) -> (crate::lower::node_::Wx, crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>, crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>) {
    let es_p6 = match &*crate::lower::node_::static_::ungrouped_f(tuple_p5).kind_p {
        crate::syntax::ExprKind::ETuple(xs_p7) => xs_p7.clone(),
        _ => crate::prelude::Array::new(),
    };
    crate::prelude::run_to_end(crate::prelude::fold_job(es_p6.clone(), (wx_p0.clone(), crate::prelude::Array::new(), crate::prelude::Array::new()), {
        let menv_p2x = menv_p2.clone();
        let benv_p1x = benv_p1.clone();
        let nkey_p3x = nkey_p3.clone();
        let stem_p4x = stem_p4.clone();
        ::std::rc::Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>, crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>), crate::syntax::Expr)| {
            let menv_p2xy = menv_p2x.clone();
            let benv_p1xy = benv_p1x.clone();
            let nkey_p3xy = nkey_p3x.clone();
            let stem_p4xy = stem_p4x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (w_p8, builds_p9, methods_pa) = p0;
                let y_pb = p1;
                {
                    let lx_pc = w_p8.lx_p.clone();
                    let i_pd = crate::prelude::len(&builds_p9);
                    let ty_pe = crate::lower::type_at_f(&lx_pc, &y_pb.span_p);
                    if crate::lower::types::is_bundle_f(&ty_pe) && has_late_plain_part_f(&lx_pc, &menv_p2xy, &menv_p2xy, &y_pb) {
                        {
                            let (w2_pf, bs_pg, ms_ph) = late_bundle_parts_f(&w_p8, &benv_p1xy, &menv_p2xy, &nkey_p3xy, &crate::prelude::Text::from(format!("{}_{}", &stem_p4xy, &i_pd)), &y_pb);
                            ::prism_rtl::Turn::Finished((w2_pf.clone(), crate::prelude::append(&builds_p9, &crate::prelude::Array::from(vec![::std::option::Option::Some(crate::lower::types::Bn::BnParts(bs_pg.clone()))])), crate::prelude::append(&methods_pa, &crate::prelude::Array::from(vec![::std::option::Option::Some(crate::lower::types::Bn::BnParts(ms_ph.clone()))]))))
                        }
                    } else {
                        if is_plain_part_ty_f(&ty_pe) && reads_late_f(&menv_p2xy, &y_pb) {
                            crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_pc.clone(), crate::lower::types::peel_f(&ty_pe)), move |out_ty_of_f_83887: crate::lower::model::OutTy| {
                                let t_pi = out_ty_of_f_83887;
                                let (getter_pl, w1_pm) = crate::lower::node_::fresh_name_f(&w_p8, &crate::prelude::Text::from(format!("late_{}_p{}", &stem_p4xy, &i_pd)));
                                let w2_pj = {
                                    let mut this: crate::lower::node_::Wx = w1_pm.clone();
                                    this.getters_p = crate::prelude::push(&this.getters_p, &crate::lower::model::MethDef { name_p: getter_pl.clone(), recv_p: crate::lower::model::Recv::RecvRef, params_p: crate::prelude::Array::new(), cx_p: crate::lower::model::CxArg::CxNone, ret_p: t_pi.clone(), body_p: crate::prelude::Array::new(), tail_p: crate::lower::types::own_f(&crate::lower::expr::value_of_f(&lx_pc, &menv_p2xy, &y_pb)), doc_p: crate::prelude::Text::from(format!("A plain part of the bundle `{}` that reads a late result: computed from the node once the row that gives the result is built.", &nkey_p3xy)) });
                                    this
                                };
                                let unbuilt_pk = crate::lower::types::Bn::BnLocal(crate::lower::expr::refusal_f(&crate::prelude::Text::from(format!("a late plain part of the bundle `{}` read at its block\'s build by a line of the block\'s node", &nkey_p3xy))), crate::lower::types::Holding::Owned, t_pi.clone());
                                ::prism_rtl::Turn::Finished((w2_pj.clone(), crate::prelude::append(&builds_p9, &crate::prelude::Array::from(vec![::std::option::Option::Some(unbuilt_pk.clone())])), crate::prelude::append(&methods_pa, &crate::prelude::Array::from(vec![::std::option::Option::Some(crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), getter_pl.clone(), crate::prelude::Array::new()), crate::lower::types::Holding::Owned, t_pi.clone()))]))))
                            })
                        } else {
                            crate::prelude::call_then(start_result_of_f(w_p8.clone(), benv_p1xy.clone(), menv_p2xy.clone(), y_pb.clone()), move |result_of_f_84630: (crate::lower::node_::Wres, crate::lower::node_::Wx)| {
                                let (res_pn, w1_po) = result_of_f_84630;
                                crate::prelude::call_then(start_fielded_parts_f(w1_po.clone(), crate::prelude::Text::from(format!("{}_{}", &stem_p4xy, &i_pd)), crate::prelude::Array::from(vec![res_pn.clone()])), move |fielded_parts_f_84689: (crate::lower::node_::Wx, crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>, crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>)| {
                                    let (w2_pp, bs_pq, ms_pr) = fielded_parts_f_84689;
                                    ::prism_rtl::Turn::Finished((w2_pp.clone(), crate::prelude::append(&builds_p9, &crate::prelude::Array::from(vec![part_of_o(&bs_pq, &crate::prelude::Nat::from(0u32))])), crate::prelude::append(&methods_pa, &crate::prelude::Array::from(vec![part_of_o(&ms_pr, &crate::prelude::Nat::from(0u32))]))))
                                })
                            })
                        }
                    }
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::lower::node_::Wx, crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>, crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>), crate::syntax::Expr)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>, crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>)>>>
    }))
}

/// ```prism
/// LatePartNames: unbounded fn Env, Stmt -> [SName]
/// ```
pub fn late_part_names_f(me_p0: &crate::lower::types::Env, s_p1: &crate::syntax::Stmt) -> crate::prelude::Array<crate::syntax::SName> {
    match &s_p1.kind_p {
        crate::syntax::StmtKind::SLet(p_p2, _, e_p3) => if !takes_late_bundle_f(me_p0, p_p2, e_p3) {
            crate::prelude::Array::new()
        } else {
            match &*ungrouped_pattern_f(p_p2).kind_p {
                crate::syntax::PatternKind::PTuple(ps_p4) => crate::prelude::run_to_end(crate::prelude::fold_job(ps_p4.clone(), crate::prelude::Array::new(), {
                    let me_p0x = me_p0.clone();
                    ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::syntax::SName>, crate::syntax::Pattern)| {
                        let me_p0xy = me_p0x.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let acc_p5 = p0;
                            let q_p6 = p1;
                            match &*q_p6.kind_p {
                                crate::syntax::PatternKind::PName(n_p7) => if is_time_name_f(&crate::check::env::sname_key_f(n_p7)) || crate::check::env::has_key_f(&me_p0xy.names_p, &crate::prelude::Text::from(format!("{}#late", &crate::check::env::sname_key_f(n_p7)))) {
                                    ::prism_rtl::Turn::Finished(acc_p5.clone())
                                } else {
                                    ::prism_rtl::Turn::Finished(crate::prelude::push(&acc_p5, n_p7))
                                },
                                _ => crate::prelude::call_then(start_binder_names_f(q_p6.clone()), move |binder_names_f_85775: crate::prelude::Array<crate::syntax::SName>| ::prism_rtl::Turn::Finished(crate::prelude::fold(&binder_names_f_85775, &acc_p5, &(|more_p8: &crate::prelude::Array<crate::syntax::SName>, n_p9: &crate::syntax::SName| if is_time_name_f(&crate::check::env::sname_key_f(n_p9)) || crate::check::env::has_key_f(&me_p0xy.names_p, &crate::prelude::Text::from(format!("{}#late", &crate::check::env::sname_key_f(n_p9)))) {
                                    more_p8.clone()
                                } else {
                                    crate::prelude::push(more_p8, n_p9)
                                })))),
                            }
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::syntax::SName>, crate::syntax::Pattern)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::syntax::SName>>>>
                })),
                _ => crate::prelude::Array::new(),
            }
        },
        _ => crate::prelude::Array::new(),
    }
}

/// The step machine of `LatePartNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LatePartNames: unbounded fn Env, Stmt -> [SName]
/// ```
pub struct LatePartNames {
    pub me_p0: crate::lower::types::Env,
    pub s_p1: crate::syntax::Stmt,
}

impl ::prism_rtl::Job<crate::prelude::Array<crate::syntax::SName>> for LatePartNames {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<crate::syntax::SName>> {
        let me_p0 = &self.me_p0;
        let s_p1 = &self.s_p1;
        match &s_p1.kind_p {
            crate::syntax::StmtKind::SLet(p_p2, _, e_p3) => {
                let e_p3x = e_p3.clone();
                let me_p0x = me_p0.clone();
                let p_p2x = p_p2.clone();
                crate::prelude::call_then(start_takes_late_bundle_f(me_p0x.clone(), p_p2x.clone(), e_p3x.clone()), move |takes_late_bundle_f_85359: bool| if !takes_late_bundle_f_85359 {
                    ::prism_rtl::Turn::Finished(crate::prelude::Array::new())
                } else {
                    match &*ungrouped_pattern_f(&p_p2x).kind_p {
                        crate::syntax::PatternKind::PTuple(ps_p4) => crate::prelude::fold_job(ps_p4.clone(), crate::prelude::Array::new(), {
                            let me_p0xx = me_p0x.clone();
                            ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::syntax::SName>, crate::syntax::Pattern)| {
                                let me_p0xxy = me_p0xx.clone();
                                crate::prelude::entered(crate::prelude::once_job(move || {
                                    let acc_p5 = p0;
                                    let q_p6 = p1;
                                    match &*q_p6.kind_p {
                                        crate::syntax::PatternKind::PName(n_p7) => if is_time_name_f(&crate::check::env::sname_key_f(n_p7)) || crate::check::env::has_key_f(&me_p0xxy.names_p, &crate::prelude::Text::from(format!("{}#late", &crate::check::env::sname_key_f(n_p7)))) {
                                            ::prism_rtl::Turn::Finished(acc_p5.clone())
                                        } else {
                                            ::prism_rtl::Turn::Finished(crate::prelude::push(&acc_p5, n_p7))
                                        },
                                        _ => crate::prelude::call_then(start_binder_names_f(q_p6.clone()), move |binder_names_f_85775: crate::prelude::Array<crate::syntax::SName>| ::prism_rtl::Turn::Finished(crate::prelude::fold(&binder_names_f_85775, &acc_p5, &(|more_p8: &crate::prelude::Array<crate::syntax::SName>, n_p9: &crate::syntax::SName| if is_time_name_f(&crate::check::env::sname_key_f(n_p9)) || crate::check::env::has_key_f(&me_p0xxy.names_p, &crate::prelude::Text::from(format!("{}#late", &crate::check::env::sname_key_f(n_p9)))) {
                                            more_p8.clone()
                                        } else {
                                            crate::prelude::push(more_p8, n_p9)
                                        })))),
                                    }
                                }))
                            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::syntax::SName>, crate::syntax::Pattern)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::syntax::SName>>>>
                        }).cycle(),
                        _ => ::prism_rtl::Turn::Finished(crate::prelude::Array::new()),
                    }
                })
            },
            _ => ::prism_rtl::Turn::Finished(crate::prelude::Array::new()),
        }
    }
}

/// `Start LatePartNames, x`: what the function value is when passed to `@Run`.
pub fn start_late_part_names_f(me_p0: crate::lower::types::Env, s_p1: crate::syntax::Stmt) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::syntax::SName>>> {
    ::std::rc::Rc::new(LatePartNames { me_p0, s_p1 })
}

/// ```prism
/// TakesLateBundle: unbounded fn Env, Pattern, Expr -> Bool
/// ```
pub fn takes_late_bundle_f(me_p0: &crate::lower::types::Env, p_p1: &crate::syntax::Pattern, e_p2: &crate::syntax::Expr) -> bool {
    match ((*crate::lower::node_::static_::ungrouped_f(e_p2).kind_p).clone(), (*ungrouped_pattern_f(p_p1).kind_p).clone()) {
        (crate::syntax::ExprKind::EName(m_p3), crate::syntax::PatternKind::PTuple(_)) => ((&crate::prelude::len(&m_p3.path_p) == &crate::prelude::Nat::from(1u32)) && crate::check::env::has_key_f(&me_p0.names_p, &crate::prelude::Text::from(format!("{}#late", &crate::check::env::sname_key_f(&m_p3))))) && is_late_bundle_name_f(me_p0, &crate::check::env::sname_key_f(&m_p3)),
        _ => false,
    }
}

/// The step machine of `TakesLateBundle`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TakesLateBundle: unbounded fn Env, Pattern, Expr -> Bool
/// ```
pub struct TakesLateBundle {
    pub me_p0: crate::lower::types::Env,
    pub p_p1: crate::syntax::Pattern,
    pub e_p2: crate::syntax::Expr,
}

impl ::prism_rtl::Job<bool> for TakesLateBundle {
    fn cycle(&self) -> ::prism_rtl::Turn<bool> {
        let me_p0 = &self.me_p0;
        let p_p1 = &self.p_p1;
        let e_p2 = &self.e_p2;
        match ((*crate::lower::node_::static_::ungrouped_f(e_p2).kind_p).clone(), (*ungrouped_pattern_f(p_p1).kind_p).clone()) {
            (crate::syntax::ExprKind::EName(m_p3), crate::syntax::PatternKind::PTuple(_)) => ::prism_rtl::Turn::Finished(((&crate::prelude::len(&m_p3.path_p) == &crate::prelude::Nat::from(1u32)) && crate::check::env::has_key_f(&me_p0.names_p, &crate::prelude::Text::from(format!("{}#late", &crate::check::env::sname_key_f(&m_p3))))) && is_late_bundle_name_f(me_p0, &crate::check::env::sname_key_f(&m_p3))),
            _ => ::prism_rtl::Turn::Finished(false),
        }
    }
}

/// `Start TakesLateBundle, x`: what the function value is when passed to `@Run`.
pub fn start_takes_late_bundle_f(me_p0: crate::lower::types::Env, p_p1: crate::syntax::Pattern, e_p2: crate::syntax::Expr) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>> {
    ::std::rc::Rc::new(TakesLateBundle { me_p0, p_p1, e_p2 })
}

/// ```prism
/// UngroupedPattern: fn Pattern -> Pattern
/// ```
pub fn ungrouped_pattern_f(p_p0: &crate::syntax::Pattern) -> crate::syntax::Pattern {
    match &*p_p0.kind_p {
        crate::syntax::PatternKind::PGroup(q_p1) => ungrouped_pattern_f(&**q_p1),
        _ => p_p0.clone(),
    }
}

/// ```prism
/// LateLetNames: unbounded fn Lx, Env, Env, Stmt -> [SName]
/// ```
pub fn late_let_names_f(lx_p0: &crate::lower::Lx, fns_p1: &crate::lower::types::Env, me_p2: &crate::lower::types::Env, s_p3: &crate::syntax::Stmt) -> crate::prelude::Array<crate::syntax::SName> {
    match &s_p3.kind_p {
        crate::syntax::StmtKind::SLet(p_p4, _, e_p5) => {
            let names_p6 = binder_names_f(p_p4);
            let plain_p7 = crate::prelude::run_to_end(crate::prelude::fold_job(names_p6.clone(), true, {
                let lx_p0x = lx_p0.clone();
                let me_p2x = me_p2.clone();
                ::std::rc::Rc::new(move |(p0, p1): (bool, crate::syntax::SName)| {
                    let lx_p0xy = lx_p0x.clone();
                    let me_p2xy = me_p2x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let ok_p8 = p0;
                        let n_p9 = p1;
                        {
                            let nkey_pa = crate::check::env::sname_key_f(&n_p9);
                            let full_pb = crate::lower::binder_ty_f(&lx_p0xy, &n_p9.span_p);
                            ::prism_rtl::Turn::Finished(ok_p8 && !((((((is_time_name_f(&nkey_pa) || crate::check::env::has_key_f(&me_p2xy.names_p, &crate::prelude::Text::from(format!("{}#late", &nkey_pa)))) || crate::check::env::has_key_f(&me_p2xy.names_p, &crate::prelude::Text::from(format!("{}#placed", &nkey_pa)))) || (&crate::lower::types::layer_of_f(&full_pb) != &crate::lower::types::Layer::LyPlain)) || crate::lower::types::time_within_f(&full_pb)) || crate::lower::types::is_bundle_f(&full_pb)) || crate::lower::node_::switch_::is_some_f(&many_instances_o(&lx_p0xy, &n_p9.span_p))))
                        }
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::syntax::SName)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
            }));
            if ((&crate::prelude::len(&names_p6) > &crate::prelude::Nat::from(0u32)) && plain_p7) && reads_late_via_f(fns_p1, me_p2, e_p5) {
                names_p6.clone()
            } else {
                crate::prelude::Array::new()
            }
        },
        _ => crate::prelude::Array::new(),
    }
}

/// The step machine of `LateLetNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LateLetNames: unbounded fn Lx, Env, Env, Stmt -> [SName]
/// ```
pub struct LateLetNames {
    pub lx_p0: crate::lower::Lx,
    pub fns_p1: crate::lower::types::Env,
    pub me_p2: crate::lower::types::Env,
    pub s_p3: crate::syntax::Stmt,
}

impl ::prism_rtl::Job<crate::prelude::Array<crate::syntax::SName>> for LateLetNames {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<crate::syntax::SName>> {
        let lx_p0 = &self.lx_p0;
        let fns_p1 = &self.fns_p1;
        let me_p2 = &self.me_p2;
        let s_p3 = &self.s_p3;
        match &s_p3.kind_p {
            crate::syntax::StmtKind::SLet(p_p4, _, e_p5) => {
                let e_p5x = e_p5.clone();
                let fns_p1x = fns_p1.clone();
                let lx_p0x = lx_p0.clone();
                let me_p2x = me_p2.clone();
                let p_p4x = p_p4.clone();
                crate::prelude::call_then(start_binder_names_f(p_p4x.clone()), move |binder_names_f_86852: crate::prelude::Array<crate::syntax::SName>| {
                    let names_p6 = binder_names_f_86852;
                    crate::prelude::call_value(crate::prelude::fold_job(names_p6.clone(), true, {
                        let lx_p0xx = lx_p0x.clone();
                        let me_p2xx = me_p2x.clone();
                        ::std::rc::Rc::new(move |(p0, p1): (bool, crate::syntax::SName)| {
                            let lx_p0xxy = lx_p0xx.clone();
                            let me_p2xxy = me_p2xx.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let ok_p8 = p0;
                                let n_p9 = p1;
                                {
                                    let nkey_pa = crate::check::env::sname_key_f(&n_p9);
                                    let full_pb = crate::lower::binder_ty_f(&lx_p0xxy, &n_p9.span_p);
                                    ::prism_rtl::Turn::Finished(ok_p8 && !((((((is_time_name_f(&nkey_pa) || crate::check::env::has_key_f(&me_p2xxy.names_p, &crate::prelude::Text::from(format!("{}#late", &nkey_pa)))) || crate::check::env::has_key_f(&me_p2xxy.names_p, &crate::prelude::Text::from(format!("{}#placed", &nkey_pa)))) || (&crate::lower::types::layer_of_f(&full_pb) != &crate::lower::types::Layer::LyPlain)) || crate::lower::types::time_within_f(&full_pb)) || crate::lower::types::is_bundle_f(&full_pb)) || crate::lower::node_::switch_::is_some_f(&many_instances_o(&lx_p0xxy, &n_p9.span_p))))
                                }
                            }))
                        }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::syntax::SName)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
                    }), move |fold_86886: bool| {
                        let plain_p7 = fold_86886;
                        if ((&crate::prelude::len(&names_p6) > &crate::prelude::Nat::from(0u32)) && plain_p7) && reads_late_via_f(&fns_p1x, &me_p2x, &e_p5x) {
                            ::prism_rtl::Turn::Finished(names_p6.clone())
                        } else {
                            ::prism_rtl::Turn::Finished(crate::prelude::Array::new())
                        }
                    })
                })
            },
            _ => ::prism_rtl::Turn::Finished(crate::prelude::Array::new()),
        }
    }
}

/// `Start LateLetNames, x`: what the function value is when passed to `@Run`.
pub fn start_late_let_names_f(lx_p0: crate::lower::Lx, fns_p1: crate::lower::types::Env, me_p2: crate::lower::types::Env, s_p3: crate::syntax::Stmt) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::syntax::SName>>> {
    ::std::rc::Rc::new(LateLetNames { lx_p0, fns_p1, me_p2, s_p3 })
}

/// ```prism
/// IsLateBundleLet: fn Env, Pattern -> Bool
/// ```
pub fn is_late_bundle_let_f(menv_p0: &crate::lower::types::Env, p_p1: &crate::syntax::Pattern) -> bool {
    match &*p_p1.kind_p {
        crate::syntax::PatternKind::PName(n_p2) => crate::check::env::has_key_f(&menv_p0.names_p, &crate::prelude::Text::from(format!("{}#latebundle", &crate::check::env::sname_key_f(n_p2)))),
        crate::syntax::PatternKind::PGroup(q_p3) => is_late_bundle_let_f(menv_p0, &**q_p3),
        _ => false,
    }
}

/// ```prism
/// IsLateLet: unbounded fn Env, Pattern -> Bool
/// ```
pub fn is_late_let_f(menv_p0: &crate::lower::types::Env, p_p1: &crate::syntax::Pattern) -> bool {
    let names_p2 = binder_names_f(p_p1);
    (&crate::prelude::len(&names_p2) > &crate::prelude::Nat::from(0u32)) && crate::prelude::fold(&names_p2, &true, &(|ok_p3: &bool, n_p4: &crate::syntax::SName| *ok_p3 && crate::check::env::has_key_f(&menv_p0.names_p, &crate::prelude::Text::from(format!("{}#late", &crate::check::env::sname_key_f(n_p4))))))
}

/// The step machine of `IsLateLet`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// IsLateLet: unbounded fn Env, Pattern -> Bool
/// ```
pub struct IsLateLet {
    pub menv_p0: crate::lower::types::Env,
    pub p_p1: crate::syntax::Pattern,
}

impl ::prism_rtl::Job<bool> for IsLateLet {
    fn cycle(&self) -> ::prism_rtl::Turn<bool> {
        let menv_p0 = &self.menv_p0;
        let p_p1 = &self.p_p1;
        let menv_p0x = menv_p0.clone();
        let p_p1x = p_p1.clone();
        crate::prelude::call_then(start_binder_names_f(p_p1x.clone()), move |binder_names_f_87716: crate::prelude::Array<crate::syntax::SName>| {
            let names_p2 = binder_names_f_87716;
            ::prism_rtl::Turn::Finished((&crate::prelude::len(&names_p2) > &crate::prelude::Nat::from(0u32)) && crate::prelude::fold(&names_p2, &true, &(|ok_p3: &bool, n_p4: &crate::syntax::SName| *ok_p3 && crate::check::env::has_key_f(&menv_p0x.names_p, &crate::prelude::Text::from(format!("{}#late", &crate::check::env::sname_key_f(n_p4)))))))
        })
    }
}

/// `Start IsLateLet, x`: what the function value is when passed to `@Run`.
pub fn start_is_late_let_f(menv_p0: crate::lower::types::Env, p_p1: crate::syntax::Pattern) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>> {
    ::std::rc::Rc::new(IsLateLet { menv_p0, p_p1 })
}

/// ```prism
/// LateLetGetters: unbounded fn Wx, Env, [Stmt] -> Wx
/// ```
pub fn late_let_getters_f(wx_p0: &crate::lower::node_::Wx, menv_p1: &crate::lower::types::Env, stmts_p2: &crate::prelude::Array<crate::syntax::Stmt>) -> crate::lower::node_::Wx {
    crate::prelude::run_to_end(crate::prelude::fold_job(stmts_p2.clone(), wx_p0.clone(), {
        let menv_p1x = menv_p1.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::lower::node_::Wx, crate::syntax::Stmt)| {
            let menv_p1xy = menv_p1x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let w_p3 = p0;
                let s_p4 = p1;
                match &s_p4.kind_p {
                    crate::syntax::StmtKind::SLet(p_p5, _, e_p6) => {
                        let e_p6x = e_p6.clone();
                        let p_p5x = p_p5.clone();
                        crate::prelude::call_then(start_is_late_let_f(menv_p1xy.clone(), p_p5x.clone()), move |is_late_let_f_88160: bool| if !is_late_let_f_88160 || takes_late_bundle_f(&menv_p1xy, &p_p5x, &e_p6x) {
                            ::prism_rtl::Turn::Finished(w_p3.clone())
                        } else {
                            match &*p_p5x.kind_p {
                                crate::syntax::PatternKind::PName(n_p7) => 'm88250: {
                                    let scrutinee = &crate::prelude::get(&menv_p1xy.names_p, &crate::check::env::sname_key_f(n_p7));
                                    if let ::std::option::Option::Some(crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XMethod(m88250_0_0_0, getter_p8, _), _, t_p9)) = scrutinee && let crate::lower::model::Ex::XSelf = &**m88250_0_0_0 {
                                        break 'm88250 ::prism_rtl::Turn::Finished({
                                            let mut this: crate::lower::node_::Wx = w_p3.clone();
                                            this.getters_p = crate::prelude::push(&this.getters_p, &crate::lower::model::MethDef { name_p: getter_p8.clone(), recv_p: crate::lower::model::Recv::RecvRef, params_p: crate::prelude::Array::new(), cx_p: crate::lower::model::CxArg::CxNone, ret_p: t_p9.clone(), body_p: crate::prelude::Array::new(), tail_p: crate::lower::types::own_f(&crate::lower::expr::value_of_f(&w_p3.lx_p, &menv_p1xy, &e_p6x)), doc_p: crate::prelude::Text::from(format!("`{}`, a `let` that reads a late result: computed from the node once the row that gives the result is built.", &crate::check::env::sname_key_f(n_p7))) });
                                            this
                                        });
                                    }
                                    ::prism_rtl::Turn::Finished(w_p3.clone())
                                },
                                _ => {
                                    let ty_pa = crate::lower::types::peel_f(&crate::lower::type_at_f(&w_p3.lx_p, &e_p6x.span_p));
                                    crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(w_p3.lx_p.clone(), ty_pa.clone()), move |out_ty_of_f_88757: crate::lower::model::OutTy| {
                                        let t_pb = out_ty_of_f_88757;
                                        let (whole_pe, w1_pf) = crate::lower::node_::fresh_name_f(&w_p3, &crate::prelude::Text::lit("late_whole"));
                                        crate::prelude::call_then(crate::lower::patterns::start_rust_pat_f(w_p3.lx_p.clone(), p_p5x.clone(), ty_pa.clone(), crate::lower::types::Holding::ByRef, crate::prelude::Text::lit("late_whole_value")), move |rust_pat_f_88852: crate::lower::patterns::PatOut| {
                                            let o_pc = rust_pat_f_88852;
                                            let w2_pd = {
                                                let mut this: crate::lower::node_::Wx = w1_pf.clone();
                                                this.getters_p = crate::prelude::push(&this.getters_p, &crate::lower::model::MethDef { name_p: whole_pe.clone(), recv_p: crate::lower::model::Recv::RecvRef, params_p: crate::prelude::Array::new(), cx_p: crate::lower::model::CxArg::CxNone, ret_p: t_pb.clone(), body_p: crate::prelude::Array::new(), tail_p: crate::lower::types::own_f(&crate::lower::expr::value_of_f(&w_p3.lx_p, &menv_p1xy, &e_p6x)), doc_p: crate::prelude::Text::from(format!("`{}`, the value a late `let`\'s pattern takes apart: computed from the node once the row that gives the late result is built.", &crate::lower::functions::src_text_f(&w_p3.lx_p, &w_p3.lx_p.file_p, &e_p6x.span_p))) });
                                                this
                                            };
                                            crate::prelude::call_then(start_binder_names_f(p_p5x.clone()), move |binder_names_f_89273: crate::prelude::Array<crate::syntax::SName>| ::prism_rtl::Turn::Finished(crate::prelude::fold(&binder_names_f_89273, &w2_pd, &(|w3_pg: &crate::lower::node_::Wx, n_ph: &crate::syntax::SName| 'm89302: {
                                                let scrutinee = &(crate::prelude::get(&menv_p1xy.names_p, &crate::check::env::sname_key_f(n_ph)), crate::prelude::fold(&o_pc.binds_p, &::std::option::Option::None, &(|found_oi: &::std::option::Option<crate::lower::types::Bn>, (k_pj, b_pk): &(crate::prelude::Text, crate::lower::types::Bn)| if k_pj == &crate::check::env::sname_key_f(n_ph) {
                                                    ::std::option::Option::Some(b_pk.clone())
                                                } else {
                                                    found_oi.clone()
                                                })));
                                                if let (::std::option::Option::Some(crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XMethod(m89302_0_0_0_0, getter_pl, _), _, bt_pm)), ::std::option::Option::Some(crate::lower::types::Bn::BnLocal(rs_pn, mode_po, vt_pp))) = scrutinee && let crate::lower::model::Ex::XSelf = &**m89302_0_0_0_0 {
                                                    break 'm89302 {
                                                        let arm_pq = crate::lower::model::XArm { pat_p: o_pc.pa_p.clone(), conds_p: o_pc.conds_p.clone(), body_p: crate::lower::types::own_f(&crate::lower::types::Vl::VlPlace(rs_pn.clone(), mode_po.clone(), vt_pp.clone())) };
                                                        let other_pr = crate::lower::model::XArm { pat_p: crate::lower::model::Pa::PaWild, conds_p: crate::prelude::Array::new(), body_p: crate::lower::model::Ex::XUnreachable };
                                                        let tail_ps = crate::lower::model::Ex::XBlock(crate::prelude::Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("late_whole_value"))), t_pb.clone()), crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), whole_pe.clone(), crate::prelude::Array::new()))]), ::std::rc::Rc::new(crate::lower::types::own_f(&crate::lower::expr::arms_value_f(&crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("late_whole_value")))), &crate::prelude::Array::from(vec![arm_pq.clone(), other_pr.clone()]), &crate::prelude::Text::lit("\'bound"), bt_pm))));
                                                        {
                                                            let mut this: crate::lower::node_::Wx = w3_pg.clone();
                                                            this.getters_p = crate::prelude::push(&this.getters_p, &crate::lower::model::MethDef { name_p: getter_pl.clone(), recv_p: crate::lower::model::Recv::RecvRef, params_p: crate::prelude::Array::new(), cx_p: crate::lower::model::CxArg::CxNone, ret_p: bt_pm.clone(), body_p: crate::prelude::Array::new(), tail_p: tail_ps.clone(), doc_p: crate::prelude::Text::from(format!("`{}`, a name of a `let`\'s pattern that reads a late result.", &crate::check::env::sname_key_f(n_ph))) });
                                                            this
                                                        }
                                                    };
                                                }
                                                {
                                                    let mut this: crate::lower::node_::Wx = w3_pg.clone();
                                                    this.build_p = crate::prelude::push(&this.build_p, &crate::lower::expr::internal_bug_do_f(&crate::prelude::Text::from(format!("the name `{}` of a late `let`\'s pattern, which the pattern does not bind", &crate::check::env::sname_key_f(n_ph)))));
                                                    this
                                                }
                                            }))))
                                        })
                                    })
                                },
                            }
                        })
                    },
                    _ => ::prism_rtl::Turn::Finished(w_p3.clone()),
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::node_::Wx, crate::syntax::Stmt)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::node_::Wx>>>
    }))
}

/// The step machine of `LateLetGetters`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LateLetGetters: unbounded fn Wx, Env, [Stmt] -> Wx
/// ```
pub struct LateLetGetters {
    pub wx_p0: crate::lower::node_::Wx,
    pub menv_p1: crate::lower::types::Env,
    pub stmts_p2: crate::prelude::Array<crate::syntax::Stmt>,
}

impl ::prism_rtl::Job<crate::lower::node_::Wx> for LateLetGetters {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::lower::node_::Wx> {
        let wx_p0 = &self.wx_p0;
        let menv_p1 = &self.menv_p1;
        let stmts_p2 = &self.stmts_p2;
        crate::prelude::fold_job(stmts_p2.clone(), wx_p0.clone(), {
            let menv_p1x = menv_p1.clone();
            ::std::rc::Rc::new(move |(p0, p1): (crate::lower::node_::Wx, crate::syntax::Stmt)| {
                let menv_p1xy = menv_p1x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let w_p3 = p0;
                    let s_p4 = p1;
                    match &s_p4.kind_p {
                        crate::syntax::StmtKind::SLet(p_p5, _, e_p6) => {
                            let e_p6x = e_p6.clone();
                            let p_p5x = p_p5.clone();
                            crate::prelude::call_then(start_is_late_let_f(menv_p1xy.clone(), p_p5x.clone()), move |is_late_let_f_88160: bool| if !is_late_let_f_88160 || takes_late_bundle_f(&menv_p1xy, &p_p5x, &e_p6x) {
                                ::prism_rtl::Turn::Finished(w_p3.clone())
                            } else {
                                match &*p_p5x.kind_p {
                                    crate::syntax::PatternKind::PName(n_p7) => 'm88250: {
                                        let scrutinee = &crate::prelude::get(&menv_p1xy.names_p, &crate::check::env::sname_key_f(n_p7));
                                        if let ::std::option::Option::Some(crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XMethod(m88250_0_0_0, getter_p8, _), _, t_p9)) = scrutinee && let crate::lower::model::Ex::XSelf = &**m88250_0_0_0 {
                                            break 'm88250 ::prism_rtl::Turn::Finished({
                                                let mut this: crate::lower::node_::Wx = w_p3.clone();
                                                this.getters_p = crate::prelude::push(&this.getters_p, &crate::lower::model::MethDef { name_p: getter_p8.clone(), recv_p: crate::lower::model::Recv::RecvRef, params_p: crate::prelude::Array::new(), cx_p: crate::lower::model::CxArg::CxNone, ret_p: t_p9.clone(), body_p: crate::prelude::Array::new(), tail_p: crate::lower::types::own_f(&crate::lower::expr::value_of_f(&w_p3.lx_p, &menv_p1xy, &e_p6x)), doc_p: crate::prelude::Text::from(format!("`{}`, a `let` that reads a late result: computed from the node once the row that gives the result is built.", &crate::check::env::sname_key_f(n_p7))) });
                                                this
                                            });
                                        }
                                        ::prism_rtl::Turn::Finished(w_p3.clone())
                                    },
                                    _ => {
                                        let ty_pa = crate::lower::types::peel_f(&crate::lower::type_at_f(&w_p3.lx_p, &e_p6x.span_p));
                                        crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(w_p3.lx_p.clone(), ty_pa.clone()), move |out_ty_of_f_88757: crate::lower::model::OutTy| {
                                            let t_pb = out_ty_of_f_88757;
                                            let (whole_pe, w1_pf) = crate::lower::node_::fresh_name_f(&w_p3, &crate::prelude::Text::lit("late_whole"));
                                            crate::prelude::call_then(crate::lower::patterns::start_rust_pat_f(w_p3.lx_p.clone(), p_p5x.clone(), ty_pa.clone(), crate::lower::types::Holding::ByRef, crate::prelude::Text::lit("late_whole_value")), move |rust_pat_f_88852: crate::lower::patterns::PatOut| {
                                                let o_pc = rust_pat_f_88852;
                                                let w2_pd = {
                                                    let mut this: crate::lower::node_::Wx = w1_pf.clone();
                                                    this.getters_p = crate::prelude::push(&this.getters_p, &crate::lower::model::MethDef { name_p: whole_pe.clone(), recv_p: crate::lower::model::Recv::RecvRef, params_p: crate::prelude::Array::new(), cx_p: crate::lower::model::CxArg::CxNone, ret_p: t_pb.clone(), body_p: crate::prelude::Array::new(), tail_p: crate::lower::types::own_f(&crate::lower::expr::value_of_f(&w_p3.lx_p, &menv_p1xy, &e_p6x)), doc_p: crate::prelude::Text::from(format!("`{}`, the value a late `let`\'s pattern takes apart: computed from the node once the row that gives the late result is built.", &crate::lower::functions::src_text_f(&w_p3.lx_p, &w_p3.lx_p.file_p, &e_p6x.span_p))) });
                                                    this
                                                };
                                                crate::prelude::call_then(start_binder_names_f(p_p5x.clone()), move |binder_names_f_89273: crate::prelude::Array<crate::syntax::SName>| ::prism_rtl::Turn::Finished(crate::prelude::fold(&binder_names_f_89273, &w2_pd, &(|w3_pg: &crate::lower::node_::Wx, n_ph: &crate::syntax::SName| 'm89302: {
                                                    let scrutinee = &(crate::prelude::get(&menv_p1xy.names_p, &crate::check::env::sname_key_f(n_ph)), crate::prelude::fold(&o_pc.binds_p, &::std::option::Option::None, &(|found_oi: &::std::option::Option<crate::lower::types::Bn>, (k_pj, b_pk): &(crate::prelude::Text, crate::lower::types::Bn)| if k_pj == &crate::check::env::sname_key_f(n_ph) {
                                                        ::std::option::Option::Some(b_pk.clone())
                                                    } else {
                                                        found_oi.clone()
                                                    })));
                                                    if let (::std::option::Option::Some(crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XMethod(m89302_0_0_0_0, getter_pl, _), _, bt_pm)), ::std::option::Option::Some(crate::lower::types::Bn::BnLocal(rs_pn, mode_po, vt_pp))) = scrutinee && let crate::lower::model::Ex::XSelf = &**m89302_0_0_0_0 {
                                                        break 'm89302 {
                                                            let arm_pq = crate::lower::model::XArm { pat_p: o_pc.pa_p.clone(), conds_p: o_pc.conds_p.clone(), body_p: crate::lower::types::own_f(&crate::lower::types::Vl::VlPlace(rs_pn.clone(), mode_po.clone(), vt_pp.clone())) };
                                                            let other_pr = crate::lower::model::XArm { pat_p: crate::lower::model::Pa::PaWild, conds_p: crate::prelude::Array::new(), body_p: crate::lower::model::Ex::XUnreachable };
                                                            let tail_ps = crate::lower::model::Ex::XBlock(crate::prelude::Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("late_whole_value"))), t_pb.clone()), crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), whole_pe.clone(), crate::prelude::Array::new()))]), ::std::rc::Rc::new(crate::lower::types::own_f(&crate::lower::expr::arms_value_f(&crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("late_whole_value")))), &crate::prelude::Array::from(vec![arm_pq.clone(), other_pr.clone()]), &crate::prelude::Text::lit("\'bound"), bt_pm))));
                                                            {
                                                                let mut this: crate::lower::node_::Wx = w3_pg.clone();
                                                                this.getters_p = crate::prelude::push(&this.getters_p, &crate::lower::model::MethDef { name_p: getter_pl.clone(), recv_p: crate::lower::model::Recv::RecvRef, params_p: crate::prelude::Array::new(), cx_p: crate::lower::model::CxArg::CxNone, ret_p: bt_pm.clone(), body_p: crate::prelude::Array::new(), tail_p: tail_ps.clone(), doc_p: crate::prelude::Text::from(format!("`{}`, a name of a `let`\'s pattern that reads a late result.", &crate::check::env::sname_key_f(n_ph))) });
                                                                this
                                                            }
                                                        };
                                                    }
                                                    {
                                                        let mut this: crate::lower::node_::Wx = w3_pg.clone();
                                                        this.build_p = crate::prelude::push(&this.build_p, &crate::lower::expr::internal_bug_do_f(&crate::prelude::Text::from(format!("the name `{}` of a late `let`\'s pattern, which the pattern does not bind", &crate::check::env::sname_key_f(n_ph)))));
                                                        this
                                                    }
                                                }))))
                                            })
                                        })
                                    },
                                }
                            })
                        },
                        _ => ::prism_rtl::Turn::Finished(w_p3.clone()),
                    }
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::node_::Wx, crate::syntax::Stmt)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::node_::Wx>>>
        }).cycle()
    }
}

/// `Start LateLetGetters, x`: what the function value is when passed to `@Run`.
pub fn start_late_let_getters_f(wx_p0: crate::lower::node_::Wx, menv_p1: crate::lower::types::Env, stmts_p2: crate::prelude::Array<crate::syntax::Stmt>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::node_::Wx>> {
    ::std::rc::Rc::new(LateLetGetters { wx_p0, menv_p1, stmts_p2 })
}

/// ```prism
/// PreInit: unbounded fn Wx, Env, Env, Stmt -> ((Wx, Env))
/// ```
pub fn pre_init_f(wx_p0: &crate::lower::node_::Wx, benv_p1: &crate::lower::types::Env, menv_p2: &crate::lower::types::Env, s_p3: &crate::syntax::Stmt) -> (crate::lower::node_::Wx, crate::lower::types::Env) {
    match &s_p3.kind_p {
        crate::syntax::StmtKind::SBind(p_p4, _, ::std::option::Option::Some(_)) => match binding_of_o(menv_p2, p_p4) {
            ::std::option::Option::Some(crate::lower::types::Bn::BnHold(f_p5, t_p6)) => {
                let wx2_p7 = {
                    let mut this: crate::lower::node_::Wx = wx_p0.clone();
                    this.inited_p = crate::check::types::add_text_f(&this.inited_p, &f_p5);
                    this
                };
                (wx2_p7.clone(), crate::lower::types::bind_f(benv_p1, &crate::prelude::Text::from(format!("{}#init", &pat_text_f(p_p4))), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(crate::prelude::Text::from(format!("{}_init", &f_p5))), crate::lower::types::Holding::Owned, t_p6)))
            },
            _ => (wx_p0.clone(), benv_p1.clone()),
        },
        crate::syntax::StmtKind::SBind(p_p8, placed_p9, ::std::option::Option::None) => match binding_of_o(menv_p2, p_p8) {
            ::std::option::Option::Some(crate::lower::types::Bn::BnHold(f_pa, t_pb)) => if !is_dynamic_place_f(&wx_p0.lx_p, placed_p9) {
                (wx_p0.clone(), benv_p1.clone())
            } else {
                {
                    let wx2_pc = {
                        let mut this: crate::lower::node_::Wx = wx_p0.clone();
                        this.inited_p = crate::check::types::add_text_f(&this.inited_p, &f_pa);
                        this
                    };
                    (wx2_pc.clone(), crate::lower::types::bind_f(benv_p1, &crate::prelude::Text::from(format!("{}#init", &pat_text_f(p_p8))), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(crate::prelude::Text::from(format!("{}_init", &f_pa))), crate::lower::types::Holding::Owned, t_pb)))
                }
            },
            ::std::option::Option::Some(crate::lower::types::Bn::BnParts(_)) => if !is_bundle_place_f(&wx_p0.lx_p, placed_p9) {
                (wx_p0.clone(), benv_p1.clone())
            } else {
                match &*p_p8.kind_p {
                    crate::syntax::PatternKind::PTuple(qs_pd) => crate::prelude::fold(qs_pd, &(wx_p0.clone(), benv_p1.clone()), &(|(w_pe, be_pf): &(crate::lower::node_::Wx, crate::lower::types::Env), q_pg: &crate::syntax::Pattern| match binding_of_name_o(menv_p2, q_pg) {
                        ::std::option::Option::Some(crate::lower::types::Bn::BnHold(f_ph, t_pi)) => {
                            let w2_pj = {
                                let mut this: crate::lower::node_::Wx = w_pe.clone();
                                this.inited_p = crate::check::types::add_text_f(&this.inited_p, &f_ph);
                                this
                            };
                            (w2_pj.clone(), crate::lower::types::bind_f(be_pf, &crate::prelude::Text::from(format!("{}#init", &pat_text_f(q_pg))), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(crate::prelude::Text::from(format!("{}_init", &f_ph))), crate::lower::types::Holding::Owned, t_pi)))
                        },
                        _ => (w_pe.clone(), be_pf.clone()),
                    })),
                    _ => (wx_p0.clone(), benv_p1.clone()),
                }
            },
            _ => (wx_p0.clone(), benv_p1.clone()),
        },
        crate::syntax::StmtKind::SLet(p_pk, _, e_pl) => 'm92321: {
            let scrutinee = &binding_of_o(menv_p2, p_pk);
            if let ::std::option::Option::Some(crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(m92321_0_0_0, rs_pm, _), _, t_pn)) = scrutinee && let crate::lower::model::Ex::XSelf = &**m92321_0_0_0 {
                break 'm92321 {
                    let (_, reads_pp) = crate::lower::node_::dynamics::dynamic_expr_f(wx_p0, menv_p2, e_pl);
                    let wx2_po = {
                        let mut this: crate::lower::node_::Wx = wx_p0.clone();
                        this.dyn_reads_p = crate::prelude::insert(&this.dyn_reads_p, rs_pm, &reads_pp);
                        this
                    };
                    if all_inited_f(&wx2_po, &reads_pp) && names_inited_f(benv_p1, e_pl) {
                        {
                            let wx3_pq = {
                                let mut this: crate::lower::node_::Wx = wx2_po.clone();
                                this.inited_p = crate::check::types::add_text_f(&this.inited_p, rs_pm);
                                this
                            };
                            (wx3_pq.clone(), crate::lower::types::bind_f(benv_p1, &crate::prelude::Text::from(format!("{}#init", &pat_text_f(p_pk))), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(crate::prelude::Text::from(format!("{}_init", rs_pm))), crate::lower::types::Holding::Owned, t_pn.clone())))
                        }
                    } else {
                        (wx2_po.clone(), benv_p1.clone())
                    }
                };
            }
            (wx_p0.clone(), benv_p1.clone())
        },
        _ => (wx_p0.clone(), benv_p1.clone()),
    }
}

/// The step machine of `PreInit`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PreInit: unbounded fn Wx, Env, Env, Stmt -> ((Wx, Env))
/// ```
pub struct PreInit {
    pub wx_p0: crate::lower::node_::Wx,
    pub benv_p1: crate::lower::types::Env,
    pub menv_p2: crate::lower::types::Env,
    pub s_p3: crate::syntax::Stmt,
}

impl ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env)> for PreInit {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::lower::node_::Wx, crate::lower::types::Env)> {
        let wx_p0 = &self.wx_p0;
        let benv_p1 = &self.benv_p1;
        let menv_p2 = &self.menv_p2;
        let s_p3 = &self.s_p3;
        match &s_p3.kind_p {
            crate::syntax::StmtKind::SBind(p_p4, _, ::std::option::Option::Some(_)) => match binding_of_o(menv_p2, p_p4) {
                ::std::option::Option::Some(crate::lower::types::Bn::BnHold(f_p5, t_p6)) => {
                    let wx2_p7 = {
                        let mut this: crate::lower::node_::Wx = wx_p0.clone();
                        this.inited_p = crate::check::types::add_text_f(&this.inited_p, &f_p5);
                        this
                    };
                    ::prism_rtl::Turn::Finished((wx2_p7.clone(), crate::lower::types::bind_f(benv_p1, &crate::prelude::Text::from(format!("{}#init", &pat_text_f(p_p4))), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(crate::prelude::Text::from(format!("{}_init", &f_p5))), crate::lower::types::Holding::Owned, t_p6.clone()))))
                },
                _ => ::prism_rtl::Turn::Finished((wx_p0.clone(), benv_p1.clone())),
            },
            crate::syntax::StmtKind::SBind(p_p8, placed_p9, ::std::option::Option::None) => match binding_of_o(menv_p2, p_p8) {
                ::std::option::Option::Some(crate::lower::types::Bn::BnHold(f_pa, t_pb)) => if !is_dynamic_place_f(&wx_p0.lx_p, placed_p9) {
                    ::prism_rtl::Turn::Finished((wx_p0.clone(), benv_p1.clone()))
                } else {
                    {
                        let wx2_pc = {
                            let mut this: crate::lower::node_::Wx = wx_p0.clone();
                            this.inited_p = crate::check::types::add_text_f(&this.inited_p, &f_pa);
                            this
                        };
                        ::prism_rtl::Turn::Finished((wx2_pc.clone(), crate::lower::types::bind_f(benv_p1, &crate::prelude::Text::from(format!("{}#init", &pat_text_f(p_p8))), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(crate::prelude::Text::from(format!("{}_init", &f_pa))), crate::lower::types::Holding::Owned, t_pb.clone()))))
                    }
                },
                ::std::option::Option::Some(crate::lower::types::Bn::BnParts(_)) => if !is_bundle_place_f(&wx_p0.lx_p, placed_p9) {
                    ::prism_rtl::Turn::Finished((wx_p0.clone(), benv_p1.clone()))
                } else {
                    match &*p_p8.kind_p {
                        crate::syntax::PatternKind::PTuple(qs_pd) => ::prism_rtl::Turn::Finished(crate::prelude::fold(qs_pd, &(wx_p0.clone(), benv_p1.clone()), &(|(w_pe, be_pf): &(crate::lower::node_::Wx, crate::lower::types::Env), q_pg: &crate::syntax::Pattern| match binding_of_name_o(menv_p2, q_pg) {
                            ::std::option::Option::Some(crate::lower::types::Bn::BnHold(f_ph, t_pi)) => {
                                let w2_pj = {
                                    let mut this: crate::lower::node_::Wx = w_pe.clone();
                                    this.inited_p = crate::check::types::add_text_f(&this.inited_p, &f_ph);
                                    this
                                };
                                (w2_pj.clone(), crate::lower::types::bind_f(be_pf, &crate::prelude::Text::from(format!("{}#init", &pat_text_f(q_pg))), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(crate::prelude::Text::from(format!("{}_init", &f_ph))), crate::lower::types::Holding::Owned, t_pi)))
                            },
                            _ => (w_pe.clone(), be_pf.clone()),
                        }))),
                        _ => ::prism_rtl::Turn::Finished((wx_p0.clone(), benv_p1.clone())),
                    }
                },
                _ => ::prism_rtl::Turn::Finished((wx_p0.clone(), benv_p1.clone())),
            },
            crate::syntax::StmtKind::SLet(p_pk, _, e_pl) => 'm92321: {
                let scrutinee = &binding_of_o(menv_p2, p_pk);
                if let ::std::option::Option::Some(crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(m92321_0_0_0, rs_pm, _), _, t_pn)) = scrutinee && let crate::lower::model::Ex::XSelf = &**m92321_0_0_0 {
                    break 'm92321 {
                        let benv_p1x = benv_p1.clone();
                        let e_plx = e_pl.clone();
                        let menv_p2x = menv_p2.clone();
                        let p_pkx = p_pk.clone();
                        let rs_pmx = rs_pm.clone();
                        let t_pnx = t_pn.clone();
                        let wx_p0x = wx_p0.clone();
                        crate::prelude::call_then(crate::lower::node_::dynamics::start_dynamic_expr_f(wx_p0x.clone(), menv_p2x.clone(), e_plx.clone()), move |dynamic_expr_f_92499: (crate::lower::model::Ex, crate::prelude::Array<crate::lower::node_::Read>)| {
                            let (_, reads_pp) = dynamic_expr_f_92499;
                            let wx2_po = {
                                let mut this: crate::lower::node_::Wx = wx_p0x.clone();
                                this.dyn_reads_p = crate::prelude::insert(&this.dyn_reads_p, &rs_pmx, &reads_pp);
                                this
                            };
                            if all_inited_f(&wx2_po, &reads_pp) && names_inited_f(&benv_p1x, &e_plx) {
                                {
                                    let wx3_pq = {
                                        let mut this: crate::lower::node_::Wx = wx2_po.clone();
                                        this.inited_p = crate::check::types::add_text_f(&this.inited_p, &rs_pmx);
                                        this
                                    };
                                    ::prism_rtl::Turn::Finished((wx3_pq.clone(), crate::lower::types::bind_f(&benv_p1x, &crate::prelude::Text::from(format!("{}#init", &pat_text_f(&p_pkx))), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(crate::prelude::Text::from(format!("{}_init", &rs_pmx))), crate::lower::types::Holding::Owned, t_pnx.clone()))))
                                }
                            } else {
                                ::prism_rtl::Turn::Finished((wx2_po.clone(), benv_p1x.clone()))
                            }
                        })
                    };
                }
                ::prism_rtl::Turn::Finished((wx_p0.clone(), benv_p1.clone()))
            },
            _ => ::prism_rtl::Turn::Finished((wx_p0.clone(), benv_p1.clone())),
        }
    }
}

/// `Start PreInit, x`: what the function value is when passed to `@Run`.
pub fn start_pre_init_f(wx_p0: crate::lower::node_::Wx, benv_p1: crate::lower::types::Env, menv_p2: crate::lower::types::Env, s_p3: crate::syntax::Stmt) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env)>> {
    ::std::rc::Rc::new(PreInit { wx_p0, benv_p1, menv_p2, s_p3 })
}

/// ```prism
/// BuildInOrder: unbounded fn Wx, [Stmt], [ [Nat] ], Nat, [Nat] -> Wx
/// ```
pub fn build_in_order_f(wx_p0: &crate::lower::node_::Wx, stmts_p1: &crate::prelude::Array<crate::syntax::Stmt>, order_p2: &crate::prelude::Array<crate::prelude::Array<crate::prelude::Nat>>, start_p3: &crate::prelude::Nat, ends_p4: &crate::prelude::Array<crate::prelude::Nat>) -> crate::lower::node_::Wx {
    let n_p5 = crate::prelude::len(stmts_p1);
    let last_p6 = crate::prelude::or(&crate::prelude::index(ends_p4, &crate::syntax::lexer::chars::dec_f(&n_p5)), start_p3);
    let runs_p7 = crate::prelude::each(&crate::check::errors::range0_f(&n_p5), &(|i_pc: &crate::prelude::Nat| {
        let from_pd = if i_pc == &crate::prelude::Nat::from(0u32) {
            start_p3.clone()
        } else {
            crate::prelude::or(&crate::prelude::index(ends_p4, &crate::syntax::lexer::chars::dec_f(i_pc)), start_p3)
        };
        crate::prelude::take(&crate::prelude::drop(&wx_p0.lets_p, &from_pd), &crate::prelude::or(&(&crate::prelude::or(&crate::prelude::index(ends_p4, i_pc), &from_pd)).checked_sub(&from_pd), &crate::prelude::Nat::from(0u32)))
    }));
    let lets_p8 = crate::prelude::fold(order_p2, &crate::prelude::take(&wx_p0.lets_p, start_p3), &(|acc_pe: &crate::prelude::Array<crate::lower::model::Do>, comp_pf: &crate::prelude::Array<crate::prelude::Nat>| crate::prelude::fold(comp_pf, acc_pe, &(|acc2_pg: &crate::prelude::Array<crate::lower::model::Do>, i_ph: &crate::prelude::Nat| crate::prelude::append(acc2_pg, &crate::prelude::or(&crate::prelude::index(&runs_p7, i_ph), &crate::prelude::Array::new()))))));
    let cyclic_p9 = crate::prelude::filter(order_p2, &(|comp_pi: &crate::prelude::Array<crate::prelude::Nat>| (&crate::prelude::len(comp_pi) > &crate::prelude::Nat::from(1u32)) && crate::prelude::fold(comp_pi, &false, &(|seen_pj: &bool, i_pk: &crate::prelude::Nat| *seen_pj || (&crate::prelude::len(&crate::prelude::or(&crate::prelude::index(&runs_p7, i_pk), &crate::prelude::Array::new())) > &crate::prelude::Nat::from(0u32))))));
    let links_pa = crate::prelude::filter(&lets_p8, &is_link_let_f);
    let wx2_pb = {
        let mut this: crate::lower::node_::Wx = wx_p0.clone();
        this.lets_p = crate::prelude::append(&crate::prelude::append(&links_pa, &crate::prelude::filter(&lets_p8, &(|d_pl: &crate::lower::model::Do| !is_link_let_f(d_pl)))), &crate::prelude::drop(&wx_p0.lets_p, &last_p6));
        this
    };
    crate::prelude::run_to_end(crate::prelude::fold_job(cyclic_p9.clone(), wx2_pb.clone(), {
        let stmts_p1x = stmts_p1.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::lower::node_::Wx, crate::prelude::Array<crate::prelude::Nat>)| {
            let stmts_p1xy = stmts_p1x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let w_pm = p0;
                let comp_pn = p1;
                ::prism_rtl::Turn::Finished({
                    let mut this: crate::lower::node_::Wx = w_pm.clone();
                    this.build_p = crate::prelude::push(&this.build_p, &crate::lower::expr::internal_bug_do_f(&crate::prelude::Text::from(format!("lines that read each other at the build ({}): a cycle among values", &crate::syntax::lexer::chars::join_f(&crate::prelude::run_to_end(crate::prelude::fold_job(comp_pn.clone(), crate::prelude::Array::new(), {
                        let stmts_p1xyx = stmts_p1xy.clone();
                        ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::prelude::Nat)| {
                            let stmts_p1xyxy = stmts_p1xyx.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let acc_po = p0;
                                let i_pp = p1;
                                crate::prelude::call_then(crate::check::blocks::start_group_defs_f(crate::prelude::or(&crate::prelude::index(&stmts_p1xyxy, &i_pp), &crate::lower::expr::dummy_stmt_l_p())), move |group_defs_f_94393: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_po, &group_defs_f_94393)))
                            }))
                        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>
                    })), &crate::prelude::Text::lit(", "))))));
                    this
                })
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::node_::Wx, crate::prelude::Array<crate::prelude::Nat>)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::node_::Wx>>>
    }))
}

/// The step machine of `BuildInOrder`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BuildInOrder: unbounded fn Wx, [Stmt], [ [Nat] ], Nat, [Nat] -> Wx
/// ```
pub struct BuildInOrder {
    pub wx_p0: crate::lower::node_::Wx,
    pub stmts_p1: crate::prelude::Array<crate::syntax::Stmt>,
    pub order_p2: crate::prelude::Array<crate::prelude::Array<crate::prelude::Nat>>,
    pub start_p3: crate::prelude::Nat,
    pub ends_p4: crate::prelude::Array<crate::prelude::Nat>,
}

impl ::prism_rtl::Job<crate::lower::node_::Wx> for BuildInOrder {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::lower::node_::Wx> {
        let wx_p0 = &self.wx_p0;
        let stmts_p1 = &self.stmts_p1;
        let order_p2 = &self.order_p2;
        let start_p3 = &self.start_p3;
        let ends_p4 = &self.ends_p4;
        let n_p5 = crate::prelude::len(stmts_p1);
        let last_p6 = crate::prelude::or(&crate::prelude::index(ends_p4, &crate::syntax::lexer::chars::dec_f(&n_p5)), start_p3);
        let runs_p7 = crate::prelude::each(&crate::check::errors::range0_f(&n_p5), &(|i_pc: &crate::prelude::Nat| {
            let from_pd = if i_pc == &crate::prelude::Nat::from(0u32) {
                start_p3.clone()
            } else {
                crate::prelude::or(&crate::prelude::index(ends_p4, &crate::syntax::lexer::chars::dec_f(i_pc)), start_p3)
            };
            crate::prelude::take(&crate::prelude::drop(&wx_p0.lets_p, &from_pd), &crate::prelude::or(&(&crate::prelude::or(&crate::prelude::index(ends_p4, i_pc), &from_pd)).checked_sub(&from_pd), &crate::prelude::Nat::from(0u32)))
        }));
        let lets_p8 = crate::prelude::fold(order_p2, &crate::prelude::take(&wx_p0.lets_p, start_p3), &(|acc_pe: &crate::prelude::Array<crate::lower::model::Do>, comp_pf: &crate::prelude::Array<crate::prelude::Nat>| crate::prelude::fold(comp_pf, acc_pe, &(|acc2_pg: &crate::prelude::Array<crate::lower::model::Do>, i_ph: &crate::prelude::Nat| crate::prelude::append(acc2_pg, &crate::prelude::or(&crate::prelude::index(&runs_p7, i_ph), &crate::prelude::Array::new()))))));
        let cyclic_p9 = crate::prelude::filter(order_p2, &(|comp_pi: &crate::prelude::Array<crate::prelude::Nat>| (&crate::prelude::len(comp_pi) > &crate::prelude::Nat::from(1u32)) && crate::prelude::fold(comp_pi, &false, &(|seen_pj: &bool, i_pk: &crate::prelude::Nat| *seen_pj || (&crate::prelude::len(&crate::prelude::or(&crate::prelude::index(&runs_p7, i_pk), &crate::prelude::Array::new())) > &crate::prelude::Nat::from(0u32))))));
        let links_pa = crate::prelude::filter(&lets_p8, &is_link_let_f);
        let wx2_pb = {
            let mut this: crate::lower::node_::Wx = wx_p0.clone();
            this.lets_p = crate::prelude::append(&crate::prelude::append(&links_pa, &crate::prelude::filter(&lets_p8, &(|d_pl: &crate::lower::model::Do| !is_link_let_f(d_pl)))), &crate::prelude::drop(&wx_p0.lets_p, &last_p6));
            this
        };
        crate::prelude::fold_job(cyclic_p9.clone(), wx2_pb.clone(), {
            let stmts_p1x = stmts_p1.clone();
            ::std::rc::Rc::new(move |(p0, p1): (crate::lower::node_::Wx, crate::prelude::Array<crate::prelude::Nat>)| {
                let stmts_p1xy = stmts_p1x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let w_pm = p0;
                    let comp_pn = p1;
                    ::prism_rtl::Turn::Finished({
                        let mut this: crate::lower::node_::Wx = w_pm.clone();
                        this.build_p = crate::prelude::push(&this.build_p, &crate::lower::expr::internal_bug_do_f(&crate::prelude::Text::from(format!("lines that read each other at the build ({}): a cycle among values", &crate::syntax::lexer::chars::join_f(&crate::prelude::run_to_end(crate::prelude::fold_job(comp_pn.clone(), crate::prelude::Array::new(), {
                            let stmts_p1xyx = stmts_p1xy.clone();
                            ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::prelude::Nat)| {
                                let stmts_p1xyxy = stmts_p1xyx.clone();
                                crate::prelude::entered(crate::prelude::once_job(move || {
                                    let acc_po = p0;
                                    let i_pp = p1;
                                    crate::prelude::call_then(crate::check::blocks::start_group_defs_f(crate::prelude::or(&crate::prelude::index(&stmts_p1xyxy, &i_pp), &crate::lower::expr::dummy_stmt_l_p())), move |group_defs_f_94393: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_po, &group_defs_f_94393)))
                                }))
                            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>
                        })), &crate::prelude::Text::lit(", "))))));
                        this
                    })
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::node_::Wx, crate::prelude::Array<crate::prelude::Nat>)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::node_::Wx>>>
        }).cycle()
    }
}

/// `Start BuildInOrder, x`: what the function value is when passed to `@Run`.
pub fn start_build_in_order_f(wx_p0: crate::lower::node_::Wx, stmts_p1: crate::prelude::Array<crate::syntax::Stmt>, order_p2: crate::prelude::Array<crate::prelude::Array<crate::prelude::Nat>>, start_p3: crate::prelude::Nat, ends_p4: crate::prelude::Array<crate::prelude::Nat>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::node_::Wx>> {
    ::std::rc::Rc::new(BuildInOrder { wx_p0, stmts_p1, order_p2, start_p3, ends_p4 })
}

/// ```prism
/// IsLinkLet: fn Do -> Bool
/// ```
pub fn is_link_let_f(d_p0: &crate::lower::model::Do) -> bool {
    match d_p0 {
        crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(_), crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(made_p1), m94630_0_1_1)) if (m94630_0_1_1.len() == 0) => crate::syntax::lexer::chars::has_prefix_f(made_p1, &crate::prelude::Text::lit("prism_rtl::Link::<")),
        _ => false,
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// BuildOrder: unbounded fn [Stmt] -> [ [Nat] ]
/// ```
pub fn build_order_f(stmts_p0: &crate::prelude::Array<crate::syntax::Stmt>) -> crate::prelude::Array<crate::prelude::Array<crate::prelude::Nat>> {
    let n_p1 = crate::prelude::len(stmts_p0);
    let defs_p2 = crate::prelude::run_to_end(crate::prelude::each_job(stmts_p0.clone(), ::std::rc::Rc::new(move |p0: crate::syntax::Stmt| crate::prelude::entered(crate::prelude::once_job(move || {
        let s_p7 = p0;
        crate::prelude::call_then(crate::check::blocks::start_group_defs_f(s_p7.clone()), move |group_defs_f_95159: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::prelude::filter(&group_defs_f_95159, &(|d_p8: &crate::prelude::Text| !crate::syntax::lexer::chars::has_prefix_f(d_p8, &crate::prelude::Text::lit("!"))))))
    }))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::syntax::Stmt) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>));
    let reads_p3 = crate::prelude::run_to_end(crate::prelude::each_job(stmts_p0.clone(), ::std::rc::Rc::new(move |p0: crate::syntax::Stmt| crate::prelude::entered(crate::prelude::once_job(move || {
        let s_p9 = p0;
        ::prism_rtl::Turn::More(::std::rc::Rc::new(ReadsAtBuild { s_p0: s_p9.clone() }))
    }))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::syntax::Stmt) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>));
    let deps_p4 = crate::prelude::each(&crate::check::errors::range0_f(&n_p1), &(|i_pa: &crate::prelude::Nat| crate::prelude::filter(&crate::check::errors::range0_f(&n_p1), &(|j_pb: &crate::prelude::Nat| (j_pb != i_pa) && crate::prelude::fold(&crate::prelude::or(&crate::prelude::index(&defs_p2, j_pb), &crate::prelude::Array::new()), &false, &(|seen_pc: &bool, d_pd: &crate::prelude::Text| *seen_pc || crate::check::types::has_text_f(&crate::prelude::or(&crate::prelude::index(&reads_p3, i_pa), &crate::prelude::Array::new()), d_pd)))))));
    let reach_p5 = crate::prelude::run_to_end(crate::prelude::each_job(crate::check::errors::range0_f(&n_p1), {
        let deps_p4x = deps_p4.clone();
        ::std::rc::Rc::new(move |p0: crate::prelude::Nat| {
            let deps_p4xy = deps_p4x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let i_pe = p0;
                ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::blocks::ReachIdx { deps_p0: deps_p4xy.clone(), frontier_p1: crate::prelude::or(&crate::prelude::index(&deps_p4xy, &i_pe), &crate::prelude::Array::new()), seen_p2: crate::prelude::Array::new() }))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Nat>>>>
    }));
    let comps_p6 = crate::prelude::each(&crate::check::errors::range0_f(&n_p1), &(|i_pf: &crate::prelude::Nat| crate::prelude::filter(&crate::check::errors::range0_f(&n_p1), &(|j_pg: &crate::prelude::Nat| (j_pg == i_pf) || (crate::check::types::has_nat_f(&crate::prelude::or(&crate::prelude::index(&reach_p5, i_pf), &crate::prelude::Array::new()), j_pg) && crate::check::types::has_nat_f(&crate::prelude::or(&crate::prelude::index(&reach_p5, j_pg), &crate::prelude::Array::new()), i_pf))))));
    crate::check::blocks::emit_groups_f(&comps_p6, &deps_p4, &crate::prelude::Array::new(), &crate::prelude::Array::new())
}

/// The step machine of `BuildOrder`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BuildOrder: unbounded fn [Stmt] -> [ [Nat] ]
/// ```
pub struct BuildOrder {
    pub stmts_p0: crate::prelude::Array<crate::syntax::Stmt>,
}

impl ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Array<crate::prelude::Nat>>> for BuildOrder {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<crate::prelude::Array<crate::prelude::Nat>>> {
        let stmts_p0 = &self.stmts_p0;
        let n_p1 = crate::prelude::len(stmts_p0);
        let stmts_p0x = stmts_p0.clone();
        crate::prelude::call_value(crate::prelude::each_job(stmts_p0x.clone(), ::std::rc::Rc::new(move |p0: crate::syntax::Stmt| crate::prelude::entered(crate::prelude::once_job(move || {
            let s_p7 = p0;
            crate::prelude::call_then(crate::check::blocks::start_group_defs_f(s_p7.clone()), move |group_defs_f_95159: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::prelude::filter(&group_defs_f_95159, &(|d_p8: &crate::prelude::Text| !crate::syntax::lexer::chars::has_prefix_f(d_p8, &crate::prelude::Text::lit("!"))))))
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::syntax::Stmt) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>), move |each_95134: crate::prelude::Array<crate::prelude::Array<crate::prelude::Text>>| {
            let defs_p2 = each_95134;
            crate::prelude::call_value(crate::prelude::each_job(stmts_p0x.clone(), ::std::rc::Rc::new(move |p0: crate::syntax::Stmt| crate::prelude::entered(crate::prelude::once_job(move || {
                let s_p9 = p0;
                ::prism_rtl::Turn::More(::std::rc::Rc::new(ReadsAtBuild { s_p0: s_p9.clone() }))
            }))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::syntax::Stmt) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>), move |each_95230: crate::prelude::Array<crate::prelude::Array<crate::prelude::Text>>| {
                let reads_p3 = each_95230;
                let deps_p4 = crate::prelude::each(&crate::check::errors::range0_f(&n_p1), &(|i_pa: &crate::prelude::Nat| crate::prelude::filter(&crate::check::errors::range0_f(&n_p1), &(|j_pb: &crate::prelude::Nat| (j_pb != i_pa) && crate::prelude::fold(&crate::prelude::or(&crate::prelude::index(&defs_p2, j_pb), &crate::prelude::Array::new()), &false, &(|seen_pc: &bool, d_pd: &crate::prelude::Text| *seen_pc || crate::check::types::has_text_f(&crate::prelude::or(&crate::prelude::index(&reads_p3, i_pa), &crate::prelude::Array::new()), d_pd)))))));
                crate::prelude::call_value(crate::prelude::each_job(crate::check::errors::range0_f(&n_p1), {
                    let deps_p4x = deps_p4.clone();
                    ::std::rc::Rc::new(move |p0: crate::prelude::Nat| {
                        let deps_p4xy = deps_p4x.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let i_pe = p0;
                            ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::blocks::ReachIdx { deps_p0: deps_p4xy.clone(), frontier_p1: crate::prelude::or(&crate::prelude::index(&deps_p4xy, &i_pe), &crate::prelude::Array::new()), seen_p2: crate::prelude::Array::new() }))
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Nat>>>>
                }), move |each_95432: crate::prelude::Array<crate::prelude::Array<crate::prelude::Nat>>| {
                    let reach_p5 = each_95432;
                    let comps_p6 = crate::prelude::each(&crate::check::errors::range0_f(&n_p1), &(|i_pf: &crate::prelude::Nat| crate::prelude::filter(&crate::check::errors::range0_f(&n_p1), &(|j_pg: &crate::prelude::Nat| (j_pg == i_pf) || (crate::check::types::has_nat_f(&crate::prelude::or(&crate::prelude::index(&reach_p5, i_pf), &crate::prelude::Array::new()), j_pg) && crate::check::types::has_nat_f(&crate::prelude::or(&crate::prelude::index(&reach_p5, j_pg), &crate::prelude::Array::new()), i_pf))))));
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::blocks::EmitGroups { comps_p0: comps_p6.clone(), deps_p1: deps_p4.clone(), done_p2: crate::prelude::Array::new(), acc_p3: crate::prelude::Array::new() }))
                })
            })
        })
    }
}

/// `Start BuildOrder, x`: what the function value is when passed to `@Run`.
pub fn start_build_order_f(stmts_p0: crate::prelude::Array<crate::syntax::Stmt>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Array<crate::prelude::Nat>>>> {
    ::std::rc::Rc::new(BuildOrder { stmts_p0 })
}

/// ```prism
/// ReadsAtBuild: unbounded fn Stmt -> [Text]
/// ```
pub fn reads_at_build_f(s_p0: &crate::syntax::Stmt) -> crate::prelude::Array<crate::prelude::Text> {
    match &s_p0.kind_p {
        crate::syntax::StmtKind::SBind(_, init_p1, ::std::option::Option::Some(_)) => crate::lower::expr::free_reads_f(&crate::check::typed::print::exprs_in_f(init_p1), &crate::prelude::Array::new()),
        crate::syntax::StmtKind::SFn(f_p2) => crate::lower::expr::free_reads_f(&crate::check::typed::print::stmt_exprs_f(s_p0), &crate::prelude::Array::from(vec![(crate::prelude::run_to_end(crate::prelude::fold_job(f_p2.params_p.clone(), crate::prelude::Array::new(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::syntax::Pattern)| crate::prelude::entered(crate::prelude::once_job(move || {
            let acc_p3 = p0;
            let q_p4 = p1;
            crate::prelude::call_then(crate::check::env::names::start_pattern_names_f(q_p4.clone()), move |pattern_names_f_96223: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_p3, &pattern_names_f_96223)))
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::syntax::Pattern)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>)), f_p2.span_p.clone())])),
        _ => crate::lower::expr::free_reads_f(&crate::check::typed::print::stmt_exprs_f(s_p0), &crate::prelude::Array::new()),
    }
}

/// The step machine of `ReadsAtBuild`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ReadsAtBuild: unbounded fn Stmt -> [Text]
/// ```
pub struct ReadsAtBuild {
    pub s_p0: crate::syntax::Stmt,
}

impl ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>> for ReadsAtBuild {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<crate::prelude::Text>> {
        let s_p0 = &self.s_p0;
        match &s_p0.kind_p {
            crate::syntax::StmtKind::SBind(_, init_p1, ::std::option::Option::Some(_)) => {
                let init_p1x = init_p1.clone();
                crate::prelude::call_then(crate::check::typed::print::start_exprs_in_f(init_p1x.clone()), move |exprs_in_f_96118: crate::prelude::Array<crate::syntax::Expr>| ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::lower::expr::FreeReads { es_p0: exprs_in_f_96118, outer_p1: crate::prelude::Array::new() })))
            },
            crate::syntax::StmtKind::SFn(f_p2) => {
                let f_p2x = f_p2.clone();
                let s_p0x = s_p0.clone();
                crate::prelude::call_then(crate::check::typed::print::start_stmt_exprs_f(s_p0x.clone()), move |stmt_exprs_f_96160: crate::prelude::Array<crate::syntax::Expr>| crate::prelude::call_value(crate::prelude::fold_job(f_p2x.params_p.clone(), crate::prelude::Array::new(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::syntax::Pattern)| crate::prelude::entered(crate::prelude::once_job(move || {
                    let acc_p3 = p0;
                    let q_p4 = p1;
                    crate::prelude::call_then(crate::check::env::names::start_pattern_names_f(q_p4.clone()), move |pattern_names_f_96223: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_p3, &pattern_names_f_96223)))
                }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::syntax::Pattern)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>), move |fold_96179: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::lower::expr::FreeReads { es_p0: stmt_exprs_f_96160, outer_p1: crate::prelude::Array::from(vec![(fold_96179, f_p2x.span_p.clone())]) }))))
            },
            _ => {
                let s_p0x = s_p0.clone();
                crate::prelude::call_then(crate::check::typed::print::start_stmt_exprs_f(s_p0x.clone()), move |stmt_exprs_f_96278: crate::prelude::Array<crate::syntax::Expr>| ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::lower::expr::FreeReads { es_p0: stmt_exprs_f_96278, outer_p1: crate::prelude::Array::new() })))
            },
        }
    }
}

/// `Start ReadsAtBuild, x`: what the function value is when passed to `@Run`.
pub fn start_reads_at_build_f(s_p0: crate::syntax::Stmt) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>> {
    ::std::rc::Rc::new(ReadsAtBuild { s_p0 })
}

/// ```prism
/// PreBind: unbounded fn Wx, Env, Env, Stmt -> ((Wx, Env, Env))
/// ```
pub fn pre_bind_f(wx_p0: &crate::lower::node_::Wx, benv_p1: &crate::lower::types::Env, menv_p2: &crate::lower::types::Env, s_p3: &crate::syntax::Stmt) -> (crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env) {
    match &s_p3.kind_p {
        crate::syntax::StmtKind::SBind(p_p4, init_p5, step_o6) => {
            let late_place_p7 = ((step_o6 == &::std::option::Option::None) && crate::check::types::has_nat_f(&wx_p0.late_hosts_p, &wx_p0.pos_p.scope_p)) && (is_dynamic_place_f(&wx_p0.lx_p, init_p5) || is_bundle_place_f(&wx_p0.lx_p, init_p5));
            let how_p8 = if late_place_p7 {
                HowBound::AsLatePlace
            } else {
                if (step_o6 == &::std::option::Option::None) && gives_result_f(&wx_p0.lx_p, menv_p2, init_p5) {
                    HowBound::AsResult
                } else {
                    if (step_o6 != &::std::option::Option::None) && reads_late_f(menv_p2, init_p5) {
                        HowBound::AsLateHold
                    } else {
                        how_bound_f(step_o6)
                    }
                }
            };
            match &*p_p4.kind_p {
                crate::syntax::PatternKind::PName(n_p9) => if (step_o6 == &::std::option::Option::None) && (crate::lower::node_::switch_::is_some_f(&late_plain_hold_o(&crate::prelude::get(&menv_p2.names_p, &crate::check::env::sname_key_f(n_p9)))) || crate::check::env::has_key_f(&menv_p2.names_p, &crate::prelude::Text::from(format!("{}#taker", &crate::check::env::sname_key_f(n_p9))))) {
                    (wx_p0.clone(), benv_p1.clone(), menv_p2.clone())
                } else {
                    pre_bind_name_f(wx_p0, benv_p1, menv_p2, n_p9, &how_p8)
                },
                crate::syntax::PatternKind::PTuple(ps_pa) => crate::prelude::run_to_end(crate::prelude::fold_job(ps_pa.clone(), (wx_p0.clone(), benv_p1.clone(), menv_p2.clone()), {
                    let late_place_p7x = late_place_p7;
                    let how_p8x = how_p8.clone();
                    let step_o6x = step_o6.clone();
                    ::std::rc::Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::syntax::Pattern)| {
                        let late_place_p7xy = late_place_p7x;
                        let how_p8xy = how_p8x.clone();
                        let step_o6xy = step_o6x.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let (w_pb, be_pc, me_pd) = p0;
                            let q_pe = p1;
                            match &*q_pe.kind_p {
                                crate::syntax::PatternKind::PName(n_pf) => if late_place_p7xy && crate::lower::node_::switch_::is_some_f(&late_plain_hold_o(&crate::prelude::get(&me_pd.names_p, &crate::check::env::sname_key_f(n_pf)))) {
                                    ::prism_rtl::Turn::Finished((w_pb.clone(), be_pc.clone(), me_pd.clone()))
                                } else {
                                    ::prism_rtl::Turn::More(::std::rc::Rc::new(PreBindName { wx_p0: w_pb.clone(), benv_p1: be_pc.clone(), menv_p2: me_pd.clone(), n_p3: n_pf.clone(), how_p4: how_p8xy.clone() }))
                                },
                                _ => if &step_o6xy == &::std::option::Option::None {
                                    crate::prelude::call_then(start_binder_names_f(q_pe.clone()), move |binder_names_f_98007: crate::prelude::Array<crate::syntax::SName>| crate::prelude::fold_job(binder_names_f_98007, (w_pb.clone(), be_pc.clone(), me_pd.clone()), {
                                        let late_place_p7xyx = late_place_p7xy;
                                        let how_p8xyx = how_p8xy.clone();
                                        ::std::rc::Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::syntax::SName)| {
                                            let late_place_p7xyxy = late_place_p7xyx;
                                            let how_p8xyxy = how_p8xyx.clone();
                                            crate::prelude::entered(crate::prelude::once_job(move || {
                                                let (w2_pg, be2_ph, me2_pi) = p0;
                                                let n_pj = p1;
                                                if late_place_p7xyxy && crate::check::env::has_key_f(&me2_pi.names_p, &crate::prelude::Text::from(format!("{}#lateplace", &crate::check::env::sname_key_f(&n_pj)))) {
                                                    ::prism_rtl::Turn::Finished((w2_pg.clone(), be2_ph.clone(), me2_pi.clone()))
                                                } else {
                                                    ::prism_rtl::Turn::More(::std::rc::Rc::new(PreBindName { wx_p0: w2_pg.clone(), benv_p1: be2_ph.clone(), menv_p2: me2_pi.clone(), n_p3: n_pj.clone(), how_p4: how_p8xyxy.clone() }))
                                                }
                                            }))
                                        }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::syntax::SName)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>>>
                                    }).cycle())
                                } else {
                                    ::prism_rtl::Turn::Finished((w_pb.clone(), be_pc.clone(), me_pd.clone()))
                                },
                            }
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::syntax::Pattern)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>>>
                })),
                _ => if step_o6 == &::std::option::Option::None {
                    crate::prelude::run_to_end(crate::prelude::fold_job(binder_names_f(p_p4), (wx_p0.clone(), benv_p1.clone(), menv_p2.clone()), {
                        let how_p8x = how_p8.clone();
                        ::std::rc::Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::syntax::SName)| {
                            let how_p8xy = how_p8x.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let (w2_pk, be2_pl, me2_pm) = p0;
                                let n_pn = p1;
                                ::prism_rtl::Turn::More(::std::rc::Rc::new(PreBindName { wx_p0: w2_pk.clone(), benv_p1: be2_pl.clone(), menv_p2: me2_pm.clone(), n_p3: n_pn.clone(), how_p4: how_p8xy.clone() }))
                            }))
                        }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::syntax::SName)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>>>
                    }))
                } else {
                    (wx_p0.clone(), benv_p1.clone(), menv_p2.clone())
                },
            }
        },
        crate::syntax::StmtKind::SLet(p_po, _, e_pp) => if is_late_let_f(menv_p2, p_po) && !takes_late_bundle_f(menv_p2, p_po, e_pp) {
            (wx_p0.clone(), benv_p1.clone(), menv_p2.clone())
        } else {
            match &*p_po.kind_p {
                crate::syntax::PatternKind::PName(n_pq) => if is_placed_let_f(menv_p2, p_po) {
                    (wx_p0.clone(), benv_p1.clone(), menv_p2.clone())
                } else {
                    pre_bind_name_f(wx_p0, benv_p1, menv_p2, n_pq, &HowBound::AsLet)
                },
                crate::syntax::PatternKind::PTuple(ps_pr) => crate::prelude::run_to_end(crate::prelude::fold_job(ps_pr.clone(), (wx_p0.clone(), benv_p1.clone(), menv_p2.clone()), ::std::rc::Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::syntax::Pattern)| crate::prelude::entered(crate::prelude::once_job(move || {
                    let (w_ps, be_pt, me_pu) = p0;
                    let q_pv = p1;
                    match &*q_pv.kind_p {
                        crate::syntax::PatternKind::PName(n_p10) => if crate::check::env::has_key_f(&me_pu.names_p, &crate::prelude::Text::from(format!("{}#late", &crate::check::env::sname_key_f(n_p10)))) {
                            ::prism_rtl::Turn::Finished((w_ps.clone(), be_pt.clone(), me_pu.clone()))
                        } else {
                            ::prism_rtl::Turn::More(::std::rc::Rc::new(PreBindName { wx_p0: w_ps.clone(), benv_p1: be_pt.clone(), menv_p2: me_pu.clone(), n_p3: n_p10.clone(), how_p4: HowBound::AsLet }))
                        },
                        _ => crate::prelude::call_then(start_binder_names_f(q_pv.clone()), move |binder_names_f_99038: crate::prelude::Array<crate::syntax::SName>| crate::prelude::fold_job(binder_names_f_99038, (w_ps.clone(), be_pt.clone(), me_pu.clone()), ::std::rc::Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::syntax::SName)| crate::prelude::entered(crate::prelude::once_job(move || {
                            let (w2_p11, be2_p12, me2_p13) = p0;
                            let n_p14 = p1;
                            if crate::check::env::has_key_f(&me2_p13.names_p, &crate::prelude::Text::from(format!("{}#late", &crate::check::env::sname_key_f(&n_p14)))) {
                                ::prism_rtl::Turn::Finished((w2_p11.clone(), be2_p12.clone(), me2_p13.clone()))
                            } else {
                                ::prism_rtl::Turn::More(::std::rc::Rc::new(PreBindName { wx_p0: w2_p11.clone(), benv_p1: be2_p12.clone(), menv_p2: me2_p13.clone(), n_p3: n_p14.clone(), how_p4: HowBound::AsLet }))
                            }
                        }))) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::syntax::SName)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>>>).cycle()),
                    }
                }))) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::syntax::Pattern)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>>>)),
                _ => crate::prelude::run_to_end(crate::prelude::fold_job(binder_names_f(p_po), (wx_p0.clone(), benv_p1.clone(), menv_p2.clone()), ::std::rc::Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::syntax::SName)| crate::prelude::entered(crate::prelude::once_job(move || {
                    let (w2_p15, be2_p16, me2_p17) = p0;
                    let n_p18 = p1;
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(PreBindName { wx_p0: w2_p15.clone(), benv_p1: be2_p16.clone(), menv_p2: me2_p17.clone(), n_p3: n_p18.clone(), how_p4: HowBound::AsLet }))
                }))) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::syntax::SName)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>>>)),
            }
        },
        crate::syntax::StmtKind::SFn(c_p19) => {
            let fname_p1a = crate::check::env::def_name_text_f(&c_p19.name_p);
            (wx_p0.clone(), crate::lower::types::bind_f(benv_p1, &fname_p1a, &crate::lower::expr::with_clause_f(benv_p1, &fname_p1a, c_p19)), crate::lower::types::bind_f(menv_p2, &fname_p1a, &crate::lower::expr::with_clause_f(menv_p2, &fname_p1a, c_p19)))
        },
        crate::syntax::StmtKind::SWidget(w_p1b) => (wx_p0.clone(), crate::lower::types::bind_f(benv_p1, &crate::check::env::sname_key_f(&w_p1b.name_p), &crate::lower::types::Bn::BnLocalWidget(w_p1b.body_p.clone())), crate::lower::types::bind_f(menv_p2, &crate::check::env::sname_key_f(&w_p1b.name_p), &crate::lower::types::Bn::BnLocalWidget(w_p1b.body_p.clone()))),
        _ => (wx_p0.clone(), benv_p1.clone(), menv_p2.clone()),
    }
}

/// The step machine of `PreBind`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PreBind: unbounded fn Wx, Env, Env, Stmt -> ((Wx, Env, Env))
/// ```
pub struct PreBind {
    pub wx_p0: crate::lower::node_::Wx,
    pub benv_p1: crate::lower::types::Env,
    pub menv_p2: crate::lower::types::Env,
    pub s_p3: crate::syntax::Stmt,
}

impl ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)> for PreBind {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)> {
        let wx_p0 = &self.wx_p0;
        let benv_p1 = &self.benv_p1;
        let menv_p2 = &self.menv_p2;
        let s_p3 = &self.s_p3;
        match &s_p3.kind_p {
            crate::syntax::StmtKind::SBind(p_p4, init_p5, step_o6) => {
                let late_place_p7 = ((step_o6 == &::std::option::Option::None) && crate::check::types::has_nat_f(&wx_p0.late_hosts_p, &wx_p0.pos_p.scope_p)) && (is_dynamic_place_f(&wx_p0.lx_p, init_p5) || is_bundle_place_f(&wx_p0.lx_p, init_p5));
                let how_p8 = if late_place_p7 {
                    HowBound::AsLatePlace
                } else {
                    if (step_o6 == &::std::option::Option::None) && gives_result_f(&wx_p0.lx_p, menv_p2, init_p5) {
                        HowBound::AsResult
                    } else {
                        if (step_o6 != &::std::option::Option::None) && reads_late_f(menv_p2, init_p5) {
                            HowBound::AsLateHold
                        } else {
                            how_bound_f(step_o6)
                        }
                    }
                };
                match &*p_p4.kind_p {
                    crate::syntax::PatternKind::PName(n_p9) => if (step_o6 == &::std::option::Option::None) && (crate::lower::node_::switch_::is_some_f(&late_plain_hold_o(&crate::prelude::get(&menv_p2.names_p, &crate::check::env::sname_key_f(n_p9)))) || crate::check::env::has_key_f(&menv_p2.names_p, &crate::prelude::Text::from(format!("{}#taker", &crate::check::env::sname_key_f(n_p9))))) {
                        ::prism_rtl::Turn::Finished((wx_p0.clone(), benv_p1.clone(), menv_p2.clone()))
                    } else {
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(PreBindName { wx_p0: wx_p0.clone(), benv_p1: benv_p1.clone(), menv_p2: menv_p2.clone(), n_p3: n_p9.clone(), how_p4: how_p8.clone() }))
                    },
                    crate::syntax::PatternKind::PTuple(ps_pa) => crate::prelude::fold_job(ps_pa.clone(), (wx_p0.clone(), benv_p1.clone(), menv_p2.clone()), {
                        let late_place_p7x = late_place_p7;
                        let how_p8x = how_p8.clone();
                        let step_o6x = step_o6.clone();
                        ::std::rc::Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::syntax::Pattern)| {
                            let late_place_p7xy = late_place_p7x;
                            let how_p8xy = how_p8x.clone();
                            let step_o6xy = step_o6x.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let (w_pb, be_pc, me_pd) = p0;
                                let q_pe = p1;
                                match &*q_pe.kind_p {
                                    crate::syntax::PatternKind::PName(n_pf) => if late_place_p7xy && crate::lower::node_::switch_::is_some_f(&late_plain_hold_o(&crate::prelude::get(&me_pd.names_p, &crate::check::env::sname_key_f(n_pf)))) {
                                        ::prism_rtl::Turn::Finished((w_pb.clone(), be_pc.clone(), me_pd.clone()))
                                    } else {
                                        ::prism_rtl::Turn::More(::std::rc::Rc::new(PreBindName { wx_p0: w_pb.clone(), benv_p1: be_pc.clone(), menv_p2: me_pd.clone(), n_p3: n_pf.clone(), how_p4: how_p8xy.clone() }))
                                    },
                                    _ => if &step_o6xy == &::std::option::Option::None {
                                        crate::prelude::call_then(start_binder_names_f(q_pe.clone()), move |binder_names_f_98007: crate::prelude::Array<crate::syntax::SName>| crate::prelude::fold_job(binder_names_f_98007, (w_pb.clone(), be_pc.clone(), me_pd.clone()), {
                                            let late_place_p7xyx = late_place_p7xy;
                                            let how_p8xyx = how_p8xy.clone();
                                            ::std::rc::Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::syntax::SName)| {
                                                let late_place_p7xyxy = late_place_p7xyx;
                                                let how_p8xyxy = how_p8xyx.clone();
                                                crate::prelude::entered(crate::prelude::once_job(move || {
                                                    let (w2_pg, be2_ph, me2_pi) = p0;
                                                    let n_pj = p1;
                                                    if late_place_p7xyxy && crate::check::env::has_key_f(&me2_pi.names_p, &crate::prelude::Text::from(format!("{}#lateplace", &crate::check::env::sname_key_f(&n_pj)))) {
                                                        ::prism_rtl::Turn::Finished((w2_pg.clone(), be2_ph.clone(), me2_pi.clone()))
                                                    } else {
                                                        ::prism_rtl::Turn::More(::std::rc::Rc::new(PreBindName { wx_p0: w2_pg.clone(), benv_p1: be2_ph.clone(), menv_p2: me2_pi.clone(), n_p3: n_pj.clone(), how_p4: how_p8xyxy.clone() }))
                                                    }
                                                }))
                                            }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::syntax::SName)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>>>
                                        }).cycle())
                                    } else {
                                        ::prism_rtl::Turn::Finished((w_pb.clone(), be_pc.clone(), me_pd.clone()))
                                    },
                                }
                            }))
                        }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::syntax::Pattern)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>>>
                    }).cycle(),
                    _ => if step_o6 == &::std::option::Option::None {
                        {
                            let benv_p1x = benv_p1.clone();
                            let menv_p2x = menv_p2.clone();
                            let p_p4x = p_p4.clone();
                            let wx_p0x = wx_p0.clone();
                            crate::prelude::call_then(start_binder_names_f(p_p4x.clone()), move |binder_names_f_98246: crate::prelude::Array<crate::syntax::SName>| crate::prelude::fold_job(binder_names_f_98246, (wx_p0x.clone(), benv_p1x.clone(), menv_p2x.clone()), {
                                let how_p8x = how_p8.clone();
                                ::std::rc::Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::syntax::SName)| {
                                    let how_p8xy = how_p8x.clone();
                                    crate::prelude::entered(crate::prelude::once_job(move || {
                                        let (w2_pk, be2_pl, me2_pm) = p0;
                                        let n_pn = p1;
                                        ::prism_rtl::Turn::More(::std::rc::Rc::new(PreBindName { wx_p0: w2_pk.clone(), benv_p1: be2_pl.clone(), menv_p2: me2_pm.clone(), n_p3: n_pn.clone(), how_p4: how_p8xy.clone() }))
                                    }))
                                }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::syntax::SName)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>>>
                            }).cycle())
                        }
                    } else {
                        ::prism_rtl::Turn::Finished((wx_p0.clone(), benv_p1.clone(), menv_p2.clone()))
                    },
                }
            },
            crate::syntax::StmtKind::SLet(p_po, _, e_pp) => {
                let benv_p1x = benv_p1.clone();
                let e_ppx = e_pp.clone();
                let menv_p2x = menv_p2.clone();
                let p_pox = p_po.clone();
                let wx_p0x = wx_p0.clone();
                crate::prelude::call_then(start_is_late_let_f(menv_p2x.clone(), p_pox.clone()), move |is_late_let_f_98528: bool| if is_late_let_f_98528 && !takes_late_bundle_f(&menv_p2x, &p_pox, &e_ppx) {
                    ::prism_rtl::Turn::Finished((wx_p0x.clone(), benv_p1x.clone(), menv_p2x.clone()))
                } else {
                    match &*p_pox.kind_p {
                        crate::syntax::PatternKind::PName(n_pq) => if is_placed_let_f(&menv_p2x, &p_pox) {
                            ::prism_rtl::Turn::Finished((wx_p0x.clone(), benv_p1x.clone(), menv_p2x.clone()))
                        } else {
                            ::prism_rtl::Turn::More(::std::rc::Rc::new(PreBindName { wx_p0: wx_p0x.clone(), benv_p1: benv_p1x.clone(), menv_p2: menv_p2x.clone(), n_p3: n_pq.clone(), how_p4: HowBound::AsLet }))
                        },
                        crate::syntax::PatternKind::PTuple(ps_pr) => crate::prelude::fold_job(ps_pr.clone(), (wx_p0x.clone(), benv_p1x.clone(), menv_p2x.clone()), ::std::rc::Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::syntax::Pattern)| crate::prelude::entered(crate::prelude::once_job(move || {
                            let (w_ps, be_pt, me_pu) = p0;
                            let q_pv = p1;
                            match &*q_pv.kind_p {
                                crate::syntax::PatternKind::PName(n_p10) => if crate::check::env::has_key_f(&me_pu.names_p, &crate::prelude::Text::from(format!("{}#late", &crate::check::env::sname_key_f(n_p10)))) {
                                    ::prism_rtl::Turn::Finished((w_ps.clone(), be_pt.clone(), me_pu.clone()))
                                } else {
                                    ::prism_rtl::Turn::More(::std::rc::Rc::new(PreBindName { wx_p0: w_ps.clone(), benv_p1: be_pt.clone(), menv_p2: me_pu.clone(), n_p3: n_p10.clone(), how_p4: HowBound::AsLet }))
                                },
                                _ => crate::prelude::call_then(start_binder_names_f(q_pv.clone()), move |binder_names_f_99038: crate::prelude::Array<crate::syntax::SName>| crate::prelude::fold_job(binder_names_f_99038, (w_ps.clone(), be_pt.clone(), me_pu.clone()), ::std::rc::Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::syntax::SName)| crate::prelude::entered(crate::prelude::once_job(move || {
                                    let (w2_p11, be2_p12, me2_p13) = p0;
                                    let n_p14 = p1;
                                    if crate::check::env::has_key_f(&me2_p13.names_p, &crate::prelude::Text::from(format!("{}#late", &crate::check::env::sname_key_f(&n_p14)))) {
                                        ::prism_rtl::Turn::Finished((w2_p11.clone(), be2_p12.clone(), me2_p13.clone()))
                                    } else {
                                        ::prism_rtl::Turn::More(::std::rc::Rc::new(PreBindName { wx_p0: w2_p11.clone(), benv_p1: be2_p12.clone(), menv_p2: me2_p13.clone(), n_p3: n_p14.clone(), how_p4: HowBound::AsLet }))
                                    }
                                }))) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::syntax::SName)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>>>).cycle()),
                            }
                        }))) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::syntax::Pattern)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>>>).cycle(),
                        _ => crate::prelude::call_then(start_binder_names_f(p_pox.clone()), move |binder_names_f_99217: crate::prelude::Array<crate::syntax::SName>| crate::prelude::fold_job(binder_names_f_99217, (wx_p0x.clone(), benv_p1x.clone(), menv_p2x.clone()), ::std::rc::Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::syntax::SName)| crate::prelude::entered(crate::prelude::once_job(move || {
                            let (w2_p15, be2_p16, me2_p17) = p0;
                            let n_p18 = p1;
                            ::prism_rtl::Turn::More(::std::rc::Rc::new(PreBindName { wx_p0: w2_p15.clone(), benv_p1: be2_p16.clone(), menv_p2: me2_p17.clone(), n_p3: n_p18.clone(), how_p4: HowBound::AsLet }))
                        }))) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::syntax::SName)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>>>).cycle()),
                    }
                })
            },
            crate::syntax::StmtKind::SFn(c_p19) => {
                let fname_p1a = crate::check::env::def_name_text_f(&c_p19.name_p);
                ::prism_rtl::Turn::Finished((wx_p0.clone(), crate::lower::types::bind_f(benv_p1, &fname_p1a, &crate::lower::expr::with_clause_f(benv_p1, &fname_p1a, c_p19)), crate::lower::types::bind_f(menv_p2, &fname_p1a, &crate::lower::expr::with_clause_f(menv_p2, &fname_p1a, c_p19))))
            },
            crate::syntax::StmtKind::SWidget(w_p1b) => ::prism_rtl::Turn::Finished((wx_p0.clone(), crate::lower::types::bind_f(benv_p1, &crate::check::env::sname_key_f(&w_p1b.name_p), &crate::lower::types::Bn::BnLocalWidget(w_p1b.body_p.clone())), crate::lower::types::bind_f(menv_p2, &crate::check::env::sname_key_f(&w_p1b.name_p), &crate::lower::types::Bn::BnLocalWidget(w_p1b.body_p.clone())))),
            _ => ::prism_rtl::Turn::Finished((wx_p0.clone(), benv_p1.clone(), menv_p2.clone())),
        }
    }
}

/// `Start PreBind, x`: what the function value is when passed to `@Run`.
pub fn start_pre_bind_f(wx_p0: crate::lower::node_::Wx, benv_p1: crate::lower::types::Env, menv_p2: crate::lower::types::Env, s_p3: crate::syntax::Stmt) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>> {
    ::std::rc::Rc::new(PreBind { wx_p0, benv_p1, menv_p2, s_p3 })
}

/// ```prism
/// BinderNames: unbounded fn Pattern -> [SName]
/// ```
pub fn binder_names_f(p_p0: &crate::syntax::Pattern) -> crate::prelude::Array<crate::syntax::SName> {
    match &*p_p0.kind_p {
        crate::syntax::PatternKind::PName(n_p1) => if crate::check::env::is_upper_text_f(&crate::lower::base_f(&crate::check::env::sname_key_f(n_p1))) {
            crate::prelude::Array::new()
        } else {
            crate::prelude::Array::from(vec![n_p1.clone()])
        },
        crate::syntax::PatternKind::PCtor(_, ps_p2) => crate::prelude::run_to_end(crate::prelude::fold_job(ps_p2.clone(), crate::prelude::Array::new(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::syntax::SName>, crate::syntax::Pattern)| crate::prelude::entered(crate::prelude::once_job(move || {
            let acc_p3 = p0;
            let q_p4 = p1;
            crate::prelude::call_then(start_binder_names_f(q_p4.clone()), move |binder_names_f_100102: crate::prelude::Array<crate::syntax::SName>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_p3, &binder_names_f_100102)))
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::syntax::SName>, crate::syntax::Pattern)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::syntax::SName>>>>)),
        crate::syntax::PatternKind::PRecord(_, fs_p5, _) => crate::prelude::run_to_end(crate::prelude::fold_job(fs_p5.clone(), crate::prelude::Array::new(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::syntax::SName>, crate::syntax::FieldPat)| crate::prelude::entered(crate::prelude::once_job(move || {
            let acc_p6 = p0;
            let f_p7 = p1;
            crate::prelude::call_then(start_binder_names_f(f_p7.pattern_p.clone()), move |binder_names_f_100187: crate::prelude::Array<crate::syntax::SName>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_p6, &binder_names_f_100187)))
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::syntax::SName>, crate::syntax::FieldPat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::syntax::SName>>>>)),
        crate::syntax::PatternKind::PTuple(ps_p8) => crate::prelude::run_to_end(crate::prelude::fold_job(ps_p8.clone(), crate::prelude::Array::new(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::syntax::SName>, crate::syntax::Pattern)| crate::prelude::entered(crate::prelude::once_job(move || {
            let acc_p9 = p0;
            let q_pa = p1;
            crate::prelude::call_then(start_binder_names_f(q_pa.clone()), move |binder_names_f_100263: crate::prelude::Array<crate::syntax::SName>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_p9, &binder_names_f_100263)))
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::syntax::SName>, crate::syntax::Pattern)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::syntax::SName>>>>)),
        crate::syntax::PatternKind::PArray(ps_pb) => crate::prelude::run_to_end(crate::prelude::fold_job(ps_pb.clone(), crate::prelude::Array::new(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::syntax::SName>, crate::syntax::Pattern)| crate::prelude::entered(crate::prelude::once_job(move || {
            let acc_pc = p0;
            let q_pd = p1;
            crate::prelude::call_then(start_binder_names_f(q_pd.clone()), move |binder_names_f_100331: crate::prelude::Array<crate::syntax::SName>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_pc, &binder_names_f_100331)))
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::syntax::SName>, crate::syntax::Pattern)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::syntax::SName>>>>)),
        crate::syntax::PatternKind::PGroup(q_pe) => binder_names_f(&**q_pe),
        _ => crate::prelude::Array::new(),
    }
}

/// The step machine of `BinderNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BinderNames: unbounded fn Pattern -> [SName]
/// ```
pub struct BinderNames {
    pub p_p0: crate::syntax::Pattern,
}

impl ::prism_rtl::Job<crate::prelude::Array<crate::syntax::SName>> for BinderNames {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<crate::syntax::SName>> {
        let p_p0 = &self.p_p0;
        match &*p_p0.kind_p {
            crate::syntax::PatternKind::PName(n_p1) => if crate::check::env::is_upper_text_f(&crate::lower::base_f(&crate::check::env::sname_key_f(n_p1))) {
                ::prism_rtl::Turn::Finished(crate::prelude::Array::new())
            } else {
                ::prism_rtl::Turn::Finished(crate::prelude::Array::from(vec![n_p1.clone()]))
            },
            crate::syntax::PatternKind::PCtor(_, ps_p2) => crate::prelude::fold_job(ps_p2.clone(), crate::prelude::Array::new(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::syntax::SName>, crate::syntax::Pattern)| crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_p3 = p0;
                let q_p4 = p1;
                crate::prelude::call_then(start_binder_names_f(q_p4.clone()), move |binder_names_f_100102: crate::prelude::Array<crate::syntax::SName>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_p3, &binder_names_f_100102)))
            }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::syntax::SName>, crate::syntax::Pattern)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::syntax::SName>>>>).cycle(),
            crate::syntax::PatternKind::PRecord(_, fs_p5, _) => crate::prelude::fold_job(fs_p5.clone(), crate::prelude::Array::new(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::syntax::SName>, crate::syntax::FieldPat)| crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_p6 = p0;
                let f_p7 = p1;
                crate::prelude::call_then(start_binder_names_f(f_p7.pattern_p.clone()), move |binder_names_f_100187: crate::prelude::Array<crate::syntax::SName>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_p6, &binder_names_f_100187)))
            }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::syntax::SName>, crate::syntax::FieldPat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::syntax::SName>>>>).cycle(),
            crate::syntax::PatternKind::PTuple(ps_p8) => crate::prelude::fold_job(ps_p8.clone(), crate::prelude::Array::new(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::syntax::SName>, crate::syntax::Pattern)| crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_p9 = p0;
                let q_pa = p1;
                crate::prelude::call_then(start_binder_names_f(q_pa.clone()), move |binder_names_f_100263: crate::prelude::Array<crate::syntax::SName>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_p9, &binder_names_f_100263)))
            }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::syntax::SName>, crate::syntax::Pattern)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::syntax::SName>>>>).cycle(),
            crate::syntax::PatternKind::PArray(ps_pb) => crate::prelude::fold_job(ps_pb.clone(), crate::prelude::Array::new(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::syntax::SName>, crate::syntax::Pattern)| crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_pc = p0;
                let q_pd = p1;
                crate::prelude::call_then(start_binder_names_f(q_pd.clone()), move |binder_names_f_100331: crate::prelude::Array<crate::syntax::SName>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_pc, &binder_names_f_100331)))
            }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::syntax::SName>, crate::syntax::Pattern)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::syntax::SName>>>>).cycle(),
            crate::syntax::PatternKind::PGroup(q_pe) => ::prism_rtl::Turn::More(::std::rc::Rc::new(BinderNames { p_p0: (**q_pe).clone() })),
            _ => ::prism_rtl::Turn::Finished(crate::prelude::Array::new()),
        }
    }
}

/// `Start BinderNames, x`: what the function value is when passed to `@Run`.
pub fn start_binder_names_f(p_p0: crate::syntax::Pattern) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::syntax::SName>>> {
    ::std::rc::Rc::new(BinderNames { p_p0 })
}

/// ```prism
/// IsNamesPattern: fn Pattern -> Bool
/// ```
pub fn is_names_pattern_f(p_p0: &crate::syntax::Pattern) -> bool {
    match &*p_p0.kind_p {
        crate::syntax::PatternKind::PName(_) => true,
        crate::syntax::PatternKind::PIgnore => true,
        crate::syntax::PatternKind::PGroup(q_p1) => is_names_pattern_f(&**q_p1),
        crate::syntax::PatternKind::PTuple(ps_p2) => crate::prelude::fold(ps_p2, &true, &(|ok_p3: &bool, q_p4: &crate::syntax::Pattern| *ok_p3 && match &*q_p4.kind_p {
            crate::syntax::PatternKind::PName(_) => true,
            crate::syntax::PatternKind::PIgnore => true,
            _ => false,
        })),
        _ => false,
    }
}

/// ```prism
/// BindPatternResult: unbounded fn Wx, Env, Pattern, Ex, OutTy, Ty -> Wx
/// ```
pub fn bind_pattern_result_f(wx_p0: &crate::lower::node_::Wx, menv_p1: &crate::lower::types::Env, p_p2: &crate::syntax::Pattern, ex_p3: &crate::lower::model::Ex, t_p4: &crate::lower::model::OutTy, ty_p5: &crate::check::types::Ty) -> crate::lower::node_::Wx {
    let (tmp_pd, wx1_pe) = crate::lower::node_::fresh_name_f(wx_p0, &crate::prelude::Text::lit("result"));
    let o_p6 = crate::lower::patterns::rust_pat_f(&wx_p0.lx_p, p_p2, ty_p5, &crate::lower::types::Holding::ByRef, &tmp_pd);
    let bound_p7 = crate::prelude::fold(&binder_names_f(p_p2), &crate::prelude::Array::new(), &(|acc_pf: &crate::prelude::Array<(crate::prelude::Text, crate::lower::model::OutTy, crate::lower::model::Ex)>, n_pg: &crate::syntax::SName| match (crate::prelude::get(&menv_p1.names_p, &crate::check::env::sname_key_f(n_pg)), crate::prelude::fold(&o_p6.binds_p, &::std::option::Option::None, &(|found_oh: &::std::option::Option<crate::lower::types::Bn>, (k_pi, b_pj): &(crate::prelude::Text, crate::lower::types::Bn)| if k_pi == &crate::check::env::sname_key_f(n_pg) {
        ::std::option::Option::Some(b_pj.clone())
    } else {
        found_oh.clone()
    }))) {
        (::std::option::Option::Some(crate::lower::types::Bn::BnLocal(rx_pk, _, bt_pl)), ::std::option::Option::Some(crate::lower::types::Bn::BnLocal(rs_pm, mode_pn, vt_po))) => crate::prelude::push(acc_pf, &(crate::lower::types::place_stem_f(&rx_pk), bt_pl, crate::lower::types::own_f(&crate::lower::types::Vl::VlPlace(rs_pm, mode_pn, vt_po)))),
        _ => acc_pf.clone(),
    }));
    let all_p8 = crate::lower::model::OutTy::OutTuple(crate::prelude::each(&bound_p7, &(|(_, bt_pp, _): &(crate::prelude::Text, crate::lower::model::OutTy, crate::lower::model::Ex)| bt_pp.clone())));
    let arm_p9 = crate::lower::model::XArm { pat_p: o_p6.pa_p.clone(), conds_p: o_p6.conds_p.clone(), body_p: crate::lower::model::Ex::XTuple(crate::prelude::each(&bound_p7, &(|(_, _, v_pq): &(crate::prelude::Text, crate::lower::model::OutTy, crate::lower::model::Ex)| v_pq.clone()))) };
    let other_pa = crate::lower::model::XArm { pat_p: crate::lower::model::Pa::PaWild, conds_p: crate::prelude::Array::new(), body_p: crate::lower::model::Ex::XUnreachable };
    let matched_pb = crate::lower::types::own_f(&crate::lower::expr::arms_value_f(&crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XVar(tmp_pd.clone()))), &crate::prelude::Array::from(vec![arm_p9.clone(), other_pa.clone()]), &crate::prelude::Text::lit("\'bound"), &all_p8));
    let wx2_pc = {
        let mut this: crate::lower::node_::Wx = wx1_pe.clone();
        this.lets_p = crate::prelude::append(&this.lets_p, &crate::prelude::Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaBind(tmp_pd.clone())), t_p4.clone()), ex_p3.clone()), crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaTuple(crate::prelude::each(&bound_p7, &(|(f_pr, _, _): &(crate::prelude::Text, crate::lower::model::OutTy, crate::lower::model::Ex)| crate::lower::model::Pa::PaBind(f_pr.clone()))))), all_p8.clone()), matched_pb.clone())]));
        this.fields_p = crate::prelude::append(&this.fields_p, &crate::prelude::each(&bound_p7, &(|(f_ps, bt_pt, _): &(crate::prelude::Text, crate::lower::model::OutTy, crate::lower::model::Ex)| (f_ps.clone(), bt_pt.clone(), crate::prelude::Text::lit("a name of a widget\'s result")))));
        this.inits_p = crate::prelude::append(&this.inits_p, &crate::prelude::each(&bound_p7, &(|(f_pu, _, _): &(crate::prelude::Text, crate::lower::model::OutTy, crate::lower::model::Ex)| (f_pu.clone(), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(f_pu.clone())))))));
        this
    };
    if &crate::prelude::len(&bound_p7) == &crate::prelude::len(&binder_names_f(p_p2)) {
        wx2_pc.clone()
    } else {
        refuse_plain_result_f(&wx2_pc, p_p2)
    }
}

/// The step machine of `BindPatternResult`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BindPatternResult: unbounded fn Wx, Env, Pattern, Ex, OutTy, Ty -> Wx
/// ```
pub struct BindPatternResult {
    pub wx_p0: crate::lower::node_::Wx,
    pub menv_p1: crate::lower::types::Env,
    pub p_p2: crate::syntax::Pattern,
    pub ex_p3: crate::lower::model::Ex,
    pub t_p4: crate::lower::model::OutTy,
    pub ty_p5: crate::check::types::Ty,
}

impl ::prism_rtl::Job<crate::lower::node_::Wx> for BindPatternResult {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::lower::node_::Wx> {
        let wx_p0 = &self.wx_p0;
        let menv_p1 = &self.menv_p1;
        let p_p2 = &self.p_p2;
        let ex_p3 = &self.ex_p3;
        let t_p4 = &self.t_p4;
        let ty_p5 = &self.ty_p5;
        let (tmp_pd, wx1_pe) = crate::lower::node_::fresh_name_f(wx_p0, &crate::prelude::Text::lit("result"));
        let ex_p3x = ex_p3.clone();
        let menv_p1x = menv_p1.clone();
        let p_p2x = p_p2.clone();
        let t_p4x = t_p4.clone();
        let ty_p5x = ty_p5.clone();
        let wx_p0x = wx_p0.clone();
        crate::prelude::call_then(crate::lower::patterns::start_rust_pat_f(wx_p0x.lx_p.clone(), p_p2x.clone(), ty_p5x.clone(), crate::lower::types::Holding::ByRef, tmp_pd.clone()), move |rust_pat_f_101359: crate::lower::patterns::PatOut| {
            let o_p6 = rust_pat_f_101359;
            crate::prelude::call_then(start_binder_names_f(p_p2x.clone()), move |binder_names_f_101498: crate::prelude::Array<crate::syntax::SName>| {
                let bound_p7 = crate::prelude::fold(&binder_names_f_101498, &crate::prelude::Array::new(), &(|acc_pf: &crate::prelude::Array<(crate::prelude::Text, crate::lower::model::OutTy, crate::lower::model::Ex)>, n_pg: &crate::syntax::SName| match (crate::prelude::get(&menv_p1x.names_p, &crate::check::env::sname_key_f(n_pg)), crate::prelude::fold(&o_p6.binds_p, &::std::option::Option::None, &(|found_oh: &::std::option::Option<crate::lower::types::Bn>, (k_pi, b_pj): &(crate::prelude::Text, crate::lower::types::Bn)| if k_pi == &crate::check::env::sname_key_f(n_pg) {
                    ::std::option::Option::Some(b_pj.clone())
                } else {
                    found_oh.clone()
                }))) {
                    (::std::option::Option::Some(crate::lower::types::Bn::BnLocal(rx_pk, _, bt_pl)), ::std::option::Option::Some(crate::lower::types::Bn::BnLocal(rs_pm, mode_pn, vt_po))) => crate::prelude::push(acc_pf, &(crate::lower::types::place_stem_f(&rx_pk), bt_pl, crate::lower::types::own_f(&crate::lower::types::Vl::VlPlace(rs_pm, mode_pn, vt_po)))),
                    _ => acc_pf.clone(),
                }));
                let all_p8 = crate::lower::model::OutTy::OutTuple(crate::prelude::each(&bound_p7, &(|(_, bt_pp, _): &(crate::prelude::Text, crate::lower::model::OutTy, crate::lower::model::Ex)| bt_pp.clone())));
                let arm_p9 = crate::lower::model::XArm { pat_p: o_p6.pa_p.clone(), conds_p: o_p6.conds_p.clone(), body_p: crate::lower::model::Ex::XTuple(crate::prelude::each(&bound_p7, &(|(_, _, v_pq): &(crate::prelude::Text, crate::lower::model::OutTy, crate::lower::model::Ex)| v_pq.clone()))) };
                let other_pa = crate::lower::model::XArm { pat_p: crate::lower::model::Pa::PaWild, conds_p: crate::prelude::Array::new(), body_p: crate::lower::model::Ex::XUnreachable };
                let matched_pb = crate::lower::types::own_f(&crate::lower::expr::arms_value_f(&crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XVar(tmp_pd.clone()))), &crate::prelude::Array::from(vec![arm_p9.clone(), other_pa.clone()]), &crate::prelude::Text::lit("\'bound"), &all_p8));
                let wx2_pc = {
                    let mut this: crate::lower::node_::Wx = wx1_pe.clone();
                    this.lets_p = crate::prelude::append(&this.lets_p, &crate::prelude::Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaBind(tmp_pd.clone())), t_p4x.clone()), ex_p3x.clone()), crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaTuple(crate::prelude::each(&bound_p7, &(|(f_pr, _, _): &(crate::prelude::Text, crate::lower::model::OutTy, crate::lower::model::Ex)| crate::lower::model::Pa::PaBind(f_pr.clone()))))), all_p8.clone()), matched_pb.clone())]));
                    this.fields_p = crate::prelude::append(&this.fields_p, &crate::prelude::each(&bound_p7, &(|(f_ps, bt_pt, _): &(crate::prelude::Text, crate::lower::model::OutTy, crate::lower::model::Ex)| (f_ps.clone(), bt_pt.clone(), crate::prelude::Text::lit("a name of a widget\'s result")))));
                    this.inits_p = crate::prelude::append(&this.inits_p, &crate::prelude::each(&bound_p7, &(|(f_pu, _, _): &(crate::prelude::Text, crate::lower::model::OutTy, crate::lower::model::Ex)| (f_pu.clone(), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(f_pu.clone())))))));
                    this
                };
                crate::prelude::call_then(start_binder_names_f(p_p2x.clone()), move |binder_names_f_102552: crate::prelude::Array<crate::syntax::SName>| if &crate::prelude::len(&bound_p7) == &crate::prelude::len(&binder_names_f_102552) {
                    ::prism_rtl::Turn::Finished(wx2_pc.clone())
                } else {
                    ::prism_rtl::Turn::Finished(refuse_plain_result_f(&wx2_pc, &p_p2x))
                })
            })
        })
    }
}

/// `Start BindPatternResult, x`: what the function value is when passed to `@Run`.
pub fn start_bind_pattern_result_f(wx_p0: crate::lower::node_::Wx, menv_p1: crate::lower::types::Env, p_p2: crate::syntax::Pattern, ex_p3: crate::lower::model::Ex, t_p4: crate::lower::model::OutTy, ty_p5: crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::node_::Wx>> {
    ::std::rc::Rc::new(BindPatternResult { wx_p0, menv_p1, p_p2, ex_p3, t_p4, ty_p5 })
}

/// ```prism
/// GivesResult: unbounded fn Lx, Env, Expr -> Bool
/// ```
pub fn gives_result_f(lx_p0: &crate::lower::Lx, menv_p1: &crate::lower::types::Env, e_p2: &crate::syntax::Expr) -> bool {
    match &*e_p2.kind_p {
        crate::syntax::ExprKind::EGroup(x_p3) => gives_result_f(lx_p0, menv_p1, &**x_p3),
        crate::syntax::ExprKind::EWidgetBlock(_) => true,
        crate::syntax::ExprKind::EFor(_, _, _) => crate::lower::types::is_bundle_f(&line_out_full_f(lx_p0, e_p2)) || (&crate::lower::node_::switch_::result_layer_f(&crate::lower::type_at_f(lx_p0, &e_p2.span_p)) == &crate::lower::types::Layer::LyDyn),
        crate::syntax::ExprKind::EMatch(_, _) => crate::lower::types::is_bundle_f(&line_out_full_f(lx_p0, e_p2)) || (&crate::lower::node_::switch_::result_layer_f(&crate::lower::type_at_f(lx_p0, &e_p2.span_p)) == &crate::lower::types::Layer::LyDyn),
        crate::syntax::ExprKind::EIf(_, _, _) => crate::lower::types::is_bundle_f(&line_out_full_f(lx_p0, e_p2)) || (&crate::lower::node_::switch_::result_layer_f(&crate::lower::type_at_f(lx_p0, &e_p2.span_p)) == &crate::lower::types::Layer::LyDyn),
        _ => {
            let callee_p4 = match &*e_p2.kind_p {
                crate::syntax::ExprKind::ECall(c_p5, _, _, _) => (**c_p5).clone(),
                _ => e_p2.clone(),
            };
            match &*callee_p4.kind_p {
                crate::syntax::ExprKind::EName(n_p6) => match crate::prelude::get(&menv_p1.names_p, &crate::check::env::sname_key_f(n_p6)) {
                    ::std::option::Option::Some(crate::lower::types::Bn::BnWidget(_, _, _, _)) => true,
                    _ => if crate::check::env::has_key_f(&menv_p1.names_p, &crate::prelude::Text::from(format!("{}#blueprint", &crate::check::env::sname_key_f(n_p6)))) {
                        true
                    } else {
                        {
                            let (q_o7, _) = crate::check::env::names::resolve_value_f(&lx_p0.g_p, &lx_p0.home_p, n_p6);
                            match &q_o7 {
                                ::std::option::Option::Some(q_p8) => (is_getter_builtin_f(q_p8) || is_host_builtin_f(q_p8)) || ((!is_prelude_name_f(q_p8) && (&crate::prelude::get(&lx_p0.g_p.vals_p, q_p8) != &::std::option::Option::None)) && is_widget_ty_f(&crate::lower::types::peel_f(&crate::lower::type_at_f(lx_p0, &e_p2.span_p)))),
                                ::std::option::Option::None => false,
                            }
                        }
                    },
                },
                _ => false,
            }
        },
    }
}

/// The step machine of `GivesResult`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// GivesResult: unbounded fn Lx, Env, Expr -> Bool
/// ```
pub struct GivesResult {
    pub lx_p0: crate::lower::Lx,
    pub menv_p1: crate::lower::types::Env,
    pub e_p2: crate::syntax::Expr,
}

impl ::prism_rtl::Job<bool> for GivesResult {
    fn cycle(&self) -> ::prism_rtl::Turn<bool> {
        let lx_p0 = &self.lx_p0;
        let menv_p1 = &self.menv_p1;
        let e_p2 = &self.e_p2;
        match &*e_p2.kind_p {
            crate::syntax::ExprKind::EGroup(x_p3) => ::prism_rtl::Turn::More(::std::rc::Rc::new(GivesResult { lx_p0: lx_p0.clone(), menv_p1: menv_p1.clone(), e_p2: (**x_p3).clone() })),
            crate::syntax::ExprKind::EWidgetBlock(_) => ::prism_rtl::Turn::Finished(true),
            crate::syntax::ExprKind::EFor(_, _, _) => ::prism_rtl::Turn::Finished(crate::lower::types::is_bundle_f(&line_out_full_f(lx_p0, e_p2)) || (&crate::lower::node_::switch_::result_layer_f(&crate::lower::type_at_f(lx_p0, &e_p2.span_p)) == &crate::lower::types::Layer::LyDyn)),
            crate::syntax::ExprKind::EMatch(_, _) => ::prism_rtl::Turn::Finished(crate::lower::types::is_bundle_f(&line_out_full_f(lx_p0, e_p2)) || (&crate::lower::node_::switch_::result_layer_f(&crate::lower::type_at_f(lx_p0, &e_p2.span_p)) == &crate::lower::types::Layer::LyDyn)),
            crate::syntax::ExprKind::EIf(_, _, _) => ::prism_rtl::Turn::Finished(crate::lower::types::is_bundle_f(&line_out_full_f(lx_p0, e_p2)) || (&crate::lower::node_::switch_::result_layer_f(&crate::lower::type_at_f(lx_p0, &e_p2.span_p)) == &crate::lower::types::Layer::LyDyn)),
            _ => {
                let callee_p4 = match &*e_p2.kind_p {
                    crate::syntax::ExprKind::ECall(c_p5, _, _, _) => (**c_p5).clone(),
                    _ => e_p2.clone(),
                };
                match &*callee_p4.kind_p {
                    crate::syntax::ExprKind::EName(n_p6) => match crate::prelude::get(&menv_p1.names_p, &crate::check::env::sname_key_f(n_p6)) {
                        ::std::option::Option::Some(crate::lower::types::Bn::BnWidget(_, _, _, _)) => ::prism_rtl::Turn::Finished(true),
                        _ => if crate::check::env::has_key_f(&menv_p1.names_p, &crate::prelude::Text::from(format!("{}#blueprint", &crate::check::env::sname_key_f(n_p6)))) {
                            ::prism_rtl::Turn::Finished(true)
                        } else {
                            {
                                let (q_o7, _) = crate::check::env::names::resolve_value_f(&lx_p0.g_p, &lx_p0.home_p, n_p6);
                                match &q_o7 {
                                    ::std::option::Option::Some(q_p8) => ::prism_rtl::Turn::Finished((is_getter_builtin_f(q_p8) || is_host_builtin_f(q_p8)) || ((!is_prelude_name_f(q_p8) && (&crate::prelude::get(&lx_p0.g_p.vals_p, q_p8) != &::std::option::Option::None)) && is_widget_ty_f(&crate::lower::types::peel_f(&crate::lower::type_at_f(lx_p0, &e_p2.span_p))))),
                                    ::std::option::Option::None => ::prism_rtl::Turn::Finished(false),
                                }
                            }
                        },
                    },
                    _ => ::prism_rtl::Turn::Finished(false),
                }
            },
        }
    }
}

/// `Start GivesResult, x`: what the function value is when passed to `@Run`.
pub fn start_gives_result_f(lx_p0: crate::lower::Lx, menv_p1: crate::lower::types::Env, e_p2: crate::syntax::Expr) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>> {
    ::std::rc::Rc::new(GivesResult { lx_p0, menv_p1, e_p2 })
}

/// ```prism
/// IsPreludeName: fn Text -> Bool
/// ```
pub fn is_prelude_name_f(q_p0: &crate::prelude::Text) -> bool {
    &crate::prelude::find(&{ thread_local!(static R: crate::prelude::Regex = crate::prelude::Regex::lit("^Prelude\\.", "")); R.with(crate::prelude::Regex::clone) }, q_p0) != &::std::option::Option::None
}

/// ```prism
/// IsGetterBuiltin: fn Text -> Bool
/// ```
pub fn is_getter_builtin_f(q_p0: &crate::prelude::Text) -> bool {
    ((q_p0 == &crate::prelude::Text::lit("Prelude.@Distinct")) || (q_p0 == &crate::prelude::Text::lit("Prelude.@PerKey"))) || (q_p0 == &crate::prelude::Text::lit("Prelude.@Flatten"))
}

/// ```prism
/// IsHostBuiltin: fn Text -> Bool
/// ```
pub fn is_host_builtin_f(q_p0: &crate::prelude::Text) -> bool {
    ((q_p0 == &crate::prelude::Text::lit("Prelude.@HostDocument")) || (q_p0 == &crate::prelude::Text::lit("Prelude.@HostSome"))) || (q_p0 == &crate::prelude::Text::lit("Prelude.@HostList"))
}

/// ```prism
/// IsWidgetTy: fn Ty -> Bool
/// ```
pub fn is_widget_ty_f(t_p0: &crate::check::types::Ty) -> bool {
    match t_p0 {
        crate::check::types::Ty::TyAt(_, _) => true,
        _ => false,
    }
}

/// ```prism
/// HowBound: fn ?Expr -> HowBound
/// ```
pub fn how_bound_f(opt0: &::std::option::Option<crate::syntax::Expr>) -> HowBound {
    match opt0 {
        ::std::option::Option::Some(_) => HowBound::AsHold,
        ::std::option::Option::None => HowBound::AsBind,
    }
}

/// ```prism
/// PreBindName: unbounded fn Wx, Env, Env, SName, HowBound -> ((Wx, Env, Env))
/// ```
pub fn pre_bind_name_f(wx_p0: &crate::lower::node_::Wx, benv_p1: &crate::lower::types::Env, menv_p2: &crate::lower::types::Env, n_p3: &crate::syntax::SName, how_p4: &HowBound) -> (crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env) {
    let lx_p5 = crate::lower::expr::widget_let_lx_f(&wx_p0.lx_p, &n_p3.span_p);
    let nkey_p6 = crate::check::env::sname_key_f(n_p3);
    let full_p7 = crate::lower::binder_ty_f(&lx_p5, &n_p3.span_p);
    let layer_p8 = crate::lower::types::layer_of_f(&full_p7);
    let t_p9 = crate::lower::types::out_ty_of_f(&lx_p5, &crate::lower::types::peel_f(&full_p7));
    let (rs_pa, wx1_pb) = crate::lower::node_::fresh_name_f(wx_p0, &crate::lower::local_name_at_f(&lx_p5, &nkey_p6, &n_p3.span_p));
    if ((((how_p4 == &HowBound::AsBind) || (how_p4 == &HowBound::AsResult)) || (how_p4 == &HowBound::AsLet)) || (how_p4 == &HowBound::AsLatePlace)) && crate::lower::types::is_bundle_f(&full_p7) {
        (wx_p0.clone(), benv_p1.clone(), menv_p2.clone())
    } else {
        if (&layer_p8 == &crate::lower::types::Layer::LyEv) || is_switched_f(&full_p7) {
            {
                let et_pc = crate::lower::types::out_ty_of_f(&lx_p5, &crate::lower::types::peel_f(&crate::lower::types::peel_f(&full_p7)));
                let (id_pj, wx2_pk) = crate::lower::node_::add_gn_f(&wx1_pb, &rs_pa, &et_pc, &crate::lower::node_::GnKind::GnNamed, &crate::prelude::Nat::from(0u32));
                let b_pd = crate::lower::types::Bn::BnEv(crate::lower::node_::ev_ref_of_f(&wx2_pk, &id_pj), t_p9.clone());
                let pf_pe = crate::prelude::Text::from(format!("{}_v_port", &rs_pa));
                let pt_pf = crate::lower::model::OutTy::OutRc(::std::rc::Rc::new(crate::lower::model::OutTy::OutPort(::std::rc::Rc::new(et_pc.clone()))));
                let wx3_pg = {
                    let mut this: crate::lower::node_::Wx = crate::lower::node_::connect_f(&wx2_pk, &crate::lower::node_::ev_ref_of_f(&wx2_pk, &id_pj), &crate::lower::node_::Sk::SkPort(crate::prelude::Text::from(format!("{}_v", &rs_pa))));
                    this.lets_p = crate::prelude::push(&this.lets_p, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaBind(pf_pe.clone())), pt_pf.clone()), crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Rc::new")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Port::new")), crate::prelude::Array::new())]))));
                    this.fields_p = crate::prelude::push(&this.fields_p, &(pf_pe.clone(), pt_pf.clone(), crate::prelude::Text::from(format!("`{}` as a value: the port it fires", &nkey_p6))));
                    this.moves_p = crate::prelude::push(&this.moves_p, &(pf_pe.clone(), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(pf_pe.clone())))));
                    this
                };
                let be_ph = crate::lower::types::bind_f(&crate::lower::types::bind_f(benv_p1, &nkey_p6, &b_pd), &crate::prelude::Text::from(format!("{}#port", &nkey_p6)), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(pf_pe.clone()), crate::lower::types::Holding::Owned, pt_pf.clone()));
                let me_pi = crate::lower::types::bind_f(&crate::lower::types::bind_f(menv_p2, &nkey_p6, &b_pd), &crate::prelude::Text::from(format!("{}#port", &nkey_p6)), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), pf_pe.clone()), crate::lower::types::Holding::Owned, pt_pf.clone()));
                (wx3_pg.clone(), be_ph.clone(), me_pi.clone())
            }
        } else {
            match (layer_p8.clone(), how_p4.clone()) {
                (crate::lower::types::Layer::LyDyn, HowBound::AsLet) => {
                    let b_pl = crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), rs_pa.clone(), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx])), crate::prelude::Array::from(vec![crate::lower::node_::Read::OwnRead(rs_pa.clone())]), t_p9.clone());
                    (wx1_pb.clone(), crate::lower::types::bind_f(benv_p1, &nkey_p6, &b_pl), crate::lower::types::bind_f(menv_p2, &nkey_p6, &b_pl))
                },
                (_, HowBound::AsLet) if (crate::lower::types::time_within_f(&full_p7) && !crate::lower::types::is_bundle_f(&full_p7)) => {
                    let b_pm = crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), rs_pa.clone(), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx])), crate::prelude::Array::from(vec![crate::lower::node_::Read::OwnRead(rs_pa.clone())]), crate::lower::types::out_ty_of_f(&lx_p5, &full_p7));
                    (wx1_pb.clone(), crate::lower::types::bind_f(benv_p1, &nkey_p6, &b_pm), crate::lower::types::bind_f(menv_p2, &nkey_p6, &b_pm))
                },
                (crate::lower::types::Layer::LyDyn, HowBound::AsResult) => {
                    let b_pn = crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), rs_pa.clone(), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx])), crate::prelude::Array::from(vec![crate::lower::node_::Read::OwnRead(rs_pa.clone())]), t_p9.clone());
                    (wx1_pb.clone(), crate::lower::types::bind_f(benv_p1, &nkey_p6, &b_pn), crate::lower::types::bind_f(menv_p2, &nkey_p6, &b_pn))
                },
                (crate::lower::types::Layer::LyDyn, HowBound::AsLateHold) => {
                    let b_po = crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), rs_pa.clone())), crate::prelude::Text::lit("get"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx]))), crate::prelude::Text::lit("expect"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XStr(crate::prelude::Text::lit("a hold that starts from a late result is set when that result is built"))])), crate::prelude::Array::from(vec![crate::lower::node_::Read::OwnRead(rs_pa.clone())]), t_p9.clone());
                    (wx1_pb.clone(), crate::lower::types::bind_f(benv_p1, &nkey_p6, &b_po), crate::lower::types::bind_f(menv_p2, &nkey_p6, &b_po))
                },
                (crate::lower::types::Layer::LyDyn, HowBound::AsLatePlace) => {
                    let b_pp = late_place_bn_f(&rs_pa, &t_p9);
                    (wx1_pb.clone(), crate::lower::types::bind_f(benv_p1, &nkey_p6, &b_pp), crate::lower::types::bind_f(menv_p2, &nkey_p6, &b_pp))
                },
                (crate::lower::types::Layer::LyDyn, _) => {
                    let b_pq = crate::lower::types::Bn::BnHold(rs_pa.clone(), t_p9.clone());
                    (wx1_pb.clone(), crate::lower::types::bind_f(benv_p1, &nkey_p6, &b_pq), crate::lower::types::bind_f(menv_p2, &nkey_p6, &b_pq))
                },
                _ => match many_instances_o(&wx_p0.lx_p, &n_p3.span_p) {
                    ::std::option::Option::Some(insts_pr) => crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(&insts_pr)), (wx1_pb.clone(), benv_p1.clone(), menv_p2.clone()), {
                        let insts_prx = insts_pr.clone();
                        let wx_p0x = wx_p0.clone();
                        let n_p3x = n_p3.clone();
                        let rs_pax = rs_pa.clone();
                        let nkey_p6x = nkey_p6.clone();
                        ::std::rc::Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::prelude::Nat)| {
                            let insts_prxy = insts_prx.clone();
                            let wx_p0xy = wx_p0x.clone();
                            let n_p3xy = n_p3x.clone();
                            let rs_paxy = rs_pax.clone();
                            let nkey_p6xy = nkey_p6x.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let (w_ps, be_pt, me_pu) = p0;
                                let k_pv = p1;
                                {
                                    let inst_p10 = crate::prelude::or(&crate::prelude::index(&insts_prxy, &k_pv), &(crate::prelude::Array::new(), crate::prelude::Array::new()));
                                    let lxk_p11 = crate::lower::expr::at_instance_f(&wx_p0xy.lx_p, &inst_p10);
                                    crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lxk_p11.clone(), crate::lower::types::peel_f(&crate::lower::binder_ty_f(&lxk_p11, &n_p3xy.span_p))), move |out_ty_of_f_109765: crate::lower::model::OutTy| {
                                        let tk_p12 = out_ty_of_f_109765;
                                        let (rk_p15, w2_p16) = if &k_pv == &crate::prelude::Nat::from(0u32) {
                                            (rs_paxy.clone(), w_ps.clone())
                                        } else {
                                            crate::lower::node_::fresh_name_f(&w_ps, &crate::prelude::Text::from(format!("{}_{}", &rs_paxy, &k_pv)))
                                        };
                                        let bkey_p13 = if &k_pv == &crate::prelude::Nat::from(0u32) {
                                            nkey_p6xy.clone()
                                        } else {
                                            crate::prelude::Text::from(format!("{}#inst{}", &nkey_p6xy, &k_pv))
                                        };
                                        let (be2_p17, me2_p18) = crate::lower::node_::bind_plain_f(&be_pt, &me_pu, &bkey_p13, &rk_p15, &tk_p12);
                                        let ukey_p14 = crate::prelude::Text::from(format!("{}#{}", &nkey_p6xy, &crate::prelude::show_text(&inst_p10)));
                                        ::prism_rtl::Turn::Finished((w2_p16.clone(), with_use_f(&be2_p17, &ukey_p14, &bkey_p13), with_use_f(&me2_p18, &ukey_p14, &bkey_p13)))
                                    })
                                }
                            }))
                        }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>>>
                    })),
                    ::std::option::Option::None => {
                        let (be_p19, me_p1a) = crate::lower::node_::bind_plain_f(benv_p1, menv_p2, &nkey_p6, &rs_pa, &t_p9);
                        (wx1_pb.clone(), be_p19.clone(), me_p1a.clone())
                    },
                },
                _ => unreachable!("no arm matched"),
            }
        }
    }
}

/// The step machine of `PreBindName`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PreBindName: unbounded fn Wx, Env, Env, SName, HowBound -> ((Wx, Env, Env))
/// ```
pub struct PreBindName {
    pub wx_p0: crate::lower::node_::Wx,
    pub benv_p1: crate::lower::types::Env,
    pub menv_p2: crate::lower::types::Env,
    pub n_p3: crate::syntax::SName,
    pub how_p4: HowBound,
}

impl ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)> for PreBindName {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)> {
        let wx_p0 = &self.wx_p0;
        let benv_p1 = &self.benv_p1;
        let menv_p2 = &self.menv_p2;
        let n_p3 = &self.n_p3;
        let how_p4 = &self.how_p4;
        let benv_p1x = benv_p1.clone();
        let how_p4x = how_p4.clone();
        let menv_p2x = menv_p2.clone();
        let n_p3x = n_p3.clone();
        let wx_p0x = wx_p0.clone();
        crate::prelude::call_then(crate::lower::expr::start_widget_let_lx_f(wx_p0x.lx_p.clone(), n_p3x.span_p.clone()), move |widget_let_lx_f_105978: crate::lower::Lx| {
            let lx_p5 = widget_let_lx_f_105978;
            let nkey_p6 = crate::check::env::sname_key_f(&n_p3x);
            let full_p7 = crate::lower::binder_ty_f(&lx_p5, &n_p3x.span_p);
            let layer_p8 = crate::lower::types::layer_of_f(&full_p7);
            crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p5.clone(), crate::lower::types::peel_f(&full_p7)), move |out_ty_of_f_106106: crate::lower::model::OutTy| {
                let t_p9 = out_ty_of_f_106106;
                crate::prelude::call_then(crate::lower::start_local_name_at_f(lx_p5.clone(), nkey_p6.clone(), n_p3x.span_p.clone()), move |local_name_at_f_106257: crate::prelude::Text| {
                    let (rs_pa, wx1_pb) = crate::lower::node_::fresh_name_f(&wx_p0x, &local_name_at_f_106257);
                    if ((((&how_p4x == &HowBound::AsBind) || (&how_p4x == &HowBound::AsResult)) || (&how_p4x == &HowBound::AsLet)) || (&how_p4x == &HowBound::AsLatePlace)) && crate::lower::types::is_bundle_f(&full_p7) {
                        ::prism_rtl::Turn::Finished((wx_p0x.clone(), benv_p1x.clone(), menv_p2x.clone()))
                    } else {
                        if (&layer_p8 == &crate::lower::types::Layer::LyEv) || is_switched_f(&full_p7) {
                            crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p5.clone(), crate::lower::types::peel_f(&crate::lower::types::peel_f(&full_p7))), move |out_ty_of_f_106694: crate::lower::model::OutTy| {
                                let et_pc = out_ty_of_f_106694;
                                let (id_pj, wx2_pk) = crate::lower::node_::add_gn_f(&wx1_pb, &rs_pa, &et_pc, &crate::lower::node_::GnKind::GnNamed, &crate::prelude::Nat::from(0u32));
                                let b_pd = crate::lower::types::Bn::BnEv(crate::lower::node_::ev_ref_of_f(&wx2_pk, &id_pj), t_p9.clone());
                                let pf_pe = crate::prelude::Text::from(format!("{}_v_port", &rs_pa));
                                let pt_pf = crate::lower::model::OutTy::OutRc(::std::rc::Rc::new(crate::lower::model::OutTy::OutPort(::std::rc::Rc::new(et_pc.clone()))));
                                let wx3_pg = {
                                    let mut this: crate::lower::node_::Wx = crate::lower::node_::connect_f(&wx2_pk, &crate::lower::node_::ev_ref_of_f(&wx2_pk, &id_pj), &crate::lower::node_::Sk::SkPort(crate::prelude::Text::from(format!("{}_v", &rs_pa))));
                                    this.lets_p = crate::prelude::push(&this.lets_p, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaBind(pf_pe.clone())), pt_pf.clone()), crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Rc::new")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Port::new")), crate::prelude::Array::new())]))));
                                    this.fields_p = crate::prelude::push(&this.fields_p, &(pf_pe.clone(), pt_pf.clone(), crate::prelude::Text::from(format!("`{}` as a value: the port it fires", &nkey_p6))));
                                    this.moves_p = crate::prelude::push(&this.moves_p, &(pf_pe.clone(), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(pf_pe.clone())))));
                                    this
                                };
                                let be_ph = crate::lower::types::bind_f(&crate::lower::types::bind_f(&benv_p1x, &nkey_p6, &b_pd), &crate::prelude::Text::from(format!("{}#port", &nkey_p6)), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(pf_pe.clone()), crate::lower::types::Holding::Owned, pt_pf.clone()));
                                let me_pi = crate::lower::types::bind_f(&crate::lower::types::bind_f(&menv_p2x, &nkey_p6, &b_pd), &crate::prelude::Text::from(format!("{}#port", &nkey_p6)), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), pf_pe.clone()), crate::lower::types::Holding::Owned, pt_pf.clone()));
                                ::prism_rtl::Turn::Finished((wx3_pg.clone(), be_ph.clone(), me_pi.clone()))
                            })
                        } else {
                            match (layer_p8.clone(), how_p4x.clone()) {
                                (crate::lower::types::Layer::LyDyn, HowBound::AsLet) => {
                                    let b_pl = crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), rs_pa.clone(), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx])), crate::prelude::Array::from(vec![crate::lower::node_::Read::OwnRead(rs_pa.clone())]), t_p9.clone());
                                    ::prism_rtl::Turn::Finished((wx1_pb.clone(), crate::lower::types::bind_f(&benv_p1x, &nkey_p6, &b_pl), crate::lower::types::bind_f(&menv_p2x, &nkey_p6, &b_pl)))
                                },
                                (_, HowBound::AsLet) if (crate::lower::types::time_within_f(&full_p7) && !crate::lower::types::is_bundle_f(&full_p7)) => crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p5.clone(), full_p7.clone()), move |out_ty_of_f_108170: crate::lower::model::OutTy| {
                                    let b_pm = crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), rs_pa.clone(), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx])), crate::prelude::Array::from(vec![crate::lower::node_::Read::OwnRead(rs_pa.clone())]), out_ty_of_f_108170);
                                    ::prism_rtl::Turn::Finished((wx1_pb.clone(), crate::lower::types::bind_f(&benv_p1x, &nkey_p6, &b_pm), crate::lower::types::bind_f(&menv_p2x, &nkey_p6, &b_pm)))
                                }),
                                (crate::lower::types::Layer::LyDyn, HowBound::AsResult) => {
                                    let b_pn = crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), rs_pa.clone(), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx])), crate::prelude::Array::from(vec![crate::lower::node_::Read::OwnRead(rs_pa.clone())]), t_p9.clone());
                                    ::prism_rtl::Turn::Finished((wx1_pb.clone(), crate::lower::types::bind_f(&benv_p1x, &nkey_p6, &b_pn), crate::lower::types::bind_f(&menv_p2x, &nkey_p6, &b_pn)))
                                },
                                (crate::lower::types::Layer::LyDyn, HowBound::AsLateHold) => {
                                    let b_po = crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), rs_pa.clone())), crate::prelude::Text::lit("get"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx]))), crate::prelude::Text::lit("expect"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XStr(crate::prelude::Text::lit("a hold that starts from a late result is set when that result is built"))])), crate::prelude::Array::from(vec![crate::lower::node_::Read::OwnRead(rs_pa.clone())]), t_p9.clone());
                                    ::prism_rtl::Turn::Finished((wx1_pb.clone(), crate::lower::types::bind_f(&benv_p1x, &nkey_p6, &b_po), crate::lower::types::bind_f(&menv_p2x, &nkey_p6, &b_po)))
                                },
                                (crate::lower::types::Layer::LyDyn, HowBound::AsLatePlace) => {
                                    let b_pp = late_place_bn_f(&rs_pa, &t_p9);
                                    ::prism_rtl::Turn::Finished((wx1_pb.clone(), crate::lower::types::bind_f(&benv_p1x, &nkey_p6, &b_pp), crate::lower::types::bind_f(&menv_p2x, &nkey_p6, &b_pp)))
                                },
                                (crate::lower::types::Layer::LyDyn, _) => {
                                    let b_pq = crate::lower::types::Bn::BnHold(rs_pa.clone(), t_p9.clone());
                                    ::prism_rtl::Turn::Finished((wx1_pb.clone(), crate::lower::types::bind_f(&benv_p1x, &nkey_p6, &b_pq), crate::lower::types::bind_f(&menv_p2x, &nkey_p6, &b_pq)))
                                },
                                _ => match many_instances_o(&wx_p0x.lx_p, &n_p3x.span_p) {
                                    ::std::option::Option::Some(insts_pr) => crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(&insts_pr)), (wx1_pb.clone(), benv_p1x.clone(), menv_p2x.clone()), {
                                        let insts_prx = insts_pr.clone();
                                        let wx_p0xx = wx_p0x.clone();
                                        let n_p3xx = n_p3x.clone();
                                        let rs_pax = rs_pa.clone();
                                        let nkey_p6x = nkey_p6.clone();
                                        ::std::rc::Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::prelude::Nat)| {
                                            let insts_prxy = insts_prx.clone();
                                            let wx_p0xxy = wx_p0xx.clone();
                                            let n_p3xxy = n_p3xx.clone();
                                            let rs_paxy = rs_pax.clone();
                                            let nkey_p6xy = nkey_p6x.clone();
                                            crate::prelude::entered(crate::prelude::once_job(move || {
                                                let (w_ps, be_pt, me_pu) = p0;
                                                let k_pv = p1;
                                                {
                                                    let inst_p10 = crate::prelude::or(&crate::prelude::index(&insts_prxy, &k_pv), &(crate::prelude::Array::new(), crate::prelude::Array::new()));
                                                    let lxk_p11 = crate::lower::expr::at_instance_f(&wx_p0xxy.lx_p, &inst_p10);
                                                    crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lxk_p11.clone(), crate::lower::types::peel_f(&crate::lower::binder_ty_f(&lxk_p11, &n_p3xxy.span_p))), move |out_ty_of_f_109765: crate::lower::model::OutTy| {
                                                        let tk_p12 = out_ty_of_f_109765;
                                                        let (rk_p15, w2_p16) = if &k_pv == &crate::prelude::Nat::from(0u32) {
                                                            (rs_paxy.clone(), w_ps.clone())
                                                        } else {
                                                            crate::lower::node_::fresh_name_f(&w_ps, &crate::prelude::Text::from(format!("{}_{}", &rs_paxy, &k_pv)))
                                                        };
                                                        let bkey_p13 = if &k_pv == &crate::prelude::Nat::from(0u32) {
                                                            nkey_p6xy.clone()
                                                        } else {
                                                            crate::prelude::Text::from(format!("{}#inst{}", &nkey_p6xy, &k_pv))
                                                        };
                                                        let (be2_p17, me2_p18) = crate::lower::node_::bind_plain_f(&be_pt, &me_pu, &bkey_p13, &rk_p15, &tk_p12);
                                                        let ukey_p14 = crate::prelude::Text::from(format!("{}#{}", &nkey_p6xy, &crate::prelude::show_text(&inst_p10)));
                                                        ::prism_rtl::Turn::Finished((w2_p16.clone(), with_use_f(&be2_p17, &ukey_p14, &bkey_p13), with_use_f(&me2_p18, &ukey_p14, &bkey_p13)))
                                                    })
                                                }
                                            }))
                                        }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>>>
                                    }).cycle(),
                                    ::std::option::Option::None => {
                                        let (be_p19, me_p1a) = crate::lower::node_::bind_plain_f(&benv_p1x, &menv_p2x, &nkey_p6, &rs_pa, &t_p9);
                                        ::prism_rtl::Turn::Finished((wx1_pb.clone(), be_p19.clone(), me_p1a.clone()))
                                    },
                                },
                                _ => unreachable!("no arm matched"),
                            }
                        }
                    }
                })
            })
        })
    }
}

/// `Start PreBindName, x`: what the function value is when passed to `@Run`.
pub fn start_pre_bind_name_f(wx_p0: crate::lower::node_::Wx, benv_p1: crate::lower::types::Env, menv_p2: crate::lower::types::Env, n_p3: crate::syntax::SName, how_p4: HowBound) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>> {
    ::std::rc::Rc::new(PreBindName { wx_p0, benv_p1, menv_p2, n_p3, how_p4 })
}

/// ```prism
/// LatePlaceBn: fn Text, OutTy -> Bn
/// ```
pub fn late_place_bn_f(f_p0: &crate::prelude::Text, t_p1: &crate::lower::model::OutTy) -> crate::lower::types::Bn {
    crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), f_p0.clone())), crate::prelude::Text::lit("get"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx]))), crate::prelude::Text::lit("expect"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XStr(crate::prelude::Text::lit("a hosted place\'s first value is asked once its node stands"))])), crate::prelude::Array::from(vec![crate::lower::node_::Read::OwnRead(f_p0.clone())]), t_p1.clone())
}

/// ```prism
/// ?LatePlaceHold: fn ?Bn -> ?Text
/// ```
pub fn late_place_hold_o(opt0: &::std::option::Option<crate::lower::types::Bn>) -> ::std::option::Option<crate::prelude::Text> {
    'c: {
        if let ::std::option::Option::Some(crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(c0_0_0_0, c0_0_0_1, _), _, _)) = opt0 && let crate::lower::model::Ex::XMethod(c0_0_0_0_r_0, c0_0_0_0_r_1, _) = &**c0_0_0_0 && let crate::lower::model::Ex::XField(c0_0_0_0_r_0_r_0, f_p0) = &**c0_0_0_0_r_0 && let crate::lower::model::Ex::XSelf = &**c0_0_0_0_r_0_r_0 && (c0_0_0_0_r_1 == &crate::prelude::Text::lit("get")) && (c0_0_0_1 == &crate::prelude::Text::lit("expect")) {
            break 'c ::std::option::Option::Some(f_p0.clone());
        }
        if let other_o1 = opt0 {
            break 'c ::std::option::Option::None;
        }
        unreachable!("no clause matched")
    }
}

/// ```prism
/// WithUse: fn Env, Text, Text -> Env
/// ```
pub fn with_use_f(env_p0: &crate::lower::types::Env, ukey_p1: &crate::prelude::Text, bkey_p2: &crate::prelude::Text) -> crate::lower::types::Env {
    let mut this: crate::lower::types::Env = env_p0.clone();
    this.uses_p = crate::prelude::insert(&this.uses_p, ukey_p1, bkey_p2);
    this
}

/// ```prism
/// ?ManyInstances: unbounded fn Lx, Range -> ?[(([((Text, Ty))], [((Text, Col))]))]
/// ```
pub fn many_instances_o(lx_p0: &crate::lower::Lx, span_p1: &crate::syntax::Range) -> ::std::option::Option<crate::prelude::Array<(crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Col)>)>> {
    match crate::prelude::get(&lx_p0.gens_p, &crate::lower::place_key_f(lx_p0, span_p1)) {
        ::std::option::Option::Some(gn_p2) => {
            let insts_p3 = crate::lower::expr::instantiations_f(lx_p0, &gn_p2);
            if &crate::prelude::len(&insts_p3) > &crate::prelude::Nat::from(1u32) {
                ::std::option::Option::Some(insts_p3.clone())
            } else {
                ::std::option::Option::None
            }
        },
        ::std::option::Option::None => ::std::option::Option::None,
    }
}

/// ```prism
/// IsSwitched: fn Ty -> Bool
/// ```
pub fn is_switched_f(t_p0: &crate::check::types::Ty) -> bool {
    'm111528: {
        if let crate::check::types::Ty::TySig(m111528_0_0, m111528_0_1) = t_p0 && (m111528_0_0 == &crate::prelude::Text::lit("$")) && let crate::check::types::Ty::TySig(m111528_0_1_r_0, _) = &**m111528_0_1 && (m111528_0_1_r_0 == &crate::prelude::Text::lit("!")) {
            break 'm111528 true;
        }
        false
    }
}

/// ```prism
/// ?BindingOf: fn Env, Pattern -> ?Bn
/// ```
pub fn binding_of_o(env_p0: &crate::lower::types::Env, p_p1: &crate::syntax::Pattern) -> ::std::option::Option<crate::lower::types::Bn> {
    match &*p_p1.kind_p {
        crate::syntax::PatternKind::PName(n_p2) => crate::prelude::get(&env_p0.names_p, &crate::check::env::sname_key_f(n_p2)),
        crate::syntax::PatternKind::PTuple(ps_p3) => ::std::option::Option::Some(crate::lower::types::Bn::BnParts(crate::prelude::each(ps_p3, &(|q_p4: &crate::syntax::Pattern| binding_of_name_o(env_p0, q_p4))))),
        _ => ::std::option::Option::None,
    }
}

/// ```prism
/// ?BindingOfName: fn Env, Pattern -> ?Bn
/// ```
pub fn binding_of_name_o(env_p0: &crate::lower::types::Env, p_p1: &crate::syntax::Pattern) -> ::std::option::Option<crate::lower::types::Bn> {
    match &*p_p1.kind_p {
        crate::syntax::PatternKind::PName(n_p2) => crate::prelude::get(&env_p0.names_p, &crate::check::env::sname_key_f(n_p2)),
        _ => crate::prelude::get(&env_p0.names_p, &part_hold_key_f(p_p1)),
    }
}

/// ```prism
/// LineExprs: fn Stmt -> [Expr]
/// ```
pub fn line_exprs_f(s_p0: &crate::syntax::Stmt) -> crate::prelude::Array<crate::syntax::Expr> {
    match &s_p0.kind_p {
        crate::syntax::StmtKind::SBind(_, e_p1, ::std::option::Option::Some(step_p2)) => crate::prelude::Array::from(vec![e_p1.clone(), step_p2.clone()]),
        crate::syntax::StmtKind::SBind(_, e_p3, ::std::option::Option::None) => crate::prelude::Array::from(vec![e_p3.clone()]),
        crate::syntax::StmtKind::SIgnore(e_p4) => crate::prelude::Array::from(vec![e_p4.clone()]),
        crate::syntax::StmtKind::SLet(_, _, e_p5) => crate::prelude::Array::from(vec![e_p5.clone()]),
        crate::syntax::StmtKind::SExpr(e_p6) => crate::prelude::Array::from(vec![e_p6.clone()]),
        _ => crate::prelude::Array::new(),
    }
}

/// ```prism
/// IsLetOfBlueprint: fn Stmt -> Bool
/// ```
pub fn is_let_of_blueprint_f(s_p0: &crate::syntax::Stmt) -> bool {
    match &s_p0.kind_p {
        crate::syntax::StmtKind::SLet(_, _, _) => true,
        _ => false,
    }
}

/// ```prism
/// WidgetStmt: unbounded fn Wx, Env, Env, Stmt, Bool -> ((Wx, Env, Env))
/// ```
pub fn widget_stmt_f(wx0_p0: &crate::lower::node_::Wx, benv0_p1: &crate::lower::types::Env, menv0_p2: &crate::lower::types::Env, s_p3: &crate::syntax::Stmt, last_p4: &bool) -> (crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env) {
    let held_init_p5 = match &s_p3.kind_p {
        crate::syntax::StmtKind::SBind(p_p8, init_p9, ::std::option::Option::Some(_)) => if is_held_hold_f(&wx0_p0.lx_p, p_p8) {
            init_key_f(init_p9)
        } else {
            crate::prelude::Text::lit("")
        },
        _ => crate::prelude::Text::lit(""),
    };
    let step_key_p6 = match &s_p3.kind_p {
        crate::syntax::StmtKind::SBind(_, _, ::std::option::Option::Some(step_pa)) => init_key_f(step_pa),
        _ => crate::prelude::Text::lit(""),
    };
    let (wxw_pf, benvw_pg, menvw_ph) = crate::prelude::run_to_end(crate::prelude::fold_job(line_exprs_f(s_p3), (wx0_p0.clone(), benv0_p1.clone(), menv0_p2.clone()), {
        let held_init_p5x = held_init_p5.clone();
        let step_key_p6x = step_key_p6.clone();
        ::std::rc::Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::syntax::Expr)| {
            let held_init_p5xy = held_init_p5x.clone();
            let step_key_p6xy = step_key_p6x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (w_pb, be_pc, me_pd) = p0;
                let e_pe = p1;
                ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::lower::node_::static_::WholeArgsAt { wx_p0: w_pb.clone(), benv_p1: be_pc.clone(), menv_p2: me_pd.clone(), e_p3: e_pe.clone(), whole_p4: &init_key_f(&e_pe) == &held_init_p5xy, late_p5: &init_key_f(&e_pe) == &step_key_p6xy }))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::syntax::Expr)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>>>
    }));
    let (wx_pm, benv_pn, menv_po) = crate::prelude::run_to_end(crate::prelude::fold_job(line_exprs_f(s_p3), (wxw_pf.clone(), benvw_pg.clone(), menvw_ph.clone()), {
        let s_p3x = s_p3.clone();
        ::std::rc::Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::syntax::Expr)| {
            let s_p3xy = s_p3x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (w_pi, be_pj, me_pk) = p0;
                let e_pl = p1;
                ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::lower::node_::static_::BlueprintValuesAt { wx_p0: w_pi.clone(), benv_p1: be_pj.clone(), menv_p2: me_pk.clone(), e_p3: e_pl.clone(), named_p4: is_let_of_blueprint_f(&s_p3xy) }))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::syntax::Expr)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>>>
    }));
    let lx_p7 = wx_pm.lx_p.clone();
    match &s_p3.kind_p {
        crate::syntax::StmtKind::SBind(p_pp, e_pq, ::std::option::Option::None) => {
            let (wx2_ps, res_pt) = if crate::lower::node_::switch_::is_some_f(&taker_getter_o(&menv_po, p_pp)) && is_late_taker_f(&wx_pm.lx_p, &menv_po, &crate::lower::node_::static_::ungrouped_f(e_pq)) {
                deferred_line_f(&wx_pm, &menv_po, &crate::lower::node_::static_::ungrouped_f(e_pq), &true)
            } else {
                build_line_f(&wx_pm, &benv_pn, &menv_po, e_pq, &binding_of_o(&menv_po, p_pp))
            };
            let wx3_pr = bind_res_f(&wx2_ps, &menv_po, p_pp, &res_pt);
            match (res_pt.clone(), (*p_pp.kind_p).clone()) {
                (crate::lower::node_::Wres::WrLate(read_pu, t_pv), crate::syntax::PatternKind::PName(n_p10)) if crate::lower::node_::switch_::is_some_f(&taker_getter_o(&menv_po, p_pp)) => {
                    let late_p11 = LateName { getter_p: crate::prelude::or(&taker_getter_o(&menv_po, p_pp), &crate::prelude::Text::lit("")), part_o: ::std::option::Option::None, ty_p: t_pv, name_p: crate::check::env::sname_key_f(&n_p10), within_o: ::std::option::Option::None };
                    (late_getters_f(&wx3_pr, &crate::prelude::Array::from(vec![late_p11.clone()]), &read_pu, &crate::prelude::Array::new()), benv_pn.clone(), menv_po.clone())
                },
                (crate::lower::node_::Wres::WrDyn(ex_p12, rds_p13, t_p14), crate::syntax::PatternKind::PName(n_p15)) => {
                    let b_p16 = crate::lower::types::Bn::BnDyn(ex_p12.clone(), rds_p13.clone(), t_p14.clone());
                    result_getter_f(&wx3_pr, &menv_po, &n_p15, &ex_p12, &rds_p13, &t_p14, &crate::lower::types::bind_f(&benv_pn, &crate::check::env::sname_key_f(&n_p15), &b_p16), &crate::lower::types::bind_f(&menv_po, &crate::check::env::sname_key_f(&n_p15), &b_p16))
                },
                (crate::lower::node_::Wres::WrHosted(inner_p17, doc_p18), crate::syntax::PatternKind::PTuple(ps_p19)) => bind_hosted_f(&wx3_pr, &benv_pn, &menv_po, &*inner_p17, &doc_p18, &ps_p19),
                (crate::lower::node_::Wres::WrParts(parts_p1a), crate::syntax::PatternKind::PTuple(ps_p1b)) => bind_parts_f(&wx2_ps, &benv_pn, &menv_po, &parts_p1a, &ps_p1b, &crate::lower::node_::keyed::bundle_part_tys_f(&crate::lower::types::out_of_f(&crate::lower::type_at_f(&lx_p7, &e_pq.span_p)))),
                (crate::lower::node_::Wres::WrParts(parts_p1c), crate::syntax::PatternKind::PName(n_p1d)) => {
                    let (wx4_p1e, builds_p1f, methods_p1g) = fielded_parts_f(&wx3_pr, &crate::lower::snake_f(&crate::check::env::sname_key_f(&n_p1d)), &parts_p1c);
                    (wx4_p1e.clone(), crate::lower::types::bind_f(&benv_pn, &crate::check::env::sname_key_f(&n_p1d), &crate::lower::types::Bn::BnParts(builds_p1f.clone())), crate::lower::types::bind_f(&menv_po, &crate::check::env::sname_key_f(&n_p1d), &crate::lower::types::Bn::BnParts(methods_p1g.clone())))
                },
                (crate::lower::node_::Wres::WrPlain(ex_p1h, t_p1i), _) => if is_names_pattern_f(p_pp) {
                    (bind_plain_result_f(&wx3_pr, &menv_po, p_pp, &ex_p1h, &t_p1i), benv_pn.clone(), menv_po.clone())
                } else {
                    (bind_pattern_result_f(&wx3_pr, &menv_po, p_pp, &ex_p1h, &t_p1i, &crate::lower::types::out_of_f(&crate::lower::type_at_f(&lx_p7, &e_pq.span_p))), benv_pn.clone(), menv_po.clone())
                },
                (crate::lower::node_::Wres::WrLate(_, t_p1j), _) if crate::check::types::has_text_f(&wx_pm.early_choices_p, &pure_choice_key_f(e_pq)) => {
                    let ex_p1k = crate::lower::types::own_f(&pure_choice_value_f(&lx_p7, &benv_pn, e_pq));
                    if is_names_pattern_f(p_pp) {
                        (bind_plain_result_f(&wx3_pr, &menv_po, p_pp, &ex_p1k, &t_p1j), benv_pn.clone(), menv_po.clone())
                    } else {
                        (bind_pattern_result_f(&wx3_pr, &menv_po, p_pp, &ex_p1k, &t_p1j, &crate::lower::types::out_of_f(&crate::lower::type_at_f(&lx_p7, &e_pq.span_p))), benv_pn.clone(), menv_po.clone())
                    }
                },
                (crate::lower::node_::Wres::WrLate(_, _), _) => ({
                    let mut this: crate::lower::node_::Wx = wx3_pr.clone();
                    this.build_p = crate::prelude::push(&this.build_p, &crate::lower::expr::internal_bug_do_f(&crate::prelude::Text::lit("a late plain result bound where its block is not split")));
                    this
                }, benv_pn.clone(), menv_po.clone()),
                _ => (wx3_pr.clone(), benv_pn.clone(), menv_po.clone()),
                _ => unreachable!("no arm matched"),
            }
        },
        crate::syntax::StmtKind::SBind(p_p1l, init_p1m, ::std::option::Option::Some(step_p1n)) => {
            let (wx2_p1o, be2_p1p) = hold_line_f(&wx_pm, &benv_pn, &menv_po, p_p1l, init_p1m, step_p1n);
            (wx2_p1o.clone(), be2_p1p.clone(), menv_po.clone())
        },
        crate::syntax::StmtKind::SIgnore(e_p1q) => {
            let (wx2_p1r, _) = build_line_f(&wx_pm, &benv_pn, &menv_po, e_p1q, &::std::option::Option::None);
            (wx2_p1r.clone(), benv_pn.clone(), menv_po.clone())
        },
        crate::syntax::StmtKind::SLet(p_p1s, _, e_p1t) => match bundle_named_o(&menv_po, p_p1s, e_p1t) {
            ::std::option::Option::Some((n_p1u, b_p1v)) => {
                let at_build_p20 = match bundle_named_o(&benv_pn, p_p1s, e_p1t) {
                    ::std::option::Option::Some((_, spelled_p21)) => spelled_p21,
                    ::std::option::Option::None => b_p1v.clone(),
                };
                (wx_pm.clone(), value_renamed_f(&crate::lower::types::bind_f(&benv_pn, &crate::check::env::sname_key_f(&n_p1u), &at_build_p20), &n_p1u, e_p1t), value_renamed_f(&crate::lower::types::bind_f(&menv_po, &crate::check::env::sname_key_f(&n_p1u), &b_p1v), &n_p1u, e_p1t))
            },
            ::std::option::Option::None => match if is_late_bundle_let_f(&menv_po, p_p1s) {
                bundle_written_o(&lx_p7, p_p1s, e_p1t)
            } else {
                ::std::option::Option::None
            } {
                ::std::option::Option::Some((n_p22, tuple_p23)) => late_bundle_let_f(&wx_pm, &benv_pn, &menv_po, &n_p22, &tuple_p23),
                ::std::option::Option::None => if is_placed_let_f(&menv_po, p_p1s) || (is_late_let_f(&menv_po, p_p1s) && !takes_late_bundle_f(&menv_po, p_p1s, e_p1t)) {
                    (wx_pm.clone(), benv_pn.clone(), menv_po.clone())
                } else {
                    match bundle_written_o(&lx_p7, p_p1s, e_p1t) {
                        ::std::option::Option::Some((n_p24, tuple_p25)) => {
                            let (res_p26, wx2_p27) = result_of_f(&wx_pm, &benv_pn, &menv_po, &tuple_p25);
                            let (wx2f_p28, builds_p29, methods_p2a) = fielded_parts_f(&wx2_p27, &crate::lower::snake_f(&crate::check::env::sname_key_f(&n_p24)), &result_parts_f(&res_p26));
                            bundle_value_f(&wx2f_p28, &crate::lower::types::bind_f(&benv_pn, &crate::check::env::sname_key_f(&n_p24), &crate::lower::types::Bn::BnParts(builds_p29.clone())), &crate::lower::types::bind_f(&menv_po, &crate::check::env::sname_key_f(&n_p24), &crate::lower::types::Bn::BnParts(methods_p2a.clone())), &n_p24, &tuple_p25, &bn_res_f(&crate::lower::types::Bn::BnParts(builds_p29.clone())))
                        },
                        ::std::option::Option::None => match named_bundle_taken_o(&menv_po, p_p1s, e_p1t) {
                            ::std::option::Option::Some((ps_p2b, methods_p2c)) => {
                                let builds_p2d = match named_bundle_taken_o(&benv_pn, p_p1s, e_p1t) {
                                    ::std::option::Option::Some((_, bs_p2e)) => plain_at_build_f(&methods_p2c, &bs_p2e),
                                    ::std::option::Option::None => methods_p2c.clone(),
                                };
                                bind_named_parts_f(&wx_pm, &benv_pn, &menv_po, &ps_p2b, &crate::lower::node_::keyed::bundle_part_tys_f(&crate::lower::type_at_f(&lx_p7, &e_p1t.span_p)), &methods_p2c, &builds_p2d)
                            },
                            ::std::option::Option::None => {
                                let (wx2_p2f, be2_p2g) = let_line_f(&wx_pm, &benv_pn, &menv_po, p_p1s, e_p1t);
                                (wx2_p2f.clone(), be2_p2g.clone(), menv_po.clone())
                            },
                        },
                    }
                },
            },
        },
        crate::syntax::StmtKind::SExpr(e_p2h) => match &*e_p2h.kind_p {
            crate::syntax::ExprKind::EFreeSigil(m119401_0_0, x_p2i) if (m119401_0_0 == &crate::prelude::Text::lit("@")) => {
                let (res_p2k, wx2_p2l) = if (&wx_pm.whole_result_at_p != &crate::prelude::Text::lit("")) && (&wx_pm.whole_result_at_p == &crate::lower::node_::switch_::result_key_f(&lx_p7, &**x_p2i)) {
                    whole_result_of_f(&wx_pm, &benv_pn, &menv_po, &**x_p2i)
                } else {
                    result_of_f(&wx_pm, &benv_pn, &menv_po, &**x_p2i)
                };
                let wx3_p2j = {
                    let mut this: crate::lower::node_::Wx = wx2_p2l.clone();
                    this.result_p = res_p2k.clone();
                    this
                };
                (wx3_p2j.clone(), benv_pn.clone(), menv_po.clone())
            },
            _ => {
                let (wx2_p2n, res_p2o) = build_line_f(&wx_pm, &benv_pn, &menv_po, e_p2h, &::std::option::Option::None);
                let wx3_p2m = if *last_p4 { set_result_f(&wx2_p2n, &res_p2o) } else { wx2_p2n.clone() };
                (wx3_p2m.clone(), benv_pn.clone(), menv_po.clone())
            },
            _ => unreachable!("no arm matched"),
        },
        crate::syntax::StmtKind::SEmit(_) => (wx_pm.clone(), benv_pn.clone(), menv_po.clone()),
        crate::syntax::StmtKind::SSignature(_) => (wx_pm.clone(), benv_pn.clone(), menv_po.clone()),
        crate::syntax::StmtKind::SFn(c_p2p) => (wx_pm.clone(), benv_pn.clone(), menv_po.clone()),
        crate::syntax::StmtKind::SWidget(_) => (wx_pm.clone(), benv_pn.clone(), menv_po.clone()),
        _ => {
            let wx2_p2q = {
                let mut this: crate::lower::node_::Wx = wx_pm.clone();
                this.build_p = crate::prelude::push(&this.build_p, &crate::lower::expr::internal_bug_do_f(&crate::prelude::Text::lit("a statement of a widget block that is none of its kinds")));
                this
            };
            (wx2_p2q.clone(), benv_pn.clone(), menv_po.clone())
        },
    }
}

/// The step machine of `WidgetStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// WidgetStmt: unbounded fn Wx, Env, Env, Stmt, Bool -> ((Wx, Env, Env))
/// ```
pub struct WidgetStmt {
    pub wx0_p0: crate::lower::node_::Wx,
    pub benv0_p1: crate::lower::types::Env,
    pub menv0_p2: crate::lower::types::Env,
    pub s_p3: crate::syntax::Stmt,
    pub last_p4: bool,
}

impl ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)> for WidgetStmt {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)> {
        let wx0_p0 = &self.wx0_p0;
        let benv0_p1 = &self.benv0_p1;
        let menv0_p2 = &self.menv0_p2;
        let s_p3 = &self.s_p3;
        let last_p4 = &self.last_p4;
        let held_init_p5 = match &s_p3.kind_p {
            crate::syntax::StmtKind::SBind(p_p8, init_p9, ::std::option::Option::Some(_)) => if is_held_hold_f(&wx0_p0.lx_p, p_p8) {
                init_key_f(init_p9)
            } else {
                crate::prelude::Text::lit("")
            },
            _ => crate::prelude::Text::lit(""),
        };
        let step_key_p6 = match &s_p3.kind_p {
            crate::syntax::StmtKind::SBind(_, _, ::std::option::Option::Some(step_pa)) => init_key_f(step_pa),
            _ => crate::prelude::Text::lit(""),
        };
        let benv0_p1x = benv0_p1.clone();
        let last_p4x = *last_p4;
        let menv0_p2x = menv0_p2.clone();
        let s_p3x = s_p3.clone();
        let wx0_p0x = wx0_p0.clone();
        crate::prelude::call_value(crate::prelude::fold_job(line_exprs_f(&s_p3x), (wx0_p0x.clone(), benv0_p1x.clone(), menv0_p2x.clone()), {
            let held_init_p5x = held_init_p5.clone();
            let step_key_p6x = step_key_p6.clone();
            ::std::rc::Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::syntax::Expr)| {
                let held_init_p5xy = held_init_p5x.clone();
                let step_key_p6xy = step_key_p6x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let (w_pb, be_pc, me_pd) = p0;
                    let e_pe = p1;
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::lower::node_::static_::WholeArgsAt { wx_p0: w_pb.clone(), benv_p1: be_pc.clone(), menv_p2: me_pd.clone(), e_p3: e_pe.clone(), whole_p4: &init_key_f(&e_pe) == &held_init_p5xy, late_p5: &init_key_f(&e_pe) == &step_key_p6xy }))
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::syntax::Expr)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>>>
        }), move |fold_113402: (crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)| {
            let (wxw_pf, benvw_pg, menvw_ph) = fold_113402;
            crate::prelude::call_value(crate::prelude::fold_job(line_exprs_f(&s_p3x), (wxw_pf.clone(), benvw_pg.clone(), menvw_ph.clone()), {
                let s_p3xx = s_p3x.clone();
                ::std::rc::Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::syntax::Expr)| {
                    let s_p3xxy = s_p3xx.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let (w_pi, be_pj, me_pk) = p0;
                        let e_pl = p1;
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::lower::node_::static_::BlueprintValuesAt { wx_p0: w_pi.clone(), benv_p1: be_pj.clone(), menv_p2: me_pk.clone(), e_p3: e_pl.clone(), named_p4: is_let_of_blueprint_f(&s_p3xxy) }))
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::syntax::Expr)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>>>
            }), move |fold_113640: (crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)| {
                let (wx_pm, benv_pn, menv_po) = fold_113640;
                let lx_p7 = wx_pm.lx_p.clone();
                match &s_p3x.kind_p {
                    crate::syntax::StmtKind::SBind(p_pp, e_pq, ::std::option::Option::None) => {
                        let benv_pnz = benv_pn.clone();
                        let e_pqz = e_pq.clone();
                        let lx_p7z = lx_p7.clone();
                        let menv_poz = menv_po.clone();
                        let p_ppz = p_pp.clone();
                        let wx_pmz = wx_pm.clone();
                        let k_let113830 = move |v113830: (crate::lower::node_::Wx, crate::lower::node_::Wres)| {
                            let (wx2_ps, res_pt) = v113830;
                            let wx3_pr = bind_res_f(&wx2_ps, &menv_poz, &p_ppz, &res_pt);
                            match (res_pt.clone(), (*p_ppz.kind_p).clone()) {
                                (crate::lower::node_::Wres::WrLate(read_pu, t_pv), crate::syntax::PatternKind::PName(n_p10)) if crate::lower::node_::switch_::is_some_f(&taker_getter_o(&menv_poz, &p_ppz)) => {
                                    let late_p11 = LateName { getter_p: crate::prelude::or(&taker_getter_o(&menv_poz, &p_ppz), &crate::prelude::Text::lit("")), part_o: ::std::option::Option::None, ty_p: t_pv.clone(), name_p: crate::check::env::sname_key_f(&n_p10), within_o: ::std::option::Option::None };
                                    crate::prelude::call_then(start_late_getters_f(wx3_pr.clone(), crate::prelude::Array::from(vec![late_p11.clone()]), read_pu.clone(), crate::prelude::Array::new()), move |late_getters_f_114496: crate::lower::node_::Wx| ::prism_rtl::Turn::Finished((late_getters_f_114496, benv_pnz.clone(), menv_poz.clone())))
                                },
                                (crate::lower::node_::Wres::WrDyn(ex_p12, rds_p13, t_p14), crate::syntax::PatternKind::PName(n_p15)) => {
                                    let b_p16 = crate::lower::types::Bn::BnDyn(ex_p12.clone(), rds_p13.clone(), t_p14.clone());
                                    ::prism_rtl::Turn::Finished(result_getter_f(&wx3_pr, &menv_poz, &n_p15, &ex_p12, &rds_p13, &t_p14, &crate::lower::types::bind_f(&benv_pnz, &crate::check::env::sname_key_f(&n_p15), &b_p16), &crate::lower::types::bind_f(&menv_poz, &crate::check::env::sname_key_f(&n_p15), &b_p16)))
                                },
                                (crate::lower::node_::Wres::WrHosted(inner_p17, doc_p18), crate::syntax::PatternKind::PTuple(ps_p19)) => ::prism_rtl::Turn::More(::std::rc::Rc::new(BindHosted { wx_p0: wx3_pr.clone(), benv_p1: benv_pnz.clone(), menv_p2: menv_poz.clone(), res_p3: (*inner_p17).clone(), doc_p4: doc_p18.clone(), ps_p5: ps_p19.clone() })),
                                (crate::lower::node_::Wres::WrParts(parts_p1a), crate::syntax::PatternKind::PTuple(ps_p1b)) => ::prism_rtl::Turn::More(::std::rc::Rc::new(BindParts { wx_p0: wx2_ps.clone(), benv_p1: benv_pnz.clone(), menv_p2: menv_poz.clone(), parts_p3: parts_p1a.clone(), ps_p4: ps_p1b.clone(), tys_p5: crate::lower::node_::keyed::bundle_part_tys_f(&crate::lower::types::out_of_f(&crate::lower::type_at_f(&lx_p7z, &e_pqz.span_p))) })),
                                (crate::lower::node_::Wres::WrParts(parts_p1c), crate::syntax::PatternKind::PName(n_p1d)) => crate::prelude::call_then(start_fielded_parts_f(wx3_pr.clone(), crate::lower::snake_f(&crate::check::env::sname_key_f(&n_p1d)), parts_p1c.clone()), move |fielded_parts_f_115231: (crate::lower::node_::Wx, crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>, crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>)| {
                                    let (wx4_p1e, builds_p1f, methods_p1g) = fielded_parts_f_115231;
                                    ::prism_rtl::Turn::Finished((wx4_p1e.clone(), crate::lower::types::bind_f(&benv_pnz, &crate::check::env::sname_key_f(&n_p1d), &crate::lower::types::Bn::BnParts(builds_p1f.clone())), crate::lower::types::bind_f(&menv_poz, &crate::check::env::sname_key_f(&n_p1d), &crate::lower::types::Bn::BnParts(methods_p1g.clone()))))
                                }),
                                (crate::lower::node_::Wres::WrPlain(ex_p1h, t_p1i), _) => if is_names_pattern_f(&p_ppz) {
                                    crate::prelude::call_then(start_bind_plain_result_f(wx3_pr.clone(), menv_poz.clone(), p_ppz.clone(), ex_p1h.clone(), t_p1i.clone()), move |bind_plain_result_f_115465: crate::lower::node_::Wx| ::prism_rtl::Turn::Finished((bind_plain_result_f_115465, benv_pnz.clone(), menv_poz.clone())))
                                } else {
                                    crate::prelude::call_then(start_bind_pattern_result_f(wx3_pr.clone(), menv_poz.clone(), p_ppz.clone(), ex_p1h.clone(), t_p1i.clone(), crate::lower::types::out_of_f(&crate::lower::type_at_f(&lx_p7z, &e_pqz.span_p))), move |bind_pattern_result_f_115525: crate::lower::node_::Wx| ::prism_rtl::Turn::Finished((bind_pattern_result_f_115525, benv_pnz.clone(), menv_poz.clone())))
                                },
                                (crate::lower::node_::Wres::WrLate(_, t_p1j), _) if crate::check::types::has_text_f(&wx_pmz.early_choices_p, &pure_choice_key_f(&e_pqz)) => crate::prelude::call_then(start_pure_choice_value_f(lx_p7z.clone(), benv_pnz.clone(), e_pqz.clone()), move |pure_choice_value_f_116056: crate::lower::types::Vl| {
                                    let ex_p1k = crate::lower::types::own_f(&pure_choice_value_f_116056);
                                    if is_names_pattern_f(&p_ppz) {
                                        crate::prelude::call_then(start_bind_plain_result_f(wx3_pr.clone(), menv_poz.clone(), p_ppz.clone(), ex_p1k.clone(), t_p1j.clone()), move |bind_plain_result_f_116129: crate::lower::node_::Wx| ::prism_rtl::Turn::Finished((bind_plain_result_f_116129, benv_pnz.clone(), menv_poz.clone())))
                                    } else {
                                        crate::prelude::call_then(start_bind_pattern_result_f(wx3_pr.clone(), menv_poz.clone(), p_ppz.clone(), ex_p1k.clone(), t_p1j.clone(), crate::lower::types::out_of_f(&crate::lower::type_at_f(&lx_p7z, &e_pqz.span_p))), move |bind_pattern_result_f_116189: crate::lower::node_::Wx| ::prism_rtl::Turn::Finished((bind_pattern_result_f_116189, benv_pnz.clone(), menv_poz.clone())))
                                    }
                                }),
                                (crate::lower::node_::Wres::WrLate(_, _), _) => ::prism_rtl::Turn::Finished(({
                                    let mut this: crate::lower::node_::Wx = wx3_pr.clone();
                                    this.build_p = crate::prelude::push(&this.build_p, &crate::lower::expr::internal_bug_do_f(&crate::prelude::Text::lit("a late plain result bound where its block is not split")));
                                    this
                                }, benv_pnz.clone(), menv_poz.clone())),
                                _ => ::prism_rtl::Turn::Finished((wx3_pr.clone(), benv_pnz.clone(), menv_poz.clone())),
                                _ => unreachable!("no arm matched"),
                            }
                        };
                        if crate::lower::node_::switch_::is_some_f(&taker_getter_o(&menv_po, p_pp)) && is_late_taker_f(&wx_pm.lx_p, &menv_po, &crate::lower::node_::static_::ungrouped_f(e_pq)) {
                            {
                                let e_pqx = e_pq.clone();
                                crate::prelude::call_then(start_deferred_line_f(wx_pm.clone(), menv_po.clone(), crate::lower::node_::static_::ungrouped_f(&e_pqx), true), move |deferred_line_f_113928: (crate::lower::node_::Wx, crate::lower::node_::Wres)| k_let113830(deferred_line_f_113928))
                            }
                        } else {
                            {
                                let e_pqx = e_pq.clone();
                                let p_ppx = p_pp.clone();
                                crate::prelude::call_then(start_build_line_f(wx_pm.clone(), benv_pn.clone(), menv_po.clone(), e_pqx.clone(), binding_of_o(&menv_po, &p_ppx)), move |build_line_f_113977: (crate::lower::node_::Wx, crate::lower::node_::Wres)| k_let113830(build_line_f_113977))
                            }
                        }
                    },
                    crate::syntax::StmtKind::SBind(p_p1l, init_p1m, ::std::option::Option::Some(step_p1n)) => {
                        let init_p1mx = init_p1m.clone();
                        let p_p1lx = p_p1l.clone();
                        let step_p1nx = step_p1n.clone();
                        crate::prelude::call_then(start_hold_line_f(wx_pm.clone(), benv_pn.clone(), menv_po.clone(), p_p1lx.clone(), init_p1mx.clone(), step_p1nx.clone()), move |hold_line_f_116585: (crate::lower::node_::Wx, crate::lower::types::Env)| {
                            let (wx2_p1o, be2_p1p) = hold_line_f_116585;
                            ::prism_rtl::Turn::Finished((wx2_p1o.clone(), be2_p1p.clone(), menv_po.clone()))
                        })
                    },
                    crate::syntax::StmtKind::SIgnore(e_p1q) => {
                        let e_p1qx = e_p1q.clone();
                        crate::prelude::call_then(start_build_line_f(wx_pm.clone(), benv_pn.clone(), menv_po.clone(), e_p1qx.clone(), ::std::option::Option::None), move |build_line_f_116708: (crate::lower::node_::Wx, crate::lower::node_::Wres)| {
                            let (wx2_p1r, _) = build_line_f_116708;
                            ::prism_rtl::Turn::Finished((wx2_p1r.clone(), benv_pn.clone(), menv_po.clone()))
                        })
                    },
                    crate::syntax::StmtKind::SLet(p_p1s, _, e_p1t) => {
                        let e_p1tx = e_p1t.clone();
                        let p_p1sx = p_p1s.clone();
                        crate::prelude::call_then(start_bundle_named_o(menv_po.clone(), p_p1sx.clone(), e_p1tx.clone()), move |bundle_named_o_116806: ::std::option::Option<(crate::syntax::SName, crate::lower::types::Bn)>| match bundle_named_o_116806 {
                            ::std::option::Option::Some((n_p1u, b_p1v)) => crate::prelude::call_then(start_bundle_named_o(benv_pn.clone(), p_p1sx.clone(), e_p1tx.clone()), move |bundle_named_o_117115: ::std::option::Option<(crate::syntax::SName, crate::lower::types::Bn)>| {
                                let at_build_p20 = match bundle_named_o_117115 {
                                    ::std::option::Option::Some((_, spelled_p21)) => spelled_p21,
                                    ::std::option::Option::None => b_p1v.clone(),
                                };
                                crate::prelude::call_then(start_value_renamed_f(crate::lower::types::bind_f(&benv_pn, &crate::check::env::sname_key_f(&n_p1u), &at_build_p20), n_p1u.clone(), e_p1tx.clone()), move |value_renamed_f_117391: crate::lower::types::Env| crate::prelude::call_then(start_value_renamed_f(crate::lower::types::bind_f(&menv_po, &crate::check::env::sname_key_f(&n_p1u), &b_p1v), n_p1u.clone(), e_p1tx.clone()), move |value_renamed_f_117448: crate::lower::types::Env| ::prism_rtl::Turn::Finished((wx_pm.clone(), value_renamed_f_117391, value_renamed_f_117448))))
                            }),
                            ::std::option::Option::None => match if is_late_bundle_let_f(&menv_po, &p_p1sx) {
                                bundle_written_o(&lx_p7, &p_p1sx, &e_p1tx)
                            } else {
                                ::std::option::Option::None
                            } {
                                ::std::option::Option::Some((n_p22, tuple_p23)) => ::prism_rtl::Turn::More(::std::rc::Rc::new(LateBundleLet { wx_p0: wx_pm.clone(), benv_p1: benv_pn.clone(), menv_p2: menv_po.clone(), n_p3: n_p22.clone(), tuple_p4: tuple_p23.clone() })),
                                ::std::option::Option::None => if is_placed_let_f(&menv_po, &p_p1sx) || (is_late_let_f(&menv_po, &p_p1sx) && !takes_late_bundle_f(&menv_po, &p_p1sx, &e_p1tx)) {
                                    ::prism_rtl::Turn::Finished((wx_pm.clone(), benv_pn.clone(), menv_po.clone()))
                                } else {
                                    crate::prelude::call_then(start_bundle_written_o(lx_p7.clone(), p_p1sx.clone(), e_p1tx.clone()), move |bundle_written_o_118043: ::std::option::Option<(crate::syntax::SName, crate::syntax::Expr)>| match bundle_written_o_118043 {
                                        ::std::option::Option::Some((n_p24, tuple_p25)) => crate::prelude::call_then(start_result_of_f(wx_pm.clone(), benv_pn.clone(), menv_po.clone(), tuple_p25.clone()), move |result_of_f_118394: (crate::lower::node_::Wres, crate::lower::node_::Wx)| {
                                            let (res_p26, wx2_p27) = result_of_f_118394;
                                            crate::prelude::call_then(start_fielded_parts_f(wx2_p27.clone(), crate::lower::snake_f(&crate::check::env::sname_key_f(&n_p24)), result_parts_f(&res_p26)), move |fielded_parts_f_118477: (crate::lower::node_::Wx, crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>, crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>)| {
                                                let (wx2f_p28, builds_p29, methods_p2a) = fielded_parts_f_118477;
                                                ::prism_rtl::Turn::More(::std::rc::Rc::new(BundleValue { wx_p0: wx2f_p28.clone(), benv_p1: crate::lower::types::bind_f(&benv_pn, &crate::check::env::sname_key_f(&n_p24), &crate::lower::types::Bn::BnParts(builds_p29.clone())), menv_p2: crate::lower::types::bind_f(&menv_po, &crate::check::env::sname_key_f(&n_p24), &crate::lower::types::Bn::BnParts(methods_p2a.clone())), n_p3: n_p24.clone(), tuple_p4: tuple_p25.clone(), res_p5: bn_res_f(&crate::lower::types::Bn::BnParts(builds_p29.clone())) }))
                                            })
                                        }),
                                        ::std::option::Option::None => crate::prelude::call_then(start_named_bundle_taken_o(menv_po.clone(), p_p1sx.clone(), e_p1tx.clone()), move |named_bundle_taken_o_118728: ::std::option::Option<(crate::prelude::Array<crate::syntax::Pattern>, crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>)>| match named_bundle_taken_o_118728 {
                                            ::std::option::Option::Some((ps_p2b, methods_p2c)) => crate::prelude::call_then(start_named_bundle_taken_o(benv_pn.clone(), p_p1sx.clone(), e_p1tx.clone()), move |named_bundle_taken_o_118990: ::std::option::Option<(crate::prelude::Array<crate::syntax::Pattern>, crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>)>| {
                                                let benv_pnz = benv_pn.clone();
                                                let e_p1txz = e_p1tx.clone();
                                                let lx_p7z = lx_p7.clone();
                                                let menv_poz = menv_po.clone();
                                                let methods_p2cz = methods_p2c.clone();
                                                let ps_p2bz = ps_p2b.clone();
                                                let wx_pmz = wx_pm.clone();
                                                let k_let118971 = move |v118971: crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>| {
                                                    let builds_p2d = v118971;
                                                    ::prism_rtl::Turn::More(::std::rc::Rc::new(BindNamedParts { wx_p0: wx_pmz.clone(), benv_p1: benv_pnz.clone(), menv_p2: menv_poz.clone(), ps_p3: ps_p2bz.clone(), tys_p4: crate::lower::node_::keyed::bundle_part_tys_f(&crate::lower::type_at_f(&lx_p7z, &e_p1txz.span_p)), methods_p5: methods_p2cz.clone(), builds_p6: builds_p2d.clone() }))
                                                };
                                                match named_bundle_taken_o_118990 {
                                                    ::std::option::Option::Some((_, bs_p2e)) => crate::prelude::call_then(start_plain_at_build_f(methods_p2c.clone(), bs_p2e.clone()), move |plain_at_build_f_119066: crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>| k_let118971(plain_at_build_f_119066)),
                                                    ::std::option::Option::None => k_let118971(methods_p2c.clone()),
                                                }
                                            }),
                                            ::std::option::Option::None => crate::prelude::call_then(start_let_line_f(wx_pm.clone(), benv_pn.clone(), menv_po.clone(), p_p1sx.clone(), e_p1tx.clone()), move |let_line_f_119312: (crate::lower::node_::Wx, crate::lower::types::Env)| {
                                                let (wx2_p2f, be2_p2g) = let_line_f_119312;
                                                ::prism_rtl::Turn::Finished((wx2_p2f.clone(), be2_p2g.clone(), menv_po.clone()))
                                            }),
                                        }),
                                    })
                                },
                            },
                        })
                    },
                    crate::syntax::StmtKind::SExpr(e_p2h) => match &*e_p2h.kind_p {
                        crate::syntax::ExprKind::EFreeSigil(m119401_0_0, x_p2i) if (m119401_0_0 == &crate::prelude::Text::lit("@")) => {
                            let benv_pnz = benv_pn.clone();
                            let menv_poz = menv_po.clone();
                            let k_let119462 = move |v119462: (crate::lower::node_::Wres, crate::lower::node_::Wx)| {
                                let (res_p2k, wx2_p2l) = v119462;
                                let wx3_p2j = {
                                    let mut this: crate::lower::node_::Wx = wx2_p2l.clone();
                                    this.result_p = res_p2k.clone();
                                    this
                                };
                                ::prism_rtl::Turn::Finished((wx3_p2j.clone(), benv_pnz.clone(), menv_poz.clone()))
                            };
                            if (&wx_pm.whole_result_at_p != &crate::prelude::Text::lit("")) && (&wx_pm.whole_result_at_p == &crate::lower::node_::switch_::result_key_f(&lx_p7, &**x_p2i)) {
                                {
                                    let x_p2ix = (**x_p2i).clone();
                                    crate::prelude::call_then(start_whole_result_of_f(wx_pm.clone(), benv_pn.clone(), menv_po.clone(), x_p2ix.clone()), move |whole_result_of_f_119548: (crate::lower::node_::Wres, crate::lower::node_::Wx)| k_let119462(whole_result_of_f_119548))
                                }
                            } else {
                                {
                                    let x_p2ix = (**x_p2i).clone();
                                    crate::prelude::call_then(start_result_of_f(wx_pm.clone(), benv_pn.clone(), menv_po.clone(), x_p2ix.clone()), move |result_of_f_119586: (crate::lower::node_::Wres, crate::lower::node_::Wx)| k_let119462(result_of_f_119586))
                                }
                            }
                        },
                        _ => {
                            let e_p2hx = e_p2h.clone();
                            crate::prelude::call_then(start_build_line_f(wx_pm.clone(), benv_pn.clone(), menv_po.clone(), e_p2hx.clone(), ::std::option::Option::None), move |build_line_f_119782: (crate::lower::node_::Wx, crate::lower::node_::Wres)| {
                                let (wx2_p2n, res_p2o) = build_line_f_119782;
                                let wx3_p2m = if last_p4x { set_result_f(&wx2_p2n, &res_p2o) } else { wx2_p2n.clone() };
                                ::prism_rtl::Turn::Finished((wx3_p2m.clone(), benv_pn.clone(), menv_po.clone()))
                            })
                        },
                        _ => unreachable!("no arm matched"),
                    },
                    crate::syntax::StmtKind::SEmit(_) => ::prism_rtl::Turn::Finished((wx_pm.clone(), benv_pn.clone(), menv_po.clone())),
                    crate::syntax::StmtKind::SSignature(_) => ::prism_rtl::Turn::Finished((wx_pm.clone(), benv_pn.clone(), menv_po.clone())),
                    crate::syntax::StmtKind::SFn(c_p2p) => ::prism_rtl::Turn::Finished((wx_pm.clone(), benv_pn.clone(), menv_po.clone())),
                    crate::syntax::StmtKind::SWidget(_) => ::prism_rtl::Turn::Finished((wx_pm.clone(), benv_pn.clone(), menv_po.clone())),
                    _ => {
                        let wx2_p2q = {
                            let mut this: crate::lower::node_::Wx = wx_pm.clone();
                            this.build_p = crate::prelude::push(&this.build_p, &crate::lower::expr::internal_bug_do_f(&crate::prelude::Text::lit("a statement of a widget block that is none of its kinds")));
                            this
                        };
                        ::prism_rtl::Turn::Finished((wx2_p2q.clone(), benv_pn.clone(), menv_po.clone()))
                    },
                }
            })
        })
    }
}

/// `Start WidgetStmt, x`: what the function value is when passed to `@Run`.
pub fn start_widget_stmt_f(wx0_p0: crate::lower::node_::Wx, benv0_p1: crate::lower::types::Env, menv0_p2: crate::lower::types::Env, s_p3: crate::syntax::Stmt, last_p4: bool) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>> {
    ::std::rc::Rc::new(WidgetStmt { wx0_p0, benv0_p1, menv0_p2, s_p3, last_p4 })
}

/// ```prism
/// ?BundleWritten: unbounded fn Lx, Pattern, Expr -> ?((SName, Expr))
/// ```
pub fn bundle_written_o(lx_p0: &crate::lower::Lx, p_p1: &crate::syntax::Pattern, e_p2: &crate::syntax::Expr) -> ::std::option::Option<(crate::syntax::SName, crate::syntax::Expr)> {
    match ((*p_p1.kind_p).clone(), (*e_p2.kind_p).clone()) {
        (crate::syntax::PatternKind::PName(n_p3), crate::syntax::ExprKind::ETuple(_)) => if crate::lower::types::is_bundle_f(&crate::lower::type_at_f(lx_p0, &e_p2.span_p)) {
            ::std::option::Option::Some((n_p3, e_p2.clone()))
        } else {
            ::std::option::Option::None
        },
        (_, crate::syntax::ExprKind::EGroup(x_p4)) => bundle_written_o(lx_p0, p_p1, &*x_p4),
        _ => ::std::option::Option::None,
    }
}

/// The step machine of `BundleWritten`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?BundleWritten: unbounded fn Lx, Pattern, Expr -> ?((SName, Expr))
/// ```
pub struct BundleWritten {
    pub lx_p0: crate::lower::Lx,
    pub p_p1: crate::syntax::Pattern,
    pub e_p2: crate::syntax::Expr,
}

impl ::prism_rtl::Job<::std::option::Option<(crate::syntax::SName, crate::syntax::Expr)>> for BundleWritten {
    fn cycle(&self) -> ::prism_rtl::Turn<::std::option::Option<(crate::syntax::SName, crate::syntax::Expr)>> {
        let lx_p0 = &self.lx_p0;
        let p_p1 = &self.p_p1;
        let e_p2 = &self.e_p2;
        match ((*p_p1.kind_p).clone(), (*e_p2.kind_p).clone()) {
            (crate::syntax::PatternKind::PName(n_p3), crate::syntax::ExprKind::ETuple(_)) => if crate::lower::types::is_bundle_f(&crate::lower::type_at_f(lx_p0, &e_p2.span_p)) {
                ::prism_rtl::Turn::Finished(::std::option::Option::Some((n_p3.clone(), e_p2.clone())))
            } else {
                ::prism_rtl::Turn::Finished(::std::option::Option::None)
            },
            (_, crate::syntax::ExprKind::EGroup(x_p4)) => ::prism_rtl::Turn::More(::std::rc::Rc::new(BundleWritten { lx_p0: lx_p0.clone(), p_p1: p_p1.clone(), e_p2: (*x_p4).clone() })),
            _ => ::prism_rtl::Turn::Finished(::std::option::Option::None),
        }
    }
}

/// `Start BundleWritten, x`: what the function value is when passed to `@Run`.
pub fn start_bundle_written_o(lx_p0: crate::lower::Lx, p_p1: crate::syntax::Pattern, e_p2: crate::syntax::Expr) -> ::std::rc::Rc<dyn ::prism_rtl::Job<::std::option::Option<(crate::syntax::SName, crate::syntax::Expr)>>> {
    ::std::rc::Rc::new(BundleWritten { lx_p0, p_p1, e_p2 })
}

/// ```prism
/// BundleValue: unbounded fn Wx, Env, Env, SName, Expr, Wres -> ((Wx, Env, Env))
/// ```
pub fn bundle_value_f(wx_p0: &crate::lower::node_::Wx, benv_p1: &crate::lower::types::Env, menv_p2: &crate::lower::types::Env, n_p3: &crate::syntax::SName, tuple_p4: &crate::syntax::Expr, res_p5: &crate::lower::node_::Wres) -> (crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env) {
    let lx_p6 = wx_p0.lx_p.clone();
    let nkey_p7 = crate::check::env::sname_key_f(n_p3);
    let parts_p8 = match res_p5 {
        crate::lower::node_::Wres::WrParts(ps_pb) => ps_pb.clone(),
        _ => crate::prelude::Array::new(),
    };
    let es_p9 = match &*tuple_p4.kind_p {
        crate::syntax::ExprKind::ETuple(xs_pc) => xs_pc.clone(),
        _ => crate::prelude::Array::new(),
    };
    let simple_pa = ((&crate::prelude::len(&parts_p8) > &crate::prelude::Nat::from(0u32)) && (&crate::prelude::len(&parts_p8) == &crate::prelude::len(&es_p9))) && crate::prelude::fold(&parts_p8, &true, &(|ok_pd: &bool, part_pe: &crate::lower::node_::Wres| *ok_pd && match part_pe {
        crate::lower::node_::Wres::WrEv(_) => true,
        crate::lower::node_::Wres::WrPlain(_, _) => true,
        crate::lower::node_::Wres::WrDyn(_, _, _) => true,
        _ => false,
    }));
    if !simple_pa {
        (wx_p0.clone(), benv_p1.clone(), menv_p2.clone())
    } else {
        {
            let (values_p12, wx1_p13) = crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(&parts_p8)), (crate::prelude::Array::new(), wx_p0.clone()), {
                let parts_p8x = parts_p8.clone();
                let es_p9x = es_p9.clone();
                let lx_p6x = lx_p6.clone();
                let nkey_p7x = nkey_p7.clone();
                ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Array<crate::lower::model::Ex>, crate::lower::node_::Wx), crate::prelude::Nat)| {
                    let parts_p8xy = parts_p8x.clone();
                    let es_p9xy = es_p9x.clone();
                    let lx_p6xy = lx_p6x.clone();
                    let nkey_p7xy = nkey_p7x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let (acc_ph, w_pi) = p0;
                        let i_pj = p1;
                        match (crate::prelude::index(&parts_p8xy, &i_pj), crate::prelude::index(&es_p9xy, &i_pj)) {
                            (::std::option::Option::Some(crate::lower::node_::Wres::WrEv(r_pk)), ::std::option::Option::Some(y_pl)) => crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p6xy.clone(), crate::lower::types::peel_f(&crate::lower::types::peel_f(&crate::lower::type_at_f(&lx_p6xy, &y_pl.span_p)))), move |out_ty_of_f_122113: crate::lower::model::OutTy| {
                                let et_pm = out_ty_of_f_122113;
                                let (rs_pq, w1_pr) = crate::lower::node_::fresh_name_f(&w_pi, &crate::prelude::Text::from(format!("{}_part{}", &crate::lower::snake_f(&nkey_p7xy), &i_pj)));
                                let pf_pn = crate::prelude::Text::from(format!("{}_v_port", &rs_pq));
                                let pt_po = crate::lower::model::OutTy::OutRc(::std::rc::Rc::new(crate::lower::model::OutTy::OutPort(::std::rc::Rc::new(et_pm.clone()))));
                                let w2_pp = {
                                    let mut this: crate::lower::node_::Wx = crate::lower::node_::connect_f(&w1_pr, &r_pk, &crate::lower::node_::Sk::SkPort(crate::prelude::Text::from(format!("{}_v", &rs_pq))));
                                    this.lets_p = crate::prelude::push(&this.lets_p, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaBind(pf_pn.clone())), pt_po.clone()), crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Rc::new")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Port::new")), crate::prelude::Array::new())]))));
                                    this.fields_p = crate::prelude::push(&this.fields_p, &(pf_pn.clone(), pt_po.clone(), crate::prelude::Text::from(format!("part {} of `{}` as a value: the port it fires", &i_pj, &nkey_p7xy))));
                                    this.moves_p = crate::prelude::push(&this.moves_p, &(pf_pn.clone(), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(pf_pn.clone())))));
                                    this
                                };
                                ::prism_rtl::Turn::Finished((crate::prelude::push(&acc_ph, &crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("prism_rtl::Event::of")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XVar(pf_pn.clone())))]))), w2_pp.clone()))
                            }),
                            (::std::option::Option::Some(crate::lower::node_::Wres::WrPlain(ex_ps, _)), _) => ::prism_rtl::Turn::Finished((crate::prelude::push(&acc_ph, &ex_ps), w_pi.clone())),
                            (::std::option::Option::Some(crate::lower::node_::Wres::WrDyn(ex_pt, reads_pu, dt_pv)), _) => {
                                let (dyn_p10, w1_p11) = live_dynamic_f(&w_pi, &crate::prelude::Text::from(format!("{}_part{}", &crate::lower::snake_f(&nkey_p7xy), &i_pj)), &ex_pt, &reads_pu, &dt_pv, &crate::prelude::Text::from(format!("part {} of `{}`", &i_pj, &nkey_p7xy)));
                                ::prism_rtl::Turn::Finished((crate::prelude::push(&acc_ph, &dyn_p10), w1_p11.clone()))
                            },
                            _ => ::prism_rtl::Turn::Finished((acc_ph.clone(), w_pi.clone())),
                        }
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Array<crate::lower::model::Ex>, crate::lower::node_::Wx), crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<crate::lower::model::Ex>, crate::lower::node_::Wx)>>>
            }));
            let t_pf = crate::lower::types::out_ty_of_f(&lx_p6, &crate::lower::type_at_f(&lx_p6, &tuple_p4.span_p));
            let (vf_p14, wx2_p15) = crate::lower::node_::fresh_name_f(&wx1_p13, &crate::prelude::Text::from(format!("{}_bundle", &crate::lower::snake_f(&nkey_p7))));
            let wx3_pg = {
                let mut this: crate::lower::node_::Wx = wx2_p15.clone();
                this.lets_p = crate::prelude::push(&this.lets_p, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaBind(vf_p14.clone())), t_pf.clone()), crate::lower::model::Ex::XTuple(values_p12.clone())));
                this.fields_p = crate::prelude::push(&this.fields_p, &(vf_p14.clone(), t_pf.clone(), crate::prelude::Text::from(format!("`{}`, a bundle, as one value", &nkey_p7))));
                this.inits_p = crate::prelude::push(&this.inits_p, &(vf_p14.clone(), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(vf_p14.clone())))));
                this
            };
            (wx3_pg.clone(), crate::lower::types::bind_f(benv_p1, &crate::prelude::Text::from(format!("{}#value", &nkey_p7)), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(vf_p14.clone()), crate::lower::types::Holding::Owned, t_pf.clone())), crate::lower::types::bind_f(menv_p2, &crate::prelude::Text::from(format!("{}#value", &nkey_p7)), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), vf_p14.clone()), crate::lower::types::Holding::Owned, t_pf.clone())))
        }
    }
}

/// The step machine of `BundleValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BundleValue: unbounded fn Wx, Env, Env, SName, Expr, Wres -> ((Wx, Env, Env))
/// ```
pub struct BundleValue {
    pub wx_p0: crate::lower::node_::Wx,
    pub benv_p1: crate::lower::types::Env,
    pub menv_p2: crate::lower::types::Env,
    pub n_p3: crate::syntax::SName,
    pub tuple_p4: crate::syntax::Expr,
    pub res_p5: crate::lower::node_::Wres,
}

impl ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)> for BundleValue {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)> {
        let wx_p0 = &self.wx_p0;
        let benv_p1 = &self.benv_p1;
        let menv_p2 = &self.menv_p2;
        let n_p3 = &self.n_p3;
        let tuple_p4 = &self.tuple_p4;
        let res_p5 = &self.res_p5;
        let lx_p6 = wx_p0.lx_p.clone();
        let nkey_p7 = crate::check::env::sname_key_f(n_p3);
        let parts_p8 = match res_p5 {
            crate::lower::node_::Wres::WrParts(ps_pb) => ps_pb.clone(),
            _ => crate::prelude::Array::new(),
        };
        let es_p9 = match &*tuple_p4.kind_p {
            crate::syntax::ExprKind::ETuple(xs_pc) => xs_pc.clone(),
            _ => crate::prelude::Array::new(),
        };
        let simple_pa = ((&crate::prelude::len(&parts_p8) > &crate::prelude::Nat::from(0u32)) && (&crate::prelude::len(&parts_p8) == &crate::prelude::len(&es_p9))) && crate::prelude::fold(&parts_p8, &true, &(|ok_pd: &bool, part_pe: &crate::lower::node_::Wres| *ok_pd && match part_pe {
            crate::lower::node_::Wres::WrEv(_) => true,
            crate::lower::node_::Wres::WrPlain(_, _) => true,
            crate::lower::node_::Wres::WrDyn(_, _, _) => true,
            _ => false,
        }));
        if !simple_pa {
            ::prism_rtl::Turn::Finished((wx_p0.clone(), benv_p1.clone(), menv_p2.clone()))
        } else {
            {
                let benv_p1x = benv_p1.clone();
                let menv_p2x = menv_p2.clone();
                let tuple_p4x = tuple_p4.clone();
                let wx_p0x = wx_p0.clone();
                crate::prelude::call_value(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(&parts_p8)), (crate::prelude::Array::new(), wx_p0x.clone()), {
                    let parts_p8x = parts_p8.clone();
                    let es_p9x = es_p9.clone();
                    let lx_p6x = lx_p6.clone();
                    let nkey_p7x = nkey_p7.clone();
                    ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Array<crate::lower::model::Ex>, crate::lower::node_::Wx), crate::prelude::Nat)| {
                        let parts_p8xy = parts_p8x.clone();
                        let es_p9xy = es_p9x.clone();
                        let lx_p6xy = lx_p6x.clone();
                        let nkey_p7xy = nkey_p7x.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let (acc_ph, w_pi) = p0;
                            let i_pj = p1;
                            match (crate::prelude::index(&parts_p8xy, &i_pj), crate::prelude::index(&es_p9xy, &i_pj)) {
                                (::std::option::Option::Some(crate::lower::node_::Wres::WrEv(r_pk)), ::std::option::Option::Some(y_pl)) => crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p6xy.clone(), crate::lower::types::peel_f(&crate::lower::types::peel_f(&crate::lower::type_at_f(&lx_p6xy, &y_pl.span_p)))), move |out_ty_of_f_122113: crate::lower::model::OutTy| {
                                    let et_pm = out_ty_of_f_122113;
                                    let (rs_pq, w1_pr) = crate::lower::node_::fresh_name_f(&w_pi, &crate::prelude::Text::from(format!("{}_part{}", &crate::lower::snake_f(&nkey_p7xy), &i_pj)));
                                    let pf_pn = crate::prelude::Text::from(format!("{}_v_port", &rs_pq));
                                    let pt_po = crate::lower::model::OutTy::OutRc(::std::rc::Rc::new(crate::lower::model::OutTy::OutPort(::std::rc::Rc::new(et_pm.clone()))));
                                    let w2_pp = {
                                        let mut this: crate::lower::node_::Wx = crate::lower::node_::connect_f(&w1_pr, &r_pk, &crate::lower::node_::Sk::SkPort(crate::prelude::Text::from(format!("{}_v", &rs_pq))));
                                        this.lets_p = crate::prelude::push(&this.lets_p, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaBind(pf_pn.clone())), pt_po.clone()), crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Rc::new")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Port::new")), crate::prelude::Array::new())]))));
                                        this.fields_p = crate::prelude::push(&this.fields_p, &(pf_pn.clone(), pt_po.clone(), crate::prelude::Text::from(format!("part {} of `{}` as a value: the port it fires", &i_pj, &nkey_p7xy))));
                                        this.moves_p = crate::prelude::push(&this.moves_p, &(pf_pn.clone(), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(pf_pn.clone())))));
                                        this
                                    };
                                    ::prism_rtl::Turn::Finished((crate::prelude::push(&acc_ph, &crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("prism_rtl::Event::of")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XVar(pf_pn.clone())))]))), w2_pp.clone()))
                                }),
                                (::std::option::Option::Some(crate::lower::node_::Wres::WrPlain(ex_ps, _)), _) => ::prism_rtl::Turn::Finished((crate::prelude::push(&acc_ph, &ex_ps), w_pi.clone())),
                                (::std::option::Option::Some(crate::lower::node_::Wres::WrDyn(ex_pt, reads_pu, dt_pv)), _) => {
                                    let (dyn_p10, w1_p11) = live_dynamic_f(&w_pi, &crate::prelude::Text::from(format!("{}_part{}", &crate::lower::snake_f(&nkey_p7xy), &i_pj)), &ex_pt, &reads_pu, &dt_pv, &crate::prelude::Text::from(format!("part {} of `{}`", &i_pj, &nkey_p7xy)));
                                    ::prism_rtl::Turn::Finished((crate::prelude::push(&acc_ph, &dyn_p10), w1_p11.clone()))
                                },
                                _ => ::prism_rtl::Turn::Finished((acc_ph.clone(), w_pi.clone())),
                            }
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Array<crate::lower::model::Ex>, crate::lower::node_::Wx), crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<crate::lower::model::Ex>, crate::lower::node_::Wx)>>>
                }), move |fold_121970: (crate::prelude::Array<crate::lower::model::Ex>, crate::lower::node_::Wx)| {
                    let (values_p12, wx1_p13) = fold_121970;
                    crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p6.clone(), crate::lower::type_at_f(&lx_p6, &tuple_p4x.span_p)), move |out_ty_of_f_123234: crate::lower::model::OutTy| {
                        let t_pf = out_ty_of_f_123234;
                        let (vf_p14, wx2_p15) = crate::lower::node_::fresh_name_f(&wx1_p13, &crate::prelude::Text::from(format!("{}_bundle", &crate::lower::snake_f(&nkey_p7))));
                        let wx3_pg = {
                            let mut this: crate::lower::node_::Wx = wx2_p15.clone();
                            this.lets_p = crate::prelude::push(&this.lets_p, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaBind(vf_p14.clone())), t_pf.clone()), crate::lower::model::Ex::XTuple(values_p12.clone())));
                            this.fields_p = crate::prelude::push(&this.fields_p, &(vf_p14.clone(), t_pf.clone(), crate::prelude::Text::from(format!("`{}`, a bundle, as one value", &nkey_p7))));
                            this.inits_p = crate::prelude::push(&this.inits_p, &(vf_p14.clone(), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(vf_p14.clone())))));
                            this
                        };
                        ::prism_rtl::Turn::Finished((wx3_pg.clone(), crate::lower::types::bind_f(&benv_p1x, &crate::prelude::Text::from(format!("{}#value", &nkey_p7)), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(vf_p14.clone()), crate::lower::types::Holding::Owned, t_pf.clone())), crate::lower::types::bind_f(&menv_p2x, &crate::prelude::Text::from(format!("{}#value", &nkey_p7)), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), vf_p14.clone()), crate::lower::types::Holding::Owned, t_pf.clone()))))
                    })
                })
            }
        }
    }
}

/// `Start BundleValue, x`: what the function value is when passed to `@Run`.
pub fn start_bundle_value_f(wx_p0: crate::lower::node_::Wx, benv_p1: crate::lower::types::Env, menv_p2: crate::lower::types::Env, n_p3: crate::syntax::SName, tuple_p4: crate::syntax::Expr, res_p5: crate::lower::node_::Wres) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>> {
    ::std::rc::Rc::new(BundleValue { wx_p0, benv_p1, menv_p2, n_p3, tuple_p4, res_p5 })
}

/// ```prism
/// ?BundleNamed: unbounded fn Env, Pattern, Expr -> ?((SName, Bn))
/// ```
pub fn bundle_named_o(menv_p0: &crate::lower::types::Env, p_p1: &crate::syntax::Pattern, e_p2: &crate::syntax::Expr) -> ::std::option::Option<(crate::syntax::SName, crate::lower::types::Bn)> {
    match ((*p_p1.kind_p).clone(), (*e_p2.kind_p).clone()) {
        (crate::syntax::PatternKind::PName(n_p3), crate::syntax::ExprKind::EName(m_p4)) => match if &crate::prelude::len(&m_p4.path_p) == &crate::prelude::Nat::from(1u32) {
            crate::prelude::get(&menv_p0.names_p, &crate::check::env::sname_key_f(&m_p4))
        } else {
            ::std::option::Option::None
        } {
            ::std::option::Option::Some(crate::lower::types::Bn::BnParts(bs_p5)) => ::std::option::Option::Some((n_p3, crate::lower::types::Bn::BnParts(bs_p5))),
            _ => ::std::option::Option::None,
        },
        (_, crate::syntax::ExprKind::EGroup(x_p6)) => bundle_named_o(menv_p0, p_p1, &*x_p6),
        _ => ::std::option::Option::None,
    }
}

/// The step machine of `BundleNamed`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?BundleNamed: unbounded fn Env, Pattern, Expr -> ?((SName, Bn))
/// ```
pub struct BundleNamed {
    pub menv_p0: crate::lower::types::Env,
    pub p_p1: crate::syntax::Pattern,
    pub e_p2: crate::syntax::Expr,
}

impl ::prism_rtl::Job<::std::option::Option<(crate::syntax::SName, crate::lower::types::Bn)>> for BundleNamed {
    fn cycle(&self) -> ::prism_rtl::Turn<::std::option::Option<(crate::syntax::SName, crate::lower::types::Bn)>> {
        let menv_p0 = &self.menv_p0;
        let p_p1 = &self.p_p1;
        let e_p2 = &self.e_p2;
        match ((*p_p1.kind_p).clone(), (*e_p2.kind_p).clone()) {
            (crate::syntax::PatternKind::PName(n_p3), crate::syntax::ExprKind::EName(m_p4)) => match if &crate::prelude::len(&m_p4.path_p) == &crate::prelude::Nat::from(1u32) {
                crate::prelude::get(&menv_p0.names_p, &crate::check::env::sname_key_f(&m_p4))
            } else {
                ::std::option::Option::None
            } {
                ::std::option::Option::Some(crate::lower::types::Bn::BnParts(bs_p5)) => ::prism_rtl::Turn::Finished(::std::option::Option::Some((n_p3.clone(), crate::lower::types::Bn::BnParts(bs_p5.clone())))),
                _ => ::prism_rtl::Turn::Finished(::std::option::Option::None),
            },
            (_, crate::syntax::ExprKind::EGroup(x_p6)) => ::prism_rtl::Turn::More(::std::rc::Rc::new(BundleNamed { menv_p0: menv_p0.clone(), p_p1: p_p1.clone(), e_p2: (*x_p6).clone() })),
            _ => ::prism_rtl::Turn::Finished(::std::option::Option::None),
        }
    }
}

/// `Start BundleNamed, x`: what the function value is when passed to `@Run`.
pub fn start_bundle_named_o(menv_p0: crate::lower::types::Env, p_p1: crate::syntax::Pattern, e_p2: crate::syntax::Expr) -> ::std::rc::Rc<dyn ::prism_rtl::Job<::std::option::Option<(crate::syntax::SName, crate::lower::types::Bn)>>> {
    ::std::rc::Rc::new(BundleNamed { menv_p0, p_p1, e_p2 })
}

/// ```prism
/// ValueRenamed: unbounded fn Env, SName, Expr -> Env
/// ```
pub fn value_renamed_f(env_p0: &crate::lower::types::Env, n_p1: &crate::syntax::SName, e_p2: &crate::syntax::Expr) -> crate::lower::types::Env {
    match &*e_p2.kind_p {
        crate::syntax::ExprKind::EGroup(x_p3) => value_renamed_f(env_p0, n_p1, &**x_p3),
        crate::syntax::ExprKind::EName(m_p4) => match crate::prelude::get(&env_p0.names_p, &crate::prelude::Text::from(format!("{}#value", &crate::check::env::sname_key_f(m_p4)))) {
            ::std::option::Option::Some(held_p5) => crate::lower::types::bind_f(env_p0, &crate::prelude::Text::from(format!("{}#value", &crate::check::env::sname_key_f(n_p1))), &held_p5),
            ::std::option::Option::None => env_p0.clone(),
        },
        _ => env_p0.clone(),
    }
}

/// The step machine of `ValueRenamed`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ValueRenamed: unbounded fn Env, SName, Expr -> Env
/// ```
pub struct ValueRenamed {
    pub env_p0: crate::lower::types::Env,
    pub n_p1: crate::syntax::SName,
    pub e_p2: crate::syntax::Expr,
}

impl ::prism_rtl::Job<crate::lower::types::Env> for ValueRenamed {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::lower::types::Env> {
        let env_p0 = &self.env_p0;
        let n_p1 = &self.n_p1;
        let e_p2 = &self.e_p2;
        match &*e_p2.kind_p {
            crate::syntax::ExprKind::EGroup(x_p3) => ::prism_rtl::Turn::More(::std::rc::Rc::new(ValueRenamed { env_p0: env_p0.clone(), n_p1: n_p1.clone(), e_p2: (**x_p3).clone() })),
            crate::syntax::ExprKind::EName(m_p4) => match crate::prelude::get(&env_p0.names_p, &crate::prelude::Text::from(format!("{}#value", &crate::check::env::sname_key_f(m_p4)))) {
                ::std::option::Option::Some(held_p5) => ::prism_rtl::Turn::Finished(crate::lower::types::bind_f(env_p0, &crate::prelude::Text::from(format!("{}#value", &crate::check::env::sname_key_f(n_p1))), &held_p5)),
                ::std::option::Option::None => ::prism_rtl::Turn::Finished(env_p0.clone()),
            },
            _ => ::prism_rtl::Turn::Finished(env_p0.clone()),
        }
    }
}

/// `Start ValueRenamed, x`: what the function value is when passed to `@Run`.
pub fn start_value_renamed_f(env_p0: crate::lower::types::Env, n_p1: crate::syntax::SName, e_p2: crate::syntax::Expr) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::types::Env>> {
    ::std::rc::Rc::new(ValueRenamed { env_p0, n_p1, e_p2 })
}

/// ```prism
/// BindHosted: unbounded fn Wx, Env, Env, Wres, Bn, [Pattern] -> ((Wx, Env, Env))
/// ```
pub fn bind_hosted_f(wx_p0: &crate::lower::node_::Wx, benv_p1: &crate::lower::types::Env, menv_p2: &crate::lower::types::Env, res_p3: &crate::lower::node_::Wres, doc_p4: &crate::lower::types::Bn, ps_p5: &crate::prelude::Array<crate::syntax::Pattern>) -> (crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env) {
    let r_o6 = match res_p3 {
        crate::lower::node_::Wres::WrEv(r_p9) => ::std::option::Option::Some(crate::lower::types::Bn::BnEv(r_p9.clone(), crate::lower::model::OutTy::OutUnit)),
        crate::lower::node_::Wres::WrDyn(ex_pa, rds_pb, t_pc) => ::std::option::Option::Some(crate::lower::types::Bn::BnDyn(ex_pa.clone(), rds_pb.clone(), t_pc.clone())),
        crate::lower::node_::Wres::WrParts(_) => ::std::option::Option::Some(bundle_bn_f(res_p3)),
        _ => ::std::option::Option::None,
    };
    let wx0_p7 = match (res_p3.clone(), crate::prelude::index(ps_p5, &crate::prelude::Nat::from(0u32))) {
        (crate::lower::node_::Wres::WrPlain(ex_pd, t_pe), ::std::option::Option::Some(p_pf)) => bind_plain_result_f(wx_p0, menv_p2, &p_pf, &ex_pd, &t_pe),
        (crate::lower::node_::Wres::WrLate(_, _), ::std::option::Option::Some(_)) => {
            let mut this: crate::lower::node_::Wx = wx_p0.clone();
            this.build_p = crate::prelude::push(&this.build_p, &crate::lower::expr::internal_bug_do_f(&crate::prelude::Text::lit("a hosted child\'s late plain result bound where its block is not split")));
            this
        },
        _ => wx_p0.clone(),
    };
    let wx1_p8 = part_getter_f(&part_getter_f(&wx0_p7, menv_p2, &crate::prelude::index(ps_p5, &crate::prelude::Nat::from(0u32)), &r_o6), menv_p2, &crate::prelude::index(ps_p5, &crate::prelude::Nat::from(1u32)), &::std::option::Option::Some(doc_p4.clone()));
    let (be1_pg, me1_ph) = bind_part_f(benv_p1, menv_p2, &crate::prelude::index(ps_p5, &crate::prelude::Nat::from(0u32)), &r_o6);
    bind_part2_f(&wx1_p8, &be1_pg, &me1_ph, &crate::prelude::index(ps_p5, &crate::prelude::Nat::from(1u32)), &::std::option::Option::Some(doc_p4.clone()))
}

/// The step machine of `BindHosted`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BindHosted: unbounded fn Wx, Env, Env, Wres, Bn, [Pattern] -> ((Wx, Env, Env))
/// ```
pub struct BindHosted {
    pub wx_p0: crate::lower::node_::Wx,
    pub benv_p1: crate::lower::types::Env,
    pub menv_p2: crate::lower::types::Env,
    pub res_p3: crate::lower::node_::Wres,
    pub doc_p4: crate::lower::types::Bn,
    pub ps_p5: crate::prelude::Array<crate::syntax::Pattern>,
}

impl ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)> for BindHosted {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)> {
        let wx_p0 = &self.wx_p0;
        let benv_p1 = &self.benv_p1;
        let menv_p2 = &self.menv_p2;
        let res_p3 = &self.res_p3;
        let doc_p4 = &self.doc_p4;
        let ps_p5 = &self.ps_p5;
        let r_o6 = match res_p3 {
            crate::lower::node_::Wres::WrEv(r_p9) => ::std::option::Option::Some(crate::lower::types::Bn::BnEv(r_p9.clone(), crate::lower::model::OutTy::OutUnit)),
            crate::lower::node_::Wres::WrDyn(ex_pa, rds_pb, t_pc) => ::std::option::Option::Some(crate::lower::types::Bn::BnDyn(ex_pa.clone(), rds_pb.clone(), t_pc.clone())),
            crate::lower::node_::Wres::WrParts(_) => ::std::option::Option::Some(bundle_bn_f(res_p3)),
            _ => ::std::option::Option::None,
        };
        let r_o6z = r_o6.clone();
        let benv_p1z = benv_p1.clone();
        let doc_p4z = doc_p4.clone();
        let menv_p2z = menv_p2.clone();
        let ps_p5z = ps_p5.clone();
        let k_let125458 = move |v125458: crate::lower::node_::Wx| {
            let wx0_p7 = v125458;
            let wx1_p8 = part_getter_f(&part_getter_f(&wx0_p7, &menv_p2z, &crate::prelude::index(&ps_p5z, &crate::prelude::Nat::from(0u32)), &r_o6z), &menv_p2z, &crate::prelude::index(&ps_p5z, &crate::prelude::Nat::from(1u32)), &::std::option::Option::Some(doc_p4z.clone()));
            let (be1_pg, me1_ph) = bind_part_f(&benv_p1z, &menv_p2z, &crate::prelude::index(&ps_p5z, &crate::prelude::Nat::from(0u32)), &r_o6z);
            ::prism_rtl::Turn::Finished(bind_part2_f(&wx1_p8, &be1_pg, &me1_ph, &crate::prelude::index(&ps_p5z, &crate::prelude::Nat::from(1u32)), &::std::option::Option::Some(doc_p4z.clone())))
        };
        match (res_p3.clone(), crate::prelude::index(ps_p5, &crate::prelude::Nat::from(0u32))) {
            (crate::lower::node_::Wres::WrPlain(ex_pd, t_pe), ::std::option::Option::Some(p_pf)) => {
                let menv_p2x = menv_p2.clone();
                let wx_p0x = wx_p0.clone();
                crate::prelude::call_then(start_bind_plain_result_f(wx_p0x.clone(), menv_p2x.clone(), p_pf.clone(), ex_pd.clone(), t_pe.clone()), move |bind_plain_result_f_125524: crate::lower::node_::Wx| k_let125458(bind_plain_result_f_125524))
            },
            (crate::lower::node_::Wres::WrLate(_, _), ::std::option::Option::Some(_)) => k_let125458({
                let mut this: crate::lower::node_::Wx = wx_p0.clone();
                this.build_p = crate::prelude::push(&this.build_p, &crate::lower::expr::internal_bug_do_f(&crate::prelude::Text::lit("a hosted child\'s late plain result bound where its block is not split")));
                this
            }),
            _ => k_let125458(wx_p0.clone()),
        }
    }
}

/// `Start BindHosted, x`: what the function value is when passed to `@Run`.
pub fn start_bind_hosted_f(wx_p0: crate::lower::node_::Wx, benv_p1: crate::lower::types::Env, menv_p2: crate::lower::types::Env, res_p3: crate::lower::node_::Wres, doc_p4: crate::lower::types::Bn, ps_p5: crate::prelude::Array<crate::syntax::Pattern>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>> {
    ::std::rc::Rc::new(BindHosted { wx_p0, benv_p1, menv_p2, res_p3, doc_p4, ps_p5 })
}

/// ```prism
/// PartGetter: fn Wx, Env, ?Pattern, ?Bn -> Wx
/// ```
pub fn part_getter_f(wx_p0: &crate::lower::node_::Wx, menv_p1: &crate::lower::types::Env, p_o2: &::std::option::Option<crate::syntax::Pattern>, b_o3: &::std::option::Option<crate::lower::types::Bn>) -> crate::lower::node_::Wx {
    match (p_o2.clone(), b_o3.clone()) {
        (::std::option::Option::Some(p_p4), ::std::option::Option::Some(crate::lower::types::Bn::BnDyn(ex_p5, rds_p6, t_p7))) => match &*p_p4.kind_p {
            crate::syntax::PatternKind::PName(n_p8) => {
                let (w2_p9, _, _) = result_getter_f(wx_p0, menv_p1, n_p8, &ex_p5, &rds_p6, &t_p7, &crate::lower::types::empty_env_p(), &crate::lower::types::empty_env_p());
                w2_p9.clone()
            },
            _ => wx_p0.clone(),
        },
        _ => wx_p0.clone(),
    }
}

/// ```prism
/// BindPart: fn Env, Env, ?Pattern, ?Bn -> ((Env, Env))
/// ```
pub fn bind_part_f(benv_p0: &crate::lower::types::Env, menv_p1: &crate::lower::types::Env, p_o2: &::std::option::Option<crate::syntax::Pattern>, b_o3: &::std::option::Option<crate::lower::types::Bn>) -> (crate::lower::types::Env, crate::lower::types::Env) {
    match (p_o2.clone(), b_o3.clone()) {
        (::std::option::Option::Some(p_p4), ::std::option::Option::Some(b_p5)) => match &*p_p4.kind_p {
            crate::syntax::PatternKind::PName(n_p6) => (crate::lower::types::bind_f(benv_p0, &crate::check::env::sname_key_f(n_p6), &b_p5), crate::lower::types::bind_f(menv_p1, &crate::check::env::sname_key_f(n_p6), &b_p5)),
            _ => (benv_p0.clone(), menv_p1.clone()),
        },
        _ => (benv_p0.clone(), menv_p1.clone()),
    }
}

/// ```prism
/// BindPart2: fn Wx, Env, Env, ?Pattern, ?Bn -> ((Wx, Env, Env))
/// ```
pub fn bind_part2_f(wx_p0: &crate::lower::node_::Wx, benv_p1: &crate::lower::types::Env, menv_p2: &crate::lower::types::Env, p_o3: &::std::option::Option<crate::syntax::Pattern>, b_o4: &::std::option::Option<crate::lower::types::Bn>) -> (crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env) {
    let (be_p5, me_p6) = bind_part_f(benv_p1, menv_p2, p_o3, b_o4);
    (wx_p0.clone(), be_p5.clone(), me_p6.clone())
}

/// ```prism
/// BindParts: unbounded fn Wx, Env, Env, [Wres], [Pattern], [Ty] -> ((Wx, Env, Env))
/// ```
pub fn bind_parts_f(wx_p0: &crate::lower::node_::Wx, benv_p1: &crate::lower::types::Env, menv_p2: &crate::lower::types::Env, parts_p3: &crate::prelude::Array<crate::lower::node_::Wres>, ps_p4: &crate::prelude::Array<crate::syntax::Pattern>, tys_p5: &crate::prelude::Array<crate::check::types::Ty>) -> (crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env) {
    crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(ps_p4)), (wx_p0.clone(), benv_p1.clone(), menv_p2.clone()), {
        let ps_p4x = ps_p4.clone();
        let parts_p3x = parts_p3.clone();
        let tys_p5x = tys_p5.clone();
        ::std::rc::Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::prelude::Nat)| {
            let ps_p4xy = ps_p4x.clone();
            let parts_p3xy = parts_p3x.clone();
            let tys_p5xy = tys_p5x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (w_p6, be_p7, me_p8) = p0;
                let i_p9 = p1;
                match (crate::prelude::index(&ps_p4xy, &i_p9), crate::prelude::index(&parts_p3xy, &i_p9)) {
                    (::std::option::Option::Some(p_pa), ::std::option::Option::Some(part_pb)) => match (part_pb.clone(), (*p_pa.kind_p).clone()) {
                        (crate::lower::node_::Wres::WrEv(r_pc), crate::syntax::PatternKind::PName(_)) => ::prism_rtl::Turn::Finished((bind_res_f(&w_p6, &me_p8, &p_pa, &part_pb), be_p7.clone(), me_p8.clone())),
                        (crate::lower::node_::Wres::WrParts(inner_pd), crate::syntax::PatternKind::PTuple(qs_pe)) => ::prism_rtl::Turn::More(::std::rc::Rc::new(BindParts { wx_p0: w_p6.clone(), benv_p1: be_p7.clone(), menv_p2: me_p8.clone(), parts_p3: inner_pd.clone(), ps_p4: qs_pe.clone(), tys_p5: crate::lower::node_::keyed::bundle_part_tys_f(&crate::prelude::or(&crate::prelude::index(&tys_p5xy, &i_p9), &crate::check::types::Ty::TyErr)) })),
                        (_, crate::syntax::PatternKind::PIgnore) => ::prism_rtl::Turn::Finished((w_p6.clone(), be_p7.clone(), me_p8.clone())),
                        (_, crate::syntax::PatternKind::PName(n_pf)) => match &part_pb {
                            crate::lower::node_::Wres::WrUnit => ::prism_rtl::Turn::Finished((w_p6.clone(), be_p7.clone(), me_p8.clone())),
                            crate::lower::node_::Wres::WrDyn(ex_pg, rds_ph, t_pi) => {
                                let b_pj = crate::lower::types::Bn::BnDyn(ex_pg.clone(), rds_ph.clone(), t_pi.clone());
                                ::prism_rtl::Turn::Finished(result_getter_f(&w_p6, &me_p8, &n_pf, ex_pg, rds_ph, t_pi, &crate::lower::types::bind_f(&be_p7, &crate::check::env::sname_key_f(&n_pf), &b_pj), &crate::lower::types::bind_f(&me_p8, &crate::check::env::sname_key_f(&n_pf), &b_pj)))
                            },
                            crate::lower::node_::Wres::WrPlain(ex_pk, t_pl) if is_field_part_f(&crate::prelude::get(&me_p8.names_p, &crate::check::env::sname_key_f(&n_pf))) => {
                                let ex_pkx = ex_pk.clone();
                                let t_plx = t_pl.clone();
                                crate::prelude::call_then(start_bind_plain_result_f(w_p6.clone(), me_p8.clone(), p_pa.clone(), ex_pkx.clone(), t_plx.clone()), move |bind_plain_result_f_128382: crate::lower::node_::Wx| ::prism_rtl::Turn::Finished((bind_plain_result_f_128382, be_p7.clone(), me_p8.clone())))
                            },
                            crate::lower::node_::Wres::WrParts(inner_pm) => {
                                let inner_pmx = inner_pm.clone();
                                crate::prelude::call_then(start_fielded_parts_f(w_p6.clone(), crate::lower::snake_f(&crate::check::env::sname_key_f(&n_pf)), inner_pmx.clone()), move |fielded_parts_f_128590: (crate::lower::node_::Wx, crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>, crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>)| {
                                    let (w2_pn, builds_po, methods_pp) = fielded_parts_f_128590;
                                    ::prism_rtl::Turn::Finished((w2_pn.clone(), crate::lower::types::bind_f(&be_p7, &crate::check::env::sname_key_f(&n_pf), &crate::lower::types::Bn::BnParts(builds_po.clone())), crate::lower::types::bind_f(&me_p8, &crate::check::env::sname_key_f(&n_pf), &crate::lower::types::Bn::BnParts(methods_pp.clone()))))
                                })
                            },
                            _ => {
                                let b_pq = bundle_bn_f(&part_pb);
                                ::prism_rtl::Turn::Finished((w_p6.clone(), crate::lower::types::bind_f(&be_p7, &crate::check::env::sname_key_f(&n_pf), &b_pq), crate::lower::types::bind_f(&me_p8, &crate::check::env::sname_key_f(&n_pf), &b_pq)))
                            },
                            _ => unreachable!("no arm matched"),
                        },
                        _ => match &part_pb {
                            crate::lower::node_::Wres::WrPlain(ex_pr, t_ps) => {
                                let ex_prx = ex_pr.clone();
                                let t_psx = t_ps.clone();
                                crate::prelude::call_then(start_bind_pattern_result_f(w_p6.clone(), me_p8.clone(), p_pa.clone(), ex_prx.clone(), t_psx.clone(), crate::prelude::or(&crate::prelude::index(&tys_p5xy, &i_p9), &crate::check::types::Ty::TyErr)), move |bind_pattern_result_f_128944: crate::lower::node_::Wx| ::prism_rtl::Turn::Finished((bind_pattern_result_f_128944, be_p7.clone(), me_p8.clone())))
                            },
                            _ => ::prism_rtl::Turn::Finished((w_p6.clone(), be_p7.clone(), me_p8.clone())),
                        },
                    },
                    _ => ::prism_rtl::Turn::Finished((w_p6.clone(), be_p7.clone(), me_p8.clone())),
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>>>
    }))
}

/// The step machine of `BindParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BindParts: unbounded fn Wx, Env, Env, [Wres], [Pattern], [Ty] -> ((Wx, Env, Env))
/// ```
pub struct BindParts {
    pub wx_p0: crate::lower::node_::Wx,
    pub benv_p1: crate::lower::types::Env,
    pub menv_p2: crate::lower::types::Env,
    pub parts_p3: crate::prelude::Array<crate::lower::node_::Wres>,
    pub ps_p4: crate::prelude::Array<crate::syntax::Pattern>,
    pub tys_p5: crate::prelude::Array<crate::check::types::Ty>,
}

impl ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)> for BindParts {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)> {
        let wx_p0 = &self.wx_p0;
        let benv_p1 = &self.benv_p1;
        let menv_p2 = &self.menv_p2;
        let parts_p3 = &self.parts_p3;
        let ps_p4 = &self.ps_p4;
        let tys_p5 = &self.tys_p5;
        crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(ps_p4)), (wx_p0.clone(), benv_p1.clone(), menv_p2.clone()), {
            let ps_p4x = ps_p4.clone();
            let parts_p3x = parts_p3.clone();
            let tys_p5x = tys_p5.clone();
            ::std::rc::Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::prelude::Nat)| {
                let ps_p4xy = ps_p4x.clone();
                let parts_p3xy = parts_p3x.clone();
                let tys_p5xy = tys_p5x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let (w_p6, be_p7, me_p8) = p0;
                    let i_p9 = p1;
                    match (crate::prelude::index(&ps_p4xy, &i_p9), crate::prelude::index(&parts_p3xy, &i_p9)) {
                        (::std::option::Option::Some(p_pa), ::std::option::Option::Some(part_pb)) => match (part_pb.clone(), (*p_pa.kind_p).clone()) {
                            (crate::lower::node_::Wres::WrEv(r_pc), crate::syntax::PatternKind::PName(_)) => ::prism_rtl::Turn::Finished((bind_res_f(&w_p6, &me_p8, &p_pa, &part_pb), be_p7.clone(), me_p8.clone())),
                            (crate::lower::node_::Wres::WrParts(inner_pd), crate::syntax::PatternKind::PTuple(qs_pe)) => ::prism_rtl::Turn::More(::std::rc::Rc::new(BindParts { wx_p0: w_p6.clone(), benv_p1: be_p7.clone(), menv_p2: me_p8.clone(), parts_p3: inner_pd.clone(), ps_p4: qs_pe.clone(), tys_p5: crate::lower::node_::keyed::bundle_part_tys_f(&crate::prelude::or(&crate::prelude::index(&tys_p5xy, &i_p9), &crate::check::types::Ty::TyErr)) })),
                            (_, crate::syntax::PatternKind::PIgnore) => ::prism_rtl::Turn::Finished((w_p6.clone(), be_p7.clone(), me_p8.clone())),
                            (_, crate::syntax::PatternKind::PName(n_pf)) => match &part_pb {
                                crate::lower::node_::Wres::WrUnit => ::prism_rtl::Turn::Finished((w_p6.clone(), be_p7.clone(), me_p8.clone())),
                                crate::lower::node_::Wres::WrDyn(ex_pg, rds_ph, t_pi) => {
                                    let b_pj = crate::lower::types::Bn::BnDyn(ex_pg.clone(), rds_ph.clone(), t_pi.clone());
                                    ::prism_rtl::Turn::Finished(result_getter_f(&w_p6, &me_p8, &n_pf, ex_pg, rds_ph, t_pi, &crate::lower::types::bind_f(&be_p7, &crate::check::env::sname_key_f(&n_pf), &b_pj), &crate::lower::types::bind_f(&me_p8, &crate::check::env::sname_key_f(&n_pf), &b_pj)))
                                },
                                crate::lower::node_::Wres::WrPlain(ex_pk, t_pl) if is_field_part_f(&crate::prelude::get(&me_p8.names_p, &crate::check::env::sname_key_f(&n_pf))) => {
                                    let ex_pkx = ex_pk.clone();
                                    let t_plx = t_pl.clone();
                                    crate::prelude::call_then(start_bind_plain_result_f(w_p6.clone(), me_p8.clone(), p_pa.clone(), ex_pkx.clone(), t_plx.clone()), move |bind_plain_result_f_128382: crate::lower::node_::Wx| ::prism_rtl::Turn::Finished((bind_plain_result_f_128382, be_p7.clone(), me_p8.clone())))
                                },
                                crate::lower::node_::Wres::WrParts(inner_pm) => {
                                    let inner_pmx = inner_pm.clone();
                                    crate::prelude::call_then(start_fielded_parts_f(w_p6.clone(), crate::lower::snake_f(&crate::check::env::sname_key_f(&n_pf)), inner_pmx.clone()), move |fielded_parts_f_128590: (crate::lower::node_::Wx, crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>, crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>)| {
                                        let (w2_pn, builds_po, methods_pp) = fielded_parts_f_128590;
                                        ::prism_rtl::Turn::Finished((w2_pn.clone(), crate::lower::types::bind_f(&be_p7, &crate::check::env::sname_key_f(&n_pf), &crate::lower::types::Bn::BnParts(builds_po.clone())), crate::lower::types::bind_f(&me_p8, &crate::check::env::sname_key_f(&n_pf), &crate::lower::types::Bn::BnParts(methods_pp.clone()))))
                                    })
                                },
                                _ => {
                                    let b_pq = bundle_bn_f(&part_pb);
                                    ::prism_rtl::Turn::Finished((w_p6.clone(), crate::lower::types::bind_f(&be_p7, &crate::check::env::sname_key_f(&n_pf), &b_pq), crate::lower::types::bind_f(&me_p8, &crate::check::env::sname_key_f(&n_pf), &b_pq)))
                                },
                                _ => unreachable!("no arm matched"),
                            },
                            _ => match &part_pb {
                                crate::lower::node_::Wres::WrPlain(ex_pr, t_ps) => {
                                    let ex_prx = ex_pr.clone();
                                    let t_psx = t_ps.clone();
                                    crate::prelude::call_then(start_bind_pattern_result_f(w_p6.clone(), me_p8.clone(), p_pa.clone(), ex_prx.clone(), t_psx.clone(), crate::prelude::or(&crate::prelude::index(&tys_p5xy, &i_p9), &crate::check::types::Ty::TyErr)), move |bind_pattern_result_f_128944: crate::lower::node_::Wx| ::prism_rtl::Turn::Finished((bind_pattern_result_f_128944, be_p7.clone(), me_p8.clone())))
                                },
                                _ => ::prism_rtl::Turn::Finished((w_p6.clone(), be_p7.clone(), me_p8.clone())),
                            },
                        },
                        _ => ::prism_rtl::Turn::Finished((w_p6.clone(), be_p7.clone(), me_p8.clone())),
                    }
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>>>
        }).cycle()
    }
}

/// `Start BindParts, x`: what the function value is when passed to `@Run`.
pub fn start_bind_parts_f(wx_p0: crate::lower::node_::Wx, benv_p1: crate::lower::types::Env, menv_p2: crate::lower::types::Env, parts_p3: crate::prelude::Array<crate::lower::node_::Wres>, ps_p4: crate::prelude::Array<crate::syntax::Pattern>, tys_p5: crate::prelude::Array<crate::check::types::Ty>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>> {
    ::std::rc::Rc::new(BindParts { wx_p0, benv_p1, menv_p2, parts_p3, ps_p4, tys_p5 })
}

/// ```prism
/// IsFieldPart: fn ?Bn -> Bool
/// ```
pub fn is_field_part_f(opt0: &::std::option::Option<crate::lower::types::Bn>) -> bool {
    'c: {
        if let ::std::option::Option::Some(crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XField(c0_0_0_0, _), _, _)) = opt0 && let crate::lower::model::Ex::XSelf = &**c0_0_0_0 {
            break 'c true;
        }
        if let other_o0 = opt0 {
            break 'c false;
        }
        unreachable!("no clause matched")
    }
}

/// ```prism
/// ResultParts: fn Wres -> [Wres]
/// ```
pub fn result_parts_f(res_p0: &crate::lower::node_::Wres) -> crate::prelude::Array<crate::lower::node_::Wres> {
    match res_p0 {
        crate::lower::node_::Wres::WrParts(parts_p1) => parts_p1.clone(),
        _ => crate::prelude::Array::new(),
    }
}

/// ```prism
/// FieldedParts: unbounded fn Wx, Text, [Wres] -> ((Wx, [?Bn], [?Bn]))
/// ```
pub fn fielded_parts_f(wx_p0: &crate::lower::node_::Wx, stem_p1: &crate::prelude::Text, parts_p2: &crate::prelude::Array<crate::lower::node_::Wres>) -> (crate::lower::node_::Wx, crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>, crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>) {
    crate::prelude::run_to_end(crate::prelude::fold_job(parts_p2.clone(), (wx_p0.clone(), crate::prelude::Array::new(), crate::prelude::Array::new()), {
        let stem_p1x = stem_p1.clone();
        ::std::rc::Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>, crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>), crate::lower::node_::Wres)| {
            let stem_p1xy = stem_p1x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (w_p3, builds_p4, methods_p5) = p0;
                let part_p6 = p1;
                {
                    let i_p7 = crate::prelude::len(&builds_p4);
                    match &part_p6 {
                        crate::lower::node_::Wres::WrPlain(ex_p8, t_p9) => {
                            let (f_pb, w1_pc) = crate::lower::node_::fresh_name_f(&w_p3, &crate::prelude::Text::from(format!("{}_part{}", &stem_p1xy, &i_p7)));
                            let w2_pa = {
                                let mut this: crate::lower::node_::Wx = w1_pc.clone();
                                this.lets_p = crate::prelude::push(&this.lets_p, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaBind(f_pb.clone())), t_p9.clone()), ex_p8.clone()));
                                this.fields_p = crate::prelude::push(&this.fields_p, &(f_pb.clone(), t_p9.clone(), crate::prelude::Text::from(format!("plain part {} of the bundle `{}`", &i_p7, &stem_p1xy))));
                                this.inits_p = crate::prelude::push(&this.inits_p, &(f_pb.clone(), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(f_pb.clone())))));
                                this
                            };
                            ::prism_rtl::Turn::Finished((w2_pa.clone(), crate::prelude::append(&builds_p4, &crate::prelude::Array::from(vec![::std::option::Option::Some(crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(f_pb.clone()), crate::lower::types::Holding::Owned, t_p9.clone()))])), crate::prelude::append(&methods_p5, &crate::prelude::Array::from(vec![::std::option::Option::Some(crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), f_pb.clone()), crate::lower::types::Holding::Owned, t_p9.clone()))]))))
                        },
                        crate::lower::node_::Wres::WrParts(inner_pd) => {
                            let inner_pdx = inner_pd.clone();
                            crate::prelude::call_then(start_fielded_parts_f(w_p3.clone(), crate::prelude::Text::from(format!("{}_part{}", &stem_p1xy, &i_p7)), inner_pdx.clone()), move |fielded_parts_f_130672: (crate::lower::node_::Wx, crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>, crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>)| {
                                let (w2_pe, bs_pf, ms_pg) = fielded_parts_f_130672;
                                ::prism_rtl::Turn::Finished((w2_pe.clone(), crate::prelude::append(&builds_p4, &crate::prelude::Array::from(vec![::std::option::Option::Some(crate::lower::types::Bn::BnParts(bs_pf.clone()))])), crate::prelude::append(&methods_p5, &crate::prelude::Array::from(vec![::std::option::Option::Some(crate::lower::types::Bn::BnParts(ms_pg.clone()))]))))
                            })
                        },
                        crate::lower::node_::Wres::WrHosted(inner_ph, _) => {
                            let inner_phx = (**inner_ph).clone();
                            crate::prelude::call_then(start_fielded_parts_f(w_p3.clone(), crate::prelude::Text::from(format!("{}_part{}", &stem_p1xy, &i_p7)), crate::prelude::Array::from(vec![inner_phx.clone()])), move |fielded_parts_f_130875: (crate::lower::node_::Wx, crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>, crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>)| {
                                let (w2_pi, bs_pj, ms_pk) = fielded_parts_f_130875;
                                ::prism_rtl::Turn::Finished((w2_pi.clone(), crate::prelude::append(&builds_p4, &crate::prelude::Array::from(vec![part_of_o(&bs_pj, &crate::prelude::Nat::from(0u32))])), crate::prelude::append(&methods_p5, &crate::prelude::Array::from(vec![part_of_o(&ms_pk, &crate::prelude::Nat::from(0u32))]))))
                            })
                        },
                        _ => {
                            let b_pl = bundle_bn_f(&part_p6);
                            ::prism_rtl::Turn::Finished((w_p3.clone(), crate::prelude::append(&builds_p4, &crate::prelude::Array::from(vec![::std::option::Option::Some(b_pl.clone())])), crate::prelude::append(&methods_p5, &crate::prelude::Array::from(vec![::std::option::Option::Some(b_pl.clone())]))))
                        },
                    }
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::lower::node_::Wx, crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>, crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>), crate::lower::node_::Wres)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>, crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>)>>>
    }))
}

/// The step machine of `FieldedParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FieldedParts: unbounded fn Wx, Text, [Wres] -> ((Wx, [?Bn], [?Bn]))
/// ```
pub struct FieldedParts {
    pub wx_p0: crate::lower::node_::Wx,
    pub stem_p1: crate::prelude::Text,
    pub parts_p2: crate::prelude::Array<crate::lower::node_::Wres>,
}

impl ::prism_rtl::Job<(crate::lower::node_::Wx, crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>, crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>)> for FieldedParts {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::lower::node_::Wx, crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>, crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>)> {
        let wx_p0 = &self.wx_p0;
        let stem_p1 = &self.stem_p1;
        let parts_p2 = &self.parts_p2;
        crate::prelude::fold_job(parts_p2.clone(), (wx_p0.clone(), crate::prelude::Array::new(), crate::prelude::Array::new()), {
            let stem_p1x = stem_p1.clone();
            ::std::rc::Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>, crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>), crate::lower::node_::Wres)| {
                let stem_p1xy = stem_p1x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let (w_p3, builds_p4, methods_p5) = p0;
                    let part_p6 = p1;
                    {
                        let i_p7 = crate::prelude::len(&builds_p4);
                        match &part_p6 {
                            crate::lower::node_::Wres::WrPlain(ex_p8, t_p9) => {
                                let (f_pb, w1_pc) = crate::lower::node_::fresh_name_f(&w_p3, &crate::prelude::Text::from(format!("{}_part{}", &stem_p1xy, &i_p7)));
                                let w2_pa = {
                                    let mut this: crate::lower::node_::Wx = w1_pc.clone();
                                    this.lets_p = crate::prelude::push(&this.lets_p, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaBind(f_pb.clone())), t_p9.clone()), ex_p8.clone()));
                                    this.fields_p = crate::prelude::push(&this.fields_p, &(f_pb.clone(), t_p9.clone(), crate::prelude::Text::from(format!("plain part {} of the bundle `{}`", &i_p7, &stem_p1xy))));
                                    this.inits_p = crate::prelude::push(&this.inits_p, &(f_pb.clone(), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(f_pb.clone())))));
                                    this
                                };
                                ::prism_rtl::Turn::Finished((w2_pa.clone(), crate::prelude::append(&builds_p4, &crate::prelude::Array::from(vec![::std::option::Option::Some(crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(f_pb.clone()), crate::lower::types::Holding::Owned, t_p9.clone()))])), crate::prelude::append(&methods_p5, &crate::prelude::Array::from(vec![::std::option::Option::Some(crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), f_pb.clone()), crate::lower::types::Holding::Owned, t_p9.clone()))]))))
                            },
                            crate::lower::node_::Wres::WrParts(inner_pd) => {
                                let inner_pdx = inner_pd.clone();
                                crate::prelude::call_then(start_fielded_parts_f(w_p3.clone(), crate::prelude::Text::from(format!("{}_part{}", &stem_p1xy, &i_p7)), inner_pdx.clone()), move |fielded_parts_f_130672: (crate::lower::node_::Wx, crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>, crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>)| {
                                    let (w2_pe, bs_pf, ms_pg) = fielded_parts_f_130672;
                                    ::prism_rtl::Turn::Finished((w2_pe.clone(), crate::prelude::append(&builds_p4, &crate::prelude::Array::from(vec![::std::option::Option::Some(crate::lower::types::Bn::BnParts(bs_pf.clone()))])), crate::prelude::append(&methods_p5, &crate::prelude::Array::from(vec![::std::option::Option::Some(crate::lower::types::Bn::BnParts(ms_pg.clone()))]))))
                                })
                            },
                            crate::lower::node_::Wres::WrHosted(inner_ph, _) => {
                                let inner_phx = (**inner_ph).clone();
                                crate::prelude::call_then(start_fielded_parts_f(w_p3.clone(), crate::prelude::Text::from(format!("{}_part{}", &stem_p1xy, &i_p7)), crate::prelude::Array::from(vec![inner_phx.clone()])), move |fielded_parts_f_130875: (crate::lower::node_::Wx, crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>, crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>)| {
                                    let (w2_pi, bs_pj, ms_pk) = fielded_parts_f_130875;
                                    ::prism_rtl::Turn::Finished((w2_pi.clone(), crate::prelude::append(&builds_p4, &crate::prelude::Array::from(vec![part_of_o(&bs_pj, &crate::prelude::Nat::from(0u32))])), crate::prelude::append(&methods_p5, &crate::prelude::Array::from(vec![part_of_o(&ms_pk, &crate::prelude::Nat::from(0u32))]))))
                                })
                            },
                            _ => {
                                let b_pl = bundle_bn_f(&part_p6);
                                ::prism_rtl::Turn::Finished((w_p3.clone(), crate::prelude::append(&builds_p4, &crate::prelude::Array::from(vec![::std::option::Option::Some(b_pl.clone())])), crate::prelude::append(&methods_p5, &crate::prelude::Array::from(vec![::std::option::Option::Some(b_pl.clone())]))))
                            },
                        }
                    }
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::lower::node_::Wx, crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>, crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>), crate::lower::node_::Wres)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>, crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>)>>>
        }).cycle()
    }
}

/// `Start FieldedParts, x`: what the function value is when passed to `@Run`.
pub fn start_fielded_parts_f(wx_p0: crate::lower::node_::Wx, stem_p1: crate::prelude::Text, parts_p2: crate::prelude::Array<crate::lower::node_::Wres>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>, crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>)>> {
    ::std::rc::Rc::new(FieldedParts { wx_p0, stem_p1, parts_p2 })
}

/// ```prism
/// ?NamedBundleTaken: unbounded fn Env, Pattern, Expr -> ?(([Pattern], [?Bn]))
/// ```
pub fn named_bundle_taken_o(env_p0: &crate::lower::types::Env, p_p1: &crate::syntax::Pattern, e_p2: &crate::syntax::Expr) -> ::std::option::Option<(crate::prelude::Array<crate::syntax::Pattern>, crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>)> {
    match ((*p_p1.kind_p).clone(), (*e_p2.kind_p).clone()) {
        (crate::syntax::PatternKind::PGroup(q_p3), _) => named_bundle_taken_o(env_p0, &*q_p3, e_p2),
        (_, crate::syntax::ExprKind::EGroup(x_p4)) => named_bundle_taken_o(env_p0, p_p1, &*x_p4),
        (crate::syntax::PatternKind::PTuple(ps_p5), crate::syntax::ExprKind::EName(m_p6)) => match if &crate::prelude::len(&m_p6.path_p) == &crate::prelude::Nat::from(1u32) {
            crate::prelude::get(&env_p0.names_p, &crate::check::env::sname_key_f(&m_p6))
        } else {
            ::std::option::Option::None
        } {
            ::std::option::Option::Some(crate::lower::types::Bn::BnParts(bs_p7)) => ::std::option::Option::Some((ps_p5, bs_p7)),
            _ => ::std::option::Option::None,
        },
        _ => ::std::option::Option::None,
    }
}

/// The step machine of `NamedBundleTaken`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?NamedBundleTaken: unbounded fn Env, Pattern, Expr -> ?(([Pattern], [?Bn]))
/// ```
pub struct NamedBundleTaken {
    pub env_p0: crate::lower::types::Env,
    pub p_p1: crate::syntax::Pattern,
    pub e_p2: crate::syntax::Expr,
}

impl ::prism_rtl::Job<::std::option::Option<(crate::prelude::Array<crate::syntax::Pattern>, crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>)>> for NamedBundleTaken {
    fn cycle(&self) -> ::prism_rtl::Turn<::std::option::Option<(crate::prelude::Array<crate::syntax::Pattern>, crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>)>> {
        let env_p0 = &self.env_p0;
        let p_p1 = &self.p_p1;
        let e_p2 = &self.e_p2;
        match ((*p_p1.kind_p).clone(), (*e_p2.kind_p).clone()) {
            (crate::syntax::PatternKind::PGroup(q_p3), _) => ::prism_rtl::Turn::More(::std::rc::Rc::new(NamedBundleTaken { env_p0: env_p0.clone(), p_p1: (*q_p3).clone(), e_p2: e_p2.clone() })),
            (_, crate::syntax::ExprKind::EGroup(x_p4)) => ::prism_rtl::Turn::More(::std::rc::Rc::new(NamedBundleTaken { env_p0: env_p0.clone(), p_p1: p_p1.clone(), e_p2: (*x_p4).clone() })),
            (crate::syntax::PatternKind::PTuple(ps_p5), crate::syntax::ExprKind::EName(m_p6)) => match if &crate::prelude::len(&m_p6.path_p) == &crate::prelude::Nat::from(1u32) {
                crate::prelude::get(&env_p0.names_p, &crate::check::env::sname_key_f(&m_p6))
            } else {
                ::std::option::Option::None
            } {
                ::std::option::Option::Some(crate::lower::types::Bn::BnParts(bs_p7)) => ::prism_rtl::Turn::Finished(::std::option::Option::Some((ps_p5.clone(), bs_p7.clone()))),
                _ => ::prism_rtl::Turn::Finished(::std::option::Option::None),
            },
            _ => ::prism_rtl::Turn::Finished(::std::option::Option::None),
        }
    }
}

/// `Start NamedBundleTaken, x`: what the function value is when passed to `@Run`.
pub fn start_named_bundle_taken_o(env_p0: crate::lower::types::Env, p_p1: crate::syntax::Pattern, e_p2: crate::syntax::Expr) -> ::std::rc::Rc<dyn ::prism_rtl::Job<::std::option::Option<(crate::prelude::Array<crate::syntax::Pattern>, crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>)>>> {
    ::std::rc::Rc::new(NamedBundleTaken { env_p0, p_p1, e_p2 })
}

/// ```prism
/// BindNamedParts: unbounded fn Wx, Env, Env, [Pattern], [Ty], [?Bn], [?Bn] -> ((Wx, Env, Env))
/// ```
pub fn bind_named_parts_f(wx_p0: &crate::lower::node_::Wx, benv_p1: &crate::lower::types::Env, menv_p2: &crate::lower::types::Env, ps_p3: &crate::prelude::Array<crate::syntax::Pattern>, tys_p4: &crate::prelude::Array<crate::check::types::Ty>, methods_p5: &crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>, builds_p6: &crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>) -> (crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env) {
    crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(ps_p3)), (wx_p0.clone(), benv_p1.clone(), menv_p2.clone()), {
        let ps_p3x = ps_p3.clone();
        let methods_p5x = methods_p5.clone();
        let tys_p4x = tys_p4.clone();
        let builds_p6x = builds_p6.clone();
        ::std::rc::Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::prelude::Nat)| {
            let ps_p3xy = ps_p3x.clone();
            let methods_p5xy = methods_p5x.clone();
            let tys_p4xy = tys_p4x.clone();
            let builds_p6xy = builds_p6x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (w_p7, be_p8, me_p9) = p0;
                let i_pa = p1;
                match (crate::prelude::index(&ps_p3xy, &i_pa), part_of_o(&methods_p5xy, &i_pa)) {
                    (::std::option::Option::Some(p_pb), ::std::option::Option::Some(m_pc)) => ::prism_rtl::Turn::Finished(bind_named_part_f(&w_p7, &be_p8, &me_p9, &p_pb, &crate::prelude::or(&crate::prelude::index(&tys_p4xy, &i_pa), &crate::check::types::Ty::TyErr), &m_pc, &part_of_o(&builds_p6xy, &i_pa))),
                    _ => ::prism_rtl::Turn::Finished((w_p7.clone(), be_p8.clone(), me_p9.clone())),
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>>>
    }))
}

/// The step machine of `BindNamedParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BindNamedParts: unbounded fn Wx, Env, Env, [Pattern], [Ty], [?Bn], [?Bn] -> ((Wx, Env, Env))
/// ```
pub struct BindNamedParts {
    pub wx_p0: crate::lower::node_::Wx,
    pub benv_p1: crate::lower::types::Env,
    pub menv_p2: crate::lower::types::Env,
    pub ps_p3: crate::prelude::Array<crate::syntax::Pattern>,
    pub tys_p4: crate::prelude::Array<crate::check::types::Ty>,
    pub methods_p5: crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>,
    pub builds_p6: crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>,
}

impl ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)> for BindNamedParts {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)> {
        let wx_p0 = &self.wx_p0;
        let benv_p1 = &self.benv_p1;
        let menv_p2 = &self.menv_p2;
        let ps_p3 = &self.ps_p3;
        let tys_p4 = &self.tys_p4;
        let methods_p5 = &self.methods_p5;
        let builds_p6 = &self.builds_p6;
        crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(ps_p3)), (wx_p0.clone(), benv_p1.clone(), menv_p2.clone()), {
            let ps_p3x = ps_p3.clone();
            let methods_p5x = methods_p5.clone();
            let tys_p4x = tys_p4.clone();
            let builds_p6x = builds_p6.clone();
            ::std::rc::Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::prelude::Nat)| {
                let ps_p3xy = ps_p3x.clone();
                let methods_p5xy = methods_p5x.clone();
                let tys_p4xy = tys_p4x.clone();
                let builds_p6xy = builds_p6x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let (w_p7, be_p8, me_p9) = p0;
                    let i_pa = p1;
                    match (crate::prelude::index(&ps_p3xy, &i_pa), part_of_o(&methods_p5xy, &i_pa)) {
                        (::std::option::Option::Some(p_pb), ::std::option::Option::Some(m_pc)) => ::prism_rtl::Turn::Finished(bind_named_part_f(&w_p7, &be_p8, &me_p9, &p_pb, &crate::prelude::or(&crate::prelude::index(&tys_p4xy, &i_pa), &crate::check::types::Ty::TyErr), &m_pc, &part_of_o(&builds_p6xy, &i_pa))),
                        _ => ::prism_rtl::Turn::Finished((w_p7.clone(), be_p8.clone(), me_p9.clone())),
                    }
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>>>
        }).cycle()
    }
}

/// `Start BindNamedParts, x`: what the function value is when passed to `@Run`.
pub fn start_bind_named_parts_f(wx_p0: crate::lower::node_::Wx, benv_p1: crate::lower::types::Env, menv_p2: crate::lower::types::Env, ps_p3: crate::prelude::Array<crate::syntax::Pattern>, tys_p4: crate::prelude::Array<crate::check::types::Ty>, methods_p5: crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>, builds_p6: crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>> {
    ::std::rc::Rc::new(BindNamedParts { wx_p0, benv_p1, menv_p2, ps_p3, tys_p4, methods_p5, builds_p6 })
}

/// ```prism
/// BindNamedPart: unbounded fn Wx, Env, Env, Pattern, Ty, Bn, ?Bn -> ((Wx, Env, Env))
/// ```
pub fn bind_named_part_f(wx_p0: &crate::lower::node_::Wx, benv_p1: &crate::lower::types::Env, menv_p2: &crate::lower::types::Env, p_p3: &crate::syntax::Pattern, ty_p4: &crate::check::types::Ty, m_p5: &crate::lower::types::Bn, built_o6: &::std::option::Option<crate::lower::types::Bn>) -> (crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env) {
    match ((*p_p3.kind_p).clone(), m_p5.clone()) {
        (crate::syntax::PatternKind::PGroup(q_p7), _) => bind_named_part_f(wx_p0, benv_p1, menv_p2, &*q_p7, ty_p4, m_p5, built_o6),
        (crate::syntax::PatternKind::PIgnore, _) => (wx_p0.clone(), benv_p1.clone(), menv_p2.clone()),
        (crate::syntax::PatternKind::PTuple(qs_p8), crate::lower::types::Bn::BnParts(ms_p9)) => {
            let bs_pa = match built_o6 {
                ::std::option::Option::Some(crate::lower::types::Bn::BnParts(xs_pb)) => xs_pb.clone(),
                _ => ms_p9.clone(),
            };
            bind_named_parts_f(wx_p0, benv_p1, menv_p2, &qs_p8, &crate::lower::node_::keyed::bundle_part_tys_f(ty_p4), &ms_p9, &bs_pa)
        },
        (crate::syntax::PatternKind::PName(n_pc), crate::lower::types::Bn::BnEv(r_pd, _)) => (bind_res_f(wx_p0, menv_p2, p_p3, &crate::lower::node_::Wres::WrEv(r_pd)), benv_p1.clone(), menv_p2.clone()),
        (crate::syntax::PatternKind::PName(n_pe), crate::lower::types::Bn::BnDyn(ex_pf, rds_pg, t_ph)) => result_getter_f(wx_p0, menv_p2, &n_pe, &ex_pf, &rds_pg, &t_ph, benv_p1, menv_p2),
        (crate::syntax::PatternKind::PName(n_pi), crate::lower::types::Bn::BnHold(f_pj, t_pk)) => result_getter_f(wx_p0, menv_p2, &n_pi, &crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), f_pj.clone())), crate::prelude::Text::lit("get"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx])), &crate::prelude::Array::from(vec![crate::lower::node_::Read::OwnRead(f_pj.clone())]), &t_pk, benv_p1, menv_p2),
        (crate::syntax::PatternKind::PName(n_pl), crate::lower::types::Bn::BnParts(ms_pm)) => {
            let bs_pn = match built_o6 {
                ::std::option::Option::Some(crate::lower::types::Bn::BnParts(xs_po)) => xs_po.clone(),
                _ => ms_pm.clone(),
            };
            (wx_p0.clone(), crate::lower::types::bind_f(benv_p1, &crate::check::env::sname_key_f(&n_pl), &crate::lower::types::Bn::BnParts(bs_pn.clone())), crate::lower::types::bind_f(menv_p2, &crate::check::env::sname_key_f(&n_pl), &crate::lower::types::Bn::BnParts(ms_pm.clone())))
        },
        (crate::syntax::PatternKind::PName(n_pp), crate::lower::types::Bn::BnLocal(part_pq, mode_pr, t_ps)) if crate::check::env::has_key_f(&menv_p2.names_p, &crate::prelude::Text::from(format!("{}#late", &crate::check::env::sname_key_f(&n_pp)))) => 'm133856: {
            let scrutinee = &crate::prelude::get(&menv_p2.names_p, &crate::check::env::sname_key_f(&n_pp));
            if let ::std::option::Option::Some(crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XMethod(m133856_0_0_0, getter_pt, _), _, _)) = scrutinee && let crate::lower::model::Ex::XSelf = &**m133856_0_0_0 {
                break 'm133856 ({
                    let mut this: crate::lower::node_::Wx = wx_p0.clone();
                    this.getters_p = crate::prelude::push(&this.getters_p, &crate::lower::model::MethDef { name_p: getter_pt.clone(), recv_p: crate::lower::model::Recv::RecvRef, params_p: crate::prelude::Array::new(), cx_p: crate::lower::model::CxArg::CxNone, ret_p: t_ps.clone(), body_p: crate::prelude::Array::new(), tail_p: crate::lower::types::own_f(&crate::lower::types::Vl::VlPlace(part_pq.clone(), mode_pr, t_ps.clone())), doc_p: crate::prelude::Text::from(format!("`{}`, a plain part of a late bundle a `let`\'s pattern names: read from the node once the row that gives it is built.", &crate::check::env::sname_key_f(&n_pp))) });
                    this
                }, benv_p1.clone(), menv_p2.clone());
            }
            ({
                let mut this: crate::lower::node_::Wx = wx_p0.clone();
                this.build_p = crate::prelude::push(&this.build_p, &crate::lower::expr::internal_bug_do_f(&crate::prelude::Text::from(format!("the late name `{}` of a `let`\'s pattern over a late bundle, which has no getter", &crate::check::env::sname_key_f(&n_pp)))));
                this
            }, benv_p1.clone(), menv_p2.clone())
        },
        (_, crate::lower::types::Bn::BnLocal(part_pu, mode_pv, t_p10)) if is_late_let_f(menv_p2, p_p3) => {
            let o_p11 = crate::lower::patterns::rust_pat_f(&wx_p0.lx_p, p_p3, ty_p4, &crate::lower::types::Holding::ByRef, &crate::prelude::Text::lit("late_part"));
            let wx2_p12 = crate::prelude::fold(&binder_names_f(p_p3), wx_p0, &(|w_p13: &crate::lower::node_::Wx, n_p14: &crate::syntax::SName| 'm134882: {
                let scrutinee = &(crate::prelude::get(&menv_p2.names_p, &crate::check::env::sname_key_f(n_p14)), crate::prelude::fold(&o_p11.binds_p, &::std::option::Option::None, &(|found_o15: &::std::option::Option<crate::lower::types::Bn>, (k_p16, b_p17): &(crate::prelude::Text, crate::lower::types::Bn)| if k_p16 == &crate::check::env::sname_key_f(n_p14) {
                    ::std::option::Option::Some(b_p17.clone())
                } else {
                    found_o15.clone()
                })));
                if let (::std::option::Option::Some(crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XMethod(m134882_0_0_0_0, getter_p18, _), _, bt_p19)), ::std::option::Option::Some(crate::lower::types::Bn::BnLocal(rs_p1a, held_p1b, vt_p1c))) = scrutinee && let crate::lower::model::Ex::XSelf = &**m134882_0_0_0_0 {
                    break 'm134882 {
                        let arm_p1d = crate::lower::model::XArm { pat_p: o_p11.pa_p.clone(), conds_p: o_p11.conds_p.clone(), body_p: crate::lower::types::own_f(&crate::lower::types::Vl::VlPlace(rs_p1a.clone(), held_p1b.clone(), vt_p1c.clone())) };
                        let other_p1e = crate::lower::model::XArm { pat_p: crate::lower::model::Pa::PaWild, conds_p: crate::prelude::Array::new(), body_p: crate::lower::model::Ex::XUnreachable };
                        let tail_p1f = crate::lower::model::Ex::XBlock(crate::prelude::Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("late_part"))), t_p10.clone()), crate::lower::types::own_f(&crate::lower::types::Vl::VlPlace(part_pu.clone(), mode_pv.clone(), t_p10.clone())))]), ::std::rc::Rc::new(crate::lower::types::own_f(&crate::lower::expr::arms_value_f(&crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("late_part")))), &crate::prelude::Array::from(vec![arm_p1d.clone(), other_p1e.clone()]), &crate::prelude::Text::lit("\'bound"), bt_p19))));
                        {
                            let mut this: crate::lower::node_::Wx = w_p13.clone();
                            this.getters_p = crate::prelude::push(&this.getters_p, &crate::lower::model::MethDef { name_p: getter_p18.clone(), recv_p: crate::lower::model::Recv::RecvRef, params_p: crate::prelude::Array::new(), cx_p: crate::lower::model::CxArg::CxNone, ret_p: bt_p19.clone(), body_p: crate::prelude::Array::new(), tail_p: tail_p1f.clone(), doc_p: crate::prelude::Text::from(format!("`{}`, a name a `let`\'s pattern binds inside a plain part of a late bundle: read from the node once the row that gives the part is built.", &crate::check::env::sname_key_f(n_p14))) });
                            this
                        }
                    };
                }
                {
                    let mut this: crate::lower::node_::Wx = w_p13.clone();
                    this.build_p = crate::prelude::push(&this.build_p, &crate::lower::expr::internal_bug_do_f(&crate::prelude::Text::from(format!("the late name `{}` of a pattern over a late bundle\'s plain part, which has no getter or which the pattern does not bind", &crate::check::env::sname_key_f(n_p14)))));
                    this
                }
            }));
            (wx2_p12.clone(), benv_p1.clone(), menv_p2.clone())
        },
        (_, crate::lower::types::Bn::BnLocal(_, _, _)) if (&crate::prelude::len(&binder_names_f(p_p3)) == &crate::prelude::Nat::from(0u32)) => (wx_p0.clone(), benv_p1.clone(), menv_p2.clone()),
        (_, crate::lower::types::Bn::BnLocal(_, _, _)) => match built_o6 {
            ::std::option::Option::Some(crate::lower::types::Bn::BnLocal(ex_p1g, mode_p1h, t_p1i)) => {
                let v_p1j = crate::lower::types::own_f(&crate::lower::types::Vl::VlPlace(ex_p1g.clone(), mode_p1h.clone(), t_p1i.clone()));
                if is_names_pattern_f(p_p3) {
                    (bind_plain_result_f(wx_p0, menv_p2, p_p3, &v_p1j, t_p1i), benv_p1.clone(), menv_p2.clone())
                } else {
                    (bind_pattern_result_f(wx_p0, menv_p2, p_p3, &v_p1j, t_p1i, ty_p4), benv_p1.clone(), menv_p2.clone())
                }
            },
            _ => ({
                let mut this: crate::lower::node_::Wx = wx_p0.clone();
                this.build_p = crate::prelude::push(&this.build_p, &crate::lower::expr::internal_bug_do_f(&crate::prelude::Text::lit("a plain part of a named bundle with no binding at the build")));
                this
            }, benv_p1.clone(), menv_p2.clone()),
        },
        _ => ({
            let mut this: crate::lower::node_::Wx = wx_p0.clone();
            this.build_p = crate::prelude::push(&this.build_p, &crate::lower::expr::internal_bug_do_f(&crate::prelude::Text::from(format!("a `let`\'s pattern over a named bundle (`{}`) that does not match the part it takes", &crate::lower::functions::src_text_f(&wx_p0.lx_p, &wx_p0.lx_p.file_p, &p_p3.span_p)))));
            this
        }, benv_p1.clone(), menv_p2.clone()),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// ResultGetter: fn Wx, Env, SName, Ex, [Read], OutTy, Env, Env -> ((Wx, Env, Env))
/// ```
pub fn result_getter_f(wx_p0: &crate::lower::node_::Wx, menv_p1: &crate::lower::types::Env, n_p2: &crate::syntax::SName, ex_p3: &crate::lower::model::Ex, rds_p4: &crate::prelude::Array<crate::lower::node_::Read>, t_p5: &crate::lower::model::OutTy, benv2_p6: &crate::lower::types::Env, menv2_p7: &crate::lower::types::Env) -> (crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env) {
    'm137227: {
        let scrutinee = &crate::prelude::get(&menv_p1.names_p, &crate::check::env::sname_key_f(n_p2));
        if let ::std::option::Option::Some(crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(m137227_0_0_0, rs_p8, _), m137227_0_1, _)) = scrutinee && let crate::lower::model::Ex::XSelf = &**m137227_0_0_0 && (m137227_0_1.len() == 1) && let ::std::option::Option::Some(crate::lower::node_::Read::OwnRead(r0_p9)) = crate::prelude::index(m137227_0_1, &crate::prelude::Nat::from(0u32)) && ((&r0_p9 == rs_p8) && !crate::check::types::has_text_f(&crate::prelude::keys(&wx_p0.dyn_reads_p), rs_p8)) {
            break 'm137227 {
                let getter_pa = crate::lower::model::MethDef { name_p: rs_p8.clone(), recv_p: crate::lower::model::Recv::RecvRef, params_p: crate::prelude::Array::new(), cx_p: crate::lower::model::CxArg::CxRef, ret_p: t_p5.clone(), body_p: crate::prelude::Array::new(), tail_p: ex_p3.clone(), doc_p: crate::prelude::Text::from(format!("`{}`, a widget\'s result", &crate::check::env::sname_key_f(n_p2))) };
                let wx2_pb = {
                    let mut this: crate::lower::node_::Wx = wx_p0.clone();
                    this.getters_p = crate::prelude::push(&this.getters_p, &getter_pa);
                    this.dyn_reads_p = crate::prelude::insert(&this.dyn_reads_p, rs_p8, rds_p4);
                    this
                };
                (wx2_pb.clone(), benv2_p6.clone(), menv2_p7.clone())
            };
        }
        (wx_p0.clone(), benv2_p6.clone(), menv2_p7.clone())
    }
}

/// ```prism
/// BindPlainResult: unbounded fn Wx, Env, Pattern, Ex, OutTy -> Wx
/// ```
pub fn bind_plain_result_f(wx_p0: &crate::lower::node_::Wx, menv_p1: &crate::lower::types::Env, p_p2: &crate::syntax::Pattern, ex_p3: &crate::lower::model::Ex, t_p4: &crate::lower::model::OutTy) -> crate::lower::node_::Wx {
    match &*p_p2.kind_p {
        crate::syntax::PatternKind::PName(n_p5) => match crate::prelude::get(&menv_p1.names_p, &crate::check::env::sname_key_f(n_p5)) {
            ::std::option::Option::Some(crate::lower::types::Bn::BnLocal(rx_p6, _, bt_p7)) => {
                let f_p8 = crate::lower::types::place_stem_f(&rx_p6);
                {
                    let mut this: crate::lower::node_::Wx = wx_p0.clone();
                    this.lets_p = crate::prelude::push(&this.lets_p, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaBind(f_p8.clone())), bt_p7.clone()), ex_p3.clone()));
                    this.fields_p = crate::prelude::push(&this.fields_p, &(f_p8.clone(), bt_p7.clone(), crate::prelude::Text::from(format!("`{}`, a widget\'s result", &crate::check::env::sname_key_f(n_p5)))));
                    this.inits_p = crate::prelude::push(&this.inits_p, &(f_p8.clone(), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(f_p8.clone())))));
                    this
                }
            },
            _ => refuse_plain_result_f(wx_p0, p_p2),
        },
        crate::syntax::PatternKind::PIgnore => wx_p0.clone(),
        crate::syntax::PatternKind::PGroup(q_p9) => bind_plain_result_f(wx_p0, menv_p1, &**q_p9, ex_p3, t_p4),
        crate::syntax::PatternKind::PTuple(ps_pa) => {
            let (tmp_pd, wx1_pe) = crate::lower::node_::fresh_name_f(wx_p0, &crate::prelude::Text::lit("result"));
            let wx2_pb = {
                let mut this: crate::lower::node_::Wx = wx1_pe.clone();
                this.lets_p = crate::prelude::push(&this.lets_p, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaBind(tmp_pd.clone())), t_p4.clone()), ex_p3.clone()));
                this
            };
            let parts_pc = match t_p4 {
                crate::lower::model::OutTy::OutTuple(ts_pf) => ts_pf.clone(),
                _ => crate::prelude::Array::new(),
            };
            crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(ps_pa)), wx2_pb.clone(), {
                let ps_pax = ps_pa.clone();
                let menv_p1x = menv_p1.clone();
                let tmp_pdx = tmp_pd.clone();
                let parts_pcx = parts_pc.clone();
                ::std::rc::Rc::new(move |(p0, p1): (crate::lower::node_::Wx, crate::prelude::Nat)| {
                    let ps_paxy = ps_pax.clone();
                    let menv_p1xy = menv_p1x.clone();
                    let tmp_pdxy = tmp_pdx.clone();
                    let parts_pcxy = parts_pcx.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let w_pg = p0;
                        let i_ph = p1;
                        match crate::prelude::index(&ps_paxy, &i_ph) {
                            ::std::option::Option::Some(q_pi) => match &*q_pi.kind_p {
                                crate::syntax::PatternKind::PName(_) => ::prism_rtl::Turn::More(::std::rc::Rc::new(BindPlainResult { wx_p0: w_pg.clone(), menv_p1: menv_p1xy.clone(), p_p2: q_pi.clone(), ex_p3: crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XPart(::std::rc::Rc::new(crate::lower::model::Ex::XVar(tmp_pdxy.clone())), i_ph.clone()))), t_p4: crate::prelude::or(&crate::prelude::index(&parts_pcxy, &i_ph), &crate::lower::model::OutTy::OutUnit) })),
                                crate::syntax::PatternKind::PIgnore => ::prism_rtl::Turn::Finished(w_pg.clone()),
                                _ => ::prism_rtl::Turn::Finished(refuse_plain_result_f(&w_pg, &q_pi)),
                            },
                            ::std::option::Option::None => ::prism_rtl::Turn::Finished(w_pg.clone()),
                        }
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::node_::Wx, crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::node_::Wx>>>
            }))
        },
        _ => refuse_plain_result_f(wx_p0, p_p2),
    }
}

/// The step machine of `BindPlainResult`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BindPlainResult: unbounded fn Wx, Env, Pattern, Ex, OutTy -> Wx
/// ```
pub struct BindPlainResult {
    pub wx_p0: crate::lower::node_::Wx,
    pub menv_p1: crate::lower::types::Env,
    pub p_p2: crate::syntax::Pattern,
    pub ex_p3: crate::lower::model::Ex,
    pub t_p4: crate::lower::model::OutTy,
}

impl ::prism_rtl::Job<crate::lower::node_::Wx> for BindPlainResult {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::lower::node_::Wx> {
        let wx_p0 = &self.wx_p0;
        let menv_p1 = &self.menv_p1;
        let p_p2 = &self.p_p2;
        let ex_p3 = &self.ex_p3;
        let t_p4 = &self.t_p4;
        match &*p_p2.kind_p {
            crate::syntax::PatternKind::PName(n_p5) => match crate::prelude::get(&menv_p1.names_p, &crate::check::env::sname_key_f(n_p5)) {
                ::std::option::Option::Some(crate::lower::types::Bn::BnLocal(rx_p6, _, bt_p7)) => {
                    let f_p8 = crate::lower::types::place_stem_f(&rx_p6);
                    ::prism_rtl::Turn::Finished({
                        let mut this: crate::lower::node_::Wx = wx_p0.clone();
                        this.lets_p = crate::prelude::push(&this.lets_p, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaBind(f_p8.clone())), bt_p7.clone()), ex_p3.clone()));
                        this.fields_p = crate::prelude::push(&this.fields_p, &(f_p8.clone(), bt_p7.clone(), crate::prelude::Text::from(format!("`{}`, a widget\'s result", &crate::check::env::sname_key_f(n_p5)))));
                        this.inits_p = crate::prelude::push(&this.inits_p, &(f_p8.clone(), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(f_p8.clone())))));
                        this
                    })
                },
                _ => ::prism_rtl::Turn::Finished(refuse_plain_result_f(wx_p0, p_p2)),
            },
            crate::syntax::PatternKind::PIgnore => ::prism_rtl::Turn::Finished(wx_p0.clone()),
            crate::syntax::PatternKind::PGroup(q_p9) => ::prism_rtl::Turn::More(::std::rc::Rc::new(BindPlainResult { wx_p0: wx_p0.clone(), menv_p1: menv_p1.clone(), p_p2: (**q_p9).clone(), ex_p3: ex_p3.clone(), t_p4: t_p4.clone() })),
            crate::syntax::PatternKind::PTuple(ps_pa) => {
                let (tmp_pd, wx1_pe) = crate::lower::node_::fresh_name_f(wx_p0, &crate::prelude::Text::lit("result"));
                let wx2_pb = {
                    let mut this: crate::lower::node_::Wx = wx1_pe.clone();
                    this.lets_p = crate::prelude::push(&this.lets_p, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaBind(tmp_pd.clone())), t_p4.clone()), ex_p3.clone()));
                    this
                };
                let parts_pc = match t_p4 {
                    crate::lower::model::OutTy::OutTuple(ts_pf) => ts_pf.clone(),
                    _ => crate::prelude::Array::new(),
                };
                crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(ps_pa)), wx2_pb.clone(), {
                    let ps_pax = ps_pa.clone();
                    let menv_p1x = menv_p1.clone();
                    let tmp_pdx = tmp_pd.clone();
                    let parts_pcx = parts_pc.clone();
                    ::std::rc::Rc::new(move |(p0, p1): (crate::lower::node_::Wx, crate::prelude::Nat)| {
                        let ps_paxy = ps_pax.clone();
                        let menv_p1xy = menv_p1x.clone();
                        let tmp_pdxy = tmp_pdx.clone();
                        let parts_pcxy = parts_pcx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let w_pg = p0;
                            let i_ph = p1;
                            match crate::prelude::index(&ps_paxy, &i_ph) {
                                ::std::option::Option::Some(q_pi) => match &*q_pi.kind_p {
                                    crate::syntax::PatternKind::PName(_) => ::prism_rtl::Turn::More(::std::rc::Rc::new(BindPlainResult { wx_p0: w_pg.clone(), menv_p1: menv_p1xy.clone(), p_p2: q_pi.clone(), ex_p3: crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XPart(::std::rc::Rc::new(crate::lower::model::Ex::XVar(tmp_pdxy.clone())), i_ph.clone()))), t_p4: crate::prelude::or(&crate::prelude::index(&parts_pcxy, &i_ph), &crate::lower::model::OutTy::OutUnit) })),
                                    crate::syntax::PatternKind::PIgnore => ::prism_rtl::Turn::Finished(w_pg.clone()),
                                    _ => ::prism_rtl::Turn::Finished(refuse_plain_result_f(&w_pg, &q_pi)),
                                },
                                ::std::option::Option::None => ::prism_rtl::Turn::Finished(w_pg.clone()),
                            }
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::node_::Wx, crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::node_::Wx>>>
                }).cycle()
            },
            _ => ::prism_rtl::Turn::Finished(refuse_plain_result_f(wx_p0, p_p2)),
        }
    }
}

/// `Start BindPlainResult, x`: what the function value is when passed to `@Run`.
pub fn start_bind_plain_result_f(wx_p0: crate::lower::node_::Wx, menv_p1: crate::lower::types::Env, p_p2: crate::syntax::Pattern, ex_p3: crate::lower::model::Ex, t_p4: crate::lower::model::OutTy) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::node_::Wx>> {
    ::std::rc::Rc::new(BindPlainResult { wx_p0, menv_p1, p_p2, ex_p3, t_p4 })
}

/// ```prism
/// RefusePlainResult: fn Wx, Pattern -> Wx
/// ```
pub fn refuse_plain_result_f(wx_p0: &crate::lower::node_::Wx, p_p1: &crate::syntax::Pattern) -> crate::lower::node_::Wx {
    let mut this: crate::lower::node_::Wx = wx_p0.clone();
    this.build_p = crate::prelude::push(&this.build_p, &crate::lower::expr::internal_bug_do_f(&crate::prelude::Text::lit("a widget\'s plain result bound by a pattern that left a name without its field or its local")));
    this
}

/// ```prism
/// BundleBn: fn Wres -> Bn
/// ```
pub fn bundle_bn_f(res_p0: &crate::lower::node_::Wres) -> crate::lower::types::Bn {
    match res_p0 {
        crate::lower::node_::Wres::WrEv(r_p1) => crate::lower::types::Bn::BnEv(r_p1.clone(), crate::lower::model::OutTy::OutUnit),
        crate::lower::node_::Wres::WrDyn(ex_p2, rds_p3, t_p4) => crate::lower::types::Bn::BnDyn(ex_p2.clone(), rds_p3.clone(), t_p4.clone()),
        crate::lower::node_::Wres::WrPlain(ex_p5, t_p6) => crate::lower::types::Bn::BnLocal(ex_p5.clone(), crate::lower::types::Holding::Owned, t_p6.clone()),
        crate::lower::node_::Wres::WrLate(_, t_p7) => crate::lower::types::Bn::BnLocal(crate::lower::expr::refusal_f(&crate::prelude::Text::lit("a late plain result in a bundle")), crate::lower::types::Holding::Owned, t_p7.clone()),
        crate::lower::node_::Wres::WrParts(parts_p8) => crate::lower::types::Bn::BnParts(crate::prelude::each(parts_p8, &(|q_p9: &crate::lower::node_::Wres| ::std::option::Option::Some(bundle_bn_f(q_p9))))),
        crate::lower::node_::Wres::WrHosted(inner_pa, _) => bundle_bn_f(&**inner_pa),
        crate::lower::node_::Wres::WrUnit => crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XUnit, crate::lower::types::Holding::Owned, crate::lower::model::OutTy::OutUnit),
    }
}

/// ```prism
/// BnRes: fn Bn -> Wres
/// ```
pub fn bn_res_f(b_p0: &crate::lower::types::Bn) -> crate::lower::node_::Wres {
    match b_p0 {
        crate::lower::types::Bn::BnEv(r_p1, _) => crate::lower::node_::Wres::WrEv(r_p1.clone()),
        crate::lower::types::Bn::BnDyn(ex_p2, rds_p3, t_p4) => crate::lower::node_::Wres::WrDyn(ex_p2.clone(), rds_p3.clone(), t_p4.clone()),
        crate::lower::types::Bn::BnLocal(ex_p5, mode_p6, t_p7) => if t_p7 == &crate::lower::model::OutTy::OutUnit {
            crate::lower::node_::Wres::WrUnit
        } else {
            crate::lower::node_::Wres::WrPlain(crate::lower::types::own_f(&crate::lower::types::Vl::VlPlace(ex_p5.clone(), mode_p6.clone(), t_p7.clone())), t_p7.clone())
        },
        crate::lower::types::Bn::BnParts(bs_p8) => crate::lower::node_::Wres::WrParts(crate::prelude::each(bs_p8, &part_res_f)),
        _ => crate::lower::node_::Wres::WrUnit,
    }
}

/// ```prism
/// PartRes: fn ?Bn -> Wres
/// ```
pub fn part_res_f(b_o0: &::std::option::Option<crate::lower::types::Bn>) -> crate::lower::node_::Wres {
    match b_o0 {
        ::std::option::Option::Some(b_p1) => bn_res_f(b_p1),
        ::std::option::Option::None => crate::lower::node_::Wres::WrUnit,
    }
}

/// ```prism
/// PlainAtBuild: unbounded fn [?Bn], [?Bn] -> [?Bn]
/// ```
pub fn plain_at_build_f(methods_p0: &crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>, builds_p1: &crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>) -> crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>> {
    crate::prelude::run_to_end(crate::prelude::fold_job(methods_p0.clone(), crate::prelude::Array::new(), {
        let builds_p1x = builds_p1.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>, ::std::option::Option<crate::lower::types::Bn>)| {
            let builds_p1xy = builds_p1x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_p2 = p0;
                let m_o3 = p1;
                ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_p2, &crate::prelude::Array::from(vec![part_at_build_o(&m_o3, &part_of_o(&builds_p1xy, &crate::prelude::len(&acc_p2)))])))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>, ::std::option::Option<crate::lower::types::Bn>)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>>>>
    }))
}

/// The step machine of `PlainAtBuild`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PlainAtBuild: unbounded fn [?Bn], [?Bn] -> [?Bn]
/// ```
pub struct PlainAtBuild {
    pub methods_p0: crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>,
    pub builds_p1: crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>,
}

impl ::prism_rtl::Job<crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>> for PlainAtBuild {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>> {
        let methods_p0 = &self.methods_p0;
        let builds_p1 = &self.builds_p1;
        crate::prelude::fold_job(methods_p0.clone(), crate::prelude::Array::new(), {
            let builds_p1x = builds_p1.clone();
            ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>, ::std::option::Option<crate::lower::types::Bn>)| {
                let builds_p1xy = builds_p1x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let acc_p2 = p0;
                    let m_o3 = p1;
                    ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_p2, &crate::prelude::Array::from(vec![part_at_build_o(&m_o3, &part_of_o(&builds_p1xy, &crate::prelude::len(&acc_p2)))])))
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>, ::std::option::Option<crate::lower::types::Bn>)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>>>>
        }).cycle()
    }
}

/// `Start PlainAtBuild, x`: what the function value is when passed to `@Run`.
pub fn start_plain_at_build_f(methods_p0: crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>, builds_p1: crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>>> {
    ::std::rc::Rc::new(PlainAtBuild { methods_p0, builds_p1 })
}

/// ```prism
/// ?PartAtBuild: unbounded fn ?Bn, ?Bn -> ?Bn
/// ```
pub fn part_at_build_o(m_o0: &::std::option::Option<crate::lower::types::Bn>, b_o1: &::std::option::Option<crate::lower::types::Bn>) -> ::std::option::Option<crate::lower::types::Bn> {
    match (m_o0.clone(), b_o1.clone()) {
        (::std::option::Option::Some(crate::lower::types::Bn::BnLocal(_, _, _)), ::std::option::Option::Some(crate::lower::types::Bn::BnLocal(ex_p2, mode_p3, t_p4))) => ::std::option::Option::Some(crate::lower::types::Bn::BnLocal(ex_p2, mode_p3, t_p4)),
        (::std::option::Option::Some(crate::lower::types::Bn::BnParts(ms_p5)), ::std::option::Option::Some(crate::lower::types::Bn::BnParts(bs_p6))) => ::std::option::Option::Some(crate::lower::types::Bn::BnParts(plain_at_build_f(&ms_p5, &bs_p6))),
        _ => m_o0.clone(),
    }
}

/// ```prism
/// ?PartOf: fn [?Bn], Nat -> ?Bn
/// ```
pub fn part_of_o(parts_p0: &crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>, i_p1: &crate::prelude::Nat) -> ::std::option::Option<crate::lower::types::Bn> {
    let (_, found_o5) = crate::prelude::fold(parts_p0, &(crate::prelude::Nat::from(0u32), ::std::option::Option::None), &(|(k_p2, f_o3): &(crate::prelude::Nat, ::std::option::Option<crate::lower::types::Bn>), b_o4: &::std::option::Option<crate::lower::types::Bn>| if k_p2 == i_p1 {
        (k_p2 + &crate::prelude::Nat::from(1u32), b_o4.clone())
    } else {
        (k_p2 + &crate::prelude::Nat::from(1u32), f_o3.clone())
    }));
    found_o5.clone()
}

/// ```prism
/// SetResult: fn Wx, Wres -> Wx
/// ```
pub fn set_result_f(wx_p0: &crate::lower::node_::Wx, res_p1: &crate::lower::node_::Wres) -> crate::lower::node_::Wx {
    let mut this: crate::lower::node_::Wx = wx_p0.clone();
    this.result_p = res_p1.clone();
    this
}

/// ```prism
/// ResultOf: unbounded fn Wx, Env, Env, Expr -> ((Wres, Wx))
/// ```
pub fn result_of_f(wx_p0: &crate::lower::node_::Wx, benv_p1: &crate::lower::types::Env, menv_p2: &crate::lower::types::Env, x_p3: &crate::syntax::Expr) -> (crate::lower::node_::Wres, crate::lower::node_::Wx) {
    let lx_p4 = wx_p0.lx_p.clone();
    let full_p5 = crate::lower::type_at_f(&lx_p4, &x_p3.span_p);
    let t_p6 = crate::lower::types::out_ty_of_f(&lx_p4, &crate::lower::types::peel_f(&full_p5));
    let bound_o7 = match &*x_p3.kind_p {
        crate::syntax::ExprKind::EName(n_p8) => if &crate::prelude::len(&n_p8.path_p) == &crate::prelude::Nat::from(1u32) {
            crate::prelude::get(&menv_p2.names_p, &crate::check::env::sname_key_f(n_p8))
        } else {
            ::std::option::Option::None
        },
        _ => ::std::option::Option::None,
    };
    match &bound_o7 {
        ::std::option::Option::Some(crate::lower::types::Bn::BnEv(r_p9, _)) => (crate::lower::node_::Wres::WrEv(r_p9.clone()), wx_p0.clone()),
        ::std::option::Option::Some(crate::lower::types::Bn::BnDyn(ex_pa, rds_pb, bt_pc)) => (crate::lower::node_::Wres::WrDyn(ex_pa.clone(), rds_pb.clone(), bt_pc.clone()), wx_p0.clone()),
        ::std::option::Option::Some(crate::lower::types::Bn::BnParts(bs_pd)) => {
            let built_oe = match &*x_p3.kind_p {
                crate::syntax::ExprKind::EName(n_pf) => crate::prelude::get(&benv_p1.names_p, &crate::check::env::sname_key_f(n_pf)),
                _ => ::std::option::Option::None,
            };
            match &built_oe {
                ::std::option::Option::Some(crate::lower::types::Bn::BnParts(builds_pg)) => (bn_res_f(&crate::lower::types::Bn::BnParts(plain_at_build_f(bs_pd, builds_pg))), wx_p0.clone()),
                _ => (bn_res_f(&crate::lower::types::Bn::BnParts(bs_pd.clone())), wx_p0.clone()),
            }
        },
        _ => match &*x_p3.kind_p {
            crate::syntax::ExprKind::ETuple(xs_ph) if crate::lower::types::is_bundle_f(&full_p5) => {
                let (parts_pn, wx2_po) = crate::prelude::run_to_end(crate::prelude::fold_job(xs_ph.clone(), (crate::prelude::Array::new(), wx_p0.clone()), {
                    let benv_p1x = benv_p1.clone();
                    let menv_p2x = menv_p2.clone();
                    ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Array<crate::lower::node_::Wres>, crate::lower::node_::Wx), crate::syntax::Expr)| {
                        let benv_p1xy = benv_p1x.clone();
                        let menv_p2xy = menv_p2x.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let (acc_pi, w_pj) = p0;
                            let y_pk = p1;
                            crate::prelude::call_then(start_result_of_f(w_pj.clone(), benv_p1xy.clone(), menv_p2xy.clone(), y_pk.clone()), move |result_of_f_142593: (crate::lower::node_::Wres, crate::lower::node_::Wx)| {
                                let (r_pl, w2_pm) = result_of_f_142593;
                                ::prism_rtl::Turn::Finished((crate::prelude::push(&acc_pi, &r_pl), w2_pm.clone()))
                            })
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Array<crate::lower::node_::Wres>, crate::lower::node_::Wx), crate::syntax::Expr)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<crate::lower::node_::Wres>, crate::lower::node_::Wx)>>>
                }));
                (crate::lower::node_::Wres::WrParts(parts_pn.clone()), wx2_po.clone())
            },
            _ => result_of_typed_f(wx_p0, benv_p1, menv_p2, x_p3, &full_p5, &t_p6),
            _ => unreachable!("no arm matched"),
        },
    }
}

/// The step machine of `ResultOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ResultOf: unbounded fn Wx, Env, Env, Expr -> ((Wres, Wx))
/// ```
pub struct ResultOf {
    pub wx_p0: crate::lower::node_::Wx,
    pub benv_p1: crate::lower::types::Env,
    pub menv_p2: crate::lower::types::Env,
    pub x_p3: crate::syntax::Expr,
}

impl ::prism_rtl::Job<(crate::lower::node_::Wres, crate::lower::node_::Wx)> for ResultOf {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::lower::node_::Wres, crate::lower::node_::Wx)> {
        let wx_p0 = &self.wx_p0;
        let benv_p1 = &self.benv_p1;
        let menv_p2 = &self.menv_p2;
        let x_p3 = &self.x_p3;
        let lx_p4 = wx_p0.lx_p.clone();
        let full_p5 = crate::lower::type_at_f(&lx_p4, &x_p3.span_p);
        let benv_p1x = benv_p1.clone();
        let menv_p2x = menv_p2.clone();
        let wx_p0x = wx_p0.clone();
        let x_p3x = x_p3.clone();
        crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p4.clone(), crate::lower::types::peel_f(&full_p5)), move |out_ty_of_f_141611: crate::lower::model::OutTy| {
            let t_p6 = out_ty_of_f_141611;
            let bound_o7 = match &*x_p3x.kind_p {
                crate::syntax::ExprKind::EName(n_p8) => if &crate::prelude::len(&n_p8.path_p) == &crate::prelude::Nat::from(1u32) {
                    crate::prelude::get(&menv_p2x.names_p, &crate::check::env::sname_key_f(n_p8))
                } else {
                    ::std::option::Option::None
                },
                _ => ::std::option::Option::None,
            };
            match &bound_o7 {
                ::std::option::Option::Some(crate::lower::types::Bn::BnEv(r_p9, _)) => ::prism_rtl::Turn::Finished((crate::lower::node_::Wres::WrEv(r_p9.clone()), wx_p0x.clone())),
                ::std::option::Option::Some(crate::lower::types::Bn::BnDyn(ex_pa, rds_pb, bt_pc)) => ::prism_rtl::Turn::Finished((crate::lower::node_::Wres::WrDyn(ex_pa.clone(), rds_pb.clone(), bt_pc.clone()), wx_p0x.clone())),
                ::std::option::Option::Some(crate::lower::types::Bn::BnParts(bs_pd)) => {
                    let built_oe = match &*x_p3x.kind_p {
                        crate::syntax::ExprKind::EName(n_pf) => crate::prelude::get(&benv_p1x.names_p, &crate::check::env::sname_key_f(n_pf)),
                        _ => ::std::option::Option::None,
                    };
                    match &built_oe {
                        ::std::option::Option::Some(crate::lower::types::Bn::BnParts(builds_pg)) => {
                            let bs_pdx = bs_pd.clone();
                            let builds_pgx = builds_pg.clone();
                            crate::prelude::call_then(start_plain_at_build_f(bs_pdx.clone(), builds_pgx.clone()), move |plain_at_build_f_142237: crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>| ::prism_rtl::Turn::Finished((bn_res_f(&crate::lower::types::Bn::BnParts(plain_at_build_f_142237)), wx_p0x.clone())))
                        },
                        _ => ::prism_rtl::Turn::Finished((bn_res_f(&crate::lower::types::Bn::BnParts(bs_pd.clone())), wx_p0x.clone())),
                    }
                },
                _ => match &*x_p3x.kind_p {
                    crate::syntax::ExprKind::ETuple(xs_ph) if crate::lower::types::is_bundle_f(&full_p5) => {
                        let xs_phx = xs_ph.clone();
                        crate::prelude::call_value(crate::prelude::fold_job(xs_phx.clone(), (crate::prelude::Array::new(), wx_p0x.clone()), {
                            let benv_p1xx = benv_p1x.clone();
                            let menv_p2xx = menv_p2x.clone();
                            ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Array<crate::lower::node_::Wres>, crate::lower::node_::Wx), crate::syntax::Expr)| {
                                let benv_p1xxy = benv_p1xx.clone();
                                let menv_p2xxy = menv_p2xx.clone();
                                crate::prelude::entered(crate::prelude::once_job(move || {
                                    let (acc_pi, w_pj) = p0;
                                    let y_pk = p1;
                                    crate::prelude::call_then(start_result_of_f(w_pj.clone(), benv_p1xxy.clone(), menv_p2xxy.clone(), y_pk.clone()), move |result_of_f_142593: (crate::lower::node_::Wres, crate::lower::node_::Wx)| {
                                        let (r_pl, w2_pm) = result_of_f_142593;
                                        ::prism_rtl::Turn::Finished((crate::prelude::push(&acc_pi, &r_pl), w2_pm.clone()))
                                    })
                                }))
                            }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Array<crate::lower::node_::Wres>, crate::lower::node_::Wx), crate::syntax::Expr)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<crate::lower::node_::Wres>, crate::lower::node_::Wx)>>>
                        }), move |fold_142517: (crate::prelude::Array<crate::lower::node_::Wres>, crate::lower::node_::Wx)| {
                            let (parts_pn, wx2_po) = fold_142517;
                            ::prism_rtl::Turn::Finished((crate::lower::node_::Wres::WrParts(parts_pn.clone()), wx2_po.clone()))
                        })
                    },
                    _ => ::prism_rtl::Turn::Finished(result_of_typed_f(&wx_p0x, &benv_p1x, &menv_p2x, &x_p3x, &full_p5, &t_p6)),
                    _ => unreachable!("no arm matched"),
                },
            }
        })
    }
}

/// `Start ResultOf, x`: what the function value is when passed to `@Run`.
pub fn start_result_of_f(wx_p0: crate::lower::node_::Wx, benv_p1: crate::lower::types::Env, menv_p2: crate::lower::types::Env, x_p3: crate::syntax::Expr) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wres, crate::lower::node_::Wx)>> {
    ::std::rc::Rc::new(ResultOf { wx_p0, benv_p1, menv_p2, x_p3 })
}

/// ```prism
/// WholeResultOf: unbounded fn Wx, Env, Env, Expr -> ((Wres, Wx))
/// ```
pub fn whole_result_of_f(wx_p0: &crate::lower::node_::Wx, benv_p1: &crate::lower::types::Env, menv_p2: &crate::lower::types::Env, x_p3: &crate::syntax::Expr) -> (crate::lower::node_::Wres, crate::lower::node_::Wx) {
    let named_o4 = match &*crate::lower::node_::static_::ungrouped_f(x_p3).kind_p {
        crate::syntax::ExprKind::EName(n_p5) => if &crate::prelude::len(&n_p5.path_p) == &crate::prelude::Nat::from(1u32) {
            crate::prelude::get(&menv_p2.names_p, &crate::check::env::sname_key_f(n_p5))
        } else {
            ::std::option::Option::None
        },
        _ => ::std::option::Option::None,
    };
    match &named_o4 {
        ::std::option::Option::Some(crate::lower::types::Bn::BnParts(bs_p6)) => whole_named_of_f(wx_p0, benv_p1, x_p3, bs_p6),
        _ => whole_written_of_f(wx_p0, benv_p1, menv_p2, x_p3),
    }
}

/// The step machine of `WholeResultOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// WholeResultOf: unbounded fn Wx, Env, Env, Expr -> ((Wres, Wx))
/// ```
pub struct WholeResultOf {
    pub wx_p0: crate::lower::node_::Wx,
    pub benv_p1: crate::lower::types::Env,
    pub menv_p2: crate::lower::types::Env,
    pub x_p3: crate::syntax::Expr,
}

impl ::prism_rtl::Job<(crate::lower::node_::Wres, crate::lower::node_::Wx)> for WholeResultOf {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::lower::node_::Wres, crate::lower::node_::Wx)> {
        let wx_p0 = &self.wx_p0;
        let benv_p1 = &self.benv_p1;
        let menv_p2 = &self.menv_p2;
        let x_p3 = &self.x_p3;
        let named_o4 = match &*crate::lower::node_::static_::ungrouped_f(x_p3).kind_p {
            crate::syntax::ExprKind::EName(n_p5) => if &crate::prelude::len(&n_p5.path_p) == &crate::prelude::Nat::from(1u32) {
                crate::prelude::get(&menv_p2.names_p, &crate::check::env::sname_key_f(n_p5))
            } else {
                ::std::option::Option::None
            },
            _ => ::std::option::Option::None,
        };
        match &named_o4 {
            ::std::option::Option::Some(crate::lower::types::Bn::BnParts(bs_p6)) => ::prism_rtl::Turn::Finished(whole_named_of_f(wx_p0, benv_p1, x_p3, bs_p6)),
            _ => ::prism_rtl::Turn::Finished(whole_written_of_f(wx_p0, benv_p1, menv_p2, x_p3)),
        }
    }
}

/// `Start WholeResultOf, x`: what the function value is when passed to `@Run`.
pub fn start_whole_result_of_f(wx_p0: crate::lower::node_::Wx, benv_p1: crate::lower::types::Env, menv_p2: crate::lower::types::Env, x_p3: crate::syntax::Expr) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wres, crate::lower::node_::Wx)>> {
    ::std::rc::Rc::new(WholeResultOf { wx_p0, benv_p1, menv_p2, x_p3 })
}

/// ```prism
/// WholeWrittenOf: unbounded fn Wx, Env, Env, Expr -> ((Wres, Wx))
/// ```
pub fn whole_written_of_f(wx_p0: &crate::lower::node_::Wx, benv_p1: &crate::lower::types::Env, menv_p2: &crate::lower::types::Env, x_p3: &crate::syntax::Expr) -> (crate::lower::node_::Wres, crate::lower::node_::Wx) {
    let lx_p4 = wx_p0.lx_p.clone();
    let full_p5 = crate::lower::type_at_f(&lx_p4, &x_p3.span_p);
    let readers_p6 = crate::prelude::filter(&crate::check::typed::print::exprs_in_f(x_p3), &(|y_p8: &crate::syntax::Expr| match &*y_p8.kind_p {
        crate::syntax::ExprKind::EName(_) => &crate::lower::types::layer_of_f(&crate::lower::type_at_f(&lx_p4, &y_p8.span_p)) == &crate::lower::types::Layer::LyDyn,
        _ => false,
    }));
    let (wx1w_pd, be1w_pe, _) = crate::prelude::run_to_end(crate::prelude::fold_job(readers_p6.clone(), (wx_p0.clone(), benv_p1.clone(), menv_p2.clone()), ::std::rc::Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::syntax::Expr)| crate::prelude::entered(crate::prelude::once_job(move || {
        let (w_p9, be_pa, me_pb) = p0;
        let y_pc = p1;
        ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::lower::node_::static_::WholeArgsAt { wx_p0: w_p9.clone(), benv_p1: be_pa.clone(), menv_p2: me_pb.clone(), e_p3: y_pc.clone(), whole_p4: true, late_p5: false }))
    }))) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::syntax::Expr)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>>>));
    let (wx1_pr, be1_ps) = crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::typed::print::exprs_in_f(x_p3), (wx1w_pd.clone(), be1w_pe.clone()), {
        let menv_p2x = menv_p2.clone();
        ::std::rc::Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::types::Env), crate::syntax::Expr)| {
            let menv_p2xy = menv_p2x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (w_pf, be_pg) = p0;
                let y_ph = p1;
                match &*y_ph.kind_p {
                    crate::syntax::ExprKind::EName(n_pi) => match (if &crate::prelude::len(&n_pi.path_p) == &crate::prelude::Nat::from(1u32) {
                        crate::prelude::get(&menv_p2xy.names_p, &crate::check::env::sname_key_f(n_pi))
                    } else {
                        ::std::option::Option::None
                    }, crate::check::env::has_key_f(&be_pg.names_p, &crate::prelude::Text::from(format!("{}#value", &crate::check::env::sname_key_f(n_pi))))) {
                        (::std::option::Option::Some(crate::lower::types::Bn::BnParts(bs_pj)), false) => {
                            let (res_pk, w2_pl) = whole_named_of_f(&w_pf, &be_pg, &y_ph, &bs_pj);
                            match &res_pk {
                                crate::lower::node_::Wres::WrPlain(ex_pm, t_pn) => {
                                    let (vf_pp, w3_pq) = crate::lower::node_::fresh_name_f(&w2_pl, &crate::prelude::Text::from(format!("{}_bundle", &crate::lower::snake_f(&crate::check::env::sname_key_f(n_pi)))));
                                    let w4_po = {
                                        let mut this: crate::lower::node_::Wx = w3_pq.clone();
                                        this.lets_p = crate::prelude::push(&this.lets_p, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaBind(vf_pp.clone())), t_pn.clone()), ex_pm.clone()));
                                        this
                                    };
                                    ::prism_rtl::Turn::Finished((w4_po.clone(), crate::lower::types::bind_f(&be_pg, &crate::prelude::Text::from(format!("{}#value", &crate::check::env::sname_key_f(n_pi))), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(vf_pp.clone()), crate::lower::types::Holding::Owned, t_pn.clone()))))
                                },
                                _ => ::prism_rtl::Turn::Finished((w2_pl.clone(), be_pg.clone())),
                            }
                        },
                        _ => ::prism_rtl::Turn::Finished((w_pf.clone(), be_pg.clone())),
                    },
                    _ => ::prism_rtl::Turn::Finished((w_pf.clone(), be_pg.clone())),
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::lower::node_::Wx, crate::lower::types::Env), crate::syntax::Expr)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env)>>>
    }));
    let lxw_p7 = {
        let mut this: crate::lower::Lx = lx_p4.clone();
        this.whole_p = true;
        this
    };
    (crate::lower::node_::Wres::WrPlain(crate::lower::types::own_f(&crate::lower::expr::value_of_f(&lxw_p7, &be1_ps, x_p3)), crate::lower::types::out_ty_of_f(&lx_p4, &full_p5)), wx1_pr.clone())
}

/// ```prism
/// WholeNamedOf: unbounded fn Wx, Env, Expr, [?Bn] -> ((Wres, Wx))
/// ```
pub fn whole_named_of_f(wx_p0: &crate::lower::node_::Wx, benv_p1: &crate::lower::types::Env, x_p2: &crate::syntax::Expr, parts_p3: &crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>) -> (crate::lower::node_::Wres, crate::lower::node_::Wx) {
    let lx_p4 = wx_p0.lx_p.clone();
    let full_p5 = crate::lower::type_at_f(&lx_p4, &x_p2.span_p);
    let builds_p6 = match &*crate::lower::node_::static_::ungrouped_f(x_p2).kind_p {
        crate::syntax::ExprKind::EName(n_p7) => match crate::prelude::get(&benv_p1.names_p, &crate::check::env::sname_key_f(n_p7)) {
            ::std::option::Option::Some(crate::lower::types::Bn::BnParts(bs_p8)) => plain_at_build_f(parts_p3, &bs_p8),
            _ => parts_p3.clone(),
        },
        _ => parts_p3.clone(),
    };
    let (values_p9, wx2_pa) = whole_parts_of_f(wx_p0, &crate::lower::snake_f(&crate::lower::functions::src_text_f(&lx_p4, &lx_p4.file_p, &x_p2.span_p)), &crate::prelude::Text::from(format!("the bundle `{}`", &crate::lower::functions::src_text_f(&lx_p4, &lx_p4.file_p, &x_p2.span_p))), &crate::lower::node_::keyed::bundle_part_tys_f(&full_p5), &builds_p6);
    (crate::lower::node_::Wres::WrPlain(crate::lower::model::Ex::XTuple(values_p9.clone()), crate::lower::types::out_ty_of_f(&lx_p4, &full_p5)), wx2_pa.clone())
}

/// ```prism
/// WholePartsOf: unbounded fn Wx, Text, Text, [Ty], [?Bn] -> (([Ex], Wx))
/// ```
pub fn whole_parts_of_f(wx_p0: &crate::lower::node_::Wx, stem_p1: &crate::prelude::Text, what_p2: &crate::prelude::Text, tys_p3: &crate::prelude::Array<crate::check::types::Ty>, builds_p4: &crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>) -> (crate::prelude::Array<crate::lower::model::Ex>, crate::lower::node_::Wx) {
    crate::prelude::run_to_end(crate::prelude::fold_job(builds_p4.clone(), (crate::prelude::Array::new(), wx_p0.clone()), {
        let tys_p3x = tys_p3.clone();
        let stem_p1x = stem_p1.clone();
        let what_p2x = what_p2.clone();
        ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Array<crate::lower::model::Ex>, crate::lower::node_::Wx), ::std::option::Option<crate::lower::types::Bn>)| {
            let tys_p3xy = tys_p3x.clone();
            let stem_p1xy = stem_p1x.clone();
            let what_p2xy = what_p2x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (acc_p5, w_p6) = p0;
                let b_o7 = p1;
                {
                    let lx_p8 = w_p6.lx_p.clone();
                    let i_p9 = crate::prelude::len(&acc_p5);
                    let part_ty_pa = crate::prelude::or(&crate::prelude::index(&tys_p3xy, &i_p9), &crate::check::types::Ty::TyErr);
                    match &b_o7 {
                        ::std::option::Option::Some(crate::lower::types::Bn::BnEv(r_pb, _)) => {
                            let r_pbx = r_pb.clone();
                            crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p8.clone(), crate::lower::types::peel_f(&crate::lower::types::peel_f(&part_ty_pa))), move |out_ty_of_f_146609: crate::lower::model::OutTy| {
                                let et_pc = out_ty_of_f_146609;
                                let (rs_pg, w1_ph) = crate::lower::node_::fresh_name_f(&w_p6, &crate::prelude::Text::from(format!("{}_part{}", &stem_p1xy, &i_p9)));
                                let pf_pd = crate::prelude::Text::from(format!("{}_v_port", &rs_pg));
                                let pt_pe = crate::lower::model::OutTy::OutRc(::std::rc::Rc::new(crate::lower::model::OutTy::OutPort(::std::rc::Rc::new(et_pc.clone()))));
                                let w2_pf = {
                                    let mut this: crate::lower::node_::Wx = crate::lower::node_::connect_f(&w1_ph, &r_pbx, &crate::lower::node_::Sk::SkPort(crate::prelude::Text::from(format!("{}_v", &rs_pg))));
                                    this.lets_p = crate::prelude::push(&this.lets_p, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaBind(pf_pd.clone())), pt_pe.clone()), crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Rc::new")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Port::new")), crate::prelude::Array::new())]))));
                                    this.fields_p = crate::prelude::push(&this.fields_p, &(pf_pd.clone(), pt_pe.clone(), crate::prelude::Text::from(format!("part {} of {} as a value: the port it fires", &i_p9, &what_p2xy))));
                                    this.moves_p = crate::prelude::push(&this.moves_p, &(pf_pd.clone(), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(pf_pd.clone())))));
                                    this
                                };
                                ::prism_rtl::Turn::Finished((crate::prelude::push(&acc_p5, &crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("prism_rtl::Event::of")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XVar(pf_pd.clone())))]))), w2_pf.clone()))
                            })
                        },
                        ::std::option::Option::Some(crate::lower::types::Bn::BnDyn(ex_pi, rds_pj, t_pk)) => {
                            let (dyn_pl, w2_pm) = live_dynamic_f(&w_p6, &crate::prelude::Text::from(format!("whole_{}_part{}", &stem_p1xy, &i_p9)), ex_pi, rds_pj, t_pk, &crate::prelude::Text::from(format!("part {} of {}", &i_p9, &what_p2xy)));
                            ::prism_rtl::Turn::Finished((crate::prelude::push(&acc_p5, &dyn_pl), w2_pm.clone()))
                        },
                        ::std::option::Option::Some(crate::lower::types::Bn::BnHold(f_pn, t_po)) => {
                            let (dyn_pp, w2_pq) = live_dynamic_f(&w_p6, &crate::prelude::Text::from(format!("whole_{}_part{}", &stem_p1xy, &i_p9)), &crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), f_pn.clone())), crate::prelude::Text::lit("get"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx])), &crate::prelude::Array::from(vec![crate::lower::node_::Read::OwnRead(f_pn.clone())]), t_po, &crate::prelude::Text::from(format!("part {} of {}", &i_p9, &what_p2xy)));
                            ::prism_rtl::Turn::Finished((crate::prelude::push(&acc_p5, &dyn_pp), w2_pq.clone()))
                        },
                        ::std::option::Option::Some(crate::lower::types::Bn::BnLocal(ex_pr, mode_ps, t_pt)) => ::prism_rtl::Turn::Finished((crate::prelude::push(&acc_p5, &crate::lower::types::own_f(&crate::lower::types::Vl::VlPlace(ex_pr.clone(), mode_ps.clone(), t_pt.clone()))), w_p6.clone())),
                        ::std::option::Option::Some(crate::lower::types::Bn::BnParts(inner_pu)) => {
                            let (values_pv, w2_p10) = whole_parts_of_f(&w_p6, &crate::prelude::Text::from(format!("{}_part{}", &stem_p1xy, &i_p9)), &crate::prelude::Text::from(format!("part {} of {}", &i_p9, &what_p2xy)), &crate::lower::node_::keyed::bundle_part_tys_f(&part_ty_pa), inner_pu);
                            ::prism_rtl::Turn::Finished((crate::prelude::push(&acc_p5, &crate::lower::model::Ex::XTuple(values_pv.clone())), w2_p10.clone()))
                        },
                        _ => ::prism_rtl::Turn::Finished((crate::prelude::push(&acc_p5, &crate::lower::expr::internal_bug_f(&crate::prelude::Text::from(format!("part {} of {}, bound as no event, dynamic, value or bundle", &i_p9, &what_p2xy)))), w_p6.clone())),
                    }
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Array<crate::lower::model::Ex>, crate::lower::node_::Wx), ::std::option::Option<crate::lower::types::Bn>)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<crate::lower::model::Ex>, crate::lower::node_::Wx)>>>
    }))
}

/// ```prism
/// WholeOfResults: unbounded fn Wx, Text, Text, [Ty], [Wres] -> ((Ex, Bool, Wx))
/// ```
pub fn whole_of_results_f(wx_p0: &crate::lower::node_::Wx, stem_p1: &crate::prelude::Text, what_p2: &crate::prelude::Text, tys_p3: &crate::prelude::Array<crate::check::types::Ty>, parts_p4: &crate::prelude::Array<crate::lower::node_::Wres>) -> (crate::lower::model::Ex, bool, crate::lower::node_::Wx) {
    if !has_late_part_f(parts_p4) {
        {
            let (values_p6, wx2_p7) = whole_parts_of_f(wx_p0, stem_p1, what_p2, tys_p3, &crate::prelude::each(parts_p4, &(|q_p5: &crate::lower::node_::Wres| ::std::option::Option::Some(bundle_bn_f(q_p5)))));
            (crate::lower::model::Ex::XTuple(values_p6.clone()), false, wx2_p7.clone())
        }
    } else {
        {
            let (values_pj, wx2_pk) = crate::prelude::run_to_end(crate::prelude::fold_job(parts_p4.clone(), (crate::prelude::Array::new(), wx_p0.clone()), {
                let tys_p3x = tys_p3.clone();
                let stem_p1x = stem_p1.clone();
                let what_p2x = what_p2.clone();
                ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Array<crate::lower::model::Ex>, crate::lower::node_::Wx), crate::lower::node_::Wres)| {
                    let tys_p3xy = tys_p3x.clone();
                    let stem_p1xy = stem_p1x.clone();
                    let what_p2xy = what_p2x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let (acc_p8, w_p9) = p0;
                        let part_pa = p1;
                        {
                            let i_pb = crate::prelude::len(&acc_p8);
                            let part_ty_pc = crate::prelude::or(&crate::prelude::index(&tys_p3xy, &i_pb), &crate::check::types::Ty::TyErr);
                            match &part_pa {
                                crate::lower::node_::Wres::WrLate(read_pd, _) => ::prism_rtl::Turn::Finished((crate::prelude::push(&acc_p8, read_pd), w_p9.clone())),
                                crate::lower::node_::Wres::WrParts(inner_pe) => {
                                    let (value_pf, _, w2_pg) = whole_of_results_f(&w_p9, &crate::prelude::Text::from(format!("{}_part{}", &stem_p1xy, &i_pb)), &crate::prelude::Text::from(format!("part {} of {}", &i_pb, &what_p2xy)), &crate::lower::node_::keyed::bundle_part_tys_f(&part_ty_pc), inner_pe);
                                    if has_late_part_f(inner_pe) {
                                        ::prism_rtl::Turn::Finished((crate::prelude::push(&acc_p8, &value_pf), w2_pg.clone()))
                                    } else {
                                        crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(w_p9.lx_p.clone(), part_ty_pc.clone()), move |out_ty_of_f_149328: crate::lower::model::OutTy| ::prism_rtl::Turn::Finished(kept_part_f(&acc_p8, &w2_pg, &value_pf, &out_ty_of_f_149328, &crate::prelude::Text::from(format!("part {} of {}", &i_pb, &what_p2xy)))))
                                    }
                                },
                                _ => {
                                    let (made_ph, w2_pi) = whole_parts_of_f(&w_p9, &crate::prelude::Text::from(format!("{}_part{}", &stem_p1xy, &i_pb)), &what_p2xy, &crate::prelude::Array::from(vec![part_ty_pc.clone()]), &crate::prelude::Array::from(vec![::std::option::Option::Some(bundle_bn_f(&part_pa))]));
                                    crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(w_p9.lx_p.clone(), part_ty_pc.clone()), move |out_ty_of_f_149574: crate::lower::model::OutTy| ::prism_rtl::Turn::Finished(kept_part_f(&acc_p8, &w2_pi, &crate::prelude::or(&crate::prelude::index(&made_ph, &crate::prelude::Nat::from(0u32)), &crate::lower::model::Ex::XUnit), &out_ty_of_f_149574, &crate::prelude::Text::from(format!("part {} of {}", &i_pb, &what_p2xy)))))
                                },
                            }
                        }
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Array<crate::lower::model::Ex>, crate::lower::node_::Wx), crate::lower::node_::Wres)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<crate::lower::model::Ex>, crate::lower::node_::Wx)>>>
            }));
            (crate::lower::model::Ex::XTuple(values_pj.clone()), true, wx2_pk.clone())
        }
    }
}

/// ```prism
/// KeptPart: fn [Ex], Wx, Ex, OutTy, Text -> (([Ex], Wx))
/// ```
pub fn kept_part_f(acc_p0: &crate::prelude::Array<crate::lower::model::Ex>, wx_p1: &crate::lower::node_::Wx, value_p2: &crate::lower::model::Ex, t_p3: &crate::lower::model::OutTy, what_p4: &crate::prelude::Text) -> (crate::prelude::Array<crate::lower::model::Ex>, crate::lower::node_::Wx) {
    let (f_p6, w1_p7) = crate::lower::node_::fresh_name_f(wx_p1, &crate::prelude::Text::lit("kept_part"));
    let w2_p5 = {
        let mut this: crate::lower::node_::Wx = w1_p7.clone();
        this.lets_p = crate::prelude::push(&this.lets_p, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaBind(f_p6.clone())), t_p3.clone()), value_p2.clone()));
        this.fields_p = crate::prelude::push(&this.fields_p, &(f_p6.clone(), t_p3.clone(), crate::prelude::Text::from(format!("{}, kept beside a late part", what_p4))));
        this.inits_p = crate::prelude::push(&this.inits_p, &(f_p6.clone(), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(f_p6.clone())))));
        this
    };
    (crate::prelude::push(acc_p0, &crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), f_p6.clone())))), w2_p5.clone())
}

/// ```prism
/// HasLatePart: unbounded fn [Wres] -> Bool
/// ```
pub fn has_late_part_f(parts_p0: &crate::prelude::Array<crate::lower::node_::Wres>) -> bool {
    crate::prelude::run_to_end(crate::prelude::fold_job(parts_p0.clone(), false, ::std::rc::Rc::new(move |(p0, p1): (bool, crate::lower::node_::Wres)| crate::prelude::entered(crate::prelude::once_job(move || {
        let found_p1 = p0;
        let part_p2 = p1;
        ::prism_rtl::Turn::Finished(found_p1 || match &part_p2 {
            crate::lower::node_::Wres::WrLate(_, _) => true,
            crate::lower::node_::Wres::WrParts(inner_p3) => has_late_part_f(inner_p3),
            crate::lower::node_::Wres::WrHosted(inner_p4, _) => has_late_part_f(&crate::prelude::Array::from(vec![(**inner_p4).clone()])),
            _ => false,
        })
    }))) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::lower::node_::Wres)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>))
}

/// ```prism
/// LiveDynamic: fn Wx, Text, Ex, [Read], OutTy, Text -> ((Ex, Wx))
/// ```
pub fn live_dynamic_f(wx_p0: &crate::lower::node_::Wx, stem_p1: &crate::prelude::Text, ex_p2: &crate::lower::model::Ex, reads_p3: &crate::prelude::Array<crate::lower::node_::Read>, t_p4: &crate::lower::model::OutTy, what_p5: &crate::prelude::Text) -> (crate::lower::model::Ex, crate::lower::node_::Wx) {
    let owner_p6 = crate::prelude::Text::lit("whole_owner");
    let wx1_p7 = if crate::check::types::has_text_f(&wx_p0.taken_p, &owner_p6) {
        wx_p0.clone()
    } else {
        {
            let mut this: crate::lower::node_::Wx = wx_p0.clone();
            this.taken_p = crate::prelude::push(&this.taken_p, &owner_p6);
            this.lets_p = crate::prelude::push(&this.lets_p, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(owner_p6.clone()), crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::from(format!("prism_rtl::Link::<{}>::new", &wx_p0.node_p))), crate::prelude::Array::new())));
            this.build_p = crate::prelude::push(&this.build_p, &crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XVar(owner_p6.clone())), crate::prelude::Text::lit("link"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("node"))))]))));
            this
        }
    };
    let (name_pi, w1_pj) = crate::lower::node_::fresh_name_f(&wx1_p7, stem_p1);
    let port_p8 = crate::prelude::Text::from(format!("{}_port", &name_pi));
    let dyn_p9 = crate::prelude::Text::from(format!("{}_dyn", &name_pi));
    let first_oa = 'm151529: {
        if let m151529_0 = reads_p3 && (m151529_0.len() == 1) && let ::std::option::Option::Some(crate::lower::node_::Read::OwnRead(f_pk)) = crate::prelude::index(m151529_0, &crate::prelude::Nat::from(0u32)) {
            break 'm151529 if crate::check::types::has_text_f(&w1_pj.inited_p, &f_pk) {
                ::std::option::Option::Some(crate::lower::model::Ex::XVar(crate::prelude::Text::from(format!("{}_init", &f_pk))))
            } else {
                ::std::option::Option::None
            };
        }
        ::std::option::Option::None
    };
    let unlinked_pb = match &first_oa {
        ::std::option::Option::Some(_) => crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("at_build")))),
        ::std::option::Option::None => crate::lower::model::Ex::XUnreachable,
    };
    let arms_pc = crate::prelude::Array::from(vec![crate::lower::model::XArm { pat_p: crate::lower::model::Pa::PaCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Some")), crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("owner"))])), conds_p: crate::prelude::Array::new(), body_p: crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("owner"))), name_pi.clone(), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx])) }, crate::lower::model::XArm { pat_p: crate::lower::model::Pa::PaUnit(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::None"))), conds_p: crate::prelude::Array::new(), body_p: unlinked_pb.clone() }]);
    let read_pd = crate::lower::model::Ex::XClosure(true, crate::prelude::Array::from(vec![crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("cx"))), crate::lower::model::OutTy::OutRef(::std::rc::Rc::new(crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Cx")), crate::prelude::Array::new()))))]), ::std::rc::Rc::new(crate::lower::model::Ex::XMatch(::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("link"))), crate::prelude::Text::lit("owner"), crate::prelude::Array::new())), arms_pc.clone(), false, t_p4.clone())));
    let linked_pe = crate::prelude::Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("link")), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(owner_p6.clone()))))]);
    let captured_pf = match &first_oa {
        ::std::option::Option::Some(v_pl) => crate::prelude::push(&linked_pe, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("at_build")), crate::lower::model::Ex::XClone(::std::rc::Rc::new(v_pl.clone())))),
        ::std::option::Option::None => linked_pe.clone(),
    };
    let made_pg = crate::lower::model::Ex::XBlock(captured_pf.clone(), ::std::rc::Rc::new(crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("prism_rtl::Dynamic::of")), crate::prelude::Array::from(vec![read_pd.clone(), crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XVar(port_p8.clone())))]))));
    let w2_ph = {
        let mut this: crate::lower::node_::Wx = w1_pj.clone();
        this.taken_p = crate::prelude::append(&this.taken_p, &crate::prelude::Array::from(vec![port_p8.clone(), dyn_p9.clone()]));
        this.getters_p = crate::prelude::push(&this.getters_p, &crate::lower::model::MethDef { name_p: name_pi.clone(), recv_p: crate::lower::model::Recv::RecvRef, params_p: crate::prelude::Array::new(), cx_p: crate::lower::model::CxArg::CxRef, ret_p: t_p4.clone(), body_p: crate::prelude::Array::new(), tail_p: ex_p2.clone(), doc_p: crate::prelude::Text::from(format!("{}, read at the read point.", what_p5)) });
        this.lets_p = crate::prelude::append(&this.lets_p, &crate::prelude::Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaBind(port_p8.clone())), crate::lower::model::OutTy::OutRc(::std::rc::Rc::new(crate::lower::model::OutTy::OutPort(::std::rc::Rc::new(crate::lower::model::OutTy::OutUnit))))), crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Rc::new")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Port::new")), crate::prelude::Array::new())]))), crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaBind(dyn_p9.clone())), crate::lower::model::OutTy::OutDyn(::std::rc::Rc::new(t_p4.clone()))), made_pg.clone())]));
        this.fields_p = crate::prelude::append(&this.fields_p, &crate::prelude::Array::from(vec![(port_p8.clone(), crate::lower::model::OutTy::OutRc(::std::rc::Rc::new(crate::lower::model::OutTy::OutPort(::std::rc::Rc::new(crate::lower::model::OutTy::OutUnit)))), crate::prelude::Text::from(format!("`{}` moved: its dynamic\'s update event", &name_pi))), (dyn_p9.clone(), crate::lower::model::OutTy::OutDyn(::std::rc::Rc::new(t_p4.clone())), crate::prelude::Text::from(format!("{} as a live dynamic", what_p5)))]));
        this.moves_p = crate::prelude::append(&this.moves_p, &crate::prelude::Array::from(vec![(port_p8.clone(), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(port_p8.clone())))), (dyn_p9.clone(), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(dyn_p9.clone()))))]));
        this.dyn_answers_p = crate::prelude::push(&this.dyn_answers_p, &(name_pi.clone(), reads_p3.clone()));
        this
    };
    (crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(dyn_p9.clone()))), crate::lower::node_::static_::once_field_f(&w2_ph, &name_pi))
}

/// ```prism
/// ResultOfTyped: unbounded fn Wx, Env, Env, Expr, Ty, OutTy -> ((Wres, Wx))
/// ```
pub fn result_of_typed_f(wx_p0: &crate::lower::node_::Wx, benv_p1: &crate::lower::types::Env, menv_p2: &crate::lower::types::Env, x_p3: &crate::syntax::Expr, full_p4: &crate::check::types::Ty, t_p5: &crate::lower::model::OutTy) -> (crate::lower::node_::Wres, crate::lower::node_::Wx) {
    let lx_p6 = wx_p0.lx_p.clone();
    match crate::lower::types::layer_of_f(full_p4) {
        crate::lower::types::Layer::LyEv => {
            let (r_p7, wx2_p8) = crate::lower::node_::dynamics::event_ref_f(wx_p0, menv_p2, x_p3);
            (crate::lower::node_::Wres::WrEv(r_p7.clone()), wx2_p8.clone())
        },
        crate::lower::types::Layer::LyDyn => {
            let (ex_p9, reads_pa) = crate::lower::node_::dynamics::dynamic_expr_f(wx_p0, menv_p2, x_p3);
            (crate::lower::node_::Wres::WrDyn(ex_p9.clone(), reads_pa.clone(), t_p5.clone()), wx_p0.clone())
        },
        _ => if t_p5 == &crate::lower::model::OutTy::OutUnit {
            (crate::lower::node_::Wres::WrUnit, wx_p0.clone())
        } else {
            (crate::lower::node_::Wres::WrPlain(crate::lower::types::own_f(&crate::lower::expr::value_of_f(&lx_p6, benv_p1, x_p3)), t_p5.clone()), wx_p0.clone())
        },
    }
}

/// ```prism
/// IsHeldHold: fn Lx, Pattern -> Bool
/// ```
pub fn is_held_hold_f(lx_p0: &crate::lower::Lx, p_p1: &crate::syntax::Pattern) -> bool {
    crate::lower::types::time_within_f(&crate::lower::binder_ty_f(lx_p0, &p_p1.span_p))
}

/// ```prism
/// ?PlacedTag: fn Lx, Expr -> ?TagInfo
/// ```
pub fn placed_tag_o(lx_p0: &crate::lower::Lx, e_p1: &crate::syntax::Expr) -> ::std::option::Option<crate::check::env::TagInfo> {
    let name_p4 = match &*e_p1.kind_p {
        crate::syntax::ExprKind::ECall(c_p2, _, _, _) => crate::lower::node_::elements::tag_name_of_f(lx_p0, &**c_p2),
        crate::syntax::ExprKind::EName(_) => crate::lower::node_::elements::tag_name_of_f(lx_p0, e_p1),
        crate::syntax::ExprKind::EGroup(x_p3) => crate::lower::node_::elements::tag_name_of_f(lx_p0, &**x_p3),
        _ => crate::prelude::Text::lit(""),
    };
    match crate::prelude::get(&lx_p0.g_p.tags_p, &name_p4) {
        ::std::option::Option::Some(tg_p5) => if &tg_p5.kind_p == &crate::prelude::Text::lit("Element") {
            ::std::option::Option::Some(tg_p5.clone())
        } else {
            ::std::option::Option::None
        },
        ::std::option::Option::None => ::std::option::Option::None,
    }
}

/// ```prism
/// IsDynamicPlace: fn Lx, Expr -> Bool
/// ```
pub fn is_dynamic_place_f(lx_p0: &crate::lower::Lx, e_p1: &crate::syntax::Expr) -> bool {
    match placed_tag_o(lx_p0, e_p1) {
        ::std::option::Option::Some(tg_p2) => &crate::lower::types::layer_of_f(&tg_p2.out_p) == &crate::lower::types::Layer::LyDyn,
        ::std::option::Option::None => false,
    }
}

/// ```prism
/// IsBundlePlace: fn Lx, Expr -> Bool
/// ```
pub fn is_bundle_place_f(lx_p0: &crate::lower::Lx, e_p1: &crate::syntax::Expr) -> bool {
    match placed_tag_o(lx_p0, e_p1) {
        ::std::option::Option::Some(tg_p2) => crate::lower::types::is_bundle_f(&crate::lower::types::peel_f(&tg_p2.out_p)),
        ::std::option::Option::None => false,
    }
}

/// ```prism
/// InitKey: fn Expr -> Text
/// ```
pub fn init_key_f(e_p0: &crate::syntax::Expr) -> crate::prelude::Text {
    crate::prelude::Text::from(format!("{}:{}", &e_p0.span_p.start_p, &e_p0.span_p.end_p))
}

/// ```prism
/// HoldLine: unbounded fn Wx, Env, Env, Pattern, Expr, Expr -> ((Wx, Env))
/// ```
pub fn hold_line_f(wx_p0: &crate::lower::node_::Wx, benv_p1: &crate::lower::types::Env, menv_p2: &crate::lower::types::Env, p_p3: &crate::syntax::Pattern, init_p4: &crate::syntax::Expr, step_p5: &crate::syntax::Expr) -> (crate::lower::node_::Wx, crate::lower::types::Env) {
    let lx_p6 = wx_p0.lx_p.clone();
    'm155354: {
        let scrutinee = &binding_of_o(menv_p2, p_p3);
        if let ::std::option::Option::Some(crate::lower::types::Bn::BnHold(f_p7, t_p8)) = scrutinee {
            break 'm155354 {
                let lxi_p9 = {
                    let mut this: crate::lower::Lx = lx_p6.clone();
                    this.whole_p = is_held_hold_f(&lx_p6, p_p3);
                    this
                };
                let iv_pa = crate::lower::types::own_f(&crate::lower::expr::value_of_f(&lxi_p9, benv_p1, init_p4));
                let wx1_pb = crate::lower::node_::add_field_f(wx_p0, f_p7, &crate::lower::model::OutTy::OutHold(::std::rc::Rc::new(t_p8.clone())), &crate::prelude::Text::from(format!("`{}`", &pat_text_f(p_p3))), &crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Hold::new")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::from(format!("{}_init", f_p7))))), crate::lower::model::Ex::XCx])));
                let (r_pd, wx2_pe) = crate::lower::node_::dynamics::event_ref_f(&wx1_pb, menv_p2, step_p5);
                let wx3_pc = {
                    let mut this: crate::lower::node_::Wx = crate::lower::node_::connect_f(&wx2_pe, &r_pd, &crate::lower::node_::Sk::SkHold(f_p7.clone()));
                    this.lets_p = crate::prelude::push(&this.lets_p, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaBind(crate::prelude::Text::from(format!("{}_init", f_p7)))), t_p8.clone()), iv_pa.clone()));
                    this.inited_p = crate::prelude::push(&this.inited_p, f_p7);
                    this
                };
                (wx3_pc.clone(), crate::lower::types::bind_f(benv_p1, &crate::prelude::Text::from(format!("{}#init", &pat_text_f(p_p3))), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(crate::prelude::Text::from(format!("{}_init", f_p7))), crate::lower::types::Holding::Owned, t_p8.clone())))
            };
        }
        if let ::std::option::Option::Some(crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(m155354_1_0_0, m155354_1_0_1, _), _, t_pg)) = scrutinee && let crate::lower::model::Ex::XMethod(m155354_1_0_0_r_0, m155354_1_0_0_r_1, _) = &**m155354_1_0_0 && let crate::lower::model::Ex::XField(m155354_1_0_0_r_0_r_0, f_pf) = &**m155354_1_0_0_r_0 && let crate::lower::model::Ex::XSelf = &**m155354_1_0_0_r_0_r_0 && (m155354_1_0_0_r_1 == &crate::prelude::Text::lit("get")) && (m155354_1_0_1 == &crate::prelude::Text::lit("expect")) {
            break 'm155354 {
                let lxi_ph = {
                    let mut this: crate::lower::Lx = lx_p6.clone();
                    this.whole_p = is_held_hold_f(&lx_p6, p_p3);
                    this
                };
                let iv_pi = crate::lower::types::own_f(&crate::lower::expr::value_of_f(&lxi_ph, menv_p2, init_p4));
                let set_pj = crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), f_pf.clone())), crate::prelude::Text::lit("set"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Some")), crate::prelude::Array::from(vec![iv_pi.clone()])), crate::lower::model::Ex::XCx])));
                let (r_pl, wx1_pm) = crate::lower::node_::dynamics::event_ref_f(wx_p0, menv_p2, step_p5);
                let wx2_pk = {
                    let mut this: crate::lower::node_::Wx = crate::lower::node_::connect_f(&wx1_pm, &some_pipe_f(&r_pl), &crate::lower::node_::Sk::SkHold(f_pf.clone()));
                    this.fields_p = crate::prelude::push(&this.fields_p, &(f_pf.clone(), crate::lower::model::OutTy::OutHold(::std::rc::Rc::new(crate::lower::model::OutTy::OutOpt(::std::rc::Rc::new(t_pg.clone())))), crate::prelude::Text::from(format!("`{}`, set when the late result it starts from is built", &pat_text_f(p_p3)))));
                    this.moves_p = crate::prelude::push(&this.moves_p, &(f_pf.clone(), crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Hold::new")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XNone, crate::lower::model::Ex::XCx]))));
                    this
                };
                if reads_late_of_places_f(menv_p2, menv_p2, init_p4) {
                    {
                        let (starter_po, wx3_pp) = crate::lower::node_::fresh_name_f(&wx2_pk, &crate::prelude::Text::from(format!("{}_start", f_pf)));
                        let wx4_pn = {
                            let mut this: crate::lower::node_::Wx = wx3_pp.clone();
                            this.getters_p = crate::prelude::push(&this.getters_p, &crate::lower::model::MethDef { name_p: starter_po.clone(), recv_p: crate::lower::model::Recv::RecvRef, params_p: crate::prelude::Array::new(), cx_p: crate::lower::model::CxArg::CxRef, ret_p: crate::lower::model::OutTy::OutUnit, body_p: crate::prelude::Array::from(vec![set_pj.clone()]), tail_p: crate::lower::model::Ex::XUnit, doc_p: crate::prelude::Text::from(format!("`{}` set from its first value, which reads a late place\'s plain part: called once the scope\'s places have asked their first values.", &pat_text_f(p_p3))) });
                            this.late_starts_p = crate::prelude::push(&this.late_starts_p, &(wx_p0.pos_p.scope_p.clone(), crate::prelude::Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("node"))), starter_po.clone(), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx])))])));
                            this
                        };
                        (wx4_pn.clone(), benv_p1.clone())
                    }
                } else {
                    {
                        let wx3_pq = {
                            let mut this: crate::lower::node_::Wx = wx2_pk.clone();
                            this.late_inits_p = crate::prelude::push(&this.late_inits_p, &set_pj);
                            this
                        };
                        (wx3_pq.clone(), benv_p1.clone())
                    }
                }
            };
        }
        (wx_p0.clone(), benv_p1.clone())
    }
}

/// The step machine of `HoldLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// HoldLine: unbounded fn Wx, Env, Env, Pattern, Expr, Expr -> ((Wx, Env))
/// ```
pub struct HoldLine {
    pub wx_p0: crate::lower::node_::Wx,
    pub benv_p1: crate::lower::types::Env,
    pub menv_p2: crate::lower::types::Env,
    pub p_p3: crate::syntax::Pattern,
    pub init_p4: crate::syntax::Expr,
    pub step_p5: crate::syntax::Expr,
}

impl ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env)> for HoldLine {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::lower::node_::Wx, crate::lower::types::Env)> {
        let wx_p0 = &self.wx_p0;
        let benv_p1 = &self.benv_p1;
        let menv_p2 = &self.menv_p2;
        let p_p3 = &self.p_p3;
        let init_p4 = &self.init_p4;
        let step_p5 = &self.step_p5;
        let lx_p6 = wx_p0.lx_p.clone();
        'm155354: {
            let scrutinee = &binding_of_o(menv_p2, p_p3);
            if let ::std::option::Option::Some(crate::lower::types::Bn::BnHold(f_p7, t_p8)) = scrutinee {
                break 'm155354 {
                    let lxi_p9 = {
                        let mut this: crate::lower::Lx = lx_p6.clone();
                        this.whole_p = is_held_hold_f(&lx_p6, p_p3);
                        this
                    };
                    let benv_p1x = benv_p1.clone();
                    let f_p7x = f_p7.clone();
                    let init_p4x = init_p4.clone();
                    let menv_p2x = menv_p2.clone();
                    let p_p3x = p_p3.clone();
                    let step_p5x = step_p5.clone();
                    let t_p8x = t_p8.clone();
                    let wx_p0x = wx_p0.clone();
                    crate::prelude::call_then(crate::lower::expr::start_value_of_f(lxi_p9.clone(), benv_p1x.clone(), init_p4x.clone()), move |value_of_f_155509: crate::lower::types::Vl| {
                        let iv_pa = crate::lower::types::own_f(&value_of_f_155509);
                        let wx1_pb = crate::lower::node_::add_field_f(&wx_p0x, &f_p7x, &crate::lower::model::OutTy::OutHold(::std::rc::Rc::new(t_p8x.clone())), &crate::prelude::Text::from(format!("`{}`", &pat_text_f(&p_p3x))), &crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Hold::new")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::from(format!("{}_init", &f_p7x))))), crate::lower::model::Ex::XCx])));
                        let (r_pd, wx2_pe) = crate::lower::node_::dynamics::event_ref_f(&wx1_pb, &menv_p2x, &step_p5x);
                        let wx3_pc = {
                            let mut this: crate::lower::node_::Wx = crate::lower::node_::connect_f(&wx2_pe, &r_pd, &crate::lower::node_::Sk::SkHold(f_p7x.clone()));
                            this.lets_p = crate::prelude::push(&this.lets_p, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaBind(crate::prelude::Text::from(format!("{}_init", &f_p7x)))), t_p8x.clone()), iv_pa.clone()));
                            this.inited_p = crate::prelude::push(&this.inited_p, &f_p7x);
                            this
                        };
                        ::prism_rtl::Turn::Finished((wx3_pc.clone(), crate::lower::types::bind_f(&benv_p1x, &crate::prelude::Text::from(format!("{}#init", &pat_text_f(&p_p3x))), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(crate::prelude::Text::from(format!("{}_init", &f_p7x))), crate::lower::types::Holding::Owned, t_p8x.clone()))))
                    })
                };
            }
            if let ::std::option::Option::Some(crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(m155354_1_0_0, m155354_1_0_1, _), _, t_pg)) = scrutinee && let crate::lower::model::Ex::XMethod(m155354_1_0_0_r_0, m155354_1_0_0_r_1, _) = &**m155354_1_0_0 && let crate::lower::model::Ex::XField(m155354_1_0_0_r_0_r_0, f_pf) = &**m155354_1_0_0_r_0 && let crate::lower::model::Ex::XSelf = &**m155354_1_0_0_r_0_r_0 && (m155354_1_0_0_r_1 == &crate::prelude::Text::lit("get")) && (m155354_1_0_1 == &crate::prelude::Text::lit("expect")) {
                break 'm155354 {
                    let lxi_ph = {
                        let mut this: crate::lower::Lx = lx_p6.clone();
                        this.whole_p = is_held_hold_f(&lx_p6, p_p3);
                        this
                    };
                    let benv_p1x = benv_p1.clone();
                    let f_pfx = f_pf.clone();
                    let init_p4x = init_p4.clone();
                    let menv_p2x = menv_p2.clone();
                    let p_p3x = p_p3.clone();
                    let step_p5x = step_p5.clone();
                    let t_pgx = t_pg.clone();
                    let wx_p0x = wx_p0.clone();
                    crate::prelude::call_then(crate::lower::expr::start_value_of_f(lxi_ph.clone(), menv_p2x.clone(), init_p4x.clone()), move |value_of_f_156443: crate::lower::types::Vl| {
                        let iv_pi = crate::lower::types::own_f(&value_of_f_156443);
                        let set_pj = crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), f_pfx.clone())), crate::prelude::Text::lit("set"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Some")), crate::prelude::Array::from(vec![iv_pi.clone()])), crate::lower::model::Ex::XCx])));
                        let (r_pl, wx1_pm) = crate::lower::node_::dynamics::event_ref_f(&wx_p0x, &menv_p2x, &step_p5x);
                        let wx2_pk = {
                            let mut this: crate::lower::node_::Wx = crate::lower::node_::connect_f(&wx1_pm, &some_pipe_f(&r_pl), &crate::lower::node_::Sk::SkHold(f_pfx.clone()));
                            this.fields_p = crate::prelude::push(&this.fields_p, &(f_pfx.clone(), crate::lower::model::OutTy::OutHold(::std::rc::Rc::new(crate::lower::model::OutTy::OutOpt(::std::rc::Rc::new(t_pgx.clone())))), crate::prelude::Text::from(format!("`{}`, set when the late result it starts from is built", &pat_text_f(&p_p3x)))));
                            this.moves_p = crate::prelude::push(&this.moves_p, &(f_pfx.clone(), crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Hold::new")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XNone, crate::lower::model::Ex::XCx]))));
                            this
                        };
                        crate::prelude::call_then(start_reads_late_of_places_f(menv_p2x.clone(), menv_p2x.clone(), init_p4x.clone()), move |reads_late_of_places_f_157270: bool| if reads_late_of_places_f_157270 {
                            {
                                let (starter_po, wx3_pp) = crate::lower::node_::fresh_name_f(&wx2_pk, &crate::prelude::Text::from(format!("{}_start", &f_pfx)));
                                let wx4_pn = {
                                    let mut this: crate::lower::node_::Wx = wx3_pp.clone();
                                    this.getters_p = crate::prelude::push(&this.getters_p, &crate::lower::model::MethDef { name_p: starter_po.clone(), recv_p: crate::lower::model::Recv::RecvRef, params_p: crate::prelude::Array::new(), cx_p: crate::lower::model::CxArg::CxRef, ret_p: crate::lower::model::OutTy::OutUnit, body_p: crate::prelude::Array::from(vec![set_pj.clone()]), tail_p: crate::lower::model::Ex::XUnit, doc_p: crate::prelude::Text::from(format!("`{}` set from its first value, which reads a late place\'s plain part: called once the scope\'s places have asked their first values.", &pat_text_f(&p_p3x))) });
                                    this.late_starts_p = crate::prelude::push(&this.late_starts_p, &(wx_p0x.pos_p.scope_p.clone(), crate::prelude::Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("node"))), starter_po.clone(), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx])))])));
                                    this
                                };
                                ::prism_rtl::Turn::Finished((wx4_pn.clone(), benv_p1x.clone()))
                            }
                        } else {
                            {
                                let wx3_pq = {
                                    let mut this: crate::lower::node_::Wx = wx2_pk.clone();
                                    this.late_inits_p = crate::prelude::push(&this.late_inits_p, &set_pj);
                                    this
                                };
                                ::prism_rtl::Turn::Finished((wx3_pq.clone(), benv_p1x.clone()))
                            }
                        })
                    })
                };
            }
            ::prism_rtl::Turn::Finished((wx_p0.clone(), benv_p1.clone()))
        }
    }
}

/// `Start HoldLine, x`: what the function value is when passed to `@Run`.
pub fn start_hold_line_f(wx_p0: crate::lower::node_::Wx, benv_p1: crate::lower::types::Env, menv_p2: crate::lower::types::Env, p_p3: crate::syntax::Pattern, init_p4: crate::syntax::Expr, step_p5: crate::syntax::Expr) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env)>> {
    ::std::rc::Rc::new(HoldLine { wx_p0, benv_p1, menv_p2, p_p3, init_p4, step_p5 })
}

/// ```prism
/// SomePipe: fn EvRef -> EvRef
/// ```
pub fn some_pipe_f(r_p0: &crate::lower::node_::EvRef) -> crate::lower::node_::EvRef {
    crate::lower::node_::EvRef { node_p: r_p0.node_p.clone(), owner_p: r_p0.owner_p.clone(), pipe_f: {
        let r_p0x = r_p0.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::lower::model::Ex, ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::Ex) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::lower::model::Do>>>>)| {
            let r_p0xy = r_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let x_p1 = p0;
                let k_f2 = p1;
                (&r_p0xy.pipe_f)((x_p1.clone(), {
                    let k_f2x = k_f2.clone();
                    ::std::rc::Rc::new(move |p0: crate::lower::model::Ex| {
                        let k_f2xy = k_f2x.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let y_p3 = p0;
                            (&k_f2xy)(crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Some")), crate::prelude::Array::from(vec![y_p3.clone()]))).cycle()
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::Ex) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::lower::model::Do>>>>
                })).cycle()
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::model::Ex, ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::Ex) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::lower::model::Do>>>>)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::lower::model::Do>>>>
    } }
}

/// ```prism
/// InitEnv: fn Env -> Env
/// ```
pub fn init_env_f(env_p0: &crate::lower::types::Env) -> crate::lower::types::Env {
    crate::prelude::fold(&crate::prelude::keys(&env_p0.names_p), env_p0, &(|en_p1: &crate::lower::types::Env, k_p2: &crate::prelude::Text| match (crate::syntax::lexer::chars::before_suffix_o(k_p2, &crate::prelude::Text::lit("#init")), crate::prelude::get(&env_p0.names_p, k_p2)) {
        (::std::option::Option::Some(name_p3), ::std::option::Option::Some(b_p4)) => crate::lower::types::bind_f(en_p1, &name_p3, &b_p4),
        _ => en_p1.clone(),
    }))
}

/// ```prism
/// AllInited: fn Wx, [Read] -> Bool
/// ```
pub fn all_inited_f(wx_p0: &crate::lower::node_::Wx, reads_p1: &crate::prelude::Array<crate::lower::node_::Read>) -> bool {
    crate::prelude::fold(&crate::lower::node_::finish::reads_closed_f(&wx_p0.dyn_reads_p, reads_p1), &true, &(|ok_p2: &bool, r_p3: &crate::lower::node_::Read| *ok_p2 && match r_p3 {
        crate::lower::node_::Read::OwnRead(f_p4) => crate::check::types::has_text_f(&wx_p0.inited_p, f_p4),
        crate::lower::node_::Read::ParentRead(_) => false,
    }))
}

/// ```prism
/// NamesInited: unbounded fn Env, Expr -> Bool
/// ```
pub fn names_inited_f(env_p0: &crate::lower::types::Env, e_p1: &crate::syntax::Expr) -> bool {
    crate::prelude::fold(&crate::lower::expr::read_names_f(&crate::check::typed::print::exprs_in_f(e_p1)), &true, &(|ok_p2: &bool, n_p3: &crate::prelude::Text| (*ok_p2 && !crate::check::env::has_key_f(&env_p0.names_p, &crate::prelude::Text::from(format!("{}#late", n_p3)))) && match crate::prelude::get(&env_p0.names_p, n_p3) {
        ::std::option::Option::Some(crate::lower::types::Bn::BnDyn(_, _, _)) => crate::check::env::has_key_f(&env_p0.names_p, &crate::prelude::Text::from(format!("{}#init", n_p3))),
        ::std::option::Option::Some(crate::lower::types::Bn::BnHold(_, _)) => crate::check::env::has_key_f(&env_p0.names_p, &crate::prelude::Text::from(format!("{}#init", n_p3))),
        _ => true,
    }))
}

/// The step machine of `NamesInited`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// NamesInited: unbounded fn Env, Expr -> Bool
/// ```
pub struct NamesInited {
    pub env_p0: crate::lower::types::Env,
    pub e_p1: crate::syntax::Expr,
}

impl ::prism_rtl::Job<bool> for NamesInited {
    fn cycle(&self) -> ::prism_rtl::Turn<bool> {
        let env_p0 = &self.env_p0;
        let e_p1 = &self.e_p1;
        let e_p1x = e_p1.clone();
        let env_p0x = env_p0.clone();
        crate::prelude::call_then(crate::check::typed::print::start_exprs_in_f(e_p1x.clone()), move |exprs_in_f_159433: crate::prelude::Array<crate::syntax::Expr>| crate::prelude::call_then(crate::lower::expr::start_read_names_f(exprs_in_f_159433), move |read_names_f_159422: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::prelude::fold(&read_names_f_159422, &true, &(|ok_p2: &bool, n_p3: &crate::prelude::Text| (*ok_p2 && !crate::check::env::has_key_f(&env_p0x.names_p, &crate::prelude::Text::from(format!("{}#late", n_p3)))) && match crate::prelude::get(&env_p0x.names_p, n_p3) {
            ::std::option::Option::Some(crate::lower::types::Bn::BnDyn(_, _, _)) => crate::check::env::has_key_f(&env_p0x.names_p, &crate::prelude::Text::from(format!("{}#init", n_p3))),
            ::std::option::Option::Some(crate::lower::types::Bn::BnHold(_, _)) => crate::check::env::has_key_f(&env_p0x.names_p, &crate::prelude::Text::from(format!("{}#init", n_p3))),
            _ => true,
        })))))
    }
}

/// `Start NamesInited, x`: what the function value is when passed to `@Run`.
pub fn start_names_inited_f(env_p0: crate::lower::types::Env, e_p1: crate::syntax::Expr) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>> {
    ::std::rc::Rc::new(NamesInited { env_p0, e_p1 })
}

/// ```prism
/// PatText: fn Pattern -> Text
/// ```
pub fn pat_text_f(p_p0: &crate::syntax::Pattern) -> crate::prelude::Text {
    match &*p_p0.kind_p {
        crate::syntax::PatternKind::PName(n_p1) => crate::check::env::sname_key_f(n_p1),
        _ => crate::prelude::Text::lit("_"),
    }
}

/// ```prism
/// LetLine: unbounded fn Wx, Env, Env, Pattern, Expr -> ((Wx, Env))
/// ```
pub fn let_line_f(wx_p0: &crate::lower::node_::Wx, benv_p1: &crate::lower::types::Env, menv_p2: &crate::lower::types::Env, p_p3: &crate::syntax::Pattern, e_p4: &crate::syntax::Expr) -> (crate::lower::node_::Wx, crate::lower::types::Env) {
    let lx_p5 = wx_p0.lx_p.clone();
    'm160161: {
        let scrutinee = &binding_of_o(menv_p2, p_p3);
        if let ::std::option::Option::Some(crate::lower::types::Bn::BnEv(er_p6, t_p7)) = scrutinee {
            break 'm160161 {
                let (r_pa, wx2_pb) = crate::lower::node_::dynamics::event_ref_f(wx_p0, menv_p2, e_p4);
                let fed_p8 = crate::lower::types::out_ty_of_f(&lx_p5, &crate::lower::types::peel_f(&crate::lower::types::peel_f(&crate::lower::type_at_f(&lx_p5, &e_p4.span_p))));
                let r2_p9 = 'm160350: {
                    if let crate::lower::model::OutTy::OutEvent(m160350_0_0) = t_p7 && let crate::lower::model::OutTy::OutRes(_) = &**m160350_0_0 {
                        break 'm160350 if &fed_p8 == &crate::lower::model::OutTy::OutError {
                            err_pipe_f(&r_pa)
                        } else {
                            r_pa.clone()
                        };
                    }
                    if let crate::lower::model::OutTy::OutRes(_) = t_p7 {
                        break 'm160350 if &fed_p8 == &crate::lower::model::OutTy::OutError {
                            err_pipe_f(&r_pa)
                        } else {
                            r_pa.clone()
                        };
                    }
                    r_pa.clone()
                };
                (crate::lower::node_::connect_f(&wx2_pb, &r2_p9, &crate::lower::node_::Sk::SkNode(er_p6.node_p.clone())), benv_p1.clone())
            };
        }
        if let ::std::option::Option::Some(crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(m160161_1_0_0, rs_pc, _), _, t_pd)) = scrutinee && let crate::lower::model::Ex::XSelf = &**m160161_1_0_0 {
            break 'm160161 {
                let (ex_pj, reads_pk) = crate::lower::node_::dynamics::dynamic_expr_f(wx_p0, menv_p2, e_p4);
                let cached_pe = (&crate::prelude::len(&reads_pk) > &crate::prelude::Nat::from(0u32)) && crate::prelude::fold(&crate::lower::node_::finish::reads_all_f(&wx_p0.dyn_reads_p, &reads_pk), &true, &(|ok_pl: &bool, r_pm: &crate::lower::node_::Read| *ok_pl && crate::lower::node_::finish::is_own_read_f(r_pm)));
                let tail_pf = if cached_pe {
                    crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::from(format!("{}_cache", rs_pc)))), crate::prelude::Text::lit("get"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx, crate::lower::model::Ex::XClosure(false, crate::prelude::Array::new(), ::std::rc::Rc::new(ex_pj.clone()))]))
                } else {
                    ex_pj.clone()
                };
                let getter_pg = crate::lower::model::MethDef { name_p: rs_pc.clone(), recv_p: crate::lower::model::Recv::RecvRef, params_p: crate::prelude::Array::new(), cx_p: crate::lower::model::CxArg::CxRef, ret_p: t_pd.clone(), body_p: crate::prelude::Array::new(), tail_p: tail_pf.clone(), doc_p: crate::prelude::Text::from(format!("`{}`", &pat_text_f(p_p3))) };
                let wx1_ph = if cached_pe {
                    {
                        let mut this: crate::lower::node_::Wx = crate::lower::node_::add_field_f(wx_p0, &crate::prelude::Text::from(format!("{}_cache", rs_pc)), &crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Cache")), crate::prelude::Array::from(vec![t_pd.clone()])), &crate::prelude::Text::from(format!("`{}`, cached", &pat_text_f(p_p3))), &crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Cache::new")), crate::prelude::Array::new()));
                        this.let_caches_p = crate::prelude::push(&this.let_caches_p, rs_pc);
                        this.taken_p = crate::prelude::push(&this.taken_p, &crate::prelude::Text::from(format!("{}_cache", rs_pc)));
                        this
                    }
                } else {
                    wx_p0.clone()
                };
                let wx2_pi = {
                    let mut this: crate::lower::node_::Wx = wx1_ph.clone();
                    this.getters_p = crate::prelude::push(&this.getters_p, &getter_pg);
                    this.dyn_reads_p = crate::prelude::insert(&this.dyn_reads_p, rs_pc, &reads_pk);
                    this
                };
                if all_inited_f(&wx2_pi, &reads_pk) && names_inited_f(benv_p1, e_p4) {
                    {
                        let wx3_pn = {
                            let mut this: crate::lower::node_::Wx = wx2_pi.clone();
                            this.lets_p = crate::prelude::push(&this.lets_p, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaBind(crate::prelude::Text::from(format!("{}_init", rs_pc)))), t_pd.clone()), crate::lower::types::own_f(&crate::lower::expr::value_of_f(&lx_p5, &init_env_f(benv_p1), e_p4))));
                            this.inited_p = crate::prelude::push(&this.inited_p, rs_pc);
                            this
                        };
                        (wx3_pn.clone(), crate::lower::types::bind_f(benv_p1, &crate::prelude::Text::from(format!("{}#init", &pat_text_f(p_p3))), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(crate::prelude::Text::from(format!("{}_init", rs_pc))), crate::lower::types::Holding::Owned, t_pd.clone())))
                    }
                } else {
                    (wx2_pi.clone(), benv_p1.clone())
                }
            };
        }
        if let ::std::option::Option::Some(crate::lower::types::Bn::BnLocal(rs_po, _, t_pp)) = scrutinee {
            break 'm160161 {
                let insts_oq = match &*p_p3.kind_p {
                    crate::syntax::PatternKind::PName(n_pt) => many_instances_o(&lx_p5, &n_pt.span_p),
                    _ => ::std::option::Option::None,
                };
                let unread_pr = match &*p_p3.kind_p {
                    crate::syntax::PatternKind::PName(n_pu) => match crate::prelude::get(&lx_p5.gens_p, &crate::lower::place_key_f(&lx_p5, &n_pu.span_p)) {
                        ::std::option::Option::Some(gn_pv) => (&(&crate::prelude::len(&gn_pv.tys_p) + &crate::prelude::len(&gn_pv.cols_p)) > &crate::prelude::Nat::from(0u32)) && (&crate::prelude::len(&crate::lower::expr::instantiations_f(&lx_p5, &gn_pv)) == &crate::prelude::Nat::from(0u32)),
                        ::std::option::Option::None => false,
                    },
                    _ => false,
                };
                let lowered_os = if unread_pr {
                    ::std::option::Option::Some(crate::prelude::Array::new())
                } else {
                    insts_oq.clone()
                };
                match &lowered_os {
                    ::std::option::Option::Some(m163143_0) if (m163143_0.len() == 0) => (wx_p0.clone(), benv_p1.clone()),
                    ::std::option::Option::Some(insts_p10) => match &*p_p3.kind_p {
                        crate::syntax::PatternKind::PName(n_p11) => {
                            let nkey_p12 = crate::check::env::sname_key_f(n_p11);
                            let wxn_p13 = crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(insts_p10)), wx_p0.clone(), {
                                let lx_p5x = lx_p5.clone();
                                let insts_p10x = insts_p10.clone();
                                let nkey_p12x = nkey_p12.clone();
                                let menv_p2x = menv_p2.clone();
                                let benv_p1x = benv_p1.clone();
                                let e_p4x = e_p4.clone();
                                ::std::rc::Rc::new(move |(p0, p1): (crate::lower::node_::Wx, crate::prelude::Nat)| {
                                    let lx_p5xy = lx_p5x.clone();
                                    let insts_p10xy = insts_p10x.clone();
                                    let nkey_p12xy = nkey_p12x.clone();
                                    let menv_p2xy = menv_p2x.clone();
                                    let benv_p1xy = benv_p1x.clone();
                                    let e_p4xy = e_p4x.clone();
                                    crate::prelude::entered(crate::prelude::once_job(move || {
                                        let w_p14 = p0;
                                        let k_p15 = p1;
                                        {
                                            let lxk_p16 = crate::lower::expr::at_instance_f(&lx_p5xy, &crate::prelude::or(&crate::prelude::index(&insts_p10xy, &k_p15), &(crate::prelude::Array::new(), crate::prelude::Array::new())));
                                            let bkey_p17 = if &k_p15 == &crate::prelude::Nat::from(0u32) {
                                                nkey_p12xy.clone()
                                            } else {
                                                crate::prelude::Text::from(format!("{}#inst{}", &nkey_p12xy, &k_p15))
                                            };
                                            match crate::prelude::get(&menv_p2xy.names_p, &bkey_p17) {
                                                ::std::option::Option::Some(crate::lower::types::Bn::BnLocal(rk_p18, _, tk_p19)) => crate::prelude::call_then(crate::lower::expr::start_value_of_f(lxk_p16.clone(), benv_p1xy.clone(), e_p4xy.clone()), move |value_of_f_163783: crate::lower::types::Vl| ::prism_rtl::Turn::Finished(widget_let_field_f(&w_p14, &crate::lower::types::place_stem_f(&rk_p18), &tk_p19, &crate::lower::types::own_f(&value_of_f_163783), &crate::prelude::Text::from(format!("`{}` at its instantiation {}", &nkey_p12xy, &k_p15))))),
                                                _ => ::prism_rtl::Turn::Finished({
                                                    let mut this: crate::lower::node_::Wx = w_p14.clone();
                                                    this.build_p = crate::prelude::push(&this.build_p, &crate::lower::expr::internal_bug_do_f(&crate::prelude::Text::from(format!("`{}` at its instantiation {}, which has no binding", &nkey_p12xy, &k_p15))));
                                                    this
                                                }),
                                            }
                                        }
                                    }))
                                }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::node_::Wx, crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::node_::Wx>>>
                            }));
                            (wxn_p13.clone(), benv_p1.clone())
                        },
                        _ => (wx_p0.clone(), benv_p1.clone()),
                    },
                    ::std::option::Option::None => {
                        let lxw_p1a = match &*p_p3.kind_p {
                            crate::syntax::PatternKind::PName(n_p1c) => crate::lower::expr::widget_let_lx_f(&lx_p5, &n_p1c.span_p),
                            _ => lx_p5.clone(),
                        };
                        let v_p1b = crate::lower::types::own_f(&crate::lower::expr::value_of_f(&lxw_p1a, benv_p1, e_p4));
                        (widget_let_field_f(wx_p0, &crate::lower::types::place_stem_f(rs_po), t_pp, &v_p1b, &crate::prelude::Text::from(format!("`{}`", &pat_text_f(p_p3)))), benv_p1.clone())
                    },
                    _ => unreachable!("no arm matched"),
                }
            };
        }
        if let ::std::option::Option::Some(crate::lower::types::Bn::BnParts(parts_p1d)) = scrutinee && (is_names_pattern_f(p_p3) && crate::prelude::fold(parts_p1d, &true, &(|ok_p1e: &bool, b_o1f: &::std::option::Option<crate::lower::types::Bn>| *ok_p1e && is_plain_part_f(b_o1f)))) {
            break 'm160161 {
                let t_p1g = crate::lower::types::out_ty_of_f(&lx_p5, &crate::lower::types::peel_f(&crate::lower::type_at_f(&lx_p5, &e_p4.span_p)));
                (bind_plain_result_f(wx_p0, menv_p2, p_p3, &crate::lower::types::own_f(&crate::lower::expr::value_of_f(&lx_p5, benv_p1, e_p4)), &t_p1g), benv_p1.clone())
            };
        }
        match &*p_p3.kind_p {
            crate::syntax::PatternKind::PIgnore => (wx_p0.clone(), benv_p1.clone()),
            _ => if crate::prelude::fold(&binder_names_f(p_p3), &true, &(|ok_p1h: &bool, n_p1i: &crate::syntax::SName| *ok_p1h && is_plain_part_f(&crate::prelude::get(&menv_p2.names_p, &crate::check::env::sname_key_f(n_p1i))))) {
                {
                    let t_p1j = crate::lower::types::out_ty_of_f(&lx_p5, &crate::lower::types::peel_f(&crate::lower::type_at_f(&lx_p5, &e_p4.span_p)));
                    (bind_pattern_result_f(wx_p0, menv_p2, p_p3, &crate::lower::types::own_f(&crate::lower::expr::value_of_f(&lx_p5, benv_p1, e_p4)), &t_p1j, &crate::lower::types::peel_f(&crate::lower::type_at_f(&lx_p5, &e_p4.span_p))), benv_p1.clone())
                }
            } else {
                if crate::prelude::fold(&binder_names_f(p_p3), &true, &(|ok_p1k: &bool, n_p1l: &crate::syntax::SName| *ok_p1k && ((is_plain_part_f(&crate::prelude::get(&menv_p2.names_p, &crate::check::env::sname_key_f(n_p1l))) || is_getter_part_f(&crate::prelude::get(&menv_p2.names_p, &crate::check::env::sname_key_f(n_p1l)))) || is_event_part_f(&crate::prelude::get(&menv_p2.names_p, &crate::check::env::sname_key_f(n_p1l)))))) {
                    (let_pattern_dynamics_f(wx_p0, benv_p1, menv_p2, p_p3, e_p4), benv_p1.clone())
                } else {
                    {
                        let wx2_p1m = {
                            let mut this: crate::lower::node_::Wx = wx_p0.clone();
                            this.build_p = crate::prelude::push(&this.build_p, &crate::lower::expr::internal_bug_do_f(&crate::prelude::Text::from(format!("a widget block\'s `let` of this pattern (`{}`), whose names are bound as no plain value, dynamic or event", &crate::lower::functions::src_text_f(&lx_p5, &lx_p5.file_p, &p_p3.span_p)))));
                            this
                        };
                        (wx2_p1m.clone(), benv_p1.clone())
                    }
                }
            },
        }
    }
}

/// The step machine of `LetLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LetLine: unbounded fn Wx, Env, Env, Pattern, Expr -> ((Wx, Env))
/// ```
pub struct LetLine {
    pub wx_p0: crate::lower::node_::Wx,
    pub benv_p1: crate::lower::types::Env,
    pub menv_p2: crate::lower::types::Env,
    pub p_p3: crate::syntax::Pattern,
    pub e_p4: crate::syntax::Expr,
}

impl ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env)> for LetLine {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::lower::node_::Wx, crate::lower::types::Env)> {
        let wx_p0 = &self.wx_p0;
        let benv_p1 = &self.benv_p1;
        let menv_p2 = &self.menv_p2;
        let p_p3 = &self.p_p3;
        let e_p4 = &self.e_p4;
        let lx_p5 = wx_p0.lx_p.clone();
        'm160161: {
            let scrutinee = &binding_of_o(menv_p2, p_p3);
            if let ::std::option::Option::Some(crate::lower::types::Bn::BnEv(er_p6, t_p7)) = scrutinee {
                break 'm160161 {
                    let (r_pa, wx2_pb) = crate::lower::node_::dynamics::event_ref_f(wx_p0, menv_p2, e_p4);
                    let benv_p1x = benv_p1.clone();
                    let e_p4x = e_p4.clone();
                    let er_p6x = er_p6.clone();
                    let t_p7x = t_p7.clone();
                    crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p5.clone(), crate::lower::types::peel_f(&crate::lower::types::peel_f(&crate::lower::type_at_f(&lx_p5, &e_p4x.span_p)))), move |out_ty_of_f_160283: crate::lower::model::OutTy| {
                        let fed_p8 = out_ty_of_f_160283;
                        let r2_p9 = 'm160350: {
                            if let crate::lower::model::OutTy::OutEvent(m160350_0_0) = &t_p7x && let crate::lower::model::OutTy::OutRes(_) = &**m160350_0_0 {
                                break 'm160350 if &fed_p8 == &crate::lower::model::OutTy::OutError {
                                    err_pipe_f(&r_pa)
                                } else {
                                    r_pa.clone()
                                };
                            }
                            if let crate::lower::model::OutTy::OutRes(_) = &t_p7x {
                                break 'm160350 if &fed_p8 == &crate::lower::model::OutTy::OutError {
                                    err_pipe_f(&r_pa)
                                } else {
                                    r_pa.clone()
                                };
                            }
                            r_pa.clone()
                        };
                        ::prism_rtl::Turn::Finished((crate::lower::node_::connect_f(&wx2_pb, &r2_p9, &crate::lower::node_::Sk::SkNode(er_p6x.node_p.clone())), benv_p1x.clone()))
                    })
                };
            }
            if let ::std::option::Option::Some(crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(m160161_1_0_0, rs_pc, _), _, t_pd)) = scrutinee && let crate::lower::model::Ex::XSelf = &**m160161_1_0_0 {
                break 'm160161 {
                    let benv_p1x = benv_p1.clone();
                    let e_p4x = e_p4.clone();
                    let menv_p2x = menv_p2.clone();
                    let p_p3x = p_p3.clone();
                    let rs_pcx = rs_pc.clone();
                    let t_pdx = t_pd.clone();
                    let wx_p0x = wx_p0.clone();
                    crate::prelude::call_then(crate::lower::node_::dynamics::start_dynamic_expr_f(wx_p0x.clone(), menv_p2x.clone(), e_p4x.clone()), move |dynamic_expr_f_160743: (crate::lower::model::Ex, crate::prelude::Array<crate::lower::node_::Read>)| {
                        let (ex_pj, reads_pk) = dynamic_expr_f_160743;
                        let cached_pe = (&crate::prelude::len(&reads_pk) > &crate::prelude::Nat::from(0u32)) && crate::prelude::fold(&crate::lower::node_::finish::reads_all_f(&wx_p0x.dyn_reads_p, &reads_pk), &true, &(|ok_pl: &bool, r_pm: &crate::lower::node_::Read| *ok_pl && crate::lower::node_::finish::is_own_read_f(r_pm)));
                        let tail_pf = if cached_pe {
                            crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::from(format!("{}_cache", &rs_pcx)))), crate::prelude::Text::lit("get"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx, crate::lower::model::Ex::XClosure(false, crate::prelude::Array::new(), ::std::rc::Rc::new(ex_pj.clone()))]))
                        } else {
                            ex_pj.clone()
                        };
                        let getter_pg = crate::lower::model::MethDef { name_p: rs_pcx.clone(), recv_p: crate::lower::model::Recv::RecvRef, params_p: crate::prelude::Array::new(), cx_p: crate::lower::model::CxArg::CxRef, ret_p: t_pdx.clone(), body_p: crate::prelude::Array::new(), tail_p: tail_pf.clone(), doc_p: crate::prelude::Text::from(format!("`{}`", &pat_text_f(&p_p3x))) };
                        let wx1_ph = if cached_pe {
                            {
                                let mut this: crate::lower::node_::Wx = crate::lower::node_::add_field_f(&wx_p0x, &crate::prelude::Text::from(format!("{}_cache", &rs_pcx)), &crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Cache")), crate::prelude::Array::from(vec![t_pdx.clone()])), &crate::prelude::Text::from(format!("`{}`, cached", &pat_text_f(&p_p3x))), &crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Cache::new")), crate::prelude::Array::new()));
                                this.let_caches_p = crate::prelude::push(&this.let_caches_p, &rs_pcx);
                                this.taken_p = crate::prelude::push(&this.taken_p, &crate::prelude::Text::from(format!("{}_cache", &rs_pcx)));
                                this
                            }
                        } else {
                            wx_p0x.clone()
                        };
                        let wx2_pi = {
                            let mut this: crate::lower::node_::Wx = wx1_ph.clone();
                            this.getters_p = crate::prelude::push(&this.getters_p, &getter_pg);
                            this.dyn_reads_p = crate::prelude::insert(&this.dyn_reads_p, &rs_pcx, &reads_pk);
                            this
                        };
                        if all_inited_f(&wx2_pi, &reads_pk) && names_inited_f(&benv_p1x, &e_p4x) {
                            {
                                let wx3_pn = {
                                    let mut this: crate::lower::node_::Wx = wx2_pi.clone();
                                    this.lets_p = crate::prelude::push(&this.lets_p, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaBind(crate::prelude::Text::from(format!("{}_init", &rs_pcx)))), t_pdx.clone()), crate::lower::types::own_f(&crate::lower::expr::value_of_f(&lx_p5, &init_env_f(&benv_p1x), &e_p4x))));
                                    this.inited_p = crate::prelude::push(&this.inited_p, &rs_pcx);
                                    this
                                };
                                ::prism_rtl::Turn::Finished((wx3_pn.clone(), crate::lower::types::bind_f(&benv_p1x, &crate::prelude::Text::from(format!("{}#init", &pat_text_f(&p_p3x))), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(crate::prelude::Text::from(format!("{}_init", &rs_pcx))), crate::lower::types::Holding::Owned, t_pdx.clone()))))
                            }
                        } else {
                            ::prism_rtl::Turn::Finished((wx2_pi.clone(), benv_p1x.clone()))
                        }
                    })
                };
            }
            if let ::std::option::Option::Some(crate::lower::types::Bn::BnLocal(rs_po, _, t_pp)) = scrutinee {
                break 'm160161 {
                    let insts_oq = match &*p_p3.kind_p {
                        crate::syntax::PatternKind::PName(n_pt) => many_instances_o(&lx_p5, &n_pt.span_p),
                        _ => ::std::option::Option::None,
                    };
                    let insts_oqz = insts_oq.clone();
                    let benv_p1z = benv_p1.clone();
                    let e_p4z = e_p4.clone();
                    let lx_p5z = lx_p5.clone();
                    let menv_p2z = menv_p2.clone();
                    let p_p3z = p_p3.clone();
                    let rs_poz = rs_po.clone();
                    let t_ppz = t_pp.clone();
                    let wx_p0z = wx_p0.clone();
                    let k_let162728 = move |v162728: bool| {
                        let unread_pr = v162728;
                        let lowered_os = if unread_pr {
                            ::std::option::Option::Some(crate::prelude::Array::new())
                        } else {
                            insts_oqz.clone()
                        };
                        match &lowered_os {
                            ::std::option::Option::Some(m163143_0) if (m163143_0.len() == 0) => ::prism_rtl::Turn::Finished((wx_p0z.clone(), benv_p1z.clone())),
                            ::std::option::Option::Some(insts_p10) => match &*p_p3z.kind_p {
                                crate::syntax::PatternKind::PName(n_p11) => {
                                    let nkey_p12 = crate::check::env::sname_key_f(n_p11);
                                    let insts_p10x = insts_p10.clone();
                                    crate::prelude::call_value(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(&insts_p10x)), wx_p0z.clone(), {
                                        let lx_p5zx = lx_p5z.clone();
                                        let insts_p10xx = insts_p10x.clone();
                                        let nkey_p12x = nkey_p12.clone();
                                        let menv_p2zx = menv_p2z.clone();
                                        let benv_p1zx = benv_p1z.clone();
                                        let e_p4zx = e_p4z.clone();
                                        ::std::rc::Rc::new(move |(p0, p1): (crate::lower::node_::Wx, crate::prelude::Nat)| {
                                            let lx_p5zxy = lx_p5zx.clone();
                                            let insts_p10xxy = insts_p10xx.clone();
                                            let nkey_p12xy = nkey_p12x.clone();
                                            let menv_p2zxy = menv_p2zx.clone();
                                            let benv_p1zxy = benv_p1zx.clone();
                                            let e_p4zxy = e_p4zx.clone();
                                            crate::prelude::entered(crate::prelude::once_job(move || {
                                                let w_p14 = p0;
                                                let k_p15 = p1;
                                                {
                                                    let lxk_p16 = crate::lower::expr::at_instance_f(&lx_p5zxy, &crate::prelude::or(&crate::prelude::index(&insts_p10xxy, &k_p15), &(crate::prelude::Array::new(), crate::prelude::Array::new())));
                                                    let bkey_p17 = if &k_p15 == &crate::prelude::Nat::from(0u32) {
                                                        nkey_p12xy.clone()
                                                    } else {
                                                        crate::prelude::Text::from(format!("{}#inst{}", &nkey_p12xy, &k_p15))
                                                    };
                                                    match crate::prelude::get(&menv_p2zxy.names_p, &bkey_p17) {
                                                        ::std::option::Option::Some(crate::lower::types::Bn::BnLocal(rk_p18, _, tk_p19)) => crate::prelude::call_then(crate::lower::expr::start_value_of_f(lxk_p16.clone(), benv_p1zxy.clone(), e_p4zxy.clone()), move |value_of_f_163783: crate::lower::types::Vl| ::prism_rtl::Turn::Finished(widget_let_field_f(&w_p14, &crate::lower::types::place_stem_f(&rk_p18), &tk_p19, &crate::lower::types::own_f(&value_of_f_163783), &crate::prelude::Text::from(format!("`{}` at its instantiation {}", &nkey_p12xy, &k_p15))))),
                                                        _ => ::prism_rtl::Turn::Finished({
                                                            let mut this: crate::lower::node_::Wx = w_p14.clone();
                                                            this.build_p = crate::prelude::push(&this.build_p, &crate::lower::expr::internal_bug_do_f(&crate::prelude::Text::from(format!("`{}` at its instantiation {}, which has no binding", &nkey_p12xy, &k_p15))));
                                                            this
                                                        }),
                                                    }
                                                }
                                            }))
                                        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::node_::Wx, crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::node_::Wx>>>
                                    }), move |fold_163427: crate::lower::node_::Wx| {
                                        let wxn_p13 = fold_163427;
                                        ::prism_rtl::Turn::Finished((wxn_p13.clone(), benv_p1z.clone()))
                                    })
                                },
                                _ => ::prism_rtl::Turn::Finished((wx_p0z.clone(), benv_p1z.clone())),
                            },
                            ::std::option::Option::None => {
                                let benv_p1zz = benv_p1z.clone();
                                let e_p4zz = e_p4z.clone();
                                let p_p3zz = p_p3z.clone();
                                let rs_pozz = rs_poz.clone();
                                let t_ppzz = t_ppz.clone();
                                let wx_p0zz = wx_p0z.clone();
                                let k_let164156 = move |v164156: crate::lower::Lx| {
                                    let lxw_p1a = v164156;
                                    crate::prelude::call_then(crate::lower::expr::start_value_of_f(lxw_p1a.clone(), benv_p1zz.clone(), e_p4zz.clone()), move |value_of_f_164307: crate::lower::types::Vl| {
                                        let v_p1b = crate::lower::types::own_f(&value_of_f_164307);
                                        ::prism_rtl::Turn::Finished((widget_let_field_f(&wx_p0zz, &crate::lower::types::place_stem_f(&rs_pozz), &t_ppzz, &v_p1b, &crate::prelude::Text::from(format!("`{}`", &pat_text_f(&p_p3zz)))), benv_p1zz.clone()))
                                    })
                                };
                                match (*p_p3z.kind_p).clone() {
                                    crate::syntax::PatternKind::PName(n_p1c) => crate::prelude::call_then(crate::lower::expr::start_widget_let_lx_f(lx_p5z.clone(), n_p1c.span_p.clone()), move |widget_let_lx_f_164213: crate::lower::Lx| k_let164156(widget_let_lx_f_164213)),
                                    _ => k_let164156(lx_p5z.clone()),
                                }
                            },
                            _ => unreachable!("no arm matched"),
                        }
                    };
                    match (*p_p3.kind_p).clone() {
                        crate::syntax::PatternKind::PName(n_pu) => match crate::prelude::get(&lx_p5.gens_p, &crate::lower::place_key_f(&lx_p5, &n_pu.span_p)) {
                            ::std::option::Option::Some(gn_pv) => if &(&crate::prelude::len(&gn_pv.tys_p) + &crate::prelude::len(&gn_pv.cols_p)) > &crate::prelude::Nat::from(0u32) {
                                crate::prelude::call_then(crate::lower::expr::start_instantiations_f(lx_p5.clone(), gn_pv.clone()), move |instantiations_f_162887: crate::prelude::Array<(crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Col)>)>| k_let162728(&crate::prelude::len(&instantiations_f_162887) == &crate::prelude::Nat::from(0u32)))
                            } else {
                                k_let162728(false)
                            },
                            ::std::option::Option::None => k_let162728(false),
                        },
                        _ => k_let162728(false),
                    }
                };
            }
            if let ::std::option::Option::Some(crate::lower::types::Bn::BnParts(parts_p1d)) = scrutinee && (is_names_pattern_f(p_p3) && crate::prelude::fold(parts_p1d, &true, &(|ok_p1e: &bool, b_o1f: &::std::option::Option<crate::lower::types::Bn>| *ok_p1e && is_plain_part_f(b_o1f)))) {
                break 'm160161 {
                    let benv_p1x = benv_p1.clone();
                    let e_p4x = e_p4.clone();
                    let menv_p2x = menv_p2.clone();
                    let p_p3x = p_p3.clone();
                    let wx_p0x = wx_p0.clone();
                    crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p5.clone(), crate::lower::types::peel_f(&crate::lower::type_at_f(&lx_p5, &e_p4x.span_p))), move |out_ty_of_f_164691: crate::lower::model::OutTy| {
                        let t_p1g = out_ty_of_f_164691;
                        crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p5.clone(), benv_p1x.clone(), e_p4x.clone()), move |value_of_f_164780: crate::lower::types::Vl| crate::prelude::call_then(start_bind_plain_result_f(wx_p0x.clone(), menv_p2x.clone(), p_p3x.clone(), crate::lower::types::own_f(&value_of_f_164780), t_p1g.clone()), move |bind_plain_result_f_164745: crate::lower::node_::Wx| ::prism_rtl::Turn::Finished((bind_plain_result_f_164745, benv_p1x.clone()))))
                    })
                };
            }
            match &*p_p3.kind_p {
                crate::syntax::PatternKind::PIgnore => ::prism_rtl::Turn::Finished((wx_p0.clone(), benv_p1.clone())),
                _ => {
                    let benv_p1x = benv_p1.clone();
                    let e_p4x = e_p4.clone();
                    let menv_p2x = menv_p2.clone();
                    let p_p3x = p_p3.clone();
                    let wx_p0x = wx_p0.clone();
                    crate::prelude::call_then(start_binder_names_f(p_p3x.clone()), move |binder_names_f_165187: crate::prelude::Array<crate::syntax::SName>| if crate::prelude::fold(&binder_names_f_165187, &true, &(|ok_p1h: &bool, n_p1i: &crate::syntax::SName| *ok_p1h && is_plain_part_f(&crate::prelude::get(&menv_p2x.names_p, &crate::check::env::sname_key_f(n_p1i))))) {
                        crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p5.clone(), crate::lower::types::peel_f(&crate::lower::type_at_f(&lx_p5, &e_p4x.span_p))), move |out_ty_of_f_165285: crate::lower::model::OutTy| {
                            let t_p1j = out_ty_of_f_165285;
                            crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p5.clone(), benv_p1x.clone(), e_p4x.clone()), move |value_of_f_165380: crate::lower::types::Vl| crate::prelude::call_then(start_bind_pattern_result_f(wx_p0x.clone(), menv_p2x.clone(), p_p3x.clone(), crate::lower::types::own_f(&value_of_f_165380), t_p1j.clone(), crate::lower::types::peel_f(&crate::lower::type_at_f(&lx_p5, &e_p4x.span_p))), move |bind_pattern_result_f_165343: crate::lower::node_::Wx| ::prism_rtl::Turn::Finished((bind_pattern_result_f_165343, benv_p1x.clone()))))
                        })
                    } else {
                        crate::prelude::call_then(start_binder_names_f(p_p3x.clone()), move |binder_names_f_165556: crate::prelude::Array<crate::syntax::SName>| if crate::prelude::fold(&binder_names_f_165556, &true, &(|ok_p1k: &bool, n_p1l: &crate::syntax::SName| *ok_p1k && ((is_plain_part_f(&crate::prelude::get(&menv_p2x.names_p, &crate::check::env::sname_key_f(n_p1l))) || is_getter_part_f(&crate::prelude::get(&menv_p2x.names_p, &crate::check::env::sname_key_f(n_p1l)))) || is_event_part_f(&crate::prelude::get(&menv_p2x.names_p, &crate::check::env::sname_key_f(n_p1l)))))) {
                            ::prism_rtl::Turn::Finished((let_pattern_dynamics_f(&wx_p0x, &benv_p1x, &menv_p2x, &p_p3x, &e_p4x), benv_p1x.clone()))
                        } else {
                            {
                                let wx2_p1m = {
                                    let mut this: crate::lower::node_::Wx = wx_p0x.clone();
                                    this.build_p = crate::prelude::push(&this.build_p, &crate::lower::expr::internal_bug_do_f(&crate::prelude::Text::from(format!("a widget block\'s `let` of this pattern (`{}`), whose names are bound as no plain value, dynamic or event", &crate::lower::functions::src_text_f(&lx_p5, &lx_p5.file_p, &p_p3x.span_p)))));
                                    this
                                };
                                ::prism_rtl::Turn::Finished((wx2_p1m.clone(), benv_p1x.clone()))
                            }
                        })
                    })
                },
            }
        }
    }
}

/// `Start LetLine, x`: what the function value is when passed to `@Run`.
pub fn start_let_line_f(wx_p0: crate::lower::node_::Wx, benv_p1: crate::lower::types::Env, menv_p2: crate::lower::types::Env, p_p3: crate::syntax::Pattern, e_p4: crate::syntax::Expr) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env)>> {
    ::std::rc::Rc::new(LetLine { wx_p0, benv_p1, menv_p2, p_p3, e_p4 })
}

/// ```prism
/// IsGetterPart: fn ?Bn -> Bool
/// ```
pub fn is_getter_part_f(opt0: &::std::option::Option<crate::lower::types::Bn>) -> bool {
    'c: {
        if let ::std::option::Option::Some(crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(c0_0_0_0, _, _), _, _)) = opt0 && let crate::lower::model::Ex::XSelf = &**c0_0_0_0 {
            break 'c true;
        }
        if let other_o0 = opt0 {
            break 'c false;
        }
        unreachable!("no clause matched")
    }
}

/// ```prism
/// IsEventPart: fn ?Bn -> Bool
/// ```
pub fn is_event_part_f(opt0: &::std::option::Option<crate::lower::types::Bn>) -> bool {
    match opt0 {
        ::std::option::Option::Some(crate::lower::types::Bn::BnEv(_, _)) => true,
        other_o0 => false,
    }
}

/// ```prism
/// LetPatternDynamics: unbounded fn Wx, Env, Env, Pattern, Expr -> Wx
/// ```
pub fn let_pattern_dynamics_f(wx_p0: &crate::lower::node_::Wx, benv_p1: &crate::lower::types::Env, menv_p2: &crate::lower::types::Env, p_p3: &crate::syntax::Pattern, e_p4: &crate::syntax::Expr) -> crate::lower::node_::Wx {
    pattern_dynamics_f(wx_p0, benv_p1, menv_p2, menv_p2, &wx_p0.lx_p, p_p3, e_p4)
}

/// ```prism
/// PatternDynamics: unbounded fn Wx, Env, Env, Env, Lx, Pattern, Expr -> Wx
/// ```
pub fn pattern_dynamics_f(wx_p0: &crate::lower::node_::Wx, benv_p1: &crate::lower::types::Env, menv_p2: &crate::lower::types::Env, penv_p3: &crate::lower::types::Env, lxp_p4: &crate::lower::Lx, p_p5: &crate::syntax::Pattern, e_p6: &crate::syntax::Expr) -> crate::lower::node_::Wx {
    let lx_p7 = wx_p0.lx_p.clone();
    let ty_p8 = crate::lower::types::peel_f(&crate::lower::type_at_f(&lx_p7, &e_p6.span_p));
    let t_p9 = crate::lower::types::out_ty_of_f(&lx_p7, &ty_p8);
    let (whole_pe, wx1_pf) = crate::lower::node_::fresh_name_f(wx_p0, &crate::prelude::Text::lit("let_whole"));
    let (ex_pg, reads_ph) = crate::lower::node_::dynamics::dynamic_expr_f(&wx1_pf, menv_p2, e_p6);
    let wx2_pa = {
        let mut this: crate::lower::node_::Wx = wx1_pf.clone();
        this.getters_p = crate::prelude::push(&this.getters_p, &crate::lower::model::MethDef { name_p: whole_pe.clone(), recv_p: crate::lower::model::Recv::RecvRef, params_p: crate::prelude::Array::new(), cx_p: crate::lower::model::CxArg::CxRef, ret_p: t_p9.clone(), body_p: crate::prelude::Array::new(), tail_p: ex_pg.clone(), doc_p: crate::prelude::Text::from(format!("`{}`, the value a `let`\'s pattern takes apart, read at the read point.", &crate::lower::functions::src_text_f(&lx_p7, &lx_p7.file_p, &e_p6.span_p))) });
        this.dyn_reads_p = crate::prelude::insert(&this.dyn_reads_p, &whole_pe, &reads_ph);
        this
    };
    let o_pb = crate::lower::patterns::rust_pat_f(lxp_p4, p_p5, &ty_p8, &crate::lower::types::Holding::ByRef, &crate::prelude::Text::lit("let_whole_value"));
    let wx3_pc = crate::prelude::run_to_end(crate::prelude::fold_job(binder_names_f(p_p5), wx2_pa.clone(), {
        let penv_p3x = penv_p3.clone();
        let o_pbx = o_pb.clone();
        let t_p9x = t_p9.clone();
        let whole_pex = whole_pe.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::lower::node_::Wx, crate::syntax::SName)| {
            let penv_p3xy = penv_p3x.clone();
            let o_pbxy = o_pbx.clone();
            let t_p9xy = t_p9x.clone();
            let whole_pexy = whole_pex.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let w_pi = p0;
                let n_pj = p1;
                'm168272: {
                    let scrutinee = &(crate::prelude::get(&penv_p3xy.names_p, &crate::check::env::sname_key_f(&n_pj)), crate::prelude::fold(&o_pbxy.binds_p, &::std::option::Option::None, &(|found_ok: &::std::option::Option<crate::lower::types::Bn>, (k_pl, b_pm): &(crate::prelude::Text, crate::lower::types::Bn)| if k_pl == &crate::check::env::sname_key_f(&n_pj) {
                        ::std::option::Option::Some(b_pm.clone())
                    } else {
                        found_ok.clone()
                    })));
                    if let (::std::option::Option::Some(crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(m168272_0_0_0_0, rs_pn, _), _, bt_po)), ::std::option::Option::Some(crate::lower::types::Bn::BnLocal(held_pp, _, _))) = scrutinee && let crate::lower::model::Ex::XSelf = &**m168272_0_0_0_0 {
                        break 'm168272 {
                            let arm_pq = crate::lower::model::XArm { pat_p: o_pbxy.pa_p.clone(), conds_p: o_pbxy.conds_p.clone(), body_p: crate::lower::model::Ex::XMethod(::std::rc::Rc::new(held_pp.clone()), crate::prelude::Text::lit("sample"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx])) };
                            let other_pr = crate::lower::model::XArm { pat_p: crate::lower::model::Pa::PaWild, conds_p: crate::prelude::Array::new(), body_p: crate::lower::model::Ex::XUnreachable };
                            let tail_ps = crate::lower::model::Ex::XBlock(crate::prelude::Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("let_whole_value"))), t_p9xy.clone()), crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), whole_pexy.clone(), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx])))]), ::std::rc::Rc::new(crate::lower::types::own_f(&crate::lower::expr::arms_value_f(&crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("let_whole_value")))), &crate::prelude::Array::from(vec![arm_pq.clone(), other_pr.clone()]), &crate::prelude::Text::lit("\'bound"), bt_po))));
                            ::prism_rtl::Turn::Finished({
                                let mut this: crate::lower::node_::Wx = w_pi.clone();
                                this.getters_p = crate::prelude::push(&this.getters_p, &crate::lower::model::MethDef { name_p: rs_pn.clone(), recv_p: crate::lower::model::Recv::RecvRef, params_p: crate::prelude::Array::new(), cx_p: crate::lower::model::CxArg::CxRef, ret_p: bt_po.clone(), body_p: crate::prelude::Array::new(), tail_p: tail_ps.clone(), doc_p: crate::prelude::Text::from(format!("`{}`, a dynamic a `let`\'s pattern binds", &crate::check::env::sname_key_f(&n_pj))) });
                                this.dyn_reads_p = crate::prelude::insert(&this.dyn_reads_p, rs_pn, &crate::prelude::Array::from(vec![crate::lower::node_::Read::OwnRead(whole_pexy.clone())]));
                                this
                            })
                        };
                    }
                    if let (::std::option::Option::Some(crate::lower::types::Bn::BnDyn(_, _, _)), _) = scrutinee {
                        break 'm168272 ::prism_rtl::Turn::Finished({
                            let mut this: crate::lower::node_::Wx = w_pi.clone();
                            this.build_p = crate::prelude::push(&this.build_p, &crate::lower::expr::internal_bug_do_f(&crate::prelude::Text::from(format!("the dynamic `{}` of a `let`\'s pattern, which the pattern does not bind", &crate::check::env::sname_key_f(&n_pj)))));
                            this
                        });
                    }
                    if let (::std::option::Option::Some(crate::lower::types::Bn::BnEv(er_pt, _)), ::std::option::Option::Some(crate::lower::types::Bn::BnLocal(held_pu, _, _))) = scrutinee {
                        break 'm168272 {
                            let et_pv = crate::lower::node_::gn_of_f(&w_pi, &er_pt.node_p).ty_p.clone();
                            let (heard_p18, w1_p19) = crate::lower::node_::fresh_name_f(&w_pi, &crate::prelude::Text::lit("heard"));
                            let (id_p1a, w2_p1b) = crate::lower::node_::add_gn_f(&w1_p19, &heard_p18, &et_pv, &crate::lower::node_::GnKind::GnPort, &crate::prelude::Nat::from(0u32));
                            let arm_p10 = crate::lower::model::XArm { pat_p: o_pbxy.pa_p.clone(), conds_p: o_pbxy.conds_p.clone(), body_p: crate::lower::model::Ex::XClone(::std::rc::Rc::new(held_pu.clone())) };
                            let other_p11 = crate::lower::model::XArm { pat_p: crate::lower::model::Pa::PaWild, conds_p: crate::prelude::Array::new(), body_p: crate::lower::model::Ex::XUnreachable };
                            let tail_p12 = crate::lower::model::Ex::XBlock(crate::prelude::Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("let_whole_value"))), t_p9xy.clone()), crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), whole_pexy.clone(), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx])))]), ::std::rc::Rc::new(crate::lower::types::own_f(&crate::lower::expr::arms_value_f(&crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("let_whole_value")))), &crate::prelude::Array::from(vec![arm_p10.clone(), other_p11.clone()]), &crate::prelude::Text::lit("\'bound"), &crate::lower::model::OutTy::OutEvent(::std::rc::Rc::new(et_pv.clone()))))));
                            let getter_p13 = crate::lower::model::MethDef { name_p: crate::prelude::Text::from(format!("{}_event", &heard_p18)), recv_p: crate::lower::model::Recv::RecvRef, params_p: crate::prelude::Array::new(), cx_p: crate::lower::model::CxArg::CxRef, ret_p: crate::lower::model::OutTy::OutEvent(::std::rc::Rc::new(et_pv.clone())), body_p: crate::prelude::Array::new(), tail_p: tail_p12.clone(), doc_p: crate::prelude::Text::from(format!("`{}`, an event a `let`\'s pattern binds, as the value holds it.", &crate::check::env::sname_key_f(&n_pj))) };
                            let port_p14 = crate::lower::model::Ex::XClosure(false, crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("ev"))]), ::std::rc::Rc::new(crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("ev"))), crate::prelude::Text::lit("port"))))));
                            let call_p15 = crate::lower::model::Ex::XClosure(false, crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("n")), crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("v")), crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("cx"))]), ::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("n"))), heard_p18.clone(), crate::prelude::Array::from(vec![crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("v")))), crate::lower::model::Ex::XCx]))));
                            let sub_p16 = crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XCall(crate::lower::helper_ref_f(&crate::prelude::Text::lit("subscribe_row")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("node")))), crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Some")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Rc::new")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("node"))), crate::prelude::Text::from(format!("{}_event", &heard_p18)), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx]))]))])), port_p14.clone(), call_p15.clone(), crate::lower::node_::finish::heard_above_f(&heard_p18), crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("node"))), crate::prelude::Text::from(format!("{}_sub", &heard_p18)))))])));
                            let w3_p17 = {
                                let mut this: crate::lower::node_::Wx = crate::lower::node_::add_field_f(&w2_p1b, &crate::prelude::Text::from(format!("{}_sub", &heard_p18)), &crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Cell")), crate::prelude::Array::from(vec![crate::lower::model::OutTy::OutOpt(::std::rc::Rc::new(crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Handle")), crate::prelude::Array::new())))])), &crate::prelude::Text::from(format!("the subscription to `{}` as the `let`\'s value holds it", &crate::check::env::sname_key_f(&n_pj))), &crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Cell::new")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XNone])));
                                this.getters_p = crate::prelude::push(&this.getters_p, &getter_p13);
                                this.build_p = crate::prelude::push(&this.build_p, &sub_p16);
                                this
                            };
                            ::prism_rtl::Turn::Finished(crate::lower::node_::connect_f(&w3_p17, &crate::lower::node_::ev_ref_of_f(&w3_p17, &id_p1a), &crate::lower::node_::Sk::SkNode(er_pt.node_p.clone())))
                        };
                    }
                    if let (::std::option::Option::Some(crate::lower::types::Bn::BnEv(_, _)), _) = scrutinee {
                        break 'm168272 ::prism_rtl::Turn::Finished({
                            let mut this: crate::lower::node_::Wx = w_pi.clone();
                            this.build_p = crate::prelude::push(&this.build_p, &crate::lower::expr::internal_bug_do_f(&crate::prelude::Text::from(format!("the event `{}` of a `let`\'s pattern, which the pattern does not bind", &crate::check::env::sname_key_f(&n_pj)))));
                            this
                        });
                    }
                    if let (::std::option::Option::Some(crate::lower::types::Bn::BnParts(ms_p1c)), ::std::option::Option::Some(crate::lower::types::Bn::BnLocal(held_p1d, _, _))) = scrutinee {
                        break 'm168272 ::prism_rtl::Turn::Finished(bundle_binder_parts_f(&w_pi, &o_pbxy, &whole_pexy, &t_p9xy, &crate::check::env::sname_key_f(&n_pj), ms_p1c, held_p1d));
                    }
                    ::prism_rtl::Turn::Finished(w_pi.clone())
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::node_::Wx, crate::syntax::SName)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::node_::Wx>>>
    }));
    let plain_pd = crate::prelude::run_to_end(crate::prelude::fold_job(binder_names_f(p_p5), crate::prelude::Array::new(), {
        let penv_p3x = penv_p3.clone();
        let o_pbx = o_pb.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<(crate::prelude::Text, crate::lower::model::OutTy, crate::lower::model::Ex)>, crate::syntax::SName)| {
            let penv_p3xy = penv_p3x.clone();
            let o_pbxy = o_pbx.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_p1e = p0;
                let n_p1f = p1;
                match (crate::prelude::get(&penv_p3xy.names_p, &crate::check::env::sname_key_f(&n_p1f)), crate::prelude::fold(&o_pbxy.binds_p, &::std::option::Option::None, &(|found_o1g: &::std::option::Option<crate::lower::types::Bn>, (k_p1h, b_p1i): &(crate::prelude::Text, crate::lower::types::Bn)| if k_p1h == &crate::check::env::sname_key_f(&n_p1f) {
                    ::std::option::Option::Some(b_p1i.clone())
                } else {
                    found_o1g.clone()
                }))) {
                    (::std::option::Option::Some(crate::lower::types::Bn::BnLocal(rx_p1j, _, bt_p1k)), ::std::option::Option::Some(crate::lower::types::Bn::BnLocal(rs_p1l, mode_p1m, vt_p1n))) => ::prism_rtl::Turn::Finished(crate::prelude::push(&acc_p1e, &(crate::lower::types::place_stem_f(&rx_p1j), bt_p1k.clone(), crate::lower::types::own_f(&crate::lower::types::Vl::VlPlace(rs_p1l.clone(), mode_p1m.clone(), vt_p1n.clone()))))),
                    (::std::option::Option::Some(crate::lower::types::Bn::BnParts(ms_p1o)), ::std::option::Option::Some(crate::lower::types::Bn::BnLocal(rs_p1p, _, _))) => ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_p1e, &bundle_binder_plains_f(&ms_p1o, &rs_p1p))),
                    _ => ::prism_rtl::Turn::Finished(acc_p1e.clone()),
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<(crate::prelude::Text, crate::lower::model::OutTy, crate::lower::model::Ex)>, crate::syntax::SName)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<(crate::prelude::Text, crate::lower::model::OutTy, crate::lower::model::Ex)>>>>
    }));
    if &crate::prelude::len(&plain_pd) == &crate::prelude::Nat::from(0u32) {
        wx3_pc.clone()
    } else {
        {
            let (tmp_p1v, wx4_p20) = crate::lower::node_::fresh_name_f(&wx3_pc, &crate::prelude::Text::lit("result"));
            let ob_p1q = crate::lower::patterns::rust_pat_f(lxp_p4, p_p5, &ty_p8, &crate::lower::types::Holding::ByRef, &tmp_p1v);
            let all_p1r = crate::lower::model::OutTy::OutTuple(crate::prelude::each(&plain_pd, &(|(_, bt_p21, _): &(crate::prelude::Text, crate::lower::model::OutTy, crate::lower::model::Ex)| bt_p21.clone())));
            let arm_p1s = crate::lower::model::XArm { pat_p: ob_p1q.pa_p.clone(), conds_p: ob_p1q.conds_p.clone(), body_p: crate::lower::model::Ex::XTuple(crate::prelude::each(&plain_pd, &(|(_, _, v_p22): &(crate::prelude::Text, crate::lower::model::OutTy, crate::lower::model::Ex)| v_p22.clone()))) };
            let other_p1t = crate::lower::model::XArm { pat_p: crate::lower::model::Pa::PaWild, conds_p: crate::prelude::Array::new(), body_p: crate::lower::model::Ex::XUnreachable };
            let matched_p1u = crate::lower::types::own_f(&crate::lower::expr::arms_value_f(&crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XVar(tmp_p1v.clone()))), &crate::prelude::Array::from(vec![arm_p1s.clone(), other_p1t.clone()]), &crate::prelude::Text::lit("\'bound"), &all_p1r));
            {
                let mut this: crate::lower::node_::Wx = wx4_p20.clone();
                this.lets_p = crate::prelude::append(&this.lets_p, &crate::prelude::Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaBind(tmp_p1v.clone())), t_p9.clone()), crate::lower::types::own_f(&crate::lower::expr::value_of_f(&lx_p7, benv_p1, e_p6))), crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaTuple(crate::prelude::each(&plain_pd, &(|(f_p23, _, _): &(crate::prelude::Text, crate::lower::model::OutTy, crate::lower::model::Ex)| crate::lower::model::Pa::PaBind(f_p23.clone()))))), all_p1r.clone()), matched_p1u.clone())]));
                this.fields_p = crate::prelude::append(&this.fields_p, &crate::prelude::each(&plain_pd, &(|(f_p24, bt_p25, _): &(crate::prelude::Text, crate::lower::model::OutTy, crate::lower::model::Ex)| (f_p24.clone(), bt_p25.clone(), crate::prelude::Text::lit("a name of a `let`\'s pattern")))));
                this.inits_p = crate::prelude::append(&this.inits_p, &crate::prelude::each(&plain_pd, &(|(f_p26, _, _): &(crate::prelude::Text, crate::lower::model::OutTy, crate::lower::model::Ex)| (f_p26.clone(), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(f_p26.clone())))))));
                this
            }
        }
    }
}

/// ```prism
/// PreBindBundleBinder: unbounded fn Wx, Text, [Ty] -> ((Wx, [?Bn], [?Bn]))
/// ```
pub fn pre_bind_bundle_binder_f(wx_p0: &crate::lower::node_::Wx, stem_p1: &crate::prelude::Text, tys_p2: &crate::prelude::Array<crate::check::types::Ty>) -> (crate::lower::node_::Wx, crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>, crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>) {
    crate::prelude::run_to_end(crate::prelude::fold_job(tys_p2.clone(), (wx_p0.clone(), crate::prelude::Array::new(), crate::prelude::Array::new()), {
        let stem_p1x = stem_p1.clone();
        ::std::rc::Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>, crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>), crate::check::types::Ty)| {
            let stem_p1xy = stem_p1x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (w_p3, builds_p4, methods_p5) = p0;
                let ty_p6 = p1;
                {
                    let lx_p7 = w_p3.lx_p.clone();
                    let i_p8 = crate::prelude::len(&builds_p4);
                    crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p7.clone(), crate::lower::types::peel_f(&ty_p6)), move |out_ty_of_f_174222: crate::lower::model::OutTy| {
                        let t_p9 = out_ty_of_f_174222;
                        if crate::lower::types::is_bundle_f(&ty_p6) {
                            {
                                let (w2_pa, bs_pb, ms_pc) = pre_bind_bundle_binder_f(&w_p3, &crate::prelude::Text::from(format!("{}_{}", &stem_p1xy, &i_p8)), &crate::lower::node_::keyed::bundle_part_tys_f(&ty_p6));
                                ::prism_rtl::Turn::Finished((w2_pa.clone(), crate::prelude::append(&builds_p4, &crate::prelude::Array::from(vec![::std::option::Option::Some(crate::lower::types::Bn::BnParts(bs_pb.clone()))])), crate::prelude::append(&methods_p5, &crate::prelude::Array::from(vec![::std::option::Option::Some(crate::lower::types::Bn::BnParts(ms_pc.clone()))]))))
                            }
                        } else {
                            match crate::lower::types::layer_of_f(&ty_p6) {
                                crate::lower::types::Layer::LyEv => {
                                    let (rs_pe, w1_pf) = crate::lower::node_::fresh_name_f(&w_p3, &crate::prelude::Text::from(format!("{}_part{}", &stem_p1xy, &i_p8)));
                                    crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p7.clone(), crate::lower::types::peel_f(&crate::lower::types::peel_f(&ty_p6))), move |out_ty_of_f_174588: crate::lower::model::OutTy| {
                                        let (id_pg, w2_ph) = crate::lower::node_::add_gn_f(&w1_pf, &rs_pe, &out_ty_of_f_174588, &crate::lower::node_::GnKind::GnNamed, &crate::prelude::Nat::from(0u32));
                                        let b_pd = crate::lower::types::Bn::BnEv(crate::lower::node_::ev_ref_of_f(&w2_ph, &id_pg), t_p9.clone());
                                        ::prism_rtl::Turn::Finished((w2_ph.clone(), crate::prelude::append(&builds_p4, &crate::prelude::Array::from(vec![::std::option::Option::Some(b_pd.clone())])), crate::prelude::append(&methods_p5, &crate::prelude::Array::from(vec![::std::option::Option::Some(b_pd.clone())]))))
                                    })
                                },
                                crate::lower::types::Layer::LyDyn => {
                                    let (rs_pj, w1_pk) = crate::lower::node_::fresh_name_f(&w_p3, &crate::prelude::Text::from(format!("{}_part{}", &stem_p1xy, &i_p8)));
                                    let b_pi = crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), rs_pj.clone(), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx])), crate::prelude::Array::from(vec![crate::lower::node_::Read::OwnRead(rs_pj.clone())]), t_p9.clone());
                                    ::prism_rtl::Turn::Finished((w1_pk.clone(), crate::prelude::append(&builds_p4, &crate::prelude::Array::from(vec![::std::option::Option::Some(b_pi.clone())])), crate::prelude::append(&methods_p5, &crate::prelude::Array::from(vec![::std::option::Option::Some(b_pi.clone())]))))
                                },
                                _ => {
                                    let (rs_pl, w1_pm) = crate::lower::node_::fresh_name_f(&w_p3, &crate::prelude::Text::from(format!("{}_part{}", &stem_p1xy, &i_p8)));
                                    ::prism_rtl::Turn::Finished((w1_pm.clone(), crate::prelude::append(&builds_p4, &crate::prelude::Array::from(vec![::std::option::Option::Some(crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(rs_pl.clone()), crate::lower::types::Holding::Owned, t_p9.clone()))])), crate::prelude::append(&methods_p5, &crate::prelude::Array::from(vec![::std::option::Option::Some(crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), rs_pl.clone()), crate::lower::types::Holding::Owned, t_p9.clone()))]))))
                                },
                            }
                        }
                    })
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::lower::node_::Wx, crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>, crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>), crate::check::types::Ty)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>, crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>)>>>
    }))
}

/// ```prism
/// BundleBinderParts: unbounded fn Wx, PatOut, Text, OutTy, Text, [?Bn], Ex -> Wx
/// ```
pub fn bundle_binder_parts_f(wx_p0: &crate::lower::node_::Wx, o_p1: &crate::lower::patterns::PatOut, whole_p2: &crate::prelude::Text, t_p3: &crate::lower::model::OutTy, nkey_p4: &crate::prelude::Text, parts_p5: &crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>, held_p6: &crate::lower::model::Ex) -> crate::lower::node_::Wx {
    crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(parts_p5)), wx_p0.clone(), {
        let parts_p5x = parts_p5.clone();
        let o_p1x = o_p1.clone();
        let held_p6x = held_p6.clone();
        let t_p3x = t_p3.clone();
        let whole_p2x = whole_p2.clone();
        let nkey_p4x = nkey_p4.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::lower::node_::Wx, crate::prelude::Nat)| {
            let parts_p5xy = parts_p5x.clone();
            let o_p1xy = o_p1x.clone();
            let held_p6xy = held_p6x.clone();
            let t_p3xy = t_p3x.clone();
            let whole_p2xy = whole_p2x.clone();
            let nkey_p4xy = nkey_p4x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let w_p7 = p0;
                let i_p8 = p1;
                'm175772: {
                    let scrutinee = &part_of_o(&parts_p5xy, &i_p8);
                    if let ::std::option::Option::Some(crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(m175772_0_0_0, rs_p9, _), _, bt_pa)) = scrutinee && let crate::lower::model::Ex::XSelf = &**m175772_0_0_0 {
                        break 'm175772 {
                            let arm_pb = crate::lower::model::XArm { pat_p: o_p1xy.pa_p.clone(), conds_p: o_p1xy.conds_p.clone(), body_p: crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XPart(::std::rc::Rc::new(held_p6xy.clone()), i_p8.clone())), crate::prelude::Text::lit("sample"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx])) };
                            let other_pc = crate::lower::model::XArm { pat_p: crate::lower::model::Pa::PaWild, conds_p: crate::prelude::Array::new(), body_p: crate::lower::model::Ex::XUnreachable };
                            let tail_pd = crate::lower::model::Ex::XBlock(crate::prelude::Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("let_whole_value"))), t_p3xy.clone()), crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), whole_p2xy.clone(), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx])))]), ::std::rc::Rc::new(crate::lower::types::own_f(&crate::lower::expr::arms_value_f(&crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("let_whole_value")))), &crate::prelude::Array::from(vec![arm_pb.clone(), other_pc.clone()]), &crate::prelude::Text::lit("\'bound"), bt_pa))));
                            ::prism_rtl::Turn::Finished({
                                let mut this: crate::lower::node_::Wx = w_p7.clone();
                                this.getters_p = crate::prelude::push(&this.getters_p, &crate::lower::model::MethDef { name_p: rs_p9.clone(), recv_p: crate::lower::model::Recv::RecvRef, params_p: crate::prelude::Array::new(), cx_p: crate::lower::model::CxArg::CxRef, ret_p: bt_pa.clone(), body_p: crate::prelude::Array::new(), tail_p: tail_pd.clone(), doc_p: crate::prelude::Text::from(format!("part {} of the bundle `{}`, a dynamic, which a pattern names inside a value", &i_p8, &nkey_p4xy)) });
                                this.dyn_reads_p = crate::prelude::insert(&this.dyn_reads_p, rs_p9, &crate::prelude::Array::from(vec![crate::lower::node_::Read::OwnRead(whole_p2xy.clone())]));
                                this
                            })
                        };
                    }
                    if let ::std::option::Option::Some(crate::lower::types::Bn::BnEv(er_pe, _)) = scrutinee {
                        break 'm175772 {
                            let et_pf = crate::lower::node_::gn_of_f(&w_p7, &er_pe.node_p).ty_p.clone();
                            let (heard_po, w1_pp) = crate::lower::node_::fresh_name_f(&w_p7, &crate::prelude::Text::lit("heard"));
                            let (id_pq, w2_pr) = crate::lower::node_::add_gn_f(&w1_pp, &heard_po, &et_pf, &crate::lower::node_::GnKind::GnPort, &crate::prelude::Nat::from(0u32));
                            let arm_pg = crate::lower::model::XArm { pat_p: o_p1xy.pa_p.clone(), conds_p: o_p1xy.conds_p.clone(), body_p: crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XPart(::std::rc::Rc::new(held_p6xy.clone()), i_p8.clone()))) };
                            let other_ph = crate::lower::model::XArm { pat_p: crate::lower::model::Pa::PaWild, conds_p: crate::prelude::Array::new(), body_p: crate::lower::model::Ex::XUnreachable };
                            let tail_pi = crate::lower::model::Ex::XBlock(crate::prelude::Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("let_whole_value"))), t_p3xy.clone()), crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), whole_p2xy.clone(), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx])))]), ::std::rc::Rc::new(crate::lower::types::own_f(&crate::lower::expr::arms_value_f(&crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("let_whole_value")))), &crate::prelude::Array::from(vec![arm_pg.clone(), other_ph.clone()]), &crate::prelude::Text::lit("\'bound"), &crate::lower::model::OutTy::OutEvent(::std::rc::Rc::new(et_pf.clone()))))));
                            let getter_pj = crate::lower::model::MethDef { name_p: crate::prelude::Text::from(format!("{}_event", &heard_po)), recv_p: crate::lower::model::Recv::RecvRef, params_p: crate::prelude::Array::new(), cx_p: crate::lower::model::CxArg::CxRef, ret_p: crate::lower::model::OutTy::OutEvent(::std::rc::Rc::new(et_pf.clone())), body_p: crate::prelude::Array::new(), tail_p: tail_pi.clone(), doc_p: crate::prelude::Text::from(format!("part {} of the bundle `{}`, an event, as the value a pattern names it in holds it.", &i_p8, &nkey_p4xy)) };
                            let port_pk = crate::lower::model::Ex::XClosure(false, crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("ev"))]), ::std::rc::Rc::new(crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("ev"))), crate::prelude::Text::lit("port"))))));
                            let call_pl = crate::lower::model::Ex::XClosure(false, crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("n")), crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("v")), crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("cx"))]), ::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("n"))), heard_po.clone(), crate::prelude::Array::from(vec![crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("v")))), crate::lower::model::Ex::XCx]))));
                            let sub_pm = crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XCall(crate::lower::helper_ref_f(&crate::prelude::Text::lit("subscribe_row")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("node")))), crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Some")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Rc::new")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("node"))), crate::prelude::Text::from(format!("{}_event", &heard_po)), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx]))]))])), port_pk.clone(), call_pl.clone(), crate::lower::node_::finish::heard_above_f(&heard_po), crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("node"))), crate::prelude::Text::from(format!("{}_sub", &heard_po)))))])));
                            let w3_pn = {
                                let mut this: crate::lower::node_::Wx = crate::lower::node_::add_field_f(&w2_pr, &crate::prelude::Text::from(format!("{}_sub", &heard_po)), &crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Cell")), crate::prelude::Array::from(vec![crate::lower::model::OutTy::OutOpt(::std::rc::Rc::new(crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Handle")), crate::prelude::Array::new())))])), &crate::prelude::Text::from(format!("the subscription to part {} of the bundle `{}` as the value holds it", &i_p8, &nkey_p4xy)), &crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Cell::new")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XNone])));
                                this.getters_p = crate::prelude::push(&this.getters_p, &getter_pj);
                                this.build_p = crate::prelude::push(&this.build_p, &sub_pm);
                                this
                            };
                            ::prism_rtl::Turn::Finished(crate::lower::node_::connect_f(&w3_pn, &crate::lower::node_::ev_ref_of_f(&w3_pn, &id_pq), &crate::lower::node_::Sk::SkNode(er_pe.node_p.clone())))
                        };
                    }
                    if let ::std::option::Option::Some(crate::lower::types::Bn::BnParts(inner_ps)) = scrutinee {
                        break 'm175772 ::prism_rtl::Turn::Finished(bundle_binder_parts_f(&w_p7, &o_p1xy, &whole_p2xy, &t_p3xy, &nkey_p4xy, inner_ps, &crate::lower::model::Ex::XPart(::std::rc::Rc::new(held_p6xy.clone()), i_p8.clone())));
                    }
                    ::prism_rtl::Turn::Finished(w_p7.clone())
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::node_::Wx, crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::node_::Wx>>>
    }))
}

/// ```prism
/// BundleBinderPlains: unbounded fn [?Bn], Ex -> [((Text, OutTy, Ex))]
/// ```
pub fn bundle_binder_plains_f(parts_p0: &crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>, held_p1: &crate::lower::model::Ex) -> crate::prelude::Array<(crate::prelude::Text, crate::lower::model::OutTy, crate::lower::model::Ex)> {
    crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(parts_p0)), crate::prelude::Array::new(), {
        let parts_p0x = parts_p0.clone();
        let held_p1x = held_p1.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<(crate::prelude::Text, crate::lower::model::OutTy, crate::lower::model::Ex)>, crate::prelude::Nat)| {
            let parts_p0xy = parts_p0x.clone();
            let held_p1xy = held_p1x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_p2 = p0;
                let i_p3 = p1;
                match part_of_o(&parts_p0xy, &i_p3) {
                    ::std::option::Option::Some(crate::lower::types::Bn::BnLocal(rx_p4, _, bt_p5)) => ::prism_rtl::Turn::Finished(crate::prelude::push(&acc_p2, &(crate::lower::types::place_stem_f(&rx_p4), bt_p5.clone(), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XPart(::std::rc::Rc::new(held_p1xy.clone()), i_p3.clone())))))),
                    ::std::option::Option::Some(crate::lower::types::Bn::BnParts(inner_p6)) => ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_p2, &bundle_binder_plains_f(&inner_p6, &crate::lower::model::Ex::XPart(::std::rc::Rc::new(held_p1xy.clone()), i_p3.clone())))),
                    _ => ::prism_rtl::Turn::Finished(acc_p2.clone()),
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<(crate::prelude::Text, crate::lower::model::OutTy, crate::lower::model::Ex)>, crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<(crate::prelude::Text, crate::lower::model::OutTy, crate::lower::model::Ex)>>>>
    }))
}

/// ```prism
/// IsPlainPart: fn ?Bn -> Bool
/// ```
pub fn is_plain_part_f(opt0: &::std::option::Option<crate::lower::types::Bn>) -> bool {
    match opt0 {
        ::std::option::Option::Some(crate::lower::types::Bn::BnLocal(_, _, _)) => true,
        ::std::option::Option::None => true,
        other_o0 => false,
    }
}

/// ```prism
/// WidgetLetField: fn Wx, Text, OutTy, Ex, Text -> Wx
/// ```
pub fn widget_let_field_f(wx_p0: &crate::lower::node_::Wx, f_p1: &crate::prelude::Text, t_p2: &crate::lower::model::OutTy, v_p3: &crate::lower::model::Ex, doc_p4: &crate::prelude::Text) -> crate::lower::node_::Wx {
    let mut this: crate::lower::node_::Wx = wx_p0.clone();
    this.lets_p = crate::prelude::push(&this.lets_p, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(f_p1.clone()), v_p3.clone()));
    this.fields_p = crate::prelude::push(&this.fields_p, &(f_p1.clone(), t_p2.clone(), doc_p4.clone()));
    this.inits_p = crate::prelude::push(&this.inits_p, &(f_p1.clone(), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(f_p1.clone())))));
    this
}

/// ```prism
/// ErrPipe: fn EvRef -> EvRef
/// ```
pub fn err_pipe_f(r_p0: &crate::lower::node_::EvRef) -> crate::lower::node_::EvRef {
    crate::lower::node_::EvRef { node_p: r_p0.node_p.clone(), owner_p: r_p0.owner_p.clone(), pipe_f: {
        let r_p0x = r_p0.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::lower::model::Ex, ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::Ex) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::lower::model::Do>>>>)| {
            let r_p0xy = r_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let x_p1 = p0;
                let k_f2 = p1;
                (&r_p0xy.pipe_f)((x_p1.clone(), {
                    let k_f2x = k_f2.clone();
                    ::std::rc::Rc::new(move |p0: crate::lower::model::Ex| {
                        let k_f2xy = k_f2x.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let y_p3 = p0;
                            (&k_f2xy)(crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Err")), crate::prelude::Array::from(vec![y_p3.clone()]))).cycle()
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::Ex) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::lower::model::Do>>>>
                })).cycle()
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::model::Ex, ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::Ex) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::lower::model::Do>>>>)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::lower::model::Do>>>>
    } }
}

/// ```prism
/// OwnAs: fn OutTy, Vl -> Ex
/// ```
pub fn own_as_f(t_p0: &crate::lower::model::OutTy, v_p1: &crate::lower::types::Vl) -> crate::lower::model::Ex {
    match t_p0 {
        crate::lower::model::OutTy::OutRes(_) => if &crate::lower::types::value_ty_f(v_p1) == &crate::lower::model::OutTy::OutError {
            crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Err")), crate::prelude::Array::from(vec![crate::lower::types::own_f(v_p1)]))
        } else {
            crate::lower::types::own_f(v_p1)
        },
        _ => crate::lower::types::own_f(v_p1),
    }
}

/// ```prism
/// BindRes: fn Wx, Env, Pattern, Wres -> Wx
/// ```
pub fn bind_res_f(wx2_p0: &crate::lower::node_::Wx, menv_p1: &crate::lower::types::Env, p_p2: &crate::syntax::Pattern, res_p3: &crate::lower::node_::Wres) -> crate::lower::node_::Wx {
    match binding_of_o(menv_p1, p_p2) {
        ::std::option::Option::Some(crate::lower::types::Bn::BnEv(er_p4, _)) => match res_p3 {
            crate::lower::node_::Wres::WrEv(r_p5) => if &er_p4.owner_p != &wx2_p0.node_p {
                crate::lower::node_::crossed_f(wx2_p0, &crate::prelude::Text::from(format!("the bound event of node `{}` (its graph node {})", &er_p4.owner_p, &er_p4.node_p)))
            } else {
                if &r_p5.node_p == &er_p4.node_p {
                    wx2_p0.clone()
                } else {
                    crate::lower::node_::connect_f(wx2_p0, r_p5, &crate::lower::node_::Sk::SkNode(er_p4.node_p.clone()))
                }
            },
            _ => wx2_p0.clone(),
        },
        _ => wx2_p0.clone(),
    }
}

/// ```prism
/// BuildLine: unbounded fn Wx, Env, Env, Expr, ?Bn -> ((Wx, Wres))
/// ```
pub fn build_line_f(wx_p0: &crate::lower::node_::Wx, benv_p1: &crate::lower::types::Env, menv_p2: &crate::lower::types::Env, e_p3: &crate::syntax::Expr, bound_o4: &::std::option::Option<crate::lower::types::Bn>) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    if is_late_taker_f(&wx_p0.lx_p, menv_p2, e_p3) {
        deferred_line_f(wx_p0, menv_p2, e_p3, &false)
    } else {
        build_line_now_f(wx_p0, benv_p1, menv_p2, e_p3, bound_o4)
    }
}

/// The step machine of `BuildLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BuildLine: unbounded fn Wx, Env, Env, Expr, ?Bn -> ((Wx, Wres))
/// ```
pub struct BuildLine {
    pub wx_p0: crate::lower::node_::Wx,
    pub benv_p1: crate::lower::types::Env,
    pub menv_p2: crate::lower::types::Env,
    pub e_p3: crate::syntax::Expr,
    pub bound_o4: ::std::option::Option<crate::lower::types::Bn>,
}

impl ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::node_::Wres)> for BuildLine {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::lower::node_::Wx, crate::lower::node_::Wres)> {
        let wx_p0 = &self.wx_p0;
        let benv_p1 = &self.benv_p1;
        let menv_p2 = &self.menv_p2;
        let e_p3 = &self.e_p3;
        let bound_o4 = &self.bound_o4;
        let bound_o4x = bound_o4.clone();
        let benv_p1x = benv_p1.clone();
        let e_p3x = e_p3.clone();
        let menv_p2x = menv_p2.clone();
        let wx_p0x = wx_p0.clone();
        crate::prelude::call_then(start_is_late_taker_f(wx_p0x.lx_p.clone(), menv_p2x.clone(), e_p3x.clone()), move |is_late_taker_f_180677: bool| if is_late_taker_f_180677 {
            ::prism_rtl::Turn::More(::std::rc::Rc::new(DeferredLine { wx_p0: wx_p0x.clone(), menv_p1: menv_p2x.clone(), e_p2: e_p3x.clone(), named_p3: false }))
        } else {
            ::prism_rtl::Turn::More(::std::rc::Rc::new(BuildLineNow { wx_p0: wx_p0x.clone(), benv_p1: benv_p1x.clone(), menv_p2: menv_p2x.clone(), e_p3: e_p3x.clone(), bound_o4: bound_o4x.clone() }))
        })
    }
}

/// `Start BuildLine, x`: what the function value is when passed to `@Run`.
pub fn start_build_line_f(wx_p0: crate::lower::node_::Wx, benv_p1: crate::lower::types::Env, menv_p2: crate::lower::types::Env, e_p3: crate::syntax::Expr, bound_o4: ::std::option::Option<crate::lower::types::Bn>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::node_::Wres)>> {
    ::std::rc::Rc::new(BuildLine { wx_p0, benv_p1, menv_p2, e_p3, bound_o4 })
}

/// ```prism
/// IsLateTaker: unbounded fn Lx, Env, Expr -> Bool
/// ```
pub fn is_late_taker_f(lx_p0: &crate::lower::Lx, menv_p1: &crate::lower::types::Env, e_p2: &crate::syntax::Expr) -> bool {
    match &*e_p2.kind_p {
        crate::syntax::ExprKind::EGroup(_) => false,
        _ => match crate::lower::types::peel_f(&crate::lower::type_at_f(lx_p0, &e_p2.span_p)) {
            crate::check::types::Ty::TyElem(_, _) => false,
            _ => reads_late_f(menv_p1, e_p2),
        },
    }
}

/// The step machine of `IsLateTaker`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// IsLateTaker: unbounded fn Lx, Env, Expr -> Bool
/// ```
pub struct IsLateTaker {
    pub lx_p0: crate::lower::Lx,
    pub menv_p1: crate::lower::types::Env,
    pub e_p2: crate::syntax::Expr,
}

impl ::prism_rtl::Job<bool> for IsLateTaker {
    fn cycle(&self) -> ::prism_rtl::Turn<bool> {
        let lx_p0 = &self.lx_p0;
        let menv_p1 = &self.menv_p1;
        let e_p2 = &self.e_p2;
        match &*e_p2.kind_p {
            crate::syntax::ExprKind::EGroup(_) => ::prism_rtl::Turn::Finished(false),
            _ => match crate::lower::types::peel_f(&crate::lower::type_at_f(lx_p0, &e_p2.span_p)) {
                crate::check::types::Ty::TyElem(_, _) => ::prism_rtl::Turn::Finished(false),
                _ => ::prism_rtl::Turn::More(::std::rc::Rc::new(ReadsLate { env_p0: menv_p1.clone(), e_p1: e_p2.clone() })),
            },
        }
    }
}

/// `Start IsLateTaker, x`: what the function value is when passed to `@Run`.
pub fn start_is_late_taker_f(lx_p0: crate::lower::Lx, menv_p1: crate::lower::types::Env, e_p2: crate::syntax::Expr) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>> {
    ::std::rc::Rc::new(IsLateTaker { lx_p0, menv_p1, e_p2 })
}

/// ```prism
/// DeferredLine: unbounded fn Wx, Env, Expr, Bool -> ((Wx, Wres))
/// ```
pub fn deferred_line_f(wx_p0: &crate::lower::node_::Wx, menv_p1: &crate::lower::types::Env, e_p2: &crate::syntax::Expr, named_p3: &bool) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    let lx_p4 = wx_p0.lx_p.clone();
    let (out_ty_p6, layer_p7) = line_result_f(&lx_p4, e_p2);
    let body_p5 = crate::syntax::Block { stmts_p: crate::prelude::Array::from(vec![crate::syntax::Stmt { kind_p: crate::syntax::StmtKind::SExpr(e_p2.clone()), span_p: e_p2.span_p.clone() }]), inline_p: true, span_p: e_p2.span_p.clone() };
    let (wx2_p8, res_p9) = crate::lower::node_::switch_::building_choice_line_f(wx_p0, menv_p1, &crate::lower::model::Ex::XUnit, &crate::prelude::Array::from(vec![::std::option::Option::None]), &crate::check::types::Ty::TyCon(crate::prelude::Text::lit("unit"), crate::prelude::Array::new()), &crate::prelude::Array::from(vec![::std::option::Option::None]), &crate::prelude::Array::from(vec![body_p5.clone()]), &out_ty_p6, &layer_p7, &line_out_full_f(&lx_p4, e_p2), &crate::prelude::Array::new());
    match crate::prelude::index(&wx2_p8.gens_p, &crate::syntax::lexer::chars::dec_f(&crate::prelude::len(&wx2_p8.gens_p))) {
        ::std::option::Option::Some(gd_pa) => if reads_late_of_places_f(menv_p1, menv_p1, e_p2) {
            (wx2_p8.clone(), res_p9.clone())
        } else {
            {
                let wx3_pb = {
                    let mut this: crate::lower::node_::Wx = wx2_p8.clone();
                    this.deferred_gens_p = crate::prelude::push(&this.deferred_gens_p, &gd_pa.name_p);
                    this
                };
                let wx4_pc = if !gd_pa.gappy_p {
                    wx3_pb.clone()
                } else {
                    {
                        let mut this: crate::lower::node_::Wx = wx3_pb.clone();
                        this.build_p = crate::prelude::push(&this.build_p, &crate::lower::expr::refusal_do_f(&crate::prelude::Text::from(format!("`{}`, a line that takes a late result at its build, above the line that gives it, and whose places are counted as they are built (a building `match` or `if` inside it)", &crate::lower::functions::src_text_f(&lx_p4, &lx_p4.file_p, &e_p2.span_p)))));
                        this
                    }
                };
                match &res_p9 {
                    crate::lower::node_::Wres::WrLate(_, _) if !*named_p3 => ({
                        let mut this: crate::lower::node_::Wx = wx4_pc.clone();
                        this.build_p = crate::prelude::push(&this.build_p, &crate::lower::expr::refusal_do_f(&crate::prelude::Text::from(format!("`{}`, a line that takes a late result at its build, above the line that gives it, and gives a plain result of its own that no name binds (a pattern\'s, or the block\'s own result)", &crate::lower::functions::src_text_f(&lx_p4, &lx_p4.file_p, &e_p2.span_p)))));
                        this
                    }, crate::lower::node_::Wres::WrUnit),
                    _ => (wx4_pc.clone(), res_p9.clone()),
                    _ => unreachable!("no arm matched"),
                }
            }
        },
        ::std::option::Option::None => ({
            let mut this: crate::lower::node_::Wx = wx2_p8.clone();
            this.build_p = crate::prelude::push(&this.build_p, &crate::lower::expr::internal_bug_do_f(&crate::prelude::Text::lit("a line that takes a late result, lowered to no generation")));
            this
        }, crate::lower::node_::Wres::WrUnit),
    }
}

/// The step machine of `DeferredLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// DeferredLine: unbounded fn Wx, Env, Expr, Bool -> ((Wx, Wres))
/// ```
pub struct DeferredLine {
    pub wx_p0: crate::lower::node_::Wx,
    pub menv_p1: crate::lower::types::Env,
    pub e_p2: crate::syntax::Expr,
    pub named_p3: bool,
}

impl ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::node_::Wres)> for DeferredLine {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::lower::node_::Wx, crate::lower::node_::Wres)> {
        let wx_p0 = &self.wx_p0;
        let menv_p1 = &self.menv_p1;
        let e_p2 = &self.e_p2;
        let named_p3 = &self.named_p3;
        let lx_p4 = wx_p0.lx_p.clone();
        let e_p2x = e_p2.clone();
        let menv_p1x = menv_p1.clone();
        let named_p3x = *named_p3;
        let wx_p0x = wx_p0.clone();
        crate::prelude::call_then(start_line_result_f(lx_p4.clone(), e_p2x.clone()), move |line_result_f_182767: (crate::lower::model::OutTy, crate::lower::types::Layer)| {
            let (out_ty_p6, layer_p7) = line_result_f_182767;
            let body_p5 = crate::syntax::Block { stmts_p: crate::prelude::Array::from(vec![crate::syntax::Stmt { kind_p: crate::syntax::StmtKind::SExpr(e_p2x.clone()), span_p: e_p2x.span_p.clone() }]), inline_p: true, span_p: e_p2x.span_p.clone() };
            crate::prelude::call_then(crate::lower::node_::switch_::start_building_choice_line_f(wx_p0x.clone(), menv_p1x.clone(), crate::lower::model::Ex::XUnit, crate::prelude::Array::from(vec![::std::option::Option::None]), crate::check::types::Ty::TyCon(crate::prelude::Text::lit("unit"), crate::prelude::Array::new()), crate::prelude::Array::from(vec![::std::option::Option::None]), crate::prelude::Array::from(vec![body_p5.clone()]), out_ty_p6.clone(), layer_p7.clone(), line_out_full_f(&lx_p4, &e_p2x), crate::prelude::Array::new()), move |building_choice_line_f_182899: (crate::lower::node_::Wx, crate::lower::node_::Wres)| {
                let (wx2_p8, res_p9) = building_choice_line_f_182899;
                match crate::prelude::index(&wx2_p8.gens_p, &crate::syntax::lexer::chars::dec_f(&crate::prelude::len(&wx2_p8.gens_p))) {
                    ::std::option::Option::Some(gd_pa) => crate::prelude::call_then(start_reads_late_of_places_f(menv_p1x.clone(), menv_p1x.clone(), e_p2x.clone()), move |reads_late_of_places_f_183084: bool| if reads_late_of_places_f_183084 {
                        ::prism_rtl::Turn::Finished((wx2_p8.clone(), res_p9.clone()))
                    } else {
                        {
                            let wx3_pb = {
                                let mut this: crate::lower::node_::Wx = wx2_p8.clone();
                                this.deferred_gens_p = crate::prelude::push(&this.deferred_gens_p, &gd_pa.name_p);
                                this
                            };
                            let wx4_pc = if !gd_pa.gappy_p {
                                wx3_pb.clone()
                            } else {
                                {
                                    let mut this: crate::lower::node_::Wx = wx3_pb.clone();
                                    this.build_p = crate::prelude::push(&this.build_p, &crate::lower::expr::refusal_do_f(&crate::prelude::Text::from(format!("`{}`, a line that takes a late result at its build, above the line that gives it, and whose places are counted as they are built (a building `match` or `if` inside it)", &crate::lower::functions::src_text_f(&lx_p4, &lx_p4.file_p, &e_p2x.span_p)))));
                                    this
                                }
                            };
                            match &res_p9 {
                                crate::lower::node_::Wres::WrLate(_, _) if !named_p3x => ::prism_rtl::Turn::Finished(({
                                    let mut this: crate::lower::node_::Wx = wx4_pc.clone();
                                    this.build_p = crate::prelude::push(&this.build_p, &crate::lower::expr::refusal_do_f(&crate::prelude::Text::from(format!("`{}`, a line that takes a late result at its build, above the line that gives it, and gives a plain result of its own that no name binds (a pattern\'s, or the block\'s own result)", &crate::lower::functions::src_text_f(&lx_p4, &lx_p4.file_p, &e_p2x.span_p)))));
                                    this
                                }, crate::lower::node_::Wres::WrUnit)),
                                _ => ::prism_rtl::Turn::Finished((wx4_pc.clone(), res_p9.clone())),
                                _ => unreachable!("no arm matched"),
                            }
                        }
                    }),
                    ::std::option::Option::None => ::prism_rtl::Turn::Finished(({
                        let mut this: crate::lower::node_::Wx = wx2_p8.clone();
                        this.build_p = crate::prelude::push(&this.build_p, &crate::lower::expr::internal_bug_do_f(&crate::prelude::Text::lit("a line that takes a late result, lowered to no generation")));
                        this
                    }, crate::lower::node_::Wres::WrUnit)),
                }
            })
        })
    }
}

/// `Start DeferredLine, x`: what the function value is when passed to `@Run`.
pub fn start_deferred_line_f(wx_p0: crate::lower::node_::Wx, menv_p1: crate::lower::types::Env, e_p2: crate::syntax::Expr, named_p3: bool) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::node_::Wres)>> {
    ::std::rc::Rc::new(DeferredLine { wx_p0, menv_p1, e_p2, named_p3 })
}

/// ```prism
/// BuildLineNow: unbounded fn Wx, Env, Env, Expr, ?Bn -> ((Wx, Wres))
/// ```
pub fn build_line_now_f(wx_p0: &crate::lower::node_::Wx, benv_p1: &crate::lower::types::Env, menv_p2: &crate::lower::types::Env, e_p3: &crate::syntax::Expr, bound_o4: &::std::option::Option<crate::lower::types::Bn>) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    let lx_p5 = wx_p0.lx_p.clone();
    let full_p6 = crate::lower::type_at_f(&lx_p5, &e_p3.span_p);
    match &*e_p3.kind_p {
        crate::syntax::ExprKind::EGroup(x_p7) => build_line_f(wx_p0, benv_p1, menv_p2, &**x_p7, bound_o4),
        crate::syntax::ExprKind::EWidgetBlock(b_p8) => crate::lower::node_::static_::inline_block_f(wx_p0, benv_p1, menv_p2, b_p8, &lx_p5),
        crate::syntax::ExprKind::EFor(binders_o9, source_pa, body_pb) => crate::lower::node_::keyed::for_line_f(wx_p0, benv_p1, menv_p2, binders_o9, &**source_pa, body_pb, e_p3, bound_o4),
        crate::syntax::ExprKind::ERebuild(scrut_pc, body_pd) => crate::lower::node_::switch_::rebuild_line_f(wx_p0, benv_p1, menv_p2, &**scrut_pc, body_pd, e_p3, bound_o4),
        crate::syntax::ExprKind::EIf(c_pe, then_b_pf, ::std::option::Option::Some(else_b_pg)) => crate::lower::node_::switch_::if_gen_line_f(wx_p0, menv_p2, &**c_pe, then_b_pf, else_b_pg, e_p3),
        crate::syntax::ExprKind::EIf(c_ph, then_b_pi, ::std::option::Option::None) => crate::lower::node_::switch_::if_gen_line_f(wx_p0, menv_p2, &**c_ph, then_b_pi, &crate::syntax::Block { stmts_p: crate::prelude::Array::new(), inline_p: true, span_p: e_p3.span_p.clone() }, e_p3),
        crate::syntax::ExprKind::EMatch(s_pj, arms_pk) => if crate::check::types::has_text_f(&wx_p0.early_choices_p, &init_key_f(e_p3)) {
            crate::lower::node_::switch_::early_choice_line_f(wx_p0, benv_p1, menv_p2, &**s_pj, arms_pk, e_p3)
        } else {
            crate::lower::node_::switch_::match_gen_line_f(wx_p0, menv_p2, &**s_pj, arms_pk, e_p3)
        },
        _ => match crate::lower::types::peel_f(&full_p6) {
            crate::check::types::Ty::TyElem(_, _) => crate::lower::node_::elements::element_line_f(wx_p0, benv_p1, menv_p2, e_p3, bound_o4),
            crate::check::types::Ty::TyAt(_, _) => crate::lower::node_::static_::widget_line_f(wx_p0, benv_p1, menv_p2, e_p3, bound_o4),
            _ => {
                let wx2_pl = {
                    let mut this: crate::lower::node_::Wx = wx_p0.clone();
                    this.build_p = crate::prelude::push(&this.build_p, &crate::lower::expr::internal_bug_do_f(&crate::prelude::Text::lit("a building line that is no element, blueprint or builder")));
                    this
                };
                (wx2_pl.clone(), crate::lower::node_::Wres::WrUnit)
            },
        },
    }
}

/// The step machine of `BuildLineNow`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BuildLineNow: unbounded fn Wx, Env, Env, Expr, ?Bn -> ((Wx, Wres))
/// ```
pub struct BuildLineNow {
    pub wx_p0: crate::lower::node_::Wx,
    pub benv_p1: crate::lower::types::Env,
    pub menv_p2: crate::lower::types::Env,
    pub e_p3: crate::syntax::Expr,
    pub bound_o4: ::std::option::Option<crate::lower::types::Bn>,
}

impl ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::node_::Wres)> for BuildLineNow {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::lower::node_::Wx, crate::lower::node_::Wres)> {
        let wx_p0 = &self.wx_p0;
        let benv_p1 = &self.benv_p1;
        let menv_p2 = &self.menv_p2;
        let e_p3 = &self.e_p3;
        let bound_o4 = &self.bound_o4;
        let lx_p5 = wx_p0.lx_p.clone();
        let full_p6 = crate::lower::type_at_f(&lx_p5, &e_p3.span_p);
        match &*e_p3.kind_p {
            crate::syntax::ExprKind::EGroup(x_p7) => ::prism_rtl::Turn::More(::std::rc::Rc::new(BuildLine { wx_p0: wx_p0.clone(), benv_p1: benv_p1.clone(), menv_p2: menv_p2.clone(), e_p3: (**x_p7).clone(), bound_o4: bound_o4.clone() })),
            crate::syntax::ExprKind::EWidgetBlock(b_p8) => ::prism_rtl::Turn::Finished(crate::lower::node_::static_::inline_block_f(wx_p0, benv_p1, menv_p2, b_p8, &lx_p5)),
            crate::syntax::ExprKind::EFor(binders_o9, source_pa, body_pb) => ::prism_rtl::Turn::Finished(crate::lower::node_::keyed::for_line_f(wx_p0, benv_p1, menv_p2, binders_o9, &**source_pa, body_pb, e_p3, bound_o4)),
            crate::syntax::ExprKind::ERebuild(scrut_pc, body_pd) => ::prism_rtl::Turn::Finished(crate::lower::node_::switch_::rebuild_line_f(wx_p0, benv_p1, menv_p2, &**scrut_pc, body_pd, e_p3, bound_o4)),
            crate::syntax::ExprKind::EIf(c_pe, then_b_pf, ::std::option::Option::Some(else_b_pg)) => ::prism_rtl::Turn::Finished(crate::lower::node_::switch_::if_gen_line_f(wx_p0, menv_p2, &**c_pe, then_b_pf, else_b_pg, e_p3)),
            crate::syntax::ExprKind::EIf(c_ph, then_b_pi, ::std::option::Option::None) => ::prism_rtl::Turn::Finished(crate::lower::node_::switch_::if_gen_line_f(wx_p0, menv_p2, &**c_ph, then_b_pi, &crate::syntax::Block { stmts_p: crate::prelude::Array::new(), inline_p: true, span_p: e_p3.span_p.clone() }, e_p3)),
            crate::syntax::ExprKind::EMatch(s_pj, arms_pk) => if crate::check::types::has_text_f(&wx_p0.early_choices_p, &init_key_f(e_p3)) {
                ::prism_rtl::Turn::Finished(crate::lower::node_::switch_::early_choice_line_f(wx_p0, benv_p1, menv_p2, &**s_pj, arms_pk, e_p3))
            } else {
                ::prism_rtl::Turn::Finished(crate::lower::node_::switch_::match_gen_line_f(wx_p0, menv_p2, &**s_pj, arms_pk, e_p3))
            },
            _ => match crate::lower::types::peel_f(&full_p6) {
                crate::check::types::Ty::TyElem(_, _) => ::prism_rtl::Turn::Finished(crate::lower::node_::elements::element_line_f(wx_p0, benv_p1, menv_p2, e_p3, bound_o4)),
                crate::check::types::Ty::TyAt(_, _) => ::prism_rtl::Turn::Finished(crate::lower::node_::static_::widget_line_f(wx_p0, benv_p1, menv_p2, e_p3, bound_o4)),
                _ => {
                    let wx2_pl = {
                        let mut this: crate::lower::node_::Wx = wx_p0.clone();
                        this.build_p = crate::prelude::push(&this.build_p, &crate::lower::expr::internal_bug_do_f(&crate::prelude::Text::lit("a building line that is no element, blueprint or builder")));
                        this
                    };
                    ::prism_rtl::Turn::Finished((wx2_pl.clone(), crate::lower::node_::Wres::WrUnit))
                },
            },
        }
    }
}

/// `Start BuildLineNow, x`: what the function value is when passed to `@Run`.
pub fn start_build_line_now_f(wx_p0: crate::lower::node_::Wx, benv_p1: crate::lower::types::Env, menv_p2: crate::lower::types::Env, e_p3: crate::syntax::Expr, bound_o4: ::std::option::Option<crate::lower::types::Bn>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::node_::Wres)>> {
    ::std::rc::Rc::new(BuildLineNow { wx_p0, benv_p1, menv_p2, e_p3, bound_o4 })
}
