//! The module `Lower.Node.Def`, from `target/bootstrap/src/prismc/lower/node/def.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// `HowBound`:
///
/// ```prism
/// type HowBound = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum HowBound {
    AsHold,
    AsBind,
    AsLet,
    AsResult,
}

impl Show for HowBound {
    fn show(&self, p: &mut Printer) {
        match self {
            HowBound::AsHold => p.choice("AsHold", &[]),
            HowBound::AsBind => p.choice("AsBind", &[]),
            HowBound::AsLet => p.choice("AsLet", &[]),
            HowBound::AsResult => p.choice("AsResult", &[]),
        }
    }
}

impl ToPod for HowBound {
    fn to_pod(&self) -> Pod {
        match self {
            HowBound::AsHold => Pod::Choice("AsHold".into(), vec![]),
            HowBound::AsBind => Pod::Choice("AsBind".into(), vec![]),
            HowBound::AsLet => Pod::Choice("AsLet".into(), vec![]),
            HowBound::AsResult => Pod::Choice("AsResult".into(), vec![]),
        }
    }
}

impl FromPod for HowBound {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "AsHold" && a.len() == 0 => Ok(HowBound::AsHold),
            Pod::Choice(c, a) if &**c == "AsBind" && a.len() == 0 => Ok(HowBound::AsBind),
            Pod::Choice(c, a) if &**c == "AsLet" && a.len() == 0 => Ok(HowBound::AsLet),
            Pod::Choice(c, a) if &**c == "AsResult" && a.len() == 0 => Ok(HowBound::AsResult),
            other => mismatch("a HowBound", other),
        }
    }
}

/// ```prism
/// NodeDefOf: unbounded fn Lx, Text, [Pattern], Block, Scheme, Bool -> NodeDef
/// ```
pub fn node_def_of(lx: &crate::lower::Lx, qk: &Text, params: &Array<crate::syntax::Pattern_>, body: &crate::syntax::Block, sc: &crate::check::types::Scheme, is_root: &bool) -> crate::lower::model::NodeDef {
    let name = crate::lower::camel(&crate::check::types::bare_name(qk));
    let ptys = match &sc.ty {
        crate::check::types::Ty::TyFn(_, ps, _) => ps.clone(),
        _ => Array::new(),
    };
    let wx0 = crate::lower::node_::new_wx(lx, &name, &Array::new(), &Array::new(), &Array::new(), &Array::new(), &Map::new(), &crate::lower::node_::node_hooks(), &Array::new(), &None);
    let (ps, wx1, benv, menv) = run_to_end(fold_job(crate::check::errors::range0(&len(params)), (Array::new(), wx0.clone(), crate::lower::types::empty_env(), crate::lower::types::empty_env()), {
        let params = params.clone();
        let lx = lx.clone();
        let ptys = ptys.clone();
        Rc::new(move |(p0, p1): ((Array<(Text, crate::lower::model::OutTy)>, crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), Nat)| {
            let params = params.clone();
            let lx = lx.clone();
            let ptys = ptys.clone();
            entered(once_job(move || {
                let (acc, w, be, me) = p0;
                let i = p1;
                {
                    let p_ = or(&index(&params, &i), &crate::lower::patterns::dummy_pat());
                    let nkey = crate::lower::functions::plain_binder(&lx, &p_);
                    let base = if &nkey == &Text::lit("") {
                        Text::from(format!("arg{}", &i))
                    } else {
                        crate::lower::snake(&nkey)
                    };
                    let (rs, w2) = crate::lower::node_::fresh_name(&w, &base);
                    call_then(crate::lower::types::start_out_ty_of(lx.clone(), crate::lower::types::peel(&or(&index(&ptys, &i), &crate::check::types::Ty::TyErr))), move |out_ty_of_1975: crate::lower::model::OutTy| {
                        let t = out_ty_of_1975;
                        let w3 = {
                            let mut this: crate::lower::node_::Wx = w2.clone();
                            this.fields = push(&this.fields, &(rs.clone(), t.clone(), Text::lit("a parameter")));
                            this.inits = push(&this.inits, &(rs.clone(), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(rs.clone())))));
                            this
                        };
                        let (be2, me2) = crate::lower::node_::bind_plain(&be, &me, &nkey, &rs, &t);
                        prism_rtl::Turn::Finished((push(&acc, &(rs.clone(), t.clone())), w3.clone(), be2.clone(), me2.clone()))
                    })
                }
            }))
        }) as Rc<dyn Fn(((Array<(Text, crate::lower::model::OutTy)>, crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), Nat)) -> Rc<dyn prism_rtl::Job<(Array<(Text, crate::lower::model::OutTy)>, crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>>>
    }));
    let wx2 = block_into(&wx1, &benv, &menv, body);
    let wx3 = if *is_root { root_result(&wx2) } else { wx2.clone() };
    crate::lower::node_::finish::finish_node(&wx3, qk, &ps, &false)
}

/// The step machine of `NodeDefOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// NodeDefOf: unbounded fn Lx, Text, [Pattern], Block, Scheme, Bool -> NodeDef
/// ```
pub struct NodeDefOf {
    pub lx: crate::lower::Lx,
    pub qk: Text,
    pub params: Array<crate::syntax::Pattern_>,
    pub body: crate::syntax::Block,
    pub sc: crate::check::types::Scheme,
    pub is_root: bool,
}

impl prism_rtl::Job<crate::lower::model::NodeDef> for NodeDefOf {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::NodeDef> {
        let lx = &self.lx;
        let qk = &self.qk;
        let params = &self.params;
        let body = &self.body;
        let sc = &self.sc;
        let is_root = &self.is_root;
        let name = crate::lower::camel(&crate::check::types::bare_name(qk));
        let ptys = match &sc.ty {
            crate::check::types::Ty::TyFn(_, ps, _) => ps.clone(),
            _ => Array::new(),
        };
        let wx0 = crate::lower::node_::new_wx(lx, &name, &Array::new(), &Array::new(), &Array::new(), &Array::new(), &Map::new(), &crate::lower::node_::node_hooks(), &Array::new(), &None);
        let body = body.clone();
        let is_root = *is_root;
        let lx = lx.clone();
        let params = params.clone();
        let qk = qk.clone();
        call_value(fold_job(crate::check::errors::range0(&len(&params)), (Array::new(), wx0.clone(), crate::lower::types::empty_env(), crate::lower::types::empty_env()), {
            let params = params.clone();
            let lx = lx.clone();
            let ptys = ptys.clone();
            Rc::new(move |(p0, p1): ((Array<(Text, crate::lower::model::OutTy)>, crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), Nat)| {
                let params = params.clone();
                let lx = lx.clone();
                let ptys = ptys.clone();
                entered(once_job(move || {
                    let (acc, w, be, me) = p0;
                    let i = p1;
                    {
                        let p_ = or(&index(&params, &i), &crate::lower::patterns::dummy_pat());
                        let nkey = crate::lower::functions::plain_binder(&lx, &p_);
                        let base = if &nkey == &Text::lit("") {
                            Text::from(format!("arg{}", &i))
                        } else {
                            crate::lower::snake(&nkey)
                        };
                        let (rs, w2) = crate::lower::node_::fresh_name(&w, &base);
                        call_then(crate::lower::types::start_out_ty_of(lx.clone(), crate::lower::types::peel(&or(&index(&ptys, &i), &crate::check::types::Ty::TyErr))), move |out_ty_of_1975: crate::lower::model::OutTy| {
                            let t = out_ty_of_1975;
                            let w3 = {
                                let mut this: crate::lower::node_::Wx = w2.clone();
                                this.fields = push(&this.fields, &(rs.clone(), t.clone(), Text::lit("a parameter")));
                                this.inits = push(&this.inits, &(rs.clone(), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(rs.clone())))));
                                this
                            };
                            let (be2, me2) = crate::lower::node_::bind_plain(&be, &me, &nkey, &rs, &t);
                            prism_rtl::Turn::Finished((push(&acc, &(rs.clone(), t.clone())), w3.clone(), be2.clone(), me2.clone()))
                        })
                    }
                }))
            }) as Rc<dyn Fn(((Array<(Text, crate::lower::model::OutTy)>, crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), Nat)) -> Rc<dyn prism_rtl::Job<(Array<(Text, crate::lower::model::OutTy)>, crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>>>
        }), move |fold_1692: (Array<(Text, crate::lower::model::OutTy)>, crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)| {
            let (ps, wx1, benv, menv) = fold_1692;
            call_then(start_block_into(wx1.clone(), benv.clone(), menv.clone(), body.clone()), move |block_into_2293: crate::lower::node_::Wx| {
                let wx2 = block_into_2293;
                let wx3 = if is_root { root_result(&wx2) } else { wx2.clone() };
                prism_rtl::Turn::More(Rc::new(crate::lower::node_::finish::FinishNode { wx0: wx3.clone(), qk: qk.clone(), params: ps.clone(), is_row: false }))
            })
        })
    }
}

/// `Start NodeDefOf, x`: what the function value is when passed to `@Run`.
pub fn start_node_def_of(lx: crate::lower::Lx, qk: Text, params: Array<crate::syntax::Pattern_>, body: crate::syntax::Block, sc: crate::check::types::Scheme, is_root: bool) -> Rc<dyn prism_rtl::Job<crate::lower::model::NodeDef>> {
    Rc::new(NodeDefOf { lx, qk, params, body, sc, is_root })
}

/// ```prism
/// RootResult: fn Wx -> Wx
/// ```
pub fn root_result(wx: &crate::lower::node_::Wx) -> crate::lower::node_::Wx {
    match &wx.result {
        crate::lower::node_::Wres::WrEv(r) => crate::lower::node_::connect(wx, r, &crate::lower::node_::Sk::SkResult),
        crate::lower::node_::Wres::WrDyn(x, rds, t) => {
            let mut this: crate::lower::node_::Wx = wx.clone();
            this.root_dyn = Some((x.clone(), rds.clone(), t.clone()));
            this.getters = push(&this.getters, &crate::lower::model::MethDef { name: Text::lit("result_value"), recv: crate::lower::model::Recv::RecvRef, params: Array::new(), cx_: crate::lower::model::CxArg::CxRef, ret: crate::lower::model::OutTy::OutPod, body: Array::new(), tail: crate::lower::model::Ex::XMethod(Rc::new(x.clone()), Text::lit("to_pod"), Array::new()), doc: Text::lit("The root\'s dynamic result, pulled after the tick.") });
            this.fields = push(&this.fields, &(Text::lit("result_last"), crate::lower::model::OutTy::OutCell(Rc::new(crate::lower::model::OutTy::OutOpt(Rc::new(crate::lower::model::OutTy::OutPod)))), Text::lit("the result the World last heard")));
            this.moves = push(&this.moves, &(Text::lit("result_last"), crate::lower::model::Ex::XCall(Text::lit("RefCell::new"), Array::from(vec![crate::lower::model::Ex::XNone]))));
            this.build = push(&this.build, &crate::lower::model::Do::DoScope(crate::lower::node_::finish::result_told(&crate::lower::model::Ex::XVar(Text::lit("node")))));
            this
        },
        crate::lower::node_::Wres::WrPlain(x, _) => {
            let mut this: crate::lower::node_::Wx = wx.clone();
            this.build = push(&this.build, &crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCx), Text::lit("result"), Array::from(vec![crate::lower::model::Ex::XCtor(Text::lit("Outcome::Value"), Array::from(vec![crate::lower::model::Ex::XMethod(Rc::new(x.clone()), Text::lit("to_pod"), Array::new())]))]))));
            this
        },
        crate::lower::node_::Wres::WrParts(_) => {
            let mut this: crate::lower::node_::Wx = wx.clone();
            this.build = push(&this.build, &crate::lower::expr::refusal_do(&Text::lit("a bundle as the root\'s result: a World hears a plain value, a dynamic or an event")));
            this
        },
        _ => wx.clone(),
    }
}

/// ```prism
/// BlockInto: unbounded fn Wx, Env, Env, Block -> Wx
/// ```
pub fn block_into(wx: &crate::lower::node_::Wx, benv: &crate::lower::types::Env, menv: &crate::lower::types::Env, b: &crate::syntax::Block) -> crate::lower::node_::Wx {
    let (wx1, be1, me1) = run_to_end(fold_job(b.stmts.clone(), (wx.clone(), benv.clone(), menv.clone()), Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::syntax::Stmt)| entered(once_job(move || {
        let (w, be, me) = p0;
        let s = p1;
        prism_rtl::Turn::More(Rc::new(PreBind { wx: w.clone(), benv: be.clone(), menv: me.clone(), s: s.clone() }))
    }))) as Rc<dyn Fn(((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>>>));
    let n = len(&b.stmts);
    let (wx2, _, _) = run_to_end(fold_job(crate::check::errors::range0(&n), (wx1.clone(), be1.clone(), me1.clone()), {
        let b = b.clone();
        let n = n.clone();
        Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), Nat)| {
            let b = b.clone();
            let n = n.clone();
            entered(once_job(move || {
                let (w, be, me) = p0;
                let i = p1;
                prism_rtl::Turn::More(Rc::new(WidgetStmt { wx: w.clone(), benv: be.clone(), menv: me.clone(), s: or(&index(&b.stmts, &i), &crate::lower::expr::dummy_stmt_l()), last: &(&i + &Nat::from(1u32)) == &n }))
            }))
        }) as Rc<dyn Fn(((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), Nat)) -> Rc<dyn prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>>>
    }));
    wx2.clone()
}

/// The step machine of `BlockInto`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BlockInto: unbounded fn Wx, Env, Env, Block -> Wx
/// ```
pub struct BlockInto {
    pub wx: crate::lower::node_::Wx,
    pub benv: crate::lower::types::Env,
    pub menv: crate::lower::types::Env,
    pub b: crate::syntax::Block,
}

impl prism_rtl::Job<crate::lower::node_::Wx> for BlockInto {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::node_::Wx> {
        let wx = &self.wx;
        let benv = &self.benv;
        let menv = &self.menv;
        let b = &self.b;
        let b = b.clone();
        let benv = benv.clone();
        let menv = menv.clone();
        let wx = wx.clone();
        call_value(fold_job(b.stmts.clone(), (wx.clone(), benv.clone(), menv.clone()), Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::syntax::Stmt)| entered(once_job(move || {
            let (w, be, me) = p0;
            let s = p1;
            prism_rtl::Turn::More(Rc::new(PreBind { wx: w.clone(), benv: be.clone(), menv: me.clone(), s: s.clone() }))
        }))) as Rc<dyn Fn(((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>>>), move |fold_3778: (crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)| {
            let (wx1, be1, me1) = fold_3778;
            let n = len(&b.stmts);
            call_value(fold_job(crate::check::errors::range0(&n), (wx1.clone(), be1.clone(), me1.clone()), {
                let b = b.clone();
                let n = n.clone();
                Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), Nat)| {
                    let b = b.clone();
                    let n = n.clone();
                    entered(once_job(move || {
                        let (w, be, me) = p0;
                        let i = p1;
                        prism_rtl::Turn::More(Rc::new(WidgetStmt { wx: w.clone(), benv: be.clone(), menv: me.clone(), s: or(&index(&b.stmts, &i), &crate::lower::expr::dummy_stmt_l()), last: &(&i + &Nat::from(1u32)) == &n }))
                    }))
                }) as Rc<dyn Fn(((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), Nat)) -> Rc<dyn prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>>>
            }), move |fold_3911: (crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)| {
                let (wx2, _, _) = fold_3911;
                prism_rtl::Turn::Finished(wx2.clone())
            })
        })
    }
}

/// `Start BlockInto, x`: what the function value is when passed to `@Run`.
pub fn start_block_into(wx: crate::lower::node_::Wx, benv: crate::lower::types::Env, menv: crate::lower::types::Env, b: crate::syntax::Block) -> Rc<dyn prism_rtl::Job<crate::lower::node_::Wx>> {
    Rc::new(BlockInto { wx, benv, menv, b })
}

/// ```prism
/// PreBind: unbounded fn Wx, Env, Env, Stmt -> ((Wx, Env, Env))
/// ```
pub fn pre_bind(wx: &crate::lower::node_::Wx, benv: &crate::lower::types::Env, menv: &crate::lower::types::Env, s: &crate::syntax::Stmt) -> (crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env) {
    match &s.kind {
        crate::syntax::StmtKind::SBind(p_, init, step_opt) => {
            let how = if (step_opt == &None) && gives_result(&wx.lx, menv, init) {
                HowBound::AsResult
            } else {
                how_bound(step_opt)
            };
            match &*p_.kind {
                crate::syntax::PatternKind::PName(n) => pre_bind_name(wx, benv, menv, n, &how),
                crate::syntax::PatternKind::PTuple(ps) => run_to_end(fold_job(ps.clone(), (wx.clone(), benv.clone(), menv.clone()), {
                    let how = how.clone();
                    Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::syntax::Pattern_)| {
                        let how = how.clone();
                        entered(once_job(move || {
                            let (w, be, me) = p0;
                            let q = p1;
                            match &*q.kind {
                                crate::syntax::PatternKind::PName(n) => prism_rtl::Turn::More(Rc::new(PreBindName { wx: w.clone(), benv: be.clone(), menv: me.clone(), n: n.clone(), how: how.clone() })),
                                _ => prism_rtl::Turn::Finished((w.clone(), be.clone(), me.clone())),
                            }
                        }))
                    }) as Rc<dyn Fn(((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::syntax::Pattern_)) -> Rc<dyn prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>>>
                })),
                _ => (wx.clone(), benv.clone(), menv.clone()),
            }
        },
        crate::syntax::StmtKind::SLet(p_, _, _) => match &*p_.kind {
            crate::syntax::PatternKind::PName(n) => pre_bind_name(wx, benv, menv, n, &HowBound::AsLet),
            _ => (wx.clone(), benv.clone(), menv.clone()),
        },
        crate::syntax::StmtKind::SFn(c) => {
            let fname = crate::check::env::def_name_text(&c.name);
            (wx.clone(), crate::lower::types::bind(benv, &fname, &crate::lower::types::Bn::BnLocalFn(c.clone())), crate::lower::types::bind(menv, &fname, &crate::lower::types::Bn::BnLocalFn(c.clone())))
        },
        _ => (wx.clone(), benv.clone(), menv.clone()),
    }
}

/// The step machine of `PreBind`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PreBind: unbounded fn Wx, Env, Env, Stmt -> ((Wx, Env, Env))
/// ```
pub struct PreBind {
    pub wx: crate::lower::node_::Wx,
    pub benv: crate::lower::types::Env,
    pub menv: crate::lower::types::Env,
    pub s: crate::syntax::Stmt,
}

impl prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)> for PreBind {
    fn cycle(&self) -> prism_rtl::Turn<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)> {
        let wx = &self.wx;
        let benv = &self.benv;
        let menv = &self.menv;
        let s = &self.s;
        match &s.kind {
            crate::syntax::StmtKind::SBind(p_, init, step_opt) => {
                let how = if (step_opt == &None) && gives_result(&wx.lx, menv, init) {
                    HowBound::AsResult
                } else {
                    how_bound(step_opt)
                };
                match &*p_.kind {
                    crate::syntax::PatternKind::PName(n) => prism_rtl::Turn::More(Rc::new(PreBindName { wx: wx.clone(), benv: benv.clone(), menv: menv.clone(), n: n.clone(), how: how.clone() })),
                    crate::syntax::PatternKind::PTuple(ps) => fold_job(ps.clone(), (wx.clone(), benv.clone(), menv.clone()), {
                        let how = how.clone();
                        Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::syntax::Pattern_)| {
                            let how = how.clone();
                            entered(once_job(move || {
                                let (w, be, me) = p0;
                                let q = p1;
                                match &*q.kind {
                                    crate::syntax::PatternKind::PName(n) => prism_rtl::Turn::More(Rc::new(PreBindName { wx: w.clone(), benv: be.clone(), menv: me.clone(), n: n.clone(), how: how.clone() })),
                                    _ => prism_rtl::Turn::Finished((w.clone(), be.clone(), me.clone())),
                                }
                            }))
                        }) as Rc<dyn Fn(((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::syntax::Pattern_)) -> Rc<dyn prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>>>
                    }).cycle(),
                    _ => prism_rtl::Turn::Finished((wx.clone(), benv.clone(), menv.clone())),
                }
            },
            crate::syntax::StmtKind::SLet(p_, _, _) => match &*p_.kind {
                crate::syntax::PatternKind::PName(n) => prism_rtl::Turn::More(Rc::new(PreBindName { wx: wx.clone(), benv: benv.clone(), menv: menv.clone(), n: n.clone(), how: HowBound::AsLet })),
                _ => prism_rtl::Turn::Finished((wx.clone(), benv.clone(), menv.clone())),
            },
            crate::syntax::StmtKind::SFn(c) => {
                let fname = crate::check::env::def_name_text(&c.name);
                prism_rtl::Turn::Finished((wx.clone(), crate::lower::types::bind(benv, &fname, &crate::lower::types::Bn::BnLocalFn(c.clone())), crate::lower::types::bind(menv, &fname, &crate::lower::types::Bn::BnLocalFn(c.clone()))))
            },
            _ => prism_rtl::Turn::Finished((wx.clone(), benv.clone(), menv.clone())),
        }
    }
}

/// `Start PreBind, x`: what the function value is when passed to `@Run`.
pub fn start_pre_bind(wx: crate::lower::node_::Wx, benv: crate::lower::types::Env, menv: crate::lower::types::Env, s: crate::syntax::Stmt) -> Rc<dyn prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>> {
    Rc::new(PreBind { wx, benv, menv, s })
}

/// ```prism
/// GivesResult: unbounded fn Lx, Env, Expr -> Bool
/// ```
pub fn gives_result(lx: &crate::lower::Lx, menv: &crate::lower::types::Env, e: &crate::syntax::Expr) -> bool {
    match &*e.kind {
        crate::syntax::ExprKind::EGroup(x) => gives_result(lx, menv, &**x),
        crate::syntax::ExprKind::EWidgetBlock(_) => true,
        _ => {
            let callee = match &*e.kind {
                crate::syntax::ExprKind::ECall(c, _, _, _) => (**c).clone(),
                _ => e.clone(),
            };
            match &*callee.kind {
                crate::syntax::ExprKind::EName(n) => match get(&menv.names, &crate::check::env::sname_key(n)) {
                    Some(crate::lower::types::Bn::BnWidget(_, _, _, _)) => true,
                    _ => {
                        let (q_opt, _) = crate::check::env::names::resolve_value(&lx.g, &lx.home, n);
                        match &q_opt {
                            Some(q) => (!is_prelude_name(q) && (&get(&lx.g.vals, q) != &None)) && is_widget_ty(&crate::lower::types::peel(&crate::lower::type_at(lx, &e.span))),
                            None => false,
                        }
                    },
                },
                _ => false,
            }
        },
    }
}

/// The step machine of `GivesResult`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// GivesResult: unbounded fn Lx, Env, Expr -> Bool
/// ```
pub struct GivesResult {
    pub lx: crate::lower::Lx,
    pub menv: crate::lower::types::Env,
    pub e: crate::syntax::Expr,
}

impl prism_rtl::Job<bool> for GivesResult {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let lx = &self.lx;
        let menv = &self.menv;
        let e = &self.e;
        match &*e.kind {
            crate::syntax::ExprKind::EGroup(x) => prism_rtl::Turn::More(Rc::new(GivesResult { lx: lx.clone(), menv: menv.clone(), e: (**x).clone() })),
            crate::syntax::ExprKind::EWidgetBlock(_) => prism_rtl::Turn::Finished(true),
            _ => {
                let callee = match &*e.kind {
                    crate::syntax::ExprKind::ECall(c, _, _, _) => (**c).clone(),
                    _ => e.clone(),
                };
                match &*callee.kind {
                    crate::syntax::ExprKind::EName(n) => match get(&menv.names, &crate::check::env::sname_key(n)) {
                        Some(crate::lower::types::Bn::BnWidget(_, _, _, _)) => prism_rtl::Turn::Finished(true),
                        _ => {
                            let (q_opt, _) = crate::check::env::names::resolve_value(&lx.g, &lx.home, n);
                            match &q_opt {
                                Some(q) => prism_rtl::Turn::Finished((!is_prelude_name(q) && (&get(&lx.g.vals, q) != &None)) && is_widget_ty(&crate::lower::types::peel(&crate::lower::type_at(lx, &e.span)))),
                                None => prism_rtl::Turn::Finished(false),
                            }
                        },
                    },
                    _ => prism_rtl::Turn::Finished(false),
                }
            },
        }
    }
}

/// `Start GivesResult, x`: what the function value is when passed to `@Run`.
pub fn start_gives_result(lx: crate::lower::Lx, menv: crate::lower::types::Env, e: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(GivesResult { lx, menv, e })
}

/// ```prism
/// IsPreludeName: fn Text -> Bool
/// ```
pub fn is_prelude_name(q: &Text) -> bool {
    &find(&{ thread_local!(static R: Regex = Regex::lit("^Prelude\\.", "")); R.with(Regex::clone) }, q) != &None
}

/// ```prism
/// IsWidgetTy: fn Ty -> Bool
/// ```
pub fn is_widget_ty(t: &crate::check::types::Ty) -> bool {
    match t {
        crate::check::types::Ty::TyAt(_, _) => true,
        _ => false,
    }
}

/// ```prism
/// HowBound: fn ?Expr -> HowBound
/// ```
pub fn how_bound(opt0: &Option<crate::syntax::Expr>) -> HowBound {
    match opt0 {
        Some(_) => HowBound::AsHold,
        None => HowBound::AsBind,
    }
}

/// ```prism
/// PreBindName: unbounded fn Wx, Env, Env, SName, HowBound -> ((Wx, Env, Env))
/// ```
pub fn pre_bind_name(wx: &crate::lower::node_::Wx, benv: &crate::lower::types::Env, menv: &crate::lower::types::Env, n: &crate::syntax::SName, how: &HowBound) -> (crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env) {
    let lx = crate::lower::expr::widget_let_lx(&wx.lx, &n.span);
    let nkey = crate::check::env::sname_key(n);
    let full = crate::lower::binder_ty(&lx, &n.span);
    let layer = crate::lower::types::layer_of(&full);
    let t = crate::lower::types::out_ty_of(&lx, &crate::lower::types::peel(&full));
    let (rs, wx1) = crate::lower::node_::fresh_name(wx, &crate::lower::snake(&nkey));
    if ((how == &HowBound::AsBind) || (how == &HowBound::AsResult)) && crate::lower::types::is_bundle(&full) {
        (wx.clone(), benv.clone(), menv.clone())
    } else {
        if (&layer == &crate::lower::types::Layer::LyEv) || is_switched(&full) {
            {
                let et = crate::lower::types::out_ty_of(&lx, &crate::lower::types::peel(&crate::lower::types::peel(&full)));
                let (id, wx2) = crate::lower::node_::add_gn(&wx1, &rs, &et, &crate::lower::node_::GnKind::GnNamed, &Nat::from(0u32));
                let b = crate::lower::types::Bn::BnEv(crate::lower::node_::ev_ref_of(&wx2, &id), t.clone());
                let pf = Text::from(format!("{}_v_port", &rs));
                let pt = crate::lower::model::OutTy::OutRc(Rc::new(crate::lower::model::OutTy::OutPort(Rc::new(et.clone()))));
                let wx3 = {
                    let mut this: crate::lower::node_::Wx = crate::lower::node_::connect(&wx2, &crate::lower::node_::ev_ref_of(&wx2, &id), &crate::lower::node_::Sk::SkPort(Text::from(format!("{}_v", &rs))));
                    this.lets = push(&this.lets, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaBind(pf.clone())), pt.clone()), crate::lower::model::Ex::XCall(Text::lit("Rc::new"), Array::from(vec![crate::lower::model::Ex::XCall(Text::lit("Port::new"), Array::new())]))));
                    this.fields = push(&this.fields, &(pf.clone(), pt.clone(), Text::from(format!("`{}` as a value: the port it fires", &nkey))));
                    this.moves = push(&this.moves, &(pf.clone(), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(pf.clone())))));
                    this
                };
                let be = crate::lower::types::bind(&crate::lower::types::bind(benv, &nkey, &b), &Text::from(format!("{}#port", &nkey)), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(pf.clone()), crate::lower::types::Holding::Owned, pt.clone()));
                let me = crate::lower::types::bind(&crate::lower::types::bind(menv, &nkey, &b), &Text::from(format!("{}#port", &nkey)), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), pf.clone()), crate::lower::types::Holding::Owned, pt.clone()));
                (wx3.clone(), be.clone(), me.clone())
            }
        } else {
            match (layer.clone(), how.clone()) {
                (crate::lower::types::Layer::LyDyn, HowBound::AsLet) => {
                    let b = crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XSelf), rs.clone(), Array::from(vec![crate::lower::model::Ex::XCx])), Array::from(vec![crate::lower::node_::Read::OwnRead(rs.clone())]), t.clone());
                    (wx1.clone(), crate::lower::types::bind(benv, &nkey, &b), crate::lower::types::bind(menv, &nkey, &b))
                },
                (crate::lower::types::Layer::LyDyn, HowBound::AsResult) => {
                    let b = crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XSelf), rs.clone(), Array::from(vec![crate::lower::model::Ex::XCx])), Array::from(vec![crate::lower::node_::Read::OwnRead(rs.clone())]), t.clone());
                    (wx1.clone(), crate::lower::types::bind(benv, &nkey, &b), crate::lower::types::bind(menv, &nkey, &b))
                },
                (crate::lower::types::Layer::LyDyn, _) => {
                    let b = crate::lower::types::Bn::BnHold(rs.clone(), t.clone());
                    (wx1.clone(), crate::lower::types::bind(benv, &nkey, &b), crate::lower::types::bind(menv, &nkey, &b))
                },
                _ => match many_instances(&wx.lx, &n.span) {
                    Some(insts) => run_to_end(fold_job(crate::check::errors::range0(&len(&insts)), (wx1.clone(), benv.clone(), menv.clone()), {
                        let insts = insts.clone();
                        let wx = wx.clone();
                        let n = n.clone();
                        let rs = rs.clone();
                        let nkey = nkey.clone();
                        Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), Nat)| {
                            let insts = insts.clone();
                            let wx = wx.clone();
                            let n = n.clone();
                            let rs = rs.clone();
                            let nkey = nkey.clone();
                            entered(once_job(move || {
                                let (w, be, me) = p0;
                                let k = p1;
                                {
                                    let inst = or(&index(&insts, &k), &(Array::new(), Array::new()));
                                    let lxk = crate::lower::expr::at_instance(&wx.lx, &inst);
                                    call_then(crate::lower::types::start_out_ty_of(lxk.clone(), crate::lower::types::peel(&crate::lower::binder_ty(&lxk, &n.span))), move |out_ty_of_9227: crate::lower::model::OutTy| {
                                        let tk = out_ty_of_9227;
                                        let (rk, w2) = if &k == &Nat::from(0u32) {
                                            (rs.clone(), w.clone())
                                        } else {
                                            crate::lower::node_::fresh_name(&w, &Text::from(format!("{}_{}", &rs, &k)))
                                        };
                                        let bkey = if &k == &Nat::from(0u32) {
                                            nkey.clone()
                                        } else {
                                            Text::from(format!("{}#inst{}", &nkey, &k))
                                        };
                                        let (be2, me2) = crate::lower::node_::bind_plain(&be, &me, &bkey, &rk, &tk);
                                        let ukey = Text::from(format!("{}#{}", &nkey, &show_text(&inst)));
                                        prism_rtl::Turn::Finished((w2.clone(), with_use(&be2, &ukey, &bkey), with_use(&me2, &ukey, &bkey)))
                                    })
                                }
                            }))
                        }) as Rc<dyn Fn(((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), Nat)) -> Rc<dyn prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>>>
                    })),
                    None => {
                        let (be, me) = crate::lower::node_::bind_plain(benv, menv, &nkey, &rs, &t);
                        (wx1.clone(), be.clone(), me.clone())
                    },
                },
            }
        }
    }
}

/// The step machine of `PreBindName`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PreBindName: unbounded fn Wx, Env, Env, SName, HowBound -> ((Wx, Env, Env))
/// ```
pub struct PreBindName {
    pub wx: crate::lower::node_::Wx,
    pub benv: crate::lower::types::Env,
    pub menv: crate::lower::types::Env,
    pub n: crate::syntax::SName,
    pub how: HowBound,
}

impl prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)> for PreBindName {
    fn cycle(&self) -> prism_rtl::Turn<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)> {
        let wx = &self.wx;
        let benv = &self.benv;
        let menv = &self.menv;
        let n = &self.n;
        let how = &self.how;
        let benv = benv.clone();
        let how = how.clone();
        let menv = menv.clone();
        let n = n.clone();
        let wx = wx.clone();
        call_then(crate::lower::expr::start_widget_let_lx(wx.lx.clone(), n.span.clone()), move |widget_let_lx_6816: crate::lower::Lx| {
            let lx = widget_let_lx_6816;
            let nkey = crate::check::env::sname_key(&n);
            let full = crate::lower::binder_ty(&lx, &n.span);
            let layer = crate::lower::types::layer_of(&full);
            call_then(crate::lower::types::start_out_ty_of(lx.clone(), crate::lower::types::peel(&full)), move |out_ty_of_6944: crate::lower::model::OutTy| {
                let t = out_ty_of_6944;
                let (rs, wx1) = crate::lower::node_::fresh_name(&wx, &crate::lower::snake(&nkey));
                if ((&how == &HowBound::AsBind) || (&how == &HowBound::AsResult)) && crate::lower::types::is_bundle(&full) {
                    prism_rtl::Turn::Finished((wx.clone(), benv.clone(), menv.clone()))
                } else {
                    if (&layer == &crate::lower::types::Layer::LyEv) || is_switched(&full) {
                        call_then(crate::lower::types::start_out_ty_of(lx.clone(), crate::lower::types::peel(&crate::lower::types::peel(&full))), move |out_ty_of_7302: crate::lower::model::OutTy| {
                            let et = out_ty_of_7302;
                            let (id, wx2) = crate::lower::node_::add_gn(&wx1, &rs, &et, &crate::lower::node_::GnKind::GnNamed, &Nat::from(0u32));
                            let b = crate::lower::types::Bn::BnEv(crate::lower::node_::ev_ref_of(&wx2, &id), t.clone());
                            let pf = Text::from(format!("{}_v_port", &rs));
                            let pt = crate::lower::model::OutTy::OutRc(Rc::new(crate::lower::model::OutTy::OutPort(Rc::new(et.clone()))));
                            let wx3 = {
                                let mut this: crate::lower::node_::Wx = crate::lower::node_::connect(&wx2, &crate::lower::node_::ev_ref_of(&wx2, &id), &crate::lower::node_::Sk::SkPort(Text::from(format!("{}_v", &rs))));
                                this.lets = push(&this.lets, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaBind(pf.clone())), pt.clone()), crate::lower::model::Ex::XCall(Text::lit("Rc::new"), Array::from(vec![crate::lower::model::Ex::XCall(Text::lit("Port::new"), Array::new())]))));
                                this.fields = push(&this.fields, &(pf.clone(), pt.clone(), Text::from(format!("`{}` as a value: the port it fires", &nkey))));
                                this.moves = push(&this.moves, &(pf.clone(), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(pf.clone())))));
                                this
                            };
                            let be = crate::lower::types::bind(&crate::lower::types::bind(&benv, &nkey, &b), &Text::from(format!("{}#port", &nkey)), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(pf.clone()), crate::lower::types::Holding::Owned, pt.clone()));
                            let me = crate::lower::types::bind(&crate::lower::types::bind(&menv, &nkey, &b), &Text::from(format!("{}#port", &nkey)), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), pf.clone()), crate::lower::types::Holding::Owned, pt.clone()));
                            prism_rtl::Turn::Finished((wx3.clone(), be.clone(), me.clone()))
                        })
                    } else {
                        match (layer.clone(), how.clone()) {
                            (crate::lower::types::Layer::LyDyn, HowBound::AsLet) => {
                                let b = crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XSelf), rs.clone(), Array::from(vec![crate::lower::model::Ex::XCx])), Array::from(vec![crate::lower::node_::Read::OwnRead(rs.clone())]), t.clone());
                                prism_rtl::Turn::Finished((wx1.clone(), crate::lower::types::bind(&benv, &nkey, &b), crate::lower::types::bind(&menv, &nkey, &b)))
                            },
                            (crate::lower::types::Layer::LyDyn, HowBound::AsResult) => {
                                let b = crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XSelf), rs.clone(), Array::from(vec![crate::lower::model::Ex::XCx])), Array::from(vec![crate::lower::node_::Read::OwnRead(rs.clone())]), t.clone());
                                prism_rtl::Turn::Finished((wx1.clone(), crate::lower::types::bind(&benv, &nkey, &b), crate::lower::types::bind(&menv, &nkey, &b)))
                            },
                            (crate::lower::types::Layer::LyDyn, _) => {
                                let b = crate::lower::types::Bn::BnHold(rs.clone(), t.clone());
                                prism_rtl::Turn::Finished((wx1.clone(), crate::lower::types::bind(&benv, &nkey, &b), crate::lower::types::bind(&menv, &nkey, &b)))
                            },
                            _ => call_then(start_many_instances(wx.lx.clone(), n.span.clone()), move |many_instances_8759: Option<Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)>>| match many_instances_8759 {
                                Some(insts) => fold_job(crate::check::errors::range0(&len(&insts)), (wx1.clone(), benv.clone(), menv.clone()), {
                                    let insts = insts.clone();
                                    let wx = wx.clone();
                                    let n = n.clone();
                                    let rs = rs.clone();
                                    let nkey = nkey.clone();
                                    Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), Nat)| {
                                        let insts = insts.clone();
                                        let wx = wx.clone();
                                        let n = n.clone();
                                        let rs = rs.clone();
                                        let nkey = nkey.clone();
                                        entered(once_job(move || {
                                            let (w, be, me) = p0;
                                            let k = p1;
                                            {
                                                let inst = or(&index(&insts, &k), &(Array::new(), Array::new()));
                                                let lxk = crate::lower::expr::at_instance(&wx.lx, &inst);
                                                call_then(crate::lower::types::start_out_ty_of(lxk.clone(), crate::lower::types::peel(&crate::lower::binder_ty(&lxk, &n.span))), move |out_ty_of_9227: crate::lower::model::OutTy| {
                                                    let tk = out_ty_of_9227;
                                                    let (rk, w2) = if &k == &Nat::from(0u32) {
                                                        (rs.clone(), w.clone())
                                                    } else {
                                                        crate::lower::node_::fresh_name(&w, &Text::from(format!("{}_{}", &rs, &k)))
                                                    };
                                                    let bkey = if &k == &Nat::from(0u32) {
                                                        nkey.clone()
                                                    } else {
                                                        Text::from(format!("{}#inst{}", &nkey, &k))
                                                    };
                                                    let (be2, me2) = crate::lower::node_::bind_plain(&be, &me, &bkey, &rk, &tk);
                                                    let ukey = Text::from(format!("{}#{}", &nkey, &show_text(&inst)));
                                                    prism_rtl::Turn::Finished((w2.clone(), with_use(&be2, &ukey, &bkey), with_use(&me2, &ukey, &bkey)))
                                                })
                                            }
                                        }))
                                    }) as Rc<dyn Fn(((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), Nat)) -> Rc<dyn prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>>>
                                }).cycle(),
                                None => {
                                    let (be, me) = crate::lower::node_::bind_plain(&benv, &menv, &nkey, &rs, &t);
                                    prism_rtl::Turn::Finished((wx1.clone(), be.clone(), me.clone()))
                                },
                            }),
                        }
                    }
                }
            })
        })
    }
}

/// `Start PreBindName, x`: what the function value is when passed to `@Run`.
pub fn start_pre_bind_name(wx: crate::lower::node_::Wx, benv: crate::lower::types::Env, menv: crate::lower::types::Env, n: crate::syntax::SName, how: HowBound) -> Rc<dyn prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>> {
    Rc::new(PreBindName { wx, benv, menv, n, how })
}

/// ```prism
/// WithUse: fn Env, Text, Text -> Env
/// ```
pub fn with_use(env: &crate::lower::types::Env, ukey: &Text, bkey: &Text) -> crate::lower::types::Env {
    let mut this: crate::lower::types::Env = env.clone();
    this.uses = insert(&this.uses, ukey, bkey);
    this
}

/// ```prism
/// ?ManyInstances: unbounded fn Lx, Range -> ?[(([((Text, Ty))], [((Text, Col))]))]
/// ```
pub fn many_instances(lx: &crate::lower::Lx, span: &crate::syntax::Range) -> Option<Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)>> {
    match get(&lx.gens, &crate::lower::place_key(lx, span)) {
        Some(gn) => {
            let insts = crate::lower::expr::instantiations(lx, &gn);
            if &len(&insts) > &Nat::from(1u32) { Some(insts.clone()) } else { None }
        },
        None => None,
    }
}

/// The step machine of `ManyInstances`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?ManyInstances: unbounded fn Lx, Range -> ?[(([((Text, Ty))], [((Text, Col))]))]
/// ```
pub struct ManyInstances {
    pub lx: crate::lower::Lx,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<Option<Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)>>> for ManyInstances {
    fn cycle(&self) -> prism_rtl::Turn<Option<Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)>>> {
        let lx = &self.lx;
        let span = &self.span;
        match get(&lx.gens, &crate::lower::place_key(lx, span)) {
            Some(gn) => {
                let lx = lx.clone();
                call_then(crate::lower::expr::start_instantiations(lx.clone(), gn.clone()), move |instantiations_10104: Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)>| {
                    let insts = instantiations_10104;
                    if &len(&insts) > &Nat::from(1u32) {
                        prism_rtl::Turn::Finished(Some(insts.clone()))
                    } else {
                        prism_rtl::Turn::Finished(None)
                    }
                })
            },
            None => prism_rtl::Turn::Finished(None),
        }
    }
}

/// `Start ManyInstances, x`: what the function value is when passed to `@Run`.
pub fn start_many_instances(lx: crate::lower::Lx, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<Option<Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)>>>> {
    Rc::new(ManyInstances { lx, span })
}

/// ```prism
/// IsSwitched: fn Ty -> Bool
/// ```
pub fn is_switched(t: &crate::check::types::Ty) -> bool {
    'm10421: {
        if let crate::check::types::Ty::TySig(m10421_0_0, m10421_0_1) = t && (m10421_0_0 == &Text::lit("$")) && let crate::check::types::Ty::TySig(m10421_0_1_r_0, _) = &**m10421_0_1 && (m10421_0_1_r_0 == &Text::lit("!")) {
            break 'm10421 true;
        }
        false
    }
}

/// ```prism
/// ?BindingOf: fn Env, Pattern -> ?Bn
/// ```
pub fn binding_of(env: &crate::lower::types::Env, p_: &crate::syntax::Pattern_) -> Option<crate::lower::types::Bn> {
    match &*p_.kind {
        crate::syntax::PatternKind::PName(n) => get(&env.names, &crate::check::env::sname_key(n)),
        crate::syntax::PatternKind::PTuple(ps) => Some(crate::lower::types::Bn::BnParts(each(ps, &(|q: &crate::syntax::Pattern_| binding_of_name(env, q))))),
        _ => None,
    }
}

/// ```prism
/// ?BindingOfName: fn Env, Pattern -> ?Bn
/// ```
pub fn binding_of_name(env: &crate::lower::types::Env, p_: &crate::syntax::Pattern_) -> Option<crate::lower::types::Bn> {
    match &*p_.kind {
        crate::syntax::PatternKind::PName(n) => get(&env.names, &crate::check::env::sname_key(n)),
        _ => None,
    }
}

/// ```prism
/// WidgetStmt: unbounded fn Wx, Env, Env, Stmt, Bool -> ((Wx, Env, Env))
/// ```
pub fn widget_stmt(wx: &crate::lower::node_::Wx, benv: &crate::lower::types::Env, menv: &crate::lower::types::Env, s: &crate::syntax::Stmt, last: &bool) -> (crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env) {
    let lx = wx.lx.clone();
    match &s.kind {
        crate::syntax::StmtKind::SBind(p_, e, None) => {
            let (wx2, res) = build_line(wx, benv, menv, e, &binding_of(menv, p_));
            let wx3 = bind_res(&wx2, menv, p_, &res);
            match (res.clone(), (*p_.kind).clone()) {
                (crate::lower::node_::Wres::WrDyn(ex, rds, t), crate::syntax::PatternKind::PName(n)) => {
                    let b = crate::lower::types::Bn::BnDyn(ex.clone(), rds.clone(), t.clone());
                    result_getter(&wx3, menv, &n, &ex, &rds, &t, &crate::lower::types::bind(benv, &crate::check::env::sname_key(&n), &b), &crate::lower::types::bind(menv, &crate::check::env::sname_key(&n), &b))
                },
                (crate::lower::node_::Wres::WrHosted(inner, doc), crate::syntax::PatternKind::PTuple(ps)) => bind_hosted(&wx3, benv, menv, &*inner, &doc, &ps),
                (crate::lower::node_::Wres::WrParts(parts), crate::syntax::PatternKind::PTuple(ps)) => bind_parts(&wx2, benv, menv, &parts, &ps),
                (crate::lower::node_::Wres::WrParts(parts), crate::syntax::PatternKind::PName(n)) => {
                    let b = bundle_bn(&res);
                    (wx3.clone(), crate::lower::types::bind(benv, &crate::check::env::sname_key(&n), &b), crate::lower::types::bind(menv, &crate::check::env::sname_key(&n), &b))
                },
                _ => (wx3.clone(), benv.clone(), menv.clone()),
            }
        },
        crate::syntax::StmtKind::SBind(p_, init, Some(step_)) => {
            let (wx2, be2) = hold_line(wx, benv, menv, p_, init, step_);
            (wx2.clone(), be2.clone(), menv.clone())
        },
        crate::syntax::StmtKind::SIgnore(e) => {
            let (wx2, _) = build_line(wx, benv, menv, e, &None);
            (wx2.clone(), benv.clone(), menv.clone())
        },
        crate::syntax::StmtKind::SLet(p_, _, e) => {
            let (wx2, be2) = let_line(wx, benv, menv, p_, e);
            (wx2.clone(), be2.clone(), menv.clone())
        },
        crate::syntax::StmtKind::SExpr(e) => match &*e.kind {
            crate::syntax::ExprKind::EFreeSigil(m12228_0_0, x) if (m12228_0_0 == &Text::lit("@")) => {
                let (res, wx2) = result_of(wx, benv, menv, &**x);
                let wx3 = {
                    let mut this: crate::lower::node_::Wx = wx2.clone();
                    this.result = res.clone();
                    this
                };
                (wx3.clone(), benv.clone(), menv.clone())
            },
            _ => {
                let (wx2, res) = build_line(wx, benv, menv, e, &None);
                let wx3 = if *last { set_result(&wx2, &res) } else { wx2.clone() };
                (wx3.clone(), benv.clone(), menv.clone())
            },
            _ => unreachable!("no arm matched"),
        },
        crate::syntax::StmtKind::SEmit(_) => (wx.clone(), benv.clone(), menv.clone()),
        crate::syntax::StmtKind::SSignature(_) => (wx.clone(), benv.clone(), menv.clone()),
        crate::syntax::StmtKind::SFn(c) => (wx.clone(), benv.clone(), menv.clone()),
        _ => {
            let wx2 = {
                let mut this: crate::lower::node_::Wx = wx.clone();
                this.build = push(&this.build, &crate::lower::expr::refusal_do(&Text::lit("a statement this back end does not lower yet")));
                this
            };
            (wx2.clone(), benv.clone(), menv.clone())
        },
    }
}

/// The step machine of `WidgetStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// WidgetStmt: unbounded fn Wx, Env, Env, Stmt, Bool -> ((Wx, Env, Env))
/// ```
pub struct WidgetStmt {
    pub wx: crate::lower::node_::Wx,
    pub benv: crate::lower::types::Env,
    pub menv: crate::lower::types::Env,
    pub s: crate::syntax::Stmt,
    pub last: bool,
}

impl prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)> for WidgetStmt {
    fn cycle(&self) -> prism_rtl::Turn<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)> {
        let wx = &self.wx;
        let benv = &self.benv;
        let menv = &self.menv;
        let s = &self.s;
        let last = &self.last;
        let lx = wx.lx.clone();
        match &s.kind {
            crate::syntax::StmtKind::SBind(p_, e, None) => {
                let benv = benv.clone();
                let e = e.clone();
                let menv = menv.clone();
                let p_ = p_.clone();
                let wx = wx.clone();
                call_then(start_build_line(wx.clone(), benv.clone(), menv.clone(), e.clone(), binding_of(&menv, &p_)), move |build_line_11092: (crate::lower::node_::Wx, crate::lower::node_::Wres)| {
                    let (wx2, res) = build_line_11092;
                    let wx3 = bind_res(&wx2, &menv, &p_, &res);
                    match (res.clone(), (*p_.kind).clone()) {
                        (crate::lower::node_::Wres::WrDyn(ex, rds, t), crate::syntax::PatternKind::PName(n)) => {
                            let b = crate::lower::types::Bn::BnDyn(ex.clone(), rds.clone(), t.clone());
                            prism_rtl::Turn::Finished(result_getter(&wx3, &menv, &n, &ex, &rds, &t, &crate::lower::types::bind(&benv, &crate::check::env::sname_key(&n), &b), &crate::lower::types::bind(&menv, &crate::check::env::sname_key(&n), &b)))
                        },
                        (crate::lower::node_::Wres::WrHosted(inner, doc), crate::syntax::PatternKind::PTuple(ps)) => prism_rtl::Turn::Finished(bind_hosted(&wx3, &benv, &menv, &*inner, &doc, &ps)),
                        (crate::lower::node_::Wres::WrParts(parts), crate::syntax::PatternKind::PTuple(ps)) => prism_rtl::Turn::More(Rc::new(BindParts { wx: wx2.clone(), benv: benv.clone(), menv: menv.clone(), parts: parts.clone(), ps: ps.clone() })),
                        (crate::lower::node_::Wres::WrParts(parts), crate::syntax::PatternKind::PName(n)) => {
                            let b = bundle_bn(&res);
                            prism_rtl::Turn::Finished((wx3.clone(), crate::lower::types::bind(&benv, &crate::check::env::sname_key(&n), &b), crate::lower::types::bind(&menv, &crate::check::env::sname_key(&n), &b)))
                        },
                        _ => prism_rtl::Turn::Finished((wx3.clone(), benv.clone(), menv.clone())),
                    }
                })
            },
            crate::syntax::StmtKind::SBind(p_, init, Some(step_)) => {
                let benv = benv.clone();
                let init = init.clone();
                let menv = menv.clone();
                let p_ = p_.clone();
                let step_ = step_.clone();
                let wx = wx.clone();
                call_then(start_hold_line(wx.clone(), benv.clone(), menv.clone(), p_.clone(), init.clone(), step_.clone()), move |hold_line_11905: (crate::lower::node_::Wx, crate::lower::types::Env)| {
                    let (wx2, be2) = hold_line_11905;
                    prism_rtl::Turn::Finished((wx2.clone(), be2.clone(), menv.clone()))
                })
            },
            crate::syntax::StmtKind::SIgnore(e) => {
                let benv = benv.clone();
                let e = e.clone();
                let menv = menv.clone();
                let wx = wx.clone();
                call_then(start_build_line(wx.clone(), benv.clone(), menv.clone(), e.clone(), None), move |build_line_12028: (crate::lower::node_::Wx, crate::lower::node_::Wres)| {
                    let (wx2, _) = build_line_12028;
                    prism_rtl::Turn::Finished((wx2.clone(), benv.clone(), menv.clone()))
                })
            },
            crate::syntax::StmtKind::SLet(p_, _, e) => {
                let benv = benv.clone();
                let e = e.clone();
                let menv = menv.clone();
                let p_ = p_.clone();
                let wx = wx.clone();
                call_then(start_let_line(wx.clone(), benv.clone(), menv.clone(), p_.clone(), e.clone()), move |let_line_12151: (crate::lower::node_::Wx, crate::lower::types::Env)| {
                    let (wx2, be2) = let_line_12151;
                    prism_rtl::Turn::Finished((wx2.clone(), be2.clone(), menv.clone()))
                })
            },
            crate::syntax::StmtKind::SExpr(e) => match &*e.kind {
                crate::syntax::ExprKind::EFreeSigil(m12228_0_0, x) if (m12228_0_0 == &Text::lit("@")) => {
                    let benv = benv.clone();
                    let menv = menv.clone();
                    let wx = wx.clone();
                    let x = (**x).clone();
                    call_then(start_result_of(wx.clone(), benv.clone(), menv.clone(), x.clone()), move |result_of_12308: (crate::lower::node_::Wres, crate::lower::node_::Wx)| {
                        let (res, wx2) = result_of_12308;
                        let wx3 = {
                            let mut this: crate::lower::node_::Wx = wx2.clone();
                            this.result = res.clone();
                            this
                        };
                        prism_rtl::Turn::Finished((wx3.clone(), benv.clone(), menv.clone()))
                    })
                },
                _ => {
                    let benv = benv.clone();
                    let e = e.clone();
                    let last = *last;
                    let menv = menv.clone();
                    let wx = wx.clone();
                    call_then(start_build_line(wx.clone(), benv.clone(), menv.clone(), e.clone(), None), move |build_line_12504: (crate::lower::node_::Wx, crate::lower::node_::Wres)| {
                        let (wx2, res) = build_line_12504;
                        let wx3 = if last { set_result(&wx2, &res) } else { wx2.clone() };
                        prism_rtl::Turn::Finished((wx3.clone(), benv.clone(), menv.clone()))
                    })
                },
                _ => unreachable!("no arm matched"),
            },
            crate::syntax::StmtKind::SEmit(_) => prism_rtl::Turn::Finished((wx.clone(), benv.clone(), menv.clone())),
            crate::syntax::StmtKind::SSignature(_) => prism_rtl::Turn::Finished((wx.clone(), benv.clone(), menv.clone())),
            crate::syntax::StmtKind::SFn(c) => prism_rtl::Turn::Finished((wx.clone(), benv.clone(), menv.clone())),
            _ => {
                let wx2 = {
                    let mut this: crate::lower::node_::Wx = wx.clone();
                    this.build = push(&this.build, &crate::lower::expr::refusal_do(&Text::lit("a statement this back end does not lower yet")));
                    this
                };
                prism_rtl::Turn::Finished((wx2.clone(), benv.clone(), menv.clone()))
            },
        }
    }
}

/// `Start WidgetStmt, x`: what the function value is when passed to `@Run`.
pub fn start_widget_stmt(wx: crate::lower::node_::Wx, benv: crate::lower::types::Env, menv: crate::lower::types::Env, s: crate::syntax::Stmt, last: bool) -> Rc<dyn prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>> {
    Rc::new(WidgetStmt { wx, benv, menv, s, last })
}

/// ```prism
/// BindHosted: fn Wx, Env, Env, Wres, Bn, [Pattern] -> ((Wx, Env, Env))
/// ```
pub fn bind_hosted(wx: &crate::lower::node_::Wx, benv: &crate::lower::types::Env, menv: &crate::lower::types::Env, res: &crate::lower::node_::Wres, doc: &crate::lower::types::Bn, ps: &Array<crate::syntax::Pattern_>) -> (crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env) {
    let r_opt = match res {
        crate::lower::node_::Wres::WrEv(r) => Some(crate::lower::types::Bn::BnEv(r.clone(), crate::lower::model::OutTy::OutUnit)),
        crate::lower::node_::Wres::WrDyn(ex, rds, t) => Some(crate::lower::types::Bn::BnDyn(ex.clone(), rds.clone(), t.clone())),
        crate::lower::node_::Wres::WrParts(_) => Some(bundle_bn(res)),
        _ => None,
    };
    let (be1, me1) = bind_part(benv, menv, &index(ps, &Nat::from(0u32)), &r_opt);
    bind_part2(wx, &be1, &me1, &index(ps, &Nat::from(1u32)), &Some(doc.clone()))
}

/// ```prism
/// BindPart: fn Env, Env, ?Pattern, ?Bn -> ((Env, Env))
/// ```
pub fn bind_part(benv: &crate::lower::types::Env, menv: &crate::lower::types::Env, p__opt: &Option<crate::syntax::Pattern_>, b_opt: &Option<crate::lower::types::Bn>) -> (crate::lower::types::Env, crate::lower::types::Env) {
    match (p__opt.clone(), b_opt.clone()) {
        (Some(p_), Some(b)) => match &*p_.kind {
            crate::syntax::PatternKind::PName(n) => (crate::lower::types::bind(benv, &crate::check::env::sname_key(n), &b), crate::lower::types::bind(menv, &crate::check::env::sname_key(n), &b)),
            _ => (benv.clone(), menv.clone()),
        },
        _ => (benv.clone(), menv.clone()),
    }
}

/// ```prism
/// BindPart2: fn Wx, Env, Env, ?Pattern, ?Bn -> ((Wx, Env, Env))
/// ```
pub fn bind_part2(wx: &crate::lower::node_::Wx, benv: &crate::lower::types::Env, menv: &crate::lower::types::Env, p__opt: &Option<crate::syntax::Pattern_>, b_opt: &Option<crate::lower::types::Bn>) -> (crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env) {
    let (be, me) = bind_part(benv, menv, p__opt, b_opt);
    (wx.clone(), be.clone(), me.clone())
}

/// ```prism
/// BindParts: unbounded fn Wx, Env, Env, [Wres], [Pattern] -> ((Wx, Env, Env))
/// ```
pub fn bind_parts(wx: &crate::lower::node_::Wx, benv: &crate::lower::types::Env, menv: &crate::lower::types::Env, parts: &Array<crate::lower::node_::Wres>, ps: &Array<crate::syntax::Pattern_>) -> (crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env) {
    run_to_end(fold_job(crate::check::errors::range0(&len(ps)), (wx.clone(), benv.clone(), menv.clone()), {
        let ps = ps.clone();
        let parts = parts.clone();
        Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), Nat)| {
            let ps = ps.clone();
            let parts = parts.clone();
            entered(once_job(move || {
                let (w, be, me) = p0;
                let i = p1;
                match (index(&ps, &i), index(&parts, &i)) {
                    (Some(p_), Some(part)) => match (part.clone(), (*p_.kind).clone()) {
                        (crate::lower::node_::Wres::WrEv(r), crate::syntax::PatternKind::PName(_)) => prism_rtl::Turn::Finished((bind_res(&w, &me, &p_, &part), be.clone(), me.clone())),
                        (crate::lower::node_::Wres::WrParts(inner), crate::syntax::PatternKind::PTuple(qs)) => prism_rtl::Turn::More(Rc::new(BindParts { wx: w.clone(), benv: be.clone(), menv: me.clone(), parts: inner.clone(), ps: qs.clone() })),
                        (_, crate::syntax::PatternKind::PName(n)) => match &part {
                            crate::lower::node_::Wres::WrUnit => prism_rtl::Turn::Finished((w.clone(), be.clone(), me.clone())),
                            crate::lower::node_::Wres::WrDyn(ex, rds, t) => {
                                let b = crate::lower::types::Bn::BnDyn(ex.clone(), rds.clone(), t.clone());
                                prism_rtl::Turn::Finished(result_getter(&w, &me, &n, ex, rds, t, &crate::lower::types::bind(&be, &crate::check::env::sname_key(&n), &b), &crate::lower::types::bind(&me, &crate::check::env::sname_key(&n), &b)))
                            },
                            _ => {
                                let b = bundle_bn(&part);
                                prism_rtl::Turn::Finished((w.clone(), crate::lower::types::bind(&be, &crate::check::env::sname_key(&n), &b), crate::lower::types::bind(&me, &crate::check::env::sname_key(&n), &b)))
                            },
                        },
                        _ => prism_rtl::Turn::Finished((w.clone(), be.clone(), me.clone())),
                    },
                    _ => prism_rtl::Turn::Finished((w.clone(), be.clone(), me.clone())),
                }
            }))
        }) as Rc<dyn Fn(((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), Nat)) -> Rc<dyn prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>>>
    }))
}

/// The step machine of `BindParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BindParts: unbounded fn Wx, Env, Env, [Wres], [Pattern] -> ((Wx, Env, Env))
/// ```
pub struct BindParts {
    pub wx: crate::lower::node_::Wx,
    pub benv: crate::lower::types::Env,
    pub menv: crate::lower::types::Env,
    pub parts: Array<crate::lower::node_::Wres>,
    pub ps: Array<crate::syntax::Pattern_>,
}

impl prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)> for BindParts {
    fn cycle(&self) -> prism_rtl::Turn<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)> {
        let wx = &self.wx;
        let benv = &self.benv;
        let menv = &self.menv;
        let parts = &self.parts;
        let ps = &self.ps;
        fold_job(crate::check::errors::range0(&len(ps)), (wx.clone(), benv.clone(), menv.clone()), {
            let ps = ps.clone();
            let parts = parts.clone();
            Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), Nat)| {
                let ps = ps.clone();
                let parts = parts.clone();
                entered(once_job(move || {
                    let (w, be, me) = p0;
                    let i = p1;
                    match (index(&ps, &i), index(&parts, &i)) {
                        (Some(p_), Some(part)) => match (part.clone(), (*p_.kind).clone()) {
                            (crate::lower::node_::Wres::WrEv(r), crate::syntax::PatternKind::PName(_)) => prism_rtl::Turn::Finished((bind_res(&w, &me, &p_, &part), be.clone(), me.clone())),
                            (crate::lower::node_::Wres::WrParts(inner), crate::syntax::PatternKind::PTuple(qs)) => prism_rtl::Turn::More(Rc::new(BindParts { wx: w.clone(), benv: be.clone(), menv: me.clone(), parts: inner.clone(), ps: qs.clone() })),
                            (_, crate::syntax::PatternKind::PName(n)) => match &part {
                                crate::lower::node_::Wres::WrUnit => prism_rtl::Turn::Finished((w.clone(), be.clone(), me.clone())),
                                crate::lower::node_::Wres::WrDyn(ex, rds, t) => {
                                    let b = crate::lower::types::Bn::BnDyn(ex.clone(), rds.clone(), t.clone());
                                    prism_rtl::Turn::Finished(result_getter(&w, &me, &n, ex, rds, t, &crate::lower::types::bind(&be, &crate::check::env::sname_key(&n), &b), &crate::lower::types::bind(&me, &crate::check::env::sname_key(&n), &b)))
                                },
                                _ => {
                                    let b = bundle_bn(&part);
                                    prism_rtl::Turn::Finished((w.clone(), crate::lower::types::bind(&be, &crate::check::env::sname_key(&n), &b), crate::lower::types::bind(&me, &crate::check::env::sname_key(&n), &b)))
                                },
                            },
                            _ => prism_rtl::Turn::Finished((w.clone(), be.clone(), me.clone())),
                        },
                        _ => prism_rtl::Turn::Finished((w.clone(), be.clone(), me.clone())),
                    }
                }))
            }) as Rc<dyn Fn(((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), Nat)) -> Rc<dyn prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>>>
        }).cycle()
    }
}

/// `Start BindParts, x`: what the function value is when passed to `@Run`.
pub fn start_bind_parts(wx: crate::lower::node_::Wx, benv: crate::lower::types::Env, menv: crate::lower::types::Env, parts: Array<crate::lower::node_::Wres>, ps: Array<crate::syntax::Pattern_>) -> Rc<dyn prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>> {
    Rc::new(BindParts { wx, benv, menv, parts, ps })
}

/// ```prism
/// ResultGetter: fn Wx, Env, SName, Ex, [Read], OutTy, Env, Env -> ((Wx, Env, Env))
/// ```
pub fn result_getter(wx: &crate::lower::node_::Wx, menv: &crate::lower::types::Env, n: &crate::syntax::SName, ex: &crate::lower::model::Ex, rds: &Array<crate::lower::node_::Read>, t: &crate::lower::model::OutTy, benv2: &crate::lower::types::Env, menv2: &crate::lower::types::Env) -> (crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env) {
    'm15540: {
        let scrutinee = &get(&menv.names, &crate::check::env::sname_key(n));
        if let Some(crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(m15540_0_0_0, rs, _), m15540_0_1, _)) = scrutinee && let crate::lower::model::Ex::XSelf = &**m15540_0_0_0 && (m15540_0_1.len() == 1) && let Some(crate::lower::node_::Read::OwnRead(r0)) = index(m15540_0_1, &Nat::from(0u32)) && ((&r0 == rs) && !crate::check::types::has_text(&keys(&wx.dyn_reads), rs)) {
            break 'm15540 {
                let getter = crate::lower::model::MethDef { name: rs.clone(), recv: crate::lower::model::Recv::RecvRef, params: Array::new(), cx_: crate::lower::model::CxArg::CxRef, ret: t.clone(), body: Array::new(), tail: ex.clone(), doc: Text::from(format!("`{}`, a widget\'s result", &crate::check::env::sname_key(n))) };
                let wx2 = {
                    let mut this: crate::lower::node_::Wx = wx.clone();
                    this.getters = push(&this.getters, &getter);
                    this.dyn_reads = insert(&this.dyn_reads, rs, rds);
                    this
                };
                (wx2.clone(), benv2.clone(), menv2.clone())
            };
        }
        (wx.clone(), benv2.clone(), menv2.clone())
    }
}

/// ```prism
/// BundleBn: fn Wres -> Bn
/// ```
pub fn bundle_bn(res: &crate::lower::node_::Wres) -> crate::lower::types::Bn {
    match res {
        crate::lower::node_::Wres::WrEv(r) => crate::lower::types::Bn::BnEv(r.clone(), crate::lower::model::OutTy::OutUnit),
        crate::lower::node_::Wres::WrDyn(ex, rds, t) => crate::lower::types::Bn::BnDyn(ex.clone(), rds.clone(), t.clone()),
        crate::lower::node_::Wres::WrPlain(ex, t) => crate::lower::types::Bn::BnLocal(ex.clone(), crate::lower::types::Holding::Owned, t.clone()),
        crate::lower::node_::Wres::WrParts(parts) => crate::lower::types::Bn::BnParts(each(parts, &(|q: &crate::lower::node_::Wres| Some(bundle_bn(q))))),
        crate::lower::node_::Wres::WrHosted(inner, _) => bundle_bn(&**inner),
        crate::lower::node_::Wres::WrUnit => crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XUnit, crate::lower::types::Holding::Owned, crate::lower::model::OutTy::OutUnit),
    }
}

/// ```prism
/// BnRes: fn Bn -> Wres
/// ```
pub fn bn_res(b: &crate::lower::types::Bn) -> crate::lower::node_::Wres {
    match b {
        crate::lower::types::Bn::BnEv(r, _) => crate::lower::node_::Wres::WrEv(r.clone()),
        crate::lower::types::Bn::BnDyn(ex, rds, t) => crate::lower::node_::Wres::WrDyn(ex.clone(), rds.clone(), t.clone()),
        crate::lower::types::Bn::BnLocal(ex, _, t) => if t == &crate::lower::model::OutTy::OutUnit {
            crate::lower::node_::Wres::WrUnit
        } else {
            crate::lower::node_::Wres::WrPlain(ex.clone(), t.clone())
        },
        crate::lower::types::Bn::BnParts(bs) => crate::lower::node_::Wres::WrParts(each(bs, &part_res)),
        _ => crate::lower::node_::Wres::WrUnit,
    }
}

/// ```prism
/// PartRes: fn ?Bn -> Wres
/// ```
pub fn part_res(b_opt: &Option<crate::lower::types::Bn>) -> crate::lower::node_::Wres {
    match b_opt {
        Some(b) => bn_res(b),
        None => crate::lower::node_::Wres::WrUnit,
    }
}

/// ```prism
/// SetResult: fn Wx, Wres -> Wx
/// ```
pub fn set_result(wx: &crate::lower::node_::Wx, res: &crate::lower::node_::Wres) -> crate::lower::node_::Wx {
    let mut this: crate::lower::node_::Wx = wx.clone();
    this.result = res.clone();
    this
}

/// ```prism
/// ResultOf: unbounded fn Wx, Env, Env, Expr -> ((Wres, Wx))
/// ```
pub fn result_of(wx: &crate::lower::node_::Wx, benv: &crate::lower::types::Env, menv: &crate::lower::types::Env, x: &crate::syntax::Expr) -> (crate::lower::node_::Wres, crate::lower::node_::Wx) {
    let lx = wx.lx.clone();
    let full = crate::lower::type_at(&lx, &x.span);
    let t = crate::lower::types::out_ty_of(&lx, &crate::lower::types::peel(&full));
    let bound_opt = match &*x.kind {
        crate::syntax::ExprKind::EName(n) => if &len(&n.path_) == &Nat::from(1u32) {
            get(&menv.names, &crate::check::env::sname_key(n))
        } else {
            None
        },
        _ => None,
    };
    match &bound_opt {
        Some(crate::lower::types::Bn::BnEv(r, _)) => (crate::lower::node_::Wres::WrEv(r.clone()), wx.clone()),
        Some(crate::lower::types::Bn::BnDyn(ex, rds, bt)) => (crate::lower::node_::Wres::WrDyn(ex.clone(), rds.clone(), bt.clone()), wx.clone()),
        Some(crate::lower::types::Bn::BnParts(bs)) => (bn_res(&crate::lower::types::Bn::BnParts(bs.clone())), wx.clone()),
        _ => match &*x.kind {
            crate::syntax::ExprKind::ETuple(xs) if crate::lower::types::is_bundle(&full) => {
                let (parts, wx2) = run_to_end(fold_job(xs.clone(), (Array::new(), wx.clone()), {
                    let benv = benv.clone();
                    let menv = menv.clone();
                    Rc::new(move |(p0, p1): ((Array<crate::lower::node_::Wres>, crate::lower::node_::Wx), crate::syntax::Expr)| {
                        let benv = benv.clone();
                        let menv = menv.clone();
                        entered(once_job(move || {
                            let (acc, w) = p0;
                            let y = p1;
                            call_then(start_result_of(w.clone(), benv.clone(), menv.clone(), y.clone()), move |result_of_17677: (crate::lower::node_::Wres, crate::lower::node_::Wx)| {
                                let (r, w2) = result_of_17677;
                                prism_rtl::Turn::Finished((push(&acc, &r), w2.clone()))
                            })
                        }))
                    }) as Rc<dyn Fn(((Array<crate::lower::node_::Wres>, crate::lower::node_::Wx), crate::syntax::Expr)) -> Rc<dyn prism_rtl::Job<(Array<crate::lower::node_::Wres>, crate::lower::node_::Wx)>>>
                }));
                (crate::lower::node_::Wres::WrParts(parts.clone()), wx2.clone())
            },
            _ => result_of_typed(wx, benv, menv, x, &full, &t),
            _ => unreachable!("no arm matched"),
        },
    }
}

/// The step machine of `ResultOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ResultOf: unbounded fn Wx, Env, Env, Expr -> ((Wres, Wx))
/// ```
pub struct ResultOf {
    pub wx: crate::lower::node_::Wx,
    pub benv: crate::lower::types::Env,
    pub menv: crate::lower::types::Env,
    pub x: crate::syntax::Expr,
}

impl prism_rtl::Job<(crate::lower::node_::Wres, crate::lower::node_::Wx)> for ResultOf {
    fn cycle(&self) -> prism_rtl::Turn<(crate::lower::node_::Wres, crate::lower::node_::Wx)> {
        let wx = &self.wx;
        let benv = &self.benv;
        let menv = &self.menv;
        let x = &self.x;
        let lx = wx.lx.clone();
        let full = crate::lower::type_at(&lx, &x.span);
        let benv = benv.clone();
        let menv = menv.clone();
        let wx = wx.clone();
        let x = x.clone();
        call_then(crate::lower::types::start_out_ty_of(lx.clone(), crate::lower::types::peel(&full)), move |out_ty_of_17086: crate::lower::model::OutTy| {
            let t = out_ty_of_17086;
            let bound_opt = match &*x.kind {
                crate::syntax::ExprKind::EName(n) => if &len(&n.path_) == &Nat::from(1u32) {
                    get(&menv.names, &crate::check::env::sname_key(n))
                } else {
                    None
                },
                _ => None,
            };
            match &bound_opt {
                Some(crate::lower::types::Bn::BnEv(r, _)) => prism_rtl::Turn::Finished((crate::lower::node_::Wres::WrEv(r.clone()), wx.clone())),
                Some(crate::lower::types::Bn::BnDyn(ex, rds, bt)) => prism_rtl::Turn::Finished((crate::lower::node_::Wres::WrDyn(ex.clone(), rds.clone(), bt.clone()), wx.clone())),
                Some(crate::lower::types::Bn::BnParts(bs)) => prism_rtl::Turn::Finished((bn_res(&crate::lower::types::Bn::BnParts(bs.clone())), wx.clone())),
                _ => match &*x.kind {
                    crate::syntax::ExprKind::ETuple(xs) if crate::lower::types::is_bundle(&full) => {
                        let xs = xs.clone();
                        call_value(fold_job(xs.clone(), (Array::new(), wx.clone()), {
                            let benv = benv.clone();
                            let menv = menv.clone();
                            Rc::new(move |(p0, p1): ((Array<crate::lower::node_::Wres>, crate::lower::node_::Wx), crate::syntax::Expr)| {
                                let benv = benv.clone();
                                let menv = menv.clone();
                                entered(once_job(move || {
                                    let (acc, w) = p0;
                                    let y = p1;
                                    call_then(start_result_of(w.clone(), benv.clone(), menv.clone(), y.clone()), move |result_of_17677: (crate::lower::node_::Wres, crate::lower::node_::Wx)| {
                                        let (r, w2) = result_of_17677;
                                        prism_rtl::Turn::Finished((push(&acc, &r), w2.clone()))
                                    })
                                }))
                            }) as Rc<dyn Fn(((Array<crate::lower::node_::Wres>, crate::lower::node_::Wx), crate::syntax::Expr)) -> Rc<dyn prism_rtl::Job<(Array<crate::lower::node_::Wres>, crate::lower::node_::Wx)>>>
                        }), move |fold_17601: (Array<crate::lower::node_::Wres>, crate::lower::node_::Wx)| {
                            let (parts, wx2) = fold_17601;
                            prism_rtl::Turn::Finished((crate::lower::node_::Wres::WrParts(parts.clone()), wx2.clone()))
                        })
                    },
                    _ => prism_rtl::Turn::More(Rc::new(ResultOfTyped { wx: wx.clone(), benv: benv.clone(), menv: menv.clone(), x: x.clone(), full: full.clone(), t: t.clone() })),
                    _ => unreachable!("no arm matched"),
                },
            }
        })
    }
}

/// `Start ResultOf, x`: what the function value is when passed to `@Run`.
pub fn start_result_of(wx: crate::lower::node_::Wx, benv: crate::lower::types::Env, menv: crate::lower::types::Env, x: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<(crate::lower::node_::Wres, crate::lower::node_::Wx)>> {
    Rc::new(ResultOf { wx, benv, menv, x })
}

/// ```prism
/// ResultOfTyped: unbounded fn Wx, Env, Env, Expr, Ty, OutTy -> ((Wres, Wx))
/// ```
pub fn result_of_typed(wx: &crate::lower::node_::Wx, benv: &crate::lower::types::Env, menv: &crate::lower::types::Env, x: &crate::syntax::Expr, full: &crate::check::types::Ty, t: &crate::lower::model::OutTy) -> (crate::lower::node_::Wres, crate::lower::node_::Wx) {
    let lx = wx.lx.clone();
    match crate::lower::types::layer_of(full) {
        crate::lower::types::Layer::LyEv => {
            let (r, wx2) = crate::lower::node_::dynamics::event_ref(wx, menv, x);
            (crate::lower::node_::Wres::WrEv(r.clone()), wx2.clone())
        },
        crate::lower::types::Layer::LyDyn => {
            let (ex, reads) = crate::lower::node_::dynamics::dynamic_expr(wx, menv, x);
            (crate::lower::node_::Wres::WrDyn(ex.clone(), reads.clone(), t.clone()), wx.clone())
        },
        _ => if t == &crate::lower::model::OutTy::OutUnit {
            (crate::lower::node_::Wres::WrUnit, wx.clone())
        } else {
            (crate::lower::node_::Wres::WrPlain(crate::lower::types::own(&crate::lower::expr::value_of(&lx, benv, x)), t.clone()), wx.clone())
        },
    }
}

/// The step machine of `ResultOfTyped`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ResultOfTyped: unbounded fn Wx, Env, Env, Expr, Ty, OutTy -> ((Wres, Wx))
/// ```
pub struct ResultOfTyped {
    pub wx: crate::lower::node_::Wx,
    pub benv: crate::lower::types::Env,
    pub menv: crate::lower::types::Env,
    pub x: crate::syntax::Expr,
    pub full: crate::check::types::Ty,
    pub t: crate::lower::model::OutTy,
}

impl prism_rtl::Job<(crate::lower::node_::Wres, crate::lower::node_::Wx)> for ResultOfTyped {
    fn cycle(&self) -> prism_rtl::Turn<(crate::lower::node_::Wres, crate::lower::node_::Wx)> {
        let wx = &self.wx;
        let benv = &self.benv;
        let menv = &self.menv;
        let x = &self.x;
        let full = &self.full;
        let t = &self.t;
        let lx = wx.lx.clone();
        match crate::lower::types::layer_of(full) {
            crate::lower::types::Layer::LyEv => {
                let menv = menv.clone();
                let wx = wx.clone();
                let x = x.clone();
                call_then(crate::lower::node_::dynamics::start_event_ref(wx.clone(), menv.clone(), x.clone()), move |event_ref_18054: (crate::lower::node_::EvRef, crate::lower::node_::Wx)| {
                    let (r, wx2) = event_ref_18054;
                    prism_rtl::Turn::Finished((crate::lower::node_::Wres::WrEv(r.clone()), wx2.clone()))
                })
            },
            crate::lower::types::Layer::LyDyn => {
                let menv = menv.clone();
                let t = t.clone();
                let wx = wx.clone();
                let x = x.clone();
                call_then(crate::lower::node_::dynamics::start_dynamic_expr(wx.clone(), menv.clone(), x.clone()), move |dynamic_expr_18150: (crate::lower::model::Ex, Array<crate::lower::node_::Read>)| {
                    let (ex, reads) = dynamic_expr_18150;
                    prism_rtl::Turn::Finished((crate::lower::node_::Wres::WrDyn(ex.clone(), reads.clone(), t.clone()), wx.clone()))
                })
            },
            _ => if t == &crate::lower::model::OutTy::OutUnit {
                prism_rtl::Turn::Finished((crate::lower::node_::Wres::WrUnit, wx.clone()))
            } else {
                {
                    let benv = benv.clone();
                    let t = t.clone();
                    let wx = wx.clone();
                    let x = x.clone();
                    call_then(crate::lower::expr::start_value_of(lx.clone(), benv.clone(), x.clone()), move |value_of_18313: crate::lower::types::Vl| prism_rtl::Turn::Finished((crate::lower::node_::Wres::WrPlain(crate::lower::types::own(&value_of_18313), t.clone()), wx.clone())))
                }
            },
        }
    }
}

/// `Start ResultOfTyped, x`: what the function value is when passed to `@Run`.
pub fn start_result_of_typed(wx: crate::lower::node_::Wx, benv: crate::lower::types::Env, menv: crate::lower::types::Env, x: crate::syntax::Expr, full: crate::check::types::Ty, t: crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<(crate::lower::node_::Wres, crate::lower::node_::Wx)>> {
    Rc::new(ResultOfTyped { wx, benv, menv, x, full, t })
}

/// ```prism
/// HoldLine: unbounded fn Wx, Env, Env, Pattern, Expr, Expr -> ((Wx, Env))
/// ```
pub fn hold_line(wx: &crate::lower::node_::Wx, benv: &crate::lower::types::Env, menv: &crate::lower::types::Env, p_: &crate::syntax::Pattern_, init: &crate::syntax::Expr, step_: &crate::syntax::Expr) -> (crate::lower::node_::Wx, crate::lower::types::Env) {
    let lx = wx.lx.clone();
    match binding_of(menv, p_) {
        Some(crate::lower::types::Bn::BnHold(f, t)) => {
            let iv = crate::lower::types::own(&crate::lower::expr::value_of(&lx, benv, init));
            let wx1 = crate::lower::node_::add_field(wx, &f, &crate::lower::model::OutTy::OutHold(Rc::new(t.clone())), &Text::from(format!("`{}`", &pat_text(p_))), &crate::lower::model::Ex::XCall(Text::lit("Hold::new"), Array::from(vec![crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(Text::from(format!("{}_init", &f))))), crate::lower::model::Ex::XCx])));
            let (r, wx2) = crate::lower::node_::dynamics::event_ref(&wx1, menv, step_);
            let wx3 = {
                let mut this: crate::lower::node_::Wx = crate::lower::node_::connect(&wx2, &r, &crate::lower::node_::Sk::SkHold(f.clone()));
                this.lets = push(&this.lets, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaBind(Text::from(format!("{}_init", &f)))), t.clone()), iv.clone()));
                this.inited = push(&this.inited, &f);
                this
            };
            (wx3.clone(), crate::lower::types::bind(benv, &Text::from(format!("{}#init", &pat_text(p_))), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(Text::from(format!("{}_init", &f))), crate::lower::types::Holding::Owned, t.clone())))
        },
        _ => (wx.clone(), benv.clone()),
    }
}

/// The step machine of `HoldLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// HoldLine: unbounded fn Wx, Env, Env, Pattern, Expr, Expr -> ((Wx, Env))
/// ```
pub struct HoldLine {
    pub wx: crate::lower::node_::Wx,
    pub benv: crate::lower::types::Env,
    pub menv: crate::lower::types::Env,
    pub p_: crate::syntax::Pattern_,
    pub init: crate::syntax::Expr,
    pub step_: crate::syntax::Expr,
}

impl prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env)> for HoldLine {
    fn cycle(&self) -> prism_rtl::Turn<(crate::lower::node_::Wx, crate::lower::types::Env)> {
        let wx = &self.wx;
        let benv = &self.benv;
        let menv = &self.menv;
        let p_ = &self.p_;
        let init = &self.init;
        let step_ = &self.step_;
        let lx = wx.lx.clone();
        match binding_of(menv, p_) {
            Some(crate::lower::types::Bn::BnHold(f, t)) => {
                let benv = benv.clone();
                let init = init.clone();
                let menv = menv.clone();
                let p_ = p_.clone();
                let step_ = step_.clone();
                let wx = wx.clone();
                call_then(crate::lower::expr::start_value_of(lx.clone(), benv.clone(), init.clone()), move |value_of_18868: crate::lower::types::Vl| {
                    let iv = crate::lower::types::own(&value_of_18868);
                    let wx1 = crate::lower::node_::add_field(&wx, &f, &crate::lower::model::OutTy::OutHold(Rc::new(t.clone())), &Text::from(format!("`{}`", &pat_text(&p_))), &crate::lower::model::Ex::XCall(Text::lit("Hold::new"), Array::from(vec![crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(Text::from(format!("{}_init", &f))))), crate::lower::model::Ex::XCx])));
                    call_then(crate::lower::node_::dynamics::start_event_ref(wx1.clone(), menv.clone(), step_.clone()), move |event_ref_19046: (crate::lower::node_::EvRef, crate::lower::node_::Wx)| {
                        let (r, wx2) = event_ref_19046;
                        let wx3 = {
                            let mut this: crate::lower::node_::Wx = crate::lower::node_::connect(&wx2, &r, &crate::lower::node_::Sk::SkHold(f.clone()));
                            this.lets = push(&this.lets, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaBind(Text::from(format!("{}_init", &f)))), t.clone()), iv.clone()));
                            this.inited = push(&this.inited, &f);
                            this
                        };
                        prism_rtl::Turn::Finished((wx3.clone(), crate::lower::types::bind(&benv, &Text::from(format!("{}#init", &pat_text(&p_))), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(Text::from(format!("{}_init", &f))), crate::lower::types::Holding::Owned, t.clone()))))
                    })
                })
            },
            _ => prism_rtl::Turn::Finished((wx.clone(), benv.clone())),
        }
    }
}

/// `Start HoldLine, x`: what the function value is when passed to `@Run`.
pub fn start_hold_line(wx: crate::lower::node_::Wx, benv: crate::lower::types::Env, menv: crate::lower::types::Env, p_: crate::syntax::Pattern_, init: crate::syntax::Expr, step_: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env)>> {
    Rc::new(HoldLine { wx, benv, menv, p_, init, step_ })
}

/// ```prism
/// InitEnv: fn Env -> Env
/// ```
pub fn init_env(env: &crate::lower::types::Env) -> crate::lower::types::Env {
    fold(&keys(&env.names), env, &(|en: &crate::lower::types::Env, k: &Text| match (crate::syntax::lexer::chars::before_suffix(k, &Text::lit("#init")), get(&env.names, k)) {
        (Some(name), Some(b)) => crate::lower::types::bind(en, &name, &b),
        _ => en.clone(),
    }))
}

/// ```prism
/// AllInited: fn Wx, [Read] -> Bool
/// ```
pub fn all_inited(wx: &crate::lower::node_::Wx, reads: &Array<crate::lower::node_::Read>) -> bool {
    fold(&crate::lower::node_::finish::reads_closed(&wx.dyn_reads, reads), &true, &(|ok_: &bool, r: &crate::lower::node_::Read| *ok_ && match r {
        crate::lower::node_::Read::OwnRead(f) => crate::check::types::has_text(&wx.inited, f),
        crate::lower::node_::Read::ParentRead(_) => false,
    }))
}

/// ```prism
/// NamesInited: unbounded fn Env, Expr -> Bool
/// ```
pub fn names_inited(env: &crate::lower::types::Env, e: &crate::syntax::Expr) -> bool {
    fold(&crate::lower::expr::read_names(&crate::check::typed::print::exprs_in(e)), &true, &(|ok_: &bool, n: &Text| *ok_ && match get(&env.names, n) {
        Some(crate::lower::types::Bn::BnDyn(_, _, _)) => crate::check::env::has_key(&env.names, &Text::from(format!("{}#init", n))),
        Some(crate::lower::types::Bn::BnHold(_, _)) => crate::check::env::has_key(&env.names, &Text::from(format!("{}#init", n))),
        _ => true,
    }))
}

/// The step machine of `NamesInited`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// NamesInited: unbounded fn Env, Expr -> Bool
/// ```
pub struct NamesInited {
    pub env: crate::lower::types::Env,
    pub e: crate::syntax::Expr,
}

impl prism_rtl::Job<bool> for NamesInited {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let env = &self.env;
        let e = &self.e;
        let e = e.clone();
        let env = env.clone();
        call_then(crate::check::typed::print::start_exprs_in(e.clone()), move |exprs_in_20565: Array<crate::syntax::Expr>| call_then(crate::lower::expr::start_read_names(exprs_in_20565), move |read_names_20554: Array<Text>| prism_rtl::Turn::Finished(fold(&read_names_20554, &true, &(|ok_: &bool, n: &Text| *ok_ && match get(&env.names, n) {
            Some(crate::lower::types::Bn::BnDyn(_, _, _)) => crate::check::env::has_key(&env.names, &Text::from(format!("{}#init", n))),
            Some(crate::lower::types::Bn::BnHold(_, _)) => crate::check::env::has_key(&env.names, &Text::from(format!("{}#init", n))),
            _ => true,
        })))))
    }
}

/// `Start NamesInited, x`: what the function value is when passed to `@Run`.
pub fn start_names_inited(env: crate::lower::types::Env, e: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(NamesInited { env, e })
}

/// ```prism
/// PatText: fn Pattern -> Text
/// ```
pub fn pat_text(p_: &crate::syntax::Pattern_) -> Text {
    match &*p_.kind {
        crate::syntax::PatternKind::PName(n) => crate::check::env::sname_key(n),
        _ => Text::lit("_"),
    }
}

/// ```prism
/// LetLine: unbounded fn Wx, Env, Env, Pattern, Expr -> ((Wx, Env))
/// ```
pub fn let_line(wx: &crate::lower::node_::Wx, benv: &crate::lower::types::Env, menv: &crate::lower::types::Env, p_: &crate::syntax::Pattern_, e: &crate::syntax::Expr) -> (crate::lower::node_::Wx, crate::lower::types::Env) {
    let lx = wx.lx.clone();
    match binding_of(menv, p_) {
        Some(crate::lower::types::Bn::BnEv(er, t)) => {
            let (r, wx2) = crate::lower::node_::dynamics::event_ref(wx, menv, e);
            let fed = crate::lower::types::out_ty_of(&lx, &crate::lower::types::peel(&crate::lower::types::peel(&crate::lower::type_at(&lx, &e.span))));
            let r2 = 'm21441: {
                if let crate::lower::model::OutTy::OutEvent(m21441_0_0) = &t && let crate::lower::model::OutTy::OutRes(_) = &**m21441_0_0 {
                    break 'm21441 if &fed == &crate::lower::model::OutTy::OutError { err_pipe(&r) } else { r.clone() };
                }
                if let crate::lower::model::OutTy::OutRes(_) = &t {
                    break 'm21441 if &fed == &crate::lower::model::OutTy::OutError { err_pipe(&r) } else { r.clone() };
                }
                r.clone()
            };
            (crate::lower::node_::connect(&wx2, &r2, &crate::lower::node_::Sk::SkNode(er.node_.clone())), benv.clone())
        },
        Some(crate::lower::types::Bn::BnDyn(_, _, t)) => {
            let rs = crate::lower::snake(&pat_text(p_));
            let (ex, reads) = crate::lower::node_::dynamics::dynamic_expr(wx, menv, e);
            let cached = (&len(&reads) > &Nat::from(0u32)) && fold(&crate::lower::node_::finish::reads_all(&wx.dyn_reads, &reads), &true, &(|ok_: &bool, r: &crate::lower::node_::Read| *ok_ && crate::lower::node_::finish::is_own_read(r)));
            let tail = if cached {
                crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_cache", &rs)))), Text::lit("get"), Array::from(vec![crate::lower::model::Ex::XCx, crate::lower::model::Ex::XClosure(false, Array::new(), Rc::new(ex.clone()))]))
            } else {
                ex.clone()
            };
            let getter = crate::lower::model::MethDef { name: rs.clone(), recv: crate::lower::model::Recv::RecvRef, params: Array::new(), cx_: crate::lower::model::CxArg::CxRef, ret: t.clone(), body: Array::new(), tail: tail.clone(), doc: Text::from(format!("`{}`", &pat_text(p_))) };
            let wx1 = if cached {
                {
                    let mut this: crate::lower::node_::Wx = crate::lower::node_::add_field(wx, &Text::from(format!("{}_cache", &rs)), &crate::lower::model::OutTy::OutNamed(Text::lit("Cache"), Array::from(vec![t.clone()])), &Text::from(format!("`{}`, cached", &pat_text(p_))), &crate::lower::model::Ex::XCall(Text::lit("Cache::new"), Array::new()));
                    this.let_caches = push(&this.let_caches, &rs);
                    this.taken = push(&this.taken, &Text::from(format!("{}_cache", &rs)));
                    this
                }
            } else {
                wx.clone()
            };
            let wx2 = {
                let mut this: crate::lower::node_::Wx = wx1.clone();
                this.getters = push(&this.getters, &getter);
                this.dyn_reads = insert(&this.dyn_reads, &rs, &reads);
                this
            };
            if all_inited(&wx2, &reads) && names_inited(benv, e) {
                {
                    let wx3 = {
                        let mut this: crate::lower::node_::Wx = wx2.clone();
                        this.lets = push(&this.lets, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaBind(Text::from(format!("{}_init", &rs)))), t.clone()), crate::lower::types::own(&crate::lower::expr::value_of(&lx, &init_env(benv), e))));
                        this.inited = push(&this.inited, &rs);
                        this
                    };
                    (wx3.clone(), crate::lower::types::bind(benv, &Text::from(format!("{}#init", &pat_text(p_))), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(Text::from(format!("{}_init", &rs))), crate::lower::types::Holding::Owned, t.clone())))
                }
            } else {
                (wx2.clone(), benv.clone())
            }
        },
        Some(crate::lower::types::Bn::BnLocal(rs, _, t)) => {
            let insts_opt = match &*p_.kind {
                crate::syntax::PatternKind::PName(n) => many_instances(&lx, &n.span),
                _ => None,
            };
            match &insts_opt {
                Some(insts) => match &*p_.kind {
                    crate::syntax::PatternKind::PName(n) => {
                        let nkey = crate::check::env::sname_key(n);
                        let wxn = run_to_end(fold_job(crate::check::errors::range0(&len(insts)), wx.clone(), {
                            let lx = lx.clone();
                            let insts = insts.clone();
                            let nkey = nkey.clone();
                            let menv = menv.clone();
                            let benv = benv.clone();
                            let e = e.clone();
                            Rc::new(move |(p0, p1): (crate::lower::node_::Wx, Nat)| {
                                let lx = lx.clone();
                                let insts = insts.clone();
                                let nkey = nkey.clone();
                                let menv = menv.clone();
                                let benv = benv.clone();
                                let e = e.clone();
                                entered(once_job(move || {
                                    let w = p0;
                                    let k = p1;
                                    {
                                        let lxk = crate::lower::expr::at_instance(&lx, &or(&index(&insts, &k), &(Array::new(), Array::new())));
                                        let bkey = if &k == &Nat::from(0u32) {
                                            nkey.clone()
                                        } else {
                                            Text::from(format!("{}#inst{}", &nkey, &k))
                                        };
                                        match get(&menv.names, &bkey) {
                                            Some(crate::lower::types::Bn::BnLocal(rk, _, tk)) => call_then(crate::lower::expr::start_value_of(lxk.clone(), benv.clone(), e.clone()), move |value_of_24102: crate::lower::types::Vl| prism_rtl::Turn::Finished(widget_let_field(&w, &crate::lower::types::place_stem(&rk), &tk, &crate::lower::types::own(&value_of_24102), &Text::from(format!("`{}` at its instantiation {}", &nkey, &k))))),
                                            _ => prism_rtl::Turn::Finished({
                                                let mut this: crate::lower::node_::Wx = w.clone();
                                                this.build = push(&this.build, &crate::lower::expr::refusal_do(&Text::from(format!("`{}` at its instantiation {}, which has no binding", &nkey, &k))));
                                                this
                                            }),
                                        }
                                    }
                                }))
                            }) as Rc<dyn Fn((crate::lower::node_::Wx, Nat)) -> Rc<dyn prism_rtl::Job<crate::lower::node_::Wx>>>
                        }));
                        (wxn.clone(), benv.clone())
                    },
                    _ => (wx.clone(), benv.clone()),
                },
                None => {
                    let lxw = match &*p_.kind {
                        crate::syntax::PatternKind::PName(n) => crate::lower::expr::widget_let_lx(&lx, &n.span),
                        _ => lx.clone(),
                    };
                    let v_ = crate::lower::types::own(&crate::lower::expr::value_of(&lxw, benv, e));
                    (widget_let_field(wx, &crate::lower::types::place_stem(&rs), &t, &v_, &Text::from(format!("`{}`", &pat_text(p_)))), benv.clone())
                },
            }
        },
        _ => (wx.clone(), benv.clone()),
    }
}

/// The step machine of `LetLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LetLine: unbounded fn Wx, Env, Env, Pattern, Expr -> ((Wx, Env))
/// ```
pub struct LetLine {
    pub wx: crate::lower::node_::Wx,
    pub benv: crate::lower::types::Env,
    pub menv: crate::lower::types::Env,
    pub p_: crate::syntax::Pattern_,
    pub e: crate::syntax::Expr,
}

impl prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env)> for LetLine {
    fn cycle(&self) -> prism_rtl::Turn<(crate::lower::node_::Wx, crate::lower::types::Env)> {
        let wx = &self.wx;
        let benv = &self.benv;
        let menv = &self.menv;
        let p_ = &self.p_;
        let e = &self.e;
        let lx = wx.lx.clone();
        match binding_of(menv, p_) {
            Some(crate::lower::types::Bn::BnEv(er, t)) => {
                let benv = benv.clone();
                let e = e.clone();
                let menv = menv.clone();
                let wx = wx.clone();
                call_then(crate::lower::node_::dynamics::start_event_ref(wx.clone(), menv.clone(), e.clone()), move |event_ref_21331: (crate::lower::node_::EvRef, crate::lower::node_::Wx)| {
                    let (r, wx2) = event_ref_21331;
                    call_then(crate::lower::types::start_out_ty_of(lx.clone(), crate::lower::types::peel(&crate::lower::types::peel(&crate::lower::type_at(&lx, &e.span)))), move |out_ty_of_21374: crate::lower::model::OutTy| {
                        let fed = out_ty_of_21374;
                        let r2 = 'm21441: {
                            if let crate::lower::model::OutTy::OutEvent(m21441_0_0) = &t && let crate::lower::model::OutTy::OutRes(_) = &**m21441_0_0 {
                                break 'm21441 if &fed == &crate::lower::model::OutTy::OutError { err_pipe(&r) } else { r.clone() };
                            }
                            if let crate::lower::model::OutTy::OutRes(_) = &t {
                                break 'm21441 if &fed == &crate::lower::model::OutTy::OutError { err_pipe(&r) } else { r.clone() };
                            }
                            r.clone()
                        };
                        prism_rtl::Turn::Finished((crate::lower::node_::connect(&wx2, &r2, &crate::lower::node_::Sk::SkNode(er.node_.clone())), benv.clone()))
                    })
                })
            },
            Some(crate::lower::types::Bn::BnDyn(_, _, t)) => {
                let rs = crate::lower::snake(&pat_text(p_));
                let benv = benv.clone();
                let e = e.clone();
                let menv = menv.clone();
                let p_ = p_.clone();
                let wx = wx.clone();
                call_then(crate::lower::node_::dynamics::start_dynamic_expr(wx.clone(), menv.clone(), e.clone()), move |dynamic_expr_21794: (crate::lower::model::Ex, Array<crate::lower::node_::Read>)| {
                    let (ex, reads) = dynamic_expr_21794;
                    let cached = (&len(&reads) > &Nat::from(0u32)) && fold(&crate::lower::node_::finish::reads_all(&wx.dyn_reads, &reads), &true, &(|ok_: &bool, r: &crate::lower::node_::Read| *ok_ && crate::lower::node_::finish::is_own_read(r)));
                    let tail = if cached {
                        crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_cache", &rs)))), Text::lit("get"), Array::from(vec![crate::lower::model::Ex::XCx, crate::lower::model::Ex::XClosure(false, Array::new(), Rc::new(ex.clone()))]))
                    } else {
                        ex.clone()
                    };
                    let getter = crate::lower::model::MethDef { name: rs.clone(), recv: crate::lower::model::Recv::RecvRef, params: Array::new(), cx_: crate::lower::model::CxArg::CxRef, ret: t.clone(), body: Array::new(), tail: tail.clone(), doc: Text::from(format!("`{}`", &pat_text(&p_))) };
                    let wx1 = if cached {
                        {
                            let mut this: crate::lower::node_::Wx = crate::lower::node_::add_field(&wx, &Text::from(format!("{}_cache", &rs)), &crate::lower::model::OutTy::OutNamed(Text::lit("Cache"), Array::from(vec![t.clone()])), &Text::from(format!("`{}`, cached", &pat_text(&p_))), &crate::lower::model::Ex::XCall(Text::lit("Cache::new"), Array::new()));
                            this.let_caches = push(&this.let_caches, &rs);
                            this.taken = push(&this.taken, &Text::from(format!("{}_cache", &rs)));
                            this
                        }
                    } else {
                        wx.clone()
                    };
                    let wx2 = {
                        let mut this: crate::lower::node_::Wx = wx1.clone();
                        this.getters = push(&this.getters, &getter);
                        this.dyn_reads = insert(&this.dyn_reads, &rs, &reads);
                        this
                    };
                    if all_inited(&wx2, &reads) && names_inited(&benv, &e) {
                        {
                            let wx3 = {
                                let mut this: crate::lower::node_::Wx = wx2.clone();
                                this.lets = push(&this.lets, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaBind(Text::from(format!("{}_init", &rs)))), t.clone()), crate::lower::types::own(&crate::lower::expr::value_of(&lx, &init_env(&benv), &e))));
                                this.inited = push(&this.inited, &rs);
                                this
                            };
                            prism_rtl::Turn::Finished((wx3.clone(), crate::lower::types::bind(&benv, &Text::from(format!("{}#init", &pat_text(&p_))), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(Text::from(format!("{}_init", &rs))), crate::lower::types::Holding::Owned, t.clone()))))
                        }
                    } else {
                        prism_rtl::Turn::Finished((wx2.clone(), benv.clone()))
                    }
                })
            },
            Some(crate::lower::types::Bn::BnLocal(rs, _, t)) => {
                let insts_opt = match &*p_.kind {
                    crate::syntax::PatternKind::PName(n) => many_instances(&lx, &n.span),
                    _ => None,
                };
                match &insts_opt {
                    Some(insts) => match &*p_.kind {
                        crate::syntax::PatternKind::PName(n) => {
                            let nkey = crate::check::env::sname_key(n);
                            let benv = benv.clone();
                            let e = e.clone();
                            let insts = insts.clone();
                            let menv = menv.clone();
                            let wx = wx.clone();
                            call_value(fold_job(crate::check::errors::range0(&len(&insts)), wx.clone(), {
                                let lx = lx.clone();
                                let insts = insts.clone();
                                let nkey = nkey.clone();
                                let menv = menv.clone();
                                let benv = benv.clone();
                                let e = e.clone();
                                Rc::new(move |(p0, p1): (crate::lower::node_::Wx, Nat)| {
                                    let lx = lx.clone();
                                    let insts = insts.clone();
                                    let nkey = nkey.clone();
                                    let menv = menv.clone();
                                    let benv = benv.clone();
                                    let e = e.clone();
                                    entered(once_job(move || {
                                        let w = p0;
                                        let k = p1;
                                        {
                                            let lxk = crate::lower::expr::at_instance(&lx, &or(&index(&insts, &k), &(Array::new(), Array::new())));
                                            let bkey = if &k == &Nat::from(0u32) {
                                                nkey.clone()
                                            } else {
                                                Text::from(format!("{}#inst{}", &nkey, &k))
                                            };
                                            match get(&menv.names, &bkey) {
                                                Some(crate::lower::types::Bn::BnLocal(rk, _, tk)) => call_then(crate::lower::expr::start_value_of(lxk.clone(), benv.clone(), e.clone()), move |value_of_24102: crate::lower::types::Vl| prism_rtl::Turn::Finished(widget_let_field(&w, &crate::lower::types::place_stem(&rk), &tk, &crate::lower::types::own(&value_of_24102), &Text::from(format!("`{}` at its instantiation {}", &nkey, &k))))),
                                                _ => prism_rtl::Turn::Finished({
                                                    let mut this: crate::lower::node_::Wx = w.clone();
                                                    this.build = push(&this.build, &crate::lower::expr::refusal_do(&Text::from(format!("`{}` at its instantiation {}, which has no binding", &nkey, &k))));
                                                    this
                                                }),
                                            }
                                        }
                                    }))
                                }) as Rc<dyn Fn((crate::lower::node_::Wx, Nat)) -> Rc<dyn prism_rtl::Job<crate::lower::node_::Wx>>>
                            }), move |fold_23746: crate::lower::node_::Wx| {
                                let wxn = fold_23746;
                                prism_rtl::Turn::Finished((wxn.clone(), benv.clone()))
                            })
                        },
                        _ => prism_rtl::Turn::Finished((wx.clone(), benv.clone())),
                    },
                    None => {
                        let lxw = match &*p_.kind {
                            crate::syntax::PatternKind::PName(n) => crate::lower::expr::widget_let_lx(&lx, &n.span),
                            _ => lx.clone(),
                        };
                        let benv = benv.clone();
                        let e = e.clone();
                        let p_ = p_.clone();
                        let wx = wx.clone();
                        call_then(crate::lower::expr::start_value_of(lxw.clone(), benv.clone(), e.clone()), move |value_of_24622: crate::lower::types::Vl| {
                            let v_ = crate::lower::types::own(&value_of_24622);
                            prism_rtl::Turn::Finished((widget_let_field(&wx, &crate::lower::types::place_stem(&rs), &t, &v_, &Text::from(format!("`{}`", &pat_text(&p_)))), benv.clone()))
                        })
                    },
                }
            },
            _ => prism_rtl::Turn::Finished((wx.clone(), benv.clone())),
        }
    }
}

/// `Start LetLine, x`: what the function value is when passed to `@Run`.
pub fn start_let_line(wx: crate::lower::node_::Wx, benv: crate::lower::types::Env, menv: crate::lower::types::Env, p_: crate::syntax::Pattern_, e: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env)>> {
    Rc::new(LetLine { wx, benv, menv, p_, e })
}

/// ```prism
/// WidgetLetField: fn Wx, Text, OutTy, Ex, Text -> Wx
/// ```
pub fn widget_let_field(wx: &crate::lower::node_::Wx, f: &Text, t: &crate::lower::model::OutTy, v_: &crate::lower::model::Ex, doc: &Text) -> crate::lower::node_::Wx {
    let mut this: crate::lower::node_::Wx = wx.clone();
    this.lets = push(&this.lets, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(f.clone()), v_.clone()));
    this.fields = push(&this.fields, &(f.clone(), t.clone(), doc.clone()));
    this.inits = push(&this.inits, &(f.clone(), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(f.clone())))));
    this
}

/// ```prism
/// ErrPipe: fn EvRef -> EvRef
/// ```
pub fn err_pipe(r: &crate::lower::node_::EvRef) -> crate::lower::node_::EvRef {
    crate::lower::node_::EvRef { node_: r.node_.clone(), owner: r.owner.clone(), pipe: {
        let r = r.clone();
        Rc::new(move |(p0, p1): (crate::lower::model::Ex, Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>)| {
            let r = r.clone();
            entered(once_job(move || {
                let x = p0;
                let k_fn = p1;
                (&r.pipe)((x.clone(), {
                    let k_fn = k_fn.clone();
                    Rc::new(move |p0: crate::lower::model::Ex| {
                        let k_fn = k_fn.clone();
                        entered(once_job(move || {
                            let y = p0;
                            (&k_fn)(crate::lower::model::Ex::XCtor(Text::lit("Err"), Array::from(vec![y.clone()]))).cycle()
                        }))
                    }) as Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>
                })).cycle()
            }))
        }) as Rc<dyn Fn((crate::lower::model::Ex, Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>)) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>
    } }
}

/// ```prism
/// OwnAs: fn OutTy, Vl -> Ex
/// ```
pub fn own_as(t: &crate::lower::model::OutTy, v_: &crate::lower::types::Vl) -> crate::lower::model::Ex {
    match t {
        crate::lower::model::OutTy::OutRes(_) => if &crate::lower::types::value_ty(v_) == &crate::lower::model::OutTy::OutError {
            crate::lower::model::Ex::XCtor(Text::lit("Err"), Array::from(vec![crate::lower::types::own(v_)]))
        } else {
            crate::lower::types::own(v_)
        },
        _ => crate::lower::types::own(v_),
    }
}

/// ```prism
/// BindRes: fn Wx, Env, Pattern, Wres -> Wx
/// ```
pub fn bind_res(wx2: &crate::lower::node_::Wx, menv: &crate::lower::types::Env, p_: &crate::syntax::Pattern_, res: &crate::lower::node_::Wres) -> crate::lower::node_::Wx {
    match binding_of(menv, p_) {
        Some(crate::lower::types::Bn::BnEv(er, _)) => match res {
            crate::lower::node_::Wres::WrEv(r) => if &er.owner != &wx2.node_ {
                crate::lower::node_::crossed(wx2, &Text::from(format!("the bound event of node `{}` (its graph node {})", &er.owner, &er.node_)))
            } else {
                if &r.node_ == &er.node_ {
                    wx2.clone()
                } else {
                    crate::lower::node_::connect(wx2, r, &crate::lower::node_::Sk::SkNode(er.node_.clone()))
                }
            },
            _ => wx2.clone(),
        },
        _ => wx2.clone(),
    }
}

/// ```prism
/// BuildLine: unbounded fn Wx, Env, Env, Expr, ?Bn -> ((Wx, Wres))
/// ```
pub fn build_line(wx: &crate::lower::node_::Wx, benv: &crate::lower::types::Env, menv: &crate::lower::types::Env, e: &crate::syntax::Expr, bound_opt: &Option<crate::lower::types::Bn>) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    let lx = wx.lx.clone();
    let full = crate::lower::type_at(&lx, &e.span);
    'm26399: {
        let scrutinee = &*e.kind;
        if let crate::syntax::ExprKind::EGroup(x) = scrutinee {
            break 'm26399 build_line(wx, benv, menv, &**x, bound_opt);
        }
        if let crate::syntax::ExprKind::EWidgetBlock(b) = scrutinee {
            break 'm26399 crate::lower::node_::static_::inline_block(wx, benv, menv, b, &lx);
        }
        if let crate::syntax::ExprKind::EFor(binders_opt, source, body) = scrutinee {
            break 'm26399 crate::lower::node_::keyed::for_line(wx, benv, menv, binders_opt, &**source, body, e, bound_opt);
        }
        if let crate::syntax::ExprKind::ERebuild(scrut, body) = scrutinee {
            break 'm26399 crate::lower::node_::switch_::rebuild_line(wx, benv, menv, &**scrut, body, e, bound_opt);
        }
        if let crate::syntax::ExprKind::EIf(m26399_4_0, then_b, Some(else_b)) = scrutinee && let crate::syntax::Cond::CondExpr(c) = &**m26399_4_0 {
            break 'm26399 crate::lower::functions::if_gen_line(wx, menv, &**c, then_b, else_b, e);
        }
        match crate::lower::types::peel(&full) {
            crate::check::types::Ty::TyElem(_, _) => crate::lower::node_::elements::element_line(wx, benv, menv, e, bound_opt),
            crate::check::types::Ty::TyAt(_, _) => crate::lower::node_::static_::widget_line(wx, benv, menv, e, bound_opt),
            _ => {
                let wx2 = {
                    let mut this: crate::lower::node_::Wx = wx.clone();
                    this.build = push(&this.build, &crate::lower::expr::refusal_do(&Text::lit("a building line this back end does not lower yet")));
                    this
                };
                (wx2.clone(), crate::lower::node_::Wres::WrUnit)
            },
        }
    }
}

/// The step machine of `BuildLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BuildLine: unbounded fn Wx, Env, Env, Expr, ?Bn -> ((Wx, Wres))
/// ```
pub struct BuildLine {
    pub wx: crate::lower::node_::Wx,
    pub benv: crate::lower::types::Env,
    pub menv: crate::lower::types::Env,
    pub e: crate::syntax::Expr,
    pub bound_opt: Option<crate::lower::types::Bn>,
}

impl prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::node_::Wres)> for BuildLine {
    fn cycle(&self) -> prism_rtl::Turn<(crate::lower::node_::Wx, crate::lower::node_::Wres)> {
        let wx = &self.wx;
        let benv = &self.benv;
        let menv = &self.menv;
        let e = &self.e;
        let bound_opt = &self.bound_opt;
        let lx = wx.lx.clone();
        let full = crate::lower::type_at(&lx, &e.span);
        'm26399: {
            let scrutinee = &*e.kind;
            if let crate::syntax::ExprKind::EGroup(x) = scrutinee {
                break 'm26399 prism_rtl::Turn::More(Rc::new(BuildLine { wx: wx.clone(), benv: benv.clone(), menv: menv.clone(), e: (**x).clone(), bound_opt: bound_opt.clone() }));
            }
            if let crate::syntax::ExprKind::EWidgetBlock(b) = scrutinee {
                break 'm26399 prism_rtl::Turn::More(Rc::new(crate::lower::node_::static_::InlineBlock { wx: wx.clone(), benv: benv.clone(), menv: menv.clone(), b: b.clone(), lx: lx.clone() }));
            }
            if let crate::syntax::ExprKind::EFor(binders_opt, source, body) = scrutinee {
                break 'm26399 prism_rtl::Turn::More(Rc::new(crate::lower::node_::keyed::ForLine { wx: wx.clone(), benv: benv.clone(), menv: menv.clone(), binders_opt: binders_opt.clone(), source: (**source).clone(), body: body.clone(), e: e.clone(), bound_opt: bound_opt.clone() }));
            }
            if let crate::syntax::ExprKind::ERebuild(scrut, body) = scrutinee {
                break 'm26399 prism_rtl::Turn::More(Rc::new(crate::lower::node_::switch_::RebuildLine { wx: wx.clone(), benv: benv.clone(), menv: menv.clone(), scrut: (**scrut).clone(), body: body.clone(), e: e.clone(), bound_opt: bound_opt.clone() }));
            }
            if let crate::syntax::ExprKind::EIf(m26399_4_0, then_b, Some(else_b)) = scrutinee && let crate::syntax::Cond::CondExpr(c) = &**m26399_4_0 {
                break 'm26399 prism_rtl::Turn::More(Rc::new(crate::lower::functions::IfGenLine { wx: wx.clone(), menv: menv.clone(), c: (**c).clone(), then_b: then_b.clone(), else_b: else_b.clone(), e: e.clone() }));
            }
            match crate::lower::types::peel(&full) {
                crate::check::types::Ty::TyElem(_, _) => prism_rtl::Turn::More(Rc::new(crate::lower::node_::elements::ElementLine { wx: wx.clone(), benv: benv.clone(), menv: menv.clone(), e: e.clone(), bound_opt: bound_opt.clone() })),
                crate::check::types::Ty::TyAt(_, _) => prism_rtl::Turn::More(Rc::new(crate::lower::node_::static_::WidgetLine { wx: wx.clone(), benv: benv.clone(), menv: menv.clone(), e: e.clone(), bound_opt: bound_opt.clone() })),
                _ => {
                    let wx2 = {
                        let mut this: crate::lower::node_::Wx = wx.clone();
                        this.build = push(&this.build, &crate::lower::expr::refusal_do(&Text::lit("a building line this back end does not lower yet")));
                        this
                    };
                    prism_rtl::Turn::Finished((wx2.clone(), crate::lower::node_::Wres::WrUnit))
                },
            }
        }
    }
}

/// `Start BuildLine, x`: what the function value is when passed to `@Run`.
pub fn start_build_line(wx: crate::lower::node_::Wx, benv: crate::lower::types::Env, menv: crate::lower::types::Env, e: crate::syntax::Expr, bound_opt: Option<crate::lower::types::Bn>) -> Rc<dyn prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::node_::Wres)>> {
    Rc::new(BuildLine { wx, benv, menv, e, bound_opt })
}
