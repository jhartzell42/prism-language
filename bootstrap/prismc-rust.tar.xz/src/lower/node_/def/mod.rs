//! The module `Lower.Node.Def`, from `target/bootstrap/src/prismc/lower/node/def.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// `HowBound`:
///
/// ```prism
/// type HowBound = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum HowBound {
    AsHold,
    AsBind,
    AsLet,
}

impl Show for HowBound {
    fn show(&self, p: &mut Printer) {
        match self {
            HowBound::AsHold => p.choice("AsHold", &[]),
            HowBound::AsBind => p.choice("AsBind", &[]),
            HowBound::AsLet => p.choice("AsLet", &[]),
        }
    }
}

impl ToPod for HowBound {
    fn to_pod(&self) -> Pod {
        match self {
            HowBound::AsHold => Pod::Choice("AsHold".into(), vec![]),
            HowBound::AsBind => Pod::Choice("AsBind".into(), vec![]),
            HowBound::AsLet => Pod::Choice("AsLet".into(), vec![]),
        }
    }
}

impl FromPod for HowBound {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "AsHold" && a.len() == 0 => Ok(HowBound::AsHold),
            Pod::Choice(c, a) if &**c == "AsBind" && a.len() == 0 => Ok(HowBound::AsBind),
            Pod::Choice(c, a) if &**c == "AsLet" && a.len() == 0 => Ok(HowBound::AsLet),
            other => mismatch("a HowBound", other),
        }
    }
}

/// ```prism
/// NodeDefOf: unbounded fn Lx, Text, [Pattern], Block, Scheme, Bool -> NodeDef
/// ```
pub fn node_def_of(lx: &crate::lower::Lx, qk: &Text, params: &Array<crate::syntax::Pattern_>, body: &crate::syntax::Block, sc: &crate::check::types::Scheme, is_root: &bool) -> crate::lower::model::NodeDef {
    let name = crate::lower::camel(&crate::check::types::bare_name(qk));
    let ptys = match &sc.ty {
        crate::check::types::Ty::TyFn(_, ps, _) => ps.clone(),
        _ => Array::new(),
    };
    let wx0 = crate::lower::node_::new_wx(lx, &name, &Array::new(), &Array::new(), &Array::new(), &Array::new(), &Map::new(), &crate::lower::node_::node_hooks(), &Nat::from(0u32), &None);
    let (ps, wx1, benv, menv) = run_to_end(fold_job(crate::check::errors::range0(&len(params)), (Array::new(), wx0.clone(), crate::lower::types::empty_env(), crate::lower::types::empty_env()), {
        let params = params.clone();
        let lx = lx.clone();
        let ptys = ptys.clone();
        Rc::new(move |(p0, p1): ((Array<(Text, crate::lower::model::OutTy)>, crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), Nat)| {
            let params = params.clone();
            let lx = lx.clone();
            let ptys = ptys.clone();
            entered(once_job(move || {
                let (acc, w, be, me) = p0;
                let i = p1;
                {
                    let p_ = or(&index(&params, &i), &crate::lower::patterns::dummy_pat());
                    let nkey = crate::lower::functions::plain_binder(&lx, &p_);
                    let base = if &nkey == &Text::lit("") {
                        Text::from(format!("arg{}", &i))
                    } else {
                        crate::lower::snake(&nkey)
                    };
                    let (rs, w2) = crate::lower::node_::fresh_name(&w, &base);
                    call_then(crate::lower::types::start_out_ty_of(lx.clone(), crate::lower::types::peel(&or(&index(&ptys, &i), &crate::check::types::Ty::TyErr))), move |out_ty_of_1972: crate::lower::model::OutTy| {
                        let t = out_ty_of_1972;
                        let w3 = {
                            let mut this: crate::lower::node_::Wx = w2.clone();
                            this.fields = push(&this.fields, &(rs.clone(), t.clone(), Text::lit("a parameter")));
                            this.inits = push(&this.inits, &(rs.clone(), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(rs.clone())))));
                            this
                        };
                        let (be2, me2) = crate::lower::node_::bind_plain(&be, &me, &nkey, &rs, &t);
                        prism_rtl::Turn::Finished((push(&acc, &(rs.clone(), t.clone())), w3.clone(), be2.clone(), me2.clone()))
                    })
                }
            }))
        }) as Rc<dyn Fn(((Array<(Text, crate::lower::model::OutTy)>, crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), Nat)) -> Rc<dyn prism_rtl::Job<(Array<(Text, crate::lower::model::OutTy)>, crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>>>
    }));
    let wx2 = block_into(&wx1, &benv, &menv, body);
    let wx3 = if *is_root { root_result(&wx2) } else { wx2.clone() };
    crate::lower::node_::finish::finish_node(&wx3, qk, &ps, &false)
}

/// The step machine of `NodeDefOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// NodeDefOf: unbounded fn Lx, Text, [Pattern], Block, Scheme, Bool -> NodeDef
/// ```
pub struct NodeDefOf {
    pub lx: crate::lower::Lx,
    pub qk: Text,
    pub params: Array<crate::syntax::Pattern_>,
    pub body: crate::syntax::Block,
    pub sc: crate::check::types::Scheme,
    pub is_root: bool,
}

impl prism_rtl::Job<crate::lower::model::NodeDef> for NodeDefOf {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::NodeDef> {
        let lx = &self.lx;
        let qk = &self.qk;
        let params = &self.params;
        let body = &self.body;
        let sc = &self.sc;
        let is_root = &self.is_root;
        let name = crate::lower::camel(&crate::check::types::bare_name(qk));
        let ptys = match &sc.ty {
            crate::check::types::Ty::TyFn(_, ps, _) => ps.clone(),
            _ => Array::new(),
        };
        let wx0 = crate::lower::node_::new_wx(lx, &name, &Array::new(), &Array::new(), &Array::new(), &Array::new(), &Map::new(), &crate::lower::node_::node_hooks(), &Nat::from(0u32), &None);
        let body = body.clone();
        let is_root = *is_root;
        let lx = lx.clone();
        let params = params.clone();
        let qk = qk.clone();
        call_value(fold_job(crate::check::errors::range0(&len(&params)), (Array::new(), wx0.clone(), crate::lower::types::empty_env(), crate::lower::types::empty_env()), {
            let params = params.clone();
            let lx = lx.clone();
            let ptys = ptys.clone();
            Rc::new(move |(p0, p1): ((Array<(Text, crate::lower::model::OutTy)>, crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), Nat)| {
                let params = params.clone();
                let lx = lx.clone();
                let ptys = ptys.clone();
                entered(once_job(move || {
                    let (acc, w, be, me) = p0;
                    let i = p1;
                    {
                        let p_ = or(&index(&params, &i), &crate::lower::patterns::dummy_pat());
                        let nkey = crate::lower::functions::plain_binder(&lx, &p_);
                        let base = if &nkey == &Text::lit("") {
                            Text::from(format!("arg{}", &i))
                        } else {
                            crate::lower::snake(&nkey)
                        };
                        let (rs, w2) = crate::lower::node_::fresh_name(&w, &base);
                        call_then(crate::lower::types::start_out_ty_of(lx.clone(), crate::lower::types::peel(&or(&index(&ptys, &i), &crate::check::types::Ty::TyErr))), move |out_ty_of_1972: crate::lower::model::OutTy| {
                            let t = out_ty_of_1972;
                            let w3 = {
                                let mut this: crate::lower::node_::Wx = w2.clone();
                                this.fields = push(&this.fields, &(rs.clone(), t.clone(), Text::lit("a parameter")));
                                this.inits = push(&this.inits, &(rs.clone(), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(rs.clone())))));
                                this
                            };
                            let (be2, me2) = crate::lower::node_::bind_plain(&be, &me, &nkey, &rs, &t);
                            prism_rtl::Turn::Finished((push(&acc, &(rs.clone(), t.clone())), w3.clone(), be2.clone(), me2.clone()))
                        })
                    }
                }))
            }) as Rc<dyn Fn(((Array<(Text, crate::lower::model::OutTy)>, crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), Nat)) -> Rc<dyn prism_rtl::Job<(Array<(Text, crate::lower::model::OutTy)>, crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>>>
        }), move |fold_1689: (Array<(Text, crate::lower::model::OutTy)>, crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)| {
            let (ps, wx1, benv, menv) = fold_1689;
            call_then(start_block_into(wx1.clone(), benv.clone(), menv.clone(), body.clone()), move |block_into_2290: crate::lower::node_::Wx| {
                let wx2 = block_into_2290;
                let wx3 = if is_root { root_result(&wx2) } else { wx2.clone() };
                prism_rtl::Turn::More(Rc::new(crate::lower::node_::finish::FinishNode { wx0: wx3.clone(), qk: qk.clone(), params: ps.clone(), is_row: false }))
            })
        })
    }
}

/// `Start NodeDefOf, x`: what the function value is when passed to `@Run`.
pub fn start_node_def_of(lx: crate::lower::Lx, qk: Text, params: Array<crate::syntax::Pattern_>, body: crate::syntax::Block, sc: crate::check::types::Scheme, is_root: bool) -> Rc<dyn prism_rtl::Job<crate::lower::model::NodeDef>> {
    Rc::new(NodeDefOf { lx, qk, params, body, sc, is_root })
}

/// ```prism
/// RootResult: fn Wx -> Wx
/// ```
pub fn root_result(wx: &crate::lower::node_::Wx) -> crate::lower::node_::Wx {
    match &wx.result {
        crate::lower::node_::Wres::WrEv(r) => crate::lower::node_::connect(wx, r, &crate::lower::node_::Sk::SkResult),
        crate::lower::node_::Wres::WrDyn(x, rds, t) => {
            let mut this: crate::lower::node_::Wx = wx.clone();
            this.root_dyn = Some((x.clone(), rds.clone(), t.clone()));
            this.getters = push(&this.getters, &crate::lower::model::MethDef { name: Text::lit("result_value"), recv: crate::lower::model::Recv::RecvRef, params: Array::new(), cx_: crate::lower::model::CxArg::CxRef, ret: crate::lower::model::OutTy::OutPod, body: Array::new(), tail: crate::lower::model::Ex::XMethod(Rc::new(x.clone()), Text::lit("to_pod"), Array::new()), doc: Text::lit("The root's dynamic result, pulled after the tick.") });
            this.fields = push(&this.fields, &(Text::lit("result_last"), crate::lower::model::OutTy::OutCell(Rc::new(crate::lower::model::OutTy::OutOpt(Rc::new(crate::lower::model::OutTy::OutPod)))), Text::lit("the result the World last heard")));
            this.moves = push(&this.moves, &(Text::lit("result_last"), crate::lower::model::Ex::XCall(Text::lit("RefCell::new"), Array::from(vec![crate::lower::model::Ex::XNone]))));
            this.build = push(&this.build, &crate::lower::model::Do::DoScope(crate::lower::node_::finish::result_told(&crate::lower::model::Ex::XVar(Text::lit("node")))));
            this
        },
        crate::lower::node_::Wres::WrPlain(x, _) => {
            let mut this: crate::lower::node_::Wx = wx.clone();
            this.build = push(&this.build, &crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCx), Text::lit("result"), Array::from(vec![crate::lower::model::Ex::XCtor(Text::lit("Outcome::Value"), Array::from(vec![crate::lower::model::Ex::XMethod(Rc::new(x.clone()), Text::lit("to_pod"), Array::new())]))]))));
            this
        },
        _ => wx.clone(),
    }
}

/// ```prism
/// BlockInto: unbounded fn Wx, Env, Env, Block -> Wx
/// ```
pub fn block_into(wx: &crate::lower::node_::Wx, benv: &crate::lower::types::Env, menv: &crate::lower::types::Env, b: &crate::syntax::Block) -> crate::lower::node_::Wx {
    let (wx1, be1, me1) = run_to_end(fold_job(b.stmts.clone(), (wx.clone(), benv.clone(), menv.clone()), Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::syntax::Stmt)| entered(once_job(move || {
        let (w, be, me) = p0;
        let s = p1;
        prism_rtl::Turn::More(Rc::new(PreBind { wx: w.clone(), benv: be.clone(), menv: me.clone(), s: s.clone() }))
    }))) as Rc<dyn Fn(((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>>>));
    let n = len(&b.stmts);
    let (wx2, _, _) = run_to_end(fold_job(crate::check::errors::range0(&n), (wx1.clone(), be1.clone(), me1.clone()), {
        let b = b.clone();
        let n = n.clone();
        Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), Nat)| {
            let b = b.clone();
            let n = n.clone();
            entered(once_job(move || {
                let (w, be, me) = p0;
                let i = p1;
                prism_rtl::Turn::More(Rc::new(WidgetStmt { wx: w.clone(), benv: be.clone(), menv: me.clone(), s: or(&index(&b.stmts, &i), &crate::lower::expr::dummy_stmt_l()), last: &(&i + &Nat::from(1u32)) == &n }))
            }))
        }) as Rc<dyn Fn(((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), Nat)) -> Rc<dyn prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>>>
    }));
    wx2.clone()
}

/// The step machine of `BlockInto`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BlockInto: unbounded fn Wx, Env, Env, Block -> Wx
/// ```
pub struct BlockInto {
    pub wx: crate::lower::node_::Wx,
    pub benv: crate::lower::types::Env,
    pub menv: crate::lower::types::Env,
    pub b: crate::syntax::Block,
}

impl prism_rtl::Job<crate::lower::node_::Wx> for BlockInto {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::node_::Wx> {
        let wx = &self.wx;
        let benv = &self.benv;
        let menv = &self.menv;
        let b = &self.b;
        let b = b.clone();
        let benv = benv.clone();
        let menv = menv.clone();
        let wx = wx.clone();
        call_value(fold_job(b.stmts.clone(), (wx.clone(), benv.clone(), menv.clone()), Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::syntax::Stmt)| entered(once_job(move || {
            let (w, be, me) = p0;
            let s = p1;
            prism_rtl::Turn::More(Rc::new(PreBind { wx: w.clone(), benv: be.clone(), menv: me.clone(), s: s.clone() }))
        }))) as Rc<dyn Fn(((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>>>), move |fold_3613: (crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)| {
            let (wx1, be1, me1) = fold_3613;
            let n = len(&b.stmts);
            call_value(fold_job(crate::check::errors::range0(&n), (wx1.clone(), be1.clone(), me1.clone()), {
                let b = b.clone();
                let n = n.clone();
                Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), Nat)| {
                    let b = b.clone();
                    let n = n.clone();
                    entered(once_job(move || {
                        let (w, be, me) = p0;
                        let i = p1;
                        prism_rtl::Turn::More(Rc::new(WidgetStmt { wx: w.clone(), benv: be.clone(), menv: me.clone(), s: or(&index(&b.stmts, &i), &crate::lower::expr::dummy_stmt_l()), last: &(&i + &Nat::from(1u32)) == &n }))
                    }))
                }) as Rc<dyn Fn(((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), Nat)) -> Rc<dyn prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>>>
            }), move |fold_3746: (crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)| {
                let (wx2, _, _) = fold_3746;
                prism_rtl::Turn::Finished(wx2.clone())
            })
        })
    }
}

/// `Start BlockInto, x`: what the function value is when passed to `@Run`.
pub fn start_block_into(wx: crate::lower::node_::Wx, benv: crate::lower::types::Env, menv: crate::lower::types::Env, b: crate::syntax::Block) -> Rc<dyn prism_rtl::Job<crate::lower::node_::Wx>> {
    Rc::new(BlockInto { wx, benv, menv, b })
}

/// ```prism
/// PreBind: unbounded fn Wx, Env, Env, Stmt -> ((Wx, Env, Env))
/// ```
pub fn pre_bind(wx: &crate::lower::node_::Wx, benv: &crate::lower::types::Env, menv: &crate::lower::types::Env, s: &crate::syntax::Stmt) -> (crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env) {
    match &s.kind {
        crate::syntax::StmtKind::SBind(p_, init, step_opt) => match &*p_.kind {
            crate::syntax::PatternKind::PName(n) => pre_bind_name(wx, benv, menv, n, &how_bound(step_opt)),
            crate::syntax::PatternKind::PTuple(ps) => run_to_end(fold_job(ps.clone(), (wx.clone(), benv.clone(), menv.clone()), Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::syntax::Pattern_)| entered(once_job(move || {
                let (w, be, me) = p0;
                let q = p1;
                match &*q.kind {
                    crate::syntax::PatternKind::PName(n) => prism_rtl::Turn::More(Rc::new(PreBindName { wx: w.clone(), benv: be.clone(), menv: me.clone(), n: n.clone(), how: HowBound::AsBind })),
                    _ => prism_rtl::Turn::Finished((w.clone(), be.clone(), me.clone())),
                }
            }))) as Rc<dyn Fn(((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::syntax::Pattern_)) -> Rc<dyn prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>>>)),
            _ => (wx.clone(), benv.clone(), menv.clone()),
        },
        crate::syntax::StmtKind::SLet(p_, _, _) => match &*p_.kind {
            crate::syntax::PatternKind::PName(n) => pre_bind_name(wx, benv, menv, n, &HowBound::AsLet),
            _ => (wx.clone(), benv.clone(), menv.clone()),
        },
        crate::syntax::StmtKind::SFn(c) => {
            let fname = crate::check::env::def_name_text(&c.name);
            (wx.clone(), crate::lower::types::bind(benv, &fname, &crate::lower::types::Bn::BnLocalFn(c.clone())), crate::lower::types::bind(menv, &fname, &crate::lower::types::Bn::BnLocalFn(c.clone())))
        },
        _ => (wx.clone(), benv.clone(), menv.clone()),
    }
}

/// The step machine of `PreBind`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PreBind: unbounded fn Wx, Env, Env, Stmt -> ((Wx, Env, Env))
/// ```
pub struct PreBind {
    pub wx: crate::lower::node_::Wx,
    pub benv: crate::lower::types::Env,
    pub menv: crate::lower::types::Env,
    pub s: crate::syntax::Stmt,
}

impl prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)> for PreBind {
    fn cycle(&self) -> prism_rtl::Turn<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)> {
        let wx = &self.wx;
        let benv = &self.benv;
        let menv = &self.menv;
        let s = &self.s;
        match &s.kind {
            crate::syntax::StmtKind::SBind(p_, init, step_opt) => match &*p_.kind {
                crate::syntax::PatternKind::PName(n) => prism_rtl::Turn::More(Rc::new(PreBindName { wx: wx.clone(), benv: benv.clone(), menv: menv.clone(), n: n.clone(), how: how_bound(step_opt) })),
                crate::syntax::PatternKind::PTuple(ps) => fold_job(ps.clone(), (wx.clone(), benv.clone(), menv.clone()), Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::syntax::Pattern_)| entered(once_job(move || {
                    let (w, be, me) = p0;
                    let q = p1;
                    match &*q.kind {
                        crate::syntax::PatternKind::PName(n) => prism_rtl::Turn::More(Rc::new(PreBindName { wx: w.clone(), benv: be.clone(), menv: me.clone(), n: n.clone(), how: HowBound::AsBind })),
                        _ => prism_rtl::Turn::Finished((w.clone(), be.clone(), me.clone())),
                    }
                }))) as Rc<dyn Fn(((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::syntax::Pattern_)) -> Rc<dyn prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>>>).cycle(),
                _ => prism_rtl::Turn::Finished((wx.clone(), benv.clone(), menv.clone())),
            },
            crate::syntax::StmtKind::SLet(p_, _, _) => match &*p_.kind {
                crate::syntax::PatternKind::PName(n) => prism_rtl::Turn::More(Rc::new(PreBindName { wx: wx.clone(), benv: benv.clone(), menv: menv.clone(), n: n.clone(), how: HowBound::AsLet })),
                _ => prism_rtl::Turn::Finished((wx.clone(), benv.clone(), menv.clone())),
            },
            crate::syntax::StmtKind::SFn(c) => {
                let fname = crate::check::env::def_name_text(&c.name);
                prism_rtl::Turn::Finished((wx.clone(), crate::lower::types::bind(benv, &fname, &crate::lower::types::Bn::BnLocalFn(c.clone())), crate::lower::types::bind(menv, &fname, &crate::lower::types::Bn::BnLocalFn(c.clone()))))
            },
            _ => prism_rtl::Turn::Finished((wx.clone(), benv.clone(), menv.clone())),
        }
    }
}

/// `Start PreBind, x`: what the function value is when passed to `@Run`.
pub fn start_pre_bind(wx: crate::lower::node_::Wx, benv: crate::lower::types::Env, menv: crate::lower::types::Env, s: crate::syntax::Stmt) -> Rc<dyn prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>> {
    Rc::new(PreBind { wx, benv, menv, s })
}

/// ```prism
/// HowBound: fn ?Expr -> HowBound
/// ```
pub fn how_bound(opt0: &Option<crate::syntax::Expr>) -> HowBound {
    match opt0 {
        Some(_) => HowBound::AsHold,
        None => HowBound::AsBind,
    }
}

/// ```prism
/// PreBindName: unbounded fn Wx, Env, Env, SName, HowBound -> ((Wx, Env, Env))
/// ```
pub fn pre_bind_name(wx: &crate::lower::node_::Wx, benv: &crate::lower::types::Env, menv: &crate::lower::types::Env, n: &crate::syntax::SName, how: &HowBound) -> (crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env) {
    let lx = crate::lower::expr::widget_let_lx(&wx.lx, &n.span);
    let nkey = crate::check::env::sname_key(n);
    let full = crate::lower::binder_ty(&lx, &n.span);
    let layer = crate::lower::types::layer_of(&full);
    let t = crate::lower::types::out_ty_of(&lx, &crate::lower::types::peel(&full));
    let (rs, wx1) = crate::lower::node_::fresh_name(wx, &crate::lower::snake(&nkey));
    if (&layer == &crate::lower::types::Layer::LyEv) || is_switched(&full) {
        {
            let et = crate::lower::types::out_ty_of(&lx, &crate::lower::types::peel(&crate::lower::types::peel(&full)));
            let (id, wx2) = crate::lower::node_::add_gn(&wx1, &rs, &et, &crate::lower::node_::GnKind::GnNamed, &Nat::from(0u32));
            let b = crate::lower::types::Bn::BnEv(crate::lower::node_::ev_ref_of(&wx2, &id), t.clone());
            let pf = Text::from(format!("{}_v_port", &rs));
            let pt = crate::lower::model::OutTy::OutRc(Rc::new(crate::lower::model::OutTy::OutPort(Rc::new(et.clone()))));
            let wx3 = {
                let mut this: crate::lower::node_::Wx = crate::lower::node_::connect(&wx2, &crate::lower::node_::ev_ref_of(&wx2, &id), &crate::lower::node_::Sk::SkPort(Text::from(format!("{}_v", &rs))));
                this.lets = push(&this.lets, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaBind(pf.clone())), pt.clone()), crate::lower::model::Ex::XCall(Text::lit("Rc::new"), Array::from(vec![crate::lower::model::Ex::XCall(Text::lit("Port::new"), Array::new())]))));
                this.fields = push(&this.fields, &(pf.clone(), pt.clone(), Text::from(format!("`{}` as a value: the port it fires", &nkey))));
                this.moves = push(&this.moves, &(pf.clone(), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(pf.clone())))));
                this
            };
            let be = crate::lower::types::bind(&crate::lower::types::bind(benv, &nkey, &b), &Text::from(format!("{}#port", &nkey)), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(pf.clone()), crate::lower::types::Holding::Owned, pt.clone()));
            let me = crate::lower::types::bind(&crate::lower::types::bind(menv, &nkey, &b), &Text::from(format!("{}#port", &nkey)), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), pf.clone()), crate::lower::types::Holding::Owned, pt.clone()));
            (wx3.clone(), be.clone(), me.clone())
        }
    } else {
        match (layer.clone(), how.clone()) {
            (crate::lower::types::Layer::LyDyn, HowBound::AsLet) => {
                let b = crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XSelf), rs.clone(), Array::from(vec![crate::lower::model::Ex::XCx])), Array::from(vec![crate::lower::node_::Read::OwnRead(rs.clone())]), t.clone());
                (wx1.clone(), crate::lower::types::bind(benv, &nkey, &b), crate::lower::types::bind(menv, &nkey, &b))
            },
            (crate::lower::types::Layer::LyDyn, _) => {
                let b = crate::lower::types::Bn::BnHold(rs.clone(), t.clone());
                (wx1.clone(), crate::lower::types::bind(benv, &nkey, &b), crate::lower::types::bind(menv, &nkey, &b))
            },
            _ => match many_instances(&wx.lx, &n.span) {
                Some(insts) => run_to_end(fold_job(crate::check::errors::range0(&len(&insts)), (wx1.clone(), benv.clone(), menv.clone()), {
                    let insts = insts.clone();
                    let wx = wx.clone();
                    let n = n.clone();
                    let rs = rs.clone();
                    let nkey = nkey.clone();
                    Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), Nat)| {
                        let insts = insts.clone();
                        let wx = wx.clone();
                        let n = n.clone();
                        let rs = rs.clone();
                        let nkey = nkey.clone();
                        entered(once_job(move || {
                            let (w, be, me) = p0;
                            let k = p1;
                            {
                                let inst = or(&index(&insts, &k), &(Array::new(), Array::new()));
                                let lxk = crate::lower::expr::at_instance(&wx.lx, &inst);
                                call_then(crate::lower::types::start_out_ty_of(lxk.clone(), crate::lower::types::peel(&crate::lower::binder_ty(&lxk, &n.span))), move |out_ty_of_7108: crate::lower::model::OutTy| {
                                    let tk = out_ty_of_7108;
                                    let (rk, w2) = if &k == &Nat::from(0u32) {
                                        (rs.clone(), w.clone())
                                    } else {
                                        crate::lower::node_::fresh_name(&w, &Text::from(format!("{}_{}", &rs, &k)))
                                    };
                                    let bkey = if &k == &Nat::from(0u32) {
                                        nkey.clone()
                                    } else {
                                        Text::from(format!("{}#inst{}", &nkey, &k))
                                    };
                                    let (be2, me2) = crate::lower::node_::bind_plain(&be, &me, &bkey, &rk, &tk);
                                    let ukey = Text::from(format!("{}#{}", &nkey, &show_text(&inst)));
                                    prism_rtl::Turn::Finished((w2.clone(), with_use(&be2, &ukey, &bkey), with_use(&me2, &ukey, &bkey)))
                                })
                            }
                        }))
                    }) as Rc<dyn Fn(((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), Nat)) -> Rc<dyn prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>>>
                })),
                None => {
                    let (be, me) = crate::lower::node_::bind_plain(benv, menv, &nkey, &rs, &t);
                    (wx1.clone(), be.clone(), me.clone())
                },
            },
        }
    }
}

/// The step machine of `PreBindName`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PreBindName: unbounded fn Wx, Env, Env, SName, HowBound -> ((Wx, Env, Env))
/// ```
pub struct PreBindName {
    pub wx: crate::lower::node_::Wx,
    pub benv: crate::lower::types::Env,
    pub menv: crate::lower::types::Env,
    pub n: crate::syntax::SName,
    pub how: HowBound,
}

impl prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)> for PreBindName {
    fn cycle(&self) -> prism_rtl::Turn<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)> {
        let wx = &self.wx;
        let benv = &self.benv;
        let menv = &self.menv;
        let n = &self.n;
        let how = &self.how;
        let benv = benv.clone();
        let how = how.clone();
        let menv = menv.clone();
        let n = n.clone();
        let wx = wx.clone();
        call_then(crate::lower::expr::start_widget_let_lx(wx.lx.clone(), n.span.clone()), move |widget_let_lx_5093: crate::lower::Lx| {
            let lx = widget_let_lx_5093;
            let nkey = crate::check::env::sname_key(&n);
            let full = crate::lower::binder_ty(&lx, &n.span);
            let layer = crate::lower::types::layer_of(&full);
            call_then(crate::lower::types::start_out_ty_of(lx.clone(), crate::lower::types::peel(&full)), move |out_ty_of_5221: crate::lower::model::OutTy| {
                let t = out_ty_of_5221;
                let (rs, wx1) = crate::lower::node_::fresh_name(&wx, &crate::lower::snake(&nkey));
                if (&layer == &crate::lower::types::Layer::LyEv) || is_switched(&full) {
                    call_then(crate::lower::types::start_out_ty_of(lx.clone(), crate::lower::types::peel(&crate::lower::types::peel(&full))), move |out_ty_of_5352: crate::lower::model::OutTy| {
                        let et = out_ty_of_5352;
                        let (id, wx2) = crate::lower::node_::add_gn(&wx1, &rs, &et, &crate::lower::node_::GnKind::GnNamed, &Nat::from(0u32));
                        let b = crate::lower::types::Bn::BnEv(crate::lower::node_::ev_ref_of(&wx2, &id), t.clone());
                        let pf = Text::from(format!("{}_v_port", &rs));
                        let pt = crate::lower::model::OutTy::OutRc(Rc::new(crate::lower::model::OutTy::OutPort(Rc::new(et.clone()))));
                        let wx3 = {
                            let mut this: crate::lower::node_::Wx = crate::lower::node_::connect(&wx2, &crate::lower::node_::ev_ref_of(&wx2, &id), &crate::lower::node_::Sk::SkPort(Text::from(format!("{}_v", &rs))));
                            this.lets = push(&this.lets, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaBind(pf.clone())), pt.clone()), crate::lower::model::Ex::XCall(Text::lit("Rc::new"), Array::from(vec![crate::lower::model::Ex::XCall(Text::lit("Port::new"), Array::new())]))));
                            this.fields = push(&this.fields, &(pf.clone(), pt.clone(), Text::from(format!("`{}` as a value: the port it fires", &nkey))));
                            this.moves = push(&this.moves, &(pf.clone(), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(pf.clone())))));
                            this
                        };
                        let be = crate::lower::types::bind(&crate::lower::types::bind(&benv, &nkey, &b), &Text::from(format!("{}#port", &nkey)), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(pf.clone()), crate::lower::types::Holding::Owned, pt.clone()));
                        let me = crate::lower::types::bind(&crate::lower::types::bind(&menv, &nkey, &b), &Text::from(format!("{}#port", &nkey)), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), pf.clone()), crate::lower::types::Holding::Owned, pt.clone()));
                        prism_rtl::Turn::Finished((wx3.clone(), be.clone(), me.clone()))
                    })
                } else {
                    match (layer.clone(), how.clone()) {
                        (crate::lower::types::Layer::LyDyn, HowBound::AsLet) => {
                            let b = crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XSelf), rs.clone(), Array::from(vec![crate::lower::model::Ex::XCx])), Array::from(vec![crate::lower::node_::Read::OwnRead(rs.clone())]), t.clone());
                            prism_rtl::Turn::Finished((wx1.clone(), crate::lower::types::bind(&benv, &nkey, &b), crate::lower::types::bind(&menv, &nkey, &b)))
                        },
                        (crate::lower::types::Layer::LyDyn, _) => {
                            let b = crate::lower::types::Bn::BnHold(rs.clone(), t.clone());
                            prism_rtl::Turn::Finished((wx1.clone(), crate::lower::types::bind(&benv, &nkey, &b), crate::lower::types::bind(&menv, &nkey, &b)))
                        },
                        _ => call_then(start_many_instances(wx.lx.clone(), n.span.clone()), move |many_instances_6640: Option<Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)>>| match many_instances_6640 {
                            Some(insts) => fold_job(crate::check::errors::range0(&len(&insts)), (wx1.clone(), benv.clone(), menv.clone()), {
                                let insts = insts.clone();
                                let wx = wx.clone();
                                let n = n.clone();
                                let rs = rs.clone();
                                let nkey = nkey.clone();
                                Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), Nat)| {
                                    let insts = insts.clone();
                                    let wx = wx.clone();
                                    let n = n.clone();
                                    let rs = rs.clone();
                                    let nkey = nkey.clone();
                                    entered(once_job(move || {
                                        let (w, be, me) = p0;
                                        let k = p1;
                                        {
                                            let inst = or(&index(&insts, &k), &(Array::new(), Array::new()));
                                            let lxk = crate::lower::expr::at_instance(&wx.lx, &inst);
                                            call_then(crate::lower::types::start_out_ty_of(lxk.clone(), crate::lower::types::peel(&crate::lower::binder_ty(&lxk, &n.span))), move |out_ty_of_7108: crate::lower::model::OutTy| {
                                                let tk = out_ty_of_7108;
                                                let (rk, w2) = if &k == &Nat::from(0u32) {
                                                    (rs.clone(), w.clone())
                                                } else {
                                                    crate::lower::node_::fresh_name(&w, &Text::from(format!("{}_{}", &rs, &k)))
                                                };
                                                let bkey = if &k == &Nat::from(0u32) {
                                                    nkey.clone()
                                                } else {
                                                    Text::from(format!("{}#inst{}", &nkey, &k))
                                                };
                                                let (be2, me2) = crate::lower::node_::bind_plain(&be, &me, &bkey, &rk, &tk);
                                                let ukey = Text::from(format!("{}#{}", &nkey, &show_text(&inst)));
                                                prism_rtl::Turn::Finished((w2.clone(), with_use(&be2, &ukey, &bkey), with_use(&me2, &ukey, &bkey)))
                                            })
                                        }
                                    }))
                                }) as Rc<dyn Fn(((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), Nat)) -> Rc<dyn prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>>>
                            }).cycle(),
                            None => {
                                let (be, me) = crate::lower::node_::bind_plain(&benv, &menv, &nkey, &rs, &t);
                                prism_rtl::Turn::Finished((wx1.clone(), be.clone(), me.clone()))
                            },
                        }),
                    }
                }
            })
        })
    }
}

/// `Start PreBindName, x`: what the function value is when passed to `@Run`.
pub fn start_pre_bind_name(wx: crate::lower::node_::Wx, benv: crate::lower::types::Env, menv: crate::lower::types::Env, n: crate::syntax::SName, how: HowBound) -> Rc<dyn prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>> {
    Rc::new(PreBindName { wx, benv, menv, n, how })
}

/// ```prism
/// WithUse: fn Env, Text, Text -> Env
/// ```
pub fn with_use(env: &crate::lower::types::Env, ukey: &Text, bkey: &Text) -> crate::lower::types::Env {
    let mut this: crate::lower::types::Env = env.clone();
    this.uses = insert(&this.uses, ukey, bkey);
    this
}

/// ```prism
/// ?ManyInstances: unbounded fn Lx, Range -> ?[(([((Text, Ty))], [((Text, Col))]))]
/// ```
pub fn many_instances(lx: &crate::lower::Lx, span: &crate::syntax::Range) -> Option<Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)>> {
    match get(&lx.gens, &crate::lower::place_key(lx, span)) {
        Some(gn) => {
            let insts = crate::lower::expr::instantiations(lx, &gn);
            if &len(&insts) > &Nat::from(1u32) { Some(insts.clone()) } else { None }
        },
        None => None,
    }
}

/// The step machine of `ManyInstances`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?ManyInstances: unbounded fn Lx, Range -> ?[(([((Text, Ty))], [((Text, Col))]))]
/// ```
pub struct ManyInstances {
    pub lx: crate::lower::Lx,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<Option<Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)>>> for ManyInstances {
    fn cycle(&self) -> prism_rtl::Turn<Option<Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)>>> {
        let lx = &self.lx;
        let span = &self.span;
        match get(&lx.gens, &crate::lower::place_key(lx, span)) {
            Some(gn) => {
                let lx = lx.clone();
                call_then(crate::lower::expr::start_instantiations(lx.clone(), gn.clone()), move |instantiations_7985: Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)>| {
                    let insts = instantiations_7985;
                    if &len(&insts) > &Nat::from(1u32) {
                        prism_rtl::Turn::Finished(Some(insts.clone()))
                    } else {
                        prism_rtl::Turn::Finished(None)
                    }
                })
            },
            None => prism_rtl::Turn::Finished(None),
        }
    }
}

/// `Start ManyInstances, x`: what the function value is when passed to `@Run`.
pub fn start_many_instances(lx: crate::lower::Lx, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<Option<Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)>>>> {
    Rc::new(ManyInstances { lx, span })
}

/// ```prism
/// IsSwitched: fn Ty -> Bool
/// ```
pub fn is_switched(t: &crate::check::types::Ty) -> bool {
    'm8302: {
        if let crate::check::types::Ty::TySig(m8302_0_0, m8302_0_1) = t && (m8302_0_0 == &Text::lit("$")) && let crate::check::types::Ty::TySig(m8302_0_1_r_0, _) = &**m8302_0_1 && (m8302_0_1_r_0 == &Text::lit("!")) {
            break 'm8302 true;
        }
        false
    }
}

/// ```prism
/// ?BindingOf: fn Env, Pattern -> ?Bn
/// ```
pub fn binding_of(env: &crate::lower::types::Env, p_: &crate::syntax::Pattern_) -> Option<crate::lower::types::Bn> {
    match &*p_.kind {
        crate::syntax::PatternKind::PName(n) => get(&env.names, &crate::check::env::sname_key(n)),
        crate::syntax::PatternKind::PTuple(ps) => Some(crate::lower::types::Bn::BnParts(each(ps, &(|q: &crate::syntax::Pattern_| binding_of_name(env, q))))),
        _ => None,
    }
}

/// ```prism
/// ?BindingOfName: fn Env, Pattern -> ?Bn
/// ```
pub fn binding_of_name(env: &crate::lower::types::Env, p_: &crate::syntax::Pattern_) -> Option<crate::lower::types::Bn> {
    match &*p_.kind {
        crate::syntax::PatternKind::PName(n) => get(&env.names, &crate::check::env::sname_key(n)),
        _ => None,
    }
}

/// ```prism
/// WidgetStmt: unbounded fn Wx, Env, Env, Stmt, Bool -> ((Wx, Env, Env))
/// ```
pub fn widget_stmt(wx: &crate::lower::node_::Wx, benv: &crate::lower::types::Env, menv: &crate::lower::types::Env, s: &crate::syntax::Stmt, last: &bool) -> (crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env) {
    let lx = wx.lx.clone();
    match &s.kind {
        crate::syntax::StmtKind::SBind(p_, e, None) => {
            let (wx2, res) = build_line(wx, benv, menv, e, &binding_of(menv, p_));
            let wx3 = bind_res(&wx2, menv, p_, &res);
            match (res.clone(), (*p_.kind).clone()) {
                (crate::lower::node_::Wres::WrDyn(ex, rds, t), crate::syntax::PatternKind::PName(n)) => {
                    let b = crate::lower::types::Bn::BnDyn(ex.clone(), rds.clone(), t.clone());
                    (wx3.clone(), crate::lower::types::bind(benv, &crate::check::env::sname_key(&n), &b), crate::lower::types::bind(menv, &crate::check::env::sname_key(&n), &b))
                },
                (crate::lower::node_::Wres::WrHosted(inner, doc), crate::syntax::PatternKind::PTuple(ps)) => bind_hosted(&wx3, benv, menv, &*inner, &doc, &ps),
                _ => (wx3.clone(), benv.clone(), menv.clone()),
            }
        },
        crate::syntax::StmtKind::SBind(p_, init, Some(step_)) => {
            let (wx2, be2) = hold_line(wx, benv, menv, p_, init, step_);
            (wx2.clone(), be2.clone(), menv.clone())
        },
        crate::syntax::StmtKind::SIgnore(e) => {
            let (wx2, _) = build_line(wx, benv, menv, e, &None);
            (wx2.clone(), benv.clone(), menv.clone())
        },
        crate::syntax::StmtKind::SLet(p_, _, e) => {
            let (wx2, be2) = let_line(wx, benv, menv, p_, e);
            (wx2.clone(), be2.clone(), menv.clone())
        },
        crate::syntax::StmtKind::SExpr(e) => match &*e.kind {
            crate::syntax::ExprKind::EFreeSigil(m9819_0_0, x) if (m9819_0_0 == &Text::lit("@")) => {
                let (res, wx2) = result_of(wx, benv, menv, &**x);
                let wx3 = {
                    let mut this: crate::lower::node_::Wx = wx2.clone();
                    this.result = res.clone();
                    this
                };
                (wx3.clone(), benv.clone(), menv.clone())
            },
            _ => {
                let (wx2, res) = build_line(wx, benv, menv, e, &None);
                let wx3 = if *last { set_result(&wx2, &res) } else { wx2.clone() };
                (wx3.clone(), benv.clone(), menv.clone())
            },
            _ => unreachable!("no arm matched"),
        },
        crate::syntax::StmtKind::SEmit(_) => (wx.clone(), benv.clone(), menv.clone()),
        crate::syntax::StmtKind::SSignature(_) => (wx.clone(), benv.clone(), menv.clone()),
        crate::syntax::StmtKind::SFn(c) => (wx.clone(), benv.clone(), menv.clone()),
        _ => {
            let wx2 = {
                let mut this: crate::lower::node_::Wx = wx.clone();
                this.build = push(&this.build, &crate::lower::expr::refusal_do(&Text::lit("a statement this back end does not lower yet")));
                this
            };
            (wx2.clone(), benv.clone(), menv.clone())
        },
    }
}

/// The step machine of `WidgetStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// WidgetStmt: unbounded fn Wx, Env, Env, Stmt, Bool -> ((Wx, Env, Env))
/// ```
pub struct WidgetStmt {
    pub wx: crate::lower::node_::Wx,
    pub benv: crate::lower::types::Env,
    pub menv: crate::lower::types::Env,
    pub s: crate::syntax::Stmt,
    pub last: bool,
}

impl prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)> for WidgetStmt {
    fn cycle(&self) -> prism_rtl::Turn<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)> {
        let wx = &self.wx;
        let benv = &self.benv;
        let menv = &self.menv;
        let s = &self.s;
        let last = &self.last;
        let lx = wx.lx.clone();
        match &s.kind {
            crate::syntax::StmtKind::SBind(p_, e, None) => {
                let benv = benv.clone();
                let e = e.clone();
                let menv = menv.clone();
                let p_ = p_.clone();
                let wx = wx.clone();
                call_then(start_build_line(wx.clone(), benv.clone(), menv.clone(), e.clone(), binding_of(&menv, &p_)), move |build_line_8973: (crate::lower::node_::Wx, crate::lower::node_::Wres)| {
                    let (wx2, res) = build_line_8973;
                    let wx3 = bind_res(&wx2, &menv, &p_, &res);
                    match (res.clone(), (*p_.kind).clone()) {
                        (crate::lower::node_::Wres::WrDyn(ex, rds, t), crate::syntax::PatternKind::PName(n)) => {
                            let b = crate::lower::types::Bn::BnDyn(ex.clone(), rds.clone(), t.clone());
                            prism_rtl::Turn::Finished((wx3.clone(), crate::lower::types::bind(&benv, &crate::check::env::sname_key(&n), &b), crate::lower::types::bind(&menv, &crate::check::env::sname_key(&n), &b)))
                        },
                        (crate::lower::node_::Wres::WrHosted(inner, doc), crate::syntax::PatternKind::PTuple(ps)) => prism_rtl::Turn::Finished(bind_hosted(&wx3, &benv, &menv, &*inner, &doc, &ps)),
                        _ => prism_rtl::Turn::Finished((wx3.clone(), benv.clone(), menv.clone())),
                    }
                })
            },
            crate::syntax::StmtKind::SBind(p_, init, Some(step_)) => {
                let benv = benv.clone();
                let init = init.clone();
                let menv = menv.clone();
                let p_ = p_.clone();
                let step_ = step_.clone();
                let wx = wx.clone();
                call_then(start_hold_line(wx.clone(), benv.clone(), menv.clone(), p_.clone(), init.clone(), step_.clone()), move |hold_line_9496: (crate::lower::node_::Wx, crate::lower::types::Env)| {
                    let (wx2, be2) = hold_line_9496;
                    prism_rtl::Turn::Finished((wx2.clone(), be2.clone(), menv.clone()))
                })
            },
            crate::syntax::StmtKind::SIgnore(e) => {
                let benv = benv.clone();
                let e = e.clone();
                let menv = menv.clone();
                let wx = wx.clone();
                call_then(start_build_line(wx.clone(), benv.clone(), menv.clone(), e.clone(), None), move |build_line_9619: (crate::lower::node_::Wx, crate::lower::node_::Wres)| {
                    let (wx2, _) = build_line_9619;
                    prism_rtl::Turn::Finished((wx2.clone(), benv.clone(), menv.clone()))
                })
            },
            crate::syntax::StmtKind::SLet(p_, _, e) => {
                let benv = benv.clone();
                let e = e.clone();
                let menv = menv.clone();
                let p_ = p_.clone();
                let wx = wx.clone();
                call_then(start_let_line(wx.clone(), benv.clone(), menv.clone(), p_.clone(), e.clone()), move |let_line_9742: (crate::lower::node_::Wx, crate::lower::types::Env)| {
                    let (wx2, be2) = let_line_9742;
                    prism_rtl::Turn::Finished((wx2.clone(), be2.clone(), menv.clone()))
                })
            },
            crate::syntax::StmtKind::SExpr(e) => match &*e.kind {
                crate::syntax::ExprKind::EFreeSigil(m9819_0_0, x) if (m9819_0_0 == &Text::lit("@")) => {
                    let benv = benv.clone();
                    let menv = menv.clone();
                    let wx = wx.clone();
                    let x = (**x).clone();
                    call_then(start_result_of(wx.clone(), benv.clone(), menv.clone(), x.clone()), move |result_of_9899: (crate::lower::node_::Wres, crate::lower::node_::Wx)| {
                        let (res, wx2) = result_of_9899;
                        let wx3 = {
                            let mut this: crate::lower::node_::Wx = wx2.clone();
                            this.result = res.clone();
                            this
                        };
                        prism_rtl::Turn::Finished((wx3.clone(), benv.clone(), menv.clone()))
                    })
                },
                _ => {
                    let benv = benv.clone();
                    let e = e.clone();
                    let last = *last;
                    let menv = menv.clone();
                    let wx = wx.clone();
                    call_then(start_build_line(wx.clone(), benv.clone(), menv.clone(), e.clone(), None), move |build_line_10095: (crate::lower::node_::Wx, crate::lower::node_::Wres)| {
                        let (wx2, res) = build_line_10095;
                        let wx3 = if last { set_result(&wx2, &res) } else { wx2.clone() };
                        prism_rtl::Turn::Finished((wx3.clone(), benv.clone(), menv.clone()))
                    })
                },
                _ => unreachable!("no arm matched"),
            },
            crate::syntax::StmtKind::SEmit(_) => prism_rtl::Turn::Finished((wx.clone(), benv.clone(), menv.clone())),
            crate::syntax::StmtKind::SSignature(_) => prism_rtl::Turn::Finished((wx.clone(), benv.clone(), menv.clone())),
            crate::syntax::StmtKind::SFn(c) => prism_rtl::Turn::Finished((wx.clone(), benv.clone(), menv.clone())),
            _ => {
                let wx2 = {
                    let mut this: crate::lower::node_::Wx = wx.clone();
                    this.build = push(&this.build, &crate::lower::expr::refusal_do(&Text::lit("a statement this back end does not lower yet")));
                    this
                };
                prism_rtl::Turn::Finished((wx2.clone(), benv.clone(), menv.clone()))
            },
        }
    }
}

/// `Start WidgetStmt, x`: what the function value is when passed to `@Run`.
pub fn start_widget_stmt(wx: crate::lower::node_::Wx, benv: crate::lower::types::Env, menv: crate::lower::types::Env, s: crate::syntax::Stmt, last: bool) -> Rc<dyn prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>> {
    Rc::new(WidgetStmt { wx, benv, menv, s, last })
}

/// ```prism
/// BindHosted: fn Wx, Env, Env, Wres, Bn, [Pattern] -> ((Wx, Env, Env))
/// ```
pub fn bind_hosted(wx: &crate::lower::node_::Wx, benv: &crate::lower::types::Env, menv: &crate::lower::types::Env, res: &crate::lower::node_::Wres, doc: &crate::lower::types::Bn, ps: &Array<crate::syntax::Pattern_>) -> (crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env) {
    let r_opt = match res {
        crate::lower::node_::Wres::WrEv(r) => Some(crate::lower::types::Bn::BnEv(r.clone(), crate::lower::model::OutTy::OutUnit)),
        crate::lower::node_::Wres::WrDyn(ex, rds, t) => Some(crate::lower::types::Bn::BnDyn(ex.clone(), rds.clone(), t.clone())),
        _ => None,
    };
    let (be1, me1) = bind_part(benv, menv, &index(ps, &Nat::from(0u32)), &r_opt);
    bind_part2(wx, &be1, &me1, &index(ps, &Nat::from(1u32)), &Some(doc.clone()))
}

/// ```prism
/// BindPart: fn Env, Env, ?Pattern, ?Bn -> ((Env, Env))
/// ```
pub fn bind_part(benv: &crate::lower::types::Env, menv: &crate::lower::types::Env, p__opt: &Option<crate::syntax::Pattern_>, b_opt: &Option<crate::lower::types::Bn>) -> (crate::lower::types::Env, crate::lower::types::Env) {
    match (p__opt.clone(), b_opt.clone()) {
        (Some(p_), Some(b)) => match &*p_.kind {
            crate::syntax::PatternKind::PName(n) => (crate::lower::types::bind(benv, &crate::check::env::sname_key(n), &b), crate::lower::types::bind(menv, &crate::check::env::sname_key(n), &b)),
            _ => (benv.clone(), menv.clone()),
        },
        _ => (benv.clone(), menv.clone()),
    }
}

/// ```prism
/// BindPart2: fn Wx, Env, Env, ?Pattern, ?Bn -> ((Wx, Env, Env))
/// ```
pub fn bind_part2(wx: &crate::lower::node_::Wx, benv: &crate::lower::types::Env, menv: &crate::lower::types::Env, p__opt: &Option<crate::syntax::Pattern_>, b_opt: &Option<crate::lower::types::Bn>) -> (crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env) {
    let (be, me) = bind_part(benv, menv, p__opt, b_opt);
    (wx.clone(), be.clone(), me.clone())
}

/// ```prism
/// SetResult: fn Wx, Wres -> Wx
/// ```
pub fn set_result(wx: &crate::lower::node_::Wx, res: &crate::lower::node_::Wres) -> crate::lower::node_::Wx {
    let mut this: crate::lower::node_::Wx = wx.clone();
    this.result = res.clone();
    this
}

/// ```prism
/// ResultOf: unbounded fn Wx, Env, Env, Expr -> ((Wres, Wx))
/// ```
pub fn result_of(wx: &crate::lower::node_::Wx, benv: &crate::lower::types::Env, menv: &crate::lower::types::Env, x: &crate::syntax::Expr) -> (crate::lower::node_::Wres, crate::lower::node_::Wx) {
    let lx = wx.lx.clone();
    let full = crate::lower::type_at(&lx, &x.span);
    let t = crate::lower::types::out_ty_of(&lx, &crate::lower::types::peel(&full));
    let bound_opt = match &*x.kind {
        crate::syntax::ExprKind::EName(n) => if &len(&n.path_) == &Nat::from(1u32) {
            get(&menv.names, &crate::check::env::sname_key(n))
        } else {
            None
        },
        _ => None,
    };
    match &bound_opt {
        Some(crate::lower::types::Bn::BnEv(r, _)) => (crate::lower::node_::Wres::WrEv(r.clone()), wx.clone()),
        Some(crate::lower::types::Bn::BnDyn(ex, rds, bt)) => (crate::lower::node_::Wres::WrDyn(ex.clone(), rds.clone(), bt.clone()), wx.clone()),
        _ => result_of_typed(wx, benv, menv, x, &full, &t),
    }
}

/// The step machine of `ResultOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ResultOf: unbounded fn Wx, Env, Env, Expr -> ((Wres, Wx))
/// ```
pub struct ResultOf {
    pub wx: crate::lower::node_::Wx,
    pub benv: crate::lower::types::Env,
    pub menv: crate::lower::types::Env,
    pub x: crate::syntax::Expr,
}

impl prism_rtl::Job<(crate::lower::node_::Wres, crate::lower::node_::Wx)> for ResultOf {
    fn cycle(&self) -> prism_rtl::Turn<(crate::lower::node_::Wres, crate::lower::node_::Wx)> {
        let wx = &self.wx;
        let benv = &self.benv;
        let menv = &self.menv;
        let x = &self.x;
        let lx = wx.lx.clone();
        let full = crate::lower::type_at(&lx, &x.span);
        let benv = benv.clone();
        let menv = menv.clone();
        let wx = wx.clone();
        let x = x.clone();
        call_then(crate::lower::types::start_out_ty_of(lx.clone(), crate::lower::types::peel(&full)), move |out_ty_of_12007: crate::lower::model::OutTy| {
            let t = out_ty_of_12007;
            let bound_opt = match &*x.kind {
                crate::syntax::ExprKind::EName(n) => if &len(&n.path_) == &Nat::from(1u32) {
                    get(&menv.names, &crate::check::env::sname_key(n))
                } else {
                    None
                },
                _ => None,
            };
            match &bound_opt {
                Some(crate::lower::types::Bn::BnEv(r, _)) => prism_rtl::Turn::Finished((crate::lower::node_::Wres::WrEv(r.clone()), wx.clone())),
                Some(crate::lower::types::Bn::BnDyn(ex, rds, bt)) => prism_rtl::Turn::Finished((crate::lower::node_::Wres::WrDyn(ex.clone(), rds.clone(), bt.clone()), wx.clone())),
                _ => prism_rtl::Turn::More(Rc::new(ResultOfTyped { wx: wx.clone(), benv: benv.clone(), menv: menv.clone(), x: x.clone(), full: full.clone(), t: t.clone() })),
            }
        })
    }
}

/// `Start ResultOf, x`: what the function value is when passed to `@Run`.
pub fn start_result_of(wx: crate::lower::node_::Wx, benv: crate::lower::types::Env, menv: crate::lower::types::Env, x: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<(crate::lower::node_::Wres, crate::lower::node_::Wx)>> {
    Rc::new(ResultOf { wx, benv, menv, x })
}

/// ```prism
/// ResultOfTyped: unbounded fn Wx, Env, Env, Expr, Ty, OutTy -> ((Wres, Wx))
/// ```
pub fn result_of_typed(wx: &crate::lower::node_::Wx, benv: &crate::lower::types::Env, menv: &crate::lower::types::Env, x: &crate::syntax::Expr, full: &crate::check::types::Ty, t: &crate::lower::model::OutTy) -> (crate::lower::node_::Wres, crate::lower::node_::Wx) {
    let lx = wx.lx.clone();
    match crate::lower::types::layer_of(full) {
        crate::lower::types::Layer::LyEv => {
            let (r, wx2) = crate::lower::node_::dynamics::event_ref(wx, menv, x);
            (crate::lower::node_::Wres::WrEv(r.clone()), wx2.clone())
        },
        crate::lower::types::Layer::LyDyn => {
            let (ex, reads) = crate::lower::node_::dynamics::dynamic_expr(wx, menv, x);
            (crate::lower::node_::Wres::WrDyn(ex.clone(), reads.clone(), t.clone()), wx.clone())
        },
        _ => if t == &crate::lower::model::OutTy::OutUnit {
            (crate::lower::node_::Wres::WrUnit, wx.clone())
        } else {
            (crate::lower::node_::Wres::WrPlain(crate::lower::types::own(&crate::lower::expr::value_of(&lx, benv, x)), t.clone()), wx.clone())
        },
    }
}

/// The step machine of `ResultOfTyped`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ResultOfTyped: unbounded fn Wx, Env, Env, Expr, Ty, OutTy -> ((Wres, Wx))
/// ```
pub struct ResultOfTyped {
    pub wx: crate::lower::node_::Wx,
    pub benv: crate::lower::types::Env,
    pub menv: crate::lower::types::Env,
    pub x: crate::syntax::Expr,
    pub full: crate::check::types::Ty,
    pub t: crate::lower::model::OutTy,
}

impl prism_rtl::Job<(crate::lower::node_::Wres, crate::lower::node_::Wx)> for ResultOfTyped {
    fn cycle(&self) -> prism_rtl::Turn<(crate::lower::node_::Wres, crate::lower::node_::Wx)> {
        let wx = &self.wx;
        let benv = &self.benv;
        let menv = &self.menv;
        let x = &self.x;
        let full = &self.full;
        let t = &self.t;
        let lx = wx.lx.clone();
        match crate::lower::types::layer_of(full) {
            crate::lower::types::Layer::LyEv => {
                let menv = menv.clone();
                let wx = wx.clone();
                let x = x.clone();
                call_then(crate::lower::node_::dynamics::start_event_ref(wx.clone(), menv.clone(), x.clone()), move |event_ref_12543: (crate::lower::node_::EvRef, crate::lower::node_::Wx)| {
                    let (r, wx2) = event_ref_12543;
                    prism_rtl::Turn::Finished((crate::lower::node_::Wres::WrEv(r.clone()), wx2.clone()))
                })
            },
            crate::lower::types::Layer::LyDyn => {
                let menv = menv.clone();
                let t = t.clone();
                let wx = wx.clone();
                let x = x.clone();
                call_then(crate::lower::node_::dynamics::start_dynamic_expr(wx.clone(), menv.clone(), x.clone()), move |dynamic_expr_12639: (crate::lower::model::Ex, Array<crate::lower::node_::Read>)| {
                    let (ex, reads) = dynamic_expr_12639;
                    prism_rtl::Turn::Finished((crate::lower::node_::Wres::WrDyn(ex.clone(), reads.clone(), t.clone()), wx.clone()))
                })
            },
            _ => if t == &crate::lower::model::OutTy::OutUnit {
                prism_rtl::Turn::Finished((crate::lower::node_::Wres::WrUnit, wx.clone()))
            } else {
                {
                    let benv = benv.clone();
                    let t = t.clone();
                    let wx = wx.clone();
                    let x = x.clone();
                    call_then(crate::lower::expr::start_value_of(lx.clone(), benv.clone(), x.clone()), move |value_of_12802: crate::lower::types::Vl| prism_rtl::Turn::Finished((crate::lower::node_::Wres::WrPlain(crate::lower::types::own(&value_of_12802), t.clone()), wx.clone())))
                }
            },
        }
    }
}

/// `Start ResultOfTyped, x`: what the function value is when passed to `@Run`.
pub fn start_result_of_typed(wx: crate::lower::node_::Wx, benv: crate::lower::types::Env, menv: crate::lower::types::Env, x: crate::syntax::Expr, full: crate::check::types::Ty, t: crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<(crate::lower::node_::Wres, crate::lower::node_::Wx)>> {
    Rc::new(ResultOfTyped { wx, benv, menv, x, full, t })
}

/// ```prism
/// HoldLine: unbounded fn Wx, Env, Env, Pattern, Expr, Expr -> ((Wx, Env))
/// ```
pub fn hold_line(wx: &crate::lower::node_::Wx, benv: &crate::lower::types::Env, menv: &crate::lower::types::Env, p_: &crate::syntax::Pattern_, init: &crate::syntax::Expr, step_: &crate::syntax::Expr) -> (crate::lower::node_::Wx, crate::lower::types::Env) {
    let lx = wx.lx.clone();
    match binding_of(menv, p_) {
        Some(crate::lower::types::Bn::BnHold(f, t)) => {
            let iv = crate::lower::types::own(&crate::lower::expr::value_of(&lx, benv, init));
            let wx1 = crate::lower::node_::add_field(wx, &f, &crate::lower::model::OutTy::OutHold(Rc::new(t.clone())), &Text::from(format!("`{}`", &pat_text(p_))), &crate::lower::model::Ex::XCall(Text::lit("Hold::new"), Array::from(vec![crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(Text::from(format!("{}_init", &f))))), crate::lower::model::Ex::XCx])));
            let (r, wx2) = crate::lower::node_::dynamics::event_ref(&wx1, menv, step_);
            let wx3 = {
                let mut this: crate::lower::node_::Wx = crate::lower::node_::connect(&wx2, &r, &crate::lower::node_::Sk::SkHold(f.clone()));
                this.lets = push(&this.lets, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaBind(Text::from(format!("{}_init", &f)))), t.clone()), iv.clone()));
                this.inited = push(&this.inited, &f);
                this
            };
            (wx3.clone(), crate::lower::types::bind(benv, &Text::from(format!("{}#init", &pat_text(p_))), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(Text::from(format!("{}_init", &f))), crate::lower::types::Holding::Owned, t.clone())))
        },
        _ => (wx.clone(), benv.clone()),
    }
}

/// The step machine of `HoldLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// HoldLine: unbounded fn Wx, Env, Env, Pattern, Expr, Expr -> ((Wx, Env))
/// ```
pub struct HoldLine {
    pub wx: crate::lower::node_::Wx,
    pub benv: crate::lower::types::Env,
    pub menv: crate::lower::types::Env,
    pub p_: crate::syntax::Pattern_,
    pub init: crate::syntax::Expr,
    pub step_: crate::syntax::Expr,
}

impl prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env)> for HoldLine {
    fn cycle(&self) -> prism_rtl::Turn<(crate::lower::node_::Wx, crate::lower::types::Env)> {
        let wx = &self.wx;
        let benv = &self.benv;
        let menv = &self.menv;
        let p_ = &self.p_;
        let init = &self.init;
        let step_ = &self.step_;
        let lx = wx.lx.clone();
        match binding_of(menv, p_) {
            Some(crate::lower::types::Bn::BnHold(f, t)) => {
                let benv = benv.clone();
                let init = init.clone();
                let menv = menv.clone();
                let p_ = p_.clone();
                let step_ = step_.clone();
                let wx = wx.clone();
                call_then(crate::lower::expr::start_value_of(lx.clone(), benv.clone(), init.clone()), move |value_of_13357: crate::lower::types::Vl| {
                    let iv = crate::lower::types::own(&value_of_13357);
                    let wx1 = crate::lower::node_::add_field(&wx, &f, &crate::lower::model::OutTy::OutHold(Rc::new(t.clone())), &Text::from(format!("`{}`", &pat_text(&p_))), &crate::lower::model::Ex::XCall(Text::lit("Hold::new"), Array::from(vec![crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(Text::from(format!("{}_init", &f))))), crate::lower::model::Ex::XCx])));
                    call_then(crate::lower::node_::dynamics::start_event_ref(wx1.clone(), menv.clone(), step_.clone()), move |event_ref_13535: (crate::lower::node_::EvRef, crate::lower::node_::Wx)| {
                        let (r, wx2) = event_ref_13535;
                        let wx3 = {
                            let mut this: crate::lower::node_::Wx = crate::lower::node_::connect(&wx2, &r, &crate::lower::node_::Sk::SkHold(f.clone()));
                            this.lets = push(&this.lets, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaBind(Text::from(format!("{}_init", &f)))), t.clone()), iv.clone()));
                            this.inited = push(&this.inited, &f);
                            this
                        };
                        prism_rtl::Turn::Finished((wx3.clone(), crate::lower::types::bind(&benv, &Text::from(format!("{}#init", &pat_text(&p_))), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(Text::from(format!("{}_init", &f))), crate::lower::types::Holding::Owned, t.clone()))))
                    })
                })
            },
            _ => prism_rtl::Turn::Finished((wx.clone(), benv.clone())),
        }
    }
}

/// `Start HoldLine, x`: what the function value is when passed to `@Run`.
pub fn start_hold_line(wx: crate::lower::node_::Wx, benv: crate::lower::types::Env, menv: crate::lower::types::Env, p_: crate::syntax::Pattern_, init: crate::syntax::Expr, step_: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env)>> {
    Rc::new(HoldLine { wx, benv, menv, p_, init, step_ })
}

/// ```prism
/// InitEnv: fn Env -> Env
/// ```
pub fn init_env(env: &crate::lower::types::Env) -> crate::lower::types::Env {
    fold(&keys(&env.names), env, &(|en: &crate::lower::types::Env, k: &Text| match (crate::syntax::lexer::chars::before_suffix(k, &Text::lit("#init")), get(&env.names, k)) {
        (Some(name), Some(b)) => crate::lower::types::bind(en, &name, &b),
        _ => en.clone(),
    }))
}

/// ```prism
/// AllInited: fn Wx, [Read] -> Bool
/// ```
pub fn all_inited(wx: &crate::lower::node_::Wx, reads: &Array<crate::lower::node_::Read>) -> bool {
    fold(&crate::lower::node_::finish::reads_closed(&wx.dyn_reads, reads), &true, &(|ok: &bool, r: &crate::lower::node_::Read| *ok && match r {
        crate::lower::node_::Read::OwnRead(f) => crate::check::types::has_text(&wx.inited, f),
        crate::lower::node_::Read::ParentRead(_) => false,
    }))
}

/// ```prism
/// PatText: fn Pattern -> Text
/// ```
pub fn pat_text(p_: &crate::syntax::Pattern_) -> Text {
    match &*p_.kind {
        crate::syntax::PatternKind::PName(n) => crate::check::env::sname_key(n),
        _ => Text::lit("_"),
    }
}

/// ```prism
/// LetLine: unbounded fn Wx, Env, Env, Pattern, Expr -> ((Wx, Env))
/// ```
pub fn let_line(wx: &crate::lower::node_::Wx, benv: &crate::lower::types::Env, menv: &crate::lower::types::Env, p_: &crate::syntax::Pattern_, e: &crate::syntax::Expr) -> (crate::lower::node_::Wx, crate::lower::types::Env) {
    let lx = wx.lx.clone();
    match binding_of(menv, p_) {
        Some(crate::lower::types::Bn::BnEv(er, t)) => {
            let (r, wx2) = crate::lower::node_::dynamics::event_ref(wx, menv, e);
            let fed = crate::lower::types::out_ty_of(&lx, &crate::lower::types::peel(&crate::lower::types::peel(&crate::lower::type_at(&lx, &e.span))));
            let r2 = 'm15327: {
                if let crate::lower::model::OutTy::OutEvent(m15327_0_0) = &t && let crate::lower::model::OutTy::OutRes(_) = &**m15327_0_0 {
                    break 'm15327 if &fed == &crate::lower::model::OutTy::OutError { err_pipe(&r) } else { r.clone() };
                }
                if let crate::lower::model::OutTy::OutRes(_) = &t {
                    break 'm15327 if &fed == &crate::lower::model::OutTy::OutError { err_pipe(&r) } else { r.clone() };
                }
                r.clone()
            };
            (crate::lower::node_::connect(&wx2, &r2, &crate::lower::node_::Sk::SkNode(er.node_.clone())), benv.clone())
        },
        Some(crate::lower::types::Bn::BnDyn(_, _, t)) => {
            let rs = crate::lower::snake(&pat_text(p_));
            let (ex, reads) = crate::lower::node_::dynamics::dynamic_expr(wx, menv, e);
            let getter = crate::lower::model::MethDef { name: rs.clone(), recv: crate::lower::model::Recv::RecvRef, params: Array::new(), cx_: crate::lower::model::CxArg::CxRef, ret: t.clone(), body: Array::new(), tail: ex.clone(), doc: Text::from(format!("`{}`", &pat_text(p_))) };
            let wx2 = {
                let mut this: crate::lower::node_::Wx = wx.clone();
                this.getters = push(&this.getters, &getter);
                this.dyn_reads = insert(&this.dyn_reads, &rs, &reads);
                this
            };
            if all_inited(&wx2, &reads) {
                {
                    let wx3 = {
                        let mut this: crate::lower::node_::Wx = wx2.clone();
                        this.lets = push(&this.lets, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaBind(Text::from(format!("{}_init", &rs)))), t.clone()), crate::lower::types::own(&crate::lower::expr::value_of(&lx, &init_env(benv), e))));
                        this.inited = push(&this.inited, &rs);
                        this
                    };
                    (wx3.clone(), crate::lower::types::bind(benv, &Text::from(format!("{}#init", &pat_text(p_))), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(Text::from(format!("{}_init", &rs))), crate::lower::types::Holding::Owned, t.clone())))
                }
            } else {
                (wx2.clone(), benv.clone())
            }
        },
        Some(crate::lower::types::Bn::BnLocal(rs, _, t)) => {
            let insts_opt = match &*p_.kind {
                crate::syntax::PatternKind::PName(n) => many_instances(&lx, &n.span),
                _ => None,
            };
            match &insts_opt {
                Some(insts) => match &*p_.kind {
                    crate::syntax::PatternKind::PName(n) => {
                        let nkey = crate::check::env::sname_key(n);
                        let wxn = run_to_end(fold_job(crate::check::errors::range0(&len(insts)), wx.clone(), {
                            let lx = lx.clone();
                            let insts = insts.clone();
                            let nkey = nkey.clone();
                            let menv = menv.clone();
                            let benv = benv.clone();
                            let e = e.clone();
                            Rc::new(move |(p0, p1): (crate::lower::node_::Wx, Nat)| {
                                let lx = lx.clone();
                                let insts = insts.clone();
                                let nkey = nkey.clone();
                                let menv = menv.clone();
                                let benv = benv.clone();
                                let e = e.clone();
                                entered(once_job(move || {
                                    let w = p0;
                                    let k = p1;
                                    {
                                        let lxk = crate::lower::expr::at_instance(&lx, &or(&index(&insts, &k), &(Array::new(), Array::new())));
                                        let bkey = if &k == &Nat::from(0u32) {
                                            nkey.clone()
                                        } else {
                                            Text::from(format!("{}#inst{}", &nkey, &k))
                                        };
                                        match get(&menv.names, &bkey) {
                                            Some(crate::lower::types::Bn::BnLocal(rk, _, tk)) => call_then(crate::lower::expr::start_value_of(lxk.clone(), benv.clone(), e.clone()), move |value_of_17130: crate::lower::types::Vl| prism_rtl::Turn::Finished(widget_let_field(&w, &crate::lower::types::place_stem(&rk), &tk, &crate::lower::types::own(&value_of_17130), &Text::from(format!("`{}` at its instantiation {}", &nkey, &k))))),
                                            _ => prism_rtl::Turn::Finished({
                                                let mut this: crate::lower::node_::Wx = w.clone();
                                                this.build = push(&this.build, &crate::lower::expr::refusal_do(&Text::from(format!("`{}` at its instantiation {}, which has no binding", &nkey, &k))));
                                                this
                                            }),
                                        }
                                    }
                                }))
                            }) as Rc<dyn Fn((crate::lower::node_::Wx, Nat)) -> Rc<dyn prism_rtl::Job<crate::lower::node_::Wx>>>
                        }));
                        (wxn.clone(), benv.clone())
                    },
                    _ => (wx.clone(), benv.clone()),
                },
                None => {
                    let lxw = match &*p_.kind {
                        crate::syntax::PatternKind::PName(n) => crate::lower::expr::widget_let_lx(&lx, &n.span),
                        _ => lx.clone(),
                    };
                    let v_ = crate::lower::types::own(&crate::lower::expr::value_of(&lxw, benv, e));
                    (widget_let_field(wx, &crate::lower::types::place_stem(&rs), &t, &v_, &Text::from(format!("`{}`", &pat_text(p_)))), benv.clone())
                },
            }
        },
        _ => (wx.clone(), benv.clone()),
    }
}

/// The step machine of `LetLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LetLine: unbounded fn Wx, Env, Env, Pattern, Expr -> ((Wx, Env))
/// ```
pub struct LetLine {
    pub wx: crate::lower::node_::Wx,
    pub benv: crate::lower::types::Env,
    pub menv: crate::lower::types::Env,
    pub p_: crate::syntax::Pattern_,
    pub e: crate::syntax::Expr,
}

impl prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env)> for LetLine {
    fn cycle(&self) -> prism_rtl::Turn<(crate::lower::node_::Wx, crate::lower::types::Env)> {
        let wx = &self.wx;
        let benv = &self.benv;
        let menv = &self.menv;
        let p_ = &self.p_;
        let e = &self.e;
        let lx = wx.lx.clone();
        match binding_of(menv, p_) {
            Some(crate::lower::types::Bn::BnEv(er, t)) => {
                let benv = benv.clone();
                let e = e.clone();
                let menv = menv.clone();
                let wx = wx.clone();
                call_then(crate::lower::node_::dynamics::start_event_ref(wx.clone(), menv.clone(), e.clone()), move |event_ref_15217: (crate::lower::node_::EvRef, crate::lower::node_::Wx)| {
                    let (r, wx2) = event_ref_15217;
                    call_then(crate::lower::types::start_out_ty_of(lx.clone(), crate::lower::types::peel(&crate::lower::types::peel(&crate::lower::type_at(&lx, &e.span)))), move |out_ty_of_15260: crate::lower::model::OutTy| {
                        let fed = out_ty_of_15260;
                        let r2 = 'm15327: {
                            if let crate::lower::model::OutTy::OutEvent(m15327_0_0) = &t && let crate::lower::model::OutTy::OutRes(_) = &**m15327_0_0 {
                                break 'm15327 if &fed == &crate::lower::model::OutTy::OutError { err_pipe(&r) } else { r.clone() };
                            }
                            if let crate::lower::model::OutTy::OutRes(_) = &t {
                                break 'm15327 if &fed == &crate::lower::model::OutTy::OutError { err_pipe(&r) } else { r.clone() };
                            }
                            r.clone()
                        };
                        prism_rtl::Turn::Finished((crate::lower::node_::connect(&wx2, &r2, &crate::lower::node_::Sk::SkNode(er.node_.clone())), benv.clone()))
                    })
                })
            },
            Some(crate::lower::types::Bn::BnDyn(_, _, t)) => {
                let rs = crate::lower::snake(&pat_text(p_));
                let benv = benv.clone();
                let e = e.clone();
                let menv = menv.clone();
                let p_ = p_.clone();
                let wx = wx.clone();
                call_then(crate::lower::node_::dynamics::start_dynamic_expr(wx.clone(), menv.clone(), e.clone()), move |dynamic_expr_15680: (crate::lower::model::Ex, Array<crate::lower::node_::Read>)| {
                    let (ex, reads) = dynamic_expr_15680;
                    let getter = crate::lower::model::MethDef { name: rs.clone(), recv: crate::lower::model::Recv::RecvRef, params: Array::new(), cx_: crate::lower::model::CxArg::CxRef, ret: t.clone(), body: Array::new(), tail: ex.clone(), doc: Text::from(format!("`{}`", &pat_text(&p_))) };
                    let wx2 = {
                        let mut this: crate::lower::node_::Wx = wx.clone();
                        this.getters = push(&this.getters, &getter);
                        this.dyn_reads = insert(&this.dyn_reads, &rs, &reads);
                        this
                    };
                    if all_inited(&wx2, &reads) {
                        {
                            let wx3 = {
                                let mut this: crate::lower::node_::Wx = wx2.clone();
                                this.lets = push(&this.lets, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaBind(Text::from(format!("{}_init", &rs)))), t.clone()), crate::lower::types::own(&crate::lower::expr::value_of(&lx, &init_env(&benv), &e))));
                                this.inited = push(&this.inited, &rs);
                                this
                            };
                            prism_rtl::Turn::Finished((wx3.clone(), crate::lower::types::bind(&benv, &Text::from(format!("{}#init", &pat_text(&p_))), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(Text::from(format!("{}_init", &rs))), crate::lower::types::Holding::Owned, t.clone()))))
                        }
                    } else {
                        prism_rtl::Turn::Finished((wx2.clone(), benv.clone()))
                    }
                })
            },
            Some(crate::lower::types::Bn::BnLocal(rs, _, t)) => {
                let insts_opt = match &*p_.kind {
                    crate::syntax::PatternKind::PName(n) => many_instances(&lx, &n.span),
                    _ => None,
                };
                match &insts_opt {
                    Some(insts) => match &*p_.kind {
                        crate::syntax::PatternKind::PName(n) => {
                            let nkey = crate::check::env::sname_key(n);
                            let benv = benv.clone();
                            let e = e.clone();
                            let insts = insts.clone();
                            let menv = menv.clone();
                            let wx = wx.clone();
                            call_value(fold_job(crate::check::errors::range0(&len(&insts)), wx.clone(), {
                                let lx = lx.clone();
                                let insts = insts.clone();
                                let nkey = nkey.clone();
                                let menv = menv.clone();
                                let benv = benv.clone();
                                let e = e.clone();
                                Rc::new(move |(p0, p1): (crate::lower::node_::Wx, Nat)| {
                                    let lx = lx.clone();
                                    let insts = insts.clone();
                                    let nkey = nkey.clone();
                                    let menv = menv.clone();
                                    let benv = benv.clone();
                                    let e = e.clone();
                                    entered(once_job(move || {
                                        let w = p0;
                                        let k = p1;
                                        {
                                            let lxk = crate::lower::expr::at_instance(&lx, &or(&index(&insts, &k), &(Array::new(), Array::new())));
                                            let bkey = if &k == &Nat::from(0u32) {
                                                nkey.clone()
                                            } else {
                                                Text::from(format!("{}#inst{}", &nkey, &k))
                                            };
                                            match get(&menv.names, &bkey) {
                                                Some(crate::lower::types::Bn::BnLocal(rk, _, tk)) => call_then(crate::lower::expr::start_value_of(lxk.clone(), benv.clone(), e.clone()), move |value_of_17130: crate::lower::types::Vl| prism_rtl::Turn::Finished(widget_let_field(&w, &crate::lower::types::place_stem(&rk), &tk, &crate::lower::types::own(&value_of_17130), &Text::from(format!("`{}` at its instantiation {}", &nkey, &k))))),
                                                _ => prism_rtl::Turn::Finished({
                                                    let mut this: crate::lower::node_::Wx = w.clone();
                                                    this.build = push(&this.build, &crate::lower::expr::refusal_do(&Text::from(format!("`{}` at its instantiation {}, which has no binding", &nkey, &k))));
                                                    this
                                                }),
                                            }
                                        }
                                    }))
                                }) as Rc<dyn Fn((crate::lower::node_::Wx, Nat)) -> Rc<dyn prism_rtl::Job<crate::lower::node_::Wx>>>
                            }), move |fold_16774: crate::lower::node_::Wx| {
                                let wxn = fold_16774;
                                prism_rtl::Turn::Finished((wxn.clone(), benv.clone()))
                            })
                        },
                        _ => prism_rtl::Turn::Finished((wx.clone(), benv.clone())),
                    },
                    None => {
                        let lxw = match &*p_.kind {
                            crate::syntax::PatternKind::PName(n) => crate::lower::expr::widget_let_lx(&lx, &n.span),
                            _ => lx.clone(),
                        };
                        let benv = benv.clone();
                        let e = e.clone();
                        let p_ = p_.clone();
                        let wx = wx.clone();
                        call_then(crate::lower::expr::start_value_of(lxw.clone(), benv.clone(), e.clone()), move |value_of_17650: crate::lower::types::Vl| {
                            let v_ = crate::lower::types::own(&value_of_17650);
                            prism_rtl::Turn::Finished((widget_let_field(&wx, &crate::lower::types::place_stem(&rs), &t, &v_, &Text::from(format!("`{}`", &pat_text(&p_)))), benv.clone()))
                        })
                    },
                }
            },
            _ => prism_rtl::Turn::Finished((wx.clone(), benv.clone())),
        }
    }
}

/// `Start LetLine, x`: what the function value is when passed to `@Run`.
pub fn start_let_line(wx: crate::lower::node_::Wx, benv: crate::lower::types::Env, menv: crate::lower::types::Env, p_: crate::syntax::Pattern_, e: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env)>> {
    Rc::new(LetLine { wx, benv, menv, p_, e })
}

/// ```prism
/// WidgetLetField: fn Wx, Text, OutTy, Ex, Text -> Wx
/// ```
pub fn widget_let_field(wx: &crate::lower::node_::Wx, f: &Text, t: &crate::lower::model::OutTy, v_: &crate::lower::model::Ex, doc: &Text) -> crate::lower::node_::Wx {
    let mut this: crate::lower::node_::Wx = wx.clone();
    this.lets = push(&this.lets, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(f.clone()), v_.clone()));
    this.fields = push(&this.fields, &(f.clone(), t.clone(), doc.clone()));
    this.inits = push(&this.inits, &(f.clone(), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(f.clone())))));
    this
}

/// ```prism
/// ErrPipe: fn EvRef -> EvRef
/// ```
pub fn err_pipe(r: &crate::lower::node_::EvRef) -> crate::lower::node_::EvRef {
    crate::lower::node_::EvRef { node_: r.node_.clone(), owner: r.owner.clone(), pipe: {
        let r = r.clone();
        Rc::new(move |(p0, p1): (crate::lower::model::Ex, Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>)| {
            let r = r.clone();
            entered(once_job(move || {
                let x = p0;
                let k_fn = p1;
                (&r.pipe)((x.clone(), {
                    let k_fn = k_fn.clone();
                    Rc::new(move |p0: crate::lower::model::Ex| {
                        let k_fn = k_fn.clone();
                        entered(once_job(move || {
                            let y = p0;
                            (&k_fn)(crate::lower::model::Ex::XCtor(Text::lit("Err"), Array::from(vec![y.clone()]))).cycle()
                        }))
                    }) as Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>
                })).cycle()
            }))
        }) as Rc<dyn Fn((crate::lower::model::Ex, Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>)) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>
    } }
}

/// ```prism
/// OwnAs: fn OutTy, Vl -> Ex
/// ```
pub fn own_as(t: &crate::lower::model::OutTy, v_: &crate::lower::types::Vl) -> crate::lower::model::Ex {
    match t {
        crate::lower::model::OutTy::OutRes(_) => if &crate::lower::types::value_ty(v_) == &crate::lower::model::OutTy::OutError {
            crate::lower::model::Ex::XCtor(Text::lit("Err"), Array::from(vec![crate::lower::types::own(v_)]))
        } else {
            crate::lower::types::own(v_)
        },
        _ => crate::lower::types::own(v_),
    }
}

/// ```prism
/// BindRes: fn Wx, Env, Pattern, Wres -> Wx
/// ```
pub fn bind_res(wx2: &crate::lower::node_::Wx, menv: &crate::lower::types::Env, p_: &crate::syntax::Pattern_, res: &crate::lower::node_::Wres) -> crate::lower::node_::Wx {
    match binding_of(menv, p_) {
        Some(crate::lower::types::Bn::BnEv(er, _)) => match res {
            crate::lower::node_::Wres::WrEv(r) => if &er.owner != &wx2.node_ {
                crate::lower::node_::crossed(wx2, &Text::from(format!("the bound event of node `{}` (its graph node {})", &er.owner, &er.node_)))
            } else {
                if &r.node_ == &er.node_ {
                    wx2.clone()
                } else {
                    crate::lower::node_::connect(wx2, r, &crate::lower::node_::Sk::SkNode(er.node_.clone()))
                }
            },
            _ => wx2.clone(),
        },
        _ => wx2.clone(),
    }
}

/// ```prism
/// BuildLine: unbounded fn Wx, Env, Env, Expr, ?Bn -> ((Wx, Wres))
/// ```
pub fn build_line(wx: &crate::lower::node_::Wx, benv: &crate::lower::types::Env, menv: &crate::lower::types::Env, e: &crate::syntax::Expr, bound_opt: &Option<crate::lower::types::Bn>) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    let lx = wx.lx.clone();
    let full = crate::lower::type_at(&lx, &e.span);
    'm19427: {
        let scrutinee = &*e.kind;
        if let crate::syntax::ExprKind::EGroup(x) = scrutinee {
            break 'm19427 build_line(wx, benv, menv, &**x, bound_opt);
        }
        if let crate::syntax::ExprKind::EWidgetBlock(b) = scrutinee {
            break 'm19427 crate::lower::node_::static_::inline_block(wx, benv, menv, b, &lx);
        }
        if let crate::syntax::ExprKind::EFor(binders_opt, source, body) = scrutinee {
            break 'm19427 crate::lower::node_::keyed::for_line(wx, benv, menv, binders_opt, &**source, body, e, bound_opt);
        }
        if let crate::syntax::ExprKind::ERebuild(scrut, body) = scrutinee {
            break 'm19427 crate::lower::node_::switch_::rebuild_line(wx, benv, menv, &**scrut, body, e, bound_opt);
        }
        if let crate::syntax::ExprKind::EIf(m19427_4_0, then_b, Some(else_b)) = scrutinee && let crate::syntax::Cond::CondExpr(c) = &**m19427_4_0 {
            break 'm19427 crate::lower::functions::if_gen_line(wx, menv, &**c, then_b, else_b, e);
        }
        match crate::lower::types::peel(&full) {
            crate::check::types::Ty::TyElem(_, _) => crate::lower::node_::elements::element_line(wx, benv, menv, e, bound_opt),
            crate::check::types::Ty::TyAt(_, _) => crate::lower::node_::static_::widget_line(wx, benv, menv, e, bound_opt),
            _ => {
                let wx2 = {
                    let mut this: crate::lower::node_::Wx = wx.clone();
                    this.build = push(&this.build, &crate::lower::expr::refusal_do(&Text::lit("a building line this back end does not lower yet")));
                    this
                };
                (wx2.clone(), crate::lower::node_::Wres::WrUnit)
            },
        }
    }
}

/// The step machine of `BuildLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BuildLine: unbounded fn Wx, Env, Env, Expr, ?Bn -> ((Wx, Wres))
/// ```
pub struct BuildLine {
    pub wx: crate::lower::node_::Wx,
    pub benv: crate::lower::types::Env,
    pub menv: crate::lower::types::Env,
    pub e: crate::syntax::Expr,
    pub bound_opt: Option<crate::lower::types::Bn>,
}

impl prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::node_::Wres)> for BuildLine {
    fn cycle(&self) -> prism_rtl::Turn<(crate::lower::node_::Wx, crate::lower::node_::Wres)> {
        let wx = &self.wx;
        let benv = &self.benv;
        let menv = &self.menv;
        let e = &self.e;
        let bound_opt = &self.bound_opt;
        let lx = wx.lx.clone();
        let full = crate::lower::type_at(&lx, &e.span);
        'm19427: {
            let scrutinee = &*e.kind;
            if let crate::syntax::ExprKind::EGroup(x) = scrutinee {
                break 'm19427 prism_rtl::Turn::More(Rc::new(BuildLine { wx: wx.clone(), benv: benv.clone(), menv: menv.clone(), e: (**x).clone(), bound_opt: bound_opt.clone() }));
            }
            if let crate::syntax::ExprKind::EWidgetBlock(b) = scrutinee {
                break 'm19427 prism_rtl::Turn::More(Rc::new(crate::lower::node_::static_::InlineBlock { wx: wx.clone(), benv: benv.clone(), menv: menv.clone(), b: b.clone(), lx: lx.clone() }));
            }
            if let crate::syntax::ExprKind::EFor(binders_opt, source, body) = scrutinee {
                break 'm19427 prism_rtl::Turn::More(Rc::new(crate::lower::node_::keyed::ForLine { wx: wx.clone(), benv: benv.clone(), menv: menv.clone(), binders_opt: binders_opt.clone(), source: (**source).clone(), body: body.clone(), e: e.clone(), bound_opt: bound_opt.clone() }));
            }
            if let crate::syntax::ExprKind::ERebuild(scrut, body) = scrutinee {
                break 'm19427 prism_rtl::Turn::More(Rc::new(crate::lower::node_::switch_::RebuildLine { wx: wx.clone(), benv: benv.clone(), menv: menv.clone(), scrut: (**scrut).clone(), body: body.clone(), e: e.clone(), bound_opt: bound_opt.clone() }));
            }
            if let crate::syntax::ExprKind::EIf(m19427_4_0, then_b, Some(else_b)) = scrutinee && let crate::syntax::Cond::CondExpr(c) = &**m19427_4_0 {
                break 'm19427 prism_rtl::Turn::More(Rc::new(crate::lower::functions::IfGenLine { wx: wx.clone(), menv: menv.clone(), c: (**c).clone(), then_b: then_b.clone(), else_b: else_b.clone(), e: e.clone() }));
            }
            match crate::lower::types::peel(&full) {
                crate::check::types::Ty::TyElem(_, _) => prism_rtl::Turn::More(Rc::new(crate::lower::node_::elements::ElementLine { wx: wx.clone(), benv: benv.clone(), menv: menv.clone(), e: e.clone(), bound_opt: bound_opt.clone() })),
                crate::check::types::Ty::TyAt(_, _) => prism_rtl::Turn::More(Rc::new(crate::lower::node_::static_::WidgetLine { wx: wx.clone(), benv: benv.clone(), menv: menv.clone(), e: e.clone(), bound_opt: bound_opt.clone() })),
                _ => {
                    let wx2 = {
                        let mut this: crate::lower::node_::Wx = wx.clone();
                        this.build = push(&this.build, &crate::lower::expr::refusal_do(&Text::lit("a building line this back end does not lower yet")));
                        this
                    };
                    prism_rtl::Turn::Finished((wx2.clone(), crate::lower::node_::Wres::WrUnit))
                },
            }
        }
    }
}

/// `Start BuildLine, x`: what the function value is when passed to `@Run`.
pub fn start_build_line(wx: crate::lower::node_::Wx, benv: crate::lower::types::Env, menv: crate::lower::types::Env, e: crate::syntax::Expr, bound_opt: Option<crate::lower::types::Bn>) -> Rc<dyn prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::node_::Wres)>> {
    Rc::new(BuildLine { wx, benv, menv, e, bound_opt })
}
