//! The module `Lower.Node.Def`, from `target/bootstrap/src/prismc/lower/node/def.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// `HowBound`:
///
/// ```prism
/// type HowBound = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum HowBound {
    AsHold,
    AsBind,
    AsLet,
    AsResult,
}

impl Show for HowBound {
    fn show(&self, p: &mut Printer) {
        match self {
            HowBound::AsHold => p.choice("AsHold", &[]),
            HowBound::AsBind => p.choice("AsBind", &[]),
            HowBound::AsLet => p.choice("AsLet", &[]),
            HowBound::AsResult => p.choice("AsResult", &[]),
        }
    }
}

impl ToPod for HowBound {
    fn to_pod(&self) -> Pod {
        match self {
            HowBound::AsHold => Pod::Choice("AsHold".into(), vec![]),
            HowBound::AsBind => Pod::Choice("AsBind".into(), vec![]),
            HowBound::AsLet => Pod::Choice("AsLet".into(), vec![]),
            HowBound::AsResult => Pod::Choice("AsResult".into(), vec![]),
        }
    }
}

impl FromPod for HowBound {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "AsHold" && a.len() == 0 => Ok(HowBound::AsHold),
            Pod::Choice(c, a) if &**c == "AsBind" && a.len() == 0 => Ok(HowBound::AsBind),
            Pod::Choice(c, a) if &**c == "AsLet" && a.len() == 0 => Ok(HowBound::AsLet),
            Pod::Choice(c, a) if &**c == "AsResult" && a.len() == 0 => Ok(HowBound::AsResult),
            other => mismatch("a HowBound", other),
        }
    }
}

/// ```prism
/// NodeDefOf: unbounded fn Lx, Text, [Pattern], Block, Scheme, Bool -> NodeDef
/// ```
pub fn node_def_of_f(lx_p0: &crate::lower::Lx, qk_p1: &Text, params_p2: &Array<crate::syntax::Pattern_>, body_p3: &crate::syntax::Block, sc_p4: &crate::check::types::Scheme, is_root_p5: &bool) -> crate::lower::model::NodeDef {
    let name_p6 = crate::lower::camel_f(&crate::check::types::bare_name_f(qk_p1));
    let ptys_p7 = match &sc_p4.ty_p {
        crate::check::types::Ty::TyFn(_, ps_pb, _) => ps_pb.clone(),
        _ => Array::new(),
    };
    let wx0_p8 = crate::lower::node_::new_wx_f(lx_p0, &name_p6, &Array::new(), &Array::new(), &Array::new(), &Array::new(), &Map::new(), &crate::lower::node_::node_hooks_p(), &Array::new(), &None);
    let (ps_pq, wx1_pr, benv_ps, menv_pt) = crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(params_p2)), (Array::new(), wx0_p8.clone(), crate::lower::types::empty_env_p(), crate::lower::types::empty_env_p()), {
        let params_p2x = params_p2.clone();
        let lx_p0x = lx_p0.clone();
        let ptys_p7x = ptys_p7.clone();
        Rc::new(move |(p0, p1): ((Array<(Text, crate::lower::model::OutTy)>, crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), Nat)| {
            let params_p2xy = params_p2x.clone();
            let lx_p0xy = lx_p0x.clone();
            let ptys_p7xy = ptys_p7x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (acc_pc, w_pd, be_pe, me_pf) = p0;
                let i_pg = p1;
                {
                    let p_ph = crate::prelude::or(&crate::prelude::index(&params_p2xy, &i_pg), &crate::lower::patterns::dummy_pat_p());
                    let nkey_pi = crate::lower::functions::plain_binder_f(&lx_p0xy, &p_ph);
                    let base_pj = if &nkey_pi == &Text::lit("") {
                        Text::from(format!("arg{}", &i_pg))
                    } else {
                        crate::lower::snake_f(&nkey_pi)
                    };
                    let (rs_pm, w2_pn) = crate::lower::node_::fresh_name_f(&w_pd, &base_pj);
                    crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0xy.clone(), crate::lower::types::peel_f(&crate::prelude::or(&crate::prelude::index(&ptys_p7xy, &i_pg), &crate::check::types::Ty::TyErr))), move |out_ty_of_f_1975: crate::lower::model::OutTy| {
                        let t_pk = out_ty_of_f_1975;
                        let w3_pl = {
                            let mut this: crate::lower::node_::Wx = w2_pn.clone();
                            this.fields_p = crate::prelude::push(&this.fields_p, &(rs_pm.clone(), t_pk.clone(), Text::lit("a parameter")));
                            this.inits_p = crate::prelude::push(&this.inits_p, &(rs_pm.clone(), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(rs_pm.clone())))));
                            this
                        };
                        let (be2_po, me2_pp) = crate::lower::node_::bind_plain_f(&be_pe, &me_pf, &nkey_pi, &rs_pm, &t_pk);
                        prism_rtl::Turn::Finished((crate::prelude::push(&acc_pc, &(rs_pm.clone(), t_pk.clone())), w3_pl.clone(), be2_po.clone(), me2_pp.clone()))
                    })
                }
            }))
        }) as Rc<dyn Fn(((Array<(Text, crate::lower::model::OutTy)>, crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), Nat)) -> Rc<dyn prism_rtl::Job<(Array<(Text, crate::lower::model::OutTy)>, crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>>>
    }));
    let wx2_p9 = block_into_f(&wx1_pr, &benv_ps, &menv_pt, body_p3);
    let wx3_pa = if *is_root_p5 { root_result_f(&wx2_p9) } else { wx2_p9.clone() };
    crate::lower::node_::finish::finish_node_f(&wx3_pa, qk_p1, &ps_pq, &false)
}

/// The step machine of `NodeDefOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// NodeDefOf: unbounded fn Lx, Text, [Pattern], Block, Scheme, Bool -> NodeDef
/// ```
pub struct NodeDefOf {
    pub lx_p0: crate::lower::Lx,
    pub qk_p1: Text,
    pub params_p2: Array<crate::syntax::Pattern_>,
    pub body_p3: crate::syntax::Block,
    pub sc_p4: crate::check::types::Scheme,
    pub is_root_p5: bool,
}

impl prism_rtl::Job<crate::lower::model::NodeDef> for NodeDefOf {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::NodeDef> {
        let lx_p0 = &self.lx_p0;
        let qk_p1 = &self.qk_p1;
        let params_p2 = &self.params_p2;
        let body_p3 = &self.body_p3;
        let sc_p4 = &self.sc_p4;
        let is_root_p5 = &self.is_root_p5;
        let name_p6 = crate::lower::camel_f(&crate::check::types::bare_name_f(qk_p1));
        let ptys_p7 = match &sc_p4.ty_p {
            crate::check::types::Ty::TyFn(_, ps_pb, _) => ps_pb.clone(),
            _ => Array::new(),
        };
        let wx0_p8 = crate::lower::node_::new_wx_f(lx_p0, &name_p6, &Array::new(), &Array::new(), &Array::new(), &Array::new(), &Map::new(), &crate::lower::node_::node_hooks_p(), &Array::new(), &None);
        let body_p3x = body_p3.clone();
        let is_root_p5x = *is_root_p5;
        let lx_p0x = lx_p0.clone();
        let params_p2x = params_p2.clone();
        let qk_p1x = qk_p1.clone();
        crate::prelude::call_value(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(&params_p2x)), (Array::new(), wx0_p8.clone(), crate::lower::types::empty_env_p(), crate::lower::types::empty_env_p()), {
            let params_p2xx = params_p2x.clone();
            let lx_p0xx = lx_p0x.clone();
            let ptys_p7x = ptys_p7.clone();
            Rc::new(move |(p0, p1): ((Array<(Text, crate::lower::model::OutTy)>, crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), Nat)| {
                let params_p2xxy = params_p2xx.clone();
                let lx_p0xxy = lx_p0xx.clone();
                let ptys_p7xy = ptys_p7x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let (acc_pc, w_pd, be_pe, me_pf) = p0;
                    let i_pg = p1;
                    {
                        let p_ph = crate::prelude::or(&crate::prelude::index(&params_p2xxy, &i_pg), &crate::lower::patterns::dummy_pat_p());
                        let nkey_pi = crate::lower::functions::plain_binder_f(&lx_p0xxy, &p_ph);
                        let base_pj = if &nkey_pi == &Text::lit("") {
                            Text::from(format!("arg{}", &i_pg))
                        } else {
                            crate::lower::snake_f(&nkey_pi)
                        };
                        let (rs_pm, w2_pn) = crate::lower::node_::fresh_name_f(&w_pd, &base_pj);
                        crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0xxy.clone(), crate::lower::types::peel_f(&crate::prelude::or(&crate::prelude::index(&ptys_p7xy, &i_pg), &crate::check::types::Ty::TyErr))), move |out_ty_of_f_1975: crate::lower::model::OutTy| {
                            let t_pk = out_ty_of_f_1975;
                            let w3_pl = {
                                let mut this: crate::lower::node_::Wx = w2_pn.clone();
                                this.fields_p = crate::prelude::push(&this.fields_p, &(rs_pm.clone(), t_pk.clone(), Text::lit("a parameter")));
                                this.inits_p = crate::prelude::push(&this.inits_p, &(rs_pm.clone(), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(rs_pm.clone())))));
                                this
                            };
                            let (be2_po, me2_pp) = crate::lower::node_::bind_plain_f(&be_pe, &me_pf, &nkey_pi, &rs_pm, &t_pk);
                            prism_rtl::Turn::Finished((crate::prelude::push(&acc_pc, &(rs_pm.clone(), t_pk.clone())), w3_pl.clone(), be2_po.clone(), me2_pp.clone()))
                        })
                    }
                }))
            }) as Rc<dyn Fn(((Array<(Text, crate::lower::model::OutTy)>, crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), Nat)) -> Rc<dyn prism_rtl::Job<(Array<(Text, crate::lower::model::OutTy)>, crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>>>
        }), move |fold_1692: (Array<(Text, crate::lower::model::OutTy)>, crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)| {
            let (ps_pq, wx1_pr, benv_ps, menv_pt) = fold_1692;
            crate::prelude::call_then(start_block_into_f(wx1_pr.clone(), benv_ps.clone(), menv_pt.clone(), body_p3x.clone()), move |block_into_f_2293: crate::lower::node_::Wx| {
                let wx2_p9 = block_into_f_2293;
                let wx3_pa = if is_root_p5x { root_result_f(&wx2_p9) } else { wx2_p9.clone() };
                prism_rtl::Turn::More(Rc::new(crate::lower::node_::finish::FinishNode { wx0_p0: wx3_pa.clone(), qk_p1: qk_p1x.clone(), params_p2: ps_pq.clone(), is_row_p3: false }))
            })
        })
    }
}

/// `Start NodeDefOf, x`: what the function value is when passed to `@Run`.
pub fn start_node_def_of_f(lx_p0: crate::lower::Lx, qk_p1: Text, params_p2: Array<crate::syntax::Pattern_>, body_p3: crate::syntax::Block, sc_p4: crate::check::types::Scheme, is_root_p5: bool) -> Rc<dyn prism_rtl::Job<crate::lower::model::NodeDef>> {
    Rc::new(NodeDefOf { lx_p0, qk_p1, params_p2, body_p3, sc_p4, is_root_p5 })
}

/// ```prism
/// RootResult: fn Wx -> Wx
/// ```
pub fn root_result_f(wx_p0: &crate::lower::node_::Wx) -> crate::lower::node_::Wx {
    match &wx_p0.result_p {
        crate::lower::node_::Wres::WrEv(r_p1) => crate::lower::node_::connect_f(wx_p0, r_p1, &crate::lower::node_::Sk::SkResult),
        crate::lower::node_::Wres::WrDyn(x_p2, rds_p3, t_p4) => {
            let mut this: crate::lower::node_::Wx = wx_p0.clone();
            this.root_dyn_o = Some((x_p2.clone(), rds_p3.clone(), t_p4.clone()));
            this.getters_p = crate::prelude::push(&this.getters_p, &crate::lower::model::MethDef { name_p: Text::lit("result_value"), recv_p: crate::lower::model::Recv::RecvRef, params_p: Array::new(), cx_p: crate::lower::model::CxArg::CxRef, ret_p: crate::lower::model::OutTy::OutPod, body_p: Array::new(), tail_p: crate::lower::model::Ex::XMethod(Rc::new(x_p2.clone()), Text::lit("to_pod"), Array::new()), doc_p: Text::lit("The root\'s dynamic result, pulled after the tick.") });
            this.fields_p = crate::prelude::push(&this.fields_p, &(Text::lit("result_last"), crate::lower::model::OutTy::OutCell(Rc::new(crate::lower::model::OutTy::OutOpt(Rc::new(crate::lower::model::OutTy::OutPod)))), Text::lit("the result the World last heard")));
            this.moves_p = crate::prelude::push(&this.moves_p, &(Text::lit("result_last"), crate::lower::model::Ex::XCall(Text::lit("RefCell::new"), Array::from(vec![crate::lower::model::Ex::XNone]))));
            this.build_p = crate::prelude::push(&this.build_p, &crate::lower::model::Do::DoScope(crate::lower::node_::finish::result_told_f(&crate::lower::model::Ex::XVar(Text::lit("node")))));
            this
        },
        crate::lower::node_::Wres::WrPlain(x_p5, _) => {
            let mut this: crate::lower::node_::Wx = wx_p0.clone();
            this.build_p = crate::prelude::push(&this.build_p, &crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCx), Text::lit("result"), Array::from(vec![crate::lower::model::Ex::XCtor(Text::lit("Outcome::Value"), Array::from(vec![crate::lower::model::Ex::XMethod(Rc::new(x_p5.clone()), Text::lit("to_pod"), Array::new())]))]))));
            this
        },
        crate::lower::node_::Wres::WrParts(_) => {
            let mut this: crate::lower::node_::Wx = wx_p0.clone();
            this.build_p = crate::prelude::push(&this.build_p, &crate::lower::expr::refusal_do_f(&Text::lit("a bundle as the root\'s result: a World hears a plain value, a dynamic or an event")));
            this
        },
        _ => wx_p0.clone(),
    }
}

/// ```prism
/// BlockInto: unbounded fn Wx, Env, Env, Block -> Wx
/// ```
pub fn block_into_f(wx_p0: &crate::lower::node_::Wx, benv_p1: &crate::lower::types::Env, menv_p2: &crate::lower::types::Env, b_p3: &crate::syntax::Block) -> crate::lower::node_::Wx {
    let (wx1_pb, be1_pc, me1_pd) = crate::prelude::run_to_end(crate::prelude::fold_job(b_p3.stmts_p.clone(), (wx_p0.clone(), benv_p1.clone(), menv_p2.clone()), Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::syntax::Stmt)| crate::prelude::entered(crate::prelude::once_job(move || {
        let (w_p7, be_p8, me_p9) = p0;
        let s_pa = p1;
        prism_rtl::Turn::More(Rc::new(PreBind { wx_p0: w_p7.clone(), benv_p1: be_p8.clone(), menv_p2: me_p9.clone(), s_p3: s_pa.clone() }))
    }))) as Rc<dyn Fn(((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>>>));
    let order_p4 = build_order_f(&b_p3.stmts_p);
    let (wx2_pk, be2_pl) = crate::prelude::run_to_end(crate::prelude::fold_job(order_p4.clone(), (wx1_pb.clone(), be1_pc.clone()), {
        let me1_pdx = me1_pd.clone();
        let b_p3x = b_p3.clone();
        Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::types::Env), Array<Nat>)| {
            let me1_pdxy = me1_pdx.clone();
            let b_p3xy = b_p3x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (w_pe, be_pf) = p0;
                let comp_pg = p1;
                crate::prelude::fold_job(comp_pg.clone(), (w_pe.clone(), be_pf.clone()), {
                    let me1_pdxyx = me1_pdxy.clone();
                    let b_p3xyx = b_p3xy.clone();
                    Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::types::Env), Nat)| {
                        let me1_pdxyxy = me1_pdxyx.clone();
                        let b_p3xyxy = b_p3xyx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let (w2_ph, be3_pi) = p0;
                            let i_pj = p1;
                            prism_rtl::Turn::More(Rc::new(PreInit { wx_p0: w2_ph.clone(), benv_p1: be3_pi.clone(), menv_p2: me1_pdxyxy.clone(), s_p3: crate::prelude::or(&crate::prelude::index(&b_p3xyxy.stmts_p, &i_pj), &crate::lower::expr::dummy_stmt_l_p()) }))
                        }))
                    }) as Rc<dyn Fn(((crate::lower::node_::Wx, crate::lower::types::Env), Nat)) -> Rc<dyn prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env)>>>
                }).cycle()
            }))
        }) as Rc<dyn Fn(((crate::lower::node_::Wx, crate::lower::types::Env), Array<Nat>)) -> Rc<dyn prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env)>>>
    }));
    let n_p5 = crate::prelude::len(&b_p3.stmts_p);
    let start_p6 = crate::prelude::len(&wx2_pk.lets_p);
    let (wx3_pu, _, _, ends_pv) = crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(&n_p5), (wx2_pk.clone(), be2_pl.clone(), me1_pd.clone(), Array::new()), {
        let b_p3x = b_p3.clone();
        let n_p5x = n_p5.clone();
        Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env, Array<Nat>), Nat)| {
            let b_p3xy = b_p3x.clone();
            let n_p5xy = n_p5x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (w_pm, be_pn, me_po, acc_pp) = p0;
                let i_pq = p1;
                crate::prelude::call_then(start_widget_stmt_f(w_pm.clone(), be_pn.clone(), me_po.clone(), crate::prelude::or(&crate::prelude::index(&b_p3xy.stmts_p, &i_pq), &crate::lower::expr::dummy_stmt_l_p()), &(&i_pq + &Nat::from(1u32)) == &n_p5xy), move |widget_stmt_f_4499: (crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)| {
                    let (w2_pr, be3_ps, me3_pt) = widget_stmt_f_4499;
                    prism_rtl::Turn::Finished((w2_pr.clone(), be3_ps.clone(), me3_pt.clone(), crate::prelude::push(&acc_pp, &crate::prelude::len(&w2_pr.lets_p))))
                })
            }))
        }) as Rc<dyn Fn(((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env, Array<Nat>), Nat)) -> Rc<dyn prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env, Array<Nat>)>>>
    }));
    build_in_order_f(&wx3_pu, &b_p3.stmts_p, &order_p4, &start_p6, &ends_pv)
}

/// The step machine of `BlockInto`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BlockInto: unbounded fn Wx, Env, Env, Block -> Wx
/// ```
pub struct BlockInto {
    pub wx_p0: crate::lower::node_::Wx,
    pub benv_p1: crate::lower::types::Env,
    pub menv_p2: crate::lower::types::Env,
    pub b_p3: crate::syntax::Block,
}

impl prism_rtl::Job<crate::lower::node_::Wx> for BlockInto {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::node_::Wx> {
        let wx_p0 = &self.wx_p0;
        let benv_p1 = &self.benv_p1;
        let menv_p2 = &self.menv_p2;
        let b_p3 = &self.b_p3;
        let b_p3x = b_p3.clone();
        let benv_p1x = benv_p1.clone();
        let menv_p2x = menv_p2.clone();
        let wx_p0x = wx_p0.clone();
        crate::prelude::call_value(crate::prelude::fold_job(b_p3x.stmts_p.clone(), (wx_p0x.clone(), benv_p1x.clone(), menv_p2x.clone()), Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::syntax::Stmt)| crate::prelude::entered(crate::prelude::once_job(move || {
            let (w_p7, be_p8, me_p9) = p0;
            let s_pa = p1;
            prism_rtl::Turn::More(Rc::new(PreBind { wx_p0: w_p7.clone(), benv_p1: be_p8.clone(), menv_p2: me_p9.clone(), s_p3: s_pa.clone() }))
        }))) as Rc<dyn Fn(((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>>>), move |fold_4040: (crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)| {
            let (wx1_pb, be1_pc, me1_pd) = fold_4040;
            crate::prelude::call_then(start_build_order_f(b_p3x.stmts_p.clone()), move |build_order_f_4131: Array<Array<Nat>>| {
                let order_p4 = build_order_f_4131;
                crate::prelude::call_value(crate::prelude::fold_job(order_p4.clone(), (wx1_pb.clone(), be1_pc.clone()), {
                    let me1_pdx = me1_pd.clone();
                    let b_p3xx = b_p3x.clone();
                    Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::types::Env), Array<Nat>)| {
                        let me1_pdxy = me1_pdx.clone();
                        let b_p3xxy = b_p3xx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let (w_pe, be_pf) = p0;
                            let comp_pg = p1;
                            crate::prelude::fold_job(comp_pg.clone(), (w_pe.clone(), be_pf.clone()), {
                                let me1_pdxyx = me1_pdxy.clone();
                                let b_p3xxyx = b_p3xxy.clone();
                                Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::types::Env), Nat)| {
                                    let me1_pdxyxy = me1_pdxyx.clone();
                                    let b_p3xxyxy = b_p3xxyx.clone();
                                    crate::prelude::entered(crate::prelude::once_job(move || {
                                        let (w2_ph, be3_pi) = p0;
                                        let i_pj = p1;
                                        prism_rtl::Turn::More(Rc::new(PreInit { wx_p0: w2_ph.clone(), benv_p1: be3_pi.clone(), menv_p2: me1_pdxyxy.clone(), s_p3: crate::prelude::or(&crate::prelude::index(&b_p3xxyxy.stmts_p, &i_pj), &crate::lower::expr::dummy_stmt_l_p()) }))
                                    }))
                                }) as Rc<dyn Fn(((crate::lower::node_::Wx, crate::lower::types::Env), Nat)) -> Rc<dyn prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env)>>>
                            }).cycle()
                        }))
                    }) as Rc<dyn Fn(((crate::lower::node_::Wx, crate::lower::types::Env), Array<Nat>)) -> Rc<dyn prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env)>>>
                }), move |fold_4173: (crate::lower::node_::Wx, crate::lower::types::Env)| {
                    let (wx2_pk, be2_pl) = fold_4173;
                    let n_p5 = crate::prelude::len(&b_p3x.stmts_p);
                    let start_p6 = crate::prelude::len(&wx2_pk.lets_p);
                    crate::prelude::call_value(crate::prelude::fold_job(crate::check::errors::range0_f(&n_p5), (wx2_pk.clone(), be2_pl.clone(), me1_pd.clone(), Array::new()), {
                        let b_p3xx = b_p3x.clone();
                        let n_p5x = n_p5.clone();
                        Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env, Array<Nat>), Nat)| {
                            let b_p3xxy = b_p3xx.clone();
                            let n_p5xy = n_p5x.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let (w_pm, be_pn, me_po, acc_pp) = p0;
                                let i_pq = p1;
                                crate::prelude::call_then(start_widget_stmt_f(w_pm.clone(), be_pn.clone(), me_po.clone(), crate::prelude::or(&crate::prelude::index(&b_p3xxy.stmts_p, &i_pq), &crate::lower::expr::dummy_stmt_l_p()), &(&i_pq + &Nat::from(1u32)) == &n_p5xy), move |widget_stmt_f_4499: (crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)| {
                                    let (w2_pr, be3_ps, me3_pt) = widget_stmt_f_4499;
                                    prism_rtl::Turn::Finished((w2_pr.clone(), be3_ps.clone(), me3_pt.clone(), crate::prelude::push(&acc_pp, &crate::prelude::len(&w2_pr.lets_p))))
                                })
                            }))
                        }) as Rc<dyn Fn(((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env, Array<Nat>), Nat)) -> Rc<dyn prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env, Array<Nat>)>>>
                    }), move |fold_4401: (crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env, Array<Nat>)| {
                        let (wx3_pu, _, _, ends_pv) = fold_4401;
                        prism_rtl::Turn::More(Rc::new(BuildInOrder { wx_p0: wx3_pu.clone(), stmts_p1: b_p3x.stmts_p.clone(), order_p2: order_p4.clone(), start_p3: start_p6.clone(), ends_p4: ends_pv.clone() }))
                    })
                })
            })
        })
    }
}

/// `Start BlockInto, x`: what the function value is when passed to `@Run`.
pub fn start_block_into_f(wx_p0: crate::lower::node_::Wx, benv_p1: crate::lower::types::Env, menv_p2: crate::lower::types::Env, b_p3: crate::syntax::Block) -> Rc<dyn prism_rtl::Job<crate::lower::node_::Wx>> {
    Rc::new(BlockInto { wx_p0, benv_p1, menv_p2, b_p3 })
}

/// ```prism
/// PreInit: unbounded fn Wx, Env, Env, Stmt -> ((Wx, Env))
/// ```
pub fn pre_init_f(wx_p0: &crate::lower::node_::Wx, benv_p1: &crate::lower::types::Env, menv_p2: &crate::lower::types::Env, s_p3: &crate::syntax::Stmt) -> (crate::lower::node_::Wx, crate::lower::types::Env) {
    match &s_p3.kind_p {
        crate::syntax::StmtKind::SBind(p_p4, _, Some(_)) => match binding_of_o(menv_p2, p_p4) {
            Some(crate::lower::types::Bn::BnHold(f_p5, t_p6)) => {
                let wx2_p7 = {
                    let mut this: crate::lower::node_::Wx = wx_p0.clone();
                    this.inited_p = crate::check::types::add_text_f(&this.inited_p, &f_p5);
                    this
                };
                (wx2_p7.clone(), crate::lower::types::bind_f(benv_p1, &Text::from(format!("{}#init", &pat_text_f(p_p4))), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(Text::from(format!("{}_init", &f_p5))), crate::lower::types::Holding::Owned, t_p6)))
            },
            _ => (wx_p0.clone(), benv_p1.clone()),
        },
        crate::syntax::StmtKind::SLet(p_p8, _, e_p9) => match binding_of_o(menv_p2, p_p8) {
            Some(crate::lower::types::Bn::BnDyn(_, _, t_pa)) => {
                let rs_pb = crate::lower::snake_f(&pat_text_f(p_p8));
                let (_, reads_pd) = crate::lower::node_::dynamics::dynamic_expr_f(wx_p0, menv_p2, e_p9);
                let wx2_pc = {
                    let mut this: crate::lower::node_::Wx = wx_p0.clone();
                    this.dyn_reads_p = crate::prelude::insert(&this.dyn_reads_p, &rs_pb, &reads_pd);
                    this
                };
                if all_inited_f(&wx2_pc, &reads_pd) && names_inited_f(benv_p1, e_p9) {
                    {
                        let wx3_pe = {
                            let mut this: crate::lower::node_::Wx = wx2_pc.clone();
                            this.inited_p = crate::check::types::add_text_f(&this.inited_p, &rs_pb);
                            this
                        };
                        (wx3_pe.clone(), crate::lower::types::bind_f(benv_p1, &Text::from(format!("{}#init", &pat_text_f(p_p8))), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(Text::from(format!("{}_init", &rs_pb))), crate::lower::types::Holding::Owned, t_pa)))
                    }
                } else {
                    (wx2_pc.clone(), benv_p1.clone())
                }
            },
            _ => (wx_p0.clone(), benv_p1.clone()),
        },
        _ => (wx_p0.clone(), benv_p1.clone()),
    }
}

/// The step machine of `PreInit`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PreInit: unbounded fn Wx, Env, Env, Stmt -> ((Wx, Env))
/// ```
pub struct PreInit {
    pub wx_p0: crate::lower::node_::Wx,
    pub benv_p1: crate::lower::types::Env,
    pub menv_p2: crate::lower::types::Env,
    pub s_p3: crate::syntax::Stmt,
}

impl prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env)> for PreInit {
    fn cycle(&self) -> prism_rtl::Turn<(crate::lower::node_::Wx, crate::lower::types::Env)> {
        let wx_p0 = &self.wx_p0;
        let benv_p1 = &self.benv_p1;
        let menv_p2 = &self.menv_p2;
        let s_p3 = &self.s_p3;
        match &s_p3.kind_p {
            crate::syntax::StmtKind::SBind(p_p4, _, Some(_)) => match binding_of_o(menv_p2, p_p4) {
                Some(crate::lower::types::Bn::BnHold(f_p5, t_p6)) => {
                    let wx2_p7 = {
                        let mut this: crate::lower::node_::Wx = wx_p0.clone();
                        this.inited_p = crate::check::types::add_text_f(&this.inited_p, &f_p5);
                        this
                    };
                    prism_rtl::Turn::Finished((wx2_p7.clone(), crate::lower::types::bind_f(benv_p1, &Text::from(format!("{}#init", &pat_text_f(p_p4))), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(Text::from(format!("{}_init", &f_p5))), crate::lower::types::Holding::Owned, t_p6.clone()))))
                },
                _ => prism_rtl::Turn::Finished((wx_p0.clone(), benv_p1.clone())),
            },
            crate::syntax::StmtKind::SLet(p_p8, _, e_p9) => match binding_of_o(menv_p2, p_p8) {
                Some(crate::lower::types::Bn::BnDyn(_, _, t_pa)) => {
                    let rs_pb = crate::lower::snake_f(&pat_text_f(p_p8));
                    let benv_p1x = benv_p1.clone();
                    let e_p9x = e_p9.clone();
                    let menv_p2x = menv_p2.clone();
                    let p_p8x = p_p8.clone();
                    let wx_p0x = wx_p0.clone();
                    crate::prelude::call_then(crate::lower::node_::dynamics::start_dynamic_expr_f(wx_p0x.clone(), menv_p2x.clone(), e_p9x.clone()), move |dynamic_expr_f_5593: (crate::lower::model::Ex, Array<crate::lower::node_::Read>)| {
                        let (_, reads_pd) = dynamic_expr_f_5593;
                        let wx2_pc = {
                            let mut this: crate::lower::node_::Wx = wx_p0x.clone();
                            this.dyn_reads_p = crate::prelude::insert(&this.dyn_reads_p, &rs_pb, &reads_pd);
                            this
                        };
                        if all_inited_f(&wx2_pc, &reads_pd) && names_inited_f(&benv_p1x, &e_p9x) {
                            {
                                let wx3_pe = {
                                    let mut this: crate::lower::node_::Wx = wx2_pc.clone();
                                    this.inited_p = crate::check::types::add_text_f(&this.inited_p, &rs_pb);
                                    this
                                };
                                prism_rtl::Turn::Finished((wx3_pe.clone(), crate::lower::types::bind_f(&benv_p1x, &Text::from(format!("{}#init", &pat_text_f(&p_p8x))), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(Text::from(format!("{}_init", &rs_pb))), crate::lower::types::Holding::Owned, t_pa.clone()))))
                            }
                        } else {
                            prism_rtl::Turn::Finished((wx2_pc.clone(), benv_p1x.clone()))
                        }
                    })
                },
                _ => prism_rtl::Turn::Finished((wx_p0.clone(), benv_p1.clone())),
            },
            _ => prism_rtl::Turn::Finished((wx_p0.clone(), benv_p1.clone())),
        }
    }
}

/// `Start PreInit, x`: what the function value is when passed to `@Run`.
pub fn start_pre_init_f(wx_p0: crate::lower::node_::Wx, benv_p1: crate::lower::types::Env, menv_p2: crate::lower::types::Env, s_p3: crate::syntax::Stmt) -> Rc<dyn prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env)>> {
    Rc::new(PreInit { wx_p0, benv_p1, menv_p2, s_p3 })
}

/// ```prism
/// BuildInOrder: unbounded fn Wx, [Stmt], [ [Nat] ], Nat, [Nat] -> Wx
/// ```
pub fn build_in_order_f(wx_p0: &crate::lower::node_::Wx, stmts_p1: &Array<crate::syntax::Stmt>, order_p2: &Array<Array<Nat>>, start_p3: &Nat, ends_p4: &Array<Nat>) -> crate::lower::node_::Wx {
    let n_p5 = crate::prelude::len(stmts_p1);
    let last_p6 = crate::prelude::or(&crate::prelude::index(ends_p4, &crate::syntax::lexer::chars::dec_f(&n_p5)), start_p3);
    let runs_p7 = crate::prelude::each(&crate::check::errors::range0_f(&n_p5), &(|i_pb: &Nat| {
        let from_pc = if i_pb == &Nat::from(0u32) {
            start_p3.clone()
        } else {
            crate::prelude::or(&crate::prelude::index(ends_p4, &crate::syntax::lexer::chars::dec_f(i_pb)), start_p3)
        };
        crate::prelude::take(&crate::prelude::drop(&wx_p0.lets_p, &from_pc), &crate::prelude::or(&(&crate::prelude::or(&crate::prelude::index(ends_p4, i_pb), &from_pc)).checked_sub(&from_pc), &Nat::from(0u32)))
    }));
    let lets_p8 = crate::prelude::fold(order_p2, &crate::prelude::take(&wx_p0.lets_p, start_p3), &(|acc_pd: &Array<crate::lower::model::Do>, comp_pe: &Array<Nat>| crate::prelude::fold(comp_pe, acc_pd, &(|acc2_pf: &Array<crate::lower::model::Do>, i_pg: &Nat| crate::prelude::append(acc2_pf, &crate::prelude::or(&crate::prelude::index(&runs_p7, i_pg), &Array::new()))))));
    let cyclic_p9 = crate::prelude::filter(order_p2, &(|comp_ph: &Array<Nat>| (&crate::prelude::len(comp_ph) > &Nat::from(1u32)) && crate::prelude::fold(comp_ph, &false, &(|seen_pi: &bool, i_pj: &Nat| *seen_pi || (&crate::prelude::len(&crate::prelude::or(&crate::prelude::index(&runs_p7, i_pj), &Array::new())) > &Nat::from(0u32))))));
    let wx2_pa = {
        let mut this: crate::lower::node_::Wx = wx_p0.clone();
        this.lets_p = crate::prelude::append(&lets_p8, &crate::prelude::drop(&wx_p0.lets_p, &last_p6));
        this
    };
    crate::prelude::run_to_end(crate::prelude::fold_job(cyclic_p9.clone(), wx2_pa.clone(), {
        let stmts_p1x = stmts_p1.clone();
        Rc::new(move |(p0, p1): (crate::lower::node_::Wx, Array<Nat>)| {
            let stmts_p1xy = stmts_p1x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let w_pk = p0;
                let comp_pl = p1;
                prism_rtl::Turn::Finished({
                    let mut this: crate::lower::node_::Wx = w_pk.clone();
                    this.build_p = crate::prelude::push(&this.build_p, &crate::lower::expr::refusal_do_f(&Text::from(format!("lines that read each other at the build ({}): a cycle among values", &crate::syntax::lexer::chars::join_f(&crate::prelude::run_to_end(crate::prelude::fold_job(comp_pl.clone(), Array::new(), {
                        let stmts_p1xyx = stmts_p1xy.clone();
                        Rc::new(move |(p0, p1): (Array<Text>, Nat)| {
                            let stmts_p1xyxy = stmts_p1xyx.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let acc_pm = p0;
                                let i_pn = p1;
                                crate::prelude::call_then(crate::check::blocks::start_group_defs_f(crate::prelude::or(&crate::prelude::index(&stmts_p1xyxy, &i_pn), &crate::lower::expr::dummy_stmt_l_p())), move |group_defs_f_7245: Array<Text>| prism_rtl::Turn::Finished(crate::prelude::append(&acc_pm, &group_defs_f_7245)))
                            }))
                        }) as Rc<dyn Fn((Array<Text>, Nat)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
                    })), &Text::lit(", "))))));
                    this
                })
            }))
        }) as Rc<dyn Fn((crate::lower::node_::Wx, Array<Nat>)) -> Rc<dyn prism_rtl::Job<crate::lower::node_::Wx>>>
    }))
}

/// The step machine of `BuildInOrder`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BuildInOrder: unbounded fn Wx, [Stmt], [ [Nat] ], Nat, [Nat] -> Wx
/// ```
pub struct BuildInOrder {
    pub wx_p0: crate::lower::node_::Wx,
    pub stmts_p1: Array<crate::syntax::Stmt>,
    pub order_p2: Array<Array<Nat>>,
    pub start_p3: Nat,
    pub ends_p4: Array<Nat>,
}

impl prism_rtl::Job<crate::lower::node_::Wx> for BuildInOrder {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::node_::Wx> {
        let wx_p0 = &self.wx_p0;
        let stmts_p1 = &self.stmts_p1;
        let order_p2 = &self.order_p2;
        let start_p3 = &self.start_p3;
        let ends_p4 = &self.ends_p4;
        let n_p5 = crate::prelude::len(stmts_p1);
        let last_p6 = crate::prelude::or(&crate::prelude::index(ends_p4, &crate::syntax::lexer::chars::dec_f(&n_p5)), start_p3);
        let runs_p7 = crate::prelude::each(&crate::check::errors::range0_f(&n_p5), &(|i_pb: &Nat| {
            let from_pc = if i_pb == &Nat::from(0u32) {
                start_p3.clone()
            } else {
                crate::prelude::or(&crate::prelude::index(ends_p4, &crate::syntax::lexer::chars::dec_f(i_pb)), start_p3)
            };
            crate::prelude::take(&crate::prelude::drop(&wx_p0.lets_p, &from_pc), &crate::prelude::or(&(&crate::prelude::or(&crate::prelude::index(ends_p4, i_pb), &from_pc)).checked_sub(&from_pc), &Nat::from(0u32)))
        }));
        let lets_p8 = crate::prelude::fold(order_p2, &crate::prelude::take(&wx_p0.lets_p, start_p3), &(|acc_pd: &Array<crate::lower::model::Do>, comp_pe: &Array<Nat>| crate::prelude::fold(comp_pe, acc_pd, &(|acc2_pf: &Array<crate::lower::model::Do>, i_pg: &Nat| crate::prelude::append(acc2_pf, &crate::prelude::or(&crate::prelude::index(&runs_p7, i_pg), &Array::new()))))));
        let cyclic_p9 = crate::prelude::filter(order_p2, &(|comp_ph: &Array<Nat>| (&crate::prelude::len(comp_ph) > &Nat::from(1u32)) && crate::prelude::fold(comp_ph, &false, &(|seen_pi: &bool, i_pj: &Nat| *seen_pi || (&crate::prelude::len(&crate::prelude::or(&crate::prelude::index(&runs_p7, i_pj), &Array::new())) > &Nat::from(0u32))))));
        let wx2_pa = {
            let mut this: crate::lower::node_::Wx = wx_p0.clone();
            this.lets_p = crate::prelude::append(&lets_p8, &crate::prelude::drop(&wx_p0.lets_p, &last_p6));
            this
        };
        crate::prelude::fold_job(cyclic_p9.clone(), wx2_pa.clone(), {
            let stmts_p1x = stmts_p1.clone();
            Rc::new(move |(p0, p1): (crate::lower::node_::Wx, Array<Nat>)| {
                let stmts_p1xy = stmts_p1x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let w_pk = p0;
                    let comp_pl = p1;
                    prism_rtl::Turn::Finished({
                        let mut this: crate::lower::node_::Wx = w_pk.clone();
                        this.build_p = crate::prelude::push(&this.build_p, &crate::lower::expr::refusal_do_f(&Text::from(format!("lines that read each other at the build ({}): a cycle among values", &crate::syntax::lexer::chars::join_f(&crate::prelude::run_to_end(crate::prelude::fold_job(comp_pl.clone(), Array::new(), {
                            let stmts_p1xyx = stmts_p1xy.clone();
                            Rc::new(move |(p0, p1): (Array<Text>, Nat)| {
                                let stmts_p1xyxy = stmts_p1xyx.clone();
                                crate::prelude::entered(crate::prelude::once_job(move || {
                                    let acc_pm = p0;
                                    let i_pn = p1;
                                    crate::prelude::call_then(crate::check::blocks::start_group_defs_f(crate::prelude::or(&crate::prelude::index(&stmts_p1xyxy, &i_pn), &crate::lower::expr::dummy_stmt_l_p())), move |group_defs_f_7245: Array<Text>| prism_rtl::Turn::Finished(crate::prelude::append(&acc_pm, &group_defs_f_7245)))
                                }))
                            }) as Rc<dyn Fn((Array<Text>, Nat)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
                        })), &Text::lit(", "))))));
                        this
                    })
                }))
            }) as Rc<dyn Fn((crate::lower::node_::Wx, Array<Nat>)) -> Rc<dyn prism_rtl::Job<crate::lower::node_::Wx>>>
        }).cycle()
    }
}

/// `Start BuildInOrder, x`: what the function value is when passed to `@Run`.
pub fn start_build_in_order_f(wx_p0: crate::lower::node_::Wx, stmts_p1: Array<crate::syntax::Stmt>, order_p2: Array<Array<Nat>>, start_p3: Nat, ends_p4: Array<Nat>) -> Rc<dyn prism_rtl::Job<crate::lower::node_::Wx>> {
    Rc::new(BuildInOrder { wx_p0, stmts_p1, order_p2, start_p3, ends_p4 })
}

/// ```prism
/// BuildOrder: unbounded fn [Stmt] -> [ [Nat] ]
/// ```
pub fn build_order_f(stmts_p0: &Array<crate::syntax::Stmt>) -> Array<Array<Nat>> {
    let n_p1 = crate::prelude::len(stmts_p0);
    let defs_p2 = crate::prelude::run_to_end(crate::prelude::each_job(stmts_p0.clone(), Rc::new(move |p0: crate::syntax::Stmt| crate::prelude::entered(crate::prelude::once_job(move || {
        let s_p7 = p0;
        crate::prelude::call_then(crate::check::blocks::start_group_defs_f(s_p7.clone()), move |group_defs_f_7730: Array<Text>| prism_rtl::Turn::Finished(crate::prelude::filter(&group_defs_f_7730, &(|d_p8: &Text| !crate::syntax::lexer::chars::has_prefix_f(d_p8, &Text::lit("!"))))))
    }))) as Rc<dyn Fn(crate::syntax::Stmt) -> Rc<dyn prism_rtl::Job<Array<Text>>>>));
    let reads_p3 = crate::prelude::run_to_end(crate::prelude::each_job(stmts_p0.clone(), Rc::new(move |p0: crate::syntax::Stmt| crate::prelude::entered(crate::prelude::once_job(move || {
        let s_p9 = p0;
        prism_rtl::Turn::More(Rc::new(ReadsAtBuild { s_p0: s_p9.clone() }))
    }))) as Rc<dyn Fn(crate::syntax::Stmt) -> Rc<dyn prism_rtl::Job<Array<Text>>>>));
    let deps_p4 = crate::prelude::each(&crate::check::errors::range0_f(&n_p1), &(|i_pa: &Nat| crate::prelude::filter(&crate::check::errors::range0_f(&n_p1), &(|j_pb: &Nat| (j_pb != i_pa) && crate::prelude::fold(&crate::prelude::or(&crate::prelude::index(&defs_p2, j_pb), &Array::new()), &false, &(|seen_pc: &bool, d_pd: &Text| *seen_pc || crate::check::types::has_text_f(&crate::prelude::or(&crate::prelude::index(&reads_p3, i_pa), &Array::new()), d_pd)))))));
    let reach_p5 = crate::prelude::run_to_end(crate::prelude::each_job(crate::check::errors::range0_f(&n_p1), {
        let deps_p4x = deps_p4.clone();
        Rc::new(move |p0: Nat| {
            let deps_p4xy = deps_p4x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let i_pe = p0;
                prism_rtl::Turn::More(Rc::new(crate::check::blocks::ReachIdx { deps_p0: deps_p4xy.clone(), frontier_p1: crate::prelude::or(&crate::prelude::index(&deps_p4xy, &i_pe), &Array::new()), seen_p2: Array::new() }))
            }))
        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Array<Nat>>>>
    }));
    let comps_p6 = crate::prelude::each(&crate::check::errors::range0_f(&n_p1), &(|i_pf: &Nat| crate::prelude::filter(&crate::check::errors::range0_f(&n_p1), &(|j_pg: &Nat| (j_pg == i_pf) || (crate::check::types::has_nat_f(&crate::prelude::or(&crate::prelude::index(&reach_p5, i_pf), &Array::new()), j_pg) && crate::check::types::has_nat_f(&crate::prelude::or(&crate::prelude::index(&reach_p5, j_pg), &Array::new()), i_pf))))));
    crate::check::blocks::emit_groups_f(&comps_p6, &deps_p4, &Array::new(), &Array::new())
}

/// The step machine of `BuildOrder`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BuildOrder: unbounded fn [Stmt] -> [ [Nat] ]
/// ```
pub struct BuildOrder {
    pub stmts_p0: Array<crate::syntax::Stmt>,
}

impl prism_rtl::Job<Array<Array<Nat>>> for BuildOrder {
    fn cycle(&self) -> prism_rtl::Turn<Array<Array<Nat>>> {
        let stmts_p0 = &self.stmts_p0;
        let n_p1 = crate::prelude::len(stmts_p0);
        let stmts_p0x = stmts_p0.clone();
        crate::prelude::call_value(crate::prelude::each_job(stmts_p0x.clone(), Rc::new(move |p0: crate::syntax::Stmt| crate::prelude::entered(crate::prelude::once_job(move || {
            let s_p7 = p0;
            crate::prelude::call_then(crate::check::blocks::start_group_defs_f(s_p7.clone()), move |group_defs_f_7730: Array<Text>| prism_rtl::Turn::Finished(crate::prelude::filter(&group_defs_f_7730, &(|d_p8: &Text| !crate::syntax::lexer::chars::has_prefix_f(d_p8, &Text::lit("!"))))))
        }))) as Rc<dyn Fn(crate::syntax::Stmt) -> Rc<dyn prism_rtl::Job<Array<Text>>>>), move |each_7705: Array<Array<Text>>| {
            let defs_p2 = each_7705;
            crate::prelude::call_value(crate::prelude::each_job(stmts_p0x.clone(), Rc::new(move |p0: crate::syntax::Stmt| crate::prelude::entered(crate::prelude::once_job(move || {
                let s_p9 = p0;
                prism_rtl::Turn::More(Rc::new(ReadsAtBuild { s_p0: s_p9.clone() }))
            }))) as Rc<dyn Fn(crate::syntax::Stmt) -> Rc<dyn prism_rtl::Job<Array<Text>>>>), move |each_7801: Array<Array<Text>>| {
                let reads_p3 = each_7801;
                let deps_p4 = crate::prelude::each(&crate::check::errors::range0_f(&n_p1), &(|i_pa: &Nat| crate::prelude::filter(&crate::check::errors::range0_f(&n_p1), &(|j_pb: &Nat| (j_pb != i_pa) && crate::prelude::fold(&crate::prelude::or(&crate::prelude::index(&defs_p2, j_pb), &Array::new()), &false, &(|seen_pc: &bool, d_pd: &Text| *seen_pc || crate::check::types::has_text_f(&crate::prelude::or(&crate::prelude::index(&reads_p3, i_pa), &Array::new()), d_pd)))))));
                crate::prelude::call_value(crate::prelude::each_job(crate::check::errors::range0_f(&n_p1), {
                    let deps_p4x = deps_p4.clone();
                    Rc::new(move |p0: Nat| {
                        let deps_p4xy = deps_p4x.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let i_pe = p0;
                            prism_rtl::Turn::More(Rc::new(crate::check::blocks::ReachIdx { deps_p0: deps_p4xy.clone(), frontier_p1: crate::prelude::or(&crate::prelude::index(&deps_p4xy, &i_pe), &Array::new()), seen_p2: Array::new() }))
                        }))
                    }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Array<Nat>>>>
                }), move |each_8003: Array<Array<Nat>>| {
                    let reach_p5 = each_8003;
                    let comps_p6 = crate::prelude::each(&crate::check::errors::range0_f(&n_p1), &(|i_pf: &Nat| crate::prelude::filter(&crate::check::errors::range0_f(&n_p1), &(|j_pg: &Nat| (j_pg == i_pf) || (crate::check::types::has_nat_f(&crate::prelude::or(&crate::prelude::index(&reach_p5, i_pf), &Array::new()), j_pg) && crate::check::types::has_nat_f(&crate::prelude::or(&crate::prelude::index(&reach_p5, j_pg), &Array::new()), i_pf))))));
                    prism_rtl::Turn::More(Rc::new(crate::check::blocks::EmitGroups { comps_p0: comps_p6.clone(), deps_p1: deps_p4.clone(), done_p2: Array::new(), acc_p3: Array::new() }))
                })
            })
        })
    }
}

/// `Start BuildOrder, x`: what the function value is when passed to `@Run`.
pub fn start_build_order_f(stmts_p0: Array<crate::syntax::Stmt>) -> Rc<dyn prism_rtl::Job<Array<Array<Nat>>>> {
    Rc::new(BuildOrder { stmts_p0 })
}

/// ```prism
/// ReadsAtBuild: unbounded fn Stmt -> [Text]
/// ```
pub fn reads_at_build_f(s_p0: &crate::syntax::Stmt) -> Array<Text> {
    match &s_p0.kind_p {
        crate::syntax::StmtKind::SBind(_, init_p1, Some(_)) => crate::lower::expr::free_reads_f(&crate::check::typed::print::exprs_in_f(init_p1), &Array::new()),
        crate::syntax::StmtKind::SFn(f_p2) => crate::lower::expr::free_reads_f(&crate::check::typed::print::stmt_exprs_f(s_p0), &Array::from(vec![(crate::prelude::run_to_end(crate::prelude::fold_job(f_p2.params_p.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Pattern_)| crate::prelude::entered(crate::prelude::once_job(move || {
            let acc_p3 = p0;
            let q_p4 = p1;
            crate::prelude::call_then(crate::check::env::names::start_pattern_names_f(q_p4.clone()), move |pattern_names_f_8794: Array<Text>| prism_rtl::Turn::Finished(crate::prelude::append(&acc_p3, &pattern_names_f_8794)))
        }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Pattern_)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>)), f_p2.span_p.clone())])),
        _ => crate::lower::expr::free_reads_f(&crate::check::typed::print::stmt_exprs_f(s_p0), &Array::new()),
    }
}

/// The step machine of `ReadsAtBuild`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ReadsAtBuild: unbounded fn Stmt -> [Text]
/// ```
pub struct ReadsAtBuild {
    pub s_p0: crate::syntax::Stmt,
}

impl prism_rtl::Job<Array<Text>> for ReadsAtBuild {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let s_p0 = &self.s_p0;
        match &s_p0.kind_p {
            crate::syntax::StmtKind::SBind(_, init_p1, Some(_)) => {
                let init_p1x = init_p1.clone();
                crate::prelude::call_then(crate::check::typed::print::start_exprs_in_f(init_p1x.clone()), move |exprs_in_f_8689: Array<crate::syntax::Expr>| prism_rtl::Turn::More(Rc::new(crate::lower::expr::FreeReads { es_p0: exprs_in_f_8689, outer_p1: Array::new() })))
            },
            crate::syntax::StmtKind::SFn(f_p2) => {
                let f_p2x = f_p2.clone();
                let s_p0x = s_p0.clone();
                crate::prelude::call_then(crate::check::typed::print::start_stmt_exprs_f(s_p0x.clone()), move |stmt_exprs_f_8731: Array<crate::syntax::Expr>| crate::prelude::call_value(crate::prelude::fold_job(f_p2x.params_p.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Pattern_)| crate::prelude::entered(crate::prelude::once_job(move || {
                    let acc_p3 = p0;
                    let q_p4 = p1;
                    crate::prelude::call_then(crate::check::env::names::start_pattern_names_f(q_p4.clone()), move |pattern_names_f_8794: Array<Text>| prism_rtl::Turn::Finished(crate::prelude::append(&acc_p3, &pattern_names_f_8794)))
                }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Pattern_)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>), move |fold_8750: Array<Text>| prism_rtl::Turn::More(Rc::new(crate::lower::expr::FreeReads { es_p0: stmt_exprs_f_8731, outer_p1: Array::from(vec![(fold_8750, f_p2x.span_p.clone())]) }))))
            },
            _ => {
                let s_p0x = s_p0.clone();
                crate::prelude::call_then(crate::check::typed::print::start_stmt_exprs_f(s_p0x.clone()), move |stmt_exprs_f_8849: Array<crate::syntax::Expr>| prism_rtl::Turn::More(Rc::new(crate::lower::expr::FreeReads { es_p0: stmt_exprs_f_8849, outer_p1: Array::new() })))
            },
        }
    }
}

/// `Start ReadsAtBuild, x`: what the function value is when passed to `@Run`.
pub fn start_reads_at_build_f(s_p0: crate::syntax::Stmt) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(ReadsAtBuild { s_p0 })
}

/// ```prism
/// PreBind: unbounded fn Wx, Env, Env, Stmt -> ((Wx, Env, Env))
/// ```
pub fn pre_bind_f(wx_p0: &crate::lower::node_::Wx, benv_p1: &crate::lower::types::Env, menv_p2: &crate::lower::types::Env, s_p3: &crate::syntax::Stmt) -> (crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env) {
    match &s_p3.kind_p {
        crate::syntax::StmtKind::SBind(p_p4, init_p5, step_o6) => {
            let how_p7 = if (step_o6 == &None) && gives_result_f(&wx_p0.lx_p, menv_p2, init_p5) {
                HowBound::AsResult
            } else {
                how_bound_f(step_o6)
            };
            match &*p_p4.kind_p {
                crate::syntax::PatternKind::PName(n_p8) => pre_bind_name_f(wx_p0, benv_p1, menv_p2, n_p8, &how_p7),
                crate::syntax::PatternKind::PTuple(ps_p9) => crate::prelude::run_to_end(crate::prelude::fold_job(ps_p9.clone(), (wx_p0.clone(), benv_p1.clone(), menv_p2.clone()), {
                    let how_p7x = how_p7.clone();
                    Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::syntax::Pattern_)| {
                        let how_p7xy = how_p7x.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let (w_pa, be_pb, me_pc) = p0;
                            let q_pd = p1;
                            match &*q_pd.kind_p {
                                crate::syntax::PatternKind::PName(n_pe) => prism_rtl::Turn::More(Rc::new(PreBindName { wx_p0: w_pa.clone(), benv_p1: be_pb.clone(), menv_p2: me_pc.clone(), n_p3: n_pe.clone(), how_p4: how_p7xy.clone() })),
                                _ => prism_rtl::Turn::Finished((w_pa.clone(), be_pb.clone(), me_pc.clone())),
                            }
                        }))
                    }) as Rc<dyn Fn(((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::syntax::Pattern_)) -> Rc<dyn prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>>>
                })),
                _ => (wx_p0.clone(), benv_p1.clone(), menv_p2.clone()),
            }
        },
        crate::syntax::StmtKind::SLet(p_pf, _, _) => match &*p_pf.kind_p {
            crate::syntax::PatternKind::PName(n_pg) => pre_bind_name_f(wx_p0, benv_p1, menv_p2, n_pg, &HowBound::AsLet),
            _ => (wx_p0.clone(), benv_p1.clone(), menv_p2.clone()),
        },
        crate::syntax::StmtKind::SFn(c_ph) => {
            let fname_pi = crate::check::env::def_name_text_f(&c_ph.name_p);
            (wx_p0.clone(), crate::lower::types::bind_f(benv_p1, &fname_pi, &crate::lower::types::Bn::BnLocalFn(c_ph.clone())), crate::lower::types::bind_f(menv_p2, &fname_pi, &crate::lower::types::Bn::BnLocalFn(c_ph.clone())))
        },
        _ => (wx_p0.clone(), benv_p1.clone(), menv_p2.clone()),
    }
}

/// The step machine of `PreBind`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PreBind: unbounded fn Wx, Env, Env, Stmt -> ((Wx, Env, Env))
/// ```
pub struct PreBind {
    pub wx_p0: crate::lower::node_::Wx,
    pub benv_p1: crate::lower::types::Env,
    pub menv_p2: crate::lower::types::Env,
    pub s_p3: crate::syntax::Stmt,
}

impl prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)> for PreBind {
    fn cycle(&self) -> prism_rtl::Turn<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)> {
        let wx_p0 = &self.wx_p0;
        let benv_p1 = &self.benv_p1;
        let menv_p2 = &self.menv_p2;
        let s_p3 = &self.s_p3;
        match &s_p3.kind_p {
            crate::syntax::StmtKind::SBind(p_p4, init_p5, step_o6) => {
                let how_p7 = if (step_o6 == &None) && gives_result_f(&wx_p0.lx_p, menv_p2, init_p5) {
                    HowBound::AsResult
                } else {
                    how_bound_f(step_o6)
                };
                match &*p_p4.kind_p {
                    crate::syntax::PatternKind::PName(n_p8) => prism_rtl::Turn::More(Rc::new(PreBindName { wx_p0: wx_p0.clone(), benv_p1: benv_p1.clone(), menv_p2: menv_p2.clone(), n_p3: n_p8.clone(), how_p4: how_p7.clone() })),
                    crate::syntax::PatternKind::PTuple(ps_p9) => crate::prelude::fold_job(ps_p9.clone(), (wx_p0.clone(), benv_p1.clone(), menv_p2.clone()), {
                        let how_p7x = how_p7.clone();
                        Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::syntax::Pattern_)| {
                            let how_p7xy = how_p7x.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let (w_pa, be_pb, me_pc) = p0;
                                let q_pd = p1;
                                match &*q_pd.kind_p {
                                    crate::syntax::PatternKind::PName(n_pe) => prism_rtl::Turn::More(Rc::new(PreBindName { wx_p0: w_pa.clone(), benv_p1: be_pb.clone(), menv_p2: me_pc.clone(), n_p3: n_pe.clone(), how_p4: how_p7xy.clone() })),
                                    _ => prism_rtl::Turn::Finished((w_pa.clone(), be_pb.clone(), me_pc.clone())),
                                }
                            }))
                        }) as Rc<dyn Fn(((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::syntax::Pattern_)) -> Rc<dyn prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>>>
                    }).cycle(),
                    _ => prism_rtl::Turn::Finished((wx_p0.clone(), benv_p1.clone(), menv_p2.clone())),
                }
            },
            crate::syntax::StmtKind::SLet(p_pf, _, _) => match &*p_pf.kind_p {
                crate::syntax::PatternKind::PName(n_pg) => prism_rtl::Turn::More(Rc::new(PreBindName { wx_p0: wx_p0.clone(), benv_p1: benv_p1.clone(), menv_p2: menv_p2.clone(), n_p3: n_pg.clone(), how_p4: HowBound::AsLet })),
                _ => prism_rtl::Turn::Finished((wx_p0.clone(), benv_p1.clone(), menv_p2.clone())),
            },
            crate::syntax::StmtKind::SFn(c_ph) => {
                let fname_pi = crate::check::env::def_name_text_f(&c_ph.name_p);
                prism_rtl::Turn::Finished((wx_p0.clone(), crate::lower::types::bind_f(benv_p1, &fname_pi, &crate::lower::types::Bn::BnLocalFn(c_ph.clone())), crate::lower::types::bind_f(menv_p2, &fname_pi, &crate::lower::types::Bn::BnLocalFn(c_ph.clone()))))
            },
            _ => prism_rtl::Turn::Finished((wx_p0.clone(), benv_p1.clone(), menv_p2.clone())),
        }
    }
}

/// `Start PreBind, x`: what the function value is when passed to `@Run`.
pub fn start_pre_bind_f(wx_p0: crate::lower::node_::Wx, benv_p1: crate::lower::types::Env, menv_p2: crate::lower::types::Env, s_p3: crate::syntax::Stmt) -> Rc<dyn prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>> {
    Rc::new(PreBind { wx_p0, benv_p1, menv_p2, s_p3 })
}

/// ```prism
/// GivesResult: unbounded fn Lx, Env, Expr -> Bool
/// ```
pub fn gives_result_f(lx_p0: &crate::lower::Lx, menv_p1: &crate::lower::types::Env, e_p2: &crate::syntax::Expr) -> bool {
    match &*e_p2.kind_p {
        crate::syntax::ExprKind::EGroup(x_p3) => gives_result_f(lx_p0, menv_p1, &**x_p3),
        crate::syntax::ExprKind::EWidgetBlock(_) => true,
        _ => {
            let callee_p4 = match &*e_p2.kind_p {
                crate::syntax::ExprKind::ECall(c_p5, _, _, _) => (**c_p5).clone(),
                _ => e_p2.clone(),
            };
            match &*callee_p4.kind_p {
                crate::syntax::ExprKind::EName(n_p6) => match crate::prelude::get(&menv_p1.names_p, &crate::check::env::sname_key_f(n_p6)) {
                    Some(crate::lower::types::Bn::BnWidget(_, _, _, _)) => true,
                    _ => {
                        let (q_o7, _) = crate::check::env::names::resolve_value_f(&lx_p0.g_p, &lx_p0.home_p, n_p6);
                        match &q_o7 {
                            Some(q_p8) => is_getter_builtin_f(q_p8) || ((!is_prelude_name_f(q_p8) && (&crate::prelude::get(&lx_p0.g_p.vals_p, q_p8) != &None)) && is_widget_ty_f(&crate::lower::types::peel_f(&crate::lower::type_at_f(lx_p0, &e_p2.span_p)))),
                            None => false,
                        }
                    },
                },
                _ => false,
            }
        },
    }
}

/// The step machine of `GivesResult`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// GivesResult: unbounded fn Lx, Env, Expr -> Bool
/// ```
pub struct GivesResult {
    pub lx_p0: crate::lower::Lx,
    pub menv_p1: crate::lower::types::Env,
    pub e_p2: crate::syntax::Expr,
}

impl prism_rtl::Job<bool> for GivesResult {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let lx_p0 = &self.lx_p0;
        let menv_p1 = &self.menv_p1;
        let e_p2 = &self.e_p2;
        match &*e_p2.kind_p {
            crate::syntax::ExprKind::EGroup(x_p3) => prism_rtl::Turn::More(Rc::new(GivesResult { lx_p0: lx_p0.clone(), menv_p1: menv_p1.clone(), e_p2: (**x_p3).clone() })),
            crate::syntax::ExprKind::EWidgetBlock(_) => prism_rtl::Turn::Finished(true),
            _ => {
                let callee_p4 = match &*e_p2.kind_p {
                    crate::syntax::ExprKind::ECall(c_p5, _, _, _) => (**c_p5).clone(),
                    _ => e_p2.clone(),
                };
                match &*callee_p4.kind_p {
                    crate::syntax::ExprKind::EName(n_p6) => match crate::prelude::get(&menv_p1.names_p, &crate::check::env::sname_key_f(n_p6)) {
                        Some(crate::lower::types::Bn::BnWidget(_, _, _, _)) => prism_rtl::Turn::Finished(true),
                        _ => {
                            let (q_o7, _) = crate::check::env::names::resolve_value_f(&lx_p0.g_p, &lx_p0.home_p, n_p6);
                            match &q_o7 {
                                Some(q_p8) => prism_rtl::Turn::Finished(is_getter_builtin_f(q_p8) || ((!is_prelude_name_f(q_p8) && (&crate::prelude::get(&lx_p0.g_p.vals_p, q_p8) != &None)) && is_widget_ty_f(&crate::lower::types::peel_f(&crate::lower::type_at_f(lx_p0, &e_p2.span_p))))),
                                None => prism_rtl::Turn::Finished(false),
                            }
                        },
                    },
                    _ => prism_rtl::Turn::Finished(false),
                }
            },
        }
    }
}

/// `Start GivesResult, x`: what the function value is when passed to `@Run`.
pub fn start_gives_result_f(lx_p0: crate::lower::Lx, menv_p1: crate::lower::types::Env, e_p2: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(GivesResult { lx_p0, menv_p1, e_p2 })
}

/// ```prism
/// IsPreludeName: fn Text -> Bool
/// ```
pub fn is_prelude_name_f(q_p0: &Text) -> bool {
    &crate::prelude::find(&{ thread_local!(static R: Regex = Regex::lit("^Prelude\\.", "")); R.with(Regex::clone) }, q_p0) != &None
}

/// ```prism
/// IsGetterBuiltin: fn Text -> Bool
/// ```
pub fn is_getter_builtin_f(q_p0: &Text) -> bool {
    ((q_p0 == &Text::lit("Prelude.@Distinct")) || (q_p0 == &Text::lit("Prelude.@PerKey"))) || (q_p0 == &Text::lit("Prelude.@Flatten"))
}

/// ```prism
/// IsWidgetTy: fn Ty -> Bool
/// ```
pub fn is_widget_ty_f(t_p0: &crate::check::types::Ty) -> bool {
    match t_p0 {
        crate::check::types::Ty::TyAt(_, _) => true,
        _ => false,
    }
}

/// ```prism
/// HowBound: fn ?Expr -> HowBound
/// ```
pub fn how_bound_f(opt0: &Option<crate::syntax::Expr>) -> HowBound {
    match opt0 {
        Some(_) => HowBound::AsHold,
        None => HowBound::AsBind,
    }
}

/// ```prism
/// PreBindName: unbounded fn Wx, Env, Env, SName, HowBound -> ((Wx, Env, Env))
/// ```
pub fn pre_bind_name_f(wx_p0: &crate::lower::node_::Wx, benv_p1: &crate::lower::types::Env, menv_p2: &crate::lower::types::Env, n_p3: &crate::syntax::SName, how_p4: &HowBound) -> (crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env) {
    let lx_p5 = crate::lower::expr::widget_let_lx_f(&wx_p0.lx_p, &n_p3.span_p);
    let nkey_p6 = crate::check::env::sname_key_f(n_p3);
    let full_p7 = crate::lower::binder_ty_f(&lx_p5, &n_p3.span_p);
    let layer_p8 = crate::lower::types::layer_of_f(&full_p7);
    let t_p9 = crate::lower::types::out_ty_of_f(&lx_p5, &crate::lower::types::peel_f(&full_p7));
    let (rs_pa, wx1_pb) = crate::lower::node_::fresh_name_f(wx_p0, &crate::lower::snake_f(&nkey_p6));
    if ((how_p4 == &HowBound::AsBind) || (how_p4 == &HowBound::AsResult)) && crate::lower::types::is_bundle_f(&full_p7) {
        (wx_p0.clone(), benv_p1.clone(), menv_p2.clone())
    } else {
        if (&layer_p8 == &crate::lower::types::Layer::LyEv) || is_switched_f(&full_p7) {
            {
                let et_pc = crate::lower::types::out_ty_of_f(&lx_p5, &crate::lower::types::peel_f(&crate::lower::types::peel_f(&full_p7)));
                let (id_pj, wx2_pk) = crate::lower::node_::add_gn_f(&wx1_pb, &rs_pa, &et_pc, &crate::lower::node_::GnKind::GnNamed, &Nat::from(0u32));
                let b_pd = crate::lower::types::Bn::BnEv(crate::lower::node_::ev_ref_of_f(&wx2_pk, &id_pj), t_p9.clone());
                let pf_pe = Text::from(format!("{}_v_port", &rs_pa));
                let pt_pf = crate::lower::model::OutTy::OutRc(Rc::new(crate::lower::model::OutTy::OutPort(Rc::new(et_pc.clone()))));
                let wx3_pg = {
                    let mut this: crate::lower::node_::Wx = crate::lower::node_::connect_f(&wx2_pk, &crate::lower::node_::ev_ref_of_f(&wx2_pk, &id_pj), &crate::lower::node_::Sk::SkPort(Text::from(format!("{}_v", &rs_pa))));
                    this.lets_p = crate::prelude::push(&this.lets_p, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaBind(pf_pe.clone())), pt_pf.clone()), crate::lower::model::Ex::XCall(Text::lit("Rc::new"), Array::from(vec![crate::lower::model::Ex::XCall(Text::lit("Port::new"), Array::new())]))));
                    this.fields_p = crate::prelude::push(&this.fields_p, &(pf_pe.clone(), pt_pf.clone(), Text::from(format!("`{}` as a value: the port it fires", &nkey_p6))));
                    this.moves_p = crate::prelude::push(&this.moves_p, &(pf_pe.clone(), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(pf_pe.clone())))));
                    this
                };
                let be_ph = crate::lower::types::bind_f(&crate::lower::types::bind_f(benv_p1, &nkey_p6, &b_pd), &Text::from(format!("{}#port", &nkey_p6)), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(pf_pe.clone()), crate::lower::types::Holding::Owned, pt_pf.clone()));
                let me_pi = crate::lower::types::bind_f(&crate::lower::types::bind_f(menv_p2, &nkey_p6, &b_pd), &Text::from(format!("{}#port", &nkey_p6)), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), pf_pe.clone()), crate::lower::types::Holding::Owned, pt_pf.clone()));
                (wx3_pg.clone(), be_ph.clone(), me_pi.clone())
            }
        } else {
            match (layer_p8.clone(), how_p4.clone()) {
                (crate::lower::types::Layer::LyDyn, HowBound::AsLet) => {
                    let b_pl = crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XSelf), rs_pa.clone(), Array::from(vec![crate::lower::model::Ex::XCx])), Array::from(vec![crate::lower::node_::Read::OwnRead(rs_pa.clone())]), t_p9.clone());
                    (wx1_pb.clone(), crate::lower::types::bind_f(benv_p1, &nkey_p6, &b_pl), crate::lower::types::bind_f(menv_p2, &nkey_p6, &b_pl))
                },
                (crate::lower::types::Layer::LyDyn, HowBound::AsResult) => {
                    let b_pm = crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XSelf), rs_pa.clone(), Array::from(vec![crate::lower::model::Ex::XCx])), Array::from(vec![crate::lower::node_::Read::OwnRead(rs_pa.clone())]), t_p9.clone());
                    (wx1_pb.clone(), crate::lower::types::bind_f(benv_p1, &nkey_p6, &b_pm), crate::lower::types::bind_f(menv_p2, &nkey_p6, &b_pm))
                },
                (crate::lower::types::Layer::LyDyn, _) => {
                    let b_pn = crate::lower::types::Bn::BnHold(rs_pa.clone(), t_p9.clone());
                    (wx1_pb.clone(), crate::lower::types::bind_f(benv_p1, &nkey_p6, &b_pn), crate::lower::types::bind_f(menv_p2, &nkey_p6, &b_pn))
                },
                _ => match many_instances_o(&wx_p0.lx_p, &n_p3.span_p) {
                    Some(insts_po) => crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(&insts_po)), (wx1_pb.clone(), benv_p1.clone(), menv_p2.clone()), {
                        let insts_pox = insts_po.clone();
                        let wx_p0x = wx_p0.clone();
                        let n_p3x = n_p3.clone();
                        let rs_pax = rs_pa.clone();
                        let nkey_p6x = nkey_p6.clone();
                        Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), Nat)| {
                            let insts_poxy = insts_pox.clone();
                            let wx_p0xy = wx_p0x.clone();
                            let n_p3xy = n_p3x.clone();
                            let rs_paxy = rs_pax.clone();
                            let nkey_p6xy = nkey_p6x.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let (w_pp, be_pq, me_pr) = p0;
                                let k_ps = p1;
                                {
                                    let inst_pt = crate::prelude::or(&crate::prelude::index(&insts_poxy, &k_ps), &(Array::new(), Array::new()));
                                    let lxk_pu = crate::lower::expr::at_instance_f(&wx_p0xy.lx_p, &inst_pt);
                                    crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lxk_pu.clone(), crate::lower::types::peel_f(&crate::lower::binder_ty_f(&lxk_pu, &n_p3xy.span_p))), move |out_ty_of_f_14418: crate::lower::model::OutTy| {
                                        let tk_pv = out_ty_of_f_14418;
                                        let (rk_p12, w2_p13) = if &k_ps == &Nat::from(0u32) {
                                            (rs_paxy.clone(), w_pp.clone())
                                        } else {
                                            crate::lower::node_::fresh_name_f(&w_pp, &Text::from(format!("{}_{}", &rs_paxy, &k_ps)))
                                        };
                                        let bkey_p10 = if &k_ps == &Nat::from(0u32) {
                                            nkey_p6xy.clone()
                                        } else {
                                            Text::from(format!("{}#inst{}", &nkey_p6xy, &k_ps))
                                        };
                                        let (be2_p14, me2_p15) = crate::lower::node_::bind_plain_f(&be_pq, &me_pr, &bkey_p10, &rk_p12, &tk_pv);
                                        let ukey_p11 = Text::from(format!("{}#{}", &nkey_p6xy, &crate::prelude::show_text(&inst_pt)));
                                        prism_rtl::Turn::Finished((w2_p13.clone(), with_use_f(&be2_p14, &ukey_p11, &bkey_p10), with_use_f(&me2_p15, &ukey_p11, &bkey_p10)))
                                    })
                                }
                            }))
                        }) as Rc<dyn Fn(((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), Nat)) -> Rc<dyn prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>>>
                    })),
                    None => {
                        let (be_p16, me_p17) = crate::lower::node_::bind_plain_f(benv_p1, menv_p2, &nkey_p6, &rs_pa, &t_p9);
                        (wx1_pb.clone(), be_p16.clone(), me_p17.clone())
                    },
                },
            }
        }
    }
}

/// The step machine of `PreBindName`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PreBindName: unbounded fn Wx, Env, Env, SName, HowBound -> ((Wx, Env, Env))
/// ```
pub struct PreBindName {
    pub wx_p0: crate::lower::node_::Wx,
    pub benv_p1: crate::lower::types::Env,
    pub menv_p2: crate::lower::types::Env,
    pub n_p3: crate::syntax::SName,
    pub how_p4: HowBound,
}

impl prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)> for PreBindName {
    fn cycle(&self) -> prism_rtl::Turn<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)> {
        let wx_p0 = &self.wx_p0;
        let benv_p1 = &self.benv_p1;
        let menv_p2 = &self.menv_p2;
        let n_p3 = &self.n_p3;
        let how_p4 = &self.how_p4;
        let benv_p1x = benv_p1.clone();
        let how_p4x = how_p4.clone();
        let menv_p2x = menv_p2.clone();
        let n_p3x = n_p3.clone();
        let wx_p0x = wx_p0.clone();
        crate::prelude::call_then(crate::lower::expr::start_widget_let_lx_f(wx_p0x.lx_p.clone(), n_p3x.span_p.clone()), move |widget_let_lx_f_12007: crate::lower::Lx| {
            let lx_p5 = widget_let_lx_f_12007;
            let nkey_p6 = crate::check::env::sname_key_f(&n_p3x);
            let full_p7 = crate::lower::binder_ty_f(&lx_p5, &n_p3x.span_p);
            let layer_p8 = crate::lower::types::layer_of_f(&full_p7);
            crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p5.clone(), crate::lower::types::peel_f(&full_p7)), move |out_ty_of_f_12135: crate::lower::model::OutTy| {
                let t_p9 = out_ty_of_f_12135;
                let (rs_pa, wx1_pb) = crate::lower::node_::fresh_name_f(&wx_p0x, &crate::lower::snake_f(&nkey_p6));
                if ((&how_p4x == &HowBound::AsBind) || (&how_p4x == &HowBound::AsResult)) && crate::lower::types::is_bundle_f(&full_p7) {
                    prism_rtl::Turn::Finished((wx_p0x.clone(), benv_p1x.clone(), menv_p2x.clone()))
                } else {
                    if (&layer_p8 == &crate::lower::types::Layer::LyEv) || is_switched_f(&full_p7) {
                        crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p5.clone(), crate::lower::types::peel_f(&crate::lower::types::peel_f(&full_p7))), move |out_ty_of_f_12493: crate::lower::model::OutTy| {
                            let et_pc = out_ty_of_f_12493;
                            let (id_pj, wx2_pk) = crate::lower::node_::add_gn_f(&wx1_pb, &rs_pa, &et_pc, &crate::lower::node_::GnKind::GnNamed, &Nat::from(0u32));
                            let b_pd = crate::lower::types::Bn::BnEv(crate::lower::node_::ev_ref_of_f(&wx2_pk, &id_pj), t_p9.clone());
                            let pf_pe = Text::from(format!("{}_v_port", &rs_pa));
                            let pt_pf = crate::lower::model::OutTy::OutRc(Rc::new(crate::lower::model::OutTy::OutPort(Rc::new(et_pc.clone()))));
                            let wx3_pg = {
                                let mut this: crate::lower::node_::Wx = crate::lower::node_::connect_f(&wx2_pk, &crate::lower::node_::ev_ref_of_f(&wx2_pk, &id_pj), &crate::lower::node_::Sk::SkPort(Text::from(format!("{}_v", &rs_pa))));
                                this.lets_p = crate::prelude::push(&this.lets_p, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaBind(pf_pe.clone())), pt_pf.clone()), crate::lower::model::Ex::XCall(Text::lit("Rc::new"), Array::from(vec![crate::lower::model::Ex::XCall(Text::lit("Port::new"), Array::new())]))));
                                this.fields_p = crate::prelude::push(&this.fields_p, &(pf_pe.clone(), pt_pf.clone(), Text::from(format!("`{}` as a value: the port it fires", &nkey_p6))));
                                this.moves_p = crate::prelude::push(&this.moves_p, &(pf_pe.clone(), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(pf_pe.clone())))));
                                this
                            };
                            let be_ph = crate::lower::types::bind_f(&crate::lower::types::bind_f(&benv_p1x, &nkey_p6, &b_pd), &Text::from(format!("{}#port", &nkey_p6)), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(pf_pe.clone()), crate::lower::types::Holding::Owned, pt_pf.clone()));
                            let me_pi = crate::lower::types::bind_f(&crate::lower::types::bind_f(&menv_p2x, &nkey_p6, &b_pd), &Text::from(format!("{}#port", &nkey_p6)), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), pf_pe.clone()), crate::lower::types::Holding::Owned, pt_pf.clone()));
                            prism_rtl::Turn::Finished((wx3_pg.clone(), be_ph.clone(), me_pi.clone()))
                        })
                    } else {
                        match (layer_p8.clone(), how_p4x.clone()) {
                            (crate::lower::types::Layer::LyDyn, HowBound::AsLet) => {
                                let b_pl = crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XSelf), rs_pa.clone(), Array::from(vec![crate::lower::model::Ex::XCx])), Array::from(vec![crate::lower::node_::Read::OwnRead(rs_pa.clone())]), t_p9.clone());
                                prism_rtl::Turn::Finished((wx1_pb.clone(), crate::lower::types::bind_f(&benv_p1x, &nkey_p6, &b_pl), crate::lower::types::bind_f(&menv_p2x, &nkey_p6, &b_pl)))
                            },
                            (crate::lower::types::Layer::LyDyn, HowBound::AsResult) => {
                                let b_pm = crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XSelf), rs_pa.clone(), Array::from(vec![crate::lower::model::Ex::XCx])), Array::from(vec![crate::lower::node_::Read::OwnRead(rs_pa.clone())]), t_p9.clone());
                                prism_rtl::Turn::Finished((wx1_pb.clone(), crate::lower::types::bind_f(&benv_p1x, &nkey_p6, &b_pm), crate::lower::types::bind_f(&menv_p2x, &nkey_p6, &b_pm)))
                            },
                            (crate::lower::types::Layer::LyDyn, _) => {
                                let b_pn = crate::lower::types::Bn::BnHold(rs_pa.clone(), t_p9.clone());
                                prism_rtl::Turn::Finished((wx1_pb.clone(), crate::lower::types::bind_f(&benv_p1x, &nkey_p6, &b_pn), crate::lower::types::bind_f(&menv_p2x, &nkey_p6, &b_pn)))
                            },
                            _ => crate::prelude::call_then(start_many_instances_o(wx_p0x.lx_p.clone(), n_p3x.span_p.clone()), move |many_instances_o_13950: Option<Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)>>| match many_instances_o_13950 {
                                Some(insts_po) => crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(&insts_po)), (wx1_pb.clone(), benv_p1x.clone(), menv_p2x.clone()), {
                                    let insts_pox = insts_po.clone();
                                    let wx_p0xx = wx_p0x.clone();
                                    let n_p3xx = n_p3x.clone();
                                    let rs_pax = rs_pa.clone();
                                    let nkey_p6x = nkey_p6.clone();
                                    Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), Nat)| {
                                        let insts_poxy = insts_pox.clone();
                                        let wx_p0xxy = wx_p0xx.clone();
                                        let n_p3xxy = n_p3xx.clone();
                                        let rs_paxy = rs_pax.clone();
                                        let nkey_p6xy = nkey_p6x.clone();
                                        crate::prelude::entered(crate::prelude::once_job(move || {
                                            let (w_pp, be_pq, me_pr) = p0;
                                            let k_ps = p1;
                                            {
                                                let inst_pt = crate::prelude::or(&crate::prelude::index(&insts_poxy, &k_ps), &(Array::new(), Array::new()));
                                                let lxk_pu = crate::lower::expr::at_instance_f(&wx_p0xxy.lx_p, &inst_pt);
                                                crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lxk_pu.clone(), crate::lower::types::peel_f(&crate::lower::binder_ty_f(&lxk_pu, &n_p3xxy.span_p))), move |out_ty_of_f_14418: crate::lower::model::OutTy| {
                                                    let tk_pv = out_ty_of_f_14418;
                                                    let (rk_p12, w2_p13) = if &k_ps == &Nat::from(0u32) {
                                                        (rs_paxy.clone(), w_pp.clone())
                                                    } else {
                                                        crate::lower::node_::fresh_name_f(&w_pp, &Text::from(format!("{}_{}", &rs_paxy, &k_ps)))
                                                    };
                                                    let bkey_p10 = if &k_ps == &Nat::from(0u32) {
                                                        nkey_p6xy.clone()
                                                    } else {
                                                        Text::from(format!("{}#inst{}", &nkey_p6xy, &k_ps))
                                                    };
                                                    let (be2_p14, me2_p15) = crate::lower::node_::bind_plain_f(&be_pq, &me_pr, &bkey_p10, &rk_p12, &tk_pv);
                                                    let ukey_p11 = Text::from(format!("{}#{}", &nkey_p6xy, &crate::prelude::show_text(&inst_pt)));
                                                    prism_rtl::Turn::Finished((w2_p13.clone(), with_use_f(&be2_p14, &ukey_p11, &bkey_p10), with_use_f(&me2_p15, &ukey_p11, &bkey_p10)))
                                                })
                                            }
                                        }))
                                    }) as Rc<dyn Fn(((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), Nat)) -> Rc<dyn prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>>>
                                }).cycle(),
                                None => {
                                    let (be_p16, me_p17) = crate::lower::node_::bind_plain_f(&benv_p1x, &menv_p2x, &nkey_p6, &rs_pa, &t_p9);
                                    prism_rtl::Turn::Finished((wx1_pb.clone(), be_p16.clone(), me_p17.clone()))
                                },
                            }),
                        }
                    }
                }
            })
        })
    }
}

/// `Start PreBindName, x`: what the function value is when passed to `@Run`.
pub fn start_pre_bind_name_f(wx_p0: crate::lower::node_::Wx, benv_p1: crate::lower::types::Env, menv_p2: crate::lower::types::Env, n_p3: crate::syntax::SName, how_p4: HowBound) -> Rc<dyn prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>> {
    Rc::new(PreBindName { wx_p0, benv_p1, menv_p2, n_p3, how_p4 })
}

/// ```prism
/// WithUse: fn Env, Text, Text -> Env
/// ```
pub fn with_use_f(env_p0: &crate::lower::types::Env, ukey_p1: &Text, bkey_p2: &Text) -> crate::lower::types::Env {
    let mut this: crate::lower::types::Env = env_p0.clone();
    this.uses_p = crate::prelude::insert(&this.uses_p, ukey_p1, bkey_p2);
    this
}

/// ```prism
/// ?ManyInstances: unbounded fn Lx, Range -> ?[(([((Text, Ty))], [((Text, Col))]))]
/// ```
pub fn many_instances_o(lx_p0: &crate::lower::Lx, span_p1: &crate::syntax::Range) -> Option<Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)>> {
    match crate::prelude::get(&lx_p0.gens_p, &crate::lower::place_key_f(lx_p0, span_p1)) {
        Some(gn_p2) => {
            let insts_p3 = crate::lower::expr::instantiations_f(lx_p0, &gn_p2);
            if &crate::prelude::len(&insts_p3) > &Nat::from(1u32) {
                Some(insts_p3.clone())
            } else {
                None
            }
        },
        None => None,
    }
}

/// The step machine of `ManyInstances`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?ManyInstances: unbounded fn Lx, Range -> ?[(([((Text, Ty))], [((Text, Col))]))]
/// ```
pub struct ManyInstances {
    pub lx_p0: crate::lower::Lx,
    pub span_p1: crate::syntax::Range,
}

impl prism_rtl::Job<Option<Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)>>> for ManyInstances {
    fn cycle(&self) -> prism_rtl::Turn<Option<Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)>>> {
        let lx_p0 = &self.lx_p0;
        let span_p1 = &self.span_p1;
        match crate::prelude::get(&lx_p0.gens_p, &crate::lower::place_key_f(lx_p0, span_p1)) {
            Some(gn_p2) => {
                let lx_p0x = lx_p0.clone();
                crate::prelude::call_then(crate::lower::expr::start_instantiations_f(lx_p0x.clone(), gn_p2.clone()), move |instantiations_f_15295: Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)>| {
                    let insts_p3 = instantiations_f_15295;
                    if &crate::prelude::len(&insts_p3) > &Nat::from(1u32) {
                        prism_rtl::Turn::Finished(Some(insts_p3.clone()))
                    } else {
                        prism_rtl::Turn::Finished(None)
                    }
                })
            },
            None => prism_rtl::Turn::Finished(None),
        }
    }
}

/// `Start ManyInstances, x`: what the function value is when passed to `@Run`.
pub fn start_many_instances_o(lx_p0: crate::lower::Lx, span_p1: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<Option<Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)>>>> {
    Rc::new(ManyInstances { lx_p0, span_p1 })
}

/// ```prism
/// IsSwitched: fn Ty -> Bool
/// ```
pub fn is_switched_f(t_p0: &crate::check::types::Ty) -> bool {
    'm15612: {
        if let crate::check::types::Ty::TySig(m15612_0_0, m15612_0_1) = t_p0 && (m15612_0_0 == &Text::lit("$")) && let crate::check::types::Ty::TySig(m15612_0_1_r_0, _) = &**m15612_0_1 && (m15612_0_1_r_0 == &Text::lit("!")) {
            break 'm15612 true;
        }
        false
    }
}

/// ```prism
/// ?BindingOf: fn Env, Pattern -> ?Bn
/// ```
pub fn binding_of_o(env_p0: &crate::lower::types::Env, p_p1: &crate::syntax::Pattern_) -> Option<crate::lower::types::Bn> {
    match &*p_p1.kind_p {
        crate::syntax::PatternKind::PName(n_p2) => crate::prelude::get(&env_p0.names_p, &crate::check::env::sname_key_f(n_p2)),
        crate::syntax::PatternKind::PTuple(ps_p3) => Some(crate::lower::types::Bn::BnParts(crate::prelude::each(ps_p3, &(|q_p4: &crate::syntax::Pattern_| binding_of_name_o(env_p0, q_p4))))),
        _ => None,
    }
}

/// ```prism
/// ?BindingOfName: fn Env, Pattern -> ?Bn
/// ```
pub fn binding_of_name_o(env_p0: &crate::lower::types::Env, p_p1: &crate::syntax::Pattern_) -> Option<crate::lower::types::Bn> {
    match &*p_p1.kind_p {
        crate::syntax::PatternKind::PName(n_p2) => crate::prelude::get(&env_p0.names_p, &crate::check::env::sname_key_f(n_p2)),
        _ => None,
    }
}

/// ```prism
/// WidgetStmt: unbounded fn Wx, Env, Env, Stmt, Bool -> ((Wx, Env, Env))
/// ```
pub fn widget_stmt_f(wx_p0: &crate::lower::node_::Wx, benv_p1: &crate::lower::types::Env, menv_p2: &crate::lower::types::Env, s_p3: &crate::syntax::Stmt, last_p4: &bool) -> (crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env) {
    let lx_p5 = wx_p0.lx_p.clone();
    match &s_p3.kind_p {
        crate::syntax::StmtKind::SBind(p_p6, e_p7, None) => {
            let (wx2_p9, res_pa) = build_line_f(wx_p0, benv_p1, menv_p2, e_p7, &binding_of_o(menv_p2, p_p6));
            let wx3_p8 = bind_res_f(&wx2_p9, menv_p2, p_p6, &res_pa);
            match (res_pa.clone(), (*p_p6.kind_p).clone()) {
                (crate::lower::node_::Wres::WrDyn(ex_pb, rds_pc, t_pd), crate::syntax::PatternKind::PName(n_pe)) => {
                    let b_pf = crate::lower::types::Bn::BnDyn(ex_pb.clone(), rds_pc.clone(), t_pd.clone());
                    result_getter_f(&wx3_p8, menv_p2, &n_pe, &ex_pb, &rds_pc, &t_pd, &crate::lower::types::bind_f(benv_p1, &crate::check::env::sname_key_f(&n_pe), &b_pf), &crate::lower::types::bind_f(menv_p2, &crate::check::env::sname_key_f(&n_pe), &b_pf))
                },
                (crate::lower::node_::Wres::WrHosted(inner_pg, doc_ph), crate::syntax::PatternKind::PTuple(ps_pi)) => bind_hosted_f(&wx3_p8, benv_p1, menv_p2, &*inner_pg, &doc_ph, &ps_pi),
                (crate::lower::node_::Wres::WrParts(parts_pj), crate::syntax::PatternKind::PTuple(ps_pk)) => bind_parts_f(&wx2_p9, benv_p1, menv_p2, &parts_pj, &ps_pk),
                (crate::lower::node_::Wres::WrParts(parts_pl), crate::syntax::PatternKind::PName(n_pm)) => {
                    let b_pn = bundle_bn_f(&res_pa);
                    (wx3_p8.clone(), crate::lower::types::bind_f(benv_p1, &crate::check::env::sname_key_f(&n_pm), &b_pn), crate::lower::types::bind_f(menv_p2, &crate::check::env::sname_key_f(&n_pm), &b_pn))
                },
                (crate::lower::node_::Wres::WrPlain(ex_po, t_pp), _) => (bind_plain_result_f(&wx3_p8, menv_p2, p_p6, &ex_po, &t_pp), benv_p1.clone(), menv_p2.clone()),
                _ => (wx3_p8.clone(), benv_p1.clone(), menv_p2.clone()),
            }
        },
        crate::syntax::StmtKind::SBind(p_pq, init_pr, Some(step_ps)) => {
            let (wx2_pt, be2_pu) = hold_line_f(wx_p0, benv_p1, menv_p2, p_pq, init_pr, step_ps);
            (wx2_pt.clone(), be2_pu.clone(), menv_p2.clone())
        },
        crate::syntax::StmtKind::SIgnore(e_pv) => {
            let (wx2_p10, _) = build_line_f(wx_p0, benv_p1, menv_p2, e_pv, &None);
            (wx2_p10.clone(), benv_p1.clone(), menv_p2.clone())
        },
        crate::syntax::StmtKind::SLet(p_p11, _, e_p12) => {
            let (wx2_p13, be2_p14) = let_line_f(wx_p0, benv_p1, menv_p2, p_p11, e_p12);
            (wx2_p13.clone(), be2_p14.clone(), menv_p2.clone())
        },
        crate::syntax::StmtKind::SExpr(e_p15) => match &*e_p15.kind_p {
            crate::syntax::ExprKind::EFreeSigil(m17518_0_0, x_p16) if (m17518_0_0 == &Text::lit("@")) => {
                let (res_p18, wx2_p19) = result_of_f(wx_p0, benv_p1, menv_p2, &**x_p16);
                let wx3_p17 = {
                    let mut this: crate::lower::node_::Wx = wx2_p19.clone();
                    this.result_p = res_p18.clone();
                    this
                };
                (wx3_p17.clone(), benv_p1.clone(), menv_p2.clone())
            },
            _ => {
                let (wx2_p1b, res_p1c) = build_line_f(wx_p0, benv_p1, menv_p2, e_p15, &None);
                let wx3_p1a = if *last_p4 { set_result_f(&wx2_p1b, &res_p1c) } else { wx2_p1b.clone() };
                (wx3_p1a.clone(), benv_p1.clone(), menv_p2.clone())
            },
            _ => unreachable!("no arm matched"),
        },
        crate::syntax::StmtKind::SEmit(_) => (wx_p0.clone(), benv_p1.clone(), menv_p2.clone()),
        crate::syntax::StmtKind::SSignature(_) => (wx_p0.clone(), benv_p1.clone(), menv_p2.clone()),
        crate::syntax::StmtKind::SFn(c_p1d) => (wx_p0.clone(), benv_p1.clone(), menv_p2.clone()),
        _ => {
            let wx2_p1e = {
                let mut this: crate::lower::node_::Wx = wx_p0.clone();
                this.build_p = crate::prelude::push(&this.build_p, &crate::lower::expr::refusal_do_f(&Text::lit("a statement this back end does not lower yet")));
                this
            };
            (wx2_p1e.clone(), benv_p1.clone(), menv_p2.clone())
        },
    }
}

/// The step machine of `WidgetStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// WidgetStmt: unbounded fn Wx, Env, Env, Stmt, Bool -> ((Wx, Env, Env))
/// ```
pub struct WidgetStmt {
    pub wx_p0: crate::lower::node_::Wx,
    pub benv_p1: crate::lower::types::Env,
    pub menv_p2: crate::lower::types::Env,
    pub s_p3: crate::syntax::Stmt,
    pub last_p4: bool,
}

impl prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)> for WidgetStmt {
    fn cycle(&self) -> prism_rtl::Turn<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)> {
        let wx_p0 = &self.wx_p0;
        let benv_p1 = &self.benv_p1;
        let menv_p2 = &self.menv_p2;
        let s_p3 = &self.s_p3;
        let last_p4 = &self.last_p4;
        let lx_p5 = wx_p0.lx_p.clone();
        match &s_p3.kind_p {
            crate::syntax::StmtKind::SBind(p_p6, e_p7, None) => {
                let benv_p1x = benv_p1.clone();
                let e_p7x = e_p7.clone();
                let menv_p2x = menv_p2.clone();
                let p_p6x = p_p6.clone();
                let wx_p0x = wx_p0.clone();
                crate::prelude::call_then(start_build_line_f(wx_p0x.clone(), benv_p1x.clone(), menv_p2x.clone(), e_p7x.clone(), binding_of_o(&menv_p2x, &p_p6x)), move |build_line_f_16283: (crate::lower::node_::Wx, crate::lower::node_::Wres)| {
                    let (wx2_p9, res_pa) = build_line_f_16283;
                    let wx3_p8 = bind_res_f(&wx2_p9, &menv_p2x, &p_p6x, &res_pa);
                    match (res_pa.clone(), (*p_p6x.kind_p).clone()) {
                        (crate::lower::node_::Wres::WrDyn(ex_pb, rds_pc, t_pd), crate::syntax::PatternKind::PName(n_pe)) => {
                            let b_pf = crate::lower::types::Bn::BnDyn(ex_pb.clone(), rds_pc.clone(), t_pd.clone());
                            prism_rtl::Turn::Finished(result_getter_f(&wx3_p8, &menv_p2x, &n_pe, &ex_pb, &rds_pc, &t_pd, &crate::lower::types::bind_f(&benv_p1x, &crate::check::env::sname_key_f(&n_pe), &b_pf), &crate::lower::types::bind_f(&menv_p2x, &crate::check::env::sname_key_f(&n_pe), &b_pf)))
                        },
                        (crate::lower::node_::Wres::WrHosted(inner_pg, doc_ph), crate::syntax::PatternKind::PTuple(ps_pi)) => prism_rtl::Turn::Finished(bind_hosted_f(&wx3_p8, &benv_p1x, &menv_p2x, &*inner_pg, &doc_ph, &ps_pi)),
                        (crate::lower::node_::Wres::WrParts(parts_pj), crate::syntax::PatternKind::PTuple(ps_pk)) => prism_rtl::Turn::More(Rc::new(BindParts { wx_p0: wx2_p9.clone(), benv_p1: benv_p1x.clone(), menv_p2: menv_p2x.clone(), parts_p3: parts_pj.clone(), ps_p4: ps_pk.clone() })),
                        (crate::lower::node_::Wres::WrParts(parts_pl), crate::syntax::PatternKind::PName(n_pm)) => {
                            let b_pn = bundle_bn_f(&res_pa);
                            prism_rtl::Turn::Finished((wx3_p8.clone(), crate::lower::types::bind_f(&benv_p1x, &crate::check::env::sname_key_f(&n_pm), &b_pn), crate::lower::types::bind_f(&menv_p2x, &crate::check::env::sname_key_f(&n_pm), &b_pn)))
                        },
                        (crate::lower::node_::Wres::WrPlain(ex_po, t_pp), _) => crate::prelude::call_then(start_bind_plain_result_f(wx3_p8.clone(), menv_p2x.clone(), p_p6x.clone(), ex_po.clone(), t_pp.clone()), move |bind_plain_result_f_17033: crate::lower::node_::Wx| prism_rtl::Turn::Finished((bind_plain_result_f_17033, benv_p1x.clone(), menv_p2x.clone()))),
                        _ => prism_rtl::Turn::Finished((wx3_p8.clone(), benv_p1x.clone(), menv_p2x.clone())),
                    }
                })
            },
            crate::syntax::StmtKind::SBind(p_pq, init_pr, Some(step_ps)) => {
                let benv_p1x = benv_p1.clone();
                let init_prx = init_pr.clone();
                let menv_p2x = menv_p2.clone();
                let p_pqx = p_pq.clone();
                let step_psx = step_ps.clone();
                let wx_p0x = wx_p0.clone();
                crate::prelude::call_then(start_hold_line_f(wx_p0x.clone(), benv_p1x.clone(), menv_p2x.clone(), p_pqx.clone(), init_prx.clone(), step_psx.clone()), move |hold_line_f_17195: (crate::lower::node_::Wx, crate::lower::types::Env)| {
                    let (wx2_pt, be2_pu) = hold_line_f_17195;
                    prism_rtl::Turn::Finished((wx2_pt.clone(), be2_pu.clone(), menv_p2x.clone()))
                })
            },
            crate::syntax::StmtKind::SIgnore(e_pv) => {
                let benv_p1x = benv_p1.clone();
                let e_pvx = e_pv.clone();
                let menv_p2x = menv_p2.clone();
                let wx_p0x = wx_p0.clone();
                crate::prelude::call_then(start_build_line_f(wx_p0x.clone(), benv_p1x.clone(), menv_p2x.clone(), e_pvx.clone(), None), move |build_line_f_17318: (crate::lower::node_::Wx, crate::lower::node_::Wres)| {
                    let (wx2_p10, _) = build_line_f_17318;
                    prism_rtl::Turn::Finished((wx2_p10.clone(), benv_p1x.clone(), menv_p2x.clone()))
                })
            },
            crate::syntax::StmtKind::SLet(p_p11, _, e_p12) => {
                let benv_p1x = benv_p1.clone();
                let e_p12x = e_p12.clone();
                let menv_p2x = menv_p2.clone();
                let p_p11x = p_p11.clone();
                let wx_p0x = wx_p0.clone();
                crate::prelude::call_then(start_let_line_f(wx_p0x.clone(), benv_p1x.clone(), menv_p2x.clone(), p_p11x.clone(), e_p12x.clone()), move |let_line_f_17441: (crate::lower::node_::Wx, crate::lower::types::Env)| {
                    let (wx2_p13, be2_p14) = let_line_f_17441;
                    prism_rtl::Turn::Finished((wx2_p13.clone(), be2_p14.clone(), menv_p2x.clone()))
                })
            },
            crate::syntax::StmtKind::SExpr(e_p15) => match &*e_p15.kind_p {
                crate::syntax::ExprKind::EFreeSigil(m17518_0_0, x_p16) if (m17518_0_0 == &Text::lit("@")) => {
                    let benv_p1x = benv_p1.clone();
                    let menv_p2x = menv_p2.clone();
                    let wx_p0x = wx_p0.clone();
                    let x_p16x = (**x_p16).clone();
                    crate::prelude::call_then(start_result_of_f(wx_p0x.clone(), benv_p1x.clone(), menv_p2x.clone(), x_p16x.clone()), move |result_of_f_17598: (crate::lower::node_::Wres, crate::lower::node_::Wx)| {
                        let (res_p18, wx2_p19) = result_of_f_17598;
                        let wx3_p17 = {
                            let mut this: crate::lower::node_::Wx = wx2_p19.clone();
                            this.result_p = res_p18.clone();
                            this
                        };
                        prism_rtl::Turn::Finished((wx3_p17.clone(), benv_p1x.clone(), menv_p2x.clone()))
                    })
                },
                _ => {
                    let benv_p1x = benv_p1.clone();
                    let e_p15x = e_p15.clone();
                    let last_p4x = *last_p4;
                    let menv_p2x = menv_p2.clone();
                    let wx_p0x = wx_p0.clone();
                    crate::prelude::call_then(start_build_line_f(wx_p0x.clone(), benv_p1x.clone(), menv_p2x.clone(), e_p15x.clone(), None), move |build_line_f_17794: (crate::lower::node_::Wx, crate::lower::node_::Wres)| {
                        let (wx2_p1b, res_p1c) = build_line_f_17794;
                        let wx3_p1a = if last_p4x { set_result_f(&wx2_p1b, &res_p1c) } else { wx2_p1b.clone() };
                        prism_rtl::Turn::Finished((wx3_p1a.clone(), benv_p1x.clone(), menv_p2x.clone()))
                    })
                },
                _ => unreachable!("no arm matched"),
            },
            crate::syntax::StmtKind::SEmit(_) => prism_rtl::Turn::Finished((wx_p0.clone(), benv_p1.clone(), menv_p2.clone())),
            crate::syntax::StmtKind::SSignature(_) => prism_rtl::Turn::Finished((wx_p0.clone(), benv_p1.clone(), menv_p2.clone())),
            crate::syntax::StmtKind::SFn(c_p1d) => prism_rtl::Turn::Finished((wx_p0.clone(), benv_p1.clone(), menv_p2.clone())),
            _ => {
                let wx2_p1e = {
                    let mut this: crate::lower::node_::Wx = wx_p0.clone();
                    this.build_p = crate::prelude::push(&this.build_p, &crate::lower::expr::refusal_do_f(&Text::lit("a statement this back end does not lower yet")));
                    this
                };
                prism_rtl::Turn::Finished((wx2_p1e.clone(), benv_p1.clone(), menv_p2.clone()))
            },
        }
    }
}

/// `Start WidgetStmt, x`: what the function value is when passed to `@Run`.
pub fn start_widget_stmt_f(wx_p0: crate::lower::node_::Wx, benv_p1: crate::lower::types::Env, menv_p2: crate::lower::types::Env, s_p3: crate::syntax::Stmt, last_p4: bool) -> Rc<dyn prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>> {
    Rc::new(WidgetStmt { wx_p0, benv_p1, menv_p2, s_p3, last_p4 })
}

/// ```prism
/// BindHosted: fn Wx, Env, Env, Wres, Bn, [Pattern] -> ((Wx, Env, Env))
/// ```
pub fn bind_hosted_f(wx_p0: &crate::lower::node_::Wx, benv_p1: &crate::lower::types::Env, menv_p2: &crate::lower::types::Env, res_p3: &crate::lower::node_::Wres, doc_p4: &crate::lower::types::Bn, ps_p5: &Array<crate::syntax::Pattern_>) -> (crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env) {
    let r_o6 = match res_p3 {
        crate::lower::node_::Wres::WrEv(r_p7) => Some(crate::lower::types::Bn::BnEv(r_p7.clone(), crate::lower::model::OutTy::OutUnit)),
        crate::lower::node_::Wres::WrDyn(ex_p8, rds_p9, t_pa) => Some(crate::lower::types::Bn::BnDyn(ex_p8.clone(), rds_p9.clone(), t_pa.clone())),
        crate::lower::node_::Wres::WrParts(_) => Some(bundle_bn_f(res_p3)),
        _ => None,
    };
    let (be1_pb, me1_pc) = bind_part_f(benv_p1, menv_p2, &crate::prelude::index(ps_p5, &Nat::from(0u32)), &r_o6);
    bind_part2_f(wx_p0, &be1_pb, &me1_pc, &crate::prelude::index(ps_p5, &Nat::from(1u32)), &Some(doc_p4.clone()))
}

/// ```prism
/// BindPart: fn Env, Env, ?Pattern, ?Bn -> ((Env, Env))
/// ```
pub fn bind_part_f(benv_p0: &crate::lower::types::Env, menv_p1: &crate::lower::types::Env, p_o2: &Option<crate::syntax::Pattern_>, b_o3: &Option<crate::lower::types::Bn>) -> (crate::lower::types::Env, crate::lower::types::Env) {
    match (p_o2.clone(), b_o3.clone()) {
        (Some(p_p4), Some(b_p5)) => match &*p_p4.kind_p {
            crate::syntax::PatternKind::PName(n_p6) => (crate::lower::types::bind_f(benv_p0, &crate::check::env::sname_key_f(n_p6), &b_p5), crate::lower::types::bind_f(menv_p1, &crate::check::env::sname_key_f(n_p6), &b_p5)),
            _ => (benv_p0.clone(), menv_p1.clone()),
        },
        _ => (benv_p0.clone(), menv_p1.clone()),
    }
}

/// ```prism
/// BindPart2: fn Wx, Env, Env, ?Pattern, ?Bn -> ((Wx, Env, Env))
/// ```
pub fn bind_part2_f(wx_p0: &crate::lower::node_::Wx, benv_p1: &crate::lower::types::Env, menv_p2: &crate::lower::types::Env, p_o3: &Option<crate::syntax::Pattern_>, b_o4: &Option<crate::lower::types::Bn>) -> (crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env) {
    let (be_p5, me_p6) = bind_part_f(benv_p1, menv_p2, p_o3, b_o4);
    (wx_p0.clone(), be_p5.clone(), me_p6.clone())
}

/// ```prism
/// BindParts: unbounded fn Wx, Env, Env, [Wres], [Pattern] -> ((Wx, Env, Env))
/// ```
pub fn bind_parts_f(wx_p0: &crate::lower::node_::Wx, benv_p1: &crate::lower::types::Env, menv_p2: &crate::lower::types::Env, parts_p3: &Array<crate::lower::node_::Wres>, ps_p4: &Array<crate::syntax::Pattern_>) -> (crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env) {
    crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(ps_p4)), (wx_p0.clone(), benv_p1.clone(), menv_p2.clone()), {
        let ps_p4x = ps_p4.clone();
        let parts_p3x = parts_p3.clone();
        Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), Nat)| {
            let ps_p4xy = ps_p4x.clone();
            let parts_p3xy = parts_p3x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (w_p5, be_p6, me_p7) = p0;
                let i_p8 = p1;
                match (crate::prelude::index(&ps_p4xy, &i_p8), crate::prelude::index(&parts_p3xy, &i_p8)) {
                    (Some(p_p9), Some(part_pa)) => match (part_pa.clone(), (*p_p9.kind_p).clone()) {
                        (crate::lower::node_::Wres::WrEv(r_pb), crate::syntax::PatternKind::PName(_)) => prism_rtl::Turn::Finished((bind_res_f(&w_p5, &me_p7, &p_p9, &part_pa), be_p6.clone(), me_p7.clone())),
                        (crate::lower::node_::Wres::WrParts(inner_pc), crate::syntax::PatternKind::PTuple(qs_pd)) => prism_rtl::Turn::More(Rc::new(BindParts { wx_p0: w_p5.clone(), benv_p1: be_p6.clone(), menv_p2: me_p7.clone(), parts_p3: inner_pc.clone(), ps_p4: qs_pd.clone() })),
                        (_, crate::syntax::PatternKind::PName(n_pe)) => match &part_pa {
                            crate::lower::node_::Wres::WrUnit => prism_rtl::Turn::Finished((w_p5.clone(), be_p6.clone(), me_p7.clone())),
                            crate::lower::node_::Wres::WrDyn(ex_pf, rds_pg, t_ph) => {
                                let b_pi = crate::lower::types::Bn::BnDyn(ex_pf.clone(), rds_pg.clone(), t_ph.clone());
                                prism_rtl::Turn::Finished(result_getter_f(&w_p5, &me_p7, &n_pe, ex_pf, rds_pg, t_ph, &crate::lower::types::bind_f(&be_p6, &crate::check::env::sname_key_f(&n_pe), &b_pi), &crate::lower::types::bind_f(&me_p7, &crate::check::env::sname_key_f(&n_pe), &b_pi)))
                            },
                            _ => {
                                let b_pj = bundle_bn_f(&part_pa);
                                prism_rtl::Turn::Finished((w_p5.clone(), crate::lower::types::bind_f(&be_p6, &crate::check::env::sname_key_f(&n_pe), &b_pj), crate::lower::types::bind_f(&me_p7, &crate::check::env::sname_key_f(&n_pe), &b_pj)))
                            },
                        },
                        _ => prism_rtl::Turn::Finished((w_p5.clone(), be_p6.clone(), me_p7.clone())),
                    },
                    _ => prism_rtl::Turn::Finished((w_p5.clone(), be_p6.clone(), me_p7.clone())),
                }
            }))
        }) as Rc<dyn Fn(((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), Nat)) -> Rc<dyn prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>>>
    }))
}

/// The step machine of `BindParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BindParts: unbounded fn Wx, Env, Env, [Wres], [Pattern] -> ((Wx, Env, Env))
/// ```
pub struct BindParts {
    pub wx_p0: crate::lower::node_::Wx,
    pub benv_p1: crate::lower::types::Env,
    pub menv_p2: crate::lower::types::Env,
    pub parts_p3: Array<crate::lower::node_::Wres>,
    pub ps_p4: Array<crate::syntax::Pattern_>,
}

impl prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)> for BindParts {
    fn cycle(&self) -> prism_rtl::Turn<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)> {
        let wx_p0 = &self.wx_p0;
        let benv_p1 = &self.benv_p1;
        let menv_p2 = &self.menv_p2;
        let parts_p3 = &self.parts_p3;
        let ps_p4 = &self.ps_p4;
        crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(ps_p4)), (wx_p0.clone(), benv_p1.clone(), menv_p2.clone()), {
            let ps_p4x = ps_p4.clone();
            let parts_p3x = parts_p3.clone();
            Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), Nat)| {
                let ps_p4xy = ps_p4x.clone();
                let parts_p3xy = parts_p3x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let (w_p5, be_p6, me_p7) = p0;
                    let i_p8 = p1;
                    match (crate::prelude::index(&ps_p4xy, &i_p8), crate::prelude::index(&parts_p3xy, &i_p8)) {
                        (Some(p_p9), Some(part_pa)) => match (part_pa.clone(), (*p_p9.kind_p).clone()) {
                            (crate::lower::node_::Wres::WrEv(r_pb), crate::syntax::PatternKind::PName(_)) => prism_rtl::Turn::Finished((bind_res_f(&w_p5, &me_p7, &p_p9, &part_pa), be_p6.clone(), me_p7.clone())),
                            (crate::lower::node_::Wres::WrParts(inner_pc), crate::syntax::PatternKind::PTuple(qs_pd)) => prism_rtl::Turn::More(Rc::new(BindParts { wx_p0: w_p5.clone(), benv_p1: be_p6.clone(), menv_p2: me_p7.clone(), parts_p3: inner_pc.clone(), ps_p4: qs_pd.clone() })),
                            (_, crate::syntax::PatternKind::PName(n_pe)) => match &part_pa {
                                crate::lower::node_::Wres::WrUnit => prism_rtl::Turn::Finished((w_p5.clone(), be_p6.clone(), me_p7.clone())),
                                crate::lower::node_::Wres::WrDyn(ex_pf, rds_pg, t_ph) => {
                                    let b_pi = crate::lower::types::Bn::BnDyn(ex_pf.clone(), rds_pg.clone(), t_ph.clone());
                                    prism_rtl::Turn::Finished(result_getter_f(&w_p5, &me_p7, &n_pe, ex_pf, rds_pg, t_ph, &crate::lower::types::bind_f(&be_p6, &crate::check::env::sname_key_f(&n_pe), &b_pi), &crate::lower::types::bind_f(&me_p7, &crate::check::env::sname_key_f(&n_pe), &b_pi)))
                                },
                                _ => {
                                    let b_pj = bundle_bn_f(&part_pa);
                                    prism_rtl::Turn::Finished((w_p5.clone(), crate::lower::types::bind_f(&be_p6, &crate::check::env::sname_key_f(&n_pe), &b_pj), crate::lower::types::bind_f(&me_p7, &crate::check::env::sname_key_f(&n_pe), &b_pj)))
                                },
                            },
                            _ => prism_rtl::Turn::Finished((w_p5.clone(), be_p6.clone(), me_p7.clone())),
                        },
                        _ => prism_rtl::Turn::Finished((w_p5.clone(), be_p6.clone(), me_p7.clone())),
                    }
                }))
            }) as Rc<dyn Fn(((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), Nat)) -> Rc<dyn prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>>>
        }).cycle()
    }
}

/// `Start BindParts, x`: what the function value is when passed to `@Run`.
pub fn start_bind_parts_f(wx_p0: crate::lower::node_::Wx, benv_p1: crate::lower::types::Env, menv_p2: crate::lower::types::Env, parts_p3: Array<crate::lower::node_::Wres>, ps_p4: Array<crate::syntax::Pattern_>) -> Rc<dyn prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>> {
    Rc::new(BindParts { wx_p0, benv_p1, menv_p2, parts_p3, ps_p4 })
}

/// ```prism
/// ResultGetter: fn Wx, Env, SName, Ex, [Read], OutTy, Env, Env -> ((Wx, Env, Env))
/// ```
pub fn result_getter_f(wx_p0: &crate::lower::node_::Wx, menv_p1: &crate::lower::types::Env, n_p2: &crate::syntax::SName, ex_p3: &crate::lower::model::Ex, rds_p4: &Array<crate::lower::node_::Read>, t_p5: &crate::lower::model::OutTy, benv2_p6: &crate::lower::types::Env, menv2_p7: &crate::lower::types::Env) -> (crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env) {
    'm20830: {
        let scrutinee = &crate::prelude::get(&menv_p1.names_p, &crate::check::env::sname_key_f(n_p2));
        if let Some(crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(m20830_0_0_0, rs_p8, _), m20830_0_1, _)) = scrutinee && let crate::lower::model::Ex::XSelf = &**m20830_0_0_0 && (m20830_0_1.len() == 1) && let Some(crate::lower::node_::Read::OwnRead(r0_p9)) = crate::prelude::index(m20830_0_1, &Nat::from(0u32)) && ((&r0_p9 == rs_p8) && !crate::check::types::has_text_f(&crate::prelude::keys(&wx_p0.dyn_reads_p), rs_p8)) {
            break 'm20830 {
                let getter_pa = crate::lower::model::MethDef { name_p: rs_p8.clone(), recv_p: crate::lower::model::Recv::RecvRef, params_p: Array::new(), cx_p: crate::lower::model::CxArg::CxRef, ret_p: t_p5.clone(), body_p: Array::new(), tail_p: ex_p3.clone(), doc_p: Text::from(format!("`{}`, a widget\'s result", &crate::check::env::sname_key_f(n_p2))) };
                let wx2_pb = {
                    let mut this: crate::lower::node_::Wx = wx_p0.clone();
                    this.getters_p = crate::prelude::push(&this.getters_p, &getter_pa);
                    this.dyn_reads_p = crate::prelude::insert(&this.dyn_reads_p, rs_p8, rds_p4);
                    this
                };
                (wx2_pb.clone(), benv2_p6.clone(), menv2_p7.clone())
            };
        }
        (wx_p0.clone(), benv2_p6.clone(), menv2_p7.clone())
    }
}

/// ```prism
/// BindPlainResult: unbounded fn Wx, Env, Pattern, Ex, OutTy -> Wx
/// ```
pub fn bind_plain_result_f(wx_p0: &crate::lower::node_::Wx, menv_p1: &crate::lower::types::Env, p_p2: &crate::syntax::Pattern_, ex_p3: &crate::lower::model::Ex, t_p4: &crate::lower::model::OutTy) -> crate::lower::node_::Wx {
    match &*p_p2.kind_p {
        crate::syntax::PatternKind::PName(n_p5) => match crate::prelude::get(&menv_p1.names_p, &crate::check::env::sname_key_f(n_p5)) {
            Some(crate::lower::types::Bn::BnLocal(rx_p6, _, bt_p7)) => {
                let f_p8 = crate::lower::types::place_stem_f(&rx_p6);
                {
                    let mut this: crate::lower::node_::Wx = wx_p0.clone();
                    this.lets_p = crate::prelude::push(&this.lets_p, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaBind(f_p8.clone())), bt_p7.clone()), ex_p3.clone()));
                    this.fields_p = crate::prelude::push(&this.fields_p, &(f_p8.clone(), bt_p7.clone(), Text::from(format!("`{}`, a widget\'s result", &crate::check::env::sname_key_f(n_p5)))));
                    this.inits_p = crate::prelude::push(&this.inits_p, &(f_p8.clone(), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(f_p8.clone())))));
                    this
                }
            },
            _ => refuse_plain_result_f(wx_p0, p_p2),
        },
        crate::syntax::PatternKind::PIgnore => wx_p0.clone(),
        crate::syntax::PatternKind::PGroup(q_p9) => bind_plain_result_f(wx_p0, menv_p1, &**q_p9, ex_p3, t_p4),
        crate::syntax::PatternKind::PTuple(ps_pa) => {
            let (tmp_pd, wx1_pe) = crate::lower::node_::fresh_name_f(wx_p0, &Text::lit("result"));
            let wx2_pb = {
                let mut this: crate::lower::node_::Wx = wx1_pe.clone();
                this.lets_p = crate::prelude::push(&this.lets_p, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaBind(tmp_pd.clone())), t_p4.clone()), ex_p3.clone()));
                this
            };
            let parts_pc = match t_p4 {
                crate::lower::model::OutTy::OutTuple(ts_pf) => ts_pf.clone(),
                _ => Array::new(),
            };
            crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(ps_pa)), wx2_pb.clone(), {
                let ps_pax = ps_pa.clone();
                let menv_p1x = menv_p1.clone();
                let tmp_pdx = tmp_pd.clone();
                let parts_pcx = parts_pc.clone();
                Rc::new(move |(p0, p1): (crate::lower::node_::Wx, Nat)| {
                    let ps_paxy = ps_pax.clone();
                    let menv_p1xy = menv_p1x.clone();
                    let tmp_pdxy = tmp_pdx.clone();
                    let parts_pcxy = parts_pcx.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let w_pg = p0;
                        let i_ph = p1;
                        match crate::prelude::index(&ps_paxy, &i_ph) {
                            Some(q_pi) => match &*q_pi.kind_p {
                                crate::syntax::PatternKind::PName(_) => prism_rtl::Turn::More(Rc::new(BindPlainResult { wx_p0: w_pg.clone(), menv_p1: menv_p1xy.clone(), p_p2: q_pi.clone(), ex_p3: crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XPart(Rc::new(crate::lower::model::Ex::XVar(tmp_pdxy.clone())), i_ph.clone()))), t_p4: crate::prelude::or(&crate::prelude::index(&parts_pcxy, &i_ph), &crate::lower::model::OutTy::OutUnit) })),
                                crate::syntax::PatternKind::PIgnore => prism_rtl::Turn::Finished(w_pg.clone()),
                                _ => prism_rtl::Turn::Finished(refuse_plain_result_f(&w_pg, &q_pi)),
                            },
                            None => prism_rtl::Turn::Finished(w_pg.clone()),
                        }
                    }))
                }) as Rc<dyn Fn((crate::lower::node_::Wx, Nat)) -> Rc<dyn prism_rtl::Job<crate::lower::node_::Wx>>>
            }))
        },
        _ => refuse_plain_result_f(wx_p0, p_p2),
    }
}

/// The step machine of `BindPlainResult`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BindPlainResult: unbounded fn Wx, Env, Pattern, Ex, OutTy -> Wx
/// ```
pub struct BindPlainResult {
    pub wx_p0: crate::lower::node_::Wx,
    pub menv_p1: crate::lower::types::Env,
    pub p_p2: crate::syntax::Pattern_,
    pub ex_p3: crate::lower::model::Ex,
    pub t_p4: crate::lower::model::OutTy,
}

impl prism_rtl::Job<crate::lower::node_::Wx> for BindPlainResult {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::node_::Wx> {
        let wx_p0 = &self.wx_p0;
        let menv_p1 = &self.menv_p1;
        let p_p2 = &self.p_p2;
        let ex_p3 = &self.ex_p3;
        let t_p4 = &self.t_p4;
        match &*p_p2.kind_p {
            crate::syntax::PatternKind::PName(n_p5) => match crate::prelude::get(&menv_p1.names_p, &crate::check::env::sname_key_f(n_p5)) {
                Some(crate::lower::types::Bn::BnLocal(rx_p6, _, bt_p7)) => {
                    let f_p8 = crate::lower::types::place_stem_f(&rx_p6);
                    prism_rtl::Turn::Finished({
                        let mut this: crate::lower::node_::Wx = wx_p0.clone();
                        this.lets_p = crate::prelude::push(&this.lets_p, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaBind(f_p8.clone())), bt_p7.clone()), ex_p3.clone()));
                        this.fields_p = crate::prelude::push(&this.fields_p, &(f_p8.clone(), bt_p7.clone(), Text::from(format!("`{}`, a widget\'s result", &crate::check::env::sname_key_f(n_p5)))));
                        this.inits_p = crate::prelude::push(&this.inits_p, &(f_p8.clone(), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(f_p8.clone())))));
                        this
                    })
                },
                _ => prism_rtl::Turn::Finished(refuse_plain_result_f(wx_p0, p_p2)),
            },
            crate::syntax::PatternKind::PIgnore => prism_rtl::Turn::Finished(wx_p0.clone()),
            crate::syntax::PatternKind::PGroup(q_p9) => prism_rtl::Turn::More(Rc::new(BindPlainResult { wx_p0: wx_p0.clone(), menv_p1: menv_p1.clone(), p_p2: (**q_p9).clone(), ex_p3: ex_p3.clone(), t_p4: t_p4.clone() })),
            crate::syntax::PatternKind::PTuple(ps_pa) => {
                let (tmp_pd, wx1_pe) = crate::lower::node_::fresh_name_f(wx_p0, &Text::lit("result"));
                let wx2_pb = {
                    let mut this: crate::lower::node_::Wx = wx1_pe.clone();
                    this.lets_p = crate::prelude::push(&this.lets_p, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaBind(tmp_pd.clone())), t_p4.clone()), ex_p3.clone()));
                    this
                };
                let parts_pc = match t_p4 {
                    crate::lower::model::OutTy::OutTuple(ts_pf) => ts_pf.clone(),
                    _ => Array::new(),
                };
                crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(ps_pa)), wx2_pb.clone(), {
                    let ps_pax = ps_pa.clone();
                    let menv_p1x = menv_p1.clone();
                    let tmp_pdx = tmp_pd.clone();
                    let parts_pcx = parts_pc.clone();
                    Rc::new(move |(p0, p1): (crate::lower::node_::Wx, Nat)| {
                        let ps_paxy = ps_pax.clone();
                        let menv_p1xy = menv_p1x.clone();
                        let tmp_pdxy = tmp_pdx.clone();
                        let parts_pcxy = parts_pcx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let w_pg = p0;
                            let i_ph = p1;
                            match crate::prelude::index(&ps_paxy, &i_ph) {
                                Some(q_pi) => match &*q_pi.kind_p {
                                    crate::syntax::PatternKind::PName(_) => prism_rtl::Turn::More(Rc::new(BindPlainResult { wx_p0: w_pg.clone(), menv_p1: menv_p1xy.clone(), p_p2: q_pi.clone(), ex_p3: crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XPart(Rc::new(crate::lower::model::Ex::XVar(tmp_pdxy.clone())), i_ph.clone()))), t_p4: crate::prelude::or(&crate::prelude::index(&parts_pcxy, &i_ph), &crate::lower::model::OutTy::OutUnit) })),
                                    crate::syntax::PatternKind::PIgnore => prism_rtl::Turn::Finished(w_pg.clone()),
                                    _ => prism_rtl::Turn::Finished(refuse_plain_result_f(&w_pg, &q_pi)),
                                },
                                None => prism_rtl::Turn::Finished(w_pg.clone()),
                            }
                        }))
                    }) as Rc<dyn Fn((crate::lower::node_::Wx, Nat)) -> Rc<dyn prism_rtl::Job<crate::lower::node_::Wx>>>
                }).cycle()
            },
            _ => prism_rtl::Turn::Finished(refuse_plain_result_f(wx_p0, p_p2)),
        }
    }
}

/// `Start BindPlainResult, x`: what the function value is when passed to `@Run`.
pub fn start_bind_plain_result_f(wx_p0: crate::lower::node_::Wx, menv_p1: crate::lower::types::Env, p_p2: crate::syntax::Pattern_, ex_p3: crate::lower::model::Ex, t_p4: crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<crate::lower::node_::Wx>> {
    Rc::new(BindPlainResult { wx_p0, menv_p1, p_p2, ex_p3, t_p4 })
}

/// ```prism
/// RefusePlainResult: fn Wx, Pattern -> Wx
/// ```
pub fn refuse_plain_result_f(wx_p0: &crate::lower::node_::Wx, p_p1: &crate::syntax::Pattern_) -> crate::lower::node_::Wx {
    let mut this: crate::lower::node_::Wx = wx_p0.clone();
    this.build_p = crate::prelude::push(&this.build_p, &crate::lower::expr::refusal_do_f(&Text::lit("a widget\'s plain result bound by this pattern: a name, or a tuple of names, binds one")));
    this
}

/// ```prism
/// BundleBn: fn Wres -> Bn
/// ```
pub fn bundle_bn_f(res_p0: &crate::lower::node_::Wres) -> crate::lower::types::Bn {
    match res_p0 {
        crate::lower::node_::Wres::WrEv(r_p1) => crate::lower::types::Bn::BnEv(r_p1.clone(), crate::lower::model::OutTy::OutUnit),
        crate::lower::node_::Wres::WrDyn(ex_p2, rds_p3, t_p4) => crate::lower::types::Bn::BnDyn(ex_p2.clone(), rds_p3.clone(), t_p4.clone()),
        crate::lower::node_::Wres::WrPlain(ex_p5, t_p6) => crate::lower::types::Bn::BnLocal(ex_p5.clone(), crate::lower::types::Holding::Owned, t_p6.clone()),
        crate::lower::node_::Wres::WrParts(parts_p7) => crate::lower::types::Bn::BnParts(crate::prelude::each(parts_p7, &(|q_p8: &crate::lower::node_::Wres| Some(bundle_bn_f(q_p8))))),
        crate::lower::node_::Wres::WrHosted(inner_p9, _) => bundle_bn_f(&**inner_p9),
        crate::lower::node_::Wres::WrUnit => crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XUnit, crate::lower::types::Holding::Owned, crate::lower::model::OutTy::OutUnit),
    }
}

/// ```prism
/// BnRes: fn Bn -> Wres
/// ```
pub fn bn_res_f(b_p0: &crate::lower::types::Bn) -> crate::lower::node_::Wres {
    match b_p0 {
        crate::lower::types::Bn::BnEv(r_p1, _) => crate::lower::node_::Wres::WrEv(r_p1.clone()),
        crate::lower::types::Bn::BnDyn(ex_p2, rds_p3, t_p4) => crate::lower::node_::Wres::WrDyn(ex_p2.clone(), rds_p3.clone(), t_p4.clone()),
        crate::lower::types::Bn::BnLocal(ex_p5, _, t_p6) => if t_p6 == &crate::lower::model::OutTy::OutUnit {
            crate::lower::node_::Wres::WrUnit
        } else {
            crate::lower::node_::Wres::WrPlain(ex_p5.clone(), t_p6.clone())
        },
        crate::lower::types::Bn::BnParts(bs_p7) => crate::lower::node_::Wres::WrParts(crate::prelude::each(bs_p7, &part_res_f)),
        _ => crate::lower::node_::Wres::WrUnit,
    }
}

/// ```prism
/// PartRes: fn ?Bn -> Wres
/// ```
pub fn part_res_f(b_o0: &Option<crate::lower::types::Bn>) -> crate::lower::node_::Wres {
    match b_o0 {
        Some(b_p1) => bn_res_f(b_p1),
        None => crate::lower::node_::Wres::WrUnit,
    }
}

/// ```prism
/// SetResult: fn Wx, Wres -> Wx
/// ```
pub fn set_result_f(wx_p0: &crate::lower::node_::Wx, res_p1: &crate::lower::node_::Wres) -> crate::lower::node_::Wx {
    let mut this: crate::lower::node_::Wx = wx_p0.clone();
    this.result_p = res_p1.clone();
    this
}

/// ```prism
/// ResultOf: unbounded fn Wx, Env, Env, Expr -> ((Wres, Wx))
/// ```
pub fn result_of_f(wx_p0: &crate::lower::node_::Wx, benv_p1: &crate::lower::types::Env, menv_p2: &crate::lower::types::Env, x_p3: &crate::syntax::Expr) -> (crate::lower::node_::Wres, crate::lower::node_::Wx) {
    let lx_p4 = wx_p0.lx_p.clone();
    let full_p5 = crate::lower::type_at_f(&lx_p4, &x_p3.span_p);
    let t_p6 = crate::lower::types::out_ty_of_f(&lx_p4, &crate::lower::types::peel_f(&full_p5));
    let bound_o7 = match &*x_p3.kind_p {
        crate::syntax::ExprKind::EName(n_p8) => if &crate::prelude::len(&n_p8.path_p) == &Nat::from(1u32) {
            crate::prelude::get(&menv_p2.names_p, &crate::check::env::sname_key_f(n_p8))
        } else {
            None
        },
        _ => None,
    };
    match &bound_o7 {
        Some(crate::lower::types::Bn::BnEv(r_p9, _)) => (crate::lower::node_::Wres::WrEv(r_p9.clone()), wx_p0.clone()),
        Some(crate::lower::types::Bn::BnDyn(ex_pa, rds_pb, bt_pc)) => (crate::lower::node_::Wres::WrDyn(ex_pa.clone(), rds_pb.clone(), bt_pc.clone()), wx_p0.clone()),
        Some(crate::lower::types::Bn::BnParts(bs_pd)) => (bn_res_f(&crate::lower::types::Bn::BnParts(bs_pd.clone())), wx_p0.clone()),
        _ => match &*x_p3.kind_p {
            crate::syntax::ExprKind::ETuple(xs_pe) if crate::lower::types::is_bundle_f(&full_p5) => {
                let (parts_pk, wx2_pl) = crate::prelude::run_to_end(crate::prelude::fold_job(xs_pe.clone(), (Array::new(), wx_p0.clone()), {
                    let benv_p1x = benv_p1.clone();
                    let menv_p2x = menv_p2.clone();
                    Rc::new(move |(p0, p1): ((Array<crate::lower::node_::Wres>, crate::lower::node_::Wx), crate::syntax::Expr)| {
                        let benv_p1xy = benv_p1x.clone();
                        let menv_p2xy = menv_p2x.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let (acc_pf, w_pg) = p0;
                            let y_ph = p1;
                            crate::prelude::call_then(start_result_of_f(w_pg.clone(), benv_p1xy.clone(), menv_p2xy.clone(), y_ph.clone()), move |result_of_f_24875: (crate::lower::node_::Wres, crate::lower::node_::Wx)| {
                                let (r_pi, w2_pj) = result_of_f_24875;
                                prism_rtl::Turn::Finished((crate::prelude::push(&acc_pf, &r_pi), w2_pj.clone()))
                            })
                        }))
                    }) as Rc<dyn Fn(((Array<crate::lower::node_::Wres>, crate::lower::node_::Wx), crate::syntax::Expr)) -> Rc<dyn prism_rtl::Job<(Array<crate::lower::node_::Wres>, crate::lower::node_::Wx)>>>
                }));
                (crate::lower::node_::Wres::WrParts(parts_pk.clone()), wx2_pl.clone())
            },
            _ => result_of_typed_f(wx_p0, benv_p1, menv_p2, x_p3, &full_p5, &t_p6),
            _ => unreachable!("no arm matched"),
        },
    }
}

/// The step machine of `ResultOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ResultOf: unbounded fn Wx, Env, Env, Expr -> ((Wres, Wx))
/// ```
pub struct ResultOf {
    pub wx_p0: crate::lower::node_::Wx,
    pub benv_p1: crate::lower::types::Env,
    pub menv_p2: crate::lower::types::Env,
    pub x_p3: crate::syntax::Expr,
}

impl prism_rtl::Job<(crate::lower::node_::Wres, crate::lower::node_::Wx)> for ResultOf {
    fn cycle(&self) -> prism_rtl::Turn<(crate::lower::node_::Wres, crate::lower::node_::Wx)> {
        let wx_p0 = &self.wx_p0;
        let benv_p1 = &self.benv_p1;
        let menv_p2 = &self.menv_p2;
        let x_p3 = &self.x_p3;
        let lx_p4 = wx_p0.lx_p.clone();
        let full_p5 = crate::lower::type_at_f(&lx_p4, &x_p3.span_p);
        let benv_p1x = benv_p1.clone();
        let menv_p2x = menv_p2.clone();
        let wx_p0x = wx_p0.clone();
        let x_p3x = x_p3.clone();
        crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p4.clone(), crate::lower::types::peel_f(&full_p5)), move |out_ty_of_f_24284: crate::lower::model::OutTy| {
            let t_p6 = out_ty_of_f_24284;
            let bound_o7 = match &*x_p3x.kind_p {
                crate::syntax::ExprKind::EName(n_p8) => if &crate::prelude::len(&n_p8.path_p) == &Nat::from(1u32) {
                    crate::prelude::get(&menv_p2x.names_p, &crate::check::env::sname_key_f(n_p8))
                } else {
                    None
                },
                _ => None,
            };
            match &bound_o7 {
                Some(crate::lower::types::Bn::BnEv(r_p9, _)) => prism_rtl::Turn::Finished((crate::lower::node_::Wres::WrEv(r_p9.clone()), wx_p0x.clone())),
                Some(crate::lower::types::Bn::BnDyn(ex_pa, rds_pb, bt_pc)) => prism_rtl::Turn::Finished((crate::lower::node_::Wres::WrDyn(ex_pa.clone(), rds_pb.clone(), bt_pc.clone()), wx_p0x.clone())),
                Some(crate::lower::types::Bn::BnParts(bs_pd)) => prism_rtl::Turn::Finished((bn_res_f(&crate::lower::types::Bn::BnParts(bs_pd.clone())), wx_p0x.clone())),
                _ => match &*x_p3x.kind_p {
                    crate::syntax::ExprKind::ETuple(xs_pe) if crate::lower::types::is_bundle_f(&full_p5) => {
                        let xs_pex = xs_pe.clone();
                        crate::prelude::call_value(crate::prelude::fold_job(xs_pex.clone(), (Array::new(), wx_p0x.clone()), {
                            let benv_p1xx = benv_p1x.clone();
                            let menv_p2xx = menv_p2x.clone();
                            Rc::new(move |(p0, p1): ((Array<crate::lower::node_::Wres>, crate::lower::node_::Wx), crate::syntax::Expr)| {
                                let benv_p1xxy = benv_p1xx.clone();
                                let menv_p2xxy = menv_p2xx.clone();
                                crate::prelude::entered(crate::prelude::once_job(move || {
                                    let (acc_pf, w_pg) = p0;
                                    let y_ph = p1;
                                    crate::prelude::call_then(start_result_of_f(w_pg.clone(), benv_p1xxy.clone(), menv_p2xxy.clone(), y_ph.clone()), move |result_of_f_24875: (crate::lower::node_::Wres, crate::lower::node_::Wx)| {
                                        let (r_pi, w2_pj) = result_of_f_24875;
                                        prism_rtl::Turn::Finished((crate::prelude::push(&acc_pf, &r_pi), w2_pj.clone()))
                                    })
                                }))
                            }) as Rc<dyn Fn(((Array<crate::lower::node_::Wres>, crate::lower::node_::Wx), crate::syntax::Expr)) -> Rc<dyn prism_rtl::Job<(Array<crate::lower::node_::Wres>, crate::lower::node_::Wx)>>>
                        }), move |fold_24799: (Array<crate::lower::node_::Wres>, crate::lower::node_::Wx)| {
                            let (parts_pk, wx2_pl) = fold_24799;
                            prism_rtl::Turn::Finished((crate::lower::node_::Wres::WrParts(parts_pk.clone()), wx2_pl.clone()))
                        })
                    },
                    _ => prism_rtl::Turn::More(Rc::new(ResultOfTyped { wx_p0: wx_p0x.clone(), benv_p1: benv_p1x.clone(), menv_p2: menv_p2x.clone(), x_p3: x_p3x.clone(), full_p4: full_p5.clone(), t_p5: t_p6.clone() })),
                    _ => unreachable!("no arm matched"),
                },
            }
        })
    }
}

/// `Start ResultOf, x`: what the function value is when passed to `@Run`.
pub fn start_result_of_f(wx_p0: crate::lower::node_::Wx, benv_p1: crate::lower::types::Env, menv_p2: crate::lower::types::Env, x_p3: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<(crate::lower::node_::Wres, crate::lower::node_::Wx)>> {
    Rc::new(ResultOf { wx_p0, benv_p1, menv_p2, x_p3 })
}

/// ```prism
/// ResultOfTyped: unbounded fn Wx, Env, Env, Expr, Ty, OutTy -> ((Wres, Wx))
/// ```
pub fn result_of_typed_f(wx_p0: &crate::lower::node_::Wx, benv_p1: &crate::lower::types::Env, menv_p2: &crate::lower::types::Env, x_p3: &crate::syntax::Expr, full_p4: &crate::check::types::Ty, t_p5: &crate::lower::model::OutTy) -> (crate::lower::node_::Wres, crate::lower::node_::Wx) {
    let lx_p6 = wx_p0.lx_p.clone();
    match crate::lower::types::layer_of_f(full_p4) {
        crate::lower::types::Layer::LyEv => {
            let (r_p7, wx2_p8) = crate::lower::node_::dynamics::event_ref_f(wx_p0, menv_p2, x_p3);
            (crate::lower::node_::Wres::WrEv(r_p7.clone()), wx2_p8.clone())
        },
        crate::lower::types::Layer::LyDyn => {
            let (ex_p9, reads_pa) = crate::lower::node_::dynamics::dynamic_expr_f(wx_p0, menv_p2, x_p3);
            (crate::lower::node_::Wres::WrDyn(ex_p9.clone(), reads_pa.clone(), t_p5.clone()), wx_p0.clone())
        },
        _ => if t_p5 == &crate::lower::model::OutTy::OutUnit {
            (crate::lower::node_::Wres::WrUnit, wx_p0.clone())
        } else {
            (crate::lower::node_::Wres::WrPlain(crate::lower::types::own_f(&crate::lower::expr::value_of_f(&lx_p6, benv_p1, x_p3)), t_p5.clone()), wx_p0.clone())
        },
    }
}

/// The step machine of `ResultOfTyped`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ResultOfTyped: unbounded fn Wx, Env, Env, Expr, Ty, OutTy -> ((Wres, Wx))
/// ```
pub struct ResultOfTyped {
    pub wx_p0: crate::lower::node_::Wx,
    pub benv_p1: crate::lower::types::Env,
    pub menv_p2: crate::lower::types::Env,
    pub x_p3: crate::syntax::Expr,
    pub full_p4: crate::check::types::Ty,
    pub t_p5: crate::lower::model::OutTy,
}

impl prism_rtl::Job<(crate::lower::node_::Wres, crate::lower::node_::Wx)> for ResultOfTyped {
    fn cycle(&self) -> prism_rtl::Turn<(crate::lower::node_::Wres, crate::lower::node_::Wx)> {
        let wx_p0 = &self.wx_p0;
        let benv_p1 = &self.benv_p1;
        let menv_p2 = &self.menv_p2;
        let x_p3 = &self.x_p3;
        let full_p4 = &self.full_p4;
        let t_p5 = &self.t_p5;
        let lx_p6 = wx_p0.lx_p.clone();
        match crate::lower::types::layer_of_f(full_p4) {
            crate::lower::types::Layer::LyEv => {
                let menv_p2x = menv_p2.clone();
                let wx_p0x = wx_p0.clone();
                let x_p3x = x_p3.clone();
                crate::prelude::call_then(crate::lower::node_::dynamics::start_event_ref_f(wx_p0x.clone(), menv_p2x.clone(), x_p3x.clone()), move |event_ref_f_25252: (crate::lower::node_::EvRef, crate::lower::node_::Wx)| {
                    let (r_p7, wx2_p8) = event_ref_f_25252;
                    prism_rtl::Turn::Finished((crate::lower::node_::Wres::WrEv(r_p7.clone()), wx2_p8.clone()))
                })
            },
            crate::lower::types::Layer::LyDyn => {
                let menv_p2x = menv_p2.clone();
                let t_p5x = t_p5.clone();
                let wx_p0x = wx_p0.clone();
                let x_p3x = x_p3.clone();
                crate::prelude::call_then(crate::lower::node_::dynamics::start_dynamic_expr_f(wx_p0x.clone(), menv_p2x.clone(), x_p3x.clone()), move |dynamic_expr_f_25348: (crate::lower::model::Ex, Array<crate::lower::node_::Read>)| {
                    let (ex_p9, reads_pa) = dynamic_expr_f_25348;
                    prism_rtl::Turn::Finished((crate::lower::node_::Wres::WrDyn(ex_p9.clone(), reads_pa.clone(), t_p5x.clone()), wx_p0x.clone()))
                })
            },
            _ => if t_p5 == &crate::lower::model::OutTy::OutUnit {
                prism_rtl::Turn::Finished((crate::lower::node_::Wres::WrUnit, wx_p0.clone()))
            } else {
                {
                    let benv_p1x = benv_p1.clone();
                    let t_p5x = t_p5.clone();
                    let wx_p0x = wx_p0.clone();
                    let x_p3x = x_p3.clone();
                    crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p6.clone(), benv_p1x.clone(), x_p3x.clone()), move |value_of_f_25511: crate::lower::types::Vl| prism_rtl::Turn::Finished((crate::lower::node_::Wres::WrPlain(crate::lower::types::own_f(&value_of_f_25511), t_p5x.clone()), wx_p0x.clone())))
                }
            },
        }
    }
}

/// `Start ResultOfTyped, x`: what the function value is when passed to `@Run`.
pub fn start_result_of_typed_f(wx_p0: crate::lower::node_::Wx, benv_p1: crate::lower::types::Env, menv_p2: crate::lower::types::Env, x_p3: crate::syntax::Expr, full_p4: crate::check::types::Ty, t_p5: crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<(crate::lower::node_::Wres, crate::lower::node_::Wx)>> {
    Rc::new(ResultOfTyped { wx_p0, benv_p1, menv_p2, x_p3, full_p4, t_p5 })
}

/// ```prism
/// HoldLine: unbounded fn Wx, Env, Env, Pattern, Expr, Expr -> ((Wx, Env))
/// ```
pub fn hold_line_f(wx_p0: &crate::lower::node_::Wx, benv_p1: &crate::lower::types::Env, menv_p2: &crate::lower::types::Env, p_p3: &crate::syntax::Pattern_, init_p4: &crate::syntax::Expr, step_p5: &crate::syntax::Expr) -> (crate::lower::node_::Wx, crate::lower::types::Env) {
    let lx_p6 = wx_p0.lx_p.clone();
    match binding_of_o(menv_p2, p_p3) {
        Some(crate::lower::types::Bn::BnHold(f_p7, t_p8)) => {
            let iv_p9 = crate::lower::types::own_f(&crate::lower::expr::value_of_f(&lx_p6, benv_p1, init_p4));
            let wx1_pa = crate::lower::node_::add_field_f(wx_p0, &f_p7, &crate::lower::model::OutTy::OutHold(Rc::new(t_p8.clone())), &Text::from(format!("`{}`", &pat_text_f(p_p3))), &crate::lower::model::Ex::XCall(Text::lit("Hold::new"), Array::from(vec![crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(Text::from(format!("{}_init", &f_p7))))), crate::lower::model::Ex::XCx])));
            let (r_pc, wx2_pd) = crate::lower::node_::dynamics::event_ref_f(&wx1_pa, menv_p2, step_p5);
            let wx3_pb = {
                let mut this: crate::lower::node_::Wx = crate::lower::node_::connect_f(&wx2_pd, &r_pc, &crate::lower::node_::Sk::SkHold(f_p7.clone()));
                this.lets_p = crate::prelude::push(&this.lets_p, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaBind(Text::from(format!("{}_init", &f_p7)))), t_p8.clone()), iv_p9.clone()));
                this.inited_p = crate::prelude::push(&this.inited_p, &f_p7);
                this
            };
            (wx3_pb.clone(), crate::lower::types::bind_f(benv_p1, &Text::from(format!("{}#init", &pat_text_f(p_p3))), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(Text::from(format!("{}_init", &f_p7))), crate::lower::types::Holding::Owned, t_p8.clone())))
        },
        _ => (wx_p0.clone(), benv_p1.clone()),
    }
}

/// The step machine of `HoldLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// HoldLine: unbounded fn Wx, Env, Env, Pattern, Expr, Expr -> ((Wx, Env))
/// ```
pub struct HoldLine {
    pub wx_p0: crate::lower::node_::Wx,
    pub benv_p1: crate::lower::types::Env,
    pub menv_p2: crate::lower::types::Env,
    pub p_p3: crate::syntax::Pattern_,
    pub init_p4: crate::syntax::Expr,
    pub step_p5: crate::syntax::Expr,
}

impl prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env)> for HoldLine {
    fn cycle(&self) -> prism_rtl::Turn<(crate::lower::node_::Wx, crate::lower::types::Env)> {
        let wx_p0 = &self.wx_p0;
        let benv_p1 = &self.benv_p1;
        let menv_p2 = &self.menv_p2;
        let p_p3 = &self.p_p3;
        let init_p4 = &self.init_p4;
        let step_p5 = &self.step_p5;
        let lx_p6 = wx_p0.lx_p.clone();
        match binding_of_o(menv_p2, p_p3) {
            Some(crate::lower::types::Bn::BnHold(f_p7, t_p8)) => {
                let benv_p1x = benv_p1.clone();
                let init_p4x = init_p4.clone();
                let menv_p2x = menv_p2.clone();
                let p_p3x = p_p3.clone();
                let step_p5x = step_p5.clone();
                let wx_p0x = wx_p0.clone();
                crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p6.clone(), benv_p1x.clone(), init_p4x.clone()), move |value_of_f_26066: crate::lower::types::Vl| {
                    let iv_p9 = crate::lower::types::own_f(&value_of_f_26066);
                    let wx1_pa = crate::lower::node_::add_field_f(&wx_p0x, &f_p7, &crate::lower::model::OutTy::OutHold(Rc::new(t_p8.clone())), &Text::from(format!("`{}`", &pat_text_f(&p_p3x))), &crate::lower::model::Ex::XCall(Text::lit("Hold::new"), Array::from(vec![crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(Text::from(format!("{}_init", &f_p7))))), crate::lower::model::Ex::XCx])));
                    crate::prelude::call_then(crate::lower::node_::dynamics::start_event_ref_f(wx1_pa.clone(), menv_p2x.clone(), step_p5x.clone()), move |event_ref_f_26244: (crate::lower::node_::EvRef, crate::lower::node_::Wx)| {
                        let (r_pc, wx2_pd) = event_ref_f_26244;
                        let wx3_pb = {
                            let mut this: crate::lower::node_::Wx = crate::lower::node_::connect_f(&wx2_pd, &r_pc, &crate::lower::node_::Sk::SkHold(f_p7.clone()));
                            this.lets_p = crate::prelude::push(&this.lets_p, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaBind(Text::from(format!("{}_init", &f_p7)))), t_p8.clone()), iv_p9.clone()));
                            this.inited_p = crate::prelude::push(&this.inited_p, &f_p7);
                            this
                        };
                        prism_rtl::Turn::Finished((wx3_pb.clone(), crate::lower::types::bind_f(&benv_p1x, &Text::from(format!("{}#init", &pat_text_f(&p_p3x))), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(Text::from(format!("{}_init", &f_p7))), crate::lower::types::Holding::Owned, t_p8.clone()))))
                    })
                })
            },
            _ => prism_rtl::Turn::Finished((wx_p0.clone(), benv_p1.clone())),
        }
    }
}

/// `Start HoldLine, x`: what the function value is when passed to `@Run`.
pub fn start_hold_line_f(wx_p0: crate::lower::node_::Wx, benv_p1: crate::lower::types::Env, menv_p2: crate::lower::types::Env, p_p3: crate::syntax::Pattern_, init_p4: crate::syntax::Expr, step_p5: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env)>> {
    Rc::new(HoldLine { wx_p0, benv_p1, menv_p2, p_p3, init_p4, step_p5 })
}

/// ```prism
/// InitEnv: fn Env -> Env
/// ```
pub fn init_env_f(env_p0: &crate::lower::types::Env) -> crate::lower::types::Env {
    crate::prelude::fold(&crate::prelude::keys(&env_p0.names_p), env_p0, &(|en_p1: &crate::lower::types::Env, k_p2: &Text| match (crate::syntax::lexer::chars::before_suffix_o(k_p2, &Text::lit("#init")), crate::prelude::get(&env_p0.names_p, k_p2)) {
        (Some(name_p3), Some(b_p4)) => crate::lower::types::bind_f(en_p1, &name_p3, &b_p4),
        _ => en_p1.clone(),
    }))
}

/// ```prism
/// AllInited: fn Wx, [Read] -> Bool
/// ```
pub fn all_inited_f(wx_p0: &crate::lower::node_::Wx, reads_p1: &Array<crate::lower::node_::Read>) -> bool {
    crate::prelude::fold(&crate::lower::node_::finish::reads_closed_f(&wx_p0.dyn_reads_p, reads_p1), &true, &(|ok_p2: &bool, r_p3: &crate::lower::node_::Read| *ok_p2 && match r_p3 {
        crate::lower::node_::Read::OwnRead(f_p4) => crate::check::types::has_text_f(&wx_p0.inited_p, f_p4),
        crate::lower::node_::Read::ParentRead(_) => false,
    }))
}

/// ```prism
/// NamesInited: unbounded fn Env, Expr -> Bool
/// ```
pub fn names_inited_f(env_p0: &crate::lower::types::Env, e_p1: &crate::syntax::Expr) -> bool {
    crate::prelude::fold(&crate::lower::expr::read_names_f(&crate::check::typed::print::exprs_in_f(e_p1)), &true, &(|ok_p2: &bool, n_p3: &Text| *ok_p2 && match crate::prelude::get(&env_p0.names_p, n_p3) {
        Some(crate::lower::types::Bn::BnDyn(_, _, _)) => crate::check::env::has_key_f(&env_p0.names_p, &Text::from(format!("{}#init", n_p3))),
        Some(crate::lower::types::Bn::BnHold(_, _)) => crate::check::env::has_key_f(&env_p0.names_p, &Text::from(format!("{}#init", n_p3))),
        _ => true,
    }))
}

/// The step machine of `NamesInited`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// NamesInited: unbounded fn Env, Expr -> Bool
/// ```
pub struct NamesInited {
    pub env_p0: crate::lower::types::Env,
    pub e_p1: crate::syntax::Expr,
}

impl prism_rtl::Job<bool> for NamesInited {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let env_p0 = &self.env_p0;
        let e_p1 = &self.e_p1;
        let e_p1x = e_p1.clone();
        let env_p0x = env_p0.clone();
        crate::prelude::call_then(crate::check::typed::print::start_exprs_in_f(e_p1x.clone()), move |exprs_in_f_27763: Array<crate::syntax::Expr>| crate::prelude::call_then(crate::lower::expr::start_read_names_f(exprs_in_f_27763), move |read_names_f_27752: Array<Text>| prism_rtl::Turn::Finished(crate::prelude::fold(&read_names_f_27752, &true, &(|ok_p2: &bool, n_p3: &Text| *ok_p2 && match crate::prelude::get(&env_p0x.names_p, n_p3) {
            Some(crate::lower::types::Bn::BnDyn(_, _, _)) => crate::check::env::has_key_f(&env_p0x.names_p, &Text::from(format!("{}#init", n_p3))),
            Some(crate::lower::types::Bn::BnHold(_, _)) => crate::check::env::has_key_f(&env_p0x.names_p, &Text::from(format!("{}#init", n_p3))),
            _ => true,
        })))))
    }
}

/// `Start NamesInited, x`: what the function value is when passed to `@Run`.
pub fn start_names_inited_f(env_p0: crate::lower::types::Env, e_p1: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(NamesInited { env_p0, e_p1 })
}

/// ```prism
/// PatText: fn Pattern -> Text
/// ```
pub fn pat_text_f(p_p0: &crate::syntax::Pattern_) -> Text {
    match &*p_p0.kind_p {
        crate::syntax::PatternKind::PName(n_p1) => crate::check::env::sname_key_f(n_p1),
        _ => Text::lit("_"),
    }
}

/// ```prism
/// LetLine: unbounded fn Wx, Env, Env, Pattern, Expr -> ((Wx, Env))
/// ```
pub fn let_line_f(wx_p0: &crate::lower::node_::Wx, benv_p1: &crate::lower::types::Env, menv_p2: &crate::lower::types::Env, p_p3: &crate::syntax::Pattern_, e_p4: &crate::syntax::Expr) -> (crate::lower::node_::Wx, crate::lower::types::Env) {
    let lx_p5 = wx_p0.lx_p.clone();
    match binding_of_o(menv_p2, p_p3) {
        Some(crate::lower::types::Bn::BnEv(er_p6, t_p7)) => {
            let (r_pa, wx2_pb) = crate::lower::node_::dynamics::event_ref_f(wx_p0, menv_p2, e_p4);
            let fed_p8 = crate::lower::types::out_ty_of_f(&lx_p5, &crate::lower::types::peel_f(&crate::lower::types::peel_f(&crate::lower::type_at_f(&lx_p5, &e_p4.span_p))));
            let r2_p9 = 'm28639: {
                if let crate::lower::model::OutTy::OutEvent(m28639_0_0) = &t_p7 && let crate::lower::model::OutTy::OutRes(_) = &**m28639_0_0 {
                    break 'm28639 if &fed_p8 == &crate::lower::model::OutTy::OutError {
                        err_pipe_f(&r_pa)
                    } else {
                        r_pa.clone()
                    };
                }
                if let crate::lower::model::OutTy::OutRes(_) = &t_p7 {
                    break 'm28639 if &fed_p8 == &crate::lower::model::OutTy::OutError {
                        err_pipe_f(&r_pa)
                    } else {
                        r_pa.clone()
                    };
                }
                r_pa.clone()
            };
            (crate::lower::node_::connect_f(&wx2_pb, &r2_p9, &crate::lower::node_::Sk::SkNode(er_p6.node_p.clone())), benv_p1.clone())
        },
        Some(crate::lower::types::Bn::BnDyn(_, _, t_pc)) => {
            let rs_pd = crate::lower::snake_f(&pat_text_f(p_p3));
            let (ex_pj, reads_pk) = crate::lower::node_::dynamics::dynamic_expr_f(wx_p0, menv_p2, e_p4);
            let cached_pe = (&crate::prelude::len(&reads_pk) > &Nat::from(0u32)) && crate::prelude::fold(&crate::lower::node_::finish::reads_all_f(&wx_p0.dyn_reads_p, &reads_pk), &true, &(|ok_pl: &bool, r_pm: &crate::lower::node_::Read| *ok_pl && crate::lower::node_::finish::is_own_read_f(r_pm)));
            let tail_pf = if cached_pe {
                crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_cache", &rs_pd)))), Text::lit("get"), Array::from(vec![crate::lower::model::Ex::XCx, crate::lower::model::Ex::XClosure(false, Array::new(), Rc::new(ex_pj.clone()))]))
            } else {
                ex_pj.clone()
            };
            let getter_pg = crate::lower::model::MethDef { name_p: rs_pd.clone(), recv_p: crate::lower::model::Recv::RecvRef, params_p: Array::new(), cx_p: crate::lower::model::CxArg::CxRef, ret_p: t_pc.clone(), body_p: Array::new(), tail_p: tail_pf.clone(), doc_p: Text::from(format!("`{}`", &pat_text_f(p_p3))) };
            let wx1_ph = if cached_pe {
                {
                    let mut this: crate::lower::node_::Wx = crate::lower::node_::add_field_f(wx_p0, &Text::from(format!("{}_cache", &rs_pd)), &crate::lower::model::OutTy::OutNamed(Text::lit("Cache"), Array::from(vec![t_pc.clone()])), &Text::from(format!("`{}`, cached", &pat_text_f(p_p3))), &crate::lower::model::Ex::XCall(Text::lit("Cache::new"), Array::new()));
                    this.let_caches_p = crate::prelude::push(&this.let_caches_p, &rs_pd);
                    this.taken_p = crate::prelude::push(&this.taken_p, &Text::from(format!("{}_cache", &rs_pd)));
                    this
                }
            } else {
                wx_p0.clone()
            };
            let wx2_pi = {
                let mut this: crate::lower::node_::Wx = wx1_ph.clone();
                this.getters_p = crate::prelude::push(&this.getters_p, &getter_pg);
                this.dyn_reads_p = crate::prelude::insert(&this.dyn_reads_p, &rs_pd, &reads_pk);
                this
            };
            if all_inited_f(&wx2_pi, &reads_pk) && names_inited_f(benv_p1, e_p4) {
                {
                    let wx3_pn = {
                        let mut this: crate::lower::node_::Wx = wx2_pi.clone();
                        this.lets_p = crate::prelude::push(&this.lets_p, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaBind(Text::from(format!("{}_init", &rs_pd)))), t_pc.clone()), crate::lower::types::own_f(&crate::lower::expr::value_of_f(&lx_p5, &init_env_f(benv_p1), e_p4))));
                        this.inited_p = crate::prelude::push(&this.inited_p, &rs_pd);
                        this
                    };
                    (wx3_pn.clone(), crate::lower::types::bind_f(benv_p1, &Text::from(format!("{}#init", &pat_text_f(p_p3))), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(Text::from(format!("{}_init", &rs_pd))), crate::lower::types::Holding::Owned, t_pc.clone())))
                }
            } else {
                (wx2_pi.clone(), benv_p1.clone())
            }
        },
        Some(crate::lower::types::Bn::BnLocal(rs_po, _, t_pp)) => {
            let insts_oq = match &*p_p3.kind_p {
                crate::syntax::PatternKind::PName(n_pr) => many_instances_o(&lx_p5, &n_pr.span_p),
                _ => None,
            };
            match &insts_oq {
                Some(insts_ps) => match &*p_p3.kind_p {
                    crate::syntax::PatternKind::PName(n_pt) => {
                        let nkey_pu = crate::check::env::sname_key_f(n_pt);
                        let wxn_pv = crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(insts_ps)), wx_p0.clone(), {
                            let lx_p5x = lx_p5.clone();
                            let insts_psx = insts_ps.clone();
                            let nkey_pux = nkey_pu.clone();
                            let menv_p2x = menv_p2.clone();
                            let benv_p1x = benv_p1.clone();
                            let e_p4x = e_p4.clone();
                            Rc::new(move |(p0, p1): (crate::lower::node_::Wx, Nat)| {
                                let lx_p5xy = lx_p5x.clone();
                                let insts_psxy = insts_psx.clone();
                                let nkey_puxy = nkey_pux.clone();
                                let menv_p2xy = menv_p2x.clone();
                                let benv_p1xy = benv_p1x.clone();
                                let e_p4xy = e_p4x.clone();
                                crate::prelude::entered(crate::prelude::once_job(move || {
                                    let w_p10 = p0;
                                    let k_p11 = p1;
                                    {
                                        let lxk_p12 = crate::lower::expr::at_instance_f(&lx_p5xy, &crate::prelude::or(&crate::prelude::index(&insts_psxy, &k_p11), &(Array::new(), Array::new())));
                                        let bkey_p13 = if &k_p11 == &Nat::from(0u32) {
                                            nkey_puxy.clone()
                                        } else {
                                            Text::from(format!("{}#inst{}", &nkey_puxy, &k_p11))
                                        };
                                        match crate::prelude::get(&menv_p2xy.names_p, &bkey_p13) {
                                            Some(crate::lower::types::Bn::BnLocal(rk_p14, _, tk_p15)) => crate::prelude::call_then(crate::lower::expr::start_value_of_f(lxk_p12.clone(), benv_p1xy.clone(), e_p4xy.clone()), move |value_of_f_31300: crate::lower::types::Vl| prism_rtl::Turn::Finished(widget_let_field_f(&w_p10, &crate::lower::types::place_stem_f(&rk_p14), &tk_p15, &crate::lower::types::own_f(&value_of_f_31300), &Text::from(format!("`{}` at its instantiation {}", &nkey_puxy, &k_p11))))),
                                            _ => prism_rtl::Turn::Finished({
                                                let mut this: crate::lower::node_::Wx = w_p10.clone();
                                                this.build_p = crate::prelude::push(&this.build_p, &crate::lower::expr::refusal_do_f(&Text::from(format!("`{}` at its instantiation {}, which has no binding", &nkey_puxy, &k_p11))));
                                                this
                                            }),
                                        }
                                    }
                                }))
                            }) as Rc<dyn Fn((crate::lower::node_::Wx, Nat)) -> Rc<dyn prism_rtl::Job<crate::lower::node_::Wx>>>
                        }));
                        (wxn_pv.clone(), benv_p1.clone())
                    },
                    _ => (wx_p0.clone(), benv_p1.clone()),
                },
                None => {
                    let lxw_p16 = match &*p_p3.kind_p {
                        crate::syntax::PatternKind::PName(n_p18) => crate::lower::expr::widget_let_lx_f(&lx_p5, &n_p18.span_p),
                        _ => lx_p5.clone(),
                    };
                    let v_p17 = crate::lower::types::own_f(&crate::lower::expr::value_of_f(&lxw_p16, benv_p1, e_p4));
                    (widget_let_field_f(wx_p0, &crate::lower::types::place_stem_f(&rs_po), &t_pp, &v_p17, &Text::from(format!("`{}`", &pat_text_f(p_p3)))), benv_p1.clone())
                },
            }
        },
        _ => (wx_p0.clone(), benv_p1.clone()),
    }
}

/// The step machine of `LetLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LetLine: unbounded fn Wx, Env, Env, Pattern, Expr -> ((Wx, Env))
/// ```
pub struct LetLine {
    pub wx_p0: crate::lower::node_::Wx,
    pub benv_p1: crate::lower::types::Env,
    pub menv_p2: crate::lower::types::Env,
    pub p_p3: crate::syntax::Pattern_,
    pub e_p4: crate::syntax::Expr,
}

impl prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env)> for LetLine {
    fn cycle(&self) -> prism_rtl::Turn<(crate::lower::node_::Wx, crate::lower::types::Env)> {
        let wx_p0 = &self.wx_p0;
        let benv_p1 = &self.benv_p1;
        let menv_p2 = &self.menv_p2;
        let p_p3 = &self.p_p3;
        let e_p4 = &self.e_p4;
        let lx_p5 = wx_p0.lx_p.clone();
        match binding_of_o(menv_p2, p_p3) {
            Some(crate::lower::types::Bn::BnEv(er_p6, t_p7)) => {
                let benv_p1x = benv_p1.clone();
                let e_p4x = e_p4.clone();
                let menv_p2x = menv_p2.clone();
                let wx_p0x = wx_p0.clone();
                crate::prelude::call_then(crate::lower::node_::dynamics::start_event_ref_f(wx_p0x.clone(), menv_p2x.clone(), e_p4x.clone()), move |event_ref_f_28529: (crate::lower::node_::EvRef, crate::lower::node_::Wx)| {
                    let (r_pa, wx2_pb) = event_ref_f_28529;
                    crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p5.clone(), crate::lower::types::peel_f(&crate::lower::types::peel_f(&crate::lower::type_at_f(&lx_p5, &e_p4x.span_p)))), move |out_ty_of_f_28572: crate::lower::model::OutTy| {
                        let fed_p8 = out_ty_of_f_28572;
                        let r2_p9 = 'm28639: {
                            if let crate::lower::model::OutTy::OutEvent(m28639_0_0) = &t_p7 && let crate::lower::model::OutTy::OutRes(_) = &**m28639_0_0 {
                                break 'm28639 if &fed_p8 == &crate::lower::model::OutTy::OutError {
                                    err_pipe_f(&r_pa)
                                } else {
                                    r_pa.clone()
                                };
                            }
                            if let crate::lower::model::OutTy::OutRes(_) = &t_p7 {
                                break 'm28639 if &fed_p8 == &crate::lower::model::OutTy::OutError {
                                    err_pipe_f(&r_pa)
                                } else {
                                    r_pa.clone()
                                };
                            }
                            r_pa.clone()
                        };
                        prism_rtl::Turn::Finished((crate::lower::node_::connect_f(&wx2_pb, &r2_p9, &crate::lower::node_::Sk::SkNode(er_p6.node_p.clone())), benv_p1x.clone()))
                    })
                })
            },
            Some(crate::lower::types::Bn::BnDyn(_, _, t_pc)) => {
                let rs_pd = crate::lower::snake_f(&pat_text_f(p_p3));
                let benv_p1x = benv_p1.clone();
                let e_p4x = e_p4.clone();
                let menv_p2x = menv_p2.clone();
                let p_p3x = p_p3.clone();
                let wx_p0x = wx_p0.clone();
                crate::prelude::call_then(crate::lower::node_::dynamics::start_dynamic_expr_f(wx_p0x.clone(), menv_p2x.clone(), e_p4x.clone()), move |dynamic_expr_f_28992: (crate::lower::model::Ex, Array<crate::lower::node_::Read>)| {
                    let (ex_pj, reads_pk) = dynamic_expr_f_28992;
                    let cached_pe = (&crate::prelude::len(&reads_pk) > &Nat::from(0u32)) && crate::prelude::fold(&crate::lower::node_::finish::reads_all_f(&wx_p0x.dyn_reads_p, &reads_pk), &true, &(|ok_pl: &bool, r_pm: &crate::lower::node_::Read| *ok_pl && crate::lower::node_::finish::is_own_read_f(r_pm)));
                    let tail_pf = if cached_pe {
                        crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_cache", &rs_pd)))), Text::lit("get"), Array::from(vec![crate::lower::model::Ex::XCx, crate::lower::model::Ex::XClosure(false, Array::new(), Rc::new(ex_pj.clone()))]))
                    } else {
                        ex_pj.clone()
                    };
                    let getter_pg = crate::lower::model::MethDef { name_p: rs_pd.clone(), recv_p: crate::lower::model::Recv::RecvRef, params_p: Array::new(), cx_p: crate::lower::model::CxArg::CxRef, ret_p: t_pc.clone(), body_p: Array::new(), tail_p: tail_pf.clone(), doc_p: Text::from(format!("`{}`", &pat_text_f(&p_p3x))) };
                    let wx1_ph = if cached_pe {
                        {
                            let mut this: crate::lower::node_::Wx = crate::lower::node_::add_field_f(&wx_p0x, &Text::from(format!("{}_cache", &rs_pd)), &crate::lower::model::OutTy::OutNamed(Text::lit("Cache"), Array::from(vec![t_pc.clone()])), &Text::from(format!("`{}`, cached", &pat_text_f(&p_p3x))), &crate::lower::model::Ex::XCall(Text::lit("Cache::new"), Array::new()));
                            this.let_caches_p = crate::prelude::push(&this.let_caches_p, &rs_pd);
                            this.taken_p = crate::prelude::push(&this.taken_p, &Text::from(format!("{}_cache", &rs_pd)));
                            this
                        }
                    } else {
                        wx_p0x.clone()
                    };
                    let wx2_pi = {
                        let mut this: crate::lower::node_::Wx = wx1_ph.clone();
                        this.getters_p = crate::prelude::push(&this.getters_p, &getter_pg);
                        this.dyn_reads_p = crate::prelude::insert(&this.dyn_reads_p, &rs_pd, &reads_pk);
                        this
                    };
                    if all_inited_f(&wx2_pi, &reads_pk) && names_inited_f(&benv_p1x, &e_p4x) {
                        {
                            let wx3_pn = {
                                let mut this: crate::lower::node_::Wx = wx2_pi.clone();
                                this.lets_p = crate::prelude::push(&this.lets_p, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaBind(Text::from(format!("{}_init", &rs_pd)))), t_pc.clone()), crate::lower::types::own_f(&crate::lower::expr::value_of_f(&lx_p5, &init_env_f(&benv_p1x), &e_p4x))));
                                this.inited_p = crate::prelude::push(&this.inited_p, &rs_pd);
                                this
                            };
                            prism_rtl::Turn::Finished((wx3_pn.clone(), crate::lower::types::bind_f(&benv_p1x, &Text::from(format!("{}#init", &pat_text_f(&p_p3x))), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(Text::from(format!("{}_init", &rs_pd))), crate::lower::types::Holding::Owned, t_pc.clone()))))
                        }
                    } else {
                        prism_rtl::Turn::Finished((wx2_pi.clone(), benv_p1x.clone()))
                    }
                })
            },
            Some(crate::lower::types::Bn::BnLocal(rs_po, _, t_pp)) => {
                let insts_oq = match &*p_p3.kind_p {
                    crate::syntax::PatternKind::PName(n_pr) => many_instances_o(&lx_p5, &n_pr.span_p),
                    _ => None,
                };
                match &insts_oq {
                    Some(insts_ps) => match &*p_p3.kind_p {
                        crate::syntax::PatternKind::PName(n_pt) => {
                            let nkey_pu = crate::check::env::sname_key_f(n_pt);
                            let benv_p1x = benv_p1.clone();
                            let e_p4x = e_p4.clone();
                            let insts_psx = insts_ps.clone();
                            let menv_p2x = menv_p2.clone();
                            let wx_p0x = wx_p0.clone();
                            crate::prelude::call_value(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(&insts_psx)), wx_p0x.clone(), {
                                let lx_p5x = lx_p5.clone();
                                let insts_psxx = insts_psx.clone();
                                let nkey_pux = nkey_pu.clone();
                                let menv_p2xx = menv_p2x.clone();
                                let benv_p1xx = benv_p1x.clone();
                                let e_p4xx = e_p4x.clone();
                                Rc::new(move |(p0, p1): (crate::lower::node_::Wx, Nat)| {
                                    let lx_p5xy = lx_p5x.clone();
                                    let insts_psxxy = insts_psxx.clone();
                                    let nkey_puxy = nkey_pux.clone();
                                    let menv_p2xxy = menv_p2xx.clone();
                                    let benv_p1xxy = benv_p1xx.clone();
                                    let e_p4xxy = e_p4xx.clone();
                                    crate::prelude::entered(crate::prelude::once_job(move || {
                                        let w_p10 = p0;
                                        let k_p11 = p1;
                                        {
                                            let lxk_p12 = crate::lower::expr::at_instance_f(&lx_p5xy, &crate::prelude::or(&crate::prelude::index(&insts_psxxy, &k_p11), &(Array::new(), Array::new())));
                                            let bkey_p13 = if &k_p11 == &Nat::from(0u32) {
                                                nkey_puxy.clone()
                                            } else {
                                                Text::from(format!("{}#inst{}", &nkey_puxy, &k_p11))
                                            };
                                            match crate::prelude::get(&menv_p2xxy.names_p, &bkey_p13) {
                                                Some(crate::lower::types::Bn::BnLocal(rk_p14, _, tk_p15)) => crate::prelude::call_then(crate::lower::expr::start_value_of_f(lxk_p12.clone(), benv_p1xxy.clone(), e_p4xxy.clone()), move |value_of_f_31300: crate::lower::types::Vl| prism_rtl::Turn::Finished(widget_let_field_f(&w_p10, &crate::lower::types::place_stem_f(&rk_p14), &tk_p15, &crate::lower::types::own_f(&value_of_f_31300), &Text::from(format!("`{}` at its instantiation {}", &nkey_puxy, &k_p11))))),
                                                _ => prism_rtl::Turn::Finished({
                                                    let mut this: crate::lower::node_::Wx = w_p10.clone();
                                                    this.build_p = crate::prelude::push(&this.build_p, &crate::lower::expr::refusal_do_f(&Text::from(format!("`{}` at its instantiation {}, which has no binding", &nkey_puxy, &k_p11))));
                                                    this
                                                }),
                                            }
                                        }
                                    }))
                                }) as Rc<dyn Fn((crate::lower::node_::Wx, Nat)) -> Rc<dyn prism_rtl::Job<crate::lower::node_::Wx>>>
                            }), move |fold_30944: crate::lower::node_::Wx| {
                                let wxn_pv = fold_30944;
                                prism_rtl::Turn::Finished((wxn_pv.clone(), benv_p1x.clone()))
                            })
                        },
                        _ => prism_rtl::Turn::Finished((wx_p0.clone(), benv_p1.clone())),
                    },
                    None => {
                        let lxw_p16 = match &*p_p3.kind_p {
                            crate::syntax::PatternKind::PName(n_p18) => crate::lower::expr::widget_let_lx_f(&lx_p5, &n_p18.span_p),
                            _ => lx_p5.clone(),
                        };
                        let benv_p1x = benv_p1.clone();
                        let e_p4x = e_p4.clone();
                        let p_p3x = p_p3.clone();
                        let wx_p0x = wx_p0.clone();
                        crate::prelude::call_then(crate::lower::expr::start_value_of_f(lxw_p16.clone(), benv_p1x.clone(), e_p4x.clone()), move |value_of_f_31820: crate::lower::types::Vl| {
                            let v_p17 = crate::lower::types::own_f(&value_of_f_31820);
                            prism_rtl::Turn::Finished((widget_let_field_f(&wx_p0x, &crate::lower::types::place_stem_f(&rs_po), &t_pp, &v_p17, &Text::from(format!("`{}`", &pat_text_f(&p_p3x)))), benv_p1x.clone()))
                        })
                    },
                }
            },
            _ => prism_rtl::Turn::Finished((wx_p0.clone(), benv_p1.clone())),
        }
    }
}

/// `Start LetLine, x`: what the function value is when passed to `@Run`.
pub fn start_let_line_f(wx_p0: crate::lower::node_::Wx, benv_p1: crate::lower::types::Env, menv_p2: crate::lower::types::Env, p_p3: crate::syntax::Pattern_, e_p4: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env)>> {
    Rc::new(LetLine { wx_p0, benv_p1, menv_p2, p_p3, e_p4 })
}

/// ```prism
/// WidgetLetField: fn Wx, Text, OutTy, Ex, Text -> Wx
/// ```
pub fn widget_let_field_f(wx_p0: &crate::lower::node_::Wx, f_p1: &Text, t_p2: &crate::lower::model::OutTy, v_p3: &crate::lower::model::Ex, doc_p4: &Text) -> crate::lower::node_::Wx {
    let mut this: crate::lower::node_::Wx = wx_p0.clone();
    this.lets_p = crate::prelude::push(&this.lets_p, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(f_p1.clone()), v_p3.clone()));
    this.fields_p = crate::prelude::push(&this.fields_p, &(f_p1.clone(), t_p2.clone(), doc_p4.clone()));
    this.inits_p = crate::prelude::push(&this.inits_p, &(f_p1.clone(), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(f_p1.clone())))));
    this
}

/// ```prism
/// ErrPipe: fn EvRef -> EvRef
/// ```
pub fn err_pipe_f(r_p0: &crate::lower::node_::EvRef) -> crate::lower::node_::EvRef {
    crate::lower::node_::EvRef { node_p: r_p0.node_p.clone(), owner_p: r_p0.owner_p.clone(), pipe_f: {
        let r_p0x = r_p0.clone();
        Rc::new(move |(p0, p1): (crate::lower::model::Ex, Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>)| {
            let r_p0xy = r_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let x_p1 = p0;
                let k_f2 = p1;
                (&r_p0xy.pipe_f)((x_p1.clone(), {
                    let k_f2x = k_f2.clone();
                    Rc::new(move |p0: crate::lower::model::Ex| {
                        let k_f2xy = k_f2x.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let y_p3 = p0;
                            (&k_f2xy)(crate::lower::model::Ex::XCtor(Text::lit("Err"), Array::from(vec![y_p3.clone()]))).cycle()
                        }))
                    }) as Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>
                })).cycle()
            }))
        }) as Rc<dyn Fn((crate::lower::model::Ex, Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>)) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>
    } }
}

/// ```prism
/// OwnAs: fn OutTy, Vl -> Ex
/// ```
pub fn own_as_f(t_p0: &crate::lower::model::OutTy, v_p1: &crate::lower::types::Vl) -> crate::lower::model::Ex {
    match t_p0 {
        crate::lower::model::OutTy::OutRes(_) => if &crate::lower::types::value_ty_f(v_p1) == &crate::lower::model::OutTy::OutError {
            crate::lower::model::Ex::XCtor(Text::lit("Err"), Array::from(vec![crate::lower::types::own_f(v_p1)]))
        } else {
            crate::lower::types::own_f(v_p1)
        },
        _ => crate::lower::types::own_f(v_p1),
    }
}

/// ```prism
/// BindRes: fn Wx, Env, Pattern, Wres -> Wx
/// ```
pub fn bind_res_f(wx2_p0: &crate::lower::node_::Wx, menv_p1: &crate::lower::types::Env, p_p2: &crate::syntax::Pattern_, res_p3: &crate::lower::node_::Wres) -> crate::lower::node_::Wx {
    match binding_of_o(menv_p1, p_p2) {
        Some(crate::lower::types::Bn::BnEv(er_p4, _)) => match res_p3 {
            crate::lower::node_::Wres::WrEv(r_p5) => if &er_p4.owner_p != &wx2_p0.node_p {
                crate::lower::node_::crossed_f(wx2_p0, &Text::from(format!("the bound event of node `{}` (its graph node {})", &er_p4.owner_p, &er_p4.node_p)))
            } else {
                if &r_p5.node_p == &er_p4.node_p {
                    wx2_p0.clone()
                } else {
                    crate::lower::node_::connect_f(wx2_p0, r_p5, &crate::lower::node_::Sk::SkNode(er_p4.node_p.clone()))
                }
            },
            _ => wx2_p0.clone(),
        },
        _ => wx2_p0.clone(),
    }
}

/// ```prism
/// BuildLine: unbounded fn Wx, Env, Env, Expr, ?Bn -> ((Wx, Wres))
/// ```
pub fn build_line_f(wx_p0: &crate::lower::node_::Wx, benv_p1: &crate::lower::types::Env, menv_p2: &crate::lower::types::Env, e_p3: &crate::syntax::Expr, bound_o4: &Option<crate::lower::types::Bn>) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    let lx_p5 = wx_p0.lx_p.clone();
    let full_p6 = crate::lower::type_at_f(&lx_p5, &e_p3.span_p);
    'm33597: {
        let scrutinee = &*e_p3.kind_p;
        if let crate::syntax::ExprKind::EGroup(x_p7) = scrutinee {
            break 'm33597 build_line_f(wx_p0, benv_p1, menv_p2, &**x_p7, bound_o4);
        }
        if let crate::syntax::ExprKind::EWidgetBlock(b_p8) = scrutinee {
            break 'm33597 crate::lower::node_::static_::inline_block_f(wx_p0, benv_p1, menv_p2, b_p8, &lx_p5);
        }
        if let crate::syntax::ExprKind::EFor(binders_o9, source_pa, body_pb) = scrutinee {
            break 'm33597 crate::lower::node_::keyed::for_line_f(wx_p0, benv_p1, menv_p2, binders_o9, &**source_pa, body_pb, e_p3, bound_o4);
        }
        if let crate::syntax::ExprKind::ERebuild(scrut_pc, body_pd) = scrutinee {
            break 'm33597 crate::lower::node_::switch_::rebuild_line_f(wx_p0, benv_p1, menv_p2, &**scrut_pc, body_pd, e_p3, bound_o4);
        }
        if let crate::syntax::ExprKind::EIf(m33597_4_0, then_b_pf, Some(else_b_pg)) = scrutinee && let crate::syntax::Cond::CondExpr(c_pe) = &**m33597_4_0 {
            break 'm33597 crate::lower::functions::if_gen_line_f(wx_p0, menv_p2, &**c_pe, then_b_pf, else_b_pg, e_p3);
        }
        match crate::lower::types::peel_f(&full_p6) {
            crate::check::types::Ty::TyElem(_, _) => crate::lower::node_::elements::element_line_f(wx_p0, benv_p1, menv_p2, e_p3, bound_o4),
            crate::check::types::Ty::TyAt(_, _) => crate::lower::node_::static_::widget_line_f(wx_p0, benv_p1, menv_p2, e_p3, bound_o4),
            _ => {
                let wx2_ph = {
                    let mut this: crate::lower::node_::Wx = wx_p0.clone();
                    this.build_p = crate::prelude::push(&this.build_p, &crate::lower::expr::refusal_do_f(&Text::lit("a building line this back end does not lower yet")));
                    this
                };
                (wx2_ph.clone(), crate::lower::node_::Wres::WrUnit)
            },
        }
    }
}

/// The step machine of `BuildLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BuildLine: unbounded fn Wx, Env, Env, Expr, ?Bn -> ((Wx, Wres))
/// ```
pub struct BuildLine {
    pub wx_p0: crate::lower::node_::Wx,
    pub benv_p1: crate::lower::types::Env,
    pub menv_p2: crate::lower::types::Env,
    pub e_p3: crate::syntax::Expr,
    pub bound_o4: Option<crate::lower::types::Bn>,
}

impl prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::node_::Wres)> for BuildLine {
    fn cycle(&self) -> prism_rtl::Turn<(crate::lower::node_::Wx, crate::lower::node_::Wres)> {
        let wx_p0 = &self.wx_p0;
        let benv_p1 = &self.benv_p1;
        let menv_p2 = &self.menv_p2;
        let e_p3 = &self.e_p3;
        let bound_o4 = &self.bound_o4;
        let lx_p5 = wx_p0.lx_p.clone();
        let full_p6 = crate::lower::type_at_f(&lx_p5, &e_p3.span_p);
        'm33597: {
            let scrutinee = &*e_p3.kind_p;
            if let crate::syntax::ExprKind::EGroup(x_p7) = scrutinee {
                break 'm33597 prism_rtl::Turn::More(Rc::new(BuildLine { wx_p0: wx_p0.clone(), benv_p1: benv_p1.clone(), menv_p2: menv_p2.clone(), e_p3: (**x_p7).clone(), bound_o4: bound_o4.clone() }));
            }
            if let crate::syntax::ExprKind::EWidgetBlock(b_p8) = scrutinee {
                break 'm33597 prism_rtl::Turn::More(Rc::new(crate::lower::node_::static_::InlineBlock { wx_p0: wx_p0.clone(), benv_p1: benv_p1.clone(), menv_p2: menv_p2.clone(), b_p3: b_p8.clone(), lx_p4: lx_p5.clone() }));
            }
            if let crate::syntax::ExprKind::EFor(binders_o9, source_pa, body_pb) = scrutinee {
                break 'm33597 prism_rtl::Turn::More(Rc::new(crate::lower::node_::keyed::ForLine { wx_p0: wx_p0.clone(), benv_p1: benv_p1.clone(), menv_p2: menv_p2.clone(), binders_o3: binders_o9.clone(), source_p4: (**source_pa).clone(), body_p5: body_pb.clone(), e_p6: e_p3.clone(), bound_o7: bound_o4.clone() }));
            }
            if let crate::syntax::ExprKind::ERebuild(scrut_pc, body_pd) = scrutinee {
                break 'm33597 prism_rtl::Turn::More(Rc::new(crate::lower::node_::switch_::RebuildLine { wx_p0: wx_p0.clone(), benv_p1: benv_p1.clone(), menv_p2: menv_p2.clone(), scrut_p3: (**scrut_pc).clone(), body_p4: body_pd.clone(), e_p5: e_p3.clone(), bound_o6: bound_o4.clone() }));
            }
            if let crate::syntax::ExprKind::EIf(m33597_4_0, then_b_pf, Some(else_b_pg)) = scrutinee && let crate::syntax::Cond::CondExpr(c_pe) = &**m33597_4_0 {
                break 'm33597 prism_rtl::Turn::More(Rc::new(crate::lower::functions::IfGenLine { wx_p0: wx_p0.clone(), menv_p1: menv_p2.clone(), c_p2: (**c_pe).clone(), then_b_p3: then_b_pf.clone(), else_b_p4: else_b_pg.clone(), e_p5: e_p3.clone() }));
            }
            match crate::lower::types::peel_f(&full_p6) {
                crate::check::types::Ty::TyElem(_, _) => prism_rtl::Turn::More(Rc::new(crate::lower::node_::elements::ElementLine { wx_p0: wx_p0.clone(), benv_p1: benv_p1.clone(), menv_p2: menv_p2.clone(), e_p3: e_p3.clone(), bound_o4: bound_o4.clone() })),
                crate::check::types::Ty::TyAt(_, _) => prism_rtl::Turn::More(Rc::new(crate::lower::node_::static_::WidgetLine { wx_p0: wx_p0.clone(), benv_p1: benv_p1.clone(), menv_p2: menv_p2.clone(), e_p3: e_p3.clone(), bound_o4: bound_o4.clone() })),
                _ => {
                    let wx2_ph = {
                        let mut this: crate::lower::node_::Wx = wx_p0.clone();
                        this.build_p = crate::prelude::push(&this.build_p, &crate::lower::expr::refusal_do_f(&Text::lit("a building line this back end does not lower yet")));
                        this
                    };
                    prism_rtl::Turn::Finished((wx2_ph.clone(), crate::lower::node_::Wres::WrUnit))
                },
            }
        }
    }
}

/// `Start BuildLine, x`: what the function value is when passed to `@Run`.
pub fn start_build_line_f(wx_p0: crate::lower::node_::Wx, benv_p1: crate::lower::types::Env, menv_p2: crate::lower::types::Env, e_p3: crate::syntax::Expr, bound_o4: Option<crate::lower::types::Bn>) -> Rc<dyn prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::node_::Wres)>> {
    Rc::new(BuildLine { wx_p0, benv_p1, menv_p2, e_p3, bound_o4 })
}
