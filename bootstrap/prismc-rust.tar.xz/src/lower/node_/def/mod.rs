//! The module `Lower.Node.Def`, from `target/bootstrap/src/prismc/lower/node/def.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// `HowBound`:
///
/// ```prism
/// type HowBound = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum HowBound {
    AsHold,
    AsBind,
    AsLet,
    AsResult,
}

impl Show for HowBound {
    fn show(&self, p: &mut Printer) {
        match self {
            HowBound::AsHold => p.choice("AsHold", &[]),
            HowBound::AsBind => p.choice("AsBind", &[]),
            HowBound::AsLet => p.choice("AsLet", &[]),
            HowBound::AsResult => p.choice("AsResult", &[]),
        }
    }
}

impl ToPod for HowBound {
    fn to_pod(&self) -> Pod {
        match self {
            HowBound::AsHold => Pod::Choice("AsHold".into(), vec![]),
            HowBound::AsBind => Pod::Choice("AsBind".into(), vec![]),
            HowBound::AsLet => Pod::Choice("AsLet".into(), vec![]),
            HowBound::AsResult => Pod::Choice("AsResult".into(), vec![]),
        }
    }
}

impl FromPod for HowBound {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "AsHold" && a.len() == 0 => Ok(HowBound::AsHold),
            Pod::Choice(c, a) if &**c == "AsBind" && a.len() == 0 => Ok(HowBound::AsBind),
            Pod::Choice(c, a) if &**c == "AsLet" && a.len() == 0 => Ok(HowBound::AsLet),
            Pod::Choice(c, a) if &**c == "AsResult" && a.len() == 0 => Ok(HowBound::AsResult),
            other => mismatch("a HowBound", other),
        }
    }
}

/// ```prism
/// NodeDefOf: unbounded fn Lx, Text, [Pattern], Block, Scheme, Bool -> NodeDef
/// ```
pub fn node_def_of(lx_p0: &crate::lower::Lx, qk_p1: &Text, params_p2: &Array<crate::syntax::Pattern_>, body_p3: &crate::syntax::Block, sc_p4: &crate::check::types::Scheme, is_root_p5: &bool) -> crate::lower::model::NodeDef {
    let name_p6 = crate::lower::camel(&crate::check::types::bare_name(qk_p1));
    let ptys_p7 = match &sc_p4.ty {
        crate::check::types::Ty::TyFn(_, ps_pb, _) => ps_pb.clone(),
        _ => Array::new(),
    };
    let wx0_p8 = crate::lower::node_::new_wx(lx_p0, &name_p6, &Array::new(), &Array::new(), &Array::new(), &Array::new(), &Map::new(), &crate::lower::node_::node_hooks(), &Array::new(), &None);
    let (ps_pq, wx1_pr, benv_ps, menv_pt) = run_to_end(fold_job(crate::check::errors::range0(&len(params_p2)), (Array::new(), wx0_p8.clone(), crate::lower::types::empty_env(), crate::lower::types::empty_env()), {
        let params_p2 = params_p2.clone();
        let lx_p0 = lx_p0.clone();
        let ptys_p7 = ptys_p7.clone();
        Rc::new(move |(p0, p1): ((Array<(Text, crate::lower::model::OutTy)>, crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), Nat)| {
            let params_p2 = params_p2.clone();
            let lx_p0 = lx_p0.clone();
            let ptys_p7 = ptys_p7.clone();
            entered(once_job(move || {
                let (acc_pc, w_pd, be_pe, me_pf) = p0;
                let i_pg = p1;
                {
                    let p_ph = or(&index(&params_p2, &i_pg), &crate::lower::patterns::dummy_pat());
                    let nkey_pi = crate::lower::functions::plain_binder(&lx_p0, &p_ph);
                    let base_pj = if &nkey_pi == &Text::lit("") {
                        Text::from(format!("arg{}", &i_pg))
                    } else {
                        crate::lower::snake(&nkey_pi)
                    };
                    let (rs_pm, w2_pn) = crate::lower::node_::fresh_name(&w_pd, &base_pj);
                    call_then(crate::lower::types::start_out_ty_of(lx_p0.clone(), crate::lower::types::peel(&or(&index(&ptys_p7, &i_pg), &crate::check::types::Ty::TyErr))), move |out_ty_of_1975: crate::lower::model::OutTy| {
                        let t_pk = out_ty_of_1975;
                        let w3_pl = {
                            let mut this: crate::lower::node_::Wx = w2_pn.clone();
                            this.fields = push(&this.fields, &(rs_pm.clone(), t_pk.clone(), Text::lit("a parameter")));
                            this.inits = push(&this.inits, &(rs_pm.clone(), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(rs_pm.clone())))));
                            this
                        };
                        let (be2_po, me2_pp) = crate::lower::node_::bind_plain(&be_pe, &me_pf, &nkey_pi, &rs_pm, &t_pk);
                        prism_rtl::Turn::Finished((push(&acc_pc, &(rs_pm.clone(), t_pk.clone())), w3_pl.clone(), be2_po.clone(), me2_pp.clone()))
                    })
                }
            }))
        }) as Rc<dyn Fn(((Array<(Text, crate::lower::model::OutTy)>, crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), Nat)) -> Rc<dyn prism_rtl::Job<(Array<(Text, crate::lower::model::OutTy)>, crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>>>
    }));
    let wx2_p9 = block_into(&wx1_pr, &benv_ps, &menv_pt, body_p3);
    let wx3_pa = if *is_root_p5 { root_result(&wx2_p9) } else { wx2_p9.clone() };
    crate::lower::node_::finish::finish_node(&wx3_pa, qk_p1, &ps_pq, &false)
}

/// The step machine of `NodeDefOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// NodeDefOf: unbounded fn Lx, Text, [Pattern], Block, Scheme, Bool -> NodeDef
/// ```
pub struct NodeDefOf {
    pub lx_p0: crate::lower::Lx,
    pub qk_p1: Text,
    pub params_p2: Array<crate::syntax::Pattern_>,
    pub body_p3: crate::syntax::Block,
    pub sc_p4: crate::check::types::Scheme,
    pub is_root_p5: bool,
}

impl prism_rtl::Job<crate::lower::model::NodeDef> for NodeDefOf {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::NodeDef> {
        let lx_p0 = &self.lx_p0;
        let qk_p1 = &self.qk_p1;
        let params_p2 = &self.params_p2;
        let body_p3 = &self.body_p3;
        let sc_p4 = &self.sc_p4;
        let is_root_p5 = &self.is_root_p5;
        let name_p6 = crate::lower::camel(&crate::check::types::bare_name(qk_p1));
        let ptys_p7 = match &sc_p4.ty {
            crate::check::types::Ty::TyFn(_, ps_pb, _) => ps_pb.clone(),
            _ => Array::new(),
        };
        let wx0_p8 = crate::lower::node_::new_wx(lx_p0, &name_p6, &Array::new(), &Array::new(), &Array::new(), &Array::new(), &Map::new(), &crate::lower::node_::node_hooks(), &Array::new(), &None);
        let body_p3 = body_p3.clone();
        let is_root_p5 = *is_root_p5;
        let lx_p0 = lx_p0.clone();
        let params_p2 = params_p2.clone();
        let qk_p1 = qk_p1.clone();
        call_value(fold_job(crate::check::errors::range0(&len(&params_p2)), (Array::new(), wx0_p8.clone(), crate::lower::types::empty_env(), crate::lower::types::empty_env()), {
            let params_p2 = params_p2.clone();
            let lx_p0 = lx_p0.clone();
            let ptys_p7 = ptys_p7.clone();
            Rc::new(move |(p0, p1): ((Array<(Text, crate::lower::model::OutTy)>, crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), Nat)| {
                let params_p2 = params_p2.clone();
                let lx_p0 = lx_p0.clone();
                let ptys_p7 = ptys_p7.clone();
                entered(once_job(move || {
                    let (acc_pc, w_pd, be_pe, me_pf) = p0;
                    let i_pg = p1;
                    {
                        let p_ph = or(&index(&params_p2, &i_pg), &crate::lower::patterns::dummy_pat());
                        let nkey_pi = crate::lower::functions::plain_binder(&lx_p0, &p_ph);
                        let base_pj = if &nkey_pi == &Text::lit("") {
                            Text::from(format!("arg{}", &i_pg))
                        } else {
                            crate::lower::snake(&nkey_pi)
                        };
                        let (rs_pm, w2_pn) = crate::lower::node_::fresh_name(&w_pd, &base_pj);
                        call_then(crate::lower::types::start_out_ty_of(lx_p0.clone(), crate::lower::types::peel(&or(&index(&ptys_p7, &i_pg), &crate::check::types::Ty::TyErr))), move |out_ty_of_1975: crate::lower::model::OutTy| {
                            let t_pk = out_ty_of_1975;
                            let w3_pl = {
                                let mut this: crate::lower::node_::Wx = w2_pn.clone();
                                this.fields = push(&this.fields, &(rs_pm.clone(), t_pk.clone(), Text::lit("a parameter")));
                                this.inits = push(&this.inits, &(rs_pm.clone(), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(rs_pm.clone())))));
                                this
                            };
                            let (be2_po, me2_pp) = crate::lower::node_::bind_plain(&be_pe, &me_pf, &nkey_pi, &rs_pm, &t_pk);
                            prism_rtl::Turn::Finished((push(&acc_pc, &(rs_pm.clone(), t_pk.clone())), w3_pl.clone(), be2_po.clone(), me2_pp.clone()))
                        })
                    }
                }))
            }) as Rc<dyn Fn(((Array<(Text, crate::lower::model::OutTy)>, crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), Nat)) -> Rc<dyn prism_rtl::Job<(Array<(Text, crate::lower::model::OutTy)>, crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>>>
        }), move |fold_1692: (Array<(Text, crate::lower::model::OutTy)>, crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)| {
            let (ps_pq, wx1_pr, benv_ps, menv_pt) = fold_1692;
            call_then(start_block_into(wx1_pr.clone(), benv_ps.clone(), menv_pt.clone(), body_p3.clone()), move |block_into_2293: crate::lower::node_::Wx| {
                let wx2_p9 = block_into_2293;
                let wx3_pa = if is_root_p5 { root_result(&wx2_p9) } else { wx2_p9.clone() };
                prism_rtl::Turn::More(Rc::new(crate::lower::node_::finish::FinishNode { wx0_p0: wx3_pa.clone(), qk_p1: qk_p1.clone(), params_p2: ps_pq.clone(), is_row_p3: false }))
            })
        })
    }
}

/// `Start NodeDefOf, x`: what the function value is when passed to `@Run`.
pub fn start_node_def_of(lx_p0: crate::lower::Lx, qk_p1: Text, params_p2: Array<crate::syntax::Pattern_>, body_p3: crate::syntax::Block, sc_p4: crate::check::types::Scheme, is_root_p5: bool) -> Rc<dyn prism_rtl::Job<crate::lower::model::NodeDef>> {
    Rc::new(NodeDefOf { lx_p0, qk_p1, params_p2, body_p3, sc_p4, is_root_p5 })
}

/// ```prism
/// RootResult: fn Wx -> Wx
/// ```
pub fn root_result(wx_p0: &crate::lower::node_::Wx) -> crate::lower::node_::Wx {
    match &wx_p0.result {
        crate::lower::node_::Wres::WrEv(r_p1) => crate::lower::node_::connect(wx_p0, r_p1, &crate::lower::node_::Sk::SkResult),
        crate::lower::node_::Wres::WrDyn(x_p2, rds_p3, t_p4) => {
            let mut this: crate::lower::node_::Wx = wx_p0.clone();
            this.root_dyn = Some((x_p2.clone(), rds_p3.clone(), t_p4.clone()));
            this.getters = push(&this.getters, &crate::lower::model::MethDef { name: Text::lit("result_value"), recv: crate::lower::model::Recv::RecvRef, params: Array::new(), cx_: crate::lower::model::CxArg::CxRef, ret: crate::lower::model::OutTy::OutPod, body: Array::new(), tail: crate::lower::model::Ex::XMethod(Rc::new(x_p2.clone()), Text::lit("to_pod"), Array::new()), doc: Text::lit("The root\'s dynamic result, pulled after the tick.") });
            this.fields = push(&this.fields, &(Text::lit("result_last"), crate::lower::model::OutTy::OutCell(Rc::new(crate::lower::model::OutTy::OutOpt(Rc::new(crate::lower::model::OutTy::OutPod)))), Text::lit("the result the World last heard")));
            this.moves = push(&this.moves, &(Text::lit("result_last"), crate::lower::model::Ex::XCall(Text::lit("RefCell::new"), Array::from(vec![crate::lower::model::Ex::XNone]))));
            this.build = push(&this.build, &crate::lower::model::Do::DoScope(crate::lower::node_::finish::result_told(&crate::lower::model::Ex::XVar(Text::lit("node")))));
            this
        },
        crate::lower::node_::Wres::WrPlain(x_p5, _) => {
            let mut this: crate::lower::node_::Wx = wx_p0.clone();
            this.build = push(&this.build, &crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCx), Text::lit("result"), Array::from(vec![crate::lower::model::Ex::XCtor(Text::lit("Outcome::Value"), Array::from(vec![crate::lower::model::Ex::XMethod(Rc::new(x_p5.clone()), Text::lit("to_pod"), Array::new())]))]))));
            this
        },
        crate::lower::node_::Wres::WrParts(_) => {
            let mut this: crate::lower::node_::Wx = wx_p0.clone();
            this.build = push(&this.build, &crate::lower::expr::refusal_do(&Text::lit("a bundle as the root\'s result: a World hears a plain value, a dynamic or an event")));
            this
        },
        _ => wx_p0.clone(),
    }
}

/// ```prism
/// BlockInto: unbounded fn Wx, Env, Env, Block -> Wx
/// ```
pub fn block_into(wx_p0: &crate::lower::node_::Wx, benv_p1: &crate::lower::types::Env, menv_p2: &crate::lower::types::Env, b_p3: &crate::syntax::Block) -> crate::lower::node_::Wx {
    let (wx1_pb, be1_pc, me1_pd) = run_to_end(fold_job(b_p3.stmts.clone(), (wx_p0.clone(), benv_p1.clone(), menv_p2.clone()), Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::syntax::Stmt)| entered(once_job(move || {
        let (w_p7, be_p8, me_p9) = p0;
        let s_pa = p1;
        prism_rtl::Turn::More(Rc::new(PreBind { wx_p0: w_p7.clone(), benv_p1: be_p8.clone(), menv_p2: me_p9.clone(), s_p3: s_pa.clone() }))
    }))) as Rc<dyn Fn(((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>>>));
    let order_p4 = build_order(&b_p3.stmts);
    let (wx2_pk, be2_pl) = run_to_end(fold_job(order_p4.clone(), (wx1_pb.clone(), be1_pc.clone()), {
        let me1_pd = me1_pd.clone();
        let b_p3 = b_p3.clone();
        Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::types::Env), Array<Nat>)| {
            let me1_pd = me1_pd.clone();
            let b_p3 = b_p3.clone();
            entered(once_job(move || {
                let (w_pe, be_pf) = p0;
                let comp_pg = p1;
                fold_job(comp_pg.clone(), (w_pe.clone(), be_pf.clone()), {
                    let me1_pd = me1_pd.clone();
                    let b_p3 = b_p3.clone();
                    Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::types::Env), Nat)| {
                        let me1_pd = me1_pd.clone();
                        let b_p3 = b_p3.clone();
                        entered(once_job(move || {
                            let (w2_ph, be3_pi) = p0;
                            let i_pj = p1;
                            prism_rtl::Turn::More(Rc::new(PreInit { wx_p0: w2_ph.clone(), benv_p1: be3_pi.clone(), menv_p2: me1_pd.clone(), s_p3: or(&index(&b_p3.stmts, &i_pj), &crate::lower::expr::dummy_stmt_l()) }))
                        }))
                    }) as Rc<dyn Fn(((crate::lower::node_::Wx, crate::lower::types::Env), Nat)) -> Rc<dyn prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env)>>>
                }).cycle()
            }))
        }) as Rc<dyn Fn(((crate::lower::node_::Wx, crate::lower::types::Env), Array<Nat>)) -> Rc<dyn prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env)>>>
    }));
    let n_p5 = len(&b_p3.stmts);
    let start_p6 = len(&wx2_pk.lets);
    let (wx3_pu, _, _, ends_pv) = run_to_end(fold_job(crate::check::errors::range0(&n_p5), (wx2_pk.clone(), be2_pl.clone(), me1_pd.clone(), Array::new()), {
        let b_p3 = b_p3.clone();
        let n_p5 = n_p5.clone();
        Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env, Array<Nat>), Nat)| {
            let b_p3 = b_p3.clone();
            let n_p5 = n_p5.clone();
            entered(once_job(move || {
                let (w_pm, be_pn, me_po, acc_pp) = p0;
                let i_pq = p1;
                call_then(start_widget_stmt(w_pm.clone(), be_pn.clone(), me_po.clone(), or(&index(&b_p3.stmts, &i_pq), &crate::lower::expr::dummy_stmt_l()), &(&i_pq + &Nat::from(1u32)) == &n_p5), move |widget_stmt_4499: (crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)| {
                    let (w2_pr, be3_ps, me3_pt) = widget_stmt_4499;
                    prism_rtl::Turn::Finished((w2_pr.clone(), be3_ps.clone(), me3_pt.clone(), push(&acc_pp, &len(&w2_pr.lets))))
                })
            }))
        }) as Rc<dyn Fn(((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env, Array<Nat>), Nat)) -> Rc<dyn prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env, Array<Nat>)>>>
    }));
    build_in_order(&wx3_pu, &b_p3.stmts, &order_p4, &start_p6, &ends_pv)
}

/// The step machine of `BlockInto`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BlockInto: unbounded fn Wx, Env, Env, Block -> Wx
/// ```
pub struct BlockInto {
    pub wx_p0: crate::lower::node_::Wx,
    pub benv_p1: crate::lower::types::Env,
    pub menv_p2: crate::lower::types::Env,
    pub b_p3: crate::syntax::Block,
}

impl prism_rtl::Job<crate::lower::node_::Wx> for BlockInto {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::node_::Wx> {
        let wx_p0 = &self.wx_p0;
        let benv_p1 = &self.benv_p1;
        let menv_p2 = &self.menv_p2;
        let b_p3 = &self.b_p3;
        let b_p3 = b_p3.clone();
        let benv_p1 = benv_p1.clone();
        let menv_p2 = menv_p2.clone();
        let wx_p0 = wx_p0.clone();
        call_value(fold_job(b_p3.stmts.clone(), (wx_p0.clone(), benv_p1.clone(), menv_p2.clone()), Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::syntax::Stmt)| entered(once_job(move || {
            let (w_p7, be_p8, me_p9) = p0;
            let s_pa = p1;
            prism_rtl::Turn::More(Rc::new(PreBind { wx_p0: w_p7.clone(), benv_p1: be_p8.clone(), menv_p2: me_p9.clone(), s_p3: s_pa.clone() }))
        }))) as Rc<dyn Fn(((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>>>), move |fold_4040: (crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)| {
            let (wx1_pb, be1_pc, me1_pd) = fold_4040;
            call_then(start_build_order(b_p3.stmts.clone()), move |build_order_4131: Array<Array<Nat>>| {
                let order_p4 = build_order_4131;
                call_value(fold_job(order_p4.clone(), (wx1_pb.clone(), be1_pc.clone()), {
                    let me1_pd = me1_pd.clone();
                    let b_p3 = b_p3.clone();
                    Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::types::Env), Array<Nat>)| {
                        let me1_pd = me1_pd.clone();
                        let b_p3 = b_p3.clone();
                        entered(once_job(move || {
                            let (w_pe, be_pf) = p0;
                            let comp_pg = p1;
                            fold_job(comp_pg.clone(), (w_pe.clone(), be_pf.clone()), {
                                let me1_pd = me1_pd.clone();
                                let b_p3 = b_p3.clone();
                                Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::types::Env), Nat)| {
                                    let me1_pd = me1_pd.clone();
                                    let b_p3 = b_p3.clone();
                                    entered(once_job(move || {
                                        let (w2_ph, be3_pi) = p0;
                                        let i_pj = p1;
                                        prism_rtl::Turn::More(Rc::new(PreInit { wx_p0: w2_ph.clone(), benv_p1: be3_pi.clone(), menv_p2: me1_pd.clone(), s_p3: or(&index(&b_p3.stmts, &i_pj), &crate::lower::expr::dummy_stmt_l()) }))
                                    }))
                                }) as Rc<dyn Fn(((crate::lower::node_::Wx, crate::lower::types::Env), Nat)) -> Rc<dyn prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env)>>>
                            }).cycle()
                        }))
                    }) as Rc<dyn Fn(((crate::lower::node_::Wx, crate::lower::types::Env), Array<Nat>)) -> Rc<dyn prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env)>>>
                }), move |fold_4173: (crate::lower::node_::Wx, crate::lower::types::Env)| {
                    let (wx2_pk, be2_pl) = fold_4173;
                    let n_p5 = len(&b_p3.stmts);
                    let start_p6 = len(&wx2_pk.lets);
                    call_value(fold_job(crate::check::errors::range0(&n_p5), (wx2_pk.clone(), be2_pl.clone(), me1_pd.clone(), Array::new()), {
                        let b_p3 = b_p3.clone();
                        let n_p5 = n_p5.clone();
                        Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env, Array<Nat>), Nat)| {
                            let b_p3 = b_p3.clone();
                            let n_p5 = n_p5.clone();
                            entered(once_job(move || {
                                let (w_pm, be_pn, me_po, acc_pp) = p0;
                                let i_pq = p1;
                                call_then(start_widget_stmt(w_pm.clone(), be_pn.clone(), me_po.clone(), or(&index(&b_p3.stmts, &i_pq), &crate::lower::expr::dummy_stmt_l()), &(&i_pq + &Nat::from(1u32)) == &n_p5), move |widget_stmt_4499: (crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)| {
                                    let (w2_pr, be3_ps, me3_pt) = widget_stmt_4499;
                                    prism_rtl::Turn::Finished((w2_pr.clone(), be3_ps.clone(), me3_pt.clone(), push(&acc_pp, &len(&w2_pr.lets))))
                                })
                            }))
                        }) as Rc<dyn Fn(((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env, Array<Nat>), Nat)) -> Rc<dyn prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env, Array<Nat>)>>>
                    }), move |fold_4401: (crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env, Array<Nat>)| {
                        let (wx3_pu, _, _, ends_pv) = fold_4401;
                        prism_rtl::Turn::More(Rc::new(BuildInOrder { wx_p0: wx3_pu.clone(), stmts_p1: b_p3.stmts.clone(), order_p2: order_p4.clone(), start_p3: start_p6.clone(), ends_p4: ends_pv.clone() }))
                    })
                })
            })
        })
    }
}

/// `Start BlockInto, x`: what the function value is when passed to `@Run`.
pub fn start_block_into(wx_p0: crate::lower::node_::Wx, benv_p1: crate::lower::types::Env, menv_p2: crate::lower::types::Env, b_p3: crate::syntax::Block) -> Rc<dyn prism_rtl::Job<crate::lower::node_::Wx>> {
    Rc::new(BlockInto { wx_p0, benv_p1, menv_p2, b_p3 })
}

/// ```prism
/// PreInit: unbounded fn Wx, Env, Env, Stmt -> ((Wx, Env))
/// ```
pub fn pre_init(wx_p0: &crate::lower::node_::Wx, benv_p1: &crate::lower::types::Env, menv_p2: &crate::lower::types::Env, s_p3: &crate::syntax::Stmt) -> (crate::lower::node_::Wx, crate::lower::types::Env) {
    match &s_p3.kind {
        crate::syntax::StmtKind::SBind(p_p4, _, Some(_)) => match binding_of(menv_p2, p_p4) {
            Some(crate::lower::types::Bn::BnHold(f_p5, t_p6)) => {
                let wx2_p7 = {
                    let mut this: crate::lower::node_::Wx = wx_p0.clone();
                    this.inited = crate::check::types::add_text(&this.inited, &f_p5);
                    this
                };
                (wx2_p7.clone(), crate::lower::types::bind(benv_p1, &Text::from(format!("{}#init", &pat_text(p_p4))), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(Text::from(format!("{}_init", &f_p5))), crate::lower::types::Holding::Owned, t_p6)))
            },
            _ => (wx_p0.clone(), benv_p1.clone()),
        },
        crate::syntax::StmtKind::SLet(p_p8, _, e_p9) => match binding_of(menv_p2, p_p8) {
            Some(crate::lower::types::Bn::BnDyn(_, _, t_pa)) => {
                let rs_pb = crate::lower::snake(&pat_text(p_p8));
                let (_, reads_pd) = crate::lower::node_::dynamics::dynamic_expr(wx_p0, menv_p2, e_p9);
                let wx2_pc = {
                    let mut this: crate::lower::node_::Wx = wx_p0.clone();
                    this.dyn_reads = insert(&this.dyn_reads, &rs_pb, &reads_pd);
                    this
                };
                if all_inited(&wx2_pc, &reads_pd) && names_inited(benv_p1, e_p9) {
                    {
                        let wx3_pe = {
                            let mut this: crate::lower::node_::Wx = wx2_pc.clone();
                            this.inited = crate::check::types::add_text(&this.inited, &rs_pb);
                            this
                        };
                        (wx3_pe.clone(), crate::lower::types::bind(benv_p1, &Text::from(format!("{}#init", &pat_text(p_p8))), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(Text::from(format!("{}_init", &rs_pb))), crate::lower::types::Holding::Owned, t_pa)))
                    }
                } else {
                    (wx2_pc.clone(), benv_p1.clone())
                }
            },
            _ => (wx_p0.clone(), benv_p1.clone()),
        },
        _ => (wx_p0.clone(), benv_p1.clone()),
    }
}

/// The step machine of `PreInit`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PreInit: unbounded fn Wx, Env, Env, Stmt -> ((Wx, Env))
/// ```
pub struct PreInit {
    pub wx_p0: crate::lower::node_::Wx,
    pub benv_p1: crate::lower::types::Env,
    pub menv_p2: crate::lower::types::Env,
    pub s_p3: crate::syntax::Stmt,
}

impl prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env)> for PreInit {
    fn cycle(&self) -> prism_rtl::Turn<(crate::lower::node_::Wx, crate::lower::types::Env)> {
        let wx_p0 = &self.wx_p0;
        let benv_p1 = &self.benv_p1;
        let menv_p2 = &self.menv_p2;
        let s_p3 = &self.s_p3;
        match &s_p3.kind {
            crate::syntax::StmtKind::SBind(p_p4, _, Some(_)) => match binding_of(menv_p2, p_p4) {
                Some(crate::lower::types::Bn::BnHold(f_p5, t_p6)) => {
                    let wx2_p7 = {
                        let mut this: crate::lower::node_::Wx = wx_p0.clone();
                        this.inited = crate::check::types::add_text(&this.inited, &f_p5);
                        this
                    };
                    prism_rtl::Turn::Finished((wx2_p7.clone(), crate::lower::types::bind(benv_p1, &Text::from(format!("{}#init", &pat_text(p_p4))), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(Text::from(format!("{}_init", &f_p5))), crate::lower::types::Holding::Owned, t_p6.clone()))))
                },
                _ => prism_rtl::Turn::Finished((wx_p0.clone(), benv_p1.clone())),
            },
            crate::syntax::StmtKind::SLet(p_p8, _, e_p9) => match binding_of(menv_p2, p_p8) {
                Some(crate::lower::types::Bn::BnDyn(_, _, t_pa)) => {
                    let rs_pb = crate::lower::snake(&pat_text(p_p8));
                    let benv_p1 = benv_p1.clone();
                    let e_p9 = e_p9.clone();
                    let menv_p2 = menv_p2.clone();
                    let p_p8 = p_p8.clone();
                    let wx_p0 = wx_p0.clone();
                    call_then(crate::lower::node_::dynamics::start_dynamic_expr(wx_p0.clone(), menv_p2.clone(), e_p9.clone()), move |dynamic_expr_5593: (crate::lower::model::Ex, Array<crate::lower::node_::Read>)| {
                        let (_, reads_pd) = dynamic_expr_5593;
                        let wx2_pc = {
                            let mut this: crate::lower::node_::Wx = wx_p0.clone();
                            this.dyn_reads = insert(&this.dyn_reads, &rs_pb, &reads_pd);
                            this
                        };
                        if all_inited(&wx2_pc, &reads_pd) && names_inited(&benv_p1, &e_p9) {
                            {
                                let wx3_pe = {
                                    let mut this: crate::lower::node_::Wx = wx2_pc.clone();
                                    this.inited = crate::check::types::add_text(&this.inited, &rs_pb);
                                    this
                                };
                                prism_rtl::Turn::Finished((wx3_pe.clone(), crate::lower::types::bind(&benv_p1, &Text::from(format!("{}#init", &pat_text(&p_p8))), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(Text::from(format!("{}_init", &rs_pb))), crate::lower::types::Holding::Owned, t_pa.clone()))))
                            }
                        } else {
                            prism_rtl::Turn::Finished((wx2_pc.clone(), benv_p1.clone()))
                        }
                    })
                },
                _ => prism_rtl::Turn::Finished((wx_p0.clone(), benv_p1.clone())),
            },
            _ => prism_rtl::Turn::Finished((wx_p0.clone(), benv_p1.clone())),
        }
    }
}

/// `Start PreInit, x`: what the function value is when passed to `@Run`.
pub fn start_pre_init(wx_p0: crate::lower::node_::Wx, benv_p1: crate::lower::types::Env, menv_p2: crate::lower::types::Env, s_p3: crate::syntax::Stmt) -> Rc<dyn prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env)>> {
    Rc::new(PreInit { wx_p0, benv_p1, menv_p2, s_p3 })
}

/// ```prism
/// BuildInOrder: unbounded fn Wx, [Stmt], [ [Nat] ], Nat, [Nat] -> Wx
/// ```
pub fn build_in_order(wx_p0: &crate::lower::node_::Wx, stmts_p1: &Array<crate::syntax::Stmt>, order_p2: &Array<Array<Nat>>, start_p3: &Nat, ends_p4: &Array<Nat>) -> crate::lower::node_::Wx {
    let n_p5 = len(stmts_p1);
    let last_p6 = or(&index(ends_p4, &crate::syntax::lexer::chars::dec(&n_p5)), start_p3);
    let runs_p7 = each(&crate::check::errors::range0(&n_p5), &(|i_pb: &Nat| {
        let from_pc = if i_pb == &Nat::from(0u32) {
            start_p3.clone()
        } else {
            or(&index(ends_p4, &crate::syntax::lexer::chars::dec(i_pb)), start_p3)
        };
        take(&drop(&wx_p0.lets, &from_pc), &or(&(&or(&index(ends_p4, i_pb), &from_pc)).checked_sub(&from_pc), &Nat::from(0u32)))
    }));
    let lets_p8 = fold(order_p2, &take(&wx_p0.lets, start_p3), &(|acc_pd: &Array<crate::lower::model::Do>, comp_pe: &Array<Nat>| fold(comp_pe, acc_pd, &(|acc2_pf: &Array<crate::lower::model::Do>, i_pg: &Nat| append(acc2_pf, &or(&index(&runs_p7, i_pg), &Array::new()))))));
    let cyclic_p9 = filter(order_p2, &(|comp_ph: &Array<Nat>| (&len(comp_ph) > &Nat::from(1u32)) && fold(comp_ph, &false, &(|seen_pi: &bool, i_pj: &Nat| *seen_pi || (&len(&or(&index(&runs_p7, i_pj), &Array::new())) > &Nat::from(0u32))))));
    let wx2_pa = {
        let mut this: crate::lower::node_::Wx = wx_p0.clone();
        this.lets = append(&lets_p8, &drop(&wx_p0.lets, &last_p6));
        this
    };
    run_to_end(fold_job(cyclic_p9.clone(), wx2_pa.clone(), {
        let stmts_p1 = stmts_p1.clone();
        Rc::new(move |(p0, p1): (crate::lower::node_::Wx, Array<Nat>)| {
            let stmts_p1 = stmts_p1.clone();
            entered(once_job(move || {
                let w_pk = p0;
                let comp_pl = p1;
                prism_rtl::Turn::Finished({
                    let mut this: crate::lower::node_::Wx = w_pk.clone();
                    this.build = push(&this.build, &crate::lower::expr::refusal_do(&Text::from(format!("lines that read each other at the build ({}): a cycle among values", &crate::syntax::lexer::chars::join(&run_to_end(fold_job(comp_pl.clone(), Array::new(), {
                        let stmts_p1 = stmts_p1.clone();
                        Rc::new(move |(p0, p1): (Array<Text>, Nat)| {
                            let stmts_p1 = stmts_p1.clone();
                            entered(once_job(move || {
                                let acc_pm = p0;
                                let i_pn = p1;
                                call_then(crate::check::blocks::start_group_defs(or(&index(&stmts_p1, &i_pn), &crate::lower::expr::dummy_stmt_l())), move |group_defs_7245: Array<Text>| prism_rtl::Turn::Finished(append(&acc_pm, &group_defs_7245)))
                            }))
                        }) as Rc<dyn Fn((Array<Text>, Nat)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
                    })), &Text::lit(", "))))));
                    this
                })
            }))
        }) as Rc<dyn Fn((crate::lower::node_::Wx, Array<Nat>)) -> Rc<dyn prism_rtl::Job<crate::lower::node_::Wx>>>
    }))
}

/// The step machine of `BuildInOrder`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BuildInOrder: unbounded fn Wx, [Stmt], [ [Nat] ], Nat, [Nat] -> Wx
/// ```
pub struct BuildInOrder {
    pub wx_p0: crate::lower::node_::Wx,
    pub stmts_p1: Array<crate::syntax::Stmt>,
    pub order_p2: Array<Array<Nat>>,
    pub start_p3: Nat,
    pub ends_p4: Array<Nat>,
}

impl prism_rtl::Job<crate::lower::node_::Wx> for BuildInOrder {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::node_::Wx> {
        let wx_p0 = &self.wx_p0;
        let stmts_p1 = &self.stmts_p1;
        let order_p2 = &self.order_p2;
        let start_p3 = &self.start_p3;
        let ends_p4 = &self.ends_p4;
        let n_p5 = len(stmts_p1);
        let last_p6 = or(&index(ends_p4, &crate::syntax::lexer::chars::dec(&n_p5)), start_p3);
        let runs_p7 = each(&crate::check::errors::range0(&n_p5), &(|i_pb: &Nat| {
            let from_pc = if i_pb == &Nat::from(0u32) {
                start_p3.clone()
            } else {
                or(&index(ends_p4, &crate::syntax::lexer::chars::dec(i_pb)), start_p3)
            };
            take(&drop(&wx_p0.lets, &from_pc), &or(&(&or(&index(ends_p4, i_pb), &from_pc)).checked_sub(&from_pc), &Nat::from(0u32)))
        }));
        let lets_p8 = fold(order_p2, &take(&wx_p0.lets, start_p3), &(|acc_pd: &Array<crate::lower::model::Do>, comp_pe: &Array<Nat>| fold(comp_pe, acc_pd, &(|acc2_pf: &Array<crate::lower::model::Do>, i_pg: &Nat| append(acc2_pf, &or(&index(&runs_p7, i_pg), &Array::new()))))));
        let cyclic_p9 = filter(order_p2, &(|comp_ph: &Array<Nat>| (&len(comp_ph) > &Nat::from(1u32)) && fold(comp_ph, &false, &(|seen_pi: &bool, i_pj: &Nat| *seen_pi || (&len(&or(&index(&runs_p7, i_pj), &Array::new())) > &Nat::from(0u32))))));
        let wx2_pa = {
            let mut this: crate::lower::node_::Wx = wx_p0.clone();
            this.lets = append(&lets_p8, &drop(&wx_p0.lets, &last_p6));
            this
        };
        fold_job(cyclic_p9.clone(), wx2_pa.clone(), {
            let stmts_p1 = stmts_p1.clone();
            Rc::new(move |(p0, p1): (crate::lower::node_::Wx, Array<Nat>)| {
                let stmts_p1 = stmts_p1.clone();
                entered(once_job(move || {
                    let w_pk = p0;
                    let comp_pl = p1;
                    prism_rtl::Turn::Finished({
                        let mut this: crate::lower::node_::Wx = w_pk.clone();
                        this.build = push(&this.build, &crate::lower::expr::refusal_do(&Text::from(format!("lines that read each other at the build ({}): a cycle among values", &crate::syntax::lexer::chars::join(&run_to_end(fold_job(comp_pl.clone(), Array::new(), {
                            let stmts_p1 = stmts_p1.clone();
                            Rc::new(move |(p0, p1): (Array<Text>, Nat)| {
                                let stmts_p1 = stmts_p1.clone();
                                entered(once_job(move || {
                                    let acc_pm = p0;
                                    let i_pn = p1;
                                    call_then(crate::check::blocks::start_group_defs(or(&index(&stmts_p1, &i_pn), &crate::lower::expr::dummy_stmt_l())), move |group_defs_7245: Array<Text>| prism_rtl::Turn::Finished(append(&acc_pm, &group_defs_7245)))
                                }))
                            }) as Rc<dyn Fn((Array<Text>, Nat)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
                        })), &Text::lit(", "))))));
                        this
                    })
                }))
            }) as Rc<dyn Fn((crate::lower::node_::Wx, Array<Nat>)) -> Rc<dyn prism_rtl::Job<crate::lower::node_::Wx>>>
        }).cycle()
    }
}

/// `Start BuildInOrder, x`: what the function value is when passed to `@Run`.
pub fn start_build_in_order(wx_p0: crate::lower::node_::Wx, stmts_p1: Array<crate::syntax::Stmt>, order_p2: Array<Array<Nat>>, start_p3: Nat, ends_p4: Array<Nat>) -> Rc<dyn prism_rtl::Job<crate::lower::node_::Wx>> {
    Rc::new(BuildInOrder { wx_p0, stmts_p1, order_p2, start_p3, ends_p4 })
}

/// ```prism
/// BuildOrder: unbounded fn [Stmt] -> [ [Nat] ]
/// ```
pub fn build_order(stmts_p0: &Array<crate::syntax::Stmt>) -> Array<Array<Nat>> {
    let n_p1 = len(stmts_p0);
    let defs_p2 = run_to_end(each_job(stmts_p0.clone(), Rc::new(move |p0: crate::syntax::Stmt| entered(once_job(move || {
        let s_p7 = p0;
        call_then(crate::check::blocks::start_group_defs(s_p7.clone()), move |group_defs_7730: Array<Text>| prism_rtl::Turn::Finished(filter(&group_defs_7730, &(|d_p8: &Text| !crate::syntax::lexer::chars::has_prefix(d_p8, &Text::lit("!"))))))
    }))) as Rc<dyn Fn(crate::syntax::Stmt) -> Rc<dyn prism_rtl::Job<Array<Text>>>>));
    let reads_p3 = run_to_end(each_job(stmts_p0.clone(), Rc::new(move |p0: crate::syntax::Stmt| entered(once_job(move || {
        let s_p9 = p0;
        prism_rtl::Turn::More(Rc::new(ReadsAtBuild { s_p0: s_p9.clone() }))
    }))) as Rc<dyn Fn(crate::syntax::Stmt) -> Rc<dyn prism_rtl::Job<Array<Text>>>>));
    let deps_p4 = each(&crate::check::errors::range0(&n_p1), &(|i_pa: &Nat| filter(&crate::check::errors::range0(&n_p1), &(|j_pb: &Nat| (j_pb != i_pa) && fold(&or(&index(&defs_p2, j_pb), &Array::new()), &false, &(|seen_pc: &bool, d_pd: &Text| *seen_pc || crate::check::types::has_text(&or(&index(&reads_p3, i_pa), &Array::new()), d_pd)))))));
    let reach_p5 = run_to_end(each_job(crate::check::errors::range0(&n_p1), {
        let deps_p4 = deps_p4.clone();
        Rc::new(move |p0: Nat| {
            let deps_p4 = deps_p4.clone();
            entered(once_job(move || {
                let i_pe = p0;
                prism_rtl::Turn::More(Rc::new(crate::check::blocks::ReachIdx { deps_p0: deps_p4.clone(), frontier_p1: or(&index(&deps_p4, &i_pe), &Array::new()), seen_p2: Array::new() }))
            }))
        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Array<Nat>>>>
    }));
    let comps_p6 = each(&crate::check::errors::range0(&n_p1), &(|i_pf: &Nat| filter(&crate::check::errors::range0(&n_p1), &(|j_pg: &Nat| (j_pg == i_pf) || (crate::check::types::has_nat(&or(&index(&reach_p5, i_pf), &Array::new()), j_pg) && crate::check::types::has_nat(&or(&index(&reach_p5, j_pg), &Array::new()), i_pf))))));
    crate::check::blocks::emit_groups(&comps_p6, &deps_p4, &Array::new(), &Array::new())
}

/// The step machine of `BuildOrder`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BuildOrder: unbounded fn [Stmt] -> [ [Nat] ]
/// ```
pub struct BuildOrder {
    pub stmts_p0: Array<crate::syntax::Stmt>,
}

impl prism_rtl::Job<Array<Array<Nat>>> for BuildOrder {
    fn cycle(&self) -> prism_rtl::Turn<Array<Array<Nat>>> {
        let stmts_p0 = &self.stmts_p0;
        let n_p1 = len(stmts_p0);
        let stmts_p0 = stmts_p0.clone();
        call_value(each_job(stmts_p0.clone(), Rc::new(move |p0: crate::syntax::Stmt| entered(once_job(move || {
            let s_p7 = p0;
            call_then(crate::check::blocks::start_group_defs(s_p7.clone()), move |group_defs_7730: Array<Text>| prism_rtl::Turn::Finished(filter(&group_defs_7730, &(|d_p8: &Text| !crate::syntax::lexer::chars::has_prefix(d_p8, &Text::lit("!"))))))
        }))) as Rc<dyn Fn(crate::syntax::Stmt) -> Rc<dyn prism_rtl::Job<Array<Text>>>>), move |each_7705: Array<Array<Text>>| {
            let defs_p2 = each_7705;
            call_value(each_job(stmts_p0.clone(), Rc::new(move |p0: crate::syntax::Stmt| entered(once_job(move || {
                let s_p9 = p0;
                prism_rtl::Turn::More(Rc::new(ReadsAtBuild { s_p0: s_p9.clone() }))
            }))) as Rc<dyn Fn(crate::syntax::Stmt) -> Rc<dyn prism_rtl::Job<Array<Text>>>>), move |each_7801: Array<Array<Text>>| {
                let reads_p3 = each_7801;
                let deps_p4 = each(&crate::check::errors::range0(&n_p1), &(|i_pa: &Nat| filter(&crate::check::errors::range0(&n_p1), &(|j_pb: &Nat| (j_pb != i_pa) && fold(&or(&index(&defs_p2, j_pb), &Array::new()), &false, &(|seen_pc: &bool, d_pd: &Text| *seen_pc || crate::check::types::has_text(&or(&index(&reads_p3, i_pa), &Array::new()), d_pd)))))));
                call_value(each_job(crate::check::errors::range0(&n_p1), {
                    let deps_p4 = deps_p4.clone();
                    Rc::new(move |p0: Nat| {
                        let deps_p4 = deps_p4.clone();
                        entered(once_job(move || {
                            let i_pe = p0;
                            prism_rtl::Turn::More(Rc::new(crate::check::blocks::ReachIdx { deps_p0: deps_p4.clone(), frontier_p1: or(&index(&deps_p4, &i_pe), &Array::new()), seen_p2: Array::new() }))
                        }))
                    }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Array<Nat>>>>
                }), move |each_8003: Array<Array<Nat>>| {
                    let reach_p5 = each_8003;
                    let comps_p6 = each(&crate::check::errors::range0(&n_p1), &(|i_pf: &Nat| filter(&crate::check::errors::range0(&n_p1), &(|j_pg: &Nat| (j_pg == i_pf) || (crate::check::types::has_nat(&or(&index(&reach_p5, i_pf), &Array::new()), j_pg) && crate::check::types::has_nat(&or(&index(&reach_p5, j_pg), &Array::new()), i_pf))))));
                    prism_rtl::Turn::More(Rc::new(crate::check::blocks::EmitGroups { comps_p0: comps_p6.clone(), deps_p1: deps_p4.clone(), done_p2: Array::new(), acc_p3: Array::new() }))
                })
            })
        })
    }
}

/// `Start BuildOrder, x`: what the function value is when passed to `@Run`.
pub fn start_build_order(stmts_p0: Array<crate::syntax::Stmt>) -> Rc<dyn prism_rtl::Job<Array<Array<Nat>>>> {
    Rc::new(BuildOrder { stmts_p0 })
}

/// ```prism
/// ReadsAtBuild: unbounded fn Stmt -> [Text]
/// ```
pub fn reads_at_build(s_p0: &crate::syntax::Stmt) -> Array<Text> {
    match &s_p0.kind {
        crate::syntax::StmtKind::SBind(_, init_p1, Some(_)) => crate::lower::expr::free_reads(&crate::check::typed::print::exprs_in(init_p1), &Array::new()),
        crate::syntax::StmtKind::SFn(f_p2) => crate::lower::expr::free_reads(&crate::check::typed::print::stmt_exprs(s_p0), &Array::from(vec![(run_to_end(fold_job(f_p2.params.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Pattern_)| entered(once_job(move || {
            let acc_p3 = p0;
            let q_p4 = p1;
            call_then(crate::check::env::names::start_pattern_names(q_p4.clone()), move |pattern_names_8794: Array<Text>| prism_rtl::Turn::Finished(append(&acc_p3, &pattern_names_8794)))
        }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Pattern_)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>)), f_p2.span.clone())])),
        _ => crate::lower::expr::free_reads(&crate::check::typed::print::stmt_exprs(s_p0), &Array::new()),
    }
}

/// The step machine of `ReadsAtBuild`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ReadsAtBuild: unbounded fn Stmt -> [Text]
/// ```
pub struct ReadsAtBuild {
    pub s_p0: crate::syntax::Stmt,
}

impl prism_rtl::Job<Array<Text>> for ReadsAtBuild {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let s_p0 = &self.s_p0;
        match &s_p0.kind {
            crate::syntax::StmtKind::SBind(_, init_p1, Some(_)) => {
                let init_p1 = init_p1.clone();
                call_then(crate::check::typed::print::start_exprs_in(init_p1.clone()), move |exprs_in_8689: Array<crate::syntax::Expr>| prism_rtl::Turn::More(Rc::new(crate::lower::expr::FreeReads { es_p0: exprs_in_8689, outer_p1: Array::new() })))
            },
            crate::syntax::StmtKind::SFn(f_p2) => {
                let f_p2 = f_p2.clone();
                let s_p0 = s_p0.clone();
                call_then(crate::check::typed::print::start_stmt_exprs(s_p0.clone()), move |stmt_exprs_8731: Array<crate::syntax::Expr>| call_value(fold_job(f_p2.params.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::Pattern_)| entered(once_job(move || {
                    let acc_p3 = p0;
                    let q_p4 = p1;
                    call_then(crate::check::env::names::start_pattern_names(q_p4.clone()), move |pattern_names_8794: Array<Text>| prism_rtl::Turn::Finished(append(&acc_p3, &pattern_names_8794)))
                }))) as Rc<dyn Fn((Array<Text>, crate::syntax::Pattern_)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>), move |fold_8750: Array<Text>| prism_rtl::Turn::More(Rc::new(crate::lower::expr::FreeReads { es_p0: stmt_exprs_8731, outer_p1: Array::from(vec![(fold_8750, f_p2.span.clone())]) }))))
            },
            _ => {
                let s_p0 = s_p0.clone();
                call_then(crate::check::typed::print::start_stmt_exprs(s_p0.clone()), move |stmt_exprs_8849: Array<crate::syntax::Expr>| prism_rtl::Turn::More(Rc::new(crate::lower::expr::FreeReads { es_p0: stmt_exprs_8849, outer_p1: Array::new() })))
            },
        }
    }
}

/// `Start ReadsAtBuild, x`: what the function value is when passed to `@Run`.
pub fn start_reads_at_build(s_p0: crate::syntax::Stmt) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(ReadsAtBuild { s_p0 })
}

/// ```prism
/// PreBind: unbounded fn Wx, Env, Env, Stmt -> ((Wx, Env, Env))
/// ```
pub fn pre_bind(wx_p0: &crate::lower::node_::Wx, benv_p1: &crate::lower::types::Env, menv_p2: &crate::lower::types::Env, s_p3: &crate::syntax::Stmt) -> (crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env) {
    match &s_p3.kind {
        crate::syntax::StmtKind::SBind(p_p4, init_p5, step_o6) => {
            let how_p7 = if (step_o6 == &None) && gives_result(&wx_p0.lx, menv_p2, init_p5) {
                HowBound::AsResult
            } else {
                how_bound(step_o6)
            };
            match &*p_p4.kind {
                crate::syntax::PatternKind::PName(n_p8) => pre_bind_name(wx_p0, benv_p1, menv_p2, n_p8, &how_p7),
                crate::syntax::PatternKind::PTuple(ps_p9) => run_to_end(fold_job(ps_p9.clone(), (wx_p0.clone(), benv_p1.clone(), menv_p2.clone()), {
                    let how_p7 = how_p7.clone();
                    Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::syntax::Pattern_)| {
                        let how_p7 = how_p7.clone();
                        entered(once_job(move || {
                            let (w_pa, be_pb, me_pc) = p0;
                            let q_pd = p1;
                            match &*q_pd.kind {
                                crate::syntax::PatternKind::PName(n_pe) => prism_rtl::Turn::More(Rc::new(PreBindName { wx_p0: w_pa.clone(), benv_p1: be_pb.clone(), menv_p2: me_pc.clone(), n_p3: n_pe.clone(), how_p4: how_p7.clone() })),
                                _ => prism_rtl::Turn::Finished((w_pa.clone(), be_pb.clone(), me_pc.clone())),
                            }
                        }))
                    }) as Rc<dyn Fn(((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::syntax::Pattern_)) -> Rc<dyn prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>>>
                })),
                _ => (wx_p0.clone(), benv_p1.clone(), menv_p2.clone()),
            }
        },
        crate::syntax::StmtKind::SLet(p_pf, _, _) => match &*p_pf.kind {
            crate::syntax::PatternKind::PName(n_pg) => pre_bind_name(wx_p0, benv_p1, menv_p2, n_pg, &HowBound::AsLet),
            _ => (wx_p0.clone(), benv_p1.clone(), menv_p2.clone()),
        },
        crate::syntax::StmtKind::SFn(c_ph) => {
            let fname_pi = crate::check::env::def_name_text(&c_ph.name);
            (wx_p0.clone(), crate::lower::types::bind(benv_p1, &fname_pi, &crate::lower::types::Bn::BnLocalFn(c_ph.clone())), crate::lower::types::bind(menv_p2, &fname_pi, &crate::lower::types::Bn::BnLocalFn(c_ph.clone())))
        },
        _ => (wx_p0.clone(), benv_p1.clone(), menv_p2.clone()),
    }
}

/// The step machine of `PreBind`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PreBind: unbounded fn Wx, Env, Env, Stmt -> ((Wx, Env, Env))
/// ```
pub struct PreBind {
    pub wx_p0: crate::lower::node_::Wx,
    pub benv_p1: crate::lower::types::Env,
    pub menv_p2: crate::lower::types::Env,
    pub s_p3: crate::syntax::Stmt,
}

impl prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)> for PreBind {
    fn cycle(&self) -> prism_rtl::Turn<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)> {
        let wx_p0 = &self.wx_p0;
        let benv_p1 = &self.benv_p1;
        let menv_p2 = &self.menv_p2;
        let s_p3 = &self.s_p3;
        match &s_p3.kind {
            crate::syntax::StmtKind::SBind(p_p4, init_p5, step_o6) => {
                let how_p7 = if (step_o6 == &None) && gives_result(&wx_p0.lx, menv_p2, init_p5) {
                    HowBound::AsResult
                } else {
                    how_bound(step_o6)
                };
                match &*p_p4.kind {
                    crate::syntax::PatternKind::PName(n_p8) => prism_rtl::Turn::More(Rc::new(PreBindName { wx_p0: wx_p0.clone(), benv_p1: benv_p1.clone(), menv_p2: menv_p2.clone(), n_p3: n_p8.clone(), how_p4: how_p7.clone() })),
                    crate::syntax::PatternKind::PTuple(ps_p9) => fold_job(ps_p9.clone(), (wx_p0.clone(), benv_p1.clone(), menv_p2.clone()), {
                        let how_p7 = how_p7.clone();
                        Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::syntax::Pattern_)| {
                            let how_p7 = how_p7.clone();
                            entered(once_job(move || {
                                let (w_pa, be_pb, me_pc) = p0;
                                let q_pd = p1;
                                match &*q_pd.kind {
                                    crate::syntax::PatternKind::PName(n_pe) => prism_rtl::Turn::More(Rc::new(PreBindName { wx_p0: w_pa.clone(), benv_p1: be_pb.clone(), menv_p2: me_pc.clone(), n_p3: n_pe.clone(), how_p4: how_p7.clone() })),
                                    _ => prism_rtl::Turn::Finished((w_pa.clone(), be_pb.clone(), me_pc.clone())),
                                }
                            }))
                        }) as Rc<dyn Fn(((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::syntax::Pattern_)) -> Rc<dyn prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>>>
                    }).cycle(),
                    _ => prism_rtl::Turn::Finished((wx_p0.clone(), benv_p1.clone(), menv_p2.clone())),
                }
            },
            crate::syntax::StmtKind::SLet(p_pf, _, _) => match &*p_pf.kind {
                crate::syntax::PatternKind::PName(n_pg) => prism_rtl::Turn::More(Rc::new(PreBindName { wx_p0: wx_p0.clone(), benv_p1: benv_p1.clone(), menv_p2: menv_p2.clone(), n_p3: n_pg.clone(), how_p4: HowBound::AsLet })),
                _ => prism_rtl::Turn::Finished((wx_p0.clone(), benv_p1.clone(), menv_p2.clone())),
            },
            crate::syntax::StmtKind::SFn(c_ph) => {
                let fname_pi = crate::check::env::def_name_text(&c_ph.name);
                prism_rtl::Turn::Finished((wx_p0.clone(), crate::lower::types::bind(benv_p1, &fname_pi, &crate::lower::types::Bn::BnLocalFn(c_ph.clone())), crate::lower::types::bind(menv_p2, &fname_pi, &crate::lower::types::Bn::BnLocalFn(c_ph.clone()))))
            },
            _ => prism_rtl::Turn::Finished((wx_p0.clone(), benv_p1.clone(), menv_p2.clone())),
        }
    }
}

/// `Start PreBind, x`: what the function value is when passed to `@Run`.
pub fn start_pre_bind(wx_p0: crate::lower::node_::Wx, benv_p1: crate::lower::types::Env, menv_p2: crate::lower::types::Env, s_p3: crate::syntax::Stmt) -> Rc<dyn prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>> {
    Rc::new(PreBind { wx_p0, benv_p1, menv_p2, s_p3 })
}

/// ```prism
/// GivesResult: unbounded fn Lx, Env, Expr -> Bool
/// ```
pub fn gives_result(lx_p0: &crate::lower::Lx, menv_p1: &crate::lower::types::Env, e_p2: &crate::syntax::Expr) -> bool {
    match &*e_p2.kind {
        crate::syntax::ExprKind::EGroup(x_p3) => gives_result(lx_p0, menv_p1, &**x_p3),
        crate::syntax::ExprKind::EWidgetBlock(_) => true,
        _ => {
            let callee_p4 = match &*e_p2.kind {
                crate::syntax::ExprKind::ECall(c_p5, _, _, _) => (**c_p5).clone(),
                _ => e_p2.clone(),
            };
            match &*callee_p4.kind {
                crate::syntax::ExprKind::EName(n_p6) => match get(&menv_p1.names, &crate::check::env::sname_key(n_p6)) {
                    Some(crate::lower::types::Bn::BnWidget(_, _, _, _)) => true,
                    _ => {
                        let (q_o7, _) = crate::check::env::names::resolve_value(&lx_p0.g, &lx_p0.home, n_p6);
                        match &q_o7 {
                            Some(q_p8) => is_getter_builtin(q_p8) || ((!is_prelude_name(q_p8) && (&get(&lx_p0.g.vals, q_p8) != &None)) && is_widget_ty(&crate::lower::types::peel(&crate::lower::type_at(lx_p0, &e_p2.span)))),
                            None => false,
                        }
                    },
                },
                _ => false,
            }
        },
    }
}

/// The step machine of `GivesResult`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// GivesResult: unbounded fn Lx, Env, Expr -> Bool
/// ```
pub struct GivesResult {
    pub lx_p0: crate::lower::Lx,
    pub menv_p1: crate::lower::types::Env,
    pub e_p2: crate::syntax::Expr,
}

impl prism_rtl::Job<bool> for GivesResult {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let lx_p0 = &self.lx_p0;
        let menv_p1 = &self.menv_p1;
        let e_p2 = &self.e_p2;
        match &*e_p2.kind {
            crate::syntax::ExprKind::EGroup(x_p3) => prism_rtl::Turn::More(Rc::new(GivesResult { lx_p0: lx_p0.clone(), menv_p1: menv_p1.clone(), e_p2: (**x_p3).clone() })),
            crate::syntax::ExprKind::EWidgetBlock(_) => prism_rtl::Turn::Finished(true),
            _ => {
                let callee_p4 = match &*e_p2.kind {
                    crate::syntax::ExprKind::ECall(c_p5, _, _, _) => (**c_p5).clone(),
                    _ => e_p2.clone(),
                };
                match &*callee_p4.kind {
                    crate::syntax::ExprKind::EName(n_p6) => match get(&menv_p1.names, &crate::check::env::sname_key(n_p6)) {
                        Some(crate::lower::types::Bn::BnWidget(_, _, _, _)) => prism_rtl::Turn::Finished(true),
                        _ => {
                            let (q_o7, _) = crate::check::env::names::resolve_value(&lx_p0.g, &lx_p0.home, n_p6);
                            match &q_o7 {
                                Some(q_p8) => prism_rtl::Turn::Finished(is_getter_builtin(q_p8) || ((!is_prelude_name(q_p8) && (&get(&lx_p0.g.vals, q_p8) != &None)) && is_widget_ty(&crate::lower::types::peel(&crate::lower::type_at(lx_p0, &e_p2.span))))),
                                None => prism_rtl::Turn::Finished(false),
                            }
                        },
                    },
                    _ => prism_rtl::Turn::Finished(false),
                }
            },
        }
    }
}

/// `Start GivesResult, x`: what the function value is when passed to `@Run`.
pub fn start_gives_result(lx_p0: crate::lower::Lx, menv_p1: crate::lower::types::Env, e_p2: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(GivesResult { lx_p0, menv_p1, e_p2 })
}

/// ```prism
/// IsPreludeName: fn Text -> Bool
/// ```
pub fn is_prelude_name(q_p0: &Text) -> bool {
    &find(&{ thread_local!(static R: Regex = Regex::lit("^Prelude\\.", "")); R.with(Regex::clone) }, q_p0) != &None
}

/// ```prism
/// IsGetterBuiltin: fn Text -> Bool
/// ```
pub fn is_getter_builtin(q_p0: &Text) -> bool {
    ((q_p0 == &Text::lit("Prelude.@Distinct")) || (q_p0 == &Text::lit("Prelude.@PerKey"))) || (q_p0 == &Text::lit("Prelude.@Flatten"))
}

/// ```prism
/// IsWidgetTy: fn Ty -> Bool
/// ```
pub fn is_widget_ty(t_p0: &crate::check::types::Ty) -> bool {
    match t_p0 {
        crate::check::types::Ty::TyAt(_, _) => true,
        _ => false,
    }
}

/// ```prism
/// HowBound: fn ?Expr -> HowBound
/// ```
pub fn how_bound(opt0: &Option<crate::syntax::Expr>) -> HowBound {
    match opt0 {
        Some(_) => HowBound::AsHold,
        None => HowBound::AsBind,
    }
}

/// ```prism
/// PreBindName: unbounded fn Wx, Env, Env, SName, HowBound -> ((Wx, Env, Env))
/// ```
pub fn pre_bind_name(wx_p0: &crate::lower::node_::Wx, benv_p1: &crate::lower::types::Env, menv_p2: &crate::lower::types::Env, n_p3: &crate::syntax::SName, how_p4: &HowBound) -> (crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env) {
    let lx_p5 = crate::lower::expr::widget_let_lx(&wx_p0.lx, &n_p3.span);
    let nkey_p6 = crate::check::env::sname_key(n_p3);
    let full_p7 = crate::lower::binder_ty(&lx_p5, &n_p3.span);
    let layer_p8 = crate::lower::types::layer_of(&full_p7);
    let t_p9 = crate::lower::types::out_ty_of(&lx_p5, &crate::lower::types::peel(&full_p7));
    let (rs_pa, wx1_pb) = crate::lower::node_::fresh_name(wx_p0, &crate::lower::snake(&nkey_p6));
    if ((how_p4 == &HowBound::AsBind) || (how_p4 == &HowBound::AsResult)) && crate::lower::types::is_bundle(&full_p7) {
        (wx_p0.clone(), benv_p1.clone(), menv_p2.clone())
    } else {
        if (&layer_p8 == &crate::lower::types::Layer::LyEv) || is_switched(&full_p7) {
            {
                let et_pc = crate::lower::types::out_ty_of(&lx_p5, &crate::lower::types::peel(&crate::lower::types::peel(&full_p7)));
                let (id_pj, wx2_pk) = crate::lower::node_::add_gn(&wx1_pb, &rs_pa, &et_pc, &crate::lower::node_::GnKind::GnNamed, &Nat::from(0u32));
                let b_pd = crate::lower::types::Bn::BnEv(crate::lower::node_::ev_ref_of(&wx2_pk, &id_pj), t_p9.clone());
                let pf_pe = Text::from(format!("{}_v_port", &rs_pa));
                let pt_pf = crate::lower::model::OutTy::OutRc(Rc::new(crate::lower::model::OutTy::OutPort(Rc::new(et_pc.clone()))));
                let wx3_pg = {
                    let mut this: crate::lower::node_::Wx = crate::lower::node_::connect(&wx2_pk, &crate::lower::node_::ev_ref_of(&wx2_pk, &id_pj), &crate::lower::node_::Sk::SkPort(Text::from(format!("{}_v", &rs_pa))));
                    this.lets = push(&this.lets, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaBind(pf_pe.clone())), pt_pf.clone()), crate::lower::model::Ex::XCall(Text::lit("Rc::new"), Array::from(vec![crate::lower::model::Ex::XCall(Text::lit("Port::new"), Array::new())]))));
                    this.fields = push(&this.fields, &(pf_pe.clone(), pt_pf.clone(), Text::from(format!("`{}` as a value: the port it fires", &nkey_p6))));
                    this.moves = push(&this.moves, &(pf_pe.clone(), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(pf_pe.clone())))));
                    this
                };
                let be_ph = crate::lower::types::bind(&crate::lower::types::bind(benv_p1, &nkey_p6, &b_pd), &Text::from(format!("{}#port", &nkey_p6)), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(pf_pe.clone()), crate::lower::types::Holding::Owned, pt_pf.clone()));
                let me_pi = crate::lower::types::bind(&crate::lower::types::bind(menv_p2, &nkey_p6, &b_pd), &Text::from(format!("{}#port", &nkey_p6)), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), pf_pe.clone()), crate::lower::types::Holding::Owned, pt_pf.clone()));
                (wx3_pg.clone(), be_ph.clone(), me_pi.clone())
            }
        } else {
            match (layer_p8.clone(), how_p4.clone()) {
                (crate::lower::types::Layer::LyDyn, HowBound::AsLet) => {
                    let b_pl = crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XSelf), rs_pa.clone(), Array::from(vec![crate::lower::model::Ex::XCx])), Array::from(vec![crate::lower::node_::Read::OwnRead(rs_pa.clone())]), t_p9.clone());
                    (wx1_pb.clone(), crate::lower::types::bind(benv_p1, &nkey_p6, &b_pl), crate::lower::types::bind(menv_p2, &nkey_p6, &b_pl))
                },
                (crate::lower::types::Layer::LyDyn, HowBound::AsResult) => {
                    let b_pm = crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XSelf), rs_pa.clone(), Array::from(vec![crate::lower::model::Ex::XCx])), Array::from(vec![crate::lower::node_::Read::OwnRead(rs_pa.clone())]), t_p9.clone());
                    (wx1_pb.clone(), crate::lower::types::bind(benv_p1, &nkey_p6, &b_pm), crate::lower::types::bind(menv_p2, &nkey_p6, &b_pm))
                },
                (crate::lower::types::Layer::LyDyn, _) => {
                    let b_pn = crate::lower::types::Bn::BnHold(rs_pa.clone(), t_p9.clone());
                    (wx1_pb.clone(), crate::lower::types::bind(benv_p1, &nkey_p6, &b_pn), crate::lower::types::bind(menv_p2, &nkey_p6, &b_pn))
                },
                _ => match many_instances(&wx_p0.lx, &n_p3.span) {
                    Some(insts_po) => run_to_end(fold_job(crate::check::errors::range0(&len(&insts_po)), (wx1_pb.clone(), benv_p1.clone(), menv_p2.clone()), {
                        let insts_po = insts_po.clone();
                        let wx_p0 = wx_p0.clone();
                        let n_p3 = n_p3.clone();
                        let rs_pa = rs_pa.clone();
                        let nkey_p6 = nkey_p6.clone();
                        Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), Nat)| {
                            let insts_po = insts_po.clone();
                            let wx_p0 = wx_p0.clone();
                            let n_p3 = n_p3.clone();
                            let rs_pa = rs_pa.clone();
                            let nkey_p6 = nkey_p6.clone();
                            entered(once_job(move || {
                                let (w_pp, be_pq, me_pr) = p0;
                                let k_ps = p1;
                                {
                                    let inst_pt = or(&index(&insts_po, &k_ps), &(Array::new(), Array::new()));
                                    let lxk_pu = crate::lower::expr::at_instance(&wx_p0.lx, &inst_pt);
                                    call_then(crate::lower::types::start_out_ty_of(lxk_pu.clone(), crate::lower::types::peel(&crate::lower::binder_ty(&lxk_pu, &n_p3.span))), move |out_ty_of_14418: crate::lower::model::OutTy| {
                                        let tk_pv = out_ty_of_14418;
                                        let (rk_p12, w2_p13) = if &k_ps == &Nat::from(0u32) {
                                            (rs_pa.clone(), w_pp.clone())
                                        } else {
                                            crate::lower::node_::fresh_name(&w_pp, &Text::from(format!("{}_{}", &rs_pa, &k_ps)))
                                        };
                                        let bkey_p10 = if &k_ps == &Nat::from(0u32) {
                                            nkey_p6.clone()
                                        } else {
                                            Text::from(format!("{}#inst{}", &nkey_p6, &k_ps))
                                        };
                                        let (be2_p14, me2_p15) = crate::lower::node_::bind_plain(&be_pq, &me_pr, &bkey_p10, &rk_p12, &tk_pv);
                                        let ukey_p11 = Text::from(format!("{}#{}", &nkey_p6, &show_text(&inst_pt)));
                                        prism_rtl::Turn::Finished((w2_p13.clone(), with_use(&be2_p14, &ukey_p11, &bkey_p10), with_use(&me2_p15, &ukey_p11, &bkey_p10)))
                                    })
                                }
                            }))
                        }) as Rc<dyn Fn(((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), Nat)) -> Rc<dyn prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>>>
                    })),
                    None => {
                        let (be_p16, me_p17) = crate::lower::node_::bind_plain(benv_p1, menv_p2, &nkey_p6, &rs_pa, &t_p9);
                        (wx1_pb.clone(), be_p16.clone(), me_p17.clone())
                    },
                },
            }
        }
    }
}

/// The step machine of `PreBindName`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PreBindName: unbounded fn Wx, Env, Env, SName, HowBound -> ((Wx, Env, Env))
/// ```
pub struct PreBindName {
    pub wx_p0: crate::lower::node_::Wx,
    pub benv_p1: crate::lower::types::Env,
    pub menv_p2: crate::lower::types::Env,
    pub n_p3: crate::syntax::SName,
    pub how_p4: HowBound,
}

impl prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)> for PreBindName {
    fn cycle(&self) -> prism_rtl::Turn<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)> {
        let wx_p0 = &self.wx_p0;
        let benv_p1 = &self.benv_p1;
        let menv_p2 = &self.menv_p2;
        let n_p3 = &self.n_p3;
        let how_p4 = &self.how_p4;
        let benv_p1 = benv_p1.clone();
        let how_p4 = how_p4.clone();
        let menv_p2 = menv_p2.clone();
        let n_p3 = n_p3.clone();
        let wx_p0 = wx_p0.clone();
        call_then(crate::lower::expr::start_widget_let_lx(wx_p0.lx.clone(), n_p3.span.clone()), move |widget_let_lx_12007: crate::lower::Lx| {
            let lx_p5 = widget_let_lx_12007;
            let nkey_p6 = crate::check::env::sname_key(&n_p3);
            let full_p7 = crate::lower::binder_ty(&lx_p5, &n_p3.span);
            let layer_p8 = crate::lower::types::layer_of(&full_p7);
            call_then(crate::lower::types::start_out_ty_of(lx_p5.clone(), crate::lower::types::peel(&full_p7)), move |out_ty_of_12135: crate::lower::model::OutTy| {
                let t_p9 = out_ty_of_12135;
                let (rs_pa, wx1_pb) = crate::lower::node_::fresh_name(&wx_p0, &crate::lower::snake(&nkey_p6));
                if ((&how_p4 == &HowBound::AsBind) || (&how_p4 == &HowBound::AsResult)) && crate::lower::types::is_bundle(&full_p7) {
                    prism_rtl::Turn::Finished((wx_p0.clone(), benv_p1.clone(), menv_p2.clone()))
                } else {
                    if (&layer_p8 == &crate::lower::types::Layer::LyEv) || is_switched(&full_p7) {
                        call_then(crate::lower::types::start_out_ty_of(lx_p5.clone(), crate::lower::types::peel(&crate::lower::types::peel(&full_p7))), move |out_ty_of_12493: crate::lower::model::OutTy| {
                            let et_pc = out_ty_of_12493;
                            let (id_pj, wx2_pk) = crate::lower::node_::add_gn(&wx1_pb, &rs_pa, &et_pc, &crate::lower::node_::GnKind::GnNamed, &Nat::from(0u32));
                            let b_pd = crate::lower::types::Bn::BnEv(crate::lower::node_::ev_ref_of(&wx2_pk, &id_pj), t_p9.clone());
                            let pf_pe = Text::from(format!("{}_v_port", &rs_pa));
                            let pt_pf = crate::lower::model::OutTy::OutRc(Rc::new(crate::lower::model::OutTy::OutPort(Rc::new(et_pc.clone()))));
                            let wx3_pg = {
                                let mut this: crate::lower::node_::Wx = crate::lower::node_::connect(&wx2_pk, &crate::lower::node_::ev_ref_of(&wx2_pk, &id_pj), &crate::lower::node_::Sk::SkPort(Text::from(format!("{}_v", &rs_pa))));
                                this.lets = push(&this.lets, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaBind(pf_pe.clone())), pt_pf.clone()), crate::lower::model::Ex::XCall(Text::lit("Rc::new"), Array::from(vec![crate::lower::model::Ex::XCall(Text::lit("Port::new"), Array::new())]))));
                                this.fields = push(&this.fields, &(pf_pe.clone(), pt_pf.clone(), Text::from(format!("`{}` as a value: the port it fires", &nkey_p6))));
                                this.moves = push(&this.moves, &(pf_pe.clone(), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(pf_pe.clone())))));
                                this
                            };
                            let be_ph = crate::lower::types::bind(&crate::lower::types::bind(&benv_p1, &nkey_p6, &b_pd), &Text::from(format!("{}#port", &nkey_p6)), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(pf_pe.clone()), crate::lower::types::Holding::Owned, pt_pf.clone()));
                            let me_pi = crate::lower::types::bind(&crate::lower::types::bind(&menv_p2, &nkey_p6, &b_pd), &Text::from(format!("{}#port", &nkey_p6)), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), pf_pe.clone()), crate::lower::types::Holding::Owned, pt_pf.clone()));
                            prism_rtl::Turn::Finished((wx3_pg.clone(), be_ph.clone(), me_pi.clone()))
                        })
                    } else {
                        match (layer_p8.clone(), how_p4.clone()) {
                            (crate::lower::types::Layer::LyDyn, HowBound::AsLet) => {
                                let b_pl = crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XSelf), rs_pa.clone(), Array::from(vec![crate::lower::model::Ex::XCx])), Array::from(vec![crate::lower::node_::Read::OwnRead(rs_pa.clone())]), t_p9.clone());
                                prism_rtl::Turn::Finished((wx1_pb.clone(), crate::lower::types::bind(&benv_p1, &nkey_p6, &b_pl), crate::lower::types::bind(&menv_p2, &nkey_p6, &b_pl)))
                            },
                            (crate::lower::types::Layer::LyDyn, HowBound::AsResult) => {
                                let b_pm = crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XSelf), rs_pa.clone(), Array::from(vec![crate::lower::model::Ex::XCx])), Array::from(vec![crate::lower::node_::Read::OwnRead(rs_pa.clone())]), t_p9.clone());
                                prism_rtl::Turn::Finished((wx1_pb.clone(), crate::lower::types::bind(&benv_p1, &nkey_p6, &b_pm), crate::lower::types::bind(&menv_p2, &nkey_p6, &b_pm)))
                            },
                            (crate::lower::types::Layer::LyDyn, _) => {
                                let b_pn = crate::lower::types::Bn::BnHold(rs_pa.clone(), t_p9.clone());
                                prism_rtl::Turn::Finished((wx1_pb.clone(), crate::lower::types::bind(&benv_p1, &nkey_p6, &b_pn), crate::lower::types::bind(&menv_p2, &nkey_p6, &b_pn)))
                            },
                            _ => call_then(start_many_instances(wx_p0.lx.clone(), n_p3.span.clone()), move |many_instances_13950: Option<Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)>>| match many_instances_13950 {
                                Some(insts_po) => fold_job(crate::check::errors::range0(&len(&insts_po)), (wx1_pb.clone(), benv_p1.clone(), menv_p2.clone()), {
                                    let insts_po = insts_po.clone();
                                    let wx_p0 = wx_p0.clone();
                                    let n_p3 = n_p3.clone();
                                    let rs_pa = rs_pa.clone();
                                    let nkey_p6 = nkey_p6.clone();
                                    Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), Nat)| {
                                        let insts_po = insts_po.clone();
                                        let wx_p0 = wx_p0.clone();
                                        let n_p3 = n_p3.clone();
                                        let rs_pa = rs_pa.clone();
                                        let nkey_p6 = nkey_p6.clone();
                                        entered(once_job(move || {
                                            let (w_pp, be_pq, me_pr) = p0;
                                            let k_ps = p1;
                                            {
                                                let inst_pt = or(&index(&insts_po, &k_ps), &(Array::new(), Array::new()));
                                                let lxk_pu = crate::lower::expr::at_instance(&wx_p0.lx, &inst_pt);
                                                call_then(crate::lower::types::start_out_ty_of(lxk_pu.clone(), crate::lower::types::peel(&crate::lower::binder_ty(&lxk_pu, &n_p3.span))), move |out_ty_of_14418: crate::lower::model::OutTy| {
                                                    let tk_pv = out_ty_of_14418;
                                                    let (rk_p12, w2_p13) = if &k_ps == &Nat::from(0u32) {
                                                        (rs_pa.clone(), w_pp.clone())
                                                    } else {
                                                        crate::lower::node_::fresh_name(&w_pp, &Text::from(format!("{}_{}", &rs_pa, &k_ps)))
                                                    };
                                                    let bkey_p10 = if &k_ps == &Nat::from(0u32) {
                                                        nkey_p6.clone()
                                                    } else {
                                                        Text::from(format!("{}#inst{}", &nkey_p6, &k_ps))
                                                    };
                                                    let (be2_p14, me2_p15) = crate::lower::node_::bind_plain(&be_pq, &me_pr, &bkey_p10, &rk_p12, &tk_pv);
                                                    let ukey_p11 = Text::from(format!("{}#{}", &nkey_p6, &show_text(&inst_pt)));
                                                    prism_rtl::Turn::Finished((w2_p13.clone(), with_use(&be2_p14, &ukey_p11, &bkey_p10), with_use(&me2_p15, &ukey_p11, &bkey_p10)))
                                                })
                                            }
                                        }))
                                    }) as Rc<dyn Fn(((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), Nat)) -> Rc<dyn prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>>>
                                }).cycle(),
                                None => {
                                    let (be_p16, me_p17) = crate::lower::node_::bind_plain(&benv_p1, &menv_p2, &nkey_p6, &rs_pa, &t_p9);
                                    prism_rtl::Turn::Finished((wx1_pb.clone(), be_p16.clone(), me_p17.clone()))
                                },
                            }),
                        }
                    }
                }
            })
        })
    }
}

/// `Start PreBindName, x`: what the function value is when passed to `@Run`.
pub fn start_pre_bind_name(wx_p0: crate::lower::node_::Wx, benv_p1: crate::lower::types::Env, menv_p2: crate::lower::types::Env, n_p3: crate::syntax::SName, how_p4: HowBound) -> Rc<dyn prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>> {
    Rc::new(PreBindName { wx_p0, benv_p1, menv_p2, n_p3, how_p4 })
}

/// ```prism
/// WithUse: fn Env, Text, Text -> Env
/// ```
pub fn with_use(env_p0: &crate::lower::types::Env, ukey_p1: &Text, bkey_p2: &Text) -> crate::lower::types::Env {
    let mut this: crate::lower::types::Env = env_p0.clone();
    this.uses = insert(&this.uses, ukey_p1, bkey_p2);
    this
}

/// ```prism
/// ?ManyInstances: unbounded fn Lx, Range -> ?[(([((Text, Ty))], [((Text, Col))]))]
/// ```
pub fn many_instances(lx_p0: &crate::lower::Lx, span_p1: &crate::syntax::Range) -> Option<Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)>> {
    match get(&lx_p0.gens, &crate::lower::place_key(lx_p0, span_p1)) {
        Some(gn_p2) => {
            let insts_p3 = crate::lower::expr::instantiations(lx_p0, &gn_p2);
            if &len(&insts_p3) > &Nat::from(1u32) { Some(insts_p3.clone()) } else { None }
        },
        None => None,
    }
}

/// The step machine of `ManyInstances`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?ManyInstances: unbounded fn Lx, Range -> ?[(([((Text, Ty))], [((Text, Col))]))]
/// ```
pub struct ManyInstances {
    pub lx_p0: crate::lower::Lx,
    pub span_p1: crate::syntax::Range,
}

impl prism_rtl::Job<Option<Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)>>> for ManyInstances {
    fn cycle(&self) -> prism_rtl::Turn<Option<Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)>>> {
        let lx_p0 = &self.lx_p0;
        let span_p1 = &self.span_p1;
        match get(&lx_p0.gens, &crate::lower::place_key(lx_p0, span_p1)) {
            Some(gn_p2) => {
                let lx_p0 = lx_p0.clone();
                call_then(crate::lower::expr::start_instantiations(lx_p0.clone(), gn_p2.clone()), move |instantiations_15295: Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)>| {
                    let insts_p3 = instantiations_15295;
                    if &len(&insts_p3) > &Nat::from(1u32) {
                        prism_rtl::Turn::Finished(Some(insts_p3.clone()))
                    } else {
                        prism_rtl::Turn::Finished(None)
                    }
                })
            },
            None => prism_rtl::Turn::Finished(None),
        }
    }
}

/// `Start ManyInstances, x`: what the function value is when passed to `@Run`.
pub fn start_many_instances(lx_p0: crate::lower::Lx, span_p1: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<Option<Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)>>>> {
    Rc::new(ManyInstances { lx_p0, span_p1 })
}

/// ```prism
/// IsSwitched: fn Ty -> Bool
/// ```
pub fn is_switched(t_p0: &crate::check::types::Ty) -> bool {
    'm15612: {
        if let crate::check::types::Ty::TySig(m15612_0_0, m15612_0_1) = t_p0 && (m15612_0_0 == &Text::lit("$")) && let crate::check::types::Ty::TySig(m15612_0_1_r_0, _) = &**m15612_0_1 && (m15612_0_1_r_0 == &Text::lit("!")) {
            break 'm15612 true;
        }
        false
    }
}

/// ```prism
/// ?BindingOf: fn Env, Pattern -> ?Bn
/// ```
pub fn binding_of(env_p0: &crate::lower::types::Env, p_p1: &crate::syntax::Pattern_) -> Option<crate::lower::types::Bn> {
    match &*p_p1.kind {
        crate::syntax::PatternKind::PName(n_p2) => get(&env_p0.names, &crate::check::env::sname_key(n_p2)),
        crate::syntax::PatternKind::PTuple(ps_p3) => Some(crate::lower::types::Bn::BnParts(each(ps_p3, &(|q_p4: &crate::syntax::Pattern_| binding_of_name(env_p0, q_p4))))),
        _ => None,
    }
}

/// ```prism
/// ?BindingOfName: fn Env, Pattern -> ?Bn
/// ```
pub fn binding_of_name(env_p0: &crate::lower::types::Env, p_p1: &crate::syntax::Pattern_) -> Option<crate::lower::types::Bn> {
    match &*p_p1.kind {
        crate::syntax::PatternKind::PName(n_p2) => get(&env_p0.names, &crate::check::env::sname_key(n_p2)),
        _ => None,
    }
}

/// ```prism
/// WidgetStmt: unbounded fn Wx, Env, Env, Stmt, Bool -> ((Wx, Env, Env))
/// ```
pub fn widget_stmt(wx_p0: &crate::lower::node_::Wx, benv_p1: &crate::lower::types::Env, menv_p2: &crate::lower::types::Env, s_p3: &crate::syntax::Stmt, last_p4: &bool) -> (crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env) {
    let lx_p5 = wx_p0.lx.clone();
    match &s_p3.kind {
        crate::syntax::StmtKind::SBind(p_p6, e_p7, None) => {
            let (wx2_p9, res_pa) = build_line(wx_p0, benv_p1, menv_p2, e_p7, &binding_of(menv_p2, p_p6));
            let wx3_p8 = bind_res(&wx2_p9, menv_p2, p_p6, &res_pa);
            match (res_pa.clone(), (*p_p6.kind).clone()) {
                (crate::lower::node_::Wres::WrDyn(ex_pb, rds_pc, t_pd), crate::syntax::PatternKind::PName(n_pe)) => {
                    let b_pf = crate::lower::types::Bn::BnDyn(ex_pb.clone(), rds_pc.clone(), t_pd.clone());
                    result_getter(&wx3_p8, menv_p2, &n_pe, &ex_pb, &rds_pc, &t_pd, &crate::lower::types::bind(benv_p1, &crate::check::env::sname_key(&n_pe), &b_pf), &crate::lower::types::bind(menv_p2, &crate::check::env::sname_key(&n_pe), &b_pf))
                },
                (crate::lower::node_::Wres::WrHosted(inner_pg, doc_ph), crate::syntax::PatternKind::PTuple(ps_pi)) => bind_hosted(&wx3_p8, benv_p1, menv_p2, &*inner_pg, &doc_ph, &ps_pi),
                (crate::lower::node_::Wres::WrParts(parts_pj), crate::syntax::PatternKind::PTuple(ps_pk)) => bind_parts(&wx2_p9, benv_p1, menv_p2, &parts_pj, &ps_pk),
                (crate::lower::node_::Wres::WrParts(parts_pl), crate::syntax::PatternKind::PName(n_pm)) => {
                    let b_pn = bundle_bn(&res_pa);
                    (wx3_p8.clone(), crate::lower::types::bind(benv_p1, &crate::check::env::sname_key(&n_pm), &b_pn), crate::lower::types::bind(menv_p2, &crate::check::env::sname_key(&n_pm), &b_pn))
                },
                (crate::lower::node_::Wres::WrPlain(ex_po, t_pp), _) => (bind_plain_result(&wx3_p8, menv_p2, p_p6, &ex_po, &t_pp), benv_p1.clone(), menv_p2.clone()),
                _ => (wx3_p8.clone(), benv_p1.clone(), menv_p2.clone()),
            }
        },
        crate::syntax::StmtKind::SBind(p_pq, init_pr, Some(step_ps)) => {
            let (wx2_pt, be2_pu) = hold_line(wx_p0, benv_p1, menv_p2, p_pq, init_pr, step_ps);
            (wx2_pt.clone(), be2_pu.clone(), menv_p2.clone())
        },
        crate::syntax::StmtKind::SIgnore(e_pv) => {
            let (wx2_p10, _) = build_line(wx_p0, benv_p1, menv_p2, e_pv, &None);
            (wx2_p10.clone(), benv_p1.clone(), menv_p2.clone())
        },
        crate::syntax::StmtKind::SLet(p_p11, _, e_p12) => {
            let (wx2_p13, be2_p14) = let_line(wx_p0, benv_p1, menv_p2, p_p11, e_p12);
            (wx2_p13.clone(), be2_p14.clone(), menv_p2.clone())
        },
        crate::syntax::StmtKind::SExpr(e_p15) => match &*e_p15.kind {
            crate::syntax::ExprKind::EFreeSigil(m17518_0_0, x_p16) if (m17518_0_0 == &Text::lit("@")) => {
                let (res_p18, wx2_p19) = result_of(wx_p0, benv_p1, menv_p2, &**x_p16);
                let wx3_p17 = {
                    let mut this: crate::lower::node_::Wx = wx2_p19.clone();
                    this.result = res_p18.clone();
                    this
                };
                (wx3_p17.clone(), benv_p1.clone(), menv_p2.clone())
            },
            _ => {
                let (wx2_p1b, res_p1c) = build_line(wx_p0, benv_p1, menv_p2, e_p15, &None);
                let wx3_p1a = if *last_p4 { set_result(&wx2_p1b, &res_p1c) } else { wx2_p1b.clone() };
                (wx3_p1a.clone(), benv_p1.clone(), menv_p2.clone())
            },
            _ => unreachable!("no arm matched"),
        },
        crate::syntax::StmtKind::SEmit(_) => (wx_p0.clone(), benv_p1.clone(), menv_p2.clone()),
        crate::syntax::StmtKind::SSignature(_) => (wx_p0.clone(), benv_p1.clone(), menv_p2.clone()),
        crate::syntax::StmtKind::SFn(c_p1d) => (wx_p0.clone(), benv_p1.clone(), menv_p2.clone()),
        _ => {
            let wx2_p1e = {
                let mut this: crate::lower::node_::Wx = wx_p0.clone();
                this.build = push(&this.build, &crate::lower::expr::refusal_do(&Text::lit("a statement this back end does not lower yet")));
                this
            };
            (wx2_p1e.clone(), benv_p1.clone(), menv_p2.clone())
        },
    }
}

/// The step machine of `WidgetStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// WidgetStmt: unbounded fn Wx, Env, Env, Stmt, Bool -> ((Wx, Env, Env))
/// ```
pub struct WidgetStmt {
    pub wx_p0: crate::lower::node_::Wx,
    pub benv_p1: crate::lower::types::Env,
    pub menv_p2: crate::lower::types::Env,
    pub s_p3: crate::syntax::Stmt,
    pub last_p4: bool,
}

impl prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)> for WidgetStmt {
    fn cycle(&self) -> prism_rtl::Turn<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)> {
        let wx_p0 = &self.wx_p0;
        let benv_p1 = &self.benv_p1;
        let menv_p2 = &self.menv_p2;
        let s_p3 = &self.s_p3;
        let last_p4 = &self.last_p4;
        let lx_p5 = wx_p0.lx.clone();
        match &s_p3.kind {
            crate::syntax::StmtKind::SBind(p_p6, e_p7, None) => {
                let benv_p1 = benv_p1.clone();
                let e_p7 = e_p7.clone();
                let menv_p2 = menv_p2.clone();
                let p_p6 = p_p6.clone();
                let wx_p0 = wx_p0.clone();
                call_then(start_build_line(wx_p0.clone(), benv_p1.clone(), menv_p2.clone(), e_p7.clone(), binding_of(&menv_p2, &p_p6)), move |build_line_16283: (crate::lower::node_::Wx, crate::lower::node_::Wres)| {
                    let (wx2_p9, res_pa) = build_line_16283;
                    let wx3_p8 = bind_res(&wx2_p9, &menv_p2, &p_p6, &res_pa);
                    match (res_pa.clone(), (*p_p6.kind).clone()) {
                        (crate::lower::node_::Wres::WrDyn(ex_pb, rds_pc, t_pd), crate::syntax::PatternKind::PName(n_pe)) => {
                            let b_pf = crate::lower::types::Bn::BnDyn(ex_pb.clone(), rds_pc.clone(), t_pd.clone());
                            prism_rtl::Turn::Finished(result_getter(&wx3_p8, &menv_p2, &n_pe, &ex_pb, &rds_pc, &t_pd, &crate::lower::types::bind(&benv_p1, &crate::check::env::sname_key(&n_pe), &b_pf), &crate::lower::types::bind(&menv_p2, &crate::check::env::sname_key(&n_pe), &b_pf)))
                        },
                        (crate::lower::node_::Wres::WrHosted(inner_pg, doc_ph), crate::syntax::PatternKind::PTuple(ps_pi)) => prism_rtl::Turn::Finished(bind_hosted(&wx3_p8, &benv_p1, &menv_p2, &*inner_pg, &doc_ph, &ps_pi)),
                        (crate::lower::node_::Wres::WrParts(parts_pj), crate::syntax::PatternKind::PTuple(ps_pk)) => prism_rtl::Turn::More(Rc::new(BindParts { wx_p0: wx2_p9.clone(), benv_p1: benv_p1.clone(), menv_p2: menv_p2.clone(), parts_p3: parts_pj.clone(), ps_p4: ps_pk.clone() })),
                        (crate::lower::node_::Wres::WrParts(parts_pl), crate::syntax::PatternKind::PName(n_pm)) => {
                            let b_pn = bundle_bn(&res_pa);
                            prism_rtl::Turn::Finished((wx3_p8.clone(), crate::lower::types::bind(&benv_p1, &crate::check::env::sname_key(&n_pm), &b_pn), crate::lower::types::bind(&menv_p2, &crate::check::env::sname_key(&n_pm), &b_pn)))
                        },
                        (crate::lower::node_::Wres::WrPlain(ex_po, t_pp), _) => call_then(start_bind_plain_result(wx3_p8.clone(), menv_p2.clone(), p_p6.clone(), ex_po.clone(), t_pp.clone()), move |bind_plain_result_17033: crate::lower::node_::Wx| prism_rtl::Turn::Finished((bind_plain_result_17033, benv_p1.clone(), menv_p2.clone()))),
                        _ => prism_rtl::Turn::Finished((wx3_p8.clone(), benv_p1.clone(), menv_p2.clone())),
                    }
                })
            },
            crate::syntax::StmtKind::SBind(p_pq, init_pr, Some(step_ps)) => {
                let benv_p1 = benv_p1.clone();
                let init_pr = init_pr.clone();
                let menv_p2 = menv_p2.clone();
                let p_pq = p_pq.clone();
                let step_ps = step_ps.clone();
                let wx_p0 = wx_p0.clone();
                call_then(start_hold_line(wx_p0.clone(), benv_p1.clone(), menv_p2.clone(), p_pq.clone(), init_pr.clone(), step_ps.clone()), move |hold_line_17195: (crate::lower::node_::Wx, crate::lower::types::Env)| {
                    let (wx2_pt, be2_pu) = hold_line_17195;
                    prism_rtl::Turn::Finished((wx2_pt.clone(), be2_pu.clone(), menv_p2.clone()))
                })
            },
            crate::syntax::StmtKind::SIgnore(e_pv) => {
                let benv_p1 = benv_p1.clone();
                let e_pv = e_pv.clone();
                let menv_p2 = menv_p2.clone();
                let wx_p0 = wx_p0.clone();
                call_then(start_build_line(wx_p0.clone(), benv_p1.clone(), menv_p2.clone(), e_pv.clone(), None), move |build_line_17318: (crate::lower::node_::Wx, crate::lower::node_::Wres)| {
                    let (wx2_p10, _) = build_line_17318;
                    prism_rtl::Turn::Finished((wx2_p10.clone(), benv_p1.clone(), menv_p2.clone()))
                })
            },
            crate::syntax::StmtKind::SLet(p_p11, _, e_p12) => {
                let benv_p1 = benv_p1.clone();
                let e_p12 = e_p12.clone();
                let menv_p2 = menv_p2.clone();
                let p_p11 = p_p11.clone();
                let wx_p0 = wx_p0.clone();
                call_then(start_let_line(wx_p0.clone(), benv_p1.clone(), menv_p2.clone(), p_p11.clone(), e_p12.clone()), move |let_line_17441: (crate::lower::node_::Wx, crate::lower::types::Env)| {
                    let (wx2_p13, be2_p14) = let_line_17441;
                    prism_rtl::Turn::Finished((wx2_p13.clone(), be2_p14.clone(), menv_p2.clone()))
                })
            },
            crate::syntax::StmtKind::SExpr(e_p15) => match &*e_p15.kind {
                crate::syntax::ExprKind::EFreeSigil(m17518_0_0, x_p16) if (m17518_0_0 == &Text::lit("@")) => {
                    let benv_p1 = benv_p1.clone();
                    let menv_p2 = menv_p2.clone();
                    let wx_p0 = wx_p0.clone();
                    let x_p16 = (**x_p16).clone();
                    call_then(start_result_of(wx_p0.clone(), benv_p1.clone(), menv_p2.clone(), x_p16.clone()), move |result_of_17598: (crate::lower::node_::Wres, crate::lower::node_::Wx)| {
                        let (res_p18, wx2_p19) = result_of_17598;
                        let wx3_p17 = {
                            let mut this: crate::lower::node_::Wx = wx2_p19.clone();
                            this.result = res_p18.clone();
                            this
                        };
                        prism_rtl::Turn::Finished((wx3_p17.clone(), benv_p1.clone(), menv_p2.clone()))
                    })
                },
                _ => {
                    let benv_p1 = benv_p1.clone();
                    let e_p15 = e_p15.clone();
                    let last_p4 = *last_p4;
                    let menv_p2 = menv_p2.clone();
                    let wx_p0 = wx_p0.clone();
                    call_then(start_build_line(wx_p0.clone(), benv_p1.clone(), menv_p2.clone(), e_p15.clone(), None), move |build_line_17794: (crate::lower::node_::Wx, crate::lower::node_::Wres)| {
                        let (wx2_p1b, res_p1c) = build_line_17794;
                        let wx3_p1a = if last_p4 { set_result(&wx2_p1b, &res_p1c) } else { wx2_p1b.clone() };
                        prism_rtl::Turn::Finished((wx3_p1a.clone(), benv_p1.clone(), menv_p2.clone()))
                    })
                },
                _ => unreachable!("no arm matched"),
            },
            crate::syntax::StmtKind::SEmit(_) => prism_rtl::Turn::Finished((wx_p0.clone(), benv_p1.clone(), menv_p2.clone())),
            crate::syntax::StmtKind::SSignature(_) => prism_rtl::Turn::Finished((wx_p0.clone(), benv_p1.clone(), menv_p2.clone())),
            crate::syntax::StmtKind::SFn(c_p1d) => prism_rtl::Turn::Finished((wx_p0.clone(), benv_p1.clone(), menv_p2.clone())),
            _ => {
                let wx2_p1e = {
                    let mut this: crate::lower::node_::Wx = wx_p0.clone();
                    this.build = push(&this.build, &crate::lower::expr::refusal_do(&Text::lit("a statement this back end does not lower yet")));
                    this
                };
                prism_rtl::Turn::Finished((wx2_p1e.clone(), benv_p1.clone(), menv_p2.clone()))
            },
        }
    }
}

/// `Start WidgetStmt, x`: what the function value is when passed to `@Run`.
pub fn start_widget_stmt(wx_p0: crate::lower::node_::Wx, benv_p1: crate::lower::types::Env, menv_p2: crate::lower::types::Env, s_p3: crate::syntax::Stmt, last_p4: bool) -> Rc<dyn prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>> {
    Rc::new(WidgetStmt { wx_p0, benv_p1, menv_p2, s_p3, last_p4 })
}

/// ```prism
/// BindHosted: fn Wx, Env, Env, Wres, Bn, [Pattern] -> ((Wx, Env, Env))
/// ```
pub fn bind_hosted(wx_p0: &crate::lower::node_::Wx, benv_p1: &crate::lower::types::Env, menv_p2: &crate::lower::types::Env, res_p3: &crate::lower::node_::Wres, doc_p4: &crate::lower::types::Bn, ps_p5: &Array<crate::syntax::Pattern_>) -> (crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env) {
    let r_o6 = match res_p3 {
        crate::lower::node_::Wres::WrEv(r_p7) => Some(crate::lower::types::Bn::BnEv(r_p7.clone(), crate::lower::model::OutTy::OutUnit)),
        crate::lower::node_::Wres::WrDyn(ex_p8, rds_p9, t_pa) => Some(crate::lower::types::Bn::BnDyn(ex_p8.clone(), rds_p9.clone(), t_pa.clone())),
        crate::lower::node_::Wres::WrParts(_) => Some(bundle_bn(res_p3)),
        _ => None,
    };
    let (be1_pb, me1_pc) = bind_part(benv_p1, menv_p2, &index(ps_p5, &Nat::from(0u32)), &r_o6);
    bind_part2(wx_p0, &be1_pb, &me1_pc, &index(ps_p5, &Nat::from(1u32)), &Some(doc_p4.clone()))
}

/// ```prism
/// BindPart: fn Env, Env, ?Pattern, ?Bn -> ((Env, Env))
/// ```
pub fn bind_part(benv_p0: &crate::lower::types::Env, menv_p1: &crate::lower::types::Env, p_o2: &Option<crate::syntax::Pattern_>, b_o3: &Option<crate::lower::types::Bn>) -> (crate::lower::types::Env, crate::lower::types::Env) {
    match (p_o2.clone(), b_o3.clone()) {
        (Some(p_p4), Some(b_p5)) => match &*p_p4.kind {
            crate::syntax::PatternKind::PName(n_p6) => (crate::lower::types::bind(benv_p0, &crate::check::env::sname_key(n_p6), &b_p5), crate::lower::types::bind(menv_p1, &crate::check::env::sname_key(n_p6), &b_p5)),
            _ => (benv_p0.clone(), menv_p1.clone()),
        },
        _ => (benv_p0.clone(), menv_p1.clone()),
    }
}

/// ```prism
/// BindPart2: fn Wx, Env, Env, ?Pattern, ?Bn -> ((Wx, Env, Env))
/// ```
pub fn bind_part2(wx_p0: &crate::lower::node_::Wx, benv_p1: &crate::lower::types::Env, menv_p2: &crate::lower::types::Env, p_o3: &Option<crate::syntax::Pattern_>, b_o4: &Option<crate::lower::types::Bn>) -> (crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env) {
    let (be_p5, me_p6) = bind_part(benv_p1, menv_p2, p_o3, b_o4);
    (wx_p0.clone(), be_p5.clone(), me_p6.clone())
}

/// ```prism
/// BindParts: unbounded fn Wx, Env, Env, [Wres], [Pattern] -> ((Wx, Env, Env))
/// ```
pub fn bind_parts(wx_p0: &crate::lower::node_::Wx, benv_p1: &crate::lower::types::Env, menv_p2: &crate::lower::types::Env, parts_p3: &Array<crate::lower::node_::Wres>, ps_p4: &Array<crate::syntax::Pattern_>) -> (crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env) {
    run_to_end(fold_job(crate::check::errors::range0(&len(ps_p4)), (wx_p0.clone(), benv_p1.clone(), menv_p2.clone()), {
        let ps_p4 = ps_p4.clone();
        let parts_p3 = parts_p3.clone();
        Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), Nat)| {
            let ps_p4 = ps_p4.clone();
            let parts_p3 = parts_p3.clone();
            entered(once_job(move || {
                let (w_p5, be_p6, me_p7) = p0;
                let i_p8 = p1;
                match (index(&ps_p4, &i_p8), index(&parts_p3, &i_p8)) {
                    (Some(p_p9), Some(part_pa)) => match (part_pa.clone(), (*p_p9.kind).clone()) {
                        (crate::lower::node_::Wres::WrEv(r_pb), crate::syntax::PatternKind::PName(_)) => prism_rtl::Turn::Finished((bind_res(&w_p5, &me_p7, &p_p9, &part_pa), be_p6.clone(), me_p7.clone())),
                        (crate::lower::node_::Wres::WrParts(inner_pc), crate::syntax::PatternKind::PTuple(qs_pd)) => prism_rtl::Turn::More(Rc::new(BindParts { wx_p0: w_p5.clone(), benv_p1: be_p6.clone(), menv_p2: me_p7.clone(), parts_p3: inner_pc.clone(), ps_p4: qs_pd.clone() })),
                        (_, crate::syntax::PatternKind::PName(n_pe)) => match &part_pa {
                            crate::lower::node_::Wres::WrUnit => prism_rtl::Turn::Finished((w_p5.clone(), be_p6.clone(), me_p7.clone())),
                            crate::lower::node_::Wres::WrDyn(ex_pf, rds_pg, t_ph) => {
                                let b_pi = crate::lower::types::Bn::BnDyn(ex_pf.clone(), rds_pg.clone(), t_ph.clone());
                                prism_rtl::Turn::Finished(result_getter(&w_p5, &me_p7, &n_pe, ex_pf, rds_pg, t_ph, &crate::lower::types::bind(&be_p6, &crate::check::env::sname_key(&n_pe), &b_pi), &crate::lower::types::bind(&me_p7, &crate::check::env::sname_key(&n_pe), &b_pi)))
                            },
                            _ => {
                                let b_pj = bundle_bn(&part_pa);
                                prism_rtl::Turn::Finished((w_p5.clone(), crate::lower::types::bind(&be_p6, &crate::check::env::sname_key(&n_pe), &b_pj), crate::lower::types::bind(&me_p7, &crate::check::env::sname_key(&n_pe), &b_pj)))
                            },
                        },
                        _ => prism_rtl::Turn::Finished((w_p5.clone(), be_p6.clone(), me_p7.clone())),
                    },
                    _ => prism_rtl::Turn::Finished((w_p5.clone(), be_p6.clone(), me_p7.clone())),
                }
            }))
        }) as Rc<dyn Fn(((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), Nat)) -> Rc<dyn prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>>>
    }))
}

/// The step machine of `BindParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BindParts: unbounded fn Wx, Env, Env, [Wres], [Pattern] -> ((Wx, Env, Env))
/// ```
pub struct BindParts {
    pub wx_p0: crate::lower::node_::Wx,
    pub benv_p1: crate::lower::types::Env,
    pub menv_p2: crate::lower::types::Env,
    pub parts_p3: Array<crate::lower::node_::Wres>,
    pub ps_p4: Array<crate::syntax::Pattern_>,
}

impl prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)> for BindParts {
    fn cycle(&self) -> prism_rtl::Turn<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)> {
        let wx_p0 = &self.wx_p0;
        let benv_p1 = &self.benv_p1;
        let menv_p2 = &self.menv_p2;
        let parts_p3 = &self.parts_p3;
        let ps_p4 = &self.ps_p4;
        fold_job(crate::check::errors::range0(&len(ps_p4)), (wx_p0.clone(), benv_p1.clone(), menv_p2.clone()), {
            let ps_p4 = ps_p4.clone();
            let parts_p3 = parts_p3.clone();
            Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), Nat)| {
                let ps_p4 = ps_p4.clone();
                let parts_p3 = parts_p3.clone();
                entered(once_job(move || {
                    let (w_p5, be_p6, me_p7) = p0;
                    let i_p8 = p1;
                    match (index(&ps_p4, &i_p8), index(&parts_p3, &i_p8)) {
                        (Some(p_p9), Some(part_pa)) => match (part_pa.clone(), (*p_p9.kind).clone()) {
                            (crate::lower::node_::Wres::WrEv(r_pb), crate::syntax::PatternKind::PName(_)) => prism_rtl::Turn::Finished((bind_res(&w_p5, &me_p7, &p_p9, &part_pa), be_p6.clone(), me_p7.clone())),
                            (crate::lower::node_::Wres::WrParts(inner_pc), crate::syntax::PatternKind::PTuple(qs_pd)) => prism_rtl::Turn::More(Rc::new(BindParts { wx_p0: w_p5.clone(), benv_p1: be_p6.clone(), menv_p2: me_p7.clone(), parts_p3: inner_pc.clone(), ps_p4: qs_pd.clone() })),
                            (_, crate::syntax::PatternKind::PName(n_pe)) => match &part_pa {
                                crate::lower::node_::Wres::WrUnit => prism_rtl::Turn::Finished((w_p5.clone(), be_p6.clone(), me_p7.clone())),
                                crate::lower::node_::Wres::WrDyn(ex_pf, rds_pg, t_ph) => {
                                    let b_pi = crate::lower::types::Bn::BnDyn(ex_pf.clone(), rds_pg.clone(), t_ph.clone());
                                    prism_rtl::Turn::Finished(result_getter(&w_p5, &me_p7, &n_pe, ex_pf, rds_pg, t_ph, &crate::lower::types::bind(&be_p6, &crate::check::env::sname_key(&n_pe), &b_pi), &crate::lower::types::bind(&me_p7, &crate::check::env::sname_key(&n_pe), &b_pi)))
                                },
                                _ => {
                                    let b_pj = bundle_bn(&part_pa);
                                    prism_rtl::Turn::Finished((w_p5.clone(), crate::lower::types::bind(&be_p6, &crate::check::env::sname_key(&n_pe), &b_pj), crate::lower::types::bind(&me_p7, &crate::check::env::sname_key(&n_pe), &b_pj)))
                                },
                            },
                            _ => prism_rtl::Turn::Finished((w_p5.clone(), be_p6.clone(), me_p7.clone())),
                        },
                        _ => prism_rtl::Turn::Finished((w_p5.clone(), be_p6.clone(), me_p7.clone())),
                    }
                }))
            }) as Rc<dyn Fn(((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), Nat)) -> Rc<dyn prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>>>
        }).cycle()
    }
}

/// `Start BindParts, x`: what the function value is when passed to `@Run`.
pub fn start_bind_parts(wx_p0: crate::lower::node_::Wx, benv_p1: crate::lower::types::Env, menv_p2: crate::lower::types::Env, parts_p3: Array<crate::lower::node_::Wres>, ps_p4: Array<crate::syntax::Pattern_>) -> Rc<dyn prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>> {
    Rc::new(BindParts { wx_p0, benv_p1, menv_p2, parts_p3, ps_p4 })
}

/// ```prism
/// ResultGetter: fn Wx, Env, SName, Ex, [Read], OutTy, Env, Env -> ((Wx, Env, Env))
/// ```
pub fn result_getter(wx_p0: &crate::lower::node_::Wx, menv_p1: &crate::lower::types::Env, n_p2: &crate::syntax::SName, ex_p3: &crate::lower::model::Ex, rds_p4: &Array<crate::lower::node_::Read>, t_p5: &crate::lower::model::OutTy, benv2_p6: &crate::lower::types::Env, menv2_p7: &crate::lower::types::Env) -> (crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env) {
    'm20830: {
        let scrutinee = &get(&menv_p1.names, &crate::check::env::sname_key(n_p2));
        if let Some(crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(m20830_0_0_0, rs_p8, _), m20830_0_1, _)) = scrutinee && let crate::lower::model::Ex::XSelf = &**m20830_0_0_0 && (m20830_0_1.len() == 1) && let Some(crate::lower::node_::Read::OwnRead(r0_p9)) = index(m20830_0_1, &Nat::from(0u32)) && ((&r0_p9 == rs_p8) && !crate::check::types::has_text(&keys(&wx_p0.dyn_reads), rs_p8)) {
            break 'm20830 {
                let getter_pa = crate::lower::model::MethDef { name: rs_p8.clone(), recv: crate::lower::model::Recv::RecvRef, params: Array::new(), cx_: crate::lower::model::CxArg::CxRef, ret: t_p5.clone(), body: Array::new(), tail: ex_p3.clone(), doc: Text::from(format!("`{}`, a widget\'s result", &crate::check::env::sname_key(n_p2))) };
                let wx2_pb = {
                    let mut this: crate::lower::node_::Wx = wx_p0.clone();
                    this.getters = push(&this.getters, &getter_pa);
                    this.dyn_reads = insert(&this.dyn_reads, rs_p8, rds_p4);
                    this
                };
                (wx2_pb.clone(), benv2_p6.clone(), menv2_p7.clone())
            };
        }
        (wx_p0.clone(), benv2_p6.clone(), menv2_p7.clone())
    }
}

/// ```prism
/// BindPlainResult: unbounded fn Wx, Env, Pattern, Ex, OutTy -> Wx
/// ```
pub fn bind_plain_result(wx_p0: &crate::lower::node_::Wx, menv_p1: &crate::lower::types::Env, p_p2: &crate::syntax::Pattern_, ex_p3: &crate::lower::model::Ex, t_p4: &crate::lower::model::OutTy) -> crate::lower::node_::Wx {
    match &*p_p2.kind {
        crate::syntax::PatternKind::PName(n_p5) => match get(&menv_p1.names, &crate::check::env::sname_key(n_p5)) {
            Some(crate::lower::types::Bn::BnLocal(rx_p6, _, bt_p7)) => {
                let f_p8 = crate::lower::types::place_stem(&rx_p6);
                {
                    let mut this: crate::lower::node_::Wx = wx_p0.clone();
                    this.lets = push(&this.lets, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaBind(f_p8.clone())), bt_p7.clone()), ex_p3.clone()));
                    this.fields = push(&this.fields, &(f_p8.clone(), bt_p7.clone(), Text::from(format!("`{}`, a widget\'s result", &crate::check::env::sname_key(n_p5)))));
                    this.inits = push(&this.inits, &(f_p8.clone(), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(f_p8.clone())))));
                    this
                }
            },
            _ => refuse_plain_result(wx_p0, p_p2),
        },
        crate::syntax::PatternKind::PIgnore => wx_p0.clone(),
        crate::syntax::PatternKind::PGroup(q_p9) => bind_plain_result(wx_p0, menv_p1, &**q_p9, ex_p3, t_p4),
        crate::syntax::PatternKind::PTuple(ps_pa) => {
            let (tmp_pd, wx1_pe) = crate::lower::node_::fresh_name(wx_p0, &Text::lit("result"));
            let wx2_pb = {
                let mut this: crate::lower::node_::Wx = wx1_pe.clone();
                this.lets = push(&this.lets, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaBind(tmp_pd.clone())), t_p4.clone()), ex_p3.clone()));
                this
            };
            let parts_pc = match t_p4 {
                crate::lower::model::OutTy::OutTuple(ts_pf) => ts_pf.clone(),
                _ => Array::new(),
            };
            run_to_end(fold_job(crate::check::errors::range0(&len(ps_pa)), wx2_pb.clone(), {
                let ps_pa = ps_pa.clone();
                let menv_p1 = menv_p1.clone();
                let tmp_pd = tmp_pd.clone();
                let parts_pc = parts_pc.clone();
                Rc::new(move |(p0, p1): (crate::lower::node_::Wx, Nat)| {
                    let ps_pa = ps_pa.clone();
                    let menv_p1 = menv_p1.clone();
                    let tmp_pd = tmp_pd.clone();
                    let parts_pc = parts_pc.clone();
                    entered(once_job(move || {
                        let w_pg = p0;
                        let i_ph = p1;
                        match index(&ps_pa, &i_ph) {
                            Some(q_pi) => match &*q_pi.kind {
                                crate::syntax::PatternKind::PName(_) => prism_rtl::Turn::More(Rc::new(BindPlainResult { wx_p0: w_pg.clone(), menv_p1: menv_p1.clone(), p_p2: q_pi.clone(), ex_p3: crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XPart(Rc::new(crate::lower::model::Ex::XVar(tmp_pd.clone())), i_ph.clone()))), t_p4: or(&index(&parts_pc, &i_ph), &crate::lower::model::OutTy::OutUnit) })),
                                crate::syntax::PatternKind::PIgnore => prism_rtl::Turn::Finished(w_pg.clone()),
                                _ => prism_rtl::Turn::Finished(refuse_plain_result(&w_pg, &q_pi)),
                            },
                            None => prism_rtl::Turn::Finished(w_pg.clone()),
                        }
                    }))
                }) as Rc<dyn Fn((crate::lower::node_::Wx, Nat)) -> Rc<dyn prism_rtl::Job<crate::lower::node_::Wx>>>
            }))
        },
        _ => refuse_plain_result(wx_p0, p_p2),
    }
}

/// The step machine of `BindPlainResult`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BindPlainResult: unbounded fn Wx, Env, Pattern, Ex, OutTy -> Wx
/// ```
pub struct BindPlainResult {
    pub wx_p0: crate::lower::node_::Wx,
    pub menv_p1: crate::lower::types::Env,
    pub p_p2: crate::syntax::Pattern_,
    pub ex_p3: crate::lower::model::Ex,
    pub t_p4: crate::lower::model::OutTy,
}

impl prism_rtl::Job<crate::lower::node_::Wx> for BindPlainResult {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::node_::Wx> {
        let wx_p0 = &self.wx_p0;
        let menv_p1 = &self.menv_p1;
        let p_p2 = &self.p_p2;
        let ex_p3 = &self.ex_p3;
        let t_p4 = &self.t_p4;
        match &*p_p2.kind {
            crate::syntax::PatternKind::PName(n_p5) => match get(&menv_p1.names, &crate::check::env::sname_key(n_p5)) {
                Some(crate::lower::types::Bn::BnLocal(rx_p6, _, bt_p7)) => {
                    let f_p8 = crate::lower::types::place_stem(&rx_p6);
                    prism_rtl::Turn::Finished({
                        let mut this: crate::lower::node_::Wx = wx_p0.clone();
                        this.lets = push(&this.lets, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaBind(f_p8.clone())), bt_p7.clone()), ex_p3.clone()));
                        this.fields = push(&this.fields, &(f_p8.clone(), bt_p7.clone(), Text::from(format!("`{}`, a widget\'s result", &crate::check::env::sname_key(n_p5)))));
                        this.inits = push(&this.inits, &(f_p8.clone(), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(f_p8.clone())))));
                        this
                    })
                },
                _ => prism_rtl::Turn::Finished(refuse_plain_result(wx_p0, p_p2)),
            },
            crate::syntax::PatternKind::PIgnore => prism_rtl::Turn::Finished(wx_p0.clone()),
            crate::syntax::PatternKind::PGroup(q_p9) => prism_rtl::Turn::More(Rc::new(BindPlainResult { wx_p0: wx_p0.clone(), menv_p1: menv_p1.clone(), p_p2: (**q_p9).clone(), ex_p3: ex_p3.clone(), t_p4: t_p4.clone() })),
            crate::syntax::PatternKind::PTuple(ps_pa) => {
                let (tmp_pd, wx1_pe) = crate::lower::node_::fresh_name(wx_p0, &Text::lit("result"));
                let wx2_pb = {
                    let mut this: crate::lower::node_::Wx = wx1_pe.clone();
                    this.lets = push(&this.lets, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaBind(tmp_pd.clone())), t_p4.clone()), ex_p3.clone()));
                    this
                };
                let parts_pc = match t_p4 {
                    crate::lower::model::OutTy::OutTuple(ts_pf) => ts_pf.clone(),
                    _ => Array::new(),
                };
                fold_job(crate::check::errors::range0(&len(ps_pa)), wx2_pb.clone(), {
                    let ps_pa = ps_pa.clone();
                    let menv_p1 = menv_p1.clone();
                    let tmp_pd = tmp_pd.clone();
                    let parts_pc = parts_pc.clone();
                    Rc::new(move |(p0, p1): (crate::lower::node_::Wx, Nat)| {
                        let ps_pa = ps_pa.clone();
                        let menv_p1 = menv_p1.clone();
                        let tmp_pd = tmp_pd.clone();
                        let parts_pc = parts_pc.clone();
                        entered(once_job(move || {
                            let w_pg = p0;
                            let i_ph = p1;
                            match index(&ps_pa, &i_ph) {
                                Some(q_pi) => match &*q_pi.kind {
                                    crate::syntax::PatternKind::PName(_) => prism_rtl::Turn::More(Rc::new(BindPlainResult { wx_p0: w_pg.clone(), menv_p1: menv_p1.clone(), p_p2: q_pi.clone(), ex_p3: crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XPart(Rc::new(crate::lower::model::Ex::XVar(tmp_pd.clone())), i_ph.clone()))), t_p4: or(&index(&parts_pc, &i_ph), &crate::lower::model::OutTy::OutUnit) })),
                                    crate::syntax::PatternKind::PIgnore => prism_rtl::Turn::Finished(w_pg.clone()),
                                    _ => prism_rtl::Turn::Finished(refuse_plain_result(&w_pg, &q_pi)),
                                },
                                None => prism_rtl::Turn::Finished(w_pg.clone()),
                            }
                        }))
                    }) as Rc<dyn Fn((crate::lower::node_::Wx, Nat)) -> Rc<dyn prism_rtl::Job<crate::lower::node_::Wx>>>
                }).cycle()
            },
            _ => prism_rtl::Turn::Finished(refuse_plain_result(wx_p0, p_p2)),
        }
    }
}

/// `Start BindPlainResult, x`: what the function value is when passed to `@Run`.
pub fn start_bind_plain_result(wx_p0: crate::lower::node_::Wx, menv_p1: crate::lower::types::Env, p_p2: crate::syntax::Pattern_, ex_p3: crate::lower::model::Ex, t_p4: crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<crate::lower::node_::Wx>> {
    Rc::new(BindPlainResult { wx_p0, menv_p1, p_p2, ex_p3, t_p4 })
}

/// ```prism
/// RefusePlainResult: fn Wx, Pattern -> Wx
/// ```
pub fn refuse_plain_result(wx_p0: &crate::lower::node_::Wx, p_p1: &crate::syntax::Pattern_) -> crate::lower::node_::Wx {
    let mut this: crate::lower::node_::Wx = wx_p0.clone();
    this.build = push(&this.build, &crate::lower::expr::refusal_do(&Text::lit("a widget\'s plain result bound by this pattern: a name, or a tuple of names, binds one")));
    this
}

/// ```prism
/// BundleBn: fn Wres -> Bn
/// ```
pub fn bundle_bn(res_p0: &crate::lower::node_::Wres) -> crate::lower::types::Bn {
    match res_p0 {
        crate::lower::node_::Wres::WrEv(r_p1) => crate::lower::types::Bn::BnEv(r_p1.clone(), crate::lower::model::OutTy::OutUnit),
        crate::lower::node_::Wres::WrDyn(ex_p2, rds_p3, t_p4) => crate::lower::types::Bn::BnDyn(ex_p2.clone(), rds_p3.clone(), t_p4.clone()),
        crate::lower::node_::Wres::WrPlain(ex_p5, t_p6) => crate::lower::types::Bn::BnLocal(ex_p5.clone(), crate::lower::types::Holding::Owned, t_p6.clone()),
        crate::lower::node_::Wres::WrParts(parts_p7) => crate::lower::types::Bn::BnParts(each(parts_p7, &(|q_p8: &crate::lower::node_::Wres| Some(bundle_bn(q_p8))))),
        crate::lower::node_::Wres::WrHosted(inner_p9, _) => bundle_bn(&**inner_p9),
        crate::lower::node_::Wres::WrUnit => crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XUnit, crate::lower::types::Holding::Owned, crate::lower::model::OutTy::OutUnit),
    }
}

/// ```prism
/// BnRes: fn Bn -> Wres
/// ```
pub fn bn_res(b_p0: &crate::lower::types::Bn) -> crate::lower::node_::Wres {
    match b_p0 {
        crate::lower::types::Bn::BnEv(r_p1, _) => crate::lower::node_::Wres::WrEv(r_p1.clone()),
        crate::lower::types::Bn::BnDyn(ex_p2, rds_p3, t_p4) => crate::lower::node_::Wres::WrDyn(ex_p2.clone(), rds_p3.clone(), t_p4.clone()),
        crate::lower::types::Bn::BnLocal(ex_p5, _, t_p6) => if t_p6 == &crate::lower::model::OutTy::OutUnit {
            crate::lower::node_::Wres::WrUnit
        } else {
            crate::lower::node_::Wres::WrPlain(ex_p5.clone(), t_p6.clone())
        },
        crate::lower::types::Bn::BnParts(bs_p7) => crate::lower::node_::Wres::WrParts(each(bs_p7, &part_res)),
        _ => crate::lower::node_::Wres::WrUnit,
    }
}

/// ```prism
/// PartRes: fn ?Bn -> Wres
/// ```
pub fn part_res(b_o0: &Option<crate::lower::types::Bn>) -> crate::lower::node_::Wres {
    match b_o0 {
        Some(b_p1) => bn_res(b_p1),
        None => crate::lower::node_::Wres::WrUnit,
    }
}

/// ```prism
/// SetResult: fn Wx, Wres -> Wx
/// ```
pub fn set_result(wx_p0: &crate::lower::node_::Wx, res_p1: &crate::lower::node_::Wres) -> crate::lower::node_::Wx {
    let mut this: crate::lower::node_::Wx = wx_p0.clone();
    this.result = res_p1.clone();
    this
}

/// ```prism
/// ResultOf: unbounded fn Wx, Env, Env, Expr -> ((Wres, Wx))
/// ```
pub fn result_of(wx_p0: &crate::lower::node_::Wx, benv_p1: &crate::lower::types::Env, menv_p2: &crate::lower::types::Env, x_p3: &crate::syntax::Expr) -> (crate::lower::node_::Wres, crate::lower::node_::Wx) {
    let lx_p4 = wx_p0.lx.clone();
    let full_p5 = crate::lower::type_at(&lx_p4, &x_p3.span);
    let t_p6 = crate::lower::types::out_ty_of(&lx_p4, &crate::lower::types::peel(&full_p5));
    let bound_o7 = match &*x_p3.kind {
        crate::syntax::ExprKind::EName(n_p8) => if &len(&n_p8.path_) == &Nat::from(1u32) {
            get(&menv_p2.names, &crate::check::env::sname_key(n_p8))
        } else {
            None
        },
        _ => None,
    };
    match &bound_o7 {
        Some(crate::lower::types::Bn::BnEv(r_p9, _)) => (crate::lower::node_::Wres::WrEv(r_p9.clone()), wx_p0.clone()),
        Some(crate::lower::types::Bn::BnDyn(ex_pa, rds_pb, bt_pc)) => (crate::lower::node_::Wres::WrDyn(ex_pa.clone(), rds_pb.clone(), bt_pc.clone()), wx_p0.clone()),
        Some(crate::lower::types::Bn::BnParts(bs_pd)) => (bn_res(&crate::lower::types::Bn::BnParts(bs_pd.clone())), wx_p0.clone()),
        _ => match &*x_p3.kind {
            crate::syntax::ExprKind::ETuple(xs_pe) if crate::lower::types::is_bundle(&full_p5) => {
                let (parts_pk, wx2_pl) = run_to_end(fold_job(xs_pe.clone(), (Array::new(), wx_p0.clone()), {
                    let benv_p1 = benv_p1.clone();
                    let menv_p2 = menv_p2.clone();
                    Rc::new(move |(p0, p1): ((Array<crate::lower::node_::Wres>, crate::lower::node_::Wx), crate::syntax::Expr)| {
                        let benv_p1 = benv_p1.clone();
                        let menv_p2 = menv_p2.clone();
                        entered(once_job(move || {
                            let (acc_pf, w_pg) = p0;
                            let y_ph = p1;
                            call_then(start_result_of(w_pg.clone(), benv_p1.clone(), menv_p2.clone(), y_ph.clone()), move |result_of_24875: (crate::lower::node_::Wres, crate::lower::node_::Wx)| {
                                let (r_pi, w2_pj) = result_of_24875;
                                prism_rtl::Turn::Finished((push(&acc_pf, &r_pi), w2_pj.clone()))
                            })
                        }))
                    }) as Rc<dyn Fn(((Array<crate::lower::node_::Wres>, crate::lower::node_::Wx), crate::syntax::Expr)) -> Rc<dyn prism_rtl::Job<(Array<crate::lower::node_::Wres>, crate::lower::node_::Wx)>>>
                }));
                (crate::lower::node_::Wres::WrParts(parts_pk.clone()), wx2_pl.clone())
            },
            _ => result_of_typed(wx_p0, benv_p1, menv_p2, x_p3, &full_p5, &t_p6),
            _ => unreachable!("no arm matched"),
        },
    }
}

/// The step machine of `ResultOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ResultOf: unbounded fn Wx, Env, Env, Expr -> ((Wres, Wx))
/// ```
pub struct ResultOf {
    pub wx_p0: crate::lower::node_::Wx,
    pub benv_p1: crate::lower::types::Env,
    pub menv_p2: crate::lower::types::Env,
    pub x_p3: crate::syntax::Expr,
}

impl prism_rtl::Job<(crate::lower::node_::Wres, crate::lower::node_::Wx)> for ResultOf {
    fn cycle(&self) -> prism_rtl::Turn<(crate::lower::node_::Wres, crate::lower::node_::Wx)> {
        let wx_p0 = &self.wx_p0;
        let benv_p1 = &self.benv_p1;
        let menv_p2 = &self.menv_p2;
        let x_p3 = &self.x_p3;
        let lx_p4 = wx_p0.lx.clone();
        let full_p5 = crate::lower::type_at(&lx_p4, &x_p3.span);
        let benv_p1 = benv_p1.clone();
        let menv_p2 = menv_p2.clone();
        let wx_p0 = wx_p0.clone();
        let x_p3 = x_p3.clone();
        call_then(crate::lower::types::start_out_ty_of(lx_p4.clone(), crate::lower::types::peel(&full_p5)), move |out_ty_of_24284: crate::lower::model::OutTy| {
            let t_p6 = out_ty_of_24284;
            let bound_o7 = match &*x_p3.kind {
                crate::syntax::ExprKind::EName(n_p8) => if &len(&n_p8.path_) == &Nat::from(1u32) {
                    get(&menv_p2.names, &crate::check::env::sname_key(n_p8))
                } else {
                    None
                },
                _ => None,
            };
            match &bound_o7 {
                Some(crate::lower::types::Bn::BnEv(r_p9, _)) => prism_rtl::Turn::Finished((crate::lower::node_::Wres::WrEv(r_p9.clone()), wx_p0.clone())),
                Some(crate::lower::types::Bn::BnDyn(ex_pa, rds_pb, bt_pc)) => prism_rtl::Turn::Finished((crate::lower::node_::Wres::WrDyn(ex_pa.clone(), rds_pb.clone(), bt_pc.clone()), wx_p0.clone())),
                Some(crate::lower::types::Bn::BnParts(bs_pd)) => prism_rtl::Turn::Finished((bn_res(&crate::lower::types::Bn::BnParts(bs_pd.clone())), wx_p0.clone())),
                _ => match &*x_p3.kind {
                    crate::syntax::ExprKind::ETuple(xs_pe) if crate::lower::types::is_bundle(&full_p5) => {
                        let xs_pe = xs_pe.clone();
                        call_value(fold_job(xs_pe.clone(), (Array::new(), wx_p0.clone()), {
                            let benv_p1 = benv_p1.clone();
                            let menv_p2 = menv_p2.clone();
                            Rc::new(move |(p0, p1): ((Array<crate::lower::node_::Wres>, crate::lower::node_::Wx), crate::syntax::Expr)| {
                                let benv_p1 = benv_p1.clone();
                                let menv_p2 = menv_p2.clone();
                                entered(once_job(move || {
                                    let (acc_pf, w_pg) = p0;
                                    let y_ph = p1;
                                    call_then(start_result_of(w_pg.clone(), benv_p1.clone(), menv_p2.clone(), y_ph.clone()), move |result_of_24875: (crate::lower::node_::Wres, crate::lower::node_::Wx)| {
                                        let (r_pi, w2_pj) = result_of_24875;
                                        prism_rtl::Turn::Finished((push(&acc_pf, &r_pi), w2_pj.clone()))
                                    })
                                }))
                            }) as Rc<dyn Fn(((Array<crate::lower::node_::Wres>, crate::lower::node_::Wx), crate::syntax::Expr)) -> Rc<dyn prism_rtl::Job<(Array<crate::lower::node_::Wres>, crate::lower::node_::Wx)>>>
                        }), move |fold_24799: (Array<crate::lower::node_::Wres>, crate::lower::node_::Wx)| {
                            let (parts_pk, wx2_pl) = fold_24799;
                            prism_rtl::Turn::Finished((crate::lower::node_::Wres::WrParts(parts_pk.clone()), wx2_pl.clone()))
                        })
                    },
                    _ => prism_rtl::Turn::More(Rc::new(ResultOfTyped { wx_p0: wx_p0.clone(), benv_p1: benv_p1.clone(), menv_p2: menv_p2.clone(), x_p3: x_p3.clone(), full_p4: full_p5.clone(), t_p5: t_p6.clone() })),
                    _ => unreachable!("no arm matched"),
                },
            }
        })
    }
}

/// `Start ResultOf, x`: what the function value is when passed to `@Run`.
pub fn start_result_of(wx_p0: crate::lower::node_::Wx, benv_p1: crate::lower::types::Env, menv_p2: crate::lower::types::Env, x_p3: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<(crate::lower::node_::Wres, crate::lower::node_::Wx)>> {
    Rc::new(ResultOf { wx_p0, benv_p1, menv_p2, x_p3 })
}

/// ```prism
/// ResultOfTyped: unbounded fn Wx, Env, Env, Expr, Ty, OutTy -> ((Wres, Wx))
/// ```
pub fn result_of_typed(wx_p0: &crate::lower::node_::Wx, benv_p1: &crate::lower::types::Env, menv_p2: &crate::lower::types::Env, x_p3: &crate::syntax::Expr, full_p4: &crate::check::types::Ty, t_p5: &crate::lower::model::OutTy) -> (crate::lower::node_::Wres, crate::lower::node_::Wx) {
    let lx_p6 = wx_p0.lx.clone();
    match crate::lower::types::layer_of(full_p4) {
        crate::lower::types::Layer::LyEv => {
            let (r_p7, wx2_p8) = crate::lower::node_::dynamics::event_ref(wx_p0, menv_p2, x_p3);
            (crate::lower::node_::Wres::WrEv(r_p7.clone()), wx2_p8.clone())
        },
        crate::lower::types::Layer::LyDyn => {
            let (ex_p9, reads_pa) = crate::lower::node_::dynamics::dynamic_expr(wx_p0, menv_p2, x_p3);
            (crate::lower::node_::Wres::WrDyn(ex_p9.clone(), reads_pa.clone(), t_p5.clone()), wx_p0.clone())
        },
        _ => if t_p5 == &crate::lower::model::OutTy::OutUnit {
            (crate::lower::node_::Wres::WrUnit, wx_p0.clone())
        } else {
            (crate::lower::node_::Wres::WrPlain(crate::lower::types::own(&crate::lower::expr::value_of(&lx_p6, benv_p1, x_p3)), t_p5.clone()), wx_p0.clone())
        },
    }
}

/// The step machine of `ResultOfTyped`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ResultOfTyped: unbounded fn Wx, Env, Env, Expr, Ty, OutTy -> ((Wres, Wx))
/// ```
pub struct ResultOfTyped {
    pub wx_p0: crate::lower::node_::Wx,
    pub benv_p1: crate::lower::types::Env,
    pub menv_p2: crate::lower::types::Env,
    pub x_p3: crate::syntax::Expr,
    pub full_p4: crate::check::types::Ty,
    pub t_p5: crate::lower::model::OutTy,
}

impl prism_rtl::Job<(crate::lower::node_::Wres, crate::lower::node_::Wx)> for ResultOfTyped {
    fn cycle(&self) -> prism_rtl::Turn<(crate::lower::node_::Wres, crate::lower::node_::Wx)> {
        let wx_p0 = &self.wx_p0;
        let benv_p1 = &self.benv_p1;
        let menv_p2 = &self.menv_p2;
        let x_p3 = &self.x_p3;
        let full_p4 = &self.full_p4;
        let t_p5 = &self.t_p5;
        let lx_p6 = wx_p0.lx.clone();
        match crate::lower::types::layer_of(full_p4) {
            crate::lower::types::Layer::LyEv => {
                let menv_p2 = menv_p2.clone();
                let wx_p0 = wx_p0.clone();
                let x_p3 = x_p3.clone();
                call_then(crate::lower::node_::dynamics::start_event_ref(wx_p0.clone(), menv_p2.clone(), x_p3.clone()), move |event_ref_25252: (crate::lower::node_::EvRef, crate::lower::node_::Wx)| {
                    let (r_p7, wx2_p8) = event_ref_25252;
                    prism_rtl::Turn::Finished((crate::lower::node_::Wres::WrEv(r_p7.clone()), wx2_p8.clone()))
                })
            },
            crate::lower::types::Layer::LyDyn => {
                let menv_p2 = menv_p2.clone();
                let t_p5 = t_p5.clone();
                let wx_p0 = wx_p0.clone();
                let x_p3 = x_p3.clone();
                call_then(crate::lower::node_::dynamics::start_dynamic_expr(wx_p0.clone(), menv_p2.clone(), x_p3.clone()), move |dynamic_expr_25348: (crate::lower::model::Ex, Array<crate::lower::node_::Read>)| {
                    let (ex_p9, reads_pa) = dynamic_expr_25348;
                    prism_rtl::Turn::Finished((crate::lower::node_::Wres::WrDyn(ex_p9.clone(), reads_pa.clone(), t_p5.clone()), wx_p0.clone()))
                })
            },
            _ => if t_p5 == &crate::lower::model::OutTy::OutUnit {
                prism_rtl::Turn::Finished((crate::lower::node_::Wres::WrUnit, wx_p0.clone()))
            } else {
                {
                    let benv_p1 = benv_p1.clone();
                    let t_p5 = t_p5.clone();
                    let wx_p0 = wx_p0.clone();
                    let x_p3 = x_p3.clone();
                    call_then(crate::lower::expr::start_value_of(lx_p6.clone(), benv_p1.clone(), x_p3.clone()), move |value_of_25511: crate::lower::types::Vl| prism_rtl::Turn::Finished((crate::lower::node_::Wres::WrPlain(crate::lower::types::own(&value_of_25511), t_p5.clone()), wx_p0.clone())))
                }
            },
        }
    }
}

/// `Start ResultOfTyped, x`: what the function value is when passed to `@Run`.
pub fn start_result_of_typed(wx_p0: crate::lower::node_::Wx, benv_p1: crate::lower::types::Env, menv_p2: crate::lower::types::Env, x_p3: crate::syntax::Expr, full_p4: crate::check::types::Ty, t_p5: crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<(crate::lower::node_::Wres, crate::lower::node_::Wx)>> {
    Rc::new(ResultOfTyped { wx_p0, benv_p1, menv_p2, x_p3, full_p4, t_p5 })
}

/// ```prism
/// HoldLine: unbounded fn Wx, Env, Env, Pattern, Expr, Expr -> ((Wx, Env))
/// ```
pub fn hold_line(wx_p0: &crate::lower::node_::Wx, benv_p1: &crate::lower::types::Env, menv_p2: &crate::lower::types::Env, p_p3: &crate::syntax::Pattern_, init_p4: &crate::syntax::Expr, step_p5: &crate::syntax::Expr) -> (crate::lower::node_::Wx, crate::lower::types::Env) {
    let lx_p6 = wx_p0.lx.clone();
    match binding_of(menv_p2, p_p3) {
        Some(crate::lower::types::Bn::BnHold(f_p7, t_p8)) => {
            let iv_p9 = crate::lower::types::own(&crate::lower::expr::value_of(&lx_p6, benv_p1, init_p4));
            let wx1_pa = crate::lower::node_::add_field(wx_p0, &f_p7, &crate::lower::model::OutTy::OutHold(Rc::new(t_p8.clone())), &Text::from(format!("`{}`", &pat_text(p_p3))), &crate::lower::model::Ex::XCall(Text::lit("Hold::new"), Array::from(vec![crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(Text::from(format!("{}_init", &f_p7))))), crate::lower::model::Ex::XCx])));
            let (r_pc, wx2_pd) = crate::lower::node_::dynamics::event_ref(&wx1_pa, menv_p2, step_p5);
            let wx3_pb = {
                let mut this: crate::lower::node_::Wx = crate::lower::node_::connect(&wx2_pd, &r_pc, &crate::lower::node_::Sk::SkHold(f_p7.clone()));
                this.lets = push(&this.lets, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaBind(Text::from(format!("{}_init", &f_p7)))), t_p8.clone()), iv_p9.clone()));
                this.inited = push(&this.inited, &f_p7);
                this
            };
            (wx3_pb.clone(), crate::lower::types::bind(benv_p1, &Text::from(format!("{}#init", &pat_text(p_p3))), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(Text::from(format!("{}_init", &f_p7))), crate::lower::types::Holding::Owned, t_p8.clone())))
        },
        _ => (wx_p0.clone(), benv_p1.clone()),
    }
}

/// The step machine of `HoldLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// HoldLine: unbounded fn Wx, Env, Env, Pattern, Expr, Expr -> ((Wx, Env))
/// ```
pub struct HoldLine {
    pub wx_p0: crate::lower::node_::Wx,
    pub benv_p1: crate::lower::types::Env,
    pub menv_p2: crate::lower::types::Env,
    pub p_p3: crate::syntax::Pattern_,
    pub init_p4: crate::syntax::Expr,
    pub step_p5: crate::syntax::Expr,
}

impl prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env)> for HoldLine {
    fn cycle(&self) -> prism_rtl::Turn<(crate::lower::node_::Wx, crate::lower::types::Env)> {
        let wx_p0 = &self.wx_p0;
        let benv_p1 = &self.benv_p1;
        let menv_p2 = &self.menv_p2;
        let p_p3 = &self.p_p3;
        let init_p4 = &self.init_p4;
        let step_p5 = &self.step_p5;
        let lx_p6 = wx_p0.lx.clone();
        match binding_of(menv_p2, p_p3) {
            Some(crate::lower::types::Bn::BnHold(f_p7, t_p8)) => {
                let benv_p1 = benv_p1.clone();
                let init_p4 = init_p4.clone();
                let menv_p2 = menv_p2.clone();
                let p_p3 = p_p3.clone();
                let step_p5 = step_p5.clone();
                let wx_p0 = wx_p0.clone();
                call_then(crate::lower::expr::start_value_of(lx_p6.clone(), benv_p1.clone(), init_p4.clone()), move |value_of_26066: crate::lower::types::Vl| {
                    let iv_p9 = crate::lower::types::own(&value_of_26066);
                    let wx1_pa = crate::lower::node_::add_field(&wx_p0, &f_p7, &crate::lower::model::OutTy::OutHold(Rc::new(t_p8.clone())), &Text::from(format!("`{}`", &pat_text(&p_p3))), &crate::lower::model::Ex::XCall(Text::lit("Hold::new"), Array::from(vec![crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(Text::from(format!("{}_init", &f_p7))))), crate::lower::model::Ex::XCx])));
                    call_then(crate::lower::node_::dynamics::start_event_ref(wx1_pa.clone(), menv_p2.clone(), step_p5.clone()), move |event_ref_26244: (crate::lower::node_::EvRef, crate::lower::node_::Wx)| {
                        let (r_pc, wx2_pd) = event_ref_26244;
                        let wx3_pb = {
                            let mut this: crate::lower::node_::Wx = crate::lower::node_::connect(&wx2_pd, &r_pc, &crate::lower::node_::Sk::SkHold(f_p7.clone()));
                            this.lets = push(&this.lets, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaBind(Text::from(format!("{}_init", &f_p7)))), t_p8.clone()), iv_p9.clone()));
                            this.inited = push(&this.inited, &f_p7);
                            this
                        };
                        prism_rtl::Turn::Finished((wx3_pb.clone(), crate::lower::types::bind(&benv_p1, &Text::from(format!("{}#init", &pat_text(&p_p3))), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(Text::from(format!("{}_init", &f_p7))), crate::lower::types::Holding::Owned, t_p8.clone()))))
                    })
                })
            },
            _ => prism_rtl::Turn::Finished((wx_p0.clone(), benv_p1.clone())),
        }
    }
}

/// `Start HoldLine, x`: what the function value is when passed to `@Run`.
pub fn start_hold_line(wx_p0: crate::lower::node_::Wx, benv_p1: crate::lower::types::Env, menv_p2: crate::lower::types::Env, p_p3: crate::syntax::Pattern_, init_p4: crate::syntax::Expr, step_p5: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env)>> {
    Rc::new(HoldLine { wx_p0, benv_p1, menv_p2, p_p3, init_p4, step_p5 })
}

/// ```prism
/// InitEnv: fn Env -> Env
/// ```
pub fn init_env(env_p0: &crate::lower::types::Env) -> crate::lower::types::Env {
    fold(&keys(&env_p0.names), env_p0, &(|en_p1: &crate::lower::types::Env, k_p2: &Text| match (crate::syntax::lexer::chars::before_suffix(k_p2, &Text::lit("#init")), get(&env_p0.names, k_p2)) {
        (Some(name_p3), Some(b_p4)) => crate::lower::types::bind(en_p1, &name_p3, &b_p4),
        _ => en_p1.clone(),
    }))
}

/// ```prism
/// AllInited: fn Wx, [Read] -> Bool
/// ```
pub fn all_inited(wx_p0: &crate::lower::node_::Wx, reads_p1: &Array<crate::lower::node_::Read>) -> bool {
    fold(&crate::lower::node_::finish::reads_closed(&wx_p0.dyn_reads, reads_p1), &true, &(|ok_p2: &bool, r_p3: &crate::lower::node_::Read| *ok_p2 && match r_p3 {
        crate::lower::node_::Read::OwnRead(f_p4) => crate::check::types::has_text(&wx_p0.inited, f_p4),
        crate::lower::node_::Read::ParentRead(_) => false,
    }))
}

/// ```prism
/// NamesInited: unbounded fn Env, Expr -> Bool
/// ```
pub fn names_inited(env_p0: &crate::lower::types::Env, e_p1: &crate::syntax::Expr) -> bool {
    fold(&crate::lower::expr::read_names(&crate::check::typed::print::exprs_in(e_p1)), &true, &(|ok_p2: &bool, n_p3: &Text| *ok_p2 && match get(&env_p0.names, n_p3) {
        Some(crate::lower::types::Bn::BnDyn(_, _, _)) => crate::check::env::has_key(&env_p0.names, &Text::from(format!("{}#init", n_p3))),
        Some(crate::lower::types::Bn::BnHold(_, _)) => crate::check::env::has_key(&env_p0.names, &Text::from(format!("{}#init", n_p3))),
        _ => true,
    }))
}

/// The step machine of `NamesInited`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// NamesInited: unbounded fn Env, Expr -> Bool
/// ```
pub struct NamesInited {
    pub env_p0: crate::lower::types::Env,
    pub e_p1: crate::syntax::Expr,
}

impl prism_rtl::Job<bool> for NamesInited {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let env_p0 = &self.env_p0;
        let e_p1 = &self.e_p1;
        let e_p1 = e_p1.clone();
        let env_p0 = env_p0.clone();
        call_then(crate::check::typed::print::start_exprs_in(e_p1.clone()), move |exprs_in_27763: Array<crate::syntax::Expr>| call_then(crate::lower::expr::start_read_names(exprs_in_27763), move |read_names_27752: Array<Text>| prism_rtl::Turn::Finished(fold(&read_names_27752, &true, &(|ok_p2: &bool, n_p3: &Text| *ok_p2 && match get(&env_p0.names, n_p3) {
            Some(crate::lower::types::Bn::BnDyn(_, _, _)) => crate::check::env::has_key(&env_p0.names, &Text::from(format!("{}#init", n_p3))),
            Some(crate::lower::types::Bn::BnHold(_, _)) => crate::check::env::has_key(&env_p0.names, &Text::from(format!("{}#init", n_p3))),
            _ => true,
        })))))
    }
}

/// `Start NamesInited, x`: what the function value is when passed to `@Run`.
pub fn start_names_inited(env_p0: crate::lower::types::Env, e_p1: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(NamesInited { env_p0, e_p1 })
}

/// ```prism
/// PatText: fn Pattern -> Text
/// ```
pub fn pat_text(p_p0: &crate::syntax::Pattern_) -> Text {
    match &*p_p0.kind {
        crate::syntax::PatternKind::PName(n_p1) => crate::check::env::sname_key(n_p1),
        _ => Text::lit("_"),
    }
}

/// ```prism
/// LetLine: unbounded fn Wx, Env, Env, Pattern, Expr -> ((Wx, Env))
/// ```
pub fn let_line(wx_p0: &crate::lower::node_::Wx, benv_p1: &crate::lower::types::Env, menv_p2: &crate::lower::types::Env, p_p3: &crate::syntax::Pattern_, e_p4: &crate::syntax::Expr) -> (crate::lower::node_::Wx, crate::lower::types::Env) {
    let lx_p5 = wx_p0.lx.clone();
    match binding_of(menv_p2, p_p3) {
        Some(crate::lower::types::Bn::BnEv(er_p6, t_p7)) => {
            let (r_pa, wx2_pb) = crate::lower::node_::dynamics::event_ref(wx_p0, menv_p2, e_p4);
            let fed_p8 = crate::lower::types::out_ty_of(&lx_p5, &crate::lower::types::peel(&crate::lower::types::peel(&crate::lower::type_at(&lx_p5, &e_p4.span))));
            let r2_p9 = 'm28639: {
                if let crate::lower::model::OutTy::OutEvent(m28639_0_0) = &t_p7 && let crate::lower::model::OutTy::OutRes(_) = &**m28639_0_0 {
                    break 'm28639 if &fed_p8 == &crate::lower::model::OutTy::OutError {
                        err_pipe(&r_pa)
                    } else {
                        r_pa.clone()
                    };
                }
                if let crate::lower::model::OutTy::OutRes(_) = &t_p7 {
                    break 'm28639 if &fed_p8 == &crate::lower::model::OutTy::OutError {
                        err_pipe(&r_pa)
                    } else {
                        r_pa.clone()
                    };
                }
                r_pa.clone()
            };
            (crate::lower::node_::connect(&wx2_pb, &r2_p9, &crate::lower::node_::Sk::SkNode(er_p6.node_.clone())), benv_p1.clone())
        },
        Some(crate::lower::types::Bn::BnDyn(_, _, t_pc)) => {
            let rs_pd = crate::lower::snake(&pat_text(p_p3));
            let (ex_pj, reads_pk) = crate::lower::node_::dynamics::dynamic_expr(wx_p0, menv_p2, e_p4);
            let cached_pe = (&len(&reads_pk) > &Nat::from(0u32)) && fold(&crate::lower::node_::finish::reads_all(&wx_p0.dyn_reads, &reads_pk), &true, &(|ok_pl: &bool, r_pm: &crate::lower::node_::Read| *ok_pl && crate::lower::node_::finish::is_own_read(r_pm)));
            let tail_pf = if cached_pe {
                crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_cache", &rs_pd)))), Text::lit("get"), Array::from(vec![crate::lower::model::Ex::XCx, crate::lower::model::Ex::XClosure(false, Array::new(), Rc::new(ex_pj.clone()))]))
            } else {
                ex_pj.clone()
            };
            let getter_pg = crate::lower::model::MethDef { name: rs_pd.clone(), recv: crate::lower::model::Recv::RecvRef, params: Array::new(), cx_: crate::lower::model::CxArg::CxRef, ret: t_pc.clone(), body: Array::new(), tail: tail_pf.clone(), doc: Text::from(format!("`{}`", &pat_text(p_p3))) };
            let wx1_ph = if cached_pe {
                {
                    let mut this: crate::lower::node_::Wx = crate::lower::node_::add_field(wx_p0, &Text::from(format!("{}_cache", &rs_pd)), &crate::lower::model::OutTy::OutNamed(Text::lit("Cache"), Array::from(vec![t_pc.clone()])), &Text::from(format!("`{}`, cached", &pat_text(p_p3))), &crate::lower::model::Ex::XCall(Text::lit("Cache::new"), Array::new()));
                    this.let_caches = push(&this.let_caches, &rs_pd);
                    this.taken = push(&this.taken, &Text::from(format!("{}_cache", &rs_pd)));
                    this
                }
            } else {
                wx_p0.clone()
            };
            let wx2_pi = {
                let mut this: crate::lower::node_::Wx = wx1_ph.clone();
                this.getters = push(&this.getters, &getter_pg);
                this.dyn_reads = insert(&this.dyn_reads, &rs_pd, &reads_pk);
                this
            };
            if all_inited(&wx2_pi, &reads_pk) && names_inited(benv_p1, e_p4) {
                {
                    let wx3_pn = {
                        let mut this: crate::lower::node_::Wx = wx2_pi.clone();
                        this.lets = push(&this.lets, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaBind(Text::from(format!("{}_init", &rs_pd)))), t_pc.clone()), crate::lower::types::own(&crate::lower::expr::value_of(&lx_p5, &init_env(benv_p1), e_p4))));
                        this.inited = push(&this.inited, &rs_pd);
                        this
                    };
                    (wx3_pn.clone(), crate::lower::types::bind(benv_p1, &Text::from(format!("{}#init", &pat_text(p_p3))), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(Text::from(format!("{}_init", &rs_pd))), crate::lower::types::Holding::Owned, t_pc.clone())))
                }
            } else {
                (wx2_pi.clone(), benv_p1.clone())
            }
        },
        Some(crate::lower::types::Bn::BnLocal(rs_po, _, t_pp)) => {
            let insts_oq = match &*p_p3.kind {
                crate::syntax::PatternKind::PName(n_pr) => many_instances(&lx_p5, &n_pr.span),
                _ => None,
            };
            match &insts_oq {
                Some(insts_ps) => match &*p_p3.kind {
                    crate::syntax::PatternKind::PName(n_pt) => {
                        let nkey_pu = crate::check::env::sname_key(n_pt);
                        let wxn_pv = run_to_end(fold_job(crate::check::errors::range0(&len(insts_ps)), wx_p0.clone(), {
                            let lx_p5 = lx_p5.clone();
                            let insts_ps = insts_ps.clone();
                            let nkey_pu = nkey_pu.clone();
                            let menv_p2 = menv_p2.clone();
                            let benv_p1 = benv_p1.clone();
                            let e_p4 = e_p4.clone();
                            Rc::new(move |(p0, p1): (crate::lower::node_::Wx, Nat)| {
                                let lx_p5 = lx_p5.clone();
                                let insts_ps = insts_ps.clone();
                                let nkey_pu = nkey_pu.clone();
                                let menv_p2 = menv_p2.clone();
                                let benv_p1 = benv_p1.clone();
                                let e_p4 = e_p4.clone();
                                entered(once_job(move || {
                                    let w_p10 = p0;
                                    let k_p11 = p1;
                                    {
                                        let lxk_p12 = crate::lower::expr::at_instance(&lx_p5, &or(&index(&insts_ps, &k_p11), &(Array::new(), Array::new())));
                                        let bkey_p13 = if &k_p11 == &Nat::from(0u32) {
                                            nkey_pu.clone()
                                        } else {
                                            Text::from(format!("{}#inst{}", &nkey_pu, &k_p11))
                                        };
                                        match get(&menv_p2.names, &bkey_p13) {
                                            Some(crate::lower::types::Bn::BnLocal(rk_p14, _, tk_p15)) => call_then(crate::lower::expr::start_value_of(lxk_p12.clone(), benv_p1.clone(), e_p4.clone()), move |value_of_31300: crate::lower::types::Vl| prism_rtl::Turn::Finished(widget_let_field(&w_p10, &crate::lower::types::place_stem(&rk_p14), &tk_p15, &crate::lower::types::own(&value_of_31300), &Text::from(format!("`{}` at its instantiation {}", &nkey_pu, &k_p11))))),
                                            _ => prism_rtl::Turn::Finished({
                                                let mut this: crate::lower::node_::Wx = w_p10.clone();
                                                this.build = push(&this.build, &crate::lower::expr::refusal_do(&Text::from(format!("`{}` at its instantiation {}, which has no binding", &nkey_pu, &k_p11))));
                                                this
                                            }),
                                        }
                                    }
                                }))
                            }) as Rc<dyn Fn((crate::lower::node_::Wx, Nat)) -> Rc<dyn prism_rtl::Job<crate::lower::node_::Wx>>>
                        }));
                        (wxn_pv.clone(), benv_p1.clone())
                    },
                    _ => (wx_p0.clone(), benv_p1.clone()),
                },
                None => {
                    let lxw_p16 = match &*p_p3.kind {
                        crate::syntax::PatternKind::PName(n_p18) => crate::lower::expr::widget_let_lx(&lx_p5, &n_p18.span),
                        _ => lx_p5.clone(),
                    };
                    let v_p17 = crate::lower::types::own(&crate::lower::expr::value_of(&lxw_p16, benv_p1, e_p4));
                    (widget_let_field(wx_p0, &crate::lower::types::place_stem(&rs_po), &t_pp, &v_p17, &Text::from(format!("`{}`", &pat_text(p_p3)))), benv_p1.clone())
                },
            }
        },
        _ => (wx_p0.clone(), benv_p1.clone()),
    }
}

/// The step machine of `LetLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LetLine: unbounded fn Wx, Env, Env, Pattern, Expr -> ((Wx, Env))
/// ```
pub struct LetLine {
    pub wx_p0: crate::lower::node_::Wx,
    pub benv_p1: crate::lower::types::Env,
    pub menv_p2: crate::lower::types::Env,
    pub p_p3: crate::syntax::Pattern_,
    pub e_p4: crate::syntax::Expr,
}

impl prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env)> for LetLine {
    fn cycle(&self) -> prism_rtl::Turn<(crate::lower::node_::Wx, crate::lower::types::Env)> {
        let wx_p0 = &self.wx_p0;
        let benv_p1 = &self.benv_p1;
        let menv_p2 = &self.menv_p2;
        let p_p3 = &self.p_p3;
        let e_p4 = &self.e_p4;
        let lx_p5 = wx_p0.lx.clone();
        match binding_of(menv_p2, p_p3) {
            Some(crate::lower::types::Bn::BnEv(er_p6, t_p7)) => {
                let benv_p1 = benv_p1.clone();
                let e_p4 = e_p4.clone();
                let menv_p2 = menv_p2.clone();
                let wx_p0 = wx_p0.clone();
                call_then(crate::lower::node_::dynamics::start_event_ref(wx_p0.clone(), menv_p2.clone(), e_p4.clone()), move |event_ref_28529: (crate::lower::node_::EvRef, crate::lower::node_::Wx)| {
                    let (r_pa, wx2_pb) = event_ref_28529;
                    call_then(crate::lower::types::start_out_ty_of(lx_p5.clone(), crate::lower::types::peel(&crate::lower::types::peel(&crate::lower::type_at(&lx_p5, &e_p4.span)))), move |out_ty_of_28572: crate::lower::model::OutTy| {
                        let fed_p8 = out_ty_of_28572;
                        let r2_p9 = 'm28639: {
                            if let crate::lower::model::OutTy::OutEvent(m28639_0_0) = &t_p7 && let crate::lower::model::OutTy::OutRes(_) = &**m28639_0_0 {
                                break 'm28639 if &fed_p8 == &crate::lower::model::OutTy::OutError {
                                    err_pipe(&r_pa)
                                } else {
                                    r_pa.clone()
                                };
                            }
                            if let crate::lower::model::OutTy::OutRes(_) = &t_p7 {
                                break 'm28639 if &fed_p8 == &crate::lower::model::OutTy::OutError {
                                    err_pipe(&r_pa)
                                } else {
                                    r_pa.clone()
                                };
                            }
                            r_pa.clone()
                        };
                        prism_rtl::Turn::Finished((crate::lower::node_::connect(&wx2_pb, &r2_p9, &crate::lower::node_::Sk::SkNode(er_p6.node_.clone())), benv_p1.clone()))
                    })
                })
            },
            Some(crate::lower::types::Bn::BnDyn(_, _, t_pc)) => {
                let rs_pd = crate::lower::snake(&pat_text(p_p3));
                let benv_p1 = benv_p1.clone();
                let e_p4 = e_p4.clone();
                let menv_p2 = menv_p2.clone();
                let p_p3 = p_p3.clone();
                let wx_p0 = wx_p0.clone();
                call_then(crate::lower::node_::dynamics::start_dynamic_expr(wx_p0.clone(), menv_p2.clone(), e_p4.clone()), move |dynamic_expr_28992: (crate::lower::model::Ex, Array<crate::lower::node_::Read>)| {
                    let (ex_pj, reads_pk) = dynamic_expr_28992;
                    let cached_pe = (&len(&reads_pk) > &Nat::from(0u32)) && fold(&crate::lower::node_::finish::reads_all(&wx_p0.dyn_reads, &reads_pk), &true, &(|ok_pl: &bool, r_pm: &crate::lower::node_::Read| *ok_pl && crate::lower::node_::finish::is_own_read(r_pm)));
                    let tail_pf = if cached_pe {
                        crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_cache", &rs_pd)))), Text::lit("get"), Array::from(vec![crate::lower::model::Ex::XCx, crate::lower::model::Ex::XClosure(false, Array::new(), Rc::new(ex_pj.clone()))]))
                    } else {
                        ex_pj.clone()
                    };
                    let getter_pg = crate::lower::model::MethDef { name: rs_pd.clone(), recv: crate::lower::model::Recv::RecvRef, params: Array::new(), cx_: crate::lower::model::CxArg::CxRef, ret: t_pc.clone(), body: Array::new(), tail: tail_pf.clone(), doc: Text::from(format!("`{}`", &pat_text(&p_p3))) };
                    let wx1_ph = if cached_pe {
                        {
                            let mut this: crate::lower::node_::Wx = crate::lower::node_::add_field(&wx_p0, &Text::from(format!("{}_cache", &rs_pd)), &crate::lower::model::OutTy::OutNamed(Text::lit("Cache"), Array::from(vec![t_pc.clone()])), &Text::from(format!("`{}`, cached", &pat_text(&p_p3))), &crate::lower::model::Ex::XCall(Text::lit("Cache::new"), Array::new()));
                            this.let_caches = push(&this.let_caches, &rs_pd);
                            this.taken = push(&this.taken, &Text::from(format!("{}_cache", &rs_pd)));
                            this
                        }
                    } else {
                        wx_p0.clone()
                    };
                    let wx2_pi = {
                        let mut this: crate::lower::node_::Wx = wx1_ph.clone();
                        this.getters = push(&this.getters, &getter_pg);
                        this.dyn_reads = insert(&this.dyn_reads, &rs_pd, &reads_pk);
                        this
                    };
                    if all_inited(&wx2_pi, &reads_pk) && names_inited(&benv_p1, &e_p4) {
                        {
                            let wx3_pn = {
                                let mut this: crate::lower::node_::Wx = wx2_pi.clone();
                                this.lets = push(&this.lets, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaBind(Text::from(format!("{}_init", &rs_pd)))), t_pc.clone()), crate::lower::types::own(&crate::lower::expr::value_of(&lx_p5, &init_env(&benv_p1), &e_p4))));
                                this.inited = push(&this.inited, &rs_pd);
                                this
                            };
                            prism_rtl::Turn::Finished((wx3_pn.clone(), crate::lower::types::bind(&benv_p1, &Text::from(format!("{}#init", &pat_text(&p_p3))), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(Text::from(format!("{}_init", &rs_pd))), crate::lower::types::Holding::Owned, t_pc.clone()))))
                        }
                    } else {
                        prism_rtl::Turn::Finished((wx2_pi.clone(), benv_p1.clone()))
                    }
                })
            },
            Some(crate::lower::types::Bn::BnLocal(rs_po, _, t_pp)) => {
                let insts_oq = match &*p_p3.kind {
                    crate::syntax::PatternKind::PName(n_pr) => many_instances(&lx_p5, &n_pr.span),
                    _ => None,
                };
                match &insts_oq {
                    Some(insts_ps) => match &*p_p3.kind {
                        crate::syntax::PatternKind::PName(n_pt) => {
                            let nkey_pu = crate::check::env::sname_key(n_pt);
                            let benv_p1 = benv_p1.clone();
                            let e_p4 = e_p4.clone();
                            let insts_ps = insts_ps.clone();
                            let menv_p2 = menv_p2.clone();
                            let wx_p0 = wx_p0.clone();
                            call_value(fold_job(crate::check::errors::range0(&len(&insts_ps)), wx_p0.clone(), {
                                let lx_p5 = lx_p5.clone();
                                let insts_ps = insts_ps.clone();
                                let nkey_pu = nkey_pu.clone();
                                let menv_p2 = menv_p2.clone();
                                let benv_p1 = benv_p1.clone();
                                let e_p4 = e_p4.clone();
                                Rc::new(move |(p0, p1): (crate::lower::node_::Wx, Nat)| {
                                    let lx_p5 = lx_p5.clone();
                                    let insts_ps = insts_ps.clone();
                                    let nkey_pu = nkey_pu.clone();
                                    let menv_p2 = menv_p2.clone();
                                    let benv_p1 = benv_p1.clone();
                                    let e_p4 = e_p4.clone();
                                    entered(once_job(move || {
                                        let w_p10 = p0;
                                        let k_p11 = p1;
                                        {
                                            let lxk_p12 = crate::lower::expr::at_instance(&lx_p5, &or(&index(&insts_ps, &k_p11), &(Array::new(), Array::new())));
                                            let bkey_p13 = if &k_p11 == &Nat::from(0u32) {
                                                nkey_pu.clone()
                                            } else {
                                                Text::from(format!("{}#inst{}", &nkey_pu, &k_p11))
                                            };
                                            match get(&menv_p2.names, &bkey_p13) {
                                                Some(crate::lower::types::Bn::BnLocal(rk_p14, _, tk_p15)) => call_then(crate::lower::expr::start_value_of(lxk_p12.clone(), benv_p1.clone(), e_p4.clone()), move |value_of_31300: crate::lower::types::Vl| prism_rtl::Turn::Finished(widget_let_field(&w_p10, &crate::lower::types::place_stem(&rk_p14), &tk_p15, &crate::lower::types::own(&value_of_31300), &Text::from(format!("`{}` at its instantiation {}", &nkey_pu, &k_p11))))),
                                                _ => prism_rtl::Turn::Finished({
                                                    let mut this: crate::lower::node_::Wx = w_p10.clone();
                                                    this.build = push(&this.build, &crate::lower::expr::refusal_do(&Text::from(format!("`{}` at its instantiation {}, which has no binding", &nkey_pu, &k_p11))));
                                                    this
                                                }),
                                            }
                                        }
                                    }))
                                }) as Rc<dyn Fn((crate::lower::node_::Wx, Nat)) -> Rc<dyn prism_rtl::Job<crate::lower::node_::Wx>>>
                            }), move |fold_30944: crate::lower::node_::Wx| {
                                let wxn_pv = fold_30944;
                                prism_rtl::Turn::Finished((wxn_pv.clone(), benv_p1.clone()))
                            })
                        },
                        _ => prism_rtl::Turn::Finished((wx_p0.clone(), benv_p1.clone())),
                    },
                    None => {
                        let lxw_p16 = match &*p_p3.kind {
                            crate::syntax::PatternKind::PName(n_p18) => crate::lower::expr::widget_let_lx(&lx_p5, &n_p18.span),
                            _ => lx_p5.clone(),
                        };
                        let benv_p1 = benv_p1.clone();
                        let e_p4 = e_p4.clone();
                        let p_p3 = p_p3.clone();
                        let wx_p0 = wx_p0.clone();
                        call_then(crate::lower::expr::start_value_of(lxw_p16.clone(), benv_p1.clone(), e_p4.clone()), move |value_of_31820: crate::lower::types::Vl| {
                            let v_p17 = crate::lower::types::own(&value_of_31820);
                            prism_rtl::Turn::Finished((widget_let_field(&wx_p0, &crate::lower::types::place_stem(&rs_po), &t_pp, &v_p17, &Text::from(format!("`{}`", &pat_text(&p_p3)))), benv_p1.clone()))
                        })
                    },
                }
            },
            _ => prism_rtl::Turn::Finished((wx_p0.clone(), benv_p1.clone())),
        }
    }
}

/// `Start LetLine, x`: what the function value is when passed to `@Run`.
pub fn start_let_line(wx_p0: crate::lower::node_::Wx, benv_p1: crate::lower::types::Env, menv_p2: crate::lower::types::Env, p_p3: crate::syntax::Pattern_, e_p4: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env)>> {
    Rc::new(LetLine { wx_p0, benv_p1, menv_p2, p_p3, e_p4 })
}

/// ```prism
/// WidgetLetField: fn Wx, Text, OutTy, Ex, Text -> Wx
/// ```
pub fn widget_let_field(wx_p0: &crate::lower::node_::Wx, f_p1: &Text, t_p2: &crate::lower::model::OutTy, v_p3: &crate::lower::model::Ex, doc_p4: &Text) -> crate::lower::node_::Wx {
    let mut this: crate::lower::node_::Wx = wx_p0.clone();
    this.lets = push(&this.lets, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(f_p1.clone()), v_p3.clone()));
    this.fields = push(&this.fields, &(f_p1.clone(), t_p2.clone(), doc_p4.clone()));
    this.inits = push(&this.inits, &(f_p1.clone(), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(f_p1.clone())))));
    this
}

/// ```prism
/// ErrPipe: fn EvRef -> EvRef
/// ```
pub fn err_pipe(r_p0: &crate::lower::node_::EvRef) -> crate::lower::node_::EvRef {
    crate::lower::node_::EvRef { node_: r_p0.node_.clone(), owner: r_p0.owner.clone(), pipe: {
        let r_p0 = r_p0.clone();
        Rc::new(move |(p0, p1): (crate::lower::model::Ex, Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>)| {
            let r_p0 = r_p0.clone();
            entered(once_job(move || {
                let x_p1 = p0;
                let k_f2 = p1;
                (&r_p0.pipe)((x_p1.clone(), {
                    let k_f2 = k_f2.clone();
                    Rc::new(move |p0: crate::lower::model::Ex| {
                        let k_f2 = k_f2.clone();
                        entered(once_job(move || {
                            let y_p3 = p0;
                            (&k_f2)(crate::lower::model::Ex::XCtor(Text::lit("Err"), Array::from(vec![y_p3.clone()]))).cycle()
                        }))
                    }) as Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>
                })).cycle()
            }))
        }) as Rc<dyn Fn((crate::lower::model::Ex, Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>)) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>
    } }
}

/// ```prism
/// OwnAs: fn OutTy, Vl -> Ex
/// ```
pub fn own_as(t_p0: &crate::lower::model::OutTy, v_p1: &crate::lower::types::Vl) -> crate::lower::model::Ex {
    match t_p0 {
        crate::lower::model::OutTy::OutRes(_) => if &crate::lower::types::value_ty(v_p1) == &crate::lower::model::OutTy::OutError {
            crate::lower::model::Ex::XCtor(Text::lit("Err"), Array::from(vec![crate::lower::types::own(v_p1)]))
        } else {
            crate::lower::types::own(v_p1)
        },
        _ => crate::lower::types::own(v_p1),
    }
}

/// ```prism
/// BindRes: fn Wx, Env, Pattern, Wres -> Wx
/// ```
pub fn bind_res(wx2_p0: &crate::lower::node_::Wx, menv_p1: &crate::lower::types::Env, p_p2: &crate::syntax::Pattern_, res_p3: &crate::lower::node_::Wres) -> crate::lower::node_::Wx {
    match binding_of(menv_p1, p_p2) {
        Some(crate::lower::types::Bn::BnEv(er_p4, _)) => match res_p3 {
            crate::lower::node_::Wres::WrEv(r_p5) => if &er_p4.owner != &wx2_p0.node_ {
                crate::lower::node_::crossed(wx2_p0, &Text::from(format!("the bound event of node `{}` (its graph node {})", &er_p4.owner, &er_p4.node_)))
            } else {
                if &r_p5.node_ == &er_p4.node_ {
                    wx2_p0.clone()
                } else {
                    crate::lower::node_::connect(wx2_p0, r_p5, &crate::lower::node_::Sk::SkNode(er_p4.node_.clone()))
                }
            },
            _ => wx2_p0.clone(),
        },
        _ => wx2_p0.clone(),
    }
}

/// ```prism
/// BuildLine: unbounded fn Wx, Env, Env, Expr, ?Bn -> ((Wx, Wres))
/// ```
pub fn build_line(wx_p0: &crate::lower::node_::Wx, benv_p1: &crate::lower::types::Env, menv_p2: &crate::lower::types::Env, e_p3: &crate::syntax::Expr, bound_o4: &Option<crate::lower::types::Bn>) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    let lx_p5 = wx_p0.lx.clone();
    let full_p6 = crate::lower::type_at(&lx_p5, &e_p3.span);
    'm33597: {
        let scrutinee = &*e_p3.kind;
        if let crate::syntax::ExprKind::EGroup(x_p7) = scrutinee {
            break 'm33597 build_line(wx_p0, benv_p1, menv_p2, &**x_p7, bound_o4);
        }
        if let crate::syntax::ExprKind::EWidgetBlock(b_p8) = scrutinee {
            break 'm33597 crate::lower::node_::static_::inline_block(wx_p0, benv_p1, menv_p2, b_p8, &lx_p5);
        }
        if let crate::syntax::ExprKind::EFor(binders_o9, source_pa, body_pb) = scrutinee {
            break 'm33597 crate::lower::node_::keyed::for_line(wx_p0, benv_p1, menv_p2, binders_o9, &**source_pa, body_pb, e_p3, bound_o4);
        }
        if let crate::syntax::ExprKind::ERebuild(scrut_pc, body_pd) = scrutinee {
            break 'm33597 crate::lower::node_::switch_::rebuild_line(wx_p0, benv_p1, menv_p2, &**scrut_pc, body_pd, e_p3, bound_o4);
        }
        if let crate::syntax::ExprKind::EIf(m33597_4_0, then_b_pf, Some(else_b_pg)) = scrutinee && let crate::syntax::Cond::CondExpr(c_pe) = &**m33597_4_0 {
            break 'm33597 crate::lower::functions::if_gen_line(wx_p0, menv_p2, &**c_pe, then_b_pf, else_b_pg, e_p3);
        }
        match crate::lower::types::peel(&full_p6) {
            crate::check::types::Ty::TyElem(_, _) => crate::lower::node_::elements::element_line(wx_p0, benv_p1, menv_p2, e_p3, bound_o4),
            crate::check::types::Ty::TyAt(_, _) => crate::lower::node_::static_::widget_line(wx_p0, benv_p1, menv_p2, e_p3, bound_o4),
            _ => {
                let wx2_ph = {
                    let mut this: crate::lower::node_::Wx = wx_p0.clone();
                    this.build = push(&this.build, &crate::lower::expr::refusal_do(&Text::lit("a building line this back end does not lower yet")));
                    this
                };
                (wx2_ph.clone(), crate::lower::node_::Wres::WrUnit)
            },
        }
    }
}

/// The step machine of `BuildLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BuildLine: unbounded fn Wx, Env, Env, Expr, ?Bn -> ((Wx, Wres))
/// ```
pub struct BuildLine {
    pub wx_p0: crate::lower::node_::Wx,
    pub benv_p1: crate::lower::types::Env,
    pub menv_p2: crate::lower::types::Env,
    pub e_p3: crate::syntax::Expr,
    pub bound_o4: Option<crate::lower::types::Bn>,
}

impl prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::node_::Wres)> for BuildLine {
    fn cycle(&self) -> prism_rtl::Turn<(crate::lower::node_::Wx, crate::lower::node_::Wres)> {
        let wx_p0 = &self.wx_p0;
        let benv_p1 = &self.benv_p1;
        let menv_p2 = &self.menv_p2;
        let e_p3 = &self.e_p3;
        let bound_o4 = &self.bound_o4;
        let lx_p5 = wx_p0.lx.clone();
        let full_p6 = crate::lower::type_at(&lx_p5, &e_p3.span);
        'm33597: {
            let scrutinee = &*e_p3.kind;
            if let crate::syntax::ExprKind::EGroup(x_p7) = scrutinee {
                break 'm33597 prism_rtl::Turn::More(Rc::new(BuildLine { wx_p0: wx_p0.clone(), benv_p1: benv_p1.clone(), menv_p2: menv_p2.clone(), e_p3: (**x_p7).clone(), bound_o4: bound_o4.clone() }));
            }
            if let crate::syntax::ExprKind::EWidgetBlock(b_p8) = scrutinee {
                break 'm33597 prism_rtl::Turn::More(Rc::new(crate::lower::node_::static_::InlineBlock { wx_p0: wx_p0.clone(), benv_p1: benv_p1.clone(), menv_p2: menv_p2.clone(), b_p3: b_p8.clone(), lx_p4: lx_p5.clone() }));
            }
            if let crate::syntax::ExprKind::EFor(binders_o9, source_pa, body_pb) = scrutinee {
                break 'm33597 prism_rtl::Turn::More(Rc::new(crate::lower::node_::keyed::ForLine { wx_p0: wx_p0.clone(), benv_p1: benv_p1.clone(), menv_p2: menv_p2.clone(), binders_o3: binders_o9.clone(), source_p4: (**source_pa).clone(), body_p5: body_pb.clone(), e_p6: e_p3.clone(), bound_o7: bound_o4.clone() }));
            }
            if let crate::syntax::ExprKind::ERebuild(scrut_pc, body_pd) = scrutinee {
                break 'm33597 prism_rtl::Turn::More(Rc::new(crate::lower::node_::switch_::RebuildLine { wx_p0: wx_p0.clone(), benv_p1: benv_p1.clone(), menv_p2: menv_p2.clone(), scrut_p3: (**scrut_pc).clone(), body_p4: body_pd.clone(), e_p5: e_p3.clone(), bound_o6: bound_o4.clone() }));
            }
            if let crate::syntax::ExprKind::EIf(m33597_4_0, then_b_pf, Some(else_b_pg)) = scrutinee && let crate::syntax::Cond::CondExpr(c_pe) = &**m33597_4_0 {
                break 'm33597 prism_rtl::Turn::More(Rc::new(crate::lower::functions::IfGenLine { wx_p0: wx_p0.clone(), menv_p1: menv_p2.clone(), c_p2: (**c_pe).clone(), then_b_p3: then_b_pf.clone(), else_b_p4: else_b_pg.clone(), e_p5: e_p3.clone() }));
            }
            match crate::lower::types::peel(&full_p6) {
                crate::check::types::Ty::TyElem(_, _) => prism_rtl::Turn::More(Rc::new(crate::lower::node_::elements::ElementLine { wx_p0: wx_p0.clone(), benv_p1: benv_p1.clone(), menv_p2: menv_p2.clone(), e_p3: e_p3.clone(), bound_o4: bound_o4.clone() })),
                crate::check::types::Ty::TyAt(_, _) => prism_rtl::Turn::More(Rc::new(crate::lower::node_::static_::WidgetLine { wx_p0: wx_p0.clone(), benv_p1: benv_p1.clone(), menv_p2: menv_p2.clone(), e_p3: e_p3.clone(), bound_o4: bound_o4.clone() })),
                _ => {
                    let wx2_ph = {
                        let mut this: crate::lower::node_::Wx = wx_p0.clone();
                        this.build = push(&this.build, &crate::lower::expr::refusal_do(&Text::lit("a building line this back end does not lower yet")));
                        this
                    };
                    prism_rtl::Turn::Finished((wx2_ph.clone(), crate::lower::node_::Wres::WrUnit))
                },
            }
        }
    }
}

/// `Start BuildLine, x`: what the function value is when passed to `@Run`.
pub fn start_build_line(wx_p0: crate::lower::node_::Wx, benv_p1: crate::lower::types::Env, menv_p2: crate::lower::types::Env, e_p3: crate::syntax::Expr, bound_o4: Option<crate::lower::types::Bn>) -> Rc<dyn prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::node_::Wres)>> {
    Rc::new(BuildLine { wx_p0, benv_p1, menv_p2, e_p3, bound_o4 })
}
