//! The module `Lower.Node.Static`, from `target/bootstrap/src/prismc/lower/node/static.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// `HostForm`:
///
/// ```prism
/// type HostForm = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum HostForm {
    HostEach,
    HostSome,
}

impl Show for HostForm {
    fn show(&self, p: &mut Printer) {
        match self {
            HostForm::HostEach => p.choice("HostEach", &[]),
            HostForm::HostSome => p.choice("HostSome", &[]),
        }
    }
}

impl ToPod for HostForm {
    fn to_pod(&self) -> Pod {
        match self {
            HostForm::HostEach => Pod::Choice("HostEach".into(), vec![]),
            HostForm::HostSome => Pod::Choice("HostSome".into(), vec![]),
        }
    }
}

impl FromPod for HostForm {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "HostEach" && a.len() == 0 => Ok(HostForm::HostEach),
            Pod::Choice(c, a) if &**c == "HostSome" && a.len() == 0 => Ok(HostForm::HostSome),
            other => mismatch("a HostForm", other),
        }
    }
}

/// ```prism
/// WidgetLine: unbounded fn Wx, Env, Env, Expr, ?Bn -> ((Wx, Wres))
/// ```
pub fn widget_line_f(wx_p0: &crate::lower::node_::Wx, benv_p1: &crate::lower::types::Env, menv_p2: &crate::lower::types::Env, e_p3: &crate::syntax::Expr, bound_o4: &Option<crate::lower::types::Bn>) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    let lx_p5 = wx_p0.lx_p.clone();
    let (callee_pb, args_pc) = match &*e_p3.kind_p {
        crate::syntax::ExprKind::ECall(c_p9, xs_pa, _, _) => ((**c_p9).clone(), xs_pa.clone()),
        _ => (e_p3.clone(), Array::new()),
    };
    let qk_p6 = match &*callee_pb.kind_p {
        crate::syntax::ExprKind::EName(n_pd) => {
            let (q_oe, _) = crate::check::env::names::resolve_value_f(&lx_p5.g_p, &lx_p5.home_p, n_pd);
            crate::prelude::or(&q_oe, &Text::lit(""))
        },
        _ => Text::lit(""),
    };
    let target_o7 = match bound_o4 {
        Some(crate::lower::types::Bn::BnEv(er_pf, _)) => Some(er_pf.node_p.clone()),
        _ => None,
    };
    let param_o8 = match &*callee_pb.kind_p {
        crate::syntax::ExprKind::EName(n_pg) => if &crate::prelude::len(&n_pg.path_p) == &Nat::from(1u32) {
            crate::prelude::get(&menv_p2.names_p, &crate::check::env::sname_key_f(n_pg))
        } else {
            None
        },
        _ => None,
    };
    match &param_o8 {
        Some(crate::lower::types::Bn::BnWidget(x_ph, cbenv_pi, cmenv_pj, clx_pk)) => apply_widget_param_f(wx_p0, x_ph, cbenv_pi, cmenv_pj, clx_pk, &crate::prelude::len(&args_pc)),
        _ => widget_call_f(wx_p0, benv_p1, menv_p2, e_p3, bound_o4, &qk_p6, &args_pc, &target_o7),
    }
}

/// The step machine of `WidgetLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// WidgetLine: unbounded fn Wx, Env, Env, Expr, ?Bn -> ((Wx, Wres))
/// ```
pub struct WidgetLine {
    pub wx_p0: crate::lower::node_::Wx,
    pub benv_p1: crate::lower::types::Env,
    pub menv_p2: crate::lower::types::Env,
    pub e_p3: crate::syntax::Expr,
    pub bound_o4: Option<crate::lower::types::Bn>,
}

impl prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::node_::Wres)> for WidgetLine {
    fn cycle(&self) -> prism_rtl::Turn<(crate::lower::node_::Wx, crate::lower::node_::Wres)> {
        let wx_p0 = &self.wx_p0;
        let benv_p1 = &self.benv_p1;
        let menv_p2 = &self.menv_p2;
        let e_p3 = &self.e_p3;
        let bound_o4 = &self.bound_o4;
        let lx_p5 = wx_p0.lx_p.clone();
        let (callee_pb, args_pc) = match &*e_p3.kind_p {
            crate::syntax::ExprKind::ECall(c_p9, xs_pa, _, _) => ((**c_p9).clone(), xs_pa.clone()),
            _ => (e_p3.clone(), Array::new()),
        };
        let qk_p6 = match &*callee_pb.kind_p {
            crate::syntax::ExprKind::EName(n_pd) => {
                let (q_oe, _) = crate::check::env::names::resolve_value_f(&lx_p5.g_p, &lx_p5.home_p, n_pd);
                crate::prelude::or(&q_oe, &Text::lit(""))
            },
            _ => Text::lit(""),
        };
        let target_o7 = match bound_o4 {
            Some(crate::lower::types::Bn::BnEv(er_pf, _)) => Some(er_pf.node_p.clone()),
            _ => None,
        };
        let param_o8 = match &*callee_pb.kind_p {
            crate::syntax::ExprKind::EName(n_pg) => if &crate::prelude::len(&n_pg.path_p) == &Nat::from(1u32) {
                crate::prelude::get(&menv_p2.names_p, &crate::check::env::sname_key_f(n_pg))
            } else {
                None
            },
            _ => None,
        };
        match &param_o8 {
            Some(crate::lower::types::Bn::BnWidget(x_ph, cbenv_pi, cmenv_pj, clx_pk)) => prism_rtl::Turn::Finished(apply_widget_param_f(wx_p0, x_ph, cbenv_pi, cmenv_pj, clx_pk, &crate::prelude::len(&args_pc))),
            _ => prism_rtl::Turn::Finished(widget_call_f(wx_p0, benv_p1, menv_p2, e_p3, bound_o4, &qk_p6, &args_pc, &target_o7)),
        }
    }
}

/// `Start WidgetLine, x`: what the function value is when passed to `@Run`.
pub fn start_widget_line_f(wx_p0: crate::lower::node_::Wx, benv_p1: crate::lower::types::Env, menv_p2: crate::lower::types::Env, e_p3: crate::syntax::Expr, bound_o4: Option<crate::lower::types::Bn>) -> Rc<dyn prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::node_::Wres)>> {
    Rc::new(WidgetLine { wx_p0, benv_p1, menv_p2, e_p3, bound_o4 })
}

/// ```prism
/// ApplyWidgetParam: unbounded fn Wx, Expr, Env, Env, Lx, Nat -> ((Wx, Wres))
/// ```
pub fn apply_widget_param_f(wx_p0: &crate::lower::node_::Wx, x_p1: &crate::syntax::Expr, cbenv_p2: &crate::lower::types::Env, cmenv_p3: &crate::lower::types::Env, clx_p4: &crate::lower::Lx, nargs_p5: &Nat) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    if nargs_p5 > &Nat::from(0u32) {
        {
            let wx2_p6 = {
                let mut this: crate::lower::node_::Wx = wx_p0.clone();
                this.build_p = crate::prelude::push(&this.build_p, &crate::lower::expr::refusal_do_f(&Text::lit("a widget parameter applied to arguments")));
                this
            };
            (wx2_p6.clone(), crate::lower::node_::Wres::WrUnit)
        }
    } else {
        {
            let lx_p7 = wx_p0.lx_p.clone();
            let inner_p8 = {
                let mut this: crate::lower::node_::Wx = wx_p0.clone();
                this.lx_p = clx_p4.clone();
                this
            };
            let (done_pa, res_pb) = crate::lower::node_::def::build_line_f(&inner_p8, cbenv_p2, cmenv_p3, x_p1, &None);
            let back_p9 = {
                let mut this: crate::lower::node_::Wx = done_pa.clone();
                this.lx_p = lx_p7.clone();
                this
            };
            (back_p9.clone(), res_pb.clone())
        }
    }
}

/// ```prism
/// InlineBlock: unbounded fn Wx, Env, Env, Block, Lx -> ((Wx, Wres))
/// ```
pub fn inline_block_f(wx_p0: &crate::lower::node_::Wx, benv_p1: &crate::lower::types::Env, menv_p2: &crate::lower::types::Env, b_p3: &crate::syntax::Block, lx_p4: &crate::lower::Lx) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    let inner_p5 = {
        let mut this: crate::lower::node_::Wx = wx_p0.clone();
        this.result_p = crate::lower::node_::Wres::WrUnit;
        this
    };
    let done_p6 = crate::lower::node_::def::block_into_f(&inner_p5, benv_p1, menv_p2, b_p3);
    let back_p7 = {
        let mut this: crate::lower::node_::Wx = done_p6.clone();
        this.result_p = wx_p0.result_p.clone();
        this
    };
    (back_p7.clone(), done_p6.result_p.clone())
}

/// The step machine of `InlineBlock`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InlineBlock: unbounded fn Wx, Env, Env, Block, Lx -> ((Wx, Wres))
/// ```
pub struct InlineBlock {
    pub wx_p0: crate::lower::node_::Wx,
    pub benv_p1: crate::lower::types::Env,
    pub menv_p2: crate::lower::types::Env,
    pub b_p3: crate::syntax::Block,
    pub lx_p4: crate::lower::Lx,
}

impl prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::node_::Wres)> for InlineBlock {
    fn cycle(&self) -> prism_rtl::Turn<(crate::lower::node_::Wx, crate::lower::node_::Wres)> {
        let wx_p0 = &self.wx_p0;
        let benv_p1 = &self.benv_p1;
        let menv_p2 = &self.menv_p2;
        let b_p3 = &self.b_p3;
        let lx_p4 = &self.lx_p4;
        let inner_p5 = {
            let mut this: crate::lower::node_::Wx = wx_p0.clone();
            this.result_p = crate::lower::node_::Wres::WrUnit;
            this
        };
        let b_p3x = b_p3.clone();
        let benv_p1x = benv_p1.clone();
        let menv_p2x = menv_p2.clone();
        let wx_p0x = wx_p0.clone();
        crate::prelude::call_then(crate::lower::node_::def::start_block_into_f(inner_p5.clone(), benv_p1x.clone(), menv_p2x.clone(), b_p3x.clone()), move |block_into_f_3395: crate::lower::node_::Wx| {
            let done_p6 = block_into_f_3395;
            let back_p7 = {
                let mut this: crate::lower::node_::Wx = done_p6.clone();
                this.result_p = wx_p0x.result_p.clone();
                this
            };
            prism_rtl::Turn::Finished((back_p7.clone(), done_p6.result_p.clone()))
        })
    }
}

/// `Start InlineBlock, x`: what the function value is when passed to `@Run`.
pub fn start_inline_block_f(wx_p0: crate::lower::node_::Wx, benv_p1: crate::lower::types::Env, menv_p2: crate::lower::types::Env, b_p3: crate::syntax::Block, lx_p4: crate::lower::Lx) -> Rc<dyn prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::node_::Wres)>> {
    Rc::new(InlineBlock { wx_p0, benv_p1, menv_p2, b_p3, lx_p4 })
}

/// ```prism
/// WidgetCall: unbounded fn Wx, Env, Env, Expr, ?Bn, Text, [Arg], ?Nat -> ((Wx, Wres))
/// ```
pub fn widget_call_f(wx_p0: &crate::lower::node_::Wx, benv_p1: &crate::lower::types::Env, menv_p2: &crate::lower::types::Env, e_p3: &crate::syntax::Expr, bound_o4: &Option<crate::lower::types::Bn>, qk_p5: &Text, args_p6: &Array<crate::syntax::Arg>, target_o7: &Option<Nat>) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    let lx_p8 = wx_p0.lx_p.clone();
    match qk_p5 {
        m3679_0 if (m3679_0 == &Text::lit("Prelude.@started")) => started_line_f(wx_p0, bound_o4),
        m3679_1 if (m3679_1 == &Text::lit("Prelude.@Switch")) => crate::lower::node_::switch_::switch_line_f(wx_p0, menv_p2, args_p6),
        m3679_2 if (m3679_2 == &Text::lit("Prelude.@Flatten")) => crate::lower::node_::switch_::flatten_line_f(wx_p0, menv_p2, args_p6, bound_o4),
        m3679_3 if (m3679_3 == &Text::lit("Prelude.@Defer")) => defer_line_f(wx_p0, menv_p2, args_p6, e_p3, target_o7),
        m3679_4 if (m3679_4 == &Text::lit("Prelude.@Distinct")) => distinct_line_f(wx_p0, menv_p2, args_p6, e_p3, bound_o4),
        m3679_5 if (m3679_5 == &Text::lit("Prelude.@PerKey")) => per_key_line_f(wx_p0, menv_p2, args_p6, bound_o4),
        m3679_6 if (m3679_6 == &Text::lit("Prelude.@Run")) => run_line_f(wx_p0, benv_p1, args_p6, e_p3, target_o7),
        m3679_7 if (m3679_7 == &Text::lit("Prelude.@Machine")) => machine_line_f(wx_p0, benv_p1, menv_p2, args_p6, e_p3, target_o7),
        m3679_8 if (m3679_8 == &Text::lit("Prelude.@HostDocument")) => host_line_f(wx_p0, benv_p1, menv_p2, &HostForm::HostEach, args_p6, bound_o4),
        m3679_9 if (m3679_9 == &Text::lit("Prelude.@HostSome")) => host_line_f(wx_p0, benv_p1, menv_p2, &HostForm::HostSome, args_p6, bound_o4),
        _ => match crate::prelude::get(&lx_p8.g_p.vals_p, qk_p5) {
            Some(v_p9) => inline_widget_f(wx_p0, benv_p1, menv_p2, qk_p5, &v_p9, args_p6, e_p3),
            None => {
                let wx2_pa = {
                    let mut this: crate::lower::node_::Wx = wx_p0.clone();
                    this.build_p = crate::prelude::push(&this.build_p, &crate::lower::expr::refusal_do_f(&Text::lit("a widget this back end does not lower yet")));
                    this
                };
                (wx2_pa.clone(), crate::lower::node_::Wres::WrUnit)
            },
        },
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// HostLine: unbounded fn Wx, Env, Env, HostForm, [Arg], ?Bn -> ((Wx, Wres))
/// ```
pub fn host_line_f(wx_p0: &crate::lower::node_::Wx, benv_p1: &crate::lower::types::Env, menv_p2: &crate::lower::types::Env, form_p3: &HostForm, args_p4: &Array<crate::syntax::Arg>, bound_o5: &Option<crate::lower::types::Bn>) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    let lx_p6 = wx_p0.lx_p.clone();
    let pos_p7 = wx_p0.pos_p.clone();
    let k_p8 = &crate::prelude::len(&wx_p0.scopes_p) + &Nat::from(1u32);
    let hf_p9 = Text::from(format!("host_{}", &k_p8));
    let rows_name_pa = Text::from(format!("{}_rows", &hf_p9));
    let doc_getter_pb = Text::from(format!("{}_doc", &hf_p9));
    let wx1_pc = {
        let mut this: crate::lower::node_::Wx = wx_p0.clone();
        this.taken_p = crate::prelude::append(&this.taken_p, &Array::from(vec![hf_p9.clone(), rows_name_pa.clone(), doc_getter_pb.clone(), Text::from(format!("{}_now", &doc_getter_pb)), Text::from(format!("{}_snap", &doc_getter_pb)), Text::from(format!("{}_direct", &doc_getter_pb)), Text::from(format!("{}_publish", &doc_getter_pb)), Text::from(format!("{}_answer", &hf_p9)), Text::from(format!("{}_moved", &hf_p9))]));
        this
    };
    let named_pd = match crate::prelude::index(args_p4, &Nat::from(1u32)) {
        Some(sup_pe) => is_widget_name_f(&sup_pe.value_p),
        None => false,
    };
    match (crate::prelude::index(args_p4, &Nat::from(0u32)), crate::prelude::index(args_p4, &Nat::from(1u32))) {
        (Some(_), Some(_)) if named_pd => {
            let wx2_pf = {
                let mut this: crate::lower::node_::Wx = wx1_pc.clone();
                this.pos_p = crate::lower::model::next_pos_f(&this.pos_p);
                this.build_p = crate::prelude::push(&this.build_p, &crate::lower::expr::refusal_do_f(&Text::lit("a named widget function as a host\'s supplier (gap NS): a lambda supplier is lowered, a widget function is not a value")));
                this
            };
            (wx2_pf.clone(), crate::lower::node_::Wres::WrHosted(Rc::new(crate::lower::node_::Wres::WrUnit), crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XUnit, crate::lower::types::Holding::Owned, crate::lower::model::OutTy::OutUnit)))
        },
        (Some(child_pg), Some(sup_ph)) => {
            let (wxd_p13, dyn_env_p14, dyn_lets_p15) = dynamic_answers_f(&wx1_pc, benv_p1, menv_p2, &hf_p9, &sup_ph.value_p);
            let offered_pi = crate::lower::types::own_f(&crate::lower::expr::value_of_f(&lx_p6, &dyn_env_p14, &sup_ph.value_p));
            let supplier0_pj = match form_p3 {
                HostForm::HostEach => offered_pi.clone(),
                HostForm::HostSome => crate::lower::model::Ex::XCall(Text::lit("prism_rtl::forward_on_none"), Array::from(vec![offered_pi.clone()])),
            };
            let supplier_pk = if &crate::prelude::len(&dyn_lets_p15) == &Nat::from(0u32) {
                supplier0_pj.clone()
            } else {
                crate::lower::model::Ex::XBlock(dyn_lets_p15.clone(), Rc::new(supplier0_pj.clone()))
            };
            let enclosing_pl = if crate::lower::node_::finish::emits_f(wx_p0, &pos_p7) {
                crate::lower::model::Ex::XNone
            } else {
                crate::lower::model::Ex::XCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Ex::XCast(Rc::new(crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(crate::lower::node_::elements::host_local_f(wx_p0, &pos_p7))))), crate::lower::types::host_of_ty_p())]))
            };
            let made_pm = crate::lower::model::Ex::XCall(Text::lit("prism_rtl::Host::new"), Array::from(vec![crate::lower::node_::finish::place_at_f(wx_p0, &Text::lit(""), &pos_p7), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(rows_name_pa.clone()))), supplier_pk.clone(), enclosing_pl.clone(), crate::lower::model::Ex::XPath(Text::from(format!("{}::{}_answer", &wx_p0.node_p, &hf_p9)))]));
            let host_ty_pn = crate::lower::model::OutTy::OutRc(Rc::new(crate::lower::model::OutTy::OutNamed(Text::lit("prism_rtl::Host"), Array::from(vec![crate::lower::types::elem_ty_p(), crate::lower::types::answer_ty_p(), crate::lower::model::OutTy::OutNamed(wx_p0.node_p.clone(), Array::new())]))));
            let rows_ty_po = crate::lower::model::OutTy::OutNamed(Text::lit("prism_rtl::Rows"), Array::from(vec![crate::lower::types::elem_ty_p(), crate::lower::types::answer_ty_p()]));
            let doc_ty_pp = crate::lower::model::OutTy::OutMap(Rc::new(crate::lower::model::OutTy::OutPath), Rc::new(crate::lower::model::OutTy::OutDyn(Rc::new(crate::lower::types::elem_ty_p()))));
            let direct_ty_pq = crate::lower::model::OutTy::OutMap(Rc::new(crate::lower::model::OutTy::OutPath), Rc::new(crate::lower::types::entry_ty_p()));
            let what_pr = Text::from(format!("the document of the child hosted at place {}", &crate::lower::model::place_text_f(&pos_p7)));
            let wx2_ps = {
                let mut this: crate::lower::node_::Wx = wxd_p13.clone();
                this.pos_p = crate::lower::model::next_pos_f(&this.pos_p);
                this.lets_p = crate::prelude::append(&this.lets_p, &Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaBind(rows_name_pa.clone())), rows_ty_po.clone()), crate::lower::model::Ex::XCall(Text::lit("Rc::new"), Array::from(vec![crate::lower::model::Ex::XCall(Text::lit("RefCell::new"), Array::from(vec![crate::lower::model::Ex::XCall(Text::lit("Map::new"), Array::new())]))]))), crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(hf_p9.clone()), made_pm.clone())]));
                this.fields_p = crate::prelude::append(&this.fields_p, &Array::from(vec![(hf_p9.clone(), host_ty_pn.clone(), Text::from(format!("the host at place {}: its supplier, its rows, and the way back into its child (pick HO)", &crate::lower::model::place_text_f(&pos_p7)))), (rows_name_pa.clone(), rows_ty_po.clone(), Text::from(format!("the rows of the host at place {}: `for p, e <- $doc`, one supplier blueprint per child place", &crate::lower::model::place_text_f(&pos_p7)))), (Text::from(format!("{}_from", &rows_name_pa)), crate::lower::model::OutTy::OutCell(Rc::new(direct_ty_pq.clone())), Text::from(format!("the places the rows of the host at place {} were last built from", &crate::lower::model::place_text_f(&pos_p7)))), (Text::from(format!("{}_snap", &doc_getter_pb)), crate::lower::model::OutTy::OutSnapshot(Rc::new(crate::lower::types::host_doc_ty_p())), Text::from(format!("`$doc` of the host at place {}, its outer, a structural dynamic: its snapshots, the places and the lagged dynamic (pick ST)", &crate::lower::model::place_text_f(&pos_p7))))]));
                this.moves_p = crate::prelude::append(&this.moves_p, &Array::from(vec![(hf_p9.clone(), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(hf_p9.clone())))), (rows_name_pa.clone(), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(rows_name_pa.clone()))))]));
                this.inits_p = crate::prelude::append(&this.inits_p, &Array::from(vec![(Text::from(format!("{}_snap", &doc_getter_pb)), crate::lower::model::Ex::XCall(Text::lit("Snapshot::new"), Array::from(vec![crate::lower::model::Ex::XStr(what_pr.clone())]))), (Text::from(format!("{}_from", &rows_name_pa)), crate::lower::model::Ex::XCall(Text::lit("RefCell::new"), Array::from(vec![crate::lower::model::Ex::XCall(Text::lit("Map::new"), Array::new())])))]));
                this.hosts_p = crate::prelude::push(&this.hosts_p, &crate::lower::node_::HostDef { pos_p: pos_p7.clone(), name_p: hf_p9.clone(), scope_p: k_p8.clone() });
                this.snaps_p = crate::prelude::push(&this.snaps_p, &crate::lower::node_::SnapDef { name_p: doc_getter_pb.clone(), live_p: Text::from(format!("{}_now", &doc_getter_pb)), ty_p: crate::lower::types::host_doc_ty_p(), eq_p: true, builder_p: rows_name_pa.clone(), before_p: true, what_p: what_pr.clone() });
                this.getters_p = crate::prelude::append(&this.getters_p, &Array::from(vec![crate::lower::model::MethDef { name_p: doc_getter_pb.clone(), recv_p: crate::lower::model::Recv::RecvRef, params_p: Array::new(), cx_p: crate::lower::model::CxArg::CxRef, ret_p: doc_ty_pp.clone(), body_p: Array::new(), tail_p: crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_snap", &doc_getter_pb)))), Text::lit("get"), Array::from(vec![crate::lower::model::Ex::XCx]))), Text::lit("doc")), doc_p: Text::from(format!("The document of the child hosted at place {}, `$doc`, its outer a structural dynamic (pick ST): one tick behind the child\'s places, the snapshot of the tick before the tick the read point is after; each entry the place\'s own dynamic.", &crate::lower::model::place_text_f(&pos_p7))) }, crate::lower::model::MethDef { name_p: Text::from(format!("{}_direct", &doc_getter_pb)), recv_p: crate::lower::model::Recv::RecvRef, params_p: Array::new(), cx_p: crate::lower::model::CxArg::CxRef, ret_p: direct_ty_pq.clone(), body_p: Array::new(), tail_p: crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_snap", &doc_getter_pb)))), Text::lit("current"), Array::from(vec![crate::lower::model::Ex::XCx]))), Text::lit("places")), doc_p: Text::from(format!("The places of the child hosted at place {}, not the lagged `$doc`: the snapshot taken in this tick\'s construction step, the places as the tick opened during propagation. The host\'s own `for` reads it, so a newborn child place gets its row in the tick it is born (pick ST).", &crate::lower::model::place_text_f(&pos_p7))) }]));
                this.scopes_p = crate::prelude::push(&this.scopes_p, &hf_p9);
                this.builders_p = crate::prelude::push(&this.builders_p, &crate::lower::model::ForDef { name_p: rows_name_pa.clone(), pos_p: pos_p7.clone(), at_p: crate::lower::node_::finish::place_at_f(wx_p0, &Text::lit("self"), &pos_p7), key_ty_p: crate::lower::model::OutTy::OutPath, value_ty_p: crate::lower::types::entry_ty_p(), row_node_p: Text::lit("prism_rtl::HostRow::<crate::Elem, crate::Answer>"), keyed_p: true, source_p: Text::from(format!("{}_direct", &doc_getter_pb)), parent_p: crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), hf_p9.clone()))), passed_p: Array::new(), moved_p: crate::prelude::or(&crate::lower::node_::finish::hosted_rows_o(wx_p0), &Text::lit("")), replaced_p: Array::new() });
                this.build_holds_p = crate::lower::node_::add_read_f(&this.build_holds_p, &crate::lower::node_::Read::OwnRead(Text::from(format!("{}_now", &doc_getter_pb))));
                this.fallible_p = true;
                this
            };
            let inner_pt = {
                let mut this: crate::lower::node_::Wx = wx2_ps.clone();
                this.pos_p = crate::lower::model::scope_pos_f(&k_p8);
                this.result_p = crate::lower::node_::Wres::WrUnit;
                this
            };
            let (done_p16, res_p17) = crate::lower::node_::def::build_line_f(&inner_pt, benv_p1, menv_p2, &child_pg.value_p, &None);
            let child_places_pu = crate::prelude::drop(&done_p16.places_p, &crate::prelude::len(&wx2_ps.places_p));
            let in_scope_fv = {
                let k_p8x = k_p8.clone();
                Rc::new(move |p_p18: &crate::lower::model::Pos_| &p_p18.scope_p == &k_p8x) as Rc<dyn Fn(&crate::lower::model::Pos_) -> bool>
            };
            let getter_p10 = host_doc_getter_f(&Text::from(format!("{}_now", &doc_getter_pb)), &pos_p7, &crate::prelude::filter(&child_places_pu, &(|pl_p19: &crate::lower::node_::Place| (&in_scope_fv)(&pl_p19.pos_p))), &crate::prelude::filter(&crate::prelude::drop(&done_p16.builders_p, &crate::prelude::len(&wx2_ps.builders_p)), &(|b_p1a: &crate::lower::model::ForDef| (&in_scope_fv)(&b_p1a.pos_p))), &crate::prelude::filter(&crate::prelude::drop(&done_p16.gens_p, &crate::prelude::len(&wx2_ps.gens_p)), &(|gd_p1b: &crate::lower::model::GenDef| (&in_scope_fv)(&gd_p1b.pos_p))));
            let back_p11 = {
                let mut this: crate::lower::node_::Wx = done_p16.clone();
                this.pos_p = wx2_ps.pos_p.clone();
                this.result_p = wx_p0.result_p.clone();
                this.getters_p = crate::prelude::push(&this.getters_p, &getter_p10);
                this.dyn_reads_p = crate::prelude::insert(&this.dyn_reads_p, &Text::from(format!("{}_now", &doc_getter_pb)), &Array::new());
                this
            };
            let doc_bn_p12 = crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XSelf), doc_getter_pb.clone(), Array::from(vec![crate::lower::model::Ex::XCx])), Array::from(vec![crate::lower::node_::Read::OwnRead(doc_getter_pb.clone())]), doc_ty_pp.clone());
            (back_p11.clone(), crate::lower::node_::Wres::WrHosted(Rc::new(res_p17.clone()), doc_bn_p12.clone()))
        },
        _ => {
            let wx2_p1c = {
                let mut this: crate::lower::node_::Wx = wx1_pc.clone();
                this.pos_p = crate::lower::model::next_pos_f(&this.pos_p);
                this.build_p = crate::prelude::push(&this.build_p, &crate::lower::expr::refusal_do_f(&Text::lit("a host without its child or its supplier")));
                this
            };
            (wx2_p1c.clone(), crate::lower::node_::Wres::WrHosted(Rc::new(crate::lower::node_::Wres::WrUnit), crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XUnit, crate::lower::types::Holding::Owned, crate::lower::model::OutTy::OutUnit)))
        },
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// IsWidgetName: fn Expr -> Bool
/// ```
pub fn is_widget_name_f(e_p0: &crate::syntax::Expr) -> bool {
    match &*e_p0.kind_p {
        crate::syntax::ExprKind::EName(n_p1) => crate::syntax::lexer::chars::has_prefix_f(&crate::check::env::sname_key_f(n_p1), &Text::lit("@")),
        crate::syntax::ExprKind::EGroup(x_p2) => is_widget_name_f(&**x_p2),
        _ => false,
    }
}

/// ```prism
/// DynamicAnswers: unbounded fn Wx, Env, Env, Text, Expr -> ((Wx, Env, [Do]))
/// ```
pub fn dynamic_answers_f(wx_p0: &crate::lower::node_::Wx, benv_p1: &crate::lower::types::Env, menv_p2: &crate::lower::types::Env, hf_p3: &Text, sup_p4: &crate::syntax::Expr) -> (crate::lower::node_::Wx, crate::lower::types::Env, Array<crate::lower::model::Do>) {
    let lx_p5 = wx_p0.lx_p.clone();
    let dyns_p6 = crate::prelude::fold(&crate::check::typed::print::exprs_in_f(sup_p4), &Array::new(), &(|acc_p7: &Array<(crate::syntax::Expr, crate::syntax::Expr)>, x_p8: &crate::syntax::Expr| match &*x_p8.kind_p {
        crate::syntax::ExprKind::EFreeSigil(m14204_0_0, y_p9) if (m14204_0_0 == &Text::lit("@")) => match dynamic_answer_o(&lx_p5, &**y_p9) {
            Some(d_pa) => crate::prelude::push(acc_p7, &((**y_p9).clone(), d_pa)),
            None => acc_p7.clone(),
        },
        _ => acc_p7.clone(),
        _ => unreachable!("no arm matched"),
    }));
    if &crate::prelude::len(&dyns_p6) == &Nat::from(0u32) {
        (wx_p0.clone(), benv_p1.clone(), Array::new())
    } else {
        {
            let owner_pb = Text::from(format!("{}_owner", hf_p3));
            let wx1_pc = {
                let mut this: crate::lower::node_::Wx = wx_p0.clone();
                this.taken_p = crate::prelude::push(&this.taken_p, &owner_pb);
                this.lets_p = crate::prelude::push(&this.lets_p, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(owner_pb.clone()), crate::lower::model::Ex::XCall(Text::from(format!("prism_rtl::Link::<{}>::new", &wx_p0.node_p)), Array::new())));
                this.build_p = crate::prelude::push(&this.build_p, &crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(owner_pb.clone())), Text::lit("link"), Array::from(vec![crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XVar(Text::lit("node"))))]))));
                this
            };
            let env0_pd = crate::lower::types::bind_f(benv_p1, &Text::lit("#owner"), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(Text::from(format!("{}x", &owner_pb))), crate::lower::types::Holding::Owned, crate::lower::model::OutTy::OutUnit));
            let lets0_pe = Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(Text::from(format!("{}x", &owner_pb))), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(owner_pb.clone()))))]);
            crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(&dyns_p6)), (wx1_pc.clone(), env0_pd.clone(), lets0_pe.clone()), {
                let dyns_p6x = dyns_p6.clone();
                let hf_p3x = hf_p3.clone();
                let menv_p2x = menv_p2.clone();
                let lx_p5x = lx_p5.clone();
                Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::types::Env, Array<crate::lower::model::Do>), Nat)| {
                    let dyns_p6xy = dyns_p6x.clone();
                    let hf_p3xy = hf_p3x.clone();
                    let menv_p2xy = menv_p2x.clone();
                    let lx_p5xy = lx_p5x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let (w_pf, en_pg, ls_ph) = p0;
                        let j_pi = p1;
                        match crate::prelude::index(&dyns_p6xy, &j_pi) {
                            Some((y_pj, d_pk)) => {
                                let name_pl = Text::from(format!("{}_dyn_{}", &hf_p3xy, &(&j_pi + &Nat::from(1u32))));
                                let port_pm = Text::from(format!("{}_port", &name_pl));
                                crate::prelude::call_then(crate::lower::node_::dynamics::start_dynamic_expr_f(w_pf.clone(), menv_p2xy.clone(), d_pk.clone()), move |dynamic_expr_f_15204: (crate::lower::model::Ex, Array<crate::lower::node_::Read>)| {
                                    let (ex_po, reads_pp) = dynamic_expr_f_15204;
                                    crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p5xy.clone(), crate::lower::types::peel_f(&crate::lower::type_at_f(&lx_p5xy, &d_pk.span_p))), move |out_ty_of_f_15251: crate::lower::model::OutTy| {
                                        let t_pn = out_ty_of_f_15251;
                                        if !crate::lower::node_::def::all_inited_f(&w_pf, &reads_pp) {
                                            prism_rtl::Turn::Finished((w_pf.clone(), en_pg.clone(), ls_ph.clone()))
                                        } else {
                                            {
                                                let w2_pq = {
                                                    let mut this: crate::lower::node_::Wx = w_pf.clone();
                                                    this.taken_p = crate::prelude::append(&this.taken_p, &Array::from(vec![name_pl.clone(), port_pm.clone()]));
                                                    this.getters_p = crate::prelude::push(&this.getters_p, &crate::lower::model::MethDef { name_p: name_pl.clone(), recv_p: crate::lower::model::Recv::RecvRef, params_p: Array::new(), cx_p: crate::lower::model::CxArg::CxRef, ret_p: t_pn.clone(), body_p: Array::new(), tail_p: ex_po.clone(), doc_p: Text::from(format!("The host at `{}`\'s dynamic answer `{}`, read at the read point (round 3 DY).", &hf_p3xy, &crate::lower::functions::src_text_f(&lx_p5xy, &lx_p5xy.file_p, &y_pj.span_p))) });
                                                    this.lets_p = crate::prelude::push(&this.lets_p, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaBind(port_pm.clone())), crate::lower::model::OutTy::OutRc(Rc::new(crate::lower::model::OutTy::OutPort(Rc::new(crate::lower::model::OutTy::OutUnit))))), crate::lower::model::Ex::XCall(Text::lit("Rc::new"), Array::from(vec![crate::lower::model::Ex::XCall(Text::lit("Port::new"), Array::new())]))));
                                                    this.fields_p = crate::prelude::push(&this.fields_p, &(port_pm.clone(), crate::lower::model::OutTy::OutRc(Rc::new(crate::lower::model::OutTy::OutPort(Rc::new(crate::lower::model::OutTy::OutUnit)))), Text::from(format!("the dynamic answer `{}` moved: its blueprints push the child\'s place next tick", &name_pl))));
                                                    this.moves_p = crate::prelude::push(&this.moves_p, &(port_pm.clone(), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(port_pm.clone())))));
                                                    this.dyn_answers_p = crate::prelude::push(&this.dyn_answers_p, &(name_pl.clone(), reads_pp.clone()));
                                                    this
                                                };
                                                prism_rtl::Turn::Finished((w2_pq.clone(), crate::lower::types::bind_f(&en_pg, &Text::from(format!("#dyn{}", &dyn_key_f(&y_pj))), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(name_pl.clone()), crate::lower::types::Holding::Owned, t_pn.clone())), crate::prelude::push(&ls_ph, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(Text::from(format!("{}x", &port_pm))), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(port_pm.clone())))))))
                                            }
                                        }
                                    })
                                })
                            },
                            None => prism_rtl::Turn::Finished((w_pf.clone(), en_pg.clone(), ls_ph.clone())),
                        }
                    }))
                }) as Rc<dyn Fn(((crate::lower::node_::Wx, crate::lower::types::Env, Array<crate::lower::model::Do>), Nat)) -> Rc<dyn prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, Array<crate::lower::model::Do>)>>>
            }))
        }
    }
}

/// ```prism
/// ?DynamicAnswer: fn Lx, Expr -> ?Expr
/// ```
pub fn dynamic_answer_o(lx_p0: &crate::lower::Lx, x_p1: &crate::syntax::Expr) -> Option<crate::syntax::Expr> {
    if &crate::lower::types::layer_of_f(&crate::lower::type_at_f(lx_p0, &x_p1.span_p)) != &crate::lower::types::Layer::LyDyn {
        None
    } else {
        match &*x_p1.kind_p {
            crate::syntax::ExprKind::EFreeSigil(m16686_0_0, inner_p2) if (m16686_0_0 == &Text::lit("$")) => if &crate::lower::types::layer_of_f(&crate::lower::type_at_f(lx_p0, &inner_p2.span_p)) == &crate::lower::types::Layer::LyDyn {
                Some((**inner_p2).clone())
            } else {
                None
            },
            _ => Some(x_p1.clone()),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// ```prism
/// DynKey: fn Expr -> Text
/// ```
pub fn dyn_key_f(x_p0: &crate::syntax::Expr) -> Text {
    Text::from(format!("{}:{}", &x_p0.span_p.start_p, &x_p0.span_p.end_p))
}

/// ```prism
/// HostDocGetter: fn Text, Pos, [Place], [ForDef], [GenDef] -> MethDef
/// ```
pub fn host_doc_getter_f(name_p0: &Text, pos_p1: &crate::lower::model::Pos_, places_p2: &Array<crate::lower::node_::Place>, builders_p3: &Array<crate::lower::model::ForDef>, gens_p4: &Array<crate::lower::model::GenDef>) -> crate::lower::model::MethDef {
    let start_p5 = crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaMut(Text::lit("doc"))), crate::lower::types::host_doc_ty_p()), crate::lower::model::Ex::XCall(Text::lit("prism_rtl::HostDoc::new"), Array::new()));
    let body_p6 = crate::lower::node_::finish::document_body_f(&{
        let f = Rc::new(crate::lower::node_::finish::map_insert_f);
        Rc::new(move |(a0, a1): (crate::lower::model::Ex, crate::lower::model::Ex)| {
            let fy = f.clone();
            crate::prelude::once_job(move || prism_rtl::Turn::Finished(fy(&a0, &a1)))
        }) as Rc<dyn Fn((crate::lower::model::Ex, crate::lower::model::Ex)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Do>>>
    }, places_p2, builders_p3, gens_p4);
    crate::lower::model::MethDef { name_p: name_p0.clone(), recv_p: crate::lower::model::Recv::RecvRef, params_p: Array::new(), cx_p: crate::lower::model::CxArg::CxRef, ret_p: crate::lower::types::host_doc_ty_p(), body_p: crate::prelude::append(&Array::from(vec![start_p5.clone()]), &body_p6), tail_p: crate::lower::model::Ex::XVar(Text::lit("doc")), doc_p: Text::from(format!("The places of the child hosted at place {}: each place\'s entry by its path relative to the child (pick HO). Read only by the snapshot of `$doc`\'s outer (pick ST).", &crate::lower::model::place_text_f(pos_p1))) }
}

/// ```prism
/// SnapGetter: fn Text, OutTy, Text -> MethDef
/// ```
pub fn snap_getter_f(name_p0: &Text, t_p1: &crate::lower::model::OutTy, doc_p2: &Text) -> crate::lower::model::MethDef {
    crate::lower::model::MethDef { name_p: name_p0.clone(), recv_p: crate::lower::model::Recv::RecvRef, params_p: Array::new(), cx_p: crate::lower::model::CxArg::CxRef, ret_p: t_p1.clone(), body_p: Array::new(), tail_p: crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_snap", name_p0)))), Text::lit("get"), Array::from(vec![crate::lower::model::Ex::XCx])), doc_p: doc_p2.clone() }
}

/// ```prism
/// StartedLine: fn Wx, ?Bn -> ((Wx, Wres))
/// ```
pub fn started_line_f(wx_p0: &crate::lower::node_::Wx, bound_o1: &Option<crate::lower::types::Bn>) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    let wx1_p2 = {
        let mut this: crate::lower::node_::Wx = wx_p0.clone();
        this.pos_p = crate::lower::model::next_pos_f(&this.pos_p);
        this
    };
    let (id_p7, wx2_p8) = match bound_o1 {
        Some(crate::lower::types::Bn::BnEv(er_p4, _)) => (er_p4.node_p.clone(), wx1_p2.clone()),
        _ => {
            let (nm_p5, w_p6) = crate::lower::node_::fresh_name_f(&wx1_p2, &Text::lit("started"));
            crate::lower::node_::add_gn_f(&w_p6, &nm_p5, &crate::lower::model::OutTy::OutUnit, &crate::lower::node_::GnKind::GnStarted, &Nat::from(0u32))
        },
    };
    let wx3_p3 = {
        let mut this: crate::lower::node_::Wx = wx2_p8.clone();
        this.started_p = crate::prelude::push(&this.started_p, &id_p7);
        this
    };
    (wx3_p3.clone(), crate::lower::node_::Wres::WrEv(crate::lower::node_::ev_ref_of_f(&wx3_p3, &id_p7)))
}

/// ```prism
/// DeferLine: unbounded fn Wx, Env, [Arg], Expr, ?Nat -> ((Wx, Wres))
/// ```
pub fn defer_line_f(wx_p0: &crate::lower::node_::Wx, menv_p1: &crate::lower::types::Env, args_p2: &Array<crate::syntax::Arg>, e_p3: &crate::syntax::Expr, target_o4: &Option<Nat>) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    let lx_p5 = wx_p0.lx_p.clone();
    let t_p6 = crate::lower::types::out_ty_of_f(&lx_p5, &crate::lower::types::out_of_f(&crate::lower::type_at_f(&lx_p5, &e_p3.span_p)));
    let (field_p9, wx1_pa) = crate::lower::node_::fresh_name_f(wx_p0, &Text::lit("deferred"));
    let (id_pc, wx2_pd) = match target_o4 {
        Some(n_pb) => (n_pb.clone(), wx1_pa.clone()),
        None => crate::lower::node_::add_gn_f(&wx1_pa, &Text::from(format!("{}_fired", &field_p9)), &t_p6, &crate::lower::node_::GnKind::GnDeferred, &Nat::from(0u32)),
    };
    let wx3_p7 = crate::lower::node_::add_field_last_f(&wx2_pd, &field_p9, &crate::lower::model::OutTy::OutDefer(Rc::new(t_p6.clone())), &Text::lit("`@Defer`"), &crate::lower::model::Ex::XCall(Text::lit("Defer::new"), Array::new()));
    let wx4_p8 = {
        let mut this: crate::lower::node_::Wx = wx3_p7.clone();
        this.defers_p = crate::prelude::push(&this.defers_p, &(field_p9.clone(), id_pc.clone()));
        this
    };
    match crate::prelude::index(args_p2, &Nat::from(0u32)) {
        Some(a_pe) => {
            let (r_pf, wx5_pg) = crate::lower::node_::dynamics::event_ref_f(&wx4_p8, menv_p1, &a_pe.value_p);
            (crate::lower::node_::connect_f(&wx5_pg, &r_pf, &crate::lower::node_::Sk::SkArm(field_p9.clone())), crate::lower::node_::Wres::WrEv(crate::lower::node_::ev_ref_of_f(&wx5_pg, &id_pc)))
        },
        None => (wx4_p8.clone(), crate::lower::node_::Wres::WrEv(crate::lower::node_::ev_ref_of_f(&wx4_p8, &id_pc))),
    }
}

/// ```prism
/// DistinctLine: unbounded fn Wx, Env, [Arg], Expr, ?Bn -> ((Wx, Wres))
/// ```
pub fn distinct_line_f(wx_p0: &crate::lower::node_::Wx, menv_p1: &crate::lower::types::Env, args_p2: &Array<crate::syntax::Arg>, e_p3: &crate::syntax::Expr, bound_o4: &Option<crate::lower::types::Bn>) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    let lx_p5 = wx_p0.lx_p.clone();
    match crate::prelude::index(args_p2, &Nat::from(0u32)) {
        None => {
            let wx2_p6 = {
                let mut this: crate::lower::node_::Wx = wx_p0.clone();
                this.build_p = crate::prelude::push(&this.build_p, &crate::lower::expr::refusal_do_f(&Text::lit("an `@Distinct` without its dynamic")));
                this
            };
            (wx2_p6.clone(), crate::lower::node_::Wres::WrUnit)
        },
        Some(a_p7) => {
            let t_p8 = crate::lower::types::out_ty_of_f(&lx_p5, &crate::lower::types::peel_f(&crate::lower::type_at_f(&lx_p5, &a_p7.value_p.span_p)));
            let (name_pg, wx1_ph) = 'm20489: {
                if let Some(crate::lower::types::Bn::BnHold(f_pe, _)) = bound_o4 {
                    break 'm20489 (f_pe.clone(), wx_p0.clone());
                }
                if let Some(crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(m20489_1_0_0, f_pf, _), _, _)) = bound_o4 && let crate::lower::model::Ex::XSelf = &**m20489_1_0_0 {
                    break 'm20489 (f_pf.clone(), wx_p0.clone());
                }
                crate::lower::node_::fresh_name_f(wx_p0, &Text::lit("distinct"))
            };
            let kept_p9 = Text::from(format!("{}_kept", &name_pg));
            let source_pa = Text::from(format!("{}_source", &name_pg));
            let (ex_pi, reads_pj) = crate::lower::node_::dynamics::dynamic_expr_f(&wx1_ph, menv_p1, &a_p7.value_p);
            let first_pb = crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XVar(Text::lit("node"))), kept_p9.clone())), Text::lit("set"), Array::from(vec![crate::lower::model::Ex::XCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("node"))), source_pa.clone(), Array::from(vec![crate::lower::model::Ex::XCx]))])), crate::lower::model::Ex::XCx])));
            let sample_pc = crate::lower::model::Ex::XMatch(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), kept_p9.clone())), Text::lit("get"), Array::from(vec![crate::lower::model::Ex::XCx]))), Array::from(vec![crate::lower::model::XArm { pat_p: crate::lower::model::Pa::PaCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("v"))])), conds_p: Array::new(), body_p: crate::lower::model::Ex::XVar(Text::lit("v")) }, crate::lower::model::XArm { pat_p: crate::lower::model::Pa::PaUnit(Text::lit("None")), conds_p: Array::new(), body_p: crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XSelf), source_pa.clone(), Array::from(vec![crate::lower::model::Ex::XCx])) }]), false, t_p8.clone());
            let wx2_pd = {
                let mut this: crate::lower::node_::Wx = wx1_ph.clone();
                this.taken_p = crate::prelude::append(&this.taken_p, &Array::from(vec![kept_p9.clone(), source_pa.clone()]));
                this.fields_p = crate::prelude::push(&this.fields_p, &(kept_p9.clone(), crate::lower::model::OutTy::OutHold(Rc::new(crate::lower::model::OutTy::OutOpt(Rc::new(t_p8.clone())))), Text::lit("`@Distinct`\'s value: its source\'s, written only when it changes")));
                this.moves_p = crate::prelude::push(&this.moves_p, &(kept_p9.clone(), crate::lower::model::Ex::XCall(Text::lit("Hold::new"), Array::from(vec![crate::lower::model::Ex::XNone, crate::lower::model::Ex::XCx]))));
                this.build_p = crate::prelude::push(&this.build_p, &first_pb);
                this.getters_p = crate::prelude::append(&this.getters_p, &Array::from(vec![crate::lower::model::MethDef { name_p: source_pa.clone(), recv_p: crate::lower::model::Recv::RecvRef, params_p: Array::new(), cx_p: crate::lower::model::CxArg::CxRef, ret_p: t_p8.clone(), body_p: Array::new(), tail_p: ex_pi.clone(), doc_p: Text::lit("`@Distinct`\'s source, read at the build.") }, crate::lower::model::MethDef { name_p: name_pg.clone(), recv_p: crate::lower::model::Recv::RecvRef, params_p: Array::new(), cx_p: crate::lower::model::CxArg::CxRef, ret_p: t_p8.clone(), body_p: Array::new(), tail_p: sample_pc.clone(), doc_p: Text::lit("`@Distinct`\'s dynamic: the value it holds at the read point.") }]));
                this.dyn_reads_p = crate::prelude::insert(&crate::prelude::insert(&this.dyn_reads_p, &name_pg, &Array::from(vec![crate::lower::node_::Read::OwnRead(kept_p9.clone())])), &source_pa, &reads_pj);
                this
            };
            let (r_pk, wx3_pl) = crate::lower::node_::dynamics::updated_event_f(&wx2_pd, menv_p1, args_p2, &t_p8);
            (crate::lower::node_::connect_f(&wx3_pl, &r_pk, &crate::lower::node_::Sk::SkDistinct(kept_p9.clone())), crate::lower::node_::Wres::WrDyn(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XSelf), name_pg.clone(), Array::from(vec![crate::lower::model::Ex::XCx])), Array::from(vec![crate::lower::node_::Read::OwnRead(kept_p9.clone())]), t_p8.clone()))
        },
    }
}

/// ```prism
/// PerKeyLine: unbounded fn Wx, Env, [Arg], ?Bn -> ((Wx, Wres))
/// ```
pub fn per_key_line_f(wx_p0: &crate::lower::node_::Wx, menv_p1: &crate::lower::types::Env, args_p2: &Array<crate::syntax::Arg>, bound_o3: &Option<crate::lower::types::Bn>) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    let lx_p4 = wx_p0.lx_p.clone();
    match crate::prelude::index(args_p2, &Nat::from(0u32)) {
        None => {
            let wx2_p5 = {
                let mut this: crate::lower::node_::Wx = wx_p0.clone();
                this.build_p = crate::prelude::push(&this.build_p, &crate::lower::expr::refusal_do_f(&Text::lit("an `@PerKey` without its dynamic")));
                this
            };
            (wx2_p5.clone(), crate::lower::node_::Wres::WrUnit)
        },
        Some(a_p6) => {
            let (kt_pg, vt_ph) = match crate::lower::types::peel_f(&crate::lower::type_at_f(&lx_p4, &a_p6.value_p.span_p)) {
                crate::check::types::Ty::TyMap(k_pe, v_pf) => (crate::lower::types::out_ty_of_f(&lx_p4, &*k_pe), crate::lower::types::out_ty_of_f(&lx_p4, &*v_pf)),
                _ => (crate::lower::model::OutTy::OutUnit, crate::lower::model::OutTy::OutUnit),
            };
            let src_ty_p7 = crate::lower::model::OutTy::OutMap(Rc::new(kt_pg.clone()), Rc::new(vt_ph.clone()));
            let t_p8 = crate::lower::model::OutTy::OutMap(Rc::new(kt_pg.clone()), Rc::new(crate::lower::model::OutTy::OutDyn(Rc::new(vt_ph.clone()))));
            let (name_pk, wx1_pl) = 'm23801: {
                if let Some(crate::lower::types::Bn::BnHold(f_pi, _)) = bound_o3 {
                    break 'm23801 (f_pi.clone(), wx_p0.clone());
                }
                if let Some(crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(m23801_1_0_0, f_pj, _), _, _)) = bound_o3 && let crate::lower::model::Ex::XSelf = &**m23801_1_0_0 {
                    break 'm23801 (f_pj.clone(), wx_p0.clone());
                }
                crate::lower::node_::fresh_name_f(wx_p0, &Text::lit("per_key"))
            };
            let kept_p9 = Text::from(format!("{}_kept", &name_pk));
            let source_pa = Text::from(format!("{}_source", &name_pk));
            let (ex_pm, reads_pn) = crate::lower::node_::dynamics::dynamic_expr_f(&wx1_pl, menv_p1, &a_p6.value_p);
            let first_pb = crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XVar(Text::lit("node"))), kept_p9.clone())), Text::lit("start"), Array::from(vec![crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("node"))), source_pa.clone(), Array::from(vec![crate::lower::model::Ex::XCx])), crate::lower::model::Ex::XCx])));
            let sample_pc = crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), kept_p9.clone())), Text::lit("outer"), Array::from(vec![crate::lower::model::Ex::XCx, crate::lower::model::Ex::XClosure(false, Array::new(), Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XSelf), source_pa.clone(), Array::from(vec![crate::lower::model::Ex::XCx]))))]));
            let wx2_pd = {
                let mut this: crate::lower::node_::Wx = wx1_pl.clone();
                this.taken_p = crate::prelude::append(&this.taken_p, &Array::from(vec![kept_p9.clone(), source_pa.clone()]));
                this.fields_p = crate::prelude::push(&this.fields_p, &(kept_p9.clone(), crate::lower::model::OutTy::OutNamed(Text::lit("prism_rtl::PerKey"), Array::from(vec![kt_pg.clone(), vt_ph.clone()])), Text::lit("`@PerKey`\'s outer and each key\'s inner")));
                this.moves_p = crate::prelude::push(&this.moves_p, &(kept_p9.clone(), crate::lower::model::Ex::XCall(Text::lit("prism_rtl::PerKey::new"), Array::new())));
                this.build_p = crate::prelude::push(&this.build_p, &first_pb);
                this.getters_p = crate::prelude::append(&this.getters_p, &Array::from(vec![crate::lower::model::MethDef { name_p: source_pa.clone(), recv_p: crate::lower::model::Recv::RecvRef, params_p: Array::new(), cx_p: crate::lower::model::CxArg::CxRef, ret_p: src_ty_p7.clone(), body_p: Array::new(), tail_p: ex_pm.clone(), doc_p: Text::lit("`@PerKey`\'s source, read at the build.") }, crate::lower::model::MethDef { name_p: name_pk.clone(), recv_p: crate::lower::model::Recv::RecvRef, params_p: Array::new(), cx_p: crate::lower::model::CxArg::CxRef, ret_p: t_p8.clone(), body_p: Array::new(), tail_p: sample_pc.clone(), doc_p: Text::lit("`@PerKey`\'s outer: each key\'s inner by key, at the read point.") }]));
                this.dyn_reads_p = crate::prelude::insert(&crate::prelude::insert(&this.dyn_reads_p, &name_pk, &Array::from(vec![crate::lower::node_::Read::OwnRead(kept_p9.clone())])), &source_pa, &reads_pn);
                this
            };
            let (r_po, wx3_pp) = crate::lower::node_::dynamics::updated_event_f(&wx2_pd, menv_p1, args_p2, &src_ty_p7);
            (crate::lower::node_::connect_f(&wx3_pp, &r_po, &crate::lower::node_::Sk::SkPerKey(kept_p9.clone())), crate::lower::node_::Wres::WrDyn(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XSelf), name_pk.clone(), Array::from(vec![crate::lower::model::Ex::XCx])), Array::from(vec![crate::lower::node_::Read::OwnRead(kept_p9.clone())]), t_p8.clone()))
        },
    }
}

/// ```prism
/// RunLine: unbounded fn Wx, Env, [Arg], Expr, ?Nat -> ((Wx, Wres))
/// ```
pub fn run_line_f(wx_p0: &crate::lower::node_::Wx, benv_p1: &crate::lower::types::Env, args_p2: &Array<crate::syntax::Arg>, e_p3: &crate::syntax::Expr, target_o4: &Option<Nat>) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    let lx_p5 = wx_p0.lx_p.clone();
    let t_p6 = crate::lower::types::out_ty_of_f(&lx_p5, &crate::lower::types::out_of_f(&crate::lower::type_at_f(&lx_p5, &e_p3.span_p)));
    let (p_pd, wx1_pe) = crate::lower::node_::fresh_name_f(wx_p0, &Text::lit("run"));
    let wx2_p7 = {
        let mut this: crate::lower::node_::Wx = wx1_pe.clone();
        this.pos_p = crate::lower::model::next_pos_f(&this.pos_p);
        this.taken_p = crate::prelude::append(&this.taken_p, &Array::from(vec![Text::from(format!("{}_job", &p_pd)), Text::from(format!("{}_again", &p_pd)), Text::from(format!("{}_started", &p_pd)), Text::from(format!("{}_turn", &p_pd))]));
        this
    };
    let start_p8 = match crate::prelude::index(args_p2, &Nat::from(0u32)) {
        Some(a_pf) => match &*a_pf.value_p.kind_p {
            crate::syntax::ExprKind::EName(n_pg) => {
                let (q_oh, _) = crate::check::env::names::resolve_value_f(&lx_p5.g_p, &lx_p5.home_p, n_pg);
                crate::lower::model::Ex::XPath(crate::lower::expr::start_path_f(&lx_p5, &crate::prelude::or(&q_oh, &Text::lit(""))))
            },
            _ => crate::lower::expr::refusal_f(&Text::lit("an `@Run` of a function value that is not a name")),
        },
        None => crate::lower::expr::refusal_f(&Text::lit("an `@Run` without its function")),
    };
    let x_p9 = match crate::prelude::index(args_p2, &Nat::from(1u32)) {
        Some(a_pi) => crate::lower::types::own_f(&crate::lower::expr::value_of_f(&lx_p5, benv_p1, &a_pi.value_p)),
        None => crate::lower::model::Ex::XUnit,
    };
    let wx3_pa = crate::lower::node_::add_field_f(&wx2_p7, &Text::from(format!("{}_job", &p_pd)), &crate::lower::model::OutTy::OutHold(Rc::new(crate::lower::model::OutTy::OutJob(Rc::new(t_p6.clone())))), &Text::lit("`@Run`\'s job (`@Machine`\'s state)"), &crate::lower::model::Ex::XCall(Text::lit("Hold::new"), Array::from(vec![crate::lower::model::Ex::XApply(Rc::new(start_p8.clone()), Array::from(vec![x_p9.clone()])), crate::lower::model::Ex::XCx])));
    let wx4_pb = crate::lower::node_::add_field_last_f(&wx3_pa, &Text::from(format!("{}_again", &p_pd)), &crate::lower::model::OutTy::OutDefer(Rc::new(crate::lower::model::OutTy::OutUnit)), &Text::lit("`@Run`\'s `!again`"), &crate::lower::model::Ex::XCall(Text::lit("Defer::new"), Array::new()));
    let (s_pj, wx5_pk) = crate::lower::node_::add_gn_f(&wx4_pb, &Text::from(format!("{}_started", &p_pd)), &crate::lower::model::OutTy::OutUnit, &crate::lower::node_::GnKind::GnStarted, &Nat::from(0u32));
    let (a_pl, wx6_pm) = crate::lower::node_::add_gn_f(&wx5_pk, &Text::from(format!("{}_again", &p_pd)), &crate::lower::model::OutTy::OutUnit, &crate::lower::node_::GnKind::GnDeferred, &Nat::from(0u32));
    let (m_pn, wx7_po) = crate::lower::node_::dynamics::merge_f(&wx6_pm, &Text::from(format!("{}_turn", &p_pd)), &crate::lower::model::OutTy::OutUnit, &crate::lower::node_::ev_ref_of_f(&wx6_pm, &s_pj), &crate::lower::node_::ev_ref_of_f(&wx6_pm, &a_pl));
    let (res_pq, wx8_pr) = match target_o4 {
        Some(n_pp) => (n_pp.clone(), wx7_po.clone()),
        None => crate::lower::node_::add_gn_f(&wx7_po, &Text::from(format!("{}_done", &p_pd)), &t_p6, &crate::lower::node_::GnKind::GnNamed, &Nat::from(0u32)),
    };
    let wx9_pc = {
        let mut this: crate::lower::node_::Wx = crate::lower::node_::connect_f(&wx8_pr, &crate::lower::node_::ev_ref_of_f(&wx8_pr, &m_pn), &crate::lower::node_::Sk::SkCycle(Text::from(format!("{}_job", &p_pd)), Text::from(format!("{}_again", &p_pd)), res_pq.clone()));
        this.started_p = crate::prelude::push(&this.started_p, &s_pj);
        this.defers_p = crate::prelude::push(&this.defers_p, &(Text::from(format!("{}_again", &p_pd)), a_pl.clone()));
        this
    };
    (wx9_pc.clone(), crate::lower::node_::Wres::WrEv(crate::lower::node_::ev_ref_of_f(&wx9_pc, &res_pq)))
}

/// ```prism
/// MachineLine: unbounded fn Wx, Env, Env, [Arg], Expr, ?Nat -> ((Wx, Wres))
/// ```
pub fn machine_line_f(wx_p0: &crate::lower::node_::Wx, benv_p1: &crate::lower::types::Env, menv_p2: &crate::lower::types::Env, args_p3: &Array<crate::syntax::Arg>, e_p4: &crate::syntax::Expr, target_o5: &Option<Nat>) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    let lx_p6 = wx_p0.lx_p.clone();
    let t_p7 = crate::lower::types::out_ty_of_f(&lx_p6, &crate::lower::types::out_of_f(&crate::lower::type_at_f(&lx_p6, &e_p4.span_p)));
    let (f_p9, wx1_pa) = crate::lower::node_::fresh_name_f(wx_p0, &Text::lit("machine"));
    let step_p8 = match crate::prelude::index(args_p3, &Nat::from(0u32)) {
        Some(a_pb) => match &*a_pb.value_p.kind_p {
            crate::syntax::ExprKind::EName(n_pc) => {
                let (q_od, _) = crate::check::env::names::resolve_value_f(&lx_p6.g_p, &lx_p6.home_p, n_pc);
                match &q_od {
                    Some(q_pe) => crate::lower::value_path_f(&lx_p6, q_pe),
                    None => Text::lit(""),
                }
            },
            _ => Text::lit(""),
        },
        None => Text::lit(""),
    };
    match (step_p8.clone(), crate::prelude::index(args_p3, &Nat::from(1u32)), crate::prelude::index(args_p3, &Nat::from(2u32))) {
        (sp_pf, Some(init_pg), Some(ev_ph)) if (&sp_pf != &Text::lit("")) => {
            let st_pi = crate::lower::types::out_ty_of_f(&lx_p6, &crate::lower::types::peel_f(&crate::lower::type_at_f(&lx_p6, &init_pg.value_p.span_p)));
            let x_pj = crate::lower::types::own_f(&crate::lower::expr::value_of_f(&lx_p6, benv_p1, &init_pg.value_p));
            let wx2_pk = crate::lower::node_::add_field_f(&wx1_pa, &Text::from(format!("{}_state", &f_p9)), &crate::lower::model::OutTy::OutHold(Rc::new(st_pi.clone())), &Text::lit("`@Machine`\'s state"), &crate::lower::model::Ex::XCall(Text::lit("Hold::new"), Array::from(vec![x_pj.clone(), crate::lower::model::Ex::XCx])));
            let (out_pm, wx3_pn) = match target_o5 {
                Some(n_pl) => (n_pl.clone(), wx2_pk.clone()),
                None => crate::lower::node_::add_gn_f(&wx2_pk, &Text::from(format!("{}_fired", &f_p9)), &t_p7, &crate::lower::node_::GnKind::GnNamed, &Nat::from(0u32)),
            };
            let (r_po, wx4_pp) = crate::lower::node_::dynamics::event_ref_f(&wx3_pn, menv_p2, &ev_ph.value_p);
            (crate::lower::node_::connect_f(&wx4_pp, &r_po, &crate::lower::node_::Sk::SkMachine(Text::from(format!("{}_state", &f_p9)), sp_pf.clone(), out_pm.clone())), crate::lower::node_::Wres::WrEv(crate::lower::node_::ev_ref_of_f(&wx4_pp, &out_pm)))
        },
        _ => {
            let wx2_pq = {
                let mut this: crate::lower::node_::Wx = wx1_pa.clone();
                this.build_p = crate::prelude::push(&this.build_p, &crate::lower::expr::refusal_do_f(&Text::lit("an `@Machine` whose step is not a named function")));
                this
            };
            (wx2_pq.clone(), crate::lower::node_::Wres::WrUnit)
        },
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// InlineWidget: unbounded fn Wx, Env, Env, Text, ValInfo, [Arg], Expr -> ((Wx, Wres))
/// ```
pub fn inline_widget_f(wx_p0: &crate::lower::node_::Wx, benv_p1: &crate::lower::types::Env, menv_p2: &crate::lower::types::Env, qk_p3: &Text, v_p4: &crate::check::env::ValInfo, args_p5: &Array<crate::syntax::Arg>, e_p6: &crate::syntax::Expr) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    let lx_p7 = wx_p0.lx_p.clone();
    let clauses_p8 = crate::lower::jobs::clauses_of_f(&lx_p7.g_p, qk_p3);
    let w_o9 = widget_decl_of_o(&lx_p7.g_p, qk_p3);
    let (params_pe, body_of) = match &w_o9 {
        Some(wd_pa) => (Array::new(), Some(wd_pa.body_p.clone())),
        None => 'm29508: {
            if let m29508_0 = &clauses_p8 && (m29508_0.len() == 1) && let Some(c_pb) = crate::prelude::index(m29508_0, &Nat::from(0u32)) {
                break 'm29508 match &c_pb.body_p {
                    crate::syntax::decls::FnBody::BodyBlock(b_pc) => (c_pb.params_p.clone(), Some(b_pc.clone())),
                    crate::syntax::decls::FnBody::BodyExpr(x_pd) => (c_pb.params_p.clone(), Some(crate::syntax::Block { stmts_p: Array::from(vec![crate::syntax::Stmt { kind_p: crate::syntax::StmtKind::SExpr(x_pd.clone()), span_p: x_pd.span_p.clone() }]), inline_p: true, span_p: x_pd.span_p.clone() })),
                };
            }
            (Array::new(), None)
        },
    };
    match &body_of {
        None => if &crate::prelude::len(&clauses_p8) == &Nat::from(0u32) {
            {
                let wx2_pg = {
                    let mut this: crate::lower::node_::Wx = wx_p0.clone();
                    this.build_p = crate::prelude::push(&this.build_p, &crate::lower::expr::refusal_do_f(&Text::from(format!("the builtin widget {}", &crate::check::types::bare_name_f(qk_p3)))));
                    this
                };
                (wx2_pg.clone(), crate::lower::node_::Wres::WrUnit)
            }
        } else {
            match crate::prelude::index(args_p5, &Nat::from(0u32)) {
                Some(a_ph) => {
                    let call_pi = crate::syntax::Block { stmts_p: Array::from(vec![crate::syntax::Stmt { kind_p: crate::syntax::StmtKind::SExpr(e_p6.clone()), span_p: e_p6.span_p.clone() }]), inline_p: true, span_p: e_p6.span_p.clone() };
                    crate::lower::node_::switch_::clause_widget_line_f(wx_p0, menv_p2, &a_ph.value_p, &call_pi, qk_p3, v_p4, e_p6)
                },
                None => {
                    let wx2_pj = {
                        let mut this: crate::lower::node_::Wx = wx_p0.clone();
                        this.build_p = crate::prelude::push(&this.build_p, &crate::lower::expr::refusal_do_f(&Text::lit("a widget of several clauses that takes no arguments")));
                        this
                    };
                    (wx2_pj.clone(), crate::lower::node_::Wres::WrUnit)
                },
            }
        },
        Some(body_pk) => if &recursion_f(&wx_p0.inlining_p, qk_p3) > &Nat::from(16u32) {
            too_deep_f(wx_p0, qk_p3, e_p6)
        } else {
            {
                let lxc_pl = crate::lower::program::in_module_at_f(&lx_p7, &v_p4.file_p, &v_p4.home_p, &lx_p7.site_p);
                let ptys_pm = match &v_p4.scheme_p.ty_p {
                    crate::check::types::Ty::TyFn(_, ps_ps, _) => ps_ps.clone(),
                    _ => Array::new(),
                };
                let (wx1_p15, be1_p16, me1_p17) = crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(&params_pe)), (wx_p0.clone(), crate::lower::types::empty_env_p(), crate::lower::types::empty_env_p()), {
                    let params_pex = params_pe.clone();
                    let lxc_plx = lxc_pl.clone();
                    let ptys_pmx = ptys_pm.clone();
                    let args_p5x = args_p5.clone();
                    let benv_p1x = benv_p1.clone();
                    let menv_p2x = menv_p2.clone();
                    Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), Nat)| {
                        let params_pexy = params_pex.clone();
                        let lxc_plxy = lxc_plx.clone();
                        let ptys_pmxy = ptys_pmx.clone();
                        let args_p5xy = args_p5x.clone();
                        let benv_p1xy = benv_p1x.clone();
                        let menv_p2xy = menv_p2x.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let (w_pt, be_pu, me_pv) = p0;
                            let i_p10 = p1;
                            {
                                let p_p11 = crate::prelude::or(&crate::prelude::index(&params_pexy, &i_p10), &crate::lower::patterns::dummy_pat_p());
                                let nkey_p12 = crate::lower::functions::plain_binder_f(&lxc_plxy, &p_p11);
                                let pty_p13 = crate::prelude::or(&crate::prelude::index(&ptys_pmxy, &i_p10), &crate::check::types::Ty::TyErr);
                                match crate::prelude::index(&args_p5xy, &i_p10) {
                                    None => prism_rtl::Turn::Finished((w_pt.clone(), be_pu.clone(), me_pv.clone())),
                                    Some(a_p14) => prism_rtl::Turn::Finished(bind_param_f(&w_pt, &benv_p1xy, &menv_p2xy, &be_pu, &me_pv, &nkey_p12, &pty_p13, &a_p14.value_p)),
                                }
                            }
                        }))
                    }) as Rc<dyn Fn(((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), Nat)) -> Rc<dyn prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>>>
                }));
                let call_span_pn = match &*e_p6.kind_p {
                    crate::syntax::ExprKind::ECall(c_p18, _, _, _) => c_p18.span_p.clone(),
                    _ => e_p6.span_p.clone(),
                };
                let lxi_po = {
                    let mut this: crate::lower::Lx = lxc_pl.clone();
                    this.inlined_p = match crate::prelude::get(&lx_p7.call_ids_p, &crate::lower::place_key_f(&lx_p7, &call_span_pn)) {
                        Some(id_p19) => Text::from(format!("{}_{}", &lx_p7.inlined_p, &crate::lower::base32_f(&id_p19))),
                        None => lx_p7.inlined_p.clone(),
                    };
                    this
                };
                let inner_pp = {
                    let mut this: crate::lower::node_::Wx = wx1_p15.clone();
                    this.lx_p = lxi_po.clone();
                    this.inlining_p = crate::prelude::push(&this.inlining_p, qk_p3);
                    this.result_p = crate::lower::node_::Wres::WrUnit;
                    this
                };
                let done_pq = crate::lower::node_::def::block_into_f(&inner_pp, &be1_p16, &me1_p17, body_pk);
                let back_pr = {
                    let mut this: crate::lower::node_::Wx = done_pq.clone();
                    this.lx_p = lx_p7.clone();
                    this.inlining_p = wx_p0.inlining_p.clone();
                    this.result_p = wx_p0.result_p.clone();
                    this
                };
                (back_pr.clone(), done_pq.result_p.clone())
            }
        },
    }
}

/// ```prism
/// Recursion: fn [Text], Text -> Nat
/// ```
pub fn recursion_f(inlining_p0: &Array<Text>, qk_p1: &Text) -> Nat {
    crate::prelude::fold(inlining_p0, &Nat::from(0u32), &(|n_p2: &Nat, k_p3: &Text| if k_p3 == qk_p1 { n_p2 + &Nat::from(1u32) } else { n_p2.clone() }))
}

/// ```prism
/// TooDeep: unbounded fn Wx, Text, Expr -> ((Wx, Wres))
/// ```
pub fn too_deep_f(wx_p0: &crate::lower::node_::Wx, qk_p1: &Text, e_p2: &crate::syntax::Expr) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    let lx_p3 = wx_p0.lx_p.clone();
    let what_p4 = Text::from(format!("`{}` recurses deeper than the compiler inlines it (16 levels)", &crate::check::types::bare_name_f(qk_p1)));
    let wx1_p5 = {
        let mut this: crate::lower::node_::Wx = wx_p0.clone();
        this.build_p = crate::prelude::push(&this.build_p, &crate::lower::model::Do::DoReturn(crate::lower::model::Ex::XCtor(Text::lit("Err"), Array::from(vec![crate::lower::model::Ex::XCall(Text::lit("Fault::too_deep"), Array::from(vec![crate::lower::model::Ex::XStr(what_p4.clone())]))]))));
        this.fallible_p = true;
        this
    };
    let t_p6 = crate::lower::types::out_ty_of_f(&lx_p3, &crate::lower::types::out_of_f(&crate::lower::type_at_f(&lx_p3, &e_p2.span_p)));
    let called_p7 = match crate::lower::type_at_f(&lx_p3, &e_p2.span_p) {
        crate::check::types::Ty::TyAt(i_p8, _) => (*i_p8).clone(),
        other_p9 => other_p9,
    };
    match crate::lower::types::layer_of_f(&called_p7) {
        crate::lower::types::Layer::LyDyn => (wx1_p5.clone(), crate::lower::node_::Wres::WrDyn(crate::lower::model::Ex::XUnreachable, Array::new(), t_p6.clone())),
        crate::lower::types::Layer::LyEv => {
            let (id_pa, wx2_pb) = crate::lower::node_::add_gn_f(&wx1_p5, &Text::lit("too_deep"), &t_p6, &crate::lower::node_::GnKind::GnNever, &Nat::from(0u32));
            (wx2_pb.clone(), crate::lower::node_::Wres::WrEv(crate::lower::node_::ev_ref_of_f(&wx2_pb, &id_pa)))
        },
        _ => if &t_p6 == &crate::lower::model::OutTy::OutUnit {
            (wx1_p5.clone(), crate::lower::node_::Wres::WrUnit)
        } else {
            {
                let wx2_pc = {
                    let mut this: crate::lower::node_::Wx = wx1_p5.clone();
                    this.lets_p = crate::prelude::push(&this.lets_p, &crate::lower::model::Do::DoReturn(crate::lower::model::Ex::XCtor(Text::lit("Err"), Array::from(vec![crate::lower::model::Ex::XCall(Text::lit("Fault::too_deep"), Array::from(vec![crate::lower::model::Ex::XStr(what_p4.clone())]))]))));
                    this
                };
                (wx2_pc.clone(), crate::lower::node_::Wres::WrPlain(crate::lower::model::Ex::XUnreachable, t_p6.clone()))
            }
        },
    }
}

/// ```prism
/// ?WidgetDeclOf: fn G, Text -> ?WidgetDecl
/// ```
pub fn widget_decl_of_o(g_p0: &crate::check::env::G, qk_p1: &Text) -> Option<crate::syntax::decls::WidgetDecl> {
    crate::prelude::fold(&g_p0.defs_p, &None, &(|found_o2: &Option<crate::syntax::decls::WidgetDecl>, d_p3: &crate::check::env::Def| if &d_p3.qk_p == qk_p1 { def_widget_o(d_p3, found_o2) } else { found_o2.clone() }))
}

/// ```prism
/// ?DefWidget: fn Def, ?WidgetDecl -> ?WidgetDecl
/// ```
pub fn def_widget_o(d_p0: &crate::check::env::Def, other_o1: &Option<crate::syntax::decls::WidgetDecl>) -> Option<crate::syntax::decls::WidgetDecl> {
    match &d_p0.body_p {
        crate::check::env::DefBody::DbWidget(w_p2) => Some(w_p2.clone()),
        _ => other_o1.clone(),
    }
}

/// ```prism
/// BindParam: unbounded fn Wx, Env, Env, Env, Env, Text, Ty, Expr -> ((Wx, Env, Env))
/// ```
pub fn bind_param_f(wx_p0: &crate::lower::node_::Wx, cbenv_p1: &crate::lower::types::Env, cmenv_p2: &crate::lower::types::Env, be_p3: &crate::lower::types::Env, me_p4: &crate::lower::types::Env, nkey_p5: &Text, pty_p6: &crate::check::types::Ty, arg_p7: &crate::syntax::Expr) -> (crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env) {
    let lx_p8 = wx_p0.lx_p.clone();
    let t_p9 = crate::lower::types::out_ty_of_f(&lx_p8, &crate::lower::types::peel_f(pty_p6));
    match crate::lower::types::layer_of_f(pty_p6) {
        crate::lower::types::Layer::LyBlueprint => {
            let b_pa = crate::lower::types::Bn::BnWidget(arg_p7.clone(), cbenv_p1.clone(), cmenv_p2.clone(), lx_p8.clone());
            (wx_p0.clone(), crate::lower::types::bind_f(be_p3, nkey_p5, &b_pa), crate::lower::types::bind_f(me_p4, nkey_p5, &b_pa))
        },
        crate::lower::types::Layer::LyEv => {
            let (r_pc, wx2_pd) = crate::lower::node_::dynamics::event_ref_f(wx_p0, cmenv_p2, arg_p7);
            let b_pb = crate::lower::types::Bn::BnEv(r_pc.clone(), t_p9.clone());
            (wx2_pd.clone(), crate::lower::types::bind_f(be_p3, nkey_p5, &b_pb), crate::lower::types::bind_f(me_p4, nkey_p5, &b_pb))
        },
        crate::lower::types::Layer::LyDyn => {
            let (ex_pf, reads_pg) = crate::lower::node_::dynamics::dynamic_expr_f(wx_p0, cmenv_p2, arg_p7);
            let b_pe = crate::lower::types::Bn::BnDyn(ex_pf.clone(), reads_pg.clone(), t_p9.clone());
            let (wx0_pk, be0_pl) = if crate::lower::node_::def::all_inited_f(wx_p0, &reads_pg) && crate::lower::node_::def::names_inited_f(cbenv_p1, arg_p7) {
                {
                    let (rsi_pi, wxi_pj) = crate::lower::node_::fresh_name_f(wx_p0, &Text::from(format!("{}_arg", &crate::lower::snake_f(nkey_p5))));
                    let wxj_ph = {
                        let mut this: crate::lower::node_::Wx = wxi_pj.clone();
                        this.lets_p = crate::prelude::push(&this.lets_p, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaBind(Text::from(format!("{}_init", &rsi_pi)))), t_p9.clone()), crate::lower::types::own_f(&crate::lower::expr::value_of_f(&lx_p8, &crate::lower::node_::def::init_env_f(cbenv_p1), arg_p7))));
                        this.inited_p = crate::prelude::push(&this.inited_p, &rsi_pi);
                        this
                    };
                    (wxj_ph.clone(), crate::lower::types::bind_f(be_p3, &Text::from(format!("{}#init", nkey_p5)), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(Text::from(format!("{}_init", &rsi_pi))), crate::lower::types::Holding::Owned, t_p9.clone())))
                }
            } else {
                (wx_p0.clone(), be_p3.clone())
            };
            'm36215: {
                if let crate::lower::model::Ex::XMethod(m36215_0_0, _, _) = &ex_pf && let crate::lower::model::Ex::XSelf = &**m36215_0_0 {
                    break 'm36215 (wx0_pk.clone(), crate::lower::types::bind_f(&be0_pl, nkey_p5, &b_pe), crate::lower::types::bind_f(me_p4, nkey_p5, &b_pe));
                }
                {
                    let (rs_pp, wx2_pq) = crate::lower::node_::fresh_name_f(&wx0_pk, &crate::lower::snake_f(nkey_p5));
                    let getter_pm = crate::lower::model::MethDef { name_p: rs_pp.clone(), recv_p: crate::lower::model::Recv::RecvRef, params_p: Array::new(), cx_p: crate::lower::model::CxArg::CxRef, ret_p: t_p9.clone(), body_p: Array::new(), tail_p: ex_pf.clone(), doc_p: Text::from(format!("`{}`, a widget\'s parameter, as its rows read it", nkey_p5)) };
                    let wx3_pn = {
                        let mut this: crate::lower::node_::Wx = wx2_pq.clone();
                        this.getters_p = crate::prelude::push(&this.getters_p, &getter_pm);
                        this.dyn_reads_p = crate::prelude::insert(&this.dyn_reads_p, &rs_pp, &reads_pg);
                        this
                    };
                    let rb_po = crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XSelf), rs_pp.clone(), Array::from(vec![crate::lower::model::Ex::XCx])), Array::from(vec![crate::lower::node_::Read::OwnRead(rs_pp.clone())]), t_p9.clone());
                    (wx3_pn.clone(), crate::lower::types::bind_f(&crate::lower::types::bind_f(&be0_pl, nkey_p5, &b_pe), &Text::from(format!("{}#row", nkey_p5)), &rb_po), crate::lower::types::bind_f(&crate::lower::types::bind_f(me_p4, nkey_p5, &b_pe), &Text::from(format!("{}#row", nkey_p5)), &rb_po))
                }
            }
        },
        _ => {
            let (rs_pt, wx2_pu) = crate::lower::node_::fresh_name_f(wx_p0, &crate::lower::snake_f(nkey_p5));
            let v_pr = crate::lower::types::own_f(&crate::lower::expr::value_of_f(&lx_p8, cbenv_p1, arg_p7));
            let wx3_ps = {
                let mut this: crate::lower::node_::Wx = wx2_pu.clone();
                this.lets_p = crate::prelude::push(&this.lets_p, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(rs_pt.clone()), v_pr.clone()));
                this.fields_p = crate::prelude::push(&this.fields_p, &(rs_pt.clone(), t_p9.clone(), Text::from(format!("`{}`", nkey_p5))));
                this.inits_p = crate::prelude::push(&this.inits_p, &(rs_pt.clone(), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(rs_pt.clone())))));
                this
            };
            let (be2_pv, me2_p10) = crate::lower::node_::bind_plain_f(be_p3, me_p4, nkey_p5, &rs_pt, &t_p9);
            (wx3_ps.clone(), be2_pv.clone(), me2_p10.clone())
        },
    }
}
