//! The module `Lower.Node.Static`, from `target/bootstrap/src/prismc/lower/node/static.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file. The runtime
//! side is reached from the crate, `crate::prelude` (and through it `::prism_rtl`), the
//! standard library from `::std`, and nothing is imported by name: a program's own type
//! (`Row`, `Option`) hides none of theirs. The traits are in scope unnamed, for their methods.

use crate::prelude::traits::*;

/// `HostForm`:
///
/// ```prism
/// type HostForm = choice:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub enum HostForm {
    HostEach,
    HostSome,
    HostList,
}

impl crate::prelude::Show for HostForm {
    fn show(&self, p: &mut crate::prelude::Printer) {
        match self {
            HostForm::HostEach => p.choice("HostEach", &[]),
            HostForm::HostSome => p.choice("HostSome", &[]),
            HostForm::HostList => p.choice("HostList", &[]),
        }
    }
}

impl crate::prelude::ToPod for HostForm {
    fn to_pod(&self) -> crate::prelude::Pod {
        match self {
            HostForm::HostEach => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("HostEach", 0), vec![]),
            HostForm::HostSome => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("HostSome", 1), vec![]),
            HostForm::HostList => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("HostList", 2), vec![]),
        }
    }
}

impl crate::prelude::FromPod for HostForm {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        match p.structure() {
            crate::prelude::Pod::Choice(c, a) if &**c == "HostEach" && a.len() == 0 => ::std::result::Result::Ok(HostForm::HostEach),
            crate::prelude::Pod::Choice(c, a) if &**c == "HostSome" && a.len() == 0 => ::std::result::Result::Ok(HostForm::HostSome),
            crate::prelude::Pod::Choice(c, a) if &**c == "HostList" && a.len() == 0 => ::std::result::Result::Ok(HostForm::HostList),
            other => ::prism_rtl::pod::mismatch("a HostForm", other),
        }
    }
}

/// ```prism
/// WidgetLine: unbounded fn Wx, Env, Env, Expr, ?Bn -> ((Wx, Wres))
/// ```
pub fn widget_line_f(wx_p0: &crate::lower::node_::Wx, benv_p1: &crate::lower::types::Env, menv_p2: &crate::lower::types::Env, e_p3: &crate::syntax::Expr, bound_o4: &::std::option::Option<crate::lower::types::Bn>) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    let lx_p5 = wx_p0.lx_p.clone();
    let (callee_pe, args_pf) = match &*e_p3.kind_p {
        crate::syntax::ExprKind::ECall(c_pc, xs_pd, _, _) => ((**c_pc).clone(), xs_pd.clone()),
        _ => (e_p3.clone(), crate::prelude::Array::new()),
    };
    let qualified_o6 = match &*e_p3.kind_p {
        crate::syntax::ExprKind::EField(r_pg, sigils_ph, name_pi) => crate::lower::expr::qualified_field_in_o(&lx_p5, menv_p2, &**r_pg, sigils_ph, name_pi),
        _ => ::std::option::Option::None,
    };
    let qk_p7 = match &*callee_pe.kind_p {
        crate::syntax::ExprKind::EName(n_pj) => {
            let (q_ok, _) = crate::check::env::names::resolve_value_f(&lx_p5.g_p, &lx_p5.home_p, n_pj);
            crate::prelude::or(&q_ok, &crate::prelude::Text::lit(""))
        },
        _ => match &qualified_o6 {
            ::std::option::Option::Some(n_pl) => {
                let (q_om, _) = crate::check::env::names::resolve_value_f(&lx_p5.g_p, &lx_p5.home_p, n_pl);
                crate::prelude::or(&q_om, &crate::prelude::Text::lit(""))
            },
            ::std::option::Option::None => crate::prelude::Text::lit(""),
        },
    };
    let target_o8 = match bound_o4 {
        ::std::option::Option::Some(crate::lower::types::Bn::BnEv(er_pn, _)) => ::std::option::Option::Some(er_pn.node_p.clone()),
        _ => ::std::option::Option::None,
    };
    let param_o9 = match &*callee_pe.kind_p {
        crate::syntax::ExprKind::EName(n_po) => if &crate::prelude::len(&n_po.path_p) == &crate::prelude::Nat::from(1u32) {
            crate::prelude::get(&menv_p2.names_p, &crate::check::env::sname_key_f(n_po))
        } else {
            ::std::option::Option::None
        },
        _ => ::std::option::Option::None,
    };
    let named_oa = match &*callee_pe.kind_p {
        crate::syntax::ExprKind::EName(n_pp) => if (&crate::prelude::len(&n_pp.path_p) == &crate::prelude::Nat::from(1u32)) && (&crate::prelude::len(&args_pf) == &crate::prelude::Nat::from(0u32)) {
            crate::prelude::get(&menv_p2.names_p, &crate::prelude::Text::from(format!("{}#blueprint", &crate::check::env::sname_key_f(n_pp))))
        } else {
            ::std::option::Option::None
        },
        _ => ::std::option::Option::None,
    };
    let held_pb = match &*e_p3.kind_p {
        crate::syntax::ExprKind::EField(_, _, _) => &crate::lower::node_::switch_::is_some_f(&qualified_o6) == &false,
        crate::syntax::ExprKind::EName(n_pq) => match if &crate::prelude::len(&n_pq.path_p) == &crate::prelude::Nat::from(1u32) {
            crate::prelude::get(&menv_p2.names_p, &crate::check::env::sname_key_f(n_pq))
        } else {
            ::std::option::Option::None
        } {
            ::std::option::Option::Some(crate::lower::types::Bn::BnLocal(_, _, _)) => true,
            _ => false,
        },
        _ => false,
    };
    if held_pb {
        value_blueprint_line_f(wx_p0, menv_p2, e_p3)
    } else {
        match &named_oa {
            ::std::option::Option::Some(crate::lower::types::Bn::BnWidget(x_pr, _, _, _)) => let_blueprint_line_f(wx_p0, benv_p1, menv_p2, x_pr, e_p3, bound_o4),
            _ => match &param_o9 {
                ::std::option::Option::Some(crate::lower::types::Bn::BnWidget(x_ps, cbenv_pt, cmenv_pu, clx_pv)) => apply_widget_param_f(wx_p0, benv_p1, menv_p2, x_ps, cbenv_pt, cmenv_pu, clx_pv, e_p3, &args_pf, bound_o4),
                ::std::option::Option::Some(crate::lower::types::Bn::BnLocalWidget(b_p10)) => local_widget_line_f(wx_p0, benv_p1, menv_p2, b_p10, e_p3),
                ::std::option::Option::Some(crate::lower::types::Bn::BnLocalFn(cs_p11)) if (&crate::prelude::len(&args_pf) > &crate::prelude::Nat::from(0u32)) => local_function_line_f(wx_p0, benv_p1, menv_p2, benv_p1, menv_p2, &crate::lower::expr::local_fn_lx_f(&lx_p5, &callee_pe.span_p), cs_p11, &callee_pe, e_p3, &args_pf),
                ::std::option::Option::Some(crate::lower::types::Bn::BnLocal(_, _, _)) if (&crate::prelude::len(&args_pf) > &crate::prelude::Nat::from(0u32)) => applied_function_line_f(wx_p0, menv_p2, &wx_p0.lx_p, menv_p2, &callee_pe, e_p3, &args_pf),
                _ => widget_call_f(wx_p0, benv_p1, menv_p2, e_p3, bound_o4, &qk_p7, &args_pf, &target_o8),
                _ => unreachable!("no arm matched"),
            },
        }
    }
}

/// ```prism
/// AppliedFunctionLine: unbounded fn Wx, Env, Lx, Env, Expr, Expr, [Arg] -> ((Wx, Wres))
/// ```
pub fn applied_function_line_f(wx_p0: &crate::lower::node_::Wx, menv_p1: &crate::lower::types::Env, clx_p2: &crate::lower::Lx, cmenv_p3: &crate::lower::types::Env, function_p4: &crate::syntax::Expr, e_p5: &crate::syntax::Expr, args_p6: &crate::prelude::Array<crate::syntax::Arg>) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    let held_p7 = crate::lower::expr::value_of_f(clx_p2, cmenv_p3, function_p4);
    let made_p8 = match crate::lower::types::value_ty_f(&held_p7) {
        crate::lower::model::OutTy::OutJobFn(_, ignore2_p9) => crate::lower::model::Ex::XCall(crate::lower::helper_ref_f(&crate::prelude::Text::lit("run_to_end")), crate::prelude::Array::from(vec![crate::lower::jobs::start_call_f(&held_p7, &crate::lower::expr::start_args_f(&wx_p0.lx_p, menv_p1, &held_p7, args_p6))])),
        _ => crate::lower::model::Ex::XApply(::std::rc::Rc::new(crate::lower::types::ref_f(&held_p7)), crate::prelude::run_to_end(crate::prelude::each_job(args_p6.clone(), {
            let wx_p0x = wx_p0.clone();
            let menv_p1x = menv_p1.clone();
            ::std::rc::Rc::new(move |p0: crate::syntax::Arg| {
                let wx_p0xy = wx_p0x.clone();
                let menv_p1xy = menv_p1x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let a_pa = p0;
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::lower::expr::ValueArgument { lx_p0: wx_p0xy.lx_p.clone(), env_p1: menv_p1xy.clone(), e_p2: a_pa.value_p.clone() }))
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::syntax::Arg) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>>>
        }))),
    };
    applied_blueprint_line_f(wx_p0, e_p5, &crate::lower::model::Ex::XRef(::std::rc::Rc::new(made_p8.clone())))
}

/// ```prism
/// ApplyWidgetParam: unbounded fn Wx, Env, Env, Expr, Env, Env, Lx, Expr, [Arg], ?Bn -> ((Wx, Wres))
/// ```
pub fn apply_widget_param_f(wx_p0: &crate::lower::node_::Wx, benv_p1: &crate::lower::types::Env, menv_p2: &crate::lower::types::Env, x_p3: &crate::syntax::Expr, cbenv_p4: &crate::lower::types::Env, cmenv_p5: &crate::lower::types::Env, clx_p6: &crate::lower::Lx, e_p7: &crate::syntax::Expr, args_p8: &crate::prelude::Array<crate::syntax::Arg>, bound_o9: &::std::option::Option<crate::lower::types::Bn>) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    if &crate::prelude::len(args_p8) > &crate::prelude::Nat::from(0u32) {
        match &*ungrouped_f(x_p3).kind_p {
            crate::syntax::ExprKind::EName(n_pa) => match if &crate::prelude::len(&n_pa.path_p) == &crate::prelude::Nat::from(1u32) {
                crate::prelude::get(&cmenv_p5.names_p, &crate::check::env::sname_key_f(n_pa))
            } else {
                ::std::option::Option::None
            } {
                ::std::option::Option::Some(crate::lower::types::Bn::BnWidget(x2_pb, cbenv2_pc, cmenv2_pd, clx2_pe)) => apply_widget_param_f(wx_p0, benv_p1, menv_p2, &x2_pb, &cbenv2_pc, &cmenv2_pd, &clx2_pe, e_p7, args_p8, bound_o9),
                ::std::option::Option::Some(crate::lower::types::Bn::BnLocal(_, _, _)) => applied_function_line_f(wx_p0, menv_p2, clx_p6, cmenv_p5, x_p3, e_p7, args_p8),
                _ => {
                    let (q_og, _) = crate::check::env::names::resolve_value_f(&clx_p6.g_p, &clx_p6.home_p, n_pa);
                    let target_of = match bound_o9 {
                        ::std::option::Option::Some(crate::lower::types::Bn::BnEv(er_ph, _)) => ::std::option::Option::Some(er_ph.node_p.clone()),
                        _ => ::std::option::Option::None,
                    };
                    match (q_og.clone(), if &crate::prelude::len(&n_pa.path_p) == &crate::prelude::Nat::from(1u32) {
                        crate::prelude::get(&cmenv_p5.names_p, &crate::check::env::sname_key_f(n_pa))
                    } else {
                        ::std::option::Option::None
                    }) {
                        (_, ::std::option::Option::Some(crate::lower::types::Bn::BnLocalFn(cs_pi))) => local_function_line_f(wx_p0, benv_p1, menv_p2, cbenv_p4, cmenv_p5, &crate::lower::expr::local_fn_lx_f(clx_p6, &ungrouped_f(x_p3).span_p), &cs_pi, &ungrouped_f(x_p3), e_p7, args_p8),
                        (::std::option::Option::Some(qk_pj), _) => widget_call_f(wx_p0, benv_p1, menv_p2, e_p7, bound_o9, &qk_pj, args_p8, &target_of),
                        _ => {
                            let wx2_pk = {
                                let mut this: crate::lower::node_::Wx = wx_p0.clone();
                                this.build_p = crate::prelude::push(&this.build_p, &crate::lower::expr::internal_bug_do_f(&crate::prelude::Text::lit("a widget function parameter whose argument names nothing")));
                                this
                            };
                            (wx2_pk.clone(), crate::lower::node_::Wres::WrUnit)
                        },
                    }
                },
            },
            crate::syntax::ExprKind::ELambda(params_ol, lambda_body_pm) => {
                let lambda_pn = ungrouped_f(x_p3);
                let ptys_po = match crate::lower::type_at_f(clx_p6, &lambda_pn.span_p) {
                    crate::check::types::Ty::TyFn(_, ps_pq, _) => ps_pq,
                    _ => crate::prelude::Array::new(),
                };
                let body_pp = match &**lambda_body_pm {
                    crate::syntax::LambdaBody::LbBlock(b_pr) => b_pr.clone(),
                    crate::syntax::LambdaBody::LbExpr(y_ps) => crate::syntax::Block { stmts_p: crate::prelude::Array::from(vec![crate::syntax::Stmt { kind_p: crate::syntax::StmtKind::SExpr((**y_ps).clone()), span_p: y_ps.span_p.clone() }]), inline_p: true, span_p: y_ps.span_p.clone() },
                };
                inlined_function_line_f(wx_p0, benv_p1, menv_p2, cbenv_p4, cmenv_p5, clx_p6, &crate::prelude::or(params_ol, &crate::prelude::Array::new()), &ptys_po, &body_pp, e_p7, args_p8)
            },
            _ => applied_function_line_f(wx_p0, menv_p2, clx_p6, cmenv_p5, x_p3, e_p7, args_p8),
        }
    } else {
        {
            let lx_pt = wx_p0.lx_p.clone();
            let inner_pu = {
                let mut this: crate::lower::node_::Wx = wx_p0.clone();
                this.lx_p = clx_p6.clone();
                this
            };
            let (done_p10, res_p11) = crate::lower::node_::def::build_line_f(&inner_pu, cbenv_p4, cmenv_p5, x_p3, &::std::option::Option::None);
            let back_pv = {
                let mut this: crate::lower::node_::Wx = done_p10.clone();
                this.lx_p = lx_pt.clone();
                this
            };
            (back_pv.clone(), res_p11.clone())
        }
    }
}

/// ```prism
/// InlinedFunctionLine: unbounded fn Wx, Env, Env, Env, Env, Lx, [Pattern], [Ty], Block, Expr, [Arg] -> ((Wx, Wres))
/// ```
pub fn inlined_function_line_f(wx_p0: &crate::lower::node_::Wx, benv_p1: &crate::lower::types::Env, menv_p2: &crate::lower::types::Env, cbenv_p3: &crate::lower::types::Env, cmenv_p4: &crate::lower::types::Env, clx_p5: &crate::lower::Lx, params_p6: &crate::prelude::Array<crate::syntax::Pattern>, ptys_p7: &crate::prelude::Array<crate::check::types::Ty>, body_p8: &crate::syntax::Block, e_p9: &crate::syntax::Expr, args_pa: &crate::prelude::Array<crate::syntax::Arg>) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    let lx_pb = wx_p0.lx_p.clone();
    let (wx1_po, be1_pp, me1_pq) = crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(params_p6)), (wx_p0.clone(), cbenv_p3.clone(), cmenv_p4.clone()), {
        let params_p6x = params_p6.clone();
        let clx_p5x = clx_p5.clone();
        let args_pax = args_pa.clone();
        let benv_p1x = benv_p1.clone();
        let menv_p2x = menv_p2.clone();
        let ptys_p7x = ptys_p7.clone();
        ::std::rc::Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::prelude::Nat)| {
            let params_p6xy = params_p6x.clone();
            let clx_p5xy = clx_p5x.clone();
            let args_paxy = args_pax.clone();
            let benv_p1xy = benv_p1x.clone();
            let menv_p2xy = menv_p2x.clone();
            let ptys_p7xy = ptys_p7x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (w_ph, be_pi, me_pj) = p0;
                let i_pk = p1;
                {
                    let p_pl = crate::prelude::or(&crate::prelude::index(&params_p6xy, &i_pk), &crate::lower::patterns::dummy_pat_p());
                    let nkey_pm = crate::lower::functions::plain_binder_f(&clx_p5xy, &p_pl);
                    match crate::prelude::index(&args_paxy, &i_pk) {
                        ::std::option::Option::None => ::prism_rtl::Turn::Finished((w_ph.clone(), be_pi.clone(), me_pj.clone())),
                        ::std::option::Option::Some(a_pn) => if &nkey_pm != &crate::prelude::Text::lit("") {
                            crate::prelude::call_then(crate::lower::start_local_name_at_f(clx_p5xy.clone(), nkey_pm.clone(), p_pl.span_p.clone()), move |local_name_at_f_10384: crate::prelude::Text| ::prism_rtl::Turn::Finished(bind_param_f(&w_ph, &benv_p1xy, &menv_p2xy, &be_pi, &me_pj, &nkey_pm, &local_name_at_f_10384, &crate::prelude::or(&crate::prelude::index(&ptys_p7xy, &i_pk), &crate::check::types::Ty::TyErr), &a_pn.value_p)))
                        } else {
                            ::prism_rtl::Turn::Finished(bind_param_pattern_f(&w_ph, &benv_p1xy, &menv_p2xy, &be_pi, &me_pj, &clx_p5xy, &p_pl, &crate::prelude::or(&crate::prelude::index(&ptys_p7xy, &i_pk), &crate::check::types::Ty::TyErr), &a_pn.value_p))
                        },
                    }
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>>>
    }));
    let call_span_pc = match &*e_p9.kind_p {
        crate::syntax::ExprKind::ECall(c_pr, _, _, _) => c_pr.span_p.clone(),
        _ => e_p9.span_p.clone(),
    };
    let lxi_pd = {
        let mut this: crate::lower::Lx = clx_p5.clone();
        this.inlined_p = match crate::prelude::get(&lx_pb.call_ids_p, &crate::lower::place_key_f(&lx_pb, &call_span_pc)) {
            ::std::option::Option::Some(id_ps) => crate::prelude::Text::from(format!("{}_{}", &lx_pb.inlined_p, &crate::lower::base32_f(&id_ps))),
            ::std::option::Option::None => lx_pb.inlined_p.clone(),
        };
        this
    };
    let inner_pe = {
        let mut this: crate::lower::node_::Wx = wx1_po.clone();
        this.lx_p = lxi_pd.clone();
        this.result_p = crate::lower::node_::Wres::WrUnit;
        this
    };
    let done_pf = crate::lower::node_::def::block_into_f(&inner_pe, &be1_pp, &me1_pq, body_p8);
    let back_pg = {
        let mut this: crate::lower::node_::Wx = done_pf.clone();
        this.lx_p = lx_pb.clone();
        this.result_p = wx_p0.result_p.clone();
        this
    };
    (back_pg.clone(), done_pf.result_p.clone())
}

/// ```prism
/// LocalFunctionLine: unbounded fn Wx, Env, Env, Env, Env, Lx, [FnClause], Expr, Expr, [Arg] -> ((Wx, Wres))
/// ```
pub fn local_function_line_f(wx_p0: &crate::lower::node_::Wx, benv_p1: &crate::lower::types::Env, menv_p2: &crate::lower::types::Env, cbenv_p3: &crate::lower::types::Env, cmenv_p4: &crate::lower::types::Env, clx_p5: &crate::lower::Lx, cs_p6: &crate::prelude::Array<crate::syntax::decls::FnClause>, named_p7: &crate::syntax::Expr, e_p8: &crate::syntax::Expr, args_p9: &crate::prelude::Array<crate::syntax::Arg>) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    let c_pa = crate::prelude::or(&crate::prelude::index(cs_p6, &crate::prelude::Nat::from(0u32)), &crate::lower::functions::dummy_clause_p());
    let mark_pb = crate::prelude::Text::from(format!("#applying{}", &c_pa.span_p.start_p));
    let ptys_pc = match crate::lower::types::peel_f(&crate::lower::subst_ty_f(clx_p5, &crate::lower::type_at_f(clx_p5, &named_p7.span_p))) {
        crate::check::types::Ty::TyFn(_, ps_pf, _) => ps_pf,
        _ => match crate::lower::types::peel_f(&crate::lower::subst_ty_f(clx_p5, &crate::lower::type_at_f(clx_p5, &c_pa.span_p))) {
            crate::check::types::Ty::TyFn(_, ps_pg, _) => ps_pg,
            _ => crate::prelude::Array::new(),
        },
    };
    let body_pd = match &c_pa.body_p {
        crate::syntax::decls::FnBody::BodyBlock(b_ph) => b_ph.clone(),
        crate::syntax::decls::FnBody::BodyExpr(y_pi) => crate::syntax::Block { stmts_p: crate::prelude::Array::from(vec![crate::syntax::Stmt { kind_p: crate::syntax::StmtKind::SExpr(y_pi.clone()), span_p: y_pi.span_p.clone() }]), inline_p: true, span_p: y_pi.span_p.clone() },
    };
    let refused_fe = {
        let wx_p0x = wx_p0.clone();
        ::std::rc::Rc::new(move |why_pj: &crate::prelude::Text| {
            let wx2_pk = {
                let mut this: crate::lower::node_::Wx = wx_p0x.clone();
                this.build_p = crate::prelude::push(&this.build_p, &crate::lower::expr::refusal_do_f(why_pj));
                this
            };
            (wx2_pk.clone(), crate::lower::node_::Wres::WrUnit)
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(&crate::prelude::Text) -> (crate::lower::node_::Wx, crate::lower::node_::Wres)>
    };
    if &crate::prelude::len(cs_p6) != &crate::prelude::Nat::from(1u32) {
        (&refused_fe)(&crate::prelude::Text::from(format!("a function of a block with several clauses, applied as a widget (`{}`)", &crate::check::env::def_name_text_f(&c_pa.name_p))))
    } else {
        if crate::check::env::has_key_f(&cmenv_p4.names_p, &mark_pb) {
            (&refused_fe)(&crate::prelude::Text::from(format!("a function of a block that applies itself as a widget (`{}`)", &crate::check::env::def_name_text_f(&c_pa.name_p))))
        } else {
            inlined_function_line_f(wx_p0, benv_p1, menv_p2, &crate::lower::types::bind_f(cbenv_p3, &mark_pb, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XUnit, crate::lower::types::Holding::Owned, crate::lower::model::OutTy::OutUnit)), &crate::lower::types::bind_f(cmenv_p4, &mark_pb, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XUnit, crate::lower::types::Holding::Owned, crate::lower::model::OutTy::OutUnit)), clx_p5, &c_pa.params_p, &ptys_pc, &body_pd, e_p8, args_p9)
        }
    }
}

/// ```prism
/// AppliedPath: fn Wx, Pos -> Ex
/// ```
pub fn applied_path_f(wx_p0: &crate::lower::node_::Wx, pos_p1: &crate::lower::model::Pos) -> crate::lower::model::Ex {
    if crate::lower::node_::finish::emits_f(wx_p0, pos_p1) {
        crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("path"))))
    } else {
        crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Path::root")), crate::prelude::Array::new())
    }
}

/// ```prism
/// ValueBlueprintLine: unbounded fn Wx, Env, Expr -> ((Wx, Wres))
/// ```
pub fn value_blueprint_line_f(wx_p0: &crate::lower::node_::Wx, menv_p1: &crate::lower::types::Env, e_p2: &crate::syntax::Expr) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    applied_blueprint_line_f(wx_p0, e_p2, &crate::lower::types::ref_f(&crate::lower::expr::value_of_f(&wx_p0.lx_p, menv_p1, e_p2)))
}

/// ```prism
/// AppliedBlueprintLine: unbounded fn Wx, Expr, Ex -> ((Wx, Wres))
/// ```
pub fn applied_blueprint_line_f(wx_p0: &crate::lower::node_::Wx, e_p1: &crate::syntax::Expr, blueprint_p2: &crate::lower::model::Ex) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    let lx_p3 = wx_p0.lx_p.clone();
    let pos_p4 = wx_p0.pos_p.clone();
    let out_ty_p5 = crate::lower::types::out_ty_of_f(&lx_p3, &crate::lower::types::out_of_f(&crate::lower::type_at_f(&lx_p3, &e_p1.span_p)));
    let heard_p6 = &crate::lower::node_::switch_::result_layer_f(&crate::lower::type_at_f(&lx_p3, &e_p1.span_p)) == &crate::lower::types::Layer::LyEv;
    let answered_p7 = ((&out_ty_p5 != &crate::lower::model::OutTy::OutUnit) && ((&crate::lower::node_::switch_::result_layer_f(&crate::lower::type_at_f(&lx_p3, &e_p1.span_p)) == &crate::lower::types::Layer::LyPlain) || (&crate::lower::node_::switch_::result_layer_f(&crate::lower::type_at_f(&lx_p3, &e_p1.span_p)) == &crate::lower::types::Layer::LyBlueprint))) && !crate::lower::types::is_bundle_f(&crate::lower::node_::def::line_out_full_f(&lx_p3, e_p1));
    let dynamic_p8 = (&crate::lower::node_::switch_::result_layer_f(&crate::lower::type_at_f(&lx_p3, &e_p1.span_p)) == &crate::lower::types::Layer::LyDyn) && !crate::lower::types::is_bundle_f(&crate::lower::node_::def::line_out_full_f(&lx_p3, e_p1));
    if crate::lower::types::is_bundle_f(&crate::lower::node_::def::line_out_full_f(&lx_p3, e_p1)) {
        applied_bundle_line_f(wx_p0, e_p1, blueprint_p2)
    } else {
        if (((&out_ty_p5 != &crate::lower::model::OutTy::OutUnit) && !heard_p6) && !answered_p7) && !dynamic_p8 {
            {
                let wx2_p9 = {
                    let mut this: crate::lower::node_::Wx = wx_p0.clone();
                    this.build_p = crate::prelude::push(&this.build_p, &crate::lower::expr::internal_bug_do_f(&crate::prelude::Text::from(format!("a blueprint value applied whose result is no event, no dynamic, no bundle and no plain value (`{}`)", &crate::lower::functions::src_text_f(&lx_p3, &lx_p3.file_p, &e_p1.span_p)))));
                    this
                };
                (wx2_p9.clone(), crate::lower::node_::Wres::WrUnit)
            }
        } else {
            {
                let (name_pm, wx1_pn) = crate::lower::node_::fresh_name_f(wx_p0, &crate::prelude::Text::lit("generation"));
                let (up_id_po, wx2_pp) = if heard_p6 {
                    crate::lower::node_::add_gn_f(&wx1_pn, &crate::prelude::Text::from(format!("{}_fired", &name_pm)), &out_ty_p5, &crate::lower::node_::GnKind::GnNamed, &crate::prelude::Nat::from(0u32))
                } else {
                    (crate::prelude::Nat::from(0u32), wx1_pn.clone())
                };
                let hosted_in_pa = if crate::lower::node_::switch_::is_hosted_scope_f(wx_p0) {
                    crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Some")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCast(::std::rc::Rc::new(crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::node_::finish::host_field_ex_f(wx_p0, &pos_p4)))), crate::lower::types::host_of_ty_p())]))
                } else {
                    crate::lower::model::Ex::XNone
                };
                let at_pb = crate::prelude::Array::from(vec![blueprint_p2.clone(), applied_path_f(wx_p0, &pos_p4), crate::lower::model::Ex::XVar(crate::prelude::Text::lit("row_base")), hosted_in_pa.clone()]);
                let taker_pc = crate::lower::model::Ex::XClosure(false, crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("answer"))]), ::std::rc::Rc::new(crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Ok")), crate::prelude::Array::from(vec![first_answer_taken_f(&lx_p3, &out_ty_p5, &crate::prelude::Text::lit("answer"))]))));
                let applied_pd = if heard_p6 {
                    crate::lower::expr::try_of_f(&crate::lower::model::Ex::XCall(crate::lower::helper_ref_f(&crate::prelude::Text::lit("apply_blueprint_heard")), crate::prelude::append(&at_pb, &crate::prelude::Array::from(vec![answer_above_f(&name_pm), answer_sink_f(&lx_p3, &name_pm, &out_ty_p5), crate::lower::model::Ex::XCx]))))
                } else {
                    if dynamic_p8 {
                        crate::lower::expr::try_of_f(&crate::lower::model::Ex::XCall(crate::lower::helper_ref_f(&crate::prelude::Text::lit("apply_blueprint_dynamic")), crate::prelude::append(&at_pb, &crate::prelude::Array::from(vec![taker_pc.clone(), crate::lower::model::Ex::XCx]))))
                    } else {
                        if answered_p7 {
                            crate::lower::expr::try_of_f(&crate::lower::model::Ex::XCall(crate::lower::helper_ref_f(&crate::prelude::Text::lit("apply_blueprint_answered")), crate::prelude::push(&at_pb, &crate::lower::model::Ex::XCx)))
                        } else {
                            crate::lower::expr::try_of_f(&crate::lower::model::Ex::XCall(crate::lower::helper_ref_f(&crate::prelude::Text::lit("apply_blueprint")), crate::prelude::push(&at_pb, &crate::lower::model::Ex::XCx)))
                        }
                    }
                };
                let gap_pe = crate::lower::model::Ex::XBin(crate::lower::model::BinOp::OpSub, ::std::rc::Rc::new(crate::lower::model::Ex::XIndex(crate::lower::node_::switch_::wide_generation_p())), ::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("built"))));
                let hearer_pf = if heard_p6 {
                    crate::prelude::Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("heard_by")), crate::lower::model::Ex::XWeak(::std::rc::Rc::new(crate::lower::model::Ex::XSelf)))])
                } else {
                    crate::prelude::Array::new()
                };
                let res_pg = crate::prelude::Text::from(format!("{}_res", &name_pm));
                let follow_ph = crate::prelude::Text::from(format!("{}_follow", &name_pm));
                let made_pi = if answered_p7 {
                    crate::lower::model::Pa::PaTuple(crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("row")), crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("built")), crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("answered"))]))
                } else {
                    if dynamic_p8 {
                        crate::lower::model::Pa::PaTuple(crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("row")), crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("built")), crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("given"))]))
                    } else {
                        crate::lower::model::Pa::PaTuple(crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("row")), crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("built"))]))
                    }
                };
                let keeps_pj = if dynamic_p8 {
                    crate::prelude::Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), follow_ph.clone())), crate::prelude::Text::lit("follow"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("given"))), crate::prelude::Text::lit("updates")))), crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XSelf)))), crate::lower::model::Ex::XPath(crate::lower::model::ref_child_f(&crate::lower::site_ref_f(&lx_p3, &wx_p0.node_p), &crate::prelude::Text::from(format!("{}_result_moved", &name_pm))))]))), crate::lower::model::Do::DoAssign(crate::lower::model::Ex::XDeref(::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), res_pg.clone())), crate::prelude::Text::lit("borrow_mut"), crate::prelude::Array::new()))), crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Some")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XVar(crate::prelude::Text::lit("given"))])))])
                } else {
                    if answered_p7 {
                        crate::prelude::Array::from(vec![crate::lower::model::Do::DoAssign(crate::lower::model::Ex::XDeref(::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), res_pg.clone())), crate::prelude::Text::lit("borrow_mut"), crate::prelude::Array::new()))), crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Some")), crate::prelude::Array::from(vec![first_answer_taken_f(&lx_p3, &out_ty_p5, &crate::prelude::Text::lit("answered"))])))])
                    } else {
                        crate::prelude::Array::new()
                    }
                };
                let select_pk = crate::lower::node_::switch_::with_row_base_f(wx_p0, &crate::prelude::Text::lit("self"), &pos_p4, &crate::lower::model::Ex::XBlock(crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&hearer_pf, &crate::prelude::Array::from(vec![crate::lower::model::Do::DoLet(made_pi.clone(), applied_pd.clone())])), &keeps_pj), &crate::lower::node_::switch_::gap_set_f(&name_pm, &::std::option::Option::Some(gap_pe.clone()))), ::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("row")))));
                let wx3_pl = {
                    let mut this: crate::lower::node_::Wx = wx2_pp.clone();
                    this.pos_p = crate::lower::model::Pos { scope_p: pos_p4.scope_p.clone(), at_p: &pos_p4.at_p + &crate::lower::node_::switch_::wide_generation_p() };
                    this.gens_p = crate::prelude::push(&this.gens_p, &crate::lower::model::GenDef { name_p: name_pm.clone(), pos_p: pos_p4.clone(), at_p: crate::lower::node_::finish::place_at_f(wx_p0, &crate::prelude::Text::lit("self"), &pos_p4), source_p: crate::lower::model::Ex::XUnit, value_ty_p: crate::lower::model::OutTy::OutUnit, select_p: select_pk.clone(), transparent_p: true, width_p: crate::lower::node_::switch_::wide_generation_p(), moved_p: crate::prelude::or(&crate::lower::node_::finish::hosted_rows_o(wx_p0), &crate::prelude::Text::lit("")), early_p: false, gappy_p: true, rebased_p: true });
                    this.gen_holds_p = crate::prelude::push(&this.gen_holds_p, &(name_pm.clone(), crate::prelude::Array::new()));
                    this.fallible_p = true;
                    this.getters_p = if heard_p6 {
                        crate::prelude::push(&crate::prelude::push(&this.getters_p, &crate::lower::node_::switch_::gen_up_f(&name_pm, &crate::lower::node_::gn_of_f(&wx2_pp, &up_id_po).name_p, &crate::lower::node_::gn_of_f(&wx2_pp, &up_id_po).ty_p)), &crate::lower::node_::switch_::gen_up_above_f(&name_pm, &crate::lower::node_::gn_of_f(&wx2_pp, &up_id_po).name_p))
                    } else {
                        this.getters_p.clone()
                    };
                    this
                };
                if heard_p6 {
                    (wx3_pl.clone(), crate::lower::node_::Wres::WrEv(crate::lower::node_::ev_ref_of_f(&wx3_pl, &up_id_po)))
                } else {
                    if dynamic_p8 {
                        {
                            let wx4_pq = {
                                let mut this: crate::lower::node_::Wx = wx3_pl.clone();
                                this.taken_p = crate::prelude::push(&this.taken_p, &follow_ph);
                                this.fields_p = crate::prelude::push(&this.fields_p, &(follow_ph.clone(), crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("prism_rtl::Follow")), crate::prelude::Array::new()), crate::prelude::Text::lit("the subscription to the update event of the dynamic the blueprint value gives")));
                                this.moves_p = crate::prelude::push(&this.moves_p, &(follow_ph.clone(), crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("prism_rtl::Follow::new")), crate::prelude::Array::new())));
                                this
                            };
                            crate::lower::node_::switch_::kept_dyn_f(&wx4_pq, &name_pm, &out_ty_p5, &crate::prelude::Array::new())
                        }
                    } else {
                        if answered_p7 {
                            {
                                let read_pr = crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), res_pg.clone())), crate::prelude::Text::lit("borrow"), crate::prelude::Array::new())), crate::prelude::Text::lit("as_ref"), crate::prelude::Array::new())), crate::prelude::Text::lit("expect"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XStr(crate::prelude::Text::lit("a blueprint value applied before what reads its result"))]))));
                                let wx4_ps = {
                                    let mut this: crate::lower::node_::Wx = wx3_pl.clone();
                                    this.taken_p = crate::prelude::push(&this.taken_p, &res_pg);
                                    this.fields_p = crate::prelude::push(&this.fields_p, &(res_pg.clone(), crate::lower::model::OutTy::OutCell(::std::rc::Rc::new(crate::lower::model::OutTy::OutOpt(::std::rc::Rc::new(out_ty_p5.clone())))), crate::prelude::Text::lit("the plain result of the blueprint value applied, kept from its build on")));
                                    this.inits_p = crate::prelude::push(&this.inits_p, &(res_pg.clone(), crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::RefCell::new")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XNone]))));
                                    this
                                };
                                (wx4_ps.clone(), crate::lower::node_::Wres::WrLate(read_pr.clone(), out_ty_p5.clone()))
                            }
                        } else {
                            (wx3_pl.clone(), crate::lower::node_::Wres::WrUnit)
                        }
                    }
                }
            }
        }
    }
}

/// ```prism
/// AnswerAbove: fn Text -> Ex
/// ```
pub fn answer_above_f(name_p0: &crate::prelude::Text) -> crate::lower::model::Ex {
    let up_p1 = crate::lower::model::Do::DoIfLet(crate::lower::model::Pa::PaCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Some")), crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("block"))])), crate::lower::model::Ex::XUpgrade(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("heard_by")))), crate::prelude::Array::from(vec![crate::lower::node_::finish::above_call_f(&crate::lower::model::Ex::XVar(crate::prelude::Text::lit("block")), &crate::prelude::Text::from(format!("{}_up", name_p0)), &crate::lower::model::Ex::XVar(crate::prelude::Text::lit("h")))]), crate::prelude::Array::new());
    crate::lower::model::Ex::XBlock(crate::prelude::Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("heard_by")), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("heard_by")))))]), ::std::rc::Rc::new(crate::lower::model::Ex::XClosure(true, crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("h"))]), ::std::rc::Rc::new(crate::lower::model::Ex::XBlock(crate::prelude::Array::from(vec![up_p1.clone()]), ::std::rc::Rc::new(crate::lower::model::Ex::XUnit))))))
}

/// ```prism
/// AnswerSink: unbounded fn Lx, Text, OutTy -> Ex
/// ```
pub fn answer_sink_f(lx_p0: &crate::lower::Lx, name_p1: &crate::prelude::Text, t_p2: &crate::lower::model::OutTy) -> crate::lower::model::Ex {
    let fired_p3 = first_answer_taken_f(lx_p0, t_p2, &crate::prelude::Text::lit("answer"));
    let up_p4 = crate::lower::model::Do::DoIfLet(crate::lower::model::Pa::PaCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Some")), crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("block"))])), crate::lower::model::Ex::XUpgrade(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("heard_by")))), crate::prelude::Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("block"))), crate::prelude::Text::from(format!("{}_up", name_p1)), crate::prelude::Array::from(vec![crate::lower::model::Ex::XVar(crate::prelude::Text::lit("fired")), crate::lower::model::Ex::XCx])))]), crate::prelude::Array::new());
    crate::lower::model::Ex::XClosure(true, crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("answer")), crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("cx"))]), ::std::rc::Rc::new(crate::lower::model::Ex::XBlock(crate::prelude::Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("fired")), fired_p3.clone()), up_p4.clone()]), ::std::rc::Rc::new(crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Ok")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XUnit]))))))
}

/// ```prism
/// ?AnswerByTag: unbounded fn Lx, OutTy, Text -> ?Ex
/// ```
pub fn answer_by_tag_o(lx_p0: &crate::lower::Lx, t_p1: &crate::lower::model::OutTy, answer_p2: &crate::prelude::Text) -> ::std::option::Option<crate::lower::model::Ex> {
    let tags_p4 = crate::prelude::run_to_end(crate::prelude::filter_job(crate::prelude::values(&lx_p0.g_p.tags_p), {
        let lx_p0x = lx_p0.clone();
        let t_p1x = t_p1.clone();
        ::std::rc::Rc::new(move |p0: crate::check::env::TagInfo| {
            let lx_p0xy = lx_p0x.clone();
            let t_p1xy = t_p1x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let tg_p3 = p0;
                if &tg_p3.kind_p == &crate::prelude::Text::lit("Element") {
                    if crate::lower::program::answer_open_f(&lx_p0xy, &tg_p3) {
                        ::prism_rtl::Turn::Finished(true)
                    } else {
                        crate::prelude::call_then(crate::lower::program::start_answer_ty_f(lx_p0xy.clone(), tg_p3.clone()), move |answer_ty_f_23254: crate::lower::model::OutTy| ::prism_rtl::Turn::Finished(&answer_ty_f_23254 == &t_p1xy))
                    }
                } else {
                    ::prism_rtl::Turn::Finished(false)
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::env::TagInfo) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
    }));
    let taken_f6 = {
        let lx_p0x = lx_p0.clone();
        let t_p1x = t_p1.clone();
        let answer_p2x = answer_p2.clone();
        ::std::rc::Rc::new(move |p0: crate::check::env::TagInfo| {
            let lx_p0xy = lx_p0x.clone();
            let t_p1xy = t_p1x.clone();
            let answer_p2xy = answer_p2x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let tg_p5 = p0;
                crate::prelude::call_then(crate::lower::program::start_answer_ty_f(lx_p0xy.clone(), tg_p5.clone()), move |answer_ty_f_23335: crate::lower::model::OutTy| ::prism_rtl::Turn::Finished(crate::lower::program::recoded_answer_f(&crate::lower::program::answer_open_f(&lx_p0xy, &tg_p5), &answer_ty_f_23335, &t_p1xy, &crate::lower::expr::try_of_f(&crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XVar(answer_p2xy.clone())), crate::lower::node_::elements::answer_accessor_f(&tg_p5), crate::prelude::Array::new())))))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::env::TagInfo) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>>>
    };
    match crate::prelude::index(&tags_p4, &crate::prelude::Nat::from(0u32)) {
        ::std::option::Option::Some(first_p7) => ::std::option::Option::Some(crate::prelude::run_to_end(crate::prelude::fold_job(crate::prelude::drop(&tags_p4, &crate::prelude::Nat::from(1u32)), crate::prelude::run_to_end((&taken_f6)(first_p7.clone())), {
            let answer_p2x = answer_p2.clone();
            let taken_f6x = taken_f6.clone();
            ::std::rc::Rc::new(move |(p0, p1): (crate::lower::model::Ex, crate::check::env::TagInfo)| {
                let answer_p2xy = answer_p2x.clone();
                let taken_f6xy = taken_f6x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let rest_p8 = p0;
                    let tg_p9 = p1;
                    crate::prelude::call_value((&taken_f6xy)(tg_p9.clone()), move |taken_23554: crate::lower::model::Ex| ::prism_rtl::Turn::Finished(crate::lower::model::Ex::XIf(::std::rc::Rc::new(crate::lower::model::Ex::XIsCase(::std::rc::Rc::new(crate::lower::model::Ex::XVar(answer_p2xy.clone())), crate::prelude::Array::from(vec![crate::lower::node_::elements::answer_variant_f(&tg_p9)]))), ::std::rc::Rc::new(taken_23554), ::std::rc::Rc::new(rest_p8.clone()))))
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::model::Ex, crate::check::env::TagInfo)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>>>
        }))),
        ::std::option::Option::None => ::std::option::Option::None,
    }
}

/// ```prism
/// FirstAnswerTaken: unbounded fn Lx, OutTy, Text -> Ex
/// ```
pub fn first_answer_taken_f(lx_p0: &crate::lower::Lx, t_p1: &crate::lower::model::OutTy, answer_p2: &crate::prelude::Text) -> crate::lower::model::Ex {
    if !crate::lower::types::podable_f(t_p1) {
        crate::lower::expr::try_of_f(&crate::lower::model::Ex::XCallAt(crate::lower::helper_ref_f(&crate::prelude::Text::lit("held_answer")), crate::prelude::Array::from(vec![t_p1.clone()]), crate::prelude::Array::from(vec![crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XVar(answer_p2.clone())))])))
    } else {
        match answer_by_tag_o(lx_p0, t_p1, answer_p2) {
            ::std::option::Option::Some(taken_p3) => taken_p3,
            ::std::option::Option::None => crate::lower::expr::try_of_f(&crate::lower::model::Ex::XCallAt(crate::lower::helper_ref_f(&crate::prelude::Text::lit("answer_plain")), crate::prelude::Array::from(vec![t_p1.clone()]), crate::prelude::Array::from(vec![crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XVar(answer_p2.clone())))]))),
        }
    }
}

/// ```prism
/// AppliedBundleLine: unbounded fn Wx, Expr, Ex -> ((Wx, Wres))
/// ```
pub fn applied_bundle_line_f(wx_p0: &crate::lower::node_::Wx, e_p1: &crate::syntax::Expr, blueprint_p2: &crate::lower::model::Ex) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    let lx_p3 = wx_p0.lx_p.clone();
    let pos_p4 = wx_p0.pos_p.clone();
    let full_p5 = crate::lower::node_::def::line_out_full_f(&lx_p3, e_p1);
    let whole_ty_p6 = crate::lower::types::out_ty_of_f(&lx_p3, &full_p5);
    let (name_ph, wx1_pi) = crate::lower::node_::fresh_name_f(wx_p0, &crate::prelude::Text::lit("generation"));
    let kept_p7 = crate::prelude::Text::from(format!("{}_whole", &name_ph));
    let read_p8 = crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), kept_p7.clone())), crate::prelude::Text::lit("borrow"), crate::prelude::Array::new())), crate::prelude::Text::lit("as_ref"), crate::prelude::Array::new())), crate::prelude::Text::lit("expect"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XStr(crate::prelude::Text::lit("a blueprint value applied before what reads its result"))]));
    let (wx2_pj, res_pk, wiring_pl) = applied_part_f(&wx1_pi, &name_ph, &full_p5, &read_p8, &crate::lower::model::Ex::XVar(crate::prelude::Text::lit("whole")), &crate::prelude::Text::lit(""));
    let hosted_in_p9 = if crate::lower::node_::switch_::is_hosted_scope_f(wx_p0) {
        crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Some")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCast(::std::rc::Rc::new(crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::node_::finish::host_field_ex_f(wx_p0, &pos_p4)))), crate::lower::types::host_of_ty_p())]))
    } else {
        crate::lower::model::Ex::XNone
    };
    let tags_pa = bundle_tags_of_f(&lx_p3, &full_p5);
    let (state_ty_pm, events_ty_pn) = bundle_carried_f(&lx_p3, &full_p5);
    let applied_pb = crate::lower::expr::try_of_f(&crate::lower::model::Ex::XCallAt(crate::lower::helper_ref_f(&crate::prelude::Text::lit("apply_blueprint_whole")), crate::prelude::Array::from(vec![whole_ty_p6.clone(), state_ty_pm.clone(), events_ty_pn.clone()]), crate::prelude::Array::from(vec![blueprint_p2.clone(), applied_path_f(wx_p0, &pos_p4), crate::lower::model::Ex::XVar(crate::prelude::Text::lit("row_base")), hosted_in_p9.clone(), bundle_state_taker_f(&lx_p3, &tags_pa, &state_ty_pm), bundle_event_taker_f(&lx_p3, &tags_pa, &events_ty_pn), bundle_assembled_f(&full_p5, &tags_pa), crate::lower::model::Ex::XCx])));
    let gap_pc = crate::lower::model::Ex::XBin(crate::lower::model::BinOp::OpSub, ::std::rc::Rc::new(crate::lower::model::Ex::XIndex(crate::lower::node_::switch_::wide_generation_p())), ::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("built"))));
    let keeps_pd = crate::lower::model::Do::DoAssign(crate::lower::model::Ex::XDeref(::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), kept_p7.clone())), crate::prelude::Text::lit("borrow_mut"), crate::prelude::Array::new()))), crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Some")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XVar(crate::prelude::Text::lit("whole"))])));
    let made_pe = crate::lower::model::Pa::PaTuple(crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("row")), crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("built")), crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("whole"))]));
    let select_pf = crate::lower::node_::switch_::with_row_base_f(wx_p0, &crate::prelude::Text::lit("self"), &pos_p4, &crate::lower::model::Ex::XBlock(crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&crate::prelude::Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("heard_by")), crate::lower::model::Ex::XWeak(::std::rc::Rc::new(crate::lower::model::Ex::XSelf))), crate::lower::model::Do::DoLet(made_pe.clone(), applied_pb.clone())]), &wiring_pl), &crate::prelude::Array::from(vec![keeps_pd.clone()])), &crate::lower::node_::switch_::gap_set_f(&name_ph, &::std::option::Option::Some(gap_pc.clone()))), ::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("row")))));
    let wx3_pg = {
        let mut this: crate::lower::node_::Wx = wx2_pj.clone();
        this.pos_p = crate::lower::model::Pos { scope_p: pos_p4.scope_p.clone(), at_p: &pos_p4.at_p + &crate::lower::node_::switch_::wide_generation_p() };
        this.gens_p = crate::prelude::push(&this.gens_p, &crate::lower::model::GenDef { name_p: name_ph.clone(), pos_p: pos_p4.clone(), at_p: crate::lower::node_::finish::place_at_f(wx_p0, &crate::prelude::Text::lit("self"), &pos_p4), source_p: crate::lower::model::Ex::XUnit, value_ty_p: crate::lower::model::OutTy::OutUnit, select_p: select_pf.clone(), transparent_p: true, width_p: crate::lower::node_::switch_::wide_generation_p(), moved_p: crate::prelude::or(&crate::lower::node_::finish::hosted_rows_o(wx_p0), &crate::prelude::Text::lit("")), early_p: false, gappy_p: true, rebased_p: true });
        this.gen_holds_p = crate::prelude::push(&this.gen_holds_p, &(name_ph.clone(), crate::prelude::Array::new()));
        this.fallible_p = true;
        this.taken_p = crate::prelude::push(&this.taken_p, &kept_p7);
        this.fields_p = crate::prelude::push(&this.fields_p, &(kept_p7.clone(), crate::lower::model::OutTy::OutCell(::std::rc::Rc::new(crate::lower::model::OutTy::OutOpt(::std::rc::Rc::new(whole_ty_p6.clone())))), crate::prelude::Text::lit("the bundle the blueprint value applied gives, its events and dynamics whole, kept from its build on")));
        this.inits_p = crate::prelude::push(&this.inits_p, &(kept_p7.clone(), crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::RefCell::new")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XNone]))));
        this
    };
    (wx3_pg.clone(), res_pk.clone())
}

/// ```prism
/// AppliedPart: unbounded fn Wx, Text, Ty, Ex, Ex, Text -> ((Wx, Wres, [Do]))
/// ```
pub fn applied_part_f(wx_p0: &crate::lower::node_::Wx, name_p1: &crate::prelude::Text, t_p2: &crate::check::types::Ty, read_p3: &crate::lower::model::Ex, whole_p4: &crate::lower::model::Ex, place_p5: &crate::prelude::Text) -> (crate::lower::node_::Wx, crate::lower::node_::Wres, crate::prelude::Array<crate::lower::model::Do>) {
    match t_p2 {
        crate::check::types::Ty::TyTuple(ts_p6) if crate::lower::types::is_bundle_f(t_p2) => {
            let (w_pe, parts_pf, wiring_pg) = crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(ts_p6)), (wx_p0.clone(), crate::prelude::Array::new(), crate::prelude::Array::new()), {
                let name_p1x = name_p1.clone();
                let ts_p6x = ts_p6.clone();
                let read_p3x = read_p3.clone();
                let whole_p4x = whole_p4.clone();
                let place_p5x = place_p5.clone();
                ::std::rc::Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::prelude::Array<crate::lower::node_::Wres>, crate::prelude::Array<crate::lower::model::Do>), crate::prelude::Nat)| {
                    let name_p1xy = name_p1x.clone();
                    let ts_p6xy = ts_p6x.clone();
                    let read_p3xy = read_p3x.clone();
                    let whole_p4xy = whole_p4x.clone();
                    let place_p5xy = place_p5x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let (w0_p7, ps_p8, ds_p9) = p0;
                        let i_pa = p1;
                        {
                            let (w2_pb, part_pc, more_pd) = applied_part_f(&w0_p7, &name_p1xy, &crate::prelude::or(&crate::prelude::index(&ts_p6xy, &i_pa), &crate::check::types::Ty::TyErr), &crate::lower::model::Ex::XPart(::std::rc::Rc::new(read_p3xy.clone()), i_pa.clone()), &crate::lower::model::Ex::XPart(::std::rc::Rc::new(whole_p4xy.clone()), i_pa.clone()), &crate::prelude::Text::from(format!("{}_{}", &place_p5xy, &i_pa)));
                            ::prism_rtl::Turn::Finished((w2_pb.clone(), crate::prelude::push(&ps_p8, &part_pc), crate::prelude::append(&ds_p9, &more_pd)))
                        }
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::lower::node_::Wx, crate::prelude::Array<crate::lower::node_::Wres>, crate::prelude::Array<crate::lower::model::Do>), crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::prelude::Array<crate::lower::node_::Wres>, crate::prelude::Array<crate::lower::model::Do>)>>>
            }));
            (w_pe.clone(), crate::lower::node_::Wres::WrParts(parts_pf.clone()), wiring_pg.clone())
        },
        _ => {
            let lx_ph = wx_p0.lx_p.clone();
            let part_pi = crate::prelude::Text::from(format!("{}_part{}", name_p1, place_p5));
            match crate::lower::types::layer_of_f(t_p2) {
                crate::lower::types::Layer::LyEv => {
                    let et_pj = crate::lower::types::out_ty_of_f(&lx_ph, &crate::lower::types::peel_f(t_p2));
                    let (up_id_po, w1_pp) = crate::lower::node_::add_gn_f(wx_p0, &crate::prelude::Text::from(format!("{}_fired", &part_pi)), &et_pj, &crate::lower::node_::GnKind::GnNamed, &crate::prelude::Nat::from(0u32));
                    let w2_pk = {
                        let mut this: crate::lower::node_::Wx = w1_pp.clone();
                        this.getters_p = crate::prelude::push(&crate::prelude::push(&this.getters_p, &crate::lower::node_::switch_::gen_up_f(&part_pi, &crate::lower::node_::gn_of_f(&w1_pp, &up_id_po).name_p, &crate::lower::node_::gn_of_f(&w1_pp, &up_id_po).ty_p)), &crate::lower::node_::switch_::gen_up_above_f(&part_pi, &crate::lower::node_::gn_of_f(&w1_pp, &up_id_po).name_p));
                        this
                    };
                    let up_pl = crate::lower::model::Do::DoIfLet(crate::lower::model::Pa::PaCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Some")), crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("block"))])), crate::lower::model::Ex::XUpgrade(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("heard_by")))), crate::prelude::Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("block"))), crate::prelude::Text::from(format!("{}_up", &part_pi)), crate::prelude::Array::from(vec![crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("fired")))), crate::lower::model::Ex::XCx])))]), crate::prelude::Array::new());
                    let hear_pm = crate::lower::model::Ex::XClosure(true, crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("fired")), crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("cx"))]), ::std::rc::Rc::new(crate::lower::model::Ex::XBlock(crate::prelude::Array::from(vec![up_pl.clone()]), ::std::rc::Rc::new(crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Ok")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XUnit]))))));
                    let heard_pn = crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XBlock(crate::prelude::Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("heard_by")), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("heard_by")))))]), ::std::rc::Rc::new(crate::lower::model::Ex::XCall(crate::lower::helper_ref_f(&crate::prelude::Text::lit("hear_part")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XRef(::std::rc::Rc::new(whole_p4.clone())), answer_above_f(&part_pi), hear_pm.clone()])))));
                    (w2_pk.clone(), crate::lower::node_::Wres::WrEv(crate::lower::node_::ev_ref_of_f(&w2_pk, &up_id_po)), crate::prelude::Array::from(vec![heard_pn.clone()]))
                },
                crate::lower::types::Layer::LyDyn => {
                    let dt_pq = crate::lower::types::out_ty_of_f(&lx_ph, &crate::lower::types::peel_f(t_p2));
                    let follow_pr = crate::prelude::Text::from(format!("{}_follow", &part_pi));
                    let w1_ps = {
                        let mut this: crate::lower::node_::Wx = wx_p0.clone();
                        this.taken_p = crate::prelude::push(&this.taken_p, &follow_pr);
                        this.fields_p = crate::prelude::push(&this.fields_p, &(follow_pr.clone(), crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("prism_rtl::Follow")), crate::prelude::Array::new()), crate::prelude::Text::lit("the subscription to the update event of a dynamic part of the bundle the blueprint value gives")));
                        this.moves_p = crate::prelude::push(&this.moves_p, &(follow_pr.clone(), crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("prism_rtl::Follow::new")), crate::prelude::Array::new())));
                        this
                    };
                    let (w2_pu, res_pv) = crate::lower::node_::switch_::kept_dyn_f(&w1_ps, &part_pi, &dt_pq, &crate::prelude::Array::new());
                    let wiring_pt = crate::prelude::Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), follow_pr.clone())), crate::prelude::Text::lit("follow"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(whole_p4.clone()), crate::prelude::Text::lit("updates")))), crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XSelf)))), crate::lower::model::Ex::XPath(crate::lower::model::ref_child_f(&crate::lower::site_ref_f(&lx_ph, &wx_p0.node_p), &crate::prelude::Text::from(format!("{}_result_moved", &part_pi))))]))), crate::lower::model::Do::DoAssign(crate::lower::model::Ex::XDeref(::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::from(format!("{}_res", &part_pi)))), crate::prelude::Text::lit("borrow_mut"), crate::prelude::Array::new()))), crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Some")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XClone(::std::rc::Rc::new(whole_p4.clone()))])))]);
                    (w2_pu.clone(), res_pv.clone(), wiring_pt.clone())
                },
                _ => (wx_p0.clone(), crate::lower::node_::Wres::WrLate(crate::lower::model::Ex::XClone(::std::rc::Rc::new(read_p3.clone())), crate::lower::types::out_ty_of_f(&lx_ph, t_p2)), crate::prelude::Array::new()),
            }
        },
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// BundleTagsOf: unbounded fn Lx, Ty -> [TagInfo]
/// ```
pub fn bundle_tags_of_f(lx_p0: &crate::lower::Lx, full_p1: &crate::check::types::Ty) -> crate::prelude::Array<crate::check::env::TagInfo> {
    let flat_p2 = crate::prelude::fold(&crate::lower::node_::keyed::bundle_part_tys_f(full_p1), &true, &(|ok_p4: &bool, x_p5: &crate::check::types::Ty| *ok_p4 && !crate::lower::types::is_bundle_f(x_p5)));
    let answers_f3 = {
        let lx_p0x = lx_p0.clone();
        let full_p1x = full_p1.clone();
        ::std::rc::Rc::new(move |p0: crate::check::env::TagInfo| {
            let lx_p0xy = lx_p0x.clone();
            let full_p1xy = full_p1x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let tg_p6 = p0;
                crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0xy.clone(), crate::lower::types::peel_f(&tg_p6.out_p)), move |out_ty_of_f_31350: crate::lower::model::OutTy| crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0xy.clone(), full_p1xy.clone()), move |out_ty_of_f_31381: crate::lower::model::OutTy| ::prism_rtl::Turn::Finished((&out_ty_of_f_31350 == &out_ty_of_f_31381) || (crate::lower::program::answer_open_f(&lx_p0xy, &tg_p6) && matches_open_f(&crate::lower::node_::keyed::bundle_part_tys_f(&crate::lower::types::peel_f(&tg_p6.out_p)), &crate::lower::node_::keyed::bundle_part_tys_f(&full_p1xy))))))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::env::TagInfo) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
    };
    if !flat_p2 {
        crate::prelude::Array::new()
    } else {
        crate::prelude::run_to_end(crate::prelude::filter_job(crate::prelude::values(&lx_p0.g_p.tags_p), {
            let answers_f3x = answers_f3.clone();
            ::std::rc::Rc::new(move |p0: crate::check::env::TagInfo| {
                let answers_f3xy = answers_f3x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let tg_p7 = p0;
                    if (&tg_p7.kind_p == &crate::prelude::Text::lit("Element")) && crate::lower::types::is_bundle_f(&crate::lower::types::peel_f(&tg_p7.out_p)) {
                        (&answers_f3xy)(tg_p7.clone()).cycle()
                    } else {
                        ::prism_rtl::Turn::Finished(false)
                    }
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::env::TagInfo) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
        }))
    }
}

/// ```prism
/// MatchesOpen: unbounded fn [Ty], [Ty] -> Bool
/// ```
pub fn matches_open_f(open_p0: &crate::prelude::Array<crate::check::types::Ty>, parts_p1: &crate::prelude::Array<crate::check::types::Ty>) -> bool {
    (&crate::prelude::len(open_p0) == &crate::prelude::len(parts_p1)) && match param_match_all_o(&crate::prelude::run_to_end(crate::prelude::each_job(open_p0.clone(), ::std::rc::Rc::new(|a0: crate::check::types::Ty| crate::prelude::entered(start_unrigid_f(a0))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::Ty>>>)), parts_p1, &crate::prelude::Map::new()) {
        ::std::option::Option::Some(_) => true,
        ::std::option::Option::None => false,
    }
}

/// ```prism
/// BundleCarried: unbounded fn Lx, Ty -> ((OutTy, OutTy))
/// ```
pub fn bundle_carried_f(lx_p0: &crate::lower::Lx, full_p1: &crate::check::types::Ty) -> (crate::lower::model::OutTy, crate::lower::model::OutTy) {
    let ts_p2 = crate::lower::node_::keyed::bundle_part_tys_f(full_p1);
    let state_p3 = crate::prelude::run_to_end(crate::prelude::each_job(crate::prelude::filter(&ts_p2, &(|x_p7: &crate::check::types::Ty| &crate::lower::types::layer_of_f(x_p7) != &crate::lower::types::Layer::LyEv)), {
        let lx_p0x = lx_p0.clone();
        ::std::rc::Rc::new(move |p0: crate::check::types::Ty| {
            let lx_p0xy = lx_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let x_p8 = p0;
                ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::lower::types::OutTyOf { lx_p0: lx_p0xy.clone(), t_p1: crate::lower::types::peel_f(&x_p8) }))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::OutTy>>>
    }));
    let events_p4 = crate::prelude::run_to_end(crate::prelude::each_job(crate::prelude::filter(&ts_p2, &(|x_p9: &crate::check::types::Ty| &crate::lower::types::layer_of_f(x_p9) == &crate::lower::types::Layer::LyEv)), {
        let lx_p0x = lx_p0.clone();
        ::std::rc::Rc::new(move |p0: crate::check::types::Ty| {
            let lx_p0xy = lx_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let x_pa = p0;
                ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::lower::types::OutTyOf { lx_p0: lx_p0xy.clone(), t_p1: crate::lower::types::peel_f(&x_pa) }))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::OutTy>>>
    }));
    let state_ty_p5 = 'm32473: {
        if let m32473_0 = &state_p3 && (m32473_0.len() == 0) {
            break 'm32473 crate::lower::model::OutTy::OutUnit;
        }
        if let m32473_1 = &state_p3 && (m32473_1.len() == 1) && let ::std::option::Option::Some(x_pb) = crate::prelude::index(m32473_1, &crate::prelude::Nat::from(0u32)) {
            break 'm32473 x_pb.clone();
        }
        crate::lower::model::OutTy::OutTuple(state_p3.clone())
    };
    let events_ty_p6 = 'm32578: {
        if let m32578_0 = &events_p4 && (m32578_0.len() == 0) {
            break 'm32578 crate::lower::model::OutTy::OutUnit;
        }
        if let m32578_1 = &events_p4 && (m32578_1.len() == 1) && let ::std::option::Option::Some(x_pc) = crate::prelude::index(m32578_1, &crate::prelude::Nat::from(0u32)) {
            break 'm32578 x_pc.clone();
        }
        crate::lower::model::OutTy::OutTuple(crate::prelude::each(&events_p4, &crate::lower::program::sparse_part_ty_f))
    };
    (state_ty_p5.clone(), events_ty_p6.clone())
}

/// ```prism
/// BundleStateTaker: unbounded fn Lx, [TagInfo], OutTy -> Ex
/// ```
pub fn bundle_state_taker_f(lx_p0: &crate::lower::Lx, tags_p1: &crate::prelude::Array<crate::check::env::TagInfo>, state_ty_p2: &crate::lower::model::OutTy) -> crate::lower::model::Ex {
    let has_state_p3 = state_ty_p2 != &crate::lower::model::OutTy::OutUnit;
    let variant_f4 = ::std::rc::Rc::new(move |tg_p8: &crate::check::env::TagInfo| if crate::lower::node_::elements::is_bundle_tag_f(tg_p8) {
        crate::lower::node_::elements::answer_first_variant_f(tg_p8)
    } else {
        crate::lower::node_::elements::answer_variant_f(tg_p8)
    }) as ::std::rc::Rc<dyn ::std::ops::Fn(&crate::check::env::TagInfo) -> crate::lower::model::Ref>;
    let accessor_f5 = ::std::rc::Rc::new(move |tg_p9: &crate::check::env::TagInfo| if crate::lower::node_::elements::is_bundle_tag_f(tg_p9) {
        crate::prelude::Text::from(format!("{}_first", &crate::lower::node_::elements::answer_accessor_f(tg_p9)))
    } else {
        crate::lower::node_::elements::answer_accessor_f(tg_p9)
    }) as ::std::rc::Rc<dyn ::std::ops::Fn(&crate::check::env::TagInfo) -> crate::prelude::Text>;
    let taken_f6 = {
        let lx_p0x = lx_p0.clone();
        let accessor_f5x = accessor_f5.clone();
        let state_ty_p2x = state_ty_p2.clone();
        ::std::rc::Rc::new(move |p0: crate::check::env::TagInfo| {
            let lx_p0xy = lx_p0x.clone();
            let accessor_f5xy = accessor_f5x.clone();
            let state_ty_p2xy = state_ty_p2x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let tg_pa = p0;
                crate::prelude::call_then(crate::lower::program::start_answer_taken_f(lx_p0xy.clone(), (&accessor_f5xy)(&tg_pa), state_ty_p2xy.clone(), crate::lower::expr::try_of_f(&crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("answer"))), (&accessor_f5xy)(&tg_pa), crate::prelude::Array::new()))), move |answer_taken_f_33503: crate::lower::model::Ex| ::prism_rtl::Turn::Finished(crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Some")), crate::prelude::Array::from(vec![answer_taken_f_33503]))))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::env::TagInfo) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>>>
    };
    let body_p7 = if !has_state_p3 {
        crate::lower::model::Ex::XNone
    } else {
        match crate::prelude::index(tags_p1, &crate::prelude::Nat::from(0u32)) {
            ::std::option::Option::Some(first_pb) => crate::prelude::run_to_end(crate::prelude::fold_job(tags_p1.clone(), crate::lower::model::Ex::XIf(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("first"))), ::std::rc::Rc::new(crate::prelude::run_to_end((&taken_f6)(first_pb.clone()))), ::std::rc::Rc::new(crate::lower::model::Ex::XNone)), {
                let variant_f4x = variant_f4.clone();
                let taken_f6x = taken_f6.clone();
                ::std::rc::Rc::new(move |(p0, p1): (crate::lower::model::Ex, crate::check::env::TagInfo)| {
                    let variant_f4xy = variant_f4x.clone();
                    let taken_f6xy = taken_f6x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let rest_pc = p0;
                        let tg_pd = p1;
                        crate::prelude::call_value((&taken_f6xy)(tg_pd.clone()), move |taken_33792: crate::lower::model::Ex| ::prism_rtl::Turn::Finished(crate::lower::model::Ex::XIf(::std::rc::Rc::new(crate::lower::model::Ex::XIsCase(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("answer"))), crate::prelude::Array::from(vec![(&variant_f4xy)(&tg_pd)]))), ::std::rc::Rc::new(taken_33792), ::std::rc::Rc::new(rest_pc.clone()))))
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::model::Ex, crate::check::env::TagInfo)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>>>
            })),
            ::std::option::Option::None => crate::lower::model::Ex::XNone,
        }
    };
    crate::lower::model::Ex::XClosure(false, crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("answer")), crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("first"))]), ::std::rc::Rc::new(crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Ok")), crate::prelude::Array::from(vec![body_p7.clone()]))))
}

/// ```prism
/// BundleEventTaker: unbounded fn Lx, [TagInfo], OutTy -> Ex
/// ```
pub fn bundle_event_taker_f(lx_p0: &crate::lower::Lx, tags_p1: &crate::prelude::Array<crate::check::env::TagInfo>, events_ty_p2: &crate::lower::model::OutTy) -> crate::lower::model::Ex {
    let has_events_p3 = events_ty_p2 != &crate::lower::model::OutTy::OutUnit;
    let taken_f4 = {
        let lx_p0x = lx_p0.clone();
        let events_ty_p2x = events_ty_p2.clone();
        ::std::rc::Rc::new(move |p0: crate::check::env::TagInfo| {
            let lx_p0xy = lx_p0x.clone();
            let events_ty_p2xy = events_ty_p2x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let tg_p6 = p0;
                ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::lower::program::AnswerTaken { lx_p0: lx_p0xy.clone(), accessor_p1: crate::lower::node_::elements::answer_accessor_f(&tg_p6), placed_p2: events_ty_p2xy.clone(), taken_p3: crate::lower::expr::try_of_f(&crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("answer"))), crate::lower::node_::elements::answer_accessor_f(&tg_p6), crate::prelude::Array::new())) }))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::env::TagInfo) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>>>
    };
    let body_p5 = match if has_events_p3 {
        crate::prelude::index(tags_p1, &crate::prelude::Nat::from(0u32))
    } else {
        ::std::option::Option::None
    } {
        ::std::option::Option::Some(first_p7) => crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Ok")), crate::prelude::Array::from(vec![crate::prelude::run_to_end(crate::prelude::fold_job(crate::prelude::drop(tags_p1, &crate::prelude::Nat::from(1u32)), crate::prelude::run_to_end((&taken_f4)(first_p7.clone())), {
            let taken_f4x = taken_f4.clone();
            ::std::rc::Rc::new(move |(p0, p1): (crate::lower::model::Ex, crate::check::env::TagInfo)| {
                let taken_f4xy = taken_f4x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let rest_p8 = p0;
                    let tg_p9 = p1;
                    crate::prelude::call_value((&taken_f4xy)(tg_p9.clone()), move |taken_34643: crate::lower::model::Ex| ::prism_rtl::Turn::Finished(crate::lower::model::Ex::XIf(::std::rc::Rc::new(crate::lower::model::Ex::XIsCase(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("answer"))), crate::prelude::Array::from(vec![crate::lower::node_::elements::answer_variant_f(&tg_p9)]))), ::std::rc::Rc::new(taken_34643), ::std::rc::Rc::new(rest_p8.clone()))))
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::model::Ex, crate::check::env::TagInfo)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>>>
        }))])),
        ::std::option::Option::None => crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Err")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Fault::answer")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XStr(crate::prelude::Text::lit("an answer to a blueprint value that gives a bundle, which no event part of the bundle is answered with"))]))])),
    };
    crate::lower::model::Ex::XClosure(false, crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("answer"))]), ::std::rc::Rc::new(body_p5.clone()))
}

/// ```prism
/// BundleAssembled: unbounded fn Ty, [TagInfo] -> Ex
/// ```
pub fn bundle_assembled_f(full_p0: &crate::check::types::Ty, tags_p1: &crate::prelude::Array<crate::check::env::TagInfo>) -> crate::lower::model::Ex {
    let ts_p2 = crate::lower::node_::keyed::bundle_part_tys_f(full_p0);
    let idx_p3 = crate::check::errors::range0_f(&crate::prelude::len(&ts_p2));
    let state_ix_p4 = crate::prelude::filter(&idx_p3, &(|i_pb: &crate::prelude::Nat| &crate::lower::types::layer_of_f(&crate::prelude::or(&crate::prelude::index(&ts_p2, i_pb), &crate::check::types::Ty::TyErr)) != &crate::lower::types::Layer::LyEv));
    let ev_ix_p5 = crate::prelude::filter(&idx_p3, &(|i_pc: &crate::prelude::Nat| &crate::lower::types::layer_of_f(&crate::prelude::or(&crate::prelude::index(&ts_p2, i_pc), &crate::check::types::Ty::TyErr)) == &crate::lower::types::Layer::LyEv));
    let place_among_f6 = ::std::rc::Rc::new(move |xs_pd: &crate::prelude::Array<crate::prelude::Nat>, i_pe: &crate::prelude::Nat| crate::prelude::fold(&crate::check::errors::range0_f(&crate::prelude::len(xs_pd)), &crate::prelude::Nat::from(0u32), &(|at_pf: &crate::prelude::Nat, k_pg: &crate::prelude::Nat| if &crate::prelude::or(&crate::prelude::index(xs_pd, k_pg), &crate::prelude::Nat::from(0u32)) == i_pe {
        k_pg.clone()
    } else {
        at_pf.clone()
    }))) as ::std::rc::Rc<dyn ::std::ops::Fn(&crate::prelude::Array<crate::prelude::Nat>, &crate::prelude::Nat) -> crate::prelude::Nat>;
    let parts_p7 = crate::prelude::each(&idx_p3, &(|i_ph: &crate::prelude::Nat| match crate::lower::types::layer_of_f(&crate::prelude::or(&crate::prelude::index(&ts_p2, i_ph), &crate::check::types::Ty::TyErr)) {
        crate::lower::types::Layer::LyEv => if &crate::prelude::len(&ev_ix_p5) == &crate::prelude::Nat::from(1u32) {
            crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("events"))))
        } else {
            crate::lower::model::Ex::XCall(crate::lower::helper_ref_f(&crate::prelude::Text::lit("event_part")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("events")))), crate::lower::model::Ex::XClosure(false, crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("fired"))]), ::std::rc::Rc::new(crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XPart(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("fired"))), (&place_among_f6)(&ev_ix_p5, i_ph))))))]))
        },
        crate::lower::types::Layer::LyDyn => if &crate::prelude::len(&state_ix_p4) == &crate::prelude::Nat::from(1u32) {
            crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("state"))))
        } else {
            crate::lower::model::Ex::XCall(crate::lower::helper_ref_f(&crate::prelude::Text::lit("state_part")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("state")))), crate::lower::model::Ex::XClosure(false, crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("held"))]), ::std::rc::Rc::new(crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XPart(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("held"))), (&place_among_f6)(&state_ix_p4, i_ph))))))]))
        },
        _ => if &crate::prelude::len(&state_ix_p4) == &crate::prelude::Nat::from(1u32) {
            crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("state"))), crate::prelude::Text::lit("sample"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx]))
        } else {
            crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XPart(::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("state"))), crate::prelude::Text::lit("sample"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx]))), (&place_among_f6)(&state_ix_p4, i_ph))))
        },
    }));
    let made_p8 = crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Ok")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XTuple(parts_p7.clone())]));
    let missing_p9 = crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Fault::answer")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XStr(crate::prelude::Text::lit("a blueprint value that gives a bundle answered no state at its build"))]));
    let body_pa = if &crate::prelude::len(tags_p1) == &crate::prelude::Nat::from(0u32) {
        crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Err")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Fault::answer")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XStr(crate::prelude::Text::lit("a blueprint value that gives a bundle answered with no bundle held whole, and no element tag of the program answers with one"))]))]))
    } else {
        if &crate::prelude::len(&state_ix_p4) == &crate::prelude::Nat::from(0u32) {
            made_p8.clone()
        } else {
            crate::lower::model::Ex::XBlock(crate::prelude::Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("state")), crate::lower::expr::try_of_f(&crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("state"))), crate::prelude::Text::lit("ok_or"), crate::prelude::Array::from(vec![missing_p9.clone()]))))]), ::std::rc::Rc::new(made_p8.clone()))
        }
    };
    crate::lower::model::Ex::XClosure(false, crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("state")), crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("events")), crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("cx"))]), ::std::rc::Rc::new(body_pa.clone()))
}

/// ```prism
/// LetBlueprintLine: unbounded fn Wx, Env, Env, Expr, Expr, ?Bn -> ((Wx, Wres))
/// ```
pub fn let_blueprint_line_f(wx_p0: &crate::lower::node_::Wx, benv_p1: &crate::lower::types::Env, menv_p2: &crate::lower::types::Env, x_p3: &crate::syntax::Expr, e_p4: &crate::syntax::Expr, bound_o5: &::std::option::Option<crate::lower::types::Bn>) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    let lx_p6 = wx_p0.lx_p.clone();
    let lxi_p7 = {
        let mut this: crate::lower::Lx = lx_p6.clone();
        this.inlined_p = match crate::prelude::get(&lx_p6.call_ids_p, &crate::lower::place_key_f(&lx_p6, &e_p4.span_p)) {
            ::std::option::Option::Some(id_pa) => crate::prelude::Text::from(format!("{}_{}", &lx_p6.inlined_p, &crate::lower::base32_f(&id_pa))),
            ::std::option::Option::None => crate::prelude::Text::from(format!("{}_at{}", &lx_p6.inlined_p, &crate::lower::base32_f(&e_p4.span_p.start_p))),
        };
        this
    };
    let inner_p8 = {
        let mut this: crate::lower::node_::Wx = wx_p0.clone();
        this.lx_p = lxi_p7.clone();
        this
    };
    let (done_pb, res_pc) = crate::lower::node_::def::build_line_f(&inner_p8, benv_p1, menv_p2, x_p3, bound_o5);
    let back_p9 = {
        let mut this: crate::lower::node_::Wx = done_pb.clone();
        this.lx_p = lx_p6.clone();
        this
    };
    (back_p9.clone(), res_pc.clone())
}

/// ```prism
/// LocalWidgetLine: unbounded fn Wx, Env, Env, Block, Expr -> ((Wx, Wres))
/// ```
pub fn local_widget_line_f(wx_p0: &crate::lower::node_::Wx, benv_p1: &crate::lower::types::Env, menv_p2: &crate::lower::types::Env, b_p3: &crate::syntax::Block, e_p4: &crate::syntax::Expr) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    let lx_p5 = wx_p0.lx_p.clone();
    let call_span_p6 = match &*e_p4.kind_p {
        crate::syntax::ExprKind::ECall(c_pa, _, _, _) => c_pa.span_p.clone(),
        _ => e_p4.span_p.clone(),
    };
    let lxi_p7 = {
        let mut this: crate::lower::Lx = lx_p5.clone();
        this.inlined_p = match crate::prelude::get(&lx_p5.call_ids_p, &crate::lower::place_key_f(&lx_p5, &call_span_p6)) {
            ::std::option::Option::Some(id_pb) => crate::prelude::Text::from(format!("{}_{}", &lx_p5.inlined_p, &crate::lower::base32_f(&id_pb))),
            ::std::option::Option::None => crate::prelude::Text::from(format!("{}_at{}", &lx_p5.inlined_p, &crate::lower::base32_f(&call_span_p6.start_p))),
        };
        this
    };
    let inner_p8 = {
        let mut this: crate::lower::node_::Wx = wx_p0.clone();
        this.lx_p = lxi_p7.clone();
        this
    };
    let (done_pc, res_pd) = inline_block_f(&inner_p8, benv_p1, menv_p2, b_p3, &lxi_p7);
    let back_p9 = {
        let mut this: crate::lower::node_::Wx = done_pc.clone();
        this.lx_p = lx_p5.clone();
        this
    };
    (back_p9.clone(), res_pd.clone())
}

/// ```prism
/// InlineBlock: unbounded fn Wx, Env, Env, Block, Lx -> ((Wx, Wres))
/// ```
pub fn inline_block_f(wx_p0: &crate::lower::node_::Wx, benv_p1: &crate::lower::types::Env, menv_p2: &crate::lower::types::Env, b_p3: &crate::syntax::Block, lx_p4: &crate::lower::Lx) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    let inner_p5 = {
        let mut this: crate::lower::node_::Wx = wx_p0.clone();
        this.result_p = crate::lower::node_::Wres::WrUnit;
        this
    };
    let done_p6 = crate::lower::node_::def::block_into_f(&inner_p5, benv_p1, menv_p2, b_p3);
    let back_p7 = {
        let mut this: crate::lower::node_::Wx = done_p6.clone();
        this.result_p = wx_p0.result_p.clone();
        this
    };
    (back_p7.clone(), done_p6.result_p.clone())
}

/// ```prism
/// WidgetCall: unbounded fn Wx, Env, Env, Expr, ?Bn, Text, [Arg], ?Nat -> ((Wx, Wres))
/// ```
pub fn widget_call_f(wx_p0: &crate::lower::node_::Wx, benv_p1: &crate::lower::types::Env, menv_p2: &crate::lower::types::Env, e_p3: &crate::syntax::Expr, bound_o4: &::std::option::Option<crate::lower::types::Bn>, qk_p5: &crate::prelude::Text, args_p6: &crate::prelude::Array<crate::syntax::Arg>, target_o7: &::std::option::Option<crate::prelude::Nat>) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    let lx_p8 = wx_p0.lx_p.clone();
    match qk_p5 {
        m39545_0 if (m39545_0 == &crate::prelude::Text::lit("Prelude.@started")) => started_line_f(wx_p0, bound_o4),
        m39545_1 if (m39545_1 == &crate::prelude::Text::lit("Prelude.@Switch")) => crate::lower::node_::switch_::switch_line_f(wx_p0, menv_p2, args_p6),
        m39545_2 if (m39545_2 == &crate::prelude::Text::lit("Prelude.@Flatten")) => crate::lower::node_::switch_::flatten_line_f(wx_p0, menv_p2, args_p6, bound_o4),
        m39545_3 if (m39545_3 == &crate::prelude::Text::lit("Prelude.@Defer")) => defer_line_f(wx_p0, menv_p2, args_p6, e_p3, target_o7),
        m39545_4 if (m39545_4 == &crate::prelude::Text::lit("Prelude.@Later")) => later_line_f(wx_p0, benv_p1, menv_p2, args_p6, e_p3, target_o7),
        m39545_5 if (m39545_5 == &crate::prelude::Text::lit("Prelude.@Distinct")) => distinct_line_f(wx_p0, menv_p2, args_p6, e_p3, bound_o4),
        m39545_6 if (m39545_6 == &crate::prelude::Text::lit("Prelude.@PerKey")) => per_key_line_f(wx_p0, menv_p2, args_p6, bound_o4),
        m39545_7 if (m39545_7 == &crate::prelude::Text::lit("Prelude.@Run")) => run_line_f(wx_p0, benv_p1, args_p6, e_p3, target_o7),
        m39545_8 if (m39545_8 == &crate::prelude::Text::lit("Prelude.@Machine")) => machine_line_f(wx_p0, benv_p1, menv_p2, args_p6, e_p3, target_o7),
        m39545_9 if (m39545_9 == &crate::prelude::Text::lit("Prelude.@HostDocument")) => host_line_f(wx_p0, benv_p1, menv_p2, &HostForm::HostEach, args_p6, bound_o4),
        m39545_10 if (m39545_10 == &crate::prelude::Text::lit("Prelude.@HostSome")) => host_line_f(wx_p0, benv_p1, menv_p2, &HostForm::HostSome, args_p6, bound_o4),
        m39545_11 if (m39545_11 == &crate::prelude::Text::lit("Prelude.@HostList")) => host_line_f(wx_p0, benv_p1, menv_p2, &HostForm::HostList, args_p6, bound_o4),
        m39545_12 if (m39545_12 == &crate::prelude::Text::lit("Prelude.@Element")) => element_call_line_f(wx_p0, benv_p1, menv_p2, args_p6, e_p3, bound_o4),
        _ => match crate::prelude::get(&lx_p8.g_p.vals_p, qk_p5) {
            ::std::option::Option::Some(v_p9) => inline_widget_f(wx_p0, benv_p1, menv_p2, qk_p5, &v_p9, args_p6, e_p3),
            ::std::option::Option::None => {
                let wx2_pa = {
                    let mut this: crate::lower::node_::Wx = wx_p0.clone();
                    this.build_p = crate::prelude::push(&this.build_p, &crate::lower::expr::refusal_do_f(&crate::prelude::Text::lit("a widget this back end does not lower yet")));
                    this
                };
                (wx2_pa.clone(), crate::lower::node_::Wres::WrUnit)
            },
        },
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// HostLine: unbounded fn Wx, Env, Env, HostForm, [Arg], ?Bn -> ((Wx, Wres))
/// ```
pub fn host_line_f(wx_p0: &crate::lower::node_::Wx, benv_p1: &crate::lower::types::Env, menv_p2: &crate::lower::types::Env, form_p3: &HostForm, args_p4: &crate::prelude::Array<crate::syntax::Arg>, bound_o5: &::std::option::Option<crate::lower::types::Bn>) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    let lx_p6 = wx_p0.lx_p.clone();
    let pos_p7 = wx_p0.pos_p.clone();
    let k_p8 = &crate::prelude::len(&wx_p0.scopes_p) + &crate::prelude::Nat::from(1u32);
    let hf_p9 = crate::prelude::Text::from(format!("host_{}", &k_p8));
    let rows_name_pa = crate::prelude::Text::from(format!("{}_rows", &hf_p9));
    let doc_getter_pb = crate::prelude::Text::from(format!("{}_doc", &hf_p9));
    let wx1_pc = {
        let mut this: crate::lower::node_::Wx = wx_p0.clone();
        this.taken_p = crate::prelude::append(&this.taken_p, &crate::prelude::Array::from(vec![hf_p9.clone(), rows_name_pa.clone(), doc_getter_pb.clone(), crate::prelude::Text::from(format!("{}_now", &doc_getter_pb)), crate::prelude::Text::from(format!("{}_snap", &doc_getter_pb)), crate::prelude::Text::from(format!("{}_direct", &doc_getter_pb)), crate::prelude::Text::from(format!("{}_publish", &doc_getter_pb)), crate::prelude::Text::from(format!("{}_answer", &hf_p9)), crate::prelude::Text::from(format!("{}_moved", &hf_p9))]));
        this
    };
    let sup_arg_od = if form_p3 == &HostForm::HostList {
        crate::prelude::index(args_p4, &crate::prelude::Nat::from(2u32))
    } else {
        crate::prelude::index(args_p4, &crate::prelude::Nat::from(1u32))
    };
    match (crate::prelude::index(args_p4, &crate::prelude::Nat::from(0u32)), sup_arg_od.clone()) {
        (::std::option::Option::Some(child_pe), ::std::option::Option::Some(sup_pf)) => {
            let (wxh_p13, benvh_p14, menvh_p15) = held_answer_readers_f(&wx1_pc, benv_p1, menv_p2, &k_p8, &sup_pf.value_p);
            let (wxd_p16, dyn_env_p17, dyn_lets_p18) = dynamic_answers_f(&wxh_p13, &benvh_p14, &menvh_p15, &hf_p9, &k_p8, &sup_pf.value_p);
            let offered_pg = crate::lower::types::own_f(&crate::lower::expr::value_of_f(&lx_p6, &dyn_env_p17, &sup_pf.value_p));
            let supplier0_ph = match form_p3 {
                HostForm::HostSome => crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("prism_rtl::forward_on_none")), crate::prelude::Array::from(vec![offered_pg.clone()])),
                _ => offered_pg.clone(),
            };
            let heard_pi = match (form_p3.clone(), crate::prelude::index(args_p4, &crate::prelude::Nat::from(1u32))) {
                (HostForm::HostList, ::std::option::Option::Some(answers_p19)) => crate::prelude::Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XVar(hf_p9.clone())), crate::prelude::Text::lit("hear"), crate::prelude::Array::from(vec![crate::lower::types::ref_f(&crate::lower::expr::value_of_f(&lx_p6, &dyn_env_p17, &answers_p19.value_p))])))]),
                _ => crate::prelude::Array::new(),
            };
            let supplier_pj = if &crate::prelude::len(&dyn_lets_p18) == &crate::prelude::Nat::from(0u32) {
                supplier0_ph.clone()
            } else {
                crate::lower::model::Ex::XBlock(dyn_lets_p18.clone(), ::std::rc::Rc::new(supplier0_ph.clone()))
            };
            let enclosing_pk = if crate::lower::node_::finish::emits_f(wx_p0, &pos_p7) {
                crate::lower::model::Ex::XNone
            } else {
                crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Some")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCast(::std::rc::Rc::new(crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::lower::node_::elements::host_local_f(wx_p0, &pos_p7))))), crate::lower::types::host_of_ty_p())]))
            };
            let unplaced_pl = crate::lower::node_::finish::place_unknown_at_build_f(wx_p0, &pos_p7);
            let made_pm = crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("prism_rtl::Host::new")), crate::prelude::Array::from(vec![if unplaced_pl {
                crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Path::root")), crate::prelude::Array::new())
            } else {
                crate::lower::node_::finish::place_at_f(wx_p0, &crate::prelude::Text::lit(""), &pos_p7)
            }, crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(rows_name_pa.clone()))), supplier_pj.clone(), enclosing_pk.clone(), crate::lower::model::Ex::XPath(crate::lower::model::ref_child_f(&crate::lower::site_ref_f(&lx_p6, &wx_p0.node_p), &crate::prelude::Text::from(format!("{}_answer", &hf_p9)))), crate::lower::model::Ex::XPath(crate::lower::model::ref_child_f(&crate::lower::site_ref_f(&lx_p6, &wx_p0.node_p), &crate::prelude::Text::from(format!("{}_moved", &hf_p9))))]));
            let host_ty_pn = crate::lower::model::OutTy::OutRc(::std::rc::Rc::new(crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("prism_rtl::Host")), crate::prelude::Array::from(vec![crate::lower::types::elem_ty_p(), crate::lower::types::answer_ty_p(), crate::lower::model::OutTy::OutNamed(crate::lower::site_ref_f(&lx_p6, &wx_p0.node_p), crate::prelude::Array::new())]))));
            let rows_ty_po = crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("prism_rtl::Rows")), crate::prelude::Array::from(vec![crate::lower::types::elem_ty_p(), crate::lower::types::answer_ty_p()]));
            let doc_ty_pp = crate::lower::model::OutTy::OutMap(::std::rc::Rc::new(crate::lower::model::OutTy::OutPath), ::std::rc::Rc::new(crate::lower::model::OutTy::OutDyn(::std::rc::Rc::new(crate::lower::types::elem_ty_p()))));
            let direct_ty_pq = crate::lower::model::OutTy::OutMap(::std::rc::Rc::new(crate::lower::model::OutTy::OutPath), ::std::rc::Rc::new(crate::lower::types::entry_ty_p()));
            let what_pr = crate::prelude::Text::from(format!("the document of the child hosted at place {}", &crate::lower::model::place_text_f(&pos_p7)));
            let wx2_ps = {
                let mut this: crate::lower::node_::Wx = wxd_p16.clone();
                this.pos_p = crate::lower::model::next_pos_f(&this.pos_p);
                this.lets_p = crate::prelude::append(&crate::prelude::append(&this.lets_p, &crate::prelude::Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaBind(rows_name_pa.clone())), rows_ty_po.clone()), crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Rc::new")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::RefCell::new")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Map::new")), crate::prelude::Array::new())]))]))), crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(hf_p9.clone()), made_pm.clone())])), &heard_pi);
                this.fields_p = crate::prelude::append(&this.fields_p, &crate::prelude::Array::from(vec![(hf_p9.clone(), host_ty_pn.clone(), crate::prelude::Text::from(format!("the host at place {}: its supplier, its rows, and the way back into its child (pick HO)", &crate::lower::model::place_text_f(&pos_p7)))), (rows_name_pa.clone(), rows_ty_po.clone(), crate::prelude::Text::from(format!("the rows of the host at place {}: `for p, e <- $doc`, one supplier blueprint per child place", &crate::lower::model::place_text_f(&pos_p7)))), (crate::prelude::Text::from(format!("{}_from", &rows_name_pa)), crate::lower::model::OutTy::OutCell(::std::rc::Rc::new(direct_ty_pq.clone())), crate::prelude::Text::from(format!("the places the rows of the host at place {} were last built from", &crate::lower::model::place_text_f(&pos_p7)))), (crate::prelude::Text::from(format!("{}_snap", &doc_getter_pb)), crate::lower::model::OutTy::OutSnapshot(::std::rc::Rc::new(crate::lower::types::host_doc_ty_p())), crate::prelude::Text::from(format!("`$doc` of the host at place {}, its outer, a structural dynamic: its snapshots, the places and the lagged dynamic (pick ST)", &crate::lower::model::place_text_f(&pos_p7))))]));
                this.moves_p = crate::prelude::append(&this.moves_p, &crate::prelude::Array::from(vec![(hf_p9.clone(), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(hf_p9.clone())))), (rows_name_pa.clone(), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(rows_name_pa.clone()))))]));
                this.inits_p = crate::prelude::append(&this.inits_p, &crate::prelude::Array::from(vec![(crate::prelude::Text::from(format!("{}_snap", &doc_getter_pb)), crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Snapshot::new")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XStr(what_pr.clone())]))), (crate::prelude::Text::from(format!("{}_from", &rows_name_pa)), crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::RefCell::new")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Map::new")), crate::prelude::Array::new())])))]));
                this.hosts_p = crate::prelude::push(&this.hosts_p, &crate::lower::node_::HostDef { pos_p: pos_p7.clone(), name_p: hf_p9.clone(), scope_p: k_p8.clone() });
                this.unplaced_hosts_p = if unplaced_pl {
                    crate::prelude::push(&this.unplaced_hosts_p, &hf_p9)
                } else {
                    this.unplaced_hosts_p.clone()
                };
                this.late_hosts_p = if unplaced_pl && !crate::check::types::has_nat_f(&this.late_hosts_p, &k_p8) {
                    crate::prelude::push(&this.late_hosts_p, &k_p8)
                } else {
                    this.late_hosts_p.clone()
                };
                this.snaps_p = crate::prelude::push(&this.snaps_p, &crate::lower::node_::SnapDef { name_p: doc_getter_pb.clone(), live_p: crate::prelude::Text::from(format!("{}_now", &doc_getter_pb)), ty_p: crate::lower::types::host_doc_ty_p(), eq_p: true, builder_p: rows_name_pa.clone(), before_p: true, what_p: what_pr.clone() });
                this.getters_p = crate::prelude::append(&this.getters_p, &crate::prelude::Array::from(vec![crate::lower::model::MethDef { name_p: doc_getter_pb.clone(), recv_p: crate::lower::model::Recv::RecvRef, params_p: crate::prelude::Array::new(), cx_p: crate::lower::model::CxArg::CxRef, ret_p: doc_ty_pp.clone(), body_p: crate::prelude::Array::new(), tail_p: crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::from(format!("{}_snap", &doc_getter_pb)))), crate::prelude::Text::lit("get"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx]))), crate::prelude::Text::lit("doc")), doc_p: crate::prelude::Text::from(format!("The document of the child hosted at place {}, `$doc`, its outer a structural dynamic (pick ST): one tick behind the child\'s places, the snapshot of the tick before the tick the read point is after; each entry the place\'s own dynamic.", &crate::lower::model::place_text_f(&pos_p7))) }, crate::lower::model::MethDef { name_p: crate::prelude::Text::from(format!("{}_direct", &doc_getter_pb)), recv_p: crate::lower::model::Recv::RecvRef, params_p: crate::prelude::Array::new(), cx_p: crate::lower::model::CxArg::CxRef, ret_p: direct_ty_pq.clone(), body_p: crate::prelude::Array::new(), tail_p: crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::from(format!("{}_snap", &doc_getter_pb)))), crate::prelude::Text::lit("current"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx]))), crate::prelude::Text::lit("places")), doc_p: crate::prelude::Text::from(format!("The places of the child hosted at place {}, not the lagged `$doc`: the snapshot taken in this tick\'s construction step, the places as the tick opened during propagation. The host\'s own `for` reads it, so a newborn child place gets its row in the tick it is born (pick ST).", &crate::lower::model::place_text_f(&pos_p7))) }]));
                this.scopes_p = crate::prelude::push(&this.scopes_p, &hf_p9);
                this.builders_p = crate::prelude::push(&this.builders_p, &crate::lower::model::ForDef { name_p: rows_name_pa.clone(), pos_p: pos_p7.clone(), at_p: crate::lower::node_::finish::place_at_f(wx_p0, &crate::prelude::Text::lit("self"), &pos_p7), key_ty_p: crate::lower::model::OutTy::OutPath, value_ty_p: crate::lower::types::entry_ty_p(), row_node_p: crate::prelude::Text::lit("prism_rtl::HostRow::<crate::Elem, crate::Answer>"), keyed_p: true, source_p: crate::prelude::Text::from(format!("{}_direct", &doc_getter_pb)), parent_p: crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), hf_p9.clone()))), passed_p: crate::prelude::Array::new(), moved_p: crate::prelude::or(&crate::lower::node_::finish::hosted_rows_o(wx_p0), &crate::prelude::Text::lit("")), replaced_p: crate::prelude::Array::new() });
                this.build_holds_p = crate::lower::node_::add_read_f(&this.build_holds_p, &crate::lower::node_::Read::OwnRead(crate::prelude::Text::from(format!("{}_now", &doc_getter_pb))));
                this.fallible_p = true;
                this
            };
            let inner_pt = {
                let mut this: crate::lower::node_::Wx = wx2_ps.clone();
                this.pos_p = crate::lower::model::scope_pos_f(&k_p8);
                this.result_p = crate::lower::node_::Wres::WrUnit;
                this
            };
            let (done_p1a, res_p1b) = crate::lower::node_::def::build_line_f(&inner_pt, benv_p1, menv_p2, &child_pe.value_p, &::std::option::Option::None);
            let child_places_pu = crate::prelude::drop(&done_p1a.places_p, &crate::prelude::len(&wx2_ps.places_p));
            let in_scope_fv = {
                let k_p8x = k_p8.clone();
                ::std::rc::Rc::new(move |p_p1c: &crate::lower::model::Pos| &p_p1c.scope_p == &k_p8x) as ::std::rc::Rc<dyn ::std::ops::Fn(&crate::lower::model::Pos) -> bool>
            };
            let getter_p10 = host_doc_getter_f(&done_p1a, &crate::prelude::Text::from(format!("{}_now", &doc_getter_pb)), &pos_p7, &crate::prelude::filter(&child_places_pu, &(|pl_p1d: &crate::lower::node_::Place| (&in_scope_fv)(&pl_p1d.pos_p))), &crate::prelude::filter(&crate::prelude::drop(&done_p1a.builders_p, &crate::prelude::len(&wx2_ps.builders_p)), &(|b_p1e: &crate::lower::model::ForDef| (&in_scope_fv)(&b_p1e.pos_p))), &crate::prelude::filter(&crate::prelude::drop(&done_p1a.gens_p, &crate::prelude::len(&wx2_ps.gens_p)), &(|gd_p1f: &crate::lower::model::GenDef| (&in_scope_fv)(&gd_p1f.pos_p))));
            let back_p11 = {
                let mut this: crate::lower::node_::Wx = done_p1a.clone();
                this.pos_p = wx2_ps.pos_p.clone();
                this.result_p = wx_p0.result_p.clone();
                this.getters_p = crate::prelude::push(&this.getters_p, &getter_p10);
                this.dyn_reads_p = crate::prelude::insert(&this.dyn_reads_p, &crate::prelude::Text::from(format!("{}_now", &doc_getter_pb)), &crate::prelude::Array::new());
                this
            };
            let doc_bn_p12 = crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), doc_getter_pb.clone(), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx])), crate::prelude::Array::from(vec![crate::lower::node_::Read::OwnRead(doc_getter_pb.clone())]), doc_ty_pp.clone());
            (back_p11.clone(), crate::lower::node_::Wres::WrHosted(::std::rc::Rc::new(res_p1b.clone()), doc_bn_p12.clone()))
        },
        _ => {
            let wx2_p1g = {
                let mut this: crate::lower::node_::Wx = wx1_pc.clone();
                this.pos_p = crate::lower::model::next_pos_f(&this.pos_p);
                this.build_p = crate::prelude::push(&this.build_p, &crate::lower::expr::refusal_do_f(&crate::prelude::Text::lit("a host without its child or its supplier")));
                this
            };
            (wx2_p1g.clone(), crate::lower::node_::Wres::WrHosted(::std::rc::Rc::new(crate::lower::node_::Wres::WrUnit), crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XUnit, crate::lower::types::Holding::Owned, crate::lower::model::OutTy::OutUnit)))
        },
    }
}

/// ```prism
/// DynamicAnswers: unbounded fn Wx, Env, Env, Text, Nat, Expr -> ((Wx, Env, [Do]))
/// ```
pub fn dynamic_answers_f(wx_p0: &crate::lower::node_::Wx, benv_p1: &crate::lower::types::Env, menv_p2: &crate::lower::types::Env, hf_p3: &crate::prelude::Text, k_p4: &crate::prelude::Nat, sup_p5: &crate::syntax::Expr) -> (crate::lower::node_::Wx, crate::lower::types::Env, crate::prelude::Array<crate::lower::model::Do>) {
    let lx_p6 = wx_p0.lx_p.clone();
    let texts_p7 = answer_texts_f(&lx_p6, benv_p1, menv_p2, &crate::check::typed::print::exprs_in_f(sup_p5), &crate::prelude::Nat::from(8u32));
    let binders_p8 = supplier_binders_f(&texts_p7);
    let dyns_p9 = crate::prelude::run_to_end(crate::prelude::fold_job(texts_p7.clone(), crate::prelude::Array::new(), {
        let binders_p8x = binders_p8.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<(crate::syntax::Expr, crate::syntax::Expr, crate::lower::types::Env, crate::lower::types::Env, crate::lower::Lx)>, (crate::syntax::Expr, crate::lower::types::Env, crate::lower::types::Env, crate::lower::Lx))| {
            let binders_p8xy = binders_p8x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_pa = p0;
                let (x_pb, be_pc, me_pd, lxd_pe) = p1;
                match &*x_pb.kind_p {
                    crate::syntax::ExprKind::EFreeSigil(m52617_0_0, y_pf) if (m52617_0_0 == &crate::prelude::Text::lit("@")) => crate::prelude::fold_job(answer_dynamics_f(&lxd_pe, &**y_pf), acc_pa.clone(), {
                        let me_pdx = me_pd.clone();
                        let binders_p8xyx = binders_p8xy.clone();
                        let be_pcx = be_pc.clone();
                        let lxd_pex = lxd_pe.clone();
                        ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<(crate::syntax::Expr, crate::syntax::Expr, crate::lower::types::Env, crate::lower::types::Env, crate::lower::Lx)>, (crate::syntax::Expr, crate::syntax::Expr))| {
                            let me_pdxy = me_pdx.clone();
                            let binders_p8xyxy = binders_p8xyx.clone();
                            let be_pcxy = be_pcx.clone();
                            let lxd_pexy = lxd_pex.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let acc2_pg = p0;
                                let (part_ph, d_pi) = p1;
                                if is_held_answer_f(&me_pdxy, &binders_p8xyxy, &d_pi) {
                                    ::prism_rtl::Turn::Finished(acc2_pg.clone())
                                } else {
                                    ::prism_rtl::Turn::Finished(crate::prelude::push(&acc2_pg, &(part_ph.clone(), d_pi.clone(), be_pcxy.clone(), me_pdxy.clone(), lxd_pexy.clone())))
                                }
                            }))
                        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<(crate::syntax::Expr, crate::syntax::Expr, crate::lower::types::Env, crate::lower::types::Env, crate::lower::Lx)>, (crate::syntax::Expr, crate::syntax::Expr))) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<(crate::syntax::Expr, crate::syntax::Expr, crate::lower::types::Env, crate::lower::types::Env, crate::lower::Lx)>>>>
                    }).cycle(),
                    _ => ::prism_rtl::Turn::Finished(acc_pa.clone()),
                    _ => unreachable!("no arm matched"),
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<(crate::syntax::Expr, crate::syntax::Expr, crate::lower::types::Env, crate::lower::types::Env, crate::lower::Lx)>, (crate::syntax::Expr, crate::lower::types::Env, crate::lower::types::Env, crate::lower::Lx))) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<(crate::syntax::Expr, crate::syntax::Expr, crate::lower::types::Env, crate::lower::types::Env, crate::lower::Lx)>>>>
    }));
    if &crate::prelude::len(&dyns_p9) == &crate::prelude::Nat::from(0u32) {
        (wx_p0.clone(), crate::lower::types::bind_f(benv_p1, &crate::prelude::Text::lit("#hostline"), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XUnit, crate::lower::types::Holding::Owned, crate::lower::model::OutTy::OutUnit)), crate::prelude::Array::new())
    } else {
        {
            let owner_pj = crate::prelude::Text::from(format!("{}_owner", hf_p3));
            let wx1_pk = {
                let mut this: crate::lower::node_::Wx = wx_p0.clone();
                this.taken_p = crate::prelude::push(&this.taken_p, &owner_pj);
                this.lets_p = crate::prelude::push(&this.lets_p, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(owner_pj.clone()), crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::from(format!("prism_rtl::Link::<{}>::new", &wx_p0.node_p))), crate::prelude::Array::new())));
                this.build_p = crate::prelude::push(&this.build_p, &crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XVar(owner_pj.clone())), crate::prelude::Text::lit("link"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("node"))))]))));
                this
            };
            let env0_pl = crate::lower::types::bind_f(&crate::lower::types::bind_f(benv_p1, &crate::prelude::Text::lit("#hostline"), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XUnit, crate::lower::types::Holding::Owned, crate::lower::model::OutTy::OutUnit)), &crate::prelude::Text::lit("#owner"), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(crate::prelude::Text::from(format!("{}x", &owner_pj))), crate::lower::types::Holding::Owned, crate::lower::model::OutTy::OutUnit));
            let lets0_pm = crate::prelude::Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::prelude::Text::from(format!("{}x", &owner_pj))), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(owner_pj.clone()))))]);
            crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(&dyns_p9)), (wx1_pk.clone(), env0_pl.clone(), lets0_pm.clone()), {
                let dyns_p9x = dyns_p9.clone();
                let hf_p3x = hf_p3.clone();
                let k_p4x = k_p4.clone();
                ::std::rc::Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::types::Env, crate::prelude::Array<crate::lower::model::Do>), crate::prelude::Nat)| {
                    let dyns_p9xy = dyns_p9x.clone();
                    let hf_p3xy = hf_p3x.clone();
                    let k_p4xy = k_p4x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let (w_pn, en_po, ls_pp) = p0;
                        let j_pq = p1;
                        match crate::prelude::index(&dyns_p9xy, &j_pq) {
                            ::std::option::Option::Some((y_pr, d_ps, be_pt, me_pu, lxd_pv)) => {
                                let name_p10 = crate::prelude::Text::from(format!("{}_dyn_{}", &hf_p3xy, &(&j_pq + &crate::prelude::Nat::from(1u32))));
                                let port_p11 = crate::prelude::Text::from(format!("{}_port", &name_p10));
                                crate::prelude::call_then(crate::lower::node_::dynamics::start_dynamic_expr_f({
                                    let mut this: crate::lower::node_::Wx = w_pn.clone();
                                    this.lx_p = lxd_pv.clone();
                                    this
                                }, me_pu.clone(), d_ps.clone()), move |dynamic_expr_f_53887: (crate::lower::model::Ex, crate::prelude::Array<crate::lower::node_::Read>)| {
                                    let (ex_p1e, reads_p1f) = dynamic_expr_f_53887;
                                    crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lxd_pv.clone(), crate::lower::types::peel_f(&crate::lower::type_at_f(&lxd_pv, &d_ps.span_p))), move |out_ty_of_f_53975: crate::lower::model::OutTy| {
                                        let t_p12 = out_ty_of_f_53975;
                                        let through_parent_p13 = crate::prelude::fold(&crate::lower::node_::finish::reads_closed_f(&w_pn.dyn_reads_p, &reads_p1f), &false, &(|f_p1g: &bool, r_p1h: &crate::lower::node_::Read| *f_p1g || match r_p1h {
                                            crate::lower::node_::Read::ParentRead(_) => true,
                                            crate::lower::node_::Read::OwnRead(_) => false,
                                        }));
                                        let valued_p14 = crate::prelude::fold(&crate::lower::node_::finish::reads_closed_f(&w_pn.dyn_reads_p, &reads_p1f), &true, &(|ok_p1i: &bool, r_p1j: &crate::lower::node_::Read| *ok_p1i && match r_p1j {
                                            crate::lower::node_::Read::OwnRead(f_p1k) => crate::check::types::has_text_f(&w_pn.inited_p, f_p1k),
                                            crate::lower::node_::Read::ParentRead(_) => true,
                                        }));
                                        let late_p15 = !(valued_p14 && names_inited_or_parent_f(&w_pn, &be_pt, &d_ps));
                                        let at_build_p16 = crate::prelude::Text::from(format!("{}_at_build", &name_p10));
                                        let w0_p17 = if late_p15 && !crate::check::types::has_nat_f(&w_pn.late_hosts_p, &k_p4xy) {
                                            {
                                                let mut this: crate::lower::node_::Wx = w_pn.clone();
                                                this.late_hosts_p = crate::prelude::push(&this.late_hosts_p, &k_p4xy);
                                                this
                                            }
                                        } else {
                                            w_pn.clone()
                                        };
                                        let w1_p18 = if late_p15 || !through_parent_p13 {
                                            w0_p17.clone()
                                        } else {
                                            {
                                                let mut this: crate::lower::node_::Wx = w0_p17.clone();
                                                this.taken_p = crate::prelude::push(&this.taken_p, &at_build_p16);
                                                this.lets_p = crate::prelude::push(&this.lets_p, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(at_build_p16.clone()), crate::lower::types::own_f(&crate::lower::expr::value_of_f(&lxd_pv, &crate::lower::node_::def::init_env_f(&be_pt), &d_ps))));
                                                this
                                            }
                                        };
                                        let en0_p19 = if late_p15 {
                                            crate::lower::types::bind_f(&en_po, &crate::prelude::Text::from(format!("#dynlate{}", &dyn_key_f(&y_pr))), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XUnit, crate::lower::types::Holding::Owned, crate::lower::model::OutTy::OutUnit))
                                        } else {
                                            en_po.clone()
                                        };
                                        let en1_p1a = if through_parent_p13 && !late_p15 {
                                            crate::lower::types::bind_f(&en0_p19, &crate::prelude::Text::from(format!("#dynbuild{}", &dyn_key_f(&y_pr))), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(crate::prelude::Text::from(format!("{}x", &at_build_p16))), crate::lower::types::Holding::Owned, t_p12.clone()))
                                        } else {
                                            en0_p19.clone()
                                        };
                                        let ls1_p1b = if through_parent_p13 && !late_p15 {
                                            crate::prelude::push(&ls_pp, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::prelude::Text::from(format!("{}x", &at_build_p16))), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(at_build_p16.clone())))))
                                        } else {
                                            ls_pp.clone()
                                        };
                                        let w2_p1c = {
                                            let mut this: crate::lower::node_::Wx = w1_p18.clone();
                                            this.taken_p = crate::prelude::append(&this.taken_p, &crate::prelude::Array::from(vec![name_p10.clone(), port_p11.clone()]));
                                            this.getters_p = crate::prelude::push(&this.getters_p, &crate::lower::model::MethDef { name_p: name_p10.clone(), recv_p: crate::lower::model::Recv::RecvRef, params_p: crate::prelude::Array::new(), cx_p: crate::lower::model::CxArg::CxRef, ret_p: t_p12.clone(), body_p: crate::prelude::Array::new(), tail_p: ex_p1e.clone(), doc_p: crate::prelude::Text::from(format!("The host at `{}`\'s dynamic answer `{}`, read at the read point (round 3 DY).", &hf_p3xy, &crate::lower::functions::src_text_f(&lxd_pv, &lxd_pv.file_p, &y_pr.span_p))) });
                                            this.lets_p = crate::prelude::push(&this.lets_p, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaBind(port_p11.clone())), crate::lower::model::OutTy::OutRc(::std::rc::Rc::new(crate::lower::model::OutTy::OutPort(::std::rc::Rc::new(crate::lower::model::OutTy::OutUnit))))), crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Rc::new")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Port::new")), crate::prelude::Array::new())]))));
                                            this.fields_p = crate::prelude::push(&this.fields_p, &(port_p11.clone(), crate::lower::model::OutTy::OutRc(::std::rc::Rc::new(crate::lower::model::OutTy::OutPort(::std::rc::Rc::new(crate::lower::model::OutTy::OutUnit)))), crate::prelude::Text::from(format!("the dynamic answer `{}` moved: its blueprints push the child\'s place next tick", &name_p10))));
                                            this.moves_p = crate::prelude::push(&this.moves_p, &(port_p11.clone(), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(port_p11.clone())))));
                                            this.dyn_answers_p = crate::prelude::push(&this.dyn_answers_p, &(name_p10.clone(), reads_p1f.clone()));
                                            this
                                        };
                                        let w3_p1d = once_field_f(&w2_p1c, &name_p10);
                                        ::prism_rtl::Turn::Finished((w3_p1d.clone(), crate::lower::types::bind_f(&en1_p1a, &crate::prelude::Text::from(format!("#dyn{}", &dyn_key_f(&y_pr))), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(name_p10.clone()), crate::lower::types::Holding::Owned, t_p12.clone())), crate::prelude::push(&ls1_p1b, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::prelude::Text::from(format!("{}x", &port_p11))), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(port_p11.clone())))))))
                                    })
                                })
                            },
                            ::std::option::Option::None => ::prism_rtl::Turn::Finished((w_pn.clone(), en_po.clone(), ls_pp.clone())),
                        }
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::lower::node_::Wx, crate::lower::types::Env, crate::prelude::Array<crate::lower::model::Do>), crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::prelude::Array<crate::lower::model::Do>)>>>
            }))
        }
    }
}

/// ```prism
/// AnswerDynamics: unbounded fn Lx, Expr -> [((Expr, Expr))]
/// ```
pub fn answer_dynamics_f(lx_p0: &crate::lower::Lx, y_p1: &crate::syntax::Expr) -> crate::prelude::Array<(crate::syntax::Expr, crate::syntax::Expr)> {
    match dynamic_answer_o(lx_p0, y_p1) {
        ::std::option::Option::Some(d_p2) => crate::prelude::Array::from(vec![(y_p1.clone(), d_p2)]),
        ::std::option::Option::None => match &*ungrouped_f(y_p1).kind_p {
            crate::syntax::ExprKind::ETuple(parts_p3) => crate::prelude::fold(parts_p3, &crate::prelude::Array::new(), &(|acc_p4: &crate::prelude::Array<(crate::syntax::Expr, crate::syntax::Expr)>, part_p5: &crate::syntax::Expr| match dynamic_answer_o(lx_p0, part_p5) {
                ::std::option::Option::Some(d_p6) => if &crate::lower::expr::constant_dynamic_o(part_p5) == &::std::option::Option::None {
                    crate::prelude::push(acc_p4, &(part_p5.clone(), d_p6))
                } else {
                    acc_p4.clone()
                },
                ::std::option::Option::None => acc_p4.clone(),
            })),
            _ => crate::prelude::Array::new(),
        },
    }
}

/// ```prism
/// SupplierBinders: unbounded fn [((Expr, Env, Env, Lx))] -> [((Text, Range))]
/// ```
pub fn supplier_binders_f(texts_p0: &crate::prelude::Array<(crate::syntax::Expr, crate::lower::types::Env, crate::lower::types::Env, crate::lower::Lx)>) -> crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)> {
    let of_pattern_f1 = ::std::rc::Rc::new(move |(p0, p1, p2): (crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>, crate::syntax::Pattern, crate::syntax::Range)| crate::prelude::entered(crate::prelude::once_job(move || {
        let acc_p3 = p0;
        let p_p4 = p1;
        let within_p5 = p2;
        crate::prelude::call_then(crate::check::env::names::start_pattern_names_f(p_p4.clone()), move |pattern_names_f_57812: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::prelude::fold(&pattern_names_f_57812, &acc_p3, &(|acc2_p6: &crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>, n_p7: &crate::prelude::Text| if crate::check::env::is_upper_text_f(&crate::lower::base_f(n_p7)) {
            acc2_p6.clone()
        } else {
            crate::prelude::push(acc2_p6, &(n_p7.clone(), within_p5.clone()))
        }))))
    }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>, crate::syntax::Pattern, crate::syntax::Range)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>>>>;
    let of_block_f2 = {
        let of_pattern_f1x = of_pattern_f1.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>, crate::syntax::Block)| {
            let of_pattern_f1xy = of_pattern_f1x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_p8 = p0;
                let b_p9 = p1;
                crate::prelude::fold_job(b_p9.stmts_p.clone(), acc_p8.clone(), {
                    let of_pattern_f1xyx = of_pattern_f1xy.clone();
                    let b_p9x = b_p9.clone();
                    ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>, crate::syntax::Stmt)| {
                        let of_pattern_f1xyxy = of_pattern_f1xyx.clone();
                        let b_p9xy = b_p9x.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let acc2_pa = p0;
                            let st_pb = p1;
                            match &st_pb.kind_p {
                                crate::syntax::StmtKind::SLet(p_pc, _, _) => (&of_pattern_f1xyxy)((acc2_pa.clone(), p_pc.clone(), b_p9xy.span_p.clone())).cycle(),
                                _ => ::prism_rtl::Turn::Finished(acc2_pa.clone()),
                            }
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>, crate::syntax::Stmt)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>>>>
                }).cycle()
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>, crate::syntax::Block)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>>>>
    };
    crate::prelude::run_to_end(crate::prelude::fold_job(texts_p0.clone(), crate::prelude::Array::new(), {
        let of_pattern_f1x = of_pattern_f1.clone();
        let of_block_f2x = of_block_f2.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>, (crate::syntax::Expr, crate::lower::types::Env, crate::lower::types::Env, crate::lower::Lx))| {
            let of_pattern_f1xy = of_pattern_f1x.clone();
            let of_block_f2xy = of_block_f2x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_pd = p0;
                let (x_pe, _, _, _) = p1;
                match &*x_pe.kind_p {
                    crate::syntax::ExprKind::ELambda(params_of, body_pg) => {
                        let of_block_f2xyz = of_block_f2xy.clone();
                        let body_pgz = (**body_pg).clone();
                        let k_let58179 = move |v58179: crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>| {
                            let own_ph = v58179;
                            match &body_pgz {
                                crate::syntax::LambdaBody::LbBlock(b_pl) => (&of_block_f2xyz)((own_ph.clone(), b_pl.clone())).cycle(),
                                crate::syntax::LambdaBody::LbExpr(_) => ::prism_rtl::Turn::Finished(own_ph.clone()),
                            }
                        };
                        match params_of.clone() {
                            ::std::option::Option::Some(ps_pi) => crate::prelude::call_value(crate::prelude::fold_job(ps_pi.clone(), acc_pd.clone(), {
                                let of_pattern_f1xyx = of_pattern_f1xy.clone();
                                let x_pex = x_pe.clone();
                                ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>, crate::syntax::Pattern)| {
                                    let of_pattern_f1xyxy = of_pattern_f1xyx.clone();
                                    let x_pexy = x_pex.clone();
                                    crate::prelude::entered(crate::prelude::once_job(move || {
                                        let acc2_pj = p0;
                                        let p_pk = p1;
                                        (&of_pattern_f1xyxy)((acc2_pj.clone(), p_pk.clone(), x_pexy.span_p.clone())).cycle()
                                    }))
                                }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>, crate::syntax::Pattern)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>>>>
                            }), move |fold_58226: crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>| k_let58179(fold_58226)),
                            ::std::option::Option::None => k_let58179(acc_pd.clone()),
                        }
                    },
                    crate::syntax::ExprKind::EMatch(_, arms_pm) => crate::prelude::fold_job(arms_pm.clone(), acc_pd.clone(), {
                        let of_block_f2xyx = of_block_f2xy.clone();
                        let of_pattern_f1xyx = of_pattern_f1xy.clone();
                        ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>, crate::syntax::Arm)| {
                            let of_block_f2xyxy = of_block_f2xyx.clone();
                            let of_pattern_f1xyxy = of_pattern_f1xyx.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let acc2_pn = p0;
                                let a_po = p1;
                                match &a_po.pattern_o {
                                    ::std::option::Option::Some(p_pp) => {
                                        let p_ppx = p_pp.clone();
                                        crate::prelude::call_value((&of_pattern_f1xyxy)((acc2_pn.clone(), p_ppx.clone(), a_po.span_p.clone())), move |of_pattern_58503: crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>| (&of_block_f2xyxy)((of_pattern_58503, a_po.body_p.clone())).cycle())
                                    },
                                    ::std::option::Option::None => (&of_block_f2xyxy)((acc2_pn.clone(), a_po.body_p.clone())).cycle(),
                                }
                            }))
                        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>, crate::syntax::Arm)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>>>>
                    }).cycle(),
                    _ => ::prism_rtl::Turn::Finished(acc_pd.clone()),
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>, (crate::syntax::Expr, crate::lower::types::Env, crate::lower::types::Env, crate::lower::Lx))) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>>>>
    }))
}

/// ```prism
/// BoundBySupplier: fn [((Text, Range))], Expr -> Bool
/// ```
pub fn bound_by_supplier_f(binders_p0: &crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>, y_p1: &crate::syntax::Expr) -> bool {
    match &*y_p1.kind_p {
        crate::syntax::ExprKind::EName(n_p2) => (&crate::prelude::len(&n_p2.path_p) == &crate::prelude::Nat::from(1u32)) && crate::prelude::fold(binders_p0, &false, &(|found_p3: &bool, (b_p4, within_p5): &(crate::prelude::Text, crate::syntax::Range)| *found_p3 || (((b_p4 == &crate::check::env::sname_key_f(n_p2)) && (&within_p5.start_p <= &y_p1.span_p.start_p)) && (&y_p1.span_p.end_p <= &within_p5.end_p)))),
        _ => false,
    }
}

/// ```prism
/// IsHeldAnswer: unbounded fn Env, [((Text, Range))], Expr -> Bool
/// ```
pub fn is_held_answer_f(menv_p0: &crate::lower::types::Env, binders_p1: &crate::prelude::Array<(crate::prelude::Text, crate::syntax::Range)>, d_p2: &crate::syntax::Expr) -> bool {
    reads_fn_parameter_f(menv_p0, d_p2) || crate::prelude::fold(&crate::check::typed::print::exprs_in_f(d_p2), &false, &(|found_p3: &bool, y_p4: &crate::syntax::Expr| *found_p3 || bound_by_supplier_f(binders_p1, y_p4)))
}

/// ```prism
/// HeldAnswerReaders: unbounded fn Wx, Env, Env, Nat, Expr -> ((Wx, Env, Env))
/// ```
pub fn held_answer_readers_f(wx_p0: &crate::lower::node_::Wx, benv_p1: &crate::lower::types::Env, menv_p2: &crate::lower::types::Env, k_p3: &crate::prelude::Nat, sup_p4: &crate::syntax::Expr) -> (crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env) {
    let lx_p5 = wx_p0.lx_p.clone();
    let texts_p6 = answer_texts_f(&lx_p5, benv_p1, menv_p2, &crate::check::typed::print::exprs_in_f(sup_p4), &crate::prelude::Nat::from(8u32));
    let binders_p7 = supplier_binders_f(&texts_p6);
    let unbound_f8 = {
        let binders_p7x = binders_p7.clone();
        ::std::rc::Rc::new(move |me_pd: &crate::lower::types::Env, y_pe: &crate::syntax::Expr| match &*y_pe.kind_p {
            crate::syntax::ExprKind::EName(n_pf) => !(bound_by_supplier_f(&binders_p7x, y_pe) || crate::check::env::has_key_f(&me_pd.names_p, &crate::prelude::Text::from(format!("{}#fnparameter", &crate::check::env::sname_key_f(n_pf))))),
            _ => false,
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(&crate::lower::types::Env, &crate::syntax::Expr) -> bool>
    };
    let read_p9 = crate::prelude::run_to_end(crate::prelude::fold_job(texts_p6.clone(), crate::prelude::Array::new(), {
        let binders_p7x = binders_p7.clone();
        let unbound_f8x = unbound_f8.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::syntax::Expr>, (crate::syntax::Expr, crate::lower::types::Env, crate::lower::types::Env, crate::lower::Lx))| {
            let binders_p7xy = binders_p7x.clone();
            let unbound_f8xy = unbound_f8x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_pg = p0;
                let (x_ph, _, me_pi, lxd_pj) = p1;
                match &*x_ph.kind_p {
                    crate::syntax::ExprKind::EFreeSigil(m61154_0_0, y_pk) if (m61154_0_0 == &crate::prelude::Text::lit("@")) => crate::prelude::fold_job(answer_dynamics_f(&lxd_pj, &**y_pk), acc_pg.clone(), {
                        let me_pix = me_pi.clone();
                        let binders_p7xyx = binders_p7xy.clone();
                        let unbound_f8xyx = unbound_f8xy.clone();
                        ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::syntax::Expr>, (crate::syntax::Expr, crate::syntax::Expr))| {
                            let me_pixy = me_pix.clone();
                            let binders_p7xyxy = binders_p7xyx.clone();
                            let unbound_f8xyxy = unbound_f8xyx.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let acc2_pl = p0;
                                let (_, d_pm) = p1;
                                if is_held_answer_f(&me_pixy, &binders_p7xyxy, &d_pm) {
                                    crate::prelude::call_then(crate::check::typed::print::start_exprs_in_f(d_pm.clone()), move |exprs_in_f_61307: crate::prelude::Array<crate::syntax::Expr>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc2_pl, &crate::prelude::filter(&exprs_in_f_61307, &(|z_pn: &crate::syntax::Expr| (&unbound_f8xyxy)(&me_pixy, z_pn))))))
                                } else {
                                    ::prism_rtl::Turn::Finished(acc2_pl.clone())
                                }
                            }))
                        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::syntax::Expr>, (crate::syntax::Expr, crate::syntax::Expr))) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::syntax::Expr>>>>
                    }).cycle(),
                    crate::syntax::ExprKind::ECall(c_po, args_pp, _, _) => match &*c_po.kind_p {
                        crate::syntax::ExprKind::EName(n_pq) => match crate::prelude::get(&me_pi.names_p, &crate::check::env::sname_key_f(n_pq)) {
                            ::std::option::Option::Some(crate::lower::types::Bn::BnLocalFn(_)) => crate::prelude::fold_job(args_pp.clone(), acc_pg.clone(), {
                                let lxd_pjx = lxd_pj.clone();
                                let unbound_f8xyx = unbound_f8xy.clone();
                                let me_pix = me_pi.clone();
                                ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::syntax::Expr>, crate::syntax::Arg)| {
                                    let lxd_pjxy = lxd_pjx.clone();
                                    let unbound_f8xyxy = unbound_f8xyx.clone();
                                    let me_pixy = me_pix.clone();
                                    crate::prelude::entered(crate::prelude::once_job(move || {
                                        let acc2_pr = p0;
                                        let a_ps = p1;
                                        if &crate::lower::types::layer_of_f(&crate::lower::type_at_f(&lxd_pjxy, &a_ps.value_p.span_p)) == &crate::lower::types::Layer::LyDyn {
                                            crate::prelude::call_then(crate::check::typed::print::start_exprs_in_f(a_ps.value_p.clone()), move |exprs_in_f_61589: crate::prelude::Array<crate::syntax::Expr>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc2_pr, &crate::prelude::filter(&exprs_in_f_61589, &(|z_pt: &crate::syntax::Expr| (&unbound_f8xyxy)(&me_pixy, z_pt))))))
                                        } else {
                                            ::prism_rtl::Turn::Finished(acc2_pr.clone())
                                        }
                                    }))
                                }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::syntax::Expr>, crate::syntax::Arg)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::syntax::Expr>>>>
                            }).cycle(),
                            _ => ::prism_rtl::Turn::Finished(acc_pg.clone()),
                        },
                        _ => ::prism_rtl::Turn::Finished(acc_pg.clone()),
                    },
                    _ => ::prism_rtl::Turn::Finished(acc_pg.clone()),
                    _ => unreachable!("no arm matched"),
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::syntax::Expr>, (crate::syntax::Expr, crate::lower::types::Env, crate::lower::types::Env, crate::lower::Lx))) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::syntax::Expr>>>>
    }));
    let names_pa = crate::prelude::fold(&read_p9, &crate::prelude::Array::new(), &(|acc_pu: &crate::prelude::Array<crate::syntax::Expr>, y_pv: &crate::syntax::Expr| match &*y_pv.kind_p {
        crate::syntax::ExprKind::EName(n_p10) => if crate::check::env::has_key_f(&menv_p2.names_p, &crate::prelude::Text::from(format!("#whole{}", &dyn_key_f(y_pv)))) || crate::check::env::has_key_f(&menv_p2.names_p, &crate::prelude::Text::from(format!("#whole#{}", &crate::check::env::sname_key_f(n_p10)))) {
            acc_pu.clone()
        } else {
            match crate::prelude::get(&menv_p2.names_p, &crate::check::env::sname_key_f(n_p10)) {
                ::std::option::Option::Some(crate::lower::types::Bn::BnHold(_, _)) => if (&crate::lower::types::layer_of_f(&crate::lower::type_at_f(&lx_p5, &y_pv.span_p)) == &crate::lower::types::Layer::LyDyn) && !crate::check::types::has_text_f(&crate::prelude::each(acc_pu, &(|z_p11: &crate::syntax::Expr| dyn_key_f(z_p11))), &dyn_key_f(y_pv)) {
                    crate::prelude::push(acc_pu, y_pv)
                } else {
                    acc_pu.clone()
                },
                ::std::option::Option::Some(crate::lower::types::Bn::BnDyn(_, _, _)) => if (&crate::lower::types::layer_of_f(&crate::lower::type_at_f(&lx_p5, &y_pv.span_p)) == &crate::lower::types::Layer::LyDyn) && !crate::check::types::has_text_f(&crate::prelude::each(acc_pu, &(|z_p12: &crate::syntax::Expr| dyn_key_f(z_p12))), &dyn_key_f(y_pv)) {
                    crate::prelude::push(acc_pu, y_pv)
                } else {
                    acc_pu.clone()
                },
                _ => acc_pu.clone(),
            }
        },
        _ => acc_pu.clone(),
    }));
    let valued_pb = crate::prelude::run_to_end(crate::prelude::fold_job(names_pa.clone(), true, {
        let wx_p0x = wx_p0.clone();
        let menv_p2x = menv_p2.clone();
        let benv_p1x = benv_p1.clone();
        ::std::rc::Rc::new(move |(p0, p1): (bool, crate::syntax::Expr)| {
            let wx_p0xy = wx_p0x.clone();
            let menv_p2xy = menv_p2x.clone();
            let benv_p1xy = benv_p1x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let ok_p13 = p0;
                let y_p14 = p1;
                crate::prelude::call_then(crate::lower::node_::dynamics::start_dynamic_expr_f(wx_p0xy.clone(), menv_p2xy.clone(), y_p14.clone()), move |dynamic_expr_f_62374: (crate::lower::model::Ex, crate::prelude::Array<crate::lower::node_::Read>)| {
                    let (_, reads_p15) = dynamic_expr_f_62374;
                    if ok_p13 && crate::lower::node_::def::all_inited_f(&wx_p0xy, &reads_p15) {
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::lower::node_::def::NamesInited { env_p0: benv_p1xy.clone(), e_p1: y_p14.clone() }))
                    } else {
                        ::prism_rtl::Turn::Finished(false)
                    }
                })
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::syntax::Expr)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
    }));
    let wx1_pc = if valued_pb || crate::check::types::has_nat_f(&wx_p0.late_hosts_p, k_p3) {
        wx_p0.clone()
    } else {
        {
            let mut this: crate::lower::node_::Wx = wx_p0.clone();
            this.late_hosts_p = crate::prelude::push(&this.late_hosts_p, k_p3);
            this
        }
    };
    live_dynamics_f(&wx1_pc, benv_p1, menv_p2, &names_pa, &false)
}

/// ```prism
/// AnswerTexts: unbounded fn Lx, Env, Env, [Expr], Nat -> [((Expr, Env, Env, Lx))]
/// ```
pub fn answer_texts_f(lx_p0: &crate::lower::Lx, benv_p1: &crate::lower::types::Env, menv_p2: &crate::lower::types::Env, written_p3: &crate::prelude::Array<crate::syntax::Expr>, depth_p4: &crate::prelude::Nat) -> crate::prelude::Array<(crate::syntax::Expr, crate::lower::types::Env, crate::lower::types::Env, crate::lower::Lx)> {
    crate::prelude::run_to_end(crate::prelude::fold_job(written_p3.clone(), crate::prelude::Array::new(), {
        let benv_p1x = benv_p1.clone();
        let menv_p2x = menv_p2.clone();
        let lx_p0x = lx_p0.clone();
        let depth_p4x = depth_p4.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<(crate::syntax::Expr, crate::lower::types::Env, crate::lower::types::Env, crate::lower::Lx)>, crate::syntax::Expr)| {
            let benv_p1xy = benv_p1x.clone();
            let menv_p2xy = menv_p2x.clone();
            let lx_p0xy = lx_p0x.clone();
            let depth_p4xy = depth_p4x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_p5 = p0;
                let x_p6 = p1;
                {
                    let own_p7 = crate::prelude::push(&acc_p5, &(x_p6.clone(), benv_p1xy.clone(), menv_p2xy.clone(), lx_p0xy.clone()));
                    match &*x_p6.kind_p {
                        crate::syntax::ExprKind::EName(n_p8) => if (&crate::prelude::len(&n_p8.path_p) != &crate::prelude::Nat::from(1u32)) || (&depth_p4xy == &crate::prelude::Nat::from(0u32)) {
                            ::prism_rtl::Turn::Finished(own_p7.clone())
                        } else {
                            match crate::prelude::get(&menv_p2xy.names_p, &crate::prelude::Text::from(format!("{}#blueprint", &crate::check::env::sname_key_f(n_p8)))) {
                                ::std::option::Option::Some(crate::lower::types::Bn::BnWidget(held_p9, _, _, _)) => crate::prelude::call_then(crate::check::typed::print::start_exprs_in_f(held_p9.clone()), move |exprs_in_f_63585: crate::prelude::Array<crate::syntax::Expr>| ::prism_rtl::Turn::Finished(crate::prelude::append(&own_p7, &answer_texts_f(&lx_p0xy, &benv_p1xy, &menv_p2xy, &exprs_in_f_63585, &crate::syntax::lexer::chars::dec_f(&depth_p4xy))))),
                                _ => match crate::prelude::get(&menv_p2xy.names_p, &crate::check::env::sname_key_f(n_p8)) {
                                    ::std::option::Option::Some(crate::lower::types::Bn::BnWidget(argument_pa, cbenv_pb, cmenv_pc, clx_pd)) => crate::prelude::call_then(crate::check::typed::print::start_exprs_in_f(argument_pa.clone()), move |exprs_in_f_63769: crate::prelude::Array<crate::syntax::Expr>| ::prism_rtl::Turn::Finished(crate::prelude::append(&own_p7, &answer_texts_f(&clx_pd, &cbenv_pb, &cmenv_pc, &exprs_in_f_63769, &crate::syntax::lexer::chars::dec_f(&depth_p4xy))))),
                                    ::std::option::Option::Some(crate::lower::types::Bn::BnLocalFn(cs_pe)) => crate::prelude::fold_job(cs_pe.clone(), own_p7.clone(), {
                                        let lx_p0xyx = lx_p0xy.clone();
                                        let x_p6x = x_p6.clone();
                                        let benv_p1xyx = benv_p1xy.clone();
                                        let menv_p2xyx = menv_p2xy.clone();
                                        let depth_p4xyx = depth_p4xy.clone();
                                        ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<(crate::syntax::Expr, crate::lower::types::Env, crate::lower::types::Env, crate::lower::Lx)>, crate::syntax::decls::FnClause)| {
                                            let lx_p0xyxy = lx_p0xyx.clone();
                                            let x_p6xy = x_p6x.clone();
                                            let benv_p1xyxy = benv_p1xyx.clone();
                                            let menv_p2xyxy = menv_p2xyx.clone();
                                            let depth_p4xyxy = depth_p4xyx.clone();
                                            crate::prelude::entered(crate::prelude::once_job(move || {
                                                let more_pf = p0;
                                                let c_pg = p1;
                                                ::prism_rtl::Turn::Finished(crate::prelude::append(&more_pf, &answer_texts_f(&crate::lower::expr::local_fn_lx_f(&lx_p0xyxy, &x_p6xy.span_p), &with_fn_parameters_f(&benv_p1xyxy, &c_pg), &with_fn_parameters_f(&menv_p2xyxy, &c_pg), &crate::lower::node_::switch_::clause_exprs_f(&c_pg), &crate::syntax::lexer::chars::dec_f(&depth_p4xyxy))))
                                            }))
                                        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<(crate::syntax::Expr, crate::lower::types::Env, crate::lower::types::Env, crate::lower::Lx)>, crate::syntax::decls::FnClause)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<(crate::syntax::Expr, crate::lower::types::Env, crate::lower::types::Env, crate::lower::Lx)>>>>
                                    }).cycle(),
                                    _ => ::prism_rtl::Turn::Finished(own_p7.clone()),
                                },
                            }
                        },
                        _ => ::prism_rtl::Turn::Finished(own_p7.clone()),
                    }
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<(crate::syntax::Expr, crate::lower::types::Env, crate::lower::types::Env, crate::lower::Lx)>, crate::syntax::Expr)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<(crate::syntax::Expr, crate::lower::types::Env, crate::lower::types::Env, crate::lower::Lx)>>>>
    }))
}

/// ```prism
/// WithFnParameters: unbounded fn Env, FnClause -> Env
/// ```
pub fn with_fn_parameters_f(env_p0: &crate::lower::types::Env, c_p1: &crate::syntax::decls::FnClause) -> crate::lower::types::Env {
    crate::prelude::run_to_end(crate::prelude::fold_job(c_p1.params_p.clone(), env_p0.clone(), ::std::rc::Rc::new(move |(p0, p1): (crate::lower::types::Env, crate::syntax::Pattern)| crate::prelude::entered(crate::prelude::once_job(move || {
        let en_p2 = p0;
        let p_p3 = p1;
        crate::prelude::call_then(crate::lower::node_::def::start_binder_names_f(p_p3.clone()), move |binder_names_f_64856: crate::prelude::Array<crate::syntax::SName>| ::prism_rtl::Turn::Finished(crate::prelude::fold(&binder_names_f_64856, &en_p2, &(|en2_p4: &crate::lower::types::Env, n_p5: &crate::syntax::SName| crate::lower::types::bind_f(en2_p4, &crate::prelude::Text::from(format!("{}#fnparameter", &crate::check::env::sname_key_f(n_p5))), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XUnit, crate::lower::types::Holding::Owned, crate::lower::model::OutTy::OutUnit))))))
    }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::types::Env, crate::syntax::Pattern)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::types::Env>>>))
}

/// ```prism
/// ReadsFnParameter: unbounded fn Env, Expr -> Bool
/// ```
pub fn reads_fn_parameter_f(env_p0: &crate::lower::types::Env, d_p1: &crate::syntax::Expr) -> bool {
    crate::prelude::fold(&crate::lower::expr::read_names_f(&crate::check::typed::print::exprs_in_f(d_p1)), &false, &(|found_p2: &bool, n_p3: &crate::prelude::Text| *found_p2 || crate::check::env::has_key_f(&env_p0.names_p, &crate::prelude::Text::from(format!("{}#fnparameter", n_p3)))))
}

/// ```prism
/// NamesInitedOrParent: unbounded fn Wx, Env, Expr -> Bool
/// ```
pub fn names_inited_or_parent_f(wx_p0: &crate::lower::node_::Wx, env_p1: &crate::lower::types::Env, e_p2: &crate::syntax::Expr) -> bool {
    crate::prelude::fold(&crate::lower::expr::read_names_f(&crate::check::typed::print::exprs_in_f(e_p2)), &true, &(|ok_p3: &bool, n_p4: &crate::prelude::Text| (*ok_p3 && !crate::check::env::has_key_f(&env_p1.names_p, &crate::prelude::Text::from(format!("{}#late", n_p4)))) && match crate::prelude::get(&env_p1.names_p, n_p4) {
        ::std::option::Option::Some(crate::lower::types::Bn::BnDyn(ex_p5, rds_p6, _)) => crate::check::env::has_key_f(&env_p1.names_p, &crate::prelude::Text::from(format!("{}#init", n_p4))) || crate::prelude::fold(&crate::lower::node_::finish::reads_closed_f(&wx_p0.dyn_reads_p, &rds_p6), &(&crate::prelude::len(&rds_p6) > &crate::prelude::Nat::from(0u32)), &(|par_p7: &bool, r_p8: &crate::lower::node_::Read| *par_p7 && crate::lower::node_::switch_::is_parent_read_f(r_p8))),
        ::std::option::Option::Some(crate::lower::types::Bn::BnHold(_, _)) => crate::check::env::has_key_f(&env_p1.names_p, &crate::prelude::Text::from(format!("{}#init", n_p4))),
        _ => true,
    }))
}

/// ```prism
/// OnceField: fn Wx, Text -> Wx
/// ```
pub fn once_field_f(wx_p0: &crate::lower::node_::Wx, name_p1: &crate::prelude::Text) -> crate::lower::node_::Wx {
    let mut this: crate::lower::node_::Wx = wx_p0.clone();
    this.taken_p = crate::prelude::push(&this.taken_p, &crate::prelude::Text::from(format!("{}_once", name_p1)));
    this.fields_p = crate::prelude::push(&this.fields_p, &(crate::prelude::Text::from(format!("{}_once", name_p1)), crate::lower::model::OutTy::OutStamped(::std::rc::Rc::new(crate::lower::model::OutTy::OutUnit)), crate::prelude::Text::from(format!("the tick `{}`\'s port fired in", name_p1))));
    this.moves_p = crate::prelude::push(&this.moves_p, &(crate::prelude::Text::from(format!("{}_once", name_p1)), crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Stamped::new")), crate::prelude::Array::new())));
    this
}

/// ```prism
/// WholeArgs: unbounded fn Wx, Env, Env, Expr, Bool -> ((Wx, Env, Env))
/// ```
pub fn whole_args_f(wx_p0: &crate::lower::node_::Wx, benv_p1: &crate::lower::types::Env, menv_p2: &crate::lower::types::Env, e_p3: &crate::syntax::Expr, whole_p4: &bool) -> (crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env) {
    whole_args_at_f(wx_p0, benv_p1, menv_p2, e_p3, whole_p4, &false)
}

/// The step machine of `WholeArgs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// WholeArgs: unbounded fn Wx, Env, Env, Expr, Bool -> ((Wx, Env, Env))
/// ```
pub struct WholeArgs {
    pub wx_p0: crate::lower::node_::Wx,
    pub benv_p1: crate::lower::types::Env,
    pub menv_p2: crate::lower::types::Env,
    pub e_p3: crate::syntax::Expr,
    pub whole_p4: bool,
}

impl ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)> for WholeArgs {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)> {
        let wx_p0 = &self.wx_p0;
        let benv_p1 = &self.benv_p1;
        let menv_p2 = &self.menv_p2;
        let e_p3 = &self.e_p3;
        let whole_p4 = &self.whole_p4;
        ::prism_rtl::Turn::More(::std::rc::Rc::new(WholeArgsAt { wx_p0: wx_p0.clone(), benv_p1: benv_p1.clone(), menv_p2: menv_p2.clone(), e_p3: e_p3.clone(), whole_p4: *whole_p4, late_p5: false }))
    }
}

/// `Start WholeArgs, x`: what the function value is when passed to `@Run`.
pub fn start_whole_args_f(wx_p0: crate::lower::node_::Wx, benv_p1: crate::lower::types::Env, menv_p2: crate::lower::types::Env, e_p3: crate::syntax::Expr, whole_p4: bool) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>> {
    ::std::rc::Rc::new(WholeArgs { wx_p0, benv_p1, menv_p2, e_p3, whole_p4 })
}

/// ```prism
/// WholeArgsAt: unbounded fn Wx, Env, Env, Expr, Bool, Bool -> ((Wx, Env, Env))
/// ```
pub fn whole_args_at_f(wx_p0: &crate::lower::node_::Wx, benv_p1: &crate::lower::types::Env, menv_p2: &crate::lower::types::Env, e_p3: &crate::syntax::Expr, whole_p4: &bool, late_p5: &bool) -> (crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env) {
    let lx_p6 = wx_p0.lx_p.clone();
    let element_values_p7 = element_values_in_f(&lx_p6, e_p3);
    let shared_calls_p8 = crate::lower::node_::switch_::shared_live_calls_f(wx_p0, menv_p2, e_p3);
    let calls_p9 = crate::prelude::run_to_end(crate::prelude::filter_job(crate::check::typed::print::exprs_in_f(e_p3), {
        let lx_p6x = lx_p6.clone();
        let element_values_p7x = element_values_p7.clone();
        let shared_calls_p8x = shared_calls_p8.clone();
        ::std::rc::Rc::new(move |p0: crate::syntax::Expr| {
            let lx_p6xy = lx_p6x.clone();
            let element_values_p7xy = element_values_p7x.clone();
            let shared_calls_p8xy = shared_calls_p8x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let x_ph = p0;
                match &*x_ph.kind_p {
                    crate::syntax::ExprKind::ECall(c_pi, _, _, _) => {
                        let c_pix = (**c_pi).clone();
                        crate::prelude::call_then(crate::lower::expr::start_is_whole_object_f(lx_p6xy.clone(), x_ph.clone()), move |is_whole_object_f_69244: bool| ::prism_rtl::Turn::Finished((((((is_whole_object_f_69244 || crate::lower::expr::is_whole_fn_f(&lx_p6xy, &crate::lower::node_::dynamics::callee_key_f(&lx_p6xy, &c_pix))) || (&crate::lower::node_::dynamics::callee_key_f(&lx_p6xy, &c_pix) == &crate::prelude::Text::lit("Prelude.@Flatten"))) || (&crate::lower::node_::dynamics::callee_key_f(&lx_p6xy, &c_pix) == &crate::prelude::Text::lit("Prelude.@Switch"))) || crate::check::types::has_text_f(&element_values_p7xy, &dyn_key_f(&x_ph))) || crate::check::types::has_text_f(&shared_calls_p8xy, &dyn_key_f(&x_ph))) || crate::lower::expr::is_dynamic_field_ctor_f(&lx_p6xy, &crate::lower::node_::dynamics::callee_key_f(&lx_p6xy, &c_pix))))
                    },
                    _ => ::prism_rtl::Turn::Finished(false),
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::syntax::Expr) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
    }));
    let in_lambdas_pa = crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::typed::print::exprs_in_f(e_p3), crate::prelude::Array::new(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::syntax::Expr>, crate::syntax::Expr)| crate::prelude::entered(crate::prelude::once_job(move || {
        let acc_pj = p0;
        let x_pk = p1;
        match &*x_pk.kind_p {
            crate::syntax::ExprKind::ELambda(_, _) => crate::prelude::call_then(crate::check::typed::print::start_exprs_in_f(x_pk.clone()), move |exprs_in_f_69823: crate::prelude::Array<crate::syntax::Expr>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_pj, &exprs_in_f_69823))),
            _ => ::prism_rtl::Turn::Finished(acc_pj.clone()),
        }
    }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::syntax::Expr>, crate::syntax::Expr)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::syntax::Expr>>>>));
    let updated_calls_pb = crate::prelude::filter(&in_lambdas_pa, &(|x_pl: &crate::syntax::Expr| match &*x_pl.kind_p {
        crate::syntax::ExprKind::ECall(c_pm, _, _, _) => &crate::lower::node_::dynamics::callee_key_f(&lx_p6, &**c_pm) == &crate::prelude::Text::lit("Prelude.!Updated"),
        _ => false,
    }));
    let constants_pc = crate::prelude::filter(&crate::check::typed::print::exprs_in_f(e_p3), &(|x_pn: &crate::syntax::Expr| crate::lower::expr::constant_of_time_at_f(&lx_p6, x_pn)));
    let given_on_pd = crate::prelude::filter(&crate::check::typed::print::exprs_in_f(e_p3), &(|x_po: &crate::syntax::Expr| match &*x_po.kind_p {
        crate::syntax::ExprKind::EBinary(m70604_0_0, value_pp, _) if (m70604_0_0 == &crate::prelude::Text::lit("on")) => crate::lower::types::has_time_f(&crate::lower::types::peel_f(&crate::lower::type_at_f(&lx_p6, &x_po.span_p))) && (&crate::lower::types::layer_of_f(&crate::lower::type_at_f(&lx_p6, &value_pp.span_p)) != &crate::lower::types::Layer::LyDyn),
        _ => false,
        _ => unreachable!("no arm matched"),
    }));
    let roots_pe = crate::prelude::run_to_end(crate::prelude::fold_job(crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&calls_p9, &updated_calls_pb), &constants_pc), &given_on_pd), if *whole_p4 {
        crate::check::typed::print::exprs_in_f(e_p3)
    } else {
        crate::prelude::Array::new()
    }, ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::syntax::Expr>, crate::syntax::Expr)| crate::prelude::entered(crate::prelude::once_job(move || {
        let acc_pq = p0;
        let c_pr = p1;
        match &*c_pr.kind_p {
            crate::syntax::ExprKind::ECall(_, args_ps, _, _) => crate::prelude::fold_job(args_ps.clone(), acc_pq.clone(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::syntax::Expr>, crate::syntax::Arg)| crate::prelude::entered(crate::prelude::once_job(move || {
                let acc2_pt = p0;
                let a_pu = p1;
                crate::prelude::call_then(crate::check::typed::print::start_exprs_in_f(a_pu.value_p.clone()), move |exprs_in_f_70996: crate::prelude::Array<crate::syntax::Expr>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc2_pt, &exprs_in_f_70996)))
            }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::syntax::Expr>, crate::syntax::Arg)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::syntax::Expr>>>>).cycle(),
            crate::syntax::ExprKind::EFreeSigil(_, x_pv) => {
                let x_pvx = (**x_pv).clone();
                crate::prelude::call_then(crate::check::typed::print::start_exprs_in_f(x_pvx.clone()), move |exprs_in_f_71056: crate::prelude::Array<crate::syntax::Expr>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_pq, &exprs_in_f_71056)))
            },
            crate::syntax::ExprKind::EBinary(m70897_2_0, value_p10, _) if (m70897_2_0 == &crate::prelude::Text::lit("on")) => {
                let value_p10x = (**value_p10).clone();
                crate::prelude::call_then(crate::check::typed::print::start_exprs_in_f(value_p10x.clone()), move |exprs_in_f_71117: crate::prelude::Array<crate::syntax::Expr>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_pq, &exprs_in_f_71117)))
            },
            _ => ::prism_rtl::Turn::Finished(acc_pq.clone()),
            _ => unreachable!("no arm matched"),
        }
    }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::syntax::Expr>, crate::syntax::Expr)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::syntax::Expr>>>>));
    let names0_pf = crate::prelude::fold(&roots_pe, &crate::prelude::Array::new(), &(|acc3_p11: &crate::prelude::Array<crate::syntax::Expr>, y_p12: &crate::syntax::Expr| match &*y_p12.kind_p {
        crate::syntax::ExprKind::EName(n_p13) => if crate::check::env::has_key_f(&menv_p2.names_p, &crate::prelude::Text::from(format!("#whole{}", &dyn_key_f(y_p12)))) || crate::check::env::has_key_f(&menv_p2.names_p, &crate::prelude::Text::from(format!("#whole#{}", &crate::check::env::sname_key_f(n_p13)))) {
            acc3_p11.clone()
        } else {
            match crate::prelude::get(&menv_p2.names_p, &crate::check::env::sname_key_f(n_p13)) {
                ::std::option::Option::Some(crate::lower::types::Bn::BnHold(_, _)) => if (&crate::lower::types::layer_of_f(&crate::lower::type_at_f(&lx_p6, &y_p12.span_p)) == &crate::lower::types::Layer::LyDyn) && !crate::check::types::has_text_f(&crate::prelude::each(acc3_p11, &(|z_p14: &crate::syntax::Expr| dyn_key_f(z_p14))), &dyn_key_f(y_p12)) {
                    crate::prelude::push(acc3_p11, y_p12)
                } else {
                    acc3_p11.clone()
                },
                ::std::option::Option::Some(crate::lower::types::Bn::BnDyn(_, _, _)) => if (&crate::lower::types::layer_of_f(&crate::lower::type_at_f(&lx_p6, &y_p12.span_p)) == &crate::lower::types::Layer::LyDyn) && !crate::check::types::has_text_f(&crate::prelude::each(acc3_p11, &(|z_p15: &crate::syntax::Expr| dyn_key_f(z_p15))), &dyn_key_f(y_p12)) {
                    crate::prelude::push(acc3_p11, y_p12)
                } else {
                    acc3_p11.clone()
                },
                _ => acc3_p11.clone(),
            }
        },
        _ => acc3_p11.clone(),
    }));
    let outers_pg = crate::prelude::fold(&calls_p9, &crate::prelude::Array::new(), &(|acc_p16: &crate::prelude::Array<crate::syntax::Expr>, c_p17: &crate::syntax::Expr| match &*c_p17.kind_p {
        crate::syntax::ExprKind::ECall(callee_p18, args_p19, _, _) => if &crate::lower::node_::dynamics::callee_key_f(&lx_p6, &**callee_p18) != &crate::prelude::Text::lit("Prelude.@Flatten") {
            acc_p16.clone()
        } else {
            match crate::prelude::index(args_p19, &crate::prelude::Nat::from(0u32)) {
                ::std::option::Option::Some(a_p1a) => match &*a_p1a.value_p.kind_p {
                    crate::syntax::ExprKind::EName(_) => acc_p16.clone(),
                    _ => if (&crate::lower::types::layer_of_f(&crate::lower::type_at_f(&lx_p6, &a_p1a.value_p.span_p)) == &crate::lower::types::Layer::LyDyn) && !crate::check::env::has_key_f(&menv_p2.names_p, &crate::prelude::Text::from(format!("#whole{}", &dyn_key_f(&a_p1a.value_p)))) {
                        crate::prelude::push(acc_p16, &a_p1a.value_p)
                    } else {
                        acc_p16.clone()
                    },
                },
                ::std::option::Option::None => acc_p16.clone(),
            }
        },
        _ => acc_p16.clone(),
    }));
    live_dynamics_f(wx_p0, benv_p1, menv_p2, &crate::prelude::append(&names0_pf, &outers_pg), late_p5)
}

/// The step machine of `WholeArgsAt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// WholeArgsAt: unbounded fn Wx, Env, Env, Expr, Bool, Bool -> ((Wx, Env, Env))
/// ```
pub struct WholeArgsAt {
    pub wx_p0: crate::lower::node_::Wx,
    pub benv_p1: crate::lower::types::Env,
    pub menv_p2: crate::lower::types::Env,
    pub e_p3: crate::syntax::Expr,
    pub whole_p4: bool,
    pub late_p5: bool,
}

impl ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)> for WholeArgsAt {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)> {
        let wx_p0 = &self.wx_p0;
        let benv_p1 = &self.benv_p1;
        let menv_p2 = &self.menv_p2;
        let e_p3 = &self.e_p3;
        let whole_p4 = &self.whole_p4;
        let late_p5 = &self.late_p5;
        let lx_p6 = wx_p0.lx_p.clone();
        let element_values_p7 = element_values_in_f(&lx_p6, e_p3);
        let shared_calls_p8 = crate::lower::node_::switch_::shared_live_calls_f(wx_p0, menv_p2, e_p3);
        let benv_p1x = benv_p1.clone();
        let e_p3x = e_p3.clone();
        let late_p5x = *late_p5;
        let menv_p2x = menv_p2.clone();
        let whole_p4x = *whole_p4;
        let wx_p0x = wx_p0.clone();
        crate::prelude::call_then(crate::check::typed::print::start_exprs_in_f(e_p3x.clone()), move |exprs_in_f_69171: crate::prelude::Array<crate::syntax::Expr>| crate::prelude::call_value(crate::prelude::filter_job(exprs_in_f_69171, {
            let lx_p6x = lx_p6.clone();
            let element_values_p7x = element_values_p7.clone();
            let shared_calls_p8x = shared_calls_p8.clone();
            ::std::rc::Rc::new(move |p0: crate::syntax::Expr| {
                let lx_p6xy = lx_p6x.clone();
                let element_values_p7xy = element_values_p7x.clone();
                let shared_calls_p8xy = shared_calls_p8x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let x_ph = p0;
                    match &*x_ph.kind_p {
                        crate::syntax::ExprKind::ECall(c_pi, _, _, _) => {
                            let c_pix = (**c_pi).clone();
                            crate::prelude::call_then(crate::lower::expr::start_is_whole_object_f(lx_p6xy.clone(), x_ph.clone()), move |is_whole_object_f_69244: bool| ::prism_rtl::Turn::Finished((((((is_whole_object_f_69244 || crate::lower::expr::is_whole_fn_f(&lx_p6xy, &crate::lower::node_::dynamics::callee_key_f(&lx_p6xy, &c_pix))) || (&crate::lower::node_::dynamics::callee_key_f(&lx_p6xy, &c_pix) == &crate::prelude::Text::lit("Prelude.@Flatten"))) || (&crate::lower::node_::dynamics::callee_key_f(&lx_p6xy, &c_pix) == &crate::prelude::Text::lit("Prelude.@Switch"))) || crate::check::types::has_text_f(&element_values_p7xy, &dyn_key_f(&x_ph))) || crate::check::types::has_text_f(&shared_calls_p8xy, &dyn_key_f(&x_ph))) || crate::lower::expr::is_dynamic_field_ctor_f(&lx_p6xy, &crate::lower::node_::dynamics::callee_key_f(&lx_p6xy, &c_pix))))
                        },
                        _ => ::prism_rtl::Turn::Finished(false),
                    }
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::syntax::Expr) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
        }), move |filter_69163: crate::prelude::Array<crate::syntax::Expr>| {
            let calls_p9 = filter_69163;
            crate::prelude::call_then(crate::check::typed::print::start_exprs_in_f(e_p3x.clone()), move |exprs_in_f_69736: crate::prelude::Array<crate::syntax::Expr>| crate::prelude::call_value(crate::prelude::fold_job(exprs_in_f_69736, crate::prelude::Array::new(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::syntax::Expr>, crate::syntax::Expr)| crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_pj = p0;
                let x_pk = p1;
                match &*x_pk.kind_p {
                    crate::syntax::ExprKind::ELambda(_, _) => crate::prelude::call_then(crate::check::typed::print::start_exprs_in_f(x_pk.clone()), move |exprs_in_f_69823: crate::prelude::Array<crate::syntax::Expr>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_pj, &exprs_in_f_69823))),
                    _ => ::prism_rtl::Turn::Finished(acc_pj.clone()),
                }
            }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::syntax::Expr>, crate::syntax::Expr)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::syntax::Expr>>>>), move |fold_69730: crate::prelude::Array<crate::syntax::Expr>| {
                let in_lambdas_pa = fold_69730;
                let updated_calls_pb = crate::prelude::filter(&in_lambdas_pa, &(|x_pl: &crate::syntax::Expr| match &*x_pl.kind_p {
                    crate::syntax::ExprKind::ECall(c_pm, _, _, _) => &crate::lower::node_::dynamics::callee_key_f(&lx_p6, &**c_pm) == &crate::prelude::Text::lit("Prelude.!Updated"),
                    _ => false,
                }));
                crate::prelude::call_then(crate::check::typed::print::start_exprs_in_f(e_p3x.clone()), move |exprs_in_f_70192: crate::prelude::Array<crate::syntax::Expr>| {
                    let constants_pc = crate::prelude::filter(&exprs_in_f_70192, &(|x_pn: &crate::syntax::Expr| crate::lower::expr::constant_of_time_at_f(&lx_p6, x_pn)));
                    crate::prelude::call_then(crate::check::typed::print::start_exprs_in_f(e_p3x.clone()), move |exprs_in_f_70587: crate::prelude::Array<crate::syntax::Expr>| {
                        let given_on_pd = crate::prelude::filter(&exprs_in_f_70587, &(|x_po: &crate::syntax::Expr| match &*x_po.kind_p {
                            crate::syntax::ExprKind::EBinary(m70604_0_0, value_pp, _) if (m70604_0_0 == &crate::prelude::Text::lit("on")) => crate::lower::types::has_time_f(&crate::lower::types::peel_f(&crate::lower::type_at_f(&lx_p6, &x_po.span_p))) && (&crate::lower::types::layer_of_f(&crate::lower::type_at_f(&lx_p6, &value_pp.span_p)) != &crate::lower::types::Layer::LyDyn),
                            _ => false,
                            _ => unreachable!("no arm matched"),
                        }));
                        crate::prelude::call_value(crate::prelude::fold_job(crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&calls_p9, &updated_calls_pb), &constants_pc), &given_on_pd), if whole_p4x {
                            crate::check::typed::print::exprs_in_f(&e_p3x)
                        } else {
                            crate::prelude::Array::new()
                        }, ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::syntax::Expr>, crate::syntax::Expr)| crate::prelude::entered(crate::prelude::once_job(move || {
                            let acc_pq = p0;
                            let c_pr = p1;
                            match &*c_pr.kind_p {
                                crate::syntax::ExprKind::ECall(_, args_ps, _, _) => crate::prelude::fold_job(args_ps.clone(), acc_pq.clone(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::syntax::Expr>, crate::syntax::Arg)| crate::prelude::entered(crate::prelude::once_job(move || {
                                    let acc2_pt = p0;
                                    let a_pu = p1;
                                    crate::prelude::call_then(crate::check::typed::print::start_exprs_in_f(a_pu.value_p.clone()), move |exprs_in_f_70996: crate::prelude::Array<crate::syntax::Expr>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc2_pt, &exprs_in_f_70996)))
                                }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::syntax::Expr>, crate::syntax::Arg)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::syntax::Expr>>>>).cycle(),
                                crate::syntax::ExprKind::EFreeSigil(_, x_pv) => {
                                    let x_pvx = (**x_pv).clone();
                                    crate::prelude::call_then(crate::check::typed::print::start_exprs_in_f(x_pvx.clone()), move |exprs_in_f_71056: crate::prelude::Array<crate::syntax::Expr>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_pq, &exprs_in_f_71056)))
                                },
                                crate::syntax::ExprKind::EBinary(m70897_2_0, value_p10, _) if (m70897_2_0 == &crate::prelude::Text::lit("on")) => {
                                    let value_p10x = (**value_p10).clone();
                                    crate::prelude::call_then(crate::check::typed::print::start_exprs_in_f(value_p10x.clone()), move |exprs_in_f_71117: crate::prelude::Array<crate::syntax::Expr>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_pq, &exprs_in_f_71117)))
                                },
                                _ => ::prism_rtl::Turn::Finished(acc_pq.clone()),
                                _ => unreachable!("no arm matched"),
                            }
                        }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::syntax::Expr>, crate::syntax::Expr)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::syntax::Expr>>>>), move |fold_70780: crate::prelude::Array<crate::syntax::Expr>| {
                            let roots_pe = fold_70780;
                            let names0_pf = crate::prelude::fold(&roots_pe, &crate::prelude::Array::new(), &(|acc3_p11: &crate::prelude::Array<crate::syntax::Expr>, y_p12: &crate::syntax::Expr| match &*y_p12.kind_p {
                                crate::syntax::ExprKind::EName(n_p13) => if crate::check::env::has_key_f(&menv_p2x.names_p, &crate::prelude::Text::from(format!("#whole{}", &dyn_key_f(y_p12)))) || crate::check::env::has_key_f(&menv_p2x.names_p, &crate::prelude::Text::from(format!("#whole#{}", &crate::check::env::sname_key_f(n_p13)))) {
                                    acc3_p11.clone()
                                } else {
                                    match crate::prelude::get(&menv_p2x.names_p, &crate::check::env::sname_key_f(n_p13)) {
                                        ::std::option::Option::Some(crate::lower::types::Bn::BnHold(_, _)) => if (&crate::lower::types::layer_of_f(&crate::lower::type_at_f(&lx_p6, &y_p12.span_p)) == &crate::lower::types::Layer::LyDyn) && !crate::check::types::has_text_f(&crate::prelude::each(acc3_p11, &(|z_p14: &crate::syntax::Expr| dyn_key_f(z_p14))), &dyn_key_f(y_p12)) {
                                            crate::prelude::push(acc3_p11, y_p12)
                                        } else {
                                            acc3_p11.clone()
                                        },
                                        ::std::option::Option::Some(crate::lower::types::Bn::BnDyn(_, _, _)) => if (&crate::lower::types::layer_of_f(&crate::lower::type_at_f(&lx_p6, &y_p12.span_p)) == &crate::lower::types::Layer::LyDyn) && !crate::check::types::has_text_f(&crate::prelude::each(acc3_p11, &(|z_p15: &crate::syntax::Expr| dyn_key_f(z_p15))), &dyn_key_f(y_p12)) {
                                            crate::prelude::push(acc3_p11, y_p12)
                                        } else {
                                            acc3_p11.clone()
                                        },
                                        _ => acc3_p11.clone(),
                                    }
                                },
                                _ => acc3_p11.clone(),
                            }));
                            let outers_pg = crate::prelude::fold(&calls_p9, &crate::prelude::Array::new(), &(|acc_p16: &crate::prelude::Array<crate::syntax::Expr>, c_p17: &crate::syntax::Expr| match &*c_p17.kind_p {
                                crate::syntax::ExprKind::ECall(callee_p18, args_p19, _, _) => if &crate::lower::node_::dynamics::callee_key_f(&lx_p6, &**callee_p18) != &crate::prelude::Text::lit("Prelude.@Flatten") {
                                    acc_p16.clone()
                                } else {
                                    match crate::prelude::index(args_p19, &crate::prelude::Nat::from(0u32)) {
                                        ::std::option::Option::Some(a_p1a) => match &*a_p1a.value_p.kind_p {
                                            crate::syntax::ExprKind::EName(_) => acc_p16.clone(),
                                            _ => if (&crate::lower::types::layer_of_f(&crate::lower::type_at_f(&lx_p6, &a_p1a.value_p.span_p)) == &crate::lower::types::Layer::LyDyn) && !crate::check::env::has_key_f(&menv_p2x.names_p, &crate::prelude::Text::from(format!("#whole{}", &dyn_key_f(&a_p1a.value_p)))) {
                                                crate::prelude::push(acc_p16, &a_p1a.value_p)
                                            } else {
                                                acc_p16.clone()
                                            },
                                        },
                                        ::std::option::Option::None => acc_p16.clone(),
                                    }
                                },
                                _ => acc_p16.clone(),
                            }));
                            ::prism_rtl::Turn::Finished(live_dynamics_f(&wx_p0x, &benv_p1x, &menv_p2x, &crate::prelude::append(&names0_pf, &outers_pg), &late_p5x))
                        })
                    })
                })
            }))
        }))
    }
}

/// `Start WholeArgsAt, x`: what the function value is when passed to `@Run`.
pub fn start_whole_args_at_f(wx_p0: crate::lower::node_::Wx, benv_p1: crate::lower::types::Env, menv_p2: crate::lower::types::Env, e_p3: crate::syntax::Expr, whole_p4: bool, late_p5: bool) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>> {
    ::std::rc::Rc::new(WholeArgsAt { wx_p0, benv_p1, menv_p2, e_p3, whole_p4, late_p5 })
}

/// ```prism
/// LiveDynamics: unbounded fn Wx, Env, Env, [Expr], Bool -> ((Wx, Env, Env))
/// ```
pub fn live_dynamics_f(wx_p0: &crate::lower::node_::Wx, benv_p1: &crate::lower::types::Env, menv_p2: &crate::lower::types::Env, names_p3: &crate::prelude::Array<crate::syntax::Expr>, late_p4: &bool) -> (crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env) {
    let lx_p5 = wx_p0.lx_p.clone();
    if &crate::prelude::len(names_p3) == &crate::prelude::Nat::from(0u32) {
        (wx_p0.clone(), benv_p1.clone(), menv_p2.clone())
    } else {
        {
            let owner_p6 = crate::prelude::Text::lit("whole_owner");
            let wx1_p7 = if crate::check::types::has_text_f(&wx_p0.taken_p, &owner_p6) {
                wx_p0.clone()
            } else {
                {
                    let mut this: crate::lower::node_::Wx = wx_p0.clone();
                    this.taken_p = crate::prelude::push(&this.taken_p, &owner_p6);
                    this.lets_p = crate::prelude::push(&this.lets_p, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(owner_p6.clone()), crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::from(format!("prism_rtl::Link::<{}>::new", &wx_p0.node_p))), crate::prelude::Array::new())));
                    this.build_p = crate::prelude::push(&this.build_p, &crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XVar(owner_p6.clone())), crate::prelude::Text::lit("link"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("node"))))]))));
                    this
                }
            };
            crate::prelude::run_to_end(crate::prelude::fold_job(names_p3.clone(), (wx1_p7.clone(), benv_p1.clone(), menv_p2.clone()), {
                let lx_p5x = lx_p5.clone();
                let late_p4x = *late_p4;
                let owner_p6x = owner_p6.clone();
                ::std::rc::Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::syntax::Expr)| {
                    let lx_p5xy = lx_p5x.clone();
                    let late_p4xy = late_p4x;
                    let owner_p6xy = owner_p6x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let (w_p8, be_p9, me_pa) = p0;
                        let y_pb = p1;
                        {
                            let stem_pc = match &*y_pb.kind_p {
                                crate::syntax::ExprKind::EName(_) => crate::prelude::Text::from(format!("whole_{}", &crate::lower::snake_f(&crate::lower::functions::src_text_f(&lx_p5xy, &lx_p5xy.file_p, &y_pb.span_p)))),
                                _ => crate::prelude::Text::lit("whole_outer"),
                            };
                            let (name_pq, w1_pr) = crate::lower::node_::fresh_name_f(&w_p8, &stem_pc);
                            let port_pd = crate::prelude::Text::from(format!("{}_port", &name_pq));
                            let dyn_pe = crate::prelude::Text::from(format!("{}_dyn", &name_pq));
                            crate::prelude::call_then(crate::lower::node_::dynamics::start_dynamic_expr_f(w1_pr.clone(), me_pa.clone(), y_pb.clone()), move |dynamic_expr_f_73655: (crate::lower::model::Ex, crate::prelude::Array<crate::lower::node_::Read>)| {
                                let (ex_ps, reads_pt) = dynamic_expr_f_73655;
                                crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p5xy.clone(), crate::lower::types::peel_f(&crate::lower::type_at_f(&lx_p5xy, &y_pb.span_p))), move |out_ty_of_f_73697: crate::lower::model::OutTy| {
                                    let t_pf = out_ty_of_f_73697;
                                    let valued_pg = (crate::lower::node_::def::all_inited_f(&w1_pr, &reads_pt) && crate::lower::node_::def::names_inited_f(&be_p9, &y_pb)) && !late_p4xy;
                                    let unlinked_ph = if valued_pg {
                                        crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("at_build"))))
                                    } else {
                                        crate::lower::model::Ex::XUnreachable
                                    };
                                    let arms_pi = crate::prelude::Array::from(vec![crate::lower::model::XArm { pat_p: crate::lower::model::Pa::PaCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Some")), crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("owner"))])), conds_p: crate::prelude::Array::new(), body_p: crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("owner"))), name_pq.clone(), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx])) }, crate::lower::model::XArm { pat_p: crate::lower::model::Pa::PaUnit(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::None"))), conds_p: crate::prelude::Array::new(), body_p: unlinked_ph.clone() }]);
                                    let read_pj = crate::lower::model::Ex::XClosure(true, crate::prelude::Array::from(vec![crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("cx"))), crate::lower::model::OutTy::OutRef(::std::rc::Rc::new(crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Cx")), crate::prelude::Array::new()))))]), ::std::rc::Rc::new(crate::lower::model::Ex::XMatch(::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("link"))), crate::prelude::Text::lit("owner"), crate::prelude::Array::new())), arms_pi.clone(), false, t_pf.clone())));
                                    let linked_pk = crate::prelude::Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("link")), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(owner_p6xy.clone()))))]);
                                    let be_p9z = be_p9.clone();
                                    let dyn_pez = dyn_pe.clone();
                                    let ex_psz = ex_ps.clone();
                                    let lx_p5xyz = lx_p5xy.clone();
                                    let me_paz = me_pa.clone();
                                    let name_pqz = name_pq.clone();
                                    let port_pdz = port_pd.clone();
                                    let read_pjz = read_pj.clone();
                                    let reads_ptz = reads_pt.clone();
                                    let t_pfz = t_pf.clone();
                                    let w1_prz = w1_pr.clone();
                                    let y_pbz = y_pb.clone();
                                    let k_let74391 = move |v74391: crate::prelude::Array<crate::lower::model::Do>| {
                                        let captured_pl = v74391;
                                        let made_pm = crate::lower::model::Ex::XBlock(captured_pl.clone(), ::std::rc::Rc::new(crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("prism_rtl::Dynamic::of")), crate::prelude::Array::from(vec![read_pjz.clone(), crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XVar(port_pdz.clone())))]))));
                                        let w2_pn = {
                                            let mut this: crate::lower::node_::Wx = w1_prz.clone();
                                            this.taken_p = crate::prelude::append(&this.taken_p, &crate::prelude::Array::from(vec![port_pdz.clone(), dyn_pez.clone()]));
                                            this.getters_p = crate::prelude::push(&this.getters_p, &crate::lower::model::MethDef { name_p: name_pqz.clone(), recv_p: crate::lower::model::Recv::RecvRef, params_p: crate::prelude::Array::new(), cx_p: crate::lower::model::CxArg::CxRef, ret_p: t_pfz.clone(), body_p: crate::prelude::Array::new(), tail_p: ex_psz.clone(), doc_p: crate::prelude::Text::from(format!("`{}` passed whole to a function, read at the read point (gap LF).", &crate::lower::functions::src_text_f(&lx_p5xyz, &lx_p5xyz.file_p, &y_pbz.span_p))) });
                                            this.lets_p = crate::prelude::append(&this.lets_p, &crate::prelude::Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaBind(port_pdz.clone())), crate::lower::model::OutTy::OutRc(::std::rc::Rc::new(crate::lower::model::OutTy::OutPort(::std::rc::Rc::new(crate::lower::model::OutTy::OutUnit))))), crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Rc::new")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Port::new")), crate::prelude::Array::new())]))), crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaBind(dyn_pez.clone())), crate::lower::model::OutTy::OutDyn(::std::rc::Rc::new(t_pfz.clone()))), made_pm.clone())]));
                                            this.fields_p = crate::prelude::append(&this.fields_p, &crate::prelude::Array::from(vec![(port_pdz.clone(), crate::lower::model::OutTy::OutRc(::std::rc::Rc::new(crate::lower::model::OutTy::OutPort(::std::rc::Rc::new(crate::lower::model::OutTy::OutUnit)))), crate::prelude::Text::from(format!("`{}` moved: its dynamic\'s update event", &name_pqz))), (dyn_pez.clone(), crate::lower::model::OutTy::OutDyn(::std::rc::Rc::new(t_pfz.clone())), crate::prelude::Text::from(format!("`{}` as the live dynamic a function takes whole", &crate::lower::functions::src_text_f(&lx_p5xyz, &lx_p5xyz.file_p, &y_pbz.span_p))))]));
                                            this.moves_p = crate::prelude::append(&this.moves_p, &crate::prelude::Array::from(vec![(port_pdz.clone(), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(port_pdz.clone())))), (dyn_pez.clone(), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(dyn_pez.clone()))))]));
                                            this.dyn_answers_p = crate::prelude::push(&this.dyn_answers_p, &(name_pqz.clone(), reads_ptz.clone()));
                                            this
                                        };
                                        let w3_po = once_field_f(&w2_pn, &name_pqz);
                                        let wkey_pp = crate::prelude::Text::from(format!("#whole{}", &dyn_key_f(&y_pbz)));
                                        ::prism_rtl::Turn::Finished((w3_po.clone(), crate::lower::types::bind_f(&be_p9z, &wkey_pp, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(dyn_pez.clone()), crate::lower::types::Holding::Owned, crate::lower::model::OutTy::OutDyn(::std::rc::Rc::new(t_pfz.clone())))), crate::lower::types::bind_f(&me_paz, &wkey_pp, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), dyn_pez.clone()), crate::lower::types::Holding::Owned, crate::lower::model::OutTy::OutDyn(::std::rc::Rc::new(t_pfz.clone()))))))
                                    };
                                    if valued_pg {
                                        crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p5xy.clone(), crate::lower::node_::def::init_env_f(&be_p9), y_pb.clone()), move |value_of_f_74464: crate::lower::types::Vl| k_let74391(crate::prelude::push(&linked_pk, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("at_build")), crate::lower::types::own_f(&value_of_f_74464)))))
                                    } else {
                                        k_let74391(linked_pk.clone())
                                    }
                                })
                            })
                        }
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::syntax::Expr)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>>>
            }))
        }
    }
}

/// ```prism
/// ElementValuesIn: unbounded fn Lx, Expr -> [Text]
/// ```
pub fn element_values_in_f(lx_p0: &crate::lower::Lx, e_p1: &crate::syntax::Expr) -> crate::prelude::Array<crate::prelude::Text> {
    let spots_p2 = crate::prelude::fold(&crate::check::typed::print::exprs_in_f(e_p1), &crate::prelude::Array::new(), &(|acc_p3: &crate::prelude::Array<crate::prelude::Text>, x_p4: &crate::syntax::Expr| match &*x_p4.kind_p {
        crate::syntax::ExprKind::ECall(c_p5, args_p6, _, _) => if &crate::lower::node_::dynamics::callee_key_f(lx_p0, &**c_p5) == &crate::prelude::Text::lit("Prelude.@Element") {
            acc_p3.clone()
        } else {
            crate::prelude::fold(args_p6, acc_p3, &(|acc2_p7: &crate::prelude::Array<crate::prelude::Text>, a_p8: &crate::syntax::Arg| crate::prelude::push(acc2_p7, &dyn_key_f(&ungrouped_f(&a_p8.value_p)))))
        },
        crate::syntax::ExprKind::ETuple(xs_p9) => crate::prelude::fold(xs_p9, acc_p3, &(|acc2_pa: &crate::prelude::Array<crate::prelude::Text>, part_pb: &crate::syntax::Expr| crate::prelude::push(acc2_pa, &dyn_key_f(&ungrouped_f(part_pb))))),
        crate::syntax::ExprKind::EArray(xs_pc) => crate::prelude::fold(xs_pc, acc_p3, &(|acc2_pd: &crate::prelude::Array<crate::prelude::Text>, part_pe: &crate::syntax::Expr| crate::prelude::push(acc2_pd, &dyn_key_f(&ungrouped_f(part_pe))))),
        crate::syntax::ExprKind::EFreeSigil(m76248_3_0, operand_pf) if (m76248_3_0 == &crate::prelude::Text::lit("?")) => crate::prelude::push(acc_p3, &dyn_key_f(&ungrouped_f(&**operand_pf))),
        _ => acc_p3.clone(),
        _ => unreachable!("no arm matched"),
    }));
    crate::prelude::fold(&crate::check::typed::print::exprs_in_f(e_p1), &crate::prelude::Array::new(), &(|acc_pg: &crate::prelude::Array<crate::prelude::Text>, x_ph: &crate::syntax::Expr| match &*x_ph.kind_p {
        crate::syntax::ExprKind::ECall(c_pi, _, _, _) => if crate::check::env::has_key_f(&lx_p0.g_p.tags_p, &crate::lower::node_::elements::tag_name_of_f(lx_p0, &**c_pi)) && crate::check::types::has_text_f(&spots_p2, &dyn_key_f(x_ph)) {
            crate::prelude::push(acc_pg, &dyn_key_f(x_ph))
        } else {
            acc_pg.clone()
        },
        _ => acc_pg.clone(),
    }))
}

/// ```prism
/// WidgetResultOf: fn Ty -> Ty
/// ```
pub fn widget_result_of_f(t_p0: &crate::check::types::Ty) -> crate::check::types::Ty {
    match t_p0 {
        crate::check::types::Ty::TyFn(_, _, r_p1) => (**r_p1).clone(),
        _ => t_p0.clone(),
    }
}

/// ```prism
/// LocalFunctionExprs: unbounded fn Env, [Expr], [Nat], [Expr], [Text] -> (([Expr], [Text]))
/// ```
pub fn local_function_exprs_f(menv_p0: &crate::lower::types::Env, exprs_p1: &crate::prelude::Array<crate::syntax::Expr>, seen_p2: &crate::prelude::Array<crate::prelude::Nat>, found_p3: &crate::prelude::Array<crate::syntax::Expr>, results_p4: &crate::prelude::Array<crate::prelude::Text>) -> (crate::prelude::Array<crate::syntax::Expr>, crate::prelude::Array<crate::prelude::Text>) {
    let (clauses_pd, seen_now_pe) = crate::prelude::fold(exprs_p1, &(crate::prelude::Array::new(), seen_p2.clone()), &(|(acc_p5, known_p6): &(crate::prelude::Array<crate::syntax::decls::FnClause>, crate::prelude::Array<crate::prelude::Nat>), x_p7: &crate::syntax::Expr| match &*x_p7.kind_p {
        crate::syntax::ExprKind::EName(n_p8) => match if &crate::prelude::len(&n_p8.path_p) == &crate::prelude::Nat::from(1u32) {
            crate::prelude::get(&menv_p0.names_p, &crate::check::env::sname_key_f(n_p8))
        } else {
            ::std::option::Option::None
        } {
            ::std::option::Option::Some(crate::lower::types::Bn::BnLocalFn(cs_p9)) => crate::prelude::fold(&cs_p9, &(acc_p5.clone(), known_p6.clone()), &(|(acc2_pa, known2_pb): &(crate::prelude::Array<crate::syntax::decls::FnClause>, crate::prelude::Array<crate::prelude::Nat>), c_pc: &crate::syntax::decls::FnClause| if crate::check::types::has_nat_f(known2_pb, &c_pc.span_p.start_p) {
                (acc2_pa.clone(), known2_pb.clone())
            } else {
                (crate::prelude::push(acc2_pa, c_pc), crate::prelude::push(known2_pb, &c_pc.span_p.start_p))
            })),
            _ => (acc_p5.clone(), known_p6.clone()),
        },
        _ => (acc_p5.clone(), known_p6.clone()),
    }));
    if &crate::prelude::len(&clauses_pd) == &crate::prelude::Nat::from(0u32) {
        (found_p3.clone(), results_p4.clone())
    } else {
        {
            let more_pf = crate::prelude::run_to_end(crate::prelude::fold_job(clauses_pd.clone(), crate::prelude::Array::new(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::syntax::Expr>, crate::syntax::decls::FnClause)| crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_ph = p0;
                let c_pi = p1;
                ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_ph, &crate::lower::node_::switch_::clause_exprs_f(&c_pi)))
            }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::syntax::Expr>, crate::syntax::decls::FnClause)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::syntax::Expr>>>>));
            let handed_back_pg = crate::prelude::fold(&clauses_pd, results_p4, &(|acc_pj: &crate::prelude::Array<crate::prelude::Text>, c_pk: &crate::syntax::decls::FnClause| match &c_pk.body_p {
                crate::syntax::decls::FnBody::BodyExpr(x_pl) => crate::prelude::push(acc_pj, &dyn_key_f(&ungrouped_f(x_pl))),
                crate::syntax::decls::FnBody::BodyBlock(b_pm) => match &crate::prelude::or(&crate::prelude::index(&b_pm.stmts_p, &crate::syntax::lexer::chars::dec_f(&crate::prelude::len(&b_pm.stmts_p))), &crate::lower::expr::dummy_stmt_l_p()).kind_p {
                    crate::syntax::StmtKind::SExpr(x_pn) => crate::prelude::push(acc_pj, &dyn_key_f(&ungrouped_f(x_pn))),
                    _ => acc_pj.clone(),
                },
            }));
            local_function_exprs_f(menv_p0, &more_pf, &seen_now_pe, &crate::prelude::append(found_p3, &more_pf), &handed_back_pg)
        }
    }
}

/// The step machine of `LocalFunctionExprs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LocalFunctionExprs: unbounded fn Env, [Expr], [Nat], [Expr], [Text] -> (([Expr], [Text]))
/// ```
pub struct LocalFunctionExprs {
    pub menv_p0: crate::lower::types::Env,
    pub exprs_p1: crate::prelude::Array<crate::syntax::Expr>,
    pub seen_p2: crate::prelude::Array<crate::prelude::Nat>,
    pub found_p3: crate::prelude::Array<crate::syntax::Expr>,
    pub results_p4: crate::prelude::Array<crate::prelude::Text>,
}

impl ::prism_rtl::Job<(crate::prelude::Array<crate::syntax::Expr>, crate::prelude::Array<crate::prelude::Text>)> for LocalFunctionExprs {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::prelude::Array<crate::syntax::Expr>, crate::prelude::Array<crate::prelude::Text>)> {
        let menv_p0 = &self.menv_p0;
        let exprs_p1 = &self.exprs_p1;
        let seen_p2 = &self.seen_p2;
        let found_p3 = &self.found_p3;
        let results_p4 = &self.results_p4;
        let (clauses_pd, seen_now_pe) = crate::prelude::fold(exprs_p1, &(crate::prelude::Array::new(), seen_p2.clone()), &(|(acc_p5, known_p6): &(crate::prelude::Array<crate::syntax::decls::FnClause>, crate::prelude::Array<crate::prelude::Nat>), x_p7: &crate::syntax::Expr| match &*x_p7.kind_p {
            crate::syntax::ExprKind::EName(n_p8) => match if &crate::prelude::len(&n_p8.path_p) == &crate::prelude::Nat::from(1u32) {
                crate::prelude::get(&menv_p0.names_p, &crate::check::env::sname_key_f(n_p8))
            } else {
                ::std::option::Option::None
            } {
                ::std::option::Option::Some(crate::lower::types::Bn::BnLocalFn(cs_p9)) => crate::prelude::fold(&cs_p9, &(acc_p5.clone(), known_p6.clone()), &(|(acc2_pa, known2_pb): &(crate::prelude::Array<crate::syntax::decls::FnClause>, crate::prelude::Array<crate::prelude::Nat>), c_pc: &crate::syntax::decls::FnClause| if crate::check::types::has_nat_f(known2_pb, &c_pc.span_p.start_p) {
                    (acc2_pa.clone(), known2_pb.clone())
                } else {
                    (crate::prelude::push(acc2_pa, c_pc), crate::prelude::push(known2_pb, &c_pc.span_p.start_p))
                })),
                _ => (acc_p5.clone(), known_p6.clone()),
            },
            _ => (acc_p5.clone(), known_p6.clone()),
        }));
        if &crate::prelude::len(&clauses_pd) == &crate::prelude::Nat::from(0u32) {
            ::prism_rtl::Turn::Finished((found_p3.clone(), results_p4.clone()))
        } else {
            {
                let found_p3x = found_p3.clone();
                let menv_p0x = menv_p0.clone();
                let results_p4x = results_p4.clone();
                crate::prelude::call_value(crate::prelude::fold_job(clauses_pd.clone(), crate::prelude::Array::new(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::syntax::Expr>, crate::syntax::decls::FnClause)| crate::prelude::entered(crate::prelude::once_job(move || {
                    let acc_ph = p0;
                    let c_pi = p1;
                    ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_ph, &crate::lower::node_::switch_::clause_exprs_f(&c_pi)))
                }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::syntax::Expr>, crate::syntax::decls::FnClause)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::syntax::Expr>>>>), move |fold_78850: crate::prelude::Array<crate::syntax::Expr>| {
                    let more_pf = fold_78850;
                    let handed_back_pg = crate::prelude::fold(&clauses_pd, &results_p4x, &(|acc_pj: &crate::prelude::Array<crate::prelude::Text>, c_pk: &crate::syntax::decls::FnClause| match &c_pk.body_p {
                        crate::syntax::decls::FnBody::BodyExpr(x_pl) => crate::prelude::push(acc_pj, &dyn_key_f(&ungrouped_f(x_pl))),
                        crate::syntax::decls::FnBody::BodyBlock(b_pm) => match &crate::prelude::or(&crate::prelude::index(&b_pm.stmts_p, &crate::syntax::lexer::chars::dec_f(&crate::prelude::len(&b_pm.stmts_p))), &crate::lower::expr::dummy_stmt_l_p()).kind_p {
                            crate::syntax::StmtKind::SExpr(x_pn) => crate::prelude::push(acc_pj, &dyn_key_f(&ungrouped_f(x_pn))),
                            _ => acc_pj.clone(),
                        },
                    }));
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(LocalFunctionExprs { menv_p0: menv_p0x.clone(), exprs_p1: more_pf.clone(), seen_p2: seen_now_pe.clone(), found_p3: crate::prelude::append(&found_p3x, &more_pf), results_p4: handed_back_pg.clone() }))
                })
            }
        }
    }
}

/// `Start LocalFunctionExprs, x`: what the function value is when passed to `@Run`.
pub fn start_local_function_exprs_f(menv_p0: crate::lower::types::Env, exprs_p1: crate::prelude::Array<crate::syntax::Expr>, seen_p2: crate::prelude::Array<crate::prelude::Nat>, found_p3: crate::prelude::Array<crate::syntax::Expr>, results_p4: crate::prelude::Array<crate::prelude::Text>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<crate::syntax::Expr>, crate::prelude::Array<crate::prelude::Text>)>> {
    ::std::rc::Rc::new(LocalFunctionExprs { menv_p0, exprs_p1, seen_p2, found_p3, results_p4 })
}

/// ```prism
/// BlueprintValuesAt: unbounded fn Wx, Env, Env, Expr, Bool -> ((Wx, Env, Env))
/// ```
pub fn blueprint_values_at_f(wx_p0: &crate::lower::node_::Wx, benv_p1: &crate::lower::types::Env, menv_p2: &crate::lower::types::Env, e_p3: &crate::syntax::Expr, named_p4: &bool) -> (crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env) {
    let lx_p5 = wx_p0.lx_p.clone();
    let (in_functions_pb, results_pc) = local_function_exprs_f(menv_p2, &crate::check::typed::print::exprs_in_f(e_p3), &crate::prelude::Array::new(), &crate::prelude::Array::new(), &crate::prelude::Array::new());
    let reached_p6 = crate::prelude::append(&crate::check::typed::print::exprs_in_f(e_p3), &in_functions_pb);
    let calls_p7 = crate::prelude::filter(&reached_p6, &(|x_pd: &crate::syntax::Expr| match &*x_pd.kind_p {
        crate::syntax::ExprKind::ECall(c_pe, _, _, _) => {
            let named_pf = match crate::prelude::get(&lx_p5.g_p.vals_p, &crate::lower::node_::dynamics::callee_key_f(&lx_p5, &**c_pe)) {
                ::std::option::Option::Some(v_ph) => crate::lower::node_::def::is_widget_ty_f(&widget_result_of_f(&v_ph.scheme_p.ty_p)),
                ::std::option::Option::None => false,
            };
            let local_pg = match &*c_pe.kind_p {
                crate::syntax::ExprKind::EName(n_pi) => match if &crate::prelude::len(&n_pi.path_p) == &crate::prelude::Nat::from(1u32) {
                    crate::prelude::get(&menv_p2.names_p, &crate::check::env::sname_key_f(n_pi))
                } else {
                    ::std::option::Option::None
                } {
                    ::std::option::Option::Some(crate::lower::types::Bn::BnWidget(_, _, _, _)) => true,
                    ::std::option::Option::Some(crate::lower::types::Bn::BnLocalWidget(_)) => true,
                    _ => false,
                },
                _ => false,
            };
            named_pf || local_pg
        },
        _ => false,
    }));
    let applied_p8 = crate::prelude::each(&calls_p7, &(|x_pj: &crate::syntax::Expr| dyn_key_f(x_pj)));
    let spots_p9 = crate::prelude::fold(&reached_p6, &(if *named_p4 {
        crate::prelude::push(&results_pc, &dyn_key_f(&ungrouped_f(e_p3)))
    } else {
        results_pc.clone()
    }), &(|acc_pk: &crate::prelude::Array<crate::prelude::Text>, x_pl: &crate::syntax::Expr| match &*x_pl.kind_p {
        crate::syntax::ExprKind::ECall(_, args_pm, _, _) => if crate::check::types::has_text_f(&applied_p8, &dyn_key_f(x_pl)) {
            acc_pk.clone()
        } else {
            crate::prelude::fold(args_pm, acc_pk, &(|acc2_pn: &crate::prelude::Array<crate::prelude::Text>, a_po: &crate::syntax::Arg| crate::prelude::push(acc2_pn, &dyn_key_f(&ungrouped_f(&a_po.value_p)))))
        },
        crate::syntax::ExprKind::ETuple(xs_pp) => crate::prelude::fold(xs_pp, acc_pk, &(|acc2_pq: &crate::prelude::Array<crate::prelude::Text>, part_pr: &crate::syntax::Expr| crate::prelude::push(acc2_pq, &dyn_key_f(&ungrouped_f(part_pr))))),
        crate::syntax::ExprKind::EArray(xs_ps) => crate::prelude::fold(xs_ps, acc_pk, &(|acc2_pt: &crate::prelude::Array<crate::prelude::Text>, part_pu: &crate::syntax::Expr| crate::prelude::push(acc2_pt, &dyn_key_f(&ungrouped_f(part_pu))))),
        crate::syntax::ExprKind::EFreeSigil(m80960_3_0, operand_pv) if (m80960_3_0 == &crate::prelude::Text::lit("?")) => crate::prelude::push(acc_pk, &dyn_key_f(&ungrouped_f(&**operand_pv))),
        _ => acc_pk.clone(),
        _ => unreachable!("no arm matched"),
    }));
    let names_pa = crate::prelude::fold(&reached_p6, &crate::prelude::Array::new(), &(|acc_p10: &crate::prelude::Array<(crate::syntax::Expr, crate::prelude::Text, crate::syntax::Block)>, y_p11: &crate::syntax::Expr| match &*y_p11.kind_p {
        crate::syntax::ExprKind::EName(n_p12) => match if &crate::prelude::len(&n_p12.path_p) == &crate::prelude::Nat::from(1u32) {
            crate::prelude::get(&menv_p2.names_p, &crate::check::env::sname_key_f(n_p12))
        } else {
            ::std::option::Option::None
        } {
            ::std::option::Option::Some(crate::lower::types::Bn::BnLocalWidget(b_p13)) => if !crate::check::types::has_text_f(&spots_p9, &dyn_key_f(y_p11)) || crate::check::env::has_key_f(&menv_p2.names_p, &crate::prelude::Text::from(format!("#whole@{}", &dyn_key_f(y_p11)))) {
                acc_p10.clone()
            } else {
                crate::prelude::push(acc_p10, &(y_p11.clone(), crate::check::env::sname_key_f(n_p12), b_p13))
            },
            _ => acc_p10.clone(),
        },
        _ => acc_p10.clone(),
    }));
    crate::prelude::run_to_end(crate::prelude::fold_job(names_pa.clone(), (wx_p0.clone(), benv_p1.clone(), menv_p2.clone()), {
        let lx_p5x = lx_p5.clone();
        ::std::rc::Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), (crate::syntax::Expr, crate::prelude::Text, crate::syntax::Block))| {
            let lx_p5xy = lx_p5x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (w_p14, be_p15, me_p16) = p0;
                let (y_p17, nkey_p18, b_p19) = p1;
                match (crate::prelude::get(&be_p15.names_p, &crate::prelude::Text::from(format!("#whole@widget:{}", &nkey_p18))), crate::prelude::get(&me_p16.names_p, &crate::prelude::Text::from(format!("#whole@widget:{}", &nkey_p18)))) {
                    (::std::option::Option::Some(at_build_p1a), ::std::option::Option::Some(in_method_p1b)) => ::prism_rtl::Turn::Finished((w_p14.clone(), crate::lower::types::bind_f(&be_p15, &crate::prelude::Text::from(format!("#whole@{}", &dyn_key_f(&y_p17))), &at_build_p1a), crate::lower::types::bind_f(&me_p16, &crate::prelude::Text::from(format!("#whole@{}", &dyn_key_f(&y_p17))), &in_method_p1b))),
                    _ => {
                        let owner_p1c = crate::prelude::Text::lit("whole_owner");
                        let w0_p1d = if crate::check::types::has_text_f(&w_p14.taken_p, &owner_p1c) {
                            w_p14.clone()
                        } else {
                            {
                                let mut this: crate::lower::node_::Wx = w_p14.clone();
                                this.taken_p = crate::prelude::push(&this.taken_p, &owner_p1c);
                                this.lets_p = crate::prelude::push(&this.lets_p, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(owner_p1c.clone()), crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::from(format!("prism_rtl::Link::<{}>::new", &w_p14.node_p))), crate::prelude::Array::new())));
                                this.build_p = crate::prelude::push(&this.build_p, &crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XVar(owner_p1c.clone())), crate::prelude::Text::lit("link"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("node"))))]))));
                                this
                            }
                        };
                        let (f_p1r, w1_p1s) = crate::lower::node_::fresh_name_f(&w0_p1d, &crate::prelude::Text::from(format!("blueprint_{}", &crate::lower::snake_f(&nkey_p18))));
                        crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p5xy.clone(), crate::lower::types::out_of_f(&crate::lower::type_at_f(&lx_p5xy, &y_p17.span_p))), move |out_ty_of_f_82588: crate::lower::model::OutTy| {
                            let gives_p1e = out_ty_of_f_82588;
                            let inner_p1f = match crate::lower::type_at_f(&lx_p5xy, &y_p17.span_p) {
                                crate::check::types::Ty::TyAt(i_p1t, _) => (*i_p1t).clone(),
                                other_p1u => other_p1u,
                            };
                            let fires_p1g = &crate::lower::types::layer_of_f(&inner_p1f) == &crate::lower::types::Layer::LyEv;
                            let live_p1h = &crate::lower::types::layer_of_f(&inner_p1f) == &crate::lower::types::Layer::LyDyn;
                            let b_p19z = b_p19.clone();
                            let be_p15z = be_p15.clone();
                            let f_p1rz = f_p1r.clone();
                            let fires_p1gz = fires_p1g;
                            let gives_p1ez = gives_p1e.clone();
                            let me_p16z = me_p16.clone();
                            let nkey_p18z = nkey_p18.clone();
                            let owner_p1cz = owner_p1c.clone();
                            let w1_p1sz = w1_p1s.clone();
                            let y_p17z = y_p17.clone();
                            let k_let83263 = move |v83263: bool| {
                                let held_whole_p1i = v83263;
                                let taken_p1j = if &gives_p1ez == &crate::lower::model::OutTy::OutUnit {
                                    crate::prelude::Text::lit("")
                                } else {
                                    if fires_p1gz {
                                        crate::prelude::Text::lit("result_event")
                                    } else {
                                        crate::prelude::Text::lit("result_value")
                                    }
                                };
                                crate::prelude::call_then(start_value_row_of_f(w1_p1sz.clone(), me_p16z.clone(), b_p19z.clone(), f_p1rz.clone(), false, taken_p1j.clone()), move |value_row_of_f_83503: (crate::lower::node_::Wx, crate::lower::model::Ex)| {
                                    let (w2_p1v, world_p20) = value_row_of_f_83503;
                                    crate::prelude::call_then(start_value_row_of_f(w2_p1v.clone(), me_p16z.clone(), b_p19z.clone(), f_p1rz.clone(), true, taken_p1j.clone()), move |value_row_of_f_83574: (crate::lower::node_::Wx, crate::lower::model::Ex)| {
                                        let (w3_p21, hosted_p22) = value_row_of_f_83574;
                                        let answer_p1k = if &gives_p1ez == &crate::lower::model::OutTy::OutUnit {
                                            crate::lower::model::Ex::XClosure(false, crate::prelude::Array::from(vec![crate::lower::model::Pa::PaWild]), ::std::rc::Rc::new(crate::lower::model::Ex::XNone))
                                        } else {
                                            if held_whole_p1i {
                                                crate::lower::model::Ex::XClosure(false, crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("widget_result"))]), ::std::rc::Rc::new(crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Some")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCall(crate::lower::helper_ref_f(&crate::prelude::Text::lit("answer_held")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XVar(crate::prelude::Text::lit("widget_result"))]))]))))
                                            } else {
                                                crate::lower::model::Ex::XClosure(false, crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("widget_result"))]), ::std::rc::Rc::new(crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Some")), crate::prelude::Array::from(vec![crate::lower::expr::tagged_f(&crate::lower::model::untagged_ref_p(), &crate::lower::model::Ex::XVar(crate::prelude::Text::lit("widget_result")))]))))
                                            }
                                        };
                                        crate::prelude::call_then(crate::lower::expr::start_tagged_or_held_f(crate::lower::model::untagged_ref_p(), gives_p1ez.clone(), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("widget_result"))))), move |tagged_or_held_f_84085: crate::lower::model::Ex| {
                                            let fired_p1l = crate::lower::model::Ex::XClosure(false, crate::prelude::Array::from(vec![crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("widget_result"))), crate::lower::model::OutTy::OutRef(::std::rc::Rc::new(gives_p1ez.clone())))]), ::std::rc::Rc::new(tagged_or_held_f_84085));
                                            let held_p1m = crate::prelude::Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("link")), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(owner_p1cz.clone())))), crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("hosted_link")), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(owner_p1cz.clone())))), crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("rows")), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::from(format!("{}_rows", &f_p1rz)))))), crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("hosted_rows")), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::from(format!("{}_hosted_rows", &f_p1rz))))))]);
                                            let value_p1n = if fires_p1gz {
                                                crate::lower::model::Ex::XBlock(held_p1m.clone(), ::std::rc::Rc::new(crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("prism_rtl::widget_event_blueprint::<crate::Elem, crate::Answer, _>")), crate::prelude::Array::from(vec![world_p20.clone(), hosted_p22.clone(), fired_p1l.clone()]))))
                                            } else {
                                                crate::lower::model::Ex::XBlock(held_p1m.clone(), ::std::rc::Rc::new(crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("prism_rtl::widget_blueprint::<crate::Elem, crate::Answer, _>")), crate::prelude::Array::from(vec![world_p20.clone(), hosted_p22.clone(), answer_p1k.clone()]))))
                                            };
                                            let w4_p1o = {
                                                let mut this: crate::lower::node_::Wx = w3_p21.clone();
                                                this.lets_p = crate::prelude::push(&this.lets_p, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaBind(f_p1rz.clone())), crate::lower::types::blueprint_ty_p()), value_p1n.clone()));
                                                this.fields_p = crate::prelude::push(&this.fields_p, &(f_p1rz.clone(), crate::lower::types::blueprint_ty_p(), crate::prelude::Text::from(format!("the widget `{}` of the block as a blueprint value", &nkey_p18z))));
                                                this.moves_p = crate::prelude::push(&this.moves_p, &(f_p1rz.clone(), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(f_p1rz.clone())))));
                                                this
                                            };
                                            let at_build_p1p = crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(f_p1rz.clone()), crate::lower::types::Holding::Owned, crate::lower::types::blueprint_ty_p());
                                            let in_method_p1q = crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), f_p1rz.clone()), crate::lower::types::Holding::Owned, crate::lower::types::blueprint_ty_p());
                                            ::prism_rtl::Turn::Finished((w4_p1o.clone(), crate::lower::types::bind_f(&crate::lower::types::bind_f(&be_p15z, &crate::prelude::Text::from(format!("#whole@widget:{}", &nkey_p18z)), &at_build_p1p), &crate::prelude::Text::from(format!("#whole@{}", &dyn_key_f(&y_p17z))), &at_build_p1p), crate::lower::types::bind_f(&crate::lower::types::bind_f(&me_p16z, &crate::prelude::Text::from(format!("#whole@widget:{}", &nkey_p18z)), &in_method_p1q), &crate::prelude::Text::from(format!("#whole@{}", &dyn_key_f(&y_p17z))), &in_method_p1q)))
                                        })
                                    })
                                })
                            };
                            if (&gives_p1e != &crate::lower::model::OutTy::OutUnit) && !fires_p1g {
                                if live_p1h || crate::lower::types::is_bundle_f(&crate::lower::types::peel_f(&inner_p1f)) {
                                    k_let83263(true)
                                } else {
                                    crate::prelude::call_then(crate::lower::types::start_podable_f(gives_p1e.clone()), move |podable_f_83355: bool| k_let83263(!podable_f_83355))
                                }
                            } else {
                                k_let83263(false)
                            }
                        })
                    },
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), (crate::syntax::Expr, crate::prelude::Text, crate::syntax::Block))) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>>>
    }))
}

/// The step machine of `BlueprintValuesAt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BlueprintValuesAt: unbounded fn Wx, Env, Env, Expr, Bool -> ((Wx, Env, Env))
/// ```
pub struct BlueprintValuesAt {
    pub wx_p0: crate::lower::node_::Wx,
    pub benv_p1: crate::lower::types::Env,
    pub menv_p2: crate::lower::types::Env,
    pub e_p3: crate::syntax::Expr,
    pub named_p4: bool,
}

impl ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)> for BlueprintValuesAt {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)> {
        let wx_p0 = &self.wx_p0;
        let benv_p1 = &self.benv_p1;
        let menv_p2 = &self.menv_p2;
        let e_p3 = &self.e_p3;
        let named_p4 = &self.named_p4;
        let lx_p5 = wx_p0.lx_p.clone();
        let benv_p1x = benv_p1.clone();
        let e_p3x = e_p3.clone();
        let menv_p2x = menv_p2.clone();
        let named_p4x = *named_p4;
        let wx_p0x = wx_p0.clone();
        crate::prelude::call_then(crate::check::typed::print::start_exprs_in_f(e_p3x.clone()), move |exprs_in_f_79823: crate::prelude::Array<crate::syntax::Expr>| crate::prelude::call_then(start_local_function_exprs_f(menv_p2x.clone(), exprs_in_f_79823, crate::prelude::Array::new(), crate::prelude::Array::new(), crate::prelude::Array::new()), move |local_function_exprs_f_79797: (crate::prelude::Array<crate::syntax::Expr>, crate::prelude::Array<crate::prelude::Text>)| {
            let (in_functions_pb, results_pc) = local_function_exprs_f_79797;
            crate::prelude::call_then(crate::check::typed::print::start_exprs_in_f(e_p3x.clone()), move |exprs_in_f_79878: crate::prelude::Array<crate::syntax::Expr>| {
                let reached_p6 = crate::prelude::append(&exprs_in_f_79878, &in_functions_pb);
                let calls_p7 = crate::prelude::filter(&reached_p6, &(|x_pd: &crate::syntax::Expr| match &*x_pd.kind_p {
                    crate::syntax::ExprKind::ECall(c_pe, _, _, _) => {
                        let named_pf = match crate::prelude::get(&lx_p5.g_p.vals_p, &crate::lower::node_::dynamics::callee_key_f(&lx_p5, &**c_pe)) {
                            ::std::option::Option::Some(v_ph) => crate::lower::node_::def::is_widget_ty_f(&widget_result_of_f(&v_ph.scheme_p.ty_p)),
                            ::std::option::Option::None => false,
                        };
                        let local_pg = match &*c_pe.kind_p {
                            crate::syntax::ExprKind::EName(n_pi) => match if &crate::prelude::len(&n_pi.path_p) == &crate::prelude::Nat::from(1u32) {
                                crate::prelude::get(&menv_p2x.names_p, &crate::check::env::sname_key_f(n_pi))
                            } else {
                                ::std::option::Option::None
                            } {
                                ::std::option::Option::Some(crate::lower::types::Bn::BnWidget(_, _, _, _)) => true,
                                ::std::option::Option::Some(crate::lower::types::Bn::BnLocalWidget(_)) => true,
                                _ => false,
                            },
                            _ => false,
                        };
                        named_pf || local_pg
                    },
                    _ => false,
                }));
                let applied_p8 = crate::prelude::each(&calls_p7, &(|x_pj: &crate::syntax::Expr| dyn_key_f(x_pj)));
                let spots_p9 = crate::prelude::fold(&reached_p6, &(if named_p4x {
                    crate::prelude::push(&results_pc, &dyn_key_f(&ungrouped_f(&e_p3x)))
                } else {
                    results_pc.clone()
                }), &(|acc_pk: &crate::prelude::Array<crate::prelude::Text>, x_pl: &crate::syntax::Expr| match &*x_pl.kind_p {
                    crate::syntax::ExprKind::ECall(_, args_pm, _, _) => if crate::check::types::has_text_f(&applied_p8, &dyn_key_f(x_pl)) {
                        acc_pk.clone()
                    } else {
                        crate::prelude::fold(args_pm, acc_pk, &(|acc2_pn: &crate::prelude::Array<crate::prelude::Text>, a_po: &crate::syntax::Arg| crate::prelude::push(acc2_pn, &dyn_key_f(&ungrouped_f(&a_po.value_p)))))
                    },
                    crate::syntax::ExprKind::ETuple(xs_pp) => crate::prelude::fold(xs_pp, acc_pk, &(|acc2_pq: &crate::prelude::Array<crate::prelude::Text>, part_pr: &crate::syntax::Expr| crate::prelude::push(acc2_pq, &dyn_key_f(&ungrouped_f(part_pr))))),
                    crate::syntax::ExprKind::EArray(xs_ps) => crate::prelude::fold(xs_ps, acc_pk, &(|acc2_pt: &crate::prelude::Array<crate::prelude::Text>, part_pu: &crate::syntax::Expr| crate::prelude::push(acc2_pt, &dyn_key_f(&ungrouped_f(part_pu))))),
                    crate::syntax::ExprKind::EFreeSigil(m80960_3_0, operand_pv) if (m80960_3_0 == &crate::prelude::Text::lit("?")) => crate::prelude::push(acc_pk, &dyn_key_f(&ungrouped_f(&**operand_pv))),
                    _ => acc_pk.clone(),
                    _ => unreachable!("no arm matched"),
                }));
                let names_pa = crate::prelude::fold(&reached_p6, &crate::prelude::Array::new(), &(|acc_p10: &crate::prelude::Array<(crate::syntax::Expr, crate::prelude::Text, crate::syntax::Block)>, y_p11: &crate::syntax::Expr| match &*y_p11.kind_p {
                    crate::syntax::ExprKind::EName(n_p12) => match if &crate::prelude::len(&n_p12.path_p) == &crate::prelude::Nat::from(1u32) {
                        crate::prelude::get(&menv_p2x.names_p, &crate::check::env::sname_key_f(n_p12))
                    } else {
                        ::std::option::Option::None
                    } {
                        ::std::option::Option::Some(crate::lower::types::Bn::BnLocalWidget(b_p13)) => if !crate::check::types::has_text_f(&spots_p9, &dyn_key_f(y_p11)) || crate::check::env::has_key_f(&menv_p2x.names_p, &crate::prelude::Text::from(format!("#whole@{}", &dyn_key_f(y_p11)))) {
                            acc_p10.clone()
                        } else {
                            crate::prelude::push(acc_p10, &(y_p11.clone(), crate::check::env::sname_key_f(n_p12), b_p13))
                        },
                        _ => acc_p10.clone(),
                    },
                    _ => acc_p10.clone(),
                }));
                crate::prelude::fold_job(names_pa.clone(), (wx_p0x.clone(), benv_p1x.clone(), menv_p2x.clone()), {
                    let lx_p5x = lx_p5.clone();
                    ::std::rc::Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), (crate::syntax::Expr, crate::prelude::Text, crate::syntax::Block))| {
                        let lx_p5xy = lx_p5x.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let (w_p14, be_p15, me_p16) = p0;
                            let (y_p17, nkey_p18, b_p19) = p1;
                            match (crate::prelude::get(&be_p15.names_p, &crate::prelude::Text::from(format!("#whole@widget:{}", &nkey_p18))), crate::prelude::get(&me_p16.names_p, &crate::prelude::Text::from(format!("#whole@widget:{}", &nkey_p18)))) {
                                (::std::option::Option::Some(at_build_p1a), ::std::option::Option::Some(in_method_p1b)) => ::prism_rtl::Turn::Finished((w_p14.clone(), crate::lower::types::bind_f(&be_p15, &crate::prelude::Text::from(format!("#whole@{}", &dyn_key_f(&y_p17))), &at_build_p1a), crate::lower::types::bind_f(&me_p16, &crate::prelude::Text::from(format!("#whole@{}", &dyn_key_f(&y_p17))), &in_method_p1b))),
                                _ => {
                                    let owner_p1c = crate::prelude::Text::lit("whole_owner");
                                    let w0_p1d = if crate::check::types::has_text_f(&w_p14.taken_p, &owner_p1c) {
                                        w_p14.clone()
                                    } else {
                                        {
                                            let mut this: crate::lower::node_::Wx = w_p14.clone();
                                            this.taken_p = crate::prelude::push(&this.taken_p, &owner_p1c);
                                            this.lets_p = crate::prelude::push(&this.lets_p, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(owner_p1c.clone()), crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::from(format!("prism_rtl::Link::<{}>::new", &w_p14.node_p))), crate::prelude::Array::new())));
                                            this.build_p = crate::prelude::push(&this.build_p, &crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XVar(owner_p1c.clone())), crate::prelude::Text::lit("link"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("node"))))]))));
                                            this
                                        }
                                    };
                                    let (f_p1r, w1_p1s) = crate::lower::node_::fresh_name_f(&w0_p1d, &crate::prelude::Text::from(format!("blueprint_{}", &crate::lower::snake_f(&nkey_p18))));
                                    crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p5xy.clone(), crate::lower::types::out_of_f(&crate::lower::type_at_f(&lx_p5xy, &y_p17.span_p))), move |out_ty_of_f_82588: crate::lower::model::OutTy| {
                                        let gives_p1e = out_ty_of_f_82588;
                                        let inner_p1f = match crate::lower::type_at_f(&lx_p5xy, &y_p17.span_p) {
                                            crate::check::types::Ty::TyAt(i_p1t, _) => (*i_p1t).clone(),
                                            other_p1u => other_p1u,
                                        };
                                        let fires_p1g = &crate::lower::types::layer_of_f(&inner_p1f) == &crate::lower::types::Layer::LyEv;
                                        let live_p1h = &crate::lower::types::layer_of_f(&inner_p1f) == &crate::lower::types::Layer::LyDyn;
                                        let b_p19z = b_p19.clone();
                                        let be_p15z = be_p15.clone();
                                        let f_p1rz = f_p1r.clone();
                                        let fires_p1gz = fires_p1g;
                                        let gives_p1ez = gives_p1e.clone();
                                        let me_p16z = me_p16.clone();
                                        let nkey_p18z = nkey_p18.clone();
                                        let owner_p1cz = owner_p1c.clone();
                                        let w1_p1sz = w1_p1s.clone();
                                        let y_p17z = y_p17.clone();
                                        let k_let83263 = move |v83263: bool| {
                                            let held_whole_p1i = v83263;
                                            let taken_p1j = if &gives_p1ez == &crate::lower::model::OutTy::OutUnit {
                                                crate::prelude::Text::lit("")
                                            } else {
                                                if fires_p1gz {
                                                    crate::prelude::Text::lit("result_event")
                                                } else {
                                                    crate::prelude::Text::lit("result_value")
                                                }
                                            };
                                            crate::prelude::call_then(start_value_row_of_f(w1_p1sz.clone(), me_p16z.clone(), b_p19z.clone(), f_p1rz.clone(), false, taken_p1j.clone()), move |value_row_of_f_83503: (crate::lower::node_::Wx, crate::lower::model::Ex)| {
                                                let (w2_p1v, world_p20) = value_row_of_f_83503;
                                                crate::prelude::call_then(start_value_row_of_f(w2_p1v.clone(), me_p16z.clone(), b_p19z.clone(), f_p1rz.clone(), true, taken_p1j.clone()), move |value_row_of_f_83574: (crate::lower::node_::Wx, crate::lower::model::Ex)| {
                                                    let (w3_p21, hosted_p22) = value_row_of_f_83574;
                                                    let answer_p1k = if &gives_p1ez == &crate::lower::model::OutTy::OutUnit {
                                                        crate::lower::model::Ex::XClosure(false, crate::prelude::Array::from(vec![crate::lower::model::Pa::PaWild]), ::std::rc::Rc::new(crate::lower::model::Ex::XNone))
                                                    } else {
                                                        if held_whole_p1i {
                                                            crate::lower::model::Ex::XClosure(false, crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("widget_result"))]), ::std::rc::Rc::new(crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Some")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCall(crate::lower::helper_ref_f(&crate::prelude::Text::lit("answer_held")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XVar(crate::prelude::Text::lit("widget_result"))]))]))))
                                                        } else {
                                                            crate::lower::model::Ex::XClosure(false, crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("widget_result"))]), ::std::rc::Rc::new(crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Some")), crate::prelude::Array::from(vec![crate::lower::expr::tagged_f(&crate::lower::model::untagged_ref_p(), &crate::lower::model::Ex::XVar(crate::prelude::Text::lit("widget_result")))]))))
                                                        }
                                                    };
                                                    crate::prelude::call_then(crate::lower::expr::start_tagged_or_held_f(crate::lower::model::untagged_ref_p(), gives_p1ez.clone(), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("widget_result"))))), move |tagged_or_held_f_84085: crate::lower::model::Ex| {
                                                        let fired_p1l = crate::lower::model::Ex::XClosure(false, crate::prelude::Array::from(vec![crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("widget_result"))), crate::lower::model::OutTy::OutRef(::std::rc::Rc::new(gives_p1ez.clone())))]), ::std::rc::Rc::new(tagged_or_held_f_84085));
                                                        let held_p1m = crate::prelude::Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("link")), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(owner_p1cz.clone())))), crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("hosted_link")), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(owner_p1cz.clone())))), crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("rows")), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::from(format!("{}_rows", &f_p1rz)))))), crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("hosted_rows")), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::from(format!("{}_hosted_rows", &f_p1rz))))))]);
                                                        let value_p1n = if fires_p1gz {
                                                            crate::lower::model::Ex::XBlock(held_p1m.clone(), ::std::rc::Rc::new(crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("prism_rtl::widget_event_blueprint::<crate::Elem, crate::Answer, _>")), crate::prelude::Array::from(vec![world_p20.clone(), hosted_p22.clone(), fired_p1l.clone()]))))
                                                        } else {
                                                            crate::lower::model::Ex::XBlock(held_p1m.clone(), ::std::rc::Rc::new(crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("prism_rtl::widget_blueprint::<crate::Elem, crate::Answer, _>")), crate::prelude::Array::from(vec![world_p20.clone(), hosted_p22.clone(), answer_p1k.clone()]))))
                                                        };
                                                        let w4_p1o = {
                                                            let mut this: crate::lower::node_::Wx = w3_p21.clone();
                                                            this.lets_p = crate::prelude::push(&this.lets_p, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaBind(f_p1rz.clone())), crate::lower::types::blueprint_ty_p()), value_p1n.clone()));
                                                            this.fields_p = crate::prelude::push(&this.fields_p, &(f_p1rz.clone(), crate::lower::types::blueprint_ty_p(), crate::prelude::Text::from(format!("the widget `{}` of the block as a blueprint value", &nkey_p18z))));
                                                            this.moves_p = crate::prelude::push(&this.moves_p, &(f_p1rz.clone(), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(f_p1rz.clone())))));
                                                            this
                                                        };
                                                        let at_build_p1p = crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(f_p1rz.clone()), crate::lower::types::Holding::Owned, crate::lower::types::blueprint_ty_p());
                                                        let in_method_p1q = crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), f_p1rz.clone()), crate::lower::types::Holding::Owned, crate::lower::types::blueprint_ty_p());
                                                        ::prism_rtl::Turn::Finished((w4_p1o.clone(), crate::lower::types::bind_f(&crate::lower::types::bind_f(&be_p15z, &crate::prelude::Text::from(format!("#whole@widget:{}", &nkey_p18z)), &at_build_p1p), &crate::prelude::Text::from(format!("#whole@{}", &dyn_key_f(&y_p17z))), &at_build_p1p), crate::lower::types::bind_f(&crate::lower::types::bind_f(&me_p16z, &crate::prelude::Text::from(format!("#whole@widget:{}", &nkey_p18z)), &in_method_p1q), &crate::prelude::Text::from(format!("#whole@{}", &dyn_key_f(&y_p17z))), &in_method_p1q)))
                                                    })
                                                })
                                            })
                                        };
                                        if (&gives_p1e != &crate::lower::model::OutTy::OutUnit) && !fires_p1g {
                                            if live_p1h || crate::lower::types::is_bundle_f(&crate::lower::types::peel_f(&inner_p1f)) {
                                                k_let83263(true)
                                            } else {
                                                crate::prelude::call_then(crate::lower::types::start_podable_f(gives_p1e.clone()), move |podable_f_83355: bool| k_let83263(!podable_f_83355))
                                            }
                                        } else {
                                            k_let83263(false)
                                        }
                                    })
                                },
                            }
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), (crate::syntax::Expr, crate::prelude::Text, crate::syntax::Block))) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>>>
                }).cycle()
            })
        }))
    }
}

/// `Start BlueprintValuesAt, x`: what the function value is when passed to `@Run`.
pub fn start_blueprint_values_at_f(wx_p0: crate::lower::node_::Wx, benv_p1: crate::lower::types::Env, menv_p2: crate::lower::types::Env, e_p3: crate::syntax::Expr, named_p4: bool) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>> {
    ::std::rc::Rc::new(BlueprintValuesAt { wx_p0, benv_p1, menv_p2, e_p3, named_p4 })
}

/// ```prism
/// ValueRowOf: unbounded fn Wx, Env, Block, Text, Bool, Text -> ((Wx, Ex))
/// ```
pub fn value_row_of_f(w_p0: &crate::lower::node_::Wx, me_p1: &crate::lower::types::Env, b_p2: &crate::syntax::Block, f_p3: &crate::prelude::Text, hosted_p4: &bool, taken_p5: &crate::prelude::Text) -> (crate::lower::node_::Wx, crate::lower::model::Ex) {
    let lx_p6 = w_p0.lx_p.clone();
    let gen_name_p7 = if *hosted_p4 {
        crate::prelude::Text::from(format!("{}_hosted", f_p3))
    } else {
        f_p3.clone()
    };
    let row_name_p8 = if *hosted_p4 {
        crate::prelude::Text::from(format!("{}HostedValue{}", &w_p0.node_p, &crate::lower::node_::keyed::row_suffix_f(w_p0)))
    } else {
        crate::prelude::Text::from(format!("{}Value{}", &w_p0.node_p, &crate::lower::node_::keyed::row_suffix_f(w_p0)))
    };
    let link_ty_p9 = crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("prism_rtl::Link")), crate::prelude::Array::from(vec![crate::lower::model::OutTy::OutNamed(crate::lower::site_ref_f(&lx_p6, &w_p0.node_p), crate::prelude::Array::new())]));
    let asked_pa = {
        let mut this: crate::lower::node_::Wx = w_p0.clone();
        this.valued_as_o = ::std::option::Option::Some(*hosted_p4);
        this
    };
    let cr_pb = crate::lower::node_::switch_::arm_row_of_f(&asked_pa, me_p1, &lx_p6, &crate::prelude::Array::new(), &crate::prelude::Array::new(), &::std::option::Option::None, b_p2, &row_name_p8, &gen_name_p7, &true, &true, &link_ty_p9, &crate::prelude::Array::new(), &crate::prelude::Array::new(), &crate::prelude::Array::new(), &true);
    let rows_pc = crate::prelude::Text::from(format!("{}_rows", &gen_name_p7));
    let rows_ty_pd = crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("prism_rtl::WeakRows")), crate::prelude::Array::from(vec![crate::lower::model::OutTy::OutNamed(crate::lower::site_ref_f(&lx_p6, &row_name_p8), crate::prelude::Array::new())]));
    let link_pe = if *hosted_p4 {
        crate::prelude::Text::lit("hosted_link")
    } else {
        crate::prelude::Text::lit("link")
    };
    let kept_pf = if *hosted_p4 {
        crate::prelude::Text::lit("hosted_rows")
    } else {
        crate::prelude::Text::lit("rows")
    };
    let tail_pg = if *hosted_p4 {
        crate::prelude::Array::from(vec![crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(link_pe.clone()))), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("enclosing")))), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("moved")))), crate::lower::model::Ex::XCx])
    } else {
        crate::prelude::Array::from(vec![crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(link_pe.clone()))), crate::lower::model::Ex::XCx])
    };
    let made_ph = crate::lower::expr::try_of_f(&crate::lower::model::Ex::XCall(crate::lower::model::ref_child_f(&crate::lower::site_ref_f(&lx_p6, &cr_pb.case_p.node_p.name_p), &crate::prelude::Text::lit("build")), crate::prelude::append(&crate::prelude::append(&crate::prelude::Array::from(vec![crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("path"))))]), &cr_pb.case_p.passed_p), &tail_pg)));
    let result_pi = if taken_p5 == &crate::prelude::Text::lit("") {
        crate::lower::model::Ex::XUnit
    } else {
        crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("row"))), taken_p5.clone(), crate::prelude::Array::new())
    };
    let built_pj = crate::lower::model::Ex::XBlock(crate::prelude::Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("row")), made_ph.clone()), crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XVar(kept_pf.clone())), crate::prelude::Text::lit("add"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("row"))))])))]), ::std::rc::Rc::new(crate::lower::model::Ex::XCall(crate::lower::helper_ref_f(&crate::prelude::Text::lit("built_widget")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("row"))), crate::prelude::Text::lit("built"), crate::prelude::Array::new()), result_pi.clone(), crate::lower::model::Ex::XVar(crate::prelude::Text::lit("row"))]))));
    let params_pk = if *hosted_p4 {
        crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("path")), crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("row_base")), crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("enclosing")), crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("moved")), crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("cx"))])
    } else {
        crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("path")), crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("row_base")), crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("cx"))])
    };
    let build_pl = crate::lower::model::Ex::XClosure(true, params_pk.clone(), ::std::rc::Rc::new(crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Ok")), crate::prelude::Array::from(vec![built_pj.clone()]))));
    let w2_pm = {
        let mut this: crate::lower::node_::Wx = cr_pb.parent_p.clone();
        this.valued_as_o = ::std::option::Option::None;
        this.rows_p = crate::prelude::append(&crate::prelude::push(&this.rows_p, &cr_pb.case_p.node_p), &cr_pb.case_p.node_p.children_p);
        this.taken_p = crate::prelude::push(&this.taken_p, &rows_pc);
        this.lets_p = crate::prelude::push(&this.lets_p, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaBind(rows_pc.clone())), rows_ty_pd.clone()), crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::from(format!("prism_rtl::WeakRows::<{}>::new", &row_name_p8))), crate::prelude::Array::new())));
        this.fields_p = crate::prelude::push(&this.fields_p, &(rows_pc.clone(), rows_ty_pd.clone(), crate::prelude::Text::lit("the rows the blueprint value of the block\'s widget built, held weakly")));
        this.moves_p = crate::prelude::push(&this.moves_p, &(rows_pc.clone(), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(rows_pc.clone())))));
        this.row_marks_p = crate::prelude::each(&this.row_marks_p, &(|rm_pn: &crate::lower::node_::RowMarks| if (&rm_pn.builder_p == &gen_name_p7) && (&rm_pn.kind_p == &crate::lower::model::RowKind::GenerationRow) {
            crate::lower::node_::RowMarks { builder_p: rm_pn.builder_p.clone(), reads_p: rm_pn.reads_p.clone(), wrote_p: rm_pn.wrote_p.clone(), builds_p: rm_pn.builds_p.clone(), kind_p: crate::lower::model::RowKind::ValueRow }
        } else {
            rm_pn.clone()
        }));
        this
    };
    (w2_pm.clone(), build_pl.clone())
}

/// The step machine of `ValueRowOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ValueRowOf: unbounded fn Wx, Env, Block, Text, Bool, Text -> ((Wx, Ex))
/// ```
pub struct ValueRowOf {
    pub w_p0: crate::lower::node_::Wx,
    pub me_p1: crate::lower::types::Env,
    pub b_p2: crate::syntax::Block,
    pub f_p3: crate::prelude::Text,
    pub hosted_p4: bool,
    pub taken_p5: crate::prelude::Text,
}

impl ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::model::Ex)> for ValueRowOf {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::lower::node_::Wx, crate::lower::model::Ex)> {
        let w_p0 = &self.w_p0;
        let me_p1 = &self.me_p1;
        let b_p2 = &self.b_p2;
        let f_p3 = &self.f_p3;
        let hosted_p4 = &self.hosted_p4;
        let taken_p5 = &self.taken_p5;
        let lx_p6 = w_p0.lx_p.clone();
        let gen_name_p7 = if *hosted_p4 {
            crate::prelude::Text::from(format!("{}_hosted", f_p3))
        } else {
            f_p3.clone()
        };
        let row_name_p8 = if *hosted_p4 {
            crate::prelude::Text::from(format!("{}HostedValue{}", &w_p0.node_p, &crate::lower::node_::keyed::row_suffix_f(w_p0)))
        } else {
            crate::prelude::Text::from(format!("{}Value{}", &w_p0.node_p, &crate::lower::node_::keyed::row_suffix_f(w_p0)))
        };
        let link_ty_p9 = crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("prism_rtl::Link")), crate::prelude::Array::from(vec![crate::lower::model::OutTy::OutNamed(crate::lower::site_ref_f(&lx_p6, &w_p0.node_p), crate::prelude::Array::new())]));
        let asked_pa = {
            let mut this: crate::lower::node_::Wx = w_p0.clone();
            this.valued_as_o = ::std::option::Option::Some(*hosted_p4);
            this
        };
        let b_p2x = b_p2.clone();
        let hosted_p4x = *hosted_p4;
        let me_p1x = me_p1.clone();
        let taken_p5x = taken_p5.clone();
        crate::prelude::call_then(crate::lower::node_::switch_::start_arm_row_of_f(asked_pa.clone(), me_p1x.clone(), lx_p6.clone(), crate::prelude::Array::new(), crate::prelude::Array::new(), ::std::option::Option::None, b_p2x.clone(), row_name_p8.clone(), gen_name_p7.clone(), true, true, link_ty_p9.clone(), crate::prelude::Array::new(), crate::prelude::Array::new(), crate::prelude::Array::new(), true), move |arm_row_of_f_86628: crate::lower::node_::switch_::ClauseRow| {
            let cr_pb = arm_row_of_f_86628;
            let rows_pc = crate::prelude::Text::from(format!("{}_rows", &gen_name_p7));
            let rows_ty_pd = crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("prism_rtl::WeakRows")), crate::prelude::Array::from(vec![crate::lower::model::OutTy::OutNamed(crate::lower::site_ref_f(&lx_p6, &row_name_p8), crate::prelude::Array::new())]));
            let link_pe = if hosted_p4x {
                crate::prelude::Text::lit("hosted_link")
            } else {
                crate::prelude::Text::lit("link")
            };
            let kept_pf = if hosted_p4x {
                crate::prelude::Text::lit("hosted_rows")
            } else {
                crate::prelude::Text::lit("rows")
            };
            let tail_pg = if hosted_p4x {
                crate::prelude::Array::from(vec![crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(link_pe.clone()))), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("enclosing")))), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("moved")))), crate::lower::model::Ex::XCx])
            } else {
                crate::prelude::Array::from(vec![crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(link_pe.clone()))), crate::lower::model::Ex::XCx])
            };
            let made_ph = crate::lower::expr::try_of_f(&crate::lower::model::Ex::XCall(crate::lower::model::ref_child_f(&crate::lower::site_ref_f(&lx_p6, &cr_pb.case_p.node_p.name_p), &crate::prelude::Text::lit("build")), crate::prelude::append(&crate::prelude::append(&crate::prelude::Array::from(vec![crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("path"))))]), &cr_pb.case_p.passed_p), &tail_pg)));
            let result_pi = if &taken_p5x == &crate::prelude::Text::lit("") {
                crate::lower::model::Ex::XUnit
            } else {
                crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("row"))), taken_p5x.clone(), crate::prelude::Array::new())
            };
            let built_pj = crate::lower::model::Ex::XBlock(crate::prelude::Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("row")), made_ph.clone()), crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XVar(kept_pf.clone())), crate::prelude::Text::lit("add"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("row"))))])))]), ::std::rc::Rc::new(crate::lower::model::Ex::XCall(crate::lower::helper_ref_f(&crate::prelude::Text::lit("built_widget")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("row"))), crate::prelude::Text::lit("built"), crate::prelude::Array::new()), result_pi.clone(), crate::lower::model::Ex::XVar(crate::prelude::Text::lit("row"))]))));
            let params_pk = if hosted_p4x {
                crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("path")), crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("row_base")), crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("enclosing")), crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("moved")), crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("cx"))])
            } else {
                crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("path")), crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("row_base")), crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("cx"))])
            };
            let build_pl = crate::lower::model::Ex::XClosure(true, params_pk.clone(), ::std::rc::Rc::new(crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Ok")), crate::prelude::Array::from(vec![built_pj.clone()]))));
            let w2_pm = {
                let mut this: crate::lower::node_::Wx = cr_pb.parent_p.clone();
                this.valued_as_o = ::std::option::Option::None;
                this.rows_p = crate::prelude::append(&crate::prelude::push(&this.rows_p, &cr_pb.case_p.node_p), &cr_pb.case_p.node_p.children_p);
                this.taken_p = crate::prelude::push(&this.taken_p, &rows_pc);
                this.lets_p = crate::prelude::push(&this.lets_p, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaBind(rows_pc.clone())), rows_ty_pd.clone()), crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::from(format!("prism_rtl::WeakRows::<{}>::new", &row_name_p8))), crate::prelude::Array::new())));
                this.fields_p = crate::prelude::push(&this.fields_p, &(rows_pc.clone(), rows_ty_pd.clone(), crate::prelude::Text::lit("the rows the blueprint value of the block\'s widget built, held weakly")));
                this.moves_p = crate::prelude::push(&this.moves_p, &(rows_pc.clone(), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(rows_pc.clone())))));
                this.row_marks_p = crate::prelude::each(&this.row_marks_p, &(|rm_pn: &crate::lower::node_::RowMarks| if (&rm_pn.builder_p == &gen_name_p7) && (&rm_pn.kind_p == &crate::lower::model::RowKind::GenerationRow) {
                    crate::lower::node_::RowMarks { builder_p: rm_pn.builder_p.clone(), reads_p: rm_pn.reads_p.clone(), wrote_p: rm_pn.wrote_p.clone(), builds_p: rm_pn.builds_p.clone(), kind_p: crate::lower::model::RowKind::ValueRow }
                } else {
                    rm_pn.clone()
                }));
                this
            };
            ::prism_rtl::Turn::Finished((w2_pm.clone(), build_pl.clone()))
        })
    }
}

/// `Start ValueRowOf, x`: what the function value is when passed to `@Run`.
pub fn start_value_row_of_f(w_p0: crate::lower::node_::Wx, me_p1: crate::lower::types::Env, b_p2: crate::syntax::Block, f_p3: crate::prelude::Text, hosted_p4: bool, taken_p5: crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::model::Ex)>> {
    ::std::rc::Rc::new(ValueRowOf { w_p0, me_p1, b_p2, f_p3, hosted_p4, taken_p5 })
}

/// ```prism
/// ?DynamicAnswer: fn Lx, Expr -> ?Expr
/// ```
pub fn dynamic_answer_o(lx_p0: &crate::lower::Lx, x_p1: &crate::syntax::Expr) -> ::std::option::Option<crate::syntax::Expr> {
    if &crate::lower::types::layer_of_f(&crate::lower::type_at_f(lx_p0, &x_p1.span_p)) != &crate::lower::types::Layer::LyDyn {
        ::std::option::Option::None
    } else {
        match &*x_p1.kind_p {
            crate::syntax::ExprKind::EFreeSigil(m88853_0_0, inner_p2) if (m88853_0_0 == &crate::prelude::Text::lit("$")) => if &crate::lower::types::layer_of_f(&crate::lower::type_at_f(lx_p0, &inner_p2.span_p)) == &crate::lower::types::Layer::LyDyn {
                ::std::option::Option::Some((**inner_p2).clone())
            } else {
                ::std::option::Option::None
            },
            _ => ::std::option::Option::Some(x_p1.clone()),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// ```prism
/// DynKey: fn Expr -> Text
/// ```
pub fn dyn_key_f(x_p0: &crate::syntax::Expr) -> crate::prelude::Text {
    crate::prelude::Text::from(format!("{}:{}", &x_p0.span_p.start_p, &x_p0.span_p.end_p))
}

/// ```prism
/// HostDocGetter: fn Wx, Text, Pos, [Place], [ForDef], [GenDef] -> MethDef
/// ```
pub fn host_doc_getter_f(wx_p0: &crate::lower::node_::Wx, name_p1: &crate::prelude::Text, pos_p2: &crate::lower::model::Pos, places_p3: &crate::prelude::Array<crate::lower::node_::Place>, builders_p4: &crate::prelude::Array<crate::lower::model::ForDef>, gens_p5: &crate::prelude::Array<crate::lower::model::GenDef>) -> crate::lower::model::MethDef {
    let start_p6 = crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaMut(crate::prelude::Text::lit("doc"))), crate::lower::types::host_doc_ty_p()), crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("prism_rtl::HostDoc::new")), crate::prelude::Array::new()));
    let body_p7 = crate::lower::node_::finish::document_body_f(wx_p0, &{
        let f = ::std::rc::Rc::new(crate::lower::node_::finish::map_insert_f);
        ::std::rc::Rc::new(move |(a0, a1): (crate::lower::model::Ex, crate::lower::model::Ex)| {
            let fy = f.clone();
            crate::prelude::once_job(move || ::prism_rtl::Turn::Finished(fy(&a0, &a1)))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::model::Ex, crate::lower::model::Ex)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Do>>>
    }, places_p3, builders_p4, gens_p5);
    crate::lower::model::MethDef { name_p: name_p1.clone(), recv_p: crate::lower::model::Recv::RecvRef, params_p: crate::prelude::Array::new(), cx_p: crate::lower::model::CxArg::CxRef, ret_p: crate::lower::types::host_doc_ty_p(), body_p: crate::prelude::append(&crate::prelude::Array::from(vec![start_p6.clone()]), &body_p7), tail_p: crate::lower::model::Ex::XVar(crate::prelude::Text::lit("doc")), doc_p: crate::prelude::Text::from(format!("The places of the child hosted at place {}: each place\'s entry by its path relative to the child (pick HO). Read only by the snapshot of `$doc`\'s outer (pick ST).", &crate::lower::model::place_text_f(pos_p2))) }
}

/// ```prism
/// SnapGetter: fn Text, OutTy, Text -> MethDef
/// ```
pub fn snap_getter_f(name_p0: &crate::prelude::Text, t_p1: &crate::lower::model::OutTy, doc_p2: &crate::prelude::Text) -> crate::lower::model::MethDef {
    crate::lower::model::MethDef { name_p: name_p0.clone(), recv_p: crate::lower::model::Recv::RecvRef, params_p: crate::prelude::Array::new(), cx_p: crate::lower::model::CxArg::CxRef, ret_p: t_p1.clone(), body_p: crate::prelude::Array::new(), tail_p: crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::from(format!("{}_snap", name_p0)))), crate::prelude::Text::lit("get"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx])), doc_p: doc_p2.clone() }
}

/// ```prism
/// StartedLine: fn Wx, ?Bn -> ((Wx, Wres))
/// ```
pub fn started_line_f(wx_p0: &crate::lower::node_::Wx, bound_o1: &::std::option::Option<crate::lower::types::Bn>) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    let wx1_p2 = {
        let mut this: crate::lower::node_::Wx = wx_p0.clone();
        this.pos_p = crate::lower::model::next_pos_f(&this.pos_p);
        this
    };
    let (id_p7, wx2_p8) = match bound_o1 {
        ::std::option::Option::Some(crate::lower::types::Bn::BnEv(er_p4, _)) => (er_p4.node_p.clone(), wx1_p2.clone()),
        _ => {
            let (nm_p5, w_p6) = crate::lower::node_::fresh_name_f(&wx1_p2, &crate::prelude::Text::lit("started"));
            crate::lower::node_::add_gn_f(&w_p6, &nm_p5, &crate::lower::model::OutTy::OutUnit, &crate::lower::node_::GnKind::GnStarted, &crate::prelude::Nat::from(0u32))
        },
    };
    let wx3_p3 = {
        let mut this: crate::lower::node_::Wx = wx2_p8.clone();
        this.started_p = crate::prelude::push(&this.started_p, &id_p7);
        this
    };
    (wx3_p3.clone(), crate::lower::node_::Wres::WrEv(crate::lower::node_::ev_ref_of_f(&wx3_p3, &id_p7)))
}

/// ```prism
/// DeferLine: unbounded fn Wx, Env, [Arg], Expr, ?Nat -> ((Wx, Wres))
/// ```
pub fn defer_line_f(wx_p0: &crate::lower::node_::Wx, menv_p1: &crate::lower::types::Env, args_p2: &crate::prelude::Array<crate::syntax::Arg>, e_p3: &crate::syntax::Expr, target_o4: &::std::option::Option<crate::prelude::Nat>) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    let lx_p5 = wx_p0.lx_p.clone();
    let t_p6 = crate::lower::types::out_ty_of_f(&lx_p5, &crate::lower::types::out_of_f(&crate::lower::type_at_f(&lx_p5, &e_p3.span_p)));
    let (field_p9, wx1_pa) = crate::lower::node_::fresh_name_f(wx_p0, &crate::prelude::Text::lit("deferred"));
    let (id_pc, wx2_pd) = match target_o4 {
        ::std::option::Option::Some(n_pb) => (n_pb.clone(), wx1_pa.clone()),
        ::std::option::Option::None => crate::lower::node_::add_gn_f(&wx1_pa, &crate::prelude::Text::from(format!("{}_fired", &field_p9)), &t_p6, &crate::lower::node_::GnKind::GnDeferred, &crate::prelude::Nat::from(0u32)),
    };
    let wx3_p7 = crate::lower::node_::add_field_last_f(&wx2_pd, &field_p9, &crate::lower::model::OutTy::OutDefer(::std::rc::Rc::new(t_p6.clone())), &crate::prelude::Text::lit("`@Defer`"), &crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Defer::new")), crate::prelude::Array::new()));
    let wx4_p8 = {
        let mut this: crate::lower::node_::Wx = wx3_p7.clone();
        this.defers_p = crate::prelude::push(&this.defers_p, &(field_p9.clone(), id_pc.clone()));
        this
    };
    match crate::prelude::index(args_p2, &crate::prelude::Nat::from(0u32)) {
        ::std::option::Option::Some(a_pe) => {
            let (r_pf, wx5_pg) = crate::lower::node_::dynamics::event_ref_f(&wx4_p8, menv_p1, &a_pe.value_p);
            (crate::lower::node_::connect_f(&wx5_pg, &r_pf, &crate::lower::node_::Sk::SkArm(field_p9.clone())), crate::lower::node_::Wres::WrEv(crate::lower::node_::ev_ref_of_f(&wx5_pg, &id_pc)))
        },
        ::std::option::Option::None => (wx4_p8.clone(), crate::lower::node_::Wres::WrEv(crate::lower::node_::ev_ref_of_f(&wx4_p8, &id_pc))),
    }
}

/// ```prism
/// LaterLine: unbounded fn Wx, Env, Env, [Arg], Expr, ?Nat -> ((Wx, Wres))
/// ```
pub fn later_line_f(wx_p0: &crate::lower::node_::Wx, benv_p1: &crate::lower::types::Env, menv_p2: &crate::lower::types::Env, args_p3: &crate::prelude::Array<crate::syntax::Arg>, e_p4: &crate::syntax::Expr, target_o5: &::std::option::Option<crate::prelude::Nat>) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    let lx_p6 = wx_p0.lx_p.clone();
    let t_p7 = crate::lower::types::out_ty_of_f(&lx_p6, &crate::lower::types::out_of_f(&crate::lower::type_at_f(&lx_p6, &e_p4.span_p)));
    match (crate::prelude::get(&lx_p6.g_p.tags_p, &crate::prelude::Text::lit("Time.After")), crate::prelude::index(args_p3, &crate::prelude::Nat::from(0u32))) {
        (::std::option::Option::Some(tg_p8), ::std::option::Option::Some(a_p9)) => {
            let (wakes_name_ph, wake_ty_pi) = crate::prelude::or(&crate::prelude::fold(&tg_p8.fields_p, &::std::option::Option::None, &(|found_oe: &::std::option::Option<(crate::prelude::Text, crate::check::types::Ty)>, (fname_pf, ft_pg): &(crate::prelude::Text, crate::check::types::Ty)| if &crate::lower::types::layer_of_f(ft_pg) == &crate::lower::types::Layer::LyEv {
                ::std::option::Option::Some((fname_pf.clone(), crate::lower::types::peel_f(ft_pg)))
            } else {
                found_oe.clone()
            })), &(crate::prelude::Text::lit(""), crate::check::types::Ty::TyErr));
            let (queue_pj, wx1_pk) = crate::lower::node_::fresh_name_f(wx_p0, &crate::prelude::Text::lit("later"));
            let wx2_pa = crate::lower::node_::add_field_last_f(&wx1_pk, &queue_pj, &crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("prism_rtl::LaterQueue")), crate::prelude::Array::from(vec![t_p7.clone()])), &crate::prelude::Text::lit("`@Later`\'s firings not answered yet, oldest first"), &crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("prism_rtl::LaterQueue::new")), crate::prelude::Array::new()));
            let (r_pl, wx3_pm) = crate::lower::node_::dynamics::event_ref_f(&wx2_pa, menv_p2, &a_p9.value_p);
            let wx4_pb = crate::lower::node_::connect_f(&wx3_pm, &r_pl, &crate::lower::node_::Sk::SkLater(queue_pj.clone()));
            let wake_pc = wake_of_no_delay_f(&lx_p6, &wake_ty_pi);
            let asks_pd = crate::lower::node_::EvRef { node_p: r_pl.node_p.clone(), owner_p: r_pl.owner_p.clone(), pipe_f: {
                let r_plx = r_pl.clone();
                let wake_pcx = wake_pc.clone();
                ::std::rc::Rc::new(move |(p0, p1): (crate::lower::model::Ex, ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::Ex) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::lower::model::Do>>>>)| {
                    let r_plxy = r_plx.clone();
                    let wake_pcxy = wake_pcx.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let x_pn = p0;
                        let k_fo = p1;
                        (&r_plxy.pipe_f)((x_pn.clone(), {
                            let k_fox = k_fo.clone();
                            let wake_pcxyx = wake_pcxy.clone();
                            ::std::rc::Rc::new(move |p0: crate::lower::model::Ex| {
                                let k_foxy = k_fox.clone();
                                let wake_pcxyxy = wake_pcxyx.clone();
                                crate::prelude::entered(crate::prelude::once_job(move || {
                                    let _ = p0;
                                    (&k_foxy)(wake_pcxyxy.clone()).cycle()
                                }))
                            }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::Ex) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::lower::model::Do>>>>
                        })).cycle()
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::model::Ex, ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::Ex) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::lower::model::Do>>>>)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::lower::model::Do>>>>
            } };
            let (wx5_pp, placed_pq) = crate::lower::node_::elements::element_placed_f(&wx4_pb, benv_p1, menv_p2, &tg_p8, &crate::prelude::Array::new(), &crate::prelude::Array::from(vec![(wakes_name_ph.clone(), asks_pd.clone(), crate::lower::types::out_ty_of_f(&lx_p6, &wake_ty_pi))]), &crate::lower::node_::elements::element_out_f(&lx_p6, &tg_p8, &tg_p8.out_p), &::std::option::Option::None);
            let (out_ps, wx6_pt) = match target_o5 {
                ::std::option::Option::Some(n_pr) => (n_pr.clone(), wx5_pp.clone()),
                ::std::option::Option::None => crate::lower::node_::add_gn_f(&wx5_pp, &crate::prelude::Text::from(format!("{}_fired", &queue_pj)), &t_p7, &crate::lower::node_::GnKind::GnNamed, &crate::prelude::Nat::from(0u32)),
            };
            match &placed_pq {
                crate::lower::node_::Wres::WrEv(answered_pu) => {
                    let oldest_pv = crate::lower::node_::EvRef { node_p: answered_pu.node_p.clone(), owner_p: answered_pu.owner_p.clone(), pipe_f: {
                        let answered_pux = answered_pu.clone();
                        let queue_pjx = queue_pj.clone();
                        ::std::rc::Rc::new(move |(p0, p1): (crate::lower::model::Ex, ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::Ex) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::lower::model::Do>>>>)| {
                            let answered_puxy = answered_pux.clone();
                            let queue_pjxy = queue_pjx.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let x_p10 = p0;
                                let k_f11 = p1;
                                (&answered_puxy.pipe_f)((x_p10.clone(), {
                                    let queue_pjxyx = queue_pjxy.clone();
                                    let k_f11x = k_f11.clone();
                                    ::std::rc::Rc::new(move |p0: crate::lower::model::Ex| {
                                        let queue_pjxyxy = queue_pjxyx.clone();
                                        let k_f11xy = k_f11x.clone();
                                        crate::prelude::entered(crate::prelude::once_job(move || {
                                            let _ = p0;
                                            crate::prelude::call_value((&k_f11xy)(crate::lower::model::Ex::XVar(crate::prelude::Text::from(format!("{}_value", &queue_pjxyxy)))), move |k_93941: crate::prelude::Array<crate::lower::model::Do>| ::prism_rtl::Turn::Finished(crate::prelude::append(&crate::prelude::Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::prelude::Text::from(format!("{}_value", &queue_pjxyxy))), crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), queue_pjxyxy.clone())), crate::prelude::Text::lit("answered"), crate::prelude::Array::new()))]), &k_93941)))
                                        }))
                                    }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::Ex) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::lower::model::Do>>>>
                                })).cycle()
                            }))
                        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::model::Ex, ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::Ex) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::lower::model::Do>>>>)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::lower::model::Do>>>>
                    } };
                    (crate::lower::node_::connect_f(&wx6_pt, &oldest_pv, &crate::lower::node_::Sk::SkNode(out_ps.clone())), crate::lower::node_::Wres::WrEv(crate::lower::node_::ev_ref_of_f(&wx6_pt, &out_ps)))
                },
                _ => {
                    let wx7_p12 = {
                        let mut this: crate::lower::node_::Wx = wx6_pt.clone();
                        this.build_p = crate::prelude::push(&this.build_p, &crate::lower::expr::internal_bug_do_f(&crate::prelude::Text::lit("`Time.After`, placed for an `@Later`, answers no event")));
                        this
                    };
                    (wx7_p12.clone(), crate::lower::node_::Wres::WrUnit)
                },
            }
        },
        _ => {
            let wx2_p13 = {
                let mut this: crate::lower::node_::Wx = wx_p0.clone();
                this.build_p = crate::prelude::push(&this.build_p, &crate::lower::expr::internal_bug_do_f(&crate::prelude::Text::lit("an `@Later` without its event, or a prelude without `Time.After`")));
                this
            };
            (wx2_p13.clone(), crate::lower::node_::Wres::WrUnit)
        },
    }
}

/// ```prism
/// WakeOfNoDelay: unbounded fn Lx, Ty -> Ex
/// ```
pub fn wake_of_no_delay_f(lx_p0: &crate::lower::Lx, wake_ty_p1: &crate::check::types::Ty) -> crate::lower::model::Ex {
    match wake_ty_p1 {
        crate::check::types::Ty::TyCon(name_p2, _) => {
            let owner_p3 = crate::prelude::or(&crate::prelude::get(&lx_p0.g_p.types_p, name_p2), &crate::check::env::names::dummy_ty_info_p());
            match &owner_p3.body_p {
                crate::check::env::TyBody::BRecord(fs_p4) => crate::lower::model::Ex::XRecord(crate::lower::ref_in_f(lx_p0, &owner_p3.home_p, &crate::lower::type_item_name_f(name_p2)), crate::prelude::run_to_end(crate::prelude::each_job(fs_p4.clone(), {
                    let owner_p3x = owner_p3.clone();
                    let lx_p0x = lx_p0.clone();
                    ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::check::types::Ty)| {
                        let owner_p3xy = owner_p3x.clone();
                        let lx_p0xy = lx_p0x.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let (fname_p5, ft_p6) = p0;
                            crate::prelude::call_then(crate::lower::start_field_spell_f(owner_p3xy.home_p.clone(), fname_p5.clone(), ft_p6.clone()), move |field_spell_f_94940: crate::prelude::Text| crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0xy.clone(), ft_p6.clone()), move |out_ty_of_f_94996: crate::lower::model::OutTy| ::prism_rtl::Turn::Finished((field_spell_f_94940, wake_field_of_no_delay_f(&out_ty_of_f_94996)))))
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::check::types::Ty)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Text, crate::lower::model::Ex)>>>
                }))),
                _ => crate::lower::expr::internal_bug_f(&crate::prelude::Text::lit("`Time.After`\'s wake is not a record")),
            }
        },
        _ => crate::lower::expr::internal_bug_f(&crate::prelude::Text::lit("`Time.After`\'s request field is not of a named type")),
    }
}

/// ```prism
/// WakeFieldOfNoDelay: fn OutTy -> Ex
/// ```
pub fn wake_field_of_no_delay_f(t_p0: &crate::lower::model::OutTy) -> crate::lower::model::Ex {
    match t_p0 {
        crate::lower::model::OutTy::OutDuration => crate::lower::model::Ex::XDuration(crate::prelude::Text::lit("0")),
        crate::lower::model::OutTy::OutText => crate::lower::model::Ex::XText(crate::prelude::Text::lit("")),
        _ => crate::lower::expr::internal_bug_f(&crate::prelude::Text::lit("a field of `Time.After`\'s wake that is neither a duration nor a text")),
    }
}

/// ```prism
/// DistinctLine: unbounded fn Wx, Env, [Arg], Expr, ?Bn -> ((Wx, Wres))
/// ```
pub fn distinct_line_f(wx_p0: &crate::lower::node_::Wx, menv_p1: &crate::lower::types::Env, args_p2: &crate::prelude::Array<crate::syntax::Arg>, e_p3: &crate::syntax::Expr, bound_o4: &::std::option::Option<crate::lower::types::Bn>) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    let lx_p5 = wx_p0.lx_p.clone();
    match crate::prelude::index(args_p2, &crate::prelude::Nat::from(0u32)) {
        ::std::option::Option::None => {
            let wx2_p6 = {
                let mut this: crate::lower::node_::Wx = wx_p0.clone();
                this.build_p = crate::prelude::push(&this.build_p, &crate::lower::expr::internal_bug_do_f(&crate::prelude::Text::lit("an `@Distinct` without its dynamic")));
                this
            };
            (wx2_p6.clone(), crate::lower::node_::Wres::WrUnit)
        },
        ::std::option::Option::Some(a_p7) => {
            let t_p8 = crate::lower::types::out_ty_of_f(&lx_p5, &crate::lower::types::peel_f(&crate::lower::type_at_f(&lx_p5, &a_p7.value_p.span_p)));
            let (name_pg, wx1_ph) = 'm96344: {
                if let ::std::option::Option::Some(crate::lower::types::Bn::BnHold(f_pe, _)) = bound_o4 {
                    break 'm96344 (f_pe.clone(), wx_p0.clone());
                }
                if let ::std::option::Option::Some(crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(m96344_1_0_0, f_pf, _), _, _)) = bound_o4 && let crate::lower::model::Ex::XSelf = &**m96344_1_0_0 {
                    break 'm96344 (f_pf.clone(), wx_p0.clone());
                }
                crate::lower::node_::fresh_name_f(wx_p0, &crate::prelude::Text::lit("distinct"))
            };
            let kept_p9 = crate::prelude::Text::from(format!("{}_kept", &name_pg));
            let source_pa = crate::prelude::Text::from(format!("{}_source", &name_pg));
            let (ex_pi, reads_pj) = crate::lower::node_::dynamics::dynamic_expr_f(&wx1_ph, menv_p1, &a_p7.value_p);
            let first_pb = crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("node"))), kept_p9.clone())), crate::prelude::Text::lit("set"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Some")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("node"))), source_pa.clone(), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx]))])), crate::lower::model::Ex::XCx])));
            let sample_pc = crate::lower::model::Ex::XMatch(::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), kept_p9.clone())), crate::prelude::Text::lit("get"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx]))), crate::prelude::Array::from(vec![crate::lower::model::XArm { pat_p: crate::lower::model::Pa::PaCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Some")), crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("v"))])), conds_p: crate::prelude::Array::new(), body_p: crate::lower::model::Ex::XVar(crate::prelude::Text::lit("v")) }, crate::lower::model::XArm { pat_p: crate::lower::model::Pa::PaUnit(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::None"))), conds_p: crate::prelude::Array::new(), body_p: crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), source_pa.clone(), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx])) }]), false, t_p8.clone());
            let wx2_pd = {
                let mut this: crate::lower::node_::Wx = wx1_ph.clone();
                this.taken_p = crate::prelude::append(&this.taken_p, &crate::prelude::Array::from(vec![kept_p9.clone(), source_pa.clone()]));
                this.fields_p = crate::prelude::push(&this.fields_p, &(kept_p9.clone(), crate::lower::model::OutTy::OutHold(::std::rc::Rc::new(crate::lower::model::OutTy::OutOpt(::std::rc::Rc::new(t_p8.clone())))), crate::prelude::Text::lit("`@Distinct`\'s value: its source\'s, written only when it changes")));
                this.moves_p = crate::prelude::push(&this.moves_p, &(kept_p9.clone(), crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Hold::new")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XNone, crate::lower::model::Ex::XCx]))));
                this.build_p = crate::prelude::push(&this.build_p, &first_pb);
                this.getters_p = crate::prelude::append(&this.getters_p, &crate::prelude::Array::from(vec![crate::lower::model::MethDef { name_p: source_pa.clone(), recv_p: crate::lower::model::Recv::RecvRef, params_p: crate::prelude::Array::new(), cx_p: crate::lower::model::CxArg::CxRef, ret_p: t_p8.clone(), body_p: crate::prelude::Array::new(), tail_p: ex_pi.clone(), doc_p: crate::prelude::Text::lit("`@Distinct`\'s source, read at the build.") }, crate::lower::model::MethDef { name_p: name_pg.clone(), recv_p: crate::lower::model::Recv::RecvRef, params_p: crate::prelude::Array::new(), cx_p: crate::lower::model::CxArg::CxRef, ret_p: t_p8.clone(), body_p: crate::prelude::Array::new(), tail_p: sample_pc.clone(), doc_p: crate::prelude::Text::lit("`@Distinct`\'s dynamic: the value it holds at the read point.") }]));
                this.dyn_reads_p = crate::prelude::insert(&crate::prelude::insert(&this.dyn_reads_p, &name_pg, &crate::prelude::Array::from(vec![crate::lower::node_::Read::OwnRead(kept_p9.clone())])), &source_pa, &reads_pj);
                this
            };
            let (r_pk, wx3_pl) = crate::lower::node_::dynamics::updated_event_f(&wx2_pd, menv_p1, args_p2, &t_p8);
            (crate::lower::node_::connect_f(&wx3_pl, &r_pk, &crate::lower::node_::Sk::SkDistinct(kept_p9.clone())), crate::lower::node_::Wres::WrDyn(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), name_pg.clone(), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx])), crate::prelude::Array::from(vec![crate::lower::node_::Read::OwnRead(kept_p9.clone())]), t_p8.clone()))
        },
    }
}

/// ```prism
/// PerKeyLine: unbounded fn Wx, Env, [Arg], ?Bn -> ((Wx, Wres))
/// ```
pub fn per_key_line_f(wx_p0: &crate::lower::node_::Wx, menv_p1: &crate::lower::types::Env, args_p2: &crate::prelude::Array<crate::syntax::Arg>, bound_o3: &::std::option::Option<crate::lower::types::Bn>) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    let lx_p4 = wx_p0.lx_p.clone();
    match crate::prelude::index(args_p2, &crate::prelude::Nat::from(0u32)) {
        ::std::option::Option::None => {
            let wx2_p5 = {
                let mut this: crate::lower::node_::Wx = wx_p0.clone();
                this.build_p = crate::prelude::push(&this.build_p, &crate::lower::expr::internal_bug_do_f(&crate::prelude::Text::lit("an `@PerKey` without its dynamic")));
                this
            };
            (wx2_p5.clone(), crate::lower::node_::Wres::WrUnit)
        },
        ::std::option::Option::Some(a_p6) => {
            let (kt_pg, vt_ph) = match crate::lower::types::peel_f(&crate::lower::type_at_f(&lx_p4, &a_p6.value_p.span_p)) {
                crate::check::types::Ty::TyMap(k_pe, v_pf) => (crate::lower::types::out_ty_of_f(&lx_p4, &*k_pe), crate::lower::types::out_ty_of_f(&lx_p4, &*v_pf)),
                _ => (crate::lower::model::OutTy::OutUnit, crate::lower::model::OutTy::OutUnit),
            };
            let src_ty_p7 = crate::lower::model::OutTy::OutMap(::std::rc::Rc::new(kt_pg.clone()), ::std::rc::Rc::new(vt_ph.clone()));
            let t_p8 = crate::lower::model::OutTy::OutMap(::std::rc::Rc::new(kt_pg.clone()), ::std::rc::Rc::new(crate::lower::model::OutTy::OutDyn(::std::rc::Rc::new(vt_ph.clone()))));
            let (name_pk, wx1_pl) = 'm99731: {
                if let ::std::option::Option::Some(crate::lower::types::Bn::BnHold(f_pi, _)) = bound_o3 {
                    break 'm99731 (f_pi.clone(), wx_p0.clone());
                }
                if let ::std::option::Option::Some(crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(m99731_1_0_0, f_pj, _), _, _)) = bound_o3 && let crate::lower::model::Ex::XSelf = &**m99731_1_0_0 {
                    break 'm99731 (f_pj.clone(), wx_p0.clone());
                }
                crate::lower::node_::fresh_name_f(wx_p0, &crate::prelude::Text::lit("per_key"))
            };
            let kept_p9 = crate::prelude::Text::from(format!("{}_kept", &name_pk));
            let source_pa = crate::prelude::Text::from(format!("{}_source", &name_pk));
            let (ex_pm, reads_pn) = crate::lower::node_::dynamics::dynamic_expr_f(&wx1_pl, menv_p1, &a_p6.value_p);
            let first_pb = crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("node"))), kept_p9.clone())), crate::prelude::Text::lit("start"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("node"))), source_pa.clone(), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx])), crate::lower::model::Ex::XCx])));
            let sample_pc = crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), kept_p9.clone())), crate::prelude::Text::lit("outer"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx, crate::lower::model::Ex::XClosure(false, crate::prelude::Array::new(), ::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), source_pa.clone(), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx]))))]));
            let wx2_pd = {
                let mut this: crate::lower::node_::Wx = wx1_pl.clone();
                this.taken_p = crate::prelude::append(&this.taken_p, &crate::prelude::Array::from(vec![kept_p9.clone(), source_pa.clone()]));
                this.fields_p = crate::prelude::push(&this.fields_p, &(kept_p9.clone(), crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("prism_rtl::PerKey")), crate::prelude::Array::from(vec![kt_pg.clone(), vt_ph.clone()])), crate::prelude::Text::lit("`@PerKey`\'s outer and each key\'s inner")));
                this.moves_p = crate::prelude::push(&this.moves_p, &(kept_p9.clone(), crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("prism_rtl::PerKey::new")), crate::prelude::Array::new())));
                this.build_p = crate::prelude::push(&this.build_p, &first_pb);
                this.getters_p = crate::prelude::append(&this.getters_p, &crate::prelude::Array::from(vec![crate::lower::model::MethDef { name_p: source_pa.clone(), recv_p: crate::lower::model::Recv::RecvRef, params_p: crate::prelude::Array::new(), cx_p: crate::lower::model::CxArg::CxRef, ret_p: src_ty_p7.clone(), body_p: crate::prelude::Array::new(), tail_p: ex_pm.clone(), doc_p: crate::prelude::Text::lit("`@PerKey`\'s source, read at the build.") }, crate::lower::model::MethDef { name_p: name_pk.clone(), recv_p: crate::lower::model::Recv::RecvRef, params_p: crate::prelude::Array::new(), cx_p: crate::lower::model::CxArg::CxRef, ret_p: t_p8.clone(), body_p: crate::prelude::Array::new(), tail_p: sample_pc.clone(), doc_p: crate::prelude::Text::lit("`@PerKey`\'s outer: each key\'s inner by key, at the read point.") }]));
                this.dyn_reads_p = crate::prelude::insert(&crate::prelude::insert(&this.dyn_reads_p, &name_pk, &crate::prelude::Array::from(vec![crate::lower::node_::Read::OwnRead(kept_p9.clone())])), &source_pa, &reads_pn);
                this
            };
            let (r_po, wx3_pp) = crate::lower::node_::dynamics::updated_event_f(&wx2_pd, menv_p1, args_p2, &src_ty_p7);
            (crate::lower::node_::connect_f(&wx3_pp, &r_po, &crate::lower::node_::Sk::SkPerKey(kept_p9.clone())), crate::lower::node_::Wres::WrDyn(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), name_pk.clone(), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx])), crate::prelude::Array::from(vec![crate::lower::node_::Read::OwnRead(kept_p9.clone())]), t_p8.clone()))
        },
    }
}

/// ```prism
/// RunLine: unbounded fn Wx, Env, [Arg], Expr, ?Nat -> ((Wx, Wres))
/// ```
pub fn run_line_f(wx_p0: &crate::lower::node_::Wx, benv_p1: &crate::lower::types::Env, args_p2: &crate::prelude::Array<crate::syntax::Arg>, e_p3: &crate::syntax::Expr, target_o4: &::std::option::Option<crate::prelude::Nat>) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    let lx_p5 = wx_p0.lx_p.clone();
    let t_p6 = crate::lower::types::out_ty_of_f(&lx_p5, &crate::lower::types::out_of_f(&crate::lower::type_at_f(&lx_p5, &e_p3.span_p)));
    let (p_pd, wx1_pe) = crate::lower::node_::fresh_name_f(wx_p0, &crate::prelude::Text::lit("run"));
    let wx2_p7 = {
        let mut this: crate::lower::node_::Wx = wx1_pe.clone();
        this.pos_p = crate::lower::model::next_pos_f(&this.pos_p);
        this.taken_p = crate::prelude::append(&this.taken_p, &crate::prelude::Array::from(vec![crate::prelude::Text::from(format!("{}_job", &p_pd)), crate::prelude::Text::from(format!("{}_again", &p_pd)), crate::prelude::Text::from(format!("{}_started", &p_pd)), crate::prelude::Text::from(format!("{}_turn", &p_pd))]));
        this
    };
    let start_p8 = match crate::prelude::index(args_p2, &crate::prelude::Nat::from(0u32)) {
        ::std::option::Option::Some(a_pf) => match &*a_pf.value_p.kind_p {
            crate::syntax::ExprKind::EName(n_pg) => {
                let (q_oi, _) = crate::check::env::names::resolve_value_f(&lx_p5.g_p, &lx_p5.home_p, n_pg);
                let local_oh = if &crate::prelude::len(&n_pg.path_p) == &crate::prelude::Nat::from(1u32) {
                    crate::prelude::get(&benv_p1.names_p, &crate::lower::types::name_key_at_f(&lx_p5, benv_p1, n_pg, &a_pf.value_p.span_p))
                } else {
                    ::std::option::Option::None
                };
                match (local_oh.clone(), q_oi.clone()) {
                    (::std::option::Option::None, ::std::option::Option::Some(q_pj)) if has_fn_def_f(&lx_p5, &q_pj) => crate::lower::model::Ex::XPath(crate::lower::expr::start_ref_f(&lx_p5, &q_pj)),
                    _ => crate::lower::expr::as_job_value_f(&lx_p5, benv_p1, &a_pf.value_p),
                    _ => unreachable!("no arm matched"),
                }
            },
            _ => crate::lower::expr::as_job_value_f(&lx_p5, benv_p1, &a_pf.value_p),
        },
        ::std::option::Option::None => crate::lower::expr::internal_bug_f(&crate::prelude::Text::lit("an `@Run` without its function")),
    };
    let x_p9 = match crate::prelude::index(args_p2, &crate::prelude::Nat::from(1u32)) {
        ::std::option::Option::Some(a_pk) => crate::lower::types::own_f(&crate::lower::expr::value_of_f(&lx_p5, benv_p1, &a_pk.value_p)),
        ::std::option::Option::None => crate::lower::model::Ex::XUnit,
    };
    let wx3_pa = crate::lower::node_::add_field_f(&wx2_p7, &crate::prelude::Text::from(format!("{}_job", &p_pd)), &crate::lower::model::OutTy::OutHold(::std::rc::Rc::new(crate::lower::model::OutTy::OutJob(::std::rc::Rc::new(t_p6.clone())))), &crate::prelude::Text::lit("`@Run`\'s job (`@Machine`\'s state)"), &crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Hold::new")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XApply(::std::rc::Rc::new(start_p8.clone()), crate::prelude::Array::from(vec![x_p9.clone()])), crate::lower::model::Ex::XCx])));
    let wx4_pb = crate::lower::node_::add_field_last_f(&wx3_pa, &crate::prelude::Text::from(format!("{}_again", &p_pd)), &crate::lower::model::OutTy::OutDefer(::std::rc::Rc::new(crate::lower::model::OutTy::OutUnit)), &crate::prelude::Text::lit("`@Run`\'s `!again`"), &crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Defer::new")), crate::prelude::Array::new()));
    let (s_pl, wx5_pm) = crate::lower::node_::add_gn_f(&wx4_pb, &crate::prelude::Text::from(format!("{}_started", &p_pd)), &crate::lower::model::OutTy::OutUnit, &crate::lower::node_::GnKind::GnStarted, &crate::prelude::Nat::from(0u32));
    let (a_pn, wx6_po) = crate::lower::node_::add_gn_f(&wx5_pm, &crate::prelude::Text::from(format!("{}_again", &p_pd)), &crate::lower::model::OutTy::OutUnit, &crate::lower::node_::GnKind::GnDeferred, &crate::prelude::Nat::from(0u32));
    let (m_pp, wx7_pq) = crate::lower::node_::dynamics::merge_f(&wx6_po, &crate::prelude::Text::from(format!("{}_turn", &p_pd)), &crate::lower::model::OutTy::OutUnit, &crate::lower::node_::ev_ref_of_f(&wx6_po, &s_pl), &crate::lower::node_::ev_ref_of_f(&wx6_po, &a_pn));
    let (res_ps, wx8_pt) = match target_o4 {
        ::std::option::Option::Some(n_pr) => (n_pr.clone(), wx7_pq.clone()),
        ::std::option::Option::None => crate::lower::node_::add_gn_f(&wx7_pq, &crate::prelude::Text::from(format!("{}_done", &p_pd)), &t_p6, &crate::lower::node_::GnKind::GnNamed, &crate::prelude::Nat::from(0u32)),
    };
    let wx9_pc = {
        let mut this: crate::lower::node_::Wx = crate::lower::node_::connect_f(&wx8_pt, &crate::lower::node_::ev_ref_of_f(&wx8_pt, &m_pp), &crate::lower::node_::Sk::SkCycle(crate::prelude::Text::from(format!("{}_job", &p_pd)), crate::prelude::Text::from(format!("{}_again", &p_pd)), res_ps.clone()));
        this.started_p = crate::prelude::push(&this.started_p, &s_pl);
        this.defers_p = crate::prelude::push(&this.defers_p, &(crate::prelude::Text::from(format!("{}_again", &p_pd)), a_pn.clone()));
        this
    };
    (wx9_pc.clone(), crate::lower::node_::Wres::WrEv(crate::lower::node_::ev_ref_of_f(&wx9_pc, &res_ps)))
}

/// ```prism
/// HasFnDef: fn Lx, Text -> Bool
/// ```
pub fn has_fn_def_f(lx_p0: &crate::lower::Lx, qk_p1: &crate::prelude::Text) -> bool {
    crate::prelude::fold(&lx_p0.g_p.defs_p, &false, &(|f_p2: &bool, d_p3: &crate::check::env::Def| *f_p2 || ((&d_p3.qk_p == qk_p1) && crate::check::env::decls::is_fn_def_f(d_p3))))
}

/// ```prism
/// MachineLine: unbounded fn Wx, Env, Env, [Arg], Expr, ?Nat -> ((Wx, Wres))
/// ```
pub fn machine_line_f(wx_p0: &crate::lower::node_::Wx, benv_p1: &crate::lower::types::Env, menv_p2: &crate::lower::types::Env, args_p3: &crate::prelude::Array<crate::syntax::Arg>, e_p4: &crate::syntax::Expr, target_o5: &::std::option::Option<crate::prelude::Nat>) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    let lx_p6 = wx_p0.lx_p.clone();
    let t_p7 = crate::lower::types::out_ty_of_f(&lx_p6, &crate::lower::types::out_of_f(&crate::lower::type_at_f(&lx_p6, &e_p4.span_p)));
    let (f_p9, wx1_pa) = crate::lower::node_::fresh_name_f(wx_p0, &crate::prelude::Text::lit("machine"));
    let named_o8 = match crate::prelude::index(args_p3, &crate::prelude::Nat::from(0u32)) {
        ::std::option::Option::Some(a_pb) => match &*a_pb.value_p.kind_p {
            crate::syntax::ExprKind::EName(n_pc) => {
                let (q_oe, _) = crate::check::env::names::resolve_value_f(&lx_p6.g_p, &lx_p6.home_p, n_pc);
                let local_pd = (&crate::prelude::len(&n_pc.path_p) == &crate::prelude::Nat::from(1u32)) && crate::check::env::has_key_f(&benv_p1.names_p, &crate::check::env::sname_key_f(n_pc));
                match &q_oe {
                    ::std::option::Option::Some(q_pf) if !local_pd => ::std::option::Option::Some(crate::lower::model::Ex::XPath(crate::lower::value_ref_f(&lx_p6, q_pf))),
                    _ => ::std::option::Option::None,
                    _ => unreachable!("no arm matched"),
                }
            },
            _ => ::std::option::Option::None,
        },
        ::std::option::Option::None => ::std::option::Option::None,
    };
    match (crate::prelude::index(args_p3, &crate::prelude::Nat::from(0u32)), crate::prelude::index(args_p3, &crate::prelude::Nat::from(1u32)), crate::prelude::index(args_p3, &crate::prelude::Nat::from(2u32))) {
        (::std::option::Option::Some(step_arg_pg), ::std::option::Option::Some(init_ph), ::std::option::Option::Some(ev_pi)) => {
            let st_pj = crate::lower::types::out_ty_of_f(&lx_p6, &crate::lower::types::peel_f(&crate::lower::type_at_f(&lx_p6, &init_ph.value_p.span_p)));
            let x_pk = crate::lower::types::own_f(&crate::lower::expr::value_of_f(&lx_p6, benv_p1, &init_ph.value_p));
            let wx0_pl = crate::lower::node_::add_field_f(&wx1_pa, &crate::prelude::Text::from(format!("{}_state", &f_p9)), &crate::lower::model::OutTy::OutHold(::std::rc::Rc::new(st_pj.clone())), &crate::prelude::Text::lit("`@Machine`\'s state"), &crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Hold::new")), crate::prelude::Array::from(vec![x_pk.clone(), crate::lower::model::Ex::XCx])));
            let (sp_po, wx2_pp) = match &named_o8 {
                ::std::option::Option::Some(p_pm) => (p_pm.clone(), wx0_pl.clone()),
                ::std::option::Option::None => {
                    let ft_pn = crate::lower::types::out_ty_of_f(&lx_p6, &crate::lower::types::peel_f(&crate::lower::type_at_f(&lx_p6, &step_arg_pg.value_p.span_p)));
                    (crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), crate::prelude::Text::from(format!("{}_step", &f_p9))), crate::lower::node_::add_field_f(&wx0_pl, &crate::prelude::Text::from(format!("{}_step", &f_p9)), &ft_pn, &crate::prelude::Text::lit("`@Machine`\'s step, a function value"), &crate::lower::types::own_f(&crate::lower::expr::value_of_f(&lx_p6, benv_p1, &step_arg_pg.value_p))))
                },
            };
            let (out_pr, wx3_ps) = match target_o5 {
                ::std::option::Option::Some(n_pq) => (n_pq.clone(), wx2_pp.clone()),
                ::std::option::Option::None => crate::lower::node_::add_gn_f(&wx2_pp, &crate::prelude::Text::from(format!("{}_fired", &f_p9)), &t_p7, &crate::lower::node_::GnKind::GnNamed, &crate::prelude::Nat::from(0u32)),
            };
            let (r_pt, wx4_pu) = crate::lower::node_::dynamics::event_ref_f(&wx3_ps, menv_p2, &ev_pi.value_p);
            (crate::lower::node_::connect_f(&wx4_pu, &r_pt, &crate::lower::node_::Sk::SkMachine(crate::prelude::Text::from(format!("{}_state", &f_p9)), sp_po.clone(), out_pr.clone())), crate::lower::node_::Wres::WrEv(crate::lower::node_::ev_ref_of_f(&wx4_pu, &out_pr)))
        },
        _ => {
            let wx2_pv = {
                let mut this: crate::lower::node_::Wx = wx1_pa.clone();
                this.build_p = crate::prelude::push(&this.build_p, &crate::lower::expr::internal_bug_do_f(&crate::prelude::Text::lit("an `@Machine` without its step, state or event")));
                this
            };
            (wx2_pv.clone(), crate::lower::node_::Wres::WrUnit)
        },
    }
}

/// ```prism
/// ElementCallLine: unbounded fn Wx, Env, Env, [Arg], Expr, ?Bn -> ((Wx, Wres))
/// ```
pub fn element_call_line_f(wx_p0: &crate::lower::node_::Wx, benv_p1: &crate::lower::types::Env, menv_p2: &crate::lower::types::Env, args_p3: &crate::prelude::Array<crate::syntax::Arg>, e_p4: &crate::syntax::Expr, bound_o5: &::std::option::Option<crate::lower::types::Bn>) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    let lx_p6 = wx_p0.lx_p.clone();
    match crate::prelude::index(args_p3, &crate::prelude::Nat::from(0u32)) {
        ::std::option::Option::Some(a_p7) if is_tag_application_f(&lx_p6, &a_p7.value_p) => crate::lower::node_::elements::element_line_f(wx_p0, benv_p1, menv_p2, &ungrouped_f(&a_p7.value_p), bound_o5),
        ::std::option::Option::Some(a_p8) if crate::lower::node_::switch_::is_some_f(&element_let_o(menv_p2, &a_p8.value_p)) => match element_let_o(menv_p2, &a_p8.value_p) {
            ::std::option::Option::Some(x_p9) => crate::lower::node_::elements::element_line_f(wx_p0, benv_p1, menv_p2, &x_p9, bound_o5),
            ::std::option::Option::None => (wx_p0.clone(), crate::lower::node_::Wres::WrUnit),
        },
        ::std::option::Option::Some(a_pa) => applied_blueprint_line_f(wx_p0, e_p4, &crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("prism_rtl::element_blueprint::<crate::Elem, crate::Answer>")), crate::prelude::Array::from(vec![crate::lower::types::ref_f(&crate::lower::expr::value_of_f(&lx_p6, menv_p2, &a_pa.value_p))]))))),
        ::std::option::Option::None => {
            let wx2_pb = {
                let mut this: crate::lower::node_::Wx = wx_p0.clone();
                this.build_p = crate::prelude::push(&this.build_p, &crate::lower::expr::internal_bug_do_f(&crate::prelude::Text::lit("`@Element` without its element")));
                this
            };
            (wx2_pb.clone(), crate::lower::node_::Wres::WrUnit)
        },
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// ?ElementLet: fn Env, Expr -> ?Expr
/// ```
pub fn element_let_o(menv_p0: &crate::lower::types::Env, e_p1: &crate::syntax::Expr) -> ::std::option::Option<crate::syntax::Expr> {
    match &*ungrouped_f(e_p1).kind_p {
        crate::syntax::ExprKind::EName(n_p2) => if &crate::prelude::len(&n_p2.path_p) != &crate::prelude::Nat::from(1u32) {
            ::std::option::Option::None
        } else {
            match crate::prelude::get(&menv_p0.names_p, &crate::prelude::Text::from(format!("{}#element", &crate::check::env::sname_key_f(n_p2)))) {
                ::std::option::Option::Some(crate::lower::types::Bn::BnWidget(x_p3, _, _, _)) => ::std::option::Option::Some(x_p3),
                _ => ::std::option::Option::None,
            }
        },
        _ => ::std::option::Option::None,
    }
}

/// ```prism
/// Ungrouped: fn Expr -> Expr
/// ```
pub fn ungrouped_f(e_p0: &crate::syntax::Expr) -> crate::syntax::Expr {
    match &*e_p0.kind_p {
        crate::syntax::ExprKind::EGroup(x_p1) => ungrouped_f(&**x_p1),
        _ => e_p0.clone(),
    }
}

/// ```prism
/// IsTagApplication: unbounded fn Lx, Expr -> Bool
/// ```
pub fn is_tag_application_f(lx_p0: &crate::lower::Lx, e_p1: &crate::syntax::Expr) -> bool {
    match &*e_p1.kind_p {
        crate::syntax::ExprKind::EGroup(x_p2) => is_tag_application_f(lx_p0, &**x_p2),
        crate::syntax::ExprKind::ECall(c_p3, _, _, _) => crate::check::env::has_key_f(&lx_p0.g_p.tags_p, &crate::lower::node_::elements::tag_name_of_f(lx_p0, &**c_p3)),
        crate::syntax::ExprKind::EName(_) => crate::check::env::has_key_f(&lx_p0.g_p.tags_p, &crate::lower::node_::elements::tag_name_of_f(lx_p0, e_p1)),
        _ => false,
    }
}

/// The step machine of `IsTagApplication`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// IsTagApplication: unbounded fn Lx, Expr -> Bool
/// ```
pub struct IsTagApplication {
    pub lx_p0: crate::lower::Lx,
    pub e_p1: crate::syntax::Expr,
}

impl ::prism_rtl::Job<bool> for IsTagApplication {
    fn cycle(&self) -> ::prism_rtl::Turn<bool> {
        let lx_p0 = &self.lx_p0;
        let e_p1 = &self.e_p1;
        match &*e_p1.kind_p {
            crate::syntax::ExprKind::EGroup(x_p2) => ::prism_rtl::Turn::More(::std::rc::Rc::new(IsTagApplication { lx_p0: lx_p0.clone(), e_p1: (**x_p2).clone() })),
            crate::syntax::ExprKind::ECall(c_p3, _, _, _) => ::prism_rtl::Turn::Finished(crate::check::env::has_key_f(&lx_p0.g_p.tags_p, &crate::lower::node_::elements::tag_name_of_f(lx_p0, &**c_p3))),
            crate::syntax::ExprKind::EName(_) => ::prism_rtl::Turn::Finished(crate::check::env::has_key_f(&lx_p0.g_p.tags_p, &crate::lower::node_::elements::tag_name_of_f(lx_p0, e_p1))),
            _ => ::prism_rtl::Turn::Finished(false),
        }
    }
}

/// `Start IsTagApplication, x`: what the function value is when passed to `@Run`.
pub fn start_is_tag_application_f(lx_p0: crate::lower::Lx, e_p1: crate::syntax::Expr) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>> {
    ::std::rc::Rc::new(IsTagApplication { lx_p0, e_p1 })
}

/// ```prism
/// InlineWidget: unbounded fn Wx, Env, Env, Text, ValInfo, [Arg], Expr -> ((Wx, Wres))
/// ```
pub fn inline_widget_f(wx_p0: &crate::lower::node_::Wx, benv_p1: &crate::lower::types::Env, menv_p2: &crate::lower::types::Env, qk_p3: &crate::prelude::Text, v_p4: &crate::check::env::ValInfo, args_p5: &crate::prelude::Array<crate::syntax::Arg>, e_p6: &crate::syntax::Expr) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    let lx_p7 = wx_p0.lx_p.clone();
    let clauses_p8 = crate::lower::jobs::clauses_of_f(&lx_p7.g_p, qk_p3);
    let w_o9 = widget_decl_of_o(&lx_p7.g_p, qk_p3);
    let (params_pe, body_of) = match &w_o9 {
        ::std::option::Option::Some(wd_pa) => (crate::prelude::Array::new(), ::std::option::Option::Some(wd_pa.body_p.clone())),
        ::std::option::Option::None => 'm109178: {
            if let m109178_0 = &clauses_p8 && (m109178_0.len() == 1) && let ::std::option::Option::Some(c_pb) = crate::prelude::index(m109178_0, &crate::prelude::Nat::from(0u32)) {
                break 'm109178 match &c_pb.body_p {
                    crate::syntax::decls::FnBody::BodyBlock(b_pc) => (c_pb.params_p.clone(), ::std::option::Option::Some(b_pc.clone())),
                    crate::syntax::decls::FnBody::BodyExpr(x_pd) => (c_pb.params_p.clone(), ::std::option::Option::Some(crate::syntax::Block { stmts_p: crate::prelude::Array::from(vec![crate::syntax::Stmt { kind_p: crate::syntax::StmtKind::SExpr(x_pd.clone()), span_p: x_pd.span_p.clone() }]), inline_p: true, span_p: x_pd.span_p.clone() })),
                };
            }
            (crate::prelude::Array::new(), ::std::option::Option::None)
        },
    };
    match &body_of {
        ::std::option::Option::None => if &crate::prelude::len(&clauses_p8) == &crate::prelude::Nat::from(0u32) {
            {
                let wx2_pg = {
                    let mut this: crate::lower::node_::Wx = wx_p0.clone();
                    this.build_p = crate::prelude::push(&this.build_p, &crate::lower::expr::internal_bug_do_f(&crate::prelude::Text::from(format!("the builtin widget {} has no body and no lowering", &crate::check::types::bare_name_f(qk_p3)))));
                    this
                };
                (wx2_pg.clone(), crate::lower::node_::Wres::WrUnit)
            }
        } else {
            match crate::prelude::index(args_p5, &crate::prelude::Nat::from(0u32)) {
                ::std::option::Option::Some(a_ph) => if crate::lower::node_::switch_::shares_at_f(wx_p0, menv_p2, qk_p3, v_p4, e_p6, args_p5) {
                    crate::lower::node_::switch_::shared_clause_line_f(wx_p0, menv_p2, &a_ph.value_p, qk_p3, v_p4, e_p6, args_p5)
                } else {
                    if &recursion_f(&wx_p0.inlining_p, qk_p3) > &crate::prelude::Nat::from(16u32) {
                        too_deep_f(wx_p0, qk_p3, e_p6)
                    } else {
                        {
                            let call_pi = crate::syntax::Block { stmts_p: crate::prelude::Array::from(vec![crate::syntax::Stmt { kind_p: crate::syntax::StmtKind::SExpr(e_p6.clone()), span_p: e_p6.span_p.clone() }]), inline_p: true, span_p: e_p6.span_p.clone() };
                            let inside_pj = {
                                let mut this: crate::lower::node_::Wx = wx_p0.clone();
                                this.inlining_p = crate::prelude::push(&this.inlining_p, qk_p3);
                                this.lx_p = with_recursing_f(&lx_p7, qk_p3);
                                this
                            };
                            let (done_pl, res_pm) = crate::lower::node_::switch_::clause_widget_line_f(&inside_pj, benv_p1, menv_p2, &a_ph.value_p, &call_pi, qk_p3, v_p4, e_p6, args_p5);
                            let outside_pk = {
                                let mut this: crate::lower::node_::Wx = done_pl.clone();
                                this.inlining_p = wx_p0.inlining_p.clone();
                                this.lx_p = lx_p7.clone();
                                this
                            };
                            (outside_pk.clone(), res_pm.clone())
                        }
                    }
                },
                ::std::option::Option::None => {
                    let wx2_pn = {
                        let mut this: crate::lower::node_::Wx = wx_p0.clone();
                        this.build_p = crate::prelude::push(&this.build_p, &crate::lower::expr::refusal_do_f(&crate::prelude::Text::lit("a widget of several clauses that takes no arguments")));
                        this
                    };
                    (wx2_pn.clone(), crate::lower::node_::Wres::WrUnit)
                },
            }
        },
        ::std::option::Option::Some(body_po) => {
            let shared_one_pp = ((&crate::prelude::len(&clauses_p8) == &crate::prelude::Nat::from(1u32)) && (&crate::prelude::len(args_p5) > &crate::prelude::Nat::from(0u32))) && crate::lower::node_::switch_::shares_at_f(wx_p0, menv_p2, qk_p3, v_p4, e_p6, args_p5);
            if shared_one_pp {
                crate::lower::node_::switch_::shared_clause_line_f(wx_p0, menv_p2, &crate::prelude::or(&crate::prelude::index(args_p5, &crate::prelude::Nat::from(0u32)), &crate::syntax::Arg { marks_p: crate::prelude::Text::lit(""), name_o: ::std::option::Option::None, value_p: crate::lower::expr::dummy_expr_p(), span_p: crate::syntax::Range { start_p: crate::prelude::Nat::from(0u32), end_p: crate::prelude::Nat::from(0u32) } }).value_p, qk_p3, v_p4, e_p6, args_p5)
            } else {
                if &recursion_f(&wx_p0.inlining_p, qk_p3) > &crate::prelude::Nat::from(16u32) {
                    too_deep_f(wx_p0, qk_p3, e_p6)
                } else {
                    {
                        let lxc_pq = crate::lower::program::in_module_at_f(&lx_p7, &v_p4.file_p, &v_p4.home_p, &lx_p7.site_p);
                        let ptys_pr = match &v_p4.scheme_p.ty_p {
                            crate::check::types::Ty::TyFn(_, ps_p12, _) => ps_p12.clone(),
                            _ => crate::prelude::Array::new(),
                        };
                        let params_os = crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(&params_pe)), ::std::option::Option::Some(crate::prelude::Map::new()), {
                            let args_p5x = args_p5.clone();
                            let ptys_prx = ptys_pr.clone();
                            let lx_p7x = lx_p7.clone();
                            ::std::rc::Rc::new(move |(p0, p1): (::std::option::Option<crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>>, crate::prelude::Nat)| {
                                let args_p5xy = args_p5x.clone();
                                let ptys_prxy = ptys_prx.clone();
                                let lx_p7xy = lx_p7x.clone();
                                crate::prelude::entered(crate::prelude::once_job(move || {
                                    let acc_o13 = p0;
                                    let i_p14 = p1;
                                    match (acc_o13.clone(), crate::prelude::index(&args_p5xy, &i_p14)) {
                                        (::std::option::Option::Some(m_p15), ::std::option::Option::Some(a_p16)) => ::prism_rtl::Turn::More(::std::rc::Rc::new(ParamInstance { pty_p0: crate::prelude::or(&crate::prelude::index(&ptys_prxy, &i_p14), &crate::check::types::Ty::TyErr), aty_p1: crate::lower::type_at_f(&lx_p7xy, &a_p16.value_p.span_p), m_p2: m_p15.clone() })),
                                        _ => ::prism_rtl::Turn::Finished(acc_o13.clone()),
                                    }
                                }))
                            }) as ::std::rc::Rc<dyn ::std::ops::Fn((::std::option::Option<crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>>, crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<::std::option::Option<crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>>>>>
                        }));
                        let unmatched_pt = crate::prelude::filter(&crate::prelude::run_to_end(crate::prelude::fold_job(ptys_pr.clone(), crate::prelude::Array::new(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::check::types::Ty)| crate::prelude::entered(crate::prelude::once_job(move || {
                            let acc_p17 = p0;
                            let t_p18 = p1;
                            crate::prelude::call_then(start_rigids_in_f(t_p18.clone()), move |rigids_in_f_113111: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_p17, &rigids_in_f_113111)))
                        }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::check::types::Ty)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>)), &(|q_p19: &crate::prelude::Text| !crate::check::env::has_key_f(&crate::prelude::or(&params_os, &crate::prelude::Map::new()), q_p19)));
                        let lxp_pu = {
                            let mut this: crate::lower::Lx = lx_p7.clone();
                            this.subst_p = crate::prelude::fold(&crate::prelude::keys(&crate::prelude::or(&params_os, &crate::prelude::Map::new())), &this.subst_p, &(|m_p1a: &crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>, q_p1b: &crate::prelude::Text| crate::prelude::insert(m_p1a, q_p1b, &crate::prelude::or(&crate::prelude::get(&crate::prelude::or(&params_os, &crate::prelude::Map::new()), q_p1b), &crate::check::types::Ty::TyErr))));
                            this
                        };
                        let (wx1_p1k, be1_p1l, me1_p1m) = crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(&params_pe)), (wx_p0.clone(), crate::lower::types::empty_env_p(), crate::lower::types::empty_env_p()), {
                            let params_pex = params_pe.clone();
                            let lxc_pqx = lxc_pq.clone();
                            let lxp_pux = lxp_pu.clone();
                            let ptys_prx = ptys_pr.clone();
                            let args_p5x = args_p5.clone();
                            let benv_p1x = benv_p1.clone();
                            let menv_p2x = menv_p2.clone();
                            ::std::rc::Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::prelude::Nat)| {
                                let params_pexy = params_pex.clone();
                                let lxc_pqxy = lxc_pqx.clone();
                                let lxp_puxy = lxp_pux.clone();
                                let ptys_prxy = ptys_prx.clone();
                                let args_p5xy = args_p5x.clone();
                                let benv_p1xy = benv_p1x.clone();
                                let menv_p2xy = menv_p2x.clone();
                                crate::prelude::entered(crate::prelude::once_job(move || {
                                    let (w_p1c, be_p1d, me_p1e) = p0;
                                    let i_p1f = p1;
                                    {
                                        let p_p1g = crate::prelude::or(&crate::prelude::index(&params_pexy, &i_p1f), &crate::lower::patterns::dummy_pat_p());
                                        let nkey_p1h = crate::lower::functions::plain_binder_f(&lxc_pqxy, &p_p1g);
                                        let pty_p1i = crate::lower::subst_ty_f(&lxp_puxy, &crate::prelude::or(&crate::prelude::index(&ptys_prxy, &i_p1f), &crate::check::types::Ty::TyErr));
                                        match crate::prelude::index(&args_p5xy, &i_p1f) {
                                            ::std::option::Option::None => ::prism_rtl::Turn::Finished((w_p1c.clone(), be_p1d.clone(), me_p1e.clone())),
                                            ::std::option::Option::Some(a_p1j) => if &nkey_p1h != &crate::prelude::Text::lit("") {
                                                crate::prelude::call_then(crate::lower::start_local_name_at_f(lxc_pqxy.clone(), nkey_p1h.clone(), p_p1g.span_p.clone()), move |local_name_at_f_113767: crate::prelude::Text| ::prism_rtl::Turn::Finished(bind_param_f(&w_p1c, &benv_p1xy, &menv_p2xy, &be_p1d, &me_p1e, &nkey_p1h, &local_name_at_f_113767, &pty_p1i, &a_p1j.value_p)))
                                            } else {
                                                ::prism_rtl::Turn::Finished(bind_param_pattern_f(&w_p1c, &benv_p1xy, &menv_p2xy, &be_p1d, &me_p1e, &lxc_pqxy, &p_p1g, &pty_p1i, &a_p1j.value_p))
                                            },
                                        }
                                    }
                                }))
                            }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>>>
                        }));
                        let call_span_pv = match &*e_p6.kind_p {
                            crate::syntax::ExprKind::ECall(c_p1n, _, _, _) => c_p1n.span_p.clone(),
                            _ => e_p6.span_p.clone(),
                        };
                        let lxi_p10 = {
                            let mut this: crate::lower::Lx = lxc_pq.clone();
                            this.inlined_p = match crate::prelude::get(&lx_p7.call_ids_p, &crate::lower::place_key_f(&lx_p7, &call_span_pv)) {
                                ::std::option::Option::Some(id_p1o) => crate::prelude::Text::from(format!("{}_{}", &lx_p7.inlined_p, &crate::lower::base32_f(&id_p1o))),
                                ::std::option::Option::None => lx_p7.inlined_p.clone(),
                            };
                            this.subst_p = crate::prelude::fold(&crate::prelude::keys(&crate::prelude::or(&params_os, &crate::prelude::Map::new())), &this.subst_p, &(|m_p1p: &crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>, q_p1q: &crate::prelude::Text| crate::prelude::insert(m_p1p, q_p1q, &crate::prelude::or(&crate::prelude::get(&crate::prelude::or(&params_os, &crate::prelude::Map::new()), q_p1q), &crate::check::types::Ty::TyErr))));
                            this.recursing_p = crate::check::types::add_text_f(&lx_p7.recursing_p, qk_p3);
                            this
                        };
                        let inner_p11 = {
                            let mut this: crate::lower::node_::Wx = wx1_p1k.clone();
                            this.lx_p = lxi_p10.clone();
                            this.inlining_p = crate::prelude::push(&this.inlining_p, qk_p3);
                            this.result_p = crate::lower::node_::Wres::WrUnit;
                            this
                        };
                        if &crate::prelude::len(&unmatched_pt) > &crate::prelude::Nat::from(0u32) {
                            {
                                let wx2_p1r = {
                                    let mut this: crate::lower::node_::Wx = wx_p0.clone();
                                    this.build_p = crate::prelude::push(&this.build_p, &crate::lower::expr::refusal_do_f(&crate::prelude::Text::from(format!("the generic widget {} at a call whose types its parameters\' do not match", &crate::check::types::bare_name_f(qk_p3)))));
                                    this
                                };
                                (wx2_p1r.clone(), crate::lower::node_::Wres::WrUnit)
                            }
                        } else {
                            {
                                let done_p1s = crate::lower::node_::def::block_into_f(&inner_p11, &be1_p1l, &me1_p1m, body_po);
                                let back_p1t = {
                                    let mut this: crate::lower::node_::Wx = done_p1s.clone();
                                    this.lx_p = lx_p7.clone();
                                    this.inlining_p = wx_p0.inlining_p.clone();
                                    this.result_p = wx_p0.result_p.clone();
                                    this
                                };
                                (back_p1t.clone(), done_p1s.result_p.clone())
                            }
                        }
                    }
                }
            }
        },
    }
}

/// ```prism
/// ?ParamInstance: unbounded fn Ty, Ty, (Text ==> Ty) -> ?(Text ==> Ty)
/// ```
pub fn param_instance_o(pty_p0: &crate::check::types::Ty, aty_p1: &crate::check::types::Ty, m_p2: &crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>) -> ::std::option::Option<crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>> {
    match param_match_o(&unrigid_f(pty_p0), aty_p1, m_p2) {
        ::std::option::Option::Some(found_p3) => ::std::option::Option::Some(found_p3),
        ::std::option::Option::None => param_match_o(&unrigid_f(pty_p0), &crate::lower::types::peel_f(aty_p1), m_p2),
    }
}

/// The step machine of `ParamInstance`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?ParamInstance: unbounded fn Ty, Ty, (Text ==> Ty) -> ?(Text ==> Ty)
/// ```
pub struct ParamInstance {
    pub pty_p0: crate::check::types::Ty,
    pub aty_p1: crate::check::types::Ty,
    pub m_p2: crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>,
}

impl ::prism_rtl::Job<::std::option::Option<crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>>> for ParamInstance {
    fn cycle(&self) -> ::prism_rtl::Turn<::std::option::Option<crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>>> {
        let pty_p0 = &self.pty_p0;
        let aty_p1 = &self.aty_p1;
        let m_p2 = &self.m_p2;
        let aty_p1x = aty_p1.clone();
        let m_p2x = m_p2.clone();
        let pty_p0x = pty_p0.clone();
        crate::prelude::call_then(start_unrigid_f(pty_p0x.clone()), move |unrigid_f_115525: crate::check::types::Ty| crate::prelude::call_then(start_param_match_o(unrigid_f_115525, aty_p1x.clone(), m_p2x.clone()), move |param_match_o_115512: ::std::option::Option<crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>>| match param_match_o_115512 {
            ::std::option::Option::Some(found_p3) => ::prism_rtl::Turn::Finished(::std::option::Option::Some(found_p3.clone())),
            ::std::option::Option::None => crate::prelude::call_then(start_unrigid_f(pty_p0x.clone()), move |unrigid_f_115590: crate::check::types::Ty| ::prism_rtl::Turn::More(::std::rc::Rc::new(ParamMatch { pat_p0: unrigid_f_115590, t_p1: crate::lower::types::peel_f(&aty_p1x), m_p2: m_p2x.clone() }))),
        }))
    }
}

/// `Start ParamInstance, x`: what the function value is when passed to `@Run`.
pub fn start_param_instance_o(pty_p0: crate::check::types::Ty, aty_p1: crate::check::types::Ty, m_p2: crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<::std::option::Option<crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>>>> {
    ::std::rc::Rc::new(ParamInstance { pty_p0, aty_p1, m_p2 })
}

/// ```prism
/// ?ParamMatch: unbounded fn Ty, Ty, (Text ==> Ty) -> ?(Text ==> Ty)
/// ```
pub fn param_match_o(pat_p0: &crate::check::types::Ty, t_p1: &crate::check::types::Ty, m_p2: &crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>) -> ::std::option::Option<crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>> {
    match (pat_p0.clone(), t_p1.clone()) {
        (crate::check::types::Ty::TyQ(v_p3), x_p4) => match crate::prelude::get(m_p2, &v_p3) {
            ::std::option::Option::Some(y_p5) => if &y_p5 == &x_p4 {
                ::std::option::Option::Some(m_p2.clone())
            } else {
                ::std::option::Option::None
            },
            ::std::option::Option::None => ::std::option::Option::Some(crate::prelude::insert(m_p2, &v_p3, &x_p4)),
        },
        (crate::check::types::Ty::TyAt(i1_p6, _), crate::check::types::Ty::TyAt(i2_p7, _)) => param_match_o(&*i1_p6, &*i2_p7, m_p2),
        (crate::check::types::Ty::TyFn(_, ps1_p8, r1_p9), crate::check::types::Ty::TyFn(_, ps2_pa, r2_pb)) => if &crate::prelude::len(&ps1_p8) == &crate::prelude::len(&ps2_pa) {
            param_match_all_o(&crate::prelude::push(&ps1_p8, &*r1_p9), &crate::prelude::push(&ps2_pa, &*r2_pb), m_p2)
        } else {
            ::std::option::Option::None
        },
        (crate::check::types::Ty::TyCon(a_pc, xs_pd), crate::check::types::Ty::TyCon(b_pe, ys_pf)) => if (&a_pc == &b_pe) && (&crate::prelude::len(&xs_pd) == &crate::prelude::len(&ys_pf)) {
            param_match_all_o(&xs_pd, &ys_pf, m_p2)
        } else {
            ::std::option::Option::None
        },
        (crate::check::types::Ty::TyTuple(xs_pg), crate::check::types::Ty::TyTuple(ys_ph)) => if &crate::prelude::len(&xs_pg) == &crate::prelude::len(&ys_ph) {
            param_match_all_o(&xs_pg, &ys_ph, m_p2)
        } else {
            ::std::option::Option::None
        },
        (crate::check::types::Ty::TyArray(x_pi), crate::check::types::Ty::TyArray(y_pj)) => param_match_o(&*x_pi, &*y_pj, m_p2),
        (crate::check::types::Ty::TyMap(k1_pk, v1_pl), crate::check::types::Ty::TyMap(k2_pm, v2_pn)) => param_match_all_o(&crate::prelude::Array::from(vec![(*k1_pk).clone(), (*v1_pl).clone()]), &crate::prelude::Array::from(vec![(*k2_pm).clone(), (*v2_pn).clone()]), m_p2),
        (crate::check::types::Ty::TySig(s1_po, i1_pp), crate::check::types::Ty::TySig(s2_pq, i2_pr)) => if &s1_po == &s2_pq {
            param_match_o(&*i1_pp, &*i2_pr, m_p2)
        } else {
            ::std::option::Option::None
        },
        (crate::check::types::Ty::TyElem(_, o1_ps), crate::check::types::Ty::TyElem(_, o2_pt)) => param_match_o(&*o1_ps, &*o2_pt, m_p2),
        _ => if pat_p0 == t_p1 {
            ::std::option::Option::Some(m_p2.clone())
        } else {
            ::std::option::Option::None
        },
    }
}

/// The step machine of `ParamMatch`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?ParamMatch: unbounded fn Ty, Ty, (Text ==> Ty) -> ?(Text ==> Ty)
/// ```
pub struct ParamMatch {
    pub pat_p0: crate::check::types::Ty,
    pub t_p1: crate::check::types::Ty,
    pub m_p2: crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>,
}

impl ::prism_rtl::Job<::std::option::Option<crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>>> for ParamMatch {
    fn cycle(&self) -> ::prism_rtl::Turn<::std::option::Option<crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>>> {
        let pat_p0 = &self.pat_p0;
        let t_p1 = &self.t_p1;
        let m_p2 = &self.m_p2;
        match (pat_p0.clone(), t_p1.clone()) {
            (crate::check::types::Ty::TyQ(v_p3), x_p4) => match crate::prelude::get(m_p2, &v_p3) {
                ::std::option::Option::Some(y_p5) => if &y_p5 == &x_p4 {
                    ::prism_rtl::Turn::Finished(::std::option::Option::Some(m_p2.clone()))
                } else {
                    ::prism_rtl::Turn::Finished(::std::option::Option::None)
                },
                ::std::option::Option::None => ::prism_rtl::Turn::Finished(::std::option::Option::Some(crate::prelude::insert(m_p2, &v_p3, &x_p4))),
            },
            (crate::check::types::Ty::TyAt(i1_p6, _), crate::check::types::Ty::TyAt(i2_p7, _)) => ::prism_rtl::Turn::More(::std::rc::Rc::new(ParamMatch { pat_p0: (*i1_p6).clone(), t_p1: (*i2_p7).clone(), m_p2: m_p2.clone() })),
            (crate::check::types::Ty::TyFn(_, ps1_p8, r1_p9), crate::check::types::Ty::TyFn(_, ps2_pa, r2_pb)) => if &crate::prelude::len(&ps1_p8) == &crate::prelude::len(&ps2_pa) {
                ::prism_rtl::Turn::More(::std::rc::Rc::new(ParamMatchAll { xs_p0: crate::prelude::push(&ps1_p8, &*r1_p9), ys_p1: crate::prelude::push(&ps2_pa, &*r2_pb), m_p2: m_p2.clone() }))
            } else {
                ::prism_rtl::Turn::Finished(::std::option::Option::None)
            },
            (crate::check::types::Ty::TyCon(a_pc, xs_pd), crate::check::types::Ty::TyCon(b_pe, ys_pf)) => if (&a_pc == &b_pe) && (&crate::prelude::len(&xs_pd) == &crate::prelude::len(&ys_pf)) {
                ::prism_rtl::Turn::More(::std::rc::Rc::new(ParamMatchAll { xs_p0: xs_pd.clone(), ys_p1: ys_pf.clone(), m_p2: m_p2.clone() }))
            } else {
                ::prism_rtl::Turn::Finished(::std::option::Option::None)
            },
            (crate::check::types::Ty::TyTuple(xs_pg), crate::check::types::Ty::TyTuple(ys_ph)) => if &crate::prelude::len(&xs_pg) == &crate::prelude::len(&ys_ph) {
                ::prism_rtl::Turn::More(::std::rc::Rc::new(ParamMatchAll { xs_p0: xs_pg.clone(), ys_p1: ys_ph.clone(), m_p2: m_p2.clone() }))
            } else {
                ::prism_rtl::Turn::Finished(::std::option::Option::None)
            },
            (crate::check::types::Ty::TyArray(x_pi), crate::check::types::Ty::TyArray(y_pj)) => ::prism_rtl::Turn::More(::std::rc::Rc::new(ParamMatch { pat_p0: (*x_pi).clone(), t_p1: (*y_pj).clone(), m_p2: m_p2.clone() })),
            (crate::check::types::Ty::TyMap(k1_pk, v1_pl), crate::check::types::Ty::TyMap(k2_pm, v2_pn)) => ::prism_rtl::Turn::More(::std::rc::Rc::new(ParamMatchAll { xs_p0: crate::prelude::Array::from(vec![(*k1_pk).clone(), (*v1_pl).clone()]), ys_p1: crate::prelude::Array::from(vec![(*k2_pm).clone(), (*v2_pn).clone()]), m_p2: m_p2.clone() })),
            (crate::check::types::Ty::TySig(s1_po, i1_pp), crate::check::types::Ty::TySig(s2_pq, i2_pr)) => if &s1_po == &s2_pq {
                ::prism_rtl::Turn::More(::std::rc::Rc::new(ParamMatch { pat_p0: (*i1_pp).clone(), t_p1: (*i2_pr).clone(), m_p2: m_p2.clone() }))
            } else {
                ::prism_rtl::Turn::Finished(::std::option::Option::None)
            },
            (crate::check::types::Ty::TyElem(_, o1_ps), crate::check::types::Ty::TyElem(_, o2_pt)) => ::prism_rtl::Turn::More(::std::rc::Rc::new(ParamMatch { pat_p0: (*o1_ps).clone(), t_p1: (*o2_pt).clone(), m_p2: m_p2.clone() })),
            _ => if pat_p0 == t_p1 {
                ::prism_rtl::Turn::Finished(::std::option::Option::Some(m_p2.clone()))
            } else {
                ::prism_rtl::Turn::Finished(::std::option::Option::None)
            },
        }
    }
}

/// `Start ParamMatch, x`: what the function value is when passed to `@Run`.
pub fn start_param_match_o(pat_p0: crate::check::types::Ty, t_p1: crate::check::types::Ty, m_p2: crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<::std::option::Option<crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>>>> {
    ::std::rc::Rc::new(ParamMatch { pat_p0, t_p1, m_p2 })
}

/// ```prism
/// ?ParamMatchAll: unbounded fn [Ty], [Ty], (Text ==> Ty) -> ?(Text ==> Ty)
/// ```
pub fn param_match_all_o(xs_p0: &crate::prelude::Array<crate::check::types::Ty>, ys_p1: &crate::prelude::Array<crate::check::types::Ty>, m_p2: &crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>) -> ::std::option::Option<crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>> {
    crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(xs_p0)), ::std::option::Option::Some(m_p2.clone()), {
        let xs_p0x = xs_p0.clone();
        let ys_p1x = ys_p1.clone();
        ::std::rc::Rc::new(move |(p0, p1): (::std::option::Option<crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>>, crate::prelude::Nat)| {
            let xs_p0xy = xs_p0x.clone();
            let ys_p1xy = ys_p1x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_o3 = p0;
                let i_p4 = p1;
                match &acc_o3 {
                    ::std::option::Option::Some(mm_p5) => ::prism_rtl::Turn::More(::std::rc::Rc::new(ParamMatch { pat_p0: crate::prelude::or(&crate::prelude::index(&xs_p0xy, &i_p4), &crate::check::types::Ty::TyErr), t_p1: crate::prelude::or(&crate::prelude::index(&ys_p1xy, &i_p4), &crate::check::types::Ty::TyErr), m_p2: mm_p5.clone() })),
                    ::std::option::Option::None => ::prism_rtl::Turn::Finished(::std::option::Option::None),
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((::std::option::Option<crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>>, crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<::std::option::Option<crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>>>>>
    }))
}

/// The step machine of `ParamMatchAll`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?ParamMatchAll: unbounded fn [Ty], [Ty], (Text ==> Ty) -> ?(Text ==> Ty)
/// ```
pub struct ParamMatchAll {
    pub xs_p0: crate::prelude::Array<crate::check::types::Ty>,
    pub ys_p1: crate::prelude::Array<crate::check::types::Ty>,
    pub m_p2: crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>,
}

impl ::prism_rtl::Job<::std::option::Option<crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>>> for ParamMatchAll {
    fn cycle(&self) -> ::prism_rtl::Turn<::std::option::Option<crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>>> {
        let xs_p0 = &self.xs_p0;
        let ys_p1 = &self.ys_p1;
        let m_p2 = &self.m_p2;
        crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(xs_p0)), ::std::option::Option::Some(m_p2.clone()), {
            let xs_p0x = xs_p0.clone();
            let ys_p1x = ys_p1.clone();
            ::std::rc::Rc::new(move |(p0, p1): (::std::option::Option<crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>>, crate::prelude::Nat)| {
                let xs_p0xy = xs_p0x.clone();
                let ys_p1xy = ys_p1x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let acc_o3 = p0;
                    let i_p4 = p1;
                    match &acc_o3 {
                        ::std::option::Option::Some(mm_p5) => ::prism_rtl::Turn::More(::std::rc::Rc::new(ParamMatch { pat_p0: crate::prelude::or(&crate::prelude::index(&xs_p0xy, &i_p4), &crate::check::types::Ty::TyErr), t_p1: crate::prelude::or(&crate::prelude::index(&ys_p1xy, &i_p4), &crate::check::types::Ty::TyErr), m_p2: mm_p5.clone() })),
                        ::std::option::Option::None => ::prism_rtl::Turn::Finished(::std::option::Option::None),
                    }
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((::std::option::Option<crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>>, crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<::std::option::Option<crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>>>>>
        }).cycle()
    }
}

/// `Start ParamMatchAll, x`: what the function value is when passed to `@Run`.
pub fn start_param_match_all_o(xs_p0: crate::prelude::Array<crate::check::types::Ty>, ys_p1: crate::prelude::Array<crate::check::types::Ty>, m_p2: crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<::std::option::Option<crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>>>> {
    ::std::rc::Rc::new(ParamMatchAll { xs_p0, ys_p1, m_p2 })
}

/// ```prism
/// RigidsIn: unbounded fn Ty -> [Text]
/// ```
pub fn rigids_in_f(t_p0: &crate::check::types::Ty) -> crate::prelude::Array<crate::prelude::Text> {
    match t_p0 {
        crate::check::types::Ty::TyRigid(n_p1) => crate::prelude::Array::from(vec![n_p1.clone()]),
        crate::check::types::Ty::TyQ(n_p2) => crate::prelude::Array::from(vec![n_p2.clone()]),
        crate::check::types::Ty::TyCon(_, args_p3) => crate::prelude::run_to_end(crate::prelude::fold_job(args_p3.clone(), crate::prelude::Array::new(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::check::types::Ty)| crate::prelude::entered(crate::prelude::once_job(move || {
            let acc_p4 = p0;
            let a_p5 = p1;
            crate::prelude::call_then(start_rigids_in_f(a_p5.clone()), move |rigids_in_f_117377: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_p4, &rigids_in_f_117377)))
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::check::types::Ty)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>)),
        crate::check::types::Ty::TyTuple(ts_p6) => crate::prelude::run_to_end(crate::prelude::fold_job(ts_p6.clone(), crate::prelude::Array::new(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::check::types::Ty)| crate::prelude::entered(crate::prelude::once_job(move || {
            let acc_p7 = p0;
            let a_p8 = p1;
            crate::prelude::call_then(start_rigids_in_f(a_p8.clone()), move |rigids_in_f_117447: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_p7, &rigids_in_f_117447)))
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::check::types::Ty)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>)),
        crate::check::types::Ty::TyArray(e_p9) => rigids_in_f(&**e_p9),
        crate::check::types::Ty::TyMap(k_pa, v_pb) => crate::check::types::union_texts_f(&rigids_in_f(&**k_pa), &rigids_in_f(&**v_pb)),
        crate::check::types::Ty::TySig(_, i_pc) => rigids_in_f(&**i_pc),
        crate::check::types::Ty::TyAt(i_pd, _) => rigids_in_f(&**i_pd),
        crate::check::types::Ty::TyElem(_, o_pe) => rigids_in_f(&**o_pe),
        crate::check::types::Ty::TyFn(_, ps_pf, r_pg) => crate::prelude::run_to_end(crate::prelude::fold_job(ps_pf.clone(), rigids_in_f(&**r_pg), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::check::types::Ty)| crate::prelude::entered(crate::prelude::once_job(move || {
            let acc_ph = p0;
            let a_pi = p1;
            crate::prelude::call_then(start_rigids_in_f(a_pi.clone()), move |rigids_in_f_117709: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_ph, &rigids_in_f_117709)))
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::check::types::Ty)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>)),
        _ => crate::prelude::Array::new(),
    }
}

/// The step machine of `RigidsIn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RigidsIn: unbounded fn Ty -> [Text]
/// ```
pub struct RigidsIn {
    pub t_p0: crate::check::types::Ty,
}

impl ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>> for RigidsIn {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<crate::prelude::Text>> {
        let t_p0 = &self.t_p0;
        match t_p0 {
            crate::check::types::Ty::TyRigid(n_p1) => ::prism_rtl::Turn::Finished(crate::prelude::Array::from(vec![n_p1.clone()])),
            crate::check::types::Ty::TyQ(n_p2) => ::prism_rtl::Turn::Finished(crate::prelude::Array::from(vec![n_p2.clone()])),
            crate::check::types::Ty::TyCon(_, args_p3) => crate::prelude::fold_job(args_p3.clone(), crate::prelude::Array::new(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::check::types::Ty)| crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_p4 = p0;
                let a_p5 = p1;
                crate::prelude::call_then(start_rigids_in_f(a_p5.clone()), move |rigids_in_f_117377: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_p4, &rigids_in_f_117377)))
            }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::check::types::Ty)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>).cycle(),
            crate::check::types::Ty::TyTuple(ts_p6) => crate::prelude::fold_job(ts_p6.clone(), crate::prelude::Array::new(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::check::types::Ty)| crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_p7 = p0;
                let a_p8 = p1;
                crate::prelude::call_then(start_rigids_in_f(a_p8.clone()), move |rigids_in_f_117447: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_p7, &rigids_in_f_117447)))
            }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::check::types::Ty)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>).cycle(),
            crate::check::types::Ty::TyArray(e_p9) => ::prism_rtl::Turn::More(::std::rc::Rc::new(RigidsIn { t_p0: (**e_p9).clone() })),
            crate::check::types::Ty::TyMap(k_pa, v_pb) => {
                let k_pax = (**k_pa).clone();
                let v_pbx = (**v_pb).clone();
                crate::prelude::call_then(start_rigids_in_f(k_pax.clone()), move |rigids_in_f_117513: crate::prelude::Array<crate::prelude::Text>| crate::prelude::call_then(start_rigids_in_f(v_pbx.clone()), move |rigids_in_f_117527: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&rigids_in_f_117513, &rigids_in_f_117527))))
            },
            crate::check::types::Ty::TySig(_, i_pc) => ::prism_rtl::Turn::More(::std::rc::Rc::new(RigidsIn { t_p0: (**i_pc).clone() })),
            crate::check::types::Ty::TyAt(i_pd, _) => ::prism_rtl::Turn::More(::std::rc::Rc::new(RigidsIn { t_p0: (**i_pd).clone() })),
            crate::check::types::Ty::TyElem(_, o_pe) => ::prism_rtl::Turn::More(::std::rc::Rc::new(RigidsIn { t_p0: (**o_pe).clone() })),
            crate::check::types::Ty::TyFn(_, ps_pf, r_pg) => {
                let ps_pfx = ps_pf.clone();
                let r_pgx = (**r_pg).clone();
                crate::prelude::call_then(start_rigids_in_f(r_pgx.clone()), move |rigids_in_f_117669: crate::prelude::Array<crate::prelude::Text>| crate::prelude::fold_job(ps_pfx.clone(), rigids_in_f_117669, ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::check::types::Ty)| crate::prelude::entered(crate::prelude::once_job(move || {
                    let acc_ph = p0;
                    let a_pi = p1;
                    crate::prelude::call_then(start_rigids_in_f(a_pi.clone()), move |rigids_in_f_117709: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_ph, &rigids_in_f_117709)))
                }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::check::types::Ty)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>).cycle())
            },
            _ => ::prism_rtl::Turn::Finished(crate::prelude::Array::new()),
        }
    }
}

/// `Start RigidsIn, x`: what the function value is when passed to `@Run`.
pub fn start_rigids_in_f(t_p0: crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>> {
    ::std::rc::Rc::new(RigidsIn { t_p0 })
}

/// ```prism
/// Unrigid: unbounded fn Ty -> Ty
/// ```
pub fn unrigid_f(t_p0: &crate::check::types::Ty) -> crate::check::types::Ty {
    match t_p0 {
        crate::check::types::Ty::TyRigid(n_p1) => crate::check::types::Ty::TyQ(n_p1.clone()),
        crate::check::types::Ty::TyCon(n_p2, args_p3) => crate::check::types::Ty::TyCon(n_p2.clone(), crate::prelude::run_to_end(crate::prelude::each_job(args_p3.clone(), ::std::rc::Rc::new(move |p0: crate::check::types::Ty| crate::prelude::entered(crate::prelude::once_job(move || {
            let a_p4 = p0;
            ::prism_rtl::Turn::More(::std::rc::Rc::new(Unrigid { t_p0: a_p4.clone() }))
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::Ty>>>))),
        crate::check::types::Ty::TyTuple(ts_p5) => crate::check::types::Ty::TyTuple(crate::prelude::run_to_end(crate::prelude::each_job(ts_p5.clone(), ::std::rc::Rc::new(move |p0: crate::check::types::Ty| crate::prelude::entered(crate::prelude::once_job(move || {
            let a_p6 = p0;
            ::prism_rtl::Turn::More(::std::rc::Rc::new(Unrigid { t_p0: a_p6.clone() }))
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::Ty>>>))),
        crate::check::types::Ty::TyArray(e_p7) => crate::check::types::Ty::TyArray(::std::rc::Rc::new(unrigid_f(&**e_p7))),
        crate::check::types::Ty::TyMap(k_p8, v_p9) => crate::check::types::Ty::TyMap(::std::rc::Rc::new(unrigid_f(&**k_p8)), ::std::rc::Rc::new(unrigid_f(&**v_p9))),
        crate::check::types::Ty::TySig(s_pa, i_pb) => crate::check::types::Ty::TySig(s_pa.clone(), ::std::rc::Rc::new(unrigid_f(&**i_pb))),
        crate::check::types::Ty::TyElem(rw_pc, o_pd) => crate::check::types::Ty::TyElem(rw_pc.clone(), ::std::rc::Rc::new(unrigid_f(&**o_pd))),
        crate::check::types::Ty::TyAt(i_pe, rw_pf) => crate::check::types::Ty::TyAt(::std::rc::Rc::new(unrigid_f(&**i_pe)), rw_pf.clone()),
        crate::check::types::Ty::TyFn(c_pg, ps_ph, r_pi) => crate::check::types::Ty::TyFn(c_pg.clone(), crate::prelude::run_to_end(crate::prelude::each_job(ps_ph.clone(), ::std::rc::Rc::new(move |p0: crate::check::types::Ty| crate::prelude::entered(crate::prelude::once_job(move || {
            let a_pj = p0;
            ::prism_rtl::Turn::More(::std::rc::Rc::new(Unrigid { t_p0: a_pj.clone() }))
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::Ty>>>)), ::std::rc::Rc::new(unrigid_f(&**r_pi))),
        other_pk => other_pk.clone(),
    }
}

/// The step machine of `Unrigid`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Unrigid: unbounded fn Ty -> Ty
/// ```
pub struct Unrigid {
    pub t_p0: crate::check::types::Ty,
}

impl ::prism_rtl::Job<crate::check::types::Ty> for Unrigid {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::types::Ty> {
        let t_p0 = &self.t_p0;
        match t_p0 {
            crate::check::types::Ty::TyRigid(n_p1) => ::prism_rtl::Turn::Finished(crate::check::types::Ty::TyQ(n_p1.clone())),
            crate::check::types::Ty::TyCon(n_p2, args_p3) => {
                let args_p3x = args_p3.clone();
                let n_p2x = n_p2.clone();
                crate::prelude::call_value(crate::prelude::each_job(args_p3x.clone(), ::std::rc::Rc::new(move |p0: crate::check::types::Ty| crate::prelude::entered(crate::prelude::once_job(move || {
                    let a_p4 = p0;
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(Unrigid { t_p0: a_p4.clone() }))
                }))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::Ty>>>), move |each_117935: crate::prelude::Array<crate::check::types::Ty>| ::prism_rtl::Turn::Finished(crate::check::types::Ty::TyCon(n_p2x.clone(), each_117935)))
            },
            crate::check::types::Ty::TyTuple(ts_p5) => {
                let ts_p5x = ts_p5.clone();
                crate::prelude::call_value(crate::prelude::each_job(ts_p5x.clone(), ::std::rc::Rc::new(move |p0: crate::check::types::Ty| crate::prelude::entered(crate::prelude::once_job(move || {
                    let a_p6 = p0;
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(Unrigid { t_p0: a_p6.clone() }))
                }))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::Ty>>>), move |each_117987: crate::prelude::Array<crate::check::types::Ty>| ::prism_rtl::Turn::Finished(crate::check::types::Ty::TyTuple(each_117987)))
            },
            crate::check::types::Ty::TyArray(e_p7) => {
                let e_p7x = (**e_p7).clone();
                crate::prelude::call_then(start_unrigid_f(e_p7x.clone()), move |unrigid_f_118036: crate::check::types::Ty| ::prism_rtl::Turn::Finished(crate::check::types::Ty::TyArray(::std::rc::Rc::new(unrigid_f_118036))))
            },
            crate::check::types::Ty::TyMap(k_p8, v_p9) => {
                let k_p8x = (**k_p8).clone();
                let v_p9x = (**v_p9).clone();
                crate::prelude::call_then(start_unrigid_f(k_p8x.clone()), move |unrigid_f_118070: crate::check::types::Ty| crate::prelude::call_then(start_unrigid_f(v_p9x.clone()), move |unrigid_f_118083: crate::check::types::Ty| ::prism_rtl::Turn::Finished(crate::check::types::Ty::TyMap(::std::rc::Rc::new(unrigid_f_118070), ::std::rc::Rc::new(unrigid_f_118083)))))
            },
            crate::check::types::Ty::TySig(s_pa, i_pb) => {
                let i_pbx = (**i_pb).clone();
                let s_pax = s_pa.clone();
                crate::prelude::call_then(start_unrigid_f(i_pbx.clone()), move |unrigid_f_118120: crate::check::types::Ty| ::prism_rtl::Turn::Finished(crate::check::types::Ty::TySig(s_pax.clone(), ::std::rc::Rc::new(unrigid_f_118120))))
            },
            crate::check::types::Ty::TyElem(rw_pc, o_pd) => {
                let o_pdx = (**o_pd).clone();
                let rw_pcx = rw_pc.clone();
                crate::prelude::call_then(start_unrigid_f(o_pdx.clone()), move |unrigid_f_118161: crate::check::types::Ty| ::prism_rtl::Turn::Finished(crate::check::types::Ty::TyElem(rw_pcx.clone(), ::std::rc::Rc::new(unrigid_f_118161))))
            },
            crate::check::types::Ty::TyAt(i_pe, rw_pf) => {
                let i_pex = (**i_pe).clone();
                let rw_pfx = rw_pf.clone();
                crate::prelude::call_then(start_unrigid_f(i_pex.clone()), move |unrigid_f_118194: crate::check::types::Ty| ::prism_rtl::Turn::Finished(crate::check::types::Ty::TyAt(::std::rc::Rc::new(unrigid_f_118194), rw_pfx.clone())))
            },
            crate::check::types::Ty::TyFn(c_pg, ps_ph, r_pi) => {
                let c_pgx = c_pg.clone();
                let ps_phx = ps_ph.clone();
                let r_pix = (**r_pi).clone();
                crate::prelude::call_value(crate::prelude::each_job(ps_phx.clone(), ::std::rc::Rc::new(move |p0: crate::check::types::Ty| crate::prelude::entered(crate::prelude::once_job(move || {
                    let a_pj = p0;
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(Unrigid { t_p0: a_pj.clone() }))
                }))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::Ty>>>), move |each_118237: crate::prelude::Array<crate::check::types::Ty>| crate::prelude::call_then(start_unrigid_f(r_pix.clone()), move |unrigid_f_118264: crate::check::types::Ty| ::prism_rtl::Turn::Finished(crate::check::types::Ty::TyFn(c_pgx.clone(), each_118237, ::std::rc::Rc::new(unrigid_f_118264)))))
            },
            other_pk => ::prism_rtl::Turn::Finished(other_pk.clone()),
        }
    }
}

/// `Start Unrigid, x`: what the function value is when passed to `@Run`.
pub fn start_unrigid_f(t_p0: crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::Ty>> {
    ::std::rc::Rc::new(Unrigid { t_p0 })
}

/// ```prism
/// WithRecursing: fn Lx, Text -> Lx
/// ```
pub fn with_recursing_f(lx_p0: &crate::lower::Lx, qk_p1: &crate::prelude::Text) -> crate::lower::Lx {
    let mut this: crate::lower::Lx = lx_p0.clone();
    this.recursing_p = crate::check::types::add_text_f(&this.recursing_p, qk_p1);
    this
}

/// ```prism
/// Recursion: fn [Text], Text -> Nat
/// ```
pub fn recursion_f(inlining_p0: &crate::prelude::Array<crate::prelude::Text>, qk_p1: &crate::prelude::Text) -> crate::prelude::Nat {
    crate::prelude::fold(inlining_p0, &crate::prelude::Nat::from(0u32), &(|n_p2: &crate::prelude::Nat, k_p3: &crate::prelude::Text| if k_p3 == qk_p1 { n_p2 + &crate::prelude::Nat::from(1u32) } else { n_p2.clone() }))
}

/// ```prism
/// TooDeep: unbounded fn Wx, Text, Expr -> ((Wx, Wres))
/// ```
pub fn too_deep_f(wx_p0: &crate::lower::node_::Wx, qk_p1: &crate::prelude::Text, e_p2: &crate::syntax::Expr) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    let lx_p3 = wx_p0.lx_p.clone();
    let what_p4 = crate::prelude::Text::from(format!("`{}` recurses deeper than the compiler inlines it (16 levels)", &crate::check::types::bare_name_f(qk_p1)));
    let wx1_p5 = {
        let mut this: crate::lower::node_::Wx = wx_p0.clone();
        this.build_p = crate::prelude::push(&this.build_p, &crate::lower::model::Do::DoReturn(crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Err")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Fault::too_deep")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XStr(what_p4.clone())]))]))));
        this.fallible_p = true;
        this
    };
    let t_p6 = crate::lower::types::out_ty_of_f(&lx_p3, &crate::lower::types::out_of_f(&crate::lower::type_at_f(&lx_p3, &e_p2.span_p)));
    let called_p7 = match crate::lower::type_at_f(&lx_p3, &e_p2.span_p) {
        crate::check::types::Ty::TyAt(i_p8, _) => (*i_p8).clone(),
        other_p9 => other_p9,
    };
    match crate::lower::types::layer_of_f(&called_p7) {
        crate::lower::types::Layer::LyDyn => (wx1_p5.clone(), crate::lower::node_::Wres::WrDyn(crate::lower::model::Ex::XUnreachable, crate::prelude::Array::new(), t_p6.clone())),
        crate::lower::types::Layer::LyEv => {
            let (id_pa, wx2_pb) = crate::lower::node_::add_gn_f(&wx1_p5, &crate::prelude::Text::lit("too_deep"), &t_p6, &crate::lower::node_::GnKind::GnNever, &crate::prelude::Nat::from(0u32));
            (wx2_pb.clone(), crate::lower::node_::Wres::WrEv(crate::lower::node_::ev_ref_of_f(&wx2_pb, &id_pa)))
        },
        _ => if &t_p6 == &crate::lower::model::OutTy::OutUnit {
            (wx1_p5.clone(), crate::lower::node_::Wres::WrUnit)
        } else {
            {
                let wx2_pc = {
                    let mut this: crate::lower::node_::Wx = wx1_p5.clone();
                    this.lets_p = crate::prelude::push(&this.lets_p, &crate::lower::model::Do::DoReturn(crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Err")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Fault::too_deep")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XStr(what_p4.clone())]))]))));
                    this
                };
                (wx2_pc.clone(), crate::lower::node_::Wres::WrPlain(crate::lower::model::Ex::XUnreachable, t_p6.clone()))
            }
        },
    }
}

/// ```prism
/// ?WidgetDeclOf: fn G, Text -> ?WidgetDecl
/// ```
pub fn widget_decl_of_o(g_p0: &crate::check::env::G, qk_p1: &crate::prelude::Text) -> ::std::option::Option<crate::syntax::decls::WidgetDecl> {
    crate::prelude::fold(&g_p0.defs_p, &::std::option::Option::None, &(|found_o2: &::std::option::Option<crate::syntax::decls::WidgetDecl>, d_p3: &crate::check::env::Def| if &d_p3.qk_p == qk_p1 { def_widget_o(d_p3, found_o2) } else { found_o2.clone() }))
}

/// ```prism
/// ?DefWidget: fn Def, ?WidgetDecl -> ?WidgetDecl
/// ```
pub fn def_widget_o(d_p0: &crate::check::env::Def, other_o1: &::std::option::Option<crate::syntax::decls::WidgetDecl>) -> ::std::option::Option<crate::syntax::decls::WidgetDecl> {
    match &d_p0.body_p {
        crate::check::env::DefBody::DbWidget(w_p2) => ::std::option::Option::Some(w_p2.clone()),
        _ => other_o1.clone(),
    }
}

/// ```prism
/// IsWidgetFnTy: fn Ty -> Bool
/// ```
pub fn is_widget_fn_ty_f(t_p0: &crate::check::types::Ty) -> bool {
    match t_p0 {
        crate::check::types::Ty::TyFn(_, _, r_p1) => crate::lower::node_::def::is_widget_ty_f(&**r_p1),
        _ => false,
    }
}

/// ```prism
/// BindParam: unbounded fn Wx, Env, Env, Env, Env, Text, Text, Ty, Expr -> ((Wx, Env, Env))
/// ```
pub fn bind_param_f(wx_p0: &crate::lower::node_::Wx, cbenv_p1: &crate::lower::types::Env, cmenv_p2: &crate::lower::types::Env, be_p3: &crate::lower::types::Env, me_p4: &crate::lower::types::Env, nkey_p5: &crate::prelude::Text, spelled_p6: &crate::prelude::Text, pty_p7: &crate::check::types::Ty, arg_p8: &crate::syntax::Expr) -> (crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env) {
    let lx_p9 = wx_p0.lx_p.clone();
    let t_pa = crate::lower::types::out_ty_of_f(&lx_p9, &crate::lower::types::peel_f(pty_p7));
    if is_widget_fn_ty_f(pty_p7) {
        {
            let b_pb = crate::lower::types::Bn::BnWidget(arg_p8.clone(), cbenv_p1.clone(), cmenv_p2.clone(), lx_p9.clone());
            (wx_p0.clone(), crate::lower::types::bind_f(be_p3, nkey_p5, &b_pb), crate::lower::types::bind_f(me_p4, nkey_p5, &b_pb))
        }
    } else {
        match crate::lower::types::layer_of_f(pty_p7) {
            crate::lower::types::Layer::LyBlueprint => {
                let b_pc = crate::lower::types::Bn::BnWidget(arg_p8.clone(), cbenv_p1.clone(), cmenv_p2.clone(), lx_p9.clone());
                (wx_p0.clone(), crate::lower::types::bind_f(be_p3, nkey_p5, &b_pc), crate::lower::types::bind_f(me_p4, nkey_p5, &b_pc))
            },
            crate::lower::types::Layer::LyEv => {
                let (r_pd, wx2_pe) = crate::lower::node_::dynamics::event_ref_f(wx_p0, cmenv_p2, arg_p8);
                bind_event_param_f(&wx2_pe, be_p3, me_p4, nkey_p5, spelled_p6, pty_p7, &r_pd)
            },
            crate::lower::types::Layer::LyDyn => {
                let (ex_pg, reads_ph) = crate::lower::node_::dynamics::dynamic_expr_f(wx_p0, cmenv_p2, arg_p8);
                let b_pf = crate::lower::types::Bn::BnDyn(ex_pg.clone(), reads_ph.clone(), t_pa.clone());
                let (wx0_pl, be0_pm) = if crate::lower::node_::def::all_inited_f(wx_p0, &reads_ph) && crate::lower::node_::def::names_inited_f(cbenv_p1, arg_p8) {
                    {
                        let (rsi_pj, wxi_pk) = crate::lower::node_::fresh_name_f(wx_p0, &crate::prelude::Text::from(format!("{}_arg", spelled_p6)));
                        let wxj_pi = {
                            let mut this: crate::lower::node_::Wx = wxi_pk.clone();
                            this.lets_p = crate::prelude::push(&this.lets_p, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaBind(crate::prelude::Text::from(format!("{}_init", &rsi_pj)))), t_pa.clone()), crate::lower::types::own_f(&crate::lower::expr::value_of_f(&lx_p9, &crate::lower::node_::def::init_env_f(cbenv_p1), arg_p8))));
                            this.inited_p = crate::prelude::push(&this.inited_p, &rsi_pj);
                            this
                        };
                        (wxj_pi.clone(), crate::lower::types::bind_f(be_p3, &crate::prelude::Text::from(format!("{}#init", nkey_p5)), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(crate::prelude::Text::from(format!("{}_init", &rsi_pj))), crate::lower::types::Holding::Owned, t_pa.clone())))
                    }
                } else {
                    (wx_p0.clone(), be_p3.clone())
                };
                'm122660: {
                    if let crate::lower::model::Ex::XMethod(m122660_0_0, _, _) = &ex_pg && let crate::lower::model::Ex::XSelf = &**m122660_0_0 {
                        break 'm122660 (wx0_pl.clone(), crate::lower::types::bind_f(&be0_pm, nkey_p5, &b_pf), crate::lower::types::bind_f(me_p4, nkey_p5, &b_pf));
                    }
                    {
                        let (rs_pq, wx2_pr) = crate::lower::node_::fresh_name_f(&wx0_pl, spelled_p6);
                        let getter_pn = crate::lower::model::MethDef { name_p: rs_pq.clone(), recv_p: crate::lower::model::Recv::RecvRef, params_p: crate::prelude::Array::new(), cx_p: crate::lower::model::CxArg::CxRef, ret_p: t_pa.clone(), body_p: crate::prelude::Array::new(), tail_p: ex_pg.clone(), doc_p: crate::prelude::Text::from(format!("`{}`, a widget\'s parameter, as its rows read it", nkey_p5)) };
                        let wx3_po = {
                            let mut this: crate::lower::node_::Wx = wx2_pr.clone();
                            this.getters_p = crate::prelude::push(&this.getters_p, &getter_pn);
                            this.dyn_reads_p = crate::prelude::insert(&this.dyn_reads_p, &rs_pq, &reads_ph);
                            this
                        };
                        let rb_pp = crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), rs_pq.clone(), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCx])), crate::prelude::Array::from(vec![crate::lower::node_::Read::OwnRead(rs_pq.clone())]), t_pa.clone());
                        (wx3_po.clone(), crate::lower::types::bind_f(&crate::lower::types::bind_f(&be0_pm, nkey_p5, &b_pf), &crate::prelude::Text::from(format!("{}#row", nkey_p5)), &rb_pp), crate::lower::types::bind_f(&crate::lower::types::bind_f(me_p4, nkey_p5, &b_pf), &crate::prelude::Text::from(format!("{}#row", nkey_p5)), &rb_pp))
                    }
                }
            },
            _ => {
                let (rs_pt, wx2a_pu) = crate::lower::node_::fresh_name_f(wx_p0, spelled_p6);
                let (v_p12, wx2_p13) = match &*ungrouped_f(arg_p8).kind_p {
                    crate::syntax::ExprKind::ETuple(_) if crate::lower::types::time_within_f(pty_p7) => match crate::lower::node_::def::whole_written_of_f(&wx2a_pu, cbenv_p1, cmenv_p2, arg_p8) {
                        (crate::lower::node_::Wres::WrPlain(ex_pv, _), w_p10) => (ex_pv, w_p10),
                        (_, w_p11) => (crate::lower::expr::internal_bug_f(&crate::prelude::Text::lit("a tuple that holds time, written as a widget\'s argument, that is no one value")), w_p11),
                    },
                    _ => (crate::lower::types::own_f(&crate::lower::expr::value_of_f(&lx_p9, cbenv_p1, arg_p8)), wx2a_pu.clone()),
                    _ => unreachable!("no arm matched"),
                };
                let wx3_ps = {
                    let mut this: crate::lower::node_::Wx = wx2_p13.clone();
                    this.lets_p = crate::prelude::push(&this.lets_p, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(rs_pt.clone()), v_p12.clone()));
                    this.fields_p = crate::prelude::push(&this.fields_p, &(rs_pt.clone(), t_pa.clone(), crate::prelude::Text::from(format!("`{}`", nkey_p5))));
                    this.inits_p = crate::prelude::push(&this.inits_p, &(rs_pt.clone(), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(rs_pt.clone())))));
                    this
                };
                let (be2_p14, me2_p15) = crate::lower::node_::bind_plain_f(be_p3, me_p4, nkey_p5, &rs_pt, &t_pa);
                (wx3_ps.clone(), be2_p14.clone(), me2_p15.clone())
            },
        }
    }
}

/// ```prism
/// BindEventParam: unbounded fn Wx, Env, Env, Text, Text, Ty, EvRef -> ((Wx, Env, Env))
/// ```
pub fn bind_event_param_f(wx2_p0: &crate::lower::node_::Wx, be_p1: &crate::lower::types::Env, me_p2: &crate::lower::types::Env, nkey_p3: &crate::prelude::Text, spelled_p4: &crate::prelude::Text, pty_p5: &crate::check::types::Ty, r_p6: &crate::lower::node_::EvRef) -> (crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env) {
    let lx_p7 = wx2_p0.lx_p.clone();
    let b_p8 = crate::lower::types::Bn::BnEv(r_p6.clone(), crate::lower::types::out_ty_of_f(&lx_p7, &crate::lower::types::peel_f(pty_p5)));
    let et_p9 = crate::lower::types::out_ty_of_f(&lx_p7, &crate::lower::types::peel_f(&crate::lower::types::peel_f(pty_p5)));
    let (rs_pd, wx3_pe) = crate::lower::node_::fresh_name_f(wx2_p0, &crate::prelude::Text::from(format!("{}_arg_v", spelled_p4)));
    let pf_pa = crate::prelude::Text::from(format!("{}_port", &rs_pd));
    let pt_pb = crate::lower::model::OutTy::OutRc(::std::rc::Rc::new(crate::lower::model::OutTy::OutPort(::std::rc::Rc::new(et_p9.clone()))));
    let wx4_pc = {
        let mut this: crate::lower::node_::Wx = crate::lower::node_::connect_f(&wx3_pe, r_p6, &crate::lower::node_::Sk::SkPort(rs_pd.clone()));
        this.taken_p = crate::prelude::push(&this.taken_p, &pf_pa);
        this.lets_p = crate::prelude::push(&this.lets_p, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaBind(pf_pa.clone())), pt_pb.clone()), crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Rc::new")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Port::new")), crate::prelude::Array::new())]))));
        this.fields_p = crate::prelude::push(&this.fields_p, &(pf_pa.clone(), pt_pb.clone(), crate::prelude::Text::from(format!("`{}` as a value: the port it fires", nkey_p3))));
        this.moves_p = crate::prelude::push(&this.moves_p, &(pf_pa.clone(), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(pf_pa.clone())))));
        this
    };
    (wx4_pc.clone(), crate::lower::types::bind_f(&crate::lower::types::bind_f(be_p1, nkey_p3, &b_p8), &crate::prelude::Text::from(format!("{}#port", nkey_p3)), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(pf_pa.clone()), crate::lower::types::Holding::Owned, pt_pb.clone())), crate::lower::types::bind_f(&crate::lower::types::bind_f(me_p2, nkey_p3, &b_p8), &crate::prelude::Text::from(format!("{}#port", nkey_p3)), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), pf_pa.clone()), crate::lower::types::Holding::Owned, pt_pb.clone())))
}

/// ```prism
/// BindParamPattern: unbounded fn Wx, Env, Env, Env, Env, Lx, Pattern, Ty, Expr -> ((Wx, Env, Env))
/// ```
pub fn bind_param_pattern_f(wx_p0: &crate::lower::node_::Wx, cbenv_p1: &crate::lower::types::Env, cmenv_p2: &crate::lower::types::Env, be_p3: &crate::lower::types::Env, me_p4: &crate::lower::types::Env, lxc_p5: &crate::lower::Lx, p_p6: &crate::syntax::Pattern, pty_p7: &crate::check::types::Ty, arg_p8: &crate::syntax::Expr) -> (crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env) {
    match &*p_p6.kind_p {
        crate::syntax::PatternKind::PGroup(q_p9) => bind_param_pattern_f(wx_p0, cbenv_p1, cmenv_p2, be_p3, me_p4, lxc_p5, &**q_p9, pty_p7, arg_p8),
        crate::syntax::PatternKind::PIgnore => (wx_p0.clone(), be_p3.clone(), me_p4.clone()),
        _ => {
            let nkey_pa = crate::lower::functions::plain_binder_f(lxc_p5, p_p6);
            if &nkey_pa != &crate::prelude::Text::lit("") {
                bind_param_f(wx_p0, cbenv_p1, cmenv_p2, be_p3, me_p4, &nkey_pa, &crate::lower::local_name_at_f(lxc_p5, &nkey_pa, &p_p6.span_p), pty_p7, arg_p8)
            } else {
                if crate::lower::types::is_bundle_f(&crate::lower::types::peel_f(pty_p7)) {
                    bind_bundle_param_f(wx_p0, cbenv_p1, cmenv_p2, be_p3, me_p4, lxc_p5, p_p6, &crate::lower::types::peel_f(pty_p7), arg_p8)
                } else {
                    if pattern_binds_time_f(lxc_p5, p_p6) {
                        bind_time_pattern_param_f(wx_p0, cbenv_p1, cmenv_p2, be_p3, me_p4, lxc_p5, p_p6, arg_p8)
                    } else {
                        bind_plain_pattern_param_f(wx_p0, cbenv_p1, be_p3, me_p4, lxc_p5, p_p6, pty_p7, arg_p8)
                    }
                }
            }
        },
    }
}

/// ```prism
/// PatternBindsTime: unbounded fn Lx, Pattern -> Bool
/// ```
pub fn pattern_binds_time_f(lxc_p0: &crate::lower::Lx, p_p1: &crate::syntax::Pattern) -> bool {
    crate::prelude::fold(&crate::lower::node_::def::binder_names_f(p_p1), &false, &(|found_p2: &bool, n_p3: &crate::syntax::SName| (*found_p2 || crate::lower::node_::def::is_time_name_f(&crate::check::env::sname_key_f(n_p3))) || crate::lower::types::time_within_f(&crate::lower::binder_ty_f(lxc_p0, &n_p3.span_p))))
}

/// ```prism
/// BindTimePatternParam: unbounded fn Wx, Env, Env, Env, Env, Lx, Pattern, Expr -> ((Wx, Env, Env))
/// ```
pub fn bind_time_pattern_param_f(wx_p0: &crate::lower::node_::Wx, cbenv_p1: &crate::lower::types::Env, cmenv_p2: &crate::lower::types::Env, be_p3: &crate::lower::types::Env, me_p4: &crate::lower::types::Env, lxc_p5: &crate::lower::Lx, p_p6: &crate::syntax::Pattern, arg_p7: &crate::syntax::Expr) -> (crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env) {
    let lx_p8 = wx_p0.lx_p.clone();
    let (named_pi, be1_pj, me1_pk) = crate::prelude::run_to_end(crate::prelude::fold_job(crate::lower::node_::def::binder_names_f(p_p6), ({
        let mut this: crate::lower::node_::Wx = wx_p0.clone();
        this.lx_p = lxc_p5.clone();
        this
    }, be_p3.clone(), me_p4.clone()), {
        let lxc_p5x = lxc_p5.clone();
        ::std::rc::Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::syntax::SName)| {
            let lxc_p5xy = lxc_p5x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (w_pa, b_pb, m_pc) = p0;
                let n_pd = p1;
                {
                    let full_pe = crate::lower::binder_ty_f(&lxc_p5xy, &n_pd.span_p);
                    if crate::lower::types::is_bundle_f(&full_pe) {
                        crate::prelude::call_then(crate::lower::start_local_name_at_f(lxc_p5xy.clone(), crate::check::env::sname_key_f(&n_pd), n_pd.span_p.clone()), move |local_name_at_f_128992: crate::prelude::Text| {
                            let (w2_pf, builds_pg, methods_ph) = crate::lower::node_::def::pre_bind_bundle_binder_f(&w_pa, &local_name_at_f_128992, &crate::lower::node_::keyed::bundle_part_tys_f(&full_pe));
                            ::prism_rtl::Turn::Finished((w2_pf.clone(), crate::lower::types::bind_f(&b_pb, &crate::check::env::sname_key_f(&n_pd), &crate::lower::types::Bn::BnParts(builds_pg.clone())), crate::lower::types::bind_f(&m_pc, &crate::check::env::sname_key_f(&n_pd), &crate::lower::types::Bn::BnParts(methods_ph.clone()))))
                        })
                    } else {
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::lower::node_::def::PreBindName { wx_p0: w_pa.clone(), benv_p1: b_pb.clone(), menv_p2: m_pc.clone(), n_p3: n_pd.clone(), how_p4: crate::lower::node_::def::HowBound::AsLet }))
                    }
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::syntax::SName)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>>>
    }));
    let back_p9 = {
        let mut this: crate::lower::node_::Wx = named_pi.clone();
        this.lx_p = lx_p8.clone();
        this
    };
    (crate::lower::node_::def::pattern_dynamics_f(&back_p9, cbenv_p1, cmenv_p2, &me1_pk, lxc_p5, p_p6, arg_p7), be1_pj.clone(), me1_pk.clone())
}

/// ```prism
/// BindPlainPatternParam: unbounded fn Wx, Env, Env, Env, Lx, Pattern, Ty, Expr -> ((Wx, Env, Env))
/// ```
pub fn bind_plain_pattern_param_f(wx_p0: &crate::lower::node_::Wx, cbenv_p1: &crate::lower::types::Env, be_p2: &crate::lower::types::Env, me_p3: &crate::lower::types::Env, lxc_p4: &crate::lower::Lx, p_p5: &crate::syntax::Pattern, pty_p6: &crate::check::types::Ty, arg_p7: &crate::syntax::Expr) -> (crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env) {
    bind_plain_pattern_value_f(wx_p0, be_p2, me_p3, lxc_p4, p_p5, pty_p6, &crate::lower::types::own_f(&crate::lower::expr::value_of_f(&wx_p0.lx_p, cbenv_p1, arg_p7)))
}

/// ```prism
/// BindPlainPatternValue: unbounded fn Wx, Env, Env, Lx, Pattern, Ty, Ex -> ((Wx, Env, Env))
/// ```
pub fn bind_plain_pattern_value_f(wx_p0: &crate::lower::node_::Wx, be_p1: &crate::lower::types::Env, me_p2: &crate::lower::types::Env, lxc_p3: &crate::lower::Lx, p_p4: &crate::syntax::Pattern, pty_p5: &crate::check::types::Ty, value_p6: &crate::lower::model::Ex) -> (crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env) {
    let lx_p7 = wx_p0.lx_p.clone();
    let t_p8 = crate::lower::types::out_ty_of_f(&lx_p7, &crate::lower::types::peel_f(pty_p5));
    let (tmp_pg, wx1_ph) = crate::lower::node_::fresh_name_f(wx_p0, &crate::prelude::Text::lit("argument"));
    let o_p9 = crate::lower::patterns::rust_pat_f(lxc_p3, p_p4, &crate::lower::types::peel_f(pty_p5), &crate::lower::types::Holding::ByRef, &tmp_pg);
    let names_pa = crate::lower::node_::def::binder_names_f(p_p4);
    let (wx2_pu, bound_pv) = crate::prelude::run_to_end(crate::prelude::fold_job(o_p9.binds_p.clone(), (wx1_ph.clone(), crate::prelude::Array::new()), {
        let names_pax = names_pa.clone();
        let p_p4x = p_p4.clone();
        let lxc_p3x = lxc_p3.clone();
        ::std::rc::Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy, crate::lower::model::Ex)>), (crate::prelude::Text, crate::lower::types::Bn))| {
            let names_paxy = names_pax.clone();
            let p_p4xy = p_p4x.clone();
            let lxc_p3xy = lxc_p3x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (w_pi, acc_pj) = p0;
                let (k_pk, b_pl) = p1;
                match &b_pl {
                    crate::lower::types::Bn::BnLocal(rs_pm, mode_pn, vt_po) => {
                        let span_pp = crate::prelude::fold(&names_paxy, &p_p4xy.span_p, &(|found_pq: &crate::syntax::Range, n_pr: &crate::syntax::SName| if &crate::check::env::sname_key_f(n_pr) == &k_pk {
                            n_pr.span_p.clone()
                        } else {
                            found_pq.clone()
                        }));
                        let mode_pnx = mode_pn.clone();
                        let rs_pmx = rs_pm.clone();
                        let vt_pox = vt_po.clone();
                        crate::prelude::call_then(crate::lower::start_local_name_at_f(lxc_p3xy.clone(), k_pk.clone(), span_pp.clone()), move |local_name_at_f_130545: crate::prelude::Text| {
                            let (f_ps, w2_pt) = crate::lower::node_::fresh_name_f(&w_pi, &local_name_at_f_130545);
                            ::prism_rtl::Turn::Finished((w2_pt.clone(), crate::prelude::push(&acc_pj, &(k_pk.clone(), f_ps.clone(), vt_pox.clone(), crate::lower::types::own_f(&crate::lower::types::Vl::VlPlace(rs_pmx.clone(), mode_pnx.clone(), vt_pox.clone()))))))
                        })
                    },
                    _ => ::prism_rtl::Turn::Finished((w_pi.clone(), acc_pj.clone())),
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::lower::node_::Wx, crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy, crate::lower::model::Ex)>), (crate::prelude::Text, crate::lower::types::Bn))) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy, crate::lower::model::Ex)>)>>>
    }));
    let all_pb = crate::lower::model::OutTy::OutTuple(crate::prelude::each(&bound_pv, &(|(_, _, vt_p10, _): &(crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy, crate::lower::model::Ex)| vt_p10.clone())));
    let arm_pc = crate::lower::model::XArm { pat_p: o_p9.pa_p.clone(), conds_p: o_p9.conds_p.clone(), body_p: crate::lower::model::Ex::XTuple(crate::prelude::each(&bound_pv, &(|(_, _, _, v_p11): &(crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy, crate::lower::model::Ex)| v_p11.clone()))) };
    let other_pd = crate::lower::model::XArm { pat_p: crate::lower::model::Pa::PaWild, conds_p: crate::prelude::Array::new(), body_p: crate::lower::model::Ex::XUnreachable };
    let matched_pe = crate::lower::types::own_f(&crate::lower::expr::arms_value_f(&crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XVar(tmp_pg.clone()))), &crate::prelude::Array::from(vec![arm_pc.clone(), other_pd.clone()]), &crate::prelude::Text::lit("\'bound"), &all_pb));
    let wx3_pf = {
        let mut this: crate::lower::node_::Wx = wx2_pu.clone();
        this.lets_p = crate::prelude::append(&this.lets_p, &crate::prelude::Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaBind(tmp_pg.clone())), t_p8.clone()), value_p6.clone()), crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaTuple(crate::prelude::each(&bound_pv, &(|(_, f_p12, _, _): &(crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy, crate::lower::model::Ex)| crate::lower::model::Pa::PaBind(f_p12.clone()))))), all_pb.clone()), matched_pe.clone())]));
        this.fields_p = crate::prelude::append(&this.fields_p, &crate::prelude::each(&bound_pv, &(|(k_p13, f_p14, vt_p15, _): &(crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy, crate::lower::model::Ex)| (f_p14.clone(), vt_p15.clone(), crate::prelude::Text::from(format!("`{}`, a name of a widget\'s parameter pattern", k_p13))))));
        this.inits_p = crate::prelude::append(&this.inits_p, &crate::prelude::each(&bound_pv, &(|(_, f_p16, _, _): &(crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy, crate::lower::model::Ex)| (f_p16.clone(), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(f_p16.clone())))))));
        this
    };
    let (be2_p1c, me2_p1d) = crate::prelude::fold(&bound_pv, &(be_p1.clone(), me_p2.clone()), &(|(b_p17, m_p18): &(crate::lower::types::Env, crate::lower::types::Env), (k_p19, f_p1a, vt_p1b, _): &(crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy, crate::lower::model::Ex)| crate::lower::node_::bind_plain_f(b_p17, m_p18, k_p19, f_p1a, vt_p1b)));
    if &crate::prelude::len(&bound_pv) == &crate::prelude::len(&names_pa) {
        (wx3_pf.clone(), be2_p1c.clone(), me2_p1d.clone())
    } else {
        ({
            let mut this: crate::lower::node_::Wx = wx3_pf.clone();
            this.build_p = crate::prelude::push(&this.build_p, &crate::lower::expr::internal_bug_do_f(&crate::prelude::Text::from(format!("a widget\'s parameter pattern (`{}`) that left a name without its field", &crate::lower::functions::src_text_f(lxc_p3, &lxc_p3.file_p, &p_p4.span_p)))));
            this
        }, be2_p1c.clone(), me2_p1d.clone())
    }
}

/// ```prism
/// BindBundleParam: unbounded fn Wx, Env, Env, Env, Env, Lx, Pattern, Ty, Expr -> ((Wx, Env, Env))
/// ```
pub fn bind_bundle_param_f(wx_p0: &crate::lower::node_::Wx, cbenv_p1: &crate::lower::types::Env, cmenv_p2: &crate::lower::types::Env, be_p3: &crate::lower::types::Env, me_p4: &crate::lower::types::Env, lxc_p5: &crate::lower::Lx, p_p6: &crate::syntax::Pattern, pty_p7: &crate::check::types::Ty, arg_p8: &crate::syntax::Expr) -> (crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env) {
    match ((*p_p6.kind_p).clone(), (*ungrouped_f(arg_p8).kind_p).clone()) {
        (crate::syntax::PatternKind::PGroup(q_p9), _) => bind_bundle_param_f(wx_p0, cbenv_p1, cmenv_p2, be_p3, me_p4, lxc_p5, &*q_p9, pty_p7, arg_p8),
        (crate::syntax::PatternKind::PTuple(ps_pa), crate::syntax::ExprKind::ETuple(xs_pb)) => crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(&ps_pa)), (wx_p0.clone(), be_p3.clone(), me_p4.clone()), {
            let ps_pax = ps_pa.clone();
            let xs_pbx = xs_pb.clone();
            let cbenv_p1x = cbenv_p1.clone();
            let cmenv_p2x = cmenv_p2.clone();
            let lxc_p5x = lxc_p5.clone();
            let pty_p7x = pty_p7.clone();
            ::std::rc::Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::prelude::Nat)| {
                let ps_paxy = ps_pax.clone();
                let xs_pbxy = xs_pbx.clone();
                let cbenv_p1xy = cbenv_p1x.clone();
                let cmenv_p2xy = cmenv_p2x.clone();
                let lxc_p5xy = lxc_p5x.clone();
                let pty_p7xy = pty_p7x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let (w_pc, b_pd, m_pe) = p0;
                    let i_pf = p1;
                    match (crate::prelude::index(&ps_paxy, &i_pf), crate::prelude::index(&xs_pbxy, &i_pf)) {
                        (::std::option::Option::Some(q_pg), ::std::option::Option::Some(x_ph)) => ::prism_rtl::Turn::Finished(bind_param_pattern_f(&w_pc, &cbenv_p1xy, &cmenv_p2xy, &b_pd, &m_pe, &lxc_p5xy, &q_pg, &crate::prelude::or(&crate::prelude::index(&crate::lower::node_::keyed::bundle_part_tys_f(&pty_p7xy), &i_pf), &crate::check::types::Ty::TyErr), &x_ph)),
                        _ => ::prism_rtl::Turn::Finished((w_pc.clone(), b_pd.clone(), m_pe.clone())),
                    }
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>>>
        })),
        (crate::syntax::PatternKind::PTuple(ps_pi), crate::syntax::ExprKind::EName(n_pj)) => match if &crate::prelude::len(&n_pj.path_p) == &crate::prelude::Nat::from(1u32) {
            crate::prelude::get(&cmenv_p2.names_p, &crate::check::env::sname_key_f(&n_pj))
        } else {
            ::std::option::Option::None
        } {
            ::std::option::Option::Some(crate::lower::types::Bn::BnParts(methods_pk)) => {
                let builds_pl = match crate::prelude::get(&cbenv_p1.names_p, &crate::check::env::sname_key_f(&n_pj)) {
                    ::std::option::Option::Some(crate::lower::types::Bn::BnParts(bs_pm)) => crate::lower::node_::def::plain_at_build_f(&methods_pk, &bs_pm),
                    _ => methods_pk.clone(),
                };
                bind_parts_param_f(wx_p0, be_p3, me_p4, lxc_p5, &ps_pi, &crate::lower::node_::keyed::bundle_part_tys_f(pty_p7), &methods_pk, &builds_pl)
            },
            _ => ({
                let mut this: crate::lower::node_::Wx = wx_p0.clone();
                this.build_p = crate::prelude::push(&this.build_p, &crate::lower::expr::internal_bug_do_f(&crate::prelude::Text::from(format!("a widget\'s bundle parameter given the name `{}`, which is bound to no bundle", &crate::check::env::sname_key_f(&n_pj)))));
                this
            }, be_p3.clone(), me_p4.clone()),
        },
        _ => bind_time_pattern_param_f(wx_p0, cbenv_p1, cmenv_p2, be_p3, me_p4, lxc_p5, p_p6, arg_p8),
    }
}

/// ```prism
/// BindPartsParam: unbounded fn Wx, Env, Env, Lx, [Pattern], [Ty], [?Bn], [?Bn] -> ((Wx, Env, Env))
/// ```
pub fn bind_parts_param_f(wx_p0: &crate::lower::node_::Wx, be_p1: &crate::lower::types::Env, me_p2: &crate::lower::types::Env, lxc_p3: &crate::lower::Lx, ps_p4: &crate::prelude::Array<crate::syntax::Pattern>, tys_p5: &crate::prelude::Array<crate::check::types::Ty>, methods_p6: &crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>, builds_p7: &crate::prelude::Array<::std::option::Option<crate::lower::types::Bn>>) -> (crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env) {
    crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(ps_p4)), (wx_p0.clone(), be_p1.clone(), me_p2.clone()), {
        let ps_p4x = ps_p4.clone();
        let methods_p6x = methods_p6.clone();
        let lxc_p3x = lxc_p3.clone();
        let tys_p5x = tys_p5.clone();
        let builds_p7x = builds_p7.clone();
        ::std::rc::Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::prelude::Nat)| {
            let ps_p4xy = ps_p4x.clone();
            let methods_p6xy = methods_p6x.clone();
            let lxc_p3xy = lxc_p3x.clone();
            let tys_p5xy = tys_p5x.clone();
            let builds_p7xy = builds_p7x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (w_p8, b_p9, m_pa) = p0;
                let i_pb = p1;
                match (crate::prelude::index(&ps_p4xy, &i_pb), crate::lower::node_::def::part_of_o(&methods_p6xy, &i_pb)) {
                    (::std::option::Option::Some(q_pc), ::std::option::Option::Some(part_pd)) => ::prism_rtl::Turn::Finished(bind_part_param_f(&w_p8, &b_p9, &m_pa, &lxc_p3xy, &q_pc, &crate::prelude::or(&crate::prelude::index(&tys_p5xy, &i_pb), &crate::check::types::Ty::TyErr), &part_pd, &crate::lower::node_::def::part_of_o(&builds_p7xy, &i_pb))),
                    _ => ::prism_rtl::Turn::Finished((w_p8.clone(), b_p9.clone(), m_pa.clone())),
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>>>
    }))
}

/// ```prism
/// BindPartParam: unbounded fn Wx, Env, Env, Lx, Pattern, Ty, Bn, ?Bn -> ((Wx, Env, Env))
/// ```
pub fn bind_part_param_f(wx_p0: &crate::lower::node_::Wx, be_p1: &crate::lower::types::Env, me_p2: &crate::lower::types::Env, lxc_p3: &crate::lower::Lx, p_p4: &crate::syntax::Pattern, ty_p5: &crate::check::types::Ty, part_p6: &crate::lower::types::Bn, built_o7: &::std::option::Option<crate::lower::types::Bn>) -> (crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env) {
    let nkey_p8 = crate::lower::functions::plain_binder_f(lxc_p3, p_p4);
    let at_build_p9 = crate::prelude::or(built_o7, part_p6);
    match ((*p_p4.kind_p).clone(), part_p6.clone()) {
        (crate::syntax::PatternKind::PGroup(q_pa), _) => bind_part_param_f(wx_p0, be_p1, me_p2, lxc_p3, &*q_pa, ty_p5, part_p6, built_o7),
        (crate::syntax::PatternKind::PIgnore, _) => (wx_p0.clone(), be_p1.clone(), me_p2.clone()),
        (crate::syntax::PatternKind::PTuple(qs_pb), crate::lower::types::Bn::BnParts(ms_pc)) => {
            let bs_pd = match built_o7 {
                ::std::option::Option::Some(crate::lower::types::Bn::BnParts(xs_pe)) => xs_pe.clone(),
                _ => ms_pc.clone(),
            };
            bind_parts_param_f(wx_p0, be_p1, me_p2, lxc_p3, &qs_pb, &crate::lower::node_::keyed::bundle_part_tys_f(ty_p5), &ms_pc, &bs_pd)
        },
        (crate::syntax::PatternKind::PName(_), crate::lower::types::Bn::BnEv(r_pf, _)) if (&nkey_p8 != &crate::prelude::Text::lit("")) => bind_event_param_f(wx_p0, be_p1, me_p2, &nkey_p8, &crate::lower::local_name_at_f(lxc_p3, &nkey_p8, &p_p4.span_p), ty_p5, &r_pf),
        (crate::syntax::PatternKind::PName(_), crate::lower::types::Bn::BnLocal(_, _, _)) if (&nkey_p8 != &crate::prelude::Text::lit("")) => match &at_build_p9 {
            crate::lower::types::Bn::BnLocal(ex_pg, mode_ph, t_pi) => {
                let (rs_pk, wx2_pl) = crate::lower::node_::fresh_name_f(wx_p0, &crate::lower::local_name_at_f(lxc_p3, &nkey_p8, &p_p4.span_p));
                let wx3_pj = {
                    let mut this: crate::lower::node_::Wx = wx2_pl.clone();
                    this.lets_p = crate::prelude::push(&this.lets_p, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaBind(rs_pk.clone())), t_pi.clone()), crate::lower::types::own_f(&crate::lower::types::Vl::VlPlace(ex_pg.clone(), mode_ph.clone(), t_pi.clone()))));
                    this.fields_p = crate::prelude::push(&this.fields_p, &(rs_pk.clone(), t_pi.clone(), crate::prelude::Text::from(format!("`{}`", &nkey_p8))));
                    this.inits_p = crate::prelude::push(&this.inits_p, &(rs_pk.clone(), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(rs_pk.clone())))));
                    this
                };
                let (be2_pm, me2_pn) = crate::lower::node_::bind_plain_f(be_p1, me_p2, &nkey_p8, &rs_pk, t_pi);
                (wx3_pj.clone(), be2_pm.clone(), me2_pn.clone())
            },
            _ => ({
                let mut this: crate::lower::node_::Wx = wx_p0.clone();
                this.build_p = crate::prelude::push(&this.build_p, &crate::lower::expr::internal_bug_do_f(&crate::prelude::Text::lit("a plain part of a named bundle with no binding at the build")));
                this
            }, be_p1.clone(), me_p2.clone()),
        },
        (crate::syntax::PatternKind::PName(_), _) if (&nkey_p8 != &crate::prelude::Text::lit("")) => (wx_p0.clone(), crate::lower::types::bind_f(be_p1, &nkey_p8, &at_build_p9), crate::lower::types::bind_f(me_p2, &nkey_p8, part_p6)),
        (_, crate::lower::types::Bn::BnLocal(_, _, _)) => match &at_build_p9 {
            crate::lower::types::Bn::BnLocal(ex_po, mode_pp, t_pq) => bind_plain_pattern_value_f(wx_p0, be_p1, me_p2, lxc_p3, p_p4, ty_p5, &crate::lower::types::own_f(&crate::lower::types::Vl::VlPlace(ex_po.clone(), mode_pp.clone(), t_pq.clone()))),
            _ => ({
                let mut this: crate::lower::node_::Wx = wx_p0.clone();
                this.build_p = crate::prelude::push(&this.build_p, &crate::lower::expr::internal_bug_do_f(&crate::prelude::Text::lit("a plain part of a named bundle with no binding at the build")));
                this
            }, be_p1.clone(), me_p2.clone()),
        },
        _ => ({
            let mut this: crate::lower::node_::Wx = wx_p0.clone();
            this.build_p = crate::prelude::push(&this.build_p, &crate::lower::expr::internal_bug_do_f(&crate::prelude::Text::from(format!("a widget\'s parameter pattern (`{}`) over a part of a named bundle that it does not match", &crate::lower::functions::src_text_f(lxc_p3, &lxc_p3.file_p, &p_p4.span_p)))));
            this
        }, be_p1.clone(), me_p2.clone()),
        _ => unreachable!("no arm matched"),
    }
}
