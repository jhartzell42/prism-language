//! The module `Lower.Node.Static`, from `target/bootstrap/src/prismc/lower/node/static.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// `HostForm`:
///
/// ```prism
/// type HostForm = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum HostForm {
    HostEach,
    HostSome,
}

impl Show for HostForm {
    fn show(&self, p: &mut Printer) {
        match self {
            HostForm::HostEach => p.choice("HostEach", &[]),
            HostForm::HostSome => p.choice("HostSome", &[]),
        }
    }
}

impl ToPod for HostForm {
    fn to_pod(&self) -> Pod {
        match self {
            HostForm::HostEach => Pod::Choice("HostEach".into(), vec![]),
            HostForm::HostSome => Pod::Choice("HostSome".into(), vec![]),
        }
    }
}

impl FromPod for HostForm {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "HostEach" && a.len() == 0 => Ok(HostForm::HostEach),
            Pod::Choice(c, a) if &**c == "HostSome" && a.len() == 0 => Ok(HostForm::HostSome),
            other => mismatch("a HostForm", other),
        }
    }
}

/// ```prism
/// WidgetLine: unbounded fn Wx, Env, Env, Expr, ?Bn -> ((Wx, Wres))
/// ```
pub fn widget_line(wx: &crate::lower::node_::Wx, benv: &crate::lower::types::Env, menv: &crate::lower::types::Env, e: &crate::syntax::Expr, bound_opt: &Option<crate::lower::types::Bn>) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    let lx = wx.lx.clone();
    let (callee, args) = match &*e.kind {
        crate::syntax::ExprKind::ECall(c, xs, _, _) => ((**c).clone(), xs.clone()),
        _ => (e.clone(), Array::new()),
    };
    let qk = match &*callee.kind {
        crate::syntax::ExprKind::EName(n) => {
            let (q_opt, _) = crate::check::env::names::resolve_value(&lx.g, &lx.home, n);
            or(&q_opt, &Text::lit(""))
        },
        _ => Text::lit(""),
    };
    let target_opt = match bound_opt {
        Some(crate::lower::types::Bn::BnEv(er, _)) => Some(er.node_.clone()),
        _ => None,
    };
    let param_opt = match &*callee.kind {
        crate::syntax::ExprKind::EName(n) => if &len(&n.path_) == &Nat::from(1u32) {
            get(&menv.names, &crate::check::env::sname_key(n))
        } else {
            None
        },
        _ => None,
    };
    match &param_opt {
        Some(crate::lower::types::Bn::BnWidget(x, cbenv, cmenv, clx)) => apply_widget_param(wx, x, cbenv, cmenv, clx, &len(&args)),
        _ => widget_call(wx, benv, menv, e, bound_opt, &qk, &args, &target_opt),
    }
}

/// The step machine of `WidgetLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// WidgetLine: unbounded fn Wx, Env, Env, Expr, ?Bn -> ((Wx, Wres))
/// ```
pub struct WidgetLine {
    pub wx: crate::lower::node_::Wx,
    pub benv: crate::lower::types::Env,
    pub menv: crate::lower::types::Env,
    pub e: crate::syntax::Expr,
    pub bound_opt: Option<crate::lower::types::Bn>,
}

impl prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::node_::Wres)> for WidgetLine {
    fn cycle(&self) -> prism_rtl::Turn<(crate::lower::node_::Wx, crate::lower::node_::Wres)> {
        let wx = &self.wx;
        let benv = &self.benv;
        let menv = &self.menv;
        let e = &self.e;
        let bound_opt = &self.bound_opt;
        let lx = wx.lx.clone();
        let (callee, args) = match &*e.kind {
            crate::syntax::ExprKind::ECall(c, xs, _, _) => ((**c).clone(), xs.clone()),
            _ => (e.clone(), Array::new()),
        };
        let qk = match &*callee.kind {
            crate::syntax::ExprKind::EName(n) => {
                let (q_opt, _) = crate::check::env::names::resolve_value(&lx.g, &lx.home, n);
                or(&q_opt, &Text::lit(""))
            },
            _ => Text::lit(""),
        };
        let target_opt = match bound_opt {
            Some(crate::lower::types::Bn::BnEv(er, _)) => Some(er.node_.clone()),
            _ => None,
        };
        let param_opt = match &*callee.kind {
            crate::syntax::ExprKind::EName(n) => if &len(&n.path_) == &Nat::from(1u32) {
                get(&menv.names, &crate::check::env::sname_key(n))
            } else {
                None
            },
            _ => None,
        };
        match &param_opt {
            Some(crate::lower::types::Bn::BnWidget(x, cbenv, cmenv, clx)) => prism_rtl::Turn::Finished(apply_widget_param(wx, x, cbenv, cmenv, clx, &len(&args))),
            _ => prism_rtl::Turn::Finished(widget_call(wx, benv, menv, e, bound_opt, &qk, &args, &target_opt)),
        }
    }
}

/// `Start WidgetLine, x`: what the function value is when passed to `@Run`.
pub fn start_widget_line(wx: crate::lower::node_::Wx, benv: crate::lower::types::Env, menv: crate::lower::types::Env, e: crate::syntax::Expr, bound_opt: Option<crate::lower::types::Bn>) -> Rc<dyn prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::node_::Wres)>> {
    Rc::new(WidgetLine { wx, benv, menv, e, bound_opt })
}

/// ```prism
/// ApplyWidgetParam: unbounded fn Wx, Expr, Env, Env, Lx, Nat -> ((Wx, Wres))
/// ```
pub fn apply_widget_param(wx: &crate::lower::node_::Wx, x: &crate::syntax::Expr, cbenv: &crate::lower::types::Env, cmenv: &crate::lower::types::Env, clx: &crate::lower::Lx, nargs: &Nat) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    if nargs > &Nat::from(0u32) {
        {
            let wx2 = {
                let mut this: crate::lower::node_::Wx = wx.clone();
                this.build = push(&this.build, &crate::lower::expr::refusal_do(&Text::lit("a widget parameter applied to arguments")));
                this
            };
            (wx2.clone(), crate::lower::node_::Wres::WrUnit)
        }
    } else {
        {
            let lx = wx.lx.clone();
            let inner = {
                let mut this: crate::lower::node_::Wx = wx.clone();
                this.lx = clx.clone();
                this
            };
            let (done, res) = crate::lower::node_::def::build_line(&inner, cbenv, cmenv, x, &None);
            let back_ = {
                let mut this: crate::lower::node_::Wx = done.clone();
                this.lx = lx.clone();
                this
            };
            (back_.clone(), res.clone())
        }
    }
}

/// ```prism
/// InlineBlock: unbounded fn Wx, Env, Env, Block, Lx -> ((Wx, Wres))
/// ```
pub fn inline_block(wx: &crate::lower::node_::Wx, benv: &crate::lower::types::Env, menv: &crate::lower::types::Env, b: &crate::syntax::Block, lx: &crate::lower::Lx) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    let inner = {
        let mut this: crate::lower::node_::Wx = wx.clone();
        this.result = crate::lower::node_::Wres::WrUnit;
        this
    };
    let done = crate::lower::node_::def::block_into(&inner, benv, menv, b);
    let back_ = {
        let mut this: crate::lower::node_::Wx = done.clone();
        this.result = wx.result.clone();
        this
    };
    (back_.clone(), done.result.clone())
}

/// The step machine of `InlineBlock`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InlineBlock: unbounded fn Wx, Env, Env, Block, Lx -> ((Wx, Wres))
/// ```
pub struct InlineBlock {
    pub wx: crate::lower::node_::Wx,
    pub benv: crate::lower::types::Env,
    pub menv: crate::lower::types::Env,
    pub b: crate::syntax::Block,
    pub lx: crate::lower::Lx,
}

impl prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::node_::Wres)> for InlineBlock {
    fn cycle(&self) -> prism_rtl::Turn<(crate::lower::node_::Wx, crate::lower::node_::Wres)> {
        let wx = &self.wx;
        let benv = &self.benv;
        let menv = &self.menv;
        let b = &self.b;
        let lx = &self.lx;
        let inner = {
            let mut this: crate::lower::node_::Wx = wx.clone();
            this.result = crate::lower::node_::Wres::WrUnit;
            this
        };
        let b = b.clone();
        let benv = benv.clone();
        let menv = menv.clone();
        let wx = wx.clone();
        call_then(crate::lower::node_::def::start_block_into(inner.clone(), benv.clone(), menv.clone(), b.clone()), move |block_into_3395: crate::lower::node_::Wx| {
            let done = block_into_3395;
            let back_ = {
                let mut this: crate::lower::node_::Wx = done.clone();
                this.result = wx.result.clone();
                this
            };
            prism_rtl::Turn::Finished((back_.clone(), done.result.clone()))
        })
    }
}

/// `Start InlineBlock, x`: what the function value is when passed to `@Run`.
pub fn start_inline_block(wx: crate::lower::node_::Wx, benv: crate::lower::types::Env, menv: crate::lower::types::Env, b: crate::syntax::Block, lx: crate::lower::Lx) -> Rc<dyn prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::node_::Wres)>> {
    Rc::new(InlineBlock { wx, benv, menv, b, lx })
}

/// ```prism
/// WidgetCall: unbounded fn Wx, Env, Env, Expr, ?Bn, Text, [Arg], ?Nat -> ((Wx, Wres))
/// ```
pub fn widget_call(wx: &crate::lower::node_::Wx, benv: &crate::lower::types::Env, menv: &crate::lower::types::Env, e: &crate::syntax::Expr, bound_opt: &Option<crate::lower::types::Bn>, qk: &Text, args: &Array<crate::syntax::Arg>, target_opt: &Option<Nat>) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    let lx = wx.lx.clone();
    match qk {
        m3679_0 if (m3679_0 == &Text::lit("Prelude.@started")) => started_line(wx, bound_opt),
        m3679_1 if (m3679_1 == &Text::lit("Prelude.@Switch")) => crate::lower::node_::switch_::switch_line(wx, menv, args),
        m3679_2 if (m3679_2 == &Text::lit("Prelude.@Flatten")) => crate::lower::node_::switch_::flatten_line(wx, menv, args, bound_opt),
        m3679_3 if (m3679_3 == &Text::lit("Prelude.@Defer")) => defer_line(wx, menv, args, e, target_opt),
        m3679_4 if (m3679_4 == &Text::lit("Prelude.@Distinct")) => distinct_line(wx, menv, args, e, bound_opt),
        m3679_5 if (m3679_5 == &Text::lit("Prelude.@PerKey")) => per_key_line(wx, menv, args, bound_opt),
        m3679_6 if (m3679_6 == &Text::lit("Prelude.@Run")) => run_line(wx, benv, args, e, target_opt),
        m3679_7 if (m3679_7 == &Text::lit("Prelude.@Machine")) => machine_line(wx, benv, menv, args, e, target_opt),
        m3679_8 if (m3679_8 == &Text::lit("Prelude.@HostDocument")) => host_line(wx, benv, menv, &HostForm::HostEach, args, bound_opt),
        m3679_9 if (m3679_9 == &Text::lit("Prelude.@HostSome")) => host_line(wx, benv, menv, &HostForm::HostSome, args, bound_opt),
        _ => match get(&lx.g.vals, qk) {
            Some(v_) => inline_widget(wx, benv, menv, qk, &v_, args, e),
            None => {
                let wx2 = {
                    let mut this: crate::lower::node_::Wx = wx.clone();
                    this.build = push(&this.build, &crate::lower::expr::refusal_do(&Text::lit("a widget this back end does not lower yet")));
                    this
                };
                (wx2.clone(), crate::lower::node_::Wres::WrUnit)
            },
        },
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// HostLine: unbounded fn Wx, Env, Env, HostForm, [Arg], ?Bn -> ((Wx, Wres))
/// ```
pub fn host_line(wx: &crate::lower::node_::Wx, benv: &crate::lower::types::Env, menv: &crate::lower::types::Env, form: &HostForm, args: &Array<crate::syntax::Arg>, bound_opt: &Option<crate::lower::types::Bn>) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    let lx = wx.lx.clone();
    let pos = wx.pos.clone();
    let k = &len(&wx.scopes) + &Nat::from(1u32);
    let hf = Text::from(format!("host_{}", &k));
    let rows_name = Text::from(format!("{}_rows", &hf));
    let doc_getter = Text::from(format!("{}_doc", &hf));
    let wx1 = {
        let mut this: crate::lower::node_::Wx = wx.clone();
        this.taken = append(&this.taken, &Array::from(vec![hf.clone(), rows_name.clone(), doc_getter.clone(), Text::from(format!("{}_now", &doc_getter)), Text::from(format!("{}_snap", &doc_getter)), Text::from(format!("{}_direct", &doc_getter)), Text::from(format!("{}_publish", &doc_getter)), Text::from(format!("{}_answer", &hf)), Text::from(format!("{}_moved", &hf))]));
        this
    };
    let named_ = match index(args, &Nat::from(1u32)) {
        Some(sup) => is_widget_name(&sup.value),
        None => false,
    };
    match (index(args, &Nat::from(0u32)), index(args, &Nat::from(1u32))) {
        (Some(_), Some(_)) if named_ => {
            let wx2 = {
                let mut this: crate::lower::node_::Wx = wx1.clone();
                this.pos = crate::lower::model::next_pos(&this.pos);
                this.build = push(&this.build, &crate::lower::expr::refusal_do(&Text::lit("a named widget function as a host\'s supplier (gap NS): a lambda supplier is lowered, a widget function is not a value")));
                this
            };
            (wx2.clone(), crate::lower::node_::Wres::WrHosted(Rc::new(crate::lower::node_::Wres::WrUnit), crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XUnit, crate::lower::types::Holding::Owned, crate::lower::model::OutTy::OutUnit)))
        },
        (Some(child), Some(sup)) => {
            let (wxd, dyn_env, dyn_lets) = dynamic_answers(&wx1, benv, menv, &hf, &sup.value);
            let offered = crate::lower::types::own(&crate::lower::expr::value_of(&lx, &dyn_env, &sup.value));
            let supplier0 = match form {
                HostForm::HostEach => offered.clone(),
                HostForm::HostSome => crate::lower::model::Ex::XCall(Text::lit("prism_rtl::forward_on_none"), Array::from(vec![offered.clone()])),
            };
            let supplier = if &len(&dyn_lets) == &Nat::from(0u32) {
                supplier0.clone()
            } else {
                crate::lower::model::Ex::XBlock(dyn_lets.clone(), Rc::new(supplier0.clone()))
            };
            let enclosing = if crate::lower::node_::finish::emits(wx, &pos) {
                crate::lower::model::Ex::XNone
            } else {
                crate::lower::model::Ex::XCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Ex::XCast(Rc::new(crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(crate::lower::node_::elements::host_local(wx, &pos))))), crate::lower::types::host_of_ty())]))
            };
            let made = crate::lower::model::Ex::XCall(Text::lit("prism_rtl::Host::new"), Array::from(vec![crate::lower::node_::finish::place_at(wx, &Text::lit(""), &pos), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(rows_name.clone()))), supplier.clone(), enclosing.clone(), crate::lower::model::Ex::XPath(Text::from(format!("{}::{}_answer", &wx.node_, &hf)))]));
            let host_ty = crate::lower::model::OutTy::OutRc(Rc::new(crate::lower::model::OutTy::OutNamed(Text::lit("prism_rtl::Host"), Array::from(vec![crate::lower::types::elem_ty(), crate::lower::types::answer_ty(), crate::lower::model::OutTy::OutNamed(wx.node_.clone(), Array::new())]))));
            let rows_ty = crate::lower::model::OutTy::OutNamed(Text::lit("prism_rtl::Rows"), Array::from(vec![crate::lower::types::elem_ty(), crate::lower::types::answer_ty()]));
            let doc_ty = crate::lower::model::OutTy::OutMap(Rc::new(crate::lower::model::OutTy::OutPath), Rc::new(crate::lower::model::OutTy::OutDyn(Rc::new(crate::lower::types::elem_ty()))));
            let direct_ty = crate::lower::model::OutTy::OutMap(Rc::new(crate::lower::model::OutTy::OutPath), Rc::new(crate::lower::types::entry_ty()));
            let what = Text::from(format!("the document of the child hosted at place {}", &crate::lower::model::place_text(&pos)));
            let wx2 = {
                let mut this: crate::lower::node_::Wx = wxd.clone();
                this.pos = crate::lower::model::next_pos(&this.pos);
                this.lets = append(&this.lets, &Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaBind(rows_name.clone())), rows_ty.clone()), crate::lower::model::Ex::XCall(Text::lit("Rc::new"), Array::from(vec![crate::lower::model::Ex::XCall(Text::lit("RefCell::new"), Array::from(vec![crate::lower::model::Ex::XCall(Text::lit("Map::new"), Array::new())]))]))), crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(hf.clone()), made.clone())]));
                this.fields = append(&this.fields, &Array::from(vec![(hf.clone(), host_ty.clone(), Text::from(format!("the host at place {}: its supplier, its rows, and the way back into its child (pick HO)", &crate::lower::model::place_text(&pos)))), (rows_name.clone(), rows_ty.clone(), Text::from(format!("the rows of the host at place {}: `for p, e <- $doc`, one supplier blueprint per child place", &crate::lower::model::place_text(&pos)))), (Text::from(format!("{}_from", &rows_name)), crate::lower::model::OutTy::OutCell(Rc::new(direct_ty.clone())), Text::from(format!("the places the rows of the host at place {} were last built from", &crate::lower::model::place_text(&pos)))), (Text::from(format!("{}_snap", &doc_getter)), crate::lower::model::OutTy::OutSnapshot(Rc::new(crate::lower::types::host_doc_ty())), Text::from(format!("`$doc` of the host at place {}, its outer, a structural dynamic: its snapshots, the places and the lagged dynamic (pick ST)", &crate::lower::model::place_text(&pos))))]));
                this.moves = append(&this.moves, &Array::from(vec![(hf.clone(), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(hf.clone())))), (rows_name.clone(), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(rows_name.clone()))))]));
                this.inits = append(&this.inits, &Array::from(vec![(Text::from(format!("{}_snap", &doc_getter)), crate::lower::model::Ex::XCall(Text::lit("Snapshot::new"), Array::from(vec![crate::lower::model::Ex::XStr(what.clone())]))), (Text::from(format!("{}_from", &rows_name)), crate::lower::model::Ex::XCall(Text::lit("RefCell::new"), Array::from(vec![crate::lower::model::Ex::XCall(Text::lit("Map::new"), Array::new())])))]));
                this.hosts = push(&this.hosts, &crate::lower::node_::HostDef { pos: pos.clone(), name: hf.clone(), scope: k.clone() });
                this.snaps = push(&this.snaps, &crate::lower::node_::SnapDef { name: doc_getter.clone(), live: Text::from(format!("{}_now", &doc_getter)), ty: crate::lower::types::host_doc_ty(), eq: true, builder: rows_name.clone(), before: true, what: what.clone() });
                this.getters = append(&this.getters, &Array::from(vec![crate::lower::model::MethDef { name: doc_getter.clone(), recv: crate::lower::model::Recv::RecvRef, params: Array::new(), cx_: crate::lower::model::CxArg::CxRef, ret: doc_ty.clone(), body: Array::new(), tail: crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_snap", &doc_getter)))), Text::lit("get"), Array::from(vec![crate::lower::model::Ex::XCx]))), Text::lit("doc")), doc: Text::from(format!("The document of the child hosted at place {}, `$doc`, its outer a structural dynamic (pick ST): one tick behind the child\'s places, the snapshot of the tick before the tick the read point is after; each entry the place\'s own dynamic.", &crate::lower::model::place_text(&pos))) }, crate::lower::model::MethDef { name: Text::from(format!("{}_direct", &doc_getter)), recv: crate::lower::model::Recv::RecvRef, params: Array::new(), cx_: crate::lower::model::CxArg::CxRef, ret: direct_ty.clone(), body: Array::new(), tail: crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_snap", &doc_getter)))), Text::lit("current"), Array::from(vec![crate::lower::model::Ex::XCx]))), Text::lit("places")), doc: Text::from(format!("The places of the child hosted at place {}, not the lagged `$doc`: the snapshot taken in this tick\'s construction step, the places as the tick opened during propagation. The host\'s own `for` reads it, so a newborn child place gets its row in the tick it is born (pick ST).", &crate::lower::model::place_text(&pos))) }]));
                this.scopes = push(&this.scopes, &hf);
                this.builders = push(&this.builders, &crate::lower::model::ForDef { name: rows_name.clone(), pos: pos.clone(), at: crate::lower::node_::finish::place_at(wx, &Text::lit("self"), &pos), key_ty: crate::lower::model::OutTy::OutPath, value_ty: crate::lower::types::entry_ty(), row_node: Text::lit("prism_rtl::HostRow::<crate::Elem, crate::Answer>"), keyed: true, source: Text::from(format!("{}_direct", &doc_getter)), parent: crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), hf.clone()))), passed: Array::new(), moved: or(&crate::lower::node_::finish::hosted_rows(wx), &Text::lit("")), replaced: Array::new() });
                this.build_holds = crate::lower::node_::add_read(&this.build_holds, &crate::lower::node_::Read::OwnRead(Text::from(format!("{}_now", &doc_getter))));
                this.fallible = true;
                this
            };
            let inner = {
                let mut this: crate::lower::node_::Wx = wx2.clone();
                this.pos = crate::lower::model::scope_pos(&k);
                this.result = crate::lower::node_::Wres::WrUnit;
                this
            };
            let (done, res) = crate::lower::node_::def::build_line(&inner, benv, menv, &child.value, &None);
            let child_places = drop(&done.places, &len(&wx2.places));
            let in_scope_fn = {
                let k = k.clone();
                Rc::new(move |p_: &crate::lower::model::Pos_| &p_.scope == &k)
            };
            let getter = host_doc_getter(&Text::from(format!("{}_now", &doc_getter)), &pos, &filter(&child_places, &(|pl: &crate::lower::node_::Place| (&in_scope_fn)(&pl.pos))), &filter(&drop(&done.builders, &len(&wx2.builders)), &(|b: &crate::lower::model::ForDef| (&in_scope_fn)(&b.pos))), &filter(&drop(&done.gens, &len(&wx2.gens)), &(|gd: &crate::lower::model::GenDef| (&in_scope_fn)(&gd.pos))));
            let back_ = {
                let mut this: crate::lower::node_::Wx = done.clone();
                this.pos = wx2.pos.clone();
                this.result = wx.result.clone();
                this.getters = push(&this.getters, &getter);
                this.dyn_reads = insert(&this.dyn_reads, &Text::from(format!("{}_now", &doc_getter)), &Array::new());
                this
            };
            let doc_bn = crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XSelf), doc_getter.clone(), Array::from(vec![crate::lower::model::Ex::XCx])), Array::from(vec![crate::lower::node_::Read::OwnRead(doc_getter.clone())]), doc_ty.clone());
            (back_.clone(), crate::lower::node_::Wres::WrHosted(Rc::new(res.clone()), doc_bn.clone()))
        },
        _ => {
            let wx2 = {
                let mut this: crate::lower::node_::Wx = wx1.clone();
                this.pos = crate::lower::model::next_pos(&this.pos);
                this.build = push(&this.build, &crate::lower::expr::refusal_do(&Text::lit("a host without its child or its supplier")));
                this
            };
            (wx2.clone(), crate::lower::node_::Wres::WrHosted(Rc::new(crate::lower::node_::Wres::WrUnit), crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XUnit, crate::lower::types::Holding::Owned, crate::lower::model::OutTy::OutUnit)))
        },
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// IsWidgetName: fn Expr -> Bool
/// ```
pub fn is_widget_name(e: &crate::syntax::Expr) -> bool {
    match &*e.kind {
        crate::syntax::ExprKind::EName(n) => crate::syntax::lexer::chars::has_prefix(&crate::check::env::sname_key(n), &Text::lit("@")),
        crate::syntax::ExprKind::EGroup(x) => is_widget_name(&**x),
        _ => false,
    }
}

/// ```prism
/// DynamicAnswers: unbounded fn Wx, Env, Env, Text, Expr -> ((Wx, Env, [Do]))
/// ```
pub fn dynamic_answers(wx: &crate::lower::node_::Wx, benv: &crate::lower::types::Env, menv: &crate::lower::types::Env, hf: &Text, sup: &crate::syntax::Expr) -> (crate::lower::node_::Wx, crate::lower::types::Env, Array<crate::lower::model::Do>) {
    let lx = wx.lx.clone();
    let dyns = fold(&crate::check::typed::print::exprs_in(sup), &Array::new(), &(|acc: &Array<(crate::syntax::Expr, crate::syntax::Expr)>, x: &crate::syntax::Expr| match &*x.kind {
        crate::syntax::ExprKind::EFreeSigil(m14204_0_0, y) if (m14204_0_0 == &Text::lit("@")) => match dynamic_answer(&lx, &**y) {
            Some(d) => push(acc, &((**y).clone(), d)),
            None => acc.clone(),
        },
        _ => acc.clone(),
        _ => unreachable!("no arm matched"),
    }));
    if &len(&dyns) == &Nat::from(0u32) {
        (wx.clone(), benv.clone(), Array::new())
    } else {
        {
            let owner = Text::from(format!("{}_owner", hf));
            let wx1 = {
                let mut this: crate::lower::node_::Wx = wx.clone();
                this.taken = push(&this.taken, &owner);
                this.lets = push(&this.lets, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(owner.clone()), crate::lower::model::Ex::XCall(Text::from(format!("prism_rtl::Link::<{}>::new", &wx.node_)), Array::new())));
                this.build = push(&this.build, &crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(owner.clone())), Text::lit("link"), Array::from(vec![crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XVar(Text::lit("node"))))]))));
                this
            };
            let env0 = crate::lower::types::bind(benv, &Text::lit("#owner"), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(owner.clone()), crate::lower::types::Holding::Owned, crate::lower::model::OutTy::OutUnit));
            let lets0 = Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(owner.clone()), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(owner.clone()))))]);
            run_to_end(fold_job(crate::check::errors::range0(&len(&dyns)), (wx1.clone(), env0.clone(), lets0.clone()), {
                let dyns = dyns.clone();
                let hf = hf.clone();
                let menv = menv.clone();
                let lx = lx.clone();
                Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::types::Env, Array<crate::lower::model::Do>), Nat)| {
                    let dyns = dyns.clone();
                    let hf = hf.clone();
                    let menv = menv.clone();
                    let lx = lx.clone();
                    entered(once_job(move || {
                        let (w, en, ls) = p0;
                        let j = p1;
                        match index(&dyns, &j) {
                            Some((y, d)) => {
                                let name = Text::from(format!("{}_dyn_{}", &hf, &(&j + &Nat::from(1u32))));
                                let port = Text::from(format!("{}_port", &name));
                                call_then(crate::lower::node_::dynamics::start_dynamic_expr(w.clone(), menv.clone(), d.clone()), move |dynamic_expr_15116: (crate::lower::model::Ex, Array<crate::lower::node_::Read>)| {
                                    let (ex, reads) = dynamic_expr_15116;
                                    call_then(crate::lower::types::start_out_ty_of(lx.clone(), crate::lower::types::peel(&crate::lower::type_at(&lx, &d.span))), move |out_ty_of_15163: crate::lower::model::OutTy| {
                                        let t = out_ty_of_15163;
                                        if !crate::lower::node_::def::all_inited(&w, &reads) {
                                            prism_rtl::Turn::Finished((w.clone(), en.clone(), ls.clone()))
                                        } else {
                                            {
                                                let w2 = {
                                                    let mut this: crate::lower::node_::Wx = w.clone();
                                                    this.taken = append(&this.taken, &Array::from(vec![name.clone(), port.clone()]));
                                                    this.getters = push(&this.getters, &crate::lower::model::MethDef { name: name.clone(), recv: crate::lower::model::Recv::RecvRef, params: Array::new(), cx_: crate::lower::model::CxArg::CxRef, ret: t.clone(), body: Array::new(), tail: ex.clone(), doc: Text::from(format!("The host at `{}`\'s dynamic answer `{}`, read at the read point (round 3 DY).", &hf, &crate::lower::functions::src_text(&lx, &lx.file, &y.span))) });
                                                    this.lets = push(&this.lets, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaBind(port.clone())), crate::lower::model::OutTy::OutRc(Rc::new(crate::lower::model::OutTy::OutPort(Rc::new(crate::lower::model::OutTy::OutUnit))))), crate::lower::model::Ex::XCall(Text::lit("Rc::new"), Array::from(vec![crate::lower::model::Ex::XCall(Text::lit("Port::new"), Array::new())]))));
                                                    this.fields = push(&this.fields, &(port.clone(), crate::lower::model::OutTy::OutRc(Rc::new(crate::lower::model::OutTy::OutPort(Rc::new(crate::lower::model::OutTy::OutUnit)))), Text::from(format!("the dynamic answer `{}` moved: its blueprints push the child\'s place next tick", &name))));
                                                    this.moves = push(&this.moves, &(port.clone(), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(port.clone())))));
                                                    this.dyn_answers = push(&this.dyn_answers, &(name.clone(), reads.clone()));
                                                    this
                                                };
                                                prism_rtl::Turn::Finished((w2.clone(), crate::lower::types::bind(&en, &Text::from(format!("#dyn{}", &dyn_key(&y))), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(name.clone()), crate::lower::types::Holding::Owned, t.clone())), push(&ls, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(port.clone()), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(port.clone())))))))
                                            }
                                        }
                                    })
                                })
                            },
                            None => prism_rtl::Turn::Finished((w.clone(), en.clone(), ls.clone())),
                        }
                    }))
                }) as Rc<dyn Fn(((crate::lower::node_::Wx, crate::lower::types::Env, Array<crate::lower::model::Do>), Nat)) -> Rc<dyn prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, Array<crate::lower::model::Do>)>>>
            }))
        }
    }
}

/// ```prism
/// ?DynamicAnswer: fn Lx, Expr -> ?Expr
/// ```
pub fn dynamic_answer(lx: &crate::lower::Lx, x: &crate::syntax::Expr) -> Option<crate::syntax::Expr> {
    if &crate::lower::types::layer_of(&crate::lower::type_at(lx, &x.span)) != &crate::lower::types::Layer::LyDyn {
        None
    } else {
        match &*x.kind {
            crate::syntax::ExprKind::EFreeSigil(m16593_0_0, inner) if (m16593_0_0 == &Text::lit("$")) => if &crate::lower::types::layer_of(&crate::lower::type_at(lx, &inner.span)) == &crate::lower::types::Layer::LyDyn {
                Some((**inner).clone())
            } else {
                None
            },
            _ => Some(x.clone()),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// ```prism
/// DynKey: fn Expr -> Text
/// ```
pub fn dyn_key(x: &crate::syntax::Expr) -> Text {
    Text::from(format!("{}:{}", &x.span.start, &x.span.end))
}

/// ```prism
/// HostDocGetter: fn Text, Pos, [Place], [ForDef], [GenDef] -> MethDef
/// ```
pub fn host_doc_getter(name: &Text, pos: &crate::lower::model::Pos_, places: &Array<crate::lower::node_::Place>, builders: &Array<crate::lower::model::ForDef>, gens: &Array<crate::lower::model::GenDef>) -> crate::lower::model::MethDef {
    let start = crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaMut(Text::lit("doc"))), crate::lower::types::host_doc_ty()), crate::lower::model::Ex::XCall(Text::lit("prism_rtl::HostDoc::new"), Array::new()));
    let body = crate::lower::node_::finish::document_body(&{
        let f = Rc::new(crate::lower::node_::finish::map_insert);
        Rc::new(move |(a0, a1): (crate::lower::model::Ex, crate::lower::model::Ex)| {
            let f = f.clone();
            once_job(move || prism_rtl::Turn::Finished(f(&a0, &a1)))
        }) as Rc<dyn Fn((crate::lower::model::Ex, crate::lower::model::Ex)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Do>>>
    }, places, builders, gens);
    crate::lower::model::MethDef { name: name.clone(), recv: crate::lower::model::Recv::RecvRef, params: Array::new(), cx_: crate::lower::model::CxArg::CxRef, ret: crate::lower::types::host_doc_ty(), body: append(&Array::from(vec![start.clone()]), &body), tail: crate::lower::model::Ex::XVar(Text::lit("doc")), doc: Text::from(format!("The places of the child hosted at place {}: each place\'s entry by its path relative to the child (pick HO). Read only by the snapshot of `$doc`\'s outer (pick ST).", &crate::lower::model::place_text(pos))) }
}

/// ```prism
/// SnapGetter: fn Text, OutTy, Text -> MethDef
/// ```
pub fn snap_getter(name: &Text, t: &crate::lower::model::OutTy, doc: &Text) -> crate::lower::model::MethDef {
    crate::lower::model::MethDef { name: name.clone(), recv: crate::lower::model::Recv::RecvRef, params: Array::new(), cx_: crate::lower::model::CxArg::CxRef, ret: t.clone(), body: Array::new(), tail: crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}_snap", name)))), Text::lit("get"), Array::from(vec![crate::lower::model::Ex::XCx])), doc: doc.clone() }
}

/// ```prism
/// StartedLine: fn Wx, ?Bn -> ((Wx, Wres))
/// ```
pub fn started_line(wx: &crate::lower::node_::Wx, bound_opt: &Option<crate::lower::types::Bn>) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    let wx1 = {
        let mut this: crate::lower::node_::Wx = wx.clone();
        this.pos = crate::lower::model::next_pos(&this.pos);
        this
    };
    let (id, wx2) = match bound_opt {
        Some(crate::lower::types::Bn::BnEv(er, _)) => (er.node_.clone(), wx1.clone()),
        _ => {
            let (nm, w) = crate::lower::node_::fresh_name(&wx1, &Text::lit("started"));
            crate::lower::node_::add_gn(&w, &nm, &crate::lower::model::OutTy::OutUnit, &crate::lower::node_::GnKind::GnStarted, &Nat::from(0u32))
        },
    };
    let wx3 = {
        let mut this: crate::lower::node_::Wx = wx2.clone();
        this.started = push(&this.started, &id);
        this
    };
    (wx3.clone(), crate::lower::node_::Wres::WrEv(crate::lower::node_::ev_ref_of(&wx3, &id)))
}

/// ```prism
/// DeferLine: unbounded fn Wx, Env, [Arg], Expr, ?Nat -> ((Wx, Wres))
/// ```
pub fn defer_line(wx: &crate::lower::node_::Wx, menv: &crate::lower::types::Env, args: &Array<crate::syntax::Arg>, e: &crate::syntax::Expr, target_opt: &Option<Nat>) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    let lx = wx.lx.clone();
    let t = crate::lower::types::out_ty_of(&lx, &crate::lower::types::out_of(&crate::lower::type_at(&lx, &e.span)));
    let (field_, wx1) = crate::lower::node_::fresh_name(wx, &Text::lit("deferred"));
    let (id, wx2) = match target_opt {
        Some(n) => (n.clone(), wx1.clone()),
        None => crate::lower::node_::add_gn(&wx1, &Text::from(format!("{}_fired", &field_)), &t, &crate::lower::node_::GnKind::GnDeferred, &Nat::from(0u32)),
    };
    let wx3 = crate::lower::node_::add_field_last(&wx2, &field_, &crate::lower::model::OutTy::OutDefer(Rc::new(t.clone())), &Text::lit("`@Defer`"), &crate::lower::model::Ex::XCall(Text::lit("Defer::new"), Array::new()));
    let wx4 = {
        let mut this: crate::lower::node_::Wx = wx3.clone();
        this.defers = push(&this.defers, &(field_.clone(), id.clone()));
        this
    };
    match index(args, &Nat::from(0u32)) {
        Some(a) => {
            let (r, wx5) = crate::lower::node_::dynamics::event_ref(&wx4, menv, &a.value);
            (crate::lower::node_::connect(&wx5, &r, &crate::lower::node_::Sk::SkArm(field_.clone())), crate::lower::node_::Wres::WrEv(crate::lower::node_::ev_ref_of(&wx5, &id)))
        },
        None => (wx4.clone(), crate::lower::node_::Wres::WrEv(crate::lower::node_::ev_ref_of(&wx4, &id))),
    }
}

/// ```prism
/// DistinctLine: unbounded fn Wx, Env, [Arg], Expr, ?Bn -> ((Wx, Wres))
/// ```
pub fn distinct_line(wx: &crate::lower::node_::Wx, menv: &crate::lower::types::Env, args: &Array<crate::syntax::Arg>, e: &crate::syntax::Expr, bound_opt: &Option<crate::lower::types::Bn>) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    let lx = wx.lx.clone();
    match index(args, &Nat::from(0u32)) {
        None => {
            let wx2 = {
                let mut this: crate::lower::node_::Wx = wx.clone();
                this.build = push(&this.build, &crate::lower::expr::refusal_do(&Text::lit("an `@Distinct` without its dynamic")));
                this
            };
            (wx2.clone(), crate::lower::node_::Wres::WrUnit)
        },
        Some(a) => {
            let t = crate::lower::types::out_ty_of(&lx, &crate::lower::types::peel(&crate::lower::type_at(&lx, &a.value.span)));
            let (name, wx1) = 'm20396: {
                if let Some(crate::lower::types::Bn::BnHold(f, _)) = bound_opt {
                    break 'm20396 (f.clone(), wx.clone());
                }
                if let Some(crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(m20396_1_0_0, f, _), _, _)) = bound_opt && let crate::lower::model::Ex::XSelf = &**m20396_1_0_0 {
                    break 'm20396 (f.clone(), wx.clone());
                }
                crate::lower::node_::fresh_name(wx, &Text::lit("distinct"))
            };
            let kept = Text::from(format!("{}_kept", &name));
            let source = Text::from(format!("{}_source", &name));
            let (ex, reads) = crate::lower::node_::dynamics::dynamic_expr(&wx1, menv, &a.value);
            let first_ = crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XVar(Text::lit("node"))), kept.clone())), Text::lit("set"), Array::from(vec![crate::lower::model::Ex::XCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("node"))), source.clone(), Array::from(vec![crate::lower::model::Ex::XCx]))])), crate::lower::model::Ex::XCx])));
            let sample = crate::lower::model::Ex::XMatch(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), kept.clone())), Text::lit("get"), Array::from(vec![crate::lower::model::Ex::XCx]))), Array::from(vec![crate::lower::model::XArm { pat: crate::lower::model::Pa::PaCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("v"))])), conds: Array::new(), body: crate::lower::model::Ex::XVar(Text::lit("v")) }, crate::lower::model::XArm { pat: crate::lower::model::Pa::PaUnit(Text::lit("None")), conds: Array::new(), body: crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XSelf), source.clone(), Array::from(vec![crate::lower::model::Ex::XCx])) }]), false, t.clone());
            let wx2 = {
                let mut this: crate::lower::node_::Wx = wx1.clone();
                this.taken = append(&this.taken, &Array::from(vec![kept.clone(), source.clone()]));
                this.fields = push(&this.fields, &(kept.clone(), crate::lower::model::OutTy::OutHold(Rc::new(crate::lower::model::OutTy::OutOpt(Rc::new(t.clone())))), Text::lit("`@Distinct`\'s value: its source\'s, written only when it changes")));
                this.moves = push(&this.moves, &(kept.clone(), crate::lower::model::Ex::XCall(Text::lit("Hold::new"), Array::from(vec![crate::lower::model::Ex::XNone, crate::lower::model::Ex::XCx]))));
                this.build = push(&this.build, &first_);
                this.getters = append(&this.getters, &Array::from(vec![crate::lower::model::MethDef { name: source.clone(), recv: crate::lower::model::Recv::RecvRef, params: Array::new(), cx_: crate::lower::model::CxArg::CxRef, ret: t.clone(), body: Array::new(), tail: ex.clone(), doc: Text::lit("`@Distinct`\'s source, read at the build.") }, crate::lower::model::MethDef { name: name.clone(), recv: crate::lower::model::Recv::RecvRef, params: Array::new(), cx_: crate::lower::model::CxArg::CxRef, ret: t.clone(), body: Array::new(), tail: sample.clone(), doc: Text::lit("`@Distinct`\'s dynamic: the value it holds at the read point.") }]));
                this.dyn_reads = insert(&insert(&this.dyn_reads, &name, &Array::from(vec![crate::lower::node_::Read::OwnRead(kept.clone())])), &source, &reads);
                this
            };
            let (r, wx3) = crate::lower::node_::dynamics::updated_event(&wx2, menv, args, &t);
            (crate::lower::node_::connect(&wx3, &r, &crate::lower::node_::Sk::SkDistinct(kept.clone())), crate::lower::node_::Wres::WrDyn(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XSelf), name.clone(), Array::from(vec![crate::lower::model::Ex::XCx])), Array::from(vec![crate::lower::node_::Read::OwnRead(kept.clone())]), t.clone()))
        },
    }
}

/// ```prism
/// PerKeyLine: unbounded fn Wx, Env, [Arg], ?Bn -> ((Wx, Wres))
/// ```
pub fn per_key_line(wx: &crate::lower::node_::Wx, menv: &crate::lower::types::Env, args: &Array<crate::syntax::Arg>, bound_opt: &Option<crate::lower::types::Bn>) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    let lx = wx.lx.clone();
    match index(args, &Nat::from(0u32)) {
        None => {
            let wx2 = {
                let mut this: crate::lower::node_::Wx = wx.clone();
                this.build = push(&this.build, &crate::lower::expr::refusal_do(&Text::lit("an `@PerKey` without its dynamic")));
                this
            };
            (wx2.clone(), crate::lower::node_::Wres::WrUnit)
        },
        Some(a) => {
            let (kt, vt) = match crate::lower::types::peel(&crate::lower::type_at(&lx, &a.value.span)) {
                crate::check::types::Ty::TyMap(k, v_) => (crate::lower::types::out_ty_of(&lx, &*k), crate::lower::types::out_ty_of(&lx, &*v_)),
                _ => (crate::lower::model::OutTy::OutUnit, crate::lower::model::OutTy::OutUnit),
            };
            let src_ty = crate::lower::model::OutTy::OutMap(Rc::new(kt.clone()), Rc::new(vt.clone()));
            let t = crate::lower::model::OutTy::OutMap(Rc::new(kt.clone()), Rc::new(crate::lower::model::OutTy::OutDyn(Rc::new(vt.clone()))));
            let (name, wx1) = 'm23708: {
                if let Some(crate::lower::types::Bn::BnHold(f, _)) = bound_opt {
                    break 'm23708 (f.clone(), wx.clone());
                }
                if let Some(crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(m23708_1_0_0, f, _), _, _)) = bound_opt && let crate::lower::model::Ex::XSelf = &**m23708_1_0_0 {
                    break 'm23708 (f.clone(), wx.clone());
                }
                crate::lower::node_::fresh_name(wx, &Text::lit("per_key"))
            };
            let kept = Text::from(format!("{}_kept", &name));
            let source = Text::from(format!("{}_source", &name));
            let (ex, reads) = crate::lower::node_::dynamics::dynamic_expr(&wx1, menv, &a.value);
            let first_ = crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XVar(Text::lit("node"))), kept.clone())), Text::lit("start"), Array::from(vec![crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("node"))), source.clone(), Array::from(vec![crate::lower::model::Ex::XCx])), crate::lower::model::Ex::XCx])));
            let sample = crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), kept.clone())), Text::lit("outer"), Array::from(vec![crate::lower::model::Ex::XCx, crate::lower::model::Ex::XClosure(false, Array::new(), Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XSelf), source.clone(), Array::from(vec![crate::lower::model::Ex::XCx]))))]));
            let wx2 = {
                let mut this: crate::lower::node_::Wx = wx1.clone();
                this.taken = append(&this.taken, &Array::from(vec![kept.clone(), source.clone()]));
                this.fields = push(&this.fields, &(kept.clone(), crate::lower::model::OutTy::OutNamed(Text::lit("prism_rtl::PerKey"), Array::from(vec![kt.clone(), vt.clone()])), Text::lit("`@PerKey`\'s outer and each key\'s inner")));
                this.moves = push(&this.moves, &(kept.clone(), crate::lower::model::Ex::XCall(Text::lit("prism_rtl::PerKey::new"), Array::new())));
                this.build = push(&this.build, &first_);
                this.getters = append(&this.getters, &Array::from(vec![crate::lower::model::MethDef { name: source.clone(), recv: crate::lower::model::Recv::RecvRef, params: Array::new(), cx_: crate::lower::model::CxArg::CxRef, ret: src_ty.clone(), body: Array::new(), tail: ex.clone(), doc: Text::lit("`@PerKey`\'s source, read at the build.") }, crate::lower::model::MethDef { name: name.clone(), recv: crate::lower::model::Recv::RecvRef, params: Array::new(), cx_: crate::lower::model::CxArg::CxRef, ret: t.clone(), body: Array::new(), tail: sample.clone(), doc: Text::lit("`@PerKey`\'s outer: each key\'s inner by key, at the read point.") }]));
                this.dyn_reads = insert(&insert(&this.dyn_reads, &name, &Array::from(vec![crate::lower::node_::Read::OwnRead(kept.clone())])), &source, &reads);
                this
            };
            let (r, wx3) = crate::lower::node_::dynamics::updated_event(&wx2, menv, args, &src_ty);
            (crate::lower::node_::connect(&wx3, &r, &crate::lower::node_::Sk::SkPerKey(kept.clone())), crate::lower::node_::Wres::WrDyn(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XSelf), name.clone(), Array::from(vec![crate::lower::model::Ex::XCx])), Array::from(vec![crate::lower::node_::Read::OwnRead(kept.clone())]), t.clone()))
        },
    }
}

/// ```prism
/// RunLine: unbounded fn Wx, Env, [Arg], Expr, ?Nat -> ((Wx, Wres))
/// ```
pub fn run_line(wx: &crate::lower::node_::Wx, benv: &crate::lower::types::Env, args: &Array<crate::syntax::Arg>, e: &crate::syntax::Expr, target_opt: &Option<Nat>) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    let lx = wx.lx.clone();
    let t = crate::lower::types::out_ty_of(&lx, &crate::lower::types::out_of(&crate::lower::type_at(&lx, &e.span)));
    let (p_, wx1) = crate::lower::node_::fresh_name(wx, &Text::lit("run"));
    let wx2 = {
        let mut this: crate::lower::node_::Wx = wx1.clone();
        this.pos = crate::lower::model::next_pos(&this.pos);
        this.taken = append(&this.taken, &Array::from(vec![Text::from(format!("{}_job", &p_)), Text::from(format!("{}_again", &p_)), Text::from(format!("{}_started", &p_)), Text::from(format!("{}_turn", &p_))]));
        this
    };
    let start = match index(args, &Nat::from(0u32)) {
        Some(a) => match &*a.value.kind {
            crate::syntax::ExprKind::EName(n) => {
                let (q_opt, _) = crate::check::env::names::resolve_value(&lx.g, &lx.home, n);
                crate::lower::model::Ex::XPath(crate::lower::expr::start_path(&lx, &or(&q_opt, &Text::lit(""))))
            },
            _ => crate::lower::expr::refusal(&Text::lit("an `@Run` of a function value that is not a name")),
        },
        None => crate::lower::expr::refusal(&Text::lit("an `@Run` without its function")),
    };
    let x = match index(args, &Nat::from(1u32)) {
        Some(a) => crate::lower::types::own(&crate::lower::expr::value_of(&lx, benv, &a.value)),
        None => crate::lower::model::Ex::XUnit,
    };
    let wx3 = crate::lower::node_::add_field(&wx2, &Text::from(format!("{}_job", &p_)), &crate::lower::model::OutTy::OutHold(Rc::new(crate::lower::model::OutTy::OutJob(Rc::new(t.clone())))), &Text::lit("`@Run`\'s job (`@Machine`\'s state)"), &crate::lower::model::Ex::XCall(Text::lit("Hold::new"), Array::from(vec![crate::lower::model::Ex::XApply(Rc::new(start.clone()), Array::from(vec![x.clone()])), crate::lower::model::Ex::XCx])));
    let wx4 = crate::lower::node_::add_field_last(&wx3, &Text::from(format!("{}_again", &p_)), &crate::lower::model::OutTy::OutDefer(Rc::new(crate::lower::model::OutTy::OutUnit)), &Text::lit("`@Run`\'s `!again`"), &crate::lower::model::Ex::XCall(Text::lit("Defer::new"), Array::new()));
    let (s, wx5) = crate::lower::node_::add_gn(&wx4, &Text::from(format!("{}_started", &p_)), &crate::lower::model::OutTy::OutUnit, &crate::lower::node_::GnKind::GnStarted, &Nat::from(0u32));
    let (a, wx6) = crate::lower::node_::add_gn(&wx5, &Text::from(format!("{}_again", &p_)), &crate::lower::model::OutTy::OutUnit, &crate::lower::node_::GnKind::GnDeferred, &Nat::from(0u32));
    let (m, wx7) = crate::lower::node_::dynamics::merge(&wx6, &Text::from(format!("{}_turn", &p_)), &crate::lower::model::OutTy::OutUnit, &crate::lower::node_::ev_ref_of(&wx6, &s), &crate::lower::node_::ev_ref_of(&wx6, &a));
    let (res, wx8) = match target_opt {
        Some(n) => (n.clone(), wx7.clone()),
        None => crate::lower::node_::add_gn(&wx7, &Text::from(format!("{}_done", &p_)), &t, &crate::lower::node_::GnKind::GnNamed, &Nat::from(0u32)),
    };
    let wx9 = {
        let mut this: crate::lower::node_::Wx = crate::lower::node_::connect(&wx8, &crate::lower::node_::ev_ref_of(&wx8, &m), &crate::lower::node_::Sk::SkCycle(Text::from(format!("{}_job", &p_)), Text::from(format!("{}_again", &p_)), res.clone()));
        this.started = push(&this.started, &s);
        this.defers = push(&this.defers, &(Text::from(format!("{}_again", &p_)), a.clone()));
        this
    };
    (wx9.clone(), crate::lower::node_::Wres::WrEv(crate::lower::node_::ev_ref_of(&wx9, &res)))
}

/// ```prism
/// MachineLine: unbounded fn Wx, Env, Env, [Arg], Expr, ?Nat -> ((Wx, Wres))
/// ```
pub fn machine_line(wx: &crate::lower::node_::Wx, benv: &crate::lower::types::Env, menv: &crate::lower::types::Env, args: &Array<crate::syntax::Arg>, e: &crate::syntax::Expr, target_opt: &Option<Nat>) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    let lx = wx.lx.clone();
    let t = crate::lower::types::out_ty_of(&lx, &crate::lower::types::out_of(&crate::lower::type_at(&lx, &e.span)));
    let (f, wx1) = crate::lower::node_::fresh_name(wx, &Text::lit("machine"));
    let step_ = match index(args, &Nat::from(0u32)) {
        Some(a) => match &*a.value.kind {
            crate::syntax::ExprKind::EName(n) => {
                let (q_opt, _) = crate::check::env::names::resolve_value(&lx.g, &lx.home, n);
                match &q_opt {
                    Some(q) => crate::lower::value_path(&lx, q),
                    None => Text::lit(""),
                }
            },
            _ => Text::lit(""),
        },
        None => Text::lit(""),
    };
    match (step_.clone(), index(args, &Nat::from(1u32)), index(args, &Nat::from(2u32))) {
        (sp, Some(init), Some(ev)) if (&sp != &Text::lit("")) => {
            let st = crate::lower::types::out_ty_of(&lx, &crate::lower::types::peel(&crate::lower::type_at(&lx, &init.value.span)));
            let x = crate::lower::types::own(&crate::lower::expr::value_of(&lx, benv, &init.value));
            let wx2 = crate::lower::node_::add_field(&wx1, &Text::from(format!("{}_state", &f)), &crate::lower::model::OutTy::OutHold(Rc::new(st.clone())), &Text::lit("`@Machine`\'s state"), &crate::lower::model::Ex::XCall(Text::lit("Hold::new"), Array::from(vec![x.clone(), crate::lower::model::Ex::XCx])));
            let (out, wx3) = match target_opt {
                Some(n) => (n.clone(), wx2.clone()),
                None => crate::lower::node_::add_gn(&wx2, &Text::from(format!("{}_fired", &f)), &t, &crate::lower::node_::GnKind::GnNamed, &Nat::from(0u32)),
            };
            let (r, wx4) = crate::lower::node_::dynamics::event_ref(&wx3, menv, &ev.value);
            (crate::lower::node_::connect(&wx4, &r, &crate::lower::node_::Sk::SkMachine(Text::from(format!("{}_state", &f)), sp.clone(), out.clone())), crate::lower::node_::Wres::WrEv(crate::lower::node_::ev_ref_of(&wx4, &out)))
        },
        _ => {
            let wx2 = {
                let mut this: crate::lower::node_::Wx = wx1.clone();
                this.build = push(&this.build, &crate::lower::expr::refusal_do(&Text::lit("an `@Machine` whose step is not a named function")));
                this
            };
            (wx2.clone(), crate::lower::node_::Wres::WrUnit)
        },
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// InlineWidget: unbounded fn Wx, Env, Env, Text, ValInfo, [Arg], Expr -> ((Wx, Wres))
/// ```
pub fn inline_widget(wx: &crate::lower::node_::Wx, benv: &crate::lower::types::Env, menv: &crate::lower::types::Env, qk: &Text, v_: &crate::check::env::ValInfo, args: &Array<crate::syntax::Arg>, e: &crate::syntax::Expr) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    let lx = wx.lx.clone();
    let clauses = crate::lower::jobs::clauses_of(&lx.g, qk);
    let w_opt = widget_decl_of(&lx.g, qk);
    let (params, body_opt) = match &w_opt {
        Some(wd) => (Array::new(), Some(wd.body.clone())),
        None => 'm29415: {
            if let m29415_0 = &clauses && (m29415_0.len() == 1) && let Some(c) = index(m29415_0, &Nat::from(0u32)) {
                break 'm29415 match &c.body {
                    crate::syntax::decls::FnBody::BodyBlock(b) => (c.params.clone(), Some(b.clone())),
                    crate::syntax::decls::FnBody::BodyExpr(x) => (c.params.clone(), Some(crate::syntax::Block { stmts: Array::from(vec![crate::syntax::Stmt { kind: crate::syntax::StmtKind::SExpr(x.clone()), span: x.span.clone() }]), inline: true, span: x.span.clone() })),
                };
            }
            (Array::new(), None)
        },
    };
    match &body_opt {
        None => if &len(&clauses) == &Nat::from(0u32) {
            {
                let wx2 = {
                    let mut this: crate::lower::node_::Wx = wx.clone();
                    this.build = push(&this.build, &crate::lower::expr::refusal_do(&Text::from(format!("the builtin widget {}", &crate::check::types::bare_name(qk)))));
                    this
                };
                (wx2.clone(), crate::lower::node_::Wres::WrUnit)
            }
        } else {
            match index(args, &Nat::from(0u32)) {
                Some(a) => {
                    let call = crate::syntax::Block { stmts: Array::from(vec![crate::syntax::Stmt { kind: crate::syntax::StmtKind::SExpr(e.clone()), span: e.span.clone() }]), inline: true, span: e.span.clone() };
                    crate::lower::node_::switch_::clause_widget_line(wx, menv, &a.value, &call, qk, v_, e)
                },
                None => {
                    let wx2 = {
                        let mut this: crate::lower::node_::Wx = wx.clone();
                        this.build = push(&this.build, &crate::lower::expr::refusal_do(&Text::lit("a widget of several clauses that takes no arguments")));
                        this
                    };
                    (wx2.clone(), crate::lower::node_::Wres::WrUnit)
                },
            }
        },
        Some(body) => if &recursion(&wx.inlining, qk) > &Nat::from(16u32) {
            too_deep(wx, qk, e)
        } else {
            {
                let lxc = crate::lower::program::in_module_at(&lx, &v_.file, &v_.home, &lx.site);
                let ptys = match &v_.scheme.ty {
                    crate::check::types::Ty::TyFn(_, ps, _) => ps.clone(),
                    _ => Array::new(),
                };
                let (wx1, be1, me1) = run_to_end(fold_job(crate::check::errors::range0(&len(&params)), (wx.clone(), crate::lower::types::empty_env(), crate::lower::types::empty_env()), {
                    let params = params.clone();
                    let lxc = lxc.clone();
                    let ptys = ptys.clone();
                    let args = args.clone();
                    let benv = benv.clone();
                    let menv = menv.clone();
                    Rc::new(move |(p0, p1): ((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), Nat)| {
                        let params = params.clone();
                        let lxc = lxc.clone();
                        let ptys = ptys.clone();
                        let args = args.clone();
                        let benv = benv.clone();
                        let menv = menv.clone();
                        entered(once_job(move || {
                            let (w, be, me) = p0;
                            let i = p1;
                            {
                                let p_ = or(&index(&params, &i), &crate::lower::patterns::dummy_pat());
                                let nkey = crate::lower::functions::plain_binder(&lxc, &p_);
                                let pty = or(&index(&ptys, &i), &crate::check::types::Ty::TyErr);
                                match index(&args, &i) {
                                    None => prism_rtl::Turn::Finished((w.clone(), be.clone(), me.clone())),
                                    Some(a) => prism_rtl::Turn::Finished(bind_param(&w, &benv, &menv, &be, &me, &nkey, &pty, &a.value)),
                                }
                            }
                        }))
                    }) as Rc<dyn Fn(((crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env), Nat)) -> Rc<dyn prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env)>>>
                }));
                let inner = {
                    let mut this: crate::lower::node_::Wx = wx1.clone();
                    this.lx = lxc.clone();
                    this.inlining = push(&this.inlining, qk);
                    this.result = crate::lower::node_::Wres::WrUnit;
                    this
                };
                let done = crate::lower::node_::def::block_into(&inner, &be1, &me1, body);
                let back_ = {
                    let mut this: crate::lower::node_::Wx = done.clone();
                    this.lx = lx.clone();
                    this.inlining = wx.inlining.clone();
                    this.result = wx.result.clone();
                    this
                };
                (back_.clone(), done.result.clone())
            }
        },
    }
}

/// ```prism
/// Recursion: fn [Text], Text -> Nat
/// ```
pub fn recursion(inlining: &Array<Text>, qk: &Text) -> Nat {
    fold(inlining, &Nat::from(0u32), &(|n: &Nat, k: &Text| if k == qk { n + &Nat::from(1u32) } else { n.clone() }))
}

/// ```prism
/// TooDeep: unbounded fn Wx, Text, Expr -> ((Wx, Wres))
/// ```
pub fn too_deep(wx: &crate::lower::node_::Wx, qk: &Text, e: &crate::syntax::Expr) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    let lx = wx.lx.clone();
    let what = Text::from(format!("`{}` recurses deeper than the compiler inlines it (16 levels)", &crate::check::types::bare_name(qk)));
    let wx1 = {
        let mut this: crate::lower::node_::Wx = wx.clone();
        this.build = push(&this.build, &crate::lower::model::Do::DoReturn(crate::lower::model::Ex::XCtor(Text::lit("Err"), Array::from(vec![crate::lower::model::Ex::XCall(Text::lit("Fault::too_deep"), Array::from(vec![crate::lower::model::Ex::XStr(what.clone())]))]))));
        this.fallible = true;
        this
    };
    let t = crate::lower::types::out_ty_of(&lx, &crate::lower::types::out_of(&crate::lower::type_at(&lx, &e.span)));
    let called = match crate::lower::type_at(&lx, &e.span) {
        crate::check::types::Ty::TyAt(i, _) => (*i).clone(),
        other => other,
    };
    match crate::lower::types::layer_of(&called) {
        crate::lower::types::Layer::LyDyn => (wx1.clone(), crate::lower::node_::Wres::WrDyn(crate::lower::model::Ex::XUnreachable, Array::new(), t.clone())),
        crate::lower::types::Layer::LyEv => {
            let (id, wx2) = crate::lower::node_::add_gn(&wx1, &Text::lit("too_deep"), &t, &crate::lower::node_::GnKind::GnNever, &Nat::from(0u32));
            (wx2.clone(), crate::lower::node_::Wres::WrEv(crate::lower::node_::ev_ref_of(&wx2, &id)))
        },
        _ => if &t == &crate::lower::model::OutTy::OutUnit {
            (wx1.clone(), crate::lower::node_::Wres::WrUnit)
        } else {
            (wx1.clone(), crate::lower::node_::Wres::WrPlain(crate::lower::model::Ex::XUnreachable, t.clone()))
        },
    }
}

/// ```prism
/// ?WidgetDeclOf: fn G, Text -> ?WidgetDecl
/// ```
pub fn widget_decl_of(g: &crate::check::env::G, qk: &Text) -> Option<crate::syntax::decls::WidgetDecl> {
    fold(&g.defs, &None, &(|found_opt: &Option<crate::syntax::decls::WidgetDecl>, d: &crate::check::env::Def| if &d.qk == qk { def_widget(d, found_opt) } else { found_opt.clone() }))
}

/// ```prism
/// ?DefWidget: fn Def, ?WidgetDecl -> ?WidgetDecl
/// ```
pub fn def_widget(d: &crate::check::env::Def, other_opt: &Option<crate::syntax::decls::WidgetDecl>) -> Option<crate::syntax::decls::WidgetDecl> {
    match &d.body {
        crate::check::env::DefBody::DbWidget(w) => Some(w.clone()),
        _ => other_opt.clone(),
    }
}

/// ```prism
/// BindParam: unbounded fn Wx, Env, Env, Env, Env, Text, Ty, Expr -> ((Wx, Env, Env))
/// ```
pub fn bind_param(wx: &crate::lower::node_::Wx, cbenv: &crate::lower::types::Env, cmenv: &crate::lower::types::Env, be: &crate::lower::types::Env, me: &crate::lower::types::Env, nkey: &Text, pty: &crate::check::types::Ty, arg: &crate::syntax::Expr) -> (crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env) {
    let lx = wx.lx.clone();
    let t = crate::lower::types::out_ty_of(&lx, &crate::lower::types::peel(pty));
    match crate::lower::types::layer_of(pty) {
        crate::lower::types::Layer::LyBlueprint => {
            let b = crate::lower::types::Bn::BnWidget(arg.clone(), cbenv.clone(), cmenv.clone(), lx.clone());
            (wx.clone(), crate::lower::types::bind(be, nkey, &b), crate::lower::types::bind(me, nkey, &b))
        },
        crate::lower::types::Layer::LyEv => {
            let (r, wx2) = crate::lower::node_::dynamics::event_ref(wx, cmenv, arg);
            let b = crate::lower::types::Bn::BnEv(r.clone(), t.clone());
            (wx2.clone(), crate::lower::types::bind(be, nkey, &b), crate::lower::types::bind(me, nkey, &b))
        },
        crate::lower::types::Layer::LyDyn => {
            let (ex, reads) = crate::lower::node_::dynamics::dynamic_expr(wx, cmenv, arg);
            let b = crate::lower::types::Bn::BnDyn(ex.clone(), reads.clone(), t.clone());
            let (wx0, be0) = if crate::lower::node_::def::all_inited(wx, &reads) && crate::lower::node_::def::names_inited(cbenv, arg) {
                {
                    let (rsi, wxi) = crate::lower::node_::fresh_name(wx, &Text::from(format!("{}_arg", &crate::lower::snake(nkey))));
                    let wxj = {
                        let mut this: crate::lower::node_::Wx = wxi.clone();
                        this.lets = push(&this.lets, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaBind(Text::from(format!("{}_init", &rsi)))), t.clone()), crate::lower::types::own(&crate::lower::expr::value_of(&lx, &crate::lower::node_::def::init_env(cbenv), arg))));
                        this.inited = push(&this.inited, &rsi);
                        this
                    };
                    (wxj.clone(), crate::lower::types::bind(be, &Text::from(format!("{}#init", nkey)), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(Text::from(format!("{}_init", &rsi))), crate::lower::types::Holding::Owned, t.clone())))
                }
            } else {
                (wx.clone(), be.clone())
            };
            'm35418: {
                if let crate::lower::model::Ex::XMethod(m35418_0_0, _, _) = &ex && let crate::lower::model::Ex::XSelf = &**m35418_0_0 {
                    break 'm35418 (wx0.clone(), crate::lower::types::bind(&be0, nkey, &b), crate::lower::types::bind(me, nkey, &b));
                }
                {
                    let (rs, wx2) = crate::lower::node_::fresh_name(&wx0, &crate::lower::snake(nkey));
                    let getter = crate::lower::model::MethDef { name: rs.clone(), recv: crate::lower::model::Recv::RecvRef, params: Array::new(), cx_: crate::lower::model::CxArg::CxRef, ret: t.clone(), body: Array::new(), tail: ex.clone(), doc: Text::from(format!("`{}`, a widget\'s parameter, as its rows read it", nkey)) };
                    let wx3 = {
                        let mut this: crate::lower::node_::Wx = wx2.clone();
                        this.getters = push(&this.getters, &getter);
                        this.dyn_reads = insert(&this.dyn_reads, &rs, &reads);
                        this
                    };
                    let rb = crate::lower::types::Bn::BnDyn(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XSelf), rs.clone(), Array::from(vec![crate::lower::model::Ex::XCx])), Array::from(vec![crate::lower::node_::Read::OwnRead(rs.clone())]), t.clone());
                    (wx3.clone(), crate::lower::types::bind(&crate::lower::types::bind(&be0, nkey, &b), &Text::from(format!("{}#row", nkey)), &rb), crate::lower::types::bind(&crate::lower::types::bind(me, nkey, &b), &Text::from(format!("{}#row", nkey)), &rb))
                }
            }
        },
        _ => {
            let (rs, wx2) = crate::lower::node_::fresh_name(wx, &crate::lower::snake(nkey));
            let v_ = crate::lower::types::own(&crate::lower::expr::value_of(&lx, cbenv, arg));
            let wx3 = {
                let mut this: crate::lower::node_::Wx = wx2.clone();
                this.lets = push(&this.lets, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(rs.clone()), v_.clone()));
                this.fields = push(&this.fields, &(rs.clone(), t.clone(), Text::from(format!("`{}`", nkey))));
                this.inits = push(&this.inits, &(rs.clone(), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(rs.clone())))));
                this
            };
            let (be2, me2) = crate::lower::node_::bind_plain(be, me, nkey, &rs, &t);
            (wx3.clone(), be2.clone(), me2.clone())
        },
    }
}
