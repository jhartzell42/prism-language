//! The module `Lower.Templates`, from `target/bootstrap/src/prismc/lower/templates.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// ```prism
/// TemplateValue: unbounded fn Lx, Env, Template -> Vl
/// ```
pub fn template_value_f(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, tp_p2: &crate::syntax::Template) -> crate::lower::types::Vl {
    let start_p3 = Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaMut(Text::lit("out")), crate::lower::model::Ex::XCall(Text::lit("String::new"), Array::new()))]);
    let dos_p4 = crate::prelude::run_to_end(crate::prelude::fold_job(tp_p2.parts_p.clone(), start_p3.clone(), {
        let lx_p0x = lx_p0.clone();
        let env_p1x = env_p1.clone();
        Rc::new(move |(p0, p1): (Array<crate::lower::model::Do>, crate::syntax::TemplatePart)| {
            let lx_p0xy = lx_p0x.clone();
            let env_p1xy = env_p1x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_p5 = p0;
                let part_p6 = p1;
                crate::prelude::call_then(start_template_part_dos_f(lx_p0xy.clone(), env_p1xy.clone(), part_p6.clone()), move |template_part_dos_f_1601: Array<crate::lower::model::Do>| prism_rtl::Turn::Finished(crate::prelude::append(&acc_p5, &template_part_dos_f_1601)))
            }))
        }) as Rc<dyn Fn((Array<crate::lower::model::Do>, crate::syntax::TemplatePart)) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>
    }));
    crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XBlock(dos_p4.clone(), Rc::new(crate::lower::model::Ex::XCall(Text::lit("Text::from"), Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("out"))])))), crate::lower::model::OutTy::OutText)
}

/// The step machine of `TemplateValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TemplateValue: unbounded fn Lx, Env, Template -> Vl
/// ```
pub struct TemplateValue {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub tp_p2: crate::syntax::Template,
}

impl prism_rtl::Job<crate::lower::types::Vl> for TemplateValue {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::types::Vl> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let tp_p2 = &self.tp_p2;
        let start_p3 = Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaMut(Text::lit("out")), crate::lower::model::Ex::XCall(Text::lit("String::new"), Array::new()))]);
        let env_p1x = env_p1.clone();
        let lx_p0x = lx_p0.clone();
        let tp_p2x = tp_p2.clone();
        crate::prelude::call_value(crate::prelude::fold_job(tp_p2x.parts_p.clone(), start_p3.clone(), {
            let lx_p0xx = lx_p0x.clone();
            let env_p1xx = env_p1x.clone();
            Rc::new(move |(p0, p1): (Array<crate::lower::model::Do>, crate::syntax::TemplatePart)| {
                let lx_p0xxy = lx_p0xx.clone();
                let env_p1xxy = env_p1xx.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let acc_p5 = p0;
                    let part_p6 = p1;
                    crate::prelude::call_then(start_template_part_dos_f(lx_p0xxy.clone(), env_p1xxy.clone(), part_p6.clone()), move |template_part_dos_f_1601: Array<crate::lower::model::Do>| prism_rtl::Turn::Finished(crate::prelude::append(&acc_p5, &template_part_dos_f_1601)))
                }))
            }) as Rc<dyn Fn((Array<crate::lower::model::Do>, crate::syntax::TemplatePart)) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>
        }), move |fold_1553: Array<crate::lower::model::Do>| {
            let dos_p4 = fold_1553;
            prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XBlock(dos_p4.clone(), Rc::new(crate::lower::model::Ex::XCall(Text::lit("Text::from"), Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("out"))])))), crate::lower::model::OutTy::OutText))
        })
    }
}

/// `Start TemplateValue, x`: what the function value is when passed to `@Run`.
pub fn start_template_value_f(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, tp_p2: crate::syntax::Template) -> Rc<dyn prism_rtl::Job<crate::lower::types::Vl>> {
    Rc::new(TemplateValue { lx_p0, env_p1, tp_p2 })
}

/// ```prism
/// TemplatePartDos: unbounded fn Lx, Env, TemplatePart -> [Do]
/// ```
pub fn template_part_dos_f(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, part_p2: &crate::syntax::TemplatePart) -> Array<crate::lower::model::Do> {
    match part_p2 {
        crate::syntax::TemplatePart::TpText(t_p3) => Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("out"))), Text::lit("push_str"), Array::from(vec![crate::lower::model::Ex::XStr(t_p3.clone())])))]),
        crate::syntax::TemplatePart::TpPlaceholder(x_p4, col_o5) => {
            let v_p6 = crate::lower::expr::value_of_f(lx_p0, env_p1, x_p4);
            let column_p7 = match col_o5 {
                Some(c_p8) => crate::lower::model::Ex::XCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Ex::XIndex(c_p8.clone())])),
                None => crate::lower::model::Ex::XNone,
            };
            Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XCall(crate::lower::helper_f(&Text::lit("place")), Array::from(vec![crate::lower::model::Ex::XRefMut(Rc::new(crate::lower::model::Ex::XVar(Text::lit("out")))), shown_text_f(&v_p6), column_p7.clone()])))])
        },
        crate::syntax::TemplatePart::TpBlock(b_p9) => {
            let v_pa = crate::lower::expr::block_value_f(lx_p0, env_p1, b_p9);
            if &crate::lower::types::value_ty_f(&v_pa) == &crate::lower::model::OutTy::OutUnit {
                Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::types::own_f(&v_pa))])
            } else {
                Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XCall(crate::lower::helper_f(&Text::lit("place")), Array::from(vec![crate::lower::model::Ex::XRefMut(Rc::new(crate::lower::model::Ex::XVar(Text::lit("out")))), shown_text_f(&v_pa), crate::lower::model::Ex::XNone])))])
            }
        },
        crate::syntax::TemplatePart::TpCall(n_pb, args_pc, parts_od, _) => {
            let plain_pe = crate::syntax::SName { sigils_p: crate::syntax::lexer::chars::after_first_f(&n_pb.sigils_p), path_p: n_pb.path_p.clone(), span_p: n_pb.span_p.clone() };
            let (qk_oj, _) = crate::check::env::names::resolve_value_f(&lx_p0.g_p, &lx_p0.home_p, n_pb);
            let (qk2_ok, _) = crate::check::env::names::resolve_value_f(&lx_p0.g_p, &lx_p0.home_p, &plain_pe);
            let callee_pf = match &qk_oj {
                Some(q_pl) => crate::lower::value_path_f(lx_p0, q_pl),
                None => match &qk2_ok {
                    Some(q_pm) => crate::lower::value_path_f(lx_p0, q_pm),
                    None => crate::lower::snake_f(&crate::check::env::sname_key_f(n_pb)),
                },
            };
            let body_pg = match parts_od {
                Some(ps_pn) => {
                    let inner_po = crate::prelude::run_to_end(crate::prelude::fold_job(ps_pn.clone(), Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaMut(Text::lit("out")), crate::lower::model::Ex::XCall(Text::lit("String::new"), Array::new()))]), {
                        let lx_p0x = lx_p0.clone();
                        let env_p1x = env_p1.clone();
                        Rc::new(move |(p0, p1): (Array<crate::lower::model::Do>, crate::syntax::TemplatePart)| {
                            let lx_p0xy = lx_p0x.clone();
                            let env_p1xy = env_p1x.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let acc_pp = p0;
                                let p_pq = p1;
                                crate::prelude::call_then(start_template_part_dos_f(lx_p0xy.clone(), env_p1xy.clone(), p_pq.clone()), move |template_part_dos_f_2929: Array<crate::lower::model::Do>| prism_rtl::Turn::Finished(crate::prelude::append(&acc_pp, &template_part_dos_f_2929)))
                            }))
                        }) as Rc<dyn Fn((Array<crate::lower::model::Do>, crate::syntax::TemplatePart)) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>
                    }));
                    Array::from(vec![crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XBlock(inner_po.clone(), Rc::new(crate::lower::model::Ex::XCall(Text::lit("Text::from"), Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("out"))]))))))])
                },
                None => Array::new(),
            };
            let passed_ph = match &qk_oj {
                Some(q_pr) => template_args_f(lx_p0, env_p1, q_pr, args_pc, &body_pg),
                None => match &qk2_ok {
                    Some(q_ps) => template_args_f(lx_p0, env_p1, q_ps, args_pc, &body_pg),
                    None => crate::prelude::append(&crate::prelude::run_to_end(crate::prelude::each_job(args_pc.clone(), {
                        let lx_p0x = lx_p0.clone();
                        let env_p1x = env_p1.clone();
                        Rc::new(move |p0: crate::syntax::Arg| {
                            let lx_p0xy = lx_p0x.clone();
                            let env_p1xy = env_p1x.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let a_pt = p0;
                                prism_rtl::Turn::More(Rc::new(crate::lower::expr::Argument { lx_p0: lx_p0xy.clone(), env_p1: env_p1xy.clone(), e_p2: a_pt.value_p.clone() }))
                            }))
                        }) as Rc<dyn Fn(crate::syntax::Arg) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
                    })), &body_pg),
                },
            };
            let call_pi = crate::lower::model::Ex::XCall(callee_pf.clone(), passed_ph.clone());
            Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XCall(crate::lower::helper_f(&Text::lit("place")), Array::from(vec![crate::lower::model::Ex::XRefMut(Rc::new(crate::lower::model::Ex::XVar(Text::lit("out")))), crate::lower::model::Ex::XRef(Rc::new(call_pi.clone())), crate::lower::model::Ex::XNone])))])
        },
    }
}

/// The step machine of `TemplatePartDos`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TemplatePartDos: unbounded fn Lx, Env, TemplatePart -> [Do]
/// ```
pub struct TemplatePartDos {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub part_p2: crate::syntax::TemplatePart,
}

impl prism_rtl::Job<Array<crate::lower::model::Do>> for TemplatePartDos {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::lower::model::Do>> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let part_p2 = &self.part_p2;
        match part_p2 {
            crate::syntax::TemplatePart::TpText(t_p3) => prism_rtl::Turn::Finished(Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("out"))), Text::lit("push_str"), Array::from(vec![crate::lower::model::Ex::XStr(t_p3.clone())])))])),
            crate::syntax::TemplatePart::TpPlaceholder(x_p4, col_o5) => {
                let col_o5x = col_o5.clone();
                let env_p1x = env_p1.clone();
                let lx_p0x = lx_p0.clone();
                let x_p4x = x_p4.clone();
                crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p0x.clone(), env_p1x.clone(), x_p4x.clone()), move |value_of_f_1931: crate::lower::types::Vl| {
                    let v_p6 = value_of_f_1931;
                    let column_p7 = match &col_o5x {
                        Some(c_p8) => crate::lower::model::Ex::XCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Ex::XIndex(c_p8.clone())])),
                        None => crate::lower::model::Ex::XNone,
                    };
                    prism_rtl::Turn::Finished(Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XCall(crate::lower::helper_f(&Text::lit("place")), Array::from(vec![crate::lower::model::Ex::XRefMut(Rc::new(crate::lower::model::Ex::XVar(Text::lit("out")))), shown_text_f(&v_p6), column_p7.clone()])))]))
                })
            },
            crate::syntax::TemplatePart::TpBlock(b_p9) => {
                let b_p9x = b_p9.clone();
                let env_p1x = env_p1.clone();
                let lx_p0x = lx_p0.clone();
                crate::prelude::call_then(crate::lower::expr::start_block_value_f(lx_p0x.clone(), env_p1x.clone(), b_p9x.clone()), move |block_value_f_2174: crate::lower::types::Vl| {
                    let v_pa = block_value_f_2174;
                    if &crate::lower::types::value_ty_f(&v_pa) == &crate::lower::model::OutTy::OutUnit {
                        prism_rtl::Turn::Finished(Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::types::own_f(&v_pa))]))
                    } else {
                        prism_rtl::Turn::Finished(Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XCall(crate::lower::helper_f(&Text::lit("place")), Array::from(vec![crate::lower::model::Ex::XRefMut(Rc::new(crate::lower::model::Ex::XVar(Text::lit("out")))), shown_text_f(&v_pa), crate::lower::model::Ex::XNone])))]))
                    }
                })
            },
            crate::syntax::TemplatePart::TpCall(n_pb, args_pc, parts_od, _) => {
                let plain_pe = crate::syntax::SName { sigils_p: crate::syntax::lexer::chars::after_first_f(&n_pb.sigils_p), path_p: n_pb.path_p.clone(), span_p: n_pb.span_p.clone() };
                let (qk_oj, _) = crate::check::env::names::resolve_value_f(&lx_p0.g_p, &lx_p0.home_p, n_pb);
                let (qk2_ok, _) = crate::check::env::names::resolve_value_f(&lx_p0.g_p, &lx_p0.home_p, &plain_pe);
                let callee_pf = match &qk_oj {
                    Some(q_pl) => crate::lower::value_path_f(lx_p0, q_pl),
                    None => match &qk2_ok {
                        Some(q_pm) => crate::lower::value_path_f(lx_p0, q_pm),
                        None => crate::lower::snake_f(&crate::check::env::sname_key_f(n_pb)),
                    },
                };
                let body_pg = match parts_od {
                    Some(ps_pn) => {
                        let inner_po = crate::prelude::run_to_end(crate::prelude::fold_job(ps_pn.clone(), Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaMut(Text::lit("out")), crate::lower::model::Ex::XCall(Text::lit("String::new"), Array::new()))]), {
                            let lx_p0x = lx_p0.clone();
                            let env_p1x = env_p1.clone();
                            Rc::new(move |(p0, p1): (Array<crate::lower::model::Do>, crate::syntax::TemplatePart)| {
                                let lx_p0xy = lx_p0x.clone();
                                let env_p1xy = env_p1x.clone();
                                crate::prelude::entered(crate::prelude::once_job(move || {
                                    let acc_pp = p0;
                                    let p_pq = p1;
                                    crate::prelude::call_then(start_template_part_dos_f(lx_p0xy.clone(), env_p1xy.clone(), p_pq.clone()), move |template_part_dos_f_2929: Array<crate::lower::model::Do>| prism_rtl::Turn::Finished(crate::prelude::append(&acc_pp, &template_part_dos_f_2929)))
                                }))
                            }) as Rc<dyn Fn((Array<crate::lower::model::Do>, crate::syntax::TemplatePart)) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>
                        }));
                        Array::from(vec![crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XBlock(inner_po.clone(), Rc::new(crate::lower::model::Ex::XCall(Text::lit("Text::from"), Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("out"))]))))))])
                    },
                    None => Array::new(),
                };
                let passed_ph = match &qk_oj {
                    Some(q_pr) => template_args_f(lx_p0, env_p1, q_pr, args_pc, &body_pg),
                    None => match &qk2_ok {
                        Some(q_ps) => template_args_f(lx_p0, env_p1, q_ps, args_pc, &body_pg),
                        None => crate::prelude::append(&crate::prelude::run_to_end(crate::prelude::each_job(args_pc.clone(), {
                            let lx_p0x = lx_p0.clone();
                            let env_p1x = env_p1.clone();
                            Rc::new(move |p0: crate::syntax::Arg| {
                                let lx_p0xy = lx_p0x.clone();
                                let env_p1xy = env_p1x.clone();
                                crate::prelude::entered(crate::prelude::once_job(move || {
                                    let a_pt = p0;
                                    prism_rtl::Turn::More(Rc::new(crate::lower::expr::Argument { lx_p0: lx_p0xy.clone(), env_p1: env_p1xy.clone(), e_p2: a_pt.value_p.clone() }))
                                }))
                            }) as Rc<dyn Fn(crate::syntax::Arg) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
                        })), &body_pg),
                    },
                };
                let call_pi = crate::lower::model::Ex::XCall(callee_pf.clone(), passed_ph.clone());
                prism_rtl::Turn::Finished(Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XCall(crate::lower::helper_f(&Text::lit("place")), Array::from(vec![crate::lower::model::Ex::XRefMut(Rc::new(crate::lower::model::Ex::XVar(Text::lit("out")))), crate::lower::model::Ex::XRef(Rc::new(call_pi.clone())), crate::lower::model::Ex::XNone])))]))
            },
        }
    }
}

/// `Start TemplatePartDos, x`: what the function value is when passed to `@Run`.
pub fn start_template_part_dos_f(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, part_p2: crate::syntax::TemplatePart) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>> {
    Rc::new(TemplatePartDos { lx_p0, env_p1, part_p2 })
}

/// ```prism
/// TemplateArgs: unbounded fn Lx, Env, Text, [Arg], [Ex] -> [Ex]
/// ```
pub fn template_args_f(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, qk_p2: &Text, args_p3: &Array<crate::syntax::Arg>, body_p4: &Array<crate::lower::model::Ex>) -> Array<crate::lower::model::Ex> {
    let clauses_p5 = crate::lower::jobs::clauses_of_f(&lx_p0.g_p, qk_p2);
    let arity_p6 = crate::prelude::len(&crate::prelude::or(&crate::prelude::index(&clauses_p5, &Nat::from(0u32)), &crate::lower::functions::dummy_clause_p()).params_p);
    crate::prelude::run_to_end(crate::prelude::each_job(crate::check::errors::range0_f(&arity_p6), {
        let body_p4x = body_p4.clone();
        let arity_p6x = arity_p6.clone();
        let clauses_p5x = clauses_p5.clone();
        let args_p3x = args_p3.clone();
        let lx_p0x = lx_p0.clone();
        let env_p1x = env_p1.clone();
        Rc::new(move |p0: Nat| {
            let body_p4xy = body_p4x.clone();
            let arity_p6xy = arity_p6x.clone();
            let clauses_p5xy = clauses_p5x.clone();
            let args_p3xy = args_p3x.clone();
            let lx_p0xy = lx_p0x.clone();
            let env_p1xy = env_p1x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let j_p7 = p0;
                if (&crate::prelude::len(&body_p4xy) > &Nat::from(0u32)) && (&(&j_p7 + &Nat::from(1u32)) == &arity_p6xy) {
                    prism_rtl::Turn::Finished(crate::prelude::or(&crate::prelude::index(&body_p4xy, &Nat::from(0u32)), &crate::lower::model::Ex::XUnit))
                } else {
                    match attr_at_o(&clauses_p5xy, &j_p7, &args_p3xy) {
                        Some(a_p8) => prism_rtl::Turn::More(Rc::new(crate::lower::expr::Argument { lx_p0: lx_p0xy.clone(), env_p1: env_p1xy.clone(), e_p2: a_p8.value_p.clone() })),
                        None => prism_rtl::Turn::Finished(crate::lower::expr::refusal_f(&Text::from(format!("a template call that fills no argument at place {}", &j_p7)))),
                    }
                }
            }))
        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
    }))
}

/// The step machine of `TemplateArgs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TemplateArgs: unbounded fn Lx, Env, Text, [Arg], [Ex] -> [Ex]
/// ```
pub struct TemplateArgs {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub qk_p2: Text,
    pub args_p3: Array<crate::syntax::Arg>,
    pub body_p4: Array<crate::lower::model::Ex>,
}

impl prism_rtl::Job<Array<crate::lower::model::Ex>> for TemplateArgs {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::lower::model::Ex>> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let qk_p2 = &self.qk_p2;
        let args_p3 = &self.args_p3;
        let body_p4 = &self.body_p4;
        let clauses_p5 = crate::lower::jobs::clauses_of_f(&lx_p0.g_p, qk_p2);
        let arity_p6 = crate::prelude::len(&crate::prelude::or(&crate::prelude::index(&clauses_p5, &Nat::from(0u32)), &crate::lower::functions::dummy_clause_p()).params_p);
        crate::prelude::each_job(crate::check::errors::range0_f(&arity_p6), {
            let body_p4x = body_p4.clone();
            let arity_p6x = arity_p6.clone();
            let clauses_p5x = clauses_p5.clone();
            let args_p3x = args_p3.clone();
            let lx_p0x = lx_p0.clone();
            let env_p1x = env_p1.clone();
            Rc::new(move |p0: Nat| {
                let body_p4xy = body_p4x.clone();
                let arity_p6xy = arity_p6x.clone();
                let clauses_p5xy = clauses_p5x.clone();
                let args_p3xy = args_p3x.clone();
                let lx_p0xy = lx_p0x.clone();
                let env_p1xy = env_p1x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let j_p7 = p0;
                    if (&crate::prelude::len(&body_p4xy) > &Nat::from(0u32)) && (&(&j_p7 + &Nat::from(1u32)) == &arity_p6xy) {
                        prism_rtl::Turn::Finished(crate::prelude::or(&crate::prelude::index(&body_p4xy, &Nat::from(0u32)), &crate::lower::model::Ex::XUnit))
                    } else {
                        match attr_at_o(&clauses_p5xy, &j_p7, &args_p3xy) {
                            Some(a_p8) => prism_rtl::Turn::More(Rc::new(crate::lower::expr::Argument { lx_p0: lx_p0xy.clone(), env_p1: env_p1xy.clone(), e_p2: a_p8.value_p.clone() })),
                            None => prism_rtl::Turn::Finished(crate::lower::expr::refusal_f(&Text::from(format!("a template call that fills no argument at place {}", &j_p7)))),
                        }
                    }
                }))
            }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
        }).cycle()
    }
}

/// `Start TemplateArgs, x`: what the function value is when passed to `@Run`.
pub fn start_template_args_f(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, qk_p2: Text, args_p3: Array<crate::syntax::Arg>, body_p4: Array<crate::lower::model::Ex>) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Ex>>> {
    Rc::new(TemplateArgs { lx_p0, env_p1, qk_p2, args_p3, body_p4 })
}

/// ```prism
/// ?AttrAt: fn [FnClause], Nat, [Arg] -> ?Arg
/// ```
pub fn attr_at_o(clauses_p0: &Array<crate::syntax::decls::FnClause>, j_p1: &Nat, args_p2: &Array<crate::syntax::Arg>) -> Option<crate::syntax::Arg> {
    let names_p7 = crate::prelude::fold(clauses_p0, &Array::new(), &(|acc_p3: &Array<Text>, c_p4: &crate::syntax::decls::FnClause| match crate::prelude::index(&c_p4.params_p, j_p1) {
        Some(p_p5) => match place_name_o(&p_p5) {
            Some(n_p6) => crate::check::types::add_text_f(acc_p3, &n_p6),
            None => acc_p3.clone(),
        },
        None => acc_p3.clone(),
    }));
    crate::prelude::fold(args_p2, &None, &(|found_o8: &Option<crate::syntax::Arg>, a_p9: &crate::syntax::Arg| match &a_p9.name_o {
        Some(n_pa) => if crate::check::types::has_text_f(&names_p7, &n_pa.name_p) {
            Some(a_p9.clone())
        } else {
            found_o8.clone()
        },
        None => found_o8.clone(),
    }))
}

/// ```prism
/// ?PlaceName: fn Pattern -> ?Text
/// ```
pub fn place_name_o(p_p0: &crate::syntax::Pattern_) -> Option<Text> {
    match &*p_p0.kind_p {
        crate::syntax::PatternKind::PName(n_p1) => Some(crate::check::env::dotted_f(&n_p1.path_p)),
        crate::syntax::PatternKind::PGroup(q_p2) => place_name_o(&**q_p2),
        _ => None,
    }
}

/// ```prism
/// ShownText: fn Vl -> Ex
/// ```
pub fn shown_text_f(v_p0: &crate::lower::types::Vl) -> crate::lower::model::Ex {
    match crate::lower::types::value_ty_f(v_p0) {
        crate::lower::model::OutTy::OutText => crate::lower::types::ref_f(v_p0),
        crate::lower::model::OutTy::OutChar => crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XFormat(Array::from(vec![crate::lower::types::ref_f(v_p0)])))),
        _ => crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XCall(crate::lower::helper_f(&Text::lit("show_text")), Array::from(vec![crate::lower::types::ref_f(v_p0)])))),
    }
}

/// ```prism
/// GivenValue: unbounded fn Lx, Env, Block, OutTy, Range -> Vl
/// ```
pub fn given_value_f(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, b_p2: &crate::syntax::Block, t_p3: &crate::lower::model::OutTy, span_p4: &crate::syntax::Range) -> crate::lower::types::Vl {
    let label_p5 = Text::from(format!("\'g{}", &span_p4.start_p));
    let is_try_p6 = match t_p3 {
        crate::lower::model::OutTy::OutRes(_) => true,
        _ => false,
    };
    let n_p7 = crate::prelude::len(&b_p2.stmts_p);
    let (dos_po, env2_pp, last_oq) = crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(&n_p7), (Array::new(), env_p1.clone(), None), {
        let b_p2x = b_p2.clone();
        let is_try_p6x = is_try_p6;
        let lx_p0x = lx_p0.clone();
        let label_p5x = label_p5.clone();
        let n_p7x = n_p7.clone();
        Rc::new(move |(p0, p1): ((Array<crate::lower::model::Do>, crate::lower::types::Env, Option<crate::lower::types::Vl>), Nat)| {
            let b_p2xy = b_p2x.clone();
            let is_try_p6xy = is_try_p6x;
            let lx_p0xy = lx_p0x.clone();
            let label_p5xy = label_p5x.clone();
            let n_p7xy = n_p7x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (acc_p9, en_pa, lv_ob) = p0;
                let i_pc = p1;
                {
                    let s_pd = crate::prelude::or(&crate::prelude::index(&b_p2xy.stmts_p, &i_pc), &crate::lower::expr::dummy_stmt_l_p());
                    let fail_pe = if is_try_p6xy {
                        crate::lower::model::Ex::XCtor(Text::lit("Err"), Array::from(vec![crate::lower::model::Ex::XCall(Text::lit("Error::new"), Array::from(vec![crate::lower::model::Ex::XStr(Text::lit("Prelude.Unmet")), crate::lower::model::Ex::XStr(source_text_f(&lx_p0xy, &s_pd.span_p))]))]))
                    } else {
                        crate::lower::model::Ex::XNone
                    };
                    match &s_pd.kind_p {
                        crate::syntax::StmtKind::SBind(p_pf, x_pg, None) => {
                            let p_pfx = p_pf.clone();
                            let x_pgx = x_pg.clone();
                            crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p0xy.clone(), en_pa.clone(), x_pgx.clone()), move |value_of_f_5976: crate::lower::types::Vl| {
                                let v_ph = value_of_f_5976;
                                crate::prelude::call_then(crate::lower::patterns::start_rust_pat_f(lx_p0xy.clone(), p_pfx.clone(), crate::lower::patterns::inner_ty_f(&crate::lower::type_at_f(&lx_p0xy, &x_pgx.span_p)), crate::lower::types::Holding::Owned, Text::from(format!("g{}", &s_pd.span_p.start_p))), move |rust_pat_f_6019: crate::lower::patterns::PatOut| {
                                    let po_pi = rust_pat_f_6019;
                                    crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0xy.clone(), crate::lower::patterns::inner_ty_f(&crate::lower::type_at_f(&lx_p0xy, &x_pgx.span_p))), move |out_ty_of_f_6161: crate::lower::model::OutTy| prism_rtl::Turn::Finished((crate::prelude::push(&acc_p9, &given_bind_f(&is_try_p6xy, &po_pi.pa_p, &crate::lower::types::own_f(&v_ph), &label_p5xy, &out_ty_of_f_6161)), crate::lower::expr::bind_all_f(&en_pa, &po_pi.binds_p), lv_ob.clone())))
                                })
                            })
                        },
                        crate::syntax::StmtKind::SRequire(c_pj) => {
                            let c_pjx = c_pj.clone();
                            crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p0xy.clone(), en_pa.clone(), c_pjx.clone()), move |value_of_f_6304: crate::lower::types::Vl| prism_rtl::Turn::Finished((crate::prelude::push(&acc_p9, &crate::lower::model::Do::DoIf(crate::lower::model::Ex::XUnary(crate::lower::model::UnOp::OpNot, Rc::new(crate::lower::types::as_bool_f(&value_of_f_6304))), Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XBreak(label_p5xy.clone(), Rc::new(fail_pe.clone())))]), Array::new())), en_pa.clone(), lv_ob.clone())))
                        },
                        crate::syntax::StmtKind::SForbid(c_pk) => {
                            let c_pkx = c_pk.clone();
                            crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p0xy.clone(), en_pa.clone(), c_pkx.clone()), move |value_of_f_6428: crate::lower::types::Vl| prism_rtl::Turn::Finished((crate::prelude::push(&acc_p9, &crate::lower::model::Do::DoIf(crate::lower::types::as_bool_f(&value_of_f_6428), Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XBreak(label_p5xy.clone(), Rc::new(fail_pe.clone())))]), Array::new())), en_pa.clone(), lv_ob.clone())))
                        },
                        crate::syntax::StmtKind::SExpr(x_pl) => if &(&i_pc + &Nat::from(1u32)) == &n_p7xy {
                            prism_rtl::Turn::Finished((acc_p9.clone(), en_pa.clone(), Some(crate::lower::expr::value_of_f(&lx_p0xy, &en_pa, x_pl))))
                        } else {
                            {
                                let x_plx = x_pl.clone();
                                crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p0xy.clone(), en_pa.clone(), x_plx.clone()), move |value_of_f_6636: crate::lower::types::Vl| prism_rtl::Turn::Finished((crate::prelude::push(&acc_p9, &crate::lower::model::Do::DoExpr(crate::lower::types::own_f(&value_of_f_6636))), en_pa.clone(), lv_ob.clone())))
                            }
                        },
                        _ => crate::prelude::call_then(crate::lower::expr::start_block_stmt_f(lx_p0xy.clone(), en_pa.clone(), s_pd.clone()), move |block_stmt_f_6728: (Array<crate::lower::model::Do>, crate::lower::types::Env)| {
                            let (more_pm, en2_pn) = block_stmt_f_6728;
                            prism_rtl::Turn::Finished((crate::prelude::append(&acc_p9, &more_pm), en2_pn.clone(), lv_ob.clone()))
                        }),
                    }
                }
            }))
        }) as Rc<dyn Fn(((Array<crate::lower::model::Do>, crate::lower::types::Env, Option<crate::lower::types::Vl>), Nat)) -> Rc<dyn prism_rtl::Job<(Array<crate::lower::model::Do>, crate::lower::types::Env, Option<crate::lower::types::Vl>)>>>
    }));
    let last_p8 = crate::prelude::or(&last_oq, &crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XNone, t_p3.clone()));
    crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XLabeled(label_p5.clone(), dos_po.clone(), Rc::new(crate::lower::types::own_f(&last_p8)), t_p3.clone()), t_p3.clone())
}

/// The step machine of `GivenValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// GivenValue: unbounded fn Lx, Env, Block, OutTy, Range -> Vl
/// ```
pub struct GivenValue {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub b_p2: crate::syntax::Block,
    pub t_p3: crate::lower::model::OutTy,
    pub span_p4: crate::syntax::Range,
}

impl prism_rtl::Job<crate::lower::types::Vl> for GivenValue {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::types::Vl> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let b_p2 = &self.b_p2;
        let t_p3 = &self.t_p3;
        let span_p4 = &self.span_p4;
        let label_p5 = Text::from(format!("\'g{}", &span_p4.start_p));
        let is_try_p6 = match t_p3 {
            crate::lower::model::OutTy::OutRes(_) => true,
            _ => false,
        };
        let n_p7 = crate::prelude::len(&b_p2.stmts_p);
        let b_p2x = b_p2.clone();
        let env_p1x = env_p1.clone();
        let lx_p0x = lx_p0.clone();
        let span_p4x = span_p4.clone();
        let t_p3x = t_p3.clone();
        crate::prelude::call_value(crate::prelude::fold_job(crate::check::errors::range0_f(&n_p7), (Array::new(), env_p1x.clone(), None), {
            let b_p2xx = b_p2x.clone();
            let is_try_p6x = is_try_p6;
            let lx_p0xx = lx_p0x.clone();
            let label_p5x = label_p5.clone();
            let n_p7x = n_p7.clone();
            Rc::new(move |(p0, p1): ((Array<crate::lower::model::Do>, crate::lower::types::Env, Option<crate::lower::types::Vl>), Nat)| {
                let b_p2xxy = b_p2xx.clone();
                let is_try_p6xy = is_try_p6x;
                let lx_p0xxy = lx_p0xx.clone();
                let label_p5xy = label_p5x.clone();
                let n_p7xy = n_p7x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let (acc_p9, en_pa, lv_ob) = p0;
                    let i_pc = p1;
                    {
                        let s_pd = crate::prelude::or(&crate::prelude::index(&b_p2xxy.stmts_p, &i_pc), &crate::lower::expr::dummy_stmt_l_p());
                        let fail_pe = if is_try_p6xy {
                            crate::lower::model::Ex::XCtor(Text::lit("Err"), Array::from(vec![crate::lower::model::Ex::XCall(Text::lit("Error::new"), Array::from(vec![crate::lower::model::Ex::XStr(Text::lit("Prelude.Unmet")), crate::lower::model::Ex::XStr(source_text_f(&lx_p0xxy, &s_pd.span_p))]))]))
                        } else {
                            crate::lower::model::Ex::XNone
                        };
                        match &s_pd.kind_p {
                            crate::syntax::StmtKind::SBind(p_pf, x_pg, None) => {
                                let p_pfx = p_pf.clone();
                                let x_pgx = x_pg.clone();
                                crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p0xxy.clone(), en_pa.clone(), x_pgx.clone()), move |value_of_f_5976: crate::lower::types::Vl| {
                                    let v_ph = value_of_f_5976;
                                    crate::prelude::call_then(crate::lower::patterns::start_rust_pat_f(lx_p0xxy.clone(), p_pfx.clone(), crate::lower::patterns::inner_ty_f(&crate::lower::type_at_f(&lx_p0xxy, &x_pgx.span_p)), crate::lower::types::Holding::Owned, Text::from(format!("g{}", &s_pd.span_p.start_p))), move |rust_pat_f_6019: crate::lower::patterns::PatOut| {
                                        let po_pi = rust_pat_f_6019;
                                        crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0xxy.clone(), crate::lower::patterns::inner_ty_f(&crate::lower::type_at_f(&lx_p0xxy, &x_pgx.span_p))), move |out_ty_of_f_6161: crate::lower::model::OutTy| prism_rtl::Turn::Finished((crate::prelude::push(&acc_p9, &given_bind_f(&is_try_p6xy, &po_pi.pa_p, &crate::lower::types::own_f(&v_ph), &label_p5xy, &out_ty_of_f_6161)), crate::lower::expr::bind_all_f(&en_pa, &po_pi.binds_p), lv_ob.clone())))
                                    })
                                })
                            },
                            crate::syntax::StmtKind::SRequire(c_pj) => {
                                let c_pjx = c_pj.clone();
                                crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p0xxy.clone(), en_pa.clone(), c_pjx.clone()), move |value_of_f_6304: crate::lower::types::Vl| prism_rtl::Turn::Finished((crate::prelude::push(&acc_p9, &crate::lower::model::Do::DoIf(crate::lower::model::Ex::XUnary(crate::lower::model::UnOp::OpNot, Rc::new(crate::lower::types::as_bool_f(&value_of_f_6304))), Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XBreak(label_p5xy.clone(), Rc::new(fail_pe.clone())))]), Array::new())), en_pa.clone(), lv_ob.clone())))
                            },
                            crate::syntax::StmtKind::SForbid(c_pk) => {
                                let c_pkx = c_pk.clone();
                                crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p0xxy.clone(), en_pa.clone(), c_pkx.clone()), move |value_of_f_6428: crate::lower::types::Vl| prism_rtl::Turn::Finished((crate::prelude::push(&acc_p9, &crate::lower::model::Do::DoIf(crate::lower::types::as_bool_f(&value_of_f_6428), Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XBreak(label_p5xy.clone(), Rc::new(fail_pe.clone())))]), Array::new())), en_pa.clone(), lv_ob.clone())))
                            },
                            crate::syntax::StmtKind::SExpr(x_pl) => if &(&i_pc + &Nat::from(1u32)) == &n_p7xy {
                                prism_rtl::Turn::Finished((acc_p9.clone(), en_pa.clone(), Some(crate::lower::expr::value_of_f(&lx_p0xxy, &en_pa, x_pl))))
                            } else {
                                {
                                    let x_plx = x_pl.clone();
                                    crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p0xxy.clone(), en_pa.clone(), x_plx.clone()), move |value_of_f_6636: crate::lower::types::Vl| prism_rtl::Turn::Finished((crate::prelude::push(&acc_p9, &crate::lower::model::Do::DoExpr(crate::lower::types::own_f(&value_of_f_6636))), en_pa.clone(), lv_ob.clone())))
                                }
                            },
                            _ => crate::prelude::call_then(crate::lower::expr::start_block_stmt_f(lx_p0xxy.clone(), en_pa.clone(), s_pd.clone()), move |block_stmt_f_6728: (Array<crate::lower::model::Do>, crate::lower::types::Env)| {
                                let (more_pm, en2_pn) = block_stmt_f_6728;
                                prism_rtl::Turn::Finished((crate::prelude::append(&acc_p9, &more_pm), en2_pn.clone(), lv_ob.clone()))
                            }),
                        }
                    }
                }))
            }) as Rc<dyn Fn(((Array<crate::lower::model::Do>, crate::lower::types::Env, Option<crate::lower::types::Vl>), Nat)) -> Rc<dyn prism_rtl::Job<(Array<crate::lower::model::Do>, crate::lower::types::Env, Option<crate::lower::types::Vl>)>>>
        }), move |fold_5660: (Array<crate::lower::model::Do>, crate::lower::types::Env, Option<crate::lower::types::Vl>)| {
            let (dos_po, env2_pp, last_oq) = fold_5660;
            let last_p8 = crate::prelude::or(&last_oq, &crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XNone, t_p3x.clone()));
            prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XLabeled(label_p5.clone(), dos_po.clone(), Rc::new(crate::lower::types::own_f(&last_p8)), t_p3x.clone()), t_p3x.clone()))
        })
    }
}

/// `Start GivenValue, x`: what the function value is when passed to `@Run`.
pub fn start_given_value_f(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, b_p2: crate::syntax::Block, t_p3: crate::lower::model::OutTy, span_p4: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<crate::lower::types::Vl>> {
    Rc::new(GivenValue { lx_p0, env_p1, b_p2, t_p3, span_p4 })
}

/// ```prism
/// GivenBind: fn Bool, Pa, Ex, Text, OutTy -> Do
/// ```
pub fn given_bind_f(is_try_p0: &bool, pa_p1: &crate::lower::model::Pa, x_p2: &crate::lower::model::Ex, label_p3: &Text, t_p4: &crate::lower::model::OutTy) -> crate::lower::model::Do {
    if *is_try_p0 {
        crate::lower::model::Do::DoLet(pa_p1.clone(), crate::lower::model::Ex::XMatch(Rc::new(x_p2.clone()), Array::from(vec![crate::lower::model::XArm { pat_p: crate::lower::model::Pa::PaCtor(Text::lit("Ok"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("v"))])), conds_p: Array::new(), body_p: crate::lower::model::Ex::XVar(Text::lit("v")) }, crate::lower::model::XArm { pat_p: crate::lower::model::Pa::PaCtor(Text::lit("Err"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("e"))])), conds_p: Array::new(), body_p: crate::lower::model::Ex::XBreak(label_p3.clone(), Rc::new(crate::lower::model::Ex::XCtor(Text::lit("Err"), Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("e"))])))) }]), false, t_p4.clone()))
    } else {
        crate::lower::model::Do::DoLetElse(crate::lower::model::Pa::PaCtor(Text::lit("Some"), Array::from(vec![pa_p1.clone()])), x_p2.clone(), crate::lower::model::Ex::XBreak(label_p3.clone(), Rc::new(crate::lower::model::Ex::XNone)))
    }
}

/// ```prism
/// SourceText: fn Lx, Range -> Text
/// ```
pub fn source_text_f(lx_p0: &crate::lower::Lx, r_p1: &crate::syntax::Range) -> Text {
    match crate::prelude::index(&lx_p0.g_p.srcs_p, &lx_p0.file_p) {
        Some(src_p2) => crate::check::errors::span_text_f(&src_p2, r_p1),
        None => Text::lit(""),
    }
}

/// ```prism
/// UpdateValue: unbounded fn Lx, Env, Expr, Block, OutTy, Range -> Vl
/// ```
pub fn update_value_f(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, target_p2: &crate::syntax::Expr, b_p3: &crate::syntax::Block, t_p4: &crate::lower::model::OutTy, span_p5: &crate::syntax::Range) -> crate::lower::types::Vl {
    let tv_p6 = crate::lower::expr::value_of_f(lx_p0, env_p1, target_p2);
    let env1_p7 = crate::lower::types::bind_f(env_p1, &Text::lit("&_"), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(Text::lit("this")), crate::lower::types::Holding::Owned, t_p4.clone()));
    let (dos_p8, _) = upd_stmts_f(lx_p0, &env1_p7, &b_p3.stmts_p);
    crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XBlock(crate::prelude::append(&Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaMut(Text::lit("this"))), t_p4.clone()), crate::lower::types::own_f(&tv_p6))]), &dos_p8), Rc::new(crate::lower::model::Ex::XVar(Text::lit("this")))), t_p4.clone())
}

/// The step machine of `UpdateValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UpdateValue: unbounded fn Lx, Env, Expr, Block, OutTy, Range -> Vl
/// ```
pub struct UpdateValue {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub target_p2: crate::syntax::Expr,
    pub b_p3: crate::syntax::Block,
    pub t_p4: crate::lower::model::OutTy,
    pub span_p5: crate::syntax::Range,
}

impl prism_rtl::Job<crate::lower::types::Vl> for UpdateValue {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::types::Vl> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let target_p2 = &self.target_p2;
        let b_p3 = &self.b_p3;
        let t_p4 = &self.t_p4;
        let span_p5 = &self.span_p5;
        let b_p3x = b_p3.clone();
        let env_p1x = env_p1.clone();
        let lx_p0x = lx_p0.clone();
        let t_p4x = t_p4.clone();
        let target_p2x = target_p2.clone();
        crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p0x.clone(), env_p1x.clone(), target_p2x.clone()), move |value_of_f_7927: crate::lower::types::Vl| {
            let tv_p6 = value_of_f_7927;
            let env1_p7 = crate::lower::types::bind_f(&env_p1x, &Text::lit("&_"), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(Text::lit("this")), crate::lower::types::Holding::Owned, t_p4x.clone()));
            crate::prelude::call_then(start_upd_stmts_f(lx_p0x.clone(), env1_p7.clone(), b_p3x.stmts_p.clone()), move |upd_stmts_f_8042: (Array<crate::lower::model::Do>, crate::lower::types::Env)| {
                let (dos_p8, _) = upd_stmts_f_8042;
                prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XBlock(crate::prelude::append(&Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaMut(Text::lit("this"))), t_p4x.clone()), crate::lower::types::own_f(&tv_p6))]), &dos_p8), Rc::new(crate::lower::model::Ex::XVar(Text::lit("this")))), t_p4x.clone()))
            })
        })
    }
}

/// `Start UpdateValue, x`: what the function value is when passed to `@Run`.
pub fn start_update_value_f(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, target_p2: crate::syntax::Expr, b_p3: crate::syntax::Block, t_p4: crate::lower::model::OutTy, span_p5: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<crate::lower::types::Vl>> {
    Rc::new(UpdateValue { lx_p0, env_p1, target_p2, b_p3, t_p4, span_p5 })
}

/// ```prism
/// UpdStmts: unbounded fn Lx, Env, [Stmt] -> (([Do], Env))
/// ```
pub fn upd_stmts_f(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, stmts_p2: &Array<crate::syntax::Stmt>) -> (Array<crate::lower::model::Do>, crate::lower::types::Env) {
    crate::prelude::run_to_end(crate::prelude::fold_job(stmts_p2.clone(), (Array::new(), env_p1.clone()), {
        let lx_p0x = lx_p0.clone();
        Rc::new(move |(p0, p1): ((Array<crate::lower::model::Do>, crate::lower::types::Env), crate::syntax::Stmt)| {
            let lx_p0xy = lx_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (acc_p3, en_p4) = p0;
                let s_p5 = p1;
                crate::prelude::call_then(start_upd_stmt_f(lx_p0xy.clone(), en_p4.clone(), s_p5.clone()), move |upd_stmt_f_8327: (Array<crate::lower::model::Do>, crate::lower::types::Env)| {
                    let (more_p6, en2_p7) = upd_stmt_f_8327;
                    prism_rtl::Turn::Finished((crate::prelude::append(&acc_p3, &more_p6), en2_p7.clone()))
                })
            }))
        }) as Rc<dyn Fn(((Array<crate::lower::model::Do>, crate::lower::types::Env), crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<(Array<crate::lower::model::Do>, crate::lower::types::Env)>>>
    }))
}

/// The step machine of `UpdStmts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UpdStmts: unbounded fn Lx, Env, [Stmt] -> (([Do], Env))
/// ```
pub struct UpdStmts {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub stmts_p2: Array<crate::syntax::Stmt>,
}

impl prism_rtl::Job<(Array<crate::lower::model::Do>, crate::lower::types::Env)> for UpdStmts {
    fn cycle(&self) -> prism_rtl::Turn<(Array<crate::lower::model::Do>, crate::lower::types::Env)> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let stmts_p2 = &self.stmts_p2;
        crate::prelude::fold_job(stmts_p2.clone(), (Array::new(), env_p1.clone()), {
            let lx_p0x = lx_p0.clone();
            Rc::new(move |(p0, p1): ((Array<crate::lower::model::Do>, crate::lower::types::Env), crate::syntax::Stmt)| {
                let lx_p0xy = lx_p0x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let (acc_p3, en_p4) = p0;
                    let s_p5 = p1;
                    crate::prelude::call_then(start_upd_stmt_f(lx_p0xy.clone(), en_p4.clone(), s_p5.clone()), move |upd_stmt_f_8327: (Array<crate::lower::model::Do>, crate::lower::types::Env)| {
                        let (more_p6, en2_p7) = upd_stmt_f_8327;
                        prism_rtl::Turn::Finished((crate::prelude::append(&acc_p3, &more_p6), en2_p7.clone()))
                    })
                }))
            }) as Rc<dyn Fn(((Array<crate::lower::model::Do>, crate::lower::types::Env), crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<(Array<crate::lower::model::Do>, crate::lower::types::Env)>>>
        }).cycle()
    }
}

/// `Start UpdStmts, x`: what the function value is when passed to `@Run`.
pub fn start_upd_stmts_f(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, stmts_p2: Array<crate::syntax::Stmt>) -> Rc<dyn prism_rtl::Job<(Array<crate::lower::model::Do>, crate::lower::types::Env)>> {
    Rc::new(UpdStmts { lx_p0, env_p1, stmts_p2 })
}

/// ```prism
/// UpdStmt: unbounded fn Lx, Env, Stmt -> (([Do], Env))
/// ```
pub fn upd_stmt_f(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, s_p2: &crate::syntax::Stmt) -> (Array<crate::lower::model::Do>, crate::lower::types::Env) {
    match &s_p2.kind_p {
        crate::syntax::StmtKind::SSet(target_p3, value_p4) => {
            let v_p5 = crate::lower::types::own_f(&crate::lower::expr::value_of_f(lx_p0, env_p1, value_p4));
            (Array::from(vec![assign_f(lx_p0, env_p1, target_p3, &v_p5)]), env_p1.clone())
        },
        crate::syntax::StmtKind::SAccum(target_p6, op_p7, value_p8) => {
            let cur_p9 = place_of_f(lx_p0, env_p1, target_p6);
            let tt_pa = crate::lower::types::out_ty_of_f(lx_p0, &crate::lower::types::peel_f(&crate::lower::type_at_f(lx_p0, &target_p6.span_p)));
            let rv_pb = crate::lower::expr::value_of_f(lx_p0, env_p1, value_p8);
            let bin_pc = crate::syntax::lexer::chars::head_f(op_p7);
            let next_pd = crate::lower::expr::op_value_f(lx_p0, &bin_pc, &crate::lower::types::Vl::VlPlace(cur_p9.clone(), crate::lower::types::Holding::Owned, tt_pa.clone()), &rv_pb, &s_p2.span_p, &tt_pa);
            (Array::from(vec![assign_f(lx_p0, env_p1, target_p6, &crate::lower::types::own_f(&next_pd))]), env_p1.clone())
        },
        crate::syntax::StmtKind::SLet(p_pe, _, x_pf) => {
            let v_pg = crate::lower::types::own_f(&crate::lower::expr::value_of_f(lx_p0, env_p1, x_pf));
            match &*p_pe.kind_p {
                crate::syntax::PatternKind::PName(n_ph) => if crate::syntax::lexer::chars::has_prefix_f(&n_ph.sigils_p, &Text::lit("&")) {
                    {
                        let rs_pi = crate::lower::local_name_at_f(lx_p0, &crate::check::env::sname_key_f(n_ph), &n_ph.span_p);
                        let bt_pj = crate::lower::types::out_ty_of_f(lx_p0, &crate::lower::types::peel_f(&crate::lower::binder_ty_f(lx_p0, &n_ph.span_p)));
                        let pa_pk = if crate::lower::expr::is_known_ty_f(&bt_pj) {
                            crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaMut(Text::from(format!("{}", &rs_pi)))), bt_pj.clone())
                        } else {
                            crate::lower::model::Pa::PaMut(Text::from(format!("{}", &rs_pi)))
                        };
                        (Array::from(vec![crate::lower::model::Do::DoLet(pa_pk.clone(), v_pg.clone())]), crate::lower::types::bind_f(env_p1, &crate::check::env::sname_key_f(n_ph), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(rs_pi.clone()), crate::lower::types::Holding::Owned, bt_pj.clone())))
                    }
                } else {
                    crate::lower::expr::block_stmt_f(lx_p0, env_p1, s_p2)
                },
                _ => crate::lower::expr::block_stmt_f(lx_p0, env_p1, s_p2),
            }
        },
        crate::syntax::StmtKind::SWhile(c_pl, body_pm) => {
            let (inner_pn, _) = upd_stmts_f(lx_p0, env_p1, &body_pm.stmts_p);
            match c_pl {
                crate::syntax::Cond::CondExpr(x_po) => (Array::from(vec![crate::lower::model::Do::DoWhile(crate::lower::types::as_bool_f(&crate::lower::expr::value_of_f(lx_p0, env_p1, &**x_po)), inner_pn.clone())]), env_p1.clone()),
                crate::syntax::Cond::CondBind(p_pp, x_pq, g_or) => {
                    let po_ps = crate::lower::patterns::rust_pat_f(lx_p0, p_pp, &crate::lower::type_at_f(lx_p0, &x_pq.span_p), &crate::lower::types::Holding::Owned, &Text::from(format!("w{}", &s_p2.span_p.start_p)));
                    let env_b_pt = crate::lower::expr::bind_all_f(env_p1, &po_ps.binds_p);
                    let (inner2_p13, _) = upd_stmts_f(lx_p0, &env_b_pt, &body_pm.stmts_p);
                    let conds_pu = crate::prelude::append(&po_ps.conds_p, &guard_conds_f(lx_p0, &env_b_pt, &**g_or));
                    let tests_pv = crate::prelude::fold(&conds_pu, &Array::new(), &(|acc_p14: &Array<crate::lower::model::Ex>, c_p15: &crate::lower::model::Cc| match c_p15 {
                        crate::lower::model::Cc::CcIf(t_p16) => crate::prelude::push(acc_p14, t_p16),
                        _ => acc_p14.clone(),
                    }));
                    let lets_p10 = crate::prelude::fold(&conds_pu, &false, &(|f_p17: &bool, c_p18: &crate::lower::model::Cc| *f_p17 || crate::lower::expr::is_let_cond_f(c_p18)));
                    let stop_p11 = if &crate::prelude::len(&tests_pv) == &Nat::from(0u32) {
                        Array::new()
                    } else {
                        Array::from(vec![crate::lower::model::Do::DoIf(crate::lower::model::Ex::XUnary(crate::lower::model::UnOp::OpNot, Rc::new(all_of_f(&tests_pv))), Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XVar(Text::lit("break")))]), Array::new())])
                    };
                    let body2_p12 = if lets_p10 {
                        Array::from(vec![crate::lower::expr::refusal_do_f(&Text::lit("a `while` whose pattern matches through an `Rc`"))])
                    } else {
                        crate::prelude::append(&stop_p11, &inner2_p13)
                    };
                    (Array::from(vec![crate::lower::model::Do::DoWhileLet(po_ps.pa_p.clone(), crate::lower::types::own_f(&crate::lower::expr::value_of_f(lx_p0, env_p1, &**x_pq)), body2_p12.clone())]), env_p1.clone())
                },
            }
        },
        crate::syntax::StmtKind::SExpr(x_p19) => match &*x_p19.kind_p {
            crate::syntax::ExprKind::EIf(c_p1a, then_b_p1b, else_b_o1c) => (Array::from(vec![upd_if_f(lx_p0, env_p1, &**c_p1a, then_b_p1b, else_b_o1c)]), env_p1.clone()),
            crate::syntax::ExprKind::EMatch(scrut_p1d, arms_p1e) => (Array::from(vec![upd_match_f(lx_p0, env_p1, &**scrut_p1d, arms_p1e)]), env_p1.clone()),
            crate::syntax::ExprKind::EFor(binders_o1f, source_p1g, body_p1h) => (Array::from(vec![upd_for_f(lx_p0, env_p1, binders_o1f, &**source_p1g, body_p1h, &x_p19.span_p)]), env_p1.clone()),
            _ => (Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::types::own_f(&crate::lower::expr::value_of_f(lx_p0, env_p1, x_p19)))]), env_p1.clone()),
        },
        _ => crate::lower::expr::block_stmt_f(lx_p0, env_p1, s_p2),
    }
}

/// The step machine of `UpdStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UpdStmt: unbounded fn Lx, Env, Stmt -> (([Do], Env))
/// ```
pub struct UpdStmt {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub s_p2: crate::syntax::Stmt,
}

impl prism_rtl::Job<(Array<crate::lower::model::Do>, crate::lower::types::Env)> for UpdStmt {
    fn cycle(&self) -> prism_rtl::Turn<(Array<crate::lower::model::Do>, crate::lower::types::Env)> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let s_p2 = &self.s_p2;
        match &s_p2.kind_p {
            crate::syntax::StmtKind::SSet(target_p3, value_p4) => {
                let env_p1x = env_p1.clone();
                let lx_p0x = lx_p0.clone();
                let target_p3x = target_p3.clone();
                let value_p4x = value_p4.clone();
                crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p0x.clone(), env_p1x.clone(), value_p4x.clone()), move |value_of_f_8514: crate::lower::types::Vl| {
                    let v_p5 = crate::lower::types::own_f(&value_of_f_8514);
                    crate::prelude::call_then(start_assign_f(lx_p0x.clone(), env_p1x.clone(), target_p3x.clone(), v_p5.clone()), move |assign_f_8551: crate::lower::model::Do| prism_rtl::Turn::Finished((Array::from(vec![assign_f_8551]), env_p1x.clone())))
                })
            },
            crate::syntax::StmtKind::SAccum(target_p6, op_p7, value_p8) => {
                let env_p1x = env_p1.clone();
                let lx_p0x = lx_p0.clone();
                let op_p7x = op_p7.clone();
                let s_p2x = s_p2.clone();
                let target_p6x = target_p6.clone();
                let value_p8x = value_p8.clone();
                crate::prelude::call_then(start_place_of_f(lx_p0x.clone(), env_p1x.clone(), target_p6x.clone()), move |place_of_f_8635: crate::lower::model::Ex| {
                    let cur_p9 = place_of_f_8635;
                    crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0x.clone(), crate::lower::types::peel_f(&crate::lower::type_at_f(&lx_p0x, &target_p6x.span_p))), move |out_ty_of_f_8676: crate::lower::model::OutTy| {
                        let tt_pa = out_ty_of_f_8676;
                        crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p0x.clone(), env_p1x.clone(), value_p8x.clone()), move |value_of_f_8737: crate::lower::types::Vl| {
                            let rv_pb = value_of_f_8737;
                            let bin_pc = crate::syntax::lexer::chars::head_f(&op_p7x);
                            let next_pd = crate::lower::expr::op_value_f(&lx_p0x, &bin_pc, &crate::lower::types::Vl::VlPlace(cur_p9.clone(), crate::lower::types::Holding::Owned, tt_pa.clone()), &rv_pb, &s_p2x.span_p, &tt_pa);
                            crate::prelude::call_then(start_assign_f(lx_p0x.clone(), env_p1x.clone(), target_p6x.clone(), crate::lower::types::own_f(&next_pd)), move |assign_f_8876: crate::lower::model::Do| prism_rtl::Turn::Finished((Array::from(vec![assign_f_8876]), env_p1x.clone())))
                        })
                    })
                })
            },
            crate::syntax::StmtKind::SLet(p_pe, _, x_pf) => {
                let env_p1x = env_p1.clone();
                let lx_p0x = lx_p0.clone();
                let p_pex = p_pe.clone();
                let s_p2x = s_p2.clone();
                let x_pfx = x_pf.clone();
                crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p0x.clone(), env_p1x.clone(), x_pfx.clone()), move |value_of_f_8965: crate::lower::types::Vl| {
                    let v_pg = crate::lower::types::own_f(&value_of_f_8965);
                    match &*p_pex.kind_p {
                        crate::syntax::PatternKind::PName(n_ph) => if crate::syntax::lexer::chars::has_prefix_f(&n_ph.sigils_p, &Text::lit("&")) {
                            {
                                let n_phx = n_ph.clone();
                                crate::prelude::call_then(crate::lower::start_local_name_at_f(lx_p0x.clone(), crate::check::env::sname_key_f(&n_phx), n_phx.span_p.clone()), move |local_name_at_f_9103: Text| {
                                    let rs_pi = local_name_at_f_9103;
                                    crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0x.clone(), crate::lower::types::peel_f(&crate::lower::binder_ty_f(&lx_p0x, &n_phx.span_p))), move |out_ty_of_f_9169: crate::lower::model::OutTy| {
                                        let bt_pj = out_ty_of_f_9169;
                                        crate::prelude::call_then(crate::lower::expr::start_is_known_ty_f(bt_pj.clone()), move |is_known_ty_f_9242: bool| {
                                            let pa_pk = if is_known_ty_f_9242 {
                                                crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaMut(Text::from(format!("{}", &rs_pi)))), bt_pj.clone())
                                            } else {
                                                crate::lower::model::Pa::PaMut(Text::from(format!("{}", &rs_pi)))
                                            };
                                            prism_rtl::Turn::Finished((Array::from(vec![crate::lower::model::Do::DoLet(pa_pk.clone(), v_pg.clone())]), crate::lower::types::bind_f(&env_p1x, &crate::check::env::sname_key_f(&n_phx), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(rs_pi.clone()), crate::lower::types::Holding::Owned, bt_pj.clone()))))
                                        })
                                    })
                                })
                            }
                        } else {
                            prism_rtl::Turn::More(Rc::new(crate::lower::expr::BlockStmt { lx_p0: lx_p0x.clone(), env_p1: env_p1x.clone(), s_p2: s_p2x.clone() }))
                        },
                        _ => prism_rtl::Turn::More(Rc::new(crate::lower::expr::BlockStmt { lx_p0: lx_p0x.clone(), env_p1: env_p1x.clone(), s_p2: s_p2x.clone() })),
                    }
                })
            },
            crate::syntax::StmtKind::SWhile(c_pl, body_pm) => {
                let body_pmx = body_pm.clone();
                let c_plx = c_pl.clone();
                let env_p1x = env_p1.clone();
                let lx_p0x = lx_p0.clone();
                let s_p2x = s_p2.clone();
                crate::prelude::call_then(start_upd_stmts_f(lx_p0x.clone(), env_p1x.clone(), body_pmx.stmts_p.clone()), move |upd_stmts_f_9541: (Array<crate::lower::model::Do>, crate::lower::types::Env)| {
                    let (inner_pn, _) = upd_stmts_f_9541;
                    match &c_plx {
                        crate::syntax::Cond::CondExpr(x_po) => {
                            let x_pox = (**x_po).clone();
                            crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p0x.clone(), env_p1x.clone(), x_pox.clone()), move |value_of_f_9633: crate::lower::types::Vl| prism_rtl::Turn::Finished((Array::from(vec![crate::lower::model::Do::DoWhile(crate::lower::types::as_bool_f(&value_of_f_9633), inner_pn.clone())]), env_p1x.clone())))
                        },
                        crate::syntax::Cond::CondBind(p_pp, x_pq, g_or) => {
                            let g_orx = (**g_or).clone();
                            let p_ppx = p_pp.clone();
                            let x_pqx = (**x_pq).clone();
                            crate::prelude::call_then(crate::lower::patterns::start_rust_pat_f(lx_p0x.clone(), p_ppx.clone(), crate::lower::type_at_f(&lx_p0x, &x_pqx.span_p), crate::lower::types::Holding::Owned, Text::from(format!("w{}", &s_p2x.span_p.start_p))), move |rust_pat_f_9727: crate::lower::patterns::PatOut| {
                                let po_ps = rust_pat_f_9727;
                                let env_b_pt = crate::lower::expr::bind_all_f(&env_p1x, &po_ps.binds_p);
                                crate::prelude::call_then(start_upd_stmts_f(lx_p0x.clone(), env_b_pt.clone(), body_pmx.stmts_p.clone()), move |upd_stmts_f_9878: (Array<crate::lower::model::Do>, crate::lower::types::Env)| {
                                    let (inner2_p13, _) = upd_stmts_f_9878;
                                    crate::prelude::call_then(start_guard_conds_f(lx_p0x.clone(), env_b_pt.clone(), g_orx.clone()), move |guard_conds_f_10136: Array<crate::lower::model::Cc>| {
                                        let conds_pu = crate::prelude::append(&po_ps.conds_p, &guard_conds_f_10136);
                                        let tests_pv = crate::prelude::fold(&conds_pu, &Array::new(), &(|acc_p14: &Array<crate::lower::model::Ex>, c_p15: &crate::lower::model::Cc| match c_p15 {
                                            crate::lower::model::Cc::CcIf(t_p16) => crate::prelude::push(acc_p14, t_p16),
                                            _ => acc_p14.clone(),
                                        }));
                                        let lets_p10 = crate::prelude::fold(&conds_pu, &false, &(|f_p17: &bool, c_p18: &crate::lower::model::Cc| *f_p17 || crate::lower::expr::is_let_cond_f(c_p18)));
                                        let stop_p11 = if &crate::prelude::len(&tests_pv) == &Nat::from(0u32) {
                                            Array::new()
                                        } else {
                                            Array::from(vec![crate::lower::model::Do::DoIf(crate::lower::model::Ex::XUnary(crate::lower::model::UnOp::OpNot, Rc::new(all_of_f(&tests_pv))), Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XVar(Text::lit("break")))]), Array::new())])
                                        };
                                        let body2_p12 = if lets_p10 {
                                            Array::from(vec![crate::lower::expr::refusal_do_f(&Text::lit("a `while` whose pattern matches through an `Rc`"))])
                                        } else {
                                            crate::prelude::append(&stop_p11, &inner2_p13)
                                        };
                                        crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p0x.clone(), env_p1x.clone(), x_pqx.clone()), move |value_of_f_10677: crate::lower::types::Vl| prism_rtl::Turn::Finished((Array::from(vec![crate::lower::model::Do::DoWhileLet(po_ps.pa_p.clone(), crate::lower::types::own_f(&value_of_f_10677), body2_p12.clone())]), env_p1x.clone())))
                                    })
                                })
                            })
                        },
                    }
                })
            },
            crate::syntax::StmtKind::SExpr(x_p19) => match &*x_p19.kind_p {
                crate::syntax::ExprKind::EIf(c_p1a, then_b_p1b, else_b_o1c) => {
                    let else_b_o1cx = else_b_o1c.clone();
                    let c_p1ax = (**c_p1a).clone();
                    let env_p1x = env_p1.clone();
                    let lx_p0x = lx_p0.clone();
                    let then_b_p1bx = then_b_p1b.clone();
                    crate::prelude::call_then(start_upd_if_f(lx_p0x.clone(), env_p1x.clone(), c_p1ax.clone(), then_b_p1bx.clone(), else_b_o1cx.clone()), move |upd_if_f_10777: crate::lower::model::Do| prism_rtl::Turn::Finished((Array::from(vec![upd_if_f_10777]), env_p1x.clone())))
                },
                crate::syntax::ExprKind::EMatch(scrut_p1d, arms_p1e) => {
                    let arms_p1ex = arms_p1e.clone();
                    let env_p1x = env_p1.clone();
                    let lx_p0x = lx_p0.clone();
                    let scrut_p1dx = (**scrut_p1d).clone();
                    crate::prelude::call_then(start_upd_match_f(lx_p0x.clone(), env_p1x.clone(), scrut_p1dx.clone(), arms_p1ex.clone()), move |upd_match_f_10852: crate::lower::model::Do| prism_rtl::Turn::Finished((Array::from(vec![upd_match_f_10852]), env_p1x.clone())))
                },
                crate::syntax::ExprKind::EFor(binders_o1f, source_p1g, body_p1h) => {
                    let binders_o1fx = binders_o1f.clone();
                    let body_p1hx = body_p1h.clone();
                    let env_p1x = env_p1.clone();
                    let lx_p0x = lx_p0.clone();
                    let source_p1gx = (**source_p1g).clone();
                    let x_p19x = x_p19.clone();
                    crate::prelude::call_then(start_upd_for_f(lx_p0x.clone(), env_p1x.clone(), binders_o1fx.clone(), source_p1gx.clone(), body_p1hx.clone(), x_p19x.span_p.clone()), move |upd_for_f_10934: crate::lower::model::Do| prism_rtl::Turn::Finished((Array::from(vec![upd_for_f_10934]), env_p1x.clone())))
                },
                _ => {
                    let env_p1x = env_p1.clone();
                    let lx_p0x = lx_p0.clone();
                    let x_p19x = x_p19.clone();
                    crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p0x.clone(), env_p1x.clone(), x_p19x.clone()), move |value_of_f_11027: crate::lower::types::Vl| prism_rtl::Turn::Finished((Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::types::own_f(&value_of_f_11027))]), env_p1x.clone())))
                },
            },
            _ => prism_rtl::Turn::More(Rc::new(crate::lower::expr::BlockStmt { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), s_p2: s_p2.clone() })),
        }
    }
}

/// `Start UpdStmt, x`: what the function value is when passed to `@Run`.
pub fn start_upd_stmt_f(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, s_p2: crate::syntax::Stmt) -> Rc<dyn prism_rtl::Job<(Array<crate::lower::model::Do>, crate::lower::types::Env)>> {
    Rc::new(UpdStmt { lx_p0, env_p1, s_p2 })
}

/// ```prism
/// UpdFor: unbounded fn Lx, Env, ?ForBinders, Expr, Block, Range -> Do
/// ```
pub fn upd_for_f(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, binders_o2: &Option<crate::syntax::ForBinders>, source_p3: &crate::syntax::Expr, body_p4: &crate::syntax::Block, span_p5: &crate::syntax::Range) -> crate::lower::model::Do {
    let sty_p6 = crate::lower::types::peel_f(&crate::lower::type_at_f(lx_p0, &source_p3.span_p));
    match ref_binder_o(binders_o2) {
        Some(n_p7) => if is_ref_path_f(source_p3) {
            upd_for_refs_f(lx_p0, env_p1, &n_p7, source_p3, body_p4, span_p5, &sty_p6)
        } else {
            upd_for_values_f(lx_p0, env_p1, binders_o2, source_p3, body_p4, span_p5, &sty_p6)
        },
        None => upd_for_values_f(lx_p0, env_p1, binders_o2, source_p3, body_p4, span_p5, &sty_p6),
    }
}

/// The step machine of `UpdFor`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UpdFor: unbounded fn Lx, Env, ?ForBinders, Expr, Block, Range -> Do
/// ```
pub struct UpdFor {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub binders_o2: Option<crate::syntax::ForBinders>,
    pub source_p3: crate::syntax::Expr,
    pub body_p4: crate::syntax::Block,
    pub span_p5: crate::syntax::Range,
}

impl prism_rtl::Job<crate::lower::model::Do> for UpdFor {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::Do> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let binders_o2 = &self.binders_o2;
        let source_p3 = &self.source_p3;
        let body_p4 = &self.body_p4;
        let span_p5 = &self.span_p5;
        let sty_p6 = crate::lower::types::peel_f(&crate::lower::type_at_f(lx_p0, &source_p3.span_p));
        match ref_binder_o(binders_o2) {
            Some(n_p7) => if is_ref_path_f(source_p3) {
                prism_rtl::Turn::More(Rc::new(UpdForRefs { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), n_p2: n_p7.clone(), source_p3: source_p3.clone(), body_p4: body_p4.clone(), span_p5: span_p5.clone(), sty_p6: sty_p6.clone() }))
            } else {
                prism_rtl::Turn::More(Rc::new(UpdForValues { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), binders_o2: binders_o2.clone(), source_p3: source_p3.clone(), body_p4: body_p4.clone(), span_p5: span_p5.clone(), sty_p6: sty_p6.clone() }))
            },
            None => prism_rtl::Turn::More(Rc::new(UpdForValues { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), binders_o2: binders_o2.clone(), source_p3: source_p3.clone(), body_p4: body_p4.clone(), span_p5: span_p5.clone(), sty_p6: sty_p6.clone() })),
        }
    }
}

/// `Start UpdFor, x`: what the function value is when passed to `@Run`.
pub fn start_upd_for_f(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, binders_o2: Option<crate::syntax::ForBinders>, source_p3: crate::syntax::Expr, body_p4: crate::syntax::Block, span_p5: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<crate::lower::model::Do>> {
    Rc::new(UpdFor { lx_p0, env_p1, binders_o2, source_p3, body_p4, span_p5 })
}

/// ```prism
/// UpdForRefs: unbounded fn Lx, Env, SName, Expr, Block, Range, Ty -> Do
/// ```
pub fn upd_for_refs_f(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, n_p2: &crate::syntax::SName, source_p3: &crate::syntax::Expr, body_p4: &crate::syntax::Block, span_p5: &crate::syntax::Range, sty_p6: &crate::check::types::Ty) -> crate::lower::model::Do {
    match sty_p6 {
        crate::check::types::Ty::TyArray(v_p7) => {
            let key_name_p8 = Text::from(format!("k{}", &span_p5.start_p));
            let ref_name_p9 = Text::from(format!("r{}", &span_p5.start_p));
            let env1_pa = crate::lower::types::bind_f(&crate::lower::types::bind_f(&crate::lower::types::bind_f(env_p1, &Text::lit("key"), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(key_name_p8.clone()), crate::lower::types::Holding::Owned, crate::lower::model::OutTy::OutNat)), &Text::lit("ix"), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(key_name_p8.clone()), crate::lower::types::Holding::Owned, crate::lower::model::OutTy::OutNat)), &crate::check::env::sname_key_f(n_p2), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XTarget(Rc::new(crate::lower::model::Ex::XVar(ref_name_p9.clone()))), crate::lower::types::Holding::Owned, crate::lower::types::out_ty_of_f(lx_p0, &**v_p7)));
            let (dos_pc, _) = upd_stmts_f(lx_p0, &env1_pa, &body_p4.stmts_p);
            let head_pb = crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(key_name_p8.clone()), crate::lower::model::Ex::XCall(crate::lower::helper_f(&Text::lit("nat_of")), Array::from(vec![crate::lower::model::Ex::XVar(Text::from(format!("i{}", &span_p5.start_p)))])));
            crate::lower::model::Do::DoFor(crate::lower::model::Pa::PaTuple(Array::from(vec![crate::lower::model::Pa::PaBind(Text::from(format!("i{}", &span_p5.start_p))), crate::lower::model::Pa::PaBind(ref_name_p9.clone())])), crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(place_of_f(lx_p0, env_p1, source_p3)), Text::lit("iter_mut"), Array::new())), Text::lit("enumerate"), Array::new()), crate::prelude::append(&Array::from(vec![head_pb.clone()]), &dos_pc))
        },
        _ => crate::lower::expr::refusal_do_f(&Text::lit("a `for` by reference over what is not an array")),
    }
}

/// The step machine of `UpdForRefs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UpdForRefs: unbounded fn Lx, Env, SName, Expr, Block, Range, Ty -> Do
/// ```
pub struct UpdForRefs {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub n_p2: crate::syntax::SName,
    pub source_p3: crate::syntax::Expr,
    pub body_p4: crate::syntax::Block,
    pub span_p5: crate::syntax::Range,
    pub sty_p6: crate::check::types::Ty,
}

impl prism_rtl::Job<crate::lower::model::Do> for UpdForRefs {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::Do> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let n_p2 = &self.n_p2;
        let source_p3 = &self.source_p3;
        let body_p4 = &self.body_p4;
        let span_p5 = &self.span_p5;
        let sty_p6 = &self.sty_p6;
        match sty_p6 {
            crate::check::types::Ty::TyArray(v_p7) => {
                let key_name_p8 = Text::from(format!("k{}", &span_p5.start_p));
                let ref_name_p9 = Text::from(format!("r{}", &span_p5.start_p));
                let body_p4x = body_p4.clone();
                let env_p1x = env_p1.clone();
                let lx_p0x = lx_p0.clone();
                let n_p2x = n_p2.clone();
                let source_p3x = source_p3.clone();
                let span_p5x = span_p5.clone();
                let v_p7x = (**v_p7).clone();
                crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0x.clone(), v_p7x.clone()), move |out_ty_of_f_12387: crate::lower::model::OutTy| {
                    let env1_pa = crate::lower::types::bind_f(&crate::lower::types::bind_f(&crate::lower::types::bind_f(&env_p1x, &Text::lit("key"), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(key_name_p8.clone()), crate::lower::types::Holding::Owned, crate::lower::model::OutTy::OutNat)), &Text::lit("ix"), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(key_name_p8.clone()), crate::lower::types::Holding::Owned, crate::lower::model::OutTy::OutNat)), &crate::check::env::sname_key_f(&n_p2x), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XTarget(Rc::new(crate::lower::model::Ex::XVar(ref_name_p9.clone()))), crate::lower::types::Holding::Owned, out_ty_of_f_12387));
                    crate::prelude::call_then(start_upd_stmts_f(lx_p0x.clone(), env1_pa.clone(), body_p4x.stmts_p.clone()), move |upd_stmts_f_12433: (Array<crate::lower::model::Do>, crate::lower::types::Env)| {
                        let (dos_pc, _) = upd_stmts_f_12433;
                        let head_pb = crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(key_name_p8.clone()), crate::lower::model::Ex::XCall(crate::lower::helper_f(&Text::lit("nat_of")), Array::from(vec![crate::lower::model::Ex::XVar(Text::from(format!("i{}", &span_p5x.start_p)))])));
                        crate::prelude::call_then(start_place_of_f(lx_p0x.clone(), env_p1x.clone(), source_p3x.clone()), move |place_of_f_12651: crate::lower::model::Ex| prism_rtl::Turn::Finished(crate::lower::model::Do::DoFor(crate::lower::model::Pa::PaTuple(Array::from(vec![crate::lower::model::Pa::PaBind(Text::from(format!("i{}", &span_p5x.start_p))), crate::lower::model::Pa::PaBind(ref_name_p9.clone())])), crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(place_of_f_12651), Text::lit("iter_mut"), Array::new())), Text::lit("enumerate"), Array::new()), crate::prelude::append(&Array::from(vec![head_pb.clone()]), &dos_pc))))
                    })
                })
            },
            _ => prism_rtl::Turn::Finished(crate::lower::expr::refusal_do_f(&Text::lit("a `for` by reference over what is not an array"))),
        }
    }
}

/// `Start UpdForRefs, x`: what the function value is when passed to `@Run`.
pub fn start_upd_for_refs_f(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, n_p2: crate::syntax::SName, source_p3: crate::syntax::Expr, body_p4: crate::syntax::Block, span_p5: crate::syntax::Range, sty_p6: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::lower::model::Do>> {
    Rc::new(UpdForRefs { lx_p0, env_p1, n_p2, source_p3, body_p4, span_p5, sty_p6 })
}

/// ```prism
/// ?RefBinder: fn ?ForBinders -> ?SName
/// ```
pub fn ref_binder_o(opt0: &Option<crate::syntax::ForBinders>) -> Option<crate::syntax::SName> {
    match opt0 {
        Some(fb_p0) => match &fb_p0.second_o {
            None => match &*fb_p0.first_p.kind_p {
                crate::syntax::PatternKind::PName(n_p1) => if crate::syntax::lexer::chars::has_prefix_f(&n_p1.sigils_p, &Text::lit("&")) {
                    Some(n_p1.clone())
                } else {
                    None
                },
                _ => None,
            },
            _ => None,
        },
        None => None,
    }
}

/// ```prism
/// IsRefPath: fn Expr -> Bool
/// ```
pub fn is_ref_path_f(e_p0: &crate::syntax::Expr) -> bool {
    match &*e_p0.kind_p {
        crate::syntax::ExprKind::EName(n_p1) => crate::syntax::lexer::chars::has_prefix_f(&n_p1.sigils_p, &Text::lit("&")),
        crate::syntax::ExprKind::EField(r_p2, _, _) => is_ref_path_f(&**r_p2),
        crate::syntax::ExprKind::EIndex(r_p3, _) => is_ref_path_f(&**r_p3),
        crate::syntax::ExprKind::EGroup(x_p4) => is_ref_path_f(&**x_p4),
        _ => false,
    }
}

/// ```prism
/// UpdForValues: unbounded fn Lx, Env, ?ForBinders, Expr, Block, Range, Ty -> Do
/// ```
pub fn upd_for_values_f(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, binders_o2: &Option<crate::syntax::ForBinders>, source_p3: &crate::syntax::Expr, body_p4: &crate::syntax::Block, span_p5: &crate::syntax::Range, sty_p6: &crate::check::types::Ty) -> crate::lower::model::Do {
    let src_p7 = crate::lower::types::own_f(&crate::lower::expr::value_of_f(lx_p0, env_p1, source_p3));
    let (kt_pf, vt_pg, is_array_ph) = match sty_p6 {
        crate::check::types::Ty::TyArray(v_pc) => (crate::lower::model::OutTy::OutNat, crate::lower::types::out_ty_of_f(lx_p0, &**v_pc), true),
        crate::check::types::Ty::TyMap(k_pd, v_pe) => (crate::lower::types::out_ty_of_f(lx_p0, &**k_pd), crate::lower::types::out_ty_of_f(lx_p0, &**v_pe), false),
        _ => (crate::lower::model::OutTy::OutUnit, crate::lower::model::OutTy::OutUnit, true),
    };
    let (vty_pl, kty_pm) = match sty_p6 {
        crate::check::types::Ty::TyArray(v_pi) => ((**v_pi).clone(), crate::check::types::Ty::TyCon(Text::lit("Nat"), Array::new())),
        crate::check::types::Ty::TyMap(k_pj, v_pk) => ((**v_pk).clone(), (**k_pj).clone()),
        _ => (crate::check::types::Ty::TyErr, crate::check::types::Ty::TyErr),
    };
    let key_name_p8 = Text::from(format!("k{}", &span_p5.start_p));
    let val_name_p9 = Text::from(format!("v{}", &span_p5.start_p));
    let env1_pa = crate::lower::types::bind_f(&crate::lower::types::bind_f(env_p1, &Text::lit("key"), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(key_name_p8.clone()), crate::lower::types::Holding::Owned, kt_pf.clone())), &Text::lit("_"), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(val_name_p9.clone()), crate::lower::types::Holding::Owned, vt_pg.clone()));
    let env2_pb = if is_array_ph {
        crate::lower::types::bind_f(&env1_pa, &Text::lit("ix"), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(key_name_p8.clone()), crate::lower::types::Holding::Owned, kt_pf.clone()))
    } else {
        env1_pa.clone()
    };
    let (binds_ps, env3_pt) = match binders_o2 {
        None => (Array::new(), env2_pb.clone()),
        Some(fb_pn) => match &fb_pn.second_o {
            None => {
                let po_po = crate::lower::patterns::rust_pat_f(lx_p0, &fb_pn.first_p, &vty_pl, &crate::lower::types::Holding::Owned, &Text::from(format!("e{}", &span_p5.start_p)));
                (Array::from(vec![crate::lower::model::Do::DoLet(po_po.pa_p.clone(), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(val_name_p9.clone()))))]), crate::lower::expr::bind_all_f(&env2_pb, &po_po.binds_p))
            },
            Some(second_pp) => {
                let pk_pq = crate::lower::patterns::rust_pat_f(lx_p0, &fb_pn.first_p, &kty_pm, &crate::lower::types::Holding::Owned, &Text::from(format!("k{}_", &span_p5.start_p)));
                let pv_pr = crate::lower::patterns::rust_pat_f(lx_p0, second_pp, &vty_pl, &crate::lower::types::Holding::Owned, &Text::from(format!("e{}", &span_p5.start_p)));
                (Array::from(vec![crate::lower::model::Do::DoLet(pk_pq.pa_p.clone(), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(key_name_p8.clone())))), crate::lower::model::Do::DoLet(pv_pr.pa_p.clone(), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(val_name_p9.clone()))))]), crate::lower::expr::bind_all_f(&crate::lower::expr::bind_all_f(&env2_pb, &pk_pq.binds_p), &pv_pr.binds_p))
            },
        },
    };
    let (dos_pu, _) = upd_stmts_f(lx_p0, &env3_pt, &body_p4.stmts_p);
    if is_array_ph {
        {
            let head_pv = crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(key_name_p8.clone()), crate::lower::model::Ex::XCall(crate::lower::helper_f(&Text::lit("nat_of")), Array::from(vec![crate::lower::model::Ex::XVar(Text::from(format!("i{}", &span_p5.start_p)))])));
            crate::lower::model::Do::DoFor(crate::lower::model::Pa::PaTuple(Array::from(vec![crate::lower::model::Pa::PaBind(Text::from(format!("i{}", &span_p5.start_p))), crate::lower::model::Pa::PaBind(val_name_p9.clone())])), crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(src_p7.clone()), Text::lit("into_iter"), Array::new())), Text::lit("enumerate"), Array::new()), crate::prelude::append(&crate::prelude::push(&Array::new(), &head_pv), &crate::prelude::append(&binds_ps, &dos_pu)))
        }
    } else {
        crate::lower::model::Do::DoFor(crate::lower::model::Pa::PaTuple(Array::from(vec![crate::lower::model::Pa::PaBind(key_name_p8.clone()), crate::lower::model::Pa::PaBind(val_name_p9.clone())])), crate::lower::model::Ex::XMethod(Rc::new(src_p7.clone()), Text::lit("into_iter"), Array::new()), crate::prelude::append(&binds_ps, &dos_pu))
    }
}

/// The step machine of `UpdForValues`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UpdForValues: unbounded fn Lx, Env, ?ForBinders, Expr, Block, Range, Ty -> Do
/// ```
pub struct UpdForValues {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub binders_o2: Option<crate::syntax::ForBinders>,
    pub source_p3: crate::syntax::Expr,
    pub body_p4: crate::syntax::Block,
    pub span_p5: crate::syntax::Range,
    pub sty_p6: crate::check::types::Ty,
}

impl prism_rtl::Job<crate::lower::model::Do> for UpdForValues {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::Do> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let binders_o2 = &self.binders_o2;
        let source_p3 = &self.source_p3;
        let body_p4 = &self.body_p4;
        let span_p5 = &self.span_p5;
        let sty_p6 = &self.sty_p6;
        let binders_o2x = binders_o2.clone();
        let body_p4x = body_p4.clone();
        let env_p1x = env_p1.clone();
        let lx_p0x = lx_p0.clone();
        let source_p3x = source_p3.clone();
        let span_p5x = span_p5.clone();
        let sty_p6x = sty_p6.clone();
        crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p0x.clone(), env_p1x.clone(), source_p3x.clone()), move |value_of_f_13546: crate::lower::types::Vl| {
            let src_p7 = crate::lower::types::own_f(&value_of_f_13546);
            let (kt_pf, vt_pg, is_array_ph) = match &sty_p6x {
                crate::check::types::Ty::TyArray(v_pc) => (crate::lower::model::OutTy::OutNat, crate::lower::types::out_ty_of_f(&lx_p0x, &**v_pc), true),
                crate::check::types::Ty::TyMap(k_pd, v_pe) => (crate::lower::types::out_ty_of_f(&lx_p0x, &**k_pd), crate::lower::types::out_ty_of_f(&lx_p0x, &**v_pe), false),
                _ => (crate::lower::model::OutTy::OutUnit, crate::lower::model::OutTy::OutUnit, true),
            };
            let (vty_pl, kty_pm) = match &sty_p6x {
                crate::check::types::Ty::TyArray(v_pi) => ((**v_pi).clone(), crate::check::types::Ty::TyCon(Text::lit("Nat"), Array::new())),
                crate::check::types::Ty::TyMap(k_pj, v_pk) => ((**v_pk).clone(), (**k_pj).clone()),
                _ => (crate::check::types::Ty::TyErr, crate::check::types::Ty::TyErr),
            };
            let key_name_p8 = Text::from(format!("k{}", &span_p5x.start_p));
            let val_name_p9 = Text::from(format!("v{}", &span_p5x.start_p));
            let env1_pa = crate::lower::types::bind_f(&crate::lower::types::bind_f(&env_p1x, &Text::lit("key"), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(key_name_p8.clone()), crate::lower::types::Holding::Owned, kt_pf.clone())), &Text::lit("_"), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(val_name_p9.clone()), crate::lower::types::Holding::Owned, vt_pg.clone()));
            let env2_pb = if is_array_ph {
                crate::lower::types::bind_f(&env1_pa, &Text::lit("ix"), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(key_name_p8.clone()), crate::lower::types::Holding::Owned, kt_pf.clone()))
            } else {
                env1_pa.clone()
            };
            let (binds_ps, env3_pt) = match &binders_o2x {
                None => (Array::new(), env2_pb.clone()),
                Some(fb_pn) => match &fb_pn.second_o {
                    None => {
                        let po_po = crate::lower::patterns::rust_pat_f(&lx_p0x, &fb_pn.first_p, &vty_pl, &crate::lower::types::Holding::Owned, &Text::from(format!("e{}", &span_p5x.start_p)));
                        (Array::from(vec![crate::lower::model::Do::DoLet(po_po.pa_p.clone(), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(val_name_p9.clone()))))]), crate::lower::expr::bind_all_f(&env2_pb, &po_po.binds_p))
                    },
                    Some(second_pp) => {
                        let pk_pq = crate::lower::patterns::rust_pat_f(&lx_p0x, &fb_pn.first_p, &kty_pm, &crate::lower::types::Holding::Owned, &Text::from(format!("k{}_", &span_p5x.start_p)));
                        let pv_pr = crate::lower::patterns::rust_pat_f(&lx_p0x, second_pp, &vty_pl, &crate::lower::types::Holding::Owned, &Text::from(format!("e{}", &span_p5x.start_p)));
                        (Array::from(vec![crate::lower::model::Do::DoLet(pk_pq.pa_p.clone(), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(key_name_p8.clone())))), crate::lower::model::Do::DoLet(pv_pr.pa_p.clone(), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(val_name_p9.clone()))))]), crate::lower::expr::bind_all_f(&crate::lower::expr::bind_all_f(&env2_pb, &pk_pq.binds_p), &pv_pr.binds_p))
                    },
                },
            };
            crate::prelude::call_then(start_upd_stmts_f(lx_p0x.clone(), env3_pt.clone(), body_p4x.stmts_p.clone()), move |upd_stmts_f_14827: (Array<crate::lower::model::Do>, crate::lower::types::Env)| {
                let (dos_pu, _) = upd_stmts_f_14827;
                if is_array_ph {
                    {
                        let head_pv = crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(key_name_p8.clone()), crate::lower::model::Ex::XCall(crate::lower::helper_f(&Text::lit("nat_of")), Array::from(vec![crate::lower::model::Ex::XVar(Text::from(format!("i{}", &span_p5x.start_p)))])));
                        prism_rtl::Turn::Finished(crate::lower::model::Do::DoFor(crate::lower::model::Pa::PaTuple(Array::from(vec![crate::lower::model::Pa::PaBind(Text::from(format!("i{}", &span_p5x.start_p))), crate::lower::model::Pa::PaBind(val_name_p9.clone())])), crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(src_p7.clone()), Text::lit("into_iter"), Array::new())), Text::lit("enumerate"), Array::new()), crate::prelude::append(&crate::prelude::push(&Array::new(), &head_pv), &crate::prelude::append(&binds_ps, &dos_pu))))
                    }
                } else {
                    prism_rtl::Turn::Finished(crate::lower::model::Do::DoFor(crate::lower::model::Pa::PaTuple(Array::from(vec![crate::lower::model::Pa::PaBind(key_name_p8.clone()), crate::lower::model::Pa::PaBind(val_name_p9.clone())])), crate::lower::model::Ex::XMethod(Rc::new(src_p7.clone()), Text::lit("into_iter"), Array::new()), crate::prelude::append(&binds_ps, &dos_pu)))
                }
            })
        })
    }
}

/// `Start UpdForValues, x`: what the function value is when passed to `@Run`.
pub fn start_upd_for_values_f(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, binders_o2: Option<crate::syntax::ForBinders>, source_p3: crate::syntax::Expr, body_p4: crate::syntax::Block, span_p5: crate::syntax::Range, sty_p6: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::lower::model::Do>> {
    Rc::new(UpdForValues { lx_p0, env_p1, binders_o2, source_p3, body_p4, span_p5, sty_p6 })
}

/// ```prism
/// UpdIf: unbounded fn Lx, Env, Cond, Block, ?Block -> Do
/// ```
pub fn upd_if_f(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, c_p2: &crate::syntax::Cond, then_b_p3: &crate::syntax::Block, else_b_o4: &Option<crate::syntax::Block>) -> crate::lower::model::Do {
    let (else_dos_p6, _) = match else_b_o4 {
        Some(b_p5) => upd_stmts_f(lx_p0, env_p1, &b_p5.stmts_p),
        None => (Array::new(), env_p1.clone()),
    };
    match c_p2 {
        crate::syntax::Cond::CondExpr(x_p7) => {
            let (then_dos_p8, _) = upd_stmts_f(lx_p0, env_p1, &then_b_p3.stmts_p);
            crate::lower::model::Do::DoIf(crate::lower::types::as_bool_f(&crate::lower::expr::value_of_f(lx_p0, env_p1, &**x_p7)), then_dos_p8.clone(), else_dos_p6.clone())
        },
        crate::syntax::Cond::CondBind(p_p9, x_pa, _) => {
            let po_pb = crate::lower::patterns::rust_pat_f(lx_p0, p_p9, &crate::lower::type_at_f(lx_p0, &x_pa.span_p), &crate::lower::types::Holding::Owned, &Text::from(format!("u{}", &x_pa.span_p.start_p)));
            let (then_dos_pc, _) = upd_stmts_f(lx_p0, &crate::lower::expr::bind_all_f(env_p1, &po_pb.binds_p), &then_b_p3.stmts_p);
            crate::lower::model::Do::DoIfLet(po_pb.pa_p.clone(), crate::lower::types::own_f(&crate::lower::expr::value_of_f(lx_p0, env_p1, &**x_pa)), then_dos_pc.clone(), else_dos_p6.clone())
        },
    }
}

/// The step machine of `UpdIf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UpdIf: unbounded fn Lx, Env, Cond, Block, ?Block -> Do
/// ```
pub struct UpdIf {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub c_p2: crate::syntax::Cond,
    pub then_b_p3: crate::syntax::Block,
    pub else_b_o4: Option<crate::syntax::Block>,
}

impl prism_rtl::Job<crate::lower::model::Do> for UpdIf {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::Do> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let c_p2 = &self.c_p2;
        let then_b_p3 = &self.then_b_p3;
        let else_b_o4 = &self.else_b_o4;
        let (else_dos_p6, _) = match else_b_o4 {
            Some(b_p5) => upd_stmts_f(lx_p0, env_p1, &b_p5.stmts_p),
            None => (Array::new(), env_p1.clone()),
        };
        match c_p2 {
            crate::syntax::Cond::CondExpr(x_p7) => {
                let env_p1x = env_p1.clone();
                let lx_p0x = lx_p0.clone();
                let then_b_p3x = then_b_p3.clone();
                let x_p7x = (**x_p7).clone();
                crate::prelude::call_then(start_upd_stmts_f(lx_p0x.clone(), env_p1x.clone(), then_b_p3x.stmts_p.clone()), move |upd_stmts_f_15546: (Array<crate::lower::model::Do>, crate::lower::types::Env)| {
                    let (then_dos_p8, _) = upd_stmts_f_15546;
                    crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p0x.clone(), env_p1x.clone(), x_p7x.clone()), move |value_of_f_15602: crate::lower::types::Vl| prism_rtl::Turn::Finished(crate::lower::model::Do::DoIf(crate::lower::types::as_bool_f(&value_of_f_15602), then_dos_p8.clone(), else_dos_p6.clone())))
                })
            },
            crate::syntax::Cond::CondBind(p_p9, x_pa, _) => {
                let env_p1x = env_p1.clone();
                let lx_p0x = lx_p0.clone();
                let p_p9x = p_p9.clone();
                let then_b_p3x = then_b_p3.clone();
                let x_pax = (**x_pa).clone();
                crate::prelude::call_then(crate::lower::patterns::start_rust_pat_f(lx_p0x.clone(), p_p9x.clone(), crate::lower::type_at_f(&lx_p0x, &x_pax.span_p), crate::lower::types::Holding::Owned, Text::from(format!("u{}", &x_pax.span_p.start_p))), move |rust_pat_f_15693: crate::lower::patterns::PatOut| {
                    let po_pb = rust_pat_f_15693;
                    crate::prelude::call_then(start_upd_stmts_f(lx_p0x.clone(), crate::lower::expr::bind_all_f(&env_p1x, &po_pb.binds_p), then_b_p3x.stmts_p.clone()), move |upd_stmts_f_15792: (Array<crate::lower::model::Do>, crate::lower::types::Env)| {
                        let (then_dos_pc, _) = upd_stmts_f_15792;
                        crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p0x.clone(), env_p1x.clone(), x_pax.clone()), move |value_of_f_15875: crate::lower::types::Vl| prism_rtl::Turn::Finished(crate::lower::model::Do::DoIfLet(po_pb.pa_p.clone(), crate::lower::types::own_f(&value_of_f_15875), then_dos_pc.clone(), else_dos_p6.clone())))
                    })
                })
            },
        }
    }
}

/// `Start UpdIf, x`: what the function value is when passed to `@Run`.
pub fn start_upd_if_f(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, c_p2: crate::syntax::Cond, then_b_p3: crate::syntax::Block, else_b_o4: Option<crate::syntax::Block>) -> Rc<dyn prism_rtl::Job<crate::lower::model::Do>> {
    Rc::new(UpdIf { lx_p0, env_p1, c_p2, then_b_p3, else_b_o4 })
}

/// ```prism
/// UpdMatch: unbounded fn Lx, Env, Expr, [Arm] -> Do
/// ```
pub fn upd_match_f(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, scrut_p2: &crate::syntax::Expr, arms_p3: &Array<crate::syntax::Arm>) -> crate::lower::model::Do {
    let sv_p4 = crate::lower::expr::value_of_f(lx_p0, env_p1, scrut_p2);
    let sty_p5 = crate::lower::type_at_f(lx_p0, &scrut_p2.span_p);
    let arms3_p6 = crate::prelude::run_to_end(crate::prelude::each_job(crate::check::errors::range0_f(&crate::prelude::len(arms_p3)), {
        let arms_p3x = arms_p3.clone();
        let lx_p0x = lx_p0.clone();
        let sty_p5x = sty_p5.clone();
        let scrut_p2x = scrut_p2.clone();
        let env_p1x = env_p1.clone();
        Rc::new(move |p0: Nat| {
            let arms_p3xy = arms_p3x.clone();
            let lx_p0xy = lx_p0x.clone();
            let sty_p5xy = sty_p5x.clone();
            let scrut_p2xy = scrut_p2x.clone();
            let env_p1xy = env_p1x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let i_p7 = p0;
                {
                    let arm_p8 = crate::prelude::or(&crate::prelude::index(&arms_p3xy, &i_p7), &crate::lower::expr::dummy_arm_p());
                    crate::prelude::call_then(crate::lower::expr::start_arm_pat_f(lx_p0xy.clone(), arm_p8.pattern_o.clone(), sty_p5xy.clone(), crate::lower::types::Holding::ByRef, Text::from(format!("u{}_{}", &scrut_p2xy.span_p.start_p, &i_p7))), move |arm_pat_f_16174: crate::lower::patterns::PatOut| {
                        let po_p9 = arm_pat_f_16174;
                        crate::prelude::call_then(start_upd_stmts_f(lx_p0xy.clone(), crate::lower::expr::bind_all_f(&env_p1xy, &po_p9.binds_p), arm_p8.body_p.stmts_p.clone()), move |upd_stmts_f_16267: (Array<crate::lower::model::Do>, crate::lower::types::Env)| {
                            let (dos_pb, _) = upd_stmts_f_16267;
                            crate::prelude::call_then(start_guard_conds_f(lx_p0xy.clone(), crate::lower::expr::bind_all_f(&env_p1xy, &po_p9.binds_p), arm_p8.guard_o.clone()), move |guard_conds_f_16360: Array<crate::lower::model::Cc>| {
                                let guarded_pa = crate::prelude::append(&po_p9.conds_p, &guard_conds_f_16360);
                                prism_rtl::Turn::Finished(crate::lower::model::XArm { pat_p: po_p9.pa_p.clone(), conds_p: guarded_pa.clone(), body_p: crate::lower::model::Ex::XBlock(dos_pb.clone(), Rc::new(crate::lower::model::Ex::XUnit)) })
                            })
                        })
                    })
                }
            }))
        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<crate::lower::model::XArm>>>
    }));
    if crate::prelude::fold(&arms3_p6, &false, &(|f_pc: &bool, a_pd: &crate::lower::model::XArm| *f_pc || (&crate::prelude::len(&a_pd.conds_p) > &Nat::from(0u32)))) {
        crate::lower::model::Do::DoExpr(crate::lower::types::own_f(&crate::lower::expr::arms_value_f(&crate::lower::types::ref_f(&sv_p4), &arms3_p6, &Text::from(format!("\'u{}", &scrut_p2.span_p.start_p)), &crate::lower::model::OutTy::OutUnit)))
    } else {
        crate::lower::model::Do::DoMatch(crate::lower::types::ref_f(&sv_p4), crate::prelude::each(&arms3_p6, &(|a_pe: &crate::lower::model::XArm| (a_pe.pat_p.clone(), arm_dos_f(&a_pe.body_p)))))
    }
}

/// The step machine of `UpdMatch`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UpdMatch: unbounded fn Lx, Env, Expr, [Arm] -> Do
/// ```
pub struct UpdMatch {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub scrut_p2: crate::syntax::Expr,
    pub arms_p3: Array<crate::syntax::Arm>,
}

impl prism_rtl::Job<crate::lower::model::Do> for UpdMatch {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::Do> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let scrut_p2 = &self.scrut_p2;
        let arms_p3 = &self.arms_p3;
        let arms_p3x = arms_p3.clone();
        let env_p1x = env_p1.clone();
        let lx_p0x = lx_p0.clone();
        let scrut_p2x = scrut_p2.clone();
        crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p0x.clone(), env_p1x.clone(), scrut_p2x.clone()), move |value_of_f_16012: crate::lower::types::Vl| {
            let sv_p4 = value_of_f_16012;
            let sty_p5 = crate::lower::type_at_f(&lx_p0x, &scrut_p2x.span_p);
            crate::prelude::call_value(crate::prelude::each_job(crate::check::errors::range0_f(&crate::prelude::len(&arms_p3x)), {
                let arms_p3xx = arms_p3x.clone();
                let lx_p0xx = lx_p0x.clone();
                let sty_p5x = sty_p5.clone();
                let scrut_p2xx = scrut_p2x.clone();
                let env_p1xx = env_p1x.clone();
                Rc::new(move |p0: Nat| {
                    let arms_p3xxy = arms_p3xx.clone();
                    let lx_p0xxy = lx_p0xx.clone();
                    let sty_p5xy = sty_p5x.clone();
                    let scrut_p2xxy = scrut_p2xx.clone();
                    let env_p1xxy = env_p1xx.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let i_p7 = p0;
                        {
                            let arm_p8 = crate::prelude::or(&crate::prelude::index(&arms_p3xxy, &i_p7), &crate::lower::expr::dummy_arm_p());
                            crate::prelude::call_then(crate::lower::expr::start_arm_pat_f(lx_p0xxy.clone(), arm_p8.pattern_o.clone(), sty_p5xy.clone(), crate::lower::types::Holding::ByRef, Text::from(format!("u{}_{}", &scrut_p2xxy.span_p.start_p, &i_p7))), move |arm_pat_f_16174: crate::lower::patterns::PatOut| {
                                let po_p9 = arm_pat_f_16174;
                                crate::prelude::call_then(start_upd_stmts_f(lx_p0xxy.clone(), crate::lower::expr::bind_all_f(&env_p1xxy, &po_p9.binds_p), arm_p8.body_p.stmts_p.clone()), move |upd_stmts_f_16267: (Array<crate::lower::model::Do>, crate::lower::types::Env)| {
                                    let (dos_pb, _) = upd_stmts_f_16267;
                                    crate::prelude::call_then(start_guard_conds_f(lx_p0xxy.clone(), crate::lower::expr::bind_all_f(&env_p1xxy, &po_p9.binds_p), arm_p8.guard_o.clone()), move |guard_conds_f_16360: Array<crate::lower::model::Cc>| {
                                        let guarded_pa = crate::prelude::append(&po_p9.conds_p, &guard_conds_f_16360);
                                        prism_rtl::Turn::Finished(crate::lower::model::XArm { pat_p: po_p9.pa_p.clone(), conds_p: guarded_pa.clone(), body_p: crate::lower::model::Ex::XBlock(dos_pb.clone(), Rc::new(crate::lower::model::Ex::XUnit)) })
                                    })
                                })
                            })
                        }
                    }))
                }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<crate::lower::model::XArm>>>
            }), move |each_16087: Array<crate::lower::model::XArm>| {
                let arms3_p6 = each_16087;
                if crate::prelude::fold(&arms3_p6, &false, &(|f_pc: &bool, a_pd: &crate::lower::model::XArm| *f_pc || (&crate::prelude::len(&a_pd.conds_p) > &Nat::from(0u32)))) {
                    prism_rtl::Turn::Finished(crate::lower::model::Do::DoExpr(crate::lower::types::own_f(&crate::lower::expr::arms_value_f(&crate::lower::types::ref_f(&sv_p4), &arms3_p6, &Text::from(format!("\'u{}", &scrut_p2x.span_p.start_p)), &crate::lower::model::OutTy::OutUnit))))
                } else {
                    prism_rtl::Turn::Finished(crate::lower::model::Do::DoMatch(crate::lower::types::ref_f(&sv_p4), crate::prelude::each(&arms3_p6, &(|a_pe: &crate::lower::model::XArm| (a_pe.pat_p.clone(), arm_dos_f(&a_pe.body_p))))))
                }
            })
        })
    }
}

/// `Start UpdMatch, x`: what the function value is when passed to `@Run`.
pub fn start_upd_match_f(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, scrut_p2: crate::syntax::Expr, arms_p3: Array<crate::syntax::Arm>) -> Rc<dyn prism_rtl::Job<crate::lower::model::Do>> {
    Rc::new(UpdMatch { lx_p0, env_p1, scrut_p2, arms_p3 })
}

/// ```prism
/// AllOf: fn [Ex] -> Ex
/// ```
pub fn all_of_f(xs0: &Array<crate::lower::model::Ex>) -> crate::lower::model::Ex {
    'c: {
        if let c0_0 = xs0 && (c0_0.len() == 1) && let Some(one_p0) = crate::prelude::index(c0_0, &Nat::from(0u32)) {
            break 'c one_p0.clone();
        }
        if let xs_p1 = xs0 {
            break 'c crate::prelude::fold(&crate::prelude::drop(xs_p1, &Nat::from(1u32)), &crate::prelude::or(&crate::prelude::index(xs_p1, &Nat::from(0u32)), &crate::lower::model::Ex::XBool(true)), &(|acc_p2: &crate::lower::model::Ex, x_p3: &crate::lower::model::Ex| crate::lower::model::Ex::XBin(crate::lower::model::BinOp::OpAnd, Rc::new(acc_p2.clone()), Rc::new(x_p3.clone()))));
        }
        unreachable!("no clause matched")
    }
}

/// ```prism
/// ArmDos: fn Ex -> [Do]
/// ```
pub fn arm_dos_f(ex0: &crate::lower::model::Ex) -> Array<crate::lower::model::Do> {
    match ex0 {
        crate::lower::model::Ex::XBlock(dos_p0, _) => dos_p0.clone(),
        x_p1 => Array::from(vec![crate::lower::model::Do::DoExpr(x_p1.clone())]),
    }
}

/// ```prism
/// GuardConds: unbounded fn Lx, Env, ?Expr -> [Cc]
/// ```
pub fn guard_conds_f(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, opt2: &Option<crate::syntax::Expr>) -> Array<crate::lower::model::Cc> {
    match opt2 {
        Some(ge_p2) => Array::from(vec![crate::lower::model::Cc::CcIf(crate::lower::types::as_bool_f(&crate::lower::expr::value_of_f(lx_p0, env_p1, ge_p2)))]),
        None => Array::new(),
    }
}

/// The step machine of `GuardConds`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// GuardConds: unbounded fn Lx, Env, ?Expr -> [Cc]
/// ```
pub struct GuardConds {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub opt2: Option<crate::syntax::Expr>,
}

impl prism_rtl::Job<Array<crate::lower::model::Cc>> for GuardConds {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::lower::model::Cc>> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let opt2 = &self.opt2;
        match opt2 {
            Some(ge_p2) => {
                let env_p1x = env_p1.clone();
                let ge_p2x = ge_p2.clone();
                let lx_p0x = lx_p0.clone();
                crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p0x.clone(), env_p1x.clone(), ge_p2x.clone()), move |value_of_f_17203: crate::lower::types::Vl| prism_rtl::Turn::Finished(Array::from(vec![crate::lower::model::Cc::CcIf(crate::lower::types::as_bool_f(&value_of_f_17203))])))
            },
            None => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start GuardConds, x`: what the function value is when passed to `@Run`.
pub fn start_guard_conds_f(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, opt2: Option<crate::syntax::Expr>) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Cc>>> {
    Rc::new(GuardConds { lx_p0, env_p1, opt2 })
}

/// ```prism
/// PlaceOf: unbounded fn Lx, Env, Expr -> Ex
/// ```
pub fn place_of_f(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, e_p2: &crate::syntax::Expr) -> crate::lower::model::Ex {
    match &*e_p2.kind_p {
        crate::syntax::ExprKind::EName(n_p3) => match crate::prelude::get(&env_p1.names_p, &crate::check::env::sname_key_f(n_p3)) {
            Some(crate::lower::types::Bn::BnLocal(rs_p4, _, _)) => rs_p4,
            _ => crate::lower::model::Ex::XVar(crate::lower::snake_f(&crate::check::env::sname_key_f(n_p3))),
        },
        crate::syntax::ExprKind::EField(r_p5, _, name_p6) => {
            let (_, _, f_p7) = crate::lower::expr::field_info_f(lx_p0, &crate::lower::types::peel_f(&place_ty_f(lx_p0, &**r_p5)), &name_p6.name_p);
            crate::lower::model::Ex::XField(Rc::new(place_of_f(lx_p0, env_p1, &**r_p5)), f_p7.clone())
        },
        crate::syntax::ExprKind::EIndex(r_p8, k_p9) => {
            let rt_pa = crate::lower::types::out_ty_of_f(lx_p0, &crate::lower::types::peel_f(&place_ty_f(lx_p0, &**r_p8)));
            let f_pb = match &rt_pa {
                crate::lower::model::OutTy::OutMap(_, _) => Text::lit("at_mut_map"),
                _ => Text::lit("at_mut"),
            };
            crate::lower::model::Ex::XDeref(Rc::new(crate::lower::model::Ex::XCall(f_pb.clone(), Array::from(vec![crate::lower::model::Ex::XRefMut(Rc::new(place_of_f(lx_p0, env_p1, &**r_p8))), crate::lower::expr::argument_f(lx_p0, env_p1, &**k_p9)]))))
        },
        crate::syntax::ExprKind::EGroup(x_pc) => place_of_f(lx_p0, env_p1, &**x_pc),
        _ => crate::lower::expr::refusal_f(&Text::lit("a reference path this back end does not lower")),
    }
}

/// The step machine of `PlaceOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PlaceOf: unbounded fn Lx, Env, Expr -> Ex
/// ```
pub struct PlaceOf {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub e_p2: crate::syntax::Expr,
}

impl prism_rtl::Job<crate::lower::model::Ex> for PlaceOf {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::Ex> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let e_p2 = &self.e_p2;
        match &*e_p2.kind_p {
            crate::syntax::ExprKind::EName(n_p3) => match crate::prelude::get(&env_p1.names_p, &crate::check::env::sname_key_f(n_p3)) {
                Some(crate::lower::types::Bn::BnLocal(rs_p4, _, _)) => prism_rtl::Turn::Finished(rs_p4.clone()),
                _ => prism_rtl::Turn::Finished(crate::lower::model::Ex::XVar(crate::lower::snake_f(&crate::check::env::sname_key_f(n_p3)))),
            },
            crate::syntax::ExprKind::EField(r_p5, _, name_p6) => {
                let env_p1x = env_p1.clone();
                let lx_p0x = lx_p0.clone();
                let name_p6x = name_p6.clone();
                let r_p5x = (**r_p5).clone();
                crate::prelude::call_then(start_place_ty_f(lx_p0x.clone(), r_p5x.clone()), move |place_ty_f_17620: crate::check::types::Ty| crate::prelude::call_then(crate::lower::expr::start_field_info_f(lx_p0x.clone(), crate::lower::types::peel_f(&place_ty_f_17620), name_p6x.name_p.clone()), move |field_info_f_17599: (crate::lower::model::OutTy, bool, Text)| {
                    let (_, _, f_p7) = field_info_f_17599;
                    crate::prelude::call_then(start_place_of_f(lx_p0x.clone(), env_p1x.clone(), r_p5x.clone()), move |place_of_f_17663: crate::lower::model::Ex| prism_rtl::Turn::Finished(crate::lower::model::Ex::XField(Rc::new(place_of_f_17663), f_p7.clone())))
                }))
            },
            crate::syntax::ExprKind::EIndex(r_p8, k_p9) => {
                let env_p1x = env_p1.clone();
                let k_p9x = (**k_p9).clone();
                let lx_p0x = lx_p0.clone();
                let r_p8x = (**r_p8).clone();
                crate::prelude::call_then(start_place_ty_f(lx_p0x.clone(), r_p8x.clone()), move |place_ty_f_17739: crate::check::types::Ty| crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0x.clone(), crate::lower::types::peel_f(&place_ty_f_17739)), move |out_ty_of_f_17720: crate::lower::model::OutTy| {
                    let rt_pa = out_ty_of_f_17720;
                    let f_pb = match &rt_pa {
                        crate::lower::model::OutTy::OutMap(_, _) => Text::lit("at_mut_map"),
                        _ => Text::lit("at_mut"),
                    };
                    crate::prelude::call_then(start_place_of_f(lx_p0x.clone(), env_p1x.clone(), r_p8x.clone()), move |place_of_f_17898: crate::lower::model::Ex| crate::prelude::call_then(crate::lower::expr::start_argument_f(lx_p0x.clone(), env_p1x.clone(), k_p9x.clone()), move |argument_f_17921: crate::lower::model::Ex| prism_rtl::Turn::Finished(crate::lower::model::Ex::XDeref(Rc::new(crate::lower::model::Ex::XCall(f_pb.clone(), Array::from(vec![crate::lower::model::Ex::XRefMut(Rc::new(place_of_f_17898)), argument_f_17921])))))))
                }))
            },
            crate::syntax::ExprKind::EGroup(x_pc) => prism_rtl::Turn::More(Rc::new(PlaceOf { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), e_p2: (**x_pc).clone() })),
            _ => prism_rtl::Turn::Finished(crate::lower::expr::refusal_f(&Text::lit("a reference path this back end does not lower"))),
        }
    }
}

/// `Start PlaceOf, x`: what the function value is when passed to `@Run`.
pub fn start_place_of_f(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, e_p2: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>> {
    Rc::new(PlaceOf { lx_p0, env_p1, e_p2 })
}

/// ```prism
/// PlaceTy: unbounded fn Lx, Expr -> Ty
/// ```
pub fn place_ty_f(lx_p0: &crate::lower::Lx, e_p1: &crate::syntax::Expr) -> crate::check::types::Ty {
    match crate::lower::type_at_f(lx_p0, &e_p1.span_p) {
        crate::check::types::Ty::TyErr => match &*e_p1.kind_p {
            crate::syntax::ExprKind::EIndex(r_p2, _) => match crate::lower::types::peel_f(&place_ty_f(lx_p0, &**r_p2)) {
                crate::check::types::Ty::TyArray(el_p3) => (*el_p3).clone(),
                crate::check::types::Ty::TyMap(_, v_p4) => (*v_p4).clone(),
                _ => crate::check::types::Ty::TyErr,
            },
            crate::syntax::ExprKind::EField(r_p5, _, name_p6) => field_ty_f(lx_p0, &crate::lower::types::peel_f(&place_ty_f(lx_p0, &**r_p5)), &name_p6.name_p),
            crate::syntax::ExprKind::EGroup(x_p7) => place_ty_f(lx_p0, &**x_p7),
            _ => crate::check::types::Ty::TyErr,
        },
        t_p8 => t_p8,
    }
}

/// The step machine of `PlaceTy`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PlaceTy: unbounded fn Lx, Expr -> Ty
/// ```
pub struct PlaceTy {
    pub lx_p0: crate::lower::Lx,
    pub e_p1: crate::syntax::Expr,
}

impl prism_rtl::Job<crate::check::types::Ty> for PlaceTy {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::Ty> {
        let lx_p0 = &self.lx_p0;
        let e_p1 = &self.e_p1;
        match crate::lower::type_at_f(lx_p0, &e_p1.span_p) {
            crate::check::types::Ty::TyErr => match &*e_p1.kind_p {
                crate::syntax::ExprKind::EIndex(r_p2, _) => {
                    let lx_p0x = lx_p0.clone();
                    let r_p2x = (**r_p2).clone();
                    crate::prelude::call_then(start_place_ty_f(lx_p0x.clone(), r_p2x.clone()), move |place_ty_f_18350: crate::check::types::Ty| match crate::lower::types::peel_f(&place_ty_f_18350) {
                        crate::check::types::Ty::TyArray(el_p3) => prism_rtl::Turn::Finished((*el_p3).clone()),
                        crate::check::types::Ty::TyMap(_, v_p4) => prism_rtl::Turn::Finished((*v_p4).clone()),
                        _ => prism_rtl::Turn::Finished(crate::check::types::Ty::TyErr),
                    })
                },
                crate::syntax::ExprKind::EField(r_p5, _, name_p6) => {
                    let lx_p0x = lx_p0.clone();
                    let name_p6x = name_p6.clone();
                    let r_p5x = (**r_p5).clone();
                    crate::prelude::call_then(start_place_ty_f(lx_p0x.clone(), r_p5x.clone()), move |place_ty_f_18504: crate::check::types::Ty| prism_rtl::Turn::More(Rc::new(FieldTy { lx_p0: lx_p0x.clone(), rty_p1: crate::lower::types::peel_f(&place_ty_f_18504), name_p2: name_p6x.name_p.clone() })))
                },
                crate::syntax::ExprKind::EGroup(x_p7) => prism_rtl::Turn::More(Rc::new(PlaceTy { lx_p0: lx_p0.clone(), e_p1: (**x_p7).clone() })),
                _ => prism_rtl::Turn::Finished(crate::check::types::Ty::TyErr),
            },
            t_p8 => prism_rtl::Turn::Finished(t_p8.clone()),
        }
    }
}

/// `Start PlaceTy, x`: what the function value is when passed to `@Run`.
pub fn start_place_ty_f(lx_p0: crate::lower::Lx, e_p1: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>> {
    Rc::new(PlaceTy { lx_p0, e_p1 })
}

/// ```prism
/// FieldTy: unbounded fn Lx, Ty, Text -> Ty
/// ```
pub fn field_ty_f(lx_p0: &crate::lower::Lx, rty_p1: &crate::check::types::Ty, name_p2: &Text) -> crate::check::types::Ty {
    match rty_p1 {
        crate::check::types::Ty::TyCon(n_p3, args_p4) => match crate::prelude::get(&lx_p0.g_p.ctors_p, n_p3) {
            Some(c_p5) => crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(&c_p5.fields_p)), crate::check::types::Ty::TyErr, {
                let c_p5x = c_p5.clone();
                let name_p2x = name_p2.clone();
                let args_p4x = args_p4.clone();
                Rc::new(move |(p0, p1): (crate::check::types::Ty, Nat)| {
                    let c_p5xy = c_p5x.clone();
                    let name_p2xy = name_p2x.clone();
                    let args_p4xy = args_p4x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let found_p6 = p0;
                        let i_p7 = p1;
                        if &crate::prelude::or(&crate::prelude::index(&c_p5xy.fields_p, &i_p7), &Text::lit("")) == &name_p2xy {
                            prism_rtl::Turn::More(Rc::new(crate::lower::expr::Instantiated { t_p0: crate::prelude::or(&crate::prelude::index(&c_p5xy.args_p, &i_p7), &crate::check::types::Ty::TyErr), params_p1: c_p5xy.params_p.clone(), args_p2: args_p4xy.clone() }))
                        } else {
                            prism_rtl::Turn::Finished(found_p6.clone())
                        }
                    }))
                }) as Rc<dyn Fn((crate::check::types::Ty, Nat)) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
            })),
            None => crate::check::types::Ty::TyErr,
        },
        _ => crate::check::types::Ty::TyErr,
    }
}

/// The step machine of `FieldTy`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FieldTy: unbounded fn Lx, Ty, Text -> Ty
/// ```
pub struct FieldTy {
    pub lx_p0: crate::lower::Lx,
    pub rty_p1: crate::check::types::Ty,
    pub name_p2: Text,
}

impl prism_rtl::Job<crate::check::types::Ty> for FieldTy {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::Ty> {
        let lx_p0 = &self.lx_p0;
        let rty_p1 = &self.rty_p1;
        let name_p2 = &self.name_p2;
        match rty_p1 {
            crate::check::types::Ty::TyCon(n_p3, args_p4) => match crate::prelude::get(&lx_p0.g_p.ctors_p, n_p3) {
                Some(c_p5) => crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(&c_p5.fields_p)), crate::check::types::Ty::TyErr, {
                    let c_p5x = c_p5.clone();
                    let name_p2x = name_p2.clone();
                    let args_p4x = args_p4.clone();
                    Rc::new(move |(p0, p1): (crate::check::types::Ty, Nat)| {
                        let c_p5xy = c_p5x.clone();
                        let name_p2xy = name_p2x.clone();
                        let args_p4xy = args_p4x.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let found_p6 = p0;
                            let i_p7 = p1;
                            if &crate::prelude::or(&crate::prelude::index(&c_p5xy.fields_p, &i_p7), &Text::lit("")) == &name_p2xy {
                                prism_rtl::Turn::More(Rc::new(crate::lower::expr::Instantiated { t_p0: crate::prelude::or(&crate::prelude::index(&c_p5xy.args_p, &i_p7), &crate::check::types::Ty::TyErr), params_p1: c_p5xy.params_p.clone(), args_p2: args_p4xy.clone() }))
                            } else {
                                prism_rtl::Turn::Finished(found_p6.clone())
                            }
                        }))
                    }) as Rc<dyn Fn((crate::check::types::Ty, Nat)) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
                }).cycle(),
                None => prism_rtl::Turn::Finished(crate::check::types::Ty::TyErr),
            },
            _ => prism_rtl::Turn::Finished(crate::check::types::Ty::TyErr),
        }
    }
}

/// `Start FieldTy, x`: what the function value is when passed to `@Run`.
pub fn start_field_ty_f(lx_p0: crate::lower::Lx, rty_p1: crate::check::types::Ty, name_p2: Text) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>> {
    Rc::new(FieldTy { lx_p0, rty_p1, name_p2 })
}

/// ```prism
/// Assign: unbounded fn Lx, Env, Expr, Ex -> Do
/// ```
pub fn assign_f(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, target_p2: &crate::syntax::Expr, v_p3: &crate::lower::model::Ex) -> crate::lower::model::Do {
    match &*target_p2.kind_p {
        crate::syntax::ExprKind::EIndex(r_p4, k_p5) => {
            let rt_p6 = crate::lower::types::out_ty_of_f(lx_p0, &crate::lower::types::peel_f(&place_ty_f(lx_p0, &**r_p4)));
            let f_p7 = match &rt_p6 {
                crate::lower::model::OutTy::OutMap(_, _) => Text::lit("set_key"),
                _ => Text::lit("set_index"),
            };
            crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XCall(f_p7.clone(), Array::from(vec![crate::lower::model::Ex::XRefMut(Rc::new(place_of_f(lx_p0, env_p1, &**r_p4))), crate::lower::expr::argument_f(lx_p0, env_p1, &**k_p5), v_p3.clone()])))
        },
        crate::syntax::ExprKind::EGroup(x_p8) => assign_f(lx_p0, env_p1, &**x_p8, v_p3),
        _ => crate::lower::model::Do::DoAssign(place_of_f(lx_p0, env_p1, target_p2), v_p3.clone()),
    }
}

/// The step machine of `Assign`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Assign: unbounded fn Lx, Env, Expr, Ex -> Do
/// ```
pub struct Assign {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub target_p2: crate::syntax::Expr,
    pub v_p3: crate::lower::model::Ex,
}

impl prism_rtl::Job<crate::lower::model::Do> for Assign {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::Do> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let target_p2 = &self.target_p2;
        let v_p3 = &self.v_p3;
        match &*target_p2.kind_p {
            crate::syntax::ExprKind::EIndex(r_p4, k_p5) => {
                let env_p1x = env_p1.clone();
                let k_p5x = (**k_p5).clone();
                let lx_p0x = lx_p0.clone();
                let r_p4x = (**r_p4).clone();
                let v_p3x = v_p3.clone();
                crate::prelude::call_then(start_place_ty_f(lx_p0x.clone(), r_p4x.clone()), move |place_ty_f_19214: crate::check::types::Ty| crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0x.clone(), crate::lower::types::peel_f(&place_ty_f_19214)), move |out_ty_of_f_19195: crate::lower::model::OutTy| {
                    let rt_p6 = out_ty_of_f_19195;
                    let f_p7 = match &rt_p6 {
                        crate::lower::model::OutTy::OutMap(_, _) => Text::lit("set_key"),
                        _ => Text::lit("set_index"),
                    };
                    crate::prelude::call_then(start_place_of_f(lx_p0x.clone(), env_p1x.clone(), r_p4x.clone()), move |place_of_f_19373: crate::lower::model::Ex| crate::prelude::call_then(crate::lower::expr::start_argument_f(lx_p0x.clone(), env_p1x.clone(), k_p5x.clone()), move |argument_f_19396: crate::lower::model::Ex| prism_rtl::Turn::Finished(crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XCall(f_p7.clone(), Array::from(vec![crate::lower::model::Ex::XRefMut(Rc::new(place_of_f_19373)), argument_f_19396, v_p3x.clone()]))))))
                }))
            },
            crate::syntax::ExprKind::EGroup(x_p8) => prism_rtl::Turn::More(Rc::new(Assign { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), target_p2: (**x_p8).clone(), v_p3: v_p3.clone() })),
            _ => {
                let env_p1x = env_p1.clone();
                let lx_p0x = lx_p0.clone();
                let target_p2x = target_p2.clone();
                let v_p3x = v_p3.clone();
                crate::prelude::call_then(start_place_of_f(lx_p0x.clone(), env_p1x.clone(), target_p2x.clone()), move |place_of_f_19483: crate::lower::model::Ex| prism_rtl::Turn::Finished(crate::lower::model::Do::DoAssign(place_of_f_19483, v_p3x.clone())))
            },
        }
    }
}

/// `Start Assign, x`: what the function value is when passed to `@Run`.
pub fn start_assign_f(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, target_p2: crate::syntax::Expr, v_p3: crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<crate::lower::model::Do>> {
    Rc::new(Assign { lx_p0, env_p1, target_p2, v_p3 })
}
