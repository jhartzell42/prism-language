//! The module `Lower.Templates`, from `target/bootstrap/src/prismc/lower/templates.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file. The runtime
//! side is reached from the crate, `crate::prelude` (and through it `::prism_rtl`), the
//! standard library from `::std`, and nothing is imported by name: a program's own type
//! (`Row`, `Option`) hides none of theirs. The traits are in scope unnamed, for their methods.

use crate::prelude::traits::*;

/// ```prism
/// TemplateValue: unbounded fn Lx, Env, Template -> Vl
/// ```
pub fn template_value_f(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, tp_p2: &crate::syntax::Template) -> crate::lower::types::Vl {
    let start_p3 = crate::prelude::Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaMut(crate::prelude::Text::lit("out")), crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::String::new")), crate::prelude::Array::new()))]);
    let dos_p4 = crate::prelude::run_to_end(crate::prelude::fold_job(tp_p2.parts_p.clone(), start_p3.clone(), {
        let lx_p0x = lx_p0.clone();
        let env_p1x = env_p1.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::lower::model::Do>, crate::syntax::TemplatePart)| {
            let lx_p0xy = lx_p0x.clone();
            let env_p1xy = env_p1x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_p5 = p0;
                let part_p6 = p1;
                crate::prelude::call_then(start_template_part_dos_f(lx_p0xy.clone(), env_p1xy.clone(), part_p6.clone()), move |template_part_dos_f_1619: crate::prelude::Array<crate::lower::model::Do>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_p5, &template_part_dos_f_1619)))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::lower::model::Do>, crate::syntax::TemplatePart)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::lower::model::Do>>>>
    }));
    crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XBlock(dos_p4.clone(), ::std::rc::Rc::new(crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Text::from")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XVar(crate::prelude::Text::lit("out"))])))), crate::lower::model::OutTy::OutText)
}

/// The step machine of `TemplateValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TemplateValue: unbounded fn Lx, Env, Template -> Vl
/// ```
pub struct TemplateValue {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub tp_p2: crate::syntax::Template,
}

impl ::prism_rtl::Job<crate::lower::types::Vl> for TemplateValue {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::lower::types::Vl> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let tp_p2 = &self.tp_p2;
        let start_p3 = crate::prelude::Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaMut(crate::prelude::Text::lit("out")), crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::String::new")), crate::prelude::Array::new()))]);
        let env_p1x = env_p1.clone();
        let lx_p0x = lx_p0.clone();
        let tp_p2x = tp_p2.clone();
        crate::prelude::call_value(crate::prelude::fold_job(tp_p2x.parts_p.clone(), start_p3.clone(), {
            let lx_p0xx = lx_p0x.clone();
            let env_p1xx = env_p1x.clone();
            ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::lower::model::Do>, crate::syntax::TemplatePart)| {
                let lx_p0xxy = lx_p0xx.clone();
                let env_p1xxy = env_p1xx.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let acc_p5 = p0;
                    let part_p6 = p1;
                    crate::prelude::call_then(start_template_part_dos_f(lx_p0xxy.clone(), env_p1xxy.clone(), part_p6.clone()), move |template_part_dos_f_1619: crate::prelude::Array<crate::lower::model::Do>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_p5, &template_part_dos_f_1619)))
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::lower::model::Do>, crate::syntax::TemplatePart)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::lower::model::Do>>>>
        }), move |fold_1571: crate::prelude::Array<crate::lower::model::Do>| {
            let dos_p4 = fold_1571;
            ::prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XBlock(dos_p4.clone(), ::std::rc::Rc::new(crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Text::from")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XVar(crate::prelude::Text::lit("out"))])))), crate::lower::model::OutTy::OutText))
        })
    }
}

/// `Start TemplateValue, x`: what the function value is when passed to `@Run`.
pub fn start_template_value_f(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, tp_p2: crate::syntax::Template) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::types::Vl>> {
    ::std::rc::Rc::new(TemplateValue { lx_p0, env_p1, tp_p2 })
}

/// ```prism
/// TemplatePartDos: unbounded fn Lx, Env, TemplatePart -> [Do]
/// ```
pub fn template_part_dos_f(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, part_p2: &crate::syntax::TemplatePart) -> crate::prelude::Array<crate::lower::model::Do> {
    match part_p2 {
        crate::syntax::TemplatePart::TpText(t_p3) => crate::prelude::Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("out"))), crate::prelude::Text::lit("push_str"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XStr(t_p3.clone())])))]),
        crate::syntax::TemplatePart::TpPlaceholder(x_p4, col_o5) => {
            let v_p6 = crate::lower::expr::value_of_f(lx_p0, env_p1, x_p4);
            let column_p7 = match col_o5 {
                ::std::option::Option::Some(c_p8) => crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Some")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XIndex(c_p8.clone())])),
                ::std::option::Option::None => crate::lower::model::Ex::XNone,
            };
            crate::prelude::Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XCall(crate::lower::helper_ref_f(&crate::prelude::Text::lit("place")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XRefMut(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("out")))), shown_text_f(&v_p6), column_p7.clone()])))])
        },
        crate::syntax::TemplatePart::TpBlock(b_p9) => {
            let v_pa = crate::lower::expr::block_value_f(lx_p0, env_p1, b_p9);
            if &crate::lower::types::value_ty_f(&v_pa) == &crate::lower::model::OutTy::OutUnit {
                crate::prelude::Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::types::own_f(&v_pa))])
            } else {
                crate::prelude::Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XCall(crate::lower::helper_ref_f(&crate::prelude::Text::lit("place")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XRefMut(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("out")))), shown_text_f(&v_pa), crate::lower::model::Ex::XNone])))])
            }
        },
        crate::syntax::TemplatePart::TpCall(n_pb, args_pc, parts_od, _) => {
            let plain_pe = crate::syntax::SName { sigils_p: crate::syntax::lexer::chars::after_first_f(&n_pb.sigils_p), path_p: n_pb.path_p.clone(), span_p: n_pb.span_p.clone() };
            let (qk_oj, _) = crate::check::env::names::resolve_value_f(&lx_p0.g_p, &lx_p0.home_p, n_pb);
            let (qk2_ok, _) = crate::check::env::names::resolve_value_f(&lx_p0.g_p, &lx_p0.home_p, &plain_pe);
            let callee_of = match &qk_oj {
                ::std::option::Option::Some(q_pl) => ::std::option::Option::Some(crate::lower::value_ref_f(lx_p0, q_pl)),
                ::std::option::Option::None => match &qk2_ok {
                    ::std::option::Option::Some(q_pm) => ::std::option::Option::Some(crate::lower::value_ref_f(lx_p0, q_pm)),
                    ::std::option::Option::None => ::std::option::Option::None,
                },
            };
            let body_pg = match parts_od {
                ::std::option::Option::Some(ps_pn) => {
                    let inner_po = crate::prelude::run_to_end(crate::prelude::fold_job(ps_pn.clone(), crate::prelude::Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaMut(crate::prelude::Text::lit("out")), crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::String::new")), crate::prelude::Array::new()))]), {
                        let lx_p0x = lx_p0.clone();
                        let env_p1x = env_p1.clone();
                        ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::lower::model::Do>, crate::syntax::TemplatePart)| {
                            let lx_p0xy = lx_p0x.clone();
                            let env_p1xy = env_p1x.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let acc_pp = p0;
                                let p_pq = p1;
                                crate::prelude::call_then(start_template_part_dos_f(lx_p0xy.clone(), env_p1xy.clone(), p_pq.clone()), move |template_part_dos_f_2998: crate::prelude::Array<crate::lower::model::Do>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_pp, &template_part_dos_f_2998)))
                            }))
                        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::lower::model::Do>, crate::syntax::TemplatePart)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::lower::model::Do>>>>
                    }));
                    crate::prelude::Array::from(vec![crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XBlock(inner_po.clone(), ::std::rc::Rc::new(crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Text::from")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XVar(crate::prelude::Text::lit("out"))]))))))])
                },
                ::std::option::Option::None => crate::prelude::Array::new(),
            };
            let passed_ph = match &qk_oj {
                ::std::option::Option::Some(q_pr) => template_args_f(lx_p0, env_p1, q_pr, args_pc, &body_pg),
                ::std::option::Option::None => match &qk2_ok {
                    ::std::option::Option::Some(q_ps) => template_args_f(lx_p0, env_p1, q_ps, args_pc, &body_pg),
                    ::std::option::Option::None => crate::prelude::append(&crate::prelude::run_to_end(crate::prelude::each_job(args_pc.clone(), {
                        let lx_p0x = lx_p0.clone();
                        let env_p1x = env_p1.clone();
                        ::std::rc::Rc::new(move |p0: crate::syntax::Arg| {
                            let lx_p0xy = lx_p0x.clone();
                            let env_p1xy = env_p1x.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let a_pt = p0;
                                ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::lower::expr::Argument { lx_p0: lx_p0xy.clone(), env_p1: env_p1xy.clone(), e_p2: a_pt.value_p.clone() }))
                            }))
                        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::syntax::Arg) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>>>
                    })), &body_pg),
                },
            };
            let call_pi = match &callee_of {
                ::std::option::Option::Some(c_pu) => crate::lower::model::Ex::XCall(c_pu.clone(), passed_ph.clone()),
                ::std::option::Option::None => crate::lower::expr::internal_bug_f(&crate::prelude::Text::from(format!("a template call of `{}`, which names no function", &crate::check::env::sname_key_f(n_pb)))),
            };
            crate::prelude::Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XCall(crate::lower::helper_ref_f(&crate::prelude::Text::lit("place")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XRefMut(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("out")))), crate::lower::model::Ex::XRef(::std::rc::Rc::new(call_pi.clone())), crate::lower::model::Ex::XNone])))])
        },
    }
}

/// The step machine of `TemplatePartDos`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TemplatePartDos: unbounded fn Lx, Env, TemplatePart -> [Do]
/// ```
pub struct TemplatePartDos {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub part_p2: crate::syntax::TemplatePart,
}

impl ::prism_rtl::Job<crate::prelude::Array<crate::lower::model::Do>> for TemplatePartDos {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<crate::lower::model::Do>> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let part_p2 = &self.part_p2;
        match part_p2 {
            crate::syntax::TemplatePart::TpText(t_p3) => ::prism_rtl::Turn::Finished(crate::prelude::Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("out"))), crate::prelude::Text::lit("push_str"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XStr(t_p3.clone())])))])),
            crate::syntax::TemplatePart::TpPlaceholder(x_p4, col_o5) => {
                let col_o5x = col_o5.clone();
                let env_p1x = env_p1.clone();
                let lx_p0x = lx_p0.clone();
                let x_p4x = x_p4.clone();
                crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p0x.clone(), env_p1x.clone(), x_p4x.clone()), move |value_of_f_1966: crate::lower::types::Vl| {
                    let v_p6 = value_of_f_1966;
                    let column_p7 = match &col_o5x {
                        ::std::option::Option::Some(c_p8) => crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Some")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XIndex(c_p8.clone())])),
                        ::std::option::Option::None => crate::lower::model::Ex::XNone,
                    };
                    ::prism_rtl::Turn::Finished(crate::prelude::Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XCall(crate::lower::helper_ref_f(&crate::prelude::Text::lit("place")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XRefMut(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("out")))), shown_text_f(&v_p6), column_p7.clone()])))]))
                })
            },
            crate::syntax::TemplatePart::TpBlock(b_p9) => {
                let b_p9x = b_p9.clone();
                let env_p1x = env_p1.clone();
                let lx_p0x = lx_p0.clone();
                crate::prelude::call_then(crate::lower::expr::start_block_value_f(lx_p0x.clone(), env_p1x.clone(), b_p9x.clone()), move |block_value_f_2230: crate::lower::types::Vl| {
                    let v_pa = block_value_f_2230;
                    if &crate::lower::types::value_ty_f(&v_pa) == &crate::lower::model::OutTy::OutUnit {
                        ::prism_rtl::Turn::Finished(crate::prelude::Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::types::own_f(&v_pa))]))
                    } else {
                        ::prism_rtl::Turn::Finished(crate::prelude::Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XCall(crate::lower::helper_ref_f(&crate::prelude::Text::lit("place")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XRefMut(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("out")))), shown_text_f(&v_pa), crate::lower::model::Ex::XNone])))]))
                    }
                })
            },
            crate::syntax::TemplatePart::TpCall(n_pb, args_pc, parts_od, _) => {
                let plain_pe = crate::syntax::SName { sigils_p: crate::syntax::lexer::chars::after_first_f(&n_pb.sigils_p), path_p: n_pb.path_p.clone(), span_p: n_pb.span_p.clone() };
                let (qk_oj, _) = crate::check::env::names::resolve_value_f(&lx_p0.g_p, &lx_p0.home_p, n_pb);
                let (qk2_ok, _) = crate::check::env::names::resolve_value_f(&lx_p0.g_p, &lx_p0.home_p, &plain_pe);
                let callee_of = match &qk_oj {
                    ::std::option::Option::Some(q_pl) => ::std::option::Option::Some(crate::lower::value_ref_f(lx_p0, q_pl)),
                    ::std::option::Option::None => match &qk2_ok {
                        ::std::option::Option::Some(q_pm) => ::std::option::Option::Some(crate::lower::value_ref_f(lx_p0, q_pm)),
                        ::std::option::Option::None => ::std::option::Option::None,
                    },
                };
                let callee_ofz = callee_of.clone();
                let qk_ojz = qk_oj.clone();
                let qk2_okz = qk2_ok.clone();
                let args_pcz = args_pc.clone();
                let env_p1z = env_p1.clone();
                let lx_p0z = lx_p0.clone();
                let n_pbz = n_pb.clone();
                let k_let2821 = move |v2821: crate::prelude::Array<crate::lower::model::Ex>| {
                    let body_pg = v2821;
                    let callee_ofzz = callee_ofz.clone();
                    let n_pbzz = n_pbz.clone();
                    let k_let3155 = move |v3155: crate::prelude::Array<crate::lower::model::Ex>| {
                        let passed_ph = v3155;
                        let call_pi = match &callee_ofzz {
                            ::std::option::Option::Some(c_pu) => crate::lower::model::Ex::XCall(c_pu.clone(), passed_ph.clone()),
                            ::std::option::Option::None => crate::lower::expr::internal_bug_f(&crate::prelude::Text::from(format!("a template call of `{}`, which names no function", &crate::check::env::sname_key_f(&n_pbzz)))),
                        };
                        ::prism_rtl::Turn::Finished(crate::prelude::Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XCall(crate::lower::helper_ref_f(&crate::prelude::Text::lit("place")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XRefMut(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("out")))), crate::lower::model::Ex::XRef(::std::rc::Rc::new(call_pi.clone())), crate::lower::model::Ex::XNone])))]))
                    };
                    match qk_ojz.clone() {
                        ::std::option::Option::Some(q_pr) => crate::prelude::call_then(start_template_args_f(lx_p0z.clone(), env_p1z.clone(), q_pr.clone(), args_pcz.clone(), body_pg.clone()), move |template_args_f_3196: crate::prelude::Array<crate::lower::model::Ex>| k_let3155(template_args_f_3196)),
                        ::std::option::Option::None => match qk2_okz.clone() {
                            ::std::option::Option::Some(q_ps) => crate::prelude::call_then(start_template_args_f(lx_p0z.clone(), env_p1z.clone(), q_ps.clone(), args_pcz.clone(), body_pg.clone()), move |template_args_f_3282: crate::prelude::Array<crate::lower::model::Ex>| k_let3155(template_args_f_3282)),
                            ::std::option::Option::None => crate::prelude::call_value(crate::prelude::each_job(args_pcz.clone(), {
                                let lx_p0zx = lx_p0z.clone();
                                let env_p1zx = env_p1z.clone();
                                ::std::rc::Rc::new(move |p0: crate::syntax::Arg| {
                                    let lx_p0zxy = lx_p0zx.clone();
                                    let env_p1zxy = env_p1zx.clone();
                                    crate::prelude::entered(crate::prelude::once_job(move || {
                                        let a_pt = p0;
                                        ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::lower::expr::Argument { lx_p0: lx_p0zxy.clone(), env_p1: env_p1zxy.clone(), e_p2: a_pt.value_p.clone() }))
                                    }))
                                }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::syntax::Arg) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>>>
                            }), move |each_3347: crate::prelude::Array<crate::lower::model::Ex>| k_let3155(crate::prelude::append(&each_3347, &body_pg))),
                        },
                    }
                };
                match parts_od.clone() {
                    ::std::option::Option::Some(ps_pn) => {
                        let env_p1x = env_p1.clone();
                        let lx_p0x = lx_p0.clone();
                        crate::prelude::call_value(crate::prelude::fold_job(ps_pn.clone(), crate::prelude::Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaMut(crate::prelude::Text::lit("out")), crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::String::new")), crate::prelude::Array::new()))]), {
                            let lx_p0xx = lx_p0x.clone();
                            let env_p1xx = env_p1x.clone();
                            ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::lower::model::Do>, crate::syntax::TemplatePart)| {
                                let lx_p0xxy = lx_p0xx.clone();
                                let env_p1xxy = env_p1xx.clone();
                                crate::prelude::entered(crate::prelude::once_job(move || {
                                    let acc_pp = p0;
                                    let p_pq = p1;
                                    crate::prelude::call_then(start_template_part_dos_f(lx_p0xxy.clone(), env_p1xxy.clone(), p_pq.clone()), move |template_part_dos_f_2998: crate::prelude::Array<crate::lower::model::Do>| ::prism_rtl::Turn::Finished(crate::prelude::append(&acc_pp, &template_part_dos_f_2998)))
                                }))
                            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::lower::model::Do>, crate::syntax::TemplatePart)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::lower::model::Do>>>>
                        }), move |fold_2892: crate::prelude::Array<crate::lower::model::Do>| {
                            let inner_po = fold_2892;
                            k_let2821(crate::prelude::Array::from(vec![crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XBlock(inner_po.clone(), ::std::rc::Rc::new(crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Text::from")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XVar(crate::prelude::Text::lit("out"))]))))))]))
                        })
                    },
                    ::std::option::Option::None => k_let2821(crate::prelude::Array::new()),
                }
            },
        }
    }
}

/// `Start TemplatePartDos, x`: what the function value is when passed to `@Run`.
pub fn start_template_part_dos_f(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, part_p2: crate::syntax::TemplatePart) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::lower::model::Do>>> {
    ::std::rc::Rc::new(TemplatePartDos { lx_p0, env_p1, part_p2 })
}

/// ```prism
/// TemplateArgs: unbounded fn Lx, Env, Text, [Arg], [Ex] -> [Ex]
/// ```
pub fn template_args_f(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, qk_p2: &crate::prelude::Text, args_p3: &crate::prelude::Array<crate::syntax::Arg>, body_p4: &crate::prelude::Array<crate::lower::model::Ex>) -> crate::prelude::Array<crate::lower::model::Ex> {
    let clauses_p5 = crate::lower::jobs::clauses_of_f(&lx_p0.g_p, qk_p2);
    let arity_p6 = crate::prelude::len(&crate::prelude::or(&crate::prelude::index(&clauses_p5, &crate::prelude::Nat::from(0u32)), &crate::lower::functions::dummy_clause_p()).params_p);
    crate::prelude::run_to_end(crate::prelude::each_job(crate::check::errors::range0_f(&arity_p6), {
        let body_p4x = body_p4.clone();
        let arity_p6x = arity_p6.clone();
        let clauses_p5x = clauses_p5.clone();
        let args_p3x = args_p3.clone();
        let lx_p0x = lx_p0.clone();
        let env_p1x = env_p1.clone();
        ::std::rc::Rc::new(move |p0: crate::prelude::Nat| {
            let body_p4xy = body_p4x.clone();
            let arity_p6xy = arity_p6x.clone();
            let clauses_p5xy = clauses_p5x.clone();
            let args_p3xy = args_p3x.clone();
            let lx_p0xy = lx_p0x.clone();
            let env_p1xy = env_p1x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let j_p7 = p0;
                if (&crate::prelude::len(&body_p4xy) > &crate::prelude::Nat::from(0u32)) && (&(&j_p7 + &crate::prelude::Nat::from(1u32)) == &arity_p6xy) {
                    ::prism_rtl::Turn::Finished(crate::prelude::or(&crate::prelude::index(&body_p4xy, &crate::prelude::Nat::from(0u32)), &crate::lower::model::Ex::XUnit))
                } else {
                    match attr_at_o(&clauses_p5xy, &j_p7, &args_p3xy) {
                        ::std::option::Option::Some(a_p8) => ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::lower::expr::Argument { lx_p0: lx_p0xy.clone(), env_p1: env_p1xy.clone(), e_p2: a_p8.value_p.clone() })),
                        ::std::option::Option::None => ::prism_rtl::Turn::Finished(crate::lower::expr::internal_bug_f(&crate::prelude::Text::from(format!("a template call that fills no argument at place {}", &j_p7)))),
                    }
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>>>
    }))
}

/// The step machine of `TemplateArgs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TemplateArgs: unbounded fn Lx, Env, Text, [Arg], [Ex] -> [Ex]
/// ```
pub struct TemplateArgs {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub qk_p2: crate::prelude::Text,
    pub args_p3: crate::prelude::Array<crate::syntax::Arg>,
    pub body_p4: crate::prelude::Array<crate::lower::model::Ex>,
}

impl ::prism_rtl::Job<crate::prelude::Array<crate::lower::model::Ex>> for TemplateArgs {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<crate::lower::model::Ex>> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let qk_p2 = &self.qk_p2;
        let args_p3 = &self.args_p3;
        let body_p4 = &self.body_p4;
        let clauses_p5 = crate::lower::jobs::clauses_of_f(&lx_p0.g_p, qk_p2);
        let arity_p6 = crate::prelude::len(&crate::prelude::or(&crate::prelude::index(&clauses_p5, &crate::prelude::Nat::from(0u32)), &crate::lower::functions::dummy_clause_p()).params_p);
        crate::prelude::each_job(crate::check::errors::range0_f(&arity_p6), {
            let body_p4x = body_p4.clone();
            let arity_p6x = arity_p6.clone();
            let clauses_p5x = clauses_p5.clone();
            let args_p3x = args_p3.clone();
            let lx_p0x = lx_p0.clone();
            let env_p1x = env_p1.clone();
            ::std::rc::Rc::new(move |p0: crate::prelude::Nat| {
                let body_p4xy = body_p4x.clone();
                let arity_p6xy = arity_p6x.clone();
                let clauses_p5xy = clauses_p5x.clone();
                let args_p3xy = args_p3x.clone();
                let lx_p0xy = lx_p0x.clone();
                let env_p1xy = env_p1x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let j_p7 = p0;
                    if (&crate::prelude::len(&body_p4xy) > &crate::prelude::Nat::from(0u32)) && (&(&j_p7 + &crate::prelude::Nat::from(1u32)) == &arity_p6xy) {
                        ::prism_rtl::Turn::Finished(crate::prelude::or(&crate::prelude::index(&body_p4xy, &crate::prelude::Nat::from(0u32)), &crate::lower::model::Ex::XUnit))
                    } else {
                        match attr_at_o(&clauses_p5xy, &j_p7, &args_p3xy) {
                            ::std::option::Option::Some(a_p8) => ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::lower::expr::Argument { lx_p0: lx_p0xy.clone(), env_p1: env_p1xy.clone(), e_p2: a_p8.value_p.clone() })),
                            ::std::option::Option::None => ::prism_rtl::Turn::Finished(crate::lower::expr::internal_bug_f(&crate::prelude::Text::from(format!("a template call that fills no argument at place {}", &j_p7)))),
                        }
                    }
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>>>
        }).cycle()
    }
}

/// `Start TemplateArgs, x`: what the function value is when passed to `@Run`.
pub fn start_template_args_f(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, qk_p2: crate::prelude::Text, args_p3: crate::prelude::Array<crate::syntax::Arg>, body_p4: crate::prelude::Array<crate::lower::model::Ex>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::lower::model::Ex>>> {
    ::std::rc::Rc::new(TemplateArgs { lx_p0, env_p1, qk_p2, args_p3, body_p4 })
}

/// ```prism
/// ?AttrAt: fn [FnClause], Nat, [Arg] -> ?Arg
/// ```
pub fn attr_at_o(clauses_p0: &crate::prelude::Array<crate::syntax::decls::FnClause>, j_p1: &crate::prelude::Nat, args_p2: &crate::prelude::Array<crate::syntax::Arg>) -> ::std::option::Option<crate::syntax::Arg> {
    let names_p7 = crate::prelude::fold(clauses_p0, &crate::prelude::Array::new(), &(|acc_p3: &crate::prelude::Array<crate::prelude::Text>, c_p4: &crate::syntax::decls::FnClause| match crate::prelude::index(&c_p4.params_p, j_p1) {
        ::std::option::Option::Some(p_p5) => match place_name_o(&p_p5) {
            ::std::option::Option::Some(n_p6) => crate::check::types::add_text_f(acc_p3, &n_p6),
            ::std::option::Option::None => acc_p3.clone(),
        },
        ::std::option::Option::None => acc_p3.clone(),
    }));
    crate::prelude::fold(args_p2, &::std::option::Option::None, &(|found_o8: &::std::option::Option<crate::syntax::Arg>, a_p9: &crate::syntax::Arg| match &a_p9.name_o {
        ::std::option::Option::Some(n_pa) => if crate::check::types::has_text_f(&names_p7, &n_pa.name_p) {
            ::std::option::Option::Some(a_p9.clone())
        } else {
            found_o8.clone()
        },
        ::std::option::Option::None => found_o8.clone(),
    }))
}

/// ```prism
/// ?PlaceName: fn Pattern -> ?Text
/// ```
pub fn place_name_o(p_p0: &crate::syntax::Pattern) -> ::std::option::Option<crate::prelude::Text> {
    match &*p_p0.kind_p {
        crate::syntax::PatternKind::PName(n_p1) => ::std::option::Option::Some(crate::check::env::dotted_f(&n_p1.path_p)),
        crate::syntax::PatternKind::PGroup(q_p2) => place_name_o(&**q_p2),
        _ => ::std::option::Option::None,
    }
}

/// ```prism
/// ShownText: fn Vl -> Ex
/// ```
pub fn shown_text_f(v_p0: &crate::lower::types::Vl) -> crate::lower::model::Ex {
    match crate::lower::types::value_ty_f(v_p0) {
        crate::lower::model::OutTy::OutText => crate::lower::types::ref_f(v_p0),
        crate::lower::model::OutTy::OutChar => crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XFormat(crate::prelude::Array::from(vec![crate::lower::types::ref_f(v_p0)])))),
        _ => crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XCall(crate::lower::helper_ref_f(&crate::prelude::Text::lit("show_text")), crate::prelude::Array::from(vec![crate::lower::types::ref_f(v_p0)])))),
    }
}

/// ```prism
/// GivenValue: unbounded fn Lx, Env, Block, OutTy, Range -> Vl
/// ```
pub fn given_value_f(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, b_p2: &crate::syntax::Block, t_p3: &crate::lower::model::OutTy, span_p4: &crate::syntax::Range) -> crate::lower::types::Vl {
    let label_p5 = crate::prelude::Text::from(format!("\'g{}", &span_p4.start_p));
    let is_try_p6 = match t_p3 {
        crate::lower::model::OutTy::OutRes(_) => true,
        _ => false,
    };
    let n_p7 = crate::prelude::len(&b_p2.stmts_p);
    let (dos_po, env2_pp, last_oq) = crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(&n_p7), (crate::prelude::Array::new(), env_p1.clone(), ::std::option::Option::None), {
        let b_p2x = b_p2.clone();
        let is_try_p6x = is_try_p6;
        let lx_p0x = lx_p0.clone();
        let label_p5x = label_p5.clone();
        let n_p7x = n_p7.clone();
        ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Array<crate::lower::model::Do>, crate::lower::types::Env, ::std::option::Option<crate::lower::types::Vl>), crate::prelude::Nat)| {
            let b_p2xy = b_p2x.clone();
            let is_try_p6xy = is_try_p6x;
            let lx_p0xy = lx_p0x.clone();
            let label_p5xy = label_p5x.clone();
            let n_p7xy = n_p7x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (acc_p9, en_pa, lv_ob) = p0;
                let i_pc = p1;
                {
                    let s_pd = crate::prelude::or(&crate::prelude::index(&b_p2xy.stmts_p, &i_pc), &crate::lower::expr::dummy_stmt_l_p());
                    let fail_pe = if is_try_p6xy {
                        crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Err")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Error::new")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XStr(crate::prelude::Text::lit("Prelude.Unmet")), crate::lower::model::Ex::XStr(source_text_f(&lx_p0xy, &s_pd.span_p))]))]))
                    } else {
                        crate::lower::model::Ex::XNone
                    };
                    match &s_pd.kind_p {
                        crate::syntax::StmtKind::SBind(p_pf, x_pg, ::std::option::Option::None) => {
                            let p_pfx = p_pf.clone();
                            let x_pgx = x_pg.clone();
                            crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p0xy.clone(), en_pa.clone(), x_pgx.clone()), move |value_of_f_6224: crate::lower::types::Vl| {
                                let v_ph = value_of_f_6224;
                                crate::prelude::call_then(crate::lower::patterns::start_rust_pat_f(lx_p0xy.clone(), p_pfx.clone(), crate::lower::patterns::inner_ty_f(&crate::lower::type_at_f(&lx_p0xy, &x_pgx.span_p)), crate::lower::types::Holding::Owned, crate::prelude::Text::from(format!("g{}", &s_pd.span_p.start_p))), move |rust_pat_f_6267: crate::lower::patterns::PatOut| {
                                    let po_pi = rust_pat_f_6267;
                                    crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0xy.clone(), crate::lower::patterns::inner_ty_f(&crate::lower::type_at_f(&lx_p0xy, &x_pgx.span_p))), move |out_ty_of_f_6409: crate::lower::model::OutTy| ::prism_rtl::Turn::Finished((crate::prelude::push(&acc_p9, &given_bind_f(&is_try_p6xy, &po_pi.pa_p, &crate::lower::types::own_f(&v_ph), &label_p5xy, &out_ty_of_f_6409)), crate::lower::expr::bind_all_f(&en_pa, &po_pi.binds_p), lv_ob.clone())))
                                })
                            })
                        },
                        crate::syntax::StmtKind::SRequire(c_pj) => {
                            let c_pjx = c_pj.clone();
                            crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p0xy.clone(), en_pa.clone(), c_pjx.clone()), move |value_of_f_6552: crate::lower::types::Vl| ::prism_rtl::Turn::Finished((crate::prelude::push(&acc_p9, &crate::lower::model::Do::DoIf(crate::lower::model::Ex::XUnary(crate::lower::model::UnOp::OpNot, ::std::rc::Rc::new(crate::lower::types::as_bool_f(&value_of_f_6552))), crate::prelude::Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XBreak(label_p5xy.clone(), ::std::rc::Rc::new(fail_pe.clone())))]), crate::prelude::Array::new())), en_pa.clone(), lv_ob.clone())))
                        },
                        crate::syntax::StmtKind::SForbid(c_pk) => {
                            let c_pkx = c_pk.clone();
                            crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p0xy.clone(), en_pa.clone(), c_pkx.clone()), move |value_of_f_6676: crate::lower::types::Vl| ::prism_rtl::Turn::Finished((crate::prelude::push(&acc_p9, &crate::lower::model::Do::DoIf(crate::lower::types::as_bool_f(&value_of_f_6676), crate::prelude::Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XBreak(label_p5xy.clone(), ::std::rc::Rc::new(fail_pe.clone())))]), crate::prelude::Array::new())), en_pa.clone(), lv_ob.clone())))
                        },
                        crate::syntax::StmtKind::SExpr(x_pl) => if &(&i_pc + &crate::prelude::Nat::from(1u32)) == &n_p7xy {
                            ::prism_rtl::Turn::Finished((acc_p9.clone(), en_pa.clone(), ::std::option::Option::Some(crate::lower::expr::value_of_f(&lx_p0xy, &en_pa, x_pl))))
                        } else {
                            {
                                let x_plx = x_pl.clone();
                                crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p0xy.clone(), en_pa.clone(), x_plx.clone()), move |value_of_f_6884: crate::lower::types::Vl| ::prism_rtl::Turn::Finished((crate::prelude::push(&acc_p9, &crate::lower::model::Do::DoExpr(crate::lower::types::own_f(&value_of_f_6884))), en_pa.clone(), lv_ob.clone())))
                            }
                        },
                        _ => crate::prelude::call_then(crate::lower::expr::start_block_stmt_f(lx_p0xy.clone(), en_pa.clone(), s_pd.clone()), move |block_stmt_f_6976: (crate::prelude::Array<crate::lower::model::Do>, crate::lower::types::Env)| {
                            let (more_pm, en2_pn) = block_stmt_f_6976;
                            ::prism_rtl::Turn::Finished((crate::prelude::append(&acc_p9, &more_pm), en2_pn.clone(), lv_ob.clone()))
                        }),
                    }
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Array<crate::lower::model::Do>, crate::lower::types::Env, ::std::option::Option<crate::lower::types::Vl>), crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<crate::lower::model::Do>, crate::lower::types::Env, ::std::option::Option<crate::lower::types::Vl>)>>>
    }));
    let last_p8 = crate::prelude::or(&last_oq, &crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XNone, t_p3.clone()));
    crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XLabeled(label_p5.clone(), dos_po.clone(), ::std::rc::Rc::new(crate::lower::types::own_f(&last_p8)), t_p3.clone()), t_p3.clone())
}

/// The step machine of `GivenValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// GivenValue: unbounded fn Lx, Env, Block, OutTy, Range -> Vl
/// ```
pub struct GivenValue {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub b_p2: crate::syntax::Block,
    pub t_p3: crate::lower::model::OutTy,
    pub span_p4: crate::syntax::Range,
}

impl ::prism_rtl::Job<crate::lower::types::Vl> for GivenValue {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::lower::types::Vl> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let b_p2 = &self.b_p2;
        let t_p3 = &self.t_p3;
        let span_p4 = &self.span_p4;
        let label_p5 = crate::prelude::Text::from(format!("\'g{}", &span_p4.start_p));
        let is_try_p6 = match t_p3 {
            crate::lower::model::OutTy::OutRes(_) => true,
            _ => false,
        };
        let n_p7 = crate::prelude::len(&b_p2.stmts_p);
        let b_p2x = b_p2.clone();
        let env_p1x = env_p1.clone();
        let lx_p0x = lx_p0.clone();
        let t_p3x = t_p3.clone();
        crate::prelude::call_value(crate::prelude::fold_job(crate::check::errors::range0_f(&n_p7), (crate::prelude::Array::new(), env_p1x.clone(), ::std::option::Option::None), {
            let b_p2xx = b_p2x.clone();
            let is_try_p6x = is_try_p6;
            let lx_p0xx = lx_p0x.clone();
            let label_p5x = label_p5.clone();
            let n_p7x = n_p7.clone();
            ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Array<crate::lower::model::Do>, crate::lower::types::Env, ::std::option::Option<crate::lower::types::Vl>), crate::prelude::Nat)| {
                let b_p2xxy = b_p2xx.clone();
                let is_try_p6xy = is_try_p6x;
                let lx_p0xxy = lx_p0xx.clone();
                let label_p5xy = label_p5x.clone();
                let n_p7xy = n_p7x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let (acc_p9, en_pa, lv_ob) = p0;
                    let i_pc = p1;
                    {
                        let s_pd = crate::prelude::or(&crate::prelude::index(&b_p2xxy.stmts_p, &i_pc), &crate::lower::expr::dummy_stmt_l_p());
                        let fail_pe = if is_try_p6xy {
                            crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Err")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("rt::Error::new")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XStr(crate::prelude::Text::lit("Prelude.Unmet")), crate::lower::model::Ex::XStr(source_text_f(&lx_p0xxy, &s_pd.span_p))]))]))
                        } else {
                            crate::lower::model::Ex::XNone
                        };
                        match &s_pd.kind_p {
                            crate::syntax::StmtKind::SBind(p_pf, x_pg, ::std::option::Option::None) => {
                                let p_pfx = p_pf.clone();
                                let x_pgx = x_pg.clone();
                                crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p0xxy.clone(), en_pa.clone(), x_pgx.clone()), move |value_of_f_6224: crate::lower::types::Vl| {
                                    let v_ph = value_of_f_6224;
                                    crate::prelude::call_then(crate::lower::patterns::start_rust_pat_f(lx_p0xxy.clone(), p_pfx.clone(), crate::lower::patterns::inner_ty_f(&crate::lower::type_at_f(&lx_p0xxy, &x_pgx.span_p)), crate::lower::types::Holding::Owned, crate::prelude::Text::from(format!("g{}", &s_pd.span_p.start_p))), move |rust_pat_f_6267: crate::lower::patterns::PatOut| {
                                        let po_pi = rust_pat_f_6267;
                                        crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0xxy.clone(), crate::lower::patterns::inner_ty_f(&crate::lower::type_at_f(&lx_p0xxy, &x_pgx.span_p))), move |out_ty_of_f_6409: crate::lower::model::OutTy| ::prism_rtl::Turn::Finished((crate::prelude::push(&acc_p9, &given_bind_f(&is_try_p6xy, &po_pi.pa_p, &crate::lower::types::own_f(&v_ph), &label_p5xy, &out_ty_of_f_6409)), crate::lower::expr::bind_all_f(&en_pa, &po_pi.binds_p), lv_ob.clone())))
                                    })
                                })
                            },
                            crate::syntax::StmtKind::SRequire(c_pj) => {
                                let c_pjx = c_pj.clone();
                                crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p0xxy.clone(), en_pa.clone(), c_pjx.clone()), move |value_of_f_6552: crate::lower::types::Vl| ::prism_rtl::Turn::Finished((crate::prelude::push(&acc_p9, &crate::lower::model::Do::DoIf(crate::lower::model::Ex::XUnary(crate::lower::model::UnOp::OpNot, ::std::rc::Rc::new(crate::lower::types::as_bool_f(&value_of_f_6552))), crate::prelude::Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XBreak(label_p5xy.clone(), ::std::rc::Rc::new(fail_pe.clone())))]), crate::prelude::Array::new())), en_pa.clone(), lv_ob.clone())))
                            },
                            crate::syntax::StmtKind::SForbid(c_pk) => {
                                let c_pkx = c_pk.clone();
                                crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p0xxy.clone(), en_pa.clone(), c_pkx.clone()), move |value_of_f_6676: crate::lower::types::Vl| ::prism_rtl::Turn::Finished((crate::prelude::push(&acc_p9, &crate::lower::model::Do::DoIf(crate::lower::types::as_bool_f(&value_of_f_6676), crate::prelude::Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XBreak(label_p5xy.clone(), ::std::rc::Rc::new(fail_pe.clone())))]), crate::prelude::Array::new())), en_pa.clone(), lv_ob.clone())))
                            },
                            crate::syntax::StmtKind::SExpr(x_pl) => if &(&i_pc + &crate::prelude::Nat::from(1u32)) == &n_p7xy {
                                ::prism_rtl::Turn::Finished((acc_p9.clone(), en_pa.clone(), ::std::option::Option::Some(crate::lower::expr::value_of_f(&lx_p0xxy, &en_pa, x_pl))))
                            } else {
                                {
                                    let x_plx = x_pl.clone();
                                    crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p0xxy.clone(), en_pa.clone(), x_plx.clone()), move |value_of_f_6884: crate::lower::types::Vl| ::prism_rtl::Turn::Finished((crate::prelude::push(&acc_p9, &crate::lower::model::Do::DoExpr(crate::lower::types::own_f(&value_of_f_6884))), en_pa.clone(), lv_ob.clone())))
                                }
                            },
                            _ => crate::prelude::call_then(crate::lower::expr::start_block_stmt_f(lx_p0xxy.clone(), en_pa.clone(), s_pd.clone()), move |block_stmt_f_6976: (crate::prelude::Array<crate::lower::model::Do>, crate::lower::types::Env)| {
                                let (more_pm, en2_pn) = block_stmt_f_6976;
                                ::prism_rtl::Turn::Finished((crate::prelude::append(&acc_p9, &more_pm), en2_pn.clone(), lv_ob.clone()))
                            }),
                        }
                    }
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Array<crate::lower::model::Do>, crate::lower::types::Env, ::std::option::Option<crate::lower::types::Vl>), crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<crate::lower::model::Do>, crate::lower::types::Env, ::std::option::Option<crate::lower::types::Vl>)>>>
        }), move |fold_5873: (crate::prelude::Array<crate::lower::model::Do>, crate::lower::types::Env, ::std::option::Option<crate::lower::types::Vl>)| {
            let (dos_po, env2_pp, last_oq) = fold_5873;
            let last_p8 = crate::prelude::or(&last_oq, &crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XNone, t_p3x.clone()));
            ::prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XLabeled(label_p5.clone(), dos_po.clone(), ::std::rc::Rc::new(crate::lower::types::own_f(&last_p8)), t_p3x.clone()), t_p3x.clone()))
        })
    }
}

/// `Start GivenValue, x`: what the function value is when passed to `@Run`.
pub fn start_given_value_f(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, b_p2: crate::syntax::Block, t_p3: crate::lower::model::OutTy, span_p4: crate::syntax::Range) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::types::Vl>> {
    ::std::rc::Rc::new(GivenValue { lx_p0, env_p1, b_p2, t_p3, span_p4 })
}

/// ```prism
/// GivenBind: fn Bool, Pa, Ex, Text, OutTy -> Do
/// ```
pub fn given_bind_f(is_try_p0: &bool, pa_p1: &crate::lower::model::Pa, x_p2: &crate::lower::model::Ex, label_p3: &crate::prelude::Text, t_p4: &crate::lower::model::OutTy) -> crate::lower::model::Do {
    if *is_try_p0 {
        crate::lower::model::Do::DoLet(pa_p1.clone(), crate::lower::model::Ex::XMatch(::std::rc::Rc::new(x_p2.clone()), crate::prelude::Array::from(vec![crate::lower::model::XArm { pat_p: crate::lower::model::Pa::PaCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Ok")), crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("v"))])), conds_p: crate::prelude::Array::new(), body_p: crate::lower::model::Ex::XVar(crate::prelude::Text::lit("v")) }, crate::lower::model::XArm { pat_p: crate::lower::model::Pa::PaCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Err")), crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("e"))])), conds_p: crate::prelude::Array::new(), body_p: crate::lower::model::Ex::XBreak(label_p3.clone(), ::std::rc::Rc::new(crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Err")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XVar(crate::prelude::Text::lit("e"))])))) }]), false, t_p4.clone()))
    } else {
        crate::lower::model::Do::DoLetElse(crate::lower::model::Pa::PaCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Some")), crate::prelude::Array::from(vec![pa_p1.clone()])), x_p2.clone(), crate::lower::model::Ex::XBreak(label_p3.clone(), ::std::rc::Rc::new(crate::lower::model::Ex::XNone)))
    }
}

/// ```prism
/// SourceText: fn Lx, Range -> Text
/// ```
pub fn source_text_f(lx_p0: &crate::lower::Lx, r_p1: &crate::syntax::Range) -> crate::prelude::Text {
    match crate::prelude::index(&lx_p0.g_p.srcs_p, &lx_p0.file_p) {
        ::std::option::Option::Some(src_p2) => crate::check::errors::span_text_f(&src_p2, r_p1),
        ::std::option::Option::None => crate::prelude::Text::lit(""),
    }
}

/// ```prism
/// UpdateValue: unbounded fn Lx, Env, Expr, Block, OutTy, Range -> Vl
/// ```
pub fn update_value_f(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, target_p2: &crate::syntax::Expr, b_p3: &crate::syntax::Block, t_p4: &crate::lower::model::OutTy, span_p5: &crate::syntax::Range) -> crate::lower::types::Vl {
    let tv_p6 = crate::lower::expr::value_of_f(lx_p0, env_p1, target_p2);
    let env1_p7 = crate::lower::types::bind_f(env_p1, &crate::prelude::Text::lit("&_"), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("this")), crate::lower::types::Holding::Owned, t_p4.clone()));
    let (dos_p8, _) = upd_stmts_f(lx_p0, &env1_p7, &b_p3.stmts_p);
    crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XBlock(crate::prelude::append(&crate::prelude::Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaMut(crate::prelude::Text::lit("this"))), t_p4.clone()), crate::lower::types::own_f(&tv_p6))]), &dos_p8), ::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("this")))), t_p4.clone())
}

/// The step machine of `UpdateValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UpdateValue: unbounded fn Lx, Env, Expr, Block, OutTy, Range -> Vl
/// ```
pub struct UpdateValue {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub target_p2: crate::syntax::Expr,
    pub b_p3: crate::syntax::Block,
    pub t_p4: crate::lower::model::OutTy,
    pub span_p5: crate::syntax::Range,
}

impl ::prism_rtl::Job<crate::lower::types::Vl> for UpdateValue {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::lower::types::Vl> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let target_p2 = &self.target_p2;
        let b_p3 = &self.b_p3;
        let t_p4 = &self.t_p4;
        let span_p5 = &self.span_p5;
        let b_p3x = b_p3.clone();
        let env_p1x = env_p1.clone();
        let lx_p0x = lx_p0.clone();
        let t_p4x = t_p4.clone();
        let target_p2x = target_p2.clone();
        crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p0x.clone(), env_p1x.clone(), target_p2x.clone()), move |value_of_f_8247: crate::lower::types::Vl| {
            let tv_p6 = value_of_f_8247;
            let env1_p7 = crate::lower::types::bind_f(&env_p1x, &crate::prelude::Text::lit("&_"), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("this")), crate::lower::types::Holding::Owned, t_p4x.clone()));
            crate::prelude::call_then(start_upd_stmts_f(lx_p0x.clone(), env1_p7.clone(), b_p3x.stmts_p.clone()), move |upd_stmts_f_8362: (crate::prelude::Array<crate::lower::model::Do>, crate::lower::types::Env)| {
                let (dos_p8, _) = upd_stmts_f_8362;
                ::prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XBlock(crate::prelude::append(&crate::prelude::Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaMut(crate::prelude::Text::lit("this"))), t_p4x.clone()), crate::lower::types::own_f(&tv_p6))]), &dos_p8), ::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("this")))), t_p4x.clone()))
            })
        })
    }
}

/// `Start UpdateValue, x`: what the function value is when passed to `@Run`.
pub fn start_update_value_f(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, target_p2: crate::syntax::Expr, b_p3: crate::syntax::Block, t_p4: crate::lower::model::OutTy, span_p5: crate::syntax::Range) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::types::Vl>> {
    ::std::rc::Rc::new(UpdateValue { lx_p0, env_p1, target_p2, b_p3, t_p4, span_p5 })
}

/// ```prism
/// UpdStmts: unbounded fn Lx, Env, [Stmt] -> (([Do], Env))
/// ```
pub fn upd_stmts_f(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, stmts_p2: &crate::prelude::Array<crate::syntax::Stmt>) -> (crate::prelude::Array<crate::lower::model::Do>, crate::lower::types::Env) {
    crate::prelude::run_to_end(crate::prelude::fold_job(stmts_p2.clone(), (crate::prelude::Array::new(), env_p1.clone()), {
        let lx_p0x = lx_p0.clone();
        ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Array<crate::lower::model::Do>, crate::lower::types::Env), crate::syntax::Stmt)| {
            let lx_p0xy = lx_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (acc_p3, en_p4) = p0;
                let s_p5 = p1;
                crate::prelude::call_then(start_upd_stmt_f(lx_p0xy.clone(), en_p4.clone(), s_p5.clone()), move |upd_stmt_f_8647: (crate::prelude::Array<crate::lower::model::Do>, crate::lower::types::Env)| {
                    let (more_p6, en2_p7) = upd_stmt_f_8647;
                    ::prism_rtl::Turn::Finished((crate::prelude::append(&acc_p3, &more_p6), en2_p7.clone()))
                })
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Array<crate::lower::model::Do>, crate::lower::types::Env), crate::syntax::Stmt)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<crate::lower::model::Do>, crate::lower::types::Env)>>>
    }))
}

/// The step machine of `UpdStmts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UpdStmts: unbounded fn Lx, Env, [Stmt] -> (([Do], Env))
/// ```
pub struct UpdStmts {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub stmts_p2: crate::prelude::Array<crate::syntax::Stmt>,
}

impl ::prism_rtl::Job<(crate::prelude::Array<crate::lower::model::Do>, crate::lower::types::Env)> for UpdStmts {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::prelude::Array<crate::lower::model::Do>, crate::lower::types::Env)> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let stmts_p2 = &self.stmts_p2;
        crate::prelude::fold_job(stmts_p2.clone(), (crate::prelude::Array::new(), env_p1.clone()), {
            let lx_p0x = lx_p0.clone();
            ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Array<crate::lower::model::Do>, crate::lower::types::Env), crate::syntax::Stmt)| {
                let lx_p0xy = lx_p0x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let (acc_p3, en_p4) = p0;
                    let s_p5 = p1;
                    crate::prelude::call_then(start_upd_stmt_f(lx_p0xy.clone(), en_p4.clone(), s_p5.clone()), move |upd_stmt_f_8647: (crate::prelude::Array<crate::lower::model::Do>, crate::lower::types::Env)| {
                        let (more_p6, en2_p7) = upd_stmt_f_8647;
                        ::prism_rtl::Turn::Finished((crate::prelude::append(&acc_p3, &more_p6), en2_p7.clone()))
                    })
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Array<crate::lower::model::Do>, crate::lower::types::Env), crate::syntax::Stmt)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<crate::lower::model::Do>, crate::lower::types::Env)>>>
        }).cycle()
    }
}

/// `Start UpdStmts, x`: what the function value is when passed to `@Run`.
pub fn start_upd_stmts_f(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, stmts_p2: crate::prelude::Array<crate::syntax::Stmt>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<crate::lower::model::Do>, crate::lower::types::Env)>> {
    ::std::rc::Rc::new(UpdStmts { lx_p0, env_p1, stmts_p2 })
}

/// ```prism
/// UpdStmt: unbounded fn Lx, Env, Stmt -> (([Do], Env))
/// ```
pub fn upd_stmt_f(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, s_p2: &crate::syntax::Stmt) -> (crate::prelude::Array<crate::lower::model::Do>, crate::lower::types::Env) {
    match &s_p2.kind_p {
        crate::syntax::StmtKind::SSet(target_p3, value_p4) => {
            let v_p5 = crate::lower::types::own_f(&crate::lower::expr::value_of_f(lx_p0, env_p1, value_p4));
            (crate::prelude::Array::from(vec![assign_f(lx_p0, env_p1, target_p3, &v_p5)]), env_p1.clone())
        },
        crate::syntax::StmtKind::SAccum(target_p6, op_p7, value_p8) => {
            let cur_p9 = place_of_f(lx_p0, env_p1, target_p6);
            let tt_pa = crate::lower::types::out_ty_of_f(lx_p0, &crate::lower::types::peel_f(&crate::lower::type_at_f(lx_p0, &target_p6.span_p)));
            let rv_pb = crate::lower::expr::value_of_f(lx_p0, env_p1, value_p8);
            let bin_pc = crate::syntax::lexer::chars::head_f(op_p7);
            let now_pd = match lens_call_o(lx_p0, target_p6) {
                ::std::option::Option::Some(_) => crate::lower::expr::value_of_f(lx_p0, env_p1, target_p6),
                ::std::option::Option::None => crate::lower::types::Vl::VlPlace(cur_p9.clone(), crate::lower::types::Holding::Owned, tt_pa.clone()),
            };
            let next_pe = crate::lower::expr::op_value_f(lx_p0, &bin_pc, &now_pd, &rv_pb, &s_p2.span_p, &tt_pa);
            (crate::prelude::Array::from(vec![assign_f(lx_p0, env_p1, target_p6, &crate::lower::types::own_f(&next_pe))]), env_p1.clone())
        },
        crate::syntax::StmtKind::SLet(p_pf, _, x_pg) => {
            let v_ph = crate::lower::types::own_f(&crate::lower::expr::value_of_f(lx_p0, env_p1, x_pg));
            match &*p_pf.kind_p {
                crate::syntax::PatternKind::PName(n_pi) => if crate::syntax::lexer::chars::has_prefix_f(&n_pi.sigils_p, &crate::prelude::Text::lit("&")) {
                    {
                        let rs_pj = crate::lower::local_name_at_f(lx_p0, &crate::check::env::sname_key_f(n_pi), &n_pi.span_p);
                        let bt_pk = crate::lower::types::out_ty_of_f(lx_p0, &crate::lower::types::peel_f(&crate::lower::binder_ty_f(lx_p0, &n_pi.span_p)));
                        let pa_pl = if crate::lower::expr::is_known_ty_f(&bt_pk) {
                            crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaMut(crate::prelude::Text::from(format!("{}", &rs_pj)))), bt_pk.clone())
                        } else {
                            crate::lower::model::Pa::PaMut(crate::prelude::Text::from(format!("{}", &rs_pj)))
                        };
                        (crate::prelude::Array::from(vec![crate::lower::model::Do::DoLet(pa_pl.clone(), v_ph.clone())]), crate::lower::types::bind_f(env_p1, &crate::check::env::sname_key_f(n_pi), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(rs_pj.clone()), crate::lower::types::Holding::Owned, bt_pk.clone())))
                    }
                } else {
                    crate::lower::expr::block_stmt_f(lx_p0, env_p1, s_p2)
                },
                _ => crate::lower::expr::block_stmt_f(lx_p0, env_p1, s_p2),
            }
        },
        crate::syntax::StmtKind::SWhile(c_pm, body_pn) => {
            let (inner_po, _) = upd_stmts_f(lx_p0, env_p1, &body_pn.stmts_p);
            match c_pm {
                crate::syntax::Cond::CondExpr(x_pp) => (crate::prelude::Array::from(vec![crate::lower::model::Do::DoWhile(crate::lower::types::as_bool_f(&crate::lower::expr::value_of_f(lx_p0, env_p1, &**x_pp)), inner_po.clone())]), env_p1.clone()),
                crate::syntax::Cond::CondBind(p_pq, x_pr, g_os) => {
                    let po_pt = crate::lower::patterns::rust_pat_f(lx_p0, p_pq, &crate::lower::type_at_f(lx_p0, &x_pr.span_p), &crate::lower::types::Holding::Owned, &crate::prelude::Text::from(format!("w{}", &s_p2.span_p.start_p)));
                    let env_b_pu = crate::lower::expr::bind_all_f(env_p1, &po_pt.binds_p);
                    let (inner2_p12, _) = upd_stmts_f(lx_p0, &env_b_pu, &body_pn.stmts_p);
                    let conds_pv = crate::prelude::append(&po_pt.conds_p, &guard_conds_f(lx_p0, &env_b_pu, &**g_os));
                    let stop_p10 = crate::prelude::each(&conds_pv, &(|c_p13: &crate::lower::model::Cc| match c_p13 {
                        crate::lower::model::Cc::CcIf(t_p14) => crate::lower::model::Do::DoIf(crate::lower::model::Ex::XUnary(crate::lower::model::UnOp::OpNot, ::std::rc::Rc::new(t_p14.clone())), crate::prelude::Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XBreakLoop)]), crate::prelude::Array::new()),
                        crate::lower::model::Cc::CcLet(pa_p15, y_p16) => crate::lower::model::Do::DoLetElse(pa_p15.clone(), y_p16.clone(), crate::lower::model::Ex::XBreakLoop),
                    }));
                    let body2_p11 = crate::prelude::append(&stop_p10, &inner2_p12);
                    (crate::prelude::Array::from(vec![crate::lower::model::Do::DoWhileLet(po_pt.pa_p.clone(), crate::lower::types::own_f(&crate::lower::expr::value_of_f(lx_p0, env_p1, &**x_pr)), body2_p11.clone())]), env_p1.clone())
                },
            }
        },
        crate::syntax::StmtKind::SExpr(x_p17) => match &*x_p17.kind_p {
            crate::syntax::ExprKind::EIf(c_p18, then_b_p19, else_b_o1a) => (crate::prelude::Array::from(vec![upd_if_f(lx_p0, env_p1, &**c_p18, then_b_p19, else_b_o1a)]), env_p1.clone()),
            crate::syntax::ExprKind::EMatch(scrut_p1b, arms_p1c) => (crate::prelude::Array::from(vec![upd_match_f(lx_p0, env_p1, &**scrut_p1b, arms_p1c)]), env_p1.clone()),
            crate::syntax::ExprKind::EFor(binders_o1d, source_p1e, body_p1f) => (crate::prelude::Array::from(vec![upd_for_f(lx_p0, env_p1, binders_o1d, &**source_p1e, body_p1f, &x_p17.span_p)]), env_p1.clone()),
            _ => (crate::prelude::Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::types::own_f(&crate::lower::expr::value_of_f(lx_p0, env_p1, x_p17)))]), env_p1.clone()),
        },
        _ => crate::lower::expr::block_stmt_f(lx_p0, env_p1, s_p2),
    }
}

/// The step machine of `UpdStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UpdStmt: unbounded fn Lx, Env, Stmt -> (([Do], Env))
/// ```
pub struct UpdStmt {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub s_p2: crate::syntax::Stmt,
}

impl ::prism_rtl::Job<(crate::prelude::Array<crate::lower::model::Do>, crate::lower::types::Env)> for UpdStmt {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::prelude::Array<crate::lower::model::Do>, crate::lower::types::Env)> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let s_p2 = &self.s_p2;
        match &s_p2.kind_p {
            crate::syntax::StmtKind::SSet(target_p3, value_p4) => {
                let env_p1x = env_p1.clone();
                let lx_p0x = lx_p0.clone();
                let target_p3x = target_p3.clone();
                let value_p4x = value_p4.clone();
                crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p0x.clone(), env_p1x.clone(), value_p4x.clone()), move |value_of_f_8834: crate::lower::types::Vl| {
                    let v_p5 = crate::lower::types::own_f(&value_of_f_8834);
                    crate::prelude::call_then(start_assign_f(lx_p0x.clone(), env_p1x.clone(), target_p3x.clone(), v_p5.clone()), move |assign_f_8871: crate::lower::model::Do| ::prism_rtl::Turn::Finished((crate::prelude::Array::from(vec![assign_f_8871]), env_p1x.clone())))
                })
            },
            crate::syntax::StmtKind::SAccum(target_p6, op_p7, value_p8) => {
                let env_p1x = env_p1.clone();
                let lx_p0x = lx_p0.clone();
                let op_p7x = op_p7.clone();
                let s_p2x = s_p2.clone();
                let target_p6x = target_p6.clone();
                let value_p8x = value_p8.clone();
                crate::prelude::call_then(start_place_of_f(lx_p0x.clone(), env_p1x.clone(), target_p6x.clone()), move |place_of_f_8955: crate::lower::model::Ex| {
                    let cur_p9 = place_of_f_8955;
                    crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0x.clone(), crate::lower::types::peel_f(&crate::lower::type_at_f(&lx_p0x, &target_p6x.span_p))), move |out_ty_of_f_8996: crate::lower::model::OutTy| {
                        let tt_pa = out_ty_of_f_8996;
                        crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p0x.clone(), env_p1x.clone(), value_p8x.clone()), move |value_of_f_9057: crate::lower::types::Vl| {
                            let rv_pb = value_of_f_9057;
                            let bin_pc = crate::syntax::lexer::chars::head_f(&op_p7x);
                            crate::prelude::call_then(start_lens_call_o(lx_p0x.clone(), target_p6x.clone()), move |lens_call_o_9258: ::std::option::Option<(crate::prelude::Text, crate::syntax::Expr)>| {
                                let bin_pcz = bin_pc.clone();
                                let env_p1xz = env_p1x.clone();
                                let lx_p0xz = lx_p0x.clone();
                                let rv_pbz = rv_pb.clone();
                                let s_p2xz = s_p2x.clone();
                                let target_p6xz = target_p6x.clone();
                                let tt_paz = tt_pa.clone();
                                let k_let9242 = move |v9242: crate::lower::types::Vl| {
                                    let now_pd = v9242;
                                    let next_pe = crate::lower::expr::op_value_f(&lx_p0xz, &bin_pcz, &now_pd, &rv_pbz, &s_p2xz.span_p, &tt_paz);
                                    crate::prelude::call_then(start_assign_f(lx_p0xz.clone(), env_p1xz.clone(), target_p6xz.clone(), crate::lower::types::own_f(&next_pe)), move |assign_f_9435: crate::lower::model::Do| ::prism_rtl::Turn::Finished((crate::prelude::Array::from(vec![assign_f_9435]), env_p1xz.clone())))
                                };
                                match lens_call_o_9258 {
                                    ::std::option::Option::Some(_) => crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p0x.clone(), env_p1x.clone(), target_p6x.clone()), move |value_of_f_9302: crate::lower::types::Vl| k_let9242(value_of_f_9302)),
                                    ::std::option::Option::None => k_let9242(crate::lower::types::Vl::VlPlace(cur_p9.clone(), crate::lower::types::Holding::Owned, tt_pa.clone())),
                                }
                            })
                        })
                    })
                })
            },
            crate::syntax::StmtKind::SLet(p_pf, _, x_pg) => {
                let env_p1x = env_p1.clone();
                let lx_p0x = lx_p0.clone();
                let p_pfx = p_pf.clone();
                let s_p2x = s_p2.clone();
                let x_pgx = x_pg.clone();
                crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p0x.clone(), env_p1x.clone(), x_pgx.clone()), move |value_of_f_9524: crate::lower::types::Vl| {
                    let v_ph = crate::lower::types::own_f(&value_of_f_9524);
                    match &*p_pfx.kind_p {
                        crate::syntax::PatternKind::PName(n_pi) => if crate::syntax::lexer::chars::has_prefix_f(&n_pi.sigils_p, &crate::prelude::Text::lit("&")) {
                            {
                                let n_pix = n_pi.clone();
                                crate::prelude::call_then(crate::lower::start_local_name_at_f(lx_p0x.clone(), crate::check::env::sname_key_f(&n_pix), n_pix.span_p.clone()), move |local_name_at_f_9662: crate::prelude::Text| {
                                    let rs_pj = local_name_at_f_9662;
                                    crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0x.clone(), crate::lower::types::peel_f(&crate::lower::binder_ty_f(&lx_p0x, &n_pix.span_p))), move |out_ty_of_f_9728: crate::lower::model::OutTy| {
                                        let bt_pk = out_ty_of_f_9728;
                                        crate::prelude::call_then(crate::lower::expr::start_is_known_ty_f(bt_pk.clone()), move |is_known_ty_f_9801: bool| {
                                            let pa_pl = if is_known_ty_f_9801 {
                                                crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaMut(crate::prelude::Text::from(format!("{}", &rs_pj)))), bt_pk.clone())
                                            } else {
                                                crate::lower::model::Pa::PaMut(crate::prelude::Text::from(format!("{}", &rs_pj)))
                                            };
                                            ::prism_rtl::Turn::Finished((crate::prelude::Array::from(vec![crate::lower::model::Do::DoLet(pa_pl.clone(), v_ph.clone())]), crate::lower::types::bind_f(&env_p1x, &crate::check::env::sname_key_f(&n_pix), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(rs_pj.clone()), crate::lower::types::Holding::Owned, bt_pk.clone()))))
                                        })
                                    })
                                })
                            }
                        } else {
                            ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::lower::expr::BlockStmt { lx_p0: lx_p0x.clone(), env_p1: env_p1x.clone(), s_p2: s_p2x.clone() }))
                        },
                        _ => ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::lower::expr::BlockStmt { lx_p0: lx_p0x.clone(), env_p1: env_p1x.clone(), s_p2: s_p2x.clone() })),
                    }
                })
            },
            crate::syntax::StmtKind::SWhile(c_pm, body_pn) => {
                let body_pnx = body_pn.clone();
                let c_pmx = c_pm.clone();
                let env_p1x = env_p1.clone();
                let lx_p0x = lx_p0.clone();
                let s_p2x = s_p2.clone();
                crate::prelude::call_then(start_upd_stmts_f(lx_p0x.clone(), env_p1x.clone(), body_pnx.stmts_p.clone()), move |upd_stmts_f_10100: (crate::prelude::Array<crate::lower::model::Do>, crate::lower::types::Env)| {
                    let (inner_po, _) = upd_stmts_f_10100;
                    match &c_pmx {
                        crate::syntax::Cond::CondExpr(x_pp) => {
                            let x_ppx = (**x_pp).clone();
                            crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p0x.clone(), env_p1x.clone(), x_ppx.clone()), move |value_of_f_10192: crate::lower::types::Vl| ::prism_rtl::Turn::Finished((crate::prelude::Array::from(vec![crate::lower::model::Do::DoWhile(crate::lower::types::as_bool_f(&value_of_f_10192), inner_po.clone())]), env_p1x.clone())))
                        },
                        crate::syntax::Cond::CondBind(p_pq, x_pr, g_os) => {
                            let g_osx = (**g_os).clone();
                            let p_pqx = p_pq.clone();
                            let x_prx = (**x_pr).clone();
                            crate::prelude::call_then(crate::lower::patterns::start_rust_pat_f(lx_p0x.clone(), p_pqx.clone(), crate::lower::type_at_f(&lx_p0x, &x_prx.span_p), crate::lower::types::Holding::Owned, crate::prelude::Text::from(format!("w{}", &s_p2x.span_p.start_p))), move |rust_pat_f_10286: crate::lower::patterns::PatOut| {
                                let po_pt = rust_pat_f_10286;
                                let env_b_pu = crate::lower::expr::bind_all_f(&env_p1x, &po_pt.binds_p);
                                crate::prelude::call_then(start_upd_stmts_f(lx_p0x.clone(), env_b_pu.clone(), body_pnx.stmts_p.clone()), move |upd_stmts_f_10437: (crate::prelude::Array<crate::lower::model::Do>, crate::lower::types::Env)| {
                                    let (inner2_p12, _) = upd_stmts_f_10437;
                                    crate::prelude::call_then(start_guard_conds_f(lx_p0x.clone(), env_b_pu.clone(), g_osx.clone()), move |guard_conds_f_10924: crate::prelude::Array<crate::lower::model::Cc>| {
                                        let conds_pv = crate::prelude::append(&po_pt.conds_p, &guard_conds_f_10924);
                                        let stop_p10 = crate::prelude::each(&conds_pv, &(|c_p13: &crate::lower::model::Cc| match c_p13 {
                                            crate::lower::model::Cc::CcIf(t_p14) => crate::lower::model::Do::DoIf(crate::lower::model::Ex::XUnary(crate::lower::model::UnOp::OpNot, ::std::rc::Rc::new(t_p14.clone())), crate::prelude::Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XBreakLoop)]), crate::prelude::Array::new()),
                                            crate::lower::model::Cc::CcLet(pa_p15, y_p16) => crate::lower::model::Do::DoLetElse(pa_p15.clone(), y_p16.clone(), crate::lower::model::Ex::XBreakLoop),
                                        }));
                                        let body2_p11 = crate::prelude::append(&stop_p10, &inner2_p12);
                                        crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p0x.clone(), env_p1x.clone(), x_prx.clone()), move |value_of_f_11236: crate::lower::types::Vl| ::prism_rtl::Turn::Finished((crate::prelude::Array::from(vec![crate::lower::model::Do::DoWhileLet(po_pt.pa_p.clone(), crate::lower::types::own_f(&value_of_f_11236), body2_p11.clone())]), env_p1x.clone())))
                                    })
                                })
                            })
                        },
                    }
                })
            },
            crate::syntax::StmtKind::SExpr(x_p17) => match &*x_p17.kind_p {
                crate::syntax::ExprKind::EIf(c_p18, then_b_p19, else_b_o1a) => {
                    let else_b_o1ax = else_b_o1a.clone();
                    let c_p18x = (**c_p18).clone();
                    let env_p1x = env_p1.clone();
                    let lx_p0x = lx_p0.clone();
                    let then_b_p19x = then_b_p19.clone();
                    crate::prelude::call_then(start_upd_if_f(lx_p0x.clone(), env_p1x.clone(), c_p18x.clone(), then_b_p19x.clone(), else_b_o1ax.clone()), move |upd_if_f_11336: crate::lower::model::Do| ::prism_rtl::Turn::Finished((crate::prelude::Array::from(vec![upd_if_f_11336]), env_p1x.clone())))
                },
                crate::syntax::ExprKind::EMatch(scrut_p1b, arms_p1c) => {
                    let arms_p1cx = arms_p1c.clone();
                    let env_p1x = env_p1.clone();
                    let lx_p0x = lx_p0.clone();
                    let scrut_p1bx = (**scrut_p1b).clone();
                    crate::prelude::call_then(start_upd_match_f(lx_p0x.clone(), env_p1x.clone(), scrut_p1bx.clone(), arms_p1cx.clone()), move |upd_match_f_11411: crate::lower::model::Do| ::prism_rtl::Turn::Finished((crate::prelude::Array::from(vec![upd_match_f_11411]), env_p1x.clone())))
                },
                crate::syntax::ExprKind::EFor(binders_o1d, source_p1e, body_p1f) => {
                    let binders_o1dx = binders_o1d.clone();
                    let body_p1fx = body_p1f.clone();
                    let env_p1x = env_p1.clone();
                    let lx_p0x = lx_p0.clone();
                    let source_p1ex = (**source_p1e).clone();
                    let x_p17x = x_p17.clone();
                    crate::prelude::call_then(start_upd_for_f(lx_p0x.clone(), env_p1x.clone(), binders_o1dx.clone(), source_p1ex.clone(), body_p1fx.clone(), x_p17x.span_p.clone()), move |upd_for_f_11493: crate::lower::model::Do| ::prism_rtl::Turn::Finished((crate::prelude::Array::from(vec![upd_for_f_11493]), env_p1x.clone())))
                },
                _ => {
                    let env_p1x = env_p1.clone();
                    let lx_p0x = lx_p0.clone();
                    let x_p17x = x_p17.clone();
                    crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p0x.clone(), env_p1x.clone(), x_p17x.clone()), move |value_of_f_11586: crate::lower::types::Vl| ::prism_rtl::Turn::Finished((crate::prelude::Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::types::own_f(&value_of_f_11586))]), env_p1x.clone())))
                },
            },
            _ => ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::lower::expr::BlockStmt { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), s_p2: s_p2.clone() })),
        }
    }
}

/// `Start UpdStmt, x`: what the function value is when passed to `@Run`.
pub fn start_upd_stmt_f(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, s_p2: crate::syntax::Stmt) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<crate::lower::model::Do>, crate::lower::types::Env)>> {
    ::std::rc::Rc::new(UpdStmt { lx_p0, env_p1, s_p2 })
}

/// ```prism
/// UpdFor: unbounded fn Lx, Env, ?ForBinders, Expr, Block, Range -> Do
/// ```
pub fn upd_for_f(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, binders_o2: &::std::option::Option<crate::syntax::ForBinders>, source_p3: &crate::syntax::Expr, body_p4: &crate::syntax::Block, span_p5: &crate::syntax::Range) -> crate::lower::model::Do {
    let sty_p6 = crate::lower::types::collection_f(&crate::lower::types::peel_f(&crate::lower::type_at_f(lx_p0, &source_p3.span_p)));
    match ref_binder_o(binders_o2) {
        ::std::option::Option::Some(n_p7) => if is_ref_path_f(source_p3) {
            upd_for_refs_f(lx_p0, env_p1, &crate::check::env::sname_key_f(&n_p7), source_p3, body_p4, span_p5, &sty_p6)
        } else {
            upd_for_values_f(lx_p0, env_p1, binders_o2, source_p3, body_p4, span_p5, &sty_p6)
        },
        ::std::option::Option::None => if (is_bare_for_f(binders_o2) && is_ref_path_f(source_p3)) && is_array_or_map_f(&sty_p6) {
            upd_for_refs_f(lx_p0, env_p1, &crate::prelude::Text::lit("&_"), source_p3, body_p4, span_p5, &sty_p6)
        } else {
            upd_for_values_f(lx_p0, env_p1, binders_o2, source_p3, body_p4, span_p5, &sty_p6)
        },
    }
}

/// The step machine of `UpdFor`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UpdFor: unbounded fn Lx, Env, ?ForBinders, Expr, Block, Range -> Do
/// ```
pub struct UpdFor {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub binders_o2: ::std::option::Option<crate::syntax::ForBinders>,
    pub source_p3: crate::syntax::Expr,
    pub body_p4: crate::syntax::Block,
    pub span_p5: crate::syntax::Range,
}

impl ::prism_rtl::Job<crate::lower::model::Do> for UpdFor {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::lower::model::Do> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let binders_o2 = &self.binders_o2;
        let source_p3 = &self.source_p3;
        let body_p4 = &self.body_p4;
        let span_p5 = &self.span_p5;
        let sty_p6 = crate::lower::types::collection_f(&crate::lower::types::peel_f(&crate::lower::type_at_f(lx_p0, &source_p3.span_p)));
        match ref_binder_o(binders_o2) {
            ::std::option::Option::Some(n_p7) => {
                let binders_o2x = binders_o2.clone();
                let body_p4x = body_p4.clone();
                let env_p1x = env_p1.clone();
                let lx_p0x = lx_p0.clone();
                let source_p3x = source_p3.clone();
                let span_p5x = span_p5.clone();
                crate::prelude::call_then(start_is_ref_path_f(source_p3x.clone()), move |is_ref_path_f_12241: bool| if is_ref_path_f_12241 {
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(UpdForRefs { lx_p0: lx_p0x.clone(), env_p1: env_p1x.clone(), nkey_p2: crate::check::env::sname_key_f(&n_p7), source_p3: source_p3x.clone(), body_p4: body_p4x.clone(), span_p5: span_p5x.clone(), sty_p6: sty_p6.clone() }))
                } else {
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(UpdForValues { lx_p0: lx_p0x.clone(), env_p1: env_p1x.clone(), binders_o2: binders_o2x.clone(), source_p3: source_p3x.clone(), body_p4: body_p4x.clone(), span_p5: span_p5x.clone(), sty_p6: sty_p6.clone() }))
                })
            },
            ::std::option::Option::None => if (is_bare_for_f(binders_o2) && is_ref_path_f(source_p3)) && is_array_or_map_f(&sty_p6) {
                ::prism_rtl::Turn::More(::std::rc::Rc::new(UpdForRefs { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), nkey_p2: crate::prelude::Text::lit("&_"), source_p3: source_p3.clone(), body_p4: body_p4.clone(), span_p5: span_p5.clone(), sty_p6: sty_p6.clone() }))
            } else {
                ::prism_rtl::Turn::More(::std::rc::Rc::new(UpdForValues { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), binders_o2: binders_o2.clone(), source_p3: source_p3.clone(), body_p4: body_p4.clone(), span_p5: span_p5.clone(), sty_p6: sty_p6.clone() }))
            },
        }
    }
}

/// `Start UpdFor, x`: what the function value is when passed to `@Run`.
pub fn start_upd_for_f(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, binders_o2: ::std::option::Option<crate::syntax::ForBinders>, source_p3: crate::syntax::Expr, body_p4: crate::syntax::Block, span_p5: crate::syntax::Range) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Do>> {
    ::std::rc::Rc::new(UpdFor { lx_p0, env_p1, binders_o2, source_p3, body_p4, span_p5 })
}

/// ```prism
/// IsBareFor: fn ?ForBinders -> Bool
/// ```
pub fn is_bare_for_f(opt0: &::std::option::Option<crate::syntax::ForBinders>) -> bool {
    match opt0 {
        ::std::option::Option::Some(_) => false,
        ::std::option::Option::None => true,
    }
}

/// ```prism
/// IsArrayOrMap: fn Ty -> Bool
/// ```
pub fn is_array_or_map_f(t_p0: &crate::check::types::Ty) -> bool {
    match t_p0 {
        crate::check::types::Ty::TyArray(_) => true,
        crate::check::types::Ty::TyMap(_, _) => true,
        _ => false,
    }
}

/// ```prism
/// UpdForRefs: unbounded fn Lx, Env, Text, Expr, Block, Range, Ty -> Do
/// ```
pub fn upd_for_refs_f(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, nkey_p2: &crate::prelude::Text, source_p3: &crate::syntax::Expr, body_p4: &crate::syntax::Block, span_p5: &crate::syntax::Range, sty_p6: &crate::check::types::Ty) -> crate::lower::model::Do {
    match sty_p6 {
        crate::check::types::Ty::TyArray(v_p7) => {
            let key_name_p8 = crate::prelude::Text::from(format!("k{}", &span_p5.start_p));
            let ref_name_p9 = crate::prelude::Text::from(format!("r{}", &span_p5.start_p));
            let env1_pa = crate::lower::types::bind_f(&crate::lower::types::bind_f(&crate::lower::types::bind_f(env_p1, &crate::prelude::Text::lit("key"), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(key_name_p8.clone()), crate::lower::types::Holding::Owned, crate::lower::model::OutTy::OutNat)), &crate::prelude::Text::lit("ix"), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(key_name_p8.clone()), crate::lower::types::Holding::Owned, crate::lower::model::OutTy::OutNat)), nkey_p2, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XTarget(::std::rc::Rc::new(crate::lower::model::Ex::XVar(ref_name_p9.clone()))), crate::lower::types::Holding::Owned, crate::lower::types::out_ty_of_f(lx_p0, &**v_p7)));
            let (dos_pc, _) = upd_stmts_f(lx_p0, &env1_pa, &body_p4.stmts_p);
            let head_pb = crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(key_name_p8.clone()), crate::lower::model::Ex::XCall(crate::lower::helper_ref_f(&crate::prelude::Text::lit("nat_of")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XVar(crate::prelude::Text::from(format!("i{}", &span_p5.start_p)))])));
            crate::lower::model::Do::DoFor(crate::lower::model::Pa::PaTuple(crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(crate::prelude::Text::from(format!("i{}", &span_p5.start_p))), crate::lower::model::Pa::PaBind(ref_name_p9.clone())])), crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(place_of_f(lx_p0, env_p1, source_p3)), crate::prelude::Text::lit("iter_mut"), crate::prelude::Array::new())), crate::prelude::Text::lit("enumerate"), crate::prelude::Array::new()), crate::prelude::append(&crate::prelude::Array::from(vec![head_pb.clone()]), &dos_pc))
        },
        crate::check::types::Ty::TyMap(k_pd, v_pe) => {
            let key_name_pf = crate::prelude::Text::from(format!("k{}", &span_p5.start_p));
            let place_pg = place_of_f(lx_p0, env_p1, source_p3);
            let entry_ph = crate::lower::model::Ex::XDeref(::std::rc::Rc::new(crate::lower::model::Ex::XCall(crate::lower::helper_ref_f(&crate::prelude::Text::lit("at_mut_map")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XRefMut(::std::rc::Rc::new(place_pg.clone())), crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XVar(key_name_pf.clone())))]))));
            let env1_pi = crate::lower::types::bind_f(&crate::lower::types::bind_f(env_p1, &crate::prelude::Text::lit("key"), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(key_name_pf.clone()), crate::lower::types::Holding::Owned, crate::lower::types::out_ty_of_f(lx_p0, &**k_pd))), nkey_p2, &crate::lower::types::Bn::BnLocal(entry_ph.clone(), crate::lower::types::Holding::Owned, crate::lower::types::out_ty_of_f(lx_p0, &**v_pe)));
            let (dos_pj, _) = upd_stmts_f(lx_p0, &env1_pi, &body_p4.stmts_p);
            crate::lower::model::Do::DoFor(crate::lower::model::Pa::PaBind(key_name_pf.clone()), crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XCall(crate::lower::helper_ref_f(&crate::prelude::Text::lit("keys")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XRef(::std::rc::Rc::new(place_pg.clone()))]))), crate::prelude::Text::lit("into_iter"), crate::prelude::Array::new()), dos_pj.clone())
        },
        _ => crate::lower::expr::internal_bug_do_f(&crate::prelude::Text::lit("a `for` by reference over what is no array and no map")),
    }
}

/// The step machine of `UpdForRefs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UpdForRefs: unbounded fn Lx, Env, Text, Expr, Block, Range, Ty -> Do
/// ```
pub struct UpdForRefs {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub nkey_p2: crate::prelude::Text,
    pub source_p3: crate::syntax::Expr,
    pub body_p4: crate::syntax::Block,
    pub span_p5: crate::syntax::Range,
    pub sty_p6: crate::check::types::Ty,
}

impl ::prism_rtl::Job<crate::lower::model::Do> for UpdForRefs {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::lower::model::Do> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let nkey_p2 = &self.nkey_p2;
        let source_p3 = &self.source_p3;
        let body_p4 = &self.body_p4;
        let span_p5 = &self.span_p5;
        let sty_p6 = &self.sty_p6;
        match sty_p6 {
            crate::check::types::Ty::TyArray(v_p7) => {
                let key_name_p8 = crate::prelude::Text::from(format!("k{}", &span_p5.start_p));
                let ref_name_p9 = crate::prelude::Text::from(format!("r{}", &span_p5.start_p));
                let body_p4x = body_p4.clone();
                let env_p1x = env_p1.clone();
                let lx_p0x = lx_p0.clone();
                let nkey_p2x = nkey_p2.clone();
                let source_p3x = source_p3.clone();
                let span_p5x = span_p5.clone();
                let v_p7x = (**v_p7).clone();
                crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0x.clone(), v_p7x.clone()), move |out_ty_of_f_13473: crate::lower::model::OutTy| {
                    let env1_pa = crate::lower::types::bind_f(&crate::lower::types::bind_f(&crate::lower::types::bind_f(&env_p1x, &crate::prelude::Text::lit("key"), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(key_name_p8.clone()), crate::lower::types::Holding::Owned, crate::lower::model::OutTy::OutNat)), &crate::prelude::Text::lit("ix"), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(key_name_p8.clone()), crate::lower::types::Holding::Owned, crate::lower::model::OutTy::OutNat)), &nkey_p2x, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XTarget(::std::rc::Rc::new(crate::lower::model::Ex::XVar(ref_name_p9.clone()))), crate::lower::types::Holding::Owned, out_ty_of_f_13473));
                    crate::prelude::call_then(start_upd_stmts_f(lx_p0x.clone(), env1_pa.clone(), body_p4x.stmts_p.clone()), move |upd_stmts_f_13519: (crate::prelude::Array<crate::lower::model::Do>, crate::lower::types::Env)| {
                        let (dos_pc, _) = upd_stmts_f_13519;
                        let head_pb = crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(key_name_p8.clone()), crate::lower::model::Ex::XCall(crate::lower::helper_ref_f(&crate::prelude::Text::lit("nat_of")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XVar(crate::prelude::Text::from(format!("i{}", &span_p5x.start_p)))])));
                        crate::prelude::call_then(start_place_of_f(lx_p0x.clone(), env_p1x.clone(), source_p3x.clone()), move |place_of_f_13740: crate::lower::model::Ex| ::prism_rtl::Turn::Finished(crate::lower::model::Do::DoFor(crate::lower::model::Pa::PaTuple(crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(crate::prelude::Text::from(format!("i{}", &span_p5x.start_p))), crate::lower::model::Pa::PaBind(ref_name_p9.clone())])), crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(place_of_f_13740), crate::prelude::Text::lit("iter_mut"), crate::prelude::Array::new())), crate::prelude::Text::lit("enumerate"), crate::prelude::Array::new()), crate::prelude::append(&crate::prelude::Array::from(vec![head_pb.clone()]), &dos_pc))))
                    })
                })
            },
            crate::check::types::Ty::TyMap(k_pd, v_pe) => {
                let key_name_pf = crate::prelude::Text::from(format!("k{}", &span_p5.start_p));
                let body_p4x = body_p4.clone();
                let env_p1x = env_p1.clone();
                let k_pdx = (**k_pd).clone();
                let lx_p0x = lx_p0.clone();
                let nkey_p2x = nkey_p2.clone();
                let source_p3x = source_p3.clone();
                let v_pex = (**v_pe).clone();
                crate::prelude::call_then(start_place_of_f(lx_p0x.clone(), env_p1x.clone(), source_p3x.clone()), move |place_of_f_14081: crate::lower::model::Ex| {
                    let place_pg = place_of_f_14081;
                    let entry_ph = crate::lower::model::Ex::XDeref(::std::rc::Rc::new(crate::lower::model::Ex::XCall(crate::lower::helper_ref_f(&crate::prelude::Text::lit("at_mut_map")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XRefMut(::std::rc::Rc::new(place_pg.clone())), crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XVar(key_name_pf.clone())))]))));
                    crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0x.clone(), k_pdx.clone()), move |out_ty_of_f_14284: crate::lower::model::OutTy| crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0x.clone(), v_pex.clone()), move |out_ty_of_f_14332: crate::lower::model::OutTy| {
                        let env1_pi = crate::lower::types::bind_f(&crate::lower::types::bind_f(&env_p1x, &crate::prelude::Text::lit("key"), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(key_name_pf.clone()), crate::lower::types::Holding::Owned, out_ty_of_f_14284)), &nkey_p2x, &crate::lower::types::Bn::BnLocal(entry_ph.clone(), crate::lower::types::Holding::Owned, out_ty_of_f_14332));
                        crate::prelude::call_then(start_upd_stmts_f(lx_p0x.clone(), env1_pi.clone(), body_p4x.stmts_p.clone()), move |upd_stmts_f_14378: (crate::prelude::Array<crate::lower::model::Do>, crate::lower::types::Env)| {
                            let (dos_pj, _) = upd_stmts_f_14378;
                            ::prism_rtl::Turn::Finished(crate::lower::model::Do::DoFor(crate::lower::model::Pa::PaBind(key_name_pf.clone()), crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XCall(crate::lower::helper_ref_f(&crate::prelude::Text::lit("keys")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XRef(::std::rc::Rc::new(place_pg.clone()))]))), crate::prelude::Text::lit("into_iter"), crate::prelude::Array::new()), dos_pj.clone()))
                        })
                    }))
                })
            },
            _ => ::prism_rtl::Turn::Finished(crate::lower::expr::internal_bug_do_f(&crate::prelude::Text::lit("a `for` by reference over what is no array and no map"))),
        }
    }
}

/// `Start UpdForRefs, x`: what the function value is when passed to `@Run`.
pub fn start_upd_for_refs_f(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, nkey_p2: crate::prelude::Text, source_p3: crate::syntax::Expr, body_p4: crate::syntax::Block, span_p5: crate::syntax::Range, sty_p6: crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Do>> {
    ::std::rc::Rc::new(UpdForRefs { lx_p0, env_p1, nkey_p2, source_p3, body_p4, span_p5, sty_p6 })
}

/// ```prism
/// ?RefBinder: fn ?ForBinders -> ?SName
/// ```
pub fn ref_binder_o(opt0: &::std::option::Option<crate::syntax::ForBinders>) -> ::std::option::Option<crate::syntax::SName> {
    match opt0 {
        ::std::option::Option::Some(fb_p0) => match &fb_p0.second_o {
            ::std::option::Option::None => match &*fb_p0.first_p.kind_p {
                crate::syntax::PatternKind::PName(n_p1) => if crate::syntax::lexer::chars::has_prefix_f(&n_p1.sigils_p, &crate::prelude::Text::lit("&")) {
                    ::std::option::Option::Some(n_p1.clone())
                } else {
                    ::std::option::Option::None
                },
                _ => ::std::option::Option::None,
            },
            _ => ::std::option::Option::None,
        },
        ::std::option::Option::None => ::std::option::Option::None,
    }
}

/// ```prism
/// IsRefPath: unbounded fn Expr -> Bool
/// ```
pub fn is_ref_path_f(e_p0: &crate::syntax::Expr) -> bool {
    match &*e_p0.kind_p {
        crate::syntax::ExprKind::EName(n_p1) => crate::syntax::lexer::chars::has_prefix_f(&n_p1.sigils_p, &crate::prelude::Text::lit("&")),
        crate::syntax::ExprKind::EField(r_p2, _, _) => is_ref_path_f(&**r_p2),
        crate::syntax::ExprKind::EIndex(r_p3, _) => is_ref_path_f(&**r_p3),
        crate::syntax::ExprKind::EGroup(x_p4) => is_ref_path_f(&**x_p4),
        _ => match crate::check::env::lens_applied_o(e_p0) {
            ::std::option::Option::Some((_, argument_p5)) => is_ref_path_f(&argument_p5),
            ::std::option::Option::None => false,
        },
    }
}

/// The step machine of `IsRefPath`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// IsRefPath: unbounded fn Expr -> Bool
/// ```
pub struct IsRefPath {
    pub e_p0: crate::syntax::Expr,
}

impl ::prism_rtl::Job<bool> for IsRefPath {
    fn cycle(&self) -> ::prism_rtl::Turn<bool> {
        let e_p0 = &self.e_p0;
        match &*e_p0.kind_p {
            crate::syntax::ExprKind::EName(n_p1) => ::prism_rtl::Turn::Finished(crate::syntax::lexer::chars::has_prefix_f(&n_p1.sigils_p, &crate::prelude::Text::lit("&"))),
            crate::syntax::ExprKind::EField(r_p2, _, _) => ::prism_rtl::Turn::More(::std::rc::Rc::new(IsRefPath { e_p0: (**r_p2).clone() })),
            crate::syntax::ExprKind::EIndex(r_p3, _) => ::prism_rtl::Turn::More(::std::rc::Rc::new(IsRefPath { e_p0: (**r_p3).clone() })),
            crate::syntax::ExprKind::EGroup(x_p4) => ::prism_rtl::Turn::More(::std::rc::Rc::new(IsRefPath { e_p0: (**x_p4).clone() })),
            _ => match crate::check::env::lens_applied_o(e_p0) {
                ::std::option::Option::Some((_, argument_p5)) => ::prism_rtl::Turn::More(::std::rc::Rc::new(IsRefPath { e_p0: argument_p5.clone() })),
                ::std::option::Option::None => ::prism_rtl::Turn::Finished(false),
            },
        }
    }
}

/// `Start IsRefPath, x`: what the function value is when passed to `@Run`.
pub fn start_is_ref_path_f(e_p0: crate::syntax::Expr) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>> {
    ::std::rc::Rc::new(IsRefPath { e_p0 })
}

/// ```prism
/// UpdForValues: unbounded fn Lx, Env, ?ForBinders, Expr, Block, Range, Ty -> Do
/// ```
pub fn upd_for_values_f(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, binders_o2: &::std::option::Option<crate::syntax::ForBinders>, source_p3: &crate::syntax::Expr, body_p4: &crate::syntax::Block, span_p5: &crate::syntax::Range, sty_p6: &crate::check::types::Ty) -> crate::lower::model::Do {
    let src_p7 = crate::lower::types::own_f(&crate::lower::types::plain_value_f(&crate::lower::expr::value_of_f(lx_p0, env_p1, source_p3)));
    let (kt_pg, vt_ph, is_array_pi) = match sty_p6 {
        crate::check::types::Ty::TyArray(v_pd) => (crate::lower::model::OutTy::OutNat, crate::lower::types::out_ty_of_f(lx_p0, &**v_pd), true),
        crate::check::types::Ty::TyMap(k_pe, v_pf) => (crate::lower::types::out_ty_of_f(lx_p0, &**k_pe), crate::lower::types::out_ty_of_f(lx_p0, &**v_pf), false),
        _ => (crate::lower::model::OutTy::OutUnit, crate::lower::model::OutTy::OutUnit, true),
    };
    let (vty_pm, kty_pn) = match sty_p6 {
        crate::check::types::Ty::TyArray(v_pj) => ((**v_pj).clone(), crate::check::types::Ty::TyCon(crate::prelude::Text::lit("Nat"), crate::prelude::Array::new())),
        crate::check::types::Ty::TyMap(k_pk, v_pl) => ((**v_pl).clone(), (**k_pk).clone()),
        _ => (crate::check::types::Ty::TyErr, crate::check::types::Ty::TyErr),
    };
    let key_name_p8 = crate::prelude::Text::from(format!("k{}", &span_p5.start_p));
    let val_name_p9 = crate::prelude::Text::from(format!("v{}", &span_p5.start_p));
    let env1_pa = crate::lower::types::bind_f(&crate::lower::types::bind_f(env_p1, &crate::prelude::Text::lit("key"), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(key_name_p8.clone()), crate::lower::types::Holding::Owned, kt_pg.clone())), &crate::prelude::Text::lit("_"), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(val_name_p9.clone()), crate::lower::types::Holding::Owned, vt_ph.clone()));
    let env2_pb = if is_array_pi {
        crate::lower::types::bind_f(&env1_pa, &crate::prelude::Text::lit("ix"), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(key_name_p8.clone()), crate::lower::types::Holding::Owned, kt_pg.clone()))
    } else {
        env1_pa.clone()
    };
    let bare_name_pc = crate::prelude::Text::from(format!("b{}", &span_p5.start_p));
    let (binds_pt, env3_pu) = match binders_o2 {
        ::std::option::Option::None => (crate::prelude::Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaMut(bare_name_pc.clone())), vt_ph.clone()), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(val_name_p9.clone()))))]), crate::lower::types::bind_f(&env2_pb, &crate::prelude::Text::lit("&_"), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(bare_name_pc.clone()), crate::lower::types::Holding::Owned, vt_ph.clone()))),
        ::std::option::Option::Some(fb_po) => match &fb_po.second_o {
            ::std::option::Option::None => {
                let po_pp = crate::lower::patterns::rust_pat_f(lx_p0, &fb_po.first_p, &vty_pm, &crate::lower::types::Holding::Owned, &crate::prelude::Text::from(format!("e{}", &span_p5.start_p)));
                (crate::prelude::Array::from(vec![crate::lower::model::Do::DoLet(po_pp.pa_p.clone(), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(val_name_p9.clone()))))]), crate::lower::expr::bind_all_f(&env2_pb, &po_pp.binds_p))
            },
            ::std::option::Option::Some(second_pq) => {
                let pk_pr = crate::lower::patterns::rust_pat_f(lx_p0, &fb_po.first_p, &kty_pn, &crate::lower::types::Holding::Owned, &crate::prelude::Text::from(format!("k{}_", &span_p5.start_p)));
                let pv_ps = crate::lower::patterns::rust_pat_f(lx_p0, second_pq, &vty_pm, &crate::lower::types::Holding::Owned, &crate::prelude::Text::from(format!("e{}", &span_p5.start_p)));
                (crate::prelude::Array::from(vec![crate::lower::model::Do::DoLet(pk_pr.pa_p.clone(), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(key_name_p8.clone())))), crate::lower::model::Do::DoLet(pv_ps.pa_p.clone(), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(val_name_p9.clone()))))]), crate::lower::expr::bind_all_f(&crate::lower::expr::bind_all_f(&env2_pb, &pk_pr.binds_p), &pv_ps.binds_p))
            },
        },
    };
    let (dos_pv, _) = upd_stmts_f(lx_p0, &env3_pu, &body_p4.stmts_p);
    if is_array_pi {
        {
            let head_p10 = crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(key_name_p8.clone()), crate::lower::model::Ex::XCall(crate::lower::helper_ref_f(&crate::prelude::Text::lit("nat_of")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XVar(crate::prelude::Text::from(format!("i{}", &span_p5.start_p)))])));
            crate::lower::model::Do::DoFor(crate::lower::model::Pa::PaTuple(crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(crate::prelude::Text::from(format!("i{}", &span_p5.start_p))), crate::lower::model::Pa::PaBind(val_name_p9.clone())])), crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(src_p7.clone()), crate::prelude::Text::lit("into_iter"), crate::prelude::Array::new())), crate::prelude::Text::lit("enumerate"), crate::prelude::Array::new()), crate::prelude::append(&crate::prelude::push(&crate::prelude::Array::new(), &head_p10), &crate::prelude::append(&binds_pt, &dos_pv)))
        }
    } else {
        crate::lower::model::Do::DoFor(crate::lower::model::Pa::PaTuple(crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(key_name_p8.clone()), crate::lower::model::Pa::PaBind(val_name_p9.clone())])), crate::lower::model::Ex::XMethod(::std::rc::Rc::new(src_p7.clone()), crate::prelude::Text::lit("into_iter"), crate::prelude::Array::new()), crate::prelude::append(&binds_pt, &dos_pv))
    }
}

/// The step machine of `UpdForValues`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UpdForValues: unbounded fn Lx, Env, ?ForBinders, Expr, Block, Range, Ty -> Do
/// ```
pub struct UpdForValues {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub binders_o2: ::std::option::Option<crate::syntax::ForBinders>,
    pub source_p3: crate::syntax::Expr,
    pub body_p4: crate::syntax::Block,
    pub span_p5: crate::syntax::Range,
    pub sty_p6: crate::check::types::Ty,
}

impl ::prism_rtl::Job<crate::lower::model::Do> for UpdForValues {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::lower::model::Do> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let binders_o2 = &self.binders_o2;
        let source_p3 = &self.source_p3;
        let body_p4 = &self.body_p4;
        let span_p5 = &self.span_p5;
        let sty_p6 = &self.sty_p6;
        let binders_o2x = binders_o2.clone();
        let body_p4x = body_p4.clone();
        let env_p1x = env_p1.clone();
        let lx_p0x = lx_p0.clone();
        let source_p3x = source_p3.clone();
        let span_p5x = span_p5.clone();
        let sty_p6x = sty_p6.clone();
        crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p0x.clone(), env_p1x.clone(), source_p3x.clone()), move |value_of_f_15445: crate::lower::types::Vl| {
            let src_p7 = crate::lower::types::own_f(&crate::lower::types::plain_value_f(&value_of_f_15445));
            let binders_o2xz = binders_o2x.clone();
            let body_p4xz = body_p4x.clone();
            let env_p1xz = env_p1x.clone();
            let lx_p0xz = lx_p0x.clone();
            let span_p5xz = span_p5x.clone();
            let src_p7z = src_p7.clone();
            let sty_p6xz = sty_p6x.clone();
            let k_let15475 = move |v15475: (crate::lower::model::OutTy, crate::lower::model::OutTy, bool)| {
                let (kt_pg, vt_ph, is_array_pi) = v15475;
                let (vty_pm, kty_pn) = match &sty_p6xz {
                    crate::check::types::Ty::TyArray(v_pj) => ((**v_pj).clone(), crate::check::types::Ty::TyCon(crate::prelude::Text::lit("Nat"), crate::prelude::Array::new())),
                    crate::check::types::Ty::TyMap(k_pk, v_pl) => ((**v_pl).clone(), (**k_pk).clone()),
                    _ => (crate::check::types::Ty::TyErr, crate::check::types::Ty::TyErr),
                };
                let key_name_p8 = crate::prelude::Text::from(format!("k{}", &span_p5xz.start_p));
                let val_name_p9 = crate::prelude::Text::from(format!("v{}", &span_p5xz.start_p));
                let env1_pa = crate::lower::types::bind_f(&crate::lower::types::bind_f(&env_p1xz, &crate::prelude::Text::lit("key"), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(key_name_p8.clone()), crate::lower::types::Holding::Owned, kt_pg.clone())), &crate::prelude::Text::lit("_"), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(val_name_p9.clone()), crate::lower::types::Holding::Owned, vt_ph.clone()));
                let env2_pb = if is_array_pi {
                    crate::lower::types::bind_f(&env1_pa, &crate::prelude::Text::lit("ix"), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(key_name_p8.clone()), crate::lower::types::Holding::Owned, kt_pg.clone()))
                } else {
                    env1_pa.clone()
                };
                let bare_name_pc = crate::prelude::Text::from(format!("b{}", &span_p5xz.start_p));
                let body_p4xzz = body_p4xz.clone();
                let is_array_piz = is_array_pi;
                let key_name_p8z = key_name_p8.clone();
                let lx_p0xzz = lx_p0xz.clone();
                let span_p5xzz = span_p5xz.clone();
                let src_p7zz = src_p7z.clone();
                let val_name_p9z = val_name_p9.clone();
                let k_let16266 = move |v16266: (crate::prelude::Array<crate::lower::model::Do>, crate::lower::types::Env)| {
                    let (binds_pt, env3_pu) = v16266;
                    crate::prelude::call_then(start_upd_stmts_f(lx_p0xzz.clone(), env3_pu.clone(), body_p4xzz.stmts_p.clone()), move |upd_stmts_f_17007: (crate::prelude::Array<crate::lower::model::Do>, crate::lower::types::Env)| {
                        let (dos_pv, _) = upd_stmts_f_17007;
                        if is_array_piz {
                            {
                                let head_p10 = crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(key_name_p8z.clone()), crate::lower::model::Ex::XCall(crate::lower::helper_ref_f(&crate::prelude::Text::lit("nat_of")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XVar(crate::prelude::Text::from(format!("i{}", &span_p5xzz.start_p)))])));
                                ::prism_rtl::Turn::Finished(crate::lower::model::Do::DoFor(crate::lower::model::Pa::PaTuple(crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(crate::prelude::Text::from(format!("i{}", &span_p5xzz.start_p))), crate::lower::model::Pa::PaBind(val_name_p9z.clone())])), crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(src_p7zz.clone()), crate::prelude::Text::lit("into_iter"), crate::prelude::Array::new())), crate::prelude::Text::lit("enumerate"), crate::prelude::Array::new()), crate::prelude::append(&crate::prelude::push(&crate::prelude::Array::new(), &head_p10), &crate::prelude::append(&binds_pt, &dos_pv))))
                            }
                        } else {
                            ::prism_rtl::Turn::Finished(crate::lower::model::Do::DoFor(crate::lower::model::Pa::PaTuple(crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(key_name_p8z.clone()), crate::lower::model::Pa::PaBind(val_name_p9z.clone())])), crate::lower::model::Ex::XMethod(::std::rc::Rc::new(src_p7zz.clone()), crate::prelude::Text::lit("into_iter"), crate::prelude::Array::new()), crate::prelude::append(&binds_pt, &dos_pv)))
                        }
                    })
                };
                match binders_o2xz.clone() {
                    ::std::option::Option::None => k_let16266((crate::prelude::Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaMut(bare_name_pc.clone())), vt_ph.clone()), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(val_name_p9.clone()))))]), crate::lower::types::bind_f(&env2_pb, &crate::prelude::Text::lit("&_"), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(bare_name_pc.clone()), crate::lower::types::Holding::Owned, vt_ph.clone())))),
                    ::std::option::Option::Some(fb_po) => match fb_po.second_o.clone() {
                        ::std::option::Option::None => crate::prelude::call_then(crate::lower::patterns::start_rust_pat_f(lx_p0xz.clone(), fb_po.first_p.clone(), vty_pm.clone(), crate::lower::types::Holding::Owned, crate::prelude::Text::from(format!("e{}", &span_p5xz.start_p))), move |rust_pat_f_16520: crate::lower::patterns::PatOut| {
                            let po_pp = rust_pat_f_16520;
                            k_let16266((crate::prelude::Array::from(vec![crate::lower::model::Do::DoLet(po_pp.pa_p.clone(), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(val_name_p9.clone()))))]), crate::lower::expr::bind_all_f(&env2_pb, &po_pp.binds_p)))
                        }),
                        ::std::option::Option::Some(second_pq) => crate::prelude::call_then(crate::lower::patterns::start_rust_pat_f(lx_p0xz.clone(), fb_po.first_p.clone(), kty_pn.clone(), crate::lower::types::Holding::Owned, crate::prelude::Text::from(format!("k{}_", &span_p5xz.start_p))), move |rust_pat_f_16706: crate::lower::patterns::PatOut| {
                            let pk_pr = rust_pat_f_16706;
                            crate::prelude::call_then(crate::lower::patterns::start_rust_pat_f(lx_p0xz.clone(), second_pq.clone(), vty_pm.clone(), crate::lower::types::Holding::Owned, crate::prelude::Text::from(format!("e{}", &span_p5xz.start_p))), move |rust_pat_f_16782: crate::lower::patterns::PatOut| {
                                let pv_ps = rust_pat_f_16782;
                                k_let16266((crate::prelude::Array::from(vec![crate::lower::model::Do::DoLet(pk_pr.pa_p.clone(), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(key_name_p8.clone())))), crate::lower::model::Do::DoLet(pv_ps.pa_p.clone(), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(val_name_p9.clone()))))]), crate::lower::expr::bind_all_f(&crate::lower::expr::bind_all_f(&env2_pb, &pk_pr.binds_p), &pv_ps.binds_p)))
                            })
                        }),
                    },
                }
            };
            match sty_p6x.clone() {
                crate::check::types::Ty::TyArray(v_pd) => crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0x.clone(), (*v_pd).clone()), move |out_ty_of_f_15542: crate::lower::model::OutTy| k_let15475((crate::lower::model::OutTy::OutNat, out_ty_of_f_15542, true))),
                crate::check::types::Ty::TyMap(k_pe, v_pf) => crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0x.clone(), (*k_pe).clone()), move |out_ty_of_f_15588: crate::lower::model::OutTy| crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0x.clone(), (*v_pf).clone()), move |out_ty_of_f_15605: crate::lower::model::OutTy| k_let15475((out_ty_of_f_15588, out_ty_of_f_15605, false)))),
                _ => k_let15475((crate::lower::model::OutTy::OutUnit, crate::lower::model::OutTy::OutUnit, true)),
            }
        })
    }
}

/// `Start UpdForValues, x`: what the function value is when passed to `@Run`.
pub fn start_upd_for_values_f(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, binders_o2: ::std::option::Option<crate::syntax::ForBinders>, source_p3: crate::syntax::Expr, body_p4: crate::syntax::Block, span_p5: crate::syntax::Range, sty_p6: crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Do>> {
    ::std::rc::Rc::new(UpdForValues { lx_p0, env_p1, binders_o2, source_p3, body_p4, span_p5, sty_p6 })
}

/// ```prism
/// UpdIf: unbounded fn Lx, Env, Cond, Block, ?Block -> Do
/// ```
pub fn upd_if_f(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, c_p2: &crate::syntax::Cond, then_b_p3: &crate::syntax::Block, else_b_o4: &::std::option::Option<crate::syntax::Block>) -> crate::lower::model::Do {
    let (else_dos_p6, _) = match else_b_o4 {
        ::std::option::Option::Some(b_p5) => upd_stmts_f(lx_p0, env_p1, &b_p5.stmts_p),
        ::std::option::Option::None => (crate::prelude::Array::new(), env_p1.clone()),
    };
    match c_p2 {
        crate::syntax::Cond::CondExpr(x_p7) => {
            let (then_dos_p8, _) = upd_stmts_f(lx_p0, env_p1, &then_b_p3.stmts_p);
            crate::lower::model::Do::DoIf(crate::lower::types::as_bool_f(&crate::lower::expr::value_of_f(lx_p0, env_p1, &**x_p7)), then_dos_p8.clone(), else_dos_p6.clone())
        },
        crate::syntax::Cond::CondBind(p_p9, x_pa, _) => {
            let po_pb = crate::lower::patterns::rust_pat_f(lx_p0, p_p9, &crate::lower::type_at_f(lx_p0, &x_pa.span_p), &crate::lower::types::Holding::Owned, &crate::prelude::Text::from(format!("u{}", &x_pa.span_p.start_p)));
            let (then_dos_pc, _) = upd_stmts_f(lx_p0, &crate::lower::expr::bind_all_f(env_p1, &po_pb.binds_p), &then_b_p3.stmts_p);
            if &crate::prelude::len(&po_pb.conds_p) == &crate::prelude::Nat::from(0u32) {
                crate::lower::model::Do::DoIfLet(po_pb.pa_p.clone(), crate::lower::types::own_f(&crate::lower::expr::value_of_f(lx_p0, env_p1, &**x_pa)), then_dos_pc.clone(), else_dos_p6.clone())
            } else {
                crate::lower::model::Do::DoExpr(crate::lower::types::own_f(&crate::lower::expr::arms_value_f(&crate::lower::types::own_f(&crate::lower::expr::value_of_f(lx_p0, env_p1, &**x_pa)), &crate::prelude::Array::from(vec![crate::lower::model::XArm { pat_p: po_pb.pa_p.clone(), conds_p: po_pb.conds_p.clone(), body_p: crate::lower::model::Ex::XBlock(then_dos_pc.clone(), ::std::rc::Rc::new(crate::lower::model::Ex::XUnit)) }, crate::lower::model::XArm { pat_p: crate::lower::model::Pa::PaWild, conds_p: crate::prelude::Array::new(), body_p: crate::lower::model::Ex::XBlock(else_dos_p6.clone(), ::std::rc::Rc::new(crate::lower::model::Ex::XUnit)) }]), &crate::prelude::Text::from(format!("\'u{}", &x_pa.span_p.start_p)), &crate::lower::model::OutTy::OutUnit)))
            }
        },
    }
}

/// The step machine of `UpdIf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UpdIf: unbounded fn Lx, Env, Cond, Block, ?Block -> Do
/// ```
pub struct UpdIf {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub c_p2: crate::syntax::Cond,
    pub then_b_p3: crate::syntax::Block,
    pub else_b_o4: ::std::option::Option<crate::syntax::Block>,
}

impl ::prism_rtl::Job<crate::lower::model::Do> for UpdIf {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::lower::model::Do> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let c_p2 = &self.c_p2;
        let then_b_p3 = &self.then_b_p3;
        let else_b_o4 = &self.else_b_o4;
        let c_p2z = c_p2.clone();
        let env_p1z = env_p1.clone();
        let lx_p0z = lx_p0.clone();
        let then_b_p3z = then_b_p3.clone();
        let k_let17552 = move |v17552: (crate::prelude::Array<crate::lower::model::Do>, crate::lower::types::Env)| {
            let (else_dos_p6, _) = v17552;
            match &c_p2z {
                crate::syntax::Cond::CondExpr(x_p7) => {
                    let x_p7x = (**x_p7).clone();
                    crate::prelude::call_then(start_upd_stmts_f(lx_p0z.clone(), env_p1z.clone(), then_b_p3z.stmts_p.clone()), move |upd_stmts_f_17729: (crate::prelude::Array<crate::lower::model::Do>, crate::lower::types::Env)| {
                        let (then_dos_p8, _) = upd_stmts_f_17729;
                        crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p0z.clone(), env_p1z.clone(), x_p7x.clone()), move |value_of_f_17785: crate::lower::types::Vl| ::prism_rtl::Turn::Finished(crate::lower::model::Do::DoIf(crate::lower::types::as_bool_f(&value_of_f_17785), then_dos_p8.clone(), else_dos_p6.clone())))
                    })
                },
                crate::syntax::Cond::CondBind(p_p9, x_pa, _) => {
                    let p_p9x = p_p9.clone();
                    let x_pax = (**x_pa).clone();
                    crate::prelude::call_then(crate::lower::patterns::start_rust_pat_f(lx_p0z.clone(), p_p9x.clone(), crate::lower::type_at_f(&lx_p0z, &x_pax.span_p), crate::lower::types::Holding::Owned, crate::prelude::Text::from(format!("u{}", &x_pax.span_p.start_p))), move |rust_pat_f_17876: crate::lower::patterns::PatOut| {
                        let po_pb = rust_pat_f_17876;
                        crate::prelude::call_then(start_upd_stmts_f(lx_p0z.clone(), crate::lower::expr::bind_all_f(&env_p1z, &po_pb.binds_p), then_b_p3z.stmts_p.clone()), move |upd_stmts_f_17975: (crate::prelude::Array<crate::lower::model::Do>, crate::lower::types::Env)| {
                            let (then_dos_pc, _) = upd_stmts_f_17975;
                            if &crate::prelude::len(&po_pb.conds_p) == &crate::prelude::Nat::from(0u32) {
                                crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p0z.clone(), env_p1z.clone(), x_pax.clone()), move |value_of_f_18225: crate::lower::types::Vl| ::prism_rtl::Turn::Finished(crate::lower::model::Do::DoIfLet(po_pb.pa_p.clone(), crate::lower::types::own_f(&value_of_f_18225), then_dos_pc.clone(), else_dos_p6.clone())))
                            } else {
                                crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p0z.clone(), env_p1z.clone(), x_pax.clone()), move |value_of_f_18311: crate::lower::types::Vl| ::prism_rtl::Turn::Finished(crate::lower::model::Do::DoExpr(crate::lower::types::own_f(&crate::lower::expr::arms_value_f(&crate::lower::types::own_f(&value_of_f_18311), &crate::prelude::Array::from(vec![crate::lower::model::XArm { pat_p: po_pb.pa_p.clone(), conds_p: po_pb.conds_p.clone(), body_p: crate::lower::model::Ex::XBlock(then_dos_pc.clone(), ::std::rc::Rc::new(crate::lower::model::Ex::XUnit)) }, crate::lower::model::XArm { pat_p: crate::lower::model::Pa::PaWild, conds_p: crate::prelude::Array::new(), body_p: crate::lower::model::Ex::XBlock(else_dos_p6.clone(), ::std::rc::Rc::new(crate::lower::model::Ex::XUnit)) }]), &crate::prelude::Text::from(format!("\'u{}", &x_pax.span_p.start_p)), &crate::lower::model::OutTy::OutUnit)))))
                            }
                        })
                    })
                },
            }
        };
        match else_b_o4.clone() {
            ::std::option::Option::Some(b_p5) => {
                let env_p1x = env_p1.clone();
                let lx_p0x = lx_p0.clone();
                crate::prelude::call_then(start_upd_stmts_f(lx_p0x.clone(), env_p1x.clone(), b_p5.stmts_p.clone()), move |upd_stmts_f_17605: (crate::prelude::Array<crate::lower::model::Do>, crate::lower::types::Env)| k_let17552(upd_stmts_f_17605))
            },
            ::std::option::Option::None => k_let17552((crate::prelude::Array::new(), env_p1.clone())),
        }
    }
}

/// `Start UpdIf, x`: what the function value is when passed to `@Run`.
pub fn start_upd_if_f(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, c_p2: crate::syntax::Cond, then_b_p3: crate::syntax::Block, else_b_o4: ::std::option::Option<crate::syntax::Block>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Do>> {
    ::std::rc::Rc::new(UpdIf { lx_p0, env_p1, c_p2, then_b_p3, else_b_o4 })
}

/// ```prism
/// UpdMatch: unbounded fn Lx, Env, Expr, [Arm] -> Do
/// ```
pub fn upd_match_f(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, scrut_p2: &crate::syntax::Expr, arms_p3: &crate::prelude::Array<crate::syntax::Arm>) -> crate::lower::model::Do {
    let sv_p4 = crate::lower::expr::value_of_f(lx_p0, env_p1, scrut_p2);
    let sty_p5 = crate::lower::type_at_f(lx_p0, &scrut_p2.span_p);
    let arms3_p6 = crate::prelude::run_to_end(crate::prelude::each_job(crate::check::errors::range0_f(&crate::prelude::len(arms_p3)), {
        let arms_p3x = arms_p3.clone();
        let lx_p0x = lx_p0.clone();
        let sty_p5x = sty_p5.clone();
        let scrut_p2x = scrut_p2.clone();
        let env_p1x = env_p1.clone();
        ::std::rc::Rc::new(move |p0: crate::prelude::Nat| {
            let arms_p3xy = arms_p3x.clone();
            let lx_p0xy = lx_p0x.clone();
            let sty_p5xy = sty_p5x.clone();
            let scrut_p2xy = scrut_p2x.clone();
            let env_p1xy = env_p1x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let i_p7 = p0;
                {
                    let arm_p8 = crate::prelude::or(&crate::prelude::index(&arms_p3xy, &i_p7), &crate::lower::expr::dummy_arm_p());
                    crate::prelude::call_then(crate::lower::expr::start_arm_pat_f(lx_p0xy.clone(), arm_p8.pattern_o.clone(), sty_p5xy.clone(), crate::lower::types::Holding::ByRef, crate::prelude::Text::from(format!("u{}_{}", &scrut_p2xy.span_p.start_p, &i_p7))), move |arm_pat_f_18754: crate::lower::patterns::PatOut| {
                        let po_p9 = arm_pat_f_18754;
                        crate::prelude::call_then(start_upd_stmts_f(lx_p0xy.clone(), crate::lower::expr::bind_all_f(&env_p1xy, &po_p9.binds_p), arm_p8.body_p.stmts_p.clone()), move |upd_stmts_f_18847: (crate::prelude::Array<crate::lower::model::Do>, crate::lower::types::Env)| {
                            let (dos_pb, _) = upd_stmts_f_18847;
                            crate::prelude::call_then(start_guard_conds_f(lx_p0xy.clone(), crate::lower::expr::bind_all_f(&env_p1xy, &po_p9.binds_p), arm_p8.guard_o.clone()), move |guard_conds_f_18940: crate::prelude::Array<crate::lower::model::Cc>| {
                                let guarded_pa = crate::prelude::append(&po_p9.conds_p, &guard_conds_f_18940);
                                ::prism_rtl::Turn::Finished(crate::lower::model::XArm { pat_p: po_p9.pa_p.clone(), conds_p: guarded_pa.clone(), body_p: crate::lower::model::Ex::XBlock(dos_pb.clone(), ::std::rc::Rc::new(crate::lower::model::Ex::XUnit)) })
                            })
                        })
                    })
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::XArm>>>
    }));
    if crate::prelude::fold(&arms3_p6, &false, &(|f_pc: &bool, a_pd: &crate::lower::model::XArm| *f_pc || (&crate::prelude::len(&a_pd.conds_p) > &crate::prelude::Nat::from(0u32)))) {
        crate::lower::model::Do::DoExpr(crate::lower::types::own_f(&crate::lower::expr::arms_value_f(&crate::lower::types::ref_f(&sv_p4), &arms3_p6, &crate::prelude::Text::from(format!("\'u{}", &scrut_p2.span_p.start_p)), &crate::lower::model::OutTy::OutUnit)))
    } else {
        crate::lower::model::Do::DoMatch(crate::lower::types::ref_f(&sv_p4), crate::prelude::each(&arms3_p6, &(|a_pe: &crate::lower::model::XArm| (a_pe.pat_p.clone(), arm_dos_f(&a_pe.body_p)))))
    }
}

/// The step machine of `UpdMatch`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UpdMatch: unbounded fn Lx, Env, Expr, [Arm] -> Do
/// ```
pub struct UpdMatch {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub scrut_p2: crate::syntax::Expr,
    pub arms_p3: crate::prelude::Array<crate::syntax::Arm>,
}

impl ::prism_rtl::Job<crate::lower::model::Do> for UpdMatch {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::lower::model::Do> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let scrut_p2 = &self.scrut_p2;
        let arms_p3 = &self.arms_p3;
        let arms_p3x = arms_p3.clone();
        let env_p1x = env_p1.clone();
        let lx_p0x = lx_p0.clone();
        let scrut_p2x = scrut_p2.clone();
        crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p0x.clone(), env_p1x.clone(), scrut_p2x.clone()), move |value_of_f_18592: crate::lower::types::Vl| {
            let sv_p4 = value_of_f_18592;
            let sty_p5 = crate::lower::type_at_f(&lx_p0x, &scrut_p2x.span_p);
            crate::prelude::call_value(crate::prelude::each_job(crate::check::errors::range0_f(&crate::prelude::len(&arms_p3x)), {
                let arms_p3xx = arms_p3x.clone();
                let lx_p0xx = lx_p0x.clone();
                let sty_p5x = sty_p5.clone();
                let scrut_p2xx = scrut_p2x.clone();
                let env_p1xx = env_p1x.clone();
                ::std::rc::Rc::new(move |p0: crate::prelude::Nat| {
                    let arms_p3xxy = arms_p3xx.clone();
                    let lx_p0xxy = lx_p0xx.clone();
                    let sty_p5xy = sty_p5x.clone();
                    let scrut_p2xxy = scrut_p2xx.clone();
                    let env_p1xxy = env_p1xx.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let i_p7 = p0;
                        {
                            let arm_p8 = crate::prelude::or(&crate::prelude::index(&arms_p3xxy, &i_p7), &crate::lower::expr::dummy_arm_p());
                            crate::prelude::call_then(crate::lower::expr::start_arm_pat_f(lx_p0xxy.clone(), arm_p8.pattern_o.clone(), sty_p5xy.clone(), crate::lower::types::Holding::ByRef, crate::prelude::Text::from(format!("u{}_{}", &scrut_p2xxy.span_p.start_p, &i_p7))), move |arm_pat_f_18754: crate::lower::patterns::PatOut| {
                                let po_p9 = arm_pat_f_18754;
                                crate::prelude::call_then(start_upd_stmts_f(lx_p0xxy.clone(), crate::lower::expr::bind_all_f(&env_p1xxy, &po_p9.binds_p), arm_p8.body_p.stmts_p.clone()), move |upd_stmts_f_18847: (crate::prelude::Array<crate::lower::model::Do>, crate::lower::types::Env)| {
                                    let (dos_pb, _) = upd_stmts_f_18847;
                                    crate::prelude::call_then(start_guard_conds_f(lx_p0xxy.clone(), crate::lower::expr::bind_all_f(&env_p1xxy, &po_p9.binds_p), arm_p8.guard_o.clone()), move |guard_conds_f_18940: crate::prelude::Array<crate::lower::model::Cc>| {
                                        let guarded_pa = crate::prelude::append(&po_p9.conds_p, &guard_conds_f_18940);
                                        ::prism_rtl::Turn::Finished(crate::lower::model::XArm { pat_p: po_p9.pa_p.clone(), conds_p: guarded_pa.clone(), body_p: crate::lower::model::Ex::XBlock(dos_pb.clone(), ::std::rc::Rc::new(crate::lower::model::Ex::XUnit)) })
                                    })
                                })
                            })
                        }
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::XArm>>>
            }), move |each_18667: crate::prelude::Array<crate::lower::model::XArm>| {
                let arms3_p6 = each_18667;
                if crate::prelude::fold(&arms3_p6, &false, &(|f_pc: &bool, a_pd: &crate::lower::model::XArm| *f_pc || (&crate::prelude::len(&a_pd.conds_p) > &crate::prelude::Nat::from(0u32)))) {
                    ::prism_rtl::Turn::Finished(crate::lower::model::Do::DoExpr(crate::lower::types::own_f(&crate::lower::expr::arms_value_f(&crate::lower::types::ref_f(&sv_p4), &arms3_p6, &crate::prelude::Text::from(format!("\'u{}", &scrut_p2x.span_p.start_p)), &crate::lower::model::OutTy::OutUnit))))
                } else {
                    ::prism_rtl::Turn::Finished(crate::lower::model::Do::DoMatch(crate::lower::types::ref_f(&sv_p4), crate::prelude::each(&arms3_p6, &(|a_pe: &crate::lower::model::XArm| (a_pe.pat_p.clone(), arm_dos_f(&a_pe.body_p))))))
                }
            })
        })
    }
}

/// `Start UpdMatch, x`: what the function value is when passed to `@Run`.
pub fn start_upd_match_f(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, scrut_p2: crate::syntax::Expr, arms_p3: crate::prelude::Array<crate::syntax::Arm>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Do>> {
    ::std::rc::Rc::new(UpdMatch { lx_p0, env_p1, scrut_p2, arms_p3 })
}

/// ```prism
/// ArmDos: fn Ex -> [Do]
/// ```
pub fn arm_dos_f(ex0: &crate::lower::model::Ex) -> crate::prelude::Array<crate::lower::model::Do> {
    match ex0 {
        crate::lower::model::Ex::XBlock(dos_p0, _) => dos_p0.clone(),
        x_p1 => crate::prelude::Array::from(vec![crate::lower::model::Do::DoExpr(x_p1.clone())]),
    }
}

/// ```prism
/// GuardConds: unbounded fn Lx, Env, ?Expr -> [Cc]
/// ```
pub fn guard_conds_f(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, opt2: &::std::option::Option<crate::syntax::Expr>) -> crate::prelude::Array<crate::lower::model::Cc> {
    match opt2 {
        ::std::option::Option::Some(ge_p2) => crate::prelude::Array::from(vec![crate::lower::model::Cc::CcIf(crate::lower::types::as_bool_f(&crate::lower::expr::value_of_f(lx_p0, env_p1, ge_p2)))]),
        ::std::option::Option::None => crate::prelude::Array::new(),
    }
}

/// The step machine of `GuardConds`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// GuardConds: unbounded fn Lx, Env, ?Expr -> [Cc]
/// ```
pub struct GuardConds {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub opt2: ::std::option::Option<crate::syntax::Expr>,
}

impl ::prism_rtl::Job<crate::prelude::Array<crate::lower::model::Cc>> for GuardConds {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<crate::lower::model::Cc>> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let opt2 = &self.opt2;
        match opt2 {
            ::std::option::Option::Some(ge_p2) => {
                let env_p1x = env_p1.clone();
                let ge_p2x = ge_p2.clone();
                let lx_p0x = lx_p0.clone();
                crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p0x.clone(), env_p1x.clone(), ge_p2x.clone()), move |value_of_f_19621: crate::lower::types::Vl| ::prism_rtl::Turn::Finished(crate::prelude::Array::from(vec![crate::lower::model::Cc::CcIf(crate::lower::types::as_bool_f(&value_of_f_19621))])))
            },
            ::std::option::Option::None => ::prism_rtl::Turn::Finished(crate::prelude::Array::new()),
        }
    }
}

/// `Start GuardConds, x`: what the function value is when passed to `@Run`.
pub fn start_guard_conds_f(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, opt2: ::std::option::Option<crate::syntax::Expr>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::lower::model::Cc>>> {
    ::std::rc::Rc::new(GuardConds { lx_p0, env_p1, opt2 })
}

/// ```prism
/// PlaceOf: unbounded fn Lx, Env, Expr -> Ex
/// ```
pub fn place_of_f(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, e_p2: &crate::syntax::Expr) -> crate::lower::model::Ex {
    match &*e_p2.kind_p {
        crate::syntax::ExprKind::EName(n_p3) => match crate::prelude::get(&env_p1.names_p, &crate::check::env::sname_key_f(n_p3)) {
            ::std::option::Option::Some(crate::lower::types::Bn::BnLocal(rs_p4, _, _)) => rs_p4,
            _ => crate::lower::model::Ex::XVar(crate::lower::snake_f(&crate::check::env::sname_key_f(n_p3))),
        },
        crate::syntax::ExprKind::EField(r_p5, _, name_p6) => {
            let rty_p7 = crate::lower::types::peel_f(&place_ty_f(lx_p0, &**r_p5));
            let (_, _, f_p8) = crate::lower::expr::field_info_f(lx_p0, &rty_p7, &name_p6.name_p);
            crate::lower::expr::field_of_ex_f(lx_p0, &place_of_f(lx_p0, env_p1, &**r_p5), &rty_p7, &f_p8)
        },
        crate::syntax::ExprKind::EIndex(r_p9, k_pa) => {
            let rt_pb = crate::lower::types::collection_out_f(&crate::lower::types::out_ty_of_f(lx_p0, &crate::lower::types::peel_f(&place_ty_f(lx_p0, &**r_p9))));
            let f_pc = match &rt_pb {
                crate::lower::model::OutTy::OutMap(_, _) => crate::lower::helper_ref_f(&crate::prelude::Text::lit("at_mut_map")),
                _ => crate::lower::helper_ref_f(&crate::prelude::Text::lit("at_mut")),
            };
            crate::lower::model::Ex::XDeref(::std::rc::Rc::new(crate::lower::model::Ex::XCall(f_pc.clone(), crate::prelude::Array::from(vec![crate::lower::model::Ex::XRefMut(::std::rc::Rc::new(place_of_f(lx_p0, env_p1, &**r_p9))), crate::lower::expr::argument_f(lx_p0, env_p1, &**k_pa)]))))
        },
        crate::syntax::ExprKind::EGroup(x_pd) => place_of_f(lx_p0, env_p1, &**x_pd),
        _ => match lens_call_o(lx_p0, e_p2) {
            ::std::option::Option::Some((qk_pe, argument_pf)) => if lens_ends_at_index_f(lx_p0, &qk_pe, &crate::prelude::len(&lx_p0.g_p.defs_p)) {
                crate::lower::expr::internal_bug_f(&crate::prelude::Text::lit("the place of a lens that ends at an index, which is set and read whole"))
            } else {
                crate::lower::model::Ex::XTarget(::std::rc::Rc::new(lens_call_ex_f(lx_p0, env_p1, &qk_pe, &argument_pf)))
            },
            ::std::option::Option::None => crate::lower::expr::internal_bug_f(&crate::prelude::Text::lit("a reference path this back end does not lower")),
        },
    }
}

/// The step machine of `PlaceOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PlaceOf: unbounded fn Lx, Env, Expr -> Ex
/// ```
pub struct PlaceOf {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub e_p2: crate::syntax::Expr,
}

impl ::prism_rtl::Job<crate::lower::model::Ex> for PlaceOf {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::lower::model::Ex> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let e_p2 = &self.e_p2;
        match &*e_p2.kind_p {
            crate::syntax::ExprKind::EName(n_p3) => match crate::prelude::get(&env_p1.names_p, &crate::check::env::sname_key_f(n_p3)) {
                ::std::option::Option::Some(crate::lower::types::Bn::BnLocal(rs_p4, _, _)) => ::prism_rtl::Turn::Finished(rs_p4.clone()),
                _ => ::prism_rtl::Turn::Finished(crate::lower::model::Ex::XVar(crate::lower::snake_f(&crate::check::env::sname_key_f(n_p3)))),
            },
            crate::syntax::ExprKind::EField(r_p5, _, name_p6) => {
                let env_p1x = env_p1.clone();
                let lx_p0x = lx_p0.clone();
                let name_p6x = name_p6.clone();
                let r_p5x = (**r_p5).clone();
                crate::prelude::call_then(start_place_ty_f(lx_p0x.clone(), r_p5x.clone()), move |place_ty_f_20005: crate::check::types::Ty| {
                    let rty_p7 = crate::lower::types::peel_f(&place_ty_f_20005);
                    crate::prelude::call_then(crate::lower::expr::start_field_info_f(lx_p0x.clone(), rty_p7.clone(), name_p6x.name_p.clone()), move |field_info_f_20056: (crate::lower::model::OutTy, bool, crate::prelude::Text)| {
                        let (_, _, f_p8) = field_info_f_20056;
                        crate::prelude::call_then(start_place_of_f(lx_p0x.clone(), env_p1x.clone(), r_p5x.clone()), move |place_of_f_20108: crate::lower::model::Ex| ::prism_rtl::Turn::Finished(crate::lower::expr::field_of_ex_f(&lx_p0x, &place_of_f_20108, &rty_p7, &f_p8)))
                    })
                })
            },
            crate::syntax::ExprKind::EIndex(r_p9, k_pa) => {
                let env_p1x = env_p1.clone();
                let k_pax = (**k_pa).clone();
                let lx_p0x = lx_p0.clone();
                let r_p9x = (**r_p9).clone();
                crate::prelude::call_then(start_place_ty_f(lx_p0x.clone(), r_p9x.clone()), move |place_ty_f_20204: crate::check::types::Ty| crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0x.clone(), crate::lower::types::peel_f(&place_ty_f_20204)), move |out_ty_of_f_20185: crate::lower::model::OutTy| {
                    let rt_pb = crate::lower::types::collection_out_f(&out_ty_of_f_20185);
                    let f_pc = match &rt_pb {
                        crate::lower::model::OutTy::OutMap(_, _) => crate::lower::helper_ref_f(&crate::prelude::Text::lit("at_mut_map")),
                        _ => crate::lower::helper_ref_f(&crate::prelude::Text::lit("at_mut")),
                    };
                    crate::prelude::call_then(start_place_of_f(lx_p0x.clone(), env_p1x.clone(), r_p9x.clone()), move |place_of_f_20384: crate::lower::model::Ex| crate::prelude::call_then(crate::lower::expr::start_argument_f(lx_p0x.clone(), env_p1x.clone(), k_pax.clone()), move |argument_f_20407: crate::lower::model::Ex| ::prism_rtl::Turn::Finished(crate::lower::model::Ex::XDeref(::std::rc::Rc::new(crate::lower::model::Ex::XCall(f_pc.clone(), crate::prelude::Array::from(vec![crate::lower::model::Ex::XRefMut(::std::rc::Rc::new(place_of_f_20384)), argument_f_20407])))))))
                }))
            },
            crate::syntax::ExprKind::EGroup(x_pd) => ::prism_rtl::Turn::More(::std::rc::Rc::new(PlaceOf { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), e_p2: (**x_pd).clone() })),
            _ => {
                let e_p2x = e_p2.clone();
                let env_p1x = env_p1.clone();
                let lx_p0x = lx_p0.clone();
                crate::prelude::call_then(start_lens_call_o(lx_p0x.clone(), e_p2x.clone()), move |lens_call_o_20558: ::std::option::Option<(crate::prelude::Text, crate::syntax::Expr)>| match lens_call_o_20558 {
                    ::std::option::Option::Some((qk_pe, argument_pf)) => crate::prelude::call_then(start_lens_ends_at_index_f(lx_p0x.clone(), qk_pe.clone(), crate::prelude::len(&lx_p0x.g_p.defs_p)), move |lens_ends_at_index_f_20618: bool| if lens_ends_at_index_f_20618 {
                        ::prism_rtl::Turn::Finished(crate::lower::expr::internal_bug_f(&crate::prelude::Text::lit("the place of a lens that ends at an index, which is set and read whole")))
                    } else {
                        crate::prelude::call_then(start_lens_call_ex_f(lx_p0x.clone(), env_p1x.clone(), qk_pe.clone(), argument_pf.clone()), move |lens_call_ex_f_20771: crate::lower::model::Ex| ::prism_rtl::Turn::Finished(crate::lower::model::Ex::XTarget(::std::rc::Rc::new(lens_call_ex_f_20771))))
                    }),
                    ::std::option::Option::None => ::prism_rtl::Turn::Finished(crate::lower::expr::internal_bug_f(&crate::prelude::Text::lit("a reference path this back end does not lower"))),
                })
            },
        }
    }
}

/// `Start PlaceOf, x`: what the function value is when passed to `@Run`.
pub fn start_place_of_f(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, e_p2: crate::syntax::Expr) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>> {
    ::std::rc::Rc::new(PlaceOf { lx_p0, env_p1, e_p2 })
}

/// ```prism
/// PlaceTy: unbounded fn Lx, Expr -> Ty
/// ```
pub fn place_ty_f(lx_p0: &crate::lower::Lx, e_p1: &crate::syntax::Expr) -> crate::check::types::Ty {
    match crate::lower::type_at_f(lx_p0, &e_p1.span_p) {
        crate::check::types::Ty::TyErr => match &*e_p1.kind_p {
            crate::syntax::ExprKind::EIndex(r_p2, _) => match crate::lower::types::collection_f(&crate::lower::types::peel_f(&place_ty_f(lx_p0, &**r_p2))) {
                crate::check::types::Ty::TyArray(el_p3) => (*el_p3).clone(),
                crate::check::types::Ty::TyMap(_, v_p4) => (*v_p4).clone(),
                _ => crate::check::types::Ty::TyErr,
            },
            crate::syntax::ExprKind::EField(r_p5, _, name_p6) => field_ty_f(lx_p0, &crate::lower::types::peel_f(&place_ty_f(lx_p0, &**r_p5)), &name_p6.name_p),
            crate::syntax::ExprKind::EGroup(x_p7) => place_ty_f(lx_p0, &**x_p7),
            _ => crate::check::types::Ty::TyErr,
        },
        t_p8 => t_p8,
    }
}

/// The step machine of `PlaceTy`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PlaceTy: unbounded fn Lx, Expr -> Ty
/// ```
pub struct PlaceTy {
    pub lx_p0: crate::lower::Lx,
    pub e_p1: crate::syntax::Expr,
}

impl ::prism_rtl::Job<crate::check::types::Ty> for PlaceTy {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::types::Ty> {
        let lx_p0 = &self.lx_p0;
        let e_p1 = &self.e_p1;
        match crate::lower::type_at_f(lx_p0, &e_p1.span_p) {
            crate::check::types::Ty::TyErr => match &*e_p1.kind_p {
                crate::syntax::ExprKind::EIndex(r_p2, _) => {
                    let lx_p0x = lx_p0.clone();
                    let r_p2x = (**r_p2).clone();
                    crate::prelude::call_then(start_place_ty_f(lx_p0x.clone(), r_p2x.clone()), move |place_ty_f_21191: crate::check::types::Ty| match crate::lower::types::collection_f(&crate::lower::types::peel_f(&place_ty_f_21191)) {
                        crate::check::types::Ty::TyArray(el_p3) => ::prism_rtl::Turn::Finished((*el_p3).clone()),
                        crate::check::types::Ty::TyMap(_, v_p4) => ::prism_rtl::Turn::Finished((*v_p4).clone()),
                        _ => ::prism_rtl::Turn::Finished(crate::check::types::Ty::TyErr),
                    })
                },
                crate::syntax::ExprKind::EField(r_p5, _, name_p6) => {
                    let lx_p0x = lx_p0.clone();
                    let name_p6x = name_p6.clone();
                    let r_p5x = (**r_p5).clone();
                    crate::prelude::call_then(start_place_ty_f(lx_p0x.clone(), r_p5x.clone()), move |place_ty_f_21346: crate::check::types::Ty| ::prism_rtl::Turn::More(::std::rc::Rc::new(FieldTy { lx_p0: lx_p0x.clone(), rty_p1: crate::lower::types::peel_f(&place_ty_f_21346), name_p2: name_p6x.name_p.clone() })))
                },
                crate::syntax::ExprKind::EGroup(x_p7) => ::prism_rtl::Turn::More(::std::rc::Rc::new(PlaceTy { lx_p0: lx_p0.clone(), e_p1: (**x_p7).clone() })),
                _ => ::prism_rtl::Turn::Finished(crate::check::types::Ty::TyErr),
            },
            t_p8 => ::prism_rtl::Turn::Finished(t_p8.clone()),
        }
    }
}

/// `Start PlaceTy, x`: what the function value is when passed to `@Run`.
pub fn start_place_ty_f(lx_p0: crate::lower::Lx, e_p1: crate::syntax::Expr) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::Ty>> {
    ::std::rc::Rc::new(PlaceTy { lx_p0, e_p1 })
}

/// ```prism
/// FieldTy: unbounded fn Lx, Ty, Text -> Ty
/// ```
pub fn field_ty_f(lx_p0: &crate::lower::Lx, rty_p1: &crate::check::types::Ty, name_p2: &crate::prelude::Text) -> crate::check::types::Ty {
    match rty_p1 {
        crate::check::types::Ty::TyCon(n_p3, args_p4) => match crate::prelude::get(&lx_p0.g_p.ctors_p, n_p3) {
            ::std::option::Option::Some(c_p5) => crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(&c_p5.fields_p)), crate::check::types::Ty::TyErr, {
                let c_p5x = c_p5.clone();
                let name_p2x = name_p2.clone();
                let args_p4x = args_p4.clone();
                ::std::rc::Rc::new(move |(p0, p1): (crate::check::types::Ty, crate::prelude::Nat)| {
                    let c_p5xy = c_p5x.clone();
                    let name_p2xy = name_p2x.clone();
                    let args_p4xy = args_p4x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let found_p6 = p0;
                        let i_p7 = p1;
                        if &crate::prelude::or(&crate::prelude::index(&c_p5xy.fields_p, &i_p7), &crate::prelude::Text::lit("")) == &name_p2xy {
                            ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::lower::expr::Instantiated { t_p0: crate::prelude::or(&crate::prelude::index(&c_p5xy.args_p, &i_p7), &crate::check::types::Ty::TyErr), params_p1: c_p5xy.params_p.clone(), args_p2: args_p4xy.clone() }))
                        } else {
                            ::prism_rtl::Turn::Finished(found_p6.clone())
                        }
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::check::types::Ty, crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::Ty>>>
            })),
            ::std::option::Option::None => crate::check::types::Ty::TyErr,
        },
        _ => crate::check::types::Ty::TyErr,
    }
}

/// The step machine of `FieldTy`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FieldTy: unbounded fn Lx, Ty, Text -> Ty
/// ```
pub struct FieldTy {
    pub lx_p0: crate::lower::Lx,
    pub rty_p1: crate::check::types::Ty,
    pub name_p2: crate::prelude::Text,
}

impl ::prism_rtl::Job<crate::check::types::Ty> for FieldTy {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::types::Ty> {
        let lx_p0 = &self.lx_p0;
        let rty_p1 = &self.rty_p1;
        let name_p2 = &self.name_p2;
        match rty_p1 {
            crate::check::types::Ty::TyCon(n_p3, args_p4) => match crate::prelude::get(&lx_p0.g_p.ctors_p, n_p3) {
                ::std::option::Option::Some(c_p5) => crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(&c_p5.fields_p)), crate::check::types::Ty::TyErr, {
                    let c_p5x = c_p5.clone();
                    let name_p2x = name_p2.clone();
                    let args_p4x = args_p4.clone();
                    ::std::rc::Rc::new(move |(p0, p1): (crate::check::types::Ty, crate::prelude::Nat)| {
                        let c_p5xy = c_p5x.clone();
                        let name_p2xy = name_p2x.clone();
                        let args_p4xy = args_p4x.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let found_p6 = p0;
                            let i_p7 = p1;
                            if &crate::prelude::or(&crate::prelude::index(&c_p5xy.fields_p, &i_p7), &crate::prelude::Text::lit("")) == &name_p2xy {
                                ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::lower::expr::Instantiated { t_p0: crate::prelude::or(&crate::prelude::index(&c_p5xy.args_p, &i_p7), &crate::check::types::Ty::TyErr), params_p1: c_p5xy.params_p.clone(), args_p2: args_p4xy.clone() }))
                            } else {
                                ::prism_rtl::Turn::Finished(found_p6.clone())
                            }
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::check::types::Ty, crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::Ty>>>
                }).cycle(),
                ::std::option::Option::None => ::prism_rtl::Turn::Finished(crate::check::types::Ty::TyErr),
            },
            _ => ::prism_rtl::Turn::Finished(crate::check::types::Ty::TyErr),
        }
    }
}

/// `Start FieldTy, x`: what the function value is when passed to `@Run`.
pub fn start_field_ty_f(lx_p0: crate::lower::Lx, rty_p1: crate::check::types::Ty, name_p2: crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::Ty>> {
    ::std::rc::Rc::new(FieldTy { lx_p0, rty_p1, name_p2 })
}

/// ```prism
/// Assign: unbounded fn Lx, Env, Expr, Ex -> Do
/// ```
pub fn assign_f(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, target_p2: &crate::syntax::Expr, v_p3: &crate::lower::model::Ex) -> crate::lower::model::Do {
    match &*target_p2.kind_p {
        crate::syntax::ExprKind::EIndex(r_p4, k_p5) => {
            let rt_p6 = crate::lower::types::collection_out_f(&crate::lower::types::out_ty_of_f(lx_p0, &crate::lower::types::peel_f(&place_ty_f(lx_p0, &**r_p4))));
            let f_p7 = match &rt_p6 {
                crate::lower::model::OutTy::OutMap(_, _) => crate::lower::helper_ref_f(&crate::prelude::Text::lit("set_key")),
                _ => crate::lower::helper_ref_f(&crate::prelude::Text::lit("set_index")),
            };
            crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XCall(f_p7.clone(), crate::prelude::Array::from(vec![crate::lower::model::Ex::XRefMut(::std::rc::Rc::new(place_of_f(lx_p0, env_p1, &**r_p4))), crate::lower::expr::argument_f(lx_p0, env_p1, &**k_p5), v_p3.clone()])))
        },
        crate::syntax::ExprKind::EGroup(x_p8) => assign_f(lx_p0, env_p1, &**x_p8, v_p3),
        _ => match lens_call_o(lx_p0, target_p2) {
            ::std::option::Option::Some((qk_p9, argument_pa)) if lens_ends_at_index_f(lx_p0, &qk_p9, &crate::prelude::len(&lx_p0.g_p.defs_p)) => {
                let held_pb = crate::prelude::Text::from(format!("part{}", &target_p2.span_p.start_p));
                crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XBlock(crate::prelude::Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(held_pb.clone()), v_p3.clone())]), ::std::rc::Rc::new(crate::lower::model::Ex::XCall(crate::lower::helper_ref_f(&crate::prelude::Text::lit("set_part")), crate::prelude::Array::from(vec![lens_call_ex_f(lx_p0, env_p1, &qk_p9, &argument_pa), crate::lower::model::Ex::XVar(held_pb.clone())])))))
            },
            _ => crate::lower::model::Do::DoAssign(place_of_f(lx_p0, env_p1, target_p2), v_p3.clone()),
            _ => unreachable!("no arm matched"),
        },
    }
}

/// The step machine of `Assign`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Assign: unbounded fn Lx, Env, Expr, Ex -> Do
/// ```
pub struct Assign {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub target_p2: crate::syntax::Expr,
    pub v_p3: crate::lower::model::Ex,
}

impl ::prism_rtl::Job<crate::lower::model::Do> for Assign {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::lower::model::Do> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let target_p2 = &self.target_p2;
        let v_p3 = &self.v_p3;
        match &*target_p2.kind_p {
            crate::syntax::ExprKind::EIndex(r_p4, k_p5) => {
                let env_p1x = env_p1.clone();
                let k_p5x = (**k_p5).clone();
                let lx_p0x = lx_p0.clone();
                let r_p4x = (**r_p4).clone();
                let v_p3x = v_p3.clone();
                crate::prelude::call_then(start_place_ty_f(lx_p0x.clone(), r_p4x.clone()), move |place_ty_f_22071: crate::check::types::Ty| crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0x.clone(), crate::lower::types::peel_f(&place_ty_f_22071)), move |out_ty_of_f_22052: crate::lower::model::OutTy| {
                    let rt_p6 = crate::lower::types::collection_out_f(&out_ty_of_f_22052);
                    let f_p7 = match &rt_p6 {
                        crate::lower::model::OutTy::OutMap(_, _) => crate::lower::helper_ref_f(&crate::prelude::Text::lit("set_key")),
                        _ => crate::lower::helper_ref_f(&crate::prelude::Text::lit("set_index")),
                    };
                    crate::prelude::call_then(start_place_of_f(lx_p0x.clone(), env_p1x.clone(), r_p4x.clone()), move |place_of_f_22251: crate::lower::model::Ex| crate::prelude::call_then(crate::lower::expr::start_argument_f(lx_p0x.clone(), env_p1x.clone(), k_p5x.clone()), move |argument_f_22274: crate::lower::model::Ex| ::prism_rtl::Turn::Finished(crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XCall(f_p7.clone(), crate::prelude::Array::from(vec![crate::lower::model::Ex::XRefMut(::std::rc::Rc::new(place_of_f_22251)), argument_f_22274, v_p3x.clone()]))))))
                }))
            },
            crate::syntax::ExprKind::EGroup(x_p8) => ::prism_rtl::Turn::More(::std::rc::Rc::new(Assign { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), target_p2: (**x_p8).clone(), v_p3: v_p3.clone() })),
            _ => {
                let env_p1x = env_p1.clone();
                let lx_p0x = lx_p0.clone();
                let target_p2x = target_p2.clone();
                let v_p3x = v_p3.clone();
                crate::prelude::call_then(start_lens_call_o(lx_p0x.clone(), target_p2x.clone()), move |lens_call_o_22357: ::std::option::Option<(crate::prelude::Text, crate::syntax::Expr)>| match lens_call_o_22357 {
                    ::std::option::Option::Some((qk_p9, argument_pa)) if lens_ends_at_index_f(&lx_p0x, &qk_p9, &crate::prelude::len(&lx_p0x.g_p.defs_p)) => {
                        let held_pb = crate::prelude::Text::from(format!("part{}", &target_p2x.span_p.start_p));
                        crate::prelude::call_then(start_lens_call_ex_f(lx_p0x.clone(), env_p1x.clone(), qk_p9.clone(), argument_pa.clone()), move |lens_call_ex_f_22759: crate::lower::model::Ex| ::prism_rtl::Turn::Finished(crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XBlock(crate::prelude::Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(held_pb.clone()), v_p3x.clone())]), ::std::rc::Rc::new(crate::lower::model::Ex::XCall(crate::lower::helper_ref_f(&crate::prelude::Text::lit("set_part")), crate::prelude::Array::from(vec![lens_call_ex_f_22759, crate::lower::model::Ex::XVar(held_pb.clone())])))))))
                    },
                    _ => crate::prelude::call_then(start_place_of_f(lx_p0x.clone(), env_p1x.clone(), target_p2x.clone()), move |place_of_f_22839: crate::lower::model::Ex| ::prism_rtl::Turn::Finished(crate::lower::model::Do::DoAssign(place_of_f_22839, v_p3x.clone()))),
                    _ => unreachable!("no arm matched"),
                })
            },
        }
    }
}

/// `Start Assign, x`: what the function value is when passed to `@Run`.
pub fn start_assign_f(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, target_p2: crate::syntax::Expr, v_p3: crate::lower::model::Ex) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Do>> {
    ::std::rc::Rc::new(Assign { lx_p0, env_p1, target_p2, v_p3 })
}

/// ```prism
/// ?LensCall: unbounded fn Lx, Expr -> ?((Text, Expr))
/// ```
pub fn lens_call_o(lx_p0: &crate::lower::Lx, e_p1: &crate::syntax::Expr) -> ::std::option::Option<(crate::prelude::Text, crate::syntax::Expr)> {
    match crate::check::env::lens_applied_o(e_p1) {
        ::std::option::Option::Some((n_p2, argument_p3)) => {
            let (qk_o4, _) = crate::check::env::names::resolve_value_f(&lx_p0.g_p, &lx_p0.home_p, &n_p2);
            match &qk_o4 {
                ::std::option::Option::Some(qk_p5) => ::std::option::Option::Some((qk_p5.clone(), argument_p3)),
                ::std::option::Option::None => ::std::option::Option::None,
            }
        },
        ::std::option::Option::None => ::std::option::Option::None,
    }
}

/// The step machine of `LensCall`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?LensCall: unbounded fn Lx, Expr -> ?((Text, Expr))
/// ```
pub struct LensCall {
    pub lx_p0: crate::lower::Lx,
    pub e_p1: crate::syntax::Expr,
}

impl ::prism_rtl::Job<::std::option::Option<(crate::prelude::Text, crate::syntax::Expr)>> for LensCall {
    fn cycle(&self) -> ::prism_rtl::Turn<::std::option::Option<(crate::prelude::Text, crate::syntax::Expr)>> {
        let lx_p0 = &self.lx_p0;
        let e_p1 = &self.e_p1;
        match crate::check::env::lens_applied_o(e_p1) {
            ::std::option::Option::Some((n_p2, argument_p3)) => {
                let (qk_o4, _) = crate::check::env::names::resolve_value_f(&lx_p0.g_p, &lx_p0.home_p, &n_p2);
                match &qk_o4 {
                    ::std::option::Option::Some(qk_p5) => ::prism_rtl::Turn::Finished(::std::option::Option::Some((qk_p5.clone(), argument_p3.clone()))),
                    ::std::option::Option::None => ::prism_rtl::Turn::Finished(::std::option::Option::None),
                }
            },
            ::std::option::Option::None => ::prism_rtl::Turn::Finished(::std::option::Option::None),
        }
    }
}

/// `Start LensCall, x`: what the function value is when passed to `@Run`.
pub fn start_lens_call_o(lx_p0: crate::lower::Lx, e_p1: crate::syntax::Expr) -> ::std::rc::Rc<dyn ::prism_rtl::Job<::std::option::Option<(crate::prelude::Text, crate::syntax::Expr)>>> {
    ::std::rc::Rc::new(LensCall { lx_p0, e_p1 })
}

/// ```prism
/// LensCallEx: unbounded fn Lx, Env, Text, Expr -> Ex
/// ```
pub fn lens_call_ex_f(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, qk_p2: &crate::prelude::Text, argument_p3: &crate::syntax::Expr) -> crate::lower::model::Ex {
    crate::lower::model::Ex::XCall(crate::lower::value_ref_f(lx_p0, qk_p2), crate::prelude::Array::from(vec![crate::lower::model::Ex::XRefMut(::std::rc::Rc::new(place_of_f(lx_p0, env_p1, argument_p3)))]))
}

/// The step machine of `LensCallEx`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LensCallEx: unbounded fn Lx, Env, Text, Expr -> Ex
/// ```
pub struct LensCallEx {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub qk_p2: crate::prelude::Text,
    pub argument_p3: crate::syntax::Expr,
}

impl ::prism_rtl::Job<crate::lower::model::Ex> for LensCallEx {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::lower::model::Ex> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let qk_p2 = &self.qk_p2;
        let argument_p3 = &self.argument_p3;
        let argument_p3x = argument_p3.clone();
        let env_p1x = env_p1.clone();
        let lx_p0x = lx_p0.clone();
        let qk_p2x = qk_p2.clone();
        crate::prelude::call_then(start_place_of_f(lx_p0x.clone(), env_p1x.clone(), argument_p3x.clone()), move |place_of_f_23740: crate::lower::model::Ex| ::prism_rtl::Turn::Finished(crate::lower::model::Ex::XCall(crate::lower::value_ref_f(&lx_p0x, &qk_p2x), crate::prelude::Array::from(vec![crate::lower::model::Ex::XRefMut(::std::rc::Rc::new(place_of_f_23740))]))))
    }
}

/// `Start LensCallEx, x`: what the function value is when passed to `@Run`.
pub fn start_lens_call_ex_f(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, qk_p2: crate::prelude::Text, argument_p3: crate::syntax::Expr) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>> {
    ::std::rc::Rc::new(LensCallEx { lx_p0, env_p1, qk_p2, argument_p3 })
}

/// ```prism
/// ?LensBody: fn Lx, Text -> ?((Text, Expr))
/// ```
pub fn lens_body_o(lx_p0: &crate::lower::Lx, qk_p1: &crate::prelude::Text) -> ::std::option::Option<(crate::prelude::Text, crate::syntax::Expr)> {
    crate::prelude::fold(&lx_p0.g_p.defs_p, &::std::option::Option::None, &(|found_o2: &::std::option::Option<(crate::prelude::Text, crate::syntax::Expr)>, d_p3: &crate::check::env::Def| match found_o2 {
        ::std::option::Option::Some(_) => found_o2.clone(),
        ::std::option::Option::None => if &d_p3.qk_p != qk_p1 {
            ::std::option::Option::None
        } else {
            match &d_p3.body_p {
                crate::check::env::DefBody::DbFn(clauses_p4) => match crate::prelude::index(clauses_p4, &crate::prelude::Nat::from(0u32)) {
                    ::std::option::Option::Some(c_p5) => match &c_p5.body_p {
                        crate::syntax::decls::FnBody::BodyExpr(e_p6) => ::std::option::Option::Some((d_p3.home_p.clone(), e_p6.clone())),
                        crate::syntax::decls::FnBody::BodyBlock(_) => ::std::option::Option::None,
                    },
                    ::std::option::Option::None => ::std::option::Option::None,
                },
                _ => ::std::option::Option::None,
            }
        },
    }))
}

/// ```prism
/// LensEndsAtIndex: unbounded fn Lx, Text, Nat -> Bool
/// ```
pub fn lens_ends_at_index_f(lx_p0: &crate::lower::Lx, qk_p1: &crate::prelude::Text, fuel_p2: &crate::prelude::Nat) -> bool {
    match fuel_p2.checked_sub(&crate::prelude::Nat::from(1u32)) {
        ::std::option::Option::None => false,
        ::std::option::Option::Some(left_p3) => match lens_body_o(lx_p0, qk_p1) {
            ::std::option::Option::Some((home_p4, body_p5)) => {
                let there_p6 = {
                    let mut this: crate::lower::Lx = lx_p0.clone();
                    this.home_p = home_p4.clone();
                    this
                };
                path_ends_at_index_f(&there_p6, &body_p5, &left_p3)
            },
            ::std::option::Option::None => false,
        },
    }
}

/// The step machine of `LensEndsAtIndex`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LensEndsAtIndex: unbounded fn Lx, Text, Nat -> Bool
/// ```
pub struct LensEndsAtIndex {
    pub lx_p0: crate::lower::Lx,
    pub qk_p1: crate::prelude::Text,
    pub fuel_p2: crate::prelude::Nat,
}

impl ::prism_rtl::Job<bool> for LensEndsAtIndex {
    fn cycle(&self) -> ::prism_rtl::Turn<bool> {
        let lx_p0 = &self.lx_p0;
        let qk_p1 = &self.qk_p1;
        let fuel_p2 = &self.fuel_p2;
        match fuel_p2.checked_sub(&crate::prelude::Nat::from(1u32)) {
            ::std::option::Option::None => ::prism_rtl::Turn::Finished(false),
            ::std::option::Option::Some(left_p3) => match lens_body_o(lx_p0, qk_p1) {
                ::std::option::Option::Some((home_p4, body_p5)) => {
                    let there_p6 = {
                        let mut this: crate::lower::Lx = lx_p0.clone();
                        this.home_p = home_p4.clone();
                        this
                    };
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(PathEndsAtIndex { lx_p0: there_p6.clone(), e_p1: body_p5.clone(), fuel_p2: left_p3.clone() }))
                },
                ::std::option::Option::None => ::prism_rtl::Turn::Finished(false),
            },
        }
    }
}

/// `Start LensEndsAtIndex, x`: what the function value is when passed to `@Run`.
pub fn start_lens_ends_at_index_f(lx_p0: crate::lower::Lx, qk_p1: crate::prelude::Text, fuel_p2: crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>> {
    ::std::rc::Rc::new(LensEndsAtIndex { lx_p0, qk_p1, fuel_p2 })
}

/// ```prism
/// PathEndsAtIndex: unbounded fn Lx, Expr, Nat -> Bool
/// ```
pub fn path_ends_at_index_f(lx_p0: &crate::lower::Lx, e_p1: &crate::syntax::Expr, fuel_p2: &crate::prelude::Nat) -> bool {
    match &*e_p1.kind_p {
        crate::syntax::ExprKind::EGroup(x_p3) => path_ends_at_index_f(lx_p0, &**x_p3, fuel_p2),
        crate::syntax::ExprKind::EIndex(_, _) => true,
        _ => match lens_call_o(lx_p0, e_p1) {
            ::std::option::Option::Some((qk_p4, _)) => lens_ends_at_index_f(lx_p0, &qk_p4, fuel_p2),
            ::std::option::Option::None => false,
        },
    }
}

/// The step machine of `PathEndsAtIndex`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PathEndsAtIndex: unbounded fn Lx, Expr, Nat -> Bool
/// ```
pub struct PathEndsAtIndex {
    pub lx_p0: crate::lower::Lx,
    pub e_p1: crate::syntax::Expr,
    pub fuel_p2: crate::prelude::Nat,
}

impl ::prism_rtl::Job<bool> for PathEndsAtIndex {
    fn cycle(&self) -> ::prism_rtl::Turn<bool> {
        let lx_p0 = &self.lx_p0;
        let e_p1 = &self.e_p1;
        let fuel_p2 = &self.fuel_p2;
        match &*e_p1.kind_p {
            crate::syntax::ExprKind::EGroup(x_p3) => ::prism_rtl::Turn::More(::std::rc::Rc::new(PathEndsAtIndex { lx_p0: lx_p0.clone(), e_p1: (**x_p3).clone(), fuel_p2: fuel_p2.clone() })),
            crate::syntax::ExprKind::EIndex(_, _) => ::prism_rtl::Turn::Finished(true),
            _ => {
                let e_p1x = e_p1.clone();
                let fuel_p2x = fuel_p2.clone();
                let lx_p0x = lx_p0.clone();
                crate::prelude::call_then(start_lens_call_o(lx_p0x.clone(), e_p1x.clone()), move |lens_call_o_24966: ::std::option::Option<(crate::prelude::Text, crate::syntax::Expr)>| match lens_call_o_24966 {
                    ::std::option::Option::Some((qk_p4, _)) => ::prism_rtl::Turn::More(::std::rc::Rc::new(LensEndsAtIndex { lx_p0: lx_p0x.clone(), qk_p1: qk_p4.clone(), fuel_p2: fuel_p2x.clone() })),
                    ::std::option::Option::None => ::prism_rtl::Turn::Finished(false),
                })
            },
        }
    }
}

/// `Start PathEndsAtIndex, x`: what the function value is when passed to `@Run`.
pub fn start_path_ends_at_index_f(lx_p0: crate::lower::Lx, e_p1: crate::syntax::Expr, fuel_p2: crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>> {
    ::std::rc::Rc::new(PathEndsAtIndex { lx_p0, e_p1, fuel_p2 })
}

/// ```prism
/// LensReference: unbounded fn Lx, Env, Expr -> Ex
/// ```
pub fn lens_reference_f(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, e_p2: &crate::syntax::Expr) -> crate::lower::model::Ex {
    match &*e_p2.kind_p {
        crate::syntax::ExprKind::EGroup(x_p3) => lens_reference_f(lx_p0, env_p1, &**x_p3),
        crate::syntax::ExprKind::EIndex(r_p4, k_p5) => crate::lower::model::Ex::XCall(crate::lower::helper_ref_f(&crate::prelude::Text::lit("part_mut")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XRefMut(::std::rc::Rc::new(place_of_f(lx_p0, env_p1, &**r_p4))), crate::lower::expr::argument_f(lx_p0, env_p1, &**k_p5)])),
        _ => match lens_call_o(lx_p0, e_p2) {
            ::std::option::Option::Some((qk_p6, argument_p7)) => lens_call_ex_f(lx_p0, env_p1, &qk_p6, &argument_p7),
            ::std::option::Option::None => crate::lower::model::Ex::XRefMut(::std::rc::Rc::new(place_of_f(lx_p0, env_p1, e_p2))),
        },
    }
}

/// The step machine of `LensReference`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LensReference: unbounded fn Lx, Env, Expr -> Ex
/// ```
pub struct LensReference {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub e_p2: crate::syntax::Expr,
}

impl ::prism_rtl::Job<crate::lower::model::Ex> for LensReference {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::lower::model::Ex> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let e_p2 = &self.e_p2;
        match &*e_p2.kind_p {
            crate::syntax::ExprKind::EGroup(x_p3) => ::prism_rtl::Turn::More(::std::rc::Rc::new(LensReference { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), e_p2: (**x_p3).clone() })),
            crate::syntax::ExprKind::EIndex(r_p4, k_p5) => {
                let env_p1x = env_p1.clone();
                let k_p5x = (**k_p5).clone();
                let lx_p0x = lx_p0.clone();
                let r_p4x = (**r_p4).clone();
                crate::prelude::call_then(start_place_of_f(lx_p0x.clone(), env_p1x.clone(), r_p4x.clone()), move |place_of_f_25414: crate::lower::model::Ex| crate::prelude::call_then(crate::lower::expr::start_argument_f(lx_p0x.clone(), env_p1x.clone(), k_p5x.clone()), move |argument_f_25437: crate::lower::model::Ex| ::prism_rtl::Turn::Finished(crate::lower::model::Ex::XCall(crate::lower::helper_ref_f(&crate::prelude::Text::lit("part_mut")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XRefMut(::std::rc::Rc::new(place_of_f_25414)), argument_f_25437])))))
            },
            _ => {
                let e_p2x = e_p2.clone();
                let env_p1x = env_p1.clone();
                let lx_p0x = lx_p0.clone();
                crate::prelude::call_then(start_lens_call_o(lx_p0x.clone(), e_p2x.clone()), move |lens_call_o_25481: ::std::option::Option<(crate::prelude::Text, crate::syntax::Expr)>| match lens_call_o_25481 {
                    ::std::option::Option::Some((qk_p6, argument_p7)) => ::prism_rtl::Turn::More(::std::rc::Rc::new(LensCallEx { lx_p0: lx_p0x.clone(), env_p1: env_p1x.clone(), qk_p2: qk_p6.clone(), argument_p3: argument_p7.clone() })),
                    ::std::option::Option::None => crate::prelude::call_then(start_place_of_f(lx_p0x.clone(), env_p1x.clone(), e_p2x.clone()), move |place_of_f_25581: crate::lower::model::Ex| ::prism_rtl::Turn::Finished(crate::lower::model::Ex::XRefMut(::std::rc::Rc::new(place_of_f_25581)))),
                })
            },
        }
    }
}

/// `Start LensReference, x`: what the function value is when passed to `@Run`.
pub fn start_lens_reference_f(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, e_p2: crate::syntax::Expr) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>> {
    ::std::rc::Rc::new(LensReference { lx_p0, env_p1, e_p2 })
}

/// ```prism
/// LensDefs: unbounded fn Lx, Text, [FnClause], Scheme -> [FnDef]
/// ```
pub fn lens_defs_f(lx_p0: &crate::lower::Lx, qk_p1: &crate::prelude::Text, clauses_p2: &crate::prelude::Array<crate::syntax::decls::FnClause>, sc_p3: &crate::check::types::Scheme) -> crate::prelude::Array<crate::lower::model::FnDef> {
    let lxb_p4 = {
        let mut this: crate::lower::Lx = lx_p0.clone();
        this.no_cx_p = true;
        this.in_definition_p = qk_p1.clone();
        this
    };
    let (pts_pg, part_ph) = crate::lower::functions::signature_out_f(lx_p0, qk_p1, sc_p3);
    let whole_p5 = crate::prelude::or(&crate::prelude::index(&pts_pg, &crate::prelude::Nat::from(0u32)), &crate::lower::model::OutTy::OutUnit);
    let (parameter_pi, _) = crate::prelude::or(&crate::prelude::index(&crate::lower::functions::param_names_f(lx_p0, clauses_p2, &pts_pg), &crate::prelude::Nat::from(0u32)), &(crate::prelude::Text::lit("whole"), true));
    let binder_p6 = match crate::prelude::index(clauses_p2, &crate::prelude::Nat::from(0u32)) {
        ::std::option::Option::Some(c_pj) => match crate::prelude::index(&c_pj.params_p, &crate::prelude::Nat::from(0u32)) {
            ::std::option::Option::Some(p_pk) => crate::lower::functions::plain_binder_f(lx_p0, &p_pk),
            ::std::option::Option::None => crate::prelude::Text::lit(""),
        },
        ::std::option::Option::None => crate::prelude::Text::lit(""),
    };
    let env_p7 = crate::lower::types::bind_f(&crate::lower::types::empty_env_p(), &binder_p6, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XTarget(::std::rc::Rc::new(crate::lower::model::Ex::XVar(parameter_pi.clone()))), crate::lower::types::Holding::Owned, whole_p5.clone()));
    let body_p8 = match crate::prelude::index(clauses_p2, &crate::prelude::Nat::from(0u32)) {
        ::std::option::Option::Some(c_pl) => match &c_pl.body_p {
            crate::syntax::decls::FnBody::BodyExpr(e_pm) => lens_reference_f(&lxb_p4, &env_p7, e_pm),
            crate::syntax::decls::FnBody::BodyBlock(_) => crate::lower::expr::internal_bug_f(&crate::prelude::Text::lit("a lens whose body is a block")),
        },
        ::std::option::Option::None => crate::lower::expr::internal_bug_f(&crate::prelude::Text::lit("a lens without a clause")),
    };
    let entry_p9 = match &part_ph {
        crate::lower::model::OutTy::OutOpt(inside_pn) => (**inside_pn).clone(),
        other_po => other_po.clone(),
    };
    let ret_pa = if lens_ends_at_index_f(lx_p0, qk_p1, &crate::prelude::len(&lx_p0.g_p.defs_p)) {
        crate::lower::model::OutTy::OutOpt(::std::rc::Rc::new(crate::lower::model::OutTy::OutRefMut(::std::rc::Rc::new(entry_p9.clone()))))
    } else {
        crate::lower::model::OutTy::OutRefMut(::std::rc::Rc::new(part_ph.clone()))
    };
    let read_pb = crate::lower::functions::fn_def_of_f(lx_p0, qk_p1, clauses_p2, sc_p3);
    let reference_pc = crate::lower::model::FnDef { name_p: read_pb.name_p.clone(), generics_p: read_pb.generics_p.clone(), params_p: crate::prelude::Array::from(vec![(parameter_pi.clone(), crate::lower::model::OutTy::OutRefMut(::std::rc::Rc::new(whole_p5.clone())))]), ret_p: ret_pa.clone(), body_p: body_p8.clone(), doc_p: read_pb.doc_p.clone(), public_p: true };
    let shared_pd = crate::lower::types::bind_f(&crate::lower::types::empty_env_p(), &binder_p6, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(parameter_pi.clone()), crate::lower::types::Holding::ByRef, whole_p5.clone()));
    let through_index_oe = match crate::prelude::index(clauses_p2, &crate::prelude::Nat::from(0u32)) {
        ::std::option::Option::Some(c_pp) => match &c_pp.body_p {
            crate::syntax::decls::FnBody::BodyExpr(e_pq) => if steps_through_index_f(e_pq, &true) {
                ::std::option::Option::Some(lens_read_through_f(&lxb_p4, &shared_pd, e_pq))
            } else {
                ::std::option::Option::None
            },
            crate::syntax::decls::FnBody::BodyBlock(_) => ::std::option::Option::None,
        },
        ::std::option::Option::None => ::std::option::Option::None,
    };
    let value_pf = {
        let mut this: crate::lower::model::FnDef = read_pb.clone();
        this.name_p = crate::prelude::Text::from(format!("{}_get", &read_pb.name_p));
        this.doc_p = crate::prelude::Text::lit("");
        this.body_p = crate::prelude::or(&through_index_oe, &read_pb.body_p);
        this
    };
    crate::prelude::Array::from(vec![reference_pc.clone(), value_pf.clone()])
}

/// The step machine of `LensDefs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LensDefs: unbounded fn Lx, Text, [FnClause], Scheme -> [FnDef]
/// ```
pub struct LensDefs {
    pub lx_p0: crate::lower::Lx,
    pub qk_p1: crate::prelude::Text,
    pub clauses_p2: crate::prelude::Array<crate::syntax::decls::FnClause>,
    pub sc_p3: crate::check::types::Scheme,
}

impl ::prism_rtl::Job<crate::prelude::Array<crate::lower::model::FnDef>> for LensDefs {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<crate::lower::model::FnDef>> {
        let lx_p0 = &self.lx_p0;
        let qk_p1 = &self.qk_p1;
        let clauses_p2 = &self.clauses_p2;
        let sc_p3 = &self.sc_p3;
        let lxb_p4 = {
            let mut this: crate::lower::Lx = lx_p0.clone();
            this.no_cx_p = true;
            this.in_definition_p = qk_p1.clone();
            this
        };
        let clauses_p2x = clauses_p2.clone();
        let lx_p0x = lx_p0.clone();
        let qk_p1x = qk_p1.clone();
        let sc_p3x = sc_p3.clone();
        crate::prelude::call_then(crate::lower::functions::start_signature_out_f(lx_p0x.clone(), qk_p1x.clone(), sc_p3x.clone()), move |signature_out_f_26335: (crate::prelude::Array<crate::lower::model::OutTy>, crate::lower::model::OutTy)| {
            let (pts_pg, part_ph) = signature_out_f_26335;
            let whole_p5 = crate::prelude::or(&crate::prelude::index(&pts_pg, &crate::prelude::Nat::from(0u32)), &crate::lower::model::OutTy::OutUnit);
            crate::prelude::call_then(crate::lower::functions::start_param_names_f(lx_p0x.clone(), clauses_p2x.clone(), pts_pg.clone()), move |param_names_f_26430: crate::prelude::Array<(crate::prelude::Text, bool)>| {
                let (parameter_pi, _) = crate::prelude::or(&crate::prelude::index(&param_names_f_26430, &crate::prelude::Nat::from(0u32)), &(crate::prelude::Text::lit("whole"), true));
                let binder_p6 = match crate::prelude::index(&clauses_p2x, &crate::prelude::Nat::from(0u32)) {
                    ::std::option::Option::Some(c_pj) => match crate::prelude::index(&c_pj.params_p, &crate::prelude::Nat::from(0u32)) {
                        ::std::option::Option::Some(p_pk) => crate::lower::functions::plain_binder_f(&lx_p0x, &p_pk),
                        ::std::option::Option::None => crate::prelude::Text::lit(""),
                    },
                    ::std::option::Option::None => crate::prelude::Text::lit(""),
                };
                let env_p7 = crate::lower::types::bind_f(&crate::lower::types::empty_env_p(), &binder_p6, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XTarget(::std::rc::Rc::new(crate::lower::model::Ex::XVar(parameter_pi.clone()))), crate::lower::types::Holding::Owned, whole_p5.clone()));
                let binder_p6z = binder_p6.clone();
                let clauses_p2xz = clauses_p2x.clone();
                let lx_p0xz = lx_p0x.clone();
                let lxb_p4z = lxb_p4.clone();
                let parameter_piz = parameter_pi.clone();
                let part_phz = part_ph.clone();
                let qk_p1xz = qk_p1x.clone();
                let sc_p3xz = sc_p3x.clone();
                let whole_p5z = whole_p5.clone();
                let k_let26711 = move |v26711: crate::lower::model::Ex| {
                    let body_p8 = v26711;
                    let entry_p9 = match &part_phz {
                        crate::lower::model::OutTy::OutOpt(inside_pn) => (**inside_pn).clone(),
                        other_po => other_po.clone(),
                    };
                    crate::prelude::call_then(start_lens_ends_at_index_f(lx_p0xz.clone(), qk_p1xz.clone(), crate::prelude::len(&lx_p0xz.g_p.defs_p)), move |lens_ends_at_index_f_27037: bool| {
                        let ret_pa = if lens_ends_at_index_f_27037 {
                            crate::lower::model::OutTy::OutOpt(::std::rc::Rc::new(crate::lower::model::OutTy::OutRefMut(::std::rc::Rc::new(entry_p9.clone()))))
                        } else {
                            crate::lower::model::OutTy::OutRefMut(::std::rc::Rc::new(part_phz.clone()))
                        };
                        crate::prelude::call_then(crate::lower::functions::start_fn_def_of_f(lx_p0xz.clone(), qk_p1xz.clone(), clauses_p2xz.clone(), sc_p3xz.clone()), move |fn_def_of_f_27139: crate::lower::model::FnDef| {
                            let read_pb = fn_def_of_f_27139;
                            let reference_pc = crate::lower::model::FnDef { name_p: read_pb.name_p.clone(), generics_p: read_pb.generics_p.clone(), params_p: crate::prelude::Array::from(vec![(parameter_piz.clone(), crate::lower::model::OutTy::OutRefMut(::std::rc::Rc::new(whole_p5z.clone())))]), ret_p: ret_pa.clone(), body_p: body_p8.clone(), doc_p: read_pb.doc_p.clone(), public_p: true };
                            let shared_pd = crate::lower::types::bind_f(&crate::lower::types::empty_env_p(), &binder_p6z, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(parameter_piz.clone()), crate::lower::types::Holding::ByRef, whole_p5z.clone()));
                            let read_pbz = read_pb.clone();
                            let reference_pcz = reference_pc.clone();
                            let k_let27500 = move |v27500: ::std::option::Option<crate::lower::model::Ex>| {
                                let through_index_oe = v27500;
                                let value_pf = {
                                    let mut this: crate::lower::model::FnDef = read_pbz.clone();
                                    this.name_p = crate::prelude::Text::from(format!("{}_get", &read_pbz.name_p));
                                    this.doc_p = crate::prelude::Text::lit("");
                                    this.body_p = crate::prelude::or(&through_index_oe, &read_pbz.body_p);
                                    this
                                };
                                ::prism_rtl::Turn::Finished(crate::prelude::Array::from(vec![reference_pcz.clone(), value_pf.clone()]))
                            };
                            match crate::prelude::index(&clauses_p2xz, &crate::prelude::Nat::from(0u32)) {
                                ::std::option::Option::Some(c_pp) => match c_pp.body_p.clone() {
                                    crate::syntax::decls::FnBody::BodyExpr(e_pq) => crate::prelude::call_then(start_steps_through_index_f(e_pq.clone(), true), move |steps_through_index_f_27592: bool| k_let27500(if steps_through_index_f_27592 {
                                        ::std::option::Option::Some(lens_read_through_f(&lxb_p4z, &shared_pd, &e_pq))
                                    } else {
                                        ::std::option::Option::None
                                    })),
                                    crate::syntax::decls::FnBody::BodyBlock(_) => k_let27500(::std::option::Option::None),
                                },
                                ::std::option::Option::None => k_let27500(::std::option::Option::None),
                            }
                        })
                    })
                };
                match crate::prelude::index(&clauses_p2x, &crate::prelude::Nat::from(0u32)) {
                    ::std::option::Option::Some(c_pl) => match c_pl.body_p.clone() {
                        crate::syntax::decls::FnBody::BodyExpr(e_pm) => crate::prelude::call_then(start_lens_reference_f(lxb_p4.clone(), env_p7.clone(), e_pm.clone()), move |lens_reference_f_26791: crate::lower::model::Ex| k_let26711(lens_reference_f_26791)),
                        crate::syntax::decls::FnBody::BodyBlock(_) => k_let26711(crate::lower::expr::internal_bug_f(&crate::prelude::Text::lit("a lens whose body is a block"))),
                    },
                    ::std::option::Option::None => k_let26711(crate::lower::expr::internal_bug_f(&crate::prelude::Text::lit("a lens without a clause"))),
                }
            })
        })
    }
}

/// `Start LensDefs, x`: what the function value is when passed to `@Run`.
pub fn start_lens_defs_f(lx_p0: crate::lower::Lx, qk_p1: crate::prelude::Text, clauses_p2: crate::prelude::Array<crate::syntax::decls::FnClause>, sc_p3: crate::check::types::Scheme) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::lower::model::FnDef>>> {
    ::std::rc::Rc::new(LensDefs { lx_p0, qk_p1, clauses_p2, sc_p3 })
}

/// ```prism
/// StepsThroughIndex: unbounded fn Expr, Bool -> Bool
/// ```
pub fn steps_through_index_f(e_p0: &crate::syntax::Expr, last_p1: &bool) -> bool {
    match &*e_p0.kind_p {
        crate::syntax::ExprKind::EGroup(x_p2) => steps_through_index_f(&**x_p2, last_p1),
        crate::syntax::ExprKind::EField(r_p3, _, _) => steps_through_index_f(&**r_p3, &false),
        crate::syntax::ExprKind::EIndex(r_p4, _) => if *last_p1 { steps_through_index_f(&**r_p4, &false) } else { true },
        _ => match crate::check::env::lens_applied_o(e_p0) {
            ::std::option::Option::Some((_, argument_p5)) => steps_through_index_f(&argument_p5, &false),
            ::std::option::Option::None => false,
        },
    }
}

/// The step machine of `StepsThroughIndex`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// StepsThroughIndex: unbounded fn Expr, Bool -> Bool
/// ```
pub struct StepsThroughIndex {
    pub e_p0: crate::syntax::Expr,
    pub last_p1: bool,
}

impl ::prism_rtl::Job<bool> for StepsThroughIndex {
    fn cycle(&self) -> ::prism_rtl::Turn<bool> {
        let e_p0 = &self.e_p0;
        let last_p1 = &self.last_p1;
        match &*e_p0.kind_p {
            crate::syntax::ExprKind::EGroup(x_p2) => ::prism_rtl::Turn::More(::std::rc::Rc::new(StepsThroughIndex { e_p0: (**x_p2).clone(), last_p1: *last_p1 })),
            crate::syntax::ExprKind::EField(r_p3, _, _) => ::prism_rtl::Turn::More(::std::rc::Rc::new(StepsThroughIndex { e_p0: (**r_p3).clone(), last_p1: false })),
            crate::syntax::ExprKind::EIndex(r_p4, _) => if *last_p1 {
                ::prism_rtl::Turn::More(::std::rc::Rc::new(StepsThroughIndex { e_p0: (**r_p4).clone(), last_p1: false }))
            } else {
                ::prism_rtl::Turn::Finished(true)
            },
            _ => match crate::check::env::lens_applied_o(e_p0) {
                ::std::option::Option::Some((_, argument_p5)) => ::prism_rtl::Turn::More(::std::rc::Rc::new(StepsThroughIndex { e_p0: argument_p5.clone(), last_p1: false })),
                ::std::option::Option::None => ::prism_rtl::Turn::Finished(false),
            },
        }
    }
}

/// `Start StepsThroughIndex, x`: what the function value is when passed to `@Run`.
pub fn start_steps_through_index_f(e_p0: crate::syntax::Expr, last_p1: bool) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>> {
    ::std::rc::Rc::new(StepsThroughIndex { e_p0, last_p1 })
}

/// ```prism
/// SharedPlaceOf: unbounded fn Lx, Env, Expr -> Ex
/// ```
pub fn shared_place_of_f(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, e_p2: &crate::syntax::Expr) -> crate::lower::model::Ex {
    match &*e_p2.kind_p {
        crate::syntax::ExprKind::EName(n_p3) => match crate::prelude::get(&env_p1.names_p, &crate::check::env::sname_key_f(n_p3)) {
            ::std::option::Option::Some(crate::lower::types::Bn::BnLocal(rs_p4, _, _)) => rs_p4,
            _ => crate::lower::model::Ex::XVar(crate::lower::snake_f(&crate::check::env::sname_key_f(n_p3))),
        },
        crate::syntax::ExprKind::EField(r_p5, _, name_p6) => {
            let rty_p7 = crate::lower::types::peel_f(&place_ty_f(lx_p0, &**r_p5));
            let (_, _, f_p8) = crate::lower::expr::field_info_f(lx_p0, &rty_p7, &name_p6.name_p);
            crate::lower::expr::field_of_ex_f(lx_p0, &shared_place_of_f(lx_p0, env_p1, &**r_p5), &rty_p7, &f_p8)
        },
        crate::syntax::ExprKind::EIndex(r_p9, k_pa) => {
            let helper_pb = match crate::lower::types::collection_out_f(&crate::lower::types::out_ty_of_f(lx_p0, &crate::lower::types::peel_f(&place_ty_f(lx_p0, &**r_p9)))) {
                crate::lower::model::OutTy::OutMap(_, _) => crate::lower::helper_ref_f(&crate::prelude::Text::lit("at_shared_map")),
                _ => crate::lower::helper_ref_f(&crate::prelude::Text::lit("at_shared")),
            };
            crate::lower::model::Ex::XDeref(::std::rc::Rc::new(crate::lower::model::Ex::XCall(helper_pb.clone(), crate::prelude::Array::from(vec![crate::lower::model::Ex::XRef(::std::rc::Rc::new(shared_place_of_f(lx_p0, env_p1, &**r_p9))), crate::lower::expr::argument_f(lx_p0, env_p1, &**k_pa)]))))
        },
        crate::syntax::ExprKind::EGroup(x_pc) => shared_place_of_f(lx_p0, env_p1, &**x_pc),
        _ => crate::lower::expr::internal_bug_f(&crate::prelude::Text::lit("a reference path read through an index that this back end does not lower")),
    }
}

/// The step machine of `SharedPlaceOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SharedPlaceOf: unbounded fn Lx, Env, Expr -> Ex
/// ```
pub struct SharedPlaceOf {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub e_p2: crate::syntax::Expr,
}

impl ::prism_rtl::Job<crate::lower::model::Ex> for SharedPlaceOf {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::lower::model::Ex> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let e_p2 = &self.e_p2;
        match &*e_p2.kind_p {
            crate::syntax::ExprKind::EName(n_p3) => match crate::prelude::get(&env_p1.names_p, &crate::check::env::sname_key_f(n_p3)) {
                ::std::option::Option::Some(crate::lower::types::Bn::BnLocal(rs_p4, _, _)) => ::prism_rtl::Turn::Finished(rs_p4.clone()),
                _ => ::prism_rtl::Turn::Finished(crate::lower::model::Ex::XVar(crate::lower::snake_f(&crate::check::env::sname_key_f(n_p3)))),
            },
            crate::syntax::ExprKind::EField(r_p5, _, name_p6) => {
                let env_p1x = env_p1.clone();
                let lx_p0x = lx_p0.clone();
                let name_p6x = name_p6.clone();
                let r_p5x = (**r_p5).clone();
                crate::prelude::call_then(start_place_ty_f(lx_p0x.clone(), r_p5x.clone()), move |place_ty_f_28898: crate::check::types::Ty| {
                    let rty_p7 = crate::lower::types::peel_f(&place_ty_f_28898);
                    crate::prelude::call_then(crate::lower::expr::start_field_info_f(lx_p0x.clone(), rty_p7.clone(), name_p6x.name_p.clone()), move |field_info_f_28949: (crate::lower::model::OutTy, bool, crate::prelude::Text)| {
                        let (_, _, f_p8) = field_info_f_28949;
                        crate::prelude::call_then(start_shared_place_of_f(lx_p0x.clone(), env_p1x.clone(), r_p5x.clone()), move |shared_place_of_f_29001: crate::lower::model::Ex| ::prism_rtl::Turn::Finished(crate::lower::expr::field_of_ex_f(&lx_p0x, &shared_place_of_f_29001, &rty_p7, &f_p8)))
                    })
                })
            },
            crate::syntax::ExprKind::EIndex(r_p9, k_pa) => {
                let env_p1x = env_p1.clone();
                let k_pax = (**k_pa).clone();
                let lx_p0x = lx_p0.clone();
                let r_p9x = (**r_p9).clone();
                crate::prelude::call_then(start_place_ty_f(lx_p0x.clone(), r_p9x.clone()), move |place_ty_f_29113: crate::check::types::Ty| crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0x.clone(), crate::lower::types::peel_f(&place_ty_f_29113)), move |out_ty_of_f_29094: crate::lower::model::OutTy| {
                    let helper_pb = match crate::lower::types::collection_out_f(&out_ty_of_f_29094) {
                        crate::lower::model::OutTy::OutMap(_, _) => crate::lower::helper_ref_f(&crate::prelude::Text::lit("at_shared_map")),
                        _ => crate::lower::helper_ref_f(&crate::prelude::Text::lit("at_shared")),
                    };
                    crate::prelude::call_then(start_shared_place_of_f(lx_p0x.clone(), env_p1x.clone(), r_p9x.clone()), move |shared_place_of_f_29276: crate::lower::model::Ex| crate::prelude::call_then(crate::lower::expr::start_argument_f(lx_p0x.clone(), env_p1x.clone(), k_pax.clone()), move |argument_f_29305: crate::lower::model::Ex| ::prism_rtl::Turn::Finished(crate::lower::model::Ex::XDeref(::std::rc::Rc::new(crate::lower::model::Ex::XCall(helper_pb.clone(), crate::prelude::Array::from(vec![crate::lower::model::Ex::XRef(::std::rc::Rc::new(shared_place_of_f_29276)), argument_f_29305])))))))
                }))
            },
            crate::syntax::ExprKind::EGroup(x_pc) => ::prism_rtl::Turn::More(::std::rc::Rc::new(SharedPlaceOf { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), e_p2: (**x_pc).clone() })),
            _ => ::prism_rtl::Turn::Finished(crate::lower::expr::internal_bug_f(&crate::prelude::Text::lit("a reference path read through an index that this back end does not lower"))),
        }
    }
}

/// `Start SharedPlaceOf, x`: what the function value is when passed to `@Run`.
pub fn start_shared_place_of_f(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, e_p2: crate::syntax::Expr) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>> {
    ::std::rc::Rc::new(SharedPlaceOf { lx_p0, env_p1, e_p2 })
}

/// ```prism
/// LensReadThrough: unbounded fn Lx, Env, Expr -> Ex
/// ```
pub fn lens_read_through_f(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, e_p2: &crate::syntax::Expr) -> crate::lower::model::Ex {
    match &*e_p2.kind_p {
        crate::syntax::ExprKind::EGroup(x_p3) => lens_read_through_f(lx_p0, env_p1, &**x_p3),
        crate::syntax::ExprKind::EIndex(r_p4, k_p5) => crate::lower::model::Ex::XCall(crate::lower::helper_ref_f(&crate::prelude::Text::lit("index")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XRef(::std::rc::Rc::new(shared_place_of_f(lx_p0, env_p1, &**r_p4))), crate::lower::expr::argument_f(lx_p0, env_p1, &**k_p5)])),
        _ => match lens_call_o(lx_p0, e_p2) {
            ::std::option::Option::Some((qk_p6, argument_p7)) => crate::lower::model::Ex::XCall(lens_read_ref_f(lx_p0, &qk_p6), crate::prelude::Array::from(vec![crate::lower::model::Ex::XRef(::std::rc::Rc::new(shared_place_of_f(lx_p0, env_p1, &argument_p7)))])),
            ::std::option::Option::None => crate::lower::model::Ex::XClone(::std::rc::Rc::new(shared_place_of_f(lx_p0, env_p1, e_p2))),
        },
    }
}

/// The step machine of `LensReadThrough`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LensReadThrough: unbounded fn Lx, Env, Expr -> Ex
/// ```
pub struct LensReadThrough {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub e_p2: crate::syntax::Expr,
}

impl ::prism_rtl::Job<crate::lower::model::Ex> for LensReadThrough {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::lower::model::Ex> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let e_p2 = &self.e_p2;
        match &*e_p2.kind_p {
            crate::syntax::ExprKind::EGroup(x_p3) => ::prism_rtl::Turn::More(::std::rc::Rc::new(LensReadThrough { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), e_p2: (**x_p3).clone() })),
            crate::syntax::ExprKind::EIndex(r_p4, k_p5) => {
                let env_p1x = env_p1.clone();
                let k_p5x = (**k_p5).clone();
                let lx_p0x = lx_p0.clone();
                let r_p4x = (**r_p4).clone();
                crate::prelude::call_then(start_shared_place_of_f(lx_p0x.clone(), env_p1x.clone(), r_p4x.clone()), move |shared_place_of_f_29819: crate::lower::model::Ex| crate::prelude::call_then(crate::lower::expr::start_argument_f(lx_p0x.clone(), env_p1x.clone(), k_p5x.clone()), move |argument_f_29848: crate::lower::model::Ex| ::prism_rtl::Turn::Finished(crate::lower::model::Ex::XCall(crate::lower::helper_ref_f(&crate::prelude::Text::lit("index")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XRef(::std::rc::Rc::new(shared_place_of_f_29819)), argument_f_29848])))))
            },
            _ => {
                let e_p2x = e_p2.clone();
                let env_p1x = env_p1.clone();
                let lx_p0x = lx_p0.clone();
                crate::prelude::call_then(start_lens_call_o(lx_p0x.clone(), e_p2x.clone()), move |lens_call_o_29892: ::std::option::Option<(crate::prelude::Text, crate::syntax::Expr)>| match lens_call_o_29892 {
                    ::std::option::Option::Some((qk_p6, argument_p7)) => crate::prelude::call_then(start_shared_place_of_f(lx_p0x.clone(), env_p1x.clone(), argument_p7.clone()), move |shared_place_of_f_29974: crate::lower::model::Ex| ::prism_rtl::Turn::Finished(crate::lower::model::Ex::XCall(lens_read_ref_f(&lx_p0x, &qk_p6), crate::prelude::Array::from(vec![crate::lower::model::Ex::XRef(::std::rc::Rc::new(shared_place_of_f_29974))])))),
                    ::std::option::Option::None => crate::prelude::call_then(start_shared_place_of_f(lx_p0x.clone(), env_p1x.clone(), e_p2x.clone()), move |shared_place_of_f_30031: crate::lower::model::Ex| ::prism_rtl::Turn::Finished(crate::lower::model::Ex::XClone(::std::rc::Rc::new(shared_place_of_f_30031)))),
                })
            },
        }
    }
}

/// `Start LensReadThrough, x`: what the function value is when passed to `@Run`.
pub fn start_lens_read_through_f(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, e_p2: crate::syntax::Expr) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>> {
    ::std::rc::Rc::new(LensReadThrough { lx_p0, env_p1, e_p2 })
}

/// ```prism
/// LensReadRef: fn Lx, Text -> Ref
/// ```
pub fn lens_read_ref_f(lx_p0: &crate::lower::Lx, qk_p1: &crate::prelude::Text) -> crate::lower::model::Ref {
    let owner_p2 = match crate::prelude::get(&lx_p0.g_p.vals_p, qk_p1) {
        ::std::option::Option::Some(v_p3) => v_p3.home_p.clone(),
        ::std::option::Option::None => crate::lower::owner_of_f(qk_p1),
    };
    crate::lower::ref_in_f(lx_p0, &owner_p2, &crate::prelude::Text::from(format!("{}_get", &crate::prelude::or(&crate::prelude::get(&lx_p0.rs_names_p, qk_p1), &crate::lower::snake_f(&crate::check::types::bare_name_f(qk_p1))))))
}

/// ```prism
/// LensRead: unbounded fn Lx, Env, Text, Expr, OutTy -> Vl
/// ```
pub fn lens_read_f(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, qk_p2: &crate::prelude::Text, argument_p3: &crate::syntax::Expr, t_p4: &crate::lower::model::OutTy) -> crate::lower::types::Vl {
    let whole_p5 = if steps_through_index_f(argument_p3, &false) {
        crate::lower::model::Ex::XRef(::std::rc::Rc::new(shared_place_of_f(lx_p0, env_p1, argument_p3)))
    } else {
        crate::lower::types::ref_f(&crate::lower::expr::value_of_f(lx_p0, env_p1, argument_p3))
    };
    crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCall(lens_read_ref_f(lx_p0, qk_p2), crate::prelude::Array::from(vec![whole_p5.clone()])), t_p4.clone())
}

/// The step machine of `LensRead`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LensRead: unbounded fn Lx, Env, Text, Expr, OutTy -> Vl
/// ```
pub struct LensRead {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub qk_p2: crate::prelude::Text,
    pub argument_p3: crate::syntax::Expr,
    pub t_p4: crate::lower::model::OutTy,
}

impl ::prism_rtl::Job<crate::lower::types::Vl> for LensRead {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::lower::types::Vl> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let qk_p2 = &self.qk_p2;
        let argument_p3 = &self.argument_p3;
        let t_p4 = &self.t_p4;
        let argument_p3x = argument_p3.clone();
        let env_p1x = env_p1.clone();
        let lx_p0x = lx_p0.clone();
        let qk_p2x = qk_p2.clone();
        let t_p4x = t_p4.clone();
        crate::prelude::call_then(start_steps_through_index_f(argument_p3x.clone(), false), move |steps_through_index_f_30521: bool| {
            let lx_p0xz = lx_p0x.clone();
            let qk_p2xz = qk_p2x.clone();
            let t_p4xz = t_p4x.clone();
            let k_let30506 = move |v30506: crate::lower::model::Ex| {
                let whole_p5 = v30506;
                ::prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XCall(lens_read_ref_f(&lx_p0xz, &qk_p2xz), crate::prelude::Array::from(vec![whole_p5.clone()])), t_p4xz.clone()))
            };
            if steps_through_index_f_30521 {
                crate::prelude::call_then(start_shared_place_of_f(lx_p0x.clone(), env_p1x.clone(), argument_p3x.clone()), move |shared_place_of_f_30562: crate::lower::model::Ex| k_let30506(crate::lower::model::Ex::XRef(::std::rc::Rc::new(shared_place_of_f_30562))))
            } else {
                crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p0x.clone(), env_p1x.clone(), argument_p3x.clone()), move |value_of_f_30606: crate::lower::types::Vl| k_let30506(crate::lower::types::ref_f(&value_of_f_30606)))
            }
        })
    }
}

/// `Start LensRead, x`: what the function value is when passed to `@Run`.
pub fn start_lens_read_f(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, qk_p2: crate::prelude::Text, argument_p3: crate::syntax::Expr, t_p4: crate::lower::model::OutTy) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::types::Vl>> {
    ::std::rc::Rc::new(LensRead { lx_p0, env_p1, qk_p2, argument_p3, t_p4 })
}
