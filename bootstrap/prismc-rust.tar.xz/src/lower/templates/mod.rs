//! The module `Lower.Templates`, from `target/bootstrap/src/prismc/lower/templates.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// ```prism
/// TemplateValue: unbounded fn Lx, Env, Template -> Vl
/// ```
pub fn template_value(lx: &crate::lower::Lx, env: &crate::lower::types::Env, tp: &crate::syntax::Template) -> crate::lower::types::Vl {
    let start = Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaMut(Text::lit("out")), crate::lower::model::Ex::XCall(Text::lit("String::new"), Array::new()))]);
    let dos = run_to_end(fold_job(tp.parts.clone(), start.clone(), {
        let lx = lx.clone();
        let env = env.clone();
        Rc::new(move |(p0, p1): (Array<crate::lower::model::Do>, crate::syntax::TemplatePart)| {
            let lx = lx.clone();
            let env = env.clone();
            entered(once_job(move || {
                let acc = p0;
                let part = p1;
                call_then(start_template_part_dos(lx.clone(), env.clone(), part.clone()), move |template_part_dos_1601: Array<crate::lower::model::Do>| prism_rtl::Turn::Finished(append(&acc, &template_part_dos_1601)))
            }))
        }) as Rc<dyn Fn((Array<crate::lower::model::Do>, crate::syntax::TemplatePart)) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>
    }));
    crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XBlock(dos.clone(), Rc::new(crate::lower::model::Ex::XCall(Text::lit("Text::from"), Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("out"))])))), crate::lower::model::OutTy::OutText)
}

/// The step machine of `TemplateValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TemplateValue: unbounded fn Lx, Env, Template -> Vl
/// ```
pub struct TemplateValue {
    pub lx: crate::lower::Lx,
    pub env: crate::lower::types::Env,
    pub tp: crate::syntax::Template,
}

impl prism_rtl::Job<crate::lower::types::Vl> for TemplateValue {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::types::Vl> {
        let lx = &self.lx;
        let env = &self.env;
        let tp = &self.tp;
        let start = Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaMut(Text::lit("out")), crate::lower::model::Ex::XCall(Text::lit("String::new"), Array::new()))]);
        let env = env.clone();
        let lx = lx.clone();
        let tp = tp.clone();
        call_value(fold_job(tp.parts.clone(), start.clone(), {
            let lx = lx.clone();
            let env = env.clone();
            Rc::new(move |(p0, p1): (Array<crate::lower::model::Do>, crate::syntax::TemplatePart)| {
                let lx = lx.clone();
                let env = env.clone();
                entered(once_job(move || {
                    let acc = p0;
                    let part = p1;
                    call_then(start_template_part_dos(lx.clone(), env.clone(), part.clone()), move |template_part_dos_1601: Array<crate::lower::model::Do>| prism_rtl::Turn::Finished(append(&acc, &template_part_dos_1601)))
                }))
            }) as Rc<dyn Fn((Array<crate::lower::model::Do>, crate::syntax::TemplatePart)) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>
        }), move |fold_1553: Array<crate::lower::model::Do>| {
            let dos = fold_1553;
            prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XBlock(dos.clone(), Rc::new(crate::lower::model::Ex::XCall(Text::lit("Text::from"), Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("out"))])))), crate::lower::model::OutTy::OutText))
        })
    }
}

/// `Start TemplateValue, x`: what the function value is when passed to `@Run`.
pub fn start_template_value(lx: crate::lower::Lx, env: crate::lower::types::Env, tp: crate::syntax::Template) -> Rc<dyn prism_rtl::Job<crate::lower::types::Vl>> {
    Rc::new(TemplateValue { lx, env, tp })
}

/// ```prism
/// TemplatePartDos: unbounded fn Lx, Env, TemplatePart -> [Do]
/// ```
pub fn template_part_dos(lx: &crate::lower::Lx, env: &crate::lower::types::Env, part: &crate::syntax::TemplatePart) -> Array<crate::lower::model::Do> {
    match part {
        crate::syntax::TemplatePart::TpText(t) => Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("out"))), Text::lit("push_str"), Array::from(vec![crate::lower::model::Ex::XStr(t.clone())])))]),
        crate::syntax::TemplatePart::TpPlaceholder(x, col_opt) => {
            let v_ = crate::lower::expr::value_of(lx, env, x);
            let column = match col_opt {
                Some(c) => crate::lower::model::Ex::XCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Ex::XIndex(c.clone())])),
                None => crate::lower::model::Ex::XNone,
            };
            Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XCall(Text::lit("place"), Array::from(vec![crate::lower::model::Ex::XRefMut(Rc::new(crate::lower::model::Ex::XVar(Text::lit("out")))), shown_text(&v_), column.clone()])))])
        },
        crate::syntax::TemplatePart::TpBlock(b) => {
            let v_ = crate::lower::expr::block_value(lx, env, b);
            if &crate::lower::types::value_ty(&v_) == &crate::lower::model::OutTy::OutUnit {
                Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::types::own(&v_))])
            } else {
                Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XCall(Text::lit("place"), Array::from(vec![crate::lower::model::Ex::XRefMut(Rc::new(crate::lower::model::Ex::XVar(Text::lit("out")))), shown_text(&v_), crate::lower::model::Ex::XNone])))])
            }
        },
        crate::syntax::TemplatePart::TpCall(n, args, parts_opt, _) => {
            let plain = crate::syntax::SName { sigils: crate::syntax::lexer::chars::after_first(&n.sigils), path_: n.path_.clone(), span: n.span.clone() };
            let (qk_opt, _) = crate::check::env::names::resolve_value(&lx.g, &lx.home, n);
            let (qk2_opt, _) = crate::check::env::names::resolve_value(&lx.g, &lx.home, &plain);
            let callee = match &qk_opt {
                Some(q) => crate::lower::value_path(lx, q),
                None => match &qk2_opt {
                    Some(q) => crate::lower::value_path(lx, q),
                    None => crate::lower::snake(&crate::check::env::sname_key(n)),
                },
            };
            let body = match parts_opt {
                Some(ps) => {
                    let inner = run_to_end(fold_job(ps.clone(), Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaMut(Text::lit("out")), crate::lower::model::Ex::XCall(Text::lit("String::new"), Array::new()))]), {
                        let lx = lx.clone();
                        let env = env.clone();
                        Rc::new(move |(p0, p1): (Array<crate::lower::model::Do>, crate::syntax::TemplatePart)| {
                            let lx = lx.clone();
                            let env = env.clone();
                            entered(once_job(move || {
                                let acc = p0;
                                let p_ = p1;
                                call_then(start_template_part_dos(lx.clone(), env.clone(), p_.clone()), move |template_part_dos_2911: Array<crate::lower::model::Do>| prism_rtl::Turn::Finished(append(&acc, &template_part_dos_2911)))
                            }))
                        }) as Rc<dyn Fn((Array<crate::lower::model::Do>, crate::syntax::TemplatePart)) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>
                    }));
                    Array::from(vec![crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XBlock(inner.clone(), Rc::new(crate::lower::model::Ex::XCall(Text::lit("Text::from"), Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("out"))]))))))])
                },
                None => Array::new(),
            };
            let passed = match &qk_opt {
                Some(q) => template_args(lx, env, q, args, &body),
                None => match &qk2_opt {
                    Some(q) => template_args(lx, env, q, args, &body),
                    None => append(&run_to_end(each_job(args.clone(), {
                        let lx = lx.clone();
                        let env = env.clone();
                        Rc::new(move |p0: crate::syntax::Arg| {
                            let lx = lx.clone();
                            let env = env.clone();
                            entered(once_job(move || {
                                let a = p0;
                                prism_rtl::Turn::More(Rc::new(crate::lower::expr::Argument { lx: lx.clone(), env: env.clone(), e: a.value.clone() }))
                            }))
                        }) as Rc<dyn Fn(crate::syntax::Arg) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
                    })), &body),
                },
            };
            let call = crate::lower::model::Ex::XCall(callee.clone(), passed.clone());
            Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XCall(Text::lit("place"), Array::from(vec![crate::lower::model::Ex::XRefMut(Rc::new(crate::lower::model::Ex::XVar(Text::lit("out")))), crate::lower::model::Ex::XRef(Rc::new(call.clone())), crate::lower::model::Ex::XNone])))])
        },
    }
}

/// The step machine of `TemplatePartDos`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TemplatePartDos: unbounded fn Lx, Env, TemplatePart -> [Do]
/// ```
pub struct TemplatePartDos {
    pub lx: crate::lower::Lx,
    pub env: crate::lower::types::Env,
    pub part: crate::syntax::TemplatePart,
}

impl prism_rtl::Job<Array<crate::lower::model::Do>> for TemplatePartDos {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::lower::model::Do>> {
        let lx = &self.lx;
        let env = &self.env;
        let part = &self.part;
        match part {
            crate::syntax::TemplatePart::TpText(t) => prism_rtl::Turn::Finished(Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("out"))), Text::lit("push_str"), Array::from(vec![crate::lower::model::Ex::XStr(t.clone())])))])),
            crate::syntax::TemplatePart::TpPlaceholder(x, col_opt) => {
                let col_opt = col_opt.clone();
                let env = env.clone();
                let lx = lx.clone();
                let x = x.clone();
                call_then(crate::lower::expr::start_value_of(lx.clone(), env.clone(), x.clone()), move |value_of_1931: crate::lower::types::Vl| {
                    let v_ = value_of_1931;
                    let column = match &col_opt {
                        Some(c) => crate::lower::model::Ex::XCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Ex::XIndex(c.clone())])),
                        None => crate::lower::model::Ex::XNone,
                    };
                    prism_rtl::Turn::Finished(Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XCall(Text::lit("place"), Array::from(vec![crate::lower::model::Ex::XRefMut(Rc::new(crate::lower::model::Ex::XVar(Text::lit("out")))), shown_text(&v_), column.clone()])))]))
                })
            },
            crate::syntax::TemplatePart::TpBlock(b) => {
                let b = b.clone();
                let env = env.clone();
                let lx = lx.clone();
                call_then(crate::lower::expr::start_block_value(lx.clone(), env.clone(), b.clone()), move |block_value_2165: crate::lower::types::Vl| {
                    let v_ = block_value_2165;
                    if &crate::lower::types::value_ty(&v_) == &crate::lower::model::OutTy::OutUnit {
                        prism_rtl::Turn::Finished(Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::types::own(&v_))]))
                    } else {
                        prism_rtl::Turn::Finished(Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XCall(Text::lit("place"), Array::from(vec![crate::lower::model::Ex::XRefMut(Rc::new(crate::lower::model::Ex::XVar(Text::lit("out")))), shown_text(&v_), crate::lower::model::Ex::XNone])))]))
                    }
                })
            },
            crate::syntax::TemplatePart::TpCall(n, args, parts_opt, _) => {
                let plain = crate::syntax::SName { sigils: crate::syntax::lexer::chars::after_first(&n.sigils), path_: n.path_.clone(), span: n.span.clone() };
                let (qk_opt, _) = crate::check::env::names::resolve_value(&lx.g, &lx.home, n);
                let (qk2_opt, _) = crate::check::env::names::resolve_value(&lx.g, &lx.home, &plain);
                let callee = match &qk_opt {
                    Some(q) => crate::lower::value_path(lx, q),
                    None => match &qk2_opt {
                        Some(q) => crate::lower::value_path(lx, q),
                        None => crate::lower::snake(&crate::check::env::sname_key(n)),
                    },
                };
                let body = match parts_opt {
                    Some(ps) => {
                        let inner = run_to_end(fold_job(ps.clone(), Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaMut(Text::lit("out")), crate::lower::model::Ex::XCall(Text::lit("String::new"), Array::new()))]), {
                            let lx = lx.clone();
                            let env = env.clone();
                            Rc::new(move |(p0, p1): (Array<crate::lower::model::Do>, crate::syntax::TemplatePart)| {
                                let lx = lx.clone();
                                let env = env.clone();
                                entered(once_job(move || {
                                    let acc = p0;
                                    let p_ = p1;
                                    call_then(start_template_part_dos(lx.clone(), env.clone(), p_.clone()), move |template_part_dos_2911: Array<crate::lower::model::Do>| prism_rtl::Turn::Finished(append(&acc, &template_part_dos_2911)))
                                }))
                            }) as Rc<dyn Fn((Array<crate::lower::model::Do>, crate::syntax::TemplatePart)) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>
                        }));
                        Array::from(vec![crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XBlock(inner.clone(), Rc::new(crate::lower::model::Ex::XCall(Text::lit("Text::from"), Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("out"))]))))))])
                    },
                    None => Array::new(),
                };
                let passed = match &qk_opt {
                    Some(q) => template_args(lx, env, q, args, &body),
                    None => match &qk2_opt {
                        Some(q) => template_args(lx, env, q, args, &body),
                        None => append(&run_to_end(each_job(args.clone(), {
                            let lx = lx.clone();
                            let env = env.clone();
                            Rc::new(move |p0: crate::syntax::Arg| {
                                let lx = lx.clone();
                                let env = env.clone();
                                entered(once_job(move || {
                                    let a = p0;
                                    prism_rtl::Turn::More(Rc::new(crate::lower::expr::Argument { lx: lx.clone(), env: env.clone(), e: a.value.clone() }))
                                }))
                            }) as Rc<dyn Fn(crate::syntax::Arg) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
                        })), &body),
                    },
                };
                let call = crate::lower::model::Ex::XCall(callee.clone(), passed.clone());
                prism_rtl::Turn::Finished(Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XCall(Text::lit("place"), Array::from(vec![crate::lower::model::Ex::XRefMut(Rc::new(crate::lower::model::Ex::XVar(Text::lit("out")))), crate::lower::model::Ex::XRef(Rc::new(call.clone())), crate::lower::model::Ex::XNone])))]))
            },
        }
    }
}

/// `Start TemplatePartDos, x`: what the function value is when passed to `@Run`.
pub fn start_template_part_dos(lx: crate::lower::Lx, env: crate::lower::types::Env, part: crate::syntax::TemplatePart) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>> {
    Rc::new(TemplatePartDos { lx, env, part })
}

/// ```prism
/// TemplateArgs: unbounded fn Lx, Env, Text, [Arg], [Ex] -> [Ex]
/// ```
pub fn template_args(lx: &crate::lower::Lx, env: &crate::lower::types::Env, qk: &Text, args: &Array<crate::syntax::Arg>, body: &Array<crate::lower::model::Ex>) -> Array<crate::lower::model::Ex> {
    let clauses = crate::lower::jobs::clauses_of(&lx.g, qk);
    let arity = len(&or(&index(&clauses, &Nat::from(0u32)), &crate::lower::functions::dummy_clause()).params);
    run_to_end(each_job(crate::check::errors::range0(&arity), {
        let body = body.clone();
        let arity = arity.clone();
        let clauses = clauses.clone();
        let args = args.clone();
        let lx = lx.clone();
        let env = env.clone();
        Rc::new(move |p0: Nat| {
            let body = body.clone();
            let arity = arity.clone();
            let clauses = clauses.clone();
            let args = args.clone();
            let lx = lx.clone();
            let env = env.clone();
            entered(once_job(move || {
                let j = p0;
                if (&len(&body) > &Nat::from(0u32)) && (&(&j + &Nat::from(1u32)) == &arity) {
                    prism_rtl::Turn::Finished(or(&index(&body, &Nat::from(0u32)), &crate::lower::model::Ex::XUnit))
                } else {
                    match attr_at(&clauses, &j, &args) {
                        Some(a) => prism_rtl::Turn::More(Rc::new(crate::lower::expr::Argument { lx: lx.clone(), env: env.clone(), e: a.value.clone() })),
                        None => prism_rtl::Turn::Finished(crate::lower::expr::refusal(&Text::from(format!("a template call that fills no argument at place {}", &j)))),
                    }
                }
            }))
        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
    }))
}

/// The step machine of `TemplateArgs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TemplateArgs: unbounded fn Lx, Env, Text, [Arg], [Ex] -> [Ex]
/// ```
pub struct TemplateArgs {
    pub lx: crate::lower::Lx,
    pub env: crate::lower::types::Env,
    pub qk: Text,
    pub args: Array<crate::syntax::Arg>,
    pub body: Array<crate::lower::model::Ex>,
}

impl prism_rtl::Job<Array<crate::lower::model::Ex>> for TemplateArgs {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::lower::model::Ex>> {
        let lx = &self.lx;
        let env = &self.env;
        let qk = &self.qk;
        let args = &self.args;
        let body = &self.body;
        let clauses = crate::lower::jobs::clauses_of(&lx.g, qk);
        let arity = len(&or(&index(&clauses, &Nat::from(0u32)), &crate::lower::functions::dummy_clause()).params);
        each_job(crate::check::errors::range0(&arity), {
            let body = body.clone();
            let arity = arity.clone();
            let clauses = clauses.clone();
            let args = args.clone();
            let lx = lx.clone();
            let env = env.clone();
            Rc::new(move |p0: Nat| {
                let body = body.clone();
                let arity = arity.clone();
                let clauses = clauses.clone();
                let args = args.clone();
                let lx = lx.clone();
                let env = env.clone();
                entered(once_job(move || {
                    let j = p0;
                    if (&len(&body) > &Nat::from(0u32)) && (&(&j + &Nat::from(1u32)) == &arity) {
                        prism_rtl::Turn::Finished(or(&index(&body, &Nat::from(0u32)), &crate::lower::model::Ex::XUnit))
                    } else {
                        match attr_at(&clauses, &j, &args) {
                            Some(a) => prism_rtl::Turn::More(Rc::new(crate::lower::expr::Argument { lx: lx.clone(), env: env.clone(), e: a.value.clone() })),
                            None => prism_rtl::Turn::Finished(crate::lower::expr::refusal(&Text::from(format!("a template call that fills no argument at place {}", &j)))),
                        }
                    }
                }))
            }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
        }).cycle()
    }
}

/// `Start TemplateArgs, x`: what the function value is when passed to `@Run`.
pub fn start_template_args(lx: crate::lower::Lx, env: crate::lower::types::Env, qk: Text, args: Array<crate::syntax::Arg>, body: Array<crate::lower::model::Ex>) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Ex>>> {
    Rc::new(TemplateArgs { lx, env, qk, args, body })
}

/// ```prism
/// ?AttrAt: fn [FnClause], Nat, [Arg] -> ?Arg
/// ```
pub fn attr_at(clauses: &Array<crate::syntax::decls::FnClause>, j: &Nat, args: &Array<crate::syntax::Arg>) -> Option<crate::syntax::Arg> {
    let names = fold(clauses, &Array::new(), &(|acc: &Array<Text>, c: &crate::syntax::decls::FnClause| match index(&c.params, j) {
        Some(p_) => match place_name(&p_) {
            Some(n) => crate::check::types::add_text(acc, &n),
            None => acc.clone(),
        },
        None => acc.clone(),
    }));
    fold(args, &None, &(|found_opt: &Option<crate::syntax::Arg>, a: &crate::syntax::Arg| match &a.name {
        Some(n) => if crate::check::types::has_text(&names, &n.name) {
            Some(a.clone())
        } else {
            found_opt.clone()
        },
        None => found_opt.clone(),
    }))
}

/// ```prism
/// ?PlaceName: fn Pattern -> ?Text
/// ```
pub fn place_name(p_: &crate::syntax::Pattern_) -> Option<Text> {
    match &*p_.kind {
        crate::syntax::PatternKind::PName(n) => Some(crate::check::env::dotted(&n.path_)),
        crate::syntax::PatternKind::PGroup(q) => place_name(&**q),
        _ => None,
    }
}

/// ```prism
/// ShownText: fn Vl -> Ex
/// ```
pub fn shown_text(v_: &crate::lower::types::Vl) -> crate::lower::model::Ex {
    match crate::lower::types::value_ty(v_) {
        crate::lower::model::OutTy::OutText => crate::lower::types::ref_(v_),
        _ => crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XCall(Text::lit("show_text"), Array::from(vec![crate::lower::types::ref_(v_)])))),
    }
}

/// ```prism
/// GivenValue: unbounded fn Lx, Env, Block, OutTy, Range -> Vl
/// ```
pub fn given_value(lx: &crate::lower::Lx, env: &crate::lower::types::Env, b: &crate::syntax::Block, t: &crate::lower::model::OutTy, span: &crate::syntax::Range) -> crate::lower::types::Vl {
    let label = Text::from(format!("\'g{}", &span.start));
    let is_try = match t {
        crate::lower::model::OutTy::OutRes(_) => true,
        _ => false,
    };
    let n = len(&b.stmts);
    let (dos, env2, last_opt) = run_to_end(fold_job(crate::check::errors::range0(&n), (Array::new(), env.clone(), None), {
        let b = b.clone();
        let is_try = is_try;
        let lx = lx.clone();
        let label = label.clone();
        let n = n.clone();
        Rc::new(move |(p0, p1): ((Array<crate::lower::model::Do>, crate::lower::types::Env, Option<crate::lower::types::Vl>), Nat)| {
            let b = b.clone();
            let is_try = is_try;
            let lx = lx.clone();
            let label = label.clone();
            let n = n.clone();
            entered(once_job(move || {
                let (acc, en, lv_opt) = p0;
                let i = p1;
                {
                    let s = or(&index(&b.stmts, &i), &crate::lower::expr::dummy_stmt_l());
                    let fail = if is_try {
                        crate::lower::model::Ex::XCtor(Text::lit("Err"), Array::from(vec![crate::lower::model::Ex::XCall(Text::lit("Error::new"), Array::from(vec![crate::lower::model::Ex::XStr(Text::lit("Prelude.Unmet")), crate::lower::model::Ex::XStr(source_text(&lx, &s.span))]))]))
                    } else {
                        crate::lower::model::Ex::XNone
                    };
                    match &s.kind {
                        crate::syntax::StmtKind::SBind(p_, x, None) => {
                            let p_ = p_.clone();
                            let x = x.clone();
                            call_then(crate::lower::expr::start_value_of(lx.clone(), en.clone(), x.clone()), move |value_of_5845: crate::lower::types::Vl| {
                                let v_ = value_of_5845;
                                call_then(crate::lower::patterns::start_rust_pat(lx.clone(), p_.clone(), crate::lower::patterns::inner_ty(&crate::lower::type_at(&lx, &x.span)), crate::lower::types::Holding::Owned, Text::from(format!("g{}", &s.span.start))), move |rust_pat_5888: crate::lower::patterns::PatOut| {
                                    let po = rust_pat_5888;
                                    call_then(crate::lower::types::start_out_ty_of(lx.clone(), crate::lower::patterns::inner_ty(&crate::lower::type_at(&lx, &x.span))), move |out_ty_of_6030: crate::lower::model::OutTy| prism_rtl::Turn::Finished((push(&acc, &given_bind(&is_try, &po.pa, &crate::lower::types::own(&v_), &label, &out_ty_of_6030)), crate::lower::expr::bind_all(&en, &po.binds), lv_opt.clone())))
                                })
                            })
                        },
                        crate::syntax::StmtKind::SRequire(c) => {
                            let c = c.clone();
                            call_then(crate::lower::expr::start_value_of(lx.clone(), en.clone(), c.clone()), move |value_of_6171: crate::lower::types::Vl| prism_rtl::Turn::Finished((push(&acc, &crate::lower::model::Do::DoIf(crate::lower::model::Ex::XUnary(Text::lit("!"), Rc::new(crate::lower::types::as_bool(&value_of_6171))), Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XBreak(label.clone(), Rc::new(fail.clone())))]), Array::new())), en.clone(), lv_opt.clone())))
                        },
                        crate::syntax::StmtKind::SForbid(c) => {
                            let c = c.clone();
                            call_then(crate::lower::expr::start_value_of(lx.clone(), en.clone(), c.clone()), move |value_of_6295: crate::lower::types::Vl| prism_rtl::Turn::Finished((push(&acc, &crate::lower::model::Do::DoIf(crate::lower::types::as_bool(&value_of_6295), Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XBreak(label.clone(), Rc::new(fail.clone())))]), Array::new())), en.clone(), lv_opt.clone())))
                        },
                        crate::syntax::StmtKind::SExpr(x) => if &(&i + &Nat::from(1u32)) == &n {
                            prism_rtl::Turn::Finished((acc.clone(), en.clone(), Some(crate::lower::expr::value_of(&lx, &en, x))))
                        } else {
                            {
                                let x = x.clone();
                                call_then(crate::lower::expr::start_value_of(lx.clone(), en.clone(), x.clone()), move |value_of_6503: crate::lower::types::Vl| prism_rtl::Turn::Finished((push(&acc, &crate::lower::model::Do::DoExpr(crate::lower::types::own(&value_of_6503))), en.clone(), lv_opt.clone())))
                            }
                        },
                        _ => call_then(crate::lower::expr::start_block_stmt(lx.clone(), en.clone(), s.clone()), move |block_stmt_6595: (Array<crate::lower::model::Do>, crate::lower::types::Env)| {
                            let (more, en2) = block_stmt_6595;
                            prism_rtl::Turn::Finished((append(&acc, &more), en2.clone(), lv_opt.clone()))
                        }),
                    }
                }
            }))
        }) as Rc<dyn Fn(((Array<crate::lower::model::Do>, crate::lower::types::Env, Option<crate::lower::types::Vl>), Nat)) -> Rc<dyn prism_rtl::Job<(Array<crate::lower::model::Do>, crate::lower::types::Env, Option<crate::lower::types::Vl>)>>>
    }));
    let last = or(&last_opt, &crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XNone, t.clone()));
    crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XLabeled(label.clone(), dos.clone(), Rc::new(crate::lower::types::own(&last)), t.clone()), t.clone())
}

/// The step machine of `GivenValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// GivenValue: unbounded fn Lx, Env, Block, OutTy, Range -> Vl
/// ```
pub struct GivenValue {
    pub lx: crate::lower::Lx,
    pub env: crate::lower::types::Env,
    pub b: crate::syntax::Block,
    pub t: crate::lower::model::OutTy,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<crate::lower::types::Vl> for GivenValue {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::types::Vl> {
        let lx = &self.lx;
        let env = &self.env;
        let b = &self.b;
        let t = &self.t;
        let span = &self.span;
        let label = Text::from(format!("\'g{}", &span.start));
        let is_try = match t {
            crate::lower::model::OutTy::OutRes(_) => true,
            _ => false,
        };
        let n = len(&b.stmts);
        let b = b.clone();
        let env = env.clone();
        let lx = lx.clone();
        let span = span.clone();
        let t = t.clone();
        call_value(fold_job(crate::check::errors::range0(&n), (Array::new(), env.clone(), None), {
            let b = b.clone();
            let is_try = is_try;
            let lx = lx.clone();
            let label = label.clone();
            let n = n.clone();
            Rc::new(move |(p0, p1): ((Array<crate::lower::model::Do>, crate::lower::types::Env, Option<crate::lower::types::Vl>), Nat)| {
                let b = b.clone();
                let is_try = is_try;
                let lx = lx.clone();
                let label = label.clone();
                let n = n.clone();
                entered(once_job(move || {
                    let (acc, en, lv_opt) = p0;
                    let i = p1;
                    {
                        let s = or(&index(&b.stmts, &i), &crate::lower::expr::dummy_stmt_l());
                        let fail = if is_try {
                            crate::lower::model::Ex::XCtor(Text::lit("Err"), Array::from(vec![crate::lower::model::Ex::XCall(Text::lit("Error::new"), Array::from(vec![crate::lower::model::Ex::XStr(Text::lit("Prelude.Unmet")), crate::lower::model::Ex::XStr(source_text(&lx, &s.span))]))]))
                        } else {
                            crate::lower::model::Ex::XNone
                        };
                        match &s.kind {
                            crate::syntax::StmtKind::SBind(p_, x, None) => {
                                let p_ = p_.clone();
                                let x = x.clone();
                                call_then(crate::lower::expr::start_value_of(lx.clone(), en.clone(), x.clone()), move |value_of_5845: crate::lower::types::Vl| {
                                    let v_ = value_of_5845;
                                    call_then(crate::lower::patterns::start_rust_pat(lx.clone(), p_.clone(), crate::lower::patterns::inner_ty(&crate::lower::type_at(&lx, &x.span)), crate::lower::types::Holding::Owned, Text::from(format!("g{}", &s.span.start))), move |rust_pat_5888: crate::lower::patterns::PatOut| {
                                        let po = rust_pat_5888;
                                        call_then(crate::lower::types::start_out_ty_of(lx.clone(), crate::lower::patterns::inner_ty(&crate::lower::type_at(&lx, &x.span))), move |out_ty_of_6030: crate::lower::model::OutTy| prism_rtl::Turn::Finished((push(&acc, &given_bind(&is_try, &po.pa, &crate::lower::types::own(&v_), &label, &out_ty_of_6030)), crate::lower::expr::bind_all(&en, &po.binds), lv_opt.clone())))
                                    })
                                })
                            },
                            crate::syntax::StmtKind::SRequire(c) => {
                                let c = c.clone();
                                call_then(crate::lower::expr::start_value_of(lx.clone(), en.clone(), c.clone()), move |value_of_6171: crate::lower::types::Vl| prism_rtl::Turn::Finished((push(&acc, &crate::lower::model::Do::DoIf(crate::lower::model::Ex::XUnary(Text::lit("!"), Rc::new(crate::lower::types::as_bool(&value_of_6171))), Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XBreak(label.clone(), Rc::new(fail.clone())))]), Array::new())), en.clone(), lv_opt.clone())))
                            },
                            crate::syntax::StmtKind::SForbid(c) => {
                                let c = c.clone();
                                call_then(crate::lower::expr::start_value_of(lx.clone(), en.clone(), c.clone()), move |value_of_6295: crate::lower::types::Vl| prism_rtl::Turn::Finished((push(&acc, &crate::lower::model::Do::DoIf(crate::lower::types::as_bool(&value_of_6295), Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XBreak(label.clone(), Rc::new(fail.clone())))]), Array::new())), en.clone(), lv_opt.clone())))
                            },
                            crate::syntax::StmtKind::SExpr(x) => if &(&i + &Nat::from(1u32)) == &n {
                                prism_rtl::Turn::Finished((acc.clone(), en.clone(), Some(crate::lower::expr::value_of(&lx, &en, x))))
                            } else {
                                {
                                    let x = x.clone();
                                    call_then(crate::lower::expr::start_value_of(lx.clone(), en.clone(), x.clone()), move |value_of_6503: crate::lower::types::Vl| prism_rtl::Turn::Finished((push(&acc, &crate::lower::model::Do::DoExpr(crate::lower::types::own(&value_of_6503))), en.clone(), lv_opt.clone())))
                                }
                            },
                            _ => call_then(crate::lower::expr::start_block_stmt(lx.clone(), en.clone(), s.clone()), move |block_stmt_6595: (Array<crate::lower::model::Do>, crate::lower::types::Env)| {
                                let (more, en2) = block_stmt_6595;
                                prism_rtl::Turn::Finished((append(&acc, &more), en2.clone(), lv_opt.clone()))
                            }),
                        }
                    }
                }))
            }) as Rc<dyn Fn(((Array<crate::lower::model::Do>, crate::lower::types::Env, Option<crate::lower::types::Vl>), Nat)) -> Rc<dyn prism_rtl::Job<(Array<crate::lower::model::Do>, crate::lower::types::Env, Option<crate::lower::types::Vl>)>>>
        }), move |fold_5529: (Array<crate::lower::model::Do>, crate::lower::types::Env, Option<crate::lower::types::Vl>)| {
            let (dos, env2, last_opt) = fold_5529;
            let last = or(&last_opt, &crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XNone, t.clone()));
            prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XLabeled(label.clone(), dos.clone(), Rc::new(crate::lower::types::own(&last)), t.clone()), t.clone()))
        })
    }
}

/// `Start GivenValue, x`: what the function value is when passed to `@Run`.
pub fn start_given_value(lx: crate::lower::Lx, env: crate::lower::types::Env, b: crate::syntax::Block, t: crate::lower::model::OutTy, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<crate::lower::types::Vl>> {
    Rc::new(GivenValue { lx, env, b, t, span })
}

/// ```prism
/// GivenBind: fn Bool, Pa, Ex, Text, OutTy -> Do
/// ```
pub fn given_bind(is_try: &bool, pa: &crate::lower::model::Pa, x: &crate::lower::model::Ex, label: &Text, t: &crate::lower::model::OutTy) -> crate::lower::model::Do {
    if *is_try {
        crate::lower::model::Do::DoLet(pa.clone(), crate::lower::model::Ex::XMatch(Rc::new(x.clone()), Array::from(vec![crate::lower::model::XArm { pat: crate::lower::model::Pa::PaCtor(Text::lit("Ok"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("v"))])), conds: Array::new(), body: crate::lower::model::Ex::XVar(Text::lit("v")) }, crate::lower::model::XArm { pat: crate::lower::model::Pa::PaCtor(Text::lit("Err"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("e"))])), conds: Array::new(), body: crate::lower::model::Ex::XBreak(label.clone(), Rc::new(crate::lower::model::Ex::XCtor(Text::lit("Err"), Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("e"))])))) }]), false, t.clone()))
    } else {
        crate::lower::model::Do::DoLetElse(crate::lower::model::Pa::PaCtor(Text::lit("Some"), Array::from(vec![pa.clone()])), x.clone(), crate::lower::model::Ex::XBreak(label.clone(), Rc::new(crate::lower::model::Ex::XNone)))
    }
}

/// ```prism
/// SourceText: fn Lx, Range -> Text
/// ```
pub fn source_text(lx: &crate::lower::Lx, r: &crate::syntax::Range) -> Text {
    match index(&lx.g.srcs, &lx.file) {
        Some(src) => crate::check::errors::span_text(&src, r),
        None => Text::lit(""),
    }
}

/// ```prism
/// UpdateValue: unbounded fn Lx, Env, Expr, Block, OutTy, Range -> Vl
/// ```
pub fn update_value(lx: &crate::lower::Lx, env: &crate::lower::types::Env, target: &crate::syntax::Expr, b: &crate::syntax::Block, t: &crate::lower::model::OutTy, span: &crate::syntax::Range) -> crate::lower::types::Vl {
    let tv = crate::lower::expr::value_of(lx, env, target);
    let env1 = crate::lower::types::bind(env, &Text::lit("&_"), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(Text::lit("this")), crate::lower::types::Holding::Owned, t.clone()));
    let (dos, _) = upd_stmts(lx, &env1, &b.stmts);
    crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XBlock(append(&Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaMut(Text::lit("this"))), t.clone()), crate::lower::types::own(&tv))]), &dos), Rc::new(crate::lower::model::Ex::XVar(Text::lit("this")))), t.clone())
}

/// The step machine of `UpdateValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UpdateValue: unbounded fn Lx, Env, Expr, Block, OutTy, Range -> Vl
/// ```
pub struct UpdateValue {
    pub lx: crate::lower::Lx,
    pub env: crate::lower::types::Env,
    pub target: crate::syntax::Expr,
    pub b: crate::syntax::Block,
    pub t: crate::lower::model::OutTy,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<crate::lower::types::Vl> for UpdateValue {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::types::Vl> {
        let lx = &self.lx;
        let env = &self.env;
        let target = &self.target;
        let b = &self.b;
        let t = &self.t;
        let span = &self.span;
        let b = b.clone();
        let env = env.clone();
        let lx = lx.clone();
        let t = t.clone();
        let target = target.clone();
        call_then(crate::lower::expr::start_value_of(lx.clone(), env.clone(), target.clone()), move |value_of_7794: crate::lower::types::Vl| {
            let tv = value_of_7794;
            let env1 = crate::lower::types::bind(&env, &Text::lit("&_"), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(Text::lit("this")), crate::lower::types::Holding::Owned, t.clone()));
            call_then(start_upd_stmts(lx.clone(), env1.clone(), b.stmts.clone()), move |upd_stmts_7909: (Array<crate::lower::model::Do>, crate::lower::types::Env)| {
                let (dos, _) = upd_stmts_7909;
                prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XBlock(append(&Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaMut(Text::lit("this"))), t.clone()), crate::lower::types::own(&tv))]), &dos), Rc::new(crate::lower::model::Ex::XVar(Text::lit("this")))), t.clone()))
            })
        })
    }
}

/// `Start UpdateValue, x`: what the function value is when passed to `@Run`.
pub fn start_update_value(lx: crate::lower::Lx, env: crate::lower::types::Env, target: crate::syntax::Expr, b: crate::syntax::Block, t: crate::lower::model::OutTy, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<crate::lower::types::Vl>> {
    Rc::new(UpdateValue { lx, env, target, b, t, span })
}

/// ```prism
/// UpdStmts: unbounded fn Lx, Env, [Stmt] -> (([Do], Env))
/// ```
pub fn upd_stmts(lx: &crate::lower::Lx, env: &crate::lower::types::Env, stmts: &Array<crate::syntax::Stmt>) -> (Array<crate::lower::model::Do>, crate::lower::types::Env) {
    run_to_end(fold_job(stmts.clone(), (Array::new(), env.clone()), {
        let lx = lx.clone();
        Rc::new(move |(p0, p1): ((Array<crate::lower::model::Do>, crate::lower::types::Env), crate::syntax::Stmt)| {
            let lx = lx.clone();
            entered(once_job(move || {
                let (acc, en) = p0;
                let s = p1;
                call_then(start_upd_stmt(lx.clone(), en.clone(), s.clone()), move |upd_stmt_8194: (Array<crate::lower::model::Do>, crate::lower::types::Env)| {
                    let (more, en2) = upd_stmt_8194;
                    prism_rtl::Turn::Finished((append(&acc, &more), en2.clone()))
                })
            }))
        }) as Rc<dyn Fn(((Array<crate::lower::model::Do>, crate::lower::types::Env), crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<(Array<crate::lower::model::Do>, crate::lower::types::Env)>>>
    }))
}

/// The step machine of `UpdStmts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UpdStmts: unbounded fn Lx, Env, [Stmt] -> (([Do], Env))
/// ```
pub struct UpdStmts {
    pub lx: crate::lower::Lx,
    pub env: crate::lower::types::Env,
    pub stmts: Array<crate::syntax::Stmt>,
}

impl prism_rtl::Job<(Array<crate::lower::model::Do>, crate::lower::types::Env)> for UpdStmts {
    fn cycle(&self) -> prism_rtl::Turn<(Array<crate::lower::model::Do>, crate::lower::types::Env)> {
        let lx = &self.lx;
        let env = &self.env;
        let stmts = &self.stmts;
        fold_job(stmts.clone(), (Array::new(), env.clone()), {
            let lx = lx.clone();
            Rc::new(move |(p0, p1): ((Array<crate::lower::model::Do>, crate::lower::types::Env), crate::syntax::Stmt)| {
                let lx = lx.clone();
                entered(once_job(move || {
                    let (acc, en) = p0;
                    let s = p1;
                    call_then(start_upd_stmt(lx.clone(), en.clone(), s.clone()), move |upd_stmt_8194: (Array<crate::lower::model::Do>, crate::lower::types::Env)| {
                        let (more, en2) = upd_stmt_8194;
                        prism_rtl::Turn::Finished((append(&acc, &more), en2.clone()))
                    })
                }))
            }) as Rc<dyn Fn(((Array<crate::lower::model::Do>, crate::lower::types::Env), crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<(Array<crate::lower::model::Do>, crate::lower::types::Env)>>>
        }).cycle()
    }
}

/// `Start UpdStmts, x`: what the function value is when passed to `@Run`.
pub fn start_upd_stmts(lx: crate::lower::Lx, env: crate::lower::types::Env, stmts: Array<crate::syntax::Stmt>) -> Rc<dyn prism_rtl::Job<(Array<crate::lower::model::Do>, crate::lower::types::Env)>> {
    Rc::new(UpdStmts { lx, env, stmts })
}

/// ```prism
/// UpdStmt: unbounded fn Lx, Env, Stmt -> (([Do], Env))
/// ```
pub fn upd_stmt(lx: &crate::lower::Lx, env: &crate::lower::types::Env, s: &crate::syntax::Stmt) -> (Array<crate::lower::model::Do>, crate::lower::types::Env) {
    match &s.kind {
        crate::syntax::StmtKind::SSet(target, value) => {
            let v_ = crate::lower::types::own(&crate::lower::expr::value_of(lx, env, value));
            (Array::from(vec![assign(lx, env, target, &v_)]), env.clone())
        },
        crate::syntax::StmtKind::SAccum(target, op, value) => {
            let cur = place_of(lx, env, target);
            let tt = crate::lower::types::out_ty_of(lx, &crate::lower::types::peel(&crate::lower::type_at(lx, &target.span)));
            let rv = crate::lower::expr::value_of(lx, env, value);
            let bin = crate::syntax::lexer::chars::head(op);
            let next = crate::lower::expr::op_value(lx, &bin, &crate::lower::types::Vl::VlPlace(cur.clone(), crate::lower::types::Holding::Owned, tt.clone()), &rv, &s.span, &tt);
            (Array::from(vec![assign(lx, env, target, &crate::lower::types::own(&next))]), env.clone())
        },
        crate::syntax::StmtKind::SLet(p_, _, x) => {
            let v_ = crate::lower::types::own(&crate::lower::expr::value_of(lx, env, x));
            match &*p_.kind {
                crate::syntax::PatternKind::PName(n) => if crate::syntax::lexer::chars::has_prefix(&n.sigils, &Text::lit("&")) {
                    {
                        let rs = crate::lower::local_name(lx, &crate::check::env::sname_key(n));
                        let bt = crate::lower::types::out_ty_of(lx, &crate::lower::types::peel(&crate::lower::binder_ty(lx, &n.span)));
                        let pa = if crate::lower::expr::is_known_ty(&bt) {
                            crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaMut(Text::from(format!("{}", &rs)))), bt.clone())
                        } else {
                            crate::lower::model::Pa::PaMut(Text::from(format!("{}", &rs)))
                        };
                        (Array::from(vec![crate::lower::model::Do::DoLet(pa.clone(), v_.clone())]), crate::lower::types::bind(env, &crate::check::env::sname_key(n), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(rs.clone()), crate::lower::types::Holding::Owned, bt.clone())))
                    }
                } else {
                    crate::lower::expr::block_stmt(lx, env, s)
                },
                _ => crate::lower::expr::block_stmt(lx, env, s),
            }
        },
        crate::syntax::StmtKind::SWhile(c, body) => {
            let (inner, _) = upd_stmts(lx, env, &body.stmts);
            match c {
                crate::syntax::Cond::CondExpr(x) => (Array::from(vec![crate::lower::model::Do::DoWhile(crate::lower::types::as_bool(&crate::lower::expr::value_of(lx, env, &**x)), inner.clone())]), env.clone()),
                crate::syntax::Cond::CondBind(p_, x, g_opt) => {
                    let po = crate::lower::patterns::rust_pat(lx, p_, &crate::lower::type_at(lx, &x.span), &crate::lower::types::Holding::Owned, &Text::from(format!("w{}", &s.span.start)));
                    let env_b = crate::lower::expr::bind_all(env, &po.binds);
                    let (inner2, _) = upd_stmts(lx, &env_b, &body.stmts);
                    let conds = append(&po.conds, &guard_conds(lx, &env_b, &**g_opt));
                    let tests = fold(&conds, &Array::new(), &(|acc: &Array<crate::lower::model::Ex>, c: &crate::lower::model::Cc| match c {
                        crate::lower::model::Cc::CcIf(t) => push(acc, t),
                        _ => acc.clone(),
                    }));
                    let lets = fold(&conds, &false, &(|f: &bool, c: &crate::lower::model::Cc| *f || crate::lower::expr::is_let_cond(c)));
                    let stop = if &len(&tests) == &Nat::from(0u32) {
                        Array::new()
                    } else {
                        Array::from(vec![crate::lower::model::Do::DoIf(crate::lower::model::Ex::XUnary(Text::lit("!"), Rc::new(all_of(&tests))), Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XVar(Text::lit("break")))]), Array::new())])
                    };
                    let body2 = if lets {
                        Array::from(vec![crate::lower::expr::refusal_do(&Text::lit("a `while` whose pattern matches through an `Rc`"))])
                    } else {
                        append(&stop, &inner2)
                    };
                    (Array::from(vec![crate::lower::model::Do::DoWhileLet(po.pa.clone(), crate::lower::types::own(&crate::lower::expr::value_of(lx, env, &**x)), body2.clone())]), env.clone())
                },
            }
        },
        crate::syntax::StmtKind::SExpr(x) => match &*x.kind {
            crate::syntax::ExprKind::EIf(c, then_b, else_b_opt) => (Array::from(vec![upd_if(lx, env, &**c, then_b, else_b_opt)]), env.clone()),
            crate::syntax::ExprKind::EMatch(scrut, arms) => (Array::from(vec![upd_match(lx, env, &**scrut, arms)]), env.clone()),
            crate::syntax::ExprKind::EFor(binders_opt, source, body) => (Array::from(vec![upd_for(lx, env, binders_opt, &**source, body, &x.span)]), env.clone()),
            _ => (Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::types::own(&crate::lower::expr::value_of(lx, env, x)))]), env.clone()),
        },
        _ => crate::lower::expr::block_stmt(lx, env, s),
    }
}

/// The step machine of `UpdStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UpdStmt: unbounded fn Lx, Env, Stmt -> (([Do], Env))
/// ```
pub struct UpdStmt {
    pub lx: crate::lower::Lx,
    pub env: crate::lower::types::Env,
    pub s: crate::syntax::Stmt,
}

impl prism_rtl::Job<(Array<crate::lower::model::Do>, crate::lower::types::Env)> for UpdStmt {
    fn cycle(&self) -> prism_rtl::Turn<(Array<crate::lower::model::Do>, crate::lower::types::Env)> {
        let lx = &self.lx;
        let env = &self.env;
        let s = &self.s;
        match &s.kind {
            crate::syntax::StmtKind::SSet(target, value) => {
                let env = env.clone();
                let lx = lx.clone();
                let target = target.clone();
                let value = value.clone();
                call_then(crate::lower::expr::start_value_of(lx.clone(), env.clone(), value.clone()), move |value_of_8381: crate::lower::types::Vl| {
                    let v_ = crate::lower::types::own(&value_of_8381);
                    call_then(start_assign(lx.clone(), env.clone(), target.clone(), v_.clone()), move |assign_8418: crate::lower::model::Do| prism_rtl::Turn::Finished((Array::from(vec![assign_8418]), env.clone())))
                })
            },
            crate::syntax::StmtKind::SAccum(target, op, value) => {
                let env = env.clone();
                let lx = lx.clone();
                let op = op.clone();
                let s = s.clone();
                let target = target.clone();
                let value = value.clone();
                call_then(start_place_of(lx.clone(), env.clone(), target.clone()), move |place_of_8502: crate::lower::model::Ex| {
                    let cur = place_of_8502;
                    call_then(crate::lower::types::start_out_ty_of(lx.clone(), crate::lower::types::peel(&crate::lower::type_at(&lx, &target.span))), move |out_ty_of_8543: crate::lower::model::OutTy| {
                        let tt = out_ty_of_8543;
                        call_then(crate::lower::expr::start_value_of(lx.clone(), env.clone(), value.clone()), move |value_of_8604: crate::lower::types::Vl| {
                            let rv = value_of_8604;
                            let bin = crate::syntax::lexer::chars::head(&op);
                            let next = crate::lower::expr::op_value(&lx, &bin, &crate::lower::types::Vl::VlPlace(cur.clone(), crate::lower::types::Holding::Owned, tt.clone()), &rv, &s.span, &tt);
                            call_then(start_assign(lx.clone(), env.clone(), target.clone(), crate::lower::types::own(&next)), move |assign_8743: crate::lower::model::Do| prism_rtl::Turn::Finished((Array::from(vec![assign_8743]), env.clone())))
                        })
                    })
                })
            },
            crate::syntax::StmtKind::SLet(p_, _, x) => {
                let env = env.clone();
                let lx = lx.clone();
                let p_ = p_.clone();
                let s = s.clone();
                let x = x.clone();
                call_then(crate::lower::expr::start_value_of(lx.clone(), env.clone(), x.clone()), move |value_of_8832: crate::lower::types::Vl| {
                    let v_ = crate::lower::types::own(&value_of_8832);
                    match &*p_.kind {
                        crate::syntax::PatternKind::PName(n) => if crate::syntax::lexer::chars::has_prefix(&n.sigils, &Text::lit("&")) {
                            {
                                let rs = crate::lower::local_name(&lx, &crate::check::env::sname_key(n));
                                let n = n.clone();
                                call_then(crate::lower::types::start_out_ty_of(lx.clone(), crate::lower::types::peel(&crate::lower::binder_ty(&lx, &n.span))), move |out_ty_of_9026: crate::lower::model::OutTy| {
                                    let bt = out_ty_of_9026;
                                    call_then(crate::lower::expr::start_is_known_ty(bt.clone()), move |is_known_ty_9099: bool| {
                                        let pa = if is_known_ty_9099 {
                                            crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaMut(Text::from(format!("{}", &rs)))), bt.clone())
                                        } else {
                                            crate::lower::model::Pa::PaMut(Text::from(format!("{}", &rs)))
                                        };
                                        prism_rtl::Turn::Finished((Array::from(vec![crate::lower::model::Do::DoLet(pa.clone(), v_.clone())]), crate::lower::types::bind(&env, &crate::check::env::sname_key(&n), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(rs.clone()), crate::lower::types::Holding::Owned, bt.clone()))))
                                    })
                                })
                            }
                        } else {
                            prism_rtl::Turn::More(Rc::new(crate::lower::expr::BlockStmt { lx: lx.clone(), env: env.clone(), s: s.clone() }))
                        },
                        _ => prism_rtl::Turn::More(Rc::new(crate::lower::expr::BlockStmt { lx: lx.clone(), env: env.clone(), s: s.clone() })),
                    }
                })
            },
            crate::syntax::StmtKind::SWhile(c, body) => {
                let body = body.clone();
                let c = c.clone();
                let env = env.clone();
                let lx = lx.clone();
                let s = s.clone();
                call_then(start_upd_stmts(lx.clone(), env.clone(), body.stmts.clone()), move |upd_stmts_9398: (Array<crate::lower::model::Do>, crate::lower::types::Env)| {
                    let (inner, _) = upd_stmts_9398;
                    match &c {
                        crate::syntax::Cond::CondExpr(x) => {
                            let x = (**x).clone();
                            call_then(crate::lower::expr::start_value_of(lx.clone(), env.clone(), x.clone()), move |value_of_9490: crate::lower::types::Vl| prism_rtl::Turn::Finished((Array::from(vec![crate::lower::model::Do::DoWhile(crate::lower::types::as_bool(&value_of_9490), inner.clone())]), env.clone())))
                        },
                        crate::syntax::Cond::CondBind(p_, x, g_opt) => {
                            let g_opt = (**g_opt).clone();
                            let p_ = p_.clone();
                            let x = (**x).clone();
                            call_then(crate::lower::patterns::start_rust_pat(lx.clone(), p_.clone(), crate::lower::type_at(&lx, &x.span), crate::lower::types::Holding::Owned, Text::from(format!("w{}", &s.span.start))), move |rust_pat_9584: crate::lower::patterns::PatOut| {
                                let po = rust_pat_9584;
                                let env_b = crate::lower::expr::bind_all(&env, &po.binds);
                                call_then(start_upd_stmts(lx.clone(), env_b.clone(), body.stmts.clone()), move |upd_stmts_9735: (Array<crate::lower::model::Do>, crate::lower::types::Env)| {
                                    let (inner2, _) = upd_stmts_9735;
                                    call_then(start_guard_conds(lx.clone(), env_b.clone(), g_opt.clone()), move |guard_conds_9993: Array<crate::lower::model::Cc>| {
                                        let conds = append(&po.conds, &guard_conds_9993);
                                        let tests = fold(&conds, &Array::new(), &(|acc: &Array<crate::lower::model::Ex>, c: &crate::lower::model::Cc| match c {
                                            crate::lower::model::Cc::CcIf(t) => push(acc, t),
                                            _ => acc.clone(),
                                        }));
                                        let lets = fold(&conds, &false, &(|f: &bool, c: &crate::lower::model::Cc| *f || crate::lower::expr::is_let_cond(c)));
                                        let stop = if &len(&tests) == &Nat::from(0u32) {
                                            Array::new()
                                        } else {
                                            Array::from(vec![crate::lower::model::Do::DoIf(crate::lower::model::Ex::XUnary(Text::lit("!"), Rc::new(all_of(&tests))), Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XVar(Text::lit("break")))]), Array::new())])
                                        };
                                        let body2 = if lets {
                                            Array::from(vec![crate::lower::expr::refusal_do(&Text::lit("a `while` whose pattern matches through an `Rc`"))])
                                        } else {
                                            append(&stop, &inner2)
                                        };
                                        call_then(crate::lower::expr::start_value_of(lx.clone(), env.clone(), x.clone()), move |value_of_10532: crate::lower::types::Vl| prism_rtl::Turn::Finished((Array::from(vec![crate::lower::model::Do::DoWhileLet(po.pa.clone(), crate::lower::types::own(&value_of_10532), body2.clone())]), env.clone())))
                                    })
                                })
                            })
                        },
                    }
                })
            },
            crate::syntax::StmtKind::SExpr(x) => match &*x.kind {
                crate::syntax::ExprKind::EIf(c, then_b, else_b_opt) => {
                    let else_b_opt = else_b_opt.clone();
                    let c = (**c).clone();
                    let env = env.clone();
                    let lx = lx.clone();
                    let then_b = then_b.clone();
                    call_then(start_upd_if(lx.clone(), env.clone(), c.clone(), then_b.clone(), else_b_opt.clone()), move |upd_if_10632: crate::lower::model::Do| prism_rtl::Turn::Finished((Array::from(vec![upd_if_10632]), env.clone())))
                },
                crate::syntax::ExprKind::EMatch(scrut, arms) => {
                    let arms = arms.clone();
                    let env = env.clone();
                    let lx = lx.clone();
                    let scrut = (**scrut).clone();
                    call_then(start_upd_match(lx.clone(), env.clone(), scrut.clone(), arms.clone()), move |upd_match_10707: crate::lower::model::Do| prism_rtl::Turn::Finished((Array::from(vec![upd_match_10707]), env.clone())))
                },
                crate::syntax::ExprKind::EFor(binders_opt, source, body) => {
                    let binders_opt = binders_opt.clone();
                    let body = body.clone();
                    let env = env.clone();
                    let lx = lx.clone();
                    let source = (**source).clone();
                    let x = x.clone();
                    call_then(start_upd_for(lx.clone(), env.clone(), binders_opt.clone(), source.clone(), body.clone(), x.span.clone()), move |upd_for_10789: crate::lower::model::Do| prism_rtl::Turn::Finished((Array::from(vec![upd_for_10789]), env.clone())))
                },
                _ => {
                    let env = env.clone();
                    let lx = lx.clone();
                    let x = x.clone();
                    call_then(crate::lower::expr::start_value_of(lx.clone(), env.clone(), x.clone()), move |value_of_10882: crate::lower::types::Vl| prism_rtl::Turn::Finished((Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::types::own(&value_of_10882))]), env.clone())))
                },
            },
            _ => prism_rtl::Turn::More(Rc::new(crate::lower::expr::BlockStmt { lx: lx.clone(), env: env.clone(), s: s.clone() })),
        }
    }
}

/// `Start UpdStmt, x`: what the function value is when passed to `@Run`.
pub fn start_upd_stmt(lx: crate::lower::Lx, env: crate::lower::types::Env, s: crate::syntax::Stmt) -> Rc<dyn prism_rtl::Job<(Array<crate::lower::model::Do>, crate::lower::types::Env)>> {
    Rc::new(UpdStmt { lx, env, s })
}

/// ```prism
/// UpdFor: unbounded fn Lx, Env, ?ForBinders, Expr, Block, Range -> Do
/// ```
pub fn upd_for(lx: &crate::lower::Lx, env: &crate::lower::types::Env, binders_opt: &Option<crate::syntax::ForBinders>, source: &crate::syntax::Expr, body: &crate::syntax::Block, span: &crate::syntax::Range) -> crate::lower::model::Do {
    let sty = crate::lower::types::peel(&crate::lower::type_at(lx, &source.span));
    match ref_binder(binders_opt) {
        Some(n) => if is_ref_path(source) {
            upd_for_refs(lx, env, &n, source, body, span, &sty)
        } else {
            upd_for_values(lx, env, binders_opt, source, body, span, &sty)
        },
        None => upd_for_values(lx, env, binders_opt, source, body, span, &sty),
    }
}

/// The step machine of `UpdFor`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UpdFor: unbounded fn Lx, Env, ?ForBinders, Expr, Block, Range -> Do
/// ```
pub struct UpdFor {
    pub lx: crate::lower::Lx,
    pub env: crate::lower::types::Env,
    pub binders_opt: Option<crate::syntax::ForBinders>,
    pub source: crate::syntax::Expr,
    pub body: crate::syntax::Block,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<crate::lower::model::Do> for UpdFor {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::Do> {
        let lx = &self.lx;
        let env = &self.env;
        let binders_opt = &self.binders_opt;
        let source = &self.source;
        let body = &self.body;
        let span = &self.span;
        let sty = crate::lower::types::peel(&crate::lower::type_at(lx, &source.span));
        match ref_binder(binders_opt) {
            Some(n) => if is_ref_path(source) {
                prism_rtl::Turn::More(Rc::new(UpdForRefs { lx: lx.clone(), env: env.clone(), n: n.clone(), source: source.clone(), body: body.clone(), span: span.clone(), sty: sty.clone() }))
            } else {
                prism_rtl::Turn::More(Rc::new(UpdForValues { lx: lx.clone(), env: env.clone(), binders_opt: binders_opt.clone(), source: source.clone(), body: body.clone(), span: span.clone(), sty: sty.clone() }))
            },
            None => prism_rtl::Turn::More(Rc::new(UpdForValues { lx: lx.clone(), env: env.clone(), binders_opt: binders_opt.clone(), source: source.clone(), body: body.clone(), span: span.clone(), sty: sty.clone() })),
        }
    }
}

/// `Start UpdFor, x`: what the function value is when passed to `@Run`.
pub fn start_upd_for(lx: crate::lower::Lx, env: crate::lower::types::Env, binders_opt: Option<crate::syntax::ForBinders>, source: crate::syntax::Expr, body: crate::syntax::Block, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<crate::lower::model::Do>> {
    Rc::new(UpdFor { lx, env, binders_opt, source, body, span })
}

/// ```prism
/// UpdForRefs: unbounded fn Lx, Env, SName, Expr, Block, Range, Ty -> Do
/// ```
pub fn upd_for_refs(lx: &crate::lower::Lx, env: &crate::lower::types::Env, n: &crate::syntax::SName, source: &crate::syntax::Expr, body: &crate::syntax::Block, span: &crate::syntax::Range, sty: &crate::check::types::Ty) -> crate::lower::model::Do {
    match sty {
        crate::check::types::Ty::TyArray(v_) => {
            let key_name = Text::from(format!("k{}", &span.start));
            let ref_name = Text::from(format!("r{}", &span.start));
            let env1 = crate::lower::types::bind(&crate::lower::types::bind(&crate::lower::types::bind(env, &Text::lit("key"), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(key_name.clone()), crate::lower::types::Holding::Owned, crate::lower::model::OutTy::OutNat)), &Text::lit("ix"), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(key_name.clone()), crate::lower::types::Holding::Owned, crate::lower::model::OutTy::OutNat)), &crate::check::env::sname_key(n), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XTarget(Rc::new(crate::lower::model::Ex::XVar(ref_name.clone()))), crate::lower::types::Holding::Owned, crate::lower::types::out_ty_of(lx, &**v_)));
            let (dos, _) = upd_stmts(lx, &env1, &body.stmts);
            let head = crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(key_name.clone()), crate::lower::model::Ex::XCall(Text::lit("nat_of"), Array::from(vec![crate::lower::model::Ex::XVar(Text::from(format!("i{}", &span.start)))])));
            crate::lower::model::Do::DoFor(crate::lower::model::Pa::PaTuple(Array::from(vec![crate::lower::model::Pa::PaBind(Text::from(format!("i{}", &span.start))), crate::lower::model::Pa::PaBind(ref_name.clone())])), crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(place_of(lx, env, source)), Text::lit("iter_mut"), Array::new())), Text::lit("enumerate"), Array::new()), append(&Array::from(vec![head.clone()]), &dos))
        },
        _ => crate::lower::expr::refusal_do(&Text::lit("a `for` by reference over what is not an array")),
    }
}

/// The step machine of `UpdForRefs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UpdForRefs: unbounded fn Lx, Env, SName, Expr, Block, Range, Ty -> Do
/// ```
pub struct UpdForRefs {
    pub lx: crate::lower::Lx,
    pub env: crate::lower::types::Env,
    pub n: crate::syntax::SName,
    pub source: crate::syntax::Expr,
    pub body: crate::syntax::Block,
    pub span: crate::syntax::Range,
    pub sty: crate::check::types::Ty,
}

impl prism_rtl::Job<crate::lower::model::Do> for UpdForRefs {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::Do> {
        let lx = &self.lx;
        let env = &self.env;
        let n = &self.n;
        let source = &self.source;
        let body = &self.body;
        let span = &self.span;
        let sty = &self.sty;
        match sty {
            crate::check::types::Ty::TyArray(v_) => {
                let key_name = Text::from(format!("k{}", &span.start));
                let ref_name = Text::from(format!("r{}", &span.start));
                let body = body.clone();
                let env = env.clone();
                let lx = lx.clone();
                let n = n.clone();
                let source = source.clone();
                let span = span.clone();
                let v_ = (**v_).clone();
                call_then(crate::lower::types::start_out_ty_of(lx.clone(), v_.clone()), move |out_ty_of_12242: crate::lower::model::OutTy| {
                    let env1 = crate::lower::types::bind(&crate::lower::types::bind(&crate::lower::types::bind(&env, &Text::lit("key"), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(key_name.clone()), crate::lower::types::Holding::Owned, crate::lower::model::OutTy::OutNat)), &Text::lit("ix"), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(key_name.clone()), crate::lower::types::Holding::Owned, crate::lower::model::OutTy::OutNat)), &crate::check::env::sname_key(&n), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XTarget(Rc::new(crate::lower::model::Ex::XVar(ref_name.clone()))), crate::lower::types::Holding::Owned, out_ty_of_12242));
                    call_then(start_upd_stmts(lx.clone(), env1.clone(), body.stmts.clone()), move |upd_stmts_12288: (Array<crate::lower::model::Do>, crate::lower::types::Env)| {
                        let (dos, _) = upd_stmts_12288;
                        let head = crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(key_name.clone()), crate::lower::model::Ex::XCall(Text::lit("nat_of"), Array::from(vec![crate::lower::model::Ex::XVar(Text::from(format!("i{}", &span.start)))])));
                        call_then(start_place_of(lx.clone(), env.clone(), source.clone()), move |place_of_12497: crate::lower::model::Ex| prism_rtl::Turn::Finished(crate::lower::model::Do::DoFor(crate::lower::model::Pa::PaTuple(Array::from(vec![crate::lower::model::Pa::PaBind(Text::from(format!("i{}", &span.start))), crate::lower::model::Pa::PaBind(ref_name.clone())])), crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(place_of_12497), Text::lit("iter_mut"), Array::new())), Text::lit("enumerate"), Array::new()), append(&Array::from(vec![head.clone()]), &dos))))
                    })
                })
            },
            _ => prism_rtl::Turn::Finished(crate::lower::expr::refusal_do(&Text::lit("a `for` by reference over what is not an array"))),
        }
    }
}

/// `Start UpdForRefs, x`: what the function value is when passed to `@Run`.
pub fn start_upd_for_refs(lx: crate::lower::Lx, env: crate::lower::types::Env, n: crate::syntax::SName, source: crate::syntax::Expr, body: crate::syntax::Block, span: crate::syntax::Range, sty: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::lower::model::Do>> {
    Rc::new(UpdForRefs { lx, env, n, source, body, span, sty })
}

/// ```prism
/// ?RefBinder: fn ?ForBinders -> ?SName
/// ```
pub fn ref_binder(opt0: &Option<crate::syntax::ForBinders>) -> Option<crate::syntax::SName> {
    match opt0 {
        Some(fb) => match &fb.second {
            None => match &*fb.first.kind {
                crate::syntax::PatternKind::PName(n) => if crate::syntax::lexer::chars::has_prefix(&n.sigils, &Text::lit("&")) {
                    Some(n.clone())
                } else {
                    None
                },
                _ => None,
            },
            _ => None,
        },
        None => None,
    }
}

/// ```prism
/// IsRefPath: fn Expr -> Bool
/// ```
pub fn is_ref_path(e: &crate::syntax::Expr) -> bool {
    match &*e.kind {
        crate::syntax::ExprKind::EName(n) => crate::syntax::lexer::chars::has_prefix(&n.sigils, &Text::lit("&")),
        crate::syntax::ExprKind::EField(r, _, _) => is_ref_path(&**r),
        crate::syntax::ExprKind::EIndex(r, _) => is_ref_path(&**r),
        crate::syntax::ExprKind::EGroup(x) => is_ref_path(&**x),
        _ => false,
    }
}

/// ```prism
/// UpdForValues: unbounded fn Lx, Env, ?ForBinders, Expr, Block, Range, Ty -> Do
/// ```
pub fn upd_for_values(lx: &crate::lower::Lx, env: &crate::lower::types::Env, binders_opt: &Option<crate::syntax::ForBinders>, source: &crate::syntax::Expr, body: &crate::syntax::Block, span: &crate::syntax::Range, sty: &crate::check::types::Ty) -> crate::lower::model::Do {
    let src = crate::lower::types::own(&crate::lower::expr::value_of(lx, env, source));
    let (kt, vt, is_array) = match sty {
        crate::check::types::Ty::TyArray(v_) => (crate::lower::model::OutTy::OutNat, crate::lower::types::out_ty_of(lx, &**v_), true),
        crate::check::types::Ty::TyMap(k, v_) => (crate::lower::types::out_ty_of(lx, &**k), crate::lower::types::out_ty_of(lx, &**v_), false),
        _ => (crate::lower::model::OutTy::OutUnit, crate::lower::model::OutTy::OutUnit, true),
    };
    let (vty, kty) = match sty {
        crate::check::types::Ty::TyArray(v_) => ((**v_).clone(), crate::check::types::Ty::TyCon(Text::lit("Nat"), Array::new())),
        crate::check::types::Ty::TyMap(k, v_) => ((**v_).clone(), (**k).clone()),
        _ => (crate::check::types::Ty::TyErr, crate::check::types::Ty::TyErr),
    };
    let key_name = Text::from(format!("k{}", &span.start));
    let val_name = Text::from(format!("v{}", &span.start));
    let env1 = crate::lower::types::bind(&crate::lower::types::bind(env, &Text::lit("key"), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(key_name.clone()), crate::lower::types::Holding::Owned, kt.clone())), &Text::lit("_"), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(val_name.clone()), crate::lower::types::Holding::Owned, vt.clone()));
    let env2 = if is_array {
        crate::lower::types::bind(&env1, &Text::lit("ix"), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(key_name.clone()), crate::lower::types::Holding::Owned, kt.clone()))
    } else {
        env1.clone()
    };
    let (binds, env3) = match binders_opt {
        None => (Array::new(), env2.clone()),
        Some(fb) => match &fb.second {
            None => {
                let po = crate::lower::patterns::rust_pat(lx, &fb.first, &vty, &crate::lower::types::Holding::Owned, &Text::from(format!("e{}", &span.start)));
                (Array::from(vec![crate::lower::model::Do::DoLet(po.pa.clone(), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(val_name.clone()))))]), crate::lower::expr::bind_all(&env2, &po.binds))
            },
            Some(second) => {
                let pk = crate::lower::patterns::rust_pat(lx, &fb.first, &kty, &crate::lower::types::Holding::Owned, &Text::from(format!("k{}_", &span.start)));
                let pv = crate::lower::patterns::rust_pat(lx, second, &vty, &crate::lower::types::Holding::Owned, &Text::from(format!("e{}", &span.start)));
                (Array::from(vec![crate::lower::model::Do::DoLet(pk.pa.clone(), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(key_name.clone())))), crate::lower::model::Do::DoLet(pv.pa.clone(), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(val_name.clone()))))]), crate::lower::expr::bind_all(&crate::lower::expr::bind_all(&env2, &pk.binds), &pv.binds))
            },
        },
    };
    let (dos, _) = upd_stmts(lx, &env3, &body.stmts);
    if is_array {
        {
            let head = crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(key_name.clone()), crate::lower::model::Ex::XCall(Text::lit("nat_of"), Array::from(vec![crate::lower::model::Ex::XVar(Text::from(format!("i{}", &span.start)))])));
            crate::lower::model::Do::DoFor(crate::lower::model::Pa::PaTuple(Array::from(vec![crate::lower::model::Pa::PaBind(Text::from(format!("i{}", &span.start))), crate::lower::model::Pa::PaBind(val_name.clone())])), crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(src.clone()), Text::lit("into_iter"), Array::new())), Text::lit("enumerate"), Array::new()), append(&push(&Array::new(), &head), &append(&binds, &dos)))
        }
    } else {
        crate::lower::model::Do::DoFor(crate::lower::model::Pa::PaTuple(Array::from(vec![crate::lower::model::Pa::PaBind(key_name.clone()), crate::lower::model::Pa::PaBind(val_name.clone())])), crate::lower::model::Ex::XMethod(Rc::new(src.clone()), Text::lit("into_iter"), Array::new()), append(&binds, &dos))
    }
}

/// The step machine of `UpdForValues`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UpdForValues: unbounded fn Lx, Env, ?ForBinders, Expr, Block, Range, Ty -> Do
/// ```
pub struct UpdForValues {
    pub lx: crate::lower::Lx,
    pub env: crate::lower::types::Env,
    pub binders_opt: Option<crate::syntax::ForBinders>,
    pub source: crate::syntax::Expr,
    pub body: crate::syntax::Block,
    pub span: crate::syntax::Range,
    pub sty: crate::check::types::Ty,
}

impl prism_rtl::Job<crate::lower::model::Do> for UpdForValues {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::Do> {
        let lx = &self.lx;
        let env = &self.env;
        let binders_opt = &self.binders_opt;
        let source = &self.source;
        let body = &self.body;
        let span = &self.span;
        let sty = &self.sty;
        let binders_opt = binders_opt.clone();
        let body = body.clone();
        let env = env.clone();
        let lx = lx.clone();
        let source = source.clone();
        let span = span.clone();
        let sty = sty.clone();
        call_then(crate::lower::expr::start_value_of(lx.clone(), env.clone(), source.clone()), move |value_of_13392: crate::lower::types::Vl| {
            let src = crate::lower::types::own(&value_of_13392);
            let (kt, vt, is_array) = match &sty {
                crate::check::types::Ty::TyArray(v_) => (crate::lower::model::OutTy::OutNat, crate::lower::types::out_ty_of(&lx, &**v_), true),
                crate::check::types::Ty::TyMap(k, v_) => (crate::lower::types::out_ty_of(&lx, &**k), crate::lower::types::out_ty_of(&lx, &**v_), false),
                _ => (crate::lower::model::OutTy::OutUnit, crate::lower::model::OutTy::OutUnit, true),
            };
            let (vty, kty) = match &sty {
                crate::check::types::Ty::TyArray(v_) => ((**v_).clone(), crate::check::types::Ty::TyCon(Text::lit("Nat"), Array::new())),
                crate::check::types::Ty::TyMap(k, v_) => ((**v_).clone(), (**k).clone()),
                _ => (crate::check::types::Ty::TyErr, crate::check::types::Ty::TyErr),
            };
            let key_name = Text::from(format!("k{}", &span.start));
            let val_name = Text::from(format!("v{}", &span.start));
            let env1 = crate::lower::types::bind(&crate::lower::types::bind(&env, &Text::lit("key"), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(key_name.clone()), crate::lower::types::Holding::Owned, kt.clone())), &Text::lit("_"), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(val_name.clone()), crate::lower::types::Holding::Owned, vt.clone()));
            let env2 = if is_array {
                crate::lower::types::bind(&env1, &Text::lit("ix"), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(key_name.clone()), crate::lower::types::Holding::Owned, kt.clone()))
            } else {
                env1.clone()
            };
            let (binds, env3) = match &binders_opt {
                None => (Array::new(), env2.clone()),
                Some(fb) => match &fb.second {
                    None => {
                        let po = crate::lower::patterns::rust_pat(&lx, &fb.first, &vty, &crate::lower::types::Holding::Owned, &Text::from(format!("e{}", &span.start)));
                        (Array::from(vec![crate::lower::model::Do::DoLet(po.pa.clone(), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(val_name.clone()))))]), crate::lower::expr::bind_all(&env2, &po.binds))
                    },
                    Some(second) => {
                        let pk = crate::lower::patterns::rust_pat(&lx, &fb.first, &kty, &crate::lower::types::Holding::Owned, &Text::from(format!("k{}_", &span.start)));
                        let pv = crate::lower::patterns::rust_pat(&lx, second, &vty, &crate::lower::types::Holding::Owned, &Text::from(format!("e{}", &span.start)));
                        (Array::from(vec![crate::lower::model::Do::DoLet(pk.pa.clone(), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(key_name.clone())))), crate::lower::model::Do::DoLet(pv.pa.clone(), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(val_name.clone()))))]), crate::lower::expr::bind_all(&crate::lower::expr::bind_all(&env2, &pk.binds), &pv.binds))
                    },
                },
            };
            call_then(start_upd_stmts(lx.clone(), env3.clone(), body.stmts.clone()), move |upd_stmts_14673: (Array<crate::lower::model::Do>, crate::lower::types::Env)| {
                let (dos, _) = upd_stmts_14673;
                if is_array {
                    {
                        let head = crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(key_name.clone()), crate::lower::model::Ex::XCall(Text::lit("nat_of"), Array::from(vec![crate::lower::model::Ex::XVar(Text::from(format!("i{}", &span.start)))])));
                        prism_rtl::Turn::Finished(crate::lower::model::Do::DoFor(crate::lower::model::Pa::PaTuple(Array::from(vec![crate::lower::model::Pa::PaBind(Text::from(format!("i{}", &span.start))), crate::lower::model::Pa::PaBind(val_name.clone())])), crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(src.clone()), Text::lit("into_iter"), Array::new())), Text::lit("enumerate"), Array::new()), append(&push(&Array::new(), &head), &append(&binds, &dos))))
                    }
                } else {
                    prism_rtl::Turn::Finished(crate::lower::model::Do::DoFor(crate::lower::model::Pa::PaTuple(Array::from(vec![crate::lower::model::Pa::PaBind(key_name.clone()), crate::lower::model::Pa::PaBind(val_name.clone())])), crate::lower::model::Ex::XMethod(Rc::new(src.clone()), Text::lit("into_iter"), Array::new()), append(&binds, &dos)))
                }
            })
        })
    }
}

/// `Start UpdForValues, x`: what the function value is when passed to `@Run`.
pub fn start_upd_for_values(lx: crate::lower::Lx, env: crate::lower::types::Env, binders_opt: Option<crate::syntax::ForBinders>, source: crate::syntax::Expr, body: crate::syntax::Block, span: crate::syntax::Range, sty: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::lower::model::Do>> {
    Rc::new(UpdForValues { lx, env, binders_opt, source, body, span, sty })
}

/// ```prism
/// UpdIf: unbounded fn Lx, Env, Cond, Block, ?Block -> Do
/// ```
pub fn upd_if(lx: &crate::lower::Lx, env: &crate::lower::types::Env, c: &crate::syntax::Cond, then_b: &crate::syntax::Block, else_b_opt: &Option<crate::syntax::Block>) -> crate::lower::model::Do {
    let (else_dos, _) = match else_b_opt {
        Some(b) => upd_stmts(lx, env, &b.stmts),
        None => (Array::new(), env.clone()),
    };
    match c {
        crate::syntax::Cond::CondExpr(x) => {
            let (then_dos, _) = upd_stmts(lx, env, &then_b.stmts);
            crate::lower::model::Do::DoIf(crate::lower::types::as_bool(&crate::lower::expr::value_of(lx, env, &**x)), then_dos.clone(), else_dos.clone())
        },
        crate::syntax::Cond::CondBind(p_, x, _) => {
            let po = crate::lower::patterns::rust_pat(lx, p_, &crate::lower::type_at(lx, &x.span), &crate::lower::types::Holding::Owned, &Text::from(format!("u{}", &x.span.start)));
            let (then_dos, _) = upd_stmts(lx, &crate::lower::expr::bind_all(env, &po.binds), &then_b.stmts);
            crate::lower::model::Do::DoIfLet(po.pa.clone(), crate::lower::types::own(&crate::lower::expr::value_of(lx, env, &**x)), then_dos.clone(), else_dos.clone())
        },
    }
}

/// The step machine of `UpdIf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UpdIf: unbounded fn Lx, Env, Cond, Block, ?Block -> Do
/// ```
pub struct UpdIf {
    pub lx: crate::lower::Lx,
    pub env: crate::lower::types::Env,
    pub c: crate::syntax::Cond,
    pub then_b: crate::syntax::Block,
    pub else_b_opt: Option<crate::syntax::Block>,
}

impl prism_rtl::Job<crate::lower::model::Do> for UpdIf {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::Do> {
        let lx = &self.lx;
        let env = &self.env;
        let c = &self.c;
        let then_b = &self.then_b;
        let else_b_opt = &self.else_b_opt;
        let (else_dos, _) = match else_b_opt {
            Some(b) => upd_stmts(lx, env, &b.stmts),
            None => (Array::new(), env.clone()),
        };
        match c {
            crate::syntax::Cond::CondExpr(x) => {
                let env = env.clone();
                let lx = lx.clone();
                let then_b = then_b.clone();
                let x = (**x).clone();
                call_then(start_upd_stmts(lx.clone(), env.clone(), then_b.stmts.clone()), move |upd_stmts_15383: (Array<crate::lower::model::Do>, crate::lower::types::Env)| {
                    let (then_dos, _) = upd_stmts_15383;
                    call_then(crate::lower::expr::start_value_of(lx.clone(), env.clone(), x.clone()), move |value_of_15439: crate::lower::types::Vl| prism_rtl::Turn::Finished(crate::lower::model::Do::DoIf(crate::lower::types::as_bool(&value_of_15439), then_dos.clone(), else_dos.clone())))
                })
            },
            crate::syntax::Cond::CondBind(p_, x, _) => {
                let env = env.clone();
                let lx = lx.clone();
                let p_ = p_.clone();
                let then_b = then_b.clone();
                let x = (**x).clone();
                call_then(crate::lower::patterns::start_rust_pat(lx.clone(), p_.clone(), crate::lower::type_at(&lx, &x.span), crate::lower::types::Holding::Owned, Text::from(format!("u{}", &x.span.start))), move |rust_pat_15530: crate::lower::patterns::PatOut| {
                    let po = rust_pat_15530;
                    call_then(start_upd_stmts(lx.clone(), crate::lower::expr::bind_all(&env, &po.binds), then_b.stmts.clone()), move |upd_stmts_15629: (Array<crate::lower::model::Do>, crate::lower::types::Env)| {
                        let (then_dos, _) = upd_stmts_15629;
                        call_then(crate::lower::expr::start_value_of(lx.clone(), env.clone(), x.clone()), move |value_of_15712: crate::lower::types::Vl| prism_rtl::Turn::Finished(crate::lower::model::Do::DoIfLet(po.pa.clone(), crate::lower::types::own(&value_of_15712), then_dos.clone(), else_dos.clone())))
                    })
                })
            },
        }
    }
}

/// `Start UpdIf, x`: what the function value is when passed to `@Run`.
pub fn start_upd_if(lx: crate::lower::Lx, env: crate::lower::types::Env, c: crate::syntax::Cond, then_b: crate::syntax::Block, else_b_opt: Option<crate::syntax::Block>) -> Rc<dyn prism_rtl::Job<crate::lower::model::Do>> {
    Rc::new(UpdIf { lx, env, c, then_b, else_b_opt })
}

/// ```prism
/// UpdMatch: unbounded fn Lx, Env, Expr, [Arm] -> Do
/// ```
pub fn upd_match(lx: &crate::lower::Lx, env: &crate::lower::types::Env, scrut: &crate::syntax::Expr, arms: &Array<crate::syntax::Arm>) -> crate::lower::model::Do {
    let sv = crate::lower::expr::value_of(lx, env, scrut);
    let sty = crate::lower::type_at(lx, &scrut.span);
    let arms3 = run_to_end(each_job(crate::check::errors::range0(&len(arms)), {
        let arms = arms.clone();
        let lx = lx.clone();
        let sty = sty.clone();
        let scrut = scrut.clone();
        let env = env.clone();
        Rc::new(move |p0: Nat| {
            let arms = arms.clone();
            let lx = lx.clone();
            let sty = sty.clone();
            let scrut = scrut.clone();
            let env = env.clone();
            entered(once_job(move || {
                let i = p0;
                {
                    let arm = or(&index(&arms, &i), &crate::lower::expr::dummy_arm());
                    call_then(crate::lower::expr::start_arm_pat(lx.clone(), arm.pattern.clone(), sty.clone(), crate::lower::types::Holding::ByRef, Text::from(format!("u{}_{}", &scrut.span.start, &i))), move |arm_pat_16011: crate::lower::patterns::PatOut| {
                        let po = arm_pat_16011;
                        call_then(start_upd_stmts(lx.clone(), crate::lower::expr::bind_all(&env, &po.binds), arm.body.stmts.clone()), move |upd_stmts_16104: (Array<crate::lower::model::Do>, crate::lower::types::Env)| {
                            let (dos, _) = upd_stmts_16104;
                            call_then(start_guard_conds(lx.clone(), crate::lower::expr::bind_all(&env, &po.binds), arm.guard.clone()), move |guard_conds_16197: Array<crate::lower::model::Cc>| {
                                let guarded = append(&po.conds, &guard_conds_16197);
                                prism_rtl::Turn::Finished(crate::lower::model::XArm { pat: po.pa.clone(), conds: guarded.clone(), body: crate::lower::model::Ex::XBlock(dos.clone(), Rc::new(crate::lower::model::Ex::XUnit)) })
                            })
                        })
                    })
                }
            }))
        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<crate::lower::model::XArm>>>
    }));
    if fold(&arms3, &false, &(|f: &bool, a: &crate::lower::model::XArm| *f || (&len(&a.conds) > &Nat::from(0u32)))) {
        crate::lower::model::Do::DoExpr(crate::lower::types::own(&crate::lower::expr::arms_value(&crate::lower::types::ref_(&sv), &arms3, &Text::from(format!("\'u{}", &scrut.span.start)), &crate::lower::model::OutTy::OutUnit)))
    } else {
        crate::lower::model::Do::DoMatch(crate::lower::types::ref_(&sv), each(&arms3, &(|a: &crate::lower::model::XArm| (a.pat.clone(), arm_dos(&a.body)))))
    }
}

/// The step machine of `UpdMatch`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UpdMatch: unbounded fn Lx, Env, Expr, [Arm] -> Do
/// ```
pub struct UpdMatch {
    pub lx: crate::lower::Lx,
    pub env: crate::lower::types::Env,
    pub scrut: crate::syntax::Expr,
    pub arms: Array<crate::syntax::Arm>,
}

impl prism_rtl::Job<crate::lower::model::Do> for UpdMatch {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::Do> {
        let lx = &self.lx;
        let env = &self.env;
        let scrut = &self.scrut;
        let arms = &self.arms;
        let arms = arms.clone();
        let env = env.clone();
        let lx = lx.clone();
        let scrut = scrut.clone();
        call_then(crate::lower::expr::start_value_of(lx.clone(), env.clone(), scrut.clone()), move |value_of_15849: crate::lower::types::Vl| {
            let sv = value_of_15849;
            let sty = crate::lower::type_at(&lx, &scrut.span);
            call_value(each_job(crate::check::errors::range0(&len(&arms)), {
                let arms = arms.clone();
                let lx = lx.clone();
                let sty = sty.clone();
                let scrut = scrut.clone();
                let env = env.clone();
                Rc::new(move |p0: Nat| {
                    let arms = arms.clone();
                    let lx = lx.clone();
                    let sty = sty.clone();
                    let scrut = scrut.clone();
                    let env = env.clone();
                    entered(once_job(move || {
                        let i = p0;
                        {
                            let arm = or(&index(&arms, &i), &crate::lower::expr::dummy_arm());
                            call_then(crate::lower::expr::start_arm_pat(lx.clone(), arm.pattern.clone(), sty.clone(), crate::lower::types::Holding::ByRef, Text::from(format!("u{}_{}", &scrut.span.start, &i))), move |arm_pat_16011: crate::lower::patterns::PatOut| {
                                let po = arm_pat_16011;
                                call_then(start_upd_stmts(lx.clone(), crate::lower::expr::bind_all(&env, &po.binds), arm.body.stmts.clone()), move |upd_stmts_16104: (Array<crate::lower::model::Do>, crate::lower::types::Env)| {
                                    let (dos, _) = upd_stmts_16104;
                                    call_then(start_guard_conds(lx.clone(), crate::lower::expr::bind_all(&env, &po.binds), arm.guard.clone()), move |guard_conds_16197: Array<crate::lower::model::Cc>| {
                                        let guarded = append(&po.conds, &guard_conds_16197);
                                        prism_rtl::Turn::Finished(crate::lower::model::XArm { pat: po.pa.clone(), conds: guarded.clone(), body: crate::lower::model::Ex::XBlock(dos.clone(), Rc::new(crate::lower::model::Ex::XUnit)) })
                                    })
                                })
                            })
                        }
                    }))
                }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<crate::lower::model::XArm>>>
            }), move |each_15924: Array<crate::lower::model::XArm>| {
                let arms3 = each_15924;
                if fold(&arms3, &false, &(|f: &bool, a: &crate::lower::model::XArm| *f || (&len(&a.conds) > &Nat::from(0u32)))) {
                    prism_rtl::Turn::Finished(crate::lower::model::Do::DoExpr(crate::lower::types::own(&crate::lower::expr::arms_value(&crate::lower::types::ref_(&sv), &arms3, &Text::from(format!("\'u{}", &scrut.span.start)), &crate::lower::model::OutTy::OutUnit))))
                } else {
                    prism_rtl::Turn::Finished(crate::lower::model::Do::DoMatch(crate::lower::types::ref_(&sv), each(&arms3, &(|a: &crate::lower::model::XArm| (a.pat.clone(), arm_dos(&a.body))))))
                }
            })
        })
    }
}

/// `Start UpdMatch, x`: what the function value is when passed to `@Run`.
pub fn start_upd_match(lx: crate::lower::Lx, env: crate::lower::types::Env, scrut: crate::syntax::Expr, arms: Array<crate::syntax::Arm>) -> Rc<dyn prism_rtl::Job<crate::lower::model::Do>> {
    Rc::new(UpdMatch { lx, env, scrut, arms })
}

/// ```prism
/// AllOf: fn [Ex] -> Ex
/// ```
pub fn all_of(xs0: &Array<crate::lower::model::Ex>) -> crate::lower::model::Ex {
    'c: {
        if let c0_0 = xs0 && (c0_0.len() == 1) && let Some(one) = index(c0_0, &Nat::from(0u32)) {
            break 'c one.clone();
        }
        if let xs = xs0 {
            break 'c fold(&drop(xs, &Nat::from(1u32)), &or(&index(xs, &Nat::from(0u32)), &crate::lower::model::Ex::XBool(true)), &(|acc: &crate::lower::model::Ex, x: &crate::lower::model::Ex| crate::lower::model::Ex::XBin(Text::lit("&&"), Rc::new(acc.clone()), Rc::new(x.clone()))));
        }
        unreachable!("no clause matched")
    }
}

/// ```prism
/// ArmDos: fn Ex -> [Do]
/// ```
pub fn arm_dos(ex0: &crate::lower::model::Ex) -> Array<crate::lower::model::Do> {
    match ex0 {
        crate::lower::model::Ex::XBlock(dos, _) => dos.clone(),
        x => Array::from(vec![crate::lower::model::Do::DoExpr(x.clone())]),
    }
}

/// ```prism
/// GuardConds: unbounded fn Lx, Env, ?Expr -> [Cc]
/// ```
pub fn guard_conds(lx: &crate::lower::Lx, env: &crate::lower::types::Env, opt2: &Option<crate::syntax::Expr>) -> Array<crate::lower::model::Cc> {
    match opt2 {
        Some(ge) => Array::from(vec![crate::lower::model::Cc::CcIf(crate::lower::types::as_bool(&crate::lower::expr::value_of(lx, env, ge)))]),
        None => Array::new(),
    }
}

/// The step machine of `GuardConds`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// GuardConds: unbounded fn Lx, Env, ?Expr -> [Cc]
/// ```
pub struct GuardConds {
    pub lx: crate::lower::Lx,
    pub env: crate::lower::types::Env,
    pub opt2: Option<crate::syntax::Expr>,
}

impl prism_rtl::Job<Array<crate::lower::model::Cc>> for GuardConds {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::lower::model::Cc>> {
        let lx = &self.lx;
        let env = &self.env;
        let opt2 = &self.opt2;
        match opt2 {
            Some(ge) => {
                let env = env.clone();
                let ge = ge.clone();
                let lx = lx.clone();
                call_then(crate::lower::expr::start_value_of(lx.clone(), env.clone(), ge.clone()), move |value_of_17039: crate::lower::types::Vl| prism_rtl::Turn::Finished(Array::from(vec![crate::lower::model::Cc::CcIf(crate::lower::types::as_bool(&value_of_17039))])))
            },
            None => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start GuardConds, x`: what the function value is when passed to `@Run`.
pub fn start_guard_conds(lx: crate::lower::Lx, env: crate::lower::types::Env, opt2: Option<crate::syntax::Expr>) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Cc>>> {
    Rc::new(GuardConds { lx, env, opt2 })
}

/// ```prism
/// PlaceOf: unbounded fn Lx, Env, Expr -> Ex
/// ```
pub fn place_of(lx: &crate::lower::Lx, env: &crate::lower::types::Env, e: &crate::syntax::Expr) -> crate::lower::model::Ex {
    match &*e.kind {
        crate::syntax::ExprKind::EName(n) => match get(&env.names, &crate::check::env::sname_key(n)) {
            Some(crate::lower::types::Bn::BnLocal(rs, _, _)) => rs.clone(),
            _ => crate::lower::model::Ex::XVar(crate::lower::snake(&crate::check::env::sname_key(n))),
        },
        crate::syntax::ExprKind::EField(r, _, name) => crate::lower::model::Ex::XField(Rc::new(place_of(lx, env, &**r)), crate::lower::snake(&name.name)),
        crate::syntax::ExprKind::EIndex(r, k) => {
            let rt = crate::lower::types::out_ty_of(lx, &crate::lower::types::peel(&crate::lower::type_at(lx, &r.span)));
            let f = match &rt {
                crate::lower::model::OutTy::OutMap(_, _) => Text::lit("at_mut_map"),
                _ => Text::lit("at_mut"),
            };
            crate::lower::model::Ex::XDeref(Rc::new(crate::lower::model::Ex::XCall(f.clone(), Array::from(vec![crate::lower::model::Ex::XRefMut(Rc::new(place_of(lx, env, &**r))), crate::lower::expr::argument(lx, env, &**k)]))))
        },
        crate::syntax::ExprKind::EGroup(x) => place_of(lx, env, &**x),
        _ => crate::lower::expr::refusal(&Text::lit("a reference path this back end does not lower")),
    }
}

/// The step machine of `PlaceOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PlaceOf: unbounded fn Lx, Env, Expr -> Ex
/// ```
pub struct PlaceOf {
    pub lx: crate::lower::Lx,
    pub env: crate::lower::types::Env,
    pub e: crate::syntax::Expr,
}

impl prism_rtl::Job<crate::lower::model::Ex> for PlaceOf {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::Ex> {
        let lx = &self.lx;
        let env = &self.env;
        let e = &self.e;
        match &*e.kind {
            crate::syntax::ExprKind::EName(n) => match get(&env.names, &crate::check::env::sname_key(n)) {
                Some(crate::lower::types::Bn::BnLocal(rs, _, _)) => prism_rtl::Turn::Finished(rs.clone()),
                _ => prism_rtl::Turn::Finished(crate::lower::model::Ex::XVar(crate::lower::snake(&crate::check::env::sname_key(n)))),
            },
            crate::syntax::ExprKind::EField(r, _, name) => {
                let env = env.clone();
                let lx = lx.clone();
                let name = name.clone();
                let r = (**r).clone();
                call_then(start_place_of(lx.clone(), env.clone(), r.clone()), move |place_of_17407: crate::lower::model::Ex| prism_rtl::Turn::Finished(crate::lower::model::Ex::XField(Rc::new(place_of_17407), crate::lower::snake(&name.name))))
            },
            crate::syntax::ExprKind::EIndex(r, k) => {
                let env = env.clone();
                let k = (**k).clone();
                let lx = lx.clone();
                let r = (**r).clone();
                call_then(crate::lower::types::start_out_ty_of(lx.clone(), crate::lower::types::peel(&crate::lower::type_at(&lx, &r.span))), move |out_ty_of_17480: crate::lower::model::OutTy| {
                    let rt = out_ty_of_17480;
                    let f = match &rt {
                        crate::lower::model::OutTy::OutMap(_, _) => Text::lit("at_mut_map"),
                        _ => Text::lit("at_mut"),
                    };
                    call_then(start_place_of(lx.clone(), env.clone(), r.clone()), move |place_of_17662: crate::lower::model::Ex| call_then(crate::lower::expr::start_argument(lx.clone(), env.clone(), k.clone()), move |argument_17685: crate::lower::model::Ex| prism_rtl::Turn::Finished(crate::lower::model::Ex::XDeref(Rc::new(crate::lower::model::Ex::XCall(f.clone(), Array::from(vec![crate::lower::model::Ex::XRefMut(Rc::new(place_of_17662)), argument_17685])))))))
                })
            },
            crate::syntax::ExprKind::EGroup(x) => prism_rtl::Turn::More(Rc::new(PlaceOf { lx: lx.clone(), env: env.clone(), e: (**x).clone() })),
            _ => prism_rtl::Turn::Finished(crate::lower::expr::refusal(&Text::lit("a reference path this back end does not lower"))),
        }
    }
}

/// `Start PlaceOf, x`: what the function value is when passed to `@Run`.
pub fn start_place_of(lx: crate::lower::Lx, env: crate::lower::types::Env, e: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>> {
    Rc::new(PlaceOf { lx, env, e })
}

/// ```prism
/// Assign: unbounded fn Lx, Env, Expr, Ex -> Do
/// ```
pub fn assign(lx: &crate::lower::Lx, env: &crate::lower::types::Env, target: &crate::syntax::Expr, v_: &crate::lower::model::Ex) -> crate::lower::model::Do {
    match &*target.kind {
        crate::syntax::ExprKind::EIndex(r, k) => {
            let rt = crate::lower::types::out_ty_of(lx, &crate::lower::types::peel(&crate::lower::type_at(lx, &r.span)));
            let f = match &rt {
                crate::lower::model::OutTy::OutMap(_, _) => Text::lit("set_key"),
                _ => Text::lit("set_index"),
            };
            crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XCall(f.clone(), Array::from(vec![crate::lower::model::Ex::XRefMut(Rc::new(place_of(lx, env, &**r))), crate::lower::expr::argument(lx, env, &**k), v_.clone()])))
        },
        crate::syntax::ExprKind::EGroup(x) => assign(lx, env, &**x, v_),
        _ => crate::lower::model::Do::DoAssign(place_of(lx, env, target), v_.clone()),
    }
}

/// The step machine of `Assign`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Assign: unbounded fn Lx, Env, Expr, Ex -> Do
/// ```
pub struct Assign {
    pub lx: crate::lower::Lx,
    pub env: crate::lower::types::Env,
    pub target: crate::syntax::Expr,
    pub v_: crate::lower::model::Ex,
}

impl prism_rtl::Job<crate::lower::model::Do> for Assign {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::Do> {
        let lx = &self.lx;
        let env = &self.env;
        let target = &self.target;
        let v_ = &self.v_;
        match &*target.kind {
            crate::syntax::ExprKind::EIndex(r, k) => {
                let env = env.clone();
                let k = (**k).clone();
                let lx = lx.clone();
                let r = (**r).clone();
                let v_ = v_.clone();
                call_then(crate::lower::types::start_out_ty_of(lx.clone(), crate::lower::types::peel(&crate::lower::type_at(&lx, &r.span))), move |out_ty_of_18093: crate::lower::model::OutTy| {
                    let rt = out_ty_of_18093;
                    let f = match &rt {
                        crate::lower::model::OutTy::OutMap(_, _) => Text::lit("set_key"),
                        _ => Text::lit("set_index"),
                    };
                    call_then(start_place_of(lx.clone(), env.clone(), r.clone()), move |place_of_18275: crate::lower::model::Ex| call_then(crate::lower::expr::start_argument(lx.clone(), env.clone(), k.clone()), move |argument_18298: crate::lower::model::Ex| prism_rtl::Turn::Finished(crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XCall(f.clone(), Array::from(vec![crate::lower::model::Ex::XRefMut(Rc::new(place_of_18275)), argument_18298, v_.clone()]))))))
                })
            },
            crate::syntax::ExprKind::EGroup(x) => prism_rtl::Turn::More(Rc::new(Assign { lx: lx.clone(), env: env.clone(), target: (**x).clone(), v_: v_.clone() })),
            _ => {
                let env = env.clone();
                let lx = lx.clone();
                let target = target.clone();
                let v_ = v_.clone();
                call_then(start_place_of(lx.clone(), env.clone(), target.clone()), move |place_of_18385: crate::lower::model::Ex| prism_rtl::Turn::Finished(crate::lower::model::Do::DoAssign(place_of_18385, v_.clone())))
            },
        }
    }
}

/// `Start Assign, x`: what the function value is when passed to `@Run`.
pub fn start_assign(lx: crate::lower::Lx, env: crate::lower::types::Env, target: crate::syntax::Expr, v_: crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<crate::lower::model::Do>> {
    Rc::new(Assign { lx, env, target, v_ })
}
