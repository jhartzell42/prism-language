//! The module `Lower.Templates`, from `target/bootstrap/src/prismc/lower/templates.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// ```prism
/// TemplateValue: unbounded fn Lx, Env, Template -> Vl
/// ```
pub fn template_value(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, tp_p2: &crate::syntax::Template) -> crate::lower::types::Vl {
    let start_p3 = Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaMut(Text::lit("out")), crate::lower::model::Ex::XCall(Text::lit("String::new"), Array::new()))]);
    let dos_p4 = run_to_end(fold_job(tp_p2.parts.clone(), start_p3.clone(), {
        let lx_p0 = lx_p0.clone();
        let env_p1 = env_p1.clone();
        Rc::new(move |(p0, p1): (Array<crate::lower::model::Do>, crate::syntax::TemplatePart)| {
            let lx_p0 = lx_p0.clone();
            let env_p1 = env_p1.clone();
            entered(once_job(move || {
                let acc_p5 = p0;
                let part_p6 = p1;
                call_then(start_template_part_dos(lx_p0.clone(), env_p1.clone(), part_p6.clone()), move |template_part_dos_1601: Array<crate::lower::model::Do>| prism_rtl::Turn::Finished(append(&acc_p5, &template_part_dos_1601)))
            }))
        }) as Rc<dyn Fn((Array<crate::lower::model::Do>, crate::syntax::TemplatePart)) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>
    }));
    crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XBlock(dos_p4.clone(), Rc::new(crate::lower::model::Ex::XCall(Text::lit("Text::from"), Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("out"))])))), crate::lower::model::OutTy::OutText)
}

/// The step machine of `TemplateValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TemplateValue: unbounded fn Lx, Env, Template -> Vl
/// ```
pub struct TemplateValue {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub tp_p2: crate::syntax::Template,
}

impl prism_rtl::Job<crate::lower::types::Vl> for TemplateValue {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::types::Vl> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let tp_p2 = &self.tp_p2;
        let start_p3 = Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaMut(Text::lit("out")), crate::lower::model::Ex::XCall(Text::lit("String::new"), Array::new()))]);
        let env_p1 = env_p1.clone();
        let lx_p0 = lx_p0.clone();
        let tp_p2 = tp_p2.clone();
        call_value(fold_job(tp_p2.parts.clone(), start_p3.clone(), {
            let lx_p0 = lx_p0.clone();
            let env_p1 = env_p1.clone();
            Rc::new(move |(p0, p1): (Array<crate::lower::model::Do>, crate::syntax::TemplatePart)| {
                let lx_p0 = lx_p0.clone();
                let env_p1 = env_p1.clone();
                entered(once_job(move || {
                    let acc_p5 = p0;
                    let part_p6 = p1;
                    call_then(start_template_part_dos(lx_p0.clone(), env_p1.clone(), part_p6.clone()), move |template_part_dos_1601: Array<crate::lower::model::Do>| prism_rtl::Turn::Finished(append(&acc_p5, &template_part_dos_1601)))
                }))
            }) as Rc<dyn Fn((Array<crate::lower::model::Do>, crate::syntax::TemplatePart)) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>
        }), move |fold_1553: Array<crate::lower::model::Do>| {
            let dos_p4 = fold_1553;
            prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XBlock(dos_p4.clone(), Rc::new(crate::lower::model::Ex::XCall(Text::lit("Text::from"), Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("out"))])))), crate::lower::model::OutTy::OutText))
        })
    }
}

/// `Start TemplateValue, x`: what the function value is when passed to `@Run`.
pub fn start_template_value(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, tp_p2: crate::syntax::Template) -> Rc<dyn prism_rtl::Job<crate::lower::types::Vl>> {
    Rc::new(TemplateValue { lx_p0, env_p1, tp_p2 })
}

/// ```prism
/// TemplatePartDos: unbounded fn Lx, Env, TemplatePart -> [Do]
/// ```
pub fn template_part_dos(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, part_p2: &crate::syntax::TemplatePart) -> Array<crate::lower::model::Do> {
    match part_p2 {
        crate::syntax::TemplatePart::TpText(t_p3) => Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("out"))), Text::lit("push_str"), Array::from(vec![crate::lower::model::Ex::XStr(t_p3.clone())])))]),
        crate::syntax::TemplatePart::TpPlaceholder(x_p4, col_o5) => {
            let v_p6 = crate::lower::expr::value_of(lx_p0, env_p1, x_p4);
            let column_p7 = match col_o5 {
                Some(c_p8) => crate::lower::model::Ex::XCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Ex::XIndex(c_p8.clone())])),
                None => crate::lower::model::Ex::XNone,
            };
            Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XCall(Text::lit("place"), Array::from(vec![crate::lower::model::Ex::XRefMut(Rc::new(crate::lower::model::Ex::XVar(Text::lit("out")))), shown_text(&v_p6), column_p7.clone()])))])
        },
        crate::syntax::TemplatePart::TpBlock(b_p9) => {
            let v_pa = crate::lower::expr::block_value(lx_p0, env_p1, b_p9);
            if &crate::lower::types::value_ty(&v_pa) == &crate::lower::model::OutTy::OutUnit {
                Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::types::own(&v_pa))])
            } else {
                Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XCall(Text::lit("place"), Array::from(vec![crate::lower::model::Ex::XRefMut(Rc::new(crate::lower::model::Ex::XVar(Text::lit("out")))), shown_text(&v_pa), crate::lower::model::Ex::XNone])))])
            }
        },
        crate::syntax::TemplatePart::TpCall(n_pb, args_pc, parts_od, _) => {
            let plain_pe = crate::syntax::SName { sigils: crate::syntax::lexer::chars::after_first(&n_pb.sigils), path_: n_pb.path_.clone(), span: n_pb.span.clone() };
            let (qk_oj, _) = crate::check::env::names::resolve_value(&lx_p0.g, &lx_p0.home, n_pb);
            let (qk2_ok, _) = crate::check::env::names::resolve_value(&lx_p0.g, &lx_p0.home, &plain_pe);
            let callee_pf = match &qk_oj {
                Some(q_pl) => crate::lower::value_path(lx_p0, q_pl),
                None => match &qk2_ok {
                    Some(q_pm) => crate::lower::value_path(lx_p0, q_pm),
                    None => crate::lower::snake(&crate::check::env::sname_key(n_pb)),
                },
            };
            let body_pg = match parts_od {
                Some(ps_pn) => {
                    let inner_po = run_to_end(fold_job(ps_pn.clone(), Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaMut(Text::lit("out")), crate::lower::model::Ex::XCall(Text::lit("String::new"), Array::new()))]), {
                        let lx_p0 = lx_p0.clone();
                        let env_p1 = env_p1.clone();
                        Rc::new(move |(p0, p1): (Array<crate::lower::model::Do>, crate::syntax::TemplatePart)| {
                            let lx_p0 = lx_p0.clone();
                            let env_p1 = env_p1.clone();
                            entered(once_job(move || {
                                let acc_pp = p0;
                                let p_pq = p1;
                                call_then(start_template_part_dos(lx_p0.clone(), env_p1.clone(), p_pq.clone()), move |template_part_dos_2911: Array<crate::lower::model::Do>| prism_rtl::Turn::Finished(append(&acc_pp, &template_part_dos_2911)))
                            }))
                        }) as Rc<dyn Fn((Array<crate::lower::model::Do>, crate::syntax::TemplatePart)) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>
                    }));
                    Array::from(vec![crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XBlock(inner_po.clone(), Rc::new(crate::lower::model::Ex::XCall(Text::lit("Text::from"), Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("out"))]))))))])
                },
                None => Array::new(),
            };
            let passed_ph = match &qk_oj {
                Some(q_pr) => template_args(lx_p0, env_p1, q_pr, args_pc, &body_pg),
                None => match &qk2_ok {
                    Some(q_ps) => template_args(lx_p0, env_p1, q_ps, args_pc, &body_pg),
                    None => append(&run_to_end(each_job(args_pc.clone(), {
                        let lx_p0 = lx_p0.clone();
                        let env_p1 = env_p1.clone();
                        Rc::new(move |p0: crate::syntax::Arg| {
                            let lx_p0 = lx_p0.clone();
                            let env_p1 = env_p1.clone();
                            entered(once_job(move || {
                                let a_pt = p0;
                                prism_rtl::Turn::More(Rc::new(crate::lower::expr::Argument { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), e_p2: a_pt.value.clone() }))
                            }))
                        }) as Rc<dyn Fn(crate::syntax::Arg) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
                    })), &body_pg),
                },
            };
            let call_pi = crate::lower::model::Ex::XCall(callee_pf.clone(), passed_ph.clone());
            Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XCall(Text::lit("place"), Array::from(vec![crate::lower::model::Ex::XRefMut(Rc::new(crate::lower::model::Ex::XVar(Text::lit("out")))), crate::lower::model::Ex::XRef(Rc::new(call_pi.clone())), crate::lower::model::Ex::XNone])))])
        },
    }
}

/// The step machine of `TemplatePartDos`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TemplatePartDos: unbounded fn Lx, Env, TemplatePart -> [Do]
/// ```
pub struct TemplatePartDos {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub part_p2: crate::syntax::TemplatePart,
}

impl prism_rtl::Job<Array<crate::lower::model::Do>> for TemplatePartDos {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::lower::model::Do>> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let part_p2 = &self.part_p2;
        match part_p2 {
            crate::syntax::TemplatePart::TpText(t_p3) => prism_rtl::Turn::Finished(Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("out"))), Text::lit("push_str"), Array::from(vec![crate::lower::model::Ex::XStr(t_p3.clone())])))])),
            crate::syntax::TemplatePart::TpPlaceholder(x_p4, col_o5) => {
                let col_o5 = col_o5.clone();
                let env_p1 = env_p1.clone();
                let lx_p0 = lx_p0.clone();
                let x_p4 = x_p4.clone();
                call_then(crate::lower::expr::start_value_of(lx_p0.clone(), env_p1.clone(), x_p4.clone()), move |value_of_1931: crate::lower::types::Vl| {
                    let v_p6 = value_of_1931;
                    let column_p7 = match &col_o5 {
                        Some(c_p8) => crate::lower::model::Ex::XCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Ex::XIndex(c_p8.clone())])),
                        None => crate::lower::model::Ex::XNone,
                    };
                    prism_rtl::Turn::Finished(Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XCall(Text::lit("place"), Array::from(vec![crate::lower::model::Ex::XRefMut(Rc::new(crate::lower::model::Ex::XVar(Text::lit("out")))), shown_text(&v_p6), column_p7.clone()])))]))
                })
            },
            crate::syntax::TemplatePart::TpBlock(b_p9) => {
                let b_p9 = b_p9.clone();
                let env_p1 = env_p1.clone();
                let lx_p0 = lx_p0.clone();
                call_then(crate::lower::expr::start_block_value(lx_p0.clone(), env_p1.clone(), b_p9.clone()), move |block_value_2165: crate::lower::types::Vl| {
                    let v_pa = block_value_2165;
                    if &crate::lower::types::value_ty(&v_pa) == &crate::lower::model::OutTy::OutUnit {
                        prism_rtl::Turn::Finished(Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::types::own(&v_pa))]))
                    } else {
                        prism_rtl::Turn::Finished(Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XCall(Text::lit("place"), Array::from(vec![crate::lower::model::Ex::XRefMut(Rc::new(crate::lower::model::Ex::XVar(Text::lit("out")))), shown_text(&v_pa), crate::lower::model::Ex::XNone])))]))
                    }
                })
            },
            crate::syntax::TemplatePart::TpCall(n_pb, args_pc, parts_od, _) => {
                let plain_pe = crate::syntax::SName { sigils: crate::syntax::lexer::chars::after_first(&n_pb.sigils), path_: n_pb.path_.clone(), span: n_pb.span.clone() };
                let (qk_oj, _) = crate::check::env::names::resolve_value(&lx_p0.g, &lx_p0.home, n_pb);
                let (qk2_ok, _) = crate::check::env::names::resolve_value(&lx_p0.g, &lx_p0.home, &plain_pe);
                let callee_pf = match &qk_oj {
                    Some(q_pl) => crate::lower::value_path(lx_p0, q_pl),
                    None => match &qk2_ok {
                        Some(q_pm) => crate::lower::value_path(lx_p0, q_pm),
                        None => crate::lower::snake(&crate::check::env::sname_key(n_pb)),
                    },
                };
                let body_pg = match parts_od {
                    Some(ps_pn) => {
                        let inner_po = run_to_end(fold_job(ps_pn.clone(), Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaMut(Text::lit("out")), crate::lower::model::Ex::XCall(Text::lit("String::new"), Array::new()))]), {
                            let lx_p0 = lx_p0.clone();
                            let env_p1 = env_p1.clone();
                            Rc::new(move |(p0, p1): (Array<crate::lower::model::Do>, crate::syntax::TemplatePart)| {
                                let lx_p0 = lx_p0.clone();
                                let env_p1 = env_p1.clone();
                                entered(once_job(move || {
                                    let acc_pp = p0;
                                    let p_pq = p1;
                                    call_then(start_template_part_dos(lx_p0.clone(), env_p1.clone(), p_pq.clone()), move |template_part_dos_2911: Array<crate::lower::model::Do>| prism_rtl::Turn::Finished(append(&acc_pp, &template_part_dos_2911)))
                                }))
                            }) as Rc<dyn Fn((Array<crate::lower::model::Do>, crate::syntax::TemplatePart)) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>
                        }));
                        Array::from(vec![crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XBlock(inner_po.clone(), Rc::new(crate::lower::model::Ex::XCall(Text::lit("Text::from"), Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("out"))]))))))])
                    },
                    None => Array::new(),
                };
                let passed_ph = match &qk_oj {
                    Some(q_pr) => template_args(lx_p0, env_p1, q_pr, args_pc, &body_pg),
                    None => match &qk2_ok {
                        Some(q_ps) => template_args(lx_p0, env_p1, q_ps, args_pc, &body_pg),
                        None => append(&run_to_end(each_job(args_pc.clone(), {
                            let lx_p0 = lx_p0.clone();
                            let env_p1 = env_p1.clone();
                            Rc::new(move |p0: crate::syntax::Arg| {
                                let lx_p0 = lx_p0.clone();
                                let env_p1 = env_p1.clone();
                                entered(once_job(move || {
                                    let a_pt = p0;
                                    prism_rtl::Turn::More(Rc::new(crate::lower::expr::Argument { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), e_p2: a_pt.value.clone() }))
                                }))
                            }) as Rc<dyn Fn(crate::syntax::Arg) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
                        })), &body_pg),
                    },
                };
                let call_pi = crate::lower::model::Ex::XCall(callee_pf.clone(), passed_ph.clone());
                prism_rtl::Turn::Finished(Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XCall(Text::lit("place"), Array::from(vec![crate::lower::model::Ex::XRefMut(Rc::new(crate::lower::model::Ex::XVar(Text::lit("out")))), crate::lower::model::Ex::XRef(Rc::new(call_pi.clone())), crate::lower::model::Ex::XNone])))]))
            },
        }
    }
}

/// `Start TemplatePartDos, x`: what the function value is when passed to `@Run`.
pub fn start_template_part_dos(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, part_p2: crate::syntax::TemplatePart) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>> {
    Rc::new(TemplatePartDos { lx_p0, env_p1, part_p2 })
}

/// ```prism
/// TemplateArgs: unbounded fn Lx, Env, Text, [Arg], [Ex] -> [Ex]
/// ```
pub fn template_args(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, qk_p2: &Text, args_p3: &Array<crate::syntax::Arg>, body_p4: &Array<crate::lower::model::Ex>) -> Array<crate::lower::model::Ex> {
    let clauses_p5 = crate::lower::jobs::clauses_of(&lx_p0.g, qk_p2);
    let arity_p6 = len(&or(&index(&clauses_p5, &Nat::from(0u32)), &crate::lower::functions::dummy_clause()).params);
    run_to_end(each_job(crate::check::errors::range0(&arity_p6), {
        let body_p4 = body_p4.clone();
        let arity_p6 = arity_p6.clone();
        let clauses_p5 = clauses_p5.clone();
        let args_p3 = args_p3.clone();
        let lx_p0 = lx_p0.clone();
        let env_p1 = env_p1.clone();
        Rc::new(move |p0: Nat| {
            let body_p4 = body_p4.clone();
            let arity_p6 = arity_p6.clone();
            let clauses_p5 = clauses_p5.clone();
            let args_p3 = args_p3.clone();
            let lx_p0 = lx_p0.clone();
            let env_p1 = env_p1.clone();
            entered(once_job(move || {
                let j_p7 = p0;
                if (&len(&body_p4) > &Nat::from(0u32)) && (&(&j_p7 + &Nat::from(1u32)) == &arity_p6) {
                    prism_rtl::Turn::Finished(or(&index(&body_p4, &Nat::from(0u32)), &crate::lower::model::Ex::XUnit))
                } else {
                    match attr_at(&clauses_p5, &j_p7, &args_p3) {
                        Some(a_p8) => prism_rtl::Turn::More(Rc::new(crate::lower::expr::Argument { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), e_p2: a_p8.value.clone() })),
                        None => prism_rtl::Turn::Finished(crate::lower::expr::refusal(&Text::from(format!("a template call that fills no argument at place {}", &j_p7)))),
                    }
                }
            }))
        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
    }))
}

/// The step machine of `TemplateArgs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TemplateArgs: unbounded fn Lx, Env, Text, [Arg], [Ex] -> [Ex]
/// ```
pub struct TemplateArgs {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub qk_p2: Text,
    pub args_p3: Array<crate::syntax::Arg>,
    pub body_p4: Array<crate::lower::model::Ex>,
}

impl prism_rtl::Job<Array<crate::lower::model::Ex>> for TemplateArgs {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::lower::model::Ex>> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let qk_p2 = &self.qk_p2;
        let args_p3 = &self.args_p3;
        let body_p4 = &self.body_p4;
        let clauses_p5 = crate::lower::jobs::clauses_of(&lx_p0.g, qk_p2);
        let arity_p6 = len(&or(&index(&clauses_p5, &Nat::from(0u32)), &crate::lower::functions::dummy_clause()).params);
        each_job(crate::check::errors::range0(&arity_p6), {
            let body_p4 = body_p4.clone();
            let arity_p6 = arity_p6.clone();
            let clauses_p5 = clauses_p5.clone();
            let args_p3 = args_p3.clone();
            let lx_p0 = lx_p0.clone();
            let env_p1 = env_p1.clone();
            Rc::new(move |p0: Nat| {
                let body_p4 = body_p4.clone();
                let arity_p6 = arity_p6.clone();
                let clauses_p5 = clauses_p5.clone();
                let args_p3 = args_p3.clone();
                let lx_p0 = lx_p0.clone();
                let env_p1 = env_p1.clone();
                entered(once_job(move || {
                    let j_p7 = p0;
                    if (&len(&body_p4) > &Nat::from(0u32)) && (&(&j_p7 + &Nat::from(1u32)) == &arity_p6) {
                        prism_rtl::Turn::Finished(or(&index(&body_p4, &Nat::from(0u32)), &crate::lower::model::Ex::XUnit))
                    } else {
                        match attr_at(&clauses_p5, &j_p7, &args_p3) {
                            Some(a_p8) => prism_rtl::Turn::More(Rc::new(crate::lower::expr::Argument { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), e_p2: a_p8.value.clone() })),
                            None => prism_rtl::Turn::Finished(crate::lower::expr::refusal(&Text::from(format!("a template call that fills no argument at place {}", &j_p7)))),
                        }
                    }
                }))
            }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
        }).cycle()
    }
}

/// `Start TemplateArgs, x`: what the function value is when passed to `@Run`.
pub fn start_template_args(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, qk_p2: Text, args_p3: Array<crate::syntax::Arg>, body_p4: Array<crate::lower::model::Ex>) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Ex>>> {
    Rc::new(TemplateArgs { lx_p0, env_p1, qk_p2, args_p3, body_p4 })
}

/// ```prism
/// ?AttrAt: fn [FnClause], Nat, [Arg] -> ?Arg
/// ```
pub fn attr_at(clauses_p0: &Array<crate::syntax::decls::FnClause>, j_p1: &Nat, args_p2: &Array<crate::syntax::Arg>) -> Option<crate::syntax::Arg> {
    let names_p7 = fold(clauses_p0, &Array::new(), &(|acc_p3: &Array<Text>, c_p4: &crate::syntax::decls::FnClause| match index(&c_p4.params, j_p1) {
        Some(p_p5) => match place_name(&p_p5) {
            Some(n_p6) => crate::check::types::add_text(acc_p3, &n_p6),
            None => acc_p3.clone(),
        },
        None => acc_p3.clone(),
    }));
    fold(args_p2, &None, &(|found_o8: &Option<crate::syntax::Arg>, a_p9: &crate::syntax::Arg| match &a_p9.name {
        Some(n_pa) => if crate::check::types::has_text(&names_p7, &n_pa.name) {
            Some(a_p9.clone())
        } else {
            found_o8.clone()
        },
        None => found_o8.clone(),
    }))
}

/// ```prism
/// ?PlaceName: fn Pattern -> ?Text
/// ```
pub fn place_name(p_p0: &crate::syntax::Pattern_) -> Option<Text> {
    match &*p_p0.kind {
        crate::syntax::PatternKind::PName(n_p1) => Some(crate::check::env::dotted(&n_p1.path_)),
        crate::syntax::PatternKind::PGroup(q_p2) => place_name(&**q_p2),
        _ => None,
    }
}

/// ```prism
/// ShownText: fn Vl -> Ex
/// ```
pub fn shown_text(v_p0: &crate::lower::types::Vl) -> crate::lower::model::Ex {
    match crate::lower::types::value_ty(v_p0) {
        crate::lower::model::OutTy::OutText => crate::lower::types::ref_(v_p0),
        crate::lower::model::OutTy::OutChar => crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XFormat(Array::from(vec![crate::lower::types::ref_(v_p0)])))),
        _ => crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XCall(Text::lit("show_text"), Array::from(vec![crate::lower::types::ref_(v_p0)])))),
    }
}

/// ```prism
/// GivenValue: unbounded fn Lx, Env, Block, OutTy, Range -> Vl
/// ```
pub fn given_value(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, b_p2: &crate::syntax::Block, t_p3: &crate::lower::model::OutTy, span_p4: &crate::syntax::Range) -> crate::lower::types::Vl {
    let label_p5 = Text::from(format!("\'g{}", &span_p4.start));
    let is_try_p6 = match t_p3 {
        crate::lower::model::OutTy::OutRes(_) => true,
        _ => false,
    };
    let n_p7 = len(&b_p2.stmts);
    let (dos_po, env2_pp, last_oq) = run_to_end(fold_job(crate::check::errors::range0(&n_p7), (Array::new(), env_p1.clone(), None), {
        let b_p2 = b_p2.clone();
        let is_try_p6 = is_try_p6;
        let lx_p0 = lx_p0.clone();
        let label_p5 = label_p5.clone();
        let n_p7 = n_p7.clone();
        Rc::new(move |(p0, p1): ((Array<crate::lower::model::Do>, crate::lower::types::Env, Option<crate::lower::types::Vl>), Nat)| {
            let b_p2 = b_p2.clone();
            let is_try_p6 = is_try_p6;
            let lx_p0 = lx_p0.clone();
            let label_p5 = label_p5.clone();
            let n_p7 = n_p7.clone();
            entered(once_job(move || {
                let (acc_p9, en_pa, lv_ob) = p0;
                let i_pc = p1;
                {
                    let s_pd = or(&index(&b_p2.stmts, &i_pc), &crate::lower::expr::dummy_stmt_l());
                    let fail_pe = if is_try_p6 {
                        crate::lower::model::Ex::XCtor(Text::lit("Err"), Array::from(vec![crate::lower::model::Ex::XCall(Text::lit("Error::new"), Array::from(vec![crate::lower::model::Ex::XStr(Text::lit("Prelude.Unmet")), crate::lower::model::Ex::XStr(source_text(&lx_p0, &s_pd.span))]))]))
                    } else {
                        crate::lower::model::Ex::XNone
                    };
                    match &s_pd.kind {
                        crate::syntax::StmtKind::SBind(p_pf, x_pg, None) => {
                            let p_pf = p_pf.clone();
                            let x_pg = x_pg.clone();
                            call_then(crate::lower::expr::start_value_of(lx_p0.clone(), en_pa.clone(), x_pg.clone()), move |value_of_5940: crate::lower::types::Vl| {
                                let v_ph = value_of_5940;
                                call_then(crate::lower::patterns::start_rust_pat(lx_p0.clone(), p_pf.clone(), crate::lower::patterns::inner_ty(&crate::lower::type_at(&lx_p0, &x_pg.span)), crate::lower::types::Holding::Owned, Text::from(format!("g{}", &s_pd.span.start))), move |rust_pat_5983: crate::lower::patterns::PatOut| {
                                    let po_pi = rust_pat_5983;
                                    call_then(crate::lower::types::start_out_ty_of(lx_p0.clone(), crate::lower::patterns::inner_ty(&crate::lower::type_at(&lx_p0, &x_pg.span))), move |out_ty_of_6125: crate::lower::model::OutTy| prism_rtl::Turn::Finished((push(&acc_p9, &given_bind(&is_try_p6, &po_pi.pa, &crate::lower::types::own(&v_ph), &label_p5, &out_ty_of_6125)), crate::lower::expr::bind_all(&en_pa, &po_pi.binds), lv_ob.clone())))
                                })
                            })
                        },
                        crate::syntax::StmtKind::SRequire(c_pj) => {
                            let c_pj = c_pj.clone();
                            call_then(crate::lower::expr::start_value_of(lx_p0.clone(), en_pa.clone(), c_pj.clone()), move |value_of_6266: crate::lower::types::Vl| prism_rtl::Turn::Finished((push(&acc_p9, &crate::lower::model::Do::DoIf(crate::lower::model::Ex::XUnary(Text::lit("!"), Rc::new(crate::lower::types::as_bool(&value_of_6266))), Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XBreak(label_p5.clone(), Rc::new(fail_pe.clone())))]), Array::new())), en_pa.clone(), lv_ob.clone())))
                        },
                        crate::syntax::StmtKind::SForbid(c_pk) => {
                            let c_pk = c_pk.clone();
                            call_then(crate::lower::expr::start_value_of(lx_p0.clone(), en_pa.clone(), c_pk.clone()), move |value_of_6390: crate::lower::types::Vl| prism_rtl::Turn::Finished((push(&acc_p9, &crate::lower::model::Do::DoIf(crate::lower::types::as_bool(&value_of_6390), Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XBreak(label_p5.clone(), Rc::new(fail_pe.clone())))]), Array::new())), en_pa.clone(), lv_ob.clone())))
                        },
                        crate::syntax::StmtKind::SExpr(x_pl) => if &(&i_pc + &Nat::from(1u32)) == &n_p7 {
                            prism_rtl::Turn::Finished((acc_p9.clone(), en_pa.clone(), Some(crate::lower::expr::value_of(&lx_p0, &en_pa, x_pl))))
                        } else {
                            {
                                let x_pl = x_pl.clone();
                                call_then(crate::lower::expr::start_value_of(lx_p0.clone(), en_pa.clone(), x_pl.clone()), move |value_of_6598: crate::lower::types::Vl| prism_rtl::Turn::Finished((push(&acc_p9, &crate::lower::model::Do::DoExpr(crate::lower::types::own(&value_of_6598))), en_pa.clone(), lv_ob.clone())))
                            }
                        },
                        _ => call_then(crate::lower::expr::start_block_stmt(lx_p0.clone(), en_pa.clone(), s_pd.clone()), move |block_stmt_6690: (Array<crate::lower::model::Do>, crate::lower::types::Env)| {
                            let (more_pm, en2_pn) = block_stmt_6690;
                            prism_rtl::Turn::Finished((append(&acc_p9, &more_pm), en2_pn.clone(), lv_ob.clone()))
                        }),
                    }
                }
            }))
        }) as Rc<dyn Fn(((Array<crate::lower::model::Do>, crate::lower::types::Env, Option<crate::lower::types::Vl>), Nat)) -> Rc<dyn prism_rtl::Job<(Array<crate::lower::model::Do>, crate::lower::types::Env, Option<crate::lower::types::Vl>)>>>
    }));
    let last_p8 = or(&last_oq, &crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XNone, t_p3.clone()));
    crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XLabeled(label_p5.clone(), dos_po.clone(), Rc::new(crate::lower::types::own(&last_p8)), t_p3.clone()), t_p3.clone())
}

/// The step machine of `GivenValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// GivenValue: unbounded fn Lx, Env, Block, OutTy, Range -> Vl
/// ```
pub struct GivenValue {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub b_p2: crate::syntax::Block,
    pub t_p3: crate::lower::model::OutTy,
    pub span_p4: crate::syntax::Range,
}

impl prism_rtl::Job<crate::lower::types::Vl> for GivenValue {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::types::Vl> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let b_p2 = &self.b_p2;
        let t_p3 = &self.t_p3;
        let span_p4 = &self.span_p4;
        let label_p5 = Text::from(format!("\'g{}", &span_p4.start));
        let is_try_p6 = match t_p3 {
            crate::lower::model::OutTy::OutRes(_) => true,
            _ => false,
        };
        let n_p7 = len(&b_p2.stmts);
        let b_p2 = b_p2.clone();
        let env_p1 = env_p1.clone();
        let lx_p0 = lx_p0.clone();
        let span_p4 = span_p4.clone();
        let t_p3 = t_p3.clone();
        call_value(fold_job(crate::check::errors::range0(&n_p7), (Array::new(), env_p1.clone(), None), {
            let b_p2 = b_p2.clone();
            let is_try_p6 = is_try_p6;
            let lx_p0 = lx_p0.clone();
            let label_p5 = label_p5.clone();
            let n_p7 = n_p7.clone();
            Rc::new(move |(p0, p1): ((Array<crate::lower::model::Do>, crate::lower::types::Env, Option<crate::lower::types::Vl>), Nat)| {
                let b_p2 = b_p2.clone();
                let is_try_p6 = is_try_p6;
                let lx_p0 = lx_p0.clone();
                let label_p5 = label_p5.clone();
                let n_p7 = n_p7.clone();
                entered(once_job(move || {
                    let (acc_p9, en_pa, lv_ob) = p0;
                    let i_pc = p1;
                    {
                        let s_pd = or(&index(&b_p2.stmts, &i_pc), &crate::lower::expr::dummy_stmt_l());
                        let fail_pe = if is_try_p6 {
                            crate::lower::model::Ex::XCtor(Text::lit("Err"), Array::from(vec![crate::lower::model::Ex::XCall(Text::lit("Error::new"), Array::from(vec![crate::lower::model::Ex::XStr(Text::lit("Prelude.Unmet")), crate::lower::model::Ex::XStr(source_text(&lx_p0, &s_pd.span))]))]))
                        } else {
                            crate::lower::model::Ex::XNone
                        };
                        match &s_pd.kind {
                            crate::syntax::StmtKind::SBind(p_pf, x_pg, None) => {
                                let p_pf = p_pf.clone();
                                let x_pg = x_pg.clone();
                                call_then(crate::lower::expr::start_value_of(lx_p0.clone(), en_pa.clone(), x_pg.clone()), move |value_of_5940: crate::lower::types::Vl| {
                                    let v_ph = value_of_5940;
                                    call_then(crate::lower::patterns::start_rust_pat(lx_p0.clone(), p_pf.clone(), crate::lower::patterns::inner_ty(&crate::lower::type_at(&lx_p0, &x_pg.span)), crate::lower::types::Holding::Owned, Text::from(format!("g{}", &s_pd.span.start))), move |rust_pat_5983: crate::lower::patterns::PatOut| {
                                        let po_pi = rust_pat_5983;
                                        call_then(crate::lower::types::start_out_ty_of(lx_p0.clone(), crate::lower::patterns::inner_ty(&crate::lower::type_at(&lx_p0, &x_pg.span))), move |out_ty_of_6125: crate::lower::model::OutTy| prism_rtl::Turn::Finished((push(&acc_p9, &given_bind(&is_try_p6, &po_pi.pa, &crate::lower::types::own(&v_ph), &label_p5, &out_ty_of_6125)), crate::lower::expr::bind_all(&en_pa, &po_pi.binds), lv_ob.clone())))
                                    })
                                })
                            },
                            crate::syntax::StmtKind::SRequire(c_pj) => {
                                let c_pj = c_pj.clone();
                                call_then(crate::lower::expr::start_value_of(lx_p0.clone(), en_pa.clone(), c_pj.clone()), move |value_of_6266: crate::lower::types::Vl| prism_rtl::Turn::Finished((push(&acc_p9, &crate::lower::model::Do::DoIf(crate::lower::model::Ex::XUnary(Text::lit("!"), Rc::new(crate::lower::types::as_bool(&value_of_6266))), Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XBreak(label_p5.clone(), Rc::new(fail_pe.clone())))]), Array::new())), en_pa.clone(), lv_ob.clone())))
                            },
                            crate::syntax::StmtKind::SForbid(c_pk) => {
                                let c_pk = c_pk.clone();
                                call_then(crate::lower::expr::start_value_of(lx_p0.clone(), en_pa.clone(), c_pk.clone()), move |value_of_6390: crate::lower::types::Vl| prism_rtl::Turn::Finished((push(&acc_p9, &crate::lower::model::Do::DoIf(crate::lower::types::as_bool(&value_of_6390), Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XBreak(label_p5.clone(), Rc::new(fail_pe.clone())))]), Array::new())), en_pa.clone(), lv_ob.clone())))
                            },
                            crate::syntax::StmtKind::SExpr(x_pl) => if &(&i_pc + &Nat::from(1u32)) == &n_p7 {
                                prism_rtl::Turn::Finished((acc_p9.clone(), en_pa.clone(), Some(crate::lower::expr::value_of(&lx_p0, &en_pa, x_pl))))
                            } else {
                                {
                                    let x_pl = x_pl.clone();
                                    call_then(crate::lower::expr::start_value_of(lx_p0.clone(), en_pa.clone(), x_pl.clone()), move |value_of_6598: crate::lower::types::Vl| prism_rtl::Turn::Finished((push(&acc_p9, &crate::lower::model::Do::DoExpr(crate::lower::types::own(&value_of_6598))), en_pa.clone(), lv_ob.clone())))
                                }
                            },
                            _ => call_then(crate::lower::expr::start_block_stmt(lx_p0.clone(), en_pa.clone(), s_pd.clone()), move |block_stmt_6690: (Array<crate::lower::model::Do>, crate::lower::types::Env)| {
                                let (more_pm, en2_pn) = block_stmt_6690;
                                prism_rtl::Turn::Finished((append(&acc_p9, &more_pm), en2_pn.clone(), lv_ob.clone()))
                            }),
                        }
                    }
                }))
            }) as Rc<dyn Fn(((Array<crate::lower::model::Do>, crate::lower::types::Env, Option<crate::lower::types::Vl>), Nat)) -> Rc<dyn prism_rtl::Job<(Array<crate::lower::model::Do>, crate::lower::types::Env, Option<crate::lower::types::Vl>)>>>
        }), move |fold_5624: (Array<crate::lower::model::Do>, crate::lower::types::Env, Option<crate::lower::types::Vl>)| {
            let (dos_po, env2_pp, last_oq) = fold_5624;
            let last_p8 = or(&last_oq, &crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XNone, t_p3.clone()));
            prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XLabeled(label_p5.clone(), dos_po.clone(), Rc::new(crate::lower::types::own(&last_p8)), t_p3.clone()), t_p3.clone()))
        })
    }
}

/// `Start GivenValue, x`: what the function value is when passed to `@Run`.
pub fn start_given_value(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, b_p2: crate::syntax::Block, t_p3: crate::lower::model::OutTy, span_p4: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<crate::lower::types::Vl>> {
    Rc::new(GivenValue { lx_p0, env_p1, b_p2, t_p3, span_p4 })
}

/// ```prism
/// GivenBind: fn Bool, Pa, Ex, Text, OutTy -> Do
/// ```
pub fn given_bind(is_try_p0: &bool, pa_p1: &crate::lower::model::Pa, x_p2: &crate::lower::model::Ex, label_p3: &Text, t_p4: &crate::lower::model::OutTy) -> crate::lower::model::Do {
    if *is_try_p0 {
        crate::lower::model::Do::DoLet(pa_p1.clone(), crate::lower::model::Ex::XMatch(Rc::new(x_p2.clone()), Array::from(vec![crate::lower::model::XArm { pat: crate::lower::model::Pa::PaCtor(Text::lit("Ok"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("v"))])), conds: Array::new(), body: crate::lower::model::Ex::XVar(Text::lit("v")) }, crate::lower::model::XArm { pat: crate::lower::model::Pa::PaCtor(Text::lit("Err"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("e"))])), conds: Array::new(), body: crate::lower::model::Ex::XBreak(label_p3.clone(), Rc::new(crate::lower::model::Ex::XCtor(Text::lit("Err"), Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("e"))])))) }]), false, t_p4.clone()))
    } else {
        crate::lower::model::Do::DoLetElse(crate::lower::model::Pa::PaCtor(Text::lit("Some"), Array::from(vec![pa_p1.clone()])), x_p2.clone(), crate::lower::model::Ex::XBreak(label_p3.clone(), Rc::new(crate::lower::model::Ex::XNone)))
    }
}

/// ```prism
/// SourceText: fn Lx, Range -> Text
/// ```
pub fn source_text(lx_p0: &crate::lower::Lx, r_p1: &crate::syntax::Range) -> Text {
    match index(&lx_p0.g.srcs, &lx_p0.file) {
        Some(src_p2) => crate::check::errors::span_text(&src_p2, r_p1),
        None => Text::lit(""),
    }
}

/// ```prism
/// UpdateValue: unbounded fn Lx, Env, Expr, Block, OutTy, Range -> Vl
/// ```
pub fn update_value(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, target_p2: &crate::syntax::Expr, b_p3: &crate::syntax::Block, t_p4: &crate::lower::model::OutTy, span_p5: &crate::syntax::Range) -> crate::lower::types::Vl {
    let tv_p6 = crate::lower::expr::value_of(lx_p0, env_p1, target_p2);
    let env1_p7 = crate::lower::types::bind(env_p1, &Text::lit("&_"), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(Text::lit("this")), crate::lower::types::Holding::Owned, t_p4.clone()));
    let (dos_p8, _) = upd_stmts(lx_p0, &env1_p7, &b_p3.stmts);
    crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XBlock(append(&Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaMut(Text::lit("this"))), t_p4.clone()), crate::lower::types::own(&tv_p6))]), &dos_p8), Rc::new(crate::lower::model::Ex::XVar(Text::lit("this")))), t_p4.clone())
}

/// The step machine of `UpdateValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UpdateValue: unbounded fn Lx, Env, Expr, Block, OutTy, Range -> Vl
/// ```
pub struct UpdateValue {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub target_p2: crate::syntax::Expr,
    pub b_p3: crate::syntax::Block,
    pub t_p4: crate::lower::model::OutTy,
    pub span_p5: crate::syntax::Range,
}

impl prism_rtl::Job<crate::lower::types::Vl> for UpdateValue {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::types::Vl> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let target_p2 = &self.target_p2;
        let b_p3 = &self.b_p3;
        let t_p4 = &self.t_p4;
        let span_p5 = &self.span_p5;
        let b_p3 = b_p3.clone();
        let env_p1 = env_p1.clone();
        let lx_p0 = lx_p0.clone();
        let t_p4 = t_p4.clone();
        let target_p2 = target_p2.clone();
        call_then(crate::lower::expr::start_value_of(lx_p0.clone(), env_p1.clone(), target_p2.clone()), move |value_of_7889: crate::lower::types::Vl| {
            let tv_p6 = value_of_7889;
            let env1_p7 = crate::lower::types::bind(&env_p1, &Text::lit("&_"), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(Text::lit("this")), crate::lower::types::Holding::Owned, t_p4.clone()));
            call_then(start_upd_stmts(lx_p0.clone(), env1_p7.clone(), b_p3.stmts.clone()), move |upd_stmts_8004: (Array<crate::lower::model::Do>, crate::lower::types::Env)| {
                let (dos_p8, _) = upd_stmts_8004;
                prism_rtl::Turn::Finished(crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XBlock(append(&Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaMut(Text::lit("this"))), t_p4.clone()), crate::lower::types::own(&tv_p6))]), &dos_p8), Rc::new(crate::lower::model::Ex::XVar(Text::lit("this")))), t_p4.clone()))
            })
        })
    }
}

/// `Start UpdateValue, x`: what the function value is when passed to `@Run`.
pub fn start_update_value(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, target_p2: crate::syntax::Expr, b_p3: crate::syntax::Block, t_p4: crate::lower::model::OutTy, span_p5: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<crate::lower::types::Vl>> {
    Rc::new(UpdateValue { lx_p0, env_p1, target_p2, b_p3, t_p4, span_p5 })
}

/// ```prism
/// UpdStmts: unbounded fn Lx, Env, [Stmt] -> (([Do], Env))
/// ```
pub fn upd_stmts(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, stmts_p2: &Array<crate::syntax::Stmt>) -> (Array<crate::lower::model::Do>, crate::lower::types::Env) {
    run_to_end(fold_job(stmts_p2.clone(), (Array::new(), env_p1.clone()), {
        let lx_p0 = lx_p0.clone();
        Rc::new(move |(p0, p1): ((Array<crate::lower::model::Do>, crate::lower::types::Env), crate::syntax::Stmt)| {
            let lx_p0 = lx_p0.clone();
            entered(once_job(move || {
                let (acc_p3, en_p4) = p0;
                let s_p5 = p1;
                call_then(start_upd_stmt(lx_p0.clone(), en_p4.clone(), s_p5.clone()), move |upd_stmt_8289: (Array<crate::lower::model::Do>, crate::lower::types::Env)| {
                    let (more_p6, en2_p7) = upd_stmt_8289;
                    prism_rtl::Turn::Finished((append(&acc_p3, &more_p6), en2_p7.clone()))
                })
            }))
        }) as Rc<dyn Fn(((Array<crate::lower::model::Do>, crate::lower::types::Env), crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<(Array<crate::lower::model::Do>, crate::lower::types::Env)>>>
    }))
}

/// The step machine of `UpdStmts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UpdStmts: unbounded fn Lx, Env, [Stmt] -> (([Do], Env))
/// ```
pub struct UpdStmts {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub stmts_p2: Array<crate::syntax::Stmt>,
}

impl prism_rtl::Job<(Array<crate::lower::model::Do>, crate::lower::types::Env)> for UpdStmts {
    fn cycle(&self) -> prism_rtl::Turn<(Array<crate::lower::model::Do>, crate::lower::types::Env)> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let stmts_p2 = &self.stmts_p2;
        fold_job(stmts_p2.clone(), (Array::new(), env_p1.clone()), {
            let lx_p0 = lx_p0.clone();
            Rc::new(move |(p0, p1): ((Array<crate::lower::model::Do>, crate::lower::types::Env), crate::syntax::Stmt)| {
                let lx_p0 = lx_p0.clone();
                entered(once_job(move || {
                    let (acc_p3, en_p4) = p0;
                    let s_p5 = p1;
                    call_then(start_upd_stmt(lx_p0.clone(), en_p4.clone(), s_p5.clone()), move |upd_stmt_8289: (Array<crate::lower::model::Do>, crate::lower::types::Env)| {
                        let (more_p6, en2_p7) = upd_stmt_8289;
                        prism_rtl::Turn::Finished((append(&acc_p3, &more_p6), en2_p7.clone()))
                    })
                }))
            }) as Rc<dyn Fn(((Array<crate::lower::model::Do>, crate::lower::types::Env), crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<(Array<crate::lower::model::Do>, crate::lower::types::Env)>>>
        }).cycle()
    }
}

/// `Start UpdStmts, x`: what the function value is when passed to `@Run`.
pub fn start_upd_stmts(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, stmts_p2: Array<crate::syntax::Stmt>) -> Rc<dyn prism_rtl::Job<(Array<crate::lower::model::Do>, crate::lower::types::Env)>> {
    Rc::new(UpdStmts { lx_p0, env_p1, stmts_p2 })
}

/// ```prism
/// UpdStmt: unbounded fn Lx, Env, Stmt -> (([Do], Env))
/// ```
pub fn upd_stmt(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, s_p2: &crate::syntax::Stmt) -> (Array<crate::lower::model::Do>, crate::lower::types::Env) {
    match &s_p2.kind {
        crate::syntax::StmtKind::SSet(target_p3, value_p4) => {
            let v_p5 = crate::lower::types::own(&crate::lower::expr::value_of(lx_p0, env_p1, value_p4));
            (Array::from(vec![assign(lx_p0, env_p1, target_p3, &v_p5)]), env_p1.clone())
        },
        crate::syntax::StmtKind::SAccum(target_p6, op_p7, value_p8) => {
            let cur_p9 = place_of(lx_p0, env_p1, target_p6);
            let tt_pa = crate::lower::types::out_ty_of(lx_p0, &crate::lower::types::peel(&crate::lower::type_at(lx_p0, &target_p6.span)));
            let rv_pb = crate::lower::expr::value_of(lx_p0, env_p1, value_p8);
            let bin_pc = crate::syntax::lexer::chars::head(op_p7);
            let next_pd = crate::lower::expr::op_value(lx_p0, &bin_pc, &crate::lower::types::Vl::VlPlace(cur_p9.clone(), crate::lower::types::Holding::Owned, tt_pa.clone()), &rv_pb, &s_p2.span, &tt_pa);
            (Array::from(vec![assign(lx_p0, env_p1, target_p6, &crate::lower::types::own(&next_pd))]), env_p1.clone())
        },
        crate::syntax::StmtKind::SLet(p_pe, _, x_pf) => {
            let v_pg = crate::lower::types::own(&crate::lower::expr::value_of(lx_p0, env_p1, x_pf));
            match &*p_pe.kind {
                crate::syntax::PatternKind::PName(n_ph) => if crate::syntax::lexer::chars::has_prefix(&n_ph.sigils, &Text::lit("&")) {
                    {
                        let rs_pi = crate::lower::local_name_at(lx_p0, &crate::check::env::sname_key(n_ph), &n_ph.span);
                        let bt_pj = crate::lower::types::out_ty_of(lx_p0, &crate::lower::types::peel(&crate::lower::binder_ty(lx_p0, &n_ph.span)));
                        let pa_pk = if crate::lower::expr::is_known_ty(&bt_pj) {
                            crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaMut(Text::from(format!("{}", &rs_pi)))), bt_pj.clone())
                        } else {
                            crate::lower::model::Pa::PaMut(Text::from(format!("{}", &rs_pi)))
                        };
                        (Array::from(vec![crate::lower::model::Do::DoLet(pa_pk.clone(), v_pg.clone())]), crate::lower::types::bind(env_p1, &crate::check::env::sname_key(n_ph), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(rs_pi.clone()), crate::lower::types::Holding::Owned, bt_pj.clone())))
                    }
                } else {
                    crate::lower::expr::block_stmt(lx_p0, env_p1, s_p2)
                },
                _ => crate::lower::expr::block_stmt(lx_p0, env_p1, s_p2),
            }
        },
        crate::syntax::StmtKind::SWhile(c_pl, body_pm) => {
            let (inner_pn, _) = upd_stmts(lx_p0, env_p1, &body_pm.stmts);
            match c_pl {
                crate::syntax::Cond::CondExpr(x_po) => (Array::from(vec![crate::lower::model::Do::DoWhile(crate::lower::types::as_bool(&crate::lower::expr::value_of(lx_p0, env_p1, &**x_po)), inner_pn.clone())]), env_p1.clone()),
                crate::syntax::Cond::CondBind(p_pp, x_pq, g_or) => {
                    let po_ps = crate::lower::patterns::rust_pat(lx_p0, p_pp, &crate::lower::type_at(lx_p0, &x_pq.span), &crate::lower::types::Holding::Owned, &Text::from(format!("w{}", &s_p2.span.start)));
                    let env_b_pt = crate::lower::expr::bind_all(env_p1, &po_ps.binds);
                    let (inner2_p13, _) = upd_stmts(lx_p0, &env_b_pt, &body_pm.stmts);
                    let conds_pu = append(&po_ps.conds, &guard_conds(lx_p0, &env_b_pt, &**g_or));
                    let tests_pv = fold(&conds_pu, &Array::new(), &(|acc_p14: &Array<crate::lower::model::Ex>, c_p15: &crate::lower::model::Cc| match c_p15 {
                        crate::lower::model::Cc::CcIf(t_p16) => push(acc_p14, t_p16),
                        _ => acc_p14.clone(),
                    }));
                    let lets_p10 = fold(&conds_pu, &false, &(|f_p17: &bool, c_p18: &crate::lower::model::Cc| *f_p17 || crate::lower::expr::is_let_cond(c_p18)));
                    let stop_p11 = if &len(&tests_pv) == &Nat::from(0u32) {
                        Array::new()
                    } else {
                        Array::from(vec![crate::lower::model::Do::DoIf(crate::lower::model::Ex::XUnary(Text::lit("!"), Rc::new(all_of(&tests_pv))), Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XVar(Text::lit("break")))]), Array::new())])
                    };
                    let body2_p12 = if lets_p10 {
                        Array::from(vec![crate::lower::expr::refusal_do(&Text::lit("a `while` whose pattern matches through an `Rc`"))])
                    } else {
                        append(&stop_p11, &inner2_p13)
                    };
                    (Array::from(vec![crate::lower::model::Do::DoWhileLet(po_ps.pa.clone(), crate::lower::types::own(&crate::lower::expr::value_of(lx_p0, env_p1, &**x_pq)), body2_p12.clone())]), env_p1.clone())
                },
            }
        },
        crate::syntax::StmtKind::SExpr(x_p19) => match &*x_p19.kind {
            crate::syntax::ExprKind::EIf(c_p1a, then_b_p1b, else_b_o1c) => (Array::from(vec![upd_if(lx_p0, env_p1, &**c_p1a, then_b_p1b, else_b_o1c)]), env_p1.clone()),
            crate::syntax::ExprKind::EMatch(scrut_p1d, arms_p1e) => (Array::from(vec![upd_match(lx_p0, env_p1, &**scrut_p1d, arms_p1e)]), env_p1.clone()),
            crate::syntax::ExprKind::EFor(binders_o1f, source_p1g, body_p1h) => (Array::from(vec![upd_for(lx_p0, env_p1, binders_o1f, &**source_p1g, body_p1h, &x_p19.span)]), env_p1.clone()),
            _ => (Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::types::own(&crate::lower::expr::value_of(lx_p0, env_p1, x_p19)))]), env_p1.clone()),
        },
        _ => crate::lower::expr::block_stmt(lx_p0, env_p1, s_p2),
    }
}

/// The step machine of `UpdStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UpdStmt: unbounded fn Lx, Env, Stmt -> (([Do], Env))
/// ```
pub struct UpdStmt {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub s_p2: crate::syntax::Stmt,
}

impl prism_rtl::Job<(Array<crate::lower::model::Do>, crate::lower::types::Env)> for UpdStmt {
    fn cycle(&self) -> prism_rtl::Turn<(Array<crate::lower::model::Do>, crate::lower::types::Env)> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let s_p2 = &self.s_p2;
        match &s_p2.kind {
            crate::syntax::StmtKind::SSet(target_p3, value_p4) => {
                let env_p1 = env_p1.clone();
                let lx_p0 = lx_p0.clone();
                let target_p3 = target_p3.clone();
                let value_p4 = value_p4.clone();
                call_then(crate::lower::expr::start_value_of(lx_p0.clone(), env_p1.clone(), value_p4.clone()), move |value_of_8476: crate::lower::types::Vl| {
                    let v_p5 = crate::lower::types::own(&value_of_8476);
                    call_then(start_assign(lx_p0.clone(), env_p1.clone(), target_p3.clone(), v_p5.clone()), move |assign_8513: crate::lower::model::Do| prism_rtl::Turn::Finished((Array::from(vec![assign_8513]), env_p1.clone())))
                })
            },
            crate::syntax::StmtKind::SAccum(target_p6, op_p7, value_p8) => {
                let env_p1 = env_p1.clone();
                let lx_p0 = lx_p0.clone();
                let op_p7 = op_p7.clone();
                let s_p2 = s_p2.clone();
                let target_p6 = target_p6.clone();
                let value_p8 = value_p8.clone();
                call_then(start_place_of(lx_p0.clone(), env_p1.clone(), target_p6.clone()), move |place_of_8597: crate::lower::model::Ex| {
                    let cur_p9 = place_of_8597;
                    call_then(crate::lower::types::start_out_ty_of(lx_p0.clone(), crate::lower::types::peel(&crate::lower::type_at(&lx_p0, &target_p6.span))), move |out_ty_of_8638: crate::lower::model::OutTy| {
                        let tt_pa = out_ty_of_8638;
                        call_then(crate::lower::expr::start_value_of(lx_p0.clone(), env_p1.clone(), value_p8.clone()), move |value_of_8699: crate::lower::types::Vl| {
                            let rv_pb = value_of_8699;
                            let bin_pc = crate::syntax::lexer::chars::head(&op_p7);
                            let next_pd = crate::lower::expr::op_value(&lx_p0, &bin_pc, &crate::lower::types::Vl::VlPlace(cur_p9.clone(), crate::lower::types::Holding::Owned, tt_pa.clone()), &rv_pb, &s_p2.span, &tt_pa);
                            call_then(start_assign(lx_p0.clone(), env_p1.clone(), target_p6.clone(), crate::lower::types::own(&next_pd)), move |assign_8838: crate::lower::model::Do| prism_rtl::Turn::Finished((Array::from(vec![assign_8838]), env_p1.clone())))
                        })
                    })
                })
            },
            crate::syntax::StmtKind::SLet(p_pe, _, x_pf) => {
                let env_p1 = env_p1.clone();
                let lx_p0 = lx_p0.clone();
                let p_pe = p_pe.clone();
                let s_p2 = s_p2.clone();
                let x_pf = x_pf.clone();
                call_then(crate::lower::expr::start_value_of(lx_p0.clone(), env_p1.clone(), x_pf.clone()), move |value_of_8927: crate::lower::types::Vl| {
                    let v_pg = crate::lower::types::own(&value_of_8927);
                    match &*p_pe.kind {
                        crate::syntax::PatternKind::PName(n_ph) => if crate::syntax::lexer::chars::has_prefix(&n_ph.sigils, &Text::lit("&")) {
                            {
                                let n_ph = n_ph.clone();
                                call_then(crate::lower::start_local_name_at(lx_p0.clone(), crate::check::env::sname_key(&n_ph), n_ph.span.clone()), move |local_name_at_9065: Text| {
                                    let rs_pi = local_name_at_9065;
                                    call_then(crate::lower::types::start_out_ty_of(lx_p0.clone(), crate::lower::types::peel(&crate::lower::binder_ty(&lx_p0, &n_ph.span))), move |out_ty_of_9131: crate::lower::model::OutTy| {
                                        let bt_pj = out_ty_of_9131;
                                        call_then(crate::lower::expr::start_is_known_ty(bt_pj.clone()), move |is_known_ty_9204: bool| {
                                            let pa_pk = if is_known_ty_9204 {
                                                crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaMut(Text::from(format!("{}", &rs_pi)))), bt_pj.clone())
                                            } else {
                                                crate::lower::model::Pa::PaMut(Text::from(format!("{}", &rs_pi)))
                                            };
                                            prism_rtl::Turn::Finished((Array::from(vec![crate::lower::model::Do::DoLet(pa_pk.clone(), v_pg.clone())]), crate::lower::types::bind(&env_p1, &crate::check::env::sname_key(&n_ph), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(rs_pi.clone()), crate::lower::types::Holding::Owned, bt_pj.clone()))))
                                        })
                                    })
                                })
                            }
                        } else {
                            prism_rtl::Turn::More(Rc::new(crate::lower::expr::BlockStmt { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), s_p2: s_p2.clone() }))
                        },
                        _ => prism_rtl::Turn::More(Rc::new(crate::lower::expr::BlockStmt { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), s_p2: s_p2.clone() })),
                    }
                })
            },
            crate::syntax::StmtKind::SWhile(c_pl, body_pm) => {
                let body_pm = body_pm.clone();
                let c_pl = c_pl.clone();
                let env_p1 = env_p1.clone();
                let lx_p0 = lx_p0.clone();
                let s_p2 = s_p2.clone();
                call_then(start_upd_stmts(lx_p0.clone(), env_p1.clone(), body_pm.stmts.clone()), move |upd_stmts_9503: (Array<crate::lower::model::Do>, crate::lower::types::Env)| {
                    let (inner_pn, _) = upd_stmts_9503;
                    match &c_pl {
                        crate::syntax::Cond::CondExpr(x_po) => {
                            let x_po = (**x_po).clone();
                            call_then(crate::lower::expr::start_value_of(lx_p0.clone(), env_p1.clone(), x_po.clone()), move |value_of_9595: crate::lower::types::Vl| prism_rtl::Turn::Finished((Array::from(vec![crate::lower::model::Do::DoWhile(crate::lower::types::as_bool(&value_of_9595), inner_pn.clone())]), env_p1.clone())))
                        },
                        crate::syntax::Cond::CondBind(p_pp, x_pq, g_or) => {
                            let g_or = (**g_or).clone();
                            let p_pp = p_pp.clone();
                            let x_pq = (**x_pq).clone();
                            call_then(crate::lower::patterns::start_rust_pat(lx_p0.clone(), p_pp.clone(), crate::lower::type_at(&lx_p0, &x_pq.span), crate::lower::types::Holding::Owned, Text::from(format!("w{}", &s_p2.span.start))), move |rust_pat_9689: crate::lower::patterns::PatOut| {
                                let po_ps = rust_pat_9689;
                                let env_b_pt = crate::lower::expr::bind_all(&env_p1, &po_ps.binds);
                                call_then(start_upd_stmts(lx_p0.clone(), env_b_pt.clone(), body_pm.stmts.clone()), move |upd_stmts_9840: (Array<crate::lower::model::Do>, crate::lower::types::Env)| {
                                    let (inner2_p13, _) = upd_stmts_9840;
                                    call_then(start_guard_conds(lx_p0.clone(), env_b_pt.clone(), g_or.clone()), move |guard_conds_10098: Array<crate::lower::model::Cc>| {
                                        let conds_pu = append(&po_ps.conds, &guard_conds_10098);
                                        let tests_pv = fold(&conds_pu, &Array::new(), &(|acc_p14: &Array<crate::lower::model::Ex>, c_p15: &crate::lower::model::Cc| match c_p15 {
                                            crate::lower::model::Cc::CcIf(t_p16) => push(acc_p14, t_p16),
                                            _ => acc_p14.clone(),
                                        }));
                                        let lets_p10 = fold(&conds_pu, &false, &(|f_p17: &bool, c_p18: &crate::lower::model::Cc| *f_p17 || crate::lower::expr::is_let_cond(c_p18)));
                                        let stop_p11 = if &len(&tests_pv) == &Nat::from(0u32) {
                                            Array::new()
                                        } else {
                                            Array::from(vec![crate::lower::model::Do::DoIf(crate::lower::model::Ex::XUnary(Text::lit("!"), Rc::new(all_of(&tests_pv))), Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XVar(Text::lit("break")))]), Array::new())])
                                        };
                                        let body2_p12 = if lets_p10 {
                                            Array::from(vec![crate::lower::expr::refusal_do(&Text::lit("a `while` whose pattern matches through an `Rc`"))])
                                        } else {
                                            append(&stop_p11, &inner2_p13)
                                        };
                                        call_then(crate::lower::expr::start_value_of(lx_p0.clone(), env_p1.clone(), x_pq.clone()), move |value_of_10637: crate::lower::types::Vl| prism_rtl::Turn::Finished((Array::from(vec![crate::lower::model::Do::DoWhileLet(po_ps.pa.clone(), crate::lower::types::own(&value_of_10637), body2_p12.clone())]), env_p1.clone())))
                                    })
                                })
                            })
                        },
                    }
                })
            },
            crate::syntax::StmtKind::SExpr(x_p19) => match &*x_p19.kind {
                crate::syntax::ExprKind::EIf(c_p1a, then_b_p1b, else_b_o1c) => {
                    let else_b_o1c = else_b_o1c.clone();
                    let c_p1a = (**c_p1a).clone();
                    let env_p1 = env_p1.clone();
                    let lx_p0 = lx_p0.clone();
                    let then_b_p1b = then_b_p1b.clone();
                    call_then(start_upd_if(lx_p0.clone(), env_p1.clone(), c_p1a.clone(), then_b_p1b.clone(), else_b_o1c.clone()), move |upd_if_10737: crate::lower::model::Do| prism_rtl::Turn::Finished((Array::from(vec![upd_if_10737]), env_p1.clone())))
                },
                crate::syntax::ExprKind::EMatch(scrut_p1d, arms_p1e) => {
                    let arms_p1e = arms_p1e.clone();
                    let env_p1 = env_p1.clone();
                    let lx_p0 = lx_p0.clone();
                    let scrut_p1d = (**scrut_p1d).clone();
                    call_then(start_upd_match(lx_p0.clone(), env_p1.clone(), scrut_p1d.clone(), arms_p1e.clone()), move |upd_match_10812: crate::lower::model::Do| prism_rtl::Turn::Finished((Array::from(vec![upd_match_10812]), env_p1.clone())))
                },
                crate::syntax::ExprKind::EFor(binders_o1f, source_p1g, body_p1h) => {
                    let binders_o1f = binders_o1f.clone();
                    let body_p1h = body_p1h.clone();
                    let env_p1 = env_p1.clone();
                    let lx_p0 = lx_p0.clone();
                    let source_p1g = (**source_p1g).clone();
                    let x_p19 = x_p19.clone();
                    call_then(start_upd_for(lx_p0.clone(), env_p1.clone(), binders_o1f.clone(), source_p1g.clone(), body_p1h.clone(), x_p19.span.clone()), move |upd_for_10894: crate::lower::model::Do| prism_rtl::Turn::Finished((Array::from(vec![upd_for_10894]), env_p1.clone())))
                },
                _ => {
                    let env_p1 = env_p1.clone();
                    let lx_p0 = lx_p0.clone();
                    let x_p19 = x_p19.clone();
                    call_then(crate::lower::expr::start_value_of(lx_p0.clone(), env_p1.clone(), x_p19.clone()), move |value_of_10987: crate::lower::types::Vl| prism_rtl::Turn::Finished((Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::types::own(&value_of_10987))]), env_p1.clone())))
                },
            },
            _ => prism_rtl::Turn::More(Rc::new(crate::lower::expr::BlockStmt { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), s_p2: s_p2.clone() })),
        }
    }
}

/// `Start UpdStmt, x`: what the function value is when passed to `@Run`.
pub fn start_upd_stmt(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, s_p2: crate::syntax::Stmt) -> Rc<dyn prism_rtl::Job<(Array<crate::lower::model::Do>, crate::lower::types::Env)>> {
    Rc::new(UpdStmt { lx_p0, env_p1, s_p2 })
}

/// ```prism
/// UpdFor: unbounded fn Lx, Env, ?ForBinders, Expr, Block, Range -> Do
/// ```
pub fn upd_for(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, binders_o2: &Option<crate::syntax::ForBinders>, source_p3: &crate::syntax::Expr, body_p4: &crate::syntax::Block, span_p5: &crate::syntax::Range) -> crate::lower::model::Do {
    let sty_p6 = crate::lower::types::peel(&crate::lower::type_at(lx_p0, &source_p3.span));
    match ref_binder(binders_o2) {
        Some(n_p7) => if is_ref_path(source_p3) {
            upd_for_refs(lx_p0, env_p1, &n_p7, source_p3, body_p4, span_p5, &sty_p6)
        } else {
            upd_for_values(lx_p0, env_p1, binders_o2, source_p3, body_p4, span_p5, &sty_p6)
        },
        None => upd_for_values(lx_p0, env_p1, binders_o2, source_p3, body_p4, span_p5, &sty_p6),
    }
}

/// The step machine of `UpdFor`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UpdFor: unbounded fn Lx, Env, ?ForBinders, Expr, Block, Range -> Do
/// ```
pub struct UpdFor {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub binders_o2: Option<crate::syntax::ForBinders>,
    pub source_p3: crate::syntax::Expr,
    pub body_p4: crate::syntax::Block,
    pub span_p5: crate::syntax::Range,
}

impl prism_rtl::Job<crate::lower::model::Do> for UpdFor {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::Do> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let binders_o2 = &self.binders_o2;
        let source_p3 = &self.source_p3;
        let body_p4 = &self.body_p4;
        let span_p5 = &self.span_p5;
        let sty_p6 = crate::lower::types::peel(&crate::lower::type_at(lx_p0, &source_p3.span));
        match ref_binder(binders_o2) {
            Some(n_p7) => if is_ref_path(source_p3) {
                prism_rtl::Turn::More(Rc::new(UpdForRefs { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), n_p2: n_p7.clone(), source_p3: source_p3.clone(), body_p4: body_p4.clone(), span_p5: span_p5.clone(), sty_p6: sty_p6.clone() }))
            } else {
                prism_rtl::Turn::More(Rc::new(UpdForValues { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), binders_o2: binders_o2.clone(), source_p3: source_p3.clone(), body_p4: body_p4.clone(), span_p5: span_p5.clone(), sty_p6: sty_p6.clone() }))
            },
            None => prism_rtl::Turn::More(Rc::new(UpdForValues { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), binders_o2: binders_o2.clone(), source_p3: source_p3.clone(), body_p4: body_p4.clone(), span_p5: span_p5.clone(), sty_p6: sty_p6.clone() })),
        }
    }
}

/// `Start UpdFor, x`: what the function value is when passed to `@Run`.
pub fn start_upd_for(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, binders_o2: Option<crate::syntax::ForBinders>, source_p3: crate::syntax::Expr, body_p4: crate::syntax::Block, span_p5: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<crate::lower::model::Do>> {
    Rc::new(UpdFor { lx_p0, env_p1, binders_o2, source_p3, body_p4, span_p5 })
}

/// ```prism
/// UpdForRefs: unbounded fn Lx, Env, SName, Expr, Block, Range, Ty -> Do
/// ```
pub fn upd_for_refs(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, n_p2: &crate::syntax::SName, source_p3: &crate::syntax::Expr, body_p4: &crate::syntax::Block, span_p5: &crate::syntax::Range, sty_p6: &crate::check::types::Ty) -> crate::lower::model::Do {
    match sty_p6 {
        crate::check::types::Ty::TyArray(v_p7) => {
            let key_name_p8 = Text::from(format!("k{}", &span_p5.start));
            let ref_name_p9 = Text::from(format!("r{}", &span_p5.start));
            let env1_pa = crate::lower::types::bind(&crate::lower::types::bind(&crate::lower::types::bind(env_p1, &Text::lit("key"), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(key_name_p8.clone()), crate::lower::types::Holding::Owned, crate::lower::model::OutTy::OutNat)), &Text::lit("ix"), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(key_name_p8.clone()), crate::lower::types::Holding::Owned, crate::lower::model::OutTy::OutNat)), &crate::check::env::sname_key(n_p2), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XTarget(Rc::new(crate::lower::model::Ex::XVar(ref_name_p9.clone()))), crate::lower::types::Holding::Owned, crate::lower::types::out_ty_of(lx_p0, &**v_p7)));
            let (dos_pc, _) = upd_stmts(lx_p0, &env1_pa, &body_p4.stmts);
            let head_pb = crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(key_name_p8.clone()), crate::lower::model::Ex::XCall(Text::lit("nat_of"), Array::from(vec![crate::lower::model::Ex::XVar(Text::from(format!("i{}", &span_p5.start)))])));
            crate::lower::model::Do::DoFor(crate::lower::model::Pa::PaTuple(Array::from(vec![crate::lower::model::Pa::PaBind(Text::from(format!("i{}", &span_p5.start))), crate::lower::model::Pa::PaBind(ref_name_p9.clone())])), crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(place_of(lx_p0, env_p1, source_p3)), Text::lit("iter_mut"), Array::new())), Text::lit("enumerate"), Array::new()), append(&Array::from(vec![head_pb.clone()]), &dos_pc))
        },
        _ => crate::lower::expr::refusal_do(&Text::lit("a `for` by reference over what is not an array")),
    }
}

/// The step machine of `UpdForRefs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UpdForRefs: unbounded fn Lx, Env, SName, Expr, Block, Range, Ty -> Do
/// ```
pub struct UpdForRefs {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub n_p2: crate::syntax::SName,
    pub source_p3: crate::syntax::Expr,
    pub body_p4: crate::syntax::Block,
    pub span_p5: crate::syntax::Range,
    pub sty_p6: crate::check::types::Ty,
}

impl prism_rtl::Job<crate::lower::model::Do> for UpdForRefs {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::Do> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let n_p2 = &self.n_p2;
        let source_p3 = &self.source_p3;
        let body_p4 = &self.body_p4;
        let span_p5 = &self.span_p5;
        let sty_p6 = &self.sty_p6;
        match sty_p6 {
            crate::check::types::Ty::TyArray(v_p7) => {
                let key_name_p8 = Text::from(format!("k{}", &span_p5.start));
                let ref_name_p9 = Text::from(format!("r{}", &span_p5.start));
                let body_p4 = body_p4.clone();
                let env_p1 = env_p1.clone();
                let lx_p0 = lx_p0.clone();
                let n_p2 = n_p2.clone();
                let source_p3 = source_p3.clone();
                let span_p5 = span_p5.clone();
                let v_p7 = (**v_p7).clone();
                call_then(crate::lower::types::start_out_ty_of(lx_p0.clone(), v_p7.clone()), move |out_ty_of_12347: crate::lower::model::OutTy| {
                    let env1_pa = crate::lower::types::bind(&crate::lower::types::bind(&crate::lower::types::bind(&env_p1, &Text::lit("key"), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(key_name_p8.clone()), crate::lower::types::Holding::Owned, crate::lower::model::OutTy::OutNat)), &Text::lit("ix"), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(key_name_p8.clone()), crate::lower::types::Holding::Owned, crate::lower::model::OutTy::OutNat)), &crate::check::env::sname_key(&n_p2), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XTarget(Rc::new(crate::lower::model::Ex::XVar(ref_name_p9.clone()))), crate::lower::types::Holding::Owned, out_ty_of_12347));
                    call_then(start_upd_stmts(lx_p0.clone(), env1_pa.clone(), body_p4.stmts.clone()), move |upd_stmts_12393: (Array<crate::lower::model::Do>, crate::lower::types::Env)| {
                        let (dos_pc, _) = upd_stmts_12393;
                        let head_pb = crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(key_name_p8.clone()), crate::lower::model::Ex::XCall(Text::lit("nat_of"), Array::from(vec![crate::lower::model::Ex::XVar(Text::from(format!("i{}", &span_p5.start)))])));
                        call_then(start_place_of(lx_p0.clone(), env_p1.clone(), source_p3.clone()), move |place_of_12602: crate::lower::model::Ex| prism_rtl::Turn::Finished(crate::lower::model::Do::DoFor(crate::lower::model::Pa::PaTuple(Array::from(vec![crate::lower::model::Pa::PaBind(Text::from(format!("i{}", &span_p5.start))), crate::lower::model::Pa::PaBind(ref_name_p9.clone())])), crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(place_of_12602), Text::lit("iter_mut"), Array::new())), Text::lit("enumerate"), Array::new()), append(&Array::from(vec![head_pb.clone()]), &dos_pc))))
                    })
                })
            },
            _ => prism_rtl::Turn::Finished(crate::lower::expr::refusal_do(&Text::lit("a `for` by reference over what is not an array"))),
        }
    }
}

/// `Start UpdForRefs, x`: what the function value is when passed to `@Run`.
pub fn start_upd_for_refs(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, n_p2: crate::syntax::SName, source_p3: crate::syntax::Expr, body_p4: crate::syntax::Block, span_p5: crate::syntax::Range, sty_p6: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::lower::model::Do>> {
    Rc::new(UpdForRefs { lx_p0, env_p1, n_p2, source_p3, body_p4, span_p5, sty_p6 })
}

/// ```prism
/// ?RefBinder: fn ?ForBinders -> ?SName
/// ```
pub fn ref_binder(opt0: &Option<crate::syntax::ForBinders>) -> Option<crate::syntax::SName> {
    match opt0 {
        Some(fb_p0) => match &fb_p0.second {
            None => match &*fb_p0.first.kind {
                crate::syntax::PatternKind::PName(n_p1) => if crate::syntax::lexer::chars::has_prefix(&n_p1.sigils, &Text::lit("&")) {
                    Some(n_p1.clone())
                } else {
                    None
                },
                _ => None,
            },
            _ => None,
        },
        None => None,
    }
}

/// ```prism
/// IsRefPath: fn Expr -> Bool
/// ```
pub fn is_ref_path(e_p0: &crate::syntax::Expr) -> bool {
    match &*e_p0.kind {
        crate::syntax::ExprKind::EName(n_p1) => crate::syntax::lexer::chars::has_prefix(&n_p1.sigils, &Text::lit("&")),
        crate::syntax::ExprKind::EField(r_p2, _, _) => is_ref_path(&**r_p2),
        crate::syntax::ExprKind::EIndex(r_p3, _) => is_ref_path(&**r_p3),
        crate::syntax::ExprKind::EGroup(x_p4) => is_ref_path(&**x_p4),
        _ => false,
    }
}

/// ```prism
/// UpdForValues: unbounded fn Lx, Env, ?ForBinders, Expr, Block, Range, Ty -> Do
/// ```
pub fn upd_for_values(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, binders_o2: &Option<crate::syntax::ForBinders>, source_p3: &crate::syntax::Expr, body_p4: &crate::syntax::Block, span_p5: &crate::syntax::Range, sty_p6: &crate::check::types::Ty) -> crate::lower::model::Do {
    let src_p7 = crate::lower::types::own(&crate::lower::expr::value_of(lx_p0, env_p1, source_p3));
    let (kt_pf, vt_pg, is_array_ph) = match sty_p6 {
        crate::check::types::Ty::TyArray(v_pc) => (crate::lower::model::OutTy::OutNat, crate::lower::types::out_ty_of(lx_p0, &**v_pc), true),
        crate::check::types::Ty::TyMap(k_pd, v_pe) => (crate::lower::types::out_ty_of(lx_p0, &**k_pd), crate::lower::types::out_ty_of(lx_p0, &**v_pe), false),
        _ => (crate::lower::model::OutTy::OutUnit, crate::lower::model::OutTy::OutUnit, true),
    };
    let (vty_pl, kty_pm) = match sty_p6 {
        crate::check::types::Ty::TyArray(v_pi) => ((**v_pi).clone(), crate::check::types::Ty::TyCon(Text::lit("Nat"), Array::new())),
        crate::check::types::Ty::TyMap(k_pj, v_pk) => ((**v_pk).clone(), (**k_pj).clone()),
        _ => (crate::check::types::Ty::TyErr, crate::check::types::Ty::TyErr),
    };
    let key_name_p8 = Text::from(format!("k{}", &span_p5.start));
    let val_name_p9 = Text::from(format!("v{}", &span_p5.start));
    let env1_pa = crate::lower::types::bind(&crate::lower::types::bind(env_p1, &Text::lit("key"), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(key_name_p8.clone()), crate::lower::types::Holding::Owned, kt_pf.clone())), &Text::lit("_"), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(val_name_p9.clone()), crate::lower::types::Holding::Owned, vt_pg.clone()));
    let env2_pb = if is_array_ph {
        crate::lower::types::bind(&env1_pa, &Text::lit("ix"), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(key_name_p8.clone()), crate::lower::types::Holding::Owned, kt_pf.clone()))
    } else {
        env1_pa.clone()
    };
    let (binds_ps, env3_pt) = match binders_o2 {
        None => (Array::new(), env2_pb.clone()),
        Some(fb_pn) => match &fb_pn.second {
            None => {
                let po_po = crate::lower::patterns::rust_pat(lx_p0, &fb_pn.first, &vty_pl, &crate::lower::types::Holding::Owned, &Text::from(format!("e{}", &span_p5.start)));
                (Array::from(vec![crate::lower::model::Do::DoLet(po_po.pa.clone(), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(val_name_p9.clone()))))]), crate::lower::expr::bind_all(&env2_pb, &po_po.binds))
            },
            Some(second_pp) => {
                let pk_pq = crate::lower::patterns::rust_pat(lx_p0, &fb_pn.first, &kty_pm, &crate::lower::types::Holding::Owned, &Text::from(format!("k{}_", &span_p5.start)));
                let pv_pr = crate::lower::patterns::rust_pat(lx_p0, second_pp, &vty_pl, &crate::lower::types::Holding::Owned, &Text::from(format!("e{}", &span_p5.start)));
                (Array::from(vec![crate::lower::model::Do::DoLet(pk_pq.pa.clone(), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(key_name_p8.clone())))), crate::lower::model::Do::DoLet(pv_pr.pa.clone(), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(val_name_p9.clone()))))]), crate::lower::expr::bind_all(&crate::lower::expr::bind_all(&env2_pb, &pk_pq.binds), &pv_pr.binds))
            },
        },
    };
    let (dos_pu, _) = upd_stmts(lx_p0, &env3_pt, &body_p4.stmts);
    if is_array_ph {
        {
            let head_pv = crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(key_name_p8.clone()), crate::lower::model::Ex::XCall(Text::lit("nat_of"), Array::from(vec![crate::lower::model::Ex::XVar(Text::from(format!("i{}", &span_p5.start)))])));
            crate::lower::model::Do::DoFor(crate::lower::model::Pa::PaTuple(Array::from(vec![crate::lower::model::Pa::PaBind(Text::from(format!("i{}", &span_p5.start))), crate::lower::model::Pa::PaBind(val_name_p9.clone())])), crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(src_p7.clone()), Text::lit("into_iter"), Array::new())), Text::lit("enumerate"), Array::new()), append(&push(&Array::new(), &head_pv), &append(&binds_ps, &dos_pu)))
        }
    } else {
        crate::lower::model::Do::DoFor(crate::lower::model::Pa::PaTuple(Array::from(vec![crate::lower::model::Pa::PaBind(key_name_p8.clone()), crate::lower::model::Pa::PaBind(val_name_p9.clone())])), crate::lower::model::Ex::XMethod(Rc::new(src_p7.clone()), Text::lit("into_iter"), Array::new()), append(&binds_ps, &dos_pu))
    }
}

/// The step machine of `UpdForValues`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UpdForValues: unbounded fn Lx, Env, ?ForBinders, Expr, Block, Range, Ty -> Do
/// ```
pub struct UpdForValues {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub binders_o2: Option<crate::syntax::ForBinders>,
    pub source_p3: crate::syntax::Expr,
    pub body_p4: crate::syntax::Block,
    pub span_p5: crate::syntax::Range,
    pub sty_p6: crate::check::types::Ty,
}

impl prism_rtl::Job<crate::lower::model::Do> for UpdForValues {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::Do> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let binders_o2 = &self.binders_o2;
        let source_p3 = &self.source_p3;
        let body_p4 = &self.body_p4;
        let span_p5 = &self.span_p5;
        let sty_p6 = &self.sty_p6;
        let binders_o2 = binders_o2.clone();
        let body_p4 = body_p4.clone();
        let env_p1 = env_p1.clone();
        let lx_p0 = lx_p0.clone();
        let source_p3 = source_p3.clone();
        let span_p5 = span_p5.clone();
        let sty_p6 = sty_p6.clone();
        call_then(crate::lower::expr::start_value_of(lx_p0.clone(), env_p1.clone(), source_p3.clone()), move |value_of_13497: crate::lower::types::Vl| {
            let src_p7 = crate::lower::types::own(&value_of_13497);
            let (kt_pf, vt_pg, is_array_ph) = match &sty_p6 {
                crate::check::types::Ty::TyArray(v_pc) => (crate::lower::model::OutTy::OutNat, crate::lower::types::out_ty_of(&lx_p0, &**v_pc), true),
                crate::check::types::Ty::TyMap(k_pd, v_pe) => (crate::lower::types::out_ty_of(&lx_p0, &**k_pd), crate::lower::types::out_ty_of(&lx_p0, &**v_pe), false),
                _ => (crate::lower::model::OutTy::OutUnit, crate::lower::model::OutTy::OutUnit, true),
            };
            let (vty_pl, kty_pm) = match &sty_p6 {
                crate::check::types::Ty::TyArray(v_pi) => ((**v_pi).clone(), crate::check::types::Ty::TyCon(Text::lit("Nat"), Array::new())),
                crate::check::types::Ty::TyMap(k_pj, v_pk) => ((**v_pk).clone(), (**k_pj).clone()),
                _ => (crate::check::types::Ty::TyErr, crate::check::types::Ty::TyErr),
            };
            let key_name_p8 = Text::from(format!("k{}", &span_p5.start));
            let val_name_p9 = Text::from(format!("v{}", &span_p5.start));
            let env1_pa = crate::lower::types::bind(&crate::lower::types::bind(&env_p1, &Text::lit("key"), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(key_name_p8.clone()), crate::lower::types::Holding::Owned, kt_pf.clone())), &Text::lit("_"), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(val_name_p9.clone()), crate::lower::types::Holding::Owned, vt_pg.clone()));
            let env2_pb = if is_array_ph {
                crate::lower::types::bind(&env1_pa, &Text::lit("ix"), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(key_name_p8.clone()), crate::lower::types::Holding::Owned, kt_pf.clone()))
            } else {
                env1_pa.clone()
            };
            let (binds_ps, env3_pt) = match &binders_o2 {
                None => (Array::new(), env2_pb.clone()),
                Some(fb_pn) => match &fb_pn.second {
                    None => {
                        let po_po = crate::lower::patterns::rust_pat(&lx_p0, &fb_pn.first, &vty_pl, &crate::lower::types::Holding::Owned, &Text::from(format!("e{}", &span_p5.start)));
                        (Array::from(vec![crate::lower::model::Do::DoLet(po_po.pa.clone(), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(val_name_p9.clone()))))]), crate::lower::expr::bind_all(&env2_pb, &po_po.binds))
                    },
                    Some(second_pp) => {
                        let pk_pq = crate::lower::patterns::rust_pat(&lx_p0, &fb_pn.first, &kty_pm, &crate::lower::types::Holding::Owned, &Text::from(format!("k{}_", &span_p5.start)));
                        let pv_pr = crate::lower::patterns::rust_pat(&lx_p0, second_pp, &vty_pl, &crate::lower::types::Holding::Owned, &Text::from(format!("e{}", &span_p5.start)));
                        (Array::from(vec![crate::lower::model::Do::DoLet(pk_pq.pa.clone(), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(key_name_p8.clone())))), crate::lower::model::Do::DoLet(pv_pr.pa.clone(), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(val_name_p9.clone()))))]), crate::lower::expr::bind_all(&crate::lower::expr::bind_all(&env2_pb, &pk_pq.binds), &pv_pr.binds))
                    },
                },
            };
            call_then(start_upd_stmts(lx_p0.clone(), env3_pt.clone(), body_p4.stmts.clone()), move |upd_stmts_14778: (Array<crate::lower::model::Do>, crate::lower::types::Env)| {
                let (dos_pu, _) = upd_stmts_14778;
                if is_array_ph {
                    {
                        let head_pv = crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(key_name_p8.clone()), crate::lower::model::Ex::XCall(Text::lit("nat_of"), Array::from(vec![crate::lower::model::Ex::XVar(Text::from(format!("i{}", &span_p5.start)))])));
                        prism_rtl::Turn::Finished(crate::lower::model::Do::DoFor(crate::lower::model::Pa::PaTuple(Array::from(vec![crate::lower::model::Pa::PaBind(Text::from(format!("i{}", &span_p5.start))), crate::lower::model::Pa::PaBind(val_name_p9.clone())])), crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(src_p7.clone()), Text::lit("into_iter"), Array::new())), Text::lit("enumerate"), Array::new()), append(&push(&Array::new(), &head_pv), &append(&binds_ps, &dos_pu))))
                    }
                } else {
                    prism_rtl::Turn::Finished(crate::lower::model::Do::DoFor(crate::lower::model::Pa::PaTuple(Array::from(vec![crate::lower::model::Pa::PaBind(key_name_p8.clone()), crate::lower::model::Pa::PaBind(val_name_p9.clone())])), crate::lower::model::Ex::XMethod(Rc::new(src_p7.clone()), Text::lit("into_iter"), Array::new()), append(&binds_ps, &dos_pu)))
                }
            })
        })
    }
}

/// `Start UpdForValues, x`: what the function value is when passed to `@Run`.
pub fn start_upd_for_values(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, binders_o2: Option<crate::syntax::ForBinders>, source_p3: crate::syntax::Expr, body_p4: crate::syntax::Block, span_p5: crate::syntax::Range, sty_p6: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::lower::model::Do>> {
    Rc::new(UpdForValues { lx_p0, env_p1, binders_o2, source_p3, body_p4, span_p5, sty_p6 })
}

/// ```prism
/// UpdIf: unbounded fn Lx, Env, Cond, Block, ?Block -> Do
/// ```
pub fn upd_if(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, c_p2: &crate::syntax::Cond, then_b_p3: &crate::syntax::Block, else_b_o4: &Option<crate::syntax::Block>) -> crate::lower::model::Do {
    let (else_dos_p6, _) = match else_b_o4 {
        Some(b_p5) => upd_stmts(lx_p0, env_p1, &b_p5.stmts),
        None => (Array::new(), env_p1.clone()),
    };
    match c_p2 {
        crate::syntax::Cond::CondExpr(x_p7) => {
            let (then_dos_p8, _) = upd_stmts(lx_p0, env_p1, &then_b_p3.stmts);
            crate::lower::model::Do::DoIf(crate::lower::types::as_bool(&crate::lower::expr::value_of(lx_p0, env_p1, &**x_p7)), then_dos_p8.clone(), else_dos_p6.clone())
        },
        crate::syntax::Cond::CondBind(p_p9, x_pa, _) => {
            let po_pb = crate::lower::patterns::rust_pat(lx_p0, p_p9, &crate::lower::type_at(lx_p0, &x_pa.span), &crate::lower::types::Holding::Owned, &Text::from(format!("u{}", &x_pa.span.start)));
            let (then_dos_pc, _) = upd_stmts(lx_p0, &crate::lower::expr::bind_all(env_p1, &po_pb.binds), &then_b_p3.stmts);
            crate::lower::model::Do::DoIfLet(po_pb.pa.clone(), crate::lower::types::own(&crate::lower::expr::value_of(lx_p0, env_p1, &**x_pa)), then_dos_pc.clone(), else_dos_p6.clone())
        },
    }
}

/// The step machine of `UpdIf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UpdIf: unbounded fn Lx, Env, Cond, Block, ?Block -> Do
/// ```
pub struct UpdIf {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub c_p2: crate::syntax::Cond,
    pub then_b_p3: crate::syntax::Block,
    pub else_b_o4: Option<crate::syntax::Block>,
}

impl prism_rtl::Job<crate::lower::model::Do> for UpdIf {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::Do> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let c_p2 = &self.c_p2;
        let then_b_p3 = &self.then_b_p3;
        let else_b_o4 = &self.else_b_o4;
        let (else_dos_p6, _) = match else_b_o4 {
            Some(b_p5) => upd_stmts(lx_p0, env_p1, &b_p5.stmts),
            None => (Array::new(), env_p1.clone()),
        };
        match c_p2 {
            crate::syntax::Cond::CondExpr(x_p7) => {
                let env_p1 = env_p1.clone();
                let lx_p0 = lx_p0.clone();
                let then_b_p3 = then_b_p3.clone();
                let x_p7 = (**x_p7).clone();
                call_then(start_upd_stmts(lx_p0.clone(), env_p1.clone(), then_b_p3.stmts.clone()), move |upd_stmts_15488: (Array<crate::lower::model::Do>, crate::lower::types::Env)| {
                    let (then_dos_p8, _) = upd_stmts_15488;
                    call_then(crate::lower::expr::start_value_of(lx_p0.clone(), env_p1.clone(), x_p7.clone()), move |value_of_15544: crate::lower::types::Vl| prism_rtl::Turn::Finished(crate::lower::model::Do::DoIf(crate::lower::types::as_bool(&value_of_15544), then_dos_p8.clone(), else_dos_p6.clone())))
                })
            },
            crate::syntax::Cond::CondBind(p_p9, x_pa, _) => {
                let env_p1 = env_p1.clone();
                let lx_p0 = lx_p0.clone();
                let p_p9 = p_p9.clone();
                let then_b_p3 = then_b_p3.clone();
                let x_pa = (**x_pa).clone();
                call_then(crate::lower::patterns::start_rust_pat(lx_p0.clone(), p_p9.clone(), crate::lower::type_at(&lx_p0, &x_pa.span), crate::lower::types::Holding::Owned, Text::from(format!("u{}", &x_pa.span.start))), move |rust_pat_15635: crate::lower::patterns::PatOut| {
                    let po_pb = rust_pat_15635;
                    call_then(start_upd_stmts(lx_p0.clone(), crate::lower::expr::bind_all(&env_p1, &po_pb.binds), then_b_p3.stmts.clone()), move |upd_stmts_15734: (Array<crate::lower::model::Do>, crate::lower::types::Env)| {
                        let (then_dos_pc, _) = upd_stmts_15734;
                        call_then(crate::lower::expr::start_value_of(lx_p0.clone(), env_p1.clone(), x_pa.clone()), move |value_of_15817: crate::lower::types::Vl| prism_rtl::Turn::Finished(crate::lower::model::Do::DoIfLet(po_pb.pa.clone(), crate::lower::types::own(&value_of_15817), then_dos_pc.clone(), else_dos_p6.clone())))
                    })
                })
            },
        }
    }
}

/// `Start UpdIf, x`: what the function value is when passed to `@Run`.
pub fn start_upd_if(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, c_p2: crate::syntax::Cond, then_b_p3: crate::syntax::Block, else_b_o4: Option<crate::syntax::Block>) -> Rc<dyn prism_rtl::Job<crate::lower::model::Do>> {
    Rc::new(UpdIf { lx_p0, env_p1, c_p2, then_b_p3, else_b_o4 })
}

/// ```prism
/// UpdMatch: unbounded fn Lx, Env, Expr, [Arm] -> Do
/// ```
pub fn upd_match(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, scrut_p2: &crate::syntax::Expr, arms_p3: &Array<crate::syntax::Arm>) -> crate::lower::model::Do {
    let sv_p4 = crate::lower::expr::value_of(lx_p0, env_p1, scrut_p2);
    let sty_p5 = crate::lower::type_at(lx_p0, &scrut_p2.span);
    let arms3_p6 = run_to_end(each_job(crate::check::errors::range0(&len(arms_p3)), {
        let arms_p3 = arms_p3.clone();
        let lx_p0 = lx_p0.clone();
        let sty_p5 = sty_p5.clone();
        let scrut_p2 = scrut_p2.clone();
        let env_p1 = env_p1.clone();
        Rc::new(move |p0: Nat| {
            let arms_p3 = arms_p3.clone();
            let lx_p0 = lx_p0.clone();
            let sty_p5 = sty_p5.clone();
            let scrut_p2 = scrut_p2.clone();
            let env_p1 = env_p1.clone();
            entered(once_job(move || {
                let i_p7 = p0;
                {
                    let arm_p8 = or(&index(&arms_p3, &i_p7), &crate::lower::expr::dummy_arm());
                    call_then(crate::lower::expr::start_arm_pat(lx_p0.clone(), arm_p8.pattern.clone(), sty_p5.clone(), crate::lower::types::Holding::ByRef, Text::from(format!("u{}_{}", &scrut_p2.span.start, &i_p7))), move |arm_pat_16116: crate::lower::patterns::PatOut| {
                        let po_p9 = arm_pat_16116;
                        call_then(start_upd_stmts(lx_p0.clone(), crate::lower::expr::bind_all(&env_p1, &po_p9.binds), arm_p8.body.stmts.clone()), move |upd_stmts_16209: (Array<crate::lower::model::Do>, crate::lower::types::Env)| {
                            let (dos_pb, _) = upd_stmts_16209;
                            call_then(start_guard_conds(lx_p0.clone(), crate::lower::expr::bind_all(&env_p1, &po_p9.binds), arm_p8.guard.clone()), move |guard_conds_16302: Array<crate::lower::model::Cc>| {
                                let guarded_pa = append(&po_p9.conds, &guard_conds_16302);
                                prism_rtl::Turn::Finished(crate::lower::model::XArm { pat: po_p9.pa.clone(), conds: guarded_pa.clone(), body: crate::lower::model::Ex::XBlock(dos_pb.clone(), Rc::new(crate::lower::model::Ex::XUnit)) })
                            })
                        })
                    })
                }
            }))
        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<crate::lower::model::XArm>>>
    }));
    if fold(&arms3_p6, &false, &(|f_pc: &bool, a_pd: &crate::lower::model::XArm| *f_pc || (&len(&a_pd.conds) > &Nat::from(0u32)))) {
        crate::lower::model::Do::DoExpr(crate::lower::types::own(&crate::lower::expr::arms_value(&crate::lower::types::ref_(&sv_p4), &arms3_p6, &Text::from(format!("\'u{}", &scrut_p2.span.start)), &crate::lower::model::OutTy::OutUnit)))
    } else {
        crate::lower::model::Do::DoMatch(crate::lower::types::ref_(&sv_p4), each(&arms3_p6, &(|a_pe: &crate::lower::model::XArm| (a_pe.pat.clone(), arm_dos(&a_pe.body)))))
    }
}

/// The step machine of `UpdMatch`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UpdMatch: unbounded fn Lx, Env, Expr, [Arm] -> Do
/// ```
pub struct UpdMatch {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub scrut_p2: crate::syntax::Expr,
    pub arms_p3: Array<crate::syntax::Arm>,
}

impl prism_rtl::Job<crate::lower::model::Do> for UpdMatch {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::Do> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let scrut_p2 = &self.scrut_p2;
        let arms_p3 = &self.arms_p3;
        let arms_p3 = arms_p3.clone();
        let env_p1 = env_p1.clone();
        let lx_p0 = lx_p0.clone();
        let scrut_p2 = scrut_p2.clone();
        call_then(crate::lower::expr::start_value_of(lx_p0.clone(), env_p1.clone(), scrut_p2.clone()), move |value_of_15954: crate::lower::types::Vl| {
            let sv_p4 = value_of_15954;
            let sty_p5 = crate::lower::type_at(&lx_p0, &scrut_p2.span);
            call_value(each_job(crate::check::errors::range0(&len(&arms_p3)), {
                let arms_p3 = arms_p3.clone();
                let lx_p0 = lx_p0.clone();
                let sty_p5 = sty_p5.clone();
                let scrut_p2 = scrut_p2.clone();
                let env_p1 = env_p1.clone();
                Rc::new(move |p0: Nat| {
                    let arms_p3 = arms_p3.clone();
                    let lx_p0 = lx_p0.clone();
                    let sty_p5 = sty_p5.clone();
                    let scrut_p2 = scrut_p2.clone();
                    let env_p1 = env_p1.clone();
                    entered(once_job(move || {
                        let i_p7 = p0;
                        {
                            let arm_p8 = or(&index(&arms_p3, &i_p7), &crate::lower::expr::dummy_arm());
                            call_then(crate::lower::expr::start_arm_pat(lx_p0.clone(), arm_p8.pattern.clone(), sty_p5.clone(), crate::lower::types::Holding::ByRef, Text::from(format!("u{}_{}", &scrut_p2.span.start, &i_p7))), move |arm_pat_16116: crate::lower::patterns::PatOut| {
                                let po_p9 = arm_pat_16116;
                                call_then(start_upd_stmts(lx_p0.clone(), crate::lower::expr::bind_all(&env_p1, &po_p9.binds), arm_p8.body.stmts.clone()), move |upd_stmts_16209: (Array<crate::lower::model::Do>, crate::lower::types::Env)| {
                                    let (dos_pb, _) = upd_stmts_16209;
                                    call_then(start_guard_conds(lx_p0.clone(), crate::lower::expr::bind_all(&env_p1, &po_p9.binds), arm_p8.guard.clone()), move |guard_conds_16302: Array<crate::lower::model::Cc>| {
                                        let guarded_pa = append(&po_p9.conds, &guard_conds_16302);
                                        prism_rtl::Turn::Finished(crate::lower::model::XArm { pat: po_p9.pa.clone(), conds: guarded_pa.clone(), body: crate::lower::model::Ex::XBlock(dos_pb.clone(), Rc::new(crate::lower::model::Ex::XUnit)) })
                                    })
                                })
                            })
                        }
                    }))
                }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<crate::lower::model::XArm>>>
            }), move |each_16029: Array<crate::lower::model::XArm>| {
                let arms3_p6 = each_16029;
                if fold(&arms3_p6, &false, &(|f_pc: &bool, a_pd: &crate::lower::model::XArm| *f_pc || (&len(&a_pd.conds) > &Nat::from(0u32)))) {
                    prism_rtl::Turn::Finished(crate::lower::model::Do::DoExpr(crate::lower::types::own(&crate::lower::expr::arms_value(&crate::lower::types::ref_(&sv_p4), &arms3_p6, &Text::from(format!("\'u{}", &scrut_p2.span.start)), &crate::lower::model::OutTy::OutUnit))))
                } else {
                    prism_rtl::Turn::Finished(crate::lower::model::Do::DoMatch(crate::lower::types::ref_(&sv_p4), each(&arms3_p6, &(|a_pe: &crate::lower::model::XArm| (a_pe.pat.clone(), arm_dos(&a_pe.body))))))
                }
            })
        })
    }
}

/// `Start UpdMatch, x`: what the function value is when passed to `@Run`.
pub fn start_upd_match(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, scrut_p2: crate::syntax::Expr, arms_p3: Array<crate::syntax::Arm>) -> Rc<dyn prism_rtl::Job<crate::lower::model::Do>> {
    Rc::new(UpdMatch { lx_p0, env_p1, scrut_p2, arms_p3 })
}

/// ```prism
/// AllOf: fn [Ex] -> Ex
/// ```
pub fn all_of(xs0: &Array<crate::lower::model::Ex>) -> crate::lower::model::Ex {
    'c: {
        if let c0_0 = xs0 && (c0_0.len() == 1) && let Some(one_p0) = index(c0_0, &Nat::from(0u32)) {
            break 'c one_p0.clone();
        }
        if let xs_p1 = xs0 {
            break 'c fold(&drop(xs_p1, &Nat::from(1u32)), &or(&index(xs_p1, &Nat::from(0u32)), &crate::lower::model::Ex::XBool(true)), &(|acc_p2: &crate::lower::model::Ex, x_p3: &crate::lower::model::Ex| crate::lower::model::Ex::XBin(Text::lit("&&"), Rc::new(acc_p2.clone()), Rc::new(x_p3.clone()))));
        }
        unreachable!("no clause matched")
    }
}

/// ```prism
/// ArmDos: fn Ex -> [Do]
/// ```
pub fn arm_dos(ex0: &crate::lower::model::Ex) -> Array<crate::lower::model::Do> {
    match ex0 {
        crate::lower::model::Ex::XBlock(dos_p0, _) => dos_p0.clone(),
        x_p1 => Array::from(vec![crate::lower::model::Do::DoExpr(x_p1.clone())]),
    }
}

/// ```prism
/// GuardConds: unbounded fn Lx, Env, ?Expr -> [Cc]
/// ```
pub fn guard_conds(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, opt2: &Option<crate::syntax::Expr>) -> Array<crate::lower::model::Cc> {
    match opt2 {
        Some(ge_p2) => Array::from(vec![crate::lower::model::Cc::CcIf(crate::lower::types::as_bool(&crate::lower::expr::value_of(lx_p0, env_p1, ge_p2)))]),
        None => Array::new(),
    }
}

/// The step machine of `GuardConds`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// GuardConds: unbounded fn Lx, Env, ?Expr -> [Cc]
/// ```
pub struct GuardConds {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub opt2: Option<crate::syntax::Expr>,
}

impl prism_rtl::Job<Array<crate::lower::model::Cc>> for GuardConds {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::lower::model::Cc>> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let opt2 = &self.opt2;
        match opt2 {
            Some(ge_p2) => {
                let env_p1 = env_p1.clone();
                let ge_p2 = ge_p2.clone();
                let lx_p0 = lx_p0.clone();
                call_then(crate::lower::expr::start_value_of(lx_p0.clone(), env_p1.clone(), ge_p2.clone()), move |value_of_17144: crate::lower::types::Vl| prism_rtl::Turn::Finished(Array::from(vec![crate::lower::model::Cc::CcIf(crate::lower::types::as_bool(&value_of_17144))])))
            },
            None => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start GuardConds, x`: what the function value is when passed to `@Run`.
pub fn start_guard_conds(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, opt2: Option<crate::syntax::Expr>) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Cc>>> {
    Rc::new(GuardConds { lx_p0, env_p1, opt2 })
}

/// ```prism
/// PlaceOf: unbounded fn Lx, Env, Expr -> Ex
/// ```
pub fn place_of(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, e_p2: &crate::syntax::Expr) -> crate::lower::model::Ex {
    match &*e_p2.kind {
        crate::syntax::ExprKind::EName(n_p3) => match get(&env_p1.names, &crate::check::env::sname_key(n_p3)) {
            Some(crate::lower::types::Bn::BnLocal(rs_p4, _, _)) => rs_p4,
            _ => crate::lower::model::Ex::XVar(crate::lower::snake(&crate::check::env::sname_key(n_p3))),
        },
        crate::syntax::ExprKind::EField(r_p5, _, name_p6) => crate::lower::model::Ex::XField(Rc::new(place_of(lx_p0, env_p1, &**r_p5)), crate::lower::snake(&name_p6.name)),
        crate::syntax::ExprKind::EIndex(r_p7, k_p8) => {
            let rt_p9 = crate::lower::types::out_ty_of(lx_p0, &crate::lower::types::peel(&crate::lower::type_at(lx_p0, &r_p7.span)));
            let f_pa = match &rt_p9 {
                crate::lower::model::OutTy::OutMap(_, _) => Text::lit("at_mut_map"),
                _ => Text::lit("at_mut"),
            };
            crate::lower::model::Ex::XDeref(Rc::new(crate::lower::model::Ex::XCall(f_pa.clone(), Array::from(vec![crate::lower::model::Ex::XRefMut(Rc::new(place_of(lx_p0, env_p1, &**r_p7))), crate::lower::expr::argument(lx_p0, env_p1, &**k_p8)]))))
        },
        crate::syntax::ExprKind::EGroup(x_pb) => place_of(lx_p0, env_p1, &**x_pb),
        _ => crate::lower::expr::refusal(&Text::lit("a reference path this back end does not lower")),
    }
}

/// The step machine of `PlaceOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PlaceOf: unbounded fn Lx, Env, Expr -> Ex
/// ```
pub struct PlaceOf {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub e_p2: crate::syntax::Expr,
}

impl prism_rtl::Job<crate::lower::model::Ex> for PlaceOf {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::Ex> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let e_p2 = &self.e_p2;
        match &*e_p2.kind {
            crate::syntax::ExprKind::EName(n_p3) => match get(&env_p1.names, &crate::check::env::sname_key(n_p3)) {
                Some(crate::lower::types::Bn::BnLocal(rs_p4, _, _)) => prism_rtl::Turn::Finished(rs_p4.clone()),
                _ => prism_rtl::Turn::Finished(crate::lower::model::Ex::XVar(crate::lower::snake(&crate::check::env::sname_key(n_p3)))),
            },
            crate::syntax::ExprKind::EField(r_p5, _, name_p6) => {
                let env_p1 = env_p1.clone();
                let lx_p0 = lx_p0.clone();
                let name_p6 = name_p6.clone();
                let r_p5 = (**r_p5).clone();
                call_then(start_place_of(lx_p0.clone(), env_p1.clone(), r_p5.clone()), move |place_of_17512: crate::lower::model::Ex| prism_rtl::Turn::Finished(crate::lower::model::Ex::XField(Rc::new(place_of_17512), crate::lower::snake(&name_p6.name))))
            },
            crate::syntax::ExprKind::EIndex(r_p7, k_p8) => {
                let env_p1 = env_p1.clone();
                let k_p8 = (**k_p8).clone();
                let lx_p0 = lx_p0.clone();
                let r_p7 = (**r_p7).clone();
                call_then(crate::lower::types::start_out_ty_of(lx_p0.clone(), crate::lower::types::peel(&crate::lower::type_at(&lx_p0, &r_p7.span))), move |out_ty_of_17585: crate::lower::model::OutTy| {
                    let rt_p9 = out_ty_of_17585;
                    let f_pa = match &rt_p9 {
                        crate::lower::model::OutTy::OutMap(_, _) => Text::lit("at_mut_map"),
                        _ => Text::lit("at_mut"),
                    };
                    call_then(start_place_of(lx_p0.clone(), env_p1.clone(), r_p7.clone()), move |place_of_17767: crate::lower::model::Ex| call_then(crate::lower::expr::start_argument(lx_p0.clone(), env_p1.clone(), k_p8.clone()), move |argument_17790: crate::lower::model::Ex| prism_rtl::Turn::Finished(crate::lower::model::Ex::XDeref(Rc::new(crate::lower::model::Ex::XCall(f_pa.clone(), Array::from(vec![crate::lower::model::Ex::XRefMut(Rc::new(place_of_17767)), argument_17790])))))))
                })
            },
            crate::syntax::ExprKind::EGroup(x_pb) => prism_rtl::Turn::More(Rc::new(PlaceOf { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), e_p2: (**x_pb).clone() })),
            _ => prism_rtl::Turn::Finished(crate::lower::expr::refusal(&Text::lit("a reference path this back end does not lower"))),
        }
    }
}

/// `Start PlaceOf, x`: what the function value is when passed to `@Run`.
pub fn start_place_of(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, e_p2: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>> {
    Rc::new(PlaceOf { lx_p0, env_p1, e_p2 })
}

/// ```prism
/// Assign: unbounded fn Lx, Env, Expr, Ex -> Do
/// ```
pub fn assign(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, target_p2: &crate::syntax::Expr, v_p3: &crate::lower::model::Ex) -> crate::lower::model::Do {
    match &*target_p2.kind {
        crate::syntax::ExprKind::EIndex(r_p4, k_p5) => {
            let rt_p6 = crate::lower::types::out_ty_of(lx_p0, &crate::lower::types::peel(&crate::lower::type_at(lx_p0, &r_p4.span)));
            let f_p7 = match &rt_p6 {
                crate::lower::model::OutTy::OutMap(_, _) => Text::lit("set_key"),
                _ => Text::lit("set_index"),
            };
            crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XCall(f_p7.clone(), Array::from(vec![crate::lower::model::Ex::XRefMut(Rc::new(place_of(lx_p0, env_p1, &**r_p4))), crate::lower::expr::argument(lx_p0, env_p1, &**k_p5), v_p3.clone()])))
        },
        crate::syntax::ExprKind::EGroup(x_p8) => assign(lx_p0, env_p1, &**x_p8, v_p3),
        _ => crate::lower::model::Do::DoAssign(place_of(lx_p0, env_p1, target_p2), v_p3.clone()),
    }
}

/// The step machine of `Assign`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Assign: unbounded fn Lx, Env, Expr, Ex -> Do
/// ```
pub struct Assign {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub target_p2: crate::syntax::Expr,
    pub v_p3: crate::lower::model::Ex,
}

impl prism_rtl::Job<crate::lower::model::Do> for Assign {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::Do> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let target_p2 = &self.target_p2;
        let v_p3 = &self.v_p3;
        match &*target_p2.kind {
            crate::syntax::ExprKind::EIndex(r_p4, k_p5) => {
                let env_p1 = env_p1.clone();
                let k_p5 = (**k_p5).clone();
                let lx_p0 = lx_p0.clone();
                let r_p4 = (**r_p4).clone();
                let v_p3 = v_p3.clone();
                call_then(crate::lower::types::start_out_ty_of(lx_p0.clone(), crate::lower::types::peel(&crate::lower::type_at(&lx_p0, &r_p4.span))), move |out_ty_of_18198: crate::lower::model::OutTy| {
                    let rt_p6 = out_ty_of_18198;
                    let f_p7 = match &rt_p6 {
                        crate::lower::model::OutTy::OutMap(_, _) => Text::lit("set_key"),
                        _ => Text::lit("set_index"),
                    };
                    call_then(start_place_of(lx_p0.clone(), env_p1.clone(), r_p4.clone()), move |place_of_18380: crate::lower::model::Ex| call_then(crate::lower::expr::start_argument(lx_p0.clone(), env_p1.clone(), k_p5.clone()), move |argument_18403: crate::lower::model::Ex| prism_rtl::Turn::Finished(crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XCall(f_p7.clone(), Array::from(vec![crate::lower::model::Ex::XRefMut(Rc::new(place_of_18380)), argument_18403, v_p3.clone()]))))))
                })
            },
            crate::syntax::ExprKind::EGroup(x_p8) => prism_rtl::Turn::More(Rc::new(Assign { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), target_p2: (**x_p8).clone(), v_p3: v_p3.clone() })),
            _ => {
                let env_p1 = env_p1.clone();
                let lx_p0 = lx_p0.clone();
                let target_p2 = target_p2.clone();
                let v_p3 = v_p3.clone();
                call_then(start_place_of(lx_p0.clone(), env_p1.clone(), target_p2.clone()), move |place_of_18490: crate::lower::model::Ex| prism_rtl::Turn::Finished(crate::lower::model::Do::DoAssign(place_of_18490, v_p3.clone())))
            },
        }
    }
}

/// `Start Assign, x`: what the function value is when passed to `@Run`.
pub fn start_assign(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, target_p2: crate::syntax::Expr, v_p3: crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<crate::lower::model::Do>> {
    Rc::new(Assign { lx_p0, env_p1, target_p2, v_p3 })
}
