//! The module `Lower.Patterns`, from `target/bootstrap/src/prismc/lower/patterns.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file. The runtime
//! side is reached from the crate, `crate::prelude` (and through it `::prism_rtl`), the
//! standard library from `::std`, and nothing is imported by name: a program's own type
//! (`Row`, `Option`) hides none of theirs. The traits are in scope unnamed, for their methods.

use crate::prelude::traits::*;

/// `PatOut`:
///
/// ```prism
/// type PatOut = record:
/// ```
#[derive(::std::clone::Clone)]
pub struct PatOut {
    pub pa_p: crate::lower::model::Pa,
    pub conds_p: crate::prelude::Array<crate::lower::model::Cc>,
    pub binds_p: crate::prelude::Array<(crate::prelude::Text, crate::lower::types::Bn)>,
}

/// ```prism
/// PatOnly: fn Pa -> PatOut
/// ```
pub fn pat_only_f(pa_p0: &crate::lower::model::Pa) -> PatOut {
    PatOut { pa_p: pa_p0.clone(), conds_p: crate::prelude::Array::new(), binds_p: crate::prelude::Array::new() }
}

/// ```prism
/// RustPat: unbounded fn Lx, Pattern, Ty, Holding, Text -> PatOut
/// ```
pub fn rust_pat_f(lx_p0: &crate::lower::Lx, p_p1: &crate::syntax::Pattern, ty_p2: &crate::check::types::Ty, mode_p3: &crate::lower::types::Holding, fresh_p4: &crate::prelude::Text) -> PatOut {
    match &*p_p1.kind_p {
        crate::syntax::PatternKind::PName(n_p5) => {
            let nkey_p6 = crate::check::env::sname_key_f(n_p5);
            let (qk_o9, why_pa) = crate::check::env::names::resolve_value_f(&lx_p0.g_p, &lx_p0.home_p, n_p5);
            let is_ctor_p7 = match &qk_o9 {
                ::std::option::Option::Some(qk_pb) => crate::check::env::has_key_f(&lx_p0.g_p.ctors_p, qk_pb) && ((crate::check::env::is_upper_text_f(&crate::lower::base_f(&nkey_p6)) || (&crate::prelude::len(&n_p5.path_p) > &crate::prelude::Nat::from(1u32))) || (is_unit_ctor_f(lx_p0, qk_pb) && !crate::check::env::has_key_f(&lx_p0.binders_p, &crate::lower::place_key_f(lx_p0, &n_p5.span_p)))),
                ::std::option::Option::None => false,
            };
            let tagged_o8 = match &qk_o9 {
                ::std::option::Option::Some(qk_pc) => crate::prelude::get(&lx_p0.g_p.tags_p, qk_pc),
                ::std::option::Option::None => ::std::option::Option::None,
            };
            if is_ctor_p7 {
                ctor_pat_f(lx_p0, n_p5, &crate::prelude::Array::new(), ty_p2, mode_p3, fresh_p4)
            } else {
                if (&why_pa == &crate::prelude::Text::lit("tag")) && (&tagged_o8 != &::std::option::Option::None) {
                    tag_pat_f(lx_p0, &crate::prelude::or(&tagged_o8, &dummy_tag_info_p()), &crate::prelude::Array::new(), &true, ty_p2, mode_p3, fresh_p4)
                } else {
                    {
                        let rs_pd = crate::lower::local_name_at_f(lx_p0, &nkey_p6, &n_p5.span_p);
                        let full_pe = crate::lower::binder_ty_f(lx_p0, &n_p5.span_p);
                        let bt_pf = crate::lower::types::out_ty_of_f(lx_p0, &(if lx_p0.whole_p { full_pe.clone() } else { crate::lower::types::peel_f(&full_pe) }));
                        PatOut { pa_p: crate::lower::model::Pa::PaBind(rs_pd.clone()), conds_p: crate::prelude::Array::new(), binds_p: crate::prelude::Array::from(vec![(nkey_p6.clone(), crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(rs_pd.clone()), mode_p3.clone(), bt_pf.clone()))]) }
                    }
                }
            }
        },
        crate::syntax::PatternKind::PIgnore => pat_only_f(&crate::lower::model::Pa::PaWild),
        crate::syntax::PatternKind::PUnit => pat_only_f(&crate::lower::model::Pa::PaWild),
        crate::syntax::PatternKind::PNil => pat_only_f(&crate::lower::model::Pa::PaUnit(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::None")))),
        crate::syntax::PatternKind::PLit(l_pg) => lit_pat_f(lx_p0, l_pg, ty_p2, mode_p3, fresh_p4, &false),
        crate::syntax::PatternKind::PNeg(l_ph) => lit_pat_f(lx_p0, l_ph, ty_p2, mode_p3, fresh_p4, &true),
        crate::syntax::PatternKind::PSigil(m1652_6_0, q_pi) if (m1652_6_0 == &crate::prelude::Text::lit("?")) => wrap_pat_f(lx_p0, &crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Some")), &**q_pi, &inner_ty_f(ty_p2), mode_p3, fresh_p4),
        crate::syntax::PatternKind::PSigil(m1652_7_0, q_pj) if (m1652_7_0 == &crate::prelude::Text::lit("~")) => wrap_pat_f(lx_p0, &crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Ok")), &**q_pj, &inner_ty_f(ty_p2), mode_p3, fresh_p4),
        crate::syntax::PatternKind::PSigil(_, q_pk) => rust_pat_f(lx_p0, &**q_pk, ty_p2, mode_p3, fresh_p4),
        crate::syntax::PatternKind::PGroup(q_pl) => rust_pat_f(lx_p0, &**q_pl, ty_p2, mode_p3, fresh_p4),
        crate::syntax::PatternKind::PCtor(n_pm, ps_pn) => ctor_pat_f(lx_p0, n_pm, ps_pn, ty_p2, mode_p3, fresh_p4),
        crate::syntax::PatternKind::PRecord(n_po, fps_pp, rest_pq) => record_pat_f(lx_p0, n_po, fps_pp, rest_pq, ty_p2, mode_p3, fresh_p4),
        crate::syntax::PatternKind::PTuple(ps_pr) => {
            let ts_ps = match crate::lower::types::peel_f(ty_p2) {
                crate::check::types::Ty::TyTuple(xs_pu) => xs_pu,
                _ => crate::prelude::Array::new(),
            };
            let subs_pt = crate::prelude::run_to_end(crate::prelude::each_job(crate::check::errors::range0_f(&crate::prelude::len(ps_pr)), {
                let lx_p0x = lx_p0.clone();
                let ps_prx = ps_pr.clone();
                let ts_psx = ts_ps.clone();
                let mode_p3x = mode_p3.clone();
                let fresh_p4x = fresh_p4.clone();
                ::std::rc::Rc::new(move |p0: crate::prelude::Nat| {
                    let lx_p0xy = lx_p0x.clone();
                    let ps_prxy = ps_prx.clone();
                    let ts_psxy = ts_psx.clone();
                    let mode_p3xy = mode_p3x.clone();
                    let fresh_p4xy = fresh_p4x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let i_pv = p0;
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(RustPat { lx_p0: lx_p0xy.clone(), p_p1: crate::prelude::or(&crate::prelude::index(&ps_prxy, &i_pv), &dummy_pat_p()), ty_p2: crate::prelude::or(&crate::prelude::index(&ts_psxy, &i_pv), &crate::check::types::Ty::TyErr), mode_p3: mode_p3xy.clone(), fresh_p4: crate::prelude::Text::from(format!("{}_{}", &fresh_p4xy, &i_pv)) }))
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<PatOut>>>
            }));
            PatOut { pa_p: crate::lower::model::Pa::PaTuple(crate::prelude::each(&subs_pt, &(|o_p10: &PatOut| o_p10.pa_p.clone()))), conds_p: crate::prelude::fold(&subs_pt, &crate::prelude::Array::new(), &(|acc_p11: &crate::prelude::Array<crate::lower::model::Cc>, o_p12: &PatOut| crate::prelude::append(acc_p11, &o_p12.conds_p))), binds_p: crate::prelude::fold(&subs_pt, &crate::prelude::Array::new(), &(|acc_p13: &crate::prelude::Array<(crate::prelude::Text, crate::lower::types::Bn)>, o_p14: &PatOut| crate::prelude::append(acc_p13, &o_p14.binds_p))) }
        },
        crate::syntax::PatternKind::PArray(ps_p15) => array_pat_f(lx_p0, ps_p15, ty_p2, mode_p3, fresh_p4),
        crate::syntax::PatternKind::PFamily(q_p16) => family_pat_f(lx_p0, q_p16, ty_p2, fresh_p4),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `RustPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RustPat: unbounded fn Lx, Pattern, Ty, Holding, Text -> PatOut
/// ```
pub struct RustPat {
    pub lx_p0: crate::lower::Lx,
    pub p_p1: crate::syntax::Pattern,
    pub ty_p2: crate::check::types::Ty,
    pub mode_p3: crate::lower::types::Holding,
    pub fresh_p4: crate::prelude::Text,
}

impl ::prism_rtl::Job<PatOut> for RustPat {
    fn cycle(&self) -> ::prism_rtl::Turn<PatOut> {
        let lx_p0 = &self.lx_p0;
        let p_p1 = &self.p_p1;
        let ty_p2 = &self.ty_p2;
        let mode_p3 = &self.mode_p3;
        let fresh_p4 = &self.fresh_p4;
        match &*p_p1.kind_p {
            crate::syntax::PatternKind::PName(n_p5) => {
                let nkey_p6 = crate::check::env::sname_key_f(n_p5);
                let (qk_o9, why_pa) = crate::check::env::names::resolve_value_f(&lx_p0.g_p, &lx_p0.home_p, n_p5);
                let is_ctor_p7 = match &qk_o9 {
                    ::std::option::Option::Some(qk_pb) => crate::check::env::has_key_f(&lx_p0.g_p.ctors_p, qk_pb) && ((crate::check::env::is_upper_text_f(&crate::lower::base_f(&nkey_p6)) || (&crate::prelude::len(&n_p5.path_p) > &crate::prelude::Nat::from(1u32))) || (is_unit_ctor_f(lx_p0, qk_pb) && !crate::check::env::has_key_f(&lx_p0.binders_p, &crate::lower::place_key_f(lx_p0, &n_p5.span_p)))),
                    ::std::option::Option::None => false,
                };
                let tagged_o8 = match &qk_o9 {
                    ::std::option::Option::Some(qk_pc) => crate::prelude::get(&lx_p0.g_p.tags_p, qk_pc),
                    ::std::option::Option::None => ::std::option::Option::None,
                };
                if is_ctor_p7 {
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(CtorPat { lx_p0: lx_p0.clone(), n_p1: n_p5.clone(), ps_p2: crate::prelude::Array::new(), ty_p3: ty_p2.clone(), mode_p4: mode_p3.clone(), fresh_p5: fresh_p4.clone() }))
                } else {
                    if (&why_pa == &crate::prelude::Text::lit("tag")) && (&tagged_o8 != &::std::option::Option::None) {
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(TagPat { lx_p0: lx_p0.clone(), tg_p1: crate::prelude::or(&tagged_o8, &dummy_tag_info_p()), fps_p2: crate::prelude::Array::new(), rest_p3: true, ty_p4: ty_p2.clone(), mode_p5: mode_p3.clone(), fresh_p6: fresh_p4.clone() }))
                    } else {
                        {
                            let lx_p0x = lx_p0.clone();
                            let mode_p3x = mode_p3.clone();
                            let n_p5x = n_p5.clone();
                            crate::prelude::call_then(crate::lower::start_local_name_at_f(lx_p0x.clone(), nkey_p6.clone(), n_p5x.span_p.clone()), move |local_name_at_f_2564: crate::prelude::Text| {
                                let rs_pd = local_name_at_f_2564;
                                let full_pe = crate::lower::binder_ty_f(&lx_p0x, &n_p5x.span_p);
                                crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0x.clone(), if lx_p0x.whole_p { full_pe.clone() } else { crate::lower::types::peel_f(&full_pe) }), move |out_ty_of_f_2927: crate::lower::model::OutTy| {
                                    let bt_pf = out_ty_of_f_2927;
                                    ::prism_rtl::Turn::Finished(PatOut { pa_p: crate::lower::model::Pa::PaBind(rs_pd.clone()), conds_p: crate::prelude::Array::new(), binds_p: crate::prelude::Array::from(vec![(nkey_p6.clone(), crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(rs_pd.clone()), mode_p3x.clone(), bt_pf.clone()))]) })
                                })
                            })
                        }
                    }
                }
            },
            crate::syntax::PatternKind::PIgnore => ::prism_rtl::Turn::Finished(pat_only_f(&crate::lower::model::Pa::PaWild)),
            crate::syntax::PatternKind::PUnit => ::prism_rtl::Turn::Finished(pat_only_f(&crate::lower::model::Pa::PaWild)),
            crate::syntax::PatternKind::PNil => ::prism_rtl::Turn::Finished(pat_only_f(&crate::lower::model::Pa::PaUnit(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::None"))))),
            crate::syntax::PatternKind::PLit(l_pg) => ::prism_rtl::Turn::More(::std::rc::Rc::new(LitPat { lx_p0: lx_p0.clone(), l_p1: l_pg.clone(), ty_p2: ty_p2.clone(), mode_p3: mode_p3.clone(), fresh_p4: fresh_p4.clone(), neg_p5: false })),
            crate::syntax::PatternKind::PNeg(l_ph) => ::prism_rtl::Turn::More(::std::rc::Rc::new(LitPat { lx_p0: lx_p0.clone(), l_p1: l_ph.clone(), ty_p2: ty_p2.clone(), mode_p3: mode_p3.clone(), fresh_p4: fresh_p4.clone(), neg_p5: true })),
            crate::syntax::PatternKind::PSigil(m1652_6_0, q_pi) if (m1652_6_0 == &crate::prelude::Text::lit("?")) => ::prism_rtl::Turn::More(::std::rc::Rc::new(WrapPat { lx_p0: lx_p0.clone(), ctor_p1: crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Some")), q_p2: (**q_pi).clone(), inner_p3: inner_ty_f(ty_p2), mode_p4: mode_p3.clone(), fresh_p5: fresh_p4.clone() })),
            crate::syntax::PatternKind::PSigil(m1652_7_0, q_pj) if (m1652_7_0 == &crate::prelude::Text::lit("~")) => ::prism_rtl::Turn::More(::std::rc::Rc::new(WrapPat { lx_p0: lx_p0.clone(), ctor_p1: crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Ok")), q_p2: (**q_pj).clone(), inner_p3: inner_ty_f(ty_p2), mode_p4: mode_p3.clone(), fresh_p5: fresh_p4.clone() })),
            crate::syntax::PatternKind::PSigil(_, q_pk) => ::prism_rtl::Turn::More(::std::rc::Rc::new(RustPat { lx_p0: lx_p0.clone(), p_p1: (**q_pk).clone(), ty_p2: ty_p2.clone(), mode_p3: mode_p3.clone(), fresh_p4: fresh_p4.clone() })),
            crate::syntax::PatternKind::PGroup(q_pl) => ::prism_rtl::Turn::More(::std::rc::Rc::new(RustPat { lx_p0: lx_p0.clone(), p_p1: (**q_pl).clone(), ty_p2: ty_p2.clone(), mode_p3: mode_p3.clone(), fresh_p4: fresh_p4.clone() })),
            crate::syntax::PatternKind::PCtor(n_pm, ps_pn) => ::prism_rtl::Turn::More(::std::rc::Rc::new(CtorPat { lx_p0: lx_p0.clone(), n_p1: n_pm.clone(), ps_p2: ps_pn.clone(), ty_p3: ty_p2.clone(), mode_p4: mode_p3.clone(), fresh_p5: fresh_p4.clone() })),
            crate::syntax::PatternKind::PRecord(n_po, fps_pp, rest_pq) => ::prism_rtl::Turn::More(::std::rc::Rc::new(RecordPat { lx_p0: lx_p0.clone(), n_p1: n_po.clone(), fps_p2: fps_pp.clone(), rest_p3: *rest_pq, ty_p4: ty_p2.clone(), mode_p5: mode_p3.clone(), fresh_p6: fresh_p4.clone() })),
            crate::syntax::PatternKind::PTuple(ps_pr) => {
                let ts_ps = match crate::lower::types::peel_f(ty_p2) {
                    crate::check::types::Ty::TyTuple(xs_pu) => xs_pu,
                    _ => crate::prelude::Array::new(),
                };
                let fresh_p4x = fresh_p4.clone();
                let lx_p0x = lx_p0.clone();
                let mode_p3x = mode_p3.clone();
                let ps_prx = ps_pr.clone();
                crate::prelude::call_value(crate::prelude::each_job(crate::check::errors::range0_f(&crate::prelude::len(&ps_prx)), {
                    let lx_p0xx = lx_p0x.clone();
                    let ps_prxx = ps_prx.clone();
                    let ts_psx = ts_ps.clone();
                    let mode_p3xx = mode_p3x.clone();
                    let fresh_p4xx = fresh_p4x.clone();
                    ::std::rc::Rc::new(move |p0: crate::prelude::Nat| {
                        let lx_p0xxy = lx_p0xx.clone();
                        let ps_prxxy = ps_prxx.clone();
                        let ts_psxy = ts_psx.clone();
                        let mode_p3xxy = mode_p3xx.clone();
                        let fresh_p4xxy = fresh_p4xx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let i_pv = p0;
                            ::prism_rtl::Turn::More(::std::rc::Rc::new(RustPat { lx_p0: lx_p0xxy.clone(), p_p1: crate::prelude::or(&crate::prelude::index(&ps_prxxy, &i_pv), &dummy_pat_p()), ty_p2: crate::prelude::or(&crate::prelude::index(&ts_psxy, &i_pv), &crate::check::types::Ty::TyErr), mode_p3: mode_p3xxy.clone(), fresh_p4: crate::prelude::Text::from(format!("{}_{}", &fresh_p4xxy, &i_pv)) }))
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<PatOut>>>
                }), move |each_3787: crate::prelude::Array<PatOut>| {
                    let subs_pt = each_3787;
                    ::prism_rtl::Turn::Finished(PatOut { pa_p: crate::lower::model::Pa::PaTuple(crate::prelude::each(&subs_pt, &(|o_p10: &PatOut| o_p10.pa_p.clone()))), conds_p: crate::prelude::fold(&subs_pt, &crate::prelude::Array::new(), &(|acc_p11: &crate::prelude::Array<crate::lower::model::Cc>, o_p12: &PatOut| crate::prelude::append(acc_p11, &o_p12.conds_p))), binds_p: crate::prelude::fold(&subs_pt, &crate::prelude::Array::new(), &(|acc_p13: &crate::prelude::Array<(crate::prelude::Text, crate::lower::types::Bn)>, o_p14: &PatOut| crate::prelude::append(acc_p13, &o_p14.binds_p))) })
                })
            },
            crate::syntax::PatternKind::PArray(ps_p15) => ::prism_rtl::Turn::More(::std::rc::Rc::new(ArrayPat { lx_p0: lx_p0.clone(), ps_p1: ps_p15.clone(), ty_p2: ty_p2.clone(), mode_p3: mode_p3.clone(), fresh_p4: fresh_p4.clone() })),
            crate::syntax::PatternKind::PFamily(q_p16) => ::prism_rtl::Turn::More(::std::rc::Rc::new(FamilyPat { lx_p0: lx_p0.clone(), q_p1: q_p16.clone(), ty_p2: ty_p2.clone(), fresh_p3: fresh_p4.clone() })),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start RustPat, x`: what the function value is when passed to `@Run`.
pub fn start_rust_pat_f(lx_p0: crate::lower::Lx, p_p1: crate::syntax::Pattern, ty_p2: crate::check::types::Ty, mode_p3: crate::lower::types::Holding, fresh_p4: crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<PatOut>> {
    ::std::rc::Rc::new(RustPat { lx_p0, p_p1, ty_p2, mode_p3, fresh_p4 })
}

/// ```prism
/// let dummyPat
/// ```
pub fn dummy_pat_p() -> crate::syntax::Pattern {
    crate::syntax::Pattern { kind_p: ::std::rc::Rc::new(crate::syntax::PatternKind::PIgnore), span_p: crate::syntax::Range { start_p: crate::prelude::Nat::from(0u32), end_p: crate::prelude::Nat::from(0u32) } }
}

/// ```prism
/// InnerTy: fn Ty -> Ty
/// ```
pub fn inner_ty_f(t_p0: &crate::check::types::Ty) -> crate::check::types::Ty {
    match crate::lower::types::peel_f(t_p0) {
        crate::check::types::Ty::TySig(m4246_0_0, i_p1) if (&m4246_0_0 == &crate::prelude::Text::lit("?")) => (*i_p1).clone(),
        crate::check::types::Ty::TySig(m4246_1_0, i_p2) if (&m4246_1_0 == &crate::prelude::Text::lit("~")) => (*i_p2).clone(),
        _ => crate::check::types::Ty::TyErr,
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// IsUnitCtor: fn Lx, Text -> Bool
/// ```
pub fn is_unit_ctor_f(lx_p0: &crate::lower::Lx, qk_p1: &crate::prelude::Text) -> bool {
    match crate::prelude::get(&lx_p0.g_p.ctors_p, qk_p1) {
        ::std::option::Option::Some(c_p2) => 'm4499: {
            let scrutinee = &crate::prelude::or(&crate::prelude::get(&lx_p0.g_p.types_p, &c_p2.owner_p), &crate::check::env::names::dummy_ty_info_p()).body_p;
            if let crate::check::env::TyBody::BChoice(m4499_0_0) = scrutinee && (m4499_0_0.len() == 1) && let ::std::option::Option::Some((_, m4499_0_0_0_1)) = crate::prelude::index(m4499_0_0, &crate::prelude::Nat::from(0u32)) && ((&m4499_0_0_0_1).len() == 0) {
                break 'm4499 crate::check::env::is_lower_text_f(&crate::check::types::bare_name_f(qk_p1));
            }
            false
        },
        ::std::option::Option::None => false,
    }
}

/// ```prism
/// WrapPat: unbounded fn Lx, Ref, Pattern, Ty, Holding, Text -> PatOut
/// ```
pub fn wrap_pat_f(lx_p0: &crate::lower::Lx, ctor_p1: &crate::lower::model::Ref, q_p2: &crate::syntax::Pattern, inner_p3: &crate::check::types::Ty, mode_p4: &crate::lower::types::Holding, fresh_p5: &crate::prelude::Text) -> PatOut {
    let o_p6 = rust_pat_f(lx_p0, q_p2, inner_p3, mode_p4, fresh_p5);
    let mut this: PatOut = o_p6.clone();
    this.pa_p = crate::lower::model::Pa::PaCtor(ctor_p1.clone(), crate::prelude::Array::from(vec![this.pa_p.clone()]));
    this
}

/// The step machine of `WrapPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// WrapPat: unbounded fn Lx, Ref, Pattern, Ty, Holding, Text -> PatOut
/// ```
pub struct WrapPat {
    pub lx_p0: crate::lower::Lx,
    pub ctor_p1: crate::lower::model::Ref,
    pub q_p2: crate::syntax::Pattern,
    pub inner_p3: crate::check::types::Ty,
    pub mode_p4: crate::lower::types::Holding,
    pub fresh_p5: crate::prelude::Text,
}

impl ::prism_rtl::Job<PatOut> for WrapPat {
    fn cycle(&self) -> ::prism_rtl::Turn<PatOut> {
        let lx_p0 = &self.lx_p0;
        let ctor_p1 = &self.ctor_p1;
        let q_p2 = &self.q_p2;
        let inner_p3 = &self.inner_p3;
        let mode_p4 = &self.mode_p4;
        let fresh_p5 = &self.fresh_p5;
        let ctor_p1x = ctor_p1.clone();
        let fresh_p5x = fresh_p5.clone();
        let inner_p3x = inner_p3.clone();
        let lx_p0x = lx_p0.clone();
        let mode_p4x = mode_p4.clone();
        let q_p2x = q_p2.clone();
        crate::prelude::call_then(start_rust_pat_f(lx_p0x.clone(), q_p2x.clone(), inner_p3x.clone(), mode_p4x.clone(), fresh_p5x.clone()), move |rust_pat_f_4778: PatOut| {
            let o_p6 = rust_pat_f_4778;
            ::prism_rtl::Turn::Finished({
                let mut this: PatOut = o_p6.clone();
                this.pa_p = crate::lower::model::Pa::PaCtor(ctor_p1x.clone(), crate::prelude::Array::from(vec![this.pa_p.clone()]));
                this
            })
        })
    }
}

/// `Start WrapPat, x`: what the function value is when passed to `@Run`.
pub fn start_wrap_pat_f(lx_p0: crate::lower::Lx, ctor_p1: crate::lower::model::Ref, q_p2: crate::syntax::Pattern, inner_p3: crate::check::types::Ty, mode_p4: crate::lower::types::Holding, fresh_p5: crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<PatOut>> {
    ::std::rc::Rc::new(WrapPat { lx_p0, ctor_p1, q_p2, inner_p3, mode_p4, fresh_p5 })
}

/// ```prism
/// LitPat: unbounded fn Lx, Literal, Ty, Holding, Text, Bool -> PatOut
/// ```
pub fn lit_pat_f(lx_p0: &crate::lower::Lx, l_p1: &crate::syntax::Literal, ty_p2: &crate::check::types::Ty, mode_p3: &crate::lower::types::Holding, fresh_p4: &crate::prelude::Text, neg_p5: &bool) -> PatOut {
    let t_p6 = crate::lower::types::out_ty_of_f(lx_p0, &crate::lower::types::peel_f(ty_p2));
    match &l_p1.kind_p {
        crate::syntax::LitKind::LChar(c_p7) => pat_only_f(&crate::lower::model::Pa::PaChar(c_p7.clone())),
        _ => {
            let lit_p8 = match &l_p1.kind_p {
                crate::syntax::LitKind::LInt(d_pb) => if (((&t_p6 == &crate::lower::model::OutTy::OutNat) || (&t_p6 == &crate::lower::model::OutTy::OutInt)) || (&t_p6 == &crate::lower::model::OutTy::OutU8)) || (&t_p6 == &crate::lower::model::OutTy::OutFloat) {
                    crate::lower::types::Vl::VlOwned(crate::lower::expr::number_f(&t_p6, d_pb, neg_p5), t_p6.clone())
                } else {
                    crate::lower::expr::literal_value_f(lx_p0, &crate::lower::types::empty_env_p(), l_p1, &l_p1.span_p, neg_p5)
                },
                _ => crate::lower::expr::literal_value_f(lx_p0, &crate::lower::types::empty_env_p(), l_p1, &l_p1.span_p, neg_p5),
            };
            let lv_p9 = crate::lower::types::Vl::VlOwned(crate::lower::types::own_f(&lit_p8), t_p6.clone());
            let b_pa = crate::lower::types::local_place_f(&crate::lower::model::Ex::XVar(fresh_p4.clone()), mode_p3, &t_p6);
            PatOut { pa_p: crate::lower::model::Pa::PaBind(fresh_p4.clone()), conds_p: crate::prelude::Array::from(vec![crate::lower::model::Cc::CcIf(crate::lower::model::Ex::XBin(crate::lower::model::BinOp::OpEq, ::std::rc::Rc::new(crate::lower::types::ref_f(&b_pa)), ::std::rc::Rc::new(crate::lower::types::ref_f(&lv_p9))))]), binds_p: crate::prelude::Array::new() }
        },
    }
}

/// The step machine of `LitPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LitPat: unbounded fn Lx, Literal, Ty, Holding, Text, Bool -> PatOut
/// ```
pub struct LitPat {
    pub lx_p0: crate::lower::Lx,
    pub l_p1: crate::syntax::Literal,
    pub ty_p2: crate::check::types::Ty,
    pub mode_p3: crate::lower::types::Holding,
    pub fresh_p4: crate::prelude::Text,
    pub neg_p5: bool,
}

impl ::prism_rtl::Job<PatOut> for LitPat {
    fn cycle(&self) -> ::prism_rtl::Turn<PatOut> {
        let lx_p0 = &self.lx_p0;
        let l_p1 = &self.l_p1;
        let ty_p2 = &self.ty_p2;
        let mode_p3 = &self.mode_p3;
        let fresh_p4 = &self.fresh_p4;
        let neg_p5 = &self.neg_p5;
        let fresh_p4x = fresh_p4.clone();
        let l_p1x = l_p1.clone();
        let lx_p0x = lx_p0.clone();
        let mode_p3x = mode_p3.clone();
        let neg_p5x = *neg_p5;
        let ty_p2x = ty_p2.clone();
        crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0x.clone(), crate::lower::types::peel_f(&ty_p2x)), move |out_ty_of_f_5090: crate::lower::model::OutTy| {
            let t_p6 = out_ty_of_f_5090;
            match &l_p1x.kind_p {
                crate::syntax::LitKind::LChar(c_p7) => ::prism_rtl::Turn::Finished(pat_only_f(&crate::lower::model::Pa::PaChar(c_p7.clone()))),
                _ => {
                    let fresh_p4xz = fresh_p4x.clone();
                    let mode_p3xz = mode_p3x.clone();
                    let t_p6z = t_p6.clone();
                    let k_let5348 = move |v5348: crate::lower::types::Vl| {
                        let lit_p8 = v5348;
                        let lv_p9 = crate::lower::types::Vl::VlOwned(crate::lower::types::own_f(&lit_p8), t_p6z.clone());
                        let b_pa = crate::lower::types::local_place_f(&crate::lower::model::Ex::XVar(fresh_p4xz.clone()), &mode_p3xz, &t_p6z);
                        ::prism_rtl::Turn::Finished(PatOut { pa_p: crate::lower::model::Pa::PaBind(fresh_p4xz.clone()), conds_p: crate::prelude::Array::from(vec![crate::lower::model::Cc::CcIf(crate::lower::model::Ex::XBin(crate::lower::model::BinOp::OpEq, ::std::rc::Rc::new(crate::lower::types::ref_f(&b_pa)), ::std::rc::Rc::new(crate::lower::types::ref_f(&lv_p9))))]), binds_p: crate::prelude::Array::new() })
                    };
                    match l_p1x.kind_p.clone() {
                        crate::syntax::LitKind::LInt(d_pb) => if (((&t_p6 == &crate::lower::model::OutTy::OutNat) || (&t_p6 == &crate::lower::model::OutTy::OutInt)) || (&t_p6 == &crate::lower::model::OutTy::OutU8)) || (&t_p6 == &crate::lower::model::OutTy::OutFloat) {
                            k_let5348(crate::lower::types::Vl::VlOwned(crate::lower::expr::number_f(&t_p6, &d_pb, &neg_p5x), t_p6.clone()))
                        } else {
                            crate::prelude::call_then(crate::lower::expr::start_literal_value_f(lx_p0x.clone(), crate::lower::types::empty_env_p(), l_p1x.clone(), l_p1x.span_p.clone(), neg_p5x), move |literal_value_f_5494: crate::lower::types::Vl| k_let5348(literal_value_f_5494))
                        },
                        _ => crate::prelude::call_then(crate::lower::expr::start_literal_value_f(lx_p0x.clone(), crate::lower::types::empty_env_p(), l_p1x.clone(), l_p1x.span_p.clone(), neg_p5x), move |literal_value_f_5563: crate::lower::types::Vl| k_let5348(literal_value_f_5563)),
                    }
                },
            }
        })
    }
}

/// `Start LitPat, x`: what the function value is when passed to `@Run`.
pub fn start_lit_pat_f(lx_p0: crate::lower::Lx, l_p1: crate::syntax::Literal, ty_p2: crate::check::types::Ty, mode_p3: crate::lower::types::Holding, fresh_p4: crate::prelude::Text, neg_p5: bool) -> ::std::rc::Rc<dyn ::prism_rtl::Job<PatOut>> {
    ::std::rc::Rc::new(LitPat { lx_p0, l_p1, ty_p2, mode_p3, fresh_p4, neg_p5 })
}

/// ```prism
/// CtorPat: unbounded fn Lx, SName, [Pattern], Ty, Holding, Text -> PatOut
/// ```
pub fn ctor_pat_f(lx_p0: &crate::lower::Lx, n_p1: &crate::syntax::SName, ps_p2: &crate::prelude::Array<crate::syntax::Pattern>, ty_p3: &crate::check::types::Ty, mode_p4: &crate::lower::types::Holding, fresh_p5: &crate::prelude::Text) -> PatOut {
    let (qk_o6, _) = crate::check::env::names::resolve_value_f(&lx_p0.g_p, &lx_p0.home_p, n_p1);
    match &qk_o6 {
        ::std::option::Option::Some(m6133_0) if (m6133_0 == &crate::prelude::Text::lit("True")) => pat_only_f(&crate::lower::model::Pa::PaBool(true)),
        ::std::option::Option::Some(m6133_1) if (m6133_1 == &crate::prelude::Text::lit("False")) => pat_only_f(&crate::lower::model::Pa::PaBool(false)),
        ::std::option::Option::Some(qk_p7) => match crate::prelude::get(&lx_p0.g_p.ctors_p, qk_p7) {
            ::std::option::Option::Some(c_p8) => {
                let owner_p9 = crate::prelude::or(&crate::prelude::get(&lx_p0.g_p.types_p, &c_p8.owner_p), &crate::check::env::names::dummy_ty_info_p());
                let ty_path_pa = crate::lower::ref_in_f(lx_p0, &owner_p9.home_p, &crate::lower::type_item_name_f(&c_p8.owner_p));
                let args_pb = match crate::lower::types::peel_f(ty_p3) {
                    crate::check::types::Ty::TyCon(_, xs_pg) => xs_pg,
                    _ => crate::prelude::Array::new(),
                };
                let subs_pc = crate::prelude::run_to_end(crate::prelude::each_job(crate::check::errors::range0_f(&crate::prelude::len(ps_p2)), {
                    let lx_p0x = lx_p0.clone();
                    let c_p8x = c_p8.clone();
                    let ps_p2x = ps_p2.clone();
                    let args_pbx = args_pb.clone();
                    let mode_p4x = mode_p4.clone();
                    let fresh_p5x = fresh_p5.clone();
                    ::std::rc::Rc::new(move |p0: crate::prelude::Nat| {
                        let lx_p0xy = lx_p0x.clone();
                        let c_p8xy = c_p8x.clone();
                        let ps_p2xy = ps_p2x.clone();
                        let args_pbxy = args_pbx.clone();
                        let mode_p4xy = mode_p4x.clone();
                        let fresh_p5xy = fresh_p5x.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let i_ph = p0;
                            crate::prelude::call_then(crate::lower::expr::start_instantiated_f(crate::prelude::or(&crate::prelude::index(&c_p8xy.args_p, &i_ph), &crate::check::types::Ty::TyErr), c_p8xy.params_p.clone(), args_pbxy.clone()), move |instantiated_f_6632: crate::check::types::Ty| ::prism_rtl::Turn::More(::std::rc::Rc::new(SubPat { lx_p0: lx_p0xy.clone(), c_p1: c_p8xy.clone(), i_p2: i_ph.clone(), p_p3: crate::prelude::or(&crate::prelude::index(&ps_p2xy, &i_ph), &dummy_pat_p()), ty_p4: instantiated_f_6632, mode_p5: mode_p4xy.clone(), fresh_p6: crate::prelude::Text::from(format!("{}_{}", &fresh_p5xy, &i_ph)) })))
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<PatOut>>>
                }));
                let conds_pd = crate::prelude::fold(&subs_pc, &crate::prelude::Array::new(), &(|acc_pi: &crate::prelude::Array<crate::lower::model::Cc>, o_pj: &PatOut| crate::prelude::append(acc_pi, &o_pj.conds_p)));
                let binds_pe = crate::prelude::fold(&subs_pc, &crate::prelude::Array::new(), &(|acc_pk: &crate::prelude::Array<(crate::prelude::Text, crate::lower::types::Bn)>, o_pl: &PatOut| crate::prelude::append(acc_pk, &o_pl.binds_p)));
                let pas_pf = crate::prelude::each(&subs_pc, &(|o_pm: &PatOut| o_pm.pa_p.clone()));
                match &owner_p9.body_p {
                    crate::check::env::TyBody::BRecord(fs_pn) => PatOut { pa_p: crate::lower::model::Pa::PaRecord(ty_path_pa.clone(), crate::prelude::run_to_end(crate::prelude::each_job(crate::check::errors::range0_f(&crate::prelude::len(&pas_pf)), {
                        let c_p8x = c_p8.clone();
                        let pas_pfx = pas_pf.clone();
                        ::std::rc::Rc::new(move |p0: crate::prelude::Nat| {
                            let c_p8xy = c_p8x.clone();
                            let pas_pfxy = pas_pfx.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let i_po = p0;
                                crate::prelude::call_then(crate::lower::start_field_spell_f(crate::lower::owner_of_f(&c_p8xy.owner_p), crate::prelude::or(&crate::prelude::index(&c_p8xy.fields_p, &i_po), &crate::prelude::Text::lit("")), crate::prelude::or(&crate::prelude::index(&c_p8xy.args_p, &i_po), &crate::check::types::Ty::TyErr)), move |field_spell_f_7030: crate::prelude::Text| ::prism_rtl::Turn::Finished((field_spell_f_7030, crate::prelude::or(&crate::prelude::index(&pas_pfxy, &i_po), &crate::lower::model::Pa::PaWild))))
                            }))
                        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Text, crate::lower::model::Pa)>>>
                    })), &crate::prelude::len(&pas_pf) < &crate::prelude::len(&c_p8.fields_p)), conds_p: conds_pd.clone(), binds_p: binds_pe.clone() },
                    _ => {
                        let is_unit_type_pp = (&crate::prelude::len(&c_p8.args_p) == &crate::prelude::Nat::from(0u32)) && is_unit_ctor_f(lx_p0, qk_p7);
                        let is_newtype_pq = ((&crate::prelude::len(&c_p8.args_p) > &crate::prelude::Nat::from(0u32)) && (&crate::check::types::bare_name_f(&c_p8.name_p) == &crate::check::types::bare_name_f(&c_p8.owner_p))) && match &owner_p9.body_p {
                            crate::check::env::TyBody::BChoice(cases_ps) => &crate::prelude::len(cases_ps) == &crate::prelude::Nat::from(1u32),
                            _ => false,
                        };
                        let path_pr = if is_unit_type_pp || is_newtype_pq {
                            ty_path_pa.clone()
                        } else {
                            crate::lower::model::ref_child_f(&ty_path_pa, &crate::lower::camel_f(&crate::check::types::bare_name_f(&c_p8.name_p)))
                        };
                        if &crate::prelude::len(&c_p8.args_p) == &crate::prelude::Nat::from(0u32) {
                            PatOut { pa_p: crate::lower::model::Pa::PaUnit(path_pr.clone()), conds_p: crate::prelude::Array::new(), binds_p: crate::prelude::Array::new() }
                        } else {
                            PatOut { pa_p: crate::lower::model::Pa::PaCtor(path_pr.clone(), pas_pf.clone()), conds_p: conds_pd.clone(), binds_p: binds_pe.clone() }
                        }
                    },
                }
            },
            ::std::option::Option::None => PatOut { pa_p: crate::lower::model::Pa::PaWild, conds_p: crate::prelude::Array::from(vec![crate::lower::model::Cc::CcIf(crate::lower::expr::internal_bug_f(&crate::prelude::Text::from(format!("a pattern of {}", qk_p7))))]), binds_p: crate::prelude::Array::new() },
        },
        ::std::option::Option::None => PatOut { pa_p: crate::lower::model::Pa::PaWild, conds_p: crate::prelude::Array::from(vec![crate::lower::model::Cc::CcIf(crate::lower::expr::internal_bug_f(&crate::prelude::Text::lit("a pattern of an unknown constructor")))]), binds_p: crate::prelude::Array::new() },
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `CtorPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CtorPat: unbounded fn Lx, SName, [Pattern], Ty, Holding, Text -> PatOut
/// ```
pub struct CtorPat {
    pub lx_p0: crate::lower::Lx,
    pub n_p1: crate::syntax::SName,
    pub ps_p2: crate::prelude::Array<crate::syntax::Pattern>,
    pub ty_p3: crate::check::types::Ty,
    pub mode_p4: crate::lower::types::Holding,
    pub fresh_p5: crate::prelude::Text,
}

impl ::prism_rtl::Job<PatOut> for CtorPat {
    fn cycle(&self) -> ::prism_rtl::Turn<PatOut> {
        let lx_p0 = &self.lx_p0;
        let n_p1 = &self.n_p1;
        let ps_p2 = &self.ps_p2;
        let ty_p3 = &self.ty_p3;
        let mode_p4 = &self.mode_p4;
        let fresh_p5 = &self.fresh_p5;
        let (qk_o6, _) = crate::check::env::names::resolve_value_f(&lx_p0.g_p, &lx_p0.home_p, n_p1);
        match &qk_o6 {
            ::std::option::Option::Some(m6133_0) if (m6133_0 == &crate::prelude::Text::lit("True")) => ::prism_rtl::Turn::Finished(pat_only_f(&crate::lower::model::Pa::PaBool(true))),
            ::std::option::Option::Some(m6133_1) if (m6133_1 == &crate::prelude::Text::lit("False")) => ::prism_rtl::Turn::Finished(pat_only_f(&crate::lower::model::Pa::PaBool(false))),
            ::std::option::Option::Some(qk_p7) => match crate::prelude::get(&lx_p0.g_p.ctors_p, qk_p7) {
                ::std::option::Option::Some(c_p8) => {
                    let owner_p9 = crate::prelude::or(&crate::prelude::get(&lx_p0.g_p.types_p, &c_p8.owner_p), &crate::check::env::names::dummy_ty_info_p());
                    let ty_path_pa = crate::lower::ref_in_f(lx_p0, &owner_p9.home_p, &crate::lower::type_item_name_f(&c_p8.owner_p));
                    let args_pb = match crate::lower::types::peel_f(ty_p3) {
                        crate::check::types::Ty::TyCon(_, xs_pg) => xs_pg,
                        _ => crate::prelude::Array::new(),
                    };
                    let fresh_p5x = fresh_p5.clone();
                    let lx_p0x = lx_p0.clone();
                    let mode_p4x = mode_p4.clone();
                    let ps_p2x = ps_p2.clone();
                    let qk_p7x = qk_p7.clone();
                    crate::prelude::call_value(crate::prelude::each_job(crate::check::errors::range0_f(&crate::prelude::len(&ps_p2x)), {
                        let lx_p0xx = lx_p0x.clone();
                        let c_p8x = c_p8.clone();
                        let ps_p2xx = ps_p2x.clone();
                        let args_pbx = args_pb.clone();
                        let mode_p4xx = mode_p4x.clone();
                        let fresh_p5xx = fresh_p5x.clone();
                        ::std::rc::Rc::new(move |p0: crate::prelude::Nat| {
                            let lx_p0xxy = lx_p0xx.clone();
                            let c_p8xy = c_p8x.clone();
                            let ps_p2xxy = ps_p2xx.clone();
                            let args_pbxy = args_pbx.clone();
                            let mode_p4xxy = mode_p4xx.clone();
                            let fresh_p5xxy = fresh_p5xx.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let i_ph = p0;
                                crate::prelude::call_then(crate::lower::expr::start_instantiated_f(crate::prelude::or(&crate::prelude::index(&c_p8xy.args_p, &i_ph), &crate::check::types::Ty::TyErr), c_p8xy.params_p.clone(), args_pbxy.clone()), move |instantiated_f_6632: crate::check::types::Ty| ::prism_rtl::Turn::More(::std::rc::Rc::new(SubPat { lx_p0: lx_p0xxy.clone(), c_p1: c_p8xy.clone(), i_p2: i_ph.clone(), p_p3: crate::prelude::or(&crate::prelude::index(&ps_p2xxy, &i_ph), &dummy_pat_p()), ty_p4: instantiated_f_6632, mode_p5: mode_p4xxy.clone(), fresh_p6: crate::prelude::Text::from(format!("{}_{}", &fresh_p5xxy, &i_ph)) })))
                            }))
                        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<PatOut>>>
                    }), move |each_6563: crate::prelude::Array<PatOut>| {
                        let subs_pc = each_6563;
                        let conds_pd = crate::prelude::fold(&subs_pc, &crate::prelude::Array::new(), &(|acc_pi: &crate::prelude::Array<crate::lower::model::Cc>, o_pj: &PatOut| crate::prelude::append(acc_pi, &o_pj.conds_p)));
                        let binds_pe = crate::prelude::fold(&subs_pc, &crate::prelude::Array::new(), &(|acc_pk: &crate::prelude::Array<(crate::prelude::Text, crate::lower::types::Bn)>, o_pl: &PatOut| crate::prelude::append(acc_pk, &o_pl.binds_p)));
                        let pas_pf = crate::prelude::each(&subs_pc, &(|o_pm: &PatOut| o_pm.pa_p.clone()));
                        match &owner_p9.body_p {
                            crate::check::env::TyBody::BRecord(fs_pn) => crate::prelude::call_value(crate::prelude::each_job(crate::check::errors::range0_f(&crate::prelude::len(&pas_pf)), {
                                let c_p8x = c_p8.clone();
                                let pas_pfx = pas_pf.clone();
                                ::std::rc::Rc::new(move |p0: crate::prelude::Nat| {
                                    let c_p8xy = c_p8x.clone();
                                    let pas_pfxy = pas_pfx.clone();
                                    crate::prelude::entered(crate::prelude::once_job(move || {
                                        let i_po = p0;
                                        crate::prelude::call_then(crate::lower::start_field_spell_f(crate::lower::owner_of_f(&c_p8xy.owner_p), crate::prelude::or(&crate::prelude::index(&c_p8xy.fields_p, &i_po), &crate::prelude::Text::lit("")), crate::prelude::or(&crate::prelude::index(&c_p8xy.args_p, &i_po), &crate::check::types::Ty::TyErr)), move |field_spell_f_7030: crate::prelude::Text| ::prism_rtl::Turn::Finished((field_spell_f_7030, crate::prelude::or(&crate::prelude::index(&pas_pfxy, &i_po), &crate::lower::model::Pa::PaWild))))
                                    }))
                                }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Text, crate::lower::model::Pa)>>>
                            }), move |each_6997: crate::prelude::Array<(crate::prelude::Text, crate::lower::model::Pa)>| ::prism_rtl::Turn::Finished(PatOut { pa_p: crate::lower::model::Pa::PaRecord(ty_path_pa.clone(), each_6997, &crate::prelude::len(&pas_pf) < &crate::prelude::len(&c_p8.fields_p)), conds_p: conds_pd.clone(), binds_p: binds_pe.clone() })),
                            _ => {
                                let is_unit_type_pp = (&crate::prelude::len(&c_p8.args_p) == &crate::prelude::Nat::from(0u32)) && is_unit_ctor_f(&lx_p0x, &qk_p7x);
                                let is_newtype_pq = ((&crate::prelude::len(&c_p8.args_p) > &crate::prelude::Nat::from(0u32)) && (&crate::check::types::bare_name_f(&c_p8.name_p) == &crate::check::types::bare_name_f(&c_p8.owner_p))) && match &owner_p9.body_p {
                                    crate::check::env::TyBody::BChoice(cases_ps) => &crate::prelude::len(cases_ps) == &crate::prelude::Nat::from(1u32),
                                    _ => false,
                                };
                                let path_pr = if is_unit_type_pp || is_newtype_pq {
                                    ty_path_pa.clone()
                                } else {
                                    crate::lower::model::ref_child_f(&ty_path_pa, &crate::lower::camel_f(&crate::check::types::bare_name_f(&c_p8.name_p)))
                                };
                                if &crate::prelude::len(&c_p8.args_p) == &crate::prelude::Nat::from(0u32) {
                                    ::prism_rtl::Turn::Finished(PatOut { pa_p: crate::lower::model::Pa::PaUnit(path_pr.clone()), conds_p: crate::prelude::Array::new(), binds_p: crate::prelude::Array::new() })
                                } else {
                                    ::prism_rtl::Turn::Finished(PatOut { pa_p: crate::lower::model::Pa::PaCtor(path_pr.clone(), pas_pf.clone()), conds_p: conds_pd.clone(), binds_p: binds_pe.clone() })
                                }
                            },
                        }
                    })
                },
                ::std::option::Option::None => ::prism_rtl::Turn::Finished(PatOut { pa_p: crate::lower::model::Pa::PaWild, conds_p: crate::prelude::Array::from(vec![crate::lower::model::Cc::CcIf(crate::lower::expr::internal_bug_f(&crate::prelude::Text::from(format!("a pattern of {}", qk_p7))))]), binds_p: crate::prelude::Array::new() }),
            },
            ::std::option::Option::None => ::prism_rtl::Turn::Finished(PatOut { pa_p: crate::lower::model::Pa::PaWild, conds_p: crate::prelude::Array::from(vec![crate::lower::model::Cc::CcIf(crate::lower::expr::internal_bug_f(&crate::prelude::Text::lit("a pattern of an unknown constructor")))]), binds_p: crate::prelude::Array::new() }),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start CtorPat, x`: what the function value is when passed to `@Run`.
pub fn start_ctor_pat_f(lx_p0: crate::lower::Lx, n_p1: crate::syntax::SName, ps_p2: crate::prelude::Array<crate::syntax::Pattern>, ty_p3: crate::check::types::Ty, mode_p4: crate::lower::types::Holding, fresh_p5: crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<PatOut>> {
    ::std::rc::Rc::new(CtorPat { lx_p0, n_p1, ps_p2, ty_p3, mode_p4, fresh_p5 })
}

/// ```prism
/// SubPat: unbounded fn Lx, CtorInfo, Nat, Pattern, Ty, Holding, Text -> PatOut
/// ```
pub fn sub_pat_f(lx_p0: &crate::lower::Lx, c_p1: &crate::check::env::CtorInfo, i_p2: &crate::prelude::Nat, p_p3: &crate::syntax::Pattern, ty_p4: &crate::check::types::Ty, mode_p5: &crate::lower::types::Holding, fresh_p6: &crate::prelude::Text) -> PatOut {
    if !crate::lower::types::rc_field_f(lx_p0, &c_p1.name_p, i_p2) {
        rust_pat_f(lx_p0, p_p3, ty_p4, mode_p5, fresh_p6)
    } else {
        {
            let rc_mode_p7 = if mode_p5 == &crate::lower::types::Holding::Owned {
                crate::lower::types::Holding::RcOwned
            } else {
                crate::lower::types::Holding::RcRef
            };
            match &*p_p3.kind_p {
                crate::syntax::PatternKind::PIgnore => pat_only_f(&crate::lower::model::Pa::PaWild),
                crate::syntax::PatternKind::PName(n_p8) => {
                    let o_p9 = rust_pat_f(lx_p0, p_p3, ty_p4, &rc_mode_p7, fresh_p6);
                    match &o_p9.pa_p {
                        crate::lower::model::Pa::PaBind(_) => o_p9.clone(),
                        _ => behind_rc_f(lx_p0, p_p3, ty_p4, &rc_mode_p7, fresh_p6),
                    }
                },
                _ => behind_rc_f(lx_p0, p_p3, ty_p4, &rc_mode_p7, fresh_p6),
            }
        }
    }
}

/// The step machine of `SubPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SubPat: unbounded fn Lx, CtorInfo, Nat, Pattern, Ty, Holding, Text -> PatOut
/// ```
pub struct SubPat {
    pub lx_p0: crate::lower::Lx,
    pub c_p1: crate::check::env::CtorInfo,
    pub i_p2: crate::prelude::Nat,
    pub p_p3: crate::syntax::Pattern,
    pub ty_p4: crate::check::types::Ty,
    pub mode_p5: crate::lower::types::Holding,
    pub fresh_p6: crate::prelude::Text,
}

impl ::prism_rtl::Job<PatOut> for SubPat {
    fn cycle(&self) -> ::prism_rtl::Turn<PatOut> {
        let lx_p0 = &self.lx_p0;
        let c_p1 = &self.c_p1;
        let i_p2 = &self.i_p2;
        let p_p3 = &self.p_p3;
        let ty_p4 = &self.ty_p4;
        let mode_p5 = &self.mode_p5;
        let fresh_p6 = &self.fresh_p6;
        if !crate::lower::types::rc_field_f(lx_p0, &c_p1.name_p, i_p2) {
            ::prism_rtl::Turn::More(::std::rc::Rc::new(RustPat { lx_p0: lx_p0.clone(), p_p1: p_p3.clone(), ty_p2: ty_p4.clone(), mode_p3: mode_p5.clone(), fresh_p4: fresh_p6.clone() }))
        } else {
            {
                let rc_mode_p7 = if mode_p5 == &crate::lower::types::Holding::Owned {
                    crate::lower::types::Holding::RcOwned
                } else {
                    crate::lower::types::Holding::RcRef
                };
                match &*p_p3.kind_p {
                    crate::syntax::PatternKind::PIgnore => ::prism_rtl::Turn::Finished(pat_only_f(&crate::lower::model::Pa::PaWild)),
                    crate::syntax::PatternKind::PName(n_p8) => {
                        let fresh_p6x = fresh_p6.clone();
                        let lx_p0x = lx_p0.clone();
                        let p_p3x = p_p3.clone();
                        let ty_p4x = ty_p4.clone();
                        crate::prelude::call_then(start_rust_pat_f(lx_p0x.clone(), p_p3x.clone(), ty_p4x.clone(), rc_mode_p7.clone(), fresh_p6x.clone()), move |rust_pat_f_8784: PatOut| {
                            let o_p9 = rust_pat_f_8784;
                            match &o_p9.pa_p {
                                crate::lower::model::Pa::PaBind(_) => ::prism_rtl::Turn::Finished(o_p9.clone()),
                                _ => ::prism_rtl::Turn::More(::std::rc::Rc::new(BehindRc { lx_p0: lx_p0x.clone(), p_p1: p_p3x.clone(), ty_p2: ty_p4x.clone(), rc_mode_p3: rc_mode_p7.clone(), fresh_p4: fresh_p6x.clone() })),
                            }
                        })
                    },
                    _ => ::prism_rtl::Turn::More(::std::rc::Rc::new(BehindRc { lx_p0: lx_p0.clone(), p_p1: p_p3.clone(), ty_p2: ty_p4.clone(), rc_mode_p3: rc_mode_p7.clone(), fresh_p4: fresh_p6.clone() })),
                }
            }
        }
    }
}

/// `Start SubPat, x`: what the function value is when passed to `@Run`.
pub fn start_sub_pat_f(lx_p0: crate::lower::Lx, c_p1: crate::check::env::CtorInfo, i_p2: crate::prelude::Nat, p_p3: crate::syntax::Pattern, ty_p4: crate::check::types::Ty, mode_p5: crate::lower::types::Holding, fresh_p6: crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<PatOut>> {
    ::std::rc::Rc::new(SubPat { lx_p0, c_p1, i_p2, p_p3, ty_p4, mode_p5, fresh_p6 })
}

/// ```prism
/// BehindRc: unbounded fn Lx, Pattern, Ty, Holding, Text -> PatOut
/// ```
pub fn behind_rc_f(lx_p0: &crate::lower::Lx, p_p1: &crate::syntax::Pattern, ty_p2: &crate::check::types::Ty, rc_mode_p3: &crate::lower::types::Holding, fresh_p4: &crate::prelude::Text) -> PatOut {
    let inner_p5 = rust_pat_f(lx_p0, p_p1, ty_p2, &crate::lower::types::Holding::ByRef, &crate::prelude::Text::from(format!("{}_r", fresh_p4)));
    let place_p6 = crate::lower::types::ref_f(&crate::lower::types::local_place_f(&crate::lower::model::Ex::XVar(fresh_p4.clone()), rc_mode_p3, &crate::lower::expr::internal_bug_type_f(&crate::prelude::Text::lit("a payload"))));
    PatOut { pa_p: crate::lower::model::Pa::PaBind(fresh_p4.clone()), conds_p: crate::prelude::append(&crate::prelude::Array::from(vec![crate::lower::model::Cc::CcLet(inner_p5.pa_p.clone(), place_p6.clone())]), &inner_p5.conds_p), binds_p: inner_p5.binds_p.clone() }
}

/// The step machine of `BehindRc`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BehindRc: unbounded fn Lx, Pattern, Ty, Holding, Text -> PatOut
/// ```
pub struct BehindRc {
    pub lx_p0: crate::lower::Lx,
    pub p_p1: crate::syntax::Pattern,
    pub ty_p2: crate::check::types::Ty,
    pub rc_mode_p3: crate::lower::types::Holding,
    pub fresh_p4: crate::prelude::Text,
}

impl ::prism_rtl::Job<PatOut> for BehindRc {
    fn cycle(&self) -> ::prism_rtl::Turn<PatOut> {
        let lx_p0 = &self.lx_p0;
        let p_p1 = &self.p_p1;
        let ty_p2 = &self.ty_p2;
        let rc_mode_p3 = &self.rc_mode_p3;
        let fresh_p4 = &self.fresh_p4;
        let fresh_p4x = fresh_p4.clone();
        let lx_p0x = lx_p0.clone();
        let p_p1x = p_p1.clone();
        let rc_mode_p3x = rc_mode_p3.clone();
        let ty_p2x = ty_p2.clone();
        crate::prelude::call_then(start_rust_pat_f(lx_p0x.clone(), p_p1x.clone(), ty_p2x.clone(), crate::lower::types::Holding::ByRef, crate::prelude::Text::from(format!("{}_r", &fresh_p4x))), move |rust_pat_f_9123: PatOut| {
            let inner_p5 = rust_pat_f_9123;
            let place_p6 = crate::lower::types::ref_f(&crate::lower::types::local_place_f(&crate::lower::model::Ex::XVar(fresh_p4x.clone()), &rc_mode_p3x, &crate::lower::expr::internal_bug_type_f(&crate::prelude::Text::lit("a payload"))));
            ::prism_rtl::Turn::Finished(PatOut { pa_p: crate::lower::model::Pa::PaBind(fresh_p4x.clone()), conds_p: crate::prelude::append(&crate::prelude::Array::from(vec![crate::lower::model::Cc::CcLet(inner_p5.pa_p.clone(), place_p6.clone())]), &inner_p5.conds_p), binds_p: inner_p5.binds_p.clone() })
        })
    }
}

/// `Start BehindRc, x`: what the function value is when passed to `@Run`.
pub fn start_behind_rc_f(lx_p0: crate::lower::Lx, p_p1: crate::syntax::Pattern, ty_p2: crate::check::types::Ty, rc_mode_p3: crate::lower::types::Holding, fresh_p4: crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<PatOut>> {
    ::std::rc::Rc::new(BehindRc { lx_p0, p_p1, ty_p2, rc_mode_p3, fresh_p4 })
}

/// ```prism
/// RecordPat: unbounded fn Lx, SName, [FieldPat], Bool, Ty, Holding, Text -> PatOut
/// ```
pub fn record_pat_f(lx_p0: &crate::lower::Lx, n_p1: &crate::syntax::SName, fps_p2: &crate::prelude::Array<crate::syntax::FieldPat>, rest_p3: &bool, ty_p4: &crate::check::types::Ty, mode_p5: &crate::lower::types::Holding, fresh_p6: &crate::prelude::Text) -> PatOut {
    let (qk_o8, why_p9) = crate::check::env::names::resolve_value_f(&lx_p0.g_p, &lx_p0.home_p, n_p1);
    let qk_p7 = crate::prelude::or(&qk_o8, &crate::prelude::Text::lit(""));
    if &qk_p7 == &crate::prelude::Text::lit("Prelude.Error") {
        error_pat_f(lx_p0, fps_p2, ty_p4, mode_p5, fresh_p6)
    } else {
        if (&why_p9 == &crate::prelude::Text::lit("tag")) && crate::check::env::has_key_f(&lx_p0.g_p.tags_p, &qk_p7) {
            tag_pat_f(lx_p0, &crate::prelude::or(&crate::prelude::get(&lx_p0.g_p.tags_p, &qk_p7), &dummy_tag_info_p()), fps_p2, rest_p3, ty_p4, mode_p5, fresh_p6)
        } else {
            match crate::prelude::get(&lx_p0.g_p.ctors_p, &qk_p7) {
                ::std::option::Option::Some(c_pa) => {
                    let owner_pb = crate::prelude::or(&crate::prelude::get(&lx_p0.g_p.types_p, &c_pa.owner_p), &crate::check::env::names::dummy_ty_info_p());
                    let ty_path_pc = crate::lower::ref_in_f(lx_p0, &owner_pb.home_p, &crate::lower::type_item_name_f(&c_pa.owner_p));
                    match &owner_pb.body_p {
                        crate::check::env::TyBody::BChoice(cases_pd) if (&crate::prelude::len(fps_p2) == &crate::prelude::Nat::from(0u32)) => rest_case_pat_f(&c_pa, cases_pd, &ty_path_pc),
                        _ => fields_pat_f(lx_p0, &c_pa, fps_p2, rest_p3, ty_p4, mode_p5, fresh_p6, &ty_path_pc),
                        _ => unreachable!("no arm matched"),
                    }
                },
                ::std::option::Option::None => match crate::prelude::get(&lx_p0.g_p.tags_p, &qk_p7) {
                    ::std::option::Option::Some(tg_pe) => tag_pat_f(lx_p0, &tg_pe, fps_p2, rest_p3, ty_p4, mode_p5, fresh_p6),
                    ::std::option::Option::None => PatOut { pa_p: crate::lower::model::Pa::PaWild, conds_p: crate::prelude::Array::from(vec![crate::lower::model::Cc::CcIf(crate::lower::expr::internal_bug_f(&crate::prelude::Text::from(format!("a pattern of {}", &qk_p7))))]), binds_p: crate::prelude::Array::new() },
                },
            }
        }
    }
}

/// The step machine of `RecordPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RecordPat: unbounded fn Lx, SName, [FieldPat], Bool, Ty, Holding, Text -> PatOut
/// ```
pub struct RecordPat {
    pub lx_p0: crate::lower::Lx,
    pub n_p1: crate::syntax::SName,
    pub fps_p2: crate::prelude::Array<crate::syntax::FieldPat>,
    pub rest_p3: bool,
    pub ty_p4: crate::check::types::Ty,
    pub mode_p5: crate::lower::types::Holding,
    pub fresh_p6: crate::prelude::Text,
}

impl ::prism_rtl::Job<PatOut> for RecordPat {
    fn cycle(&self) -> ::prism_rtl::Turn<PatOut> {
        let lx_p0 = &self.lx_p0;
        let n_p1 = &self.n_p1;
        let fps_p2 = &self.fps_p2;
        let rest_p3 = &self.rest_p3;
        let ty_p4 = &self.ty_p4;
        let mode_p5 = &self.mode_p5;
        let fresh_p6 = &self.fresh_p6;
        let (qk_o8, why_p9) = crate::check::env::names::resolve_value_f(&lx_p0.g_p, &lx_p0.home_p, n_p1);
        let qk_p7 = crate::prelude::or(&qk_o8, &crate::prelude::Text::lit(""));
        if &qk_p7 == &crate::prelude::Text::lit("Prelude.Error") {
            ::prism_rtl::Turn::More(::std::rc::Rc::new(ErrorPat { lx_p0: lx_p0.clone(), fps_p1: fps_p2.clone(), ty_p2: ty_p4.clone(), mode_p3: mode_p5.clone(), fresh_p4: fresh_p6.clone() }))
        } else {
            if (&why_p9 == &crate::prelude::Text::lit("tag")) && crate::check::env::has_key_f(&lx_p0.g_p.tags_p, &qk_p7) {
                ::prism_rtl::Turn::More(::std::rc::Rc::new(TagPat { lx_p0: lx_p0.clone(), tg_p1: crate::prelude::or(&crate::prelude::get(&lx_p0.g_p.tags_p, &qk_p7), &dummy_tag_info_p()), fps_p2: fps_p2.clone(), rest_p3: *rest_p3, ty_p4: ty_p4.clone(), mode_p5: mode_p5.clone(), fresh_p6: fresh_p6.clone() }))
            } else {
                match crate::prelude::get(&lx_p0.g_p.ctors_p, &qk_p7) {
                    ::std::option::Option::Some(c_pa) => {
                        let owner_pb = crate::prelude::or(&crate::prelude::get(&lx_p0.g_p.types_p, &c_pa.owner_p), &crate::check::env::names::dummy_ty_info_p());
                        let ty_path_pc = crate::lower::ref_in_f(lx_p0, &owner_pb.home_p, &crate::lower::type_item_name_f(&c_pa.owner_p));
                        match &owner_pb.body_p {
                            crate::check::env::TyBody::BChoice(cases_pd) if (&crate::prelude::len(fps_p2) == &crate::prelude::Nat::from(0u32)) => ::prism_rtl::Turn::Finished(rest_case_pat_f(&c_pa, cases_pd, &ty_path_pc)),
                            _ => ::prism_rtl::Turn::More(::std::rc::Rc::new(FieldsPat { lx_p0: lx_p0.clone(), c_p1: c_pa.clone(), fps_p2: fps_p2.clone(), rest_p3: *rest_p3, ty_p4: ty_p4.clone(), mode_p5: mode_p5.clone(), fresh_p6: fresh_p6.clone(), ty_path_p7: ty_path_pc.clone() })),
                            _ => unreachable!("no arm matched"),
                        }
                    },
                    ::std::option::Option::None => match crate::prelude::get(&lx_p0.g_p.tags_p, &qk_p7) {
                        ::std::option::Option::Some(tg_pe) => ::prism_rtl::Turn::More(::std::rc::Rc::new(TagPat { lx_p0: lx_p0.clone(), tg_p1: tg_pe.clone(), fps_p2: fps_p2.clone(), rest_p3: *rest_p3, ty_p4: ty_p4.clone(), mode_p5: mode_p5.clone(), fresh_p6: fresh_p6.clone() })),
                        ::std::option::Option::None => ::prism_rtl::Turn::Finished(PatOut { pa_p: crate::lower::model::Pa::PaWild, conds_p: crate::prelude::Array::from(vec![crate::lower::model::Cc::CcIf(crate::lower::expr::internal_bug_f(&crate::prelude::Text::from(format!("a pattern of {}", &qk_p7))))]), binds_p: crate::prelude::Array::new() }),
                    },
                }
            }
        }
    }
}

/// `Start RecordPat, x`: what the function value is when passed to `@Run`.
pub fn start_record_pat_f(lx_p0: crate::lower::Lx, n_p1: crate::syntax::SName, fps_p2: crate::prelude::Array<crate::syntax::FieldPat>, rest_p3: bool, ty_p4: crate::check::types::Ty, mode_p5: crate::lower::types::Holding, fresh_p6: crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<PatOut>> {
    ::std::rc::Rc::new(RecordPat { lx_p0, n_p1, fps_p2, rest_p3, ty_p4, mode_p5, fresh_p6 })
}

/// ```prism
/// RestCasePat: fn CtorInfo, [((Text, [Ty]))], Ref -> PatOut
/// ```
pub fn rest_case_pat_f(c_p0: &crate::check::env::CtorInfo, cases_p1: &crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<crate::check::types::Ty>)>, ty_path_p2: &crate::lower::model::Ref) -> PatOut {
    let is_newtype_p3 = ((&crate::prelude::len(cases_p1) == &crate::prelude::Nat::from(1u32)) && (&crate::check::types::bare_name_f(&c_p0.name_p) == &crate::check::types::bare_name_f(&c_p0.owner_p))) && (&crate::prelude::len(&c_p0.args_p) > &crate::prelude::Nat::from(0u32));
    let path_p4 = if is_newtype_p3 {
        ty_path_p2.clone()
    } else {
        crate::lower::model::ref_child_f(ty_path_p2, &crate::lower::camel_f(&crate::check::types::bare_name_f(&c_p0.name_p)))
    };
    if &crate::prelude::len(&c_p0.args_p) == &crate::prelude::Nat::from(0u32) {
        PatOut { pa_p: crate::lower::model::Pa::PaUnit(path_p4.clone()), conds_p: crate::prelude::Array::new(), binds_p: crate::prelude::Array::new() }
    } else {
        PatOut { pa_p: crate::lower::model::Pa::PaCtor(path_p4.clone(), crate::prelude::each(&c_p0.args_p, &(|_: &crate::check::types::Ty| crate::lower::model::Pa::PaWild))), conds_p: crate::prelude::Array::new(), binds_p: crate::prelude::Array::new() }
    }
}

/// ```prism
/// FieldsPat: unbounded fn Lx, CtorInfo, [FieldPat], Bool, Ty, Holding, Text, Ref -> PatOut
/// ```
pub fn fields_pat_f(lx_p0: &crate::lower::Lx, c_p1: &crate::check::env::CtorInfo, fps_p2: &crate::prelude::Array<crate::syntax::FieldPat>, rest_p3: &bool, ty_p4: &crate::check::types::Ty, mode_p5: &crate::lower::types::Holding, fresh_p6: &crate::prelude::Text, ty_path_p7: &crate::lower::model::Ref) -> PatOut {
    let args_p8 = match crate::lower::types::peel_f(ty_p4) {
        crate::check::types::Ty::TyCon(_, xs_pc) => xs_pc,
        _ => crate::prelude::Array::new(),
    };
    let subs_p9 = crate::prelude::run_to_end(crate::prelude::each_job(crate::check::errors::range0_f(&crate::prelude::len(fps_p2)), {
        let fps_p2x = fps_p2.clone();
        let c_p1x = c_p1.clone();
        let lx_p0x = lx_p0.clone();
        let args_p8x = args_p8.clone();
        let mode_p5x = mode_p5.clone();
        let fresh_p6x = fresh_p6.clone();
        ::std::rc::Rc::new(move |p0: crate::prelude::Nat| {
            let fps_p2xy = fps_p2x.clone();
            let c_p1xy = c_p1x.clone();
            let lx_p0xy = lx_p0x.clone();
            let args_p8xy = args_p8x.clone();
            let mode_p5xy = mode_p5x.clone();
            let fresh_p6xy = fresh_p6x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let i_pd = p0;
                {
                    let fp_pe = crate::prelude::or(&crate::prelude::index(&fps_p2xy, &i_pd), &dummy_field_pat_p());
                    let fname_pf = match &fp_pe.name_o {
                        ::std::option::Option::Some(id_ph) => id_ph.name_p.clone(),
                        ::std::option::Option::None => crate::prelude::or(&crate::prelude::index(&c_p1xy.fields_p, &i_pd), &crate::prelude::Text::lit("")),
                    };
                    let fix_pg = crate::prelude::fold(&crate::check::errors::range0_f(&crate::prelude::len(&c_p1xy.fields_p)), &i_pd, &(|found_pi: &crate::prelude::Nat, j_pj: &crate::prelude::Nat| if &crate::prelude::or(&crate::prelude::index(&c_p1xy.fields_p, j_pj), &crate::prelude::Text::lit("")) == &fname_pf {
                        j_pj.clone()
                    } else {
                        found_pi.clone()
                    }));
                    crate::prelude::call_then(crate::lower::start_field_spell_f(crate::lower::owner_of_f(&c_p1xy.owner_p), fname_pf.clone(), crate::prelude::or(&crate::prelude::index(&c_p1xy.args_p, &fix_pg), &crate::check::types::Ty::TyErr)), move |field_spell_f_11613: crate::prelude::Text| crate::prelude::call_then(crate::lower::expr::start_instantiated_f(crate::prelude::or(&crate::prelude::index(&c_p1xy.args_p, &fix_pg), &crate::check::types::Ty::TyErr), c_p1xy.params_p.clone(), args_p8xy.clone()), move |instantiated_f_11709: crate::check::types::Ty| crate::prelude::call_then(start_sub_pat_f(lx_p0xy.clone(), c_p1xy.clone(), fix_pg.clone(), fp_pe.pattern_p.clone(), instantiated_f_11709, mode_p5xy.clone(), crate::prelude::Text::from(format!("{}_{}", &fresh_p6xy, &i_pd))), move |sub_pat_f_11677: PatOut| ::prism_rtl::Turn::Finished((field_spell_f_11613, sub_pat_f_11677)))))
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Text, PatOut)>>>
    }));
    let conds_pa = crate::prelude::fold(&subs_p9, &crate::prelude::Array::new(), &(|acc_pk: &crate::prelude::Array<crate::lower::model::Cc>, (_, o_pl): &(crate::prelude::Text, PatOut)| crate::prelude::append(acc_pk, &o_pl.conds_p)));
    let binds_pb = crate::prelude::fold(&subs_p9, &crate::prelude::Array::new(), &(|acc_pm: &crate::prelude::Array<(crate::prelude::Text, crate::lower::types::Bn)>, (_, o_pn): &(crate::prelude::Text, PatOut)| crate::prelude::append(acc_pm, &o_pn.binds_p)));
    PatOut { pa_p: crate::lower::model::Pa::PaRecord(ty_path_p7.clone(), crate::prelude::each(&subs_p9, &(|(f_po, o_pp): &(crate::prelude::Text, PatOut)| (f_po.clone(), o_pp.pa_p.clone()))), *rest_p3 || (&crate::prelude::len(&subs_p9) < &crate::prelude::len(&c_p1.fields_p))), conds_p: conds_pa.clone(), binds_p: binds_pb.clone() }
}

/// The step machine of `FieldsPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FieldsPat: unbounded fn Lx, CtorInfo, [FieldPat], Bool, Ty, Holding, Text, Ref -> PatOut
/// ```
pub struct FieldsPat {
    pub lx_p0: crate::lower::Lx,
    pub c_p1: crate::check::env::CtorInfo,
    pub fps_p2: crate::prelude::Array<crate::syntax::FieldPat>,
    pub rest_p3: bool,
    pub ty_p4: crate::check::types::Ty,
    pub mode_p5: crate::lower::types::Holding,
    pub fresh_p6: crate::prelude::Text,
    pub ty_path_p7: crate::lower::model::Ref,
}

impl ::prism_rtl::Job<PatOut> for FieldsPat {
    fn cycle(&self) -> ::prism_rtl::Turn<PatOut> {
        let lx_p0 = &self.lx_p0;
        let c_p1 = &self.c_p1;
        let fps_p2 = &self.fps_p2;
        let rest_p3 = &self.rest_p3;
        let ty_p4 = &self.ty_p4;
        let mode_p5 = &self.mode_p5;
        let fresh_p6 = &self.fresh_p6;
        let ty_path_p7 = &self.ty_path_p7;
        let args_p8 = match crate::lower::types::peel_f(ty_p4) {
            crate::check::types::Ty::TyCon(_, xs_pc) => xs_pc,
            _ => crate::prelude::Array::new(),
        };
        let c_p1x = c_p1.clone();
        let fps_p2x = fps_p2.clone();
        let fresh_p6x = fresh_p6.clone();
        let lx_p0x = lx_p0.clone();
        let mode_p5x = mode_p5.clone();
        let rest_p3x = *rest_p3;
        let ty_path_p7x = ty_path_p7.clone();
        crate::prelude::call_value(crate::prelude::each_job(crate::check::errors::range0_f(&crate::prelude::len(&fps_p2x)), {
            let fps_p2xx = fps_p2x.clone();
            let c_p1xx = c_p1x.clone();
            let lx_p0xx = lx_p0x.clone();
            let args_p8x = args_p8.clone();
            let mode_p5xx = mode_p5x.clone();
            let fresh_p6xx = fresh_p6x.clone();
            ::std::rc::Rc::new(move |p0: crate::prelude::Nat| {
                let fps_p2xxy = fps_p2xx.clone();
                let c_p1xxy = c_p1xx.clone();
                let lx_p0xxy = lx_p0xx.clone();
                let args_p8xy = args_p8x.clone();
                let mode_p5xxy = mode_p5xx.clone();
                let fresh_p6xxy = fresh_p6xx.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let i_pd = p0;
                    {
                        let fp_pe = crate::prelude::or(&crate::prelude::index(&fps_p2xxy, &i_pd), &dummy_field_pat_p());
                        let fname_pf = match &fp_pe.name_o {
                            ::std::option::Option::Some(id_ph) => id_ph.name_p.clone(),
                            ::std::option::Option::None => crate::prelude::or(&crate::prelude::index(&c_p1xxy.fields_p, &i_pd), &crate::prelude::Text::lit("")),
                        };
                        let fix_pg = crate::prelude::fold(&crate::check::errors::range0_f(&crate::prelude::len(&c_p1xxy.fields_p)), &i_pd, &(|found_pi: &crate::prelude::Nat, j_pj: &crate::prelude::Nat| if &crate::prelude::or(&crate::prelude::index(&c_p1xxy.fields_p, j_pj), &crate::prelude::Text::lit("")) == &fname_pf {
                            j_pj.clone()
                        } else {
                            found_pi.clone()
                        }));
                        crate::prelude::call_then(crate::lower::start_field_spell_f(crate::lower::owner_of_f(&c_p1xxy.owner_p), fname_pf.clone(), crate::prelude::or(&crate::prelude::index(&c_p1xxy.args_p, &fix_pg), &crate::check::types::Ty::TyErr)), move |field_spell_f_11613: crate::prelude::Text| crate::prelude::call_then(crate::lower::expr::start_instantiated_f(crate::prelude::or(&crate::prelude::index(&c_p1xxy.args_p, &fix_pg), &crate::check::types::Ty::TyErr), c_p1xxy.params_p.clone(), args_p8xy.clone()), move |instantiated_f_11709: crate::check::types::Ty| crate::prelude::call_then(start_sub_pat_f(lx_p0xxy.clone(), c_p1xxy.clone(), fix_pg.clone(), fp_pe.pattern_p.clone(), instantiated_f_11709, mode_p5xxy.clone(), crate::prelude::Text::from(format!("{}_{}", &fresh_p6xxy, &i_pd))), move |sub_pat_f_11677: PatOut| ::prism_rtl::Turn::Finished((field_spell_f_11613, sub_pat_f_11677)))))
                    }
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Text, PatOut)>>>
        }), move |each_11273: crate::prelude::Array<(crate::prelude::Text, PatOut)>| {
            let subs_p9 = each_11273;
            let conds_pa = crate::prelude::fold(&subs_p9, &crate::prelude::Array::new(), &(|acc_pk: &crate::prelude::Array<crate::lower::model::Cc>, (_, o_pl): &(crate::prelude::Text, PatOut)| crate::prelude::append(acc_pk, &o_pl.conds_p)));
            let binds_pb = crate::prelude::fold(&subs_p9, &crate::prelude::Array::new(), &(|acc_pm: &crate::prelude::Array<(crate::prelude::Text, crate::lower::types::Bn)>, (_, o_pn): &(crate::prelude::Text, PatOut)| crate::prelude::append(acc_pm, &o_pn.binds_p)));
            ::prism_rtl::Turn::Finished(PatOut { pa_p: crate::lower::model::Pa::PaRecord(ty_path_p7x.clone(), crate::prelude::each(&subs_p9, &(|(f_po, o_pp): &(crate::prelude::Text, PatOut)| (f_po.clone(), o_pp.pa_p.clone()))), rest_p3x || (&crate::prelude::len(&subs_p9) < &crate::prelude::len(&c_p1x.fields_p))), conds_p: conds_pa.clone(), binds_p: binds_pb.clone() })
        })
    }
}

/// `Start FieldsPat, x`: what the function value is when passed to `@Run`.
pub fn start_fields_pat_f(lx_p0: crate::lower::Lx, c_p1: crate::check::env::CtorInfo, fps_p2: crate::prelude::Array<crate::syntax::FieldPat>, rest_p3: bool, ty_p4: crate::check::types::Ty, mode_p5: crate::lower::types::Holding, fresh_p6: crate::prelude::Text, ty_path_p7: crate::lower::model::Ref) -> ::std::rc::Rc<dyn ::prism_rtl::Job<PatOut>> {
    ::std::rc::Rc::new(FieldsPat { lx_p0, c_p1, fps_p2, rest_p3, ty_p4, mode_p5, fresh_p6, ty_path_p7 })
}

/// ```prism
/// let dummyFieldPat
/// ```
pub fn dummy_field_pat_p() -> crate::syntax::FieldPat {
    crate::syntax::FieldPat { marks_p: crate::prelude::Text::lit(""), name_o: ::std::option::Option::None, pattern_p: dummy_pat_p(), span_p: crate::syntax::Range { start_p: crate::prelude::Nat::from(0u32), end_p: crate::prelude::Nat::from(0u32) } }
}

/// ```prism
/// let dummyTagInfo
/// ```
pub fn dummy_tag_info_p() -> crate::check::env::TagInfo {
    crate::check::env::TagInfo { name_p: crate::prelude::Text::lit(""), family_p: crate::prelude::Text::lit(""), kind_p: crate::prelude::Text::lit(""), out_p: crate::check::types::Ty::TyErr, qs_p: crate::prelude::Array::new(), rqs_p: crate::prelude::Array::new(), bounds_p: crate::prelude::Array::new(), fields_p: crate::prelude::Array::new(), field_at_p: crate::prelude::Array::new(), home_p: crate::prelude::Text::lit(""), file_p: crate::prelude::Nat::from(0u32), span_p: crate::syntax::Range { start_p: crate::prelude::Nat::from(0u32), end_p: crate::prelude::Nat::from(0u32) } }
}

/// ```prism
/// IsLive: fn Ty -> Bool
/// ```
pub fn is_live_f(t_p0: &crate::check::types::Ty) -> bool {
    match crate::lower::types::peel_f(t_p0) {
        crate::check::types::Ty::TyElem(_, _) => true,
        _ => false,
    }
}

/// ```prism
/// TagFieldName: fn FieldPat, [Text], Nat -> Text
/// ```
pub fn tag_field_name_f(fp_p0: &crate::syntax::FieldPat, names_p1: &crate::prelude::Array<crate::prelude::Text>, i_p2: &crate::prelude::Nat) -> crate::prelude::Text {
    match &fp_p0.name_o {
        ::std::option::Option::Some(id_p3) => id_p3.name_p.clone(),
        ::std::option::Option::None => match &*fp_p0.pattern_p.kind_p {
            crate::syntax::PatternKind::PName(n_p4) => if crate::check::types::has_text_f(names_p1, &crate::check::env::sname_key_f(n_p4)) {
                crate::check::env::sname_key_f(n_p4)
            } else {
                crate::prelude::or(&crate::prelude::index(names_p1, i_p2), &crate::prelude::Text::lit(""))
            },
            _ => crate::prelude::or(&crate::prelude::index(names_p1, i_p2), &crate::prelude::Text::lit("")),
        },
    }
}

/// ```prism
/// TagPat: unbounded fn Lx, TagInfo, [FieldPat], Bool, Ty, Holding, Text -> PatOut
/// ```
pub fn tag_pat_f(lx_p0: &crate::lower::Lx, tg_p1: &crate::check::env::TagInfo, fps_p2: &crate::prelude::Array<crate::syntax::FieldPat>, rest_p3: &bool, ty_p4: &crate::check::types::Ty, mode_p5: &crate::lower::types::Holding, fresh_p6: &crate::prelude::Text) -> PatOut {
    let (variant_pj, struct_path_pk) = crate::lower::program::tag_paths_f(lx_p0, tg_p1);
    let live_p7 = is_live_f(ty_p4);
    let names_p8 = crate::prelude::each(&tg_p1.fields_p, &(|(f_pl, _): &(crate::prelude::Text, crate::check::types::Ty)| f_pl.clone()));
    let sub_mode_p9 = if live_p7 { crate::lower::types::Holding::ByRef } else { mode_p5.clone() };
    let parts_pa = crate::prelude::run_to_end(crate::prelude::each_job(crate::check::errors::range0_f(&crate::prelude::len(fps_p2)), {
        let fps_p2x = fps_p2.clone();
        let names_p8x = names_p8.clone();
        let tg_p1x = tg_p1.clone();
        let live_p7x = live_p7;
        let lx_p0x = lx_p0.clone();
        let fresh_p6x = fresh_p6.clone();
        let sub_mode_p9x = sub_mode_p9.clone();
        ::std::rc::Rc::new(move |p0: crate::prelude::Nat| {
            let fps_p2xy = fps_p2x.clone();
            let names_p8xy = names_p8x.clone();
            let tg_p1xy = tg_p1x.clone();
            let live_p7xy = live_p7x;
            let lx_p0xy = lx_p0x.clone();
            let fresh_p6xy = fresh_p6x.clone();
            let sub_mode_p9xy = sub_mode_p9x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let i_pm = p0;
                {
                    let fp_pn = crate::prelude::or(&crate::prelude::index(&fps_p2xy, &i_pm), &dummy_field_pat_p());
                    let fname_po = tag_field_name_f(&fp_pn, &names_p8xy, &i_pm);
                    let ft_pp = crate::prelude::fold(&tg_p1xy.fields_p, &crate::check::types::Ty::TyErr, &(|found_pq: &crate::check::types::Ty, (f_pr, t_ps): &(crate::prelude::Text, crate::check::types::Ty)| if f_pr == &fname_po { t_ps.clone() } else { found_pq.clone() }));
                    match crate::lower::types::layer_of_f(&ft_pp) {
                        crate::lower::types::Layer::LyEv if live_p7xy => crate::prelude::call_then(crate::lower::start_field_spell_f(tg_p1xy.home_p.clone(), fname_po.clone(), ft_pp.clone()), move |field_spell_f_14176: crate::prelude::Text| crate::prelude::call_then(start_event_field_pat_f(lx_p0xy.clone(), fp_pn.pattern_p.clone(), fname_po.clone(), field_spell_f_14176, ft_pp.clone(), crate::prelude::Text::from(format!("{}_v", &fresh_p6xy)), crate::lower::ref_in_f(&lx_p0xy, &tg_p1xy.home_p, &crate::lower::desc_struct_of_f(&tg_p1xy))), move |event_field_pat_f_14138: PatOut| ::prism_rtl::Turn::Finished((::std::option::Option::None, event_field_pat_f_14138)))),
                        crate::lower::types::Layer::LyEv if (&crate::prelude::len(&crate::lower::program::level_events_f(&tg_p1xy)) > &crate::prelude::Nat::from(0u32)) => crate::prelude::call_then(start_rust_pat_f(lx_p0xy.clone(), fp_pn.pattern_p.clone(), ft_pp.clone(), sub_mode_p9xy.clone(), crate::prelude::Text::from(format!("{}_{}", &fresh_p6xy, &i_pm))), move |rust_pat_f_14426: PatOut| {
                            let o_pt = rust_pat_f_14426;
                            ::prism_rtl::Turn::Finished((::std::option::Option::Some(crate::lower::field_spell_f(&tg_p1xy.home_p, &fname_po, &ft_pp)), o_pt.clone()))
                        }),
                        crate::lower::types::Layer::LyEv => ::prism_rtl::Turn::Finished((::std::option::Option::None, PatOut { pa_p: crate::lower::model::Pa::PaWild, conds_p: crate::prelude::Array::from(vec![crate::lower::model::Cc::CcIf(crate::lower::expr::internal_bug_f(&crate::prelude::Text::from(format!("an event field in a pattern of a row value that is no element ({}.{})", &tg_p1xy.name_p, &fname_po))))]), binds_p: crate::prelude::Array::new() })),
                        crate::lower::types::Layer::LyDyn if live_p7xy => crate::prelude::call_then(crate::lower::start_field_spell_f(tg_p1xy.home_p.clone(), fname_po.clone(), ft_pp.clone()), move |field_spell_f_14779: crate::prelude::Text| crate::prelude::call_then(start_live_field_pat_f(lx_p0xy.clone(), fp_pn.pattern_p.clone(), fname_po.clone(), field_spell_f_14779, ft_pp.clone(), crate::prelude::Text::from(format!("{}_v", &fresh_p6xy)), crate::lower::ref_in_f(&lx_p0xy, &tg_p1xy.home_p, &crate::lower::desc_struct_of_f(&tg_p1xy))), move |live_field_pat_f_14742: PatOut| ::prism_rtl::Turn::Finished((::std::option::Option::None, live_field_pat_f_14742)))),
                        _ => crate::prelude::call_then(start_rust_pat_f(lx_p0xy.clone(), fp_pn.pattern_p.clone(), crate::lower::types::peel_f(&ft_pp), sub_mode_p9xy.clone(), crate::prelude::Text::from(format!("{}_{}", &fresh_p6xy, &i_pm))), move |rust_pat_f_14917: PatOut| {
                            let o_pu = rust_pat_f_14917;
                            ::prism_rtl::Turn::Finished((::std::option::Option::Some(crate::lower::field_spell_f(&tg_p1xy.home_p, &fname_po, &ft_pp)), o_pu.clone()))
                        }),
                        _ => unreachable!("no arm matched"),
                    }
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(::std::option::Option<crate::prelude::Text>, PatOut)>>>
    }));
    let field_pas_pb = crate::prelude::fold(&parts_pa, &crate::prelude::Array::new(), &(|acc_pv: &crate::prelude::Array<(crate::prelude::Text, crate::lower::model::Pa)>, (f_o10, o_p11): &(::std::option::Option<crate::prelude::Text>, PatOut)| match f_o10 {
        ::std::option::Option::Some(f_p12) => crate::prelude::push(acc_pv, &(f_p12.clone(), o_p11.pa_p.clone())),
        ::std::option::Option::None => acc_pv.clone(),
    }));
    let conds_pc = crate::prelude::fold(&parts_pa, &crate::prelude::Array::new(), &(|acc_p13: &crate::prelude::Array<crate::lower::model::Cc>, (_, o_p14): &(::std::option::Option<crate::prelude::Text>, PatOut)| crate::prelude::append(acc_p13, &o_p14.conds_p)));
    let binds_pd = crate::prelude::fold(&parts_pa, &crate::prelude::Array::new(), &(|acc_p15: &crate::prelude::Array<(crate::prelude::Text, crate::lower::types::Bn)>, (_, o_p16): &(::std::option::Option<crate::prelude::Text>, PatOut)| crate::prelude::append(acc_p15, &o_p16.binds_p)));
    let level_pe = crate::lower::model::Pa::PaCtor(variant_pj.clone(), crate::prelude::Array::from(vec![crate::lower::model::Pa::PaRecord(struct_path_pk.clone(), field_pas_pb.clone(), true)]));
    let tagged_pf = crate::prelude::push(&crate::prelude::push(&binds_pd, &(crate::prelude::Text::lit("#tag"), crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XPath(crate::lower::node_::elements::answer_variant_f(tg_p1)), crate::lower::types::Holding::Owned, crate::lower::model::OutTy::OutUnit))), &(crate::prelude::Text::lit("#tagfirst"), crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XPath(crate::lower::node_::elements::answer_first_variant_f(tg_p1)), crate::lower::types::Holding::Owned, crate::lower::model::OutTy::OutUnit)));
    let view_pg = crate::prelude::Text::from(format!("{}_v", fresh_p6));
    let desc_path_ph = crate::lower::ref_in_f(lx_p0, &tg_p1.home_p, &crate::lower::desc_struct_of_f(tg_p1));
    let viewed_pi = crate::prelude::Array::from(vec![crate::lower::model::Cc::CcLet(crate::lower::model::Pa::PaCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Some")), crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(view_pg.clone())])), desc_view_f(lx_p0, tg_p1, fresh_p6)), crate::lower::model::Cc::CcLet(crate::lower::model::Pa::PaRecord(desc_path_ph.clone(), field_pas_pb.clone(), true), crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XVar(view_pg.clone()))))]);
    if live_p7 {
        PatOut { pa_p: crate::lower::model::Pa::PaBind(fresh_p6.clone()), conds_p: crate::prelude::append(&viewed_pi, &conds_pc), binds_p: tagged_pf.clone() }
    } else {
        PatOut { pa_p: level_pe.clone(), conds_p: conds_pc.clone(), binds_p: binds_pd.clone() }
    }
}

/// The step machine of `TagPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TagPat: unbounded fn Lx, TagInfo, [FieldPat], Bool, Ty, Holding, Text -> PatOut
/// ```
pub struct TagPat {
    pub lx_p0: crate::lower::Lx,
    pub tg_p1: crate::check::env::TagInfo,
    pub fps_p2: crate::prelude::Array<crate::syntax::FieldPat>,
    pub rest_p3: bool,
    pub ty_p4: crate::check::types::Ty,
    pub mode_p5: crate::lower::types::Holding,
    pub fresh_p6: crate::prelude::Text,
}

impl ::prism_rtl::Job<PatOut> for TagPat {
    fn cycle(&self) -> ::prism_rtl::Turn<PatOut> {
        let lx_p0 = &self.lx_p0;
        let tg_p1 = &self.tg_p1;
        let fps_p2 = &self.fps_p2;
        let rest_p3 = &self.rest_p3;
        let ty_p4 = &self.ty_p4;
        let mode_p5 = &self.mode_p5;
        let fresh_p6 = &self.fresh_p6;
        let (variant_pj, struct_path_pk) = crate::lower::program::tag_paths_f(lx_p0, tg_p1);
        let live_p7 = is_live_f(ty_p4);
        let names_p8 = crate::prelude::each(&tg_p1.fields_p, &(|(f_pl, _): &(crate::prelude::Text, crate::check::types::Ty)| f_pl.clone()));
        let sub_mode_p9 = if live_p7 { crate::lower::types::Holding::ByRef } else { mode_p5.clone() };
        let fps_p2x = fps_p2.clone();
        let fresh_p6x = fresh_p6.clone();
        let lx_p0x = lx_p0.clone();
        let tg_p1x = tg_p1.clone();
        crate::prelude::call_value(crate::prelude::each_job(crate::check::errors::range0_f(&crate::prelude::len(&fps_p2x)), {
            let fps_p2xx = fps_p2x.clone();
            let names_p8x = names_p8.clone();
            let tg_p1xx = tg_p1x.clone();
            let live_p7x = live_p7;
            let lx_p0xx = lx_p0x.clone();
            let fresh_p6xx = fresh_p6x.clone();
            let sub_mode_p9x = sub_mode_p9.clone();
            ::std::rc::Rc::new(move |p0: crate::prelude::Nat| {
                let fps_p2xxy = fps_p2xx.clone();
                let names_p8xy = names_p8x.clone();
                let tg_p1xxy = tg_p1xx.clone();
                let live_p7xy = live_p7x;
                let lx_p0xxy = lx_p0xx.clone();
                let fresh_p6xxy = fresh_p6xx.clone();
                let sub_mode_p9xy = sub_mode_p9x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let i_pm = p0;
                    {
                        let fp_pn = crate::prelude::or(&crate::prelude::index(&fps_p2xxy, &i_pm), &dummy_field_pat_p());
                        let fname_po = tag_field_name_f(&fp_pn, &names_p8xy, &i_pm);
                        let ft_pp = crate::prelude::fold(&tg_p1xxy.fields_p, &crate::check::types::Ty::TyErr, &(|found_pq: &crate::check::types::Ty, (f_pr, t_ps): &(crate::prelude::Text, crate::check::types::Ty)| if f_pr == &fname_po { t_ps.clone() } else { found_pq.clone() }));
                        match crate::lower::types::layer_of_f(&ft_pp) {
                            crate::lower::types::Layer::LyEv if live_p7xy => crate::prelude::call_then(crate::lower::start_field_spell_f(tg_p1xxy.home_p.clone(), fname_po.clone(), ft_pp.clone()), move |field_spell_f_14176: crate::prelude::Text| crate::prelude::call_then(start_event_field_pat_f(lx_p0xxy.clone(), fp_pn.pattern_p.clone(), fname_po.clone(), field_spell_f_14176, ft_pp.clone(), crate::prelude::Text::from(format!("{}_v", &fresh_p6xxy)), crate::lower::ref_in_f(&lx_p0xxy, &tg_p1xxy.home_p, &crate::lower::desc_struct_of_f(&tg_p1xxy))), move |event_field_pat_f_14138: PatOut| ::prism_rtl::Turn::Finished((::std::option::Option::None, event_field_pat_f_14138)))),
                            crate::lower::types::Layer::LyEv if (&crate::prelude::len(&crate::lower::program::level_events_f(&tg_p1xxy)) > &crate::prelude::Nat::from(0u32)) => crate::prelude::call_then(start_rust_pat_f(lx_p0xxy.clone(), fp_pn.pattern_p.clone(), ft_pp.clone(), sub_mode_p9xy.clone(), crate::prelude::Text::from(format!("{}_{}", &fresh_p6xxy, &i_pm))), move |rust_pat_f_14426: PatOut| {
                                let o_pt = rust_pat_f_14426;
                                ::prism_rtl::Turn::Finished((::std::option::Option::Some(crate::lower::field_spell_f(&tg_p1xxy.home_p, &fname_po, &ft_pp)), o_pt.clone()))
                            }),
                            crate::lower::types::Layer::LyEv => ::prism_rtl::Turn::Finished((::std::option::Option::None, PatOut { pa_p: crate::lower::model::Pa::PaWild, conds_p: crate::prelude::Array::from(vec![crate::lower::model::Cc::CcIf(crate::lower::expr::internal_bug_f(&crate::prelude::Text::from(format!("an event field in a pattern of a row value that is no element ({}.{})", &tg_p1xxy.name_p, &fname_po))))]), binds_p: crate::prelude::Array::new() })),
                            crate::lower::types::Layer::LyDyn if live_p7xy => crate::prelude::call_then(crate::lower::start_field_spell_f(tg_p1xxy.home_p.clone(), fname_po.clone(), ft_pp.clone()), move |field_spell_f_14779: crate::prelude::Text| crate::prelude::call_then(start_live_field_pat_f(lx_p0xxy.clone(), fp_pn.pattern_p.clone(), fname_po.clone(), field_spell_f_14779, ft_pp.clone(), crate::prelude::Text::from(format!("{}_v", &fresh_p6xxy)), crate::lower::ref_in_f(&lx_p0xxy, &tg_p1xxy.home_p, &crate::lower::desc_struct_of_f(&tg_p1xxy))), move |live_field_pat_f_14742: PatOut| ::prism_rtl::Turn::Finished((::std::option::Option::None, live_field_pat_f_14742)))),
                            _ => crate::prelude::call_then(start_rust_pat_f(lx_p0xxy.clone(), fp_pn.pattern_p.clone(), crate::lower::types::peel_f(&ft_pp), sub_mode_p9xy.clone(), crate::prelude::Text::from(format!("{}_{}", &fresh_p6xxy, &i_pm))), move |rust_pat_f_14917: PatOut| {
                                let o_pu = rust_pat_f_14917;
                                ::prism_rtl::Turn::Finished((::std::option::Option::Some(crate::lower::field_spell_f(&tg_p1xxy.home_p, &fname_po, &ft_pp)), o_pu.clone()))
                            }),
                            _ => unreachable!("no arm matched"),
                        }
                    }
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(::std::option::Option<crate::prelude::Text>, PatOut)>>>
        }), move |each_13698: crate::prelude::Array<(::std::option::Option<crate::prelude::Text>, PatOut)>| {
            let parts_pa = each_13698;
            let field_pas_pb = crate::prelude::fold(&parts_pa, &crate::prelude::Array::new(), &(|acc_pv: &crate::prelude::Array<(crate::prelude::Text, crate::lower::model::Pa)>, (f_o10, o_p11): &(::std::option::Option<crate::prelude::Text>, PatOut)| match f_o10 {
                ::std::option::Option::Some(f_p12) => crate::prelude::push(acc_pv, &(f_p12.clone(), o_p11.pa_p.clone())),
                ::std::option::Option::None => acc_pv.clone(),
            }));
            let conds_pc = crate::prelude::fold(&parts_pa, &crate::prelude::Array::new(), &(|acc_p13: &crate::prelude::Array<crate::lower::model::Cc>, (_, o_p14): &(::std::option::Option<crate::prelude::Text>, PatOut)| crate::prelude::append(acc_p13, &o_p14.conds_p)));
            let binds_pd = crate::prelude::fold(&parts_pa, &crate::prelude::Array::new(), &(|acc_p15: &crate::prelude::Array<(crate::prelude::Text, crate::lower::types::Bn)>, (_, o_p16): &(::std::option::Option<crate::prelude::Text>, PatOut)| crate::prelude::append(acc_p15, &o_p16.binds_p)));
            let level_pe = crate::lower::model::Pa::PaCtor(variant_pj.clone(), crate::prelude::Array::from(vec![crate::lower::model::Pa::PaRecord(struct_path_pk.clone(), field_pas_pb.clone(), true)]));
            let tagged_pf = crate::prelude::push(&crate::prelude::push(&binds_pd, &(crate::prelude::Text::lit("#tag"), crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XPath(crate::lower::node_::elements::answer_variant_f(&tg_p1x)), crate::lower::types::Holding::Owned, crate::lower::model::OutTy::OutUnit))), &(crate::prelude::Text::lit("#tagfirst"), crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XPath(crate::lower::node_::elements::answer_first_variant_f(&tg_p1x)), crate::lower::types::Holding::Owned, crate::lower::model::OutTy::OutUnit)));
            let view_pg = crate::prelude::Text::from(format!("{}_v", &fresh_p6x));
            let desc_path_ph = crate::lower::ref_in_f(&lx_p0x, &tg_p1x.home_p, &crate::lower::desc_struct_of_f(&tg_p1x));
            crate::prelude::call_then(start_desc_view_f(lx_p0x.clone(), tg_p1x.clone(), fresh_p6x.clone()), move |desc_view_f_15972: crate::lower::model::Ex| {
                let viewed_pi = crate::prelude::Array::from(vec![crate::lower::model::Cc::CcLet(crate::lower::model::Pa::PaCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Some")), crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(view_pg.clone())])), desc_view_f_15972), crate::lower::model::Cc::CcLet(crate::lower::model::Pa::PaRecord(desc_path_ph.clone(), field_pas_pb.clone(), true), crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XVar(view_pg.clone()))))]);
                if live_p7 {
                    ::prism_rtl::Turn::Finished(PatOut { pa_p: crate::lower::model::Pa::PaBind(fresh_p6x.clone()), conds_p: crate::prelude::append(&viewed_pi, &conds_pc), binds_p: tagged_pf.clone() })
                } else {
                    ::prism_rtl::Turn::Finished(PatOut { pa_p: level_pe.clone(), conds_p: conds_pc.clone(), binds_p: binds_pd.clone() })
                }
            })
        })
    }
}

/// `Start TagPat, x`: what the function value is when passed to `@Run`.
pub fn start_tag_pat_f(lx_p0: crate::lower::Lx, tg_p1: crate::check::env::TagInfo, fps_p2: crate::prelude::Array<crate::syntax::FieldPat>, rest_p3: bool, ty_p4: crate::check::types::Ty, mode_p5: crate::lower::types::Holding, fresh_p6: crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<PatOut>> {
    ::std::rc::Rc::new(TagPat { lx_p0, tg_p1, fps_p2, rest_p3, ty_p4, mode_p5, fresh_p6 })
}

/// ```prism
/// DescView: unbounded fn Lx, TagInfo, Text -> Ex
/// ```
pub fn desc_view_f(lx_p0: &crate::lower::Lx, tg_p1: &crate::check::env::TagInfo, fresh_p2: &crate::prelude::Text) -> crate::lower::model::Ex {
    desc_view_by_f(lx_p0, tg_p1, fresh_p2, &crate::prelude::Text::lit("prism_rtl::element_view"))
}

/// The step machine of `DescView`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// DescView: unbounded fn Lx, TagInfo, Text -> Ex
/// ```
pub struct DescView {
    pub lx_p0: crate::lower::Lx,
    pub tg_p1: crate::check::env::TagInfo,
    pub fresh_p2: crate::prelude::Text,
}

impl ::prism_rtl::Job<crate::lower::model::Ex> for DescView {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::lower::model::Ex> {
        let lx_p0 = &self.lx_p0;
        let tg_p1 = &self.tg_p1;
        let fresh_p2 = &self.fresh_p2;
        ::prism_rtl::Turn::More(::std::rc::Rc::new(DescViewBy { lx_p0: lx_p0.clone(), tg_p1: tg_p1.clone(), fresh_p2: fresh_p2.clone(), reader_p3: crate::prelude::Text::lit("prism_rtl::element_view") }))
    }
}

/// `Start DescView, x`: what the function value is when passed to `@Run`.
pub fn start_desc_view_f(lx_p0: crate::lower::Lx, tg_p1: crate::check::env::TagInfo, fresh_p2: crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>> {
    ::std::rc::Rc::new(DescView { lx_p0, tg_p1, fresh_p2 })
}

/// ```prism
/// DescViewBy: unbounded fn Lx, TagInfo, Text, Text -> Ex
/// ```
pub fn desc_view_by_f(lx_p0: &crate::lower::Lx, tg_p1: &crate::check::env::TagInfo, fresh_p2: &crate::prelude::Text, reader_p3: &crate::prelude::Text) -> crate::lower::model::Ex {
    let (variant_pb, struct_path_pc) = crate::lower::program::tag_paths_f(lx_p0, tg_p1);
    let desc_path_p4 = crate::lower::ref_in_f(lx_p0, &tg_p1.home_p, &crate::lower::desc_struct_of_f(tg_p1));
    let fields_p5 = crate::prelude::run_to_end(crate::prelude::each_job(tg_p1.fields_p.clone(), {
        let tg_p1x = tg_p1.clone();
        let variant_pbx = variant_pb.clone();
        let struct_path_pcx = struct_path_pc.clone();
        let lx_p0x = lx_p0.clone();
        ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::check::types::Ty)| {
            let tg_p1xy = tg_p1x.clone();
            let variant_pbxy = variant_pbx.clone();
            let struct_path_pcxy = struct_path_pcx.clone();
            let lx_p0xy = lx_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (fname_pd, ft_pe) = p0;
                crate::prelude::call_then(crate::lower::start_field_spell_f(tg_p1xy.home_p.clone(), fname_pd.clone(), ft_pe.clone()), move |field_spell_f_17057: crate::prelude::Text| {
                    let f_pf = field_spell_f_17057;
                    let f_pfz = f_pf.clone();
                    let k_let17095 = move |v17095: crate::lower::model::Ex| {
                        let v_pg = v17095;
                        ::prism_rtl::Turn::Finished((f_pfz.clone(), v_pg.clone()))
                    };
                    match crate::lower::types::layer_of_f(&ft_pe) {
                        crate::lower::types::Layer::LyDyn => crate::prelude::call_then(crate::lower::types::start_tag_field_out_f(lx_p0xy.clone(), ft_pe.clone()), move |tag_field_out_f_17185: crate::lower::model::OutTy| k_let17095(live_projection_f(&crate::prelude::Text::lit("l"), &variant_pbxy, &struct_path_pcxy, &f_pf, &tag_field_out_f_17185))),
                        crate::lower::types::Layer::LyEv => k_let17095(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("l"))), crate::prelude::Text::lit("requested"), crate::prelude::Array::from(vec![if &crate::lower::node_::elements::request_field_f(&tg_p1xy, &fname_pd) == &crate::prelude::Text::lit("") {
                            crate::lower::model::Ex::XNone
                        } else {
                            crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Some")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XStr(crate::lower::node_::elements::request_field_f(&tg_p1xy, &fname_pd))]))
                        }]))),
                        _ => k_let17095(crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XFieldOf(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("x"))), struct_path_pcxy.clone(), f_pf.clone())))),
                    }
                })
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::check::types::Ty)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Text, crate::lower::model::Ex)>>>
    }));
    let some_p6 = crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Some")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XRecord(desc_path_p4.clone(), fields_p5.clone())]));
    let desc_ty_p7 = crate::lower::model::OutTy::OutNamed(desc_path_p4.clone(), crate::prelude::Array::new());
    let arms_p8 = crate::prelude::Array::from(vec![crate::lower::model::XArm { pat_p: crate::lower::model::Pa::PaCtor(variant_pb.clone(), crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("x"))])), conds_p: crate::prelude::Array::new(), body_p: some_p6.clone() }, crate::lower::model::XArm { pat_p: crate::lower::model::Pa::PaWild, conds_p: crate::prelude::Array::new(), body_p: crate::lower::model::Ex::XTyped(::std::rc::Rc::new(crate::lower::model::Ex::XNone), crate::lower::model::OutTy::OutOpt(::std::rc::Rc::new(desc_ty_p7.clone()))) }]);
    let live_ty_p9 = crate::lower::model::OutTy::OutRef(::std::rc::Rc::new(crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("prism_rtl::Live")), crate::prelude::Array::from(vec![crate::lower::model::OutTy::OutNamed(crate::lower::model::elem_ref_p(), crate::prelude::Array::new())]))));
    let of_live_pa = crate::lower::model::Ex::XClosure(false, crate::prelude::Array::from(vec![crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("l"))), live_ty_p9.clone())]), ::std::rc::Rc::new(crate::lower::model::Ex::XMatch(::std::rc::Rc::new(crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("l"))), crate::prelude::Text::lit("identity"))))), arms_p8.clone(), false, crate::lower::model::OutTy::OutOpt(::std::rc::Rc::new(desc_ty_p7.clone())))));
    crate::lower::model::Ex::XCallAt(crate::lower::model::Ref::RefRuntime(reader_p3.clone()), crate::prelude::Array::from(vec![crate::lower::model::OutTy::OutNamed(crate::lower::model::elem_ref_p(), crate::prelude::Array::new()), desc_ty_p7.clone()]), crate::prelude::Array::from(vec![crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XVar(fresh_p2.clone()))), of_live_pa.clone()]))
}

/// The step machine of `DescViewBy`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// DescViewBy: unbounded fn Lx, TagInfo, Text, Text -> Ex
/// ```
pub struct DescViewBy {
    pub lx_p0: crate::lower::Lx,
    pub tg_p1: crate::check::env::TagInfo,
    pub fresh_p2: crate::prelude::Text,
    pub reader_p3: crate::prelude::Text,
}

impl ::prism_rtl::Job<crate::lower::model::Ex> for DescViewBy {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::lower::model::Ex> {
        let lx_p0 = &self.lx_p0;
        let tg_p1 = &self.tg_p1;
        let fresh_p2 = &self.fresh_p2;
        let reader_p3 = &self.reader_p3;
        let (variant_pb, struct_path_pc) = crate::lower::program::tag_paths_f(lx_p0, tg_p1);
        let desc_path_p4 = crate::lower::ref_in_f(lx_p0, &tg_p1.home_p, &crate::lower::desc_struct_of_f(tg_p1));
        let fresh_p2x = fresh_p2.clone();
        let lx_p0x = lx_p0.clone();
        let reader_p3x = reader_p3.clone();
        let tg_p1x = tg_p1.clone();
        crate::prelude::call_value(crate::prelude::each_job(tg_p1x.fields_p.clone(), {
            let tg_p1xx = tg_p1x.clone();
            let variant_pbx = variant_pb.clone();
            let struct_path_pcx = struct_path_pc.clone();
            let lx_p0xx = lx_p0x.clone();
            ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::check::types::Ty)| {
                let tg_p1xxy = tg_p1xx.clone();
                let variant_pbxy = variant_pbx.clone();
                let struct_path_pcxy = struct_path_pcx.clone();
                let lx_p0xxy = lx_p0xx.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let (fname_pd, ft_pe) = p0;
                    crate::prelude::call_then(crate::lower::start_field_spell_f(tg_p1xxy.home_p.clone(), fname_pd.clone(), ft_pe.clone()), move |field_spell_f_17057: crate::prelude::Text| {
                        let f_pf = field_spell_f_17057;
                        let f_pfz = f_pf.clone();
                        let k_let17095 = move |v17095: crate::lower::model::Ex| {
                            let v_pg = v17095;
                            ::prism_rtl::Turn::Finished((f_pfz.clone(), v_pg.clone()))
                        };
                        match crate::lower::types::layer_of_f(&ft_pe) {
                            crate::lower::types::Layer::LyDyn => crate::prelude::call_then(crate::lower::types::start_tag_field_out_f(lx_p0xxy.clone(), ft_pe.clone()), move |tag_field_out_f_17185: crate::lower::model::OutTy| k_let17095(live_projection_f(&crate::prelude::Text::lit("l"), &variant_pbxy, &struct_path_pcxy, &f_pf, &tag_field_out_f_17185))),
                            crate::lower::types::Layer::LyEv => k_let17095(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("l"))), crate::prelude::Text::lit("requested"), crate::prelude::Array::from(vec![if &crate::lower::node_::elements::request_field_f(&tg_p1xxy, &fname_pd) == &crate::prelude::Text::lit("") {
                                crate::lower::model::Ex::XNone
                            } else {
                                crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Some")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XStr(crate::lower::node_::elements::request_field_f(&tg_p1xxy, &fname_pd))]))
                            }]))),
                            _ => k_let17095(crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XFieldOf(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("x"))), struct_path_pcxy.clone(), f_pf.clone())))),
                        }
                    })
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::check::types::Ty)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Text, crate::lower::model::Ex)>>>
        }), move |each_17008: crate::prelude::Array<(crate::prelude::Text, crate::lower::model::Ex)>| {
            let fields_p5 = each_17008;
            let some_p6 = crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Some")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XRecord(desc_path_p4.clone(), fields_p5.clone())]));
            let desc_ty_p7 = crate::lower::model::OutTy::OutNamed(desc_path_p4.clone(), crate::prelude::Array::new());
            let arms_p8 = crate::prelude::Array::from(vec![crate::lower::model::XArm { pat_p: crate::lower::model::Pa::PaCtor(variant_pb.clone(), crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("x"))])), conds_p: crate::prelude::Array::new(), body_p: some_p6.clone() }, crate::lower::model::XArm { pat_p: crate::lower::model::Pa::PaWild, conds_p: crate::prelude::Array::new(), body_p: crate::lower::model::Ex::XTyped(::std::rc::Rc::new(crate::lower::model::Ex::XNone), crate::lower::model::OutTy::OutOpt(::std::rc::Rc::new(desc_ty_p7.clone()))) }]);
            let live_ty_p9 = crate::lower::model::OutTy::OutRef(::std::rc::Rc::new(crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("prism_rtl::Live")), crate::prelude::Array::from(vec![crate::lower::model::OutTy::OutNamed(crate::lower::model::elem_ref_p(), crate::prelude::Array::new())]))));
            let of_live_pa = crate::lower::model::Ex::XClosure(false, crate::prelude::Array::from(vec![crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("l"))), live_ty_p9.clone())]), ::std::rc::Rc::new(crate::lower::model::Ex::XMatch(::std::rc::Rc::new(crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("l"))), crate::prelude::Text::lit("identity"))))), arms_p8.clone(), false, crate::lower::model::OutTy::OutOpt(::std::rc::Rc::new(desc_ty_p7.clone())))));
            ::prism_rtl::Turn::Finished(crate::lower::model::Ex::XCallAt(crate::lower::model::Ref::RefRuntime(reader_p3x.clone()), crate::prelude::Array::from(vec![crate::lower::model::OutTy::OutNamed(crate::lower::model::elem_ref_p(), crate::prelude::Array::new()), desc_ty_p7.clone()]), crate::prelude::Array::from(vec![crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XVar(fresh_p2x.clone()))), of_live_pa.clone()])))
        })
    }
}

/// `Start DescViewBy, x`: what the function value is when passed to `@Run`.
pub fn start_desc_view_by_f(lx_p0: crate::lower::Lx, tg_p1: crate::check::env::TagInfo, fresh_p2: crate::prelude::Text, reader_p3: crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>> {
    ::std::rc::Rc::new(DescViewBy { lx_p0, tg_p1, fresh_p2, reader_p3 })
}

/// ```prism
/// LiveFieldPat: unbounded fn Lx, Pattern, Text, Text, Ty, Text, Ref -> PatOut
/// ```
pub fn live_field_pat_f(lx_p0: &crate::lower::Lx, p_p1: &crate::syntax::Pattern, fname_p2: &crate::prelude::Text, rs_field_p3: &crate::prelude::Text, ft_p4: &crate::check::types::Ty, view_p5: &crate::prelude::Text, desc_path_p6: &crate::lower::model::Ref) -> PatOut {
    match &*p_p1.kind_p {
        crate::syntax::PatternKind::PIgnore => pat_only_f(&crate::lower::model::Pa::PaWild),
        crate::syntax::PatternKind::PName(n_p7) => PatOut { pa_p: crate::lower::model::Pa::PaWild, conds_p: crate::prelude::Array::new(), binds_p: crate::prelude::Array::from(vec![(crate::check::env::sname_key_f(n_p7), crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XFieldOf(::std::rc::Rc::new(crate::lower::model::Ex::XVar(view_p5.clone())), desc_path_p6.clone(), rs_field_p3.clone()))), crate::lower::types::Holding::Owned, crate::lower::model::OutTy::OutDyn(::std::rc::Rc::new(crate::lower::types::tag_field_out_f(lx_p0, ft_p4)))))]) },
        crate::syntax::PatternKind::PGroup(q_p8) => live_field_pat_f(lx_p0, &**q_p8, fname_p2, rs_field_p3, ft_p4, view_p5, desc_path_p6),
        _ => PatOut { pa_p: crate::lower::model::Pa::PaWild, conds_p: crate::prelude::Array::from(vec![crate::lower::model::Cc::CcIf(crate::lower::expr::refusal_f(&crate::prelude::Text::from(format!("a pattern inside an element\'s `$` field ({})", fname_p2))))]), binds_p: crate::prelude::Array::new() },
    }
}

/// The step machine of `LiveFieldPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LiveFieldPat: unbounded fn Lx, Pattern, Text, Text, Ty, Text, Ref -> PatOut
/// ```
pub struct LiveFieldPat {
    pub lx_p0: crate::lower::Lx,
    pub p_p1: crate::syntax::Pattern,
    pub fname_p2: crate::prelude::Text,
    pub rs_field_p3: crate::prelude::Text,
    pub ft_p4: crate::check::types::Ty,
    pub view_p5: crate::prelude::Text,
    pub desc_path_p6: crate::lower::model::Ref,
}

impl ::prism_rtl::Job<PatOut> for LiveFieldPat {
    fn cycle(&self) -> ::prism_rtl::Turn<PatOut> {
        let lx_p0 = &self.lx_p0;
        let p_p1 = &self.p_p1;
        let fname_p2 = &self.fname_p2;
        let rs_field_p3 = &self.rs_field_p3;
        let ft_p4 = &self.ft_p4;
        let view_p5 = &self.view_p5;
        let desc_path_p6 = &self.desc_path_p6;
        match &*p_p1.kind_p {
            crate::syntax::PatternKind::PIgnore => ::prism_rtl::Turn::Finished(pat_only_f(&crate::lower::model::Pa::PaWild)),
            crate::syntax::PatternKind::PName(n_p7) => {
                let desc_path_p6x = desc_path_p6.clone();
                let ft_p4x = ft_p4.clone();
                let lx_p0x = lx_p0.clone();
                let n_p7x = n_p7.clone();
                let rs_field_p3x = rs_field_p3.clone();
                let view_p5x = view_p5.clone();
                crate::prelude::call_then(crate::lower::types::start_tag_field_out_f(lx_p0x.clone(), ft_p4x.clone()), move |tag_field_out_f_18710: crate::lower::model::OutTy| ::prism_rtl::Turn::Finished(PatOut { pa_p: crate::lower::model::Pa::PaWild, conds_p: crate::prelude::Array::new(), binds_p: crate::prelude::Array::from(vec![(crate::check::env::sname_key_f(&n_p7x), crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XFieldOf(::std::rc::Rc::new(crate::lower::model::Ex::XVar(view_p5x.clone())), desc_path_p6x.clone(), rs_field_p3x.clone()))), crate::lower::types::Holding::Owned, crate::lower::model::OutTy::OutDyn(::std::rc::Rc::new(tag_field_out_f_18710))))]) }))
            },
            crate::syntax::PatternKind::PGroup(q_p8) => ::prism_rtl::Turn::More(::std::rc::Rc::new(LiveFieldPat { lx_p0: lx_p0.clone(), p_p1: (**q_p8).clone(), fname_p2: fname_p2.clone(), rs_field_p3: rs_field_p3.clone(), ft_p4: ft_p4.clone(), view_p5: view_p5.clone(), desc_path_p6: desc_path_p6.clone() })),
            _ => ::prism_rtl::Turn::Finished(PatOut { pa_p: crate::lower::model::Pa::PaWild, conds_p: crate::prelude::Array::from(vec![crate::lower::model::Cc::CcIf(crate::lower::expr::refusal_f(&crate::prelude::Text::from(format!("a pattern inside an element\'s `$` field ({})", fname_p2))))]), binds_p: crate::prelude::Array::new() }),
        }
    }
}

/// `Start LiveFieldPat, x`: what the function value is when passed to `@Run`.
pub fn start_live_field_pat_f(lx_p0: crate::lower::Lx, p_p1: crate::syntax::Pattern, fname_p2: crate::prelude::Text, rs_field_p3: crate::prelude::Text, ft_p4: crate::check::types::Ty, view_p5: crate::prelude::Text, desc_path_p6: crate::lower::model::Ref) -> ::std::rc::Rc<dyn ::prism_rtl::Job<PatOut>> {
    ::std::rc::Rc::new(LiveFieldPat { lx_p0, p_p1, fname_p2, rs_field_p3, ft_p4, view_p5, desc_path_p6 })
}

/// ```prism
/// EventFieldPat: unbounded fn Lx, Pattern, Text, Text, Ty, Text, Ref -> PatOut
/// ```
pub fn event_field_pat_f(lx_p0: &crate::lower::Lx, p_p1: &crate::syntax::Pattern, fname_p2: &crate::prelude::Text, rs_field_p3: &crate::prelude::Text, ft_p4: &crate::check::types::Ty, view_p5: &crate::prelude::Text, desc_path_p6: &crate::lower::model::Ref) -> PatOut {
    match &*p_p1.kind_p {
        crate::syntax::PatternKind::PIgnore => pat_only_f(&crate::lower::model::Pa::PaWild),
        crate::syntax::PatternKind::PName(n_p7) => PatOut { pa_p: crate::lower::model::Pa::PaWild, conds_p: crate::prelude::Array::new(), binds_p: crate::prelude::Array::from(vec![(crate::check::env::sname_key_f(n_p7), crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XFieldOf(::std::rc::Rc::new(crate::lower::model::Ex::XVar(view_p5.clone())), desc_path_p6.clone(), rs_field_p3.clone()))), crate::lower::types::Holding::Owned, crate::lower::model::OutTy::OutEvent(::std::rc::Rc::new(crate::lower::types::tag_field_out_f(lx_p0, ft_p4)))))]) },
        crate::syntax::PatternKind::PGroup(q_p8) => event_field_pat_f(lx_p0, &**q_p8, fname_p2, rs_field_p3, ft_p4, view_p5, desc_path_p6),
        _ => PatOut { pa_p: crate::lower::model::Pa::PaWild, conds_p: crate::prelude::Array::from(vec![crate::lower::model::Cc::CcIf(crate::lower::expr::internal_bug_f(&crate::prelude::Text::from(format!("a pattern inside an element\'s event field ({})", fname_p2))))]), binds_p: crate::prelude::Array::new() },
    }
}

/// The step machine of `EventFieldPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// EventFieldPat: unbounded fn Lx, Pattern, Text, Text, Ty, Text, Ref -> PatOut
/// ```
pub struct EventFieldPat {
    pub lx_p0: crate::lower::Lx,
    pub p_p1: crate::syntax::Pattern,
    pub fname_p2: crate::prelude::Text,
    pub rs_field_p3: crate::prelude::Text,
    pub ft_p4: crate::check::types::Ty,
    pub view_p5: crate::prelude::Text,
    pub desc_path_p6: crate::lower::model::Ref,
}

impl ::prism_rtl::Job<PatOut> for EventFieldPat {
    fn cycle(&self) -> ::prism_rtl::Turn<PatOut> {
        let lx_p0 = &self.lx_p0;
        let p_p1 = &self.p_p1;
        let fname_p2 = &self.fname_p2;
        let rs_field_p3 = &self.rs_field_p3;
        let ft_p4 = &self.ft_p4;
        let view_p5 = &self.view_p5;
        let desc_path_p6 = &self.desc_path_p6;
        match &*p_p1.kind_p {
            crate::syntax::PatternKind::PIgnore => ::prism_rtl::Turn::Finished(pat_only_f(&crate::lower::model::Pa::PaWild)),
            crate::syntax::PatternKind::PName(n_p7) => {
                let desc_path_p6x = desc_path_p6.clone();
                let ft_p4x = ft_p4.clone();
                let lx_p0x = lx_p0.clone();
                let n_p7x = n_p7.clone();
                let rs_field_p3x = rs_field_p3.clone();
                let view_p5x = view_p5.clone();
                crate::prelude::call_then(crate::lower::types::start_tag_field_out_f(lx_p0x.clone(), ft_p4x.clone()), move |tag_field_out_f_19391: crate::lower::model::OutTy| ::prism_rtl::Turn::Finished(PatOut { pa_p: crate::lower::model::Pa::PaWild, conds_p: crate::prelude::Array::new(), binds_p: crate::prelude::Array::from(vec![(crate::check::env::sname_key_f(&n_p7x), crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XFieldOf(::std::rc::Rc::new(crate::lower::model::Ex::XVar(view_p5x.clone())), desc_path_p6x.clone(), rs_field_p3x.clone()))), crate::lower::types::Holding::Owned, crate::lower::model::OutTy::OutEvent(::std::rc::Rc::new(tag_field_out_f_19391))))]) }))
            },
            crate::syntax::PatternKind::PGroup(q_p8) => ::prism_rtl::Turn::More(::std::rc::Rc::new(EventFieldPat { lx_p0: lx_p0.clone(), p_p1: (**q_p8).clone(), fname_p2: fname_p2.clone(), rs_field_p3: rs_field_p3.clone(), ft_p4: ft_p4.clone(), view_p5: view_p5.clone(), desc_path_p6: desc_path_p6.clone() })),
            _ => ::prism_rtl::Turn::Finished(PatOut { pa_p: crate::lower::model::Pa::PaWild, conds_p: crate::prelude::Array::from(vec![crate::lower::model::Cc::CcIf(crate::lower::expr::internal_bug_f(&crate::prelude::Text::from(format!("a pattern inside an element\'s event field ({})", fname_p2))))]), binds_p: crate::prelude::Array::new() }),
        }
    }
}

/// `Start EventFieldPat, x`: what the function value is when passed to `@Run`.
pub fn start_event_field_pat_f(lx_p0: crate::lower::Lx, p_p1: crate::syntax::Pattern, fname_p2: crate::prelude::Text, rs_field_p3: crate::prelude::Text, ft_p4: crate::check::types::Ty, view_p5: crate::prelude::Text, desc_path_p6: crate::lower::model::Ref) -> ::std::rc::Rc<dyn ::prism_rtl::Job<PatOut>> {
    ::std::rc::Rc::new(EventFieldPat { lx_p0, p_p1, fname_p2, rs_field_p3, ft_p4, view_p5, desc_path_p6 })
}

/// ```prism
/// LiveProjection: fn Text, Ref, Ref, Text, OutTy -> Ex
/// ```
pub fn live_projection_f(fresh_p0: &crate::prelude::Text, variant_p1: &crate::lower::model::Ref, struct_path_p2: &crate::lower::model::Ref, fname_p3: &crate::prelude::Text, ft_p4: &crate::lower::model::OutTy) -> crate::lower::model::Ex {
    let arm_p5 = crate::lower::model::XArm { pat_p: crate::lower::model::Pa::PaCtor(variant_p1.clone(), crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("x"))])), conds_p: crate::prelude::Array::new(), body_p: crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XFieldOf(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("x"))), struct_path_p2.clone(), fname_p3.clone()))) };
    let other_p6 = crate::lower::model::XArm { pat_p: crate::lower::model::Pa::PaWild, conds_p: crate::prelude::Array::new(), body_p: crate::lower::model::Ex::XUnreachable };
    crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XVar(fresh_p0.clone())), crate::prelude::Text::lit("level"))), crate::prelude::Text::lit("map"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XClosure(true, crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("l"))]), ::std::rc::Rc::new(crate::lower::model::Ex::XMatch(::std::rc::Rc::new(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("l"))), crate::prelude::Array::from(vec![arm_p5.clone(), other_p6.clone()]), false, ft_p4.clone())))]))
}

/// ```prism
/// FamilyPat: unbounded fn Lx, QualName, Ty, Text -> PatOut
/// ```
pub fn family_pat_f(lx_p0: &crate::lower::Lx, q_p1: &crate::syntax::QualName, ty_p2: &crate::check::types::Ty, fresh_p3: &crate::prelude::Text) -> PatOut {
    let fam_p4 = crate::check::env::dotted_f(&crate::prelude::filter(&q_p1.path_p, &(|x_p8: &crate::prelude::Text| x_p8 != &crate::prelude::Text::lit("*"))));
    let kind_p5 = match crate::lower::types::peel_f(ty_p2) {
        crate::check::types::Ty::TyElem(_, _) => crate::prelude::Text::lit("Element"),
        crate::check::types::Ty::TyElemAny(_) => crate::prelude::Text::lit("Element"),
        crate::check::types::Ty::TyCon(k_p9, _) => k_p9,
        _ => crate::prelude::Text::lit(""),
    };
    let tags_p6 = crate::prelude::filter(&crate::lower::program::kind_tags_f(lx_p0, &kind_p5, &crate::prelude::keys(&lx_p0.rs_mods_p)), &(|tg_pa: &crate::check::env::TagInfo| &tg_pa.family_p == &fam_p4));
    let is_one_p7 = if is_live_f(ty_p2) {
        crate::prelude::run_to_end(crate::prelude::fold_job(tags_p6.clone(), crate::lower::model::Ex::XBool(false), {
            let lx_p0x = lx_p0.clone();
            let fresh_p3x = fresh_p3.clone();
            ::std::rc::Rc::new(move |(p0, p1): (crate::lower::model::Ex, crate::check::env::TagInfo)| {
                let lx_p0xy = lx_p0x.clone();
                let fresh_p3xy = fresh_p3x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let acc_pb = p0;
                    let tg_pc = p1;
                    crate::prelude::call_then(start_desc_view_by_f(lx_p0xy.clone(), tg_pc.clone(), fresh_p3xy.clone(), crate::prelude::Text::lit("prism_rtl::element_is")), move |desc_view_by_f_20699: crate::lower::model::Ex| ::prism_rtl::Turn::Finished(crate::lower::model::Ex::XBin(crate::lower::model::BinOp::OpOr, ::std::rc::Rc::new(acc_pb.clone()), ::std::rc::Rc::new(desc_view_by_f_20699))))
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::model::Ex, crate::check::env::TagInfo)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>>>
        }))
    } else {
        crate::lower::model::Ex::XIsCase(::std::rc::Rc::new(crate::lower::model::Ex::XVar(fresh_p3.clone())), crate::prelude::each(&tags_p6, &(|tg_pd: &crate::check::env::TagInfo| crate::lower::program::variant_of_f(lx_p0, tg_pd))))
    };
    PatOut { pa_p: crate::lower::model::Pa::PaBind(fresh_p3.clone()), conds_p: crate::prelude::Array::from(vec![crate::lower::model::Cc::CcIf(is_one_p7.clone())]), binds_p: crate::prelude::Array::new() }
}

/// The step machine of `FamilyPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FamilyPat: unbounded fn Lx, QualName, Ty, Text -> PatOut
/// ```
pub struct FamilyPat {
    pub lx_p0: crate::lower::Lx,
    pub q_p1: crate::syntax::QualName,
    pub ty_p2: crate::check::types::Ty,
    pub fresh_p3: crate::prelude::Text,
}

impl ::prism_rtl::Job<PatOut> for FamilyPat {
    fn cycle(&self) -> ::prism_rtl::Turn<PatOut> {
        let lx_p0 = &self.lx_p0;
        let q_p1 = &self.q_p1;
        let ty_p2 = &self.ty_p2;
        let fresh_p3 = &self.fresh_p3;
        let fam_p4 = crate::check::env::dotted_f(&crate::prelude::filter(&q_p1.path_p, &(|x_p8: &crate::prelude::Text| x_p8 != &crate::prelude::Text::lit("*"))));
        let kind_p5 = match crate::lower::types::peel_f(ty_p2) {
            crate::check::types::Ty::TyElem(_, _) => crate::prelude::Text::lit("Element"),
            crate::check::types::Ty::TyElemAny(_) => crate::prelude::Text::lit("Element"),
            crate::check::types::Ty::TyCon(k_p9, _) => k_p9,
            _ => crate::prelude::Text::lit(""),
        };
        let tags_p6 = crate::prelude::filter(&crate::lower::program::kind_tags_f(lx_p0, &kind_p5, &crate::prelude::keys(&lx_p0.rs_mods_p)), &(|tg_pa: &crate::check::env::TagInfo| &tg_pa.family_p == &fam_p4));
        let fresh_p3z = fresh_p3.clone();
        let k_let20619 = move |v20619: crate::lower::model::Ex| {
            let is_one_p7 = v20619;
            ::prism_rtl::Turn::Finished(PatOut { pa_p: crate::lower::model::Pa::PaBind(fresh_p3z.clone()), conds_p: crate::prelude::Array::from(vec![crate::lower::model::Cc::CcIf(is_one_p7.clone())]), binds_p: crate::prelude::Array::new() })
        };
        if is_live_f(ty_p2) {
            {
                let fresh_p3x = fresh_p3.clone();
                let lx_p0x = lx_p0.clone();
                crate::prelude::call_value(crate::prelude::fold_job(tags_p6.clone(), crate::lower::model::Ex::XBool(false), {
                    let lx_p0xx = lx_p0x.clone();
                    let fresh_p3xx = fresh_p3x.clone();
                    ::std::rc::Rc::new(move |(p0, p1): (crate::lower::model::Ex, crate::check::env::TagInfo)| {
                        let lx_p0xxy = lx_p0xx.clone();
                        let fresh_p3xxy = fresh_p3xx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let acc_pb = p0;
                            let tg_pc = p1;
                            crate::prelude::call_then(start_desc_view_by_f(lx_p0xxy.clone(), tg_pc.clone(), fresh_p3xxy.clone(), crate::prelude::Text::lit("prism_rtl::element_is")), move |desc_view_by_f_20699: crate::lower::model::Ex| ::prism_rtl::Turn::Finished(crate::lower::model::Ex::XBin(crate::lower::model::BinOp::OpOr, ::std::rc::Rc::new(acc_pb.clone()), ::std::rc::Rc::new(desc_view_by_f_20699))))
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::model::Ex, crate::check::env::TagInfo)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>>>
                }), move |fold_20645: crate::lower::model::Ex| k_let20619(fold_20645))
            }
        } else {
            k_let20619(crate::lower::model::Ex::XIsCase(::std::rc::Rc::new(crate::lower::model::Ex::XVar(fresh_p3.clone())), crate::prelude::each(&tags_p6, &(|tg_pd: &crate::check::env::TagInfo| crate::lower::program::variant_of_f(lx_p0, tg_pd)))))
        }
    }
}

/// `Start FamilyPat, x`: what the function value is when passed to `@Run`.
pub fn start_family_pat_f(lx_p0: crate::lower::Lx, q_p1: crate::syntax::QualName, ty_p2: crate::check::types::Ty, fresh_p3: crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<PatOut>> {
    ::std::rc::Rc::new(FamilyPat { lx_p0, q_p1, ty_p2, fresh_p3 })
}

/// ```prism
/// ErrorPat: unbounded fn Lx, [FieldPat], Ty, Holding, Text -> PatOut
/// ```
pub fn error_pat_f(lx_p0: &crate::lower::Lx, fps_p1: &crate::prelude::Array<crate::syntax::FieldPat>, ty_p2: &crate::check::types::Ty, mode_p3: &crate::lower::types::Holding, fresh_p4: &crate::prelude::Text) -> PatOut {
    let e_p5 = crate::lower::types::local_place_f(&crate::lower::model::Ex::XVar(fresh_p4.clone()), mode_p3, &crate::lower::model::OutTy::OutError);
    let parts_p6 = crate::prelude::run_to_end(crate::prelude::each_job(fps_p1.clone(), {
        let lx_p0x = lx_p0.clone();
        let fresh_p4x = fresh_p4.clone();
        ::std::rc::Rc::new(move |p0: crate::syntax::FieldPat| {
            let lx_p0xy = lx_p0x.clone();
            let fresh_p4xy = fresh_p4x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let fp_p8 = p0;
                {
                    let fname_p9 = match &fp_p8.name_o {
                        ::std::option::Option::Some(id_pa) => id_pa.name_p.clone(),
                        ::std::option::Option::None => crate::prelude::Text::lit(""),
                    };
                    match &fname_p9 {
                        m21239_0 if (m21239_0 == &crate::prelude::Text::lit("kind")) => match &*fp_p8.pattern_p.kind_p {
                            crate::syntax::PatternKind::PName(k_pb) => {
                                let (kq_oc, _) = crate::check::env::names::resolve_value_f(&lx_p0xy.g_p, &lx_p0xy.home_p, k_pb);
                                match &kq_oc {
                                    ::std::option::Option::Some(kq_pd) => if crate::check::env::has_key_f(&lx_p0xy.g_p.tags_p, kq_pd) {
                                        ::prism_rtl::Turn::Finished((crate::prelude::Array::from(vec![crate::lower::model::Cc::CcIf(crate::lower::model::Ex::XBin(crate::lower::model::BinOp::OpEq, ::std::rc::Rc::new(crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XDeref(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XVar(fresh_p4xy.clone())), crate::prelude::Text::lit("kind_p"))))))), ::std::rc::Rc::new(crate::lower::model::Ex::XStr(kq_pd.clone()))))]), crate::prelude::Array::new()))
                                    } else {
                                        ::prism_rtl::Turn::Finished((crate::prelude::Array::new(), crate::prelude::Array::from(vec![(crate::check::env::sname_key_f(k_pb), crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XCall(crate::lower::helper_ref_f(&crate::prelude::Text::lit("kind_of")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XVar(fresh_p4xy.clone())))])), crate::lower::types::Holding::Owned, crate::lower::model::OutTy::OutPod))])))
                                    },
                                    ::std::option::Option::None => ::prism_rtl::Turn::Finished((crate::prelude::Array::new(), crate::prelude::Array::from(vec![(crate::check::env::sname_key_f(k_pb), crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XCall(crate::lower::helper_ref_f(&crate::prelude::Text::lit("kind_of")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XVar(fresh_p4xy.clone())))])), crate::lower::types::Holding::Owned, crate::lower::model::OutTy::OutPod))]))),
                                }
                            },
                            crate::syntax::PatternKind::PRecord(k_pe, kfps_pf, _) => {
                                let (kq_oh, _) = crate::check::env::names::resolve_value_f(&lx_p0xy.g_p, &lx_p0xy.home_p, k_pe);
                                let kind_tag_og = match &kq_oh {
                                    ::std::option::Option::Some(kq_pi) => crate::prelude::get(&lx_p0xy.g_p.tags_p, kq_pi),
                                    ::std::option::Option::None => ::std::option::Option::None,
                                };
                                match &kind_tag_og {
                                    ::std::option::Option::Some(tg_pj) => {
                                        let named_pk = crate::lower::model::Cc::CcIf(crate::lower::model::Ex::XBin(crate::lower::model::BinOp::OpEq, ::std::rc::Rc::new(crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XDeref(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XVar(fresh_p4xy.clone())), crate::prelude::Text::lit("kind_p"))))))), ::std::rc::Rc::new(crate::lower::model::Ex::XStr(tg_pj.name_p.clone()))));
                                        let names_pl = crate::prelude::each(&tg_pj.fields_p, &(|(f_pm, _): &(crate::prelude::Text, crate::check::types::Ty)| f_pm.clone()));
                                        crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(kfps_pf)), (crate::prelude::Array::from(vec![named_pk.clone()]), crate::prelude::Array::new()), {
                                            let kfps_pfx = kfps_pf.clone();
                                            let names_plx = names_pl.clone();
                                            let tg_pjx = tg_pj.clone();
                                            let fname_p9x = fname_p9.clone();
                                            let fresh_p4xyx = fresh_p4xy.clone();
                                            let lx_p0xyx = lx_p0xy.clone();
                                            ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Array<crate::lower::model::Cc>, crate::prelude::Array<(crate::prelude::Text, crate::lower::types::Bn)>), crate::prelude::Nat)| {
                                                let kfps_pfxy = kfps_pfx.clone();
                                                let names_plxy = names_plx.clone();
                                                let tg_pjxy = tg_pjx.clone();
                                                let fname_p9xy = fname_p9x.clone();
                                                let fresh_p4xyxy = fresh_p4xyx.clone();
                                                let lx_p0xyxy = lx_p0xyx.clone();
                                                crate::prelude::entered(crate::prelude::once_job(move || {
                                                    let (cs_pn, bs_po) = p0;
                                                    let i_pp = p1;
                                                    {
                                                        let kfp_pq = crate::prelude::or(&crate::prelude::index(&kfps_pfxy, &i_pp), &dummy_field_pat_p());
                                                        let fname_pr = tag_field_name_f(&kfp_pq, &names_plxy, &i_pp);
                                                        let ft_ps = crate::prelude::fold(&tg_pjxy.fields_p, &crate::check::types::Ty::TyErr, &(|found_p10: &crate::check::types::Ty, (f_p11, t_p12): &(crate::prelude::Text, crate::check::types::Ty)| if f_p11 == &fname_pr { t_p12.clone() } else { found_p10.clone() }));
                                                        let local_pt = crate::prelude::Text::from(format!("{}_k{}", &fresh_p4xyxy, &i_pp));
                                                        crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0xyxy.clone(), crate::lower::types::peel_f(&ft_ps)), move |out_ty_of_f_23042: crate::lower::model::OutTy| {
                                                            let read_pu = crate::lower::model::Ex::XCallAt(crate::lower::helper_ref_f(&crate::prelude::Text::lit("fault_field")), crate::prelude::Array::from(vec![out_ty_of_f_23042]), crate::prelude::Array::from(vec![crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XVar(fresh_p4xyxy.clone()))), crate::lower::model::Ex::XStr(fname_pr.clone())]));
                                                            crate::prelude::call_then(start_rust_pat_f(lx_p0xyxy.clone(), kfp_pq.pattern_p.clone(), crate::lower::types::peel_f(&ft_ps), crate::lower::types::Holding::ByRef, crate::prelude::Text::from(format!("{}_p", &local_pt))), move |rust_pat_f_23146: PatOut| {
                                                                let o_pv = rust_pat_f_23146;
                                                                ::prism_rtl::Turn::Finished((crate::prelude::append(&crate::prelude::push(&cs_pn, &crate::lower::model::Cc::CcLet(o_pv.pa_p.clone(), crate::lower::model::Ex::XRef(::std::rc::Rc::new(read_pu.clone())))), &o_pv.conds_p), crate::prelude::append(&bs_po, &o_pv.binds_p)))
                                                            })
                                                        })
                                                    }
                                                }))
                                            }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Array<crate::lower::model::Cc>, crate::prelude::Array<(crate::prelude::Text, crate::lower::types::Bn)>), crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<crate::lower::model::Cc>, crate::prelude::Array<(crate::prelude::Text, crate::lower::types::Bn)>)>>>
                                        }).cycle()
                                    },
                                    ::std::option::Option::None => ::prism_rtl::Turn::Finished((crate::prelude::Array::from(vec![crate::lower::model::Cc::CcIf(crate::lower::expr::internal_bug_f(&crate::prelude::Text::lit("an `Error`\'s kind matched against what is no fault kind")))]), crate::prelude::Array::new())),
                                }
                            },
                            _ => ::prism_rtl::Turn::Finished((crate::prelude::Array::new(), crate::prelude::Array::new())),
                        },
                        m21239_1 if (m21239_1 == &crate::prelude::Text::lit("message")) => match &*fp_p8.pattern_p.kind_p {
                            crate::syntax::PatternKind::PName(m_p13) => ::prism_rtl::Turn::Finished((crate::prelude::Array::new(), crate::prelude::Array::from(vec![(crate::check::env::sname_key_f(m_p13), crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XVar(fresh_p4xy.clone())), crate::prelude::Text::lit("message_p")), crate::lower::types::Holding::Owned, crate::lower::model::OutTy::OutText))]))),
                            _ => ::prism_rtl::Turn::Finished((crate::prelude::Array::new(), crate::prelude::Array::new())),
                        },
                        _ => ::prism_rtl::Turn::Finished((crate::prelude::Array::new(), crate::prelude::Array::new())),
                        _ => unreachable!("no arm matched"),
                    }
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::syntax::FieldPat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<crate::lower::model::Cc>, crate::prelude::Array<(crate::prelude::Text, crate::lower::types::Bn)>)>>>
    }));
    let wrapped_p7 = match crate::lower::types::peel_f(ty_p2) {
        crate::check::types::Ty::TySig(m23736_0_0, _) if (&m23736_0_0 == &crate::prelude::Text::lit("~")) => crate::lower::model::Pa::PaCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Err")), crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(fresh_p4.clone())])),
        _ => crate::lower::model::Pa::PaBind(fresh_p4.clone()),
        _ => unreachable!("no arm matched"),
    };
    PatOut { pa_p: wrapped_p7.clone(), conds_p: crate::prelude::fold(&parts_p6, &crate::prelude::Array::new(), &(|acc_p14: &crate::prelude::Array<crate::lower::model::Cc>, (cs_p15, _): &(crate::prelude::Array<crate::lower::model::Cc>, crate::prelude::Array<(crate::prelude::Text, crate::lower::types::Bn)>)| crate::prelude::append(acc_p14, cs_p15))), binds_p: crate::prelude::fold(&parts_p6, &crate::prelude::Array::new(), &(|acc_p16: &crate::prelude::Array<(crate::prelude::Text, crate::lower::types::Bn)>, (_, bs_p17): &(crate::prelude::Array<crate::lower::model::Cc>, crate::prelude::Array<(crate::prelude::Text, crate::lower::types::Bn)>)| crate::prelude::append(acc_p16, bs_p17))) }
}

/// The step machine of `ErrorPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ErrorPat: unbounded fn Lx, [FieldPat], Ty, Holding, Text -> PatOut
/// ```
pub struct ErrorPat {
    pub lx_p0: crate::lower::Lx,
    pub fps_p1: crate::prelude::Array<crate::syntax::FieldPat>,
    pub ty_p2: crate::check::types::Ty,
    pub mode_p3: crate::lower::types::Holding,
    pub fresh_p4: crate::prelude::Text,
}

impl ::prism_rtl::Job<PatOut> for ErrorPat {
    fn cycle(&self) -> ::prism_rtl::Turn<PatOut> {
        let lx_p0 = &self.lx_p0;
        let fps_p1 = &self.fps_p1;
        let ty_p2 = &self.ty_p2;
        let mode_p3 = &self.mode_p3;
        let fresh_p4 = &self.fresh_p4;
        let e_p5 = crate::lower::types::local_place_f(&crate::lower::model::Ex::XVar(fresh_p4.clone()), mode_p3, &crate::lower::model::OutTy::OutError);
        let fps_p1x = fps_p1.clone();
        let fresh_p4x = fresh_p4.clone();
        let lx_p0x = lx_p0.clone();
        let ty_p2x = ty_p2.clone();
        crate::prelude::call_value(crate::prelude::each_job(fps_p1x.clone(), {
            let lx_p0xx = lx_p0x.clone();
            let fresh_p4xx = fresh_p4x.clone();
            ::std::rc::Rc::new(move |p0: crate::syntax::FieldPat| {
                let lx_p0xxy = lx_p0xx.clone();
                let fresh_p4xxy = fresh_p4xx.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let fp_p8 = p0;
                    {
                        let fname_p9 = match &fp_p8.name_o {
                            ::std::option::Option::Some(id_pa) => id_pa.name_p.clone(),
                            ::std::option::Option::None => crate::prelude::Text::lit(""),
                        };
                        match &fname_p9 {
                            m21239_0 if (m21239_0 == &crate::prelude::Text::lit("kind")) => match &*fp_p8.pattern_p.kind_p {
                                crate::syntax::PatternKind::PName(k_pb) => {
                                    let (kq_oc, _) = crate::check::env::names::resolve_value_f(&lx_p0xxy.g_p, &lx_p0xxy.home_p, k_pb);
                                    match &kq_oc {
                                        ::std::option::Option::Some(kq_pd) => if crate::check::env::has_key_f(&lx_p0xxy.g_p.tags_p, kq_pd) {
                                            ::prism_rtl::Turn::Finished((crate::prelude::Array::from(vec![crate::lower::model::Cc::CcIf(crate::lower::model::Ex::XBin(crate::lower::model::BinOp::OpEq, ::std::rc::Rc::new(crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XDeref(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XVar(fresh_p4xxy.clone())), crate::prelude::Text::lit("kind_p"))))))), ::std::rc::Rc::new(crate::lower::model::Ex::XStr(kq_pd.clone()))))]), crate::prelude::Array::new()))
                                        } else {
                                            ::prism_rtl::Turn::Finished((crate::prelude::Array::new(), crate::prelude::Array::from(vec![(crate::check::env::sname_key_f(k_pb), crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XCall(crate::lower::helper_ref_f(&crate::prelude::Text::lit("kind_of")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XVar(fresh_p4xxy.clone())))])), crate::lower::types::Holding::Owned, crate::lower::model::OutTy::OutPod))])))
                                        },
                                        ::std::option::Option::None => ::prism_rtl::Turn::Finished((crate::prelude::Array::new(), crate::prelude::Array::from(vec![(crate::check::env::sname_key_f(k_pb), crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XCall(crate::lower::helper_ref_f(&crate::prelude::Text::lit("kind_of")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XVar(fresh_p4xxy.clone())))])), crate::lower::types::Holding::Owned, crate::lower::model::OutTy::OutPod))]))),
                                    }
                                },
                                crate::syntax::PatternKind::PRecord(k_pe, kfps_pf, _) => {
                                    let (kq_oh, _) = crate::check::env::names::resolve_value_f(&lx_p0xxy.g_p, &lx_p0xxy.home_p, k_pe);
                                    let kind_tag_og = match &kq_oh {
                                        ::std::option::Option::Some(kq_pi) => crate::prelude::get(&lx_p0xxy.g_p.tags_p, kq_pi),
                                        ::std::option::Option::None => ::std::option::Option::None,
                                    };
                                    match &kind_tag_og {
                                        ::std::option::Option::Some(tg_pj) => {
                                            let named_pk = crate::lower::model::Cc::CcIf(crate::lower::model::Ex::XBin(crate::lower::model::BinOp::OpEq, ::std::rc::Rc::new(crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XDeref(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XVar(fresh_p4xxy.clone())), crate::prelude::Text::lit("kind_p"))))))), ::std::rc::Rc::new(crate::lower::model::Ex::XStr(tg_pj.name_p.clone()))));
                                            let names_pl = crate::prelude::each(&tg_pj.fields_p, &(|(f_pm, _): &(crate::prelude::Text, crate::check::types::Ty)| f_pm.clone()));
                                            crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(kfps_pf)), (crate::prelude::Array::from(vec![named_pk.clone()]), crate::prelude::Array::new()), {
                                                let kfps_pfx = kfps_pf.clone();
                                                let names_plx = names_pl.clone();
                                                let tg_pjx = tg_pj.clone();
                                                let fname_p9x = fname_p9.clone();
                                                let fresh_p4xxyx = fresh_p4xxy.clone();
                                                let lx_p0xxyx = lx_p0xxy.clone();
                                                ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Array<crate::lower::model::Cc>, crate::prelude::Array<(crate::prelude::Text, crate::lower::types::Bn)>), crate::prelude::Nat)| {
                                                    let kfps_pfxy = kfps_pfx.clone();
                                                    let names_plxy = names_plx.clone();
                                                    let tg_pjxy = tg_pjx.clone();
                                                    let fname_p9xy = fname_p9x.clone();
                                                    let fresh_p4xxyxy = fresh_p4xxyx.clone();
                                                    let lx_p0xxyxy = lx_p0xxyx.clone();
                                                    crate::prelude::entered(crate::prelude::once_job(move || {
                                                        let (cs_pn, bs_po) = p0;
                                                        let i_pp = p1;
                                                        {
                                                            let kfp_pq = crate::prelude::or(&crate::prelude::index(&kfps_pfxy, &i_pp), &dummy_field_pat_p());
                                                            let fname_pr = tag_field_name_f(&kfp_pq, &names_plxy, &i_pp);
                                                            let ft_ps = crate::prelude::fold(&tg_pjxy.fields_p, &crate::check::types::Ty::TyErr, &(|found_p10: &crate::check::types::Ty, (f_p11, t_p12): &(crate::prelude::Text, crate::check::types::Ty)| if f_p11 == &fname_pr { t_p12.clone() } else { found_p10.clone() }));
                                                            let local_pt = crate::prelude::Text::from(format!("{}_k{}", &fresh_p4xxyxy, &i_pp));
                                                            crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0xxyxy.clone(), crate::lower::types::peel_f(&ft_ps)), move |out_ty_of_f_23042: crate::lower::model::OutTy| {
                                                                let read_pu = crate::lower::model::Ex::XCallAt(crate::lower::helper_ref_f(&crate::prelude::Text::lit("fault_field")), crate::prelude::Array::from(vec![out_ty_of_f_23042]), crate::prelude::Array::from(vec![crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XVar(fresh_p4xxyxy.clone()))), crate::lower::model::Ex::XStr(fname_pr.clone())]));
                                                                crate::prelude::call_then(start_rust_pat_f(lx_p0xxyxy.clone(), kfp_pq.pattern_p.clone(), crate::lower::types::peel_f(&ft_ps), crate::lower::types::Holding::ByRef, crate::prelude::Text::from(format!("{}_p", &local_pt))), move |rust_pat_f_23146: PatOut| {
                                                                    let o_pv = rust_pat_f_23146;
                                                                    ::prism_rtl::Turn::Finished((crate::prelude::append(&crate::prelude::push(&cs_pn, &crate::lower::model::Cc::CcLet(o_pv.pa_p.clone(), crate::lower::model::Ex::XRef(::std::rc::Rc::new(read_pu.clone())))), &o_pv.conds_p), crate::prelude::append(&bs_po, &o_pv.binds_p)))
                                                                })
                                                            })
                                                        }
                                                    }))
                                                }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Array<crate::lower::model::Cc>, crate::prelude::Array<(crate::prelude::Text, crate::lower::types::Bn)>), crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<crate::lower::model::Cc>, crate::prelude::Array<(crate::prelude::Text, crate::lower::types::Bn)>)>>>
                                            }).cycle()
                                        },
                                        ::std::option::Option::None => ::prism_rtl::Turn::Finished((crate::prelude::Array::from(vec![crate::lower::model::Cc::CcIf(crate::lower::expr::internal_bug_f(&crate::prelude::Text::lit("an `Error`\'s kind matched against what is no fault kind")))]), crate::prelude::Array::new())),
                                    }
                                },
                                _ => ::prism_rtl::Turn::Finished((crate::prelude::Array::new(), crate::prelude::Array::new())),
                            },
                            m21239_1 if (m21239_1 == &crate::prelude::Text::lit("message")) => match &*fp_p8.pattern_p.kind_p {
                                crate::syntax::PatternKind::PName(m_p13) => ::prism_rtl::Turn::Finished((crate::prelude::Array::new(), crate::prelude::Array::from(vec![(crate::check::env::sname_key_f(m_p13), crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XVar(fresh_p4xxy.clone())), crate::prelude::Text::lit("message_p")), crate::lower::types::Holding::Owned, crate::lower::model::OutTy::OutText))]))),
                                _ => ::prism_rtl::Turn::Finished((crate::prelude::Array::new(), crate::prelude::Array::new())),
                            },
                            _ => ::prism_rtl::Turn::Finished((crate::prelude::Array::new(), crate::prelude::Array::new())),
                            _ => unreachable!("no arm matched"),
                        }
                    }
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::syntax::FieldPat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<crate::lower::model::Cc>, crate::prelude::Array<(crate::prelude::Text, crate::lower::types::Bn)>)>>>
        }), move |each_21133: crate::prelude::Array<(crate::prelude::Array<crate::lower::model::Cc>, crate::prelude::Array<(crate::prelude::Text, crate::lower::types::Bn)>)>| {
            let parts_p6 = each_21133;
            let wrapped_p7 = match crate::lower::types::peel_f(&ty_p2x) {
                crate::check::types::Ty::TySig(m23736_0_0, _) if (&m23736_0_0 == &crate::prelude::Text::lit("~")) => crate::lower::model::Pa::PaCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Err")), crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(fresh_p4x.clone())])),
                _ => crate::lower::model::Pa::PaBind(fresh_p4x.clone()),
                _ => unreachable!("no arm matched"),
            };
            ::prism_rtl::Turn::Finished(PatOut { pa_p: wrapped_p7.clone(), conds_p: crate::prelude::fold(&parts_p6, &crate::prelude::Array::new(), &(|acc_p14: &crate::prelude::Array<crate::lower::model::Cc>, (cs_p15, _): &(crate::prelude::Array<crate::lower::model::Cc>, crate::prelude::Array<(crate::prelude::Text, crate::lower::types::Bn)>)| crate::prelude::append(acc_p14, cs_p15))), binds_p: crate::prelude::fold(&parts_p6, &crate::prelude::Array::new(), &(|acc_p16: &crate::prelude::Array<(crate::prelude::Text, crate::lower::types::Bn)>, (_, bs_p17): &(crate::prelude::Array<crate::lower::model::Cc>, crate::prelude::Array<(crate::prelude::Text, crate::lower::types::Bn)>)| crate::prelude::append(acc_p16, bs_p17))) })
        })
    }
}

/// `Start ErrorPat, x`: what the function value is when passed to `@Run`.
pub fn start_error_pat_f(lx_p0: crate::lower::Lx, fps_p1: crate::prelude::Array<crate::syntax::FieldPat>, ty_p2: crate::check::types::Ty, mode_p3: crate::lower::types::Holding, fresh_p4: crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<PatOut>> {
    ::std::rc::Rc::new(ErrorPat { lx_p0, fps_p1, ty_p2, mode_p3, fresh_p4 })
}

/// ```prism
/// ArrayPat: unbounded fn Lx, [Pattern], Ty, Holding, Text -> PatOut
/// ```
pub fn array_pat_f(lx_p0: &crate::lower::Lx, ps_p1: &crate::prelude::Array<crate::syntax::Pattern>, ty_p2: &crate::check::types::Ty, mode_p3: &crate::lower::types::Holding, fresh_p4: &crate::prelude::Text) -> PatOut {
    let et_p5 = match crate::lower::types::collection_f(&crate::lower::types::peel_f(ty_p2)) {
        crate::check::types::Ty::TyArray(x_pb) => (*x_pb).clone(),
        _ => crate::check::types::Ty::TyErr,
    };
    let arr_p6 = crate::lower::types::plain_value_f(&crate::lower::types::local_place_f(&crate::lower::model::Ex::XVar(fresh_p4.clone()), mode_p3, &crate::lower::types::out_ty_of_f(lx_p0, &crate::lower::types::peel_f(ty_p2))));
    let len_cond_p7 = crate::lower::model::Cc::CcIf(crate::lower::model::Ex::XBin(crate::lower::model::BinOp::OpEq, ::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::types::ref_f(&arr_p6)), crate::prelude::Text::lit("len"), crate::prelude::Array::new())), ::std::rc::Rc::new(crate::lower::model::Ex::XIndex(crate::prelude::len(ps_p1)))));
    let subs_p8 = crate::prelude::run_to_end(crate::prelude::each_job(crate::check::errors::range0_f(&crate::prelude::len(ps_p1)), {
        let lx_p0x = lx_p0.clone();
        let ps_p1x = ps_p1.clone();
        let et_p5x = et_p5.clone();
        let fresh_p4x = fresh_p4.clone();
        ::std::rc::Rc::new(move |p0: crate::prelude::Nat| {
            let lx_p0xy = lx_p0x.clone();
            let ps_p1xy = ps_p1x.clone();
            let et_p5xy = et_p5x.clone();
            let fresh_p4xy = fresh_p4x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let i_pc = p0;
                crate::prelude::call_then(start_rust_pat_f(lx_p0xy.clone(), crate::prelude::or(&crate::prelude::index(&ps_p1xy, &i_pc), &dummy_pat_p()), et_p5xy.clone(), crate::lower::types::Holding::Owned, crate::prelude::Text::from(format!("{}_{}", &fresh_p4xy, &i_pc))), move |rust_pat_f_24533: PatOut| ::prism_rtl::Turn::Finished((i_pc.clone(), rust_pat_f_24533)))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Nat, PatOut)>>>
    }));
    let conds_p9 = crate::prelude::fold(&subs_p8, &crate::prelude::Array::from(vec![len_cond_p7.clone()]), &(|acc_pd: &crate::prelude::Array<crate::lower::model::Cc>, (i_pe, o_pf): &(crate::prelude::Nat, PatOut)| crate::prelude::append(&crate::prelude::push(acc_pd, &crate::lower::model::Cc::CcLet(crate::lower::model::Pa::PaCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Some")), crate::prelude::Array::from(vec![o_pf.pa_p.clone()])), crate::lower::model::Ex::XCall(crate::lower::helper_ref_f(&crate::prelude::Text::lit("index")), crate::prelude::Array::from(vec![crate::lower::types::ref_f(&arr_p6), crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XNat(crate::prelude::Text::from(format!("{}", i_pe)))))])))), &o_pf.conds_p)));
    let binds_pa = crate::prelude::fold(&subs_p8, &crate::prelude::Array::new(), &(|acc_pg: &crate::prelude::Array<(crate::prelude::Text, crate::lower::types::Bn)>, (_, o_ph): &(crate::prelude::Nat, PatOut)| crate::prelude::append(acc_pg, &o_ph.binds_p)));
    PatOut { pa_p: crate::lower::model::Pa::PaBind(fresh_p4.clone()), conds_p: conds_p9.clone(), binds_p: binds_pa.clone() }
}

/// The step machine of `ArrayPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ArrayPat: unbounded fn Lx, [Pattern], Ty, Holding, Text -> PatOut
/// ```
pub struct ArrayPat {
    pub lx_p0: crate::lower::Lx,
    pub ps_p1: crate::prelude::Array<crate::syntax::Pattern>,
    pub ty_p2: crate::check::types::Ty,
    pub mode_p3: crate::lower::types::Holding,
    pub fresh_p4: crate::prelude::Text,
}

impl ::prism_rtl::Job<PatOut> for ArrayPat {
    fn cycle(&self) -> ::prism_rtl::Turn<PatOut> {
        let lx_p0 = &self.lx_p0;
        let ps_p1 = &self.ps_p1;
        let ty_p2 = &self.ty_p2;
        let mode_p3 = &self.mode_p3;
        let fresh_p4 = &self.fresh_p4;
        let et_p5 = match crate::lower::types::collection_f(&crate::lower::types::peel_f(ty_p2)) {
            crate::check::types::Ty::TyArray(x_pb) => (*x_pb).clone(),
            _ => crate::check::types::Ty::TyErr,
        };
        let fresh_p4x = fresh_p4.clone();
        let lx_p0x = lx_p0.clone();
        let mode_p3x = mode_p3.clone();
        let ps_p1x = ps_p1.clone();
        let ty_p2x = ty_p2.clone();
        crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0x.clone(), crate::lower::types::peel_f(&ty_p2x)), move |out_ty_of_f_24371: crate::lower::model::OutTy| {
            let arr_p6 = crate::lower::types::plain_value_f(&crate::lower::types::local_place_f(&crate::lower::model::Ex::XVar(fresh_p4x.clone()), &mode_p3x, &out_ty_of_f_24371));
            let len_cond_p7 = crate::lower::model::Cc::CcIf(crate::lower::model::Ex::XBin(crate::lower::model::BinOp::OpEq, ::std::rc::Rc::new(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(crate::lower::types::ref_f(&arr_p6)), crate::prelude::Text::lit("len"), crate::prelude::Array::new())), ::std::rc::Rc::new(crate::lower::model::Ex::XIndex(crate::prelude::len(&ps_p1x)))));
            crate::prelude::call_value(crate::prelude::each_job(crate::check::errors::range0_f(&crate::prelude::len(&ps_p1x)), {
                let lx_p0xx = lx_p0x.clone();
                let ps_p1xx = ps_p1x.clone();
                let et_p5x = et_p5.clone();
                let fresh_p4xx = fresh_p4x.clone();
                ::std::rc::Rc::new(move |p0: crate::prelude::Nat| {
                    let lx_p0xxy = lx_p0xx.clone();
                    let ps_p1xxy = ps_p1xx.clone();
                    let et_p5xy = et_p5x.clone();
                    let fresh_p4xxy = fresh_p4xx.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let i_pc = p0;
                        crate::prelude::call_then(start_rust_pat_f(lx_p0xxy.clone(), crate::prelude::or(&crate::prelude::index(&ps_p1xxy, &i_pc), &dummy_pat_p()), et_p5xy.clone(), crate::lower::types::Holding::Owned, crate::prelude::Text::from(format!("{}_{}", &fresh_p4xxy, &i_pc))), move |rust_pat_f_24533: PatOut| ::prism_rtl::Turn::Finished((i_pc.clone(), rust_pat_f_24533)))
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Nat, PatOut)>>>
            }), move |each_24498: crate::prelude::Array<(crate::prelude::Nat, PatOut)>| {
                let subs_p8 = each_24498;
                let conds_p9 = crate::prelude::fold(&subs_p8, &crate::prelude::Array::from(vec![len_cond_p7.clone()]), &(|acc_pd: &crate::prelude::Array<crate::lower::model::Cc>, (i_pe, o_pf): &(crate::prelude::Nat, PatOut)| crate::prelude::append(&crate::prelude::push(acc_pd, &crate::lower::model::Cc::CcLet(crate::lower::model::Pa::PaCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Some")), crate::prelude::Array::from(vec![o_pf.pa_p.clone()])), crate::lower::model::Ex::XCall(crate::lower::helper_ref_f(&crate::prelude::Text::lit("index")), crate::prelude::Array::from(vec![crate::lower::types::ref_f(&arr_p6), crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XNat(crate::prelude::Text::from(format!("{}", i_pe)))))])))), &o_pf.conds_p)));
                let binds_pa = crate::prelude::fold(&subs_p8, &crate::prelude::Array::new(), &(|acc_pg: &crate::prelude::Array<(crate::prelude::Text, crate::lower::types::Bn)>, (_, o_ph): &(crate::prelude::Nat, PatOut)| crate::prelude::append(acc_pg, &o_ph.binds_p)));
                ::prism_rtl::Turn::Finished(PatOut { pa_p: crate::lower::model::Pa::PaBind(fresh_p4x.clone()), conds_p: conds_p9.clone(), binds_p: binds_pa.clone() })
            })
        })
    }
}

/// `Start ArrayPat, x`: what the function value is when passed to `@Run`.
pub fn start_array_pat_f(lx_p0: crate::lower::Lx, ps_p1: crate::prelude::Array<crate::syntax::Pattern>, ty_p2: crate::check::types::Ty, mode_p3: crate::lower::types::Holding, fresh_p4: crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<PatOut>> {
    ::std::rc::Rc::new(ArrayPat { lx_p0, ps_p1, ty_p2, mode_p3, fresh_p4 })
}
