//! The module `Lower.Patterns`, from `target/bootstrap/src/prismc/lower/patterns.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// `PatOut`:
///
/// ```prism
/// type PatOut = record:
/// ```
#[derive(Clone)]
pub struct PatOut {
    pub pa: crate::lower::model::Pa,
    pub conds: Array<crate::lower::model::Cc>,
    pub binds: Array<(Text, crate::lower::types::Bn)>,
}

/// ```prism
/// PatOnly: fn Pa -> PatOut
/// ```
pub fn pat_only(pa: &crate::lower::model::Pa) -> PatOut {
    PatOut { pa: pa.clone(), conds: Array::new(), binds: Array::new() }
}

/// ```prism
/// RustPat: unbounded fn Lx, Pattern, Ty, Holding, Text -> PatOut
/// ```
pub fn rust_pat(lx: &crate::lower::Lx, p_: &crate::syntax::Pattern_, ty: &crate::check::types::Ty, mode: &crate::lower::types::Holding, fresh: &Text) -> PatOut {
    match &*p_.kind {
        crate::syntax::PatternKind::PName(n) => {
            let nkey = crate::check::env::sname_key(n);
            let (qk_opt, why) = crate::check::env::names::resolve_value(&lx.g, &lx.home, n);
            let is_ctor = match &qk_opt {
                Some(qk) => crate::check::env::has_key(&lx.g.ctors, qk) && ((crate::check::env::is_upper_text(&crate::lower::base(&nkey)) || (&len(&n.path_) > &Nat::from(1u32))) || is_unit_ctor(lx, qk)),
                None => false,
            };
            let tagged_opt = match &qk_opt {
                Some(qk) => get(&lx.g.tags, qk),
                None => None,
            };
            if is_ctor {
                ctor_pat(lx, n, &Array::new(), ty, mode, fresh)
            } else {
                if (&why == &Text::lit("tag")) && (&tagged_opt != &None) {
                    tag_pat(lx, &or(&tagged_opt, &dummy_tag_info()), &Array::new(), &true, ty, mode, fresh)
                } else {
                    {
                        let rs = crate::lower::local_name(lx, &nkey);
                        let bt = crate::lower::types::out_ty_of(lx, &crate::lower::types::peel(&crate::lower::binder_ty(lx, &n.span)));
                        PatOut { pa: crate::lower::model::Pa::PaBind(rs.clone()), conds: Array::new(), binds: Array::from(vec![(nkey.clone(), crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(rs.clone()), mode.clone(), bt.clone()))]) }
                    }
                }
            }
        },
        crate::syntax::PatternKind::PIgnore => pat_only(&crate::lower::model::Pa::PaWild),
        crate::syntax::PatternKind::PUnit => pat_only(&crate::lower::model::Pa::PaWild),
        crate::syntax::PatternKind::PNil => pat_only(&crate::lower::model::Pa::PaUnit(Text::lit("None"))),
        crate::syntax::PatternKind::PLit(l) => lit_pat(lx, l, ty, mode, fresh, &false),
        crate::syntax::PatternKind::PNeg(l) => lit_pat(lx, l, ty, mode, fresh, &true),
        crate::syntax::PatternKind::PSigil(m1652_6_0, q) if (m1652_6_0 == &Text::lit("?")) => wrap_pat(lx, &Text::lit("Some"), &**q, &inner_ty(ty), mode, fresh),
        crate::syntax::PatternKind::PSigil(m1652_7_0, q) if (m1652_7_0 == &Text::lit("~")) => wrap_pat(lx, &Text::lit("Ok"), &**q, &inner_ty(ty), mode, fresh),
        crate::syntax::PatternKind::PSigil(_, q) => rust_pat(lx, &**q, ty, mode, fresh),
        crate::syntax::PatternKind::PGroup(q) => rust_pat(lx, &**q, ty, mode, fresh),
        crate::syntax::PatternKind::PCtor(n, ps) => ctor_pat(lx, n, ps, ty, mode, fresh),
        crate::syntax::PatternKind::PRecord(n, fps, rest) => record_pat(lx, n, fps, rest, ty, mode, fresh),
        crate::syntax::PatternKind::PTuple(ps) => {
            let ts = match crate::lower::types::peel(ty) {
                crate::check::types::Ty::TyTuple(xs) => xs,
                _ => Array::new(),
            };
            let subs = run_to_end(each_job(crate::check::errors::range0(&len(ps)), {
                let lx = lx.clone();
                let ps = ps.clone();
                let ts = ts.clone();
                let mode = mode.clone();
                let fresh = fresh.clone();
                Rc::new(move |p0: Nat| {
                    let lx = lx.clone();
                    let ps = ps.clone();
                    let ts = ts.clone();
                    let mode = mode.clone();
                    let fresh = fresh.clone();
                    entered(once_job(move || {
                        let i = p0;
                        prism_rtl::Turn::More(Rc::new(RustPat { lx: lx.clone(), p_: or(&index(&ps, &i), &dummy_pat()), ty: or(&index(&ts, &i), &crate::check::types::Ty::TyErr), mode: mode.clone(), fresh: Text::from(format!("{}_{}", &fresh, &i)) }))
                    }))
                }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<PatOut>>>
            }));
            PatOut { pa: crate::lower::model::Pa::PaTuple(each(&subs, &(|o: &PatOut| o.pa.clone()))), conds: fold(&subs, &Array::new(), &(|acc: &Array<crate::lower::model::Cc>, o: &PatOut| append(acc, &o.conds))), binds: fold(&subs, &Array::new(), &(|acc: &Array<(Text, crate::lower::types::Bn)>, o: &PatOut| append(acc, &o.binds))) }
        },
        crate::syntax::PatternKind::PArray(ps) => array_pat(lx, ps, ty, mode, fresh),
        crate::syntax::PatternKind::PFamily(q) => family_pat(lx, q, ty, fresh),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `RustPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RustPat: unbounded fn Lx, Pattern, Ty, Holding, Text -> PatOut
/// ```
pub struct RustPat {
    pub lx: crate::lower::Lx,
    pub p_: crate::syntax::Pattern_,
    pub ty: crate::check::types::Ty,
    pub mode: crate::lower::types::Holding,
    pub fresh: Text,
}

impl prism_rtl::Job<PatOut> for RustPat {
    fn cycle(&self) -> prism_rtl::Turn<PatOut> {
        let lx = &self.lx;
        let p_ = &self.p_;
        let ty = &self.ty;
        let mode = &self.mode;
        let fresh = &self.fresh;
        match &*p_.kind {
            crate::syntax::PatternKind::PName(n) => {
                let nkey = crate::check::env::sname_key(n);
                let (qk_opt, why) = crate::check::env::names::resolve_value(&lx.g, &lx.home, n);
                let is_ctor = match &qk_opt {
                    Some(qk) => crate::check::env::has_key(&lx.g.ctors, qk) && ((crate::check::env::is_upper_text(&crate::lower::base(&nkey)) || (&len(&n.path_) > &Nat::from(1u32))) || is_unit_ctor(lx, qk)),
                    None => false,
                };
                let tagged_opt = match &qk_opt {
                    Some(qk) => get(&lx.g.tags, qk),
                    None => None,
                };
                if is_ctor {
                    prism_rtl::Turn::More(Rc::new(CtorPat { lx: lx.clone(), n: n.clone(), ps: Array::new(), ty: ty.clone(), mode: mode.clone(), fresh: fresh.clone() }))
                } else {
                    if (&why == &Text::lit("tag")) && (&tagged_opt != &None) {
                        prism_rtl::Turn::More(Rc::new(TagPat { lx: lx.clone(), tg: or(&tagged_opt, &dummy_tag_info()), fps: Array::new(), rest: true, ty: ty.clone(), mode: mode.clone(), fresh: fresh.clone() }))
                    } else {
                        {
                            let rs = crate::lower::local_name(lx, &nkey);
                            let lx = lx.clone();
                            let mode = mode.clone();
                            let n = n.clone();
                            call_then(crate::lower::types::start_out_ty_of(lx.clone(), crate::lower::types::peel(&crate::lower::binder_ty(&lx, &n.span))), move |out_ty_of_2270: crate::lower::model::OutTy| {
                                let bt = out_ty_of_2270;
                                prism_rtl::Turn::Finished(PatOut { pa: crate::lower::model::Pa::PaBind(rs.clone()), conds: Array::new(), binds: Array::from(vec![(nkey.clone(), crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(rs.clone()), mode.clone(), bt.clone()))]) })
                            })
                        }
                    }
                }
            },
            crate::syntax::PatternKind::PIgnore => prism_rtl::Turn::Finished(pat_only(&crate::lower::model::Pa::PaWild)),
            crate::syntax::PatternKind::PUnit => prism_rtl::Turn::Finished(pat_only(&crate::lower::model::Pa::PaWild)),
            crate::syntax::PatternKind::PNil => prism_rtl::Turn::Finished(pat_only(&crate::lower::model::Pa::PaUnit(Text::lit("None")))),
            crate::syntax::PatternKind::PLit(l) => prism_rtl::Turn::More(Rc::new(LitPat { lx: lx.clone(), l: l.clone(), ty: ty.clone(), mode: mode.clone(), fresh: fresh.clone(), neg: false })),
            crate::syntax::PatternKind::PNeg(l) => prism_rtl::Turn::More(Rc::new(LitPat { lx: lx.clone(), l: l.clone(), ty: ty.clone(), mode: mode.clone(), fresh: fresh.clone(), neg: true })),
            crate::syntax::PatternKind::PSigil(m1652_6_0, q) if (m1652_6_0 == &Text::lit("?")) => prism_rtl::Turn::More(Rc::new(WrapPat { lx: lx.clone(), ctor: Text::lit("Some"), q: (**q).clone(), inner: inner_ty(ty), mode: mode.clone(), fresh: fresh.clone() })),
            crate::syntax::PatternKind::PSigil(m1652_7_0, q) if (m1652_7_0 == &Text::lit("~")) => prism_rtl::Turn::More(Rc::new(WrapPat { lx: lx.clone(), ctor: Text::lit("Ok"), q: (**q).clone(), inner: inner_ty(ty), mode: mode.clone(), fresh: fresh.clone() })),
            crate::syntax::PatternKind::PSigil(_, q) => prism_rtl::Turn::More(Rc::new(RustPat { lx: lx.clone(), p_: (**q).clone(), ty: ty.clone(), mode: mode.clone(), fresh: fresh.clone() })),
            crate::syntax::PatternKind::PGroup(q) => prism_rtl::Turn::More(Rc::new(RustPat { lx: lx.clone(), p_: (**q).clone(), ty: ty.clone(), mode: mode.clone(), fresh: fresh.clone() })),
            crate::syntax::PatternKind::PCtor(n, ps) => prism_rtl::Turn::More(Rc::new(CtorPat { lx: lx.clone(), n: n.clone(), ps: ps.clone(), ty: ty.clone(), mode: mode.clone(), fresh: fresh.clone() })),
            crate::syntax::PatternKind::PRecord(n, fps, rest) => prism_rtl::Turn::More(Rc::new(RecordPat { lx: lx.clone(), n: n.clone(), fps: fps.clone(), rest: *rest, ty: ty.clone(), mode: mode.clone(), fresh: fresh.clone() })),
            crate::syntax::PatternKind::PTuple(ps) => {
                let ts = match crate::lower::types::peel(ty) {
                    crate::check::types::Ty::TyTuple(xs) => xs,
                    _ => Array::new(),
                };
                let fresh = fresh.clone();
                let lx = lx.clone();
                let mode = mode.clone();
                let ps = ps.clone();
                call_value(each_job(crate::check::errors::range0(&len(&ps)), {
                    let lx = lx.clone();
                    let ps = ps.clone();
                    let ts = ts.clone();
                    let mode = mode.clone();
                    let fresh = fresh.clone();
                    Rc::new(move |p0: Nat| {
                        let lx = lx.clone();
                        let ps = ps.clone();
                        let ts = ts.clone();
                        let mode = mode.clone();
                        let fresh = fresh.clone();
                        entered(once_job(move || {
                            let i = p0;
                            prism_rtl::Turn::More(Rc::new(RustPat { lx: lx.clone(), p_: or(&index(&ps, &i), &dummy_pat()), ty: or(&index(&ts, &i), &crate::check::types::Ty::TyErr), mode: mode.clone(), fresh: Text::from(format!("{}_{}", &fresh, &i)) }))
                        }))
                    }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<PatOut>>>
                }), move |each_3069: Array<PatOut>| {
                    let subs = each_3069;
                    prism_rtl::Turn::Finished(PatOut { pa: crate::lower::model::Pa::PaTuple(each(&subs, &(|o: &PatOut| o.pa.clone()))), conds: fold(&subs, &Array::new(), &(|acc: &Array<crate::lower::model::Cc>, o: &PatOut| append(acc, &o.conds))), binds: fold(&subs, &Array::new(), &(|acc: &Array<(Text, crate::lower::types::Bn)>, o: &PatOut| append(acc, &o.binds))) })
                })
            },
            crate::syntax::PatternKind::PArray(ps) => prism_rtl::Turn::More(Rc::new(ArrayPat { lx: lx.clone(), ps: ps.clone(), ty: ty.clone(), mode: mode.clone(), fresh: fresh.clone() })),
            crate::syntax::PatternKind::PFamily(q) => prism_rtl::Turn::More(Rc::new(FamilyPat { lx: lx.clone(), q: q.clone(), ty: ty.clone(), fresh: fresh.clone() })),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start RustPat, x`: what the function value is when passed to `@Run`.
pub fn start_rust_pat(lx: crate::lower::Lx, p_: crate::syntax::Pattern_, ty: crate::check::types::Ty, mode: crate::lower::types::Holding, fresh: Text) -> Rc<dyn prism_rtl::Job<PatOut>> {
    Rc::new(RustPat { lx, p_, ty, mode, fresh })
}

/// ```prism
/// let dummyPat
/// ```
pub fn dummy_pat() -> crate::syntax::Pattern_ {
    crate::syntax::Pattern_ { kind: Rc::new(crate::syntax::PatternKind::PIgnore), span: crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) } }
}

/// ```prism
/// InnerTy: fn Ty -> Ty
/// ```
pub fn inner_ty(t: &crate::check::types::Ty) -> crate::check::types::Ty {
    match crate::lower::types::peel(t) {
        crate::check::types::Ty::TySig(m3528_0_0, i) if (&m3528_0_0 == &Text::lit("?")) => (*i).clone(),
        crate::check::types::Ty::TySig(m3528_1_0, i) if (&m3528_1_0 == &Text::lit("~")) => (*i).clone(),
        _ => crate::check::types::Ty::TyErr,
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// IsUnitCtor: fn Lx, Text -> Bool
/// ```
pub fn is_unit_ctor(lx: &crate::lower::Lx, qk: &Text) -> bool {
    match get(&lx.g.ctors, qk) {
        Some(c) => 'm3781: {
            let scrutinee = &or(&get(&lx.g.types, &c.owner), &crate::check::env::names::dummy_ty_info()).body;
            if let crate::check::env::TyBody::BChoice(m3781_0_0) = scrutinee && (m3781_0_0.len() == 1) && let Some((_, m3781_0_0_0_1)) = index(m3781_0_0, &Nat::from(0u32)) && ((&m3781_0_0_0_1).len() == 0) {
                break 'm3781 crate::check::env::is_lower_text(&crate::check::types::bare_name(qk));
            }
            false
        },
        None => false,
    }
}

/// ```prism
/// WrapPat: unbounded fn Lx, Text, Pattern, Ty, Holding, Text -> PatOut
/// ```
pub fn wrap_pat(lx: &crate::lower::Lx, ctor: &Text, q: &crate::syntax::Pattern_, inner: &crate::check::types::Ty, mode: &crate::lower::types::Holding, fresh: &Text) -> PatOut {
    let o = rust_pat(lx, q, inner, mode, fresh);
    let mut this: PatOut = o.clone();
    this.pa = crate::lower::model::Pa::PaCtor(ctor.clone(), Array::from(vec![this.pa.clone()]));
    this
}

/// The step machine of `WrapPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// WrapPat: unbounded fn Lx, Text, Pattern, Ty, Holding, Text -> PatOut
/// ```
pub struct WrapPat {
    pub lx: crate::lower::Lx,
    pub ctor: Text,
    pub q: crate::syntax::Pattern_,
    pub inner: crate::check::types::Ty,
    pub mode: crate::lower::types::Holding,
    pub fresh: Text,
}

impl prism_rtl::Job<PatOut> for WrapPat {
    fn cycle(&self) -> prism_rtl::Turn<PatOut> {
        let lx = &self.lx;
        let ctor = &self.ctor;
        let q = &self.q;
        let inner = &self.inner;
        let mode = &self.mode;
        let fresh = &self.fresh;
        let ctor = ctor.clone();
        let fresh = fresh.clone();
        let inner = inner.clone();
        let lx = lx.clone();
        let mode = mode.clone();
        let q = q.clone();
        call_then(start_rust_pat(lx.clone(), q.clone(), inner.clone(), mode.clone(), fresh.clone()), move |rust_pat_4061: PatOut| {
            let o = rust_pat_4061;
            prism_rtl::Turn::Finished({
                let mut this: PatOut = o.clone();
                this.pa = crate::lower::model::Pa::PaCtor(ctor.clone(), Array::from(vec![this.pa.clone()]));
                this
            })
        })
    }
}

/// `Start WrapPat, x`: what the function value is when passed to `@Run`.
pub fn start_wrap_pat(lx: crate::lower::Lx, ctor: Text, q: crate::syntax::Pattern_, inner: crate::check::types::Ty, mode: crate::lower::types::Holding, fresh: Text) -> Rc<dyn prism_rtl::Job<PatOut>> {
    Rc::new(WrapPat { lx, ctor, q, inner, mode, fresh })
}

/// ```prism
/// LitPat: unbounded fn Lx, Literal, Ty, Holding, Text, Bool -> PatOut
/// ```
pub fn lit_pat(lx: &crate::lower::Lx, l: &crate::syntax::Literal, ty: &crate::check::types::Ty, mode: &crate::lower::types::Holding, fresh: &Text, neg: &bool) -> PatOut {
    let t = crate::lower::types::out_ty_of(lx, &crate::lower::types::peel(ty));
    match &l.kind {
        crate::syntax::LitKind::LChar(c) => pat_only(&crate::lower::model::Pa::PaChar(c.clone())),
        _ => {
            let lit = match &l.kind {
                crate::syntax::LitKind::LInt(d) => if (((&t == &crate::lower::model::OutTy::OutNat) || (&t == &crate::lower::model::OutTy::OutInt)) || (&t == &crate::lower::model::OutTy::OutU8)) || (&t == &crate::lower::model::OutTy::OutFloat) {
                    crate::lower::types::Vl::VlOwned(crate::lower::expr::number(&t, d, neg), t.clone())
                } else {
                    crate::lower::expr::literal_value(lx, &crate::lower::types::empty_env(), l, &l.span, neg)
                },
                _ => crate::lower::expr::literal_value(lx, &crate::lower::types::empty_env(), l, &l.span, neg),
            };
            let lv = crate::lower::types::Vl::VlOwned(crate::lower::types::own(&lit), t.clone());
            let b = crate::lower::types::local_place(&crate::lower::model::Ex::XVar(fresh.clone()), mode, &t);
            PatOut { pa: crate::lower::model::Pa::PaBind(fresh.clone()), conds: Array::from(vec![crate::lower::model::Cc::CcIf(crate::lower::model::Ex::XBin(Text::lit("=="), Rc::new(crate::lower::types::ref_(&b)), Rc::new(crate::lower::types::ref_(&lv))))]), binds: Array::new() }
        },
    }
}

/// The step machine of `LitPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LitPat: unbounded fn Lx, Literal, Ty, Holding, Text, Bool -> PatOut
/// ```
pub struct LitPat {
    pub lx: crate::lower::Lx,
    pub l: crate::syntax::Literal,
    pub ty: crate::check::types::Ty,
    pub mode: crate::lower::types::Holding,
    pub fresh: Text,
    pub neg: bool,
}

impl prism_rtl::Job<PatOut> for LitPat {
    fn cycle(&self) -> prism_rtl::Turn<PatOut> {
        let lx = &self.lx;
        let l = &self.l;
        let ty = &self.ty;
        let mode = &self.mode;
        let fresh = &self.fresh;
        let neg = &self.neg;
        let fresh = fresh.clone();
        let l = l.clone();
        let lx = lx.clone();
        let mode = mode.clone();
        let neg = *neg;
        let ty = ty.clone();
        call_then(crate::lower::types::start_out_ty_of(lx.clone(), crate::lower::types::peel(&ty)), move |out_ty_of_4373: crate::lower::model::OutTy| {
            let t = out_ty_of_4373;
            match &l.kind {
                crate::syntax::LitKind::LChar(c) => prism_rtl::Turn::Finished(pat_only(&crate::lower::model::Pa::PaChar(c.clone()))),
                _ => {
                    let lit = match &l.kind {
                        crate::syntax::LitKind::LInt(d) => if (((&t == &crate::lower::model::OutTy::OutNat) || (&t == &crate::lower::model::OutTy::OutInt)) || (&t == &crate::lower::model::OutTy::OutU8)) || (&t == &crate::lower::model::OutTy::OutFloat) {
                            crate::lower::types::Vl::VlOwned(crate::lower::expr::number(&t, d, &neg), t.clone())
                        } else {
                            crate::lower::expr::literal_value(&lx, &crate::lower::types::empty_env(), &l, &l.span, &neg)
                        },
                        _ => crate::lower::expr::literal_value(&lx, &crate::lower::types::empty_env(), &l, &l.span, &neg),
                    };
                    let lv = crate::lower::types::Vl::VlOwned(crate::lower::types::own(&lit), t.clone());
                    let b = crate::lower::types::local_place(&crate::lower::model::Ex::XVar(fresh.clone()), &mode, &t);
                    prism_rtl::Turn::Finished(PatOut { pa: crate::lower::model::Pa::PaBind(fresh.clone()), conds: Array::from(vec![crate::lower::model::Cc::CcIf(crate::lower::model::Ex::XBin(Text::lit("=="), Rc::new(crate::lower::types::ref_(&b)), Rc::new(crate::lower::types::ref_(&lv))))]), binds: Array::new() })
                },
            }
        })
    }
}

/// `Start LitPat, x`: what the function value is when passed to `@Run`.
pub fn start_lit_pat(lx: crate::lower::Lx, l: crate::syntax::Literal, ty: crate::check::types::Ty, mode: crate::lower::types::Holding, fresh: Text, neg: bool) -> Rc<dyn prism_rtl::Job<PatOut>> {
    Rc::new(LitPat { lx, l, ty, mode, fresh, neg })
}

/// ```prism
/// CtorPat: unbounded fn Lx, SName, [Pattern], Ty, Holding, Text -> PatOut
/// ```
pub fn ctor_pat(lx: &crate::lower::Lx, n: &crate::syntax::SName, ps: &Array<crate::syntax::Pattern_>, ty: &crate::check::types::Ty, mode: &crate::lower::types::Holding, fresh: &Text) -> PatOut {
    let (qk_opt, _) = crate::check::env::names::resolve_value(&lx.g, &lx.home, n);
    match &qk_opt {
        Some(m5416_0) if (m5416_0 == &Text::lit("True")) => pat_only(&crate::lower::model::Pa::PaBool(true)),
        Some(m5416_1) if (m5416_1 == &Text::lit("False")) => pat_only(&crate::lower::model::Pa::PaBool(false)),
        Some(qk) => match get(&lx.g.ctors, qk) {
            Some(c) => {
                let owner = or(&get(&lx.g.types, &c.owner), &crate::check::env::names::dummy_ty_info());
                let ty_path = crate::lower::path_in(lx, &owner.home, &crate::lower::camel(&crate::check::types::bare_name(&c.owner)));
                let args = match crate::lower::types::peel(ty) {
                    crate::check::types::Ty::TyCon(_, xs) => xs,
                    _ => Array::new(),
                };
                let subs = run_to_end(each_job(crate::check::errors::range0(&len(ps)), {
                    let lx = lx.clone();
                    let c = c.clone();
                    let ps = ps.clone();
                    let args = args.clone();
                    let mode = mode.clone();
                    let fresh = fresh.clone();
                    Rc::new(move |p0: Nat| {
                        let lx = lx.clone();
                        let c = c.clone();
                        let ps = ps.clone();
                        let args = args.clone();
                        let mode = mode.clone();
                        let fresh = fresh.clone();
                        entered(once_job(move || {
                            let i = p0;
                            call_then(crate::lower::expr::start_instantiated(or(&index(&c.args, &i), &crate::check::types::Ty::TyErr), c.params.clone(), args.clone()), move |instantiated_5920: crate::check::types::Ty| prism_rtl::Turn::More(Rc::new(SubPat { lx: lx.clone(), c: c.clone(), i: i.clone(), p_: or(&index(&ps, &i), &dummy_pat()), ty: instantiated_5920, mode: mode.clone(), fresh: Text::from(format!("{}_{}", &fresh, &i)) })))
                        }))
                    }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<PatOut>>>
                }));
                let conds = fold(&subs, &Array::new(), &(|acc: &Array<crate::lower::model::Cc>, o: &PatOut| append(acc, &o.conds)));
                let binds = fold(&subs, &Array::new(), &(|acc: &Array<(Text, crate::lower::types::Bn)>, o: &PatOut| append(acc, &o.binds)));
                let pas = each(&subs, &(|o: &PatOut| o.pa.clone()));
                match &owner.body {
                    crate::check::env::TyBody::BRecord(fs) => PatOut { pa: crate::lower::model::Pa::PaRecord(ty_path.clone(), each(&crate::check::errors::range0(&len(&pas)), &(|i: &Nat| (crate::lower::snake(&or(&index(&c.fields, i), &Text::lit(""))), or(&index(&pas, i), &crate::lower::model::Pa::PaWild)))), &len(&pas) < &len(&c.fields)), conds: conds.clone(), binds: binds.clone() },
                    _ => {
                        let is_unit_type = (&len(&c.args) == &Nat::from(0u32)) && is_unit_ctor(lx, qk);
                        let is_newtype = (&crate::check::types::bare_name(&c.name) == &crate::check::types::bare_name(&c.owner)) && match &owner.body {
                            crate::check::env::TyBody::BChoice(cases) => &len(cases) == &Nat::from(1u32),
                            _ => false,
                        };
                        let path_ = if is_unit_type || is_newtype {
                            ty_path.clone()
                        } else {
                            Text::from(format!("{}::{}", &ty_path, &crate::lower::camel(&crate::check::types::bare_name(&c.name))))
                        };
                        if &len(&c.args) == &Nat::from(0u32) {
                            PatOut { pa: crate::lower::model::Pa::PaUnit(path_.clone()), conds: Array::new(), binds: Array::new() }
                        } else {
                            PatOut { pa: crate::lower::model::Pa::PaCtor(path_.clone(), pas.clone()), conds: conds.clone(), binds: binds.clone() }
                        }
                    },
                }
            },
            None => PatOut { pa: crate::lower::model::Pa::PaWild, conds: Array::from(vec![crate::lower::model::Cc::CcIf(crate::lower::expr::refusal(&Text::from(format!("a pattern of {}", qk))))]), binds: Array::new() },
        },
        None => PatOut { pa: crate::lower::model::Pa::PaWild, conds: Array::from(vec![crate::lower::model::Cc::CcIf(crate::lower::expr::refusal(&Text::lit("a pattern of an unknown constructor")))]), binds: Array::new() },
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `CtorPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CtorPat: unbounded fn Lx, SName, [Pattern], Ty, Holding, Text -> PatOut
/// ```
pub struct CtorPat {
    pub lx: crate::lower::Lx,
    pub n: crate::syntax::SName,
    pub ps: Array<crate::syntax::Pattern_>,
    pub ty: crate::check::types::Ty,
    pub mode: crate::lower::types::Holding,
    pub fresh: Text,
}

impl prism_rtl::Job<PatOut> for CtorPat {
    fn cycle(&self) -> prism_rtl::Turn<PatOut> {
        let lx = &self.lx;
        let n = &self.n;
        let ps = &self.ps;
        let ty = &self.ty;
        let mode = &self.mode;
        let fresh = &self.fresh;
        let (qk_opt, _) = crate::check::env::names::resolve_value(&lx.g, &lx.home, n);
        match &qk_opt {
            Some(m5416_0) if (m5416_0 == &Text::lit("True")) => prism_rtl::Turn::Finished(pat_only(&crate::lower::model::Pa::PaBool(true))),
            Some(m5416_1) if (m5416_1 == &Text::lit("False")) => prism_rtl::Turn::Finished(pat_only(&crate::lower::model::Pa::PaBool(false))),
            Some(qk) => match get(&lx.g.ctors, qk) {
                Some(c) => {
                    let owner = or(&get(&lx.g.types, &c.owner), &crate::check::env::names::dummy_ty_info());
                    let ty_path = crate::lower::path_in(lx, &owner.home, &crate::lower::camel(&crate::check::types::bare_name(&c.owner)));
                    let args = match crate::lower::types::peel(ty) {
                        crate::check::types::Ty::TyCon(_, xs) => xs,
                        _ => Array::new(),
                    };
                    let fresh = fresh.clone();
                    let lx = lx.clone();
                    let mode = mode.clone();
                    let ps = ps.clone();
                    let qk = qk.clone();
                    call_value(each_job(crate::check::errors::range0(&len(&ps)), {
                        let lx = lx.clone();
                        let c = c.clone();
                        let ps = ps.clone();
                        let args = args.clone();
                        let mode = mode.clone();
                        let fresh = fresh.clone();
                        Rc::new(move |p0: Nat| {
                            let lx = lx.clone();
                            let c = c.clone();
                            let ps = ps.clone();
                            let args = args.clone();
                            let mode = mode.clone();
                            let fresh = fresh.clone();
                            entered(once_job(move || {
                                let i = p0;
                                call_then(crate::lower::expr::start_instantiated(or(&index(&c.args, &i), &crate::check::types::Ty::TyErr), c.params.clone(), args.clone()), move |instantiated_5920: crate::check::types::Ty| prism_rtl::Turn::More(Rc::new(SubPat { lx: lx.clone(), c: c.clone(), i: i.clone(), p_: or(&index(&ps, &i), &dummy_pat()), ty: instantiated_5920, mode: mode.clone(), fresh: Text::from(format!("{}_{}", &fresh, &i)) })))
                            }))
                        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<PatOut>>>
                    }), move |each_5851: Array<PatOut>| {
                        let subs = each_5851;
                        let conds = fold(&subs, &Array::new(), &(|acc: &Array<crate::lower::model::Cc>, o: &PatOut| append(acc, &o.conds)));
                        let binds = fold(&subs, &Array::new(), &(|acc: &Array<(Text, crate::lower::types::Bn)>, o: &PatOut| append(acc, &o.binds)));
                        let pas = each(&subs, &(|o: &PatOut| o.pa.clone()));
                        match &owner.body {
                            crate::check::env::TyBody::BRecord(fs) => prism_rtl::Turn::Finished(PatOut { pa: crate::lower::model::Pa::PaRecord(ty_path.clone(), each(&crate::check::errors::range0(&len(&pas)), &(|i: &Nat| (crate::lower::snake(&or(&index(&c.fields, i), &Text::lit(""))), or(&index(&pas, i), &crate::lower::model::Pa::PaWild)))), &len(&pas) < &len(&c.fields)), conds: conds.clone(), binds: binds.clone() }),
                            _ => {
                                let is_unit_type = (&len(&c.args) == &Nat::from(0u32)) && is_unit_ctor(&lx, &qk);
                                let is_newtype = (&crate::check::types::bare_name(&c.name) == &crate::check::types::bare_name(&c.owner)) && match &owner.body {
                                    crate::check::env::TyBody::BChoice(cases) => &len(cases) == &Nat::from(1u32),
                                    _ => false,
                                };
                                let path_ = if is_unit_type || is_newtype {
                                    ty_path.clone()
                                } else {
                                    Text::from(format!("{}::{}", &ty_path, &crate::lower::camel(&crate::check::types::bare_name(&c.name))))
                                };
                                if &len(&c.args) == &Nat::from(0u32) {
                                    prism_rtl::Turn::Finished(PatOut { pa: crate::lower::model::Pa::PaUnit(path_.clone()), conds: Array::new(), binds: Array::new() })
                                } else {
                                    prism_rtl::Turn::Finished(PatOut { pa: crate::lower::model::Pa::PaCtor(path_.clone(), pas.clone()), conds: conds.clone(), binds: binds.clone() })
                                }
                            },
                        }
                    })
                },
                None => prism_rtl::Turn::Finished(PatOut { pa: crate::lower::model::Pa::PaWild, conds: Array::from(vec![crate::lower::model::Cc::CcIf(crate::lower::expr::refusal(&Text::from(format!("a pattern of {}", qk))))]), binds: Array::new() }),
            },
            None => prism_rtl::Turn::Finished(PatOut { pa: crate::lower::model::Pa::PaWild, conds: Array::from(vec![crate::lower::model::Cc::CcIf(crate::lower::expr::refusal(&Text::lit("a pattern of an unknown constructor")))]), binds: Array::new() }),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start CtorPat, x`: what the function value is when passed to `@Run`.
pub fn start_ctor_pat(lx: crate::lower::Lx, n: crate::syntax::SName, ps: Array<crate::syntax::Pattern_>, ty: crate::check::types::Ty, mode: crate::lower::types::Holding, fresh: Text) -> Rc<dyn prism_rtl::Job<PatOut>> {
    Rc::new(CtorPat { lx, n, ps, ty, mode, fresh })
}

/// ```prism
/// SubPat: unbounded fn Lx, CtorInfo, Nat, Pattern, Ty, Holding, Text -> PatOut
/// ```
pub fn sub_pat(lx: &crate::lower::Lx, c: &crate::check::env::CtorInfo, i: &Nat, p_: &crate::syntax::Pattern_, ty: &crate::check::types::Ty, mode: &crate::lower::types::Holding, fresh: &Text) -> PatOut {
    if !crate::lower::types::rc_field(lx, &c.name, i) {
        rust_pat(lx, p_, ty, mode, fresh)
    } else {
        {
            let rc_mode = if mode == &crate::lower::types::Holding::Owned {
                crate::lower::types::Holding::RcOwned
            } else {
                crate::lower::types::Holding::RcRef
            };
            match &*p_.kind {
                crate::syntax::PatternKind::PIgnore => pat_only(&crate::lower::model::Pa::PaWild),
                crate::syntax::PatternKind::PName(n) => {
                    let o = rust_pat(lx, p_, ty, &rc_mode, fresh);
                    match &o.pa {
                        crate::lower::model::Pa::PaBind(_) => o.clone(),
                        _ => behind_rc(lx, p_, ty, &rc_mode, fresh),
                    }
                },
                _ => behind_rc(lx, p_, ty, &rc_mode, fresh),
            }
        }
    }
}

/// The step machine of `SubPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SubPat: unbounded fn Lx, CtorInfo, Nat, Pattern, Ty, Holding, Text -> PatOut
/// ```
pub struct SubPat {
    pub lx: crate::lower::Lx,
    pub c: crate::check::env::CtorInfo,
    pub i: Nat,
    pub p_: crate::syntax::Pattern_,
    pub ty: crate::check::types::Ty,
    pub mode: crate::lower::types::Holding,
    pub fresh: Text,
}

impl prism_rtl::Job<PatOut> for SubPat {
    fn cycle(&self) -> prism_rtl::Turn<PatOut> {
        let lx = &self.lx;
        let c = &self.c;
        let i = &self.i;
        let p_ = &self.p_;
        let ty = &self.ty;
        let mode = &self.mode;
        let fresh = &self.fresh;
        if !crate::lower::types::rc_field(lx, &c.name, i) {
            prism_rtl::Turn::More(Rc::new(RustPat { lx: lx.clone(), p_: p_.clone(), ty: ty.clone(), mode: mode.clone(), fresh: fresh.clone() }))
        } else {
            {
                let rc_mode = if mode == &crate::lower::types::Holding::Owned {
                    crate::lower::types::Holding::RcOwned
                } else {
                    crate::lower::types::Holding::RcRef
                };
                match &*p_.kind {
                    crate::syntax::PatternKind::PIgnore => prism_rtl::Turn::Finished(pat_only(&crate::lower::model::Pa::PaWild)),
                    crate::syntax::PatternKind::PName(n) => {
                        let fresh = fresh.clone();
                        let lx = lx.clone();
                        let p_ = p_.clone();
                        let ty = ty.clone();
                        call_then(start_rust_pat(lx.clone(), p_.clone(), ty.clone(), rc_mode.clone(), fresh.clone()), move |rust_pat_7814: PatOut| {
                            let o = rust_pat_7814;
                            match &o.pa {
                                crate::lower::model::Pa::PaBind(_) => prism_rtl::Turn::Finished(o.clone()),
                                _ => prism_rtl::Turn::More(Rc::new(BehindRc { lx: lx.clone(), p_: p_.clone(), ty: ty.clone(), rc_mode: rc_mode.clone(), fresh: fresh.clone() })),
                            }
                        })
                    },
                    _ => prism_rtl::Turn::More(Rc::new(BehindRc { lx: lx.clone(), p_: p_.clone(), ty: ty.clone(), rc_mode: rc_mode.clone(), fresh: fresh.clone() })),
                }
            }
        }
    }
}

/// `Start SubPat, x`: what the function value is when passed to `@Run`.
pub fn start_sub_pat(lx: crate::lower::Lx, c: crate::check::env::CtorInfo, i: Nat, p_: crate::syntax::Pattern_, ty: crate::check::types::Ty, mode: crate::lower::types::Holding, fresh: Text) -> Rc<dyn prism_rtl::Job<PatOut>> {
    Rc::new(SubPat { lx, c, i, p_, ty, mode, fresh })
}

/// ```prism
/// BehindRc: unbounded fn Lx, Pattern, Ty, Holding, Text -> PatOut
/// ```
pub fn behind_rc(lx: &crate::lower::Lx, p_: &crate::syntax::Pattern_, ty: &crate::check::types::Ty, rc_mode: &crate::lower::types::Holding, fresh: &Text) -> PatOut {
    let inner = rust_pat(lx, p_, ty, &crate::lower::types::Holding::ByRef, &Text::from(format!("{}_r", fresh)));
    let place_ = crate::lower::types::ref_(&crate::lower::types::local_place(&crate::lower::model::Ex::XVar(fresh.clone()), rc_mode, &crate::lower::model::OutTy::OutUnknown(Text::lit("a payload"))));
    PatOut { pa: crate::lower::model::Pa::PaBind(fresh.clone()), conds: append(&Array::from(vec![crate::lower::model::Cc::CcLet(inner.pa.clone(), place_.clone())]), &inner.conds), binds: inner.binds.clone() }
}

/// The step machine of `BehindRc`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BehindRc: unbounded fn Lx, Pattern, Ty, Holding, Text -> PatOut
/// ```
pub struct BehindRc {
    pub lx: crate::lower::Lx,
    pub p_: crate::syntax::Pattern_,
    pub ty: crate::check::types::Ty,
    pub rc_mode: crate::lower::types::Holding,
    pub fresh: Text,
}

impl prism_rtl::Job<PatOut> for BehindRc {
    fn cycle(&self) -> prism_rtl::Turn<PatOut> {
        let lx = &self.lx;
        let p_ = &self.p_;
        let ty = &self.ty;
        let rc_mode = &self.rc_mode;
        let fresh = &self.fresh;
        let fresh = fresh.clone();
        let lx = lx.clone();
        let p_ = p_.clone();
        let rc_mode = rc_mode.clone();
        let ty = ty.clone();
        call_then(start_rust_pat(lx.clone(), p_.clone(), ty.clone(), crate::lower::types::Holding::ByRef, Text::from(format!("{}_r", &fresh))), move |rust_pat_8153: PatOut| {
            let inner = rust_pat_8153;
            let place_ = crate::lower::types::ref_(&crate::lower::types::local_place(&crate::lower::model::Ex::XVar(fresh.clone()), &rc_mode, &crate::lower::model::OutTy::OutUnknown(Text::lit("a payload"))));
            prism_rtl::Turn::Finished(PatOut { pa: crate::lower::model::Pa::PaBind(fresh.clone()), conds: append(&Array::from(vec![crate::lower::model::Cc::CcLet(inner.pa.clone(), place_.clone())]), &inner.conds), binds: inner.binds.clone() })
        })
    }
}

/// `Start BehindRc, x`: what the function value is when passed to `@Run`.
pub fn start_behind_rc(lx: crate::lower::Lx, p_: crate::syntax::Pattern_, ty: crate::check::types::Ty, rc_mode: crate::lower::types::Holding, fresh: Text) -> Rc<dyn prism_rtl::Job<PatOut>> {
    Rc::new(BehindRc { lx, p_, ty, rc_mode, fresh })
}

/// ```prism
/// RecordPat: unbounded fn Lx, SName, [FieldPat], Bool, Ty, Holding, Text -> PatOut
/// ```
pub fn record_pat(lx: &crate::lower::Lx, n: &crate::syntax::SName, fps: &Array<crate::syntax::FieldPat>, rest: &bool, ty: &crate::check::types::Ty, mode: &crate::lower::types::Holding, fresh: &Text) -> PatOut {
    let (qk_opt, why) = crate::check::env::names::resolve_value(&lx.g, &lx.home, n);
    let qk = or(&qk_opt, &Text::lit(""));
    if &qk == &Text::lit("Prelude.Error") {
        error_pat(lx, fps, ty, mode, fresh)
    } else {
        if (&why == &Text::lit("tag")) && crate::check::env::has_key(&lx.g.tags, &qk) {
            tag_pat(lx, &or(&get(&lx.g.tags, &qk), &dummy_tag_info()), fps, rest, ty, mode, fresh)
        } else {
            match get(&lx.g.ctors, &qk) {
                Some(c) => {
                    let owner = or(&get(&lx.g.types, &c.owner), &crate::check::env::names::dummy_ty_info());
                    let ty_path = crate::lower::path_in(lx, &owner.home, &crate::lower::camel(&crate::check::types::bare_name(&c.owner)));
                    match &owner.body {
                        crate::check::env::TyBody::BChoice(cases) if (&len(fps) == &Nat::from(0u32)) => rest_case_pat(&c, cases, &ty_path),
                        _ => fields_pat(lx, &c, fps, rest, ty, mode, fresh, &ty_path),
                        _ => unreachable!("no arm matched"),
                    }
                },
                None => match get(&lx.g.tags, &qk) {
                    Some(tg) => tag_pat(lx, &tg, fps, rest, ty, mode, fresh),
                    None => PatOut { pa: crate::lower::model::Pa::PaWild, conds: Array::from(vec![crate::lower::model::Cc::CcIf(crate::lower::expr::refusal(&Text::from(format!("a pattern of {}", &qk))))]), binds: Array::new() },
                },
            }
        }
    }
}

/// The step machine of `RecordPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RecordPat: unbounded fn Lx, SName, [FieldPat], Bool, Ty, Holding, Text -> PatOut
/// ```
pub struct RecordPat {
    pub lx: crate::lower::Lx,
    pub n: crate::syntax::SName,
    pub fps: Array<crate::syntax::FieldPat>,
    pub rest: bool,
    pub ty: crate::check::types::Ty,
    pub mode: crate::lower::types::Holding,
    pub fresh: Text,
}

impl prism_rtl::Job<PatOut> for RecordPat {
    fn cycle(&self) -> prism_rtl::Turn<PatOut> {
        let lx = &self.lx;
        let n = &self.n;
        let fps = &self.fps;
        let rest = &self.rest;
        let ty = &self.ty;
        let mode = &self.mode;
        let fresh = &self.fresh;
        let (qk_opt, why) = crate::check::env::names::resolve_value(&lx.g, &lx.home, n);
        let qk = or(&qk_opt, &Text::lit(""));
        if &qk == &Text::lit("Prelude.Error") {
            prism_rtl::Turn::More(Rc::new(ErrorPat { lx: lx.clone(), fps: fps.clone(), ty: ty.clone(), mode: mode.clone(), fresh: fresh.clone() }))
        } else {
            if (&why == &Text::lit("tag")) && crate::check::env::has_key(&lx.g.tags, &qk) {
                prism_rtl::Turn::More(Rc::new(TagPat { lx: lx.clone(), tg: or(&get(&lx.g.tags, &qk), &dummy_tag_info()), fps: fps.clone(), rest: *rest, ty: ty.clone(), mode: mode.clone(), fresh: fresh.clone() }))
            } else {
                match get(&lx.g.ctors, &qk) {
                    Some(c) => {
                        let owner = or(&get(&lx.g.types, &c.owner), &crate::check::env::names::dummy_ty_info());
                        let ty_path = crate::lower::path_in(lx, &owner.home, &crate::lower::camel(&crate::check::types::bare_name(&c.owner)));
                        match &owner.body {
                            crate::check::env::TyBody::BChoice(cases) if (&len(fps) == &Nat::from(0u32)) => prism_rtl::Turn::Finished(rest_case_pat(&c, cases, &ty_path)),
                            _ => prism_rtl::Turn::More(Rc::new(FieldsPat { lx: lx.clone(), c: c.clone(), fps: fps.clone(), rest: *rest, ty: ty.clone(), mode: mode.clone(), fresh: fresh.clone(), ty_path: ty_path.clone() })),
                            _ => unreachable!("no arm matched"),
                        }
                    },
                    None => match get(&lx.g.tags, &qk) {
                        Some(tg) => prism_rtl::Turn::More(Rc::new(TagPat { lx: lx.clone(), tg: tg.clone(), fps: fps.clone(), rest: *rest, ty: ty.clone(), mode: mode.clone(), fresh: fresh.clone() })),
                        None => prism_rtl::Turn::Finished(PatOut { pa: crate::lower::model::Pa::PaWild, conds: Array::from(vec![crate::lower::model::Cc::CcIf(crate::lower::expr::refusal(&Text::from(format!("a pattern of {}", &qk))))]), binds: Array::new() }),
                    },
                }
            }
        }
    }
}

/// `Start RecordPat, x`: what the function value is when passed to `@Run`.
pub fn start_record_pat(lx: crate::lower::Lx, n: crate::syntax::SName, fps: Array<crate::syntax::FieldPat>, rest: bool, ty: crate::check::types::Ty, mode: crate::lower::types::Holding, fresh: Text) -> Rc<dyn prism_rtl::Job<PatOut>> {
    Rc::new(RecordPat { lx, n, fps, rest, ty, mode, fresh })
}

/// ```prism
/// RestCasePat: fn CtorInfo, [((Text, [Ty]))], Text -> PatOut
/// ```
pub fn rest_case_pat(c: &crate::check::env::CtorInfo, cases: &Array<(Text, Array<crate::check::types::Ty>)>, ty_path: &Text) -> PatOut {
    let is_newtype = (&len(cases) == &Nat::from(1u32)) && (&crate::check::types::bare_name(&c.name) == &crate::check::types::bare_name(&c.owner));
    let path_ = if is_newtype {
        ty_path.clone()
    } else {
        Text::from(format!("{}::{}", ty_path, &crate::lower::camel(&crate::check::types::bare_name(&c.name))))
    };
    if &len(&c.args) == &Nat::from(0u32) {
        PatOut { pa: crate::lower::model::Pa::PaUnit(path_.clone()), conds: Array::new(), binds: Array::new() }
    } else {
        PatOut { pa: crate::lower::model::Pa::PaCtor(path_.clone(), each(&c.args, &(|_: &crate::check::types::Ty| crate::lower::model::Pa::PaWild))), conds: Array::new(), binds: Array::new() }
    }
}

/// ```prism
/// FieldsPat: unbounded fn Lx, CtorInfo, [FieldPat], Bool, Ty, Holding, Text, Text -> PatOut
/// ```
pub fn fields_pat(lx: &crate::lower::Lx, c: &crate::check::env::CtorInfo, fps: &Array<crate::syntax::FieldPat>, rest: &bool, ty: &crate::check::types::Ty, mode: &crate::lower::types::Holding, fresh: &Text, ty_path: &Text) -> PatOut {
    let args = match crate::lower::types::peel(ty) {
        crate::check::types::Ty::TyCon(_, xs) => xs,
        _ => Array::new(),
    };
    let subs = run_to_end(each_job(crate::check::errors::range0(&len(fps)), {
        let fps = fps.clone();
        let c = c.clone();
        let lx = lx.clone();
        let args = args.clone();
        let mode = mode.clone();
        let fresh = fresh.clone();
        Rc::new(move |p0: Nat| {
            let fps = fps.clone();
            let c = c.clone();
            let lx = lx.clone();
            let args = args.clone();
            let mode = mode.clone();
            let fresh = fresh.clone();
            entered(once_job(move || {
                let i = p0;
                {
                    let fp = or(&index(&fps, &i), &dummy_field_pat());
                    let fname = match &fp.name {
                        Some(id) => id.name.clone(),
                        None => or(&index(&c.fields, &i), &Text::lit("")),
                    };
                    let fix = fold(&crate::check::errors::range0(&len(&c.fields)), &i, &(|found: &Nat, j: &Nat| if &or(&index(&c.fields, j), &Text::lit("")) == &fname {
                        j.clone()
                    } else {
                        found.clone()
                    }));
                    call_then(crate::lower::expr::start_instantiated(or(&index(&c.args, &fix), &crate::check::types::Ty::TyErr), c.params.clone(), args.clone()), move |instantiated_10660: crate::check::types::Ty| call_then(start_sub_pat(lx.clone(), c.clone(), fix.clone(), fp.pattern.clone(), instantiated_10660, mode.clone(), Text::from(format!("{}_{}", &fresh, &i))), move |sub_pat_10628: PatOut| prism_rtl::Turn::Finished((crate::lower::snake(&fname), sub_pat_10628))))
                }
            }))
        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<(Text, PatOut)>>>
    }));
    let conds = fold(&subs, &Array::new(), &(|acc: &Array<crate::lower::model::Cc>, (_, o): &(Text, PatOut)| append(acc, &o.conds)));
    let binds = fold(&subs, &Array::new(), &(|acc: &Array<(Text, crate::lower::types::Bn)>, (_, o): &(Text, PatOut)| append(acc, &o.binds)));
    PatOut { pa: crate::lower::model::Pa::PaRecord(ty_path.clone(), each(&subs, &(|(f, o): &(Text, PatOut)| (f.clone(), o.pa.clone()))), *rest || (&len(&subs) < &len(&c.fields))), conds: conds.clone(), binds: binds.clone() }
}

/// The step machine of `FieldsPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FieldsPat: unbounded fn Lx, CtorInfo, [FieldPat], Bool, Ty, Holding, Text, Text -> PatOut
/// ```
pub struct FieldsPat {
    pub lx: crate::lower::Lx,
    pub c: crate::check::env::CtorInfo,
    pub fps: Array<crate::syntax::FieldPat>,
    pub rest: bool,
    pub ty: crate::check::types::Ty,
    pub mode: crate::lower::types::Holding,
    pub fresh: Text,
    pub ty_path: Text,
}

impl prism_rtl::Job<PatOut> for FieldsPat {
    fn cycle(&self) -> prism_rtl::Turn<PatOut> {
        let lx = &self.lx;
        let c = &self.c;
        let fps = &self.fps;
        let rest = &self.rest;
        let ty = &self.ty;
        let mode = &self.mode;
        let fresh = &self.fresh;
        let ty_path = &self.ty_path;
        let args = match crate::lower::types::peel(ty) {
            crate::check::types::Ty::TyCon(_, xs) => xs,
            _ => Array::new(),
        };
        let c = c.clone();
        let fps = fps.clone();
        let fresh = fresh.clone();
        let lx = lx.clone();
        let mode = mode.clone();
        let rest = *rest;
        let ty_path = ty_path.clone();
        call_value(each_job(crate::check::errors::range0(&len(&fps)), {
            let fps = fps.clone();
            let c = c.clone();
            let lx = lx.clone();
            let args = args.clone();
            let mode = mode.clone();
            let fresh = fresh.clone();
            Rc::new(move |p0: Nat| {
                let fps = fps.clone();
                let c = c.clone();
                let lx = lx.clone();
                let args = args.clone();
                let mode = mode.clone();
                let fresh = fresh.clone();
                entered(once_job(move || {
                    let i = p0;
                    {
                        let fp = or(&index(&fps, &i), &dummy_field_pat());
                        let fname = match &fp.name {
                            Some(id) => id.name.clone(),
                            None => or(&index(&c.fields, &i), &Text::lit("")),
                        };
                        let fix = fold(&crate::check::errors::range0(&len(&c.fields)), &i, &(|found: &Nat, j: &Nat| if &or(&index(&c.fields, j), &Text::lit("")) == &fname {
                            j.clone()
                        } else {
                            found.clone()
                        }));
                        call_then(crate::lower::expr::start_instantiated(or(&index(&c.args, &fix), &crate::check::types::Ty::TyErr), c.params.clone(), args.clone()), move |instantiated_10660: crate::check::types::Ty| call_then(start_sub_pat(lx.clone(), c.clone(), fix.clone(), fp.pattern.clone(), instantiated_10660, mode.clone(), Text::from(format!("{}_{}", &fresh, &i))), move |sub_pat_10628: PatOut| prism_rtl::Turn::Finished((crate::lower::snake(&fname), sub_pat_10628))))
                    }
                }))
            }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<(Text, PatOut)>>>
        }), move |each_10275: Array<(Text, PatOut)>| {
            let subs = each_10275;
            let conds = fold(&subs, &Array::new(), &(|acc: &Array<crate::lower::model::Cc>, (_, o): &(Text, PatOut)| append(acc, &o.conds)));
            let binds = fold(&subs, &Array::new(), &(|acc: &Array<(Text, crate::lower::types::Bn)>, (_, o): &(Text, PatOut)| append(acc, &o.binds)));
            prism_rtl::Turn::Finished(PatOut { pa: crate::lower::model::Pa::PaRecord(ty_path.clone(), each(&subs, &(|(f, o): &(Text, PatOut)| (f.clone(), o.pa.clone()))), rest || (&len(&subs) < &len(&c.fields))), conds: conds.clone(), binds: binds.clone() })
        })
    }
}

/// `Start FieldsPat, x`: what the function value is when passed to `@Run`.
pub fn start_fields_pat(lx: crate::lower::Lx, c: crate::check::env::CtorInfo, fps: Array<crate::syntax::FieldPat>, rest: bool, ty: crate::check::types::Ty, mode: crate::lower::types::Holding, fresh: Text, ty_path: Text) -> Rc<dyn prism_rtl::Job<PatOut>> {
    Rc::new(FieldsPat { lx, c, fps, rest, ty, mode, fresh, ty_path })
}

/// ```prism
/// let dummyFieldPat
/// ```
pub fn dummy_field_pat() -> crate::syntax::FieldPat {
    crate::syntax::FieldPat { name: None, pattern: dummy_pat(), span: crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) } }
}

/// ```prism
/// let dummyTagInfo
/// ```
pub fn dummy_tag_info() -> crate::check::env::TagInfo {
    crate::check::env::TagInfo { name: Text::lit(""), family: Text::lit(""), kind: Text::lit(""), out: crate::check::types::Ty::TyErr, qs: Array::new(), rqs: Array::new(), bounds: Array::new(), fields: Array::new(), home: Text::lit(""), file: Nat::from(0u32), span: crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) } }
}

/// ```prism
/// IsLive: fn Ty -> Bool
/// ```
pub fn is_live(t: &crate::check::types::Ty) -> bool {
    match crate::lower::types::peel(t) {
        crate::check::types::Ty::TyElem(_, _) => true,
        _ => false,
    }
}

/// ```prism
/// TagFieldName: fn FieldPat, [Text], Nat -> Text
/// ```
pub fn tag_field_name(fp: &crate::syntax::FieldPat, names: &Array<Text>, i: &Nat) -> Text {
    match &fp.name {
        Some(id) => id.name.clone(),
        None => match &*fp.pattern.kind {
            crate::syntax::PatternKind::PName(n) => if crate::check::types::has_text(names, &crate::check::env::sname_key(n)) {
                crate::check::env::sname_key(n)
            } else {
                or(&index(names, i), &Text::lit(""))
            },
            _ => or(&index(names, i), &Text::lit("")),
        },
    }
}

/// ```prism
/// TagPat: unbounded fn Lx, TagInfo, [FieldPat], Bool, Ty, Holding, Text -> PatOut
/// ```
pub fn tag_pat(lx: &crate::lower::Lx, tg: &crate::check::env::TagInfo, fps: &Array<crate::syntax::FieldPat>, rest: &bool, ty: &crate::check::types::Ty, mode: &crate::lower::types::Holding, fresh: &Text) -> PatOut {
    let (variant, struct_path) = crate::lower::program::tag_paths(lx, tg);
    let live = is_live(ty);
    let names = each(&tg.fields, &(|(f, _): &(Text, crate::check::types::Ty)| f.clone()));
    let sub_mode = if live { crate::lower::types::Holding::ByRef } else { mode.clone() };
    let parts = run_to_end(each_job(crate::check::errors::range0(&len(fps)), {
        let fps = fps.clone();
        let names = names.clone();
        let tg = tg.clone();
        let live = live;
        let lx = lx.clone();
        let variant = variant.clone();
        let fresh = fresh.clone();
        let sub_mode = sub_mode.clone();
        Rc::new(move |p0: Nat| {
            let fps = fps.clone();
            let names = names.clone();
            let tg = tg.clone();
            let live = live;
            let lx = lx.clone();
            let variant = variant.clone();
            let fresh = fresh.clone();
            let sub_mode = sub_mode.clone();
            entered(once_job(move || {
                let i = p0;
                {
                    let fp = or(&index(&fps, &i), &dummy_field_pat());
                    let fname = tag_field_name(&fp, &names, &i);
                    let ft = fold(&tg.fields, &crate::check::types::Ty::TyErr, &(|found: &crate::check::types::Ty, (f, t): &(Text, crate::check::types::Ty)| if f == &fname { t.clone() } else { found.clone() }));
                    match crate::lower::types::layer_of(&ft) {
                        crate::lower::types::Layer::LyEv => prism_rtl::Turn::Finished((None, PatOut { pa: crate::lower::model::Pa::PaWild, conds: Array::from(vec![crate::lower::model::Cc::CcIf(crate::lower::expr::refusal(&Text::from(format!("an event field in an element pattern ({}.{})", &tg.name, &fname))))]), binds: Array::new() })),
                        crate::lower::types::Layer::LyDyn if live => call_then(start_live_field_pat(lx.clone(), fp.pattern.clone(), variant.clone(), fname.clone(), ft.clone(), fresh.clone()), move |live_field_pat_13035: PatOut| prism_rtl::Turn::Finished((None, live_field_pat_13035))),
                        _ => call_then(start_rust_pat(lx.clone(), fp.pattern.clone(), crate::lower::types::peel(&ft), sub_mode.clone(), Text::from(format!("{}_{}", &fresh, &i))), move |rust_pat_13140: PatOut| {
                            let o = rust_pat_13140;
                            prism_rtl::Turn::Finished((Some(crate::lower::snake(&fname)), o.clone()))
                        }),
                        _ => unreachable!("no arm matched"),
                    }
                }
            }))
        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<(Option<Text>, PatOut)>>>
    }));
    let field_pas = fold(&parts, &Array::new(), &(|acc: &Array<(Text, crate::lower::model::Pa)>, (f_opt, o): &(Option<Text>, PatOut)| match f_opt {
        Some(f) => push(acc, &(f.clone(), o.pa.clone())),
        None => acc.clone(),
    }));
    let conds = fold(&parts, &Array::new(), &(|acc: &Array<crate::lower::model::Cc>, (_, o): &(Option<Text>, PatOut)| append(acc, &o.conds)));
    let binds = fold(&parts, &Array::new(), &(|acc: &Array<(Text, crate::lower::types::Bn)>, (_, o): &(Option<Text>, PatOut)| append(acc, &o.binds)));
    let level = crate::lower::model::Pa::PaCtor(variant.clone(), Array::from(vec![crate::lower::model::Pa::PaRecord(struct_path.clone(), field_pas.clone(), true)]));
    let tagged = push(&binds, &(Text::lit("#tag"), crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XPath(crate::lower::node_::elements::answer_variant(tg)), crate::lower::types::Holding::Owned, crate::lower::model::OutTy::OutUnit)));
    if live {
        PatOut { pa: crate::lower::model::Pa::PaBind(fresh.clone()), conds: append(&Array::from(vec![crate::lower::model::Cc::CcLet(level.clone(), crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XVar(fresh.clone())), Text::lit("identity")))))]), &conds), binds: tagged.clone() }
    } else {
        PatOut { pa: level.clone(), conds: conds.clone(), binds: binds.clone() }
    }
}

/// The step machine of `TagPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TagPat: unbounded fn Lx, TagInfo, [FieldPat], Bool, Ty, Holding, Text -> PatOut
/// ```
pub struct TagPat {
    pub lx: crate::lower::Lx,
    pub tg: crate::check::env::TagInfo,
    pub fps: Array<crate::syntax::FieldPat>,
    pub rest: bool,
    pub ty: crate::check::types::Ty,
    pub mode: crate::lower::types::Holding,
    pub fresh: Text,
}

impl prism_rtl::Job<PatOut> for TagPat {
    fn cycle(&self) -> prism_rtl::Turn<PatOut> {
        let lx = &self.lx;
        let tg = &self.tg;
        let fps = &self.fps;
        let rest = &self.rest;
        let ty = &self.ty;
        let mode = &self.mode;
        let fresh = &self.fresh;
        let (variant, struct_path) = crate::lower::program::tag_paths(lx, tg);
        let live = is_live(ty);
        let names = each(&tg.fields, &(|(f, _): &(Text, crate::check::types::Ty)| f.clone()));
        let sub_mode = if live { crate::lower::types::Holding::ByRef } else { mode.clone() };
        let fps = fps.clone();
        let fresh = fresh.clone();
        let lx = lx.clone();
        let tg = tg.clone();
        call_value(each_job(crate::check::errors::range0(&len(&fps)), {
            let fps = fps.clone();
            let names = names.clone();
            let tg = tg.clone();
            let live = live;
            let lx = lx.clone();
            let variant = variant.clone();
            let fresh = fresh.clone();
            let sub_mode = sub_mode.clone();
            Rc::new(move |p0: Nat| {
                let fps = fps.clone();
                let names = names.clone();
                let tg = tg.clone();
                let live = live;
                let lx = lx.clone();
                let variant = variant.clone();
                let fresh = fresh.clone();
                let sub_mode = sub_mode.clone();
                entered(once_job(move || {
                    let i = p0;
                    {
                        let fp = or(&index(&fps, &i), &dummy_field_pat());
                        let fname = tag_field_name(&fp, &names, &i);
                        let ft = fold(&tg.fields, &crate::check::types::Ty::TyErr, &(|found: &crate::check::types::Ty, (f, t): &(Text, crate::check::types::Ty)| if f == &fname { t.clone() } else { found.clone() }));
                        match crate::lower::types::layer_of(&ft) {
                            crate::lower::types::Layer::LyEv => prism_rtl::Turn::Finished((None, PatOut { pa: crate::lower::model::Pa::PaWild, conds: Array::from(vec![crate::lower::model::Cc::CcIf(crate::lower::expr::refusal(&Text::from(format!("an event field in an element pattern ({}.{})", &tg.name, &fname))))]), binds: Array::new() })),
                            crate::lower::types::Layer::LyDyn if live => call_then(start_live_field_pat(lx.clone(), fp.pattern.clone(), variant.clone(), fname.clone(), ft.clone(), fresh.clone()), move |live_field_pat_13035: PatOut| prism_rtl::Turn::Finished((None, live_field_pat_13035))),
                            _ => call_then(start_rust_pat(lx.clone(), fp.pattern.clone(), crate::lower::types::peel(&ft), sub_mode.clone(), Text::from(format!("{}_{}", &fresh, &i))), move |rust_pat_13140: PatOut| {
                                let o = rust_pat_13140;
                                prism_rtl::Turn::Finished((Some(crate::lower::snake(&fname)), o.clone()))
                            }),
                            _ => unreachable!("no arm matched"),
                        }
                    }
                }))
            }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<(Option<Text>, PatOut)>>>
        }), move |each_12624: Array<(Option<Text>, PatOut)>| {
            let parts = each_12624;
            let field_pas = fold(&parts, &Array::new(), &(|acc: &Array<(Text, crate::lower::model::Pa)>, (f_opt, o): &(Option<Text>, PatOut)| match f_opt {
                Some(f) => push(acc, &(f.clone(), o.pa.clone())),
                None => acc.clone(),
            }));
            let conds = fold(&parts, &Array::new(), &(|acc: &Array<crate::lower::model::Cc>, (_, o): &(Option<Text>, PatOut)| append(acc, &o.conds)));
            let binds = fold(&parts, &Array::new(), &(|acc: &Array<(Text, crate::lower::types::Bn)>, (_, o): &(Option<Text>, PatOut)| append(acc, &o.binds)));
            let level = crate::lower::model::Pa::PaCtor(variant.clone(), Array::from(vec![crate::lower::model::Pa::PaRecord(struct_path.clone(), field_pas.clone(), true)]));
            let tagged = push(&binds, &(Text::lit("#tag"), crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XPath(crate::lower::node_::elements::answer_variant(&tg)), crate::lower::types::Holding::Owned, crate::lower::model::OutTy::OutUnit)));
            if live {
                prism_rtl::Turn::Finished(PatOut { pa: crate::lower::model::Pa::PaBind(fresh.clone()), conds: append(&Array::from(vec![crate::lower::model::Cc::CcLet(level.clone(), crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XVar(fresh.clone())), Text::lit("identity")))))]), &conds), binds: tagged.clone() })
            } else {
                prism_rtl::Turn::Finished(PatOut { pa: level.clone(), conds: conds.clone(), binds: binds.clone() })
            }
        })
    }
}

/// `Start TagPat, x`: what the function value is when passed to `@Run`.
pub fn start_tag_pat(lx: crate::lower::Lx, tg: crate::check::env::TagInfo, fps: Array<crate::syntax::FieldPat>, rest: bool, ty: crate::check::types::Ty, mode: crate::lower::types::Holding, fresh: Text) -> Rc<dyn prism_rtl::Job<PatOut>> {
    Rc::new(TagPat { lx, tg, fps, rest, ty, mode, fresh })
}

/// ```prism
/// LiveFieldPat: unbounded fn Lx, Pattern, Text, Text, Ty, Text -> PatOut
/// ```
pub fn live_field_pat(lx: &crate::lower::Lx, p_: &crate::syntax::Pattern_, variant: &Text, fname: &Text, ft: &crate::check::types::Ty, fresh: &Text) -> PatOut {
    match &*p_.kind {
        crate::syntax::PatternKind::PIgnore => pat_only(&crate::lower::model::Pa::PaWild),
        crate::syntax::PatternKind::PName(n) => {
            let rs = if lx.in_node {
                live_projection(fresh, variant, fname, &crate::lower::types::out_ty_of(lx, &crate::lower::types::peel(ft)))
            } else {
                crate::lower::expr::refusal(&Text::from(format!("a live element\'s `$` field ({}) in a plain function, which has no read point (gap LE)", fname)))
            };
            PatOut { pa: crate::lower::model::Pa::PaWild, conds: Array::new(), binds: Array::from(vec![(crate::check::env::sname_key(n), crate::lower::types::Bn::BnLocal(rs.clone(), crate::lower::types::Holding::Owned, crate::lower::model::OutTy::OutDyn(Rc::new(crate::lower::types::out_ty_of(lx, &crate::lower::types::peel(ft))))))]) }
        },
        crate::syntax::PatternKind::PGroup(q) => live_field_pat(lx, &**q, variant, fname, ft, fresh),
        _ => PatOut { pa: crate::lower::model::Pa::PaWild, conds: Array::from(vec![crate::lower::model::Cc::CcIf(crate::lower::expr::refusal(&Text::from(format!("a pattern inside a live element\'s `$` field ({})", fname))))]), binds: Array::new() },
    }
}

/// The step machine of `LiveFieldPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LiveFieldPat: unbounded fn Lx, Pattern, Text, Text, Ty, Text -> PatOut
/// ```
pub struct LiveFieldPat {
    pub lx: crate::lower::Lx,
    pub p_: crate::syntax::Pattern_,
    pub variant: Text,
    pub fname: Text,
    pub ft: crate::check::types::Ty,
    pub fresh: Text,
}

impl prism_rtl::Job<PatOut> for LiveFieldPat {
    fn cycle(&self) -> prism_rtl::Turn<PatOut> {
        let lx = &self.lx;
        let p_ = &self.p_;
        let variant = &self.variant;
        let fname = &self.fname;
        let ft = &self.ft;
        let fresh = &self.fresh;
        match &*p_.kind {
            crate::syntax::PatternKind::PIgnore => prism_rtl::Turn::Finished(pat_only(&crate::lower::model::Pa::PaWild)),
            crate::syntax::PatternKind::PName(n) => {
                let rs = if lx.in_node {
                    live_projection(fresh, variant, fname, &crate::lower::types::out_ty_of(lx, &crate::lower::types::peel(ft)))
                } else {
                    crate::lower::expr::refusal(&Text::from(format!("a live element\'s `$` field ({}) in a plain function, which has no read point (gap LE)", fname)))
                };
                let ft = ft.clone();
                let lx = lx.clone();
                let n = n.clone();
                call_then(crate::lower::types::start_out_ty_of(lx.clone(), crate::lower::types::peel(&ft)), move |out_ty_of_14752: crate::lower::model::OutTy| prism_rtl::Turn::Finished(PatOut { pa: crate::lower::model::Pa::PaWild, conds: Array::new(), binds: Array::from(vec![(crate::check::env::sname_key(&n), crate::lower::types::Bn::BnLocal(rs.clone(), crate::lower::types::Holding::Owned, crate::lower::model::OutTy::OutDyn(Rc::new(out_ty_of_14752))))]) }))
            },
            crate::syntax::PatternKind::PGroup(q) => prism_rtl::Turn::More(Rc::new(LiveFieldPat { lx: lx.clone(), p_: (**q).clone(), variant: variant.clone(), fname: fname.clone(), ft: ft.clone(), fresh: fresh.clone() })),
            _ => prism_rtl::Turn::Finished(PatOut { pa: crate::lower::model::Pa::PaWild, conds: Array::from(vec![crate::lower::model::Cc::CcIf(crate::lower::expr::refusal(&Text::from(format!("a pattern inside a live element\'s `$` field ({})", fname))))]), binds: Array::new() }),
        }
    }
}

/// `Start LiveFieldPat, x`: what the function value is when passed to `@Run`.
pub fn start_live_field_pat(lx: crate::lower::Lx, p_: crate::syntax::Pattern_, variant: Text, fname: Text, ft: crate::check::types::Ty, fresh: Text) -> Rc<dyn prism_rtl::Job<PatOut>> {
    Rc::new(LiveFieldPat { lx, p_, variant, fname, ft, fresh })
}

/// ```prism
/// LiveProjection: fn Text, Text, Text, OutTy -> Ex
/// ```
pub fn live_projection(fresh: &Text, variant: &Text, fname: &Text, ft: &crate::lower::model::OutTy) -> crate::lower::model::Ex {
    let arm = crate::lower::model::XArm { pat: crate::lower::model::Pa::PaCtor(variant.clone(), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("x"))])), conds: Array::new(), body: crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XVar(Text::lit("x"))), crate::lower::snake(fname)))) };
    let other = crate::lower::model::XArm { pat: crate::lower::model::Pa::PaWild, conds: Array::new(), body: crate::lower::model::Ex::XUnreachable };
    crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XVar(fresh.clone())), Text::lit("level"))), Text::lit("map"), Array::from(vec![crate::lower::model::Ex::XClosure(true, Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("l"))]), Rc::new(crate::lower::model::Ex::XMatch(Rc::new(crate::lower::model::Ex::XVar(Text::lit("l"))), Array::from(vec![arm.clone(), other.clone()]), false, ft.clone())))]))
}

/// ```prism
/// FamilyPat: unbounded fn Lx, QualName, Ty, Text -> PatOut
/// ```
pub fn family_pat(lx: &crate::lower::Lx, q: &crate::syntax::QualName, ty: &crate::check::types::Ty, fresh: &Text) -> PatOut {
    let fam = crate::check::env::dotted(&filter(&q.path_, &(|x: &Text| x != &Text::lit("*"))));
    let kind = match crate::lower::types::peel(ty) {
        crate::check::types::Ty::TyElem(_, _) => Text::lit("Element"),
        crate::check::types::Ty::TyElemAny(_) => Text::lit("Element"),
        crate::check::types::Ty::TyCon(k, _) => k,
        _ => Text::lit(""),
    };
    let tags = filter(&crate::lower::program::kind_tags(lx, &kind, &keys(&lx.rs_mods)), &(|tg: &crate::check::env::TagInfo| &tg.family == &fam));
    let place_ = if is_live(ty) {
        crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XVar(fresh.clone())), Text::lit("identity"))
    } else {
        crate::lower::model::Ex::XVar(fresh.clone())
    };
    PatOut { pa: crate::lower::model::Pa::PaBind(fresh.clone()), conds: Array::from(vec![crate::lower::model::Cc::CcIf(crate::lower::model::Ex::XIsCase(Rc::new(place_.clone()), each(&tags, &(|tg: &crate::check::env::TagInfo| crate::lower::program::variant_of(lx, tg)))))]), binds: Array::new() }
}

/// The step machine of `FamilyPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FamilyPat: unbounded fn Lx, QualName, Ty, Text -> PatOut
/// ```
pub struct FamilyPat {
    pub lx: crate::lower::Lx,
    pub q: crate::syntax::QualName,
    pub ty: crate::check::types::Ty,
    pub fresh: Text,
}

impl prism_rtl::Job<PatOut> for FamilyPat {
    fn cycle(&self) -> prism_rtl::Turn<PatOut> {
        let lx = &self.lx;
        let q = &self.q;
        let ty = &self.ty;
        let fresh = &self.fresh;
        let fam = crate::check::env::dotted(&filter(&q.path_, &(|x: &Text| x != &Text::lit("*"))));
        let kind = match crate::lower::types::peel(ty) {
            crate::check::types::Ty::TyElem(_, _) => Text::lit("Element"),
            crate::check::types::Ty::TyElemAny(_) => Text::lit("Element"),
            crate::check::types::Ty::TyCon(k, _) => k,
            _ => Text::lit(""),
        };
        let tags = filter(&crate::lower::program::kind_tags(lx, &kind, &keys(&lx.rs_mods)), &(|tg: &crate::check::env::TagInfo| &tg.family == &fam));
        let place_ = if is_live(ty) {
            crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XVar(fresh.clone())), Text::lit("identity"))
        } else {
            crate::lower::model::Ex::XVar(fresh.clone())
        };
        prism_rtl::Turn::Finished(PatOut { pa: crate::lower::model::Pa::PaBind(fresh.clone()), conds: Array::from(vec![crate::lower::model::Cc::CcIf(crate::lower::model::Ex::XIsCase(Rc::new(place_.clone()), each(&tags, &(|tg: &crate::check::env::TagInfo| crate::lower::program::variant_of(lx, tg)))))]), binds: Array::new() })
    }
}

/// `Start FamilyPat, x`: what the function value is when passed to `@Run`.
pub fn start_family_pat(lx: crate::lower::Lx, q: crate::syntax::QualName, ty: crate::check::types::Ty, fresh: Text) -> Rc<dyn prism_rtl::Job<PatOut>> {
    Rc::new(FamilyPat { lx, q, ty, fresh })
}

/// ```prism
/// ErrorPat: unbounded fn Lx, [FieldPat], Ty, Holding, Text -> PatOut
/// ```
pub fn error_pat(lx: &crate::lower::Lx, fps: &Array<crate::syntax::FieldPat>, ty: &crate::check::types::Ty, mode: &crate::lower::types::Holding, fresh: &Text) -> PatOut {
    let e = crate::lower::types::local_place(&crate::lower::model::Ex::XVar(fresh.clone()), mode, &crate::lower::model::OutTy::OutError);
    let parts = each(fps, &(|fp: &crate::syntax::FieldPat| {
        let fname = match &fp.name {
            Some(id) => id.name.clone(),
            None => Text::lit(""),
        };
        match &fname {
            m16367_0 if (m16367_0 == &Text::lit("kind")) => match &*fp.pattern.kind {
                crate::syntax::PatternKind::PName(k) => {
                    let (kq_opt, _) = crate::check::env::names::resolve_value(&lx.g, &lx.home, k);
                    match &kq_opt {
                        Some(kq) => if crate::check::env::has_key(&lx.g.tags, kq) {
                            (Array::from(vec![crate::lower::model::Cc::CcIf(crate::lower::model::Ex::XBin(Text::lit("=="), Rc::new(crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XDeref(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XVar(fresh.clone())), Text::lit("kind"))))))), Rc::new(crate::lower::model::Ex::XStr(kq.clone()))))]), Array::new())
                        } else {
                            (Array::new(), Array::from(vec![(crate::check::env::sname_key(k), crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XVar(fresh.clone())), Text::lit("kind")), crate::lower::types::Holding::Owned, crate::lower::model::OutTy::OutText))]))
                        },
                        None => (Array::new(), Array::from(vec![(crate::check::env::sname_key(k), crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XVar(fresh.clone())), Text::lit("kind")), crate::lower::types::Holding::Owned, crate::lower::model::OutTy::OutText))])),
                    }
                },
                _ => (Array::new(), Array::new()),
            },
            m16367_1 if (m16367_1 == &Text::lit("message")) => match &*fp.pattern.kind {
                crate::syntax::PatternKind::PName(m) => (Array::new(), Array::from(vec![(crate::check::env::sname_key(m), crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XVar(fresh.clone())), Text::lit("message")), crate::lower::types::Holding::Owned, crate::lower::model::OutTy::OutText))])),
                _ => (Array::new(), Array::new()),
            },
            _ => (Array::new(), Array::new()),
            _ => unreachable!("no arm matched"),
        }
    }));
    let wrapped = match crate::lower::types::peel(ty) {
        crate::check::types::Ty::TySig(m17204_0_0, _) if (&m17204_0_0 == &Text::lit("~")) => crate::lower::model::Pa::PaCtor(Text::lit("Err"), Array::from(vec![crate::lower::model::Pa::PaBind(fresh.clone())])),
        _ => crate::lower::model::Pa::PaBind(fresh.clone()),
        _ => unreachable!("no arm matched"),
    };
    PatOut { pa: wrapped.clone(), conds: fold(&parts, &Array::new(), &(|acc: &Array<crate::lower::model::Cc>, (cs, _): &(Array<crate::lower::model::Cc>, Array<(Text, crate::lower::types::Bn)>)| append(acc, cs))), binds: fold(&parts, &Array::new(), &(|acc: &Array<(Text, crate::lower::types::Bn)>, (_, bs): &(Array<crate::lower::model::Cc>, Array<(Text, crate::lower::types::Bn)>)| append(acc, bs))) }
}

/// The step machine of `ErrorPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ErrorPat: unbounded fn Lx, [FieldPat], Ty, Holding, Text -> PatOut
/// ```
pub struct ErrorPat {
    pub lx: crate::lower::Lx,
    pub fps: Array<crate::syntax::FieldPat>,
    pub ty: crate::check::types::Ty,
    pub mode: crate::lower::types::Holding,
    pub fresh: Text,
}

impl prism_rtl::Job<PatOut> for ErrorPat {
    fn cycle(&self) -> prism_rtl::Turn<PatOut> {
        let lx = &self.lx;
        let fps = &self.fps;
        let ty = &self.ty;
        let mode = &self.mode;
        let fresh = &self.fresh;
        let e = crate::lower::types::local_place(&crate::lower::model::Ex::XVar(fresh.clone()), mode, &crate::lower::model::OutTy::OutError);
        let parts = each(fps, &(|fp: &crate::syntax::FieldPat| {
            let fname = match &fp.name {
                Some(id) => id.name.clone(),
                None => Text::lit(""),
            };
            match &fname {
                m16367_0 if (m16367_0 == &Text::lit("kind")) => match &*fp.pattern.kind {
                    crate::syntax::PatternKind::PName(k) => {
                        let (kq_opt, _) = crate::check::env::names::resolve_value(&lx.g, &lx.home, k);
                        match &kq_opt {
                            Some(kq) => if crate::check::env::has_key(&lx.g.tags, kq) {
                                (Array::from(vec![crate::lower::model::Cc::CcIf(crate::lower::model::Ex::XBin(Text::lit("=="), Rc::new(crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XDeref(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XVar(fresh.clone())), Text::lit("kind"))))))), Rc::new(crate::lower::model::Ex::XStr(kq.clone()))))]), Array::new())
                            } else {
                                (Array::new(), Array::from(vec![(crate::check::env::sname_key(k), crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XVar(fresh.clone())), Text::lit("kind")), crate::lower::types::Holding::Owned, crate::lower::model::OutTy::OutText))]))
                            },
                            None => (Array::new(), Array::from(vec![(crate::check::env::sname_key(k), crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XVar(fresh.clone())), Text::lit("kind")), crate::lower::types::Holding::Owned, crate::lower::model::OutTy::OutText))])),
                        }
                    },
                    _ => (Array::new(), Array::new()),
                },
                m16367_1 if (m16367_1 == &Text::lit("message")) => match &*fp.pattern.kind {
                    crate::syntax::PatternKind::PName(m) => (Array::new(), Array::from(vec![(crate::check::env::sname_key(m), crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XVar(fresh.clone())), Text::lit("message")), crate::lower::types::Holding::Owned, crate::lower::model::OutTy::OutText))])),
                    _ => (Array::new(), Array::new()),
                },
                _ => (Array::new(), Array::new()),
                _ => unreachable!("no arm matched"),
            }
        }));
        let wrapped = match crate::lower::types::peel(ty) {
            crate::check::types::Ty::TySig(m17204_0_0, _) if (&m17204_0_0 == &Text::lit("~")) => crate::lower::model::Pa::PaCtor(Text::lit("Err"), Array::from(vec![crate::lower::model::Pa::PaBind(fresh.clone())])),
            _ => crate::lower::model::Pa::PaBind(fresh.clone()),
            _ => unreachable!("no arm matched"),
        };
        prism_rtl::Turn::Finished(PatOut { pa: wrapped.clone(), conds: fold(&parts, &Array::new(), &(|acc: &Array<crate::lower::model::Cc>, (cs, _): &(Array<crate::lower::model::Cc>, Array<(Text, crate::lower::types::Bn)>)| append(acc, cs))), binds: fold(&parts, &Array::new(), &(|acc: &Array<(Text, crate::lower::types::Bn)>, (_, bs): &(Array<crate::lower::model::Cc>, Array<(Text, crate::lower::types::Bn)>)| append(acc, bs))) })
    }
}

/// `Start ErrorPat, x`: what the function value is when passed to `@Run`.
pub fn start_error_pat(lx: crate::lower::Lx, fps: Array<crate::syntax::FieldPat>, ty: crate::check::types::Ty, mode: crate::lower::types::Holding, fresh: Text) -> Rc<dyn prism_rtl::Job<PatOut>> {
    Rc::new(ErrorPat { lx, fps, ty, mode, fresh })
}

/// ```prism
/// ArrayPat: unbounded fn Lx, [Pattern], Ty, Holding, Text -> PatOut
/// ```
pub fn array_pat(lx: &crate::lower::Lx, ps: &Array<crate::syntax::Pattern_>, ty: &crate::check::types::Ty, mode: &crate::lower::types::Holding, fresh: &Text) -> PatOut {
    let et = match crate::lower::types::peel(ty) {
        crate::check::types::Ty::TyArray(x) => (*x).clone(),
        _ => crate::check::types::Ty::TyErr,
    };
    let arr = crate::lower::types::local_place(&crate::lower::model::Ex::XVar(fresh.clone()), mode, &crate::lower::types::out_ty_of(lx, &crate::lower::types::peel(ty)));
    let len_cond = crate::lower::model::Cc::CcIf(crate::lower::model::Ex::XBin(Text::lit("=="), Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::types::ref_(&arr)), Text::lit("len"), Array::new())), Rc::new(crate::lower::model::Ex::XIndex(len(ps)))));
    let subs = run_to_end(each_job(crate::check::errors::range0(&len(ps)), {
        let lx = lx.clone();
        let ps = ps.clone();
        let et = et.clone();
        let fresh = fresh.clone();
        Rc::new(move |p0: Nat| {
            let lx = lx.clone();
            let ps = ps.clone();
            let et = et.clone();
            let fresh = fresh.clone();
            entered(once_job(move || {
                let i = p0;
                call_then(start_rust_pat(lx.clone(), or(&index(&ps, &i), &dummy_pat()), et.clone(), crate::lower::types::Holding::Owned, Text::from(format!("{}_{}", &fresh, &i))), move |rust_pat_17901: PatOut| prism_rtl::Turn::Finished((i.clone(), rust_pat_17901)))
            }))
        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<(Nat, PatOut)>>>
    }));
    let conds = fold(&subs, &Array::from(vec![len_cond.clone()]), &(|acc: &Array<crate::lower::model::Cc>, (i, o): &(Nat, PatOut)| append(&push(acc, &crate::lower::model::Cc::CcLet(crate::lower::model::Pa::PaCtor(Text::lit("Some"), Array::from(vec![o.pa.clone()])), crate::lower::model::Ex::XCall(Text::lit("index"), Array::from(vec![crate::lower::types::ref_(&arr), crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XNat(Text::from(format!("{}", i)))))])))), &o.conds)));
    let binds = fold(&subs, &Array::new(), &(|acc: &Array<(Text, crate::lower::types::Bn)>, (_, o): &(Nat, PatOut)| append(acc, &o.binds)));
    PatOut { pa: crate::lower::model::Pa::PaBind(fresh.clone()), conds: conds.clone(), binds: binds.clone() }
}

/// The step machine of `ArrayPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ArrayPat: unbounded fn Lx, [Pattern], Ty, Holding, Text -> PatOut
/// ```
pub struct ArrayPat {
    pub lx: crate::lower::Lx,
    pub ps: Array<crate::syntax::Pattern_>,
    pub ty: crate::check::types::Ty,
    pub mode: crate::lower::types::Holding,
    pub fresh: Text,
}

impl prism_rtl::Job<PatOut> for ArrayPat {
    fn cycle(&self) -> prism_rtl::Turn<PatOut> {
        let lx = &self.lx;
        let ps = &self.ps;
        let ty = &self.ty;
        let mode = &self.mode;
        let fresh = &self.fresh;
        let et = match crate::lower::types::peel(ty) {
            crate::check::types::Ty::TyArray(x) => (*x).clone(),
            _ => crate::check::types::Ty::TyErr,
        };
        let fresh = fresh.clone();
        let lx = lx.clone();
        let mode = mode.clone();
        let ps = ps.clone();
        let ty = ty.clone();
        call_then(crate::lower::types::start_out_ty_of(lx.clone(), crate::lower::types::peel(&ty)), move |out_ty_of_17740: crate::lower::model::OutTy| {
            let arr = crate::lower::types::local_place(&crate::lower::model::Ex::XVar(fresh.clone()), &mode, &out_ty_of_17740);
            let len_cond = crate::lower::model::Cc::CcIf(crate::lower::model::Ex::XBin(Text::lit("=="), Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::types::ref_(&arr)), Text::lit("len"), Array::new())), Rc::new(crate::lower::model::Ex::XIndex(len(&ps)))));
            call_value(each_job(crate::check::errors::range0(&len(&ps)), {
                let lx = lx.clone();
                let ps = ps.clone();
                let et = et.clone();
                let fresh = fresh.clone();
                Rc::new(move |p0: Nat| {
                    let lx = lx.clone();
                    let ps = ps.clone();
                    let et = et.clone();
                    let fresh = fresh.clone();
                    entered(once_job(move || {
                        let i = p0;
                        call_then(start_rust_pat(lx.clone(), or(&index(&ps, &i), &dummy_pat()), et.clone(), crate::lower::types::Holding::Owned, Text::from(format!("{}_{}", &fresh, &i))), move |rust_pat_17901: PatOut| prism_rtl::Turn::Finished((i.clone(), rust_pat_17901)))
                    }))
                }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<(Nat, PatOut)>>>
            }), move |each_17866: Array<(Nat, PatOut)>| {
                let subs = each_17866;
                let conds = fold(&subs, &Array::from(vec![len_cond.clone()]), &(|acc: &Array<crate::lower::model::Cc>, (i, o): &(Nat, PatOut)| append(&push(acc, &crate::lower::model::Cc::CcLet(crate::lower::model::Pa::PaCtor(Text::lit("Some"), Array::from(vec![o.pa.clone()])), crate::lower::model::Ex::XCall(Text::lit("index"), Array::from(vec![crate::lower::types::ref_(&arr), crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XNat(Text::from(format!("{}", i)))))])))), &o.conds)));
                let binds = fold(&subs, &Array::new(), &(|acc: &Array<(Text, crate::lower::types::Bn)>, (_, o): &(Nat, PatOut)| append(acc, &o.binds)));
                prism_rtl::Turn::Finished(PatOut { pa: crate::lower::model::Pa::PaBind(fresh.clone()), conds: conds.clone(), binds: binds.clone() })
            })
        })
    }
}

/// `Start ArrayPat, x`: what the function value is when passed to `@Run`.
pub fn start_array_pat(lx: crate::lower::Lx, ps: Array<crate::syntax::Pattern_>, ty: crate::check::types::Ty, mode: crate::lower::types::Holding, fresh: Text) -> Rc<dyn prism_rtl::Job<PatOut>> {
    Rc::new(ArrayPat { lx, ps, ty, mode, fresh })
}
