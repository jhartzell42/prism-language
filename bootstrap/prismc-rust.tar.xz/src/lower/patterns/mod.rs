//! The module `Lower.Patterns`, from `target/bootstrap/src/prismc/lower/patterns.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// `PatOut`:
///
/// ```prism
/// type PatOut = record:
/// ```
#[derive(Clone)]
pub struct PatOut {
    pub pa_p: crate::lower::model::Pa,
    pub conds_p: Array<crate::lower::model::Cc>,
    pub binds_p: Array<(Text, crate::lower::types::Bn)>,
}

/// ```prism
/// PatOnly: fn Pa -> PatOut
/// ```
pub fn pat_only_f(pa_p0: &crate::lower::model::Pa) -> PatOut {
    PatOut { pa_p: pa_p0.clone(), conds_p: Array::new(), binds_p: Array::new() }
}

/// ```prism
/// RustPat: unbounded fn Lx, Pattern, Ty, Holding, Text -> PatOut
/// ```
pub fn rust_pat_f(lx_p0: &crate::lower::Lx, p_p1: &crate::syntax::Pattern_, ty_p2: &crate::check::types::Ty, mode_p3: &crate::lower::types::Holding, fresh_p4: &Text) -> PatOut {
    match &*p_p1.kind_p {
        crate::syntax::PatternKind::PName(n_p5) => {
            let nkey_p6 = crate::check::env::sname_key_f(n_p5);
            let (qk_o9, why_pa) = crate::check::env::names::resolve_value_f(&lx_p0.g_p, &lx_p0.home_p, n_p5);
            let is_ctor_p7 = match &qk_o9 {
                Some(qk_pb) => crate::check::env::has_key_f(&lx_p0.g_p.ctors_p, qk_pb) && ((crate::check::env::is_upper_text_f(&crate::lower::base_f(&nkey_p6)) || (&crate::prelude::len(&n_p5.path_p) > &Nat::from(1u32))) || is_unit_ctor_f(lx_p0, qk_pb)),
                None => false,
            };
            let tagged_o8 = match &qk_o9 {
                Some(qk_pc) => crate::prelude::get(&lx_p0.g_p.tags_p, qk_pc),
                None => None,
            };
            if is_ctor_p7 {
                ctor_pat_f(lx_p0, n_p5, &Array::new(), ty_p2, mode_p3, fresh_p4)
            } else {
                if (&why_pa == &Text::lit("tag")) && (&tagged_o8 != &None) {
                    tag_pat_f(lx_p0, &crate::prelude::or(&tagged_o8, &dummy_tag_info_p()), &Array::new(), &true, ty_p2, mode_p3, fresh_p4)
                } else {
                    {
                        let rs_pd = crate::lower::local_name_at_f(lx_p0, &nkey_p6, &n_p5.span_p);
                        let bt_pe = crate::lower::types::out_ty_of_f(lx_p0, &crate::lower::types::peel_f(&crate::lower::binder_ty_f(lx_p0, &n_p5.span_p)));
                        PatOut { pa_p: crate::lower::model::Pa::PaBind(rs_pd.clone()), conds_p: Array::new(), binds_p: Array::from(vec![(nkey_p6.clone(), crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(rs_pd.clone()), mode_p3.clone(), bt_pe.clone()))]) }
                    }
                }
            }
        },
        crate::syntax::PatternKind::PIgnore => pat_only_f(&crate::lower::model::Pa::PaWild),
        crate::syntax::PatternKind::PUnit => pat_only_f(&crate::lower::model::Pa::PaWild),
        crate::syntax::PatternKind::PNil => pat_only_f(&crate::lower::model::Pa::PaUnit(Text::lit("None"))),
        crate::syntax::PatternKind::PLit(l_pf) => lit_pat_f(lx_p0, l_pf, ty_p2, mode_p3, fresh_p4, &false),
        crate::syntax::PatternKind::PNeg(l_pg) => lit_pat_f(lx_p0, l_pg, ty_p2, mode_p3, fresh_p4, &true),
        crate::syntax::PatternKind::PSigil(m1652_6_0, q_ph) if (m1652_6_0 == &Text::lit("?")) => wrap_pat_f(lx_p0, &Text::lit("Some"), &**q_ph, &inner_ty_f(ty_p2), mode_p3, fresh_p4),
        crate::syntax::PatternKind::PSigil(m1652_7_0, q_pi) if (m1652_7_0 == &Text::lit("~")) => wrap_pat_f(lx_p0, &Text::lit("Ok"), &**q_pi, &inner_ty_f(ty_p2), mode_p3, fresh_p4),
        crate::syntax::PatternKind::PSigil(_, q_pj) => rust_pat_f(lx_p0, &**q_pj, ty_p2, mode_p3, fresh_p4),
        crate::syntax::PatternKind::PGroup(q_pk) => rust_pat_f(lx_p0, &**q_pk, ty_p2, mode_p3, fresh_p4),
        crate::syntax::PatternKind::PCtor(n_pl, ps_pm) => ctor_pat_f(lx_p0, n_pl, ps_pm, ty_p2, mode_p3, fresh_p4),
        crate::syntax::PatternKind::PRecord(n_pn, fps_po, rest_pp) => record_pat_f(lx_p0, n_pn, fps_po, rest_pp, ty_p2, mode_p3, fresh_p4),
        crate::syntax::PatternKind::PTuple(ps_pq) => {
            let ts_pr = match crate::lower::types::peel_f(ty_p2) {
                crate::check::types::Ty::TyTuple(xs_pt) => xs_pt,
                _ => Array::new(),
            };
            let subs_ps = crate::prelude::run_to_end(crate::prelude::each_job(crate::check::errors::range0_f(&crate::prelude::len(ps_pq)), {
                let lx_p0x = lx_p0.clone();
                let ps_pqx = ps_pq.clone();
                let ts_prx = ts_pr.clone();
                let mode_p3x = mode_p3.clone();
                let fresh_p4x = fresh_p4.clone();
                Rc::new(move |p0: Nat| {
                    let lx_p0xy = lx_p0x.clone();
                    let ps_pqxy = ps_pqx.clone();
                    let ts_prxy = ts_prx.clone();
                    let mode_p3xy = mode_p3x.clone();
                    let fresh_p4xy = fresh_p4x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let i_pu = p0;
                        prism_rtl::Turn::More(Rc::new(RustPat { lx_p0: lx_p0xy.clone(), p_p1: crate::prelude::or(&crate::prelude::index(&ps_pqxy, &i_pu), &dummy_pat_p()), ty_p2: crate::prelude::or(&crate::prelude::index(&ts_prxy, &i_pu), &crate::check::types::Ty::TyErr), mode_p3: mode_p3xy.clone(), fresh_p4: Text::from(format!("{}_{}", &fresh_p4xy, &i_pu)) }))
                    }))
                }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<PatOut>>>
            }));
            PatOut { pa_p: crate::lower::model::Pa::PaTuple(crate::prelude::each(&subs_ps, &(|o_pv: &PatOut| o_pv.pa_p.clone()))), conds_p: crate::prelude::fold(&subs_ps, &Array::new(), &(|acc_p10: &Array<crate::lower::model::Cc>, o_p11: &PatOut| crate::prelude::append(acc_p10, &o_p11.conds_p))), binds_p: crate::prelude::fold(&subs_ps, &Array::new(), &(|acc_p12: &Array<(Text, crate::lower::types::Bn)>, o_p13: &PatOut| crate::prelude::append(acc_p12, &o_p13.binds_p))) }
        },
        crate::syntax::PatternKind::PArray(ps_p14) => array_pat_f(lx_p0, ps_p14, ty_p2, mode_p3, fresh_p4),
        crate::syntax::PatternKind::PFamily(q_p15) => family_pat_f(lx_p0, q_p15, ty_p2, fresh_p4),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `RustPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RustPat: unbounded fn Lx, Pattern, Ty, Holding, Text -> PatOut
/// ```
pub struct RustPat {
    pub lx_p0: crate::lower::Lx,
    pub p_p1: crate::syntax::Pattern_,
    pub ty_p2: crate::check::types::Ty,
    pub mode_p3: crate::lower::types::Holding,
    pub fresh_p4: Text,
}

impl prism_rtl::Job<PatOut> for RustPat {
    fn cycle(&self) -> prism_rtl::Turn<PatOut> {
        let lx_p0 = &self.lx_p0;
        let p_p1 = &self.p_p1;
        let ty_p2 = &self.ty_p2;
        let mode_p3 = &self.mode_p3;
        let fresh_p4 = &self.fresh_p4;
        match &*p_p1.kind_p {
            crate::syntax::PatternKind::PName(n_p5) => {
                let nkey_p6 = crate::check::env::sname_key_f(n_p5);
                let (qk_o9, why_pa) = crate::check::env::names::resolve_value_f(&lx_p0.g_p, &lx_p0.home_p, n_p5);
                let is_ctor_p7 = match &qk_o9 {
                    Some(qk_pb) => crate::check::env::has_key_f(&lx_p0.g_p.ctors_p, qk_pb) && ((crate::check::env::is_upper_text_f(&crate::lower::base_f(&nkey_p6)) || (&crate::prelude::len(&n_p5.path_p) > &Nat::from(1u32))) || is_unit_ctor_f(lx_p0, qk_pb)),
                    None => false,
                };
                let tagged_o8 = match &qk_o9 {
                    Some(qk_pc) => crate::prelude::get(&lx_p0.g_p.tags_p, qk_pc),
                    None => None,
                };
                if is_ctor_p7 {
                    prism_rtl::Turn::More(Rc::new(CtorPat { lx_p0: lx_p0.clone(), n_p1: n_p5.clone(), ps_p2: Array::new(), ty_p3: ty_p2.clone(), mode_p4: mode_p3.clone(), fresh_p5: fresh_p4.clone() }))
                } else {
                    if (&why_pa == &Text::lit("tag")) && (&tagged_o8 != &None) {
                        prism_rtl::Turn::More(Rc::new(TagPat { lx_p0: lx_p0.clone(), tg_p1: crate::prelude::or(&tagged_o8, &dummy_tag_info_p()), fps_p2: Array::new(), rest_p3: true, ty_p4: ty_p2.clone(), mode_p5: mode_p3.clone(), fresh_p6: fresh_p4.clone() }))
                    } else {
                        {
                            let lx_p0x = lx_p0.clone();
                            let mode_p3x = mode_p3.clone();
                            let n_p5x = n_p5.clone();
                            crate::prelude::call_then(crate::lower::start_local_name_at_f(lx_p0x.clone(), nkey_p6.clone(), n_p5x.span_p.clone()), move |local_name_at_f_2230: Text| {
                                let rs_pd = local_name_at_f_2230;
                                crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0x.clone(), crate::lower::types::peel_f(&crate::lower::binder_ty_f(&lx_p0x, &n_p5x.span_p))), move |out_ty_of_f_2280: crate::lower::model::OutTy| {
                                    let bt_pe = out_ty_of_f_2280;
                                    prism_rtl::Turn::Finished(PatOut { pa_p: crate::lower::model::Pa::PaBind(rs_pd.clone()), conds_p: Array::new(), binds_p: Array::from(vec![(nkey_p6.clone(), crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(rs_pd.clone()), mode_p3x.clone(), bt_pe.clone()))]) })
                                })
                            })
                        }
                    }
                }
            },
            crate::syntax::PatternKind::PIgnore => prism_rtl::Turn::Finished(pat_only_f(&crate::lower::model::Pa::PaWild)),
            crate::syntax::PatternKind::PUnit => prism_rtl::Turn::Finished(pat_only_f(&crate::lower::model::Pa::PaWild)),
            crate::syntax::PatternKind::PNil => prism_rtl::Turn::Finished(pat_only_f(&crate::lower::model::Pa::PaUnit(Text::lit("None")))),
            crate::syntax::PatternKind::PLit(l_pf) => prism_rtl::Turn::More(Rc::new(LitPat { lx_p0: lx_p0.clone(), l_p1: l_pf.clone(), ty_p2: ty_p2.clone(), mode_p3: mode_p3.clone(), fresh_p4: fresh_p4.clone(), neg_p5: false })),
            crate::syntax::PatternKind::PNeg(l_pg) => prism_rtl::Turn::More(Rc::new(LitPat { lx_p0: lx_p0.clone(), l_p1: l_pg.clone(), ty_p2: ty_p2.clone(), mode_p3: mode_p3.clone(), fresh_p4: fresh_p4.clone(), neg_p5: true })),
            crate::syntax::PatternKind::PSigil(m1652_6_0, q_ph) if (m1652_6_0 == &Text::lit("?")) => prism_rtl::Turn::More(Rc::new(WrapPat { lx_p0: lx_p0.clone(), ctor_p1: Text::lit("Some"), q_p2: (**q_ph).clone(), inner_p3: inner_ty_f(ty_p2), mode_p4: mode_p3.clone(), fresh_p5: fresh_p4.clone() })),
            crate::syntax::PatternKind::PSigil(m1652_7_0, q_pi) if (m1652_7_0 == &Text::lit("~")) => prism_rtl::Turn::More(Rc::new(WrapPat { lx_p0: lx_p0.clone(), ctor_p1: Text::lit("Ok"), q_p2: (**q_pi).clone(), inner_p3: inner_ty_f(ty_p2), mode_p4: mode_p3.clone(), fresh_p5: fresh_p4.clone() })),
            crate::syntax::PatternKind::PSigil(_, q_pj) => prism_rtl::Turn::More(Rc::new(RustPat { lx_p0: lx_p0.clone(), p_p1: (**q_pj).clone(), ty_p2: ty_p2.clone(), mode_p3: mode_p3.clone(), fresh_p4: fresh_p4.clone() })),
            crate::syntax::PatternKind::PGroup(q_pk) => prism_rtl::Turn::More(Rc::new(RustPat { lx_p0: lx_p0.clone(), p_p1: (**q_pk).clone(), ty_p2: ty_p2.clone(), mode_p3: mode_p3.clone(), fresh_p4: fresh_p4.clone() })),
            crate::syntax::PatternKind::PCtor(n_pl, ps_pm) => prism_rtl::Turn::More(Rc::new(CtorPat { lx_p0: lx_p0.clone(), n_p1: n_pl.clone(), ps_p2: ps_pm.clone(), ty_p3: ty_p2.clone(), mode_p4: mode_p3.clone(), fresh_p5: fresh_p4.clone() })),
            crate::syntax::PatternKind::PRecord(n_pn, fps_po, rest_pp) => prism_rtl::Turn::More(Rc::new(RecordPat { lx_p0: lx_p0.clone(), n_p1: n_pn.clone(), fps_p2: fps_po.clone(), rest_p3: *rest_pp, ty_p4: ty_p2.clone(), mode_p5: mode_p3.clone(), fresh_p6: fresh_p4.clone() })),
            crate::syntax::PatternKind::PTuple(ps_pq) => {
                let ts_pr = match crate::lower::types::peel_f(ty_p2) {
                    crate::check::types::Ty::TyTuple(xs_pt) => xs_pt,
                    _ => Array::new(),
                };
                let fresh_p4x = fresh_p4.clone();
                let lx_p0x = lx_p0.clone();
                let mode_p3x = mode_p3.clone();
                let ps_pqx = ps_pq.clone();
                crate::prelude::call_value(crate::prelude::each_job(crate::check::errors::range0_f(&crate::prelude::len(&ps_pqx)), {
                    let lx_p0xx = lx_p0x.clone();
                    let ps_pqxx = ps_pqx.clone();
                    let ts_prx = ts_pr.clone();
                    let mode_p3xx = mode_p3x.clone();
                    let fresh_p4xx = fresh_p4x.clone();
                    Rc::new(move |p0: Nat| {
                        let lx_p0xxy = lx_p0xx.clone();
                        let ps_pqxxy = ps_pqxx.clone();
                        let ts_prxy = ts_prx.clone();
                        let mode_p3xxy = mode_p3xx.clone();
                        let fresh_p4xxy = fresh_p4xx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let i_pu = p0;
                            prism_rtl::Turn::More(Rc::new(RustPat { lx_p0: lx_p0xxy.clone(), p_p1: crate::prelude::or(&crate::prelude::index(&ps_pqxxy, &i_pu), &dummy_pat_p()), ty_p2: crate::prelude::or(&crate::prelude::index(&ts_prxy, &i_pu), &crate::check::types::Ty::TyErr), mode_p3: mode_p3xxy.clone(), fresh_p4: Text::from(format!("{}_{}", &fresh_p4xxy, &i_pu)) }))
                        }))
                    }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<PatOut>>>
                }), move |each_3079: Array<PatOut>| {
                    let subs_ps = each_3079;
                    prism_rtl::Turn::Finished(PatOut { pa_p: crate::lower::model::Pa::PaTuple(crate::prelude::each(&subs_ps, &(|o_pv: &PatOut| o_pv.pa_p.clone()))), conds_p: crate::prelude::fold(&subs_ps, &Array::new(), &(|acc_p10: &Array<crate::lower::model::Cc>, o_p11: &PatOut| crate::prelude::append(acc_p10, &o_p11.conds_p))), binds_p: crate::prelude::fold(&subs_ps, &Array::new(), &(|acc_p12: &Array<(Text, crate::lower::types::Bn)>, o_p13: &PatOut| crate::prelude::append(acc_p12, &o_p13.binds_p))) })
                })
            },
            crate::syntax::PatternKind::PArray(ps_p14) => prism_rtl::Turn::More(Rc::new(ArrayPat { lx_p0: lx_p0.clone(), ps_p1: ps_p14.clone(), ty_p2: ty_p2.clone(), mode_p3: mode_p3.clone(), fresh_p4: fresh_p4.clone() })),
            crate::syntax::PatternKind::PFamily(q_p15) => prism_rtl::Turn::More(Rc::new(FamilyPat { lx_p0: lx_p0.clone(), q_p1: q_p15.clone(), ty_p2: ty_p2.clone(), fresh_p3: fresh_p4.clone() })),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start RustPat, x`: what the function value is when passed to `@Run`.
pub fn start_rust_pat_f(lx_p0: crate::lower::Lx, p_p1: crate::syntax::Pattern_, ty_p2: crate::check::types::Ty, mode_p3: crate::lower::types::Holding, fresh_p4: Text) -> Rc<dyn prism_rtl::Job<PatOut>> {
    Rc::new(RustPat { lx_p0, p_p1, ty_p2, mode_p3, fresh_p4 })
}

/// ```prism
/// let dummyPat
/// ```
pub fn dummy_pat_p() -> crate::syntax::Pattern_ {
    crate::syntax::Pattern_ { kind_p: Rc::new(crate::syntax::PatternKind::PIgnore), span_p: crate::syntax::Range { start_p: Nat::from(0u32), end_p: Nat::from(0u32) } }
}

/// ```prism
/// InnerTy: fn Ty -> Ty
/// ```
pub fn inner_ty_f(t_p0: &crate::check::types::Ty) -> crate::check::types::Ty {
    match crate::lower::types::peel_f(t_p0) {
        crate::check::types::Ty::TySig(m3538_0_0, i_p1) if (&m3538_0_0 == &Text::lit("?")) => (*i_p1).clone(),
        crate::check::types::Ty::TySig(m3538_1_0, i_p2) if (&m3538_1_0 == &Text::lit("~")) => (*i_p2).clone(),
        _ => crate::check::types::Ty::TyErr,
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// IsUnitCtor: fn Lx, Text -> Bool
/// ```
pub fn is_unit_ctor_f(lx_p0: &crate::lower::Lx, qk_p1: &Text) -> bool {
    match crate::prelude::get(&lx_p0.g_p.ctors_p, qk_p1) {
        Some(c_p2) => 'm3791: {
            let scrutinee = &crate::prelude::or(&crate::prelude::get(&lx_p0.g_p.types_p, &c_p2.owner_p), &crate::check::env::names::dummy_ty_info_p()).body_p;
            if let crate::check::env::TyBody::BChoice(m3791_0_0) = scrutinee && (m3791_0_0.len() == 1) && let Some((_, m3791_0_0_0_1)) = crate::prelude::index(m3791_0_0, &Nat::from(0u32)) && ((&m3791_0_0_0_1).len() == 0) {
                break 'm3791 crate::check::env::is_lower_text_f(&crate::check::types::bare_name_f(qk_p1));
            }
            false
        },
        None => false,
    }
}

/// ```prism
/// WrapPat: unbounded fn Lx, Text, Pattern, Ty, Holding, Text -> PatOut
/// ```
pub fn wrap_pat_f(lx_p0: &crate::lower::Lx, ctor_p1: &Text, q_p2: &crate::syntax::Pattern_, inner_p3: &crate::check::types::Ty, mode_p4: &crate::lower::types::Holding, fresh_p5: &Text) -> PatOut {
    let o_p6 = rust_pat_f(lx_p0, q_p2, inner_p3, mode_p4, fresh_p5);
    let mut this: PatOut = o_p6.clone();
    this.pa_p = crate::lower::model::Pa::PaCtor(ctor_p1.clone(), Array::from(vec![this.pa_p.clone()]));
    this
}

/// The step machine of `WrapPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// WrapPat: unbounded fn Lx, Text, Pattern, Ty, Holding, Text -> PatOut
/// ```
pub struct WrapPat {
    pub lx_p0: crate::lower::Lx,
    pub ctor_p1: Text,
    pub q_p2: crate::syntax::Pattern_,
    pub inner_p3: crate::check::types::Ty,
    pub mode_p4: crate::lower::types::Holding,
    pub fresh_p5: Text,
}

impl prism_rtl::Job<PatOut> for WrapPat {
    fn cycle(&self) -> prism_rtl::Turn<PatOut> {
        let lx_p0 = &self.lx_p0;
        let ctor_p1 = &self.ctor_p1;
        let q_p2 = &self.q_p2;
        let inner_p3 = &self.inner_p3;
        let mode_p4 = &self.mode_p4;
        let fresh_p5 = &self.fresh_p5;
        let ctor_p1x = ctor_p1.clone();
        let fresh_p5x = fresh_p5.clone();
        let inner_p3x = inner_p3.clone();
        let lx_p0x = lx_p0.clone();
        let mode_p4x = mode_p4.clone();
        let q_p2x = q_p2.clone();
        crate::prelude::call_then(start_rust_pat_f(lx_p0x.clone(), q_p2x.clone(), inner_p3x.clone(), mode_p4x.clone(), fresh_p5x.clone()), move |rust_pat_f_4071: PatOut| {
            let o_p6 = rust_pat_f_4071;
            prism_rtl::Turn::Finished({
                let mut this: PatOut = o_p6.clone();
                this.pa_p = crate::lower::model::Pa::PaCtor(ctor_p1x.clone(), Array::from(vec![this.pa_p.clone()]));
                this
            })
        })
    }
}

/// `Start WrapPat, x`: what the function value is when passed to `@Run`.
pub fn start_wrap_pat_f(lx_p0: crate::lower::Lx, ctor_p1: Text, q_p2: crate::syntax::Pattern_, inner_p3: crate::check::types::Ty, mode_p4: crate::lower::types::Holding, fresh_p5: Text) -> Rc<dyn prism_rtl::Job<PatOut>> {
    Rc::new(WrapPat { lx_p0, ctor_p1, q_p2, inner_p3, mode_p4, fresh_p5 })
}

/// ```prism
/// LitPat: unbounded fn Lx, Literal, Ty, Holding, Text, Bool -> PatOut
/// ```
pub fn lit_pat_f(lx_p0: &crate::lower::Lx, l_p1: &crate::syntax::Literal, ty_p2: &crate::check::types::Ty, mode_p3: &crate::lower::types::Holding, fresh_p4: &Text, neg_p5: &bool) -> PatOut {
    let t_p6 = crate::lower::types::out_ty_of_f(lx_p0, &crate::lower::types::peel_f(ty_p2));
    match &l_p1.kind_p {
        crate::syntax::LitKind::LChar(c_p7) => pat_only_f(&crate::lower::model::Pa::PaChar(c_p7.clone())),
        _ => {
            let lit_p8 = match &l_p1.kind_p {
                crate::syntax::LitKind::LInt(d_pb) => if (((&t_p6 == &crate::lower::model::OutTy::OutNat) || (&t_p6 == &crate::lower::model::OutTy::OutInt)) || (&t_p6 == &crate::lower::model::OutTy::OutU8)) || (&t_p6 == &crate::lower::model::OutTy::OutFloat) {
                    crate::lower::types::Vl::VlOwned(crate::lower::expr::number_f(&t_p6, d_pb, neg_p5), t_p6.clone())
                } else {
                    crate::lower::expr::literal_value_f(lx_p0, &crate::lower::types::empty_env_p(), l_p1, &l_p1.span_p, neg_p5)
                },
                _ => crate::lower::expr::literal_value_f(lx_p0, &crate::lower::types::empty_env_p(), l_p1, &l_p1.span_p, neg_p5),
            };
            let lv_p9 = crate::lower::types::Vl::VlOwned(crate::lower::types::own_f(&lit_p8), t_p6.clone());
            let b_pa = crate::lower::types::local_place_f(&crate::lower::model::Ex::XVar(fresh_p4.clone()), mode_p3, &t_p6);
            PatOut { pa_p: crate::lower::model::Pa::PaBind(fresh_p4.clone()), conds_p: Array::from(vec![crate::lower::model::Cc::CcIf(crate::lower::model::Ex::XBin(crate::lower::model::BinOp::OpEq, Rc::new(crate::lower::types::ref_f(&b_pa)), Rc::new(crate::lower::types::ref_f(&lv_p9))))]), binds_p: Array::new() }
        },
    }
}

/// The step machine of `LitPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LitPat: unbounded fn Lx, Literal, Ty, Holding, Text, Bool -> PatOut
/// ```
pub struct LitPat {
    pub lx_p0: crate::lower::Lx,
    pub l_p1: crate::syntax::Literal,
    pub ty_p2: crate::check::types::Ty,
    pub mode_p3: crate::lower::types::Holding,
    pub fresh_p4: Text,
    pub neg_p5: bool,
}

impl prism_rtl::Job<PatOut> for LitPat {
    fn cycle(&self) -> prism_rtl::Turn<PatOut> {
        let lx_p0 = &self.lx_p0;
        let l_p1 = &self.l_p1;
        let ty_p2 = &self.ty_p2;
        let mode_p3 = &self.mode_p3;
        let fresh_p4 = &self.fresh_p4;
        let neg_p5 = &self.neg_p5;
        let fresh_p4x = fresh_p4.clone();
        let l_p1x = l_p1.clone();
        let lx_p0x = lx_p0.clone();
        let mode_p3x = mode_p3.clone();
        let neg_p5x = *neg_p5;
        let ty_p2x = ty_p2.clone();
        crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0x.clone(), crate::lower::types::peel_f(&ty_p2x)), move |out_ty_of_f_4383: crate::lower::model::OutTy| {
            let t_p6 = out_ty_of_f_4383;
            match &l_p1x.kind_p {
                crate::syntax::LitKind::LChar(c_p7) => prism_rtl::Turn::Finished(pat_only_f(&crate::lower::model::Pa::PaChar(c_p7.clone()))),
                _ => {
                    let lit_p8 = match &l_p1x.kind_p {
                        crate::syntax::LitKind::LInt(d_pb) => if (((&t_p6 == &crate::lower::model::OutTy::OutNat) || (&t_p6 == &crate::lower::model::OutTy::OutInt)) || (&t_p6 == &crate::lower::model::OutTy::OutU8)) || (&t_p6 == &crate::lower::model::OutTy::OutFloat) {
                            crate::lower::types::Vl::VlOwned(crate::lower::expr::number_f(&t_p6, d_pb, &neg_p5x), t_p6.clone())
                        } else {
                            crate::lower::expr::literal_value_f(&lx_p0x, &crate::lower::types::empty_env_p(), &l_p1x, &l_p1x.span_p, &neg_p5x)
                        },
                        _ => crate::lower::expr::literal_value_f(&lx_p0x, &crate::lower::types::empty_env_p(), &l_p1x, &l_p1x.span_p, &neg_p5x),
                    };
                    let lv_p9 = crate::lower::types::Vl::VlOwned(crate::lower::types::own_f(&lit_p8), t_p6.clone());
                    let b_pa = crate::lower::types::local_place_f(&crate::lower::model::Ex::XVar(fresh_p4x.clone()), &mode_p3x, &t_p6);
                    prism_rtl::Turn::Finished(PatOut { pa_p: crate::lower::model::Pa::PaBind(fresh_p4x.clone()), conds_p: Array::from(vec![crate::lower::model::Cc::CcIf(crate::lower::model::Ex::XBin(crate::lower::model::BinOp::OpEq, Rc::new(crate::lower::types::ref_f(&b_pa)), Rc::new(crate::lower::types::ref_f(&lv_p9))))]), binds_p: Array::new() })
                },
            }
        })
    }
}

/// `Start LitPat, x`: what the function value is when passed to `@Run`.
pub fn start_lit_pat_f(lx_p0: crate::lower::Lx, l_p1: crate::syntax::Literal, ty_p2: crate::check::types::Ty, mode_p3: crate::lower::types::Holding, fresh_p4: Text, neg_p5: bool) -> Rc<dyn prism_rtl::Job<PatOut>> {
    Rc::new(LitPat { lx_p0, l_p1, ty_p2, mode_p3, fresh_p4, neg_p5 })
}

/// ```prism
/// CtorPat: unbounded fn Lx, SName, [Pattern], Ty, Holding, Text -> PatOut
/// ```
pub fn ctor_pat_f(lx_p0: &crate::lower::Lx, n_p1: &crate::syntax::SName, ps_p2: &Array<crate::syntax::Pattern_>, ty_p3: &crate::check::types::Ty, mode_p4: &crate::lower::types::Holding, fresh_p5: &Text) -> PatOut {
    let (qk_o6, _) = crate::check::env::names::resolve_value_f(&lx_p0.g_p, &lx_p0.home_p, n_p1);
    match &qk_o6 {
        Some(m5426_0) if (m5426_0 == &Text::lit("True")) => pat_only_f(&crate::lower::model::Pa::PaBool(true)),
        Some(m5426_1) if (m5426_1 == &Text::lit("False")) => pat_only_f(&crate::lower::model::Pa::PaBool(false)),
        Some(qk_p7) => match crate::prelude::get(&lx_p0.g_p.ctors_p, qk_p7) {
            Some(c_p8) => {
                let owner_p9 = crate::prelude::or(&crate::prelude::get(&lx_p0.g_p.types_p, &c_p8.owner_p), &crate::check::env::names::dummy_ty_info_p());
                let ty_path_pa = crate::lower::path_in_f(lx_p0, &owner_p9.home_p, &crate::lower::camel_f(&crate::check::types::bare_name_f(&c_p8.owner_p)));
                let args_pb = match crate::lower::types::peel_f(ty_p3) {
                    crate::check::types::Ty::TyCon(_, xs_pg) => xs_pg,
                    _ => Array::new(),
                };
                let subs_pc = crate::prelude::run_to_end(crate::prelude::each_job(crate::check::errors::range0_f(&crate::prelude::len(ps_p2)), {
                    let lx_p0x = lx_p0.clone();
                    let c_p8x = c_p8.clone();
                    let ps_p2x = ps_p2.clone();
                    let args_pbx = args_pb.clone();
                    let mode_p4x = mode_p4.clone();
                    let fresh_p5x = fresh_p5.clone();
                    Rc::new(move |p0: Nat| {
                        let lx_p0xy = lx_p0x.clone();
                        let c_p8xy = c_p8x.clone();
                        let ps_p2xy = ps_p2x.clone();
                        let args_pbxy = args_pbx.clone();
                        let mode_p4xy = mode_p4x.clone();
                        let fresh_p5xy = fresh_p5x.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let i_ph = p0;
                            crate::prelude::call_then(crate::lower::expr::start_instantiated_f(crate::prelude::or(&crate::prelude::index(&c_p8xy.args_p, &i_ph), &crate::check::types::Ty::TyErr), c_p8xy.params_p.clone(), args_pbxy.clone()), move |instantiated_f_5930: crate::check::types::Ty| prism_rtl::Turn::More(Rc::new(SubPat { lx_p0: lx_p0xy.clone(), c_p1: c_p8xy.clone(), i_p2: i_ph.clone(), p_p3: crate::prelude::or(&crate::prelude::index(&ps_p2xy, &i_ph), &dummy_pat_p()), ty_p4: instantiated_f_5930, mode_p5: mode_p4xy.clone(), fresh_p6: Text::from(format!("{}_{}", &fresh_p5xy, &i_ph)) })))
                        }))
                    }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<PatOut>>>
                }));
                let conds_pd = crate::prelude::fold(&subs_pc, &Array::new(), &(|acc_pi: &Array<crate::lower::model::Cc>, o_pj: &PatOut| crate::prelude::append(acc_pi, &o_pj.conds_p)));
                let binds_pe = crate::prelude::fold(&subs_pc, &Array::new(), &(|acc_pk: &Array<(Text, crate::lower::types::Bn)>, o_pl: &PatOut| crate::prelude::append(acc_pk, &o_pl.binds_p)));
                let pas_pf = crate::prelude::each(&subs_pc, &(|o_pm: &PatOut| o_pm.pa_p.clone()));
                match &owner_p9.body_p {
                    crate::check::env::TyBody::BRecord(fs_pn) => PatOut { pa_p: crate::lower::model::Pa::PaRecord(ty_path_pa.clone(), crate::prelude::run_to_end(crate::prelude::each_job(crate::check::errors::range0_f(&crate::prelude::len(&pas_pf)), {
                        let c_p8x = c_p8.clone();
                        let pas_pfx = pas_pf.clone();
                        Rc::new(move |p0: Nat| {
                            let c_p8xy = c_p8x.clone();
                            let pas_pfxy = pas_pfx.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let i_po = p0;
                                crate::prelude::call_then(crate::lower::start_field_spell_f(crate::lower::owner_of_f(&c_p8xy.owner_p), crate::prelude::or(&crate::prelude::index(&c_p8xy.fields_p, &i_po), &Text::lit("")), crate::prelude::or(&crate::prelude::index(&c_p8xy.args_p, &i_po), &crate::check::types::Ty::TyErr)), move |field_spell_f_6328: Text| prism_rtl::Turn::Finished((field_spell_f_6328, crate::prelude::or(&crate::prelude::index(&pas_pfxy, &i_po), &crate::lower::model::Pa::PaWild))))
                            }))
                        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<(Text, crate::lower::model::Pa)>>>
                    })), &crate::prelude::len(&pas_pf) < &crate::prelude::len(&c_p8.fields_p)), conds_p: conds_pd.clone(), binds_p: binds_pe.clone() },
                    _ => {
                        let is_unit_type_pp = (&crate::prelude::len(&c_p8.args_p) == &Nat::from(0u32)) && is_unit_ctor_f(lx_p0, qk_p7);
                        let is_newtype_pq = (&crate::check::types::bare_name_f(&c_p8.name_p) == &crate::check::types::bare_name_f(&c_p8.owner_p)) && match &owner_p9.body_p {
                            crate::check::env::TyBody::BChoice(cases_ps) => &crate::prelude::len(cases_ps) == &Nat::from(1u32),
                            _ => false,
                        };
                        let path_pr = if is_unit_type_pp || is_newtype_pq {
                            ty_path_pa.clone()
                        } else {
                            Text::from(format!("{}::{}", &ty_path_pa, &crate::lower::camel_f(&crate::check::types::bare_name_f(&c_p8.name_p))))
                        };
                        if &crate::prelude::len(&c_p8.args_p) == &Nat::from(0u32) {
                            PatOut { pa_p: crate::lower::model::Pa::PaUnit(path_pr.clone()), conds_p: Array::new(), binds_p: Array::new() }
                        } else {
                            PatOut { pa_p: crate::lower::model::Pa::PaCtor(path_pr.clone(), pas_pf.clone()), conds_p: conds_pd.clone(), binds_p: binds_pe.clone() }
                        }
                    },
                }
            },
            None => PatOut { pa_p: crate::lower::model::Pa::PaWild, conds_p: Array::from(vec![crate::lower::model::Cc::CcIf(crate::lower::expr::refusal_f(&Text::from(format!("a pattern of {}", qk_p7))))]), binds_p: Array::new() },
        },
        None => PatOut { pa_p: crate::lower::model::Pa::PaWild, conds_p: Array::from(vec![crate::lower::model::Cc::CcIf(crate::lower::expr::refusal_f(&Text::lit("a pattern of an unknown constructor")))]), binds_p: Array::new() },
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `CtorPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CtorPat: unbounded fn Lx, SName, [Pattern], Ty, Holding, Text -> PatOut
/// ```
pub struct CtorPat {
    pub lx_p0: crate::lower::Lx,
    pub n_p1: crate::syntax::SName,
    pub ps_p2: Array<crate::syntax::Pattern_>,
    pub ty_p3: crate::check::types::Ty,
    pub mode_p4: crate::lower::types::Holding,
    pub fresh_p5: Text,
}

impl prism_rtl::Job<PatOut> for CtorPat {
    fn cycle(&self) -> prism_rtl::Turn<PatOut> {
        let lx_p0 = &self.lx_p0;
        let n_p1 = &self.n_p1;
        let ps_p2 = &self.ps_p2;
        let ty_p3 = &self.ty_p3;
        let mode_p4 = &self.mode_p4;
        let fresh_p5 = &self.fresh_p5;
        let (qk_o6, _) = crate::check::env::names::resolve_value_f(&lx_p0.g_p, &lx_p0.home_p, n_p1);
        match &qk_o6 {
            Some(m5426_0) if (m5426_0 == &Text::lit("True")) => prism_rtl::Turn::Finished(pat_only_f(&crate::lower::model::Pa::PaBool(true))),
            Some(m5426_1) if (m5426_1 == &Text::lit("False")) => prism_rtl::Turn::Finished(pat_only_f(&crate::lower::model::Pa::PaBool(false))),
            Some(qk_p7) => match crate::prelude::get(&lx_p0.g_p.ctors_p, qk_p7) {
                Some(c_p8) => {
                    let owner_p9 = crate::prelude::or(&crate::prelude::get(&lx_p0.g_p.types_p, &c_p8.owner_p), &crate::check::env::names::dummy_ty_info_p());
                    let ty_path_pa = crate::lower::path_in_f(lx_p0, &owner_p9.home_p, &crate::lower::camel_f(&crate::check::types::bare_name_f(&c_p8.owner_p)));
                    let args_pb = match crate::lower::types::peel_f(ty_p3) {
                        crate::check::types::Ty::TyCon(_, xs_pg) => xs_pg,
                        _ => Array::new(),
                    };
                    let fresh_p5x = fresh_p5.clone();
                    let lx_p0x = lx_p0.clone();
                    let mode_p4x = mode_p4.clone();
                    let ps_p2x = ps_p2.clone();
                    let qk_p7x = qk_p7.clone();
                    crate::prelude::call_value(crate::prelude::each_job(crate::check::errors::range0_f(&crate::prelude::len(&ps_p2x)), {
                        let lx_p0xx = lx_p0x.clone();
                        let c_p8x = c_p8.clone();
                        let ps_p2xx = ps_p2x.clone();
                        let args_pbx = args_pb.clone();
                        let mode_p4xx = mode_p4x.clone();
                        let fresh_p5xx = fresh_p5x.clone();
                        Rc::new(move |p0: Nat| {
                            let lx_p0xxy = lx_p0xx.clone();
                            let c_p8xy = c_p8x.clone();
                            let ps_p2xxy = ps_p2xx.clone();
                            let args_pbxy = args_pbx.clone();
                            let mode_p4xxy = mode_p4xx.clone();
                            let fresh_p5xxy = fresh_p5xx.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let i_ph = p0;
                                crate::prelude::call_then(crate::lower::expr::start_instantiated_f(crate::prelude::or(&crate::prelude::index(&c_p8xy.args_p, &i_ph), &crate::check::types::Ty::TyErr), c_p8xy.params_p.clone(), args_pbxy.clone()), move |instantiated_f_5930: crate::check::types::Ty| prism_rtl::Turn::More(Rc::new(SubPat { lx_p0: lx_p0xxy.clone(), c_p1: c_p8xy.clone(), i_p2: i_ph.clone(), p_p3: crate::prelude::or(&crate::prelude::index(&ps_p2xxy, &i_ph), &dummy_pat_p()), ty_p4: instantiated_f_5930, mode_p5: mode_p4xxy.clone(), fresh_p6: Text::from(format!("{}_{}", &fresh_p5xxy, &i_ph)) })))
                            }))
                        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<PatOut>>>
                    }), move |each_5861: Array<PatOut>| {
                        let subs_pc = each_5861;
                        let conds_pd = crate::prelude::fold(&subs_pc, &Array::new(), &(|acc_pi: &Array<crate::lower::model::Cc>, o_pj: &PatOut| crate::prelude::append(acc_pi, &o_pj.conds_p)));
                        let binds_pe = crate::prelude::fold(&subs_pc, &Array::new(), &(|acc_pk: &Array<(Text, crate::lower::types::Bn)>, o_pl: &PatOut| crate::prelude::append(acc_pk, &o_pl.binds_p)));
                        let pas_pf = crate::prelude::each(&subs_pc, &(|o_pm: &PatOut| o_pm.pa_p.clone()));
                        match &owner_p9.body_p {
                            crate::check::env::TyBody::BRecord(fs_pn) => crate::prelude::call_value(crate::prelude::each_job(crate::check::errors::range0_f(&crate::prelude::len(&pas_pf)), {
                                let c_p8x = c_p8.clone();
                                let pas_pfx = pas_pf.clone();
                                Rc::new(move |p0: Nat| {
                                    let c_p8xy = c_p8x.clone();
                                    let pas_pfxy = pas_pfx.clone();
                                    crate::prelude::entered(crate::prelude::once_job(move || {
                                        let i_po = p0;
                                        crate::prelude::call_then(crate::lower::start_field_spell_f(crate::lower::owner_of_f(&c_p8xy.owner_p), crate::prelude::or(&crate::prelude::index(&c_p8xy.fields_p, &i_po), &Text::lit("")), crate::prelude::or(&crate::prelude::index(&c_p8xy.args_p, &i_po), &crate::check::types::Ty::TyErr)), move |field_spell_f_6328: Text| prism_rtl::Turn::Finished((field_spell_f_6328, crate::prelude::or(&crate::prelude::index(&pas_pfxy, &i_po), &crate::lower::model::Pa::PaWild))))
                                    }))
                                }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<(Text, crate::lower::model::Pa)>>>
                            }), move |each_6295: Array<(Text, crate::lower::model::Pa)>| prism_rtl::Turn::Finished(PatOut { pa_p: crate::lower::model::Pa::PaRecord(ty_path_pa.clone(), each_6295, &crate::prelude::len(&pas_pf) < &crate::prelude::len(&c_p8.fields_p)), conds_p: conds_pd.clone(), binds_p: binds_pe.clone() })),
                            _ => {
                                let is_unit_type_pp = (&crate::prelude::len(&c_p8.args_p) == &Nat::from(0u32)) && is_unit_ctor_f(&lx_p0x, &qk_p7x);
                                let is_newtype_pq = (&crate::check::types::bare_name_f(&c_p8.name_p) == &crate::check::types::bare_name_f(&c_p8.owner_p)) && match &owner_p9.body_p {
                                    crate::check::env::TyBody::BChoice(cases_ps) => &crate::prelude::len(cases_ps) == &Nat::from(1u32),
                                    _ => false,
                                };
                                let path_pr = if is_unit_type_pp || is_newtype_pq {
                                    ty_path_pa.clone()
                                } else {
                                    Text::from(format!("{}::{}", &ty_path_pa, &crate::lower::camel_f(&crate::check::types::bare_name_f(&c_p8.name_p))))
                                };
                                if &crate::prelude::len(&c_p8.args_p) == &Nat::from(0u32) {
                                    prism_rtl::Turn::Finished(PatOut { pa_p: crate::lower::model::Pa::PaUnit(path_pr.clone()), conds_p: Array::new(), binds_p: Array::new() })
                                } else {
                                    prism_rtl::Turn::Finished(PatOut { pa_p: crate::lower::model::Pa::PaCtor(path_pr.clone(), pas_pf.clone()), conds_p: conds_pd.clone(), binds_p: binds_pe.clone() })
                                }
                            },
                        }
                    })
                },
                None => prism_rtl::Turn::Finished(PatOut { pa_p: crate::lower::model::Pa::PaWild, conds_p: Array::from(vec![crate::lower::model::Cc::CcIf(crate::lower::expr::refusal_f(&Text::from(format!("a pattern of {}", qk_p7))))]), binds_p: Array::new() }),
            },
            None => prism_rtl::Turn::Finished(PatOut { pa_p: crate::lower::model::Pa::PaWild, conds_p: Array::from(vec![crate::lower::model::Cc::CcIf(crate::lower::expr::refusal_f(&Text::lit("a pattern of an unknown constructor")))]), binds_p: Array::new() }),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start CtorPat, x`: what the function value is when passed to `@Run`.
pub fn start_ctor_pat_f(lx_p0: crate::lower::Lx, n_p1: crate::syntax::SName, ps_p2: Array<crate::syntax::Pattern_>, ty_p3: crate::check::types::Ty, mode_p4: crate::lower::types::Holding, fresh_p5: Text) -> Rc<dyn prism_rtl::Job<PatOut>> {
    Rc::new(CtorPat { lx_p0, n_p1, ps_p2, ty_p3, mode_p4, fresh_p5 })
}

/// ```prism
/// SubPat: unbounded fn Lx, CtorInfo, Nat, Pattern, Ty, Holding, Text -> PatOut
/// ```
pub fn sub_pat_f(lx_p0: &crate::lower::Lx, c_p1: &crate::check::env::CtorInfo, i_p2: &Nat, p_p3: &crate::syntax::Pattern_, ty_p4: &crate::check::types::Ty, mode_p5: &crate::lower::types::Holding, fresh_p6: &Text) -> PatOut {
    if !crate::lower::types::rc_field_f(lx_p0, &c_p1.name_p, i_p2) {
        rust_pat_f(lx_p0, p_p3, ty_p4, mode_p5, fresh_p6)
    } else {
        {
            let rc_mode_p7 = if mode_p5 == &crate::lower::types::Holding::Owned {
                crate::lower::types::Holding::RcOwned
            } else {
                crate::lower::types::Holding::RcRef
            };
            match &*p_p3.kind_p {
                crate::syntax::PatternKind::PIgnore => pat_only_f(&crate::lower::model::Pa::PaWild),
                crate::syntax::PatternKind::PName(n_p8) => {
                    let o_p9 = rust_pat_f(lx_p0, p_p3, ty_p4, &rc_mode_p7, fresh_p6);
                    match &o_p9.pa_p {
                        crate::lower::model::Pa::PaBind(_) => o_p9.clone(),
                        _ => behind_rc_f(lx_p0, p_p3, ty_p4, &rc_mode_p7, fresh_p6),
                    }
                },
                _ => behind_rc_f(lx_p0, p_p3, ty_p4, &rc_mode_p7, fresh_p6),
            }
        }
    }
}

/// The step machine of `SubPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SubPat: unbounded fn Lx, CtorInfo, Nat, Pattern, Ty, Holding, Text -> PatOut
/// ```
pub struct SubPat {
    pub lx_p0: crate::lower::Lx,
    pub c_p1: crate::check::env::CtorInfo,
    pub i_p2: Nat,
    pub p_p3: crate::syntax::Pattern_,
    pub ty_p4: crate::check::types::Ty,
    pub mode_p5: crate::lower::types::Holding,
    pub fresh_p6: Text,
}

impl prism_rtl::Job<PatOut> for SubPat {
    fn cycle(&self) -> prism_rtl::Turn<PatOut> {
        let lx_p0 = &self.lx_p0;
        let c_p1 = &self.c_p1;
        let i_p2 = &self.i_p2;
        let p_p3 = &self.p_p3;
        let ty_p4 = &self.ty_p4;
        let mode_p5 = &self.mode_p5;
        let fresh_p6 = &self.fresh_p6;
        if !crate::lower::types::rc_field_f(lx_p0, &c_p1.name_p, i_p2) {
            prism_rtl::Turn::More(Rc::new(RustPat { lx_p0: lx_p0.clone(), p_p1: p_p3.clone(), ty_p2: ty_p4.clone(), mode_p3: mode_p5.clone(), fresh_p4: fresh_p6.clone() }))
        } else {
            {
                let rc_mode_p7 = if mode_p5 == &crate::lower::types::Holding::Owned {
                    crate::lower::types::Holding::RcOwned
                } else {
                    crate::lower::types::Holding::RcRef
                };
                match &*p_p3.kind_p {
                    crate::syntax::PatternKind::PIgnore => prism_rtl::Turn::Finished(pat_only_f(&crate::lower::model::Pa::PaWild)),
                    crate::syntax::PatternKind::PName(n_p8) => {
                        let fresh_p6x = fresh_p6.clone();
                        let lx_p0x = lx_p0.clone();
                        let p_p3x = p_p3.clone();
                        let ty_p4x = ty_p4.clone();
                        crate::prelude::call_then(start_rust_pat_f(lx_p0x.clone(), p_p3x.clone(), ty_p4x.clone(), rc_mode_p7.clone(), fresh_p6x.clone()), move |rust_pat_f_7871: PatOut| {
                            let o_p9 = rust_pat_f_7871;
                            match &o_p9.pa_p {
                                crate::lower::model::Pa::PaBind(_) => prism_rtl::Turn::Finished(o_p9.clone()),
                                _ => prism_rtl::Turn::More(Rc::new(BehindRc { lx_p0: lx_p0x.clone(), p_p1: p_p3x.clone(), ty_p2: ty_p4x.clone(), rc_mode_p3: rc_mode_p7.clone(), fresh_p4: fresh_p6x.clone() })),
                            }
                        })
                    },
                    _ => prism_rtl::Turn::More(Rc::new(BehindRc { lx_p0: lx_p0.clone(), p_p1: p_p3.clone(), ty_p2: ty_p4.clone(), rc_mode_p3: rc_mode_p7.clone(), fresh_p4: fresh_p6.clone() })),
                }
            }
        }
    }
}

/// `Start SubPat, x`: what the function value is when passed to `@Run`.
pub fn start_sub_pat_f(lx_p0: crate::lower::Lx, c_p1: crate::check::env::CtorInfo, i_p2: Nat, p_p3: crate::syntax::Pattern_, ty_p4: crate::check::types::Ty, mode_p5: crate::lower::types::Holding, fresh_p6: Text) -> Rc<dyn prism_rtl::Job<PatOut>> {
    Rc::new(SubPat { lx_p0, c_p1, i_p2, p_p3, ty_p4, mode_p5, fresh_p6 })
}

/// ```prism
/// BehindRc: unbounded fn Lx, Pattern, Ty, Holding, Text -> PatOut
/// ```
pub fn behind_rc_f(lx_p0: &crate::lower::Lx, p_p1: &crate::syntax::Pattern_, ty_p2: &crate::check::types::Ty, rc_mode_p3: &crate::lower::types::Holding, fresh_p4: &Text) -> PatOut {
    let inner_p5 = rust_pat_f(lx_p0, p_p1, ty_p2, &crate::lower::types::Holding::ByRef, &Text::from(format!("{}_r", fresh_p4)));
    let place_p6 = crate::lower::types::ref_f(&crate::lower::types::local_place_f(&crate::lower::model::Ex::XVar(fresh_p4.clone()), rc_mode_p3, &crate::lower::model::OutTy::OutRefused(Text::lit("a payload"))));
    PatOut { pa_p: crate::lower::model::Pa::PaBind(fresh_p4.clone()), conds_p: crate::prelude::append(&Array::from(vec![crate::lower::model::Cc::CcLet(inner_p5.pa_p.clone(), place_p6.clone())]), &inner_p5.conds_p), binds_p: inner_p5.binds_p.clone() }
}

/// The step machine of `BehindRc`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BehindRc: unbounded fn Lx, Pattern, Ty, Holding, Text -> PatOut
/// ```
pub struct BehindRc {
    pub lx_p0: crate::lower::Lx,
    pub p_p1: crate::syntax::Pattern_,
    pub ty_p2: crate::check::types::Ty,
    pub rc_mode_p3: crate::lower::types::Holding,
    pub fresh_p4: Text,
}

impl prism_rtl::Job<PatOut> for BehindRc {
    fn cycle(&self) -> prism_rtl::Turn<PatOut> {
        let lx_p0 = &self.lx_p0;
        let p_p1 = &self.p_p1;
        let ty_p2 = &self.ty_p2;
        let rc_mode_p3 = &self.rc_mode_p3;
        let fresh_p4 = &self.fresh_p4;
        let fresh_p4x = fresh_p4.clone();
        let lx_p0x = lx_p0.clone();
        let p_p1x = p_p1.clone();
        let rc_mode_p3x = rc_mode_p3.clone();
        let ty_p2x = ty_p2.clone();
        crate::prelude::call_then(start_rust_pat_f(lx_p0x.clone(), p_p1x.clone(), ty_p2x.clone(), crate::lower::types::Holding::ByRef, Text::from(format!("{}_r", &fresh_p4x))), move |rust_pat_f_8210: PatOut| {
            let inner_p5 = rust_pat_f_8210;
            let place_p6 = crate::lower::types::ref_f(&crate::lower::types::local_place_f(&crate::lower::model::Ex::XVar(fresh_p4x.clone()), &rc_mode_p3x, &crate::lower::model::OutTy::OutRefused(Text::lit("a payload"))));
            prism_rtl::Turn::Finished(PatOut { pa_p: crate::lower::model::Pa::PaBind(fresh_p4x.clone()), conds_p: crate::prelude::append(&Array::from(vec![crate::lower::model::Cc::CcLet(inner_p5.pa_p.clone(), place_p6.clone())]), &inner_p5.conds_p), binds_p: inner_p5.binds_p.clone() })
        })
    }
}

/// `Start BehindRc, x`: what the function value is when passed to `@Run`.
pub fn start_behind_rc_f(lx_p0: crate::lower::Lx, p_p1: crate::syntax::Pattern_, ty_p2: crate::check::types::Ty, rc_mode_p3: crate::lower::types::Holding, fresh_p4: Text) -> Rc<dyn prism_rtl::Job<PatOut>> {
    Rc::new(BehindRc { lx_p0, p_p1, ty_p2, rc_mode_p3, fresh_p4 })
}

/// ```prism
/// RecordPat: unbounded fn Lx, SName, [FieldPat], Bool, Ty, Holding, Text -> PatOut
/// ```
pub fn record_pat_f(lx_p0: &crate::lower::Lx, n_p1: &crate::syntax::SName, fps_p2: &Array<crate::syntax::FieldPat>, rest_p3: &bool, ty_p4: &crate::check::types::Ty, mode_p5: &crate::lower::types::Holding, fresh_p6: &Text) -> PatOut {
    let (qk_o8, why_p9) = crate::check::env::names::resolve_value_f(&lx_p0.g_p, &lx_p0.home_p, n_p1);
    let qk_p7 = crate::prelude::or(&qk_o8, &Text::lit(""));
    if &qk_p7 == &Text::lit("Prelude.Error") {
        error_pat_f(lx_p0, fps_p2, ty_p4, mode_p5, fresh_p6)
    } else {
        if (&why_p9 == &Text::lit("tag")) && crate::check::env::has_key_f(&lx_p0.g_p.tags_p, &qk_p7) {
            tag_pat_f(lx_p0, &crate::prelude::or(&crate::prelude::get(&lx_p0.g_p.tags_p, &qk_p7), &dummy_tag_info_p()), fps_p2, rest_p3, ty_p4, mode_p5, fresh_p6)
        } else {
            match crate::prelude::get(&lx_p0.g_p.ctors_p, &qk_p7) {
                Some(c_pa) => {
                    let owner_pb = crate::prelude::or(&crate::prelude::get(&lx_p0.g_p.types_p, &c_pa.owner_p), &crate::check::env::names::dummy_ty_info_p());
                    let ty_path_pc = crate::lower::path_in_f(lx_p0, &owner_pb.home_p, &crate::lower::camel_f(&crate::check::types::bare_name_f(&c_pa.owner_p)));
                    match &owner_pb.body_p {
                        crate::check::env::TyBody::BChoice(cases_pd) if (&crate::prelude::len(fps_p2) == &Nat::from(0u32)) => rest_case_pat_f(&c_pa, cases_pd, &ty_path_pc),
                        _ => fields_pat_f(lx_p0, &c_pa, fps_p2, rest_p3, ty_p4, mode_p5, fresh_p6, &ty_path_pc),
                        _ => unreachable!("no arm matched"),
                    }
                },
                None => match crate::prelude::get(&lx_p0.g_p.tags_p, &qk_p7) {
                    Some(tg_pe) => tag_pat_f(lx_p0, &tg_pe, fps_p2, rest_p3, ty_p4, mode_p5, fresh_p6),
                    None => PatOut { pa_p: crate::lower::model::Pa::PaWild, conds_p: Array::from(vec![crate::lower::model::Cc::CcIf(crate::lower::expr::refusal_f(&Text::from(format!("a pattern of {}", &qk_p7))))]), binds_p: Array::new() },
                },
            }
        }
    }
}

/// The step machine of `RecordPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RecordPat: unbounded fn Lx, SName, [FieldPat], Bool, Ty, Holding, Text -> PatOut
/// ```
pub struct RecordPat {
    pub lx_p0: crate::lower::Lx,
    pub n_p1: crate::syntax::SName,
    pub fps_p2: Array<crate::syntax::FieldPat>,
    pub rest_p3: bool,
    pub ty_p4: crate::check::types::Ty,
    pub mode_p5: crate::lower::types::Holding,
    pub fresh_p6: Text,
}

impl prism_rtl::Job<PatOut> for RecordPat {
    fn cycle(&self) -> prism_rtl::Turn<PatOut> {
        let lx_p0 = &self.lx_p0;
        let n_p1 = &self.n_p1;
        let fps_p2 = &self.fps_p2;
        let rest_p3 = &self.rest_p3;
        let ty_p4 = &self.ty_p4;
        let mode_p5 = &self.mode_p5;
        let fresh_p6 = &self.fresh_p6;
        let (qk_o8, why_p9) = crate::check::env::names::resolve_value_f(&lx_p0.g_p, &lx_p0.home_p, n_p1);
        let qk_p7 = crate::prelude::or(&qk_o8, &Text::lit(""));
        if &qk_p7 == &Text::lit("Prelude.Error") {
            prism_rtl::Turn::More(Rc::new(ErrorPat { lx_p0: lx_p0.clone(), fps_p1: fps_p2.clone(), ty_p2: ty_p4.clone(), mode_p3: mode_p5.clone(), fresh_p4: fresh_p6.clone() }))
        } else {
            if (&why_p9 == &Text::lit("tag")) && crate::check::env::has_key_f(&lx_p0.g_p.tags_p, &qk_p7) {
                prism_rtl::Turn::More(Rc::new(TagPat { lx_p0: lx_p0.clone(), tg_p1: crate::prelude::or(&crate::prelude::get(&lx_p0.g_p.tags_p, &qk_p7), &dummy_tag_info_p()), fps_p2: fps_p2.clone(), rest_p3: *rest_p3, ty_p4: ty_p4.clone(), mode_p5: mode_p5.clone(), fresh_p6: fresh_p6.clone() }))
            } else {
                match crate::prelude::get(&lx_p0.g_p.ctors_p, &qk_p7) {
                    Some(c_pa) => {
                        let owner_pb = crate::prelude::or(&crate::prelude::get(&lx_p0.g_p.types_p, &c_pa.owner_p), &crate::check::env::names::dummy_ty_info_p());
                        let ty_path_pc = crate::lower::path_in_f(lx_p0, &owner_pb.home_p, &crate::lower::camel_f(&crate::check::types::bare_name_f(&c_pa.owner_p)));
                        match &owner_pb.body_p {
                            crate::check::env::TyBody::BChoice(cases_pd) if (&crate::prelude::len(fps_p2) == &Nat::from(0u32)) => prism_rtl::Turn::Finished(rest_case_pat_f(&c_pa, cases_pd, &ty_path_pc)),
                            _ => prism_rtl::Turn::More(Rc::new(FieldsPat { lx_p0: lx_p0.clone(), c_p1: c_pa.clone(), fps_p2: fps_p2.clone(), rest_p3: *rest_p3, ty_p4: ty_p4.clone(), mode_p5: mode_p5.clone(), fresh_p6: fresh_p6.clone(), ty_path_p7: ty_path_pc.clone() })),
                            _ => unreachable!("no arm matched"),
                        }
                    },
                    None => match crate::prelude::get(&lx_p0.g_p.tags_p, &qk_p7) {
                        Some(tg_pe) => prism_rtl::Turn::More(Rc::new(TagPat { lx_p0: lx_p0.clone(), tg_p1: tg_pe.clone(), fps_p2: fps_p2.clone(), rest_p3: *rest_p3, ty_p4: ty_p4.clone(), mode_p5: mode_p5.clone(), fresh_p6: fresh_p6.clone() })),
                        None => prism_rtl::Turn::Finished(PatOut { pa_p: crate::lower::model::Pa::PaWild, conds_p: Array::from(vec![crate::lower::model::Cc::CcIf(crate::lower::expr::refusal_f(&Text::from(format!("a pattern of {}", &qk_p7))))]), binds_p: Array::new() }),
                    },
                }
            }
        }
    }
}

/// `Start RecordPat, x`: what the function value is when passed to `@Run`.
pub fn start_record_pat_f(lx_p0: crate::lower::Lx, n_p1: crate::syntax::SName, fps_p2: Array<crate::syntax::FieldPat>, rest_p3: bool, ty_p4: crate::check::types::Ty, mode_p5: crate::lower::types::Holding, fresh_p6: Text) -> Rc<dyn prism_rtl::Job<PatOut>> {
    Rc::new(RecordPat { lx_p0, n_p1, fps_p2, rest_p3, ty_p4, mode_p5, fresh_p6 })
}

/// ```prism
/// RestCasePat: fn CtorInfo, [((Text, [Ty]))], Text -> PatOut
/// ```
pub fn rest_case_pat_f(c_p0: &crate::check::env::CtorInfo, cases_p1: &Array<(Text, Array<crate::check::types::Ty>)>, ty_path_p2: &Text) -> PatOut {
    let is_newtype_p3 = (&crate::prelude::len(cases_p1) == &Nat::from(1u32)) && (&crate::check::types::bare_name_f(&c_p0.name_p) == &crate::check::types::bare_name_f(&c_p0.owner_p));
    let path_p4 = if is_newtype_p3 {
        ty_path_p2.clone()
    } else {
        Text::from(format!("{}::{}", ty_path_p2, &crate::lower::camel_f(&crate::check::types::bare_name_f(&c_p0.name_p))))
    };
    if &crate::prelude::len(&c_p0.args_p) == &Nat::from(0u32) {
        PatOut { pa_p: crate::lower::model::Pa::PaUnit(path_p4.clone()), conds_p: Array::new(), binds_p: Array::new() }
    } else {
        PatOut { pa_p: crate::lower::model::Pa::PaCtor(path_p4.clone(), crate::prelude::each(&c_p0.args_p, &(|_: &crate::check::types::Ty| crate::lower::model::Pa::PaWild))), conds_p: Array::new(), binds_p: Array::new() }
    }
}

/// ```prism
/// FieldsPat: unbounded fn Lx, CtorInfo, [FieldPat], Bool, Ty, Holding, Text, Text -> PatOut
/// ```
pub fn fields_pat_f(lx_p0: &crate::lower::Lx, c_p1: &crate::check::env::CtorInfo, fps_p2: &Array<crate::syntax::FieldPat>, rest_p3: &bool, ty_p4: &crate::check::types::Ty, mode_p5: &crate::lower::types::Holding, fresh_p6: &Text, ty_path_p7: &Text) -> PatOut {
    let args_p8 = match crate::lower::types::peel_f(ty_p4) {
        crate::check::types::Ty::TyCon(_, xs_pc) => xs_pc,
        _ => Array::new(),
    };
    let subs_p9 = crate::prelude::run_to_end(crate::prelude::each_job(crate::check::errors::range0_f(&crate::prelude::len(fps_p2)), {
        let fps_p2x = fps_p2.clone();
        let c_p1x = c_p1.clone();
        let lx_p0x = lx_p0.clone();
        let args_p8x = args_p8.clone();
        let mode_p5x = mode_p5.clone();
        let fresh_p6x = fresh_p6.clone();
        Rc::new(move |p0: Nat| {
            let fps_p2xy = fps_p2x.clone();
            let c_p1xy = c_p1x.clone();
            let lx_p0xy = lx_p0x.clone();
            let args_p8xy = args_p8x.clone();
            let mode_p5xy = mode_p5x.clone();
            let fresh_p6xy = fresh_p6x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let i_pd = p0;
                {
                    let fp_pe = crate::prelude::or(&crate::prelude::index(&fps_p2xy, &i_pd), &dummy_field_pat_p());
                    let fname_pf = match &fp_pe.name_o {
                        Some(id_ph) => id_ph.name_p.clone(),
                        None => crate::prelude::or(&crate::prelude::index(&c_p1xy.fields_p, &i_pd), &Text::lit("")),
                    };
                    let fix_pg = crate::prelude::fold(&crate::check::errors::range0_f(&crate::prelude::len(&c_p1xy.fields_p)), &i_pd, &(|found_pi: &Nat, j_pj: &Nat| if &crate::prelude::or(&crate::prelude::index(&c_p1xy.fields_p, j_pj), &Text::lit("")) == &fname_pf {
                        j_pj.clone()
                    } else {
                        found_pi.clone()
                    }));
                    crate::prelude::call_then(crate::lower::start_field_spell_f(crate::lower::owner_of_f(&c_p1xy.owner_p), fname_pf.clone(), crate::prelude::or(&crate::prelude::index(&c_p1xy.args_p, &fix_pg), &crate::check::types::Ty::TyErr)), move |field_spell_f_10672: Text| crate::prelude::call_then(crate::lower::expr::start_instantiated_f(crate::prelude::or(&crate::prelude::index(&c_p1xy.args_p, &fix_pg), &crate::check::types::Ty::TyErr), c_p1xy.params_p.clone(), args_p8xy.clone()), move |instantiated_f_10768: crate::check::types::Ty| crate::prelude::call_then(start_sub_pat_f(lx_p0xy.clone(), c_p1xy.clone(), fix_pg.clone(), fp_pe.pattern_p.clone(), instantiated_f_10768, mode_p5xy.clone(), Text::from(format!("{}_{}", &fresh_p6xy, &i_pd))), move |sub_pat_f_10736: PatOut| prism_rtl::Turn::Finished((field_spell_f_10672, sub_pat_f_10736)))))
                }
            }))
        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<(Text, PatOut)>>>
    }));
    let conds_pa = crate::prelude::fold(&subs_p9, &Array::new(), &(|acc_pk: &Array<crate::lower::model::Cc>, (_, o_pl): &(Text, PatOut)| crate::prelude::append(acc_pk, &o_pl.conds_p)));
    let binds_pb = crate::prelude::fold(&subs_p9, &Array::new(), &(|acc_pm: &Array<(Text, crate::lower::types::Bn)>, (_, o_pn): &(Text, PatOut)| crate::prelude::append(acc_pm, &o_pn.binds_p)));
    PatOut { pa_p: crate::lower::model::Pa::PaRecord(ty_path_p7.clone(), crate::prelude::each(&subs_p9, &(|(f_po, o_pp): &(Text, PatOut)| (f_po.clone(), o_pp.pa_p.clone()))), *rest_p3 || (&crate::prelude::len(&subs_p9) < &crate::prelude::len(&c_p1.fields_p))), conds_p: conds_pa.clone(), binds_p: binds_pb.clone() }
}

/// The step machine of `FieldsPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FieldsPat: unbounded fn Lx, CtorInfo, [FieldPat], Bool, Ty, Holding, Text, Text -> PatOut
/// ```
pub struct FieldsPat {
    pub lx_p0: crate::lower::Lx,
    pub c_p1: crate::check::env::CtorInfo,
    pub fps_p2: Array<crate::syntax::FieldPat>,
    pub rest_p3: bool,
    pub ty_p4: crate::check::types::Ty,
    pub mode_p5: crate::lower::types::Holding,
    pub fresh_p6: Text,
    pub ty_path_p7: Text,
}

impl prism_rtl::Job<PatOut> for FieldsPat {
    fn cycle(&self) -> prism_rtl::Turn<PatOut> {
        let lx_p0 = &self.lx_p0;
        let c_p1 = &self.c_p1;
        let fps_p2 = &self.fps_p2;
        let rest_p3 = &self.rest_p3;
        let ty_p4 = &self.ty_p4;
        let mode_p5 = &self.mode_p5;
        let fresh_p6 = &self.fresh_p6;
        let ty_path_p7 = &self.ty_path_p7;
        let args_p8 = match crate::lower::types::peel_f(ty_p4) {
            crate::check::types::Ty::TyCon(_, xs_pc) => xs_pc,
            _ => Array::new(),
        };
        let c_p1x = c_p1.clone();
        let fps_p2x = fps_p2.clone();
        let fresh_p6x = fresh_p6.clone();
        let lx_p0x = lx_p0.clone();
        let mode_p5x = mode_p5.clone();
        let rest_p3x = *rest_p3;
        let ty_path_p7x = ty_path_p7.clone();
        crate::prelude::call_value(crate::prelude::each_job(crate::check::errors::range0_f(&crate::prelude::len(&fps_p2x)), {
            let fps_p2xx = fps_p2x.clone();
            let c_p1xx = c_p1x.clone();
            let lx_p0xx = lx_p0x.clone();
            let args_p8x = args_p8.clone();
            let mode_p5xx = mode_p5x.clone();
            let fresh_p6xx = fresh_p6x.clone();
            Rc::new(move |p0: Nat| {
                let fps_p2xxy = fps_p2xx.clone();
                let c_p1xxy = c_p1xx.clone();
                let lx_p0xxy = lx_p0xx.clone();
                let args_p8xy = args_p8x.clone();
                let mode_p5xxy = mode_p5xx.clone();
                let fresh_p6xxy = fresh_p6xx.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let i_pd = p0;
                    {
                        let fp_pe = crate::prelude::or(&crate::prelude::index(&fps_p2xxy, &i_pd), &dummy_field_pat_p());
                        let fname_pf = match &fp_pe.name_o {
                            Some(id_ph) => id_ph.name_p.clone(),
                            None => crate::prelude::or(&crate::prelude::index(&c_p1xxy.fields_p, &i_pd), &Text::lit("")),
                        };
                        let fix_pg = crate::prelude::fold(&crate::check::errors::range0_f(&crate::prelude::len(&c_p1xxy.fields_p)), &i_pd, &(|found_pi: &Nat, j_pj: &Nat| if &crate::prelude::or(&crate::prelude::index(&c_p1xxy.fields_p, j_pj), &Text::lit("")) == &fname_pf {
                            j_pj.clone()
                        } else {
                            found_pi.clone()
                        }));
                        crate::prelude::call_then(crate::lower::start_field_spell_f(crate::lower::owner_of_f(&c_p1xxy.owner_p), fname_pf.clone(), crate::prelude::or(&crate::prelude::index(&c_p1xxy.args_p, &fix_pg), &crate::check::types::Ty::TyErr)), move |field_spell_f_10672: Text| crate::prelude::call_then(crate::lower::expr::start_instantiated_f(crate::prelude::or(&crate::prelude::index(&c_p1xxy.args_p, &fix_pg), &crate::check::types::Ty::TyErr), c_p1xxy.params_p.clone(), args_p8xy.clone()), move |instantiated_f_10768: crate::check::types::Ty| crate::prelude::call_then(start_sub_pat_f(lx_p0xxy.clone(), c_p1xxy.clone(), fix_pg.clone(), fp_pe.pattern_p.clone(), instantiated_f_10768, mode_p5xxy.clone(), Text::from(format!("{}_{}", &fresh_p6xxy, &i_pd))), move |sub_pat_f_10736: PatOut| prism_rtl::Turn::Finished((field_spell_f_10672, sub_pat_f_10736)))))
                    }
                }))
            }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<(Text, PatOut)>>>
        }), move |each_10332: Array<(Text, PatOut)>| {
            let subs_p9 = each_10332;
            let conds_pa = crate::prelude::fold(&subs_p9, &Array::new(), &(|acc_pk: &Array<crate::lower::model::Cc>, (_, o_pl): &(Text, PatOut)| crate::prelude::append(acc_pk, &o_pl.conds_p)));
            let binds_pb = crate::prelude::fold(&subs_p9, &Array::new(), &(|acc_pm: &Array<(Text, crate::lower::types::Bn)>, (_, o_pn): &(Text, PatOut)| crate::prelude::append(acc_pm, &o_pn.binds_p)));
            prism_rtl::Turn::Finished(PatOut { pa_p: crate::lower::model::Pa::PaRecord(ty_path_p7x.clone(), crate::prelude::each(&subs_p9, &(|(f_po, o_pp): &(Text, PatOut)| (f_po.clone(), o_pp.pa_p.clone()))), rest_p3x || (&crate::prelude::len(&subs_p9) < &crate::prelude::len(&c_p1x.fields_p))), conds_p: conds_pa.clone(), binds_p: binds_pb.clone() })
        })
    }
}

/// `Start FieldsPat, x`: what the function value is when passed to `@Run`.
pub fn start_fields_pat_f(lx_p0: crate::lower::Lx, c_p1: crate::check::env::CtorInfo, fps_p2: Array<crate::syntax::FieldPat>, rest_p3: bool, ty_p4: crate::check::types::Ty, mode_p5: crate::lower::types::Holding, fresh_p6: Text, ty_path_p7: Text) -> Rc<dyn prism_rtl::Job<PatOut>> {
    Rc::new(FieldsPat { lx_p0, c_p1, fps_p2, rest_p3, ty_p4, mode_p5, fresh_p6, ty_path_p7 })
}

/// ```prism
/// let dummyFieldPat
/// ```
pub fn dummy_field_pat_p() -> crate::syntax::FieldPat {
    crate::syntax::FieldPat { name_o: None, pattern_p: dummy_pat_p(), span_p: crate::syntax::Range { start_p: Nat::from(0u32), end_p: Nat::from(0u32) } }
}

/// ```prism
/// let dummyTagInfo
/// ```
pub fn dummy_tag_info_p() -> crate::check::env::TagInfo {
    crate::check::env::TagInfo { name_p: Text::lit(""), family_p: Text::lit(""), kind_p: Text::lit(""), out_p: crate::check::types::Ty::TyErr, qs_p: Array::new(), rqs_p: Array::new(), bounds_p: Array::new(), fields_p: Array::new(), home_p: Text::lit(""), file_p: Nat::from(0u32), span_p: crate::syntax::Range { start_p: Nat::from(0u32), end_p: Nat::from(0u32) } }
}

/// ```prism
/// IsLive: fn Ty -> Bool
/// ```
pub fn is_live_f(t_p0: &crate::check::types::Ty) -> bool {
    match crate::lower::types::peel_f(t_p0) {
        crate::check::types::Ty::TyElem(_, _) => true,
        _ => false,
    }
}

/// ```prism
/// TagFieldName: fn FieldPat, [Text], Nat -> Text
/// ```
pub fn tag_field_name_f(fp_p0: &crate::syntax::FieldPat, names_p1: &Array<Text>, i_p2: &Nat) -> Text {
    match &fp_p0.name_o {
        Some(id_p3) => id_p3.name_p.clone(),
        None => match &*fp_p0.pattern_p.kind_p {
            crate::syntax::PatternKind::PName(n_p4) => if crate::check::types::has_text_f(names_p1, &crate::check::env::sname_key_f(n_p4)) {
                crate::check::env::sname_key_f(n_p4)
            } else {
                crate::prelude::or(&crate::prelude::index(names_p1, i_p2), &Text::lit(""))
            },
            _ => crate::prelude::or(&crate::prelude::index(names_p1, i_p2), &Text::lit("")),
        },
    }
}

/// ```prism
/// TagPat: unbounded fn Lx, TagInfo, [FieldPat], Bool, Ty, Holding, Text -> PatOut
/// ```
pub fn tag_pat_f(lx_p0: &crate::lower::Lx, tg_p1: &crate::check::env::TagInfo, fps_p2: &Array<crate::syntax::FieldPat>, rest_p3: &bool, ty_p4: &crate::check::types::Ty, mode_p5: &crate::lower::types::Holding, fresh_p6: &Text) -> PatOut {
    let (variant_pg, struct_path_ph) = crate::lower::program::tag_paths_f(lx_p0, tg_p1);
    let live_p7 = is_live_f(ty_p4);
    let names_p8 = crate::prelude::each(&tg_p1.fields_p, &(|(f_pi, _): &(Text, crate::check::types::Ty)| f_pi.clone()));
    let sub_mode_p9 = if live_p7 { crate::lower::types::Holding::ByRef } else { mode_p5.clone() };
    let parts_pa = crate::prelude::run_to_end(crate::prelude::each_job(crate::check::errors::range0_f(&crate::prelude::len(fps_p2)), {
        let fps_p2x = fps_p2.clone();
        let names_p8x = names_p8.clone();
        let tg_p1x = tg_p1.clone();
        let live_p7x = live_p7;
        let lx_p0x = lx_p0.clone();
        let variant_pgx = variant_pg.clone();
        let fresh_p6x = fresh_p6.clone();
        let sub_mode_p9x = sub_mode_p9.clone();
        Rc::new(move |p0: Nat| {
            let fps_p2xy = fps_p2x.clone();
            let names_p8xy = names_p8x.clone();
            let tg_p1xy = tg_p1x.clone();
            let live_p7xy = live_p7x;
            let lx_p0xy = lx_p0x.clone();
            let variant_pgxy = variant_pgx.clone();
            let fresh_p6xy = fresh_p6x.clone();
            let sub_mode_p9xy = sub_mode_p9x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let i_pj = p0;
                {
                    let fp_pk = crate::prelude::or(&crate::prelude::index(&fps_p2xy, &i_pj), &dummy_field_pat_p());
                    let fname_pl = tag_field_name_f(&fp_pk, &names_p8xy, &i_pj);
                    let ft_pm = crate::prelude::fold(&tg_p1xy.fields_p, &crate::check::types::Ty::TyErr, &(|found_pn: &crate::check::types::Ty, (f_po, t_pp): &(Text, crate::check::types::Ty)| if f_po == &fname_pl { t_pp.clone() } else { found_pn.clone() }));
                    match crate::lower::types::layer_of_f(&ft_pm) {
                        crate::lower::types::Layer::LyEv => prism_rtl::Turn::Finished((None, PatOut { pa_p: crate::lower::model::Pa::PaWild, conds_p: Array::from(vec![crate::lower::model::Cc::CcIf(crate::lower::expr::refusal_f(&Text::from(format!("an event field in an element pattern ({}.{})", &tg_p1xy.name_p, &fname_pl))))]), binds_p: Array::new() })),
                        crate::lower::types::Layer::LyDyn if live_p7xy => crate::prelude::call_then(crate::lower::start_field_spell_f(tg_p1xy.home_p.clone(), fname_pl.clone(), ft_pm.clone()), move |field_spell_f_13189: Text| crate::prelude::call_then(start_live_field_pat_f(lx_p0xy.clone(), fp_pk.pattern_p.clone(), variant_pgxy.clone(), fname_pl.clone(), field_spell_f_13189, ft_pm.clone(), fresh_p6xy.clone()), move |live_field_pat_f_13143: PatOut| prism_rtl::Turn::Finished((None, live_field_pat_f_13143)))),
                        _ => crate::prelude::call_then(start_rust_pat_f(lx_p0xy.clone(), fp_pk.pattern_p.clone(), crate::lower::types::peel_f(&ft_pm), sub_mode_p9xy.clone(), Text::from(format!("{}_{}", &fresh_p6xy, &i_pj))), move |rust_pat_f_13281: PatOut| {
                            let o_pq = rust_pat_f_13281;
                            prism_rtl::Turn::Finished((Some(crate::lower::field_spell_f(&tg_p1xy.home_p, &fname_pl, &ft_pm)), o_pq.clone()))
                        }),
                        _ => unreachable!("no arm matched"),
                    }
                }
            }))
        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<(Option<Text>, PatOut)>>>
    }));
    let field_pas_pb = crate::prelude::fold(&parts_pa, &Array::new(), &(|acc_pr: &Array<(Text, crate::lower::model::Pa)>, (f_os, o_pt): &(Option<Text>, PatOut)| match f_os {
        Some(f_pu) => crate::prelude::push(acc_pr, &(f_pu.clone(), o_pt.pa_p.clone())),
        None => acc_pr.clone(),
    }));
    let conds_pc = crate::prelude::fold(&parts_pa, &Array::new(), &(|acc_pv: &Array<crate::lower::model::Cc>, (_, o_p10): &(Option<Text>, PatOut)| crate::prelude::append(acc_pv, &o_p10.conds_p)));
    let binds_pd = crate::prelude::fold(&parts_pa, &Array::new(), &(|acc_p11: &Array<(Text, crate::lower::types::Bn)>, (_, o_p12): &(Option<Text>, PatOut)| crate::prelude::append(acc_p11, &o_p12.binds_p)));
    let level_pe = crate::lower::model::Pa::PaCtor(variant_pg.clone(), Array::from(vec![crate::lower::model::Pa::PaRecord(struct_path_ph.clone(), field_pas_pb.clone(), true)]));
    let tagged_pf = crate::prelude::push(&binds_pd, &(Text::lit("#tag"), crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XPath(crate::lower::node_::elements::answer_variant_f(tg_p1)), crate::lower::types::Holding::Owned, crate::lower::model::OutTy::OutUnit)));
    if live_p7 {
        PatOut { pa_p: crate::lower::model::Pa::PaBind(fresh_p6.clone()), conds_p: crate::prelude::append(&Array::from(vec![crate::lower::model::Cc::CcLet(level_pe.clone(), crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XVar(fresh_p6.clone())), Text::lit("identity")))))]), &conds_pc), binds_p: tagged_pf.clone() }
    } else {
        PatOut { pa_p: level_pe.clone(), conds_p: conds_pc.clone(), binds_p: binds_pd.clone() }
    }
}

/// The step machine of `TagPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TagPat: unbounded fn Lx, TagInfo, [FieldPat], Bool, Ty, Holding, Text -> PatOut
/// ```
pub struct TagPat {
    pub lx_p0: crate::lower::Lx,
    pub tg_p1: crate::check::env::TagInfo,
    pub fps_p2: Array<crate::syntax::FieldPat>,
    pub rest_p3: bool,
    pub ty_p4: crate::check::types::Ty,
    pub mode_p5: crate::lower::types::Holding,
    pub fresh_p6: Text,
}

impl prism_rtl::Job<PatOut> for TagPat {
    fn cycle(&self) -> prism_rtl::Turn<PatOut> {
        let lx_p0 = &self.lx_p0;
        let tg_p1 = &self.tg_p1;
        let fps_p2 = &self.fps_p2;
        let rest_p3 = &self.rest_p3;
        let ty_p4 = &self.ty_p4;
        let mode_p5 = &self.mode_p5;
        let fresh_p6 = &self.fresh_p6;
        let (variant_pg, struct_path_ph) = crate::lower::program::tag_paths_f(lx_p0, tg_p1);
        let live_p7 = is_live_f(ty_p4);
        let names_p8 = crate::prelude::each(&tg_p1.fields_p, &(|(f_pi, _): &(Text, crate::check::types::Ty)| f_pi.clone()));
        let sub_mode_p9 = if live_p7 { crate::lower::types::Holding::ByRef } else { mode_p5.clone() };
        let fps_p2x = fps_p2.clone();
        let fresh_p6x = fresh_p6.clone();
        let lx_p0x = lx_p0.clone();
        let tg_p1x = tg_p1.clone();
        crate::prelude::call_value(crate::prelude::each_job(crate::check::errors::range0_f(&crate::prelude::len(&fps_p2x)), {
            let fps_p2xx = fps_p2x.clone();
            let names_p8x = names_p8.clone();
            let tg_p1xx = tg_p1x.clone();
            let live_p7x = live_p7;
            let lx_p0xx = lx_p0x.clone();
            let variant_pgx = variant_pg.clone();
            let fresh_p6xx = fresh_p6x.clone();
            let sub_mode_p9x = sub_mode_p9.clone();
            Rc::new(move |p0: Nat| {
                let fps_p2xxy = fps_p2xx.clone();
                let names_p8xy = names_p8x.clone();
                let tg_p1xxy = tg_p1xx.clone();
                let live_p7xy = live_p7x;
                let lx_p0xxy = lx_p0xx.clone();
                let variant_pgxy = variant_pgx.clone();
                let fresh_p6xxy = fresh_p6xx.clone();
                let sub_mode_p9xy = sub_mode_p9x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let i_pj = p0;
                    {
                        let fp_pk = crate::prelude::or(&crate::prelude::index(&fps_p2xxy, &i_pj), &dummy_field_pat_p());
                        let fname_pl = tag_field_name_f(&fp_pk, &names_p8xy, &i_pj);
                        let ft_pm = crate::prelude::fold(&tg_p1xxy.fields_p, &crate::check::types::Ty::TyErr, &(|found_pn: &crate::check::types::Ty, (f_po, t_pp): &(Text, crate::check::types::Ty)| if f_po == &fname_pl { t_pp.clone() } else { found_pn.clone() }));
                        match crate::lower::types::layer_of_f(&ft_pm) {
                            crate::lower::types::Layer::LyEv => prism_rtl::Turn::Finished((None, PatOut { pa_p: crate::lower::model::Pa::PaWild, conds_p: Array::from(vec![crate::lower::model::Cc::CcIf(crate::lower::expr::refusal_f(&Text::from(format!("an event field in an element pattern ({}.{})", &tg_p1xxy.name_p, &fname_pl))))]), binds_p: Array::new() })),
                            crate::lower::types::Layer::LyDyn if live_p7xy => crate::prelude::call_then(crate::lower::start_field_spell_f(tg_p1xxy.home_p.clone(), fname_pl.clone(), ft_pm.clone()), move |field_spell_f_13189: Text| crate::prelude::call_then(start_live_field_pat_f(lx_p0xxy.clone(), fp_pk.pattern_p.clone(), variant_pgxy.clone(), fname_pl.clone(), field_spell_f_13189, ft_pm.clone(), fresh_p6xxy.clone()), move |live_field_pat_f_13143: PatOut| prism_rtl::Turn::Finished((None, live_field_pat_f_13143)))),
                            _ => crate::prelude::call_then(start_rust_pat_f(lx_p0xxy.clone(), fp_pk.pattern_p.clone(), crate::lower::types::peel_f(&ft_pm), sub_mode_p9xy.clone(), Text::from(format!("{}_{}", &fresh_p6xxy, &i_pj))), move |rust_pat_f_13281: PatOut| {
                                let o_pq = rust_pat_f_13281;
                                prism_rtl::Turn::Finished((Some(crate::lower::field_spell_f(&tg_p1xxy.home_p, &fname_pl, &ft_pm)), o_pq.clone()))
                            }),
                            _ => unreachable!("no arm matched"),
                        }
                    }
                }))
            }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<(Option<Text>, PatOut)>>>
        }), move |each_12732: Array<(Option<Text>, PatOut)>| {
            let parts_pa = each_12732;
            let field_pas_pb = crate::prelude::fold(&parts_pa, &Array::new(), &(|acc_pr: &Array<(Text, crate::lower::model::Pa)>, (f_os, o_pt): &(Option<Text>, PatOut)| match f_os {
                Some(f_pu) => crate::prelude::push(acc_pr, &(f_pu.clone(), o_pt.pa_p.clone())),
                None => acc_pr.clone(),
            }));
            let conds_pc = crate::prelude::fold(&parts_pa, &Array::new(), &(|acc_pv: &Array<crate::lower::model::Cc>, (_, o_p10): &(Option<Text>, PatOut)| crate::prelude::append(acc_pv, &o_p10.conds_p)));
            let binds_pd = crate::prelude::fold(&parts_pa, &Array::new(), &(|acc_p11: &Array<(Text, crate::lower::types::Bn)>, (_, o_p12): &(Option<Text>, PatOut)| crate::prelude::append(acc_p11, &o_p12.binds_p)));
            let level_pe = crate::lower::model::Pa::PaCtor(variant_pg.clone(), Array::from(vec![crate::lower::model::Pa::PaRecord(struct_path_ph.clone(), field_pas_pb.clone(), true)]));
            let tagged_pf = crate::prelude::push(&binds_pd, &(Text::lit("#tag"), crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XPath(crate::lower::node_::elements::answer_variant_f(&tg_p1x)), crate::lower::types::Holding::Owned, crate::lower::model::OutTy::OutUnit)));
            if live_p7 {
                prism_rtl::Turn::Finished(PatOut { pa_p: crate::lower::model::Pa::PaBind(fresh_p6x.clone()), conds_p: crate::prelude::append(&Array::from(vec![crate::lower::model::Cc::CcLet(level_pe.clone(), crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XVar(fresh_p6x.clone())), Text::lit("identity")))))]), &conds_pc), binds_p: tagged_pf.clone() })
            } else {
                prism_rtl::Turn::Finished(PatOut { pa_p: level_pe.clone(), conds_p: conds_pc.clone(), binds_p: binds_pd.clone() })
            }
        })
    }
}

/// `Start TagPat, x`: what the function value is when passed to `@Run`.
pub fn start_tag_pat_f(lx_p0: crate::lower::Lx, tg_p1: crate::check::env::TagInfo, fps_p2: Array<crate::syntax::FieldPat>, rest_p3: bool, ty_p4: crate::check::types::Ty, mode_p5: crate::lower::types::Holding, fresh_p6: Text) -> Rc<dyn prism_rtl::Job<PatOut>> {
    Rc::new(TagPat { lx_p0, tg_p1, fps_p2, rest_p3, ty_p4, mode_p5, fresh_p6 })
}

/// ```prism
/// LiveFieldPat: unbounded fn Lx, Pattern, Text, Text, Text, Ty, Text -> PatOut
/// ```
pub fn live_field_pat_f(lx_p0: &crate::lower::Lx, p_p1: &crate::syntax::Pattern_, variant_p2: &Text, fname_p3: &Text, rs_field_p4: &Text, ft_p5: &crate::check::types::Ty, fresh_p6: &Text) -> PatOut {
    match &*p_p1.kind_p {
        crate::syntax::PatternKind::PIgnore => pat_only_f(&crate::lower::model::Pa::PaWild),
        crate::syntax::PatternKind::PName(n_p7) => {
            let rs_p8 = if lx_p0.in_node_p {
                live_projection_f(fresh_p6, variant_p2, rs_field_p4, &crate::lower::types::out_ty_of_f(lx_p0, &crate::lower::types::peel_f(ft_p5)))
            } else {
                crate::lower::expr::refusal_f(&Text::from(format!("a live element\'s `$` field ({}) in a plain function, which has no read point (gap LE)", fname_p3)))
            };
            PatOut { pa_p: crate::lower::model::Pa::PaWild, conds_p: Array::new(), binds_p: Array::from(vec![(crate::check::env::sname_key_f(n_p7), crate::lower::types::Bn::BnLocal(rs_p8.clone(), crate::lower::types::Holding::Owned, crate::lower::model::OutTy::OutDyn(Rc::new(crate::lower::types::out_ty_of_f(lx_p0, &crate::lower::types::peel_f(ft_p5))))))]) }
        },
        crate::syntax::PatternKind::PGroup(q_p9) => live_field_pat_f(lx_p0, &**q_p9, variant_p2, fname_p3, rs_field_p4, ft_p5, fresh_p6),
        _ => PatOut { pa_p: crate::lower::model::Pa::PaWild, conds_p: Array::from(vec![crate::lower::model::Cc::CcIf(crate::lower::expr::refusal_f(&Text::from(format!("a pattern inside a live element\'s `$` field ({})", fname_p3))))]), binds_p: Array::new() },
    }
}

/// The step machine of `LiveFieldPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LiveFieldPat: unbounded fn Lx, Pattern, Text, Text, Text, Ty, Text -> PatOut
/// ```
pub struct LiveFieldPat {
    pub lx_p0: crate::lower::Lx,
    pub p_p1: crate::syntax::Pattern_,
    pub variant_p2: Text,
    pub fname_p3: Text,
    pub rs_field_p4: Text,
    pub ft_p5: crate::check::types::Ty,
    pub fresh_p6: Text,
}

impl prism_rtl::Job<PatOut> for LiveFieldPat {
    fn cycle(&self) -> prism_rtl::Turn<PatOut> {
        let lx_p0 = &self.lx_p0;
        let p_p1 = &self.p_p1;
        let variant_p2 = &self.variant_p2;
        let fname_p3 = &self.fname_p3;
        let rs_field_p4 = &self.rs_field_p4;
        let ft_p5 = &self.ft_p5;
        let fresh_p6 = &self.fresh_p6;
        match &*p_p1.kind_p {
            crate::syntax::PatternKind::PIgnore => prism_rtl::Turn::Finished(pat_only_f(&crate::lower::model::Pa::PaWild)),
            crate::syntax::PatternKind::PName(n_p7) => {
                let rs_p8 = if lx_p0.in_node_p {
                    live_projection_f(fresh_p6, variant_p2, rs_field_p4, &crate::lower::types::out_ty_of_f(lx_p0, &crate::lower::types::peel_f(ft_p5)))
                } else {
                    crate::lower::expr::refusal_f(&Text::from(format!("a live element\'s `$` field ({}) in a plain function, which has no read point (gap LE)", fname_p3)))
                };
                let ft_p5x = ft_p5.clone();
                let lx_p0x = lx_p0.clone();
                let n_p7x = n_p7.clone();
                crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0x.clone(), crate::lower::types::peel_f(&ft_p5x)), move |out_ty_of_f_14928: crate::lower::model::OutTy| prism_rtl::Turn::Finished(PatOut { pa_p: crate::lower::model::Pa::PaWild, conds_p: Array::new(), binds_p: Array::from(vec![(crate::check::env::sname_key_f(&n_p7x), crate::lower::types::Bn::BnLocal(rs_p8.clone(), crate::lower::types::Holding::Owned, crate::lower::model::OutTy::OutDyn(Rc::new(out_ty_of_f_14928))))]) }))
            },
            crate::syntax::PatternKind::PGroup(q_p9) => prism_rtl::Turn::More(Rc::new(LiveFieldPat { lx_p0: lx_p0.clone(), p_p1: (**q_p9).clone(), variant_p2: variant_p2.clone(), fname_p3: fname_p3.clone(), rs_field_p4: rs_field_p4.clone(), ft_p5: ft_p5.clone(), fresh_p6: fresh_p6.clone() })),
            _ => prism_rtl::Turn::Finished(PatOut { pa_p: crate::lower::model::Pa::PaWild, conds_p: Array::from(vec![crate::lower::model::Cc::CcIf(crate::lower::expr::refusal_f(&Text::from(format!("a pattern inside a live element\'s `$` field ({})", fname_p3))))]), binds_p: Array::new() }),
        }
    }
}

/// `Start LiveFieldPat, x`: what the function value is when passed to `@Run`.
pub fn start_live_field_pat_f(lx_p0: crate::lower::Lx, p_p1: crate::syntax::Pattern_, variant_p2: Text, fname_p3: Text, rs_field_p4: Text, ft_p5: crate::check::types::Ty, fresh_p6: Text) -> Rc<dyn prism_rtl::Job<PatOut>> {
    Rc::new(LiveFieldPat { lx_p0, p_p1, variant_p2, fname_p3, rs_field_p4, ft_p5, fresh_p6 })
}

/// ```prism
/// LiveProjection: fn Text, Text, Text, OutTy -> Ex
/// ```
pub fn live_projection_f(fresh_p0: &Text, variant_p1: &Text, fname_p2: &Text, ft_p3: &crate::lower::model::OutTy) -> crate::lower::model::Ex {
    let arm_p4 = crate::lower::model::XArm { pat_p: crate::lower::model::Pa::PaCtor(variant_p1.clone(), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("x"))])), conds_p: Array::new(), body_p: crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XVar(Text::lit("x"))), fname_p2.clone()))) };
    let other_p5 = crate::lower::model::XArm { pat_p: crate::lower::model::Pa::PaWild, conds_p: Array::new(), body_p: crate::lower::model::Ex::XUnreachable };
    crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XVar(fresh_p0.clone())), Text::lit("level"))), Text::lit("map"), Array::from(vec![crate::lower::model::Ex::XClosure(true, Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("l"))]), Rc::new(crate::lower::model::Ex::XMatch(Rc::new(crate::lower::model::Ex::XVar(Text::lit("l"))), Array::from(vec![arm_p4.clone(), other_p5.clone()]), false, ft_p3.clone())))]))
}

/// ```prism
/// FamilyPat: unbounded fn Lx, QualName, Ty, Text -> PatOut
/// ```
pub fn family_pat_f(lx_p0: &crate::lower::Lx, q_p1: &crate::syntax::QualName, ty_p2: &crate::check::types::Ty, fresh_p3: &Text) -> PatOut {
    let fam_p4 = crate::check::env::dotted_f(&crate::prelude::filter(&q_p1.path_p, &(|x_p8: &Text| x_p8 != &Text::lit("*"))));
    let kind_p5 = match crate::lower::types::peel_f(ty_p2) {
        crate::check::types::Ty::TyElem(_, _) => Text::lit("Element"),
        crate::check::types::Ty::TyElemAny(_) => Text::lit("Element"),
        crate::check::types::Ty::TyCon(k_p9, _) => k_p9,
        _ => Text::lit(""),
    };
    let tags_p6 = crate::prelude::filter(&crate::lower::program::kind_tags_f(lx_p0, &kind_p5, &crate::prelude::keys(&lx_p0.rs_mods_p)), &(|tg_pa: &crate::check::env::TagInfo| &tg_pa.family_p == &fam_p4));
    let place_p7 = if is_live_f(ty_p2) {
        crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XVar(fresh_p3.clone())), Text::lit("identity"))
    } else {
        crate::lower::model::Ex::XVar(fresh_p3.clone())
    };
    PatOut { pa_p: crate::lower::model::Pa::PaBind(fresh_p3.clone()), conds_p: Array::from(vec![crate::lower::model::Cc::CcIf(crate::lower::model::Ex::XIsCase(Rc::new(place_p7.clone()), crate::prelude::each(&tags_p6, &(|tg_pb: &crate::check::env::TagInfo| crate::lower::program::variant_of_f(lx_p0, tg_pb)))))]), binds_p: Array::new() }
}

/// The step machine of `FamilyPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FamilyPat: unbounded fn Lx, QualName, Ty, Text -> PatOut
/// ```
pub struct FamilyPat {
    pub lx_p0: crate::lower::Lx,
    pub q_p1: crate::syntax::QualName,
    pub ty_p2: crate::check::types::Ty,
    pub fresh_p3: Text,
}

impl prism_rtl::Job<PatOut> for FamilyPat {
    fn cycle(&self) -> prism_rtl::Turn<PatOut> {
        let lx_p0 = &self.lx_p0;
        let q_p1 = &self.q_p1;
        let ty_p2 = &self.ty_p2;
        let fresh_p3 = &self.fresh_p3;
        let fam_p4 = crate::check::env::dotted_f(&crate::prelude::filter(&q_p1.path_p, &(|x_p8: &Text| x_p8 != &Text::lit("*"))));
        let kind_p5 = match crate::lower::types::peel_f(ty_p2) {
            crate::check::types::Ty::TyElem(_, _) => Text::lit("Element"),
            crate::check::types::Ty::TyElemAny(_) => Text::lit("Element"),
            crate::check::types::Ty::TyCon(k_p9, _) => k_p9,
            _ => Text::lit(""),
        };
        let tags_p6 = crate::prelude::filter(&crate::lower::program::kind_tags_f(lx_p0, &kind_p5, &crate::prelude::keys(&lx_p0.rs_mods_p)), &(|tg_pa: &crate::check::env::TagInfo| &tg_pa.family_p == &fam_p4));
        let place_p7 = if is_live_f(ty_p2) {
            crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XVar(fresh_p3.clone())), Text::lit("identity"))
        } else {
            crate::lower::model::Ex::XVar(fresh_p3.clone())
        };
        prism_rtl::Turn::Finished(PatOut { pa_p: crate::lower::model::Pa::PaBind(fresh_p3.clone()), conds_p: Array::from(vec![crate::lower::model::Cc::CcIf(crate::lower::model::Ex::XIsCase(Rc::new(place_p7.clone()), crate::prelude::each(&tags_p6, &(|tg_pb: &crate::check::env::TagInfo| crate::lower::program::variant_of_f(lx_p0, tg_pb)))))]), binds_p: Array::new() })
    }
}

/// `Start FamilyPat, x`: what the function value is when passed to `@Run`.
pub fn start_family_pat_f(lx_p0: crate::lower::Lx, q_p1: crate::syntax::QualName, ty_p2: crate::check::types::Ty, fresh_p3: Text) -> Rc<dyn prism_rtl::Job<PatOut>> {
    Rc::new(FamilyPat { lx_p0, q_p1, ty_p2, fresh_p3 })
}

/// ```prism
/// ErrorPat: unbounded fn Lx, [FieldPat], Ty, Holding, Text -> PatOut
/// ```
pub fn error_pat_f(lx_p0: &crate::lower::Lx, fps_p1: &Array<crate::syntax::FieldPat>, ty_p2: &crate::check::types::Ty, mode_p3: &crate::lower::types::Holding, fresh_p4: &Text) -> PatOut {
    let e_p5 = crate::lower::types::local_place_f(&crate::lower::model::Ex::XVar(fresh_p4.clone()), mode_p3, &crate::lower::model::OutTy::OutError);
    let parts_p6 = crate::prelude::each(fps_p1, &(|fp_p8: &crate::syntax::FieldPat| {
        let fname_p9 = match &fp_p8.name_o {
            Some(id_pa) => id_pa.name_p.clone(),
            None => Text::lit(""),
        };
        match &fname_p9 {
            m16544_0 if (m16544_0 == &Text::lit("kind")) => match &*fp_p8.pattern_p.kind_p {
                crate::syntax::PatternKind::PName(k_pb) => {
                    let (kq_oc, _) = crate::check::env::names::resolve_value_f(&lx_p0.g_p, &lx_p0.home_p, k_pb);
                    match &kq_oc {
                        Some(kq_pd) => if crate::check::env::has_key_f(&lx_p0.g_p.tags_p, kq_pd) {
                            (Array::from(vec![crate::lower::model::Cc::CcIf(crate::lower::model::Ex::XBin(crate::lower::model::BinOp::OpEq, Rc::new(crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XDeref(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XVar(fresh_p4.clone())), Text::lit("kind_p"))))))), Rc::new(crate::lower::model::Ex::XStr(kq_pd.clone()))))]), Array::new())
                        } else {
                            (Array::new(), Array::from(vec![(crate::check::env::sname_key_f(k_pb), crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XVar(fresh_p4.clone())), Text::lit("kind_p")), crate::lower::types::Holding::Owned, crate::lower::model::OutTy::OutText))]))
                        },
                        None => (Array::new(), Array::from(vec![(crate::check::env::sname_key_f(k_pb), crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XVar(fresh_p4.clone())), Text::lit("kind_p")), crate::lower::types::Holding::Owned, crate::lower::model::OutTy::OutText))])),
                    }
                },
                _ => (Array::new(), Array::new()),
            },
            m16544_1 if (m16544_1 == &Text::lit("message")) => match &*fp_p8.pattern_p.kind_p {
                crate::syntax::PatternKind::PName(m_pe) => (Array::new(), Array::from(vec![(crate::check::env::sname_key_f(m_pe), crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XVar(fresh_p4.clone())), Text::lit("message_p")), crate::lower::types::Holding::Owned, crate::lower::model::OutTy::OutText))])),
                _ => (Array::new(), Array::new()),
            },
            _ => (Array::new(), Array::new()),
            _ => unreachable!("no arm matched"),
        }
    }));
    let wrapped_p7 = match crate::lower::types::peel_f(ty_p2) {
        crate::check::types::Ty::TySig(m17389_0_0, _) if (&m17389_0_0 == &Text::lit("~")) => crate::lower::model::Pa::PaCtor(Text::lit("Err"), Array::from(vec![crate::lower::model::Pa::PaBind(fresh_p4.clone())])),
        _ => crate::lower::model::Pa::PaBind(fresh_p4.clone()),
        _ => unreachable!("no arm matched"),
    };
    PatOut { pa_p: wrapped_p7.clone(), conds_p: crate::prelude::fold(&parts_p6, &Array::new(), &(|acc_pf: &Array<crate::lower::model::Cc>, (cs_pg, _): &(Array<crate::lower::model::Cc>, Array<(Text, crate::lower::types::Bn)>)| crate::prelude::append(acc_pf, cs_pg))), binds_p: crate::prelude::fold(&parts_p6, &Array::new(), &(|acc_ph: &Array<(Text, crate::lower::types::Bn)>, (_, bs_pi): &(Array<crate::lower::model::Cc>, Array<(Text, crate::lower::types::Bn)>)| crate::prelude::append(acc_ph, bs_pi))) }
}

/// The step machine of `ErrorPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ErrorPat: unbounded fn Lx, [FieldPat], Ty, Holding, Text -> PatOut
/// ```
pub struct ErrorPat {
    pub lx_p0: crate::lower::Lx,
    pub fps_p1: Array<crate::syntax::FieldPat>,
    pub ty_p2: crate::check::types::Ty,
    pub mode_p3: crate::lower::types::Holding,
    pub fresh_p4: Text,
}

impl prism_rtl::Job<PatOut> for ErrorPat {
    fn cycle(&self) -> prism_rtl::Turn<PatOut> {
        let lx_p0 = &self.lx_p0;
        let fps_p1 = &self.fps_p1;
        let ty_p2 = &self.ty_p2;
        let mode_p3 = &self.mode_p3;
        let fresh_p4 = &self.fresh_p4;
        let e_p5 = crate::lower::types::local_place_f(&crate::lower::model::Ex::XVar(fresh_p4.clone()), mode_p3, &crate::lower::model::OutTy::OutError);
        let parts_p6 = crate::prelude::each(fps_p1, &(|fp_p8: &crate::syntax::FieldPat| {
            let fname_p9 = match &fp_p8.name_o {
                Some(id_pa) => id_pa.name_p.clone(),
                None => Text::lit(""),
            };
            match &fname_p9 {
                m16544_0 if (m16544_0 == &Text::lit("kind")) => match &*fp_p8.pattern_p.kind_p {
                    crate::syntax::PatternKind::PName(k_pb) => {
                        let (kq_oc, _) = crate::check::env::names::resolve_value_f(&lx_p0.g_p, &lx_p0.home_p, k_pb);
                        match &kq_oc {
                            Some(kq_pd) => if crate::check::env::has_key_f(&lx_p0.g_p.tags_p, kq_pd) {
                                (Array::from(vec![crate::lower::model::Cc::CcIf(crate::lower::model::Ex::XBin(crate::lower::model::BinOp::OpEq, Rc::new(crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XDeref(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XVar(fresh_p4.clone())), Text::lit("kind_p"))))))), Rc::new(crate::lower::model::Ex::XStr(kq_pd.clone()))))]), Array::new())
                            } else {
                                (Array::new(), Array::from(vec![(crate::check::env::sname_key_f(k_pb), crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XVar(fresh_p4.clone())), Text::lit("kind_p")), crate::lower::types::Holding::Owned, crate::lower::model::OutTy::OutText))]))
                            },
                            None => (Array::new(), Array::from(vec![(crate::check::env::sname_key_f(k_pb), crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XVar(fresh_p4.clone())), Text::lit("kind_p")), crate::lower::types::Holding::Owned, crate::lower::model::OutTy::OutText))])),
                        }
                    },
                    _ => (Array::new(), Array::new()),
                },
                m16544_1 if (m16544_1 == &Text::lit("message")) => match &*fp_p8.pattern_p.kind_p {
                    crate::syntax::PatternKind::PName(m_pe) => (Array::new(), Array::from(vec![(crate::check::env::sname_key_f(m_pe), crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XVar(fresh_p4.clone())), Text::lit("message_p")), crate::lower::types::Holding::Owned, crate::lower::model::OutTy::OutText))])),
                    _ => (Array::new(), Array::new()),
                },
                _ => (Array::new(), Array::new()),
                _ => unreachable!("no arm matched"),
            }
        }));
        let wrapped_p7 = match crate::lower::types::peel_f(ty_p2) {
            crate::check::types::Ty::TySig(m17389_0_0, _) if (&m17389_0_0 == &Text::lit("~")) => crate::lower::model::Pa::PaCtor(Text::lit("Err"), Array::from(vec![crate::lower::model::Pa::PaBind(fresh_p4.clone())])),
            _ => crate::lower::model::Pa::PaBind(fresh_p4.clone()),
            _ => unreachable!("no arm matched"),
        };
        prism_rtl::Turn::Finished(PatOut { pa_p: wrapped_p7.clone(), conds_p: crate::prelude::fold(&parts_p6, &Array::new(), &(|acc_pf: &Array<crate::lower::model::Cc>, (cs_pg, _): &(Array<crate::lower::model::Cc>, Array<(Text, crate::lower::types::Bn)>)| crate::prelude::append(acc_pf, cs_pg))), binds_p: crate::prelude::fold(&parts_p6, &Array::new(), &(|acc_ph: &Array<(Text, crate::lower::types::Bn)>, (_, bs_pi): &(Array<crate::lower::model::Cc>, Array<(Text, crate::lower::types::Bn)>)| crate::prelude::append(acc_ph, bs_pi))) })
    }
}

/// `Start ErrorPat, x`: what the function value is when passed to `@Run`.
pub fn start_error_pat_f(lx_p0: crate::lower::Lx, fps_p1: Array<crate::syntax::FieldPat>, ty_p2: crate::check::types::Ty, mode_p3: crate::lower::types::Holding, fresh_p4: Text) -> Rc<dyn prism_rtl::Job<PatOut>> {
    Rc::new(ErrorPat { lx_p0, fps_p1, ty_p2, mode_p3, fresh_p4 })
}

/// ```prism
/// ArrayPat: unbounded fn Lx, [Pattern], Ty, Holding, Text -> PatOut
/// ```
pub fn array_pat_f(lx_p0: &crate::lower::Lx, ps_p1: &Array<crate::syntax::Pattern_>, ty_p2: &crate::check::types::Ty, mode_p3: &crate::lower::types::Holding, fresh_p4: &Text) -> PatOut {
    let et_p5 = match crate::lower::types::peel_f(ty_p2) {
        crate::check::types::Ty::TyArray(x_pb) => (*x_pb).clone(),
        _ => crate::check::types::Ty::TyErr,
    };
    let arr_p6 = crate::lower::types::local_place_f(&crate::lower::model::Ex::XVar(fresh_p4.clone()), mode_p3, &crate::lower::types::out_ty_of_f(lx_p0, &crate::lower::types::peel_f(ty_p2)));
    let len_cond_p7 = crate::lower::model::Cc::CcIf(crate::lower::model::Ex::XBin(crate::lower::model::BinOp::OpEq, Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::types::ref_f(&arr_p6)), Text::lit("len"), Array::new())), Rc::new(crate::lower::model::Ex::XIndex(crate::prelude::len(ps_p1)))));
    let subs_p8 = crate::prelude::run_to_end(crate::prelude::each_job(crate::check::errors::range0_f(&crate::prelude::len(ps_p1)), {
        let lx_p0x = lx_p0.clone();
        let ps_p1x = ps_p1.clone();
        let et_p5x = et_p5.clone();
        let fresh_p4x = fresh_p4.clone();
        Rc::new(move |p0: Nat| {
            let lx_p0xy = lx_p0x.clone();
            let ps_p1xy = ps_p1x.clone();
            let et_p5xy = et_p5x.clone();
            let fresh_p4xy = fresh_p4x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let i_pc = p0;
                crate::prelude::call_then(start_rust_pat_f(lx_p0xy.clone(), crate::prelude::or(&crate::prelude::index(&ps_p1xy, &i_pc), &dummy_pat_p()), et_p5xy.clone(), crate::lower::types::Holding::Owned, Text::from(format!("{}_{}", &fresh_p4xy, &i_pc))), move |rust_pat_f_18086: PatOut| prism_rtl::Turn::Finished((i_pc.clone(), rust_pat_f_18086)))
            }))
        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<(Nat, PatOut)>>>
    }));
    let conds_p9 = crate::prelude::fold(&subs_p8, &Array::from(vec![len_cond_p7.clone()]), &(|acc_pd: &Array<crate::lower::model::Cc>, (i_pe, o_pf): &(Nat, PatOut)| crate::prelude::append(&crate::prelude::push(acc_pd, &crate::lower::model::Cc::CcLet(crate::lower::model::Pa::PaCtor(Text::lit("Some"), Array::from(vec![o_pf.pa_p.clone()])), crate::lower::model::Ex::XCall(crate::lower::helper_f(&Text::lit("index")), Array::from(vec![crate::lower::types::ref_f(&arr_p6), crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XNat(Text::from(format!("{}", i_pe)))))])))), &o_pf.conds_p)));
    let binds_pa = crate::prelude::fold(&subs_p8, &Array::new(), &(|acc_pg: &Array<(Text, crate::lower::types::Bn)>, (_, o_ph): &(Nat, PatOut)| crate::prelude::append(acc_pg, &o_ph.binds_p)));
    PatOut { pa_p: crate::lower::model::Pa::PaBind(fresh_p4.clone()), conds_p: conds_p9.clone(), binds_p: binds_pa.clone() }
}

/// The step machine of `ArrayPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ArrayPat: unbounded fn Lx, [Pattern], Ty, Holding, Text -> PatOut
/// ```
pub struct ArrayPat {
    pub lx_p0: crate::lower::Lx,
    pub ps_p1: Array<crate::syntax::Pattern_>,
    pub ty_p2: crate::check::types::Ty,
    pub mode_p3: crate::lower::types::Holding,
    pub fresh_p4: Text,
}

impl prism_rtl::Job<PatOut> for ArrayPat {
    fn cycle(&self) -> prism_rtl::Turn<PatOut> {
        let lx_p0 = &self.lx_p0;
        let ps_p1 = &self.ps_p1;
        let ty_p2 = &self.ty_p2;
        let mode_p3 = &self.mode_p3;
        let fresh_p4 = &self.fresh_p4;
        let et_p5 = match crate::lower::types::peel_f(ty_p2) {
            crate::check::types::Ty::TyArray(x_pb) => (*x_pb).clone(),
            _ => crate::check::types::Ty::TyErr,
        };
        let fresh_p4x = fresh_p4.clone();
        let lx_p0x = lx_p0.clone();
        let mode_p3x = mode_p3.clone();
        let ps_p1x = ps_p1.clone();
        let ty_p2x = ty_p2.clone();
        crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0x.clone(), crate::lower::types::peel_f(&ty_p2x)), move |out_ty_of_f_17925: crate::lower::model::OutTy| {
            let arr_p6 = crate::lower::types::local_place_f(&crate::lower::model::Ex::XVar(fresh_p4x.clone()), &mode_p3x, &out_ty_of_f_17925);
            let len_cond_p7 = crate::lower::model::Cc::CcIf(crate::lower::model::Ex::XBin(crate::lower::model::BinOp::OpEq, Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::types::ref_f(&arr_p6)), Text::lit("len"), Array::new())), Rc::new(crate::lower::model::Ex::XIndex(crate::prelude::len(&ps_p1x)))));
            crate::prelude::call_value(crate::prelude::each_job(crate::check::errors::range0_f(&crate::prelude::len(&ps_p1x)), {
                let lx_p0xx = lx_p0x.clone();
                let ps_p1xx = ps_p1x.clone();
                let et_p5x = et_p5.clone();
                let fresh_p4xx = fresh_p4x.clone();
                Rc::new(move |p0: Nat| {
                    let lx_p0xxy = lx_p0xx.clone();
                    let ps_p1xxy = ps_p1xx.clone();
                    let et_p5xy = et_p5x.clone();
                    let fresh_p4xxy = fresh_p4xx.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let i_pc = p0;
                        crate::prelude::call_then(start_rust_pat_f(lx_p0xxy.clone(), crate::prelude::or(&crate::prelude::index(&ps_p1xxy, &i_pc), &dummy_pat_p()), et_p5xy.clone(), crate::lower::types::Holding::Owned, Text::from(format!("{}_{}", &fresh_p4xxy, &i_pc))), move |rust_pat_f_18086: PatOut| prism_rtl::Turn::Finished((i_pc.clone(), rust_pat_f_18086)))
                    }))
                }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<(Nat, PatOut)>>>
            }), move |each_18051: Array<(Nat, PatOut)>| {
                let subs_p8 = each_18051;
                let conds_p9 = crate::prelude::fold(&subs_p8, &Array::from(vec![len_cond_p7.clone()]), &(|acc_pd: &Array<crate::lower::model::Cc>, (i_pe, o_pf): &(Nat, PatOut)| crate::prelude::append(&crate::prelude::push(acc_pd, &crate::lower::model::Cc::CcLet(crate::lower::model::Pa::PaCtor(Text::lit("Some"), Array::from(vec![o_pf.pa_p.clone()])), crate::lower::model::Ex::XCall(crate::lower::helper_f(&Text::lit("index")), Array::from(vec![crate::lower::types::ref_f(&arr_p6), crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XNat(Text::from(format!("{}", i_pe)))))])))), &o_pf.conds_p)));
                let binds_pa = crate::prelude::fold(&subs_p8, &Array::new(), &(|acc_pg: &Array<(Text, crate::lower::types::Bn)>, (_, o_ph): &(Nat, PatOut)| crate::prelude::append(acc_pg, &o_ph.binds_p)));
                prism_rtl::Turn::Finished(PatOut { pa_p: crate::lower::model::Pa::PaBind(fresh_p4x.clone()), conds_p: conds_p9.clone(), binds_p: binds_pa.clone() })
            })
        })
    }
}

/// `Start ArrayPat, x`: what the function value is when passed to `@Run`.
pub fn start_array_pat_f(lx_p0: crate::lower::Lx, ps_p1: Array<crate::syntax::Pattern_>, ty_p2: crate::check::types::Ty, mode_p3: crate::lower::types::Holding, fresh_p4: Text) -> Rc<dyn prism_rtl::Job<PatOut>> {
    Rc::new(ArrayPat { lx_p0, ps_p1, ty_p2, mode_p3, fresh_p4 })
}
