//! The module `Lower.Types`, from `target/bootstrap/src/prismc/lower/types.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// `Bn`:
///
/// ```prism
/// type Bn = choice:
/// ```
#[derive(Clone)]
pub enum Bn {
    BnLocal(crate::lower::model::Ex, Holding, crate::lower::model::OutTy),
    BnHold(Text, crate::lower::model::OutTy),
    BnDyn(crate::lower::model::Ex, Array<crate::lower::node_::Read>, crate::lower::model::OutTy),
    BnEv(crate::lower::node_::EvRef, crate::lower::model::OutTy),
    BnParts(Array<Option<Bn>>),
    BnWidget(crate::syntax::Expr, Env, Env, crate::lower::Lx),
    BnLocalFn(crate::syntax::decls::FnClause),
}

/// `Env`:
///
/// ```prism
/// type Env = record:
/// ```
#[derive(Clone)]
pub struct Env {
    pub names: Map<Text, Bn>,
    pub spans: Map<Text, Vl>,
    pub uses: Map<Text, Text>,
}

/// `Holding`:
///
/// ```prism
/// type Holding = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum Holding {
    ByRef,
    Owned,
    RcRef,
    RcOwned,
}

impl Show for Holding {
    fn show(&self, p: &mut Printer) {
        match self {
            Holding::ByRef => p.choice("ByRef", &[]),
            Holding::Owned => p.choice("Owned", &[]),
            Holding::RcRef => p.choice("RcRef", &[]),
            Holding::RcOwned => p.choice("RcOwned", &[]),
        }
    }
}

impl ToPod for Holding {
    fn to_pod(&self) -> Pod {
        match self {
            Holding::ByRef => Pod::Choice("ByRef".into(), vec![]),
            Holding::Owned => Pod::Choice("Owned".into(), vec![]),
            Holding::RcRef => Pod::Choice("RcRef".into(), vec![]),
            Holding::RcOwned => Pod::Choice("RcOwned".into(), vec![]),
        }
    }
}

impl FromPod for Holding {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "ByRef" && a.len() == 0 => Ok(Holding::ByRef),
            Pod::Choice(c, a) if &**c == "Owned" && a.len() == 0 => Ok(Holding::Owned),
            Pod::Choice(c, a) if &**c == "RcRef" && a.len() == 0 => Ok(Holding::RcRef),
            Pod::Choice(c, a) if &**c == "RcOwned" && a.len() == 0 => Ok(Holding::RcOwned),
            other => mismatch("a Holding", other),
        }
    }
}

/// `Layer`:
///
/// ```prism
/// type Layer = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum Layer {
    LyPlain,
    LyDyn,
    LyEv,
    LyBlueprint,
}

impl Show for Layer {
    fn show(&self, p: &mut Printer) {
        match self {
            Layer::LyPlain => p.choice("LyPlain", &[]),
            Layer::LyDyn => p.choice("LyDyn", &[]),
            Layer::LyEv => p.choice("LyEv", &[]),
            Layer::LyBlueprint => p.choice("LyBlueprint", &[]),
        }
    }
}

impl ToPod for Layer {
    fn to_pod(&self) -> Pod {
        match self {
            Layer::LyPlain => Pod::Choice("LyPlain".into(), vec![]),
            Layer::LyDyn => Pod::Choice("LyDyn".into(), vec![]),
            Layer::LyEv => Pod::Choice("LyEv".into(), vec![]),
            Layer::LyBlueprint => Pod::Choice("LyBlueprint".into(), vec![]),
        }
    }
}

impl FromPod for Layer {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "LyPlain" && a.len() == 0 => Ok(Layer::LyPlain),
            Pod::Choice(c, a) if &**c == "LyDyn" && a.len() == 0 => Ok(Layer::LyDyn),
            Pod::Choice(c, a) if &**c == "LyEv" && a.len() == 0 => Ok(Layer::LyEv),
            Pod::Choice(c, a) if &**c == "LyBlueprint" && a.len() == 0 => Ok(Layer::LyBlueprint),
            other => mismatch("a Layer", other),
        }
    }
}

/// `Vl`:
///
/// ```prism
/// type Vl = choice:
/// ```
#[derive(Clone)]
pub enum Vl {
    VlPlace(crate::lower::model::Ex, Holding, crate::lower::model::OutTy),
    VlOwned(crate::lower::model::Ex, crate::lower::model::OutTy),
}

impl ToPod for Vl {
    fn to_pod(&self) -> Pod {
        match self {
            Vl::VlPlace(a0, a1, a2) => Pod::Choice("VlPlace".into(), vec![a0.to_pod(), a1.to_pod(), a2.to_pod()]),
            Vl::VlOwned(a0, a1) => Pod::Choice("VlOwned".into(), vec![a0.to_pod(), a1.to_pod()]),
        }
    }
}

impl FromPod for Vl {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "VlPlace" && a.len() == 3 => Ok(Vl::VlPlace(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?, FromPod::from_pod(&a[2])?)),
            Pod::Choice(c, a) if &**c == "VlOwned" && a.len() == 2 => Ok(Vl::VlOwned(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            other => mismatch("a Vl", other),
        }
    }
}

/// ```prism
/// OutTyOf: unbounded fn Lx, Ty -> OutTy
/// ```
pub fn out_ty_of(lx: &crate::lower::Lx, t: &crate::check::types::Ty) -> crate::lower::model::OutTy {
    'm1375: {
        if let crate::check::types::Ty::TyCon(m1375_0_0, m1375_0_1) = t && (m1375_0_0 == &Text::lit("Nat")) && (m1375_0_1.len() == 0) {
            break 'm1375 crate::lower::model::OutTy::OutNat;
        }
        if let crate::check::types::Ty::TyCon(m1375_1_0, m1375_1_1) = t && (m1375_1_0 == &Text::lit("Int")) && (m1375_1_1.len() == 0) {
            break 'm1375 crate::lower::model::OutTy::OutInt;
        }
        if let crate::check::types::Ty::TyCon(m1375_2_0, m1375_2_1) = t && (m1375_2_0 == &Text::lit("U8")) && (m1375_2_1.len() == 0) {
            break 'm1375 crate::lower::model::OutTy::OutU8;
        }
        if let crate::check::types::Ty::TyCon(m1375_3_0, m1375_3_1) = t && (m1375_3_0 == &Text::lit("Float")) && (m1375_3_1.len() == 0) {
            break 'm1375 crate::lower::model::OutTy::OutFloat;
        }
        if let crate::check::types::Ty::TyCon(m1375_4_0, m1375_4_1) = t && (m1375_4_0 == &Text::lit("Bool")) && (m1375_4_1.len() == 0) {
            break 'm1375 crate::lower::model::OutTy::OutBool;
        }
        if let crate::check::types::Ty::TyCon(m1375_5_0, m1375_5_1) = t && (m1375_5_0 == &Text::lit("Char")) && (m1375_5_1.len() == 0) {
            break 'm1375 crate::lower::model::OutTy::OutChar;
        }
        if let crate::check::types::Ty::TyCon(m1375_6_0, m1375_6_1) = t && (m1375_6_0 == &Text::lit("Text")) && (m1375_6_1.len() == 0) {
            break 'm1375 crate::lower::model::OutTy::OutText;
        }
        if let crate::check::types::Ty::TyCon(m1375_7_0, m1375_7_1) = t && (m1375_7_0 == &Text::lit("unit")) && (m1375_7_1.len() == 0) {
            break 'm1375 crate::lower::model::OutTy::OutUnit;
        }
        if let crate::check::types::Ty::TyCon(m1375_8_0, m1375_8_1) = t && (m1375_8_0 == &Text::lit("Path")) && (m1375_8_1.len() == 0) {
            break 'm1375 crate::lower::model::OutTy::OutPath;
        }
        if let crate::check::types::Ty::TyCon(m1375_9_0, m1375_9_1) = t && (m1375_9_0 == &Text::lit("Cursor")) && (m1375_9_1.len() == 0) {
            break 'm1375 crate::lower::model::OutTy::OutCursor;
        }
        if let crate::check::types::Ty::TyCon(m1375_10_0, m1375_10_1) = t && (m1375_10_0 == &Text::lit("Regex")) && (m1375_10_1.len() == 0) {
            break 'm1375 crate::lower::model::OutTy::OutRegex;
        }
        if let crate::check::types::Ty::TyCon(m1375_11_0, m1375_11_1) = t && (m1375_11_0 == &Text::lit("RegexReplacement")) && (m1375_11_1.len() == 0) {
            break 'm1375 crate::lower::model::OutTy::OutReplacement;
        }
        if let crate::check::types::Ty::TyCon(m1375_12_0, m1375_12_1) = t && (m1375_12_0 == &Text::lit("Duration")) && (m1375_12_1.len() == 0) {
            break 'm1375 crate::lower::model::OutTy::OutDuration;
        }
        if let crate::check::types::Ty::TyCon(m1375_13_0, m1375_13_1) = t && (m1375_13_0 == &Text::lit("Prelude.Error")) && (m1375_13_1.len() == 0) {
            break 'm1375 crate::lower::model::OutTy::OutError;
        }
        if let crate::check::types::Ty::TyCon(m1375_14_0, m1375_14_1) = t && (m1375_14_0 == &Text::lit("\0Self")) && (m1375_14_1.len() == 0) {
            break 'm1375 crate::lower::model::OutTy::OutNamed(Text::lit("Self"), Array::new());
        }
        if let crate::check::types::Ty::TyCon(m1375_15_0, m1375_15_1) = t && (m1375_15_0 == &Text::lit("Buffer")) && (m1375_15_1.len() == 1) && let Some(a) = index(m1375_15_1, &Nat::from(0u32)) {
            break 'm1375 crate::lower::model::OutTy::OutArray(Rc::new(out_ty_of(lx, &a)));
        }
        if let crate::check::types::Ty::TyCon(m1375_16_0, m1375_16_1) = t && (m1375_16_0 == &Text::lit("Table")) && (m1375_16_1.len() == 2) && let Some(k) = index(m1375_16_1, &Nat::from(0u32)) && let Some(v_) = index(m1375_16_1, &Nat::from(1u32)) {
            break 'm1375 crate::lower::model::OutTy::OutArray(Rc::new(crate::lower::model::OutTy::OutTuple(Array::from(vec![out_ty_of(lx, &k), out_ty_of(lx, &v_)]))));
        }
        if let crate::check::types::Ty::TyCon(m1375_17_0, m1375_17_1) = t && (m1375_17_0 == &Text::lit("\0Event")) && (m1375_17_1.len() == 1) && let Some(a) = index(m1375_17_1, &Nat::from(0u32)) {
            break 'm1375 crate::lower::model::OutTy::OutEvent(Rc::new(out_ty_of(lx, &a)));
        }
        if let crate::check::types::Ty::TyCon(n, args) = t {
            break 'm1375 named_ty(lx, n, &run_to_end(each_job(args.clone(), {
                let lx = lx.clone();
                Rc::new(move |p0: crate::check::types::Ty| {
                    let lx = lx.clone();
                    entered(once_job(move || {
                        let a = p0;
                        prism_rtl::Turn::More(Rc::new(OutTyOf { lx: lx.clone(), t: a.clone() }))
                    }))
                }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::lower::model::OutTy>>>
            })));
        }
        if let crate::check::types::Ty::TyFn(c, ps, res) = t {
            break 'm1375 {
                let c2 = crate::lower::inst_col(lx, c);
                if &c2 == &crate::check::types::Col::CBound {
                    crate::lower::model::OutTy::OutFn(run_to_end(each_job(ps.clone(), {
                        let lx = lx.clone();
                        Rc::new(move |p0: crate::check::types::Ty| {
                            let lx = lx.clone();
                            entered(once_job(move || {
                                let p_ = p0;
                                prism_rtl::Turn::More(Rc::new(OutTyOf { lx: lx.clone(), t: p_.clone() }))
                            }))
                        }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::lower::model::OutTy>>>
                    })), Rc::new(out_ty_of(lx, &**res)))
                } else {
                    if crate::lower::is_quant_col(lx, &c2) {
                        crate::lower::model::OutTy::OutQuantified(or(&get(&lx.quants, &crate::lower::expr::col_name(&c2)), &Text::lit("")))
                    } else {
                        crate::lower::model::OutTy::OutJobFn(Rc::new(rust_ty_of_params(lx, &each(ps, &(|p_: &crate::check::types::Ty| job_param(p_))))), Rc::new(out_ty_of(lx, &**res)))
                    }
                }
            };
        }
        if let crate::check::types::Ty::TyTuple(m1375_20_0) = t && (m1375_20_0.len() == 0) {
            break 'm1375 crate::lower::model::OutTy::OutUnit;
        }
        if let crate::check::types::Ty::TyTuple(ts) = t {
            break 'm1375 crate::lower::model::OutTy::OutTuple(run_to_end(each_job(ts.clone(), {
                let lx = lx.clone();
                Rc::new(move |p0: crate::check::types::Ty| {
                    let lx = lx.clone();
                    entered(once_job(move || {
                        let a = p0;
                        prism_rtl::Turn::More(Rc::new(OutTyOf { lx: lx.clone(), t: a.clone() }))
                    }))
                }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::lower::model::OutTy>>>
            })));
        }
        if let crate::check::types::Ty::TyArray(e) = t {
            break 'm1375 crate::lower::model::OutTy::OutArray(Rc::new(out_ty_of(lx, &**e)));
        }
        if let crate::check::types::Ty::TyMap(k, v_) = t {
            break 'm1375 crate::lower::model::OutTy::OutMap(Rc::new(out_ty_of(lx, &**k)), Rc::new(out_ty_of(lx, &**v_)));
        }
        if let crate::check::types::Ty::TySig(m1375_24_0, i) = t && (m1375_24_0 == &Text::lit("?")) {
            break 'm1375 crate::lower::model::OutTy::OutOpt(Rc::new(out_ty_of(lx, &**i)));
        }
        if let crate::check::types::Ty::TySig(m1375_25_0, i) = t && (m1375_25_0 == &Text::lit("~")) {
            break 'm1375 crate::lower::model::OutTy::OutRes(Rc::new(out_ty_of(lx, &**i)));
        }
        if let crate::check::types::Ty::TySig(m1375_26_0, i) = t && (m1375_26_0 == &Text::lit("!")) {
            break 'm1375 crate::lower::model::OutTy::OutEvent(Rc::new(out_ty_of(lx, &**i)));
        }
        if let crate::check::types::Ty::TySig(m1375_27_0, i) = t && (m1375_27_0 == &Text::lit("$")) {
            break 'm1375 crate::lower::model::OutTy::OutDyn(Rc::new(out_ty_of(lx, &**i)));
        }
        if let crate::check::types::Ty::TySig(m1375_28_0, i) = t && (m1375_28_0 == &Text::lit("&")) {
            break 'm1375 out_ty_of(lx, &**i);
        }
        if let crate::check::types::Ty::TySig(_, i) = t {
            break 'm1375 out_ty_of(lx, &**i);
        }
        if let crate::check::types::Ty::TyQ(n) = t {
            break 'm1375 crate::lower::model::OutTy::OutGen(crate::lower::camel(n));
        }
        if let crate::check::types::Ty::TyRigid(n) = t {
            break 'm1375 crate::lower::model::OutTy::OutGen(crate::lower::camel(n));
        }
        if let crate::check::types::Ty::TyFlex(n) = t {
            break 'm1375 match get(&lx.subst, &Text::from(format!("\'{}", n))) {
                Some(x) => out_ty_of(lx, &x),
                None => match get(&lx.quants, &Text::from(format!("\'{}", n))) {
                    Some(b) => crate::lower::model::OutTy::OutQuantified(b),
                    None => crate::lower::model::OutTy::OutUnit,
                },
            };
        }
        if let crate::check::types::Ty::TyAny(_) = t {
            break 'm1375 crate::lower::model::OutTy::OutShowAny;
        }
        if let crate::check::types::Ty::TyElem(_, _) = t {
            break 'm1375 crate::lower::model::OutTy::OutLive(Rc::new(crate::lower::model::OutTy::OutNamed(Text::lit("crate::Elem"), Array::new())));
        }
        if let crate::check::types::Ty::TyElemAny(_) = t {
            break 'm1375 crate::lower::model::OutTy::OutNamed(Text::lit("crate::Elem"), Array::new());
        }
        if let crate::check::types::Ty::TyAt(i, _) = t {
            break 'm1375 blueprint_ty();
        }
        if let crate::check::types::Ty::TyAssoc(_, _) = t {
            break 'm1375 crate::lower::model::OutTy::OutUnknown(Text::lit("an associated type"));
        }
        if let crate::check::types::Ty::TyErr = t {
            break 'm1375 crate::lower::model::OutTy::OutUnknown(Text::lit("a type the checker did not find"));
        }
        unreachable!("no clause matched")
    }
}

/// The step machine of `OutTyOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// OutTyOf: unbounded fn Lx, Ty -> OutTy
/// ```
pub struct OutTyOf {
    pub lx: crate::lower::Lx,
    pub t: crate::check::types::Ty,
}

impl prism_rtl::Job<crate::lower::model::OutTy> for OutTyOf {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::OutTy> {
        let lx = &self.lx;
        let t = &self.t;
        'm1375: {
            if let crate::check::types::Ty::TyCon(m1375_0_0, m1375_0_1) = t && (m1375_0_0 == &Text::lit("Nat")) && (m1375_0_1.len() == 0) {
                break 'm1375 prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutNat);
            }
            if let crate::check::types::Ty::TyCon(m1375_1_0, m1375_1_1) = t && (m1375_1_0 == &Text::lit("Int")) && (m1375_1_1.len() == 0) {
                break 'm1375 prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutInt);
            }
            if let crate::check::types::Ty::TyCon(m1375_2_0, m1375_2_1) = t && (m1375_2_0 == &Text::lit("U8")) && (m1375_2_1.len() == 0) {
                break 'm1375 prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutU8);
            }
            if let crate::check::types::Ty::TyCon(m1375_3_0, m1375_3_1) = t && (m1375_3_0 == &Text::lit("Float")) && (m1375_3_1.len() == 0) {
                break 'm1375 prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutFloat);
            }
            if let crate::check::types::Ty::TyCon(m1375_4_0, m1375_4_1) = t && (m1375_4_0 == &Text::lit("Bool")) && (m1375_4_1.len() == 0) {
                break 'm1375 prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutBool);
            }
            if let crate::check::types::Ty::TyCon(m1375_5_0, m1375_5_1) = t && (m1375_5_0 == &Text::lit("Char")) && (m1375_5_1.len() == 0) {
                break 'm1375 prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutChar);
            }
            if let crate::check::types::Ty::TyCon(m1375_6_0, m1375_6_1) = t && (m1375_6_0 == &Text::lit("Text")) && (m1375_6_1.len() == 0) {
                break 'm1375 prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutText);
            }
            if let crate::check::types::Ty::TyCon(m1375_7_0, m1375_7_1) = t && (m1375_7_0 == &Text::lit("unit")) && (m1375_7_1.len() == 0) {
                break 'm1375 prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutUnit);
            }
            if let crate::check::types::Ty::TyCon(m1375_8_0, m1375_8_1) = t && (m1375_8_0 == &Text::lit("Path")) && (m1375_8_1.len() == 0) {
                break 'm1375 prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutPath);
            }
            if let crate::check::types::Ty::TyCon(m1375_9_0, m1375_9_1) = t && (m1375_9_0 == &Text::lit("Cursor")) && (m1375_9_1.len() == 0) {
                break 'm1375 prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutCursor);
            }
            if let crate::check::types::Ty::TyCon(m1375_10_0, m1375_10_1) = t && (m1375_10_0 == &Text::lit("Regex")) && (m1375_10_1.len() == 0) {
                break 'm1375 prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutRegex);
            }
            if let crate::check::types::Ty::TyCon(m1375_11_0, m1375_11_1) = t && (m1375_11_0 == &Text::lit("RegexReplacement")) && (m1375_11_1.len() == 0) {
                break 'm1375 prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutReplacement);
            }
            if let crate::check::types::Ty::TyCon(m1375_12_0, m1375_12_1) = t && (m1375_12_0 == &Text::lit("Duration")) && (m1375_12_1.len() == 0) {
                break 'm1375 prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutDuration);
            }
            if let crate::check::types::Ty::TyCon(m1375_13_0, m1375_13_1) = t && (m1375_13_0 == &Text::lit("Prelude.Error")) && (m1375_13_1.len() == 0) {
                break 'm1375 prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutError);
            }
            if let crate::check::types::Ty::TyCon(m1375_14_0, m1375_14_1) = t && (m1375_14_0 == &Text::lit("\0Self")) && (m1375_14_1.len() == 0) {
                break 'm1375 prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutNamed(Text::lit("Self"), Array::new()));
            }
            if let crate::check::types::Ty::TyCon(m1375_15_0, m1375_15_1) = t && (m1375_15_0 == &Text::lit("Buffer")) && (m1375_15_1.len() == 1) && let Some(a) = index(m1375_15_1, &Nat::from(0u32)) {
                break 'm1375 {
                    let lx = lx.clone();
                    call_then(start_out_ty_of(lx.clone(), a.clone()), move |out_ty_of_1957: crate::lower::model::OutTy| prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutArray(Rc::new(out_ty_of_1957))))
                };
            }
            if let crate::check::types::Ty::TyCon(m1375_16_0, m1375_16_1) = t && (m1375_16_0 == &Text::lit("Table")) && (m1375_16_1.len() == 2) && let Some(k) = index(m1375_16_1, &Nat::from(0u32)) && let Some(v_) = index(m1375_16_1, &Nat::from(1u32)) {
                break 'm1375 {
                    let lx = lx.clone();
                    call_then(start_out_ty_of(lx.clone(), k.clone()), move |out_ty_of_2023: crate::lower::model::OutTy| call_then(start_out_ty_of(lx.clone(), v_.clone()), move |out_ty_of_2040: crate::lower::model::OutTy| prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutArray(Rc::new(crate::lower::model::OutTy::OutTuple(Array::from(vec![out_ty_of_2023, out_ty_of_2040])))))))
                };
            }
            if let crate::check::types::Ty::TyCon(m1375_17_0, m1375_17_1) = t && (m1375_17_0 == &Text::lit("\0Event")) && (m1375_17_1.len() == 1) && let Some(a) = index(m1375_17_1, &Nat::from(0u32)) {
                break 'm1375 {
                    let lx = lx.clone();
                    call_then(start_out_ty_of(lx.clone(), a.clone()), move |out_ty_of_2099: crate::lower::model::OutTy| prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutEvent(Rc::new(out_ty_of_2099))))
                };
            }
            if let crate::check::types::Ty::TyCon(n, args) = t {
                break 'm1375 {
                    let args = args.clone();
                    let lx = lx.clone();
                    let n = n.clone();
                    call_value(each_job(args.clone(), {
                        let lx = lx.clone();
                        Rc::new(move |p0: crate::check::types::Ty| {
                            let lx = lx.clone();
                            entered(once_job(move || {
                                let a = p0;
                                prism_rtl::Turn::More(Rc::new(OutTyOf { lx: lx.clone(), t: a.clone() }))
                            }))
                        }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::lower::model::OutTy>>>
                    }), move |each_2149: Array<crate::lower::model::OutTy>| prism_rtl::Turn::More(Rc::new(NamedTy { lx: lx.clone(), n: n.clone(), args: each_2149 })))
                };
            }
            if let crate::check::types::Ty::TyFn(c, ps, res) = t {
                break 'm1375 {
                    let c2 = crate::lower::inst_col(lx, c);
                    if &c2 == &crate::check::types::Col::CBound {
                        {
                            let lx = lx.clone();
                            let ps = ps.clone();
                            let res = (**res).clone();
                            call_value(each_job(ps.clone(), {
                                let lx = lx.clone();
                                Rc::new(move |p0: crate::check::types::Ty| {
                                    let lx = lx.clone();
                                    entered(once_job(move || {
                                        let p_ = p0;
                                        prism_rtl::Turn::More(Rc::new(OutTyOf { lx: lx.clone(), t: p_.clone() }))
                                    }))
                                }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::lower::model::OutTy>>>
                            }), move |each_2430: Array<crate::lower::model::OutTy>| call_then(start_out_ty_of(lx.clone(), res.clone()), move |out_ty_of_2461: crate::lower::model::OutTy| prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutFn(each_2430, Rc::new(out_ty_of_2461)))))
                        }
                    } else {
                        if crate::lower::is_quant_col(lx, &c2) {
                            prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutQuantified(or(&get(&lx.quants, &crate::lower::expr::col_name(&c2)), &Text::lit(""))))
                        } else {
                            {
                                let lx = lx.clone();
                                let ps = ps.clone();
                                let res = (**res).clone();
                                call_then(start_rust_ty_of_params(lx.clone(), each(&ps, &(|p_: &crate::check::types::Ty| job_param(p_)))), move |rust_ty_of_params_2583: crate::lower::model::OutTy| call_then(start_out_ty_of(lx.clone(), res.clone()), move |out_ty_of_2632: crate::lower::model::OutTy| prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutJobFn(Rc::new(rust_ty_of_params_2583), Rc::new(out_ty_of_2632)))))
                            }
                        }
                    }
                };
            }
            if let crate::check::types::Ty::TyTuple(m1375_20_0) = t && (m1375_20_0.len() == 0) {
                break 'm1375 prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutUnit);
            }
            if let crate::check::types::Ty::TyTuple(ts) = t {
                break 'm1375 {
                    let lx = lx.clone();
                    let ts = ts.clone();
                    call_value(each_job(ts.clone(), {
                        let lx = lx.clone();
                        Rc::new(move |p0: crate::check::types::Ty| {
                            let lx = lx.clone();
                            entered(once_job(move || {
                                let a = p0;
                                prism_rtl::Turn::More(Rc::new(OutTyOf { lx: lx.clone(), t: a.clone() }))
                            }))
                        }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::lower::model::OutTy>>>
                    }), move |each_2701: Array<crate::lower::model::OutTy>| prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutTuple(each_2701)))
                };
            }
            if let crate::check::types::Ty::TyArray(e) = t {
                break 'm1375 {
                    let e = (**e).clone();
                    let lx = lx.clone();
                    call_then(start_out_ty_of(lx.clone(), e.clone()), move |out_ty_of_2755: crate::lower::model::OutTy| prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutArray(Rc::new(out_ty_of_2755))))
                };
            }
            if let crate::check::types::Ty::TyMap(k, v_) = t {
                break 'm1375 {
                    let k = (**k).clone();
                    let lx = lx.clone();
                    let v_ = (**v_).clone();
                    call_then(start_out_ty_of(lx.clone(), k.clone()), move |out_ty_of_2794: crate::lower::model::OutTy| call_then(start_out_ty_of(lx.clone(), v_.clone()), move |out_ty_of_2811: crate::lower::model::OutTy| prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutMap(Rc::new(out_ty_of_2794), Rc::new(out_ty_of_2811)))))
                };
            }
            if let crate::check::types::Ty::TySig(m1375_24_0, i) = t && (m1375_24_0 == &Text::lit("?")) {
                break 'm1375 {
                    let i = (**i).clone();
                    let lx = lx.clone();
                    call_then(start_out_ty_of(lx.clone(), i.clone()), move |out_ty_of_2852: crate::lower::model::OutTy| prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutOpt(Rc::new(out_ty_of_2852))))
                };
            }
            if let crate::check::types::Ty::TySig(m1375_25_0, i) = t && (m1375_25_0 == &Text::lit("~")) {
                break 'm1375 {
                    let i = (**i).clone();
                    let lx = lx.clone();
                    call_then(start_out_ty_of(lx.clone(), i.clone()), move |out_ty_of_2893: crate::lower::model::OutTy| prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutRes(Rc::new(out_ty_of_2893))))
                };
            }
            if let crate::check::types::Ty::TySig(m1375_26_0, i) = t && (m1375_26_0 == &Text::lit("!")) {
                break 'm1375 {
                    let i = (**i).clone();
                    let lx = lx.clone();
                    call_then(start_out_ty_of(lx.clone(), i.clone()), move |out_ty_of_2936: crate::lower::model::OutTy| prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutEvent(Rc::new(out_ty_of_2936))))
                };
            }
            if let crate::check::types::Ty::TySig(m1375_27_0, i) = t && (m1375_27_0 == &Text::lit("$")) {
                break 'm1375 {
                    let i = (**i).clone();
                    let lx = lx.clone();
                    call_then(start_out_ty_of(lx.clone(), i.clone()), move |out_ty_of_2977: crate::lower::model::OutTy| prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutDyn(Rc::new(out_ty_of_2977))))
                };
            }
            if let crate::check::types::Ty::TySig(m1375_28_0, i) = t && (m1375_28_0 == &Text::lit("&")) {
                break 'm1375 prism_rtl::Turn::More(Rc::new(OutTyOf { lx: lx.clone(), t: (**i).clone() }));
            }
            if let crate::check::types::Ty::TySig(_, i) = t {
                break 'm1375 prism_rtl::Turn::More(Rc::new(OutTyOf { lx: lx.clone(), t: (**i).clone() }));
            }
            if let crate::check::types::Ty::TyQ(n) = t {
                break 'm1375 prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutGen(crate::lower::camel(n)));
            }
            if let crate::check::types::Ty::TyRigid(n) = t {
                break 'm1375 prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutGen(crate::lower::camel(n)));
            }
            if let crate::check::types::Ty::TyFlex(n) = t {
                break 'm1375 match get(&lx.subst, &Text::from(format!("\'{}", n))) {
                    Some(x) => prism_rtl::Turn::More(Rc::new(OutTyOf { lx: lx.clone(), t: x.clone() })),
                    None => match get(&lx.quants, &Text::from(format!("\'{}", n))) {
                        Some(b) => prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutQuantified(b.clone())),
                        None => prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutUnit),
                    },
                };
            }
            if let crate::check::types::Ty::TyAny(_) = t {
                break 'm1375 prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutShowAny);
            }
            if let crate::check::types::Ty::TyElem(_, _) = t {
                break 'm1375 prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutLive(Rc::new(crate::lower::model::OutTy::OutNamed(Text::lit("crate::Elem"), Array::new()))));
            }
            if let crate::check::types::Ty::TyElemAny(_) = t {
                break 'm1375 prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutNamed(Text::lit("crate::Elem"), Array::new()));
            }
            if let crate::check::types::Ty::TyAt(i, _) = t {
                break 'm1375 prism_rtl::Turn::Finished(blueprint_ty());
            }
            if let crate::check::types::Ty::TyAssoc(_, _) = t {
                break 'm1375 prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutUnknown(Text::lit("an associated type")));
            }
            if let crate::check::types::Ty::TyErr = t {
                break 'm1375 prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutUnknown(Text::lit("a type the checker did not find")));
            }
            unreachable!("no clause matched")
        }
    }
}

/// `Start OutTyOf, x`: what the function value is when passed to `@Run`.
pub fn start_out_ty_of(lx: crate::lower::Lx, t: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::lower::model::OutTy>> {
    Rc::new(OutTyOf { lx, t })
}

/// ```prism
/// let blueprintTy
/// ```
pub fn blueprint_ty() -> crate::lower::model::OutTy {
    crate::lower::model::OutTy::OutNamed(Text::lit("prism_rtl::Blueprint"), Array::from(vec![crate::lower::model::OutTy::OutNamed(Text::lit("crate::Elem"), Array::new()), crate::lower::model::OutTy::OutNamed(Text::lit("crate::Answer"), Array::new())]))
}

/// ```prism
/// let elemTy
/// ```
pub fn elem_ty() -> crate::lower::model::OutTy {
    crate::lower::model::OutTy::OutNamed(Text::lit("crate::Elem"), Array::new())
}

/// ```prism
/// let answerTy
/// ```
pub fn answer_ty() -> crate::lower::model::OutTy {
    crate::lower::model::OutTy::OutNamed(Text::lit("crate::Answer"), Array::new())
}

/// ```prism
/// let entryTy
/// ```
pub fn entry_ty() -> crate::lower::model::OutTy {
    crate::lower::model::OutTy::OutRc(Rc::new(crate::lower::model::OutTy::OutNamed(Text::lit("prism_rtl::Entry"), Array::from(vec![crate::lower::model::OutTy::OutNamed(Text::lit("crate::Elem"), Array::new())]))))
}

/// ```prism
/// let hostDocTy
/// ```
pub fn host_doc_ty() -> crate::lower::model::OutTy {
    crate::lower::model::OutTy::OutNamed(Text::lit("prism_rtl::HostDoc"), Array::from(vec![crate::lower::model::OutTy::OutNamed(Text::lit("crate::Elem"), Array::new())]))
}

/// ```prism
/// let hostOfTy
/// ```
pub fn host_of_ty() -> crate::lower::model::OutTy {
    crate::lower::model::OutTy::OutObj(Rc::new(crate::lower::model::OutTy::OutNamed(Text::lit("prism_rtl::HostOf"), Array::from(vec![crate::lower::model::OutTy::OutNamed(Text::lit("crate::Elem"), Array::new()), crate::lower::model::OutTy::OutNamed(Text::lit("crate::Answer"), Array::new())]))))
}

/// ```prism
/// HasBlueprint: fn Ty -> Bool
/// ```
pub fn has_blueprint(t: &crate::check::types::Ty) -> bool {
    match t {
        crate::check::types::Ty::TyAt(_, _) => true,
        crate::check::types::Ty::TySig(_, i) => has_blueprint(&**i),
        _ => false,
    }
}

/// ```prism
/// EventParam: fn Ty -> Ty
/// ```
pub fn event_param(t: &crate::check::types::Ty) -> crate::check::types::Ty {
    match t {
        crate::check::types::Ty::TySig(m4785_0_0, i) if (m4785_0_0 == &Text::lit("!")) => crate::check::types::Ty::TyCon(Text::lit("\0Event"), Array::from(vec![peel(&**i)])),
        _ => t.clone(),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// JobParam: fn Ty -> Ty
/// ```
pub fn job_param(ty0: &crate::check::types::Ty) -> crate::check::types::Ty {
    match ty0 {
        crate::check::types::Ty::TyFn(_, ps, r) => crate::check::types::Ty::TyFn(crate::check::types::Col::CUnbound, ps.clone(), Rc::new((**r).clone())),
        t => t.clone(),
    }
}

/// ```prism
/// RustTyOfParams: unbounded fn Lx, [Ty] -> OutTy
/// ```
pub fn rust_ty_of_params(lx: &crate::lower::Lx, ps: &Array<crate::check::types::Ty>) -> crate::lower::model::OutTy {
    'm5348: {
        if let m5348_0 = ps && (m5348_0.len() == 1) && let Some(p_) = index(m5348_0, &Nat::from(0u32)) {
            break 'm5348 out_ty_of(lx, &p_);
        }
        crate::lower::model::OutTy::OutTuple(run_to_end(each_job(ps.clone(), {
            let lx = lx.clone();
            Rc::new(move |p0: crate::check::types::Ty| {
                let lx = lx.clone();
                entered(once_job(move || {
                    let p_ = p0;
                    prism_rtl::Turn::More(Rc::new(OutTyOf { lx: lx.clone(), t: p_.clone() }))
                }))
            }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::lower::model::OutTy>>>
        })))
    }
}

/// The step machine of `RustTyOfParams`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RustTyOfParams: unbounded fn Lx, [Ty] -> OutTy
/// ```
pub struct RustTyOfParams {
    pub lx: crate::lower::Lx,
    pub ps: Array<crate::check::types::Ty>,
}

impl prism_rtl::Job<crate::lower::model::OutTy> for RustTyOfParams {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::OutTy> {
        let lx = &self.lx;
        let ps = &self.ps;
        'm5348: {
            if let m5348_0 = ps && (m5348_0.len() == 1) && let Some(p_) = index(m5348_0, &Nat::from(0u32)) {
                break 'm5348 prism_rtl::Turn::More(Rc::new(OutTyOf { lx: lx.clone(), t: p_.clone() }));
            }
            {
                let lx = lx.clone();
                let ps = ps.clone();
                call_value(each_job(ps.clone(), {
                    let lx = lx.clone();
                    Rc::new(move |p0: crate::check::types::Ty| {
                        let lx = lx.clone();
                        entered(once_job(move || {
                            let p_ = p0;
                            prism_rtl::Turn::More(Rc::new(OutTyOf { lx: lx.clone(), t: p_.clone() }))
                        }))
                    }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::lower::model::OutTy>>>
                }), move |each_5408: Array<crate::lower::model::OutTy>| prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutTuple(each_5408)))
            }
        }
    }
}

/// `Start RustTyOfParams, x`: what the function value is when passed to `@Run`.
pub fn start_rust_ty_of_params(lx: crate::lower::Lx, ps: Array<crate::check::types::Ty>) -> Rc<dyn prism_rtl::Job<crate::lower::model::OutTy>> {
    Rc::new(RustTyOfParams { lx, ps })
}

/// ```prism
/// NamedTy: unbounded fn Lx, Text, [OutTy] -> OutTy
/// ```
pub fn named_ty(lx: &crate::lower::Lx, n: &Text, args: &Array<crate::lower::model::OutTy>) -> crate::lower::model::OutTy {
    match get(&lx.g.types, n) {
        Some(ti) => match &ti.body {
            crate::check::env::TyBody::BAlias(a) => out_ty_of(lx, a),
            crate::check::env::TyBody::BRowKind => if n == &Text::lit("Prelude.Fault") {
                crate::lower::model::OutTy::OutPod
            } else {
                crate::lower::model::OutTy::OutNamed(crate::lower::path_in(lx, &ti.home, &crate::lower::camel(&crate::check::types::bare_name(n))), Array::new())
            },
            _ => crate::lower::model::OutTy::OutNamed(crate::lower::path_in(lx, &ti.home, &crate::lower::camel(&crate::check::types::bare_name(n))), args.clone()),
        },
        None => if crate::check::env::has_key(&lx.g.families, n) {
            crate::lower::model::OutTy::OutPod
        } else {
            crate::lower::model::OutTy::OutNamed(crate::lower::camel(&crate::check::types::bare_name(n)), args.clone())
        },
    }
}

/// The step machine of `NamedTy`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// NamedTy: unbounded fn Lx, Text, [OutTy] -> OutTy
/// ```
pub struct NamedTy {
    pub lx: crate::lower::Lx,
    pub n: Text,
    pub args: Array<crate::lower::model::OutTy>,
}

impl prism_rtl::Job<crate::lower::model::OutTy> for NamedTy {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::OutTy> {
        let lx = &self.lx;
        let n = &self.n;
        let args = &self.args;
        match get(&lx.g.types, n) {
            Some(ti) => match &ti.body {
                crate::check::env::TyBody::BAlias(a) => prism_rtl::Turn::More(Rc::new(OutTyOf { lx: lx.clone(), t: a.clone() })),
                crate::check::env::TyBody::BRowKind => if n == &Text::lit("Prelude.Fault") {
                    prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutPod)
                } else {
                    prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutNamed(crate::lower::path_in(lx, &ti.home, &crate::lower::camel(&crate::check::types::bare_name(n))), Array::new()))
                },
                _ => prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutNamed(crate::lower::path_in(lx, &ti.home, &crate::lower::camel(&crate::check::types::bare_name(n))), args.clone())),
            },
            None => if crate::check::env::has_key(&lx.g.families, n) {
                prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutPod)
            } else {
                prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutNamed(crate::lower::camel(&crate::check::types::bare_name(n)), args.clone()))
            },
        }
    }
}

/// `Start NamedTy, x`: what the function value is when passed to `@Run`.
pub fn start_named_ty(lx: crate::lower::Lx, n: Text, args: Array<crate::lower::model::OutTy>) -> Rc<dyn prism_rtl::Job<crate::lower::model::OutTy>> {
    Rc::new(NamedTy { lx, n, args })
}

/// ```prism
/// Peel: fn Ty -> Ty
/// ```
pub fn peel(t: &crate::check::types::Ty) -> crate::check::types::Ty {
    match t {
        crate::check::types::Ty::TySig(m6146_0_0, i) if (m6146_0_0 == &Text::lit("$")) => peel(&**i),
        crate::check::types::Ty::TySig(m6146_1_0, i) if (m6146_1_0 == &Text::lit("!")) => peel(&**i),
        crate::check::types::Ty::TySig(m6146_2_0, i) if (m6146_2_0 == &Text::lit("&")) => peel(&**i),
        _ => t.clone(),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// OutOf: fn Ty -> Ty
/// ```
pub fn out_of(t: &crate::check::types::Ty) -> crate::check::types::Ty {
    match t {
        crate::check::types::Ty::TyAt(i, _) => peel(&**i),
        _ => peel(t),
    }
}

/// ```prism
/// IsBundle: fn Ty -> Bool
/// ```
pub fn is_bundle(t: &crate::check::types::Ty) -> bool {
    match t {
        crate::check::types::Ty::TyTuple(ts) => fold(ts, &false, &(|found: &bool, x: &crate::check::types::Ty| ((*found || (&layer_of(x) == &Layer::LyEv)) || (&layer_of(x) == &Layer::LyDyn)) || is_bundle(x))),
        _ => false,
    }
}

/// ```prism
/// LayerOf: fn Ty -> Layer
/// ```
pub fn layer_of(t: &crate::check::types::Ty) -> Layer {
    match t {
        crate::check::types::Ty::TySig(m6991_0_0, _) if (m6991_0_0 == &Text::lit("$")) => Layer::LyDyn,
        crate::check::types::Ty::TySig(m6991_1_0, _) if (m6991_1_0 == &Text::lit("!")) => Layer::LyEv,
        crate::check::types::Ty::TySig(m6991_2_0, i) if (m6991_2_0 == &Text::lit("&")) => layer_of(&**i),
        crate::check::types::Ty::TyAt(_, _) => Layer::LyBlueprint,
        _ => Layer::LyPlain,
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// Layouts: unbounded fn G -> (Text ==> [Bool])
/// ```
pub fn layouts(g: &crate::check::env::G) -> Map<Text, Array<bool>> {
    run_to_end(fold_job(values(&g.ctors), Map::new(), {
        let g = g.clone();
        Rc::new(move |(p0, p1): (Map<Text, Array<bool>>, crate::check::env::CtorInfo)| {
            let g = g.clone();
            entered(once_job(move || {
                let m = p0;
                let c = p1;
                call_value(each_job(c.args.clone(), {
                    let g = g.clone();
                    let c = c.clone();
                    Rc::new(move |p0: crate::check::types::Ty| {
                        let g = g.clone();
                        let c = c.clone();
                        entered(once_job(move || {
                            let a = p0;
                            prism_rtl::Turn::More(Rc::new(Reaches { g: g.clone(), t: a.clone(), target: c.owner.clone(), seen: Array::new() }))
                        }))
                    }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<bool>>>
                }), move |each_7499: Array<bool>| prism_rtl::Turn::Finished(insert(&m, &c.name, &each_7499)))
            }))
        }) as Rc<dyn Fn((Map<Text, Array<bool>>, crate::check::env::CtorInfo)) -> Rc<dyn prism_rtl::Job<Map<Text, Array<bool>>>>>
    }))
}

/// The step machine of `Layouts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Layouts: unbounded fn G -> (Text ==> [Bool])
/// ```
pub struct Layouts {
    pub g: crate::check::env::G,
}

impl prism_rtl::Job<Map<Text, Array<bool>>> for Layouts {
    fn cycle(&self) -> prism_rtl::Turn<Map<Text, Array<bool>>> {
        let g = &self.g;
        fold_job(values(&g.ctors), Map::new(), {
            let g = g.clone();
            Rc::new(move |(p0, p1): (Map<Text, Array<bool>>, crate::check::env::CtorInfo)| {
                let g = g.clone();
                entered(once_job(move || {
                    let m = p0;
                    let c = p1;
                    call_value(each_job(c.args.clone(), {
                        let g = g.clone();
                        let c = c.clone();
                        Rc::new(move |p0: crate::check::types::Ty| {
                            let g = g.clone();
                            let c = c.clone();
                            entered(once_job(move || {
                                let a = p0;
                                prism_rtl::Turn::More(Rc::new(Reaches { g: g.clone(), t: a.clone(), target: c.owner.clone(), seen: Array::new() }))
                            }))
                        }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<bool>>>
                    }), move |each_7499: Array<bool>| prism_rtl::Turn::Finished(insert(&m, &c.name, &each_7499)))
                }))
            }) as Rc<dyn Fn((Map<Text, Array<bool>>, crate::check::env::CtorInfo)) -> Rc<dyn prism_rtl::Job<Map<Text, Array<bool>>>>>
        }).cycle()
    }
}

/// `Start Layouts, x`: what the function value is when passed to `@Run`.
pub fn start_layouts(g: crate::check::env::G) -> Rc<dyn prism_rtl::Job<Map<Text, Array<bool>>>> {
    Rc::new(Layouts { g })
}

/// ```prism
/// Reaches: unbounded fn G, Ty, Text, [Text] -> Bool
/// ```
pub fn reaches(g: &crate::check::env::G, t: &crate::check::types::Ty, target: &Text, seen: &Array<Text>) -> bool {
    match t {
        crate::check::types::Ty::TyCon(n, args) => if n == target {
            true
        } else {
            if crate::check::types::has_text(seen, n) {
                false
            } else {
                if run_to_end(fold_job(args.clone(), false, {
                    let g = g.clone();
                    let target = target.clone();
                    let seen = seen.clone();
                    Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| {
                        let g = g.clone();
                        let target = target.clone();
                        let seen = seen.clone();
                        entered(once_job(move || {
                            let f = p0;
                            let a = p1;
                            prism_rtl::Turn::Finished(f || reaches(&g, &a, &target, &seen))
                        }))
                    }) as Rc<dyn Fn((bool, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<bool>>>
                })) {
                    true
                } else {
                    match get(&g.types, n) {
                        Some(ti) => match &ti.body {
                            crate::check::env::TyBody::BRecord(fs) => run_to_end(fold_job(fs.clone(), false, {
                                let g = g.clone();
                                let target = target.clone();
                                let seen = seen.clone();
                                let n = n.clone();
                                Rc::new(move |(p0, p1): (bool, (Text, crate::check::types::Ty))| {
                                    let g = g.clone();
                                    let target = target.clone();
                                    let seen = seen.clone();
                                    let n = n.clone();
                                    entered(once_job(move || {
                                        let f = p0;
                                        let (_, ft) = p1;
                                        prism_rtl::Turn::Finished(f || reaches(&g, &ft, &target, &push(&seen, &n)))
                                    }))
                                }) as Rc<dyn Fn((bool, (Text, crate::check::types::Ty))) -> Rc<dyn prism_rtl::Job<bool>>>
                            })),
                            crate::check::env::TyBody::BChoice(cs) => run_to_end(fold_job(cs.clone(), false, {
                                let g = g.clone();
                                let target = target.clone();
                                let seen = seen.clone();
                                let n = n.clone();
                                Rc::new(move |(p0, p1): (bool, (Text, Array<crate::check::types::Ty>))| {
                                    let g = g.clone();
                                    let target = target.clone();
                                    let seen = seen.clone();
                                    let n = n.clone();
                                    entered(once_job(move || {
                                        let f = p0;
                                        let (_, ats) = p1;
                                        prism_rtl::Turn::Finished(f || run_to_end(fold_job(ats.clone(), false, {
                                            let g = g.clone();
                                            let target = target.clone();
                                            let seen = seen.clone();
                                            let n = n.clone();
                                            Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| {
                                                let g = g.clone();
                                                let target = target.clone();
                                                let seen = seen.clone();
                                                let n = n.clone();
                                                entered(once_job(move || {
                                                    let f2 = p0;
                                                    let at_ = p1;
                                                    prism_rtl::Turn::Finished(f2 || reaches(&g, &at_, &target, &push(&seen, &n)))
                                                }))
                                            }) as Rc<dyn Fn((bool, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<bool>>>
                                        })))
                                    }))
                                }) as Rc<dyn Fn((bool, (Text, Array<crate::check::types::Ty>))) -> Rc<dyn prism_rtl::Job<bool>>>
                            })),
                            crate::check::env::TyBody::BAlias(a) => reaches(g, a, target, &push(seen, n)),
                            _ => false,
                        },
                        None => false,
                    }
                }
            }
        },
        crate::check::types::Ty::TySig(m7629_1_0, i) if (m7629_1_0 == &Text::lit("?")) => reaches(g, &**i, target, seen),
        crate::check::types::Ty::TySig(m7629_2_0, i) if (m7629_2_0 == &Text::lit("~")) => reaches(g, &**i, target, seen),
        crate::check::types::Ty::TyTuple(ts) => run_to_end(fold_job(ts.clone(), false, {
            let g = g.clone();
            let target = target.clone();
            let seen = seen.clone();
            Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| {
                let g = g.clone();
                let target = target.clone();
                let seen = seen.clone();
                entered(once_job(move || {
                    let f = p0;
                    let a = p1;
                    prism_rtl::Turn::Finished(f || reaches(&g, &a, &target, &seen))
                }))
            }) as Rc<dyn Fn((bool, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<bool>>>
        })),
        _ => false,
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `Reaches`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Reaches: unbounded fn G, Ty, Text, [Text] -> Bool
/// ```
pub struct Reaches {
    pub g: crate::check::env::G,
    pub t: crate::check::types::Ty,
    pub target: Text,
    pub seen: Array<Text>,
}

impl prism_rtl::Job<bool> for Reaches {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let g = &self.g;
        let t = &self.t;
        let target = &self.target;
        let seen = &self.seen;
        match t {
            crate::check::types::Ty::TyCon(n, args) => if n == target {
                prism_rtl::Turn::Finished(true)
            } else {
                if crate::check::types::has_text(seen, n) {
                    prism_rtl::Turn::Finished(false)
                } else {
                    {
                        let args = args.clone();
                        let g = g.clone();
                        let n = n.clone();
                        let seen = seen.clone();
                        let target = target.clone();
                        call_value(fold_job(args.clone(), false, {
                            let g = g.clone();
                            let target = target.clone();
                            let seen = seen.clone();
                            Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| {
                                let g = g.clone();
                                let target = target.clone();
                                let seen = seen.clone();
                                entered(once_job(move || {
                                    let f = p0;
                                    let a = p1;
                                    prism_rtl::Turn::Finished(f || reaches(&g, &a, &target, &seen))
                                }))
                            }) as Rc<dyn Fn((bool, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<bool>>>
                        }), move |fold_7743: bool| if fold_7743 {
                            prism_rtl::Turn::Finished(true)
                        } else {
                            match get(&g.types, &n) {
                                Some(ti) => match &ti.body {
                                    crate::check::env::TyBody::BRecord(fs) => fold_job(fs.clone(), false, {
                                        let g = g.clone();
                                        let target = target.clone();
                                        let seen = seen.clone();
                                        let n = n.clone();
                                        Rc::new(move |(p0, p1): (bool, (Text, crate::check::types::Ty))| {
                                            let g = g.clone();
                                            let target = target.clone();
                                            let seen = seen.clone();
                                            let n = n.clone();
                                            entered(once_job(move || {
                                                let f = p0;
                                                let (_, ft) = p1;
                                                prism_rtl::Turn::Finished(f || reaches(&g, &ft, &target, &push(&seen, &n)))
                                            }))
                                        }) as Rc<dyn Fn((bool, (Text, crate::check::types::Ty))) -> Rc<dyn prism_rtl::Job<bool>>>
                                    }).cycle(),
                                    crate::check::env::TyBody::BChoice(cs) => fold_job(cs.clone(), false, {
                                        let g = g.clone();
                                        let target = target.clone();
                                        let seen = seen.clone();
                                        let n = n.clone();
                                        Rc::new(move |(p0, p1): (bool, (Text, Array<crate::check::types::Ty>))| {
                                            let g = g.clone();
                                            let target = target.clone();
                                            let seen = seen.clone();
                                            let n = n.clone();
                                            entered(once_job(move || {
                                                let f = p0;
                                                let (_, ats) = p1;
                                                prism_rtl::Turn::Finished(f || run_to_end(fold_job(ats.clone(), false, {
                                                    let g = g.clone();
                                                    let target = target.clone();
                                                    let seen = seen.clone();
                                                    let n = n.clone();
                                                    Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| {
                                                        let g = g.clone();
                                                        let target = target.clone();
                                                        let seen = seen.clone();
                                                        let n = n.clone();
                                                        entered(once_job(move || {
                                                            let f2 = p0;
                                                            let at_ = p1;
                                                            prism_rtl::Turn::Finished(f2 || reaches(&g, &at_, &target, &push(&seen, &n)))
                                                        }))
                                                    }) as Rc<dyn Fn((bool, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<bool>>>
                                                })))
                                            }))
                                        }) as Rc<dyn Fn((bool, (Text, Array<crate::check::types::Ty>))) -> Rc<dyn prism_rtl::Job<bool>>>
                                    }).cycle(),
                                    crate::check::env::TyBody::BAlias(a) => prism_rtl::Turn::More(Rc::new(Reaches { g: g.clone(), t: a.clone(), target: target.clone(), seen: push(&seen, &n) })),
                                    _ => prism_rtl::Turn::Finished(false),
                                },
                                None => prism_rtl::Turn::Finished(false),
                            }
                        })
                    }
                }
            },
            crate::check::types::Ty::TySig(m7629_1_0, i) if (m7629_1_0 == &Text::lit("?")) => prism_rtl::Turn::More(Rc::new(Reaches { g: g.clone(), t: (**i).clone(), target: target.clone(), seen: seen.clone() })),
            crate::check::types::Ty::TySig(m7629_2_0, i) if (m7629_2_0 == &Text::lit("~")) => prism_rtl::Turn::More(Rc::new(Reaches { g: g.clone(), t: (**i).clone(), target: target.clone(), seen: seen.clone() })),
            crate::check::types::Ty::TyTuple(ts) => fold_job(ts.clone(), false, {
                let g = g.clone();
                let target = target.clone();
                let seen = seen.clone();
                Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| {
                    let g = g.clone();
                    let target = target.clone();
                    let seen = seen.clone();
                    entered(once_job(move || {
                        let f = p0;
                        let a = p1;
                        prism_rtl::Turn::Finished(f || reaches(&g, &a, &target, &seen))
                    }))
                }) as Rc<dyn Fn((bool, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<bool>>>
            }).cycle(),
            _ => prism_rtl::Turn::Finished(false),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start Reaches, x`: what the function value is when passed to `@Run`.
pub fn start_reaches(g: crate::check::env::G, t: crate::check::types::Ty, target: Text, seen: Array<Text>) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(Reaches { g, t, target, seen })
}

/// ```prism
/// RcField: fn Lx, Text, Nat -> Bool
/// ```
pub fn rc_field(lx: &crate::lower::Lx, ctor: &Text, i: &Nat) -> bool {
    or(&index(&or(&get(&lx.layouts, ctor), &Array::new()), i), &false)
}

/// ```prism
/// Floaty: unbounded fn G, Ty, [Text] -> Bool
/// ```
pub fn floaty(g: &crate::check::env::G, t: &crate::check::types::Ty, seen: &Array<Text>) -> bool {
    match t {
        crate::check::types::Ty::TyCon(m8733_0_0, m8733_0_1) if (m8733_0_0 == &Text::lit("Float")) && (m8733_0_1.len() == 0) => true,
        crate::check::types::Ty::TyCon(n, args) => if run_to_end(fold_job(args.clone(), false, {
            let g = g.clone();
            let seen = seen.clone();
            Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| {
                let g = g.clone();
                let seen = seen.clone();
                entered(once_job(move || {
                    let f = p0;
                    let a = p1;
                    prism_rtl::Turn::Finished(f || floaty(&g, &a, &seen))
                }))
            }) as Rc<dyn Fn((bool, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<bool>>>
        })) {
            true
        } else {
            if crate::check::types::has_text(seen, n) {
                false
            } else {
                match get(&g.types, n) {
                    Some(ti) => match &ti.body {
                        crate::check::env::TyBody::BRecord(fs) => run_to_end(fold_job(fs.clone(), false, {
                            let g = g.clone();
                            let seen = seen.clone();
                            let n = n.clone();
                            Rc::new(move |(p0, p1): (bool, (Text, crate::check::types::Ty))| {
                                let g = g.clone();
                                let seen = seen.clone();
                                let n = n.clone();
                                entered(once_job(move || {
                                    let f = p0;
                                    let (_, ft) = p1;
                                    prism_rtl::Turn::Finished(f || floaty(&g, &ft, &push(&seen, &n)))
                                }))
                            }) as Rc<dyn Fn((bool, (Text, crate::check::types::Ty))) -> Rc<dyn prism_rtl::Job<bool>>>
                        })),
                        crate::check::env::TyBody::BChoice(cs) => run_to_end(fold_job(cs.clone(), false, {
                            let g = g.clone();
                            let seen = seen.clone();
                            let n = n.clone();
                            Rc::new(move |(p0, p1): (bool, (Text, Array<crate::check::types::Ty>))| {
                                let g = g.clone();
                                let seen = seen.clone();
                                let n = n.clone();
                                entered(once_job(move || {
                                    let f = p0;
                                    let (_, ats) = p1;
                                    prism_rtl::Turn::Finished(f || run_to_end(fold_job(ats.clone(), false, {
                                        let g = g.clone();
                                        let seen = seen.clone();
                                        let n = n.clone();
                                        Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| {
                                            let g = g.clone();
                                            let seen = seen.clone();
                                            let n = n.clone();
                                            entered(once_job(move || {
                                                let f2 = p0;
                                                let at_ = p1;
                                                prism_rtl::Turn::Finished(f2 || floaty(&g, &at_, &push(&seen, &n)))
                                            }))
                                        }) as Rc<dyn Fn((bool, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<bool>>>
                                    })))
                                }))
                            }) as Rc<dyn Fn((bool, (Text, Array<crate::check::types::Ty>))) -> Rc<dyn prism_rtl::Job<bool>>>
                        })),
                        _ => false,
                    },
                    None => false,
                }
            }
        },
        crate::check::types::Ty::TySig(_, i) => floaty(g, &**i, seen),
        crate::check::types::Ty::TyTuple(ts) => run_to_end(fold_job(ts.clone(), false, {
            let g = g.clone();
            let seen = seen.clone();
            Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| {
                let g = g.clone();
                let seen = seen.clone();
                entered(once_job(move || {
                    let f = p0;
                    let a = p1;
                    prism_rtl::Turn::Finished(f || floaty(&g, &a, &seen))
                }))
            }) as Rc<dyn Fn((bool, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<bool>>>
        })),
        crate::check::types::Ty::TyArray(e) => floaty(g, &**e, seen),
        crate::check::types::Ty::TyMap(k, v_) => floaty(g, &**k, seen) || floaty(g, &**v_, seen),
        _ => false,
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `Floaty`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Floaty: unbounded fn G, Ty, [Text] -> Bool
/// ```
pub struct Floaty {
    pub g: crate::check::env::G,
    pub t: crate::check::types::Ty,
    pub seen: Array<Text>,
}

impl prism_rtl::Job<bool> for Floaty {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let g = &self.g;
        let t = &self.t;
        let seen = &self.seen;
        match t {
            crate::check::types::Ty::TyCon(m8733_0_0, m8733_0_1) if (m8733_0_0 == &Text::lit("Float")) && (m8733_0_1.len() == 0) => prism_rtl::Turn::Finished(true),
            crate::check::types::Ty::TyCon(n, args) => {
                let args = args.clone();
                let g = g.clone();
                let n = n.clone();
                let seen = seen.clone();
                call_value(fold_job(args.clone(), false, {
                    let g = g.clone();
                    let seen = seen.clone();
                    Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| {
                        let g = g.clone();
                        let seen = seen.clone();
                        entered(once_job(move || {
                            let f = p0;
                            let a = p1;
                            prism_rtl::Turn::Finished(f || floaty(&g, &a, &seen))
                        }))
                    }) as Rc<dyn Fn((bool, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<bool>>>
                }), move |fold_8802: bool| if fold_8802 {
                    prism_rtl::Turn::Finished(true)
                } else {
                    if crate::check::types::has_text(&seen, &n) {
                        prism_rtl::Turn::Finished(false)
                    } else {
                        match get(&g.types, &n) {
                            Some(ti) => match &ti.body {
                                crate::check::env::TyBody::BRecord(fs) => fold_job(fs.clone(), false, {
                                    let g = g.clone();
                                    let seen = seen.clone();
                                    let n = n.clone();
                                    Rc::new(move |(p0, p1): (bool, (Text, crate::check::types::Ty))| {
                                        let g = g.clone();
                                        let seen = seen.clone();
                                        let n = n.clone();
                                        entered(once_job(move || {
                                            let f = p0;
                                            let (_, ft) = p1;
                                            prism_rtl::Turn::Finished(f || floaty(&g, &ft, &push(&seen, &n)))
                                        }))
                                    }) as Rc<dyn Fn((bool, (Text, crate::check::types::Ty))) -> Rc<dyn prism_rtl::Job<bool>>>
                                }).cycle(),
                                crate::check::env::TyBody::BChoice(cs) => fold_job(cs.clone(), false, {
                                    let g = g.clone();
                                    let seen = seen.clone();
                                    let n = n.clone();
                                    Rc::new(move |(p0, p1): (bool, (Text, Array<crate::check::types::Ty>))| {
                                        let g = g.clone();
                                        let seen = seen.clone();
                                        let n = n.clone();
                                        entered(once_job(move || {
                                            let f = p0;
                                            let (_, ats) = p1;
                                            prism_rtl::Turn::Finished(f || run_to_end(fold_job(ats.clone(), false, {
                                                let g = g.clone();
                                                let seen = seen.clone();
                                                let n = n.clone();
                                                Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| {
                                                    let g = g.clone();
                                                    let seen = seen.clone();
                                                    let n = n.clone();
                                                    entered(once_job(move || {
                                                        let f2 = p0;
                                                        let at_ = p1;
                                                        prism_rtl::Turn::Finished(f2 || floaty(&g, &at_, &push(&seen, &n)))
                                                    }))
                                                }) as Rc<dyn Fn((bool, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<bool>>>
                                            })))
                                        }))
                                    }) as Rc<dyn Fn((bool, (Text, Array<crate::check::types::Ty>))) -> Rc<dyn prism_rtl::Job<bool>>>
                                }).cycle(),
                                _ => prism_rtl::Turn::Finished(false),
                            },
                            None => prism_rtl::Turn::Finished(false),
                        }
                    }
                })
            },
            crate::check::types::Ty::TySig(_, i) => prism_rtl::Turn::More(Rc::new(Floaty { g: g.clone(), t: (**i).clone(), seen: seen.clone() })),
            crate::check::types::Ty::TyTuple(ts) => fold_job(ts.clone(), false, {
                let g = g.clone();
                let seen = seen.clone();
                Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| {
                    let g = g.clone();
                    let seen = seen.clone();
                    entered(once_job(move || {
                        let f = p0;
                        let a = p1;
                        prism_rtl::Turn::Finished(f || floaty(&g, &a, &seen))
                    }))
                }) as Rc<dyn Fn((bool, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<bool>>>
            }).cycle(),
            crate::check::types::Ty::TyArray(e) => prism_rtl::Turn::More(Rc::new(Floaty { g: g.clone(), t: (**e).clone(), seen: seen.clone() })),
            crate::check::types::Ty::TyMap(k, v_) => {
                let g = g.clone();
                let k = (**k).clone();
                let seen = seen.clone();
                let v_ = (**v_).clone();
                call_then(start_floaty(g.clone(), k.clone(), seen.clone()), move |floaty_9402: bool| prism_rtl::Turn::Finished(floaty_9402 || floaty(&g, &v_, &seen)))
            },
            _ => prism_rtl::Turn::Finished(false),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start Floaty, x`: what the function value is when passed to `@Run`.
pub fn start_floaty(g: crate::check::env::G, t: crate::check::types::Ty, seen: Array<Text>) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(Floaty { g, t, seen })
}

/// ```prism
/// Podable: unbounded fn OutTy -> Bool
/// ```
pub fn podable(t: &crate::lower::model::OutTy) -> bool {
    match t {
        crate::lower::model::OutTy::OutFn(_, _) => false,
        crate::lower::model::OutTy::OutJobFn(_, _) => false,
        crate::lower::model::OutTy::OutJob(_) => false,
        crate::lower::model::OutTy::OutEvent(_) => false,
        crate::lower::model::OutTy::OutDyn(_) => false,
        crate::lower::model::OutTy::OutShowAny => false,
        crate::lower::model::OutTy::OutLive(_) => false,
        crate::lower::model::OutTy::OutUnknown(_) => false,
        crate::lower::model::OutTy::OutGen(_) => true,
        crate::lower::model::OutTy::OutNamed(_, args) => run_to_end(fold_job(args.clone(), true, Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| entered(once_job(move || {
            let ok_ = p0;
            let a = p1;
            prism_rtl::Turn::Finished(ok_ && podable(&a))
        }))) as Rc<dyn Fn((bool, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<bool>>>)),
        crate::lower::model::OutTy::OutOpt(i) => podable(&**i),
        crate::lower::model::OutTy::OutRes(i) => podable(&**i),
        crate::lower::model::OutTy::OutRc(i) => podable(&**i),
        crate::lower::model::OutTy::OutTuple(ts) => run_to_end(fold_job(ts.clone(), true, Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| entered(once_job(move || {
            let ok_ = p0;
            let a = p1;
            prism_rtl::Turn::Finished(ok_ && podable(&a))
        }))) as Rc<dyn Fn((bool, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<bool>>>)),
        crate::lower::model::OutTy::OutArray(e) => podable(&**e),
        crate::lower::model::OutTy::OutMap(k, v_) => podable(&**k) && podable(&**v_),
        _ => true,
    }
}

/// The step machine of `Podable`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Podable: unbounded fn OutTy -> Bool
/// ```
pub struct Podable {
    pub t: crate::lower::model::OutTy,
}

impl prism_rtl::Job<bool> for Podable {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let t = &self.t;
        match t {
            crate::lower::model::OutTy::OutFn(_, _) => prism_rtl::Turn::Finished(false),
            crate::lower::model::OutTy::OutJobFn(_, _) => prism_rtl::Turn::Finished(false),
            crate::lower::model::OutTy::OutJob(_) => prism_rtl::Turn::Finished(false),
            crate::lower::model::OutTy::OutEvent(_) => prism_rtl::Turn::Finished(false),
            crate::lower::model::OutTy::OutDyn(_) => prism_rtl::Turn::Finished(false),
            crate::lower::model::OutTy::OutShowAny => prism_rtl::Turn::Finished(false),
            crate::lower::model::OutTy::OutLive(_) => prism_rtl::Turn::Finished(false),
            crate::lower::model::OutTy::OutUnknown(_) => prism_rtl::Turn::Finished(false),
            crate::lower::model::OutTy::OutGen(_) => prism_rtl::Turn::Finished(true),
            crate::lower::model::OutTy::OutNamed(_, args) => fold_job(args.clone(), true, Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| entered(once_job(move || {
                let ok_ = p0;
                let a = p1;
                prism_rtl::Turn::Finished(ok_ && podable(&a))
            }))) as Rc<dyn Fn((bool, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<bool>>>).cycle(),
            crate::lower::model::OutTy::OutOpt(i) => prism_rtl::Turn::More(Rc::new(Podable { t: (**i).clone() })),
            crate::lower::model::OutTy::OutRes(i) => prism_rtl::Turn::More(Rc::new(Podable { t: (**i).clone() })),
            crate::lower::model::OutTy::OutRc(i) => prism_rtl::Turn::More(Rc::new(Podable { t: (**i).clone() })),
            crate::lower::model::OutTy::OutTuple(ts) => fold_job(ts.clone(), true, Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| entered(once_job(move || {
                let ok_ = p0;
                let a = p1;
                prism_rtl::Turn::Finished(ok_ && podable(&a))
            }))) as Rc<dyn Fn((bool, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<bool>>>).cycle(),
            crate::lower::model::OutTy::OutArray(e) => prism_rtl::Turn::More(Rc::new(Podable { t: (**e).clone() })),
            crate::lower::model::OutTy::OutMap(k, v_) => {
                let k = (**k).clone();
                let v_ = (**v_).clone();
                call_then(start_podable(k.clone()), move |podable_10077: bool| prism_rtl::Turn::Finished(podable_10077 && podable(&v_)))
            },
            _ => prism_rtl::Turn::Finished(true),
        }
    }
}

/// `Start Podable, x`: what the function value is when passed to `@Run`.
pub fn start_podable(t: crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(Podable { t })
}

/// ```prism
/// RuntimeEq: unbounded fn OutTy -> Bool
/// ```
pub fn runtime_eq(t: &crate::lower::model::OutTy) -> bool {
    match t {
        crate::lower::model::OutTy::OutDyn(_) => true,
        crate::lower::model::OutTy::OutNamed(_, args) => run_to_end(fold_job(args.clone(), true, Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| entered(once_job(move || {
            let ok_ = p0;
            let a = p1;
            prism_rtl::Turn::Finished(ok_ && runtime_eq(&a))
        }))) as Rc<dyn Fn((bool, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<bool>>>)),
        crate::lower::model::OutTy::OutOpt(i) => runtime_eq(&**i),
        crate::lower::model::OutTy::OutRes(i) => runtime_eq(&**i),
        crate::lower::model::OutTy::OutRc(i) => runtime_eq(&**i),
        crate::lower::model::OutTy::OutTuple(ts) => run_to_end(fold_job(ts.clone(), true, Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| entered(once_job(move || {
            let ok_ = p0;
            let a = p1;
            prism_rtl::Turn::Finished(ok_ && runtime_eq(&a))
        }))) as Rc<dyn Fn((bool, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<bool>>>)),
        crate::lower::model::OutTy::OutArray(e) => runtime_eq(&**e),
        crate::lower::model::OutTy::OutMap(k, v_) => runtime_eq(&**k) && runtime_eq(&**v_),
        other => podable(other),
    }
}

/// The step machine of `RuntimeEq`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RuntimeEq: unbounded fn OutTy -> Bool
/// ```
pub struct RuntimeEq {
    pub t: crate::lower::model::OutTy,
}

impl prism_rtl::Job<bool> for RuntimeEq {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let t = &self.t;
        match t {
            crate::lower::model::OutTy::OutDyn(_) => prism_rtl::Turn::Finished(true),
            crate::lower::model::OutTy::OutNamed(_, args) => fold_job(args.clone(), true, Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| entered(once_job(move || {
                let ok_ = p0;
                let a = p1;
                prism_rtl::Turn::Finished(ok_ && runtime_eq(&a))
            }))) as Rc<dyn Fn((bool, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<bool>>>).cycle(),
            crate::lower::model::OutTy::OutOpt(i) => prism_rtl::Turn::More(Rc::new(RuntimeEq { t: (**i).clone() })),
            crate::lower::model::OutTy::OutRes(i) => prism_rtl::Turn::More(Rc::new(RuntimeEq { t: (**i).clone() })),
            crate::lower::model::OutTy::OutRc(i) => prism_rtl::Turn::More(Rc::new(RuntimeEq { t: (**i).clone() })),
            crate::lower::model::OutTy::OutTuple(ts) => fold_job(ts.clone(), true, Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| entered(once_job(move || {
                let ok_ = p0;
                let a = p1;
                prism_rtl::Turn::Finished(ok_ && runtime_eq(&a))
            }))) as Rc<dyn Fn((bool, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<bool>>>).cycle(),
            crate::lower::model::OutTy::OutArray(e) => prism_rtl::Turn::More(Rc::new(RuntimeEq { t: (**e).clone() })),
            crate::lower::model::OutTy::OutMap(k, v_) => {
                let k = (**k).clone();
                let v_ = (**v_).clone();
                call_then(start_runtime_eq(k.clone()), move |runtime_eq_10709: bool| prism_rtl::Turn::Finished(runtime_eq_10709 && runtime_eq(&v_)))
            },
            other => prism_rtl::Turn::More(Rc::new(Podable { t: other.clone() })),
        }
    }
}

/// `Start RuntimeEq, x`: what the function value is when passed to `@Run`.
pub fn start_runtime_eq(t: crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(RuntimeEq { t })
}

/// ```prism
/// HoldsDyn: unbounded fn OutTy -> Bool
/// ```
pub fn holds_dyn(t: &crate::lower::model::OutTy) -> bool {
    match t {
        crate::lower::model::OutTy::OutDyn(_) => true,
        crate::lower::model::OutTy::OutNamed(_, args) => run_to_end(fold_job(args.clone(), false, Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| entered(once_job(move || {
            let f = p0;
            let a = p1;
            prism_rtl::Turn::Finished(f || holds_dyn(&a))
        }))) as Rc<dyn Fn((bool, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<bool>>>)),
        crate::lower::model::OutTy::OutOpt(i) => holds_dyn(&**i),
        crate::lower::model::OutTy::OutRes(i) => holds_dyn(&**i),
        crate::lower::model::OutTy::OutRc(i) => holds_dyn(&**i),
        crate::lower::model::OutTy::OutTuple(ts) => run_to_end(fold_job(ts.clone(), false, Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| entered(once_job(move || {
            let f = p0;
            let a = p1;
            prism_rtl::Turn::Finished(f || holds_dyn(&a))
        }))) as Rc<dyn Fn((bool, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<bool>>>)),
        crate::lower::model::OutTy::OutArray(e) => holds_dyn(&**e),
        crate::lower::model::OutTy::OutMap(k, v_) => holds_dyn(&**k) || holds_dyn(&**v_),
        _ => false,
    }
}

/// The step machine of `HoldsDyn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// HoldsDyn: unbounded fn OutTy -> Bool
/// ```
pub struct HoldsDyn {
    pub t: crate::lower::model::OutTy,
}

impl prism_rtl::Job<bool> for HoldsDyn {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let t = &self.t;
        match t {
            crate::lower::model::OutTy::OutDyn(_) => prism_rtl::Turn::Finished(true),
            crate::lower::model::OutTy::OutNamed(_, args) => fold_job(args.clone(), false, Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| entered(once_job(move || {
                let f = p0;
                let a = p1;
                prism_rtl::Turn::Finished(f || holds_dyn(&a))
            }))) as Rc<dyn Fn((bool, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<bool>>>).cycle(),
            crate::lower::model::OutTy::OutOpt(i) => prism_rtl::Turn::More(Rc::new(HoldsDyn { t: (**i).clone() })),
            crate::lower::model::OutTy::OutRes(i) => prism_rtl::Turn::More(Rc::new(HoldsDyn { t: (**i).clone() })),
            crate::lower::model::OutTy::OutRc(i) => prism_rtl::Turn::More(Rc::new(HoldsDyn { t: (**i).clone() })),
            crate::lower::model::OutTy::OutTuple(ts) => fold_job(ts.clone(), false, Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| entered(once_job(move || {
                let f = p0;
                let a = p1;
                prism_rtl::Turn::Finished(f || holds_dyn(&a))
            }))) as Rc<dyn Fn((bool, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<bool>>>).cycle(),
            crate::lower::model::OutTy::OutArray(e) => prism_rtl::Turn::More(Rc::new(HoldsDyn { t: (**e).clone() })),
            crate::lower::model::OutTy::OutMap(k, v_) => {
                let k = (**k).clone();
                let v_ = (**v_).clone();
                call_then(start_holds_dyn(k.clone()), move |holds_dyn_11171: bool| prism_rtl::Turn::Finished(holds_dyn_11171 || holds_dyn(&v_)))
            },
            _ => prism_rtl::Turn::Finished(false),
        }
    }
}

/// `Start HoldsDyn, x`: what the function value is when passed to `@Run`.
pub fn start_holds_dyn(t: crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(HoldsDyn { t })
}

/// ```prism
/// let emptyEnv
/// ```
pub fn empty_env() -> Env {
    Env { names: Map::new(), spans: Map::new(), uses: Map::new() }
}

/// ```prism
/// NameKeyAt: fn Lx, Env, SName, Range -> Text
/// ```
pub fn name_key_at(lx: &crate::lower::Lx, env: &Env, n: &crate::syntax::SName, span: &crate::syntax::Range) -> Text {
    match get(&lx.use_insts, &crate::lower::place_key(lx, span)) {
        Some(u) => or(&get(&env.uses, &Text::from(format!("{}#{}", &crate::check::env::sname_key(n), &show_text(&crate::lower::expr::inst_at(lx, &u))))), &crate::check::env::sname_key(n)),
        None => crate::check::env::sname_key(n),
    }
}

/// ```prism
/// WithInstances: fn Env, [Text] -> [Text]
/// ```
pub fn with_instances(env: &Env, names: &Array<Text>) -> Array<Text> {
    fold(names, names, &(|acc: &Array<Text>, n: &Text| append(acc, &filter(&keys(&env.names), &(|k: &Text| crate::syntax::lexer::chars::has_prefix(k, &Text::from(format!("{}#inst", n))))))))
}

/// ```prism
/// BindSpan: fn Env, Text, Vl -> Env
/// ```
pub fn bind_span(env: &Env, nkey: &Text, v_: &Vl) -> Env {
    let mut this: Env = env.clone();
    this.spans = insert(&this.spans, nkey, v_);
    this
}

/// ```prism
/// Bind: fn Env, Text, Bn -> Env
/// ```
pub fn bind(env: &Env, name: &Text, b: &Bn) -> Env {
    let mut this: Env = env.clone();
    this.names = insert(&this.names, name, b);
    this
}

/// ```prism
/// ValueTy: fn Vl -> OutTy
/// ```
pub fn value_ty(vl0: &Vl) -> crate::lower::model::OutTy {
    match vl0 {
        Vl::VlPlace(_, _, t) => t.clone(),
        Vl::VlOwned(_, t) => t.clone(),
    }
}

/// ```prism
/// LocalPlace: fn Ex, Holding, OutTy -> Vl
/// ```
pub fn local_place(x: &crate::lower::model::Ex, mode: &Holding, t: &crate::lower::model::OutTy) -> Vl {
    Vl::VlPlace(x.clone(), mode.clone(), t.clone())
}

/// ```prism
/// PlaceStem: fn Ex -> Text
/// ```
pub fn place_stem(x: &crate::lower::model::Ex) -> Text {
    match x {
        crate::lower::model::Ex::XVar(n) => n.clone(),
        crate::lower::model::Ex::XField(_, f) => f.clone(),
        crate::lower::model::Ex::XTarget(y) => place_stem(&**y),
        crate::lower::model::Ex::XPart(y, k) => Text::from(format!("{}_{}", &place_stem(&**y), k)),
        _ => Text::lit("place"),
    }
}

/// ```prism
/// OnSelf: fn Ex -> Bool
/// ```
pub fn on_self(x: &crate::lower::model::Ex) -> bool {
    'm14660: {
        if let crate::lower::model::Ex::XField(m14660_0_0, _) = x && let crate::lower::model::Ex::XSelf = &**m14660_0_0 {
            break 'm14660 true;
        }
        if let crate::lower::model::Ex::XField(y, _) = x {
            break 'm14660 on_self(&**y);
        }
        if let crate::lower::model::Ex::XPart(y, _) = x {
            break 'm14660 on_self(&**y);
        }
        if let crate::lower::model::Ex::XMethod(y, _, _) = x {
            break 'm14660 on_self(&**y);
        }
        if let crate::lower::model::Ex::XUpgrade(y) = x {
            break 'm14660 on_self(&**y);
        }
        false
    }
}

/// ```prism
/// ?ThroughParent: fn Ex -> ?Ex
/// ```
pub fn through_parent(x: &crate::lower::model::Ex) -> Option<crate::lower::model::Ex> {
    'm15064: {
        if let crate::lower::model::Ex::XField(m15064_0_0, m15064_0_1) = x && let crate::lower::model::Ex::XSelf = &**m15064_0_0 && (m15064_0_1 == &Text::lit("parent")) {
            break 'm15064 Some(crate::lower::model::Ex::XVar(Text::lit("parent")));
        }
        if let crate::lower::model::Ex::XField(y, f) = x {
            break 'm15064 match through_parent(&**y) {
                Some(z) => Some(crate::lower::model::Ex::XField(Rc::new(z), f.clone())),
                None => None,
            };
        }
        if let crate::lower::model::Ex::XPart(y, k) = x {
            break 'm15064 match through_parent(&**y) {
                Some(z) => Some(crate::lower::model::Ex::XPart(Rc::new(z), k.clone())),
                None => None,
            };
        }
        if let crate::lower::model::Ex::XMethod(y, m, xs) = x {
            break 'm15064 match through_parent(&**y) {
                Some(z) => Some(crate::lower::model::Ex::XMethod(Rc::new(z), m.clone(), xs.clone())),
                None => None,
            };
        }
        if let crate::lower::model::Ex::XUpgrade(y) = x {
            break 'm15064 match through_parent(&**y) {
                Some(z) => Some(crate::lower::model::Ex::XUpgrade(Rc::new(z))),
                None => None,
            };
        }
        None
    }
}

/// ```prism
/// Own: fn Vl -> Ex
/// ```
pub fn own(vl0: &Vl) -> crate::lower::model::Ex {
    match vl0 {
        Vl::VlPlace(x, Holding::RcRef, _) => crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XDeref(Rc::new(crate::lower::model::Ex::XDeref(Rc::new(x.clone())))))),
        Vl::VlPlace(x, Holding::RcOwned, _) => crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XDeref(Rc::new(x.clone())))),
        Vl::VlPlace(x, mode, t) => if is_copy(t) {
            copy(&Vl::VlPlace(x.clone(), mode.clone(), t.clone()))
        } else {
            crate::lower::model::Ex::XClone(Rc::new(x.clone()))
        },
        Vl::VlOwned(e, _) => e.clone(),
    }
}

/// ```prism
/// Ref: fn Vl -> Ex
/// ```
pub fn ref_(vl0: &Vl) -> crate::lower::model::Ex {
    match vl0 {
        Vl::VlPlace(x, Holding::ByRef, _) => x.clone(),
        Vl::VlPlace(x, Holding::RcRef, _) => crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XDeref(Rc::new(crate::lower::model::Ex::XDeref(Rc::new(x.clone())))))),
        Vl::VlPlace(x, Holding::RcOwned, _) => crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XDeref(Rc::new(x.clone())))),
        Vl::VlPlace(x, _, _) => crate::lower::model::Ex::XRef(Rc::new(x.clone())),
        Vl::VlOwned(e, _) => crate::lower::model::Ex::XRef(Rc::new(e.clone())),
    }
}

/// ```prism
/// Copy: fn Vl -> Ex
/// ```
pub fn copy(vl0: &Vl) -> crate::lower::model::Ex {
    match vl0 {
        Vl::VlPlace(x, Holding::ByRef, _) => crate::lower::model::Ex::XDeref(Rc::new(x.clone())),
        Vl::VlPlace(x, Holding::RcRef, _) => crate::lower::model::Ex::XDeref(Rc::new(crate::lower::model::Ex::XDeref(Rc::new(crate::lower::model::Ex::XDeref(Rc::new(x.clone())))))),
        Vl::VlPlace(x, _, _) => x.clone(),
        Vl::VlOwned(e, _) => e.clone(),
    }
}

/// ```prism
/// IsCopy: fn OutTy -> Bool
/// ```
pub fn is_copy(t: &crate::lower::model::OutTy) -> bool {
    ((((t == &crate::lower::model::OutTy::OutBool) || (t == &crate::lower::model::OutTy::OutFloat)) || (t == &crate::lower::model::OutTy::OutU8)) || (t == &crate::lower::model::OutTy::OutChar)) || (t == &crate::lower::model::OutTy::OutUnit)
}

/// ```prism
/// AsBool: fn Vl -> Ex
/// ```
pub fn as_bool(v_: &Vl) -> crate::lower::model::Ex {
    copy(v_)
}
