//! The module `Lower.Types`, from `target/bootstrap/src/prismc/lower/types.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// `Bn`:
///
/// ```prism
/// type Bn = choice:
/// ```
#[derive(Clone)]
pub enum Bn {
    BnLocal(crate::lower::model::Ex, Holding, crate::lower::model::OutTy),
    BnHold(Text, crate::lower::model::OutTy),
    BnDyn(crate::lower::model::Ex, Array<crate::lower::node_::Read>, crate::lower::model::OutTy),
    BnEv(crate::lower::node_::EvRef, crate::lower::model::OutTy),
    BnParts(Array<Option<Bn>>),
    BnWidget(crate::syntax::Expr, Env, Env, crate::lower::Lx),
    BnLocalFn(crate::syntax::decls::FnClause),
}

/// `Env`:
///
/// ```prism
/// type Env = record:
/// ```
#[derive(Clone)]
pub struct Env {
    pub names: Map<Text, Bn>,
    pub spans: Map<Text, Vl>,
    pub uses: Map<Text, Text>,
}

/// `Holding`:
///
/// ```prism
/// type Holding = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum Holding {
    ByRef,
    Owned,
    RcRef,
    RcOwned,
}

impl Show for Holding {
    fn show(&self, p: &mut Printer) {
        match self {
            Holding::ByRef => p.choice("ByRef", &[]),
            Holding::Owned => p.choice("Owned", &[]),
            Holding::RcRef => p.choice("RcRef", &[]),
            Holding::RcOwned => p.choice("RcOwned", &[]),
        }
    }
}

impl ToPod for Holding {
    fn to_pod(&self) -> Pod {
        match self {
            Holding::ByRef => Pod::Choice("ByRef".into(), vec![]),
            Holding::Owned => Pod::Choice("Owned".into(), vec![]),
            Holding::RcRef => Pod::Choice("RcRef".into(), vec![]),
            Holding::RcOwned => Pod::Choice("RcOwned".into(), vec![]),
        }
    }
}

impl FromPod for Holding {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "ByRef" && a.len() == 0 => Ok(Holding::ByRef),
            Pod::Choice(c, a) if &**c == "Owned" && a.len() == 0 => Ok(Holding::Owned),
            Pod::Choice(c, a) if &**c == "RcRef" && a.len() == 0 => Ok(Holding::RcRef),
            Pod::Choice(c, a) if &**c == "RcOwned" && a.len() == 0 => Ok(Holding::RcOwned),
            other => mismatch("a Holding", other),
        }
    }
}

/// `Layer`:
///
/// ```prism
/// type Layer = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum Layer {
    LyPlain,
    LyDyn,
    LyEv,
    LyBlueprint,
}

impl Show for Layer {
    fn show(&self, p: &mut Printer) {
        match self {
            Layer::LyPlain => p.choice("LyPlain", &[]),
            Layer::LyDyn => p.choice("LyDyn", &[]),
            Layer::LyEv => p.choice("LyEv", &[]),
            Layer::LyBlueprint => p.choice("LyBlueprint", &[]),
        }
    }
}

impl ToPod for Layer {
    fn to_pod(&self) -> Pod {
        match self {
            Layer::LyPlain => Pod::Choice("LyPlain".into(), vec![]),
            Layer::LyDyn => Pod::Choice("LyDyn".into(), vec![]),
            Layer::LyEv => Pod::Choice("LyEv".into(), vec![]),
            Layer::LyBlueprint => Pod::Choice("LyBlueprint".into(), vec![]),
        }
    }
}

impl FromPod for Layer {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "LyPlain" && a.len() == 0 => Ok(Layer::LyPlain),
            Pod::Choice(c, a) if &**c == "LyDyn" && a.len() == 0 => Ok(Layer::LyDyn),
            Pod::Choice(c, a) if &**c == "LyEv" && a.len() == 0 => Ok(Layer::LyEv),
            Pod::Choice(c, a) if &**c == "LyBlueprint" && a.len() == 0 => Ok(Layer::LyBlueprint),
            other => mismatch("a Layer", other),
        }
    }
}

/// `Vl`:
///
/// ```prism
/// type Vl = choice:
/// ```
#[derive(Clone)]
pub enum Vl {
    VlPlace(crate::lower::model::Ex, Holding, crate::lower::model::OutTy),
    VlOwned(crate::lower::model::Ex, crate::lower::model::OutTy),
}

impl ToPod for Vl {
    fn to_pod(&self) -> Pod {
        match self {
            Vl::VlPlace(a0, a1, a2) => Pod::Choice("VlPlace".into(), vec![a0.to_pod(), a1.to_pod(), a2.to_pod()]),
            Vl::VlOwned(a0, a1) => Pod::Choice("VlOwned".into(), vec![a0.to_pod(), a1.to_pod()]),
        }
    }
}

impl FromPod for Vl {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "VlPlace" && a.len() == 3 => Ok(Vl::VlPlace(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?, FromPod::from_pod(&a[2])?)),
            Pod::Choice(c, a) if &**c == "VlOwned" && a.len() == 2 => Ok(Vl::VlOwned(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            other => mismatch("a Vl", other),
        }
    }
}

/// ```prism
/// OutTyOf: unbounded fn Lx, Ty -> OutTy
/// ```
pub fn out_ty_of(lx_p0: &crate::lower::Lx, t_p1: &crate::check::types::Ty) -> crate::lower::model::OutTy {
    'm1375: {
        if let crate::check::types::Ty::TyCon(m1375_0_0, m1375_0_1) = t_p1 && (m1375_0_0 == &Text::lit("Nat")) && (m1375_0_1.len() == 0) {
            break 'm1375 crate::lower::model::OutTy::OutNat;
        }
        if let crate::check::types::Ty::TyCon(m1375_1_0, m1375_1_1) = t_p1 && (m1375_1_0 == &Text::lit("Int")) && (m1375_1_1.len() == 0) {
            break 'm1375 crate::lower::model::OutTy::OutInt;
        }
        if let crate::check::types::Ty::TyCon(m1375_2_0, m1375_2_1) = t_p1 && (m1375_2_0 == &Text::lit("U8")) && (m1375_2_1.len() == 0) {
            break 'm1375 crate::lower::model::OutTy::OutU8;
        }
        if let crate::check::types::Ty::TyCon(m1375_3_0, m1375_3_1) = t_p1 && (m1375_3_0 == &Text::lit("Float")) && (m1375_3_1.len() == 0) {
            break 'm1375 crate::lower::model::OutTy::OutFloat;
        }
        if let crate::check::types::Ty::TyCon(m1375_4_0, m1375_4_1) = t_p1 && (m1375_4_0 == &Text::lit("Bool")) && (m1375_4_1.len() == 0) {
            break 'm1375 crate::lower::model::OutTy::OutBool;
        }
        if let crate::check::types::Ty::TyCon(m1375_5_0, m1375_5_1) = t_p1 && (m1375_5_0 == &Text::lit("Char")) && (m1375_5_1.len() == 0) {
            break 'm1375 crate::lower::model::OutTy::OutChar;
        }
        if let crate::check::types::Ty::TyCon(m1375_6_0, m1375_6_1) = t_p1 && (m1375_6_0 == &Text::lit("Text")) && (m1375_6_1.len() == 0) {
            break 'm1375 crate::lower::model::OutTy::OutText;
        }
        if let crate::check::types::Ty::TyCon(m1375_7_0, m1375_7_1) = t_p1 && (m1375_7_0 == &Text::lit("unit")) && (m1375_7_1.len() == 0) {
            break 'm1375 crate::lower::model::OutTy::OutUnit;
        }
        if let crate::check::types::Ty::TyCon(m1375_8_0, m1375_8_1) = t_p1 && (m1375_8_0 == &Text::lit("Path")) && (m1375_8_1.len() == 0) {
            break 'm1375 crate::lower::model::OutTy::OutPath;
        }
        if let crate::check::types::Ty::TyCon(m1375_9_0, m1375_9_1) = t_p1 && (m1375_9_0 == &Text::lit("Cursor")) && (m1375_9_1.len() == 0) {
            break 'm1375 crate::lower::model::OutTy::OutCursor;
        }
        if let crate::check::types::Ty::TyCon(m1375_10_0, m1375_10_1) = t_p1 && (m1375_10_0 == &Text::lit("Regex")) && (m1375_10_1.len() == 0) {
            break 'm1375 crate::lower::model::OutTy::OutRegex;
        }
        if let crate::check::types::Ty::TyCon(m1375_11_0, m1375_11_1) = t_p1 && (m1375_11_0 == &Text::lit("RegexReplacement")) && (m1375_11_1.len() == 0) {
            break 'm1375 crate::lower::model::OutTy::OutReplacement;
        }
        if let crate::check::types::Ty::TyCon(m1375_12_0, m1375_12_1) = t_p1 && (m1375_12_0 == &Text::lit("Duration")) && (m1375_12_1.len() == 0) {
            break 'm1375 crate::lower::model::OutTy::OutDuration;
        }
        if let crate::check::types::Ty::TyCon(m1375_13_0, m1375_13_1) = t_p1 && (m1375_13_0 == &Text::lit("Prelude.Error")) && (m1375_13_1.len() == 0) {
            break 'm1375 crate::lower::model::OutTy::OutError;
        }
        if let crate::check::types::Ty::TyCon(m1375_14_0, m1375_14_1) = t_p1 && (m1375_14_0 == &Text::lit("\0Self")) && (m1375_14_1.len() == 0) {
            break 'm1375 crate::lower::model::OutTy::OutNamed(Text::lit("Self"), Array::new());
        }
        if let crate::check::types::Ty::TyCon(m1375_15_0, m1375_15_1) = t_p1 && (m1375_15_0 == &Text::lit("Buffer")) && (m1375_15_1.len() == 1) && let Some(a_p2) = index(m1375_15_1, &Nat::from(0u32)) {
            break 'm1375 crate::lower::model::OutTy::OutArray(Rc::new(out_ty_of(lx_p0, &a_p2)));
        }
        if let crate::check::types::Ty::TyCon(m1375_16_0, m1375_16_1) = t_p1 && (m1375_16_0 == &Text::lit("Table")) && (m1375_16_1.len() == 2) && let Some(k_p3) = index(m1375_16_1, &Nat::from(0u32)) && let Some(v_p4) = index(m1375_16_1, &Nat::from(1u32)) {
            break 'm1375 crate::lower::model::OutTy::OutArray(Rc::new(crate::lower::model::OutTy::OutTuple(Array::from(vec![out_ty_of(lx_p0, &k_p3), out_ty_of(lx_p0, &v_p4)]))));
        }
        if let crate::check::types::Ty::TyCon(m1375_17_0, m1375_17_1) = t_p1 && (m1375_17_0 == &Text::lit("\0Event")) && (m1375_17_1.len() == 1) && let Some(a_p5) = index(m1375_17_1, &Nat::from(0u32)) {
            break 'm1375 crate::lower::model::OutTy::OutEvent(Rc::new(out_ty_of(lx_p0, &a_p5)));
        }
        if let crate::check::types::Ty::TyCon(n_p6, args_p7) = t_p1 {
            break 'm1375 named_ty(lx_p0, n_p6, &run_to_end(each_job(args_p7.clone(), {
                let lx_p0 = lx_p0.clone();
                Rc::new(move |p0: crate::check::types::Ty| {
                    let lx_p0 = lx_p0.clone();
                    entered(once_job(move || {
                        let a_p8 = p0;
                        prism_rtl::Turn::More(Rc::new(OutTyOf { lx_p0: lx_p0.clone(), t_p1: a_p8.clone() }))
                    }))
                }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::lower::model::OutTy>>>
            })));
        }
        if let crate::check::types::Ty::TyFn(c_p9, ps_pa, res_pb) = t_p1 {
            break 'm1375 {
                let c2_pc = crate::lower::inst_col(lx_p0, c_p9);
                if &c2_pc == &crate::check::types::Col::CBound {
                    crate::lower::model::OutTy::OutFn(run_to_end(each_job(ps_pa.clone(), {
                        let lx_p0 = lx_p0.clone();
                        Rc::new(move |p0: crate::check::types::Ty| {
                            let lx_p0 = lx_p0.clone();
                            entered(once_job(move || {
                                let p_pd = p0;
                                prism_rtl::Turn::More(Rc::new(OutTyOf { lx_p0: lx_p0.clone(), t_p1: p_pd.clone() }))
                            }))
                        }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::lower::model::OutTy>>>
                    })), Rc::new(out_ty_of(lx_p0, &**res_pb)))
                } else {
                    if crate::lower::is_quant_col(lx_p0, &c2_pc) {
                        crate::lower::model::OutTy::OutQuantified(or(&get(&lx_p0.quants, &crate::lower::expr::col_name(&c2_pc)), &Text::lit("")))
                    } else {
                        crate::lower::model::OutTy::OutJobFn(Rc::new(rust_ty_of_params(lx_p0, &each(ps_pa, &(|p_pe: &crate::check::types::Ty| job_param(p_pe))))), Rc::new(out_ty_of(lx_p0, &**res_pb)))
                    }
                }
            };
        }
        if let crate::check::types::Ty::TyTuple(m1375_20_0) = t_p1 && (m1375_20_0.len() == 0) {
            break 'm1375 crate::lower::model::OutTy::OutUnit;
        }
        if let crate::check::types::Ty::TyTuple(ts_pf) = t_p1 {
            break 'm1375 crate::lower::model::OutTy::OutTuple(run_to_end(each_job(ts_pf.clone(), {
                let lx_p0 = lx_p0.clone();
                Rc::new(move |p0: crate::check::types::Ty| {
                    let lx_p0 = lx_p0.clone();
                    entered(once_job(move || {
                        let a_pg = p0;
                        prism_rtl::Turn::More(Rc::new(OutTyOf { lx_p0: lx_p0.clone(), t_p1: a_pg.clone() }))
                    }))
                }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::lower::model::OutTy>>>
            })));
        }
        if let crate::check::types::Ty::TyArray(e_ph) = t_p1 {
            break 'm1375 crate::lower::model::OutTy::OutArray(Rc::new(out_ty_of(lx_p0, &**e_ph)));
        }
        if let crate::check::types::Ty::TyMap(k_pi, v_pj) = t_p1 {
            break 'm1375 crate::lower::model::OutTy::OutMap(Rc::new(out_ty_of(lx_p0, &**k_pi)), Rc::new(out_ty_of(lx_p0, &**v_pj)));
        }
        if let crate::check::types::Ty::TySig(m1375_24_0, i_pk) = t_p1 && (m1375_24_0 == &Text::lit("?")) {
            break 'm1375 crate::lower::model::OutTy::OutOpt(Rc::new(out_ty_of(lx_p0, &**i_pk)));
        }
        if let crate::check::types::Ty::TySig(m1375_25_0, i_pl) = t_p1 && (m1375_25_0 == &Text::lit("~")) {
            break 'm1375 crate::lower::model::OutTy::OutRes(Rc::new(out_ty_of(lx_p0, &**i_pl)));
        }
        if let crate::check::types::Ty::TySig(m1375_26_0, i_pm) = t_p1 && (m1375_26_0 == &Text::lit("!")) {
            break 'm1375 crate::lower::model::OutTy::OutEvent(Rc::new(out_ty_of(lx_p0, &**i_pm)));
        }
        if let crate::check::types::Ty::TySig(m1375_27_0, i_pn) = t_p1 && (m1375_27_0 == &Text::lit("$")) {
            break 'm1375 crate::lower::model::OutTy::OutDyn(Rc::new(out_ty_of(lx_p0, &**i_pn)));
        }
        if let crate::check::types::Ty::TySig(m1375_28_0, i_po) = t_p1 && (m1375_28_0 == &Text::lit("&")) {
            break 'm1375 out_ty_of(lx_p0, &**i_po);
        }
        if let crate::check::types::Ty::TySig(_, i_pp) = t_p1 {
            break 'm1375 out_ty_of(lx_p0, &**i_pp);
        }
        if let crate::check::types::Ty::TyQ(n_pq) = t_p1 {
            break 'm1375 crate::lower::model::OutTy::OutGen(crate::lower::camel(n_pq));
        }
        if let crate::check::types::Ty::TyRigid(n_pr) = t_p1 {
            break 'm1375 crate::lower::model::OutTy::OutGen(crate::lower::camel(n_pr));
        }
        if let crate::check::types::Ty::TyFlex(n_ps) = t_p1 {
            break 'm1375 match get(&lx_p0.subst, &Text::from(format!("\'{}", n_ps))) {
                Some(x_pt) => out_ty_of(lx_p0, &x_pt),
                None => match get(&lx_p0.quants, &Text::from(format!("\'{}", n_ps))) {
                    Some(b_pu) => crate::lower::model::OutTy::OutQuantified(b_pu),
                    None => crate::lower::model::OutTy::OutUnit,
                },
            };
        }
        if let crate::check::types::Ty::TyAny(_) = t_p1 {
            break 'm1375 crate::lower::model::OutTy::OutShowAny;
        }
        if let crate::check::types::Ty::TyElem(_, _) = t_p1 {
            break 'm1375 crate::lower::model::OutTy::OutLive(Rc::new(crate::lower::model::OutTy::OutNamed(Text::lit("crate::Elem"), Array::new())));
        }
        if let crate::check::types::Ty::TyElemAny(_) = t_p1 {
            break 'm1375 crate::lower::model::OutTy::OutNamed(Text::lit("crate::Elem"), Array::new());
        }
        if let crate::check::types::Ty::TyAt(i_pv, _) = t_p1 {
            break 'm1375 blueprint_ty();
        }
        if let crate::check::types::Ty::TyAssoc(_, _) = t_p1 {
            break 'm1375 crate::lower::model::OutTy::OutUnknown(Text::lit("an associated type"));
        }
        if let crate::check::types::Ty::TyErr = t_p1 {
            break 'm1375 crate::lower::model::OutTy::OutUnknown(Text::lit("a type the checker did not find"));
        }
        unreachable!("no clause matched")
    }
}

/// The step machine of `OutTyOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// OutTyOf: unbounded fn Lx, Ty -> OutTy
/// ```
pub struct OutTyOf {
    pub lx_p0: crate::lower::Lx,
    pub t_p1: crate::check::types::Ty,
}

impl prism_rtl::Job<crate::lower::model::OutTy> for OutTyOf {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::OutTy> {
        let lx_p0 = &self.lx_p0;
        let t_p1 = &self.t_p1;
        'm1375: {
            if let crate::check::types::Ty::TyCon(m1375_0_0, m1375_0_1) = t_p1 && (m1375_0_0 == &Text::lit("Nat")) && (m1375_0_1.len() == 0) {
                break 'm1375 prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutNat);
            }
            if let crate::check::types::Ty::TyCon(m1375_1_0, m1375_1_1) = t_p1 && (m1375_1_0 == &Text::lit("Int")) && (m1375_1_1.len() == 0) {
                break 'm1375 prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutInt);
            }
            if let crate::check::types::Ty::TyCon(m1375_2_0, m1375_2_1) = t_p1 && (m1375_2_0 == &Text::lit("U8")) && (m1375_2_1.len() == 0) {
                break 'm1375 prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutU8);
            }
            if let crate::check::types::Ty::TyCon(m1375_3_0, m1375_3_1) = t_p1 && (m1375_3_0 == &Text::lit("Float")) && (m1375_3_1.len() == 0) {
                break 'm1375 prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutFloat);
            }
            if let crate::check::types::Ty::TyCon(m1375_4_0, m1375_4_1) = t_p1 && (m1375_4_0 == &Text::lit("Bool")) && (m1375_4_1.len() == 0) {
                break 'm1375 prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutBool);
            }
            if let crate::check::types::Ty::TyCon(m1375_5_0, m1375_5_1) = t_p1 && (m1375_5_0 == &Text::lit("Char")) && (m1375_5_1.len() == 0) {
                break 'm1375 prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutChar);
            }
            if let crate::check::types::Ty::TyCon(m1375_6_0, m1375_6_1) = t_p1 && (m1375_6_0 == &Text::lit("Text")) && (m1375_6_1.len() == 0) {
                break 'm1375 prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutText);
            }
            if let crate::check::types::Ty::TyCon(m1375_7_0, m1375_7_1) = t_p1 && (m1375_7_0 == &Text::lit("unit")) && (m1375_7_1.len() == 0) {
                break 'm1375 prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutUnit);
            }
            if let crate::check::types::Ty::TyCon(m1375_8_0, m1375_8_1) = t_p1 && (m1375_8_0 == &Text::lit("Path")) && (m1375_8_1.len() == 0) {
                break 'm1375 prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutPath);
            }
            if let crate::check::types::Ty::TyCon(m1375_9_0, m1375_9_1) = t_p1 && (m1375_9_0 == &Text::lit("Cursor")) && (m1375_9_1.len() == 0) {
                break 'm1375 prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutCursor);
            }
            if let crate::check::types::Ty::TyCon(m1375_10_0, m1375_10_1) = t_p1 && (m1375_10_0 == &Text::lit("Regex")) && (m1375_10_1.len() == 0) {
                break 'm1375 prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutRegex);
            }
            if let crate::check::types::Ty::TyCon(m1375_11_0, m1375_11_1) = t_p1 && (m1375_11_0 == &Text::lit("RegexReplacement")) && (m1375_11_1.len() == 0) {
                break 'm1375 prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutReplacement);
            }
            if let crate::check::types::Ty::TyCon(m1375_12_0, m1375_12_1) = t_p1 && (m1375_12_0 == &Text::lit("Duration")) && (m1375_12_1.len() == 0) {
                break 'm1375 prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutDuration);
            }
            if let crate::check::types::Ty::TyCon(m1375_13_0, m1375_13_1) = t_p1 && (m1375_13_0 == &Text::lit("Prelude.Error")) && (m1375_13_1.len() == 0) {
                break 'm1375 prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutError);
            }
            if let crate::check::types::Ty::TyCon(m1375_14_0, m1375_14_1) = t_p1 && (m1375_14_0 == &Text::lit("\0Self")) && (m1375_14_1.len() == 0) {
                break 'm1375 prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutNamed(Text::lit("Self"), Array::new()));
            }
            if let crate::check::types::Ty::TyCon(m1375_15_0, m1375_15_1) = t_p1 && (m1375_15_0 == &Text::lit("Buffer")) && (m1375_15_1.len() == 1) && let Some(a_p2) = index(m1375_15_1, &Nat::from(0u32)) {
                break 'm1375 {
                    let lx_p0 = lx_p0.clone();
                    call_then(start_out_ty_of(lx_p0.clone(), a_p2.clone()), move |out_ty_of_1957: crate::lower::model::OutTy| prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutArray(Rc::new(out_ty_of_1957))))
                };
            }
            if let crate::check::types::Ty::TyCon(m1375_16_0, m1375_16_1) = t_p1 && (m1375_16_0 == &Text::lit("Table")) && (m1375_16_1.len() == 2) && let Some(k_p3) = index(m1375_16_1, &Nat::from(0u32)) && let Some(v_p4) = index(m1375_16_1, &Nat::from(1u32)) {
                break 'm1375 {
                    let lx_p0 = lx_p0.clone();
                    call_then(start_out_ty_of(lx_p0.clone(), k_p3.clone()), move |out_ty_of_2023: crate::lower::model::OutTy| call_then(start_out_ty_of(lx_p0.clone(), v_p4.clone()), move |out_ty_of_2040: crate::lower::model::OutTy| prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutArray(Rc::new(crate::lower::model::OutTy::OutTuple(Array::from(vec![out_ty_of_2023, out_ty_of_2040])))))))
                };
            }
            if let crate::check::types::Ty::TyCon(m1375_17_0, m1375_17_1) = t_p1 && (m1375_17_0 == &Text::lit("\0Event")) && (m1375_17_1.len() == 1) && let Some(a_p5) = index(m1375_17_1, &Nat::from(0u32)) {
                break 'm1375 {
                    let lx_p0 = lx_p0.clone();
                    call_then(start_out_ty_of(lx_p0.clone(), a_p5.clone()), move |out_ty_of_2099: crate::lower::model::OutTy| prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutEvent(Rc::new(out_ty_of_2099))))
                };
            }
            if let crate::check::types::Ty::TyCon(n_p6, args_p7) = t_p1 {
                break 'm1375 {
                    let args_p7 = args_p7.clone();
                    let lx_p0 = lx_p0.clone();
                    let n_p6 = n_p6.clone();
                    call_value(each_job(args_p7.clone(), {
                        let lx_p0 = lx_p0.clone();
                        Rc::new(move |p0: crate::check::types::Ty| {
                            let lx_p0 = lx_p0.clone();
                            entered(once_job(move || {
                                let a_p8 = p0;
                                prism_rtl::Turn::More(Rc::new(OutTyOf { lx_p0: lx_p0.clone(), t_p1: a_p8.clone() }))
                            }))
                        }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::lower::model::OutTy>>>
                    }), move |each_2149: Array<crate::lower::model::OutTy>| prism_rtl::Turn::More(Rc::new(NamedTy { lx_p0: lx_p0.clone(), n_p1: n_p6.clone(), args_p2: each_2149 })))
                };
            }
            if let crate::check::types::Ty::TyFn(c_p9, ps_pa, res_pb) = t_p1 {
                break 'm1375 {
                    let c2_pc = crate::lower::inst_col(lx_p0, c_p9);
                    if &c2_pc == &crate::check::types::Col::CBound {
                        {
                            let lx_p0 = lx_p0.clone();
                            let ps_pa = ps_pa.clone();
                            let res_pb = (**res_pb).clone();
                            call_value(each_job(ps_pa.clone(), {
                                let lx_p0 = lx_p0.clone();
                                Rc::new(move |p0: crate::check::types::Ty| {
                                    let lx_p0 = lx_p0.clone();
                                    entered(once_job(move || {
                                        let p_pd = p0;
                                        prism_rtl::Turn::More(Rc::new(OutTyOf { lx_p0: lx_p0.clone(), t_p1: p_pd.clone() }))
                                    }))
                                }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::lower::model::OutTy>>>
                            }), move |each_2430: Array<crate::lower::model::OutTy>| call_then(start_out_ty_of(lx_p0.clone(), res_pb.clone()), move |out_ty_of_2461: crate::lower::model::OutTy| prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutFn(each_2430, Rc::new(out_ty_of_2461)))))
                        }
                    } else {
                        if crate::lower::is_quant_col(lx_p0, &c2_pc) {
                            prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutQuantified(or(&get(&lx_p0.quants, &crate::lower::expr::col_name(&c2_pc)), &Text::lit(""))))
                        } else {
                            {
                                let lx_p0 = lx_p0.clone();
                                let ps_pa = ps_pa.clone();
                                let res_pb = (**res_pb).clone();
                                call_then(start_rust_ty_of_params(lx_p0.clone(), each(&ps_pa, &(|p_pe: &crate::check::types::Ty| job_param(p_pe)))), move |rust_ty_of_params_2583: crate::lower::model::OutTy| call_then(start_out_ty_of(lx_p0.clone(), res_pb.clone()), move |out_ty_of_2632: crate::lower::model::OutTy| prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutJobFn(Rc::new(rust_ty_of_params_2583), Rc::new(out_ty_of_2632)))))
                            }
                        }
                    }
                };
            }
            if let crate::check::types::Ty::TyTuple(m1375_20_0) = t_p1 && (m1375_20_0.len() == 0) {
                break 'm1375 prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutUnit);
            }
            if let crate::check::types::Ty::TyTuple(ts_pf) = t_p1 {
                break 'm1375 {
                    let lx_p0 = lx_p0.clone();
                    let ts_pf = ts_pf.clone();
                    call_value(each_job(ts_pf.clone(), {
                        let lx_p0 = lx_p0.clone();
                        Rc::new(move |p0: crate::check::types::Ty| {
                            let lx_p0 = lx_p0.clone();
                            entered(once_job(move || {
                                let a_pg = p0;
                                prism_rtl::Turn::More(Rc::new(OutTyOf { lx_p0: lx_p0.clone(), t_p1: a_pg.clone() }))
                            }))
                        }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::lower::model::OutTy>>>
                    }), move |each_2701: Array<crate::lower::model::OutTy>| prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutTuple(each_2701)))
                };
            }
            if let crate::check::types::Ty::TyArray(e_ph) = t_p1 {
                break 'm1375 {
                    let e_ph = (**e_ph).clone();
                    let lx_p0 = lx_p0.clone();
                    call_then(start_out_ty_of(lx_p0.clone(), e_ph.clone()), move |out_ty_of_2755: crate::lower::model::OutTy| prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutArray(Rc::new(out_ty_of_2755))))
                };
            }
            if let crate::check::types::Ty::TyMap(k_pi, v_pj) = t_p1 {
                break 'm1375 {
                    let k_pi = (**k_pi).clone();
                    let lx_p0 = lx_p0.clone();
                    let v_pj = (**v_pj).clone();
                    call_then(start_out_ty_of(lx_p0.clone(), k_pi.clone()), move |out_ty_of_2794: crate::lower::model::OutTy| call_then(start_out_ty_of(lx_p0.clone(), v_pj.clone()), move |out_ty_of_2811: crate::lower::model::OutTy| prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutMap(Rc::new(out_ty_of_2794), Rc::new(out_ty_of_2811)))))
                };
            }
            if let crate::check::types::Ty::TySig(m1375_24_0, i_pk) = t_p1 && (m1375_24_0 == &Text::lit("?")) {
                break 'm1375 {
                    let i_pk = (**i_pk).clone();
                    let lx_p0 = lx_p0.clone();
                    call_then(start_out_ty_of(lx_p0.clone(), i_pk.clone()), move |out_ty_of_2852: crate::lower::model::OutTy| prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutOpt(Rc::new(out_ty_of_2852))))
                };
            }
            if let crate::check::types::Ty::TySig(m1375_25_0, i_pl) = t_p1 && (m1375_25_0 == &Text::lit("~")) {
                break 'm1375 {
                    let i_pl = (**i_pl).clone();
                    let lx_p0 = lx_p0.clone();
                    call_then(start_out_ty_of(lx_p0.clone(), i_pl.clone()), move |out_ty_of_2893: crate::lower::model::OutTy| prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutRes(Rc::new(out_ty_of_2893))))
                };
            }
            if let crate::check::types::Ty::TySig(m1375_26_0, i_pm) = t_p1 && (m1375_26_0 == &Text::lit("!")) {
                break 'm1375 {
                    let i_pm = (**i_pm).clone();
                    let lx_p0 = lx_p0.clone();
                    call_then(start_out_ty_of(lx_p0.clone(), i_pm.clone()), move |out_ty_of_2936: crate::lower::model::OutTy| prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutEvent(Rc::new(out_ty_of_2936))))
                };
            }
            if let crate::check::types::Ty::TySig(m1375_27_0, i_pn) = t_p1 && (m1375_27_0 == &Text::lit("$")) {
                break 'm1375 {
                    let i_pn = (**i_pn).clone();
                    let lx_p0 = lx_p0.clone();
                    call_then(start_out_ty_of(lx_p0.clone(), i_pn.clone()), move |out_ty_of_2977: crate::lower::model::OutTy| prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutDyn(Rc::new(out_ty_of_2977))))
                };
            }
            if let crate::check::types::Ty::TySig(m1375_28_0, i_po) = t_p1 && (m1375_28_0 == &Text::lit("&")) {
                break 'm1375 prism_rtl::Turn::More(Rc::new(OutTyOf { lx_p0: lx_p0.clone(), t_p1: (**i_po).clone() }));
            }
            if let crate::check::types::Ty::TySig(_, i_pp) = t_p1 {
                break 'm1375 prism_rtl::Turn::More(Rc::new(OutTyOf { lx_p0: lx_p0.clone(), t_p1: (**i_pp).clone() }));
            }
            if let crate::check::types::Ty::TyQ(n_pq) = t_p1 {
                break 'm1375 prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutGen(crate::lower::camel(n_pq)));
            }
            if let crate::check::types::Ty::TyRigid(n_pr) = t_p1 {
                break 'm1375 prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutGen(crate::lower::camel(n_pr)));
            }
            if let crate::check::types::Ty::TyFlex(n_ps) = t_p1 {
                break 'm1375 match get(&lx_p0.subst, &Text::from(format!("\'{}", n_ps))) {
                    Some(x_pt) => prism_rtl::Turn::More(Rc::new(OutTyOf { lx_p0: lx_p0.clone(), t_p1: x_pt.clone() })),
                    None => match get(&lx_p0.quants, &Text::from(format!("\'{}", n_ps))) {
                        Some(b_pu) => prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutQuantified(b_pu.clone())),
                        None => prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutUnit),
                    },
                };
            }
            if let crate::check::types::Ty::TyAny(_) = t_p1 {
                break 'm1375 prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutShowAny);
            }
            if let crate::check::types::Ty::TyElem(_, _) = t_p1 {
                break 'm1375 prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutLive(Rc::new(crate::lower::model::OutTy::OutNamed(Text::lit("crate::Elem"), Array::new()))));
            }
            if let crate::check::types::Ty::TyElemAny(_) = t_p1 {
                break 'm1375 prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutNamed(Text::lit("crate::Elem"), Array::new()));
            }
            if let crate::check::types::Ty::TyAt(i_pv, _) = t_p1 {
                break 'm1375 prism_rtl::Turn::Finished(blueprint_ty());
            }
            if let crate::check::types::Ty::TyAssoc(_, _) = t_p1 {
                break 'm1375 prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutUnknown(Text::lit("an associated type")));
            }
            if let crate::check::types::Ty::TyErr = t_p1 {
                break 'm1375 prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutUnknown(Text::lit("a type the checker did not find")));
            }
            unreachable!("no clause matched")
        }
    }
}

/// `Start OutTyOf, x`: what the function value is when passed to `@Run`.
pub fn start_out_ty_of(lx_p0: crate::lower::Lx, t_p1: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::lower::model::OutTy>> {
    Rc::new(OutTyOf { lx_p0, t_p1 })
}

/// ```prism
/// let blueprintTy
/// ```
pub fn blueprint_ty() -> crate::lower::model::OutTy {
    crate::lower::model::OutTy::OutNamed(Text::lit("prism_rtl::Blueprint"), Array::from(vec![crate::lower::model::OutTy::OutNamed(Text::lit("crate::Elem"), Array::new()), crate::lower::model::OutTy::OutNamed(Text::lit("crate::Answer"), Array::new())]))
}

/// ```prism
/// let elemTy
/// ```
pub fn elem_ty() -> crate::lower::model::OutTy {
    crate::lower::model::OutTy::OutNamed(Text::lit("crate::Elem"), Array::new())
}

/// ```prism
/// let answerTy
/// ```
pub fn answer_ty() -> crate::lower::model::OutTy {
    crate::lower::model::OutTy::OutNamed(Text::lit("crate::Answer"), Array::new())
}

/// ```prism
/// let entryTy
/// ```
pub fn entry_ty() -> crate::lower::model::OutTy {
    crate::lower::model::OutTy::OutRc(Rc::new(crate::lower::model::OutTy::OutNamed(Text::lit("prism_rtl::Entry"), Array::from(vec![crate::lower::model::OutTy::OutNamed(Text::lit("crate::Elem"), Array::new())]))))
}

/// ```prism
/// let hostDocTy
/// ```
pub fn host_doc_ty() -> crate::lower::model::OutTy {
    crate::lower::model::OutTy::OutNamed(Text::lit("prism_rtl::HostDoc"), Array::from(vec![crate::lower::model::OutTy::OutNamed(Text::lit("crate::Elem"), Array::new())]))
}

/// ```prism
/// let hostOfTy
/// ```
pub fn host_of_ty() -> crate::lower::model::OutTy {
    crate::lower::model::OutTy::OutObj(Rc::new(crate::lower::model::OutTy::OutNamed(Text::lit("prism_rtl::HostOf"), Array::from(vec![crate::lower::model::OutTy::OutNamed(Text::lit("crate::Elem"), Array::new()), crate::lower::model::OutTy::OutNamed(Text::lit("crate::Answer"), Array::new())]))))
}

/// ```prism
/// HasBlueprint: fn Ty -> Bool
/// ```
pub fn has_blueprint(t_p0: &crate::check::types::Ty) -> bool {
    match t_p0 {
        crate::check::types::Ty::TyAt(_, _) => true,
        crate::check::types::Ty::TySig(_, i_p1) => has_blueprint(&**i_p1),
        _ => false,
    }
}

/// ```prism
/// EventParam: fn Ty -> Ty
/// ```
pub fn event_param(t_p0: &crate::check::types::Ty) -> crate::check::types::Ty {
    match t_p0 {
        crate::check::types::Ty::TySig(m4785_0_0, i_p1) if (m4785_0_0 == &Text::lit("!")) => crate::check::types::Ty::TyCon(Text::lit("\0Event"), Array::from(vec![peel(&**i_p1)])),
        _ => t_p0.clone(),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// JobParam: fn Ty -> Ty
/// ```
pub fn job_param(ty0: &crate::check::types::Ty) -> crate::check::types::Ty {
    match ty0 {
        crate::check::types::Ty::TyFn(_, ps_p0, r_p1) => crate::check::types::Ty::TyFn(crate::check::types::Col::CUnbound, ps_p0.clone(), Rc::new((**r_p1).clone())),
        t_p2 => t_p2.clone(),
    }
}

/// ```prism
/// RustTyOfParams: unbounded fn Lx, [Ty] -> OutTy
/// ```
pub fn rust_ty_of_params(lx_p0: &crate::lower::Lx, ps_p1: &Array<crate::check::types::Ty>) -> crate::lower::model::OutTy {
    'm5348: {
        if let m5348_0 = ps_p1 && (m5348_0.len() == 1) && let Some(p_p2) = index(m5348_0, &Nat::from(0u32)) {
            break 'm5348 out_ty_of(lx_p0, &p_p2);
        }
        crate::lower::model::OutTy::OutTuple(run_to_end(each_job(ps_p1.clone(), {
            let lx_p0 = lx_p0.clone();
            Rc::new(move |p0: crate::check::types::Ty| {
                let lx_p0 = lx_p0.clone();
                entered(once_job(move || {
                    let p_p3 = p0;
                    prism_rtl::Turn::More(Rc::new(OutTyOf { lx_p0: lx_p0.clone(), t_p1: p_p3.clone() }))
                }))
            }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::lower::model::OutTy>>>
        })))
    }
}

/// The step machine of `RustTyOfParams`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RustTyOfParams: unbounded fn Lx, [Ty] -> OutTy
/// ```
pub struct RustTyOfParams {
    pub lx_p0: crate::lower::Lx,
    pub ps_p1: Array<crate::check::types::Ty>,
}

impl prism_rtl::Job<crate::lower::model::OutTy> for RustTyOfParams {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::OutTy> {
        let lx_p0 = &self.lx_p0;
        let ps_p1 = &self.ps_p1;
        'm5348: {
            if let m5348_0 = ps_p1 && (m5348_0.len() == 1) && let Some(p_p2) = index(m5348_0, &Nat::from(0u32)) {
                break 'm5348 prism_rtl::Turn::More(Rc::new(OutTyOf { lx_p0: lx_p0.clone(), t_p1: p_p2.clone() }));
            }
            {
                let lx_p0 = lx_p0.clone();
                let ps_p1 = ps_p1.clone();
                call_value(each_job(ps_p1.clone(), {
                    let lx_p0 = lx_p0.clone();
                    Rc::new(move |p0: crate::check::types::Ty| {
                        let lx_p0 = lx_p0.clone();
                        entered(once_job(move || {
                            let p_p3 = p0;
                            prism_rtl::Turn::More(Rc::new(OutTyOf { lx_p0: lx_p0.clone(), t_p1: p_p3.clone() }))
                        }))
                    }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::lower::model::OutTy>>>
                }), move |each_5408: Array<crate::lower::model::OutTy>| prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutTuple(each_5408)))
            }
        }
    }
}

/// `Start RustTyOfParams, x`: what the function value is when passed to `@Run`.
pub fn start_rust_ty_of_params(lx_p0: crate::lower::Lx, ps_p1: Array<crate::check::types::Ty>) -> Rc<dyn prism_rtl::Job<crate::lower::model::OutTy>> {
    Rc::new(RustTyOfParams { lx_p0, ps_p1 })
}

/// ```prism
/// NamedTy: unbounded fn Lx, Text, [OutTy] -> OutTy
/// ```
pub fn named_ty(lx_p0: &crate::lower::Lx, n_p1: &Text, args_p2: &Array<crate::lower::model::OutTy>) -> crate::lower::model::OutTy {
    match get(&lx_p0.g.types, n_p1) {
        Some(ti_p3) => match &ti_p3.body {
            crate::check::env::TyBody::BAlias(a_p4) => out_ty_of(lx_p0, a_p4),
            crate::check::env::TyBody::BRowKind => if n_p1 == &Text::lit("Prelude.Fault") {
                crate::lower::model::OutTy::OutPod
            } else {
                crate::lower::model::OutTy::OutNamed(crate::lower::path_in(lx_p0, &ti_p3.home, &crate::lower::camel(&crate::check::types::bare_name(n_p1))), Array::new())
            },
            _ => crate::lower::model::OutTy::OutNamed(crate::lower::path_in(lx_p0, &ti_p3.home, &crate::lower::camel(&crate::check::types::bare_name(n_p1))), args_p2.clone()),
        },
        None => if crate::check::env::has_key(&lx_p0.g.families, n_p1) {
            crate::lower::model::OutTy::OutPod
        } else {
            crate::lower::model::OutTy::OutNamed(crate::lower::camel(&crate::check::types::bare_name(n_p1)), args_p2.clone())
        },
    }
}

/// The step machine of `NamedTy`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// NamedTy: unbounded fn Lx, Text, [OutTy] -> OutTy
/// ```
pub struct NamedTy {
    pub lx_p0: crate::lower::Lx,
    pub n_p1: Text,
    pub args_p2: Array<crate::lower::model::OutTy>,
}

impl prism_rtl::Job<crate::lower::model::OutTy> for NamedTy {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::OutTy> {
        let lx_p0 = &self.lx_p0;
        let n_p1 = &self.n_p1;
        let args_p2 = &self.args_p2;
        match get(&lx_p0.g.types, n_p1) {
            Some(ti_p3) => match &ti_p3.body {
                crate::check::env::TyBody::BAlias(a_p4) => prism_rtl::Turn::More(Rc::new(OutTyOf { lx_p0: lx_p0.clone(), t_p1: a_p4.clone() })),
                crate::check::env::TyBody::BRowKind => if n_p1 == &Text::lit("Prelude.Fault") {
                    prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutPod)
                } else {
                    prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutNamed(crate::lower::path_in(lx_p0, &ti_p3.home, &crate::lower::camel(&crate::check::types::bare_name(n_p1))), Array::new()))
                },
                _ => prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutNamed(crate::lower::path_in(lx_p0, &ti_p3.home, &crate::lower::camel(&crate::check::types::bare_name(n_p1))), args_p2.clone())),
            },
            None => if crate::check::env::has_key(&lx_p0.g.families, n_p1) {
                prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutPod)
            } else {
                prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutNamed(crate::lower::camel(&crate::check::types::bare_name(n_p1)), args_p2.clone()))
            },
        }
    }
}

/// `Start NamedTy, x`: what the function value is when passed to `@Run`.
pub fn start_named_ty(lx_p0: crate::lower::Lx, n_p1: Text, args_p2: Array<crate::lower::model::OutTy>) -> Rc<dyn prism_rtl::Job<crate::lower::model::OutTy>> {
    Rc::new(NamedTy { lx_p0, n_p1, args_p2 })
}

/// ```prism
/// Peel: fn Ty -> Ty
/// ```
pub fn peel(t_p0: &crate::check::types::Ty) -> crate::check::types::Ty {
    match t_p0 {
        crate::check::types::Ty::TySig(m6146_0_0, i_p1) if (m6146_0_0 == &Text::lit("$")) => peel(&**i_p1),
        crate::check::types::Ty::TySig(m6146_1_0, i_p2) if (m6146_1_0 == &Text::lit("!")) => peel(&**i_p2),
        crate::check::types::Ty::TySig(m6146_2_0, i_p3) if (m6146_2_0 == &Text::lit("&")) => peel(&**i_p3),
        _ => t_p0.clone(),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// OutOf: fn Ty -> Ty
/// ```
pub fn out_of(t_p0: &crate::check::types::Ty) -> crate::check::types::Ty {
    match t_p0 {
        crate::check::types::Ty::TyAt(i_p1, _) => peel(&**i_p1),
        _ => peel(t_p0),
    }
}

/// ```prism
/// IsBundle: fn Ty -> Bool
/// ```
pub fn is_bundle(t_p0: &crate::check::types::Ty) -> bool {
    match t_p0 {
        crate::check::types::Ty::TyTuple(ts_p1) => fold(ts_p1, &false, &(|found_p2: &bool, x_p3: &crate::check::types::Ty| ((*found_p2 || (&layer_of(x_p3) == &Layer::LyEv)) || (&layer_of(x_p3) == &Layer::LyDyn)) || is_bundle(x_p3))),
        _ => false,
    }
}

/// ```prism
/// LayerOf: fn Ty -> Layer
/// ```
pub fn layer_of(t_p0: &crate::check::types::Ty) -> Layer {
    match t_p0 {
        crate::check::types::Ty::TySig(m6991_0_0, _) if (m6991_0_0 == &Text::lit("$")) => Layer::LyDyn,
        crate::check::types::Ty::TySig(m6991_1_0, _) if (m6991_1_0 == &Text::lit("!")) => Layer::LyEv,
        crate::check::types::Ty::TySig(m6991_2_0, i_p1) if (m6991_2_0 == &Text::lit("&")) => layer_of(&**i_p1),
        crate::check::types::Ty::TyAt(_, _) => Layer::LyBlueprint,
        _ => Layer::LyPlain,
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// Layouts: unbounded fn G -> (Text ==> [Bool])
/// ```
pub fn layouts(g_p0: &crate::check::env::G) -> Map<Text, Array<bool>> {
    run_to_end(fold_job(values(&g_p0.ctors), Map::new(), {
        let g_p0 = g_p0.clone();
        Rc::new(move |(p0, p1): (Map<Text, Array<bool>>, crate::check::env::CtorInfo)| {
            let g_p0 = g_p0.clone();
            entered(once_job(move || {
                let m_p1 = p0;
                let c_p2 = p1;
                call_value(each_job(c_p2.args.clone(), {
                    let g_p0 = g_p0.clone();
                    let c_p2 = c_p2.clone();
                    Rc::new(move |p0: crate::check::types::Ty| {
                        let g_p0 = g_p0.clone();
                        let c_p2 = c_p2.clone();
                        entered(once_job(move || {
                            let a_p3 = p0;
                            prism_rtl::Turn::More(Rc::new(Reaches { g_p0: g_p0.clone(), t_p1: a_p3.clone(), target_p2: c_p2.owner.clone(), seen_p3: Array::new() }))
                        }))
                    }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<bool>>>
                }), move |each_7499: Array<bool>| prism_rtl::Turn::Finished(insert(&m_p1, &c_p2.name, &each_7499)))
            }))
        }) as Rc<dyn Fn((Map<Text, Array<bool>>, crate::check::env::CtorInfo)) -> Rc<dyn prism_rtl::Job<Map<Text, Array<bool>>>>>
    }))
}

/// The step machine of `Layouts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Layouts: unbounded fn G -> (Text ==> [Bool])
/// ```
pub struct Layouts {
    pub g_p0: crate::check::env::G,
}

impl prism_rtl::Job<Map<Text, Array<bool>>> for Layouts {
    fn cycle(&self) -> prism_rtl::Turn<Map<Text, Array<bool>>> {
        let g_p0 = &self.g_p0;
        fold_job(values(&g_p0.ctors), Map::new(), {
            let g_p0 = g_p0.clone();
            Rc::new(move |(p0, p1): (Map<Text, Array<bool>>, crate::check::env::CtorInfo)| {
                let g_p0 = g_p0.clone();
                entered(once_job(move || {
                    let m_p1 = p0;
                    let c_p2 = p1;
                    call_value(each_job(c_p2.args.clone(), {
                        let g_p0 = g_p0.clone();
                        let c_p2 = c_p2.clone();
                        Rc::new(move |p0: crate::check::types::Ty| {
                            let g_p0 = g_p0.clone();
                            let c_p2 = c_p2.clone();
                            entered(once_job(move || {
                                let a_p3 = p0;
                                prism_rtl::Turn::More(Rc::new(Reaches { g_p0: g_p0.clone(), t_p1: a_p3.clone(), target_p2: c_p2.owner.clone(), seen_p3: Array::new() }))
                            }))
                        }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<bool>>>
                    }), move |each_7499: Array<bool>| prism_rtl::Turn::Finished(insert(&m_p1, &c_p2.name, &each_7499)))
                }))
            }) as Rc<dyn Fn((Map<Text, Array<bool>>, crate::check::env::CtorInfo)) -> Rc<dyn prism_rtl::Job<Map<Text, Array<bool>>>>>
        }).cycle()
    }
}

/// `Start Layouts, x`: what the function value is when passed to `@Run`.
pub fn start_layouts(g_p0: crate::check::env::G) -> Rc<dyn prism_rtl::Job<Map<Text, Array<bool>>>> {
    Rc::new(Layouts { g_p0 })
}

/// ```prism
/// Reaches: unbounded fn G, Ty, Text, [Text] -> Bool
/// ```
pub fn reaches(g_p0: &crate::check::env::G, t_p1: &crate::check::types::Ty, target_p2: &Text, seen_p3: &Array<Text>) -> bool {
    match t_p1 {
        crate::check::types::Ty::TyCon(n_p4, args_p5) => if n_p4 == target_p2 {
            true
        } else {
            if crate::check::types::has_text(seen_p3, n_p4) {
                false
            } else {
                if run_to_end(fold_job(args_p5.clone(), false, {
                    let g_p0 = g_p0.clone();
                    let target_p2 = target_p2.clone();
                    let seen_p3 = seen_p3.clone();
                    Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| {
                        let g_p0 = g_p0.clone();
                        let target_p2 = target_p2.clone();
                        let seen_p3 = seen_p3.clone();
                        entered(once_job(move || {
                            let f_p6 = p0;
                            let a_p7 = p1;
                            prism_rtl::Turn::Finished(f_p6 || reaches(&g_p0, &a_p7, &target_p2, &seen_p3))
                        }))
                    }) as Rc<dyn Fn((bool, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<bool>>>
                })) {
                    true
                } else {
                    match get(&g_p0.types, n_p4) {
                        Some(ti_p8) => match &ti_p8.body {
                            crate::check::env::TyBody::BRecord(fs_p9) => run_to_end(fold_job(fs_p9.clone(), false, {
                                let g_p0 = g_p0.clone();
                                let target_p2 = target_p2.clone();
                                let seen_p3 = seen_p3.clone();
                                let n_p4 = n_p4.clone();
                                Rc::new(move |(p0, p1): (bool, (Text, crate::check::types::Ty))| {
                                    let g_p0 = g_p0.clone();
                                    let target_p2 = target_p2.clone();
                                    let seen_p3 = seen_p3.clone();
                                    let n_p4 = n_p4.clone();
                                    entered(once_job(move || {
                                        let f_pa = p0;
                                        let (_, ft_pb) = p1;
                                        prism_rtl::Turn::Finished(f_pa || reaches(&g_p0, &ft_pb, &target_p2, &push(&seen_p3, &n_p4)))
                                    }))
                                }) as Rc<dyn Fn((bool, (Text, crate::check::types::Ty))) -> Rc<dyn prism_rtl::Job<bool>>>
                            })),
                            crate::check::env::TyBody::BChoice(cs_pc) => run_to_end(fold_job(cs_pc.clone(), false, {
                                let g_p0 = g_p0.clone();
                                let target_p2 = target_p2.clone();
                                let seen_p3 = seen_p3.clone();
                                let n_p4 = n_p4.clone();
                                Rc::new(move |(p0, p1): (bool, (Text, Array<crate::check::types::Ty>))| {
                                    let g_p0 = g_p0.clone();
                                    let target_p2 = target_p2.clone();
                                    let seen_p3 = seen_p3.clone();
                                    let n_p4 = n_p4.clone();
                                    entered(once_job(move || {
                                        let f_pd = p0;
                                        let (_, ats_pe) = p1;
                                        prism_rtl::Turn::Finished(f_pd || run_to_end(fold_job(ats_pe.clone(), false, {
                                            let g_p0 = g_p0.clone();
                                            let target_p2 = target_p2.clone();
                                            let seen_p3 = seen_p3.clone();
                                            let n_p4 = n_p4.clone();
                                            Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| {
                                                let g_p0 = g_p0.clone();
                                                let target_p2 = target_p2.clone();
                                                let seen_p3 = seen_p3.clone();
                                                let n_p4 = n_p4.clone();
                                                entered(once_job(move || {
                                                    let f2_pf = p0;
                                                    let at_pg = p1;
                                                    prism_rtl::Turn::Finished(f2_pf || reaches(&g_p0, &at_pg, &target_p2, &push(&seen_p3, &n_p4)))
                                                }))
                                            }) as Rc<dyn Fn((bool, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<bool>>>
                                        })))
                                    }))
                                }) as Rc<dyn Fn((bool, (Text, Array<crate::check::types::Ty>))) -> Rc<dyn prism_rtl::Job<bool>>>
                            })),
                            crate::check::env::TyBody::BAlias(a_ph) => reaches(g_p0, a_ph, target_p2, &push(seen_p3, n_p4)),
                            _ => false,
                        },
                        None => false,
                    }
                }
            }
        },
        crate::check::types::Ty::TySig(m7629_1_0, i_pi) if (m7629_1_0 == &Text::lit("?")) => reaches(g_p0, &**i_pi, target_p2, seen_p3),
        crate::check::types::Ty::TySig(m7629_2_0, i_pj) if (m7629_2_0 == &Text::lit("~")) => reaches(g_p0, &**i_pj, target_p2, seen_p3),
        crate::check::types::Ty::TyTuple(ts_pk) => run_to_end(fold_job(ts_pk.clone(), false, {
            let g_p0 = g_p0.clone();
            let target_p2 = target_p2.clone();
            let seen_p3 = seen_p3.clone();
            Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| {
                let g_p0 = g_p0.clone();
                let target_p2 = target_p2.clone();
                let seen_p3 = seen_p3.clone();
                entered(once_job(move || {
                    let f_pl = p0;
                    let a_pm = p1;
                    prism_rtl::Turn::Finished(f_pl || reaches(&g_p0, &a_pm, &target_p2, &seen_p3))
                }))
            }) as Rc<dyn Fn((bool, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<bool>>>
        })),
        _ => false,
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `Reaches`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Reaches: unbounded fn G, Ty, Text, [Text] -> Bool
/// ```
pub struct Reaches {
    pub g_p0: crate::check::env::G,
    pub t_p1: crate::check::types::Ty,
    pub target_p2: Text,
    pub seen_p3: Array<Text>,
}

impl prism_rtl::Job<bool> for Reaches {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let g_p0 = &self.g_p0;
        let t_p1 = &self.t_p1;
        let target_p2 = &self.target_p2;
        let seen_p3 = &self.seen_p3;
        match t_p1 {
            crate::check::types::Ty::TyCon(n_p4, args_p5) => if n_p4 == target_p2 {
                prism_rtl::Turn::Finished(true)
            } else {
                if crate::check::types::has_text(seen_p3, n_p4) {
                    prism_rtl::Turn::Finished(false)
                } else {
                    {
                        let args_p5 = args_p5.clone();
                        let g_p0 = g_p0.clone();
                        let n_p4 = n_p4.clone();
                        let seen_p3 = seen_p3.clone();
                        let target_p2 = target_p2.clone();
                        call_value(fold_job(args_p5.clone(), false, {
                            let g_p0 = g_p0.clone();
                            let target_p2 = target_p2.clone();
                            let seen_p3 = seen_p3.clone();
                            Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| {
                                let g_p0 = g_p0.clone();
                                let target_p2 = target_p2.clone();
                                let seen_p3 = seen_p3.clone();
                                entered(once_job(move || {
                                    let f_p6 = p0;
                                    let a_p7 = p1;
                                    prism_rtl::Turn::Finished(f_p6 || reaches(&g_p0, &a_p7, &target_p2, &seen_p3))
                                }))
                            }) as Rc<dyn Fn((bool, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<bool>>>
                        }), move |fold_7743: bool| if fold_7743 {
                            prism_rtl::Turn::Finished(true)
                        } else {
                            match get(&g_p0.types, &n_p4) {
                                Some(ti_p8) => match &ti_p8.body {
                                    crate::check::env::TyBody::BRecord(fs_p9) => fold_job(fs_p9.clone(), false, {
                                        let g_p0 = g_p0.clone();
                                        let target_p2 = target_p2.clone();
                                        let seen_p3 = seen_p3.clone();
                                        let n_p4 = n_p4.clone();
                                        Rc::new(move |(p0, p1): (bool, (Text, crate::check::types::Ty))| {
                                            let g_p0 = g_p0.clone();
                                            let target_p2 = target_p2.clone();
                                            let seen_p3 = seen_p3.clone();
                                            let n_p4 = n_p4.clone();
                                            entered(once_job(move || {
                                                let f_pa = p0;
                                                let (_, ft_pb) = p1;
                                                prism_rtl::Turn::Finished(f_pa || reaches(&g_p0, &ft_pb, &target_p2, &push(&seen_p3, &n_p4)))
                                            }))
                                        }) as Rc<dyn Fn((bool, (Text, crate::check::types::Ty))) -> Rc<dyn prism_rtl::Job<bool>>>
                                    }).cycle(),
                                    crate::check::env::TyBody::BChoice(cs_pc) => fold_job(cs_pc.clone(), false, {
                                        let g_p0 = g_p0.clone();
                                        let target_p2 = target_p2.clone();
                                        let seen_p3 = seen_p3.clone();
                                        let n_p4 = n_p4.clone();
                                        Rc::new(move |(p0, p1): (bool, (Text, Array<crate::check::types::Ty>))| {
                                            let g_p0 = g_p0.clone();
                                            let target_p2 = target_p2.clone();
                                            let seen_p3 = seen_p3.clone();
                                            let n_p4 = n_p4.clone();
                                            entered(once_job(move || {
                                                let f_pd = p0;
                                                let (_, ats_pe) = p1;
                                                prism_rtl::Turn::Finished(f_pd || run_to_end(fold_job(ats_pe.clone(), false, {
                                                    let g_p0 = g_p0.clone();
                                                    let target_p2 = target_p2.clone();
                                                    let seen_p3 = seen_p3.clone();
                                                    let n_p4 = n_p4.clone();
                                                    Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| {
                                                        let g_p0 = g_p0.clone();
                                                        let target_p2 = target_p2.clone();
                                                        let seen_p3 = seen_p3.clone();
                                                        let n_p4 = n_p4.clone();
                                                        entered(once_job(move || {
                                                            let f2_pf = p0;
                                                            let at_pg = p1;
                                                            prism_rtl::Turn::Finished(f2_pf || reaches(&g_p0, &at_pg, &target_p2, &push(&seen_p3, &n_p4)))
                                                        }))
                                                    }) as Rc<dyn Fn((bool, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<bool>>>
                                                })))
                                            }))
                                        }) as Rc<dyn Fn((bool, (Text, Array<crate::check::types::Ty>))) -> Rc<dyn prism_rtl::Job<bool>>>
                                    }).cycle(),
                                    crate::check::env::TyBody::BAlias(a_ph) => prism_rtl::Turn::More(Rc::new(Reaches { g_p0: g_p0.clone(), t_p1: a_ph.clone(), target_p2: target_p2.clone(), seen_p3: push(&seen_p3, &n_p4) })),
                                    _ => prism_rtl::Turn::Finished(false),
                                },
                                None => prism_rtl::Turn::Finished(false),
                            }
                        })
                    }
                }
            },
            crate::check::types::Ty::TySig(m7629_1_0, i_pi) if (m7629_1_0 == &Text::lit("?")) => prism_rtl::Turn::More(Rc::new(Reaches { g_p0: g_p0.clone(), t_p1: (**i_pi).clone(), target_p2: target_p2.clone(), seen_p3: seen_p3.clone() })),
            crate::check::types::Ty::TySig(m7629_2_0, i_pj) if (m7629_2_0 == &Text::lit("~")) => prism_rtl::Turn::More(Rc::new(Reaches { g_p0: g_p0.clone(), t_p1: (**i_pj).clone(), target_p2: target_p2.clone(), seen_p3: seen_p3.clone() })),
            crate::check::types::Ty::TyTuple(ts_pk) => fold_job(ts_pk.clone(), false, {
                let g_p0 = g_p0.clone();
                let target_p2 = target_p2.clone();
                let seen_p3 = seen_p3.clone();
                Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| {
                    let g_p0 = g_p0.clone();
                    let target_p2 = target_p2.clone();
                    let seen_p3 = seen_p3.clone();
                    entered(once_job(move || {
                        let f_pl = p0;
                        let a_pm = p1;
                        prism_rtl::Turn::Finished(f_pl || reaches(&g_p0, &a_pm, &target_p2, &seen_p3))
                    }))
                }) as Rc<dyn Fn((bool, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<bool>>>
            }).cycle(),
            _ => prism_rtl::Turn::Finished(false),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start Reaches, x`: what the function value is when passed to `@Run`.
pub fn start_reaches(g_p0: crate::check::env::G, t_p1: crate::check::types::Ty, target_p2: Text, seen_p3: Array<Text>) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(Reaches { g_p0, t_p1, target_p2, seen_p3 })
}

/// ```prism
/// RcField: fn Lx, Text, Nat -> Bool
/// ```
pub fn rc_field(lx_p0: &crate::lower::Lx, ctor_p1: &Text, i_p2: &Nat) -> bool {
    or(&index(&or(&get(&lx_p0.layouts, ctor_p1), &Array::new()), i_p2), &false)
}

/// ```prism
/// Podable: unbounded fn OutTy -> Bool
/// ```
pub fn podable(t_p0: &crate::lower::model::OutTy) -> bool {
    match t_p0 {
        crate::lower::model::OutTy::OutFn(_, _) => false,
        crate::lower::model::OutTy::OutJobFn(_, _) => false,
        crate::lower::model::OutTy::OutJob(_) => false,
        crate::lower::model::OutTy::OutEvent(_) => false,
        crate::lower::model::OutTy::OutDyn(_) => false,
        crate::lower::model::OutTy::OutShowAny => false,
        crate::lower::model::OutTy::OutLive(_) => false,
        crate::lower::model::OutTy::OutUnknown(_) => false,
        crate::lower::model::OutTy::OutGen(_) => true,
        crate::lower::model::OutTy::OutNamed(_, args_p1) => run_to_end(fold_job(args_p1.clone(), true, Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| entered(once_job(move || {
            let ok_p2 = p0;
            let a_p3 = p1;
            prism_rtl::Turn::Finished(ok_p2 && podable(&a_p3))
        }))) as Rc<dyn Fn((bool, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<bool>>>)),
        crate::lower::model::OutTy::OutOpt(i_p4) => podable(&**i_p4),
        crate::lower::model::OutTy::OutRes(i_p5) => podable(&**i_p5),
        crate::lower::model::OutTy::OutRc(i_p6) => podable(&**i_p6),
        crate::lower::model::OutTy::OutTuple(ts_p7) => run_to_end(fold_job(ts_p7.clone(), true, Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| entered(once_job(move || {
            let ok_p8 = p0;
            let a_p9 = p1;
            prism_rtl::Turn::Finished(ok_p8 && podable(&a_p9))
        }))) as Rc<dyn Fn((bool, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<bool>>>)),
        crate::lower::model::OutTy::OutArray(e_pa) => podable(&**e_pa),
        crate::lower::model::OutTy::OutMap(k_pb, v_pc) => podable(&**k_pb) && podable(&**v_pc),
        _ => true,
    }
}

/// The step machine of `Podable`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Podable: unbounded fn OutTy -> Bool
/// ```
pub struct Podable {
    pub t_p0: crate::lower::model::OutTy,
}

impl prism_rtl::Job<bool> for Podable {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let t_p0 = &self.t_p0;
        match t_p0 {
            crate::lower::model::OutTy::OutFn(_, _) => prism_rtl::Turn::Finished(false),
            crate::lower::model::OutTy::OutJobFn(_, _) => prism_rtl::Turn::Finished(false),
            crate::lower::model::OutTy::OutJob(_) => prism_rtl::Turn::Finished(false),
            crate::lower::model::OutTy::OutEvent(_) => prism_rtl::Turn::Finished(false),
            crate::lower::model::OutTy::OutDyn(_) => prism_rtl::Turn::Finished(false),
            crate::lower::model::OutTy::OutShowAny => prism_rtl::Turn::Finished(false),
            crate::lower::model::OutTy::OutLive(_) => prism_rtl::Turn::Finished(false),
            crate::lower::model::OutTy::OutUnknown(_) => prism_rtl::Turn::Finished(false),
            crate::lower::model::OutTy::OutGen(_) => prism_rtl::Turn::Finished(true),
            crate::lower::model::OutTy::OutNamed(_, args_p1) => fold_job(args_p1.clone(), true, Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| entered(once_job(move || {
                let ok_p2 = p0;
                let a_p3 = p1;
                prism_rtl::Turn::Finished(ok_p2 && podable(&a_p3))
            }))) as Rc<dyn Fn((bool, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<bool>>>).cycle(),
            crate::lower::model::OutTy::OutOpt(i_p4) => prism_rtl::Turn::More(Rc::new(Podable { t_p0: (**i_p4).clone() })),
            crate::lower::model::OutTy::OutRes(i_p5) => prism_rtl::Turn::More(Rc::new(Podable { t_p0: (**i_p5).clone() })),
            crate::lower::model::OutTy::OutRc(i_p6) => prism_rtl::Turn::More(Rc::new(Podable { t_p0: (**i_p6).clone() })),
            crate::lower::model::OutTy::OutTuple(ts_p7) => fold_job(ts_p7.clone(), true, Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| entered(once_job(move || {
                let ok_p8 = p0;
                let a_p9 = p1;
                prism_rtl::Turn::Finished(ok_p8 && podable(&a_p9))
            }))) as Rc<dyn Fn((bool, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<bool>>>).cycle(),
            crate::lower::model::OutTy::OutArray(e_pa) => prism_rtl::Turn::More(Rc::new(Podable { t_p0: (**e_pa).clone() })),
            crate::lower::model::OutTy::OutMap(k_pb, v_pc) => {
                let k_pb = (**k_pb).clone();
                let v_pc = (**v_pc).clone();
                call_then(start_podable(k_pb.clone()), move |podable_9199: bool| prism_rtl::Turn::Finished(podable_9199 && podable(&v_pc)))
            },
            _ => prism_rtl::Turn::Finished(true),
        }
    }
}

/// `Start Podable, x`: what the function value is when passed to `@Run`.
pub fn start_podable(t_p0: crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(Podable { t_p0 })
}

/// ```prism
/// RuntimeEq: unbounded fn OutTy -> Bool
/// ```
pub fn runtime_eq(t_p0: &crate::lower::model::OutTy) -> bool {
    match t_p0 {
        crate::lower::model::OutTy::OutDyn(_) => true,
        crate::lower::model::OutTy::OutNamed(_, args_p1) => run_to_end(fold_job(args_p1.clone(), true, Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| entered(once_job(move || {
            let ok_p2 = p0;
            let a_p3 = p1;
            prism_rtl::Turn::Finished(ok_p2 && runtime_eq(&a_p3))
        }))) as Rc<dyn Fn((bool, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<bool>>>)),
        crate::lower::model::OutTy::OutOpt(i_p4) => runtime_eq(&**i_p4),
        crate::lower::model::OutTy::OutRes(i_p5) => runtime_eq(&**i_p5),
        crate::lower::model::OutTy::OutRc(i_p6) => runtime_eq(&**i_p6),
        crate::lower::model::OutTy::OutTuple(ts_p7) => run_to_end(fold_job(ts_p7.clone(), true, Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| entered(once_job(move || {
            let ok_p8 = p0;
            let a_p9 = p1;
            prism_rtl::Turn::Finished(ok_p8 && runtime_eq(&a_p9))
        }))) as Rc<dyn Fn((bool, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<bool>>>)),
        crate::lower::model::OutTy::OutArray(e_pa) => runtime_eq(&**e_pa),
        crate::lower::model::OutTy::OutMap(k_pb, v_pc) => runtime_eq(&**k_pb) && runtime_eq(&**v_pc),
        other_pd => podable(other_pd),
    }
}

/// The step machine of `RuntimeEq`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RuntimeEq: unbounded fn OutTy -> Bool
/// ```
pub struct RuntimeEq {
    pub t_p0: crate::lower::model::OutTy,
}

impl prism_rtl::Job<bool> for RuntimeEq {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let t_p0 = &self.t_p0;
        match t_p0 {
            crate::lower::model::OutTy::OutDyn(_) => prism_rtl::Turn::Finished(true),
            crate::lower::model::OutTy::OutNamed(_, args_p1) => fold_job(args_p1.clone(), true, Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| entered(once_job(move || {
                let ok_p2 = p0;
                let a_p3 = p1;
                prism_rtl::Turn::Finished(ok_p2 && runtime_eq(&a_p3))
            }))) as Rc<dyn Fn((bool, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<bool>>>).cycle(),
            crate::lower::model::OutTy::OutOpt(i_p4) => prism_rtl::Turn::More(Rc::new(RuntimeEq { t_p0: (**i_p4).clone() })),
            crate::lower::model::OutTy::OutRes(i_p5) => prism_rtl::Turn::More(Rc::new(RuntimeEq { t_p0: (**i_p5).clone() })),
            crate::lower::model::OutTy::OutRc(i_p6) => prism_rtl::Turn::More(Rc::new(RuntimeEq { t_p0: (**i_p6).clone() })),
            crate::lower::model::OutTy::OutTuple(ts_p7) => fold_job(ts_p7.clone(), true, Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| entered(once_job(move || {
                let ok_p8 = p0;
                let a_p9 = p1;
                prism_rtl::Turn::Finished(ok_p8 && runtime_eq(&a_p9))
            }))) as Rc<dyn Fn((bool, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<bool>>>).cycle(),
            crate::lower::model::OutTy::OutArray(e_pa) => prism_rtl::Turn::More(Rc::new(RuntimeEq { t_p0: (**e_pa).clone() })),
            crate::lower::model::OutTy::OutMap(k_pb, v_pc) => {
                let k_pb = (**k_pb).clone();
                let v_pc = (**v_pc).clone();
                call_then(start_runtime_eq(k_pb.clone()), move |runtime_eq_9831: bool| prism_rtl::Turn::Finished(runtime_eq_9831 && runtime_eq(&v_pc)))
            },
            other_pd => prism_rtl::Turn::More(Rc::new(Podable { t_p0: other_pd.clone() })),
        }
    }
}

/// `Start RuntimeEq, x`: what the function value is when passed to `@Run`.
pub fn start_runtime_eq(t_p0: crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(RuntimeEq { t_p0 })
}

/// ```prism
/// HoldsDyn: unbounded fn OutTy -> Bool
/// ```
pub fn holds_dyn(t_p0: &crate::lower::model::OutTy) -> bool {
    match t_p0 {
        crate::lower::model::OutTy::OutDyn(_) => true,
        crate::lower::model::OutTy::OutNamed(_, args_p1) => run_to_end(fold_job(args_p1.clone(), false, Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| entered(once_job(move || {
            let f_p2 = p0;
            let a_p3 = p1;
            prism_rtl::Turn::Finished(f_p2 || holds_dyn(&a_p3))
        }))) as Rc<dyn Fn((bool, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<bool>>>)),
        crate::lower::model::OutTy::OutOpt(i_p4) => holds_dyn(&**i_p4),
        crate::lower::model::OutTy::OutRes(i_p5) => holds_dyn(&**i_p5),
        crate::lower::model::OutTy::OutRc(i_p6) => holds_dyn(&**i_p6),
        crate::lower::model::OutTy::OutTuple(ts_p7) => run_to_end(fold_job(ts_p7.clone(), false, Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| entered(once_job(move || {
            let f_p8 = p0;
            let a_p9 = p1;
            prism_rtl::Turn::Finished(f_p8 || holds_dyn(&a_p9))
        }))) as Rc<dyn Fn((bool, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<bool>>>)),
        crate::lower::model::OutTy::OutArray(e_pa) => holds_dyn(&**e_pa),
        crate::lower::model::OutTy::OutMap(k_pb, v_pc) => holds_dyn(&**k_pb) || holds_dyn(&**v_pc),
        _ => false,
    }
}

/// The step machine of `HoldsDyn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// HoldsDyn: unbounded fn OutTy -> Bool
/// ```
pub struct HoldsDyn {
    pub t_p0: crate::lower::model::OutTy,
}

impl prism_rtl::Job<bool> for HoldsDyn {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let t_p0 = &self.t_p0;
        match t_p0 {
            crate::lower::model::OutTy::OutDyn(_) => prism_rtl::Turn::Finished(true),
            crate::lower::model::OutTy::OutNamed(_, args_p1) => fold_job(args_p1.clone(), false, Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| entered(once_job(move || {
                let f_p2 = p0;
                let a_p3 = p1;
                prism_rtl::Turn::Finished(f_p2 || holds_dyn(&a_p3))
            }))) as Rc<dyn Fn((bool, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<bool>>>).cycle(),
            crate::lower::model::OutTy::OutOpt(i_p4) => prism_rtl::Turn::More(Rc::new(HoldsDyn { t_p0: (**i_p4).clone() })),
            crate::lower::model::OutTy::OutRes(i_p5) => prism_rtl::Turn::More(Rc::new(HoldsDyn { t_p0: (**i_p5).clone() })),
            crate::lower::model::OutTy::OutRc(i_p6) => prism_rtl::Turn::More(Rc::new(HoldsDyn { t_p0: (**i_p6).clone() })),
            crate::lower::model::OutTy::OutTuple(ts_p7) => fold_job(ts_p7.clone(), false, Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| entered(once_job(move || {
                let f_p8 = p0;
                let a_p9 = p1;
                prism_rtl::Turn::Finished(f_p8 || holds_dyn(&a_p9))
            }))) as Rc<dyn Fn((bool, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<bool>>>).cycle(),
            crate::lower::model::OutTy::OutArray(e_pa) => prism_rtl::Turn::More(Rc::new(HoldsDyn { t_p0: (**e_pa).clone() })),
            crate::lower::model::OutTy::OutMap(k_pb, v_pc) => {
                let k_pb = (**k_pb).clone();
                let v_pc = (**v_pc).clone();
                call_then(start_holds_dyn(k_pb.clone()), move |holds_dyn_10293: bool| prism_rtl::Turn::Finished(holds_dyn_10293 || holds_dyn(&v_pc)))
            },
            _ => prism_rtl::Turn::Finished(false),
        }
    }
}

/// `Start HoldsDyn, x`: what the function value is when passed to `@Run`.
pub fn start_holds_dyn(t_p0: crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(HoldsDyn { t_p0 })
}

/// ```prism
/// let emptyEnv
/// ```
pub fn empty_env() -> Env {
    Env { names: Map::new(), spans: Map::new(), uses: Map::new() }
}

/// ```prism
/// NameKeyAt: fn Lx, Env, SName, Range -> Text
/// ```
pub fn name_key_at(lx_p0: &crate::lower::Lx, env_p1: &Env, n_p2: &crate::syntax::SName, span_p3: &crate::syntax::Range) -> Text {
    match get(&lx_p0.use_insts, &crate::lower::place_key(lx_p0, span_p3)) {
        Some(u_p4) => or(&get(&env_p1.uses, &Text::from(format!("{}#{}", &crate::check::env::sname_key(n_p2), &show_text(&crate::lower::expr::inst_at(lx_p0, &u_p4))))), &crate::check::env::sname_key(n_p2)),
        None => crate::check::env::sname_key(n_p2),
    }
}

/// ```prism
/// WithInstances: fn Env, [Text] -> [Text]
/// ```
pub fn with_instances(env_p0: &Env, names_p1: &Array<Text>) -> Array<Text> {
    fold(names_p1, names_p1, &(|acc_p2: &Array<Text>, n_p3: &Text| append(acc_p2, &filter(&keys(&env_p0.names), &(|k_p4: &Text| crate::syntax::lexer::chars::has_prefix(k_p4, &Text::from(format!("{}#inst", n_p3))))))))
}

/// ```prism
/// BindSpan: fn Env, Text, Vl -> Env
/// ```
pub fn bind_span(env_p0: &Env, nkey_p1: &Text, v_p2: &Vl) -> Env {
    let mut this: Env = env_p0.clone();
    this.spans = insert(&this.spans, nkey_p1, v_p2);
    this
}

/// ```prism
/// Bind: fn Env, Text, Bn -> Env
/// ```
pub fn bind(env_p0: &Env, name_p1: &Text, b_p2: &Bn) -> Env {
    let mut this: Env = env_p0.clone();
    this.names = insert(&this.names, name_p1, b_p2);
    this
}

/// ```prism
/// ValueTy: fn Vl -> OutTy
/// ```
pub fn value_ty(vl0: &Vl) -> crate::lower::model::OutTy {
    match vl0 {
        Vl::VlPlace(_, _, t_p0) => t_p0.clone(),
        Vl::VlOwned(_, t_p1) => t_p1.clone(),
    }
}

/// ```prism
/// LocalPlace: fn Ex, Holding, OutTy -> Vl
/// ```
pub fn local_place(x_p0: &crate::lower::model::Ex, mode_p1: &Holding, t_p2: &crate::lower::model::OutTy) -> Vl {
    Vl::VlPlace(x_p0.clone(), mode_p1.clone(), t_p2.clone())
}

/// ```prism
/// PlaceStem: fn Ex -> Text
/// ```
pub fn place_stem(x_p0: &crate::lower::model::Ex) -> Text {
    match x_p0 {
        crate::lower::model::Ex::XVar(n_p1) => n_p1.clone(),
        crate::lower::model::Ex::XField(_, f_p2) => f_p2.clone(),
        crate::lower::model::Ex::XTarget(y_p3) => place_stem(&**y_p3),
        crate::lower::model::Ex::XPart(y_p4, k_p5) => Text::from(format!("{}_{}", &place_stem(&**y_p4), k_p5)),
        _ => Text::lit("place"),
    }
}

/// ```prism
/// OnSelf: fn Ex -> Bool
/// ```
pub fn on_self(x_p0: &crate::lower::model::Ex) -> bool {
    'm13782: {
        if let crate::lower::model::Ex::XField(m13782_0_0, _) = x_p0 && let crate::lower::model::Ex::XSelf = &**m13782_0_0 {
            break 'm13782 true;
        }
        if let crate::lower::model::Ex::XField(y_p1, _) = x_p0 {
            break 'm13782 on_self(&**y_p1);
        }
        if let crate::lower::model::Ex::XPart(y_p2, _) = x_p0 {
            break 'm13782 on_self(&**y_p2);
        }
        if let crate::lower::model::Ex::XMethod(y_p3, _, _) = x_p0 {
            break 'm13782 on_self(&**y_p3);
        }
        if let crate::lower::model::Ex::XUpgrade(y_p4) = x_p0 {
            break 'm13782 on_self(&**y_p4);
        }
        false
    }
}

/// ```prism
/// ?ThroughParent: fn Ex -> ?Ex
/// ```
pub fn through_parent(x_p0: &crate::lower::model::Ex) -> Option<crate::lower::model::Ex> {
    'm14186: {
        if let crate::lower::model::Ex::XField(m14186_0_0, m14186_0_1) = x_p0 && let crate::lower::model::Ex::XSelf = &**m14186_0_0 && (m14186_0_1 == &Text::lit("parent")) {
            break 'm14186 Some(crate::lower::model::Ex::XVar(Text::lit("parent")));
        }
        if let crate::lower::model::Ex::XField(y_p1, f_p2) = x_p0 {
            break 'm14186 match through_parent(&**y_p1) {
                Some(z_p3) => Some(crate::lower::model::Ex::XField(Rc::new(z_p3), f_p2.clone())),
                None => None,
            };
        }
        if let crate::lower::model::Ex::XPart(y_p4, k_p5) = x_p0 {
            break 'm14186 match through_parent(&**y_p4) {
                Some(z_p6) => Some(crate::lower::model::Ex::XPart(Rc::new(z_p6), k_p5.clone())),
                None => None,
            };
        }
        if let crate::lower::model::Ex::XMethod(y_p7, m_p8, xs_p9) = x_p0 {
            break 'm14186 match through_parent(&**y_p7) {
                Some(z_pa) => Some(crate::lower::model::Ex::XMethod(Rc::new(z_pa), m_p8.clone(), xs_p9.clone())),
                None => None,
            };
        }
        if let crate::lower::model::Ex::XUpgrade(y_pb) = x_p0 {
            break 'm14186 match through_parent(&**y_pb) {
                Some(z_pc) => Some(crate::lower::model::Ex::XUpgrade(Rc::new(z_pc))),
                None => None,
            };
        }
        None
    }
}

/// ```prism
/// Own: fn Vl -> Ex
/// ```
pub fn own(vl0: &Vl) -> crate::lower::model::Ex {
    match vl0 {
        Vl::VlPlace(x_p0, Holding::RcRef, _) => crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XDeref(Rc::new(crate::lower::model::Ex::XDeref(Rc::new(x_p0.clone())))))),
        Vl::VlPlace(x_p1, Holding::RcOwned, _) => crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XDeref(Rc::new(x_p1.clone())))),
        Vl::VlPlace(x_p2, mode_p3, t_p4) => if is_copy(t_p4) {
            copy(&Vl::VlPlace(x_p2.clone(), mode_p3.clone(), t_p4.clone()))
        } else {
            crate::lower::model::Ex::XClone(Rc::new(x_p2.clone()))
        },
        Vl::VlOwned(e_p5, _) => e_p5.clone(),
    }
}

/// ```prism
/// Ref: fn Vl -> Ex
/// ```
pub fn ref_(vl0: &Vl) -> crate::lower::model::Ex {
    match vl0 {
        Vl::VlPlace(x_p0, Holding::ByRef, _) => x_p0.clone(),
        Vl::VlPlace(x_p1, Holding::RcRef, _) => crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XDeref(Rc::new(crate::lower::model::Ex::XDeref(Rc::new(x_p1.clone())))))),
        Vl::VlPlace(x_p2, Holding::RcOwned, _) => crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XDeref(Rc::new(x_p2.clone())))),
        Vl::VlPlace(x_p3, _, _) => crate::lower::model::Ex::XRef(Rc::new(x_p3.clone())),
        Vl::VlOwned(e_p4, _) => crate::lower::model::Ex::XRef(Rc::new(e_p4.clone())),
    }
}

/// ```prism
/// Copy: fn Vl -> Ex
/// ```
pub fn copy(vl0: &Vl) -> crate::lower::model::Ex {
    match vl0 {
        Vl::VlPlace(x_p0, Holding::ByRef, _) => crate::lower::model::Ex::XDeref(Rc::new(x_p0.clone())),
        Vl::VlPlace(x_p1, Holding::RcRef, _) => crate::lower::model::Ex::XDeref(Rc::new(crate::lower::model::Ex::XDeref(Rc::new(crate::lower::model::Ex::XDeref(Rc::new(x_p1.clone())))))),
        Vl::VlPlace(x_p2, _, _) => x_p2.clone(),
        Vl::VlOwned(e_p3, _) => e_p3.clone(),
    }
}

/// ```prism
/// IsCopy: fn OutTy -> Bool
/// ```
pub fn is_copy(t_p0: &crate::lower::model::OutTy) -> bool {
    ((((t_p0 == &crate::lower::model::OutTy::OutBool) || (t_p0 == &crate::lower::model::OutTy::OutFloat)) || (t_p0 == &crate::lower::model::OutTy::OutU8)) || (t_p0 == &crate::lower::model::OutTy::OutChar)) || (t_p0 == &crate::lower::model::OutTy::OutUnit)
}

/// ```prism
/// AsBool: fn Vl -> Ex
/// ```
pub fn as_bool(v_p0: &Vl) -> crate::lower::model::Ex {
    copy(v_p0)
}
