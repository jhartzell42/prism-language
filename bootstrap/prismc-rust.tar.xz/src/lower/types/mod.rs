//! The module `Lower.Types`, from `target/bootstrap/src/prismc/lower/types.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file. The runtime
//! side is reached from the crate, `crate::prelude` (and through it `::prism_rtl`), the
//! standard library from `::std`, and nothing is imported by name: a program's own type
//! (`Row`, `Option`) hides none of theirs. The traits are in scope unnamed, for their methods.

use crate::prelude::traits::*;

/// `Bn`:
///
/// ```prism
/// type Bn = choice:
/// ```
#[derive(::std::clone::Clone)]
pub enum Bn {
    BnLocal(crate::lower::model::Ex, Holding, crate::lower::model::OutTy),
    BnHold(crate::prelude::Text, crate::lower::model::OutTy),
    BnDyn(crate::lower::model::Ex, crate::prelude::Array<crate::lower::node_::Read>, crate::lower::model::OutTy),
    BnEv(crate::lower::node_::EvRef, crate::lower::model::OutTy),
    BnParts(crate::prelude::Array<::std::option::Option<Bn>>),
    BnWidget(crate::syntax::Expr, Env, Env, crate::lower::Lx),
    BnLocalFn(crate::prelude::Array<crate::syntax::decls::FnClause>),
    BnLocalWidget(crate::syntax::Block),
}

/// `Env`:
///
/// ```prism
/// type Env = record:
/// ```
#[derive(::std::clone::Clone)]
pub struct Env {
    pub names_p: crate::prelude::Map<crate::prelude::Text, Bn>,
    pub spans_p: crate::prelude::Map<crate::prelude::Text, Vl>,
    pub uses_p: crate::prelude::Map<crate::prelude::Text, crate::prelude::Text>,
}

/// `Holding`:
///
/// ```prism
/// type Holding = choice:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub enum Holding {
    ByRef,
    Owned,
    RcRef,
    RcOwned,
}

impl crate::prelude::Show for Holding {
    fn show(&self, p: &mut crate::prelude::Printer) {
        match self {
            Holding::ByRef => p.choice("ByRef", &[]),
            Holding::Owned => p.choice("Owned", &[]),
            Holding::RcRef => p.choice("RcRef", &[]),
            Holding::RcOwned => p.choice("RcOwned", &[]),
        }
    }
}

impl crate::prelude::ToPod for Holding {
    fn to_pod(&self) -> crate::prelude::Pod {
        match self {
            Holding::ByRef => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("ByRef", 0), vec![]),
            Holding::Owned => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("Owned", 1), vec![]),
            Holding::RcRef => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("RcRef", 2), vec![]),
            Holding::RcOwned => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("RcOwned", 3), vec![]),
        }
    }
}

impl crate::prelude::FromPod for Holding {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        match p.structure() {
            crate::prelude::Pod::Choice(c, a) if &**c == "ByRef" && a.len() == 0 => ::std::result::Result::Ok(Holding::ByRef),
            crate::prelude::Pod::Choice(c, a) if &**c == "Owned" && a.len() == 0 => ::std::result::Result::Ok(Holding::Owned),
            crate::prelude::Pod::Choice(c, a) if &**c == "RcRef" && a.len() == 0 => ::std::result::Result::Ok(Holding::RcRef),
            crate::prelude::Pod::Choice(c, a) if &**c == "RcOwned" && a.len() == 0 => ::std::result::Result::Ok(Holding::RcOwned),
            other => ::prism_rtl::pod::mismatch("a Holding", other),
        }
    }
}

/// `Layer`:
///
/// ```prism
/// type Layer = choice:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub enum Layer {
    LyPlain,
    LyDyn,
    LyEv,
    LyBlueprint,
}

impl crate::prelude::Show for Layer {
    fn show(&self, p: &mut crate::prelude::Printer) {
        match self {
            Layer::LyPlain => p.choice("LyPlain", &[]),
            Layer::LyDyn => p.choice("LyDyn", &[]),
            Layer::LyEv => p.choice("LyEv", &[]),
            Layer::LyBlueprint => p.choice("LyBlueprint", &[]),
        }
    }
}

impl crate::prelude::ToPod for Layer {
    fn to_pod(&self) -> crate::prelude::Pod {
        match self {
            Layer::LyPlain => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("LyPlain", 0), vec![]),
            Layer::LyDyn => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("LyDyn", 1), vec![]),
            Layer::LyEv => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("LyEv", 2), vec![]),
            Layer::LyBlueprint => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("LyBlueprint", 3), vec![]),
        }
    }
}

impl crate::prelude::FromPod for Layer {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        match p.structure() {
            crate::prelude::Pod::Choice(c, a) if &**c == "LyPlain" && a.len() == 0 => ::std::result::Result::Ok(Layer::LyPlain),
            crate::prelude::Pod::Choice(c, a) if &**c == "LyDyn" && a.len() == 0 => ::std::result::Result::Ok(Layer::LyDyn),
            crate::prelude::Pod::Choice(c, a) if &**c == "LyEv" && a.len() == 0 => ::std::result::Result::Ok(Layer::LyEv),
            crate::prelude::Pod::Choice(c, a) if &**c == "LyBlueprint" && a.len() == 0 => ::std::result::Result::Ok(Layer::LyBlueprint),
            other => ::prism_rtl::pod::mismatch("a Layer", other),
        }
    }
}

/// `Vl`:
///
/// ```prism
/// type Vl = choice:
/// ```
#[derive(::std::clone::Clone)]
pub enum Vl {
    VlPlace(crate::lower::model::Ex, Holding, crate::lower::model::OutTy),
    VlOwned(crate::lower::model::Ex, crate::lower::model::OutTy),
}

impl crate::prelude::ToPod for Vl {
    fn to_pod(&self) -> crate::prelude::Pod {
        match self {
            Vl::VlPlace(a0, a1, a2) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("VlPlace", 0), vec![a0.to_pod(), a1.to_pod(), a2.to_pod()]),
            Vl::VlOwned(a0, a1) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("VlOwned", 1), vec![a0.to_pod(), a1.to_pod()]),
        }
    }
}

impl crate::prelude::FromPod for Vl {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        match p.structure() {
            crate::prelude::Pod::Choice(c, a) if &**c == "VlPlace" && a.len() == 3 => ::std::result::Result::Ok(Vl::VlPlace(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?, crate::prelude::FromPod::from_pod(&a[2])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "VlOwned" && a.len() == 2 => ::std::result::Result::Ok(Vl::VlOwned(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?)),
            other => ::prism_rtl::pod::mismatch("a Vl", other),
        }
    }
}

/// ```prism
/// OutTyOf: unbounded fn Lx, Ty -> OutTy
/// ```
pub fn out_ty_of_f(lx_p0: &crate::lower::Lx, t_p1: &crate::check::types::Ty) -> crate::lower::model::OutTy {
    'm1375: {
        if let crate::check::types::Ty::TyCon(m1375_0_0, m1375_0_1) = t_p1 && (m1375_0_0 == &crate::prelude::Text::lit("Nat")) && (m1375_0_1.len() == 0) {
            break 'm1375 crate::lower::model::OutTy::OutNat;
        }
        if let crate::check::types::Ty::TyCon(m1375_1_0, m1375_1_1) = t_p1 && (m1375_1_0 == &crate::prelude::Text::lit("Int")) && (m1375_1_1.len() == 0) {
            break 'm1375 crate::lower::model::OutTy::OutInt;
        }
        if let crate::check::types::Ty::TyCon(m1375_2_0, m1375_2_1) = t_p1 && (m1375_2_0 == &crate::prelude::Text::lit("U8")) && (m1375_2_1.len() == 0) {
            break 'm1375 crate::lower::model::OutTy::OutU8;
        }
        if let crate::check::types::Ty::TyCon(m1375_3_0, m1375_3_1) = t_p1 && (m1375_3_0 == &crate::prelude::Text::lit("Float")) && (m1375_3_1.len() == 0) {
            break 'm1375 crate::lower::model::OutTy::OutFloat;
        }
        if let crate::check::types::Ty::TyCon(m1375_4_0, m1375_4_1) = t_p1 && (m1375_4_0 == &crate::prelude::Text::lit("Bool")) && (m1375_4_1.len() == 0) {
            break 'm1375 crate::lower::model::OutTy::OutBool;
        }
        if let crate::check::types::Ty::TyCon(m1375_5_0, m1375_5_1) = t_p1 && (m1375_5_0 == &crate::prelude::Text::lit("Char")) && (m1375_5_1.len() == 0) {
            break 'm1375 crate::lower::model::OutTy::OutChar;
        }
        if let crate::check::types::Ty::TyCon(m1375_6_0, m1375_6_1) = t_p1 && (m1375_6_0 == &crate::prelude::Text::lit("Text")) && (m1375_6_1.len() == 0) {
            break 'm1375 crate::lower::model::OutTy::OutText;
        }
        if let crate::check::types::Ty::TyCon(m1375_7_0, m1375_7_1) = t_p1 && (m1375_7_0 == &crate::prelude::Text::lit("unit")) && (m1375_7_1.len() == 0) {
            break 'm1375 crate::lower::model::OutTy::OutUnit;
        }
        if let crate::check::types::Ty::TyCon(m1375_8_0, m1375_8_1) = t_p1 && (m1375_8_0 == &crate::prelude::Text::lit("Path")) && (m1375_8_1.len() == 0) {
            break 'm1375 crate::lower::model::OutTy::OutPath;
        }
        if let crate::check::types::Ty::TyCon(m1375_9_0, m1375_9_1) = t_p1 && (m1375_9_0 == &crate::prelude::Text::lit("Cursor")) && (m1375_9_1.len() == 0) {
            break 'm1375 crate::lower::model::OutTy::OutCursor;
        }
        if let crate::check::types::Ty::TyCon(m1375_10_0, m1375_10_1) = t_p1 && (m1375_10_0 == &crate::prelude::Text::lit("Regex")) && (m1375_10_1.len() == 0) {
            break 'm1375 crate::lower::model::OutTy::OutRegex;
        }
        if let crate::check::types::Ty::TyCon(m1375_11_0, m1375_11_1) = t_p1 && (m1375_11_0 == &crate::prelude::Text::lit("RegexReplacement")) && (m1375_11_1.len() == 0) {
            break 'm1375 crate::lower::model::OutTy::OutReplacement;
        }
        if let crate::check::types::Ty::TyCon(m1375_12_0, m1375_12_1) = t_p1 && (m1375_12_0 == &crate::prelude::Text::lit("Duration")) && (m1375_12_1.len() == 0) {
            break 'm1375 crate::lower::model::OutTy::OutDuration;
        }
        if let crate::check::types::Ty::TyCon(m1375_13_0, _) = t_p1 && (m1375_13_0 == &crate::prelude::Text::lit("Answer")) {
            break 'm1375 answer_ty_p();
        }
        if let crate::check::types::Ty::TyCon(m1375_14_0, m1375_14_1) = t_p1 && (m1375_14_0 == &crate::prelude::Text::lit("Wired")) && (m1375_14_1.len() == 0) {
            break 'm1375 crate::lower::model::OutTy::OutNamed(crate::lower::model::elem_ref_p(), crate::prelude::Array::new());
        }
        if let crate::check::types::Ty::TyCon(m1375_15_0, m1375_15_1) = t_p1 && (m1375_15_0 == &crate::prelude::Text::lit("Prelude.Error")) && (m1375_15_1.len() == 0) {
            break 'm1375 crate::lower::model::OutTy::OutError;
        }
        if let crate::check::types::Ty::TyCon(m1375_16_0, m1375_16_1) = t_p1 && (m1375_16_0 == &crate::prelude::Text::lit("Prelude.NonEmpty")) && (m1375_16_1.len() == 1) && let ::std::option::Option::Some(c_p2) = crate::prelude::index(m1375_16_1, &crate::prelude::Nat::from(0u32)) {
            break 'm1375 non_empty_out_f(&out_ty_of_f(lx_p0, &c_p2));
        }
        if let crate::check::types::Ty::TyCon(m1375_17_0, m1375_17_1) = t_p1 && (m1375_17_0 == &crate::prelude::Text::lit("\0Self")) && (m1375_17_1.len() == 0) {
            break 'm1375 crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("Self")), crate::prelude::Array::new());
        }
        if let crate::check::types::Ty::TyCon(m1375_18_0, m1375_18_1) = t_p1 && (m1375_18_0 == &crate::prelude::Text::lit("Buffer")) && (m1375_18_1.len() == 1) && let ::std::option::Option::Some(a_p3) = crate::prelude::index(m1375_18_1, &crate::prelude::Nat::from(0u32)) {
            break 'm1375 crate::lower::model::OutTy::OutArray(::std::rc::Rc::new(out_ty_of_f(lx_p0, &a_p3)));
        }
        if let crate::check::types::Ty::TyCon(m1375_19_0, m1375_19_1) = t_p1 && (m1375_19_0 == &crate::prelude::Text::lit("Table")) && (m1375_19_1.len() == 2) && let ::std::option::Option::Some(k_p4) = crate::prelude::index(m1375_19_1, &crate::prelude::Nat::from(0u32)) && let ::std::option::Option::Some(v_p5) = crate::prelude::index(m1375_19_1, &crate::prelude::Nat::from(1u32)) {
            break 'm1375 crate::lower::model::OutTy::OutArray(::std::rc::Rc::new(crate::lower::model::OutTy::OutTuple(crate::prelude::Array::from(vec![out_ty_of_f(lx_p0, &k_p4), out_ty_of_f(lx_p0, &v_p5)]))));
        }
        if let crate::check::types::Ty::TyCon(m1375_20_0, m1375_20_1) = t_p1 && (m1375_20_0 == &crate::prelude::Text::lit("\0Event")) && (m1375_20_1.len() == 1) && let ::std::option::Option::Some(a_p6) = crate::prelude::index(m1375_20_1, &crate::prelude::Nat::from(0u32)) {
            break 'm1375 crate::lower::model::OutTy::OutEvent(::std::rc::Rc::new(out_ty_of_f(lx_p0, &a_p6)));
        }
        if let crate::check::types::Ty::TyCon(n_p7, args_p8) = t_p1 {
            break 'm1375 named_ty_f(lx_p0, n_p7, &crate::prelude::run_to_end(crate::prelude::each_job(args_p8.clone(), {
                let lx_p0x = lx_p0.clone();
                ::std::rc::Rc::new(move |p0: crate::check::types::Ty| {
                    let lx_p0xy = lx_p0x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let a_p9 = p0;
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(OutTyOf { lx_p0: lx_p0xy.clone(), t_p1: a_p9.clone() }))
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::OutTy>>>
            })));
        }
        if let crate::check::types::Ty::TyFn(c_pa, ps_pb, res_pc) = t_p1 {
            break 'm1375 {
                let c2_pd = crate::lower::inst_col_f(lx_p0, c_pa);
                if &c2_pd == &crate::check::types::Col::CBound {
                    crate::lower::model::OutTy::OutFn(crate::prelude::run_to_end(crate::prelude::each_job(ps_pb.clone(), {
                        let lx_p0x = lx_p0.clone();
                        ::std::rc::Rc::new(move |p0: crate::check::types::Ty| {
                            let lx_p0xy = lx_p0x.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let p_pe = p0;
                                ::prism_rtl::Turn::More(::std::rc::Rc::new(OutTyOf { lx_p0: lx_p0xy.clone(), t_p1: p_pe.clone() }))
                            }))
                        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::OutTy>>>
                    })), ::std::rc::Rc::new(out_ty_of_f(lx_p0, &**res_pc)))
                } else {
                    if crate::lower::is_quant_col_f(lx_p0, &c2_pd) {
                        crate::lower::model::OutTy::OutQuantified(crate::prelude::or(&crate::prelude::get(&lx_p0.quants_p, &crate::lower::expr::col_name_f(&c2_pd)), &crate::prelude::Text::lit("")))
                    } else {
                        crate::lower::model::OutTy::OutJobFn(::std::rc::Rc::new(rust_ty_of_params_f(lx_p0, &crate::prelude::each(ps_pb, &(|p_pf: &crate::check::types::Ty| job_param_f(p_pf))))), ::std::rc::Rc::new(out_ty_of_f(lx_p0, &**res_pc)))
                    }
                }
            };
        }
        if let crate::check::types::Ty::TyTuple(m1375_23_0) = t_p1 && (m1375_23_0.len() == 0) {
            break 'm1375 crate::lower::model::OutTy::OutUnit;
        }
        if let crate::check::types::Ty::TyTuple(ts_pg) = t_p1 {
            break 'm1375 crate::lower::model::OutTy::OutTuple(crate::prelude::run_to_end(crate::prelude::each_job(ts_pg.clone(), {
                let lx_p0x = lx_p0.clone();
                ::std::rc::Rc::new(move |p0: crate::check::types::Ty| {
                    let lx_p0xy = lx_p0x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let a_ph = p0;
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(OutTyOf { lx_p0: lx_p0xy.clone(), t_p1: a_ph.clone() }))
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::OutTy>>>
            })));
        }
        if let crate::check::types::Ty::TyArray(e_pi) = t_p1 {
            break 'm1375 crate::lower::model::OutTy::OutArray(::std::rc::Rc::new(out_ty_of_f(lx_p0, &**e_pi)));
        }
        if let crate::check::types::Ty::TyMap(k_pj, v_pk) = t_p1 {
            break 'm1375 crate::lower::model::OutTy::OutMap(::std::rc::Rc::new(out_ty_of_f(lx_p0, &**k_pj)), ::std::rc::Rc::new(out_ty_of_f(lx_p0, &**v_pk)));
        }
        if let crate::check::types::Ty::TySig(m1375_27_0, i_pl) = t_p1 && (m1375_27_0 == &crate::prelude::Text::lit("?")) {
            break 'm1375 crate::lower::model::OutTy::OutOpt(::std::rc::Rc::new(out_ty_of_f(lx_p0, &**i_pl)));
        }
        if let crate::check::types::Ty::TySig(m1375_28_0, i_pm) = t_p1 && (m1375_28_0 == &crate::prelude::Text::lit("~")) {
            break 'm1375 crate::lower::model::OutTy::OutRes(::std::rc::Rc::new(out_ty_of_f(lx_p0, &**i_pm)));
        }
        if let crate::check::types::Ty::TySig(m1375_29_0, i_pn) = t_p1 && (m1375_29_0 == &crate::prelude::Text::lit("!")) {
            break 'm1375 crate::lower::model::OutTy::OutEvent(::std::rc::Rc::new(out_ty_of_f(lx_p0, &**i_pn)));
        }
        if let crate::check::types::Ty::TySig(m1375_30_0, i_po) = t_p1 && (m1375_30_0 == &crate::prelude::Text::lit("$")) {
            break 'm1375 crate::lower::model::OutTy::OutDyn(::std::rc::Rc::new(out_ty_of_f(lx_p0, &**i_po)));
        }
        if let crate::check::types::Ty::TySig(m1375_31_0, i_pp) = t_p1 && (m1375_31_0 == &crate::prelude::Text::lit("&")) {
            break 'm1375 out_ty_of_f(lx_p0, &**i_pp);
        }
        if let crate::check::types::Ty::TySig(_, i_pq) = t_p1 {
            break 'm1375 out_ty_of_f(lx_p0, &**i_pq);
        }
        if let crate::check::types::Ty::TyQ(n_pr) = t_p1 {
            break 'm1375 match crate::prelude::get(&lx_p0.subst_p, n_pr) {
                ::std::option::Option::Some(x_ps) => out_ty_of_f(lx_p0, &x_ps),
                ::std::option::Option::None => crate::lower::model::OutTy::OutGen(crate::lower::camel_f(n_pr)),
            };
        }
        if let crate::check::types::Ty::TyRigid(n_pt) = t_p1 {
            break 'm1375 match crate::prelude::get(&lx_p0.subst_p, n_pt) {
                ::std::option::Option::Some(x_pu) => out_ty_of_f(lx_p0, &x_pu),
                ::std::option::Option::None => crate::lower::model::OutTy::OutGen(crate::lower::camel_f(n_pt)),
            };
        }
        if let crate::check::types::Ty::TyFlex(n_pv) = t_p1 {
            break 'm1375 match crate::prelude::get(&lx_p0.subst_p, &crate::prelude::Text::from(format!("\'{}", n_pv))) {
                ::std::option::Option::Some(x_p10) => out_ty_of_f(lx_p0, &x_p10),
                ::std::option::Option::None => match crate::prelude::get(&lx_p0.quants_p, &crate::prelude::Text::from(format!("\'{}", n_pv))) {
                    ::std::option::Option::Some(b_p11) => crate::lower::model::OutTy::OutQuantified(b_p11),
                    ::std::option::Option::None => crate::lower::expr::internal_bug_type_f(&crate::prelude::Text::from(format!("a type variable the checker left undecided (`t{}`)", n_pv))),
                },
            };
        }
        if let crate::check::types::Ty::TyAny(bounds_p12) = t_p1 {
            break 'm1375 if is_show_only_f(bounds_p12) {
                crate::lower::model::OutTy::OutShowAny
            } else {
                crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("prism_rtl::Packed")), crate::prelude::Array::new())
            };
        }
        if let crate::check::types::Ty::TyElem(_, _) = t_p1 {
            break 'm1375 crate::lower::model::OutTy::OutLive(::std::rc::Rc::new(crate::lower::model::OutTy::OutNamed(crate::lower::model::elem_ref_p(), crate::prelude::Array::new())));
        }
        if let crate::check::types::Ty::TyElemAny(_) = t_p1 {
            break 'm1375 crate::lower::model::OutTy::OutNamed(crate::lower::model::elem_ref_p(), crate::prelude::Array::new());
        }
        if let crate::check::types::Ty::TyAt(i_p13, _) = t_p1 {
            break 'm1375 blueprint_ty_p();
        }
        if let crate::check::types::Ty::TyAssoc(tr_p14, n_p15, a_p16) = t_p1 {
            break 'm1375 assoc_out_f(lx_p0, tr_p14, n_p15, &**a_p16);
        }
        if let crate::check::types::Ty::TyErr = t_p1 {
            break 'm1375 crate::lower::expr::internal_bug_type_f(&crate::prelude::Text::lit("a type the checker did not find"));
        }
        unreachable!("no clause matched")
    }
}

/// The step machine of `OutTyOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// OutTyOf: unbounded fn Lx, Ty -> OutTy
/// ```
pub struct OutTyOf {
    pub lx_p0: crate::lower::Lx,
    pub t_p1: crate::check::types::Ty,
}

impl ::prism_rtl::Job<crate::lower::model::OutTy> for OutTyOf {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::lower::model::OutTy> {
        let lx_p0 = &self.lx_p0;
        let t_p1 = &self.t_p1;
        'm1375: {
            if let crate::check::types::Ty::TyCon(m1375_0_0, m1375_0_1) = t_p1 && (m1375_0_0 == &crate::prelude::Text::lit("Nat")) && (m1375_0_1.len() == 0) {
                break 'm1375 ::prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutNat);
            }
            if let crate::check::types::Ty::TyCon(m1375_1_0, m1375_1_1) = t_p1 && (m1375_1_0 == &crate::prelude::Text::lit("Int")) && (m1375_1_1.len() == 0) {
                break 'm1375 ::prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutInt);
            }
            if let crate::check::types::Ty::TyCon(m1375_2_0, m1375_2_1) = t_p1 && (m1375_2_0 == &crate::prelude::Text::lit("U8")) && (m1375_2_1.len() == 0) {
                break 'm1375 ::prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutU8);
            }
            if let crate::check::types::Ty::TyCon(m1375_3_0, m1375_3_1) = t_p1 && (m1375_3_0 == &crate::prelude::Text::lit("Float")) && (m1375_3_1.len() == 0) {
                break 'm1375 ::prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutFloat);
            }
            if let crate::check::types::Ty::TyCon(m1375_4_0, m1375_4_1) = t_p1 && (m1375_4_0 == &crate::prelude::Text::lit("Bool")) && (m1375_4_1.len() == 0) {
                break 'm1375 ::prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutBool);
            }
            if let crate::check::types::Ty::TyCon(m1375_5_0, m1375_5_1) = t_p1 && (m1375_5_0 == &crate::prelude::Text::lit("Char")) && (m1375_5_1.len() == 0) {
                break 'm1375 ::prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutChar);
            }
            if let crate::check::types::Ty::TyCon(m1375_6_0, m1375_6_1) = t_p1 && (m1375_6_0 == &crate::prelude::Text::lit("Text")) && (m1375_6_1.len() == 0) {
                break 'm1375 ::prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutText);
            }
            if let crate::check::types::Ty::TyCon(m1375_7_0, m1375_7_1) = t_p1 && (m1375_7_0 == &crate::prelude::Text::lit("unit")) && (m1375_7_1.len() == 0) {
                break 'm1375 ::prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutUnit);
            }
            if let crate::check::types::Ty::TyCon(m1375_8_0, m1375_8_1) = t_p1 && (m1375_8_0 == &crate::prelude::Text::lit("Path")) && (m1375_8_1.len() == 0) {
                break 'm1375 ::prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutPath);
            }
            if let crate::check::types::Ty::TyCon(m1375_9_0, m1375_9_1) = t_p1 && (m1375_9_0 == &crate::prelude::Text::lit("Cursor")) && (m1375_9_1.len() == 0) {
                break 'm1375 ::prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutCursor);
            }
            if let crate::check::types::Ty::TyCon(m1375_10_0, m1375_10_1) = t_p1 && (m1375_10_0 == &crate::prelude::Text::lit("Regex")) && (m1375_10_1.len() == 0) {
                break 'm1375 ::prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutRegex);
            }
            if let crate::check::types::Ty::TyCon(m1375_11_0, m1375_11_1) = t_p1 && (m1375_11_0 == &crate::prelude::Text::lit("RegexReplacement")) && (m1375_11_1.len() == 0) {
                break 'm1375 ::prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutReplacement);
            }
            if let crate::check::types::Ty::TyCon(m1375_12_0, m1375_12_1) = t_p1 && (m1375_12_0 == &crate::prelude::Text::lit("Duration")) && (m1375_12_1.len() == 0) {
                break 'm1375 ::prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutDuration);
            }
            if let crate::check::types::Ty::TyCon(m1375_13_0, _) = t_p1 && (m1375_13_0 == &crate::prelude::Text::lit("Answer")) {
                break 'm1375 ::prism_rtl::Turn::Finished(answer_ty_p());
            }
            if let crate::check::types::Ty::TyCon(m1375_14_0, m1375_14_1) = t_p1 && (m1375_14_0 == &crate::prelude::Text::lit("Wired")) && (m1375_14_1.len() == 0) {
                break 'm1375 ::prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutNamed(crate::lower::model::elem_ref_p(), crate::prelude::Array::new()));
            }
            if let crate::check::types::Ty::TyCon(m1375_15_0, m1375_15_1) = t_p1 && (m1375_15_0 == &crate::prelude::Text::lit("Prelude.Error")) && (m1375_15_1.len() == 0) {
                break 'm1375 ::prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutError);
            }
            if let crate::check::types::Ty::TyCon(m1375_16_0, m1375_16_1) = t_p1 && (m1375_16_0 == &crate::prelude::Text::lit("Prelude.NonEmpty")) && (m1375_16_1.len() == 1) && let ::std::option::Option::Some(c_p2) = crate::prelude::index(m1375_16_1, &crate::prelude::Nat::from(0u32)) {
                break 'm1375 {
                    let lx_p0x = lx_p0.clone();
                    crate::prelude::call_then(start_out_ty_of_f(lx_p0x.clone(), c_p2.clone()), move |out_ty_of_f_2342: crate::lower::model::OutTy| ::prism_rtl::Turn::Finished(non_empty_out_f(&out_ty_of_f_2342)))
                };
            }
            if let crate::check::types::Ty::TyCon(m1375_17_0, m1375_17_1) = t_p1 && (m1375_17_0 == &crate::prelude::Text::lit("\0Self")) && (m1375_17_1.len() == 0) {
                break 'm1375 ::prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("Self")), crate::prelude::Array::new()));
            }
            if let crate::check::types::Ty::TyCon(m1375_18_0, m1375_18_1) = t_p1 && (m1375_18_0 == &crate::prelude::Text::lit("Buffer")) && (m1375_18_1.len() == 1) && let ::std::option::Option::Some(a_p3) = crate::prelude::index(m1375_18_1, &crate::prelude::Nat::from(0u32)) {
                break 'm1375 {
                    let lx_p0x = lx_p0.clone();
                    crate::prelude::call_then(start_out_ty_of_f(lx_p0x.clone(), a_p3.clone()), move |out_ty_of_f_2458: crate::lower::model::OutTy| ::prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutArray(::std::rc::Rc::new(out_ty_of_f_2458))))
                };
            }
            if let crate::check::types::Ty::TyCon(m1375_19_0, m1375_19_1) = t_p1 && (m1375_19_0 == &crate::prelude::Text::lit("Table")) && (m1375_19_1.len() == 2) && let ::std::option::Option::Some(k_p4) = crate::prelude::index(m1375_19_1, &crate::prelude::Nat::from(0u32)) && let ::std::option::Option::Some(v_p5) = crate::prelude::index(m1375_19_1, &crate::prelude::Nat::from(1u32)) {
                break 'm1375 {
                    let lx_p0x = lx_p0.clone();
                    crate::prelude::call_then(start_out_ty_of_f(lx_p0x.clone(), k_p4.clone()), move |out_ty_of_f_2524: crate::lower::model::OutTy| crate::prelude::call_then(start_out_ty_of_f(lx_p0x.clone(), v_p5.clone()), move |out_ty_of_f_2541: crate::lower::model::OutTy| ::prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutArray(::std::rc::Rc::new(crate::lower::model::OutTy::OutTuple(crate::prelude::Array::from(vec![out_ty_of_f_2524, out_ty_of_f_2541])))))))
                };
            }
            if let crate::check::types::Ty::TyCon(m1375_20_0, m1375_20_1) = t_p1 && (m1375_20_0 == &crate::prelude::Text::lit("\0Event")) && (m1375_20_1.len() == 1) && let ::std::option::Option::Some(a_p6) = crate::prelude::index(m1375_20_1, &crate::prelude::Nat::from(0u32)) {
                break 'm1375 {
                    let lx_p0x = lx_p0.clone();
                    crate::prelude::call_then(start_out_ty_of_f(lx_p0x.clone(), a_p6.clone()), move |out_ty_of_f_2600: crate::lower::model::OutTy| ::prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutEvent(::std::rc::Rc::new(out_ty_of_f_2600))))
                };
            }
            if let crate::check::types::Ty::TyCon(n_p7, args_p8) = t_p1 {
                break 'm1375 {
                    let args_p8x = args_p8.clone();
                    let lx_p0x = lx_p0.clone();
                    let n_p7x = n_p7.clone();
                    crate::prelude::call_value(crate::prelude::each_job(args_p8x.clone(), {
                        let lx_p0xx = lx_p0x.clone();
                        ::std::rc::Rc::new(move |p0: crate::check::types::Ty| {
                            let lx_p0xxy = lx_p0xx.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let a_p9 = p0;
                                ::prism_rtl::Turn::More(::std::rc::Rc::new(OutTyOf { lx_p0: lx_p0xxy.clone(), t_p1: a_p9.clone() }))
                            }))
                        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::OutTy>>>
                    }), move |each_2650: crate::prelude::Array<crate::lower::model::OutTy>| ::prism_rtl::Turn::More(::std::rc::Rc::new(NamedTy { lx_p0: lx_p0x.clone(), n_p1: n_p7x.clone(), args_p2: each_2650 })))
                };
            }
            if let crate::check::types::Ty::TyFn(c_pa, ps_pb, res_pc) = t_p1 {
                break 'm1375 {
                    let c2_pd = crate::lower::inst_col_f(lx_p0, c_pa);
                    if &c2_pd == &crate::check::types::Col::CBound {
                        {
                            let lx_p0x = lx_p0.clone();
                            let ps_pbx = ps_pb.clone();
                            let res_pcx = (**res_pc).clone();
                            crate::prelude::call_value(crate::prelude::each_job(ps_pbx.clone(), {
                                let lx_p0xx = lx_p0x.clone();
                                ::std::rc::Rc::new(move |p0: crate::check::types::Ty| {
                                    let lx_p0xxy = lx_p0xx.clone();
                                    crate::prelude::entered(crate::prelude::once_job(move || {
                                        let p_pe = p0;
                                        ::prism_rtl::Turn::More(::std::rc::Rc::new(OutTyOf { lx_p0: lx_p0xxy.clone(), t_p1: p_pe.clone() }))
                                    }))
                                }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::OutTy>>>
                            }), move |each_2931: crate::prelude::Array<crate::lower::model::OutTy>| crate::prelude::call_then(start_out_ty_of_f(lx_p0x.clone(), res_pcx.clone()), move |out_ty_of_f_2962: crate::lower::model::OutTy| ::prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutFn(each_2931, ::std::rc::Rc::new(out_ty_of_f_2962)))))
                        }
                    } else {
                        if crate::lower::is_quant_col_f(lx_p0, &c2_pd) {
                            ::prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutQuantified(crate::prelude::or(&crate::prelude::get(&lx_p0.quants_p, &crate::lower::expr::col_name_f(&c2_pd)), &crate::prelude::Text::lit(""))))
                        } else {
                            {
                                let lx_p0x = lx_p0.clone();
                                let ps_pbx = ps_pb.clone();
                                let res_pcx = (**res_pc).clone();
                                crate::prelude::call_then(start_rust_ty_of_params_f(lx_p0x.clone(), crate::prelude::each(&ps_pbx, &(|p_pf: &crate::check::types::Ty| job_param_f(p_pf)))), move |rust_ty_of_params_f_3084: crate::lower::model::OutTy| crate::prelude::call_then(start_out_ty_of_f(lx_p0x.clone(), res_pcx.clone()), move |out_ty_of_f_3133: crate::lower::model::OutTy| ::prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutJobFn(::std::rc::Rc::new(rust_ty_of_params_f_3084), ::std::rc::Rc::new(out_ty_of_f_3133)))))
                            }
                        }
                    }
                };
            }
            if let crate::check::types::Ty::TyTuple(m1375_23_0) = t_p1 && (m1375_23_0.len() == 0) {
                break 'm1375 ::prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutUnit);
            }
            if let crate::check::types::Ty::TyTuple(ts_pg) = t_p1 {
                break 'm1375 {
                    let lx_p0x = lx_p0.clone();
                    let ts_pgx = ts_pg.clone();
                    crate::prelude::call_value(crate::prelude::each_job(ts_pgx.clone(), {
                        let lx_p0xx = lx_p0x.clone();
                        ::std::rc::Rc::new(move |p0: crate::check::types::Ty| {
                            let lx_p0xxy = lx_p0xx.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let a_ph = p0;
                                ::prism_rtl::Turn::More(::std::rc::Rc::new(OutTyOf { lx_p0: lx_p0xxy.clone(), t_p1: a_ph.clone() }))
                            }))
                        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::OutTy>>>
                    }), move |each_3202: crate::prelude::Array<crate::lower::model::OutTy>| ::prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutTuple(each_3202)))
                };
            }
            if let crate::check::types::Ty::TyArray(e_pi) = t_p1 {
                break 'm1375 {
                    let e_pix = (**e_pi).clone();
                    let lx_p0x = lx_p0.clone();
                    crate::prelude::call_then(start_out_ty_of_f(lx_p0x.clone(), e_pix.clone()), move |out_ty_of_f_3256: crate::lower::model::OutTy| ::prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutArray(::std::rc::Rc::new(out_ty_of_f_3256))))
                };
            }
            if let crate::check::types::Ty::TyMap(k_pj, v_pk) = t_p1 {
                break 'm1375 {
                    let k_pjx = (**k_pj).clone();
                    let lx_p0x = lx_p0.clone();
                    let v_pkx = (**v_pk).clone();
                    crate::prelude::call_then(start_out_ty_of_f(lx_p0x.clone(), k_pjx.clone()), move |out_ty_of_f_3295: crate::lower::model::OutTy| crate::prelude::call_then(start_out_ty_of_f(lx_p0x.clone(), v_pkx.clone()), move |out_ty_of_f_3312: crate::lower::model::OutTy| ::prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutMap(::std::rc::Rc::new(out_ty_of_f_3295), ::std::rc::Rc::new(out_ty_of_f_3312)))))
                };
            }
            if let crate::check::types::Ty::TySig(m1375_27_0, i_pl) = t_p1 && (m1375_27_0 == &crate::prelude::Text::lit("?")) {
                break 'm1375 {
                    let i_plx = (**i_pl).clone();
                    let lx_p0x = lx_p0.clone();
                    crate::prelude::call_then(start_out_ty_of_f(lx_p0x.clone(), i_plx.clone()), move |out_ty_of_f_3353: crate::lower::model::OutTy| ::prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutOpt(::std::rc::Rc::new(out_ty_of_f_3353))))
                };
            }
            if let crate::check::types::Ty::TySig(m1375_28_0, i_pm) = t_p1 && (m1375_28_0 == &crate::prelude::Text::lit("~")) {
                break 'm1375 {
                    let i_pmx = (**i_pm).clone();
                    let lx_p0x = lx_p0.clone();
                    crate::prelude::call_then(start_out_ty_of_f(lx_p0x.clone(), i_pmx.clone()), move |out_ty_of_f_3394: crate::lower::model::OutTy| ::prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutRes(::std::rc::Rc::new(out_ty_of_f_3394))))
                };
            }
            if let crate::check::types::Ty::TySig(m1375_29_0, i_pn) = t_p1 && (m1375_29_0 == &crate::prelude::Text::lit("!")) {
                break 'm1375 {
                    let i_pnx = (**i_pn).clone();
                    let lx_p0x = lx_p0.clone();
                    crate::prelude::call_then(start_out_ty_of_f(lx_p0x.clone(), i_pnx.clone()), move |out_ty_of_f_3437: crate::lower::model::OutTy| ::prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutEvent(::std::rc::Rc::new(out_ty_of_f_3437))))
                };
            }
            if let crate::check::types::Ty::TySig(m1375_30_0, i_po) = t_p1 && (m1375_30_0 == &crate::prelude::Text::lit("$")) {
                break 'm1375 {
                    let i_pox = (**i_po).clone();
                    let lx_p0x = lx_p0.clone();
                    crate::prelude::call_then(start_out_ty_of_f(lx_p0x.clone(), i_pox.clone()), move |out_ty_of_f_3478: crate::lower::model::OutTy| ::prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutDyn(::std::rc::Rc::new(out_ty_of_f_3478))))
                };
            }
            if let crate::check::types::Ty::TySig(m1375_31_0, i_pp) = t_p1 && (m1375_31_0 == &crate::prelude::Text::lit("&")) {
                break 'm1375 ::prism_rtl::Turn::More(::std::rc::Rc::new(OutTyOf { lx_p0: lx_p0.clone(), t_p1: (**i_pp).clone() }));
            }
            if let crate::check::types::Ty::TySig(_, i_pq) = t_p1 {
                break 'm1375 ::prism_rtl::Turn::More(::std::rc::Rc::new(OutTyOf { lx_p0: lx_p0.clone(), t_p1: (**i_pq).clone() }));
            }
            if let crate::check::types::Ty::TyQ(n_pr) = t_p1 {
                break 'm1375 match crate::prelude::get(&lx_p0.subst_p, n_pr) {
                    ::std::option::Option::Some(x_ps) => ::prism_rtl::Turn::More(::std::rc::Rc::new(OutTyOf { lx_p0: lx_p0.clone(), t_p1: x_ps.clone() })),
                    ::std::option::Option::None => ::prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutGen(crate::lower::camel_f(n_pr))),
                };
            }
            if let crate::check::types::Ty::TyRigid(n_pt) = t_p1 {
                break 'm1375 match crate::prelude::get(&lx_p0.subst_p, n_pt) {
                    ::std::option::Option::Some(x_pu) => ::prism_rtl::Turn::More(::std::rc::Rc::new(OutTyOf { lx_p0: lx_p0.clone(), t_p1: x_pu.clone() })),
                    ::std::option::Option::None => ::prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutGen(crate::lower::camel_f(n_pt))),
                };
            }
            if let crate::check::types::Ty::TyFlex(n_pv) = t_p1 {
                break 'm1375 match crate::prelude::get(&lx_p0.subst_p, &crate::prelude::Text::from(format!("\'{}", n_pv))) {
                    ::std::option::Option::Some(x_p10) => ::prism_rtl::Turn::More(::std::rc::Rc::new(OutTyOf { lx_p0: lx_p0.clone(), t_p1: x_p10.clone() })),
                    ::std::option::Option::None => match crate::prelude::get(&lx_p0.quants_p, &crate::prelude::Text::from(format!("\'{}", n_pv))) {
                        ::std::option::Option::Some(b_p11) => ::prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutQuantified(b_p11.clone())),
                        ::std::option::Option::None => ::prism_rtl::Turn::Finished(crate::lower::expr::internal_bug_type_f(&crate::prelude::Text::from(format!("a type variable the checker left undecided (`t{}`)", n_pv)))),
                    },
                };
            }
            if let crate::check::types::Ty::TyAny(bounds_p12) = t_p1 {
                break 'm1375 if is_show_only_f(bounds_p12) {
                    ::prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutShowAny)
                } else {
                    ::prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("prism_rtl::Packed")), crate::prelude::Array::new()))
                };
            }
            if let crate::check::types::Ty::TyElem(_, _) = t_p1 {
                break 'm1375 ::prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutLive(::std::rc::Rc::new(crate::lower::model::OutTy::OutNamed(crate::lower::model::elem_ref_p(), crate::prelude::Array::new()))));
            }
            if let crate::check::types::Ty::TyElemAny(_) = t_p1 {
                break 'm1375 ::prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutNamed(crate::lower::model::elem_ref_p(), crate::prelude::Array::new()));
            }
            if let crate::check::types::Ty::TyAt(i_p13, _) = t_p1 {
                break 'm1375 ::prism_rtl::Turn::Finished(blueprint_ty_p());
            }
            if let crate::check::types::Ty::TyAssoc(tr_p14, n_p15, a_p16) = t_p1 {
                break 'm1375 ::prism_rtl::Turn::More(::std::rc::Rc::new(AssocOut { lx_p0: lx_p0.clone(), tr_p1: tr_p14.clone(), n_p2: n_p15.clone(), a_p3: (**a_p16).clone() }));
            }
            if let crate::check::types::Ty::TyErr = t_p1 {
                break 'm1375 ::prism_rtl::Turn::Finished(crate::lower::expr::internal_bug_type_f(&crate::prelude::Text::lit("a type the checker did not find")));
            }
            unreachable!("no clause matched")
        }
    }
}

/// `Start OutTyOf, x`: what the function value is when passed to `@Run`.
pub fn start_out_ty_of_f(lx_p0: crate::lower::Lx, t_p1: crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::OutTy>> {
    ::std::rc::Rc::new(OutTyOf { lx_p0, t_p1 })
}

/// ```prism
/// let blueprintTy
/// ```
pub fn blueprint_ty_p() -> crate::lower::model::OutTy {
    crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("prism_rtl::Blueprint")), crate::prelude::Array::from(vec![crate::lower::model::OutTy::OutNamed(crate::lower::model::elem_ref_p(), crate::prelude::Array::new()), crate::lower::model::OutTy::OutNamed(crate::lower::model::answer_ref_p(), crate::prelude::Array::new())]))
}

/// ```prism
/// let elemTy
/// ```
pub fn elem_ty_p() -> crate::lower::model::OutTy {
    crate::lower::model::OutTy::OutNamed(crate::lower::model::elem_ref_p(), crate::prelude::Array::new())
}

/// ```prism
/// let answerTy
/// ```
pub fn answer_ty_p() -> crate::lower::model::OutTy {
    crate::lower::model::OutTy::OutNamed(crate::lower::model::answer_ref_p(), crate::prelude::Array::new())
}

/// ```prism
/// let entryTy
/// ```
pub fn entry_ty_p() -> crate::lower::model::OutTy {
    crate::lower::model::OutTy::OutRc(::std::rc::Rc::new(crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("prism_rtl::Entry")), crate::prelude::Array::from(vec![crate::lower::model::OutTy::OutNamed(crate::lower::model::elem_ref_p(), crate::prelude::Array::new())]))))
}

/// ```prism
/// let hostDocTy
/// ```
pub fn host_doc_ty_p() -> crate::lower::model::OutTy {
    crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("prism_rtl::HostDoc")), crate::prelude::Array::from(vec![crate::lower::model::OutTy::OutNamed(crate::lower::model::elem_ref_p(), crate::prelude::Array::new())]))
}

/// ```prism
/// let hostOfTy
/// ```
pub fn host_of_ty_p() -> crate::lower::model::OutTy {
    crate::lower::model::OutTy::OutObj(::std::rc::Rc::new(crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("prism_rtl::HostOf")), crate::prelude::Array::from(vec![crate::lower::model::OutTy::OutNamed(crate::lower::model::elem_ref_p(), crate::prelude::Array::new()), crate::lower::model::OutTy::OutNamed(crate::lower::model::answer_ref_p(), crate::prelude::Array::new())]))))
}

/// ```prism
/// HasBlueprint: fn Ty -> Bool
/// ```
pub fn has_blueprint_f(t_p0: &crate::check::types::Ty) -> bool {
    match t_p0 {
        crate::check::types::Ty::TyAt(_, _) => true,
        crate::check::types::Ty::TySig(_, i_p1) => has_blueprint_f(&**i_p1),
        _ => false,
    }
}

/// ```prism
/// TimeWithin: fn Ty -> Bool
/// ```
pub fn time_within_f(t_p0: &crate::check::types::Ty) -> bool {
    has_time_f(&peel_f(t_p0))
}

/// ```prism
/// HasTime: fn Ty -> Bool
/// ```
pub fn has_time_f(t_p0: &crate::check::types::Ty) -> bool {
    match t_p0 {
        crate::check::types::Ty::TySig(m5845_0_0, _) if (m5845_0_0 == &crate::prelude::Text::lit("$")) => true,
        crate::check::types::Ty::TySig(m5845_1_0, _) if (m5845_1_0 == &crate::prelude::Text::lit("!")) => true,
        crate::check::types::Ty::TySig(_, i_p1) => has_time_f(&**i_p1),
        crate::check::types::Ty::TyCon(_, ts_p2) => crate::prelude::fold(ts_p2, &false, &(|seen_p3: &bool, x_p4: &crate::check::types::Ty| *seen_p3 || has_time_f(x_p4))),
        crate::check::types::Ty::TyTuple(ts_p5) => crate::prelude::fold(ts_p5, &false, &(|seen_p6: &bool, x_p7: &crate::check::types::Ty| *seen_p6 || has_time_f(x_p7))),
        crate::check::types::Ty::TyArray(x_p8) => has_time_f(&**x_p8),
        crate::check::types::Ty::TyMap(k_p9, v_pa) => has_time_f(&**k_p9) || has_time_f(&**v_pa),
        crate::check::types::Ty::TyAssoc(_, _, x_pb) => has_time_f(&**x_pb),
        _ => false,
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// EventParam: fn Ty -> Ty
/// ```
pub fn event_param_f(t_p0: &crate::check::types::Ty) -> crate::check::types::Ty {
    match t_p0 {
        crate::check::types::Ty::TySig(m6342_0_0, i_p1) if (m6342_0_0 == &crate::prelude::Text::lit("!")) => crate::check::types::Ty::TyCon(crate::prelude::Text::lit("\0Event"), crate::prelude::Array::from(vec![peel_f(&**i_p1)])),
        _ => t_p0.clone(),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// JobParam: fn Ty -> Ty
/// ```
pub fn job_param_f(ty0: &crate::check::types::Ty) -> crate::check::types::Ty {
    match ty0 {
        crate::check::types::Ty::TyFn(_, ps_p0, r_p1) => crate::check::types::Ty::TyFn(crate::check::types::Col::CUnbound, ps_p0.clone(), ::std::rc::Rc::new((**r_p1).clone())),
        t_p2 => t_p2.clone(),
    }
}

/// ```prism
/// RustTyOfParams: unbounded fn Lx, [Ty] -> OutTy
/// ```
pub fn rust_ty_of_params_f(lx_p0: &crate::lower::Lx, ps_p1: &crate::prelude::Array<crate::check::types::Ty>) -> crate::lower::model::OutTy {
    'm6905: {
        if let m6905_0 = ps_p1 && (m6905_0.len() == 1) && let ::std::option::Option::Some(p_p2) = crate::prelude::index(m6905_0, &crate::prelude::Nat::from(0u32)) {
            break 'm6905 out_ty_of_f(lx_p0, &p_p2);
        }
        crate::lower::model::OutTy::OutTuple(crate::prelude::run_to_end(crate::prelude::each_job(ps_p1.clone(), {
            let lx_p0x = lx_p0.clone();
            ::std::rc::Rc::new(move |p0: crate::check::types::Ty| {
                let lx_p0xy = lx_p0x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let p_p3 = p0;
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(OutTyOf { lx_p0: lx_p0xy.clone(), t_p1: p_p3.clone() }))
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::OutTy>>>
        })))
    }
}

/// The step machine of `RustTyOfParams`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RustTyOfParams: unbounded fn Lx, [Ty] -> OutTy
/// ```
pub struct RustTyOfParams {
    pub lx_p0: crate::lower::Lx,
    pub ps_p1: crate::prelude::Array<crate::check::types::Ty>,
}

impl ::prism_rtl::Job<crate::lower::model::OutTy> for RustTyOfParams {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::lower::model::OutTy> {
        let lx_p0 = &self.lx_p0;
        let ps_p1 = &self.ps_p1;
        'm6905: {
            if let m6905_0 = ps_p1 && (m6905_0.len() == 1) && let ::std::option::Option::Some(p_p2) = crate::prelude::index(m6905_0, &crate::prelude::Nat::from(0u32)) {
                break 'm6905 ::prism_rtl::Turn::More(::std::rc::Rc::new(OutTyOf { lx_p0: lx_p0.clone(), t_p1: p_p2.clone() }));
            }
            {
                let lx_p0x = lx_p0.clone();
                let ps_p1x = ps_p1.clone();
                crate::prelude::call_value(crate::prelude::each_job(ps_p1x.clone(), {
                    let lx_p0xx = lx_p0x.clone();
                    ::std::rc::Rc::new(move |p0: crate::check::types::Ty| {
                        let lx_p0xxy = lx_p0xx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let p_p3 = p0;
                            ::prism_rtl::Turn::More(::std::rc::Rc::new(OutTyOf { lx_p0: lx_p0xxy.clone(), t_p1: p_p3.clone() }))
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::OutTy>>>
                }), move |each_6965: crate::prelude::Array<crate::lower::model::OutTy>| ::prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutTuple(each_6965)))
            }
        }
    }
}

/// `Start RustTyOfParams, x`: what the function value is when passed to `@Run`.
pub fn start_rust_ty_of_params_f(lx_p0: crate::lower::Lx, ps_p1: crate::prelude::Array<crate::check::types::Ty>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::OutTy>> {
    ::std::rc::Rc::new(RustTyOfParams { lx_p0, ps_p1 })
}

/// ```prism
/// NamedTy: unbounded fn Lx, Text, [OutTy] -> OutTy
/// ```
pub fn named_ty_f(lx_p0: &crate::lower::Lx, n_p1: &crate::prelude::Text, args_p2: &crate::prelude::Array<crate::lower::model::OutTy>) -> crate::lower::model::OutTy {
    match crate::prelude::get(&lx_p0.g_p.types_p, n_p1) {
        ::std::option::Option::Some(ti_p3) => match &ti_p3.body_p {
            crate::check::env::TyBody::BAlias(a_p4) => out_ty_of_f(lx_p0, a_p4),
            crate::check::env::TyBody::BRowKind => if n_p1 == &crate::prelude::Text::lit("Prelude.Fault") {
                crate::lower::model::OutTy::OutPod
            } else {
                crate::lower::model::OutTy::OutNamed(crate::lower::ref_in_f(lx_p0, &ti_p3.home_p, &crate::lower::type_item_name_f(n_p1)), crate::prelude::Array::new())
            },
            _ => crate::lower::model::OutTy::OutNamed(crate::lower::ref_in_f(lx_p0, &ti_p3.home_p, &crate::lower::type_item_name_f(n_p1)), args_p2.clone()),
        },
        ::std::option::Option::None => if crate::check::env::has_key_f(&lx_p0.g_p.families_p, n_p1) {
            crate::lower::model::OutTy::OutPod
        } else {
            crate::lower::expr::internal_bug_type_f(&crate::prelude::Text::from(format!("the type `{}`, which the checker did not declare", n_p1)))
        },
    }
}

/// The step machine of `NamedTy`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// NamedTy: unbounded fn Lx, Text, [OutTy] -> OutTy
/// ```
pub struct NamedTy {
    pub lx_p0: crate::lower::Lx,
    pub n_p1: crate::prelude::Text,
    pub args_p2: crate::prelude::Array<crate::lower::model::OutTy>,
}

impl ::prism_rtl::Job<crate::lower::model::OutTy> for NamedTy {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::lower::model::OutTy> {
        let lx_p0 = &self.lx_p0;
        let n_p1 = &self.n_p1;
        let args_p2 = &self.args_p2;
        match crate::prelude::get(&lx_p0.g_p.types_p, n_p1) {
            ::std::option::Option::Some(ti_p3) => match &ti_p3.body_p {
                crate::check::env::TyBody::BAlias(a_p4) => ::prism_rtl::Turn::More(::std::rc::Rc::new(OutTyOf { lx_p0: lx_p0.clone(), t_p1: a_p4.clone() })),
                crate::check::env::TyBody::BRowKind => if n_p1 == &crate::prelude::Text::lit("Prelude.Fault") {
                    ::prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutPod)
                } else {
                    ::prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutNamed(crate::lower::ref_in_f(lx_p0, &ti_p3.home_p, &crate::lower::type_item_name_f(n_p1)), crate::prelude::Array::new()))
                },
                _ => ::prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutNamed(crate::lower::ref_in_f(lx_p0, &ti_p3.home_p, &crate::lower::type_item_name_f(n_p1)), args_p2.clone())),
            },
            ::std::option::Option::None => if crate::check::env::has_key_f(&lx_p0.g_p.families_p, n_p1) {
                ::prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutPod)
            } else {
                ::prism_rtl::Turn::Finished(crate::lower::expr::internal_bug_type_f(&crate::prelude::Text::from(format!("the type `{}`, which the checker did not declare", n_p1))))
            },
        }
    }
}

/// `Start NamedTy, x`: what the function value is when passed to `@Run`.
pub fn start_named_ty_f(lx_p0: crate::lower::Lx, n_p1: crate::prelude::Text, args_p2: crate::prelude::Array<crate::lower::model::OutTy>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::OutTy>> {
    ::std::rc::Rc::new(NamedTy { lx_p0, n_p1, args_p2 })
}

/// ```prism
/// NonEmptyOut: fn OutTy -> OutTy
/// ```
pub fn non_empty_out_f(c_p0: &crate::lower::model::OutTy) -> crate::lower::model::OutTy {
    crate::lower::model::OutTy::OutNamed(non_empty_ref_p(), crate::prelude::Array::from(vec![c_p0.clone()]))
}

/// ```prism
/// let nonEmptyRef
/// ```
pub fn non_empty_ref_p() -> crate::lower::model::Ref {
    crate::lower::helper_ref_f(&crate::prelude::Text::lit("NonEmpty"))
}

/// ```prism
/// ?PlainOut: fn OutTy -> ?OutTy
/// ```
pub fn plain_out_o(t_p0: &crate::lower::model::OutTy) -> ::std::option::Option<crate::lower::model::OutTy> {
    'm8458: {
        if let crate::lower::model::OutTy::OutNamed(n_p1, m8458_0_1) = t_p0 && (m8458_0_1.len() == 1) && let ::std::option::Option::Some(c_p2) = crate::prelude::index(m8458_0_1, &crate::prelude::Nat::from(0u32)) && (n_p1 == &non_empty_ref_p()) {
            break 'm8458 ::std::option::Option::Some(c_p2.clone());
        }
        ::std::option::Option::None
    }
}

/// ```prism
/// CollectionOut: fn OutTy -> OutTy
/// ```
pub fn collection_out_f(t_p0: &crate::lower::model::OutTy) -> crate::lower::model::OutTy {
    crate::prelude::or(&plain_out_o(t_p0), t_p0)
}

/// ```prism
/// Collection: fn Ty -> Ty
/// ```
pub fn collection_f(t_p0: &crate::check::types::Ty) -> crate::check::types::Ty {
    'm8897: {
        if let crate::check::types::Ty::TyCon(m8897_0_0, m8897_0_1) = t_p0 && (m8897_0_0 == &crate::prelude::Text::lit("Prelude.NonEmpty")) && (m8897_0_1.len() == 1) && let ::std::option::Option::Some(c_p1) = crate::prelude::index(m8897_0_1, &crate::prelude::Nat::from(0u32)) {
            break 'm8897 c_p1.clone();
        }
        t_p0.clone()
    }
}

/// ```prism
/// PlainValue: fn Vl -> Vl
/// ```
pub fn plain_value_f(v_p0: &Vl) -> Vl {
    match plain_out_o(&value_ty_f(v_p0)) {
        ::std::option::Option::Some(c_p1) => Vl::VlPlace(crate::lower::model::Ex::XCall(crate::lower::helper_ref_f(&crate::prelude::Text::lit("plain_collection")), crate::prelude::Array::from(vec![ref_f(v_p0)])), Holding::ByRef, c_p1),
        ::std::option::Option::None => match value_ty_f(v_p0) {
            crate::lower::model::OutTy::OutDyn(inner_p2) => match plain_out_o(&*inner_p2) {
                ::std::option::Option::Some(c_p3) => Vl::VlOwned(plain_mapped_f(v_p0, &*inner_p2), crate::lower::model::OutTy::OutDyn(::std::rc::Rc::new(c_p3))),
                ::std::option::Option::None => v_p0.clone(),
            },
            crate::lower::model::OutTy::OutEvent(inner_p4) => match plain_out_o(&*inner_p4) {
                ::std::option::Option::Some(c_p5) => Vl::VlOwned(plain_mapped_f(v_p0, &*inner_p4), crate::lower::model::OutTy::OutEvent(::std::rc::Rc::new(c_p5))),
                ::std::option::Option::None => v_p0.clone(),
            },
            _ => v_p0.clone(),
        },
    }
}

/// ```prism
/// PlainMapped: fn Vl, OutTy -> Ex
/// ```
pub fn plain_mapped_f(v_p0: &Vl, inner_p1: &crate::lower::model::OutTy) -> crate::lower::model::Ex {
    crate::lower::model::Ex::XMethod(::std::rc::Rc::new(own_f(v_p0)), crate::prelude::Text::lit("map"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XClosure(true, crate::prelude::Array::from(vec![crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("non_empty"))), crate::lower::model::OutTy::OutRef(::std::rc::Rc::new(inner_p1.clone())))]), ::std::rc::Rc::new(crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XCall(crate::lower::helper_ref_f(&crate::prelude::Text::lit("plain_collection")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XVar(crate::prelude::Text::lit("non_empty"))]))))))]))
}

/// ```prism
/// PlainOwned: fn Ty, Ex -> Ex
/// ```
pub fn plain_owned_f(t_p0: &crate::check::types::Ty, x_p1: &crate::lower::model::Ex) -> crate::lower::model::Ex {
    match t_p0 {
        crate::check::types::Ty::TyCon(m10165_0_0, _) if (m10165_0_0 == &crate::prelude::Text::lit("Prelude.NonEmpty")) => crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XCall(crate::lower::helper_ref_f(&crate::prelude::Text::lit("plain_collection")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XRef(::std::rc::Rc::new(x_p1.clone()))])))),
        _ => x_p1.clone(),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// Peel: fn Ty -> Ty
/// ```
pub fn peel_f(t_p0: &crate::check::types::Ty) -> crate::check::types::Ty {
    match t_p0 {
        crate::check::types::Ty::TySig(m10579_0_0, i_p1) if (m10579_0_0 == &crate::prelude::Text::lit("$")) => peel_ref_f(&**i_p1),
        crate::check::types::Ty::TySig(m10579_1_0, i_p2) if (m10579_1_0 == &crate::prelude::Text::lit("!")) => peel_ref_f(&**i_p2),
        crate::check::types::Ty::TySig(m10579_2_0, i_p3) if (m10579_2_0 == &crate::prelude::Text::lit("&")) => peel_f(&**i_p3),
        _ => t_p0.clone(),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// PeelRef: fn Ty -> Ty
/// ```
pub fn peel_ref_f(t_p0: &crate::check::types::Ty) -> crate::check::types::Ty {
    match t_p0 {
        crate::check::types::Ty::TySig(m10723_0_0, i_p1) if (m10723_0_0 == &crate::prelude::Text::lit("&")) => peel_ref_f(&**i_p1),
        _ => t_p0.clone(),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// OutOf: fn Ty -> Ty
/// ```
pub fn out_of_f(t_p0: &crate::check::types::Ty) -> crate::check::types::Ty {
    match t_p0 {
        crate::check::types::Ty::TyAt(i_p1, _) => peel_f(&**i_p1),
        _ => peel_f(t_p0),
    }
}

/// ```prism
/// IsBundle: fn Ty -> Bool
/// ```
pub fn is_bundle_f(t_p0: &crate::check::types::Ty) -> bool {
    match t_p0 {
        crate::check::types::Ty::TyTuple(ts_p1) => crate::prelude::fold(ts_p1, &false, &(|found_p2: &bool, x_p3: &crate::check::types::Ty| ((*found_p2 || (&layer_of_f(x_p3) == &Layer::LyEv)) || (&layer_of_f(x_p3) == &Layer::LyDyn)) || is_bundle_f(x_p3))),
        _ => false,
    }
}

/// ```prism
/// LayerOf: fn Ty -> Layer
/// ```
pub fn layer_of_f(t_p0: &crate::check::types::Ty) -> Layer {
    match t_p0 {
        crate::check::types::Ty::TySig(m11521_0_0, _) if (m11521_0_0 == &crate::prelude::Text::lit("$")) => Layer::LyDyn,
        crate::check::types::Ty::TySig(m11521_1_0, _) if (m11521_1_0 == &crate::prelude::Text::lit("!")) => Layer::LyEv,
        crate::check::types::Ty::TySig(m11521_2_0, i_p1) if (m11521_2_0 == &crate::prelude::Text::lit("&")) => layer_of_f(&**i_p1),
        crate::check::types::Ty::TyAt(_, _) => Layer::LyBlueprint,
        _ => Layer::LyPlain,
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// IsShowOnly: fn [Text] -> Bool
/// ```
pub fn is_show_only_f(bounds_p0: &crate::prelude::Array<crate::prelude::Text>) -> bool {
    crate::prelude::fold(bounds_p0, &true, &(|ok_p1: &bool, b_p2: &crate::prelude::Text| *ok_p1 && (&crate::check::types::bare_name_f(b_p2) == &crate::prelude::Text::lit("Show"))))
}

/// ```prism
/// Layouts: unbounded fn G -> (Text ==> [Bool])
/// ```
pub fn layouts_f(g_p0: &crate::check::env::G) -> crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<bool>> {
    crate::prelude::run_to_end(crate::prelude::fold_job(crate::prelude::values(&g_p0.ctors_p), crate::prelude::Map::new(), {
        let g_p0x = g_p0.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<bool>>, crate::check::env::CtorInfo)| {
            let g_p0xy = g_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let m_p1 = p0;
                let c_p2 = p1;
                crate::prelude::call_value(crate::prelude::each_job(c_p2.args_p.clone(), {
                    let g_p0xyx = g_p0xy.clone();
                    let c_p2x = c_p2.clone();
                    ::std::rc::Rc::new(move |p0: crate::check::types::Ty| {
                        let g_p0xyxy = g_p0xyx.clone();
                        let c_p2xy = c_p2x.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let a_p3 = p0;
                            ::prism_rtl::Turn::More(::std::rc::Rc::new(Reaches { g_p0: g_p0xyxy.clone(), t_p1: a_p3.clone(), target_p2: c_p2xy.owner_p.clone(), seen_p3: crate::prelude::Array::new() }))
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
                }), move |each_12296: crate::prelude::Array<bool>| ::prism_rtl::Turn::Finished(crate::prelude::insert(&m_p1, &c_p2.name_p, &each_12296)))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<bool>>, crate::check::env::CtorInfo)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<bool>>>>>
    }))
}

/// The step machine of `Layouts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Layouts: unbounded fn G -> (Text ==> [Bool])
/// ```
pub struct Layouts {
    pub g_p0: crate::check::env::G,
}

impl ::prism_rtl::Job<crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<bool>>> for Layouts {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<bool>>> {
        let g_p0 = &self.g_p0;
        crate::prelude::fold_job(crate::prelude::values(&g_p0.ctors_p), crate::prelude::Map::new(), {
            let g_p0x = g_p0.clone();
            ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<bool>>, crate::check::env::CtorInfo)| {
                let g_p0xy = g_p0x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let m_p1 = p0;
                    let c_p2 = p1;
                    crate::prelude::call_value(crate::prelude::each_job(c_p2.args_p.clone(), {
                        let g_p0xyx = g_p0xy.clone();
                        let c_p2x = c_p2.clone();
                        ::std::rc::Rc::new(move |p0: crate::check::types::Ty| {
                            let g_p0xyxy = g_p0xyx.clone();
                            let c_p2xy = c_p2x.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let a_p3 = p0;
                                ::prism_rtl::Turn::More(::std::rc::Rc::new(Reaches { g_p0: g_p0xyxy.clone(), t_p1: a_p3.clone(), target_p2: c_p2xy.owner_p.clone(), seen_p3: crate::prelude::Array::new() }))
                            }))
                        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
                    }), move |each_12296: crate::prelude::Array<bool>| ::prism_rtl::Turn::Finished(crate::prelude::insert(&m_p1, &c_p2.name_p, &each_12296)))
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<bool>>, crate::check::env::CtorInfo)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<bool>>>>>
        }).cycle()
    }
}

/// `Start Layouts, x`: what the function value is when passed to `@Run`.
pub fn start_layouts_f(g_p0: crate::check::env::G) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<bool>>>> {
    ::std::rc::Rc::new(Layouts { g_p0 })
}

/// ```prism
/// Reaches: unbounded fn G, Ty, Text, [Text] -> Bool
/// ```
pub fn reaches_f(g_p0: &crate::check::env::G, t_p1: &crate::check::types::Ty, target_p2: &crate::prelude::Text, seen_p3: &crate::prelude::Array<crate::prelude::Text>) -> bool {
    match t_p1 {
        crate::check::types::Ty::TyCon(n_p4, args_p5) => if n_p4 == target_p2 {
            true
        } else {
            if crate::check::types::has_text_f(seen_p3, n_p4) {
                false
            } else {
                if crate::prelude::run_to_end(crate::prelude::fold_job(args_p5.clone(), false, {
                    let g_p0x = g_p0.clone();
                    let target_p2x = target_p2.clone();
                    let seen_p3x = seen_p3.clone();
                    ::std::rc::Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| {
                        let g_p0xy = g_p0x.clone();
                        let target_p2xy = target_p2x.clone();
                        let seen_p3xy = seen_p3x.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let f_p6 = p0;
                            let a_p7 = p1;
                            if f_p6 {
                                ::prism_rtl::Turn::Finished(true)
                            } else {
                                ::prism_rtl::Turn::More(::std::rc::Rc::new(Reaches { g_p0: g_p0xy.clone(), t_p1: a_p7.clone(), target_p2: target_p2xy.clone(), seen_p3: seen_p3xy.clone() }))
                            }
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::check::types::Ty)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
                })) {
                    true
                } else {
                    match crate::prelude::get(&g_p0.types_p, n_p4) {
                        ::std::option::Option::Some(ti_p8) => match &ti_p8.body_p {
                            crate::check::env::TyBody::BRecord(fs_p9) => crate::prelude::run_to_end(crate::prelude::fold_job(fs_p9.clone(), false, {
                                let g_p0x = g_p0.clone();
                                let target_p2x = target_p2.clone();
                                let seen_p3x = seen_p3.clone();
                                let n_p4x = n_p4.clone();
                                ::std::rc::Rc::new(move |(p0, p1): (bool, (crate::prelude::Text, crate::check::types::Ty))| {
                                    let g_p0xy = g_p0x.clone();
                                    let target_p2xy = target_p2x.clone();
                                    let seen_p3xy = seen_p3x.clone();
                                    let n_p4xy = n_p4x.clone();
                                    crate::prelude::entered(crate::prelude::once_job(move || {
                                        let f_pa = p0;
                                        let (_, ft_pb) = p1;
                                        if f_pa {
                                            ::prism_rtl::Turn::Finished(true)
                                        } else {
                                            ::prism_rtl::Turn::More(::std::rc::Rc::new(Reaches { g_p0: g_p0xy.clone(), t_p1: ft_pb.clone(), target_p2: target_p2xy.clone(), seen_p3: crate::prelude::push(&seen_p3xy, &n_p4xy) }))
                                        }
                                    }))
                                }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, (crate::prelude::Text, crate::check::types::Ty))) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
                            })),
                            crate::check::env::TyBody::BChoice(cs_pc) => crate::prelude::run_to_end(crate::prelude::fold_job(cs_pc.clone(), false, {
                                let g_p0x = g_p0.clone();
                                let target_p2x = target_p2.clone();
                                let seen_p3x = seen_p3.clone();
                                let n_p4x = n_p4.clone();
                                ::std::rc::Rc::new(move |(p0, p1): (bool, (crate::prelude::Text, crate::prelude::Array<crate::check::types::Ty>))| {
                                    let g_p0xy = g_p0x.clone();
                                    let target_p2xy = target_p2x.clone();
                                    let seen_p3xy = seen_p3x.clone();
                                    let n_p4xy = n_p4x.clone();
                                    crate::prelude::entered(crate::prelude::once_job(move || {
                                        let f_pd = p0;
                                        let (_, ats_pe) = p1;
                                        if f_pd {
                                            ::prism_rtl::Turn::Finished(true)
                                        } else {
                                            crate::prelude::fold_job(ats_pe.clone(), false, {
                                                let g_p0xyx = g_p0xy.clone();
                                                let target_p2xyx = target_p2xy.clone();
                                                let seen_p3xyx = seen_p3xy.clone();
                                                let n_p4xyx = n_p4xy.clone();
                                                ::std::rc::Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| {
                                                    let g_p0xyxy = g_p0xyx.clone();
                                                    let target_p2xyxy = target_p2xyx.clone();
                                                    let seen_p3xyxy = seen_p3xyx.clone();
                                                    let n_p4xyxy = n_p4xyx.clone();
                                                    crate::prelude::entered(crate::prelude::once_job(move || {
                                                        let f2_pf = p0;
                                                        let at_pg = p1;
                                                        if f2_pf {
                                                            ::prism_rtl::Turn::Finished(true)
                                                        } else {
                                                            ::prism_rtl::Turn::More(::std::rc::Rc::new(Reaches { g_p0: g_p0xyxy.clone(), t_p1: at_pg.clone(), target_p2: target_p2xyxy.clone(), seen_p3: crate::prelude::push(&seen_p3xyxy, &n_p4xyxy) }))
                                                        }
                                                    }))
                                                }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::check::types::Ty)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
                                            }).cycle()
                                        }
                                    }))
                                }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, (crate::prelude::Text, crate::prelude::Array<crate::check::types::Ty>))) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
                            })),
                            crate::check::env::TyBody::BAlias(a_ph) => reaches_f(g_p0, a_ph, target_p2, &crate::prelude::push(seen_p3, n_p4)),
                            _ => false,
                        },
                        ::std::option::Option::None => false,
                    }
                }
            }
        },
        crate::check::types::Ty::TySig(m12426_1_0, i_pi) if (m12426_1_0 == &crate::prelude::Text::lit("?")) => reaches_f(g_p0, &**i_pi, target_p2, seen_p3),
        crate::check::types::Ty::TySig(m12426_2_0, i_pj) if (m12426_2_0 == &crate::prelude::Text::lit("~")) => reaches_f(g_p0, &**i_pj, target_p2, seen_p3),
        crate::check::types::Ty::TyTuple(ts_pk) => crate::prelude::run_to_end(crate::prelude::fold_job(ts_pk.clone(), false, {
            let g_p0x = g_p0.clone();
            let target_p2x = target_p2.clone();
            let seen_p3x = seen_p3.clone();
            ::std::rc::Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| {
                let g_p0xy = g_p0x.clone();
                let target_p2xy = target_p2x.clone();
                let seen_p3xy = seen_p3x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let f_pl = p0;
                    let a_pm = p1;
                    if f_pl {
                        ::prism_rtl::Turn::Finished(true)
                    } else {
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(Reaches { g_p0: g_p0xy.clone(), t_p1: a_pm.clone(), target_p2: target_p2xy.clone(), seen_p3: seen_p3xy.clone() }))
                    }
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::check::types::Ty)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
        })),
        _ => false,
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `Reaches`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Reaches: unbounded fn G, Ty, Text, [Text] -> Bool
/// ```
pub struct Reaches {
    pub g_p0: crate::check::env::G,
    pub t_p1: crate::check::types::Ty,
    pub target_p2: crate::prelude::Text,
    pub seen_p3: crate::prelude::Array<crate::prelude::Text>,
}

impl ::prism_rtl::Job<bool> for Reaches {
    fn cycle(&self) -> ::prism_rtl::Turn<bool> {
        let g_p0 = &self.g_p0;
        let t_p1 = &self.t_p1;
        let target_p2 = &self.target_p2;
        let seen_p3 = &self.seen_p3;
        match t_p1 {
            crate::check::types::Ty::TyCon(n_p4, args_p5) => if n_p4 == target_p2 {
                ::prism_rtl::Turn::Finished(true)
            } else {
                if crate::check::types::has_text_f(seen_p3, n_p4) {
                    ::prism_rtl::Turn::Finished(false)
                } else {
                    {
                        let args_p5x = args_p5.clone();
                        let g_p0x = g_p0.clone();
                        let n_p4x = n_p4.clone();
                        let seen_p3x = seen_p3.clone();
                        let target_p2x = target_p2.clone();
                        crate::prelude::call_value(crate::prelude::fold_job(args_p5x.clone(), false, {
                            let g_p0xx = g_p0x.clone();
                            let target_p2xx = target_p2x.clone();
                            let seen_p3xx = seen_p3x.clone();
                            ::std::rc::Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| {
                                let g_p0xxy = g_p0xx.clone();
                                let target_p2xxy = target_p2xx.clone();
                                let seen_p3xxy = seen_p3xx.clone();
                                crate::prelude::entered(crate::prelude::once_job(move || {
                                    let f_p6 = p0;
                                    let a_p7 = p1;
                                    if f_p6 {
                                        ::prism_rtl::Turn::Finished(true)
                                    } else {
                                        ::prism_rtl::Turn::More(::std::rc::Rc::new(Reaches { g_p0: g_p0xxy.clone(), t_p1: a_p7.clone(), target_p2: target_p2xxy.clone(), seen_p3: seen_p3xxy.clone() }))
                                    }
                                }))
                            }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::check::types::Ty)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
                        }), move |fold_12540: bool| if fold_12540 {
                            ::prism_rtl::Turn::Finished(true)
                        } else {
                            match crate::prelude::get(&g_p0x.types_p, &n_p4x) {
                                ::std::option::Option::Some(ti_p8) => match &ti_p8.body_p {
                                    crate::check::env::TyBody::BRecord(fs_p9) => crate::prelude::fold_job(fs_p9.clone(), false, {
                                        let g_p0xx = g_p0x.clone();
                                        let target_p2xx = target_p2x.clone();
                                        let seen_p3xx = seen_p3x.clone();
                                        let n_p4xx = n_p4x.clone();
                                        ::std::rc::Rc::new(move |(p0, p1): (bool, (crate::prelude::Text, crate::check::types::Ty))| {
                                            let g_p0xxy = g_p0xx.clone();
                                            let target_p2xxy = target_p2xx.clone();
                                            let seen_p3xxy = seen_p3xx.clone();
                                            let n_p4xxy = n_p4xx.clone();
                                            crate::prelude::entered(crate::prelude::once_job(move || {
                                                let f_pa = p0;
                                                let (_, ft_pb) = p1;
                                                if f_pa {
                                                    ::prism_rtl::Turn::Finished(true)
                                                } else {
                                                    ::prism_rtl::Turn::More(::std::rc::Rc::new(Reaches { g_p0: g_p0xxy.clone(), t_p1: ft_pb.clone(), target_p2: target_p2xxy.clone(), seen_p3: crate::prelude::push(&seen_p3xxy, &n_p4xxy) }))
                                                }
                                            }))
                                        }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, (crate::prelude::Text, crate::check::types::Ty))) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
                                    }).cycle(),
                                    crate::check::env::TyBody::BChoice(cs_pc) => crate::prelude::fold_job(cs_pc.clone(), false, {
                                        let g_p0xx = g_p0x.clone();
                                        let target_p2xx = target_p2x.clone();
                                        let seen_p3xx = seen_p3x.clone();
                                        let n_p4xx = n_p4x.clone();
                                        ::std::rc::Rc::new(move |(p0, p1): (bool, (crate::prelude::Text, crate::prelude::Array<crate::check::types::Ty>))| {
                                            let g_p0xxy = g_p0xx.clone();
                                            let target_p2xxy = target_p2xx.clone();
                                            let seen_p3xxy = seen_p3xx.clone();
                                            let n_p4xxy = n_p4xx.clone();
                                            crate::prelude::entered(crate::prelude::once_job(move || {
                                                let f_pd = p0;
                                                let (_, ats_pe) = p1;
                                                if f_pd {
                                                    ::prism_rtl::Turn::Finished(true)
                                                } else {
                                                    crate::prelude::fold_job(ats_pe.clone(), false, {
                                                        let g_p0xxyx = g_p0xxy.clone();
                                                        let target_p2xxyx = target_p2xxy.clone();
                                                        let seen_p3xxyx = seen_p3xxy.clone();
                                                        let n_p4xxyx = n_p4xxy.clone();
                                                        ::std::rc::Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| {
                                                            let g_p0xxyxy = g_p0xxyx.clone();
                                                            let target_p2xxyxy = target_p2xxyx.clone();
                                                            let seen_p3xxyxy = seen_p3xxyx.clone();
                                                            let n_p4xxyxy = n_p4xxyx.clone();
                                                            crate::prelude::entered(crate::prelude::once_job(move || {
                                                                let f2_pf = p0;
                                                                let at_pg = p1;
                                                                if f2_pf {
                                                                    ::prism_rtl::Turn::Finished(true)
                                                                } else {
                                                                    ::prism_rtl::Turn::More(::std::rc::Rc::new(Reaches { g_p0: g_p0xxyxy.clone(), t_p1: at_pg.clone(), target_p2: target_p2xxyxy.clone(), seen_p3: crate::prelude::push(&seen_p3xxyxy, &n_p4xxyxy) }))
                                                                }
                                                            }))
                                                        }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::check::types::Ty)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
                                                    }).cycle()
                                                }
                                            }))
                                        }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, (crate::prelude::Text, crate::prelude::Array<crate::check::types::Ty>))) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
                                    }).cycle(),
                                    crate::check::env::TyBody::BAlias(a_ph) => ::prism_rtl::Turn::More(::std::rc::Rc::new(Reaches { g_p0: g_p0x.clone(), t_p1: a_ph.clone(), target_p2: target_p2x.clone(), seen_p3: crate::prelude::push(&seen_p3x, &n_p4x) })),
                                    _ => ::prism_rtl::Turn::Finished(false),
                                },
                                ::std::option::Option::None => ::prism_rtl::Turn::Finished(false),
                            }
                        })
                    }
                }
            },
            crate::check::types::Ty::TySig(m12426_1_0, i_pi) if (m12426_1_0 == &crate::prelude::Text::lit("?")) => ::prism_rtl::Turn::More(::std::rc::Rc::new(Reaches { g_p0: g_p0.clone(), t_p1: (**i_pi).clone(), target_p2: target_p2.clone(), seen_p3: seen_p3.clone() })),
            crate::check::types::Ty::TySig(m12426_2_0, i_pj) if (m12426_2_0 == &crate::prelude::Text::lit("~")) => ::prism_rtl::Turn::More(::std::rc::Rc::new(Reaches { g_p0: g_p0.clone(), t_p1: (**i_pj).clone(), target_p2: target_p2.clone(), seen_p3: seen_p3.clone() })),
            crate::check::types::Ty::TyTuple(ts_pk) => crate::prelude::fold_job(ts_pk.clone(), false, {
                let g_p0x = g_p0.clone();
                let target_p2x = target_p2.clone();
                let seen_p3x = seen_p3.clone();
                ::std::rc::Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| {
                    let g_p0xy = g_p0x.clone();
                    let target_p2xy = target_p2x.clone();
                    let seen_p3xy = seen_p3x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let f_pl = p0;
                        let a_pm = p1;
                        if f_pl {
                            ::prism_rtl::Turn::Finished(true)
                        } else {
                            ::prism_rtl::Turn::More(::std::rc::Rc::new(Reaches { g_p0: g_p0xy.clone(), t_p1: a_pm.clone(), target_p2: target_p2xy.clone(), seen_p3: seen_p3xy.clone() }))
                        }
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::check::types::Ty)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
            }).cycle(),
            _ => ::prism_rtl::Turn::Finished(false),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start Reaches, x`: what the function value is when passed to `@Run`.
pub fn start_reaches_f(g_p0: crate::check::env::G, t_p1: crate::check::types::Ty, target_p2: crate::prelude::Text, seen_p3: crate::prelude::Array<crate::prelude::Text>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>> {
    ::std::rc::Rc::new(Reaches { g_p0, t_p1, target_p2, seen_p3 })
}

/// ```prism
/// RcField: fn Lx, Text, Nat -> Bool
/// ```
pub fn rc_field_f(lx_p0: &crate::lower::Lx, ctor_p1: &crate::prelude::Text, i_p2: &crate::prelude::Nat) -> bool {
    crate::prelude::or(&crate::prelude::index(&crate::prelude::or(&crate::prelude::get(&lx_p0.layouts_p, ctor_p1), &crate::prelude::Array::new()), i_p2), &false)
}

/// ```prism
/// TagFieldOut: unbounded fn Lx, Ty -> OutTy
/// ```
pub fn tag_field_out_f(lx_p0: &crate::lower::Lx, ft_p1: &crate::check::types::Ty) -> crate::lower::model::OutTy {
    let own_p2 = {
        let mut this: crate::lower::Lx = lx_p0.clone();
        this.subst_p = crate::prelude::Map::new();
        this
    };
    erased_out_f(&out_ty_of_f(&own_p2, &peel_f(ft_p1)))
}

/// The step machine of `TagFieldOut`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TagFieldOut: unbounded fn Lx, Ty -> OutTy
/// ```
pub struct TagFieldOut {
    pub lx_p0: crate::lower::Lx,
    pub ft_p1: crate::check::types::Ty,
}

impl ::prism_rtl::Job<crate::lower::model::OutTy> for TagFieldOut {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::lower::model::OutTy> {
        let lx_p0 = &self.lx_p0;
        let ft_p1 = &self.ft_p1;
        let own_p2 = {
            let mut this: crate::lower::Lx = lx_p0.clone();
            this.subst_p = crate::prelude::Map::new();
            this
        };
        let ft_p1x = ft_p1.clone();
        crate::prelude::call_then(start_out_ty_of_f(own_p2.clone(), peel_f(&ft_p1x)), move |out_ty_of_f_14174: crate::lower::model::OutTy| ::prism_rtl::Turn::More(::std::rc::Rc::new(ErasedOut { t_p0: out_ty_of_f_14174 })))
    }
}

/// `Start TagFieldOut, x`: what the function value is when passed to `@Run`.
pub fn start_tag_field_out_f(lx_p0: crate::lower::Lx, ft_p1: crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::OutTy>> {
    ::std::rc::Rc::new(TagFieldOut { lx_p0, ft_p1 })
}

/// ```prism
/// TagFieldOpen: unbounded fn Lx, Ty -> Bool
/// ```
pub fn tag_field_open_f(lx_p0: &crate::lower::Lx, ft_p1: &crate::check::types::Ty) -> bool {
    let own_p2 = {
        let mut this: crate::lower::Lx = lx_p0.clone();
        this.subst_p = crate::prelude::Map::new();
        this
    };
    holds_gen_f(&out_ty_of_f(&own_p2, &peel_f(ft_p1)))
}

/// The step machine of `TagFieldOpen`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TagFieldOpen: unbounded fn Lx, Ty -> Bool
/// ```
pub struct TagFieldOpen {
    pub lx_p0: crate::lower::Lx,
    pub ft_p1: crate::check::types::Ty,
}

impl ::prism_rtl::Job<bool> for TagFieldOpen {
    fn cycle(&self) -> ::prism_rtl::Turn<bool> {
        let lx_p0 = &self.lx_p0;
        let ft_p1 = &self.ft_p1;
        let own_p2 = {
            let mut this: crate::lower::Lx = lx_p0.clone();
            this.subst_p = crate::prelude::Map::new();
            this
        };
        let ft_p1x = ft_p1.clone();
        crate::prelude::call_then(start_out_ty_of_f(own_p2.clone(), peel_f(&ft_p1x)), move |out_ty_of_f_14390: crate::lower::model::OutTy| ::prism_rtl::Turn::Finished(holds_gen_f(&out_ty_of_f_14390)))
    }
}

/// `Start TagFieldOpen, x`: what the function value is when passed to `@Run`.
pub fn start_tag_field_open_f(lx_p0: crate::lower::Lx, ft_p1: crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>> {
    ::std::rc::Rc::new(TagFieldOpen { lx_p0, ft_p1 })
}

/// ```prism
/// ErasedOut: unbounded fn OutTy -> OutTy
/// ```
pub fn erased_out_f(t_p0: &crate::lower::model::OutTy) -> crate::lower::model::OutTy {
    match t_p0 {
        crate::lower::model::OutTy::OutGen(_) => crate::lower::model::OutTy::OutPod,
        crate::lower::model::OutTy::OutNamed(r_p1, args_p2) => crate::lower::model::OutTy::OutNamed(r_p1.clone(), crate::prelude::run_to_end(crate::prelude::each_job(args_p2.clone(), ::std::rc::Rc::new(move |p0: crate::lower::model::OutTy| crate::prelude::entered(crate::prelude::once_job(move || {
            let a_p3 = p0;
            ::prism_rtl::Turn::More(::std::rc::Rc::new(ErasedOut { t_p0: a_p3.clone() }))
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::OutTy) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::OutTy>>>))),
        crate::lower::model::OutTy::OutOpt(i_p4) => crate::lower::model::OutTy::OutOpt(::std::rc::Rc::new(erased_out_f(&**i_p4))),
        crate::lower::model::OutTy::OutRes(i_p5) => crate::lower::model::OutTy::OutRes(::std::rc::Rc::new(erased_out_f(&**i_p5))),
        crate::lower::model::OutTy::OutRc(i_p6) => crate::lower::model::OutTy::OutRc(::std::rc::Rc::new(erased_out_f(&**i_p6))),
        crate::lower::model::OutTy::OutTuple(ts_p7) => crate::lower::model::OutTy::OutTuple(crate::prelude::run_to_end(crate::prelude::each_job(ts_p7.clone(), ::std::rc::Rc::new(move |p0: crate::lower::model::OutTy| crate::prelude::entered(crate::prelude::once_job(move || {
            let a_p8 = p0;
            ::prism_rtl::Turn::More(::std::rc::Rc::new(ErasedOut { t_p0: a_p8.clone() }))
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::OutTy) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::OutTy>>>))),
        crate::lower::model::OutTy::OutArray(e_p9) => crate::lower::model::OutTy::OutArray(::std::rc::Rc::new(erased_out_f(&**e_p9))),
        crate::lower::model::OutTy::OutMap(k_pa, v_pb) => crate::lower::model::OutTy::OutMap(::std::rc::Rc::new(erased_out_f(&**k_pa)), ::std::rc::Rc::new(erased_out_f(&**v_pb))),
        crate::lower::model::OutTy::OutEvent(i_pc) => crate::lower::model::OutTy::OutEvent(::std::rc::Rc::new(erased_out_f(&**i_pc))),
        crate::lower::model::OutTy::OutDyn(i_pd) => crate::lower::model::OutTy::OutDyn(::std::rc::Rc::new(erased_out_f(&**i_pd))),
        crate::lower::model::OutTy::OutFn(ps_pe, r_pf) => crate::lower::model::OutTy::OutFn(crate::prelude::run_to_end(crate::prelude::each_job(ps_pe.clone(), ::std::rc::Rc::new(move |p0: crate::lower::model::OutTy| crate::prelude::entered(crate::prelude::once_job(move || {
            let a_pg = p0;
            ::prism_rtl::Turn::More(::std::rc::Rc::new(ErasedOut { t_p0: a_pg.clone() }))
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::OutTy) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::OutTy>>>)), ::std::rc::Rc::new(erased_out_f(&**r_pf))),
        crate::lower::model::OutTy::OutJobFn(a_ph, r_pi) => crate::lower::model::OutTy::OutJobFn(::std::rc::Rc::new(erased_out_f(&**a_ph)), ::std::rc::Rc::new(erased_out_f(&**r_pi))),
        _ => t_p0.clone(),
    }
}

/// The step machine of `ErasedOut`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ErasedOut: unbounded fn OutTy -> OutTy
/// ```
pub struct ErasedOut {
    pub t_p0: crate::lower::model::OutTy,
}

impl ::prism_rtl::Job<crate::lower::model::OutTy> for ErasedOut {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::lower::model::OutTy> {
        let t_p0 = &self.t_p0;
        match t_p0 {
            crate::lower::model::OutTy::OutGen(_) => ::prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutPod),
            crate::lower::model::OutTy::OutNamed(r_p1, args_p2) => {
                let args_p2x = args_p2.clone();
                let r_p1x = r_p1.clone();
                crate::prelude::call_value(crate::prelude::each_job(args_p2x.clone(), ::std::rc::Rc::new(move |p0: crate::lower::model::OutTy| crate::prelude::entered(crate::prelude::once_job(move || {
                    let a_p3 = p0;
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(ErasedOut { t_p0: a_p3.clone() }))
                }))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::OutTy) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::OutTy>>>), move |each_14541: crate::prelude::Array<crate::lower::model::OutTy>| ::prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutNamed(r_p1x.clone(), each_14541)))
            },
            crate::lower::model::OutTy::OutOpt(i_p4) => {
                let i_p4x = (**i_p4).clone();
                crate::prelude::call_then(start_erased_out_f(i_p4x.clone()), move |erased_out_f_14592: crate::lower::model::OutTy| ::prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutOpt(::std::rc::Rc::new(erased_out_f_14592))))
            },
            crate::lower::model::OutTy::OutRes(i_p5) => {
                let i_p5x = (**i_p5).clone();
                crate::prelude::call_then(start_erased_out_f(i_p5x.clone()), move |erased_out_f_14627: crate::lower::model::OutTy| ::prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutRes(::std::rc::Rc::new(erased_out_f_14627))))
            },
            crate::lower::model::OutTy::OutRc(i_p6) => {
                let i_p6x = (**i_p6).clone();
                crate::prelude::call_then(start_erased_out_f(i_p6x.clone()), move |erased_out_f_14660: crate::lower::model::OutTy| ::prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutRc(::std::rc::Rc::new(erased_out_f_14660))))
            },
            crate::lower::model::OutTy::OutTuple(ts_p7) => {
                let ts_p7x = ts_p7.clone();
                crate::prelude::call_value(crate::prelude::each_job(ts_p7x.clone(), ::std::rc::Rc::new(move |p0: crate::lower::model::OutTy| crate::prelude::entered(crate::prelude::once_job(move || {
                    let a_p8 = p0;
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(ErasedOut { t_p0: a_p8.clone() }))
                }))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::OutTy) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::OutTy>>>), move |each_14700: crate::prelude::Array<crate::lower::model::OutTy>| ::prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutTuple(each_14700)))
            },
            crate::lower::model::OutTy::OutArray(e_p9) => {
                let e_p9x = (**e_p9).clone();
                crate::prelude::call_then(start_erased_out_f(e_p9x.clone()), move |erased_out_f_14753: crate::lower::model::OutTy| ::prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutArray(::std::rc::Rc::new(erased_out_f_14753))))
            },
            crate::lower::model::OutTy::OutMap(k_pa, v_pb) => {
                let k_pax = (**k_pa).clone();
                let v_pbx = (**v_pb).clone();
                crate::prelude::call_then(start_erased_out_f(k_pax.clone()), move |erased_out_f_14791: crate::lower::model::OutTy| crate::prelude::call_then(start_erased_out_f(v_pbx.clone()), move |erased_out_f_14806: crate::lower::model::OutTy| ::prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutMap(::std::rc::Rc::new(erased_out_f_14791), ::std::rc::Rc::new(erased_out_f_14806)))))
            },
            crate::lower::model::OutTy::OutEvent(i_pc) => {
                let i_pcx = (**i_pc).clone();
                crate::prelude::call_then(start_erased_out_f(i_pcx.clone()), move |erased_out_f_14845: crate::lower::model::OutTy| ::prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutEvent(::std::rc::Rc::new(erased_out_f_14845))))
            },
            crate::lower::model::OutTy::OutDyn(i_pd) => {
                let i_pdx = (**i_pd).clone();
                crate::prelude::call_then(start_erased_out_f(i_pdx.clone()), move |erased_out_f_14880: crate::lower::model::OutTy| ::prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutDyn(::std::rc::Rc::new(erased_out_f_14880))))
            },
            crate::lower::model::OutTy::OutFn(ps_pe, r_pf) => {
                let ps_pex = ps_pe.clone();
                let r_pfx = (**r_pf).clone();
                crate::prelude::call_value(crate::prelude::each_job(ps_pex.clone(), ::std::rc::Rc::new(move |p0: crate::lower::model::OutTy| crate::prelude::entered(crate::prelude::once_job(move || {
                    let a_pg = p0;
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(ErasedOut { t_p0: a_pg.clone() }))
                }))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::OutTy) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::OutTy>>>), move |each_14917: crate::prelude::Array<crate::lower::model::OutTy>| crate::prelude::call_then(start_erased_out_f(r_pfx.clone()), move |erased_out_f_14946: crate::lower::model::OutTy| ::prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutFn(each_14917, ::std::rc::Rc::new(erased_out_f_14946)))))
            },
            crate::lower::model::OutTy::OutJobFn(a_ph, r_pi) => {
                let a_phx = (**a_ph).clone();
                let r_pix = (**r_pi).clone();
                crate::prelude::call_then(start_erased_out_f(a_phx.clone()), move |erased_out_f_14988: crate::lower::model::OutTy| crate::prelude::call_then(start_erased_out_f(r_pix.clone()), move |erased_out_f_15003: crate::lower::model::OutTy| ::prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutJobFn(::std::rc::Rc::new(erased_out_f_14988), ::std::rc::Rc::new(erased_out_f_15003)))))
            },
            _ => ::prism_rtl::Turn::Finished(t_p0.clone()),
        }
    }
}

/// `Start ErasedOut, x`: what the function value is when passed to `@Run`.
pub fn start_erased_out_f(t_p0: crate::lower::model::OutTy) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::OutTy>> {
    ::std::rc::Rc::new(ErasedOut { t_p0 })
}

/// ```prism
/// HoldsGen: unbounded fn OutTy -> Bool
/// ```
pub fn holds_gen_f(t_p0: &crate::lower::model::OutTy) -> bool {
    t_p0 != &erased_out_f(t_p0)
}

/// ```prism
/// RecodedField: unbounded fn Lx, Ty, Ex -> Ex
/// ```
pub fn recoded_field_f(lx_p0: &crate::lower::Lx, ft_p1: &crate::check::types::Ty, value_p2: &crate::lower::model::Ex) -> crate::lower::model::Ex {
    if !tag_field_open_f(lx_p0, ft_p1) {
        value_p2.clone()
    } else {
        {
            let erased_p3 = tag_field_out_f(lx_p0, ft_p1);
            crate::lower::model::Ex::XCallAt(crate::lower::helper_ref_f(&crate::prelude::Text::lit("recode")), crate::prelude::Array::from(vec![erased_p3.clone()]), crate::prelude::Array::from(vec![crate::lower::model::Ex::XRef(::std::rc::Rc::new(value_p2.clone()))]))
        }
    }
}

/// The step machine of `RecodedField`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RecodedField: unbounded fn Lx, Ty, Ex -> Ex
/// ```
pub struct RecodedField {
    pub lx_p0: crate::lower::Lx,
    pub ft_p1: crate::check::types::Ty,
    pub value_p2: crate::lower::model::Ex,
}

impl ::prism_rtl::Job<crate::lower::model::Ex> for RecodedField {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::lower::model::Ex> {
        let lx_p0 = &self.lx_p0;
        let ft_p1 = &self.ft_p1;
        let value_p2 = &self.value_p2;
        let ft_p1x = ft_p1.clone();
        let lx_p0x = lx_p0.clone();
        let value_p2x = value_p2.clone();
        crate::prelude::call_then(start_tag_field_open_f(lx_p0x.clone(), ft_p1x.clone()), move |tag_field_open_f_15447: bool| if !tag_field_open_f_15447 {
            ::prism_rtl::Turn::Finished(value_p2x.clone())
        } else {
            crate::prelude::call_then(start_tag_field_out_f(lx_p0x.clone(), ft_p1x.clone()), move |tag_field_out_f_15498: crate::lower::model::OutTy| {
                let erased_p3 = tag_field_out_f_15498;
                ::prism_rtl::Turn::Finished(crate::lower::model::Ex::XCallAt(crate::lower::helper_ref_f(&crate::prelude::Text::lit("recode")), crate::prelude::Array::from(vec![erased_p3.clone()]), crate::prelude::Array::from(vec![crate::lower::model::Ex::XRef(::std::rc::Rc::new(value_p2x.clone()))])))
            })
        })
    }
}

/// `Start RecodedField, x`: what the function value is when passed to `@Run`.
pub fn start_recoded_field_f(lx_p0: crate::lower::Lx, ft_p1: crate::check::types::Ty, value_p2: crate::lower::model::Ex) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>> {
    ::std::rc::Rc::new(RecodedField { lx_p0, ft_p1, value_p2 })
}

/// ```prism
/// RecodedWhole: unbounded fn Lx, Ty, Ex -> Ex
/// ```
pub fn recoded_whole_f(lx_p0: &crate::lower::Lx, ft_p1: &crate::check::types::Ty, value_p2: &crate::lower::model::Ex) -> crate::lower::model::Ex {
    if !tag_field_open_f(lx_p0, ft_p1) {
        value_p2.clone()
    } else {
        match layer_of_f(ft_p1) {
            Layer::LyPlain => recoded_field_f(lx_p0, ft_p1, value_p2),
            _ => crate::lower::model::Ex::XMethod(::std::rc::Rc::new(value_p2.clone()), crate::prelude::Text::lit("map"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XClosure(true, crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("open"))]), ::std::rc::Rc::new(crate::lower::model::Ex::XCallAt(crate::lower::helper_ref_f(&crate::prelude::Text::lit("recode")), crate::prelude::Array::from(vec![tag_field_out_f(lx_p0, ft_p1)]), crate::prelude::Array::from(vec![crate::lower::model::Ex::XVar(crate::prelude::Text::lit("open"))]))))])),
        }
    }
}

/// The step machine of `RecodedWhole`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RecodedWhole: unbounded fn Lx, Ty, Ex -> Ex
/// ```
pub struct RecodedWhole {
    pub lx_p0: crate::lower::Lx,
    pub ft_p1: crate::check::types::Ty,
    pub value_p2: crate::lower::model::Ex,
}

impl ::prism_rtl::Job<crate::lower::model::Ex> for RecodedWhole {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::lower::model::Ex> {
        let lx_p0 = &self.lx_p0;
        let ft_p1 = &self.ft_p1;
        let value_p2 = &self.value_p2;
        let ft_p1x = ft_p1.clone();
        let lx_p0x = lx_p0.clone();
        let value_p2x = value_p2.clone();
        crate::prelude::call_then(start_tag_field_open_f(lx_p0x.clone(), ft_p1x.clone()), move |tag_field_open_f_15742: bool| if !tag_field_open_f_15742 {
            ::prism_rtl::Turn::Finished(value_p2x.clone())
        } else {
            match layer_of_f(&ft_p1x) {
                Layer::LyPlain => ::prism_rtl::Turn::More(::std::rc::Rc::new(RecodedField { lx_p0: lx_p0x.clone(), ft_p1: ft_p1x.clone(), value_p2: value_p2x.clone() })),
                _ => crate::prelude::call_then(start_tag_field_out_f(lx_p0x.clone(), ft_p1x.clone()), move |tag_field_out_f_15942: crate::lower::model::OutTy| ::prism_rtl::Turn::Finished(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(value_p2x.clone()), crate::prelude::Text::lit("map"), crate::prelude::Array::from(vec![crate::lower::model::Ex::XClosure(true, crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(crate::prelude::Text::lit("open"))]), ::std::rc::Rc::new(crate::lower::model::Ex::XCallAt(crate::lower::helper_ref_f(&crate::prelude::Text::lit("recode")), crate::prelude::Array::from(vec![tag_field_out_f_15942]), crate::prelude::Array::from(vec![crate::lower::model::Ex::XVar(crate::prelude::Text::lit("open"))]))))])))),
            }
        })
    }
}

/// `Start RecodedWhole, x`: what the function value is when passed to `@Run`.
pub fn start_recoded_whole_f(lx_p0: crate::lower::Lx, ft_p1: crate::check::types::Ty, value_p2: crate::lower::model::Ex) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>> {
    ::std::rc::Rc::new(RecodedWhole { lx_p0, ft_p1, value_p2 })
}

/// ```prism
/// Podable: unbounded fn OutTy -> Bool
/// ```
pub fn podable_f(t_p0: &crate::lower::model::OutTy) -> bool {
    match t_p0 {
        crate::lower::model::OutTy::OutFn(_, _) => false,
        crate::lower::model::OutTy::OutJobFn(_, _) => false,
        crate::lower::model::OutTy::OutJob(_) => false,
        crate::lower::model::OutTy::OutEvent(_) => false,
        crate::lower::model::OutTy::OutDyn(_) => false,
        crate::lower::model::OutTy::OutShowAny => false,
        crate::lower::model::OutTy::OutLive(_) => false,
        crate::lower::model::OutTy::OutRefused(_) => false,
        crate::lower::model::OutTy::OutGen(_) => true,
        crate::lower::model::OutTy::OutNamed(_, args_p1) => crate::prelude::run_to_end(crate::prelude::fold_job(args_p1.clone(), true, ::std::rc::Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| crate::prelude::entered(crate::prelude::once_job(move || {
            let ok_p2 = p0;
            let a_p3 = p1;
            if ok_p2 {
                ::prism_rtl::Turn::More(::std::rc::Rc::new(Podable { t_p0: a_p3.clone() }))
            } else {
                ::prism_rtl::Turn::Finished(false)
            }
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::lower::model::OutTy)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>)),
        crate::lower::model::OutTy::OutOpt(i_p4) => podable_f(&**i_p4),
        crate::lower::model::OutTy::OutRes(i_p5) => podable_f(&**i_p5),
        crate::lower::model::OutTy::OutRc(i_p6) => podable_f(&**i_p6),
        crate::lower::model::OutTy::OutTuple(ts_p7) => crate::prelude::run_to_end(crate::prelude::fold_job(ts_p7.clone(), true, ::std::rc::Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| crate::prelude::entered(crate::prelude::once_job(move || {
            let ok_p8 = p0;
            let a_p9 = p1;
            if ok_p8 {
                ::prism_rtl::Turn::More(::std::rc::Rc::new(Podable { t_p0: a_p9.clone() }))
            } else {
                ::prism_rtl::Turn::Finished(false)
            }
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::lower::model::OutTy)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>)),
        crate::lower::model::OutTy::OutArray(e_pa) => podable_f(&**e_pa),
        crate::lower::model::OutTy::OutMap(k_pb, v_pc) => podable_f(&**k_pb) && podable_f(&**v_pc),
        _ => true,
    }
}

/// The step machine of `Podable`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Podable: unbounded fn OutTy -> Bool
/// ```
pub struct Podable {
    pub t_p0: crate::lower::model::OutTy,
}

impl ::prism_rtl::Job<bool> for Podable {
    fn cycle(&self) -> ::prism_rtl::Turn<bool> {
        let t_p0 = &self.t_p0;
        match t_p0 {
            crate::lower::model::OutTy::OutFn(_, _) => ::prism_rtl::Turn::Finished(false),
            crate::lower::model::OutTy::OutJobFn(_, _) => ::prism_rtl::Turn::Finished(false),
            crate::lower::model::OutTy::OutJob(_) => ::prism_rtl::Turn::Finished(false),
            crate::lower::model::OutTy::OutEvent(_) => ::prism_rtl::Turn::Finished(false),
            crate::lower::model::OutTy::OutDyn(_) => ::prism_rtl::Turn::Finished(false),
            crate::lower::model::OutTy::OutShowAny => ::prism_rtl::Turn::Finished(false),
            crate::lower::model::OutTy::OutLive(_) => ::prism_rtl::Turn::Finished(false),
            crate::lower::model::OutTy::OutRefused(_) => ::prism_rtl::Turn::Finished(false),
            crate::lower::model::OutTy::OutGen(_) => ::prism_rtl::Turn::Finished(true),
            crate::lower::model::OutTy::OutNamed(_, args_p1) => crate::prelude::fold_job(args_p1.clone(), true, ::std::rc::Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| crate::prelude::entered(crate::prelude::once_job(move || {
                let ok_p2 = p0;
                let a_p3 = p1;
                if ok_p2 {
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(Podable { t_p0: a_p3.clone() }))
                } else {
                    ::prism_rtl::Turn::Finished(false)
                }
            }))) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::lower::model::OutTy)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>).cycle(),
            crate::lower::model::OutTy::OutOpt(i_p4) => ::prism_rtl::Turn::More(::std::rc::Rc::new(Podable { t_p0: (**i_p4).clone() })),
            crate::lower::model::OutTy::OutRes(i_p5) => ::prism_rtl::Turn::More(::std::rc::Rc::new(Podable { t_p0: (**i_p5).clone() })),
            crate::lower::model::OutTy::OutRc(i_p6) => ::prism_rtl::Turn::More(::std::rc::Rc::new(Podable { t_p0: (**i_p6).clone() })),
            crate::lower::model::OutTy::OutTuple(ts_p7) => crate::prelude::fold_job(ts_p7.clone(), true, ::std::rc::Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| crate::prelude::entered(crate::prelude::once_job(move || {
                let ok_p8 = p0;
                let a_p9 = p1;
                if ok_p8 {
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(Podable { t_p0: a_p9.clone() }))
                } else {
                    ::prism_rtl::Turn::Finished(false)
                }
            }))) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::lower::model::OutTy)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>).cycle(),
            crate::lower::model::OutTy::OutArray(e_pa) => ::prism_rtl::Turn::More(::std::rc::Rc::new(Podable { t_p0: (**e_pa).clone() })),
            crate::lower::model::OutTy::OutMap(k_pb, v_pc) => {
                let k_pbx = (**k_pb).clone();
                let v_pcx = (**v_pc).clone();
                crate::prelude::call_then(start_podable_f(k_pbx.clone()), move |podable_f_16599: bool| if podable_f_16599 {
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(Podable { t_p0: v_pcx.clone() }))
                } else {
                    ::prism_rtl::Turn::Finished(false)
                })
            },
            _ => ::prism_rtl::Turn::Finished(true),
        }
    }
}

/// `Start Podable, x`: what the function value is when passed to `@Run`.
pub fn start_podable_f(t_p0: crate::lower::model::OutTy) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>> {
    ::std::rc::Rc::new(Podable { t_p0 })
}

/// ```prism
/// RuntimeEq: unbounded fn OutTy -> Bool
/// ```
pub fn runtime_eq_f(t_p0: &crate::lower::model::OutTy) -> bool {
    match t_p0 {
        crate::lower::model::OutTy::OutDyn(_) => true,
        crate::lower::model::OutTy::OutNamed(_, args_p1) => crate::prelude::run_to_end(crate::prelude::fold_job(args_p1.clone(), true, ::std::rc::Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| crate::prelude::entered(crate::prelude::once_job(move || {
            let ok_p2 = p0;
            let a_p3 = p1;
            if ok_p2 {
                ::prism_rtl::Turn::More(::std::rc::Rc::new(RuntimeEq { t_p0: a_p3.clone() }))
            } else {
                ::prism_rtl::Turn::Finished(false)
            }
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::lower::model::OutTy)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>)),
        crate::lower::model::OutTy::OutOpt(i_p4) => runtime_eq_f(&**i_p4),
        crate::lower::model::OutTy::OutRes(i_p5) => runtime_eq_f(&**i_p5),
        crate::lower::model::OutTy::OutRc(i_p6) => runtime_eq_f(&**i_p6),
        crate::lower::model::OutTy::OutTuple(ts_p7) => crate::prelude::run_to_end(crate::prelude::fold_job(ts_p7.clone(), true, ::std::rc::Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| crate::prelude::entered(crate::prelude::once_job(move || {
            let ok_p8 = p0;
            let a_p9 = p1;
            if ok_p8 {
                ::prism_rtl::Turn::More(::std::rc::Rc::new(RuntimeEq { t_p0: a_p9.clone() }))
            } else {
                ::prism_rtl::Turn::Finished(false)
            }
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::lower::model::OutTy)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>)),
        crate::lower::model::OutTy::OutArray(e_pa) => runtime_eq_f(&**e_pa),
        crate::lower::model::OutTy::OutMap(k_pb, v_pc) => runtime_eq_f(&**k_pb) && runtime_eq_f(&**v_pc),
        other_pd => podable_f(other_pd),
    }
}

/// The step machine of `RuntimeEq`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RuntimeEq: unbounded fn OutTy -> Bool
/// ```
pub struct RuntimeEq {
    pub t_p0: crate::lower::model::OutTy,
}

impl ::prism_rtl::Job<bool> for RuntimeEq {
    fn cycle(&self) -> ::prism_rtl::Turn<bool> {
        let t_p0 = &self.t_p0;
        match t_p0 {
            crate::lower::model::OutTy::OutDyn(_) => ::prism_rtl::Turn::Finished(true),
            crate::lower::model::OutTy::OutNamed(_, args_p1) => crate::prelude::fold_job(args_p1.clone(), true, ::std::rc::Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| crate::prelude::entered(crate::prelude::once_job(move || {
                let ok_p2 = p0;
                let a_p3 = p1;
                if ok_p2 {
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(RuntimeEq { t_p0: a_p3.clone() }))
                } else {
                    ::prism_rtl::Turn::Finished(false)
                }
            }))) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::lower::model::OutTy)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>).cycle(),
            crate::lower::model::OutTy::OutOpt(i_p4) => ::prism_rtl::Turn::More(::std::rc::Rc::new(RuntimeEq { t_p0: (**i_p4).clone() })),
            crate::lower::model::OutTy::OutRes(i_p5) => ::prism_rtl::Turn::More(::std::rc::Rc::new(RuntimeEq { t_p0: (**i_p5).clone() })),
            crate::lower::model::OutTy::OutRc(i_p6) => ::prism_rtl::Turn::More(::std::rc::Rc::new(RuntimeEq { t_p0: (**i_p6).clone() })),
            crate::lower::model::OutTy::OutTuple(ts_p7) => crate::prelude::fold_job(ts_p7.clone(), true, ::std::rc::Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| crate::prelude::entered(crate::prelude::once_job(move || {
                let ok_p8 = p0;
                let a_p9 = p1;
                if ok_p8 {
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(RuntimeEq { t_p0: a_p9.clone() }))
                } else {
                    ::prism_rtl::Turn::Finished(false)
                }
            }))) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::lower::model::OutTy)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>).cycle(),
            crate::lower::model::OutTy::OutArray(e_pa) => ::prism_rtl::Turn::More(::std::rc::Rc::new(RuntimeEq { t_p0: (**e_pa).clone() })),
            crate::lower::model::OutTy::OutMap(k_pb, v_pc) => {
                let k_pbx = (**k_pb).clone();
                let v_pcx = (**v_pc).clone();
                crate::prelude::call_then(start_runtime_eq_f(k_pbx.clone()), move |runtime_eq_f_17231: bool| if runtime_eq_f_17231 {
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(RuntimeEq { t_p0: v_pcx.clone() }))
                } else {
                    ::prism_rtl::Turn::Finished(false)
                })
            },
            other_pd => ::prism_rtl::Turn::More(::std::rc::Rc::new(Podable { t_p0: other_pd.clone() })),
        }
    }
}

/// `Start RuntimeEq, x`: what the function value is when passed to `@Run`.
pub fn start_runtime_eq_f(t_p0: crate::lower::model::OutTy) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>> {
    ::std::rc::Rc::new(RuntimeEq { t_p0 })
}

/// ```prism
/// HoldsDyn: unbounded fn OutTy -> Bool
/// ```
pub fn holds_dyn_f(t_p0: &crate::lower::model::OutTy) -> bool {
    match t_p0 {
        crate::lower::model::OutTy::OutDyn(_) => true,
        crate::lower::model::OutTy::OutNamed(_, args_p1) => crate::prelude::run_to_end(crate::prelude::fold_job(args_p1.clone(), false, ::std::rc::Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| crate::prelude::entered(crate::prelude::once_job(move || {
            let f_p2 = p0;
            let a_p3 = p1;
            if f_p2 {
                ::prism_rtl::Turn::Finished(true)
            } else {
                ::prism_rtl::Turn::More(::std::rc::Rc::new(HoldsDyn { t_p0: a_p3.clone() }))
            }
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::lower::model::OutTy)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>)),
        crate::lower::model::OutTy::OutOpt(i_p4) => holds_dyn_f(&**i_p4),
        crate::lower::model::OutTy::OutRes(i_p5) => holds_dyn_f(&**i_p5),
        crate::lower::model::OutTy::OutRc(i_p6) => holds_dyn_f(&**i_p6),
        crate::lower::model::OutTy::OutTuple(ts_p7) => crate::prelude::run_to_end(crate::prelude::fold_job(ts_p7.clone(), false, ::std::rc::Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| crate::prelude::entered(crate::prelude::once_job(move || {
            let f_p8 = p0;
            let a_p9 = p1;
            if f_p8 {
                ::prism_rtl::Turn::Finished(true)
            } else {
                ::prism_rtl::Turn::More(::std::rc::Rc::new(HoldsDyn { t_p0: a_p9.clone() }))
            }
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::lower::model::OutTy)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>)),
        crate::lower::model::OutTy::OutArray(e_pa) => holds_dyn_f(&**e_pa),
        crate::lower::model::OutTy::OutMap(k_pb, v_pc) => holds_dyn_f(&**k_pb) || holds_dyn_f(&**v_pc),
        _ => false,
    }
}

/// The step machine of `HoldsDyn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// HoldsDyn: unbounded fn OutTy -> Bool
/// ```
pub struct HoldsDyn {
    pub t_p0: crate::lower::model::OutTy,
}

impl ::prism_rtl::Job<bool> for HoldsDyn {
    fn cycle(&self) -> ::prism_rtl::Turn<bool> {
        let t_p0 = &self.t_p0;
        match t_p0 {
            crate::lower::model::OutTy::OutDyn(_) => ::prism_rtl::Turn::Finished(true),
            crate::lower::model::OutTy::OutNamed(_, args_p1) => crate::prelude::fold_job(args_p1.clone(), false, ::std::rc::Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| crate::prelude::entered(crate::prelude::once_job(move || {
                let f_p2 = p0;
                let a_p3 = p1;
                if f_p2 {
                    ::prism_rtl::Turn::Finished(true)
                } else {
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(HoldsDyn { t_p0: a_p3.clone() }))
                }
            }))) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::lower::model::OutTy)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>).cycle(),
            crate::lower::model::OutTy::OutOpt(i_p4) => ::prism_rtl::Turn::More(::std::rc::Rc::new(HoldsDyn { t_p0: (**i_p4).clone() })),
            crate::lower::model::OutTy::OutRes(i_p5) => ::prism_rtl::Turn::More(::std::rc::Rc::new(HoldsDyn { t_p0: (**i_p5).clone() })),
            crate::lower::model::OutTy::OutRc(i_p6) => ::prism_rtl::Turn::More(::std::rc::Rc::new(HoldsDyn { t_p0: (**i_p6).clone() })),
            crate::lower::model::OutTy::OutTuple(ts_p7) => crate::prelude::fold_job(ts_p7.clone(), false, ::std::rc::Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| crate::prelude::entered(crate::prelude::once_job(move || {
                let f_p8 = p0;
                let a_p9 = p1;
                if f_p8 {
                    ::prism_rtl::Turn::Finished(true)
                } else {
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(HoldsDyn { t_p0: a_p9.clone() }))
                }
            }))) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::lower::model::OutTy)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>).cycle(),
            crate::lower::model::OutTy::OutArray(e_pa) => ::prism_rtl::Turn::More(::std::rc::Rc::new(HoldsDyn { t_p0: (**e_pa).clone() })),
            crate::lower::model::OutTy::OutMap(k_pb, v_pc) => {
                let k_pbx = (**k_pb).clone();
                let v_pcx = (**v_pc).clone();
                crate::prelude::call_then(start_holds_dyn_f(k_pbx.clone()), move |holds_dyn_f_17693: bool| if holds_dyn_f_17693 {
                    ::prism_rtl::Turn::Finished(true)
                } else {
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(HoldsDyn { t_p0: v_pcx.clone() }))
                })
            },
            _ => ::prism_rtl::Turn::Finished(false),
        }
    }
}

/// `Start HoldsDyn, x`: what the function value is when passed to `@Run`.
pub fn start_holds_dyn_f(t_p0: crate::lower::model::OutTy) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>> {
    ::std::rc::Rc::new(HoldsDyn { t_p0 })
}

/// ```prism
/// let emptyEnv
/// ```
pub fn empty_env_p() -> Env {
    Env { names_p: crate::prelude::Map::new(), spans_p: crate::prelude::Map::new(), uses_p: crate::prelude::Map::new() }
}

/// ```prism
/// NameKeyAt: fn Lx, Env, SName, Range -> Text
/// ```
pub fn name_key_at_f(lx_p0: &crate::lower::Lx, env_p1: &Env, n_p2: &crate::syntax::SName, span_p3: &crate::syntax::Range) -> crate::prelude::Text {
    match crate::prelude::get(&lx_p0.use_insts_p, &crate::lower::place_key_f(lx_p0, span_p3)) {
        ::std::option::Option::Some(u_p4) => crate::prelude::or(&crate::prelude::get(&env_p1.uses_p, &crate::prelude::Text::from(format!("{}#{}", &crate::check::env::sname_key_f(n_p2), &crate::prelude::show_text(&crate::lower::expr::inst_at_f(lx_p0, &u_p4))))), &crate::check::env::sname_key_f(n_p2)),
        ::std::option::Option::None => crate::check::env::sname_key_f(n_p2),
    }
}

/// ```prism
/// WithInstances: fn Env, [Text] -> [Text]
/// ```
pub fn with_instances_f(env_p0: &Env, names_p1: &crate::prelude::Array<crate::prelude::Text>) -> crate::prelude::Array<crate::prelude::Text> {
    crate::prelude::fold(names_p1, names_p1, &(|acc_p2: &crate::prelude::Array<crate::prelude::Text>, n_p3: &crate::prelude::Text| crate::prelude::append(acc_p2, &crate::prelude::filter(&crate::prelude::keys(&env_p0.names_p), &(|k_p4: &crate::prelude::Text| crate::syntax::lexer::chars::has_prefix_f(k_p4, &crate::prelude::Text::from(format!("{}#inst", n_p3))))))))
}

/// ```prism
/// BindSpan: fn Env, Text, Vl -> Env
/// ```
pub fn bind_span_f(env_p0: &Env, nkey_p1: &crate::prelude::Text, v_p2: &Vl) -> Env {
    let mut this: Env = env_p0.clone();
    this.spans_p = crate::prelude::insert(&this.spans_p, nkey_p1, v_p2);
    this
}

/// ```prism
/// Bind: fn Env, Text, Bn -> Env
/// ```
pub fn bind_f(env_p0: &Env, name_p1: &crate::prelude::Text, b_p2: &Bn) -> Env {
    let mut this: Env = env_p0.clone();
    this.names_p = crate::prelude::insert(&this.names_p, name_p1, b_p2);
    this
}

/// ```prism
/// ValueTy: fn Vl -> OutTy
/// ```
pub fn value_ty_f(vl0: &Vl) -> crate::lower::model::OutTy {
    match vl0 {
        Vl::VlPlace(_, _, t_p0) => t_p0.clone(),
        Vl::VlOwned(_, t_p1) => t_p1.clone(),
    }
}

/// ```prism
/// LocalPlace: fn Ex, Holding, OutTy -> Vl
/// ```
pub fn local_place_f(x_p0: &crate::lower::model::Ex, mode_p1: &Holding, t_p2: &crate::lower::model::OutTy) -> Vl {
    Vl::VlPlace(x_p0.clone(), mode_p1.clone(), t_p2.clone())
}

/// ```prism
/// PlaceStem: fn Ex -> Text
/// ```
pub fn place_stem_f(x_p0: &crate::lower::model::Ex) -> crate::prelude::Text {
    match x_p0 {
        crate::lower::model::Ex::XVar(n_p1) => n_p1.clone(),
        crate::lower::model::Ex::XField(_, f_p2) => f_p2.clone(),
        crate::lower::model::Ex::XFieldOf(_, _, f_p3) => f_p3.clone(),
        crate::lower::model::Ex::XTarget(y_p4) => place_stem_f(&**y_p4),
        crate::lower::model::Ex::XPart(y_p5, k_p6) => crate::prelude::Text::from(format!("{}_{}", &place_stem_f(&**y_p5), k_p6)),
        _ => crate::prelude::Text::lit("place"),
    }
}

/// ```prism
/// OnSelf: fn Ex -> Bool
/// ```
pub fn on_self_f(x_p0: &crate::lower::model::Ex) -> bool {
    'm21492: {
        if let crate::lower::model::Ex::XField(m21492_0_0, _) = x_p0 && let crate::lower::model::Ex::XSelf = &**m21492_0_0 {
            break 'm21492 true;
        }
        if let crate::lower::model::Ex::XField(y_p1, _) = x_p0 {
            break 'm21492 on_self_f(&**y_p1);
        }
        if let crate::lower::model::Ex::XFieldOf(y_p2, _, _) = x_p0 {
            break 'm21492 on_self_f(&**y_p2);
        }
        if let crate::lower::model::Ex::XPart(y_p3, _) = x_p0 {
            break 'm21492 on_self_f(&**y_p3);
        }
        if let crate::lower::model::Ex::XMethod(y_p4, _, _) = x_p0 {
            break 'm21492 on_self_f(&**y_p4);
        }
        if let crate::lower::model::Ex::XUpgrade(y_p5) = x_p0 {
            break 'm21492 on_self_f(&**y_p5);
        }
        false
    }
}

/// ```prism
/// ?ThroughParent: fn Ex -> ?Ex
/// ```
pub fn through_parent_o(x_p0: &crate::lower::model::Ex) -> ::std::option::Option<crate::lower::model::Ex> {
    'm21937: {
        if let crate::lower::model::Ex::XField(m21937_0_0, m21937_0_1) = x_p0 && let crate::lower::model::Ex::XSelf = &**m21937_0_0 && (m21937_0_1 == &crate::prelude::Text::lit("parent")) {
            break 'm21937 ::std::option::Option::Some(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("parent")));
        }
        if let crate::lower::model::Ex::XField(y_p1, f_p2) = x_p0 {
            break 'm21937 match through_parent_o(&**y_p1) {
                ::std::option::Option::Some(z_p3) => ::std::option::Option::Some(crate::lower::model::Ex::XField(::std::rc::Rc::new(z_p3), f_p2.clone())),
                ::std::option::Option::None => ::std::option::Option::None,
            };
        }
        if let crate::lower::model::Ex::XFieldOf(y_p4, o_p5, f_p6) = x_p0 {
            break 'm21937 match through_parent_o(&**y_p4) {
                ::std::option::Option::Some(z_p7) => ::std::option::Option::Some(crate::lower::model::Ex::XFieldOf(::std::rc::Rc::new(z_p7), o_p5.clone(), f_p6.clone())),
                ::std::option::Option::None => ::std::option::Option::None,
            };
        }
        if let crate::lower::model::Ex::XPart(y_p8, k_p9) = x_p0 {
            break 'm21937 match through_parent_o(&**y_p8) {
                ::std::option::Option::Some(z_pa) => ::std::option::Option::Some(crate::lower::model::Ex::XPart(::std::rc::Rc::new(z_pa), k_p9.clone())),
                ::std::option::Option::None => ::std::option::Option::None,
            };
        }
        if let crate::lower::model::Ex::XMethod(y_pb, m_pc, xs_pd) = x_p0 {
            break 'm21937 match through_parent_o(&**y_pb) {
                ::std::option::Option::Some(z_pe) => ::std::option::Option::Some(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(z_pe), m_pc.clone(), xs_pd.clone())),
                ::std::option::Option::None => ::std::option::Option::None,
            };
        }
        if let crate::lower::model::Ex::XUpgrade(y_pf) = x_p0 {
            break 'm21937 match through_parent_o(&**y_pf) {
                ::std::option::Option::Some(z_pg) => ::std::option::Option::Some(crate::lower::model::Ex::XUpgrade(::std::rc::Rc::new(z_pg))),
                ::std::option::Option::None => ::std::option::Option::None,
            };
        }
        ::std::option::Option::None
    }
}

/// ```prism
/// Own: fn Vl -> Ex
/// ```
pub fn own_f(vl0: &Vl) -> crate::lower::model::Ex {
    match vl0 {
        Vl::VlPlace(x_p0, Holding::RcRef, _) => crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XDeref(::std::rc::Rc::new(crate::lower::model::Ex::XDeref(::std::rc::Rc::new(x_p0.clone())))))),
        Vl::VlPlace(x_p1, Holding::RcOwned, _) => crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XDeref(::std::rc::Rc::new(x_p1.clone())))),
        Vl::VlPlace(x_p2, mode_p3, t_p4) => if is_copy_f(t_p4) {
            copy_f(&Vl::VlPlace(x_p2.clone(), mode_p3.clone(), t_p4.clone()))
        } else {
            crate::lower::model::Ex::XClone(::std::rc::Rc::new(x_p2.clone()))
        },
        Vl::VlOwned(e_p5, _) => e_p5.clone(),
    }
}

/// ```prism
/// Ref: fn Vl -> Ex
/// ```
pub fn ref_f(vl0: &Vl) -> crate::lower::model::Ex {
    match vl0 {
        Vl::VlPlace(x_p0, Holding::ByRef, _) => x_p0.clone(),
        Vl::VlPlace(x_p1, Holding::RcRef, _) => crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XDeref(::std::rc::Rc::new(crate::lower::model::Ex::XDeref(::std::rc::Rc::new(x_p1.clone())))))),
        Vl::VlPlace(x_p2, Holding::RcOwned, _) => crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XDeref(::std::rc::Rc::new(x_p2.clone())))),
        Vl::VlPlace(x_p3, _, _) => crate::lower::model::Ex::XRef(::std::rc::Rc::new(x_p3.clone())),
        Vl::VlOwned(e_p4, _) => crate::lower::model::Ex::XRef(::std::rc::Rc::new(e_p4.clone())),
    }
}

/// ```prism
/// Copy: fn Vl -> Ex
/// ```
pub fn copy_f(vl0: &Vl) -> crate::lower::model::Ex {
    match vl0 {
        Vl::VlPlace(x_p0, Holding::ByRef, _) => crate::lower::model::Ex::XDeref(::std::rc::Rc::new(x_p0.clone())),
        Vl::VlPlace(x_p1, Holding::RcRef, _) => crate::lower::model::Ex::XDeref(::std::rc::Rc::new(crate::lower::model::Ex::XDeref(::std::rc::Rc::new(crate::lower::model::Ex::XDeref(::std::rc::Rc::new(x_p1.clone())))))),
        Vl::VlPlace(x_p2, _, _) => x_p2.clone(),
        Vl::VlOwned(e_p3, _) => e_p3.clone(),
    }
}

/// ```prism
/// IsCopy: fn OutTy -> Bool
/// ```
pub fn is_copy_f(t_p0: &crate::lower::model::OutTy) -> bool {
    ((((t_p0 == &crate::lower::model::OutTy::OutBool) || (t_p0 == &crate::lower::model::OutTy::OutFloat)) || (t_p0 == &crate::lower::model::OutTy::OutU8)) || (t_p0 == &crate::lower::model::OutTy::OutChar)) || (t_p0 == &crate::lower::model::OutTy::OutUnit)
}

/// ```prism
/// AsBool: fn Vl -> Ex
/// ```
pub fn as_bool_f(v_p0: &Vl) -> crate::lower::model::Ex {
    copy_f(v_p0)
}

/// ```prism
/// AssocOut: unbounded fn Lx, Text, Text, Ty -> OutTy
/// ```
pub fn assoc_out_f(lx_p0: &crate::lower::Lx, tr_p1: &crate::prelude::Text, n_p2: &crate::prelude::Text, a_p3: &crate::check::types::Ty) -> crate::lower::model::OutTy {
    match impl_assoc_o(&lx_p0.g_p, tr_p1, n_p2, a_p3) {
        ::std::option::Option::Some(t_p4) => out_ty_of_f(lx_p0, &t_p4),
        ::std::option::Option::None => match crate::prelude::get(&lx_p0.g_p.traits_p, tr_p1) {
            ::std::option::Option::Some(info_p5) => crate::lower::model::OutTy::OutAssoc(crate::lower::path_in_f(lx_p0, &info_p5.home_p, &crate::lower::trait_name_f(&info_p5.name_p)), crate::lower::camel_f(n_p2), ::std::rc::Rc::new(out_ty_of_f(lx_p0, a_p3))),
            ::std::option::Option::None => crate::lower::expr::internal_bug_type_f(&crate::prelude::Text::from(format!("an associated type `{}` of `{}`, which no trait of the program declares", n_p2, tr_p1))),
        },
    }
}

/// The step machine of `AssocOut`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// AssocOut: unbounded fn Lx, Text, Text, Ty -> OutTy
/// ```
pub struct AssocOut {
    pub lx_p0: crate::lower::Lx,
    pub tr_p1: crate::prelude::Text,
    pub n_p2: crate::prelude::Text,
    pub a_p3: crate::check::types::Ty,
}

impl ::prism_rtl::Job<crate::lower::model::OutTy> for AssocOut {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::lower::model::OutTy> {
        let lx_p0 = &self.lx_p0;
        let tr_p1 = &self.tr_p1;
        let n_p2 = &self.n_p2;
        let a_p3 = &self.a_p3;
        let a_p3x = a_p3.clone();
        let lx_p0x = lx_p0.clone();
        let n_p2x = n_p2.clone();
        let tr_p1x = tr_p1.clone();
        crate::prelude::call_then(start_impl_assoc_o(lx_p0x.g_p.clone(), tr_p1x.clone(), n_p2x.clone(), a_p3x.clone()), move |impl_assoc_o_23867: ::std::option::Option<crate::check::types::Ty>| match impl_assoc_o_23867 {
            ::std::option::Option::Some(t_p4) => ::prism_rtl::Turn::More(::std::rc::Rc::new(OutTyOf { lx_p0: lx_p0x.clone(), t_p1: t_p4.clone() })),
            ::std::option::Option::None => match crate::prelude::get(&lx_p0x.g_p.traits_p, &tr_p1x) {
                ::std::option::Option::Some(info_p5) => crate::prelude::call_then(start_out_ty_of_f(lx_p0x.clone(), a_p3x.clone()), move |out_ty_of_f_24033: crate::lower::model::OutTy| ::prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutAssoc(crate::lower::path_in_f(&lx_p0x, &info_p5.home_p, &crate::lower::trait_name_f(&info_p5.name_p)), crate::lower::camel_f(&n_p2x), ::std::rc::Rc::new(out_ty_of_f_24033)))),
                ::std::option::Option::None => ::prism_rtl::Turn::Finished(crate::lower::expr::internal_bug_type_f(&crate::prelude::Text::from(format!("an associated type `{}` of `{}`, which no trait of the program declares", &n_p2x, &tr_p1x)))),
            },
        })
    }
}

/// `Start AssocOut, x`: what the function value is when passed to `@Run`.
pub fn start_assoc_out_f(lx_p0: crate::lower::Lx, tr_p1: crate::prelude::Text, n_p2: crate::prelude::Text, a_p3: crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::OutTy>> {
    ::std::rc::Rc::new(AssocOut { lx_p0, tr_p1, n_p2, a_p3 })
}

/// ```prism
/// ?ImplAssoc: unbounded fn G, Text, Text, Ty -> ?Ty
/// ```
pub fn impl_assoc_o(g_p0: &crate::check::env::G, tr_p1: &crate::prelude::Text, n_p2: &crate::prelude::Text, a_p3: &crate::check::types::Ty) -> ::std::option::Option<crate::check::types::Ty> {
    match a_p3 {
        crate::check::types::Ty::TyCon(c_p4, args_p5) => crate::prelude::run_to_end(crate::prelude::fold_job(crate::prelude::or(&crate::prelude::get(&g_p0.impls_p, tr_p1), &crate::prelude::Array::new()), ::std::option::Option::None, {
            let n_p2x = n_p2.clone();
            let c_p4x = c_p4.clone();
            let args_p5x = args_p5.clone();
            ::std::rc::Rc::new(move |(p0, p1): (::std::option::Option<crate::check::types::Ty>, crate::check::env::ImplInfo)| {
                let n_p2xy = n_p2x.clone();
                let c_p4xy = c_p4x.clone();
                let args_p5xy = args_p5x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let found_o6 = p0;
                    let im_p7 = p1;
                    match &found_o6 {
                        ::std::option::Option::Some(t_p8) => ::prism_rtl::Turn::Finished(::std::option::Option::Some(t_p8.clone())),
                        ::std::option::Option::None => ::prism_rtl::Turn::More(::std::rc::Rc::new(ImplChoice { im_p0: im_p7.clone(), n_p1: n_p2xy.clone(), c_p2: c_p4xy.clone(), args_p3: args_p5xy.clone() })),
                    }
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((::std::option::Option<crate::check::types::Ty>, crate::check::env::ImplInfo)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<::std::option::Option<crate::check::types::Ty>>>>
        })),
        _ => ::std::option::Option::None,
    }
}

/// The step machine of `ImplAssoc`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?ImplAssoc: unbounded fn G, Text, Text, Ty -> ?Ty
/// ```
pub struct ImplAssoc {
    pub g_p0: crate::check::env::G,
    pub tr_p1: crate::prelude::Text,
    pub n_p2: crate::prelude::Text,
    pub a_p3: crate::check::types::Ty,
}

impl ::prism_rtl::Job<::std::option::Option<crate::check::types::Ty>> for ImplAssoc {
    fn cycle(&self) -> ::prism_rtl::Turn<::std::option::Option<crate::check::types::Ty>> {
        let g_p0 = &self.g_p0;
        let tr_p1 = &self.tr_p1;
        let n_p2 = &self.n_p2;
        let a_p3 = &self.a_p3;
        match a_p3 {
            crate::check::types::Ty::TyCon(c_p4, args_p5) => crate::prelude::fold_job(crate::prelude::or(&crate::prelude::get(&g_p0.impls_p, tr_p1), &crate::prelude::Array::new()), ::std::option::Option::None, {
                let n_p2x = n_p2.clone();
                let c_p4x = c_p4.clone();
                let args_p5x = args_p5.clone();
                ::std::rc::Rc::new(move |(p0, p1): (::std::option::Option<crate::check::types::Ty>, crate::check::env::ImplInfo)| {
                    let n_p2xy = n_p2x.clone();
                    let c_p4xy = c_p4x.clone();
                    let args_p5xy = args_p5x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let found_o6 = p0;
                        let im_p7 = p1;
                        match &found_o6 {
                            ::std::option::Option::Some(t_p8) => ::prism_rtl::Turn::Finished(::std::option::Option::Some(t_p8.clone())),
                            ::std::option::Option::None => ::prism_rtl::Turn::More(::std::rc::Rc::new(ImplChoice { im_p0: im_p7.clone(), n_p1: n_p2xy.clone(), c_p2: c_p4xy.clone(), args_p3: args_p5xy.clone() })),
                        }
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn((::std::option::Option<crate::check::types::Ty>, crate::check::env::ImplInfo)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<::std::option::Option<crate::check::types::Ty>>>>
            }).cycle(),
            _ => ::prism_rtl::Turn::Finished(::std::option::Option::None),
        }
    }
}

/// `Start ImplAssoc, x`: what the function value is when passed to `@Run`.
pub fn start_impl_assoc_o(g_p0: crate::check::env::G, tr_p1: crate::prelude::Text, n_p2: crate::prelude::Text, a_p3: crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<::std::option::Option<crate::check::types::Ty>>> {
    ::std::rc::Rc::new(ImplAssoc { g_p0, tr_p1, n_p2, a_p3 })
}

/// ```prism
/// ?ImplChoice: unbounded fn ImplInfo, Text, Text, [Ty] -> ?Ty
/// ```
pub fn impl_choice_o(im_p0: &crate::check::env::ImplInfo, n_p1: &crate::prelude::Text, c_p2: &crate::prelude::Text, args_p3: &crate::prelude::Array<crate::check::types::Ty>) -> ::std::option::Option<crate::check::types::Ty> {
    match &im_p0.head_p {
        crate::check::types::Ty::TyCon(hc_p4, hargs_p5) if ((hc_p4 == c_p2) && (&crate::prelude::len(hargs_p5) == &crate::prelude::len(args_p3))) => {
            let params_p6 = crate::prelude::each(hargs_p5, &(|h_p7: &crate::check::types::Ty| match h_p7 {
                crate::check::types::Ty::TyQ(q_p8) => q_p8.clone(),
                _ => crate::prelude::Text::lit(""),
            }));
            crate::prelude::run_to_end(crate::prelude::fold_job(im_p0.assocs_p.clone(), ::std::option::Option::None, {
                let n_p1x = n_p1.clone();
                let params_p6x = params_p6.clone();
                let args_p3x = args_p3.clone();
                ::std::rc::Rc::new(move |(p0, p1): (::std::option::Option<crate::check::types::Ty>, (crate::prelude::Text, crate::check::types::Ty))| {
                    let n_p1xy = n_p1x.clone();
                    let params_p6xy = params_p6x.clone();
                    let args_p3xy = args_p3x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let f2_o9 = p0;
                        let (an_pa, at_pb) = p1;
                        if (&an_pa == &n_p1xy) && (&f2_o9 == &::std::option::Option::None) {
                            ::prism_rtl::Turn::Finished(::std::option::Option::Some(crate::lower::expr::instantiated_f(&at_pb, &params_p6xy, &args_p3xy)))
                        } else {
                            ::prism_rtl::Turn::Finished(f2_o9.clone())
                        }
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn((::std::option::Option<crate::check::types::Ty>, (crate::prelude::Text, crate::check::types::Ty))) -> ::std::rc::Rc<dyn ::prism_rtl::Job<::std::option::Option<crate::check::types::Ty>>>>
            }))
        },
        _ => ::std::option::Option::None,
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `ImplChoice`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?ImplChoice: unbounded fn ImplInfo, Text, Text, [Ty] -> ?Ty
/// ```
pub struct ImplChoice {
    pub im_p0: crate::check::env::ImplInfo,
    pub n_p1: crate::prelude::Text,
    pub c_p2: crate::prelude::Text,
    pub args_p3: crate::prelude::Array<crate::check::types::Ty>,
}

impl ::prism_rtl::Job<::std::option::Option<crate::check::types::Ty>> for ImplChoice {
    fn cycle(&self) -> ::prism_rtl::Turn<::std::option::Option<crate::check::types::Ty>> {
        let im_p0 = &self.im_p0;
        let n_p1 = &self.n_p1;
        let c_p2 = &self.c_p2;
        let args_p3 = &self.args_p3;
        match &im_p0.head_p {
            crate::check::types::Ty::TyCon(hc_p4, hargs_p5) if ((hc_p4 == c_p2) && (&crate::prelude::len(hargs_p5) == &crate::prelude::len(args_p3))) => {
                let params_p6 = crate::prelude::each(hargs_p5, &(|h_p7: &crate::check::types::Ty| match h_p7 {
                    crate::check::types::Ty::TyQ(q_p8) => q_p8.clone(),
                    _ => crate::prelude::Text::lit(""),
                }));
                crate::prelude::fold_job(im_p0.assocs_p.clone(), ::std::option::Option::None, {
                    let n_p1x = n_p1.clone();
                    let params_p6x = params_p6.clone();
                    let args_p3x = args_p3.clone();
                    ::std::rc::Rc::new(move |(p0, p1): (::std::option::Option<crate::check::types::Ty>, (crate::prelude::Text, crate::check::types::Ty))| {
                        let n_p1xy = n_p1x.clone();
                        let params_p6xy = params_p6x.clone();
                        let args_p3xy = args_p3x.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let f2_o9 = p0;
                            let (an_pa, at_pb) = p1;
                            if (&an_pa == &n_p1xy) && (&f2_o9 == &::std::option::Option::None) {
                                ::prism_rtl::Turn::Finished(::std::option::Option::Some(crate::lower::expr::instantiated_f(&at_pb, &params_p6xy, &args_p3xy)))
                            } else {
                                ::prism_rtl::Turn::Finished(f2_o9.clone())
                            }
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn((::std::option::Option<crate::check::types::Ty>, (crate::prelude::Text, crate::check::types::Ty))) -> ::std::rc::Rc<dyn ::prism_rtl::Job<::std::option::Option<crate::check::types::Ty>>>>
                }).cycle()
            },
            _ => ::prism_rtl::Turn::Finished(::std::option::Option::None),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start ImplChoice, x`: what the function value is when passed to `@Run`.
pub fn start_impl_choice_o(im_p0: crate::check::env::ImplInfo, n_p1: crate::prelude::Text, c_p2: crate::prelude::Text, args_p3: crate::prelude::Array<crate::check::types::Ty>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<::std::option::Option<crate::check::types::Ty>>> {
    ::std::rc::Rc::new(ImplChoice { im_p0, n_p1, c_p2, args_p3 })
}
