//! The module `Lower.Jobs`, from `target/bootstrap/src/prismc/lower/jobs.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// ```prism
/// Tail: unbounded fn Lx, Env, Expr -> Ex
/// ```
pub fn tail(lx: &crate::lower::Lx, env: &crate::lower::types::Env, e: &crate::syntax::Expr) -> crate::lower::model::Ex {
    match frame_call(lx, env, e, &true) {
        Some(c) => frame(lx, env, &c, &rest_text(lx, &e.span, &c.span, &e.span), &{
            let lx = lx.clone();
            let e = e.clone();
            Rc::new(move |p0: crate::lower::types::Env| {
                let lx = lx.clone();
                let e = e.clone();
                entered(once_job(move || {
                    let env2 = p0;
                    prism_rtl::Turn::More(Rc::new(Tail { lx: lx.clone(), env: env2.clone(), e: e.clone() }))
                }))
            }) as Rc<dyn Fn(crate::lower::types::Env) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
        }),
        None => tail_here(lx, env, e),
    }
}

/// The step machine of `Tail`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Tail: unbounded fn Lx, Env, Expr -> Ex
/// ```
pub struct Tail {
    pub lx: crate::lower::Lx,
    pub env: crate::lower::types::Env,
    pub e: crate::syntax::Expr,
}

impl prism_rtl::Job<crate::lower::model::Ex> for Tail {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::Ex> {
        let lx = &self.lx;
        let env = &self.env;
        let e = &self.e;
        let e = e.clone();
        let env = env.clone();
        let lx = lx.clone();
        call_then(start_frame_call(lx.clone(), env.clone(), e.clone(), true), move |frame_call_1854: Option<crate::syntax::Expr>| match frame_call_1854 {
            Some(c) => prism_rtl::Turn::More(Rc::new(Frame { lx: lx.clone(), env: env.clone(), call: c.clone(), rest_text_: rest_text(&lx, &e.span, &c.span, &e.span), cont_fn: {
                let lx = lx.clone();
                let e = e.clone();
                Rc::new(move |p0: crate::lower::types::Env| {
                    let lx = lx.clone();
                    let e = e.clone();
                    entered(once_job(move || {
                        let env2 = p0;
                        prism_rtl::Turn::More(Rc::new(Tail { lx: lx.clone(), env: env2.clone(), e: e.clone() }))
                    }))
                }) as Rc<dyn Fn(crate::lower::types::Env) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
            } })),
            None => prism_rtl::Turn::More(Rc::new(TailHere { lx: lx.clone(), env: env.clone(), e: e.clone() })),
        })
    }
}

/// `Start Tail, x`: what the function value is when passed to `@Run`.
pub fn start_tail(lx: crate::lower::Lx, env: crate::lower::types::Env, e: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>> {
    Rc::new(Tail { lx, env, e })
}

/// ```prism
/// TailHere: unbounded fn Lx, Env, Expr -> Ex
/// ```
pub fn tail_here(lx: &crate::lower::Lx, env: &crate::lower::types::Env, e: &crate::syntax::Expr) -> crate::lower::model::Ex {
    'm2072: {
        let scrutinee = &*e.kind;
        if let crate::syntax::ExprKind::EGroup(x) = scrutinee {
            break 'm2072 tail(lx, env, &**x);
        }
        if let crate::syntax::ExprKind::EUpdate(target, b) = scrutinee {
            break 'm2072 if has_top_while(lx, b) {
                upd_tail(lx, env, &**target, b, &e.span, &(Rc::new(move |(p0, p1): (crate::lower::types::Env, crate::lower::model::Ex)| once_job(move || {
                    let en = p0;
                    let v_ = p1;
                    prism_rtl::Turn::Finished(crate::lower::model::Ex::XCtor(Text::lit("prism_rtl::Turn::Finished"), Array::from(vec![v_.clone()])))
                })) as Rc<dyn Fn((crate::lower::types::Env, crate::lower::model::Ex)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>))
            } else {
                crate::lower::model::Ex::XCtor(Text::lit("prism_rtl::Turn::Finished"), Array::from(vec![crate::lower::types::own(&crate::lower::expr::value_of(lx, env, e))]))
            };
        }
        if let crate::syntax::ExprKind::EMatch(s, arms) = scrutinee {
            break 'm2072 tail_match(lx, env, &**s, arms, &e.span);
        }
        if let crate::syntax::ExprKind::EIf(m2072_3_0, then_b, Some(else_b)) = scrutinee && let crate::syntax::Cond::CondExpr(c) = &**m2072_3_0 {
            break 'm2072 crate::lower::model::Ex::XIf(Rc::new(crate::lower::types::as_bool(&crate::lower::expr::value_of(lx, env, &**c))), Rc::new(tail_block(lx, env, then_b)), Rc::new(tail_block(lx, env, else_b)));
        }
        if let crate::syntax::ExprKind::ECall(callee, args, _, _) = scrutinee {
            break 'm2072 match tail_callee(lx, env, &**callee) {
                Some(qk) => {
                    let job = or(&get(&lx.rs_names, &qk), &crate::lower::snake(&crate::check::types::bare_name(&qk)));
                    let job_name = crate::lower::path_in(lx, &crate::lower::owner_of(&qk), &crate::lower::camel(&crate::check::types::bare_name(&qk)));
                    let (ptys, _) = scheme_parts(lx, &qk);
                    let fields = job_field_names(lx, &qk);
                    let vals = crate::lower::expr::named_args_owned(lx, env, &qk, args);
                    if crate::lower::program::enters_at_once(lx, &qk, args) {
                        crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCall(crate::lower::path_in(lx, &crate::lower::owner_of(&qk), &Text::from(format!("start_{}", &job))), vals.clone())), Text::lit("cycle"), Array::new())
                    } else {
                        if crate::lower::program::is_color_poly(lx, &qk) {
                            crate::lower::model::Ex::XCtor(Text::lit("prism_rtl::Turn::More"), Array::from(vec![crate::lower::model::Ex::XCall(crate::lower::path_in(lx, &crate::lower::owner_of(&qk), &Text::from(format!("start_{}", &job))), vals.clone())]))
                        } else {
                            crate::lower::model::Ex::XCtor(Text::lit("prism_rtl::Turn::More"), Array::from(vec![crate::lower::model::Ex::XCall(Text::lit("Rc::new"), Array::from(vec![crate::lower::model::Ex::XRecord(job_name.clone(), each(&crate::check::errors::range0(&len(&vals)), &(|i: &Nat| (or(&index(&fields, i), &Text::lit("arg")), or(&index(&vals, i), &crate::lower::model::Ex::XUnit)))))]))]))
                        }
                    }
                },
                None => match local_job_fn(lx, env, &**callee) {
                    Some(f) => crate::lower::model::Ex::XMethod(Rc::new(start_call(&f, &crate::lower::expr::start_args(lx, env, &f, args))), Text::lit("cycle"), Array::new()),
                    None => match crate::lower::expr::prelude_job_call(lx, env, e) {
                        Some(job) => crate::lower::model::Ex::XMethod(Rc::new(job.clone()), Text::lit("cycle"), Array::new()),
                        None => crate::lower::model::Ex::XCtor(Text::lit("prism_rtl::Turn::Finished"), Array::from(vec![crate::lower::types::own(&crate::lower::expr::value_of(lx, env, e))])),
                    },
                },
            };
        }
        crate::lower::model::Ex::XCtor(Text::lit("prism_rtl::Turn::Finished"), Array::from(vec![crate::lower::types::own(&crate::lower::expr::value_of(lx, env, e))]))
    }
}

/// The step machine of `TailHere`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TailHere: unbounded fn Lx, Env, Expr -> Ex
/// ```
pub struct TailHere {
    pub lx: crate::lower::Lx,
    pub env: crate::lower::types::Env,
    pub e: crate::syntax::Expr,
}

impl prism_rtl::Job<crate::lower::model::Ex> for TailHere {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::Ex> {
        let lx = &self.lx;
        let env = &self.env;
        let e = &self.e;
        'm2072: {
            let scrutinee = &*e.kind;
            if let crate::syntax::ExprKind::EGroup(x) = scrutinee {
                break 'm2072 prism_rtl::Turn::More(Rc::new(Tail { lx: lx.clone(), env: env.clone(), e: (**x).clone() }));
            }
            if let crate::syntax::ExprKind::EUpdate(target, b) = scrutinee {
                break 'm2072 if has_top_while(lx, b) {
                    prism_rtl::Turn::More(Rc::new(UpdTail { lx: lx.clone(), env: env.clone(), target: (**target).clone(), b: b.clone(), to: e.span.clone(), cont_fn: Rc::new(move |(p0, p1): (crate::lower::types::Env, crate::lower::model::Ex)| once_job(move || {
                        let en = p0;
                        let v_ = p1;
                        prism_rtl::Turn::Finished(crate::lower::model::Ex::XCtor(Text::lit("prism_rtl::Turn::Finished"), Array::from(vec![v_.clone()])))
                    })) as Rc<dyn Fn((crate::lower::types::Env, crate::lower::model::Ex)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>> }))
                } else {
                    {
                        let e = e.clone();
                        let env = env.clone();
                        let lx = lx.clone();
                        call_then(crate::lower::expr::start_value_of(lx.clone(), env.clone(), e.clone()), move |value_of_2311: crate::lower::types::Vl| prism_rtl::Turn::Finished(crate::lower::model::Ex::XCtor(Text::lit("prism_rtl::Turn::Finished"), Array::from(vec![crate::lower::types::own(&value_of_2311)]))))
                    }
                };
            }
            if let crate::syntax::ExprKind::EMatch(s, arms) = scrutinee {
                break 'm2072 prism_rtl::Turn::More(Rc::new(TailMatch { lx: lx.clone(), env: env.clone(), s: (**s).clone(), arms: arms.clone(), span: e.span.clone() }));
            }
            if let crate::syntax::ExprKind::EIf(m2072_3_0, then_b, Some(else_b)) = scrutinee && let crate::syntax::Cond::CondExpr(c) = &**m2072_3_0 {
                break 'm2072 {
                    let c = (**c).clone();
                    let else_b = else_b.clone();
                    let env = env.clone();
                    let lx = lx.clone();
                    let then_b = then_b.clone();
                    call_then(crate::lower::expr::start_value_of(lx.clone(), env.clone(), c.clone()), move |value_of_2441: crate::lower::types::Vl| call_then(start_tail_block(lx.clone(), env.clone(), then_b.clone()), move |tail_block_2464: crate::lower::model::Ex| call_then(start_tail_block(lx.clone(), env.clone(), else_b.clone()), move |tail_block_2492: crate::lower::model::Ex| prism_rtl::Turn::Finished(crate::lower::model::Ex::XIf(Rc::new(crate::lower::types::as_bool(&value_of_2441)), Rc::new(tail_block_2464), Rc::new(tail_block_2492))))))
                };
            }
            if let crate::syntax::ExprKind::ECall(callee, args, _, _) = scrutinee {
                break 'm2072 match tail_callee(lx, env, &**callee) {
                    Some(qk) => {
                        let job = or(&get(&lx.rs_names, &qk), &crate::lower::snake(&crate::check::types::bare_name(&qk)));
                        let job_name = crate::lower::path_in(lx, &crate::lower::owner_of(&qk), &crate::lower::camel(&crate::check::types::bare_name(&qk)));
                        let (ptys, _) = scheme_parts(lx, &qk);
                        let args = args.clone();
                        let env = env.clone();
                        let lx = lx.clone();
                        call_then(start_job_field_names(lx.clone(), qk.clone()), move |job_field_names_2822: Array<Text>| {
                            let fields = job_field_names_2822;
                            call_then(crate::lower::expr::start_named_args_owned(lx.clone(), env.clone(), qk.clone(), args.clone()), move |named_args_owned_2866: Array<crate::lower::model::Ex>| {
                                let vals = named_args_owned_2866;
                                if crate::lower::program::enters_at_once(&lx, &qk, &args) {
                                    prism_rtl::Turn::Finished(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCall(crate::lower::path_in(&lx, &crate::lower::owner_of(&qk), &Text::from(format!("start_{}", &job))), vals.clone())), Text::lit("cycle"), Array::new()))
                                } else {
                                    if crate::lower::program::is_color_poly(&lx, &qk) {
                                        prism_rtl::Turn::Finished(crate::lower::model::Ex::XCtor(Text::lit("prism_rtl::Turn::More"), Array::from(vec![crate::lower::model::Ex::XCall(crate::lower::path_in(&lx, &crate::lower::owner_of(&qk), &Text::from(format!("start_{}", &job))), vals.clone())])))
                                    } else {
                                        prism_rtl::Turn::Finished(crate::lower::model::Ex::XCtor(Text::lit("prism_rtl::Turn::More"), Array::from(vec![crate::lower::model::Ex::XCall(Text::lit("Rc::new"), Array::from(vec![crate::lower::model::Ex::XRecord(job_name.clone(), each(&crate::check::errors::range0(&len(&vals)), &(|i: &Nat| (or(&index(&fields, i), &Text::lit("arg")), or(&index(&vals, i), &crate::lower::model::Ex::XUnit)))))]))])))
                                    }
                                }
                            })
                        })
                    },
                    None => {
                        let args = args.clone();
                        let callee = (**callee).clone();
                        let e = e.clone();
                        let env = env.clone();
                        let lx = lx.clone();
                        call_then(start_local_job_fn(lx.clone(), env.clone(), callee.clone()), move |local_job_fn_3346: Option<crate::lower::types::Vl>| match local_job_fn_3346 {
                            Some(f) => call_then(crate::lower::expr::start_start_args(lx.clone(), env.clone(), f.clone(), args.clone()), move |start_args_3415: Array<crate::lower::model::Ex>| prism_rtl::Turn::Finished(crate::lower::model::Ex::XMethod(Rc::new(start_call(&f, &start_args_3415)), Text::lit("cycle"), Array::new()))),
                            None => call_then(crate::lower::expr::start_prelude_job_call(lx.clone(), env.clone(), e.clone()), move |prelude_job_call_3482: Option<crate::lower::model::Ex>| match prelude_job_call_3482 {
                                Some(job) => prism_rtl::Turn::Finished(crate::lower::model::Ex::XMethod(Rc::new(job.clone()), Text::lit("cycle"), Array::new())),
                                None => call_then(crate::lower::expr::start_value_of(lx.clone(), env.clone(), e.clone()), move |value_of_3623: crate::lower::types::Vl| prism_rtl::Turn::Finished(crate::lower::model::Ex::XCtor(Text::lit("prism_rtl::Turn::Finished"), Array::from(vec![crate::lower::types::own(&value_of_3623)])))),
                            }),
                        })
                    },
                };
            }
            {
                let e = e.clone();
                let env = env.clone();
                let lx = lx.clone();
                call_then(crate::lower::expr::start_value_of(lx.clone(), env.clone(), e.clone()), move |value_of_3702: crate::lower::types::Vl| prism_rtl::Turn::Finished(crate::lower::model::Ex::XCtor(Text::lit("prism_rtl::Turn::Finished"), Array::from(vec![crate::lower::types::own(&value_of_3702)]))))
            }
        }
    }
}

/// `Start TailHere, x`: what the function value is when passed to `@Run`.
pub fn start_tail_here(lx: crate::lower::Lx, env: crate::lower::types::Env, e: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>> {
    Rc::new(TailHere { lx, env, e })
}

/// ```prism
/// TailBlock: unbounded fn Lx, Env, Block -> Ex
/// ```
pub fn tail_block(lx: &crate::lower::Lx, env: &crate::lower::types::Env, b: &crate::syntax::Block) -> crate::lower::model::Ex {
    tail_from(lx, env, b, &Nat::from(0u32))
}

/// The step machine of `TailBlock`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TailBlock: unbounded fn Lx, Env, Block -> Ex
/// ```
pub struct TailBlock {
    pub lx: crate::lower::Lx,
    pub env: crate::lower::types::Env,
    pub b: crate::syntax::Block,
}

impl prism_rtl::Job<crate::lower::model::Ex> for TailBlock {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::Ex> {
        let lx = &self.lx;
        let env = &self.env;
        let b = &self.b;
        prism_rtl::Turn::More(Rc::new(TailFrom { lx: lx.clone(), env: env.clone(), b: b.clone(), i: Nat::from(0u32) }))
    }
}

/// `Start TailBlock, x`: what the function value is when passed to `@Run`.
pub fn start_tail_block(lx: crate::lower::Lx, env: crate::lower::types::Env, b: crate::syntax::Block) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>> {
    Rc::new(TailBlock { lx, env, b })
}

/// ```prism
/// TailFrom: unbounded fn Lx, Env, Block, Nat -> Ex
/// ```
pub fn tail_from(lx: &crate::lower::Lx, env: &crate::lower::types::Env, b: &crate::syntax::Block, i: &Nat) -> crate::lower::model::Ex {
    let s = or(&index(&b.stmts, i), &crate::lower::expr::dummy_stmt_l());
    if &(i + &Nat::from(1u32)) >= &len(&b.stmts) {
        match &s.kind {
            crate::syntax::StmtKind::SExpr(x) => tail(lx, env, x),
            _ => crate::lower::model::Ex::XCtor(Text::lit("prism_rtl::Turn::Finished"), Array::from(vec![crate::lower::model::Ex::XUnit])),
        }
    } else {
        {
            let found_opt = match &s.kind {
                crate::syntax::StmtKind::SLet(_, _, x) => frame_call(lx, env, x, &false),
                crate::syntax::StmtKind::SExpr(x) => frame_call(lx, env, x, &false),
                _ => None,
            };
            let looping_opt = match &s.kind {
                crate::syntax::StmtKind::SLet(p_, _, x) => match &*x.kind {
                    crate::syntax::ExprKind::EUpdate(target, ub) => if has_top_while(lx, ub) {
                        Some((p_.clone(), (**target).clone(), ub.clone(), x.clone()))
                    } else {
                        None
                    },
                    _ => None,
                },
                _ => None,
            };
            match &looping_opt {
                Some((p_, target, ub, x)) => upd_tail(lx, env, target, ub, &b.span, &{
                    let lx = lx.clone();
                    let p_ = p_.clone();
                    let x = x.clone();
                    let s = s.clone();
                    let b = b.clone();
                    let i = i.clone();
                    Rc::new(move |(p0, p1): (crate::lower::types::Env, crate::lower::model::Ex)| {
                        let lx = lx.clone();
                        let p_ = p_.clone();
                        let x = x.clone();
                        let s = s.clone();
                        let b = b.clone();
                        let i = i.clone();
                        entered(once_job(move || {
                            let en = p0;
                            let v_ = p1;
                            call_then(crate::lower::patterns::start_rust_pat(lx.clone(), p_.clone(), crate::lower::type_at(&lx, &x.span), crate::lower::types::Holding::Owned, Text::from(format!("l{}", &s.span.start))), move |rust_pat_4825: crate::lower::patterns::PatOut| {
                                let po = rust_pat_4825;
                                call_then(start_tail_from(lx.clone(), crate::lower::expr::bind_all(&en, &po.binds), b.clone(), &i + &Nat::from(1u32)), move |tail_from_4917: crate::lower::model::Ex| {
                                    let rest = tail_from_4917;
                                    prism_rtl::Turn::Finished(prepend(&Array::from(vec![crate::lower::model::Do::DoLet(po.pa.clone(), v_.clone())]), &rest))
                                })
                            })
                        }))
                    }) as Rc<dyn Fn((crate::lower::types::Env, crate::lower::model::Ex)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
                }),
                None => match &found_opt {
                    Some(c) => frame(lx, env, c, &rest_text(lx, &s.span, &c.span, &b.span), &{
                        let lx = lx.clone();
                        let b = b.clone();
                        let i = i.clone();
                        Rc::new(move |p0: crate::lower::types::Env| {
                            let lx = lx.clone();
                            let b = b.clone();
                            let i = i.clone();
                            entered(once_job(move || {
                                let env2 = p0;
                                prism_rtl::Turn::More(Rc::new(TailFrom { lx: lx.clone(), env: env2.clone(), b: b.clone(), i: i.clone() }))
                            }))
                        }) as Rc<dyn Fn(crate::lower::types::Env) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
                    }),
                    None => {
                        let (dos, env2) = crate::lower::expr::block_stmt(lx, env, &s);
                        match tail_from(lx, &env2, b, &(i + &Nat::from(1u32))) {
                            crate::lower::model::Ex::XBlock(more, last) => crate::lower::model::Ex::XBlock(append(&dos, &more), Rc::new((*last).clone())),
                            last => if &len(&dos) == &Nat::from(0u32) {
                                last.clone()
                            } else {
                                crate::lower::model::Ex::XBlock(dos.clone(), Rc::new(last.clone()))
                            },
                        }
                    },
                },
            }
        }
    }
}

/// The step machine of `TailFrom`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TailFrom: unbounded fn Lx, Env, Block, Nat -> Ex
/// ```
pub struct TailFrom {
    pub lx: crate::lower::Lx,
    pub env: crate::lower::types::Env,
    pub b: crate::syntax::Block,
    pub i: Nat,
}

impl prism_rtl::Job<crate::lower::model::Ex> for TailFrom {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::Ex> {
        let lx = &self.lx;
        let env = &self.env;
        let b = &self.b;
        let i = &self.i;
        let s = or(&index(&b.stmts, i), &crate::lower::expr::dummy_stmt_l());
        if &(i + &Nat::from(1u32)) >= &len(&b.stmts) {
            match &s.kind {
                crate::syntax::StmtKind::SExpr(x) => prism_rtl::Turn::More(Rc::new(Tail { lx: lx.clone(), env: env.clone(), e: x.clone() })),
                _ => prism_rtl::Turn::Finished(crate::lower::model::Ex::XCtor(Text::lit("prism_rtl::Turn::Finished"), Array::from(vec![crate::lower::model::Ex::XUnit]))),
            }
        } else {
            {
                let found_opt = match &s.kind {
                    crate::syntax::StmtKind::SLet(_, _, x) => frame_call(lx, env, x, &false),
                    crate::syntax::StmtKind::SExpr(x) => frame_call(lx, env, x, &false),
                    _ => None,
                };
                let looping_opt = match &s.kind {
                    crate::syntax::StmtKind::SLet(p_, _, x) => match &*x.kind {
                        crate::syntax::ExprKind::EUpdate(target, ub) => if has_top_while(lx, ub) {
                            Some((p_.clone(), (**target).clone(), ub.clone(), x.clone()))
                        } else {
                            None
                        },
                        _ => None,
                    },
                    _ => None,
                };
                match &looping_opt {
                    Some((p_, target, ub, x)) => prism_rtl::Turn::More(Rc::new(UpdTail { lx: lx.clone(), env: env.clone(), target: target.clone(), b: ub.clone(), to: b.span.clone(), cont_fn: {
                        let lx = lx.clone();
                        let p_ = p_.clone();
                        let x = x.clone();
                        let s = s.clone();
                        let b = b.clone();
                        let i = i.clone();
                        Rc::new(move |(p0, p1): (crate::lower::types::Env, crate::lower::model::Ex)| {
                            let lx = lx.clone();
                            let p_ = p_.clone();
                            let x = x.clone();
                            let s = s.clone();
                            let b = b.clone();
                            let i = i.clone();
                            entered(once_job(move || {
                                let en = p0;
                                let v_ = p1;
                                call_then(crate::lower::patterns::start_rust_pat(lx.clone(), p_.clone(), crate::lower::type_at(&lx, &x.span), crate::lower::types::Holding::Owned, Text::from(format!("l{}", &s.span.start))), move |rust_pat_4825: crate::lower::patterns::PatOut| {
                                    let po = rust_pat_4825;
                                    call_then(start_tail_from(lx.clone(), crate::lower::expr::bind_all(&en, &po.binds), b.clone(), &i + &Nat::from(1u32)), move |tail_from_4917: crate::lower::model::Ex| {
                                        let rest = tail_from_4917;
                                        prism_rtl::Turn::Finished(prepend(&Array::from(vec![crate::lower::model::Do::DoLet(po.pa.clone(), v_.clone())]), &rest))
                                    })
                                })
                            }))
                        }) as Rc<dyn Fn((crate::lower::types::Env, crate::lower::model::Ex)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
                    } })),
                    None => match &found_opt {
                        Some(c) => prism_rtl::Turn::More(Rc::new(Frame { lx: lx.clone(), env: env.clone(), call: c.clone(), rest_text_: rest_text(lx, &s.span, &c.span, &b.span), cont_fn: {
                            let lx = lx.clone();
                            let b = b.clone();
                            let i = i.clone();
                            Rc::new(move |p0: crate::lower::types::Env| {
                                let lx = lx.clone();
                                let b = b.clone();
                                let i = i.clone();
                                entered(once_job(move || {
                                    let env2 = p0;
                                    prism_rtl::Turn::More(Rc::new(TailFrom { lx: lx.clone(), env: env2.clone(), b: b.clone(), i: i.clone() }))
                                }))
                            }) as Rc<dyn Fn(crate::lower::types::Env) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
                        } })),
                        None => {
                            let b = b.clone();
                            let env = env.clone();
                            let i = i.clone();
                            let lx = lx.clone();
                            call_then(crate::lower::expr::start_block_stmt(lx.clone(), env.clone(), s.clone()), move |block_stmt_5220: (Array<crate::lower::model::Do>, crate::lower::types::Env)| {
                                let (dos, env2) = block_stmt_5220;
                                call_then(start_tail_from(lx.clone(), env2.clone(), b.clone(), &i + &Nat::from(1u32)), move |tail_from_5267: crate::lower::model::Ex| match tail_from_5267 {
                                    crate::lower::model::Ex::XBlock(more, last) => prism_rtl::Turn::Finished(crate::lower::model::Ex::XBlock(append(&dos, &more), Rc::new((*last).clone()))),
                                    last => if &len(&dos) == &Nat::from(0u32) {
                                        prism_rtl::Turn::Finished(last.clone())
                                    } else {
                                        prism_rtl::Turn::Finished(crate::lower::model::Ex::XBlock(dos.clone(), Rc::new(last.clone())))
                                    },
                                })
                            })
                        },
                    },
                }
            }
        }
    }
}

/// `Start TailFrom, x`: what the function value is when passed to `@Run`.
pub fn start_tail_from(lx: crate::lower::Lx, env: crate::lower::types::Env, b: crate::syntax::Block, i: Nat) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>> {
    Rc::new(TailFrom { lx, env, b, i })
}

/// ```prism
/// HasTopWhile: fn Lx, Block -> Bool
/// ```
pub fn has_top_while(lx: &crate::lower::Lx, b: &crate::syntax::Block) -> bool {
    fold(&b.stmts, &false, &(|f: &bool, st: &crate::syntax::Stmt| (*f || is_cycle_while(lx, st)) || holds_cycle_while(lx, st)))
}

/// ```prism
/// IsCycleWhile: fn Lx, Stmt -> Bool
/// ```
pub fn is_cycle_while(lx: &crate::lower::Lx, st: &crate::syntax::Stmt) -> bool {
    match &st.kind {
        crate::syntax::StmtKind::SWhile(_, _) => crate::check::env::has_key(&lx.unshrunk, &crate::lower::place_key(lx, &st.span)),
        _ => false,
    }
}

/// ```prism
/// ElseHasTopWhile: fn Lx, ?Block -> Bool
/// ```
pub fn else_has_top_while(lx: &crate::lower::Lx, opt1: &Option<crate::syntax::Block>) -> bool {
    match opt1 {
        Some(b) => has_top_while(lx, b),
        None => false,
    }
}

/// ```prism
/// HoldsCycleWhile: fn Lx, Stmt -> Bool
/// ```
pub fn holds_cycle_while(lx: &crate::lower::Lx, st: &crate::syntax::Stmt) -> bool {
    match &st.kind {
        crate::syntax::StmtKind::SWhile(_, wb) => has_top_while(lx, wb),
        crate::syntax::StmtKind::SExpr(x) => match &*x.kind {
            crate::syntax::ExprKind::EIf(_, then_b, else_b_opt) => has_top_while(lx, then_b) || else_has_top_while(lx, else_b_opt),
            crate::syntax::ExprKind::EMatch(_, arms) => fold(arms, &false, &(|f: &bool, a: &crate::syntax::Arm| *f || has_top_while(lx, &a.body))),
            crate::syntax::ExprKind::EFor(_, _, fb) => has_top_while(lx, fb),
            _ => false,
        },
        _ => false,
    }
}

/// ```prism
/// UpdTail: unbounded fn Lx, Env, Expr, Block, Range, (unbounded fn Env, Ex -> Ex) -> Ex
/// ```
pub fn upd_tail(lx: &crate::lower::Lx, env: &crate::lower::types::Env, target: &crate::syntax::Expr, b: &crate::syntax::Block, to: &crate::syntax::Range, cont_fn: &Rc<dyn Fn((crate::lower::types::Env, crate::lower::model::Ex)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>) -> crate::lower::model::Ex {
    let t = crate::lower::types::out_ty_of(lx, &crate::lower::types::peel(&crate::lower::type_at(lx, &target.span)));
    let tv = crate::lower::expr::value_of(lx, env, target);
    let env1 = crate::lower::types::bind(env, &Text::lit("&_"), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(Text::lit("this")), crate::lower::types::Holding::Owned, t.clone()));
    prepend(&Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaMut(Text::lit("this"))), t.clone()), crate::lower::types::own(&tv))]), &upd_tail_from(lx, env, &env1, b, &Nat::from(0u32), to, &cont_fn.clone()))
}

/// The step machine of `UpdTail`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UpdTail: unbounded fn Lx, Env, Expr, Block, Range, (unbounded fn Env, Ex -> Ex) -> Ex
/// ```
pub struct UpdTail {
    pub lx: crate::lower::Lx,
    pub env: crate::lower::types::Env,
    pub target: crate::syntax::Expr,
    pub b: crate::syntax::Block,
    pub to: crate::syntax::Range,
    pub cont_fn: Rc<dyn Fn((crate::lower::types::Env, crate::lower::model::Ex)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>,
}

impl prism_rtl::Job<crate::lower::model::Ex> for UpdTail {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::Ex> {
        let lx = &self.lx;
        let env = &self.env;
        let target = &self.target;
        let b = &self.b;
        let to = &self.to;
        let cont_fn = &self.cont_fn;
        let cont_fn = cont_fn.clone();
        let b = b.clone();
        let env = env.clone();
        let lx = lx.clone();
        let target = target.clone();
        let to = to.clone();
        call_then(crate::lower::types::start_out_ty_of(lx.clone(), crate::lower::types::peel(&crate::lower::type_at(&lx, &target.span))), move |out_ty_of_7825: crate::lower::model::OutTy| {
            let t = out_ty_of_7825;
            call_then(crate::lower::expr::start_value_of(lx.clone(), env.clone(), target.clone()), move |value_of_7882: crate::lower::types::Vl| {
                let tv = value_of_7882;
                let env1 = crate::lower::types::bind(&env, &Text::lit("&_"), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(Text::lit("this")), crate::lower::types::Holding::Owned, t.clone()));
                call_then(start_upd_tail_from(lx.clone(), env.clone(), env1.clone(), b.clone(), Nat::from(0u32), to.clone(), cont_fn.clone()), move |upd_tail_from_8035: crate::lower::model::Ex| prism_rtl::Turn::Finished(prepend(&Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaMut(Text::lit("this"))), t.clone()), crate::lower::types::own(&tv))]), &upd_tail_from_8035)))
            })
        })
    }
}

/// `Start UpdTail, x`: what the function value is when passed to `@Run`.
pub fn start_upd_tail(lx: crate::lower::Lx, env: crate::lower::types::Env, target: crate::syntax::Expr, b: crate::syntax::Block, to: crate::syntax::Range, cont_fn: Rc<dyn Fn((crate::lower::types::Env, crate::lower::model::Ex)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>> {
    Rc::new(UpdTail { lx, env, target, b, to, cont_fn })
}

/// ```prism
/// UpdTailFrom: unbounded fn Lx, Env, Env, Block, Nat, Range, (unbounded fn Env, Ex -> Ex) -> Ex
/// ```
pub fn upd_tail_from(lx: &crate::lower::Lx, outer: &crate::lower::types::Env, env: &crate::lower::types::Env, b: &crate::syntax::Block, i: &Nat, to: &crate::syntax::Range, cont_fn: &Rc<dyn Fn((crate::lower::types::Env, crate::lower::model::Ex)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>) -> crate::lower::model::Ex {
    if i >= &len(&b.stmts) {
        run_to_end(cont_fn((outer.clone(), crate::lower::model::Ex::XVar(Text::lit("this")))))
    } else {
        {
            let s = or(&index(&b.stmts, i), &crate::lower::expr::dummy_stmt_l());
            let rest = rest_text(lx, &crate::syntax::Range { start: s.span.end.clone(), end: s.span.end.clone() }, &crate::syntax::Range { start: s.span.end.clone(), end: s.span.end.clone() }, to);
            let next_fn = {
                let lx = lx.clone();
                let b = b.clone();
                let i = i.clone();
                let to = to.clone();
                let cont_fn = cont_fn.clone();
                Rc::new(move |(p0, p1): (crate::lower::types::Env, crate::lower::types::Env)| {
                    let lx = lx.clone();
                    let b = b.clone();
                    let i = i.clone();
                    let to = to.clone();
                    let cont_fn = cont_fn.clone();
                    entered(once_job(move || {
                        let o2 = p0;
                        let e2 = p1;
                        prism_rtl::Turn::More(Rc::new(UpdTailFrom { lx: lx.clone(), outer: o2.clone(), env: e2.clone(), b: b.clone(), i: &i + &Nat::from(1u32), to: to.clone(), cont_fn: cont_fn.clone() }))
                    }))
                }) as Rc<dyn Fn((crate::lower::types::Env, crate::lower::types::Env)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
            };
            if is_cycle_while(lx, &s) || holds_cycle_while(lx, &s) {
                stmt_job(lx, outer, env, &s, &rest, &next_fn.clone())
            } else {
                {
                    let (dos, env2) = crate::lower::templates::upd_stmt(lx, env, &s);
                    prepend(&dos, &upd_tail_from(lx, outer, &env2, b, &(i + &Nat::from(1u32)), to, &cont_fn.clone()))
                }
            }
        }
    }
}

/// The step machine of `UpdTailFrom`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UpdTailFrom: unbounded fn Lx, Env, Env, Block, Nat, Range, (unbounded fn Env, Ex -> Ex) -> Ex
/// ```
pub struct UpdTailFrom {
    pub lx: crate::lower::Lx,
    pub outer: crate::lower::types::Env,
    pub env: crate::lower::types::Env,
    pub b: crate::syntax::Block,
    pub i: Nat,
    pub to: crate::syntax::Range,
    pub cont_fn: Rc<dyn Fn((crate::lower::types::Env, crate::lower::model::Ex)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>,
}

impl prism_rtl::Job<crate::lower::model::Ex> for UpdTailFrom {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::Ex> {
        let lx = &self.lx;
        let outer = &self.outer;
        let env = &self.env;
        let b = &self.b;
        let i = &self.i;
        let to = &self.to;
        let cont_fn = &self.cont_fn;
        if i >= &len(&b.stmts) {
            cont_fn((outer.clone(), crate::lower::model::Ex::XVar(Text::lit("this")))).cycle()
        } else {
            {
                let s = or(&index(&b.stmts, i), &crate::lower::expr::dummy_stmt_l());
                let rest = rest_text(lx, &crate::syntax::Range { start: s.span.end.clone(), end: s.span.end.clone() }, &crate::syntax::Range { start: s.span.end.clone(), end: s.span.end.clone() }, to);
                let next_fn = {
                    let lx = lx.clone();
                    let b = b.clone();
                    let i = i.clone();
                    let to = to.clone();
                    let cont_fn = cont_fn.clone();
                    Rc::new(move |(p0, p1): (crate::lower::types::Env, crate::lower::types::Env)| {
                        let lx = lx.clone();
                        let b = b.clone();
                        let i = i.clone();
                        let to = to.clone();
                        let cont_fn = cont_fn.clone();
                        entered(once_job(move || {
                            let o2 = p0;
                            let e2 = p1;
                            prism_rtl::Turn::More(Rc::new(UpdTailFrom { lx: lx.clone(), outer: o2.clone(), env: e2.clone(), b: b.clone(), i: &i + &Nat::from(1u32), to: to.clone(), cont_fn: cont_fn.clone() }))
                        }))
                    }) as Rc<dyn Fn((crate::lower::types::Env, crate::lower::types::Env)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
                };
                if is_cycle_while(lx, &s) || holds_cycle_while(lx, &s) {
                    prism_rtl::Turn::More(Rc::new(StmtJob { lx: lx.clone(), outer: outer.clone(), env: env.clone(), s: s.clone(), rest: rest.clone(), cont_fn: next_fn.clone() }))
                } else {
                    {
                        let cont_fn = cont_fn.clone();
                        let b = b.clone();
                        let env = env.clone();
                        let i = i.clone();
                        let lx = lx.clone();
                        let outer = outer.clone();
                        let to = to.clone();
                        call_then(crate::lower::templates::start_upd_stmt(lx.clone(), env.clone(), s.clone()), move |upd_stmt_8662: (Array<crate::lower::model::Do>, crate::lower::types::Env)| {
                            let (dos, env2) = upd_stmt_8662;
                            call_then(start_upd_tail_from(lx.clone(), outer.clone(), env2.clone(), b.clone(), &i + &Nat::from(1u32), to.clone(), cont_fn.clone()), move |upd_tail_from_8707: crate::lower::model::Ex| prism_rtl::Turn::Finished(prepend(&dos, &upd_tail_from_8707)))
                        })
                    }
                }
            }
        }
    }
}

/// `Start UpdTailFrom, x`: what the function value is when passed to `@Run`.
pub fn start_upd_tail_from(lx: crate::lower::Lx, outer: crate::lower::types::Env, env: crate::lower::types::Env, b: crate::syntax::Block, i: Nat, to: crate::syntax::Range, cont_fn: Rc<dyn Fn((crate::lower::types::Env, crate::lower::model::Ex)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>> {
    Rc::new(UpdTailFrom { lx, outer, env, b, i, to, cont_fn })
}

/// ```prism
/// StmtJob: unbounded fn Lx, Env, Env, Stmt, Text, (unbounded fn Env, Env -> Ex) -> Ex
/// ```
pub fn stmt_job(lx: &crate::lower::Lx, outer: &crate::lower::types::Env, env: &crate::lower::types::Env, s: &crate::syntax::Stmt, rest: &Text, cont_fn: &Rc<dyn Fn((crate::lower::types::Env, crate::lower::types::Env)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>) -> crate::lower::model::Ex {
    match &s.kind {
        crate::syntax::StmtKind::SWhile(c, wb) => while_job(lx, outer, env, c, wb, &s.span, rest, &cont_fn.clone()),
        crate::syntax::StmtKind::SExpr(x) => match &*x.kind {
            crate::syntax::ExprKind::EIf(c, then_b, else_b_opt) => if_job(lx, outer, env, &**c, then_b, else_b_opt, &s.span, rest, &cont_fn.clone()),
            crate::syntax::ExprKind::EMatch(scrut, arms) => match_job(lx, outer, env, &**scrut, arms, &s.span, rest, &cont_fn.clone()),
            crate::syntax::ExprKind::EFor(binders_opt, source, body) => match crate::lower::templates::ref_binder(binders_opt) {
                Some(_) => crate::lower::expr::refusal(&Text::lit("a cycle-point `while` in a `for &` of an `update` block, whose references a job cannot keep (gap LP)")),
                None => for_job(lx, outer, env, binders_opt, &**source, body, &s.span, rest, &cont_fn.clone()),
            },
            _ => crate::lower::expr::refusal(&Text::from(format!("a cycle-point `while` in {} (gap LP)", &crate::lower::expr::kind_words(&*x.kind)))),
        },
        _ => crate::lower::expr::refusal(&Text::lit("a cycle-point `while` in this statement (gap LP)")),
    }
}

/// The step machine of `StmtJob`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// StmtJob: unbounded fn Lx, Env, Env, Stmt, Text, (unbounded fn Env, Env -> Ex) -> Ex
/// ```
pub struct StmtJob {
    pub lx: crate::lower::Lx,
    pub outer: crate::lower::types::Env,
    pub env: crate::lower::types::Env,
    pub s: crate::syntax::Stmt,
    pub rest: Text,
    pub cont_fn: Rc<dyn Fn((crate::lower::types::Env, crate::lower::types::Env)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>,
}

impl prism_rtl::Job<crate::lower::model::Ex> for StmtJob {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::Ex> {
        let lx = &self.lx;
        let outer = &self.outer;
        let env = &self.env;
        let s = &self.s;
        let rest = &self.rest;
        let cont_fn = &self.cont_fn;
        match &s.kind {
            crate::syntax::StmtKind::SWhile(c, wb) => prism_rtl::Turn::More(Rc::new(WhileJob { lx: lx.clone(), outer: outer.clone(), env: env.clone(), c: c.clone(), wb: wb.clone(), span: s.span.clone(), rest_text_: rest.clone(), cont_fn: cont_fn.clone() })),
            crate::syntax::StmtKind::SExpr(x) => match &*x.kind {
                crate::syntax::ExprKind::EIf(c, then_b, else_b_opt) => prism_rtl::Turn::More(Rc::new(IfJob { lx: lx.clone(), outer: outer.clone(), env: env.clone(), c: (**c).clone(), then_b: then_b.clone(), else_b_opt: else_b_opt.clone(), span: s.span.clone(), rest_text_: rest.clone(), cont_fn: cont_fn.clone() })),
                crate::syntax::ExprKind::EMatch(scrut, arms) => prism_rtl::Turn::More(Rc::new(MatchJob { lx: lx.clone(), outer: outer.clone(), env: env.clone(), scrut: (**scrut).clone(), arms: arms.clone(), span: s.span.clone(), rest_text_: rest.clone(), cont_fn: cont_fn.clone() })),
                crate::syntax::ExprKind::EFor(binders_opt, source, body) => match crate::lower::templates::ref_binder(binders_opt) {
                    Some(_) => prism_rtl::Turn::Finished(crate::lower::expr::refusal(&Text::lit("a cycle-point `while` in a `for &` of an `update` block, whose references a job cannot keep (gap LP)"))),
                    None => prism_rtl::Turn::More(Rc::new(ForJob { lx: lx.clone(), outer: outer.clone(), env: env.clone(), binders_opt: binders_opt.clone(), source: (**source).clone(), body: body.clone(), span: s.span.clone(), rest_text_: rest.clone(), cont_fn: cont_fn.clone() })),
                },
                _ => prism_rtl::Turn::Finished(crate::lower::expr::refusal(&Text::from(format!("a cycle-point `while` in {} (gap LP)", &crate::lower::expr::kind_words(&*x.kind))))),
            },
            _ => prism_rtl::Turn::Finished(crate::lower::expr::refusal(&Text::lit("a cycle-point `while` in this statement (gap LP)"))),
        }
    }
}

/// `Start StmtJob, x`: what the function value is when passed to `@Run`.
pub fn start_stmt_job(lx: crate::lower::Lx, outer: crate::lower::types::Env, env: crate::lower::types::Env, s: crate::syntax::Stmt, rest: Text, cont_fn: Rc<dyn Fn((crate::lower::types::Env, crate::lower::types::Env)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>> {
    Rc::new(StmtJob { lx, outer, env, s, rest, cont_fn })
}

/// ```prism
/// Prepend: fn [Do], Ex -> Ex
/// ```
pub fn prepend(dos: &Array<crate::lower::model::Do>, ex1: &crate::lower::model::Ex) -> crate::lower::model::Ex {
    match ex1 {
        crate::lower::model::Ex::XBlock(more, last) => crate::lower::model::Ex::XBlock(append(dos, more), Rc::new((**last).clone())),
        x => if &len(dos) == &Nat::from(0u32) {
            x.clone()
        } else {
            crate::lower::model::Ex::XBlock(dos.clone(), Rc::new(x.clone()))
        },
    }
}

/// ```prism
/// WhileJob: unbounded fn Lx, Env, Env, Cond, Block, Range, Text, (unbounded fn Env, Env -> Ex) -> Ex
/// ```
pub fn while_job(lx: &crate::lower::Lx, outer: &crate::lower::types::Env, env: &crate::lower::types::Env, c: &crate::syntax::Cond, wb: &crate::syntax::Block, span: &crate::syntax::Range, rest_text_: &Text, cont_fn: &Rc<dyn Fn((crate::lower::types::Env, crate::lower::types::Env)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>) -> crate::lower::model::Ex {
    let state = fold(&keys(&env.names), &Array::new(), &(|acc: &Array<(Text, Text, crate::lower::model::OutTy)>, k: &Text| if !crate::syntax::lexer::chars::has_prefix(k, &Text::lit("&")) {
        acc.clone()
    } else {
        match get(&env.names, k) {
            Some(crate::lower::types::Bn::BnLocal(rs, _, bt)) => push(acc, &(k.clone(), crate::lower::types::place_stem(&rs), bt.clone())),
            _ => acc.clone(),
        }
    }));
    let names = each(&state, &(|(_, rs, _): &(Text, Text, crate::lower::model::OutTy)| rs.clone()));
    let st_ty = crate::lower::model::OutTy::OutTuple(each(&state, &(|(_, _, bt): &(Text, Text, crate::lower::model::OutTy)| bt.clone())));
    let pat = crate::lower::model::Pa::PaTuple(each(&names, &(|n: &Text| crate::lower::model::Pa::PaMut(Text::from(format!("{}", n))))));
    let pack = crate::lower::model::Ex::XTuple(each(&names, &(|n: &Text| crate::lower::model::Ex::XVar(n.clone()))));
    let env_s = fold(&state, env, &(|en: &crate::lower::types::Env, (k, rs, bt): &(Text, Text, crate::lower::model::OutTy)| crate::lower::types::bind(en, k, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(rs.clone()), crate::lower::types::Holding::Owned, bt.clone()))));
    let loop_text = match index(&lx.g.srcs, &lx.file) {
        Some(src) => crate::check::errors::span_text(&src, span),
        None => Text::lit(""),
    };
    let caps = caps_in(&env_s, &loop_text, &names);
    let cap_dos = each(&caps, &(|(_, rs, mode, bt): &(Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)| crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::lower::types::place_stem(rs)), crate::lower::types::own(&crate::lower::types::Vl::VlPlace(rs.clone(), mode.clone(), bt.clone())))));
    let env_c = fold(&caps, &env_s, &(|en: &crate::lower::types::Env, (k, rs, _, bt): &(Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)| crate::lower::types::bind(en, k, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(crate::lower::types::place_stem(rs)), crate::lower::types::Holding::Owned, bt.clone()))));
    let jobs = has_top_while(lx, wb);
    let finish_fn = {
        let jobs = jobs;
        Rc::new(move |x: &crate::lower::model::Ex| if jobs {
            crate::lower::model::Ex::XCtor(Text::lit("prism_rtl::Turn::Finished"), Array::from(vec![x.clone()]))
        } else {
            x.clone()
        })
    };
    let step_ty = crate::lower::model::OutTy::OutNamed(Text::lit("Result"), Array::from(vec![st_ty.clone(), st_ty.clone()]));
    let again = (&finish_fn)(&crate::lower::model::Ex::XTyped(Rc::new(crate::lower::model::Ex::XCtor(Text::lit("Ok"), Array::from(vec![pack.clone()]))), step_ty.clone()));
    let stop = (&finish_fn)(&crate::lower::model::Ex::XTyped(Rc::new(crate::lower::model::Ex::XCtor(Text::lit("Err"), Array::from(vec![pack.clone()]))), step_ty.clone()));
    let body_fn = {
        let jobs = jobs;
        let lx = lx.clone();
        let wb = wb.clone();
        let again = again.clone();
        Rc::new(move |p0: crate::lower::types::Env| {
            let jobs = jobs;
            let lx = lx.clone();
            let wb = wb.clone();
            let again = again.clone();
            entered(once_job(move || {
                let en = p0;
                if jobs {
                    prism_rtl::Turn::More(Rc::new(UpdTailFrom { lx: lx.clone(), outer: en.clone(), env: en.clone(), b: wb.clone(), i: Nat::from(0u32), to: wb.span.clone(), cont_fn: {
                        let again = again.clone();
                        Rc::new(move |(p0, p1): (crate::lower::types::Env, crate::lower::model::Ex)| {
                            let again = again.clone();
                            once_job(move || {
                                let o2 = p0;
                                let e2 = p1;
                                prism_rtl::Turn::Finished(again.clone())
                            })
                        }) as Rc<dyn Fn((crate::lower::types::Env, crate::lower::model::Ex)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
                    } }))
                } else {
                    prism_rtl::Turn::More(Rc::new(StmtsThen { lx: lx.clone(), env: en.clone(), b: wb.clone(), last: again.clone() }))
                }
            }))
        }) as Rc<dyn Fn(crate::lower::types::Env) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
    };
    let res_ty = if jobs {
        crate::lower::model::OutTy::OutNamed(Text::lit("prism_rtl::Turn"), Array::from(vec![step_ty.clone()]))
    } else {
        st_ty.clone()
    };
    let turn = match c {
        crate::syntax::Cond::CondExpr(x) => crate::lower::model::Ex::XIf(Rc::new(crate::lower::types::as_bool(&crate::lower::expr::value_of(lx, &env_c, &**x))), Rc::new(run_to_end((&body_fn)(env_c.clone()))), Rc::new(stop.clone())),
        crate::syntax::Cond::CondBind(p_, x, g_opt) => {
            let po = crate::lower::patterns::rust_pat(lx, p_, &crate::lower::type_at(lx, &x.span), &crate::lower::types::Holding::Owned, &Text::from(format!("w{}", &span.start)));
            let env_b = crate::lower::expr::bind_all(&env_c, &po.binds);
            let conds = append(&po.conds, &crate::lower::templates::guard_conds(lx, &env_b, &**g_opt));
            crate::lower::types::own(&crate::lower::expr::arms_value(&crate::lower::types::own(&crate::lower::expr::value_of(lx, &env_c, &**x)), &Array::from(vec![crate::lower::model::XArm { pat: po.pa.clone(), conds: conds.clone(), body: run_to_end((&body_fn)(env_b.clone())) }, crate::lower::model::XArm { pat: crate::lower::model::Pa::PaWild, conds: Array::new(), body: stop.clone() }]), &Text::from(format!("'w{}", &span.start)), &res_ty))
        },
    };
    let out_caps = caps_in(outer, rest_text_, &names);
    let out_dos = each(&out_caps, &(|(_, rs, mode, bt): &(Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)| crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::lower::types::place_stem(rs)), crate::lower::types::own(&crate::lower::types::Vl::VlPlace(rs.clone(), mode.clone(), bt.clone())))));
    let outer2 = fold(&out_caps, outer, &(|en: &crate::lower::types::Env, (k, rs, _, bt): &(Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)| crate::lower::types::bind(en, k, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(crate::lower::types::place_stem(rs)), crate::lower::types::Holding::Owned, bt.clone()))));
    let env2 = fold(&out_caps, &env_s, &(|en: &crate::lower::types::Env, (k, rs, _, bt): &(Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)| crate::lower::types::bind(en, k, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(crate::lower::types::place_stem(rs)), crate::lower::types::Holding::Owned, bt.clone()))));
    let step_fn = prepend(&cap_dos, &crate::lower::model::Ex::XClosure(true, Array::from(vec![crate::lower::model::Pa::PaTyped(Rc::new(pat.clone()), st_ty.clone())]), Rc::new(turn.clone())));
    let looping = if jobs { Text::lit("loop_turns") } else { Text::lit("loop_job") };
    let enter = crate::lower::model::Ex::XCall(Text::lit("call_then"), Array::from(vec![crate::lower::model::Ex::XCall(looping.clone(), Array::from(vec![pack.clone(), step_fn.clone()])), crate::lower::model::Ex::XClosure(true, Array::from(vec![crate::lower::model::Pa::PaTyped(Rc::new(pat.clone()), st_ty.clone())]), Rc::new(run_to_end(cont_fn((outer2.clone(), env2.clone())))))]));
    prepend(&out_dos, &enter)
}

/// The step machine of `WhileJob`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// WhileJob: unbounded fn Lx, Env, Env, Cond, Block, Range, Text, (unbounded fn Env, Env -> Ex) -> Ex
/// ```
pub struct WhileJob {
    pub lx: crate::lower::Lx,
    pub outer: crate::lower::types::Env,
    pub env: crate::lower::types::Env,
    pub c: crate::syntax::Cond,
    pub wb: crate::syntax::Block,
    pub span: crate::syntax::Range,
    pub rest_text_: Text,
    pub cont_fn: Rc<dyn Fn((crate::lower::types::Env, crate::lower::types::Env)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>,
}

impl prism_rtl::Job<crate::lower::model::Ex> for WhileJob {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::Ex> {
        let lx = &self.lx;
        let outer = &self.outer;
        let env = &self.env;
        let c = &self.c;
        let wb = &self.wb;
        let span = &self.span;
        let rest_text_ = &self.rest_text_;
        let cont_fn = &self.cont_fn;
        let state = fold(&keys(&env.names), &Array::new(), &(|acc: &Array<(Text, Text, crate::lower::model::OutTy)>, k: &Text| if !crate::syntax::lexer::chars::has_prefix(k, &Text::lit("&")) {
            acc.clone()
        } else {
            match get(&env.names, k) {
                Some(crate::lower::types::Bn::BnLocal(rs, _, bt)) => push(acc, &(k.clone(), crate::lower::types::place_stem(&rs), bt.clone())),
                _ => acc.clone(),
            }
        }));
        let names = each(&state, &(|(_, rs, _): &(Text, Text, crate::lower::model::OutTy)| rs.clone()));
        let st_ty = crate::lower::model::OutTy::OutTuple(each(&state, &(|(_, _, bt): &(Text, Text, crate::lower::model::OutTy)| bt.clone())));
        let pat = crate::lower::model::Pa::PaTuple(each(&names, &(|n: &Text| crate::lower::model::Pa::PaMut(Text::from(format!("{}", n))))));
        let pack = crate::lower::model::Ex::XTuple(each(&names, &(|n: &Text| crate::lower::model::Ex::XVar(n.clone()))));
        let env_s = fold(&state, env, &(|en: &crate::lower::types::Env, (k, rs, bt): &(Text, Text, crate::lower::model::OutTy)| crate::lower::types::bind(en, k, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(rs.clone()), crate::lower::types::Holding::Owned, bt.clone()))));
        let loop_text = match index(&lx.g.srcs, &lx.file) {
            Some(src) => crate::check::errors::span_text(&src, span),
            None => Text::lit(""),
        };
        let caps = caps_in(&env_s, &loop_text, &names);
        let cap_dos = each(&caps, &(|(_, rs, mode, bt): &(Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)| crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::lower::types::place_stem(rs)), crate::lower::types::own(&crate::lower::types::Vl::VlPlace(rs.clone(), mode.clone(), bt.clone())))));
        let env_c = fold(&caps, &env_s, &(|en: &crate::lower::types::Env, (k, rs, _, bt): &(Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)| crate::lower::types::bind(en, k, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(crate::lower::types::place_stem(rs)), crate::lower::types::Holding::Owned, bt.clone()))));
        let jobs = has_top_while(lx, wb);
        let finish_fn = {
            let jobs = jobs;
            Rc::new(move |x: &crate::lower::model::Ex| if jobs {
                crate::lower::model::Ex::XCtor(Text::lit("prism_rtl::Turn::Finished"), Array::from(vec![x.clone()]))
            } else {
                x.clone()
            })
        };
        let step_ty = crate::lower::model::OutTy::OutNamed(Text::lit("Result"), Array::from(vec![st_ty.clone(), st_ty.clone()]));
        let again = (&finish_fn)(&crate::lower::model::Ex::XTyped(Rc::new(crate::lower::model::Ex::XCtor(Text::lit("Ok"), Array::from(vec![pack.clone()]))), step_ty.clone()));
        let stop = (&finish_fn)(&crate::lower::model::Ex::XTyped(Rc::new(crate::lower::model::Ex::XCtor(Text::lit("Err"), Array::from(vec![pack.clone()]))), step_ty.clone()));
        let body_fn = {
            let jobs = jobs;
            let lx = lx.clone();
            let wb = wb.clone();
            let again = again.clone();
            Rc::new(move |p0: crate::lower::types::Env| {
                let jobs = jobs;
                let lx = lx.clone();
                let wb = wb.clone();
                let again = again.clone();
                entered(once_job(move || {
                    let en = p0;
                    if jobs {
                        prism_rtl::Turn::More(Rc::new(UpdTailFrom { lx: lx.clone(), outer: en.clone(), env: en.clone(), b: wb.clone(), i: Nat::from(0u32), to: wb.span.clone(), cont_fn: {
                            let again = again.clone();
                            Rc::new(move |(p0, p1): (crate::lower::types::Env, crate::lower::model::Ex)| {
                                let again = again.clone();
                                once_job(move || {
                                    let o2 = p0;
                                    let e2 = p1;
                                    prism_rtl::Turn::Finished(again.clone())
                                })
                            }) as Rc<dyn Fn((crate::lower::types::Env, crate::lower::model::Ex)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
                        } }))
                    } else {
                        prism_rtl::Turn::More(Rc::new(StmtsThen { lx: lx.clone(), env: en.clone(), b: wb.clone(), last: again.clone() }))
                    }
                }))
            }) as Rc<dyn Fn(crate::lower::types::Env) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
        };
        let res_ty = if jobs {
            crate::lower::model::OutTy::OutNamed(Text::lit("prism_rtl::Turn"), Array::from(vec![step_ty.clone()]))
        } else {
            st_ty.clone()
        };
        let turn = match c {
            crate::syntax::Cond::CondExpr(x) => crate::lower::model::Ex::XIf(Rc::new(crate::lower::types::as_bool(&crate::lower::expr::value_of(lx, &env_c, &**x))), Rc::new(run_to_end((&body_fn)(env_c.clone()))), Rc::new(stop.clone())),
            crate::syntax::Cond::CondBind(p_, x, g_opt) => {
                let po = crate::lower::patterns::rust_pat(lx, p_, &crate::lower::type_at(lx, &x.span), &crate::lower::types::Holding::Owned, &Text::from(format!("w{}", &span.start)));
                let env_b = crate::lower::expr::bind_all(&env_c, &po.binds);
                let conds = append(&po.conds, &crate::lower::templates::guard_conds(lx, &env_b, &**g_opt));
                crate::lower::types::own(&crate::lower::expr::arms_value(&crate::lower::types::own(&crate::lower::expr::value_of(lx, &env_c, &**x)), &Array::from(vec![crate::lower::model::XArm { pat: po.pa.clone(), conds: conds.clone(), body: run_to_end((&body_fn)(env_b.clone())) }, crate::lower::model::XArm { pat: crate::lower::model::Pa::PaWild, conds: Array::new(), body: stop.clone() }]), &Text::from(format!("'w{}", &span.start)), &res_ty))
            },
        };
        let out_caps = caps_in(outer, rest_text_, &names);
        let out_dos = each(&out_caps, &(|(_, rs, mode, bt): &(Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)| crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::lower::types::place_stem(rs)), crate::lower::types::own(&crate::lower::types::Vl::VlPlace(rs.clone(), mode.clone(), bt.clone())))));
        let outer2 = fold(&out_caps, outer, &(|en: &crate::lower::types::Env, (k, rs, _, bt): &(Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)| crate::lower::types::bind(en, k, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(crate::lower::types::place_stem(rs)), crate::lower::types::Holding::Owned, bt.clone()))));
        let env2 = fold(&out_caps, &env_s, &(|en: &crate::lower::types::Env, (k, rs, _, bt): &(Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)| crate::lower::types::bind(en, k, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(crate::lower::types::place_stem(rs)), crate::lower::types::Holding::Owned, bt.clone()))));
        let step_fn = prepend(&cap_dos, &crate::lower::model::Ex::XClosure(true, Array::from(vec![crate::lower::model::Pa::PaTyped(Rc::new(pat.clone()), st_ty.clone())]), Rc::new(turn.clone())));
        let looping = if jobs { Text::lit("loop_turns") } else { Text::lit("loop_job") };
        let cont_fn = cont_fn.clone();
        call_value((&cont_fn)((outer2.clone(), env2.clone())), move |cont_13212: crate::lower::model::Ex| {
            let enter = crate::lower::model::Ex::XCall(Text::lit("call_then"), Array::from(vec![crate::lower::model::Ex::XCall(looping.clone(), Array::from(vec![pack.clone(), step_fn.clone()])), crate::lower::model::Ex::XClosure(true, Array::from(vec![crate::lower::model::Pa::PaTyped(Rc::new(pat.clone()), st_ty.clone())]), Rc::new(cont_13212))]));
            prism_rtl::Turn::Finished(prepend(&out_dos, &enter))
        })
    }
}

/// `Start WhileJob, x`: what the function value is when passed to `@Run`.
pub fn start_while_job(lx: crate::lower::Lx, outer: crate::lower::types::Env, env: crate::lower::types::Env, c: crate::syntax::Cond, wb: crate::syntax::Block, span: crate::syntax::Range, rest_text_: Text, cont_fn: Rc<dyn Fn((crate::lower::types::Env, crate::lower::types::Env)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>> {
    Rc::new(WhileJob { lx, outer, env, c, wb, span, rest_text_, cont_fn })
}

/// ```prism
/// StmtsThen: unbounded fn Lx, Env, Block, Ex -> Ex
/// ```
pub fn stmts_then(lx: &crate::lower::Lx, env: &crate::lower::types::Env, b: &crate::syntax::Block, last: &crate::lower::model::Ex) -> crate::lower::model::Ex {
    let (dos, _) = crate::lower::templates::upd_stmts(lx, env, &b.stmts);
    crate::lower::model::Ex::XBlock(dos.clone(), Rc::new(last.clone()))
}

/// The step machine of `StmtsThen`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// StmtsThen: unbounded fn Lx, Env, Block, Ex -> Ex
/// ```
pub struct StmtsThen {
    pub lx: crate::lower::Lx,
    pub env: crate::lower::types::Env,
    pub b: crate::syntax::Block,
    pub last: crate::lower::model::Ex,
}

impl prism_rtl::Job<crate::lower::model::Ex> for StmtsThen {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::Ex> {
        let lx = &self.lx;
        let env = &self.env;
        let b = &self.b;
        let last = &self.last;
        let b = b.clone();
        let env = env.clone();
        let last = last.clone();
        let lx = lx.clone();
        call_then(crate::lower::templates::start_upd_stmts(lx.clone(), env.clone(), b.stmts.clone()), move |upd_stmts_13425: (Array<crate::lower::model::Do>, crate::lower::types::Env)| {
            let (dos, _) = upd_stmts_13425;
            prism_rtl::Turn::Finished(crate::lower::model::Ex::XBlock(dos.clone(), Rc::new(last.clone())))
        })
    }
}

/// `Start StmtsThen, x`: what the function value is when passed to `@Run`.
pub fn start_stmts_then(lx: crate::lower::Lx, env: crate::lower::types::Env, b: crate::syntax::Block, last: crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>> {
    Rc::new(StmtsThen { lx, env, b, last })
}

/// ```prism
/// IfJob: unbounded fn Lx, Env, Env, Cond, Block, ?Block, Range, Text, (unbounded fn Env, Env -> Ex) -> Ex
/// ```
pub fn if_job(lx: &crate::lower::Lx, outer: &crate::lower::types::Env, env: &crate::lower::types::Env, c: &crate::syntax::Cond, then_b: &crate::syntax::Block, else_b_opt: &Option<crate::syntax::Block>, span: &crate::syntax::Range, rest_text_: &Text, cont_fn: &Rc<dyn Fn((crate::lower::types::Env, crate::lower::types::Env)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>) -> crate::lower::model::Ex {
    let state = fold(&keys(&env.names), &Array::new(), &(|acc: &Array<(Text, Text, crate::lower::model::OutTy)>, k: &Text| if !crate::syntax::lexer::chars::has_prefix(k, &Text::lit("&")) {
        acc.clone()
    } else {
        match get(&env.names, k) {
            Some(crate::lower::types::Bn::BnLocal(rs, _, bt)) => push(acc, &(k.clone(), crate::lower::types::place_stem(&rs), bt.clone())),
            _ => acc.clone(),
        }
    }));
    let names = each(&state, &(|(_, rs, _): &(Text, Text, crate::lower::model::OutTy)| rs.clone()));
    let st_ty = crate::lower::model::OutTy::OutTuple(each(&state, &(|(_, _, bt): &(Text, Text, crate::lower::model::OutTy)| bt.clone())));
    let pat = crate::lower::model::Pa::PaTuple(each(&names, &(|n: &Text| crate::lower::model::Pa::PaMut(Text::from(format!("{}", n))))));
    let pack = crate::lower::model::Ex::XTuple(each(&names, &(|n: &Text| crate::lower::model::Ex::XVar(n.clone()))));
    let env_s = fold(&state, env, &(|en: &crate::lower::types::Env, (k, rs, bt): &(Text, Text, crate::lower::model::OutTy)| crate::lower::types::bind(en, k, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(rs.clone()), crate::lower::types::Holding::Owned, bt.clone()))));
    let out_caps = caps_in(outer, rest_text_, &names);
    let out_dos = each(&out_caps, &(|(_, rs, mode, bt): &(Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)| crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::lower::types::place_stem(rs)), crate::lower::types::own(&crate::lower::types::Vl::VlPlace(rs.clone(), mode.clone(), bt.clone())))));
    let outer2 = fold(&out_caps, outer, &(|en: &crate::lower::types::Env, (k, rs, _, bt): &(Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)| crate::lower::types::bind(en, k, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(crate::lower::types::place_stem(rs)), crate::lower::types::Holding::Owned, bt.clone()))));
    let env2 = fold(&out_caps, &env_s, &(|en: &crate::lower::types::Env, (k, rs, _, bt): &(Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)| crate::lower::types::bind(en, k, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(crate::lower::types::place_stem(rs)), crate::lower::types::Holding::Owned, bt.clone()))));
    let k_name = Text::from(format!("k_if{}", &span.start));
    let k_do = crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(k_name.clone()), crate::lower::model::Ex::XClosure(true, Array::from(vec![crate::lower::model::Pa::PaTyped(Rc::new(pat.clone()), st_ty.clone())]), Rc::new(run_to_end(cont_fn((outer2.clone(), env2.clone()))))));
    let to_k_fn = {
        let k_name = k_name.clone();
        let pack = pack.clone();
        Rc::new(move |o2: &crate::lower::types::Env, e2: &crate::lower::model::Ex| crate::lower::model::Ex::XCall(k_name.clone(), Array::from(vec![pack.clone()])))
    };
    let branch_fn = {
        let lx = lx.clone();
        let env = env.clone();
        let to_k_fn = to_k_fn.clone();
        Rc::new(move |p0: crate::syntax::Block| {
            let lx = lx.clone();
            let env = env.clone();
            let to_k_fn = to_k_fn.clone();
            entered(once_job(move || {
                let b = p0;
                prism_rtl::Turn::More(Rc::new(UpdTailFrom { lx: lx.clone(), outer: env.clone(), env: env.clone(), b: b.clone(), i: Nat::from(0u32), to: b.span.clone(), cont_fn: {
                    let f = to_k_fn.clone();
                    Rc::new(move |(a0, a1): (crate::lower::types::Env, crate::lower::model::Ex)| {
                        let f = f.clone();
                        once_job(move || prism_rtl::Turn::Finished(f(&a0, &a1)))
                    }) as Rc<dyn Fn((crate::lower::types::Env, crate::lower::model::Ex)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
                } }))
            }))
        }) as Rc<dyn Fn(crate::syntax::Block) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
    };
    let else_x = match else_b_opt {
        Some(eb) => run_to_end((&branch_fn)(eb.clone())),
        None => crate::lower::model::Ex::XCall(k_name.clone(), Array::from(vec![pack.clone()])),
    };
    let choose = match c {
        crate::syntax::Cond::CondExpr(x) => crate::lower::model::Ex::XIf(Rc::new(crate::lower::types::as_bool(&crate::lower::expr::value_of(lx, env, &**x))), Rc::new(run_to_end((&branch_fn)(then_b.clone()))), Rc::new(else_x.clone())),
        crate::syntax::Cond::CondBind(p_, x, _) => {
            let po = crate::lower::patterns::rust_pat(lx, p_, &crate::lower::type_at(lx, &x.span), &crate::lower::types::Holding::Owned, &Text::from(format!("u{}", &x.span.start)));
            let then_x = upd_tail_from(lx, &crate::lower::expr::bind_all(env, &po.binds), &crate::lower::expr::bind_all(env, &po.binds), then_b, &Nat::from(0u32), &then_b.span, &{
                let f = to_k_fn.clone();
                Rc::new(move |(a0, a1): (crate::lower::types::Env, crate::lower::model::Ex)| {
                    let f = f.clone();
                    once_job(move || prism_rtl::Turn::Finished(f(&a0, &a1)))
                }) as Rc<dyn Fn((crate::lower::types::Env, crate::lower::model::Ex)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
            });
            crate::lower::types::own(&crate::lower::expr::arms_value(&crate::lower::types::own(&crate::lower::expr::value_of(lx, env, &**x)), &Array::from(vec![crate::lower::model::XArm { pat: po.pa.clone(), conds: po.conds.clone(), body: then_x.clone() }, crate::lower::model::XArm { pat: crate::lower::model::Pa::PaWild, conds: Array::new(), body: else_x.clone() }]), &Text::from(format!("'u{}", &x.span.start)), &crate::lower::model::OutTy::OutUnknown(Text::lit("the job's turn"))))
        },
    };
    prepend(&push(&out_dos, &k_do), &choose)
}

/// The step machine of `IfJob`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// IfJob: unbounded fn Lx, Env, Env, Cond, Block, ?Block, Range, Text, (unbounded fn Env, Env -> Ex) -> Ex
/// ```
pub struct IfJob {
    pub lx: crate::lower::Lx,
    pub outer: crate::lower::types::Env,
    pub env: crate::lower::types::Env,
    pub c: crate::syntax::Cond,
    pub then_b: crate::syntax::Block,
    pub else_b_opt: Option<crate::syntax::Block>,
    pub span: crate::syntax::Range,
    pub rest_text_: Text,
    pub cont_fn: Rc<dyn Fn((crate::lower::types::Env, crate::lower::types::Env)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>,
}

impl prism_rtl::Job<crate::lower::model::Ex> for IfJob {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::Ex> {
        let lx = &self.lx;
        let outer = &self.outer;
        let env = &self.env;
        let c = &self.c;
        let then_b = &self.then_b;
        let else_b_opt = &self.else_b_opt;
        let span = &self.span;
        let rest_text_ = &self.rest_text_;
        let cont_fn = &self.cont_fn;
        let state = fold(&keys(&env.names), &Array::new(), &(|acc: &Array<(Text, Text, crate::lower::model::OutTy)>, k: &Text| if !crate::syntax::lexer::chars::has_prefix(k, &Text::lit("&")) {
            acc.clone()
        } else {
            match get(&env.names, k) {
                Some(crate::lower::types::Bn::BnLocal(rs, _, bt)) => push(acc, &(k.clone(), crate::lower::types::place_stem(&rs), bt.clone())),
                _ => acc.clone(),
            }
        }));
        let names = each(&state, &(|(_, rs, _): &(Text, Text, crate::lower::model::OutTy)| rs.clone()));
        let st_ty = crate::lower::model::OutTy::OutTuple(each(&state, &(|(_, _, bt): &(Text, Text, crate::lower::model::OutTy)| bt.clone())));
        let pat = crate::lower::model::Pa::PaTuple(each(&names, &(|n: &Text| crate::lower::model::Pa::PaMut(Text::from(format!("{}", n))))));
        let pack = crate::lower::model::Ex::XTuple(each(&names, &(|n: &Text| crate::lower::model::Ex::XVar(n.clone()))));
        let env_s = fold(&state, env, &(|en: &crate::lower::types::Env, (k, rs, bt): &(Text, Text, crate::lower::model::OutTy)| crate::lower::types::bind(en, k, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(rs.clone()), crate::lower::types::Holding::Owned, bt.clone()))));
        let out_caps = caps_in(outer, rest_text_, &names);
        let out_dos = each(&out_caps, &(|(_, rs, mode, bt): &(Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)| crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::lower::types::place_stem(rs)), crate::lower::types::own(&crate::lower::types::Vl::VlPlace(rs.clone(), mode.clone(), bt.clone())))));
        let outer2 = fold(&out_caps, outer, &(|en: &crate::lower::types::Env, (k, rs, _, bt): &(Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)| crate::lower::types::bind(en, k, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(crate::lower::types::place_stem(rs)), crate::lower::types::Holding::Owned, bt.clone()))));
        let env2 = fold(&out_caps, &env_s, &(|en: &crate::lower::types::Env, (k, rs, _, bt): &(Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)| crate::lower::types::bind(en, k, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(crate::lower::types::place_stem(rs)), crate::lower::types::Holding::Owned, bt.clone()))));
        let k_name = Text::from(format!("k_if{}", &span.start));
        let else_b_opt = else_b_opt.clone();
        let cont_fn = cont_fn.clone();
        let c = c.clone();
        let env = env.clone();
        let lx = lx.clone();
        let span = span.clone();
        let then_b = then_b.clone();
        call_value((&cont_fn)((outer2.clone(), env2.clone())), move |cont_15137: crate::lower::model::Ex| {
            let k_do = crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(k_name.clone()), crate::lower::model::Ex::XClosure(true, Array::from(vec![crate::lower::model::Pa::PaTyped(Rc::new(pat.clone()), st_ty.clone())]), Rc::new(cont_15137)));
            let to_k_fn = {
                let k_name = k_name.clone();
                let pack = pack.clone();
                Rc::new(move |o2: &crate::lower::types::Env, e2: &crate::lower::model::Ex| crate::lower::model::Ex::XCall(k_name.clone(), Array::from(vec![pack.clone()])))
            };
            let branch_fn = {
                let lx = lx.clone();
                let env = env.clone();
                let to_k_fn = to_k_fn.clone();
                Rc::new(move |p0: crate::syntax::Block| {
                    let lx = lx.clone();
                    let env = env.clone();
                    let to_k_fn = to_k_fn.clone();
                    entered(once_job(move || {
                        let b = p0;
                        prism_rtl::Turn::More(Rc::new(UpdTailFrom { lx: lx.clone(), outer: env.clone(), env: env.clone(), b: b.clone(), i: Nat::from(0u32), to: b.span.clone(), cont_fn: {
                            let f = to_k_fn.clone();
                            Rc::new(move |(a0, a1): (crate::lower::types::Env, crate::lower::model::Ex)| {
                                let f = f.clone();
                                once_job(move || prism_rtl::Turn::Finished(f(&a0, &a1)))
                            }) as Rc<dyn Fn((crate::lower::types::Env, crate::lower::model::Ex)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
                        } }))
                    }))
                }) as Rc<dyn Fn(crate::syntax::Block) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
            };
            let else_x = match &else_b_opt {
                Some(eb) => run_to_end((&branch_fn)(eb.clone())),
                None => crate::lower::model::Ex::XCall(k_name.clone(), Array::from(vec![pack.clone()])),
            };
            let choose = match &c {
                crate::syntax::Cond::CondExpr(x) => crate::lower::model::Ex::XIf(Rc::new(crate::lower::types::as_bool(&crate::lower::expr::value_of(&lx, &env, &**x))), Rc::new(run_to_end((&branch_fn)(then_b.clone()))), Rc::new(else_x.clone())),
                crate::syntax::Cond::CondBind(p_, x, _) => {
                    let po = crate::lower::patterns::rust_pat(&lx, p_, &crate::lower::type_at(&lx, &x.span), &crate::lower::types::Holding::Owned, &Text::from(format!("u{}", &x.span.start)));
                    let then_x = upd_tail_from(&lx, &crate::lower::expr::bind_all(&env, &po.binds), &crate::lower::expr::bind_all(&env, &po.binds), &then_b, &Nat::from(0u32), &then_b.span, &{
                        let f = to_k_fn.clone();
                        Rc::new(move |(a0, a1): (crate::lower::types::Env, crate::lower::model::Ex)| {
                            let f = f.clone();
                            once_job(move || prism_rtl::Turn::Finished(f(&a0, &a1)))
                        }) as Rc<dyn Fn((crate::lower::types::Env, crate::lower::model::Ex)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
                    });
                    crate::lower::types::own(&crate::lower::expr::arms_value(&crate::lower::types::own(&crate::lower::expr::value_of(&lx, &env, &**x)), &Array::from(vec![crate::lower::model::XArm { pat: po.pa.clone(), conds: po.conds.clone(), body: then_x.clone() }, crate::lower::model::XArm { pat: crate::lower::model::Pa::PaWild, conds: Array::new(), body: else_x.clone() }]), &Text::from(format!("'u{}", &x.span.start)), &crate::lower::model::OutTy::OutUnknown(Text::lit("the job's turn"))))
                },
            };
            prism_rtl::Turn::Finished(prepend(&push(&out_dos, &k_do), &choose))
        })
    }
}

/// `Start IfJob, x`: what the function value is when passed to `@Run`.
pub fn start_if_job(lx: crate::lower::Lx, outer: crate::lower::types::Env, env: crate::lower::types::Env, c: crate::syntax::Cond, then_b: crate::syntax::Block, else_b_opt: Option<crate::syntax::Block>, span: crate::syntax::Range, rest_text_: Text, cont_fn: Rc<dyn Fn((crate::lower::types::Env, crate::lower::types::Env)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>> {
    Rc::new(IfJob { lx, outer, env, c, then_b, else_b_opt, span, rest_text_, cont_fn })
}

/// ```prism
/// MatchJob: unbounded fn Lx, Env, Env, Expr, [Arm], Range, Text, (unbounded fn Env, Env -> Ex) -> Ex
/// ```
pub fn match_job(lx: &crate::lower::Lx, outer: &crate::lower::types::Env, env: &crate::lower::types::Env, scrut: &crate::syntax::Expr, arms: &Array<crate::syntax::Arm>, span: &crate::syntax::Range, rest_text_: &Text, cont_fn: &Rc<dyn Fn((crate::lower::types::Env, crate::lower::types::Env)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>) -> crate::lower::model::Ex {
    let state = fold(&keys(&env.names), &Array::new(), &(|acc: &Array<(Text, Text, crate::lower::model::OutTy)>, k: &Text| if !crate::syntax::lexer::chars::has_prefix(k, &Text::lit("&")) {
        acc.clone()
    } else {
        match get(&env.names, k) {
            Some(crate::lower::types::Bn::BnLocal(rs, _, bt)) => push(acc, &(k.clone(), crate::lower::types::place_stem(&rs), bt.clone())),
            _ => acc.clone(),
        }
    }));
    let names = each(&state, &(|(_, rs, _): &(Text, Text, crate::lower::model::OutTy)| rs.clone()));
    let st_ty = crate::lower::model::OutTy::OutTuple(each(&state, &(|(_, _, bt): &(Text, Text, crate::lower::model::OutTy)| bt.clone())));
    let pat = crate::lower::model::Pa::PaTuple(each(&names, &(|n: &Text| crate::lower::model::Pa::PaMut(Text::from(format!("{}", n))))));
    let pack = crate::lower::model::Ex::XTuple(each(&names, &(|n: &Text| crate::lower::model::Ex::XVar(n.clone()))));
    let env_s = fold(&state, env, &(|en: &crate::lower::types::Env, (k, rs, bt): &(Text, Text, crate::lower::model::OutTy)| crate::lower::types::bind(en, k, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(rs.clone()), crate::lower::types::Holding::Owned, bt.clone()))));
    let out_caps = caps_in(outer, rest_text_, &names);
    let out_dos = each(&out_caps, &(|(_, rs, mode, bt): &(Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)| crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::lower::types::place_stem(rs)), crate::lower::types::own(&crate::lower::types::Vl::VlPlace(rs.clone(), mode.clone(), bt.clone())))));
    let outer2 = fold(&out_caps, outer, &(|en: &crate::lower::types::Env, (k, rs, _, bt): &(Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)| crate::lower::types::bind(en, k, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(crate::lower::types::place_stem(rs)), crate::lower::types::Holding::Owned, bt.clone()))));
    let env2 = fold(&out_caps, &env_s, &(|en: &crate::lower::types::Env, (k, rs, _, bt): &(Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)| crate::lower::types::bind(en, k, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(crate::lower::types::place_stem(rs)), crate::lower::types::Holding::Owned, bt.clone()))));
    let k_name = Text::from(format!("k_match{}", &span.start));
    let k_do = crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(k_name.clone()), crate::lower::model::Ex::XClosure(true, Array::from(vec![crate::lower::model::Pa::PaTyped(Rc::new(pat.clone()), st_ty.clone())]), Rc::new(run_to_end(cont_fn((outer2.clone(), env2.clone()))))));
    let to_k_fn = {
        let k_name = k_name.clone();
        let pack = pack.clone();
        Rc::new(move |o2: &crate::lower::types::Env, e2: &crate::lower::model::Ex| crate::lower::model::Ex::XCall(k_name.clone(), Array::from(vec![pack.clone()])))
    };
    let sty = crate::lower::type_at(lx, &scrut.span);
    let xarms = run_to_end(each_job(crate::check::errors::range0(&len(arms)), {
        let arms = arms.clone();
        let lx = lx.clone();
        let sty = sty.clone();
        let scrut = scrut.clone();
        let env = env.clone();
        let to_k_fn = to_k_fn.clone();
        Rc::new(move |p0: Nat| {
            let arms = arms.clone();
            let lx = lx.clone();
            let sty = sty.clone();
            let scrut = scrut.clone();
            let env = env.clone();
            let to_k_fn = to_k_fn.clone();
            entered(once_job(move || {
                let i = p0;
                {
                    let arm = or(&index(&arms, &i), &crate::lower::expr::dummy_arm());
                    call_then(crate::lower::expr::start_arm_pat(lx.clone(), arm.pattern.clone(), sty.clone(), crate::lower::types::Holding::Owned, Text::from(format!("u{}_{}", &scrut.span.start, &i))), move |arm_pat_17704: crate::lower::patterns::PatOut| {
                        let po = arm_pat_17704;
                        let env_a = crate::lower::expr::bind_all(&env, &po.binds);
                        call_then(crate::lower::templates::start_guard_conds(lx.clone(), env_a.clone(), arm.guard.clone()), move |guard_conds_17848: Array<crate::lower::model::Cc>| {
                            let guarded = append(&po.conds, &guard_conds_17848);
                            call_then(start_upd_tail_from(lx.clone(), env_a.clone(), env_a.clone(), arm.body.clone(), Nat::from(0u32), arm.body.span.clone(), {
                                let f = to_k_fn.clone();
                                Rc::new(move |(a0, a1): (crate::lower::types::Env, crate::lower::model::Ex)| {
                                    let f = f.clone();
                                    once_job(move || prism_rtl::Turn::Finished(f(&a0, &a1)))
                                }) as Rc<dyn Fn((crate::lower::types::Env, crate::lower::model::Ex)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
                            }), move |upd_tail_from_17926: crate::lower::model::Ex| prism_rtl::Turn::Finished(crate::lower::model::XArm { pat: po.pa.clone(), conds: guarded.clone(), body: upd_tail_from_17926 }))
                        })
                    })
                }
            }))
        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<crate::lower::model::XArm>>>
    }));
    prepend(&push(&out_dos, &k_do), &crate::lower::types::own(&crate::lower::expr::arms_value(&crate::lower::types::own(&crate::lower::expr::value_of(lx, env, scrut)), &xarms, &Text::from(format!("'u{}", &scrut.span.start)), &crate::lower::model::OutTy::OutUnknown(Text::lit("the job's turn")))))
}

/// The step machine of `MatchJob`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// MatchJob: unbounded fn Lx, Env, Env, Expr, [Arm], Range, Text, (unbounded fn Env, Env -> Ex) -> Ex
/// ```
pub struct MatchJob {
    pub lx: crate::lower::Lx,
    pub outer: crate::lower::types::Env,
    pub env: crate::lower::types::Env,
    pub scrut: crate::syntax::Expr,
    pub arms: Array<crate::syntax::Arm>,
    pub span: crate::syntax::Range,
    pub rest_text_: Text,
    pub cont_fn: Rc<dyn Fn((crate::lower::types::Env, crate::lower::types::Env)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>,
}

impl prism_rtl::Job<crate::lower::model::Ex> for MatchJob {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::Ex> {
        let lx = &self.lx;
        let outer = &self.outer;
        let env = &self.env;
        let scrut = &self.scrut;
        let arms = &self.arms;
        let span = &self.span;
        let rest_text_ = &self.rest_text_;
        let cont_fn = &self.cont_fn;
        let state = fold(&keys(&env.names), &Array::new(), &(|acc: &Array<(Text, Text, crate::lower::model::OutTy)>, k: &Text| if !crate::syntax::lexer::chars::has_prefix(k, &Text::lit("&")) {
            acc.clone()
        } else {
            match get(&env.names, k) {
                Some(crate::lower::types::Bn::BnLocal(rs, _, bt)) => push(acc, &(k.clone(), crate::lower::types::place_stem(&rs), bt.clone())),
                _ => acc.clone(),
            }
        }));
        let names = each(&state, &(|(_, rs, _): &(Text, Text, crate::lower::model::OutTy)| rs.clone()));
        let st_ty = crate::lower::model::OutTy::OutTuple(each(&state, &(|(_, _, bt): &(Text, Text, crate::lower::model::OutTy)| bt.clone())));
        let pat = crate::lower::model::Pa::PaTuple(each(&names, &(|n: &Text| crate::lower::model::Pa::PaMut(Text::from(format!("{}", n))))));
        let pack = crate::lower::model::Ex::XTuple(each(&names, &(|n: &Text| crate::lower::model::Ex::XVar(n.clone()))));
        let env_s = fold(&state, env, &(|en: &crate::lower::types::Env, (k, rs, bt): &(Text, Text, crate::lower::model::OutTy)| crate::lower::types::bind(en, k, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(rs.clone()), crate::lower::types::Holding::Owned, bt.clone()))));
        let out_caps = caps_in(outer, rest_text_, &names);
        let out_dos = each(&out_caps, &(|(_, rs, mode, bt): &(Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)| crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::lower::types::place_stem(rs)), crate::lower::types::own(&crate::lower::types::Vl::VlPlace(rs.clone(), mode.clone(), bt.clone())))));
        let outer2 = fold(&out_caps, outer, &(|en: &crate::lower::types::Env, (k, rs, _, bt): &(Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)| crate::lower::types::bind(en, k, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(crate::lower::types::place_stem(rs)), crate::lower::types::Holding::Owned, bt.clone()))));
        let env2 = fold(&out_caps, &env_s, &(|en: &crate::lower::types::Env, (k, rs, _, bt): &(Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)| crate::lower::types::bind(en, k, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(crate::lower::types::place_stem(rs)), crate::lower::types::Holding::Owned, bt.clone()))));
        let k_name = Text::from(format!("k_match{}", &span.start));
        let cont_fn = cont_fn.clone();
        let arms = arms.clone();
        let env = env.clone();
        let lx = lx.clone();
        let scrut = scrut.clone();
        let span = span.clone();
        call_value((&cont_fn)((outer2.clone(), env2.clone())), move |cont_17499: crate::lower::model::Ex| {
            let k_do = crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(k_name.clone()), crate::lower::model::Ex::XClosure(true, Array::from(vec![crate::lower::model::Pa::PaTyped(Rc::new(pat.clone()), st_ty.clone())]), Rc::new(cont_17499)));
            let to_k_fn = {
                let k_name = k_name.clone();
                let pack = pack.clone();
                Rc::new(move |o2: &crate::lower::types::Env, e2: &crate::lower::model::Ex| crate::lower::model::Ex::XCall(k_name.clone(), Array::from(vec![pack.clone()])))
            };
            let sty = crate::lower::type_at(&lx, &scrut.span);
            call_value(each_job(crate::check::errors::range0(&len(&arms)), {
                let arms = arms.clone();
                let lx = lx.clone();
                let sty = sty.clone();
                let scrut = scrut.clone();
                let env = env.clone();
                let to_k_fn = to_k_fn.clone();
                Rc::new(move |p0: Nat| {
                    let arms = arms.clone();
                    let lx = lx.clone();
                    let sty = sty.clone();
                    let scrut = scrut.clone();
                    let env = env.clone();
                    let to_k_fn = to_k_fn.clone();
                    entered(once_job(move || {
                        let i = p0;
                        {
                            let arm = or(&index(&arms, &i), &crate::lower::expr::dummy_arm());
                            call_then(crate::lower::expr::start_arm_pat(lx.clone(), arm.pattern.clone(), sty.clone(), crate::lower::types::Holding::Owned, Text::from(format!("u{}_{}", &scrut.span.start, &i))), move |arm_pat_17704: crate::lower::patterns::PatOut| {
                                let po = arm_pat_17704;
                                let env_a = crate::lower::expr::bind_all(&env, &po.binds);
                                call_then(crate::lower::templates::start_guard_conds(lx.clone(), env_a.clone(), arm.guard.clone()), move |guard_conds_17848: Array<crate::lower::model::Cc>| {
                                    let guarded = append(&po.conds, &guard_conds_17848);
                                    call_then(start_upd_tail_from(lx.clone(), env_a.clone(), env_a.clone(), arm.body.clone(), Nat::from(0u32), arm.body.span.clone(), {
                                        let f = to_k_fn.clone();
                                        Rc::new(move |(a0, a1): (crate::lower::types::Env, crate::lower::model::Ex)| {
                                            let f = f.clone();
                                            once_job(move || prism_rtl::Turn::Finished(f(&a0, &a1)))
                                        }) as Rc<dyn Fn((crate::lower::types::Env, crate::lower::model::Ex)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
                                    }), move |upd_tail_from_17926: crate::lower::model::Ex| prism_rtl::Turn::Finished(crate::lower::model::XArm { pat: po.pa.clone(), conds: guarded.clone(), body: upd_tail_from_17926 }))
                                })
                            })
                        }
                    }))
                }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<crate::lower::model::XArm>>>
            }), move |each_17617: Array<crate::lower::model::XArm>| {
                let xarms = each_17617;
                call_then(crate::lower::expr::start_value_of(lx.clone(), env.clone(), scrut.clone()), move |value_of_18042: crate::lower::types::Vl| prism_rtl::Turn::Finished(prepend(&push(&out_dos, &k_do), &crate::lower::types::own(&crate::lower::expr::arms_value(&crate::lower::types::own(&value_of_18042), &xarms, &Text::from(format!("'u{}", &scrut.span.start)), &crate::lower::model::OutTy::OutUnknown(Text::lit("the job's turn")))))))
            })
        })
    }
}

/// `Start MatchJob, x`: what the function value is when passed to `@Run`.
pub fn start_match_job(lx: crate::lower::Lx, outer: crate::lower::types::Env, env: crate::lower::types::Env, scrut: crate::syntax::Expr, arms: Array<crate::syntax::Arm>, span: crate::syntax::Range, rest_text_: Text, cont_fn: Rc<dyn Fn((crate::lower::types::Env, crate::lower::types::Env)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>> {
    Rc::new(MatchJob { lx, outer, env, scrut, arms, span, rest_text_, cont_fn })
}

/// ```prism
/// ForJob: unbounded fn Lx, Env, Env, ?ForBinders, Expr, Block, Range, Text, (unbounded fn Env, Env -> Ex) -> Ex
/// ```
pub fn for_job(lx: &crate::lower::Lx, outer: &crate::lower::types::Env, env: &crate::lower::types::Env, binders_opt: &Option<crate::syntax::ForBinders>, source: &crate::syntax::Expr, body: &crate::syntax::Block, span: &crate::syntax::Range, rest_text_: &Text, cont_fn: &Rc<dyn Fn((crate::lower::types::Env, crate::lower::types::Env)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>) -> crate::lower::model::Ex {
    let state = fold(&keys(&env.names), &Array::new(), &(|acc: &Array<(Text, Text, crate::lower::model::OutTy)>, k: &Text| if !crate::syntax::lexer::chars::has_prefix(k, &Text::lit("&")) {
        acc.clone()
    } else {
        match get(&env.names, k) {
            Some(crate::lower::types::Bn::BnLocal(rs, _, bt)) => push(acc, &(k.clone(), crate::lower::types::place_stem(&rs), bt.clone())),
            _ => acc.clone(),
        }
    }));
    let names = each(&state, &(|(_, rs, _): &(Text, Text, crate::lower::model::OutTy)| rs.clone()));
    let st_ty = crate::lower::model::OutTy::OutTuple(each(&state, &(|(_, _, bt): &(Text, Text, crate::lower::model::OutTy)| bt.clone())));
    let pat = crate::lower::model::Pa::PaTuple(each(&names, &(|n: &Text| crate::lower::model::Pa::PaMut(Text::from(format!("{}", n))))));
    let pack = crate::lower::model::Ex::XTuple(each(&names, &(|n: &Text| crate::lower::model::Ex::XVar(n.clone()))));
    let env_s = fold(&state, env, &(|en: &crate::lower::types::Env, (k, rs, bt): &(Text, Text, crate::lower::model::OutTy)| crate::lower::types::bind(en, k, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(rs.clone()), crate::lower::types::Holding::Owned, bt.clone()))));
    let src = crate::lower::types::own(&crate::lower::expr::value_of(lx, env, source));
    let sty = crate::lower::types::peel(&crate::lower::type_at(lx, &source.span));
    let (kt, vt, is_array) = match &sty {
        crate::check::types::Ty::TyArray(v_) => (crate::lower::model::OutTy::OutNat, crate::lower::types::out_ty_of(lx, &**v_), true),
        crate::check::types::Ty::TyMap(k, v_) => (crate::lower::types::out_ty_of(lx, &**k), crate::lower::types::out_ty_of(lx, &**v_), false),
        _ => (crate::lower::model::OutTy::OutUnit, crate::lower::model::OutTy::OutUnit, true),
    };
    let (vty, kty) = match &sty {
        crate::check::types::Ty::TyArray(v_) => ((**v_).clone(), crate::check::types::Ty::TyCon(Text::lit("Nat"), Array::new())),
        crate::check::types::Ty::TyMap(k, v_) => ((**v_).clone(), (**k).clone()),
        _ => (crate::check::types::Ty::TyErr, crate::check::types::Ty::TyErr),
    };
    let key_name = Text::from(format!("k{}", &span.start));
    let val_name = Text::from(format!("v{}", &span.start));
    let loop_text = match index(&lx.g.srcs, &lx.file) {
        Some(src2) => crate::check::errors::span_text(&src2, span),
        None => Text::lit(""),
    };
    let caps = caps_in(&env_s, &loop_text, &names);
    let cap_dos = each(&caps, &(|(_, rs, mode, bt): &(Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)| crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::lower::types::place_stem(rs)), crate::lower::types::own(&crate::lower::types::Vl::VlPlace(rs.clone(), mode.clone(), bt.clone())))));
    let env_c = fold(&caps, &env_s, &(|en: &crate::lower::types::Env, (k, rs, _, bt): &(Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)| crate::lower::types::bind(en, k, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(crate::lower::types::place_stem(rs)), crate::lower::types::Holding::Owned, bt.clone()))));
    let env1 = crate::lower::types::bind(&crate::lower::types::bind(&env_c, &Text::lit("key"), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(key_name.clone()), crate::lower::types::Holding::Owned, kt.clone())), &Text::lit("_"), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(val_name.clone()), crate::lower::types::Holding::Owned, vt.clone()));
    let env_k = if is_array {
        crate::lower::types::bind(&env1, &Text::lit("ix"), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(key_name.clone()), crate::lower::types::Holding::Owned, kt.clone()))
    } else {
        env1.clone()
    };
    let (binds, env_b) = match binders_opt {
        None => (Array::new(), env_k.clone()),
        Some(fb) => match &fb.second {
            None => {
                let po = crate::lower::patterns::rust_pat(lx, &fb.first, &vty, &crate::lower::types::Holding::Owned, &Text::from(format!("e{}", &span.start)));
                (Array::from(vec![crate::lower::model::Do::DoLet(po.pa.clone(), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(val_name.clone()))))]), crate::lower::expr::bind_all(&env_k, &po.binds))
            },
            Some(second) => {
                let pk = crate::lower::patterns::rust_pat(lx, &fb.first, &kty, &crate::lower::types::Holding::Owned, &Text::from(format!("k{}_", &span.start)));
                let pv = crate::lower::patterns::rust_pat(lx, second, &vty, &crate::lower::types::Holding::Owned, &Text::from(format!("e{}", &span.start)));
                (Array::from(vec![crate::lower::model::Do::DoLet(pk.pa.clone(), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(key_name.clone())))), crate::lower::model::Do::DoLet(pv.pa.clone(), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(val_name.clone()))))]), crate::lower::expr::bind_all(&crate::lower::expr::bind_all(&env_k, &pk.binds), &pv.binds))
            },
        },
    };
    let turn = prepend(&binds, &upd_tail_from(lx, &env_b, &env_b, body, &Nat::from(0u32), &body.span, &{
        let pack = pack.clone();
        Rc::new(move |(p0, p1): (crate::lower::types::Env, crate::lower::model::Ex)| {
            let pack = pack.clone();
            once_job(move || {
                let o2 = p0;
                let e2 = p1;
                prism_rtl::Turn::Finished(crate::lower::model::Ex::XCtor(Text::lit("prism_rtl::Turn::Finished"), Array::from(vec![pack.clone()])))
            })
        }) as Rc<dyn Fn((crate::lower::types::Env, crate::lower::model::Ex)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
    }));
    let step_fn = prepend(&cap_dos, &crate::lower::model::Ex::XClosure(true, Array::from(vec![crate::lower::model::Pa::PaTyped(Rc::new(pat.clone()), st_ty.clone()), crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaBind(key_name.clone())), kt.clone()), crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaBind(val_name.clone())), vt.clone())]), Rc::new(turn.clone())));
    let out_caps = caps_in(outer, rest_text_, &names);
    let out_dos = each(&out_caps, &(|(_, rs, mode, bt): &(Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)| crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::lower::types::place_stem(rs)), crate::lower::types::own(&crate::lower::types::Vl::VlPlace(rs.clone(), mode.clone(), bt.clone())))));
    let outer2 = fold(&out_caps, outer, &(|en: &crate::lower::types::Env, (k, rs, _, bt): &(Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)| crate::lower::types::bind(en, k, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(crate::lower::types::place_stem(rs)), crate::lower::types::Holding::Owned, bt.clone()))));
    let env2 = fold(&out_caps, &env_s, &(|en: &crate::lower::types::Env, (k, rs, _, bt): &(Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)| crate::lower::types::bind(en, k, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(crate::lower::types::place_stem(rs)), crate::lower::types::Holding::Owned, bt.clone()))));
    let looping = if is_array { Text::lit("for_turns_indexed") } else { Text::lit("for_turns_keyed") };
    let enter = crate::lower::model::Ex::XCall(Text::lit("call_then"), Array::from(vec![crate::lower::model::Ex::XCall(looping.clone(), Array::from(vec![src.clone(), pack.clone(), step_fn.clone()])), crate::lower::model::Ex::XClosure(true, Array::from(vec![crate::lower::model::Pa::PaTyped(Rc::new(pat.clone()), st_ty.clone())]), Rc::new(run_to_end(cont_fn((outer2.clone(), env2.clone())))))]));
    prepend(&out_dos, &enter)
}

/// The step machine of `ForJob`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ForJob: unbounded fn Lx, Env, Env, ?ForBinders, Expr, Block, Range, Text, (unbounded fn Env, Env -> Ex) -> Ex
/// ```
pub struct ForJob {
    pub lx: crate::lower::Lx,
    pub outer: crate::lower::types::Env,
    pub env: crate::lower::types::Env,
    pub binders_opt: Option<crate::syntax::ForBinders>,
    pub source: crate::syntax::Expr,
    pub body: crate::syntax::Block,
    pub span: crate::syntax::Range,
    pub rest_text_: Text,
    pub cont_fn: Rc<dyn Fn((crate::lower::types::Env, crate::lower::types::Env)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>,
}

impl prism_rtl::Job<crate::lower::model::Ex> for ForJob {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::Ex> {
        let lx = &self.lx;
        let outer = &self.outer;
        let env = &self.env;
        let binders_opt = &self.binders_opt;
        let source = &self.source;
        let body = &self.body;
        let span = &self.span;
        let rest_text_ = &self.rest_text_;
        let cont_fn = &self.cont_fn;
        let state = fold(&keys(&env.names), &Array::new(), &(|acc: &Array<(Text, Text, crate::lower::model::OutTy)>, k: &Text| if !crate::syntax::lexer::chars::has_prefix(k, &Text::lit("&")) {
            acc.clone()
        } else {
            match get(&env.names, k) {
                Some(crate::lower::types::Bn::BnLocal(rs, _, bt)) => push(acc, &(k.clone(), crate::lower::types::place_stem(&rs), bt.clone())),
                _ => acc.clone(),
            }
        }));
        let names = each(&state, &(|(_, rs, _): &(Text, Text, crate::lower::model::OutTy)| rs.clone()));
        let st_ty = crate::lower::model::OutTy::OutTuple(each(&state, &(|(_, _, bt): &(Text, Text, crate::lower::model::OutTy)| bt.clone())));
        let pat = crate::lower::model::Pa::PaTuple(each(&names, &(|n: &Text| crate::lower::model::Pa::PaMut(Text::from(format!("{}", n))))));
        let pack = crate::lower::model::Ex::XTuple(each(&names, &(|n: &Text| crate::lower::model::Ex::XVar(n.clone()))));
        let env_s = fold(&state, env, &(|en: &crate::lower::types::Env, (k, rs, bt): &(Text, Text, crate::lower::model::OutTy)| crate::lower::types::bind(en, k, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(rs.clone()), crate::lower::types::Holding::Owned, bt.clone()))));
        let binders_opt = binders_opt.clone();
        let cont_fn = cont_fn.clone();
        let body = body.clone();
        let env = env.clone();
        let lx = lx.clone();
        let outer = outer.clone();
        let rest_text_ = rest_text_.clone();
        let source = source.clone();
        let span = span.clone();
        call_then(crate::lower::expr::start_value_of(lx.clone(), env.clone(), source.clone()), move |value_of_19279: crate::lower::types::Vl| {
            let src = crate::lower::types::own(&value_of_19279);
            let sty = crate::lower::types::peel(&crate::lower::type_at(&lx, &source.span));
            let (kt, vt, is_array) = match &sty {
                crate::check::types::Ty::TyArray(v_) => (crate::lower::model::OutTy::OutNat, crate::lower::types::out_ty_of(&lx, &**v_), true),
                crate::check::types::Ty::TyMap(k, v_) => (crate::lower::types::out_ty_of(&lx, &**k), crate::lower::types::out_ty_of(&lx, &**v_), false),
                _ => (crate::lower::model::OutTy::OutUnit, crate::lower::model::OutTy::OutUnit, true),
            };
            let (vty, kty) = match &sty {
                crate::check::types::Ty::TyArray(v_) => ((**v_).clone(), crate::check::types::Ty::TyCon(Text::lit("Nat"), Array::new())),
                crate::check::types::Ty::TyMap(k, v_) => ((**v_).clone(), (**k).clone()),
                _ => (crate::check::types::Ty::TyErr, crate::check::types::Ty::TyErr),
            };
            let key_name = Text::from(format!("k{}", &span.start));
            let val_name = Text::from(format!("v{}", &span.start));
            let loop_text = match index(&lx.g.srcs, &lx.file) {
                Some(src2) => crate::check::errors::span_text(&src2, &span),
                None => Text::lit(""),
            };
            let caps = caps_in(&env_s, &loop_text, &names);
            let cap_dos = each(&caps, &(|(_, rs, mode, bt): &(Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)| crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::lower::types::place_stem(rs)), crate::lower::types::own(&crate::lower::types::Vl::VlPlace(rs.clone(), mode.clone(), bt.clone())))));
            let env_c = fold(&caps, &env_s, &(|en: &crate::lower::types::Env, (k, rs, _, bt): &(Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)| crate::lower::types::bind(en, k, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(crate::lower::types::place_stem(rs)), crate::lower::types::Holding::Owned, bt.clone()))));
            let env1 = crate::lower::types::bind(&crate::lower::types::bind(&env_c, &Text::lit("key"), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(key_name.clone()), crate::lower::types::Holding::Owned, kt.clone())), &Text::lit("_"), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(val_name.clone()), crate::lower::types::Holding::Owned, vt.clone()));
            let env_k = if is_array {
                crate::lower::types::bind(&env1, &Text::lit("ix"), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(key_name.clone()), crate::lower::types::Holding::Owned, kt.clone()))
            } else {
                env1.clone()
            };
            let (binds, env_b) = match &binders_opt {
                None => (Array::new(), env_k.clone()),
                Some(fb) => match &fb.second {
                    None => {
                        let po = crate::lower::patterns::rust_pat(&lx, &fb.first, &vty, &crate::lower::types::Holding::Owned, &Text::from(format!("e{}", &span.start)));
                        (Array::from(vec![crate::lower::model::Do::DoLet(po.pa.clone(), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(val_name.clone()))))]), crate::lower::expr::bind_all(&env_k, &po.binds))
                    },
                    Some(second) => {
                        let pk = crate::lower::patterns::rust_pat(&lx, &fb.first, &kty, &crate::lower::types::Holding::Owned, &Text::from(format!("k{}_", &span.start)));
                        let pv = crate::lower::patterns::rust_pat(&lx, second, &vty, &crate::lower::types::Holding::Owned, &Text::from(format!("e{}", &span.start)));
                        (Array::from(vec![crate::lower::model::Do::DoLet(pk.pa.clone(), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(key_name.clone())))), crate::lower::model::Do::DoLet(pv.pa.clone(), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(val_name.clone()))))]), crate::lower::expr::bind_all(&crate::lower::expr::bind_all(&env_k, &pk.binds), &pv.binds))
                    },
                },
            };
            call_then(start_upd_tail_from(lx.clone(), env_b.clone(), env_b.clone(), body.clone(), Nat::from(0u32), body.span.clone(), {
                let pack = pack.clone();
                Rc::new(move |(p0, p1): (crate::lower::types::Env, crate::lower::model::Ex)| {
                    let pack = pack.clone();
                    once_job(move || {
                        let o2 = p0;
                        let e2 = p1;
                        prism_rtl::Turn::Finished(crate::lower::model::Ex::XCtor(Text::lit("prism_rtl::Turn::Finished"), Array::from(vec![pack.clone()])))
                    })
                }) as Rc<dyn Fn((crate::lower::types::Env, crate::lower::model::Ex)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
            }), move |upd_tail_from_21044: crate::lower::model::Ex| {
                let turn = prepend(&binds, &upd_tail_from_21044);
                let step_fn = prepend(&cap_dos, &crate::lower::model::Ex::XClosure(true, Array::from(vec![crate::lower::model::Pa::PaTyped(Rc::new(pat.clone()), st_ty.clone()), crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaBind(key_name.clone())), kt.clone()), crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaBind(val_name.clone())), vt.clone())]), Rc::new(turn.clone())));
                let out_caps = caps_in(&outer, &rest_text_, &names);
                let out_dos = each(&out_caps, &(|(_, rs, mode, bt): &(Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)| crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::lower::types::place_stem(rs)), crate::lower::types::own(&crate::lower::types::Vl::VlPlace(rs.clone(), mode.clone(), bt.clone())))));
                let outer2 = fold(&out_caps, &outer, &(|en: &crate::lower::types::Env, (k, rs, _, bt): &(Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)| crate::lower::types::bind(en, k, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(crate::lower::types::place_stem(rs)), crate::lower::types::Holding::Owned, bt.clone()))));
                let env2 = fold(&out_caps, &env_s, &(|en: &crate::lower::types::Env, (k, rs, _, bt): &(Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)| crate::lower::types::bind(en, k, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(crate::lower::types::place_stem(rs)), crate::lower::types::Holding::Owned, bt.clone()))));
                let looping = if is_array { Text::lit("for_turns_indexed") } else { Text::lit("for_turns_keyed") };
                call_value((&cont_fn)((outer2.clone(), env2.clone())), move |cont_21892: crate::lower::model::Ex| {
                    let enter = crate::lower::model::Ex::XCall(Text::lit("call_then"), Array::from(vec![crate::lower::model::Ex::XCall(looping.clone(), Array::from(vec![src.clone(), pack.clone(), step_fn.clone()])), crate::lower::model::Ex::XClosure(true, Array::from(vec![crate::lower::model::Pa::PaTyped(Rc::new(pat.clone()), st_ty.clone())]), Rc::new(cont_21892))]));
                    prism_rtl::Turn::Finished(prepend(&out_dos, &enter))
                })
            })
        })
    }
}

/// `Start ForJob, x`: what the function value is when passed to `@Run`.
pub fn start_for_job(lx: crate::lower::Lx, outer: crate::lower::types::Env, env: crate::lower::types::Env, binders_opt: Option<crate::syntax::ForBinders>, source: crate::syntax::Expr, body: crate::syntax::Block, span: crate::syntax::Range, rest_text_: Text, cont_fn: Rc<dyn Fn((crate::lower::types::Env, crate::lower::types::Env)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>> {
    Rc::new(ForJob { lx, outer, env, binders_opt, source, body, span, rest_text_, cont_fn })
}

/// ```prism
/// InstanceOf: fn Text -> Text
/// ```
pub fn instance_of(k: &Text) -> Text {
    or(&index(&split_on(k, &Text::lit("#inst")), &Nat::from(0u32)), k)
}

/// ```prism
/// CapsIn: fn Env, Text, [Text] -> [((Text, Ex, Holding, OutTy))]
/// ```
pub fn caps_in(env: &crate::lower::types::Env, text: &Text, skip: &Array<Text>) -> Array<(Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)> {
    fold(&keys(&env.names), &Array::new(), &(|acc: &Array<(Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)>, k: &Text| match get(&env.names, k) {
        Some(crate::lower::types::Bn::BnLocal(rs, mode, bt)) => if (crate::check::types::has_text(skip, &crate::lower::types::place_stem(&rs)) || crate::lower::types::on_self(&rs)) || !mentions(text, &crate::syntax::lexer::chars::drop_prefix(&instance_of(k), &crate::check::types::unify::marks_of(k))) {
            acc.clone()
        } else {
            push(acc, &(k.clone(), rs.clone(), mode.clone(), bt.clone()))
        },
        _ => acc.clone(),
    }))
}

/// ```prism
/// ?FrameCall: unbounded fn Lx, Env, Expr, Bool -> ?Expr
/// ```
pub fn frame_call(lx: &crate::lower::Lx, env: &crate::lower::types::Env, e: &crate::syntax::Expr, top: &bool) -> Option<crate::syntax::Expr> {
    if crate::check::env::has_key(&env.spans, &crate::lower::place_key(lx, &e.span)) {
        None
    } else {
        'm23060: {
            let scrutinee = &*e.kind;
            if let crate::syntax::ExprKind::EGroup(x) = scrutinee {
                break 'm23060 frame_call(lx, env, &**x, top);
            }
            if let crate::syntax::ExprKind::ECall(c, args, _, _) = scrutinee {
                break 'm23060 match first_frame(lx, env, &each(args, &(|a: &crate::syntax::Arg| a.value.clone()))) {
                    Some(x) => Some(x.clone()),
                    None => if *top {
                        None
                    } else {
                        match tail_callee(lx, env, &**c) {
                            Some(_) => Some(e.clone()),
                            None => match local_job_fn(lx, env, &**c) {
                                Some(_) => Some(e.clone()),
                                None => match crate::lower::expr::prelude_job_call(lx, env, e) {
                                    Some(_) => Some(e.clone()),
                                    None => None,
                                },
                            },
                        }
                    },
                };
            }
            if let crate::syntax::ExprKind::EMatch(x, _) = scrutinee {
                break 'm23060 frame_call(lx, env, &**x, &false);
            }
            if let crate::syntax::ExprKind::EIf(m23060_3_0, _, _) = scrutinee && let crate::syntax::Cond::CondExpr(x) = &**m23060_3_0 {
                break 'm23060 frame_call(lx, env, &**x, &false);
            }
            if let crate::syntax::ExprKind::EBinary(op, l, r) = scrutinee {
                break 'm23060 if (op == &Text::lit("and")) || (op == &Text::lit("or")) {
                    frame_call(lx, env, &**l, &false)
                } else {
                    first_frame(lx, env, &Array::from(vec![(**l).clone(), (**r).clone()]))
                };
            }
            if let crate::syntax::ExprKind::ETuple(es) = scrutinee {
                break 'm23060 first_frame(lx, env, es);
            }
            if let crate::syntax::ExprKind::EArray(es) = scrutinee {
                break 'm23060 first_frame(lx, env, es);
            }
            if let crate::syntax::ExprKind::EUnary(_, x) = scrutinee {
                break 'm23060 frame_call(lx, env, &**x, &false);
            }
            if let crate::syntax::ExprKind::EField(x, _, _) = scrutinee {
                break 'm23060 frame_call(lx, env, &**x, &false);
            }
            if let crate::syntax::ExprKind::EIndex(x, i) = scrutinee {
                break 'm23060 first_frame(lx, env, &Array::from(vec![(**x).clone(), (**i).clone()]));
            }
            if let crate::syntax::ExprKind::EMethod(x, _, args) = scrutinee {
                break 'm23060 first_frame(lx, env, &append(&Array::from(vec![(**x).clone()]), &each(args, &(|a: &crate::syntax::Arg| a.value.clone()))));
            }
            if let crate::syntax::ExprKind::ECast(x, _, _) = scrutinee {
                break 'm23060 frame_call(lx, env, &**x, &false);
            }
            if let crate::syntax::ExprKind::ELit(l) = scrutinee {
                break 'm23060 match &l.kind {
                    crate::syntax::LitKind::LText(segs) => first_frame(lx, env, &placeholders(segs)),
                    _ => None,
                };
            }
            None
        }
    }
}

/// The step machine of `FrameCall`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?FrameCall: unbounded fn Lx, Env, Expr, Bool -> ?Expr
/// ```
pub struct FrameCall {
    pub lx: crate::lower::Lx,
    pub env: crate::lower::types::Env,
    pub e: crate::syntax::Expr,
    pub top: bool,
}

impl prism_rtl::Job<Option<crate::syntax::Expr>> for FrameCall {
    fn cycle(&self) -> prism_rtl::Turn<Option<crate::syntax::Expr>> {
        let lx = &self.lx;
        let env = &self.env;
        let e = &self.e;
        let top = &self.top;
        if crate::check::env::has_key(&env.spans, &crate::lower::place_key(lx, &e.span)) {
            prism_rtl::Turn::Finished(None)
        } else {
            'm23060: {
                let scrutinee = &*e.kind;
                if let crate::syntax::ExprKind::EGroup(x) = scrutinee {
                    break 'm23060 prism_rtl::Turn::More(Rc::new(FrameCall { lx: lx.clone(), env: env.clone(), e: (**x).clone(), top: *top }));
                }
                if let crate::syntax::ExprKind::ECall(c, args, _, _) = scrutinee {
                    break 'm23060 {
                        let args = args.clone();
                        let c = (**c).clone();
                        let e = e.clone();
                        let env = env.clone();
                        let lx = lx.clone();
                        let top = *top;
                        call_then(start_first_frame(lx.clone(), env.clone(), each(&args, &(|a: &crate::syntax::Arg| a.value.clone()))), move |first_frame_23164: Option<crate::syntax::Expr>| match first_frame_23164 {
                            Some(x) => prism_rtl::Turn::Finished(Some(x.clone())),
                            None => if top {
                                prism_rtl::Turn::Finished(None)
                            } else {
                                match tail_callee(&lx, &env, &c) {
                                    Some(_) => prism_rtl::Turn::Finished(Some(e.clone())),
                                    None => call_then(start_local_job_fn(lx.clone(), env.clone(), c.clone()), move |local_job_fn_23395: Option<crate::lower::types::Vl>| match local_job_fn_23395 {
                                        Some(_) => prism_rtl::Turn::Finished(Some(e.clone())),
                                        None => call_then(crate::lower::expr::start_prelude_job_call(lx.clone(), env.clone(), e.clone()), move |prelude_job_call_23492: Option<crate::lower::model::Ex>| match prelude_job_call_23492 {
                                            Some(_) => prism_rtl::Turn::Finished(Some(e.clone())),
                                            None => prism_rtl::Turn::Finished(None),
                                        }),
                                    }),
                                }
                            },
                        })
                    };
                }
                if let crate::syntax::ExprKind::EMatch(x, _) = scrutinee {
                    break 'm23060 prism_rtl::Turn::More(Rc::new(FrameCall { lx: lx.clone(), env: env.clone(), e: (**x).clone(), top: false }));
                }
                if let crate::syntax::ExprKind::EIf(m23060_3_0, _, _) = scrutinee && let crate::syntax::Cond::CondExpr(x) = &**m23060_3_0 {
                    break 'm23060 prism_rtl::Turn::More(Rc::new(FrameCall { lx: lx.clone(), env: env.clone(), e: (**x).clone(), top: false }));
                }
                if let crate::syntax::ExprKind::EBinary(op, l, r) = scrutinee {
                    break 'm23060 if (op == &Text::lit("and")) || (op == &Text::lit("or")) {
                        prism_rtl::Turn::More(Rc::new(FrameCall { lx: lx.clone(), env: env.clone(), e: (**l).clone(), top: false }))
                    } else {
                        prism_rtl::Turn::More(Rc::new(FirstFrame { lx: lx.clone(), env: env.clone(), es: Array::from(vec![(**l).clone(), (**r).clone()]) }))
                    };
                }
                if let crate::syntax::ExprKind::ETuple(es) = scrutinee {
                    break 'm23060 prism_rtl::Turn::More(Rc::new(FirstFrame { lx: lx.clone(), env: env.clone(), es: es.clone() }));
                }
                if let crate::syntax::ExprKind::EArray(es) = scrutinee {
                    break 'm23060 prism_rtl::Turn::More(Rc::new(FirstFrame { lx: lx.clone(), env: env.clone(), es: es.clone() }));
                }
                if let crate::syntax::ExprKind::EUnary(_, x) = scrutinee {
                    break 'm23060 prism_rtl::Turn::More(Rc::new(FrameCall { lx: lx.clone(), env: env.clone(), e: (**x).clone(), top: false }));
                }
                if let crate::syntax::ExprKind::EField(x, _, _) = scrutinee {
                    break 'm23060 prism_rtl::Turn::More(Rc::new(FrameCall { lx: lx.clone(), env: env.clone(), e: (**x).clone(), top: false }));
                }
                if let crate::syntax::ExprKind::EIndex(x, i) = scrutinee {
                    break 'm23060 prism_rtl::Turn::More(Rc::new(FirstFrame { lx: lx.clone(), env: env.clone(), es: Array::from(vec![(**x).clone(), (**i).clone()]) }));
                }
                if let crate::syntax::ExprKind::EMethod(x, _, args) = scrutinee {
                    break 'm23060 prism_rtl::Turn::More(Rc::new(FirstFrame { lx: lx.clone(), env: env.clone(), es: append(&Array::from(vec![(**x).clone()]), &each(args, &(|a: &crate::syntax::Arg| a.value.clone()))) }));
                }
                if let crate::syntax::ExprKind::ECast(x, _, _) = scrutinee {
                    break 'm23060 prism_rtl::Turn::More(Rc::new(FrameCall { lx: lx.clone(), env: env.clone(), e: (**x).clone(), top: false }));
                }
                if let crate::syntax::ExprKind::ELit(l) = scrutinee {
                    break 'm23060 match &l.kind {
                        crate::syntax::LitKind::LText(segs) => prism_rtl::Turn::More(Rc::new(FirstFrame { lx: lx.clone(), env: env.clone(), es: placeholders(segs) })),
                        _ => prism_rtl::Turn::Finished(None),
                    };
                }
                prism_rtl::Turn::Finished(None)
            }
        }
    }
}

/// `Start FrameCall, x`: what the function value is when passed to `@Run`.
pub fn start_frame_call(lx: crate::lower::Lx, env: crate::lower::types::Env, e: crate::syntax::Expr, top: bool) -> Rc<dyn prism_rtl::Job<Option<crate::syntax::Expr>>> {
    Rc::new(FrameCall { lx, env, e, top })
}

/// ```prism
/// Placeholders: fn [TextSeg] -> [Expr]
/// ```
pub fn placeholders(segs: &Array<crate::syntax::TextSeg>) -> Array<crate::syntax::Expr> {
    fold(segs, &Array::new(), &(|acc: &Array<crate::syntax::Expr>, sg: &crate::syntax::TextSeg| match sg {
        crate::syntax::TextSeg::SegPlaceholder(x) => push(acc, x),
        _ => acc.clone(),
    }))
}

/// ```prism
/// ?FirstFrame: unbounded fn Lx, Env, [Expr] -> ?Expr
/// ```
pub fn first_frame(lx: &crate::lower::Lx, env: &crate::lower::types::Env, es: &Array<crate::syntax::Expr>) -> Option<crate::syntax::Expr> {
    run_to_end(fold_job(es.clone(), None, {
        let lx = lx.clone();
        let env = env.clone();
        Rc::new(move |(p0, p1): (Option<crate::syntax::Expr>, crate::syntax::Expr)| {
            let lx = lx.clone();
            let env = env.clone();
            entered(once_job(move || {
                let found_opt = p0;
                let x = p1;
                match &found_opt {
                    Some(f) => prism_rtl::Turn::Finished(Some(f.clone())),
                    None => prism_rtl::Turn::More(Rc::new(FrameCall { lx: lx.clone(), env: env.clone(), e: x.clone(), top: false })),
                }
            }))
        }) as Rc<dyn Fn((Option<crate::syntax::Expr>, crate::syntax::Expr)) -> Rc<dyn prism_rtl::Job<Option<crate::syntax::Expr>>>>
    }))
}

/// The step machine of `FirstFrame`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?FirstFrame: unbounded fn Lx, Env, [Expr] -> ?Expr
/// ```
pub struct FirstFrame {
    pub lx: crate::lower::Lx,
    pub env: crate::lower::types::Env,
    pub es: Array<crate::syntax::Expr>,
}

impl prism_rtl::Job<Option<crate::syntax::Expr>> for FirstFrame {
    fn cycle(&self) -> prism_rtl::Turn<Option<crate::syntax::Expr>> {
        let lx = &self.lx;
        let env = &self.env;
        let es = &self.es;
        fold_job(es.clone(), None, {
            let lx = lx.clone();
            let env = env.clone();
            Rc::new(move |(p0, p1): (Option<crate::syntax::Expr>, crate::syntax::Expr)| {
                let lx = lx.clone();
                let env = env.clone();
                entered(once_job(move || {
                    let found_opt = p0;
                    let x = p1;
                    match &found_opt {
                        Some(f) => prism_rtl::Turn::Finished(Some(f.clone())),
                        None => prism_rtl::Turn::More(Rc::new(FrameCall { lx: lx.clone(), env: env.clone(), e: x.clone(), top: false })),
                    }
                }))
            }) as Rc<dyn Fn((Option<crate::syntax::Expr>, crate::syntax::Expr)) -> Rc<dyn prism_rtl::Job<Option<crate::syntax::Expr>>>>
        }).cycle()
    }
}

/// `Start FirstFrame, x`: what the function value is when passed to `@Run`.
pub fn start_first_frame(lx: crate::lower::Lx, env: crate::lower::types::Env, es: Array<crate::syntax::Expr>) -> Rc<dyn prism_rtl::Job<Option<crate::syntax::Expr>>> {
    Rc::new(FirstFrame { lx, env, es })
}

/// ```prism
/// Frame: unbounded fn Lx, Env, Expr, Text, (unbounded fn Env -> Ex) -> Ex
/// ```
pub fn frame(lx: &crate::lower::Lx, env: &crate::lower::types::Env, call: &crate::syntax::Expr, rest_text_: &Text, cont_fn: &Rc<dyn Fn(crate::lower::types::Env) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>) -> crate::lower::model::Ex {
    match &*call.kind {
        crate::syntax::ExprKind::ECall(c, args, _, _) => {
            let qk_opt = tail_callee(lx, env, &**c);
            let qk = or(&qk_opt, &Text::lit(""));
            let base = match &qk_opt {
                Some(q) => or(&get(&lx.rs_names, q), &crate::lower::snake(&crate::check::types::bare_name(q))),
                None => crate::lower::snake(&callee_text(&**c)),
            };
            let v_ = Text::from(format!("{}_{}", &base, &call.span.start));
            let t = crate::lower::types::out_ty_of(lx, &crate::lower::types::peel(&crate::lower::type_at(lx, &call.span)));
            let caps = fold(&keys(&env.names), &Array::new(), &(|acc: &Array<(Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)>, k: &Text| match get(&env.names, k) {
                Some(crate::lower::types::Bn::BnLocal(rs, mode, bt)) => if ((&mode == &crate::lower::types::Holding::ByRef) || (&mode == &crate::lower::types::Holding::RcRef)) && mentions(rest_text_, &instance_of(k)) {
                    push(acc, &(k.clone(), rs.clone(), mode.clone(), bt.clone()))
                } else {
                    acc.clone()
                },
                _ => acc.clone(),
            }));
            let dos = each(&caps, &(|(_, rs, mode, bt): &(Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)| crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::lower::types::place_stem(rs)), crate::lower::types::own(&crate::lower::types::Vl::VlPlace(rs.clone(), mode.clone(), bt.clone())))));
            let env2 = fold(&caps, env, &(|en: &crate::lower::types::Env, (k, rs, _, bt): &(Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)| crate::lower::types::bind(en, k, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(crate::lower::types::place_stem(rs)), crate::lower::types::Holding::Owned, bt.clone()))));
            let vals = match &qk_opt {
                Some(q) => crate::lower::expr::named_args_owned(lx, &env2, q, args),
                None => match local_job_fn(lx, &env2, &**c) {
                    Some(f) => crate::lower::expr::start_args(lx, &env2, &f, args),
                    None => run_to_end(each_job(args.clone(), {
                        let lx = lx.clone();
                        let env2 = env2.clone();
                        Rc::new(move |p0: crate::syntax::Arg| {
                            let lx = lx.clone();
                            let env2 = env2.clone();
                            entered(once_job(move || {
                                let a = p0;
                                call_then(crate::lower::expr::start_value_of(lx.clone(), env2.clone(), a.value.clone()), move |value_of_26215: crate::lower::types::Vl| prism_rtl::Turn::Finished(crate::lower::types::own(&value_of_26215)))
                            }))
                        }) as Rc<dyn Fn(crate::syntax::Arg) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
                    })),
                },
            };
            let env3 = crate::lower::types::bind_span(&env2, &crate::lower::place_key(lx, &call.span), &crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XVar(v_.clone()), t.clone()));
            let body = run_to_end(cont_fn(env3.clone()));
            let (job, how) = match &qk_opt {
                Some(q) => (crate::lower::model::Ex::XCall(crate::lower::path_in(lx, &crate::lower::owner_of(q), &Text::from(format!("start_{}", &base))), vals.clone()), if crate::lower::program::enters_at_once(lx, q, args) {
                    Text::lit("call_value")
                } else {
                    Text::lit("call_then")
                }),
                None => match local_job_fn(lx, &env2, &**c) {
                    Some(f) => (start_call(&f, &vals), Text::lit("call_value")),
                    None => match crate::lower::expr::prelude_job_call(lx, &env2, call) {
                        Some(pj) => (pj.clone(), Text::lit("call_value")),
                        None => (crate::lower::expr::refusal(&Text::lit("a call this frame cannot enter")), Text::lit("call_then")),
                    },
                },
            };
            let enter = crate::lower::model::Ex::XCall(how.clone(), Array::from(vec![job.clone(), crate::lower::model::Ex::XClosure(true, Array::from(vec![crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaBind(v_.clone())), t.clone())]), Rc::new(body.clone()))]));
            if &len(&dos) == &Nat::from(0u32) {
                enter.clone()
            } else {
                crate::lower::model::Ex::XBlock(dos.clone(), Rc::new(enter.clone()))
            }
        },
        _ => run_to_end(cont_fn(env.clone())),
    }
}

/// The step machine of `Frame`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Frame: unbounded fn Lx, Env, Expr, Text, (unbounded fn Env -> Ex) -> Ex
/// ```
pub struct Frame {
    pub lx: crate::lower::Lx,
    pub env: crate::lower::types::Env,
    pub call: crate::syntax::Expr,
    pub rest_text_: Text,
    pub cont_fn: Rc<dyn Fn(crate::lower::types::Env) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>,
}

impl prism_rtl::Job<crate::lower::model::Ex> for Frame {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::Ex> {
        let lx = &self.lx;
        let env = &self.env;
        let call = &self.call;
        let rest_text_ = &self.rest_text_;
        let cont_fn = &self.cont_fn;
        match &*call.kind {
            crate::syntax::ExprKind::ECall(c, args, _, _) => {
                let qk_opt = tail_callee(lx, env, &**c);
                let qk = or(&qk_opt, &Text::lit(""));
                let base = match &qk_opt {
                    Some(q) => or(&get(&lx.rs_names, q), &crate::lower::snake(&crate::check::types::bare_name(q))),
                    None => crate::lower::snake(&callee_text(&**c)),
                };
                let v_ = Text::from(format!("{}_{}", &base, &call.span.start));
                let cont_fn = cont_fn.clone();
                let args = args.clone();
                let c = (**c).clone();
                let call = call.clone();
                let env = env.clone();
                let lx = lx.clone();
                let rest_text_ = rest_text_.clone();
                call_then(crate::lower::types::start_out_ty_of(lx.clone(), crate::lower::types::peel(&crate::lower::type_at(&lx, &call.span))), move |out_ty_of_25460: crate::lower::model::OutTy| {
                    let t = out_ty_of_25460;
                    let caps = fold(&keys(&env.names), &Array::new(), &(|acc: &Array<(Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)>, k: &Text| match get(&env.names, k) {
                        Some(crate::lower::types::Bn::BnLocal(rs, mode, bt)) => if ((&mode == &crate::lower::types::Holding::ByRef) || (&mode == &crate::lower::types::Holding::RcRef)) && mentions(&rest_text_, &instance_of(k)) {
                            push(acc, &(k.clone(), rs.clone(), mode.clone(), bt.clone()))
                        } else {
                            acc.clone()
                        },
                        _ => acc.clone(),
                    }));
                    let dos = each(&caps, &(|(_, rs, mode, bt): &(Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)| crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::lower::types::place_stem(rs)), crate::lower::types::own(&crate::lower::types::Vl::VlPlace(rs.clone(), mode.clone(), bt.clone())))));
                    let env2 = fold(&caps, &env, &(|en: &crate::lower::types::Env, (k, rs, _, bt): &(Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)| crate::lower::types::bind(en, k, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(crate::lower::types::place_stem(rs)), crate::lower::types::Holding::Owned, bt.clone()))));
                    let vals = match &qk_opt {
                        Some(q) => crate::lower::expr::named_args_owned(&lx, &env2, q, &args),
                        None => match local_job_fn(&lx, &env2, &c) {
                            Some(f) => crate::lower::expr::start_args(&lx, &env2, &f, &args),
                            None => run_to_end(each_job(args.clone(), {
                                let lx = lx.clone();
                                let env2 = env2.clone();
                                Rc::new(move |p0: crate::syntax::Arg| {
                                    let lx = lx.clone();
                                    let env2 = env2.clone();
                                    entered(once_job(move || {
                                        let a = p0;
                                        call_then(crate::lower::expr::start_value_of(lx.clone(), env2.clone(), a.value.clone()), move |value_of_26215: crate::lower::types::Vl| prism_rtl::Turn::Finished(crate::lower::types::own(&value_of_26215)))
                                    }))
                                }) as Rc<dyn Fn(crate::syntax::Arg) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
                            })),
                        },
                    };
                    let env3 = crate::lower::types::bind_span(&env2, &crate::lower::place_key(&lx, &call.span), &crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XVar(v_.clone()), t.clone()));
                    call_value((&cont_fn)(env3.clone()), move |cont_26343: crate::lower::model::Ex| {
                        let body = cont_26343;
                        let (job, how) = match &qk_opt {
                            Some(q) => (crate::lower::model::Ex::XCall(crate::lower::path_in(&lx, &crate::lower::owner_of(q), &Text::from(format!("start_{}", &base))), vals.clone()), if crate::lower::program::enters_at_once(&lx, q, &args) {
                                Text::lit("call_value")
                            } else {
                                Text::lit("call_then")
                            }),
                            None => match local_job_fn(&lx, &env2, &c) {
                                Some(f) => (start_call(&f, &vals), Text::lit("call_value")),
                                None => match crate::lower::expr::prelude_job_call(&lx, &env2, &call) {
                                    Some(pj) => (pj.clone(), Text::lit("call_value")),
                                    None => (crate::lower::expr::refusal(&Text::lit("a call this frame cannot enter")), Text::lit("call_then")),
                                },
                            },
                        };
                        let enter = crate::lower::model::Ex::XCall(how.clone(), Array::from(vec![job.clone(), crate::lower::model::Ex::XClosure(true, Array::from(vec![crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaBind(v_.clone())), t.clone())]), Rc::new(body.clone()))]));
                        if &len(&dos) == &Nat::from(0u32) {
                            prism_rtl::Turn::Finished(enter.clone())
                        } else {
                            prism_rtl::Turn::Finished(crate::lower::model::Ex::XBlock(dos.clone(), Rc::new(enter.clone())))
                        }
                    })
                })
            },
            _ => cont_fn(env.clone()).cycle(),
        }
    }
}

/// `Start Frame, x`: what the function value is when passed to `@Run`.
pub fn start_frame(lx: crate::lower::Lx, env: crate::lower::types::Env, call: crate::syntax::Expr, rest_text_: Text, cont_fn: Rc<dyn Fn(crate::lower::types::Env) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>> {
    Rc::new(Frame { lx, env, call, rest_text_, cont_fn })
}

/// ```prism
/// ?LocalJobFn: unbounded fn Lx, Env, Expr -> ?Vl
/// ```
pub fn local_job_fn(lx: &crate::lower::Lx, env: &crate::lower::types::Env, c: &crate::syntax::Expr) -> Option<crate::lower::types::Vl> {
    match &*c.kind {
        crate::syntax::ExprKind::EName(n) => if (&len(&n.path_) == &Nat::from(1u32)) && crate::check::env::has_key(&env.names, &crate::check::env::sname_key(n)) {
            job_value(&crate::lower::expr::name_value(lx, env, n, &c.span))
        } else {
            None
        },
        crate::syntax::ExprKind::EGroup(x) => local_job_fn(lx, env, &**x),
        crate::syntax::ExprKind::EField(_, _, _) => job_value(&crate::lower::expr::value_of(lx, env, c)),
        _ => None,
    }
}

/// The step machine of `LocalJobFn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?LocalJobFn: unbounded fn Lx, Env, Expr -> ?Vl
/// ```
pub struct LocalJobFn {
    pub lx: crate::lower::Lx,
    pub env: crate::lower::types::Env,
    pub c: crate::syntax::Expr,
}

impl prism_rtl::Job<Option<crate::lower::types::Vl>> for LocalJobFn {
    fn cycle(&self) -> prism_rtl::Turn<Option<crate::lower::types::Vl>> {
        let lx = &self.lx;
        let env = &self.env;
        let c = &self.c;
        match &*c.kind {
            crate::syntax::ExprKind::EName(n) => if (&len(&n.path_) == &Nat::from(1u32)) && crate::check::env::has_key(&env.names, &crate::check::env::sname_key(n)) {
                {
                    let c = c.clone();
                    let env = env.clone();
                    let lx = lx.clone();
                    let n = n.clone();
                    call_then(crate::lower::expr::start_name_value(lx.clone(), env.clone(), n.clone(), c.span.clone()), move |name_value_27260: crate::lower::types::Vl| prism_rtl::Turn::Finished(job_value(&name_value_27260)))
                }
            } else {
                prism_rtl::Turn::Finished(None)
            },
            crate::syntax::ExprKind::EGroup(x) => prism_rtl::Turn::More(Rc::new(LocalJobFn { lx: lx.clone(), env: env.clone(), c: (**x).clone() })),
            crate::syntax::ExprKind::EField(_, _, _) => {
                let c = c.clone();
                let env = env.clone();
                let lx = lx.clone();
                call_then(crate::lower::expr::start_value_of(lx.clone(), env.clone(), c.clone()), move |value_of_27391: crate::lower::types::Vl| prism_rtl::Turn::Finished(job_value(&value_of_27391)))
            },
            _ => prism_rtl::Turn::Finished(None),
        }
    }
}

/// `Start LocalJobFn, x`: what the function value is when passed to `@Run`.
pub fn start_local_job_fn(lx: crate::lower::Lx, env: crate::lower::types::Env, c: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<Option<crate::lower::types::Vl>>> {
    Rc::new(LocalJobFn { lx, env, c })
}

/// ```prism
/// ?JobValue: fn Vl -> ?Vl
/// ```
pub fn job_value(f: &crate::lower::types::Vl) -> Option<crate::lower::types::Vl> {
    match crate::lower::types::value_ty(f) {
        crate::lower::model::OutTy::OutJobFn(_, _) => Some(f.clone()),
        _ => None,
    }
}

/// ```prism
/// StartCall: fn Vl, [Ex] -> Ex
/// ```
pub fn start_call(f: &crate::lower::types::Vl, vals: &Array<crate::lower::model::Ex>) -> crate::lower::model::Ex {
    crate::lower::model::Ex::XApply(Rc::new(crate::lower::types::ref_(f)), Array::from(vec![one_or_tuple(vals)]))
}

/// ```prism
/// OneOrTuple: fn [Ex] -> Ex
/// ```
pub fn one_or_tuple(xs0: &Array<crate::lower::model::Ex>) -> crate::lower::model::Ex {
    'c: {
        if let c0_0 = xs0 && (c0_0.len() == 1) && let Some(one) = index(c0_0, &Nat::from(0u32)) {
            break 'c one.clone();
        }
        if let vals = xs0 {
            break 'c crate::lower::model::Ex::XTuple(vals.clone());
        }
        unreachable!("no clause matched")
    }
}

/// ```prism
/// CalleeText: fn Expr -> Text
/// ```
pub fn callee_text(c: &crate::syntax::Expr) -> Text {
    match &*c.kind {
        crate::syntax::ExprKind::EName(n) => crate::check::env::dotted(&n.path_),
        crate::syntax::ExprKind::EGroup(x) => callee_text(&**x),
        _ => Text::lit("call"),
    }
}

/// ```prism
/// RestText: fn Lx, Range, Range, Range -> Text
/// ```
pub fn rest_text(lx: &crate::lower::Lx, from: &crate::syntax::Range, call: &crate::syntax::Range, to: &crate::syntax::Range) -> Text {
    match index(&lx.g.srcs, &lx.file) {
        Some(src) => crate::check::errors::span_text(&src, &crate::syntax::Range { start: from.start.clone(), end: to.end.clone() }),
        None => Text::lit(""),
    }
}

/// ```prism
/// Mentions: fn Text, Text -> Bool
/// ```
pub fn mentions(text: &Text, name: &Text) -> bool {
    let parts = split_on(text, name);
    let last = crate::syntax::lexer::chars::dec(&len(&parts));
    fold(&crate::check::errors::range0(&last), &false, &(|found: &bool, i: &Nat| {
        let before_ = or(&index(&parts, i), &Text::lit(""));
        let after_ = or(&index(&parts, &(i + &Nat::from(1u32))), &Text::lit(""));
        let left_word = if &before_ != &Text::lit("") {
            ends_ident(&before_)
        } else {
            (i > &Nat::from(0u32)) && ends_ident(name)
        };
        let right_word = if &after_ != &Text::lit("") {
            starts_ident(&after_)
        } else {
            (&(i + &Nat::from(1u32)) < &last) && starts_ident(name)
        };
        *found || (!left_word && !right_word)
    }))
}

/// ```prism
/// EndsIdent: fn Text -> Bool
/// ```
pub fn ends_ident(t: &Text) -> bool {
    (&len_text(t) > &Nat::from(0u32)) && crate::syntax::lexer::chars::is_ident_char(&crate::syntax::lexer::chars::last_char(t))
}

/// ```prism
/// StartsIdent: fn Text -> Bool
/// ```
pub fn starts_ident(t: &Text) -> bool {
    (&len_text(t) > &Nat::from(0u32)) && crate::syntax::lexer::chars::is_ident_char(&crate::syntax::lexer::chars::head(t))
}

/// ```prism
/// TailBody: unbounded fn Lx, Env, FnBody -> Ex
/// ```
pub fn tail_body(lx: &crate::lower::Lx, env: &crate::lower::types::Env, fn_body2: &crate::syntax::decls::FnBody) -> crate::lower::model::Ex {
    match fn_body2 {
        crate::syntax::decls::FnBody::BodyExpr(x) => tail(lx, env, x),
        crate::syntax::decls::FnBody::BodyBlock(b) => tail_block(lx, env, b),
    }
}

/// The step machine of `TailBody`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TailBody: unbounded fn Lx, Env, FnBody -> Ex
/// ```
pub struct TailBody {
    pub lx: crate::lower::Lx,
    pub env: crate::lower::types::Env,
    pub fn_body2: crate::syntax::decls::FnBody,
}

impl prism_rtl::Job<crate::lower::model::Ex> for TailBody {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::Ex> {
        let lx = &self.lx;
        let env = &self.env;
        let fn_body2 = &self.fn_body2;
        match fn_body2 {
            crate::syntax::decls::FnBody::BodyExpr(x) => prism_rtl::Turn::More(Rc::new(Tail { lx: lx.clone(), env: env.clone(), e: x.clone() })),
            crate::syntax::decls::FnBody::BodyBlock(b) => prism_rtl::Turn::More(Rc::new(TailBlock { lx: lx.clone(), env: env.clone(), b: b.clone() })),
        }
    }
}

/// `Start TailBody, x`: what the function value is when passed to `@Run`.
pub fn start_tail_body(lx: crate::lower::Lx, env: crate::lower::types::Env, fn_body2: crate::syntax::decls::FnBody) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>> {
    Rc::new(TailBody { lx, env, fn_body2 })
}

/// ```prism
/// TailMatch: unbounded fn Lx, Env, Expr, [Arm], Range -> Ex
/// ```
pub fn tail_match(lx: &crate::lower::Lx, env: &crate::lower::types::Env, s: &crate::syntax::Expr, arms: &Array<crate::syntax::Arm>, span: &crate::syntax::Range) -> crate::lower::model::Ex {
    let sv = crate::lower::expr::value_of(lx, env, s);
    let sty = crate::lower::type_at(lx, &s.span);
    let label = Text::from(format!("m{}", &span.start));
    let by_ref = run_to_end(each_job(crate::check::errors::range0(&len(arms)), {
        let lx = lx.clone();
        let arms = arms.clone();
        let sty = sty.clone();
        let label = label.clone();
        Rc::new(move |p0: Nat| {
            let lx = lx.clone();
            let arms = arms.clone();
            let sty = sty.clone();
            let label = label.clone();
            entered(once_job(move || {
                let i = p0;
                prism_rtl::Turn::More(Rc::new(crate::lower::expr::ArmPat { lx: lx.clone(), opt1: or(&index(&arms, &i), &crate::lower::expr::dummy_arm()).pattern.clone(), ty: sty.clone(), mode: crate::lower::types::Holding::ByRef, fresh: Text::from(format!("{}_{}", &label, &i)) }))
            }))
        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<crate::lower::patterns::PatOut>>>
    }));
    let chain = fold(&by_ref, &false, &(|f: &bool, po: &crate::lower::patterns::PatOut| *f || fold(&po.conds, &false, &(|f2: &bool, c: &crate::lower::model::Cc| *f2 || crate::lower::expr::is_let_cond(c)))));
    let owned = match &sv {
        crate::lower::types::Vl::VlOwned(_, _) => !chain,
        _ => false,
    };
    let pats = if owned {
        run_to_end(each_job(crate::check::errors::range0(&len(arms)), {
            let lx = lx.clone();
            let arms = arms.clone();
            let sty = sty.clone();
            let label = label.clone();
            Rc::new(move |p0: Nat| {
                let lx = lx.clone();
                let arms = arms.clone();
                let sty = sty.clone();
                let label = label.clone();
                entered(once_job(move || {
                    let i = p0;
                    prism_rtl::Turn::More(Rc::new(crate::lower::expr::ArmPat { lx: lx.clone(), opt1: or(&index(&arms, &i), &crate::lower::expr::dummy_arm()).pattern.clone(), ty: sty.clone(), mode: crate::lower::types::Holding::Owned, fresh: Text::from(format!("{}_{}", &label, &i)) }))
                }))
            }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<crate::lower::patterns::PatOut>>>
        }))
    } else {
        by_ref.clone()
    };
    let xarms = run_to_end(each_job(crate::check::errors::range0(&len(arms)), {
        let arms = arms.clone();
        let pats = pats.clone();
        let env = env.clone();
        let lx = lx.clone();
        Rc::new(move |p0: Nat| {
            let arms = arms.clone();
            let pats = pats.clone();
            let env = env.clone();
            let lx = lx.clone();
            entered(once_job(move || {
                let i = p0;
                {
                    let arm = or(&index(&arms, &i), &crate::lower::expr::dummy_arm());
                    let po = or(&index(&pats, &i), &crate::lower::patterns::PatOut { pa: crate::lower::model::Pa::PaWild, conds: Array::new(), binds: Array::new() });
                    let env2 = crate::lower::expr::bind_all(&env, &po.binds);
                    call_then(crate::lower::templates::start_guard_conds(lx.clone(), env2.clone(), arm.guard.clone()), move |guard_conds_30303: Array<crate::lower::model::Cc>| call_then(start_tail_block(lx.clone(), env2.clone(), arm.body.clone()), move |tail_block_30344: crate::lower::model::Ex| prism_rtl::Turn::Finished(crate::lower::model::XArm { pat: po.pa.clone(), conds: append(&po.conds, &guard_conds_30303), body: tail_block_30344 })))
                }
            }))
        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<crate::lower::model::XArm>>>
    }));
    let scrut = if owned { crate::lower::types::own(&sv) } else { crate::lower::types::ref_(&sv) };
    crate::lower::types::own(&crate::lower::expr::arms_value(&scrut, &xarms, &Text::from(format!("'{}", &label)), &crate::lower::model::OutTy::OutUnknown(Text::lit("the job's turn"))))
}

/// The step machine of `TailMatch`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TailMatch: unbounded fn Lx, Env, Expr, [Arm], Range -> Ex
/// ```
pub struct TailMatch {
    pub lx: crate::lower::Lx,
    pub env: crate::lower::types::Env,
    pub s: crate::syntax::Expr,
    pub arms: Array<crate::syntax::Arm>,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<crate::lower::model::Ex> for TailMatch {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::Ex> {
        let lx = &self.lx;
        let env = &self.env;
        let s = &self.s;
        let arms = &self.arms;
        let span = &self.span;
        let arms = arms.clone();
        let env = env.clone();
        let lx = lx.clone();
        let s = s.clone();
        let span = span.clone();
        call_then(crate::lower::expr::start_value_of(lx.clone(), env.clone(), s.clone()), move |value_of_29525: crate::lower::types::Vl| {
            let sv = value_of_29525;
            let sty = crate::lower::type_at(&lx, &s.span);
            let label = Text::from(format!("m{}", &span.start));
            call_value(each_job(crate::check::errors::range0(&len(&arms)), {
                let lx = lx.clone();
                let arms = arms.clone();
                let sty = sty.clone();
                let label = label.clone();
                Rc::new(move |p0: Nat| {
                    let lx = lx.clone();
                    let arms = arms.clone();
                    let sty = sty.clone();
                    let label = label.clone();
                    entered(once_job(move || {
                        let i = p0;
                        prism_rtl::Turn::More(Rc::new(crate::lower::expr::ArmPat { lx: lx.clone(), opt1: or(&index(&arms, &i), &crate::lower::expr::dummy_arm()).pattern.clone(), ty: sty.clone(), mode: crate::lower::types::Holding::ByRef, fresh: Text::from(format!("{}_{}", &label, &i)) }))
                    }))
                }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<crate::lower::patterns::PatOut>>>
            }), move |each_29624: Array<crate::lower::patterns::PatOut>| {
                let by_ref = each_29624;
                let chain = fold(&by_ref, &false, &(|f: &bool, po: &crate::lower::patterns::PatOut| *f || fold(&po.conds, &false, &(|f2: &bool, c: &crate::lower::model::Cc| *f2 || crate::lower::expr::is_let_cond(c)))));
                let owned = match &sv {
                    crate::lower::types::Vl::VlOwned(_, _) => !chain,
                    _ => false,
                };
                let pats = if owned {
                    run_to_end(each_job(crate::check::errors::range0(&len(&arms)), {
                        let lx = lx.clone();
                        let arms = arms.clone();
                        let sty = sty.clone();
                        let label = label.clone();
                        Rc::new(move |p0: Nat| {
                            let lx = lx.clone();
                            let arms = arms.clone();
                            let sty = sty.clone();
                            let label = label.clone();
                            entered(once_job(move || {
                                let i = p0;
                                prism_rtl::Turn::More(Rc::new(crate::lower::expr::ArmPat { lx: lx.clone(), opt1: or(&index(&arms, &i), &crate::lower::expr::dummy_arm()).pattern.clone(), ty: sty.clone(), mode: crate::lower::types::Holding::Owned, fresh: Text::from(format!("{}_{}", &label, &i)) }))
                            }))
                        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<crate::lower::patterns::PatOut>>>
                    }))
                } else {
                    by_ref.clone()
                };
                call_value(each_job(crate::check::errors::range0(&len(&arms)), {
                    let arms = arms.clone();
                    let pats = pats.clone();
                    let env = env.clone();
                    let lx = lx.clone();
                    Rc::new(move |p0: Nat| {
                        let arms = arms.clone();
                        let pats = pats.clone();
                        let env = env.clone();
                        let lx = lx.clone();
                        entered(once_job(move || {
                            let i = p0;
                            {
                                let arm = or(&index(&arms, &i), &crate::lower::expr::dummy_arm());
                                let po = or(&index(&pats, &i), &crate::lower::patterns::PatOut { pa: crate::lower::model::Pa::PaWild, conds: Array::new(), binds: Array::new() });
                                let env2 = crate::lower::expr::bind_all(&env, &po.binds);
                                call_then(crate::lower::templates::start_guard_conds(lx.clone(), env2.clone(), arm.guard.clone()), move |guard_conds_30303: Array<crate::lower::model::Cc>| call_then(start_tail_block(lx.clone(), env2.clone(), arm.body.clone()), move |tail_block_30344: crate::lower::model::Ex| prism_rtl::Turn::Finished(crate::lower::model::XArm { pat: po.pa.clone(), conds: append(&po.conds, &guard_conds_30303), body: tail_block_30344 })))
                            }
                        }))
                    }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<crate::lower::model::XArm>>>
                }), move |each_30070: Array<crate::lower::model::XArm>| {
                    let xarms = each_30070;
                    let scrut = if owned { crate::lower::types::own(&sv) } else { crate::lower::types::ref_(&sv) };
                    prism_rtl::Turn::Finished(crate::lower::types::own(&crate::lower::expr::arms_value(&scrut, &xarms, &Text::from(format!("'{}", &label)), &crate::lower::model::OutTy::OutUnknown(Text::lit("the job's turn")))))
                })
            })
        })
    }
}

/// `Start TailMatch, x`: what the function value is when passed to `@Run`.
pub fn start_tail_match(lx: crate::lower::Lx, env: crate::lower::types::Env, s: crate::syntax::Expr, arms: Array<crate::syntax::Arm>, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>> {
    Rc::new(TailMatch { lx, env, s, arms, span })
}

/// ```prism
/// ?TailCallee: fn Lx, Env, Expr -> ?Text
/// ```
pub fn tail_callee(lx: &crate::lower::Lx, env: &crate::lower::types::Env, callee: &crate::syntax::Expr) -> Option<Text> {
    match &*callee.kind {
        crate::syntax::ExprKind::EName(n) => if (&len(&n.path_) == &Nat::from(1u32)) && crate::check::env::has_key(&env.names, &crate::check::env::sname_key(n)) {
            None
        } else {
            {
                let (qk_opt, _) = crate::check::env::names::resolve_value(&lx.g, &lx.home, n);
                match &qk_opt {
                    Some(qk) => if crate::check::types::has_text(&lx.unbs, qk) && !crate::lower::program::in_prelude(lx, qk) {
                        Some(qk.clone())
                    } else {
                        None
                    },
                    None => None,
                }
            }
        },
        _ => None,
    }
}

/// ```prism
/// SchemeParts: fn Lx, Text -> (([Ty], Ty))
/// ```
pub fn scheme_parts(lx: &crate::lower::Lx, qk: &Text) -> (Array<crate::check::types::Ty>, crate::check::types::Ty) {
    match get(&lx.g.vals, qk) {
        Some(v_) => match &v_.scheme.ty {
            crate::check::types::Ty::TyFn(_, ps, r) => (ps.clone(), (**r).clone()),
            other => (Array::new(), other.clone()),
        },
        None => (Array::new(), crate::check::types::Ty::TyErr),
    }
}

/// ```prism
/// JobFieldNames: unbounded fn Lx, Text -> [Text]
/// ```
pub fn job_field_names(lx: &crate::lower::Lx, qk: &Text) -> Array<Text> {
    let clauses = clauses_of(&lx.g, qk);
    let (ptys, _) = scheme_parts(lx, qk);
    let pts = run_to_end(each_job(ptys.clone(), {
        let lx = lx.clone();
        Rc::new(move |p0: crate::check::types::Ty| {
            let lx = lx.clone();
            entered(once_job(move || {
                let p_ = p0;
                prism_rtl::Turn::More(Rc::new(crate::lower::types::OutTyOf { lx: lx.clone(), t: crate::lower::types::peel(&p_) }))
            }))
        }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::lower::model::OutTy>>>
    }));
    each(&crate::lower::functions::param_names(lx, &clauses, &pts), &(|(n, _): &(Text, bool)| n.clone()))
}

/// The step machine of `JobFieldNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// JobFieldNames: unbounded fn Lx, Text -> [Text]
/// ```
pub struct JobFieldNames {
    pub lx: crate::lower::Lx,
    pub qk: Text,
}

impl prism_rtl::Job<Array<Text>> for JobFieldNames {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let lx = &self.lx;
        let qk = &self.qk;
        let clauses = clauses_of(&lx.g, qk);
        let (ptys, _) = scheme_parts(lx, qk);
        let lx = lx.clone();
        call_value(each_job(ptys.clone(), {
            let lx = lx.clone();
            Rc::new(move |p0: crate::check::types::Ty| {
                let lx = lx.clone();
                entered(once_job(move || {
                    let p_ = p0;
                    prism_rtl::Turn::More(Rc::new(crate::lower::types::OutTyOf { lx: lx.clone(), t: crate::lower::types::peel(&p_) }))
                }))
            }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::lower::model::OutTy>>>
        }), move |each_31411: Array<crate::lower::model::OutTy>| {
            let pts = each_31411;
            prism_rtl::Turn::Finished(each(&crate::lower::functions::param_names(&lx, &clauses, &pts), &(|(n, _): &(Text, bool)| n.clone())))
        })
    }
}

/// `Start JobFieldNames, x`: what the function value is when passed to `@Run`.
pub fn start_job_field_names(lx: crate::lower::Lx, qk: Text) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(JobFieldNames { lx, qk })
}

/// ```prism
/// ClausesOf: fn G, Text -> [FnClause]
/// ```
pub fn clauses_of(g: &crate::check::env::G, qk: &Text) -> Array<crate::syntax::decls::FnClause> {
    fold(&g.defs, &Array::new(), &(|acc: &Array<crate::syntax::decls::FnClause>, d: &crate::check::env::Def| if &d.qk == qk { def_clauses(d, acc) } else { acc.clone() }))
}

/// ```prism
/// DefClauses: fn Def, [FnClause] -> [FnClause]
/// ```
pub fn def_clauses(d: &crate::check::env::Def, other: &Array<crate::syntax::decls::FnClause>) -> Array<crate::syntax::decls::FnClause> {
    match &d.body {
        crate::check::env::DefBody::DbFn(cs) => cs.clone(),
        _ => other.clone(),
    }
}

/// ```prism
/// JobDefOf: unbounded fn Lx, Text, [FnClause], Scheme -> JobDef
/// ```
pub fn job_def_of(lx: &crate::lower::Lx, qk: &Text, clauses: &Array<crate::syntax::decls::FnClause>, sc: &crate::check::types::Scheme) -> crate::lower::model::JobDef {
    let (ptys, res) = match &sc.ty {
        crate::check::types::Ty::TyFn(_, ps, r) => (ps.clone(), (**r).clone()),
        other => (Array::new(), other.clone()),
    };
    let pts = run_to_end(each_job(ptys.clone(), {
        let lx = lx.clone();
        Rc::new(move |p0: crate::check::types::Ty| {
            let lx = lx.clone();
            entered(once_job(move || {
                let p_ = p0;
                prism_rtl::Turn::More(Rc::new(crate::lower::types::OutTyOf { lx: lx.clone(), t: crate::lower::types::peel(&p_) }))
            }))
        }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::lower::model::OutTy>>>
    }));
    let names = crate::lower::functions::param_names(lx, clauses, &pts);
    let body = job_clauses(lx, clauses, &names, &ptys, &pts);
    let base = or(&get(&lx.rs_names, qk), &crate::lower::snake(&crate::check::types::bare_name(qk)));
    crate::lower::model::JobDef { name: crate::lower::camel(&crate::check::types::bare_name(qk)), start: Text::from(format!("start_{}", &base)), generics: crate::lower::functions::scheme_generics(lx, sc), fields: each(&crate::check::errors::range0(&len(&pts)), &(|i: &Nat| (or(&index(&each(&names, &(|(n, _): &(Text, bool)| n.clone())), i), &Text::lit("arg")), or(&index(&pts, i), &crate::lower::model::OutTy::OutUnit)))), ret: crate::lower::types::out_ty_of(lx, &crate::lower::types::peel(&res)), body: body.clone(), doc: crate::lower::functions::signature_text(lx, qk) }
}

/// The step machine of `JobDefOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// JobDefOf: unbounded fn Lx, Text, [FnClause], Scheme -> JobDef
/// ```
pub struct JobDefOf {
    pub lx: crate::lower::Lx,
    pub qk: Text,
    pub clauses: Array<crate::syntax::decls::FnClause>,
    pub sc: crate::check::types::Scheme,
}

impl prism_rtl::Job<crate::lower::model::JobDef> for JobDefOf {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::JobDef> {
        let lx = &self.lx;
        let qk = &self.qk;
        let clauses = &self.clauses;
        let sc = &self.sc;
        let (ptys, res) = match &sc.ty {
            crate::check::types::Ty::TyFn(_, ps, r) => (ps.clone(), (**r).clone()),
            other => (Array::new(), other.clone()),
        };
        let clauses = clauses.clone();
        let lx = lx.clone();
        let qk = qk.clone();
        let sc = sc.clone();
        call_value(each_job(ptys.clone(), {
            let lx = lx.clone();
            Rc::new(move |p0: crate::check::types::Ty| {
                let lx = lx.clone();
                entered(once_job(move || {
                    let p_ = p0;
                    prism_rtl::Turn::More(Rc::new(crate::lower::types::OutTyOf { lx: lx.clone(), t: crate::lower::types::peel(&p_) }))
                }))
            }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::lower::model::OutTy>>>
        }), move |each_32065: Array<crate::lower::model::OutTy>| {
            let pts = each_32065;
            let names = crate::lower::functions::param_names(&lx, &clauses, &pts);
            call_then(start_job_clauses(lx.clone(), clauses.clone(), names.clone(), ptys.clone(), pts.clone()), move |job_clauses_32161: crate::lower::model::Ex| {
                let body = job_clauses_32161;
                let base = or(&get(&lx.rs_names, &qk), &crate::lower::snake(&crate::check::types::bare_name(&qk)));
                call_then(crate::lower::types::start_out_ty_of(lx.clone(), crate::lower::types::peel(&res)), move |out_ty_of_32472: crate::lower::model::OutTy| prism_rtl::Turn::Finished(crate::lower::model::JobDef { name: crate::lower::camel(&crate::check::types::bare_name(&qk)), start: Text::from(format!("start_{}", &base)), generics: crate::lower::functions::scheme_generics(&lx, &sc), fields: each(&crate::check::errors::range0(&len(&pts)), &(|i: &Nat| (or(&index(&each(&names, &(|(n, _): &(Text, bool)| n.clone())), i), &Text::lit("arg")), or(&index(&pts, i), &crate::lower::model::OutTy::OutUnit)))), ret: out_ty_of_32472, body: body.clone(), doc: crate::lower::functions::signature_text(&lx, &qk) }))
            })
        })
    }
}

/// `Start JobDefOf, x`: what the function value is when passed to `@Run`.
pub fn start_job_def_of(lx: crate::lower::Lx, qk: Text, clauses: Array<crate::syntax::decls::FnClause>, sc: crate::check::types::Scheme) -> Rc<dyn prism_rtl::Job<crate::lower::model::JobDef>> {
    Rc::new(JobDefOf { lx, qk, clauses, sc })
}

/// ```prism
/// JobClauses: unbounded fn Lx, [FnClause], [((Text, Bool))], [Ty], [OutTy] -> Ex
/// ```
pub fn job_clauses(lx: &crate::lower::Lx, clauses: &Array<crate::syntax::decls::FnClause>, names: &Array<(Text, bool)>, ptys: &Array<crate::check::types::Ty>, pts: &Array<crate::lower::model::OutTy>) -> crate::lower::model::Ex {
    let lets = each(&crate::check::errors::range0(&len(names)), &(|i: &Nat| {
        let (rs, _) = or(&index(names, i), &(Text::lit("arg"), true));
        crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(rs.clone()), crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), rs.clone()))))
    }));
    let inner = crate::lower::functions::clauses_body(lx, &crate::lower::types::empty_env(), clauses, names, ptys, &(Rc::new(|(a0, a1, a2): (crate::lower::Lx, crate::lower::types::Env, crate::syntax::decls::FnBody)| entered(start_tail_body(a0, a1, a2))) as Rc<dyn Fn((crate::lower::Lx, crate::lower::types::Env, crate::syntax::decls::FnBody)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>), &Text::lit("j"), &crate::lower::model::OutTy::OutUnknown(Text::lit("the job's turn")));
    crate::lower::model::Ex::XBlock(lets.clone(), Rc::new(inner.clone()))
}

/// The step machine of `JobClauses`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// JobClauses: unbounded fn Lx, [FnClause], [((Text, Bool))], [Ty], [OutTy] -> Ex
/// ```
pub struct JobClauses {
    pub lx: crate::lower::Lx,
    pub clauses: Array<crate::syntax::decls::FnClause>,
    pub names: Array<(Text, bool)>,
    pub ptys: Array<crate::check::types::Ty>,
    pub pts: Array<crate::lower::model::OutTy>,
}

impl prism_rtl::Job<crate::lower::model::Ex> for JobClauses {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::Ex> {
        let lx = &self.lx;
        let clauses = &self.clauses;
        let names = &self.names;
        let ptys = &self.ptys;
        let pts = &self.pts;
        let lets = each(&crate::check::errors::range0(&len(names)), &(|i: &Nat| {
            let (rs, _) = or(&index(names, i), &(Text::lit("arg"), true));
            crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(rs.clone()), crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), rs.clone()))))
        }));
        let clauses = clauses.clone();
        let lx = lx.clone();
        let names = names.clone();
        let ptys = ptys.clone();
        call_then(crate::lower::functions::start_clauses_body(lx.clone(), crate::lower::types::empty_env(), clauses.clone(), names.clone(), ptys.clone(), Rc::new(|(a0, a1, a2): (crate::lower::Lx, crate::lower::types::Env, crate::syntax::decls::FnBody)| entered(start_tail_body(a0, a1, a2))) as Rc<dyn Fn((crate::lower::Lx, crate::lower::types::Env, crate::syntax::decls::FnBody)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>, Text::lit("j"), crate::lower::model::OutTy::OutUnknown(Text::lit("the job's turn"))), move |clauses_body_32901: crate::lower::model::Ex| {
            let inner = clauses_body_32901;
            prism_rtl::Turn::Finished(crate::lower::model::Ex::XBlock(lets.clone(), Rc::new(inner.clone())))
        })
    }
}

/// `Start JobClauses, x`: what the function value is when passed to `@Run`.
pub fn start_job_clauses(lx: crate::lower::Lx, clauses: Array<crate::syntax::decls::FnClause>, names: Array<(Text, bool)>, ptys: Array<crate::check::types::Ty>, pts: Array<crate::lower::model::OutTy>) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>> {
    Rc::new(JobClauses { lx, clauses, names, ptys, pts })
}
