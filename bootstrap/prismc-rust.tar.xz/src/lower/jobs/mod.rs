//! The module `Lower.Jobs`, from `target/bootstrap/src/prismc/lower/jobs.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file. The runtime
//! side is reached from the crate, `crate::prelude` (and through it `::prism_rtl`), the
//! standard library from `::std`, and nothing is imported by name: a program's own type
//! (`Row`, `Option`) hides none of theirs. The traits are in scope unnamed, for their methods.

use crate::prelude::traits::*;

/// ```prism
/// Tail: unbounded fn Lx, Env, Expr -> Ex
/// ```
pub fn tail_f(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, e_p2: &crate::syntax::Expr) -> crate::lower::model::Ex {
    match frame_call_o(lx_p0, env_p1, e_p2, &true) {
        ::std::option::Option::Some(c_p3) => frame_f(lx_p0, env_p1, &c_p3, &rest_reads_f(lx_p0, &e_p2.span_p, &c_p3.span_p, &e_p2.span_p), &{
            let lx_p0x = lx_p0.clone();
            let e_p2x = e_p2.clone();
            ::std::rc::Rc::new(move |p0: crate::lower::types::Env| {
                let lx_p0xy = lx_p0x.clone();
                let e_p2xy = e_p2x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let env2_p4 = p0;
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(Tail { lx_p0: lx_p0xy.clone(), env_p1: env2_p4.clone(), e_p2: e_p2xy.clone() }))
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::types::Env) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>>>
        }),
        ::std::option::Option::None => tail_here_f(lx_p0, env_p1, e_p2),
    }
}

/// The step machine of `Tail`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Tail: unbounded fn Lx, Env, Expr -> Ex
/// ```
pub struct Tail {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub e_p2: crate::syntax::Expr,
}

impl ::prism_rtl::Job<crate::lower::model::Ex> for Tail {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::lower::model::Ex> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let e_p2 = &self.e_p2;
        let e_p2x = e_p2.clone();
        let env_p1x = env_p1.clone();
        let lx_p0x = lx_p0.clone();
        crate::prelude::call_then(start_frame_call_o(lx_p0x.clone(), env_p1x.clone(), e_p2x.clone(), true), move |frame_call_o_1854: ::std::option::Option<crate::syntax::Expr>| match frame_call_o_1854 {
            ::std::option::Option::Some(c_p3) => ::prism_rtl::Turn::More(::std::rc::Rc::new(Frame { lx_p0: lx_p0x.clone(), env_p1: env_p1x.clone(), call_p2: c_p3.clone(), rest_reads_p3: rest_reads_f(&lx_p0x, &e_p2x.span_p, &c_p3.span_p, &e_p2x.span_p), cont_f4: {
                let lx_p0xx = lx_p0x.clone();
                let e_p2xx = e_p2x.clone();
                ::std::rc::Rc::new(move |p0: crate::lower::types::Env| {
                    let lx_p0xxy = lx_p0xx.clone();
                    let e_p2xxy = e_p2xx.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let env2_p4 = p0;
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(Tail { lx_p0: lx_p0xxy.clone(), env_p1: env2_p4.clone(), e_p2: e_p2xxy.clone() }))
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::types::Env) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>>>
            } })),
            ::std::option::Option::None => ::prism_rtl::Turn::More(::std::rc::Rc::new(TailHere { lx_p0: lx_p0x.clone(), env_p1: env_p1x.clone(), e_p2: e_p2x.clone() })),
        })
    }
}

/// `Start Tail, x`: what the function value is when passed to `@Run`.
pub fn start_tail_f(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, e_p2: crate::syntax::Expr) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>> {
    ::std::rc::Rc::new(Tail { lx_p0, env_p1, e_p2 })
}

/// ```prism
/// TailHere: unbounded fn Lx, Env, Expr -> Ex
/// ```
pub fn tail_here_f(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, e_p2: &crate::syntax::Expr) -> crate::lower::model::Ex {
    'm2073: {
        let scrutinee = &*e_p2.kind_p;
        if let crate::syntax::ExprKind::EGroup(x_p3) = scrutinee {
            break 'm2073 tail_f(lx_p0, env_p1, &**x_p3);
        }
        if let crate::syntax::ExprKind::EUpdate(target_p4, b_p5) = scrutinee {
            break 'm2073 if has_top_while_f(lx_p0, b_p5) {
                upd_tail_f(lx_p0, env_p1, &**target_p4, b_p5, &e_p2.span_p, &(::std::rc::Rc::new(move |(p0, p1): (crate::lower::types::Env, crate::lower::model::Ex)| crate::prelude::once_job(move || {
                    let en_p6 = p0;
                    let v_p7 = p1;
                    ::prism_rtl::Turn::Finished(crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("prism_rtl::Turn::Finished")), crate::prelude::Array::from(vec![v_p7.clone()])))
                })) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::types::Env, crate::lower::model::Ex)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>>>))
            } else {
                crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("prism_rtl::Turn::Finished")), crate::prelude::Array::from(vec![crate::lower::types::own_f(&crate::lower::expr::value_of_f(lx_p0, env_p1, e_p2))]))
            };
        }
        if let crate::syntax::ExprKind::EMatch(s_p8, arms_p9) = scrutinee {
            break 'm2073 tail_match_f(lx_p0, env_p1, &**s_p8, arms_p9, &e_p2.span_p);
        }
        if let crate::syntax::ExprKind::EIf(m2073_3_0, then_b_pb, ::std::option::Option::Some(else_b_pc)) = scrutinee && let crate::syntax::Cond::CondExpr(c_pa) = &**m2073_3_0 {
            break 'm2073 crate::lower::model::Ex::XIf(::std::rc::Rc::new(crate::lower::types::as_bool_f(&crate::lower::expr::value_of_f(lx_p0, env_p1, &**c_pa))), ::std::rc::Rc::new(tail_block_f(lx_p0, env_p1, then_b_pb)), ::std::rc::Rc::new(tail_block_f(lx_p0, env_p1, else_b_pc)));
        }
        if let crate::syntax::ExprKind::EBinary(op_pd, l_pe, r_pf) = scrutinee && (((op_pd == &crate::prelude::Text::lit("and")) || (op_pd == &crate::prelude::Text::lit("or"))) && any_job_f(lx_p0, env_p1, &**r_pf)) {
            break 'm2073 {
                let shortcut_pg = crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("prism_rtl::Turn::Finished")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XBool(op_pd == &crate::prelude::Text::lit("or"))]));
                if op_pd == &crate::prelude::Text::lit("and") {
                    crate::lower::model::Ex::XIf(::std::rc::Rc::new(crate::lower::types::as_bool_f(&crate::lower::expr::value_of_f(lx_p0, env_p1, &**l_pe))), ::std::rc::Rc::new(tail_f(lx_p0, env_p1, &**r_pf)), ::std::rc::Rc::new(shortcut_pg.clone()))
                } else {
                    crate::lower::model::Ex::XIf(::std::rc::Rc::new(crate::lower::types::as_bool_f(&crate::lower::expr::value_of_f(lx_p0, env_p1, &**l_pe))), ::std::rc::Rc::new(shortcut_pg.clone()), ::std::rc::Rc::new(tail_f(lx_p0, env_p1, &**r_pf)))
                }
            };
        }
        if let crate::syntax::ExprKind::ECall(callee_ph, args_pi, _, _) = scrutinee {
            break 'm2073 match tail_callee_o(lx_p0, env_p1, &**callee_ph) {
                ::std::option::Option::Some(qk_pj) => {
                    let job_pk = crate::prelude::or(&crate::prelude::get(&lx_p0.rs_names_p, &qk_pj), &crate::lower::snake_f(&crate::check::types::bare_name_f(&qk_pj)));
                    let job_name_pl = crate::lower::ref_in_f(lx_p0, &crate::lower::owner_of_f(&qk_pj), &crate::lower::camel_f(&crate::check::types::bare_name_f(&qk_pj)));
                    let (ptys_po, _) = scheme_parts_f(lx_p0, &qk_pj);
                    let fields_pm = job_field_names_f(lx_p0, &qk_pj);
                    let vals_pn = crate::lower::expr::named_args_owned_f(lx_p0, env_p1, &qk_pj, args_pi);
                    if crate::lower::program::enters_at_once_f(lx_p0, &qk_pj, args_pi) {
                        crate::lower::model::Ex::XMethod(::std::rc::Rc::new(start_of_f(lx_p0, &qk_pj, &**callee_ph, &vals_pn)), crate::prelude::Text::lit("cycle"), crate::prelude::Array::new())
                    } else {
                        if crate::lower::program::is_color_poly_f(lx_p0, &qk_pj) || job_by_start_f(lx_p0, &qk_pj) {
                            crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("prism_rtl::Turn::More")), crate::prelude::Array::from(vec![start_of_f(lx_p0, &qk_pj, &**callee_ph, &vals_pn)]))
                        } else {
                            crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("prism_rtl::Turn::More")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Rc::new")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XRecord(job_name_pl.clone(), crate::prelude::each(&crate::check::errors::range0_f(&crate::prelude::len(&vals_pn)), &(|i_pp: &crate::prelude::Nat| (crate::prelude::or(&crate::prelude::index(&fields_pm, i_pp), &crate::prelude::Text::lit("arg")), crate::prelude::or(&crate::prelude::index(&vals_pn, i_pp), &crate::lower::model::Ex::XUnit)))))]))]))
                        }
                    }
                },
                ::std::option::Option::None => match local_job_fn_o(lx_p0, env_p1, &**callee_ph) {
                    ::std::option::Option::Some(f_pq) => crate::lower::model::Ex::XMethod(::std::rc::Rc::new(start_call_f(&f_pq, &crate::lower::expr::start_args_f(lx_p0, env_p1, &f_pq, args_pi))), crate::prelude::Text::lit("cycle"), crate::prelude::Array::new()),
                    ::std::option::Option::None => match crate::lower::expr::prelude_job_call_o(lx_p0, env_p1, e_p2) {
                        ::std::option::Option::Some(job_pr) => crate::lower::model::Ex::XMethod(::std::rc::Rc::new(job_pr), crate::prelude::Text::lit("cycle"), crate::prelude::Array::new()),
                        ::std::option::Option::None => crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("prism_rtl::Turn::Finished")), crate::prelude::Array::from(vec![crate::lower::types::own_f(&crate::lower::expr::value_of_f(lx_p0, env_p1, e_p2))])),
                    },
                },
            };
        }
        crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("prism_rtl::Turn::Finished")), crate::prelude::Array::from(vec![crate::lower::types::own_f(&crate::lower::expr::value_of_f(lx_p0, env_p1, e_p2))]))
    }
}

/// The step machine of `TailHere`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TailHere: unbounded fn Lx, Env, Expr -> Ex
/// ```
pub struct TailHere {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub e_p2: crate::syntax::Expr,
}

impl ::prism_rtl::Job<crate::lower::model::Ex> for TailHere {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::lower::model::Ex> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let e_p2 = &self.e_p2;
        'm2073: {
            let scrutinee = &*e_p2.kind_p;
            if let crate::syntax::ExprKind::EGroup(x_p3) = scrutinee {
                break 'm2073 ::prism_rtl::Turn::More(::std::rc::Rc::new(Tail { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), e_p2: (**x_p3).clone() }));
            }
            if let crate::syntax::ExprKind::EUpdate(target_p4, b_p5) = scrutinee {
                break 'm2073 if has_top_while_f(lx_p0, b_p5) {
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(UpdTail { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), target_p2: (**target_p4).clone(), b_p3: b_p5.clone(), to_p4: e_p2.span_p.clone(), cont_f5: ::std::rc::Rc::new(move |(p0, p1): (crate::lower::types::Env, crate::lower::model::Ex)| crate::prelude::once_job(move || {
                        let en_p6 = p0;
                        let v_p7 = p1;
                        ::prism_rtl::Turn::Finished(crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("prism_rtl::Turn::Finished")), crate::prelude::Array::from(vec![v_p7.clone()])))
                    })) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::types::Env, crate::lower::model::Ex)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>>> }))
                } else {
                    {
                        let e_p2x = e_p2.clone();
                        let env_p1x = env_p1.clone();
                        let lx_p0x = lx_p0.clone();
                        crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p0x.clone(), env_p1x.clone(), e_p2x.clone()), move |value_of_f_2338: crate::lower::types::Vl| ::prism_rtl::Turn::Finished(crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("prism_rtl::Turn::Finished")), crate::prelude::Array::from(vec![crate::lower::types::own_f(&value_of_f_2338)]))))
                    }
                };
            }
            if let crate::syntax::ExprKind::EMatch(s_p8, arms_p9) = scrutinee {
                break 'm2073 ::prism_rtl::Turn::More(::std::rc::Rc::new(TailMatch { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), s_p2: (**s_p8).clone(), arms_p3: arms_p9.clone(), span_p4: e_p2.span_p.clone() }));
            }
            if let crate::syntax::ExprKind::EIf(m2073_3_0, then_b_pb, ::std::option::Option::Some(else_b_pc)) = scrutinee && let crate::syntax::Cond::CondExpr(c_pa) = &**m2073_3_0 {
                break 'm2073 {
                    let c_pax = (**c_pa).clone();
                    let else_b_pcx = else_b_pc.clone();
                    let env_p1x = env_p1.clone();
                    let lx_p0x = lx_p0.clone();
                    let then_b_pbx = then_b_pb.clone();
                    crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p0x.clone(), env_p1x.clone(), c_pax.clone()), move |value_of_f_2468: crate::lower::types::Vl| crate::prelude::call_then(start_tail_block_f(lx_p0x.clone(), env_p1x.clone(), then_b_pbx.clone()), move |tail_block_f_2491: crate::lower::model::Ex| crate::prelude::call_then(start_tail_block_f(lx_p0x.clone(), env_p1x.clone(), else_b_pcx.clone()), move |tail_block_f_2519: crate::lower::model::Ex| ::prism_rtl::Turn::Finished(crate::lower::model::Ex::XIf(::std::rc::Rc::new(crate::lower::types::as_bool_f(&value_of_f_2468)), ::std::rc::Rc::new(tail_block_f_2491), ::std::rc::Rc::new(tail_block_f_2519))))))
                };
            }
            if let crate::syntax::ExprKind::EBinary(op_pd, l_pe, r_pf) = scrutinee && (((op_pd == &crate::prelude::Text::lit("and")) || (op_pd == &crate::prelude::Text::lit("or"))) && any_job_f(lx_p0, env_p1, &**r_pf)) {
                break 'm2073 {
                    let shortcut_pg = crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("prism_rtl::Turn::Finished")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XBool(op_pd == &crate::prelude::Text::lit("or"))]));
                    if op_pd == &crate::prelude::Text::lit("and") {
                        {
                            let env_p1x = env_p1.clone();
                            let l_pex = (**l_pe).clone();
                            let lx_p0x = lx_p0.clone();
                            let r_pfx = (**r_pf).clone();
                            crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p0x.clone(), env_p1x.clone(), l_pex.clone()), move |value_of_f_2820: crate::lower::types::Vl| crate::prelude::call_then(start_tail_f(lx_p0x.clone(), env_p1x.clone(), r_pfx.clone()), move |tail_f_2843: crate::lower::model::Ex| ::prism_rtl::Turn::Finished(crate::lower::model::Ex::XIf(::std::rc::Rc::new(crate::lower::types::as_bool_f(&value_of_f_2820)), ::std::rc::Rc::new(tail_f_2843), ::std::rc::Rc::new(shortcut_pg.clone())))))
                        }
                    } else {
                        {
                            let env_p1x = env_p1.clone();
                            let l_pex = (**l_pe).clone();
                            let lx_p0x = lx_p0.clone();
                            let r_pfx = (**r_pf).clone();
                            crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p0x.clone(), env_p1x.clone(), l_pex.clone()), move |value_of_f_2897: crate::lower::types::Vl| crate::prelude::call_then(start_tail_f(lx_p0x.clone(), env_p1x.clone(), r_pfx.clone()), move |tail_f_2930: crate::lower::model::Ex| ::prism_rtl::Turn::Finished(crate::lower::model::Ex::XIf(::std::rc::Rc::new(crate::lower::types::as_bool_f(&value_of_f_2897)), ::std::rc::Rc::new(shortcut_pg.clone()), ::std::rc::Rc::new(tail_f_2930)))))
                        }
                    }
                };
            }
            if let crate::syntax::ExprKind::ECall(callee_ph, args_pi, _, _) = scrutinee {
                break 'm2073 match tail_callee_o(lx_p0, env_p1, &**callee_ph) {
                    ::std::option::Option::Some(qk_pj) => {
                        let job_pk = crate::prelude::or(&crate::prelude::get(&lx_p0.rs_names_p, &qk_pj), &crate::lower::snake_f(&crate::check::types::bare_name_f(&qk_pj)));
                        let job_name_pl = crate::lower::ref_in_f(lx_p0, &crate::lower::owner_of_f(&qk_pj), &crate::lower::camel_f(&crate::check::types::bare_name_f(&qk_pj)));
                        let (ptys_po, _) = scheme_parts_f(lx_p0, &qk_pj);
                        let args_pix = args_pi.clone();
                        let callee_phx = (**callee_ph).clone();
                        let env_p1x = env_p1.clone();
                        let lx_p0x = lx_p0.clone();
                        crate::prelude::call_then(start_job_field_names_f(lx_p0x.clone(), qk_pj.clone()), move |job_field_names_f_3250: crate::prelude::Array<crate::prelude::Text>| {
                            let fields_pm = job_field_names_f_3250;
                            crate::prelude::call_then(crate::lower::expr::start_named_args_owned_f(lx_p0x.clone(), env_p1x.clone(), qk_pj.clone(), args_pix.clone()), move |named_args_owned_f_3294: crate::prelude::Array<crate::lower::model::Ex>| {
                                let vals_pn = named_args_owned_f_3294;
                                if crate::lower::program::enters_at_once_f(&lx_p0x, &qk_pj, &args_pix) {
                                    crate::prelude::call_then(start_start_of_f(lx_p0x.clone(), qk_pj.clone(), callee_phx.clone(), vals_pn.clone()), move |start_of_f_3378: crate::lower::model::Ex| ::prism_rtl::Turn::Finished(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(start_of_f_3378), crate::prelude::Text::lit("cycle"), crate::prelude::Array::new())))
                                } else {
                                    if crate::lower::program::is_color_poly_f(&lx_p0x, &qk_pj) || job_by_start_f(&lx_p0x, &qk_pj) {
                                        crate::prelude::call_then(start_start_of_f(lx_p0x.clone(), qk_pj.clone(), callee_phx.clone(), vals_pn.clone()), move |start_of_f_3534: crate::lower::model::Ex| ::prism_rtl::Turn::Finished(crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("prism_rtl::Turn::More")), crate::prelude::Array::from(vec![start_of_f_3534]))))
                                    } else {
                                        ::prism_rtl::Turn::Finished(crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("prism_rtl::Turn::More")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Rc::new")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XRecord(job_name_pl.clone(), crate::prelude::each(&crate::check::errors::range0_f(&crate::prelude::len(&vals_pn)), &(|i_pp: &crate::prelude::Nat| (crate::prelude::or(&crate::prelude::index(&fields_pm, i_pp), &crate::prelude::Text::lit("arg")), crate::prelude::or(&crate::prelude::index(&vals_pn, i_pp), &crate::lower::model::Ex::XUnit)))))]))])))
                                    }
                                }
                            })
                        })
                    },
                    ::std::option::Option::None => {
                        let args_pix = args_pi.clone();
                        let callee_phx = (**callee_ph).clone();
                        let e_p2x = e_p2.clone();
                        let env_p1x = env_p1.clone();
                        let lx_p0x = lx_p0.clone();
                        crate::prelude::call_then(start_local_job_fn_o(lx_p0x.clone(), env_p1x.clone(), callee_phx.clone()), move |local_job_fn_o_3793: ::std::option::Option<crate::lower::types::Vl>| match local_job_fn_o_3793 {
                            ::std::option::Option::Some(f_pq) => crate::prelude::call_then(crate::lower::expr::start_start_args_f(lx_p0x.clone(), env_p1x.clone(), f_pq.clone(), args_pix.clone()), move |start_args_f_3862: crate::prelude::Array<crate::lower::model::Ex>| ::prism_rtl::Turn::Finished(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(start_call_f(&f_pq, &start_args_f_3862)), crate::prelude::Text::lit("cycle"), crate::prelude::Array::new()))),
                            ::std::option::Option::None => crate::prelude::call_then(crate::lower::expr::start_prelude_job_call_o(lx_p0x.clone(), env_p1x.clone(), e_p2x.clone()), move |prelude_job_call_o_3929: ::std::option::Option<crate::lower::model::Ex>| match prelude_job_call_o_3929 {
                                ::std::option::Option::Some(job_pr) => ::prism_rtl::Turn::Finished(crate::lower::model::Ex::XMethod(::std::rc::Rc::new(job_pr.clone()), crate::prelude::Text::lit("cycle"), crate::prelude::Array::new())),
                                ::std::option::Option::None => crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p0x.clone(), env_p1x.clone(), e_p2x.clone()), move |value_of_f_4083: crate::lower::types::Vl| ::prism_rtl::Turn::Finished(crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("prism_rtl::Turn::Finished")), crate::prelude::Array::from(vec![crate::lower::types::own_f(&value_of_f_4083)])))),
                            }),
                        })
                    },
                };
            }
            {
                let e_p2x = e_p2.clone();
                let env_p1x = env_p1.clone();
                let lx_p0x = lx_p0.clone();
                crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p0x.clone(), env_p1x.clone(), e_p2x.clone()), move |value_of_f_4175: crate::lower::types::Vl| ::prism_rtl::Turn::Finished(crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("prism_rtl::Turn::Finished")), crate::prelude::Array::from(vec![crate::lower::types::own_f(&value_of_f_4175)]))))
            }
        }
    }
}

/// `Start TailHere, x`: what the function value is when passed to `@Run`.
pub fn start_tail_here_f(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, e_p2: crate::syntax::Expr) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>> {
    ::std::rc::Rc::new(TailHere { lx_p0, env_p1, e_p2 })
}

/// ```prism
/// TailBlock: unbounded fn Lx, Env, Block -> Ex
/// ```
pub fn tail_block_f(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, b_p2: &crate::syntax::Block) -> crate::lower::model::Ex {
    tail_from_f(lx_p0, env_p1, b_p2, &crate::prelude::Nat::from(0u32))
}

/// The step machine of `TailBlock`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TailBlock: unbounded fn Lx, Env, Block -> Ex
/// ```
pub struct TailBlock {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub b_p2: crate::syntax::Block,
}

impl ::prism_rtl::Job<crate::lower::model::Ex> for TailBlock {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::lower::model::Ex> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let b_p2 = &self.b_p2;
        ::prism_rtl::Turn::More(::std::rc::Rc::new(TailFrom { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), b_p2: b_p2.clone(), i_p3: crate::prelude::Nat::from(0u32) }))
    }
}

/// `Start TailBlock, x`: what the function value is when passed to `@Run`.
pub fn start_tail_block_f(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, b_p2: crate::syntax::Block) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>> {
    ::std::rc::Rc::new(TailBlock { lx_p0, env_p1, b_p2 })
}

/// ```prism
/// TailFrom: unbounded fn Lx, Env, Block, Nat -> Ex
/// ```
pub fn tail_from_f(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, b_p2: &crate::syntax::Block, i_p3: &crate::prelude::Nat) -> crate::lower::model::Ex {
    tail_from_k_f(lx_p0, env_p1, b_p2, i_p3, &{
        let lx_p0x = lx_p0.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::lower::types::Env, ::std::option::Option<crate::syntax::Expr>)| {
            let lx_p0xy = lx_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let en_p4 = p0;
                let x_o5 = p1;
                match &x_o5 {
                    ::std::option::Option::Some(x_p6) => ::prism_rtl::Turn::More(::std::rc::Rc::new(Tail { lx_p0: lx_p0xy.clone(), env_p1: en_p4.clone(), e_p2: x_p6.clone() })),
                    ::std::option::Option::None => ::prism_rtl::Turn::Finished(crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("prism_rtl::Turn::Finished")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XUnit]))),
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::types::Env, ::std::option::Option<crate::syntax::Expr>)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>>>
    })
}

/// The step machine of `TailFrom`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TailFrom: unbounded fn Lx, Env, Block, Nat -> Ex
/// ```
pub struct TailFrom {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub b_p2: crate::syntax::Block,
    pub i_p3: crate::prelude::Nat,
}

impl ::prism_rtl::Job<crate::lower::model::Ex> for TailFrom {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::lower::model::Ex> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let b_p2 = &self.b_p2;
        let i_p3 = &self.i_p3;
        ::prism_rtl::Turn::More(::std::rc::Rc::new(TailFromK { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), b_p2: b_p2.clone(), i_p3: i_p3.clone(), last_f4: {
            let lx_p0x = lx_p0.clone();
            ::std::rc::Rc::new(move |(p0, p1): (crate::lower::types::Env, ::std::option::Option<crate::syntax::Expr>)| {
                let lx_p0xy = lx_p0x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let en_p4 = p0;
                    let x_o5 = p1;
                    match &x_o5 {
                        ::std::option::Option::Some(x_p6) => ::prism_rtl::Turn::More(::std::rc::Rc::new(Tail { lx_p0: lx_p0xy.clone(), env_p1: en_p4.clone(), e_p2: x_p6.clone() })),
                        ::std::option::Option::None => ::prism_rtl::Turn::Finished(crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("prism_rtl::Turn::Finished")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XUnit]))),
                    }
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::types::Env, ::std::option::Option<crate::syntax::Expr>)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>>>
        } }))
    }
}

/// `Start TailFrom, x`: what the function value is when passed to `@Run`.
pub fn start_tail_from_f(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, b_p2: crate::syntax::Block, i_p3: crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>> {
    ::std::rc::Rc::new(TailFrom { lx_p0, env_p1, b_p2, i_p3 })
}

/// ```prism
/// TailFromK: unbounded fn Lx, Env, Block, Nat, (unbounded fn Env, ?Expr -> Ex) -> Ex
/// ```
pub fn tail_from_k_f(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, b_p2: &crate::syntax::Block, i_p3: &crate::prelude::Nat, last_f4: &::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::types::Env, ::std::option::Option<crate::syntax::Expr>)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>>>) -> crate::lower::model::Ex {
    let s_p5 = crate::prelude::or(&crate::prelude::index(&b_p2.stmts_p, i_p3), &crate::lower::expr::dummy_stmt_l_p());
    if &(i_p3 + &crate::prelude::Nat::from(1u32)) >= &crate::prelude::len(&b_p2.stmts_p) {
        match &s_p5.kind_p {
            crate::syntax::StmtKind::SExpr(x_p6) => crate::prelude::run_to_end(last_f4((env_p1.clone(), ::std::option::Option::Some(x_p6.clone())))),
            _ => {
                let (dos_p7, env2_p8) = crate::lower::expr::block_stmt_f(lx_p0, env_p1, &s_p5);
                prepend_f(&dos_p7, &crate::prelude::run_to_end(last_f4((env2_p8.clone(), ::std::option::Option::None))))
            },
        }
    } else {
        {
            let found_o9 = match &s_p5.kind_p {
                crate::syntax::StmtKind::SLet(_, _, x_pd) => frame_call_o(lx_p0, env_p1, x_pd, &false),
                crate::syntax::StmtKind::SExpr(x_pe) => frame_call_o(lx_p0, env_p1, x_pe, &false),
                _ => ::std::option::Option::None,
            };
            let looping_oa = match &s_p5.kind_p {
                crate::syntax::StmtKind::SLet(p_pf, _, x_pg) => match &*x_pg.kind_p {
                    crate::syntax::ExprKind::EUpdate(target_ph, ub_pi) => if has_top_while_f(lx_p0, ub_pi) {
                        ::std::option::Option::Some((p_pf.clone(), (**target_ph).clone(), ub_pi.clone(), x_pg.clone()))
                    } else {
                        ::std::option::Option::None
                    },
                    _ => ::std::option::Option::None,
                },
                _ => ::std::option::Option::None,
            };
            let generic_ob = match &s_p5.kind_p {
                crate::syntax::StmtKind::SLet(p_pj, _, x_pk) => match &*p_pj.kind_p {
                    crate::syntax::PatternKind::PName(n_pl) => match crate::prelude::get(&lx_p0.gens_p, &crate::lower::place_key_f(lx_p0, &n_pl.span_p)) {
                        ::std::option::Option::Some(gn_pm) => ::std::option::Option::Some((n_pl.clone(), gn_pm, x_pk.clone())),
                        ::std::option::Option::None => ::std::option::Option::None,
                    },
                    _ => ::std::option::Option::None,
                },
                _ => ::std::option::Option::None,
            };
            let branched_oc = match &s_p5.kind_p {
                crate::syntax::StmtKind::SLet(p_pn, _, x_po) => if branch_jobs_f(lx_p0, env_p1, x_po) {
                    ::std::option::Option::Some((::std::option::Option::Some(p_pn.clone()), x_po.clone()))
                } else {
                    ::std::option::Option::None
                },
                crate::syntax::StmtKind::SExpr(x_pp) => if branch_jobs_f(lx_p0, env_p1, x_pp) {
                    ::std::option::Option::Some((::std::option::Option::None, x_pp.clone()))
                } else {
                    ::std::option::Option::None
                },
                _ => ::std::option::Option::None,
            };
            match &looping_oa {
                ::std::option::Option::Some((p_pq, target_pr, ub_ps, x_pt)) => upd_tail_f(lx_p0, env_p1, target_pr, ub_ps, &b_p2.span_p, &{
                    let lx_p0x = lx_p0.clone();
                    let p_pqx = p_pq.clone();
                    let x_ptx = x_pt.clone();
                    let s_p5x = s_p5.clone();
                    let b_p2x = b_p2.clone();
                    let i_p3x = i_p3.clone();
                    let last_f4x = last_f4.clone();
                    ::std::rc::Rc::new(move |(p0, p1): (crate::lower::types::Env, crate::lower::model::Ex)| {
                        let lx_p0xy = lx_p0x.clone();
                        let p_pqxy = p_pqx.clone();
                        let x_ptxy = x_ptx.clone();
                        let s_p5xy = s_p5x.clone();
                        let b_p2xy = b_p2x.clone();
                        let i_p3xy = i_p3x.clone();
                        let last_f4xy = last_f4x.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let en_pu = p0;
                            let v_pv = p1;
                            crate::prelude::call_then(crate::lower::patterns::start_rust_pat_f(lx_p0xy.clone(), p_pqxy.clone(), crate::lower::type_at_f(&lx_p0xy, &x_ptxy.span_p), crate::lower::types::Holding::Owned, crate::prelude::Text::from(format!("l{}", &s_p5xy.span_p.start_p))), move |rust_pat_f_6275: crate::lower::patterns::PatOut| {
                                let po_p10 = rust_pat_f_6275;
                                crate::prelude::call_then(start_tail_from_k_f(lx_p0xy.clone(), crate::lower::expr::bind_all_f(&en_pu, &po_p10.binds_p), b_p2xy.clone(), &i_p3xy + &crate::prelude::Nat::from(1u32), last_f4xy.clone()), move |tail_from_k_f_6367: crate::lower::model::Ex| {
                                    let rest_p11 = tail_from_k_f_6367;
                                    ::prism_rtl::Turn::Finished(prepend_f(&crate::prelude::Array::from(vec![crate::lower::model::Do::DoLet(po_p10.pa_p.clone(), v_pv.clone())]), &rest_p11))
                                })
                            })
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::types::Env, crate::lower::model::Ex)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>>>
                }),
                ::std::option::Option::None => match &generic_ob {
                    ::std::option::Option::Some((n_p12, gn_p13, x_p14)) => generic_let_tail_f(lx_p0, env_p1, b_p2, &s_p5, n_p12, gn_p13, x_p14, &crate::prelude::Nat::from(0u32), &{
                        let lx_p0x = lx_p0.clone();
                        let b_p2x = b_p2.clone();
                        let i_p3x = i_p3.clone();
                        let last_f4x = last_f4.clone();
                        ::std::rc::Rc::new(move |p0: crate::lower::types::Env| {
                            let lx_p0xy = lx_p0x.clone();
                            let b_p2xy = b_p2x.clone();
                            let i_p3xy = i_p3x.clone();
                            let last_f4xy = last_f4x.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let env2_p15 = p0;
                                ::prism_rtl::Turn::More(::std::rc::Rc::new(TailFromK { lx_p0: lx_p0xy.clone(), env_p1: env2_p15.clone(), b_p2: b_p2xy.clone(), i_p3: &i_p3xy + &crate::prelude::Nat::from(1u32), last_f4: last_f4xy.clone() }))
                            }))
                        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::types::Env) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>>>
                    }),
                    ::std::option::Option::None => match &found_o9 {
                        ::std::option::Option::Some(c_p16) => frame_f(lx_p0, env_p1, c_p16, &rest_reads_f(lx_p0, &s_p5.span_p, &c_p16.span_p, &b_p2.span_p), &{
                            let lx_p0x = lx_p0.clone();
                            let b_p2x = b_p2.clone();
                            let i_p3x = i_p3.clone();
                            let last_f4x = last_f4.clone();
                            ::std::rc::Rc::new(move |p0: crate::lower::types::Env| {
                                let lx_p0xy = lx_p0x.clone();
                                let b_p2xy = b_p2x.clone();
                                let i_p3xy = i_p3x.clone();
                                let last_f4xy = last_f4x.clone();
                                crate::prelude::entered(crate::prelude::once_job(move || {
                                    let env2_p17 = p0;
                                    ::prism_rtl::Turn::More(::std::rc::Rc::new(TailFromK { lx_p0: lx_p0xy.clone(), env_p1: env2_p17.clone(), b_p2: b_p2xy.clone(), i_p3: i_p3xy.clone(), last_f4: last_f4xy.clone() }))
                                }))
                            }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::types::Env) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>>>
                        }),
                        ::std::option::Option::None => match &branched_oc {
                            ::std::option::Option::Some((p_o18, x_p19)) => kstmt_f(lx_p0, env_p1, b_p2, i_p3, &s_p5, p_o18, x_p19, &last_f4.clone()),
                            ::std::option::Option::None => {
                                let (dos_p1a, env2_p1b) = crate::lower::expr::block_stmt_f(lx_p0, env_p1, &s_p5);
                                match tail_from_k_f(lx_p0, &env2_p1b, b_p2, &(i_p3 + &crate::prelude::Nat::from(1u32)), &last_f4.clone()) {
                                    crate::lower::model::Ex::XBlock(more_p1c, last_p1d) => crate::lower::model::Ex::XBlock(crate::prelude::append(&dos_p1a, &more_p1c), ::std::rc::Rc::new((*last_p1d).clone())),
                                    last_p1e => if &crate::prelude::len(&dos_p1a) == &crate::prelude::Nat::from(0u32) {
                                        last_p1e.clone()
                                    } else {
                                        crate::lower::model::Ex::XBlock(dos_p1a.clone(), ::std::rc::Rc::new(last_p1e.clone()))
                                    },
                                }
                            },
                        },
                    },
                },
            }
        }
    }
}

/// The step machine of `TailFromK`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TailFromK: unbounded fn Lx, Env, Block, Nat, (unbounded fn Env, ?Expr -> Ex) -> Ex
/// ```
pub struct TailFromK {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub b_p2: crate::syntax::Block,
    pub i_p3: crate::prelude::Nat,
    pub last_f4: ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::types::Env, ::std::option::Option<crate::syntax::Expr>)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>>>,
}

impl ::prism_rtl::Job<crate::lower::model::Ex> for TailFromK {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::lower::model::Ex> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let b_p2 = &self.b_p2;
        let i_p3 = &self.i_p3;
        let last_f4 = &self.last_f4;
        let s_p5 = crate::prelude::or(&crate::prelude::index(&b_p2.stmts_p, i_p3), &crate::lower::expr::dummy_stmt_l_p());
        if &(i_p3 + &crate::prelude::Nat::from(1u32)) >= &crate::prelude::len(&b_p2.stmts_p) {
            match &s_p5.kind_p {
                crate::syntax::StmtKind::SExpr(x_p6) => last_f4((env_p1.clone(), ::std::option::Option::Some(x_p6.clone()))).cycle(),
                _ => {
                    let last_f4x = last_f4.clone();
                    let env_p1x = env_p1.clone();
                    let lx_p0x = lx_p0.clone();
                    crate::prelude::call_then(crate::lower::expr::start_block_stmt_f(lx_p0x.clone(), env_p1x.clone(), s_p5.clone()), move |block_stmt_f_5154: (crate::prelude::Array<crate::lower::model::Do>, crate::lower::types::Env)| {
                        let (dos_p7, env2_p8) = block_stmt_f_5154;
                        crate::prelude::call_value((&last_f4x)((env2_p8.clone(), ::std::option::Option::None)), move |last_5201: crate::lower::model::Ex| ::prism_rtl::Turn::Finished(prepend_f(&dos_p7, &last_5201)))
                    })
                },
            }
        } else {
            {
                let last_f4z = last_f4.clone();
                let b_p2z = b_p2.clone();
                let env_p1z = env_p1.clone();
                let i_p3z = i_p3.clone();
                let lx_p0z = lx_p0.clone();
                let s_p5z = s_p5.clone();
                let k_let5235 = move |v5235: ::std::option::Option<crate::syntax::Expr>| {
                    let found_o9 = v5235;
                    let looping_oa = match &s_p5z.kind_p {
                        crate::syntax::StmtKind::SLet(p_pf, _, x_pg) => match &*x_pg.kind_p {
                            crate::syntax::ExprKind::EUpdate(target_ph, ub_pi) => if has_top_while_f(&lx_p0z, ub_pi) {
                                ::std::option::Option::Some((p_pf.clone(), (**target_ph).clone(), ub_pi.clone(), x_pg.clone()))
                            } else {
                                ::std::option::Option::None
                            },
                            _ => ::std::option::Option::None,
                        },
                        _ => ::std::option::Option::None,
                    };
                    let generic_ob = match &s_p5z.kind_p {
                        crate::syntax::StmtKind::SLet(p_pj, _, x_pk) => match &*p_pj.kind_p {
                            crate::syntax::PatternKind::PName(n_pl) => match crate::prelude::get(&lx_p0z.gens_p, &crate::lower::place_key_f(&lx_p0z, &n_pl.span_p)) {
                                ::std::option::Option::Some(gn_pm) => ::std::option::Option::Some((n_pl.clone(), gn_pm, x_pk.clone())),
                                ::std::option::Option::None => ::std::option::Option::None,
                            },
                            _ => ::std::option::Option::None,
                        },
                        _ => ::std::option::Option::None,
                    };
                    let found_o9z = found_o9.clone();
                    let generic_obz = generic_ob.clone();
                    let looping_oaz = looping_oa.clone();
                    let last_f4zz = last_f4z.clone();
                    let b_p2zz = b_p2z.clone();
                    let env_p1zz = env_p1z.clone();
                    let i_p3zz = i_p3z.clone();
                    let lx_p0zz = lx_p0z.clone();
                    let s_p5zz = s_p5z.clone();
                    let k_let5915 = move |v5915: ::std::option::Option<(::std::option::Option<crate::syntax::Pattern>, crate::syntax::Expr)>| {
                        let branched_oc = v5915;
                        match &looping_oaz {
                            ::std::option::Option::Some((p_pq, target_pr, ub_ps, x_pt)) => ::prism_rtl::Turn::More(::std::rc::Rc::new(UpdTail { lx_p0: lx_p0zz.clone(), env_p1: env_p1zz.clone(), target_p2: target_pr.clone(), b_p3: ub_ps.clone(), to_p4: b_p2zz.span_p.clone(), cont_f5: {
                                let lx_p0zzx = lx_p0zz.clone();
                                let p_pqx = p_pq.clone();
                                let x_ptx = x_pt.clone();
                                let s_p5zzx = s_p5zz.clone();
                                let b_p2zzx = b_p2zz.clone();
                                let i_p3zzx = i_p3zz.clone();
                                let last_f4zzx = last_f4zz.clone();
                                ::std::rc::Rc::new(move |(p0, p1): (crate::lower::types::Env, crate::lower::model::Ex)| {
                                    let lx_p0zzxy = lx_p0zzx.clone();
                                    let p_pqxy = p_pqx.clone();
                                    let x_ptxy = x_ptx.clone();
                                    let s_p5zzxy = s_p5zzx.clone();
                                    let b_p2zzxy = b_p2zzx.clone();
                                    let i_p3zzxy = i_p3zzx.clone();
                                    let last_f4zzxy = last_f4zzx.clone();
                                    crate::prelude::entered(crate::prelude::once_job(move || {
                                        let en_pu = p0;
                                        let v_pv = p1;
                                        crate::prelude::call_then(crate::lower::patterns::start_rust_pat_f(lx_p0zzxy.clone(), p_pqxy.clone(), crate::lower::type_at_f(&lx_p0zzxy, &x_ptxy.span_p), crate::lower::types::Holding::Owned, crate::prelude::Text::from(format!("l{}", &s_p5zzxy.span_p.start_p))), move |rust_pat_f_6275: crate::lower::patterns::PatOut| {
                                            let po_p10 = rust_pat_f_6275;
                                            crate::prelude::call_then(start_tail_from_k_f(lx_p0zzxy.clone(), crate::lower::expr::bind_all_f(&en_pu, &po_p10.binds_p), b_p2zzxy.clone(), &i_p3zzxy + &crate::prelude::Nat::from(1u32), last_f4zzxy.clone()), move |tail_from_k_f_6367: crate::lower::model::Ex| {
                                                let rest_p11 = tail_from_k_f_6367;
                                                ::prism_rtl::Turn::Finished(prepend_f(&crate::prelude::Array::from(vec![crate::lower::model::Do::DoLet(po_p10.pa_p.clone(), v_pv.clone())]), &rest_p11))
                                            })
                                        })
                                    }))
                                }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::types::Env, crate::lower::model::Ex)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>>>
                            } })),
                            ::std::option::Option::None => match &generic_obz {
                                ::std::option::Option::Some((n_p12, gn_p13, x_p14)) => ::prism_rtl::Turn::More(::std::rc::Rc::new(GenericLetTail { lx_p0: lx_p0zz.clone(), env_p1: env_p1zz.clone(), b_p2: b_p2zz.clone(), s_p3: s_p5zz.clone(), n_p4: n_p12.clone(), gn_p5: gn_p13.clone(), x_p6: x_p14.clone(), k_p7: crate::prelude::Nat::from(0u32), rest_f8: {
                                    let lx_p0zzx = lx_p0zz.clone();
                                    let b_p2zzx = b_p2zz.clone();
                                    let i_p3zzx = i_p3zz.clone();
                                    let last_f4zzx = last_f4zz.clone();
                                    ::std::rc::Rc::new(move |p0: crate::lower::types::Env| {
                                        let lx_p0zzxy = lx_p0zzx.clone();
                                        let b_p2zzxy = b_p2zzx.clone();
                                        let i_p3zzxy = i_p3zzx.clone();
                                        let last_f4zzxy = last_f4zzx.clone();
                                        crate::prelude::entered(crate::prelude::once_job(move || {
                                            let env2_p15 = p0;
                                            ::prism_rtl::Turn::More(::std::rc::Rc::new(TailFromK { lx_p0: lx_p0zzxy.clone(), env_p1: env2_p15.clone(), b_p2: b_p2zzxy.clone(), i_p3: &i_p3zzxy + &crate::prelude::Nat::from(1u32), last_f4: last_f4zzxy.clone() }))
                                        }))
                                    }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::types::Env) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>>>
                                } })),
                                ::std::option::Option::None => match &found_o9z {
                                    ::std::option::Option::Some(c_p16) => ::prism_rtl::Turn::More(::std::rc::Rc::new(Frame { lx_p0: lx_p0zz.clone(), env_p1: env_p1zz.clone(), call_p2: c_p16.clone(), rest_reads_p3: rest_reads_f(&lx_p0zz, &s_p5zz.span_p, &c_p16.span_p, &b_p2zz.span_p), cont_f4: {
                                        let lx_p0zzx = lx_p0zz.clone();
                                        let b_p2zzx = b_p2zz.clone();
                                        let i_p3zzx = i_p3zz.clone();
                                        let last_f4zzx = last_f4zz.clone();
                                        ::std::rc::Rc::new(move |p0: crate::lower::types::Env| {
                                            let lx_p0zzxy = lx_p0zzx.clone();
                                            let b_p2zzxy = b_p2zzx.clone();
                                            let i_p3zzxy = i_p3zzx.clone();
                                            let last_f4zzxy = last_f4zzx.clone();
                                            crate::prelude::entered(crate::prelude::once_job(move || {
                                                let env2_p17 = p0;
                                                ::prism_rtl::Turn::More(::std::rc::Rc::new(TailFromK { lx_p0: lx_p0zzxy.clone(), env_p1: env2_p17.clone(), b_p2: b_p2zzxy.clone(), i_p3: i_p3zzxy.clone(), last_f4: last_f4zzxy.clone() }))
                                            }))
                                        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::types::Env) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>>>
                                    } })),
                                    ::std::option::Option::None => match &branched_oc {
                                        ::std::option::Option::Some((p_o18, x_p19)) => ::prism_rtl::Turn::More(::std::rc::Rc::new(KStmt { lx_p0: lx_p0zz.clone(), env_p1: env_p1zz.clone(), b_p2: b_p2zz.clone(), i_p3: i_p3zz.clone(), s_p4: s_p5zz.clone(), p_o5: p_o18.clone(), x_p6: x_p19.clone(), last_f7: last_f4zz.clone() })),
                                        ::std::option::Option::None => crate::prelude::call_then(crate::lower::expr::start_block_stmt_f(lx_p0zz.clone(), env_p1zz.clone(), s_p5zz.clone()), move |block_stmt_f_7035: (crate::prelude::Array<crate::lower::model::Do>, crate::lower::types::Env)| {
                                            let (dos_p1a, env2_p1b) = block_stmt_f_7035;
                                            crate::prelude::call_then(start_tail_from_k_f(lx_p0zz.clone(), env2_p1b.clone(), b_p2zz.clone(), &i_p3zz + &crate::prelude::Nat::from(1u32), last_f4zz.clone()), move |tail_from_k_f_7086: crate::lower::model::Ex| match tail_from_k_f_7086 {
                                                crate::lower::model::Ex::XBlock(more_p1c, last_p1d) => ::prism_rtl::Turn::Finished(crate::lower::model::Ex::XBlock(crate::prelude::append(&dos_p1a, &more_p1c), ::std::rc::Rc::new((*last_p1d).clone()))),
                                                last_p1e => if &crate::prelude::len(&dos_p1a) == &crate::prelude::Nat::from(0u32) {
                                                    ::prism_rtl::Turn::Finished(last_p1e.clone())
                                                } else {
                                                    ::prism_rtl::Turn::Finished(crate::lower::model::Ex::XBlock(dos_p1a.clone(), ::std::rc::Rc::new(last_p1e.clone())))
                                                },
                                            })
                                        }),
                                    },
                                },
                            },
                        }
                    };
                    match s_p5z.kind_p.clone() {
                        crate::syntax::StmtKind::SLet(p_pn, _, x_po) => crate::prelude::call_then(start_branch_jobs_f(lx_p0z.clone(), env_p1z.clone(), x_po.clone()), move |branch_jobs_f_5979: bool| k_let5915(if branch_jobs_f_5979 {
                            ::std::option::Option::Some((::std::option::Option::Some(p_pn.clone()), x_po.clone()))
                        } else {
                            ::std::option::Option::None
                        })),
                        crate::syntax::StmtKind::SExpr(x_pp) => crate::prelude::call_then(start_branch_jobs_f(lx_p0z.clone(), env_p1z.clone(), x_pp.clone()), move |branch_jobs_f_6051: bool| k_let5915(if branch_jobs_f_6051 {
                            ::std::option::Option::Some((::std::option::Option::None, x_pp.clone()))
                        } else {
                            ::std::option::Option::None
                        })),
                        _ => k_let5915(::std::option::Option::None),
                    }
                };
                match s_p5.kind_p.clone() {
                    crate::syntax::StmtKind::SLet(_, _, x_pd) => {
                        let env_p1x = env_p1.clone();
                        let lx_p0x = lx_p0.clone();
                        crate::prelude::call_then(start_frame_call_o(lx_p0x.clone(), env_p1x.clone(), x_pd.clone(), false), move |frame_call_o_5298: ::std::option::Option<crate::syntax::Expr>| k_let5235(frame_call_o_5298))
                    },
                    crate::syntax::StmtKind::SExpr(x_pe) => {
                        let env_p1x = env_p1.clone();
                        let lx_p0x = lx_p0.clone();
                        crate::prelude::call_then(start_frame_call_o(lx_p0x.clone(), env_p1x.clone(), x_pe.clone(), false), move |frame_call_o_5348: ::std::option::Option<crate::syntax::Expr>| k_let5235(frame_call_o_5348))
                    },
                    _ => k_let5235(::std::option::Option::None),
                }
            }
        }
    }
}

/// `Start TailFromK, x`: what the function value is when passed to `@Run`.
pub fn start_tail_from_k_f(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, b_p2: crate::syntax::Block, i_p3: crate::prelude::Nat, last_f4: ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::types::Env, ::std::option::Option<crate::syntax::Expr>)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>>>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>> {
    ::std::rc::Rc::new(TailFromK { lx_p0, env_p1, b_p2, i_p3, last_f4 })
}

/// ```prism
/// GenericLetTail: unbounded fn Lx, Env, Block, Stmt, SName, GenNote, Expr, Nat, (unbounded fn Env -> Ex) -> Ex
/// ```
pub fn generic_let_tail_f(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, b_p2: &crate::syntax::Block, s_p3: &crate::syntax::Stmt, n_p4: &crate::syntax::SName, gn_p5: &crate::check::typed::GenNote, x_p6: &crate::syntax::Expr, k_p7: &crate::prelude::Nat, rest_f8: &::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::types::Env) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>>>) -> crate::lower::model::Ex {
    let distinct_p9 = crate::lower::expr::let_instantiations_f(lx_p0, gn_p5, x_p6);
    match crate::prelude::index(&distinct_p9, k_p7) {
        ::std::option::Option::None => crate::prelude::run_to_end(rest_f8(env_p1.clone())),
        ::std::option::Option::Some(inst_pa) => {
            let lxk_pb = crate::lower::expr::at_instance_f(lx_p0, &inst_pa);
            let last_pc = &(k_p7 + &crate::prelude::Nat::from(1u32)) >= &crate::prelude::len(&distinct_p9);
            let with_bound_fd = {
                let lx_p0x = lx_p0.clone();
                let n_p4x = n_p4.clone();
                let gn_p5x = gn_p5.clone();
                let x_p6x = x_p6.clone();
                let k_p7x = k_p7.clone();
                let last_pcx = last_pc;
                let b_p2x = b_p2.clone();
                let s_p3x = s_p3.clone();
                let rest_f8x = rest_f8.clone();
                ::std::rc::Rc::new(move |(p0, p1): (crate::lower::types::Env, crate::lower::model::Ex)| {
                    let lx_p0xy = lx_p0x.clone();
                    let n_p4xy = n_p4x.clone();
                    let gn_p5xy = gn_p5x.clone();
                    let x_p6xy = x_p6x.clone();
                    let k_p7xy = k_p7x.clone();
                    let last_pcxy = last_pcx;
                    let b_p2xy = b_p2x.clone();
                    let s_p3xy = s_p3x.clone();
                    let rest_f8xy = rest_f8x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let en_pe = p0;
                        let value_pf = p1;
                        crate::prelude::call_then(crate::lower::expr::start_generic_let_bound_f(lx_p0xy.clone(), en_pe.clone(), n_p4xy.clone(), gn_p5xy.clone(), x_p6xy.clone(), k_p7xy.clone(), value_pf.clone()), move |generic_let_bound_f_8368: (crate::prelude::Array<crate::lower::model::Do>, crate::lower::types::Env)| {
                            let (dos_ph, en2_pi) = generic_let_bound_f_8368;
                            let rest_f8xyz = rest_f8xy.clone();
                            let b_p2xyz = b_p2xy.clone();
                            let dos_phz = dos_ph.clone();
                            let gn_p5xyz = gn_p5xy.clone();
                            let k_p7xyz = k_p7xy.clone();
                            let lx_p0xyz = lx_p0xy.clone();
                            let n_p4xyz = n_p4xy.clone();
                            let s_p3xyz = s_p3xy.clone();
                            let x_p6xyz = x_p6xy.clone();
                            let k_let8427 = move |v8427: crate::lower::types::Env| {
                                let en3_pg = v8427;
                                crate::prelude::call_then(start_generic_let_tail_f(lx_p0xyz.clone(), en3_pg.clone(), b_p2xyz.clone(), s_p3xyz.clone(), n_p4xyz.clone(), gn_p5xyz.clone(), x_p6xyz.clone(), &k_p7xyz + &crate::prelude::Nat::from(1u32), rest_f8xyz.clone()), move |generic_let_tail_f_8608: crate::lower::model::Ex| ::prism_rtl::Turn::Finished(prepend_f(&dos_phz, &generic_let_tail_f_8608)))
                            };
                            if last_pcxy {
                                k_let8427(en2_pi.clone())
                            } else {
                                crate::prelude::call_then(crate::check::typed::print::start_exprs_in_f(x_p6xy.clone()), move |exprs_in_f_8462: crate::prelude::Array<crate::syntax::Expr>| k_let8427(crate::prelude::fold(&exprs_in_f_8462, &en2_pi, &(|e2_pj: &crate::lower::types::Env, inner_pk: &crate::syntax::Expr| {
                                    let mut this: crate::lower::types::Env = e2_pj.clone();
                                    this.spans_p = crate::prelude::remove(&this.spans_p, &crate::lower::place_key_f(&lx_p0xy, &inner_pk.span_p));
                                    this
                                }))))
                            }
                        })
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::types::Env, crate::lower::model::Ex)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>>>
            };
            match frame_call_o(&lxk_pb, env_p1, x_p6, &false) {
                ::std::option::Option::Some(c_pl) => frame_f(&lxk_pb, env_p1, &c_pl, &rest_reads_f(lx_p0, &s_p3.span_p, &c_pl.span_p, &b_p2.span_p), &{
                    let lx_p0x = lx_p0.clone();
                    let b_p2x = b_p2.clone();
                    let s_p3x = s_p3.clone();
                    let n_p4x = n_p4.clone();
                    let gn_p5x = gn_p5.clone();
                    let x_p6x = x_p6.clone();
                    let k_p7x = k_p7.clone();
                    let rest_f8x = rest_f8.clone();
                    ::std::rc::Rc::new(move |p0: crate::lower::types::Env| {
                        let lx_p0xy = lx_p0x.clone();
                        let b_p2xy = b_p2x.clone();
                        let s_p3xy = s_p3x.clone();
                        let n_p4xy = n_p4x.clone();
                        let gn_p5xy = gn_p5x.clone();
                        let x_p6xy = x_p6x.clone();
                        let k_p7xy = k_p7x.clone();
                        let rest_f8xy = rest_f8x.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let env2_pm = p0;
                            ::prism_rtl::Turn::More(::std::rc::Rc::new(GenericLetTail { lx_p0: lx_p0xy.clone(), env_p1: env2_pm.clone(), b_p2: b_p2xy.clone(), s_p3: s_p3xy.clone(), n_p4: n_p4xy.clone(), gn_p5: gn_p5xy.clone(), x_p6: x_p6xy.clone(), k_p7: k_p7xy.clone(), rest_f8: rest_f8xy.clone() }))
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::types::Env) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>>>
                }),
                ::std::option::Option::None => if branch_jobs_f(&lxk_pb, env_p1, x_p6) {
                    {
                        let from_pn = if last_pc {
                            crate::syntax::Range { start_p: s_p3.span_p.end_p.clone(), end_p: s_p3.span_p.end_p.clone() }
                        } else {
                            s_p3.span_p.clone()
                        };
                        kvalue_f(&lxk_pb, env_p1, &from_pn, b_p2, x_p6, &crate::prelude::Text::from(format!("{}w{}", &s_p3.span_p.start_p, k_p7)), &with_bound_fd.clone())
                    }
                } else {
                    crate::prelude::run_to_end((&with_bound_fd)((env_p1.clone(), crate::lower::types::own_f(&crate::lower::expr::value_of_f(&lxk_pb, env_p1, x_p6)))))
                },
            }
        },
    }
}

/// The step machine of `GenericLetTail`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// GenericLetTail: unbounded fn Lx, Env, Block, Stmt, SName, GenNote, Expr, Nat, (unbounded fn Env -> Ex) -> Ex
/// ```
pub struct GenericLetTail {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub b_p2: crate::syntax::Block,
    pub s_p3: crate::syntax::Stmt,
    pub n_p4: crate::syntax::SName,
    pub gn_p5: crate::check::typed::GenNote,
    pub x_p6: crate::syntax::Expr,
    pub k_p7: crate::prelude::Nat,
    pub rest_f8: ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::types::Env) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>>>,
}

impl ::prism_rtl::Job<crate::lower::model::Ex> for GenericLetTail {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::lower::model::Ex> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let b_p2 = &self.b_p2;
        let s_p3 = &self.s_p3;
        let n_p4 = &self.n_p4;
        let gn_p5 = &self.gn_p5;
        let x_p6 = &self.x_p6;
        let k_p7 = &self.k_p7;
        let rest_f8 = &self.rest_f8;
        let rest_f8x = rest_f8.clone();
        let b_p2x = b_p2.clone();
        let env_p1x = env_p1.clone();
        let gn_p5x = gn_p5.clone();
        let k_p7x = k_p7.clone();
        let lx_p0x = lx_p0.clone();
        let n_p4x = n_p4.clone();
        let s_p3x = s_p3.clone();
        let x_p6x = x_p6.clone();
        crate::prelude::call_then(crate::lower::expr::start_let_instantiations_f(lx_p0x.clone(), gn_p5x.clone(), x_p6x.clone()), move |let_instantiations_f_8114: crate::prelude::Array<(crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Col)>)>| {
            let distinct_p9 = let_instantiations_f_8114;
            match crate::prelude::index(&distinct_p9, &k_p7x) {
                ::std::option::Option::None => (&rest_f8x)(env_p1x.clone()).cycle(),
                ::std::option::Option::Some(inst_pa) => {
                    let lxk_pb = crate::lower::expr::at_instance_f(&lx_p0x, &inst_pa);
                    let last_pc = &(&k_p7x + &crate::prelude::Nat::from(1u32)) >= &crate::prelude::len(&distinct_p9);
                    let with_bound_fd = {
                        let lx_p0xx = lx_p0x.clone();
                        let n_p4xx = n_p4x.clone();
                        let gn_p5xx = gn_p5x.clone();
                        let x_p6xx = x_p6x.clone();
                        let k_p7xx = k_p7x.clone();
                        let last_pcx = last_pc;
                        let b_p2xx = b_p2x.clone();
                        let s_p3xx = s_p3x.clone();
                        let rest_f8xx = rest_f8x.clone();
                        ::std::rc::Rc::new(move |(p0, p1): (crate::lower::types::Env, crate::lower::model::Ex)| {
                            let lx_p0xxy = lx_p0xx.clone();
                            let n_p4xxy = n_p4xx.clone();
                            let gn_p5xxy = gn_p5xx.clone();
                            let x_p6xxy = x_p6xx.clone();
                            let k_p7xxy = k_p7xx.clone();
                            let last_pcxy = last_pcx;
                            let b_p2xxy = b_p2xx.clone();
                            let s_p3xxy = s_p3xx.clone();
                            let rest_f8xxy = rest_f8xx.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let en_pe = p0;
                                let value_pf = p1;
                                crate::prelude::call_then(crate::lower::expr::start_generic_let_bound_f(lx_p0xxy.clone(), en_pe.clone(), n_p4xxy.clone(), gn_p5xxy.clone(), x_p6xxy.clone(), k_p7xxy.clone(), value_pf.clone()), move |generic_let_bound_f_8368: (crate::prelude::Array<crate::lower::model::Do>, crate::lower::types::Env)| {
                                    let (dos_ph, en2_pi) = generic_let_bound_f_8368;
                                    let rest_f8xxyz = rest_f8xxy.clone();
                                    let b_p2xxyz = b_p2xxy.clone();
                                    let dos_phz = dos_ph.clone();
                                    let gn_p5xxyz = gn_p5xxy.clone();
                                    let k_p7xxyz = k_p7xxy.clone();
                                    let lx_p0xxyz = lx_p0xxy.clone();
                                    let n_p4xxyz = n_p4xxy.clone();
                                    let s_p3xxyz = s_p3xxy.clone();
                                    let x_p6xxyz = x_p6xxy.clone();
                                    let k_let8427 = move |v8427: crate::lower::types::Env| {
                                        let en3_pg = v8427;
                                        crate::prelude::call_then(start_generic_let_tail_f(lx_p0xxyz.clone(), en3_pg.clone(), b_p2xxyz.clone(), s_p3xxyz.clone(), n_p4xxyz.clone(), gn_p5xxyz.clone(), x_p6xxyz.clone(), &k_p7xxyz + &crate::prelude::Nat::from(1u32), rest_f8xxyz.clone()), move |generic_let_tail_f_8608: crate::lower::model::Ex| ::prism_rtl::Turn::Finished(prepend_f(&dos_phz, &generic_let_tail_f_8608)))
                                    };
                                    if last_pcxy {
                                        k_let8427(en2_pi.clone())
                                    } else {
                                        crate::prelude::call_then(crate::check::typed::print::start_exprs_in_f(x_p6xxy.clone()), move |exprs_in_f_8462: crate::prelude::Array<crate::syntax::Expr>| k_let8427(crate::prelude::fold(&exprs_in_f_8462, &en2_pi, &(|e2_pj: &crate::lower::types::Env, inner_pk: &crate::syntax::Expr| {
                                            let mut this: crate::lower::types::Env = e2_pj.clone();
                                            this.spans_p = crate::prelude::remove(&this.spans_p, &crate::lower::place_key_f(&lx_p0xxy, &inner_pk.span_p));
                                            this
                                        }))))
                                    }
                                })
                            }))
                        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::types::Env, crate::lower::model::Ex)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>>>
                    };
                    crate::prelude::call_then(start_frame_call_o(lxk_pb.clone(), env_p1x.clone(), x_p6x.clone(), false), move |frame_call_o_8679: ::std::option::Option<crate::syntax::Expr>| match frame_call_o_8679 {
                        ::std::option::Option::Some(c_pl) => ::prism_rtl::Turn::More(::std::rc::Rc::new(Frame { lx_p0: lxk_pb.clone(), env_p1: env_p1x.clone(), call_p2: c_pl.clone(), rest_reads_p3: rest_reads_f(&lx_p0x, &s_p3x.span_p, &c_pl.span_p, &b_p2x.span_p), cont_f4: {
                            let lx_p0xx = lx_p0x.clone();
                            let b_p2xx = b_p2x.clone();
                            let s_p3xx = s_p3x.clone();
                            let n_p4xx = n_p4x.clone();
                            let gn_p5xx = gn_p5x.clone();
                            let x_p6xx = x_p6x.clone();
                            let k_p7xx = k_p7x.clone();
                            let rest_f8xx = rest_f8x.clone();
                            ::std::rc::Rc::new(move |p0: crate::lower::types::Env| {
                                let lx_p0xxy = lx_p0xx.clone();
                                let b_p2xxy = b_p2xx.clone();
                                let s_p3xxy = s_p3xx.clone();
                                let n_p4xxy = n_p4xx.clone();
                                let gn_p5xxy = gn_p5xx.clone();
                                let x_p6xxy = x_p6xx.clone();
                                let k_p7xxy = k_p7xx.clone();
                                let rest_f8xxy = rest_f8xx.clone();
                                crate::prelude::entered(crate::prelude::once_job(move || {
                                    let env2_pm = p0;
                                    ::prism_rtl::Turn::More(::std::rc::Rc::new(GenericLetTail { lx_p0: lx_p0xxy.clone(), env_p1: env2_pm.clone(), b_p2: b_p2xxy.clone(), s_p3: s_p3xxy.clone(), n_p4: n_p4xxy.clone(), gn_p5: gn_p5xxy.clone(), x_p6: x_p6xxy.clone(), k_p7: k_p7xxy.clone(), rest_f8: rest_f8xxy.clone() }))
                                }))
                            }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::types::Env) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>>>
                        } })),
                        ::std::option::Option::None => crate::prelude::call_then(start_branch_jobs_f(lxk_pb.clone(), env_p1x.clone(), x_p6x.clone()), move |branch_jobs_f_8891: bool| if branch_jobs_f_8891 {
                            {
                                let from_pn = if last_pc {
                                    crate::syntax::Range { start_p: s_p3x.span_p.end_p.clone(), end_p: s_p3x.span_p.end_p.clone() }
                                } else {
                                    s_p3x.span_p.clone()
                                };
                                ::prism_rtl::Turn::More(::std::rc::Rc::new(KValue { lx_p0: lxk_pb.clone(), env_p1: env_p1x.clone(), from_p2: from_pn.clone(), b_p3: b_p2x.clone(), x_p4: x_p6x.clone(), label_p5: crate::prelude::Text::from(format!("{}w{}", &s_p3x.span_p.start_p, &k_p7x)), body_f6: with_bound_fd.clone() }))
                            }
                        } else {
                            crate::prelude::call_then(crate::lower::expr::start_value_of_f(lxk_pb.clone(), env_p1x.clone(), x_p6x.clone()), move |value_of_f_9236: crate::lower::types::Vl| (&with_bound_fd)((env_p1x.clone(), crate::lower::types::own_f(&value_of_f_9236))).cycle())
                        }),
                    })
                },
            }
        })
    }
}

/// `Start GenericLetTail, x`: what the function value is when passed to `@Run`.
pub fn start_generic_let_tail_f(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, b_p2: crate::syntax::Block, s_p3: crate::syntax::Stmt, n_p4: crate::syntax::SName, gn_p5: crate::check::typed::GenNote, x_p6: crate::syntax::Expr, k_p7: crate::prelude::Nat, rest_f8: ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::types::Env) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>>>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>> {
    ::std::rc::Rc::new(GenericLetTail { lx_p0, env_p1, b_p2, s_p3, n_p4, gn_p5, x_p6, k_p7, rest_f8 })
}

/// ```prism
/// KStmt: unbounded fn Lx, Env, Block, Nat, Stmt, ?Pattern, Expr, (unbounded fn Env, ?Expr -> Ex) -> Ex
/// ```
pub fn kstmt_f(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, b_p2: &crate::syntax::Block, i_p3: &crate::prelude::Nat, s_p4: &crate::syntax::Stmt, p_o5: &::std::option::Option<crate::syntax::Pattern>, x_p6: &crate::syntax::Expr, last_f7: &::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::types::Env, ::std::option::Option<crate::syntax::Expr>)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>>>) -> crate::lower::model::Ex {
    let after_p8 = crate::syntax::Range { start_p: s_p4.span_p.end_p.clone(), end_p: s_p4.span_p.end_p.clone() };
    kvalue_f(lx_p0, env_p1, &after_p8, b_p2, x_p6, &crate::prelude::Text::from(format!("{}", &s_p4.span_p.start_p)), &{
        let p_o5x = p_o5.clone();
        let lx_p0x = lx_p0.clone();
        let x_p6x = x_p6.clone();
        let s_p4x = s_p4.clone();
        let b_p2x = b_p2.clone();
        let i_p3x = i_p3.clone();
        let last_f7x = last_f7.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::lower::types::Env, crate::lower::model::Ex)| {
            let p_o5xy = p_o5x.clone();
            let lx_p0xy = lx_p0x.clone();
            let x_p6xy = x_p6x.clone();
            let s_p4xy = s_p4x.clone();
            let b_p2xy = b_p2x.clone();
            let i_p3xy = i_p3x.clone();
            let last_f7xy = last_f7x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let env_k_p9 = p0;
                let value_pa = p1;
                match &p_o5xy {
                    ::std::option::Option::Some(p_pb) => {
                        let p_pbx = p_pb.clone();
                        crate::prelude::call_then(crate::lower::patterns::start_rust_pat_f(lx_p0xy.clone(), p_pbx.clone(), crate::lower::type_at_f(&lx_p0xy, &x_p6xy.span_p), crate::lower::types::Holding::Owned, crate::prelude::Text::from(format!("l{}", &s_p4xy.span_p.start_p))), move |rust_pat_f_9966: crate::lower::patterns::PatOut| {
                            let po_pc = rust_pat_f_9966;
                            crate::prelude::call_then(start_tail_from_k_f(lx_p0xy.clone(), crate::lower::expr::bind_all_f(&env_k_p9, &po_pc.binds_p), b_p2xy.clone(), &i_p3xy + &crate::prelude::Nat::from(1u32), last_f7xy.clone()), move |tail_from_k_f_10074: crate::lower::model::Ex| ::prism_rtl::Turn::Finished(prepend_f(&crate::prelude::Array::from(vec![crate::lower::model::Do::DoLet(po_pc.pa_p.clone(), value_pa.clone())]), &tail_from_k_f_10074)))
                        })
                    },
                    ::std::option::Option::None => ::prism_rtl::Turn::More(::std::rc::Rc::new(TailFromK { lx_p0: lx_p0xy.clone(), env_p1: env_k_p9.clone(), b_p2: b_p2xy.clone(), i_p3: &i_p3xy + &crate::prelude::Nat::from(1u32), last_f4: last_f7xy.clone() })),
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::types::Env, crate::lower::model::Ex)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>>>
    })
}

/// The step machine of `KStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// KStmt: unbounded fn Lx, Env, Block, Nat, Stmt, ?Pattern, Expr, (unbounded fn Env, ?Expr -> Ex) -> Ex
/// ```
pub struct KStmt {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub b_p2: crate::syntax::Block,
    pub i_p3: crate::prelude::Nat,
    pub s_p4: crate::syntax::Stmt,
    pub p_o5: ::std::option::Option<crate::syntax::Pattern>,
    pub x_p6: crate::syntax::Expr,
    pub last_f7: ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::types::Env, ::std::option::Option<crate::syntax::Expr>)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>>>,
}

impl ::prism_rtl::Job<crate::lower::model::Ex> for KStmt {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::lower::model::Ex> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let b_p2 = &self.b_p2;
        let i_p3 = &self.i_p3;
        let s_p4 = &self.s_p4;
        let p_o5 = &self.p_o5;
        let x_p6 = &self.x_p6;
        let last_f7 = &self.last_f7;
        let after_p8 = crate::syntax::Range { start_p: s_p4.span_p.end_p.clone(), end_p: s_p4.span_p.end_p.clone() };
        ::prism_rtl::Turn::More(::std::rc::Rc::new(KValue { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), from_p2: after_p8.clone(), b_p3: b_p2.clone(), x_p4: x_p6.clone(), label_p5: crate::prelude::Text::from(format!("{}", &s_p4.span_p.start_p)), body_f6: {
            let p_o5x = p_o5.clone();
            let lx_p0x = lx_p0.clone();
            let x_p6x = x_p6.clone();
            let s_p4x = s_p4.clone();
            let b_p2x = b_p2.clone();
            let i_p3x = i_p3.clone();
            let last_f7x = last_f7.clone();
            ::std::rc::Rc::new(move |(p0, p1): (crate::lower::types::Env, crate::lower::model::Ex)| {
                let p_o5xy = p_o5x.clone();
                let lx_p0xy = lx_p0x.clone();
                let x_p6xy = x_p6x.clone();
                let s_p4xy = s_p4x.clone();
                let b_p2xy = b_p2x.clone();
                let i_p3xy = i_p3x.clone();
                let last_f7xy = last_f7x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let env_k_p9 = p0;
                    let value_pa = p1;
                    match &p_o5xy {
                        ::std::option::Option::Some(p_pb) => {
                            let p_pbx = p_pb.clone();
                            crate::prelude::call_then(crate::lower::patterns::start_rust_pat_f(lx_p0xy.clone(), p_pbx.clone(), crate::lower::type_at_f(&lx_p0xy, &x_p6xy.span_p), crate::lower::types::Holding::Owned, crate::prelude::Text::from(format!("l{}", &s_p4xy.span_p.start_p))), move |rust_pat_f_9966: crate::lower::patterns::PatOut| {
                                let po_pc = rust_pat_f_9966;
                                crate::prelude::call_then(start_tail_from_k_f(lx_p0xy.clone(), crate::lower::expr::bind_all_f(&env_k_p9, &po_pc.binds_p), b_p2xy.clone(), &i_p3xy + &crate::prelude::Nat::from(1u32), last_f7xy.clone()), move |tail_from_k_f_10074: crate::lower::model::Ex| ::prism_rtl::Turn::Finished(prepend_f(&crate::prelude::Array::from(vec![crate::lower::model::Do::DoLet(po_pc.pa_p.clone(), value_pa.clone())]), &tail_from_k_f_10074)))
                            })
                        },
                        ::std::option::Option::None => ::prism_rtl::Turn::More(::std::rc::Rc::new(TailFromK { lx_p0: lx_p0xy.clone(), env_p1: env_k_p9.clone(), b_p2: b_p2xy.clone(), i_p3: &i_p3xy + &crate::prelude::Nat::from(1u32), last_f4: last_f7xy.clone() })),
                    }
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::types::Env, crate::lower::model::Ex)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>>>
        } }))
    }
}

/// `Start KStmt, x`: what the function value is when passed to `@Run`.
pub fn start_kstmt_f(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, b_p2: crate::syntax::Block, i_p3: crate::prelude::Nat, s_p4: crate::syntax::Stmt, p_o5: ::std::option::Option<crate::syntax::Pattern>, x_p6: crate::syntax::Expr, last_f7: ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::types::Env, ::std::option::Option<crate::syntax::Expr>)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>>>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>> {
    ::std::rc::Rc::new(KStmt { lx_p0, env_p1, b_p2, i_p3, s_p4, p_o5, x_p6, last_f7 })
}

/// ```prism
/// KValue: unbounded fn Lx, Env, Range, Block, Expr, Text, (unbounded fn Env, Ex -> Ex) -> Ex
/// ```
pub fn kvalue_f(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, from_p2: &crate::syntax::Range, b_p3: &crate::syntax::Block, x_p4: &crate::syntax::Expr, label_p5: &crate::prelude::Text, body_f6: &::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::types::Env, crate::lower::model::Ex)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>>>) -> crate::lower::model::Ex {
    let rest_p7 = rest_reads_f(lx_p0, from_p2, from_p2, &b_p3.span_p);
    let caps_p8 = crate::prelude::fold(&crate::prelude::keys(&env_p1.names_p), &crate::prelude::Array::new(), &(|acc_pf: &crate::prelude::Array<(crate::prelude::Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)>, k_pg: &crate::prelude::Text| match crate::prelude::get(&env_p1.names_p, k_pg) {
        ::std::option::Option::Some(crate::lower::types::Bn::BnLocal(rs_ph, mode_pi, bt_pj)) => if !crate::lower::types::on_self_f(&rs_ph) && reads_f(&rest_p7, k_pg) {
            crate::prelude::push(acc_pf, &(k_pg.clone(), rs_ph.clone(), mode_pi, bt_pj))
        } else {
            acc_pf.clone()
        },
        _ => acc_pf.clone(),
    }));
    let dos_p9 = crate::prelude::each(&caps_p8, &(|(_, rs_pk, mode_pl, bt_pm): &(crate::prelude::Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)| crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::lower::expr::outer_name_f(rs_pk)), crate::lower::types::own_f(&crate::lower::types::Vl::VlPlace(rs_pk.clone(), mode_pl.clone(), bt_pm.clone())))));
    let env_k_pa = crate::prelude::fold(&caps_p8, env_p1, &(|en_pn: &crate::lower::types::Env, (k_po, rs_pp, _, bt_pq): &(crate::prelude::Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)| crate::lower::types::bind_f(en_pn, k_po, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(crate::lower::expr::outer_name_f(rs_pp)), crate::lower::types::Holding::Owned, bt_pq.clone()))));
    let t_pb = crate::lower::types::out_ty_of_f(lx_p0, &crate::lower::types::peel_f(&crate::lower::type_at_f(lx_p0, &x_p4.span_p)));
    let v_pc = crate::prelude::Text::from(format!("v{}", label_p5));
    let k_name_pd = crate::prelude::Text::from(format!("k_let{}", label_p5));
    let k_do_pe = crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(k_name_pd.clone()), crate::lower::model::Ex::XClosure(true, crate::prelude::Array::from(vec![crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaBind(v_pc.clone())), t_pb.clone())]), ::std::rc::Rc::new(crate::prelude::run_to_end(body_f6((env_k_pa.clone(), crate::lower::model::Ex::XVar(v_pc.clone())))))));
    prepend_f(&crate::prelude::push(&dos_p9, &k_do_pe), &tail_k_f(lx_p0, env_p1, x_p4, &{
        let k_name_pdx = k_name_pd.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::lower::types::Env, crate::lower::model::Ex)| {
            let k_name_pdxy = k_name_pdx.clone();
            crate::prelude::once_job(move || {
                let en_pr = p0;
                let val_ps = p1;
                ::prism_rtl::Turn::Finished(crate::lower::model::Ex::XApply(::std::rc::Rc::new(crate::lower::model::Ex::XVar(k_name_pdxy.clone())), crate::prelude::Array::from(vec![val_ps.clone()])))
            })
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::types::Env, crate::lower::model::Ex)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>>>
    }))
}

/// The step machine of `KValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// KValue: unbounded fn Lx, Env, Range, Block, Expr, Text, (unbounded fn Env, Ex -> Ex) -> Ex
/// ```
pub struct KValue {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub from_p2: crate::syntax::Range,
    pub b_p3: crate::syntax::Block,
    pub x_p4: crate::syntax::Expr,
    pub label_p5: crate::prelude::Text,
    pub body_f6: ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::types::Env, crate::lower::model::Ex)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>>>,
}

impl ::prism_rtl::Job<crate::lower::model::Ex> for KValue {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::lower::model::Ex> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let from_p2 = &self.from_p2;
        let b_p3 = &self.b_p3;
        let x_p4 = &self.x_p4;
        let label_p5 = &self.label_p5;
        let body_f6 = &self.body_f6;
        let rest_p7 = rest_reads_f(lx_p0, from_p2, from_p2, &b_p3.span_p);
        let caps_p8 = crate::prelude::fold(&crate::prelude::keys(&env_p1.names_p), &crate::prelude::Array::new(), &(|acc_pf: &crate::prelude::Array<(crate::prelude::Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)>, k_pg: &crate::prelude::Text| match crate::prelude::get(&env_p1.names_p, k_pg) {
            ::std::option::Option::Some(crate::lower::types::Bn::BnLocal(rs_ph, mode_pi, bt_pj)) => if !crate::lower::types::on_self_f(&rs_ph) && reads_f(&rest_p7, k_pg) {
                crate::prelude::push(acc_pf, &(k_pg.clone(), rs_ph.clone(), mode_pi, bt_pj))
            } else {
                acc_pf.clone()
            },
            _ => acc_pf.clone(),
        }));
        let dos_p9 = crate::prelude::each(&caps_p8, &(|(_, rs_pk, mode_pl, bt_pm): &(crate::prelude::Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)| crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::lower::expr::outer_name_f(rs_pk)), crate::lower::types::own_f(&crate::lower::types::Vl::VlPlace(rs_pk.clone(), mode_pl.clone(), bt_pm.clone())))));
        let env_k_pa = crate::prelude::fold(&caps_p8, env_p1, &(|en_pn: &crate::lower::types::Env, (k_po, rs_pp, _, bt_pq): &(crate::prelude::Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)| crate::lower::types::bind_f(en_pn, k_po, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(crate::lower::expr::outer_name_f(rs_pp)), crate::lower::types::Holding::Owned, bt_pq.clone()))));
        let body_f6x = body_f6.clone();
        let env_p1x = env_p1.clone();
        let label_p5x = label_p5.clone();
        let lx_p0x = lx_p0.clone();
        let x_p4x = x_p4.clone();
        crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0x.clone(), crate::lower::types::peel_f(&crate::lower::type_at_f(&lx_p0x, &x_p4x.span_p))), move |out_ty_of_f_11211: crate::lower::model::OutTy| {
            let t_pb = out_ty_of_f_11211;
            let v_pc = crate::prelude::Text::from(format!("v{}", &label_p5x));
            let k_name_pd = crate::prelude::Text::from(format!("k_let{}", &label_p5x));
            crate::prelude::call_value((&body_f6x)((env_k_pa.clone(), crate::lower::model::Ex::XVar(v_pc.clone()))), move |body_11386: crate::lower::model::Ex| {
                let k_do_pe = crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(k_name_pd.clone()), crate::lower::model::Ex::XClosure(true, crate::prelude::Array::from(vec![crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaBind(v_pc.clone())), t_pb.clone())]), ::std::rc::Rc::new(body_11386)));
                crate::prelude::call_then(start_tail_k_f(lx_p0x.clone(), env_p1x.clone(), x_p4x.clone(), {
                    let k_name_pdx = k_name_pd.clone();
                    ::std::rc::Rc::new(move |(p0, p1): (crate::lower::types::Env, crate::lower::model::Ex)| {
                        let k_name_pdxy = k_name_pdx.clone();
                        crate::prelude::once_job(move || {
                            let en_pr = p0;
                            let val_ps = p1;
                            ::prism_rtl::Turn::Finished(crate::lower::model::Ex::XApply(::std::rc::Rc::new(crate::lower::model::Ex::XVar(k_name_pdxy.clone())), crate::prelude::Array::from(vec![val_ps.clone()])))
                        })
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::types::Env, crate::lower::model::Ex)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>>>
                }), move |tail_k_f_11438: crate::lower::model::Ex| ::prism_rtl::Turn::Finished(prepend_f(&crate::prelude::push(&dos_p9, &k_do_pe), &tail_k_f_11438)))
            })
        })
    }
}

/// `Start KValue, x`: what the function value is when passed to `@Run`.
pub fn start_kvalue_f(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, from_p2: crate::syntax::Range, b_p3: crate::syntax::Block, x_p4: crate::syntax::Expr, label_p5: crate::prelude::Text, body_f6: ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::types::Env, crate::lower::model::Ex)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>>>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>> {
    ::std::rc::Rc::new(KValue { lx_p0, env_p1, from_p2, b_p3, x_p4, label_p5, body_f6 })
}

/// ```prism
/// TailK: unbounded fn Lx, Env, Expr, (unbounded fn Env, Ex -> Ex) -> Ex
/// ```
pub fn tail_k_f(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, e_p2: &crate::syntax::Expr, k_f3: &::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::types::Env, crate::lower::model::Ex)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>>>) -> crate::lower::model::Ex {
    match frame_call_o(lx_p0, env_p1, e_p2, &false) {
        ::std::option::Option::Some(c_p4) => frame_f(lx_p0, env_p1, &c_p4, &rest_reads_f(lx_p0, &e_p2.span_p, &c_p4.span_p, &e_p2.span_p), &{
            let lx_p0x = lx_p0.clone();
            let e_p2x = e_p2.clone();
            let k_f3x = k_f3.clone();
            ::std::rc::Rc::new(move |p0: crate::lower::types::Env| {
                let lx_p0xy = lx_p0x.clone();
                let e_p2xy = e_p2x.clone();
                let k_f3xy = k_f3x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let env2_p5 = p0;
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(TailK { lx_p0: lx_p0xy.clone(), env_p1: env2_p5.clone(), e_p2: e_p2xy.clone(), k_f3: k_f3xy.clone() }))
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::types::Env) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>>>
        }),
        ::std::option::Option::None => {
            let block_k_f6 = {
                let lx_p0x = lx_p0.clone();
                let k_f3x = k_f3.clone();
                ::std::rc::Rc::new(move |(p0, p1): (crate::lower::types::Env, crate::syntax::Block)| {
                    let lx_p0xy = lx_p0x.clone();
                    let k_f3xy = k_f3x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let en_p7 = p0;
                        let bl_p8 = p1;
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(TailFromK { lx_p0: lx_p0xy.clone(), env_p1: en_p7.clone(), b_p2: bl_p8.clone(), i_p3: crate::prelude::Nat::from(0u32), last_f4: {
                            let lx_p0xyx = lx_p0xy.clone();
                            let k_f3xyx = k_f3xy.clone();
                            ::std::rc::Rc::new(move |(p0, p1): (crate::lower::types::Env, ::std::option::Option<crate::syntax::Expr>)| {
                                let lx_p0xyxy = lx_p0xyx.clone();
                                let k_f3xyxy = k_f3xyx.clone();
                                crate::prelude::entered(crate::prelude::once_job(move || {
                                    let en2_p9 = p0;
                                    let y_oa = p1;
                                    match &y_oa {
                                        ::std::option::Option::Some(y_pb) => ::prism_rtl::Turn::More(::std::rc::Rc::new(TailK { lx_p0: lx_p0xyxy.clone(), env_p1: en2_p9.clone(), e_p2: y_pb.clone(), k_f3: k_f3xyxy.clone() })),
                                        ::std::option::Option::None => (&k_f3xyxy)((en2_p9.clone(), crate::lower::model::Ex::XUnit)).cycle(),
                                    }
                                }))
                            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::types::Env, ::std::option::Option<crate::syntax::Expr>)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>>>
                        } }))
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::types::Env, crate::syntax::Block)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>>>
            };
            'm12135: {
                let scrutinee = &*e_p2.kind_p;
                if let crate::syntax::ExprKind::EGroup(y_pc) = scrutinee {
                    break 'm12135 tail_k_f(lx_p0, env_p1, &**y_pc, &k_f3.clone());
                }
                if let crate::syntax::ExprKind::EMatch(sc_pd, arms_pe) = scrutinee && branch_jobs_f(lx_p0, env_p1, e_p2) {
                    break 'm12135 {
                        let sty_pf = crate::lower::type_at_f(lx_p0, &sc_pd.span_p);
                        let label_pg = crate::prelude::Text::from(format!("m{}", &e_p2.span_p.start_p));
                        let xarms_ph = crate::prelude::run_to_end(crate::prelude::each_job(crate::check::errors::range0_f(&crate::prelude::len(arms_pe)), {
                            let arms_pex = arms_pe.clone();
                            let lx_p0x = lx_p0.clone();
                            let sty_pfx = sty_pf.clone();
                            let label_pgx = label_pg.clone();
                            let env_p1x = env_p1.clone();
                            let block_k_f6x = block_k_f6.clone();
                            ::std::rc::Rc::new(move |p0: crate::prelude::Nat| {
                                let arms_pexy = arms_pex.clone();
                                let lx_p0xy = lx_p0x.clone();
                                let sty_pfxy = sty_pfx.clone();
                                let label_pgxy = label_pgx.clone();
                                let env_p1xy = env_p1x.clone();
                                let block_k_f6xy = block_k_f6x.clone();
                                crate::prelude::entered(crate::prelude::once_job(move || {
                                    let j_pi = p0;
                                    {
                                        let arm_pj = crate::prelude::or(&crate::prelude::index(&arms_pexy, &j_pi), &crate::lower::expr::dummy_arm_p());
                                        crate::prelude::call_then(crate::lower::expr::start_arm_pat_f(lx_p0xy.clone(), arm_pj.pattern_o.clone(), sty_pfxy.clone(), crate::lower::types::Holding::Owned, crate::prelude::Text::from(format!("{}_{}", &label_pgxy, &j_pi))), move |arm_pat_f_12475: crate::lower::patterns::PatOut| {
                                            let po_pk = arm_pat_f_12475;
                                            let env_a_pl = crate::lower::expr::bind_all_f(&env_p1xy, &po_pk.binds_p);
                                            crate::prelude::call_then(crate::lower::templates::start_guard_conds_f(lx_p0xy.clone(), env_a_pl.clone(), arm_pj.guard_o.clone()), move |guard_conds_f_12640: crate::prelude::Array<crate::lower::model::Cc>| crate::prelude::call_value((&block_k_f6xy)((env_a_pl.clone(), arm_pj.body_p.clone())), move |block_k_12681: crate::lower::model::Ex| ::prism_rtl::Turn::Finished(crate::lower::model::XArm { pat_p: po_pk.pa_p.clone(), conds_p: crate::prelude::append(&po_pk.conds_p, &guard_conds_f_12640), body_p: block_k_12681 })))
                                        })
                                    }
                                }))
                            }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::XArm>>>
                        }));
                        crate::lower::types::own_f(&crate::lower::expr::arms_value_f(&crate::lower::types::own_f(&crate::lower::expr::value_of_f(lx_p0, env_p1, &**sc_pd)), &xarms_ph, &crate::prelude::Text::from(format!("\'{}", &label_pg)), &crate::lower::model::OutTy::OutTurn))
                    };
                }
                if let crate::syntax::ExprKind::EIf(m12135_2_0, then_b_pn, else_b_oo) = scrutinee && let crate::syntax::Cond::CondExpr(c_pm) = &**m12135_2_0 && branch_jobs_f(lx_p0, env_p1, e_p2) {
                    break 'm12135 {
                        let else_x_pp = match else_b_oo {
                            ::std::option::Option::Some(eb_pq) => crate::prelude::run_to_end((&block_k_f6)((env_p1.clone(), eb_pq.clone()))),
                            ::std::option::Option::None => crate::prelude::run_to_end(k_f3((env_p1.clone(), crate::lower::model::Ex::XUnit))),
                        };
                        crate::lower::model::Ex::XIf(::std::rc::Rc::new(crate::lower::types::as_bool_f(&crate::lower::expr::value_of_f(lx_p0, env_p1, &**c_pm))), ::std::rc::Rc::new(crate::prelude::run_to_end((&block_k_f6)((env_p1.clone(), then_b_pn.clone())))), ::std::rc::Rc::new(else_x_pp.clone()))
                    };
                }
                if let crate::syntax::ExprKind::EBinary(op_pr, l_ps, r_pt) = scrutinee && (((op_pr == &crate::prelude::Text::lit("and")) || (op_pr == &crate::prelude::Text::lit("or"))) && any_job_f(lx_p0, env_p1, &**r_pt)) {
                    break 'm12135 {
                        let right_x_pu = tail_k_f(lx_p0, env_p1, &**r_pt, &k_f3.clone());
                        if op_pr == &crate::prelude::Text::lit("and") {
                            crate::lower::model::Ex::XIf(::std::rc::Rc::new(crate::lower::types::as_bool_f(&crate::lower::expr::value_of_f(lx_p0, env_p1, &**l_ps))), ::std::rc::Rc::new(right_x_pu.clone()), ::std::rc::Rc::new(crate::prelude::run_to_end(k_f3((env_p1.clone(), crate::lower::model::Ex::XBool(false))))))
                        } else {
                            crate::lower::model::Ex::XIf(::std::rc::Rc::new(crate::lower::types::as_bool_f(&crate::lower::expr::value_of_f(lx_p0, env_p1, &**l_ps))), ::std::rc::Rc::new(crate::prelude::run_to_end(k_f3((env_p1.clone(), crate::lower::model::Ex::XBool(true))))), ::std::rc::Rc::new(right_x_pu.clone()))
                        }
                    };
                }
                crate::prelude::run_to_end(k_f3((env_p1.clone(), crate::lower::types::own_f(&crate::lower::expr::value_of_f(lx_p0, env_p1, e_p2)))))
            }
        },
    }
}

/// The step machine of `TailK`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TailK: unbounded fn Lx, Env, Expr, (unbounded fn Env, Ex -> Ex) -> Ex
/// ```
pub struct TailK {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub e_p2: crate::syntax::Expr,
    pub k_f3: ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::types::Env, crate::lower::model::Ex)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>>>,
}

impl ::prism_rtl::Job<crate::lower::model::Ex> for TailK {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::lower::model::Ex> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let e_p2 = &self.e_p2;
        let k_f3 = &self.k_f3;
        let k_f3x = k_f3.clone();
        let e_p2x = e_p2.clone();
        let env_p1x = env_p1.clone();
        let lx_p0x = lx_p0.clone();
        crate::prelude::call_then(start_frame_call_o(lx_p0x.clone(), env_p1x.clone(), e_p2x.clone(), false), move |frame_call_o_11848: ::std::option::Option<crate::syntax::Expr>| match frame_call_o_11848 {
            ::std::option::Option::Some(c_p4) => ::prism_rtl::Turn::More(::std::rc::Rc::new(Frame { lx_p0: lx_p0x.clone(), env_p1: env_p1x.clone(), call_p2: c_p4.clone(), rest_reads_p3: rest_reads_f(&lx_p0x, &e_p2x.span_p, &c_p4.span_p, &e_p2x.span_p), cont_f4: {
                let lx_p0xx = lx_p0x.clone();
                let e_p2xx = e_p2x.clone();
                let k_f3xx = k_f3x.clone();
                ::std::rc::Rc::new(move |p0: crate::lower::types::Env| {
                    let lx_p0xxy = lx_p0xx.clone();
                    let e_p2xxy = e_p2xx.clone();
                    let k_f3xxy = k_f3xx.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let env2_p5 = p0;
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(TailK { lx_p0: lx_p0xxy.clone(), env_p1: env2_p5.clone(), e_p2: e_p2xxy.clone(), k_f3: k_f3xxy.clone() }))
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::types::Env) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>>>
            } })),
            ::std::option::Option::None => {
                let block_k_f6 = {
                    let lx_p0xx = lx_p0x.clone();
                    let k_f3xx = k_f3x.clone();
                    ::std::rc::Rc::new(move |(p0, p1): (crate::lower::types::Env, crate::syntax::Block)| {
                        let lx_p0xxy = lx_p0xx.clone();
                        let k_f3xxy = k_f3xx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let en_p7 = p0;
                            let bl_p8 = p1;
                            ::prism_rtl::Turn::More(::std::rc::Rc::new(TailFromK { lx_p0: lx_p0xxy.clone(), env_p1: en_p7.clone(), b_p2: bl_p8.clone(), i_p3: crate::prelude::Nat::from(0u32), last_f4: {
                                let lx_p0xxyx = lx_p0xxy.clone();
                                let k_f3xxyx = k_f3xxy.clone();
                                ::std::rc::Rc::new(move |(p0, p1): (crate::lower::types::Env, ::std::option::Option<crate::syntax::Expr>)| {
                                    let lx_p0xxyxy = lx_p0xxyx.clone();
                                    let k_f3xxyxy = k_f3xxyx.clone();
                                    crate::prelude::entered(crate::prelude::once_job(move || {
                                        let en2_p9 = p0;
                                        let y_oa = p1;
                                        match &y_oa {
                                            ::std::option::Option::Some(y_pb) => ::prism_rtl::Turn::More(::std::rc::Rc::new(TailK { lx_p0: lx_p0xxyxy.clone(), env_p1: en2_p9.clone(), e_p2: y_pb.clone(), k_f3: k_f3xxyxy.clone() })),
                                            ::std::option::Option::None => (&k_f3xxyxy)((en2_p9.clone(), crate::lower::model::Ex::XUnit)).cycle(),
                                        }
                                    }))
                                }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::types::Env, ::std::option::Option<crate::syntax::Expr>)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>>>
                            } }))
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::types::Env, crate::syntax::Block)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>>>
                };
                'm12135: {
                    let scrutinee = &*e_p2x.kind_p;
                    if let crate::syntax::ExprKind::EGroup(y_pc) = scrutinee {
                        break 'm12135 ::prism_rtl::Turn::More(::std::rc::Rc::new(TailK { lx_p0: lx_p0x.clone(), env_p1: env_p1x.clone(), e_p2: (**y_pc).clone(), k_f3: k_f3x.clone() }));
                    }
                    if let crate::syntax::ExprKind::EMatch(sc_pd, arms_pe) = scrutinee && branch_jobs_f(&lx_p0x, &env_p1x, &e_p2x) {
                        break 'm12135 {
                            let sty_pf = crate::lower::type_at_f(&lx_p0x, &sc_pd.span_p);
                            let label_pg = crate::prelude::Text::from(format!("m{}", &e_p2x.span_p.start_p));
                            let arms_pex = arms_pe.clone();
                            let sc_pdx = (**sc_pd).clone();
                            crate::prelude::call_value(crate::prelude::each_job(crate::check::errors::range0_f(&crate::prelude::len(&arms_pex)), {
                                let arms_pexx = arms_pex.clone();
                                let lx_p0xx = lx_p0x.clone();
                                let sty_pfx = sty_pf.clone();
                                let label_pgx = label_pg.clone();
                                let env_p1xx = env_p1x.clone();
                                let block_k_f6x = block_k_f6.clone();
                                ::std::rc::Rc::new(move |p0: crate::prelude::Nat| {
                                    let arms_pexxy = arms_pexx.clone();
                                    let lx_p0xxy = lx_p0xx.clone();
                                    let sty_pfxy = sty_pfx.clone();
                                    let label_pgxy = label_pgx.clone();
                                    let env_p1xxy = env_p1xx.clone();
                                    let block_k_f6xy = block_k_f6x.clone();
                                    crate::prelude::entered(crate::prelude::once_job(move || {
                                        let j_pi = p0;
                                        {
                                            let arm_pj = crate::prelude::or(&crate::prelude::index(&arms_pexxy, &j_pi), &crate::lower::expr::dummy_arm_p());
                                            crate::prelude::call_then(crate::lower::expr::start_arm_pat_f(lx_p0xxy.clone(), arm_pj.pattern_o.clone(), sty_pfxy.clone(), crate::lower::types::Holding::Owned, crate::prelude::Text::from(format!("{}_{}", &label_pgxy, &j_pi))), move |arm_pat_f_12475: crate::lower::patterns::PatOut| {
                                                let po_pk = arm_pat_f_12475;
                                                let env_a_pl = crate::lower::expr::bind_all_f(&env_p1xxy, &po_pk.binds_p);
                                                crate::prelude::call_then(crate::lower::templates::start_guard_conds_f(lx_p0xxy.clone(), env_a_pl.clone(), arm_pj.guard_o.clone()), move |guard_conds_f_12640: crate::prelude::Array<crate::lower::model::Cc>| crate::prelude::call_value((&block_k_f6xy)((env_a_pl.clone(), arm_pj.body_p.clone())), move |block_k_12681: crate::lower::model::Ex| ::prism_rtl::Turn::Finished(crate::lower::model::XArm { pat_p: po_pk.pa_p.clone(), conds_p: crate::prelude::append(&po_pk.conds_p, &guard_conds_f_12640), body_p: block_k_12681 })))
                                            })
                                        }
                                    }))
                                }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::XArm>>>
                            }), move |each_12364: crate::prelude::Array<crate::lower::model::XArm>| {
                                let xarms_ph = each_12364;
                                crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p0x.clone(), env_p1x.clone(), sc_pdx.clone()), move |value_of_f_12742: crate::lower::types::Vl| ::prism_rtl::Turn::Finished(crate::lower::types::own_f(&crate::lower::expr::arms_value_f(&crate::lower::types::own_f(&value_of_f_12742), &xarms_ph, &crate::prelude::Text::from(format!("\'{}", &label_pg)), &crate::lower::model::OutTy::OutTurn))))
                            })
                        };
                    }
                    if let crate::syntax::ExprKind::EIf(m12135_2_0, then_b_pn, else_b_oo) = scrutinee && let crate::syntax::Cond::CondExpr(c_pm) = &**m12135_2_0 && branch_jobs_f(&lx_p0x, &env_p1x, &e_p2x) {
                        break 'm12135 {
                            let block_k_f6z = block_k_f6.clone();
                            let c_pmz = (**c_pm).clone();
                            let env_p1xz = env_p1x.clone();
                            let lx_p0xz = lx_p0x.clone();
                            let then_b_pnz = then_b_pn.clone();
                            let k_let12879 = move |v12879: crate::lower::model::Ex| {
                                let else_x_pp = v12879;
                                crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p0xz.clone(), env_p1xz.clone(), c_pmz.clone()), move |value_of_f_13013: crate::lower::types::Vl| crate::prelude::call_value((&block_k_f6z)((env_p1xz.clone(), then_b_pnz.clone())), move |block_k_13036: crate::lower::model::Ex| ::prism_rtl::Turn::Finished(crate::lower::model::Ex::XIf(::std::rc::Rc::new(crate::lower::types::as_bool_f(&value_of_f_13013)), ::std::rc::Rc::new(block_k_13036), ::std::rc::Rc::new(else_x_pp.clone())))))
                            };
                            match else_b_oo.clone() {
                                ::std::option::Option::Some(eb_pq) => crate::prelude::call_value((&block_k_f6)((env_p1x.clone(), eb_pq.clone())), move |block_k_12931: crate::lower::model::Ex| k_let12879(block_k_12931)),
                                ::std::option::Option::None => crate::prelude::call_value((&k_f3x)((env_p1x.clone(), crate::lower::model::Ex::XUnit)), move |k_12971: crate::lower::model::Ex| k_let12879(k_12971)),
                            }
                        };
                    }
                    if let crate::syntax::ExprKind::EBinary(op_pr, l_ps, r_pt) = scrutinee && (((op_pr == &crate::prelude::Text::lit("and")) || (op_pr == &crate::prelude::Text::lit("or"))) && any_job_f(&lx_p0x, &env_p1x, &**r_pt)) {
                        break 'm12135 {
                            let l_psx = (**l_ps).clone();
                            let op_prx = op_pr.clone();
                            let r_ptx = (**r_pt).clone();
                            crate::prelude::call_then(start_tail_k_f(lx_p0x.clone(), env_p1x.clone(), r_ptx.clone(), k_f3x.clone()), move |tail_k_f_13174: crate::lower::model::Ex| {
                                let right_x_pu = tail_k_f_13174;
                                if &op_prx == &crate::prelude::Text::lit("and") {
                                    crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p0x.clone(), env_p1x.clone(), l_psx.clone()), move |value_of_f_13239: crate::lower::types::Vl| crate::prelude::call_value((&k_f3x)((env_p1x.clone(), crate::lower::model::Ex::XBool(false))), move |k_13270: crate::lower::model::Ex| ::prism_rtl::Turn::Finished(crate::lower::model::Ex::XIf(::std::rc::Rc::new(crate::lower::types::as_bool_f(&value_of_f_13239)), ::std::rc::Rc::new(right_x_pu.clone()), ::std::rc::Rc::new(k_13270)))))
                                } else {
                                    crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p0x.clone(), env_p1x.clone(), l_psx.clone()), move |value_of_f_13327: crate::lower::types::Vl| crate::prelude::call_value((&k_f3x)((env_p1x.clone(), crate::lower::model::Ex::XBool(true))), move |k_13350: crate::lower::model::Ex| ::prism_rtl::Turn::Finished(crate::lower::model::Ex::XIf(::std::rc::Rc::new(crate::lower::types::as_bool_f(&value_of_f_13327)), ::std::rc::Rc::new(k_13350), ::std::rc::Rc::new(right_x_pu.clone())))))
                                }
                            })
                        };
                    }
                    crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p0x.clone(), env_p1x.clone(), e_p2x.clone()), move |value_of_f_13415: crate::lower::types::Vl| (&k_f3x)((env_p1x.clone(), crate::lower::types::own_f(&value_of_f_13415))).cycle())
                }
            },
        })
    }
}

/// `Start TailK, x`: what the function value is when passed to `@Run`.
pub fn start_tail_k_f(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, e_p2: crate::syntax::Expr, k_f3: ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::types::Env, crate::lower::model::Ex)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>>>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>> {
    ::std::rc::Rc::new(TailK { lx_p0, env_p1, e_p2, k_f3 })
}

/// ```prism
/// BranchJobs: unbounded fn Lx, Env, Expr -> Bool
/// ```
pub fn branch_jobs_f(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, e_p2: &crate::syntax::Expr) -> bool {
    'm13687: {
        let scrutinee = &*e_p2.kind_p;
        if let crate::syntax::ExprKind::EGroup(y_p3) = scrutinee {
            break 'm13687 branch_jobs_f(lx_p0, env_p1, &**y_p3);
        }
        if let crate::syntax::ExprKind::EMatch(_, arms_p4) = scrutinee {
            break 'm13687 crate::prelude::run_to_end(crate::prelude::fold_job(arms_p4.clone(), false, {
                let lx_p0x = lx_p0.clone();
                let env_p1x = env_p1.clone();
                ::std::rc::Rc::new(move |(p0, p1): (bool, crate::syntax::Arm)| {
                    let lx_p0xy = lx_p0x.clone();
                    let env_p1xy = env_p1x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let f_p5 = p0;
                        let a_p6 = p1;
                        if f_p5 {
                            ::prism_rtl::Turn::Finished(true)
                        } else {
                            ::prism_rtl::Turn::More(::std::rc::Rc::new(BlockJob { lx_p0: lx_p0xy.clone(), env_p1: env_p1xy.clone(), b_p2: a_p6.body_p.clone() }))
                        }
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::syntax::Arm)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
            }));
        }
        if let crate::syntax::ExprKind::EIf(m13687_2_0, then_b_p7, else_b_o8) = scrutinee && let crate::syntax::Cond::CondExpr(_) = &**m13687_2_0 {
            break 'm13687 block_job_f(lx_p0, env_p1, then_b_p7) || match else_b_o8 {
                ::std::option::Option::Some(eb_p9) => block_job_f(lx_p0, env_p1, eb_p9),
                ::std::option::Option::None => false,
            };
        }
        if let crate::syntax::ExprKind::EBinary(op_pa, _, r_pb) = scrutinee {
            break 'm13687 ((op_pa == &crate::prelude::Text::lit("and")) || (op_pa == &crate::prelude::Text::lit("or"))) && any_job_f(lx_p0, env_p1, &**r_pb);
        }
        false
    }
}

/// The step machine of `BranchJobs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BranchJobs: unbounded fn Lx, Env, Expr -> Bool
/// ```
pub struct BranchJobs {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub e_p2: crate::syntax::Expr,
}

impl ::prism_rtl::Job<bool> for BranchJobs {
    fn cycle(&self) -> ::prism_rtl::Turn<bool> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let e_p2 = &self.e_p2;
        'm13687: {
            let scrutinee = &*e_p2.kind_p;
            if let crate::syntax::ExprKind::EGroup(y_p3) = scrutinee {
                break 'm13687 ::prism_rtl::Turn::More(::std::rc::Rc::new(BranchJobs { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), e_p2: (**y_p3).clone() }));
            }
            if let crate::syntax::ExprKind::EMatch(_, arms_p4) = scrutinee {
                break 'm13687 crate::prelude::fold_job(arms_p4.clone(), false, {
                    let lx_p0x = lx_p0.clone();
                    let env_p1x = env_p1.clone();
                    ::std::rc::Rc::new(move |(p0, p1): (bool, crate::syntax::Arm)| {
                        let lx_p0xy = lx_p0x.clone();
                        let env_p1xy = env_p1x.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let f_p5 = p0;
                            let a_p6 = p1;
                            if f_p5 {
                                ::prism_rtl::Turn::Finished(true)
                            } else {
                                ::prism_rtl::Turn::More(::std::rc::Rc::new(BlockJob { lx_p0: lx_p0xy.clone(), env_p1: env_p1xy.clone(), b_p2: a_p6.body_p.clone() }))
                            }
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::syntax::Arm)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
                }).cycle();
            }
            if let crate::syntax::ExprKind::EIf(m13687_2_0, then_b_p7, else_b_o8) = scrutinee && let crate::syntax::Cond::CondExpr(_) = &**m13687_2_0 {
                break 'm13687 {
                    let else_b_o8x = else_b_o8.clone();
                    let env_p1x = env_p1.clone();
                    let lx_p0x = lx_p0.clone();
                    let then_b_p7x = then_b_p7.clone();
                    crate::prelude::call_then(start_block_job_f(lx_p0x.clone(), env_p1x.clone(), then_b_p7x.clone()), move |block_job_f_13861: bool| if block_job_f_13861 {
                        ::prism_rtl::Turn::Finished(true)
                    } else {
                        match &else_b_o8x {
                            ::std::option::Option::Some(eb_p9) => ::prism_rtl::Turn::More(::std::rc::Rc::new(BlockJob { lx_p0: lx_p0x.clone(), env_p1: env_p1x.clone(), b_p2: eb_p9.clone() })),
                            ::std::option::Option::None => ::prism_rtl::Turn::Finished(false),
                        }
                    })
                };
            }
            if let crate::syntax::ExprKind::EBinary(op_pa, _, r_pb) = scrutinee {
                break 'm13687 if (op_pa == &crate::prelude::Text::lit("and")) || (op_pa == &crate::prelude::Text::lit("or")) {
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(AnyJob { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), e_p2: (**r_pb).clone() }))
                } else {
                    ::prism_rtl::Turn::Finished(false)
                };
            }
            ::prism_rtl::Turn::Finished(false)
        }
    }
}

/// `Start BranchJobs, x`: what the function value is when passed to `@Run`.
pub fn start_branch_jobs_f(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, e_p2: crate::syntax::Expr) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>> {
    ::std::rc::Rc::new(BranchJobs { lx_p0, env_p1, e_p2 })
}

/// ```prism
/// BlockJob: unbounded fn Lx, Env, Block -> Bool
/// ```
pub fn block_job_f(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, b_p2: &crate::syntax::Block) -> bool {
    crate::prelude::run_to_end(crate::prelude::fold_job(b_p2.stmts_p.clone(), false, {
        let lx_p0x = lx_p0.clone();
        let env_p1x = env_p1.clone();
        ::std::rc::Rc::new(move |(p0, p1): (bool, crate::syntax::Stmt)| {
            let lx_p0xy = lx_p0x.clone();
            let env_p1xy = env_p1x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let f_p3 = p0;
                let st_p4 = p1;
                if f_p3 {
                    ::prism_rtl::Turn::Finished(true)
                } else {
                    match &st_p4.kind_p {
                        crate::syntax::StmtKind::SLet(_, _, x_p5) => ::prism_rtl::Turn::More(::std::rc::Rc::new(AnyJob { lx_p0: lx_p0xy.clone(), env_p1: env_p1xy.clone(), e_p2: x_p5.clone() })),
                        crate::syntax::StmtKind::SExpr(x_p6) => ::prism_rtl::Turn::More(::std::rc::Rc::new(AnyJob { lx_p0: lx_p0xy.clone(), env_p1: env_p1xy.clone(), e_p2: x_p6.clone() })),
                        _ => ::prism_rtl::Turn::Finished(false),
                    }
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::syntax::Stmt)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
    }))
}

/// The step machine of `BlockJob`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BlockJob: unbounded fn Lx, Env, Block -> Bool
/// ```
pub struct BlockJob {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub b_p2: crate::syntax::Block,
}

impl ::prism_rtl::Job<bool> for BlockJob {
    fn cycle(&self) -> ::prism_rtl::Turn<bool> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let b_p2 = &self.b_p2;
        crate::prelude::fold_job(b_p2.stmts_p.clone(), false, {
            let lx_p0x = lx_p0.clone();
            let env_p1x = env_p1.clone();
            ::std::rc::Rc::new(move |(p0, p1): (bool, crate::syntax::Stmt)| {
                let lx_p0xy = lx_p0x.clone();
                let env_p1xy = env_p1x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let f_p3 = p0;
                    let st_p4 = p1;
                    if f_p3 {
                        ::prism_rtl::Turn::Finished(true)
                    } else {
                        match &st_p4.kind_p {
                            crate::syntax::StmtKind::SLet(_, _, x_p5) => ::prism_rtl::Turn::More(::std::rc::Rc::new(AnyJob { lx_p0: lx_p0xy.clone(), env_p1: env_p1xy.clone(), e_p2: x_p5.clone() })),
                            crate::syntax::StmtKind::SExpr(x_p6) => ::prism_rtl::Turn::More(::std::rc::Rc::new(AnyJob { lx_p0: lx_p0xy.clone(), env_p1: env_p1xy.clone(), e_p2: x_p6.clone() })),
                            _ => ::prism_rtl::Turn::Finished(false),
                        }
                    }
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::syntax::Stmt)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
        }).cycle()
    }
}

/// `Start BlockJob, x`: what the function value is when passed to `@Run`.
pub fn start_block_job_f(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, b_p2: crate::syntax::Block) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>> {
    ::std::rc::Rc::new(BlockJob { lx_p0, env_p1, b_p2 })
}

/// ```prism
/// AnyJob: unbounded fn Lx, Env, Expr -> Bool
/// ```
pub fn any_job_f(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, e_p2: &crate::syntax::Expr) -> bool {
    match frame_call_o(lx_p0, env_p1, e_p2, &false) {
        ::std::option::Option::Some(_) => true,
        ::std::option::Option::None => branch_jobs_f(lx_p0, env_p1, e_p2),
    }
}

/// The step machine of `AnyJob`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// AnyJob: unbounded fn Lx, Env, Expr -> Bool
/// ```
pub struct AnyJob {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub e_p2: crate::syntax::Expr,
}

impl ::prism_rtl::Job<bool> for AnyJob {
    fn cycle(&self) -> ::prism_rtl::Turn<bool> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let e_p2 = &self.e_p2;
        let e_p2x = e_p2.clone();
        let env_p1x = env_p1.clone();
        let lx_p0x = lx_p0.clone();
        crate::prelude::call_then(start_frame_call_o(lx_p0x.clone(), env_p1x.clone(), e_p2x.clone(), false), move |frame_call_o_14515: ::std::option::Option<crate::syntax::Expr>| match frame_call_o_14515 {
            ::std::option::Option::Some(_) => ::prism_rtl::Turn::Finished(true),
            ::std::option::Option::None => ::prism_rtl::Turn::More(::std::rc::Rc::new(BranchJobs { lx_p0: lx_p0x.clone(), env_p1: env_p1x.clone(), e_p2: e_p2x.clone() })),
        })
    }
}

/// `Start AnyJob, x`: what the function value is when passed to `@Run`.
pub fn start_any_job_f(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, e_p2: crate::syntax::Expr) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>> {
    ::std::rc::Rc::new(AnyJob { lx_p0, env_p1, e_p2 })
}

/// ```prism
/// HasTopWhile: fn Lx, Block -> Bool
/// ```
pub fn has_top_while_f(lx_p0: &crate::lower::Lx, b_p1: &crate::syntax::Block) -> bool {
    crate::prelude::fold(&b_p1.stmts_p, &false, &(|f_p2: &bool, st_p3: &crate::syntax::Stmt| (*f_p2 || is_cycle_while_f(lx_p0, st_p3)) || holds_cycle_while_f(lx_p0, st_p3)))
}

/// ```prism
/// IsCycleWhile: fn Lx, Stmt -> Bool
/// ```
pub fn is_cycle_while_f(lx_p0: &crate::lower::Lx, st_p1: &crate::syntax::Stmt) -> bool {
    match &st_p1.kind_p {
        crate::syntax::StmtKind::SWhile(_, _) => crate::check::env::has_key_f(&lx_p0.unshrunk_p, &crate::lower::place_key_f(lx_p0, &st_p1.span_p)),
        _ => false,
    }
}

/// ```prism
/// ElseHasTopWhile: fn Lx, ?Block -> Bool
/// ```
pub fn else_has_top_while_f(lx_p0: &crate::lower::Lx, opt1: &::std::option::Option<crate::syntax::Block>) -> bool {
    match opt1 {
        ::std::option::Option::Some(b_p1) => has_top_while_f(lx_p0, b_p1),
        ::std::option::Option::None => false,
    }
}

/// ```prism
/// HoldsCycleWhile: fn Lx, Stmt -> Bool
/// ```
pub fn holds_cycle_while_f(lx_p0: &crate::lower::Lx, st_p1: &crate::syntax::Stmt) -> bool {
    match &st_p1.kind_p {
        crate::syntax::StmtKind::SWhile(_, wb_p2) => has_top_while_f(lx_p0, wb_p2),
        crate::syntax::StmtKind::SExpr(x_p3) => match &*x_p3.kind_p {
            crate::syntax::ExprKind::EIf(_, then_b_p4, else_b_o5) => has_top_while_f(lx_p0, then_b_p4) || else_has_top_while_f(lx_p0, else_b_o5),
            crate::syntax::ExprKind::EMatch(_, arms_p6) => crate::prelude::fold(arms_p6, &false, &(|f_p7: &bool, a_p8: &crate::syntax::Arm| *f_p7 || has_top_while_f(lx_p0, &a_p8.body_p))),
            crate::syntax::ExprKind::EFor(_, _, fb_p9) => has_top_while_f(lx_p0, fb_p9),
            _ => false,
        },
        _ => false,
    }
}

/// ```prism
/// UpdTail: unbounded fn Lx, Env, Expr, Block, Range, (unbounded fn Env, Ex -> Ex) -> Ex
/// ```
pub fn upd_tail_f(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, target_p2: &crate::syntax::Expr, b_p3: &crate::syntax::Block, to_p4: &crate::syntax::Range, cont_f5: &::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::types::Env, crate::lower::model::Ex)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>>>) -> crate::lower::model::Ex {
    let t_p6 = crate::lower::types::out_ty_of_f(lx_p0, &crate::lower::types::peel_f(&crate::lower::type_at_f(lx_p0, &target_p2.span_p)));
    let tv_p7 = crate::lower::expr::value_of_f(lx_p0, env_p1, target_p2);
    let env1_p8 = crate::lower::types::bind_f(env_p1, &crate::prelude::Text::lit("&_"), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("this")), crate::lower::types::Holding::Owned, t_p6.clone()));
    prepend_f(&crate::prelude::Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaMut(crate::prelude::Text::lit("this"))), t_p6.clone()), crate::lower::types::own_f(&tv_p7))]), &upd_tail_from_f(lx_p0, env_p1, &env1_p8, b_p3, &crate::prelude::Nat::from(0u32), to_p4, &cont_f5.clone()))
}

/// The step machine of `UpdTail`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UpdTail: unbounded fn Lx, Env, Expr, Block, Range, (unbounded fn Env, Ex -> Ex) -> Ex
/// ```
pub struct UpdTail {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub target_p2: crate::syntax::Expr,
    pub b_p3: crate::syntax::Block,
    pub to_p4: crate::syntax::Range,
    pub cont_f5: ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::types::Env, crate::lower::model::Ex)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>>>,
}

impl ::prism_rtl::Job<crate::lower::model::Ex> for UpdTail {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::lower::model::Ex> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let target_p2 = &self.target_p2;
        let b_p3 = &self.b_p3;
        let to_p4 = &self.to_p4;
        let cont_f5 = &self.cont_f5;
        let cont_f5x = cont_f5.clone();
        let b_p3x = b_p3.clone();
        let env_p1x = env_p1.clone();
        let lx_p0x = lx_p0.clone();
        let target_p2x = target_p2.clone();
        let to_p4x = to_p4.clone();
        crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0x.clone(), crate::lower::types::peel_f(&crate::lower::type_at_f(&lx_p0x, &target_p2x.span_p))), move |out_ty_of_f_16972: crate::lower::model::OutTy| {
            let t_p6 = out_ty_of_f_16972;
            crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p0x.clone(), env_p1x.clone(), target_p2x.clone()), move |value_of_f_17029: crate::lower::types::Vl| {
                let tv_p7 = value_of_f_17029;
                let env1_p8 = crate::lower::types::bind_f(&env_p1x, &crate::prelude::Text::lit("&_"), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(crate::prelude::Text::lit("this")), crate::lower::types::Holding::Owned, t_p6.clone()));
                crate::prelude::call_then(start_upd_tail_from_f(lx_p0x.clone(), env_p1x.clone(), env1_p8.clone(), b_p3x.clone(), crate::prelude::Nat::from(0u32), to_p4x.clone(), cont_f5x.clone()), move |upd_tail_from_f_17182: crate::lower::model::Ex| ::prism_rtl::Turn::Finished(prepend_f(&crate::prelude::Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaMut(crate::prelude::Text::lit("this"))), t_p6.clone()), crate::lower::types::own_f(&tv_p7))]), &upd_tail_from_f_17182)))
            })
        })
    }
}

/// `Start UpdTail, x`: what the function value is when passed to `@Run`.
pub fn start_upd_tail_f(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, target_p2: crate::syntax::Expr, b_p3: crate::syntax::Block, to_p4: crate::syntax::Range, cont_f5: ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::types::Env, crate::lower::model::Ex)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>>>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>> {
    ::std::rc::Rc::new(UpdTail { lx_p0, env_p1, target_p2, b_p3, to_p4, cont_f5 })
}

/// ```prism
/// UpdTailFrom: unbounded fn Lx, Env, Env, Block, Nat, Range, (unbounded fn Env, Ex -> Ex) -> Ex
/// ```
pub fn upd_tail_from_f(lx_p0: &crate::lower::Lx, outer_p1: &crate::lower::types::Env, env_p2: &crate::lower::types::Env, b_p3: &crate::syntax::Block, i_p4: &crate::prelude::Nat, to_p5: &crate::syntax::Range, cont_f6: &::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::types::Env, crate::lower::model::Ex)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>>>) -> crate::lower::model::Ex {
    if i_p4 >= &crate::prelude::len(&b_p3.stmts_p) {
        crate::prelude::run_to_end(cont_f6((outer_p1.clone(), crate::lower::model::Ex::XVar(crate::prelude::Text::lit("this")))))
    } else {
        {
            let s_p7 = crate::prelude::or(&crate::prelude::index(&b_p3.stmts_p, i_p4), &crate::lower::expr::dummy_stmt_l_p());
            let rest_p8 = rest_reads_f(lx_p0, &crate::syntax::Range { start_p: s_p7.span_p.end_p.clone(), end_p: s_p7.span_p.end_p.clone() }, &crate::syntax::Range { start_p: s_p7.span_p.end_p.clone(), end_p: s_p7.span_p.end_p.clone() }, to_p5);
            let next_f9 = {
                let lx_p0x = lx_p0.clone();
                let b_p3x = b_p3.clone();
                let i_p4x = i_p4.clone();
                let to_p5x = to_p5.clone();
                let cont_f6x = cont_f6.clone();
                ::std::rc::Rc::new(move |(p0, p1): (crate::lower::types::Env, crate::lower::types::Env)| {
                    let lx_p0xy = lx_p0x.clone();
                    let b_p3xy = b_p3x.clone();
                    let i_p4xy = i_p4x.clone();
                    let to_p5xy = to_p5x.clone();
                    let cont_f6xy = cont_f6x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let o2_pa = p0;
                        let e2_pb = p1;
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(UpdTailFrom { lx_p0: lx_p0xy.clone(), outer_p1: o2_pa.clone(), env_p2: e2_pb.clone(), b_p3: b_p3xy.clone(), i_p4: &i_p4xy + &crate::prelude::Nat::from(1u32), to_p5: to_p5xy.clone(), cont_f6: cont_f6xy.clone() }))
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::types::Env, crate::lower::types::Env)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>>>
            };
            if is_cycle_while_f(lx_p0, &s_p7) || holds_cycle_while_f(lx_p0, &s_p7) {
                stmt_job_f(lx_p0, outer_p1, env_p2, &s_p7, &rest_p8, &next_f9.clone())
            } else {
                {
                    let (dos_pc, env2_pd) = crate::lower::templates::upd_stmt_f(lx_p0, env_p2, &s_p7);
                    prepend_f(&dos_pc, &upd_tail_from_f(lx_p0, outer_p1, &env2_pd, b_p3, &(i_p4 + &crate::prelude::Nat::from(1u32)), to_p5, &cont_f6.clone()))
                }
            }
        }
    }
}

/// The step machine of `UpdTailFrom`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UpdTailFrom: unbounded fn Lx, Env, Env, Block, Nat, Range, (unbounded fn Env, Ex -> Ex) -> Ex
/// ```
pub struct UpdTailFrom {
    pub lx_p0: crate::lower::Lx,
    pub outer_p1: crate::lower::types::Env,
    pub env_p2: crate::lower::types::Env,
    pub b_p3: crate::syntax::Block,
    pub i_p4: crate::prelude::Nat,
    pub to_p5: crate::syntax::Range,
    pub cont_f6: ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::types::Env, crate::lower::model::Ex)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>>>,
}

impl ::prism_rtl::Job<crate::lower::model::Ex> for UpdTailFrom {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::lower::model::Ex> {
        let lx_p0 = &self.lx_p0;
        let outer_p1 = &self.outer_p1;
        let env_p2 = &self.env_p2;
        let b_p3 = &self.b_p3;
        let i_p4 = &self.i_p4;
        let to_p5 = &self.to_p5;
        let cont_f6 = &self.cont_f6;
        if i_p4 >= &crate::prelude::len(&b_p3.stmts_p) {
            cont_f6((outer_p1.clone(), crate::lower::model::Ex::XVar(crate::prelude::Text::lit("this")))).cycle()
        } else {
            {
                let s_p7 = crate::prelude::or(&crate::prelude::index(&b_p3.stmts_p, i_p4), &crate::lower::expr::dummy_stmt_l_p());
                let rest_p8 = rest_reads_f(lx_p0, &crate::syntax::Range { start_p: s_p7.span_p.end_p.clone(), end_p: s_p7.span_p.end_p.clone() }, &crate::syntax::Range { start_p: s_p7.span_p.end_p.clone(), end_p: s_p7.span_p.end_p.clone() }, to_p5);
                let next_f9 = {
                    let lx_p0x = lx_p0.clone();
                    let b_p3x = b_p3.clone();
                    let i_p4x = i_p4.clone();
                    let to_p5x = to_p5.clone();
                    let cont_f6x = cont_f6.clone();
                    ::std::rc::Rc::new(move |(p0, p1): (crate::lower::types::Env, crate::lower::types::Env)| {
                        let lx_p0xy = lx_p0x.clone();
                        let b_p3xy = b_p3x.clone();
                        let i_p4xy = i_p4x.clone();
                        let to_p5xy = to_p5x.clone();
                        let cont_f6xy = cont_f6x.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let o2_pa = p0;
                            let e2_pb = p1;
                            ::prism_rtl::Turn::More(::std::rc::Rc::new(UpdTailFrom { lx_p0: lx_p0xy.clone(), outer_p1: o2_pa.clone(), env_p2: e2_pb.clone(), b_p3: b_p3xy.clone(), i_p4: &i_p4xy + &crate::prelude::Nat::from(1u32), to_p5: to_p5xy.clone(), cont_f6: cont_f6xy.clone() }))
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::types::Env, crate::lower::types::Env)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>>>
                };
                if is_cycle_while_f(lx_p0, &s_p7) || holds_cycle_while_f(lx_p0, &s_p7) {
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(StmtJob { lx_p0: lx_p0.clone(), outer_p1: outer_p1.clone(), env_p2: env_p2.clone(), s_p3: s_p7.clone(), rest_p4: rest_p8.clone(), cont_f5: next_f9.clone() }))
                } else {
                    {
                        let cont_f6x = cont_f6.clone();
                        let b_p3x = b_p3.clone();
                        let env_p2x = env_p2.clone();
                        let i_p4x = i_p4.clone();
                        let lx_p0x = lx_p0.clone();
                        let outer_p1x = outer_p1.clone();
                        let to_p5x = to_p5.clone();
                        crate::prelude::call_then(crate::lower::templates::start_upd_stmt_f(lx_p0x.clone(), env_p2x.clone(), s_p7.clone()), move |upd_stmt_f_17810: (crate::prelude::Array<crate::lower::model::Do>, crate::lower::types::Env)| {
                            let (dos_pc, env2_pd) = upd_stmt_f_17810;
                            crate::prelude::call_then(start_upd_tail_from_f(lx_p0x.clone(), outer_p1x.clone(), env2_pd.clone(), b_p3x.clone(), &i_p4x + &crate::prelude::Nat::from(1u32), to_p5x.clone(), cont_f6x.clone()), move |upd_tail_from_f_17855: crate::lower::model::Ex| ::prism_rtl::Turn::Finished(prepend_f(&dos_pc, &upd_tail_from_f_17855)))
                        })
                    }
                }
            }
        }
    }
}

/// `Start UpdTailFrom, x`: what the function value is when passed to `@Run`.
pub fn start_upd_tail_from_f(lx_p0: crate::lower::Lx, outer_p1: crate::lower::types::Env, env_p2: crate::lower::types::Env, b_p3: crate::syntax::Block, i_p4: crate::prelude::Nat, to_p5: crate::syntax::Range, cont_f6: ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::types::Env, crate::lower::model::Ex)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>>>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>> {
    ::std::rc::Rc::new(UpdTailFrom { lx_p0, outer_p1, env_p2, b_p3, i_p4, to_p5, cont_f6 })
}

/// ```prism
/// StmtJob: unbounded fn Lx, Env, Env, Stmt, [Text], (unbounded fn Env, Env -> Ex) -> Ex
/// ```
pub fn stmt_job_f(lx_p0: &crate::lower::Lx, outer_p1: &crate::lower::types::Env, env_p2: &crate::lower::types::Env, s_p3: &crate::syntax::Stmt, rest_p4: &crate::prelude::Array<crate::prelude::Text>, cont_f5: &::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::types::Env, crate::lower::types::Env)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>>>) -> crate::lower::model::Ex {
    match &s_p3.kind_p {
        crate::syntax::StmtKind::SWhile(c_p6, wb_p7) => while_job_f(lx_p0, outer_p1, env_p2, c_p6, wb_p7, &s_p3.span_p, rest_p4, &cont_f5.clone()),
        crate::syntax::StmtKind::SExpr(x_p8) => match &*x_p8.kind_p {
            crate::syntax::ExprKind::EIf(c_p9, then_b_pa, else_b_ob) => if_job_f(lx_p0, outer_p1, env_p2, &**c_p9, then_b_pa, else_b_ob, &s_p3.span_p, rest_p4, &cont_f5.clone()),
            crate::syntax::ExprKind::EMatch(scrut_pc, arms_pd) => match_job_f(lx_p0, outer_p1, env_p2, &**scrut_pc, arms_pd, &s_p3.span_p, rest_p4, &cont_f5.clone()),
            crate::syntax::ExprKind::EFor(binders_oe, source_pf, body_pg) => for_job_f(lx_p0, outer_p1, env_p2, binders_oe, &**source_pf, body_pg, &s_p3.span_p, rest_p4, &cont_f5.clone()),
            _ => crate::lower::expr::internal_bug_f(&crate::prelude::Text::from(format!("a cycle-point `while` in {} (gap LP)", &crate::lower::expr::kind_words_f(&*x_p8.kind_p)))),
        },
        _ => crate::lower::expr::internal_bug_f(&crate::prelude::Text::lit("a cycle-point `while` in this statement (gap LP)")),
    }
}

/// The step machine of `StmtJob`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// StmtJob: unbounded fn Lx, Env, Env, Stmt, [Text], (unbounded fn Env, Env -> Ex) -> Ex
/// ```
pub struct StmtJob {
    pub lx_p0: crate::lower::Lx,
    pub outer_p1: crate::lower::types::Env,
    pub env_p2: crate::lower::types::Env,
    pub s_p3: crate::syntax::Stmt,
    pub rest_p4: crate::prelude::Array<crate::prelude::Text>,
    pub cont_f5: ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::types::Env, crate::lower::types::Env)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>>>,
}

impl ::prism_rtl::Job<crate::lower::model::Ex> for StmtJob {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::lower::model::Ex> {
        let lx_p0 = &self.lx_p0;
        let outer_p1 = &self.outer_p1;
        let env_p2 = &self.env_p2;
        let s_p3 = &self.s_p3;
        let rest_p4 = &self.rest_p4;
        let cont_f5 = &self.cont_f5;
        match &s_p3.kind_p {
            crate::syntax::StmtKind::SWhile(c_p6, wb_p7) => ::prism_rtl::Turn::More(::std::rc::Rc::new(WhileJob { lx_p0: lx_p0.clone(), outer_p1: outer_p1.clone(), env_p2: env_p2.clone(), c_p3: c_p6.clone(), wb_p4: wb_p7.clone(), span_p5: s_p3.span_p.clone(), rest_reads_p6: rest_p4.clone(), cont_f7: cont_f5.clone() })),
            crate::syntax::StmtKind::SExpr(x_p8) => match &*x_p8.kind_p {
                crate::syntax::ExprKind::EIf(c_p9, then_b_pa, else_b_ob) => ::prism_rtl::Turn::More(::std::rc::Rc::new(IfJob { lx_p0: lx_p0.clone(), outer_p1: outer_p1.clone(), env_p2: env_p2.clone(), c_p3: (**c_p9).clone(), then_b_p4: then_b_pa.clone(), else_b_o5: else_b_ob.clone(), span_p6: s_p3.span_p.clone(), rest_reads_p7: rest_p4.clone(), cont_f8: cont_f5.clone() })),
                crate::syntax::ExprKind::EMatch(scrut_pc, arms_pd) => ::prism_rtl::Turn::More(::std::rc::Rc::new(MatchJob { lx_p0: lx_p0.clone(), outer_p1: outer_p1.clone(), env_p2: env_p2.clone(), scrut_p3: (**scrut_pc).clone(), arms_p4: arms_pd.clone(), span_p5: s_p3.span_p.clone(), rest_reads_p6: rest_p4.clone(), cont_f7: cont_f5.clone() })),
                crate::syntax::ExprKind::EFor(binders_oe, source_pf, body_pg) => ::prism_rtl::Turn::More(::std::rc::Rc::new(ForJob { lx_p0: lx_p0.clone(), outer_p1: outer_p1.clone(), env_p2: env_p2.clone(), binders_o3: binders_oe.clone(), source_p4: (**source_pf).clone(), body_p5: body_pg.clone(), span_p6: s_p3.span_p.clone(), rest_reads_p7: rest_p4.clone(), cont_f8: cont_f5.clone() })),
                _ => ::prism_rtl::Turn::Finished(crate::lower::expr::internal_bug_f(&crate::prelude::Text::from(format!("a cycle-point `while` in {} (gap LP)", &crate::lower::expr::kind_words_f(&*x_p8.kind_p))))),
            },
            _ => ::prism_rtl::Turn::Finished(crate::lower::expr::internal_bug_f(&crate::prelude::Text::lit("a cycle-point `while` in this statement (gap LP)"))),
        }
    }
}

/// `Start StmtJob, x`: what the function value is when passed to `@Run`.
pub fn start_stmt_job_f(lx_p0: crate::lower::Lx, outer_p1: crate::lower::types::Env, env_p2: crate::lower::types::Env, s_p3: crate::syntax::Stmt, rest_p4: crate::prelude::Array<crate::prelude::Text>, cont_f5: ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::types::Env, crate::lower::types::Env)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>>>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>> {
    ::std::rc::Rc::new(StmtJob { lx_p0, outer_p1, env_p2, s_p3, rest_p4, cont_f5 })
}

/// ```prism
/// Prepend: fn [Do], Ex -> Ex
/// ```
pub fn prepend_f(dos_p0: &crate::prelude::Array<crate::lower::model::Do>, ex1: &crate::lower::model::Ex) -> crate::lower::model::Ex {
    match ex1 {
        crate::lower::model::Ex::XBlock(more_p1, last_p2) => crate::lower::model::Ex::XBlock(crate::prelude::append(dos_p0, more_p1), ::std::rc::Rc::new((**last_p2).clone())),
        x_p4 => if &crate::prelude::len(dos_p0) == &crate::prelude::Nat::from(0u32) {
            x_p4.clone()
        } else {
            crate::lower::model::Ex::XBlock(dos_p0.clone(), ::std::rc::Rc::new(x_p4.clone()))
        },
    }
}

/// ```prism
/// WhileJob: unbounded fn Lx, Env, Env, Cond, Block, Range, [Text], (unbounded fn Env, Env -> Ex) -> Ex
/// ```
pub fn while_job_f(lx_p0: &crate::lower::Lx, outer_p1: &crate::lower::types::Env, env_p2: &crate::lower::types::Env, c_p3: &crate::syntax::Cond, wb_p4: &crate::syntax::Block, span_p5: &crate::syntax::Range, rest_reads_p6: &crate::prelude::Array<crate::prelude::Text>, cont_f7: &::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::types::Env, crate::lower::types::Env)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>>>) -> crate::lower::model::Ex {
    let state_p8 = crate::prelude::fold(&crate::prelude::keys(&env_p2.names_p), &crate::prelude::Array::new(), &(|acc_p11: &crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy)>, k_p12: &crate::prelude::Text| if !crate::syntax::lexer::chars::has_prefix_f(k_p12, &crate::prelude::Text::lit("&")) {
        acc_p11.clone()
    } else {
        match crate::prelude::get(&env_p2.names_p, k_p12) {
            ::std::option::Option::Some(crate::lower::types::Bn::BnLocal(rs_p13, _, bt_p14)) => crate::prelude::push(acc_p11, &(k_p12.clone(), crate::lower::types::place_stem_f(&rs_p13), bt_p14)),
            _ => acc_p11.clone(),
        }
    }));
    let names_p9 = crate::prelude::each(&state_p8, &(|(_, rs_p15, _): &(crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy)| rs_p15.clone()));
    let st_ty_pa = crate::lower::model::OutTy::OutTuple(crate::prelude::each(&state_p8, &(|(_, _, bt_p16): &(crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy)| bt_p16.clone())));
    let pat_pb = crate::lower::model::Pa::PaTuple(crate::prelude::each(&names_p9, &(|n_p17: &crate::prelude::Text| crate::lower::model::Pa::PaMut(crate::prelude::Text::from(format!("{}", n_p17))))));
    let pack_pc = crate::lower::model::Ex::XTuple(crate::prelude::each(&names_p9, &(|n_p18: &crate::prelude::Text| crate::lower::model::Ex::XVar(n_p18.clone()))));
    let env_s_pd = crate::prelude::fold(&state_p8, env_p2, &(|en_p19: &crate::lower::types::Env, (k_p1a, rs_p1b, bt_p1c): &(crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy)| crate::lower::types::bind_f(en_p19, k_p1a, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(rs_p1b.clone()), crate::lower::types::Holding::Owned, bt_p1c.clone()))));
    let loop_reads_pe = reads_in_f(lx_p0, span_p5);
    let caps_pf = caps_in_f(&env_s_pd, &loop_reads_pe, &names_p9);
    let cap_dos_pg = crate::prelude::each(&caps_pf, &(|(_, rs_p1d, mode_p1e, bt_p1f): &(crate::prelude::Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)| crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::lower::expr::capture_name_f(rs_p1d)), crate::lower::types::own_f(&crate::lower::types::Vl::VlPlace(rs_p1d.clone(), mode_p1e.clone(), bt_p1f.clone())))));
    let env_c_ph = crate::prelude::fold(&caps_pf, &env_s_pd, &(|en_p1g: &crate::lower::types::Env, (k_p1h, rs_p1i, _, bt_p1j): &(crate::prelude::Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)| crate::lower::types::bind_f(en_p1g, k_p1h, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(crate::lower::expr::capture_name_f(rs_p1i)), crate::lower::types::Holding::Owned, bt_p1j.clone()))));
    let jobs_pi = has_top_while_f(lx_p0, wb_p4);
    let finish_fj = {
        let jobs_pix = jobs_pi;
        ::std::rc::Rc::new(move |x_p1k: &crate::lower::model::Ex| if jobs_pix {
            crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("prism_rtl::Turn::Finished")), crate::prelude::Array::from(vec![x_p1k.clone()]))
        } else {
            x_p1k.clone()
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(&crate::lower::model::Ex) -> crate::lower::model::Ex>
    };
    let step_ty_pk = crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Result")), crate::prelude::Array::from(vec![st_ty_pa.clone(), st_ty_pa.clone()]));
    let again_pl = (&finish_fj)(&crate::lower::model::Ex::XTyped(::std::rc::Rc::new(crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Ok")), crate::prelude::Array::from(vec![pack_pc.clone()]))), step_ty_pk.clone()));
    let stop_pm = (&finish_fj)(&crate::lower::model::Ex::XTyped(::std::rc::Rc::new(crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Err")), crate::prelude::Array::from(vec![pack_pc.clone()]))), step_ty_pk.clone()));
    let body_fn = {
        let jobs_pix = jobs_pi;
        let lx_p0x = lx_p0.clone();
        let wb_p4x = wb_p4.clone();
        let again_plx = again_pl.clone();
        ::std::rc::Rc::new(move |p0: crate::lower::types::Env| {
            let jobs_pixy = jobs_pix;
            let lx_p0xy = lx_p0x.clone();
            let wb_p4xy = wb_p4x.clone();
            let again_plxy = again_plx.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let en_p1l = p0;
                if jobs_pixy {
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(UpdTailFrom { lx_p0: lx_p0xy.clone(), outer_p1: en_p1l.clone(), env_p2: en_p1l.clone(), b_p3: wb_p4xy.clone(), i_p4: crate::prelude::Nat::from(0u32), to_p5: wb_p4xy.span_p.clone(), cont_f6: {
                        let again_plxyx = again_plxy.clone();
                        ::std::rc::Rc::new(move |(p0, p1): (crate::lower::types::Env, crate::lower::model::Ex)| {
                            let again_plxyxy = again_plxyx.clone();
                            crate::prelude::once_job(move || {
                                let o2_p1m = p0;
                                let e2_p1n = p1;
                                ::prism_rtl::Turn::Finished(again_plxyxy.clone())
                            })
                        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::types::Env, crate::lower::model::Ex)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>>>
                    } }))
                } else {
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(StmtsThen { lx_p0: lx_p0xy.clone(), env_p1: en_p1l.clone(), b_p2: wb_p4xy.clone(), last_p3: again_plxy.clone() }))
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::types::Env) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>>>
    };
    let res_ty_po = if jobs_pi {
        crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("prism_rtl::Turn")), crate::prelude::Array::from(vec![step_ty_pk.clone()]))
    } else {
        st_ty_pa.clone()
    };
    let turn_pp = match c_p3 {
        crate::syntax::Cond::CondExpr(x_p1o) => crate::lower::model::Ex::XIf(::std::rc::Rc::new(crate::lower::types::as_bool_f(&crate::lower::expr::value_of_f(lx_p0, &env_c_ph, &**x_p1o))), ::std::rc::Rc::new(crate::prelude::run_to_end((&body_fn)(env_c_ph.clone()))), ::std::rc::Rc::new(stop_pm.clone())),
        crate::syntax::Cond::CondBind(p_p1p, x_p1q, g_o1r) => {
            let po_p1s = crate::lower::patterns::rust_pat_f(lx_p0, p_p1p, &crate::lower::type_at_f(lx_p0, &x_p1q.span_p), &crate::lower::types::Holding::Owned, &crate::prelude::Text::from(format!("w{}", &span_p5.start_p)));
            let env_b_p1t = crate::lower::expr::bind_all_f(&env_c_ph, &po_p1s.binds_p);
            let conds_p1u = crate::prelude::append(&po_p1s.conds_p, &crate::lower::templates::guard_conds_f(lx_p0, &env_b_p1t, &**g_o1r));
            crate::lower::types::own_f(&crate::lower::expr::arms_value_f(&crate::lower::types::own_f(&crate::lower::expr::value_of_f(lx_p0, &env_c_ph, &**x_p1q)), &crate::prelude::Array::from(vec![crate::lower::model::XArm { pat_p: po_p1s.pa_p.clone(), conds_p: conds_p1u.clone(), body_p: crate::prelude::run_to_end((&body_fn)(env_b_p1t.clone())) }, crate::lower::model::XArm { pat_p: crate::lower::model::Pa::PaWild, conds_p: crate::prelude::Array::new(), body_p: stop_pm.clone() }]), &crate::prelude::Text::from(format!("\'w{}", &span_p5.start_p)), &res_ty_po))
        },
    };
    let out_caps_pq = caps_in_f(outer_p1, rest_reads_p6, &names_p9);
    let out_dos_pr = crate::prelude::each(&out_caps_pq, &(|(_, rs_p1v, mode_p20, bt_p21): &(crate::prelude::Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)| crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::lower::expr::outer_name_f(rs_p1v)), crate::lower::types::own_f(&crate::lower::types::Vl::VlPlace(rs_p1v.clone(), mode_p20.clone(), bt_p21.clone())))));
    let outer2_ps = crate::prelude::fold(&out_caps_pq, outer_p1, &(|en_p22: &crate::lower::types::Env, (k_p23, rs_p24, _, bt_p25): &(crate::prelude::Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)| crate::lower::types::bind_f(en_p22, k_p23, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(crate::lower::expr::outer_name_f(rs_p24)), crate::lower::types::Holding::Owned, bt_p25.clone()))));
    let env2_pt = crate::prelude::fold(&out_caps_pq, &env_s_pd, &(|en_p26: &crate::lower::types::Env, (k_p27, rs_p28, _, bt_p29): &(crate::prelude::Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)| crate::lower::types::bind_f(en_p26, k_p27, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(crate::lower::expr::outer_name_f(rs_p28)), crate::lower::types::Holding::Owned, bt_p29.clone()))));
    let step_fn_pu = prepend_f(&cap_dos_pg, &crate::lower::model::Ex::XClosure(true, crate::prelude::Array::from(vec![crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(pat_pb.clone()), st_ty_pa.clone())]), ::std::rc::Rc::new(turn_pp.clone())));
    let looping_pv = crate::lower::helper_ref_f(&(if jobs_pi {
        crate::prelude::Text::lit("loop_turns")
    } else {
        crate::prelude::Text::lit("loop_job")
    }));
    let enter_p10 = crate::lower::model::Ex::XCall(crate::lower::helper_ref_f(&crate::prelude::Text::lit("call_then")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCall(looping_pv.clone(), crate::prelude::Array::from(vec![pack_pc.clone(), step_fn_pu.clone()])), crate::lower::model::Ex::XClosure(true, crate::prelude::Array::from(vec![crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(pat_pb.clone()), st_ty_pa.clone())]), ::std::rc::Rc::new(crate::prelude::run_to_end(cont_f7((outer2_ps.clone(), env2_pt.clone())))))]));
    prepend_f(&out_dos_pr, &enter_p10)
}

/// The step machine of `WhileJob`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// WhileJob: unbounded fn Lx, Env, Env, Cond, Block, Range, [Text], (unbounded fn Env, Env -> Ex) -> Ex
/// ```
pub struct WhileJob {
    pub lx_p0: crate::lower::Lx,
    pub outer_p1: crate::lower::types::Env,
    pub env_p2: crate::lower::types::Env,
    pub c_p3: crate::syntax::Cond,
    pub wb_p4: crate::syntax::Block,
    pub span_p5: crate::syntax::Range,
    pub rest_reads_p6: crate::prelude::Array<crate::prelude::Text>,
    pub cont_f7: ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::types::Env, crate::lower::types::Env)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>>>,
}

impl ::prism_rtl::Job<crate::lower::model::Ex> for WhileJob {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::lower::model::Ex> {
        let lx_p0 = &self.lx_p0;
        let outer_p1 = &self.outer_p1;
        let env_p2 = &self.env_p2;
        let c_p3 = &self.c_p3;
        let wb_p4 = &self.wb_p4;
        let span_p5 = &self.span_p5;
        let rest_reads_p6 = &self.rest_reads_p6;
        let cont_f7 = &self.cont_f7;
        let state_p8 = crate::prelude::fold(&crate::prelude::keys(&env_p2.names_p), &crate::prelude::Array::new(), &(|acc_p11: &crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy)>, k_p12: &crate::prelude::Text| if !crate::syntax::lexer::chars::has_prefix_f(k_p12, &crate::prelude::Text::lit("&")) {
            acc_p11.clone()
        } else {
            match crate::prelude::get(&env_p2.names_p, k_p12) {
                ::std::option::Option::Some(crate::lower::types::Bn::BnLocal(rs_p13, _, bt_p14)) => crate::prelude::push(acc_p11, &(k_p12.clone(), crate::lower::types::place_stem_f(&rs_p13), bt_p14)),
                _ => acc_p11.clone(),
            }
        }));
        let names_p9 = crate::prelude::each(&state_p8, &(|(_, rs_p15, _): &(crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy)| rs_p15.clone()));
        let st_ty_pa = crate::lower::model::OutTy::OutTuple(crate::prelude::each(&state_p8, &(|(_, _, bt_p16): &(crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy)| bt_p16.clone())));
        let pat_pb = crate::lower::model::Pa::PaTuple(crate::prelude::each(&names_p9, &(|n_p17: &crate::prelude::Text| crate::lower::model::Pa::PaMut(crate::prelude::Text::from(format!("{}", n_p17))))));
        let pack_pc = crate::lower::model::Ex::XTuple(crate::prelude::each(&names_p9, &(|n_p18: &crate::prelude::Text| crate::lower::model::Ex::XVar(n_p18.clone()))));
        let env_s_pd = crate::prelude::fold(&state_p8, env_p2, &(|en_p19: &crate::lower::types::Env, (k_p1a, rs_p1b, bt_p1c): &(crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy)| crate::lower::types::bind_f(en_p19, k_p1a, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(rs_p1b.clone()), crate::lower::types::Holding::Owned, bt_p1c.clone()))));
        let loop_reads_pe = reads_in_f(lx_p0, span_p5);
        let caps_pf = caps_in_f(&env_s_pd, &loop_reads_pe, &names_p9);
        let cap_dos_pg = crate::prelude::each(&caps_pf, &(|(_, rs_p1d, mode_p1e, bt_p1f): &(crate::prelude::Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)| crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::lower::expr::capture_name_f(rs_p1d)), crate::lower::types::own_f(&crate::lower::types::Vl::VlPlace(rs_p1d.clone(), mode_p1e.clone(), bt_p1f.clone())))));
        let env_c_ph = crate::prelude::fold(&caps_pf, &env_s_pd, &(|en_p1g: &crate::lower::types::Env, (k_p1h, rs_p1i, _, bt_p1j): &(crate::prelude::Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)| crate::lower::types::bind_f(en_p1g, k_p1h, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(crate::lower::expr::capture_name_f(rs_p1i)), crate::lower::types::Holding::Owned, bt_p1j.clone()))));
        let jobs_pi = has_top_while_f(lx_p0, wb_p4);
        let finish_fj = {
            let jobs_pix = jobs_pi;
            ::std::rc::Rc::new(move |x_p1k: &crate::lower::model::Ex| if jobs_pix {
                crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("prism_rtl::Turn::Finished")), crate::prelude::Array::from(vec![x_p1k.clone()]))
            } else {
                x_p1k.clone()
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(&crate::lower::model::Ex) -> crate::lower::model::Ex>
        };
        let step_ty_pk = crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Result")), crate::prelude::Array::from(vec![st_ty_pa.clone(), st_ty_pa.clone()]));
        let again_pl = (&finish_fj)(&crate::lower::model::Ex::XTyped(::std::rc::Rc::new(crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Ok")), crate::prelude::Array::from(vec![pack_pc.clone()]))), step_ty_pk.clone()));
        let stop_pm = (&finish_fj)(&crate::lower::model::Ex::XTyped(::std::rc::Rc::new(crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Err")), crate::prelude::Array::from(vec![pack_pc.clone()]))), step_ty_pk.clone()));
        let body_fn = {
            let jobs_pix = jobs_pi;
            let lx_p0x = lx_p0.clone();
            let wb_p4x = wb_p4.clone();
            let again_plx = again_pl.clone();
            ::std::rc::Rc::new(move |p0: crate::lower::types::Env| {
                let jobs_pixy = jobs_pix;
                let lx_p0xy = lx_p0x.clone();
                let wb_p4xy = wb_p4x.clone();
                let again_plxy = again_plx.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let en_p1l = p0;
                    if jobs_pixy {
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(UpdTailFrom { lx_p0: lx_p0xy.clone(), outer_p1: en_p1l.clone(), env_p2: en_p1l.clone(), b_p3: wb_p4xy.clone(), i_p4: crate::prelude::Nat::from(0u32), to_p5: wb_p4xy.span_p.clone(), cont_f6: {
                            let again_plxyx = again_plxy.clone();
                            ::std::rc::Rc::new(move |(p0, p1): (crate::lower::types::Env, crate::lower::model::Ex)| {
                                let again_plxyxy = again_plxyx.clone();
                                crate::prelude::once_job(move || {
                                    let o2_p1m = p0;
                                    let e2_p1n = p1;
                                    ::prism_rtl::Turn::Finished(again_plxyxy.clone())
                                })
                            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::types::Env, crate::lower::model::Ex)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>>>
                        } }))
                    } else {
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(StmtsThen { lx_p0: lx_p0xy.clone(), env_p1: en_p1l.clone(), b_p2: wb_p4xy.clone(), last_p3: again_plxy.clone() }))
                    }
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::types::Env) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>>>
        };
        let res_ty_po = if jobs_pi {
            crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("prism_rtl::Turn")), crate::prelude::Array::from(vec![step_ty_pk.clone()]))
        } else {
            st_ty_pa.clone()
        };
        let cont_f7z = cont_f7.clone();
        let cap_dos_pgz = cap_dos_pg.clone();
        let env_s_pdz = env_s_pd.clone();
        let jobs_piz = jobs_pi;
        let names_p9z = names_p9.clone();
        let outer_p1z = outer_p1.clone();
        let pack_pcz = pack_pc.clone();
        let pat_pbz = pat_pb.clone();
        let rest_reads_p6z = rest_reads_p6.clone();
        let st_ty_paz = st_ty_pa.clone();
        let k_let20985 = move |v20985: crate::lower::model::Ex| {
            let turn_pp = v20985;
            let out_caps_pq = caps_in_f(&outer_p1z, &rest_reads_p6z, &names_p9z);
            let out_dos_pr = crate::prelude::each(&out_caps_pq, &(|(_, rs_p1v, mode_p20, bt_p21): &(crate::prelude::Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)| crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::lower::expr::outer_name_f(rs_p1v)), crate::lower::types::own_f(&crate::lower::types::Vl::VlPlace(rs_p1v.clone(), mode_p20.clone(), bt_p21.clone())))));
            let outer2_ps = crate::prelude::fold(&out_caps_pq, &outer_p1z, &(|en_p22: &crate::lower::types::Env, (k_p23, rs_p24, _, bt_p25): &(crate::prelude::Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)| crate::lower::types::bind_f(en_p22, k_p23, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(crate::lower::expr::outer_name_f(rs_p24)), crate::lower::types::Holding::Owned, bt_p25.clone()))));
            let env2_pt = crate::prelude::fold(&out_caps_pq, &env_s_pdz, &(|en_p26: &crate::lower::types::Env, (k_p27, rs_p28, _, bt_p29): &(crate::prelude::Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)| crate::lower::types::bind_f(en_p26, k_p27, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(crate::lower::expr::outer_name_f(rs_p28)), crate::lower::types::Holding::Owned, bt_p29.clone()))));
            let step_fn_pu = prepend_f(&cap_dos_pgz, &crate::lower::model::Ex::XClosure(true, crate::prelude::Array::from(vec![crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(pat_pbz.clone()), st_ty_paz.clone())]), ::std::rc::Rc::new(turn_pp.clone())));
            let looping_pv = crate::lower::helper_ref_f(&(if jobs_piz {
                crate::prelude::Text::lit("loop_turns")
            } else {
                crate::prelude::Text::lit("loop_job")
            }));
            crate::prelude::call_value((&cont_f7z)((outer2_ps.clone(), env2_pt.clone())), move |cont_22248: crate::lower::model::Ex| {
                let enter_p10 = crate::lower::model::Ex::XCall(crate::lower::helper_ref_f(&crate::prelude::Text::lit("call_then")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCall(looping_pv.clone(), crate::prelude::Array::from(vec![pack_pcz.clone(), step_fn_pu.clone()])), crate::lower::model::Ex::XClosure(true, crate::prelude::Array::from(vec![crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(pat_pbz.clone()), st_ty_paz.clone())]), ::std::rc::Rc::new(cont_22248))]));
                ::prism_rtl::Turn::Finished(prepend_f(&out_dos_pr, &enter_p10))
            })
        };
        match c_p3.clone() {
            crate::syntax::Cond::CondExpr(x_p1o) => {
                let lx_p0x = lx_p0.clone();
                crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p0x.clone(), env_c_ph.clone(), (*x_p1o).clone()), move |value_of_f_21038: crate::lower::types::Vl| crate::prelude::call_value((&body_fn)(env_c_ph.clone()), move |body_21062: crate::lower::model::Ex| k_let20985(crate::lower::model::Ex::XIf(::std::rc::Rc::new(crate::lower::types::as_bool_f(&value_of_f_21038)), ::std::rc::Rc::new(body_21062), ::std::rc::Rc::new(stop_pm.clone())))))
            },
            crate::syntax::Cond::CondBind(p_p1p, x_p1q, g_o1r) => {
                let lx_p0x = lx_p0.clone();
                let span_p5x = span_p5.clone();
                crate::prelude::call_then(crate::lower::patterns::start_rust_pat_f(lx_p0x.clone(), p_p1p.clone(), crate::lower::type_at_f(&lx_p0x, &x_p1q.span_p), crate::lower::types::Holding::Owned, crate::prelude::Text::from(format!("w{}", &span_p5x.start_p))), move |rust_pat_f_21127: crate::lower::patterns::PatOut| {
                    let po_p1s = rust_pat_f_21127;
                    let env_b_p1t = crate::lower::expr::bind_all_f(&env_c_ph, &po_p1s.binds_p);
                    crate::prelude::call_then(crate::lower::templates::start_guard_conds_f(lx_p0x.clone(), env_b_p1t.clone(), (*g_o1r).clone()), move |guard_conds_f_21274: crate::prelude::Array<crate::lower::model::Cc>| {
                        let conds_p1u = crate::prelude::append(&po_p1s.conds_p, &guard_conds_f_21274);
                        crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p0x.clone(), env_c_ph.clone(), (*x_p1q).clone()), move |value_of_f_21332: crate::lower::types::Vl| crate::prelude::call_value((&body_fn)(env_b_p1t.clone()), move |body_21392: crate::lower::model::Ex| k_let20985(crate::lower::types::own_f(&crate::lower::expr::arms_value_f(&crate::lower::types::own_f(&value_of_f_21332), &crate::prelude::Array::from(vec![crate::lower::model::XArm { pat_p: po_p1s.pa_p.clone(), conds_p: conds_p1u.clone(), body_p: body_21392 }, crate::lower::model::XArm { pat_p: crate::lower::model::Pa::PaWild, conds_p: crate::prelude::Array::new(), body_p: stop_pm.clone() }]), &crate::prelude::Text::from(format!("\'w{}", &span_p5x.start_p)), &res_ty_po)))))
                    })
                })
            },
        }
    }
}

/// `Start WhileJob, x`: what the function value is when passed to `@Run`.
pub fn start_while_job_f(lx_p0: crate::lower::Lx, outer_p1: crate::lower::types::Env, env_p2: crate::lower::types::Env, c_p3: crate::syntax::Cond, wb_p4: crate::syntax::Block, span_p5: crate::syntax::Range, rest_reads_p6: crate::prelude::Array<crate::prelude::Text>, cont_f7: ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::types::Env, crate::lower::types::Env)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>>>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>> {
    ::std::rc::Rc::new(WhileJob { lx_p0, outer_p1, env_p2, c_p3, wb_p4, span_p5, rest_reads_p6, cont_f7 })
}

/// ```prism
/// StmtsThen: unbounded fn Lx, Env, Block, Ex -> Ex
/// ```
pub fn stmts_then_f(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, b_p2: &crate::syntax::Block, last_p3: &crate::lower::model::Ex) -> crate::lower::model::Ex {
    let (dos_p4, _) = crate::lower::templates::upd_stmts_f(lx_p0, env_p1, &b_p2.stmts_p);
    crate::lower::model::Ex::XBlock(dos_p4.clone(), ::std::rc::Rc::new(last_p3.clone()))
}

/// The step machine of `StmtsThen`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// StmtsThen: unbounded fn Lx, Env, Block, Ex -> Ex
/// ```
pub struct StmtsThen {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub b_p2: crate::syntax::Block,
    pub last_p3: crate::lower::model::Ex,
}

impl ::prism_rtl::Job<crate::lower::model::Ex> for StmtsThen {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::lower::model::Ex> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let b_p2 = &self.b_p2;
        let last_p3 = &self.last_p3;
        let b_p2x = b_p2.clone();
        let env_p1x = env_p1.clone();
        let last_p3x = last_p3.clone();
        let lx_p0x = lx_p0.clone();
        crate::prelude::call_then(crate::lower::templates::start_upd_stmts_f(lx_p0x.clone(), env_p1x.clone(), b_p2x.stmts_p.clone()), move |upd_stmts_f_22461: (crate::prelude::Array<crate::lower::model::Do>, crate::lower::types::Env)| {
            let (dos_p4, _) = upd_stmts_f_22461;
            ::prism_rtl::Turn::Finished(crate::lower::model::Ex::XBlock(dos_p4.clone(), ::std::rc::Rc::new(last_p3x.clone())))
        })
    }
}

/// `Start StmtsThen, x`: what the function value is when passed to `@Run`.
pub fn start_stmts_then_f(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, b_p2: crate::syntax::Block, last_p3: crate::lower::model::Ex) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>> {
    ::std::rc::Rc::new(StmtsThen { lx_p0, env_p1, b_p2, last_p3 })
}

/// ```prism
/// IfJob: unbounded fn Lx, Env, Env, Cond, Block, ?Block, Range, [Text], (unbounded fn Env, Env -> Ex) -> Ex
/// ```
pub fn if_job_f(lx_p0: &crate::lower::Lx, outer_p1: &crate::lower::types::Env, env_p2: &crate::lower::types::Env, c_p3: &crate::syntax::Cond, then_b_p4: &crate::syntax::Block, else_b_o5: &::std::option::Option<crate::syntax::Block>, span_p6: &crate::syntax::Range, rest_reads_p7: &crate::prelude::Array<crate::prelude::Text>, cont_f8: &::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::types::Env, crate::lower::types::Env)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>>>) -> crate::lower::model::Ex {
    let state_p9 = crate::prelude::fold(&crate::prelude::keys(&env_p2.names_p), &crate::prelude::Array::new(), &(|acc_pp: &crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy)>, k_pq: &crate::prelude::Text| if !crate::syntax::lexer::chars::has_prefix_f(k_pq, &crate::prelude::Text::lit("&")) {
        acc_pp.clone()
    } else {
        match crate::prelude::get(&env_p2.names_p, k_pq) {
            ::std::option::Option::Some(crate::lower::types::Bn::BnLocal(rs_pr, _, bt_ps)) => crate::prelude::push(acc_pp, &(k_pq.clone(), crate::lower::types::place_stem_f(&rs_pr), bt_ps)),
            _ => acc_pp.clone(),
        }
    }));
    let names_pa = crate::prelude::each(&state_p9, &(|(_, rs_pt, _): &(crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy)| rs_pt.clone()));
    let st_ty_pb = crate::lower::model::OutTy::OutTuple(crate::prelude::each(&state_p9, &(|(_, _, bt_pu): &(crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy)| bt_pu.clone())));
    let pat_pc = crate::lower::model::Pa::PaTuple(crate::prelude::each(&names_pa, &(|n_pv: &crate::prelude::Text| crate::lower::model::Pa::PaMut(crate::prelude::Text::from(format!("{}", n_pv))))));
    let pack_pd = crate::lower::model::Ex::XTuple(crate::prelude::each(&names_pa, &(|n_p10: &crate::prelude::Text| crate::lower::model::Ex::XVar(n_p10.clone()))));
    let env_s_pe = crate::prelude::fold(&state_p9, env_p2, &(|en_p11: &crate::lower::types::Env, (k_p12, rs_p13, bt_p14): &(crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy)| crate::lower::types::bind_f(en_p11, k_p12, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(rs_p13.clone()), crate::lower::types::Holding::Owned, bt_p14.clone()))));
    let out_caps_pf = caps_in_f(outer_p1, rest_reads_p7, &names_pa);
    let out_dos_pg = crate::prelude::each(&out_caps_pf, &(|(_, rs_p15, mode_p16, bt_p17): &(crate::prelude::Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)| crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::lower::expr::outer_name_f(rs_p15)), crate::lower::types::own_f(&crate::lower::types::Vl::VlPlace(rs_p15.clone(), mode_p16.clone(), bt_p17.clone())))));
    let outer2_ph = crate::prelude::fold(&out_caps_pf, outer_p1, &(|en_p18: &crate::lower::types::Env, (k_p19, rs_p1a, _, bt_p1b): &(crate::prelude::Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)| crate::lower::types::bind_f(en_p18, k_p19, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(crate::lower::expr::outer_name_f(rs_p1a)), crate::lower::types::Holding::Owned, bt_p1b.clone()))));
    let env2_pi = crate::prelude::fold(&out_caps_pf, &env_s_pe, &(|en_p1c: &crate::lower::types::Env, (k_p1d, rs_p1e, _, bt_p1f): &(crate::prelude::Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)| crate::lower::types::bind_f(en_p1c, k_p1d, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(crate::lower::expr::outer_name_f(rs_p1e)), crate::lower::types::Holding::Owned, bt_p1f.clone()))));
    let k_name_pj = crate::prelude::Text::from(format!("k_if{}", &span_p6.start_p));
    let k_do_pk = crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(k_name_pj.clone()), crate::lower::model::Ex::XClosure(true, crate::prelude::Array::from(vec![crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(pat_pc.clone()), st_ty_pb.clone())]), ::std::rc::Rc::new(crate::prelude::run_to_end(cont_f8((outer2_ph.clone(), env2_pi.clone()))))));
    let to_k_fl = {
        let k_name_pjx = k_name_pj.clone();
        let pack_pdx = pack_pd.clone();
        ::std::rc::Rc::new(move |o2_p1g: &crate::lower::types::Env, e2_p1h: &crate::lower::model::Ex| crate::lower::model::Ex::XApply(::std::rc::Rc::new(crate::lower::model::Ex::XVar(k_name_pjx.clone())), crate::prelude::Array::from(vec![pack_pdx.clone()]))) as ::std::rc::Rc<dyn ::std::ops::Fn(&crate::lower::types::Env, &crate::lower::model::Ex) -> crate::lower::model::Ex>
    };
    let branch_fm = {
        let lx_p0x = lx_p0.clone();
        let env_p2x = env_p2.clone();
        let to_k_flx = to_k_fl.clone();
        ::std::rc::Rc::new(move |p0: crate::syntax::Block| {
            let lx_p0xy = lx_p0x.clone();
            let env_p2xy = env_p2x.clone();
            let to_k_flxy = to_k_flx.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let b_p1i = p0;
                ::prism_rtl::Turn::More(::std::rc::Rc::new(UpdTailFrom { lx_p0: lx_p0xy.clone(), outer_p1: env_p2xy.clone(), env_p2: env_p2xy.clone(), b_p3: b_p1i.clone(), i_p4: crate::prelude::Nat::from(0u32), to_p5: b_p1i.span_p.clone(), cont_f6: {
                    let f = to_k_flxy.clone();
                    ::std::rc::Rc::new(move |(a0, a1): (crate::lower::types::Env, crate::lower::model::Ex)| {
                        let fy = f.clone();
                        crate::prelude::once_job(move || ::prism_rtl::Turn::Finished(fy(&a0, &a1)))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::types::Env, crate::lower::model::Ex)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>>>
                } }))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::syntax::Block) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>>>
    };
    let else_x_pn = match else_b_o5 {
        ::std::option::Option::Some(eb_p1j) => crate::prelude::run_to_end((&branch_fm)(eb_p1j.clone())),
        ::std::option::Option::None => crate::lower::model::Ex::XApply(::std::rc::Rc::new(crate::lower::model::Ex::XVar(k_name_pj.clone())), crate::prelude::Array::from(vec![pack_pd.clone()])),
    };
    let choose_po = match c_p3 {
        crate::syntax::Cond::CondExpr(x_p1k) => crate::lower::model::Ex::XIf(::std::rc::Rc::new(crate::lower::types::as_bool_f(&crate::lower::expr::value_of_f(lx_p0, env_p2, &**x_p1k))), ::std::rc::Rc::new(crate::prelude::run_to_end((&branch_fm)(then_b_p4.clone()))), ::std::rc::Rc::new(else_x_pn.clone())),
        crate::syntax::Cond::CondBind(p_p1l, x_p1m, _) => {
            let po_p1n = crate::lower::patterns::rust_pat_f(lx_p0, p_p1l, &crate::lower::type_at_f(lx_p0, &x_p1m.span_p), &crate::lower::types::Holding::Owned, &crate::prelude::Text::from(format!("u{}", &x_p1m.span_p.start_p)));
            let then_x_p1o = upd_tail_from_f(lx_p0, &crate::lower::expr::bind_all_f(env_p2, &po_p1n.binds_p), &crate::lower::expr::bind_all_f(env_p2, &po_p1n.binds_p), then_b_p4, &crate::prelude::Nat::from(0u32), &then_b_p4.span_p, &{
                let f = to_k_fl.clone();
                ::std::rc::Rc::new(move |(a0, a1): (crate::lower::types::Env, crate::lower::model::Ex)| {
                    let fy = f.clone();
                    crate::prelude::once_job(move || ::prism_rtl::Turn::Finished(fy(&a0, &a1)))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::types::Env, crate::lower::model::Ex)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>>>
            });
            crate::lower::types::own_f(&crate::lower::expr::arms_value_f(&crate::lower::types::own_f(&crate::lower::expr::value_of_f(lx_p0, env_p2, &**x_p1m)), &crate::prelude::Array::from(vec![crate::lower::model::XArm { pat_p: po_p1n.pa_p.clone(), conds_p: po_p1n.conds_p.clone(), body_p: then_x_p1o.clone() }, crate::lower::model::XArm { pat_p: crate::lower::model::Pa::PaWild, conds_p: crate::prelude::Array::new(), body_p: else_x_pn.clone() }]), &crate::prelude::Text::from(format!("\'u{}", &x_p1m.span_p.start_p)), &crate::lower::model::OutTy::OutTurn))
        },
    };
    prepend_f(&crate::prelude::push(&out_dos_pg, &k_do_pk), &choose_po)
}

/// The step machine of `IfJob`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// IfJob: unbounded fn Lx, Env, Env, Cond, Block, ?Block, Range, [Text], (unbounded fn Env, Env -> Ex) -> Ex
/// ```
pub struct IfJob {
    pub lx_p0: crate::lower::Lx,
    pub outer_p1: crate::lower::types::Env,
    pub env_p2: crate::lower::types::Env,
    pub c_p3: crate::syntax::Cond,
    pub then_b_p4: crate::syntax::Block,
    pub else_b_o5: ::std::option::Option<crate::syntax::Block>,
    pub span_p6: crate::syntax::Range,
    pub rest_reads_p7: crate::prelude::Array<crate::prelude::Text>,
    pub cont_f8: ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::types::Env, crate::lower::types::Env)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>>>,
}

impl ::prism_rtl::Job<crate::lower::model::Ex> for IfJob {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::lower::model::Ex> {
        let lx_p0 = &self.lx_p0;
        let outer_p1 = &self.outer_p1;
        let env_p2 = &self.env_p2;
        let c_p3 = &self.c_p3;
        let then_b_p4 = &self.then_b_p4;
        let else_b_o5 = &self.else_b_o5;
        let span_p6 = &self.span_p6;
        let rest_reads_p7 = &self.rest_reads_p7;
        let cont_f8 = &self.cont_f8;
        let state_p9 = crate::prelude::fold(&crate::prelude::keys(&env_p2.names_p), &crate::prelude::Array::new(), &(|acc_pp: &crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy)>, k_pq: &crate::prelude::Text| if !crate::syntax::lexer::chars::has_prefix_f(k_pq, &crate::prelude::Text::lit("&")) {
            acc_pp.clone()
        } else {
            match crate::prelude::get(&env_p2.names_p, k_pq) {
                ::std::option::Option::Some(crate::lower::types::Bn::BnLocal(rs_pr, _, bt_ps)) => crate::prelude::push(acc_pp, &(k_pq.clone(), crate::lower::types::place_stem_f(&rs_pr), bt_ps)),
                _ => acc_pp.clone(),
            }
        }));
        let names_pa = crate::prelude::each(&state_p9, &(|(_, rs_pt, _): &(crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy)| rs_pt.clone()));
        let st_ty_pb = crate::lower::model::OutTy::OutTuple(crate::prelude::each(&state_p9, &(|(_, _, bt_pu): &(crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy)| bt_pu.clone())));
        let pat_pc = crate::lower::model::Pa::PaTuple(crate::prelude::each(&names_pa, &(|n_pv: &crate::prelude::Text| crate::lower::model::Pa::PaMut(crate::prelude::Text::from(format!("{}", n_pv))))));
        let pack_pd = crate::lower::model::Ex::XTuple(crate::prelude::each(&names_pa, &(|n_p10: &crate::prelude::Text| crate::lower::model::Ex::XVar(n_p10.clone()))));
        let env_s_pe = crate::prelude::fold(&state_p9, env_p2, &(|en_p11: &crate::lower::types::Env, (k_p12, rs_p13, bt_p14): &(crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy)| crate::lower::types::bind_f(en_p11, k_p12, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(rs_p13.clone()), crate::lower::types::Holding::Owned, bt_p14.clone()))));
        let out_caps_pf = caps_in_f(outer_p1, rest_reads_p7, &names_pa);
        let out_dos_pg = crate::prelude::each(&out_caps_pf, &(|(_, rs_p15, mode_p16, bt_p17): &(crate::prelude::Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)| crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::lower::expr::outer_name_f(rs_p15)), crate::lower::types::own_f(&crate::lower::types::Vl::VlPlace(rs_p15.clone(), mode_p16.clone(), bt_p17.clone())))));
        let outer2_ph = crate::prelude::fold(&out_caps_pf, outer_p1, &(|en_p18: &crate::lower::types::Env, (k_p19, rs_p1a, _, bt_p1b): &(crate::prelude::Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)| crate::lower::types::bind_f(en_p18, k_p19, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(crate::lower::expr::outer_name_f(rs_p1a)), crate::lower::types::Holding::Owned, bt_p1b.clone()))));
        let env2_pi = crate::prelude::fold(&out_caps_pf, &env_s_pe, &(|en_p1c: &crate::lower::types::Env, (k_p1d, rs_p1e, _, bt_p1f): &(crate::prelude::Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)| crate::lower::types::bind_f(en_p1c, k_p1d, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(crate::lower::expr::outer_name_f(rs_p1e)), crate::lower::types::Holding::Owned, bt_p1f.clone()))));
        let k_name_pj = crate::prelude::Text::from(format!("k_if{}", &span_p6.start_p));
        let else_b_o5x = else_b_o5.clone();
        let cont_f8x = cont_f8.clone();
        let c_p3x = c_p3.clone();
        let env_p2x = env_p2.clone();
        let lx_p0x = lx_p0.clone();
        let then_b_p4x = then_b_p4.clone();
        crate::prelude::call_value((&cont_f8x)((outer2_ph.clone(), env2_pi.clone())), move |cont_24177: crate::lower::model::Ex| {
            let k_do_pk = crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(k_name_pj.clone()), crate::lower::model::Ex::XClosure(true, crate::prelude::Array::from(vec![crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(pat_pc.clone()), st_ty_pb.clone())]), ::std::rc::Rc::new(cont_24177)));
            let to_k_fl = {
                let k_name_pjx = k_name_pj.clone();
                let pack_pdx = pack_pd.clone();
                ::std::rc::Rc::new(move |o2_p1g: &crate::lower::types::Env, e2_p1h: &crate::lower::model::Ex| crate::lower::model::Ex::XApply(::std::rc::Rc::new(crate::lower::model::Ex::XVar(k_name_pjx.clone())), crate::prelude::Array::from(vec![pack_pdx.clone()]))) as ::std::rc::Rc<dyn ::std::ops::Fn(&crate::lower::types::Env, &crate::lower::model::Ex) -> crate::lower::model::Ex>
            };
            let branch_fm = {
                let lx_p0xx = lx_p0x.clone();
                let env_p2xx = env_p2x.clone();
                let to_k_flx = to_k_fl.clone();
                ::std::rc::Rc::new(move |p0: crate::syntax::Block| {
                    let lx_p0xxy = lx_p0xx.clone();
                    let env_p2xxy = env_p2xx.clone();
                    let to_k_flxy = to_k_flx.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let b_p1i = p0;
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(UpdTailFrom { lx_p0: lx_p0xxy.clone(), outer_p1: env_p2xxy.clone(), env_p2: env_p2xxy.clone(), b_p3: b_p1i.clone(), i_p4: crate::prelude::Nat::from(0u32), to_p5: b_p1i.span_p.clone(), cont_f6: {
                            let f = to_k_flxy.clone();
                            ::std::rc::Rc::new(move |(a0, a1): (crate::lower::types::Env, crate::lower::model::Ex)| {
                                let fy = f.clone();
                                crate::prelude::once_job(move || ::prism_rtl::Turn::Finished(fy(&a0, &a1)))
                            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::types::Env, crate::lower::model::Ex)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>>>
                        } }))
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::syntax::Block) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>>>
            };
            let branch_fmz = branch_fm.clone();
            let to_k_flz = to_k_fl.clone();
            let c_p3xz = c_p3x.clone();
            let env_p2xz = env_p2x.clone();
            let k_do_pkz = k_do_pk.clone();
            let lx_p0xz = lx_p0x.clone();
            let out_dos_pgz = out_dos_pg.clone();
            let then_b_p4xz = then_b_p4x.clone();
            let k_let24321 = move |v24321: crate::lower::model::Ex| {
                let else_x_pn = v24321;
                let k_do_pkzz = k_do_pkz.clone();
                let out_dos_pgzz = out_dos_pgz.clone();
                let k_let24418 = move |v24418: crate::lower::model::Ex| {
                    let choose_po = v24418;
                    ::prism_rtl::Turn::Finished(prepend_f(&crate::prelude::push(&out_dos_pgzz, &k_do_pkzz), &choose_po))
                };
                match c_p3xz.clone() {
                    crate::syntax::Cond::CondExpr(x_p1k) => crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p0xz.clone(), env_p2xz.clone(), (*x_p1k).clone()), move |value_of_f_24473: crate::lower::types::Vl| crate::prelude::call_value((&branch_fmz)(then_b_p4xz.clone()), move |branch_24496: crate::lower::model::Ex| k_let24418(crate::lower::model::Ex::XIf(::std::rc::Rc::new(crate::lower::types::as_bool_f(&value_of_f_24473)), ::std::rc::Rc::new(branch_24496), ::std::rc::Rc::new(else_x_pn.clone()))))),
                    crate::syntax::Cond::CondBind(p_p1l, x_p1m, _) => crate::prelude::call_then(crate::lower::patterns::start_rust_pat_f(lx_p0xz.clone(), p_p1l.clone(), crate::lower::type_at_f(&lx_p0xz, &x_p1m.span_p), crate::lower::types::Holding::Owned, crate::prelude::Text::from(format!("u{}", &x_p1m.span_p.start_p))), move |rust_pat_f_24569: crate::lower::patterns::PatOut| {
                        let po_p1n = rust_pat_f_24569;
                        crate::prelude::call_then(start_upd_tail_from_f(lx_p0xz.clone(), crate::lower::expr::bind_all_f(&env_p2xz, &po_p1n.binds_p), crate::lower::expr::bind_all_f(&env_p2xz, &po_p1n.binds_p), then_b_p4xz.clone(), crate::prelude::Nat::from(0u32), then_b_p4xz.span_p.clone(), {
                            let f = to_k_flz.clone();
                            ::std::rc::Rc::new(move |(a0, a1): (crate::lower::types::Env, crate::lower::model::Ex)| {
                                let fy = f.clone();
                                crate::prelude::once_job(move || ::prism_rtl::Turn::Finished(fy(&a0, &a1)))
                            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::types::Env, crate::lower::model::Ex)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>>>
                        }), move |upd_tail_from_f_24654: crate::lower::model::Ex| {
                            let then_x_p1o = upd_tail_from_f_24654;
                            crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p0xz.clone(), env_p2xz.clone(), (*x_p1m).clone()), move |value_of_f_24779: crate::lower::types::Vl| k_let24418(crate::lower::types::own_f(&crate::lower::expr::arms_value_f(&crate::lower::types::own_f(&value_of_f_24779), &crate::prelude::Array::from(vec![crate::lower::model::XArm { pat_p: po_p1n.pa_p.clone(), conds_p: po_p1n.conds_p.clone(), body_p: then_x_p1o.clone() }, crate::lower::model::XArm { pat_p: crate::lower::model::Pa::PaWild, conds_p: crate::prelude::Array::new(), body_p: else_x_pn.clone() }]), &crate::prelude::Text::from(format!("\'u{}", &x_p1m.span_p.start_p)), &crate::lower::model::OutTy::OutTurn))))
                        })
                    }),
                }
            };
            match else_b_o5x.clone() {
                ::std::option::Option::Some(eb_p1j) => crate::prelude::call_value((&branch_fm)(eb_p1j.clone()), move |branch_24361: crate::lower::model::Ex| k_let24321(branch_24361)),
                ::std::option::Option::None => k_let24321(crate::lower::model::Ex::XApply(::std::rc::Rc::new(crate::lower::model::Ex::XVar(k_name_pj.clone())), crate::prelude::Array::from(vec![pack_pd.clone()]))),
            }
        })
    }
}

/// `Start IfJob, x`: what the function value is when passed to `@Run`.
pub fn start_if_job_f(lx_p0: crate::lower::Lx, outer_p1: crate::lower::types::Env, env_p2: crate::lower::types::Env, c_p3: crate::syntax::Cond, then_b_p4: crate::syntax::Block, else_b_o5: ::std::option::Option<crate::syntax::Block>, span_p6: crate::syntax::Range, rest_reads_p7: crate::prelude::Array<crate::prelude::Text>, cont_f8: ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::types::Env, crate::lower::types::Env)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>>>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>> {
    ::std::rc::Rc::new(IfJob { lx_p0, outer_p1, env_p2, c_p3, then_b_p4, else_b_o5, span_p6, rest_reads_p7, cont_f8 })
}

/// ```prism
/// MatchJob: unbounded fn Lx, Env, Env, Expr, [Arm], Range, [Text], (unbounded fn Env, Env -> Ex) -> Ex
/// ```
pub fn match_job_f(lx_p0: &crate::lower::Lx, outer_p1: &crate::lower::types::Env, env_p2: &crate::lower::types::Env, scrut_p3: &crate::syntax::Expr, arms_p4: &crate::prelude::Array<crate::syntax::Arm>, span_p5: &crate::syntax::Range, rest_reads_p6: &crate::prelude::Array<crate::prelude::Text>, cont_f7: &::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::types::Env, crate::lower::types::Env)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>>>) -> crate::lower::model::Ex {
    let state_p8 = crate::prelude::fold(&crate::prelude::keys(&env_p2.names_p), &crate::prelude::Array::new(), &(|acc_pn: &crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy)>, k_po: &crate::prelude::Text| if !crate::syntax::lexer::chars::has_prefix_f(k_po, &crate::prelude::Text::lit("&")) {
        acc_pn.clone()
    } else {
        match crate::prelude::get(&env_p2.names_p, k_po) {
            ::std::option::Option::Some(crate::lower::types::Bn::BnLocal(rs_pp, _, bt_pq)) => crate::prelude::push(acc_pn, &(k_po.clone(), crate::lower::types::place_stem_f(&rs_pp), bt_pq)),
            _ => acc_pn.clone(),
        }
    }));
    let names_p9 = crate::prelude::each(&state_p8, &(|(_, rs_pr, _): &(crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy)| rs_pr.clone()));
    let st_ty_pa = crate::lower::model::OutTy::OutTuple(crate::prelude::each(&state_p8, &(|(_, _, bt_ps): &(crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy)| bt_ps.clone())));
    let pat_pb = crate::lower::model::Pa::PaTuple(crate::prelude::each(&names_p9, &(|n_pt: &crate::prelude::Text| crate::lower::model::Pa::PaMut(crate::prelude::Text::from(format!("{}", n_pt))))));
    let pack_pc = crate::lower::model::Ex::XTuple(crate::prelude::each(&names_p9, &(|n_pu: &crate::prelude::Text| crate::lower::model::Ex::XVar(n_pu.clone()))));
    let env_s_pd = crate::prelude::fold(&state_p8, env_p2, &(|en_pv: &crate::lower::types::Env, (k_p10, rs_p11, bt_p12): &(crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy)| crate::lower::types::bind_f(en_pv, k_p10, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(rs_p11.clone()), crate::lower::types::Holding::Owned, bt_p12.clone()))));
    let out_caps_pe = caps_in_f(outer_p1, rest_reads_p6, &names_p9);
    let out_dos_pf = crate::prelude::each(&out_caps_pe, &(|(_, rs_p13, mode_p14, bt_p15): &(crate::prelude::Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)| crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::lower::expr::outer_name_f(rs_p13)), crate::lower::types::own_f(&crate::lower::types::Vl::VlPlace(rs_p13.clone(), mode_p14.clone(), bt_p15.clone())))));
    let outer2_pg = crate::prelude::fold(&out_caps_pe, outer_p1, &(|en_p16: &crate::lower::types::Env, (k_p17, rs_p18, _, bt_p19): &(crate::prelude::Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)| crate::lower::types::bind_f(en_p16, k_p17, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(crate::lower::expr::outer_name_f(rs_p18)), crate::lower::types::Holding::Owned, bt_p19.clone()))));
    let env2_ph = crate::prelude::fold(&out_caps_pe, &env_s_pd, &(|en_p1a: &crate::lower::types::Env, (k_p1b, rs_p1c, _, bt_p1d): &(crate::prelude::Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)| crate::lower::types::bind_f(en_p1a, k_p1b, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(crate::lower::expr::outer_name_f(rs_p1c)), crate::lower::types::Holding::Owned, bt_p1d.clone()))));
    let k_name_pi = crate::prelude::Text::from(format!("k_match{}", &span_p5.start_p));
    let k_do_pj = crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(k_name_pi.clone()), crate::lower::model::Ex::XClosure(true, crate::prelude::Array::from(vec![crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(pat_pb.clone()), st_ty_pa.clone())]), ::std::rc::Rc::new(crate::prelude::run_to_end(cont_f7((outer2_pg.clone(), env2_ph.clone()))))));
    let to_k_fk = {
        let k_name_pix = k_name_pi.clone();
        let pack_pcx = pack_pc.clone();
        ::std::rc::Rc::new(move |o2_p1e: &crate::lower::types::Env, e2_p1f: &crate::lower::model::Ex| crate::lower::model::Ex::XApply(::std::rc::Rc::new(crate::lower::model::Ex::XVar(k_name_pix.clone())), crate::prelude::Array::from(vec![pack_pcx.clone()]))) as ::std::rc::Rc<dyn ::std::ops::Fn(&crate::lower::types::Env, &crate::lower::model::Ex) -> crate::lower::model::Ex>
    };
    let sty_pl = crate::lower::type_at_f(lx_p0, &scrut_p3.span_p);
    let xarms_pm = crate::prelude::run_to_end(crate::prelude::each_job(crate::check::errors::range0_f(&crate::prelude::len(arms_p4)), {
        let arms_p4x = arms_p4.clone();
        let lx_p0x = lx_p0.clone();
        let sty_plx = sty_pl.clone();
        let scrut_p3x = scrut_p3.clone();
        let env_p2x = env_p2.clone();
        let to_k_fkx = to_k_fk.clone();
        ::std::rc::Rc::new(move |p0: crate::prelude::Nat| {
            let arms_p4xy = arms_p4x.clone();
            let lx_p0xy = lx_p0x.clone();
            let sty_plxy = sty_plx.clone();
            let scrut_p3xy = scrut_p3x.clone();
            let env_p2xy = env_p2x.clone();
            let to_k_fkxy = to_k_fkx.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let i_p1g = p0;
                {
                    let arm_p1h = crate::prelude::or(&crate::prelude::index(&arms_p4xy, &i_p1g), &crate::lower::expr::dummy_arm_p());
                    crate::prelude::call_then(crate::lower::expr::start_arm_pat_f(lx_p0xy.clone(), arm_p1h.pattern_o.clone(), sty_plxy.clone(), crate::lower::types::Holding::Owned, crate::prelude::Text::from(format!("u{}_{}", &scrut_p3xy.span_p.start_p, &i_p1g))), move |arm_pat_f_26752: crate::lower::patterns::PatOut| {
                        let po_p1i = arm_pat_f_26752;
                        let env_a_p1j = crate::lower::expr::bind_all_f(&env_p2xy, &po_p1i.binds_p);
                        crate::prelude::call_then(crate::lower::templates::start_guard_conds_f(lx_p0xy.clone(), env_a_p1j.clone(), arm_p1h.guard_o.clone()), move |guard_conds_f_26896: crate::prelude::Array<crate::lower::model::Cc>| {
                            let guarded_p1k = crate::prelude::append(&po_p1i.conds_p, &guard_conds_f_26896);
                            crate::prelude::call_then(start_upd_tail_from_f(lx_p0xy.clone(), env_a_p1j.clone(), env_a_p1j.clone(), arm_p1h.body_p.clone(), crate::prelude::Nat::from(0u32), arm_p1h.body_p.span_p.clone(), {
                                let f = to_k_fkxy.clone();
                                ::std::rc::Rc::new(move |(a0, a1): (crate::lower::types::Env, crate::lower::model::Ex)| {
                                    let fy = f.clone();
                                    crate::prelude::once_job(move || ::prism_rtl::Turn::Finished(fy(&a0, &a1)))
                                }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::types::Env, crate::lower::model::Ex)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>>>
                            }), move |upd_tail_from_f_26974: crate::lower::model::Ex| ::prism_rtl::Turn::Finished(crate::lower::model::XArm { pat_p: po_p1i.pa_p.clone(), conds_p: guarded_p1k.clone(), body_p: upd_tail_from_f_26974 }))
                        })
                    })
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::XArm>>>
    }));
    prepend_f(&crate::prelude::push(&out_dos_pf, &k_do_pj), &crate::lower::types::own_f(&crate::lower::expr::arms_value_f(&crate::lower::types::own_f(&crate::lower::expr::value_of_f(lx_p0, env_p2, scrut_p3)), &xarms_pm, &crate::prelude::Text::from(format!("\'u{}", &scrut_p3.span_p.start_p)), &crate::lower::model::OutTy::OutTurn)))
}

/// The step machine of `MatchJob`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// MatchJob: unbounded fn Lx, Env, Env, Expr, [Arm], Range, [Text], (unbounded fn Env, Env -> Ex) -> Ex
/// ```
pub struct MatchJob {
    pub lx_p0: crate::lower::Lx,
    pub outer_p1: crate::lower::types::Env,
    pub env_p2: crate::lower::types::Env,
    pub scrut_p3: crate::syntax::Expr,
    pub arms_p4: crate::prelude::Array<crate::syntax::Arm>,
    pub span_p5: crate::syntax::Range,
    pub rest_reads_p6: crate::prelude::Array<crate::prelude::Text>,
    pub cont_f7: ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::types::Env, crate::lower::types::Env)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>>>,
}

impl ::prism_rtl::Job<crate::lower::model::Ex> for MatchJob {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::lower::model::Ex> {
        let lx_p0 = &self.lx_p0;
        let outer_p1 = &self.outer_p1;
        let env_p2 = &self.env_p2;
        let scrut_p3 = &self.scrut_p3;
        let arms_p4 = &self.arms_p4;
        let span_p5 = &self.span_p5;
        let rest_reads_p6 = &self.rest_reads_p6;
        let cont_f7 = &self.cont_f7;
        let state_p8 = crate::prelude::fold(&crate::prelude::keys(&env_p2.names_p), &crate::prelude::Array::new(), &(|acc_pn: &crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy)>, k_po: &crate::prelude::Text| if !crate::syntax::lexer::chars::has_prefix_f(k_po, &crate::prelude::Text::lit("&")) {
            acc_pn.clone()
        } else {
            match crate::prelude::get(&env_p2.names_p, k_po) {
                ::std::option::Option::Some(crate::lower::types::Bn::BnLocal(rs_pp, _, bt_pq)) => crate::prelude::push(acc_pn, &(k_po.clone(), crate::lower::types::place_stem_f(&rs_pp), bt_pq)),
                _ => acc_pn.clone(),
            }
        }));
        let names_p9 = crate::prelude::each(&state_p8, &(|(_, rs_pr, _): &(crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy)| rs_pr.clone()));
        let st_ty_pa = crate::lower::model::OutTy::OutTuple(crate::prelude::each(&state_p8, &(|(_, _, bt_ps): &(crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy)| bt_ps.clone())));
        let pat_pb = crate::lower::model::Pa::PaTuple(crate::prelude::each(&names_p9, &(|n_pt: &crate::prelude::Text| crate::lower::model::Pa::PaMut(crate::prelude::Text::from(format!("{}", n_pt))))));
        let pack_pc = crate::lower::model::Ex::XTuple(crate::prelude::each(&names_p9, &(|n_pu: &crate::prelude::Text| crate::lower::model::Ex::XVar(n_pu.clone()))));
        let env_s_pd = crate::prelude::fold(&state_p8, env_p2, &(|en_pv: &crate::lower::types::Env, (k_p10, rs_p11, bt_p12): &(crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy)| crate::lower::types::bind_f(en_pv, k_p10, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(rs_p11.clone()), crate::lower::types::Holding::Owned, bt_p12.clone()))));
        let out_caps_pe = caps_in_f(outer_p1, rest_reads_p6, &names_p9);
        let out_dos_pf = crate::prelude::each(&out_caps_pe, &(|(_, rs_p13, mode_p14, bt_p15): &(crate::prelude::Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)| crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::lower::expr::outer_name_f(rs_p13)), crate::lower::types::own_f(&crate::lower::types::Vl::VlPlace(rs_p13.clone(), mode_p14.clone(), bt_p15.clone())))));
        let outer2_pg = crate::prelude::fold(&out_caps_pe, outer_p1, &(|en_p16: &crate::lower::types::Env, (k_p17, rs_p18, _, bt_p19): &(crate::prelude::Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)| crate::lower::types::bind_f(en_p16, k_p17, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(crate::lower::expr::outer_name_f(rs_p18)), crate::lower::types::Holding::Owned, bt_p19.clone()))));
        let env2_ph = crate::prelude::fold(&out_caps_pe, &env_s_pd, &(|en_p1a: &crate::lower::types::Env, (k_p1b, rs_p1c, _, bt_p1d): &(crate::prelude::Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)| crate::lower::types::bind_f(en_p1a, k_p1b, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(crate::lower::expr::outer_name_f(rs_p1c)), crate::lower::types::Holding::Owned, bt_p1d.clone()))));
        let k_name_pi = crate::prelude::Text::from(format!("k_match{}", &span_p5.start_p));
        let cont_f7x = cont_f7.clone();
        let arms_p4x = arms_p4.clone();
        let env_p2x = env_p2.clone();
        let lx_p0x = lx_p0.clone();
        let scrut_p3x = scrut_p3.clone();
        crate::prelude::call_value((&cont_f7x)((outer2_pg.clone(), env2_ph.clone())), move |cont_26539: crate::lower::model::Ex| {
            let k_do_pj = crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(k_name_pi.clone()), crate::lower::model::Ex::XClosure(true, crate::prelude::Array::from(vec![crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(pat_pb.clone()), st_ty_pa.clone())]), ::std::rc::Rc::new(cont_26539)));
            let to_k_fk = {
                let k_name_pix = k_name_pi.clone();
                let pack_pcx = pack_pc.clone();
                ::std::rc::Rc::new(move |o2_p1e: &crate::lower::types::Env, e2_p1f: &crate::lower::model::Ex| crate::lower::model::Ex::XApply(::std::rc::Rc::new(crate::lower::model::Ex::XVar(k_name_pix.clone())), crate::prelude::Array::from(vec![pack_pcx.clone()]))) as ::std::rc::Rc<dyn ::std::ops::Fn(&crate::lower::types::Env, &crate::lower::model::Ex) -> crate::lower::model::Ex>
            };
            let sty_pl = crate::lower::type_at_f(&lx_p0x, &scrut_p3x.span_p);
            crate::prelude::call_value(crate::prelude::each_job(crate::check::errors::range0_f(&crate::prelude::len(&arms_p4x)), {
                let arms_p4xx = arms_p4x.clone();
                let lx_p0xx = lx_p0x.clone();
                let sty_plx = sty_pl.clone();
                let scrut_p3xx = scrut_p3x.clone();
                let env_p2xx = env_p2x.clone();
                let to_k_fkx = to_k_fk.clone();
                ::std::rc::Rc::new(move |p0: crate::prelude::Nat| {
                    let arms_p4xxy = arms_p4xx.clone();
                    let lx_p0xxy = lx_p0xx.clone();
                    let sty_plxy = sty_plx.clone();
                    let scrut_p3xxy = scrut_p3xx.clone();
                    let env_p2xxy = env_p2xx.clone();
                    let to_k_fkxy = to_k_fkx.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let i_p1g = p0;
                        {
                            let arm_p1h = crate::prelude::or(&crate::prelude::index(&arms_p4xxy, &i_p1g), &crate::lower::expr::dummy_arm_p());
                            crate::prelude::call_then(crate::lower::expr::start_arm_pat_f(lx_p0xxy.clone(), arm_p1h.pattern_o.clone(), sty_plxy.clone(), crate::lower::types::Holding::Owned, crate::prelude::Text::from(format!("u{}_{}", &scrut_p3xxy.span_p.start_p, &i_p1g))), move |arm_pat_f_26752: crate::lower::patterns::PatOut| {
                                let po_p1i = arm_pat_f_26752;
                                let env_a_p1j = crate::lower::expr::bind_all_f(&env_p2xxy, &po_p1i.binds_p);
                                crate::prelude::call_then(crate::lower::templates::start_guard_conds_f(lx_p0xxy.clone(), env_a_p1j.clone(), arm_p1h.guard_o.clone()), move |guard_conds_f_26896: crate::prelude::Array<crate::lower::model::Cc>| {
                                    let guarded_p1k = crate::prelude::append(&po_p1i.conds_p, &guard_conds_f_26896);
                                    crate::prelude::call_then(start_upd_tail_from_f(lx_p0xxy.clone(), env_a_p1j.clone(), env_a_p1j.clone(), arm_p1h.body_p.clone(), crate::prelude::Nat::from(0u32), arm_p1h.body_p.span_p.clone(), {
                                        let f = to_k_fkxy.clone();
                                        ::std::rc::Rc::new(move |(a0, a1): (crate::lower::types::Env, crate::lower::model::Ex)| {
                                            let fy = f.clone();
                                            crate::prelude::once_job(move || ::prism_rtl::Turn::Finished(fy(&a0, &a1)))
                                        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::types::Env, crate::lower::model::Ex)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>>>
                                    }), move |upd_tail_from_f_26974: crate::lower::model::Ex| ::prism_rtl::Turn::Finished(crate::lower::model::XArm { pat_p: po_p1i.pa_p.clone(), conds_p: guarded_p1k.clone(), body_p: upd_tail_from_f_26974 }))
                                })
                            })
                        }
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::XArm>>>
            }), move |each_26665: crate::prelude::Array<crate::lower::model::XArm>| {
                let xarms_pm = each_26665;
                crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p0x.clone(), env_p2x.clone(), scrut_p3x.clone()), move |value_of_f_27090: crate::lower::types::Vl| ::prism_rtl::Turn::Finished(prepend_f(&crate::prelude::push(&out_dos_pf, &k_do_pj), &crate::lower::types::own_f(&crate::lower::expr::arms_value_f(&crate::lower::types::own_f(&value_of_f_27090), &xarms_pm, &crate::prelude::Text::from(format!("\'u{}", &scrut_p3x.span_p.start_p)), &crate::lower::model::OutTy::OutTurn)))))
            })
        })
    }
}

/// `Start MatchJob, x`: what the function value is when passed to `@Run`.
pub fn start_match_job_f(lx_p0: crate::lower::Lx, outer_p1: crate::lower::types::Env, env_p2: crate::lower::types::Env, scrut_p3: crate::syntax::Expr, arms_p4: crate::prelude::Array<crate::syntax::Arm>, span_p5: crate::syntax::Range, rest_reads_p6: crate::prelude::Array<crate::prelude::Text>, cont_f7: ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::types::Env, crate::lower::types::Env)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>>>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>> {
    ::std::rc::Rc::new(MatchJob { lx_p0, outer_p1, env_p2, scrut_p3, arms_p4, span_p5, rest_reads_p6, cont_f7 })
}

/// ```prism
/// ForJob: unbounded fn Lx, Env, Env, ?ForBinders, Expr, Block, Range, [Text], (unbounded fn Env, Env -> Ex) -> Ex
/// ```
pub fn for_job_f(lx_p0: &crate::lower::Lx, outer_p1: &crate::lower::types::Env, env_p2: &crate::lower::types::Env, binders_o3: &::std::option::Option<crate::syntax::ForBinders>, source_p4: &crate::syntax::Expr, body_p5: &crate::syntax::Block, span_p6: &crate::syntax::Range, rest_reads_p7: &crate::prelude::Array<crate::prelude::Text>, cont_f8: &::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::types::Env, crate::lower::types::Env)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>>>) -> crate::lower::model::Ex {
    let state_p9 = crate::prelude::fold(&crate::prelude::keys(&env_p2.names_p), &crate::prelude::Array::new(), &(|acc_p18: &crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy)>, k_p19: &crate::prelude::Text| if !crate::syntax::lexer::chars::has_prefix_f(k_p19, &crate::prelude::Text::lit("&")) {
        acc_p18.clone()
    } else {
        match crate::prelude::get(&env_p2.names_p, k_p19) {
            ::std::option::Option::Some(crate::lower::types::Bn::BnLocal(rs_p1a, _, bt_p1b)) => crate::prelude::push(acc_p18, &(k_p19.clone(), crate::lower::types::place_stem_f(&rs_p1a), bt_p1b)),
            _ => acc_p18.clone(),
        }
    }));
    let names_pa = crate::prelude::each(&state_p9, &(|(_, rs_p1c, _): &(crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy)| rs_p1c.clone()));
    let st_ty_pb = crate::lower::model::OutTy::OutTuple(crate::prelude::each(&state_p9, &(|(_, _, bt_p1d): &(crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy)| bt_p1d.clone())));
    let pat_pc = crate::lower::model::Pa::PaTuple(crate::prelude::each(&names_pa, &(|n_p1e: &crate::prelude::Text| crate::lower::model::Pa::PaMut(crate::prelude::Text::from(format!("{}", n_p1e))))));
    let pack_pd = crate::lower::model::Ex::XTuple(crate::prelude::each(&names_pa, &(|n_p1f: &crate::prelude::Text| crate::lower::model::Ex::XVar(n_p1f.clone()))));
    let env_s_pe = crate::prelude::fold(&state_p9, env_p2, &(|en_p1g: &crate::lower::types::Env, (k_p1h, rs_p1i, bt_p1j): &(crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy)| crate::lower::types::bind_f(en_p1g, k_p1h, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(rs_p1i.clone()), crate::lower::types::Holding::Owned, bt_p1j.clone()))));
    let src_pf = crate::lower::types::own_f(&crate::lower::types::plain_value_f(&crate::lower::expr::value_of_f(lx_p0, env_p2, source_p4)));
    let sty_pg = crate::lower::types::collection_f(&crate::lower::types::peel_f(&crate::lower::type_at_f(lx_p0, &source_p4.span_p)));
    let (kt_p1n, vt_p1o, is_array_p1p) = match &sty_pg {
        crate::check::types::Ty::TyArray(v_p1k) => (crate::lower::model::OutTy::OutNat, crate::lower::types::out_ty_of_f(lx_p0, &**v_p1k), true),
        crate::check::types::Ty::TyMap(k_p1l, v_p1m) => (crate::lower::types::out_ty_of_f(lx_p0, &**k_p1l), crate::lower::types::out_ty_of_f(lx_p0, &**v_p1m), false),
        _ => (crate::lower::model::OutTy::OutUnit, crate::lower::model::OutTy::OutUnit, true),
    };
    let (vty_p1t, kty_p1u) = match &sty_pg {
        crate::check::types::Ty::TyArray(v_p1q) => ((**v_p1q).clone(), crate::check::types::Ty::TyCon(crate::prelude::Text::lit("Nat"), crate::prelude::Array::new())),
        crate::check::types::Ty::TyMap(k_p1r, v_p1s) => ((**v_p1s).clone(), (**k_p1r).clone()),
        _ => (crate::check::types::Ty::TyErr, crate::check::types::Ty::TyErr),
    };
    let key_name_ph = crate::prelude::Text::from(format!("k{}", &span_p6.start_p));
    let val_name_pi = crate::prelude::Text::from(format!("v{}", &span_p6.start_p));
    let loop_reads_pj = reads_in_f(lx_p0, span_p6);
    let caps_pk = caps_in_f(&env_s_pe, &loop_reads_pj, &names_pa);
    let cap_dos_pl = crate::prelude::each(&caps_pk, &(|(_, rs_p1v, mode_p20, bt_p21): &(crate::prelude::Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)| crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::lower::expr::capture_name_f(rs_p1v)), crate::lower::types::own_f(&crate::lower::types::Vl::VlPlace(rs_p1v.clone(), mode_p20.clone(), bt_p21.clone())))));
    let env_c_pm = crate::prelude::fold(&caps_pk, &env_s_pe, &(|en_p22: &crate::lower::types::Env, (k_p23, rs_p24, _, bt_p25): &(crate::prelude::Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)| crate::lower::types::bind_f(en_p22, k_p23, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(crate::lower::expr::capture_name_f(rs_p24)), crate::lower::types::Holding::Owned, bt_p25.clone()))));
    let env1_pn = crate::lower::types::bind_f(&crate::lower::types::bind_f(&env_c_pm, &crate::prelude::Text::lit("key"), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(key_name_ph.clone()), crate::lower::types::Holding::Owned, kt_p1n.clone())), &crate::prelude::Text::lit("_"), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(val_name_pi.clone()), crate::lower::types::Holding::Owned, vt_p1o.clone()));
    let env_k_po = if is_array_p1p {
        crate::lower::types::bind_f(&env1_pn, &crate::prelude::Text::lit("ix"), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(key_name_ph.clone()), crate::lower::types::Holding::Owned, kt_p1n.clone()))
    } else {
        env1_pn.clone()
    };
    let bare_pp = crate::lower::templates::is_bare_for_f(binders_o3);
    let block_key_pq = crate::prelude::Text::from(format!("&_#block{}", &span_p6.start_p));
    let ref_or = match crate::lower::templates::ref_binder_o(binders_o3) {
        ::std::option::Option::Some(n_p26) => if crate::lower::templates::is_ref_path_f(source_p4) {
            ::std::option::Option::Some(crate::check::env::sname_key_f(&n_p26))
        } else {
            ::std::option::Option::None
        },
        ::std::option::Option::None => if bare_pp && crate::lower::templates::is_ref_path_f(source_p4) {
            ::std::option::Option::Some(crate::prelude::Text::lit("&_"))
        } else {
            ::std::option::Option::None
        },
    };
    let env_t_ps = if !bare_pp {
        env_k_po.clone()
    } else {
        match crate::prelude::get(&env_k_po.names_p, &crate::prelude::Text::lit("&_")) {
            ::std::option::Option::Some(b_p27) => crate::lower::types::bind_f(&env_k_po, &block_key_pq, &b_p27),
            ::std::option::Option::None => env_k_po.clone(),
        }
    };
    let ref_name_pt = crate::prelude::Text::from(format!("r{}", &span_p6.start_p));
    let (binds_p2e, env_b_p2f) = match (ref_or.clone(), binders_o3.clone()) {
        (::std::option::Option::Some(nkey_p28), _) => (crate::prelude::Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaMut(ref_name_pt.clone())), vt_p1o.clone()), crate::lower::model::Ex::XVar(val_name_pi.clone()))]), crate::lower::types::bind_f(&env_t_ps, &nkey_p28, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(ref_name_pt.clone()), crate::lower::types::Holding::Owned, vt_p1o.clone()))),
        (::std::option::Option::None, ::std::option::Option::None) => (crate::prelude::Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaMut(ref_name_pt.clone())), vt_p1o.clone()), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(val_name_pi.clone()))))]), crate::lower::types::bind_f(&env_t_ps, &crate::prelude::Text::lit("&_"), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(ref_name_pt.clone()), crate::lower::types::Holding::Owned, vt_p1o.clone()))),
        (::std::option::Option::None, ::std::option::Option::Some(fb_p29)) => match &fb_p29.second_o {
            ::std::option::Option::None => {
                let po_p2a = crate::lower::patterns::rust_pat_f(lx_p0, &fb_p29.first_p, &vty_p1t, &crate::lower::types::Holding::Owned, &crate::prelude::Text::from(format!("e{}", &span_p6.start_p)));
                (crate::prelude::Array::from(vec![crate::lower::model::Do::DoLet(po_p2a.pa_p.clone(), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(val_name_pi.clone()))))]), crate::lower::expr::bind_all_f(&env_k_po, &po_p2a.binds_p))
            },
            ::std::option::Option::Some(second_p2b) => {
                let pk_p2c = crate::lower::patterns::rust_pat_f(lx_p0, &fb_p29.first_p, &kty_p1u, &crate::lower::types::Holding::Owned, &crate::prelude::Text::from(format!("k{}_", &span_p6.start_p)));
                let pv_p2d = crate::lower::patterns::rust_pat_f(lx_p0, second_p2b, &vty_p1t, &crate::lower::types::Holding::Owned, &crate::prelude::Text::from(format!("e{}", &span_p6.start_p)));
                (crate::prelude::Array::from(vec![crate::lower::model::Do::DoLet(pk_p2c.pa_p.clone(), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(key_name_ph.clone())))), crate::lower::model::Do::DoLet(pv_p2d.pa_p.clone(), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(val_name_pi.clone()))))]), crate::lower::expr::bind_all_f(&crate::lower::expr::bind_all_f(&env_k_po, &pk_p2c.binds_p), &pv_p2d.binds_p))
            },
        },
    };
    let done_pu = crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("prism_rtl::Turn::Finished")), crate::prelude::Array::from(vec![pack_pd.clone()]));
    let ended_fv = {
        let ref_orx = ref_or.clone();
        let block_key_pqx = block_key_pq.clone();
        let is_array_p1px = is_array_p1p;
        let lx_p0x = lx_p0.clone();
        let source_p4x = source_p4.clone();
        let key_name_phx = key_name_ph.clone();
        let done_pux = done_pu.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::lower::types::Env, crate::lower::model::Ex)| {
            let ref_orxy = ref_orx.clone();
            let block_key_pqxy = block_key_pqx.clone();
            let is_array_p1pxy = is_array_p1px;
            let lx_p0xy = lx_p0x.clone();
            let source_p4xy = source_p4x.clone();
            let key_name_phxy = key_name_phx.clone();
            let done_puxy = done_pux.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let o2_p2g = p0;
                let _ = p1;
                match &ref_orxy {
                    ::std::option::Option::Some(nkey_p2h) => {
                        let o2b_p2i = with_block_topic_f(&o2_p2g, &block_key_pqxy);
                        let nkey_p2hx = nkey_p2h.clone();
                        crate::prelude::call_then(crate::lower::templates::start_place_of_f(lx_p0xy.clone(), o2b_p2i.clone(), source_p4xy.clone()), move |place_of_f_31780: crate::lower::model::Ex| {
                            let entry_p2j = crate::lower::model::Ex::XDeref(::std::rc::Rc::new(crate::lower::model::Ex::XCall(crate::lower::helper_ref_f(&(if is_array_p1pxy {
                                crate::prelude::Text::lit("at_mut")
                            } else {
                                crate::prelude::Text::lit("at_mut_map")
                            })), crate::prelude::Array::from(vec![crate::lower::model::Ex::XRefMut(::std::rc::Rc::new(place_of_f_31780)), crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XVar(key_name_phxy.clone())))]))));
                            let kept_p2k = match crate::prelude::get(&o2_p2g.names_p, &nkey_p2hx) {
                                ::std::option::Option::Some(crate::lower::types::Bn::BnLocal(rs_p2l, _, _)) => rs_p2l,
                                _ => crate::lower::expr::internal_bug_f(&crate::prelude::Text::lit("a `for &` entry\'s state lost in its turn")),
                            };
                            ::prism_rtl::Turn::Finished(crate::lower::model::Ex::XBlock(crate::prelude::Array::from(vec![crate::lower::model::Do::DoAssign(entry_p2j.clone(), kept_p2k.clone())]), ::std::rc::Rc::new(done_puxy.clone())))
                        })
                    },
                    ::std::option::Option::None => ::prism_rtl::Turn::Finished(done_puxy.clone()),
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::types::Env, crate::lower::model::Ex)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>>>
    };
    let turn_p10 = prepend_f(&binds_p2e, &upd_tail_from_f(lx_p0, &env_b_p2f, &env_b_p2f, body_p5, &crate::prelude::Nat::from(0u32), &body_p5.span_p, &ended_fv.clone()));
    let step_fn_p11 = prepend_f(&cap_dos_pl, &crate::lower::model::Ex::XClosure(true, crate::prelude::Array::from(vec![crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(pat_pc.clone()), st_ty_pb.clone()), crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaBind(key_name_ph.clone())), kt_p1n.clone()), crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaBind(val_name_pi.clone())), vt_p1o.clone())]), ::std::rc::Rc::new(turn_p10.clone())));
    let out_caps_p12 = caps_in_f(outer_p1, rest_reads_p7, &names_pa);
    let out_dos_p13 = crate::prelude::each(&out_caps_p12, &(|(_, rs_p2m, mode_p2n, bt_p2o): &(crate::prelude::Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)| crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::lower::expr::outer_name_f(rs_p2m)), crate::lower::types::own_f(&crate::lower::types::Vl::VlPlace(rs_p2m.clone(), mode_p2n.clone(), bt_p2o.clone())))));
    let outer2_p14 = crate::prelude::fold(&out_caps_p12, outer_p1, &(|en_p2p: &crate::lower::types::Env, (k_p2q, rs_p2r, _, bt_p2s): &(crate::prelude::Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)| crate::lower::types::bind_f(en_p2p, k_p2q, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(crate::lower::expr::outer_name_f(rs_p2r)), crate::lower::types::Holding::Owned, bt_p2s.clone()))));
    let env2_p15 = crate::prelude::fold(&out_caps_p12, &env_s_pe, &(|en_p2t: &crate::lower::types::Env, (k_p2u, rs_p2v, _, bt_p30): &(crate::prelude::Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)| crate::lower::types::bind_f(en_p2t, k_p2u, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(crate::lower::expr::outer_name_f(rs_p2v)), crate::lower::types::Holding::Owned, bt_p30.clone()))));
    let looping_p16 = crate::lower::helper_ref_f(&(if is_array_p1p {
        crate::prelude::Text::lit("for_turns_indexed")
    } else {
        crate::prelude::Text::lit("for_turns_keyed")
    }));
    let enter_p17 = crate::lower::model::Ex::XCall(crate::lower::helper_ref_f(&crate::prelude::Text::lit("call_then")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCall(looping_p16.clone(), crate::prelude::Array::from(vec![src_pf.clone(), pack_pd.clone(), step_fn_p11.clone()])), crate::lower::model::Ex::XClosure(true, crate::prelude::Array::from(vec![crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(pat_pc.clone()), st_ty_pb.clone())]), ::std::rc::Rc::new(crate::prelude::run_to_end(cont_f8((outer2_p14.clone(), env2_p15.clone())))))]));
    prepend_f(&out_dos_p13, &enter_p17)
}

/// The step machine of `ForJob`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ForJob: unbounded fn Lx, Env, Env, ?ForBinders, Expr, Block, Range, [Text], (unbounded fn Env, Env -> Ex) -> Ex
/// ```
pub struct ForJob {
    pub lx_p0: crate::lower::Lx,
    pub outer_p1: crate::lower::types::Env,
    pub env_p2: crate::lower::types::Env,
    pub binders_o3: ::std::option::Option<crate::syntax::ForBinders>,
    pub source_p4: crate::syntax::Expr,
    pub body_p5: crate::syntax::Block,
    pub span_p6: crate::syntax::Range,
    pub rest_reads_p7: crate::prelude::Array<crate::prelude::Text>,
    pub cont_f8: ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::types::Env, crate::lower::types::Env)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>>>,
}

impl ::prism_rtl::Job<crate::lower::model::Ex> for ForJob {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::lower::model::Ex> {
        let lx_p0 = &self.lx_p0;
        let outer_p1 = &self.outer_p1;
        let env_p2 = &self.env_p2;
        let binders_o3 = &self.binders_o3;
        let source_p4 = &self.source_p4;
        let body_p5 = &self.body_p5;
        let span_p6 = &self.span_p6;
        let rest_reads_p7 = &self.rest_reads_p7;
        let cont_f8 = &self.cont_f8;
        let state_p9 = crate::prelude::fold(&crate::prelude::keys(&env_p2.names_p), &crate::prelude::Array::new(), &(|acc_p18: &crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy)>, k_p19: &crate::prelude::Text| if !crate::syntax::lexer::chars::has_prefix_f(k_p19, &crate::prelude::Text::lit("&")) {
            acc_p18.clone()
        } else {
            match crate::prelude::get(&env_p2.names_p, k_p19) {
                ::std::option::Option::Some(crate::lower::types::Bn::BnLocal(rs_p1a, _, bt_p1b)) => crate::prelude::push(acc_p18, &(k_p19.clone(), crate::lower::types::place_stem_f(&rs_p1a), bt_p1b)),
                _ => acc_p18.clone(),
            }
        }));
        let names_pa = crate::prelude::each(&state_p9, &(|(_, rs_p1c, _): &(crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy)| rs_p1c.clone()));
        let st_ty_pb = crate::lower::model::OutTy::OutTuple(crate::prelude::each(&state_p9, &(|(_, _, bt_p1d): &(crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy)| bt_p1d.clone())));
        let pat_pc = crate::lower::model::Pa::PaTuple(crate::prelude::each(&names_pa, &(|n_p1e: &crate::prelude::Text| crate::lower::model::Pa::PaMut(crate::prelude::Text::from(format!("{}", n_p1e))))));
        let pack_pd = crate::lower::model::Ex::XTuple(crate::prelude::each(&names_pa, &(|n_p1f: &crate::prelude::Text| crate::lower::model::Ex::XVar(n_p1f.clone()))));
        let env_s_pe = crate::prelude::fold(&state_p9, env_p2, &(|en_p1g: &crate::lower::types::Env, (k_p1h, rs_p1i, bt_p1j): &(crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy)| crate::lower::types::bind_f(en_p1g, k_p1h, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(rs_p1i.clone()), crate::lower::types::Holding::Owned, bt_p1j.clone()))));
        let binders_o3x = binders_o3.clone();
        let cont_f8x = cont_f8.clone();
        let body_p5x = body_p5.clone();
        let env_p2x = env_p2.clone();
        let lx_p0x = lx_p0.clone();
        let outer_p1x = outer_p1.clone();
        let rest_reads_p7x = rest_reads_p7.clone();
        let source_p4x = source_p4.clone();
        let span_p6x = span_p6.clone();
        crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p0x.clone(), env_p2x.clone(), source_p4x.clone()), move |value_of_f_28389: crate::lower::types::Vl| {
            let src_pf = crate::lower::types::own_f(&crate::lower::types::plain_value_f(&value_of_f_28389));
            let sty_pg = crate::lower::types::collection_f(&crate::lower::types::peel_f(&crate::lower::type_at_f(&lx_p0x, &source_p4x.span_p)));
            let binders_o3xz = binders_o3x.clone();
            let cont_f8xz = cont_f8x.clone();
            let body_p5xz = body_p5x.clone();
            let env_s_pez = env_s_pe.clone();
            let lx_p0xz = lx_p0x.clone();
            let names_paz = names_pa.clone();
            let outer_p1xz = outer_p1x.clone();
            let pack_pdz = pack_pd.clone();
            let pat_pcz = pat_pc.clone();
            let rest_reads_p7xz = rest_reads_p7x.clone();
            let source_p4xz = source_p4x.clone();
            let span_p6xz = span_p6x.clone();
            let src_pfz = src_pf.clone();
            let st_ty_pbz = st_ty_pb.clone();
            let sty_pgz = sty_pg.clone();
            let k_let28476 = move |v28476: (crate::lower::model::OutTy, crate::lower::model::OutTy, bool)| {
                let (kt_p1n, vt_p1o, is_array_p1p) = v28476;
                let (vty_p1t, kty_p1u) = match &sty_pgz {
                    crate::check::types::Ty::TyArray(v_p1q) => ((**v_p1q).clone(), crate::check::types::Ty::TyCon(crate::prelude::Text::lit("Nat"), crate::prelude::Array::new())),
                    crate::check::types::Ty::TyMap(k_p1r, v_p1s) => ((**v_p1s).clone(), (**k_p1r).clone()),
                    _ => (crate::check::types::Ty::TyErr, crate::check::types::Ty::TyErr),
                };
                let key_name_ph = crate::prelude::Text::from(format!("k{}", &span_p6xz.start_p));
                let val_name_pi = crate::prelude::Text::from(format!("v{}", &span_p6xz.start_p));
                let loop_reads_pj = reads_in_f(&lx_p0xz, &span_p6xz);
                let caps_pk = caps_in_f(&env_s_pez, &loop_reads_pj, &names_paz);
                let cap_dos_pl = crate::prelude::each(&caps_pk, &(|(_, rs_p1v, mode_p20, bt_p21): &(crate::prelude::Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)| crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::lower::expr::capture_name_f(rs_p1v)), crate::lower::types::own_f(&crate::lower::types::Vl::VlPlace(rs_p1v.clone(), mode_p20.clone(), bt_p21.clone())))));
                let env_c_pm = crate::prelude::fold(&caps_pk, &env_s_pez, &(|en_p22: &crate::lower::types::Env, (k_p23, rs_p24, _, bt_p25): &(crate::prelude::Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)| crate::lower::types::bind_f(en_p22, k_p23, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(crate::lower::expr::capture_name_f(rs_p24)), crate::lower::types::Holding::Owned, bt_p25.clone()))));
                let env1_pn = crate::lower::types::bind_f(&crate::lower::types::bind_f(&env_c_pm, &crate::prelude::Text::lit("key"), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(key_name_ph.clone()), crate::lower::types::Holding::Owned, kt_p1n.clone())), &crate::prelude::Text::lit("_"), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(val_name_pi.clone()), crate::lower::types::Holding::Owned, vt_p1o.clone()));
                let env_k_po = if is_array_p1p {
                    crate::lower::types::bind_f(&env1_pn, &crate::prelude::Text::lit("ix"), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(key_name_ph.clone()), crate::lower::types::Holding::Owned, kt_p1n.clone()))
                } else {
                    env1_pn.clone()
                };
                let bare_pp = crate::lower::templates::is_bare_for_f(&binders_o3xz);
                let block_key_pq = crate::prelude::Text::from(format!("&_#block{}", &span_p6xz.start_p));
                let binders_o3xzz = binders_o3xz.clone();
                let cont_f8xzz = cont_f8xz.clone();
                let bare_ppz = bare_pp;
                let block_key_pqz = block_key_pq.clone();
                let body_p5xzz = body_p5xz.clone();
                let cap_dos_plz = cap_dos_pl.clone();
                let env_k_poz = env_k_po.clone();
                let env_s_pezz = env_s_pez.clone();
                let is_array_p1pz = is_array_p1p;
                let key_name_phz = key_name_ph.clone();
                let kt_p1nz = kt_p1n.clone();
                let kty_p1uz = kty_p1u.clone();
                let lx_p0xzz = lx_p0xz.clone();
                let names_pazz = names_paz.clone();
                let outer_p1xzz = outer_p1xz.clone();
                let pack_pdzz = pack_pdz.clone();
                let pat_pczz = pat_pcz.clone();
                let rest_reads_p7xzz = rest_reads_p7xz.clone();
                let source_p4xzz = source_p4xz.clone();
                let span_p6xzz = span_p6xz.clone();
                let src_pfzz = src_pfz.clone();
                let st_ty_pbzz = st_ty_pbz.clone();
                let val_name_piz = val_name_pi.clone();
                let vt_p1oz = vt_p1o.clone();
                let vty_p1tz = vty_p1t.clone();
                let k_let30206 = move |v30206: ::std::option::Option<crate::prelude::Text>| {
                    let ref_or = v30206;
                    let env_t_ps = if !bare_ppz {
                        env_k_poz.clone()
                    } else {
                        match crate::prelude::get(&env_k_poz.names_p, &crate::prelude::Text::lit("&_")) {
                            ::std::option::Option::Some(b_p27) => crate::lower::types::bind_f(&env_k_poz, &block_key_pqz, &b_p27),
                            ::std::option::Option::None => env_k_poz.clone(),
                        }
                    };
                    let ref_name_pt = crate::prelude::Text::from(format!("r{}", &span_p6xzz.start_p));
                    let ref_orz = ref_or.clone();
                    let cont_f8xzzz = cont_f8xzz.clone();
                    let block_key_pqzz = block_key_pqz.clone();
                    let body_p5xzzz = body_p5xzz.clone();
                    let cap_dos_plzz = cap_dos_plz.clone();
                    let env_s_pezzz = env_s_pezz.clone();
                    let is_array_p1pzz = is_array_p1pz;
                    let key_name_phzz = key_name_phz.clone();
                    let kt_p1nzz = kt_p1nz.clone();
                    let lx_p0xzzz = lx_p0xzz.clone();
                    let names_pazzz = names_pazz.clone();
                    let outer_p1xzzz = outer_p1xzz.clone();
                    let pack_pdzzz = pack_pdzz.clone();
                    let pat_pczzz = pat_pczz.clone();
                    let rest_reads_p7xzzz = rest_reads_p7xzz.clone();
                    let source_p4xzzz = source_p4xzz.clone();
                    let src_pfzzz = src_pfzz.clone();
                    let st_ty_pbzzz = st_ty_pbzz.clone();
                    let val_name_pizz = val_name_piz.clone();
                    let vt_p1ozz = vt_p1oz.clone();
                    let k_let30518 = move |v30518: (crate::prelude::Array<crate::lower::model::Do>, crate::lower::types::Env)| {
                        let (binds_p2e, env_b_p2f) = v30518;
                        let done_pu = crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("prism_rtl::Turn::Finished")), crate::prelude::Array::from(vec![pack_pdzzz.clone()]));
                        let ended_fv = {
                            let ref_orzx = ref_orz.clone();
                            let block_key_pqzzx = block_key_pqzz.clone();
                            let is_array_p1pzzx = is_array_p1pzz;
                            let lx_p0xzzzx = lx_p0xzzz.clone();
                            let source_p4xzzzx = source_p4xzzz.clone();
                            let key_name_phzzx = key_name_phzz.clone();
                            let done_pux = done_pu.clone();
                            ::std::rc::Rc::new(move |(p0, p1): (crate::lower::types::Env, crate::lower::model::Ex)| {
                                let ref_orzxy = ref_orzx.clone();
                                let block_key_pqzzxy = block_key_pqzzx.clone();
                                let is_array_p1pzzxy = is_array_p1pzzx;
                                let lx_p0xzzzxy = lx_p0xzzzx.clone();
                                let source_p4xzzzxy = source_p4xzzzx.clone();
                                let key_name_phzzxy = key_name_phzzx.clone();
                                let done_puxy = done_pux.clone();
                                crate::prelude::entered(crate::prelude::once_job(move || {
                                    let o2_p2g = p0;
                                    let _ = p1;
                                    match &ref_orzxy {
                                        ::std::option::Option::Some(nkey_p2h) => {
                                            let o2b_p2i = with_block_topic_f(&o2_p2g, &block_key_pqzzxy);
                                            let nkey_p2hx = nkey_p2h.clone();
                                            crate::prelude::call_then(crate::lower::templates::start_place_of_f(lx_p0xzzzxy.clone(), o2b_p2i.clone(), source_p4xzzzxy.clone()), move |place_of_f_31780: crate::lower::model::Ex| {
                                                let entry_p2j = crate::lower::model::Ex::XDeref(::std::rc::Rc::new(crate::lower::model::Ex::XCall(crate::lower::helper_ref_f(&(if is_array_p1pzzxy {
                                                    crate::prelude::Text::lit("at_mut")
                                                } else {
                                                    crate::prelude::Text::lit("at_mut_map")
                                                })), crate::prelude::Array::from(vec![crate::lower::model::Ex::XRefMut(::std::rc::Rc::new(place_of_f_31780)), crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XVar(key_name_phzzxy.clone())))]))));
                                                let kept_p2k = match crate::prelude::get(&o2_p2g.names_p, &nkey_p2hx) {
                                                    ::std::option::Option::Some(crate::lower::types::Bn::BnLocal(rs_p2l, _, _)) => rs_p2l,
                                                    _ => crate::lower::expr::internal_bug_f(&crate::prelude::Text::lit("a `for &` entry\'s state lost in its turn")),
                                                };
                                                ::prism_rtl::Turn::Finished(crate::lower::model::Ex::XBlock(crate::prelude::Array::from(vec![crate::lower::model::Do::DoAssign(entry_p2j.clone(), kept_p2k.clone())]), ::std::rc::Rc::new(done_puxy.clone())))
                                            })
                                        },
                                        ::std::option::Option::None => ::prism_rtl::Turn::Finished(done_puxy.clone()),
                                    }
                                }))
                            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::types::Env, crate::lower::model::Ex)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>>>
                        };
                        crate::prelude::call_then(start_upd_tail_from_f(lx_p0xzzz.clone(), env_b_p2f.clone(), env_b_p2f.clone(), body_p5xzzz.clone(), crate::prelude::Nat::from(0u32), body_p5xzzz.span_p.clone(), ended_fv.clone()), move |upd_tail_from_f_32131: crate::lower::model::Ex| {
                            let turn_p10 = prepend_f(&binds_p2e, &upd_tail_from_f_32131);
                            let step_fn_p11 = prepend_f(&cap_dos_plzz, &crate::lower::model::Ex::XClosure(true, crate::prelude::Array::from(vec![crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(pat_pczzz.clone()), st_ty_pbzzz.clone()), crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaBind(key_name_phzz.clone())), kt_p1nzz.clone()), crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaBind(val_name_pizz.clone())), vt_p1ozz.clone())]), ::std::rc::Rc::new(turn_p10.clone())));
                            let out_caps_p12 = caps_in_f(&outer_p1xzzz, &rest_reads_p7xzzz, &names_pazzz);
                            let out_dos_p13 = crate::prelude::each(&out_caps_p12, &(|(_, rs_p2m, mode_p2n, bt_p2o): &(crate::prelude::Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)| crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::lower::expr::outer_name_f(rs_p2m)), crate::lower::types::own_f(&crate::lower::types::Vl::VlPlace(rs_p2m.clone(), mode_p2n.clone(), bt_p2o.clone())))));
                            let outer2_p14 = crate::prelude::fold(&out_caps_p12, &outer_p1xzzz, &(|en_p2p: &crate::lower::types::Env, (k_p2q, rs_p2r, _, bt_p2s): &(crate::prelude::Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)| crate::lower::types::bind_f(en_p2p, k_p2q, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(crate::lower::expr::outer_name_f(rs_p2r)), crate::lower::types::Holding::Owned, bt_p2s.clone()))));
                            let env2_p15 = crate::prelude::fold(&out_caps_p12, &env_s_pezzz, &(|en_p2t: &crate::lower::types::Env, (k_p2u, rs_p2v, _, bt_p30): &(crate::prelude::Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)| crate::lower::types::bind_f(en_p2t, k_p2u, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(crate::lower::expr::outer_name_f(rs_p2v)), crate::lower::types::Holding::Owned, bt_p30.clone()))));
                            let looping_p16 = crate::lower::helper_ref_f(&(if is_array_p1pzz {
                                crate::prelude::Text::lit("for_turns_indexed")
                            } else {
                                crate::prelude::Text::lit("for_turns_keyed")
                            }));
                            crate::prelude::call_value((&cont_f8xzzz)((outer2_p14.clone(), env2_p15.clone())), move |cont_32956: crate::lower::model::Ex| {
                                let enter_p17 = crate::lower::model::Ex::XCall(crate::lower::helper_ref_f(&crate::prelude::Text::lit("call_then")), crate::prelude::Array::from(vec![crate::lower::model::Ex::XCall(looping_p16.clone(), crate::prelude::Array::from(vec![src_pfzzz.clone(), pack_pdzzz.clone(), step_fn_p11.clone()])), crate::lower::model::Ex::XClosure(true, crate::prelude::Array::from(vec![crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(pat_pczzz.clone()), st_ty_pbzzz.clone())]), ::std::rc::Rc::new(cont_32956))]));
                                ::prism_rtl::Turn::Finished(prepend_f(&out_dos_p13, &enter_p17))
                            })
                        })
                    };
                    match (ref_or.clone(), binders_o3xzz.clone()) {
                        (::std::option::Option::Some(nkey_p28), _) => k_let30518((crate::prelude::Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaMut(ref_name_pt.clone())), vt_p1oz.clone()), crate::lower::model::Ex::XVar(val_name_piz.clone()))]), crate::lower::types::bind_f(&env_t_ps, &nkey_p28, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(ref_name_pt.clone()), crate::lower::types::Holding::Owned, vt_p1oz.clone())))),
                        (::std::option::Option::None, ::std::option::Option::None) => k_let30518((crate::prelude::Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaMut(ref_name_pt.clone())), vt_p1oz.clone()), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(val_name_piz.clone()))))]), crate::lower::types::bind_f(&env_t_ps, &crate::prelude::Text::lit("&_"), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(ref_name_pt.clone()), crate::lower::types::Holding::Owned, vt_p1oz.clone())))),
                        (::std::option::Option::None, ::std::option::Option::Some(fb_p29)) => match fb_p29.second_o.clone() {
                            ::std::option::Option::None => crate::prelude::call_then(crate::lower::patterns::start_rust_pat_f(lx_p0xzz.clone(), fb_p29.first_p.clone(), vty_p1tz.clone(), crate::lower::types::Holding::Owned, crate::prelude::Text::from(format!("e{}", &span_p6xzz.start_p))), move |rust_pat_f_30944: crate::lower::patterns::PatOut| {
                                let po_p2a = rust_pat_f_30944;
                                k_let30518((crate::prelude::Array::from(vec![crate::lower::model::Do::DoLet(po_p2a.pa_p.clone(), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(val_name_piz.clone()))))]), crate::lower::expr::bind_all_f(&env_k_poz, &po_p2a.binds_p)))
                            }),
                            ::std::option::Option::Some(second_p2b) => crate::prelude::call_then(crate::lower::patterns::start_rust_pat_f(lx_p0xzz.clone(), fb_p29.first_p.clone(), kty_p1uz.clone(), crate::lower::types::Holding::Owned, crate::prelude::Text::from(format!("k{}_", &span_p6xzz.start_p))), move |rust_pat_f_31130: crate::lower::patterns::PatOut| {
                                let pk_p2c = rust_pat_f_31130;
                                crate::prelude::call_then(crate::lower::patterns::start_rust_pat_f(lx_p0xzz.clone(), second_p2b.clone(), vty_p1tz.clone(), crate::lower::types::Holding::Owned, crate::prelude::Text::from(format!("e{}", &span_p6xzz.start_p))), move |rust_pat_f_31206: crate::lower::patterns::PatOut| {
                                    let pv_p2d = rust_pat_f_31206;
                                    k_let30518((crate::prelude::Array::from(vec![crate::lower::model::Do::DoLet(pk_p2c.pa_p.clone(), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(key_name_phz.clone())))), crate::lower::model::Do::DoLet(pv_p2d.pa_p.clone(), crate::lower::model::Ex::XClone(::std::rc::Rc::new(crate::lower::model::Ex::XVar(val_name_piz.clone()))))]), crate::lower::expr::bind_all_f(&crate::lower::expr::bind_all_f(&env_k_poz, &pk_p2c.binds_p), &pv_p2d.binds_p)))
                                })
                            }),
                        },
                    }
                };
                match crate::lower::templates::ref_binder_o(&binders_o3xz) {
                    ::std::option::Option::Some(n_p26) => crate::prelude::call_then(crate::lower::templates::start_is_ref_path_f(source_p4xz.clone()), move |is_ref_path_f_30260: bool| k_let30206(if is_ref_path_f_30260 {
                        ::std::option::Option::Some(crate::check::env::sname_key_f(&n_p26))
                    } else {
                        ::std::option::Option::None
                    })),
                    ::std::option::Option::None => k_let30206(if bare_pp && crate::lower::templates::is_ref_path_f(&source_p4xz) {
                        ::std::option::Option::Some(crate::prelude::Text::lit("&_"))
                    } else {
                        ::std::option::Option::None
                    }),
                }
            };
            match sty_pg.clone() {
                crate::check::types::Ty::TyArray(v_p1k) => crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0x.clone(), (*v_p1k).clone()), move |out_ty_of_f_28543: crate::lower::model::OutTy| k_let28476((crate::lower::model::OutTy::OutNat, out_ty_of_f_28543, true))),
                crate::check::types::Ty::TyMap(k_p1l, v_p1m) => crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0x.clone(), (*k_p1l).clone()), move |out_ty_of_f_28589: crate::lower::model::OutTy| crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0x.clone(), (*v_p1m).clone()), move |out_ty_of_f_28606: crate::lower::model::OutTy| k_let28476((out_ty_of_f_28589, out_ty_of_f_28606, false)))),
                _ => k_let28476((crate::lower::model::OutTy::OutUnit, crate::lower::model::OutTy::OutUnit, true)),
            }
        })
    }
}

/// `Start ForJob, x`: what the function value is when passed to `@Run`.
pub fn start_for_job_f(lx_p0: crate::lower::Lx, outer_p1: crate::lower::types::Env, env_p2: crate::lower::types::Env, binders_o3: ::std::option::Option<crate::syntax::ForBinders>, source_p4: crate::syntax::Expr, body_p5: crate::syntax::Block, span_p6: crate::syntax::Range, rest_reads_p7: crate::prelude::Array<crate::prelude::Text>, cont_f8: ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::types::Env, crate::lower::types::Env)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>>>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>> {
    ::std::rc::Rc::new(ForJob { lx_p0, outer_p1, env_p2, binders_o3, source_p4, body_p5, span_p6, rest_reads_p7, cont_f8 })
}

/// ```prism
/// WithBlockTopic: fn Env, Text -> Env
/// ```
pub fn with_block_topic_f(env_p0: &crate::lower::types::Env, block_key_p1: &crate::prelude::Text) -> crate::lower::types::Env {
    match crate::prelude::get(&env_p0.names_p, block_key_p1) {
        ::std::option::Option::Some(b_p2) => crate::lower::types::bind_f(env_p0, &crate::prelude::Text::lit("&_"), &b_p2),
        ::std::option::Option::None => env_p0.clone(),
    }
}

/// ```prism
/// InstanceOf: fn Text -> Text
/// ```
pub fn instance_of_f(k_p0: &crate::prelude::Text) -> crate::prelude::Text {
    crate::prelude::or(&crate::prelude::index(&crate::prelude::split_on(k_p0, &crate::prelude::Text::lit("#inst")), &crate::prelude::Nat::from(0u32)), k_p0)
}

/// ```prism
/// CapsIn: fn Env, [Text], [Text] -> [((Text, Ex, Holding, OutTy))]
/// ```
pub fn caps_in_f(env_p0: &crate::lower::types::Env, reads_p1: &crate::prelude::Array<crate::prelude::Text>, skip_p2: &crate::prelude::Array<crate::prelude::Text>) -> crate::prelude::Array<(crate::prelude::Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)> {
    crate::prelude::fold(&crate::prelude::keys(&env_p0.names_p), &crate::prelude::Array::new(), &(|acc_p3: &crate::prelude::Array<(crate::prelude::Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)>, k_p4: &crate::prelude::Text| match crate::prelude::get(&env_p0.names_p, k_p4) {
        ::std::option::Option::Some(crate::lower::types::Bn::BnLocal(rs_p5, mode_p6, bt_p7)) => if (crate::check::types::has_text_f(skip_p2, &crate::lower::types::place_stem_f(&rs_p5)) || crate::lower::types::on_self_f(&rs_p5)) || !reads_f(reads_p1, k_p4) {
            acc_p3.clone()
        } else {
            crate::prelude::push(acc_p3, &(k_p4.clone(), rs_p5.clone(), mode_p6, bt_p7))
        },
        _ => acc_p3.clone(),
    }))
}

/// ```prism
/// ?FrameCall: unbounded fn Lx, Env, Expr, Bool -> ?Expr
/// ```
pub fn frame_call_o(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, e_p2: &crate::syntax::Expr, top_p3: &bool) -> ::std::option::Option<crate::syntax::Expr> {
    if crate::check::env::has_key_f(&env_p1.spans_p, &crate::lower::place_key_f(lx_p0, &e_p2.span_p)) {
        ::std::option::Option::None
    } else {
        'm34341: {
            let scrutinee = &*e_p2.kind_p;
            if let crate::syntax::ExprKind::EGroup(x_p4) = scrutinee {
                break 'm34341 frame_call_o(lx_p0, env_p1, &**x_p4, top_p3);
            }
            if let crate::syntax::ExprKind::ECall(c_p5, args_p6, _, _) = scrutinee {
                break 'm34341 match first_frame_o(lx_p0, env_p1, &crate::prelude::each(args_p6, &(|a_p7: &crate::syntax::Arg| a_p7.value_p.clone()))) {
                    ::std::option::Option::Some(x_p8) => ::std::option::Option::Some(x_p8),
                    ::std::option::Option::None => if *top_p3 {
                        ::std::option::Option::None
                    } else {
                        match tail_callee_o(lx_p0, env_p1, &**c_p5) {
                            ::std::option::Option::Some(_) => ::std::option::Option::Some(e_p2.clone()),
                            ::std::option::Option::None => match local_job_fn_o(lx_p0, env_p1, &**c_p5) {
                                ::std::option::Option::Some(_) => ::std::option::Option::Some(e_p2.clone()),
                                ::std::option::Option::None => match crate::lower::expr::prelude_job_call_o(lx_p0, env_p1, e_p2) {
                                    ::std::option::Option::Some(_) => ::std::option::Option::Some(e_p2.clone()),
                                    ::std::option::Option::None => ::std::option::Option::None,
                                },
                            },
                        }
                    },
                };
            }
            if let crate::syntax::ExprKind::EMatch(x_p9, _) = scrutinee {
                break 'm34341 frame_call_o(lx_p0, env_p1, &**x_p9, &false);
            }
            if let crate::syntax::ExprKind::EIf(m34341_3_0, _, _) = scrutinee && let crate::syntax::Cond::CondExpr(x_pa) = &**m34341_3_0 {
                break 'm34341 frame_call_o(lx_p0, env_p1, &**x_pa, &false);
            }
            if let crate::syntax::ExprKind::EBinary(op_pb, l_pc, r_pd) = scrutinee {
                break 'm34341 if (op_pb == &crate::prelude::Text::lit("and")) || (op_pb == &crate::prelude::Text::lit("or")) {
                    frame_call_o(lx_p0, env_p1, &**l_pc, &false)
                } else {
                    first_frame_o(lx_p0, env_p1, &crate::prelude::Array::from(vec![(**l_pc).clone(), (**r_pd).clone()]))
                };
            }
            if let crate::syntax::ExprKind::ETuple(es_pe) = scrutinee {
                break 'm34341 first_frame_o(lx_p0, env_p1, es_pe);
            }
            if let crate::syntax::ExprKind::EArray(es_pf) = scrutinee {
                break 'm34341 first_frame_o(lx_p0, env_p1, es_pf);
            }
            if let crate::syntax::ExprKind::EUnary(_, x_pg) = scrutinee {
                break 'm34341 frame_call_o(lx_p0, env_p1, &**x_pg, &false);
            }
            if let crate::syntax::ExprKind::EField(x_ph, _, _) = scrutinee {
                break 'm34341 frame_call_o(lx_p0, env_p1, &**x_ph, &false);
            }
            if let crate::syntax::ExprKind::EIndex(x_pi, i_pj) = scrutinee {
                break 'm34341 first_frame_o(lx_p0, env_p1, &crate::prelude::Array::from(vec![(**x_pi).clone(), (**i_pj).clone()]));
            }
            if let crate::syntax::ExprKind::EMethod(x_pk, _, args_pl) = scrutinee {
                break 'm34341 first_frame_o(lx_p0, env_p1, &crate::prelude::append(&crate::prelude::Array::from(vec![(**x_pk).clone()]), &crate::prelude::each(args_pl, &(|a_pm: &crate::syntax::Arg| a_pm.value_p.clone()))));
            }
            if let crate::syntax::ExprKind::ECast(x_pn, _, _) = scrutinee {
                break 'm34341 frame_call_o(lx_p0, env_p1, &**x_pn, &false);
            }
            if let crate::syntax::ExprKind::ELit(l_po) = scrutinee {
                break 'm34341 match &l_po.kind_p {
                    crate::syntax::LitKind::LText(segs_pp) => first_frame_o(lx_p0, env_p1, &placeholders_f(segs_pp)),
                    _ => ::std::option::Option::None,
                };
            }
            ::std::option::Option::None
        }
    }
}

/// The step machine of `FrameCall`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?FrameCall: unbounded fn Lx, Env, Expr, Bool -> ?Expr
/// ```
pub struct FrameCall {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub e_p2: crate::syntax::Expr,
    pub top_p3: bool,
}

impl ::prism_rtl::Job<::std::option::Option<crate::syntax::Expr>> for FrameCall {
    fn cycle(&self) -> ::prism_rtl::Turn<::std::option::Option<crate::syntax::Expr>> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let e_p2 = &self.e_p2;
        let top_p3 = &self.top_p3;
        if crate::check::env::has_key_f(&env_p1.spans_p, &crate::lower::place_key_f(lx_p0, &e_p2.span_p)) {
            ::prism_rtl::Turn::Finished(::std::option::Option::None)
        } else {
            'm34341: {
                let scrutinee = &*e_p2.kind_p;
                if let crate::syntax::ExprKind::EGroup(x_p4) = scrutinee {
                    break 'm34341 ::prism_rtl::Turn::More(::std::rc::Rc::new(FrameCall { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), e_p2: (**x_p4).clone(), top_p3: *top_p3 }));
                }
                if let crate::syntax::ExprKind::ECall(c_p5, args_p6, _, _) = scrutinee {
                    break 'm34341 {
                        let args_p6x = args_p6.clone();
                        let c_p5x = (**c_p5).clone();
                        let e_p2x = e_p2.clone();
                        let env_p1x = env_p1.clone();
                        let lx_p0x = lx_p0.clone();
                        let top_p3x = *top_p3;
                        crate::prelude::call_then(start_first_frame_o(lx_p0x.clone(), env_p1x.clone(), crate::prelude::each(&args_p6x, &(|a_p7: &crate::syntax::Arg| a_p7.value_p.clone()))), move |first_frame_o_34445: ::std::option::Option<crate::syntax::Expr>| match first_frame_o_34445 {
                            ::std::option::Option::Some(x_p8) => ::prism_rtl::Turn::Finished(::std::option::Option::Some(x_p8.clone())),
                            ::std::option::Option::None => if top_p3x {
                                ::prism_rtl::Turn::Finished(::std::option::Option::None)
                            } else {
                                match tail_callee_o(&lx_p0x, &env_p1x, &c_p5x) {
                                    ::std::option::Option::Some(_) => ::prism_rtl::Turn::Finished(::std::option::Option::Some(e_p2x.clone())),
                                    ::std::option::Option::None => crate::prelude::call_then(start_local_job_fn_o(lx_p0x.clone(), env_p1x.clone(), c_p5x.clone()), move |local_job_fn_o_34676: ::std::option::Option<crate::lower::types::Vl>| match local_job_fn_o_34676 {
                                        ::std::option::Option::Some(_) => ::prism_rtl::Turn::Finished(::std::option::Option::Some(e_p2x.clone())),
                                        ::std::option::Option::None => crate::prelude::call_then(crate::lower::expr::start_prelude_job_call_o(lx_p0x.clone(), env_p1x.clone(), e_p2x.clone()), move |prelude_job_call_o_34773: ::std::option::Option<crate::lower::model::Ex>| match prelude_job_call_o_34773 {
                                            ::std::option::Option::Some(_) => ::prism_rtl::Turn::Finished(::std::option::Option::Some(e_p2x.clone())),
                                            ::std::option::Option::None => ::prism_rtl::Turn::Finished(::std::option::Option::None),
                                        }),
                                    }),
                                }
                            },
                        })
                    };
                }
                if let crate::syntax::ExprKind::EMatch(x_p9, _) = scrutinee {
                    break 'm34341 ::prism_rtl::Turn::More(::std::rc::Rc::new(FrameCall { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), e_p2: (**x_p9).clone(), top_p3: false }));
                }
                if let crate::syntax::ExprKind::EIf(m34341_3_0, _, _) = scrutinee && let crate::syntax::Cond::CondExpr(x_pa) = &**m34341_3_0 {
                    break 'm34341 ::prism_rtl::Turn::More(::std::rc::Rc::new(FrameCall { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), e_p2: (**x_pa).clone(), top_p3: false }));
                }
                if let crate::syntax::ExprKind::EBinary(op_pb, l_pc, r_pd) = scrutinee {
                    break 'm34341 if (op_pb == &crate::prelude::Text::lit("and")) || (op_pb == &crate::prelude::Text::lit("or")) {
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(FrameCall { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), e_p2: (**l_pc).clone(), top_p3: false }))
                    } else {
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(FirstFrame { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), es_p2: crate::prelude::Array::from(vec![(**l_pc).clone(), (**r_pd).clone()]) }))
                    };
                }
                if let crate::syntax::ExprKind::ETuple(es_pe) = scrutinee {
                    break 'm34341 ::prism_rtl::Turn::More(::std::rc::Rc::new(FirstFrame { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), es_p2: es_pe.clone() }));
                }
                if let crate::syntax::ExprKind::EArray(es_pf) = scrutinee {
                    break 'm34341 ::prism_rtl::Turn::More(::std::rc::Rc::new(FirstFrame { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), es_p2: es_pf.clone() }));
                }
                if let crate::syntax::ExprKind::EUnary(_, x_pg) = scrutinee {
                    break 'm34341 ::prism_rtl::Turn::More(::std::rc::Rc::new(FrameCall { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), e_p2: (**x_pg).clone(), top_p3: false }));
                }
                if let crate::syntax::ExprKind::EField(x_ph, _, _) = scrutinee {
                    break 'm34341 ::prism_rtl::Turn::More(::std::rc::Rc::new(FrameCall { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), e_p2: (**x_ph).clone(), top_p3: false }));
                }
                if let crate::syntax::ExprKind::EIndex(x_pi, i_pj) = scrutinee {
                    break 'm34341 ::prism_rtl::Turn::More(::std::rc::Rc::new(FirstFrame { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), es_p2: crate::prelude::Array::from(vec![(**x_pi).clone(), (**i_pj).clone()]) }));
                }
                if let crate::syntax::ExprKind::EMethod(x_pk, _, args_pl) = scrutinee {
                    break 'm34341 ::prism_rtl::Turn::More(::std::rc::Rc::new(FirstFrame { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), es_p2: crate::prelude::append(&crate::prelude::Array::from(vec![(**x_pk).clone()]), &crate::prelude::each(args_pl, &(|a_pm: &crate::syntax::Arg| a_pm.value_p.clone()))) }));
                }
                if let crate::syntax::ExprKind::ECast(x_pn, _, _) = scrutinee {
                    break 'm34341 ::prism_rtl::Turn::More(::std::rc::Rc::new(FrameCall { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), e_p2: (**x_pn).clone(), top_p3: false }));
                }
                if let crate::syntax::ExprKind::ELit(l_po) = scrutinee {
                    break 'm34341 match &l_po.kind_p {
                        crate::syntax::LitKind::LText(segs_pp) => ::prism_rtl::Turn::More(::std::rc::Rc::new(FirstFrame { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), es_p2: placeholders_f(segs_pp) })),
                        _ => ::prism_rtl::Turn::Finished(::std::option::Option::None),
                    };
                }
                ::prism_rtl::Turn::Finished(::std::option::Option::None)
            }
        }
    }
}

/// `Start FrameCall, x`: what the function value is when passed to `@Run`.
pub fn start_frame_call_o(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, e_p2: crate::syntax::Expr, top_p3: bool) -> ::std::rc::Rc<dyn ::prism_rtl::Job<::std::option::Option<crate::syntax::Expr>>> {
    ::std::rc::Rc::new(FrameCall { lx_p0, env_p1, e_p2, top_p3 })
}

/// ```prism
/// Placeholders: fn [TextSeg] -> [Expr]
/// ```
pub fn placeholders_f(segs_p0: &crate::prelude::Array<crate::syntax::TextSeg>) -> crate::prelude::Array<crate::syntax::Expr> {
    crate::prelude::fold(segs_p0, &crate::prelude::Array::new(), &(|acc_p1: &crate::prelude::Array<crate::syntax::Expr>, sg_p2: &crate::syntax::TextSeg| match sg_p2 {
        crate::syntax::TextSeg::SegPlaceholder(x_p3) => crate::prelude::push(acc_p1, x_p3),
        _ => acc_p1.clone(),
    }))
}

/// ```prism
/// ?FirstFrame: unbounded fn Lx, Env, [Expr] -> ?Expr
/// ```
pub fn first_frame_o(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, es_p2: &crate::prelude::Array<crate::syntax::Expr>) -> ::std::option::Option<crate::syntax::Expr> {
    crate::prelude::run_to_end(crate::prelude::fold_job(es_p2.clone(), ::std::option::Option::None, {
        let lx_p0x = lx_p0.clone();
        let env_p1x = env_p1.clone();
        ::std::rc::Rc::new(move |(p0, p1): (::std::option::Option<crate::syntax::Expr>, crate::syntax::Expr)| {
            let lx_p0xy = lx_p0x.clone();
            let env_p1xy = env_p1x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let found_o3 = p0;
                let x_p4 = p1;
                match &found_o3 {
                    ::std::option::Option::Some(f_p5) => ::prism_rtl::Turn::Finished(::std::option::Option::Some(f_p5.clone())),
                    ::std::option::Option::None => ::prism_rtl::Turn::More(::std::rc::Rc::new(FrameCall { lx_p0: lx_p0xy.clone(), env_p1: env_p1xy.clone(), e_p2: x_p4.clone(), top_p3: false })),
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((::std::option::Option<crate::syntax::Expr>, crate::syntax::Expr)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<::std::option::Option<crate::syntax::Expr>>>>
    }))
}

/// The step machine of `FirstFrame`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?FirstFrame: unbounded fn Lx, Env, [Expr] -> ?Expr
/// ```
pub struct FirstFrame {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub es_p2: crate::prelude::Array<crate::syntax::Expr>,
}

impl ::prism_rtl::Job<::std::option::Option<crate::syntax::Expr>> for FirstFrame {
    fn cycle(&self) -> ::prism_rtl::Turn<::std::option::Option<crate::syntax::Expr>> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let es_p2 = &self.es_p2;
        crate::prelude::fold_job(es_p2.clone(), ::std::option::Option::None, {
            let lx_p0x = lx_p0.clone();
            let env_p1x = env_p1.clone();
            ::std::rc::Rc::new(move |(p0, p1): (::std::option::Option<crate::syntax::Expr>, crate::syntax::Expr)| {
                let lx_p0xy = lx_p0x.clone();
                let env_p1xy = env_p1x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let found_o3 = p0;
                    let x_p4 = p1;
                    match &found_o3 {
                        ::std::option::Option::Some(f_p5) => ::prism_rtl::Turn::Finished(::std::option::Option::Some(f_p5.clone())),
                        ::std::option::Option::None => ::prism_rtl::Turn::More(::std::rc::Rc::new(FrameCall { lx_p0: lx_p0xy.clone(), env_p1: env_p1xy.clone(), e_p2: x_p4.clone(), top_p3: false })),
                    }
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((::std::option::Option<crate::syntax::Expr>, crate::syntax::Expr)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<::std::option::Option<crate::syntax::Expr>>>>
        }).cycle()
    }
}

/// `Start FirstFrame, x`: what the function value is when passed to `@Run`.
pub fn start_first_frame_o(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, es_p2: crate::prelude::Array<crate::syntax::Expr>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<::std::option::Option<crate::syntax::Expr>>> {
    ::std::rc::Rc::new(FirstFrame { lx_p0, env_p1, es_p2 })
}

/// ```prism
/// Frame: unbounded fn Lx, Env, Expr, [Text], (unbounded fn Env -> Ex) -> Ex
/// ```
pub fn frame_f(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, call_p2: &crate::syntax::Expr, rest_reads_p3: &crate::prelude::Array<crate::prelude::Text>, cont_f4: &::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::types::Env) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>>>) -> crate::lower::model::Ex {
    match &*call_p2.kind_p {
        crate::syntax::ExprKind::ECall(c_p5, args_p6, _, _) => {
            let qk_o7 = tail_callee_o(lx_p0, env_p1, &**c_p5);
            let qk_p8 = crate::prelude::or(&qk_o7, &crate::prelude::Text::lit(""));
            let base_p9 = match &qk_o7 {
                ::std::option::Option::Some(q_ph) => crate::prelude::or(&crate::prelude::get(&lx_p0.rs_names_p, q_ph), &crate::lower::snake_f(&crate::check::types::bare_name_f(q_ph))),
                ::std::option::Option::None => crate::lower::snake_f(&callee_text_f(&**c_p5)),
            };
            let v_pa = crate::prelude::Text::from(format!("{}_{}", &base_p9, &call_p2.span_p.start_p));
            let t_pb = crate::lower::types::out_ty_of_f(lx_p0, &crate::lower::types::peel_f(&crate::lower::type_at_f(lx_p0, &call_p2.span_p)));
            let caps_pc = crate::prelude::fold(&crate::prelude::keys(&env_p1.names_p), &crate::prelude::Array::new(), &(|acc_pi: &crate::prelude::Array<(crate::prelude::Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)>, k_pj: &crate::prelude::Text| match crate::prelude::get(&env_p1.names_p, k_pj) {
                ::std::option::Option::Some(crate::lower::types::Bn::BnLocal(rs_pk, mode_pl, bt_pm)) => if ((&mode_pl == &crate::lower::types::Holding::ByRef) || (&mode_pl == &crate::lower::types::Holding::RcRef)) && reads_f(rest_reads_p3, k_pj) {
                    crate::prelude::push(acc_pi, &(k_pj.clone(), rs_pk, mode_pl.clone(), bt_pm))
                } else {
                    acc_pi.clone()
                },
                _ => acc_pi.clone(),
            }));
            let dos_pd = crate::prelude::each(&caps_pc, &(|(_, rs_pn, mode_po, bt_pp): &(crate::prelude::Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)| crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::lower::expr::capture_name_f(rs_pn)), crate::lower::types::own_f(&crate::lower::types::Vl::VlPlace(rs_pn.clone(), mode_po.clone(), bt_pp.clone())))));
            let env2_pe = crate::prelude::fold(&caps_pc, env_p1, &(|en_pq: &crate::lower::types::Env, (k_pr, rs_ps, _, bt_pt): &(crate::prelude::Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)| crate::lower::types::bind_f(en_pq, k_pr, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(crate::lower::expr::capture_name_f(rs_ps)), crate::lower::types::Holding::Owned, bt_pt.clone()))));
            let env3_pf = crate::lower::types::bind_span_f(&env2_pe, &crate::lower::place_key_f(lx_p0, &call_p2.span_p), &crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XVar(v_pa.clone()), t_pb.clone()));
            let enter_pg = match crate::prelude::get(&lx_p0.lifts_p, &crate::lower::place_key_f(lx_p0, &call_p2.span_p)) {
                ::std::option::Option::Some(ln_pu) if (&crate::prelude::len(&ln_pu.operands_p) > &crate::prelude::Nat::from(0u32)) => lifted_frame_f(lx_p0, &env2_pe, &env3_pf, &**c_p5, &qk_o7, &base_p9, args_p6, call_p2, &v_pa, &t_pb, &ln_pu, &ln_pu.operands_p, &cont_f4.clone()),
                _ => {
                    let (job_pv, how_p10) = frame_job_f(lx_p0, &env2_pe, &**c_p5, &qk_o7, &base_p9, args_p6, call_p2);
                    crate::lower::model::Ex::XCall(how_p10.clone(), crate::prelude::Array::from(vec![job_pv.clone(), frame_taker_f(lx_p0, &qk_o7, &**c_p5, call_p2, &v_pa, &t_pb, &crate::prelude::run_to_end(cont_f4(env3_pf.clone())))]))
                },
                _ => unreachable!("no arm matched"),
            };
            if &crate::prelude::len(&dos_pd) == &crate::prelude::Nat::from(0u32) {
                enter_pg.clone()
            } else {
                crate::lower::model::Ex::XBlock(dos_pd.clone(), ::std::rc::Rc::new(enter_pg.clone()))
            }
        },
        _ => crate::prelude::run_to_end(cont_f4(env_p1.clone())),
    }
}

/// The step machine of `Frame`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Frame: unbounded fn Lx, Env, Expr, [Text], (unbounded fn Env -> Ex) -> Ex
/// ```
pub struct Frame {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub call_p2: crate::syntax::Expr,
    pub rest_reads_p3: crate::prelude::Array<crate::prelude::Text>,
    pub cont_f4: ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::types::Env) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>>>,
}

impl ::prism_rtl::Job<crate::lower::model::Ex> for Frame {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::lower::model::Ex> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let call_p2 = &self.call_p2;
        let rest_reads_p3 = &self.rest_reads_p3;
        let cont_f4 = &self.cont_f4;
        match &*call_p2.kind_p {
            crate::syntax::ExprKind::ECall(c_p5, args_p6, _, _) => {
                let qk_o7 = tail_callee_o(lx_p0, env_p1, &**c_p5);
                let qk_p8 = crate::prelude::or(&qk_o7, &crate::prelude::Text::lit(""));
                let base_p9 = match &qk_o7 {
                    ::std::option::Option::Some(q_ph) => crate::prelude::or(&crate::prelude::get(&lx_p0.rs_names_p, q_ph), &crate::lower::snake_f(&crate::check::types::bare_name_f(q_ph))),
                    ::std::option::Option::None => crate::lower::snake_f(&callee_text_f(&**c_p5)),
                };
                let v_pa = crate::prelude::Text::from(format!("{}_{}", &base_p9, &call_p2.span_p.start_p));
                let cont_f4x = cont_f4.clone();
                let args_p6x = args_p6.clone();
                let c_p5x = (**c_p5).clone();
                let call_p2x = call_p2.clone();
                let env_p1x = env_p1.clone();
                let lx_p0x = lx_p0.clone();
                let rest_reads_p3x = rest_reads_p3.clone();
                crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0x.clone(), crate::lower::types::peel_f(&crate::lower::type_at_f(&lx_p0x, &call_p2x.span_p))), move |out_ty_of_f_36744: crate::lower::model::OutTy| {
                    let t_pb = out_ty_of_f_36744;
                    let caps_pc = crate::prelude::fold(&crate::prelude::keys(&env_p1x.names_p), &crate::prelude::Array::new(), &(|acc_pi: &crate::prelude::Array<(crate::prelude::Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)>, k_pj: &crate::prelude::Text| match crate::prelude::get(&env_p1x.names_p, k_pj) {
                        ::std::option::Option::Some(crate::lower::types::Bn::BnLocal(rs_pk, mode_pl, bt_pm)) => if ((&mode_pl == &crate::lower::types::Holding::ByRef) || (&mode_pl == &crate::lower::types::Holding::RcRef)) && reads_f(&rest_reads_p3x, k_pj) {
                            crate::prelude::push(acc_pi, &(k_pj.clone(), rs_pk, mode_pl.clone(), bt_pm))
                        } else {
                            acc_pi.clone()
                        },
                        _ => acc_pi.clone(),
                    }));
                    let dos_pd = crate::prelude::each(&caps_pc, &(|(_, rs_pn, mode_po, bt_pp): &(crate::prelude::Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)| crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::lower::expr::capture_name_f(rs_pn)), crate::lower::types::own_f(&crate::lower::types::Vl::VlPlace(rs_pn.clone(), mode_po.clone(), bt_pp.clone())))));
                    let env2_pe = crate::prelude::fold(&caps_pc, &env_p1x, &(|en_pq: &crate::lower::types::Env, (k_pr, rs_ps, _, bt_pt): &(crate::prelude::Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)| crate::lower::types::bind_f(en_pq, k_pr, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(crate::lower::expr::capture_name_f(rs_ps)), crate::lower::types::Holding::Owned, bt_pt.clone()))));
                    let env3_pf = crate::lower::types::bind_span_f(&env2_pe, &crate::lower::place_key_f(&lx_p0x, &call_p2x.span_p), &crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XVar(v_pa.clone()), t_pb.clone()));
                    let dos_pdz = dos_pd.clone();
                    let k_let37359 = move |v37359: crate::lower::model::Ex| {
                        let enter_pg = v37359;
                        if &crate::prelude::len(&dos_pdz) == &crate::prelude::Nat::from(0u32) {
                            ::prism_rtl::Turn::Finished(enter_pg.clone())
                        } else {
                            ::prism_rtl::Turn::Finished(crate::lower::model::Ex::XBlock(dos_pdz.clone(), ::std::rc::Rc::new(enter_pg.clone())))
                        }
                    };
                    match crate::prelude::get(&lx_p0x.lifts_p, &crate::lower::place_key_f(&lx_p0x, &call_p2x.span_p)) {
                        ::std::option::Option::Some(ln_pu) if (&crate::prelude::len(&ln_pu.operands_p) > &crate::prelude::Nat::from(0u32)) => crate::prelude::call_then(start_lifted_frame_f(lx_p0x.clone(), env2_pe.clone(), env3_pf.clone(), c_p5x.clone(), qk_o7.clone(), base_p9.clone(), args_p6x.clone(), call_p2x.clone(), v_pa.clone(), t_pb.clone(), ln_pu.clone(), ln_pu.operands_p.clone(), cont_f4x.clone()), move |lifted_frame_f_37787: crate::lower::model::Ex| k_let37359(lifted_frame_f_37787)),
                        _ => crate::prelude::call_then(start_frame_job_f(lx_p0x.clone(), env2_pe.clone(), c_p5x.clone(), qk_o7.clone(), base_p9.clone(), args_p6x.clone(), call_p2x.clone()), move |frame_job_f_37927: (crate::lower::model::Ex, crate::lower::model::Ref)| {
                            let (job_pv, how_p10) = frame_job_f_37927;
                            crate::prelude::call_value((&cont_f4x)(env3_pf.clone()), move |cont_38042: crate::lower::model::Ex| crate::prelude::call_then(start_frame_taker_f(lx_p0x.clone(), qk_o7.clone(), c_p5x.clone(), call_p2x.clone(), v_pa.clone(), t_pb.clone(), cont_38042), move |frame_taker_f_38006: crate::lower::model::Ex| k_let37359(crate::lower::model::Ex::XCall(how_p10.clone(), crate::prelude::Array::from(vec![job_pv.clone(), frame_taker_f_38006])))))
                        }),
                        _ => unreachable!("no arm matched"),
                    }
                })
            },
            _ => cont_f4(env_p1.clone()).cycle(),
        }
    }
}

/// `Start Frame, x`: what the function value is when passed to `@Run`.
pub fn start_frame_f(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, call_p2: crate::syntax::Expr, rest_reads_p3: crate::prelude::Array<crate::prelude::Text>, cont_f4: ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::types::Env) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>>>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>> {
    ::std::rc::Rc::new(Frame { lx_p0, env_p1, call_p2, rest_reads_p3, cont_f4 })
}

/// ```prism
/// FrameTaker: unbounded fn Lx, ?Text, Expr, Expr, Text, OutTy, Ex -> Ex
/// ```
pub fn frame_taker_f(lx_p0: &crate::lower::Lx, qk_o1: &::std::option::Option<crate::prelude::Text>, c_p2: &crate::syntax::Expr, call_p3: &crate::syntax::Expr, name_p4: &crate::prelude::Text, t_p5: &crate::lower::model::OutTy, rest_p6: &crate::lower::model::Ex) -> crate::lower::model::Ex {
    let signature_o7 = match qk_o1 {
        ::std::option::Option::Some(q_p8) => match crate::prelude::get(&lx_p0.g_p.vals_p, q_p8) {
            ::std::option::Option::Some(callee_p9) => crate::lower::expr::signature_result_o(lx_p0, &callee_p9, &c_p2.span_p, &call_p3.span_p, t_p5),
            ::std::option::Option::None => ::std::option::Option::None,
        },
        ::std::option::Option::None => ::std::option::Option::None,
    };
    match &signature_o7 {
        ::std::option::Option::Some(signature_ty_pa) => {
            let job_pb = crate::prelude::Text::from(format!("{}_job", name_p4));
            let walked_pc = crate::lower::expr::recolored_f(lx_p0, &crate::lower::model::Ex::XVar(job_pb.clone()), signature_ty_pa, &crate::lower::types::peel_f(&crate::lower::subst_ty_f(lx_p0, &crate::lower::type_at_f(lx_p0, &call_p3.span_p))), &crate::prelude::Nat::from(0u32));
            crate::lower::model::Ex::XClosure(true, crate::prelude::Array::from(vec![crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaBind(job_pb.clone())), crate::lower::types::out_ty_of_f(lx_p0, signature_ty_pa))]), ::std::rc::Rc::new(prepend_f(&crate::prelude::Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaBind(name_p4.clone())), t_p5.clone()), walked_pc.clone())]), rest_p6)))
        },
        ::std::option::Option::None => crate::lower::model::Ex::XClosure(true, crate::prelude::Array::from(vec![crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaBind(name_p4.clone())), t_p5.clone())]), ::std::rc::Rc::new(rest_p6.clone())),
    }
}

/// The step machine of `FrameTaker`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FrameTaker: unbounded fn Lx, ?Text, Expr, Expr, Text, OutTy, Ex -> Ex
/// ```
pub struct FrameTaker {
    pub lx_p0: crate::lower::Lx,
    pub qk_o1: ::std::option::Option<crate::prelude::Text>,
    pub c_p2: crate::syntax::Expr,
    pub call_p3: crate::syntax::Expr,
    pub name_p4: crate::prelude::Text,
    pub t_p5: crate::lower::model::OutTy,
    pub rest_p6: crate::lower::model::Ex,
}

impl ::prism_rtl::Job<crate::lower::model::Ex> for FrameTaker {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::lower::model::Ex> {
        let lx_p0 = &self.lx_p0;
        let qk_o1 = &self.qk_o1;
        let c_p2 = &self.c_p2;
        let call_p3 = &self.call_p3;
        let name_p4 = &self.name_p4;
        let t_p5 = &self.t_p5;
        let rest_p6 = &self.rest_p6;
        let call_p3z = call_p3.clone();
        let lx_p0z = lx_p0.clone();
        let name_p4z = name_p4.clone();
        let rest_p6z = rest_p6.clone();
        let t_p5z = t_p5.clone();
        let k_let38644 = move |v38644: ::std::option::Option<crate::check::types::Ty>| {
            let signature_o7 = v38644;
            match &signature_o7 {
                ::std::option::Option::Some(signature_ty_pa) => {
                    let job_pb = crate::prelude::Text::from(format!("{}_job", &name_p4z));
                    let signature_ty_pax = signature_ty_pa.clone();
                    crate::prelude::call_then(crate::lower::expr::start_recolored_f(lx_p0z.clone(), crate::lower::model::Ex::XVar(job_pb.clone()), signature_ty_pax.clone(), crate::lower::types::peel_f(&crate::lower::subst_ty_f(&lx_p0z, &crate::lower::type_at_f(&lx_p0z, &call_p3z.span_p))), crate::prelude::Nat::from(0u32)), move |recolored_f_38920: crate::lower::model::Ex| {
                        let walked_pc = recolored_f_38920;
                        crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0z.clone(), signature_ty_pax.clone()), move |out_ty_of_f_39059: crate::lower::model::OutTy| ::prism_rtl::Turn::Finished(crate::lower::model::Ex::XClosure(true, crate::prelude::Array::from(vec![crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaBind(job_pb.clone())), out_ty_of_f_39059)]), ::std::rc::Rc::new(prepend_f(&crate::prelude::Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaBind(name_p4z.clone())), t_p5z.clone()), walked_pc.clone())]), &rest_p6z)))))
                    })
                },
                ::std::option::Option::None => ::prism_rtl::Turn::Finished(crate::lower::model::Ex::XClosure(true, crate::prelude::Array::from(vec![crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaBind(name_p4z.clone())), t_p5z.clone())]), ::std::rc::Rc::new(rest_p6z.clone()))),
            }
        };
        match qk_o1.clone() {
            ::std::option::Option::Some(q_p8) => match crate::prelude::get(&lx_p0.g_p.vals_p, &q_p8) {
                ::std::option::Option::Some(callee_p9) => {
                    let c_p2x = c_p2.clone();
                    let call_p3x = call_p3.clone();
                    let lx_p0x = lx_p0.clone();
                    let t_p5x = t_p5.clone();
                    crate::prelude::call_then(crate::lower::expr::start_signature_result_o(lx_p0x.clone(), callee_p9.clone(), c_p2x.span_p.clone(), call_p3x.span_p.clone(), t_p5x.clone()), move |signature_result_o_38727: ::std::option::Option<crate::check::types::Ty>| k_let38644(signature_result_o_38727))
                },
                ::std::option::Option::None => k_let38644(::std::option::Option::None),
            },
            ::std::option::Option::None => k_let38644(::std::option::Option::None),
        }
    }
}

/// `Start FrameTaker, x`: what the function value is when passed to `@Run`.
pub fn start_frame_taker_f(lx_p0: crate::lower::Lx, qk_o1: ::std::option::Option<crate::prelude::Text>, c_p2: crate::syntax::Expr, call_p3: crate::syntax::Expr, name_p4: crate::prelude::Text, t_p5: crate::lower::model::OutTy, rest_p6: crate::lower::model::Ex) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>> {
    ::std::rc::Rc::new(FrameTaker { lx_p0, qk_o1, c_p2, call_p3, name_p4, t_p5, rest_p6 })
}

/// ```prism
/// FrameJob: unbounded fn Lx, Env, Expr, ?Text, Text, [Arg], Expr -> ((Ex, Ref))
/// ```
pub fn frame_job_f(lx_p0: &crate::lower::Lx, env2_p1: &crate::lower::types::Env, c_p2: &crate::syntax::Expr, qk_o3: &::std::option::Option<crate::prelude::Text>, base_p4: &crate::prelude::Text, args_p5: &crate::prelude::Array<crate::syntax::Arg>, call_p6: &crate::syntax::Expr) -> (crate::lower::model::Ex, crate::lower::model::Ref) {
    let vals_p7 = match qk_o3 {
        ::std::option::Option::Some(q_p8) => crate::lower::expr::named_args_owned_f(lx_p0, env2_p1, q_p8, args_p5),
        ::std::option::Option::None => match local_job_fn_o(lx_p0, env2_p1, c_p2) {
            ::std::option::Option::Some(f_p9) => crate::lower::expr::start_args_f(lx_p0, env2_p1, &f_p9, args_p5),
            ::std::option::Option::None => crate::prelude::run_to_end(crate::prelude::each_job(args_p5.clone(), {
                let lx_p0x = lx_p0.clone();
                let env2_p1x = env2_p1.clone();
                ::std::rc::Rc::new(move |p0: crate::syntax::Arg| {
                    let lx_p0xy = lx_p0x.clone();
                    let env2_p1xy = env2_p1x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let a_pa = p0;
                        crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p0xy.clone(), env2_p1xy.clone(), a_pa.value_p.clone()), move |value_of_f_39599: crate::lower::types::Vl| ::prism_rtl::Turn::Finished(crate::lower::types::own_f(&value_of_f_39599)))
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::syntax::Arg) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>>>
            })),
        },
    };
    match qk_o3 {
        ::std::option::Option::Some(q_pb) => (start_of_f(lx_p0, q_pb, c_p2, &vals_p7), crate::lower::helper_ref_f(&(if crate::lower::program::enters_at_once_f(lx_p0, q_pb, args_p5) {
            crate::prelude::Text::lit("call_value")
        } else {
            crate::prelude::Text::lit("call_then")
        }))),
        ::std::option::Option::None => match local_job_fn_o(lx_p0, env2_p1, c_p2) {
            ::std::option::Option::Some(f_pc) => (start_call_f(&f_pc, &vals_p7), crate::lower::helper_ref_f(&crate::prelude::Text::lit("call_value"))),
            ::std::option::Option::None => match crate::lower::expr::prelude_job_call_o(lx_p0, env2_p1, call_p6) {
                ::std::option::Option::Some(pj_pd) => (pj_pd, crate::lower::helper_ref_f(&crate::prelude::Text::lit("call_value"))),
                ::std::option::Option::None => (crate::lower::expr::internal_bug_f(&crate::prelude::Text::lit("a call this frame cannot enter")), crate::lower::helper_ref_f(&crate::prelude::Text::lit("call_then"))),
            },
        },
    }
}

/// The step machine of `FrameJob`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FrameJob: unbounded fn Lx, Env, Expr, ?Text, Text, [Arg], Expr -> ((Ex, Ref))
/// ```
pub struct FrameJob {
    pub lx_p0: crate::lower::Lx,
    pub env2_p1: crate::lower::types::Env,
    pub c_p2: crate::syntax::Expr,
    pub qk_o3: ::std::option::Option<crate::prelude::Text>,
    pub base_p4: crate::prelude::Text,
    pub args_p5: crate::prelude::Array<crate::syntax::Arg>,
    pub call_p6: crate::syntax::Expr,
}

impl ::prism_rtl::Job<(crate::lower::model::Ex, crate::lower::model::Ref)> for FrameJob {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::lower::model::Ex, crate::lower::model::Ref)> {
        let lx_p0 = &self.lx_p0;
        let env2_p1 = &self.env2_p1;
        let c_p2 = &self.c_p2;
        let qk_o3 = &self.qk_o3;
        let base_p4 = &self.base_p4;
        let args_p5 = &self.args_p5;
        let call_p6 = &self.call_p6;
        let qk_o3z = qk_o3.clone();
        let args_p5z = args_p5.clone();
        let c_p2z = c_p2.clone();
        let call_p6z = call_p6.clone();
        let env2_p1z = env2_p1.clone();
        let lx_p0z = lx_p0.clone();
        let k_let39404 = move |v39404: crate::prelude::Array<crate::lower::model::Ex>| {
            let vals_p7 = v39404;
            match &qk_o3z {
                ::std::option::Option::Some(q_pb) => {
                    let q_pbx = q_pb.clone();
                    crate::prelude::call_then(start_start_of_f(lx_p0z.clone(), q_pbx.clone(), c_p2z.clone(), vals_p7.clone()), move |start_of_f_39657: crate::lower::model::Ex| ::prism_rtl::Turn::Finished((start_of_f_39657, crate::lower::helper_ref_f(&(if crate::lower::program::enters_at_once_f(&lx_p0z, &q_pbx, &args_p5z) {
                        crate::prelude::Text::lit("call_value")
                    } else {
                        crate::prelude::Text::lit("call_then")
                    })))))
                },
                ::std::option::Option::None => crate::prelude::call_then(start_local_job_fn_o(lx_p0z.clone(), env2_p1z.clone(), c_p2z.clone()), move |local_job_fn_o_39777: ::std::option::Option<crate::lower::types::Vl>| match local_job_fn_o_39777 {
                    ::std::option::Option::Some(f_pc) => ::prism_rtl::Turn::Finished((start_call_f(&f_pc, &vals_p7), crate::lower::helper_ref_f(&crate::prelude::Text::lit("call_value")))),
                    ::std::option::Option::None => crate::prelude::call_then(crate::lower::expr::start_prelude_job_call_o(lx_p0z.clone(), env2_p1z.clone(), call_p6z.clone()), move |prelude_job_call_o_39892: ::std::option::Option<crate::lower::model::Ex>| match prelude_job_call_o_39892 {
                        ::std::option::Option::Some(pj_pd) => ::prism_rtl::Turn::Finished((pj_pd.clone(), crate::lower::helper_ref_f(&crate::prelude::Text::lit("call_value")))),
                        ::std::option::Option::None => ::prism_rtl::Turn::Finished((crate::lower::expr::internal_bug_f(&crate::prelude::Text::lit("a call this frame cannot enter")), crate::lower::helper_ref_f(&crate::prelude::Text::lit("call_then")))),
                    }),
                }),
            }
        };
        match qk_o3.clone() {
            ::std::option::Option::Some(q_p8) => {
                let args_p5x = args_p5.clone();
                let env2_p1x = env2_p1.clone();
                let lx_p0x = lx_p0.clone();
                crate::prelude::call_then(crate::lower::expr::start_named_args_owned_f(lx_p0x.clone(), env2_p1x.clone(), q_p8.clone(), args_p5x.clone()), move |named_args_owned_f_39439: crate::prelude::Array<crate::lower::model::Ex>| k_let39404(named_args_owned_f_39439))
            },
            ::std::option::Option::None => {
                let args_p5x = args_p5.clone();
                let c_p2x = c_p2.clone();
                let env2_p1x = env2_p1.clone();
                let lx_p0x = lx_p0.clone();
                crate::prelude::call_then(start_local_job_fn_o(lx_p0x.clone(), env2_p1x.clone(), c_p2x.clone()), move |local_job_fn_o_39491: ::std::option::Option<crate::lower::types::Vl>| match local_job_fn_o_39491 {
                    ::std::option::Option::Some(f_p9) => crate::prelude::call_then(crate::lower::expr::start_start_args_f(lx_p0x.clone(), env2_p1x.clone(), f_p9.clone(), args_p5x.clone()), move |start_args_f_39533: crate::prelude::Array<crate::lower::model::Ex>| k_let39404(start_args_f_39533)),
                    ::std::option::Option::None => crate::prelude::call_value(crate::prelude::each_job(args_p5x.clone(), {
                        let lx_p0xx = lx_p0x.clone();
                        let env2_p1xx = env2_p1x.clone();
                        ::std::rc::Rc::new(move |p0: crate::syntax::Arg| {
                            let lx_p0xxy = lx_p0xx.clone();
                            let env2_p1xxy = env2_p1xx.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let a_pa = p0;
                                crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p0xxy.clone(), env2_p1xxy.clone(), a_pa.value_p.clone()), move |value_of_f_39599: crate::lower::types::Vl| ::prism_rtl::Turn::Finished(crate::lower::types::own_f(&value_of_f_39599)))
                            }))
                        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::syntax::Arg) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>>>
                    }), move |each_39578: crate::prelude::Array<crate::lower::model::Ex>| k_let39404(each_39578)),
                })
            },
        }
    }
}

/// `Start FrameJob, x`: what the function value is when passed to `@Run`.
pub fn start_frame_job_f(lx_p0: crate::lower::Lx, env2_p1: crate::lower::types::Env, c_p2: crate::syntax::Expr, qk_o3: ::std::option::Option<crate::prelude::Text>, base_p4: crate::prelude::Text, args_p5: crate::prelude::Array<crate::syntax::Arg>, call_p6: crate::syntax::Expr) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::lower::model::Ex, crate::lower::model::Ref)>> {
    ::std::rc::Rc::new(FrameJob { lx_p0, env2_p1, c_p2, qk_o3, base_p4, args_p5, call_p6 })
}

/// ```prism
/// LiftedFrame: unbounded fn Lx, Env, Env, Expr, ?Text, Text, [Arg], Expr, Text, OutTy, LiftNote, [Range], (unbounded fn Env -> Ex) -> Ex
/// ```
pub fn lifted_frame_f(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, env3_p2: &crate::lower::types::Env, c_p3: &crate::syntax::Expr, qk_o4: &::std::option::Option<crate::prelude::Text>, base_p5: &crate::prelude::Text, args_p6: &crate::prelude::Array<crate::syntax::Arg>, call_p7: &crate::syntax::Expr, v_p8: &crate::prelude::Text, t_p9: &crate::lower::model::OutTy, ln_pa: &crate::check::typed::LiftNote, operands_pb: &crate::prelude::Array<crate::syntax::Range>, cont_fc: &::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::types::Env) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>>>) -> crate::lower::model::Ex {
    match operands_pb {
        m40625_0 if (m40625_0.len() == 0) => {
            let inner_pd = crate::lower::types::out_ty_of_f(lx_p0, &crate::lower::patterns::inner_ty_f(&crate::lower::type_at_f(lx_p0, &call_p7.span_p)));
            let lx_in_pe = {
                let mut this: crate::lower::Lx = lx_p0.clone();
                this.tys_p = crate::prelude::insert(&this.tys_p, &crate::lower::place_key_f(lx_p0, &call_p7.span_p), &crate::lower::patterns::inner_ty_f(&crate::lower::type_at_f(lx_p0, &call_p7.span_p)));
                this.lifts_p = crate::prelude::insert(&this.lifts_p, &crate::lower::place_key_f(lx_p0, &call_p7.span_p), &crate::check::typed::LiftNote { at_p: ln_pa.at_p.clone(), sigil_p: ln_pa.sigil_p.clone(), operands_p: crate::prelude::Array::new() });
                this
            };
            let lx_ops_pf = crate::prelude::fold(&ln_pa.operands_p, &lx_in_pe, &(|l_ph: &crate::lower::Lx, r_pi: &crate::syntax::Range| {
                let mut this: crate::lower::Lx = l_ph.clone();
                this.tys_p = crate::prelude::insert(&this.tys_p, &crate::lower::place_key_f(lx_p0, r_pi), &crate::lower::patterns::inner_ty_f(&crate::lower::type_at_f(lx_p0, r_pi)));
                this
            }));
            let (job_pj, how_pk) = frame_job_f(&lx_ops_pf, env_p1, c_p3, qk_o4, base_p5, args_p6, call_p7);
            let wrapped_pg = crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(if &ln_pa.sigil_p == &crate::prelude::Text::lit("~") {
                crate::prelude::Text::lit("std::Ok")
            } else {
                crate::prelude::Text::lit("std::Some")
            }), crate::prelude::Array::from(vec![crate::lower::model::Ex::XVar(crate::prelude::Text::from(format!("{}_in", v_p8)))]));
            crate::lower::model::Ex::XCall(how_pk.clone(), crate::prelude::Array::from(vec![job_pj.clone(), frame_taker_f(&lx_in_pe, qk_o4, c_p3, call_p7, &crate::prelude::Text::from(format!("{}_in", v_p8)), &inner_pd, &prepend_f(&crate::prelude::Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaBind(v_p8.clone())), t_p9.clone()), wrapped_pg.clone())]), &crate::prelude::run_to_end(cont_fc(env3_p2.clone()))))]))
        },
        _ => {
            let r_pl = crate::prelude::or(&crate::prelude::index(operands_pb, &crate::prelude::Nat::from(0u32)), &call_p7.span_p);
            let sv_pm = crate::lower::expr::value_of_f(lx_p0, env_p1, &crate::prelude::or(&crate::lower::expr::operand_at_o(call_p7, &r_pl), &crate::lower::expr::dummy_expr_p()));
            let it_pn = crate::lower::types::out_ty_of_f(lx_p0, &crate::lower::patterns::inner_ty_f(&crate::lower::type_at_f(lx_p0, &r_pl)));
            let owned_po = match &sv_pm {
                crate::lower::types::Vl::VlOwned(_, _) => true,
                _ => false,
            };
            let mode_pp = if owned_po {
                crate::lower::types::Holding::Owned
            } else {
                crate::lower::types::Holding::ByRef
            };
            let x_pq = crate::prelude::Text::from(format!("o{}_{}", &r_pl.start_p, &r_pl.end_p));
            let env2_pr = crate::lower::types::bind_span_f(env_p1, &crate::lower::place_key_f(lx_p0, &r_pl), &crate::lower::types::Vl::VlPlace(crate::lower::model::Ex::XVar(x_pq.clone()), mode_pp.clone(), it_pn.clone()));
            let present_ps = lifted_frame_f(lx_p0, &env2_pr, env3_p2, c_p3, qk_o4, base_p5, args_p6, call_p7, v_p8, t_p9, ln_pa, &crate::prelude::drop(operands_pb, &crate::prelude::Nat::from(1u32)), &cont_fc.clone());
            let absent_pt = if &ln_pa.sigil_p == &crate::prelude::Text::lit("~") {
                crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Err")), crate::prelude::Array::from(vec![crate::lower::types::own_f(&crate::lower::types::Vl::VlPlace(crate::lower::model::Ex::XVar(crate::prelude::Text::from(format!("{}_e", &x_pq))), mode_pp.clone(), crate::lower::model::OutTy::OutError))]))
            } else {
                crate::lower::model::Ex::XTyped(::std::rc::Rc::new(crate::lower::model::Ex::XNone), t_p9.clone())
            };
            let fail_arm_pu = crate::lower::model::XArm { pat_p: if &ln_pa.sigil_p == &crate::prelude::Text::lit("~") {
                crate::lower::model::Pa::PaCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Err")), crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(crate::prelude::Text::from(format!("{}_e", &x_pq)))]))
            } else {
                crate::lower::model::Pa::PaUnit(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::None")))
            }, conds_p: crate::prelude::Array::new(), body_p: crate::lower::model::Ex::XBlock(crate::prelude::Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaBind(v_p8.clone())), t_p9.clone()), absent_pt.clone())]), ::std::rc::Rc::new(crate::prelude::run_to_end(cont_fc(env3_p2.clone())))) };
            let arms_pv = crate::prelude::Array::from(vec![crate::lower::model::XArm { pat_p: crate::lower::model::Pa::PaCtor(crate::lower::model::Ref::RefRuntime(if &ln_pa.sigil_p == &crate::prelude::Text::lit("~") {
                crate::prelude::Text::lit("std::Ok")
            } else {
                crate::prelude::Text::lit("std::Some")
            }), crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(x_pq.clone())])), conds_p: crate::prelude::Array::new(), body_p: present_ps.clone() }, fail_arm_pu.clone()]);
            crate::lower::model::Ex::XMatch(::std::rc::Rc::new(if owned_po {
                crate::lower::types::own_f(&sv_pm)
            } else {
                crate::lower::types::ref_f(&sv_pm)
            }), arms_pv.clone(), false, crate::lower::model::OutTy::OutTurn)
        },
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `LiftedFrame`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LiftedFrame: unbounded fn Lx, Env, Env, Expr, ?Text, Text, [Arg], Expr, Text, OutTy, LiftNote, [Range], (unbounded fn Env -> Ex) -> Ex
/// ```
pub struct LiftedFrame {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub env3_p2: crate::lower::types::Env,
    pub c_p3: crate::syntax::Expr,
    pub qk_o4: ::std::option::Option<crate::prelude::Text>,
    pub base_p5: crate::prelude::Text,
    pub args_p6: crate::prelude::Array<crate::syntax::Arg>,
    pub call_p7: crate::syntax::Expr,
    pub v_p8: crate::prelude::Text,
    pub t_p9: crate::lower::model::OutTy,
    pub ln_pa: crate::check::typed::LiftNote,
    pub operands_pb: crate::prelude::Array<crate::syntax::Range>,
    pub cont_fc: ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::types::Env) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>>>,
}

impl ::prism_rtl::Job<crate::lower::model::Ex> for LiftedFrame {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::lower::model::Ex> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let env3_p2 = &self.env3_p2;
        let c_p3 = &self.c_p3;
        let qk_o4 = &self.qk_o4;
        let base_p5 = &self.base_p5;
        let args_p6 = &self.args_p6;
        let call_p7 = &self.call_p7;
        let v_p8 = &self.v_p8;
        let t_p9 = &self.t_p9;
        let ln_pa = &self.ln_pa;
        let operands_pb = &self.operands_pb;
        let cont_fc = &self.cont_fc;
        match operands_pb {
            m40625_0 if (m40625_0.len() == 0) => {
                let qk_o4x = qk_o4.clone();
                let cont_fcx = cont_fc.clone();
                let args_p6x = args_p6.clone();
                let base_p5x = base_p5.clone();
                let c_p3x = c_p3.clone();
                let call_p7x = call_p7.clone();
                let env_p1x = env_p1.clone();
                let env3_p2x = env3_p2.clone();
                let ln_pax = ln_pa.clone();
                let lx_p0x = lx_p0.clone();
                let t_p9x = t_p9.clone();
                let v_p8x = v_p8.clone();
                crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0x.clone(), crate::lower::patterns::inner_ty_f(&crate::lower::type_at_f(&lx_p0x, &call_p7x.span_p))), move |out_ty_of_f_40671: crate::lower::model::OutTy| {
                    let inner_pd = out_ty_of_f_40671;
                    let lx_in_pe = {
                        let mut this: crate::lower::Lx = lx_p0x.clone();
                        this.tys_p = crate::prelude::insert(&this.tys_p, &crate::lower::place_key_f(&lx_p0x, &call_p7x.span_p), &crate::lower::patterns::inner_ty_f(&crate::lower::type_at_f(&lx_p0x, &call_p7x.span_p)));
                        this.lifts_p = crate::prelude::insert(&this.lifts_p, &crate::lower::place_key_f(&lx_p0x, &call_p7x.span_p), &crate::check::typed::LiftNote { at_p: ln_pax.at_p.clone(), sigil_p: ln_pax.sigil_p.clone(), operands_p: crate::prelude::Array::new() });
                        this
                    };
                    let lx_ops_pf = crate::prelude::fold(&ln_pax.operands_p, &lx_in_pe, &(|l_ph: &crate::lower::Lx, r_pi: &crate::syntax::Range| {
                        let mut this: crate::lower::Lx = l_ph.clone();
                        this.tys_p = crate::prelude::insert(&this.tys_p, &crate::lower::place_key_f(&lx_p0x, r_pi), &crate::lower::patterns::inner_ty_f(&crate::lower::type_at_f(&lx_p0x, r_pi)));
                        this
                    }));
                    crate::prelude::call_then(start_frame_job_f(lx_ops_pf.clone(), env_p1x.clone(), c_p3x.clone(), qk_o4x.clone(), base_p5x.clone(), args_p6x.clone(), call_p7x.clone()), move |frame_job_f_41128: (crate::lower::model::Ex, crate::lower::model::Ref)| {
                        let (job_pj, how_pk) = frame_job_f_41128;
                        let wrapped_pg = crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(if &ln_pax.sigil_p == &crate::prelude::Text::lit("~") {
                            crate::prelude::Text::lit("std::Ok")
                        } else {
                            crate::prelude::Text::lit("std::Some")
                        }), crate::prelude::Array::from(vec![crate::lower::model::Ex::XVar(crate::prelude::Text::from(format!("{}_in", &v_p8x)))]));
                        crate::prelude::call_value((&cont_fcx)(env3_p2x.clone()), move |cont_41417: crate::lower::model::Ex| crate::prelude::call_then(start_frame_taker_f(lx_in_pe.clone(), qk_o4x.clone(), c_p3x.clone(), call_p7x.clone(), crate::prelude::Text::from(format!("{}_in", &v_p8x)), inner_pd.clone(), prepend_f(&crate::prelude::Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaBind(v_p8x.clone())), t_p9x.clone()), wrapped_pg.clone())]), &cont_41417)), move |frame_taker_f_41313: crate::lower::model::Ex| ::prism_rtl::Turn::Finished(crate::lower::model::Ex::XCall(how_pk.clone(), crate::prelude::Array::from(vec![job_pj.clone(), frame_taker_f_41313])))))
                    })
                })
            },
            _ => {
                let r_pl = crate::prelude::or(&crate::prelude::index(operands_pb, &crate::prelude::Nat::from(0u32)), &call_p7.span_p);
                let qk_o4x = qk_o4.clone();
                let cont_fcx = cont_fc.clone();
                let args_p6x = args_p6.clone();
                let base_p5x = base_p5.clone();
                let c_p3x = c_p3.clone();
                let call_p7x = call_p7.clone();
                let env_p1x = env_p1.clone();
                let env3_p2x = env3_p2.clone();
                let ln_pax = ln_pa.clone();
                let lx_p0x = lx_p0.clone();
                let operands_pbx = operands_pb.clone();
                let t_p9x = t_p9.clone();
                let v_p8x = v_p8.clone();
                crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p0x.clone(), env_p1x.clone(), crate::prelude::or(&crate::lower::expr::operand_at_o(&call_p7x, &r_pl), &crate::lower::expr::dummy_expr_p())), move |value_of_f_41506: crate::lower::types::Vl| {
                    let sv_pm = value_of_f_41506;
                    crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0x.clone(), crate::lower::patterns::inner_ty_f(&crate::lower::type_at_f(&lx_p0x, &r_pl))), move |out_ty_of_f_41577: crate::lower::model::OutTy| {
                        let it_pn = out_ty_of_f_41577;
                        let owned_po = match &sv_pm {
                            crate::lower::types::Vl::VlOwned(_, _) => true,
                            _ => false,
                        };
                        let mode_pp = if owned_po {
                            crate::lower::types::Holding::Owned
                        } else {
                            crate::lower::types::Holding::ByRef
                        };
                        let x_pq = crate::prelude::Text::from(format!("o{}_{}", &r_pl.start_p, &r_pl.end_p));
                        let env2_pr = crate::lower::types::bind_span_f(&env_p1x, &crate::lower::place_key_f(&lx_p0x, &r_pl), &crate::lower::types::Vl::VlPlace(crate::lower::model::Ex::XVar(x_pq.clone()), mode_pp.clone(), it_pn.clone()));
                        crate::prelude::call_then(start_lifted_frame_f(lx_p0x.clone(), env2_pr.clone(), env3_p2x.clone(), c_p3x.clone(), qk_o4x.clone(), base_p5x.clone(), args_p6x.clone(), call_p7x.clone(), v_p8x.clone(), t_p9x.clone(), ln_pax.clone(), crate::prelude::drop(&operands_pbx, &crate::prelude::Nat::from(1u32)), cont_fcx.clone()), move |lifted_frame_f_41900: crate::lower::model::Ex| {
                            let present_ps = lifted_frame_f_41900;
                            let absent_pt = if &ln_pax.sigil_p == &crate::prelude::Text::lit("~") {
                                crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Err")), crate::prelude::Array::from(vec![crate::lower::types::own_f(&crate::lower::types::Vl::VlPlace(crate::lower::model::Ex::XVar(crate::prelude::Text::from(format!("{}_e", &x_pq))), mode_pp.clone(), crate::lower::model::OutTy::OutError))]))
                            } else {
                                crate::lower::model::Ex::XTyped(::std::rc::Rc::new(crate::lower::model::Ex::XNone), t_p9x.clone())
                            };
                            crate::prelude::call_value((&cont_fcx)(env3_p2x.clone()), move |cont_42348: crate::lower::model::Ex| {
                                let fail_arm_pu = crate::lower::model::XArm { pat_p: if &ln_pax.sigil_p == &crate::prelude::Text::lit("~") {
                                    crate::lower::model::Pa::PaCtor(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::Err")), crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(crate::prelude::Text::from(format!("{}_e", &x_pq)))]))
                                } else {
                                    crate::lower::model::Pa::PaUnit(crate::lower::model::Ref::RefRuntime(crate::prelude::Text::lit("std::None")))
                                }, conds_p: crate::prelude::Array::new(), body_p: crate::lower::model::Ex::XBlock(crate::prelude::Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(::std::rc::Rc::new(crate::lower::model::Pa::PaBind(v_p8x.clone())), t_p9x.clone()), absent_pt.clone())]), ::std::rc::Rc::new(cont_42348)) };
                                let arms_pv = crate::prelude::Array::from(vec![crate::lower::model::XArm { pat_p: crate::lower::model::Pa::PaCtor(crate::lower::model::Ref::RefRuntime(if &ln_pax.sigil_p == &crate::prelude::Text::lit("~") {
                                    crate::prelude::Text::lit("std::Ok")
                                } else {
                                    crate::prelude::Text::lit("std::Some")
                                }), crate::prelude::Array::from(vec![crate::lower::model::Pa::PaBind(x_pq.clone())])), conds_p: crate::prelude::Array::new(), body_p: present_ps.clone() }, fail_arm_pu.clone()]);
                                ::prism_rtl::Turn::Finished(crate::lower::model::Ex::XMatch(::std::rc::Rc::new(if owned_po {
                                    crate::lower::types::own_f(&sv_pm)
                                } else {
                                    crate::lower::types::ref_f(&sv_pm)
                                }), arms_pv.clone(), false, crate::lower::model::OutTy::OutTurn))
                            })
                        })
                    })
                })
            },
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start LiftedFrame, x`: what the function value is when passed to `@Run`.
pub fn start_lifted_frame_f(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, env3_p2: crate::lower::types::Env, c_p3: crate::syntax::Expr, qk_o4: ::std::option::Option<crate::prelude::Text>, base_p5: crate::prelude::Text, args_p6: crate::prelude::Array<crate::syntax::Arg>, call_p7: crate::syntax::Expr, v_p8: crate::prelude::Text, t_p9: crate::lower::model::OutTy, ln_pa: crate::check::typed::LiftNote, operands_pb: crate::prelude::Array<crate::syntax::Range>, cont_fc: ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::types::Env) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>>>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>> {
    ::std::rc::Rc::new(LiftedFrame { lx_p0, env_p1, env3_p2, c_p3, qk_o4, base_p5, args_p6, call_p7, v_p8, t_p9, ln_pa, operands_pb, cont_fc })
}

/// ```prism
/// ?LocalJobFn: unbounded fn Lx, Env, Expr -> ?Vl
/// ```
pub fn local_job_fn_o(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, c_p2: &crate::syntax::Expr) -> ::std::option::Option<crate::lower::types::Vl> {
    match &*c_p2.kind_p {
        crate::syntax::ExprKind::EName(n_p3) => if (&crate::prelude::len(&n_p3.path_p) == &crate::prelude::Nat::from(1u32)) && crate::check::env::has_key_f(&env_p1.names_p, &crate::check::env::sname_key_f(n_p3)) {
            job_value_o(&crate::lower::expr::name_value_f(lx_p0, env_p1, n_p3, &c_p2.span_p))
        } else {
            ::std::option::Option::None
        },
        crate::syntax::ExprKind::EGroup(x_p4) => local_job_fn_o(lx_p0, env_p1, &**x_p4),
        crate::syntax::ExprKind::EField(_, _, _) => job_value_o(&crate::lower::expr::value_of_f(lx_p0, env_p1, c_p2)),
        _ => ::std::option::Option::None,
    }
}

/// The step machine of `LocalJobFn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?LocalJobFn: unbounded fn Lx, Env, Expr -> ?Vl
/// ```
pub struct LocalJobFn {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub c_p2: crate::syntax::Expr,
}

impl ::prism_rtl::Job<::std::option::Option<crate::lower::types::Vl>> for LocalJobFn {
    fn cycle(&self) -> ::prism_rtl::Turn<::std::option::Option<crate::lower::types::Vl>> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let c_p2 = &self.c_p2;
        match &*c_p2.kind_p {
            crate::syntax::ExprKind::EName(n_p3) => if (&crate::prelude::len(&n_p3.path_p) == &crate::prelude::Nat::from(1u32)) && crate::check::env::has_key_f(&env_p1.names_p, &crate::check::env::sname_key_f(n_p3)) {
                {
                    let c_p2x = c_p2.clone();
                    let env_p1x = env_p1.clone();
                    let lx_p0x = lx_p0.clone();
                    let n_p3x = n_p3.clone();
                    crate::prelude::call_then(crate::lower::expr::start_name_value_f(lx_p0x.clone(), env_p1x.clone(), n_p3x.clone(), c_p2x.span_p.clone()), move |name_value_f_42844: crate::lower::types::Vl| ::prism_rtl::Turn::Finished(job_value_o(&name_value_f_42844)))
                }
            } else {
                ::prism_rtl::Turn::Finished(::std::option::Option::None)
            },
            crate::syntax::ExprKind::EGroup(x_p4) => ::prism_rtl::Turn::More(::std::rc::Rc::new(LocalJobFn { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), c_p2: (**x_p4).clone() })),
            crate::syntax::ExprKind::EField(_, _, _) => {
                let c_p2x = c_p2.clone();
                let env_p1x = env_p1.clone();
                let lx_p0x = lx_p0.clone();
                crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p0x.clone(), env_p1x.clone(), c_p2x.clone()), move |value_of_f_42975: crate::lower::types::Vl| ::prism_rtl::Turn::Finished(job_value_o(&value_of_f_42975)))
            },
            _ => ::prism_rtl::Turn::Finished(::std::option::Option::None),
        }
    }
}

/// `Start LocalJobFn, x`: what the function value is when passed to `@Run`.
pub fn start_local_job_fn_o(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, c_p2: crate::syntax::Expr) -> ::std::rc::Rc<dyn ::prism_rtl::Job<::std::option::Option<crate::lower::types::Vl>>> {
    ::std::rc::Rc::new(LocalJobFn { lx_p0, env_p1, c_p2 })
}

/// ```prism
/// ?JobValue: fn Vl -> ?Vl
/// ```
pub fn job_value_o(f_p0: &crate::lower::types::Vl) -> ::std::option::Option<crate::lower::types::Vl> {
    match crate::lower::types::value_ty_f(f_p0) {
        crate::lower::model::OutTy::OutJobFn(_, _) => ::std::option::Option::Some(f_p0.clone()),
        _ => ::std::option::Option::None,
    }
}

/// ```prism
/// StartCall: fn Vl, [Ex] -> Ex
/// ```
pub fn start_call_f(f_p0: &crate::lower::types::Vl, vals_p1: &crate::prelude::Array<crate::lower::model::Ex>) -> crate::lower::model::Ex {
    crate::lower::model::Ex::XApply(::std::rc::Rc::new(crate::lower::types::ref_f(f_p0)), crate::prelude::Array::from(vec![one_or_tuple_f(vals_p1)]))
}

/// ```prism
/// OneOrTuple: fn [Ex] -> Ex
/// ```
pub fn one_or_tuple_f(xs0: &crate::prelude::Array<crate::lower::model::Ex>) -> crate::lower::model::Ex {
    'c: {
        if let c0_0 = xs0 && (c0_0.len() == 1) && let ::std::option::Option::Some(one_p0) = crate::prelude::index(c0_0, &crate::prelude::Nat::from(0u32)) {
            break 'c one_p0.clone();
        }
        if let vals_p1 = xs0 {
            break 'c crate::lower::model::Ex::XTuple(vals_p1.clone());
        }
        unreachable!("no clause matched")
    }
}

/// ```prism
/// CalleeText: fn Expr -> Text
/// ```
pub fn callee_text_f(c_p0: &crate::syntax::Expr) -> crate::prelude::Text {
    match &*c_p0.kind_p {
        crate::syntax::ExprKind::EName(n_p1) => crate::check::env::dotted_f(&n_p1.path_p),
        crate::syntax::ExprKind::EGroup(x_p2) => callee_text_f(&**x_p2),
        _ => crate::prelude::Text::lit("call"),
    }
}

/// ```prism
/// RestReads: fn Lx, Range, Range, Range -> [Text]
/// ```
pub fn rest_reads_f(lx_p0: &crate::lower::Lx, from_p1: &crate::syntax::Range, call_p2: &crate::syntax::Range, to_p3: &crate::syntax::Range) -> crate::prelude::Array<crate::prelude::Text> {
    reads_in_f(lx_p0, &crate::syntax::Range { start_p: from_p1.start_p.clone(), end_p: to_p3.end_p.clone() })
}

/// ```prism
/// ReadsIn: fn Lx, Range -> [Text]
/// ```
pub fn reads_in_f(lx_p0: &crate::lower::Lx, r_p1: &crate::syntax::Range) -> crate::prelude::Array<crate::prelude::Text> {
    crate::prelude::fold(&crate::prelude::or(&crate::prelude::get(&lx_p0.use_names_p, &lx_p0.file_p), &crate::prelude::Array::new()), &crate::prelude::Array::new(), &(|acc_p2: &crate::prelude::Array<crate::prelude::Text>, (at_p3, n_p4): &(crate::prelude::Nat, crate::prelude::Text)| if ((at_p3 >= &r_p1.start_p) && (at_p3 < &r_p1.end_p)) && !crate::check::types::has_text_f(acc_p2, n_p4) {
        crate::prelude::push(acc_p2, n_p4)
    } else {
        acc_p2.clone()
    }))
}

/// ```prism
/// Reads: fn [Text], Text -> Bool
/// ```
pub fn reads_f(reads_p0: &crate::prelude::Array<crate::prelude::Text>, k_p1: &crate::prelude::Text) -> bool {
    let base_p2 = crate::syntax::lexer::chars::drop_prefix_f(&instance_of_f(k_p1), &crate::check::types::unify::marks_of_f(k_p1));
    crate::prelude::fold(reads_p0, &false, &(|found_p3: &bool, n_p4: &crate::prelude::Text| *found_p3 || (&crate::syntax::lexer::chars::drop_prefix_f(n_p4, &crate::check::types::unify::marks_of_f(n_p4)) == &base_p2)))
}

/// ```prism
/// TailBody: unbounded fn Lx, Env, FnBody -> Ex
/// ```
pub fn tail_body_f(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, fn_body2: &crate::syntax::decls::FnBody) -> crate::lower::model::Ex {
    match fn_body2 {
        crate::syntax::decls::FnBody::BodyExpr(x_p2) => tail_f(lx_p0, env_p1, x_p2),
        crate::syntax::decls::FnBody::BodyBlock(b_p5) => tail_block_f(lx_p0, env_p1, b_p5),
    }
}

/// The step machine of `TailBody`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TailBody: unbounded fn Lx, Env, FnBody -> Ex
/// ```
pub struct TailBody {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub fn_body2: crate::syntax::decls::FnBody,
}

impl ::prism_rtl::Job<crate::lower::model::Ex> for TailBody {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::lower::model::Ex> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let fn_body2 = &self.fn_body2;
        match fn_body2 {
            crate::syntax::decls::FnBody::BodyExpr(x_p2) => ::prism_rtl::Turn::More(::std::rc::Rc::new(Tail { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), e_p2: x_p2.clone() })),
            crate::syntax::decls::FnBody::BodyBlock(b_p5) => ::prism_rtl::Turn::More(::std::rc::Rc::new(TailBlock { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), b_p2: b_p5.clone() })),
        }
    }
}

/// `Start TailBody, x`: what the function value is when passed to `@Run`.
pub fn start_tail_body_f(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, fn_body2: crate::syntax::decls::FnBody) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>> {
    ::std::rc::Rc::new(TailBody { lx_p0, env_p1, fn_body2 })
}

/// ```prism
/// TailMatch: unbounded fn Lx, Env, Expr, [Arm], Range -> Ex
/// ```
pub fn tail_match_f(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, s_p2: &crate::syntax::Expr, arms_p3: &crate::prelude::Array<crate::syntax::Arm>, span_p4: &crate::syntax::Range) -> crate::lower::model::Ex {
    let sv_p5 = crate::lower::expr::value_of_f(lx_p0, env_p1, s_p2);
    let sty_p6 = crate::lower::type_at_f(lx_p0, &s_p2.span_p);
    let label_p7 = crate::prelude::Text::from(format!("m{}", &span_p4.start_p));
    let by_ref_p8 = crate::prelude::run_to_end(crate::prelude::each_job(crate::check::errors::range0_f(&crate::prelude::len(arms_p3)), {
        let lx_p0x = lx_p0.clone();
        let arms_p3x = arms_p3.clone();
        let sty_p6x = sty_p6.clone();
        let label_p7x = label_p7.clone();
        ::std::rc::Rc::new(move |p0: crate::prelude::Nat| {
            let lx_p0xy = lx_p0x.clone();
            let arms_p3xy = arms_p3x.clone();
            let sty_p6xy = sty_p6x.clone();
            let label_p7xy = label_p7x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let i_pe = p0;
                ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::lower::expr::ArmPat { lx_p0: lx_p0xy.clone(), opt1: crate::prelude::or(&crate::prelude::index(&arms_p3xy, &i_pe), &crate::lower::expr::dummy_arm_p()).pattern_o.clone(), ty_p2: sty_p6xy.clone(), mode_p3: crate::lower::types::Holding::ByRef, fresh_p4: crate::prelude::Text::from(format!("{}_{}", &label_p7xy, &i_pe)) }))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::patterns::PatOut>>>
    }));
    let chain_p9 = crate::prelude::fold(&by_ref_p8, &false, &(|f_pf: &bool, po_pg: &crate::lower::patterns::PatOut| *f_pf || crate::prelude::fold(&po_pg.conds_p, &false, &(|f2_ph: &bool, c_pi: &crate::lower::model::Cc| *f2_ph || crate::lower::expr::is_let_cond_f(c_pi)))));
    let owned_pa = match &sv_p5 {
        crate::lower::types::Vl::VlOwned(_, _) => !chain_p9,
        _ => false,
    };
    let pats_pb = if owned_pa {
        crate::prelude::run_to_end(crate::prelude::each_job(crate::check::errors::range0_f(&crate::prelude::len(arms_p3)), {
            let lx_p0x = lx_p0.clone();
            let arms_p3x = arms_p3.clone();
            let sty_p6x = sty_p6.clone();
            let label_p7x = label_p7.clone();
            ::std::rc::Rc::new(move |p0: crate::prelude::Nat| {
                let lx_p0xy = lx_p0x.clone();
                let arms_p3xy = arms_p3x.clone();
                let sty_p6xy = sty_p6x.clone();
                let label_p7xy = label_p7x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let i_pj = p0;
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::lower::expr::ArmPat { lx_p0: lx_p0xy.clone(), opt1: crate::prelude::or(&crate::prelude::index(&arms_p3xy, &i_pj), &crate::lower::expr::dummy_arm_p()).pattern_o.clone(), ty_p2: sty_p6xy.clone(), mode_p3: crate::lower::types::Holding::Owned, fresh_p4: crate::prelude::Text::from(format!("{}_{}", &label_p7xy, &i_pj)) }))
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::patterns::PatOut>>>
        }))
    } else {
        by_ref_p8.clone()
    };
    let xarms_pc = crate::prelude::run_to_end(crate::prelude::each_job(crate::check::errors::range0_f(&crate::prelude::len(arms_p3)), {
        let arms_p3x = arms_p3.clone();
        let pats_pbx = pats_pb.clone();
        let env_p1x = env_p1.clone();
        let lx_p0x = lx_p0.clone();
        ::std::rc::Rc::new(move |p0: crate::prelude::Nat| {
            let arms_p3xy = arms_p3x.clone();
            let pats_pbxy = pats_pbx.clone();
            let env_p1xy = env_p1x.clone();
            let lx_p0xy = lx_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let i_pk = p0;
                {
                    let arm_pl = crate::prelude::or(&crate::prelude::index(&arms_p3xy, &i_pk), &crate::lower::expr::dummy_arm_p());
                    let po_pm = crate::prelude::or(&crate::prelude::index(&pats_pbxy, &i_pk), &crate::lower::patterns::PatOut { pa_p: crate::lower::model::Pa::PaWild, conds_p: crate::prelude::Array::new(), binds_p: crate::prelude::Array::new() });
                    let env2_pn = crate::lower::expr::bind_all_f(&env_p1xy, &po_pm.binds_p);
                    crate::prelude::call_then(crate::lower::templates::start_guard_conds_f(lx_p0xy.clone(), env2_pn.clone(), arm_pl.guard_o.clone()), move |guard_conds_f_45473: crate::prelude::Array<crate::lower::model::Cc>| crate::prelude::call_then(start_tail_block_f(lx_p0xy.clone(), env2_pn.clone(), arm_pl.body_p.clone()), move |tail_block_f_45514: crate::lower::model::Ex| ::prism_rtl::Turn::Finished(crate::lower::model::XArm { pat_p: po_pm.pa_p.clone(), conds_p: crate::prelude::append(&po_pm.conds_p, &guard_conds_f_45473), body_p: tail_block_f_45514 })))
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::XArm>>>
    }));
    let scrut_pd = if owned_pa {
        crate::lower::types::own_f(&sv_p5)
    } else {
        crate::lower::types::ref_f(&sv_p5)
    };
    crate::lower::types::own_f(&crate::lower::expr::arms_value_f(&scrut_pd, &xarms_pc, &crate::prelude::Text::from(format!("\'{}", &label_p7)), &crate::lower::model::OutTy::OutTurn))
}

/// The step machine of `TailMatch`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TailMatch: unbounded fn Lx, Env, Expr, [Arm], Range -> Ex
/// ```
pub struct TailMatch {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub s_p2: crate::syntax::Expr,
    pub arms_p3: crate::prelude::Array<crate::syntax::Arm>,
    pub span_p4: crate::syntax::Range,
}

impl ::prism_rtl::Job<crate::lower::model::Ex> for TailMatch {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::lower::model::Ex> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let s_p2 = &self.s_p2;
        let arms_p3 = &self.arms_p3;
        let span_p4 = &self.span_p4;
        let arms_p3x = arms_p3.clone();
        let env_p1x = env_p1.clone();
        let lx_p0x = lx_p0.clone();
        let s_p2x = s_p2.clone();
        let span_p4x = span_p4.clone();
        crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p0x.clone(), env_p1x.clone(), s_p2x.clone()), move |value_of_f_44695: crate::lower::types::Vl| {
            let sv_p5 = value_of_f_44695;
            let sty_p6 = crate::lower::type_at_f(&lx_p0x, &s_p2x.span_p);
            let label_p7 = crate::prelude::Text::from(format!("m{}", &span_p4x.start_p));
            crate::prelude::call_value(crate::prelude::each_job(crate::check::errors::range0_f(&crate::prelude::len(&arms_p3x)), {
                let lx_p0xx = lx_p0x.clone();
                let arms_p3xx = arms_p3x.clone();
                let sty_p6x = sty_p6.clone();
                let label_p7x = label_p7.clone();
                ::std::rc::Rc::new(move |p0: crate::prelude::Nat| {
                    let lx_p0xxy = lx_p0xx.clone();
                    let arms_p3xxy = arms_p3xx.clone();
                    let sty_p6xy = sty_p6x.clone();
                    let label_p7xy = label_p7x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let i_pe = p0;
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::lower::expr::ArmPat { lx_p0: lx_p0xxy.clone(), opt1: crate::prelude::or(&crate::prelude::index(&arms_p3xxy, &i_pe), &crate::lower::expr::dummy_arm_p()).pattern_o.clone(), ty_p2: sty_p6xy.clone(), mode_p3: crate::lower::types::Holding::ByRef, fresh_p4: crate::prelude::Text::from(format!("{}_{}", &label_p7xy, &i_pe)) }))
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::patterns::PatOut>>>
            }), move |each_44794: crate::prelude::Array<crate::lower::patterns::PatOut>| {
                let by_ref_p8 = each_44794;
                let chain_p9 = crate::prelude::fold(&by_ref_p8, &false, &(|f_pf: &bool, po_pg: &crate::lower::patterns::PatOut| *f_pf || crate::prelude::fold(&po_pg.conds_p, &false, &(|f2_ph: &bool, c_pi: &crate::lower::model::Cc| *f2_ph || crate::lower::expr::is_let_cond_f(c_pi)))));
                let owned_pa = match &sv_p5 {
                    crate::lower::types::Vl::VlOwned(_, _) => !chain_p9,
                    _ => false,
                };
                let arms_p3xz = arms_p3x.clone();
                let env_p1xz = env_p1x.clone();
                let label_p7z = label_p7.clone();
                let lx_p0xz = lx_p0x.clone();
                let owned_paz = owned_pa;
                let sv_p5z = sv_p5.clone();
                let k_let45090 = move |v45090: crate::prelude::Array<crate::lower::patterns::PatOut>| {
                    let pats_pb = v45090;
                    crate::prelude::call_value(crate::prelude::each_job(crate::check::errors::range0_f(&crate::prelude::len(&arms_p3xz)), {
                        let arms_p3xzx = arms_p3xz.clone();
                        let pats_pbx = pats_pb.clone();
                        let env_p1xzx = env_p1xz.clone();
                        let lx_p0xzx = lx_p0xz.clone();
                        ::std::rc::Rc::new(move |p0: crate::prelude::Nat| {
                            let arms_p3xzxy = arms_p3xzx.clone();
                            let pats_pbxy = pats_pbx.clone();
                            let env_p1xzxy = env_p1xzx.clone();
                            let lx_p0xzxy = lx_p0xzx.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let i_pk = p0;
                                {
                                    let arm_pl = crate::prelude::or(&crate::prelude::index(&arms_p3xzxy, &i_pk), &crate::lower::expr::dummy_arm_p());
                                    let po_pm = crate::prelude::or(&crate::prelude::index(&pats_pbxy, &i_pk), &crate::lower::patterns::PatOut { pa_p: crate::lower::model::Pa::PaWild, conds_p: crate::prelude::Array::new(), binds_p: crate::prelude::Array::new() });
                                    let env2_pn = crate::lower::expr::bind_all_f(&env_p1xzxy, &po_pm.binds_p);
                                    crate::prelude::call_then(crate::lower::templates::start_guard_conds_f(lx_p0xzxy.clone(), env2_pn.clone(), arm_pl.guard_o.clone()), move |guard_conds_f_45473: crate::prelude::Array<crate::lower::model::Cc>| crate::prelude::call_then(start_tail_block_f(lx_p0xzxy.clone(), env2_pn.clone(), arm_pl.body_p.clone()), move |tail_block_f_45514: crate::lower::model::Ex| ::prism_rtl::Turn::Finished(crate::lower::model::XArm { pat_p: po_pm.pa_p.clone(), conds_p: crate::prelude::append(&po_pm.conds_p, &guard_conds_f_45473), body_p: tail_block_f_45514 })))
                                }
                            }))
                        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::XArm>>>
                    }), move |each_45240: crate::prelude::Array<crate::lower::model::XArm>| {
                        let xarms_pc = each_45240;
                        let scrut_pd = if owned_paz {
                            crate::lower::types::own_f(&sv_p5z)
                        } else {
                            crate::lower::types::ref_f(&sv_p5z)
                        };
                        ::prism_rtl::Turn::Finished(crate::lower::types::own_f(&crate::lower::expr::arms_value_f(&scrut_pd, &xarms_pc, &crate::prelude::Text::from(format!("\'{}", &label_p7z)), &crate::lower::model::OutTy::OutTurn)))
                    })
                };
                if owned_pa {
                    crate::prelude::call_value(crate::prelude::each_job(crate::check::errors::range0_f(&crate::prelude::len(&arms_p3x)), {
                        let lx_p0xx = lx_p0x.clone();
                        let arms_p3xx = arms_p3x.clone();
                        let sty_p6x = sty_p6.clone();
                        let label_p7x = label_p7.clone();
                        ::std::rc::Rc::new(move |p0: crate::prelude::Nat| {
                            let lx_p0xxy = lx_p0xx.clone();
                            let arms_p3xxy = arms_p3xx.clone();
                            let sty_p6xy = sty_p6x.clone();
                            let label_p7xy = label_p7x.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let i_pj = p0;
                                ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::lower::expr::ArmPat { lx_p0: lx_p0xxy.clone(), opt1: crate::prelude::or(&crate::prelude::index(&arms_p3xxy, &i_pj), &crate::lower::expr::dummy_arm_p()).pattern_o.clone(), ty_p2: sty_p6xy.clone(), mode_p3: crate::lower::types::Holding::Owned, fresh_p4: crate::prelude::Text::from(format!("{}_{}", &label_p7xy, &i_pj)) }))
                            }))
                        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::patterns::PatOut>>>
                    }), move |each_45111: crate::prelude::Array<crate::lower::patterns::PatOut>| k_let45090(each_45111))
                } else {
                    k_let45090(by_ref_p8.clone())
                }
            })
        })
    }
}

/// `Start TailMatch, x`: what the function value is when passed to `@Run`.
pub fn start_tail_match_f(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, s_p2: crate::syntax::Expr, arms_p3: crate::prelude::Array<crate::syntax::Arm>, span_p4: crate::syntax::Range) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>> {
    ::std::rc::Rc::new(TailMatch { lx_p0, env_p1, s_p2, arms_p3, span_p4 })
}

/// ```prism
/// ?TailCallee: fn Lx, Env, Expr -> ?Text
/// ```
pub fn tail_callee_o(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, callee_p2: &crate::syntax::Expr) -> ::std::option::Option<crate::prelude::Text> {
    match &*callee_p2.kind_p {
        crate::syntax::ExprKind::EName(n_p3) => if (&crate::prelude::len(&n_p3.path_p) == &crate::prelude::Nat::from(1u32)) && crate::check::env::has_key_f(&env_p1.names_p, &crate::check::env::sname_key_f(n_p3)) {
            ::std::option::Option::None
        } else {
            {
                let (qk_o4, _) = crate::check::env::names::resolve_value_f(&lx_p0.g_p, &lx_p0.home_p, n_p3);
                match &qk_o4 {
                    ::std::option::Option::Some(qk_p5) => if crate::check::types::has_text_f(&lx_p0.unbs_p, qk_p5) && !crate::lower::program::in_prelude_f(lx_p0, qk_p5) {
                        ::std::option::Option::Some(qk_p5.clone())
                    } else {
                        ::std::option::Option::None
                    },
                    ::std::option::Option::None => ::std::option::Option::None,
                }
            }
        },
        _ => ::std::option::Option::None,
    }
}

/// ```prism
/// JobByStart: unbounded fn Lx, Text -> Bool
/// ```
pub fn job_by_start_f(lx_p0: &crate::lower::Lx, qk_p1: &crate::prelude::Text) -> bool {
    match crate::prelude::get(&lx_p0.g_p.vals_p, qk_p1) {
        ::std::option::Option::Some(v_p2) => {
            let (ptys_p4, _) = scheme_parts_f(lx_p0, qk_p1);
            let named_p3 = crate::prelude::run_to_end(crate::prelude::fold_job(ptys_p4.clone(), crate::prelude::Array::new(), {
                let lx_p0x = lx_p0.clone();
                ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::check::types::Ty)| {
                    let lx_p0xy = lx_p0x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let acc_p5 = p0;
                        let p_p6 = p1;
                        crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0xy.clone(), crate::lower::types::peel_f(&p_p6)), move |out_ty_of_f_46616: crate::lower::model::OutTy| ::prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_p5, &crate::lower::functions::ty_params_in_f(&out_ty_of_f_46616))))
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::check::types::Ty)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>
            }));
            crate::prelude::fold(&crate::lower::functions::scheme_generics_f(lx_p0, &v_p2.scheme_p), &false, &(|found_p7: &bool, (g_p8, ignore2_p9): &(crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>)| *found_p7 || !crate::check::types::has_text_f(&named_p3, g_p8)))
        },
        ::std::option::Option::None => false,
    }
}

/// The step machine of `JobByStart`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// JobByStart: unbounded fn Lx, Text -> Bool
/// ```
pub struct JobByStart {
    pub lx_p0: crate::lower::Lx,
    pub qk_p1: crate::prelude::Text,
}

impl ::prism_rtl::Job<bool> for JobByStart {
    fn cycle(&self) -> ::prism_rtl::Turn<bool> {
        let lx_p0 = &self.lx_p0;
        let qk_p1 = &self.qk_p1;
        match crate::prelude::get(&lx_p0.g_p.vals_p, qk_p1) {
            ::std::option::Option::Some(v_p2) => {
                let (ptys_p4, _) = scheme_parts_f(lx_p0, qk_p1);
                let lx_p0x = lx_p0.clone();
                crate::prelude::call_value(crate::prelude::fold_job(ptys_p4.clone(), crate::prelude::Array::new(), {
                    let lx_p0xx = lx_p0x.clone();
                    ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::check::types::Ty)| {
                        let lx_p0xxy = lx_p0xx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let acc_p5 = p0;
                            let p_p6 = p1;
                            crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0xxy.clone(), crate::lower::types::peel_f(&p_p6)), move |out_ty_of_f_46616: crate::lower::model::OutTy| ::prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_p5, &crate::lower::functions::ty_params_in_f(&out_ty_of_f_46616))))
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::check::types::Ty)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>
                }), move |fold_46560: crate::prelude::Array<crate::prelude::Text>| {
                    let named_p3 = fold_46560;
                    ::prism_rtl::Turn::Finished(crate::prelude::fold(&crate::lower::functions::scheme_generics_f(&lx_p0x, &v_p2.scheme_p), &false, &(|found_p7: &bool, (g_p8, ignore2_p9): &(crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>)| *found_p7 || !crate::check::types::has_text_f(&named_p3, g_p8))))
                })
            },
            ::std::option::Option::None => ::prism_rtl::Turn::Finished(false),
        }
    }
}

/// `Start JobByStart, x`: what the function value is when passed to `@Run`.
pub fn start_job_by_start_f(lx_p0: crate::lower::Lx, qk_p1: crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>> {
    ::std::rc::Rc::new(JobByStart { lx_p0, qk_p1 })
}

/// ```prism
/// StartOf: unbounded fn Lx, Text, Expr, [Ex] -> Ex
/// ```
pub fn start_of_f(lx_p0: &crate::lower::Lx, qk_p1: &crate::prelude::Text, callee_p2: &crate::syntax::Expr, vals_p3: &crate::prelude::Array<crate::lower::model::Ex>) -> crate::lower::model::Ex {
    let start_p4 = crate::lower::ref_in_f(lx_p0, &crate::lower::owner_of_f(qk_p1), &crate::prelude::Text::from(format!("start_{}", &crate::prelude::or(&crate::prelude::get(&lx_p0.rs_names_p, qk_p1), &crate::lower::snake_f(&crate::check::types::bare_name_f(qk_p1))))));
    match crate::prelude::get(&lx_p0.g_p.vals_p, qk_p1) {
        ::std::option::Option::Some(v_p5) if job_by_start_f(lx_p0, qk_p1) => match crate::lower::node_::static_::param_match_o(&crate::lower::node_::static_::unrigid_f(&v_p5.scheme_p.ty_p), &crate::lower::type_at_f(lx_p0, &callee_p2.span_p), &crate::prelude::Map::new()) {
            ::std::option::Option::Some(found_p6) => if crate::prelude::fold(&v_p5.scheme_p.qs_p, &true, &(|all_p7: &bool, q_p8: &crate::prelude::Text| *all_p7 && crate::check::env::has_key_f(&found_p6, q_p8))) {
                crate::lower::model::Ex::XCallAt(start_p4.clone(), crate::prelude::run_to_end(crate::prelude::each_job(v_p5.scheme_p.qs_p.clone(), {
                    let lx_p0x = lx_p0.clone();
                    let found_p6x = found_p6.clone();
                    ::std::rc::Rc::new(move |p0: crate::prelude::Text| {
                        let lx_p0xy = lx_p0x.clone();
                        let found_p6xy = found_p6x.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let q_p9 = p0;
                            ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::lower::types::OutTyOf { lx_p0: lx_p0xy.clone(), t_p1: crate::prelude::or(&crate::prelude::get(&found_p6xy, &q_p9), &crate::check::types::Ty::TyErr) }))
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::OutTy>>>
                })), vals_p3.clone())
            } else {
                crate::lower::model::Ex::XCall(start_p4.clone(), vals_p3.clone())
            },
            ::std::option::Option::None => crate::lower::model::Ex::XCall(start_p4.clone(), vals_p3.clone()),
        },
        _ => crate::lower::model::Ex::XCall(start_p4.clone(), vals_p3.clone()),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `StartOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// StartOf: unbounded fn Lx, Text, Expr, [Ex] -> Ex
/// ```
pub struct StartOf {
    pub lx_p0: crate::lower::Lx,
    pub qk_p1: crate::prelude::Text,
    pub callee_p2: crate::syntax::Expr,
    pub vals_p3: crate::prelude::Array<crate::lower::model::Ex>,
}

impl ::prism_rtl::Job<crate::lower::model::Ex> for StartOf {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::lower::model::Ex> {
        let lx_p0 = &self.lx_p0;
        let qk_p1 = &self.qk_p1;
        let callee_p2 = &self.callee_p2;
        let vals_p3 = &self.vals_p3;
        let start_p4 = crate::lower::ref_in_f(lx_p0, &crate::lower::owner_of_f(qk_p1), &crate::prelude::Text::from(format!("start_{}", &crate::prelude::or(&crate::prelude::get(&lx_p0.rs_names_p, qk_p1), &crate::lower::snake_f(&crate::check::types::bare_name_f(qk_p1))))));
        match crate::prelude::get(&lx_p0.g_p.vals_p, qk_p1) {
            ::std::option::Option::Some(v_p5) if job_by_start_f(lx_p0, qk_p1) => {
                let callee_p2x = callee_p2.clone();
                let lx_p0x = lx_p0.clone();
                let vals_p3x = vals_p3.clone();
                crate::prelude::call_then(crate::lower::node_::static_::start_unrigid_f(v_p5.scheme_p.ty_p.clone()), move |unrigid_f_47261: crate::check::types::Ty| crate::prelude::call_then(crate::lower::node_::static_::start_param_match_o(unrigid_f_47261, crate::lower::type_at_f(&lx_p0x, &callee_p2x.span_p), crate::prelude::Map::new()), move |param_match_o_47248: ::std::option::Option<crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>>| match param_match_o_47248 {
                    ::std::option::Option::Some(found_p6) => if crate::prelude::fold(&v_p5.scheme_p.qs_p, &true, &(|all_p7: &bool, q_p8: &crate::prelude::Text| *all_p7 && crate::check::env::has_key_f(&found_p6, q_p8))) {
                        crate::prelude::call_value(crate::prelude::each_job(v_p5.scheme_p.qs_p.clone(), {
                            let lx_p0xx = lx_p0x.clone();
                            let found_p6x = found_p6.clone();
                            ::std::rc::Rc::new(move |p0: crate::prelude::Text| {
                                let lx_p0xxy = lx_p0xx.clone();
                                let found_p6xy = found_p6x.clone();
                                crate::prelude::entered(crate::prelude::once_job(move || {
                                    let q_p9 = p0;
                                    ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::lower::types::OutTyOf { lx_p0: lx_p0xxy.clone(), t_p1: crate::prelude::or(&crate::prelude::get(&found_p6xy, &q_p9), &crate::check::types::Ty::TyErr) }))
                                }))
                            }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::OutTy>>>
                        }), move |each_47412: crate::prelude::Array<crate::lower::model::OutTy>| ::prism_rtl::Turn::Finished(crate::lower::model::Ex::XCallAt(start_p4.clone(), each_47412, vals_p3x.clone())))
                    } else {
                        ::prism_rtl::Turn::Finished(crate::lower::model::Ex::XCall(start_p4.clone(), vals_p3x.clone()))
                    },
                    ::std::option::Option::None => ::prism_rtl::Turn::Finished(crate::lower::model::Ex::XCall(start_p4.clone(), vals_p3x.clone())),
                }))
            },
            _ => ::prism_rtl::Turn::Finished(crate::lower::model::Ex::XCall(start_p4.clone(), vals_p3.clone())),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start StartOf, x`: what the function value is when passed to `@Run`.
pub fn start_start_of_f(lx_p0: crate::lower::Lx, qk_p1: crate::prelude::Text, callee_p2: crate::syntax::Expr, vals_p3: crate::prelude::Array<crate::lower::model::Ex>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>> {
    ::std::rc::Rc::new(StartOf { lx_p0, qk_p1, callee_p2, vals_p3 })
}

/// ```prism
/// SchemeParts: fn Lx, Text -> (([Ty], Ty))
/// ```
pub fn scheme_parts_f(lx_p0: &crate::lower::Lx, qk_p1: &crate::prelude::Text) -> (crate::prelude::Array<crate::check::types::Ty>, crate::check::types::Ty) {
    match crate::prelude::get(&lx_p0.g_p.vals_p, qk_p1) {
        ::std::option::Option::Some(v_p2) => match &v_p2.scheme_p.ty_p {
            crate::check::types::Ty::TyFn(_, ps_p3, r_p4) => (ps_p3.clone(), (**r_p4).clone()),
            other_p5 => (crate::prelude::Array::new(), other_p5.clone()),
        },
        ::std::option::Option::None => (crate::prelude::Array::new(), crate::check::types::Ty::TyErr),
    }
}

/// ```prism
/// JobFieldNames: unbounded fn Lx, Text -> [Text]
/// ```
pub fn job_field_names_f(lx_p0: &crate::lower::Lx, qk_p1: &crate::prelude::Text) -> crate::prelude::Array<crate::prelude::Text> {
    let clauses_p2 = clauses_of_f(&lx_p0.g_p, qk_p1);
    let (ptys_p5, _) = scheme_parts_f(lx_p0, qk_p1);
    let pts_p3 = crate::prelude::run_to_end(crate::prelude::each_job(ptys_p5.clone(), {
        let lx_p0x = lx_p0.clone();
        ::std::rc::Rc::new(move |p0: crate::check::types::Ty| {
            let lx_p0xy = lx_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let p_p6 = p0;
                ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::lower::types::OutTyOf { lx_p0: lx_p0xy.clone(), t_p1: crate::lower::types::peel_f(&p_p6) }))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::OutTy>>>
    }));
    let lxf_p4 = {
        let mut this: crate::lower::Lx = lx_p0.clone();
        this.file_p = crate::prelude::fold(&lx_p0.g_p.defs_p, &lx_p0.file_p, &(|f_p7: &crate::prelude::Nat, d_p8: &crate::check::env::Def| if &d_p8.qk_p == qk_p1 { d_p8.file_p.clone() } else { f_p7.clone() }));
        this
    };
    crate::prelude::each(&crate::lower::functions::param_names_f(&lxf_p4, &clauses_p2, &pts_p3), &(|(n_p9, _): &(crate::prelude::Text, bool)| n_p9.clone()))
}

/// The step machine of `JobFieldNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// JobFieldNames: unbounded fn Lx, Text -> [Text]
/// ```
pub struct JobFieldNames {
    pub lx_p0: crate::lower::Lx,
    pub qk_p1: crate::prelude::Text,
}

impl ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>> for JobFieldNames {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<crate::prelude::Text>> {
        let lx_p0 = &self.lx_p0;
        let qk_p1 = &self.qk_p1;
        let clauses_p2 = clauses_of_f(&lx_p0.g_p, qk_p1);
        let (ptys_p5, _) = scheme_parts_f(lx_p0, qk_p1);
        let lx_p0x = lx_p0.clone();
        let qk_p1x = qk_p1.clone();
        crate::prelude::call_value(crate::prelude::each_job(ptys_p5.clone(), {
            let lx_p0xx = lx_p0x.clone();
            ::std::rc::Rc::new(move |p0: crate::check::types::Ty| {
                let lx_p0xxy = lx_p0xx.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let p_p6 = p0;
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::lower::types::OutTyOf { lx_p0: lx_p0xxy.clone(), t_p1: crate::lower::types::peel_f(&p_p6) }))
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::OutTy>>>
        }), move |each_48000: crate::prelude::Array<crate::lower::model::OutTy>| {
            let pts_p3 = each_48000;
            let lxf_p4 = {
                let mut this: crate::lower::Lx = lx_p0x.clone();
                this.file_p = crate::prelude::fold(&lx_p0x.g_p.defs_p, &lx_p0x.file_p, &(|f_p7: &crate::prelude::Nat, d_p8: &crate::check::env::Def| if &d_p8.qk_p == &qk_p1x { d_p8.file_p.clone() } else { f_p7.clone() }));
                this
            };
            crate::prelude::call_then(crate::lower::functions::start_param_names_f(lxf_p4.clone(), clauses_p2.clone(), pts_p3.clone()), move |param_names_f_48234: crate::prelude::Array<(crate::prelude::Text, bool)>| ::prism_rtl::Turn::Finished(crate::prelude::each(&param_names_f_48234, &(|(n_p9, _): &(crate::prelude::Text, bool)| n_p9.clone()))))
        })
    }
}

/// `Start JobFieldNames, x`: what the function value is when passed to `@Run`.
pub fn start_job_field_names_f(lx_p0: crate::lower::Lx, qk_p1: crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>> {
    ::std::rc::Rc::new(JobFieldNames { lx_p0, qk_p1 })
}

/// ```prism
/// ClausesOf: fn G, Text -> [FnClause]
/// ```
pub fn clauses_of_f(g_p0: &crate::check::env::G, qk_p1: &crate::prelude::Text) -> crate::prelude::Array<crate::syntax::decls::FnClause> {
    crate::prelude::fold(&g_p0.defs_p, &crate::prelude::Array::new(), &(|acc_p2: &crate::prelude::Array<crate::syntax::decls::FnClause>, d_p3: &crate::check::env::Def| if &d_p3.qk_p == qk_p1 { def_clauses_f(d_p3, acc_p2) } else { acc_p2.clone() }))
}

/// ```prism
/// DefClauses: fn Def, [FnClause] -> [FnClause]
/// ```
pub fn def_clauses_f(d_p0: &crate::check::env::Def, other_p1: &crate::prelude::Array<crate::syntax::decls::FnClause>) -> crate::prelude::Array<crate::syntax::decls::FnClause> {
    match &d_p0.body_p {
        crate::check::env::DefBody::DbFn(cs_p2) => cs_p2.clone(),
        _ => other_p1.clone(),
    }
}

/// ```prism
/// JobDefOf: unbounded fn Lx, Text, [FnClause], Scheme -> JobDef
/// ```
pub fn job_def_of_f(lx_p0: &crate::lower::Lx, qk_p1: &crate::prelude::Text, clauses_p2: &crate::prelude::Array<crate::syntax::decls::FnClause>, sc_p3: &crate::check::types::Scheme) -> crate::lower::model::JobDef {
    let (ptys_pc, res_pd) = match &sc_p3.ty_p {
        crate::check::types::Ty::TyFn(_, ps_p9, r_pa) => (ps_p9.clone(), (**r_pa).clone()),
        other_pb => (crate::prelude::Array::new(), other_pb.clone()),
    };
    let pts_p4 = crate::prelude::run_to_end(crate::prelude::each_job(ptys_pc.clone(), {
        let lx_p0x = lx_p0.clone();
        ::std::rc::Rc::new(move |p0: crate::check::types::Ty| {
            let lx_p0xy = lx_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let p_pe = p0;
                ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::lower::types::OutTyOf { lx_p0: lx_p0xy.clone(), t_p1: crate::lower::types::peel_f(&p_pe) }))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::OutTy>>>
    }));
    let names_p5 = crate::lower::functions::param_names_f(lx_p0, clauses_p2, &pts_p4);
    let lxb_p6 = {
        let mut this: crate::lower::Lx = lx_p0.clone();
        this.in_definition_p = qk_p1.clone();
        this
    };
    let body_p7 = job_clauses_f(&lxb_p6, clauses_p2, &names_p5, &ptys_pc, &pts_p4);
    let base_p8 = crate::prelude::or(&crate::prelude::get(&lx_p0.rs_names_p, qk_p1), &crate::lower::snake_f(&crate::check::types::bare_name_f(qk_p1)));
    crate::lower::model::JobDef { name_p: crate::lower::camel_f(&crate::check::types::bare_name_f(qk_p1)), start_p: crate::prelude::Text::from(format!("start_{}", &base_p8)), generics_p: crate::lower::functions::scheme_generics_f(lx_p0, sc_p3), fields_p: crate::prelude::each(&crate::check::errors::range0_f(&crate::prelude::len(&pts_p4)), &(|i_pf: &crate::prelude::Nat| (crate::prelude::or(&crate::prelude::index(&crate::prelude::each(&names_p5, &(|(n_pg, _): &(crate::prelude::Text, bool)| n_pg.clone())), i_pf), &crate::prelude::Text::lit("arg")), crate::prelude::or(&crate::prelude::index(&pts_p4, i_pf), &crate::lower::model::OutTy::OutUnit)))), ret_p: crate::lower::types::out_ty_of_f(lx_p0, &crate::lower::types::peel_f(&res_pd)), body_p: body_p7.clone(), doc_p: crate::lower::functions::signature_text_f(lx_p0, qk_p1) }
}

/// The step machine of `JobDefOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// JobDefOf: unbounded fn Lx, Text, [FnClause], Scheme -> JobDef
/// ```
pub struct JobDefOf {
    pub lx_p0: crate::lower::Lx,
    pub qk_p1: crate::prelude::Text,
    pub clauses_p2: crate::prelude::Array<crate::syntax::decls::FnClause>,
    pub sc_p3: crate::check::types::Scheme,
}

impl ::prism_rtl::Job<crate::lower::model::JobDef> for JobDefOf {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::lower::model::JobDef> {
        let lx_p0 = &self.lx_p0;
        let qk_p1 = &self.qk_p1;
        let clauses_p2 = &self.clauses_p2;
        let sc_p3 = &self.sc_p3;
        let (ptys_pc, res_pd) = match &sc_p3.ty_p {
            crate::check::types::Ty::TyFn(_, ps_p9, r_pa) => (ps_p9.clone(), (**r_pa).clone()),
            other_pb => (crate::prelude::Array::new(), other_pb.clone()),
        };
        let clauses_p2x = clauses_p2.clone();
        let lx_p0x = lx_p0.clone();
        let qk_p1x = qk_p1.clone();
        let sc_p3x = sc_p3.clone();
        crate::prelude::call_value(crate::prelude::each_job(ptys_pc.clone(), {
            let lx_p0xx = lx_p0x.clone();
            ::std::rc::Rc::new(move |p0: crate::check::types::Ty| {
                let lx_p0xxy = lx_p0xx.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let p_pe = p0;
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::lower::types::OutTyOf { lx_p0: lx_p0xxy.clone(), t_p1: crate::lower::types::peel_f(&p_pe) }))
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::OutTy>>>
        }), move |each_48842: crate::prelude::Array<crate::lower::model::OutTy>| {
            let pts_p4 = each_48842;
            crate::prelude::call_then(crate::lower::functions::start_param_names_f(lx_p0x.clone(), clauses_p2x.clone(), pts_p4.clone()), move |param_names_f_48895: crate::prelude::Array<(crate::prelude::Text, bool)>| {
                let names_p5 = param_names_f_48895;
                let lxb_p6 = {
                    let mut this: crate::lower::Lx = lx_p0x.clone();
                    this.in_definition_p = qk_p1x.clone();
                    this
                };
                crate::prelude::call_then(start_job_clauses_f(lxb_p6.clone(), clauses_p2x.clone(), names_p5.clone(), ptys_pc.clone(), pts_p4.clone()), move |job_clauses_f_48993: crate::lower::model::Ex| {
                    let body_p7 = job_clauses_f_48993;
                    let base_p8 = crate::prelude::or(&crate::prelude::get(&lx_p0x.rs_names_p, &qk_p1x), &crate::lower::snake_f(&crate::check::types::bare_name_f(&qk_p1x)));
                    crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0x.clone(), crate::lower::types::peel_f(&res_pd)), move |out_ty_of_f_49305: crate::lower::model::OutTy| ::prism_rtl::Turn::Finished(crate::lower::model::JobDef { name_p: crate::lower::camel_f(&crate::check::types::bare_name_f(&qk_p1x)), start_p: crate::prelude::Text::from(format!("start_{}", &base_p8)), generics_p: crate::lower::functions::scheme_generics_f(&lx_p0x, &sc_p3x), fields_p: crate::prelude::each(&crate::check::errors::range0_f(&crate::prelude::len(&pts_p4)), &(|i_pf: &crate::prelude::Nat| (crate::prelude::or(&crate::prelude::index(&crate::prelude::each(&names_p5, &(|(n_pg, _): &(crate::prelude::Text, bool)| n_pg.clone())), i_pf), &crate::prelude::Text::lit("arg")), crate::prelude::or(&crate::prelude::index(&pts_p4, i_pf), &crate::lower::model::OutTy::OutUnit)))), ret_p: out_ty_of_f_49305, body_p: body_p7.clone(), doc_p: crate::lower::functions::signature_text_f(&lx_p0x, &qk_p1x) }))
                })
            })
        })
    }
}

/// `Start JobDefOf, x`: what the function value is when passed to `@Run`.
pub fn start_job_def_of_f(lx_p0: crate::lower::Lx, qk_p1: crate::prelude::Text, clauses_p2: crate::prelude::Array<crate::syntax::decls::FnClause>, sc_p3: crate::check::types::Scheme) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::JobDef>> {
    ::std::rc::Rc::new(JobDefOf { lx_p0, qk_p1, clauses_p2, sc_p3 })
}

/// ```prism
/// JobClauses: unbounded fn Lx, [FnClause], [((Text, Bool))], [Ty], [OutTy] -> Ex
/// ```
pub fn job_clauses_f(lx_p0: &crate::lower::Lx, clauses_p1: &crate::prelude::Array<crate::syntax::decls::FnClause>, names_p2: &crate::prelude::Array<(crate::prelude::Text, bool)>, ptys_p3: &crate::prelude::Array<crate::check::types::Ty>, pts_p4: &crate::prelude::Array<crate::lower::model::OutTy>) -> crate::lower::model::Ex {
    let lets_p5 = crate::prelude::each(&crate::check::errors::range0_f(&crate::prelude::len(names_p2)), &(|i_p7: &crate::prelude::Nat| {
        let (rs_p8, _) = crate::prelude::or(&crate::prelude::index(names_p2, i_p7), &(crate::prelude::Text::lit("arg"), true));
        crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(rs_p8.clone()), crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), rs_p8.clone()))))
    }));
    let inner_p6 = crate::lower::functions::clauses_body_f(lx_p0, &crate::lower::types::empty_env_p(), clauses_p1, names_p2, ptys_p3, &(::std::rc::Rc::new(|(a0, a1, a2): (crate::lower::Lx, crate::lower::types::Env, crate::syntax::decls::FnBody)| crate::prelude::entered(start_tail_body_f(a0, a1, a2))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::Lx, crate::lower::types::Env, crate::syntax::decls::FnBody)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>>>), &crate::prelude::Text::lit("j"), &crate::lower::model::OutTy::OutTurn);
    crate::lower::model::Ex::XBlock(lets_p5.clone(), ::std::rc::Rc::new(inner_p6.clone()))
}

/// The step machine of `JobClauses`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// JobClauses: unbounded fn Lx, [FnClause], [((Text, Bool))], [Ty], [OutTy] -> Ex
/// ```
pub struct JobClauses {
    pub lx_p0: crate::lower::Lx,
    pub clauses_p1: crate::prelude::Array<crate::syntax::decls::FnClause>,
    pub names_p2: crate::prelude::Array<(crate::prelude::Text, bool)>,
    pub ptys_p3: crate::prelude::Array<crate::check::types::Ty>,
    pub pts_p4: crate::prelude::Array<crate::lower::model::OutTy>,
}

impl ::prism_rtl::Job<crate::lower::model::Ex> for JobClauses {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::lower::model::Ex> {
        let lx_p0 = &self.lx_p0;
        let clauses_p1 = &self.clauses_p1;
        let names_p2 = &self.names_p2;
        let ptys_p3 = &self.ptys_p3;
        let pts_p4 = &self.pts_p4;
        let lets_p5 = crate::prelude::each(&crate::check::errors::range0_f(&crate::prelude::len(names_p2)), &(|i_p7: &crate::prelude::Nat| {
            let (rs_p8, _) = crate::prelude::or(&crate::prelude::index(names_p2, i_p7), &(crate::prelude::Text::lit("arg"), true));
            crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(rs_p8.clone()), crate::lower::model::Ex::XRef(::std::rc::Rc::new(crate::lower::model::Ex::XField(::std::rc::Rc::new(crate::lower::model::Ex::XSelf), rs_p8.clone()))))
        }));
        let clauses_p1x = clauses_p1.clone();
        let lx_p0x = lx_p0.clone();
        let names_p2x = names_p2.clone();
        let ptys_p3x = ptys_p3.clone();
        crate::prelude::call_then(crate::lower::functions::start_clauses_body_f(lx_p0x.clone(), crate::lower::types::empty_env_p(), clauses_p1x.clone(), names_p2x.clone(), ptys_p3x.clone(), ::std::rc::Rc::new(|(a0, a1, a2): (crate::lower::Lx, crate::lower::types::Env, crate::syntax::decls::FnBody)| crate::prelude::entered(start_tail_body_f(a0, a1, a2))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::Lx, crate::lower::types::Env, crate::syntax::decls::FnBody)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>>>, crate::prelude::Text::lit("j"), crate::lower::model::OutTy::OutTurn), move |clauses_body_f_49734: crate::lower::model::Ex| {
            let inner_p6 = clauses_body_f_49734;
            ::prism_rtl::Turn::Finished(crate::lower::model::Ex::XBlock(lets_p5.clone(), ::std::rc::Rc::new(inner_p6.clone())))
        })
    }
}

/// `Start JobClauses, x`: what the function value is when passed to `@Run`.
pub fn start_job_clauses_f(lx_p0: crate::lower::Lx, clauses_p1: crate::prelude::Array<crate::syntax::decls::FnClause>, names_p2: crate::prelude::Array<(crate::prelude::Text, bool)>, ptys_p3: crate::prelude::Array<crate::check::types::Ty>, pts_p4: crate::prelude::Array<crate::lower::model::OutTy>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::lower::model::Ex>> {
    ::std::rc::Rc::new(JobClauses { lx_p0, clauses_p1, names_p2, ptys_p3, pts_p4 })
}
