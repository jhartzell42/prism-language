//! The module `Lower.Jobs`, from `target/bootstrap/src/prismc/lower/jobs.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// ```prism
/// Tail: unbounded fn Lx, Env, Expr -> Ex
/// ```
pub fn tail(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, e_p2: &crate::syntax::Expr) -> crate::lower::model::Ex {
    match frame_call(lx_p0, env_p1, e_p2, &true) {
        Some(c_p3) => frame(lx_p0, env_p1, &c_p3, &rest_text(lx_p0, &e_p2.span, &c_p3.span, &e_p2.span), &{
            let lx_p0 = lx_p0.clone();
            let e_p2 = e_p2.clone();
            Rc::new(move |p0: crate::lower::types::Env| {
                let lx_p0 = lx_p0.clone();
                let e_p2 = e_p2.clone();
                entered(once_job(move || {
                    let env2_p4 = p0;
                    prism_rtl::Turn::More(Rc::new(Tail { lx_p0: lx_p0.clone(), env_p1: env2_p4.clone(), e_p2: e_p2.clone() }))
                }))
            }) as Rc<dyn Fn(crate::lower::types::Env) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
        }),
        None => tail_here(lx_p0, env_p1, e_p2),
    }
}

/// The step machine of `Tail`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Tail: unbounded fn Lx, Env, Expr -> Ex
/// ```
pub struct Tail {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub e_p2: crate::syntax::Expr,
}

impl prism_rtl::Job<crate::lower::model::Ex> for Tail {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::Ex> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let e_p2 = &self.e_p2;
        let e_p2 = e_p2.clone();
        let env_p1 = env_p1.clone();
        let lx_p0 = lx_p0.clone();
        call_then(start_frame_call(lx_p0.clone(), env_p1.clone(), e_p2.clone(), true), move |frame_call_1854: Option<crate::syntax::Expr>| match frame_call_1854 {
            Some(c_p3) => prism_rtl::Turn::More(Rc::new(Frame { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), call_p2: c_p3.clone(), rest_text_p3: rest_text(&lx_p0, &e_p2.span, &c_p3.span, &e_p2.span), cont_f4: {
                let lx_p0 = lx_p0.clone();
                let e_p2 = e_p2.clone();
                Rc::new(move |p0: crate::lower::types::Env| {
                    let lx_p0 = lx_p0.clone();
                    let e_p2 = e_p2.clone();
                    entered(once_job(move || {
                        let env2_p4 = p0;
                        prism_rtl::Turn::More(Rc::new(Tail { lx_p0: lx_p0.clone(), env_p1: env2_p4.clone(), e_p2: e_p2.clone() }))
                    }))
                }) as Rc<dyn Fn(crate::lower::types::Env) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
            } })),
            None => prism_rtl::Turn::More(Rc::new(TailHere { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), e_p2: e_p2.clone() })),
        })
    }
}

/// `Start Tail, x`: what the function value is when passed to `@Run`.
pub fn start_tail(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, e_p2: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>> {
    Rc::new(Tail { lx_p0, env_p1, e_p2 })
}

/// ```prism
/// TailHere: unbounded fn Lx, Env, Expr -> Ex
/// ```
pub fn tail_here(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, e_p2: &crate::syntax::Expr) -> crate::lower::model::Ex {
    'm2072: {
        let scrutinee = &*e_p2.kind;
        if let crate::syntax::ExprKind::EGroup(x_p3) = scrutinee {
            break 'm2072 tail(lx_p0, env_p1, &**x_p3);
        }
        if let crate::syntax::ExprKind::EUpdate(target_p4, b_p5) = scrutinee {
            break 'm2072 if has_top_while(lx_p0, b_p5) {
                upd_tail(lx_p0, env_p1, &**target_p4, b_p5, &e_p2.span, &(Rc::new(move |(p0, p1): (crate::lower::types::Env, crate::lower::model::Ex)| once_job(move || {
                    let en_p6 = p0;
                    let v_p7 = p1;
                    prism_rtl::Turn::Finished(crate::lower::model::Ex::XCtor(Text::lit("prism_rtl::Turn::Finished"), Array::from(vec![v_p7.clone()])))
                })) as Rc<dyn Fn((crate::lower::types::Env, crate::lower::model::Ex)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>))
            } else {
                crate::lower::model::Ex::XCtor(Text::lit("prism_rtl::Turn::Finished"), Array::from(vec![crate::lower::types::own(&crate::lower::expr::value_of(lx_p0, env_p1, e_p2))]))
            };
        }
        if let crate::syntax::ExprKind::EMatch(s_p8, arms_p9) = scrutinee {
            break 'm2072 tail_match(lx_p0, env_p1, &**s_p8, arms_p9, &e_p2.span);
        }
        if let crate::syntax::ExprKind::EIf(m2072_3_0, then_b_pb, Some(else_b_pc)) = scrutinee && let crate::syntax::Cond::CondExpr(c_pa) = &**m2072_3_0 {
            break 'm2072 crate::lower::model::Ex::XIf(Rc::new(crate::lower::types::as_bool(&crate::lower::expr::value_of(lx_p0, env_p1, &**c_pa))), Rc::new(tail_block(lx_p0, env_p1, then_b_pb)), Rc::new(tail_block(lx_p0, env_p1, else_b_pc)));
        }
        if let crate::syntax::ExprKind::ECall(callee_pd, args_pe, _, _) = scrutinee {
            break 'm2072 match tail_callee(lx_p0, env_p1, &**callee_pd) {
                Some(qk_pf) => {
                    let job_pg = or(&get(&lx_p0.rs_names, &qk_pf), &crate::lower::snake(&crate::check::types::bare_name(&qk_pf)));
                    let job_name_ph = crate::lower::path_in(lx_p0, &crate::lower::owner_of(&qk_pf), &crate::lower::camel(&crate::check::types::bare_name(&qk_pf)));
                    let (ptys_pk, _) = scheme_parts(lx_p0, &qk_pf);
                    let fields_pi = job_field_names(lx_p0, &qk_pf);
                    let vals_pj = crate::lower::expr::named_args_owned(lx_p0, env_p1, &qk_pf, args_pe);
                    if crate::lower::program::enters_at_once(lx_p0, &qk_pf, args_pe) {
                        crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCall(crate::lower::path_in(lx_p0, &crate::lower::owner_of(&qk_pf), &Text::from(format!("start_{}", &job_pg))), vals_pj.clone())), Text::lit("cycle"), Array::new())
                    } else {
                        if crate::lower::program::is_color_poly(lx_p0, &qk_pf) {
                            crate::lower::model::Ex::XCtor(Text::lit("prism_rtl::Turn::More"), Array::from(vec![crate::lower::model::Ex::XCall(crate::lower::path_in(lx_p0, &crate::lower::owner_of(&qk_pf), &Text::from(format!("start_{}", &job_pg))), vals_pj.clone())]))
                        } else {
                            crate::lower::model::Ex::XCtor(Text::lit("prism_rtl::Turn::More"), Array::from(vec![crate::lower::model::Ex::XCall(Text::lit("Rc::new"), Array::from(vec![crate::lower::model::Ex::XRecord(job_name_ph.clone(), each(&crate::check::errors::range0(&len(&vals_pj)), &(|i_pl: &Nat| (or(&index(&fields_pi, i_pl), &Text::lit("arg")), or(&index(&vals_pj, i_pl), &crate::lower::model::Ex::XUnit)))))]))]))
                        }
                    }
                },
                None => match local_job_fn(lx_p0, env_p1, &**callee_pd) {
                    Some(f_pm) => crate::lower::model::Ex::XMethod(Rc::new(start_call(&f_pm, &crate::lower::expr::start_args(lx_p0, env_p1, &f_pm, args_pe))), Text::lit("cycle"), Array::new()),
                    None => match crate::lower::expr::prelude_job_call(lx_p0, env_p1, e_p2) {
                        Some(job_pn) => crate::lower::model::Ex::XMethod(Rc::new(job_pn), Text::lit("cycle"), Array::new()),
                        None => crate::lower::model::Ex::XCtor(Text::lit("prism_rtl::Turn::Finished"), Array::from(vec![crate::lower::types::own(&crate::lower::expr::value_of(lx_p0, env_p1, e_p2))])),
                    },
                },
            };
        }
        crate::lower::model::Ex::XCtor(Text::lit("prism_rtl::Turn::Finished"), Array::from(vec![crate::lower::types::own(&crate::lower::expr::value_of(lx_p0, env_p1, e_p2))]))
    }
}

/// The step machine of `TailHere`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TailHere: unbounded fn Lx, Env, Expr -> Ex
/// ```
pub struct TailHere {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub e_p2: crate::syntax::Expr,
}

impl prism_rtl::Job<crate::lower::model::Ex> for TailHere {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::Ex> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let e_p2 = &self.e_p2;
        'm2072: {
            let scrutinee = &*e_p2.kind;
            if let crate::syntax::ExprKind::EGroup(x_p3) = scrutinee {
                break 'm2072 prism_rtl::Turn::More(Rc::new(Tail { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), e_p2: (**x_p3).clone() }));
            }
            if let crate::syntax::ExprKind::EUpdate(target_p4, b_p5) = scrutinee {
                break 'm2072 if has_top_while(lx_p0, b_p5) {
                    prism_rtl::Turn::More(Rc::new(UpdTail { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), target_p2: (**target_p4).clone(), b_p3: b_p5.clone(), to_p4: e_p2.span.clone(), cont_f5: Rc::new(move |(p0, p1): (crate::lower::types::Env, crate::lower::model::Ex)| once_job(move || {
                        let en_p6 = p0;
                        let v_p7 = p1;
                        prism_rtl::Turn::Finished(crate::lower::model::Ex::XCtor(Text::lit("prism_rtl::Turn::Finished"), Array::from(vec![v_p7.clone()])))
                    })) as Rc<dyn Fn((crate::lower::types::Env, crate::lower::model::Ex)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>> }))
                } else {
                    {
                        let e_p2 = e_p2.clone();
                        let env_p1 = env_p1.clone();
                        let lx_p0 = lx_p0.clone();
                        call_then(crate::lower::expr::start_value_of(lx_p0.clone(), env_p1.clone(), e_p2.clone()), move |value_of_2311: crate::lower::types::Vl| prism_rtl::Turn::Finished(crate::lower::model::Ex::XCtor(Text::lit("prism_rtl::Turn::Finished"), Array::from(vec![crate::lower::types::own(&value_of_2311)]))))
                    }
                };
            }
            if let crate::syntax::ExprKind::EMatch(s_p8, arms_p9) = scrutinee {
                break 'm2072 prism_rtl::Turn::More(Rc::new(TailMatch { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), s_p2: (**s_p8).clone(), arms_p3: arms_p9.clone(), span_p4: e_p2.span.clone() }));
            }
            if let crate::syntax::ExprKind::EIf(m2072_3_0, then_b_pb, Some(else_b_pc)) = scrutinee && let crate::syntax::Cond::CondExpr(c_pa) = &**m2072_3_0 {
                break 'm2072 {
                    let c_pa = (**c_pa).clone();
                    let else_b_pc = else_b_pc.clone();
                    let env_p1 = env_p1.clone();
                    let lx_p0 = lx_p0.clone();
                    let then_b_pb = then_b_pb.clone();
                    call_then(crate::lower::expr::start_value_of(lx_p0.clone(), env_p1.clone(), c_pa.clone()), move |value_of_2441: crate::lower::types::Vl| call_then(start_tail_block(lx_p0.clone(), env_p1.clone(), then_b_pb.clone()), move |tail_block_2464: crate::lower::model::Ex| call_then(start_tail_block(lx_p0.clone(), env_p1.clone(), else_b_pc.clone()), move |tail_block_2492: crate::lower::model::Ex| prism_rtl::Turn::Finished(crate::lower::model::Ex::XIf(Rc::new(crate::lower::types::as_bool(&value_of_2441)), Rc::new(tail_block_2464), Rc::new(tail_block_2492))))))
                };
            }
            if let crate::syntax::ExprKind::ECall(callee_pd, args_pe, _, _) = scrutinee {
                break 'm2072 match tail_callee(lx_p0, env_p1, &**callee_pd) {
                    Some(qk_pf) => {
                        let job_pg = or(&get(&lx_p0.rs_names, &qk_pf), &crate::lower::snake(&crate::check::types::bare_name(&qk_pf)));
                        let job_name_ph = crate::lower::path_in(lx_p0, &crate::lower::owner_of(&qk_pf), &crate::lower::camel(&crate::check::types::bare_name(&qk_pf)));
                        let (ptys_pk, _) = scheme_parts(lx_p0, &qk_pf);
                        let args_pe = args_pe.clone();
                        let env_p1 = env_p1.clone();
                        let lx_p0 = lx_p0.clone();
                        call_then(start_job_field_names(lx_p0.clone(), qk_pf.clone()), move |job_field_names_2822: Array<Text>| {
                            let fields_pi = job_field_names_2822;
                            call_then(crate::lower::expr::start_named_args_owned(lx_p0.clone(), env_p1.clone(), qk_pf.clone(), args_pe.clone()), move |named_args_owned_2866: Array<crate::lower::model::Ex>| {
                                let vals_pj = named_args_owned_2866;
                                if crate::lower::program::enters_at_once(&lx_p0, &qk_pf, &args_pe) {
                                    prism_rtl::Turn::Finished(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCall(crate::lower::path_in(&lx_p0, &crate::lower::owner_of(&qk_pf), &Text::from(format!("start_{}", &job_pg))), vals_pj.clone())), Text::lit("cycle"), Array::new()))
                                } else {
                                    if crate::lower::program::is_color_poly(&lx_p0, &qk_pf) {
                                        prism_rtl::Turn::Finished(crate::lower::model::Ex::XCtor(Text::lit("prism_rtl::Turn::More"), Array::from(vec![crate::lower::model::Ex::XCall(crate::lower::path_in(&lx_p0, &crate::lower::owner_of(&qk_pf), &Text::from(format!("start_{}", &job_pg))), vals_pj.clone())])))
                                    } else {
                                        prism_rtl::Turn::Finished(crate::lower::model::Ex::XCtor(Text::lit("prism_rtl::Turn::More"), Array::from(vec![crate::lower::model::Ex::XCall(Text::lit("Rc::new"), Array::from(vec![crate::lower::model::Ex::XRecord(job_name_ph.clone(), each(&crate::check::errors::range0(&len(&vals_pj)), &(|i_pl: &Nat| (or(&index(&fields_pi, i_pl), &Text::lit("arg")), or(&index(&vals_pj, i_pl), &crate::lower::model::Ex::XUnit)))))]))])))
                                    }
                                }
                            })
                        })
                    },
                    None => {
                        let args_pe = args_pe.clone();
                        let callee_pd = (**callee_pd).clone();
                        let e_p2 = e_p2.clone();
                        let env_p1 = env_p1.clone();
                        let lx_p0 = lx_p0.clone();
                        call_then(start_local_job_fn(lx_p0.clone(), env_p1.clone(), callee_pd.clone()), move |local_job_fn_3346: Option<crate::lower::types::Vl>| match local_job_fn_3346 {
                            Some(f_pm) => call_then(crate::lower::expr::start_start_args(lx_p0.clone(), env_p1.clone(), f_pm.clone(), args_pe.clone()), move |start_args_3415: Array<crate::lower::model::Ex>| prism_rtl::Turn::Finished(crate::lower::model::Ex::XMethod(Rc::new(start_call(&f_pm, &start_args_3415)), Text::lit("cycle"), Array::new()))),
                            None => call_then(crate::lower::expr::start_prelude_job_call(lx_p0.clone(), env_p1.clone(), e_p2.clone()), move |prelude_job_call_3482: Option<crate::lower::model::Ex>| match prelude_job_call_3482 {
                                Some(job_pn) => prism_rtl::Turn::Finished(crate::lower::model::Ex::XMethod(Rc::new(job_pn.clone()), Text::lit("cycle"), Array::new())),
                                None => call_then(crate::lower::expr::start_value_of(lx_p0.clone(), env_p1.clone(), e_p2.clone()), move |value_of_3623: crate::lower::types::Vl| prism_rtl::Turn::Finished(crate::lower::model::Ex::XCtor(Text::lit("prism_rtl::Turn::Finished"), Array::from(vec![crate::lower::types::own(&value_of_3623)])))),
                            }),
                        })
                    },
                };
            }
            {
                let e_p2 = e_p2.clone();
                let env_p1 = env_p1.clone();
                let lx_p0 = lx_p0.clone();
                call_then(crate::lower::expr::start_value_of(lx_p0.clone(), env_p1.clone(), e_p2.clone()), move |value_of_3702: crate::lower::types::Vl| prism_rtl::Turn::Finished(crate::lower::model::Ex::XCtor(Text::lit("prism_rtl::Turn::Finished"), Array::from(vec![crate::lower::types::own(&value_of_3702)]))))
            }
        }
    }
}

/// `Start TailHere, x`: what the function value is when passed to `@Run`.
pub fn start_tail_here(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, e_p2: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>> {
    Rc::new(TailHere { lx_p0, env_p1, e_p2 })
}

/// ```prism
/// TailBlock: unbounded fn Lx, Env, Block -> Ex
/// ```
pub fn tail_block(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, b_p2: &crate::syntax::Block) -> crate::lower::model::Ex {
    tail_from(lx_p0, env_p1, b_p2, &Nat::from(0u32))
}

/// The step machine of `TailBlock`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TailBlock: unbounded fn Lx, Env, Block -> Ex
/// ```
pub struct TailBlock {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub b_p2: crate::syntax::Block,
}

impl prism_rtl::Job<crate::lower::model::Ex> for TailBlock {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::Ex> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let b_p2 = &self.b_p2;
        prism_rtl::Turn::More(Rc::new(TailFrom { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), b_p2: b_p2.clone(), i_p3: Nat::from(0u32) }))
    }
}

/// `Start TailBlock, x`: what the function value is when passed to `@Run`.
pub fn start_tail_block(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, b_p2: crate::syntax::Block) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>> {
    Rc::new(TailBlock { lx_p0, env_p1, b_p2 })
}

/// ```prism
/// TailFrom: unbounded fn Lx, Env, Block, Nat -> Ex
/// ```
pub fn tail_from(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, b_p2: &crate::syntax::Block, i_p3: &Nat) -> crate::lower::model::Ex {
    let s_p4 = or(&index(&b_p2.stmts, i_p3), &crate::lower::expr::dummy_stmt_l());
    if &(i_p3 + &Nat::from(1u32)) >= &len(&b_p2.stmts) {
        match &s_p4.kind {
            crate::syntax::StmtKind::SExpr(x_p5) => tail(lx_p0, env_p1, x_p5),
            _ => crate::lower::model::Ex::XCtor(Text::lit("prism_rtl::Turn::Finished"), Array::from(vec![crate::lower::model::Ex::XUnit])),
        }
    } else {
        {
            let found_o6 = match &s_p4.kind {
                crate::syntax::StmtKind::SLet(_, _, x_p8) => frame_call(lx_p0, env_p1, x_p8, &false),
                crate::syntax::StmtKind::SExpr(x_p9) => frame_call(lx_p0, env_p1, x_p9, &false),
                _ => None,
            };
            let looping_o7 = match &s_p4.kind {
                crate::syntax::StmtKind::SLet(p_pa, _, x_pb) => match &*x_pb.kind {
                    crate::syntax::ExprKind::EUpdate(target_pc, ub_pd) => if has_top_while(lx_p0, ub_pd) {
                        Some((p_pa.clone(), (**target_pc).clone(), ub_pd.clone(), x_pb.clone()))
                    } else {
                        None
                    },
                    _ => None,
                },
                _ => None,
            };
            match &looping_o7 {
                Some((p_pe, target_pf, ub_pg, x_ph)) => upd_tail(lx_p0, env_p1, target_pf, ub_pg, &b_p2.span, &{
                    let lx_p0 = lx_p0.clone();
                    let p_pe = p_pe.clone();
                    let x_ph = x_ph.clone();
                    let s_p4 = s_p4.clone();
                    let b_p2 = b_p2.clone();
                    let i_p3 = i_p3.clone();
                    Rc::new(move |(p0, p1): (crate::lower::types::Env, crate::lower::model::Ex)| {
                        let lx_p0 = lx_p0.clone();
                        let p_pe = p_pe.clone();
                        let x_ph = x_ph.clone();
                        let s_p4 = s_p4.clone();
                        let b_p2 = b_p2.clone();
                        let i_p3 = i_p3.clone();
                        entered(once_job(move || {
                            let en_pi = p0;
                            let v_pj = p1;
                            call_then(crate::lower::patterns::start_rust_pat(lx_p0.clone(), p_pe.clone(), crate::lower::type_at(&lx_p0, &x_ph.span), crate::lower::types::Holding::Owned, Text::from(format!("l{}", &s_p4.span.start))), move |rust_pat_4825: crate::lower::patterns::PatOut| {
                                let po_pk = rust_pat_4825;
                                call_then(start_tail_from(lx_p0.clone(), crate::lower::expr::bind_all(&en_pi, &po_pk.binds), b_p2.clone(), &i_p3 + &Nat::from(1u32)), move |tail_from_4917: crate::lower::model::Ex| {
                                    let rest_pl = tail_from_4917;
                                    prism_rtl::Turn::Finished(prepend(&Array::from(vec![crate::lower::model::Do::DoLet(po_pk.pa.clone(), v_pj.clone())]), &rest_pl))
                                })
                            })
                        }))
                    }) as Rc<dyn Fn((crate::lower::types::Env, crate::lower::model::Ex)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
                }),
                None => match &found_o6 {
                    Some(c_pm) => frame(lx_p0, env_p1, c_pm, &rest_text(lx_p0, &s_p4.span, &c_pm.span, &b_p2.span), &{
                        let lx_p0 = lx_p0.clone();
                        let b_p2 = b_p2.clone();
                        let i_p3 = i_p3.clone();
                        Rc::new(move |p0: crate::lower::types::Env| {
                            let lx_p0 = lx_p0.clone();
                            let b_p2 = b_p2.clone();
                            let i_p3 = i_p3.clone();
                            entered(once_job(move || {
                                let env2_pn = p0;
                                prism_rtl::Turn::More(Rc::new(TailFrom { lx_p0: lx_p0.clone(), env_p1: env2_pn.clone(), b_p2: b_p2.clone(), i_p3: i_p3.clone() }))
                            }))
                        }) as Rc<dyn Fn(crate::lower::types::Env) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
                    }),
                    None => {
                        let (dos_po, env2_pp) = crate::lower::expr::block_stmt(lx_p0, env_p1, &s_p4);
                        match tail_from(lx_p0, &env2_pp, b_p2, &(i_p3 + &Nat::from(1u32))) {
                            crate::lower::model::Ex::XBlock(more_pq, last_pr) => crate::lower::model::Ex::XBlock(append(&dos_po, &more_pq), Rc::new((*last_pr).clone())),
                            last_ps => if &len(&dos_po) == &Nat::from(0u32) {
                                last_ps.clone()
                            } else {
                                crate::lower::model::Ex::XBlock(dos_po.clone(), Rc::new(last_ps.clone()))
                            },
                        }
                    },
                },
            }
        }
    }
}

/// The step machine of `TailFrom`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TailFrom: unbounded fn Lx, Env, Block, Nat -> Ex
/// ```
pub struct TailFrom {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub b_p2: crate::syntax::Block,
    pub i_p3: Nat,
}

impl prism_rtl::Job<crate::lower::model::Ex> for TailFrom {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::Ex> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let b_p2 = &self.b_p2;
        let i_p3 = &self.i_p3;
        let s_p4 = or(&index(&b_p2.stmts, i_p3), &crate::lower::expr::dummy_stmt_l());
        if &(i_p3 + &Nat::from(1u32)) >= &len(&b_p2.stmts) {
            match &s_p4.kind {
                crate::syntax::StmtKind::SExpr(x_p5) => prism_rtl::Turn::More(Rc::new(Tail { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), e_p2: x_p5.clone() })),
                _ => prism_rtl::Turn::Finished(crate::lower::model::Ex::XCtor(Text::lit("prism_rtl::Turn::Finished"), Array::from(vec![crate::lower::model::Ex::XUnit]))),
            }
        } else {
            {
                let found_o6 = match &s_p4.kind {
                    crate::syntax::StmtKind::SLet(_, _, x_p8) => frame_call(lx_p0, env_p1, x_p8, &false),
                    crate::syntax::StmtKind::SExpr(x_p9) => frame_call(lx_p0, env_p1, x_p9, &false),
                    _ => None,
                };
                let looping_o7 = match &s_p4.kind {
                    crate::syntax::StmtKind::SLet(p_pa, _, x_pb) => match &*x_pb.kind {
                        crate::syntax::ExprKind::EUpdate(target_pc, ub_pd) => if has_top_while(lx_p0, ub_pd) {
                            Some((p_pa.clone(), (**target_pc).clone(), ub_pd.clone(), x_pb.clone()))
                        } else {
                            None
                        },
                        _ => None,
                    },
                    _ => None,
                };
                match &looping_o7 {
                    Some((p_pe, target_pf, ub_pg, x_ph)) => prism_rtl::Turn::More(Rc::new(UpdTail { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), target_p2: target_pf.clone(), b_p3: ub_pg.clone(), to_p4: b_p2.span.clone(), cont_f5: {
                        let lx_p0 = lx_p0.clone();
                        let p_pe = p_pe.clone();
                        let x_ph = x_ph.clone();
                        let s_p4 = s_p4.clone();
                        let b_p2 = b_p2.clone();
                        let i_p3 = i_p3.clone();
                        Rc::new(move |(p0, p1): (crate::lower::types::Env, crate::lower::model::Ex)| {
                            let lx_p0 = lx_p0.clone();
                            let p_pe = p_pe.clone();
                            let x_ph = x_ph.clone();
                            let s_p4 = s_p4.clone();
                            let b_p2 = b_p2.clone();
                            let i_p3 = i_p3.clone();
                            entered(once_job(move || {
                                let en_pi = p0;
                                let v_pj = p1;
                                call_then(crate::lower::patterns::start_rust_pat(lx_p0.clone(), p_pe.clone(), crate::lower::type_at(&lx_p0, &x_ph.span), crate::lower::types::Holding::Owned, Text::from(format!("l{}", &s_p4.span.start))), move |rust_pat_4825: crate::lower::patterns::PatOut| {
                                    let po_pk = rust_pat_4825;
                                    call_then(start_tail_from(lx_p0.clone(), crate::lower::expr::bind_all(&en_pi, &po_pk.binds), b_p2.clone(), &i_p3 + &Nat::from(1u32)), move |tail_from_4917: crate::lower::model::Ex| {
                                        let rest_pl = tail_from_4917;
                                        prism_rtl::Turn::Finished(prepend(&Array::from(vec![crate::lower::model::Do::DoLet(po_pk.pa.clone(), v_pj.clone())]), &rest_pl))
                                    })
                                })
                            }))
                        }) as Rc<dyn Fn((crate::lower::types::Env, crate::lower::model::Ex)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
                    } })),
                    None => match &found_o6 {
                        Some(c_pm) => prism_rtl::Turn::More(Rc::new(Frame { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), call_p2: c_pm.clone(), rest_text_p3: rest_text(lx_p0, &s_p4.span, &c_pm.span, &b_p2.span), cont_f4: {
                            let lx_p0 = lx_p0.clone();
                            let b_p2 = b_p2.clone();
                            let i_p3 = i_p3.clone();
                            Rc::new(move |p0: crate::lower::types::Env| {
                                let lx_p0 = lx_p0.clone();
                                let b_p2 = b_p2.clone();
                                let i_p3 = i_p3.clone();
                                entered(once_job(move || {
                                    let env2_pn = p0;
                                    prism_rtl::Turn::More(Rc::new(TailFrom { lx_p0: lx_p0.clone(), env_p1: env2_pn.clone(), b_p2: b_p2.clone(), i_p3: i_p3.clone() }))
                                }))
                            }) as Rc<dyn Fn(crate::lower::types::Env) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
                        } })),
                        None => {
                            let b_p2 = b_p2.clone();
                            let env_p1 = env_p1.clone();
                            let i_p3 = i_p3.clone();
                            let lx_p0 = lx_p0.clone();
                            call_then(crate::lower::expr::start_block_stmt(lx_p0.clone(), env_p1.clone(), s_p4.clone()), move |block_stmt_5220: (Array<crate::lower::model::Do>, crate::lower::types::Env)| {
                                let (dos_po, env2_pp) = block_stmt_5220;
                                call_then(start_tail_from(lx_p0.clone(), env2_pp.clone(), b_p2.clone(), &i_p3 + &Nat::from(1u32)), move |tail_from_5267: crate::lower::model::Ex| match tail_from_5267 {
                                    crate::lower::model::Ex::XBlock(more_pq, last_pr) => prism_rtl::Turn::Finished(crate::lower::model::Ex::XBlock(append(&dos_po, &more_pq), Rc::new((*last_pr).clone()))),
                                    last_ps => if &len(&dos_po) == &Nat::from(0u32) {
                                        prism_rtl::Turn::Finished(last_ps.clone())
                                    } else {
                                        prism_rtl::Turn::Finished(crate::lower::model::Ex::XBlock(dos_po.clone(), Rc::new(last_ps.clone())))
                                    },
                                })
                            })
                        },
                    },
                }
            }
        }
    }
}

/// `Start TailFrom, x`: what the function value is when passed to `@Run`.
pub fn start_tail_from(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, b_p2: crate::syntax::Block, i_p3: Nat) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>> {
    Rc::new(TailFrom { lx_p0, env_p1, b_p2, i_p3 })
}

/// ```prism
/// HasTopWhile: fn Lx, Block -> Bool
/// ```
pub fn has_top_while(lx_p0: &crate::lower::Lx, b_p1: &crate::syntax::Block) -> bool {
    fold(&b_p1.stmts, &false, &(|f_p2: &bool, st_p3: &crate::syntax::Stmt| (*f_p2 || is_cycle_while(lx_p0, st_p3)) || holds_cycle_while(lx_p0, st_p3)))
}

/// ```prism
/// IsCycleWhile: fn Lx, Stmt -> Bool
/// ```
pub fn is_cycle_while(lx_p0: &crate::lower::Lx, st_p1: &crate::syntax::Stmt) -> bool {
    match &st_p1.kind {
        crate::syntax::StmtKind::SWhile(_, _) => crate::check::env::has_key(&lx_p0.unshrunk, &crate::lower::place_key(lx_p0, &st_p1.span)),
        _ => false,
    }
}

/// ```prism
/// ElseHasTopWhile: fn Lx, ?Block -> Bool
/// ```
pub fn else_has_top_while(lx_p0: &crate::lower::Lx, opt1: &Option<crate::syntax::Block>) -> bool {
    match opt1 {
        Some(b_p1) => has_top_while(lx_p0, b_p1),
        None => false,
    }
}

/// ```prism
/// HoldsCycleWhile: fn Lx, Stmt -> Bool
/// ```
pub fn holds_cycle_while(lx_p0: &crate::lower::Lx, st_p1: &crate::syntax::Stmt) -> bool {
    match &st_p1.kind {
        crate::syntax::StmtKind::SWhile(_, wb_p2) => has_top_while(lx_p0, wb_p2),
        crate::syntax::StmtKind::SExpr(x_p3) => match &*x_p3.kind {
            crate::syntax::ExprKind::EIf(_, then_b_p4, else_b_o5) => has_top_while(lx_p0, then_b_p4) || else_has_top_while(lx_p0, else_b_o5),
            crate::syntax::ExprKind::EMatch(_, arms_p6) => fold(arms_p6, &false, &(|f_p7: &bool, a_p8: &crate::syntax::Arm| *f_p7 || has_top_while(lx_p0, &a_p8.body))),
            crate::syntax::ExprKind::EFor(_, _, fb_p9) => has_top_while(lx_p0, fb_p9),
            _ => false,
        },
        _ => false,
    }
}

/// ```prism
/// UpdTail: unbounded fn Lx, Env, Expr, Block, Range, (unbounded fn Env, Ex -> Ex) -> Ex
/// ```
pub fn upd_tail(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, target_p2: &crate::syntax::Expr, b_p3: &crate::syntax::Block, to_p4: &crate::syntax::Range, cont_f5: &Rc<dyn Fn((crate::lower::types::Env, crate::lower::model::Ex)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>) -> crate::lower::model::Ex {
    let t_p6 = crate::lower::types::out_ty_of(lx_p0, &crate::lower::types::peel(&crate::lower::type_at(lx_p0, &target_p2.span)));
    let tv_p7 = crate::lower::expr::value_of(lx_p0, env_p1, target_p2);
    let env1_p8 = crate::lower::types::bind(env_p1, &Text::lit("&_"), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(Text::lit("this")), crate::lower::types::Holding::Owned, t_p6.clone()));
    prepend(&Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaMut(Text::lit("this"))), t_p6.clone()), crate::lower::types::own(&tv_p7))]), &upd_tail_from(lx_p0, env_p1, &env1_p8, b_p3, &Nat::from(0u32), to_p4, &cont_f5.clone()))
}

/// The step machine of `UpdTail`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UpdTail: unbounded fn Lx, Env, Expr, Block, Range, (unbounded fn Env, Ex -> Ex) -> Ex
/// ```
pub struct UpdTail {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub target_p2: crate::syntax::Expr,
    pub b_p3: crate::syntax::Block,
    pub to_p4: crate::syntax::Range,
    pub cont_f5: Rc<dyn Fn((crate::lower::types::Env, crate::lower::model::Ex)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>,
}

impl prism_rtl::Job<crate::lower::model::Ex> for UpdTail {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::Ex> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let target_p2 = &self.target_p2;
        let b_p3 = &self.b_p3;
        let to_p4 = &self.to_p4;
        let cont_f5 = &self.cont_f5;
        let cont_f5 = cont_f5.clone();
        let b_p3 = b_p3.clone();
        let env_p1 = env_p1.clone();
        let lx_p0 = lx_p0.clone();
        let target_p2 = target_p2.clone();
        let to_p4 = to_p4.clone();
        call_then(crate::lower::types::start_out_ty_of(lx_p0.clone(), crate::lower::types::peel(&crate::lower::type_at(&lx_p0, &target_p2.span))), move |out_ty_of_7825: crate::lower::model::OutTy| {
            let t_p6 = out_ty_of_7825;
            call_then(crate::lower::expr::start_value_of(lx_p0.clone(), env_p1.clone(), target_p2.clone()), move |value_of_7882: crate::lower::types::Vl| {
                let tv_p7 = value_of_7882;
                let env1_p8 = crate::lower::types::bind(&env_p1, &Text::lit("&_"), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(Text::lit("this")), crate::lower::types::Holding::Owned, t_p6.clone()));
                call_then(start_upd_tail_from(lx_p0.clone(), env_p1.clone(), env1_p8.clone(), b_p3.clone(), Nat::from(0u32), to_p4.clone(), cont_f5.clone()), move |upd_tail_from_8035: crate::lower::model::Ex| prism_rtl::Turn::Finished(prepend(&Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaMut(Text::lit("this"))), t_p6.clone()), crate::lower::types::own(&tv_p7))]), &upd_tail_from_8035)))
            })
        })
    }
}

/// `Start UpdTail, x`: what the function value is when passed to `@Run`.
pub fn start_upd_tail(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, target_p2: crate::syntax::Expr, b_p3: crate::syntax::Block, to_p4: crate::syntax::Range, cont_f5: Rc<dyn Fn((crate::lower::types::Env, crate::lower::model::Ex)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>> {
    Rc::new(UpdTail { lx_p0, env_p1, target_p2, b_p3, to_p4, cont_f5 })
}

/// ```prism
/// UpdTailFrom: unbounded fn Lx, Env, Env, Block, Nat, Range, (unbounded fn Env, Ex -> Ex) -> Ex
/// ```
pub fn upd_tail_from(lx_p0: &crate::lower::Lx, outer_p1: &crate::lower::types::Env, env_p2: &crate::lower::types::Env, b_p3: &crate::syntax::Block, i_p4: &Nat, to_p5: &crate::syntax::Range, cont_f6: &Rc<dyn Fn((crate::lower::types::Env, crate::lower::model::Ex)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>) -> crate::lower::model::Ex {
    if i_p4 >= &len(&b_p3.stmts) {
        run_to_end(cont_f6((outer_p1.clone(), crate::lower::model::Ex::XVar(Text::lit("this")))))
    } else {
        {
            let s_p7 = or(&index(&b_p3.stmts, i_p4), &crate::lower::expr::dummy_stmt_l());
            let rest_p8 = rest_text(lx_p0, &crate::syntax::Range { start: s_p7.span.end.clone(), end: s_p7.span.end.clone() }, &crate::syntax::Range { start: s_p7.span.end.clone(), end: s_p7.span.end.clone() }, to_p5);
            let next_f9 = {
                let lx_p0 = lx_p0.clone();
                let b_p3 = b_p3.clone();
                let i_p4 = i_p4.clone();
                let to_p5 = to_p5.clone();
                let cont_f6 = cont_f6.clone();
                Rc::new(move |(p0, p1): (crate::lower::types::Env, crate::lower::types::Env)| {
                    let lx_p0 = lx_p0.clone();
                    let b_p3 = b_p3.clone();
                    let i_p4 = i_p4.clone();
                    let to_p5 = to_p5.clone();
                    let cont_f6 = cont_f6.clone();
                    entered(once_job(move || {
                        let o2_pa = p0;
                        let e2_pb = p1;
                        prism_rtl::Turn::More(Rc::new(UpdTailFrom { lx_p0: lx_p0.clone(), outer_p1: o2_pa.clone(), env_p2: e2_pb.clone(), b_p3: b_p3.clone(), i_p4: &i_p4 + &Nat::from(1u32), to_p5: to_p5.clone(), cont_f6: cont_f6.clone() }))
                    }))
                }) as Rc<dyn Fn((crate::lower::types::Env, crate::lower::types::Env)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
            };
            if is_cycle_while(lx_p0, &s_p7) || holds_cycle_while(lx_p0, &s_p7) {
                stmt_job(lx_p0, outer_p1, env_p2, &s_p7, &rest_p8, &next_f9.clone())
            } else {
                {
                    let (dos_pc, env2_pd) = crate::lower::templates::upd_stmt(lx_p0, env_p2, &s_p7);
                    prepend(&dos_pc, &upd_tail_from(lx_p0, outer_p1, &env2_pd, b_p3, &(i_p4 + &Nat::from(1u32)), to_p5, &cont_f6.clone()))
                }
            }
        }
    }
}

/// The step machine of `UpdTailFrom`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UpdTailFrom: unbounded fn Lx, Env, Env, Block, Nat, Range, (unbounded fn Env, Ex -> Ex) -> Ex
/// ```
pub struct UpdTailFrom {
    pub lx_p0: crate::lower::Lx,
    pub outer_p1: crate::lower::types::Env,
    pub env_p2: crate::lower::types::Env,
    pub b_p3: crate::syntax::Block,
    pub i_p4: Nat,
    pub to_p5: crate::syntax::Range,
    pub cont_f6: Rc<dyn Fn((crate::lower::types::Env, crate::lower::model::Ex)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>,
}

impl prism_rtl::Job<crate::lower::model::Ex> for UpdTailFrom {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::Ex> {
        let lx_p0 = &self.lx_p0;
        let outer_p1 = &self.outer_p1;
        let env_p2 = &self.env_p2;
        let b_p3 = &self.b_p3;
        let i_p4 = &self.i_p4;
        let to_p5 = &self.to_p5;
        let cont_f6 = &self.cont_f6;
        if i_p4 >= &len(&b_p3.stmts) {
            cont_f6((outer_p1.clone(), crate::lower::model::Ex::XVar(Text::lit("this")))).cycle()
        } else {
            {
                let s_p7 = or(&index(&b_p3.stmts, i_p4), &crate::lower::expr::dummy_stmt_l());
                let rest_p8 = rest_text(lx_p0, &crate::syntax::Range { start: s_p7.span.end.clone(), end: s_p7.span.end.clone() }, &crate::syntax::Range { start: s_p7.span.end.clone(), end: s_p7.span.end.clone() }, to_p5);
                let next_f9 = {
                    let lx_p0 = lx_p0.clone();
                    let b_p3 = b_p3.clone();
                    let i_p4 = i_p4.clone();
                    let to_p5 = to_p5.clone();
                    let cont_f6 = cont_f6.clone();
                    Rc::new(move |(p0, p1): (crate::lower::types::Env, crate::lower::types::Env)| {
                        let lx_p0 = lx_p0.clone();
                        let b_p3 = b_p3.clone();
                        let i_p4 = i_p4.clone();
                        let to_p5 = to_p5.clone();
                        let cont_f6 = cont_f6.clone();
                        entered(once_job(move || {
                            let o2_pa = p0;
                            let e2_pb = p1;
                            prism_rtl::Turn::More(Rc::new(UpdTailFrom { lx_p0: lx_p0.clone(), outer_p1: o2_pa.clone(), env_p2: e2_pb.clone(), b_p3: b_p3.clone(), i_p4: &i_p4 + &Nat::from(1u32), to_p5: to_p5.clone(), cont_f6: cont_f6.clone() }))
                        }))
                    }) as Rc<dyn Fn((crate::lower::types::Env, crate::lower::types::Env)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
                };
                if is_cycle_while(lx_p0, &s_p7) || holds_cycle_while(lx_p0, &s_p7) {
                    prism_rtl::Turn::More(Rc::new(StmtJob { lx_p0: lx_p0.clone(), outer_p1: outer_p1.clone(), env_p2: env_p2.clone(), s_p3: s_p7.clone(), rest_p4: rest_p8.clone(), cont_f5: next_f9.clone() }))
                } else {
                    {
                        let cont_f6 = cont_f6.clone();
                        let b_p3 = b_p3.clone();
                        let env_p2 = env_p2.clone();
                        let i_p4 = i_p4.clone();
                        let lx_p0 = lx_p0.clone();
                        let outer_p1 = outer_p1.clone();
                        let to_p5 = to_p5.clone();
                        call_then(crate::lower::templates::start_upd_stmt(lx_p0.clone(), env_p2.clone(), s_p7.clone()), move |upd_stmt_8662: (Array<crate::lower::model::Do>, crate::lower::types::Env)| {
                            let (dos_pc, env2_pd) = upd_stmt_8662;
                            call_then(start_upd_tail_from(lx_p0.clone(), outer_p1.clone(), env2_pd.clone(), b_p3.clone(), &i_p4 + &Nat::from(1u32), to_p5.clone(), cont_f6.clone()), move |upd_tail_from_8707: crate::lower::model::Ex| prism_rtl::Turn::Finished(prepend(&dos_pc, &upd_tail_from_8707)))
                        })
                    }
                }
            }
        }
    }
}

/// `Start UpdTailFrom, x`: what the function value is when passed to `@Run`.
pub fn start_upd_tail_from(lx_p0: crate::lower::Lx, outer_p1: crate::lower::types::Env, env_p2: crate::lower::types::Env, b_p3: crate::syntax::Block, i_p4: Nat, to_p5: crate::syntax::Range, cont_f6: Rc<dyn Fn((crate::lower::types::Env, crate::lower::model::Ex)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>> {
    Rc::new(UpdTailFrom { lx_p0, outer_p1, env_p2, b_p3, i_p4, to_p5, cont_f6 })
}

/// ```prism
/// StmtJob: unbounded fn Lx, Env, Env, Stmt, Text, (unbounded fn Env, Env -> Ex) -> Ex
/// ```
pub fn stmt_job(lx_p0: &crate::lower::Lx, outer_p1: &crate::lower::types::Env, env_p2: &crate::lower::types::Env, s_p3: &crate::syntax::Stmt, rest_p4: &Text, cont_f5: &Rc<dyn Fn((crate::lower::types::Env, crate::lower::types::Env)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>) -> crate::lower::model::Ex {
    match &s_p3.kind {
        crate::syntax::StmtKind::SWhile(c_p6, wb_p7) => while_job(lx_p0, outer_p1, env_p2, c_p6, wb_p7, &s_p3.span, rest_p4, &cont_f5.clone()),
        crate::syntax::StmtKind::SExpr(x_p8) => match &*x_p8.kind {
            crate::syntax::ExprKind::EIf(c_p9, then_b_pa, else_b_ob) => if_job(lx_p0, outer_p1, env_p2, &**c_p9, then_b_pa, else_b_ob, &s_p3.span, rest_p4, &cont_f5.clone()),
            crate::syntax::ExprKind::EMatch(scrut_pc, arms_pd) => match_job(lx_p0, outer_p1, env_p2, &**scrut_pc, arms_pd, &s_p3.span, rest_p4, &cont_f5.clone()),
            crate::syntax::ExprKind::EFor(binders_oe, source_pf, body_pg) => match crate::lower::templates::ref_binder(binders_oe) {
                Some(_) => crate::lower::expr::refusal(&Text::lit("a cycle-point `while` in a `for &` of an `update` block, whose references a job cannot keep (gap LP)")),
                None => for_job(lx_p0, outer_p1, env_p2, binders_oe, &**source_pf, body_pg, &s_p3.span, rest_p4, &cont_f5.clone()),
            },
            _ => crate::lower::expr::refusal(&Text::from(format!("a cycle-point `while` in {} (gap LP)", &crate::lower::expr::kind_words(&*x_p8.kind)))),
        },
        _ => crate::lower::expr::refusal(&Text::lit("a cycle-point `while` in this statement (gap LP)")),
    }
}

/// The step machine of `StmtJob`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// StmtJob: unbounded fn Lx, Env, Env, Stmt, Text, (unbounded fn Env, Env -> Ex) -> Ex
/// ```
pub struct StmtJob {
    pub lx_p0: crate::lower::Lx,
    pub outer_p1: crate::lower::types::Env,
    pub env_p2: crate::lower::types::Env,
    pub s_p3: crate::syntax::Stmt,
    pub rest_p4: Text,
    pub cont_f5: Rc<dyn Fn((crate::lower::types::Env, crate::lower::types::Env)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>,
}

impl prism_rtl::Job<crate::lower::model::Ex> for StmtJob {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::Ex> {
        let lx_p0 = &self.lx_p0;
        let outer_p1 = &self.outer_p1;
        let env_p2 = &self.env_p2;
        let s_p3 = &self.s_p3;
        let rest_p4 = &self.rest_p4;
        let cont_f5 = &self.cont_f5;
        match &s_p3.kind {
            crate::syntax::StmtKind::SWhile(c_p6, wb_p7) => prism_rtl::Turn::More(Rc::new(WhileJob { lx_p0: lx_p0.clone(), outer_p1: outer_p1.clone(), env_p2: env_p2.clone(), c_p3: c_p6.clone(), wb_p4: wb_p7.clone(), span_p5: s_p3.span.clone(), rest_text_p6: rest_p4.clone(), cont_f7: cont_f5.clone() })),
            crate::syntax::StmtKind::SExpr(x_p8) => match &*x_p8.kind {
                crate::syntax::ExprKind::EIf(c_p9, then_b_pa, else_b_ob) => prism_rtl::Turn::More(Rc::new(IfJob { lx_p0: lx_p0.clone(), outer_p1: outer_p1.clone(), env_p2: env_p2.clone(), c_p3: (**c_p9).clone(), then_b_p4: then_b_pa.clone(), else_b_o5: else_b_ob.clone(), span_p6: s_p3.span.clone(), rest_text_p7: rest_p4.clone(), cont_f8: cont_f5.clone() })),
                crate::syntax::ExprKind::EMatch(scrut_pc, arms_pd) => prism_rtl::Turn::More(Rc::new(MatchJob { lx_p0: lx_p0.clone(), outer_p1: outer_p1.clone(), env_p2: env_p2.clone(), scrut_p3: (**scrut_pc).clone(), arms_p4: arms_pd.clone(), span_p5: s_p3.span.clone(), rest_text_p6: rest_p4.clone(), cont_f7: cont_f5.clone() })),
                crate::syntax::ExprKind::EFor(binders_oe, source_pf, body_pg) => match crate::lower::templates::ref_binder(binders_oe) {
                    Some(_) => prism_rtl::Turn::Finished(crate::lower::expr::refusal(&Text::lit("a cycle-point `while` in a `for &` of an `update` block, whose references a job cannot keep (gap LP)"))),
                    None => prism_rtl::Turn::More(Rc::new(ForJob { lx_p0: lx_p0.clone(), outer_p1: outer_p1.clone(), env_p2: env_p2.clone(), binders_o3: binders_oe.clone(), source_p4: (**source_pf).clone(), body_p5: body_pg.clone(), span_p6: s_p3.span.clone(), rest_text_p7: rest_p4.clone(), cont_f8: cont_f5.clone() })),
                },
                _ => prism_rtl::Turn::Finished(crate::lower::expr::refusal(&Text::from(format!("a cycle-point `while` in {} (gap LP)", &crate::lower::expr::kind_words(&*x_p8.kind))))),
            },
            _ => prism_rtl::Turn::Finished(crate::lower::expr::refusal(&Text::lit("a cycle-point `while` in this statement (gap LP)"))),
        }
    }
}

/// `Start StmtJob, x`: what the function value is when passed to `@Run`.
pub fn start_stmt_job(lx_p0: crate::lower::Lx, outer_p1: crate::lower::types::Env, env_p2: crate::lower::types::Env, s_p3: crate::syntax::Stmt, rest_p4: Text, cont_f5: Rc<dyn Fn((crate::lower::types::Env, crate::lower::types::Env)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>> {
    Rc::new(StmtJob { lx_p0, outer_p1, env_p2, s_p3, rest_p4, cont_f5 })
}

/// ```prism
/// Prepend: fn [Do], Ex -> Ex
/// ```
pub fn prepend(dos_p0: &Array<crate::lower::model::Do>, ex1: &crate::lower::model::Ex) -> crate::lower::model::Ex {
    match ex1 {
        crate::lower::model::Ex::XBlock(more_p1, last_p2) => crate::lower::model::Ex::XBlock(append(dos_p0, more_p1), Rc::new((**last_p2).clone())),
        x_p4 => if &len(dos_p0) == &Nat::from(0u32) {
            x_p4.clone()
        } else {
            crate::lower::model::Ex::XBlock(dos_p0.clone(), Rc::new(x_p4.clone()))
        },
    }
}

/// ```prism
/// WhileJob: unbounded fn Lx, Env, Env, Cond, Block, Range, Text, (unbounded fn Env, Env -> Ex) -> Ex
/// ```
pub fn while_job(lx_p0: &crate::lower::Lx, outer_p1: &crate::lower::types::Env, env_p2: &crate::lower::types::Env, c_p3: &crate::syntax::Cond, wb_p4: &crate::syntax::Block, span_p5: &crate::syntax::Range, rest_text_p6: &Text, cont_f7: &Rc<dyn Fn((crate::lower::types::Env, crate::lower::types::Env)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>) -> crate::lower::model::Ex {
    let state_p8 = fold(&keys(&env_p2.names), &Array::new(), &(|acc_p11: &Array<(Text, Text, crate::lower::model::OutTy)>, k_p12: &Text| if !crate::syntax::lexer::chars::has_prefix(k_p12, &Text::lit("&")) {
        acc_p11.clone()
    } else {
        match get(&env_p2.names, k_p12) {
            Some(crate::lower::types::Bn::BnLocal(rs_p13, _, bt_p14)) => push(acc_p11, &(k_p12.clone(), crate::lower::types::place_stem(&rs_p13), bt_p14)),
            _ => acc_p11.clone(),
        }
    }));
    let names_p9 = each(&state_p8, &(|(_, rs_p15, _): &(Text, Text, crate::lower::model::OutTy)| rs_p15.clone()));
    let st_ty_pa = crate::lower::model::OutTy::OutTuple(each(&state_p8, &(|(_, _, bt_p16): &(Text, Text, crate::lower::model::OutTy)| bt_p16.clone())));
    let pat_pb = crate::lower::model::Pa::PaTuple(each(&names_p9, &(|n_p17: &Text| crate::lower::model::Pa::PaMut(Text::from(format!("{}", n_p17))))));
    let pack_pc = crate::lower::model::Ex::XTuple(each(&names_p9, &(|n_p18: &Text| crate::lower::model::Ex::XVar(n_p18.clone()))));
    let env_s_pd = fold(&state_p8, env_p2, &(|en_p19: &crate::lower::types::Env, (k_p1a, rs_p1b, bt_p1c): &(Text, Text, crate::lower::model::OutTy)| crate::lower::types::bind(en_p19, k_p1a, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(rs_p1b.clone()), crate::lower::types::Holding::Owned, bt_p1c.clone()))));
    let loop_text_pe = match index(&lx_p0.g.srcs, &lx_p0.file) {
        Some(src_p1d) => crate::check::errors::span_text(&src_p1d, span_p5),
        None => Text::lit(""),
    };
    let caps_pf = caps_in(&env_s_pd, &loop_text_pe, &names_p9);
    let cap_dos_pg = each(&caps_pf, &(|(_, rs_p1e, mode_p1f, bt_p1g): &(Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)| crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::lower::types::place_stem(rs_p1e)), crate::lower::types::own(&crate::lower::types::Vl::VlPlace(rs_p1e.clone(), mode_p1f.clone(), bt_p1g.clone())))));
    let env_c_ph = fold(&caps_pf, &env_s_pd, &(|en_p1h: &crate::lower::types::Env, (k_p1i, rs_p1j, _, bt_p1k): &(Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)| crate::lower::types::bind(en_p1h, k_p1i, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(crate::lower::types::place_stem(rs_p1j)), crate::lower::types::Holding::Owned, bt_p1k.clone()))));
    let jobs_pi = has_top_while(lx_p0, wb_p4);
    let finish_fj = {
        let jobs_pi = jobs_pi;
        Rc::new(move |x_p1l: &crate::lower::model::Ex| if jobs_pi {
            crate::lower::model::Ex::XCtor(Text::lit("prism_rtl::Turn::Finished"), Array::from(vec![x_p1l.clone()]))
        } else {
            x_p1l.clone()
        }) as Rc<dyn Fn(&crate::lower::model::Ex) -> crate::lower::model::Ex>
    };
    let step_ty_pk = crate::lower::model::OutTy::OutNamed(Text::lit("Result"), Array::from(vec![st_ty_pa.clone(), st_ty_pa.clone()]));
    let again_pl = (&finish_fj)(&crate::lower::model::Ex::XTyped(Rc::new(crate::lower::model::Ex::XCtor(Text::lit("Ok"), Array::from(vec![pack_pc.clone()]))), step_ty_pk.clone()));
    let stop_pm = (&finish_fj)(&crate::lower::model::Ex::XTyped(Rc::new(crate::lower::model::Ex::XCtor(Text::lit("Err"), Array::from(vec![pack_pc.clone()]))), step_ty_pk.clone()));
    let body_fn = {
        let jobs_pi = jobs_pi;
        let lx_p0 = lx_p0.clone();
        let wb_p4 = wb_p4.clone();
        let again_pl = again_pl.clone();
        Rc::new(move |p0: crate::lower::types::Env| {
            let jobs_pi = jobs_pi;
            let lx_p0 = lx_p0.clone();
            let wb_p4 = wb_p4.clone();
            let again_pl = again_pl.clone();
            entered(once_job(move || {
                let en_p1m = p0;
                if jobs_pi {
                    prism_rtl::Turn::More(Rc::new(UpdTailFrom { lx_p0: lx_p0.clone(), outer_p1: en_p1m.clone(), env_p2: en_p1m.clone(), b_p3: wb_p4.clone(), i_p4: Nat::from(0u32), to_p5: wb_p4.span.clone(), cont_f6: {
                        let again_pl = again_pl.clone();
                        Rc::new(move |(p0, p1): (crate::lower::types::Env, crate::lower::model::Ex)| {
                            let again_pl = again_pl.clone();
                            once_job(move || {
                                let o2_p1n = p0;
                                let e2_p1o = p1;
                                prism_rtl::Turn::Finished(again_pl.clone())
                            })
                        }) as Rc<dyn Fn((crate::lower::types::Env, crate::lower::model::Ex)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
                    } }))
                } else {
                    prism_rtl::Turn::More(Rc::new(StmtsThen { lx_p0: lx_p0.clone(), env_p1: en_p1m.clone(), b_p2: wb_p4.clone(), last_p3: again_pl.clone() }))
                }
            }))
        }) as Rc<dyn Fn(crate::lower::types::Env) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
    };
    let res_ty_po = if jobs_pi {
        crate::lower::model::OutTy::OutNamed(Text::lit("prism_rtl::Turn"), Array::from(vec![step_ty_pk.clone()]))
    } else {
        st_ty_pa.clone()
    };
    let turn_pp = match c_p3 {
        crate::syntax::Cond::CondExpr(x_p1p) => crate::lower::model::Ex::XIf(Rc::new(crate::lower::types::as_bool(&crate::lower::expr::value_of(lx_p0, &env_c_ph, &**x_p1p))), Rc::new(run_to_end((&body_fn)(env_c_ph.clone()))), Rc::new(stop_pm.clone())),
        crate::syntax::Cond::CondBind(p_p1q, x_p1r, g_o1s) => {
            let po_p1t = crate::lower::patterns::rust_pat(lx_p0, p_p1q, &crate::lower::type_at(lx_p0, &x_p1r.span), &crate::lower::types::Holding::Owned, &Text::from(format!("w{}", &span_p5.start)));
            let env_b_p1u = crate::lower::expr::bind_all(&env_c_ph, &po_p1t.binds);
            let conds_p1v = append(&po_p1t.conds, &crate::lower::templates::guard_conds(lx_p0, &env_b_p1u, &**g_o1s));
            crate::lower::types::own(&crate::lower::expr::arms_value(&crate::lower::types::own(&crate::lower::expr::value_of(lx_p0, &env_c_ph, &**x_p1r)), &Array::from(vec![crate::lower::model::XArm { pat: po_p1t.pa.clone(), conds: conds_p1v.clone(), body: run_to_end((&body_fn)(env_b_p1u.clone())) }, crate::lower::model::XArm { pat: crate::lower::model::Pa::PaWild, conds: Array::new(), body: stop_pm.clone() }]), &Text::from(format!("\'w{}", &span_p5.start)), &res_ty_po))
        },
    };
    let out_caps_pq = caps_in(outer_p1, rest_text_p6, &names_p9);
    let out_dos_pr = each(&out_caps_pq, &(|(_, rs_p20, mode_p21, bt_p22): &(Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)| crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::lower::types::place_stem(rs_p20)), crate::lower::types::own(&crate::lower::types::Vl::VlPlace(rs_p20.clone(), mode_p21.clone(), bt_p22.clone())))));
    let outer2_ps = fold(&out_caps_pq, outer_p1, &(|en_p23: &crate::lower::types::Env, (k_p24, rs_p25, _, bt_p26): &(Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)| crate::lower::types::bind(en_p23, k_p24, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(crate::lower::types::place_stem(rs_p25)), crate::lower::types::Holding::Owned, bt_p26.clone()))));
    let env2_pt = fold(&out_caps_pq, &env_s_pd, &(|en_p27: &crate::lower::types::Env, (k_p28, rs_p29, _, bt_p2a): &(Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)| crate::lower::types::bind(en_p27, k_p28, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(crate::lower::types::place_stem(rs_p29)), crate::lower::types::Holding::Owned, bt_p2a.clone()))));
    let step_fn_pu = prepend(&cap_dos_pg, &crate::lower::model::Ex::XClosure(true, Array::from(vec![crate::lower::model::Pa::PaTyped(Rc::new(pat_pb.clone()), st_ty_pa.clone())]), Rc::new(turn_pp.clone())));
    let looping_pv = if jobs_pi { Text::lit("loop_turns") } else { Text::lit("loop_job") };
    let enter_p10 = crate::lower::model::Ex::XCall(Text::lit("call_then"), Array::from(vec![crate::lower::model::Ex::XCall(looping_pv.clone(), Array::from(vec![pack_pc.clone(), step_fn_pu.clone()])), crate::lower::model::Ex::XClosure(true, Array::from(vec![crate::lower::model::Pa::PaTyped(Rc::new(pat_pb.clone()), st_ty_pa.clone())]), Rc::new(run_to_end(cont_f7((outer2_ps.clone(), env2_pt.clone())))))]));
    prepend(&out_dos_pr, &enter_p10)
}

/// The step machine of `WhileJob`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// WhileJob: unbounded fn Lx, Env, Env, Cond, Block, Range, Text, (unbounded fn Env, Env -> Ex) -> Ex
/// ```
pub struct WhileJob {
    pub lx_p0: crate::lower::Lx,
    pub outer_p1: crate::lower::types::Env,
    pub env_p2: crate::lower::types::Env,
    pub c_p3: crate::syntax::Cond,
    pub wb_p4: crate::syntax::Block,
    pub span_p5: crate::syntax::Range,
    pub rest_text_p6: Text,
    pub cont_f7: Rc<dyn Fn((crate::lower::types::Env, crate::lower::types::Env)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>,
}

impl prism_rtl::Job<crate::lower::model::Ex> for WhileJob {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::Ex> {
        let lx_p0 = &self.lx_p0;
        let outer_p1 = &self.outer_p1;
        let env_p2 = &self.env_p2;
        let c_p3 = &self.c_p3;
        let wb_p4 = &self.wb_p4;
        let span_p5 = &self.span_p5;
        let rest_text_p6 = &self.rest_text_p6;
        let cont_f7 = &self.cont_f7;
        let state_p8 = fold(&keys(&env_p2.names), &Array::new(), &(|acc_p11: &Array<(Text, Text, crate::lower::model::OutTy)>, k_p12: &Text| if !crate::syntax::lexer::chars::has_prefix(k_p12, &Text::lit("&")) {
            acc_p11.clone()
        } else {
            match get(&env_p2.names, k_p12) {
                Some(crate::lower::types::Bn::BnLocal(rs_p13, _, bt_p14)) => push(acc_p11, &(k_p12.clone(), crate::lower::types::place_stem(&rs_p13), bt_p14)),
                _ => acc_p11.clone(),
            }
        }));
        let names_p9 = each(&state_p8, &(|(_, rs_p15, _): &(Text, Text, crate::lower::model::OutTy)| rs_p15.clone()));
        let st_ty_pa = crate::lower::model::OutTy::OutTuple(each(&state_p8, &(|(_, _, bt_p16): &(Text, Text, crate::lower::model::OutTy)| bt_p16.clone())));
        let pat_pb = crate::lower::model::Pa::PaTuple(each(&names_p9, &(|n_p17: &Text| crate::lower::model::Pa::PaMut(Text::from(format!("{}", n_p17))))));
        let pack_pc = crate::lower::model::Ex::XTuple(each(&names_p9, &(|n_p18: &Text| crate::lower::model::Ex::XVar(n_p18.clone()))));
        let env_s_pd = fold(&state_p8, env_p2, &(|en_p19: &crate::lower::types::Env, (k_p1a, rs_p1b, bt_p1c): &(Text, Text, crate::lower::model::OutTy)| crate::lower::types::bind(en_p19, k_p1a, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(rs_p1b.clone()), crate::lower::types::Holding::Owned, bt_p1c.clone()))));
        let loop_text_pe = match index(&lx_p0.g.srcs, &lx_p0.file) {
            Some(src_p1d) => crate::check::errors::span_text(&src_p1d, span_p5),
            None => Text::lit(""),
        };
        let caps_pf = caps_in(&env_s_pd, &loop_text_pe, &names_p9);
        let cap_dos_pg = each(&caps_pf, &(|(_, rs_p1e, mode_p1f, bt_p1g): &(Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)| crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::lower::types::place_stem(rs_p1e)), crate::lower::types::own(&crate::lower::types::Vl::VlPlace(rs_p1e.clone(), mode_p1f.clone(), bt_p1g.clone())))));
        let env_c_ph = fold(&caps_pf, &env_s_pd, &(|en_p1h: &crate::lower::types::Env, (k_p1i, rs_p1j, _, bt_p1k): &(Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)| crate::lower::types::bind(en_p1h, k_p1i, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(crate::lower::types::place_stem(rs_p1j)), crate::lower::types::Holding::Owned, bt_p1k.clone()))));
        let jobs_pi = has_top_while(lx_p0, wb_p4);
        let finish_fj = {
            let jobs_pi = jobs_pi;
            Rc::new(move |x_p1l: &crate::lower::model::Ex| if jobs_pi {
                crate::lower::model::Ex::XCtor(Text::lit("prism_rtl::Turn::Finished"), Array::from(vec![x_p1l.clone()]))
            } else {
                x_p1l.clone()
            }) as Rc<dyn Fn(&crate::lower::model::Ex) -> crate::lower::model::Ex>
        };
        let step_ty_pk = crate::lower::model::OutTy::OutNamed(Text::lit("Result"), Array::from(vec![st_ty_pa.clone(), st_ty_pa.clone()]));
        let again_pl = (&finish_fj)(&crate::lower::model::Ex::XTyped(Rc::new(crate::lower::model::Ex::XCtor(Text::lit("Ok"), Array::from(vec![pack_pc.clone()]))), step_ty_pk.clone()));
        let stop_pm = (&finish_fj)(&crate::lower::model::Ex::XTyped(Rc::new(crate::lower::model::Ex::XCtor(Text::lit("Err"), Array::from(vec![pack_pc.clone()]))), step_ty_pk.clone()));
        let body_fn = {
            let jobs_pi = jobs_pi;
            let lx_p0 = lx_p0.clone();
            let wb_p4 = wb_p4.clone();
            let again_pl = again_pl.clone();
            Rc::new(move |p0: crate::lower::types::Env| {
                let jobs_pi = jobs_pi;
                let lx_p0 = lx_p0.clone();
                let wb_p4 = wb_p4.clone();
                let again_pl = again_pl.clone();
                entered(once_job(move || {
                    let en_p1m = p0;
                    if jobs_pi {
                        prism_rtl::Turn::More(Rc::new(UpdTailFrom { lx_p0: lx_p0.clone(), outer_p1: en_p1m.clone(), env_p2: en_p1m.clone(), b_p3: wb_p4.clone(), i_p4: Nat::from(0u32), to_p5: wb_p4.span.clone(), cont_f6: {
                            let again_pl = again_pl.clone();
                            Rc::new(move |(p0, p1): (crate::lower::types::Env, crate::lower::model::Ex)| {
                                let again_pl = again_pl.clone();
                                once_job(move || {
                                    let o2_p1n = p0;
                                    let e2_p1o = p1;
                                    prism_rtl::Turn::Finished(again_pl.clone())
                                })
                            }) as Rc<dyn Fn((crate::lower::types::Env, crate::lower::model::Ex)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
                        } }))
                    } else {
                        prism_rtl::Turn::More(Rc::new(StmtsThen { lx_p0: lx_p0.clone(), env_p1: en_p1m.clone(), b_p2: wb_p4.clone(), last_p3: again_pl.clone() }))
                    }
                }))
            }) as Rc<dyn Fn(crate::lower::types::Env) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
        };
        let res_ty_po = if jobs_pi {
            crate::lower::model::OutTy::OutNamed(Text::lit("prism_rtl::Turn"), Array::from(vec![step_ty_pk.clone()]))
        } else {
            st_ty_pa.clone()
        };
        let turn_pp = match c_p3 {
            crate::syntax::Cond::CondExpr(x_p1p) => crate::lower::model::Ex::XIf(Rc::new(crate::lower::types::as_bool(&crate::lower::expr::value_of(lx_p0, &env_c_ph, &**x_p1p))), Rc::new(run_to_end((&body_fn)(env_c_ph.clone()))), Rc::new(stop_pm.clone())),
            crate::syntax::Cond::CondBind(p_p1q, x_p1r, g_o1s) => {
                let po_p1t = crate::lower::patterns::rust_pat(lx_p0, p_p1q, &crate::lower::type_at(lx_p0, &x_p1r.span), &crate::lower::types::Holding::Owned, &Text::from(format!("w{}", &span_p5.start)));
                let env_b_p1u = crate::lower::expr::bind_all(&env_c_ph, &po_p1t.binds);
                let conds_p1v = append(&po_p1t.conds, &crate::lower::templates::guard_conds(lx_p0, &env_b_p1u, &**g_o1s));
                crate::lower::types::own(&crate::lower::expr::arms_value(&crate::lower::types::own(&crate::lower::expr::value_of(lx_p0, &env_c_ph, &**x_p1r)), &Array::from(vec![crate::lower::model::XArm { pat: po_p1t.pa.clone(), conds: conds_p1v.clone(), body: run_to_end((&body_fn)(env_b_p1u.clone())) }, crate::lower::model::XArm { pat: crate::lower::model::Pa::PaWild, conds: Array::new(), body: stop_pm.clone() }]), &Text::from(format!("\'w{}", &span_p5.start)), &res_ty_po))
            },
        };
        let out_caps_pq = caps_in(outer_p1, rest_text_p6, &names_p9);
        let out_dos_pr = each(&out_caps_pq, &(|(_, rs_p20, mode_p21, bt_p22): &(Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)| crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::lower::types::place_stem(rs_p20)), crate::lower::types::own(&crate::lower::types::Vl::VlPlace(rs_p20.clone(), mode_p21.clone(), bt_p22.clone())))));
        let outer2_ps = fold(&out_caps_pq, outer_p1, &(|en_p23: &crate::lower::types::Env, (k_p24, rs_p25, _, bt_p26): &(Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)| crate::lower::types::bind(en_p23, k_p24, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(crate::lower::types::place_stem(rs_p25)), crate::lower::types::Holding::Owned, bt_p26.clone()))));
        let env2_pt = fold(&out_caps_pq, &env_s_pd, &(|en_p27: &crate::lower::types::Env, (k_p28, rs_p29, _, bt_p2a): &(Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)| crate::lower::types::bind(en_p27, k_p28, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(crate::lower::types::place_stem(rs_p29)), crate::lower::types::Holding::Owned, bt_p2a.clone()))));
        let step_fn_pu = prepend(&cap_dos_pg, &crate::lower::model::Ex::XClosure(true, Array::from(vec![crate::lower::model::Pa::PaTyped(Rc::new(pat_pb.clone()), st_ty_pa.clone())]), Rc::new(turn_pp.clone())));
        let looping_pv = if jobs_pi { Text::lit("loop_turns") } else { Text::lit("loop_job") };
        let cont_f7 = cont_f7.clone();
        call_value((&cont_f7)((outer2_ps.clone(), env2_pt.clone())), move |cont_13212: crate::lower::model::Ex| {
            let enter_p10 = crate::lower::model::Ex::XCall(Text::lit("call_then"), Array::from(vec![crate::lower::model::Ex::XCall(looping_pv.clone(), Array::from(vec![pack_pc.clone(), step_fn_pu.clone()])), crate::lower::model::Ex::XClosure(true, Array::from(vec![crate::lower::model::Pa::PaTyped(Rc::new(pat_pb.clone()), st_ty_pa.clone())]), Rc::new(cont_13212))]));
            prism_rtl::Turn::Finished(prepend(&out_dos_pr, &enter_p10))
        })
    }
}

/// `Start WhileJob, x`: what the function value is when passed to `@Run`.
pub fn start_while_job(lx_p0: crate::lower::Lx, outer_p1: crate::lower::types::Env, env_p2: crate::lower::types::Env, c_p3: crate::syntax::Cond, wb_p4: crate::syntax::Block, span_p5: crate::syntax::Range, rest_text_p6: Text, cont_f7: Rc<dyn Fn((crate::lower::types::Env, crate::lower::types::Env)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>> {
    Rc::new(WhileJob { lx_p0, outer_p1, env_p2, c_p3, wb_p4, span_p5, rest_text_p6, cont_f7 })
}

/// ```prism
/// StmtsThen: unbounded fn Lx, Env, Block, Ex -> Ex
/// ```
pub fn stmts_then(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, b_p2: &crate::syntax::Block, last_p3: &crate::lower::model::Ex) -> crate::lower::model::Ex {
    let (dos_p4, _) = crate::lower::templates::upd_stmts(lx_p0, env_p1, &b_p2.stmts);
    crate::lower::model::Ex::XBlock(dos_p4.clone(), Rc::new(last_p3.clone()))
}

/// The step machine of `StmtsThen`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// StmtsThen: unbounded fn Lx, Env, Block, Ex -> Ex
/// ```
pub struct StmtsThen {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub b_p2: crate::syntax::Block,
    pub last_p3: crate::lower::model::Ex,
}

impl prism_rtl::Job<crate::lower::model::Ex> for StmtsThen {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::Ex> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let b_p2 = &self.b_p2;
        let last_p3 = &self.last_p3;
        let b_p2 = b_p2.clone();
        let env_p1 = env_p1.clone();
        let last_p3 = last_p3.clone();
        let lx_p0 = lx_p0.clone();
        call_then(crate::lower::templates::start_upd_stmts(lx_p0.clone(), env_p1.clone(), b_p2.stmts.clone()), move |upd_stmts_13425: (Array<crate::lower::model::Do>, crate::lower::types::Env)| {
            let (dos_p4, _) = upd_stmts_13425;
            prism_rtl::Turn::Finished(crate::lower::model::Ex::XBlock(dos_p4.clone(), Rc::new(last_p3.clone())))
        })
    }
}

/// `Start StmtsThen, x`: what the function value is when passed to `@Run`.
pub fn start_stmts_then(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, b_p2: crate::syntax::Block, last_p3: crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>> {
    Rc::new(StmtsThen { lx_p0, env_p1, b_p2, last_p3 })
}

/// ```prism
/// IfJob: unbounded fn Lx, Env, Env, Cond, Block, ?Block, Range, Text, (unbounded fn Env, Env -> Ex) -> Ex
/// ```
pub fn if_job(lx_p0: &crate::lower::Lx, outer_p1: &crate::lower::types::Env, env_p2: &crate::lower::types::Env, c_p3: &crate::syntax::Cond, then_b_p4: &crate::syntax::Block, else_b_o5: &Option<crate::syntax::Block>, span_p6: &crate::syntax::Range, rest_text_p7: &Text, cont_f8: &Rc<dyn Fn((crate::lower::types::Env, crate::lower::types::Env)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>) -> crate::lower::model::Ex {
    let state_p9 = fold(&keys(&env_p2.names), &Array::new(), &(|acc_pp: &Array<(Text, Text, crate::lower::model::OutTy)>, k_pq: &Text| if !crate::syntax::lexer::chars::has_prefix(k_pq, &Text::lit("&")) {
        acc_pp.clone()
    } else {
        match get(&env_p2.names, k_pq) {
            Some(crate::lower::types::Bn::BnLocal(rs_pr, _, bt_ps)) => push(acc_pp, &(k_pq.clone(), crate::lower::types::place_stem(&rs_pr), bt_ps)),
            _ => acc_pp.clone(),
        }
    }));
    let names_pa = each(&state_p9, &(|(_, rs_pt, _): &(Text, Text, crate::lower::model::OutTy)| rs_pt.clone()));
    let st_ty_pb = crate::lower::model::OutTy::OutTuple(each(&state_p9, &(|(_, _, bt_pu): &(Text, Text, crate::lower::model::OutTy)| bt_pu.clone())));
    let pat_pc = crate::lower::model::Pa::PaTuple(each(&names_pa, &(|n_pv: &Text| crate::lower::model::Pa::PaMut(Text::from(format!("{}", n_pv))))));
    let pack_pd = crate::lower::model::Ex::XTuple(each(&names_pa, &(|n_p10: &Text| crate::lower::model::Ex::XVar(n_p10.clone()))));
    let env_s_pe = fold(&state_p9, env_p2, &(|en_p11: &crate::lower::types::Env, (k_p12, rs_p13, bt_p14): &(Text, Text, crate::lower::model::OutTy)| crate::lower::types::bind(en_p11, k_p12, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(rs_p13.clone()), crate::lower::types::Holding::Owned, bt_p14.clone()))));
    let out_caps_pf = caps_in(outer_p1, rest_text_p7, &names_pa);
    let out_dos_pg = each(&out_caps_pf, &(|(_, rs_p15, mode_p16, bt_p17): &(Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)| crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::lower::types::place_stem(rs_p15)), crate::lower::types::own(&crate::lower::types::Vl::VlPlace(rs_p15.clone(), mode_p16.clone(), bt_p17.clone())))));
    let outer2_ph = fold(&out_caps_pf, outer_p1, &(|en_p18: &crate::lower::types::Env, (k_p19, rs_p1a, _, bt_p1b): &(Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)| crate::lower::types::bind(en_p18, k_p19, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(crate::lower::types::place_stem(rs_p1a)), crate::lower::types::Holding::Owned, bt_p1b.clone()))));
    let env2_pi = fold(&out_caps_pf, &env_s_pe, &(|en_p1c: &crate::lower::types::Env, (k_p1d, rs_p1e, _, bt_p1f): &(Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)| crate::lower::types::bind(en_p1c, k_p1d, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(crate::lower::types::place_stem(rs_p1e)), crate::lower::types::Holding::Owned, bt_p1f.clone()))));
    let k_name_pj = Text::from(format!("k_if{}", &span_p6.start));
    let k_do_pk = crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(k_name_pj.clone()), crate::lower::model::Ex::XClosure(true, Array::from(vec![crate::lower::model::Pa::PaTyped(Rc::new(pat_pc.clone()), st_ty_pb.clone())]), Rc::new(run_to_end(cont_f8((outer2_ph.clone(), env2_pi.clone()))))));
    let to_k_fl = {
        let k_name_pj = k_name_pj.clone();
        let pack_pd = pack_pd.clone();
        Rc::new(move |o2_p1g: &crate::lower::types::Env, e2_p1h: &crate::lower::model::Ex| crate::lower::model::Ex::XCall(k_name_pj.clone(), Array::from(vec![pack_pd.clone()]))) as Rc<dyn Fn(&crate::lower::types::Env, &crate::lower::model::Ex) -> crate::lower::model::Ex>
    };
    let branch_fm = {
        let lx_p0 = lx_p0.clone();
        let env_p2 = env_p2.clone();
        let to_k_fl = to_k_fl.clone();
        Rc::new(move |p0: crate::syntax::Block| {
            let lx_p0 = lx_p0.clone();
            let env_p2 = env_p2.clone();
            let to_k_fl = to_k_fl.clone();
            entered(once_job(move || {
                let b_p1i = p0;
                prism_rtl::Turn::More(Rc::new(UpdTailFrom { lx_p0: lx_p0.clone(), outer_p1: env_p2.clone(), env_p2: env_p2.clone(), b_p3: b_p1i.clone(), i_p4: Nat::from(0u32), to_p5: b_p1i.span.clone(), cont_f6: {
                    let f = to_k_fl.clone();
                    Rc::new(move |(a0, a1): (crate::lower::types::Env, crate::lower::model::Ex)| {
                        let f = f.clone();
                        once_job(move || prism_rtl::Turn::Finished(f(&a0, &a1)))
                    }) as Rc<dyn Fn((crate::lower::types::Env, crate::lower::model::Ex)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
                } }))
            }))
        }) as Rc<dyn Fn(crate::syntax::Block) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
    };
    let else_x_pn = match else_b_o5 {
        Some(eb_p1j) => run_to_end((&branch_fm)(eb_p1j.clone())),
        None => crate::lower::model::Ex::XCall(k_name_pj.clone(), Array::from(vec![pack_pd.clone()])),
    };
    let choose_po = match c_p3 {
        crate::syntax::Cond::CondExpr(x_p1k) => crate::lower::model::Ex::XIf(Rc::new(crate::lower::types::as_bool(&crate::lower::expr::value_of(lx_p0, env_p2, &**x_p1k))), Rc::new(run_to_end((&branch_fm)(then_b_p4.clone()))), Rc::new(else_x_pn.clone())),
        crate::syntax::Cond::CondBind(p_p1l, x_p1m, _) => {
            let po_p1n = crate::lower::patterns::rust_pat(lx_p0, p_p1l, &crate::lower::type_at(lx_p0, &x_p1m.span), &crate::lower::types::Holding::Owned, &Text::from(format!("u{}", &x_p1m.span.start)));
            let then_x_p1o = upd_tail_from(lx_p0, &crate::lower::expr::bind_all(env_p2, &po_p1n.binds), &crate::lower::expr::bind_all(env_p2, &po_p1n.binds), then_b_p4, &Nat::from(0u32), &then_b_p4.span, &{
                let f = to_k_fl.clone();
                Rc::new(move |(a0, a1): (crate::lower::types::Env, crate::lower::model::Ex)| {
                    let f = f.clone();
                    once_job(move || prism_rtl::Turn::Finished(f(&a0, &a1)))
                }) as Rc<dyn Fn((crate::lower::types::Env, crate::lower::model::Ex)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
            });
            crate::lower::types::own(&crate::lower::expr::arms_value(&crate::lower::types::own(&crate::lower::expr::value_of(lx_p0, env_p2, &**x_p1m)), &Array::from(vec![crate::lower::model::XArm { pat: po_p1n.pa.clone(), conds: po_p1n.conds.clone(), body: then_x_p1o.clone() }, crate::lower::model::XArm { pat: crate::lower::model::Pa::PaWild, conds: Array::new(), body: else_x_pn.clone() }]), &Text::from(format!("\'u{}", &x_p1m.span.start)), &crate::lower::model::OutTy::OutUnknown(Text::lit("the job\'s turn"))))
        },
    };
    prepend(&push(&out_dos_pg, &k_do_pk), &choose_po)
}

/// The step machine of `IfJob`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// IfJob: unbounded fn Lx, Env, Env, Cond, Block, ?Block, Range, Text, (unbounded fn Env, Env -> Ex) -> Ex
/// ```
pub struct IfJob {
    pub lx_p0: crate::lower::Lx,
    pub outer_p1: crate::lower::types::Env,
    pub env_p2: crate::lower::types::Env,
    pub c_p3: crate::syntax::Cond,
    pub then_b_p4: crate::syntax::Block,
    pub else_b_o5: Option<crate::syntax::Block>,
    pub span_p6: crate::syntax::Range,
    pub rest_text_p7: Text,
    pub cont_f8: Rc<dyn Fn((crate::lower::types::Env, crate::lower::types::Env)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>,
}

impl prism_rtl::Job<crate::lower::model::Ex> for IfJob {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::Ex> {
        let lx_p0 = &self.lx_p0;
        let outer_p1 = &self.outer_p1;
        let env_p2 = &self.env_p2;
        let c_p3 = &self.c_p3;
        let then_b_p4 = &self.then_b_p4;
        let else_b_o5 = &self.else_b_o5;
        let span_p6 = &self.span_p6;
        let rest_text_p7 = &self.rest_text_p7;
        let cont_f8 = &self.cont_f8;
        let state_p9 = fold(&keys(&env_p2.names), &Array::new(), &(|acc_pp: &Array<(Text, Text, crate::lower::model::OutTy)>, k_pq: &Text| if !crate::syntax::lexer::chars::has_prefix(k_pq, &Text::lit("&")) {
            acc_pp.clone()
        } else {
            match get(&env_p2.names, k_pq) {
                Some(crate::lower::types::Bn::BnLocal(rs_pr, _, bt_ps)) => push(acc_pp, &(k_pq.clone(), crate::lower::types::place_stem(&rs_pr), bt_ps)),
                _ => acc_pp.clone(),
            }
        }));
        let names_pa = each(&state_p9, &(|(_, rs_pt, _): &(Text, Text, crate::lower::model::OutTy)| rs_pt.clone()));
        let st_ty_pb = crate::lower::model::OutTy::OutTuple(each(&state_p9, &(|(_, _, bt_pu): &(Text, Text, crate::lower::model::OutTy)| bt_pu.clone())));
        let pat_pc = crate::lower::model::Pa::PaTuple(each(&names_pa, &(|n_pv: &Text| crate::lower::model::Pa::PaMut(Text::from(format!("{}", n_pv))))));
        let pack_pd = crate::lower::model::Ex::XTuple(each(&names_pa, &(|n_p10: &Text| crate::lower::model::Ex::XVar(n_p10.clone()))));
        let env_s_pe = fold(&state_p9, env_p2, &(|en_p11: &crate::lower::types::Env, (k_p12, rs_p13, bt_p14): &(Text, Text, crate::lower::model::OutTy)| crate::lower::types::bind(en_p11, k_p12, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(rs_p13.clone()), crate::lower::types::Holding::Owned, bt_p14.clone()))));
        let out_caps_pf = caps_in(outer_p1, rest_text_p7, &names_pa);
        let out_dos_pg = each(&out_caps_pf, &(|(_, rs_p15, mode_p16, bt_p17): &(Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)| crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::lower::types::place_stem(rs_p15)), crate::lower::types::own(&crate::lower::types::Vl::VlPlace(rs_p15.clone(), mode_p16.clone(), bt_p17.clone())))));
        let outer2_ph = fold(&out_caps_pf, outer_p1, &(|en_p18: &crate::lower::types::Env, (k_p19, rs_p1a, _, bt_p1b): &(Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)| crate::lower::types::bind(en_p18, k_p19, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(crate::lower::types::place_stem(rs_p1a)), crate::lower::types::Holding::Owned, bt_p1b.clone()))));
        let env2_pi = fold(&out_caps_pf, &env_s_pe, &(|en_p1c: &crate::lower::types::Env, (k_p1d, rs_p1e, _, bt_p1f): &(Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)| crate::lower::types::bind(en_p1c, k_p1d, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(crate::lower::types::place_stem(rs_p1e)), crate::lower::types::Holding::Owned, bt_p1f.clone()))));
        let k_name_pj = Text::from(format!("k_if{}", &span_p6.start));
        let else_b_o5 = else_b_o5.clone();
        let cont_f8 = cont_f8.clone();
        let c_p3 = c_p3.clone();
        let env_p2 = env_p2.clone();
        let lx_p0 = lx_p0.clone();
        let span_p6 = span_p6.clone();
        let then_b_p4 = then_b_p4.clone();
        call_value((&cont_f8)((outer2_ph.clone(), env2_pi.clone())), move |cont_15137: crate::lower::model::Ex| {
            let k_do_pk = crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(k_name_pj.clone()), crate::lower::model::Ex::XClosure(true, Array::from(vec![crate::lower::model::Pa::PaTyped(Rc::new(pat_pc.clone()), st_ty_pb.clone())]), Rc::new(cont_15137)));
            let to_k_fl = {
                let k_name_pj = k_name_pj.clone();
                let pack_pd = pack_pd.clone();
                Rc::new(move |o2_p1g: &crate::lower::types::Env, e2_p1h: &crate::lower::model::Ex| crate::lower::model::Ex::XCall(k_name_pj.clone(), Array::from(vec![pack_pd.clone()]))) as Rc<dyn Fn(&crate::lower::types::Env, &crate::lower::model::Ex) -> crate::lower::model::Ex>
            };
            let branch_fm = {
                let lx_p0 = lx_p0.clone();
                let env_p2 = env_p2.clone();
                let to_k_fl = to_k_fl.clone();
                Rc::new(move |p0: crate::syntax::Block| {
                    let lx_p0 = lx_p0.clone();
                    let env_p2 = env_p2.clone();
                    let to_k_fl = to_k_fl.clone();
                    entered(once_job(move || {
                        let b_p1i = p0;
                        prism_rtl::Turn::More(Rc::new(UpdTailFrom { lx_p0: lx_p0.clone(), outer_p1: env_p2.clone(), env_p2: env_p2.clone(), b_p3: b_p1i.clone(), i_p4: Nat::from(0u32), to_p5: b_p1i.span.clone(), cont_f6: {
                            let f = to_k_fl.clone();
                            Rc::new(move |(a0, a1): (crate::lower::types::Env, crate::lower::model::Ex)| {
                                let f = f.clone();
                                once_job(move || prism_rtl::Turn::Finished(f(&a0, &a1)))
                            }) as Rc<dyn Fn((crate::lower::types::Env, crate::lower::model::Ex)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
                        } }))
                    }))
                }) as Rc<dyn Fn(crate::syntax::Block) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
            };
            let else_x_pn = match &else_b_o5 {
                Some(eb_p1j) => run_to_end((&branch_fm)(eb_p1j.clone())),
                None => crate::lower::model::Ex::XCall(k_name_pj.clone(), Array::from(vec![pack_pd.clone()])),
            };
            let choose_po = match &c_p3 {
                crate::syntax::Cond::CondExpr(x_p1k) => crate::lower::model::Ex::XIf(Rc::new(crate::lower::types::as_bool(&crate::lower::expr::value_of(&lx_p0, &env_p2, &**x_p1k))), Rc::new(run_to_end((&branch_fm)(then_b_p4.clone()))), Rc::new(else_x_pn.clone())),
                crate::syntax::Cond::CondBind(p_p1l, x_p1m, _) => {
                    let po_p1n = crate::lower::patterns::rust_pat(&lx_p0, p_p1l, &crate::lower::type_at(&lx_p0, &x_p1m.span), &crate::lower::types::Holding::Owned, &Text::from(format!("u{}", &x_p1m.span.start)));
                    let then_x_p1o = upd_tail_from(&lx_p0, &crate::lower::expr::bind_all(&env_p2, &po_p1n.binds), &crate::lower::expr::bind_all(&env_p2, &po_p1n.binds), &then_b_p4, &Nat::from(0u32), &then_b_p4.span, &{
                        let f = to_k_fl.clone();
                        Rc::new(move |(a0, a1): (crate::lower::types::Env, crate::lower::model::Ex)| {
                            let f = f.clone();
                            once_job(move || prism_rtl::Turn::Finished(f(&a0, &a1)))
                        }) as Rc<dyn Fn((crate::lower::types::Env, crate::lower::model::Ex)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
                    });
                    crate::lower::types::own(&crate::lower::expr::arms_value(&crate::lower::types::own(&crate::lower::expr::value_of(&lx_p0, &env_p2, &**x_p1m)), &Array::from(vec![crate::lower::model::XArm { pat: po_p1n.pa.clone(), conds: po_p1n.conds.clone(), body: then_x_p1o.clone() }, crate::lower::model::XArm { pat: crate::lower::model::Pa::PaWild, conds: Array::new(), body: else_x_pn.clone() }]), &Text::from(format!("\'u{}", &x_p1m.span.start)), &crate::lower::model::OutTy::OutUnknown(Text::lit("the job\'s turn"))))
                },
            };
            prism_rtl::Turn::Finished(prepend(&push(&out_dos_pg, &k_do_pk), &choose_po))
        })
    }
}

/// `Start IfJob, x`: what the function value is when passed to `@Run`.
pub fn start_if_job(lx_p0: crate::lower::Lx, outer_p1: crate::lower::types::Env, env_p2: crate::lower::types::Env, c_p3: crate::syntax::Cond, then_b_p4: crate::syntax::Block, else_b_o5: Option<crate::syntax::Block>, span_p6: crate::syntax::Range, rest_text_p7: Text, cont_f8: Rc<dyn Fn((crate::lower::types::Env, crate::lower::types::Env)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>> {
    Rc::new(IfJob { lx_p0, outer_p1, env_p2, c_p3, then_b_p4, else_b_o5, span_p6, rest_text_p7, cont_f8 })
}

/// ```prism
/// MatchJob: unbounded fn Lx, Env, Env, Expr, [Arm], Range, Text, (unbounded fn Env, Env -> Ex) -> Ex
/// ```
pub fn match_job(lx_p0: &crate::lower::Lx, outer_p1: &crate::lower::types::Env, env_p2: &crate::lower::types::Env, scrut_p3: &crate::syntax::Expr, arms_p4: &Array<crate::syntax::Arm>, span_p5: &crate::syntax::Range, rest_text_p6: &Text, cont_f7: &Rc<dyn Fn((crate::lower::types::Env, crate::lower::types::Env)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>) -> crate::lower::model::Ex {
    let state_p8 = fold(&keys(&env_p2.names), &Array::new(), &(|acc_pn: &Array<(Text, Text, crate::lower::model::OutTy)>, k_po: &Text| if !crate::syntax::lexer::chars::has_prefix(k_po, &Text::lit("&")) {
        acc_pn.clone()
    } else {
        match get(&env_p2.names, k_po) {
            Some(crate::lower::types::Bn::BnLocal(rs_pp, _, bt_pq)) => push(acc_pn, &(k_po.clone(), crate::lower::types::place_stem(&rs_pp), bt_pq)),
            _ => acc_pn.clone(),
        }
    }));
    let names_p9 = each(&state_p8, &(|(_, rs_pr, _): &(Text, Text, crate::lower::model::OutTy)| rs_pr.clone()));
    let st_ty_pa = crate::lower::model::OutTy::OutTuple(each(&state_p8, &(|(_, _, bt_ps): &(Text, Text, crate::lower::model::OutTy)| bt_ps.clone())));
    let pat_pb = crate::lower::model::Pa::PaTuple(each(&names_p9, &(|n_pt: &Text| crate::lower::model::Pa::PaMut(Text::from(format!("{}", n_pt))))));
    let pack_pc = crate::lower::model::Ex::XTuple(each(&names_p9, &(|n_pu: &Text| crate::lower::model::Ex::XVar(n_pu.clone()))));
    let env_s_pd = fold(&state_p8, env_p2, &(|en_pv: &crate::lower::types::Env, (k_p10, rs_p11, bt_p12): &(Text, Text, crate::lower::model::OutTy)| crate::lower::types::bind(en_pv, k_p10, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(rs_p11.clone()), crate::lower::types::Holding::Owned, bt_p12.clone()))));
    let out_caps_pe = caps_in(outer_p1, rest_text_p6, &names_p9);
    let out_dos_pf = each(&out_caps_pe, &(|(_, rs_p13, mode_p14, bt_p15): &(Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)| crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::lower::types::place_stem(rs_p13)), crate::lower::types::own(&crate::lower::types::Vl::VlPlace(rs_p13.clone(), mode_p14.clone(), bt_p15.clone())))));
    let outer2_pg = fold(&out_caps_pe, outer_p1, &(|en_p16: &crate::lower::types::Env, (k_p17, rs_p18, _, bt_p19): &(Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)| crate::lower::types::bind(en_p16, k_p17, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(crate::lower::types::place_stem(rs_p18)), crate::lower::types::Holding::Owned, bt_p19.clone()))));
    let env2_ph = fold(&out_caps_pe, &env_s_pd, &(|en_p1a: &crate::lower::types::Env, (k_p1b, rs_p1c, _, bt_p1d): &(Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)| crate::lower::types::bind(en_p1a, k_p1b, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(crate::lower::types::place_stem(rs_p1c)), crate::lower::types::Holding::Owned, bt_p1d.clone()))));
    let k_name_pi = Text::from(format!("k_match{}", &span_p5.start));
    let k_do_pj = crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(k_name_pi.clone()), crate::lower::model::Ex::XClosure(true, Array::from(vec![crate::lower::model::Pa::PaTyped(Rc::new(pat_pb.clone()), st_ty_pa.clone())]), Rc::new(run_to_end(cont_f7((outer2_pg.clone(), env2_ph.clone()))))));
    let to_k_fk = {
        let k_name_pi = k_name_pi.clone();
        let pack_pc = pack_pc.clone();
        Rc::new(move |o2_p1e: &crate::lower::types::Env, e2_p1f: &crate::lower::model::Ex| crate::lower::model::Ex::XCall(k_name_pi.clone(), Array::from(vec![pack_pc.clone()]))) as Rc<dyn Fn(&crate::lower::types::Env, &crate::lower::model::Ex) -> crate::lower::model::Ex>
    };
    let sty_pl = crate::lower::type_at(lx_p0, &scrut_p3.span);
    let xarms_pm = run_to_end(each_job(crate::check::errors::range0(&len(arms_p4)), {
        let arms_p4 = arms_p4.clone();
        let lx_p0 = lx_p0.clone();
        let sty_pl = sty_pl.clone();
        let scrut_p3 = scrut_p3.clone();
        let env_p2 = env_p2.clone();
        let to_k_fk = to_k_fk.clone();
        Rc::new(move |p0: Nat| {
            let arms_p4 = arms_p4.clone();
            let lx_p0 = lx_p0.clone();
            let sty_pl = sty_pl.clone();
            let scrut_p3 = scrut_p3.clone();
            let env_p2 = env_p2.clone();
            let to_k_fk = to_k_fk.clone();
            entered(once_job(move || {
                let i_p1g = p0;
                {
                    let arm_p1h = or(&index(&arms_p4, &i_p1g), &crate::lower::expr::dummy_arm());
                    call_then(crate::lower::expr::start_arm_pat(lx_p0.clone(), arm_p1h.pattern.clone(), sty_pl.clone(), crate::lower::types::Holding::Owned, Text::from(format!("u{}_{}", &scrut_p3.span.start, &i_p1g))), move |arm_pat_17704: crate::lower::patterns::PatOut| {
                        let po_p1i = arm_pat_17704;
                        let env_a_p1j = crate::lower::expr::bind_all(&env_p2, &po_p1i.binds);
                        call_then(crate::lower::templates::start_guard_conds(lx_p0.clone(), env_a_p1j.clone(), arm_p1h.guard.clone()), move |guard_conds_17848: Array<crate::lower::model::Cc>| {
                            let guarded_p1k = append(&po_p1i.conds, &guard_conds_17848);
                            call_then(start_upd_tail_from(lx_p0.clone(), env_a_p1j.clone(), env_a_p1j.clone(), arm_p1h.body.clone(), Nat::from(0u32), arm_p1h.body.span.clone(), {
                                let f = to_k_fk.clone();
                                Rc::new(move |(a0, a1): (crate::lower::types::Env, crate::lower::model::Ex)| {
                                    let f = f.clone();
                                    once_job(move || prism_rtl::Turn::Finished(f(&a0, &a1)))
                                }) as Rc<dyn Fn((crate::lower::types::Env, crate::lower::model::Ex)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
                            }), move |upd_tail_from_17926: crate::lower::model::Ex| prism_rtl::Turn::Finished(crate::lower::model::XArm { pat: po_p1i.pa.clone(), conds: guarded_p1k.clone(), body: upd_tail_from_17926 }))
                        })
                    })
                }
            }))
        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<crate::lower::model::XArm>>>
    }));
    prepend(&push(&out_dos_pf, &k_do_pj), &crate::lower::types::own(&crate::lower::expr::arms_value(&crate::lower::types::own(&crate::lower::expr::value_of(lx_p0, env_p2, scrut_p3)), &xarms_pm, &Text::from(format!("\'u{}", &scrut_p3.span.start)), &crate::lower::model::OutTy::OutUnknown(Text::lit("the job\'s turn")))))
}

/// The step machine of `MatchJob`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// MatchJob: unbounded fn Lx, Env, Env, Expr, [Arm], Range, Text, (unbounded fn Env, Env -> Ex) -> Ex
/// ```
pub struct MatchJob {
    pub lx_p0: crate::lower::Lx,
    pub outer_p1: crate::lower::types::Env,
    pub env_p2: crate::lower::types::Env,
    pub scrut_p3: crate::syntax::Expr,
    pub arms_p4: Array<crate::syntax::Arm>,
    pub span_p5: crate::syntax::Range,
    pub rest_text_p6: Text,
    pub cont_f7: Rc<dyn Fn((crate::lower::types::Env, crate::lower::types::Env)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>,
}

impl prism_rtl::Job<crate::lower::model::Ex> for MatchJob {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::Ex> {
        let lx_p0 = &self.lx_p0;
        let outer_p1 = &self.outer_p1;
        let env_p2 = &self.env_p2;
        let scrut_p3 = &self.scrut_p3;
        let arms_p4 = &self.arms_p4;
        let span_p5 = &self.span_p5;
        let rest_text_p6 = &self.rest_text_p6;
        let cont_f7 = &self.cont_f7;
        let state_p8 = fold(&keys(&env_p2.names), &Array::new(), &(|acc_pn: &Array<(Text, Text, crate::lower::model::OutTy)>, k_po: &Text| if !crate::syntax::lexer::chars::has_prefix(k_po, &Text::lit("&")) {
            acc_pn.clone()
        } else {
            match get(&env_p2.names, k_po) {
                Some(crate::lower::types::Bn::BnLocal(rs_pp, _, bt_pq)) => push(acc_pn, &(k_po.clone(), crate::lower::types::place_stem(&rs_pp), bt_pq)),
                _ => acc_pn.clone(),
            }
        }));
        let names_p9 = each(&state_p8, &(|(_, rs_pr, _): &(Text, Text, crate::lower::model::OutTy)| rs_pr.clone()));
        let st_ty_pa = crate::lower::model::OutTy::OutTuple(each(&state_p8, &(|(_, _, bt_ps): &(Text, Text, crate::lower::model::OutTy)| bt_ps.clone())));
        let pat_pb = crate::lower::model::Pa::PaTuple(each(&names_p9, &(|n_pt: &Text| crate::lower::model::Pa::PaMut(Text::from(format!("{}", n_pt))))));
        let pack_pc = crate::lower::model::Ex::XTuple(each(&names_p9, &(|n_pu: &Text| crate::lower::model::Ex::XVar(n_pu.clone()))));
        let env_s_pd = fold(&state_p8, env_p2, &(|en_pv: &crate::lower::types::Env, (k_p10, rs_p11, bt_p12): &(Text, Text, crate::lower::model::OutTy)| crate::lower::types::bind(en_pv, k_p10, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(rs_p11.clone()), crate::lower::types::Holding::Owned, bt_p12.clone()))));
        let out_caps_pe = caps_in(outer_p1, rest_text_p6, &names_p9);
        let out_dos_pf = each(&out_caps_pe, &(|(_, rs_p13, mode_p14, bt_p15): &(Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)| crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::lower::types::place_stem(rs_p13)), crate::lower::types::own(&crate::lower::types::Vl::VlPlace(rs_p13.clone(), mode_p14.clone(), bt_p15.clone())))));
        let outer2_pg = fold(&out_caps_pe, outer_p1, &(|en_p16: &crate::lower::types::Env, (k_p17, rs_p18, _, bt_p19): &(Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)| crate::lower::types::bind(en_p16, k_p17, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(crate::lower::types::place_stem(rs_p18)), crate::lower::types::Holding::Owned, bt_p19.clone()))));
        let env2_ph = fold(&out_caps_pe, &env_s_pd, &(|en_p1a: &crate::lower::types::Env, (k_p1b, rs_p1c, _, bt_p1d): &(Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)| crate::lower::types::bind(en_p1a, k_p1b, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(crate::lower::types::place_stem(rs_p1c)), crate::lower::types::Holding::Owned, bt_p1d.clone()))));
        let k_name_pi = Text::from(format!("k_match{}", &span_p5.start));
        let cont_f7 = cont_f7.clone();
        let arms_p4 = arms_p4.clone();
        let env_p2 = env_p2.clone();
        let lx_p0 = lx_p0.clone();
        let scrut_p3 = scrut_p3.clone();
        let span_p5 = span_p5.clone();
        call_value((&cont_f7)((outer2_pg.clone(), env2_ph.clone())), move |cont_17499: crate::lower::model::Ex| {
            let k_do_pj = crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(k_name_pi.clone()), crate::lower::model::Ex::XClosure(true, Array::from(vec![crate::lower::model::Pa::PaTyped(Rc::new(pat_pb.clone()), st_ty_pa.clone())]), Rc::new(cont_17499)));
            let to_k_fk = {
                let k_name_pi = k_name_pi.clone();
                let pack_pc = pack_pc.clone();
                Rc::new(move |o2_p1e: &crate::lower::types::Env, e2_p1f: &crate::lower::model::Ex| crate::lower::model::Ex::XCall(k_name_pi.clone(), Array::from(vec![pack_pc.clone()]))) as Rc<dyn Fn(&crate::lower::types::Env, &crate::lower::model::Ex) -> crate::lower::model::Ex>
            };
            let sty_pl = crate::lower::type_at(&lx_p0, &scrut_p3.span);
            call_value(each_job(crate::check::errors::range0(&len(&arms_p4)), {
                let arms_p4 = arms_p4.clone();
                let lx_p0 = lx_p0.clone();
                let sty_pl = sty_pl.clone();
                let scrut_p3 = scrut_p3.clone();
                let env_p2 = env_p2.clone();
                let to_k_fk = to_k_fk.clone();
                Rc::new(move |p0: Nat| {
                    let arms_p4 = arms_p4.clone();
                    let lx_p0 = lx_p0.clone();
                    let sty_pl = sty_pl.clone();
                    let scrut_p3 = scrut_p3.clone();
                    let env_p2 = env_p2.clone();
                    let to_k_fk = to_k_fk.clone();
                    entered(once_job(move || {
                        let i_p1g = p0;
                        {
                            let arm_p1h = or(&index(&arms_p4, &i_p1g), &crate::lower::expr::dummy_arm());
                            call_then(crate::lower::expr::start_arm_pat(lx_p0.clone(), arm_p1h.pattern.clone(), sty_pl.clone(), crate::lower::types::Holding::Owned, Text::from(format!("u{}_{}", &scrut_p3.span.start, &i_p1g))), move |arm_pat_17704: crate::lower::patterns::PatOut| {
                                let po_p1i = arm_pat_17704;
                                let env_a_p1j = crate::lower::expr::bind_all(&env_p2, &po_p1i.binds);
                                call_then(crate::lower::templates::start_guard_conds(lx_p0.clone(), env_a_p1j.clone(), arm_p1h.guard.clone()), move |guard_conds_17848: Array<crate::lower::model::Cc>| {
                                    let guarded_p1k = append(&po_p1i.conds, &guard_conds_17848);
                                    call_then(start_upd_tail_from(lx_p0.clone(), env_a_p1j.clone(), env_a_p1j.clone(), arm_p1h.body.clone(), Nat::from(0u32), arm_p1h.body.span.clone(), {
                                        let f = to_k_fk.clone();
                                        Rc::new(move |(a0, a1): (crate::lower::types::Env, crate::lower::model::Ex)| {
                                            let f = f.clone();
                                            once_job(move || prism_rtl::Turn::Finished(f(&a0, &a1)))
                                        }) as Rc<dyn Fn((crate::lower::types::Env, crate::lower::model::Ex)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
                                    }), move |upd_tail_from_17926: crate::lower::model::Ex| prism_rtl::Turn::Finished(crate::lower::model::XArm { pat: po_p1i.pa.clone(), conds: guarded_p1k.clone(), body: upd_tail_from_17926 }))
                                })
                            })
                        }
                    }))
                }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<crate::lower::model::XArm>>>
            }), move |each_17617: Array<crate::lower::model::XArm>| {
                let xarms_pm = each_17617;
                call_then(crate::lower::expr::start_value_of(lx_p0.clone(), env_p2.clone(), scrut_p3.clone()), move |value_of_18042: crate::lower::types::Vl| prism_rtl::Turn::Finished(prepend(&push(&out_dos_pf, &k_do_pj), &crate::lower::types::own(&crate::lower::expr::arms_value(&crate::lower::types::own(&value_of_18042), &xarms_pm, &Text::from(format!("\'u{}", &scrut_p3.span.start)), &crate::lower::model::OutTy::OutUnknown(Text::lit("the job\'s turn")))))))
            })
        })
    }
}

/// `Start MatchJob, x`: what the function value is when passed to `@Run`.
pub fn start_match_job(lx_p0: crate::lower::Lx, outer_p1: crate::lower::types::Env, env_p2: crate::lower::types::Env, scrut_p3: crate::syntax::Expr, arms_p4: Array<crate::syntax::Arm>, span_p5: crate::syntax::Range, rest_text_p6: Text, cont_f7: Rc<dyn Fn((crate::lower::types::Env, crate::lower::types::Env)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>> {
    Rc::new(MatchJob { lx_p0, outer_p1, env_p2, scrut_p3, arms_p4, span_p5, rest_text_p6, cont_f7 })
}

/// ```prism
/// ForJob: unbounded fn Lx, Env, Env, ?ForBinders, Expr, Block, Range, Text, (unbounded fn Env, Env -> Ex) -> Ex
/// ```
pub fn for_job(lx_p0: &crate::lower::Lx, outer_p1: &crate::lower::types::Env, env_p2: &crate::lower::types::Env, binders_o3: &Option<crate::syntax::ForBinders>, source_p4: &crate::syntax::Expr, body_p5: &crate::syntax::Block, span_p6: &crate::syntax::Range, rest_text_p7: &Text, cont_f8: &Rc<dyn Fn((crate::lower::types::Env, crate::lower::types::Env)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>) -> crate::lower::model::Ex {
    let state_p9 = fold(&keys(&env_p2.names), &Array::new(), &(|acc_p11: &Array<(Text, Text, crate::lower::model::OutTy)>, k_p12: &Text| if !crate::syntax::lexer::chars::has_prefix(k_p12, &Text::lit("&")) {
        acc_p11.clone()
    } else {
        match get(&env_p2.names, k_p12) {
            Some(crate::lower::types::Bn::BnLocal(rs_p13, _, bt_p14)) => push(acc_p11, &(k_p12.clone(), crate::lower::types::place_stem(&rs_p13), bt_p14)),
            _ => acc_p11.clone(),
        }
    }));
    let names_pa = each(&state_p9, &(|(_, rs_p15, _): &(Text, Text, crate::lower::model::OutTy)| rs_p15.clone()));
    let st_ty_pb = crate::lower::model::OutTy::OutTuple(each(&state_p9, &(|(_, _, bt_p16): &(Text, Text, crate::lower::model::OutTy)| bt_p16.clone())));
    let pat_pc = crate::lower::model::Pa::PaTuple(each(&names_pa, &(|n_p17: &Text| crate::lower::model::Pa::PaMut(Text::from(format!("{}", n_p17))))));
    let pack_pd = crate::lower::model::Ex::XTuple(each(&names_pa, &(|n_p18: &Text| crate::lower::model::Ex::XVar(n_p18.clone()))));
    let env_s_pe = fold(&state_p9, env_p2, &(|en_p19: &crate::lower::types::Env, (k_p1a, rs_p1b, bt_p1c): &(Text, Text, crate::lower::model::OutTy)| crate::lower::types::bind(en_p19, k_p1a, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(rs_p1b.clone()), crate::lower::types::Holding::Owned, bt_p1c.clone()))));
    let src_pf = crate::lower::types::own(&crate::lower::expr::value_of(lx_p0, env_p2, source_p4));
    let sty_pg = crate::lower::types::peel(&crate::lower::type_at(lx_p0, &source_p4.span));
    let (kt_p1g, vt_p1h, is_array_p1i) = match &sty_pg {
        crate::check::types::Ty::TyArray(v_p1d) => (crate::lower::model::OutTy::OutNat, crate::lower::types::out_ty_of(lx_p0, &**v_p1d), true),
        crate::check::types::Ty::TyMap(k_p1e, v_p1f) => (crate::lower::types::out_ty_of(lx_p0, &**k_p1e), crate::lower::types::out_ty_of(lx_p0, &**v_p1f), false),
        _ => (crate::lower::model::OutTy::OutUnit, crate::lower::model::OutTy::OutUnit, true),
    };
    let (vty_p1m, kty_p1n) = match &sty_pg {
        crate::check::types::Ty::TyArray(v_p1j) => ((**v_p1j).clone(), crate::check::types::Ty::TyCon(Text::lit("Nat"), Array::new())),
        crate::check::types::Ty::TyMap(k_p1k, v_p1l) => ((**v_p1l).clone(), (**k_p1k).clone()),
        _ => (crate::check::types::Ty::TyErr, crate::check::types::Ty::TyErr),
    };
    let key_name_ph = Text::from(format!("k{}", &span_p6.start));
    let val_name_pi = Text::from(format!("v{}", &span_p6.start));
    let loop_text_pj = match index(&lx_p0.g.srcs, &lx_p0.file) {
        Some(src2_p1o) => crate::check::errors::span_text(&src2_p1o, span_p6),
        None => Text::lit(""),
    };
    let caps_pk = caps_in(&env_s_pe, &loop_text_pj, &names_pa);
    let cap_dos_pl = each(&caps_pk, &(|(_, rs_p1p, mode_p1q, bt_p1r): &(Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)| crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::lower::types::place_stem(rs_p1p)), crate::lower::types::own(&crate::lower::types::Vl::VlPlace(rs_p1p.clone(), mode_p1q.clone(), bt_p1r.clone())))));
    let env_c_pm = fold(&caps_pk, &env_s_pe, &(|en_p1s: &crate::lower::types::Env, (k_p1t, rs_p1u, _, bt_p1v): &(Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)| crate::lower::types::bind(en_p1s, k_p1t, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(crate::lower::types::place_stem(rs_p1u)), crate::lower::types::Holding::Owned, bt_p1v.clone()))));
    let env1_pn = crate::lower::types::bind(&crate::lower::types::bind(&env_c_pm, &Text::lit("key"), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(key_name_ph.clone()), crate::lower::types::Holding::Owned, kt_p1g.clone())), &Text::lit("_"), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(val_name_pi.clone()), crate::lower::types::Holding::Owned, vt_p1h.clone()));
    let env_k_po = if is_array_p1i {
        crate::lower::types::bind(&env1_pn, &Text::lit("ix"), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(key_name_ph.clone()), crate::lower::types::Holding::Owned, kt_p1g.clone()))
    } else {
        env1_pn.clone()
    };
    let (binds_p25, env_b_p26) = match binders_o3 {
        None => (Array::new(), env_k_po.clone()),
        Some(fb_p20) => match &fb_p20.second {
            None => {
                let po_p21 = crate::lower::patterns::rust_pat(lx_p0, &fb_p20.first, &vty_p1m, &crate::lower::types::Holding::Owned, &Text::from(format!("e{}", &span_p6.start)));
                (Array::from(vec![crate::lower::model::Do::DoLet(po_p21.pa.clone(), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(val_name_pi.clone()))))]), crate::lower::expr::bind_all(&env_k_po, &po_p21.binds))
            },
            Some(second_p22) => {
                let pk_p23 = crate::lower::patterns::rust_pat(lx_p0, &fb_p20.first, &kty_p1n, &crate::lower::types::Holding::Owned, &Text::from(format!("k{}_", &span_p6.start)));
                let pv_p24 = crate::lower::patterns::rust_pat(lx_p0, second_p22, &vty_p1m, &crate::lower::types::Holding::Owned, &Text::from(format!("e{}", &span_p6.start)));
                (Array::from(vec![crate::lower::model::Do::DoLet(pk_p23.pa.clone(), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(key_name_ph.clone())))), crate::lower::model::Do::DoLet(pv_p24.pa.clone(), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(val_name_pi.clone()))))]), crate::lower::expr::bind_all(&crate::lower::expr::bind_all(&env_k_po, &pk_p23.binds), &pv_p24.binds))
            },
        },
    };
    let turn_pp = prepend(&binds_p25, &upd_tail_from(lx_p0, &env_b_p26, &env_b_p26, body_p5, &Nat::from(0u32), &body_p5.span, &{
        let pack_pd = pack_pd.clone();
        Rc::new(move |(p0, p1): (crate::lower::types::Env, crate::lower::model::Ex)| {
            let pack_pd = pack_pd.clone();
            once_job(move || {
                let o2_p27 = p0;
                let e2_p28 = p1;
                prism_rtl::Turn::Finished(crate::lower::model::Ex::XCtor(Text::lit("prism_rtl::Turn::Finished"), Array::from(vec![pack_pd.clone()])))
            })
        }) as Rc<dyn Fn((crate::lower::types::Env, crate::lower::model::Ex)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
    }));
    let step_fn_pq = prepend(&cap_dos_pl, &crate::lower::model::Ex::XClosure(true, Array::from(vec![crate::lower::model::Pa::PaTyped(Rc::new(pat_pc.clone()), st_ty_pb.clone()), crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaBind(key_name_ph.clone())), kt_p1g.clone()), crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaBind(val_name_pi.clone())), vt_p1h.clone())]), Rc::new(turn_pp.clone())));
    let out_caps_pr = caps_in(outer_p1, rest_text_p7, &names_pa);
    let out_dos_ps = each(&out_caps_pr, &(|(_, rs_p29, mode_p2a, bt_p2b): &(Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)| crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::lower::types::place_stem(rs_p29)), crate::lower::types::own(&crate::lower::types::Vl::VlPlace(rs_p29.clone(), mode_p2a.clone(), bt_p2b.clone())))));
    let outer2_pt = fold(&out_caps_pr, outer_p1, &(|en_p2c: &crate::lower::types::Env, (k_p2d, rs_p2e, _, bt_p2f): &(Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)| crate::lower::types::bind(en_p2c, k_p2d, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(crate::lower::types::place_stem(rs_p2e)), crate::lower::types::Holding::Owned, bt_p2f.clone()))));
    let env2_pu = fold(&out_caps_pr, &env_s_pe, &(|en_p2g: &crate::lower::types::Env, (k_p2h, rs_p2i, _, bt_p2j): &(Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)| crate::lower::types::bind(en_p2g, k_p2h, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(crate::lower::types::place_stem(rs_p2i)), crate::lower::types::Holding::Owned, bt_p2j.clone()))));
    let looping_pv = if is_array_p1i {
        Text::lit("for_turns_indexed")
    } else {
        Text::lit("for_turns_keyed")
    };
    let enter_p10 = crate::lower::model::Ex::XCall(Text::lit("call_then"), Array::from(vec![crate::lower::model::Ex::XCall(looping_pv.clone(), Array::from(vec![src_pf.clone(), pack_pd.clone(), step_fn_pq.clone()])), crate::lower::model::Ex::XClosure(true, Array::from(vec![crate::lower::model::Pa::PaTyped(Rc::new(pat_pc.clone()), st_ty_pb.clone())]), Rc::new(run_to_end(cont_f8((outer2_pt.clone(), env2_pu.clone())))))]));
    prepend(&out_dos_ps, &enter_p10)
}

/// The step machine of `ForJob`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ForJob: unbounded fn Lx, Env, Env, ?ForBinders, Expr, Block, Range, Text, (unbounded fn Env, Env -> Ex) -> Ex
/// ```
pub struct ForJob {
    pub lx_p0: crate::lower::Lx,
    pub outer_p1: crate::lower::types::Env,
    pub env_p2: crate::lower::types::Env,
    pub binders_o3: Option<crate::syntax::ForBinders>,
    pub source_p4: crate::syntax::Expr,
    pub body_p5: crate::syntax::Block,
    pub span_p6: crate::syntax::Range,
    pub rest_text_p7: Text,
    pub cont_f8: Rc<dyn Fn((crate::lower::types::Env, crate::lower::types::Env)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>,
}

impl prism_rtl::Job<crate::lower::model::Ex> for ForJob {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::Ex> {
        let lx_p0 = &self.lx_p0;
        let outer_p1 = &self.outer_p1;
        let env_p2 = &self.env_p2;
        let binders_o3 = &self.binders_o3;
        let source_p4 = &self.source_p4;
        let body_p5 = &self.body_p5;
        let span_p6 = &self.span_p6;
        let rest_text_p7 = &self.rest_text_p7;
        let cont_f8 = &self.cont_f8;
        let state_p9 = fold(&keys(&env_p2.names), &Array::new(), &(|acc_p11: &Array<(Text, Text, crate::lower::model::OutTy)>, k_p12: &Text| if !crate::syntax::lexer::chars::has_prefix(k_p12, &Text::lit("&")) {
            acc_p11.clone()
        } else {
            match get(&env_p2.names, k_p12) {
                Some(crate::lower::types::Bn::BnLocal(rs_p13, _, bt_p14)) => push(acc_p11, &(k_p12.clone(), crate::lower::types::place_stem(&rs_p13), bt_p14)),
                _ => acc_p11.clone(),
            }
        }));
        let names_pa = each(&state_p9, &(|(_, rs_p15, _): &(Text, Text, crate::lower::model::OutTy)| rs_p15.clone()));
        let st_ty_pb = crate::lower::model::OutTy::OutTuple(each(&state_p9, &(|(_, _, bt_p16): &(Text, Text, crate::lower::model::OutTy)| bt_p16.clone())));
        let pat_pc = crate::lower::model::Pa::PaTuple(each(&names_pa, &(|n_p17: &Text| crate::lower::model::Pa::PaMut(Text::from(format!("{}", n_p17))))));
        let pack_pd = crate::lower::model::Ex::XTuple(each(&names_pa, &(|n_p18: &Text| crate::lower::model::Ex::XVar(n_p18.clone()))));
        let env_s_pe = fold(&state_p9, env_p2, &(|en_p19: &crate::lower::types::Env, (k_p1a, rs_p1b, bt_p1c): &(Text, Text, crate::lower::model::OutTy)| crate::lower::types::bind(en_p19, k_p1a, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(rs_p1b.clone()), crate::lower::types::Holding::Owned, bt_p1c.clone()))));
        let binders_o3 = binders_o3.clone();
        let cont_f8 = cont_f8.clone();
        let body_p5 = body_p5.clone();
        let env_p2 = env_p2.clone();
        let lx_p0 = lx_p0.clone();
        let outer_p1 = outer_p1.clone();
        let rest_text_p7 = rest_text_p7.clone();
        let source_p4 = source_p4.clone();
        let span_p6 = span_p6.clone();
        call_then(crate::lower::expr::start_value_of(lx_p0.clone(), env_p2.clone(), source_p4.clone()), move |value_of_19279: crate::lower::types::Vl| {
            let src_pf = crate::lower::types::own(&value_of_19279);
            let sty_pg = crate::lower::types::peel(&crate::lower::type_at(&lx_p0, &source_p4.span));
            let (kt_p1g, vt_p1h, is_array_p1i) = match &sty_pg {
                crate::check::types::Ty::TyArray(v_p1d) => (crate::lower::model::OutTy::OutNat, crate::lower::types::out_ty_of(&lx_p0, &**v_p1d), true),
                crate::check::types::Ty::TyMap(k_p1e, v_p1f) => (crate::lower::types::out_ty_of(&lx_p0, &**k_p1e), crate::lower::types::out_ty_of(&lx_p0, &**v_p1f), false),
                _ => (crate::lower::model::OutTy::OutUnit, crate::lower::model::OutTy::OutUnit, true),
            };
            let (vty_p1m, kty_p1n) = match &sty_pg {
                crate::check::types::Ty::TyArray(v_p1j) => ((**v_p1j).clone(), crate::check::types::Ty::TyCon(Text::lit("Nat"), Array::new())),
                crate::check::types::Ty::TyMap(k_p1k, v_p1l) => ((**v_p1l).clone(), (**k_p1k).clone()),
                _ => (crate::check::types::Ty::TyErr, crate::check::types::Ty::TyErr),
            };
            let key_name_ph = Text::from(format!("k{}", &span_p6.start));
            let val_name_pi = Text::from(format!("v{}", &span_p6.start));
            let loop_text_pj = match index(&lx_p0.g.srcs, &lx_p0.file) {
                Some(src2_p1o) => crate::check::errors::span_text(&src2_p1o, &span_p6),
                None => Text::lit(""),
            };
            let caps_pk = caps_in(&env_s_pe, &loop_text_pj, &names_pa);
            let cap_dos_pl = each(&caps_pk, &(|(_, rs_p1p, mode_p1q, bt_p1r): &(Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)| crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::lower::types::place_stem(rs_p1p)), crate::lower::types::own(&crate::lower::types::Vl::VlPlace(rs_p1p.clone(), mode_p1q.clone(), bt_p1r.clone())))));
            let env_c_pm = fold(&caps_pk, &env_s_pe, &(|en_p1s: &crate::lower::types::Env, (k_p1t, rs_p1u, _, bt_p1v): &(Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)| crate::lower::types::bind(en_p1s, k_p1t, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(crate::lower::types::place_stem(rs_p1u)), crate::lower::types::Holding::Owned, bt_p1v.clone()))));
            let env1_pn = crate::lower::types::bind(&crate::lower::types::bind(&env_c_pm, &Text::lit("key"), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(key_name_ph.clone()), crate::lower::types::Holding::Owned, kt_p1g.clone())), &Text::lit("_"), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(val_name_pi.clone()), crate::lower::types::Holding::Owned, vt_p1h.clone()));
            let env_k_po = if is_array_p1i {
                crate::lower::types::bind(&env1_pn, &Text::lit("ix"), &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(key_name_ph.clone()), crate::lower::types::Holding::Owned, kt_p1g.clone()))
            } else {
                env1_pn.clone()
            };
            let (binds_p25, env_b_p26) = match &binders_o3 {
                None => (Array::new(), env_k_po.clone()),
                Some(fb_p20) => match &fb_p20.second {
                    None => {
                        let po_p21 = crate::lower::patterns::rust_pat(&lx_p0, &fb_p20.first, &vty_p1m, &crate::lower::types::Holding::Owned, &Text::from(format!("e{}", &span_p6.start)));
                        (Array::from(vec![crate::lower::model::Do::DoLet(po_p21.pa.clone(), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(val_name_pi.clone()))))]), crate::lower::expr::bind_all(&env_k_po, &po_p21.binds))
                    },
                    Some(second_p22) => {
                        let pk_p23 = crate::lower::patterns::rust_pat(&lx_p0, &fb_p20.first, &kty_p1n, &crate::lower::types::Holding::Owned, &Text::from(format!("k{}_", &span_p6.start)));
                        let pv_p24 = crate::lower::patterns::rust_pat(&lx_p0, second_p22, &vty_p1m, &crate::lower::types::Holding::Owned, &Text::from(format!("e{}", &span_p6.start)));
                        (Array::from(vec![crate::lower::model::Do::DoLet(pk_p23.pa.clone(), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(key_name_ph.clone())))), crate::lower::model::Do::DoLet(pv_p24.pa.clone(), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(val_name_pi.clone()))))]), crate::lower::expr::bind_all(&crate::lower::expr::bind_all(&env_k_po, &pk_p23.binds), &pv_p24.binds))
                    },
                },
            };
            call_then(start_upd_tail_from(lx_p0.clone(), env_b_p26.clone(), env_b_p26.clone(), body_p5.clone(), Nat::from(0u32), body_p5.span.clone(), {
                let pack_pd = pack_pd.clone();
                Rc::new(move |(p0, p1): (crate::lower::types::Env, crate::lower::model::Ex)| {
                    let pack_pd = pack_pd.clone();
                    once_job(move || {
                        let o2_p27 = p0;
                        let e2_p28 = p1;
                        prism_rtl::Turn::Finished(crate::lower::model::Ex::XCtor(Text::lit("prism_rtl::Turn::Finished"), Array::from(vec![pack_pd.clone()])))
                    })
                }) as Rc<dyn Fn((crate::lower::types::Env, crate::lower::model::Ex)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
            }), move |upd_tail_from_21044: crate::lower::model::Ex| {
                let turn_pp = prepend(&binds_p25, &upd_tail_from_21044);
                let step_fn_pq = prepend(&cap_dos_pl, &crate::lower::model::Ex::XClosure(true, Array::from(vec![crate::lower::model::Pa::PaTyped(Rc::new(pat_pc.clone()), st_ty_pb.clone()), crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaBind(key_name_ph.clone())), kt_p1g.clone()), crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaBind(val_name_pi.clone())), vt_p1h.clone())]), Rc::new(turn_pp.clone())));
                let out_caps_pr = caps_in(&outer_p1, &rest_text_p7, &names_pa);
                let out_dos_ps = each(&out_caps_pr, &(|(_, rs_p29, mode_p2a, bt_p2b): &(Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)| crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::lower::types::place_stem(rs_p29)), crate::lower::types::own(&crate::lower::types::Vl::VlPlace(rs_p29.clone(), mode_p2a.clone(), bt_p2b.clone())))));
                let outer2_pt = fold(&out_caps_pr, &outer_p1, &(|en_p2c: &crate::lower::types::Env, (k_p2d, rs_p2e, _, bt_p2f): &(Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)| crate::lower::types::bind(en_p2c, k_p2d, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(crate::lower::types::place_stem(rs_p2e)), crate::lower::types::Holding::Owned, bt_p2f.clone()))));
                let env2_pu = fold(&out_caps_pr, &env_s_pe, &(|en_p2g: &crate::lower::types::Env, (k_p2h, rs_p2i, _, bt_p2j): &(Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)| crate::lower::types::bind(en_p2g, k_p2h, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(crate::lower::types::place_stem(rs_p2i)), crate::lower::types::Holding::Owned, bt_p2j.clone()))));
                let looping_pv = if is_array_p1i {
                    Text::lit("for_turns_indexed")
                } else {
                    Text::lit("for_turns_keyed")
                };
                call_value((&cont_f8)((outer2_pt.clone(), env2_pu.clone())), move |cont_21892: crate::lower::model::Ex| {
                    let enter_p10 = crate::lower::model::Ex::XCall(Text::lit("call_then"), Array::from(vec![crate::lower::model::Ex::XCall(looping_pv.clone(), Array::from(vec![src_pf.clone(), pack_pd.clone(), step_fn_pq.clone()])), crate::lower::model::Ex::XClosure(true, Array::from(vec![crate::lower::model::Pa::PaTyped(Rc::new(pat_pc.clone()), st_ty_pb.clone())]), Rc::new(cont_21892))]));
                    prism_rtl::Turn::Finished(prepend(&out_dos_ps, &enter_p10))
                })
            })
        })
    }
}

/// `Start ForJob, x`: what the function value is when passed to `@Run`.
pub fn start_for_job(lx_p0: crate::lower::Lx, outer_p1: crate::lower::types::Env, env_p2: crate::lower::types::Env, binders_o3: Option<crate::syntax::ForBinders>, source_p4: crate::syntax::Expr, body_p5: crate::syntax::Block, span_p6: crate::syntax::Range, rest_text_p7: Text, cont_f8: Rc<dyn Fn((crate::lower::types::Env, crate::lower::types::Env)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>> {
    Rc::new(ForJob { lx_p0, outer_p1, env_p2, binders_o3, source_p4, body_p5, span_p6, rest_text_p7, cont_f8 })
}

/// ```prism
/// InstanceOf: fn Text -> Text
/// ```
pub fn instance_of(k_p0: &Text) -> Text {
    or(&index(&split_on(k_p0, &Text::lit("#inst")), &Nat::from(0u32)), k_p0)
}

/// ```prism
/// CapsIn: fn Env, Text, [Text] -> [((Text, Ex, Holding, OutTy))]
/// ```
pub fn caps_in(env_p0: &crate::lower::types::Env, text_p1: &Text, skip_p2: &Array<Text>) -> Array<(Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)> {
    fold(&keys(&env_p0.names), &Array::new(), &(|acc_p3: &Array<(Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)>, k_p4: &Text| match get(&env_p0.names, k_p4) {
        Some(crate::lower::types::Bn::BnLocal(rs_p5, mode_p6, bt_p7)) => if (crate::check::types::has_text(skip_p2, &crate::lower::types::place_stem(&rs_p5)) || crate::lower::types::on_self(&rs_p5)) || !mentions(text_p1, &crate::syntax::lexer::chars::drop_prefix(&instance_of(k_p4), &crate::check::types::unify::marks_of(k_p4))) {
            acc_p3.clone()
        } else {
            push(acc_p3, &(k_p4.clone(), rs_p5.clone(), mode_p6, bt_p7))
        },
        _ => acc_p3.clone(),
    }))
}

/// ```prism
/// ?FrameCall: unbounded fn Lx, Env, Expr, Bool -> ?Expr
/// ```
pub fn frame_call(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, e_p2: &crate::syntax::Expr, top_p3: &bool) -> Option<crate::syntax::Expr> {
    if crate::check::env::has_key(&env_p1.spans, &crate::lower::place_key(lx_p0, &e_p2.span)) {
        None
    } else {
        'm23060: {
            let scrutinee = &*e_p2.kind;
            if let crate::syntax::ExprKind::EGroup(x_p4) = scrutinee {
                break 'm23060 frame_call(lx_p0, env_p1, &**x_p4, top_p3);
            }
            if let crate::syntax::ExprKind::ECall(c_p5, args_p6, _, _) = scrutinee {
                break 'm23060 match first_frame(lx_p0, env_p1, &each(args_p6, &(|a_p7: &crate::syntax::Arg| a_p7.value.clone()))) {
                    Some(x_p8) => Some(x_p8),
                    None => if *top_p3 {
                        None
                    } else {
                        match tail_callee(lx_p0, env_p1, &**c_p5) {
                            Some(_) => Some(e_p2.clone()),
                            None => match local_job_fn(lx_p0, env_p1, &**c_p5) {
                                Some(_) => Some(e_p2.clone()),
                                None => match crate::lower::expr::prelude_job_call(lx_p0, env_p1, e_p2) {
                                    Some(_) => Some(e_p2.clone()),
                                    None => None,
                                },
                            },
                        }
                    },
                };
            }
            if let crate::syntax::ExprKind::EMatch(x_p9, _) = scrutinee {
                break 'm23060 frame_call(lx_p0, env_p1, &**x_p9, &false);
            }
            if let crate::syntax::ExprKind::EIf(m23060_3_0, _, _) = scrutinee && let crate::syntax::Cond::CondExpr(x_pa) = &**m23060_3_0 {
                break 'm23060 frame_call(lx_p0, env_p1, &**x_pa, &false);
            }
            if let crate::syntax::ExprKind::EBinary(op_pb, l_pc, r_pd) = scrutinee {
                break 'm23060 if (op_pb == &Text::lit("and")) || (op_pb == &Text::lit("or")) {
                    frame_call(lx_p0, env_p1, &**l_pc, &false)
                } else {
                    first_frame(lx_p0, env_p1, &Array::from(vec![(**l_pc).clone(), (**r_pd).clone()]))
                };
            }
            if let crate::syntax::ExprKind::ETuple(es_pe) = scrutinee {
                break 'm23060 first_frame(lx_p0, env_p1, es_pe);
            }
            if let crate::syntax::ExprKind::EArray(es_pf) = scrutinee {
                break 'm23060 first_frame(lx_p0, env_p1, es_pf);
            }
            if let crate::syntax::ExprKind::EUnary(_, x_pg) = scrutinee {
                break 'm23060 frame_call(lx_p0, env_p1, &**x_pg, &false);
            }
            if let crate::syntax::ExprKind::EField(x_ph, _, _) = scrutinee {
                break 'm23060 frame_call(lx_p0, env_p1, &**x_ph, &false);
            }
            if let crate::syntax::ExprKind::EIndex(x_pi, i_pj) = scrutinee {
                break 'm23060 first_frame(lx_p0, env_p1, &Array::from(vec![(**x_pi).clone(), (**i_pj).clone()]));
            }
            if let crate::syntax::ExprKind::EMethod(x_pk, _, args_pl) = scrutinee {
                break 'm23060 first_frame(lx_p0, env_p1, &append(&Array::from(vec![(**x_pk).clone()]), &each(args_pl, &(|a_pm: &crate::syntax::Arg| a_pm.value.clone()))));
            }
            if let crate::syntax::ExprKind::ECast(x_pn, _, _) = scrutinee {
                break 'm23060 frame_call(lx_p0, env_p1, &**x_pn, &false);
            }
            if let crate::syntax::ExprKind::ELit(l_po) = scrutinee {
                break 'm23060 match &l_po.kind {
                    crate::syntax::LitKind::LText(segs_pp) => first_frame(lx_p0, env_p1, &placeholders(segs_pp)),
                    _ => None,
                };
            }
            None
        }
    }
}

/// The step machine of `FrameCall`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?FrameCall: unbounded fn Lx, Env, Expr, Bool -> ?Expr
/// ```
pub struct FrameCall {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub e_p2: crate::syntax::Expr,
    pub top_p3: bool,
}

impl prism_rtl::Job<Option<crate::syntax::Expr>> for FrameCall {
    fn cycle(&self) -> prism_rtl::Turn<Option<crate::syntax::Expr>> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let e_p2 = &self.e_p2;
        let top_p3 = &self.top_p3;
        if crate::check::env::has_key(&env_p1.spans, &crate::lower::place_key(lx_p0, &e_p2.span)) {
            prism_rtl::Turn::Finished(None)
        } else {
            'm23060: {
                let scrutinee = &*e_p2.kind;
                if let crate::syntax::ExprKind::EGroup(x_p4) = scrutinee {
                    break 'm23060 prism_rtl::Turn::More(Rc::new(FrameCall { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), e_p2: (**x_p4).clone(), top_p3: *top_p3 }));
                }
                if let crate::syntax::ExprKind::ECall(c_p5, args_p6, _, _) = scrutinee {
                    break 'm23060 {
                        let args_p6 = args_p6.clone();
                        let c_p5 = (**c_p5).clone();
                        let e_p2 = e_p2.clone();
                        let env_p1 = env_p1.clone();
                        let lx_p0 = lx_p0.clone();
                        let top_p3 = *top_p3;
                        call_then(start_first_frame(lx_p0.clone(), env_p1.clone(), each(&args_p6, &(|a_p7: &crate::syntax::Arg| a_p7.value.clone()))), move |first_frame_23164: Option<crate::syntax::Expr>| match first_frame_23164 {
                            Some(x_p8) => prism_rtl::Turn::Finished(Some(x_p8.clone())),
                            None => if top_p3 {
                                prism_rtl::Turn::Finished(None)
                            } else {
                                match tail_callee(&lx_p0, &env_p1, &c_p5) {
                                    Some(_) => prism_rtl::Turn::Finished(Some(e_p2.clone())),
                                    None => call_then(start_local_job_fn(lx_p0.clone(), env_p1.clone(), c_p5.clone()), move |local_job_fn_23395: Option<crate::lower::types::Vl>| match local_job_fn_23395 {
                                        Some(_) => prism_rtl::Turn::Finished(Some(e_p2.clone())),
                                        None => call_then(crate::lower::expr::start_prelude_job_call(lx_p0.clone(), env_p1.clone(), e_p2.clone()), move |prelude_job_call_23492: Option<crate::lower::model::Ex>| match prelude_job_call_23492 {
                                            Some(_) => prism_rtl::Turn::Finished(Some(e_p2.clone())),
                                            None => prism_rtl::Turn::Finished(None),
                                        }),
                                    }),
                                }
                            },
                        })
                    };
                }
                if let crate::syntax::ExprKind::EMatch(x_p9, _) = scrutinee {
                    break 'm23060 prism_rtl::Turn::More(Rc::new(FrameCall { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), e_p2: (**x_p9).clone(), top_p3: false }));
                }
                if let crate::syntax::ExprKind::EIf(m23060_3_0, _, _) = scrutinee && let crate::syntax::Cond::CondExpr(x_pa) = &**m23060_3_0 {
                    break 'm23060 prism_rtl::Turn::More(Rc::new(FrameCall { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), e_p2: (**x_pa).clone(), top_p3: false }));
                }
                if let crate::syntax::ExprKind::EBinary(op_pb, l_pc, r_pd) = scrutinee {
                    break 'm23060 if (op_pb == &Text::lit("and")) || (op_pb == &Text::lit("or")) {
                        prism_rtl::Turn::More(Rc::new(FrameCall { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), e_p2: (**l_pc).clone(), top_p3: false }))
                    } else {
                        prism_rtl::Turn::More(Rc::new(FirstFrame { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), es_p2: Array::from(vec![(**l_pc).clone(), (**r_pd).clone()]) }))
                    };
                }
                if let crate::syntax::ExprKind::ETuple(es_pe) = scrutinee {
                    break 'm23060 prism_rtl::Turn::More(Rc::new(FirstFrame { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), es_p2: es_pe.clone() }));
                }
                if let crate::syntax::ExprKind::EArray(es_pf) = scrutinee {
                    break 'm23060 prism_rtl::Turn::More(Rc::new(FirstFrame { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), es_p2: es_pf.clone() }));
                }
                if let crate::syntax::ExprKind::EUnary(_, x_pg) = scrutinee {
                    break 'm23060 prism_rtl::Turn::More(Rc::new(FrameCall { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), e_p2: (**x_pg).clone(), top_p3: false }));
                }
                if let crate::syntax::ExprKind::EField(x_ph, _, _) = scrutinee {
                    break 'm23060 prism_rtl::Turn::More(Rc::new(FrameCall { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), e_p2: (**x_ph).clone(), top_p3: false }));
                }
                if let crate::syntax::ExprKind::EIndex(x_pi, i_pj) = scrutinee {
                    break 'm23060 prism_rtl::Turn::More(Rc::new(FirstFrame { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), es_p2: Array::from(vec![(**x_pi).clone(), (**i_pj).clone()]) }));
                }
                if let crate::syntax::ExprKind::EMethod(x_pk, _, args_pl) = scrutinee {
                    break 'm23060 prism_rtl::Turn::More(Rc::new(FirstFrame { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), es_p2: append(&Array::from(vec![(**x_pk).clone()]), &each(args_pl, &(|a_pm: &crate::syntax::Arg| a_pm.value.clone()))) }));
                }
                if let crate::syntax::ExprKind::ECast(x_pn, _, _) = scrutinee {
                    break 'm23060 prism_rtl::Turn::More(Rc::new(FrameCall { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), e_p2: (**x_pn).clone(), top_p3: false }));
                }
                if let crate::syntax::ExprKind::ELit(l_po) = scrutinee {
                    break 'm23060 match &l_po.kind {
                        crate::syntax::LitKind::LText(segs_pp) => prism_rtl::Turn::More(Rc::new(FirstFrame { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), es_p2: placeholders(segs_pp) })),
                        _ => prism_rtl::Turn::Finished(None),
                    };
                }
                prism_rtl::Turn::Finished(None)
            }
        }
    }
}

/// `Start FrameCall, x`: what the function value is when passed to `@Run`.
pub fn start_frame_call(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, e_p2: crate::syntax::Expr, top_p3: bool) -> Rc<dyn prism_rtl::Job<Option<crate::syntax::Expr>>> {
    Rc::new(FrameCall { lx_p0, env_p1, e_p2, top_p3 })
}

/// ```prism
/// Placeholders: fn [TextSeg] -> [Expr]
/// ```
pub fn placeholders(segs_p0: &Array<crate::syntax::TextSeg>) -> Array<crate::syntax::Expr> {
    fold(segs_p0, &Array::new(), &(|acc_p1: &Array<crate::syntax::Expr>, sg_p2: &crate::syntax::TextSeg| match sg_p2 {
        crate::syntax::TextSeg::SegPlaceholder(x_p3) => push(acc_p1, x_p3),
        _ => acc_p1.clone(),
    }))
}

/// ```prism
/// ?FirstFrame: unbounded fn Lx, Env, [Expr] -> ?Expr
/// ```
pub fn first_frame(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, es_p2: &Array<crate::syntax::Expr>) -> Option<crate::syntax::Expr> {
    run_to_end(fold_job(es_p2.clone(), None, {
        let lx_p0 = lx_p0.clone();
        let env_p1 = env_p1.clone();
        Rc::new(move |(p0, p1): (Option<crate::syntax::Expr>, crate::syntax::Expr)| {
            let lx_p0 = lx_p0.clone();
            let env_p1 = env_p1.clone();
            entered(once_job(move || {
                let found_o3 = p0;
                let x_p4 = p1;
                match &found_o3 {
                    Some(f_p5) => prism_rtl::Turn::Finished(Some(f_p5.clone())),
                    None => prism_rtl::Turn::More(Rc::new(FrameCall { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), e_p2: x_p4.clone(), top_p3: false })),
                }
            }))
        }) as Rc<dyn Fn((Option<crate::syntax::Expr>, crate::syntax::Expr)) -> Rc<dyn prism_rtl::Job<Option<crate::syntax::Expr>>>>
    }))
}

/// The step machine of `FirstFrame`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?FirstFrame: unbounded fn Lx, Env, [Expr] -> ?Expr
/// ```
pub struct FirstFrame {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub es_p2: Array<crate::syntax::Expr>,
}

impl prism_rtl::Job<Option<crate::syntax::Expr>> for FirstFrame {
    fn cycle(&self) -> prism_rtl::Turn<Option<crate::syntax::Expr>> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let es_p2 = &self.es_p2;
        fold_job(es_p2.clone(), None, {
            let lx_p0 = lx_p0.clone();
            let env_p1 = env_p1.clone();
            Rc::new(move |(p0, p1): (Option<crate::syntax::Expr>, crate::syntax::Expr)| {
                let lx_p0 = lx_p0.clone();
                let env_p1 = env_p1.clone();
                entered(once_job(move || {
                    let found_o3 = p0;
                    let x_p4 = p1;
                    match &found_o3 {
                        Some(f_p5) => prism_rtl::Turn::Finished(Some(f_p5.clone())),
                        None => prism_rtl::Turn::More(Rc::new(FrameCall { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), e_p2: x_p4.clone(), top_p3: false })),
                    }
                }))
            }) as Rc<dyn Fn((Option<crate::syntax::Expr>, crate::syntax::Expr)) -> Rc<dyn prism_rtl::Job<Option<crate::syntax::Expr>>>>
        }).cycle()
    }
}

/// `Start FirstFrame, x`: what the function value is when passed to `@Run`.
pub fn start_first_frame(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, es_p2: Array<crate::syntax::Expr>) -> Rc<dyn prism_rtl::Job<Option<crate::syntax::Expr>>> {
    Rc::new(FirstFrame { lx_p0, env_p1, es_p2 })
}

/// ```prism
/// Frame: unbounded fn Lx, Env, Expr, Text, (unbounded fn Env -> Ex) -> Ex
/// ```
pub fn frame(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, call_p2: &crate::syntax::Expr, rest_text_p3: &Text, cont_f4: &Rc<dyn Fn(crate::lower::types::Env) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>) -> crate::lower::model::Ex {
    match &*call_p2.kind {
        crate::syntax::ExprKind::ECall(c_p5, args_p6, _, _) => {
            let qk_o7 = tail_callee(lx_p0, env_p1, &**c_p5);
            let qk_p8 = or(&qk_o7, &Text::lit(""));
            let base_p9 = match &qk_o7 {
                Some(q_pj) => or(&get(&lx_p0.rs_names, q_pj), &crate::lower::snake(&crate::check::types::bare_name(q_pj))),
                None => crate::lower::snake(&callee_text(&**c_p5)),
            };
            let v_pa = Text::from(format!("{}_{}", &base_p9, &call_p2.span.start));
            let t_pb = crate::lower::types::out_ty_of(lx_p0, &crate::lower::types::peel(&crate::lower::type_at(lx_p0, &call_p2.span)));
            let caps_pc = fold(&keys(&env_p1.names), &Array::new(), &(|acc_pk: &Array<(Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)>, k_pl: &Text| match get(&env_p1.names, k_pl) {
                Some(crate::lower::types::Bn::BnLocal(rs_pm, mode_pn, bt_po)) => if ((&mode_pn == &crate::lower::types::Holding::ByRef) || (&mode_pn == &crate::lower::types::Holding::RcRef)) && mentions(rest_text_p3, &instance_of(k_pl)) {
                    push(acc_pk, &(k_pl.clone(), rs_pm, mode_pn.clone(), bt_po))
                } else {
                    acc_pk.clone()
                },
                _ => acc_pk.clone(),
            }));
            let dos_pd = each(&caps_pc, &(|(_, rs_pp, mode_pq, bt_pr): &(Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)| crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::lower::types::place_stem(rs_pp)), crate::lower::types::own(&crate::lower::types::Vl::VlPlace(rs_pp.clone(), mode_pq.clone(), bt_pr.clone())))));
            let env2_pe = fold(&caps_pc, env_p1, &(|en_ps: &crate::lower::types::Env, (k_pt, rs_pu, _, bt_pv): &(Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)| crate::lower::types::bind(en_ps, k_pt, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(crate::lower::types::place_stem(rs_pu)), crate::lower::types::Holding::Owned, bt_pv.clone()))));
            let vals_pf = match &qk_o7 {
                Some(q_p10) => crate::lower::expr::named_args_owned(lx_p0, &env2_pe, q_p10, args_p6),
                None => match local_job_fn(lx_p0, &env2_pe, &**c_p5) {
                    Some(f_p11) => crate::lower::expr::start_args(lx_p0, &env2_pe, &f_p11, args_p6),
                    None => run_to_end(each_job(args_p6.clone(), {
                        let lx_p0 = lx_p0.clone();
                        let env2_pe = env2_pe.clone();
                        Rc::new(move |p0: crate::syntax::Arg| {
                            let lx_p0 = lx_p0.clone();
                            let env2_pe = env2_pe.clone();
                            entered(once_job(move || {
                                let a_p12 = p0;
                                call_then(crate::lower::expr::start_value_of(lx_p0.clone(), env2_pe.clone(), a_p12.value.clone()), move |value_of_26215: crate::lower::types::Vl| prism_rtl::Turn::Finished(crate::lower::types::own(&value_of_26215)))
                            }))
                        }) as Rc<dyn Fn(crate::syntax::Arg) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
                    })),
                },
            };
            let env3_pg = crate::lower::types::bind_span(&env2_pe, &crate::lower::place_key(lx_p0, &call_p2.span), &crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XVar(v_pa.clone()), t_pb.clone()));
            let body_ph = run_to_end(cont_f4(env3_pg.clone()));
            let (job_p16, how_p17) = match &qk_o7 {
                Some(q_p13) => (crate::lower::model::Ex::XCall(crate::lower::path_in(lx_p0, &crate::lower::owner_of(q_p13), &Text::from(format!("start_{}", &base_p9))), vals_pf.clone()), if crate::lower::program::enters_at_once(lx_p0, q_p13, args_p6) {
                    Text::lit("call_value")
                } else {
                    Text::lit("call_then")
                }),
                None => match local_job_fn(lx_p0, &env2_pe, &**c_p5) {
                    Some(f_p14) => (start_call(&f_p14, &vals_pf), Text::lit("call_value")),
                    None => match crate::lower::expr::prelude_job_call(lx_p0, &env2_pe, call_p2) {
                        Some(pj_p15) => (pj_p15, Text::lit("call_value")),
                        None => (crate::lower::expr::refusal(&Text::lit("a call this frame cannot enter")), Text::lit("call_then")),
                    },
                },
            };
            let enter_pi = if crate::lower::expr::is_lifted_at(lx_p0, &call_p2.span) {
                crate::lower::expr::refusal(&Text::from(format!("an unbounded call lifted over `?` or `~` (`{}`)", &crate::lower::functions::src_text(lx_p0, &lx_p0.file, &call_p2.span))))
            } else {
                crate::lower::model::Ex::XCall(how_p17.clone(), Array::from(vec![job_p16.clone(), crate::lower::model::Ex::XClosure(true, Array::from(vec![crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaBind(v_pa.clone())), t_pb.clone())]), Rc::new(body_ph.clone()))]))
            };
            if &len(&dos_pd) == &Nat::from(0u32) {
                enter_pi.clone()
            } else {
                crate::lower::model::Ex::XBlock(dos_pd.clone(), Rc::new(enter_pi.clone()))
            }
        },
        _ => run_to_end(cont_f4(env_p1.clone())),
    }
}

/// The step machine of `Frame`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Frame: unbounded fn Lx, Env, Expr, Text, (unbounded fn Env -> Ex) -> Ex
/// ```
pub struct Frame {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub call_p2: crate::syntax::Expr,
    pub rest_text_p3: Text,
    pub cont_f4: Rc<dyn Fn(crate::lower::types::Env) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>,
}

impl prism_rtl::Job<crate::lower::model::Ex> for Frame {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::Ex> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let call_p2 = &self.call_p2;
        let rest_text_p3 = &self.rest_text_p3;
        let cont_f4 = &self.cont_f4;
        match &*call_p2.kind {
            crate::syntax::ExprKind::ECall(c_p5, args_p6, _, _) => {
                let qk_o7 = tail_callee(lx_p0, env_p1, &**c_p5);
                let qk_p8 = or(&qk_o7, &Text::lit(""));
                let base_p9 = match &qk_o7 {
                    Some(q_pj) => or(&get(&lx_p0.rs_names, q_pj), &crate::lower::snake(&crate::check::types::bare_name(q_pj))),
                    None => crate::lower::snake(&callee_text(&**c_p5)),
                };
                let v_pa = Text::from(format!("{}_{}", &base_p9, &call_p2.span.start));
                let cont_f4 = cont_f4.clone();
                let args_p6 = args_p6.clone();
                let c_p5 = (**c_p5).clone();
                let call_p2 = call_p2.clone();
                let env_p1 = env_p1.clone();
                let lx_p0 = lx_p0.clone();
                let rest_text_p3 = rest_text_p3.clone();
                call_then(crate::lower::types::start_out_ty_of(lx_p0.clone(), crate::lower::types::peel(&crate::lower::type_at(&lx_p0, &call_p2.span))), move |out_ty_of_25460: crate::lower::model::OutTy| {
                    let t_pb = out_ty_of_25460;
                    let caps_pc = fold(&keys(&env_p1.names), &Array::new(), &(|acc_pk: &Array<(Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)>, k_pl: &Text| match get(&env_p1.names, k_pl) {
                        Some(crate::lower::types::Bn::BnLocal(rs_pm, mode_pn, bt_po)) => if ((&mode_pn == &crate::lower::types::Holding::ByRef) || (&mode_pn == &crate::lower::types::Holding::RcRef)) && mentions(&rest_text_p3, &instance_of(k_pl)) {
                            push(acc_pk, &(k_pl.clone(), rs_pm, mode_pn.clone(), bt_po))
                        } else {
                            acc_pk.clone()
                        },
                        _ => acc_pk.clone(),
                    }));
                    let dos_pd = each(&caps_pc, &(|(_, rs_pp, mode_pq, bt_pr): &(Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)| crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(crate::lower::types::place_stem(rs_pp)), crate::lower::types::own(&crate::lower::types::Vl::VlPlace(rs_pp.clone(), mode_pq.clone(), bt_pr.clone())))));
                    let env2_pe = fold(&caps_pc, &env_p1, &(|en_ps: &crate::lower::types::Env, (k_pt, rs_pu, _, bt_pv): &(Text, crate::lower::model::Ex, crate::lower::types::Holding, crate::lower::model::OutTy)| crate::lower::types::bind(en_ps, k_pt, &crate::lower::types::Bn::BnLocal(crate::lower::model::Ex::XVar(crate::lower::types::place_stem(rs_pu)), crate::lower::types::Holding::Owned, bt_pv.clone()))));
                    let vals_pf = match &qk_o7 {
                        Some(q_p10) => crate::lower::expr::named_args_owned(&lx_p0, &env2_pe, q_p10, &args_p6),
                        None => match local_job_fn(&lx_p0, &env2_pe, &c_p5) {
                            Some(f_p11) => crate::lower::expr::start_args(&lx_p0, &env2_pe, &f_p11, &args_p6),
                            None => run_to_end(each_job(args_p6.clone(), {
                                let lx_p0 = lx_p0.clone();
                                let env2_pe = env2_pe.clone();
                                Rc::new(move |p0: crate::syntax::Arg| {
                                    let lx_p0 = lx_p0.clone();
                                    let env2_pe = env2_pe.clone();
                                    entered(once_job(move || {
                                        let a_p12 = p0;
                                        call_then(crate::lower::expr::start_value_of(lx_p0.clone(), env2_pe.clone(), a_p12.value.clone()), move |value_of_26215: crate::lower::types::Vl| prism_rtl::Turn::Finished(crate::lower::types::own(&value_of_26215)))
                                    }))
                                }) as Rc<dyn Fn(crate::syntax::Arg) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
                            })),
                        },
                    };
                    let env3_pg = crate::lower::types::bind_span(&env2_pe, &crate::lower::place_key(&lx_p0, &call_p2.span), &crate::lower::types::Vl::VlOwned(crate::lower::model::Ex::XVar(v_pa.clone()), t_pb.clone()));
                    call_value((&cont_f4)(env3_pg.clone()), move |cont_26343: crate::lower::model::Ex| {
                        let body_ph = cont_26343;
                        let (job_p16, how_p17) = match &qk_o7 {
                            Some(q_p13) => (crate::lower::model::Ex::XCall(crate::lower::path_in(&lx_p0, &crate::lower::owner_of(q_p13), &Text::from(format!("start_{}", &base_p9))), vals_pf.clone()), if crate::lower::program::enters_at_once(&lx_p0, q_p13, &args_p6) {
                                Text::lit("call_value")
                            } else {
                                Text::lit("call_then")
                            }),
                            None => match local_job_fn(&lx_p0, &env2_pe, &c_p5) {
                                Some(f_p14) => (start_call(&f_p14, &vals_pf), Text::lit("call_value")),
                                None => match crate::lower::expr::prelude_job_call(&lx_p0, &env2_pe, &call_p2) {
                                    Some(pj_p15) => (pj_p15, Text::lit("call_value")),
                                    None => (crate::lower::expr::refusal(&Text::lit("a call this frame cannot enter")), Text::lit("call_then")),
                                },
                            },
                        };
                        let enter_pi = if crate::lower::expr::is_lifted_at(&lx_p0, &call_p2.span) {
                            crate::lower::expr::refusal(&Text::from(format!("an unbounded call lifted over `?` or `~` (`{}`)", &crate::lower::functions::src_text(&lx_p0, &lx_p0.file, &call_p2.span))))
                        } else {
                            crate::lower::model::Ex::XCall(how_p17.clone(), Array::from(vec![job_p16.clone(), crate::lower::model::Ex::XClosure(true, Array::from(vec![crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaBind(v_pa.clone())), t_pb.clone())]), Rc::new(body_ph.clone()))]))
                        };
                        if &len(&dos_pd) == &Nat::from(0u32) {
                            prism_rtl::Turn::Finished(enter_pi.clone())
                        } else {
                            prism_rtl::Turn::Finished(crate::lower::model::Ex::XBlock(dos_pd.clone(), Rc::new(enter_pi.clone())))
                        }
                    })
                })
            },
            _ => cont_f4(env_p1.clone()).cycle(),
        }
    }
}

/// `Start Frame, x`: what the function value is when passed to `@Run`.
pub fn start_frame(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, call_p2: crate::syntax::Expr, rest_text_p3: Text, cont_f4: Rc<dyn Fn(crate::lower::types::Env) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>> {
    Rc::new(Frame { lx_p0, env_p1, call_p2, rest_text_p3, cont_f4 })
}

/// ```prism
/// ?LocalJobFn: unbounded fn Lx, Env, Expr -> ?Vl
/// ```
pub fn local_job_fn(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, c_p2: &crate::syntax::Expr) -> Option<crate::lower::types::Vl> {
    match &*c_p2.kind {
        crate::syntax::ExprKind::EName(n_p3) => if (&len(&n_p3.path_) == &Nat::from(1u32)) && crate::check::env::has_key(&env_p1.names, &crate::check::env::sname_key(n_p3)) {
            job_value(&crate::lower::expr::name_value(lx_p0, env_p1, n_p3, &c_p2.span))
        } else {
            None
        },
        crate::syntax::ExprKind::EGroup(x_p4) => local_job_fn(lx_p0, env_p1, &**x_p4),
        crate::syntax::ExprKind::EField(_, _, _) => job_value(&crate::lower::expr::value_of(lx_p0, env_p1, c_p2)),
        _ => None,
    }
}

/// The step machine of `LocalJobFn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?LocalJobFn: unbounded fn Lx, Env, Expr -> ?Vl
/// ```
pub struct LocalJobFn {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub c_p2: crate::syntax::Expr,
}

impl prism_rtl::Job<Option<crate::lower::types::Vl>> for LocalJobFn {
    fn cycle(&self) -> prism_rtl::Turn<Option<crate::lower::types::Vl>> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let c_p2 = &self.c_p2;
        match &*c_p2.kind {
            crate::syntax::ExprKind::EName(n_p3) => if (&len(&n_p3.path_) == &Nat::from(1u32)) && crate::check::env::has_key(&env_p1.names, &crate::check::env::sname_key(n_p3)) {
                {
                    let c_p2 = c_p2.clone();
                    let env_p1 = env_p1.clone();
                    let lx_p0 = lx_p0.clone();
                    let n_p3 = n_p3.clone();
                    call_then(crate::lower::expr::start_name_value(lx_p0.clone(), env_p1.clone(), n_p3.clone(), c_p2.span.clone()), move |name_value_27527: crate::lower::types::Vl| prism_rtl::Turn::Finished(job_value(&name_value_27527)))
                }
            } else {
                prism_rtl::Turn::Finished(None)
            },
            crate::syntax::ExprKind::EGroup(x_p4) => prism_rtl::Turn::More(Rc::new(LocalJobFn { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), c_p2: (**x_p4).clone() })),
            crate::syntax::ExprKind::EField(_, _, _) => {
                let c_p2 = c_p2.clone();
                let env_p1 = env_p1.clone();
                let lx_p0 = lx_p0.clone();
                call_then(crate::lower::expr::start_value_of(lx_p0.clone(), env_p1.clone(), c_p2.clone()), move |value_of_27658: crate::lower::types::Vl| prism_rtl::Turn::Finished(job_value(&value_of_27658)))
            },
            _ => prism_rtl::Turn::Finished(None),
        }
    }
}

/// `Start LocalJobFn, x`: what the function value is when passed to `@Run`.
pub fn start_local_job_fn(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, c_p2: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<Option<crate::lower::types::Vl>>> {
    Rc::new(LocalJobFn { lx_p0, env_p1, c_p2 })
}

/// ```prism
/// ?JobValue: fn Vl -> ?Vl
/// ```
pub fn job_value(f_p0: &crate::lower::types::Vl) -> Option<crate::lower::types::Vl> {
    match crate::lower::types::value_ty(f_p0) {
        crate::lower::model::OutTy::OutJobFn(_, _) => Some(f_p0.clone()),
        _ => None,
    }
}

/// ```prism
/// StartCall: fn Vl, [Ex] -> Ex
/// ```
pub fn start_call(f_p0: &crate::lower::types::Vl, vals_p1: &Array<crate::lower::model::Ex>) -> crate::lower::model::Ex {
    crate::lower::model::Ex::XApply(Rc::new(crate::lower::types::ref_(f_p0)), Array::from(vec![one_or_tuple(vals_p1)]))
}

/// ```prism
/// OneOrTuple: fn [Ex] -> Ex
/// ```
pub fn one_or_tuple(xs0: &Array<crate::lower::model::Ex>) -> crate::lower::model::Ex {
    'c: {
        if let c0_0 = xs0 && (c0_0.len() == 1) && let Some(one_p0) = index(c0_0, &Nat::from(0u32)) {
            break 'c one_p0.clone();
        }
        if let vals_p1 = xs0 {
            break 'c crate::lower::model::Ex::XTuple(vals_p1.clone());
        }
        unreachable!("no clause matched")
    }
}

/// ```prism
/// CalleeText: fn Expr -> Text
/// ```
pub fn callee_text(c_p0: &crate::syntax::Expr) -> Text {
    match &*c_p0.kind {
        crate::syntax::ExprKind::EName(n_p1) => crate::check::env::dotted(&n_p1.path_),
        crate::syntax::ExprKind::EGroup(x_p2) => callee_text(&**x_p2),
        _ => Text::lit("call"),
    }
}

/// ```prism
/// RestText: fn Lx, Range, Range, Range -> Text
/// ```
pub fn rest_text(lx_p0: &crate::lower::Lx, from_p1: &crate::syntax::Range, call_p2: &crate::syntax::Range, to_p3: &crate::syntax::Range) -> Text {
    match index(&lx_p0.g.srcs, &lx_p0.file) {
        Some(src_p4) => crate::check::errors::span_text(&src_p4, &crate::syntax::Range { start: from_p1.start.clone(), end: to_p3.end.clone() }),
        None => Text::lit(""),
    }
}

/// ```prism
/// Mentions: fn Text, Text -> Bool
/// ```
pub fn mentions(text_p0: &Text, name_p1: &Text) -> bool {
    let parts_p2 = split_on(text_p0, name_p1);
    let last_p3 = crate::syntax::lexer::chars::dec(&len(&parts_p2));
    fold(&crate::check::errors::range0(&last_p3), &false, &(|found_p4: &bool, i_p5: &Nat| {
        let before_p6 = or(&index(&parts_p2, i_p5), &Text::lit(""));
        let after_p7 = or(&index(&parts_p2, &(i_p5 + &Nat::from(1u32))), &Text::lit(""));
        let left_word_p8 = if &before_p6 != &Text::lit("") {
            ends_ident(&before_p6)
        } else {
            (i_p5 > &Nat::from(0u32)) && ends_ident(name_p1)
        };
        let right_word_p9 = if &after_p7 != &Text::lit("") {
            starts_ident(&after_p7)
        } else {
            (&(i_p5 + &Nat::from(1u32)) < &last_p3) && starts_ident(name_p1)
        };
        *found_p4 || (!left_word_p8 && !right_word_p9)
    }))
}

/// ```prism
/// EndsIdent: fn Text -> Bool
/// ```
pub fn ends_ident(t_p0: &Text) -> bool {
    (&len_text(t_p0) > &Nat::from(0u32)) && crate::syntax::lexer::chars::is_ident_char(&crate::syntax::lexer::chars::last_char(t_p0))
}

/// ```prism
/// StartsIdent: fn Text -> Bool
/// ```
pub fn starts_ident(t_p0: &Text) -> bool {
    (&len_text(t_p0) > &Nat::from(0u32)) && crate::syntax::lexer::chars::is_ident_char(&crate::syntax::lexer::chars::head(t_p0))
}

/// ```prism
/// TailBody: unbounded fn Lx, Env, FnBody -> Ex
/// ```
pub fn tail_body(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, fn_body2: &crate::syntax::decls::FnBody) -> crate::lower::model::Ex {
    match fn_body2 {
        crate::syntax::decls::FnBody::BodyExpr(x_p2) => tail(lx_p0, env_p1, x_p2),
        crate::syntax::decls::FnBody::BodyBlock(b_p5) => tail_block(lx_p0, env_p1, b_p5),
    }
}

/// The step machine of `TailBody`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TailBody: unbounded fn Lx, Env, FnBody -> Ex
/// ```
pub struct TailBody {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub fn_body2: crate::syntax::decls::FnBody,
}

impl prism_rtl::Job<crate::lower::model::Ex> for TailBody {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::Ex> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let fn_body2 = &self.fn_body2;
        match fn_body2 {
            crate::syntax::decls::FnBody::BodyExpr(x_p2) => prism_rtl::Turn::More(Rc::new(Tail { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), e_p2: x_p2.clone() })),
            crate::syntax::decls::FnBody::BodyBlock(b_p5) => prism_rtl::Turn::More(Rc::new(TailBlock { lx_p0: lx_p0.clone(), env_p1: env_p1.clone(), b_p2: b_p5.clone() })),
        }
    }
}

/// `Start TailBody, x`: what the function value is when passed to `@Run`.
pub fn start_tail_body(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, fn_body2: crate::syntax::decls::FnBody) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>> {
    Rc::new(TailBody { lx_p0, env_p1, fn_body2 })
}

/// ```prism
/// TailMatch: unbounded fn Lx, Env, Expr, [Arm], Range -> Ex
/// ```
pub fn tail_match(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, s_p2: &crate::syntax::Expr, arms_p3: &Array<crate::syntax::Arm>, span_p4: &crate::syntax::Range) -> crate::lower::model::Ex {
    let sv_p5 = crate::lower::expr::value_of(lx_p0, env_p1, s_p2);
    let sty_p6 = crate::lower::type_at(lx_p0, &s_p2.span);
    let label_p7 = Text::from(format!("m{}", &span_p4.start));
    let by_ref_p8 = run_to_end(each_job(crate::check::errors::range0(&len(arms_p3)), {
        let lx_p0 = lx_p0.clone();
        let arms_p3 = arms_p3.clone();
        let sty_p6 = sty_p6.clone();
        let label_p7 = label_p7.clone();
        Rc::new(move |p0: Nat| {
            let lx_p0 = lx_p0.clone();
            let arms_p3 = arms_p3.clone();
            let sty_p6 = sty_p6.clone();
            let label_p7 = label_p7.clone();
            entered(once_job(move || {
                let i_pe = p0;
                prism_rtl::Turn::More(Rc::new(crate::lower::expr::ArmPat { lx_p0: lx_p0.clone(), opt1: or(&index(&arms_p3, &i_pe), &crate::lower::expr::dummy_arm()).pattern.clone(), ty_p2: sty_p6.clone(), mode_p3: crate::lower::types::Holding::ByRef, fresh_p4: Text::from(format!("{}_{}", &label_p7, &i_pe)) }))
            }))
        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<crate::lower::patterns::PatOut>>>
    }));
    let chain_p9 = fold(&by_ref_p8, &false, &(|f_pf: &bool, po_pg: &crate::lower::patterns::PatOut| *f_pf || fold(&po_pg.conds, &false, &(|f2_ph: &bool, c_pi: &crate::lower::model::Cc| *f2_ph || crate::lower::expr::is_let_cond(c_pi)))));
    let owned_pa = match &sv_p5 {
        crate::lower::types::Vl::VlOwned(_, _) => !chain_p9,
        _ => false,
    };
    let pats_pb = if owned_pa {
        run_to_end(each_job(crate::check::errors::range0(&len(arms_p3)), {
            let lx_p0 = lx_p0.clone();
            let arms_p3 = arms_p3.clone();
            let sty_p6 = sty_p6.clone();
            let label_p7 = label_p7.clone();
            Rc::new(move |p0: Nat| {
                let lx_p0 = lx_p0.clone();
                let arms_p3 = arms_p3.clone();
                let sty_p6 = sty_p6.clone();
                let label_p7 = label_p7.clone();
                entered(once_job(move || {
                    let i_pj = p0;
                    prism_rtl::Turn::More(Rc::new(crate::lower::expr::ArmPat { lx_p0: lx_p0.clone(), opt1: or(&index(&arms_p3, &i_pj), &crate::lower::expr::dummy_arm()).pattern.clone(), ty_p2: sty_p6.clone(), mode_p3: crate::lower::types::Holding::Owned, fresh_p4: Text::from(format!("{}_{}", &label_p7, &i_pj)) }))
                }))
            }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<crate::lower::patterns::PatOut>>>
        }))
    } else {
        by_ref_p8.clone()
    };
    let xarms_pc = run_to_end(each_job(crate::check::errors::range0(&len(arms_p3)), {
        let arms_p3 = arms_p3.clone();
        let pats_pb = pats_pb.clone();
        let env_p1 = env_p1.clone();
        let lx_p0 = lx_p0.clone();
        Rc::new(move |p0: Nat| {
            let arms_p3 = arms_p3.clone();
            let pats_pb = pats_pb.clone();
            let env_p1 = env_p1.clone();
            let lx_p0 = lx_p0.clone();
            entered(once_job(move || {
                let i_pk = p0;
                {
                    let arm_pl = or(&index(&arms_p3, &i_pk), &crate::lower::expr::dummy_arm());
                    let po_pm = or(&index(&pats_pb, &i_pk), &crate::lower::patterns::PatOut { pa: crate::lower::model::Pa::PaWild, conds: Array::new(), binds: Array::new() });
                    let env2_pn = crate::lower::expr::bind_all(&env_p1, &po_pm.binds);
                    call_then(crate::lower::templates::start_guard_conds(lx_p0.clone(), env2_pn.clone(), arm_pl.guard.clone()), move |guard_conds_30570: Array<crate::lower::model::Cc>| call_then(start_tail_block(lx_p0.clone(), env2_pn.clone(), arm_pl.body.clone()), move |tail_block_30611: crate::lower::model::Ex| prism_rtl::Turn::Finished(crate::lower::model::XArm { pat: po_pm.pa.clone(), conds: append(&po_pm.conds, &guard_conds_30570), body: tail_block_30611 })))
                }
            }))
        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<crate::lower::model::XArm>>>
    }));
    let scrut_pd = if owned_pa {
        crate::lower::types::own(&sv_p5)
    } else {
        crate::lower::types::ref_(&sv_p5)
    };
    crate::lower::types::own(&crate::lower::expr::arms_value(&scrut_pd, &xarms_pc, &Text::from(format!("\'{}", &label_p7)), &crate::lower::model::OutTy::OutUnknown(Text::lit("the job\'s turn"))))
}

/// The step machine of `TailMatch`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TailMatch: unbounded fn Lx, Env, Expr, [Arm], Range -> Ex
/// ```
pub struct TailMatch {
    pub lx_p0: crate::lower::Lx,
    pub env_p1: crate::lower::types::Env,
    pub s_p2: crate::syntax::Expr,
    pub arms_p3: Array<crate::syntax::Arm>,
    pub span_p4: crate::syntax::Range,
}

impl prism_rtl::Job<crate::lower::model::Ex> for TailMatch {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::Ex> {
        let lx_p0 = &self.lx_p0;
        let env_p1 = &self.env_p1;
        let s_p2 = &self.s_p2;
        let arms_p3 = &self.arms_p3;
        let span_p4 = &self.span_p4;
        let arms_p3 = arms_p3.clone();
        let env_p1 = env_p1.clone();
        let lx_p0 = lx_p0.clone();
        let s_p2 = s_p2.clone();
        let span_p4 = span_p4.clone();
        call_then(crate::lower::expr::start_value_of(lx_p0.clone(), env_p1.clone(), s_p2.clone()), move |value_of_29792: crate::lower::types::Vl| {
            let sv_p5 = value_of_29792;
            let sty_p6 = crate::lower::type_at(&lx_p0, &s_p2.span);
            let label_p7 = Text::from(format!("m{}", &span_p4.start));
            call_value(each_job(crate::check::errors::range0(&len(&arms_p3)), {
                let lx_p0 = lx_p0.clone();
                let arms_p3 = arms_p3.clone();
                let sty_p6 = sty_p6.clone();
                let label_p7 = label_p7.clone();
                Rc::new(move |p0: Nat| {
                    let lx_p0 = lx_p0.clone();
                    let arms_p3 = arms_p3.clone();
                    let sty_p6 = sty_p6.clone();
                    let label_p7 = label_p7.clone();
                    entered(once_job(move || {
                        let i_pe = p0;
                        prism_rtl::Turn::More(Rc::new(crate::lower::expr::ArmPat { lx_p0: lx_p0.clone(), opt1: or(&index(&arms_p3, &i_pe), &crate::lower::expr::dummy_arm()).pattern.clone(), ty_p2: sty_p6.clone(), mode_p3: crate::lower::types::Holding::ByRef, fresh_p4: Text::from(format!("{}_{}", &label_p7, &i_pe)) }))
                    }))
                }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<crate::lower::patterns::PatOut>>>
            }), move |each_29891: Array<crate::lower::patterns::PatOut>| {
                let by_ref_p8 = each_29891;
                let chain_p9 = fold(&by_ref_p8, &false, &(|f_pf: &bool, po_pg: &crate::lower::patterns::PatOut| *f_pf || fold(&po_pg.conds, &false, &(|f2_ph: &bool, c_pi: &crate::lower::model::Cc| *f2_ph || crate::lower::expr::is_let_cond(c_pi)))));
                let owned_pa = match &sv_p5 {
                    crate::lower::types::Vl::VlOwned(_, _) => !chain_p9,
                    _ => false,
                };
                let pats_pb = if owned_pa {
                    run_to_end(each_job(crate::check::errors::range0(&len(&arms_p3)), {
                        let lx_p0 = lx_p0.clone();
                        let arms_p3 = arms_p3.clone();
                        let sty_p6 = sty_p6.clone();
                        let label_p7 = label_p7.clone();
                        Rc::new(move |p0: Nat| {
                            let lx_p0 = lx_p0.clone();
                            let arms_p3 = arms_p3.clone();
                            let sty_p6 = sty_p6.clone();
                            let label_p7 = label_p7.clone();
                            entered(once_job(move || {
                                let i_pj = p0;
                                prism_rtl::Turn::More(Rc::new(crate::lower::expr::ArmPat { lx_p0: lx_p0.clone(), opt1: or(&index(&arms_p3, &i_pj), &crate::lower::expr::dummy_arm()).pattern.clone(), ty_p2: sty_p6.clone(), mode_p3: crate::lower::types::Holding::Owned, fresh_p4: Text::from(format!("{}_{}", &label_p7, &i_pj)) }))
                            }))
                        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<crate::lower::patterns::PatOut>>>
                    }))
                } else {
                    by_ref_p8.clone()
                };
                call_value(each_job(crate::check::errors::range0(&len(&arms_p3)), {
                    let arms_p3 = arms_p3.clone();
                    let pats_pb = pats_pb.clone();
                    let env_p1 = env_p1.clone();
                    let lx_p0 = lx_p0.clone();
                    Rc::new(move |p0: Nat| {
                        let arms_p3 = arms_p3.clone();
                        let pats_pb = pats_pb.clone();
                        let env_p1 = env_p1.clone();
                        let lx_p0 = lx_p0.clone();
                        entered(once_job(move || {
                            let i_pk = p0;
                            {
                                let arm_pl = or(&index(&arms_p3, &i_pk), &crate::lower::expr::dummy_arm());
                                let po_pm = or(&index(&pats_pb, &i_pk), &crate::lower::patterns::PatOut { pa: crate::lower::model::Pa::PaWild, conds: Array::new(), binds: Array::new() });
                                let env2_pn = crate::lower::expr::bind_all(&env_p1, &po_pm.binds);
                                call_then(crate::lower::templates::start_guard_conds(lx_p0.clone(), env2_pn.clone(), arm_pl.guard.clone()), move |guard_conds_30570: Array<crate::lower::model::Cc>| call_then(start_tail_block(lx_p0.clone(), env2_pn.clone(), arm_pl.body.clone()), move |tail_block_30611: crate::lower::model::Ex| prism_rtl::Turn::Finished(crate::lower::model::XArm { pat: po_pm.pa.clone(), conds: append(&po_pm.conds, &guard_conds_30570), body: tail_block_30611 })))
                            }
                        }))
                    }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<crate::lower::model::XArm>>>
                }), move |each_30337: Array<crate::lower::model::XArm>| {
                    let xarms_pc = each_30337;
                    let scrut_pd = if owned_pa {
                        crate::lower::types::own(&sv_p5)
                    } else {
                        crate::lower::types::ref_(&sv_p5)
                    };
                    prism_rtl::Turn::Finished(crate::lower::types::own(&crate::lower::expr::arms_value(&scrut_pd, &xarms_pc, &Text::from(format!("\'{}", &label_p7)), &crate::lower::model::OutTy::OutUnknown(Text::lit("the job\'s turn")))))
                })
            })
        })
    }
}

/// `Start TailMatch, x`: what the function value is when passed to `@Run`.
pub fn start_tail_match(lx_p0: crate::lower::Lx, env_p1: crate::lower::types::Env, s_p2: crate::syntax::Expr, arms_p3: Array<crate::syntax::Arm>, span_p4: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>> {
    Rc::new(TailMatch { lx_p0, env_p1, s_p2, arms_p3, span_p4 })
}

/// ```prism
/// ?TailCallee: fn Lx, Env, Expr -> ?Text
/// ```
pub fn tail_callee(lx_p0: &crate::lower::Lx, env_p1: &crate::lower::types::Env, callee_p2: &crate::syntax::Expr) -> Option<Text> {
    match &*callee_p2.kind {
        crate::syntax::ExprKind::EName(n_p3) => if (&len(&n_p3.path_) == &Nat::from(1u32)) && crate::check::env::has_key(&env_p1.names, &crate::check::env::sname_key(n_p3)) {
            None
        } else {
            {
                let (qk_o4, _) = crate::check::env::names::resolve_value(&lx_p0.g, &lx_p0.home, n_p3);
                match &qk_o4 {
                    Some(qk_p5) => if crate::check::types::has_text(&lx_p0.unbs, qk_p5) && !crate::lower::program::in_prelude(lx_p0, qk_p5) {
                        Some(qk_p5.clone())
                    } else {
                        None
                    },
                    None => None,
                }
            }
        },
        _ => None,
    }
}

/// ```prism
/// SchemeParts: fn Lx, Text -> (([Ty], Ty))
/// ```
pub fn scheme_parts(lx_p0: &crate::lower::Lx, qk_p1: &Text) -> (Array<crate::check::types::Ty>, crate::check::types::Ty) {
    match get(&lx_p0.g.vals, qk_p1) {
        Some(v_p2) => match &v_p2.scheme.ty {
            crate::check::types::Ty::TyFn(_, ps_p3, r_p4) => (ps_p3.clone(), (**r_p4).clone()),
            other_p5 => (Array::new(), other_p5.clone()),
        },
        None => (Array::new(), crate::check::types::Ty::TyErr),
    }
}

/// ```prism
/// JobFieldNames: unbounded fn Lx, Text -> [Text]
/// ```
pub fn job_field_names(lx_p0: &crate::lower::Lx, qk_p1: &Text) -> Array<Text> {
    let clauses_p2 = clauses_of(&lx_p0.g, qk_p1);
    let (ptys_p5, _) = scheme_parts(lx_p0, qk_p1);
    let pts_p3 = run_to_end(each_job(ptys_p5.clone(), {
        let lx_p0 = lx_p0.clone();
        Rc::new(move |p0: crate::check::types::Ty| {
            let lx_p0 = lx_p0.clone();
            entered(once_job(move || {
                let p_p6 = p0;
                prism_rtl::Turn::More(Rc::new(crate::lower::types::OutTyOf { lx_p0: lx_p0.clone(), t_p1: crate::lower::types::peel(&p_p6) }))
            }))
        }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::lower::model::OutTy>>>
    }));
    let lxf_p4 = {
        let mut this: crate::lower::Lx = lx_p0.clone();
        this.file = fold(&lx_p0.g.defs, &lx_p0.file, &(|f_p7: &Nat, d_p8: &crate::check::env::Def| if &d_p8.qk == qk_p1 { d_p8.file.clone() } else { f_p7.clone() }));
        this
    };
    each(&crate::lower::functions::param_names(&lxf_p4, &clauses_p2, &pts_p3), &(|(n_p9, _): &(Text, bool)| n_p9.clone()))
}

/// The step machine of `JobFieldNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// JobFieldNames: unbounded fn Lx, Text -> [Text]
/// ```
pub struct JobFieldNames {
    pub lx_p0: crate::lower::Lx,
    pub qk_p1: Text,
}

impl prism_rtl::Job<Array<Text>> for JobFieldNames {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let lx_p0 = &self.lx_p0;
        let qk_p1 = &self.qk_p1;
        let clauses_p2 = clauses_of(&lx_p0.g, qk_p1);
        let (ptys_p5, _) = scheme_parts(lx_p0, qk_p1);
        let lx_p0 = lx_p0.clone();
        let qk_p1 = qk_p1.clone();
        call_value(each_job(ptys_p5.clone(), {
            let lx_p0 = lx_p0.clone();
            Rc::new(move |p0: crate::check::types::Ty| {
                let lx_p0 = lx_p0.clone();
                entered(once_job(move || {
                    let p_p6 = p0;
                    prism_rtl::Turn::More(Rc::new(crate::lower::types::OutTyOf { lx_p0: lx_p0.clone(), t_p1: crate::lower::types::peel(&p_p6) }))
                }))
            }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::lower::model::OutTy>>>
        }), move |each_31678: Array<crate::lower::model::OutTy>| {
            let pts_p3 = each_31678;
            let lxf_p4 = {
                let mut this: crate::lower::Lx = lx_p0.clone();
                this.file = fold(&lx_p0.g.defs, &lx_p0.file, &(|f_p7: &Nat, d_p8: &crate::check::env::Def| if &d_p8.qk == &qk_p1 { d_p8.file.clone() } else { f_p7.clone() }));
                this
            };
            call_then(crate::lower::functions::start_param_names(lxf_p4.clone(), clauses_p2.clone(), pts_p3.clone()), move |param_names_31912: Array<(Text, bool)>| prism_rtl::Turn::Finished(each(&param_names_31912, &(|(n_p9, _): &(Text, bool)| n_p9.clone()))))
        })
    }
}

/// `Start JobFieldNames, x`: what the function value is when passed to `@Run`.
pub fn start_job_field_names(lx_p0: crate::lower::Lx, qk_p1: Text) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(JobFieldNames { lx_p0, qk_p1 })
}

/// ```prism
/// ClausesOf: fn G, Text -> [FnClause]
/// ```
pub fn clauses_of(g_p0: &crate::check::env::G, qk_p1: &Text) -> Array<crate::syntax::decls::FnClause> {
    fold(&g_p0.defs, &Array::new(), &(|acc_p2: &Array<crate::syntax::decls::FnClause>, d_p3: &crate::check::env::Def| if &d_p3.qk == qk_p1 { def_clauses(d_p3, acc_p2) } else { acc_p2.clone() }))
}

/// ```prism
/// DefClauses: fn Def, [FnClause] -> [FnClause]
/// ```
pub fn def_clauses(d_p0: &crate::check::env::Def, other_p1: &Array<crate::syntax::decls::FnClause>) -> Array<crate::syntax::decls::FnClause> {
    match &d_p0.body {
        crate::check::env::DefBody::DbFn(cs_p2) => cs_p2.clone(),
        _ => other_p1.clone(),
    }
}

/// ```prism
/// JobDefOf: unbounded fn Lx, Text, [FnClause], Scheme -> JobDef
/// ```
pub fn job_def_of(lx_p0: &crate::lower::Lx, qk_p1: &Text, clauses_p2: &Array<crate::syntax::decls::FnClause>, sc_p3: &crate::check::types::Scheme) -> crate::lower::model::JobDef {
    let (ptys_pb, res_pc) = match &sc_p3.ty {
        crate::check::types::Ty::TyFn(_, ps_p8, r_p9) => (ps_p8.clone(), (**r_p9).clone()),
        other_pa => (Array::new(), other_pa.clone()),
    };
    let pts_p4 = run_to_end(each_job(ptys_pb.clone(), {
        let lx_p0 = lx_p0.clone();
        Rc::new(move |p0: crate::check::types::Ty| {
            let lx_p0 = lx_p0.clone();
            entered(once_job(move || {
                let p_pd = p0;
                prism_rtl::Turn::More(Rc::new(crate::lower::types::OutTyOf { lx_p0: lx_p0.clone(), t_p1: crate::lower::types::peel(&p_pd) }))
            }))
        }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::lower::model::OutTy>>>
    }));
    let names_p5 = crate::lower::functions::param_names(lx_p0, clauses_p2, &pts_p4);
    let body_p6 = job_clauses(lx_p0, clauses_p2, &names_p5, &ptys_pb, &pts_p4);
    let base_p7 = or(&get(&lx_p0.rs_names, qk_p1), &crate::lower::snake(&crate::check::types::bare_name(qk_p1)));
    crate::lower::model::JobDef { name: crate::lower::camel(&crate::check::types::bare_name(qk_p1)), start: Text::from(format!("start_{}", &base_p7)), generics: crate::lower::functions::scheme_generics(lx_p0, sc_p3), fields: each(&crate::check::errors::range0(&len(&pts_p4)), &(|i_pe: &Nat| (or(&index(&each(&names_p5, &(|(n_pf, _): &(Text, bool)| n_pf.clone())), i_pe), &Text::lit("arg")), or(&index(&pts_p4, i_pe), &crate::lower::model::OutTy::OutUnit)))), ret: crate::lower::types::out_ty_of(lx_p0, &crate::lower::types::peel(&res_pc)), body: body_p6.clone(), doc: crate::lower::functions::signature_text(lx_p0, qk_p1) }
}

/// The step machine of `JobDefOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// JobDefOf: unbounded fn Lx, Text, [FnClause], Scheme -> JobDef
/// ```
pub struct JobDefOf {
    pub lx_p0: crate::lower::Lx,
    pub qk_p1: Text,
    pub clauses_p2: Array<crate::syntax::decls::FnClause>,
    pub sc_p3: crate::check::types::Scheme,
}

impl prism_rtl::Job<crate::lower::model::JobDef> for JobDefOf {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::JobDef> {
        let lx_p0 = &self.lx_p0;
        let qk_p1 = &self.qk_p1;
        let clauses_p2 = &self.clauses_p2;
        let sc_p3 = &self.sc_p3;
        let (ptys_pb, res_pc) = match &sc_p3.ty {
            crate::check::types::Ty::TyFn(_, ps_p8, r_p9) => (ps_p8.clone(), (**r_p9).clone()),
            other_pa => (Array::new(), other_pa.clone()),
        };
        let clauses_p2 = clauses_p2.clone();
        let lx_p0 = lx_p0.clone();
        let qk_p1 = qk_p1.clone();
        let sc_p3 = sc_p3.clone();
        call_value(each_job(ptys_pb.clone(), {
            let lx_p0 = lx_p0.clone();
            Rc::new(move |p0: crate::check::types::Ty| {
                let lx_p0 = lx_p0.clone();
                entered(once_job(move || {
                    let p_pd = p0;
                    prism_rtl::Turn::More(Rc::new(crate::lower::types::OutTyOf { lx_p0: lx_p0.clone(), t_p1: crate::lower::types::peel(&p_pd) }))
                }))
            }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::lower::model::OutTy>>>
        }), move |each_32520: Array<crate::lower::model::OutTy>| {
            let pts_p4 = each_32520;
            call_then(crate::lower::functions::start_param_names(lx_p0.clone(), clauses_p2.clone(), pts_p4.clone()), move |param_names_32573: Array<(Text, bool)>| {
                let names_p5 = param_names_32573;
                call_then(start_job_clauses(lx_p0.clone(), clauses_p2.clone(), names_p5.clone(), ptys_pb.clone(), pts_p4.clone()), move |job_clauses_32616: crate::lower::model::Ex| {
                    let body_p6 = job_clauses_32616;
                    let base_p7 = or(&get(&lx_p0.rs_names, &qk_p1), &crate::lower::snake(&crate::check::types::bare_name(&qk_p1)));
                    call_then(crate::lower::types::start_out_ty_of(lx_p0.clone(), crate::lower::types::peel(&res_pc)), move |out_ty_of_32927: crate::lower::model::OutTy| prism_rtl::Turn::Finished(crate::lower::model::JobDef { name: crate::lower::camel(&crate::check::types::bare_name(&qk_p1)), start: Text::from(format!("start_{}", &base_p7)), generics: crate::lower::functions::scheme_generics(&lx_p0, &sc_p3), fields: each(&crate::check::errors::range0(&len(&pts_p4)), &(|i_pe: &Nat| (or(&index(&each(&names_p5, &(|(n_pf, _): &(Text, bool)| n_pf.clone())), i_pe), &Text::lit("arg")), or(&index(&pts_p4, i_pe), &crate::lower::model::OutTy::OutUnit)))), ret: out_ty_of_32927, body: body_p6.clone(), doc: crate::lower::functions::signature_text(&lx_p0, &qk_p1) }))
                })
            })
        })
    }
}

/// `Start JobDefOf, x`: what the function value is when passed to `@Run`.
pub fn start_job_def_of(lx_p0: crate::lower::Lx, qk_p1: Text, clauses_p2: Array<crate::syntax::decls::FnClause>, sc_p3: crate::check::types::Scheme) -> Rc<dyn prism_rtl::Job<crate::lower::model::JobDef>> {
    Rc::new(JobDefOf { lx_p0, qk_p1, clauses_p2, sc_p3 })
}

/// ```prism
/// JobClauses: unbounded fn Lx, [FnClause], [((Text, Bool))], [Ty], [OutTy] -> Ex
/// ```
pub fn job_clauses(lx_p0: &crate::lower::Lx, clauses_p1: &Array<crate::syntax::decls::FnClause>, names_p2: &Array<(Text, bool)>, ptys_p3: &Array<crate::check::types::Ty>, pts_p4: &Array<crate::lower::model::OutTy>) -> crate::lower::model::Ex {
    let lets_p5 = each(&crate::check::errors::range0(&len(names_p2)), &(|i_p7: &Nat| {
        let (rs_p8, _) = or(&index(names_p2, i_p7), &(Text::lit("arg"), true));
        crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(rs_p8.clone()), crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), rs_p8.clone()))))
    }));
    let inner_p6 = crate::lower::functions::clauses_body(lx_p0, &crate::lower::types::empty_env(), clauses_p1, names_p2, ptys_p3, &(Rc::new(|(a0, a1, a2): (crate::lower::Lx, crate::lower::types::Env, crate::syntax::decls::FnBody)| entered(start_tail_body(a0, a1, a2))) as Rc<dyn Fn((crate::lower::Lx, crate::lower::types::Env, crate::syntax::decls::FnBody)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>), &Text::lit("j"), &crate::lower::model::OutTy::OutUnknown(Text::lit("the job\'s turn")));
    crate::lower::model::Ex::XBlock(lets_p5.clone(), Rc::new(inner_p6.clone()))
}

/// The step machine of `JobClauses`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// JobClauses: unbounded fn Lx, [FnClause], [((Text, Bool))], [Ty], [OutTy] -> Ex
/// ```
pub struct JobClauses {
    pub lx_p0: crate::lower::Lx,
    pub clauses_p1: Array<crate::syntax::decls::FnClause>,
    pub names_p2: Array<(Text, bool)>,
    pub ptys_p3: Array<crate::check::types::Ty>,
    pub pts_p4: Array<crate::lower::model::OutTy>,
}

impl prism_rtl::Job<crate::lower::model::Ex> for JobClauses {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::Ex> {
        let lx_p0 = &self.lx_p0;
        let clauses_p1 = &self.clauses_p1;
        let names_p2 = &self.names_p2;
        let ptys_p3 = &self.ptys_p3;
        let pts_p4 = &self.pts_p4;
        let lets_p5 = each(&crate::check::errors::range0(&len(names_p2)), &(|i_p7: &Nat| {
            let (rs_p8, _) = or(&index(names_p2, i_p7), &(Text::lit("arg"), true));
            crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(rs_p8.clone()), crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), rs_p8.clone()))))
        }));
        let clauses_p1 = clauses_p1.clone();
        let lx_p0 = lx_p0.clone();
        let names_p2 = names_p2.clone();
        let ptys_p3 = ptys_p3.clone();
        call_then(crate::lower::functions::start_clauses_body(lx_p0.clone(), crate::lower::types::empty_env(), clauses_p1.clone(), names_p2.clone(), ptys_p3.clone(), Rc::new(|(a0, a1, a2): (crate::lower::Lx, crate::lower::types::Env, crate::syntax::decls::FnBody)| entered(start_tail_body(a0, a1, a2))) as Rc<dyn Fn((crate::lower::Lx, crate::lower::types::Env, crate::syntax::decls::FnBody)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>, Text::lit("j"), crate::lower::model::OutTy::OutUnknown(Text::lit("the job\'s turn"))), move |clauses_body_33356: crate::lower::model::Ex| {
            let inner_p6 = clauses_body_33356;
            prism_rtl::Turn::Finished(crate::lower::model::Ex::XBlock(lets_p5.clone(), Rc::new(inner_p6.clone())))
        })
    }
}

/// `Start JobClauses, x`: what the function value is when passed to `@Run`.
pub fn start_job_clauses(lx_p0: crate::lower::Lx, clauses_p1: Array<crate::syntax::decls::FnClause>, names_p2: Array<(Text, bool)>, ptys_p3: Array<crate::check::types::Ty>, pts_p4: Array<crate::lower::model::OutTy>) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>> {
    Rc::new(JobClauses { lx_p0, clauses_p1, names_p2, ptys_p3, pts_p4 })
}
